import json
from .base import *
from dagba.services import builder as B, settings as S

def jpeg_bytes():
    from PIL import Image; b = io.BytesIO(); Image.new('RGB', (40, 30), (20, 90, 200)).save(b, 'JPEG'); return b.getvalue()

def mp4(n=3000): return b"\x00\x00\x00\x18ftypmp42\x00\x00\x00\x00mp42isom" + bytes(range(256)) * (n // 256 + 1)
def jpost(c, tc, url, obj, **kw): return c.post(url, data=json.dumps(obj), content_type="application/json", headers={"X-CSRF-Token": tc.tok(c)}, **kw)

class BuilderBase(Base):
    def upload_video(self, c, data=None, name="lesson.mp4", split=2):
        data = data if data is not None else mp4()
        r = jpost(c, self, "/staff/builder/upload/init", {"name": name, "size": len(data)}); j = r.get_json(); self.assertTrue(j["ok"], j)
        uid = j["upload_id"]; step = -(-len(data) // split)
        for i in range(split):
            r = c.post(f"/staff/builder/upload/{uid}/chunk?index={i}", data=data[i * step:(i + 1) * step], content_type="application/octet-stream", headers={"X-CSRF-Token": self.tok(c)}); self.assertTrue(r.get_json()["ok"])
        return uid, jpost(c, self, f"/staff/builder/upload/{uid}/finish", {})
    def payload(self, **kw):
        p = {"action": "draft", "title": "Algebra Basics", "division": "academic", "academic_level": "basic", "category_id": dbm.val("SELECT id FROM categories WHERE slug='academic-mathematics'"), "summary": "s", "price": "5000", "modules": [{"id": None, "title": "Intro", "lessons": [{"title": "Welcome", "kind": "text", "body": "hello"}]}]}
        p.update(kw)
        if p["division"] == "income" and "category_id" not in kw: p["category_id"] = ""; p["academic_level"] = ""          # Income Skills has no academic level
        return p

class BuilderAccessTests(BuilderBase):
    def test_who_can_open_builder_and_catalog(self):
        for who, code in (("owner", 200), ("inst", 200), ("alice", 403), ("writer", 403), ("officer", 403), ("noperm", 403)):
            self.assertEqual(self.client(who).get("/staff/builder").status_code, code, who); self.assertEqual(self.client(who).get("/staff/catalog").status_code, code, who)
        self.assertEqual(self.app.test_client().get("/staff/builder").status_code, 302)
    def test_instructor_cannot_open_others_course(self):
        other = dbm.ex("INSERT INTO courses(division,title,slug,status,instructor_id) VALUES ('academic','O','o','draft',?)", (self.users["owner"],))
        self.assertEqual(self.client("inst").get(f"/staff/builder/{other}").status_code, 404); self.assertEqual(self.client("owner").get(f"/staff/builder/{other}").status_code, 200)
        i = self.client("inst"); r = jpost(i, self, "/staff/builder/save", self.payload(id=other)); self.assertEqual(r.status_code, 404)
    def test_save_requires_csrf_and_login(self):
        c = self.client("owner"); self.assertEqual(c.post("/staff/builder/save", data="{}", content_type="application/json").status_code, 400)
        self.assertEqual(jpost(self.app.test_client(), self, "/staff/builder/save", {}).status_code, 401)

class ChunkedUploadTests(BuilderBase):
    def test_full_chunked_upload_and_storage(self):
        c = self.client("inst"); uid, r = self.upload_video(c); j = r.get_json(); self.assertTrue(j["ok"], j)
        self.assertRegex(j["file"], r"^[0-9a-f]{32}\.mp4$"); path = os.path.join(self.app.config["PRIVATE_DIR"], j["file"]); self.assertEqual(open(path, "rb").read(), mp4())
        self.assertEqual(self.client().get("/static/" + j["file"]).status_code, 404)
    def test_resume_status_and_out_of_order(self):
        c = self.client("inst"); data = mp4(); j = jpost(c, self, "/staff/builder/upload/init", {"name": "a.mp4", "size": len(data)}).get_json(); uid = j["upload_id"]
        h = {"X-CSRF-Token": self.tok(c)}; half = len(data) // 2
        c.post(f"/staff/builder/upload/{uid}/chunk?index=0", data=data[:half], headers=h)
        st = c.get(f"/staff/builder/upload/{uid}/status").get_json(); self.assertEqual((st["next_index"], st["received"]), (1, half))   # a fresh session can resume from here
        r = c.post(f"/staff/builder/upload/{uid}/chunk?index=5", data=data[half:], headers=h); self.assertEqual(r.status_code, 409); self.assertEqual(r.get_json()["expected"], 1)
        r = jpost(c, self, f"/staff/builder/upload/{uid}/finish", {}); self.assertEqual(r.status_code, 409)                       # incomplete
        c.post(f"/staff/builder/upload/{uid}/chunk?index=1", data=data[half:], headers=h); self.assertTrue(jpost(c, self, f"/staff/builder/upload/{uid}/finish", {}).get_json()["ok"])
    def test_rejections(self):
        c = self.client("inst")
        for name, size in (("x.exe", 100), ("x.mp4", 0), ("x.mp4", 600 * 1024 * 1024)):
            r = jpost(c, self, "/staff/builder/upload/init", {"name": name, "size": size}); self.assertEqual(r.status_code, 400, (name, size))
        _, r = self.upload_video(c, data=b"<?php echo 1; ?>" + b"0" * 100, name="evil.mp4"); self.assertEqual(r.status_code, 400)       # content != extension
        _, r = self.upload_video(c, data=mp4(), name="v.webm"); self.assertEqual(r.status_code, 400)                                   # mp4 bytes named .webm
        S.put("video.max_mb", "10"); r = jpost(c, self, "/staff/builder/upload/init", {"name": "a.mp4", "size": 11 * 1024 * 1024}); self.assertEqual(r.status_code, 400)
        self.assertEqual(self.val("SELECT COUNT(*) FROM uploads WHERE status='ready'"), 0)
    def test_other_user_cannot_touch_my_upload(self):
        c = self.client("inst"); uid = jpost(c, self, "/staff/builder/upload/init", {"name": "a.mp4", "size": 100}).get_json()["upload_id"]
        o = self.client("owner"); self.assertEqual(o.get(f"/staff/builder/upload/{uid}/status").status_code, 404)
        self.assertEqual(o.post(f"/staff/builder/upload/{uid}/chunk?index=0", data=b"x" * 100, headers={"X-CSRF-Token": self.tok(o)}).status_code, 404)
        for who in ("alice", "writer"): w = self.client(who); self.assertEqual(w.post("/staff/builder/upload/init", data="{}", content_type="application/json", headers={"X-CSRF-Token": self.tok(w)}).status_code, 403)
    def test_thumbnail_and_resource_uploads(self):
        c = self.client("inst"); r = c.post("/staff/builder/thumbnail", data={"file": (io.BytesIO(png_bytes()), "t.png")}, headers={"X-CSRF-Token": self.tok(c)}, content_type="multipart/form-data"); self.assertTrue(r.get_json()["ok"])
        r = c.post("/staff/builder/thumbnail", data={"file": (io.BytesIO(b"<svg/>"), "t.png")}, headers={"X-CSRF-Token": self.tok(c)}, content_type="multipart/form-data"); self.assertEqual(r.status_code, 400)
        r = c.post("/staff/builder/resource", data={"file": (io.BytesIO(PDF), "notes.pdf")}, headers={"X-CSRF-Token": self.tok(c)}, content_type="multipart/form-data"); self.assertTrue(r.get_json()["ok"])

class SaveCourseTests(BuilderBase):
    def test_one_session_create_everything(self):
        o = self.client("owner"); _, f = self.upload_video(o); vf = f.get_json()
        rf = o.post("/staff/builder/resource", data={"file": (io.BytesIO(PDF), "notes.pdf")}, headers={"X-CSRF-Token": self.tok(o)}, content_type="multipart/form-data").get_json()
        th = o.post("/staff/builder/thumbnail", data={"file": (io.BytesIO(png_bytes()), "t.png")}, headers={"X-CSRF-Token": self.tok(o)}, content_type="multipart/form-data").get_json()
        p = self.payload(action="publish", thumbnail=th["file"], subscription_eligible=True, certificate_enabled=True, modules=[
            {"id": None, "title": "Week 1", "lessons": [{"title": "Intro video", "kind": "video", "video_file": vf["file"], "video_name": vf["name"], "resource_file": rf["file"], "resource_name": rf["name"], "free_preview": True, "duration_min": "12"},
                                                      {"title": "Notes", "kind": "text", "body": "Read this"}]},
            {"id": None, "title": "Week 2", "lessons": [{"title": "YouTube lesson", "kind": "video", "video_url": "https://youtu.be/dQw4w9WgXcQ"}]}],
            quiz={"title": "Check", "pass_mark": 60, "questions": [{"prompt": "2+2?", "options": "3\n4\n5", "correct": 2, "explanation": "four"}]})
        j = jpost(o, self, "/staff/builder/save", p).get_json(); self.assertTrue(j["ok"], j); cid = j["id"]
        c = dbm.q1("SELECT * FROM courses WHERE id=?", (cid,)); self.assertEqual((c["status"], c["price_kobo"], c["slug"], c["thumbnail"]), ("published", 500000, "algebra-basics", None))          # Basic courses carry no image; the category does
        self.assertEqual(self.val("SELECT COUNT(*) FROM modules WHERE course_id=?", (cid,)), 2); self.assertEqual(self.val("SELECT COUNT(*) FROM lessons WHERE course_id=?", (cid,)), 3)
        l = dbm.q1("SELECT * FROM lessons WHERE title='Intro video'"); self.assertEqual((l["video_file"], l["resource_name"], l["free_preview"], l["duration_min"]), (vf["file"], "notes.pdf", 1, 12))
        self.assertEqual(self.val("SELECT COUNT(*) FROM questions WHERE course_id=?", (cid,)), 1); self.assertEqual(self.val("SELECT COUNT(*) FROM quizzes WHERE course_id=?", (cid,)), 1)
        self.assertEqual(self.app.test_client().get("/courses/algebra-basics").status_code, 200)
        self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='course.builder_save'"), 1)
        page = self.client("owner").get(f"/staff/builder/{cid}").data.decode(); self.assertIn("Intro video", page); self.assertIn(vf["file"], page)     # reloads for editing

    def test_validation_messages_and_atomicity(self):
        mods_before = self.val("SELECT COUNT(*) FROM modules"); o = self.client("owner"); bad = self.payload(title="", division="x", modules=[{"title": "", "lessons": [{"title": "", "kind": "video"}, {"title": "T", "kind": "embed"}]}])
        j = jpost(o, self, "/staff/builder/save", bad).get_json(); self.assertFalse(j["ok"]); self.assertGreaterEqual(len(j["errors"]), 5); self.assertEqual(self.val("SELECT COUNT(*) FROM courses WHERE title='Algebra Basics'"), 0)
        self.assertEqual(self.val("SELECT COUNT(*) FROM modules"), mods_before)
        j = jpost(o, self, "/staff/builder/save", self.payload(action="publish", modules=[{"title": "M", "lessons": []}])).get_json(); self.assertIn("at least one lesson", " ".join(j["errors"]))
        j = jpost(o, self, "/staff/builder/save", self.payload(modules=[{"title": "M", "lessons": [{"title": "v", "kind": "video", "video_url": "http://insecure.com/x.mp4"}]}])).get_json(); self.assertFalse(j["ok"])

    def test_cannot_attach_someone_elses_or_made_up_files(self):
        i = self.client("inst"); _, f = self.upload_video(i); vf = f.get_json()["file"]; o = self.client("owner")
        mk = lambda fname: self.payload(modules=[{"title": "M", "lessons": [{"title": "v", "kind": "video", "video_file": fname}]}])
        self.assertFalse(jpost(o, self, "/staff/builder/save", mk(vf)).get_json()["ok"])                       # owned by instructor, not by owner
        self.assertFalse(jpost(i, self, "/staff/builder/save", mk("../../etc/passwd")).get_json()["ok"])
        self.assertFalse(jpost(i, self, "/staff/builder/save", mk("a" * 32 + ".mp4")).get_json()["ok"])
        self.assertTrue(jpost(i, self, "/staff/builder/save", mk(vf)).get_json()["ok"])

    def test_instructor_limits(self):
        i = self.client("inst"); j = jpost(i, self, "/staff/builder/save", self.payload(price="1", featured=True, instructor_id=self.users["owner"], action="publish")).get_json(); self.assertTrue(j["ok"], j)
        c = dbm.q1("SELECT * FROM courses WHERE id=?", (j["id"],)); self.assertEqual((c["status"], c["price_kobo"], c["featured"], c["instructor_id"]), ("review", 0, 0, self.users["inst"]))   # submit-for-review; cannot self-publish/price/feature
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND title LIKE 'Course ready%'", (self.users["owner"],)), 1)
        self.assertEqual(self.app.test_client().get("/courses/algebra-basics").status_code, 404)
        j2 = jpost(self.client("owner"), self, "/staff/builder/save", self.payload(id=j["id"], action="publish", price="2500", instructor_id=self.users["inst"])).get_json(); self.assertEqual(j2["status"], "published")
        c = dbm.q1("SELECT * FROM courses WHERE id=?", (j["id"],)); self.assertEqual((c["price_kobo"], c["instructor_id"]), (250000, self.users["inst"]))
        j3 = jpost(i, self, "/staff/builder/save", self.payload(id=j["id"], title="Renamed", price="1")).get_json(); c = dbm.q1("SELECT * FROM courses WHERE id=?", (j["id"],))
        self.assertEqual((c["status"], c["price_kobo"], c["title"]), ("published", 250000, "Renamed"))             # editing a live course neither unpublishes nor changes price

    def test_edit_reorder_remove_and_file_cleanup(self):
        o = self.client("owner"); _, f = self.upload_video(o); vf = f.get_json()
        j = jpost(o, self, "/staff/builder/save", self.payload(modules=[{"title": "A", "lessons": [{"title": "L1", "kind": "video", "video_file": vf["file"], "video_name": "v.mp4"}, {"title": "L2", "kind": "text", "body": "x"}]}, {"title": "B", "lessons": [{"title": "L3", "kind": "text", "body": "y"}]}])).get_json()
        cid = j["id"]; data = B.load_course(cid); ma, mb = data["modules"]; l1, l2 = ma["lessons"]; l3 = mb["lessons"][0]
        path = os.path.join(self.app.config["PRIVATE_DIR"], vf["file"]); self.assertTrue(os.path.exists(path))
        data["modules"] = [dict(id=mb["id"], title="B renamed", lessons=[l3]), dict(id=ma["id"], title="A", lessons=[l2])]    # swap modules, drop L1 (with its video)
        data["action"] = "draft"; data["quiz"] = None; data["price"] = "5000"
        r = jpost(o, self, "/staff/builder/save", data).get_json(); self.assertTrue(r["ok"], r)
        self.assertEqual([m["title"] for m in B.load_course(cid)["modules"]], ["B renamed", "A"]); self.assertEqual(self.val("SELECT COUNT(*) FROM lessons WHERE course_id=?", (cid,)), 2)
        self.assertFalse(os.path.exists(path)); self.assertEqual(self.val("SELECT COUNT(*) FROM uploads WHERE stored_name=?", (vf["file"],)), 0)         # video file deleted from disk
        self.assertEqual(self.val("SELECT id FROM lessons WHERE title='L2' AND course_id=?", (cid,)), l2["id"])                                                                 # ids preserved => learner progress kept
        data2 = B.load_course(cid); data2["modules"][0]["lessons"][0]["id"] = dbm.ex("INSERT INTO lessons(course_id,title,kind,position) VALUES (?,?,?,1)", (self.paid, "foreign", "text"))
        data2["action"] = "draft"; data2["price"] = "5000"; self.assertFalse(jpost(o, self, "/staff/builder/save", data2).get_json()["ok"])                 # cannot hijack another course's lesson

    def test_progress_survives_edit(self):
        o = self.client("owner"); j = jpost(o, self, "/staff/builder/save", self.payload(action="publish")).get_json(); cid = j["id"]; l = B.load_course(cid)["modules"][0]["lessons"][0]
        dbm.ex("INSERT INTO progress(user_id,lesson_id,course_id,completed_at) VALUES (?,?,?,?)", (self.users["alice"], l["id"], cid, "2026-01-01 00:00:00"))
        d = B.load_course(cid); d["title"] = "Algebra v2"; d["action"] = "publish"; d["price"] = "5000"; self.assertTrue(jpost(o, self, "/staff/builder/save", d).get_json()["ok"])
        self.assertEqual(self.val("SELECT COUNT(*) FROM progress WHERE lesson_id=?", (l["id"],)), 1)

    def test_quiz_edit_and_delete(self):
        o = self.client("owner"); q = {"title": "Q", "pass_mark": 50, "questions": [{"prompt": "a?", "options": "x\ny", "correct": 1}]}
        j = jpost(o, self, "/staff/builder/save", self.payload(quiz=q)).get_json(); cid = j["id"]; zid = self.val("SELECT id FROM quizzes WHERE course_id=?", (cid,))
        bad = dict(q, questions=[{"prompt": "a?", "options": "only", "correct": 1}]); self.assertFalse(jpost(o, self, "/staff/builder/save", self.payload(id=cid, quiz=dict(bad, id=zid))).get_json()["ok"])
        d = B.load_course(cid); d["quiz"]["questions"].append({"prompt": "b?", "options": "p\nq", "correct": 2, "explanation": ""}); d["price"] = "5000"; d["action"] = "draft"
        self.assertTrue(jpost(o, self, "/staff/builder/save", d).get_json()["ok"]); self.assertEqual(self.val("SELECT COUNT(*) FROM questions WHERE quiz_id=?", (zid,)), 2)
        d = B.load_course(cid); d["quiz"] = {"id": zid, "delete": True}; d["price"] = "5000"; d["action"] = "draft"; jpost(o, self, "/staff/builder/save", d); self.assertEqual(self.val("SELECT COUNT(*) FROM quizzes WHERE course_id=?", (cid,)), 0)

class VideoStreamingTests(BuilderBase):
    def make(self, price=500000, preview=False):
        i = self.client("owner"); _, f = self.upload_video(i, data=mp4(5000)); vf = f.get_json()
        j = jpost(self.client("owner"), self, "/staff/builder/save", self.payload(action="publish", price=str(price / 100), instructor_id=self.users["inst"], modules=[{"title": "M", "lessons": [{"title": "V", "kind": "video", "video_file": vf["file"], "video_name": "v.mp4", "free_preview": preview}]}])) .get_json()
        self.assertTrue(j["ok"], j); return j["id"], self.val("SELECT id FROM lessons WHERE course_id=?", (j["id"],)), vf["file"]
    def test_video_requires_access_and_supports_range(self):
        cid, lid, _ = self.make()
        self.assertEqual(self.app.test_client().get(f"/learn/video/{lid}").status_code, 302); self.assertEqual(self.client("bob").get(f"/learn/video/{lid}").status_code, 403)
        dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at) VALUES (?,?,?,?,?)", (self.users["alice"], "course", cid, "academic", "2026-01-01 00:00:00"))
        a = self.client("alice"); r = a.get(f"/learn/video/{lid}"); self.assertEqual((r.status_code, r.mimetype), (200, "video/mp4")); self.assertEqual(len(r.data), len(mp4(5000)))
        self.assertEqual(r.headers.get("Accept-Ranges"), "bytes"); self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")
        r = a.get(f"/learn/video/{lid}", headers={"Range": "bytes=100-199"}); self.assertEqual(r.status_code, 206); self.assertEqual(r.data, mp4(5000)[100:200])      # seeking works
        slug = dbm.q1("SELECT slug FROM courses WHERE id=?", (cid,))["slug"]; page = a.get(f"/learn/{slug}/lesson/{lid}").data.decode(); self.assertIn(f"/learn/video/{lid}", page); self.assertIn("<video", page)
        self.assertEqual(self.client("inst").get(f"/learn/video/{lid}").status_code, 200)
    def test_free_preview_video_and_expired_access(self):
        cid, lid, _ = self.make(preview=True); self.assertEqual(self.client("bob").get(f"/learn/video/{lid}").status_code, 200)
        dbm.ex("UPDATE lessons SET free_preview=0"); dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at,expires_at) VALUES (?,?,?,?,?,?)", (self.users["alice"], "course", cid, "academic", "2020-01-01 00:00:00", "2020-02-01 00:00:00"))
        self.assertEqual(self.client("alice").get(f"/learn/video/{lid}").status_code, 403); dbm.ex("UPDATE courses SET status='draft'"); self.assertEqual(self.client("bob").get(f"/learn/video/{lid}").status_code, 403)
    def test_deleting_lesson_via_crud_removes_file(self):
        cid, lid, fn = self.make(); path = os.path.join(self.app.config["PRIVATE_DIR"], fn); self.assertTrue(os.path.exists(path))
        self.post(self.client("owner"), f"/staff/r/lessons/{lid}/delete"); self.assertFalse(os.path.exists(path))

class CatalogTests(BuilderBase):
    def seed(self):
        o = self.client("owner")
        for t, d, pr in (("Maths A", "academic", "5000"), ("Design B", "income", "10000"), ("Free C", "academic", "0")): jpost(o, self, "/staff/builder/save", self.payload(title=t, division=d, price=pr, action="publish"))
        jpost(self.client("inst"), self, "/staff/builder/save", self.payload(title="Inst Draft", price="1"))
    def test_catalog_lists_filters_and_stats(self):
        self.seed(); o = self.client("owner"); h = o.get("/staff/catalog").data.decode()
        for t in ("Maths A", "Design B", "Free C", "Inst Draft"): self.assertIn(t, h)
        self.assertIn("Design B", o.get("/staff/catalog?division=income").data.decode()); self.assertNotIn("Maths A", o.get("/staff/catalog?division=income").data.decode())
        self.assertIn("Inst Draft", o.get("/staff/catalog?status=draft").data.decode()); self.assertNotIn("Maths A", o.get("/staff/catalog?status=draft").data.decode())
        self.assertIn("Maths A", o.get("/staff/catalog?q=maths").data.decode()); self.assertNotIn("Design B", o.get("/staff/catalog?q=maths").data.decode())
        self.assertEqual(o.get("/staff/catalog?sort=price&page=1").status_code, 200)
    def test_instructor_sees_only_own(self):
        self.seed(); h = self.client("inst").get("/staff/catalog").data.decode(); self.assertIn("Inst Draft", h); self.assertNotIn("Maths A", h)
        self.assertNotIn("earned", h)                                                                    # no revenue for instructors
    def test_catalog_csv_and_status_toggle(self):
        self.seed(); o = self.client("owner"); r = o.get("/staff/catalog/export.csv"); self.assertEqual(r.status_code, 200); self.assertIn(b"Maths A", r.data); self.assertIn(b"Confirmed revenue", r.data)
        r = self.client("inst").get("/staff/catalog/export.csv"); self.assertIn(b"Inst Draft", r.data); self.assertNotIn(b"Maths A", r.data); self.assertNotIn(b"Confirmed revenue", r.data)
        cid = self.val("SELECT id FROM courses WHERE title='Maths A'"); self.post(o, f"/staff/catalog/{cid}/status", {"status": "draft"}); self.assertEqual(self.val("SELECT status FROM courses WHERE id=?", (cid,)), "draft")
        self.post(o, f"/staff/catalog/{cid}/status", {"status": "published"}); self.assertEqual(self.val("SELECT status FROM courses WHERE id=?", (cid,)), "published")
        self.assertEqual(self.post(self.client("inst"), f"/staff/catalog/{cid}/status", {"status": "archived"}).status_code, 403); self.assertEqual(self.val("SELECT status FROM courses WHERE id=?", (cid,)), "published")
        empty = dbm.ex("INSERT INTO courses(division,title,slug,status) VALUES ('academic','NoLessons','nl','draft')"); self.post(o, f"/staff/catalog/{empty}/status", {"status": "published"}); self.assertEqual(self.val("SELECT status FROM courses WHERE id=?", (empty,)), "draft")
        self.assertEqual(self.post(o, f"/staff/catalog/{cid}/status", {"status": "bogus"}).status_code, 400)
    def test_csv_formula_safe(self):
        jpost(self.client("owner"), self, "/staff/builder/save", self.payload(title="=HYPERLINK(1)", action="publish")); self.assertIn(b"'=HYPERLINK", self.client("owner").get("/staff/catalog/export.csv").data)
    def test_catalog_shows_video_stats(self):
        i = self.client("owner"); _, f = self.upload_video(i); vf = f.get_json(); jpost(self.client("owner"), self, "/staff/builder/save", self.payload(action="publish", modules=[{"title": "M", "lessons": [{"title": "V", "kind": "video", "video_file": vf["file"], "video_name": "v.mp4"}]}]))
        dbm.ex("UPDATE lessons SET video_size=?", (len(mp4()),)); h = self.client("owner").get("/staff/catalog").data.decode(); self.assertIn("Uploaded videos", h); self.assertIn("1 videos", h)

class CoverImageTests(BuilderBase):
    """Regression: 'Thumbnail is invalid; upload it again.' appeared when the server saved the cover as .jpg/.png (no WebP encoder)."""
    def upload_cover(self, c, data=None, name="t.png"):
        return c.post("/staff/builder/thumbnail", data={"file": (io.BytesIO(data or png_bytes()), name)}, headers={"X-CSRF-Token": self.tok(c)}, content_type="multipart/form-data").get_json()
    def test_cover_saves_when_server_has_no_webp_support(self):
        from PIL import Image
        real = Image.Image.save
        def nowebp(self_, fp, fmt=None, **k):
            if fmt == "WEBP": raise OSError("encoder webp not available")
            return real(self_, fp, fmt, **k)
        Image.Image.save = nowebp
        try: o = self.client("owner"); r = self.upload_cover(o); r2 = self.upload_cover(o, data=jpeg_bytes(), name="p.jpg")
        finally: Image.Image.save = real
        self.assertTrue(r["file"].endswith(".png") or r["file"].endswith(".jpg")); self.assertTrue(r2["file"].endswith(".jpg"))
        for cover in (r["file"], r2["file"]):
            j = jpost(o, self, "/staff/builder/save", self.payload(title="Cover " + cover[:6], thumbnail=cover, division="income", action="publish")).get_json(); self.assertTrue(j["ok"], j)
            slug = self.val("SELECT slug FROM courses WHERE id=?", (j["id"],)); self.assertEqual(self.val("SELECT thumbnail FROM courses WHERE id=?", (j["id"],)), cover)
            self.assertEqual(self.app.test_client().get(f"/media/{cover}").status_code, 200); self.assertIn(f"/media/{cover}", self.app.test_client().get("/courses").data.decode())
    def test_normal_webp_cover_still_works(self):
        o = self.client("owner"); r = self.upload_cover(o); self.assertTrue(r["file"].endswith(".webp"))
        j = jpost(o, self, "/staff/builder/save", self.payload(thumbnail=r["file"], division="income")).get_json(); self.assertTrue(j["ok"], j)
    def test_existing_cover_never_blocks_saving_even_if_its_file_is_missing(self):
        o = self.client("owner"); r = self.upload_cover(o); j = jpost(o, self, "/staff/builder/save", self.payload(thumbnail=r["file"], division="income")).get_json(); cid = j["id"]
        os.remove(os.path.join(self.app.config["PUBLIC_DIR"], r["file"]))                                             # e.g. a restored backup without the images folder
        d = B.load_course(cid); d["title"] = "Edited title"; d["price"] = "5000"; j2 = jpost(o, self, "/staff/builder/save", d).get_json(); self.assertTrue(j2["ok"], j2)
        self.assertEqual(self.val("SELECT title FROM courses WHERE id=?", (cid,)), "Edited title")
        legacy = dbm.ex("INSERT INTO courses(division,academic_level,title,slug,status,thumbnail) VALUES ('academic','basic','Legacy','legacy-x','draft','whatever-old-name.jpeg')")      # odd legacy value: still editable
        d = B.load_course(legacy); d["title"] = "Legacy edited"; self.assertTrue(jpost(o, self, "/staff/builder/save", dict(d, price="0")).get_json()["ok"])
    def test_new_covers_are_still_checked(self):
        o = self.client("owner"); good = self.upload_cover(o)["file"]
        for bad in ("../../etc/passwd", "../x.jpg", "abc.jpg", "A" * 24 + ".jpg", "0" * 24 + ".svg", "0" * 24 + ".php", "0" * 24 + ".jpg", "/etc/passwd", "0" * 24 + ".webp.exe"):
            j = jpost(o, self, "/staff/builder/save", self.payload(thumbnail=bad, division="income")).get_json(); self.assertFalse(j["ok"], bad); self.assertIn("cover image did not upload correctly", " ".join(j["errors"]), bad)
        self.assertEqual(self.val("SELECT COUNT(*) FROM courses WHERE title='Algebra Basics'"), 0)
        self.assertTrue(jpost(o, self, "/staff/builder/save", self.payload(thumbnail=good, division="income")).get_json()["ok"])
    def test_cover_can_be_replaced_and_removed(self):
        o = self.client("owner"); a = self.upload_cover(o)["file"]; cid = jpost(o, self, "/staff/builder/save", self.payload(thumbnail=a, division="income")).get_json()["id"]
        b = self.upload_cover(o, data=jpeg_bytes(), name="n.jpg")["file"]; d = B.load_course(cid); d.update(thumbnail=b, price="5000"); self.assertTrue(jpost(o, self, "/staff/builder/save", d).get_json()["ok"]); self.assertEqual(self.val("SELECT thumbnail FROM courses WHERE id=?", (cid,)), b)
        d = B.load_course(cid); d.update(thumbnail="", price="5000"); self.assertTrue(jpost(o, self, "/staff/builder/save", d).get_json()["ok"]); self.assertIsNone(self.val("SELECT thumbnail FROM courses WHERE id=?", (cid,)))
