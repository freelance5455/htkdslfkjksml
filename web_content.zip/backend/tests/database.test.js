import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { setupTestEnv } from './helpers/setup-test-env.js';

setupTestEnv();
const { runMigrations } = await import('../src/database/migrate.js');
const { taskRepository } = await import('../src/database/repositories/task-repository.js');
const { researchRepository } = await import('../src/database/repositories/research-repository.js');
const { resourceRepository } = await import('../src/database/repositories/resource-repository.js');

before(() => {
  runMigrations();
});

test('taskRepository: cria, atualiza status e persiste resultado', () => {
  const task = taskRepository.create({ type: 'test.type', payload: { foo: 'bar' } });
  assert.equal(task.status, 'queued');
  assert.deepEqual(task.payload, { foo: 'bar' });

  const updated = taskRepository.updateStatus(task.id, 'completed', { result: { ok: true } });
  assert.equal(updated.status, 'completed');
  assert.deepEqual(updated.result, { ok: true });
});

test('taskRepository: countByStatus reflete o estado real das tarefas', () => {
  const before = taskRepository.countByStatus();
  const t1 = taskRepository.create({ type: 'x', payload: {} });
  const t2 = taskRepository.create({ type: 'x', payload: {} });
  taskRepository.updateStatus(t1.id, 'failed', { error: 'erro simulado' });

  const after = taskRepository.countByStatus();
  assert.equal(after.failed, before.failed + 1);
  assert.equal(after.queued, before.queued + 1); // t2 continua queued
});

test('taskRepository: findByParentRequest agrupa tarefas de uma mesma solicitacao', () => {
  const requestId = 'req-abc';
  taskRepository.create({ type: 'a', payload: {}, parentRequestId: requestId });
  taskRepository.create({ type: 'b', payload: {}, parentRequestId: requestId });
  taskRepository.create({ type: 'c', payload: {}, parentRequestId: 'outro-request' });

  const grouped = taskRepository.findByParentRequest(requestId);
  assert.equal(grouped.length, 2);
});

test('researchRepository: cria query, adiciona resultados e lista corretamente', () => {
  const query = researchRepository.createQuery({ query: 'madeira de eucalipto', category: 'texture' });
  assert.equal(query.status, 'queued');
  assert.equal(query.results.length, 0);

  researchRepository.addResult(query.id, {
    sourceUrl: 'https://exemplo.com/a',
    title: 'Fonte A',
    snippet: 'resumo A',
    extractedText: 'texto completo A',
  });
  researchRepository.addResult(query.id, {
    sourceUrl: 'https://exemplo.com/b',
    title: 'Fonte B',
  });

  const found = researchRepository.findQueryById(query.id);
  assert.equal(found.results.length, 2);
  assert.equal(found.results[0].source_url, 'https://exemplo.com/a');

  const completed = researchRepository.updateQueryStatus(query.id, 'completed');
  assert.equal(completed.status, 'completed');
});

test('resourceRepository: valida tipo invalido e campos obrigatorios', () => {
  assert.throws(
    () => resourceRepository.create({ type: 'invalido', category: 'x', name: 'y' }),
    /Tipo de recurso invalido/
  );
  assert.throws(
    () => resourceRepository.create({ type: 'texture', category: '', name: '' }),
    /obrigatorios/
  );
});

test('resourceRepository: cria, busca por filtros e atualiza tags', () => {
  const resource = resourceRepository.create({
    type: 'texture', category: 'wood', name: 'Eucalipto', tags: ['madeira', 'marrom'],
  });
  assert.ok(resource.id);
  assert.deepEqual(resource.tags, ['madeira', 'marrom']);

  const byTag = resourceRepository.search({ tag: 'marrom' });
  assert.equal(byTag.total, 1);

  const byTypeAbsent = resourceRepository.search({ type: 'model' });
  assert.equal(byTypeAbsent.total, 0);

  const updated = resourceRepository.update(resource.id, { tags: ['madeira', 'vermelho'] });
  assert.deepEqual(updated.tags, ['madeira', 'vermelho']);

  const deleted = resourceRepository.delete(resource.id);
  assert.equal(deleted, true);
  assert.equal(resourceRepository.findById(resource.id), null);
});

test('resourceRepository: countByType soma corretamente por tipo', () => {
  resourceRepository.create({ type: 'sound', category: 'impact', name: 'som 1' });
  resourceRepository.create({ type: 'sound', category: 'impact', name: 'som 2' });
  const counts = resourceRepository.countByType();
  assert.equal(counts.sound, 2);
});
