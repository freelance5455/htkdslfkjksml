from .base import *

class FileTests(Base):
    def test_public_image_upload_reencoded_and_served(self):
        o = self.client("owner")
        r = o.post("/staff/r/articles/new", data={"_csrf": self.tok(o), "title": "Img", "body": "b", "status": "draft", "featured_image": (io.BytesIO(png_bytes()), "p.png")}, content_type="multipart/form-data"); self.assertEqual(r.status_code, 302)
        name = self.val("SELECT featured_image FROM articles"); self.assertTrue(name.endswith(".webp"))
        resp = self.app.test_client().get(f"/media/{name}"); self.assertEqual(resp.status_code, 200); self.assertEqual(resp.mimetype, "image/webp")
        self.assertEqual(self.app.test_client().get("/media/../t.db").status_code, 404)
        r = o.post("/staff/r/articles/new", data={"_csrf": self.tok(o), "title": "Bad", "body": "b", "status": "draft", "featured_image": (io.BytesIO(b"<svg onload=1>"), "x.png")}, content_type="multipart/form-data"); self.assertEqual(r.status_code, 200)

    def test_lesson_resource_download_requires_access(self):
        i = self.client("inst")
        r = i.post("/staff/r/lessons/new", data={"_csrf": self.tok(i), "course_id": str(self.paid), "title": "Notes", "kind": "pdf", "downloadable": "1", "resource_file": (io.BytesIO(PDF), "notes.pdf")}, content_type="multipart/form-data"); self.assertEqual(r.status_code, 302)
        lid = self.val("SELECT id FROM lessons WHERE title='Notes'"); self.assertEqual(self.client("bob").get(f"/learn/resource/{lid}").status_code, 403)
        dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at) VALUES (?,?,?,?,?)", (self.users["alice"], "course", self.paid, "academic", "2026-01-01 00:00:00"))
        self.assertEqual(self.client("alice").get(f"/learn/resource/{lid}").status_code, 200); self.assertEqual(self.client("inst").get(f"/learn/resource/{lid}").status_code, 200)
        dbm.ex("UPDATE lessons SET downloadable=0 WHERE id=?", (lid,)); self.assertEqual(self.client("alice").get(f"/learn/resource/{lid}").status_code, 403)

    def test_csv_formula_injection_neutralised(self):
        dbm.ex("UPDATE users SET full_name='=HYPERLINK(\"http://evil\")' WHERE email='alice@t.test'"); self.buy(self.client("alice"), "course", "paid-maths")
        data = self.client("owner").get("/staff/payments/export.csv").data.decode(); self.assertNotIn(',=HYPERLINK', data); self.assertIn("'=HYPERLINK", data)

    def test_unicode_csrf_token_does_not_crash(self):
        c = self.client(); self.assertEqual(c.post("/login", data={"_csrf": "é✓", "email": "a", "password": "b"}).status_code, 400)

    def test_user_suspension_blocks_existing_session(self):
        c = self.client("alice"); self.assertEqual(c.get("/student").status_code, 200)
        dbm.ex("UPDATE users SET is_active=0 WHERE email='alice@t.test'"); self.assertEqual(c.get("/student").status_code, 302)

    def test_migrations_idempotent(self):
        self.assertEqual(dbm.migrate(self.app.config["DATABASE"], MIG), [])

class MotionTests(Base):
    def test_animation_assets_wired_and_csp_safe(self):
        c = self.app.test_client(); h = c.get("/")
        body = h.data.decode()
        self.assertIn("js/boot.js", body); self.assertIn("js/anim.js", body)
        self.assertNotIn("<script>", body.replace('<script type="application/ld+json">', ""))     # no inline scripts (CSP: script-src 'self')
        self.assertNotIn(' style="', body)                                                       # no inline styles (CSP: style-src 'self')
        for f in ("css/app.css", "js/boot.js", "js/anim.js"): self.assertEqual(c.get("/static/" + f).status_code, 200)
        css = c.get("/static/css/app.css").data.decode(); self.assertIn("prefers-reduced-motion", css); self.assertIn(".reveal", css)

class HomepageMotionTests(Base):
    def test_homepage_motion_markup_uses_real_data_only(self):
        dbm.ex("UPDATE courses SET status='draft'")
        c = self.app.test_client(); h = c.get("/").data.decode()
        self.assertIn("marquee", h); self.assertIn("Mathematics", h)                      # ticker from real categories (fallback to seeded ones when no courses exist)
        self.assertNotIn('class="numbers"', h)                                            # no stats band while there are no published courses
        self.assertIn("data-hx", h); self.assertNotIn("data-words", h)                      # the hero is now the database-driven carousel (see test_hero.py); the old rotating-word line is gone
        dbm.ex("UPDATE courses SET status='published' WHERE id IN (?,?,?)", (self.paid, self.inc, self.free)); dbm.ex("INSERT INTO lessons(course_id,title,kind,position) VALUES (?,?,?,9)", (self.free, "extra", "text"))
        h = c.get("/").data.decode(); self.assertIn('class="numbers"', h); self.assertRegex(h, r'data-count="3"')       # 3 published courses in the fixture (draft excluded)
        self.assertNotIn(" style=", h); self.assertNotIn("<script>", h.replace('<script type="application/ld+json">', ""))
        self.assertIn("steps", h); self.assertIn("tilt", h)
    def test_motion_assets_and_reduced_motion_rules(self):
        c = self.app.test_client(); js = c.get("/static/js/anim.js").data.decode(); css = c.get("/static/css/app.css").data.decode()
        self.assertIn("rotor", js); self.assertIn(".marquee", css); self.assertIn("prefers-reduced-motion", css)
        self.assertLess(js.index("if(rm)return"), js.index("rotor"))                       # all hero motion sits after the reduced-motion bail-out

class CarouselAndArticleCardTests(Base):
    def test_testimonial_carousel_and_article_images_on_homepage(self):
        from dagba.services import settings as S
        a = self.app.test_client(); self.assertNotIn("tcar", a.get("/").data.decode())                                  # nothing to show => no empty section
        dbm.ex("INSERT INTO testimonials(name,detail,quote,verified,status) VALUES ('Ada <b>X</b>','SS3','Great <script>alert(1)</script> course',1,'published')")
        dbm.ex("INSERT INTO testimonials(name,quote,verified,status) VALUES ('Draft','hidden',1,'draft')")
        h = a.get("/").data.decode(); self.assertIn('class="tcar"', h); self.assertIn("ttrack", h); self.assertIn("Verified", h); self.assertIn("Ada &lt;b&gt;X&lt;/b&gt;", h); self.assertNotIn("<script>alert(1)", h); self.assertNotIn("hidden", h.split("tcar")[1].split("</section>")[0])
        S.put("home.show_testimonials", "0"); self.assertNotIn("tcar", a.get("/").data.decode()); S.put("home.show_testimonials", "1")
        cat = dbm.ex("INSERT INTO article_categories(name,slug) VALUES ('Study Hacks','study-hacks')")
        dbm.ex("INSERT INTO articles(title,slug,excerpt,body,featured_image,status,category_id) VALUES ('With pic','with-pic','ex','b','abc123abc123abc123abc123.webp','published',?)", (cat,))
        dbm.ex("INSERT INTO articles(title,slug,excerpt,body,status) VALUES ('No pic','no-pic','ex','b','published')")
        for url in ("/", "/blog"):
            h = a.get(url).data.decode(); self.assertIn('class="card acard', h); self.assertIn("/media/abc123abc123abc123abc123.webp", h); self.assertIn('loading="lazy"', h); self.assertIn("Study Hacks", h); self.assertIn("aph", h); self.assertIn("Read more", h)
            self.assertNotIn(" style=", h)
    def test_carousel_script_and_css_contract(self):
        c = self.app.test_client(); js = c.get("/static/js/anim.js").data.decode(); css = c.get("/static/css/app.css").data.decode()
        self.assertIn("tcar", js); self.assertIn("scroll-snap-type", css); self.assertIn("prefers-reduced-motion", css)
        self.assertLess(js.index("var car=document.querySelector('.tcar')"), js.index("if(rm)return")); self.assertIn("if(!rm&&cards.length>1)", js)       # carousel works for everyone; auto-play only without reduced motion
