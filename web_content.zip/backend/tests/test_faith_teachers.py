"""Faith teachers & per-division tutor rates (merged from the 'faith-tutors' update onto the standalone Faith system)."""
from .base import *
from .test_builder import jpost
from .test_faith import FaithBase, TutorTests, mp3
from dagba.services import payouts as P, settings as S, faith as F

class TeacherTests(TutorTests):
    def pub(self, series=None):
        i, slug = self.mkitem(series_id=series or self.mine, access="public"); return slug
    def test_teacher_pages_are_public_with_only_name_and_bio(self):
        dbm.ex("UPDATE users SET bio='Pastor and teacher of prayer.' WHERE id=?", (self.iid,))
        anon = self.app.test_client(); self.assertEqual(anon.get(f"/faith/teacher/{self.iid}").status_code, 404)          # no live series yet
        self.pub(); t = anon.get(f"/faith/teacher/{self.iid}"); self.assertEqual(t.status_code, 200); h = t.data.decode()
        self.assertIn("Pastor and teacher of prayer.", h); self.assertIn("Mine", h); self.assertNotIn("inst@t.test", h); self.assertNotIn("Theirs", h)
        idx = anon.get("/faith").data.decode(); self.assertIn("Meet our teachers", idx); self.assertIn(f"/faith/teacher/{self.iid}", idx)
        s = anon.get("/faith/series/mine").data.decode(); self.assertIn("About your teacher", s); self.assertIn(f"/faith/teacher/{self.iid}", s)
        self.assertEqual(anon.get("/faith/teacher/999999").status_code, 404); self.assertEqual(anon.get(f"/faith/teacher/{self.users['alice']}").status_code, 404)
    def test_unpublished_or_inactive_teacher_not_listed(self):
        self.pub(); dbm.ex("UPDATE faith_series SET status='draft' WHERE id=?", (self.mine,)); self.assertEqual(self.app.test_client().get(f"/faith/teacher/{self.iid}").status_code, 404)
        dbm.ex("UPDATE faith_series SET status='published' WHERE id=?", (self.mine,)); dbm.ex("UPDATE users SET is_active=0 WHERE id=?", (self.iid,))
        self.assertEqual(self.app.test_client().get(f"/faith/teacher/{self.iid}").status_code, 404); self.assertNotIn("Meet our teachers", self.app.test_client().get("/faith").data.decode())
    def test_admin_overview_has_teachers_panel_and_add_link(self):
        h = self.owner.get("/staff/faith/").data.decode(); self.assertIn("+ Add a teacher", h); self.assertIn("Current Faith teacher share: 40%", h); self.assertIn("Inst", h)
        self.assertIn("1</span> series with no teacher", h)
        self.assertIn("selected", self.owner.get("/staff/users/new?role=instructor").data.decode().split("<option")[2])
        self.assertEqual(self.client("faither").get("/staff/faith/").status_code, 200)

class DivisionRateTests(TutorTests):
    def test_default_rate_and_per_division_rate_for_faith(self):
        self.assertEqual(P.rates(), {"academic": 40.0, "income": 40.0, "professional": 40.0, "faith": 40.0})
        S.put("payout.instructor_percent_faith", "25"); self.assertEqual((P.percent("faith"), P.percent("academic"), P.percent()), (25.0, 40.0, 40.0))
        self.buy("mine"); e = self.row("SELECT * FROM instructor_earnings"); self.assertEqual((e["percent"], e["amount_kobo"]), (25.0, 125000))     # NGN 5,000 x 25%
        S.put("payout.instructor_percent_faith", "0"); self.assertEqual(P.percent("faith"), 0.0)
        S.put("payout.instructor_percent_faith", ""); self.assertEqual(P.percent("faith"), 40.0)
    def test_rate_change_only_affects_future_sales(self):
        S.put("payout.instructor_percent_faith", "25"); self.buy("mine"); S.put("payout.instructor_percent_faith", "10")
        self.assertEqual(self.val("SELECT percent FROM instructor_earnings WHERE instructor_id=?", (self.iid,)), 25.0)
    def test_by_division_counts_faith_series_and_nets_refunds(self):
        t = self.buy("mine"); d = P.by_division(self.iid); self.assertEqual((d["faith"]["sales"], d["faith"]["earned"], d["faith"]["gross"]), (1, 200000, 500000)); self.assertEqual(d["academic"]["sales"], 0)
        self.assertEqual(P.by_division()["faith"]["earned"], 200000)
    def test_settings_page_validates_division_rates(self):
        o = self.owner; self.assertIn("Faith &amp; Spiritual Growth courses: tutor share", o.get("/staff/settings/payouts").data.decode())
        for bad in ("abc", "101", "-1"): self.post(o, "/staff/settings/payouts", {"payout.instructor_percent_faith": bad}); self.assertEqual(S.get("payout.instructor_percent_faith", ""), "", bad)
        self.post(o, "/staff/settings/payouts", {"payout.instructor_percent": "40", "payout.instructor_percent_faith": "30"}); self.assertEqual(S.get("payout.instructor_percent_faith"), "30")
    def test_earnings_pages_show_division_and_csv_columns(self):
        S.put("payout.instructor_percent_faith", "30"); self.buy("mine")
        h = self.inst.get("/staff/earnings").data.decode(); self.assertIn("Faith &amp; Spiritual Growth", h); self.assertIn("30%", h)
        a = self.client("owner").get("/staff/payouts/instructors"); self.assertEqual(a.status_code, 200); self.assertIn("Faith: ", a.data.decode())
        csv = self.client("owner").get("/staff/payouts/instructors/export.csv").data.decode(); self.assertIn("Earned: Faith (NGN)", csv.splitlines()[0])
        self.assertEqual(self.client("owner").get("/staff/payouts").status_code, 200)
    def test_course_sales_use_the_course_division_rate(self):
        S.put("payout.instructor_percent_income", "50"); S.put("payout.instructor_percent_faith", "10")
        self.assertEqual((P.percent("income"), P.percent("faith"), P.percent("academic")), (50.0, 10.0, 40.0))

class AacAudioTests(FaithBase):
    def test_aac_and_opus_audio_upload_and_stream(self):
        aac = b"\xff\xf1" + bytes(range(200)) * 20; r = self.up(self.owner, aac, "talk.aac", "audio"); self.assertTrue(r["ok"], r)
        self.assertTrue(r["file"].endswith(".aac")); ogg = b"OggS" + bytes(range(100)) * 40; r2 = self.up(self.owner, ogg, "talk.opus", "audio"); self.assertTrue(r2["ok"], r2); self.assertTrue(r2["file"].endswith(".ogg"))
        self.assertFalse(self.up(self.owner, b"not audio at all" * 50, "bad.aac", "audio").get("ok"))
