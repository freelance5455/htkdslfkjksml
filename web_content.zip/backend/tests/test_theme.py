import re
from .base import *
from dagba.services import theme as TH, settings as S

CSS_FILE = os.path.join(os.path.dirname(__file__), "..", "dagba", "static", "css", "app.css")

def full(**over):
    d = dict(TH.DEFAULTS); d.update(over); return d

class ThemeBase(Base):
    def setUp(self):
        super().setUp(); self.mk("themer", "admin", perms=["settings.manage"]); self.o = self.client("owner")
    def save(self, c=None, **over):
        return self.post(c or self.o, "/staff/theme", {k: v for k, v in full(**over).items() if v != "0"}, follow_redirects=True)
    def theme_css(self): return self.client().get("/theme.css").data.decode()
    def light_css(self): return re.sub(r"html\[data-mode=dark\]\{[^}]*\}", "", self.theme_css()).strip()      # everything except the dark-mode rule

class DefaultsTests(ThemeBase):
    def test_default_theme_overrides_nothing(self):
        self.assertEqual(self.light_css(), "")                                  # the stylesheet's own defaults are the original look
        self.assertEqual(TH.variables(full()), {})

    def test_stylesheet_defaults_match_the_engine_defaults(self):
        """app.css :root and theme.py must agree, otherwise 'only changed values' would silently drift from the real defaults."""
        root = open(CSS_FILE).read().split("}\n", 1)[0]
        css_vars = dict(re.findall(r"(--[a-z0-9-]+):([^;]+)", root))
        derived = ("--tint-soft", "--tint-faint", "--line-strong", "--line-soft", "--on-dark-soft", "--on-dark-dim", "--on-dark-hi", "--on-dark-hi2", "--on-hero-soft", "--on-hero-hi", "--on-hero-hi2", "--field-text")
        for k, v in TH.variables(full(), only_changed=False).items():
            self.assertIn(k, css_vars, k)
            if k not in derived: self.assertEqual(css_vars[k].strip().lower().replace(" ", ""), v.lower().replace(" ", ""), k)     # derived ones only need to be close; they are recomputed when their parents change
        for k in ("--tint-soft", "--tint-faint"):            # these two are calibrated to match the shipped look exactly
            self.assertEqual(css_vars[k].lower(), TH.variables(full(), only_changed=False)[k], k)

    def test_no_hardcoded_theme_colours_left_in_the_stylesheet(self):
        body = open(CSS_FILE).read().split("}\n", 1)[1]
        for lit in ("#e6e1f7", "#cfc8ea", "#faf9ff", "#f3efff", "#efe9ff", "#1f1b2e", "#6b6880", "#3b1d8f", "#faf8ff", "#e8e2ff", "#cfc6ee", "#c9b8ff", "#e5defd", "114,54,230"):
            self.assertNotIn(lit, body, lit)
        self.assertNotRegex(body, r"border-radius:(8|10|12|14|16)px")
        self.assertNotRegex(open(CSS_FILE).read().split("}\n", 1)[0], r"--[a-z0-9-]+:var\(")      # no self-referencing defaults

    def test_pages_load_app_css_before_theme_css_with_revision(self):
        h = self.client().get("/").data.decode(); self.assertLess(h.index("css/app.css"), h.index("/theme.css?v="))

class SaveAndApplyTests(ThemeBase):
    def test_save_changes_the_whole_site_and_busts_the_cache(self):
        before = self.client().get("/").data.decode(); rev0 = re.search(r"theme\.css\?v=(\d+)", before).group(1)
        r = self.save(**{"brand.primary": "#0369a1", "theme.bg": "#f5faff", "theme.radius": "very", "theme.width": "wide", "theme.font_body": "classic", "theme.font_size": "18"})
        self.assertIn(b"Theme saved", r.data)
        css = self.theme_css(); lcss = self.light_css()
        for frag in ("--brand:#0369a1", "--bg:#f5faff", "--r-lg:22px", "--wrap:1280px", "--fs:18px", "Georgia"): self.assertIn(frag, css)
        self.assertNotIn("--dark:", lcss)                                             # unchanged values are not repeated
        self.assertNotEqual(re.search(r"theme\.css\?v=(\d+)", self.client().get("/").data.decode()).group(1), rev0)
        resp = self.client().get("/theme.css?v=1"); self.assertIn("max-age=31536000", resp.headers["Cache-Control"]); self.assertIn("max-age=300", self.client().get("/theme.css").headers["Cache-Control"])

    def test_certificates_and_meta_follow_the_theme_colours(self):
        self.save(**{"brand.primary": "#0369a1", "brand.dark": "#082f49"})
        self.assertEqual((S.get("brand.primary"), S.get("brand.dark")), ("#0369a1", "#082f49")); self.assertIn(b'content="#082f49"', self.client().get("/").data)

    def test_dashboards_use_the_same_theme(self):
        self.save(**{"brand.primary": "#047857"}); self.assertIn("--brand:#047857", self.light_css())
        for who, url in (("alice", "/student"), ("owner", "/staff/")): self.assertIn(b"theme.css?v=", self.client(who).get(url).data)

    def test_options_become_rules(self):
        self.save(**{"theme.sticky": "0", "theme.hero": "brand", "theme.pill": "1", "theme.motion": "0", "theme.custom_css": ".btn{letter-spacing:1px}"})
        css = self.theme_css()
        self.assertIn("header.site{position:static}", css); self.assertIn(".hero{background:var(--brand)", css); self.assertIn("--r-btn:999px", css)
        self.assertIn("animation:none!important", css); self.assertTrue(css.rstrip().endswith(".btn{letter-spacing:1px}"))
        self.save(**{"theme.hero": "dark"}); self.assertIn(".hero{background:var(--dark)", self.theme_css())

    def test_heading_colour_follows_header_unless_set(self):
        self.save(**{"brand.dark": "#082f49"}); self.assertIn("--heading:#082f49", self.theme_css())
        self.save(**{"brand.dark": "#082f49", "theme.heading_same": "0", "theme.heading": "#112233"}); self.assertIn("--heading:#112233", self.theme_css())

    def test_audit_log_and_no_change_message(self):
        self.save(**{"theme.radius": "square"}); self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='theme.saved'"), 1)
        self.assertIn(b"No changes", self.save(**{"theme.radius": "square"}).data)

    def test_reset_restores_the_original_look(self):
        self.save(**{"brand.primary": "#0369a1", "theme.radius": "square", "theme.custom_css": "a{color:red}"}); self.assertNotEqual(self.light_css(), "")
        r = self.post(self.o, "/staff/theme", {"action": "reset"}, follow_redirects=True); self.assertIn(b"original theme", r.data)
        self.assertEqual(self.light_css(), ""); self.assertEqual(S.get("brand.primary"), "#7236E6")
        self.assertEqual(self.val("SELECT COUNT(*) FROM settings WHERE key LIKE 'theme.%' AND key<>'theme.rev'"), 0)

class ValidationTests(ThemeBase):
    def test_bad_values_are_rejected_and_nothing_is_saved(self):
        for k, bad in (("brand.primary", "red"), ("brand.primary", "#12"), ("theme.bg", "javascript:alert(1)"), ("theme.font_body", "x;}body{display:none"), ("theme.font_size", "400"),
                       ("theme.radius", "huge"), ("theme.width", "1px"), ("theme.hero", "x"), ("theme.custom_css", "a{color:red")):
            r = self.save(**{"theme.radius": "square", k: bad}); self.assertNotIn(b"Theme saved", r.data, (k, bad))
            self.assertEqual(self.light_css(), "", (k, bad)); self.assertEqual(S.get("theme.radius", "default"), "default", (k, bad))

    def test_custom_css_size_limit(self):
        self.assertNotIn(b"Theme saved", self.save(**{"theme.custom_css": "a{b:c}" * 4000}).data)

    def test_colours_are_normalised_to_lowercase_hex(self):
        self.save(**{"brand.primary": "#0369A1"}); self.assertEqual(S.get("brand.primary"), "#0369a1")

    def test_stored_garbage_cannot_break_the_site(self):
        S.put("brand.primary", "}body{display:none"); S.put("theme.font_body", "nope"); S.put("theme.radius", "??")
        css = self.theme_css(); self.assertNotIn("display:none", css); self.assertEqual(self.client().get("/").status_code, 200)

class AccessTests(ThemeBase):
    def test_only_settings_managers_can_use_the_editor(self):
        for who in ("noperm", "officer", "alice", "inst"):
            c = self.client(who)
            for method, url in (("get", "/staff/theme"), ("post", "/staff/theme"), ("post", "/staff/theme/preview")):
                r = self.post(c, url, {}) if method == "post" else c.get(url); self.assertEqual(r.status_code, 403, (who, url))
        self.assertEqual(self.client().get("/staff/theme").status_code, 302)
        self.assertEqual(self.client("themer").get("/staff/theme").status_code, 200); self.assertEqual(self.o.get("/staff/theme").status_code, 200)
        self.assertEqual(self.light_css(), "")

    def test_csrf_enforced_and_link_in_menu(self):
        self.assertEqual(self.o.post("/staff/theme", data={"theme.radius": "square"}).status_code, 400)
        self.assertEqual(self.o.post("/staff/theme/preview", data={}).status_code, 400)
        self.assertIn(b'href="/staff/theme"', self.o.get("/staff/").data)

    def test_editor_renders_and_branding_page_still_works(self):
        h = self.o.get("/staff/theme").data.decode()
        for frag in ("Midnight (dark mode)", "Ocean blue", 'id="tp"', "js/theme.js", "Restore the original theme"): self.assertIn(frag, h)
        r = self.o.get("/staff/settings/brand"); self.assertEqual(r.status_code, 200); self.assertNotIn(b"brand.primary", r.data); self.assertIn(b"Theme", r.data)

class PreviewTests(ThemeBase):
    def test_preview_returns_variables_and_saves_nothing(self):
        r = self.post(self.o, "/staff/theme/preview", {"brand.primary": "#0369a1", "theme.radius": "square", "theme.hero": "dark"}); d = r.get_json()
        self.assertEqual(d["vars"]["--brand"], "#0369a1"); self.assertEqual(d["vars"]["--r-lg"], "0px"); self.assertEqual(d["hero"], "dark"); self.assertIn("--on-dark", d["vars"])
        self.assertEqual(S.get("brand.primary"), "#7236E6"); self.assertEqual(self.light_css(), "")

    def test_preview_survives_bad_input_and_flags_unreadable_palettes(self):
        d = self.post(self.o, "/staff/theme/preview", {"brand.primary": "nope", "theme.text": "#fafafa", "theme.bg": "#ffffff"}).get_json()
        self.assertEqual(d["vars"]["--brand"], "#7236E6"); self.assertTrue(d["errors"]); self.assertTrue(any("Body text" in w for w in d["warnings"]))

class ColourMathTests(unittest.TestCase):
    def test_text_colour_flips_with_background(self):
        self.assertEqual(TH.on_colour("#1b1230"), "#ffffff"); self.assertEqual(TH.on_colour("#ffffff"), TH.INK); self.assertEqual(TH.on_colour("#fde047"), TH.INK); self.assertEqual(TH.on_colour("#7236E6"), "#ffffff")

    def test_every_background_gets_readable_text(self):
        import itertools
        for r, g, b in itertools.product(range(0, 256, 51), repeat=3):
            bg = "#%02x%02x%02x" % (r, g, b); self.assertGreaterEqual(TH.contrast(TH.on_colour(bg), bg), 4.5, bg)

    def test_light_header_gets_dark_text(self):
        v = TH.variables(full(**{"brand.dark": "#f1f5f9"})); self.assertEqual(v["--on-dark"], TH.INK)
        v = TH.variables(full(**{"brand.primary": "#fde047"})); self.assertEqual(v["--on-brand"], TH.INK)

    def test_light_banner_gets_dark_text(self):
        v = TH.variables(full(**{"brand.dark": "#e0f2fe", "theme.hero_mid": "#bae6fd", "brand.primary": "#7dd3fc"})); self.assertEqual(v["--on-hero"], TH.INK)

    def test_derived_tints_follow_the_surface(self):
        v = TH.variables(full(**{"theme.surface": "#1a1530", "theme.tint": "#2a2150"}))
        self.assertEqual(TH.mix("#2a2150", "#1a1530", .27), v["--tint-soft"]); self.assertLess(TH.lum(v["--tint-soft"]), .1)

class PresetTests(ThemeBase):
    def test_every_preset_is_valid_and_readable(self):
        for name, p in TH.PRESETS.items():
            v = full(**p); vals, errs = TH.from_form(v); self.assertEqual(errs, [], name); self.assertEqual(TH.warnings(vals), [], name)
            for k in p: self.assertIn(k, TH.DEFAULTS, (name, k))
            vs = TH.variables(vals, only_changed=False); self.assertGreaterEqual(TH.contrast(vs["--on-dark"], vs["--dark"]), 7, name); self.assertGreaterEqual(TH.contrast(vs["--on-brand"], vs["--brand"]), 4.5, name)

    def test_original_preset_changes_nothing(self):
        self.assertEqual(TH.variables(full(**TH.PRESETS["Dagba purple (original)"])), {})

    def test_every_preset_can_be_saved_through_the_form(self):
        for name, p in TH.PRESETS.items():
            self.assertIn(b"Theme saved" if name != "Dagba purple (original)" or self.light_css() else b"", self.save(**p).data, name)
        self.assertEqual(self.client().get("/").status_code, 200)

    def test_dark_preset_makes_cards_and_fields_dark(self):
        self.save(**TH.PRESETS["Midnight (dark mode)"]); css = self.theme_css()
        for frag in ("--bg:#0f0b1e", "--surface:#1a1530", "--text:#e8e4f5", "--field-text:#e8e4f5", "--heading:#ffffff"): self.assertIn(frag, css)

class FeatureInteractionTests(ThemeBase):
    def test_affiliate_and_other_pages_still_render_with_a_custom_theme(self):
        self.save(**TH.PRESETS["Midnight (dark mode)"], **{"theme.radius": "square"})
        for who, url in ((None, "/"), (None, "/courses"), (None, "/pricing"), (None, "/login"), ("alice", "/student"), ("owner", "/staff/affiliates"), ("owner", "/staff/users")):
            c = self.client(who) if who else self.client(); self.assertEqual(c.get(url).status_code, 200, url)


class DarkModeTests(ThemeBase):
    def test_button_is_on_every_page_by_default_with_accessible_label(self):
        for who, url in ((None, "/"), (None, "/courses"), (None, "/login"), ("alice", "/student"), ("owner", "/staff/")):
            h = (self.client(who) if who else self.client()).get(url).data.decode()
            self.assertIn('id="modebtn"', h, url); self.assertIn('aria-label="Switch to dark mode"', h, url); self.assertIn("js/mode.js", h, url)
            self.assertLess(h.index("js/mode.js"), h.index("<body"), url)                 # runs before the page paints: no flash of the wrong mode
        self.assertIn('name="dda-mode-default" content="light"', self.client().get("/").data.decode())

    def test_dark_rule_is_always_served_and_light_look_is_untouched(self):
        css = self.theme_css(); self.assertIn("html[data-mode=dark]{", css); self.assertIn("color-scheme:dark", css); self.assertEqual(self.light_css(), "")

    def test_dark_palette_follows_the_primary_colour(self):
        self.save(**{"brand.primary": "#047857"}); dark = re.search(r"html\[data-mode=dark\]\{([^}]*)\}", self.theme_css()).group(1)
        d = dict(p.split(":", 1) for p in dark.split(";") if ":" in p)
        self.assertGreaterEqual(TH.contrast(d["--brand"], d["--surface"]), 4.5); self.assertLess(TH.lum(d["--bg"]), .02); self.assertGreater(TH.lum(d["--text"]), .8)

    def test_dark_palette_is_readable_for_every_preset_and_odd_colours(self):
        import itertools
        samples = [full(**p) for p in TH.PRESETS.values()] + [full(**{"brand.primary": c, "brand.accent": a}) for c, a in itertools.product(("#000000", "#ffffff", "#ff0000", "#00ff00", "#0000ff", "#fde047", "#6666ff"), ("#000000", "#ffffff", "#2563eb"))]
        for v in samples:
            vals, errs = TH.from_form(v); self.assertEqual(errs, [])
            dv = TH.dark_values(vals); self.assertEqual(TH.warnings(dv), [], (vals["brand.primary"], vals["brand.accent"]))
            self.assertGreaterEqual(TH.contrast(dv["theme.text"], dv["theme.bg"]), 10); self.assertGreaterEqual(TH.contrast(dv["theme.muted"], dv["theme.surface"]), 4.5)
            self.assertGreaterEqual(TH.contrast(dv["brand.accent"], dv["theme.bg"]), 3.0)
            vs = TH.variables(dv, only_changed=False); self.assertGreaterEqual(TH.contrast(vs["--on-brand"], vs["--brand"]), 4.5); self.assertGreaterEqual(TH.contrast(vs["--on-dark"], vs["--dark"]), 7)

    def test_admin_can_hide_the_button(self):
        self.save(**{"theme.mode_button": "0"}); h = self.client().get("/").data.decode()
        self.assertNotIn('id="modebtn"', h); self.assertIn('name="dda-mode-default" content="off"', h)       # 'off' also tells the script to ignore any saved dark choice

    def test_first_visit_default_can_follow_the_device(self):
        self.save(**{"theme.mode_default": "auto"}); self.assertIn('name="dda-mode-default" content="auto"', self.client().get("/").data.decode())
        self.assertNotIn(b"Theme saved", self.save(**{"theme.mode_default": "sometimes"}).data); self.assertEqual(S.get("theme.mode_default"), "auto")

    def test_button_hides_itself_when_the_site_theme_is_already_dark(self):
        self.save(**TH.PRESETS["Midnight (dark mode)"]); self.assertNotIn('id="modebtn"', self.client().get("/").data.decode())
        self.save(**TH.PRESETS["Ocean blue"]); self.assertIn('id="modebtn"', self.client().get("/").data.decode())

    def test_reset_brings_the_button_back_to_defaults(self):
        self.save(**{"theme.mode_button": "0", "theme.mode_default": "auto"}); self.post(self.o, "/staff/theme", {"action": "reset"})
        self.assertIn('id="modebtn"', self.client().get("/").data.decode()); self.assertEqual(TH.mode_default(), "light")

    def test_preview_returns_dark_variables_too(self):
        d = self.post(self.o, "/staff/theme/preview", {"brand.primary": "#047857"}).get_json()
        self.assertIn("--bg", d["dark"]); self.assertNotEqual(d["dark"]["--bg"], d["vars"]["--bg"]); self.assertIn(b"data-pmode", self.o.get("/staff/theme").data)

    def test_editor_has_the_mode_settings(self):
        h = self.o.get("/staff/theme").data.decode(); self.assertIn("theme.mode_button", h); self.assertIn("Match the visitor", h)

    def test_script_and_styles_are_shipped(self):
        js = self.client().get("/static/js/mode.js"); self.assertEqual(js.status_code, 200); self.assertIn(b"dda-mode", js.data); self.assertIn(b"localStorage", js.data)
        css = open(CSS_FILE).read(); self.assertIn(".mode-btn", css); self.assertIn("html[data-mode=dark] .badge.green", css)
