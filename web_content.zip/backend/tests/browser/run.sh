#!/bin/bash
# Optional real-browser tests for the Intro Cards carousel and the admin icon picker (Playwright + Chromium; not needed to run the site).
#   usage:  tests/browser/run.sh public|many|admin        (needs: node, `npm i playwright` and `npx playwright install chromium`)
# Boots a throwaway instance on port 5055 with a temporary database, runs the script, stops the server.
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; HERE="$ROOT/tests/browser"; TMP="$(mktemp -d)"; mkdir -p /tmp/dagba-e2e-shots
cd "$ROOT"
export DATABASE_PATH="$TMP/e2e.db" SECRET_KEY=e2e-secret-key-not-used-in-prod PORT=5055
python3 manage.py migrate >/dev/null 2>&1; python3 manage.py seed >/dev/null 2>&1
ADMIN_EMAIL=admin@example.com ADMIN_NAME=Admin ADMIN_PASSWORD='Passw0rd!x9' python3 manage.py create-admin >/dev/null 2>&1
python3 manage.py seed-demo >/dev/null 2>&1
[ -f "$HERE/$1.pre.py" ] && python3 "$HERE/$1.pre.py"
python3 manage.py run >"$TMP/server.log" 2>&1 & SP=$!
for i in $(seq 1 30); do curl -s -o /dev/null http://127.0.0.1:5055/ && break; sleep 0.5; done
timeout 240 node "$HERE/$1.js"; kill $SP 2>/dev/null; rm -rf "$TMP"
