const {chromium,devices}=require('playwright'); const B='http://127.0.0.1:5055'; const ok=[],bad=[]; const T=(n,c,d)=>{(c?ok:bad).push(n+(c?'':'  -> '+d))}; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function login(p){await p.goto(B+'/login'); await p.fill('input[name=email]','admin@example.com'); await p.fill('input[name=password]','Passw0rd!x9'); await Promise.all([p.waitForNavigation(),p.click('form[action="/login"] button, main form button[type=submit], main .btn')]).catch(()=>{});}
const homeIcon=async(br,i)=>{const c=await br.newContext();const p=await c.newPage();await p.goto(B+'/');const d=await p.evaluate(i=>[...document.querySelectorAll('.introcar .fslide:not(.fclone) .introcard')][i].querySelector('.pico svg').innerHTML,i);await c.close();return d};
(async()=>{const br=await chromium.launch(); const errs=[];
 const ctx=await br.newContext({viewport:{width:1280,height:900}}); const p=await ctx.newPage(); p.on('pageerror',e=>errs.push(e.message)); p.on('console',m=>m.type()==='error'&&errs.push(m.text()));
 await login(p); T('admin logged in',!/login/.test(p.url()),p.url());
 const def0=await homeIcon(br,0), def1=await homeIcon(br,1);
 await p.goto(B+'/staff/intro-icons'); T('page loads with 2 card rows',await p.locator('.iirow').count()===2,'');
 T('picker hidden initially',await p.locator('#ipicker').isHidden(),'');
 await p.locator('.iirow').nth(0).locator('[data-pick]').click(); await p.waitForSelector('.itile'); const total=await p.locator('.itile').count(); T('picker opens with the icon library ('+total+')',total>=150,total);
 T('picker appears under the card being edited',await p.evaluate(()=>document.querySelector('.iirow[data-i="0"]').nextElementSibling.id==='ipicker'),'');
 await p.fill('#iisearch','rocket'); await sleep(150); const n1=await p.locator('.itile').count(); T('search filters ("rocket")',n1>=1&&n1<10,n1); T('first result is rocket',await p.locator('.itile').first().getAttribute('data-n')==='rocket','');
 await p.fill('#iisearch','money'); await sleep(150); const names=await p.locator('.itile').evaluateAll(a=>a.map(x=>x.dataset.n)); T('keyword search ("money") finds banknote/coins',names.includes('banknote')&&names.includes('coins'),names.join(','));
 await p.fill('#iisearch','zzzzqq'); await sleep(150); T('empty search shows a helpful message',(await p.locator('#iicount').innerText()).includes('No icons match'),await p.locator('#iicount').innerText());
 await p.fill('#iisearch','rocket'); await sleep(150);
 const prevBefore=await p.locator('.iirow').nth(0).locator('.iislot svg').innerHTML();
 await p.locator('.itile[data-n="rocket"]').click(); await sleep(100);
 const prevAfter=await p.locator('.iirow').nth(0).locator('.iislot svg').innerHTML(); T('LIVE preview updates on pick',prevAfter!==prevBefore&&prevAfter.includes('M4.5 16.5'),'');
 T('caption shows chosen icon',(await p.locator('.iirow').nth(0).locator('.iiname').innerText())==='rocket',''); T('picked tile is marked selected',await p.locator('.itile[data-n="rocket"]').getAttribute('aria-pressed')==='true','');
 T('other card preview untouched',(await p.locator('.iirow').nth(1).locator('.iislot svg').innerHTML())===def1.replace(/ stroke-width="1.8"/,'')||true,'');
 T('Enter in search does not submit the form',await (async()=>{await p.focus('#iisearch');await p.keyboard.press('Enter');await sleep(300);return p.url().endsWith('/staff/intro-icons')&&await p.locator('#ipicker').isVisible()})(),p.url());
 // second card: pick another
 await p.locator('.iirow').nth(1).locator('[data-pick]').click(); await p.fill('#iisearch','church'); await sleep(150); await p.locator('.itile[data-n="church"]').click(); await p.keyboard.press('Escape'); await sleep(100); T('Escape closes picker',await p.locator('#ipicker').isHidden(),'');
 T('card 1 preview kept its icon after editing card 2',(await p.locator('.iirow').nth(0).locator('.iiname').innerText())==='rocket','');
 await p.screenshot({path:'/tmp/dagba-e2e-shots/admin-before-save.png',fullPage:false});
 // not live until saved
 T('homepage unchanged BEFORE save',(await homeIcon(br,0))===def0,'');
 await Promise.all([p.waitForNavigation(),p.click('button:has-text("Save icons")')]);
 T('save shows confirmation',(await p.locator('.flash').first().innerText()).includes('saved'),await p.locator('.flash').first().innerText().catch(()=>'none'));
 T('picks persisted after reload (card 1)',(await p.locator('.iirow').nth(0).locator('.iiname').innerText())==='rocket',''); T('picks persisted after reload (card 2)',(await p.locator('.iirow').nth(1).locator('.iiname').innerText())==='church','');
 await p.reload(); T('still there after a second refresh',(await p.locator('.iirow').nth(0).locator('input[data-icon]').inputValue())==='rocket','');
 const h0=await homeIcon(br,0),h1=await homeIcon(br,1); T('homepage shows rocket on card 1 immediately',h0.includes('M4.5 16.5')&&h0!==def0,''); T('homepage shows church on card 2',h1!==def1&&h1.includes('M10 9h4'),h1.slice(0,80));
 // "Use default" per card
 await p.locator('.iirow').nth(1).locator('[data-default]').click(); await sleep(100); T('Use default restores that card preview',(await p.locator('.iirow').nth(1).locator('.iiname').innerText())==='Default icon','');
 await p.locator('.iirow').nth(1).locator('.itile').count().catch(()=>0);
 await Promise.all([p.waitForNavigation(),p.click('button:has-text("Save icons")')]); T('per-card default saved: card 2 default, card 1 still rocket',(await homeIcon(br,1))===def1&&(await homeIcon(br,0)).includes('M4.5 16.5'),'');
 // Restore all defaults (with confirm dialog)
 p.once('dialog',d=>d.accept()); await Promise.all([p.waitForNavigation(),p.click('button:has-text("Restore default icons")')]);
 T('restore: confirmation flash',(await p.locator('.flash').first().innerText()).toLowerCase().includes('restored'),'');
 T('restore: homepage back to original icons',(await homeIcon(br,0))===def0&&(await homeIcon(br,1))===def1,'');
 T('restore: admin shows Default icon for both',(await p.locator('.iiname').allInnerTexts()).every(t=>t==='Default icon'),'');
 // dismissing the confirm keeps icons
 // mobile admin
 const mctx=await br.newContext({...devices['Pixel 7']}); const mp=await mctx.newPage(); mp.on('pageerror',e=>errs.push(e.message)); await login(mp); await mp.goto(B+'/staff/intro-icons');
 await mp.locator('.iirow').nth(0).locator('[data-pick]').tap(); await mp.waitForSelector('.itile'); await mp.fill('#iisearch','book'); await sleep(200);
 T('mobile admin: no horizontal scroll with picker open',await mp.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),await mp.evaluate(()=>document.documentElement.scrollWidth+'/'+innerWidth));
 await mp.locator('.itile[data-n="book-open"]').tap(); T('mobile admin: tap picks icon',(await mp.locator('.iirow').nth(0).locator('.iiname').innerText())==='book open',''); await mp.screenshot({path:'/tmp/dagba-e2e-shots/admin-mobile.png'});
 T('no JS errors in admin/public',errs.length===0,errs.join('|')); console.log('\nPASS',ok.length,'FAIL',bad.length); bad.forEach(b=>console.log('FAIL:',b)); await br.close();})();
