import os, sys; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
from dagba import create_app
from dagba.services import settings as S
app=create_app()
with app.app_context():
    S.put("c.home.what_cards", "\n".join([
     "Academic learning | Secondary school subjects (Basic), university-level courses (Advanced) and professional development programmes, organised by subject. | /academic | Explore academic courses",
     "Income skills | Practical, job-ready skills such as digital marketing, design, web development, freelancing and personal finance. | /income-skills | Explore income skills",
     "Professional Development | Preparation for professional examinations, certifications and career advancement with pathways. | /professional | Explore programmes | rocket",
     "Faith and growth | Bible studies, practical Christian living, prayer and spiritual growth alongside your learning journey today. | /faith | Explore faith | church",
     "Supercalifragilisticexpialidocious_unbroken_title_to_test_overflow_handling_on_small_screens | Averyveryveryverylongunbrokenwordtotestoverflowhandlingonsmallscreensaveryveryveryverylongunbrokenwordtotestoverflow | /pricing | See pricing | gem"]))
