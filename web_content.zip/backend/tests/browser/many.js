const {chromium,devices}=require('playwright'); const B='http://127.0.0.1:5055'; const ok=[],bad=[]; const T=(n,c,d)=>{(c?ok:bad).push(n+(c?'':'  -> '+d))}; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const info=p=>p.evaluate(()=>{const r=document.querySelector('.introcar');const t=r.querySelector('.ftrack');const tb=t.getBoundingClientRect();
 const real=[...t.querySelectorAll('.fslide:not(.fclone)')];const vis=[...t.querySelectorAll('.fslide')].filter(s=>{const b=s.getBoundingClientRect();return b.left>=tb.left-2&&b.right<=tb.right+2&&b.width>0});
 const cards=[...t.querySelectorAll('.introcard')];const over=cards.filter(c=>c.scrollWidth>c.clientWidth+1).length;
 return {n:real.length,visible:vis.length,on:[...r.querySelectorAll('.tdots button')].findIndex(d=>d.classList.contains('on')),dots:r.querySelectorAll('.tdots button').length,ctrlHidden:r.querySelector('.tctrl').hidden,btn:getComputedStyle(r.querySelector('.tbtn')).display!=='none',over,ox:document.documentElement.scrollWidth-innerWidth}});
(async()=>{const br=await chromium.launch(); const errs=[];
 for(const [name,vp,exp,mobile] of [['desktop 1280',{width:1280,height:800},3,false],['laptop 1024',{width:1024,height:768},3,false],['tablet 768',{width:768,height:1024},2,false],['phone 360',{width:360,height:740},1,true]]){
  const ctx=await br.newContext({viewport:vp,hasTouch:mobile,isMobile:mobile}); const p=await ctx.newPage(); p.on('pageerror',e=>errs.push(e.message)); p.on('console',m=>m.type()==='error'&&errs.push(m.text()));
  await p.goto(B+'/'); await p.locator('.introcar').scrollIntoViewIfNeeded(); await sleep(900); let g=await info(p); console.log(name,JSON.stringify(g));
  T(name+': '+exp+' cards visible',g.visible===exp,JSON.stringify(g)); T(name+': dots = cards ('+g.n+')',g.dots===g.n&&g.n===5,JSON.stringify(g)); T(name+': no horizontal scroll',g.ox<=0,g.ox); T(name+': long words wrap (no card overflow)',g.over===0,g.over);
  T(name+': controls shown (looping)',!g.ctrlHidden,''); T(name+': arrows '+(mobile?'hidden on touch widths':'visible'),mobile?!g.btn:g.btn,'');
  const on0=g.on; await sleep(4900); g=await info(p); T(name+': auto-slides within 5s',g.on!==on0,`${on0}->${g.on}`);
  if(!mobile){ const o=g.on; await p.locator('.introcar .tbtn[data-dir="1"]').click(); await sleep(800); g=await info(p); T(name+': next arrow works',g.on===(o+1)%5,`${o}->${g.on}`);
    await p.locator('.introcar .tbtn[data-dir="-1"]').click(); await sleep(800); g=await info(p); T(name+': previous arrow works',g.on===o,`->${g.on}`);
    // loop around: click next 5 times returns to start
    for(let i=0;i<5;i++){await p.locator('.introcar .tbtn[data-dir="1"]').click();await sleep(650)} g=await info(p); T(name+': loops seamlessly',g.on===o,`->${g.on}`);
    // pause on hover
    await p.locator('.introcar').hover(); const h0=(await info(p)).on; await sleep(5200); T(name+': auto-slide pauses while hovering',(await info(p)).on===h0,'');
    // keyboard
    await p.locator('.introcar .ftrack').focus(); const k0=(await info(p)).on; await p.keyboard.press('ArrowRight'); await sleep(800); T(name+': keyboard arrow works',(await info(p)).on!==k0,'');
    await p.mouse.move(5,5); }
  await p.screenshot({path:`/tmp/dagba-e2e-shots/many-${name.replace(' ','-')}.png`,clip:await p.locator('.introcar').boundingBox().then(b=>({x:0,y:Math.max(0,b.y-100),width:vp.width,height:Math.min(b.height+140,vp.height)}))});
  await ctx.close();}
 T('no JS errors',errs.length===0,errs.join('|')); console.log('\nPASS',ok.length,'FAIL',bad.length); bad.forEach(b=>console.log('FAIL:',b)); await br.close();})();
