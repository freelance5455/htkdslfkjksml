const {chromium,devices}=require('playwright');
const B='http://127.0.0.1:5055'; const ok=[],bad=[]; const T=(n,c,d)=>{(c?ok:bad).push(n+(c?'':'  -> '+d)); };
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function intro(page){ // geometry of the intro carousel
  return page.evaluate(()=>{const r=document.querySelector('.introcar');const t=r.querySelector('.ftrack');const tb=t.getBoundingClientRect();
    const slides=[...t.querySelectorAll('.fslide:not(.fclone)')];
    const vis=slides.filter(s=>{const b=s.getBoundingClientRect();return b.left>=tb.left-2&&b.right<=tb.right+2&&b.width>0});
    const dots=[...r.querySelectorAll('.tdots button')];const on=dots.findIndex(d=>d.classList.contains('on'));
    const ctrlHidden=r.querySelector('.tctrl').hidden; const btn=r.querySelector('.tbtn');
    return {n:slides.length,visible:vis.length,dots:dots.length,on,ctrlHidden,btnShown:getComputedStyle(btn).display!=='none',trackW:tb.width,slideW:slides[0].getBoundingClientRect().width,
      overflowX:document.documentElement.scrollWidth-window.innerWidth, seen:r.classList.contains('seen'), delay:r.getAttribute('data-delay')}});
}
async function setCards(page,n){}
(async()=>{
  const br=await chromium.launch(); const errs=[];
  const watch=p=>{p.on('pageerror',e=>errs.push('pageerror '+e.message));p.on('console',m=>{if(m.type()==='error')errs.push('console '+m.text())})};
  // ---------- phone
  let ctx=await br.newContext({...devices['iPhone 13']}); let page=await ctx.newPage(); watch(page);
  await page.goto(B+'/'); await page.locator('.introcar').scrollIntoViewIfNeeded(); await sleep(900);
  let g=await intro(page); console.log('phone',JSON.stringify(g));
  T('phone: carousel built, delay 4500',g.delay==='4500'&&g.n>=2,JSON.stringify(g));
  T('phone: ONE card visible at a time',g.visible===1&&Math.abs(g.slideW-g.trackW)<14,JSON.stringify(g));
  T('phone: pagination dots = cards',g.dots===g.n,JSON.stringify(g));
  T('phone: no horizontal scroll',g.overflowX<=0,g.overflowX);
  T('phone: arrows hidden on touch widths',!g.btnShown,'');
  T('phone: entrance animation ran',g.seen,'');
  const first=g.on; await sleep(5200); g=await intro(page);
  T('phone: auto-slides within ~5s',g.on!==first,`on ${first} -> ${g.on}`);
  // swipe with real touch gesture via CDP
  const cdp=await ctx.newCDPSession(page); const box=await page.locator('.introcar .ftrack').boundingBox(); const sx=Math.round(box.x+box.width/2),sy=Math.round(box.y+box.height/2);
  async function swipe(dx){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:sx,y:sy}]});for(let i=1;i<=12;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:sx+dx*i/12,y:sy}]});await sleep(16)}await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]})}
  const before=(await intro(page)).on; await swipe(-200);
  await sleep(900); g=await intro(page); T('phone: swipe left goes to next card',g.on!==before,`on ${before} -> ${g.on}`); const b2=g.on; await swipe(200); await sleep(900); g=await intro(page); T('phone: swipe right goes back',g.on!==b2,`on ${b2} -> ${g.on}`);
  await page.screenshot({path:'/tmp/dagba-e2e-shots/phone-intro.png',clip:await page.locator('.introcar').boundingBox().then(b=>({x:0,y:Math.max(0,b.y-90),width:390,height:b.height+130}))});
  // dot click
  await page.locator('.introcar .tdots button').nth(0).click(); await sleep(700); g=await intro(page); T('phone: dot click navigates',g.on===0,JSON.stringify(g));
  await ctx.close();
  // ---------- small android / tablet / desktop overflow + layout
  for(const [name,vp,exp] of [['android 360',{width:360,height:740},1],['tablet 768',{width:768,height:1024},2],['laptop 1280',{width:1280,height:800},3],['wide 1920',{width:1920,height:1000},3]]){
    ctx=await br.newContext({viewport:vp}); page=await ctx.newPage(); watch(page); await page.goto(B+'/'); await page.locator('.introcar').scrollIntoViewIfNeeded(); await sleep(900);
    g=await intro(page); console.log(name,JSON.stringify(g)); T(name+': no horizontal scroll',g.overflowX<=0,g.overflowX);
    T(name+': cards visible = '+Math.min(exp,g.n),g.visible===Math.min(exp,g.n),JSON.stringify(g));
    if(name.startsWith('laptop')){ T('desktop: arrows shown when looping (>3 cards) / hidden when all fit',g.n>3?(!g.ctrlHidden&&g.btnShown):g.ctrlHidden,JSON.stringify(g));
      // hover elevation
      const c=page.locator('.introcar .fslide:not(.fclone) .introcard').first(); const t0=await c.evaluate(e=>getComputedStyle(e).transform); await c.hover(); await sleep(450);
      const t1=await c.evaluate(e=>getComputedStyle(e).transform); const sh=await c.evaluate(e=>getComputedStyle(e).boxShadow); T('desktop: hover lifts card',t1!==t0&&t1!=='none',`${t0} -> ${t1}`); T('desktop: hover shadow',sh!=='none',sh);
      await page.screenshot({path:'/tmp/dagba-e2e-shots/desktop-intro.png',clip:await page.locator('.introcar').boundingBox().then(b=>({x:0,y:Math.max(0,b.y-90),width:1280,height:b.height+130}))}); }
    await ctx.close();
  }
  // ---------- reduced motion
  ctx=await br.newContext({viewport:{width:390,height:800},reducedMotion:'reduce',hasTouch:true,isMobile:true}); page=await ctx.newPage(); watch(page); await page.goto(B+'/'); await page.locator('.introcar').scrollIntoViewIfNeeded(); await sleep(600);
  g=await intro(page); const op=await page.evaluate(()=>getComputedStyle(document.querySelector('.introcar .fslide')).opacity); const tr=await page.evaluate(()=>getComputedStyle(document.querySelector('.introcar .fslide')).transitionDuration);
  T('reduced motion: cards fully visible immediately',op==='1'&&g.seen,op); T('reduced motion: no transition',/^0s(, 0s)*$/.test(tr),tr);
  const o=g.on; await sleep(5600); g=await intro(page); T('reduced motion: no auto-sliding',g.on===o,`on ${o} -> ${g.on}`); await ctx.close();
  T('no JS errors / CSP violations on homepage',errs.length===0,errs.join(' | '));
  console.log('\nPASS',ok.length,'FAIL',bad.length); bad.forEach(b=>console.log('FAIL:',b)); await br.close();
})();
