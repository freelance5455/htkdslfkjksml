import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { randomUUID } from 'node:crypto';

/**
 * Deve ser chamado e aguardado ANTES de qualquer `import(...)` dinamico de
 * modulos de `src/`, para garantir que cada arquivo de teste use seu proprio
 * banco de dados SQLite isolado (evitando interferencia entre testes).
 */
export function setupTestEnv() {
  const testDir = fs.mkdtempSync(path.join(os.tmpdir(), 'adam-knowledge-test-'));
  process.env.DATABASE_PATH = path.join(testDir, 'test.db');
  process.env.RESOURCE_STORAGE_PATH = path.join(testDir, 'resources');
  process.env.ADDONFORGE_TOKEN = `test-token-${randomUUID()}`;
  process.env.PORT = '0'; // porta efemera, atribuida pelo SO
  process.env.HOST = '127.0.0.1';
  process.env.WEB_SEARCH_PROVIDER = '';
  process.env.AI_PROVIDER = '';
  return { testDir, token: process.env.ADDONFORGE_TOKEN };
}
