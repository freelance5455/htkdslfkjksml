import sqlite3, tempfile, shutil
from .base import *
from dagba.services import payouts as PO, payments as P, settings as S, providers

class PayoutBase(Base):
    def setUp(self):
        super().setUp()
        self.mk("payroll", "admin", perms=["payouts.manage"]); self.mk("inst2", "instructor")
        self.other = dbm.ex("INSERT INTO courses(division,title,slug,price_kobo,status,instructor_id) VALUES ('academic','Other Tutor Course','other-tutor',200000,'published',?)", (self.users["inst2"],))
        self.noinst = dbm.ex("INSERT INTO courses(division,title,slug,price_kobo,status) VALUES ('academic','Orphan','orphan',100000,'published')")
    def sale(self, who="alice", slug="paid-maths", promo=""):
        c = self.client(who); ref = self.buy(c, "course", slug, who=who, promo=promo); t = self.tx(ref)
        self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}); return t["id"]
    def earned(self, who="inst"): return self.val("SELECT COALESCE(SUM(amount_kobo),0) FROM instructor_earnings WHERE instructor_id=?", (self.users[who],))
    def bank(self, c, number="0123456789"):
        return self.post(c, "/staff/earnings/account", {"bank": "GTBank", "account_name": "Inst Tutor", "account_number": number})
    def request(self, c, amount):
        return self.post(c, "/staff/earnings/request", {"amount": str(amount)}, follow_redirects=True)
    def pay(self, c, rid, data=None, name="receipt.png", **form):
        d = {"_csrf": self.tok(c), "action": "pay", "confirm": "1", "reference": "TRX-1"}; d.update(form)
        if data is not False: d["receipt"] = (io.BytesIO(png_bytes() if data is None else data), name)
        return c.post(f"/staff/payouts/{rid}", data=d, content_type="multipart/form-data", follow_redirects=True)
    def open_request(self, amount=1000):
        self.sale(); c = self.client("inst"); self.bank(c); self.request(c, amount); return c, self.val("SELECT id FROM payout_requests ORDER BY id DESC LIMIT 1")

class EarningsRuleTests(PayoutBase):
    def test_tutor_gets_40_percent_exactly_once(self):
        tid = self.sale(); e = dbm.q1("SELECT * FROM instructor_earnings"); self.assertEqual((e["instructor_id"], e["gross_kobo"], e["percent"], e["amount_kobo"], e["kind"]), (self.users["inst"], 500000, 40.0, 200000, "sale"))
        for _ in range(3): self.post(self.client("officer"), f"/staff/payments/{tid}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings"), 1)
        dbm.ex("INSERT OR IGNORE INTO instructor_earnings(instructor_id,transaction_id,course_id,kind,gross_kobo,percent,amount_kobo) VALUES (?,?,?,?,?,?,?)", (self.users["inst"], tid, self.paid, "sale", 1, 99, 1)); self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings"), 1)   # DB-level guard
        n = dbm.q1("SELECT * FROM notifications WHERE user_id=? AND kind='earning'", (self.users["inst"],)); self.assertEqual(n["title"], "New purchase of your course"); self.assertIn("Alice", n["body"]); self.assertIn("2,000", n["body"])
    def test_nothing_earned_until_money_is_confirmed(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths"); t = self.tx(ref); self.assertEqual(self.earned(), 0)                  # pending verification
        self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "info", "confirm": "1", "text": "more"}); self.assertEqual(self.earned(), 0)
        self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "reject", "confirm": "1", "text": "no"}); self.assertEqual(self.earned(), 0)
    def test_split_is_on_what_the_student_really_paid(self):
        dbm.ex("INSERT INTO promos(code,percent_off,applies_to) VALUES ('HALF',50,'all')"); self.sale(promo="HALF"); self.assertEqual(self.earned(), 100000)     # 40% of 2,500
        self.assertEqual(PO.share(33333, 40), 13333); self.assertEqual(PO.share(33334, 40), 13334); self.assertEqual(PO.share(1, 40), 0)
    def test_no_share_for_subscriptions_free_promos_or_courses_without_tutor(self):
        c = self.client("alice"); ref = self.buy(c, "plan", self.plan_a); self.post(self.client("officer"), f"/staff/payments/{self.tx(ref)['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}); self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings"), 0)
        dbm.ex("INSERT INTO promos(code,percent_off,applies_to) VALUES ('FREE',100,'courses')"); self.buy(self.client("bob"), "course", "paid-maths", who="bob", submit=False, promo="FREE"); self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings"), 0)
        self.sale("bob", "orphan"); self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings"), 0)
    def test_percent_change_applies_to_future_sales_only(self):
        self.sale(); S.put("payout.instructor_percent", "50"); self.sale("bob")
        self.assertEqual([r["percent"] for r in dbm.q("SELECT percent FROM instructor_earnings ORDER BY id")], [40.0, 50.0]); self.assertEqual(self.earned(), 200000 + 250000)
    def test_each_tutor_is_credited_for_their_own_course(self):
        self.sale(); self.sale("bob", "other-tutor"); self.assertEqual(self.earned("inst"), 200000); self.assertEqual(self.earned("inst2"), 80000)
    def test_refund_reverses_the_share(self):
        tid = self.sale(); self.post(self.client("refunder"), f"/staff/payments/{tid}", {"action": "refund", "confirm": "1", "text": "customer request"})
        self.assertEqual(self.earned(), 0); self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings WHERE kind='reversal'"), 1); self.assertEqual(PO.summary(self.users["inst"])["available"], 0)
        dbm.ex("INSERT OR IGNORE INTO instructor_earnings(instructor_id,transaction_id,kind,gross_kobo,percent,amount_kobo) VALUES (?,?,?,?,?,?)", (self.users["inst"], tid, "reversal", 1, 40, -5)); self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings"), 2)
    def test_refund_after_withdrawal_blocks_further_requests_until_new_earnings(self):
        tid = self.sale(); c = self.client("inst"); self.bank(c); self.request(c, 2000); rid = self.val("SELECT id FROM payout_requests"); self.pay(self.client("payroll"), rid)
        self.post(self.client("refunder"), f"/staff/payments/{tid}", {"action": "refund", "confirm": "1", "text": "x"}); self.assertEqual(PO.summary(self.users["inst"])["available"], -200000)
        self.assertIn("once you have earned money", self.request(c, 1).data.decode()); self.sale("bob", "paid-maths"); self.assertEqual(PO.summary(self.users["inst"])["available"], 0)
    def test_gateway_approval_also_credits(self):
        S.put("pay.paystack.enabled", "1"); S.put("pay.paystack.secret_key", "sk"); c = self.client("alice"); ref = self.buy(c, "course", "paid-maths", submit=False); dbm.ex("UPDATE transactions SET method='paystack' WHERE reference=?", (ref,))
        P.finalize_gateway(ref, "paystack", {"status": "success", "amount_kobo": 500000, "currency": "NGN"}); P.finalize_gateway(ref, "paystack", {"status": "success", "amount_kobo": 500000, "currency": "NGN"}); self.assertEqual(self.earned(), 200000)
    def test_existing_sales_are_backfilled_by_the_migration(self):
        d = tempfile.mkdtemp(); path = os.path.join(d, "old.db"); mig = os.path.join(d, "m"); os.makedirs(mig)
        for f in ("001_init.sql", "002_video_builder.sql"): shutil.copy(os.path.join(MIG, f), mig)
        dbm.migrate(path, mig); c = sqlite3.connect(path)
        c.execute("INSERT INTO users(email,password_hash,full_name,role) VALUES ('t@x','h','T','instructor')"); c.execute("INSERT INTO users(email,password_hash,full_name) VALUES ('s@x','h','S')")
        c.execute("INSERT INTO courses(division,title,slug,price_kobo,status,instructor_id) VALUES ('academic','C','c',500000,'published',1)")
        for i, (st, amt) in enumerate((("approved", 500000), ("approved", 0), ("refunded", 500000), ("pending_verification", 500000))):
            c.execute("INSERT INTO transactions(reference,user_id,item_type,course_id,item_title,list_price_kobo,amount_kobo,status) VALUES (?,2,'course',1,'C',500000,?,?)", (f"R{i}", amt, st))
        c.commit(); c.close(); self.assertIn("003_instructor_payouts.sql", dbm.migrate(path, MIG))
        rows = sqlite3.connect(path).execute("SELECT amount_kobo, percent FROM instructor_earnings").fetchall(); self.assertEqual(rows, [(200000, 40.0)]); shutil.rmtree(d, ignore_errors=True)

class EarningsPageTests(PayoutBase):
    def test_visibility_and_privacy(self):
        self.sale(); self.sale("bob", "other-tutor")
        for who, code in (("inst", 200), ("inst2", 200), ("alice", 403), ("writer", 403), ("officer", 403), ("owner", 403), ("payroll", 403)): self.assertEqual(self.client(who).get("/staff/earnings").status_code, code, who)
        self.assertEqual(self.app.test_client().get("/staff/earnings").status_code, 302)
        h = self.client("inst").get("/staff/earnings").data.decode(); self.assertIn("Paid Maths", h); self.assertIn("2,000", h); self.assertIn("Alice", h); self.assertNotIn("alice@t.test", h); self.assertNotIn("Other Tutor Course", h)
        h2 = self.client("inst2").get("/staff/earnings").data.decode(); self.assertIn("Other Tutor Course", h2); self.assertNotIn("Paid Maths", h2)
    def test_masked_student_names(self):
        self.assertEqual(PO.mask_name("Adaeze Nwosu Okafor"), "Adaeze O."); self.assertEqual(PO.mask_name("Ada"), "Ada"); self.assertEqual(PO.mask_name(""), "A student")
    def test_dashboard_tile_and_empty_state(self):
        h = self.client("inst").get("/staff/earnings").data.decode(); self.assertIn("once you have earned money", h); self.assertIn("No purchases yet", h)
        self.sale(); d = self.client("inst").get("/staff/").data.decode(); self.assertIn("Available to withdraw", d); self.assertIn("2,000", d)
    def test_sale_notification_text_is_editable(self):
        S.put("c.notif.sale_title", "Cha-ching!"); S.put("c.notif.sale_body", "{student} just bought {item}: +{amount}"); self.sale()
        n = dbm.q1("SELECT * FROM notifications WHERE user_id=? AND kind='earning'", (self.users["inst"],)); self.assertEqual((n["title"], n["body"]), ("Cha-ching!", "Alice just bought Paid Maths: +\u20a62,000"))
    def test_tutor_csv_is_private_and_formula_safe(self):
        dbm.ex("UPDATE users SET full_name='=cmd|x' WHERE email='alice@t.test'"); self.sale(); r = self.client("inst").get("/staff/earnings/export.csv"); self.assertEqual(r.status_code, 200); self.assertIn(b"Paid Maths", r.data); self.assertNotIn(b",=cmd", r.data)
        self.assertEqual(self.client("alice").get("/staff/earnings/export.csv").status_code, 403)

class WithdrawalRequestTests(PayoutBase):
    def test_cannot_request_without_earnings(self):
        c = self.client("inst"); self.bank(c); h = self.request(c, 1000).data.decode(); self.assertIn("once you have earned money", h); self.assertEqual(self.val("SELECT COUNT(*) FROM payout_requests"), 0)
    def test_bank_details_required_and_validated(self):
        self.sale(); c = self.client("inst"); self.assertIn("Save your bank account details first", self.request(c, 1000).data.decode())
        for bad in ("123", "12345678901", "abcdefghij", "0123 4567"): self.bank(c, bad); self.assertIsNone(self.val("SELECT payout_account_number FROM users WHERE email='inst@t.test'"), bad)
        self.assertIn("Bank details saved", self.bank(c, "0123 456789").data.decode() if False else self.post(c, "/staff/earnings/account", {"bank": "GTB", "account_name": "T", "account_number": "0123456789"}, follow_redirects=True).data.decode())
    def test_amount_rules(self):
        self.sale(); c = self.client("inst"); self.bank(c)
        for bad, msg in (("abc", "valid amount"), ("0", "Enter the amount"), ("-5", "negative"), ("2000.01", "at most"), ("999999", "at most"), ("", "Enter the amount")): self.assertIn(msg, self.request(c, bad).data.decode(), bad); self.assertEqual(self.val("SELECT COUNT(*) FROM payout_requests"), 0, bad)
        S.put("payout.min_naira", "1500"); self.assertIn("minimum withdrawal is", self.request(c, 1000).data.decode()); self.assertEqual(self.val("SELECT COUNT(*) FROM payout_requests"), 0)
        self.assertIn("Withdrawal requested", self.request(c, 1500).data.decode()); self.assertEqual(self.val("SELECT amount_kobo FROM payout_requests"), 150000)
    def test_request_reserves_money_one_open_request_and_cancel(self):
        self.sale(); c = self.client("inst"); self.bank(c); self.assertIn("Withdrawal requested", self.request(c, 1200).data.decode())
        s = PO.summary(self.users["inst"]); self.assertEqual((s["earned"], s["pending"], s["available"]), (200000, 120000, 80000))
        self.assertIn("already have a withdrawal request", self.request(c, 100).data.decode()); self.assertEqual(self.val("SELECT COUNT(*) FROM payout_requests"), 1)
        rid = self.val("SELECT id FROM payout_requests"); self.assertEqual(self.post(self.client("inst2"), f"/staff/earnings/{rid}/cancel").status_code, 302); self.assertEqual(self.val("SELECT status FROM payout_requests"), "requested")   # another tutor cannot cancel it
        self.post(c, f"/staff/earnings/{rid}/cancel"); self.assertEqual(self.val("SELECT status FROM payout_requests"), "cancelled"); self.assertEqual(PO.summary(self.users["inst"])["available"], 200000)
        self.assertIn("Withdrawal requested", self.request(c, 2000).data.decode())
    def test_double_submit_cannot_overdraw(self):
        self.sale(); c = self.client("inst"); self.bank(c); self.request(c, 2000)
        with self.assertRaises(PO.PayoutError): PO.request(dbm.q1("SELECT * FROM users WHERE id=?", (self.users["inst"],)), "2000")
        self.assertEqual(self.val("SELECT COUNT(*) FROM payout_requests"), 1); self.assertEqual(PO.summary(self.users["inst"])["available"], 0)
    def test_switch_off_and_roles(self):
        self.sale(); c = self.client("inst"); self.bank(c); S.put("payout.enabled", "0"); self.assertIn("switched off", self.request(c, 100).data.decode()); self.assertEqual(self.val("SELECT COUNT(*) FROM payout_requests"), 0)
        for who in ("alice", "writer", "officer"): self.assertEqual(self.post(self.client(who), "/staff/earnings/request", {"amount": "10"}).status_code, 403)
    def test_admin_is_notified_with_link(self):
        c, rid = self.open_request(); self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND kind='payout'", (self.users["payroll"],)), 1); self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND kind='payout'", (self.users["owner"],)), 1)
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND kind='payout'", (self.users["officer"],)), 0); self.assertEqual(self.val("SELECT link FROM notifications WHERE user_id=? AND kind='payout'", (self.users["payroll"],)), f"/staff/payouts/{rid}")
        h = self.client("payroll").get("/staff/").data.decode(); self.assertIn('class="dot">1<', h)                                                                                        # pending counter in the menu

class AdminPayoutTests(PayoutBase):
    def test_pay_requires_receipt_then_completes(self):
        c, rid = self.open_request(1500); a = self.client("payroll")
        self.pay(a, rid, data=False); self.assertEqual(self.val("SELECT status FROM payout_requests"), "requested")                                               # no receipt => not completed
        for data, name in ((b"<?php echo 1;?>", "r.php"), (b"<?php echo 1;?>", "r.png"), (b"MZ\x90", "r.exe"), (b"", "r.png"), (png_bytes(), "r.pdf")): self.pay(a, rid, data=data, name=name); self.assertEqual(self.val("SELECT status FROM payout_requests"), "requested", name)
        a.post(f"/staff/payouts/{rid}", data={"_csrf": self.tok(a), "action": "pay", "receipt": (io.BytesIO(png_bytes()), "r.png")}, content_type="multipart/form-data"); self.assertEqual(self.val("SELECT status FROM payout_requests"), "requested")    # needs the confirmation tick
        self.assertIn("Marked as paid", self.pay(a, rid).data.decode()); r = dbm.q1("SELECT * FROM payout_requests"); self.assertEqual((r["status"], r["decided_by"], r["transfer_reference"], r["receipt_mime"]), ("paid", self.users["payroll"], "TRX-1", "image/png")); self.assertRegex(r["receipt_file"], r"^[0-9a-f]{32}\.png$")
        s = PO.summary(self.users["inst"]); self.assertEqual((s["paid"], s["pending"], s["available"]), (150000, 0, 50000))
        n = dbm.q1("SELECT * FROM notifications WHERE user_id=? AND title='Withdrawal paid'", (self.users["inst"],)); self.assertIn("1,500", n["body"]); self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='payout.paid'"), 1)
        self.assertIn("already been processed", self.pay(a, rid).data.decode()); self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='payout.paid'"), 1)       # cannot pay twice
        self.assertEqual(self.client().get("/static/" + r["receipt_file"]).status_code, 404)
        h = c.get("/staff/earnings").data.decode(); self.assertIn("View receipt", h); self.assertIn("TRX-1", h)
    def test_receipt_access_control(self):
        c, rid = self.open_request(); self.pay(self.client("payroll"), rid); url = f"/staff/payouts/receipt/{rid}"
        for who in ("inst", "payroll", "owner"): self.assertEqual(self.client(who).get(url).status_code, 200, who)
        for who in ("inst2", "alice", "writer", "officer", "noperm"): self.assertEqual(self.client(who).get(url).status_code, 403, who)
        r = self.client("inst").get(url); self.assertIn("sandbox", r.headers["Content-Security-Policy"]); self.assertEqual(self.app.test_client().get(url).status_code, 302)
    def test_reject_needs_reason_and_releases_money(self):
        c, rid = self.open_request(2000); a = self.client("payroll"); self.post(a, f"/staff/payouts/{rid}", {"action": "reject", "confirm": "1", "reason": ""}); self.assertEqual(self.val("SELECT status FROM payout_requests"), "requested")
        self.post(a, f"/staff/payouts/{rid}", {"action": "reject", "confirm": "1", "reason": "Account name does not match"}); self.assertEqual(self.val("SELECT status FROM payout_requests"), "rejected")
        self.assertEqual(PO.summary(self.users["inst"])["available"], 200000); self.assertIn("does not match", self.val("SELECT body FROM notifications WHERE user_id=? AND title='Withdrawal request declined'", (self.users["inst"],)))
        self.assertIn("Account name does not match", c.get("/staff/earnings").data.decode()); self.assertIn("Withdrawal requested", self.request(c, 2000).data.decode())
    def test_only_people_with_the_permission_can_manage_payouts(self):
        c, rid = self.open_request()
        for who in ("alice", "inst", "inst2", "writer", "officer", "refunder", "noperm"):
            k = self.client(who)
            for url in ("/staff/payouts", f"/staff/payouts/{rid}", "/staff/payouts/instructors", "/staff/payouts/export.csv", "/staff/payouts/instructors/export.csv", "/staff/settings/payouts"): self.assertEqual(k.get(url).status_code, 403, (who, url))
            self.pay(k, rid); self.post(k, f"/staff/payouts/{rid}", {"action": "reject", "confirm": "1", "reason": "x"}); self.assertEqual(self.val("SELECT status FROM payout_requests"), "requested", who)
        self.assertEqual(self.app.test_client().get("/staff/payouts").status_code, 302)
        for who in ("owner", "payroll"): self.assertEqual(self.client(who).get(f"/staff/payouts/{rid}").status_code, 200)
        o = self.client("owner"); self.post(o, f"/staff/users/{self.users['noperm']}", {"action": "perms", "perm": ["payouts.manage"]}); self.assertEqual(self.client("noperm").get("/staff/payouts").status_code, 200)
    def test_admin_cannot_decide_own_request_but_owner_may(self):
        mine = self.mk("adm_inst", "admin", perms=["payouts.manage", "courses.manage"]); cid = dbm.ex("INSERT INTO courses(division,title,slug,price_kobo,status,instructor_id) VALUES ('academic','Admin Course','admin-course',100000,'published',?)", (mine,))
        self.sale("alice", "admin-course"); c = self.client("adm_inst"); self.assertEqual(c.get("/staff/earnings").status_code, 200)                      # an admin who teaches sees earnings too
        self.bank(c); self.request(c, 400); rid = self.val("SELECT id FROM payout_requests"); self.pay(c, rid); self.assertEqual(self.val("SELECT status FROM payout_requests"), "requested")
        self.post(c, f"/staff/payouts/{rid}", {"action": "reject", "confirm": "1", "reason": "x"}); self.assertEqual(self.val("SELECT status FROM payout_requests"), "requested"); self.pay(self.client("payroll"), rid); self.assertEqual(self.val("SELECT status FROM payout_requests"), "paid")
    def test_lists_summary_and_settings(self):
        c, rid = self.open_request(1000); o = self.client("owner"); self.assertIn("Waiting to be paid", o.get("/staff/payouts?status=requested").data.decode()); self.assertIn("Inst", o.get("/staff/payouts?q=0123456789").data.decode())
        h = o.get("/staff/payouts/instructors").data.decode(); self.assertIn("School&#39;s share", h.replace("School's share", "School&#39;s share")); self.assertIn("3,000", h)                      # school keeps 60% of 5,000
        self.assertIn(b"Inst", o.get("/staff/payouts/export.csv").data); self.assertIn(b"Tutor earned", o.get("/staff/payouts/instructors/export.csv").data)
        for bad in ("101", "-1", "abc", ""): self.post(o, "/staff/settings/payouts", {"payout.instructor_percent": bad, "payout.min_naira": "0", "payout.enabled": "1", "payout.instructions": "x"}); self.assertEqual(S.get("payout.instructor_percent"), "40", bad)
        self.post(o, "/staff/settings/payouts", {"payout.instructor_percent": "35.5", "payout.min_naira": "2000", "payout.enabled": "1", "payout.instructions": "Paid on Fridays"}); self.assertEqual((S.get("payout.instructor_percent"), S.get("payout.min_naira")), ("35.5", "2000"))
        self.assertIn("Paid on Fridays", self.client("inst").get("/staff/earnings").data.decode()); self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='settings.payouts'"), 1)
