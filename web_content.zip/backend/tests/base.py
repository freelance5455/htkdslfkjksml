import io, os, shutil, tempfile, unittest, logging
from werkzeug.security import generate_password_hash
from PIL import Image
from dagba import create_app, db as dbm
from dagba.seed import seed_structure

logging.disable(logging.CRITICAL)
MIG = os.path.join(os.path.dirname(os.path.dirname(__file__)), "migrations")
PW = "Passw0rdTest1"
PWHASH = generate_password_hash(PW)

def png_bytes():
    b = io.BytesIO(); Image.new("RGB", (20, 20), (200, 30, 30)).save(b, "PNG"); return b.getvalue()
MOU_BODY = ("<h2>1. Parties</h2><p>This Memorandum of Understanding is made between the Academy and the Tutor who signs it, and sets out how the Tutor may publish courses.</p>"
            "<h2>2. Responsibilities</h2><ol><li>The Tutor will give accurate information and keep course material up to date.</li><li>The Academy will host and sell approved courses and pay the Tutor's agreed share.</li></ol>"
            "<h2>3. Changes</h2><p>A new version may be published; each tutor keeps the exact version they signed.</p>")
PDF = b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n"

class Base(unittest.TestCase):
    rate = False
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.app = create_app({"DATABASE": os.path.join(self.tmp, "t.db"), "PRIVATE_DIR": os.path.join(self.tmp, "priv"), "PUBLIC_DIR": os.path.join(self.tmp, "pub"),
                               "SECRET_KEY": "test", "TESTING": True, "RATE_LIMITS_ENABLED": self.rate})
        dbm.migrate(self.app.config["DATABASE"], MIG)
        self.ctx = self.app.app_context(); self.ctx.push()
        seed_structure()
        self.users = {}
        self.mk("owner", "admin", owner=1)
        self.mk("officer", "admin", perms=["payments.manage"])
        self.mk("refunder", "admin", perms=["payments.manage", "payments.refund"])
        self.mk("noperm", "admin")
        self.mk("alice", "student"); self.mk("bob", "student"); self.mk("inst", "instructor"); self.mk("writer", "writer")
        ex = dbm.ex
        self.paid = ex("INSERT INTO courses(division,title,slug,price_kobo,status,instructor_id) VALUES ('academic','Paid Maths','paid-maths',500000,'published',?)", (self.users["inst"],))
        self.inc = ex("INSERT INTO courses(division,title,slug,price_kobo,status,instructor_id) VALUES ('income','Marketing','marketing',1000000,'published',?)", (self.users["inst"],))
        self.free = ex("INSERT INTO courses(division,title,slug,price_kobo,status) VALUES ('academic','Free','free',0,'published')")
        self.draft = ex("INSERT INTO courses(division,title,slug,price_kobo,status) VALUES ('academic','Draft','draftc',100,'draft')")
        for c in (self.paid, self.inc):
            m = ex("INSERT INTO modules(course_id,title,position) VALUES (?,?,1)", (c, "M1"))
            for i in (1, 2): ex("INSERT INTO lessons(course_id,module_id,title,kind,body,position) VALUES (?,?,?,?,?,?)", (c, m, f"L{i}", "text", "body", i))
        self.plan_a = ex("INSERT INTO plans(name,division,price_kobo,duration_days,active) VALUES ('Acad Sub','academic',1500000,30,1)")
        self.plan_i = ex("INSERT INTO plans(name,division,price_kobo,duration_days,active) VALUES ('Inc Sub','income',3000000,30,1)")
        from dagba.services import settings as S
        S.put("bank.name", "Test Bank"); S.put("bank.account_name", "Dagba"); S.put("bank.account_number", "0123456789")

    def publish_mou(self, body=None, change_type="minor", title="Tutor Memorandum of Understanding"):
        """Publish a MOU version as the owner, through the service layer (the HTTP flow has its own tests)."""
        from dagba.services import mou as M
        actor = dbm.q1("SELECT * FROM users WHERE id=?", (self.users["owner"],))
        M.create_draft(actor)
        return M.publish(actor, {"title": title, "body_html": body or MOU_BODY, "change_type": change_type})

    def tearDown(self):
        self.ctx.pop(); shutil.rmtree(self.tmp, ignore_errors=True)

    def mk(self, key, role, owner=0, perms=()):
        uid = dbm.ex("INSERT INTO users(email,password_hash,full_name,role,is_owner) VALUES (?,?,?,?,?)", (f"{key}@t.test", PWHASH, key.title(), role, owner))
        for p in perms: dbm.ex("INSERT INTO user_permissions VALUES (?,?)", (uid, p))
        self.users[key] = uid; return uid

    def client(self, who=None):
        c = self.app.test_client()
        with c.session_transaction() as s: s["_csrf"] = "tok"
        if who: self.assertEqual(self.post(c, "/login", {"email": f"{who}@t.test", "password": PW}).status_code, 302)
        return c

    def tok(self, c):
        with c.session_transaction() as s: return s.setdefault("_csrf", "tok")

    def post(self, c, url, data=None, **kw):
        d = dict(data or {}); d["_csrf"] = self.tok(c); return c.post(url, data=d, **kw)

    def row(self, sql, a=()): return dbm.q1(sql, a)
    def val(self, sql, a=()): return dbm.val(sql, a)

    def buy(self, c, kind, ident, who="alice", submit=True, promo=""):
        path = f"/checkout/course/{ident}" if kind == "course" else f"/checkout/plan/{ident}"
        r = self.post(c, path, {"action": "pay", "promo": promo}); self.assertEqual(r.status_code, 302, r.data[:300])
        ref = r.headers["Location"].rsplit("/", 1)[-1]
        if submit:
            r = self.upload(c, ref)
            self.assertEqual(r.status_code, 302)
        return ref

    def upload(self, c, ref, name="r.png", data=None, extra=None):
        d = {"_csrf": self.tok(c), "transfer_date": "2026-11-01", "sender_name": "A", "receipt": (io.BytesIO(data if data is not None else png_bytes()), name)}
        d.update(extra or {}); return c.post(f"/pay/{ref}/evidence", data=d, content_type="multipart/form-data")

    def tx(self, ref): return self.row("SELECT * FROM transactions WHERE reference=?", (ref,))
