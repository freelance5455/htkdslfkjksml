"""Faith topic icon/image (optional, admin-assigned) and homepage study-path icons."""
import io
from .base import *
from .test_faith import FaithBase

class TopicVisualTests(FaithBase):
    def setUp(self):
        super().setUp()
        self.mkitem()                                           # a published lesson so the topic shows on the homepage too
    def form(self, icon=None, image=None, **extra):
        d = {"_csrf": self.tok(self.owner), "name": "Prayer", "description": "Learn to pray.", "position": "2", "active": "1", "access_policy": "lifetime", "price_kobo": "0"}
        if icon is not None: d["icon"] = icon
        if image: d["image"] = (io.BytesIO(image), "t.png")
        d.update(extra)
        return self.owner.post(f"/staff/r/faith-topics/{self.topic}/edit", data=d, content_type="multipart/form-data")
    def row(self): return dbm.q1("SELECT icon, image FROM faith_topics WHERE id=?", (self.topic,))
    def public(self, path="/faith"): return self.app.test_client().get(path).data.decode()

    def test_visual_is_optional_and_existing_data_untouched(self):
        r = self.row(); self.assertIsNone(r["icon"]); self.assertIsNone(r["image"])
        self.assertEqual(self.form(icon="").status_code, 302)
        self.assertNotIn('class="tvis', self.public())
        self.assertEqual(self.val("SELECT name FROM faith_topics WHERE id=?", (self.topic,)), "Prayer")
    def test_icon_shows_on_cards_and_can_be_changed_and_removed(self):
        self.assertEqual(self.form(icon="prayer").status_code, 302); self.assertEqual(self.row()["icon"], "prayer")
        for path in ("/faith", "/"): self.assertIn('class="tvis"', self.public(path), path)
        self.form(icon="heart"); self.assertEqual(self.row()["icon"], "heart")
        self.form(icon=""); self.assertIsNone(self.row()["icon"]); self.assertNotIn('class="tvis"', self.public())
    def test_form_shows_picker_and_rejects_unknown_icon(self):
        html = self.owner.get(f"/staff/r/faith-topics/{self.topic}/edit").data.decode()
        self.assertIn('class="iconpick"', html); self.assertIn('name="icon"', html); self.assertIn('name="image"', html)
        self.form(icon="nope"); self.assertIsNone(self.row()["icon"])
    def test_image_upload_replace_remove_and_public_display(self):
        self.assertEqual(self.form(icon="", image=png_bytes()).status_code, 302); first = self.row()["image"]; self.assertTrue(first)
        self.assertIn(f"/media/{first}", self.public()); self.assertIn(f"/media/{first}", self.public("/"))
        self.assertEqual(self.app.test_client().get(f"/media/{first}").status_code, 200)
        self.assertIn(f"/media/{first}", self.owner.get(f"/staff/r/faith-topics/{self.topic}/edit").data.decode())
        self.form(icon="", image=png_bytes()); second = self.row()["image"]; self.assertNotEqual(first, second)
        self.assertEqual(self.app.test_client().get(f"/media/{first}").status_code, 404)           # replaced file tidied away
        self.form(icon="", remove_image="1"); self.assertIsNone(self.row()["image"])
        self.assertEqual(self.app.test_client().get(f"/media/{second}").status_code, 404)
    def test_saving_without_changes_keeps_image_and_icon_replaces_image(self):
        self.form(icon="", image=png_bytes()); keep = self.row()["image"]
        self.form(icon=""); self.assertEqual(self.row()["image"], keep)
        self.form(icon="star"); r = self.row(); self.assertEqual(r["icon"], "star"); self.assertIsNone(r["image"])   # either/or
        self.form(icon="star", image=png_bytes()); r = self.row(); self.assertTrue(r["image"]); self.assertIsNone(r["icon"])
    def test_bad_image_rejected_and_other_topics_unaffected(self):
        self.form(icon="", image=b"not an image"); self.assertIsNone(self.row()["image"])
        others = dbm.q("SELECT icon, image FROM faith_topics WHERE id!=?", (self.topic,)); self.assertTrue(all(o["icon"] is None and o["image"] is None for o in others))
    def test_icon_keys_match_template(self):
        from dagba.services import faith as F
        t = open("dagba/templates/_icons.html", encoding="utf-8").read()
        for k, _ in F.TOPIC_ICONS: self.assertIn(f"k=='{k}'", t)

class StudyPathIconTests(Base):
    def test_homepage_study_path_cards_get_icons(self):
        html = self.app.test_client().get("/").data.decode()
        self.assertGreaterEqual(html.count('class="pico"'), 2)
        self.assertIn("Academic learning", html); self.assertIn("Income skills", html)
    def test_icon_matches_card_title(self):
        from flask import render_template_string
        with self.app.test_request_context("/"):
            f = lambda t, l="": render_template_string("{% from '_icons.html' import path_icon %}{{ path_icon(t, l) }}", t=t, l=l)
            self.assertIn("M22 9L12 4", f("Academic Learning")); self.assertIn("M3 17l6-6", f("Income Skills"))
            self.assertIn("M9 7V5", f("Professional Development")); self.assertEqual(f("Something else").strip(), "")

class FeaturedCarouselTests(Base):
    def test_featured_courses_render_as_carousel_with_existing_cards_and_links(self):
        extra = dbm.ex("INSERT INTO courses(division,title,slug,price_kobo,status) VALUES ('income','Graphic Design','graphic-design',100000,'published')")
        dbm.ex("UPDATE courses SET featured=1 WHERE id IN (?,?)", (extra, self.inc))
        html = self.app.test_client().get("/").data.decode()
        self.assertIn("data-fcar", html); self.assertIn("js/carousel.js", html)
        self.assertGreaterEqual(html.count('class="fslide"'), 2)
        self.assertIn("/courses/graphic-design", html); self.assertIn("/courses/marketing", html)   # existing card links unchanged (Income Skills section)
        self.assertIn('data-dir="-1"', html); self.assertIn('data-dir="1"', html)
        self.assertEqual(self.app.test_client().get("/static/js/carousel.js").status_code, 200)
    def test_homepage_without_featured_courses_has_no_carousel(self):
        dbm.ex("UPDATE courses SET featured=0"); dbm.ex("UPDATE courses SET status='draft'")
        html = self.app.test_client().get("/").data.decode()
        self.assertEqual(html.count("data-fcar"), 1); self.assertIn("introcar", html.split("data-fcar")[1][:200])      # only the Intro Cards carousel; no course carousel

class HomepageCarouselsTests(Base):
    def test_every_course_section_is_its_own_carousel(self):
        cid = dbm.ex("INSERT INTO categories(division,level,name,slug,price_kobo,featured,active) VALUES ('academic','basic','Maths JSS1','basic-maths-jss1',500000,1,1)")
        dbm.ex("INSERT INTO courses(division,title,slug,price_kobo,status,category_id,academic_level) VALUES ('academic','Algebra','algebra',0,'published',?,'basic')", (cid,))
        dbm.ex("UPDATE courses SET featured=1 WHERE id=?", (self.inc,))
        t = dbm.q1("SELECT id FROM faith_topics LIMIT 1")["id"]
        dbm.ex("INSERT INTO faith_items(topic_id,title,slug,kind,body,status,access,created_at) VALUES (?,?,?,?,?,?,?,datetime('now'))", (t, "L", "l", "reading", "b", "published", "public"))
        html = self.app.test_client().get("/").data.decode()
        self.assertEqual(html.count("data-fcar"), 4)                                   # intro cards, faith, basic categories, featured
        self.assertIn("/faith/", html); self.assertIn("Maths JSS1", html); self.assertIn("/courses/marketing", html)   # existing cards/links unchanged
        self.assertEqual(html.count('data-dir="1"'), 4)                                # each has its own arrows (intro cards + 3 course/faith carousels)
