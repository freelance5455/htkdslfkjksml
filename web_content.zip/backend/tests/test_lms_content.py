from .base import *
from dagba.services import lms, access

class LmsTests(Base):
    def grant(self, who, cid):
        dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at) VALUES (?,?,?,?,?)", (self.users[who], "course", cid, "academic", "2026-01-01 00:00:00"))
    def lessons(self, cid): return [r["id"] for r in lms.ordered_lessons(cid)]

    def test_course_player_access_and_progress_persistence(self):
        c = self.client("alice"); self.assertEqual(c.get("/learn/paid-maths").status_code, 302); self.grant("alice", self.paid)
        l1, l2 = self.lessons(self.paid); self.assertEqual(c.get(f"/learn/paid-maths/lesson/{l1}").status_code, 200)
        self.assertEqual(lms.resume_lesson(self.users["alice"], self.paid)["id"], l1)
        self.post(c, f"/learn/lesson/{l1}/progress", {"position": "42"}); self.assertEqual(self.val("SELECT position_seconds FROM progress WHERE lesson_id=?", (l1,)), 42)
        self.post(c, f"/learn/lesson/{l1}/complete"); self.assertEqual(lms.course_progress(self.users["alice"], self.paid)["percent"], 50)
        c2 = self.client("alice")   # another device: progress comes from DB
        self.assertIn("50%", c2.get("/learn/paid-maths").data.decode()); self.assertEqual(lms.resume_lesson(self.users["alice"], self.paid)["id"], l2)
        self.assertEqual(self.client("bob").get(f"/learn/paid-maths/lesson/{l1}").status_code, 302)
        self.assertEqual(self.post(self.client("bob"), f"/learn/lesson/{l1}/complete").status_code, 403)
        self.assertEqual(self.val("SELECT COUNT(*) FROM progress WHERE user_id=?", (self.users["bob"],)), 0)

    def test_free_course_and_free_preview(self):
        l = dbm.ex("INSERT INTO lessons(course_id,title,kind,body,position) VALUES (?,?,?,?,1)", (self.free, "F1", "text", "x"))
        self.assertEqual(self.client("alice").get(f"/learn/free/lesson/{l}").status_code, 200)
        l1, l2 = self.lessons(self.paid); dbm.ex("UPDATE lessons SET free_preview=1 WHERE id=?", (l1,))
        self.assertEqual(self.client("bob").get(f"/learn/paid-maths/lesson/{l1}").status_code, 200); self.assertEqual(self.client("bob").get(f"/learn/paid-maths/lesson/{l2}").status_code, 302)

    def test_quiz_graded_server_side(self):
        self.grant("alice", self.paid); z = dbm.ex("INSERT INTO quizzes(course_id,title,pass_mark) VALUES (?,?,50)", (self.paid, "Q"))
        q1 = dbm.ex("INSERT INTO questions(quiz_id,course_id,prompt,options,correct) VALUES (?,?,?,?,2)", (z, self.paid, "2+2?", "3\n4\n5"))
        c = self.client("alice"); page = c.get(f"/learn/paid-maths/quiz/{z}").data.decode(); self.assertNotIn("correct", page.lower().replace("correct answer", ""))
        r = self.post(c, f"/learn/paid-maths/quiz/{z}", {f"q{q1}": "1"}); self.assertIn(b"0%", r.data); self.assertEqual(self.val("SELECT passed FROM quiz_attempts"), 0)
        r = self.post(c, f"/learn/paid-maths/quiz/{z}", {f"q{q1}": "2"}); self.assertEqual(self.val("SELECT MAX(score_percent) FROM quiz_attempts"), 100)
        self.assertEqual(self.client("bob").get(f"/learn/paid-maths/quiz/{z}").status_code, 403)

    def test_assignment_flow_and_feedback(self):
        self.grant("alice", self.paid); a = dbm.ex("INSERT INTO assignments(course_id,title,instructions) VALUES (?,?,?)", (self.paid, "A1", "do it"))
        c = self.client("alice"); self.post(c, f"/learn/paid-maths/assignment/{a}", {"body": "my answer"}); s = dbm.q1("SELECT * FROM submissions")
        self.assertEqual(s["status"], "submitted"); self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=?", (self.users["inst"],)), 1)
        self.assertEqual(self.client("writer").get(f"/staff/submissions/{s['id']}").status_code, 403)
        i = self.client("inst"); self.assertEqual(i.get(f"/staff/submissions/{s['id']}").status_code, 200)
        self.post(i, f"/staff/submissions/{s['id']}", {"score": "80", "feedback": "good"}); self.assertEqual(self.val("SELECT status FROM submissions"), "reviewed")
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND kind='assignment'", (self.users["alice"],)), 1)
        self.post(i, f"/staff/submissions/{s['id']}", {"score": "999"}); self.assertEqual(self.val("SELECT score FROM submissions"), 80)

    def test_certificate_lifecycle(self):
        self.grant("alice", self.paid); a = self.users["alice"]; c = self.client("alice"); l1, l2 = self.lessons(self.paid)
        self.post(c, "/learn/paid-maths/certificate"); self.assertEqual(self.val("SELECT COUNT(*) FROM certificates"), 0)       # not eligible
        for l in (l1, l2): self.post(c, f"/learn/lesson/{l}/complete")
        z = dbm.ex("INSERT INTO quizzes(course_id,title,pass_mark) VALUES (?,?,50)", (self.paid, "Q")); qq = dbm.ex("INSERT INTO questions(quiz_id,course_id,prompt,options,correct) VALUES (?,?,?,?,1)", (z, self.paid, "?", "a\nb"))
        self.post(c, "/learn/paid-maths/certificate"); self.assertEqual(self.val("SELECT COUNT(*) FROM certificates"), 0)       # quiz not passed
        self.post(c, f"/learn/paid-maths/quiz/{z}", {f"q{qq}": "1"}); self.post(c, "/learn/paid-maths/certificate")
        cert = dbm.q1("SELECT * FROM certificates"); self.assertRegex(cert["cert_id"], r"^DDA-\d{4}-[0-9A-F]{8}$")
        self.post(c, "/learn/paid-maths/certificate"); self.assertEqual(self.val("SELECT COUNT(*) FROM certificates"), 1)
        pdf = c.get(f"/certificates/{cert['cert_id']}.pdf"); self.assertEqual(pdf.status_code, 200); self.assertTrue(pdf.data.startswith(b"%PDF")); self.assertIn(b"QR", b"QR" + pdf.data)
        self.assertEqual(self.client("bob").get(f"/certificates/{cert['cert_id']}.pdf").status_code, 404)
        anon = self.app.test_client(); v = anon.get(f"/verify/{cert['cert_id']}").data.decode(); self.assertIn("Valid certificate", v); self.assertIn("Alice", v)
        self.assertIn("No certificate found", anon.get("/verify/DDA-0000-FFFFFFFF").data.decode())
        o = self.client("owner"); self.post(o, "/staff/certificates", {"cert_id": cert["cert_id"], "action": "revoke", "reason": ""}); self.assertIsNone(self.val("SELECT revoked_at FROM certificates"))
        self.post(o, "/staff/certificates", {"cert_id": cert["cert_id"], "action": "revoke", "reason": "fraud"}); self.assertIn("revoked", anon.get(f"/verify/{cert['cert_id']}").data.decode().lower())
        self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='certificate.revoke'"), 1); self.assertEqual(c.get(f"/certificates/{cert['cert_id']}.pdf").status_code, 302)
        self.assertEqual(self.client("officer").get("/staff/certificates").status_code, 403)

    def test_course_creation_and_lesson_by_instructor(self):
        i = self.client("inst"); r = self.post(i, "/staff/r/courses/new", {"title": "My New Course", "division": "income", "status": "published", "price_kobo": "1"}); self.assertEqual(r.status_code, 200)
        self.assertEqual(self.val("SELECT COUNT(*) FROM courses WHERE title='My New Course'"), 0)   # instructor cannot choose Published
        r = self.post(i, "/staff/r/courses/new", {"title": "My New Course", "division": "income", "status": "review", "price_kobo": "1"}); self.assertEqual(r.status_code, 302)
        c = dbm.q1("SELECT * FROM courses WHERE title='My New Course'"); self.assertEqual((c["status"], c["price_kobo"], c["instructor_id"], c["slug"]), ("review", 0, self.users["inst"], "my-new-course"))  # cannot self-publish / set price
        r = self.post(i, "/staff/r/lessons/new", {"course_id": str(c["id"]), "title": "Intro", "kind": "video", "video_url": "https://youtu.be/dQw4w9WgXcQ", "position": "1"}); self.assertEqual(r.status_code, 302)
        r = self.post(i, "/staff/r/lessons/new", {"course_id": str(c["id"]), "title": "Bad", "kind": "video", "video_url": "javascript:alert(1)"}); self.assertEqual(r.status_code, 200)
        self.assertEqual(self.val("SELECT COUNT(*) FROM lessons WHERE course_id=?", (c["id"],)), 1)
        self.assertEqual(self.app.test_client().get("/courses/my-new-course").status_code, 404)    # draft hidden from public
        o = self.client("owner"); self.post(o, f"/staff/r/courses/{c['id']}/edit", {"title": "My New Course", "division": "income", "status": "published", "price_kobo": "2500", "access_policy": "lifetime"})
        self.assertEqual(self.val("SELECT price_kobo FROM courses WHERE id=?", (c["id"],)), 250000); self.assertEqual(self.app.test_client().get("/courses/my-new-course").status_code, 200)
        l = dbm.q1("SELECT * FROM lessons WHERE course_id=?", (c["id"],)); page = self.client("owner").get(f"/learn/my-new-course/lesson/{l['id']}").data.decode(); self.assertIn("youtube-nocookie.com/embed/dQw4w9WgXcQ", page)

    def test_admin_creates_category_and_course_without_code(self):
        o = self.client("owner"); self.post(o, "/staff/r/categories/new", {"division": "income", "name": "Drone Piloting", "active": "1"})
        cat = dbm.q1("SELECT * FROM categories WHERE name='Drone Piloting'"); self.assertTrue(cat)
        self.post(o, "/staff/r/courses/new", {"title": "Drones 101", "division": "income", "category_id": str(cat["id"]), "status": "published", "price_kobo": "7500"})
        self.assertIn("Drones 101", self.app.test_client().get("/income-skills").data.decode())

class ContentTests(Base):
    def test_writer_workflow(self):
        w = self.client("writer"); self.post(w, "/staff/r/articles/new", {"title": "Study Tips", "body": "## Hi\nbody", "status": "published"}); self.assertEqual(w.get("/staff/r/articles/new").status_code, 200)
        self.assertEqual(self.val("SELECT COUNT(*) FROM articles"), 0)                    # writers cannot publish
        self.post(w, "/staff/r/articles/new", {"title": "Study Tips", "body": "text", "status": "pending"}); a = dbm.q1("SELECT * FROM articles")
        self.assertEqual((a["status"], a["author_id"]), ("pending", self.users["writer"])); self.assertEqual(self.app.test_client().get("/blog/study-tips").status_code, 404)
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND title LIKE 'Content awaiting%'", (self.users["owner"],)), 1)
        o = self.client("owner"); self.post(o, f"/staff/r/articles/{a['id']}/edit", {"title": "Study Tips", "body": "text", "status": "published"})
        self.assertEqual(self.app.test_client().get("/blog/study-tips").status_code, 200); self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND title LIKE '%approved%'", (self.users["writer"],)), 1)
        self.post(w, f"/staff/r/articles/{a['id']}/edit", {"title": "Hacked", "body": "x", "status": "draft"}); self.assertEqual(self.val("SELECT title FROM articles"), "Study Tips")   # cannot edit published
        self.post(w, "/staff/r/articles/new", {"title": "Mine", "body": "t", "status": "draft"}); self.assertEqual(self.client("owner").get("/staff/r/articles").status_code, 200)
        other = self.mk("writer2", "writer"); mine = dbm.q1("SELECT id FROM articles WHERE title='Mine'")["id"]
        self.assertEqual(self.client("writer2").get(f"/staff/r/articles/{mine}/edit").status_code, 404)

    def test_scheduled_publication_and_sitemap(self):
        dbm.ex("INSERT INTO articles(title,slug,body,status,publish_at) VALUES ('Future','future','b','scheduled','2999-01-01 00:00:00')")
        dbm.ex("INSERT INTO articles(title,slug,body,status,publish_at) VALUES ('Past','past','b','scheduled','2000-01-01 00:00:00')")
        a = self.app.test_client(); self.assertEqual(a.get("/blog/future").status_code, 404); self.assertEqual(a.get("/blog/past").status_code, 200)
        sm = a.get("/sitemap.xml").data.decode(); self.assertIn("/blog/past", sm); self.assertNotIn("/blog/future", sm); self.assertIn("/courses/paid-maths", sm); self.assertNotIn("draftc", sm)
        self.assertIn("Disallow: /staff", a.get("/robots.txt").data.decode())

    def test_nuggets_and_testimonials(self):
        o = self.client("owner"); self.post(o, "/staff/r/nuggets/new", {"title": "Pay Yourself First", "body": "Save before spending.", "status": "published", "category": "Finance"})
        self.assertIn("Pay Yourself First", self.app.test_client().get("/nuggets").data.decode())
        self.post(o, "/staff/r/testimonials/new", {"name": "Ada", "quote": "Great", "status": "published"}); self.assertEqual(self.val("SELECT COUNT(*) FROM testimonials"), 0)   # unverified cannot publish
        self.post(o, "/staff/r/testimonials/new", {"name": "Ada", "quote": "Great", "status": "published", "verified": "1"}); self.assertIn("Great", self.app.test_client().get("/testimonials").data.decode())
        t = dbm.q1("SELECT id FROM testimonials")["id"]; self.post(o, f"/staff/r/testimonials/{t}/delete"); self.assertEqual(self.val("SELECT COUNT(*) FROM testimonials"), 0)

    def test_xss_escaped_in_rendered_content(self):
        dbm.ex("INSERT INTO nuggets(title,slug,body,status) VALUES ('<script>alert(1)</script>','x','<img src=x onerror=alert(1)> **b**','published')")
        h = self.app.test_client().get("/nuggets/x").data.decode(); self.assertNotIn("<script>alert", h); self.assertNotIn("<img src=x", h); self.assertIn("&lt;img", h)

    def test_security_headers(self):
        h = self.app.test_client().get("/").headers
        for k in ("Content-Security-Policy", "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy"): self.assertIn(k, h)
        self.assertIn("script-src 'self'", h["Content-Security-Policy"])

    def test_contact_newsletter_notify(self):
        c = self.client(); self.post(c, "/contact", {"name": "Z", "email": "z@x.com", "message": "hi"}); self.assertEqual(self.val("SELECT COUNT(*) FROM contact_messages"), 1)
        self.post(c, "/contact", {"name": "Bot", "email": "z@x.com", "message": "hi", "website": "spam"}); self.assertEqual(self.val("SELECT COUNT(*) FROM contact_messages"), 1)
        self.post(c, "/newsletter", {"email": "n@x.com"}); self.post(c, "/newsletter", {"email": "n@x.com"}); self.assertEqual(self.val("SELECT COUNT(*) FROM newsletter_subscribers"), 1)

    def test_notifications_read_unread_and_broadcast(self):
        o = self.client("owner"); self.post(o, "/staff/broadcast", {"audience": "students", "title": "Welcome back", "body": "Term starts"})
        c = self.client("alice"); self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL", (self.users["alice"],)), 1)
        self.post(c, "/notifications", {}); self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL", (self.users["alice"],)), 0)
        nid = self.val("SELECT id FROM notifications WHERE user_id=?", (self.users["alice"],)); self.assertEqual(self.client("bob").get(f"/notifications/{nid}/go").status_code, 404)

    def test_registration_notifies_and_audit_view_and_backup(self):
        self.post(self.client(), "/register", {"full_name": "Zed", "email": "zed@t.test", "password": PW, "password2": PW})
        self.assertGreaterEqual(self.val("SELECT COUNT(*) FROM notifications WHERE title LIKE 'New student%'"), 1)
        o = self.client("owner"); self.assertEqual(o.get("/staff/audit").status_code, 200)
        r = self.post(o, "/staff/system"); self.assertEqual(r.status_code, 200); self.assertTrue(r.data.startswith(b"PK"))
        self.assertEqual(self.client("officer").get("/staff/system").status_code, 403)

    def test_all_staff_pages_render_for_owner(self):
        o = self.client("owner")
        for p in ["/staff/", "/staff/users", "/staff/users/new", f"/staff/users/{self.users['alice']}", "/staff/payments", "/staff/reports", "/staff/messages", "/staff/broadcast", "/staff/certificates", "/staff/audit", "/staff/system", "/staff/submissions"] + \
                 [f"/staff/settings/{g}" for g in ("bank", "methods", "site", "home", "brand", "seo", "cert")] + [f"/staff/r/{k}" for k in ("categories","courses","modules","lessons","quizzes","questions","assignments","announcements","plans","promos","testimonials","faqs","pages","article-categories","articles","nuggets")] + \
                 [f"/staff/r/{k}/new" for k in ("categories","courses","modules","lessons","quizzes","questions","assignments","announcements","plans","promos","testimonials","faqs","article-categories","articles","nuggets")] + [f"/staff/courses/{self.paid}/learners", "/student", "/student/courses", "/student/payments", "/student/certificates", "/student/assessments", "/student/assignments", "/notifications", "/account"]:
            self.assertEqual(o.get(p).status_code, 200, p)
        a = self.client("alice")
        for p in ("/student", "/student/courses", "/student/payments", "/student/certificates", "/student/assessments", "/student/assignments", "/notifications", "/account", "/checkout/course/paid-maths", f"/checkout/plan/{self.plan_a}"): self.assertEqual(a.get(p).status_code, 200, p)
        for who in ("inst", "writer"): self.assertEqual(self.client(who).get("/staff/").status_code, 200)
