from .base import *
from dagba.services import access
from .test_academic import cat
from .test_pricing import PricingBase

class BasicCategoryTests(PricingBase):
    def setUp(self):
        super().setUp()
        dbm.ex("UPDATE categories SET name='English JSS1', featured=1 WHERE id=?", (self.phys,))
        self.a = self.make("Grammar Basics", "basic", "academic-physics"); self.b = self.make("Comprehension Skills", "basic", "academic-physics")
        self.adv = self.make("Law 1", "advanced", "advanced-law", price="3000")
        self.pro = self.make("ICAN Prep", "professional", None, price="4000")
    def page(self, path, who=None):
        c = self.client(who) if who else self.app.test_client(); return c.get(path).data.decode()

    def test_homepage_shows_category_name_and_price_not_course_titles(self):
        h = self.page("/"); self.assertIn('href="/academic/basic/english-jss1"', h); self.assertIn("8,000", h)
        self.assertNotIn("Grammar Basics", h); self.assertNotIn("Comprehension Skills", h)
        self.assertNotIn("Law 1", h); self.assertIn("<h3>Law</h3>", h)       # Advanced shows its subject once, not its courses
    def test_unfeatured_category_not_on_homepage(self):
        dbm.ex("UPDATE categories SET featured=0 WHERE id=?", (self.phys,)); self.assertNotIn('href="/academic/basic/english-jss1"', self.page("/"))
    def test_course_listing_shows_categories_for_basic_only(self):
        h = self.page("/courses"); self.assertIn("English JSS1", h); self.assertNotIn("Grammar Basics", h); self.assertIn("Law 1", h); self.assertIn("ICAN Prep", h)
        h = self.page("/courses?level=basic"); self.assertIn("English JSS1", h); self.assertNotIn("Grammar Basics", h)
        h = self.page("/courses?level=advanced"); self.assertIn("Law 1", h); self.assertNotIn('href="/academic/basic/english-jss1"', h)
    def test_category_filter_redirects_to_category_page(self):
        r = self.app.test_client().get(f"/courses?category={self.phys}"); self.assertEqual(r.status_code, 302); self.assertIn("/academic/basic/english-jss1", r.headers["Location"])
    def test_category_page_lists_courses_topics_and_lessons(self):
        mid = dbm.ex("INSERT INTO modules(course_id,title,position) VALUES (?,?,0)", (self.a, "Nouns and Verbs"))
        dbm.ex("INSERT INTO lessons(course_id,module_id,title,kind,position) VALUES (?,?,?,?,0)", (self.a, mid, "Common nouns", "text"))
        dbm.ex("INSERT INTO lessons(course_id,title,kind,position) VALUES (?,?,?,0)", (self.b, "Reading passages", "text"))
        h = self.page("/academic/basic/english-jss1"); [self.assertIn(x, h) for x in ("Grammar Basics", "Comprehension Skills", "Nouns and Verbs", "Common nouns", "Reading passages")]
    def test_subscription_unlocks_every_basic_category_even_if_course_not_eligible(self):
        dbm.ex("UPDATE courses SET subscription_eligible=0 WHERE id=?", (self.a,)); self.assertIsNone(self.acc("alice", self.a))
        self.approve_path("alice", f"/checkout/plan/{self.plan_a}")
        self.assertEqual(self.acc("alice", self.a), "subscription"); self.assertEqual(self.acc("alice", self.b), "subscription")
        self.assertIn("Unlocked by your Basic subscription", self.page("/academic/basic/english-jss1", "alice"))
        self.assertIsNone(self.acc("alice", self.adv)); self.assertIsNone(self.acc("alice", self.pro))
    def test_category_purchase_unlocks_all_its_content(self):
        self.approve_path("alice", f"/checkout/subject/{self.phys}")
        self.assertEqual(self.acc("alice", self.a), "purchased"); self.assertEqual(self.acc("alice", self.b), "purchased"); self.assertIn("You own this subject", self.page("/academic/basic/english-jss1", "alice"))
    def test_admin_can_create_priced_featured_category_and_assign_courses(self):
        o = self.client("owner")
        r = self.post(o, "/staff/r/categories/new", {"division": "academic", "level": "basic", "name": "Maths JSS2", "price_kobo": "1500", "featured": "1", "active": "1", "access_policy": "lifetime"})
        new = self.val("SELECT id FROM categories WHERE name='Maths JSS2'"); self.assertTrue(new, r.data[:300])
        self.assertEqual(self.val("SELECT price_kobo FROM categories WHERE id=?", (new,)), 150000); self.assertEqual(self.val("SELECT featured FROM categories WHERE id=?", (new,)), 1)
        self.assertEqual(self.post(o, f"/staff/academic/category/{new}", {"course": [str(self.a)]}).status_code, 302)
        self.assertEqual(self.val("SELECT category_id FROM courses WHERE id=?", (self.a,)), new); self.assertEqual(self.val("SELECT category_id FROM courses WHERE id=?", (self.b,)), self.phys)
        self.assertEqual(o.get(f"/staff/academic/category/{new}").status_code, 200); self.assertEqual(o.get("/staff/academic").status_code, 200)
        self.assertEqual(self.client("alice").get(f"/staff/academic/category/{new}").status_code, 403)
    def test_active_basic_category_needs_price_and_advanced_may_be_featured(self):
        o = self.client("owner"); self.post(o, "/staff/r/categories/new", {"division": "academic", "level": "basic", "name": "Free One", "price_kobo": "0", "active": "1", "access_policy": "lifetime"})
        self.assertIsNone(self.val("SELECT id FROM categories WHERE name='Free One'"))
        self.post(o, "/staff/r/categories/new", {"division": "academic", "level": "advanced", "name": "Adv X", "featured": "1", "active": "1", "access_policy": "lifetime"})
        self.assertEqual(self.val("SELECT featured FROM categories WHERE name='Adv X'"), 1)        # Advanced subjects can now be shown on the homepage
        self.post(o, "/staff/r/categories/new", {"division": "income", "name": "Inc X", "featured": "1", "active": "1", "access_policy": "lifetime"}); self.assertEqual(self.val("SELECT featured FROM categories WHERE name='Inc X'"), 0)
