from .base import *
from dagba.services import content as C, settings as S, lms

class Editor(Base):
    def save(self, c, gid, **over):
        """Post a settings group the way the browser does: every field of the form, with overrides applied."""
        from dagba.blueprints.staffpay import GROUPS
        data = {}
        for f in GROUPS[gid]["fields"]:
            if f["t"] == "check":
                if S.flag(f["k"]) : data[f["k"]] = "1"
            elif f["t"] in ("image", "secret"): continue
            else: data[f["k"]] = S.get(f["k"], "")
        for k, v in over.items():
            k = k.replace("__", ".")
            if v is False: data.pop(k, None)
            else: data[k] = v
        return self.post(c, f"/staff/settings/{gid}", data)

class TextAndMenuTests(Editor):
    def test_defaults_match_original_design(self):
        h = self.app.test_client().get("/").data.decode()
        for t in ("How it works", "Create a free account", "Why learn with us", "What is Dagba Digital Academy?", "Income Skills", "Privacy Policy", "Verify a certificate", "Frequently asked questions"): self.assertIn(t, h)
    def test_owner_edits_homepage_text_cards_and_steps(self):
        o = self.client("owner")
        r = self.save(o, "c_home", **{"c__home.steps_title": "Your path", "c__home.steps": "Join | Register free\nPay | Transfer money", "c__home.what_title": "Welcome to {name}", "c__home.faq_link": ""}); self.assertEqual(r.status_code, 302)
        h = self.app.test_client().get("/").data.decode()
        self.assertIn("Your path", h); self.assertNotIn("How it works", h); self.assertIn("Register free", h); self.assertNotIn("Create a free account", h)
        self.assertIn("Welcome to Dagba Digital Academy", h)                      # {name} placeholder
        self.assertNotIn("All FAQs", h)                                           # clearing text hides it
        self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='settings.c_home'"), 1)
    def test_menus_are_editable_and_validated(self):
        o = self.client("owner"); c = self.app.test_client()
        self.save(o, "c_menus", **{"c__nav.header": "Learn | /courses\nMy shop | https://shop.example.com\nPolicies | /p/rules", "c__nav.footer_legal": "Rules | /p/rules", "c__footer.extra": "Made in Nigeria"})
        h = c.get("/").data.decode(); self.assertIn(">Learn</a>", h); self.assertIn("https://shop.example.com", h); self.assertNotIn(">Nuggets</a>", h); self.assertIn("Rules", h); self.assertNotIn("Refund Policy", h); self.assertIn("Made in Nigeria", h)
        for bad in ("Evil | javascript:alert(1)", "Evil | //evil.com", "NoLink", "Evil | data:text/html,x"):
            before = S.get("c.nav.header"); r = self.save(o, "c_menus", **{"c__nav.header": bad}); self.assertEqual(r.status_code, 200); self.assertEqual(S.get("c.nav.header"), before, bad)
    def test_menu_text_is_escaped(self):
        o = self.client("owner"); self.save(o, "c_menus", **{"c__nav.header": "<script>alert(1)</script> | /courses", "c__footer.extra": "<img src=x onerror=alert(1)>"})
        h = self.app.test_client().get("/").data.decode(); self.assertNotIn("<script>alert(1)</script>", h); self.assertNotIn("<img src=x", h); self.assertIn("&lt;script&gt;", h)
    def test_what_cards_link_validated(self):
        o = self.client("owner"); r = self.save(o, "c_home", **{"c__home.what_cards": "Card | text | javascript:alert(1) | Go"}); self.assertEqual(r.status_code, 200); self.assertNotIn("javascript:", S.get("c.home.what_cards"))
        self.save(o, "c_home", **{"c__home.what_cards": "Card | text | /courses | Go"}); self.assertIn('href="/courses">Go', self.app.test_client().get("/").data.decode())
    def test_page_headings_and_messages(self):
        o = self.client("owner"); self.save(o, "c_pages", **{"c__pricing.title": "Our Prices", "c__courses.title_academic": "School subjects", "c__contact.success": "Thanks, we will reply soon.", "c__login.title": "Welcome back", "c__blog.empty": "Coming soon!"})
        c = self.app.test_client(); self.assertIn("Our Prices", c.get("/pricing").data.decode()); self.assertIn("School subjects", c.get("/academic").data.decode()); self.assertIn("Welcome back", c.get("/login").data.decode()); self.assertIn("Coming soon!", c.get("/blog").data.decode())
        cc = self.client(); r = self.post(cc, "/contact", {"name": "Z", "email": "z@x.com", "message": "hi"}, follow_redirects=True); self.assertIn("Thanks, we will reply soon.", r.data.decode())
    def test_site_name_flows_through(self):
        o = self.client("owner"); self.save(o, "site", **{"site__name": "Acme Academy"}); h = self.app.test_client().get("/").data.decode(); self.assertIn("What is Acme Academy?", h)
    def test_section_toggles(self):
        o = self.client("owner"); dbm.ex("INSERT INTO nuggets(title,slug,body,status) VALUES ('N','n','b','published')")
        h = self.app.test_client().get("/").data.decode(); self.assertIn("Frequently asked questions", h); self.assertIn("Academy nuggets", h)
        self.save(o, "home", **{"home__show_faq": False, "home__show_what": False, "home__show_nuggets": False, "home__show_steps": False, "home__show_newsletter": False})
        h = self.app.test_client().get("/").data.decode()
        for gone in ("Frequently asked questions", "What is Dagba", "Academy nuggets", "How it works", "Stay in the loop"): self.assertNotIn(gone, h)
        self.assertIn("Why learn with us", h)
    def test_settings_cache_not_stale(self):
        S.put("c.home.faq_title", "AAA"); self.assertEqual(C.ct("home.faq_title"), "AAA"); S.put("c.home.faq_title", "BBB"); self.assertEqual(C.ct("home.faq_title"), "BBB")
    def test_permissions(self):
        for who, code in (("owner", 200), ("officer", 403), ("inst", 403), ("alice", 403), ("writer", 403), ("noperm", 403)):
            for url in ("/staff/content", "/staff/settings/c_menus", "/staff/settings/c_home", "/staff/settings/c_pages"): self.assertEqual(self.client(who).get(url).status_code, code, (who, url))
        w = self.client("noperm"); self.assertEqual(self.save(w, "c_menus", **{"c__footer.extra": "hacked"}).status_code, 403); self.assertNotIn("hacked", self.app.test_client().get("/").data.decode())
        dbm.ex("INSERT INTO user_permissions VALUES (?,?)", (self.users["noperm"], "settings.manage")); self.assertEqual(self.client("noperm").get("/staff/content").status_code, 200)
    def test_index_lists_everything(self):
        h = self.client("owner").get("/staff/content").data.decode()
        for t in ("Menus &amp; footer", "Homepage text", "Page headings", "Logo, favicon", "Pages", "FAQs", "Certificate wording"): self.assertIn(t, h)

class BrandingAndPagesTests(Editor):
    def upload(self, c, field, data, name):
        from dagba.blueprints.staffpay import GROUPS
        form = {"_csrf": self.tok(c), field: (io.BytesIO(data), name)}
        for f in GROUPS["brand"]["fields"]:
            if f["t"] == "color": form[f["k"]] = S.get(f["k"])
        return c.post("/staff/settings/brand", data=form, content_type="multipart/form-data")
    def test_logo_and_favicon_upload_use_and_reset(self):
        o = self.client("owner"); self.assertEqual(self.upload(o, "brand.logo", png_bytes(), "logo.png").status_code, 302); self.assertEqual(self.upload(o, "brand.favicon", png_bytes(), "f.png").status_code, 302)
        logo, fav = S.get("brand.logo"), S.get("brand.favicon"); self.assertTrue(logo.endswith(".webp") and fav.endswith(".webp"))
        h = self.app.test_client().get("/").data.decode(); self.assertIn(f"/media/{logo}", h); self.assertIn(f'rel="icon" href="/media/{fav}"', h)
        self.assertEqual(self.app.test_client().get(f"/media/{logo}").status_code, 200)
        r = self.upload(o, "brand.logo", b"<svg onload=1>", "x.png"); self.assertEqual(r.status_code, 200); self.assertEqual(S.get("brand.logo"), logo)         # bad file rejected, old kept
        self.post(o, "/staff/settings/brand", {"brand.primary": "#7236E6", "brand.dark": "#1b1230", "brand.accent": "#2563eb", "reset_brand.logo": "1"}); self.assertEqual(S.get("brand.logo"), ""); self.assertIn("/static/img/logo.png", self.app.test_client().get("/").data.decode())
    def test_certificate_uses_custom_logo_and_wording(self):
        o = self.client("owner"); self.upload(o, "brand.logo", png_bytes(), "logo.png")
        self.save(o, "cert", **{"cert__title_text": "DIPLOMA OF EXCELLENCE", "cert__line1": "Proudly awarded to", "cert__line2": "for finishing", "cert__completed": "Finished on", "cert__min_quiz_pass": "1", "cert__signatory": "Principal"})
        self.assertEqual(S.get("cert.title_text"), "DIPLOMA OF EXCELLENCE")
        cert = dict(student_name="Ada", course_title="Maths", issued_at="2026-01-01 00:00:00", cert_id="DDA-2026-AAAAAAAA")
        with self.app.test_request_context("/"): pdf = lms.certificate_pdf(cert)
        self.assertTrue(pdf.startswith(b"%PDF")); self.assertGreater(len(pdf), 1500)
    def test_create_edit_delete_custom_pages(self):
        o = self.client("owner"); r = self.post(o, "/staff/r/pages/new", {"title": "School Rules", "body": "## Rule one\nBe kind.", "seo_description": "Our rules"}); self.assertEqual(r.status_code, 302)
        pg = dbm.q1("SELECT * FROM pages WHERE title='School Rules'"); self.assertEqual(pg["slug"], "school-rules"); a = self.app.test_client()
        r = a.get("/p/school-rules"); self.assertEqual(r.status_code, 200); self.assertIn("Be kind.", r.data.decode()); self.assertIn("/p/school-rules", a.get("/sitemap.xml").data.decode())
        self.save(o, "c_menus", **{"c__nav.header": "Rules | /p/school-rules"}); self.assertIn('href="/p/school-rules">Rules', a.get("/").data.decode())
        self.post(o, f"/staff/r/pages/{pg['id']}/edit", {"title": "School Rules", "body": "Updated text"}); self.assertIn("Updated text", a.get("/p/school-rules").data.decode())
        self.post(o, "/staff/r/pages/new", {"title": "School Rules", "body": "dup"}); self.assertEqual(self.val("SELECT COUNT(*) FROM pages WHERE title='School Rules'"), 2)          # duplicate title gets its own slug
        self.post(o, f"/staff/r/pages/{pg['id']}/delete"); self.assertEqual(a.get("/p/school-rules").status_code, 404)
    def test_core_pages_protected_and_editable(self):
        o = self.client("owner"); core = dbm.q1("SELECT * FROM pages WHERE slug='about'")
        self.post(o, f"/staff/r/pages/{core['id']}/delete"); self.assertEqual(self.val("SELECT COUNT(*) FROM pages WHERE slug='about'"), 1)
        self.post(o, f"/staff/r/pages/{core['id']}/edit", {"title": "About Us Now", "body": "New about text"}); self.assertIn("New about text", self.app.test_client().get("/about").data.decode()); self.assertEqual(self.val("SELECT slug FROM pages WHERE id=?", (core["id"],)), "about")
        self.assertEqual(self.app.test_client().get("/p/about").status_code, 302); self.assertEqual(self.app.test_client().get("/p/nonexistent").status_code, 404)
        self.assertEqual(self.post(self.client("writer"), "/staff/r/pages/new", {"title": "X", "body": "y"}).status_code, 403)

class MessageTests(Editor):
    def test_payment_page_and_notifications_editable(self):
        o = self.client("owner")
        self.save(o, "c_messages", **{"c__pay.bank_title": "Transfer to our account", "c__pay.pending_text": "Relax, we are checking.", "c__notif.approved_title": "You're in!", "c__notif.approved_body": "{item} is unlocked.", "c__notif.rejected_body": "We could not confirm: {reason}"})
        a = self.client("alice"); ref = self.buy(a, "course", "paid-maths", submit=False); self.assertIn("Transfer to our account", a.get(f"/pay/{ref}").data.decode())
        self.upload(a, ref); self.assertIn("Relax, we are checking.", a.get(f"/pay/{ref}").data.decode())
        t = self.tx(ref); self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        n = dbm.q1("SELECT * FROM notifications WHERE user_id=? AND kind='payment' ORDER BY id DESC", (self.users["alice"],)); self.assertEqual((n["title"], n["body"]), ("You're in!", "Paid Maths is unlocked."))
        ref2 = self.buy(self.client("bob"), "course", "marketing", who="bob"); t2 = self.tx(ref2)
        self.post(self.client("officer"), f"/staff/payments/{t2['id']}", {"action": "reject", "confirm": "1", "text": "no funds"}); self.assertEqual(self.val("SELECT body FROM notifications WHERE user_id=? AND title='Payment not approved'", (self.users["bob"],)), "We could not confirm: no funds")
