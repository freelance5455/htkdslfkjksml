import sqlite3, tempfile, shutil, os
from .base import *
from dagba.services import access
from .test_academic import AcademicBase, cat

class PricingBase(AcademicBase):
    def setUp(self):
        super().setUp()
        self.adv_plan = self.val("SELECT id FROM plans WHERE level='advanced'")
        dbm.ex("UPDATE plans SET price_kobo=2500000, active=1 WHERE id=?", (self.adv_plan,)); dbm.ex("UPDATE plans SET level='basic' WHERE id=?", (self.plan_a,))
        self.phys = cat("academic-physics"); self.chem = cat("academic-chemistry")
        dbm.ex("UPDATE categories SET price_kobo=800000 WHERE id=?", (self.phys,))
    def c(self, cid): return dbm.q1("SELECT * FROM courses WHERE id=?", (cid,))
    def acc(self, who, cid): return access.course_access(self.users[who], self.c(cid))
    def approve_path(self, who, path):
        c = self.client(who); r = self.post(c, path, {"action": "pay"}); self.assertEqual(r.status_code, 302, r.data[:200])
        ref = r.headers["Location"].rsplit("/", 1)[-1]; self.assertEqual(self.upload(c, ref).status_code, 302)
        self.post(self.client("officer"), f"/staff/payments/{self.tx(ref)['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}); return ref

class SubjectTests(PricingBase):
    def test_subject_purchase_unlocks_all_its_courses_only(self):
        a = self.make("Phys 1", "basic", "academic-physics"); b = self.make("Phys 2", "basic", "academic-physics"); o = self.make("Chem 1", "basic", "academic-chemistry", price="500")
        self.assertIsNone(self.acc("alice", a)); self.approve_path("alice", f"/checkout/subject/{self.phys}")
        self.assertEqual(self.acc("alice", a), "purchased"); self.assertEqual(self.acc("alice", b), "purchased"); self.assertIsNone(self.acc("alice", o))
        self.assertEqual(self.client("alice").get("/learn/" + self.val("SELECT slug FROM courses WHERE id=?", (a,))).status_code, 200)
        self.assertIsNone(self.acc("bob", a))
        self.assertEqual(self.val("SELECT amount_kobo FROM transactions WHERE item_type='subject'"), 800000)
    def test_course_in_priced_subject_is_sold_via_subject(self):
        a = self.make("Phys 1", "basic", "academic-physics", price="0"); self.assertIsNone(self.acc("alice", a))        # not free even with course price 0
        slug = self.val("SELECT slug FROM courses WHERE id=?", (a,)); r = self.post(self.client("alice"), f"/checkout/course/{slug}"); self.assertIn(f"/checkout/subject/{self.phys}", r.headers["Location"])
        self.assertIn("8,000", self.client("alice").get(f"/courses/{slug}").data.decode().replace("₦", ""))
        self.assertIn("Buy Physics", self.client("alice").get("/academic/basic/physics").data.decode())
    def test_unpriced_subject_keeps_legacy_course_price(self):
        a = self.make("Chem 1", "basic", "academic-chemistry", price="500"); self.assertIsNone(self.acc("alice", a)); self.approve_path("alice", "/checkout/course/" + self.val("SELECT slug FROM courses WHERE id=?", (a,)))
        self.assertEqual(self.acc("alice", a), "purchased")
    def test_subject_refund_revokes_and_duplicate_blocked(self):
        a = self.make("Phys 1", "basic", "academic-physics"); ref = self.approve_path("alice", f"/checkout/subject/{self.phys}")
        r = self.post(self.client("alice"), f"/checkout/subject/{self.phys}", {"action": "pay"}); self.assertEqual(self.val("SELECT COUNT(*) FROM transactions WHERE item_type='subject'"), 1)
        self.post(self.client("owner"), f"/staff/payments/{self.tx(ref)['id']}/refund", {"reason": "test", "confirm": "1"}); 
        from dagba.services import payments as P
        if self.acc("alice", a): P.refund(self.tx(ref)["id"], dbm.q1("SELECT * FROM users WHERE id=?", (self.users["owner"],)), "test")
        self.assertIsNone(self.acc("alice", a))
    def test_advanced_subjects_can_now_be_bought_and_priced(self):
        adv = cat("advanced-physics"); a = self.make("Adv Phys 1", "advanced", "advanced-physics", price="0")
        self.assertEqual(self.post(self.client("alice"), f"/checkout/subject/{adv}", {"action": "pay"}).status_code, 302)       # a subject without a price cannot be paid for
        self.assertEqual(self.val("SELECT COUNT(*) FROM transactions WHERE item_type='subject'"), 0)
        o = self.client("owner"); self.post(o, f"/staff/r/categories/{adv}/edit", {"division": "academic", "level": "advanced", "name": "Physics", "price_kobo": "5000", "active": "1", "access_policy": "lifetime"})
        self.assertEqual(self.val("SELECT price_kobo FROM categories WHERE id=?", (adv,)), 500000)
        self.approve_path("alice", f"/checkout/subject/{adv}"); self.assertEqual(self.acc("alice", a), "purchased"); self.assertEqual(self.val("SELECT amount_kobo FROM transactions WHERE item_type='subject'"), 500000)
    def test_income_categories_cannot_be_bought_or_priced(self):
        inc = self.val("SELECT id FROM categories WHERE division='income' LIMIT 1"); r = self.post(self.client("alice"), f"/checkout/subject/{inc}", {"action": "pay"}); self.assertEqual(r.status_code, 404)
        o = self.client("owner"); self.post(o, f"/staff/r/categories/{inc}/edit", {"division": "income", "name": "Whatever", "price_kobo": "5000", "active": "1", "access_policy": "lifetime"})
        self.assertEqual(self.val("SELECT price_kobo FROM categories WHERE id=?", (inc,)), 0)

class SectionSeparationTests(PricingBase):
    def setUp(self):
        super().setUp()
        self.b = self.make("Phys 1", "basic", "academic-physics", price="0", subscription_eligible=True)
        self.a = self.make("Law 1", "advanced", "advanced-law", price="3000", subscription_eligible=True)
        self.p = self.make("ICAN Prep", "professional", None, price="4000", subscription_eligible=True)
    def test_professional_is_never_subscription_eligible(self):
        self.assertEqual(self.val("SELECT subscription_eligible FROM courses WHERE id=?", (self.p,)), 0)
        self.assertEqual(self.val("SELECT COUNT(*) FROM plans WHERE level IS NULL AND division='academic' AND id!=?", (self.plan_a,)), 0)
    def test_basic_and_advanced_subscriptions_are_independent(self):
        self.approve_path("alice", f"/checkout/plan/{self.plan_a}")
        self.assertEqual(self.acc("alice", self.b), "subscription"); self.assertIsNone(self.acc("alice", self.a)); self.assertIsNone(self.acc("alice", self.p))
        self.approve_path("bob", f"/checkout/plan/{self.adv_plan}")
        self.assertEqual(self.acc("bob", self.a), "subscription"); self.assertIsNone(self.acc("bob", self.b)); self.assertIsNone(self.acc("bob", self.p))
        dbm.ex("UPDATE entitlements SET expires_at='2000-01-01 00:00:00' WHERE kind='subscription' AND level='basic'")
        self.approve_path("alice", f"/checkout/plan/{self.adv_plan}"); self.assertIsNone(self.acc("alice", self.b)); self.assertEqual(self.acc("alice", self.a), "subscription")
        self.assertEqual(self.acc("bob", self.a), "subscription")
    def test_advanced_and_professional_courses_sold_individually(self):
        self.approve_path("alice", "/checkout/course/" + self.val("SELECT slug FROM courses WHERE id=?", (self.a,)))
        self.assertEqual(self.acc("alice", self.a), "purchased"); self.assertIsNone(self.acc("alice", self.p)); self.assertIsNone(self.acc("alice", self.b))
        self.approve_path("alice", "/checkout/course/" + self.val("SELECT slug FROM courses WHERE id=?", (self.p,))); self.assertEqual(self.acc("alice", self.p), "purchased")
        self.assertEqual(self.val("SELECT amount_kobo FROM transactions WHERE course_id=?", (self.p,)), 400000)
    def test_subject_purchase_does_not_unlock_advanced_or_professional(self):
        self.approve_path("alice", f"/checkout/subject/{self.phys}"); self.assertEqual(self.acc("alice", self.b), "purchased"); self.assertIsNone(self.acc("alice", self.a)); self.assertIsNone(self.acc("alice", self.p))
    def test_pages_and_dashboard(self):
        self.approve_path("alice", f"/checkout/subject/{self.phys}"); c = self.client("alice")
        for u in ("/student", "/student/courses", "/student/payments", "/pricing", "/academic/basic/physics", "/professional"): self.assertEqual(c.get(u).status_code, 200, u)
        h = self.app.test_client().get("/pricing").data.decode(); self.assertIn("Acad Sub", h); self.assertIn("Advanced Subscription", h); self.assertIn("ICAN Prep", h); self.assertIn("Law 1", h); self.assertIn("Physics", h)
        self.assertIn("Physics", c.get("/student/courses").data.decode())

class AdminPricingTests(PricingBase):
    def test_admin_screen_sets_all_prices(self):
        a = self.make("Law 1", "advanced", "advanced-law", price="3000"); p = self.make("ICAN Prep", "professional", None, price="4000"); o = self.client("owner")
        self.assertEqual(o.get("/staff/pricing").status_code, 200)
        self.post(o, "/staff/pricing", {"kind": "subject", "id": self.chem, "price": "9,500"}); self.assertEqual(self.val("SELECT price_kobo FROM categories WHERE id=?", (self.chem,)), 950000)
        self.post(o, "/staff/pricing", {"kind": "course", "id": a, "price": "12000"}); self.assertEqual(self.val("SELECT price_kobo FROM courses WHERE id=?", (a,)), 1200000)
        self.post(o, "/staff/pricing", {"kind": "course", "id": p, "price": "15000"}); self.assertEqual(self.val("SELECT price_kobo FROM courses WHERE id=?", (p,)), 1500000)
        self.post(o, "/staff/pricing", {"kind": "plan", "id": self.adv_plan, "price": "7000", "days": "90", "active": "1"}); self.assertEqual(self.row("SELECT price_kobo,duration_days FROM plans WHERE id=?", (self.adv_plan,))["duration_days"], 90)
        self.post(o, "/staff/pricing", {"kind": "plan", "id": self.adv_plan, "price": "0", "days": "30", "active": "1"}); self.assertEqual(self.val("SELECT price_kobo FROM plans WHERE id=?", (self.adv_plan,)), 700000)       # cannot activate unpriced plan
        self.post(o, "/staff/pricing", {"kind": "subject", "id": self.chem, "price": "abc"}); self.assertEqual(self.val("SELECT price_kobo FROM categories WHERE id=?", (self.chem,)), 950000)
        self.assertGreaterEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action LIKE 'price.%'"), 4)
    def test_only_pricing_managers_reach_screen(self):
        for who in ("alice", "inst"): self.assertIn(self.client(who).get("/staff/pricing").status_code, (302, 403))
    def test_plan_form_requires_basic_or_advanced(self):
        o = self.client("owner"); self.post(o, "/staff/r/plans/new", {"name": "Pro Sub", "division": "academic", "level": "", "price": "", "price_kobo": "1000", "duration_days": "30"}); self.assertEqual(self.val("SELECT COUNT(*) FROM plans WHERE name='Pro Sub'"), 0)
        self.post(o, "/staff/r/plans/new", {"name": "Adv 2", "division": "academic", "level": "advanced", "price_kobo": "1000", "duration_days": "30"}); self.assertEqual(self.val("SELECT level FROM plans WHERE name='Adv 2'"), "advanced")

class PricingUpgradeTests(Base):
    def test_upgrade_keeps_payments_and_subscriptions(self):
        d = tempfile.mkdtemp(); old = os.path.join(d, "mig"); os.makedirs(old)
        for f in sorted(os.listdir(MIG)):
            if f < "010": shutil.copy(os.path.join(MIG, f), old)
        path = os.path.join(d, "o.db"); dbm.migrate(path, old); c = sqlite3.connect(path)
        c.execute("INSERT INTO users(id,email,password_hash,full_name) VALUES (1,'a@b.c','x','A')")
        c.execute("INSERT INTO plans(id,name,division,price_kobo,duration_days,active) VALUES (50,'Academic Subscription','academic',100000,30,1)")
        c.execute("INSERT INTO courses(id,division,title,slug,price_kobo,status) VALUES (7,'academic','C','c',500000,'published')")
        c.execute("INSERT INTO transactions(id,reference,user_id,item_type,plan_id,item_title,division,list_price_kobo,amount_kobo,status) VALUES (9,'R9',1,'plan',50,'Academic Subscription','academic',100000,100000,'approved')")
        c.execute("INSERT INTO transactions(id,reference,user_id,item_type,course_id,item_title,list_price_kobo,amount_kobo,status) VALUES (10,'R10',1,'course',7,'C',500000,500000,'approved')")
        c.execute("INSERT INTO entitlements(user_id,kind,plan_id,division,starts_at,expires_at,transaction_id) VALUES (1,'subscription',50,'academic','2026-01-01 00:00:00','2099-01-01 00:00:00',9)")
        c.execute("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at,transaction_id) VALUES (1,'course',7,'academic','2026-01-01 00:00:00',10)"); c.commit(); c.close()
        self.assertEqual(dbm.migrate(path, MIG), ["010_pricing_structure.sql", "011_basic_category_featured.sql", "012_basic_category_image.sql", "013_faith_topic_visuals.sql", "014_faith_tutor_topics.sql", "015_hero_slides.sql", "016_tutor_program.sql", "017_professional_division.sql", "018_professional_navigation.sql", "019_subject_pricing_all_divisions.sql", "020_division_separation.sql", "021_tutor_mou.sql", "022_prelaunch.sql", "023_learning_objectives.sql", "024_interactive_learning.sql", "025_mobile_api.sql", "026_store_billing.sql"]); c = sqlite3.connect(path)
        self.assertEqual(c.execute("SELECT name,level FROM plans WHERE id=50").fetchone(), ("Basic Subscription", "basic")); self.assertEqual(c.execute("SELECT COUNT(*) FROM plans WHERE level='advanced' AND active=0").fetchone()[0], 1)
        self.assertEqual(c.execute("SELECT kind,level,transaction_id FROM entitlements ORDER BY id").fetchall(), [("subscription", "basic", 9), ("course", None, 10)])
        self.assertEqual(c.execute("SELECT COUNT(*),SUM(amount_kobo) FROM transactions").fetchone(), (2, 600000)); self.assertEqual(c.execute("PRAGMA foreign_key_check").fetchall(), [])
        c.close(); shutil.rmtree(d, ignore_errors=True)
