"""Subject-level pricing for Basic, Advanced and Professional Development (Income Skills keeps course pricing)."""
import io, os, shutil, sqlite3, tempfile
from .base import *
from dagba.services import access, academic as A
from .test_pricing import PricingBase

class SubjectPricingBase(PricingBase):
    def setUp(self):
        super().setUp()
        ex = dbm.ex
        self.adv = ex("INSERT INTO categories(division,level,name,slug,price_kobo,featured,active) VALUES ('academic','advanced','Jurisprudence','t-adv-jur',300000,1,1)")
        self.pro = ex("INSERT INTO categories(division,name,slug,price_kobo,featured,active) VALUES ('professional','Taxation Exams','t-pro-tax',450000,1,1)")
        self.pro2 = ex("INSERT INTO categories(division,name,slug,price_kobo,featured,active) VALUES ('professional','Audit Exams','t-pro-aud',200000,1,1)")
        dbm.ex("UPDATE categories SET name='English JSS1', featured=1 WHERE id=?", (self.phys,))
        self.b1 = self.make("Grammar", "basic", "academic-physics"); self.a1 = self.make("Torts", "advanced", "t-adv-jur"); self.a2 = self.make("Contracts", "advanced", "t-adv-jur")
        self.p1 = self.course("Tax Law", "professional", self.pro); self.p2 = self.course("Tax Practice", "professional", self.pro); self.pdraft = self.course("Tax Draft", "professional", self.pro, "draft")
        self.p_other = self.course("Audit 1", "professional", self.pro2)
        self.i1 = self.course("Freelancing", "income", None, price=700000)
        self.o = self.client("owner"); self.pub = self.app.test_client()
    def make(self, title, level, subject_slug=None, **kw):
        if subject_slug and subject_slug.startswith("t-"): kw.setdefault("price", "0")
        return super().make(title, level, subject_slug, **kw)
    def course(self, title, div, cat, status="published", price=0):
        return dbm.ex("INSERT INTO courses(division,category_id,title,slug,price_kobo,status) VALUES (?,?,?,?,?,?)", (div, cat, title, title.lower().replace(" ", "-"), price, status))
    def home(self): return self.pub.get("/").data.decode()
    def sec(self, h, sid):
        import re; m = re.search(r'<section class="block[^"]*" id="%s">(.*?)</section>' % sid, h, re.S); return m.group(1) if m else ""
    def subs(self, who): return access.subscription_status(self.users[who])

class AdminTests(SubjectPricingBase):
    def form(self, rid=None, image=None, **kw):
        d = {"_csrf": self.tok(self.o), "access_policy": "lifetime", "active": "1"}; d.update(kw)
        if image: d["image"] = (io.BytesIO(image), "c.png")
        return self.o.post(f"/staff/r/categories/{rid}/edit" if rid else "/staff/r/categories/new", data=d, content_type="multipart/form-data")
    def test_create_edit_price_image_feature_all_three_divisions(self):
        specs = [("Basic", dict(division="academic", level="basic")), ("Advanced", dict(division="academic", level="advanced")), ("Professional", dict(division="professional", level=""))]
        for label, base in specs:
            name = f"New {label} Subject"
            r = self.form(name=name, description="About it", price_kobo="1234.50", featured="1", image=png_bytes(), **base); self.assertEqual(r.status_code, 302, label)
            row = dbm.q1("SELECT * FROM categories WHERE name=?", (name,))
            self.assertEqual((row["price_kobo"], row["featured"], row["active"], row["description"]), (123450, 1, 1, "About it")); self.assertTrue(row["image"])
            self.assertEqual(self.form(row["id"], name=name, price_kobo="999", featured="", active="", **base).status_code, 302)         # edit and save a new price, unfeature, deactivate
            row = dbm.q1("SELECT * FROM categories WHERE id=?", (row["id"],)); self.assertEqual((row["price_kobo"], row["featured"], row["active"]), (99900, 0, 0)); self.assertTrue(row["image"])
    def test_existing_unpriced_subjects_can_still_be_edited(self):
        for cid, base in ((self.adv, dict(division="academic", level="advanced")), (self.pro, dict(division="professional", level=""))):
            self.assertEqual(self.form(cid, name=dbm.val("SELECT name FROM categories WHERE id=?", (cid,)), price_kobo="0", **base).status_code, 302)
    def test_prices_screen_saves_every_division(self):
        self.assertEqual(self.o.get("/staff/pricing").status_code, 200)
        for cid, naira_ in ((self.phys, "111"), (self.adv, "222"), (self.pro, "333")):
            r = self.post(self.o, "/staff/pricing", {"kind": "subject", "id": str(cid), "price": naira_}); self.assertEqual(r.status_code, 302)
            self.assertEqual(self.val("SELECT price_kobo FROM categories WHERE id=?", (cid,)), int(naira_) * 100)
        inc = self.val("SELECT id FROM categories WHERE division='income' LIMIT 1"); self.assertEqual(self.post(self.o, "/staff/pricing", {"kind": "subject", "id": str(inc), "price": "5"}).status_code, 404)
    def test_assign_courses_page_for_each_division(self):
        for cid in (self.phys, self.adv, self.pro):
            self.assertEqual(self.o.get(f"/staff/academic/category/{cid}").status_code, 200)
        self.assertEqual(self.post(self.o, f"/staff/academic/category/{self.pro}", {"course": [str(self.p1), str(self.p_other)]}).status_code, 302)
        self.assertEqual(self.val("SELECT category_id FROM courses WHERE id=?", (self.p_other,)), self.pro); self.assertIsNone(self.val("SELECT category_id FROM courses WHERE id=?", (self.p2,)))
        self.assertEqual(self.o.get("/staff/academic").status_code, 200)

class HomepageTests(SubjectPricingBase):
    def test_cards_for_three_divisions_with_price_and_image_once(self):
        dbm.ex("UPDATE categories SET image='x.png' WHERE id=?", (self.pro,)); h = self.home()
        for sid, name, price in (("basic", "English JSS1", "8,000"), ("advanced", "Jurisprudence", "3,000"), ("professional", "Taxation Exams", "4,500")):
            s = self.sec(h, sid); self.assertEqual(s.count(f"<h3>{name}</h3>"), 1, sid); self.assertIn(price, s)
        self.assertIn("/media/x.png", self.sec(h, "professional"))
        self.assertLess(h.index('id="basic"'), h.index('id="advanced"')); self.assertLess(h.index('id="advanced"'), h.index('id="professional"'))
        for t in ("Tax Law", "Tax Practice", "Grammar", "Torts"): self.assertNotIn(t, h.split('id="income"')[0].split('id="basic"')[1])
        self.assertIn("Freelancing", self.sec(h, "income"))
    def test_only_active_featured_subjects_with_published_courses(self):
        dbm.ex("UPDATE categories SET active=0 WHERE id=?", (self.pro2,)); dbm.ex("UPDATE categories SET featured=0 WHERE id=?", (self.pro,))
        s = self.sec(self.home(), "professional"); self.assertEqual(s, "")      # one inactive, one not featured
        dbm.ex("UPDATE categories SET featured=1 WHERE id=?", (self.pro,)); dbm.ex("UPDATE courses SET status='draft' WHERE category_id=?", (self.pro,)); self.assertEqual(self.sec(self.home(), "professional"), "")
    def test_saved_price_change_shows_immediately(self):
        self.post(self.o, "/staff/pricing", {"kind": "subject", "id": str(self.pro), "price": "9999"}); self.assertIn("9,999", self.sec(self.home(), "professional"))

class PurchaseTests(SubjectPricingBase):
    def test_each_division_subject_unlocks_all_published_courses_only(self):
        for who, sid, got, not_got in (("alice", self.phys, [self.b1], [self.a1, self.p1]), ("bob", self.adv, [self.a1, self.a2], [self.b1, self.p1]), ("alice", self.pro, [self.p1, self.p2], [self.p_other, self.a1])):
            self.approve_path(who, f"/checkout/subject/{sid}")
            for c in got: self.assertEqual(self.acc(who, c), "purchased")
            for c in not_got: self.assertIsNone(self.acc(who, c))
        self.assertIsNone(self.acc("alice", self.pdraft))                     # unpublished never unlocked
        dbm.ex("UPDATE courses SET status='published' WHERE id=?", (self.pdraft,)); self.assertEqual(self.acc("alice", self.pdraft), "purchased")      # courses added later are covered
        late = self.course("Tax Late", "professional", self.pro); self.assertEqual(self.acc("alice", late), "purchased")
        self.assertEqual(self.client("alice").get("/learn/tax-law").status_code, 200); self.assertIsNone(self.acc("bob", self.p1))
    def test_checkout_uses_saved_price_and_entitlement_records_scope(self):
        self.post(self.o, "/staff/pricing", {"kind": "subject", "id": str(self.pro), "price": "5000"})
        self.approve_path("alice", f"/checkout/subject/{self.pro}")
        self.assertEqual(self.val("SELECT amount_kobo FROM transactions WHERE item_type='subject'"), 500000)
        self.assertEqual(tuple(self.row("SELECT division, level, category_id FROM entitlements WHERE kind='subject'")), ("professional", "professional", self.pro))
        self.post(self.o, "/staff/pricing", {"kind": "subject", "id": str(self.pro), "price": "1"}); self.assertEqual(self.val("SELECT amount_kobo FROM transactions WHERE item_type='subject'"), 500000)   # old payment unchanged
    def test_course_checkout_redirects_to_its_subject_and_page_shows_price(self):
        for slug, sid in (("torts", self.adv), ("tax-law", self.pro)):
            r = self.post(self.client("alice"), f"/checkout/course/{slug}", {"action": "pay"}); self.assertIn(f"/checkout/subject/{sid}", r.headers["Location"])
        self.assertIn("4,500", self.client("alice").get("/courses/tax-law").data.decode())
    def test_cannot_buy_same_subject_twice_and_pages_show_owned(self):
        for sid in (self.adv, self.pro):
            self.approve_path("alice", f"/checkout/subject/{sid}"); self.post(self.client("alice"), f"/checkout/subject/{sid}", {"action": "pay"})
        self.assertEqual(self.val("SELECT COUNT(*) FROM transactions WHERE item_type='subject'"), 2)
        self.assertIn("You own this subject", self.client("alice").get("/professional/taxation-exams").data.decode()); self.assertIn("You own this subject", self.client("alice").get("/academic/advanced/jurisprudence").data.decode())
    def test_open_request_reused_and_rejected_payment_grants_nothing(self):
        c = self.client("alice"); r1 = self.post(c, f"/checkout/subject/{self.pro}", {"action": "pay"}); r2 = self.post(c, f"/checkout/subject/{self.pro}", {"action": "pay"}); self.assertEqual(r1.headers["Location"], r2.headers["Location"])
        ref = r1.headers["Location"].rsplit("/", 1)[-1]; self.upload(c, ref); self.post(self.client("officer"), f"/staff/payments/{self.tx(ref)['id']}", {"action": "reject", "reason": "no funds", "confirm": "1"}); self.assertIsNone(self.acc("alice", self.p1))
    def test_refund_revokes_subject_access(self):
        ref = self.approve_path("alice", f"/checkout/subject/{self.adv}"); from dagba.services import payments as P
        P.refund(self.tx(ref)["id"], dbm.q1("SELECT * FROM users WHERE id=?", (self.users["owner"],)), "test"); self.assertIsNone(self.acc("alice", self.a1))
    def test_inactive_or_unpriced_subject_cannot_be_bought_but_owners_keep_access(self):
        self.approve_path("alice", f"/checkout/subject/{self.pro}"); dbm.ex("UPDATE categories SET active=0 WHERE id=?", (self.pro,))
        self.assertEqual(self.acc("alice", self.p1), "purchased"); self.assertEqual(self.post(self.client("bob"), f"/checkout/subject/{self.pro}", {"action": "pay"}).status_code, 302)
        self.assertEqual(self.val("SELECT COUNT(*) FROM transactions WHERE user_id=?", (self.users["bob"],)), 0)
    def test_legacy_individual_purchase_stays_valid_after_subject_is_priced(self):
        c = self.course("Old Pro", "professional", None, price=100000); self.approve_path("alice", "/checkout/course/old-pro")
        dbm.ex("UPDATE courses SET category_id=? WHERE id=?", (self.pro, c)); self.assertEqual(self.acc("alice", c), "purchased")
        ent = self.course("Taxless", "professional", self.pro2); dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at) VALUES (?,?,?,?,?)", (self.users["alice"], "course", ent, "professional", "2026-01-01 00:00:00")); self.assertEqual(self.acc("alice", ent), "purchased")
    def test_income_skills_course_purchase_unchanged(self):
        self.assertIsNone(self.acc("alice", self.i1)); self.approve_path("alice", "/checkout/course/freelancing"); self.assertEqual(self.acc("alice", self.i1), "purchased")
        self.assertEqual(self.val("SELECT amount_kobo FROM transactions WHERE item_type='course'"), 700000); self.assertIsNone(self.acc("bob", self.i1))

class SubscriptionSeparationTests(SubjectPricingBase):
    def test_subscriptions_stay_independent(self):
        self.approve_path("alice", f"/checkout/plan/{self.plan_a}")                                   # Basic subscription
        self.assertEqual(self.acc("alice", self.b1), "subscription"); self.assertIsNone(self.acc("alice", self.a1)); self.assertIsNone(self.acc("alice", self.p1))
        dbm.ex("UPDATE courses SET subscription_eligible=1 WHERE id IN (?,?,?)", (self.a1, self.p1, self.i1))      # eligibility flag never makes Professional Development subscribable
        self.approve_path("bob", f"/checkout/plan/{self.adv_plan}")                                   # Advanced subscription
        self.assertEqual(self.acc("bob", self.a1), "subscription"); self.assertIsNone(self.acc("bob", self.b1)); self.assertIsNone(self.acc("bob", self.p1))
        self.approve_path("alice", f"/checkout/plan/{self.plan_i}"); self.assertEqual(self.acc("alice", self.i1), "subscription"); self.assertIsNone(self.acc("alice", self.p1)); self.assertIsNone(self.acc("alice", self.a1))
    def test_subject_purchases_never_create_subscription_access(self):
        for sid in (self.pro, self.adv, self.phys): self.approve_path("alice", f"/checkout/subject/{sid}")
        self.assertEqual(self.subs("alice"), {"basic": None, "advanced": None, "income": None})
        self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements WHERE kind='subscription'"), 0)
        self.assertIsNone(self.acc("alice", self.i1)); self.assertIsNone(self.acc("alice", self.p_other))
    def test_pro_subject_owner_does_not_get_other_pro_or_subscription_courses(self):
        self.approve_path("alice", f"/checkout/subject/{self.pro}"); self.assertIsNone(self.acc("alice", self.p_other))

class PublicPagesTests(SubjectPricingBase):
    def test_pages_render_for_all_divisions(self):
        self.approve_path("alice", f"/checkout/subject/{self.pro}"); self.approve_path("alice", f"/checkout/subject/{self.adv}")
        c = self.client("alice")
        for u in ("/", "/pricing", "/professional", "/professional/taxation-exams", "/professional/other", "/academic/advanced", "/academic/advanced/jurisprudence", "/academic/professional/taxation-exams",
                  "/student", "/student/courses", "/student/courses?path=professional", "/student/courses?path=advanced", "/student/payments", "/sitemap.xml", "/courses", "/courses/tax-law"):
            self.assertIn(c.get(u).status_code, (200, 301), u)
        h = c.get("/student/courses").data.decode(); self.assertIn("Taxation Exams", h); self.assertIn("Jurisprudence", h)
        self.assertIn("/professional/taxation-exams", c.get("/sitemap.xml").data.decode())
        p = self.pub.get("/pricing").data.decode(); self.assertIn("Taxation Exams", p); self.assertIn("4,500", p); self.assertIn("Jurisprudence", p)
        self.assertEqual(self.pub.get("/professional/nonexistent").status_code, 404)
        self.assertIn("Tax Law", self.pub.get("/professional/taxation-exams").data.decode()); self.assertNotIn("Audit 1", self.pub.get("/professional/taxation-exams").data.decode())
    def test_lessons_visible_only_when_unlocked(self):
        m = dbm.ex("INSERT INTO modules(course_id,title,position) VALUES (?,?,1)", (self.p1, "Topic X")); dbm.ex("INSERT INTO lessons(course_id,module_id,title,kind,position) VALUES (?,?,?,?,1)", (self.p1, m, "Lesson Z", "text"))
        self.assertNotIn('/lesson', self.pub.get("/professional/taxation-exams").data.decode().split("Lesson Z")[0][-80:]); self.approve_path("alice", f"/checkout/subject/{self.pro}")
        h = self.client("alice").get("/professional/taxation-exams").data.decode(); self.assertIn("Topic X", h); self.assertIn("Lesson Z</a>", h)

class MigrationTests(Base):
    def test_019_keeps_data_and_features_professional_subjects(self):
        d = tempfile.mkdtemp(); old = os.path.join(d, "mig"); os.makedirs(old)
        for f in sorted(os.listdir(MIG)):
            if f < "019": shutil.copy(os.path.join(MIG, f), old)
        path = os.path.join(d, "o.db"); dbm.migrate(path, old); c = sqlite3.connect(path)
        c.execute("INSERT INTO users(id,email,password_hash,full_name) VALUES (1,'a@b.c','x','A')")
        c.execute("INSERT INTO categories(id,division,level,name,slug,price_kobo,active) VALUES (900,'academic','basic','Old Basic','ob',100000,1)")
        c.execute("INSERT INTO categories(id,division,name,slug,active) VALUES (901,'professional','Old Pro','op',1)")
        c.execute("INSERT INTO entitlements(id,user_id,kind,category_id,starts_at) VALUES (5,1,'subject',900,'2026-01-01 00:00:00')"); c.commit(); c.close()
        self.assertEqual(dbm.migrate(path, MIG), ["019_subject_pricing_all_divisions.sql", "020_division_separation.sql", "021_tutor_mou.sql", "022_prelaunch.sql", "023_learning_objectives.sql", "024_interactive_learning.sql", "025_mobile_api.sql", "026_store_billing.sql"]); c = sqlite3.connect(path)
        self.assertEqual(c.execute("SELECT division,level,category_id FROM entitlements WHERE id=5").fetchone(), ("academic", "basic", 900))
        self.assertEqual(c.execute("SELECT price_kobo FROM categories WHERE id=900").fetchone()[0], 100000); self.assertEqual(c.execute("SELECT featured FROM categories WHERE id=901").fetchone()[0], 1)
        self.assertEqual(c.execute("PRAGMA foreign_key_check").fetchall(), []); self.assertEqual(dbm.migrate(path, MIG), []); c.close(); shutil.rmtree(d, ignore_errors=True)
