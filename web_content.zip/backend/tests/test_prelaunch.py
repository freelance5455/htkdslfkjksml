"""Pre-Launch Mode: server-side gate, automatic launch, admin controls, early registration."""
import re
from datetime import datetime, timedelta, timezone
from .base import *
from dagba.services import prelaunch as P, settings as S

def when(**kw): return datetime.now(timezone.utc) + timedelta(**kw)
def local_str(dt, off="+01:00"):
    h, m = int(off[1:3]), int(off[4:6]); sign = 1 if off[0] == "+" else -1
    return (dt + sign * timedelta(hours=h, minutes=m)).strftime("%Y-%m-%dT%H:%M")

class PL(Base):
    def setUp(self):
        super().setUp(); self.orig_now = P._now
        self.mk("pladmin", "admin", perms=["prelaunch.manage"])
    def tearDown(self):
        P._now = self.orig_now; super().tearDown()
    def on(self, days=30, off="+01:00", **extra):
        S.put("prelaunch.utc_offset", off); S.put("prelaunch.launch_at", local_str(when(days=days), off)); S.put("prelaunch.enabled", "1")
        for k, v in extra.items(): S.put("prelaunch." + k, v)
    def anon(self): return self.app.test_client()
    def n(self, sql, a=()): return self.val(sql, a)

PROTECTED = ["/courses", "/blog", "/pricing", "/faq", "/contact", "/academic", "/nuggets", "/testimonials", "/become-a-tutor", "/student", "/student/courses", "/account", "/sitemap.xml", "/verify", "/courses/paid-maths", "/staff/", "/learn/video/1", "/pay/ABC"]

class GateTests(PL):
    def test_off_by_default_and_site_is_open(self):
        self.assertFalse(P.restricting())
        for c in (self.anon(), self.client("alice")): self.assertEqual(c.get("/courses").status_code, 200)
        self.assertNotIn("Doors open in", self.anon().get("/").data.decode())

    def test_public_and_students_only_see_the_countdown(self):
        self.on()
        for who in (None, "alice", "bob"):
            c = self.anon() if who is None else self.client(who)
            r = c.get("/"); self.assertEqual(r.status_code, 200); h = r.data.decode()
            for s in ("We are launching soon", "Doors open in", 'data-u="d"', 'data-u="s"', "Dagba Digital Academy"): self.assertIn(s, h)
            if who is None: self.assertIn("Get early access", h)
            self.assertNotIn("Browse courses", h); self.assertIn("no-store", r.headers["Cache-Control"])
            for p in PROTECTED:
                r = c.get(p); self.assertEqual(r.status_code, 302, (who, p)); self.assertEqual(r.headers["Location"], "/", (who, p))
            self.assertEqual(c.get("/", method="HEAD").status_code, 200)
        a = self.client("alice")                                                                  # content is protected even with a real purchase/entitlement
        dbm.ex("INSERT INTO entitlements(user_id,course_id,source) VALUES (?,?,?)", (self.users["alice"], self.paid, "purchase")) if self.n("SELECT COUNT(*) FROM pragma_table_info('entitlements') WHERE name='source'") else None
        lid = self.n("SELECT id FROM lessons WHERE course_id=? LIMIT 1", (self.paid,)); self.assertEqual(a.get(f"/learn/lesson/{lid}").status_code, 302); self.assertEqual(a.get(f"/learn/{self.paid}").status_code, 302)

    def test_non_page_requests_are_refused(self):
        self.on()
        c = self.client("alice"); tok = self.tok(c)
        r = c.post("/newsletter", data={"email": "a@b.co", "_csrf": tok}); self.assertEqual(r.status_code, 403); self.assertFalse(r.get_json()["ok"])
        self.assertEqual(self.n("SELECT COUNT(*) FROM newsletter_subscribers"), 0)
        r = c.get("/courses", headers={"X-Requested-With": "fetch"}); self.assertEqual(r.status_code, 403)
        r = c.post("/account", data={"_csrf": tok}); self.assertEqual(r.status_code, 403)

    def test_admin_and_instructor_have_full_access(self):
        self.on()
        for who in ("owner", "noperm", "inst"):
            c = self.client(who); self.assertEqual(c.get("/courses").status_code, 200, who); self.assertIn("Pre-Launch Mode is ON", c.get("/courses").data.decode(), who)
            self.assertNotIn("Doors open in", c.get("/").data.decode(), who)
        self.assertEqual(self.client("inst").get("/staff/").status_code, 200)
        self.assertEqual(self.client("owner").get("/staff/").status_code, 200)

    def test_writers_and_bypass_roles_are_configurable(self):
        self.on(); w = self.client("writer"); self.assertEqual(w.get("/courses").status_code, 302)
        S.put("prelaunch.bypass_roles", "instructor,writer"); self.assertEqual(w.get("/courses").status_code, 200)
        S.put("prelaunch.bypass_roles", ""); self.assertEqual(self.client("inst").get("/courses").status_code, 302); self.assertEqual(self.client("owner").get("/courses").status_code, 200)
        S.put("prelaunch.bypass_roles", "student,admin,junk"); self.assertEqual(self.client("alice").get("/courses").status_code, 302)      # a student can never be made a bypass role

    def test_allowed_paths_still_work_for_visitors(self):
        self.on(); c = self.anon()
        for p in ("/login", "/register", "/forgot-password", "/pre-launch", "/static/css/app.css", "/theme.css", "/terms-and-conditions", "/privacy-policy", "/robots.txt"): self.assertEqual(c.get(p).status_code, 200, p)
        self.assertEqual(c.get("/reset-password/badtoken").status_code, 302); self.assertEqual(c.get("/reset-password/badtoken").headers["Location"], "/forgot-password")   # reaches the real view, not the gate
        r = c.post("/webhooks/paystack", data=b"{}", content_type="application/json"); self.assertNotEqual(r.status_code, 403 if r.is_json and r.get_json().get("error", "").startswith("Dagba") else 0)
        self.assertEqual(c.get("/media/anything.png").status_code, 302)
        S.put("brand.logo", "logo.png"); self.assertNotEqual(c.get("/media/logo.png").status_code, 302)
        self.assertEqual(c.get("/media/other.png").status_code, 302)

    def test_login_works_and_students_land_on_the_countdown(self):
        self.on(); c = self.anon(); r = c.post("/login", data={"email": "alice@t.test", "password": PW, "_csrf": self.tok(c)}); self.assertEqual(r.status_code, 302)
        r = c.get(r.headers["Location"]); self.assertEqual(r.status_code, 302); self.assertEqual(r.headers["Location"], "/")
        h = c.get("/").data.decode(); self.assertIn("Thanks for registering, Alice", h); self.assertIn("Log out", h); self.assertNotIn("Get early access", h)
        c2 = self.anon(); r = c2.post("/login", data={"email": "owner@t.test", "password": PW, "_csrf": self.tok(c2)}); self.assertEqual(c2.get(r.headers["Location"]).status_code, 200)
        r = c.post("/logout", data={"_csrf": self.tok(c)}); self.assertEqual(r.status_code, 302)

class LaunchTests(PL):
    def test_opens_automatically_at_the_launch_moment(self):
        S.put("prelaunch.utc_offset", "+01:00"); S.put("prelaunch.launch_at", "2027-01-04T00:00"); S.put("prelaunch.enabled", "1")
        self.assertEqual(P.launch_at(), datetime(2027, 1, 3, 23, 0, tzinfo=timezone.utc)); self.assertIn("4 January 2027, 00:00", P.launch_label())
        P._now = lambda: datetime(2027, 1, 3, 22, 59, 59, tzinfo=timezone.utc); c = self.client("alice"); self.assertEqual(c.get("/courses").status_code, 302); self.assertTrue(P.restricting())
        P._now = lambda: datetime(2027, 1, 3, 23, 0, 0, tzinfo=timezone.utc); self.assertFalse(P.restricting()); self.assertEqual(c.get("/courses").status_code, 200)
        self.assertEqual(c.get("/student").status_code, 200); self.assertNotIn("Doors open in", self.anon().get("/").data.decode())
        self.assertEqual(S.get("prelaunch.enabled"), "1", "nothing was changed in the database: the date alone lifts the gate")

    def test_other_time_zones(self):
        self.assertEqual(P.parse_launch("2027-01-04T00:00", "-05:00"), datetime(2027, 1, 4, 5, 0, tzinfo=timezone.utc))
        self.assertEqual(P.parse_launch("2027-01-04T00:00", "+05:30"), datetime(2027, 1, 3, 18, 30, tzinfo=timezone.utc)); self.assertIsNone(P.parse_launch("nonsense"))
        S.put("prelaunch.launch_at", "garbage"); self.assertEqual(P.launch_at(), datetime(2027, 1, 3, 23, 0, tzinfo=timezone.utc), "a bad stored value falls back to the default launch")

    def test_past_launch_time_means_open_even_if_switch_is_on(self):
        self.on(days=-1); self.assertFalse(P.restricting()); self.assertEqual(self.client("alice").get("/courses").status_code, 200)
        self.assertEqual(self.anon().get("/pre-launch").status_code, 302)

    def test_admin_can_open_manually_before_the_date(self):
        self.on(); self.assertEqual(self.client("alice").get("/courses").status_code, 302)
        a = self.client("pladmin"); r = self.post(a, "/staff/prelaunch", {"action": "open_now"}); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.client("alice").get("/courses").status_code, 200); self.assertFalse(P.restricting())
        self.post(a, "/staff/prelaunch", {"action": "close_now"}); self.assertEqual(self.client("alice").get("/courses").status_code, 302)
        self.assertEqual(self.n("SELECT COUNT(*) FROM audit_logs WHERE action='prelaunch.switched'"), 2)

class AdminTests(PL):
    def form(self, **o):
        d = dict(enabled="1", launch_date="2027-01-04", launch_time="00:00", utc_offset="+01:00", show_countdown="1", signup_enabled="1", register_enabled="1", bypass="instructor",
                 badge="Opening 4 Jan", title="Big news", message="Line one\nLine two", countdown_label="Counting", live_text="Live", signup_title="Join", signup_text="Text", signup_button="Go", success_text="Thanks!",
                 account_text="Account text", account_button="Sign up now", registered_text="Hi {name}", social_title="Find us", footer="Footer line")
        d.update(o); return {k: v for k, v in d.items() if v is not None}

    def test_only_permitted_admins(self):
        for p in ("/staff/prelaunch", "/staff/prelaunch/signups", "/staff/prelaunch/signups.csv"):
            for who in ("alice", "inst", "noperm", "officer"): self.assertEqual(self.client(who).get(p).status_code, 403, (who, p))
            self.assertEqual(self.anon().get(p).status_code, 302)
            for who in ("pladmin", "owner"): self.assertEqual(self.client(who).get(p).status_code, 200, (who, p))
        self.assertEqual(self.post(self.client("noperm"), "/staff/prelaunch", self.form()).status_code, 403); self.assertFalse(P.enabled())
        self.assertEqual(self.client("pladmin").get("/pre-launch").status_code, 200); self.assertIn("Preview", self.client("pladmin").get("/pre-launch").data.decode())
        self.assertEqual(self.client("alice").get("/pre-launch").status_code, 302)
        self.assertEqual(self.client("pladmin").post("/staff/prelaunch", data={"action": "close_now"}).status_code, 400)           # CSRF

    def test_changes_apply_immediately_without_code_changes(self):
        S.put("social.facebook", "https://facebook.com/dagba")
        a = self.client("pladmin"); r = self.post(a, "/staff/prelaunch", self.form(launch_date="2030-06-15", launch_time="09:30", utc_offset="+00:00")); self.assertEqual(r.status_code, 302)
        self.assertTrue(P.restricting()); self.assertEqual(P.launch_at(), datetime(2030, 6, 15, 9, 30, tzinfo=timezone.utc))
        h = self.anon().get("/").data.decode()
        for s in ("Opening 4 Jan", "Big news", "Line one", "Line two", "Counting", "Join", "Go", "Account text", "Sign up now", "Find us", "Footer line", "15 June 2030, 09:30 (UTC+00:00)"): self.assertIn(s, h)
        self.assertIn("Hi Alice", self.client("alice").get("/").data.decode())
        page = a.get("/staff/prelaunch").data.decode(); self.assertIn("2030-06-15", page); self.assertIn("09:30", page); self.assertIn("Big news", page)
        self.assertEqual(self.n("SELECT COUNT(*) FROM audit_logs WHERE action='prelaunch.settings_saved'"), 1)
        self.post(a, "/staff/prelaunch", self.form(enabled=None)); self.assertFalse(P.restricting()); self.assertEqual(self.anon().get("/courses").status_code, 200)

    def test_toggles_for_countdown_signup_registration(self):
        a = self.client("pladmin"); self.post(a, "/staff/prelaunch", self.form(launch_date="2030-06-15", show_countdown=None, signup_enabled=None, register_enabled=None))
        h = self.anon().get("/").data.decode(); self.assertNotIn("pl-tiles", h); self.assertIn("15 June 2030", h); self.assertNotIn('name="email"', h); self.assertNotIn("Sign up now", h)
        c = self.anon(); self.assertEqual(c.get("/register").status_code, 302); r = c.post("/prelaunch/subscribe", data={"email": "x@y.co", "_csrf": self.tok(c)}); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.n("SELECT COUNT(*) FROM prelaunch_signups"), 0)

    def test_validation(self):
        a = self.client("pladmin")
        for bad in (dict(launch_date="nope"), dict(launch_time=""), dict(utc_offset="+99:00"), dict(title="x" * 300)):
            self.post(a, "/staff/prelaunch", self.form(**bad)); self.assertFalse(P.enabled(), bad); self.assertNotEqual(S.get("prelaunch.title"), "x" * 300)
        r = self.post(a, "/staff/prelaunch", self.form(launch_date="2020-01-01"), follow_redirects=True); self.assertIn("already in the past", r.data.decode())
        S.put("prelaunch.message", "<script>alert(1)</script>"); self.assertNotIn("<script>alert", self.client("pladmin").get("/pre-launch").data.decode())

class EarlyRegistrationTests(PL):
    def sub(self, c, email, **kw):
        return c.post("/prelaunch/subscribe", data=dict(email=email, _csrf=self.tok(c), **kw), follow_redirects=True)
    def test_email_signup_is_saved_once(self):
        self.on(); c = self.anon(); r = self.sub(c, "New@Example.com"); self.assertIn("You are on the list", r.data.decode())
        r = self.sub(c, "new@example.COM"); self.assertIn("You are on the list", r.data.decode()); self.assertEqual(self.n("SELECT COUNT(*) FROM prelaunch_signups"), 1)
        row = dbm.q1("SELECT * FROM prelaunch_signups"); self.assertEqual(row["email"], "new@example.com"); self.assertEqual(row["source"], "email"); self.assertIsNone(row["user_id"])
        for bad in ("", "nope", "a@b", "x" * 250 + "@a.co"): self.assertIn("valid email", self.sub(c, bad).data.decode(), bad)
        self.sub(c, "bot@example.com", website="http://spam"); self.assertEqual(self.n("SELECT COUNT(*) FROM prelaunch_signups"), 1)
        self.assertEqual(c.post("/prelaunch/subscribe", data={"email": "z@z.co"}).status_code, 400)
        with self.assertRaises(Exception): dbm.ex("INSERT INTO prelaunch_signups(email) VALUES ('NEW@example.com')")

    def test_not_accepted_when_mode_is_off(self):
        c = self.anon(); self.sub(c, "late@example.com"); self.assertEqual(self.n("SELECT COUNT(*) FROM prelaunch_signups"), 0)

    def test_rate_limit(self):
        self.rate = True; self.tearDown(); self.setUp(); self.on(); c = self.anon()
        for i in range(14): self.sub(c, f"u{i}@example.com")
        self.assertLess(self.n("SELECT COUNT(*) FROM prelaunch_signups"), 14)

    def test_creating_an_account_before_launch(self):
        self.on(); S.put("prelaunch.signup_enabled", "1"); c = self.anon(); self.sub(c, "eager@example.com")
        r = c.post("/register", data={"full_name": "Eager Beaver", "email": "Eager@Example.com", "password": "Sup3rSecret9", "password2": "Sup3rSecret9", "_csrf": self.tok(c)}); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.n("SELECT COUNT(*) FROM prelaunch_signups"), 1, "the earlier email and the account are one record")
        row = dbm.q1("SELECT * FROM prelaunch_signups"); self.assertEqual(row["source"], "account"); self.assertEqual(row["user_id"], self.n("SELECT id FROM users WHERE email='eager@example.com'"))
        c.get(r.headers["Location"]); h = c.get("/").data.decode(); self.assertIn("Thanks for registering, Eager", h)
        for p in ("/student", "/courses", "/account"): self.assertEqual(c.get(p).status_code, 302)
        c2 = self.anon(); r = c2.post("/register", data={"full_name": "Dup", "email": "eager@example.com", "password": "Sup3rSecret9", "password2": "Sup3rSecret9", "_csrf": self.tok(c2)}, follow_redirects=True)
        self.assertIn("already exists", r.data.decode()); self.assertEqual(self.n("SELECT COUNT(*) FROM users WHERE email='eager@example.com'"), 1)
        c3 = self.anon(); self.sub(c3, "alice@t.test"); self.assertEqual(dbm.q1("SELECT user_id FROM prelaunch_signups WHERE email='alice@t.test'")["user_id"], self.users["alice"])
        P._now = lambda: datetime(2030, 1, 1, tzinfo=timezone.utc)                           # after launch the same student can use everything
        self.assertEqual(c.get("/student").status_code, 200)

    def test_registration_closed_when_disabled(self):
        self.on(register_enabled="0"); c = self.anon(); self.assertEqual(c.get("/register").status_code, 302)
        self.assertEqual(c.post("/register", data={"full_name": "X", "email": "x@x.co", "password": "Sup3rSecret9", "password2": "Sup3rSecret9", "_csrf": self.tok(c)}).status_code, 403)
        self.assertEqual(self.n("SELECT COUNT(*) FROM users WHERE email='x@x.co'"), 0)

    def test_admin_lists_registrations_and_exports(self):
        self.on(); c = self.anon(); self.sub(c, "=cmd@evil.com"); self.sub(c, "plain@example.com")
        c4 = self.anon(); c4.post("/register", data={"full_name": "Acc One", "email": "acc1@example.com", "password": "Sup3rSecret9", "password2": "Sup3rSecret9", "_csrf": self.tok(c4)})
        a = self.client("pladmin"); h = a.get("/staff/prelaunch/signups").data.decode()
        for s in ("plain@example.com", "acc1@example.com", "alice@t.test", "Email only", "Account"): self.assertIn(s, h)
        self.assertEqual(h.count("plain@example.com"), 1)
        self.assertIn("acc1@example.com", a.get("/staff/prelaunch/signups?q=acc+one").data.decode()); self.assertNotIn("plain@example.com", a.get("/staff/prelaunch/signups?q=acc+one").data.decode())
        self.assertNotIn("acc1@example.com", a.get("/staff/prelaunch/signups?source=email").data.decode())
        csv_ = a.get("/staff/prelaunch/signups.csv"); self.assertEqual(csv_.mimetype, "text/csv"); body = csv_.data.decode(); self.assertIn("plain@example.com", body); self.assertIn("alice@t.test", body); self.assertIn("'=cmd@evil.com", body)
        sid = self.n("SELECT id FROM prelaunch_signups WHERE email='plain@example.com'"); self.assertEqual(self.post(a, f"/staff/prelaunch/signups/{sid}/delete").status_code, 302)
        self.assertEqual(self.n("SELECT COUNT(*) FROM prelaunch_signups WHERE email='plain@example.com'"), 0)
        aid = self.n("SELECT id FROM prelaunch_signups WHERE email='acc1@example.com'"); self.post(a, f"/staff/prelaunch/signups/{aid}/delete"); self.assertEqual(self.n("SELECT COUNT(*) FROM prelaunch_signups WHERE email='acc1@example.com'"), 1)
        self.assertEqual(self.post(self.client("alice"), f"/staff/prelaunch/signups/{aid}/delete").status_code, 403)           # students are stopped by the gate itself
        self.assertEqual(self.n("SELECT COUNT(*) FROM prelaunch_signups WHERE email='acc1@example.com'"), 1)

class PageTests(PL):
    def test_page_content_social_links_and_mobile(self):
        S.put("social.facebook", "https://facebook.com/dagba"); S.put("social.instagram", "javascript:alert(1)"); S.put("social.x", "https://x.com/dagba"); S.put("contact.whatsapp", "+234 801 234 5678")
        self.on(); h = self.anon().get("/").data.decode()
        self.assertIn('href="https://facebook.com/dagba"', h); self.assertIn('href="https://x.com/dagba"', h); self.assertNotIn("javascript:", h); self.assertIn("wa.me/2348012345678", h)
        self.assertIn('name="viewport"', h); self.assertIn("js/prelaunch.js", h); self.assertIn("img/logo.png", h); self.assertIn("Dagba Digital Academy", h)
        self.assertNotIn('href="/courses"', h); self.assertNotIn("Explore", h.split("</main>")[0])
        js = self.anon().get("/static/js/prelaunch.js"); self.assertEqual(js.status_code, 200); self.assertIn("data-now", js.data.decode())

    def test_staff_banner_and_hidden_navigation(self):
        self.on(); h = self.client("owner").get("/courses").data.decode(); self.assertIn("Pre-Launch Mode is ON", h)
        self.assertNotIn("Pre-Launch Mode is ON", self.anon().get("/login").data.decode()); self.assertNotIn('href="/courses"', self.anon().get("/login").data.decode())
        nav = self.client("pladmin").get("/staff/").data.decode(); self.assertIn("Pre-Launch settings", nav); self.assertIn("Early registrations", nav)
        self.assertNotIn("Pre-Launch settings", self.client("noperm").get("/staff/").data.decode())

    def test_existing_data_untouched(self):
        n_users = self.n("SELECT COUNT(*) FROM users"); n_courses = self.n("SELECT COUNT(*) FROM courses"); self.on(); self.assertEqual(self.n("SELECT COUNT(*) FROM users"), n_users); self.assertEqual(self.n("SELECT COUNT(*) FROM courses"), n_courses)
        self.assertEqual(self.n("SELECT COUNT(*) FROM prelaunch_signups"), 0)
