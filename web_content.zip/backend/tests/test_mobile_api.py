import json
from tests.base import Base, PW
from dagba import db as dbm
from dagba.services import settings as S, mobile
from dagba.util import now

FUTURE = "2999-01-01 00:00:00"

class MobileApi(Base):
    def setUp(self):
        super().setUp(); self.c = self.app.test_client()

    def j(self, method, url, data=None, tok=None, **kw):
        h = {"Authorization": f"Bearer {tok}"} if tok else {}
        r = getattr(self.c, method)(url, json=data, headers=h, **kw)
        return r, (r.get_json(silent=True) or {})

    def login(self, who="alice"):
        r, d = self.j("post", "/api/v1/auth/login", {"email": f"{who}@t.test", "password": PW, "platform": "android"})
        self.assertEqual(r.status_code, 200, d); return d

    # ---- public config / catalogue
    def test_config_never_leaks_secrets(self):
        S.put("pay.paystack.secret_key", "sk_live_SECRET"); S.put("bank.account_number", "0123456789")
        r, d = self.j("get", "/api/v1/config"); raw = r.get_data(as_text=True)
        self.assertEqual(r.status_code, 200); self.assertNotIn("sk_live_SECRET", raw); self.assertNotIn("0123456789", raw)
        self.assertEqual([x["key"] for x in d["academic_levels"]], ["basic", "advanced"])      # no JSS/SS
        self.assertTrue(r.headers.get("ETag"))
        r2 = self.c.get("/api/v1/config", headers={"If-None-Match": r.headers["ETag"]}); self.assertEqual(r2.status_code, 304)

    def test_courses_listing_published_only_no_jss(self):
        r, d = self.j("get", "/api/v1/courses"); titles = {c["title"] for c in d["courses"]}
        self.assertIn("Paid Maths", titles); self.assertNotIn("Draft", titles)
        self.assertNotIn("class_level", json.dumps(d)); self.assertNotIn("JSS", json.dumps(d))
        r, d = self.j("get", "/api/v1/courses?division=income"); self.assertEqual([c["title"] for c in d["courses"]], ["Marketing"])
        r, d = self.j("get", "/api/v1/courses?q=%25"); self.assertEqual(d["total"], 0)           # LIKE wildcards are escaped

    def test_draft_course_hidden_and_detail_hides_lesson_bodies(self):
        r, d = self.j("get", "/api/v1/courses/draftc"); self.assertEqual(r.status_code, 404); self.assertFalse(d["ok"])
        r, d = self.j("get", "/api/v1/courses/paid-maths"); self.assertEqual(r.status_code, 200)
        self.assertNotIn("body", json.dumps(d["course"]["curriculum"])); self.assertIsNone(d["course"]["access"])
        self.assertTrue(all(l["locked"] for m in d["course"]["curriculum"] for l in m["lessons"]))

    # ---- auth
    def test_login_refresh_rotation_and_replay_revokes_session(self):
        t = self.login(); r, d = self.j("get", "/api/v1/me", tok=t["access_token"]); self.assertEqual(d["user"]["email"], "alice@t.test")
        r, d = self.j("post", "/api/v1/auth/refresh", {"refresh_token": t["refresh_token"]}); self.assertEqual(r.status_code, 200)
        new = d["refresh_token"]; self.assertNotEqual(new, t["refresh_token"])
        r, d2 = self.j("post", "/api/v1/auth/refresh", {"refresh_token": t["refresh_token"]}); self.assertEqual(r.status_code, 401)   # replay of a rotated token
        r, d3 = self.j("post", "/api/v1/auth/refresh", {"refresh_token": new}); self.assertEqual(r.status_code, 401)                  # whole session now revoked
        r, _ = self.j("get", "/api/v1/me", tok=t["access_token"]); self.assertEqual(r.status_code, 401)

    def test_bad_login_and_missing_token(self):
        r, d = self.j("post", "/api/v1/auth/login", {"email": "alice@t.test", "password": "wrong"}); self.assertEqual(r.status_code, 401)
        r, d = self.j("get", "/api/v1/me"); self.assertEqual(r.status_code, 401); self.assertEqual(d["error"]["code"], "unauthorized")
        r, d = self.j("get", "/api/v1/me", tok="garbage"); self.assertEqual(r.status_code, 401)

    def test_cookie_session_is_not_accepted_by_api(self):
        c = self.client("alice"); r = c.get("/api/v1/me"); self.assertEqual(r.status_code, 401)

    def test_logout_revokes_access(self):
        t = self.login(); self.j("post", "/api/v1/auth/logout", tok=t["access_token"])
        r, _ = self.j("get", "/api/v1/me", tok=t["access_token"]); self.assertEqual(r.status_code, 401)

    def test_deactivated_user_loses_access(self):
        t = self.login(); dbm.ex("UPDATE users SET is_active=0 WHERE id=?", (self.users["alice"],))
        r, _ = self.j("get", "/api/v1/me", tok=t["access_token"]); self.assertEqual(r.status_code, 401)

    def test_register_creates_student_and_validates(self):
        r, d = self.j("post", "/api/v1/auth/register", {"email": "new@t.test", "full_name": "New Person", "password": "Str0ngPass!word"})
        self.assertEqual(r.status_code, 201, d); self.assertEqual(d["user"]["role"], "student")
        self.assertEqual(self.val("SELECT role FROM users WHERE email='new@t.test'"), "student")
        r, d = self.j("post", "/api/v1/auth/register", {"email": "new@t.test", "full_name": "Dup", "password": "Str0ngPass!word"}); self.assertEqual(r.status_code, 400)
        r, d = self.j("post", "/api/v1/auth/register", {"email": "x@t.test", "full_name": "X", "password": "123"}); self.assertEqual(r.status_code, 400)

    def test_change_password_signs_out_other_devices(self):
        a = self.login(); b = self.login()
        r, d = self.j("post", "/api/v1/me/password", {"current_password": PW, "new_password": "An0ther-Str0ng-Pass"}, tok=a["access_token"]); self.assertEqual(r.status_code, 200, d)
        self.assertEqual(self.j("get", "/api/v1/me", tok=a["access_token"])[0].status_code, 200)
        self.assertEqual(self.j("get", "/api/v1/me", tok=b["access_token"])[0].status_code, 401)

    # ---- entitlements stay independent
    def test_subscriptions_are_independent_in_me_and_course_access(self):
        dbm.ex("INSERT INTO entitlements(user_id,kind,plan_id,division,starts_at,expires_at) VALUES (?,?,?,?,?,?)",
               (self.users["alice"], "subscription", self.plan_a, "academic", now(), FUTURE))
        t = self.login(); r, d = self.j("get", "/api/v1/me", tok=t["access_token"]); s = d["user"]["subscriptions"]
        self.assertTrue(s["basic"]["active"]); self.assertFalse(s["income"]["active"]); self.assertFalse(s["advanced"]["active"])
        r, d = self.j("get", "/api/v1/courses/marketing", tok=t["access_token"]); self.assertIsNone(d["course"]["access"])       # Academic sub does not unlock Income Skills
        r, d = self.j("get", "/api/v1/courses/paid-maths", tok=t["access_token"]); self.assertEqual(d["course"]["access"], "subscription")

    # ---- sync + account deletion + prelaunch
    def test_content_version_bumps_on_admin_changes_from_any_route(self):
        v0 = mobile.content_version(); dbm.ex("UPDATE courses SET price_kobo=750000 WHERE id=?", (self.paid,))
        v1 = mobile.content_version(); self.assertGreater(v1, v0)
        dbm.ex("INSERT INTO progress(user_id,lesson_id,course_id,updated_at) SELECT ?,id,course_id,? FROM lessons LIMIT 1", (self.users["alice"], now()))
        self.assertEqual(mobile.content_version(), v1)                                          # learner activity must not invalidate everyone's cache
        r, d = self.j("get", "/api/v1/courses/paid-maths"); self.assertEqual(d["course"]["price_kobo"], 750000)       # price change appears with no app release

    def test_account_deletion_anonymises_and_blocks_login(self):
        t = self.login()
        r, d = self.j("delete", "/api/v1/me", {"password": "wrong"}, tok=t["access_token"]); self.assertEqual(r.status_code, 400)
        r, d = self.j("delete", "/api/v1/me", {"password": PW}, tok=t["access_token"]); self.assertEqual(r.status_code, 200, d)
        u = self.row("SELECT * FROM users WHERE id=?", (self.users["alice"],)); self.assertEqual(u["is_active"], 0); self.assertNotIn("alice", u["email"])
        r, _ = self.j("post", "/api/v1/auth/login", {"email": "alice@t.test", "password": PW}); self.assertEqual(r.status_code, 401)

    def test_staff_cannot_self_delete_via_app(self):
        t = self.login("inst"); r, d = self.j("delete", "/api/v1/me", {"password": PW}, tok=t["access_token"]); self.assertEqual(r.status_code, 403)

    def test_prelaunch_blocks_catalogue_but_not_config_or_login(self):
        S.put("prelaunch.enabled", "1"); S.put("prelaunch.launch_at", "2999-01-01T00:00")
        self.assertEqual(self.j("get", "/api/v1/config")[0].status_code, 200)
        r, d = self.j("get", "/api/v1/courses"); self.assertEqual(r.status_code, 403); self.assertEqual(d["error"]["code"], "prelaunch")
        self.assertEqual(self.j("post", "/api/v1/auth/login", {"email": "alice@t.test", "password": PW})[0].status_code, 200)

    def test_register_device_token(self):
        t = self.login(); tok = "f" * 60
        r, d = self.j("post", "/api/v1/devices", {"token": tok, "platform": "android"}, tok=t["access_token"]); self.assertEqual(r.status_code, 200)
        self.assertEqual(self.val("SELECT COUNT(*) FROM device_tokens"), 1)
        self.assertEqual(self.j("post", "/api/v1/devices", {"token": "x", "platform": "android"}, tok=t["access_token"])[0].status_code, 400)

    def test_api_404_is_json(self):
        r, d = self.j("get", "/api/v1/nope"); self.assertEqual(r.status_code, 404); self.assertFalse(d["ok"])

    def test_public_account_deletion_page_exists(self):
        r = self.c.get("/delete-account"); self.assertEqual(r.status_code, 200); self.assertIn(b"Delete account", r.data)

    def test_cors_only_for_app_origins_and_preflight_ok_even_prelaunch(self):
        r = self.c.options("/api/v1/courses", headers={"Origin": "https://localhost", "Access-Control-Request-Method": "GET", "Access-Control-Request-Headers": "authorization"})
        self.assertEqual(r.headers.get("Access-Control-Allow-Origin"), "https://localhost"); self.assertIn("Authorization", r.headers["Access-Control-Allow-Headers"])
        r = self.c.get("/api/v1/config", headers={"Origin": "https://evil.example"}); self.assertIsNone(r.headers.get("Access-Control-Allow-Origin"))
        S.put("prelaunch.enabled", "1"); S.put("prelaunch.launch_at", "2999-01-01T00:00")
        r = self.c.options("/api/v1/courses", headers={"Origin": "capacitor://localhost", "Access-Control-Request-Method": "GET"}); self.assertEqual(r.headers.get("Access-Control-Allow-Origin"), "capacitor://localhost")

    def test_app_link_files_only_when_configured_and_bundles_locked_down(self):
        self.assertEqual(self.c.get("/.well-known/assetlinks.json").status_code, 404)
        S.put("mobile.android_package", "com.dagbadigitalacademy.app"); S.put("mobile.android_sha256", "AA:BB")
        self.assertEqual(self.c.get("/.well-known/assetlinks.json").get_json()[0]["target"]["package_name"], "com.dagbadigitalacademy.app")
        S.put("mobile.apple_app_id", "TEAM123.com.dagbadigitalacademy.app"); self.assertIn("TEAM123", self.c.get("/.well-known/apple-app-site-association").get_data(as_text=True))
        self.assertEqual(self.c.get("/api/v1/bundles/..%2Fsecret.zip").status_code, 404); self.assertEqual(self.c.get("/api/v1/bundles/dagba-web-1.zip").status_code, 404)
