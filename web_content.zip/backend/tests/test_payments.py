import json, hmac, hashlib
from .base import *
from dagba.services import payments as P, access, providers, settings as S

class ManualTransferAcceptance(Base):
    """Maps to the 20 payment acceptance tests in the specification."""
    def test_01_to_07_submit_pending_no_access(self):
        c = self.client("alice")
        r = c.get("/checkout/course/paid-maths"); self.assertEqual(r.status_code, 200)                          # 1 select paid course
        ref = self.buy(c, "course", "paid-maths", submit=False)
        page = c.get(f"/pay/{ref}").data.decode()
        self.assertIn("Test Bank", page); self.assertIn("0123456789", page); self.assertIn(ref, page); self.assertIn("5,000", page)   # 2 bank details, 3 reference, amount
        self.assertRegex(ref, r"^DDA-[A-Z0-9]{10}$")
        self.assertEqual(self.upload(c, ref).status_code, 302)                                                    # 4 receipt upload
        self.assertEqual(self.tx(ref)["status"], "pending_verification")                                          # 5 pending queue
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND kind='payment'", (self.users["officer"],)), 1)  # 6 staff notified
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND kind='payment'", (self.users["owner"],)), 1)
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=?", (self.users["noperm"],)), 0)
        self.assertEqual(self.client("officer").get("/staff/payments?status=pending_verification").status_code, 200)
        self.assertEqual(self.app.test_client().get("/").status_code, 200)
        self.assertEqual(c.get("/learn/paid-maths").status_code, 302)                                             # 7 no access while pending
        self.assertIsNone(access.course_access(self.users["alice"], dbm.q1("SELECT * FROM courses WHERE id=?", (self.paid,))))
        self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements"), 0)

    def test_08_to_10_approve_activates_exact_item(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths"); t = self.tx(ref)
        o = self.client("officer"); r = self.post(o, f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1", "note": "seen in bank"}); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.tx(ref)["status"], "approved")
        ents = dbm.q("SELECT * FROM entitlements"); self.assertEqual(len(ents), 1); self.assertEqual((ents[0]["kind"], ents[0]["course_id"]), ("course", self.paid))
        self.assertEqual(c.get("/learn/paid-maths").status_code, 200)                                              # 9 access active
        self.assertIsNone(access.course_access(self.users["alice"], dbm.q1("SELECT * FROM courses WHERE id=?", (self.inc,))))   # only that course
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND title LIKE 'Payment approved%'", (self.users["alice"],)), 1)  # 10 student notified
        self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='payment.approve' AND entity_id=?", (str(t["id"]),)), 1)  # 18 audit
        self.assertEqual(self.tx(ref)["decided_by"], self.users["officer"])

    def test_approval_requires_confirmation_checkboxes(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths"); t = self.tx(ref); o = self.client("officer")
        self.post(o, f"/staff/payments/{t['id']}", {"action": "approve"}); self.assertEqual(self.tx(ref)["status"], "pending_verification")
        self.post(o, f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1"}); self.assertEqual(self.tx(ref)["status"], "pending_verification")

    def test_11_12_reject_no_access_reason_shown_and_resubmit(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths"); t = self.tx(ref)
        self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "reject", "confirm": "1", "text": "Amount not received"})
        self.assertEqual(self.tx(ref)["status"], "rejected"); self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements"), 0)
        self.assertEqual(c.get("/learn/paid-maths").status_code, 302)
        self.assertIn("Amount not received", c.get(f"/pay/{ref}").data.decode())
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND body LIKE '%Amount not received%'", (self.users["alice"],)), 1)
        self.assertEqual(self.upload(c, ref).status_code, 302); self.assertEqual(self.tx(ref)["status"], "pending_verification")   # resubmission allowed
        S.put("bank.allow_resubmit", "0"); self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "reject", "confirm": "1", "text": "again"})
        self.upload(c, ref); self.assertEqual(self.tx(ref)["status"], "rejected")                                    # setting respected

    def test_reject_requires_reason(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths"); t = self.tx(ref)
        self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "reject", "confirm": "1", "text": ""}); self.assertEqual(self.tx(ref)["status"], "pending_verification")

    def test_13_request_info_flow(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths"); t = self.tx(ref)
        self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "info", "confirm": "1", "text": "Please send the full receipt"})
        self.assertEqual(self.tx(ref)["status"], "info_requested"); self.assertIn("full receipt", c.get(f"/pay/{ref}").data.decode())
        self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements"), 0)
        self.assertEqual(self.upload(c, ref).status_code, 302); self.assertEqual(self.tx(ref)["status"], "pending_verification")
        self.assertEqual(self.val("SELECT COUNT(*) FROM payment_evidence WHERE transaction_id=?", (t["id"],)), 2)

    def test_14_duplicate_approval_no_duplicate_entitlement(self):
        c = self.client("alice"); ref = self.buy(c, "plan", self.plan_a); t = self.tx(ref); o = self.client("officer")
        for _ in range(3): self.post(o, f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements WHERE transaction_id=?", (t["id"],)), 1)
        with self.assertRaises(P.PayError): P.decide(t["id"], dbm.q1("SELECT * FROM users WHERE id=?", (self.users["officer"],)), "approve")
        dbm.ex("INSERT OR IGNORE INTO entitlements(user_id,kind,division,starts_at,transaction_id) VALUES (?,?,?,?,?)", (self.users["alice"], "subscription", "academic", "2026-01-01 00:00:00", t["id"]))
        self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements WHERE transaction_id=?", (t["id"],)), 1)   # DB-level guard

    def test_15_unauthorised_cannot_approve(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths"); t = self.tx(ref)
        for who in ("alice", "bob", "inst", "writer", "noperm"):
            r = self.post(self.client(who), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}); self.assertIn(r.status_code, (302, 403)); 
            self.assertEqual(self.tx(ref)["status"], "pending_verification", who)
        self.assertEqual(self.client("noperm").get(f"/staff/payments/{t['id']}").status_code, 403)
        with self.assertRaises(P.PayError): P.decide(t["id"], dbm.q1("SELECT * FROM users WHERE id=?", (self.users["noperm"],)), "approve")

    def test_cannot_approve_own_payment(self):
        o = self.client("officer"); ref = self.buy(o, "course", "paid-maths", who="officer"); t = self.tx(ref)
        self.post(o, f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}); self.assertEqual(self.tx(ref)["status"], "pending_verification")

    def test_students_cannot_tamper_amount_or_status(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths", submit=False)
        self.post(c, f"/pay/{ref}/evidence", {"amount_kobo": "1", "status": "approved", "amount": "1"})
        self.upload(c, ref, extra={"amount_kobo": "1", "status": "approved", "amount_sent": "1"})
        t = self.tx(ref); self.assertEqual(t["amount_kobo"], 500000); self.assertEqual(t["status"], "pending_verification")
        self.assertEqual(self.post(self.client("bob"), f"/pay/{ref}/cancel").status_code, 404)   # other student cannot touch it

    def test_16_17_bank_settings_editable_and_toggle(self):
        o = self.client("owner")
        self.post(o, "/staff/settings/bank", {"bank.enabled": "1", "bank.name": "Zenith", "bank.account_name": "Dagba Digital Academy", "bank.account_number": "1122334455", "bank.file_types": "jpg,png,pdf", "bank.max_mb": "5", "bank.receipt_required": "1", "bank.allow_resubmit": "1"})
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths", submit=False); page = c.get(f"/pay/{ref}").data.decode()
        self.assertIn("Zenith", page); self.assertIn("1122334455", page); self.assertNotIn("0123456789", page)
        self.post(o, "/staff/settings/bank", {"bank.name": "Zenith", "bank.account_number": "1122334455", "bank.file_types": "jpg", "bank.max_mb": "5"})   # disables manual (checkbox absent)
        self.assertIn("not available", c.get(f"/pay/{ref}").data.decode()); self.assertEqual(self.upload(c, ref).status_code, 302); self.assertEqual(self.tx(ref)["status"], "awaiting_payment")
        self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='settings.bank'"), 2)
        self.assertEqual(self.post(self.client("officer"), "/staff/settings/bank", {"bank.account_number": "9999999999"}).status_code, 403)
        r = self.post(o, "/staff/settings/bank", {"bank.account_number": "12ab", "bank.max_mb": "5", "bank.file_types": "jpg"}); self.assertEqual(r.status_code, 200)   # validation

    def test_19_reports_separate_pending_from_confirmed(self):
        c = self.client("alice"); r1 = self.buy(c, "course", "paid-maths"); b = self.client("bob"); r2 = self.buy(b, "course", "marketing")
        self.post(self.client("officer"), f"/staff/payments/{self.tx(r1)['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        from dagba.blueprints import staffpay
        with self.app.test_request_context("/"): rep = staffpay._report()
        self.assertEqual(rep["confirmed"]["amt"], 500000); self.assertEqual(rep["pending"]["amt"], 1000000)
        self.assertEqual(rep["by_course"][0]["item_title"], "Paid Maths")
        csv = self.client("owner").get("/staff/reports/export.csv"); self.assertEqual(csv.status_code, 200); self.assertIn(b"NOT revenue", csv.data)
        pc = self.client("owner").get("/staff/payments/export.csv"); self.assertIn(self.tx(r2)["reference"].encode(), pc.data)

    def test_cancelled_and_refunded(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths", submit=False); self.post(c, f"/pay/{ref}/cancel"); self.assertEqual(self.tx(ref)["status"], "cancelled")
        ref2 = self.buy(c, "course", "paid-maths"); t = self.tx(ref2); self.post(self.client("refunder"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "refund", "confirm": "1", "text": "x"}); self.assertEqual(self.tx(ref2)["status"], "approved")   # no refund perm
        self.post(self.client("refunder"), f"/staff/payments/{t['id']}", {"action": "refund", "confirm": "1", "text": "customer request"}); self.assertEqual(self.tx(ref2)["status"], "refunded")
        self.assertEqual(c.get("/learn/paid-maths").status_code, 302)

    def test_duplicate_open_transaction_reused(self):
        c = self.client("alice"); a = self.buy(c, "course", "paid-maths", submit=False); b = self.buy(c, "course", "paid-maths", submit=False); self.assertEqual(a, b)

    def test_promo_server_side_and_free_promo(self):
        dbm.ex("INSERT INTO promos(code,percent_off,applies_to) VALUES ('HALF',50,'all')"); dbm.ex("INSERT INTO promos(code,percent_off,applies_to) VALUES ('FREE',100,'courses')")
        dbm.ex("INSERT INTO promos(code,percent_off,applies_to,expires_at) VALUES ('OLD',50,'all','2020-01-01 00:00:00')")
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths", submit=False, promo="HALF"); self.assertEqual(self.tx(ref)["amount_kobo"], 250000)
        r = self.post(c, "/checkout/course/marketing", {"action": "pay", "promo": "OLD"}); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.val("SELECT amount_kobo FROM transactions WHERE course_id=?", (self.inc,)), 1000000)    # invalid code ignored => full price
        b = self.client("bob"); self.buy(b, "course", "paid-maths", who="bob", submit=False, promo="FREE")
        self.assertEqual(b.get("/learn/paid-maths").status_code, 200)

class EntitlementTests(Base):
    def _approve(self, who, kind, ident):
        c = self.client(who); ref = self.buy(c, kind, ident, who=who); self.post(self.client("officer"), f"/staff/payments/{self.tx(ref)['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}); return c

    def test_subscriptions_are_independent(self):
        a = self.users["alice"]; self._approve("alice", "plan", self.plan_a)
        pc, ic, fc = [dbm.q1("SELECT * FROM courses WHERE id=?", (i,)) for i in (self.paid, self.inc, self.free)]
        self.assertEqual(access.course_access(a, pc), "subscription"); self.assertIsNone(access.course_access(a, ic)); self.assertEqual(access.course_access(a, fc), "free")
        self._approve("alice", "plan", self.plan_i); self.assertEqual(access.course_access(a, ic), "subscription")

    def test_expiry_isolation(self):
        a = self.users["alice"]; self._approve("alice", "plan", self.plan_a); self._approve("alice", "plan", self.plan_i); self._approve("alice", "course", "paid-maths")
        pc, ic = [dbm.q1("SELECT * FROM courses WHERE id=?", (i,)) for i in (self.paid, self.inc)]
        dbm.ex("UPDATE entitlements SET expires_at='2020-01-01 00:00:00' WHERE kind='subscription' AND division='academic'")        # academic expires
        self.assertEqual(access.course_access(a, ic), "subscription")                      # income unaffected
        self.assertEqual(access.course_access(a, pc), "purchased")                         # individual purchase unaffected
        dbm.ex("UPDATE entitlements SET expires_at='2020-01-01 00:00:00' WHERE kind='subscription'")
        self.assertIsNone(access.course_access(a, ic)); self.assertEqual(access.course_access(a, pc), "purchased")
        self.assertEqual(access.expire_notifications(), 2); self.assertEqual(access.expire_notifications(), 0)
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND kind='subscription'", (a,)), 2)

    def test_individual_course_not_subscription_eligible_excluded(self):
        a = self.users["alice"]; self._approve("alice", "plan", self.plan_a); dbm.ex("UPDATE courses SET subscription_eligible=0 WHERE id=?", (self.paid,))
        self.assertIsNone(access.course_access(a, dbm.q1("SELECT * FROM courses WHERE id=?", (self.paid,))))

    def test_renewal_stacks_and_limited_course_access(self):
        a = self.users["alice"]; self._approve("alice", "plan", self.plan_a); self._approve("alice", "plan", self.plan_a)
        exp = access._active_sub_expiry(a, "basic"); from dagba.util import parse_ts, now_dt
        self.assertGreater((parse_ts(exp) - now_dt()).days, 58)
        dbm.ex("UPDATE courses SET access_policy='days', access_days=10 WHERE id=?", (self.inc,)); self._approve("bob", "course", "marketing")
        e = dbm.q1("SELECT * FROM entitlements WHERE course_id=?", (self.inc,)); self.assertLessEqual((parse_ts(e["expires_at"]) - now_dt()).days, 10)

    def test_draft_and_inactive_not_purchasable(self):
        c = self.client("alice"); self.assertEqual(self.post(c, "/checkout/course/draftc", {"action": "pay"}).status_code, 302)
        self.assertEqual(self.val("SELECT COUNT(*) FROM transactions"), 0)
        dbm.ex("UPDATE plans SET active=0"); self.post(c, f"/checkout/plan/{self.plan_a}", {"action": "pay"}); self.assertEqual(self.val("SELECT COUNT(*) FROM transactions"), 0)

    def test_approval_survives_notification_failure(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths"); t = self.tx(ref)
        import dagba.services.payments as pm; orig = pm.notify
        pm.notify = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom"))
        try: self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        finally: pm.notify = orig
        self.assertEqual(self.tx(ref)["status"], "approved"); self.assertEqual(c.get("/learn/paid-maths").status_code, 200)

class UploadSecurityTests(Base):
    def _ref(self, c): return self.buy(c, "course", "paid-maths", submit=False)
    def test_rejects_bad_uploads(self):
        c = self.client("alice"); ref = self._ref(c)
        cases = [("evil.php", b"<?php echo 1;?>"), ("r.png", b"<?php echo 1;?>"), ("r.png", PDF), ("r.pdf", png_bytes()), ("r.exe", b"MZ\x90\x00"), ("r.png", b""), ("r.png", png_bytes()[:30]), ("r.svg", b"<svg onload=alert(1)>")]
        for name, data in cases:
            self.upload(c, ref, name=name, data=data); self.assertEqual(self.tx(ref)["status"], "awaiting_payment", name)
        self.assertEqual(self.val("SELECT COUNT(*) FROM payment_evidence"), 0)
    def test_size_limit(self):
        c = self.client("alice"); ref = self._ref(c); big = png_bytes() + b"0" * (6 * 1024 * 1024)
        self.upload(c, ref, data=big); self.assertEqual(self.tx(ref)["status"], "awaiting_payment")
    def test_valid_pdf_and_private_storage(self):
        c = self.client("alice"); ref = self._ref(c); self.assertEqual(self.upload(c, ref, name="r.pdf", data=PDF).status_code, 302)
        e = dbm.q1("SELECT * FROM payment_evidence"); self.assertEqual(e["mime"], "application/pdf"); self.assertRegex(e["file"], r"^[0-9a-f]{32}\.pdf$")
        self.assertEqual(self.client().get("/static/" + e["file"]).status_code, 404)
        self.assertTrue(os.path.exists(os.path.join(self.app.config["PRIVATE_DIR"], e["file"])))
    def test_receipt_access_control(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths"); e = dbm.q1("SELECT * FROM payment_evidence")
        url = f"/pay/receipt/{e['id']}"
        self.assertEqual(c.get(url).status_code, 200); self.assertEqual(self.client("officer").get(url).status_code, 200); self.assertEqual(self.client("owner").get(url).status_code, 200)
        for who in ("bob", "noperm", "inst", "writer"): self.assertEqual(self.client(who).get(url).status_code, 403, who)
        self.assertEqual(self.app.test_client().get(url).status_code, 302)
        self.assertIn("sandbox", c.get(url).headers["Content-Security-Policy"]); self.assertEqual(c.get(url).headers["X-Content-Type-Options"], "nosniff")
    def test_receipt_optional_setting(self):
        S.put("bank.receipt_required", "0"); c = self.client("alice"); ref = self._ref(c)
        r = c.post(f"/pay/{ref}/evidence", data={"_csrf": self.tok(c), "note": "paid at 2pm via transfer", "transfer_date": "2026-11-01"}, content_type="multipart/form-data"); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.tx(ref)["status"], "pending_verification")

class GatewayTests(Base):
    """Provider network calls are replaced by stubs: real HTTP needs credentials. Signature + idempotency logic is real."""
    def test_providers_hidden_until_configured_and_enabled(self):
        self.assertEqual(providers.active_providers(), [])
        S.put("pay.paystack.enabled", "1"); self.assertEqual(providers.active_providers(), [])       # enabled but no secret
        S.put("pay.paystack.secret_key", "sk_test_x"); self.assertEqual([p.name for p in providers.active_providers()], ["paystack"])
        S.put("pay.paystack.enabled", "0"); self.assertEqual(providers.active_providers(), [])
        S.put("pay.flutterwave.enabled", "1"); S.put("pay.flutterwave.secret_key", "k"); self.assertEqual(providers.active_providers(), [])   # needs webhook hash
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths", submit=False); self.assertNotIn("Paystack", c.get(f"/pay/{ref}").data.decode())

    def test_secrets_never_leak_to_browser(self):
        S.put("pay.paystack.secret_key", "sk_live_SUPERSECRET"); o = self.client("owner")
        self.assertNotIn(b"SUPERSECRET", o.get("/staff/settings/methods").data)
        self.post(o, "/staff/settings/methods", {"pay.paystack.secret_key": ""}); self.assertEqual(S.get("pay.paystack.secret_key"), "sk_live_SUPERSECRET")   # blank keeps
        self.assertNotIn("SUPERSECRET", json.dumps(S.all_public())); self.assertNotIn("SUPERSECRET", self.client().get("/").data.decode())

    def _setup(self):
        S.put("pay.paystack.enabled", "1"); S.put("pay.paystack.secret_key", "sk_test_secret")
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths", submit=False)
        dbm.ex("UPDATE transactions SET method='paystack' WHERE reference=?", (ref,)); return c, ref

    def test_webhook_signature_and_idempotent_activation(self):
        c, ref = self._setup(); body = json.dumps({"event": "charge.success", "data": {"id": 99, "reference": ref}}).encode()
        sig = hmac.new(b"sk_test_secret", body, hashlib.sha512).hexdigest(); anon = self.app.test_client()
        self.assertEqual(anon.post("/webhooks/paystack", data=body, headers={"x-paystack-signature": "bad"}).status_code, 401)
        self.assertEqual(anon.post("/webhooks/paystack", data=body).status_code, 401)
        self.assertEqual(self.tx(ref)["status"], "awaiting_payment")
        orig = providers.Paystack.verify; providers.Paystack.verify = lambda s, r: {"status": "success", "amount_kobo": 500000, "currency": "NGN"}
        try:
            for _ in range(3): self.assertEqual(anon.post("/webhooks/paystack", data=body, headers={"x-paystack-signature": sig}).status_code, 200)
        finally: providers.Paystack.verify = orig
        self.assertEqual(self.tx(ref)["status"], "approved"); self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements"), 1); self.assertEqual(c.get("/learn/paid-maths").status_code, 200)

    def test_amount_mismatch_and_failure_never_grant(self):
        c, ref = self._setup()
        self.assertEqual(P.finalize_gateway(ref, "paystack", {"status": "success", "amount_kobo": 100, "currency": "NGN"}), "failed")
        self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements"), 0)
        ref2 = self.buy(c, "course", "paid-maths", submit=False); dbm.ex("UPDATE transactions SET method='paystack' WHERE reference=?", (ref2,))
        self.assertEqual(P.finalize_gateway(ref2, "paystack", {"status": "pending"}), "awaiting_payment"); self.assertEqual(P.finalize_gateway(ref2, "paystack", {"status": "failed"}), "failed")
        ref3 = self.buy(c, "course", "paid-maths", submit=False); dbm.ex("UPDATE transactions SET method='paystack' WHERE reference=?", (ref3,))
        self.assertEqual(P.finalize_gateway(ref3, "paystack", {"status": "success", "amount_kobo": 500000, "currency": "USD"}), "failed"); self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements"), 0)

    def test_gateway_and_manual_coexist_same_entitlement_system(self):
        c, ref = self._setup(); P.finalize_gateway(ref, "paystack", {"status": "success", "amount_kobo": 500000, "currency": "NGN"})
        r2 = self.buy(self.client("bob"), "course", "marketing", who="bob"); self.post(self.client("officer"), f"/staff/payments/{self.tx(r2)['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        self.assertEqual({r["method"] for r in dbm.q("SELECT method FROM transactions WHERE status='approved'")}, {"paystack", "manual_transfer"})
        self.assertEqual({r["kind"] for r in dbm.q("SELECT kind FROM entitlements")}, {"course"}); self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements"), 2)

    def test_flutterwave_webhook_hash(self):
        S.put("pay.flutterwave.enabled", "1"); S.put("pay.flutterwave.secret_key", "k"); S.put("pay.flutterwave.webhook_hash", "h4sh"); a = self.app.test_client()
        self.assertEqual(a.post("/webhooks/flutterwave", data=b"{}", headers={"verif-hash": "nope"}).status_code, 401)
        self.assertEqual(a.post("/webhooks/flutterwave", data=b"{}", headers={"verif-hash": "h4sh"}).status_code, 200)
