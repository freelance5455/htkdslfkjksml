"""Faith & Spiritual Growth: topics, series, lessons, media upload/streaming, access rules, progress, admin permissions,
menu/homepage integration, and upgrade of an existing site (menu setting migrated, nothing else disturbed)."""
import json, sqlite3, tempfile, shutil
from .base import *
from .test_builder import mp4, jpost, jpeg_bytes
from dagba.services import faith as F, settings as S

def mp3(n=3000): return b"ID3\x03\x00\x00\x00\x00\x00\x00" + bytes(range(256)) * (n // 256 + 1)

class FaithBase(Base):
    def setUp(self):
        super().setUp()
        self.owner = self.client("owner")
        self.mk("faither", "admin", perms=["faith.manage"])
        self.topic = self.val("SELECT id FROM faith_topics WHERE slug='prayer'")

    def up(self, c, data, name, kind):
        j = jpost(c, self, "/staff/faith/upload/init", {"name": name, "size": len(data), "kind": kind}).get_json()
        if not j.get("ok"): return j
        uid = j["upload_id"]; half = len(data) // 2
        for i, part in enumerate((data[:half], data[half:])):
            r = c.post(f"/staff/faith/upload/{uid}/chunk?index={i}", data=part, content_type="application/octet-stream", headers={"X-CSRF-Token": self.tok(c)}); self.assertTrue(r.get_json()["ok"])
        return jpost(c, self, f"/staff/faith/upload/{uid}/finish", {}).get_json()

    def save(self, c=None, **kw):
        p = dict(title="Lord Teach Us to Pray", topic_id=self.topic, kind="reading", body="Our Father in heaven...", status="published", access="public", scripture="Luke 11:1-4")
        p.update(kw); return jpost(c or self.owner, self, "/staff/faith/save", p)

    def mkitem(self, **kw):
        j = self.save(**kw).get_json(); self.assertTrue(j["ok"], j); return j["id"], self.val("SELECT slug FROM faith_items WHERE id=?", (j["id"],))

class StructureAndMenuTests(FaithBase):
    def test_six_topics_exist_and_page_renders_for_everyone(self):
        names = [r["name"] for r in dbm.q("SELECT name FROM faith_topics ORDER BY position")]
        self.assertEqual(names, ["Bible Studies", "Christian Living", "Prayer", "Biblical Wisdom", "Relationships", "Spiritual Growth"])
        for who in (None, "alice", "owner"):
            c = self.client(who) if who else self.app.test_client(); r = c.get("/faith"); self.assertEqual(r.status_code, 200); t = r.data.decode()
            for n in names: self.assertIn(n.replace("&", "&amp;"), t)
            self.assertIn("Lessons are being prepared", t)                                    # honest empty state, no fake content
    def test_menu_has_faith_link_and_existing_links_remain(self):
        t = self.app.test_client().get("/").data.decode()
        self.assertIn('href="/faith">Faith</a>', t)
        for h in ("/courses", "/academic", "/income-skills", "/pricing", "/blog", "/nuggets", "/about", "/contact"): self.assertIn(f'href="{h}"', t)
    def test_homepage_section_appears_only_with_published_lessons(self):
        self.assertNotIn("faithband", self.app.test_client().get("/").data.decode())
        self.mkitem(); t = self.app.test_client().get("/").data.decode(); self.assertIn("faithband", t); self.assertIn("/faith/topic/prayer", t)
        S.put("home.show_faith", "0"); self.assertNotIn("faithband", self.app.test_client().get("/").data.decode())
    def test_empty_topic_page_and_unknown_pages(self):
        self.assertEqual(self.app.test_client().get("/faith/topic/prayer").status_code, 200)
        for u in ("/faith/topic/nope", "/faith/series/nope", "/faith/lesson/nope", "/faith/media/999/video", "/faith/media/1/zzz"): self.assertEqual(self.app.test_client().get(u).status_code, 404, u)
    def test_hidden_topic_disappears(self):
        dbm.ex("UPDATE faith_topics SET active=0 WHERE slug='prayer'"); self.assertEqual(self.app.test_client().get("/faith/topic/prayer").status_code, 404)

class PermissionTests(FaithBase):
    def test_only_faith_managers_reach_admin(self):
        for who, code in (("owner", 200), ("faither", 200), ("noperm", 403), ("officer", 403), ("writer", 403), ("alice", 403)):
            c = self.client(who)
            for u in ("/staff/faith/", "/staff/faith/lessons", "/staff/faith/lesson/new", "/staff/r/faith-topics", "/staff/r/faith-series"): self.assertEqual(c.get(u).status_code, code, (who, u))
        self.assertEqual(self.app.test_client().get("/staff/faith/").status_code, 302)
    def test_save_and_upload_endpoints_are_protected(self):
        for who in ("alice", "noperm", "writer"):
            c = self.client(who)
            self.assertEqual(jpost(c, self, "/staff/faith/save", {"title": "x"}).status_code, 403, who)
            self.assertEqual(jpost(c, self, "/staff/faith/upload/init", {"name": "a.mp3", "size": 10, "kind": "audio"}).status_code, 403, who)
        self.assertEqual(jpost(self.app.test_client(), self, "/staff/faith/save", {}).status_code, 401)
        self.assertEqual(self.owner.post("/staff/faith/save", data="{}", content_type="application/json").status_code, 400)       # CSRF
    def test_permission_is_listed_for_staff_setup(self):
        t = self.owner.get(f"/staff/users/{self.users['noperm']}").data.decode(); self.assertIn("faith.manage", t)
    def test_sidebar_shows_faith_only_with_permission(self):
        self.assertIn('href="/staff/faith/lessons"', self.client("faither").get("/staff/").data.decode()); self.assertNotIn('href="/staff/faith/lessons"', self.client("officer").get("/staff/").data.decode())

class LessonLifecycleTests(FaithBase):
    def test_publish_rules_per_format(self):
        for kind, extra in (("video", {}), ("audio", {}), ("reading", {"body": ""}), ("study", {"body": ""})):
            r = self.save(kind=kind, **extra); self.assertEqual(r.status_code, 400, kind); self.assertTrue(r.get_json()["errors"], kind)
        self.assertEqual(self.save(kind="video", status="draft", body="").get_json()["status"], "draft")                          # drafts may be incomplete
        self.assertTrue(self.save(kind="video", video_url="https://www.youtube.com/watch?v=dQw4w9WgXcQ", title="V").get_json()["ok"])
        self.assertTrue(self.save(kind="audio", audio_url="https://example.com/a.mp3", title="A").get_json()["ok"])
        self.assertEqual(self.save(kind="video", video_url="http://insecure.example/v.mp4", title="V2").status_code, 400)
        self.assertEqual(self.save(kind="video", video_url="https://example.com/page", title="V3").status_code, 400)               # not embeddable
        self.assertEqual(self.save(kind="audio", audio_url="https://example.com/a.exe", title="A2").status_code, 400)
    def test_validation_of_topic_series_kind(self):
        self.assertEqual(self.save(topic_id=9999).status_code, 400); self.assertEqual(self.save(kind="zzz").status_code, 400); self.assertEqual(self.save(title="  ").status_code, 400)
        other = self.val("SELECT id FROM faith_topics WHERE slug='relationships'"); s = dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status) VALUES (?,?,?,?)", (other, "S", "s", "published"))
        self.assertEqual(self.save(series_id=s).status_code, 400)                                                              # series from another topic
        self.assertTrue(self.save(series_id=s, topic_id=other).get_json()["ok"])
    def test_slugs_unique_and_edit_keeps_slug(self):
        a, sa = self.mkitem(); b, sb = self.mkitem(); self.assertNotEqual(sa, sb)
        j = self.save(id=a, title="Renamed", body="x").get_json(); self.assertTrue(j["ok"]); self.assertEqual(self.val("SELECT slug FROM faith_items WHERE id=?", (a,)), sa)
        self.assertEqual(self.save(id=99999).status_code, 404)
    def test_draft_and_archived_hidden_from_public_visible_to_managers(self):
        i, slug = self.mkitem(status="draft")
        self.assertEqual(self.app.test_client().get(f"/faith/lesson/{slug}").status_code, 404); self.assertEqual(self.client("alice").get(f"/faith/lesson/{slug}").status_code, 404)
        r = self.client("faither").get(f"/faith/lesson/{slug}"); self.assertEqual(r.status_code, 200); self.assertIn("Preview", r.data.decode()); self.assertIn("noindex", r.data.decode())
        self.assertNotIn(slug, self.app.test_client().get("/faith/browse").data.decode()); self.assertNotIn(slug, self.app.test_client().get("/sitemap.xml").data.decode())
        self.post(self.owner, f"/staff/faith/lesson/{i}/status", {"status": "published"}); self.assertEqual(self.app.test_client().get(f"/faith/lesson/{slug}").status_code, 200)
        self.assertIn(f"/faith/lesson/{slug}", self.app.test_client().get("/sitemap.xml").data.decode())
        self.post(self.owner, f"/staff/faith/lesson/{i}/status", {"status": "archived"}); self.assertEqual(self.app.test_client().get(f"/faith/lesson/{slug}").status_code, 404)
    def test_cannot_publish_empty_lesson_from_list_button(self):
        i, _ = self.mkitem(status="draft", kind="video", body=""); self.post(self.owner, f"/staff/faith/lesson/{i}/status", {"status": "published"}); self.assertEqual(self.val("SELECT status FROM faith_items WHERE id=?", (i,)), "draft")
    def test_delete_removes_files_and_progress(self):
        v = self.up(self.owner, mp4(), "v.mp4", "video"); self.assertTrue(v["ok"], v); a = self.up(self.owner, mp3(), "a.mp3", "audio"); self.assertTrue(a["ok"], a)
        i, _ = self.mkitem(kind="video", video_file=v["file"], video_name="v.mp4", audio_file=a["file"], audio_name="a.mp3")
        dbm.ex("INSERT INTO faith_progress(user_id,item_id) VALUES (?,?)", (self.users["alice"], i))
        for n in (v["file"], a["file"]): self.assertTrue(os.path.exists(os.path.join(self.app.config["PRIVATE_DIR"], n)))
        self.post(self.owner, f"/staff/faith/lesson/{i}/delete")
        for n in (v["file"], a["file"]): self.assertFalse(os.path.exists(os.path.join(self.app.config["PRIVATE_DIR"], n)))
        self.assertEqual(self.val("SELECT COUNT(*) FROM faith_progress"), 0)
    def test_replacing_a_file_deletes_the_old_one(self):
        v1 = self.up(self.owner, mp4(), "v.mp4", "video"); i, _ = self.mkitem(kind="video", video_file=v1["file"])
        v2 = self.up(self.owner, mp4(4000), "w.mp4", "video"); self.assertTrue(self.save(id=i, kind="video", video_file=v2["file"]).get_json()["ok"])
        self.assertFalse(os.path.exists(os.path.join(self.app.config["PRIVATE_DIR"], v1["file"]))); self.assertTrue(os.path.exists(os.path.join(self.app.config["PRIVATE_DIR"], v2["file"])))
    def test_cannot_attach_someone_elses_or_wrong_kind_upload(self):
        v = self.up(self.owner, mp4(), "v.mp4", "video"); f = self.client("faither")
        self.assertEqual(self.save(f, kind="video", video_file=v["file"]).status_code, 400)                                       # uploaded by another user
        self.assertEqual(self.save(kind="audio", audio_file=v["file"]).status_code, 400)                                          # a video is not audio
    def test_old_unattached_cleanup_never_deletes_faith_files(self):
        from dagba.services import builder as B
        v = self.up(self.owner, mp4(), "v.mp4", "video"); i, _ = self.mkitem(kind="video", video_file=v["file"])
        dbm.ex("UPDATE uploads SET created_at=datetime('now','-5 day')"); B.init_upload({"id": self.users["owner"]}, "x.mp4", 100)
        self.assertTrue(os.path.exists(os.path.join(self.app.config["PRIVATE_DIR"], v["file"])))

class MediaUploadTests(FaithBase):
    def test_audio_upload_accepts_valid_and_rejects_bad(self):
        ok = self.up(self.owner, mp3(), "talk.mp3", "audio"); self.assertTrue(ok["ok"], ok); self.assertRegex(ok["file"], r"^[0-9a-f]{32}\.mp3$")
        bad = self.up(self.owner, b"<?php echo 1;?>" + b"0" * 100, "evil.mp3", "audio"); self.assertFalse(bad["ok"])
        self.assertFalse(self.up(self.owner, mp4(), "x.mp3", "audio")["ok"])                                                       # mp4 bytes named mp3
        r = jpost(self.owner, self, "/staff/faith/upload/init", {"name": "x.exe", "size": 10, "kind": "audio"}); self.assertEqual(r.status_code, 400)
        S.put("faith.audio_max_mb", "5"); r = jpost(self.owner, self, "/staff/faith/upload/init", {"name": "x.mp3", "size": 6 * 1024 * 1024, "kind": "audio"}); self.assertEqual(r.status_code, 400)
    def test_other_audio_formats_by_signature(self):
        wav = b"RIFF\x24\x00\x00\x00WAVEfmt " + b"\x00" * 200; ogg = b"OggS\x00\x02" + b"\x00" * 200; m4a = b"\x00\x00\x00\x20ftypM4A " + b"\x00" * 200
        for name, d in (("a.wav", wav), ("a.ogg", ogg), ("a.oga", ogg), ("a.m4a", m4a)): self.assertTrue(self.up(self.owner, d, name, "audio")["ok"], name)
    def test_existing_video_upload_endpoint_still_video_only(self):
        c = self.client("inst"); r = jpost(c, self, "/staff/builder/upload/init", {"name": "a.mp3", "size": 100}); self.assertEqual(r.status_code, 400)
    def test_study_material_and_cover(self):
        r = self.owner.post("/staff/faith/resource", data={"_csrf": self.tok(self.owner), "file": (io.BytesIO(PDF), "guide.pdf")}, content_type="multipart/form-data").get_json(); self.assertTrue(r["ok"], r)
        c = self.owner.post("/staff/faith/cover", data={"_csrf": self.tok(self.owner), "file": (io.BytesIO(png_bytes()), "c.png")}, content_type="multipart/form-data").get_json(); self.assertTrue(c["ok"], c)
        i, slug = self.mkitem(kind="study", body="", resource_file=r["file"], resource_name="guide.pdf", thumbnail=c["file"])
        t = self.app.test_client().get(f"/faith/lesson/{slug}").data.decode(); self.assertIn("guide.pdf", t); self.assertIn(c["file"], t)
        d = self.app.test_client().get(f"/faith/resource/{i}?dl=1"); self.assertEqual(d.status_code, 200); self.assertEqual(d.data, PDF)
        self.assertEqual(self.owner.post("/staff/faith/resource", data={"_csrf": self.tok(self.owner), "file": (io.BytesIO(b"MZ\x90"), "x.exe")}, content_type="multipart/form-data").status_code, 400)
    def test_download_can_be_switched_off(self):
        r = self.owner.post("/staff/faith/resource", data={"_csrf": self.tok(self.owner), "file": (io.BytesIO(PDF), "g.pdf")}, content_type="multipart/form-data").get_json()
        i, slug = self.mkitem(kind="study", body="", resource_file=r["file"], downloadable=False)
        self.assertEqual(self.app.test_client().get(f"/faith/resource/{i}").status_code, 404); self.assertEqual(self.client("faither").get(f"/faith/resource/{i}").status_code, 200)
    def test_streaming_with_range_for_video_and_audio(self):
        v = self.up(self.owner, mp4(), "v.mp4", "video"); a = self.up(self.owner, mp3(), "a.mp3", "audio")
        i, slug = self.mkitem(kind="video", video_file=v["file"], audio_file=a["file"])
        c = self.app.test_client()
        r = c.get(f"/faith/media/{i}/video", headers={"Range": "bytes=0-9"}); self.assertEqual(r.status_code, 206); self.assertEqual(r.data, mp4()[:10]); self.assertEqual(r.mimetype, "video/mp4")
        r = c.get(f"/faith/media/{i}/audio", headers={"Range": "bytes=2-5"}); self.assertEqual(r.status_code, 206); self.assertEqual(r.mimetype, "audio/mpeg")
        t = c.get(f"/faith/lesson/{slug}").data.decode(); self.assertIn("<video", t); self.assertIn("<audio", t)
    def test_private_files_not_reachable_directly(self):
        v = self.up(self.owner, mp4(), "v.mp4", "video"); self.assertEqual(self.app.test_client().get("/static/" + v["file"]).status_code, 404)

class AccessRuleTests(FaithBase):
    def test_members_only_lesson_is_gated_for_visitors(self):
        v = self.up(self.owner, mp4(), "v.mp4", "video"); i, slug = self.mkitem(kind="video", video_file=v["file"], access="members", title="Members Talk", body="SECRET NOTES")
        g = self.app.test_client(); t = g.get(f"/faith/lesson/{slug}").data.decode()
        self.assertIn("Members Talk", t); self.assertIn("Members only", t); self.assertNotIn("SECRET NOTES", t); self.assertNotIn("<video", t)
        self.assertEqual(g.get(f"/faith/media/{i}/video").status_code, 403); self.assertNotIn(slug, g.get("/sitemap.xml").data.decode())
        a = self.client("alice"); t = a.get(f"/faith/lesson/{slug}").data.decode(); self.assertIn("SECRET NOTES", t); self.assertIn("<video", t); self.assertEqual(a.get(f"/faith/media/{i}/video").status_code, 200)
    def test_public_lesson_open_to_visitors_without_progress_tracking(self):
        i, slug = self.mkitem(); g = self.app.test_client(); self.assertEqual(g.get(f"/faith/lesson/{slug}").status_code, 200)
        self.assertEqual(self.val("SELECT COUNT(*) FROM faith_progress"), 0)
        for u in (f"/faith/lesson/{i}/complete", f"/faith/lesson/{i}/save", f"/faith/lesson/{i}/progress"): self.assertEqual(self.post(g, u).status_code, 302, u)   # login required
    def test_unpublished_media_not_served_to_public(self):
        v = self.up(self.owner, mp4(), "v.mp4", "video"); i, _ = self.mkitem(kind="video", video_file=v["file"], status="draft")
        self.assertEqual(self.app.test_client().get(f"/faith/media/{i}/video").status_code, 404); self.assertEqual(self.client("alice").get(f"/faith/media/{i}/video").status_code, 404); self.assertEqual(self.client("faither").get(f"/faith/media/{i}/video").status_code, 200)
    def test_no_payment_needed_and_courses_unaffected(self):
        i, slug = self.mkitem(); self.assertEqual(self.client("alice").get(f"/faith/lesson/{slug}").status_code, 200)
        self.assertEqual(self.val("SELECT COUNT(*) FROM transactions"), 0)

class ProgressTests(FaithBase):
    def setUp(self):
        super().setUp()
        s = dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status) VALUES (?,?,?,?)", (self.topic, "Learning to Pray", "learning-to-pray", "published"))
        self.ids = []
        for n, t in enumerate(("One", "Two", "Three")): self.ids.append(self.mkitem(title=t, series_id=s, position=n + 1)[0])
        self.s = s; self.a = self.client("alice")
    def test_visit_creates_progress_complete_advances_and_undo(self):
        slugs = [self.val("SELECT slug FROM faith_items WHERE id=?", (i,)) for i in self.ids]
        self.a.get(f"/faith/lesson/{slugs[0]}"); self.assertEqual(self.val("SELECT COUNT(*) FROM faith_progress WHERE user_id=?", (self.users["alice"],)), 1)
        r = self.post(self.a, f"/faith/lesson/{self.ids[0]}/complete"); self.assertEqual(r.status_code, 302); self.assertTrue(r.headers["Location"].endswith(slugs[1]))
        self.assertTrue(self.val("SELECT completed_at FROM faith_progress WHERE user_id=? AND item_id=?", (self.users["alice"], self.ids[0])))
        self.post(self.a, f"/faith/lesson/{self.ids[0]}/complete", {"undo": "1"}); self.assertIsNone(self.val("SELECT completed_at FROM faith_progress WHERE user_id=? AND item_id=?", (self.users["alice"], self.ids[0])))
    def test_series_progress_and_finishing(self):
        for i in self.ids[:2]: self.post(self.a, f"/faith/lesson/{i}/complete")
        t = self.a.get("/faith/series/learning-to-pray").data.decode(); self.assertIn("66%", t); self.assertIn("2/3", t)
        r = self.post(self.a, f"/faith/lesson/{self.ids[2]}/complete"); self.assertTrue(r.headers["Location"].endswith("/faith/series/learning-to-pray"))
        self.assertEqual(F.series_progress(self.users["alice"], self.s)["percent"], 100)
    def test_progress_is_per_user(self):
        self.post(self.a, f"/faith/lesson/{self.ids[0]}/complete"); self.assertEqual(F.series_progress(self.users["bob"], self.s)["done"], 0)
    def test_resume_position_and_continue_lists(self):
        slug = self.val("SELECT slug FROM faith_items WHERE id=?", (self.ids[1],)); self.a.get(f"/faith/lesson/{slug}")
        r = self.post(self.a, f"/faith/lesson/{self.ids[1]}/progress", {"position": "125"}); self.assertEqual(r.get_json(), {"ok": True})
        self.assertEqual(self.val("SELECT position_seconds FROM faith_progress WHERE user_id=? AND item_id=?", (self.users["alice"], self.ids[1])), 125)
        self.post(self.a, f"/faith/lesson/{self.ids[1]}/progress", {"position": "-5"}); self.assertEqual(self.val("SELECT position_seconds FROM faith_progress WHERE item_id=?", (self.ids[1],)), 0)
        self.assertIn("Two", self.a.get("/faith/my").data.decode()); self.assertIn("Continue where you left off", self.a.get("/faith").data.decode()); self.assertIn("Two", self.a.get("/student").data.decode())
    def test_save_for_later_toggles(self):
        self.post(self.a, f"/faith/lesson/{self.ids[0]}/save"); self.assertEqual(self.val("SELECT COUNT(*) FROM faith_saved"), 1)
        self.assertIn("One", self.a.get("/faith/my").data.decode()); self.post(self.a, f"/faith/lesson/{self.ids[0]}/save"); self.assertEqual(self.val("SELECT COUNT(*) FROM faith_saved"), 0)
    def test_fetch_requests_get_json(self):
        r = self.a.post(f"/faith/lesson/{self.ids[0]}/complete", data={"_csrf": self.tok(self.a)}, headers={"X-Requested-With": "fetch"}); self.assertEqual(r.get_json(), {"ok": True, "done": True})
    def test_cannot_touch_unpublished_or_unknown(self):
        d, _ = self.mkitem(status="draft", title="Hidden"); self.assertEqual(self.post(self.a, f"/faith/lesson/{d}/complete").status_code, 403); self.assertEqual(self.post(self.a, "/faith/lesson/99999/save").status_code, 404)
    def test_deleting_user_or_lesson_cleans_up(self):
        self.post(self.a, f"/faith/lesson/{self.ids[0]}/complete"); dbm.ex("DELETE FROM users WHERE id=?", (self.users["alice"],)); self.assertEqual(self.val("SELECT COUNT(*) FROM faith_progress"), 0)
    def test_series_page_for_visitors_and_ordering(self):
        t = self.app.test_client().get("/faith/series/learning-to-pray").data.decode(); self.assertTrue(t.index("One") < t.index("Two") < t.index("Three"))
    def test_dashboard_link_in_student_menu(self):
        self.assertIn("/faith/my", self.a.get("/student").data.decode())

class BrowseAndSearchTests(FaithBase):
    def test_filters(self):
        self.mkitem(title="Prayer Basics", summary="how to pray"); self.mkitem(title="Wisdom Talk", kind="audio", audio_url="https://x.example/a.mp3", topic_id=self.val("SELECT id FROM faith_topics WHERE slug='biblical-wisdom'"), speaker="Pastor Ade")
        c = self.app.test_client()
        t = c.get("/faith/browse?q=pastor").data.decode(); self.assertIn("Wisdom Talk", t); self.assertNotIn("Prayer Basics", t)
        t = c.get("/faith/browse?kind=audio").data.decode(); self.assertIn("Wisdom Talk", t); self.assertNotIn("Prayer Basics", t)
        t = c.get("/faith/topic/prayer").data.decode(); self.assertIn("Prayer Basics", t); self.assertNotIn("Wisdom Talk", t)
        self.assertEqual(c.get("/faith/browse?kind=zzz&topic=%27%3B--&q=%25").status_code, 200)
    def test_hostile_text_is_escaped(self):
        self.mkitem(title="<script>alert(1)</script>", body="<img src=x onerror=alert(1)>"); t = self.app.test_client().get("/faith/browse").data.decode()
        self.assertNotIn("<script>alert(1)", t); self.assertIn("&lt;script&gt;", t)

class SeriesAndTopicAdminTests(FaithBase):
    def test_series_and_topic_crud_via_standard_admin_screens(self):
        r = self.post(self.owner, "/staff/r/faith-series/new", {"topic_id": self.topic, "title": "Prayer 101", "summary": "s", "status": "published"}); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.val("SELECT slug FROM faith_series WHERE title='Prayer 101'"), "prayer-101")
        r = self.post(self.owner, "/staff/r/faith-topics/new", {"name": "Worship", "active": "1", "position": "7"}); self.assertEqual(r.status_code, 302); self.assertTrue(self.val("SELECT 1 FROM faith_topics WHERE slug='worship'"))
        self.assertIn("Worship", self.app.test_client().get("/faith").data.decode())
    def test_topic_with_content_cannot_be_deleted_or_hidden(self):
        self.mkitem(); r = self.post(self.owner, f"/staff/r/faith-topics/{self.topic}/delete"); self.assertEqual(self.val("SELECT COUNT(*) FROM faith_topics WHERE id=?", (self.topic,)), 1)
        r = self.post(self.owner, f"/staff/r/faith-topics/{self.topic}/edit", {"name": "Prayer", "position": "2"}); self.assertEqual(self.val("SELECT active FROM faith_topics WHERE id=?", (self.topic,)), 1)
    def test_deleting_series_keeps_lessons(self):
        s = dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status) VALUES (?,?,?,?)", (self.topic, "T", "t", "published")); i, slug = self.mkitem(series_id=s)
        self.post(self.owner, f"/staff/r/faith-series/{s}/delete"); self.assertIsNone(self.val("SELECT series_id FROM faith_items WHERE id=?", (i,))); self.assertEqual(self.app.test_client().get(f"/faith/lesson/{slug}").status_code, 200)
    def test_series_with_no_published_lessons_is_not_listed(self):
        dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status) VALUES (?,?,?,?)", (self.topic, "Empty Series", "empty-series", "published"))
        self.assertNotIn("Empty Series", self.app.test_client().get("/faith").data.decode()); self.assertNotIn("Empty Series", self.app.test_client().get("/faith/topic/prayer").data.decode())

class AdminPagesTests(FaithBase):
    def test_pages_render_with_content(self):
        i, slug = self.mkitem()
        for u in ("/staff/faith/", "/staff/faith/lessons", "/staff/faith/lessons?status=published&kind=reading&q=pray", f"/staff/faith/lesson/{i}", "/staff/faith/lesson/new?topic=3", "/staff/settings/faith", "/staff/settings/c_faith"):
            self.assertEqual(self.owner.get(u).status_code, 200, u)
        self.assertIn("Published Faith lessons", self.owner.get("/staff/").data.decode())
    def test_faith_settings_validation_and_text_editor(self):
        r = self.post(self.owner, "/staff/settings/faith", {"faith.audio_max_mb": "2"}); self.assertEqual(S.get("faith.audio_max_mb"), "200")
        self.post(self.owner, "/staff/settings/faith", {"faith.audio_max_mb": "300"}); self.assertEqual(S.get("faith.audio_max_mb"), "300")
        f = self.client("faither"); self.assertEqual(f.get("/staff/settings/faith").status_code, 200); self.assertEqual(f.get("/staff/settings/c_faith").status_code, 403)
        self.post(self.owner, "/staff/settings/c_faith", {"c.faith.title": "Faith Hub"}); self.assertIn("Faith Hub", self.app.test_client().get("/faith").data.decode())
    def test_audit_trail(self):
        i, _ = self.mkitem(); self.post(self.owner, f"/staff/faith/lesson/{i}/delete"); self.assertTrue(self.val("SELECT 1 FROM audit_logs WHERE action='faith.save'")); self.assertTrue(self.val("SELECT 1 FROM audit_logs WHERE action='faith.delete'"))

class PaidCourseTests(FaithBase):
    """A Faith series is a paid course: bought through the normal checkout, verified by staff, locked until then."""
    def setUp(self):
        super().setUp()
        self.sid = dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status,price_kobo) VALUES (?,?,?,?,?)", (self.topic, "Learning to Pray", "learning-to-pray", "published", 500000))
        self.free = self.mkitem(title="Welcome", series_id=self.sid, access="public")
        self.paid = self.mkitem(title="Lesson Two", series_id=self.sid, access="members", body="SECRET TEACHING TEXT")
        self.alice = self.client("alice"); self.anon = self.app.test_client()
    def buy_series(self, c=None, promo="", submit=True):
        c = c or self.alice
        r = self.post(c, "/checkout/faith/learning-to-pray", {"action": "pay", "promo": promo}); self.assertEqual(r.status_code, 302, r.data[:200])
        ref = r.headers["Location"].rsplit("/", 1)[-1]
        if submit: self.assertEqual(self.upload(c, ref).status_code, 302)
        return ref
    def approve(self, ref):
        t = self.tx(ref); o = self.client("officer")
        self.assertEqual(self.post(o, f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}).status_code, 302)
    def test_free_preview_open_paid_lesson_locked_for_everyone_without_purchase(self):
        for c in (self.anon, self.alice):
            self.assertIn("Welcome", c.get("/faith/lesson/" + self.free[1]).data.decode())
            r = c.get("/faith/lesson/" + self.paid[1]); t = r.data.decode()
            self.assertEqual(r.status_code, 200); self.assertNotIn("SECRET TEACHING TEXT", t); self.assertIn("Enrol in this course", t if c is self.alice else "Enrol in this course" if "Log in to enrol" in t else t)
        self.assertIn("5,000", self.anon.get("/faith/series/learning-to-pray").data.decode())
    def test_locked_media_resource_and_actions_refused(self):
        j = self.up(self.owner, mp3(), "a.mp3", "audio"); self.assertTrue(j["ok"], j)
        iid, slug = self.mkitem(title="Audio two", series_id=self.sid, access="members", kind="audio", audio_file=j["file"], audio_name="a.mp3")
        for c in (self.anon, self.alice): self.assertEqual(c.get(f"/faith/media/{iid}/audio").status_code, 403)
        self.assertEqual(self.post(self.alice, f"/faith/lesson/{iid}/complete").status_code, 403)
        self.assertEqual(self.post(self.alice, f"/faith/lesson/{iid}/progress", {"position": 5}).status_code, 403)
        self.assertEqual(self.val("SELECT COUNT(*) FROM faith_progress WHERE item_id=?", (iid,)), 0)
        self.assertEqual(self.owner.get(f"/faith/media/{iid}/audio").status_code, 200)               # managers can always open
    def test_purchase_flow_unlocks_only_after_staff_approval(self):
        ref = self.buy_series(); t = self.tx(ref)
        self.assertEqual((t["item_type"], t["faith_series_id"], t["amount_kobo"], t["course_id"]), ("faith", self.sid, 500000, None))
        self.assertNotIn("SECRET TEACHING TEXT", self.alice.get("/faith/lesson/" + self.paid[1]).data.decode())     # pending is not access
        self.approve(ref)
        self.assertEqual(self.tx(ref)["status"], "approved"); self.assertEqual(self.val("SELECT COUNT(*) FROM faith_access WHERE user_id=? AND series_id=?", (self.users["alice"], self.sid)), 1)
        self.assertIn("SECRET TEACHING TEXT", self.alice.get("/faith/lesson/" + self.paid[1]).data.decode())
        self.assertIn("SECRET TEACHING TEXT", self.client("alice").get("/faith/lesson/" + self.paid[1]).data.decode())
        self.assertNotIn("SECRET TEACHING TEXT", self.client("bob").get("/faith/lesson/" + self.paid[1]).data.decode())   # someone else's purchase
        self.assertEqual(self.post(self.alice, f"/faith/lesson/{self.paid[0]}/complete").status_code, 302)
        self.assertIn("My faith courses", self.alice.get("/faith/my").data.decode())
        self.assertEqual(self.post(self.alice, "/checkout/faith/learning-to-pray", {"action": "pay"}).status_code, 200)  # already owns: told so, no new transaction
        self.assertEqual(self.val("SELECT COUNT(*) FROM transactions WHERE item_type='faith'"), 1)
    def test_refund_revokes_access(self):
        ref = self.buy_series(); self.approve(ref); t = self.tx(ref)
        self.assertEqual(self.post(self.client("refunder"), f"/staff/payments/{t['id']}", {"action": "refund", "confirm": "1", "text": "requested"}).status_code, 302)
        self.assertEqual(self.tx(ref)["status"], "refunded")
        self.assertNotIn("SECRET TEACHING TEXT", self.alice.get("/faith/lesson/" + self.paid[1]).data.decode())
    def test_promo_and_full_discount_grants_directly(self):
        dbm.ex("INSERT INTO promos(code,percent_off,applies_to,active) VALUES ('FREE100',100,'courses',1)")
        ref = self.buy_series(promo="FREE100", submit=False); self.assertEqual(self.tx(ref)["status"], "approved")
        self.assertIn("SECRET TEACHING TEXT", self.alice.get("/faith/lesson/" + self.paid[1]).data.decode())
        dbm.ex("INSERT INTO promos(code,percent_off,applies_to,active) VALUES ('PLANONLY',50,'plans',1)")
        r = self.post(self.client("bob"), "/checkout/faith/learning-to-pray", {"action": "pay", "promo": "PLANONLY"}); self.assertEqual(r.status_code, 302)   # plan-only code is ignored: full price, never a discount
        self.assertEqual(self.row("SELECT discount_kobo, amount_kobo FROM transactions WHERE user_id=? AND item_type='faith'", (self.users["bob"],))["amount_kobo"], 500000)
    def test_limited_days_access_expires(self):
        dbm.ex("UPDATE faith_series SET access_policy='days', access_days=30 WHERE id=?", (self.sid,))
        ref = self.buy_series(); self.approve(ref); a = self.row("SELECT * FROM faith_access"); self.assertTrue(a["expires_at"])
        dbm.ex("UPDATE faith_access SET expires_at='2000-01-01 00:00:00'")
        self.assertNotIn("SECRET TEACHING TEXT", self.alice.get("/faith/lesson/" + self.paid[1]).data.decode())
    def test_free_series_and_standalone_lessons_unchanged(self):
        dbm.ex("UPDATE faith_series SET price_kobo=0 WHERE id=?", (self.sid,))
        self.assertIn("SECRET TEACHING TEXT", self.alice.get("/faith/lesson/" + self.paid[1]).data.decode())       # price 0: any signed-in learner
        self.assertNotIn("SECRET TEACHING TEXT", self.anon.get("/faith/lesson/" + self.paid[1]).data.decode())
        self.assertEqual(self.post(self.alice, "/checkout/faith/learning-to-pray", {"action": "pay"}).status_code, 302)   # nothing to buy: back to the series
        self.assertEqual(self.val("SELECT COUNT(*) FROM transactions WHERE item_type='faith'"), 0)
    def test_unpublished_series_cannot_be_bought_and_visitor_must_log_in(self):
        dbm.ex("UPDATE faith_series SET status='draft' WHERE id=?", (self.sid,))
        self.post(self.alice, "/checkout/faith/learning-to-pray", {"action": "pay"}); self.assertEqual(self.val("SELECT COUNT(*) FROM transactions WHERE item_type='faith'"), 0)
        self.assertEqual(self.anon.get("/checkout/faith/learning-to-pray").status_code, 302)
        self.assertEqual(self.anon.get("/checkout/faith/nope").status_code, 302)
    def test_staff_can_price_series_and_reports_show_sales(self):
        r = self.post(self.owner, f"/staff/r/faith-series/{self.sid}/edit", {"topic_id": self.topic, "title": "Learning to Pray", "price_kobo": "7500", "access_policy": "lifetime", "status": "published"}); self.assertEqual(r.status_code, 302, r.data[:200])
        self.assertEqual(self.val("SELECT price_kobo FROM faith_series WHERE id=?", (self.sid,)), 750000)
        ref = self.buy_series(); self.approve(ref)
        t = self.owner.get("/staff/faith/").data.decode(); self.assertIn("7,500", t)
        self.assertIn("Learning to Pray", self.owner.get(f"/staff/users/{self.users['alice']}").data.decode())

class TutorTests(FaithBase):
    """Faith series have instructors: tutors teach their own series, cannot publish, and earn the normal revenue share."""
    def setUp(self):
        super().setUp()
        self.inst = self.client("inst"); self.iid = self.users["inst"]
        self.mine = dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status,price_kobo,instructor_id) VALUES (?,?,?,?,?,?)", (self.topic, "Mine", "mine", "published", 500000, self.iid))
        self.theirs = dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status,price_kobo) VALUES (?,?,?,?,?)", (self.topic, "Theirs", "theirs", "published", 500000))
        self.alice = self.client("alice")
    def lesson(self, series, **kw):
        d = dict(title="Tutor lesson", topic_id=self.topic, series_id=series, kind="reading", body="text", access="members", status="published", featured=True); d.update(kw)
        return jpost(self.inst, self, "/staff/faith/save", d)
    def buy(self, slug):
        r = self.post(self.alice, f"/checkout/faith/{slug}", {"action": "pay"}); ref = r.headers["Location"].rsplit("/", 1)[-1]
        self.assertEqual(self.upload(self.alice, ref).status_code, 302); t = self.tx(ref)
        self.assertEqual(self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}).status_code, 302); return t
    def test_tutor_pages_and_scope(self):
        self.assertEqual(self.inst.get("/staff/faith/").status_code, 302)
        self.assertEqual(self.inst.get("/staff/faith/lessons").status_code, 200); self.assertEqual(self.inst.get("/staff/faith/lesson/new").status_code, 200)
        self.assertEqual(self.inst.get("/staff/r/faith-topics").status_code, 403)
        t = self.inst.get("/staff/r/faith-series").data.decode(); self.assertIn("Mine", t); self.assertNotIn("Theirs", t)
        self.assertNotIn("Theirs", self.inst.get("/staff/faith/lesson/new").data.decode())
        self.assertIn('href="/staff/faith/lessons"', self.inst.get("/staff/").data.decode())
    def test_tutor_saves_draft_only_in_own_series(self):
        j = self.lesson(self.mine).get_json(); self.assertTrue(j["ok"], j)
        row = self.row("SELECT * FROM faith_items WHERE id=?", (j["id"],)); self.assertEqual((row["status"], row["featured"], row["created_by"]), ("draft", 0, self.iid))   # cannot publish or feature
        self.assertTrue(self.val("SELECT 1 FROM notifications WHERE title='New Faith lesson from a tutor'"))
        r = self.lesson(self.theirs); self.assertEqual(r.status_code, 400)
        r = self.lesson(None); self.assertEqual(r.status_code, 400)
        self.assertEqual(self.app.test_client().get("/faith/lesson/" + row["slug"]).status_code, 404)    # draft stays hidden until an admin publishes
        self.assertEqual(self.post(self.inst, f"/staff/faith/lesson/{j['id']}/status", {"status": "published"}).status_code, 403)
        self.assertEqual(self.post(self.owner, f"/staff/faith/lesson/{j['id']}/status", {"status": "published"}).status_code, 302)
        self.assertEqual(self.app.test_client().get("/faith/lesson/" + row["slug"]).status_code, 200)
    def test_tutor_cannot_touch_other_tutors_lessons(self):
        i, slug = self.mkitem(series_id=self.theirs)
        self.assertEqual(self.inst.get(f"/staff/faith/lesson/{i}").status_code, 403)
        self.assertEqual(self.lesson(self.mine, id=i).status_code, 403)
        self.assertEqual(self.post(self.inst, f"/staff/faith/lesson/{i}/delete").status_code, 403)
        j = self.lesson(self.mine).get_json(); self.assertEqual(self.post(self.inst, f"/staff/faith/lesson/{j['id']}/delete").status_code, 302)   # own draft is deletable
    def test_tutor_series_creation_is_draft_and_owned(self):
        r = self.post(self.inst, "/staff/r/faith-series/new", {"topic_id": self.topic, "title": "My new course", "status": "draft", "price_kobo": "9999", "access_policy": "lifetime", "instructor_id": str(self.users["alice"])}); self.assertEqual(r.status_code, 302, r.data[:200])
        s = self.row("SELECT * FROM faith_series WHERE title='My new course'"); self.assertEqual((s["status"], s["instructor_id"], s["price_kobo"]), ("draft", self.iid, 999900))   # tutor sets the price; publishing and assigning stay with admins
    def test_tutor_can_change_price_of_own_series_only_and_admin_is_told(self):
        r = self.post(self.inst, f"/staff/r/faith-series/{self.mine}/edit", {"topic_id": self.topic, "title": "Mine", "price_kobo": "3000", "access_policy": "days", "access_days": "60", "status": "draft"}); self.assertEqual(r.status_code, 302, r.data[:200])
        s = self.row("SELECT * FROM faith_series WHERE id=?", (self.mine,)); self.assertEqual((s["price_kobo"], s["access_policy"], s["access_days"], s["status"]), (300000, "days", 60, "published"))   # published stays published
        self.assertTrue(self.val("SELECT 1 FROM notifications WHERE title='Tutor changed a Faith course price'"))
        self.assertIn(self.post(self.inst, f"/staff/r/faith-series/{self.theirs}/edit", {"topic_id": self.topic, "title": "Theirs", "price_kobo": "1", "status": "draft"}).status_code, (403, 404))
        self.assertEqual(self.val("SELECT price_kobo FROM faith_series WHERE id=?", (self.theirs,)), 500000)
    def test_sale_credits_the_series_tutor_and_refund_reverses(self):
        t = self.buy("mine"); e = self.row("SELECT * FROM instructor_earnings")
        self.assertEqual((e["instructor_id"], e["faith_series_id"], e["course_id"], e["kind"], e["gross_kobo"], e["amount_kobo"]), (self.iid, self.mine, None, "sale", 500000, 200000))
        page = self.inst.get("/staff/earnings"); self.assertEqual(page.status_code, 200); self.assertIn("Mine", page.data.decode())
        self.assertEqual(self.inst.get("/staff/earnings/export.csv").status_code, 200)
        self.assertEqual(self.post(self.client("refunder"), f"/staff/payments/{t['id']}", {"action": "refund", "confirm": "1", "text": "x"}).status_code, 302)
        self.assertEqual(self.val("SELECT COALESCE(SUM(amount_kobo),0) FROM instructor_earnings WHERE instructor_id=?", (self.iid,)), 0)
        self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings WHERE kind='reversal' AND faith_series_id=?", (self.mine,)), 1)
        self.assertEqual(self.owner.get("/staff/payouts").status_code, 200); r = self.owner.get("/staff/payouts/instructors"); self.assertEqual(r.status_code, 200); self.assertIn("inst", r.data.decode().lower())
    def test_series_without_tutor_creates_no_earning(self):
        self.buy("theirs"); self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings"), 0)
    def test_public_series_page_names_the_tutor(self):
        self.assertIn("Taught by", self.app.test_client().get("/faith/series/mine").data.decode())
    def test_admin_can_assign_instructor(self):
        r = self.post(self.owner, f"/staff/r/faith-series/{self.theirs}/edit", {"topic_id": self.topic, "title": "Theirs", "price_kobo": "5000", "access_policy": "lifetime", "status": "published", "instructor_id": str(self.iid)}); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.val("SELECT instructor_id FROM faith_series WHERE id=?", (self.theirs,)), self.iid)

class TopicPriceTests(FaithBase):
    """A topic can be sold as a bundle: owning it unlocks every course-content lesson in the topic, in any series or none."""
    def setUp(self):
        super().setUp()
        dbm.ex("UPDATE faith_topics SET price_kobo=800000 WHERE id=?", (self.topic,))
        self.sid = dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status,price_kobo) VALUES (?,?,?,?,?)", (self.topic, "Series A", "series-a", "published", 300000))
        self.free_s = dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status) VALUES (?,?,?,?)", (self.topic, "Free series", "free-series", "published"))
        self.in_series = self.mkitem(title="In paid series", series_id=self.sid, access="members", body="SERIES SECRET")
        self.in_free = self.mkitem(title="In free series", series_id=self.free_s, access="members", body="FREE SERIES SECRET")
        self.loose = self.mkitem(title="Loose lesson", access="members", body="LOOSE SECRET")
        self.preview = self.mkitem(title="Preview", access="public", body="PREVIEW TEXT")
        self.alice = self.client("alice"); self.anon = self.app.test_client()
    def see(self, c, item): return c.get("/faith/lesson/" + item[1]).data.decode()
    def buy_topic(self, c=None, promo=""):
        c = c or self.alice
        r = self.post(c, "/checkout/faith-topic/prayer", {"action": "pay", "promo": promo}); self.assertEqual(r.status_code, 302, r.data[:200])
        ref = r.headers["Location"].rsplit("/", 1)[-1]
        if self.tx(ref)["status"] != "approved": self.assertEqual(self.upload(c, ref).status_code, 302)
        return ref
    def approve(self, ref):
        t = self.tx(ref); self.assertEqual(self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}).status_code, 302)
    def test_everything_locked_until_topic_bought_standalone_lessons_included(self):
        for it, secret in ((self.in_series, "SERIES SECRET"), (self.in_free, "FREE SERIES SECRET"), (self.loose, "LOOSE SECRET")): self.assertNotIn(secret, self.see(self.alice, it))
        self.assertIn("PREVIEW TEXT", self.see(self.anon, self.preview))
        ref = self.buy_topic(); t = self.tx(ref); self.assertEqual((t["item_type"], t["faith_topic_id"], t["faith_series_id"], t["amount_kobo"]), ("faith_topic", self.topic, None, 800000))
        self.assertNotIn("LOOSE SECRET", self.see(self.alice, self.loose))          # pending is not access
        self.approve(ref)
        for it, secret in ((self.in_series, "SERIES SECRET"), (self.in_free, "FREE SERIES SECRET"), (self.loose, "LOOSE SECRET")): self.assertIn(secret, self.see(self.alice, it))
        self.assertNotIn("LOOSE SECRET", self.see(self.client("bob"), self.loose))
        self.assertIn("You have the whole topic", self.alice.get("/faith/topic/prayer").data.decode()); self.assertIn("Prayer", self.alice.get("/faith/my").data.decode())
        self.assertEqual(self.post(self.alice, "/checkout/faith-topic/prayer", {"action": "pay"}).status_code, 200)       # already owns
        self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings"), 0)
    def test_series_purchase_still_works_alongside_a_priced_topic(self):
        r = self.post(self.alice, "/checkout/faith/series-a", {"action": "pay"}); ref = r.headers["Location"].rsplit("/", 1)[-1]; self.upload(self.alice, ref); self.approve(ref)
        self.assertIn("SERIES SECRET", self.see(self.alice, self.in_series)); self.assertNotIn("LOOSE SECRET", self.see(self.alice, self.loose)); self.assertNotIn("FREE SERIES SECRET", self.see(self.alice, self.in_free))
    def test_locked_page_offers_both_options_and_media_is_protected(self):
        t = self.see(self.alice, self.in_series); self.assertIn("/checkout/faith/series-a", t); self.assertIn("/checkout/faith-topic/prayer", t)
        t = self.see(self.alice, self.loose); self.assertIn("/checkout/faith-topic/prayer", t); self.assertNotIn("/checkout/faith/", t)
        j = self.up(self.owner, mp3(), "a.mp3", "audio"); iid, slug = self.mkitem(title="Aud", access="members", kind="audio", audio_file=j["file"], audio_name="a.mp3")
        self.assertEqual(self.alice.get(f"/faith/media/{iid}/audio").status_code, 403)
        self.approve(self.buy_topic()); self.assertEqual(self.alice.get(f"/faith/media/{iid}/audio").status_code, 200)
    def test_refund_revokes_topic_access(self):
        ref = self.buy_topic(); self.approve(ref); t = self.tx(ref)
        self.assertEqual(self.post(self.client("refunder"), f"/staff/payments/{t['id']}", {"action": "refund", "confirm": "1", "text": "x"}).status_code, 302)
        self.assertNotIn("LOOSE SECRET", self.see(self.alice, self.loose))
    def test_limited_days_and_full_discount(self):
        dbm.ex("UPDATE faith_topics SET access_policy='days', access_days=30 WHERE id=?", (self.topic,))
        self.approve(self.buy_topic()); self.assertTrue(self.val("SELECT expires_at FROM faith_access WHERE topic_id=?", (self.topic,)))
        dbm.ex("UPDATE faith_access SET expires_at='2000-01-01 00:00:00'"); self.assertNotIn("LOOSE SECRET", self.see(self.alice, self.loose))
        dbm.ex("INSERT INTO promos(code,percent_off,applies_to,active) VALUES ('ALLFREE',100,'courses',1)")
        ref = self.buy_topic(self.client("bob"), "ALLFREE"); self.assertEqual(self.tx(ref)["status"], "approved"); self.assertIn("LOOSE SECRET", self.see(self.client("bob"), self.loose))
    def test_free_topic_cannot_be_bought_and_admin_sets_price(self):
        dbm.ex("UPDATE faith_topics SET price_kobo=0 WHERE id=?", (self.topic,)); self.post(self.alice, "/checkout/faith-topic/prayer", {"action": "pay"})
        self.assertEqual(self.val("SELECT COUNT(*) FROM transactions WHERE item_type='faith_topic'"), 0)
        r = self.post(self.owner, f"/staff/r/faith-topics/{self.topic}/edit", {"name": "Prayer", "position": "2", "active": "1", "price_kobo": "12000", "access_policy": "lifetime"}); self.assertEqual(r.status_code, 302, r.data[:200])
        self.assertEqual(self.val("SELECT price_kobo FROM faith_topics WHERE id=?", (self.topic,)), 1200000)
        self.assertEqual(self.client("inst").get("/staff/r/faith-topics").status_code, 403)
        self.assertIn("12,000", self.app.test_client().get("/faith/topic/prayer").data.decode())
        self.assertEqual(self.app.test_client().get("/checkout/faith-topic/prayer").status_code, 302)
    def test_staff_user_page_and_reports_include_topic_sales(self):
        self.approve(self.buy_topic()); self.assertIn("Prayer (topic)", self.owner.get(f"/staff/users/{self.users['alice']}").data.decode())
        self.assertIn("8,000", self.owner.get("/staff/faith/").data.decode())

class UpgradeTests(Base):
    """A site that already exists (settings saved, uploads recorded) is upgraded without losing anything."""
    def old_site(self, d, settings):
        old = os.path.join(d, "mig"); os.makedirs(old)
        for f in sorted(os.listdir(MIG)):
            if f < "006": shutil.copy(os.path.join(MIG, f), old)
        path = os.path.join(d, "old.db"); dbm.migrate(path, old); c = sqlite3.connect(path)
        c.execute("INSERT INTO users(id,email,password_hash,full_name) VALUES (1,'a@b.c','x','A')")
        c.execute("INSERT INTO uploads(id,user_id,kind,original_name,size,status,stored_name) VALUES ('u1',1,'video','v.mp4',10,'ready','abc.mp4')")
        c.execute("INSERT INTO courses(id,division,title,slug,price_kobo,status) VALUES (1,'income','C','c',100000,'published')")
        c.execute("INSERT INTO transactions(id,reference,user_id,item_type,course_id,item_title,list_price_kobo,amount_kobo,status) VALUES (7,'REF7',1,'course',1,'C',100000,100000,'approved')")
        c.execute("INSERT INTO payment_evidence(transaction_id,file,mime,size) VALUES (7,'r.png','image/png',3)")
        c.execute("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at,transaction_id) VALUES (1,'course',1,'income','2026-01-01 00:00:00',7)")
        for k, v in settings.items(): c.execute("INSERT INTO settings(key,value) VALUES (?,?)", (k, v))
        c.commit(); c.close(); return path
    def test_upgrade_adds_menu_item_once_and_keeps_uploads(self):
        d = tempfile.mkdtemp(); path = self.old_site(d, {"c.nav.header": "Courses | /courses\r\nPricing | /pricing\r\nContact | /contact", "c.nav.footer_explore": "Courses | /courses"})
        self.assertEqual(dbm.migrate(path, MIG), ["006_faith.sql", "007_faith_paid.sql", "008_faith_instructors.sql", "009_faith_topic_prices.sql", "010_pricing_structure.sql", "011_basic_category_featured.sql", "012_basic_category_image.sql", "013_faith_topic_visuals.sql", "014_faith_tutor_topics.sql", "015_hero_slides.sql", "016_tutor_program.sql", "017_professional_division.sql", "018_professional_navigation.sql", "019_subject_pricing_all_divisions.sql", "020_division_separation.sql", "021_tutor_mou.sql", "022_prelaunch.sql", "023_learning_objectives.sql", "024_interactive_learning.sql", "025_mobile_api.sql", "026_store_billing.sql"]); self.assertEqual(dbm.migrate(path, MIG), [])
        c = sqlite3.connect(path); h = c.execute("SELECT value FROM settings WHERE key='c.nav.header'").fetchone()[0]
        self.assertEqual(h.count("/faith"), 1); self.assertLess(h.index("/faith"), h.index("/pricing")); self.assertIn("Contact | /contact", h)
        self.assertEqual(c.execute("SELECT value FROM settings WHERE key='c.nav.footer_explore'").fetchone()[0].count("/faith"), 1)
        self.assertEqual(c.execute("SELECT reference,status,amount_kobo FROM transactions WHERE id=7").fetchone(), ("REF7", "approved", 100000))          # existing payments survive the rebuild
        self.assertEqual(c.execute("SELECT COUNT(*) FROM payment_evidence WHERE transaction_id=7").fetchone()[0], 1); self.assertEqual(c.execute("SELECT transaction_id FROM entitlements").fetchone()[0], 7)
        self.assertEqual(c.execute("PRAGMA foreign_key_check").fetchall(), [])
        self.assertEqual(c.execute("SELECT stored_name FROM uploads WHERE id='u1'").fetchone()[0], "abc.mp4"); self.assertEqual(c.execute("SELECT COUNT(*) FROM faith_topics").fetchone()[0], 6)
        c.execute("INSERT INTO uploads(id,user_id,kind,original_name,size) VALUES ('u2',1,'audio','a.mp3',5)"); c.commit(); c.close()           # audio is now an allowed upload kind
        from dagba import create_app
        app = create_app({"DATABASE": path, "PRIVATE_DIR": d + "/p", "PUBLIC_DIR": d + "/u", "SECRET_KEY": "x", "RATE_LIMITS_ENABLED": False}); cl = app.test_client()
        for u in ("/", "/faith", "/courses", "/academic", "/pricing"): self.assertEqual(cl.get(u).status_code, 200, u)
        self.assertIn('href="/faith">Faith</a>', cl.get("/").data.decode()); shutil.rmtree(d, ignore_errors=True)
    def test_upgrade_from_previous_release_keeps_faith_purchases(self):
        d = tempfile.mkdtemp(); old = os.path.join(d, "mig"); os.makedirs(old)
        for f in sorted(os.listdir(MIG)):
            if f < "009": shutil.copy(os.path.join(MIG, f), old)
        path = os.path.join(d, "o.db"); dbm.migrate(path, old); c = sqlite3.connect(path)
        c.execute("INSERT INTO users(id,email,password_hash,full_name) VALUES (1,'a@b.c','x','A')")
        c.execute("INSERT INTO faith_series(id,topic_id,title,slug,status,price_kobo) VALUES (5,1,'S','s','published',500000)")
        c.execute("INSERT INTO transactions(id,reference,user_id,item_type,faith_series_id,item_title,list_price_kobo,amount_kobo,status) VALUES (9,'REF9',1,'faith',5,'S',500000,500000,'approved')")
        c.execute("INSERT INTO payment_evidence(transaction_id,file,mime,size) VALUES (9,'r.png','image/png',3)")
        c.execute("INSERT INTO faith_access(user_id,series_id,starts_at,transaction_id) VALUES (1,5,'2026-01-01 00:00:00',9)")
        c.execute("INSERT INTO instructor_earnings(instructor_id,transaction_id,faith_series_id,kind,gross_kobo,percent,amount_kobo) VALUES (1,9,5,'sale',500000,40,200000)"); c.commit(); c.close()
        self.assertEqual(dbm.migrate(path, MIG), ["009_faith_topic_prices.sql", "010_pricing_structure.sql", "011_basic_category_featured.sql", "012_basic_category_image.sql", "013_faith_topic_visuals.sql", "014_faith_tutor_topics.sql", "015_hero_slides.sql", "016_tutor_program.sql", "017_professional_division.sql", "018_professional_navigation.sql", "019_subject_pricing_all_divisions.sql", "020_division_separation.sql", "021_tutor_mou.sql", "022_prelaunch.sql", "023_learning_objectives.sql", "024_interactive_learning.sql", "025_mobile_api.sql", "026_store_billing.sql"])
        c = sqlite3.connect(path)
        self.assertEqual(c.execute("SELECT reference,item_type,faith_series_id,faith_topic_id,amount_kobo FROM transactions WHERE id=9").fetchone(), ("REF9", "faith", 5, None, 500000))
        self.assertEqual(c.execute("SELECT series_id,topic_id,transaction_id FROM faith_access").fetchall(), [(5, None, 9)])
        self.assertEqual(c.execute("SELECT COUNT(*) FROM payment_evidence WHERE transaction_id=9").fetchone()[0], 1); self.assertEqual(c.execute("SELECT COUNT(*) FROM instructor_earnings").fetchone()[0], 1)
        self.assertEqual(c.execute("PRAGMA foreign_key_check").fetchall(), []); self.assertEqual(c.execute("SELECT price_kobo FROM faith_topics WHERE id=1").fetchone()[0], 0)
        c.close(); shutil.rmtree(d, ignore_errors=True)
    def test_owner_who_removed_menu_is_not_forced_to_have_it(self):
        d = tempfile.mkdtemp(); path = self.old_site(d, {"c.nav.header": ""}); dbm.migrate(path, MIG)
        self.assertEqual(sqlite3.connect(path).execute("SELECT value FROM settings WHERE key='c.nav.header'").fetchone()[0], ""); shutil.rmtree(d, ignore_errors=True)
