"""Student dashboard and learning experience: continue learning, progress overview, activity, to-do/assessments, recommendations, notifications, objectives."""
import re
from datetime import date, timedelta
from .base import *
from .test_builder import BuilderBase, jpost
from dagba.services import lms, learning as LRN, builder as B

def day(n): return (date.today() + timedelta(days=n)).isoformat()

class DashBase(Base):
    def grant(self, who, cid, kind="course"):
        dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at) VALUES (?,?,?,?,?)", (self.users[who], kind, cid, "academic", "2026-01-01 00:00:00"))
    def lessons(self, cid): return [r["id"] for r in lms.ordered_lessons(cid)]
    def dash(self, who="alice"): return self.client(who).get("/student").data.decode()

class DashboardTests(DashBase):
    def test_new_student_sees_a_clean_dashboard_with_recommendations(self):
        r = self.client("bob").get("/student"); self.assertEqual(r.status_code, 200); h = r.data.decode()
        for s in ("Welcome, Bob", "You have not started any course yet", "Recommended for you", "Paid Maths", "Recent notifications"): self.assertIn(s, h)
        for s in ("Your overall progress", "Pending assignments", "Learning history"): self.assertNotIn(s, h)
        self.assertEqual(self.app.test_client().get("/student").status_code, 302)

    def test_continue_learning_resumes_from_saved_position_and_next_lesson(self):
        self.grant("alice", self.paid); l1, l2 = self.lessons(self.paid); c = self.client("alice")
        h = c.get("/student").data.decode(); self.assertIn("Start learning", h); self.assertIn("Next up", h); self.assertIn(f"/learn/paid-maths/lesson/{l1}", h)
        c.get(f"/learn/paid-maths/lesson/{l1}"); self.post(c, f"/learn/lesson/{l1}/progress", {"position": "125"})
        h = c.get("/student").data.decode(); self.assertIn("Resume lesson", h); self.assertIn("saved at 2:05", h); self.assertIn(f'/learn/paid-maths/lesson/{l1}"', h); self.assertIn("last studied", h)
        self.post(c, f"/learn/lesson/{l1}/complete"); h = self.client("alice").get("/student").data.decode()          # another device: it all comes from the database
        self.assertIn(f'/learn/paid-maths/lesson/{l2}"', h); self.assertIn("50%", h); self.assertIn("Your overall progress", h); self.assertIn("1 of 2 lessons completed", h)
        for s in ("Recently accessed", "My courses"): self.assertIn(s, h)
        ov = LRN.overview(self.users["alice"], [dict(dbm.q1("SELECT * FROM courses WHERE id=?", (self.paid,)), progress=lms.course_progress(self.users["alice"], self.paid))])
        self.assertEqual((ov["percent"], ov["in_progress"], ov["completed"]), (50, 1, 0))
        self.assertEqual(self.dash("bob").count("saved at"), 0, "nobody else's position leaks")

    def test_completed_courses_modules_and_certificates(self):
        self.grant("alice", self.paid); l1, l2 = self.lessons(self.paid)
        m = dbm.ex("INSERT INTO modules(course_id,title,position) VALUES (?,?,1)", (self.paid, "Module A")); dbm.ex("UPDATE lessons SET module_id=? WHERE id IN (?,?)", (m, l1, l2))
        c = self.client("alice"); self.post(c, f"/learn/lesson/{l1}/complete"); self.assertEqual(LRN.completed_modules(self.users["alice"], [self.paid]), [])
        self.post(c, f"/learn/lesson/{l2}/complete"); h = c.get("/student").data.decode()
        for s in ("Completed", "Course completed", "Module A", "100%", "You have finished every lesson"): self.assertIn(s, h)
        self.assertEqual([r["title"] for r in LRN.completed_modules(self.users["alice"], [self.paid])], ["Module A"])
        self.assertNotIn("Resume lesson", h)
        dbm.ex("INSERT INTO certificates(cert_id,user_id,course_id,student_name,course_title) VALUES ('DDA-C1',?,?,?,?)", (self.users["alice"], self.paid, "Alice", "Paid Maths"))
        h = c.get("/student").data.decode(); self.assertIn("View my 1 certificate", h); self.assertIn("1 certificate", h)

    def test_pending_assignments_and_upcoming_assessments(self):
        self.grant("alice", self.paid); late = dbm.ex("INSERT INTO assignments(course_id,title,due_date) VALUES (?,?,?)", (self.paid, "Late work", day(-3)))
        soon = dbm.ex("INSERT INTO assignments(course_id,title,due_date) VALUES (?,?,?)", (self.paid, "Soon work", day(4))); nod = dbm.ex("INSERT INTO assignments(course_id,title) VALUES (?,?)", (self.paid, "Open work"))
        z = dbm.ex("INSERT INTO quizzes(course_id,title,pass_mark) VALUES (?,?,50)", (self.paid, "Unit quiz")); qq = dbm.ex("INSERT INTO questions(quiz_id,course_id,prompt,options,correct) VALUES (?,?,?,?,2)", (z, self.paid, "2+2?", "3\n4"))
        h = self.dash(); self.assertIn("Pending assignments", h)
        for s in ("Late work", "Overdue", "Soon work", f"Due {day(4)}", "Open work", "No due date", "Upcoming assessments", "Unit quiz", "Take quiz"): self.assertIn(s, h)
        self.assertLess(h.index("Late work"), h.index("Soon work")); self.assertLess(h.index("Soon work"), h.index("Open work"))
        up = h[h.index("Upcoming assessments"):]; self.assertIn("Soon work", up); self.assertNotIn("Late work", up.split("Recent")[0])
        c = self.client("alice"); self.post(c, f"/learn/paid-maths/assignment/{soon}", {"body": "done"}); self.post(c, f"/learn/paid-maths/quiz/{z}", {f"q{qq}": "2"})
        h = self.dash(); self.assertNotIn("Soon work", h.split("Recently accessed")[0].split("Recent grades")[0]); self.assertNotIn("Take quiz", h)
        self.assertEqual(self.dash("bob").count("Late work"), 0)

    def test_recent_grades(self):
        self.grant("alice", self.paid); a = dbm.ex("INSERT INTO assignments(course_id,title,max_score) VALUES (?,?,100)", (self.paid, "Essay"))
        dbm.ex("INSERT INTO submissions(assignment_id,user_id,body,status,score,feedback,reviewed_at) VALUES (?,?,?,?,?,?,datetime('now'))", (a, self.users["alice"], "x", "reviewed", 85, "good"))
        dbm.ex("INSERT INTO quiz_attempts(quiz_id,user_id,score_percent,passed) VALUES ((SELECT COALESCE(MAX(id),0) FROM quizzes),?,?,1)", (self.users["alice"], 70)) if False else None
        h = self.dash(); self.assertIn("Recent grades", h); self.assertIn("85/100", h); self.assertIn("Essay", h)
        self.assertNotIn("Recent grades", self.dash("bob"))

    def test_recommendations_follow_enrolments_and_class_level(self):
        cat = self.val("SELECT id FROM categories WHERE slug='academic-mathematics'"); other = self.val("SELECT id FROM categories WHERE division='academic' AND id<>? LIMIT 1", (cat,))
        dbm.ex("UPDATE courses SET category_id=? WHERE id=?", (cat, self.paid)); self.grant("alice", self.paid)
        same = dbm.ex("INSERT INTO courses(division,category_id,title,slug,price_kobo,status,academic_level) VALUES ('academic',?,?,?,100000,'published','basic')", (cat, "More Maths", "more-maths"))
        nxt = dbm.ex("INSERT INTO courses(division,category_id,title,slug,price_kobo,status,academic_level) VALUES ('academic',?,?,?,100000,'published','advanced')", (cat, "Calculus Next", "calculus-next"))
        draft = dbm.ex("INSERT INTO courses(division,category_id,title,slug,price_kobo,status) VALUES ('academic',?,?,?,100000,'draft')", (cat, "Hidden Draft", "hidden-draft"))
        far = dbm.ex("INSERT INTO courses(division,category_id,title,slug,price_kobo,status,class_level) VALUES ('income',NULL,?,?,100000,'published','SS2')", ("Class Match", "class-match"))
        h = self.dash(); self.assertIn("Recommended for you", h); rec = h[h.index("Recommended for you"):]
        self.assertIn("More Maths", rec); self.assertIn("Because you study", rec); self.assertNotIn("Hidden Draft", rec); self.assertNotIn("Paid Maths", rec.split("Faith")[0].split("Learning history")[0].split("Recent notifications")[0])
        dbm.ex("UPDATE users SET class_level='SS2' WHERE id=?", (self.users["alice"],)); h = self.dash(); self.assertIn("Class Match", h); self.assertIn("For SS2", h)
        l1, l2 = self.lessons(self.paid); c = self.client("alice"); self.post(c, f"/learn/lesson/{l1}/complete"); self.post(c, f"/learn/lesson/{l2}/complete")
        h = self.dash(); self.assertIn("Next step after finishing", h); self.assertIn("Calculus Next", h)
        titles = [r["course"]["title"] for r in LRN.recommendations(self.users["alice"], [dict(dbm.q1("SELECT * FROM courses WHERE id=?", (self.paid,)), progress=lms.course_progress(self.users["alice"], self.paid))], 10)]
        self.assertLess(titles.index("Calculus Next"), titles.index("Class Match")) if "Class Match" in titles else None
        self.assertIn(self.val("SELECT 1"), (1,))
        self.assertTrue(len(LRN.recommendations(self.users["alice"], [], 3)) <= 3)

    def test_activity_history_and_page(self):
        self.grant("alice", self.paid); l1, l2 = self.lessons(self.paid); c = self.client("alice"); self.post(c, f"/learn/lesson/{l1}/complete")
        z = dbm.ex("INSERT INTO quizzes(course_id,title,pass_mark) VALUES (?,?,50)", (self.paid, "Q1")); qq = dbm.ex("INSERT INTO questions(quiz_id,course_id,prompt,options,correct) VALUES (?,?,?,?,1)", (z, self.paid, "p", "a\nb"))
        self.post(c, f"/learn/paid-maths/quiz/{z}", {f"q{qq}": "1"})
        h = c.get("/student").data.decode(); self.assertIn("Learning history", h); self.assertIn("Completed lesson", h); self.assertIn("Quiz: passed (100%)", h)
        r = c.get("/student/activity"); self.assertEqual(r.status_code, 200); a = r.data.decode()
        for s in ("My learning activity", "Recently accessed lessons", "Learning history", "Completed lesson", "Q1", "1 of 2 lessons completed"): self.assertIn(s, a)
        b = self.client("bob").get("/student/activity").data.decode(); self.assertNotIn("Completed lesson", b); self.assertIn("will appear here", b)
        self.assertEqual(self.app.test_client().get("/student/activity").status_code, 302)
        self.assertIn("Learning activity", c.get("/student").data.decode())             # in the student menu

    def test_enrolment_access_and_progress_logic_unchanged(self):
        c = self.client("alice"); l1, l2 = self.lessons(self.paid)
        self.assertEqual(c.get("/student").status_code, 200); self.assertEqual(c.get(f"/learn/paid-maths/lesson/{l1}").status_code, 302)       # still needs access
        self.assertEqual(self.dash().count(f"/learn/paid-maths/lesson/{l1}"), 0); self.assertEqual(self.val("SELECT COUNT(*) FROM progress"), 0, "viewing the dashboard writes nothing")

class NotificationTests(DashBase):
    def seed(self):
        for kind, title in (("announcement", "Course announcement: Exam"), ("assignment", "Assignment feedback: Essay"), ("assessment", "Assessment result: Q1"), ("certificate", "Certificate ready"), ("info", "Plain info")):
            dbm.ex("INSERT INTO notifications(user_id,kind,title,body) VALUES (?,?,?,?)", (self.users["alice"], kind, title, "body"))
        dbm.ex("INSERT INTO notifications(user_id,kind,title,body) VALUES (?,?,?,?)", (self.users["bob"], "announcement", "Bob only", "x"))
    def test_filters_and_dashboard_labels(self):
        self.seed(); c = self.client("alice")
        for kind, title in (("announcement", "Course announcement: Exam"), ("assignment", "Assignment feedback: Essay"), ("grade", "Assessment result: Q1"), ("certificate", "Certificate ready")):
            h = c.get(f"/notifications?kind={kind}").data.decode(); self.assertIn(title, h, kind)
            for other in ("Course announcement: Exam", "Assignment feedback: Essay", "Assessment result: Q1", "Certificate ready", "Plain info"):
                if other != title: self.assertNotIn(other, h, (kind, other))
        h = c.get("/notifications?kind=bogus").data.decode(); self.assertIn("Plain info", h); self.assertIn("Certificate ready", h); self.assertNotIn("Bob only", h)
        self.assertIn("Announcements", h); self.assertIn("Grades", h)
        d = c.get("/student").data.decode()
        for s in ("5 new", "Announcement", "Grade", "Certificate", "Assignment", "All notifications"): self.assertIn(s, d)
        self.assertNotIn("Bob only", d)
        self.assertEqual(c.get("/notifications?kind=announcement&page=2").status_code, 200)
        self.post(c, "/notifications"); self.assertNotIn("new</span>", c.get("/student").data.decode().split("Recent notifications")[1].split("</h2>")[0])

class ObjectivesTests(BuilderBase, DashBase):
    def test_objectives_and_outcomes_shown_on_course_pages(self):
        dbm.ex("UPDATE courses SET objectives=?, outcomes=? WHERE id=?", ("Understand algebra\n- Solve equations\n<b>x</b>", "Factorise expressions\n\u2022 Graph lines", self.paid)); self.grant("alice", self.paid)
        h = self.app.test_client().get("/courses/paid-maths").data.decode()
        for s in ("Course objectives", "Understand algebra", "Solve equations", "Expected learning outcomes", "Factorise expressions", "Graph lines", "&lt;b&gt;x&lt;/b&gt;"): self.assertIn(s, h)
        self.assertNotIn("<b>x</b>", h)
        l = self.client("alice").get("/learn/paid-maths").data.decode()
        for s in ("What this course covers", "Course objectives", "Understand algebra", "Expected learning outcomes", "Graph lines"): self.assertIn(s, l)
        dbm.ex("UPDATE courses SET objectives=NULL, outcomes='' WHERE id=?", (self.paid,))
        h = self.app.test_client().get("/courses/paid-maths").data.decode(); self.assertNotIn("Course objectives", h); self.assertNotIn("Expected learning outcomes", h)
        self.assertNotIn("What this course covers", self.client("alice").get("/learn/paid-maths").data.decode())

    def test_instructors_can_edit_objectives_in_the_builder_and_existing_courses_are_not_blanked(self):
        o = self.client("owner"); j = jpost(o, self, "/staff/builder/save", self.payload(objectives="Goal one\nGoal two", outcomes="Outcome one")).get_json(); self.assertTrue(j["ok"], j); cid = j["id"]
        r = dbm.q1("SELECT objectives, outcomes FROM courses WHERE id=?", (cid,)); self.assertEqual((r["objectives"], r["outcomes"]), ("Goal one\nGoal two", "Outcome one"))
        self.assertEqual(B.load_course(cid)["objectives"], "Goal one\nGoal two") if hasattr(B, "load_course") else None
        p = self.payload(id=cid); j = jpost(o, self, "/staff/builder/save", p).get_json(); self.assertTrue(j["ok"], j)           # a client that never sends the fields leaves them alone
        r = dbm.q1("SELECT objectives, outcomes FROM courses WHERE id=?", (cid,)); self.assertEqual((r["objectives"], r["outcomes"]), ("Goal one\nGoal two", "Outcome one"))
        self.assertEqual(self.client("owner").get(f"/staff/crud/courses/{cid}").status_code, 200) if False else None
