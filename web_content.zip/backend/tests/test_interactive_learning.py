"""Interactive learning: scheduled release, lesson/course discussions with notifications and moderation, learning paths with prerequisites."""
from datetime import datetime, timedelta, timezone
from .base import *
from .test_builder import BuilderBase, jpost
from dagba.services import lms, release as R, pathways as PW, discussions as D, learning as LRN, builder as B

def utc(days=0, hours=0):
    return (datetime.now(timezone.utc) + timedelta(days=days, hours=hours)).strftime("%Y-%m-%d %H:%M:%S")

class IL(Base):
    def setUp(self):
        super().setUp()
        if "inst2" not in self.users: self.mk("inst2", "instructor")
    def course(self, slug, title, lessons=2, owner="inst", **kw):
        cid = dbm.ex("INSERT INTO courses(division,title,slug,price_kobo,status,instructor_id) VALUES ('academic',?,?,500000,'published',?)", (title, slug, self.users[owner]))
        self.mod = dbm.ex("INSERT INTO modules(course_id,title,position) VALUES (?,?,1)", (cid, "Module 1"))
        ids = [dbm.ex("INSERT INTO lessons(course_id,module_id,title,kind,body,position) VALUES (?,?,?,?,?,?)", (cid, self.mod, f"{title} L{i}", "text", "body", i)) for i in range(1, lessons + 1)]
        return cid, ids
    def grant(self, who, cid): dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at) VALUES (?,?,?,?,?)", (self.users[who], "course", cid, "academic", "2026-01-01 00:00:00"))
    def finish(self, who, cid):
        for l in lms.ordered_lessons(cid): dbm.ex("INSERT INTO progress(user_id,lesson_id,course_id,completed_at,updated_at) VALUES (?,?,?,datetime('now'),datetime('now')) ON CONFLICT(user_id,lesson_id) DO UPDATE SET completed_at=datetime('now')", (self.users[who], l["id"], cid))
    def n(self, sql, a=()): return self.val(sql, a)

# ------------------------------------------------------------------ scheduled release
class ReleaseTests(IL, BuilderBase):
    def test_locked_lessons_are_enforced_server_side_and_shown_with_dates(self):
        cid, (l1, l2) = self.course("sched", "Sched"); self.grant("alice", cid); a = self.client("alice")
        dbm.ex("UPDATE lessons SET release_at=? WHERE id=?", (utc(days=3), l2)); dbm.ex("UPDATE lessons SET video_file='v.mp4', resource_file='r.pdf', downloadable=1 WHERE id=?", (l2,))
        self.assertEqual(a.get(f"/learn/sched/lesson/{l1}").status_code, 200)
        r = a.get(f"/learn/sched/lesson/{l2}"); self.assertEqual(r.status_code, 302); self.assertTrue(r.headers["Location"].endswith("/learn/sched"))
        h = a.get("/learn/sched").data.decode(); self.assertIn("Opens ", h); self.assertIn("is-locked", h); self.assertNotIn(f"/learn/sched/lesson/{l2}", h); self.assertIn(f"/learn/sched/lesson/{l1}", h)
        self.assertIn("opens on", a.get(f"/learn/sched/lesson/{l2}", follow_redirects=True).data.decode())
        for p in (f"/learn/video/{l2}", f"/learn/resource/{l2}"): self.assertEqual(a.get(p).status_code, 403, p)
        for p in (f"/learn/lesson/{l2}/progress", f"/learn/lesson/{l2}/complete"): self.assertEqual(self.post(a, p, {"position": "5"}).status_code, 403, p)
        self.assertEqual(self.n("SELECT COUNT(*) FROM progress WHERE lesson_id=?", (l2,)), 0)
        self.assertEqual(self.client("inst").get(f"/learn/sched/lesson/{l2}").status_code, 200)             # the instructor previews everything
        self.assertEqual(self.client("owner").get(f"/learn/sched/lesson/{l2}").status_code, 200)
        self.assertIn("Scheduled:", self.client("inst").get("/learn/sched").data.decode())
        dbm.ex("UPDATE lessons SET release_at=? WHERE id=?", (utc(hours=-1), l2))                          # the moment passes: nothing else changes
        self.assertEqual(a.get(f"/learn/sched/lesson/{l2}").status_code, 200); self.assertEqual(a.get(f"/learn/video/{l2}").status_code, 404)    # open (file itself is missing in the test)
        self.assertNotIn("is-locked", a.get("/learn/sched").data.decode())

    def test_module_release_and_the_later_date_wins(self):
        cid, (l1, l2) = self.course("modrel", "ModRel"); self.grant("alice", cid); a = self.client("alice")
        dbm.ex("UPDATE modules SET release_at=? WHERE id=?", (utc(days=2), self.mod))
        for l in (l1, l2): self.assertEqual(a.get(f"/learn/modrel/lesson/{l}").status_code, 302)
        dbm.ex("UPDATE modules SET release_at=? WHERE id=?", (utc(hours=-5), self.mod)); dbm.ex("UPDATE lessons SET release_at=? WHERE id=?", (utc(days=1), l1))
        self.assertEqual(a.get(f"/learn/modrel/lesson/{l1}").status_code, 302); self.assertEqual(a.get(f"/learn/modrel/lesson/{l2}").status_code, 200)
        rows = {r["id"]: r for r in lms.ordered_lessons(cid)}; self.assertTrue(R.opens_at(rows[l1])); self.assertIsNone(R.opens_at(rows[l2]))
        self.assertEqual(R.effective("2027-01-01 00:00:00", "2027-02-01 00:00:00"), "2027-02-01 00:00:00"); self.assertIsNone(R.effective(None, None))

    def test_free_preview_respects_release_and_resume_skips_locked(self):
        cid, (l1, l2) = self.course("fp", "FP"); dbm.ex("UPDATE lessons SET free_preview=1 WHERE id IN (?,?)", (l1, l2)); b = self.client("bob")
        self.assertEqual(b.get(f"/learn/fp/lesson/{l1}").status_code, 200); dbm.ex("UPDATE lessons SET release_at=? WHERE id=?", (utc(days=2), l1))
        self.assertEqual(b.get(f"/learn/fp/lesson/{l1}").status_code, 302)
        self.grant("alice", cid); self.assertEqual(lms.resume_lesson(self.users["alice"], cid)["id"], l2, "never resume into a locked lesson")
        a = self.client("alice"); r = self.post(a, f"/learn/lesson/{l2}/complete"); self.assertTrue(r.headers["Location"].endswith("/learn/fp"), "the next lesson is locked, so go to the course page")
        h = a.get("/student").data.decode(); self.assertIn("Coming up", h); self.assertIn("FP L1", h); self.assertIn("Opens ", h)
        self.assertEqual([x["title"] for x in R.upcoming([cid])], ["FP L1"])

    def test_formats_and_time_zone(self):
        self.assertEqual(R.to_utc("2030-01-05T09:00"), "2030-01-05 08:00:00"); self.assertEqual(R.to_local("2030-01-05 08:00:00"), "2030-01-05T09:00"); self.assertIsNone(R.to_utc("")); self.assertEqual(R.fmt("2030-01-05 08:00:00"), "5 Jan 2030, 09:00")
        with self.assertRaises(ValueError): R.to_utc("not a date")
        S_ = __import__("dagba.services.settings", fromlist=["x"]); S_.put("site.utc_offset", "-05:00"); self.assertEqual(R.to_utc("2030-01-05T09:00"), "2030-01-05 14:00:00")

    def test_builder_saves_release_dates_and_never_wipes_them(self):
        o = self.client("owner"); mods = [{"id": None, "title": "Intro", "release_at": "2030-02-01T08:00", "lessons": [{"title": "Welcome", "kind": "text", "body": "hi", "release_at": "2030-02-03T10:30"}, {"title": "Second", "kind": "text", "body": "yo"}]}]
        j = jpost(o, self, "/staff/builder/save", self.payload(modules=mods)).get_json(); self.assertTrue(j["ok"], j); cid = j["id"]
        m = dbm.q1("SELECT * FROM modules WHERE course_id=?", (cid,)); self.assertEqual(m["release_at"], "2030-02-01 07:00:00")
        ls = dbm.q("SELECT title, release_at FROM lessons WHERE course_id=? ORDER BY position", (cid,)); self.assertEqual(ls[0]["release_at"], "2030-02-03 09:30:00"); self.assertIsNone(ls[1]["release_at"])
        loaded = B.load_course(cid)["modules"][0]; self.assertEqual(loaded["release_at"], "2030-02-01T08:00"); self.assertEqual(loaded["lessons"][0]["release_at"], "2030-02-03T10:30")
        mods2 = [{"id": m["id"], "title": "Intro", "lessons": [{"id": dbm.q("SELECT id FROM lessons WHERE course_id=? ORDER BY position", (cid,))[i]["id"], "title": t, "kind": "text", "body": "x"} for i, t in enumerate(("Welcome", "Second"))]}]
        self.assertTrue(jpost(o, self, "/staff/builder/save", self.payload(id=cid, modules=mods2)).get_json()["ok"])
        self.assertEqual(dbm.q1("SELECT release_at FROM modules WHERE id=?", (m["id"],))["release_at"], "2030-02-01 07:00:00", "a client that omits the key leaves it alone")
        mods3 = [dict(mods2[0], release_at="", lessons=[dict(l, release_at="") for l in mods2[0]["lessons"]])]
        self.assertTrue(jpost(o, self, "/staff/builder/save", self.payload(id=cid, modules=mods3)).get_json()["ok"]); self.assertIsNone(dbm.q1("SELECT release_at FROM modules WHERE id=?", (m["id"],))["release_at"])
        bad = [dict(mods2[0], release_at="garbage")]; r = jpost(o, self, "/staff/builder/save", self.payload(id=cid, modules=bad)); self.assertEqual(r.status_code, 400)
        self.assertIn("datetime-local", self.client("owner").get(f"/staff/builder/{cid}").data.decode())

# ------------------------------------------------------------------ discussions
class DiscussionTests(IL):
    def setUp(self):
        super().setUp(); self.cid, (self.l1, self.l2) = self.course("disc", "Disc"); self.grant("alice", self.cid)
    def ask(self, who, body, lesson=None, parent=None, slug="disc"):
        c = self.client(who); d = {"body": body}
        if lesson: d["lesson_id"] = lesson
        if parent: d["parent_id"] = parent
        return self.post(c, f"/learn/{slug}/discuss", d)

    def test_question_reply_threading_and_notifications(self):
        r = self.ask("alice", "How do I factorise x^2 + 5x + 6?", self.l1); self.assertEqual(r.status_code, 302); self.assertIn("#post-", r.headers["Location"])
        q_ = dbm.q1("SELECT * FROM discussion_posts"); self.assertEqual((q_["lesson_id"], q_["parent_id"], q_["status"]), (self.l1, None, "visible"))
        n = dbm.q1("SELECT * FROM notifications WHERE user_id=?", (self.users["inst"],)); self.assertEqual(n["kind"], "discussion"); self.assertIn("New question", n["title"]); self.assertIn(f"/learn/disc/lesson/{self.l1}#post-{q_['id']}", n["link"])
        self.assertEqual(self.n("SELECT COUNT(*) FROM notifications WHERE user_id=?", (self.users["alice"],)), 0, "no notification to yourself")
        self.assertEqual(self.ask("inst", "Find two numbers that multiply to 6 and add to 5.", self.l1, q_["id"]).status_code, 302)
        n = dbm.q1("SELECT * FROM notifications WHERE user_id=? AND kind='discussion'", (self.users["alice"],)); self.assertIn("New reply", n["title"]); self.assertIn("Inst:", n["body"])
        self.assertEqual(self.ask("alice", "Got it, thanks!", self.l1, q_["id"]).status_code, 302)
        self.assertEqual(self.n("SELECT COUNT(*) FROM notifications WHERE user_id=? AND kind='discussion'", (self.users["inst"],)), 2)
        self.assertEqual(self.n("SELECT COUNT(*) FROM notifications WHERE user_id=? AND kind='discussion'", (self.users["alice"],)), 1)
        h = self.client("alice").get(f"/learn/disc/lesson/{self.l1}").data.decode()
        for s in ("Lesson discussion", "How do I factorise", "Find two numbers", "Got it, thanks!", "Instructor", "Alice", "Post reply"): self.assertIn(s, h)
        self.mk("carol", "student"); self.grant("carol", self.cid); self.ask("carol", "Same question here", self.l1, q_["id"])
        self.assertEqual(self.n("SELECT COUNT(*) FROM notifications WHERE user_id=? AND kind='discussion'", (self.users["alice"],)), 2, "thread participants hear about new replies")
        self.assertIn("Discussions", self.client("alice").get("/notifications?kind=discussion").data.decode()); self.assertIn("New reply", self.client("alice").get("/notifications?kind=discussion").data.decode())
        self.assertNotIn("New question", self.client("alice").get("/notifications?kind=assignment").data.decode())

    def test_course_wide_discussion_and_scope(self):
        self.ask("alice", "General question about the course"); h = self.client("alice").get("/learn/disc/discussion").data.decode(); self.assertIn("Course discussion", h); self.assertIn("General question", h)
        self.assertNotIn("General question", self.client("alice").get(f"/learn/disc/lesson/{self.l1}").data.decode())
        self.assertIn("Course discussion", self.client("alice").get("/learn/disc").data.decode())
        p = dbm.q1("SELECT * FROM discussion_posts"); r = self.ask("inst", "reply", self.l1, p["id"]); self.assertEqual(self.n("SELECT COUNT(*) FROM discussion_posts"), 1, "a reply must match the lesson of its question")

    def test_only_people_with_access_can_read_or_post(self):
        self.ask("alice", "Visible to the class", self.l1)
        for who in ("bob", "inst2"):
            c = self.client(who); self.assertEqual(c.get("/learn/disc/discussion").status_code, 302); self.assertEqual(c.get(f"/learn/disc/lesson/{self.l1}").status_code, 302)
            self.ask(who, "I should not be able to post here", self.l1); self.ask(who, "course-wide attempt")
        self.assertEqual(self.n("SELECT COUNT(*) FROM discussion_posts"), 1); self.assertEqual(self.app.test_client().post("/learn/disc/discuss", data={"body": "anon"}).status_code, 400)
        b = self.client("bob"); self.assertNotIn("Visible to the class", b.get("/learn/disc/discussion", follow_redirects=True).data.decode())
        self.assertEqual(self.client("owner").get("/learn/disc/discussion").status_code, 200)               # admins have oversight
        self.assertIn("Visible to the class", self.client("owner").get(f"/learn/disc/lesson/{self.l1}").data.decode())

    def test_validation_locked_lessons_and_rate_limit(self):
        for bad in ("", " ", "x", "y" * 3001): self.ask("alice", bad, self.l1)
        self.assertEqual(self.n("SELECT COUNT(*) FROM discussion_posts"), 0)
        dbm.ex("UPDATE lessons SET release_at=? WHERE id=?", (utc(days=2), self.l2)); self.ask("alice", "question on a locked lesson", self.l2); self.ask("alice", "bad lesson", 99999)
        self.assertEqual(self.n("SELECT COUNT(*) FROM discussion_posts"), 0)
        other, (ol,) = self.course("other", "Other", 1); self.ask("alice", "cross-course lesson id", ol); self.assertEqual(self.n("SELECT COUNT(*) FROM discussion_posts"), 0)
        self.ask("alice", "<script>alert(1)</script> hello", self.l1); h = self.client("alice").get(f"/learn/disc/lesson/{self.l1}").data.decode()
        self.assertNotIn("<script>alert(1)", h); self.assertIn("&lt;script&gt;alert(1)", h)

    def test_instructor_and_admin_moderation(self):
        self.ask("alice", "Inappropriate content here", self.l1); p = dbm.q1("SELECT * FROM discussion_posts"); self.ask("inst", "A reply", self.l1, p["id"]); rep = dbm.q1("SELECT * FROM discussion_posts WHERE parent_id IS NOT NULL")
        # students cannot remove others' posts or moderate
        self.mk("carol", "student"); self.grant("carol", self.cid)
        self.assertEqual(self.post(self.client("carol"), f"/learn/disc/discuss/{p['id']}/delete").status_code, 302); self.assertEqual(self.n("SELECT status FROM discussion_posts WHERE id=?", (p["id"],)), "visible")
        for who in ("alice", "carol", "bob"):
            self.assertEqual(self.client(who).get("/staff/discussions").status_code, 403, who); self.assertEqual(self.post(self.client(who), f"/staff/discussions/{p['id']}/remove").status_code, 403, who)
        # another instructor cannot moderate this course
        self.assertEqual(self.client("inst2").get("/staff/discussions").status_code, 200); self.assertNotIn("Inappropriate", self.client("inst2").get("/staff/discussions").data.decode())
        self.post(self.client("inst2"), f"/staff/discussions/{p['id']}/remove"); self.assertEqual(self.n("SELECT status FROM discussion_posts WHERE id=?", (p["id"],)), "visible")
        i = self.client("inst"); h = i.get("/staff/discussions").data.decode(); self.assertIn("Inappropriate content here", h); self.assertIn("Remove", h)
        self.assertEqual(self.post(i, f"/staff/discussions/{p['id']}/remove", {"reason": "Off topic"}).status_code, 302)
        row = dbm.q1("SELECT * FROM discussion_posts WHERE id=?", (p["id"],)); self.assertEqual((row["status"], row["removed_by"], row["removed_reason"]), ("removed", self.users["inst"], "Off topic")); self.assertTrue(row["removed_at"])
        note = dbm.q1("SELECT * FROM notifications WHERE user_id=? AND title LIKE 'Your discussion post was removed'", (self.users["alice"],)); self.assertIn("Off topic", note["body"])
        h = self.client("alice").get(f"/learn/disc/lesson/{self.l1}").data.decode(); self.assertNotIn("Inappropriate content", h); self.assertNotIn("A reply", h, "replies of a removed question are hidden too")
        h = i.get(f"/learn/disc/lesson/{self.l1}").data.decode(); self.assertIn("Inappropriate content", h); self.assertIn("Removed", h); self.assertIn("Restore", h)
        self.assertEqual(self.ask("alice", "reply to removed", self.l1, p["id"]).status_code, 302); self.assertEqual(self.n("SELECT COUNT(*) FROM discussion_posts"), 2)
        self.post(i, f"/staff/discussions/{p['id']}/restore"); self.assertEqual(self.n("SELECT status FROM discussion_posts WHERE id=?", (p["id"],)), "visible")
        self.assertIn("Inappropriate content", self.client("alice").get(f"/learn/disc/lesson/{self.l1}").data.decode())
        self.post(i, f"/staff/discussions/{rep['id']}/remove"); self.assertNotIn("A reply", self.client("alice").get(f"/learn/disc/lesson/{self.l1}").data.decode())
        # admin oversight: an admin with the permission sees and moderates every course; an admin without it cannot
        self.mk("modadmin", "admin", perms=["discussions.manage"]); m = self.client("modadmin"); self.assertIn("Inappropriate content", m.get("/staff/discussions?q=Inappropriate").data.decode())
        self.assertEqual(self.post(m, f"/staff/discussions/{p['id']}/remove").status_code, 302); self.assertEqual(self.n("SELECT status FROM discussion_posts WHERE id=?", (p["id"],)), "removed")
        self.assertEqual(self.client("noperm").get("/staff/discussions").status_code, 403)
        self.assertIn("Inappropriate", m.get("/staff/discussions?status=removed").data.decode()); self.assertNotIn("Inappropriate", m.get("/staff/discussions?status=visible").data.decode())
        self.assertGreaterEqual(self.n("SELECT COUNT(*) FROM audit_logs WHERE action IN ('discussion.removed','discussion.restored')"), 4)
        self.assertEqual(self.post(self.client("alice"), "/staff/discussions/%d/bogus" % p["id"]).status_code, 403)

    def test_authors_can_delete_their_own_posts(self):
        self.ask("alice", "Oops, wrong place", self.l1); p = dbm.q1("SELECT * FROM discussion_posts"); self.post(self.client("alice"), f"/learn/disc/discuss/{p['id']}/delete")
        row = dbm.q1("SELECT * FROM discussion_posts WHERE id=?", (p["id"],)); self.assertEqual(row["status"], "removed"); self.assertIn("author", row["removed_reason"])
        self.assertNotIn("Oops", self.client("alice").get(f"/learn/disc/lesson/{self.l1}").data.decode())

    def test_removed_user_and_privacy(self):
        self.ask("alice", "Question from a student", self.l1); dbm.ex("UPDATE users SET full_name='Alice Okonkwo Smith' WHERE id=?", (self.users["alice"],))
        self.mk("carol", "student"); self.grant("carol", self.cid); h = self.client("carol").get(f"/learn/disc/lesson/{self.l1}").data.decode(); self.assertIn("Alice S.", h); self.assertNotIn("Okonkwo", h); self.assertNotIn("alice@t.test", h)
        dbm.ex("DELETE FROM users WHERE id=?", (self.users["alice"],)); self.assertIn("Former student", self.client("carol").get(f"/learn/disc/lesson/{self.l1}").data.decode())

# ------------------------------------------------------------------ learning paths
class PathTests(IL):
    def setUp(self):
        super().setUp(); self.a, (self.a1, self.a2) = self.course("path-a", "Path A"); self.b, (self.b1,) = self.course("path-b", "Path B", 1); self.c, _ = self.course("path-c", "Path C", 1)
        for who in ("alice",):
            for cid in (self.a, self.b, self.c): self.grant(who, cid)
        self.mk("pathadmin", "admin", perms=["paths.manage"])
    def build(self, status="published"):
        o = self.client("pathadmin"); r = self.post(o, "/staff/learning-paths", {"title": "Maths Career Path"}); self.assertEqual(r.status_code, 302); pid = self.n("SELECT id FROM learning_paths")
        for cid in (self.a, self.b, self.c): self.post(o, f"/staff/learning-paths/{pid}", {"action": "add", "course_id": cid})
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "prereq", "course_id": self.b, "requires": self.a}); self.post(o, f"/staff/learning-paths/{pid}", {"action": "prereq", "course_id": self.c, "requires": [self.a, self.b]})
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "save", "title": "Maths Career Path", "summary": "From basics to mastery", "status": status}); return pid

    def test_admin_builds_orders_and_publishes_a_path(self):
        pid = self.build(); o = self.client("pathadmin"); self.assertEqual([r["title"] for r in PW.courses(pid)], ["Path A", "Path B", "Path C"]); self.assertEqual(PW.get(pid)["status"], "published")
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "down", "course_id": self.a}); self.assertEqual([r["title"] for r in PW.courses(pid)], ["Path B", "Path A", "Path C"])
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "up", "course_id": self.a}); self.assertEqual([r["title"] for r in PW.courses(pid)][0], "Path A")
        self.assertEqual(PW.prereq_map(pid), {self.b: [self.a], self.c: [self.a, self.b]}); h = o.get(f"/staff/learning-paths/{pid}").data.decode(); self.assertIn("Path B", h); self.assertIn("Save prerequisites", h)
        self.assertIn("Maths Career Path", o.get("/staff/learning-paths").data.decode()); self.assertGreaterEqual(self.n("SELECT COUNT(*) FROM audit_logs WHERE action LIKE 'path.%'"), 5)
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "remove", "course_id": self.b}); self.assertEqual([r["title"] for r in PW.courses(pid)], ["Path A", "Path C"]); self.assertEqual(PW.prereq_map(pid), {self.c: [self.a]})
        self.assertEqual([r["position"] for r in PW.courses(pid)], [1, 2])

    def test_validation_cycles_and_empty_publish(self):
        o = self.client("pathadmin"); self.post(o, "/staff/learning-paths", {"title": "T"}); pid = self.n("SELECT id FROM learning_paths")
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "save", "title": "T", "status": "published"}); self.assertEqual(PW.get(pid)["status"], "draft", "cannot publish an empty path")
        for cid in (self.a, self.b): self.post(o, f"/staff/learning-paths/{pid}", {"action": "add", "course_id": cid})
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "add", "course_id": self.a}); self.assertEqual(self.n("SELECT COUNT(*) FROM learning_path_courses"), 2)
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "prereq", "course_id": self.b, "requires": self.a})
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "prereq", "course_id": self.a, "requires": self.b}); self.assertEqual(PW.prereq_map(pid), {self.b: [self.a]}, "a loop is refused")
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "prereq", "course_id": self.a, "requires": self.a}); self.post(o, f"/staff/learning-paths/{pid}", {"action": "prereq", "course_id": self.a, "requires": self.c})
        self.assertEqual(PW.prereq_map(pid), {self.b: [self.a]})
        with self.assertRaises(Exception): dbm.ex("INSERT INTO path_prerequisites VALUES (?,?,?)", (pid, self.a, self.a))
        self.assertEqual(self.post(o, f"/staff/learning-paths/{pid}", {"action": "nonsense"}).status_code, 400)

    def test_permissions_and_instructor_scope(self):
        pid = self.build(); self.assertEqual(self.client("noperm").get("/staff/learning-paths").status_code, 403); self.assertEqual(self.client("alice").get("/staff/learning-paths").status_code, 403)
        i = self.client("inst"); self.assertEqual(i.get("/staff/learning-paths").status_code, 200); self.assertNotIn("Maths Career Path", i.get("/staff/learning-paths").data.decode()); self.assertEqual(i.get(f"/staff/learning-paths/{pid}").status_code, 404)
        self.assertEqual(self.post(i, f"/staff/learning-paths/{pid}", {"action": "delete"}).status_code, 404); self.assertTrue(PW.get(pid))
        self.post(i, "/staff/learning-paths", {"title": "Inst path"}); mine = self.n("SELECT id FROM learning_paths WHERE title='Inst path'")
        foreign, _ = self.course("foreign", "Foreign", 1, owner="inst2"); self.post(i, f"/staff/learning-paths/{mine}", {"action": "add", "course_id": foreign}); self.assertEqual(self.n("SELECT COUNT(*) FROM learning_path_courses WHERE path_id=?", (mine,)), 0)
        self.post(i, f"/staff/learning-paths/{mine}", {"action": "add", "course_id": self.a}); self.assertEqual(self.n("SELECT COUNT(*) FROM learning_path_courses WHERE path_id=?", (mine,)), 1)
        self.assertEqual(self.client("inst2").get(f"/staff/learning-paths/{mine}").status_code, 404); self.assertEqual(self.client("owner").get(f"/staff/learning-paths/{pid}").status_code, 200)

    def test_prerequisites_block_every_learning_route_until_completed(self):
        pid = self.build(); a = self.client("alice"); lb = self.n("SELECT id FROM lessons WHERE course_id=?", (self.b,))
        self.assertEqual(PW.paths_for_course(self.b)[0]["id"], pid); self.assertEqual([u["title"] for u in PW.unmet(self.users["alice"], self.b)], ["Path A"])
        r = a.get("/learn/path-b"); self.assertEqual(r.status_code, 403); self.assertIn("Complete the prerequisite", r.data.decode()); self.assertIn("Path A", r.data.decode())
        self.assertEqual(a.get(f"/learn/path-b/lesson/{lb}").status_code, 302); self.assertEqual(a.get(f"/learn/path-b/lesson/{lb}", follow_redirects=True).status_code, 403)
        for p in (f"/learn/lesson/{lb}/complete", f"/learn/lesson/{lb}/progress"): self.assertEqual(self.post(a, p, {"position": "3"}).status_code, 403, p)
        dbm.ex("UPDATE lessons SET video_file='v.mp4' WHERE id=?", (lb,)); self.assertEqual(a.get(f"/learn/video/{lb}").status_code, 403)
        z = dbm.ex("INSERT INTO quizzes(course_id,title,pass_mark) VALUES (?,?,50)", (self.b, "BQ")); asg = dbm.ex("INSERT INTO assignments(course_id,title) VALUES (?,?)", (self.b, "BA"))
        self.assertEqual(a.get(f"/learn/path-b/quiz/{z}").status_code, 403); self.assertEqual(a.get(f"/learn/path-b/assignment/{asg}").status_code, 403)
        self.assertEqual(self.n("SELECT COUNT(*) FROM progress WHERE course_id=?", (self.b,)), 0)
        self.assertIn("Complete", self.client("alice").get("/courses/path-b").data.decode()) if False else None
        h = a.get("/courses/path-b").data.decode(); self.assertIn("Prerequisites", h); self.assertIn("opens once you complete", h); self.assertIn("Maths Career Path", h)
        self.assertEqual(self.client("inst").get("/learn/path-b").status_code, 200); self.assertEqual(self.client("owner").get("/learn/path-b").status_code, 200)         # staff preview
        self.finish("alice", self.a); self.assertEqual(PW.unmet(self.users["alice"], self.b), []); self.assertEqual(a.get("/learn/path-b").status_code, 200); self.assertEqual(a.get(f"/learn/path-b/lesson/{lb}").status_code, 200)
        self.assertEqual(self.post(a, f"/learn/lesson/{lb}/complete").status_code, 302); self.assertEqual(a.get("/learn/path-c").status_code, 200)
        self.assertEqual(self.client("bob").get("/learn/path-b").status_code, 302, "enrolment is still required on top of prerequisites")

    def test_draft_paths_do_not_restrict_and_unpublishing_lifts_them(self):
        pid = self.build(status="draft"); a = self.client("alice"); self.assertEqual(a.get("/learn/path-b").status_code, 200); self.assertEqual(PW.requirements(self.b), [])
        self.post(self.client("pathadmin"), f"/staff/learning-paths/{pid}", {"action": "save", "title": "Maths Career Path", "status": "published"}); self.assertEqual(a.get("/learn/path-b").status_code, 403)
        self.post(self.client("pathadmin"), f"/staff/learning-paths/{pid}", {"action": "save", "title": "Maths Career Path", "status": "draft"}); self.assertEqual(a.get("/learn/path-b").status_code, 200)
        self.assertEqual(self.app.test_client().get(f"/learning-paths/maths-career-path").status_code, 404); self.assertEqual(self.client("alice").get("/learning-paths/maths-career-path").status_code, 404)
        self.assertEqual(self.client("pathadmin").get("/learning-paths/maths-career-path").status_code, 200)

    def test_prerequisite_course_without_lessons_does_not_block(self):
        empty = dbm.ex("INSERT INTO courses(division,title,slug,status,instructor_id) VALUES ('academic','Empty','empty','published',?)", (self.users["inst"],)); o = self.client("pathadmin"); self.post(o, "/staff/learning-paths", {"title": "E"}); pid = self.n("SELECT id FROM learning_paths")
        for cid in (empty, self.a): self.post(o, f"/staff/learning-paths/{pid}", {"action": "add", "course_id": cid})
        self.post(o, f"/staff/learning-paths/{pid}", {"action": "prereq", "course_id": self.a, "requires": empty}); self.post(o, f"/staff/learning-paths/{pid}", {"action": "save", "title": "E", "status": "published"})
        self.assertEqual(self.client("alice").get("/learn/path-a").status_code, 200)

    def test_student_sees_path_progress(self):
        pid = self.build(); a = self.client("alice"); self.assertEqual(self.app.test_client().get("/learning-paths").status_code, 200)
        h = a.get("/learning-paths/maths-career-path").data.decode()
        for s in ("Maths Career Path", "Recommended sequence", "Path A", "Path B", "Locked", "Requires:", "Your progress", "0 of 3 courses"): self.assertIn(s, h)
        self.finish("alice", self.a); dbm.ex("INSERT INTO progress(user_id,lesson_id,course_id,completed_at,updated_at) VALUES (?,?,?,NULL,datetime('now'))", (self.users["alice"], self.n("SELECT id FROM lessons WHERE course_id=?", (self.b,)), self.b))
        prog = PW.progress(self.users["alice"], PW.get(pid)); self.assertEqual([s["state"] for s in prog["steps"]], ["completed", "available", "locked"]); self.assertEqual((prog["courses_done"], prog["courses_total"]), (1, 3)); self.assertEqual(prog["next"]["course"]["slug"], "path-b")
        self.assertEqual(prog["percent"], 50)                       # 2 of the path's 4 lessons are done (A 2/2, B 0/1, C 0/1)
        self.assertIn("50%", a.get("/learning-paths/maths-career-path").data.decode()); d = a.get("/student").data.decode(); self.assertIn("Your learning paths", d); self.assertIn("Maths Career Path", d); self.assertIn("Next:", d)
        self.assertIn("Learning paths", d)

class DiscussionRateTests(IL):
    rate = True
    def test_posting_is_rate_limited(self):
        cid, (l1, _) = self.course("rl", "RL"); self.grant("alice", cid); c = self.client("alice")
        for i in range(25): self.post(c, "/learn/rl/discuss", {"body": f"question number {i}", "lesson_id": l1})
        self.assertEqual(self.n("SELECT COUNT(*) FROM discussion_posts"), 20)

class PreLaunchInteropTests(IL):
    def test_new_pages_stay_behind_the_pre_launch_gate(self):
        from dagba.services import settings as S_
        cid, (l1, _) = self.course("pl", "PL"); self.grant("alice", cid); S_.put("prelaunch.launch_at", "2099-01-01T00:00"); S_.put("prelaunch.enabled", "1"); a = self.client("alice")
        for p in ("/learning-paths", "/learn/pl/discussion", "/student/activity"): r = a.get(p); self.assertEqual((r.status_code, r.headers["Location"]), (302, "/"), p)
        self.assertEqual(self.post(a, "/learn/pl/discuss", {"body": "hello there"}).status_code, 403); self.assertEqual(self.n("SELECT COUNT(*) FROM discussion_posts"), 0)
        i = self.client("inst"); self.assertEqual(i.get("/learn/pl/discussion").status_code, 200); self.assertEqual(i.get("/staff/discussions").status_code, 200)
