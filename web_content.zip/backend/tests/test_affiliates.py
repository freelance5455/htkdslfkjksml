from .base import *
from dagba.services import affiliates as A, settings as S

class AffBase(Base):
    def setUp(self):
        super().setUp()
        self.mk("affman", "admin", perms=["affiliates.manage"])
        self.owner_c = self.client("owner")

    # ---- helpers
    def add_aff(self, email="chioma@t.test", name="Chioma Okafor", slug="chioma", percent="", c=None):
        r = self.post(c or self.owner_c, "/staff/affiliates/new", {"full_name": name, "email": email, "slug": slug, "percent": percent}, follow_redirects=True)
        return r

    def aff(self, slug="chioma"): return self.row("SELECT * FROM affiliates WHERE slug=?", (slug,))

    def visit(self, c, path, **kw): return c.get(path, **kw)

    def register(self, c, email="newbie@t.test", name="New Student"):
        r = self.post(c, "/register", {"full_name": name, "email": email, "password": PW, "password2": PW})
        self.assertEqual(r.status_code, 302, r.data[:300]); return self.row("SELECT * FROM users WHERE email=?", (email,))

    def login_fresh(self, email, pw=PW):
        """A brand-new browser (no cookies): like another phone, or the normal web address typed in later."""
        c = self.client(); r = self.post(c, "/login", {"email": email, "password": pw}); self.assertEqual(r.status_code, 302); return c

    def approve(self, tid): return self.post(self.client("officer"), f"/staff/payments/{tid}", {"action": "approve", "confirm": "1", "verified_funds": "1"})

    def purchase(self, c, slug="paid-maths"):
        ref = self.buy(c, "course", slug); t = self.tx(ref); self.approve(t["id"]); return t["id"]

    def earned(self, slug="chioma"): return self.val("SELECT COALESCE(SUM(amount_kobo),0) FROM affiliate_earnings WHERE affiliate_id=(SELECT id FROM affiliates WHERE slug=?)", (slug,))

class LinkAndLockTests(AffBase):
    def test_link_sets_cookie_counts_click_and_redirects_home(self):
        self.add_aff(); c = self.client()
        r = c.get("/r/chioma"); self.assertEqual(r.status_code, 302); self.assertEqual(r.headers["Location"], "/")
        self.assertIn("dda_ref=", r.headers.get("Set-Cookie", "")); self.assertIn("no-store", r.headers["Cache-Control"])
        self.assertEqual(self.val("SELECT COUNT(*) FROM affiliate_clicks"), 1)
        c.get("/r/chioma"); self.assertEqual(self.val("SELECT COUNT(*) FROM affiliate_clicks"), 1)        # refresh within 30 minutes is not a new click

    def test_link_is_case_insensitive_and_unknown_links_do_nothing(self):
        self.add_aff(); c = self.client(); self.assertIn("dda_ref=", c.get("/r/ChIoMa").headers.get("Set-Cookie", ""))
        d = self.client(); r = d.get("/r/nobody"); self.assertEqual(r.status_code, 302); self.assertNotIn("dda_ref", r.headers.get("Set-Cookie", ""))

    def test_signup_after_visit_is_tied_to_the_affiliate_for_good(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); c.get("/courses"); c.get("/")      # browses around on the normal address
        u = self.register(c)
        self.assertEqual(u["referred_by_affiliate"], self.aff()["id"]); self.assertIsNotNone(u["referred_at"])
        n = self.row("SELECT * FROM notifications WHERE user_id=? AND title LIKE 'New sign-up%'", (self.aff()["user_id"],)); self.assertIn("New S.", n["body"])

    def test_purchase_on_another_device_or_normal_address_still_credits_affiliate(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "buyer@t.test", "Buyer One")
        other = self.login_fresh("buyer@t.test")                      # no cookie at all
        self.assertNotIn("dda_ref", [k.decode() if isinstance(k, bytes) else k for k in []])
        self.purchase(other)
        e = self.row("SELECT * FROM affiliate_earnings"); self.assertEqual((e["gross_kobo"], e["percent"], e["amount_kobo"], e["kind"]), (500000, 20.0, 100000, "sale"))
        n = self.row("SELECT * FROM notifications WHERE user_id=? AND kind='earning'", (self.aff()["user_id"],)); self.assertIn("Buyer O.", n["body"]); self.assertIn("1,000", n["body"])

    def test_every_later_purchase_also_earns(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test", "Buyer")
        self.purchase(c, "paid-maths"); self.purchase(c, "marketing")
        self.assertEqual(self.earned(), 100000 + 200000)

    def test_first_link_wins(self):
        self.add_aff(); self.add_aff("tunde@t.test", "Tunde Ade", "tunde")
        c = self.client(); c.get("/r/chioma"); c.get("/r/tunde"); u = self.register(c)
        self.assertEqual(u["referred_by_affiliate"], self.aff("chioma")["id"])

    def test_ref_parameter_on_any_page_works_and_to_is_safe(self):
        self.add_aff(); c = self.client(); r = c.get("/courses?ref=chioma"); self.assertEqual(r.status_code, 200); self.assertIn("dda_ref=", r.headers.get("Set-Cookie", ""))
        d = self.client(); r = d.get("/r/chioma?to=/courses"); self.assertEqual(r.headers["Location"], "/courses")
        e = self.client(); r = e.get("/r/chioma?to=//evil.example"); self.assertEqual(r.headers["Location"], "/")
        e = self.client(); r = e.get("/r/chioma?to=/staff"); self.assertEqual(r.headers["Location"], "/")

    def test_tampered_cookie_is_ignored(self):
        self.add_aff(); c = self.client(); c.set_cookie("dda_ref", "forged-value"); u = self.register(c); self.assertIsNone(u["referred_by_affiliate"])

    def test_no_link_means_no_affiliate(self):
        self.add_aff(); u = self.register(self.client()); self.assertIsNone(u["referred_by_affiliate"])

    def test_existing_accounts_are_never_re_attributed(self):
        self.add_aff()
        c = self.client("alice"); r = c.get("/r/chioma"); self.assertNotIn("dda_ref", r.headers.get("Set-Cookie", ""))   # logged in: nothing set
        self.assertEqual(self.val("SELECT COUNT(*) FROM affiliate_clicks"), 0)
        self.purchase(c); self.assertEqual(self.earned(), 0)

    def test_crawlers_do_not_count_or_set_cookies(self):
        self.add_aff(); c = self.client(); r = c.get("/r/chioma", headers={"User-Agent": "facebookexternalhit/1.1"})
        self.assertNotIn("dda_ref", r.headers.get("Set-Cookie", "")); self.assertEqual(self.val("SELECT COUNT(*) FROM affiliate_clicks"), 0)

    def test_affiliate_cannot_earn_on_their_own_purchases(self):
        self.add_aff("self@t.test", "Self Buyer", "selfie"); a = self.aff("selfie")
        dbm.ex("UPDATE users SET referred_by_affiliate=? WHERE id=?", (a["id"], a["user_id"]))
        # (new password flow: give the auto-created account a known password)
        dbm.ex("UPDATE users SET password_hash=? WHERE id=?", (PWHASH, a["user_id"]))
        self.purchase(self.login_fresh("self@t.test")); self.assertEqual(self.earned("selfie"), 0)

    def test_programme_switched_off_stops_tracking_and_earning(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test")
        S.put("affiliate.enabled", "0")
        self.assertNotIn("dda_ref", self.client().get("/r/chioma").headers.get("Set-Cookie", ""))
        self.purchase(self.login_fresh("b@t.test")); self.assertEqual(self.earned(), 0)

class SlugTests(AffBase):
    def test_custom_names_are_cleaned_and_validated(self):
        self.add_aff(slug="Chioma Okafor"); self.assertIsNotNone(self.aff("chioma-okafor"))
        for bad, why in (("ab", "short"), ("a" * 31, "long"), ("admin", "reserved"), ("!!", "empty")):
            self.add_aff(f"x{len(bad)}{bad[:1]}@t.test", "X Y", bad); self.assertIsNone(self.aff(bad), why)
        r = self.add_aff("dup@t.test", "Dup", "chioma-okafor"); self.assertIn(b"already taken", r.data)
        self.assertEqual(self.val("SELECT COUNT(*) FROM users WHERE email='dup@t.test'"), 0)           # nothing half-created

    def test_blank_name_is_derived_from_full_name_and_made_unique(self):
        self.add_aff("a@t.test", "Ngozi Eze", ""); self.add_aff("b@t.test", "Ngozi Eze", "")
        self.assertIsNotNone(self.aff("ngozi-eze")); self.assertIsNotNone(self.aff("ngozi-eze-2"))

    def test_affiliate_can_rename_own_link_old_one_stops(self):
        self.add_aff("c@t.test", "C C", "cee"); a = self.aff("cee"); dbm.ex("UPDATE users SET password_hash=? WHERE id=?", (PWHASH, a["user_id"]))
        c = self.login_fresh("c@t.test"); r = self.post(c, "/affiliate/link", {"slug": "cee-official"}, follow_redirects=True); self.assertIn(b"OLD link", r.data)
        self.assertIsNotNone(self.aff("cee-official")); self.assertIsNone(self.aff("cee"))
        self.assertNotIn("dda_ref", self.client().get("/r/cee").headers.get("Set-Cookie", "")); self.assertIn("dda_ref", self.client().get("/r/cee-official").headers.get("Set-Cookie", ""))
        self.add_aff()                                                                                  # "chioma" now belongs to someone else
        r = self.post(c, "/affiliate/link", {"slug": "chioma"}, follow_redirects=True); self.assertIn(b"already taken", r.data); self.assertEqual(self.aff("cee-official")["slug"], "cee-official")

class PercentTests(AffBase):
    def test_admin_changes_default_percent_future_sales_only(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test")
        self.purchase(c); self.assertEqual(self.earned(), 100000)                                       # 20% of 5,000
        r = self.post(self.owner_c, "/staff/affiliates/default-percent", {"percent": "35"}, follow_redirects=True); self.assertIn(b"35%", r.data)
        self.purchase(c, "marketing"); self.assertEqual(self.earned(), 100000 + 350000)                 # 35% of 10,000
        self.assertEqual([r["percent"] for r in dbm.q("SELECT percent FROM affiliate_earnings ORDER BY id")], [20.0, 35.0])   # first sale keeps its rate

    def test_personal_rate_overrides_default_and_can_be_cleared(self):
        self.add_aff(percent="50"); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test"); self.purchase(c); self.assertEqual(self.earned(), 250000)
        self.post(self.owner_c, f"/staff/affiliates/{self.aff()['id']}", {"action": "update", "slug": "chioma", "percent": ""})
        self.assertIsNone(self.aff()["percent"]); self.purchase(c, "marketing"); self.assertEqual(self.earned(), 250000 + 200000)

    def test_percent_validation(self):
        for bad in ("101", "-1", "abc", ""):
            self.post(self.owner_c, "/staff/affiliates/default-percent", {"percent": bad}); self.assertEqual(S.get("affiliate.percent"), "20", bad)
        r = self.add_aff(percent="150"); self.assertIn(b"0 to 100", r.data); self.assertIsNone(self.aff())

    def test_discounts_reduce_the_commission_base(self):
        dbm.ex("INSERT INTO promos(code,percent_off,applies_to) VALUES ('HALF',50,'all')")
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test")
        ref = self.buy(c, "course", "paid-maths", promo="HALF"); self.approve(self.tx(ref)["id"]); self.assertEqual(self.earned(), 50000)   # 20% of 2,500

    def test_subscriptions_only_when_switched_on(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test")
        ref = self.buy(c, "plan", self.plan_a); self.approve(self.tx(ref)["id"]); self.assertEqual(self.earned(), 0)
        S.put("affiliate.on_plans", "1"); ref = self.buy(c, "plan", self.plan_i); self.approve(self.tx(ref)["id"]); self.assertEqual(self.earned(), 600000)

class LedgerSafetyTests(AffBase):
    def test_credited_exactly_once_even_if_approved_repeatedly(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test")
        tid = self.purchase(c)
        for _ in range(3): self.approve(tid)
        self.assertEqual(self.val("SELECT COUNT(*) FROM affiliate_earnings"), 1)

    def test_nothing_earned_until_payment_confirmed(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test"); ref = self.buy(c, "course", "paid-maths"); self.assertEqual(self.earned(), 0)
        self.post(self.client("officer"), f"/staff/payments/{self.tx(ref)['id']}", {"action": "reject", "confirm": "1", "text": "no"}); self.assertEqual(self.earned(), 0)

    def test_refund_takes_the_commission_back(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test"); tid = self.purchase(c); self.assertEqual(self.earned(), 100000)
        self.post(self.client("refunder"), f"/staff/payments/{tid}", {"action": "refund", "text": "asked", "confirm": "1"})
        self.assertEqual(self.earned(), 0); self.assertEqual(A.summary(self.aff()["id"])["sales"], 1)

    def test_free_promo_purchase_earns_nothing(self):
        dbm.ex("INSERT INTO promos(code,percent_off,applies_to) VALUES ('FREE',100,'all')")
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test"); self.buy(c, "course", "paid-maths", promo="FREE", submit=False); self.assertEqual(self.earned(), 0)

class AddRemoveTests(AffBase):
    def test_add_creates_account_with_setup_link_for_new_person(self):
        r = self.add_aff(); self.assertIn(b"/r/chioma", r.data); self.assertIn(b"/reset-password/", r.data)
        u = self.row("SELECT * FROM users WHERE email='chioma@t.test'"); self.assertEqual(u["role"], "student"); self.assertEqual(self.aff()["user_id"], u["id"])
        self.assertEqual(self.val("SELECT COUNT(*) FROM password_resets WHERE user_id=?", (u["id"],)), 1)

    def test_add_existing_user_by_email(self):
        r = self.add_aff("alice@t.test", "", "alice-promo"); self.assertNotIn(b"/reset-password/", r.data); self.assertEqual(self.aff("alice-promo")["user_id"], self.users["alice"])
        self.assertIn(b"already an affiliate", self.add_aff("alice@t.test", "", "alice-2").data)

    def test_deactivated_account_cannot_be_added(self):
        dbm.ex("UPDATE users SET is_active=0 WHERE id=?", (self.users["bob"],)); self.assertIn(b"deactivated", self.add_aff("bob@t.test", "", "bobby").data)

    def test_remove_stops_link_and_new_earnings_but_keeps_history_and_balance(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test"); self.purchase(c); a = self.aff()
        r = self.post(self.owner_c, f"/staff/affiliates/{a['id']}", {"action": "remove"}, follow_redirects=True); self.assertIn(b"confirmation", r.data); self.assertEqual(self.aff()["status"], "active")
        self.post(self.owner_c, f"/staff/affiliates/{a['id']}", {"action": "remove", "confirm": "1"}); self.assertEqual(self.aff()["status"], "removed")
        self.assertNotIn("dda_ref", self.client().get("/r/chioma").headers.get("Set-Cookie", ""))      # link dead
        self.purchase(c, "marketing"); self.assertEqual(self.earned(), 100000)                           # nothing new
        self.assertEqual(A.summary(a["id"])["available"], 100000)                                        # what was earned is still theirs
        self.assertIn(b"Removed (1)", self.owner_c.get("/staff/affiliates").data)
        self.assertNotIn(b"/r/chioma", self.owner_c.get("/staff/affiliates").data)                       # gone from the active list
        self.assertIn(b"/r/chioma", self.owner_c.get("/staff/affiliates?tab=removed").data)

    def test_restore_resumes_earning_for_people_already_tied(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test"); a = self.aff()
        self.post(self.owner_c, f"/staff/affiliates/{a['id']}", {"action": "remove", "confirm": "1"}); self.post(self.owner_c, f"/staff/affiliates/{a['id']}", {"action": "restore"})
        self.assertEqual(self.aff()["status"], "active"); self.purchase(c); self.assertEqual(self.earned(), 100000)
        self.assertIn("dda_ref", self.client().get("/r/chioma").headers.get("Set-Cookie", ""))

    def test_cookie_for_removed_affiliate_can_be_replaced_by_a_new_link(self):
        self.add_aff(); self.add_aff("tunde@t.test", "Tunde Ade", "tunde"); c = self.client(); c.get("/r/chioma")
        self.post(self.owner_c, f"/staff/affiliates/{self.aff()['id']}", {"action": "remove", "confirm": "1"})
        c.get("/r/tunde"); u = self.register(c); self.assertEqual(u["referred_by_affiliate"], self.aff("tunde")["id"])

class AccessTests(AffBase):
    def test_only_permitted_admins_manage_affiliates(self):
        for who in ("noperm", "officer", "alice", "inst"):
            c = self.client(who)
            for url in ("/staff/affiliates", "/staff/affiliates/export.csv"): self.assertEqual(c.get(url).status_code, 403, (who, url))
            self.assertEqual(self.post(c, "/staff/affiliates/new", {"email": "z@t.test", "full_name": "Z"}).status_code, 403)
            self.assertEqual(self.post(c, "/staff/affiliates/default-percent", {"percent": "90"}).status_code, 403)
        self.assertEqual(S.get("affiliate.percent"), "20")
        self.assertEqual(self.client("affman").get("/staff/affiliates").status_code, 200)
        self.assertEqual(self.client().get("/staff/affiliates").status_code, 302)

    def test_dashboard_only_for_affiliates_and_nav_link_appears(self):
        self.assertEqual(self.client("alice").get("/affiliate").status_code, 404)
        self.add_aff("alice@t.test", "", "alice-p"); c = self.client("alice"); r = c.get("/affiliate"); self.assertEqual(r.status_code, 200); self.assertIn(b"/r/alice-p", r.data)
        self.assertIn(b"Affiliate", c.get("/student").data)

    def test_affiliate_sees_only_their_own_data_with_masked_names(self):
        self.add_aff("alice@t.test", "", "alice-p"); self.add_aff("tunde@t.test", "Tunde Ade", "tunde")
        c = self.client(); c.get("/r/tunde"); self.register(c, "secret@t.test", "Secret Person"); self.purchase(c)
        page = self.client("alice").get("/affiliate").data; self.assertNotIn(b"Secret", page); self.assertNotIn(b"secret@t.test", page)
        d = self.client(); d.get("/r/alice-p"); self.register(d, "pat@t.test", "Patricia Obi"); page = self.client("alice").get("/affiliate").data
        self.assertIn(b"Patricia O.", page); self.assertNotIn(b"pat@t.test", page); self.assertNotIn(b"Patricia Obi", page)

    def test_admin_pages_render_with_data(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test"); self.purchase(c); a = self.aff()
        for url in ("/staff/affiliates", "/staff/affiliates?tab=removed", "/staff/affiliates?tab=requests", f"/staff/affiliates/{a['id']}", "/staff/settings/affiliates"):
            self.assertEqual(self.owner_c.get(url).status_code, 200, url)
        self.assertIn(b"Chioma Okafor", self.owner_c.get(f"/staff/affiliates/{a['id']}").data)
        csv = self.owner_c.get("/staff/affiliates/export.csv"); self.assertIn(b"chioma", csv.data); self.assertEqual(self.owner_c.get("/staff/affiliates/999").status_code, 404)

    def test_permission_appears_in_user_permission_list_and_settings_group_saves(self):
        self.assertIn("affiliates.manage", PERMISSIONS_KEYS())
        r = self.post(self.owner_c, "/staff/settings/affiliates", {"affiliate.percent": "12.5", "affiliate.enabled": "1", "affiliate.min_naira": "500", "affiliate.payout_enabled": "1", "affiliate.instructions": "hi"}, follow_redirects=True)
        self.assertEqual(S.get("affiliate.percent"), "12.5"); self.assertEqual(S.get("affiliate.on_plans"), "0")
        self.post(self.owner_c, "/staff/settings/affiliates", {"affiliate.percent": "500", "affiliate.enabled": "1"}); self.assertEqual(S.get("affiliate.percent"), "12.5")

def PERMISSIONS_KEYS():
    from dagba.security import PERMISSIONS; return PERMISSIONS

class WithdrawalTests(AffBase):
    def setUp(self):
        super().setUp(); self.add_aff(); a = self.aff(); dbm.ex("UPDATE users SET password_hash=? WHERE id=?", (PWHASH, a["user_id"]))
        c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test"); self.purchase(c)        # chioma now has 1,000 available
        self.ac = self.login_fresh("chioma@t.test"); self.a = a

    def bank(self): return self.post(self.ac, "/affiliate/account", {"bank": "GTBank", "account_name": "Chioma O", "account_number": "0123456789"})
    def request(self, amt): return self.post(self.ac, "/affiliate/request", {"amount": str(amt)}, follow_redirects=True)
    def pay(self, c, rid, data=None, **form):
        d = {"_csrf": self.tok(c), "action": "pay", "confirm": "1", "rid": str(rid), "reference": "TRX-9"}; d.update(form)
        if data is not False: d["receipt"] = (io.BytesIO(png_bytes() if data is None else data), "r.png")
        return c.post(f"/staff/affiliates/{self.a['id']}", data=d, content_type="multipart/form-data", follow_redirects=True)

    def test_request_needs_bank_details_and_respects_balance(self):
        self.assertIn(b"bank account details", self.request(500).data); self.bank()
        self.assertIn(b"at most", self.request(1001).data); self.assertEqual(self.val("SELECT COUNT(*) FROM affiliate_payouts"), 0)
        self.assertIn(b"Withdrawal requested", self.request(400).data); self.assertEqual(A.summary(self.a["id"])["available"], 60000)
        self.assertIn(b"already have a withdrawal", self.request(100).data)
        self.assertTrue(self.val("SELECT COUNT(*) FROM notifications WHERE kind='payout' AND title LIKE '%affiliate%'") >= 1)

    def test_minimum_and_switch(self):
        self.bank(); S.put("affiliate.min_naira", "500"); self.assertIn(b"minimum", self.request(100).data)
        S.put("affiliate.payout_enabled", "0"); self.assertIn(b"switched off", self.request(600).data)

    def test_cancel_returns_money(self):
        self.bank(); self.request(1000); rid = self.val("SELECT id FROM affiliate_payouts"); self.assertEqual(A.summary(self.a["id"])["available"], 0)
        self.post(self.ac, f"/affiliate/{rid}/cancel"); self.assertEqual(A.summary(self.a["id"])["available"], 100000)

    def test_admin_must_upload_receipt_then_affiliate_sees_it(self):
        self.bank(); self.request(1000); rid = self.val("SELECT id FROM affiliate_payouts")
        self.assertIn(b"receipt", self.pay(self.owner_c, rid, data=False).data); self.assertEqual(self.row("SELECT status FROM affiliate_payouts")["status"], "requested")
        self.assertIn(b"Marked as paid", self.pay(self.owner_c, rid).data); r = self.row("SELECT * FROM affiliate_payouts"); self.assertEqual((r["status"], r["transfer_reference"]), ("paid", "TRX-9"))
        self.assertEqual(self.ac.get(f"/affiliate/receipt/{rid}").status_code, 200); self.assertEqual(self.client("alice").get(f"/affiliate/receipt/{rid}").status_code, 403)
        self.assertIn(b"already been processed", self.pay(self.owner_c, rid).data)
        s = A.summary(self.a["id"]); self.assertEqual((s["paid"], s["available"]), (100000, 0))

    def test_decline_returns_money_and_needs_reason(self):
        self.bank(); self.request(1000); rid = self.val("SELECT id FROM affiliate_payouts")
        d = lambda **k: self.post(self.owner_c, f"/staff/affiliates/{self.a['id']}", dict({"action": "reject", "rid": rid, "confirm": "1"}, **k), follow_redirects=True)
        self.assertIn(b"reason", d(reason="").data); d(reason="Details do not match"); self.assertEqual(A.summary(self.a["id"])["available"], 100000)

    def test_removed_affiliate_can_still_withdraw_earned_money(self):
        self.post(self.owner_c, f"/staff/affiliates/{self.a['id']}", {"action": "remove", "confirm": "1"}); self.bank(); self.assertIn(b"Withdrawal requested", self.request(1000).data)
        self.assertEqual(self.ac.get("/affiliate").status_code, 200)

    def test_nobody_can_decide_their_own_request(self):
        dbm.ex("INSERT INTO user_permissions VALUES (?,?)", (self.a["user_id"], "affiliates.manage")); dbm.ex("UPDATE users SET role='admin' WHERE id=?", (self.a["user_id"],))
        c = self.login_fresh("chioma@t.test"); self.bank_admin = self.post(c, "/affiliate/account", {"bank": "GTBank", "account_name": "C", "account_number": "0123456789"})
        self.post(c, "/affiliate/request", {"amount": "1000"}); rid = self.val("SELECT id FROM affiliate_payouts")
        self.assertIn(b"cannot decide your own", self.pay(c, rid).data); self.assertEqual(self.row("SELECT status FROM affiliate_payouts")["status"], "requested")

    def test_csrf_enforced(self):
        c = self.login_fresh("chioma@t.test"); self.assertEqual(c.post("/affiliate/request", data={"amount": "1"}).status_code, 400)
        self.assertEqual(self.owner_c.post("/staff/affiliates/new", data={"email": "a@b.co"}).status_code, 400)

class SchemaTests(AffBase):
    def test_database_guards_double_credit_and_bad_rates(self):
        self.add_aff(); c = self.client(); c.get("/r/chioma"); self.register(c, "b@t.test"); tid = self.purchase(c); a = self.aff()
        dbm.ex("INSERT OR IGNORE INTO affiliate_earnings(affiliate_id,transaction_id,buyer_id,kind,gross_kobo,percent,amount_kobo) VALUES (?,?,?,?,?,?,?)", (a["id"], tid, 1, "sale", 1, 99, 1))
        self.assertEqual(self.val("SELECT COUNT(*) FROM affiliate_earnings"), 1)
        with self.assertRaises(Exception): dbm.ex("UPDATE affiliates SET percent=150 WHERE id=?", (a["id"],))
        with self.assertRaises(Exception): dbm.ex("INSERT INTO affiliates(user_id,slug) VALUES (?,?)", (self.users["bob"], "CHIOMA"))   # slugs unique, case-insensitively
