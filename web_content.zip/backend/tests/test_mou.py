"""Tutor MOU and electronic signature: admin versioning, mandatory signing on submission (checked on the server), immutability, access control,
PDF generation, records register, and that the existing tutor flows still work."""
import io, os, re, shutil, subprocess, sqlite3, tempfile
from .base import *
from .test_tutors import TutBase
from dagba.services import mou as M, tutors as T
from dagba.security import PERMISSIONS

def pdf_text(data):
    """Plain text of a PDF (pdftotext or pypdf); None when neither is available."""
    try:
        import pypdf
        return "\n".join(p.extract_text() or "" for p in pypdf.PdfReader(io.BytesIO(data)).pages)
    except ImportError: pass
    if shutil.which("pdftotext"):
        with tempfile.NamedTemporaryFile(suffix=".pdf") as f:
            f.write(data); f.flush(); return subprocess.run(["pdftotext", "-layout", f.name, "-"], capture_output=True, text=True).stdout
    return None

NEW_BODY = "<h2>1. Parties</h2><p>REVISED TERMS: this second text replaces the first for future signatories only, and sets out the full arrangement between the Academy and the Tutor in detail.</p><h2>2. Duties</h2><ol><li>Do the work.</li><li>Keep records.</li></ol>"

class MouBase(TutBase):
    def setUp(self):
        super().setUp()
        self.mk("mouadmin", "admin", perms=["mou.manage"]); self.mk("inst3", "instructor")
        self.m = self.client("mouadmin")
    def signed(self, who="eve"):
        c, aid, cid = self.submitted_application(who); return c, aid, cid, M.for_user(self.users[who])[0]
    def acc_count(self): return self.val("SELECT COUNT(*) FROM mou_acceptances")
    def app_status(self, aid): return self.val("SELECT status FROM tutor_applications WHERE id=?", (aid,))
    def ready_app(self, who="eve"):
        """An application that is complete except for the MOU: returns (client, application id)."""
        c = self.client(who); self.post(c, "/tutor/apply/start"); self.apply_form(c, "save")
        aid = self.val("SELECT id FROM tutor_applications WHERE user_id=?", (self.users[who],)); cid = self.val("SELECT course_id FROM tutor_applications WHERE id=?", (aid,))
        self.assertEqual(self.lesson_via_builder(c, cid).status_code, 200); return c, aid

# ------------------------------------------------------------------ 1. admin: Tutor MOU Management
class AdminManagementTests(MouBase):
    with_mou = False
    def test_create_edit_preview_publish_and_versions(self):
        m = self.m
        self.assertEqual(m.get("/staff/mou").status_code, 200)
        self.assertEqual(self.post(m, "/staff/mou/draft/new").status_code, 302)
        self.assertEqual(m.get("/staff/mou/draft").status_code, 200); self.assertIn(b"mou-editor", m.get("/staff/mou/draft").data + b"mou-editor")
        r = self.post(m, "/staff/mou/draft", {"action": "save", "title": "Tutor MOU", "body_html": MOU_BODY, "change_type": "minor", "change_note": "first"}); self.assertEqual(r.status_code, 302)
        self.assertIsNone(M.current(), "saving a draft must not publish anything")
        self.assertEqual(self.post(m, "/staff/mou/draft", {"action": "preview", "title": "Tutor MOU", "body_html": MOU_BODY}).status_code, 302)
        pv = m.get("/staff/mou/draft/preview"); self.assertEqual(pv.status_code, 200); self.assertIn(b"Preview", pv.data); self.assertIn(b"Electronic signature", pv.data)
        self.assertEqual(m.get("/staff/mou/versions/%d/pdf" % M.draft()["id"]).status_code, 200)       # a draft can be downloaded by the person managing it
        r = self.post(m, "/staff/mou/draft", {"action": "publish", "title": "Tutor MOU", "body_html": MOU_BODY, "change_type": "minor"}); self.assertEqual(r.status_code, 302)
        v1 = M.current(); self.assertEqual(v1["version_label"], "1.0"); self.assertEqual(v1["status"], "published"); self.assertTrue(v1["content_hash"]); self.assertIsNone(M.draft())
        # a later draft does not touch what is published
        self.post(m, "/staff/mou/draft/new"); self.assertEqual(M.draft()["body_html"], v1["body_html"], "a new draft starts as a copy of the published text")
        self.post(m, "/staff/mou/draft", {"action": "save", "title": "Changed", "body_html": NEW_BODY, "change_type": "minor"})
        self.assertEqual(M.current()["body_html"], v1["body_html"]); self.assertEqual(M.current()["title"], "Tutor MOU")
        self.post(m, "/staff/mou/draft", {"action": "publish", "title": "Tutor MOU", "body_html": NEW_BODY, "change_type": "minor"}); self.assertEqual(M.current()["version_label"], "1.1")
        self.post(m, "/staff/mou/draft/new"); self.post(m, "/staff/mou/draft", {"action": "publish", "title": "Tutor MOU", "body_html": MOU_BODY, "change_type": "major"}); self.assertEqual(M.current()["version_label"], "2.0")
        self.post(m, "/staff/mou/draft/new"); self.post(m, "/staff/mou/draft", {"action": "publish", "title": "Tutor MOU", "body_html": NEW_BODY, "change_type": "minor"}); self.assertEqual(M.current()["version_label"], "2.1")
        labels = [v["version_label"] for v in M.versions()]; self.assertEqual(labels, ["2.1", "2.0", "1.1", "1.0"])
        page = m.get("/staff/mou").data.decode()
        for lab in labels: self.assertIn(lab, page)
        for v in M.versions():                                                       # every version can be viewed and downloaded as a PDF
            self.assertEqual(m.get(f"/staff/mou/versions/{v['id']}").status_code, 200)
            r = m.get(f"/staff/mou/versions/{v['id']}/pdf"); self.assertEqual(r.status_code, 200); self.assertTrue(r.data.startswith(b"%PDF"))
        actions = {r["action"] for r in dbm.q("SELECT action FROM audit_logs WHERE action LIKE 'mou.%'")}
        self.assertTrue({"mou.draft_created", "mou.draft_saved", "mou.published", "mou.version_pdf"} <= actions)

    def test_discard_draft_and_validation(self):
        m = self.m; self.post(m, "/staff/mou/draft/new")
        self.post(m, "/staff/mou/draft", {"action": "publish", "title": "T", "body_html": "<p>too short</p>", "change_type": "minor"})
        self.assertIsNone(M.current(), "a near-empty agreement is refused")
        self.post(m, "/staff/mou/draft", {"action": "publish", "title": "", "body_html": MOU_BODY, "change_type": "minor"}); self.assertIsNone(M.current())
        self.post(m, "/staff/mou/draft/discard"); self.assertIsNone(M.draft())

    def test_published_versions_are_immutable_in_the_database(self):
        v = self.publish_mou()
        for sql in ("UPDATE mou_versions SET body_html='x' WHERE id=?", "DELETE FROM mou_versions WHERE id=?", "UPDATE mou_versions SET status='draft', version_label=NULL, published_at=NULL WHERE id=?"):
            with self.assertRaises(sqlite3.DatabaseError): dbm.ex(sql, (v["id"],))
        self.assertEqual(M.get_version(v["id"])["body_html"], v["body_html"])

    def test_publish_assigns_numbers_even_if_two_drafts_race(self):
        self.publish_mou(); self.publish_mou(NEW_BODY, "major"); self.assertEqual([v["version_label"] for v in M.versions()], ["2.0", "1.0"])
        with self.assertRaises(sqlite3.IntegrityError): dbm.ex("INSERT INTO mou_versions(document_id,status,title) VALUES (1,'draft','a')"); dbm.ex("INSERT INTO mou_versions(document_id,status,title) VALUES (1,'draft','b')")

# ------------------------------------------------------------------ 13. access control to management
class AccessTests(MouBase):
    def test_only_authorised_admins_manage(self):
        paths = ["/staff/mou", "/staff/mou/draft", "/staff/mou/draft/preview"]
        self.assertTrue("mou.manage" in PERMISSIONS)
        anon = self.app.test_client()
        for p in paths: r = anon.get(p); self.assertEqual(r.status_code, 302); self.assertIn("/login", r.headers["Location"])
        for who in ("alice", "inst", "writer", "noperm", "officer", "reviewer"):
            c = self.client(who)
            for p in paths: self.assertEqual(c.get(p).status_code, 403, (who, p))
            for p in ("/staff/mou/draft/new", "/staff/mou/draft", "/staff/mou/draft/discard"): self.assertEqual(self.post(c, p, {"action": "publish"}).status_code, 403, (who, p))
        self.assertEqual(self.client("owner").get("/staff/mou").status_code, 200)
        self.assertEqual(self.m.get("/staff/mou").status_code, 200)
        before = M.current(); r = self.post(self.client("reviewer"), "/staff/mou/draft", {"action": "publish", "title": "x", "body_html": MOU_BODY}); self.assertEqual(r.status_code, 403)
        self.assertEqual(M.current()["id"], before["id"])

    def test_csrf_is_enforced(self):
        c = self.m; r = c.post("/staff/mou/draft/new", data={}); self.assertEqual(r.status_code, 400)
        r = c.post("/staff/mou/draft", data={"action": "publish", "_csrf": "wrong"}); self.assertEqual(r.status_code, 400)

    def test_records_pages_need_a_permission(self):
        for who in ("alice", "inst", "noperm", "officer"):
            c = self.client(who)
            for p in ("/staff/mou/records", "/staff/mou/records.csv", "/staff/mou/agreements/DDA-MOU-2026-ABCDEFGH"): self.assertEqual(c.get(p).status_code, 403, (who, p))
        for who in ("reviewer", "mouadmin", "owner"): self.assertEqual(self.client(who).get("/staff/mou/records").status_code, 200)

# ------------------------------------------------------------------ 2. applicant: mandatory acceptance, checked by the backend
class SubmissionTests(MouBase):
    def test_cannot_submit_without_acceptance_or_signature(self):
        c, aid = self.ready_app(); v = M.current(); me = "Eve"
        c.get("/tutor/apply")
        cases = {"nothing": {}, "no signature": dict(mou_version_id=v["id"], mou_agree="1"), "no tick": dict(mou_version_id=v["id"], mou_signature=me), "blank signature": dict(mou_version_id=v["id"], mou_agree="1", mou_signature="   "),
                 "wrong name": dict(mou_version_id=v["id"], mou_agree="1", mou_signature="Someone Else"), "no version": dict(mou_agree="1", mou_signature=me), "bad version": dict(mou_version_id="abc", mou_agree="1", mou_signature=me),
                 "tick not 1": dict(mou_version_id=v["id"], mou_agree="on", mou_signature=me), "huge name": dict(mou_version_id=v["id"], mou_agree="1", mou_signature="Eve" + " " * 5 + "x" * 400)}
        for label, extra in cases.items():
            r = self.apply_form(c, "submit", sign=False, **{}) if not extra else None
            d = self.form(); d.update({k: str(x) for k, x in extra.items()}); d["_csrf"] = self.tok(c); d["action"] = "submit"; d["cover"] = (io.BytesIO(png_bytes()), "c.png")
            r = c.post("/tutor/apply/save", data=d, content_type="multipart/form-data", follow_redirects=True)
            self.assertEqual(self.app_status(aid), "draft", label); self.assertEqual(self.acc_count(), 0, label)
            self.assertIn(b"Memorandum of Understanding", r.data, label)
        # a clear message says what is missing
        r = self.apply_form(c, "submit", sign=False); r = c.get("/tutor/apply")
        self.assertIn(b"Tick the box", self.client_post_text(c)); 

    def client_post_text(self, c):
        d = self.form(); d["_csrf"] = self.tok(c); d["action"] = "submit"; d["cover"] = (io.BytesIO(png_bytes()), "c.png")
        return c.post("/tutor/apply/save", data=d, content_type="multipart/form-data", follow_redirects=True).data

    def test_draft_can_be_saved_without_signing(self):
        c, aid = self.ready_app(); r = self.apply_form(c, "save"); self.assertEqual(r.status_code, 302)
        r = c.get("/tutor/apply"); self.assertIn(b"Draft saved", r.data); self.assertEqual(self.app_status(aid), "draft"); self.assertEqual(self.acc_count(), 0)

    def test_successful_signing_records_everything(self):
        c, aid, cid, acc = self.signed(); v = M.current(); u = dbm.q1("SELECT * FROM users WHERE id=?", (self.users["eve"],))
        self.assertEqual(self.app_status(aid), "pending")
        self.assertEqual(acc["user_id"], u["id"]); self.assertEqual(acc["full_name"], u["full_name"]); self.assertEqual(acc["email"], u["email"]); self.assertEqual(acc["signature"], "Eve")
        self.assertEqual(acc["version_id"], v["id"]); self.assertEqual(acc["version_label"], "1.0"); self.assertEqual(acc["application_id"], aid)
        self.assertEqual(acc["content_html"], v["body_html"]); self.assertEqual(acc["document_title"], v["title"]); self.assertEqual(acc["content_hash"], v["content_hash"])
        self.assertEqual(acc["agreement_text"], M.agreement_text()); self.assertEqual(acc["confirmation_text"], M.confirmation_text())
        self.assertTrue(re.fullmatch(r"DDA-MOU-\d{4}-[A-Z2-9]{8}", acc["reference"])); self.assertTrue(acc["accepted_at"]); self.assertTrue(acc["ip_address"]); self.assertIsNotNone(acc["user_agent"])
        self.assertTrue(M.verify(acc)); self.assertEqual(len(acc["record_hash"]), 64)
        self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_application_events WHERE application_id=? AND event='mou_accepted'", (aid,)), 1)
        self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='mou.accepted'"), 1)
        self.assertIn("Tutor Memorandum of Understanding", c.get("/tutor/apply").data.decode())

    def test_signature_name_is_normalised_but_must_match(self):
        dbm.ex("UPDATE users SET full_name='Ada  Obi' WHERE id=?", (self.users["eve"],))
        c, aid = self.ready_app(); c.get("/tutor/apply"); v = M.current()
        def attempt(sig):
            d = self.form(); d.update(mou_version_id=str(v["id"]), mou_agree="1", mou_signature=sig, _csrf=self.tok(c), action="submit"); d["cover"] = (io.BytesIO(png_bytes()), "c.png")
            c.post("/tutor/apply/save", data=d, content_type="multipart/form-data"); return self.app_status(aid)
        for bad in ("Ada", "Adaobi", "Ada Obi Jr", "Ade Obi"): self.assertEqual(attempt(bad), "draft", bad)
        self.assertEqual(attempt("  aDA    oBI "), "pending")
        self.assertEqual(M.for_user(self.users["eve"])[0]["signature"], "aDA oBI")
        self.assertTrue(M.names_match("ÉMILE  Zola", "émile zola")); self.assertFalse(M.names_match("", "")); self.assertFalse(M.names_match("a", "b"))

    def test_applicant_must_have_been_shown_the_document(self):
        c, aid = self.ready_app()                                  # never loaded the application page or the reader after the MOU was published
        dbm.ex("DELETE FROM mou_views"); v = M.current()
        d = self.form(); d.update(mou_version_id=str(v["id"]), mou_agree="1", mou_signature="Eve", _csrf=self.tok(c), action="submit"); d["cover"] = (io.BytesIO(png_bytes()), "c.png")
        r = c.post("/tutor/apply/save", data=d, content_type="multipart/form-data", follow_redirects=True)
        self.assertEqual(self.app_status(aid), "draft"); self.assertIn(b"open and read the Memorandum", r.data)
        self.assertEqual(c.get("/tutor/apply/mou").status_code, 200)       # opening the reader counts as being shown it
        d["cover"] = (io.BytesIO(png_bytes()), "c.png"); c.post("/tutor/apply/save", data=d, content_type="multipart/form-data"); self.assertEqual(self.app_status(aid), "pending")

    def test_new_version_before_submission_requires_the_latest(self):
        c, aid = self.ready_app(); c.get("/tutor/apply"); old = M.current(); self.publish_mou(NEW_BODY, "minor"); new = M.current(); self.assertEqual(new["version_label"], "1.1")
        d = self.form(); d.update(mou_version_id=str(old["id"]), mou_agree="1", mou_signature="Eve", _csrf=self.tok(c), action="submit"); d["cover"] = (io.BytesIO(png_bytes()), "c.png")
        r = c.post("/tutor/apply/save", data=d, content_type="multipart/form-data", follow_redirects=True)
        self.assertEqual(self.app_status(aid), "draft"); self.assertEqual(self.acc_count(), 0)
        self.assertIn(b"REVISED TERMS", r.data, "the page now shows the latest version")
        self.assertEqual(self.apply_form(c, "submit").status_code, 302); self.assertEqual(self.app_status(aid), "pending"); self.assertEqual(M.for_user(self.users["eve"])[0]["version_label"], "1.1")

    def test_already_signed_version_is_not_asked_again_and_not_duplicated(self):
        c, aid, cid, acc = self.signed()
        self.assertEqual(self.decide(self.rev, aid, "revision", feedback="Please improve the summary").status_code, 302)
        page = c.get("/tutor/apply").data.decode(); self.assertNotIn('name="mou_signature"', page); self.assertIn("do not need to sign it again", page)
        d = self.form(); d["_csrf"] = self.tok(c); d["action"] = "submit"; d["cover"] = (io.BytesIO(png_bytes()), "c.png")     # no MOU fields at all
        c.post("/tutor/apply/save", data=d, content_type="multipart/form-data"); self.assertEqual(self.app_status(aid), "pending")
        self.assertEqual(self.acc_count(), 1); self.assertEqual(M.for_user(self.users["eve"])[0]["reference"], acc["reference"])
        # but a newer published version means the next resubmission must sign it
        self.decide(self.rev, aid, "revision", feedback="Again"); self.publish_mou(NEW_BODY, "major")
        d["cover"] = (io.BytesIO(png_bytes()), "c.png"); c.post("/tutor/apply/save", data=d, content_type="multipart/form-data"); self.assertEqual(self.app_status(aid), "revision")
        self.assertEqual(self.apply_form(c, "submit").status_code, 302); self.assertEqual(self.app_status(aid), "pending")
        self.assertEqual([r["version_label"] for r in M.for_user(self.users["eve"])], ["2.0", "1.0"])

    def test_accept_is_idempotent_and_unique_per_version(self):
        c, aid, cid, acc = self.signed(); v = M.current(); u = dbm.q1("SELECT * FROM users WHERE id=?", (self.users["eve"],)); a = T.get(aid)
        with self.app.test_request_context("/"):
            again = M.accept(u, a, v, {"mou_signature": "Eve"}); self.assertEqual(again["id"], acc["id"])
        self.assertEqual(self.acc_count(), 1)
        with self.assertRaises(sqlite3.IntegrityError):            # even bypassing the service, the database refuses a second record for the same version
            dbm.ex("""INSERT INTO mou_acceptances(reference,user_id,version_id,version_label,document_title,content_html,content_hash,full_name,email,signature,agreement_text,confirmation_text,record_hash)
                      VALUES ('X1',?,?,?,?,?,?,?,?,?,?,?,?)""", (u["id"], v["id"], v["version_label"], v["title"], v["body_html"], v["content_hash"], "a", "b", "c", "d", "e", "f"))
        r = self.apply_form(c, "submit"); self.assertEqual(self.acc_count(), 1)                 # a repeated POST after submission changes nothing

    def test_submission_and_acceptance_commit_together(self):
        c, aid = self.ready_app(); orig = T._submit
        def boom(*a, **k): raise RuntimeError("simulated failure after the agreement was written")
        T._submit = boom
        try:
            with self.assertRaises(RuntimeError): self.apply_form(c, "submit")
        finally: T._submit = orig
        self.assertEqual(self.acc_count(), 0, "no acceptance without a submitted application"); self.assertEqual(self.app_status(aid), "draft")
        self.assertEqual(self.apply_form(c, "submit").status_code, 302); self.assertEqual(self.app_status(aid), "pending"); self.assertEqual(self.acc_count(), 1)

    def test_signature_section_is_in_the_application_page(self):
        c, aid = self.ready_app(); p = c.get("/tutor/apply").data.decode()
        for s in ("Review and Sign Tutor Memorandum of Understanding", M.agreement_text(), M.confirmation_text(), 'name="mou_signature"', 'name="mou_agree"', "Download unsigned PDF", "full-screen reader", "REVISED TERMS" if False else "Parties"): self.assertIn(s, p)
        self.assertEqual(c.get("/tutor/apply/mou").status_code, 200)
        r = c.get("/tutor/apply/mou.pdf"); self.assertEqual(r.status_code, 200); self.assertTrue(r.data.startswith(b"%PDF"))

class NoPublishedMouTests(MouBase):
    with_mou = False
    def test_submission_blocked_until_published_but_drafts_work(self):
        c, aid = self.ready_app(); self.assertEqual(self.apply_form(c, "save").status_code, 302)
        r = self.apply_form(c, "submit"); self.assertEqual(self.app_status(aid), "draft")
        page = c.get("/tutor/apply").data.decode(); self.assertIn("not been published", page); self.assertRegex(page, r'<button class="btn ok" name="action" value="submit"\s+disabled')
        self.publish_mou(); self.with_mou = True; self.assertEqual(self.apply_form(c, "submit").status_code, 302); self.assertEqual(self.app_status(aid), "pending")

# ------------------------------------------------------------------ 7-10, 12: signed agreements: instructor, admin, history
class AgreementAccessTests(MouBase):
    def approved(self, who="eve"):
        c, aid, cid, acc = self.signed(who); self.approve(aid, price="25000"); self.assertEqual(self.val("SELECT role FROM users WHERE id=?", (self.users[who],)), "instructor"); return c, aid, acc

    def test_instructor_sees_views_and_downloads_their_signed_mou(self):
        c, aid, acc = self.approved()
        r = c.get("/staff/tutor/agreement"); self.assertEqual(r.status_code, 200); h = r.data.decode()
        for s in ("My Agreement / Signed MOU", acc["reference"], "1.0", "Signed", "Download PDF", "View document", acc["accepted_at"][:16]): self.assertIn(s, h)
        self.assertIn("My Agreement / Signed MOU", c.get("/staff/").data.decode(), "listed in the instructor dashboard menu")
        r = c.get(f"/staff/tutor/agreement/{acc['reference']}"); self.assertEqual(r.status_code, 200); h = r.data.decode()
        for s in ("1. Parties", "Electronic signature", "Eve", acc["email"], acc["content_hash"], "not a verified identity credential"): self.assertIn(s, h)
        r = c.get(f"/staff/tutor/agreement/{acc['reference']}/pdf"); self.assertEqual(r.status_code, 200); self.assertEqual(r.mimetype, "application/pdf"); self.assertTrue(r.data.startswith(b"%PDF"))
        self.assertIn("attachment", r.headers["Content-Disposition"]); self.assertIn(acc["reference"], r.headers["Content-Disposition"]); self.assertIn("no-store", r.headers["Cache-Control"])
        txt = re.sub(r"\s+", " ", pdf_text(r.data) or "")
        if txt:
            for s in (acc["reference"], "Eve", acc["email"], "1.0", "1. Parties", "Page 1 of", "ELECTRONIC SIGNATURE AND ACCEPTANCE RECORD", acc["accepted_at"], "not a verified identity credential"): self.assertIn(s, txt)
        self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='mou.agreement_downloaded'"), 1)

    def test_nobody_else_can_open_it(self):
        c, aid, acc = self.approved(); ref = acc["reference"]
        other = self.client("inst3"); stranger = self.client("bob"); anon = self.app.test_client()
        for cl in (other, stranger):
            for p in (f"/staff/tutor/agreement/{ref}", f"/staff/tutor/agreement/{ref}/pdf"): self.assertEqual(cl.get(p).status_code, 404, p)
            for p in (f"/staff/mou/agreements/{ref}", f"/staff/mou/agreements/{ref}/pdf"): self.assertEqual(cl.get(p).status_code, 403, p)
        for p in (f"/staff/tutor/agreement/{ref}", f"/staff/tutor/agreement/{ref}/pdf", f"/staff/mou/agreements/{ref}", "/staff/tutor/agreement"): r = anon.get(p); self.assertEqual(r.status_code, 302); self.assertIn("/login", r.headers["Location"])
        self.assertEqual(self.client("inst2").get("/staff/tutor/agreement").status_code, 200)            # an instructor with no agreement sees an explanation, nothing of others
        self.assertNotIn(ref, self.client("inst2").get("/staff/tutor/agreement").data.decode())
        self.assertEqual(self.client("alice").get("/staff/tutor/agreement").status_code, 403)
        self.assertEqual(other.get(f"/staff/tutor/agreement/DDA-MOU-2026-NOSUCHAA").status_code, 404)
        for verb in ("post", "put", "delete"):                                                    # applicants and tutors have no way to change or remove a signed agreement
            r = getattr(c, verb)(f"/staff/tutor/agreement/{ref}", data={"_csrf": self.tok(c)}); self.assertIn(r.status_code, (400, 405))
        self.assertEqual(self.acc_count(), 1)

    def test_admin_can_open_any_agreement_and_it_is_logged(self):
        c, aid, acc = self.approved(); ref = acc["reference"]
        for who in ("reviewer", "mouadmin", "owner"):
            a = self.client(who); self.assertEqual(a.get(f"/staff/mou/agreements/{ref}").status_code, 200)
            r = a.get(f"/staff/mou/agreements/{ref}/pdf"); self.assertEqual(r.status_code, 200); self.assertTrue(r.data.startswith(b"%PDF"))
        self.assertEqual(self.client("noperm").get(f"/staff/mou/agreements/{ref}").status_code, 403)
        self.assertGreaterEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action IN ('mou.agreement_viewed','mou.agreement_downloaded')"), 6)
        h = self.client("reviewer").get(f"/staff/mou/agreements/{ref}").data.decode(); self.assertIn("Recorded IP address", h)
        self.assertNotIn("Recorded IP address", c.get(f"/staff/tutor/agreement/{ref}").data.decode(), "the IP address is for administrators")
        d = self.client("reviewer").get(f"/staff/tutors/{self.users['eve']}").data.decode()
        for s in ("Memorandum of Understanding", ref, "View signed MOU", "Download PDF", "eve@t.test", "1.0"): self.assertIn(s, d)
        d = self.client("reviewer").get(f"/staff/tutors/applications/{aid}").data.decode(); self.assertIn(ref, d)

    def test_publishing_a_new_version_leaves_signed_agreements_untouched(self):
        c, aid, acc = self.approved(); old_html, old_hash, ref = acc["content_html"], acc["content_hash"], acc["reference"]
        old_pdf = c.get(f"/staff/tutor/agreement/{ref}/pdf").data
        self.publish_mou(NEW_BODY, "major"); self.assertEqual(M.current()["version_label"], "2.0")
        now_acc = M.by_reference(ref); self.assertEqual(now_acc["content_html"], old_html); self.assertEqual(now_acc["content_hash"], old_hash); self.assertEqual(now_acc["version_label"], "1.0"); self.assertTrue(M.verify(now_acc))
        h = c.get(f"/staff/tutor/agreement/{ref}").data.decode(); self.assertIn("1. Parties", h); self.assertNotIn("REVISED TERMS", h)
        p = c.get("/staff/tutor/agreement"); self.assertIn("A newer version", p.data.decode()); self.assertIn("Signed (earlier version)", p.data.decode())
        txt = pdf_text(c.get(f"/staff/tutor/agreement/{ref}/pdf").data)
        if txt: self.assertIn("1. Parties", txt); self.assertNotIn("REVISED TERMS", txt)
        self.assertEqual(M.agreement_pdf(now_acc)[:4], b"%PDF")
        # the tutor signs the new version later: both agreements stay available
        u = dbm.q1("SELECT * FROM users WHERE id=?", (self.users["eve"],)); db = dbm.get_db(); db.execute("BEGIN IMMEDIATE")
        with self.app.test_request_context("/"): second = M.accept(u, None, M.current(), {"mou_signature": "Eve"})
        db.execute("COMMIT")
        rows = M.for_user(self.users["eve"]); self.assertEqual([r["version_label"] for r in rows], ["2.0", "1.0"])
        h = c.get("/staff/tutor/agreement").data.decode(); self.assertIn(ref, h); self.assertIn(second["reference"], h)
        for r in rows: self.assertEqual(c.get(f"/staff/tutor/agreement/{r['reference']}/pdf").status_code, 200)
        a = self.client("reviewer"); h = a.get(f"/staff/tutors/{self.users['eve']}").data.decode(); self.assertIn(ref, h); self.assertIn(second["reference"], h)
        sv = {v["version_label"]: v["signed"] for v in M.versions()}; self.assertEqual(sv, {"2.0": 1, "1.0": 1})
        self.assertIn("2.0", self.m.get("/staff/mou").data.decode())

    def test_signed_agreements_cannot_be_changed_or_deleted(self):
        c, aid, acc = self.approved()
        for sql in ("UPDATE mou_acceptances SET signature='Mallory' WHERE id=?", "UPDATE mou_acceptances SET content_html='<p>x</p>' WHERE id=?", "DELETE FROM mou_acceptances WHERE id=?"):
            with self.assertRaises(sqlite3.DatabaseError): dbm.ex(sql, (acc["id"],))
        with self.assertRaises(sqlite3.DatabaseError): dbm.ex("DELETE FROM users WHERE id=?", (self.users["eve"],))
        with self.assertRaises(sqlite3.DatabaseError): dbm.ex("DELETE FROM mou_versions WHERE id=?", (acc["version_id"],))
        u = self.users["eve"]; v = M.current()                       # a record cannot be inserted with text that differs from the published version
        with self.assertRaises(sqlite3.DatabaseError):
            dbm.ex("""INSERT INTO mou_acceptances(reference,user_id,version_id,version_label,document_title,content_html,content_hash,full_name,email,signature,agreement_text,confirmation_text,record_hash)
                      VALUES ('FAKE',?,?,?,?,?,?,?,?,?,?,?,?)""", (self.users["bob"], v["id"], "1.0", "t", "<p>forged</p>", "0" * 64, "a", "b", "c", "d", "e", "f"))

    def test_tampering_is_detectable(self):
        c, aid, acc = self.approved(); self.assertTrue(M.verify(acc)); self.assertEqual(M.status_of(acc)[0], "Signed")
        dbm.ex("DROP TRIGGER trg_mou_acc_no_update"); dbm.ex("UPDATE mou_acceptances SET signature='Mallory' WHERE id=?", (acc["id"],))
        bad = M.by_reference(acc["reference"]); self.assertFalse(M.verify(bad)); self.assertEqual(M.status_of(bad)[0], "Integrity check failed")
        self.assertIn("Integrity check failed", self.client("reviewer").get(f"/staff/mou/agreements/{acc['reference']}").data.decode())

# ------------------------------------------------------------------ the central register
class RecordsTests(MouBase):
    def test_search_filter_and_export(self):
        c1, a1, _cid1, acc1 = self.signed("eve"); self.approve(a1, price="1000")
        self.publish_mou(NEW_BODY, "major"); self.mk("zed", "student"); dbm.ex("UPDATE users SET full_name='Zed Zulu' WHERE id=?", (self.users["zed"],))
        c2, a2, cid2 = self.submitted_application("zed"); acc2 = M.for_user(self.users["zed"])[0]; self.assertEqual(acc2["version_label"], "2.0")
        r = self.client("reviewer"); base = "/staff/mou/records"
        def refs(qs): return {x for x in re.findall(r"DDA-MOU-\d{4}-[A-Z2-9]{8}", r.get(base + qs).data.decode())}
        self.assertEqual(refs(""), {acc1["reference"], acc2["reference"]})
        self.assertEqual(refs("?q=zulu"), {acc2["reference"]}); self.assertEqual(refs("?q=eve@t.test"), {acc1["reference"]}); self.assertEqual(refs("?q=" + acc1["reference"][-6:]), {acc1["reference"]}); self.assertEqual(refs("?q=nobody"), set())
        self.assertEqual(refs(f"?version={acc1['version_id']}"), {acc1["reference"]}); self.assertEqual(refs(f"?version={acc2['version_id']}"), {acc2["reference"]})
        self.assertEqual(refs("?status=current"), {acc2["reference"]}); self.assertEqual(refs("?status=earlier"), {acc1["reference"]})
        self.assertEqual(refs("?account=tutor"), {acc1["reference"]}); self.assertEqual(refs("?account=applicant"), {acc2["reference"]})
        today = acc1["accepted_at"][:10]; self.assertEqual(refs(f"?from={today}&to={today}"), {acc1["reference"], acc2["reference"]}); self.assertEqual(refs("?from=2999-01-01"), set()); self.assertEqual(refs("?to=2000-01-01"), set())
        self.assertEqual(refs("?q=%25"), set(), "LIKE wildcards in the search box are escaped")
        csv_ = r.get(base + ".csv?q=zulu"); self.assertEqual(csv_.status_code, 200); body = csv_.data.decode()
        self.assertIn("text/csv", csv_.mimetype); self.assertIn(acc2["reference"], body); self.assertNotIn(acc1["reference"], body); self.assertIn("Content SHA-256", body)
        self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='mou.register_exported'"), 1)
        for p in (f"/staff/mou/agreements/{acc1['reference']}", f"/staff/mou/agreements/{acc2['reference']}/pdf"): self.assertEqual(r.get(p).status_code, 200)

    def test_csv_neutralises_formulas(self):
        dbm.ex("UPDATE users SET full_name='=cmd|x' WHERE id=?", (self.users["eve"],))
        self.ready_app(); c = self.client("eve"); c.get("/tutor/apply"); self.assertEqual(self.apply_form(c, "submit").status_code, 302)
        body = self.client("reviewer").get("/staff/mou/records.csv").data.decode(); self.assertIn("'=cmd|x", body)

# ------------------------------------------------------------------ pages render, PDF quality, sanitiser, and existing flows
class RenderingTests(MouBase):
    def test_all_pages_render_and_menu_links(self):
        self.publish_mou(); self.post(self.m, "/staff/mou/draft/new")
        for p in ("/staff/mou", "/staff/mou/draft", "/staff/mou/draft/preview", "/staff/mou/records", f"/staff/mou/versions/{M.current()['id']}"): self.assertEqual(self.m.get(p).status_code, 200, p)
        menu = self.m.get("/staff/mou").data.decode(); self.assertIn("Tutor MOU Management", menu); self.assertIn("Signed MOU records", menu)
        self.assertIn("Signed MOU records", self.client("reviewer").get("/staff/tutors").data.decode())
        self.assertNotIn("Tutor MOU Management", self.client("reviewer").get("/staff/tutors").data.decode())
        for who in ("alice", "inst"): self.assertEqual(self.client(who).get("/tutor/apply/mou").status_code, 200)
        self.assertEqual(self.app.test_client().get("/tutor/apply/mou").status_code, 302)

    def test_unsigned_pdf_and_long_unicode_document(self):
        body = "".join(f"<h2>{i}. Clause heading ọ̀ṣẹ</h2><p>Paragraph “quoted” — Ẹ káàbọ̀ {i}. " + "Lorem ipsum dolor sit amet, consectetur adipiscing elit. " * 12 + "</p><ul><li>Point <strong>bold</strong> and <em>italic</em> <u>u</u></li><li>Another<ol><li>nested one</li><li>nested two</li></ol></li></ul>" for i in range(1, 25))
        v = self.publish_mou(body, "major"); data = M.version_pdf(v); self.assertTrue(data.startswith(b"%PDF")); txt = pdf_text(data)
        if txt: self.assertRegex(txt, r"Page 1 of \d+"); self.assertIn("Unsigned review copy", txt); self.assertIn("Version 2.0", txt); self.assertIn("Clause heading", txt)
        dbm.ex("UPDATE users SET full_name='Ọláyínká Adéyemí-Nwosu' WHERE id=?", (self.users["eve"],))
        c, aid, cid, acc = self.signed(); r = c.get(f"/staff/tutor/agreement/{acc['reference']}/pdf"); self.assertEqual(r.status_code, 200)
        self.assertGreater(len(M.agreement_pdf(acc)), 3000)

    def test_sanitiser_blocks_active_content_and_is_idempotent(self):
        evil = '<p onclick="x()">Hi <script>alert(1)</script><img src=x onerror=alert(1)><a href="javascript:alert(1)">bad</a> <a href="https://ok.example/a?b=1&c=2" onmouseover="x">good</a></p><iframe src="//e"></iframe><style>p{}</style><h1>Top</h1><div>div text</div><b>b</b><i>i</i><li>stray</li>'
        s = M.sanitize(evil)
        for bad in ("<script", "onclick", "onerror", "javascript:", "<img", "<iframe", "<style", "onmouseover", "alert("): self.assertNotIn(bad, s)
        self.assertIn('<a href="https://ok.example/a?b=1&amp;c=2" rel="noopener noreferrer nofollow" target="_blank">good</a>', s); self.assertIn("<h2>Top</h2>", s); self.assertIn("<strong>b</strong>", s)
        self.assertEqual(M.sanitize(s), s); self.assertEqual(M.sanitize(M.sanitize(MOU_BODY)), M.sanitize(MOU_BODY)); self.assertEqual(str(M.safe_markup(evil)), s)
        self.assertEqual(M.sanitize("<ul><li>a</li><ul><li>b</li></ul></ul>"), "<ul><li>a<ul><li>b</li></ul></li></ul>")
        self.assertEqual(M.sanitize("plain text"), "<p>plain text</p>"); self.assertEqual(M.sanitize(""), "")
        self.assertEqual(M.sanitize("<p>&lt;script&gt;</p>"), "<p>&lt;script&gt;</p>")
        # the stored XSS attempt through the HTTP editor never reaches the page
        self.post(self.m, "/staff/mou/draft/new"); self.post(self.m, "/staff/mou/draft", {"action": "save", "title": "<b>T</b>", "body_html": evil + MOU_BODY, "change_type": "minor"})
        self.assertNotIn("<script", self.m.get("/staff/mou/draft/preview").data.decode().replace("<script src", ""))
        self.assertNotIn("alert(1)", M.draft()["body_html"])

class ExistingFlowTests(MouBase):
    def test_existing_tutors_submitting_courses_are_not_asked_to_sign(self):
        cid = dbm.ex("INSERT INTO courses(division,title,slug,price_kobo,status,instructor_id) VALUES ('income','Extra','extra',1000,'review',?)", (self.users["inst2"],))
        dbm.ex("INSERT INTO lessons(course_id,title,kind,body,position) VALUES (?,?,?,?,1)", (cid, "L1", "text", "b"))
        aid = T.course_submitted(cid, dbm.q1("SELECT * FROM users WHERE id=?", (self.users["inst2"],))); self.assertTrue(aid)
        self.assertEqual(dbm.q1("SELECT kind, status FROM tutor_applications WHERE id=?", (aid,))["status"], "pending"); self.assertEqual(self.acc_count(), 0)
        self.assertEqual(self.client("inst2").get("/staff/tutor/submissions").status_code, 200)
        self.assertEqual(self.approve(aid, price="1000").status_code, 302); self.assertEqual(self.val("SELECT status FROM courses WHERE id=?", (cid,)), "published")

    def test_a_tutor_draft_cannot_reach_review_through_the_course_path(self):
        """course_submitted() must not push an unsigned 'tutor' application to pending (it is only reachable for role instructor)."""
        c, aid = self.ready_app(); dbm.ex("UPDATE users SET role='instructor' WHERE id=?", (self.users["eve"],)); cid = self.val("SELECT course_id FROM tutor_applications WHERE id=?", (aid,))
        dbm.ex("UPDATE courses SET status='review' WHERE id=?", (cid,)); T.course_submitted(cid, dbm.q1("SELECT * FROM users WHERE id=?", (self.users["eve"],)))
        self.assertEqual(self.app_status(aid), "draft")

    def test_legacy_applications_and_tutors_still_work(self):
        legacy = dbm.ex("INSERT INTO tutor_applications(user_id,kind,status,full_name,title,course_id,submitted_at) VALUES (?,?,?,?,?,?,datetime('now'))", (self.users["bob"], "tutor", "pending", "Bob", "Old", self.paid))
        page = self.client("reviewer").get(f"/staff/tutors/applications/{legacy}").data.decode(); self.assertIn("No signed MOU is on file", page)
        self.assertIn("No signed MOU on file", self.client("reviewer").get(f"/staff/tutors/{self.users['inst']}").data.decode())
        self.assertIn("No signed MOU is on file", self.client("inst").get("/staff/tutor/agreement").data.decode())
        self.assertEqual(self.client("inst").get("/staff/").status_code, 200)
