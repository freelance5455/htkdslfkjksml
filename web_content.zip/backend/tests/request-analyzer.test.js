import { test } from 'node:test';
import assert from 'node:assert/strict';
import { RequestAnalyzer } from '../src/core/request-analyzer.js';

const analyzer = new RequestAnalyzer();

test('RequestAnalyzer: rejeita query vazia', () => {
  assert.throws(() => analyzer.analyze(''), /obrigatorio/);
  assert.throws(() => analyzer.analyze('   '), /obrigatorio/);
  assert.throws(() => analyzer.analyze(null), /obrigatorio/);
});

test('RequestAnalyzer: identifica categoria de recurso a partir da linguagem natural', () => {
  const r1 = analyzer.analyze('Preciso de uma textura de pedra para o chao');
  assert.equal(r1.resourceCategory, 'texture');

  const r2 = analyzer.analyze('Quero um modelo 3d de uma criatura voadora');
  assert.equal(r2.resourceCategory, 'model');

  const r3 = analyzer.analyze('Pesquise efeitos sonoros de maquinas');
  assert.equal(r3.resourceCategory, 'sound');
});

test('RequestAnalyzer: exemplo da especificacao (madeira de eucalipto) gera as subtarefas corretas', () => {
  const result = analyzer.analyze(
    'Pesquise madeira de eucalipto, encontre fotografias de sua superfície e identifique os padrões visuais para criar uma textura de Minecraft.'
  );

  const types = result.subtasks.map((t) => t.type);
  assert.ok(types.includes('research.web_search'), 'deve incluir pesquisa textual');
  assert.ok(types.includes('research.image_search'), 'deve incluir pesquisa de imagens (mencionou "fotografias")');
  assert.ok(types.includes('research.material_analysis'), 'deve incluir analise de material (mencionou "padrões")');
  assert.equal(result.resourceCategory, 'texture');
});

test('RequestAnalyzer: requisitos explicitos (vindos do AddonForge) tem prioridade sobre a deteccao por palavra-chave', () => {
  const result = analyzer.analyze('pesquisar informacoes gerais', {
    find_images: true,
    analyze_material: false,
    find_documentation: true,
  });

  const types = result.subtasks.map((t) => t.type);
  assert.ok(types.includes('research.image_search'));
  assert.ok(!types.includes('research.material_analysis'));
  assert.ok(types.includes('research.documentation_search'));
});

test('RequestAnalyzer: pedido simples sem palavras-chave gera apenas pesquisa textual', () => {
  const result = analyzer.analyze('Qual a capital da Australia?');
  assert.deepEqual(result.subtasks.map((t) => t.type), ['research.web_search']);
  assert.equal(result.intent, 'general_research');
});
