import os
from tests.base import Base, PW
from dagba import db as dbm
from dagba.util import now

class MobileLearning(Base):
    def setUp(self):
        super().setUp(); self.c = self.app.test_client()
        dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at) VALUES (?,?,?,?,?)", (self.users["alice"], "course", self.paid, "academic", now()))
        self.l1, self.l2 = [r["id"] for r in dbm.q("SELECT id FROM lessons WHERE course_id=? ORDER BY position", (self.paid,))]
        self.inc_l = dbm.q1("SELECT id FROM lessons WHERE course_id=?", (self.inc,))["id"]
        self.ta = self.login("alice"); self.tb = self.login("bob")

    def login(self, who):
        r = self.c.post("/api/v1/auth/login", json={"email": f"{who}@t.test", "password": PW}); return r.get_json()["access_token"]
    def j(self, method, url, data=None, tok=None, **kw):
        r = getattr(self.c, method)(url, json=data, headers={"Authorization": f"Bearer {tok}"} if tok else {}, **kw); return r, (r.get_json(silent=True) or {})

    def test_entitlement_gates_course_and_lessons(self):
        self.assertEqual(self.j("get", "/api/v1/learn/paid-maths", tok=self.ta)[0].status_code, 200)
        r, d = self.j("get", "/api/v1/learn/paid-maths", tok=self.tb); self.assertEqual(r.status_code, 403); self.assertFalse(d["ok"])
        self.assertEqual(self.j("get", f"/api/v1/lessons/{self.l1}", tok=self.tb)[0].status_code, 403)
        self.assertEqual(self.j("get", f"/api/v1/lessons/{self.inc_l}", tok=self.ta)[0].status_code, 403)          # an individual purchase never unlocks another course
        self.assertEqual(self.j("get", f"/api/v1/lessons/{self.l1}")[0].status_code, 401)

    def test_free_preview_lesson_open_to_non_buyers(self):
        dbm.ex("UPDATE lessons SET free_preview=1 WHERE id=?", (self.l1,))
        r, d = self.j("get", f"/api/v1/lessons/{self.l1}", tok=self.tb); self.assertEqual(r.status_code, 200); self.assertIsNone(d["lesson"]["access"])
        self.assertEqual(self.j("get", f"/api/v1/lessons/{self.l2}", tok=self.tb)[0].status_code, 403)

    def test_lesson_progress_complete_resume(self):
        r, d = self.j("get", f"/api/v1/lessons/{self.l1}", tok=self.ta); self.assertEqual(d["lesson"]["next_id"], self.l2)
        self.assertEqual(self.j("post", f"/api/v1/lessons/{self.l1}/progress", {"position": 42}, tok=self.ta)[0].status_code, 200)
        self.assertEqual(self.j("get", f"/api/v1/lessons/{self.l1}", tok=self.ta)[1]["lesson"]["position_seconds"], 42)
        r, d = self.j("post", f"/api/v1/lessons/{self.l1}/complete", tok=self.ta); self.assertEqual(d["progress"]["percent"], 50)
        r, d = self.j("get", "/api/v1/my/learning", tok=self.ta); self.assertEqual([c["slug"] for c in d["in_progress"]], ["paid-maths"])
        r, d = self.j("get", "/api/v1/home", tok=self.ta); self.assertEqual(d["continue"][0]["lesson"]["id"], self.l2)

    def test_scheduled_release_blocks_lesson(self):
        dbm.ex("UPDATE lessons SET release_at='2999-01-01 00:00:00' WHERE id=?", (self.l2,))
        r, d = self.j("get", f"/api/v1/lessons/{self.l2}", tok=self.ta); self.assertEqual(r.status_code, 403); self.assertIn("opens", d["error"]["message"])

    def test_signed_video_link_streams_and_is_bound(self):
        name = "v1.mp4"; os.makedirs(self.app.config["PRIVATE_DIR"], exist_ok=True)
        with open(os.path.join(self.app.config["PRIVATE_DIR"], name), "wb") as fh: fh.write(b"0123456789" * 100)
        dbm.ex("UPDATE lessons SET kind='video', video_file=? WHERE id=?", (name, self.l1))
        d = self.j("get", f"/api/v1/lessons/{self.l1}", tok=self.ta)[1]; url = "/api/v1" + d["lesson"]["video"]["url"].split("/api/v1", 1)[1]
        r = self.c.get(url, headers={"Range": "bytes=0-9"}); self.assertEqual(r.status_code, 206); self.assertEqual(r.data, b"0123456789")
        other = url.replace(f"/video/{self.l1}", f"/video/{self.l2}"); self.assertEqual(self.c.get(other).status_code, 403)   # signature is lesson-bound
        self.assertEqual(self.c.get(f"/api/v1/media/video/{self.l1}?t=bad").status_code, 403)
        dbm.ex("UPDATE users SET is_active=0 WHERE id=?", (self.users["alice"],)); self.assertEqual(self.c.get(url).status_code, 403)

    def test_quiz_hides_answers_grades_and_records_attempt(self):
        z = dbm.ex("INSERT INTO quizzes(course_id,title,pass_mark) VALUES (?,?,?)", (self.paid, "Q1", 50))
        q1 = dbm.ex("INSERT INTO questions(quiz_id,course_id,prompt,options,correct,explanation,position) VALUES (?,?,?,?,?,?,1)", (z, self.paid, "2+2?", "3\n4\n5", 2, "four"))
        q2 = dbm.ex("INSERT INTO questions(quiz_id,course_id,prompt,options,correct,position) VALUES (?,?,?,?,?,2)", (z, self.paid, "1+1?", "2\n3", 1))
        r, d = self.j("get", f"/api/v1/quizzes/{z}", tok=self.ta); raw = r.get_data(as_text=True)
        self.assertEqual(len(d["quiz"]["questions"]), 2); self.assertNotIn("correct", raw); self.assertNotIn("four", raw)
        r, d = self.j("post", f"/api/v1/quizzes/{z}/submit", {"answers": {str(q1): 2, str(q2): 2}}, tok=self.ta); self.assertEqual(d["percent"], 50); self.assertTrue(d["passed"])
        self.assertEqual(self.val("SELECT COUNT(*) FROM quiz_attempts WHERE user_id=?", (self.users["alice"],)), 1)
        self.assertEqual(self.j("get", f"/api/v1/quizzes/{z}", tok=self.tb)[0].status_code, 403)

    def test_assignment_submit_and_no_resubmit_after_review(self):
        a = dbm.ex("INSERT INTO assignments(course_id,title,instructions) VALUES (?,?,?)", (self.paid, "A1", "do it"))
        self.assertEqual(self.j("post", f"/api/v1/assignments/{a}/submit", {"body": ""}, tok=self.ta)[0].status_code, 400)
        self.assertEqual(self.j("post", f"/api/v1/assignments/{a}/submit", {"body": "my answer"}, tok=self.ta)[0].status_code, 200)
        self.assertEqual(self.j("get", f"/api/v1/assignments/{a}", tok=self.ta)[1]["submission"]["body"], "my answer")
        dbm.ex("UPDATE submissions SET status='reviewed' WHERE assignment_id=?", (a,))
        self.assertEqual(self.j("post", f"/api/v1/assignments/{a}/submit", {"body": "again"}, tok=self.ta)[0].status_code, 409)
        self.assertEqual(self.j("post", f"/api/v1/assignments/{a}/submit", {"body": "x"}, tok=self.tb)[0].status_code, 403)

    def test_certificate_requires_completion_then_pdf_via_signed_link(self):
        self.assertEqual(self.j("post", "/api/v1/learn/paid-maths/certificate", tok=self.ta)[0].status_code, 409)
        for l in (self.l1, self.l2): self.j("post", f"/api/v1/lessons/{l}/complete", tok=self.ta)
        r, d = self.j("post", "/api/v1/learn/paid-maths/certificate", tok=self.ta); self.assertEqual(r.status_code, 200, d)
        c = self.j("get", "/api/v1/my/certificates", tok=self.ta)[1]["certificates"][0]; self.assertTrue(c["verify_url"].endswith("/verify/" + d["cert_id"]))
        r = self.c.get("/api/v1" + c["pdf_url"].split("/api/v1", 1)[1]); self.assertEqual(r.status_code, 200); self.assertTrue(r.data.startswith(b"%PDF"))

    def test_notifications_list_and_read(self):
        from dagba.services.notify import notify
        notify(self.users["alice"], "Hello", "b", "/x", "announcement")
        r, d = self.j("get", "/api/v1/notifications", tok=self.ta); self.assertEqual(d["unread"], 1)
        self.j("post", "/api/v1/notifications/read", {}, tok=self.ta); self.assertEqual(self.j("get", "/api/v1/notifications", tok=self.ta)[1]["unread"], 0)
        self.assertEqual(self.j("get", "/api/v1/notifications", tok=self.tb)[1]["notifications"], [])             # never another user's

    def test_payments_history_only_own(self):
        dbm.ex("INSERT INTO transactions(reference,user_id,item_type,course_id,item_title,list_price_kobo,amount_kobo,status) VALUES ('R1',?,?,?,?,?,?,?)", (self.users["alice"], "course", self.paid, "Paid Maths", 500000, 500000, "pending_verification"))
        self.assertEqual(len(self.j("get", "/api/v1/my/payments", tok=self.ta)[1]["transactions"]), 1)
        self.assertEqual(len(self.j("get", "/api/v1/my/payments", tok=self.tb)[1]["transactions"]), 0)

    def test_home_public_and_admin_toggles(self):
        r, d = self.j("get", "/api/v1/home"); self.assertTrue(d["ok"]); self.assertEqual([s["key"] for s in d["sections"]][:1], ["basic"]); self.assertNotIn("continue", d)
        from dagba.services import settings as S
        S.put("home.show_income", "0"); self.assertNotIn("income", [s["key"] for s in self.j("get", "/api/v1/home")[1]["sections"]])

    def test_articles_only_published_and_discussions_need_access(self):
        dbm.ex("INSERT INTO articles(title,slug,excerpt,body,status) VALUES ('Live','live','e','b','published')"); dbm.ex("INSERT INTO articles(title,slug,body,status) VALUES ('Hidden','hidden','b','draft')")
        self.assertEqual([a["slug"] for a in self.j("get", "/api/v1/articles")[1]["articles"]], ["live"])
        self.assertEqual(self.j("get", "/api/v1/articles/hidden")[0].status_code, 404)
        self.assertEqual(self.j("post", "/api/v1/courses/paid-maths/discussions", {"body": "Question here please"}, tok=self.tb)[0].status_code, 400)
        self.assertEqual(self.j("post", "/api/v1/courses/paid-maths/discussions", {"body": "Question here please"}, tok=self.ta)[0].status_code, 200)
        self.assertEqual(len(self.j("get", "/api/v1/courses/paid-maths/discussions", tok=self.ta)[1]["threads"]), 1)

    def test_home_basic_block_follows_the_websites_featured_switch(self):
        from dagba.services import settings as S
        self.assertIn("basic", [s["key"] for s in self.j("get", "/api/v1/home")[1]["sections"]])
        S.put("home.show_featured", "0"); self.assertNotIn("basic", [s["key"] for s in self.j("get", "/api/v1/home")[1]["sections"]])
