"""Strict division separation: every course appears only in its own homepage section; a course's division never changes by accident."""
import re, sqlite3, os, shutil, tempfile
from .base import *
from .test_builder import BuilderBase, jpost
from dagba.services import academic as A

LESSON = [{"id": None, "title": "Intro", "lessons": [{"title": "Welcome", "kind": "text", "body": "Hello"}]}]

class SeparationBase(BuilderBase):
    def setUp(self):
        super().setUp()
        d = dbm.ex
        self.bs = dbm.val("SELECT id FROM categories WHERE slug='academic-mathematics'")                         # Basic subject (seeded)
        d("UPDATE categories SET price_kobo=500000, featured=1, active=1 WHERE id=?", (self.bs,))
        self.as_ = d("INSERT INTO categories(division,level,name,slug,price_kobo,featured,active) VALUES ('academic','advanced','Zoology','t-adv-zoo',300000,1,1)")
        self.ps = d("INSERT INTO categories(division,name,slug,price_kobo,featured,active) VALUES ('professional','Banking Exams','t-pro-bank',400000,1,1)")
        self.o = self.client("owner"); self.pub = self.app.test_client()
    def save(self, title, division, cat=None, level="", action="publish", featured=False, c=None, **kw):
        p = self.payload(title=title, division=division, academic_level=level, category_id=cat if cat is not None else "", action=action, featured=featured, modules=LESSON); p.update(kw)
        j = jpost(c or self.o, self, "/staff/builder/save", p).get_json(); self.assertTrue(j["ok"], j); return j["id"]
    def home(self): return self.pub.get("/").data.decode()
    def sec(self, h, sid): m = re.search(r'<section class="block[^"]*" id="%s">(.*?)</section>' % sid, h, re.S); return m.group(1) if m else ""
    def div(self, cid): return dbm.val("SELECT division FROM courses WHERE id=?", (cid,))

class HomepageSeparationTests(SeparationBase):
    def test_one_published_course_per_division_appears_only_in_its_section(self):
        b = self.save("Zed Basic Algebra", "academic", self.bs, "basic", featured=True)
        a = self.save("Zed Advanced Anatomy", "academic", self.as_, "advanced", featured=True)
        p = self.save("Zed Pro Banking Law", "professional", self.ps, featured=True)
        i = self.save("Zed Income Welding", "income", featured=False)
        self.assertEqual([self.div(x) for x in (b, a, p, i)], ["academic", "academic", "professional", "income"])
        h = self.home()
        income = self.sec(h, "income"); self.assertIn("Zed Income Welding", income)
        for t in ("Zed Basic Algebra", "Zed Advanced Anatomy", "Zed Pro Banking Law"): self.assertNotIn(t, income, t)            # featured flag never overrides division
        for sid, subject in (("basic", "Mathematics"), ("advanced", "Zoology"), ("professional", "Banking Exams")):
            s = self.sec(h, sid); self.assertEqual(s.count(f"<h3>{subject}</h3>"), 1, sid); self.assertNotIn("Zed Income Welding", s)
            for t in ("Zed Basic Algebra", "Zed Advanced Anatomy", "Zed Pro Banking Law", "Zed Income Welding"): self.assertNotIn(t, s, (sid, t))      # subject cards only, never course cards
        self.assertNotIn("Zed Basic Algebra", h.replace(income, "")); self.assertNotIn("Zed Advanced Anatomy", h.replace(income, ""))
        self.assertNotIn("Featured Course", h)
    def test_featured_flag_on_other_divisions_never_enters_income_section(self):
        for t, dv, cat, lv in (("Fx Adv", "academic", self.as_, "advanced"), ("Fx Pro", "professional", self.ps, ""), ("Fx Basic", "academic", self.bs, "basic")):
            self.save(t, dv, cat, lv, featured=True)
        self.assertNotIn("Fx ", self.sec(self.home(), "income"))                            # featured Basic/Advanced/Professional courses are not in the Income section
        dbm.ex("UPDATE courses SET featured=1")                                            # even featuring every course in the database cannot leak
        inc = self.sec(self.home(), "income"); self.assertNotIn("Fx ", inc)
        for r in dbm.q("SELECT title FROM courses WHERE division<>'income'"): self.assertNotIn(f"<h3>{r['title']}</h3>", inc)
        titles = re.findall(r'href="/courses/([a-z0-9-]+)"', inc)
        self.assertTrue(all(dbm.val("SELECT division FROM courses WHERE slug=?", (t,)) == "income" for t in titles) and titles)
    def test_only_published_income_courses(self):
        d = self.save("Draft Income", "income", action="draft"); self.assertNotIn("Draft Income", self.home())
        r = self.save("Review Income", "income", action="draft"); dbm.ex("UPDATE courses SET status='archived' WHERE id=?", (r,)); self.assertNotIn("Review Income", self.home())
        self.save("Live Income", "income"); self.assertIn("Live Income", self.sec(self.home(), "income"))
        dbm.ex("UPDATE courses SET status='published' WHERE id=?", (d,)); self.assertIn("Draft Income", self.sec(self.home(), "income"))
    def test_publishing_or_creating_other_division_never_touches_income(self):
        self.save("Live Income", "income"); before = self.sec(self.home(), "income")
        for t, dv, cat, lv in (("Other A", "academic", self.as_, "advanced"), ("Other P", "professional", None, ""), ("Other B", "academic", self.bs, "basic")):
            self.save(t, dv, cat, lv, action="draft"); self.save(t + " Live", dv, cat, lv)
        self.assertEqual(self.sec(self.home(), "income"), before)
    def test_income_section_title_is_income_skills_even_with_legacy_override(self):
        dbm.ex("INSERT OR REPLACE INTO settings(key,value) VALUES ('home.featured_title','Featured Course')")
        d = tempfile.mkdtemp(); path = os.path.join(d, "x.db"); dbm.migrate(path, MIG)      # migration 020 renames stored legacy titles on upgrade
        c = sqlite3.connect(path); c.execute("DELETE FROM schema_migrations WHERE name='020_division_separation.sql'"); c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES ('home.featured_title','Our Featured Courses')"); c.commit(); c.close()
        dbm.migrate(path, MIG); c = sqlite3.connect(path); self.assertEqual(c.execute("SELECT value FROM settings WHERE key='home.featured_title'").fetchone()[0], "Income Skills"); c.close(); shutil.rmtree(d, ignore_errors=True)
        dbm.ex("DELETE FROM settings WHERE key='home.featured_title'"); self.save("Title Income", "income"); self.assertIn("<h2>Income Skills</h2>", self.sec(self.home(), "income"))

class EditSafetyTests(SeparationBase):
    def test_editing_never_changes_division(self):
        for dv, cat, lv in (("income", None, ""), ("professional", self.ps, ""), ("academic", self.as_, "advanced"), ("academic", self.bs, "basic")):
            cid = self.save(f"Edit {dv}{lv}", dv, cat, lv)
            p = self.payload(id=cid, title=f"Edit {dv}{lv} v2", division=dv, academic_level=lv, category_id=cat if cat else "", action="publish", modules=LESSON)
            p.pop("division"); j = jpost(self.o, self, "/staff/builder/save", p).get_json(); self.assertTrue(j["ok"], j); self.assertEqual(self.div(cid), dv)         # no division sent: the stored one is kept
            p["division"] = "income" if dv != "income" else "professional"; j = jpost(self.o, self, "/staff/builder/save", p).get_json(); self.assertFalse(j["ok"]); self.assertEqual(self.div(cid), dv)      # a different division is refused
    def test_admin_can_move_a_course_only_explicitly(self):
        cid = self.save("Movable", "income"); p = self.payload(id=cid, title="Movable", division="professional", academic_level="", category_id=self.ps, action="publish", modules=LESSON)
        self.assertFalse(jpost(self.o, self, "/staff/builder/save", p).get_json()["ok"]); self.assertEqual(self.div(cid), "income")
        p["division_change"] = True; self.assertTrue(jpost(self.o, self, "/staff/builder/save", p).get_json()["ok"]); self.assertEqual(self.div(cid), "professional")
        self.assertNotIn("Movable", self.sec(self.home(), "income"))
    def test_instructor_cannot_move_a_course(self):
        i = self.client("inst"); cid = self.save("Inst Course", "income", c=i, action="draft"); self.assertEqual(self.div(cid), "income")
        p = self.payload(id=cid, title="Inst Course", division="professional", academic_level="", category_id="", action="draft", modules=LESSON, division_change=True)
        j = jpost(i, self, "/staff/builder/save", p).get_json(); self.assertFalse(j["ok"]); self.assertEqual(self.div(cid), "income")
    def test_builder_page_locks_division_for_saved_courses(self):
        cid = self.save("Lock Me", "income"); h = self.o.get(f"/staff/builder/{cid}").data.decode(); self.assertIn("The division is fixed once a course is saved", h); self.assertIn("c_divmove", h)
        self.assertNotIn("c_divmove", self.client("inst").get("/staff/builder").data.decode())
    def test_cross_division_category_is_refused(self):
        p = self.payload(title="Bad Cat", division="income", academic_level="", category_id=self.as_, action="draft", modules=LESSON); self.assertFalse(jpost(self.o, self, "/staff/builder/save", p).get_json()["ok"])
        with self.assertRaises(sqlite3.IntegrityError): dbm.ex("INSERT INTO courses(division,title,slug,status,category_id) VALUES ('income','Raw','raw','published',?)", (self.as_,))      # database guard
    def test_category_with_courses_cannot_change_division(self):
        self.save("In Zoo", "academic", self.as_, "advanced"); r = self.post(self.o, f"/staff/r/categories/{self.as_}/edit", {"division": "income", "name": "Zoology", "price_kobo": "0", "active": "1", "access_policy": "lifetime"})
        self.assertEqual(r.status_code, 200); self.assertEqual(dbm.val("SELECT division FROM categories WHERE id=?", (self.as_,)), "academic")

class RepairMigrationTests(Base):
    def test_020_repairs_only_provable_mismatches_and_logs_them(self):
        d = tempfile.mkdtemp(); old = os.path.join(d, "m"); os.makedirs(old)
        for f in sorted(os.listdir(MIG)):
            if f < "020": shutil.copy(os.path.join(MIG, f), old)
        path = os.path.join(d, "r.db"); dbm.migrate(path, old); c = sqlite3.connect(path)
        c.execute("INSERT INTO categories(id,division,level,name,slug,active) VALUES (800,'academic','advanced','Law X','lx',1)")
        c.execute("INSERT INTO categories(id,division,name,slug,active) VALUES (801,'professional','Pro X','px',1)")
        ins = "INSERT INTO courses(id,division,academic_level,category_id,title,slug,status,subscription_eligible) VALUES (?,?,?,?,?,?,?,?)"
        c.execute(ins, (700, "income", None, 800, "Wrongly income advanced", "w1", "published", 1))             # category proves it is Academic Advanced
        c.execute(ins, (701, "income", None, 801, "Wrongly income pro", "w2", "published", 1))                 # category proves it is Professional
        c.execute(ins, (702, "income", None, None, "Genuine income", "g1", "published", 1))                    # no category: nothing proves otherwise
        c.execute(ins, (703, "academic", "advanced", 800, "Correct advanced", "g2", "published", 1)); c.commit(); c.close()
        self.assertEqual(dbm.migrate(path, MIG), ["020_division_separation.sql", "021_tutor_mou.sql", "022_prelaunch.sql", "023_learning_objectives.sql", "024_interactive_learning.sql", "025_mobile_api.sql", "026_store_billing.sql"]); c = sqlite3.connect(path)
        rows = {r[0]: r[1:] for r in c.execute("SELECT id,division,academic_level,subscription_eligible,status FROM courses WHERE id>=700")}
        self.assertEqual(rows[700], ("academic", "advanced", 1, "published")); self.assertEqual(rows[701], ("professional", None, 0, "published"))
        self.assertEqual(rows[702], ("income", None, 1, "published")); self.assertEqual(rows[703], ("academic", "advanced", 1, "published"))
        self.assertEqual(sorted(r[0] for r in c.execute("SELECT course_id FROM division_repairs")), [700, 701]); self.assertEqual(c.execute("SELECT old_division FROM division_repairs WHERE course_id=700").fetchone()[0], "income")
        self.assertEqual(c.execute("PRAGMA foreign_key_check").fetchall(), []); self.assertEqual(dbm.migrate(path, MIG), []); c.close(); shutil.rmtree(d, ignore_errors=True)
