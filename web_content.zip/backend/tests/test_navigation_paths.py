import re
from .base import *
from dagba import db as dbm

def hrefs(html):
    """Sidebar links only (inside the dashboard <aside>)."""
    side = html.split('<aside class="side">', 1)[1].split("</aside>", 1)[0]
    return re.findall(r'<a class="nk[^"]*" href="([^"]+)"', side)

def sidebar(html): return html.split('<aside class="side">', 1)[1].split("</aside>", 1)[0]

class PathBase(Base):
    def setUp(self):
        super().setUp(); ex = dbm.ex
        self.inst2 = self.mk("inst2", "instructor")
        self.cats, self.courses = {}, {}
        for lv in ("basic", "advanced"):
            self.cats[lv] = ex("INSERT INTO categories(division,level,name,slug) VALUES ('academic',?,?,?)", (lv, f"{lv.title()} Subject", f"sub-{lv}"))
        self.cats["professional"] = ex("INSERT INTO categories(division,name,slug) VALUES ('professional','Professional Subject','sub-professional')")      # its own division now
        self.cats["income"] = ex("INSERT INTO categories(division,name,slug) VALUES ('income','Income Cat','sub-income')")
        for lv in ("basic", "advanced"):
            self.courses[lv] = ex("INSERT INTO courses(division,academic_level,category_id,title,slug,status,instructor_id) VALUES ('academic',?,?,?,?, 'published',?)", (lv, self.cats[lv], f"{lv.title()} Course", f"c-{lv}", self.users["inst"]))
        self.courses["professional"] = ex("INSERT INTO courses(division,category_id,title,slug,status,instructor_id) VALUES ('professional',?,?,?, 'published',?)", (self.cats["professional"], "Professional Course", "c-professional", self.users["inst"]))
        self.courses["income"] = ex("INSERT INTO courses(division,category_id,title,slug,status,instructor_id) VALUES ('income',?,?,?, 'published',?)", (self.cats["income"], "Income Course", "c-income", self.users["inst"]))
        self.courses["legacy"] = ex("INSERT INTO courses(division,title,slug,status,instructor_id) VALUES ('academic','Legacy Course','c-legacy','published',?)", (self.users["inst2"],))   # no level => Basic
        self.lesson, self.quiz, self.assign, self.module = {}, {}, {}, {}
        for k in ("basic", "advanced", "professional", "income"):
            c = self.courses[k]
            self.module[k] = ex("INSERT INTO modules(course_id,title,position) VALUES (?,?,1)", (c, f"{k} topic"))
            self.lesson[k] = ex("INSERT INTO lessons(course_id,module_id,title,kind,body,position,resource_file,resource_name) VALUES (?,?,?,?,?,1,?,?)", (c, self.module[k], f"{k} lesson", "text", "b", f"{k}.pdf", f"{k}-notes.pdf"))
            self.quiz[k] = ex("INSERT INTO quizzes(course_id,title) VALUES (?,?)", (c, f"{k} quiz"))
            self.assign[k] = ex("INSERT INTO assignments(course_id,title) VALUES (?,?)", (c, f"{k} assignment"))

    def page(self, who, url):
        c = self.client(who); return c.get(url)

ALL = ("basic", "advanced", "professional", "income")

class SidebarStructureTests(PathBase):
    def test_owner_sees_grouped_parent_menus(self):
        h = self.page("owner", "/staff/").data.decode(); s = sidebar(h)
        for g in ("Faith", "Academics", "Income Skills", "Professional Development", "Payments", "Affiliates", "Users", "Appearance", "Blog / Content", "Notifications"):
            self.assertRegex(s, r'<summary>.*?<span class="nl">%s</span>' % re.escape(g), g)
        self.assertIn("Analytics &amp; reports", s)
        for lv in ("Basic", "Advanced"): self.assertIn(f'<span class="nl">{lv}</span>', s)
        self.assertNotIn('<span class="nl">Professional</span>', s)                       # Professional Development is a main group of its own, not an Academic sub-group

    def test_every_sidebar_link_opens_for_every_role(self):
        for who in ("owner", "officer", "noperm", "inst", "writer", "alice"):
            c = self.client(who); h = c.get("/student" if who == "alice" else "/staff/").data.decode()
            links = hrefs(h); self.assertGreaterEqual(len(links), 3, who)
            for href in links:
                r = c.get(href); self.assertEqual(r.status_code, 200, f"{who}: {href} -> {r.status_code}")

    def test_owner_every_submenu_in_every_path(self):
        c = self.client("owner")
        for lv in ALL:
            for ep in ("", "/enrolments", "/resources"): self.assertEqual(c.get(f"/staff/path/{lv}{ep}").status_code, 200)
            for rn in ("categories", "courses", "modules", "lessons", "assignments", "quizzes", "announcements"):
                self.assertEqual(c.get(f"/staff/r/{rn}?ctx={lv}").status_code, 200, (lv, rn))

    def test_active_group_and_link_are_highlighted(self):
        s = sidebar(self.page("owner", "/staff/r/courses?ctx=advanced").data.decode())
        self.assertRegex(s, r'<details class="ng d0 on" open><summary><svg[^>]*>.*?</svg><span class="nl">Academics</span>')
        self.assertRegex(s, r'<details class="ng d1 on" open><summary><span class="nl">Advanced</span>')
        self.assertEqual(len(re.findall(r'aria-current="page"', s)), 1)
        self.assertRegex(s, r'class="nk d2 on" href="/staff/r/courses\?ctx=advanced" aria-current="page"')
        self.assertNotRegex(s, r'class="nk d2 on" href="/staff/r/courses\?ctx=basic"')

    def test_filtered_submenus_highlight_only_themselves(self):
        s = sidebar(self.page("owner", "/staff/users?role=student").data.decode())
        self.assertRegex(s, r'class="nk d1 on" href="/staff/users\?role=student"'); self.assertNotRegex(s, r'class="nk d1 on" href="/staff/users"')
        s = sidebar(self.page("owner", "/staff/users").data.decode()); self.assertRegex(s, r'class="nk d1 on" href="/staff/users"')

    def test_course_builder_highlights_its_own_path(self):
        s = sidebar(self.page("owner", f"/staff/builder/{self.courses['professional']}").data.decode())
        self.assertRegex(s, r'class="nk d1 on" href="/staff/r/courses\?ctx=professional"')           # a main group like Income Skills

class RoleVisibilityTests(PathBase):
    def labels(self, who, url="/staff/"):
        s = sidebar(self.page(who, url).data.decode()); return re.findall(r'<span class="nl">([^<]+)</span>', s)
    def test_instructor_menu_has_no_admin_functions(self):
        l = self.labels("inst")
        for bad in ("Users", "Payments", "Appearance", "Affiliates", "Certificates", "Analytics & reports", "Backup & export"): self.assertNotIn(bad, l)
        for ok in ("Dashboard", "Faith", "Academics", "Income Skills", "My earnings", "Assignments to mark"): self.assertIn(ok, l)
    def test_writer_menu_is_content_only(self):
        l = self.labels("writer")
        self.assertIn("My articles", l); self.assertNotIn("Academics", l); self.assertNotIn("Payments", l); self.assertNotIn("Writers' submissions", l)
    def test_payment_officer_sees_payments_only(self):
        l = self.labels("officer")
        self.assertIn("Payments", l); self.assertIn("Transactions", l); self.assertNotIn("Users", l); self.assertNotIn("Academics", l); self.assertNotIn("Appearance", l)
    def test_admin_without_permissions_sees_almost_nothing(self):
        l = self.labels("noperm"); self.assertNotIn("Payments", l); self.assertNotIn("Academics", l); self.assertNotIn("Users", l)
    def test_student_menu_is_learning_only(self):
        s = sidebar(self.page("alice", "/student").data.decode())
        for t in ("My learning", "Faith &amp; Growth", "Payments", "Certificates"): self.assertIn(t, s)
        for bad in ("/staff", "Users", "Appearance"): self.assertNotIn(bad, s)
    def test_path_pages_are_closed_to_unauthorised_roles(self):
        for who, code in (("writer", 403), ("alice", 403), ("noperm", 403), ("officer", 403)):
            for u in ("/staff/path/basic", "/staff/path/basic/enrolments", "/staff/path/basic/resources"): self.assertEqual(self.page(who, u).status_code, code, (who, u))
        self.assertEqual(self.app.test_client().get("/staff/path/basic").status_code, 302)
        self.assertEqual(self.page("owner", "/staff/path/faith").status_code, 404); self.assertEqual(self.page("owner", "/staff/path/nope").status_code, 404)

class StrictSeparationTests(PathBase):
    NAMES = dict(courses="{} Course", modules="{} topic", lessons="{} lesson", quizzes="{} quiz", assignments="{} assignment")
    def test_every_resource_lists_only_its_own_path(self):
        c = self.client("owner")
        for lv in ALL:
            for rn, tpl in self.NAMES.items():
                h = c.get(f"/staff/r/{rn}?ctx={lv}").data.decode()
                self.assertIn(tpl.format(lv.title() if rn == "courses" else lv), h, (lv, rn))
                for other in ALL:
                    if other != lv: self.assertNotIn(tpl.format(other.title() if rn == "courses" else other), h, (lv, other, rn))
    def test_categories_are_separated(self):
        c = self.client("owner"); self.assertIn("Basic Subject", c.get("/staff/r/categories?ctx=basic").data.decode())
        for lv in ALL:
            h = c.get(f"/staff/r/categories?ctx={lv}").data.decode()
            for o in ("Basic Subject", "Advanced Subject", "Professional Subject", "Income Cat"):
                if lv not in o.lower(): self.assertNotIn(o, h, (lv, o))
    def test_legacy_course_without_level_counts_as_basic_only(self):
        c = self.client("owner")
        self.assertIn("Legacy Course", c.get("/staff/r/courses?ctx=basic").data.decode())
        for lv in ("advanced", "professional", "income"): self.assertNotIn("Legacy Course", c.get(f"/staff/r/courses?ctx={lv}").data.decode())
    def test_cannot_open_edit_or_delete_another_paths_record(self):
        c = self.client("owner")
        for rn, ids in (("categories", self.cats), ("lessons", self.lesson), ("quizzes", self.quiz), ("assignments", self.assign), ("modules", self.module)):
            self.assertEqual(c.get(f"/staff/r/{rn}/{ids['advanced']}/edit?ctx=advanced").status_code, 200, rn)
            self.assertEqual(c.get(f"/staff/r/{rn}/{ids['advanced']}/edit?ctx=basic").status_code, 404, rn)
            r = self.post(c, f"/staff/r/{rn}/{ids['advanced']}/delete?ctx=basic"); self.assertEqual(r.status_code, 404, rn)
        self.assertTrue(self.val("SELECT 1 FROM lessons WHERE id=?", (self.lesson["advanced"],)))
    def test_faith_and_academic_contexts_never_mix(self):
        c = self.client("owner")
        for rn in ("faith-topics", "faith-series"):
            self.assertEqual(c.get(f"/staff/r/{rn}?ctx=basic").status_code, 404); self.assertEqual(c.get(f"/staff/r/{rn}?ctx=income").status_code, 404); self.assertEqual(c.get(f"/staff/r/{rn}?ctx=faith").status_code, 200)
        for rn in ("courses", "lessons", "categories", "quizzes"): self.assertEqual(c.get(f"/staff/r/{rn}?ctx=faith").status_code, 404, rn)
    def test_new_category_inside_a_path_is_forced_into_that_path(self):
        c = self.client("owner")
        r = self.post(c, "/staff/r/categories/new?ctx=advanced", {"name": "Forged", "division": "income", "level": "basic", "active": "1"}); self.assertEqual(r.status_code, 302, r.data[:200])
        row = self.row("SELECT * FROM categories WHERE name='Forged'"); self.assertEqual((row["division"], row["level"]), ("academic", "advanced"))
        self.assertIn("ctx=advanced", r.headers["Location"])
        self.assertNotIn("Forged", c.get("/staff/r/categories?ctx=basic").data.decode()); self.assertIn("Forged", c.get("/staff/r/categories?ctx=advanced").data.decode())
    def test_form_in_a_path_hides_division_and_level_choices(self):
        h = self.client("owner").get("/staff/r/categories/new?ctx=basic").data.decode()
        self.assertNotIn('name="division"', h); self.assertNotIn('name="level"', h); self.assertIn("Basic - Categories", h)
    def test_cannot_attach_content_to_another_paths_course(self):
        c = self.client("owner")
        r = self.post(c, "/staff/r/lessons/new?ctx=basic", {"course_id": self.courses["advanced"], "title": "Sneaky", "kind": "text", "body": "x", "position": "1"})
        self.assertEqual(r.status_code, 200); self.assertIsNone(self.row("SELECT 1 FROM lessons WHERE title='Sneaky'"))
        r = self.post(c, "/staff/r/lessons/new?ctx=advanced", {"course_id": self.courses["advanced"], "title": "Proper", "kind": "text", "body": "x", "position": "1"})
        self.assertEqual(r.status_code, 302); self.assertTrue(self.row("SELECT 1 FROM lessons WHERE title='Proper'"))
    def test_course_choices_in_a_form_are_limited_to_the_path(self):
        h = self.client("owner").get("/staff/r/lessons/new?ctx=professional").data.decode()
        self.assertIn("Professional Course", h); self.assertNotIn("Basic Course", h); self.assertNotIn("Income Course", h)
    def test_questions_follow_their_quizs_path(self):
        ex = dbm.ex; qb = ex("INSERT INTO questions(quiz_id,course_id,prompt,options,correct) VALUES (?,?,?,?,1)", (self.quiz["basic"], self.courses["basic"], "BasicQ?", "a\nb"))
        qa = ex("INSERT INTO questions(quiz_id,course_id,prompt,options,correct) VALUES (?,?,?,?,1)", (self.quiz["advanced"], self.courses["advanced"], "AdvQ?", "a\nb"))
        c = self.client("owner"); h = c.get("/staff/r/questions?ctx=basic").data.decode()
        self.assertIn("BasicQ?", h); self.assertNotIn("AdvQ?", h); self.assertEqual(c.get(f"/staff/r/questions/{qa}/edit?ctx=basic").status_code, 404)
    def test_instructor_sees_only_own_courses_inside_a_path(self):
        c = self.client("inst2"); h = c.get("/staff/r/courses?ctx=basic").data.decode()
        self.assertIn("Legacy Course", h); self.assertNotIn("Basic Course", h)
        c = self.client("inst"); h = c.get("/staff/r/courses?ctx=basic").data.decode(); self.assertIn("Basic Course", h); self.assertNotIn("Legacy Course", h)
        self.assertEqual(c.get(f"/staff/r/lessons/{self.lesson['advanced']}/edit?ctx=basic").status_code, 404)
        self.assertEqual(c.get("/staff/r/categories?ctx=basic").status_code, 403)

class PathPagesTests(PathBase):
    def test_overview_counts_only_its_path(self):
        for lv in ALL:
            h = self.page("owner", f"/staff/path/{lv}").data.decode().split("<section>", 1)[1]
            self.assertIn(f"{lv.title()} Course", h)
            for o in ALL:
                if o != lv: self.assertNotIn(f"{o.title()} Course", h, (lv, o))
        self.assertEqual(self.page("owner", "/staff/path/advanced").data.decode().split("<section>", 1)[1].count("published</span>"), 1)
    def test_enrolments_show_only_that_paths_students(self):
        ex = dbm.ex
        ex("INSERT INTO entitlements(user_id,kind,course_id,starts_at) VALUES (?,?,?,datetime('now'))", (self.users["alice"], "course", self.courses["advanced"]))
        ex("INSERT INTO entitlements(user_id,kind,course_id,starts_at) VALUES (?,?,?,datetime('now'))", (self.users["bob"], "course", self.courses["income"]))
        c = self.client("owner")
        a = c.get("/staff/path/advanced/enrolments").data.decode(); i = c.get("/staff/path/income/enrolments").data.decode(); b = c.get("/staff/path/basic/enrolments").data.decode()
        self.assertIn("Alice", a); self.assertNotIn("Bob", a); self.assertIn("Bob", i); self.assertNotIn("Alice", i); self.assertNotIn("Alice", b); self.assertNotIn("Bob", b)
    def test_resources_are_per_path(self):
        c = self.client("owner"); h = c.get("/staff/path/advanced/resources").data.decode()
        self.assertIn("advanced-notes.pdf", h); self.assertNotIn("basic-notes.pdf", h); self.assertNotIn("income-notes.pdf", h)
    def test_instructor_enrolments_limited_to_own_courses(self):
        ex = dbm.ex; ex("INSERT INTO entitlements(user_id,kind,course_id,starts_at) VALUES (?,?,?,datetime('now'))", (self.users["alice"], "course", self.courses["legacy"]))
        self.assertNotIn("Alice", self.page("inst", "/staff/path/basic/enrolments").data.decode()); self.assertIn("Alice", self.page("inst2", "/staff/path/basic/enrolments").data.decode())
    def test_new_course_in_a_path_preselects_it(self):
        h = self.page("owner", "/staff/builder?ctx=advanced").data.decode(); self.assertIn('"academic_level": "advanced"', h.replace("&#34;", '"'))

class FilteredViewsTests(PathBase):
    def test_payment_views_filter_in_the_backend(self):
        c = self.client("alice"); ref = self.buy(c, "course", "paid-maths"); self.buy(self.client("bob"), "plan", self.plan_a, "bob")
        o = self.client("owner")
        co = o.get("/staff/payments?type=course").data.decode(); pl = o.get("/staff/payments?type=plan").data.decode()
        self.assertIn(ref, co); self.assertNotIn(ref, pl)
    def test_blog_views_filter_by_status(self):
        ex = dbm.ex
        ex("INSERT INTO articles(title,slug,body,status,author_id) VALUES ('Pend A','pend-a','b','pending',?)", (self.users["writer"],)); ex("INSERT INTO articles(title,slug,body,status,author_id) VALUES ('Draft A','draft-a','b','draft',?)", (self.users["writer"],))
        o = self.client("owner"); h = o.get("/staff/r/articles?status=pending").data.decode(); self.assertIn("Pend A", h); self.assertNotIn("Draft A", h)
        self.assertIn("Draft A", o.get("/staff/r/articles?status=draft").data.decode())
        w = self.client("writer"); self.assertIn("Draft A", w.get("/staff/r/articles?status=draft").data.decode())
    def test_student_courses_filter_by_path(self):
        dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,starts_at) VALUES (?,?,?,datetime('now'))", (self.users["alice"], "course", self.courses["advanced"]))
        dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,starts_at) VALUES (?,?,?,datetime('now'))", (self.users["alice"], "course", self.courses["income"]))
        c = self.client("alice"); a = c.get("/student/courses?path=advanced").data.decode()
        self.assertIn("Advanced Course", a); self.assertNotIn("Income Course", a); self.assertIn("Income Course", c.get("/student/courses?path=income").data.decode()); self.assertIn("Advanced Course", c.get("/student/courses").data.decode())
