import { extractOtpAndLinks } from '../src/lib/otp.js';
import { encryptText, decryptText } from '../src/lib/crypto.js';
import { sanitizeEmailHtml } from '../src/lib/sanitize.js';

describe('TempBox Core Engine Test Suite', () => {
  describe('OTP & Code Auto-Detection', () => {
    it('extracts standard 6-digit verification codes', () => {
      const text = 'Your verification code is 492019. Valid for 10 minutes.';
      const res = extractOtpAndLinks(text);
      expect(res.code).toBe('492019');
      expect(res.confidence).toBe('high');
    });

    it('extracts 4-digit PINs with prefix', () => {
      const text = 'Use code: 8291 to verify your account.';
      const res = extractOtpAndLinks(text);
      expect(res.code).toBe('8291');
    });

    it('extracts Google-style alphanumeric codes', () => {
      const text = 'G-749201 is your Google verification code.';
      const res = extractOtpAndLinks(text);
      expect(res.code).toBe('G-749201');
    });

    it('extracts verification URLs', () => {
      const text = 'Please click here to confirm: https://auth.example.com/confirm?token=abc123xyz';
      const res = extractOtpAndLinks(text);
      expect(res.verificationUrl).toContain('https://auth.example.com/confirm?token=abc123xyz');
    });
  });

  describe('At-Rest Encryption (AES-256-GCM)', () => {
    it('encrypts and decrypts email and SMS content correctly', () => {
      const sensitive = 'Private verification message with personal data 12345';
      const encrypted = encryptText(sensitive);

      expect(encrypted.cipherText).not.toBe(sensitive);
      expect(encrypted.iv).toBeDefined();
      expect(encrypted.authTag).toBeDefined();

      const decrypted = decryptText(encrypted);
      expect(decrypted).toBe(sensitive);
    });
  });

  describe('HTML Sanitization & Anti-Tracking', () => {
    it('strips dangerous scripts and malicious event handlers', () => {
      const dirty = '<p>Hello</p><script>alert("hacked")</script><img src="x" onerror="stealCookie()" />';
      const result = sanitizeEmailHtml(dirty, false);

      expect(result.cleanHtml).not.toContain('<script>');
      expect(result.cleanHtml).not.toContain('onerror');
      expect(result.cleanHtml).toContain('<p>Hello</p>');
    });

    it('detects and neutralizes 1x1 tracking pixels', () => {
      const emailWithTracker = '<p>Welcome</p><img src="https://tracker.spy/pixel.gif" width="1" height="1" />';
      const result = sanitizeEmailHtml(emailWithTracker, false);

      expect(result.hasTrackers).toBe(true);
      expect(result.cleanHtml).toContain('<!-- tracker removed -->');
    });

    it('blocks remote images when allowRemoteImages is false', () => {
      const email = '<img src="https://images.unsplash.com/photo.jpg" alt="Hero" />';
      const result = sanitizeEmailHtml(email, false);

      expect(result.cleanHtml).toContain('data-blocked-src="https://images.unsplash.com/photo.jpg"');
    });
  });
});
