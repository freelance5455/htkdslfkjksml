"""Crawl every route as every kind of visitor, with normal and hostile/empty input: nothing may answer with a 5xx."""
import re
from .base import *
from tests.test_builder import mp4, jpost

SKIP = ("static", "public.media")

class NoServerErrors(Base):
    def setUp(self):
        super().setUp()
        o = self.client("owner")
        _, f = self._video(o)
        j = jpost(o, self, "/staff/builder/save", {"action": "publish", "title": "Crawl Course", "division": "academic", "academic_level": "basic", "category_id": self.val("SELECT id FROM categories WHERE slug='academic-mathematics'"), "price": "100", "instructor_id": self.users["inst"],
            "modules": [{"title": "M", "lessons": [{"title": "V", "kind": "video", "video_file": f.get_json()["file"], "video_name": "v.mp4", "free_preview": True}, {"title": "T", "kind": "text", "body": "x"}]}],
            "quiz": {"title": "Q", "pass_mark": 50, "questions": [{"prompt": "a?", "options": "x\ny", "correct": 1}]}}).get_json(); self.cid = j["id"]
        self.slug = self.val("SELECT slug FROM courses WHERE id=?", (self.cid,)); self.lid = self.val("SELECT id FROM lessons WHERE course_id=?", (self.cid,))
        self.zid = self.val("SELECT id FROM quizzes WHERE course_id=?", (self.cid,))
        self.aid = dbm.ex("INSERT INTO assignments(course_id,title,instructions) VALUES (?,?,?)", (self.cid, "A", "do"))
        dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at) VALUES (?,?,?,?,?)", (self.users["alice"], "course", self.cid, "academic", "2026-01-01 00:00:00"))
        self.ref = self.buy(self.client("bob"), "course", "marketing", who="bob"); self.tid = self.tx(self.ref)["id"]
        self.ev = self.val("SELECT id FROM payment_evidence LIMIT 1")
        dbm.ex("INSERT INTO certificates(cert_id,user_id,course_id,student_name,course_title) VALUES ('DDA-2026-AAAAAAAA',?,?,'Alice','Crawl Course')", (self.users["alice"], self.cid))
        dbm.ex("INSERT INTO articles(title,slug,body,status) VALUES ('Art','art','b','published')"); dbm.ex("INSERT INTO nuggets(title,slug,body,status) VALUES ('Nug','nug','b','published')")
        dbm.ex("INSERT INTO testimonials(name,quote,status,verified) VALUES ('T','q','published',1)")
    def _video(self, c):
        from tests.test_builder import BuilderBase
        return BuilderBase.upload_video(self, c)
    def url(self, rule):
        args = {}
        for a, conv in rule._converters.items():
            n = a
            args[a] = (self.lid if a == "lid" else self.cid if a in ("cid", "rid") else self.zid if a in ("qid",) else self.aid if a == "aid" else self.tid if a in ("tid",) else self.ev if a == "eid" else 1) if conv.__class__.__name__ == "IntegerConverter" else \
                      {"slug": self.slug, "ref": self.ref, "rname": "courses", "group": "bank", "cert_id": "DDA-2026-AAAAAAAA", "provider": "paystack", "token": "x", "uid": "x", "name": "x.webp", "filename": "css/app.css"}.get(a, "x")
        return rule.build(args)[1] if False else __import__("flask").url_for(rule.endpoint, **args)
    def test_every_get_route_never_500s_for_every_role(self):
        bad = []; n = 0
        for who in (None, "alice", "bob", "inst", "writer", "officer", "noperm", "owner"):
            c = self.client(who) if who else self.app.test_client()
            for rule in self.app.url_map.iter_rules():
                if "GET" not in rule.methods or rule.endpoint in SKIP or rule.endpoint.endswith("export.csv") and False: continue
                with self.app.test_request_context("/"): url = self.url(rule)
                if rule.endpoint in ("auth.logout",): continue
                r = c.get(url); n += 1
                if r.status_code >= 500: bad.append((who, url, r.status_code))
        self.assertEqual(bad, [], f"{len(bad)} server errors out of {n} requests")
    def test_every_post_route_survives_empty_and_garbage_forms(self):
        bad = []; n = 0
        for who in (None, "alice", "inst", "owner"):
            c = self.client(who) if who else self.app.test_client()
            for rule in self.app.url_map.iter_rules():
                if "POST" not in rule.methods or rule.endpoint in SKIP or rule.endpoint in ("auth.logout", "staff.system", "pay.webhook"): continue
                with self.app.test_request_context("/"): url = self.url(rule)
                for form in ({}, {"_csrf": self.tok(c), "x": "\x00", "action": "approve", "status": "zzz", "id": "abc", "position": "99999999999999999999", "title": "A" * 5000, "price_kobo": "-5", "role": "root"}):
                    d = dict(form); d.setdefault("_csrf", self.tok(c))
                    r = c.post(url, data=d); n += 1
                    if r.status_code >= 500: bad.append((who, url, r.status_code))
                    r = c.post(url, data="{not json", content_type="application/json", headers={"X-CSRF-Token": self.tok(c)}); n += 1
                    if r.status_code >= 500: bad.append((who, url, "json", r.status_code))
        self.assertEqual(bad, [], f"{len(bad)} server errors out of {n} requests")

class FriendlyErrorTests(Base):
    def test_500_page_has_reference_and_owner_can_see_cause(self):
        import dagba.blueprints.public as pub
        self.app.config["PROPAGATE_EXCEPTIONS"] = False; self.app.testing = False
        real = pub.q; pub.q = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("kaboom detail"))
        try:
            guest = self.app.test_client().get("/faq"); owner = self.client("owner").get("/faq")
        finally: pub.q = real
        self.assertEqual(guest.status_code, 500); g = guest.data.decode(); self.assertIn("Something went wrong on our side", g); self.assertRegex(g, r"Reference: <strong>[0-9A-F]{8}</strong>"); self.assertNotIn("kaboom", g)   # visitors never see internals
        self.assertIn("kaboom detail", owner.data.decode())                                                                                                      # the owner does
        ref = re.search(r"Reference: <strong>([0-9A-F]{8})</strong>", g).group(1); self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='error.500' AND entity_id=?", (ref,)), 1)
        self.assertIn(ref, self.client("owner").get("/staff/audit?q=error.500").data.decode())
    def test_old_database_is_upgraded_automatically_on_start(self):
        import sqlite3, tempfile, shutil, os
        from dagba import create_app
        d = tempfile.mkdtemp(); path = os.path.join(d, "old.db"); c = sqlite3.connect(path)
        c.executescript(open(os.path.join(MIG, "001_init.sql")).read()); c.execute("CREATE TABLE schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT DEFAULT (datetime('now')))"); c.execute("INSERT INTO schema_migrations(name) VALUES ('001_init.sql')"); c.commit(); c.close()
        app = create_app({"DATABASE": path, "PRIVATE_DIR": d + "/p", "PUBLIC_DIR": d + "/u", "SECRET_KEY": "x", "RATE_LIMITS_ENABLED": False})
        cols = [r[1] for r in sqlite3.connect(path).execute("pragma table_info(lessons)")]; self.assertIn("video_file", cols)
        self.assertEqual(app.test_client().get("/courses").status_code, 200); shutil.rmtree(d, ignore_errors=True)
