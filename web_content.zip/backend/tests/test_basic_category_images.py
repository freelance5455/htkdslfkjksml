import io
from .base import *
from .test_pricing import PricingBase
from .test_builder import jpost

class CategoryImageTests(PricingBase):
    def setUp(self):
        super().setUp()
        dbm.ex("UPDATE categories SET name='English JSS1', featured=1 WHERE id=?", (self.phys,))
        self.a = self.make("Grammar Basics", "basic", "academic-physics")
        self.o = self.client("owner")
    def form(self, cid, image=None, **extra):
        d = {"_csrf": self.tok(self.o), "division": "academic", "level": "basic", "name": "English JSS1", "price_kobo": "8000", "featured": "1", "active": "1", "access_policy": "lifetime"}
        d.update(extra)
        if image: d["image"] = (io.BytesIO(image), "cat.png")
        return self.o.post(f"/staff/r/categories/{cid}/edit", data=d, content_type="multipart/form-data")
    def img(self, cid=None): return self.val("SELECT image FROM categories WHERE id=?", (cid or self.phys,))
    def page(self, path): return self.app.test_client().get(path).data.decode()

    def test_upload_change_and_remove(self):
        self.assertEqual(self.form(self.phys, png_bytes()).status_code, 302); first = self.img(); self.assertTrue(first)
        self.assertEqual(self.app.test_client().get(f"/media/{first}").status_code, 200)
        self.assertIn(f"/media/{first}", self.o.get(f"/staff/r/categories/{self.phys}/edit").data.decode())
        self.form(self.phys, png_bytes()); second = self.img(); self.assertTrue(second); self.assertNotEqual(first, second)
        self.assertEqual(self.app.test_client().get(f"/media/{first}").status_code, 404)          # replaced file is tidied away
        self.form(self.phys, remove_image="1"); self.assertIsNone(self.img())
    def test_saving_without_file_keeps_image(self):
        self.form(self.phys, png_bytes()); keep = self.img(); self.form(self.phys, name="English JSS1"); self.assertEqual(self.img(), keep)
    def test_image_shows_on_homepage_and_basic_listing(self):
        self.form(self.phys, png_bytes()); img = self.img()
        for path in ("/", "/academic/basic", "/courses?level=basic", "/courses"):
            h = self.page(path); self.assertIn(f"/media/{img}", h, path); self.assertIn("English JSS1", h)
            self.assertIn('class="catimg"', h)
    def test_category_without_image_still_displays(self):
        h = self.page("/"); self.assertIn("English JSS1", h); self.assertNotIn("catimg", h)
    def test_bad_file_rejected(self):
        self.form(self.phys, b"not an image"); self.assertIsNone(self.img())
    def test_advanced_category_can_take_an_image(self):
        adv = self.val("SELECT id FROM categories WHERE slug='advanced-law'")
        self.form(adv, png_bytes(), level="basic", name="Law", price_kobo="", featured=""); self.form(adv, png_bytes(), level="advanced", name="Law", price_kobo="", featured="")
        self.assertIsNotNone(self.img(adv))      # cover images are supported for Advanced subjects too
    def test_basic_courses_take_no_image_but_others_do(self):
        j = jpost(self.o, self, "/staff/builder/save", self.payload(title="Grammar Basics", id=self.a, thumbnail="0123456789abcdef01234567.png", category_id=self.phys, action="publish")).get_json()
        self.assertTrue(j["ok"], j); self.assertIsNone(self.val("SELECT thumbnail FROM courses WHERE id=?", (self.a,)))
        self.assertIn('id="thumbrow"', self.o.get("/staff/builder").data.decode()); self.assertIn("thumbrow", self.app.test_client().get("/static/js/builder.js").data.decode())
    def test_existing_basic_course_image_is_preserved(self):
        dbm.ex("UPDATE courses SET thumbnail='aaaaaaaaaaaaaaaaaaaaaaaa.png' WHERE id=?", (self.a,))
        jpost(self.o, self, "/staff/builder/save", self.payload(title="Grammar Basics 2", id=self.a, thumbnail="", category_id=self.phys, action="publish"))
        self.assertEqual(self.val("SELECT thumbnail FROM courses WHERE id=?", (self.a,)), "aaaaaaaaaaaaaaaaaaaaaaaa.png")
