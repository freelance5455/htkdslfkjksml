from .base import *
from dagba.blueprints.auth import make_reset_link, safe_next, check_password_strength

class AuthTests(Base):
    def test_register_login_logout(self):
        c = self.client()
        r = self.post(c, "/register", {"full_name": "New Kid", "email": "kid@t.test", "password": PW, "password2": PW, "class_level": "SS1"})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(self.row("SELECT 1 FROM users WHERE email='kid@t.test'"))
        self.assertNotIn(PW, self.row("SELECT password_hash FROM users WHERE email='kid@t.test'")[0])
        self.assertEqual(c.get("/student").status_code, 200)
        self.post(c, "/logout"); self.assertEqual(c.get("/student").status_code, 302)

    def test_weak_and_duplicate_registration(self):
        c = self.client()
        r = self.post(c, "/register", {"full_name": "X", "email": "x@t.test", "password": "short", "password2": "short"}); self.assertEqual(r.status_code, 200)
        self.assertFalse(self.row("SELECT 1 FROM users WHERE email='x@t.test'"))
        r = self.post(c, "/register", {"full_name": "X", "email": "alice@t.test", "password": PW, "password2": PW}); self.assertEqual(r.status_code, 200)

    def test_wrong_password_and_inactive(self):
        c = self.client(); r = self.post(c, "/login", {"email": "alice@t.test", "password": "nope12345"}); self.assertEqual(r.status_code, 200)
        dbm.ex("UPDATE users SET is_active=0 WHERE email='alice@t.test'")
        r = self.post(c, "/login", {"email": "alice@t.test", "password": PW}); self.assertEqual(r.status_code, 200)

    def test_open_redirect_blocked(self):
        self.assertIsNone(safe_next("//evil.com")); self.assertIsNone(safe_next("https://evil.com")); self.assertEqual(safe_next("/student"), "/student")

    def test_password_recovery(self):
        link = make_reset_link(self.users["alice"]); token = link.rsplit("/", 1)[-1]
        c = self.client(); self.assertEqual(c.get(f"/reset-password/{token}").status_code, 200)
        r = self.post(c, f"/reset-password/{token}", {"password": "BrandNew123", "password2": "BrandNew123"}); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.post(self.client(), "/login", {"email": "alice@t.test", "password": "BrandNew123"}).status_code, 302)
        r = c.get(f"/reset-password/{token}"); self.assertEqual(r.status_code, 302)  # single use
        self.assertEqual(self.post(self.client(), "/reset-password/garbage", {}).status_code, 302)

    def test_forgot_does_not_reveal_accounts(self):
        c = self.client(); a = self.post(c, "/forgot-password", {"email": "alice@t.test"}); b = self.post(c, "/forgot-password", {"email": "nobody@t.test"})
        self.assertEqual(a.status_code, b.status_code)

    def test_csrf_enforced(self):
        c = self.app.test_client(); r = c.post("/login", data={"email": "alice@t.test", "password": PW}); self.assertEqual(r.status_code, 400)

class RateLimitTests(Base):
    rate = True
    def test_login_rate_limit(self):
        c = self.client()
        for _ in range(8): self.post(c, "/login", {"email": "alice@t.test", "password": "bad-pass1"})
        r = self.post(c, "/login", {"email": "alice@t.test", "password": PW})
        self.assertEqual(r.status_code, 200); self.assertIn(b"Too many", r.data)

class RbacTests(Base):
    def test_anonymous_redirected(self):
        for p in ("/staff/", "/student", "/staff/payments", "/learn/paid-maths"): self.assertEqual(self.client().get(p).status_code, 302, p)
    def test_student_blocked_from_staff(self):
        c = self.client("alice")
        for p in ("/staff/", "/staff/payments", "/staff/users", "/staff/settings/bank", "/staff/r/courses", "/staff/audit", "/staff/system"): self.assertEqual(c.get(p).status_code, 403, p)
    def test_instructor_and_writer_limits(self):
        i = self.client("inst")
        for p in ("/staff/payments", "/staff/settings/bank", "/staff/users", "/staff/r/articles", "/staff/r/plans"): self.assertEqual(i.get(p).status_code, 403, p)
        self.assertEqual(i.get("/staff/r/courses").status_code, 200)
        w = self.client("writer")
        for p in ("/staff/payments", "/staff/r/courses", "/staff/r/testimonials"): self.assertEqual(w.get(p).status_code, 403, p)
        self.assertEqual(w.get("/staff/r/articles").status_code, 200)
    def test_admin_needs_specific_permission(self):
        n = self.client("noperm")
        for p in ("/staff/payments", "/staff/settings/bank", "/staff/r/courses", "/staff/users"): self.assertEqual(n.get(p).status_code, 403, p)
        o = self.client("officer"); self.assertEqual(o.get("/staff/payments").status_code, 200); self.assertEqual(o.get("/staff/settings/bank").status_code, 403)
        self.assertEqual(self.client("owner").get("/staff/settings/bank").status_code, 200)
    def test_staff_cannot_escalate(self):
        dbm.ex("INSERT INTO user_permissions VALUES (?,?)", (self.users["noperm"], "users.manage"))
        c = self.client("noperm"); a = self.users["alice"]
        r = self.post(c, f"/staff/users/{a}", {"action": "role", "role": "admin"}); self.assertEqual(self.val("SELECT role FROM users WHERE id=?", (a,)), "student")
        self.post(c, f"/staff/users/{self.users['officer']}", {"action": "perms", "perm": ["system.manage"]}); self.assertEqual(self.client("noperm").get(f"/staff/users/{self.users['owner']}").status_code, 403)
    def test_owner_assigns_permissions(self):
        o = self.client("owner"); self.post(o, f"/staff/users/{self.users['noperm']}", {"action": "perms", "perm": ["reports.view"]})
        self.assertEqual(self.client("noperm").get("/staff/reports").status_code, 200)
    def test_instructor_only_own_courses(self):
        i = self.client("inst"); other = dbm.ex("INSERT INTO courses(division,title,slug,price_kobo,status,instructor_id) VALUES ('academic','Other','other',0,'published',?)", (self.users["owner"],))
        self.assertEqual(i.get(f"/staff/r/courses/{other}/edit").status_code, 404)
        r = self.post(i, "/staff/r/lessons/new", {"course_id": str(other), "title": "x", "kind": "text"}); self.assertEqual(r.status_code, 200)
        self.assertEqual(self.val("SELECT COUNT(*) FROM lessons WHERE course_id=?", (other,)), 0)
