import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { SourceReader, SourceReadError } from '../src/research/source-reader.js';

let server;
let baseUrl;
const reader = new SourceReader({ timeoutMs: 1000 });

before(async () => {
  server = http.createServer((req, res) => {
    if (req.url === '/pagina-valida') {
      res.setHeader('content-type', 'text/html');
      res.end(`<html><head><title>Titulo de Teste</title></head>
        <body>
          <nav>menu irrelevante que deve ser removido</nav>
          <h1>Conteudo Principal</h1>
          <p>Primeiro paragrafo com informacao util.</p>
          <p>Segundo paragrafo tambem util.</p>
          <script>console.log('deve ser removido')</script>
          <footer>rodape irrelevante</footer>
        </body></html>`);
    } else if (req.url === '/nao-encontrado') {
      res.statusCode = 404;
      res.end('nao encontrado');
    } else if (req.url === '/lento') {
      const timer = setTimeout(() => { res.end('nunca deveria chegar aqui'); }, 5000);
      req.on('close', () => clearTimeout(timer)); // cliente abortou (timeout) -> libera o timer
    } else if (req.url === '/binario') {
      res.setHeader('content-type', 'application/octet-stream');
      res.end(Buffer.from([0, 1, 2, 3]));
    } else {
      res.statusCode = 500;
      res.end('erro interno simulado');
    }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(() => {
  server.close();
});

test('SourceReader: le uma pagina real, extrai titulo e remove nav/script/footer', async () => {
  const result = await reader.read(`${baseUrl}/pagina-valida`);
  assert.equal(result.title, 'Titulo de Teste');
  assert.ok(result.text.includes('Conteudo Principal'));
  assert.ok(result.text.includes('Primeiro paragrafo com informacao util.'));
  assert.ok(!result.text.includes('menu irrelevante'));
  assert.ok(!result.text.includes('rodape irrelevante'));
  assert.ok(!result.text.includes('deve ser removido'));
  assert.ok(result.fetchedAt);
});

test('SourceReader: reporta erro honesto em HTTP 404 (nunca finge sucesso)', async () => {
  await assert.rejects(
    () => reader.read(`${baseUrl}/nao-encontrado`),
    (err) => {
      assert.ok(err instanceof SourceReadError);
      assert.equal(err.code, 'HTTP_ERROR');
      return true;
    }
  );
});

test('SourceReader: reporta erro honesto em URL invalida', async () => {
  await assert.rejects(
    () => reader.read('nao-e-uma-url'),
    (err) => {
      assert.equal(err.code, 'INVALID_URL');
      return true;
    }
  );
});

test('SourceReader: reporta erro honesto em timeout', async () => {
  await assert.rejects(
    () => reader.read(`${baseUrl}/lento`),
    (err) => {
      assert.equal(err.code, 'TIMEOUT');
      return true;
    }
  );
});

test('SourceReader: rejeita protocolo nao suportado', async () => {
  await assert.rejects(
    () => reader.read('ftp://exemplo.com/arquivo'),
    (err) => {
      assert.equal(err.code, 'UNSUPPORTED_PROTOCOL');
      return true;
    }
  );
});

test('SourceReader: reporta erro honesto para host inexistente (sem rede/DNS)', async () => {
  await assert.rejects(
    () => reader.read('http://host-que-definitivamente-nao-existe.invalid/'),
    (err) => {
      assert.equal(err.code, 'NETWORK_ERROR');
      return true;
    }
  );
});
