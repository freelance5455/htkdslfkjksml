import sqlite3, tempfile, shutil
from .base import *
from dagba import create_app
from .test_builder import BuilderBase, jpost
from dagba.services import academic as A, access, settings as S, builder as B

def cat(slug): return dbm.val("SELECT id FROM categories WHERE slug=?", (slug,))

class AcademicBase(BuilderBase):
    def make(self, title, level, subject_slug=None, status="published", who="owner", price="1000", **kw):
        c = self.client(who); p = self.payload(title=title, academic_level=level, category_id=cat(subject_slug) if subject_slug else "", price=price, action="publish" if status == "published" else "draft", **kw)
        j = jpost(c, self, "/staff/builder/save", p).get_json(); self.assertTrue(j["ok"], j); return j["id"]

class PublicStructureTests(AcademicBase):
    def test_landing_has_two_academic_levels_and_links_to_the_separate_professional_division(self):
        h = self.app.test_client().get("/academic").data.decode()
        for t in ("Basic", "Secondary School Education", "Advanced", "University-Level Education", "Professional Development", "Professional Examinations and Career Advancement", "Nigerian secondary schools", "university depth"): self.assertIn(t, h)
        for lv in ("basic", "advanced"): self.assertIn(f'href="/academic/{lv}"', h)
        self.assertNotIn('href="/academic/professional"', h); self.assertIn('href="/professional"', h)       # Professional Development is no longer part of Academic
        self.assertNotIn("JSS", h); self.assertNotIn("SS3", h)
    def test_basic_and_advanced_list_their_own_subjects(self):
        c = self.app.test_client(); b = c.get("/academic/basic").data.decode(); a = c.get("/academic/advanced").data.decode()
        for t in ("Mathematics", "Physics", "Chemistry", "Biology", "Economics", "Government", "Literature in English", "Agricultural Science", "Further Mathematics", "Civic Education", "English Language"): self.assertIn(t, b)
        for t in ("Computer Science", "Statistics", "Engineering", "Law"): self.assertIn(t, a); self.assertNotIn(t, b)
        self.assertIn("Government", b); self.assertNotIn("Government", a)
        self.assertIn("/academic/basic/physics", b); self.assertIn("/academic/advanced/physics", a); self.assertIn("Coming soon", b)
    def test_same_subject_exists_independently_in_basic_and_advanced(self):
        self.make("Secondary Physics: Motion", "basic", "academic-physics"); self.make("University Physics: Quantum Mechanics", "advanced", "advanced-physics")
        c = self.app.test_client(); b = c.get("/academic/basic/physics").data.decode(); a = c.get("/academic/advanced/physics").data.decode()
        self.assertIn("Secondary Physics", b); self.assertNotIn("Quantum", b); self.assertIn("Quantum Mechanics", a); self.assertNotIn("Secondary Physics", a)
        self.assertIn("1 course", c.get("/academic/basic").data.decode()); self.assertIn("1 course", c.get("/academic/advanced").data.decode())
        self.assertEqual(self.val("SELECT COUNT(*) FROM categories WHERE name='Physics' AND division='academic'"), 2)
    def test_professional_shows_coming_soon_without_fabricated_content(self):
        c = self.app.test_client(); r = c.get("/professional"); h = r.data.decode(); self.assertEqual(r.status_code, 200)
        self.assertIn("Programs Coming Soon", h); self.assertIn("professional examinations", h.lower()); self.assertNotIn("ICAN", h); self.assertEqual(h.count('class="card'), 1)             # one card: the notice
        self.assertIn("Notify me", h); self.assertEqual(self.val("SELECT COUNT(*) FROM categories WHERE level='professional'"), 0); self.assertEqual(self.val("SELECT COUNT(*) FROM courses WHERE academic_level='professional'"), 0)
        self.assertEqual(c.get("/academic/professional").status_code, 301)                         # the old address still works (permanent redirect)
    def test_professional_programmes_appear_once_published(self):
        pro = dbm.ex("INSERT INTO categories(division,level,name,slug) VALUES ('professional',NULL,'Accounting Examinations','professional-accounting-examinations')")
        self.make("Draft programme", "professional", None, status="draft"); self.make("Live programme", "professional", None); cid = self.val("SELECT id FROM courses WHERE title='Live programme'")
        h = self.app.test_client().get("/professional").data.decode(); self.assertIn("Live programme", h); self.assertNotIn("Draft programme", h); self.assertNotIn("Programs Coming Soon", h)
        dbm.ex("UPDATE courses SET category_id=? WHERE id=?", (pro, cid)); h = self.app.test_client().get("/professional").data.decode(); self.assertIn("Accounting Examinations (1)", h)
        self.assertIn("Live programme", self.app.test_client().get(f"/professional?area={pro}").data.decode())
    def test_unknown_urls_and_other_bucket(self):
        c = self.app.test_client()
        for u in ("/academic/primary", "/academic/basic/not-a-subject", "/academic/advanced/government"): self.assertEqual(c.get(u).status_code, 404, u)
        dbm.ex("INSERT INTO courses(division,academic_level,title,slug,status,price_kobo) VALUES ('academic','basic','Loose course','loose-course','published',100)"); self.assertIn("Other courses", c.get("/academic/basic").data.decode()); self.assertIn("Loose course", c.get("/academic/basic/other").data.decode())
    def test_hidden_subject_not_shown_and_empty_subject_marked(self):
        dbm.ex("UPDATE categories SET active=0 WHERE slug='academic-government'"); c = self.app.test_client(); self.assertNotIn("Government", c.get("/academic/basic").data.decode()); self.assertEqual(c.get("/academic/basic/government").status_code, 404)
    def test_course_page_breadcrumb_and_badges(self):
        cid = self.make("Uni Maths", "advanced", "advanced-mathematics"); slug = self.val("SELECT slug FROM courses WHERE id=?", (cid,)); h = self.app.test_client().get(f"/courses/{slug}").data.decode()
        for t in ("Academic</a>", "/academic/advanced", "/academic/advanced/mathematics", 'badge blue">Advanced'): self.assertIn(t, h)
    def test_course_filters_use_level_not_classes(self):
        self.make("Basic Chem", "basic", "academic-chemistry"); self.make("Adv Chem", "advanced", "advanced-chemistry"); c = self.app.test_client()
        h = c.get("/courses?level=advanced").data.decode(); self.assertIn("Adv Chem", h); self.assertNotIn("Basic Chem", h)
        h = c.get("/courses").data.decode(); self.assertIn("Chemistry (Basic)", h); self.assertIn("Chemistry (Advanced)", h); self.assertNotIn("All classes", h); self.assertNotIn("JSS", h)
        self.assertIn('href="/academic/basic/chemistry"', c.get("/courses?class=SS1&level=basic").data.decode())      # a leftover ?class= is simply ignored; Basic shows its category, not the course title
    def test_sitemap_and_no_jss_anywhere_public(self):
        self.make("Maths Basic", "basic", "academic-mathematics"); c = self.app.test_client(); sm = c.get("/sitemap.xml").data.decode()
        for u in ("/academic/basic", "/academic/advanced", "/professional", "/academic/basic/mathematics"): self.assertIn(u, sm)
        self.assertNotIn("/academic/professional", sm)
        for url in ("/", "/academic", "/academic/basic", "/academic/advanced", "/courses", "/pricing", "/academic/basic/mathematics"): h = c.get(url).data.decode(); self.assertNotIn("JSS", h, url); self.assertNotIn("SS1", h, url)
    def test_editable_texts(self):
        o = self.client("owner"); from dagba.blueprints.staffpay import GROUPS
        data = {f["k"]: S.get(f["k"], "") for f in GROUPS["c_academic"]["fields"]}; data["c.academic.pro_text"] = "Your future in accounting starts here."; data["c.academic.soon_title"] = "Launching soon"
        self.assertEqual(self.post(o, "/staff/settings/c_academic", data).status_code, 302); c = self.app.test_client()
        self.assertIn("Your future in accounting", c.get("/professional").data.decode()); self.assertIn("Launching soon", c.get("/professional").data.decode())

class BuilderAcademicTests(AcademicBase):
    def save(self, who="owner", **kw): return jpost(self.client(who), self, "/staff/builder/save", self.payload(**kw)).get_json()
    def test_academic_course_needs_a_category(self):
        for bad in ("", "primary", None): j = self.save(academic_level=bad); self.assertFalse(j["ok"], bad); self.assertIn("Choose the academic category", " ".join(j["errors"]))
    def test_subject_is_required_to_publish_but_not_for_drafts(self):
        self.assertTrue(self.save(academic_level="basic", category_id="", action="draft")["ok"])
        j = self.save(academic_level="advanced", category_id="", action="publish"); self.assertFalse(j["ok"]); self.assertIn("Choose the subject", " ".join(j["errors"]))
        self.assertTrue(self.save(academic_level="professional", category_id="", action="publish")["ok"])                                         # programme area optional
    def test_subject_must_match_the_category(self):
        j = self.save(academic_level="basic", category_id=cat("advanced-physics")); self.assertFalse(j["ok"]); self.assertIn("does not belong to the Basic category", " ".join(j["errors"]))
        j = self.save(academic_level="advanced", category_id=cat("academic-physics")); self.assertFalse(j["ok"])
        j = self.save(academic_level="basic", category_id=cat("income-copywriting")); self.assertFalse(j["ok"])
    def test_uploaded_course_is_saved_with_category_and_subject_and_appears_in_the_right_place(self):
        j = self.save(title="Calculus I", academic_level="advanced", category_id=cat("advanced-mathematics"), action="publish"); self.assertTrue(j["ok"])
        c = dbm.q1("SELECT * FROM courses WHERE id=?", (j["id"],)); self.assertEqual((c["division"], c["academic_level"], c["category_id"]), ("academic", "advanced", cat("advanced-mathematics")))
        t = self.app.test_client(); self.assertIn("Calculus I", t.get("/academic/advanced/mathematics").data.decode()); self.assertNotIn("Calculus I", t.get("/academic/basic/mathematics").data.decode())
        d = B.load_course(j["id"]); self.assertEqual((d["academic_level"], d["category_id"]), ("advanced", cat("advanced-mathematics")))
    def test_instructor_chooses_category_and_admin_publishes(self):
        j = self.save("inst", title="Inst Chemistry", academic_level="basic", category_id=cat("academic-chemistry"), action="publish"); self.assertTrue(j["ok"], j); self.assertEqual(j["status"], "review")
        self.assertNotIn("Inst Chemistry", self.app.test_client().get("/academic/basic/chemistry").data.decode())
        d = B.load_course(j["id"]); d.update(action="publish", price="1000"); self.assertEqual(jpost(self.client("owner"), self, "/staff/builder/save", d).get_json()["status"], "published")
        self.assertIn("Inst Chemistry", self.app.test_client().get("/academic/basic/chemistry").data.decode())
    def test_reassign_between_categories(self):
        cid = self.make("Movable", "basic", "academic-physics"); d = B.load_course(cid); d.update(academic_level="advanced", category_id=cat("advanced-physics"), action="publish", price="1000"); self.assertTrue(jpost(self.client("owner"), self, "/staff/builder/save", d).get_json()["ok"])
        t = self.app.test_client(); self.assertNotIn("Movable", t.get("/academic/basic/physics").data.decode()); self.assertIn("Movable", t.get("/academic/advanced/physics").data.decode())
    def test_builder_page_has_new_selectors_and_no_jss(self):
        h = self.client("owner").get("/staff/builder").data.decode()
        for t in ("Academic category", "Basic: Secondary School", "Advanced: University level", "Professional Development", 'id="c_level"'): self.assertIn(t, h)
        self.assertNotIn("JSS", h); self.assertNotIn("SS1", h); self.assertIn("builder.js", h)
        js = self.app.test_client().get("/static/js/builder.js").data.decode(); self.assertIn("c.level===lvlSel.value", js)
        import json, re; init = json.loads(re.search(r'id="initial">(.*?)</script>', h, re.S).group(1)); levels = {c["level"] for c in init["cats"] if c["division"] == "academic"}; self.assertEqual(levels, {"basic", "advanced"})
    def test_income_skills_flow_is_unchanged(self):
        j = jpost(self.client("owner"), self, "/staff/builder/save", {"action": "publish", "title": "Copywriting 101", "division": "income", "category_id": cat("income-copywriting"), "price": "3000", "level": "Beginner", "class_level": "", "term": "",
                  "modules": [{"title": "M", "lessons": [{"title": "L", "kind": "text", "body": "x"}]}]}).get_json(); self.assertTrue(j["ok"], j)
        c = dbm.q1("SELECT * FROM courses WHERE id=?", (j["id"],)); self.assertEqual((c["division"], c["academic_level"], c["category_id"], c["level"], c["needs_review"]), ("income", None, cat("income-copywriting"), "Beginner", 0))
        i = self.app.test_client().get("/income-skills").data.decode(); self.assertIn("Copywriting 101", i); self.assertIn("Copywriting", i)
        self.assertNotIn("Copywriting 101", self.app.test_client().get("/academic/basic").data.decode())
        j2 = jpost(self.client("owner"), self, "/staff/builder/save", {"action": "draft", "title": "Stray", "division": "income", "academic_level": "advanced", "category_id": "", "modules": []}).get_json()                     # a stray level on an income course is ignored
        self.assertIsNone(self.val("SELECT academic_level FROM courses WHERE id=?", (j2["id"],)))

class AdminManagementTests(AcademicBase):
    def test_structure_page_permissions_and_content(self):
        for who, code in (("owner", 200), ("inst", 403), ("alice", 403), ("officer", 403), ("writer", 403), ("noperm", 403)): self.assertEqual(self.client(who).get("/staff/academic").status_code, code, who)
        h = self.client("owner").get("/staff/academic").data.decode()
        for t in ("Basic", "Advanced", "Professional Development", "Physics", "+ Add subject"): self.assertIn(t, h)
        dbm.ex("INSERT INTO user_permissions VALUES (?,?)", (self.users["noperm"], "courses.manage")); self.assertEqual(self.client("noperm").get("/staff/academic").status_code, 200)
    def test_review_queue_and_reassign(self):
        cid = dbm.ex("INSERT INTO courses(division,academic_level,title,slug,price_kobo,status,needs_review) VALUES ('academic','basic','Legacy Course','legacy-course',100,'published',1)")
        o = self.client("owner"); self.assertIn("Legacy Course", o.get("/staff/academic").data.decode()); self.assertIn("Academic courses to check", o.get("/staff/catalog").data.decode()); self.assertIn("Legacy Course", o.get("/staff/catalog?review=1").data.decode())
        self.assertIn("Legacy Course", self.app.test_client().get("/academic/basic/other").data.decode())                                          # still visible to students while waiting
        self.post(o, f"/staff/academic/assign/{cid}", {"target": f"advanced:{cat('academic-physics')}"}); self.assertEqual(self.val("SELECT needs_review FROM courses WHERE id=?", (cid,)), 1)   # wrong level for that subject
        self.post(o, f"/staff/academic/assign/{cid}", {"target": "basic:"}); self.assertEqual(self.val("SELECT needs_review FROM courses WHERE id=?", (cid,)), 1)                            # subject required for basic
        self.post(o, f"/staff/academic/assign/{cid}", {"target": f"basic:{cat('academic-biology')}"}); c = dbm.q1("SELECT * FROM courses WHERE id=?", (cid,)); self.assertEqual((c["academic_level"], c["category_id"], c["needs_review"]), ("basic", cat("academic-biology"), 0))
        self.assertIn("Legacy Course", self.app.test_client().get("/academic/basic/biology").data.decode()); self.assertEqual(self.val("SELECT COUNT(*) FROM audit_logs WHERE action='course.academic_assign'"), 1)
        for who in ("inst", "alice", "officer"): self.assertEqual(self.post(self.client(who), f"/staff/academic/assign/{cid}", {"target": "basic:"}).status_code, 403)
        inc = self.val("SELECT id FROM courses WHERE division='income' LIMIT 1") or dbm.ex("INSERT INTO courses(division,title,slug,status) VALUES ('income','Inc','inc-x','draft')"); self.assertEqual(self.post(o, f"/staff/academic/assign/{inc}", {"target": "basic:"}).status_code, 404)
    def test_manage_subjects_independently_per_level(self):
        o = self.client("owner")
        self.post(o, "/staff/r/categories/new", {"division": "academic", "level": "advanced", "name": "Astronomy", "active": "1"}); self.assertEqual(self.val("SELECT slug FROM categories WHERE name='Astronomy'"), "advanced-astronomy")
        self.post(o, "/staff/r/categories/new", {"division": "academic", "level": "basic", "name": "Astronomy", "price_kobo": "1000", "active": "1"}); self.assertEqual(self.val("SELECT COUNT(*) FROM categories WHERE name='Astronomy'"), 2)           # same name in both levels is allowed
        self.post(o, "/staff/r/categories/new", {"division": "academic", "level": "basic", "name": "astronomy", "price_kobo": "1000", "active": "1"}); self.assertEqual(self.val("SELECT COUNT(*) FROM categories WHERE lower(name)='astronomy'"), 2)      # but not twice in one level
        self.post(o, "/staff/r/categories/new", {"division": "academic", "level": "", "name": "No Level"}); self.assertEqual(self.val("SELECT COUNT(*) FROM categories WHERE name='No Level'"), 0)
        self.post(o, "/staff/r/categories/new", {"division": "income", "level": "advanced", "name": "Podcasting", "active": "1"}); self.assertIsNone(self.val("SELECT level FROM categories WHERE name='Podcasting'"))   # income categories carry no level
        self.post(o, "/staff/r/categories/new", {"division": "professional", "level": "", "name": "Project Management", "active": "1"}); self.assertEqual(self.val("SELECT division FROM categories WHERE name='Project Management'"), "professional"); self.assertIsNone(self.val("SELECT level FROM categories WHERE name='Project Management'"))
        self.post(o, "/staff/r/categories/new", {"division": "academic", "level": "professional", "name": "Old Style", "active": "1"}); self.assertEqual(self.val("SELECT COUNT(*) FROM categories WHERE name='Old Style'"), 0)     # Professional is not an academic level any more
        self.assertIn("Astronomy", self.app.test_client().get("/academic/advanced").data.decode())
        self.assertEqual(o.get("/staff/r/categories?level=advanced").status_code, 200); self.assertEqual(o.get("/staff/r/categories/new?level=advanced").status_code, 200)
    def test_changing_or_removing_a_subject_never_loses_courses(self):
        cid = self.make("Keep me", "basic", "academic-economics"); o = self.client("owner"); sid = cat("academic-economics")
        r = self.post(o, f"/staff/r/categories/{sid}/edit", {"division": "academic", "level": "advanced", "name": "Economics", "active": "1"}); self.assertEqual(r.status_code, 200); self.assertEqual(self.val("SELECT level FROM categories WHERE id=?", (sid,)), "basic")
        self.post(o, f"/staff/r/categories/{sid}/delete"); self.assertEqual(self.val("SELECT COUNT(*) FROM courses WHERE id=?", (cid,)), 1); c = dbm.q1("SELECT * FROM courses WHERE id=?", (cid,)); self.assertEqual((c["category_id"], c["needs_review"]), (None, 1))
        self.assertIn("Keep me", self.app.test_client().get("/academic/basic/other").data.decode())
    def test_catalog_shows_levels_and_filters(self):
        self.make("B1", "basic", "academic-physics"); self.make("A1", "advanced", "advanced-physics"); o = self.client("owner")
        h = o.get("/staff/catalog").data.decode(); self.assertIn("Any academic category", h); self.assertIn("Physics (Basic)", h); self.assertIn("Physics (Advanced)", h)
        self.assertIn("A1", o.get("/staff/catalog?level=advanced").data.decode()); self.assertNotIn("B1", o.get("/staff/catalog?level=advanced").data.decode()); self.assertIn("Academic category", o.get("/staff/catalog/export.csv").data.decode())
    def test_basic_subscription_unlocks_basic_only(self):
        b = self.make("Sub Basic", "basic", "academic-physics", price="2000", subscription_eligible=True); a = self.make("Sub Adv", "advanced", "advanced-physics", price="2000", subscription_eligible=True); p = self.make("Sub Pro", "professional", None, price="2000", subscription_eligible=True)
        ref = self.buy(self.client("alice"), "plan", self.plan_a); self.post(self.client("officer"), f"/staff/payments/{self.tx(ref)['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        self.assertEqual(access.course_access(self.users["alice"], dbm.q1("SELECT * FROM courses WHERE id=?", (b,))), "subscription")
        for cid in (a, p): self.assertIsNone(access.course_access(self.users["alice"], dbm.q1("SELECT * FROM courses WHERE id=?", (cid,))), cid)   # Advanced / Professional stay separate
        self.assertIsNone(access.course_access(self.users["alice"], dbm.q1("SELECT * FROM courses WHERE id=?", (self.inc,))))                                  # the Income subscription stays separate

class MigrationTests(Base):
    def test_existing_academic_data_is_preserved_classified_and_flagged(self):
        d = tempfile.mkdtemp(); path = os.path.join(d, "old.db"); mig = os.path.join(d, "m"); os.makedirs(mig)
        for f in ("001_init.sql", "002_video_builder.sql", "003_instructor_payouts.sql"): shutil.copy(os.path.join(MIG, f), mig)
        dbm.migrate(path, mig); c = sqlite3.connect(path); c.row_factory = sqlite3.Row
        c.execute("INSERT INTO users(email,password_hash,full_name,role) VALUES ('s@x','h','Student','student')"); c.execute("INSERT INTO users(email,password_hash,full_name,role) VALUES ('t@x','h','Tutor','instructor')")
        for i, (n, dv) in enumerate((("Physics", "academic"), ("Mathematics", "academic"), ("Copywriting", "income"))): c.execute("INSERT INTO categories(division,name,slug,position) VALUES (?,?,?,?)", (dv, n, ("academic-" if dv == "academic" else "income-") + n.lower(), i))
        c.execute("INSERT INTO categories(division,name,slug) VALUES ('academic','University Stuff','custom-university-stuff')")
        c.execute("INSERT INTO pages(slug,title,body) VALUES ('about','About','Intro.\n\nOur academic courses support JSS1 to SS3 learners, including WAEC preparation, while our income skills courses prepare learners.')")
        c.execute("INSERT INTO pages(slug,title,body) VALUES ('my-own-page','Mine','I wrote this myself and mention JSS1 on purpose.')")
        rows = [("Seeded subject course", "academic", 1, "SS2", None), ("Text-matched subject", "academic", None, "JSS1", "mathematics"), ("No subject at all", "academic", None, None, None), ("Custom category course", "academic", 4, None, None), ("Income course", "income", 3, "Beginner", None)]
        for i, (t, dv, cat_id, cl, subj) in enumerate(rows, 1):
            c.execute("INSERT INTO courses(division,category_id,title,slug,summary,description,thumbnail,class_level,subject,price_kobo,status,instructor_id) VALUES (?,?,?,?,?,?,?,?,?,?,'published',2)", (dv, cat_id, t, f"c{i}", f"sum {i}", f"desc {i}", f"thumb{i}.webp", cl, subj, 500000))
            c.execute("INSERT INTO lessons(course_id,title,kind,position) VALUES (?,?,?,1)", (i, f"Lesson of {t}", "text")); c.execute("INSERT INTO progress(user_id,lesson_id,course_id,completed_at) VALUES (1,?,?,'2026-01-01 00:00:00')", (i, i))
            c.execute("INSERT INTO transactions(reference,user_id,item_type,course_id,item_title,list_price_kobo,amount_kobo,status) VALUES (?,1,'course',?,?,500000,500000,'approved')", (f"R{i}", i, t))
            c.execute("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at,transaction_id) VALUES (1,'course',?,?,'2026-01-01 00:00:00',?)", (i, dv, i))
        c.commit(); before = {t: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("courses", "lessons", "progress", "transactions", "entitlements", "users")}; c.close()
        self.assertEqual(dbm.migrate(path, MIG), ["004_academic_levels.sql", "005_affiliates.sql", "006_faith.sql", "007_faith_paid.sql", "008_faith_instructors.sql", "009_faith_topic_prices.sql", "010_pricing_structure.sql", "011_basic_category_featured.sql", "012_basic_category_image.sql", "013_faith_topic_visuals.sql", "014_faith_tutor_topics.sql", "015_hero_slides.sql", "016_tutor_program.sql", "017_professional_division.sql", "018_professional_navigation.sql", "019_subject_pricing_all_divisions.sql", "020_division_separation.sql", "021_tutor_mou.sql", "022_prelaunch.sql", "023_learning_objectives.sql", "024_interactive_learning.sql", "025_mobile_api.sql", "026_store_billing.sql"]); c = sqlite3.connect(path); c.row_factory = sqlite3.Row
        for t, n in before.items(): self.assertEqual(c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0], n, t)                                           # nothing deleted, nothing duplicated
        co = {r["title"]: r for r in c.execute("SELECT * FROM courses")}
        for t in ("Seeded subject course", "Text-matched subject", "No subject at all", "Custom category course"): self.assertEqual(co[t]["academic_level"], "basic", t)
        self.assertEqual((co["Seeded subject course"]["needs_review"], co["Text-matched subject"]["needs_review"]), (0, 0))                          # reliably classified
        self.assertEqual(c.execute("SELECT name FROM categories WHERE id=?", (co["Text-matched subject"]["category_id"],)).fetchone()[0], "Mathematics")
        self.assertEqual((co["No subject at all"]["needs_review"], co["Custom category course"]["needs_review"]), (1, 1))                           # kept, flagged for an administrator
        inc = co["Income course"]; self.assertEqual((inc["academic_level"], inc["needs_review"], inc["category_id"], inc["class_level"]), (None, 0, 3, "Beginner"))   # Income Skills untouched
        for r in c.execute("SELECT * FROM courses"): self.assertEqual((r["description"], r["thumbnail"]), (f"desc {r['id']}", f"thumb{r['id']}.webp"))
        lv = {r["name"]: r["level"] for r in c.execute("SELECT * FROM categories WHERE division='academic' AND slug NOT LIKE 'advanced-%'")}; self.assertEqual(set(lv.values()), {"basic"})
        self.assertIsNone(c.execute("SELECT level FROM categories WHERE division='income'").fetchone()[0]); self.assertEqual(c.execute("SELECT COUNT(*) FROM categories WHERE level='advanced'").fetchone()[0], 13)
        about = c.execute("SELECT body FROM pages WHERE slug='about'").fetchone()[0]; self.assertNotIn("JSS1", about); self.assertIn("Basic (secondary school), Advanced (university level)", about); self.assertTrue(about.startswith("Intro."))
        self.assertIn("JSS1", c.execute("SELECT body FROM pages WHERE slug='my-own-page'").fetchone()[0])                                                       # nothing else is rewritten
        self.assertEqual(dbm.migrate(path, MIG), []); self.assertEqual(c.execute("SELECT COUNT(*) FROM categories").fetchone()[0], 4 + 13)                                              # re-running adds nothing
        shutil.rmtree(d, ignore_errors=True)
    def test_students_keep_access_and_progress_after_upgrade(self):
        d = tempfile.mkdtemp(); path = os.path.join(d, "old.db"); mig = os.path.join(d, "m"); os.makedirs(mig)
        for f in ("001_init.sql", "002_video_builder.sql", "003_instructor_payouts.sql"): shutil.copy(os.path.join(MIG, f), mig)
        dbm.migrate(path, mig); c = sqlite3.connect(path)
        from werkzeug.security import generate_password_hash as g
        c.execute("INSERT INTO users(id,email,password_hash,full_name,role) VALUES (1,'st@x.t',?,'Stu','student')", (PWHASH,)); c.execute("INSERT INTO categories(division,name,slug) VALUES ('academic','Physics','academic-physics')")
        c.execute("INSERT INTO courses(id,division,category_id,title,slug,class_level,price_kobo,status) VALUES (1,'academic',1,'Old Physics','old-physics','SS3',500000,'published')"); c.execute("INSERT INTO lessons(id,course_id,title,kind,body,position) VALUES (1,1,'L1','text','hello',1)")
        c.execute("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at) VALUES (1,'course',1,'academic','2026-01-01 00:00:00')"); c.execute("INSERT INTO progress(user_id,lesson_id,course_id,completed_at) VALUES (1,1,1,'2026-01-02 00:00:00')"); c.commit(); c.close()
        app = create_app({"DATABASE": path, "PRIVATE_DIR": d + "/p", "PUBLIC_DIR": d + "/u", "SECRET_KEY": "x", "RATE_LIMITS_ENABLED": False})        # auto-migrates on start
        cl = app.test_client()
        with cl.session_transaction() as s: s["_csrf"] = "t"
        cl.post("/login", data={"_csrf": "t", "email": "st@x.t", "password": PW}); self.assertEqual(cl.get("/learn/old-physics").status_code, 200); self.assertEqual(cl.get("/learn/old-physics/lesson/1").status_code, 200)
        self.assertIn("100%", cl.get("/learn/old-physics").data.decode()); self.assertIn("Old Physics", cl.get("/academic/basic/physics").data.decode()); shutil.rmtree(d, ignore_errors=True)
