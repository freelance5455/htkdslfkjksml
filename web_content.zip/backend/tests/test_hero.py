"""Homepage hero carousel: database-driven slides, admin management (images, text, buttons, order, default, rotation), public rendering,
permissions, CSP-safety and image handling."""
import io, os, re
from .base import *
from dagba.services import hero as H

def jpg(w=1400, h=1700, colour=(40, 90, 200)):
    b = io.BytesIO(); Image.new("RGB", (w, h), colour).save(b, "JPEG"); return b.getvalue()

class HeroBase(Base):
    def setUp(self):
        super().setUp(); self.o = self.client("owner"); self.pub = self.app.test_client()
    def home(self): return self.pub.get("/").data.decode()
    def form(self, sid=None, image=None, **kw):
        d = {"_csrf": self.tok(self.o), "headline": "Learn anywhere", "label": "Test", "description": "Short text.", "cta_label": "Go", "cta_url": "/courses", "cta2_label": "", "cta2_url": "",
             "art": "academic", "tone": "purple", "focus": "center", "active": "1"}
        d.update(kw)
        d = {k: v for k, v in d.items() if v is not None}
        if image is not None: d["image"] = (io.BytesIO(image), "pic.jpg")
        return self.o.post(f"/staff/hero/{sid}/edit" if sid else "/staff/hero/new", data=d, content_type="multipart/form-data")
    def ids(self): return [r["id"] for r in dbm.q("SELECT id FROM hero_slides ORDER BY position, id")]
    def row(self, sid): return dbm.q1("SELECT * FROM hero_slides WHERE id=?", (sid,))
    def files(self): return sorted(os.listdir(self.app.config["PUBLIC_DIR"])) if os.path.isdir(self.app.config["PUBLIC_DIR"]) else []

class HeroPublicTests(HeroBase):
    def test_seeded_slides_render_with_real_content_and_no_inline_style_or_script(self):
        h = self.home()
        for t in ("Academic Learning", "Income Skills", "Faith &amp; Personal Growth", "Professional Development", "School subjects, made simple."): self.assertIn(t, h)
        self.assertEqual(h.count('class="hslide'), 4); self.assertIn('data-start="0"', h); self.assertIn('data-autoplay="1"', h); self.assertIn('data-interval="6"', h)
        self.assertNotIn(" style=", h); self.assertEqual(h.count("<h1"), 1)                                   # one real page heading; slide headlines are h2
        self.assertIn("/static/js/hero.js", h); self.assertNotIn("<script>", h.replace('<script type="application/ld+json">', ""))
        self.assertIn('href="/professional"', h); self.assertIn("img/hero/academic.svg", h)
        for f in ("js/hero.js", "img/hero/academic.svg", "img/hero/income.svg", "img/hero/faith.svg", "img/hero/professional.svg"): self.assertEqual(self.pub.get("/static/" + f).status_code, 200, f)
    def test_only_first_slide_picture_loads_immediately(self):
        h = self.home(); self.assertEqual(h.count('fetchpriority="high"'), 1); self.assertEqual(h.count("data-src="), 3)           # the others wait (Nigerian mobile data)
    def test_disabled_slides_are_not_shown_and_all_disabled_falls_back_to_plain_banner(self):
        dbm.ex("UPDATE hero_slides SET active=0 WHERE headline LIKE 'Skills%'"); h = self.home(); self.assertNotIn("Skills that pay", h); self.assertEqual(h.count('class="hslide'), 3)
        dbm.ex("UPDATE hero_slides SET active=0"); h = self.home(); self.assertNotIn("data-hx", h); self.assertIn("hx-plain", h); self.assertIn("Learn what school teaches", h)
        self.assertEqual(self.pub.get("/").status_code, 200)
    def test_single_slide_has_no_controls_and_no_autoplay(self):
        dbm.ex("UPDATE hero_slides SET active=0 WHERE id>1"); h = self.home(); self.assertNotIn("hx-bars", h); self.assertIn('data-autoplay="0"', h)
    def test_default_slide_is_first_shown_and_order_follows_position(self):
        ids = self.ids(); dbm.ex("UPDATE hero_slides SET is_default=0"); dbm.ex("UPDATE hero_slides SET is_default=1 WHERE id=?", (ids[2],)); h = self.home()
        self.assertIn('data-start="2"', h); self.assertRegex(h, r'class="hslide tone-\w+ focus-\w+ is-active"[^>]*aria-label="3 of 4')
        dbm.ex("UPDATE hero_slides SET is_default=0 WHERE id=?", (ids[2],)); dbm.ex("UPDATE hero_slides SET is_default=1, active=0 WHERE id=?", (ids[1],)); self.assertIn('data-start="0"', self.home())   # default but hidden => first visible
    def test_rotation_settings_reach_the_page(self):
        r = self.o.post("/staff/hero/settings", data={"_csrf": self.tok(self.o), "interval": "9"}); self.assertEqual(r.status_code, 302)
        h = self.home(); self.assertIn('data-autoplay="0"', h); self.assertIn('data-interval="9"', h)
        self.o.post("/staff/hero/settings", data={"_csrf": self.tok(self.o), "interval": "4", "autoplay": "1"}); h = self.home(); self.assertIn('data-autoplay="1"', h); self.assertIn('data-interval="4"', h)
    def test_bad_rotation_values_are_refused(self):
        for bad in ("", "abc", "1", "99", "-5"):
            self.o.post("/staff/hero/settings", data={"_csrf": self.tok(self.o), "interval": bad, "autoplay": "1"}); self.assertEqual(H.interval(), 6, bad)
    def test_text_is_escaped(self):
        self.form(headline='<script>alert(1)</script>', description='"><img src=x onerror=alert(1)>', label="<b>x</b>"); h = self.home()
        self.assertNotIn("<script>alert(1)", h); self.assertNotIn("<img src=x", h); self.assertIn("&lt;script&gt;", h)
    def test_buttons_only_render_with_label_and_safe_link(self):
        sid = self.ids()[0]; dbm.ex("UPDATE hero_slides SET cta2_label='Bad', cta2_url='javascript:alert(1)' WHERE id=?", (sid,)); h = self.home()
        self.assertNotIn("javascript:", h)                                                                    # safe_url neutralises anything stored by other means
        dbm.ex("UPDATE hero_slides SET cta_label='', cta2_label='', cta2_url='' WHERE id=?", (sid,)); self.assertNotIn('class="hcta"', self.home().split("</section>")[0].split('class="hslide')[1].split("hmedia")[0])

class HeroAdminTests(HeroBase):
    def test_permissions_and_menu(self):
        for who in (None, "alice", "inst", "writer", "noperm"):
            c = self.app.test_client() if who is None else self.client(who)
            for u in ("/staff/hero/", "/staff/hero/new"): self.assertIn(c.get(u).status_code, (302, 403), (who, u))
            r = c.post("/staff/hero/1/delete", data={"_csrf": self.tok(c) if who else "x"}); self.assertIn(r.status_code, (302, 400, 403))
        self.assertEqual(len(self.ids()), 4)
        self.assertEqual(self.o.get("/staff/hero/").status_code, 200)
        m = self.client("noperm").get("/staff/").data.decode(); self.assertNotIn("Homepage hero", m)
        self.assertIn("Homepage hero", self.o.get("/staff/").data.decode())
        self.assertEqual(self.o.get("/staff/hero/999/edit").status_code, 404)
    def test_admin_page_lists_slides_and_controls(self):
        h = self.o.get("/staff/hero/").data.decode()
        for t in ("School subjects, made simple.", "Automatic rotation", "Make first", "Hide", "Delete", "Add slide", "First slide"): self.assertIn(t, h)
        self.assertNotIn(" style=", h)
        self.assertNotIn(" style=", self.o.get("/staff/hero/new").data.decode())
    def test_add_edit_delete(self):
        r = self.form(headline="New slide here", cta_label="Join", cta_url="https://example.com/x", cta2_label="More", cta2_url="/faq"); self.assertEqual(r.status_code, 302)
        sid = self.ids()[-1]; self.assertEqual(self.row(sid)["headline"], "New slide here"); self.assertEqual(self.row(sid)["position"], 5)
        h = self.home(); self.assertIn("New slide here", h); self.assertIn("https://example.com/x", h)      # live immediately
        self.form(sid, headline="Edited headline", cta_label="Different", cta_url="/pricing"); h = self.home(); self.assertIn("Edited headline", h); self.assertNotIn("New slide here", h); self.assertIn("Different", h)
        r = self.o.post(f"/staff/hero/{sid}/delete", data={"_csrf": self.tok(self.o)}); self.assertEqual(r.status_code, 302); self.assertNotIn(sid, self.ids()); self.assertNotIn("Edited headline", self.home())
    def test_validation_errors_keep_the_form_and_save_nothing(self):
        before = len(self.ids())
        for kw in (dict(headline=""), dict(headline="x" * 71), dict(description="x" * 171), dict(cta_url="javascript:alert(1)"), dict(cta_url="//evil.com"), dict(cta_url="http://plain.example"), dict(cta_label="Go", cta_url=""),
                   dict(cta_label="", cta_url="/courses"), dict(art="nope"), dict(tone="neon"), dict(focus="up")):
            r = self.form(**kw); self.assertEqual(r.status_code, 200, kw); self.assertEqual(len(self.ids()), before, kw)
        self.assertEqual(self.form(cta_label="", cta_url="", cta2_label="", cta2_url="").status_code, 302)     # a slide with no buttons is allowed
    def test_slide_limit(self):
        for _ in range(H.MAX_SLIDES - 4): self.assertEqual(self.form().status_code, 302)
        self.assertEqual(len(self.ids()), H.MAX_SLIDES); r = self.form(); self.assertEqual(r.status_code, 302); self.assertEqual(len(self.ids()), H.MAX_SLIDES)
    def test_enable_disable(self):
        sid = self.ids()[1]; self.o.post(f"/staff/hero/{sid}/toggle", data={"_csrf": self.tok(self.o)}); self.assertEqual(self.row(sid)["active"], 0); self.assertNotIn("Skills that pay", self.home())
        self.o.post(f"/staff/hero/{sid}/toggle", data={"_csrf": self.tok(self.o)}); self.assertEqual(self.row(sid)["active"], 1); self.assertIn("Skills that pay", self.home())
    def test_reorder_and_edges(self):
        a, b, c, d = self.ids(); mv = lambda s, dr: self.o.post(f"/staff/hero/{s}/move", data={"_csrf": self.tok(self.o), "dir": dr})
        mv(b, "up"); self.assertEqual(self.ids(), [b, a, c, d]); h = self.home(); self.assertLess(h.index("Skills that pay"), h.index("School subjects, made simple."))
        mv(b, "up"); self.assertEqual(self.ids(), [b, a, c, d]); mv(d, "down"); self.assertEqual(self.ids(), [b, a, c, d]); mv(c, "down"); self.assertEqual(self.ids(), [b, a, d, c])
    def test_default_selection(self):
        a, b, c, d = self.ids(); self.o.post(f"/staff/hero/{c}/default", data={"_csrf": self.tok(self.o)})
        self.assertEqual(dbm.val("SELECT COUNT(*) FROM hero_slides WHERE is_default=1"), 1); self.assertEqual(self.row(c)["is_default"], 1); self.assertIn('data-start="2"', self.home())
        dbm.ex("UPDATE hero_slides SET active=0 WHERE id=?", (d,)); self.o.post(f"/staff/hero/{d}/default", data={"_csrf": self.tok(self.o)}); self.assertEqual((self.row(d)["active"], self.row(d)["is_default"]), (1, 1))   # making a hidden slide first also shows it
        self.o.post(f"/staff/hero/{d}/toggle", data={"_csrf": self.tok(self.o)}); self.assertEqual(self.row(d)["is_default"], 0)                                                  # hiding it ends its "first" status
        self.form(a, is_default="1"); self.assertEqual(self.row(a)["is_default"], 1); self.assertEqual(dbm.val("SELECT COUNT(*) FROM hero_slides WHERE is_default=1"), 1)
    def test_csrf_required(self):
        r = self.o.post("/staff/hero/1/delete", data={}); self.assertIn(r.status_code, (400, 403)); self.assertEqual(len(self.ids()), 4)

class HeroImageTests(HeroBase):
    def new_with_image(self, **kw):
        self.assertEqual(self.form(image=jpg(), headline="Pic slide", **kw).status_code, 302); return self.ids()[-1]
    def test_upload_creates_small_variants_and_serves_them(self):
        sid = self.new_with_image(image_alt="Students"); r = self.row(sid); self.assertTrue(r["image"].endswith(".webp") or r["image"].endswith(".jpg")); self.assertEqual(r["image_sizes"], "480,800,1200")
        base, ext = os.path.splitext(r["image"]); names = {r["image"], f"{base}-480{ext}", f"{base}-1200{ext}"}; self.assertTrue(names <= set(self.files()))
        sizes = {n: Image.open(os.path.join(self.app.config["PUBLIC_DIR"], n)).width for n in names}; self.assertEqual(sorted(sizes.values()), [480, 800, 1200])
        self.assertLess(os.path.getsize(os.path.join(self.app.config["PUBLIC_DIR"], f"{base}-480{ext}")), 60_000)
        for n in names: self.assertEqual(self.pub.get(f"/media/{n}").status_code, 200)
        h = self.home(); self.assertIn(f"/media/{r['image']}", h); self.assertIn("480w", h); self.assertIn("1200w", h); self.assertIn('alt="Students"', h); self.assertIn('data-fallback="/static/img/hero/academic.svg"', h)
    def test_small_source_is_not_upscaled(self):
        self.assertEqual(self.form(image=jpg(500, 600), headline="Small").status_code, 302); r = self.row(self.ids()[-1])
        self.assertTrue(all(int(w) <= 500 for w in r["image_sizes"].split(","))); self.assertEqual(Image.open(os.path.join(self.app.config["PUBLIC_DIR"], r["image"])).width <= 500, True)
    def test_replace_and_remove_delete_old_files(self):
        sid = self.new_with_image(); old = self.row(sid)["image"]; n0 = len(self.files()); self.assertEqual(n0, 3)
        self.form(sid, image=jpg(900, 900), headline="Pic slide"); new = self.row(sid)["image"]; self.assertNotEqual(old, new); self.assertFalse(any(f.startswith(old.split(".")[0]) for f in self.files())); self.assertEqual(len(self.files()), 2)      # 900 px source: 480 + 800 only, never upscaled
        self.form(sid, headline="Pic slide"); self.assertEqual(self.row(sid)["image"], new)                                   # saving without a file keeps the picture
        self.form(sid, headline="Pic slide", remove_image="1"); self.assertIsNone(self.row(sid)["image"]); self.assertEqual(self.files(), [])
        h = self.home(); self.assertIn("img/hero/academic.svg", h)
    def test_delete_slide_removes_its_files(self):
        sid = self.new_with_image(); self.assertEqual(len(self.files()), 3); self.o.post(f"/staff/hero/{sid}/delete", data={"_csrf": self.tok(self.o)}); self.assertEqual(self.files(), [])
    def test_bad_uploads_are_refused_without_saving(self):
        n = len(self.ids())
        for data, name in ((b"not an image", "a.jpg"), (png_bytes()[:30], "b.png"), (PDF, "c.jpg"), (b"GIF89a....", "d.gif")):
            d = {"_csrf": self.tok(self.o), "headline": "Bad", "art": "academic", "tone": "purple", "focus": "center", "active": "1", "image": (io.BytesIO(data), name)}
            r = self.o.post("/staff/hero/new", data=d, content_type="multipart/form-data"); self.assertEqual(r.status_code, 200, name)
        self.assertEqual(len(self.ids()), n); self.assertEqual(self.files(), [])
    def test_validation_error_after_upload_leaves_no_orphan_files(self):
        self.form(image=jpg(), headline=""); self.assertEqual(self.files(), [])
    def test_png_with_transparency_and_phone_rotation(self):
        b = io.BytesIO(); Image.new("RGBA", (900, 600), (0, 0, 0, 0)).save(b, "PNG")
        d = {"_csrf": self.tok(self.o), "headline": "PNG", "art": "academic", "tone": "blue", "focus": "top", "active": "1", "image": (io.BytesIO(b.getvalue()), "x.png")}
        self.assertEqual(self.o.post("/staff/hero/new", data=d, content_type="multipart/form-data").status_code, 302); self.assertIn("focus-top", self.home())
    def test_shared_image_is_kept_while_another_slide_uses_it(self):
        sid = self.new_with_image(); r = self.row(sid); dbm.ex("INSERT INTO hero_slides(headline,image,image_sizes,position) VALUES ('Twin',?,?,9)", (r["image"], r["image_sizes"]))
        self.o.post(f"/staff/hero/{sid}/delete", data={"_csrf": self.tok(self.o)}); self.assertEqual(len(self.files()), 3)
