# تشغيل الخادم الخلفي لتطبيق فيديو

## المسار المقترح
- Supabase: Auth + PostgreSQL + Storage.
- Admin: مجلد `admin/` كصفحة HTTPS مستقلة.
- LIVE: LiveKit/Agora عبر Edge Function أو backend، مع إبقاء الأسرار خارج APK.

## إعداد Supabase
1. أنشئ مشروعًا جديدًا.
2. شغّل `supabase/schema.sql` كاملًا في SQL Editor.
3. من Authentication فعّل Email/Password.
4. أنشئ Storage buckets من الـSQL (videos وavatars).
5. أنشئ مستخدمًا من التطبيق، ثم اجعله مديرًا:
   `update public.profiles set role='admin' where id='UUID';`
6. ضع Project URL وAnon Key في:
   - `app/src/main/assets/config.js`
   - `admin/config.js`

## النشر
- APK: ابنِ المشروع من Android Studio.
- Admin: ارفع مجلد `admin/` على استضافة HTTPS مثل Cloudflare Pages أو Vercel أو Nginx.
- لا تضع Service Role Key أو LiveKit API Secret داخل APK أو `admin/config.js`.

## LIVE الحقيقي
الواجهة وقاعدة البيانات جاهزان لتسجيل جلسات LIVE، لكن نقل الصوت/الفيديو المباشر نفسه يحتاج مزود WebRTC. استخدم LiveKit/Agora مع token يصدره backend/Edge Function.
