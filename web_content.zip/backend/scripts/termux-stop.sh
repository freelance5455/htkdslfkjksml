#!/data/data/com.termux/files/usr/bin/bash
tmux kill-session -t dagba 2>/dev/null && echo "Website stopped." || echo "Website was not running."
termux-wake-unlock 2>/dev/null || true
