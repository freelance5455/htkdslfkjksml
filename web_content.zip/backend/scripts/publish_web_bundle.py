#!/usr/bin/env python3
"""Publish a LIVE UPDATE of the app's web layer (HTML/CSS/JS in mobile/www) to every installed app, without a store release.
Allowed by Apple/Google only for interpreted web assets: native code, plugins, permissions, icons and anything in android/ or ios/ still need a store build.
Usage (on the server, from the backend folder):
  python scripts/publish_web_bundle.py /path/to/mobile/www 1.0.1 [--min-native 1.0.0] [--dry-run]
--min-native: the lowest installed app version (store build) that can run this bundle. Older installs skip it and keep working on their own bundle."""
import argparse, hashlib, os, re, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def build(www, version, out_dir):
    if not os.path.isfile(os.path.join(www, "index.html")): sys.exit("index.html not found in " + www)
    os.makedirs(out_dir, exist_ok=True); path = os.path.join(out_dir, f"dagba-web-{version}.zip")
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _d, files in os.walk(www):
            for f in sorted(files):
                if f.startswith(".") or f.endswith(".map"): continue
                full = os.path.join(root, f); z.write(full, os.path.relpath(full, www))      # index.html must sit at the zip root
    return path, hashlib.sha256(open(path, "rb").read()).hexdigest()

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("www"); ap.add_argument("version"); ap.add_argument("--min-native", default=""); ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    if not re.fullmatch(r"\d+\.\d+\.\d+(-[0-9A-Za-z.]+)?", a.version): sys.exit("version must look like 1.0.1")
    from dagba import create_app
    app = create_app()
    out = os.path.join(app.config["PUBLIC_DIR"], "bundles")
    path, sha = build(a.www, a.version, out); size = os.path.getsize(path)
    print(f"bundle {os.path.basename(path)}  {size/1024:.0f} KB  sha256={sha}")
    if a.dry_run: os.remove(path); print("dry run: nothing published"); return
    with app.app_context():
        from dagba.services import settings as S
        S.put("mobile.bundle_url", f"{app.config['SITE_URL']}/api/v1/bundles/{os.path.basename(path)}"); S.put("mobile.bundle_sha256", sha)
        S.put("mobile.bundle_min_native", a.min_native); S.put("mobile.bundle_version", a.version)        # version is written last: apps only see a complete record
    print("Published. Apps pick it up at next launch and apply it on the launch after (never mid-lesson). To roll back, publish the previous bundle again with a NEW higher version number.")

if __name__ == "__main__": main()
