#!/data/data/com.termux/files/usr/bin/bash
# One-time setup of Dagba Digital Academy inside Termux (Android).
# Usage:  bash ~/dagba/scripts/termux-setup.sh
set -e
APP="$HOME/dagba"; ENVDIR="$HOME/dagba-env"; DATA="$HOME/dagba-data"
[ -f "$APP/manage.py" ] || { echo "ERROR: $APP/manage.py not found. Unzip the project into your home folder first (see guide, Step 4)."; exit 1; }

echo; echo "== 1/6  Updating Termux (press Enter if asked about configuration files) =="
pkg update -y && pkg upgrade -y

echo; echo "== 2/6  Installing required programs =="
pkg install -y python python-pillow unzip tmux nano openssl libjpeg-turbo libwebp cloudflared cronie termux-services termux-api 2>&1 | tail -n 5

echo; echo "== 3/6  Creating the Python environment and installing the website's libraries =="
python -m venv --system-site-packages "$ENVDIR"
. "$ENVDIR/bin/activate"
pip install --upgrade pip
pip install "Flask>=3.1,<3.2" "Werkzeug>=3.1,<3.2" "reportlab>=4.4,<4.5" gunicorn
python -c "import flask, PIL, reportlab; print('Libraries OK: Flask', flask.__version__, '| Pillow', PIL.__version__, '| ReportLab', reportlab.Version)"

echo; echo "== 4/6  Creating your private data folders and settings file =="
mkdir -p "$DATA/private" "$DATA/public" "$DATA/backups" "$DATA/logs"
if [ -f "$APP/.env" ]; then
  echo ".env already exists: keeping it."
else
  KEY=$(python -c "import secrets;print(secrets.token_hex(32))")
  cat > "$APP/.env" <<EOF
SECRET_KEY=$KEY
SITE_URL=http://localhost:8000
COOKIE_SECURE=false
TRUST_PROXY=false
DATABASE_PATH=$DATA/dagba.db
PRIVATE_UPLOAD_DIR=$DATA/private
PUBLIC_UPLOAD_DIR=$DATA/public
EOF
  chmod 600 "$APP/.env"
  echo "Created $APP/.env with a new random SECRET_KEY."
fi

echo; echo "== 5/6  Creating the database =="
cd "$APP"
python manage.py migrate
python manage.py seed

echo; echo "== 6/6  Create the OWNER (administrator) account =="
python manage.py create-admin

chmod +x "$APP"/scripts/*.sh
echo; echo "DONE. Next: bash ~/dagba/scripts/termux-start.sh lan"
