#!/usr/bin/env python3
"""Set or show the mobile-app settings that have no screen in the admin dashboard. Only keys starting with 'mobile.' are accepted.
  python scripts/mobile_settings.py show
  python scripts/mobile_settings.py set mobile.android_package com.dagbadigitalacademy.app
Keys: mobile.android_package, mobile.android_sha256 (comma-separated), mobile.apple_app_id (TEAMID.bundleid), mobile.store_url_android, mobile.store_url_ios.
(mobile.bundle_* are written by publish_web_bundle.py.)"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dagba import create_app
KEYS = ("mobile.android_package", "mobile.android_sha256", "mobile.apple_app_id", "mobile.store_url_android", "mobile.store_url_ios")
app = create_app()
with app.app_context():
    from dagba.services import settings as S
    if len(sys.argv) >= 2 and sys.argv[1] == "show":
        for k in KEYS + ("mobile.bundle_version", "mobile.bundle_min_native"): print(f"{k} = {S.get(k, '') or '(not set)'}")
    elif len(sys.argv) == 4 and sys.argv[1] == "set":
        if sys.argv[2] not in KEYS: sys.exit("Unknown key. Allowed: " + ", ".join(KEYS))
        if sys.argv[2].startswith("mobile.store_url") and not sys.argv[3].startswith("https://"): sys.exit("URL must start with https://")
        S.put(sys.argv[2], sys.argv[3]); print("saved")
    else: print(__doc__)
