#!/data/data/com.termux/files/usr/bin/bash
# Start the website (and optionally an internet tunnel) in the background.
#   termux-start.sh lan      website only, reachable on your home Wi-Fi at http://PHONE-IP:8000
#   termux-start.sh quick    website + free temporary public https address (changes every restart)
#   termux-start.sh tunnel   website + your permanent Cloudflare tunnel (needs ~/.dagba-tunnel-token)
#   termux-start.sh          = "tunnel" if the token file exists, otherwise "lan"
APP="$HOME/dagba"; ENVDIR="$HOME/dagba-env"; LOG="$HOME/dagba-data/logs"; TOKEN="$HOME/.dagba-tunnel-token"
mkdir -p "$LOG"
MODE="${1:-}"; [ -z "$MODE" ] && { [ -f "$TOKEN" ] && MODE=tunnel || MODE=lan; }
termux-wake-lock 2>/dev/null || true            # keep the CPU awake while the site runs
tmux kill-session -t dagba 2>/dev/null || true
BIND="0.0.0.0:8000"; [ "$MODE" != "lan" ] && BIND="127.0.0.1:8000"
tmux new-session -d -s dagba -n web "cd $APP && . $ENVDIR/bin/activate && gunicorn -w 2 --threads 4 --timeout 120 -b $BIND --access-logfile - --error-logfile - wsgi:app 2>&1 | tee -a $LOG/web.log"
case "$MODE" in
  quick)  tmux new-window -t dagba -n tunnel "cloudflared tunnel --url http://127.0.0.1:8000 2>&1 | tee -a $LOG/tunnel.log" ;;
  tunnel) [ -f "$TOKEN" ] || { echo "No tunnel token found at $TOKEN (see guide, Part C)."; exit 1; }
          tmux new-window -t dagba -n tunnel "cloudflared tunnel run --token \$(cat $TOKEN) 2>&1 | tee -a $LOG/tunnel.log" ;;
esac
sleep 3
echo "Started in mode: $MODE."
echo "  Watch it:   tmux attach -t dagba      (leave with Ctrl+B then D)"
echo "  Logs:       $LOG"
[ "$MODE" = "lan" ] && echo "  Open on the phone: http://localhost:8000   |   other devices on the same Wi-Fi: http://PHONE-IP:8000"
[ "$MODE" = "quick" ] && { echo "  Your temporary public address will appear below in about 10 seconds:"; sleep 10; grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' "$LOG/tunnel.log" | tail -n 1; }
true
