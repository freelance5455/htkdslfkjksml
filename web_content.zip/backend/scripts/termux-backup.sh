#!/data/data/com.termux/files/usr/bin/bash
# Backs up the database + all uploads (videos, receipts, images) and, if allowed, copies it to your phone's Download folder.
APP="$HOME/dagba"; DATA="$HOME/dagba-data"; OUT="$DATA/backups"; D=$(date +%F)
mkdir -p "$OUT"; cd "$APP" && . "$HOME/dagba-env/bin/activate"
python manage.py backup "$OUT/dagba-$D.db" >/dev/null && tar -czf "$OUT/dagba-uploads-$D.tar.gz" -C "$DATA" private public && echo "Backup saved: $OUT/dagba-$D.db and dagba-uploads-$D.tar.gz"
if [ -d "$HOME/storage/downloads" ]; then mkdir -p "$HOME/storage/downloads/dagba-backups"; cp "$OUT/dagba-$D.db" "$OUT/dagba-uploads-$D.tar.gz" "$HOME/storage/downloads/dagba-backups/" && echo "Copy placed in your phone's Download/dagba-backups folder."; fi
ls -1t "$OUT"/dagba-2* 2>/dev/null | tail -n +15 | xargs -r rm -f     # keep the newest 14 files
