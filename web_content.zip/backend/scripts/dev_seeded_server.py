"""DEVELOPMENT ONLY: starts the app on a throw-away database filled with sample data so the mobile app/API can be exercised end to end.
Never point this at production: it creates a temporary database and demo users (password Passw0rdTest1)."""
import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tests.base import Base
class Seed(Base):
    def runTest(self): pass
if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5055
    s = Seed(); s.setUp()
    from dagba import db as dbm
    from dagba.util import now
    dbm.ex("INSERT INTO entitlements(user_id,kind,course_id,division,starts_at) VALUES (?,?,?,?,?)", (s.users["alice"], "course", s.paid, "academic", now()))
    s.app.config["SITE_URL"] = f"http://127.0.0.1:{port}"
    print("seeded; alice@t.test / Passw0rdTest1", flush=True)
    s.app.run("127.0.0.1", port, threaded=True, use_reloader=False)
