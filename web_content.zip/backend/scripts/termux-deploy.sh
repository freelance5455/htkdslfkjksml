#!/data/data/com.termux/files/usr/bin/bash
# Deploy a new version of Dagba Digital Academy on your phone and restore your latest backup.
#   Run from Termux:   bash ~/storage/downloads/dagba-deploy.sh   (or, after the first deploy, bash ~/dagba/scripts/termux-deploy.sh)
#   Options:  --yes      do not ask for confirmation
#             --no-restore   deploy and migrate only
#             tunnel|lan|quick   how to start the site afterwards (default: same as termux-start.sh)
# Looks in  Download/dagba-digital-academy-complete-source.zip  (the new site)  and  Download/dagba-backups  (your backups).
set -e
DL="${DL:-$HOME/storage/downloads}"; ZIP="$DL/dagba-digital-academy-complete-source.zip"; BK="$DL/dagba-backups"
APP="$HOME/dagba"; ENVDIR="$HOME/dagba-env"; YES=0; RESTORE=1; MODE=""
for a in "$@"; do case "$a" in --yes|-y) YES=1;; --no-restore) RESTORE=0;; lan|quick|tunnel) MODE="$a";; esac; done
say() { echo; echo "== $* =="; }
die() { echo; echo "STOPPED: $*"; exit 1; }

[ -d "$DL" ] || die "Cannot see your Downloads folder. Run  termux-setup-storage  once, tap Allow, then run this again."
[ -f "$ZIP" ] || die "Not found: $ZIP  (the zip must be named dagba-digital-academy-complete-source.zip and sit in Downloads)."
[ -x "$ENVDIR/bin/python" ] || [ -f "$ENVDIR/bin/activate" ] || die "The site is not installed on this phone yet. Do Part B of the guide first (bash ~/dagba/scripts/termux-setup.sh), then run this again."

# ---- 1. pick the backup (before touching anything) ---------------------------------------------
DB=""; TAR=""; AZIP=""
if [ "$RESTORE" = 1 ]; then
  [ -d "$BK" ] || die "Backup folder not found: $BK  (use --no-restore to deploy without restoring)."
  DB=$(ls -1 "$BK"/dagba-2*.db 2>/dev/null | sort | tail -n 1 || true)
  if [ -n "$DB" ]; then
    D=$(basename "$DB" .db); D=${D#dagba-}
    [ -f "$BK/dagba-uploads-$D.tar.gz" ] && TAR="$BK/dagba-uploads-$D.tar.gz" || TAR=$(ls -1 "$BK"/dagba-uploads-*.tar.gz 2>/dev/null | sort | tail -n 1 || true)
  else
    AZIP=$(ls -1t "$BK"/*.zip 2>/dev/null | head -n 1 || true)       # a ZIP downloaded from Admin > Backup & export
  fi
  [ -n "$DB$AZIP" ] || die "No backup found in $BK (expected dagba-YYYY-MM-DD.db and dagba-uploads-YYYY-MM-DD.tar.gz, or a ZIP from Backup & export)."
  echo "Backup to restore:"; echo "   database: ${DB:-(inside $AZIP)}"; echo "   uploads : ${TAR:-${AZIP:-NONE found: uploaded files will be left as they are}}"
  echo "Restoring REPLACES the live database with this backup (a safety copy of the current one is kept)."
  if [ "$YES" != 1 ]; then printf "Continue? Type yes: "; read -r ans; [ "$ans" = yes ] || die "Cancelled. Nothing was changed."; fi
fi

# ---- 2. stop the site, deploy the new code ---------------------------------------------------------
say "1/5 Stopping the website"
bash "$APP/scripts/termux-stop.sh" 2>/dev/null || tmux kill-session -t dagba 2>/dev/null || true
say "2/5 Deploying the new site files (your settings and data are not touched)"
command -v unzip >/dev/null || pkg install -y unzip
cd "$HOME" && unzip -oq "$ZIP" && chmod +x "$APP"/scripts/*.sh
[ -f "$APP/manage.py" ] || die "The zip did not contain a dagba folder with manage.py."
[ -f "$ENVDIR/bin/activate" ] && . "$ENVDIR/bin/activate"
[ -f "$APP/.env" ] && { set -a; . "$APP/.env"; set +a; }
DATA="$HOME/dagba-data"; DBFILE="${DATABASE_PATH:-$DATA/dagba.db}"; PRIV="${PRIVATE_UPLOAD_DIR:-$DATA/private}"; PUB="${PUBLIC_UPLOAD_DIR:-$DATA/public}"
mkdir -p "$DATA/backups" "$DATA/logs" "$PRIV" "$PUB" "$(dirname "$DBFILE")"
cd "$APP"

# ---- 3. restore the backup --------------------------------------------------------------------------------
if [ "$RESTORE" = 1 ]; then
  say "3/5 Restoring your backup"
  if [ -f "$DBFILE" ]; then SAFE="$DATA/backups/before-restore-$(date +%F-%H%M%S).db"; cp "$DBFILE" "$SAFE" && echo "Safety copy of the current database: $SAFE"; fi
  TMP=$(mktemp -d "$HOME/.dagba-restore.XXXXXX"); trap 'rm -rf "$TMP"' EXIT
  if [ -n "$AZIP" ]; then
    unzip -oq "$AZIP" -d "$TMP"; NEWDB=$(find "$TMP" -name 'dagba*.db' | head -n 1); [ -n "$NEWDB" ] || die "No database inside $AZIP."
    SRC_UP="$TMP"
  else NEWDB="$DB"; SRC_UP=""; fi
  python - "$NEWDB" <<'PY' || die "The backup database failed its integrity check (it may be damaged or incomplete). Nothing was replaced."
import sqlite3, sys
c = sqlite3.connect("file:%s?mode=ro" % sys.argv[1], uri=True)
if c.execute("PRAGMA integrity_check").fetchone()[0] != "ok" or not c.execute("SELECT 1 FROM sqlite_master WHERE name='users'").fetchone(): sys.exit(1)
PY
  rm -f "$DBFILE-wal" "$DBFILE-shm"; cp "$NEWDB" "$DBFILE.new" && mv "$DBFILE.new" "$DBFILE"; echo "Database restored."
  if [ -n "$TAR" ]; then tar -xzf "$TAR" -C "$DATA" && echo "Uploads restored from $(basename "$TAR")."
  elif [ -n "$SRC_UP" ]; then [ -d "$SRC_UP/private" ] && cp -a "$SRC_UP/private/." "$PRIV/"; [ -d "$SRC_UP/public" ] && cp -a "$SRC_UP/public/." "$PUB/"; echo "Uploads restored from the ZIP."
  else echo "No uploads archive found: uploaded files left as they are."; fi
else say "3/5 Restore skipped (--no-restore)"; fi

# ---- 4. migrations (after the restore, so the restored database is brought up to date) ---------
say "4/5 Running database migrations"
python manage.py migrate
python - <<'PY'
import sqlite3, os
c = sqlite3.connect(os.environ.get("DATABASE_PATH") or os.path.expanduser("~/dagba-data/dagba.db"))
print("Faith tables present:", bool(c.execute("SELECT 1 FROM sqlite_master WHERE name='faith_series'").fetchone()), "| users:", c.execute("SELECT COUNT(*) FROM users").fetchone()[0])
PY

# ---- 5. start -----------------------------------------------------------------------------------------------------------
say "5/5 Starting the website"
if [ -n "$DEPLOY_NO_START" ]; then echo "(start skipped)"; else bash "$APP/scripts/termux-start.sh" $MODE; fi
echo; echo "DONE. The new version is live with your restored data."
