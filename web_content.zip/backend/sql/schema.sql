CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY,
    balance BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reward_sessions (
    nonce UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'rewarded', 'expired')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS reward_transactions (
    transaction_id TEXT PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    nonce UUID REFERENCES reward_sessions(nonce),
    ad_network TEXT NOT NULL,
    ad_unit TEXT NOT NULL,
    reward_amount INTEGER NOT NULL,
    reward_item TEXT NOT NULL,
    timestamp_ms BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_reward_sessions_user
    ON reward_sessions(user_id);

CREATE INDEX IF NOT EXISTS idx_reward_transactions_user
    ON reward_transactions(user_id);
