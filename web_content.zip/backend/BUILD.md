# Production checklist
- Use HTTPS.
- Store Webull secrets in server environment/secret manager.
- Add authentication between APK and backend before public deployment.
- Add Webull MQTT streaming for true push quotes; REST snapshot is fallback/on-demand.
- Persist candles server-side for M1/M5/M15/H1/D1 strategy calculations.
- Mark data STALE/OFFLINE when the stream stops; never substitute demo prices.
- Keep all order/trading routes disabled.
