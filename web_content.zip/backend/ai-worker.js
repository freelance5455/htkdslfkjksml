// Proxy gratuit (Cloudflare Workers) pour l'assistant IA. La clé reste côté serveur :
//   wrangler secret put ANTHROPIC_API_KEY
// Attention : l'API Anthropic est payante ; quiconque connaît l'URL peut consommer votre crédit.
// Gardez l'URL privée et ajoutez une limitation de débit avant tout usage public.
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (req.method !== 'POST') return new Response('POST only', { status: 405, headers: cors });
    let b; try { b = await req.json(); } catch { return new Response('bad json', { status: 400, headers: cors }); }
    const messages = (b.messages || []).slice(-10).map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content).slice(0, 2000) }));
    if (!messages.length || messages[0].role !== 'user') return new Response('bad messages', { status: 400, headers: cors });
    const system = 'Tu es l\'assistant pédagogique de Crypto Max PRO. Réponds dans la langue de l\'utilisateur (' + String(b.lang || 'ar').slice(0, 2) + '), de façon concise. Explique les concepts et les données fournies, sans conseil financier ni promesse de gain, et ne demande jamais de clé privée ni de phrase de récupération. Prix récents : ' + String(b.context || '').slice(0, 800);
    const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' }, body: JSON.stringify({ model: 'claude-haiku-5-5', max_tokens: 600, system, messages }) });
    if (!r.ok) return new Response('upstream ' + r.status, { status: 502, headers: cors });
    const d = await r.json();
    return new Response(JSON.stringify({ reply: (d.content || []).filter(x => x.type === 'text').map(x => x.text).join('\n') }), { headers: { ...cors, 'Content-Type': 'application/json' } });
  }
};
