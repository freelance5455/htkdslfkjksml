# Changing the whole website theme

**Admin > Theme & colours** (needs the *settings.manage* permission; the owner always has it).
The page has a **live preview** on the right. Nothing changes on the real site until you press **Save theme**.

## What you can change
* **Ready-made looks**: Dagba purple (the original), Ocean blue, Emerald, Sunset, Slate & gold, Midnight (dark mode). Click one, then adjust anything.
* **Colours**: primary, header/footer, accent, home-page banner middle, page background, cards/tables/forms, body text, headings,
  secondary text, borders and soft highlight. Everything else is worked out for you: the text on the header, banner and buttons switches
  between light and dark automatically so it stays readable, and tints/borders are derived from your choices.
* **Fonts**: body and heading fonts (system fonts, so nothing is downloaded) and text size (14 to 20 px).
* **Shape & layout**: corner roundness (square to very rounded), pill-shaped buttons, page width, home-banner style
  (colour blend / solid header colour / solid primary colour), sticky header on/off, animations on/off.
* **Advanced custom CSS**: for designers; added last so it can override anything.
* **Restore the original theme** puts everything back (colours, fonts, layout, custom CSS).

## Light / dark mode switch for visitors
A moon / sun button in the header (next to the Menu button on phones) lets any visitor switch the whole site between light and dark. It appears on every page,
including the student and admin dashboards, and the choice is remembered on that visitor's device.
* **Admin > Theme & colours > Light / dark mode**: show or hide the button, and choose what a first-time visitor sees (light, or whatever their device is set to).
* The dark colours are generated from your primary colour: near-black tinted backgrounds, light text, and your primary/accent colours lightened just enough to stay readable.
  Use the **Light / Dark** buttons above the live preview to check them.
* If your own theme is already dark (e.g. the Midnight preset) the button hides itself, because there is nothing to switch to.
* The mode is applied before the page paints, so there is no flash of the wrong colours. It needs no account and works with cookies/JavaScript restrictions
  (if saving is blocked the switch still works for that page view).

## Where it applies
Public pages, student dashboards, staff/admin pages (they share one stylesheet) and certificates (which use the primary and header colours).
Logo and favicon stay under **Branding**.

## Good to know
* The shipped stylesheet defaults are the original look, so the site looks exactly as before until you save a change.
* After saving, visitors get the new look on their next page load (the stylesheet link carries a revision number).
* If a combination is hard to read (body text, headings or the primary colour against the page or cards), you get a warning when saving and
  in the preview. Aim for contrast 4.5:1 or more.
* Fonts are limited to ones already on visitors' devices because the site's security policy only allows its own files. Custom CSS may
  use images and fonts hosted on this site, not other websites.
* Saves are recorded in the audit log.

## Technical notes
* Engine: `dagba/services/theme.py` (validation, colour maths, CSS generation). Routes: `/staff/theme` (+ `/staff/theme/preview`) in `blueprints/staffpay.py`;
  served as `/theme.css`, loaded after `static/css/app.css`, whose `:root` block holds the defaults.
* Settings keys: `brand.primary`, `brand.dark`, `brand.accent` (unchanged, so nothing is lost on upgrade) and new `theme.*` keys.
* No database migration is needed.
* Dark mode: `services/theme.py` (`dark_values`, `dark_css`) emits `html[data-mode=dark]{...}` inside `/theme.css`; `static/js/mode.js` (loaded in `<head>`) sets the attribute and stores the choice in `localStorage` (`dda-mode`).
* Tests: `tests/test_theme.py` (includes a guard that no theme colours are hard-coded in the stylesheet again).
