# Faith & Spiritual Growth

A native part of the academy: same website design, menu, user accounts, admin dashboard, uploads and backups. It is **not** a separate platform. Each Faith **series is a paid course**, sold through the same checkout, payment approval, promo codes, gateways and refunds as every other course. It does not use certificates or subscription plans.

## What learners see
- **Faith** in the main menu and footer (`/faith`), plus a section on the homepage (shown once lessons are published).
- Six topics out of the box: Bible Studies, Christian Living, Prayer, Biblical Wisdom, Relationships, Spiritual Growth.
- Lessons are **video**, **audio**, **reading** or **study guide** (PDF/Word/etc.). One lesson can combine them, e.g. a video with an audio-only version and a PDF guide.
- **Series** group lessons into an ordered study (e.g. "The Gospel of John") with progress.
- Search and filter by topic and format. Works on phones.
- Signed-in learners get: progress, resume where you stopped (video/audio), "Mark complete & continue", "Save for later", and **My faith journey** (also linked in the student menu and shown on the student dashboard).
- **Free previews:** any lesson marked *Free preview* is open to everyone, no account needed. This is the public content people can try before buying.
- **Paid courses:** the other lessons in a priced series show as *Locked*. The lesson page shows the title and summary plus an **Enrol in this course** button. The video, audio, text and study files are never sent to someone who has not paid (the media links are protected too).
- **Buying:** Enrol takes the learner to the normal checkout (promo code, bank transfer or card, as configured). Access starts when staff approve the payment (or at once for a 100% promo), and the learner is notified. Bought courses appear under **My faith courses**.
- A refund removes access. Access can be lifetime or a number of days, set per series.
- A series with price 0 is free to every signed-in learner (nothing is locked from them).
- **Topics can be priced too** (admin, under Faith: Topics). A topic price is a bundle: buying it unlocks every course-content lesson in that topic, whether the lesson is in a series or not, including lessons added later. Owning either a series or its topic unlocks a lesson, and locked lessons offer both options when both are priced. Topic sales go through the same checkout, approval, promo codes and refunds. They have no instructor, so no tutor payout is created.

## What you do (admin)
Sign in as owner (or an admin who has the new **faith.manage** permission, granted on the user's page under Users).

| Menu item | Use |
|---|---|
| Faith overview | Counts, topics, recent lessons, quick links |
| Faith: Lessons | List, search, filter, publish/unpublish, archive, delete |
| (+ New lesson) | One-page editor: details, video/audio/study-material upload, written text, access, status |
| Faith: Topics | Rename, reorder, hide, add topics |
| Faith: Series | Create a course: set its **Price**, lifetime/limited access, cover image; assign lessons in the lesson editor |
| Faith settings | Maximum audio upload size |
| Website text & menus > Faith & Spiritual Growth text | Headings and messages; menu links live under "Header menu" / "Footer: Explore links" |
| Homepage | Tick/untick "Show Faith & Spiritual Growth section" |

**To sell a course:** create the series, set its price (an admin or the course's tutor can) and publish it, then put lessons in it. In each lesson choose *Free preview* (open to all) or *Course content* (needs purchase; the default). Lessons that are not in a series can be sold only through a priced topic. The overview shows paid courses, enrolled learners, Faith sales and a reminder if a published series has no price. Payments appear in the normal Payments screen (type "faith"), with promo codes working as for courses.

Statuses: **Draft** (hidden), **Published**, **Archived** (hidden). Managers can preview drafts on the website (marked "Preview", not indexed by search engines).
To publish, a lesson needs content for its main format (video/audio file or link, reading text, or study material/text).

## Instructors (tutors) and payouts
- Each series can have an **Instructor** (set by an admin under Faith: Series). The series page shows "Taught by ...".
- Every approved sale of that series credits the tutor with the same revenue share as course sales (Payout settings), in the same earnings ledger. A refund reverses it. Tutors see these sales under **My earnings**, request payouts as usual, and admins see them under Tutor earnings and Payout requests. A series with no instructor earns nothing for any tutor.
- Tutors with the Instructor role get **Faith: Lessons** and **Faith: Series** in their menu. They can create series (saved as draft, assigned to them) and create or edit lessons **only inside their own series**, including uploads. **Tutors set the price** (and lifetime/limited access) of their own courses. They cannot publish, archive, feature, assign instructors or touch other tutors' content. Admins with faith.manage are told when a tutor creates a series or lesson, or changes a price, and publish the course.
- Tutors can delete their own drafts only.

## Teachers and per-division tutor rates
- **Add a teacher:** Faith overview > **Teachers** panel > **+ Add a teacher** (opens the normal new-user form with the role *instructor* preselected). Then choose them as the **Instructor** of a series under Faith: Series. The panel lists each teacher's series, purchases, earnings and available balance, and warns about series that have no teacher.
- **Rate:** Tutor payout settings now has the default share (40%) plus an **optional rate for Academic, Income Skills and Faith & Spiritual Growth**. Leave a division blank to use the default; set e.g. 25 for Faith, or 0 if Faith teachers serve without pay. A change affects future sales only (each sale remembers the rate that applied).
- **Reports:** *Tutor earnings* shows money per division and a Faith badge per tutor; the CSV has a column per division; teachers see each sale's division and their rate on *My earnings*.
- **Public:** the Faith page shows **Meet our teachers**, series cards say "Taught by ...", each series page has an **About your teacher** card, and every teacher with a live series has a page at `/faith/teacher/<id>`. Only the name and the **bio** are public (teachers edit their bio under *My account*). Email and payment details are never shown. Headings can be edited under Website text & menus > Faith & Spiritual Growth text.
- **Audio files** now also accept **AAC** and **Opus** (checked by their real content, like the other formats).

## Media
- Video: MP4 or WebM (limit in Site settings), or a YouTube/Vimeo link.
- Audio: MP3, M4A, AAC, OGG or WAV (default 200 MB; Faith settings), or a direct https link.
- Study material: PDF, DOCX, PPTX, XLSX, ZIP or image up to 25 MB; "Let learners download" can be switched off per lesson.
- Large files upload in 4 MB pieces and can resume. Files are stored privately and streamed through the app (with seeking), so members-only lessons cannot be fetched by direct link.
- If you run behind Nginx, make sure `client_max_body_size` is at least 5 MB (chunks) and larger than the largest non-chunked upload you use.

## Technical notes
- Migration `009_faith_topic_prices.sql` adds topic prices and rebuilds `transactions` and `faith_access` again (same safe procedure and checks as 007; back up first).
- Migration `008_faith_instructors.sql` adds `faith_series.instructor_id` and `instructor_earnings.faith_series_id` (both nullable, nothing rebuilt).
- Migration `007_faith_paid.sql` adds the series price columns and the `faith_access` table, and rebuilds the `transactions` table (all existing payments, receipts, entitlements and earnings are copied across and checked; the runner switches foreign keys off just for this file and refuses to commit if anything would be left broken). **Back up the database before deploying, as for any upgrade.**
- Migration `006_faith.sql` adds `faith_topics`, `faith_series`, `faith_items`, `faith_progress`, `faith_saved`; rebuilds the small `uploads` table to allow audio; and adds "Faith" to an existing saved header menu and footer (only if you have not emptied them). Nothing is deleted.
- Code: `dagba/services/faith.py`, `dagba/blueprints/faith.py` (public), `dagba/blueprints/faith_admin.py` (admin), templates in `templates/faith/` and `templates/staff/faith_*.html`, scripts `static/js/faith.js` and `faith_editor.js`, tests in `tests/test_faith.py`.
- `python manage.py seed-demo` adds three clearly labelled **[DEMO]** prayer lessons so you can try it. Delete them from Faith: Lessons.
- No Bible text is bundled. Paste scripture you are licensed to use, or give references only.

## Topic icons and images (optional)
Admin > Faith > **Edit topic** (or **+ Add a topic**) has a **Topic icon** picker (12 built-in icons) and a **Topic image** upload. Both are optional; a topic with neither looks exactly as before. A topic shows an uploaded image **or** an icon: uploading an image clears the icon, and choosing an icon replaces the image. Tick **Remove the current image** to clear it. The visual appears on the topic's card on the Faith page and the homepage Faith section. Images use the normal upload system (resized, stored in the public media folder).

## Tutor topic assignment and lesson review
- **Assign topics (admins with faith.manage):** Faith > **Tutors** lists every tutor with their assigned topics. Click a tutor to tick the topics they may write lessons in, or click a topic (under *By topic*) to assign it to several tutors at once. Unticking revokes. Every change is in the Activity log and the tutor is notified.
- **What an assignment does:** it **adds** the right to create lessons (without a series) in that topic. It never replaces or removes anything a tutor already has: their own series, their courses, earnings and every other section work exactly as before. Assignments are enforced on the server, not just hidden in the menu.
- **Revoking** stops new lessons in that topic and stops the tutor opening that topic's lessons. Nothing is deleted: published lessons stay live, drafts stay in the database, and admins can still edit, approve or publish them. Re-assigning restores access.
- **Review flow (all tutor lessons, including those in their own series):** the tutor saves a draft, presses **Submit for review** (the lesson needs content first), admins are notified, and an admin presses **Approve & publish** (lessons list, or Status > Published in the editor) or **Return** with a note. Nothing is ever published automatically. While a lesson awaits review the tutor cannot change it (they can **Withdraw** it). Lessons awaiting review are counted in the dashboard's *Items awaiting review* and under Lessons > *Awaiting review*.
- **Technical:** migration `014_faith_tutor_topics.sql` adds the `faith_topic_tutors` table and three nullable columns on `faith_items` (`submitted_at`, `review_note`, `reviewed_at`). A lesson is awaiting review when `status='draft'` and `submitted_at` is set, so the existing status values and their database check are unchanged.
