# Deployment (any host: VPS, cPanel-with-Python, Docker, PaaS)
No provider is assumed. Needs: Python 3.11+, a persistent disk for the SQLite file and uploads, HTTPS.

## A. Linux VPS (systemd + nginx)
```bash
sudo useradd -r -m dagba && sudo mkdir -p /opt/dagba /var/lib/dagba && sudo chown -R dagba /opt/dagba /var/lib/dagba
# copy the project to /opt/dagba, then as user dagba:
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-prod.txt
cp .env.example .env   # set SECRET_KEY, SITE_URL=https://..., COOKIE_SECURE=true, TRUST_PROXY=true, DATABASE_PATH=/var/lib/dagba/dagba.db, upload dirs under /var/lib/dagba
.venv/bin/python manage.py migrate && .venv/bin/python manage.py seed && .venv/bin/python manage.py create-admin
```
Install `dagba.service.example` as `/etc/systemd/system/dagba.service`, `sudo systemctl enable --now dagba`, and use `deploy-nginx.conf.example` (add HTTPS via certbot).

## B. Docker
`cp .env.example .env` (edit), then `docker compose up -d --build`; create the owner with `docker compose exec web python manage.py create-admin`. Data lives in the `dagba-data` volume (back it up).

## C. Notes
- Use **one server** (multiple gunicorn workers are fine); SQLite is not for multi-server clusters.
- Always HTTPS in production (`COOKIE_SECURE=true`). Set `TRUST_PROXY=true` only when actually behind a proxy.
- Schedule daily backups and `python manage.py expire-subscriptions`.
- Nginx/Caddy: set `client_max_body_size 26m` (video uploads are sent in 4 MB pieces, so no huge request limit is needed) and keep proxy read/send timeouts at 120s or more. `/static/` may be served directly.
- **Disk & backups:** uploaded videos live in `PRIVATE_UPLOAD_DIR` and count toward disk and the backup ZIP. Plan storage (e.g. 100 lessons x 150 MB = 15 GB). Videos are streamed straight from disk by the app (HTTP Range); for very large audiences put a CDN or dedicated video host in front later.
