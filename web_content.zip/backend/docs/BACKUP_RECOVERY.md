# Backup & recovery
**What to back up:** the database file **and** the upload folders (`PRIVATE_UPLOAD_DIR` has payment receipts; `PUBLIC_UPLOAD_DIR` has images) and your `.env`.

**Easiest:** Admin > *Backup & export* downloads one ZIP containing a consistent database snapshot + all uploads. Keep it private (it contains student data and payment receipts).
**Command line:** `python manage.py backup /path/dagba-backup.db` (database only; also copy the upload folders).
**Automate (cron, daily):**
```
0 2 * * * cd /opt/dagba && .venv/bin/python manage.py backup /backups/dagba-$(date +\%F).db && rsync -a instance/private instance/public /backups/uploads/
```
Copy backups **off the server** (another machine/cloud storage). Test restores occasionally.

**Restore / migrate to a new host**
1. Install the app on the new server (INSTALL.md) but do not create an admin.
2. Stop the app. Unzip the backup: put `dagba.db` at `DATABASE_PATH`, `private/*` into `PRIVATE_UPLOAD_DIR`, `public/*` into `PUBLIC_UPLOAD_DIR`.
3. Copy your `.env` (keep the same `SECRET_KEY` if you want existing logins to remain valid).
4. `python manage.py migrate` (applies any newer migrations), then start the app.
5. Update `SITE_URL`, point DNS, re-register gateway webhooks if used.
