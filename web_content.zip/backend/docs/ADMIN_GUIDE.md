# Admin guide (no coding needed)
Log in -> **Dashboard**. The left menu shows only what your role/permissions allow.

| Task | Where |
|---|---|
| **Organise the Academic section (Basic / Advanced / Professional), add or hide subjects, review migrated courses** | **Academic structure** |
| **Create or edit a whole course (details, lessons, video upload, quiz) on one page** | **+ New course** / **Course catalog > Edit** |
| See every course, filter, publish/unpublish/archive, export | **Course catalog** |
| Categories, assignments, announcements (separate small lists) | Categories, Assignments, Course announcements |
| Prices, access period, subscription eligibility, featured | Course form (admin-only fields) |
| Subscription plans / promo codes | Subscription plans, Discounts & promo codes |
| Verify payments, export CSV | Payments |
| Bank details / payment methods | Bank transfer, Payment methods |
| **Every word on the public site: homepage sections, headings, buttons, menus, footer, page titles, messages** | **Website text & menus** (11 editor screens, one index page) |
| Hero headline/buttons, show or hide each homepage section | Homepage |
| Logo, browser-tab icon, brand colours | Branding (upload the logo; it also appears on certificates) |
| Contact details, social links, academy name | Site settings |
| Search description | SEO |
| Certificate heading and lines | Certificates settings |
| Wording of payment-page messages and notifications students receive | Website text & menus > Payment page & notifications |
| About / Privacy / Terms / Refund pages, and **brand-new pages** (appear at /p/your-page; add them to the menu in Menus & footer) | Pages |
| FAQs, testimonials (publishable only if *verified*) | FAQs, Testimonials |
| Blog / nuggets (writers submit, admins approve) | Blog articles, Blog categories, Academy nuggets |
| Staff and students, roles, permissions, reset links, deactivate | Users |
| Review assignments | Submissions |
| **Tutor withdrawal requests: pay a tutor and upload the receipt** | **Payout requests** (needs the *payouts.manage* permission) |
| Who earned what, how much the school keeps | **Tutor earnings** |
| **Change the website's colours, fonts and overall look** | **Theme & colours** (needs *settings.manage*; see `THEME.md`) |
| **Influencers / affiliates: add, remove, set the commission %, pay their withdrawals** | **Affiliates** (needs the *affiliates.manage* permission; see `AFFILIATES.md`) |
| Tutor share % / minimum withdrawal / switch withdrawals on or off | **Payout settings** |
| Revoke/reinstate certificates (reason required, audited) | Certificates |
| Announce to students/subscribers | Announcements |
| Everything that happened | Audit log |
| Backup | Backup & export |

**Roles:** *student*; *instructor* (own courses, lessons, quizzes, assignments, feedback, learners); *writer* (own articles/nuggets, submit for approval, cannot publish); *admin* (owner has everything; other admins only the permissions the owner ticks on their user page).
**Video lessons:** upload MP4 or WebM straight from the Course builder (stored privately on your server and streamed only to students who have access; seeking and resume-where-you-stopped work). Or paste a YouTube/Vimeo link. PDFs/DOCX/PPTX/XLSX/ZIP can be attached as downloadable files.
**Video tips for Nigerian connections:** export as MP4 (H.264 video, AAC audio), 720p, about 1-2 Mbps: a 10-minute lesson is then ~100-150 MB and plays smoothly on mobile data. Browsers cannot play every format (e.g. .mov/.avi/.mkv are refused). The upload limit (default 500 MB per video) is set under **Site settings**.
**Lesson/quiz order:** use the *Order* numbers (smaller first).

## Faith & Spiritual Growth
Managed from the **Faith** items in the admin menu (overview, lessons, topics, series, settings). Full guide: `docs/FAITH.md`.

## Website text & menus: how it works
Open **Website text & menus**. Pick a screen (Menus & footer, Homepage text, Page headings & messages, Payment page & notifications, plus Homepage, Branding, Site settings, SEO, Certificates, Pages, FAQs). Each box shows the wording **currently on the site**; change it and press *Save settings*: it is live immediately.
- **Menus** are lists, one item per line: `Label | /page` or `Label | https://link`. Unsafe links (e.g. `javascript:`) are refused.
- **Cards/steps** on the homepage are also one per line: `Title | Text` (intro cards: `Title | Text | /link | Link label`).
- `{name}` is replaced with your academy name; `{item}` / `{reason}` work in notification texts.
- **Clearing a box hides that text.** To go back to the original wording, paste the original back (see `dagba/services/content.py`, which lists every default).
- Text you type is always shown safely (it cannot inject scripts). Formatting is plain text; long-form pages and articles support `## headings`, `**bold**`, `- lists`.
- Every change is recorded in the Audit log. Only users with the *settings.manage* permission (the owner by default) can edit.

## Tutor earnings and withdrawals
- **The rule:** when a student's payment for an **individual course** is approved, the course's tutor is credited **40%** of what the student actually paid (after any discount) and the school keeps 60%. Change the percentage in **Payout settings**; a change affects **future sales only** (every sale remembers the percentage that applied). **Subscriptions are not split** (they are not tied to one course), so the school keeps them. Courses with no tutor assigned earn nothing for any tutor.
- **Tutors** open **My earnings** to see each purchase (date, course, the student's first name and initial, amount paid, their share), their totals (earned, paid to them, waiting, available), and to request a withdrawal. They can only request money they have **actually earned**; one open request at a time; they save their bank details first.
- **You pay them:** a request appears under **Payout requests** (you get a notification and a counter). Open it, send the money from your banking app to the account shown, then **upload the transfer receipt** (JPG/PNG/PDF), tick the confirmation and press **Mark as paid**. The request **cannot be completed without a receipt**. The tutor is notified and can open the receipt. To refuse, give a reason; the money returns to their available balance.
- **Refunds:** refunding a student's payment (Payments > refund) takes the tutor's share back. If the tutor has already been paid, their balance goes negative and is offset by future earnings.
- **Permissions:** give staff *payouts.manage* (Users > the person > permissions) to let them handle payouts. Nobody can decide their own request (the owner excepted).
- When you upgrade an existing site, sales approved earlier are credited to tutors once, at 40%, so check **Tutor earnings** afterwards.

## The Academic section: Basic, Advanced, Professional Development
Academic courses live in one of three categories, each with its **own subjects**:
- **Basic: Secondary School Education.** Subjects such as Mathematics, English Language, Physics, Chemistry, Biology, Economics, Government, Literature in English, Agricultural Science, Further Mathematics, Civic Education. (JSS1-SS3 classes are no longer used: courses are organised by subject.)
- **Advanced: University-Level Education.** Its own subject list (Mathematics, Physics, Chemistry, Biology, Economics, Accounting, Computer Science, Statistics, Engineering, Business Administration, Political Science, Law, ...). **Physics can exist under both Basic and Advanced**: they are separate subjects with separate courses.
- **Professional Development.** Shows **"Programs Coming Soon"** until you publish a first professional course. Nothing is pre-filled.

**Uploading a course:** in **+ New course** choose *Division: Academic*, then the **Academic category** (Basic / Advanced / Professional Development), then the **Subject**. The course appears automatically at Academic > category > subject. A subject is required to publish Basic and Advanced courses (drafts may omit it); for Professional it is an optional *programme area*. Income Skills courses work exactly as before.
**Managing subjects:** **Academic structure** shows the three categories and their subjects; **+ Add subject** (or *programme area* under Professional), edit, hide, reorder. A subject that has courses cannot be moved to another category until its courses are moved; removing a subject keeps its courses and flags them for review.
**Launching Professional programmes later (no coding):** (1) optionally add programme areas under Professional (for example a body of examinations), (2) upload courses with category *Professional Development*, (3) publish. The "Coming Soon" message disappears automatically and the programmes are listed; set the wording under **Website text & menus > Academic section text**.
**After the upgrade:** existing academic courses were kept and moved to **Basic**. Those already in a standard subject were classified automatically; any that could not be matched with certainty are listed under **Academic structure > Courses to check** (and in the catalog with a *Needs review* badge). They stay visible to students meanwhile; choose the right category and subject for each. Enrolments, purchases, progress and lessons were not touched. Subscriptions are unchanged: the **Academic subscription still covers every academic course** (Basic, Advanced and Professional).


## Dashboard navigation (Parent menu > submenu > page)
Every dashboard now uses one grouped, collapsible sidebar (`dagba/services/navigation.py`). Parent menus open to reveal their submenus; the active parent and page stay highlighted. Each role sees only what its permissions allow (the pages still enforce their own checks).

**Learning paths are separate.** Faith, Basic, Advanced, Professional and Income Skills each have their own submenu (Overview, Subjects/Categories, Courses, Topics, Lessons, Assignments, Quizzes, Students / Enrolments, Resources, Course announcements). The chosen path travels with every link as `?ctx=<path>` and is enforced in SQL (`dagba/services/paths.py`):
- lists show only that path's records; opening, editing or deleting a record from another path returns 404;
- new subjects and courses created inside a path are forced into that path (the form no longer offers division/level);
- lessons, topics, quizzes, assignments and announcements can only be attached to a course of the same path, and the course pickers list only that path's courses;
- Faith topics/series exist only under Faith.
Courses saved before academic levels existed (no level) count as Basic, exactly as before. Old direct URLs without `?ctx=` still work and show everything, as before.

No database changes were made.


## Subject pricing (Basic, Advanced, Professional Development)
All three are sold by subject. In **Academic structure** choose Basic, Advanced or Professional, then **+ Add subject**: name, description, cover image, subject price, *Show on the homepage*, and Active. Use **Courses** on a subject to tick the courses it contains: one purchase unlocks all of them (and any added later). Prices can also be changed on **Prices & subscriptions**. Students pay by manual bank transfer as before; approve the payment under Payments and the whole subject unlocks. Income Skills courses stay individually priced. Subscriptions remain separate: Basic, Advanced and Income never unlock each other, and Professional Development has none.


## Homepage Intro Cards: icons and carousel
- **Change an icon:** Admin > Appearance > **Intro card icons**. Each intro card is listed with a live preview. Press **Change icon**, search the Lucide library (names and keywords, e.g. "money", "church", "laptop"), click an icon and watch the preview update, then **Save icons**. It is stored in the database and is live on the homepage immediately and after every refresh. **Use default** resets one card; **Restore default icons** resets all of them to the original icons.
- **Card wording and links** are still edited under Website text & menus > Homepage text. The icon is kept in an optional 5th part of each line (`Title | Text | /link | Link label | icon-name`), so it stays with its card when you reorder or reword cards. Leave it out for the original automatic icon.
- **How visitors see it:** phones show one card at a time (swipe, dots, auto-slide every 4.5 seconds, paused while touching or hovering); tablets show two; desktops show three with arrows and subtle hover lift. A section with fewer cards than fit simply shares the row. Visitors who prefer reduced motion get no auto-sliding and no animations. The section is switched on/off under Appearance > Homepage ("Show intro section").
- **Icon library:** a 180-icon Lucide subset in `dagba/static/icons/lucide-subset.json` (ISC licence, see `LICENSE-lucide.txt` beside it). To offer more icons, add entries to that file (`n` name, `k` search keywords, `s` inner SVG markup); no code change or new dependency is needed.
