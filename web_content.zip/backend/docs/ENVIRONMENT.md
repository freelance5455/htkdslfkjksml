# Environment variables
Set as real environment variables, or in a `.env` file beside `manage.py` (real variables win). See `.env.example`.

| Variable | Purpose | Default |
|---|---|---|
| `SECRET_KEY` | Signs sessions. **Set a long random value in production.** If unset, one is generated and stored in `instance/.secret_key`. | auto |
| `SITE_URL` | Public base URL (certificates QR, sitemap, canonical links, gateway callbacks) | `http://localhost:5000` |
| `COOKIE_SECURE` | `true` when using HTTPS (also enables HSTS) | false |
| `TRUST_PROXY` | `true` behind nginx/Caddy so client IPs are correct for rate limiting & audit | false |
| `DATABASE_PATH` | SQLite file | `instance/dagba.db` |
| `PRIVATE_UPLOAD_DIR` | Payment receipts, assignments, lesson resources (never served directly) | `instance/private` |
| `PUBLIC_UPLOAD_DIR` | Re-encoded thumbnails/article images | `instance/public` |
| `MAX_UPLOAD_MB` | Hard request-size ceiling | 25 |
| `SMTP_HOST/PORT/USER/PASSWORD/FROM` | Optional email. Without it, everything still works (in-app notifications; admin can generate password-reset links). | unset |
| `PAYSTACK_SECRET_KEY`, `FLUTTERWAVE_SECRET_KEY`, `FLUTTERWAVE_WEBHOOK_HASH` | Optional gateway secrets (override dashboard values) | unset |
| `ADMIN_EMAIL/NAME/PASSWORD` | Non-interactive `create-admin` | unset |
| `PORT` | Dev server port for `manage.py run` | 5000 |
