# Host Dagba Digital Academy on your Android phone (Termux)

**Time:** about 30-40 minutes the first time. **You need:** an Android phone (Android 8+, 4 GB RAM and 5 GB free space recommended), internet, and the file `dagba-digital-academy-complete-source.zip`.

> **Be realistic.** A phone is great for **testing, demos and a small pilot**. It is not a reliable server: it can sleep, lose signal, overheat, run out of battery or be restarted by Android. Mobile data also costs money. When you start taking real students and real payments, move the site to a small cloud server (your backup restores there in minutes: see Part F). Until then, follow the safety tips in Part H.

I could not run Termux while writing this, so the commands follow Termux's documented behaviour; everything the scripts do (syntax, starting the website, reading the settings file) was checked on a computer. If a step fails, see Part G.

---
## Part A: Get ready (once)

### Step 1: Install Termux the right way
Do **not** use the Google Play version (it is outdated and broken).
1. Install **F-Droid** from https://f-droid.org (allow your browser to install apps when asked).
2. In F-Droid search and install: **Termux** and, optionally, **Termux:Boot** (starts the site after a restart) and **Termux:API**.
3. Open Termux once. You will see a black screen with a `$`. That is where you type commands.

### Step 2: Stop Android from killing Termux
1. **Settings > Apps > Termux > Battery** > choose **Unrestricted** (wording varies: "Don't optimise" / "No restrictions").
2. Pull down the Termux notification and tap **Acquire wakelock** (or the scripts do it for you).
3. Android 12-14 can silently stop background programs. If you can: **Settings > Developer options > Disable child process restrictions** (Android 14+). On Android 12/13 this needs a one-time computer command; see Part G.
4. Keep the phone **plugged in** and cool (not under a pillow, not in the sun).

### Step 3: Let Termux read your Downloads folder
In Termux type, then tap **Allow** when asked:
```
termux-setup-storage
```

---
## Part B: Install the website

### Step 4: Put the project on the phone
1. Download `dagba-digital-academy-complete-source.zip` to your phone (it lands in **Downloads**).
2. In Termux type these lines one at a time:
```
pkg install -y unzip
cp ~/storage/downloads/dagba-digital-academy-complete-source.zip ~/
cd ~
unzip -o dagba-digital-academy-complete-source.zip
ls ~/dagba
```
You should see files like `manage.py`, `README.md`, `scripts`.

### Step 5: Run the one-command setup
```
bash ~/dagba/scripts/termux-setup.sh
```
It will: update Termux (if it asks about configuration files, just press **Enter**), install Python and the libraries, create private data folders in `~/dagba-data`, create your settings file with a random secret key, create the database, and finally ask you to **create the owner account**:
- **Owner email**: the email you will log in with.
- **Owner full name**: your name.
- **Password**: at least 8 characters with letters and numbers. (You will not see it as you type: that is normal.)

This takes 10-20 minutes on a phone. Wait for **DONE**.

### Step 6: Start the website
```
bash ~/dagba/scripts/termux-start.sh lan
```
Open your phone's browser (Chrome) and go to:
```
http://localhost:8000
```
You should see the Dagba homepage. Log in at `/login` with your owner email and password, then follow the "First steps as owner" in `README.md` (bank details, plans, courses).

Useful: `bash ~/dagba/scripts/termux-stop.sh` stops it. `tmux attach -t dagba` shows it running (leave with **Ctrl+B** then **D**; on Termux's keyboard Ctrl is the key above Shift).

### Step 7: Open it from other devices on your Wi-Fi (optional)
1. Find your phone's address: **Settings > Wi-Fi > (your network) > IP address**, e.g. `192.168.1.23`.
2. On another phone/laptop on the **same Wi-Fi**, open `http://192.168.1.23:8000`.
3. If it doesn't open, your router may have "client isolation"/"AP isolation" turned on, or you are on a guest network.
Only use `lan` mode on a Wi-Fi you trust: anyone on that network can reach the site.

---
## Part C: Put it on the internet (so students can reach it)
Home internet and mobile data usually don't let outsiders connect directly to your phone. Use a **Cloudflare tunnel**: a free, secure connection that gives your site an https address. Both options use `cloudflared`, already installed by Step 5.

### Option 1: Quick test address (free, no domain, changes each restart)
```
bash ~/dagba/scripts/termux-start.sh quick
```
After about 10 seconds it prints an address like `https://random-words.trycloudflare.com`. Open it on any device. Then tell the site its address:
```
nano ~/dagba/.env
```
Change these three lines (use the arrow keys; **Ctrl+X**, then **Y**, then **Enter** saves):
```
SITE_URL=https://random-words.trycloudflare.com
COOKIE_SECURE=true
TRUST_PROXY=true
```
Restart with `bash ~/dagba/scripts/termux-start.sh quick`. **Remember:** the address changes every time you restart, so certificate QR codes and links would break. Use this for demos only.

### Option 2: Your own permanent address (recommended)
You need a **domain name** (for example `dagbaacademy.com`, bought from any registrar) added to a free **Cloudflare** account (https://dash.cloudflare.com: "Add a site", choose the Free plan, and change your domain's nameservers as Cloudflare instructs).
1. In Cloudflare open **Zero Trust** (left menu) > **Networks** > **Tunnels** > **Create a tunnel** > **Cloudflared**. Name it `dagba`.
2. On the "install connector" page, find the long **token** (the very long text after `--token`). Copy only that text.
3. In Termux, save it privately (paste with a long-press):
```
nano ~/.dagba-tunnel-token
chmod 600 ~/.dagba-tunnel-token
```
4. Back in Cloudflare, on the tunnel's **Public hostname** tab add: Hostname `www.yourdomain.com`, Service type **HTTP**, URL `localhost:8000`. Save.
5. Tell the site its address (`nano ~/dagba/.env`):
```
SITE_URL=https://www.yourdomain.com
COOKIE_SECURE=true
TRUST_PROXY=true
```
6. Start it:
```
bash ~/dagba/scripts/termux-start.sh tunnel
```
Open `https://www.yourdomain.com`. (Cloudflare's menus are renamed from time to time; look for "Tunnels" under Zero Trust or Networks.)

---
## Part D: Keep it running

| What | How |
|---|---|
| Is it up? | `curl -I http://localhost:8000` (look for `200`) |
| See logs | `tail -n 50 ~/dagba-data/logs/web.log` and `tunnel.log` |
| Stop / start | `bash ~/dagba/scripts/termux-stop.sh` / `termux-start.sh tunnel` (or `lan`, `quick`) |
| Start automatically after the phone restarts | Install **Termux:Boot**, open it once, then:<br>`mkdir -p ~/.termux/boot`<br>`cp ~/dagba/scripts/boot/dagba ~/.termux/boot/dagba`<br>`chmod +x ~/.termux/boot/dagba` |
| After editing `.env` | Run the start script again |
| Forgot owner password | `cd ~/dagba && . ~/dagba-env/bin/activate && python manage.py create-admin` (same email = new password) |

---
## Part E: Backups (do this on day one)
Everything important lives in `~/dagba-data` (database, receipts, videos, images).
- **Back up now:** `bash ~/dagba/scripts/termux-backup.sh`. It saves a database copy and an uploads archive and, if storage access is allowed, copies them to **Download/dagba-backups** on your phone. **Move those files off the phone** (Google Drive, email to yourself, a computer) regularly. A phone backup on the same phone is not a backup if the phone is lost.
- **Automatic daily backup (optional):**
```
sv-enable crond
crontab -e
```
Add this line (then save with **Ctrl+X**, **Y**, **Enter**):
```
0 2 * * * /data/data/com.termux/files/home/dagba/scripts/termux-backup.sh >> /data/data/com.termux/files/home/dagba-data/logs/backup.log 2>&1
```
(Close and reopen Termux once so `crond` starts. The boot script also starts it.)

## Part F: Update the site, or move to a real server later
- **Update and restore your backup in one command** (new ZIP and your `dagba-backups` folder both in Downloads):
```
cd ~ && unzip -oq ~/storage/downloads/dagba-digital-academy-complete-source.zip dagba/scripts/termux-deploy.sh && bash ~/dagba/scripts/termux-deploy.sh
```
It checks the backup first, stops the site, deploys the new files, restores the newest backup (database and uploads; a safety copy of the current database is kept in `~/dagba-data/backups`), runs the migrations on the restored database, and starts the site. Add `--yes` to skip the confirmation, `--no-restore` to deploy without restoring, or `tunnel` / `lan` / `quick` to choose how it starts.
- **Update only:** download the new ZIP, then:
```
bash ~/dagba/scripts/termux-stop.sh
cp ~/storage/downloads/dagba-digital-academy-complete-source.zip ~/
cd ~ && unzip -o dagba-digital-academy-complete-source.zip
chmod +x ~/dagba/scripts/*.sh
bash ~/dagba/scripts/termux-start.sh tunnel
```
Your `.env` and `~/dagba-data` are not touched, and the database upgrades itself.
- **Move to a cloud server:** follow `docs/DEPLOYMENT.md` there, then restore your backup using `docs/BACKUP_RECOVERY.md`.

---
## Part G: Troubleshooting
| Problem | Fix |
|---|---|
| `termux-setup.sh: No such file` | Step 4 not done: `ls ~/dagba/scripts` must list the scripts. |
| pip says "failed building wheel" | `pkg install -y clang make` then run the setup script again. |
| `Permission denied` on storage | Run `termux-setup-storage` and tap Allow. |
| Site works on the phone but not other devices | Use `lan` mode, same Wi-Fi, check the phone's IP, router AP isolation (Step 7). |
| Site stops after the screen turns off / after a while | Battery set to Unrestricted (Step 2), wakelock on, phone plugged in. On Android 12-13 the "phantom process killer" may stop it: connect the phone to a computer with USB debugging and run `adb shell "settings put global settings_enable_monitor_phantom_procs false"` (and `adb shell device_config set_sync_disabled_for_tests persistent` on Android 12L+/13 if it keeps happening). |
| Tunnel does not connect | Try the `cloudflared` line with `--protocol http2` added (edit `termux-start.sh`), check data/Wi-Fi works, or wait a minute and restart. |
| Login loops / "Security check failed" after going online | `.env` must have the correct `SITE_URL` (https) and `COOKIE_SECURE=true`, `TRUST_PROXY=true`; then restart. Always open the site using that exact address. |
| "500 Something went wrong" | Note the reference code; owner: **Admin > Audit log** and search `error.500`. See `docs/TROUBLESHOOTING.md`. |
| Port already in use | `bash ~/dagba/scripts/termux-stop.sh` then start again. |
| Phone full | `df -h ~` to check; delete old backups in `~/dagba-data/backups`; lower the video limit (Part H). |

## Part H: Settings and habits that suit a phone
- **Videos:** in the website go to **Site settings** and set *Maximum lesson video upload size* to about **100-150 MB**, and ask instructors to upload 720p MP4. Check free space often (`df -h ~`).
- **Strong owner password**, lock your phone with a PIN, and do not share `~/.dagba-tunnel-token` or `~/dagba/.env`.
- Don't run `lan` mode on public/shared Wi-Fi.
- Keep Termux updated occasionally: `pkg update && pkg upgrade -y`, then restart the site.
- For manual bank-transfer payments nothing changes: students upload receipts; you confirm the money in your bank app before approving.
- Plan to move to a cloud server as soon as the academy has regular students.
