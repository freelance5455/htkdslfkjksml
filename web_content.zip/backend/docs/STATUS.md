# Project status, deviations and known limitations
Written honestly so you know exactly what you are getting.

## Delivered and automatically tested (183 tests, all passing, including a crawl that hits every page and form as every role with hostile input and requires zero server errors)
Registration/login/logout, password recovery, rate limiting, CSRF, role & permission enforcement (incl. privilege-escalation attempts), course/lesson/quiz/assignment management, access rules, lesson completion, progress persistence and resume across devices, quizzes (server-graded), assignments + feedback, certificates (PDF + QR, eligibility, public verification, revocation), blog/nuggets/testimonials workflows (writer approval, scheduling, verified-only testimonials), notifications, announcements, backup download, security headers, upload validation (magic bytes, extension match, size, private storage, access-controlled receipt viewing), and **all 20 manual-payment acceptance scenarios** (pending never grants access; approval grants exactly the purchased item once; reject/info-request flows; unauthorised and self-approval blocked; settings editable and respected; reports separate pending from confirmed; audit trail). Gateway *logic* is tested with stubbed provider responses (signature checks, idempotency, amount/currency mismatch, failure never grants).
A real HTTP end-to-end run (curl against a live server) also confirmed: register -> checkout -> receipt upload -> blocked access -> owner approval -> access granted -> duplicate approval refused.

## Animation
Homepage extras: rotating subject word, floating subject chips with scroll parallax, subject ticker, real-number counters (only shown when there are published courses), a progress line through *How it works*, heading underline sweeps, 3D card tilt and cursor spotlight on mouse devices, shine on the main button; all off under reduced-motion. Lightweight, dependency-free motion (CSS transforms/opacity + `static/js/anim.js`, ~70 lines): page fade-in, staged hero entrance with drifting gradient and floating glows, scroll-reveal with staggered cards, hover lift and image zoom (hover devices only), button press feedback, animated mobile menu, sticky-header shadow, reading-progress bar on long text pages, progress bars that fill, dashboard integer counters, smooth flash messages, notification-dot pulse, soft page-leave fade and native View Transitions where the browser supports them. Everything respects `prefers-reduced-motion` (all motion off, content fully visible) and content stays visible if JavaScript is disabled. Verified in headless Chromium: no console/CSP errors, no horizontal overflow. To tone it down or disable, edit the `/* Motion */` section of `app.css` or remove the `anim.js` script tag from `base.html`.

## Course builder, direct video upload and catalog
- One-page **Course Builder**: details, price/access, modules and lessons, direct video upload, attachments, optional quiz, save as draft or publish (instructors submit for review). Editing preserves learner progress; removed lessons' files are deleted; ids from other courses cannot be hijacked; an upload can only be attached by the user who made it.
- **Direct video upload**: MP4/WebM, validated by file signature, **resumable 4 MB chunks** (tested with a simulated dropped connection), per-video limit configurable (10 to 2000 MB, default 500). Stored privately and streamed with Range support only to entitled learners / free previews / the course's staff; resume position saved.
- **Course catalog** for admins (all courses) and instructors (own): stats, filters, publish/unpublish/archive, CSV export, revenue only for users with `reports.view`.
- Verified in a real browser end-to-end (multi-chunk upload, drop/resume, publish, catalog, student playback, seek, resume). Headless Chromium here has no H.264 decoder, so *playback* was verified with WebM; MP4 is served by the identical code path and byte-range behaviour is unit-tested, and H.264 MP4 plays in all mainstream phone/desktop browsers.
- Limits: no server-side transcoding/compression (upload sensible 720p H.264 MP4); no built-in video DRM (a determined student can still screen-record); no CDN. Assignments are still managed in their own menu, not inside the builder.

## What the admin can and cannot edit without code
**Editable in the dashboard:** courses (incl. videos, quizzes, prices, access), categories, plans, promo codes, blog, nuggets, testimonials, FAQs, pages (edit and create), all homepage sections (text, cards, steps, show/hide), hero, header menu, footer links/headings, every public page heading and message, button labels, login/sign-up/checkout wording, payment-page wording, student notification wording, logo, favicon, colours, contact details, social links, SEO description, certificate wording and signatory, bank details, payment methods, staff and permissions.
**Still in the source code (not in the dashboard):** the layout/design of pages (HTML/CSS) and of the certificate PDF; labels inside the dashboards themselves (student/instructor/admin menus, table headers, form labels, buttons such as Save); system error and validation messages (e.g. "Incorrect email or password"); the password-reset email text; the 404/403 pages; the privacy/terms/refund wording is editable but supplied only as templates for your lawyer. These are application interface rather than website content; they can be changed in `dagba/templates/` and `dagba/blueprints/` by a developer. If you want any of them exposed for editing, add the key to `dagba/services/content.py`.

## Image uploads (blog, nuggets, course covers, logo)
Accepts JPG/PNG/WebP up to 15 MB (larger phone photos are fine), re-encodes to a web-friendly size, straightens phone photos using their rotation data, and shows a clear message (never an error page) for damaged/incomplete files, images with absurd pixel dimensions, or unsupported formats such as iPhone HEIC. If a server's Pillow lacks WebP support it falls back to JPEG/PNG automatically.

## Homepage extras added later
Testimonials appear in a swipeable, auto-playing carousel (arrows, dots, keyboard, pauses on touch/hover/off-screen; fully usable with JavaScript off or reduced-motion). Article cards show the post's featured image (lazy-loaded, fade/zoom-in, graceful placeholder) on both the homepage and the blog page.

## Tutor earnings and payouts
Per-sale ledger (40% default, snapshot per sale, idempotent, reversed on refund), tutor Earnings page, withdrawal requests limited to earned balance, admin queue with mandatory receipt upload, notifications, CSV exports, permission `payouts.manage`, settings (percentage, minimum, on/off). Tested including duplicate approvals, refunds after payout, race/double-submit, permissions and receipt access, and a real-browser run of the whole flow.
Limits: one global percentage (not per tutor or per course); subscriptions are not shared with tutors; withdrawals are paid manually by the admin (no automatic bank payout); no tax/withholding handling; tutors see students' first name and last initial only.

## Academic restructure (Basic / Advanced / Professional Development)
Academic subjects and courses now carry a level; JSS/SS course classification was removed from the course builder, filters, cards and catalog; new public pages (Academic landing, Basic/Advanced subject lists, subject pages, Professional Development "Programs Coming Soon"); admin **Academic structure** page; builder, catalog and category forms updated. Migration 004 preserves everything (verified against an old-format database full of enrolments, progress, purchases and lessons), classifies existing courses into Basic, flags uncertain ones for review, and never deletes or duplicates records. Income Skills, payments, subscriptions, authentication and the other dashboards are unchanged (the `academic` division is the same, so entitlements work as before).
Notes: the student *profile* "class/level" field (used only for the learner's own profile) was left alone; a custom About/Home text you edited earlier is not rewritten (only the exact old sentence in the seeded About page is updated); the Advanced subject list is a starting set you can edit.

## Deviations from the brief
1. **Stack.** The brief preferred React/Next.js + Node + PostgreSQL + Tailwind. The build sandbox had **no internet access** (no `npm install`, no PostgreSQL), so that stack could not be installed or tested. I built with Python/Flask + SQLite + server-rendered templates + hand-written CSS, which I could run and test. It is a standard, editable VS Code project with migrations, lockfile and Docker files. Moving to PostgreSQL later means adapting `dagba/db.py` and minor DDL types (not done or tested).
2. **No Tailwind / React.** The UI is server-rendered HTML with a small CSS file and ~30 lines of JavaScript (no framework).
3. **Lockfile** (`requirements.lock`) pins the exact versions tested here (no hashes).

## Not verified here (please test before relying on it)
- **Paystack and Flutterwave live integration**: implemented from public API documentation but never called against real accounts. Treat as *awaiting credentials*; test with provider test keys.
- **Email delivery (SMTP)**: code is best-effort and failure-tolerant but was not tested against a real mail server.
- **Real-device rendering**: layouts were checked in headless Chromium at 375, 768 and 1280 px (public pages, student and owner dashboards, checkout/payment pages): no horizontal overflow after fixes, wide tables scroll inside their own wrapper, and the dashboard menu collapses on phones. This is not a substitute for testing on real Android/iPhone devices and slow connections. Please do that and report issues.
- **Docker image build and gunicorn run**: files provided, but Docker/gunicorn were not available to run in this sandbox.
- **Load/performance**: not load-tested.

## Product limitations (by design for this version)
- Quizzes are single-answer multiple choice. Assignments accept text + JPG/PNG/PDF.
- Video lessons use YouTube/Vimeo/direct-URL links (no built-in video hosting/upload). Resume position is stored for direct video files only.
- Newsletter addresses are collected and listed in admin; the app does not send bulk email.
- Policy pages are **templates, not legal advice**; have them reviewed. Pages can be edited, not created or deleted.
- Subscription "academic" vs "income" are the two divisions; adding a third division requires a code/schema change (categories and courses within divisions are unlimited and admin-managed).
- Demonstration data exists only via the optional `seed-demo` command and is labelled `[DEMO]`. The production seed contains no testimonials, statistics or fake courses.
- Gateway secrets entered in the dashboard are stored in the database in plain text (protect DB/backups) or may be supplied through environment variables instead.

## Homepage hero carousel
- The homepage banner is a database-driven carousel (table `hero_slides`, migration 015; rotation settings `hero.autoplay`, `hero.interval`).
- Managed in Admin > Appearance > Homepage hero (`blueprints/hero_admin.py`, `services/hero.py`): add/edit/delete slides, upload/replace/remove pictures
  (re-encoded to 480/800/1200 px WebP), enable/disable, reorder, choose the first slide, automatic rotation. Needs the `settings.manage` permission.
- Public rendering: `templates/_hero.html`, `static/js/hero.js`, hero block at the end of `static/css/app.css`. Built-in illustrations in `static/img/hero/` are the fallback.
- If every slide is hidden the older single banner (Appearance > Homepage text) is shown. Tests: `tests/test_hero.py`.

## Tutor programme (applications, referral links, commissions, profile pictures)
- **Tutors are `instructor` accounts.** Approval upgrades the applicant's existing student account in place (no second account) and creates a `tutor_profiles` row with a referral code.
- **Applications** (`tutor_applications`, kind `tutor` = become a tutor, kind `course` = extra course from an existing tutor; statuses draft / pending / revision / approved / rejected;
  history in `tutor_application_events`). Public page `/become-a-tutor`; applicant form `/tutor/apply`; materials are authored in the normal Course Builder on a draft course
  that belongs to the application (applicants can open only that course). Every new course is reviewed: tutors' own "submit for review" lands in the same queue,
  and a tutor course can only go live after review: if an administrator publishes a course that is waiting in the queue (catalog button, builder or course form) it is recorded as an approval (`tutors.finalize_publish`); a course that was never submitted cannot be published (`tutors.publish_blocked`).
- **Admin** (permission `tutors.manage`): Tutors > Tutor applications / New course reviews / All applications / Tutors / Tutor transactions. Approve (with adjusted price), request revision,
  reject, suspend/unsuspend. Commission overrides need `payouts.manage` as well.
- **Referrals**: `/course/<slug>?ref=<code>` (also `/courses/<slug>`). Signed 30-day cookie + a per-account record (follows the person across devices); newest link wins; bots ignored;
  self-referral (same account, email or phone) never counts. The order is stamped (`transactions.tutor_ref_id`) when it is created; on payment approval the ledger row is `source='affiliate'`
  (tutor-generated, default 97%) or `source='platform'` (academy-generated, the existing per-division share). Influencer affiliates are never paid on top of a tutor-referred sale.
- **Settings** (Settings > Payouts): tutor-generated share, highest share allowed (97), referral window (30 days), holding period before withdrawal, applications open, referrals on.
  Overrides per tutor (`tutor_profiles`) and per course (`courses.tutor_*_percent`). Priority: course > tutor > default; each ledger row snapshots percent and basis.
- **Balances**: available = cleared earnings - paid - requested; pending = requested withdrawals + earnings still inside the holding period (default 0 days, so behaviour is unchanged).
- **Profile pictures** (`users.avatar`, `services/avatars.py`, `templates/_avatar.html`): optional for every role; JPG/PNG/WebP, 5 MB, re-encoded to a 256 px square WebP, initials as default.
  Users manage theirs under Profile settings; admins under Users > user. Shown in the header, dashboard sidebar, user lists, course instructor box and public tutor page `/tutors/<code>`.
- Tests: `tests/test_tutors.py`.

## Course structure: Academic (Basic, Advanced) | Income Skills | Professional Development
- **Professional Development is its own division** (`courses.division` / `categories.division` = `'professional'`), independent of Academic, like Income Skills. Migration `017_professional_division.sql`
  rebuilds `categories` and `courses` (SQLite cannot relax a CHECK in place) copying every row with the same ids, then moves former "Academic > Professional" areas/courses to the new division
  (level cleared, no subscription). Foreign keys are verified before commit. Nothing is deleted or duplicated (`tests/test_divisions.py::MigrationTests`).
- **Homepage** (all from the database, in this order): Basic *subjects* -> Advanced Courses *subjects* -> Income Skills *courses* -> Professional Development *courses*.
  Each subject appears once (`services/academic.py: subjects/home_subjects`), empty subjects/sections are hidden, subject cards open `/academic/<level>/<subject>` (all published courses of that subject).
  A subject is shown when it is active, ticked "Show on the homepage" (`categories.featured`) and has a published course. Income/Professional show published courses, featured first (up to 12), with a "view all" link.
  Section toggles and titles: Settings > Homepage content / Website text. The old "Featured Courses" title is now "Income Skills" (an untouched default is renamed by the migration).
- **URLs**: `/professional` (new). `/academic/professional` and `/academic/professional/...` redirect (301) there. `/courses?division=academic|income|professional` filters the catalogue. Sitemap lists `/professional`.
- **Admin**: Course structure page (Staff > Academics > Overview) manages subjects for Basic, Advanced and Professional areas; a "Professional Development" menu group mirrors Income Skills; builder, course form,
  catalogue filters and category form offer the three divisions; cross-division categories are refused; old forms that still send "academic + professional" are mapped to the new division.
- **Money**: Professional Development gets its own tutor-share setting; until set it keeps the Academic rate (it used to be Academic), so no rate changes silently.
- **Dashboards**: the admin dashboard shows published courses per group (Basic, Advanced, Income Skills, Professional Development), linking to each path overview; instructors' "My courses" shows each course's division;
  Reports has "Course sales by division" (also in the CSV export); the Basic / Advanced / Income / Professional path dashboards are scoped by the new division rules.


## Subject-level pricing for Basic, Advanced and Professional Development (migration 019)
Basic, Advanced and Professional Development are sold by subject; Income Skills keeps per-course prices. See `docs/PRICING.md` ("Subject pricing for all three divisions").
- Code: `services/access.py` (`subject_of`, `subject_scope`, division-aware `course_access`, `purchased_courses`), `services/payments.py` (subject pricing, grant, return link), `services/academic.py` (`home_subjects`, `category_contents`, `priced_subjects`), `blueprints/pay.py` (`checkout_subject`), `blueprints/public.py` (`_subject_page`, `/professional/<subject>`, price list), `blueprints/staff.py` + `builder.py` (admin rules, prices screen, assign courses), templates `_m.html`, `public/home.html`, `public/academic_subject.html`, `public/professional.html`, `public/pricing.html`, `staff/academic*.html`, `staff/pricing.html`.
- Homepage order is now Basic, Advanced, Professional Development (subject cards with cover image and price), Income Skills (course cards).
- Tests: `tests/test_subject_pricing.py` (admin, homepage, purchase, access, subscription separation, migration); older tests were updated where they encoded the Basic-only rules.


## Division separation (migration 020)
Homepage Income Skills section is `division='income'` + published only (`services/academic.home_income_courses`); course division locked on edit (`services/builder.save_course`, builder page/JS); migration 020 renames stale "Featured" titles, logs and repairs provable division mismatches (`division_repairs`), adds database triggers; `manage.py audit-divisions`. Tests: `tests/test_division_separation.py`.


## Admin-controlled Intro Card icons + animated Intro Cards carousel
- Icons: `services/icons.py` (Lucide subset registry, `intro_cards`, save/reset into the existing `c.home.what_cards` setting as an optional 5th field), route `/staff/intro-icons` (`staffpay.intro_icons`, permission `settings.manage`), `templates/staff/intro_icons.html`, `static/js/intro_icons_admin.js`, menu item under Appearance. No schema change or migration.
- Carousel: the homepage intro section reuses the shared `[data-fcar]` carousel (`_m.html` `carousel(label, cls, delay)`, `static/js/carousel.js`) with the `introcar` modifier (1/2/3 cards per view, 4.5 s delay, entrance animation, hover lift in `app.css`). Also fixed a bug in `carousel.js` where the `focusout` handler had been swallowed by a comment (keyboard focus could pause auto-slide indefinitely).
- Tests: `tests/test_intro_cards.py` (12 unit tests) and optional real-browser tests in `tests/browser/` (`run.sh public|many|admin`; 25 + 44 + 31 checks across phone, tablet, desktop, reduced motion, swipe, overflow and the full admin flow).
