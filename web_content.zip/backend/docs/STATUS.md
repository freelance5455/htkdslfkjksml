# STATUS — ADAM KNOWLEDGE (Backend, Primeira Etapa)

Documento honesto do que está **realmente funcional e testado** versus o
que ainda precisa ser construído. Nenhum item abaixo marcado como concluído
é simulado — tudo foi testado com execução real (ver `docs/TEST_REPORT.md`).

## ✅ Concluído e testado nesta etapa

| Item da especificação (seção) | Status | Onde está |
|---|---|---|
| Arquitetura modular (seção 3) | ✅ Completo | `src/{core,database,research,resources,communication,monitor}` |
| Banco de dados local (seção 8) | ✅ Completo | SQLite nativo, 6 tabelas, migrations versionadas |
| ADAM TASK ENGINE (seção 10) | ✅ Completo | Concorrência, retry, cancelamento, estados reais |
| ADAM KNOWLEDGE CORE (seção 5) | ✅ Completo (núcleo) | Orquestração real; integração de IA é ponto de extensão (ver pendências) |
| ADAM WEB RESEARCH ENGINE (seção 6) | ✅ Completo (núcleo) | Pesquisa real + leitura de páginas reais; provider plugável |
| ADAM RESOURCE LIBRARY (seção 9) | ✅ Completo | CRUD real, arquivos em disco, metadados completos |
| API de comunicação com AddonForge (seção 11) | ✅ Completo | Endpoints do contrato e download binário implementados e testados |
| Segurança básica (seção 12, parcial) | ✅ Parcial | Auth por token (tempo constante), limite de tamanho de requisição, validação de entrada básica |
| Diagnóstico (seção 15) | ✅ Completo | Estados reais, nunca fixos |
| Recuperação de tarefas após reinicialização | ✅ Implementado e testado | Tarefas `processing` voltam para `queued` quando ainda têm tentativas; tarefas no limite viram `failed`; tarefas sem handler aguardam registro |
| CORS e preflight OPTIONS | ✅ Implementado e testado | Lista de origens permitidas configurável por `CORS_ALLOWED_ORIGINS` |
| Download binário da biblioteca | ✅ Implementado e testado | `GET /api/library/:id/file`, autenticado |
| Proteção de caminho/extensão de arquivo | ✅ Implementado e testado | Extensões validadas e caminhos limitados à pasta de recursos |
| Documentação (seção 16) | ✅ Completo | Este conjunto de documentos |
| Testes automatizados (seção 18, item 13) | ✅ Completo | 44 testes, 0 falhas |
| Divisão de pedido em subtarefas (exemplo da seção 6) | ✅ Completo e testado | Request Analyzer reproduz o exemplo exato da especificação |

## ⚠️ Implementado parcialmente (funciona, mas com limitação documentada)

| Item | O que funciona | O que falta |
|---|---|---|
| ADAM IMAGE RESEARCH (seção 7) | Reaproveita a pesquisa web textual; retorna nota explícita de limitação | Motor dedicado de busca de imagens (API de imagens específica, classificação por categoria visual) |
| Extração de texto de páginas (seção 6) | Extração real via regex, funciona para a maioria de páginas de artigo/documentação | Parser DOM completo para páginas com estrutura complexa |
| Provedor de pesquisa padrão (DuckDuckGo HTML) | Funciona sem chave de API | Depende de estrutura de HTML de terceiros — recomendado trocar por API oficial em produção (template já incluso: `generic-api-provider.js`) |
| Validação de entrada da API | ✅ Resolvido nesta etapa: erros de validação (`*ValidationError`) retornam 400 consistentemente, em qualquer camada | Validação ainda mais granular (schema completo por rota) fica para a próxima etapa |
| Modo offline (seção 13) | Funciona naturalmente: consultas ao banco local funcionam sem internet | Não há um "modo" explícito alternado na API — é uma consequência da arquitetura, não um recurso com toggle dedicado |

## ❌ Não implementado nesta etapa (por decisão explícita, conforme seção 18 da especificação)

Estes itens foram **propositalmente adiados para a segunda etapa**, com
contratos e pontos de extensão já preparados para não exigir reconstrução:

- **Análise automatizada de padrões visuais/materiais** (visão
  computacional) — retorna nota explícita de que depende de um motor
  generativo futuro.
- **Integração real com um provedor de IA generativa** — o ponto de
  extensão (`IntelligenceOrchestrator.callAiProvider`) existe e informa
  claramente quando não configurado, mas a chamada real à API do provedor
  ainda não foi implementada.
- **Sincronização remota (`POST /api/sync`)** — responde `501` com mensagem
  clara; a tabela/schema remoto (Postgres) não foi criada nesta etapa.
- **Motores de criação de texturas, modelos, animações e sons** — fora de
  escopo da primeira etapa, por definição da própria especificação.
- **Aplicativo Android** — esta etapa é só o backend (decisão da "opção 3"
  escolhida: backend primeiro, Android depois).

## 🐛 Bugs reais encontrados e corrigidos durante o desenvolvimento

Ver lista completa com detalhes técnicos em `docs/TEST_REPORT.md`, seção
"Bugs reais encontrados e corrigidos". Resumo:

1. Condição de corrida na compilação de resultados de subtarefas.
2. Falso positivo de palavra-chave ("api" dentro de "capital").
3. Cobertura insuficiente de sinônimos ("efeitos sonoros" não reconhecido).
4. Teste com suposição incorreta sobre estado do banco.
5. Timer de teste não limpo, atrasando a suíte.

Todos corrigidos e re-testados antes desta entrega.

## Limitação de ambiente (relevante para auditoria desta entrega)

O ambiente usado para escrever e testar esta primeira versão **não tinha
acesso à internet** para `npm install` ou para pesquisas web reais. Por
isso:

- O núcleo foi construído **sem dependências externas obrigatórias**,
  usando apenas recursos nativos do Node.js 22.
- Os testes de pesquisa web real (contra a internet de verdade) **não
  puderam ser executados no ambiente de desenvolvimento** — foram testados
  com um servidor HTTP local simulando páginas reais (loopback), o que
  valida a lógica de extração/tratamento de erro, mas não substitui um
  teste contra a internet real.
- **Recomendação explícita**: ao rodar este projeto pela primeira vez com
  internet disponível, execute manualmente uma pesquisa real (ex: via
  `POST /api/research` com `WEB_SEARCH_PROVIDER=duckduckgo_html`) e
  verifique os resultados antes de considerar este módulo
  "validado em produção". Isso está listado como ação pendente abaixo.

## Ações pendentes recomendadas antes de considerar esta etapa "pronta para produção"

- [ ] Rodar uma pesquisa web real (com internet) e confirmar que o provider
      DuckDuckGo HTML ainda funciona (estrutura de HTML de terceiros pode
      mudar).
- [ ] Gerar um `ADDONFORGE_TOKEN` forte e único antes de qualquer uso real
      (o `.env.example` vem com um valor de exemplo que **não deve** ser
      usado como está).
- [ ] Integrar o endpoint de download binário ao cliente AddonForge e validar no navegador Android.
- [ ] Configurar `CORS_ALLOWED_ORIGINS` para a origem exata usada pelo AddonForge em produção.
- [ ] Decidir se o roteador HTTP caseiro será mantido ou substituído por
      Express/Fastify assim que `npm install` estiver disponível.
- [x] ~~Revisar os códigos de status HTTP de erro de validação de recursos~~
      — corrigido: erros `*ValidationError` agora retornam 400
      consistentemente (antes retornavam 500).
