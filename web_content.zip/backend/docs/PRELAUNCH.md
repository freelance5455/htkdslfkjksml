# Pre-Launch Mode

A switchable, date-driven gate in front of the whole site (default **OFF**; nothing changes until an admin turns it on).

**Admin > Pre-Launch > Pre-Launch settings** (permission `prelaunch.manage`; the owner always has it):
turn the mode ON/OFF, set launch date, time and time zone (default 4 January 2027, 00:00, West Africa Time), edit every line of the countdown page,
show/hide the countdown, enable/disable email collection and pre-launch account creation, choose which extra roles (instructors, writers) may use the full site.
**Early registrations** lists every collected email and every student account (search, filter, CSV export, remove email-only entries).

How it works
* `services/prelaunch.py: gate()` runs in the app's `before_request` hook on every request. It is active when the switch is ON **and** the launch moment is in the future, so the site opens by itself at the launch time (no cron, no restart) and every admin change applies instantly.
* Administrators always get through (they cannot be locked out); instructors by default. Students and visitors get the countdown page at `/`; every other URL redirects to it (non-page requests get 403 JSON). Allowed for everyone: login/logout/password reset, registration (if enabled), legal pages, static files, the branding images, payment webhooks.
* Early registration: `POST /prelaunch/subscribe` (CSRF, honeypot, rate limit) and `/register` store people in `prelaunch_signups` (unique per email, case-insensitive; an account upgrades an earlier email-only row). Students who register can log in but only see the countdown until launch.
* Migration `022_prelaunch.sql` adds one table; no existing data is touched. Settings are kept in the existing `settings` table (`prelaunch.*`).
* Time zones use a fixed UTC offset chosen in the settings (no tz database needed on the host).
