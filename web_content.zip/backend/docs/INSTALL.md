# Installation

**Requirements:** Python 3.11+ (tested on 3.12), pip. Nothing else (SQLite is built in).

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt          # or requirements.lock for the exact tested versions
cp .env.example .env                     # then edit
python manage.py migrate                 # create/upgrade the database (safe to re-run)
python manage.py seed                    # structural data only; safe to re-run
python manage.py create-admin            # prompts for email, name, password (or set ADMIN_EMAIL/ADMIN_NAME/ADMIN_PASSWORD)
python manage.py run                     # development server on :5000
```
Open VS Code on the folder; the layout is:
```
dagba/               application package
  blueprints/        routes (public, auth, student+learning, pay, staff, staffpay)
  services/          business logic (payments, access/entitlements, lms+certificates, providers, notify, uploads, settings, audit)
  templates/ static/ HTML + CSS/JS + logo
migrations/          numbered SQL migrations (001_init.sql ...)
tests/               unittest suite
manage.py            CLI: migrate | seed | create-admin | seed-demo | expire-subscriptions | backup | run
wsgi.py              production entry point (gunicorn wsgi:app)
```
**Adding a migration:** create `migrations/002_description.sql`; it is applied once, in order, by `python manage.py migrate`.

**Scheduled task (recommended, daily):** `python manage.py expire-subscriptions` sends "your subscription expired" notifications.
(Access expiry itself is evaluated live on every request; this job only sends the notification.)
