# Relatório de Testes — ADAM KNOWLEDGE Backend (Primeira Etapa)

**Resultado da última execução:** ✅ **44 de 44 testes passando** (0 falhas,
0 pulados), usando `node --experimental-sqlite --test "tests/**/*.test.js"`.

Tempo total de execução: ~2.5s.

Todos os testes usam comportamento real (servidor HTTP real em porta
efêmera, banco SQLite real isolado por arquivo de teste, servidor HTTP de
mock real via loopback para simular páginas web) — nenhum teste depende de
mocks de framework ou asserts sobre strings fixas sem execução real do
código.

## Por módulo

### `tests/database.test.js` (7 testes) — Repositórios de banco de dados
- Criação, atualização de status e persistência de resultado de tarefas
- Contagem real por status
- Agrupamento de tarefas por solicitação pai
- Criação de pesquisas, adição de resultados, atualização de status
- Validação de tipo inválido e campos obrigatórios em recursos
- CRUD completo de recursos (criar, buscar por tag, atualizar, deletar)
- Contagem de recursos por tipo

### `tests/task-manager.test.js` (9 testes) — ADAM TASK ENGINE
- Execução simples com sucesso
- **Respeito ao limite de concorrência** (verificado contando tarefas
  simultâneas em tempo real, não apenas inferido)
- Retry automático após falha, com sucesso na 3ª tentativa
- Falha definitiva após exceder o número máximo de tentativas
- Cancelamento cooperativo de tarefa ainda na fila
- Erro claro ao tentar enfileirar tipo sem handler registrado
- Estatísticas (`getStats`) refletindo contagens reais
- Recuperação de tarefas `queued` e `processing` após reinicialização

### `tests/request-analyzer.test.js` (5 testes) — Interpretação de linguagem natural
- Rejeição de query vazia/nula
- Detecção de categoria de recurso (textura, modelo, som) via linguagem natural
- **Exemplo literal da especificação** (madeira de eucalipto) gerando as
  subtarefas corretas (pesquisa + imagens + análise de material)
- Prioridade de requisitos explícitos sobre detecção automática
- Pedido simples gerando apenas a subtarefa de pesquisa textual

### `tests/source-reader.test.js` (6 testes) — Leitura real de páginas web
- Leitura de página real via HTTP (servidor de mock local), extração
  correta de título e remoção de `nav`/`script`/`footer`
- Erro honesto em HTTP 404 (nunca finge sucesso)
- Erro honesto em URL inválida
- Erro honesto em timeout (timeout real de 1 segundo testado)
- Rejeição de protocolo não suportado (ex: `ftp://`)
- Erro honesto para host inexistente (sem rede/DNS)

### `tests/api.test.js` (17 testes) — API HTTP completa (integração real)
- Health check sem autenticação, com estados reais
- Rejeição de requisição sem token e com token incorreto (401)
- Handshake de conexão com token correto
- Validação de campo obrigatório (`query`) em `/api/research`
- **Fluxo completo**: criar solicitação de pesquisa → aguardar
  processamento assíncrono real → consultar resultado compilado
- Consulta de tarefa/solicitação inexistente (404)
- **Fluxo completo de recursos**: criar → buscar por filtro → obter por id
- Tratamento de erro de validação de domínio (tipo de recurso inválido)
- Consulta de recurso inexistente (404)
- `/api/sync` respondendo 501 honestamente (não implementado)
- Corpo JSON inválido (400)
- Rota inexistente (404)

## Cobertura por arquivo (execução real do test runner)

- `tests/api.test.js`: 17 testes — health, autenticação, conexão, pesquisa, recursos, CORS, download binário e respostas de erro.
- `tests/database.test.js`: 7 testes — persistência e repositórios SQLite.
- `tests/request-analyzer.test.js`: 5 testes — análise de pedidos em linguagem natural.
- `tests/source-reader.test.js`: 6 testes — leitura HTTP, timeout e validação de URL.
- `tests/task-manager.test.js`: 9 testes — fila, concorrência, retry, cancelamento e recuperação após reinicialização e respeito ao limite de tentativas.

**Total confirmado:** 44 testes, 0 falhas, 0 ignorados.

## Bugs reais encontrados e corrigidos durante o desenvolvimento

Documentado com transparência (ver `docs/STATUS.md` para mais detalhes):

1. **Condição de corrida na compilação de resultados**: a subtarefa
   `research.compile_results` rodava em paralelo com as demais subtarefas
   (mesmo nível de concorrência), então compilava resultados ainda
   incompletos. Corrigido removendo-a como tarefa enfileirada e movendo a
   compilação para `IntelligenceOrchestrator.getRequestStatus()`, que só
   compila quando todas as subtarefas realmente terminaram.

2. **Falso positivo na detecção de palavras-chave**: a palavra-chave `"api"`
   (usada para detectar pedidos de documentação técnica) dava match via
   substring dentro da palavra **"capital"** (c-**api**-tal), fazendo
   qualquer pergunta sobre "capital de um país" ser erroneamente classificada
   como pedido de documentação técnica. Corrigido trocando a checagem de
   substring por correspondência de **tokens inteiros** (tokenização
   unicode-aware).

3. **Cobertura insuficiente de sinônimos**: "efeitos sonoros" não era
   reconhecido como categoria `sound` (só "som"/"sons" estavam mapeados).
   Corrigido adicionando as variações `sonoro`/`sonora`/`sonoros`/`sonoras`.

4. **Teste com suposição incorreta de banco vazio**: um teste do Task Engine
   assumia contagem absoluta de tarefas, mas o banco é compartilhado entre
   todos os testes do mesmo arquivo. Corrigido para comparar a variação
   (antes/depois), não o valor absoluto.

5. **Timer pendurado em teste de timeout**: o servidor de mock usado para
   testar timeout tinha um `setTimeout` de 5s que não era limpo quando o
   cliente abortava a conexão, atrasando a suíte em ~4s por execução.
   Corrigido limpando o timer no evento `close` da requisição.

6. **Erros de validação de entrada retornavam 500 em vez de 400**: um
   recurso com `type` inválido ou sem `category`/`name` causava um erro
   genérico que o roteador tratava como falha interna do servidor (500).
   Corrigido criando `ResourceValidationError` (e uma convenção
   `*ValidationError` no roteador) para que qualquer erro de validação,
   em qualquer camada, vire 400 — erro do cliente, não do servidor.

## Como reproduzir

```bash
npm test
# ou, diretamente:
node --experimental-sqlite --test "tests/**/*.test.js"
```
