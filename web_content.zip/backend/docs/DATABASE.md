# Database
SQLite in WAL mode (one file, trivially backed up and moved, no server to run). Schema: `migrations/001_init.sql`. Foreign keys are enforced. Money is stored as integer **kobo**. Timestamps are UTC.

Main tables: `users`, `user_permissions` (roles = `users.role`; staff permissions granular), `categories`, `courses`, `modules`, `lessons`, `quizzes`, `questions`, `quiz_attempts`, `assignments`, `submissions`, `progress`, `announcements`, `plans`, `promos`, `transactions`, `payment_evidence`, `payment_notes`, `entitlements`, `notifications`, `certificates`, `articles`, `article_categories`, `nuggets`, `testimonials`, `faqs`, `pages`, `settings`, `audit_logs`, `password_resets`, `rate_events`, `webhook_events`, `newsletter_subscribers`, `contact_messages`.

**Integrity guarantees enforced by the database**
- `entitlements.transaction_id` is `UNIQUE`: one payment can create at most one entitlement, whatever happens in the application.
- `transactions.status` is a `CHECK`-constrained state set; `amount_kobo >= 0`.
- Subscription and course entitlements are separate rows, evaluated independently.

**Scale & hosting note.** SQLite comfortably serves thousands of learners on one server. It allows one writer at a time, so run a single host (several gunicorn workers on one machine are fine). If you later outgrow it, the data access layer (`dagba/db.py`, plain parameterised SQL) is the only place to adapt for PostgreSQL; schema DDL needs minor type changes (`INTEGER PRIMARY KEY` -> `SERIAL`, `datetime('now')` -> `now()`). This port has **not** been done or tested.

Export: `python manage.py backup` (consistent snapshot) or Admin > Backup & export.
