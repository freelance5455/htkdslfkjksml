# API — ADAM ADDONFORGE BRIDGE

Base URL padrão: `http://127.0.0.1:4100` (configurável via `.env`).

## CORS (uso pelo AddonForge no navegador)

O servidor responde a preflight `OPTIONS` e libera apenas origens listadas em `CORS_ALLOWED_ORIGINS` no `.env`. As origens são separadas por ponto e vírgula. Para HTML aberto diretamente como arquivo local, o navegador pode enviar `Origin: null`; nesse caso, `CORS_ALLOWED_ORIGINS=null` permite essa origem opaca. Em produção, configure somente a origem realmente usada pelo cliente.

## Autenticação

Todas as rotas, **exceto `GET /api/health`**, exigem o header:

```
Authorization: Bearer <ADDONFORGE_TOKEN>
```

O token é definido no `.env` do servidor (`ADDONFORGE_TOKEN`). Requisições
sem o header, com formato inválido, ou com token incorreto recebem
`401 UNAUTHORIZED`.

## Formato de erro padrão

```json
{
  "error": "CODIGO_DO_ERRO",
  "message": "Descrição legível do que deu errado."
}
```

Códigos possíveis: `UNAUTHORIZED` (401), `INVALID_REQUEST` (400),
`INVALID_JSON` (400), `VALIDATION_ERROR` (400), `NOT_FOUND` (404),
`FILE_NOT_FOUND` (404), `CORS_ORIGIN_DENIED` (403) e `INTERNAL_ERROR` (500).

---

## `GET /api/health`

Não exige autenticação. Retorna o diagnóstico real do sistema (ver
ADAM SYSTEM MONITOR).

**Resposta 200:**
```json
{
  "app": "ADAM KNOWLEDGE",
  "timestamp": "2026-11-21T04:30:02.775Z",
  "database": "OK",
  "internet": "CONECTADA",
  "webResearch": "DISPONIVEL",
  "imageResearch": "PARCIAL (reaproveita pesquisa web nesta etapa)",
  "artificialIntelligence": "NAO CONFIGURADA",
  "addonForge": "DESCONECTADO",
  "addonForgeLastSeenAt": null,
  "storage": "OK (97.4% livre)",
  "tasks": { "queued": 0, "processing": 0, "completed": 6, "failed": 2, "cancelled": 0, "activeNow": 0, "queuedInMemory": 0, "concurrencyLimit": 4 },
  "recentErrors": []
}
```

---

## `POST /api/connect`

Handshake inicial do AddonForge. Marca o AddonForge como "conectado" (visível
em `/api/health`) por 5 minutos a partir desta chamada.

**Request body:**
```json
{ "client_name": "AddonForge" }
```

**Resposta 200:**
```json
{ "connected": true, "server": "ADAM KNOWLEDGE", "version": "0.1.0", "serverTime": "..." }
```

---

## `POST /api/research`

Dispara uma solicitação de pesquisa/conhecimento. Processamento é
**assíncrono** — a resposta imediata é `202 Accepted` com os ids das
subtarefas criadas; o resultado final é obtido depois via
`GET /api/tasks/:request_id`.

**Request body:**
```json
{
  "request_id": "unique-request-id",
  "query": "Madeira de eucalipto",
  "category": "texture",
  "requirements": {
    "find_images": true,
    "analyze_material": true,
    "find_documentation": false
  }
}
```

- `request_id` (opcional): se omitido, um UUID é gerado automaticamente e
  retornado na resposta.
- `query` (obrigatório): string não vazia.
- `requirements` (opcional): flags explícitas que têm prioridade sobre a
  detecção automática por palavra-chave do Request Analyzer.

**Resposta 202:**
```json
{
  "request_id": "unique-request-id",
  "status": "processing",
  "intent": "create_resource_reference:texture",
  "tasks": [
    { "task_id": "...", "type": "research.web_search", "status": "queued" },
    { "task_id": "...", "type": "research.image_search", "status": "queued" }
  ]
}
```

**Erros:** `400 INVALID_REQUEST` se `query` estiver ausente ou vazio.

---

## `GET /api/tasks/:id`

Aceita tanto o `request_id` de uma solicitação completa (recomendado) quanto
o `task_id` de uma subtarefa individual.

**Consultando por `request_id`** — resposta 200:
```json
{
  "requestId": "unique-request-id",
  "status": "completed_with_errors",
  "tasks": [
    { "id": "...", "type": "research.web_search", "status": "failed", "result": null, "error": "Nenhum provedor de pesquisa web esta configurado..." },
    { "id": "...", "type": "research.image_search", "status": "completed", "result": { "...": "..." }, "error": null }
  ],
  "compiledResult": {
    "summary": "1 de 2 subtarefa(s) concluida(s) com sucesso.",
    "successful": [ { "type": "research.image_search", "result": { "...": "..." } } ],
    "failed": [ { "type": "research.web_search", "error": "..." } ]
  }
}
```

`status` pode ser: `processing`, `completed`, `completed_with_errors`.
`compiledResult` é `null` enquanto `status === "processing"`.

**Consultando por `task_id`** (subtarefa individual) — resposta 200: o
registro bruto da tarefa (`id`, `type`, `status`, `payload`, `result`,
`error`, `attempts`, timestamps).

**Erros:** `404 NOT_FOUND` se nenhum request ou task com esse id existir.

---

## `POST /api/resources/search`

Busca recursos na biblioteca com filtros no corpo da requisição.

**Request body (todos os campos opcionais):**
```json
{ "type": "texture", "category": "wood", "project": "addon-01", "tag": "eucalipto", "text": "casca", "limit": 50, "offset": 0 }
```

**Resposta 200:**
```json
{ "items": [ { "...": "..." } ], "total": 1 }
```

---

## `POST /api/resources/create`

Registra um novo recurso (textura, modelo, animação, som ou documentação).

**Request body:**
```json
{
  "type": "texture",
  "category": "wood",
  "name": "Eucalipto - casca 01",
  "description": "Referência de textura de casca de eucalipto",
  "origin": "https://exemplo.com/foto-eucalipto.jpg",
  "format": "png",
  "resolution": "512x512",
  "license_info": "CC-BY apenas para referência",
  "tags": ["madeira", "eucalipto"],
  "project": "minecraft-addon-01",
  "compatibility": "Bedrock 1.21+",
  "file_base64": "<conteudo do arquivo em base64, opcional>",
  "file_extension": "png"
}
```

Se `file_base64` for enviado, o arquivo é realmente salvo em disco sob
`storage/resources/<tipo>/<categoria>/`. Se omitido, o recurso é cadastrado
apenas como **referência** (sem arquivo reutilizável) — distinção importante
feita pela especificação entre "imagem de referência" e "arquivo
reutilizável".

**Resposta 201:** o recurso criado, incluindo `id` gerado.

**Erros:** `400 VALIDATION_ERROR` para tipo inválido, campos obrigatórios ausentes ou extensão de arquivo inválida.

---

## `GET /api/library`

Lista recursos via query string. Parâmetros: `type`, `category`, `project`,
`tag`, `text`, `limit`, `offset` (todos opcionais).

Exemplo: `GET /api/library?type=texture&tag=eucalipto`

**Resposta 200:** mesmo formato de `/api/resources/search`.

---

## `GET /api/library/:id`

**Resposta 200:** o recurso completo. **Erros:** `404 NOT_FOUND`.

---

## `GET /api/library/:id/file`

Baixa os bytes reais do arquivo associado ao recurso. Exige autenticação. Retorna `404 FILE_NOT_FOUND` se o recurso for apenas uma referência sem arquivo salvo. O tipo de conteúdo é definido por extensão conhecida; extensões desconhecidas são entregues como `application/octet-stream`.

Exemplo: `GET /api/library/ID_DO_RECURSO/file`

---

## `POST /api/sync`

Sincronização com armazenamento remoto. **Ainda não implementada nesta
etapa** — a rota existe e responde honestamente:

**Resposta 501:**
```json
{ "synced": false, "message": "Sincronizacao com armazenamento remoto esta preparada na arquitetura mas ainda nao implementada nesta primeira etapa (ver docs/STATUS.md)." }
```
