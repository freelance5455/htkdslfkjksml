# Preparação para empacotamento Android / APKForge

## Situação verificada desta entrega

Este ZIP contém o backend Node.js do ADAM KNOWLEDGE. Ele **não é um projeto Android** e não gera APK sozinho. O backend requer Node.js 22 ou superior e usa `node:sqlite`.

Um empacotador que apenas transforma HTML/CSS/JavaScript de navegador em APK (WebView) não consegue executar este servidor Node.js automaticamente. Para incluir o backend no APK, o APKForge precisa oferecer explicitamente suporte a uma destas opções:

1. executar um runtime Node.js dentro do Android e iniciar `src/server.js` como serviço/processo gerenciado; ou
2. integrar um serviço/backend hospedado externamente, com conexão HTTPS e autenticação.

Se o APKForge só aceitar um site ou arquivo HTML, ele poderá empacotar uma interface, mas **não hospedará o backend, o SQLite nem a fila de tarefas**.

## O que precisamos confirmar no APKForge antes de adaptar

- aceita somente HTML ou aceita projeto ZIP completo?
- permite incluir arquivos locais e módulos nativos Android?
- tem suporte documentado a Node.js no dispositivo?
- permite iniciar e manter um serviço em segundo plano?
- permite permissões de internet e armazenamento?
- qual origem/URL a WebView usa? Isso define a configuração CORS.

## Segurança antes de publicar

- Não publique o token de API dentro de HTML/JavaScript distribuído: ele pode ser extraído do APK.
- Não exponha o servidor em `0.0.0.0` sem autenticação forte, HTTPS ou controles equivalentes.
- Configure `CORS_ALLOWED_ORIGINS` apenas com a origem real do aplicativo.
- O banco SQLite é criado localmente na primeira inicialização pelas migrations. Nenhum banco de teste ou dados pessoais é incluído neste ZIP.

## Próxima validação

Depois que o usuário fornecer o APKForge (arquivo, link oficial ou capturas das opções de projeto), comparar os recursos reais do empacotador com os requisitos acima. Não declarar compatibilidade antes desse teste.
