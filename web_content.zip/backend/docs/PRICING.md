# Academic and Professional Development pricing

| Section | Sold as | Subscription |
|---|---|---|
| Basic | Per **subject** (e.g. Physics). One purchase unlocks every course, topic and lesson in it. | Own Basic subscription |
| Advanced | Per **subject** (e.g. Law, Engineering). One purchase unlocks every course, topic and lesson in it. | Own Advanced subscription |
| Professional Development | Per **subject** (programme area, e.g. ICAN, HSC Certification Preparation). One purchase unlocks every course, topic and lesson in it. | **None** (a subject purchase never creates a subscription) |
| Income Skills | Unchanged (per course + own subscription) | Unchanged |

Topics and lessons are never priced separately. Basic, Advanced and Income subscriptions are fully independent (separate expiry, separate renewal); a subscription never unlocks another section. Professional Development is never unlocked by any subscription.

## Admin
- **Prices & subscriptions** (sidebar): one screen to set subscription fees/duration/on-off, Basic, Advanced and Professional Development subject prices, and individual course prices (Income Skills, plus any Advanced/Professional course whose subject has no price).
- Categories > a subject (Basic, Advanced or Professional) also has Subject price, cover image, homepage featuring, active status and access length. Plans have a Section (Basic / Advanced).
- Basic course in a priced subject is sold through the subject (its own price is ignored). If the subject has no price yet, the course's old price still applies, so nothing becomes free or inaccessible by accident.
- Announcements can target Basic or Advanced subscribers.

## Upgrade notes (migration 010)
- Existing "Academic" plans/subscriptions become **Basic**; a new inactive **Advanced Subscription** plan is created (set its price on the Prices screen, then tick Offered).
- Existing course purchases, payments and student records are copied unchanged. Existing course entitlements keep working.
- Existing students who held an Academic subscription now get Basic courses only (Advanced courses need the Advanced subscription or a purchase; Professional need a purchase).
- The migration rebuilds the `transactions` and `entitlements` tables: take a backup first (`scripts/termux-backup.sh`).

## Basic Academic: category display (migration 011)

Students see, buy and browse **Basic categories** (for example "English JSS1"), not individual Basic courses.

- **Homepage / course listings:** Basic categories appear as cards with the category name and price. Courses inside a Basic category are no longer listed individually. Only categories ticked **Feature on the homepage** appear on the homepage.
- **Category page** (`/academic/basic/<category>`): shows every published course in the category with its topics and lessons.
- **Access:** one purchase of a category unlocks all its courses, topics and lessons. An active Basic subscription unlocks every Basic category (regardless of each course's own "Included in subscriptions" flag).
- **Admin:** Staff > Academic structure > Basic. **+ Add category** (name, price, feature on homepage), **Courses** (tick the courses that belong to the category), **Edit** (price, featuring, access period). An active Basic category must have a price.
- Advanced and Professional Development are unchanged. Basic courses that have no category stay visible as before.

## Basic Academic: category cover images (migration 012)

- Each **Basic category** can have one cover image: Staff > Academic structure > Basic > Edit (or Categories). Upload, replace, or tick **Remove the current image**. Replaced or removed files are deleted from the server.
- The image shows with the category name on the homepage, the Basic category list (`/academic/basic`) and the course listings. It scales to 16:9 on desktop and 3:2 on phones, and categories without an image still display normally.
- Basic courses no longer have a cover upload in the course builder or the course form; existing images on Basic courses are kept, not deleted. Advanced, Professional Development and Income Skills courses are unchanged.


## Subject pricing for all three divisions (migration 019)

Basic, Advanced and Professional Development are now all **sold by subject**. Income Skills keeps individual course prices and its own subscription.

- **Admin:** Staff > Academic structure (Basic / Advanced / Professional) > **+ Add subject**: name, description, cover image, **Subject price**, **Show on the homepage**, Active. **Courses** assigns courses to the subject. Prices can also be edited on **Prices & subscriptions**. Only Basic requires a price for an active subject (as before); an Advanced/Professional subject with no price falls back to individual course prices, so nothing becomes free or inaccessible by accident. Income Skills categories cannot carry a subject price.
- **Homepage** order: Basic, Advanced, Professional Development subject cards, then Income Skills courses. A card shows the subject name, cover image and saved price, once per subject, only while the subject is active, featured and has a published course. Professional Development shows subject cards, never individual course cards (courses with no subject remain on `/professional`).
- **Pages:** `/academic/basic|advanced/<subject>` and `/professional/<subject>` show the price, a Buy button and every course, topic and lesson the subject unlocks. `/academic/professional/<subject>` redirects to `/professional/<subject>`.
- **Purchase:** a course inside a priced subject redirects its checkout to the subject (`/checkout/subject/<id>`), which charges the saved price through the existing manual bank-transfer flow. When an administrator verifies the payment, a `subject` entitlement (division + level + subject) is granted and unlocks every published course of that subject, including courses added later. A subject already owned cannot be bought again; an open request is reused. Refunds revoke it. Deactivating a subject stops new sales but owners keep access.
- **Subscriptions are not merged:** a Basic subscription unlocks only Basic, an Advanced subscription only Advanced (eligible courses), Income only Income. Subject purchases never create subscription access.
- **Backward compatibility:** migration 019 is additive (one index, back-fill of subject-entitlement division/level, and featuring of existing active Professional subjects so the homepage keeps showing them; untick any in admin). No table is rebuilt; existing purchases, individual course entitlements, transactions, subscriptions and prices are untouched. Back up before upgrading anyway (`scripts/termux-backup.sh`).


## Strict division separation (migration 020)
- **Homepage sections are strictly per division.** Basic, Advanced and Professional Development show *subjects only* (never course cards). The **Income Skills** section (formerly "Featured Course") shows published courses with `division='income'` only. The general `featured` flag only orders courses inside the Income Skills section; it can never bring a Basic, Advanced or Professional course into it. Publishing or creating a course in another division never changes this section. The section title is edited under Settings > Homepage text (`Income Skills section: title`); migration 020 renames any stored title that still said "Featured".
- **A course's division cannot change by accident.** In the course builder the division is locked once a course is saved (a request without a division keeps the stored one, and a different one is refused). Only an administrator who ticks **Move this course to another division** can move a course; instructors never can. A course also cannot be saved into a category of another division (builder validation plus database triggers), and a category that already has courses cannot change division.
- **Data repair:** migration 020 corrects a course's division *only* where it can be proven: the course sits in a category of a different division (the category was chosen explicitly), so the course follows its category. Each repair is recorded in the `division_repairs` table (old values included) for review or reversal. Courses with no category are never touched. Run `python manage.py audit-divisions` any time for a read-only report of courses whose division, level and category disagree; fix those by hand in the course builder.
