# Arquitetura — ADAM KNOWLEDGE (Backend, Primeira Etapa)

## Visão geral

```
                      ┌──────────────────────────┐
                      │   ADAM ADDONFORGE BRIDGE   │   (src/communication)
                      │   API HTTP autenticada     │
                      └─────────────┬────────────┘
                                    │
                      ┌─────────────▼────────────┐
                      │  ADAM KNOWLEDGE CORE       │   (src/core/intelligence-orchestrator.js)
                      │  - Request Analyzer        │
                      │  - Task Engine             │
                      └───┬─────────────────┬─────┘
                          │                 │
            ┌─────────────▼───┐   ┌─────────▼──────────┐
            │ ADAM WEB         │   │ ADAM RESOURCE        │
            │ RESEARCH ENGINE  │   │ LIBRARY               │
            │ (src/research)   │   │ (src/resources)       │
            └─────────┬────────┘   └──────────┬───────────┘
                      │                         │
                      └───────────┬─────────────┘
                                  │
                      ┌───────────▼────────────┐
                      │ ADAM KNOWLEDGE DATABASE  │   (src/database)
                      │ SQLite local             │
                      └─────────────────────────┘

                      ┌─────────────────────────┐
                      │ ADAM SYSTEM MONITOR       │  (src/monitor) — observa todos os módulos acima
                      └─────────────────────────┘
```

## Módulos e suas responsabilidades reais

### `src/core` — ADAM KNOWLEDGE CORE

- **`request-analyzer.js`**: interpreta a linguagem natural (ou requisitos
  estruturados vindos do AddonForge) e decompõe o pedido em subtarefas.
  Implementação real baseada em regras/palavras-chave (tokenização
  unicode-aware, para evitar falsos positivos tipo "capital" casando com a
  palavra-chave "api"). **Não é uma IA generativa** — é um ponto de extensão
  documentado para, no futuro, plugar um LLM real sem mudar o contrato de
  saída (`{ intent, resourceCategory, subtasks }`).

- **`task-manager.js`**: o ADAM TASK ENGINE. Fila assíncrona real com:
  - limite de concorrência configurável
  - estados persistidos (`queued`, `processing`, `completed`, `failed`,
    `cancelled`)
  - retentativas automáticas controladas (`maxAttempts`)
  - cancelamento cooperativo (`isCancelled()` é checado pelo handler)
  - eventos (`task:queued`, `task:processing`, `task:completed`,
    `task:failed`, `task:cancelled`)

- **`intelligence-orchestrator.js`**: liga Request Analyzer + Task Engine +
  Web Research + Resource Library. Registra os handlers de cada tipo de
  subtarefa e expõe `processRequest()` / `getRequestStatus()`. A compilação
  final dos resultados (`_compileResults`) só acontece depois que **todas**
  as subtarefas de uma solicitação realmente terminam — isso corrigiu uma
  condição de corrida real encontrada durante o desenvolvimento (ver
  `docs/STATUS.md`, seção "Bugs encontrados e corrigidos").

### `src/database` — ADAM KNOWLEDGE DATABASE

- **`db.js`**: conexão singleton com SQLite via `node:sqlite` (nativo do
  Node 22, ainda experimental). `PRAGMA journal_mode = WAL` e
  `PRAGMA foreign_keys = ON` habilitados.
- **`migrate.js`**: runner de migrations idempotente e versionado — cada
  arquivo `.sql` em `migrations/` é aplicado uma única vez e registrado em
  `schema_migrations`.
- **`migrations/001_init.sql`**: schema completo da fundação (tasks,
  research_queries, research_results, resources, addonforge_requests).
- **`repositories/`**: camada de acesso a dados. Nenhuma lógica de negócio
  aqui — apenas CRUD real sobre as tabelas.

Decisão de design: **arquivos grandes não são salvos no banco**. O banco
guarda apenas o `file_path` relativo; o conteúdo binário vive em
`storage/resources/`. Isso facilita trocar o armazenamento local por um
armazenamento de objetos remoto (S3-compatible, por exemplo) no futuro,
sem alterar o schema.

### `src/research` — ADAM WEB RESEARCH ENGINE

- **`search-providers/`**: contrato plugável (`SearchProvider`). Duas
  implementações reais:
  - `duckduckgo-provider.js`: usa a versão HTML (sem JS) da DuckDuckGo.
    **Não exige chave de API**, mas depende da estrutura pública da página,
    que pode mudar sem aviso — documentado como adequado para
    desenvolvimento/uso leve, não para produção crítica.
  - `generic-api-provider.js`: template para um provedor com API oficial e
    chave (formato de referência compatível com Brave Search API). Caminho
    recomendado para produção.
- **`source-reader.js`**: acessa uma URL real via `fetch` e extrai
  título + texto legível, removendo `<script>`, `<style>`, `<nav>`,
  `<footer>` via um extrator leve baseado em regex (documentado como
  limitação honesta: não substitui um parser DOM completo para páginas
  muito complexas — ponto de evolução futura).
- **`web-search.js`**: orquestra provider + source reader + persistência.
  Se nenhum provider estiver configurado, lança
  `WebResearchNotConfiguredError` em vez de simular resultados — isso é
  testado explicitamente (`tests/database.test.js`, `tests/api.test.js`).

### `src/resources` — ADAM RESOURCE LIBRARY

- **`resource-library.js`**: cria a árvore de pastas
  `storage/resources/<tipo>/<categoria>/`, salva arquivos reais em disco
  (quando fornecidos) e delega metadados ao `resource-repository`. Também
  sabe ler o conteúdo de volta (`readResourceFile`) e deletar (arquivo +
  registro) de forma consistente.

### `src/communication` — ADAM ADDONFORGE BRIDGE

- **`http-router.js`**: roteador HTTP minimalista sobre `node:http` (sem
  framework externo — ver nota sobre ambiente sem rede no README). Suporta
  parâmetros de rota (`:id`), parsing de JSON com limite de tamanho (2MB) e
  tratamento de erros centralizado.
- **`auth.js`**: autenticação Bearer com comparação em tempo constante
  (`timingSafeEqual`), e um rastreador de conexão do AddonForge (usado pelo
  System Monitor para saber se está `CONECTADO`/`DESCONECTADO` de verdade).
- **`addonforge-bridge.js`**: implementa o contrato de API completo da
  especificação (ver `docs/API.md` para detalhes de cada rota).

### `src/monitor` — ADAM SYSTEM MONITOR

Todas as verificações são **reais**, executadas no momento da chamada:
checagem de banco (`SELECT 1`), checagem de internet (`fetch HEAD` com
timeout curto), checagem de armazenamento (`fs.statfsSync`), estatísticas
reais do Task Engine, e os últimos erros registrados pelo logger. Nada é
reportado como "fixo" — se a internet cair, o status muda de verdade.

## Fluxo completo de uma solicitação (exemplo end-to-end)

1. AddonForge faz `POST /api/research` com `query` e `requirements`.
2. `addonforge-bridge.js` autentica e chama
   `intelligenceOrchestrator.processRequest()`.
3. `request-analyzer.js` decompõe em subtarefas (`research.web_search`,
   `research.image_search`, etc).
4. Cada subtarefa é enfileirada no `TaskManager`, que as processa
   assincronamente (respeitando concorrência).
5. `research.web_search` chama `webResearchEngine.research()`, que usa o
   provider configurado e o `sourceReader` para ler as páginas de verdade.
6. Tudo é persistido via `research-repository.js`.
7. AddonForge consulta `GET /api/tasks/:request_id` periodicamente; quando
   todas as subtarefas terminam, a resposta inclui `compiledResult` com o
   resumo organizado (sucessos e falhas separados).

## Pontos de evolução (documentados, não escondidos)

| Área | Estado atual | Evolução recomendada |
|---|---|---|
| Roteador HTTP | Implementação própria sobre `node:http` | Trocar por Express/Fastify quando houver `npm install` disponível |
| Extração de HTML | Regex-based, leve | Parser DOM completo (ex: uma lib de parsing HTML real) |
| Pesquisa de imagens | Reaproveita a pesquisa web textual | Motor dedicado (ADAM IMAGE RESEARCH) com APIs de busca de imagem |
| Análise de material/padrões visuais | Não implementado (retorna nota explícita) | Motor de visão computacional — segunda etapa do projeto |
| Provedor de IA generativa | Ponto de extensão preparado, não implementado | Integração real com Anthropic/OpenAI/outro |
| Sincronização remota (`/api/sync`) | Responde 501 explicitamente | Implementar sync real com Postgres/armazenamento de objetos remoto |
| node:sqlite | Experimental no Node 22 | Monitorar estabilização, ou migrar para `better-sqlite3` via npm quando disponível |
