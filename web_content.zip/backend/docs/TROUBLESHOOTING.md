# Troubleshooting

## "500 - Something went wrong on our side"
It means the server hit an unexpected error while handling that request. Nothing is wrong with your device or what you typed.
1. Note the **Reference** code shown on the page (8 letters/digits).
2. **Owner/admin:** log in and open **Audit log**, search `error.500` (or the reference): it shows the page and the cause. Administrators also see the technical detail directly on the error page.
3. **Server log:** the same reference is in the log with the full traceback (the terminal running `python manage.py run`, or `journalctl -u dagba` / `docker compose logs web`).
4. Most common causes: an out-of-date database (the app now upgrades it automatically on start; or run `python manage.py migrate`), a full disk (uploads/videos), a file permission problem on the data folders, or a missing/invalid environment setting.
- **"Security check failed (CSRF)"**: the page was open too long or cookies are blocked. Refresh and retry. Behind HTTPS make sure `COOKIE_SECURE=true` and you use the https URL.
- **Everyone is rate-limited / "Too many attempts"**: behind a proxy set `TRUST_PROXY=true`.
- **Students see "Bank transfer is not available"**: set bank name + account number in Admin > Bank transfer and tick *Enable*.
- **A gateway button does not show**: it must be enabled **and** configured (Admin > Payment methods shows its state).
- **Forgot-password email never arrives**: SMTP is optional; as owner open Users > the user > *Generate password reset link* and send it securely.
- **"This image could not be processed"**: the image file is damaged or incomplete (often a photo that did not finish downloading or was cut off when forwarded). Use the original file or re-save it as JPG/PNG. iPhone HEIC photos: choose "Most Compatible" in camera settings or share as JPG.
- **"The cover image did not upload correctly"**: choose the cover image again (JPG, PNG or WebP up to 15 MB) and wait for "Cover image ready" before pressing Save. You can also remove the cover and save without one. Existing covers never block saving a course.
- **Uploads rejected**: file content must match its extension (JPG/PNG/PDF) and be under the size limit.
- **`database is locked`**: only one app server should write to the SQLite file; check for a stray second process.
- **Fresh start (dev only)**: delete `instance/` and re-run migrate/seed/create-admin.
- **Run tests**: `python -m unittest discover -s tests -t .`
