# Payments guide

## 1. Set up bank transfer (owner, no coding)
Admin > **Bank transfer**: bank name, account name, 10-digit account number, instructions, support contact, whether receipts are mandatory, accepted file types (jpg/png/pdf), max size (1-20 MB), whether rejected students may resubmit, and an on/off switch. Changes are live immediately on every student payment page. Bank details are never hard-coded. Only users with the `bank.manage` permission can edit them, and every change is written to the audit log.

## 2. How a student pays
Choose course/plan -> (optional promo code) -> **Continue to payment** -> sees bank details, exact amount and a unique reference (`DDA-XXXXXXXXXX`) -> transfers using their own banking app -> uploads receipt (JPG/PNG/PDF) with transfer date/sender -> status **Pending verification**. The server fixes the amount; students cannot change amounts or statuses.

## 3. How a payment officer verifies
Admin > **Payments** (pending shown first, with a counter; staff with payments permission also get a dashboard notification linking straight to the transaction).
1. Open the payment, inspect the receipt and details (amount sent is highlighted if it differs from the expected amount).
2. **Check your bank account** to confirm the money has actually arrived with the right amount/reference. **A receipt alone never grants access.**
3. Choose **Approve** (tick both confirmations), **Reject** (reason shown to student), or **Request information** (message shown to student). Add internal notes any time.
4. Approval creates exactly one entitlement for exactly what was bought and notifies the student. Duplicate approvals are impossible. You cannot decide your own payment.
Refunds (`payments.refund` permission) mark the payment refunded and revoke the access that payment created.

Permissions to give a payment officer: `payments.manage` (and optionally `reports.view`, `payments.refund`).

## 4. Access rules (Admin > Courses / Plans)
- Individual course: lifetime, or N days after approval (per-course setting).
- Subscriptions: **Academic** and **Income Skills** are separate plans with separate expiry. Renewals stack on remaining time. A course is included in a subscription only if its *Included in subscriptions* box is ticked.
- An expired subscription never removes an individual purchase, and never affects the other subscription.
- Discounts: Admin > Discounts & promo codes (percent and/or amount, applies to courses/plans, dates, max uses). Validated server-side. A 100% code grants access immediately and is recorded.

## 5. Reports
Admin > Reports: **confirmed revenue = approved payments only**. Pending submissions are shown separately and never counted as revenue. Breakdowns by course, subscription category, plan, payment method, date range; CSV export (spreadsheet-formula safe).

## 6. Activating Paystack / Flutterwave later
Code for both is already in `dagba/services/providers.py` and wired into checkout, server-side verification and authenticated webhooks. **They have not been exercised against live accounts (none were available), so treat them as "awaiting credentials" and test with the provider's test keys first.**
1. Create the provider account; get **secret key** (and for Flutterwave a **secret hash** you invent).
2. Admin > **Payment methods**: paste keys, tick *enabled*, save. (Or set `PAYSTACK_SECRET_KEY` / `FLUTTERWAVE_SECRET_KEY` / `FLUTTERWAVE_WEBHOOK_HASH` on the server.)
3. In the provider dashboard set the webhook URL: `https://YOUR-DOMAIN/webhooks/paystack` or `/webhooks/flutterwave`.
4. The option appears to students **only** when enabled **and** configured. The status panel on that page tells you honestly: *Awaiting credentials / Credentials saved, disabled / Active*.
5. Test a small payment. Success is only trusted after the server calls the provider's verify API and the amount/currency match; failures/mismatches never grant access; repeated webhooks are idempotent.
Both gateways and manual transfer can run at the same time and feed the same transaction + entitlement system.
Secret keys are never sent to browsers. Stored in the database (restrict database access and backups accordingly) or supplied via environment variables.

## 7. Tutor revenue share
Individual course sales credit the tutor 40% (configurable) at the moment the payment is approved, whichever method was used (bank transfer or gateway). See the *Tutor earnings and withdrawals* section of `docs/ADMIN_GUIDE.md`. The site records and tracks withdrawals but does **not** send money itself: you transfer from your bank and upload the receipt as proof.
