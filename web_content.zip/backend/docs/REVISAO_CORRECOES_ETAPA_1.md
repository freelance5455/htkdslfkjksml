# Revisao e correcoes — ADAM KNOWLEDGE (Etapa 1)

Esta versao preserva a arquitetura, os modulos e os contratos existentes do ZIP-base. As mudancas foram feitas sobre os arquivos originais, sem reconstruir o projeto do zero.

## Correcoes realizadas

1. **Recuperacao da fila apos reinicializacao**
   - Tarefas que estavam `processing` voltam para `queued` ao iniciar o servidor, desde que ainda tenham tentativas disponiveis.
   - Tarefas que ja atingiram o limite configurado passam para `failed`, sem ganhar tentativas extras.
   - Tarefas queued sao recolocadas na fila quando o handler correspondente estiver registrado.

2. **CORS e preflight OPTIONS**
   - O servidor responde ao preflight de navegadores.
   - As origens permitidas sao configuradas em `CORS_ALLOWED_ORIGINS`, separadas por ponto e virgula.
   - A configuracao de exemplo permite `Origin: null`, comum quando o HTML e aberto diretamente como arquivo local. Em producao, configure somente a origem necessaria.

3. **Download de arquivos da biblioteca**
   - Novo endpoint autenticado `GET /api/library/:id/file`.
   - Retorna os bytes do arquivo armazenado, com Content-Type conhecido quando possivel e `application/octet-stream` como fallback.
   - Recursos cadastrados apenas como referencia retornam `404 FILE_NOT_FOUND`.

4. **Protecao de caminhos e extensoes**
   - Extensoes aceitam somente letras e numeros, com 1 a 10 caracteres.
   - Caminhos resolvidos precisam permanecer dentro da pasta-base da biblioteca.
   - Leitura e exclusao usam a mesma validacao de caminho.

5. **Documentacao e testes**
   - README, STATUS, API e relatorio de testes atualizados.
   - A suite atual possui 44 testes automatizados.

## Validacao executada

Com Node.js 22 e `node:sqlite`:

```bash
npm test
```

Resultado desta revisao: **44 testes, 44 aprovados, 0 falhas, 0 ignorados**.

Os testes incluem servidor HTTP real em porta local, SQLite isolado, preflight CORS permitido/negado, download binario autenticado, rejeicao de extensao maliciosa e recuperacao de tarefas interrompidas.

## Limites que continuam pendentes

Esta revisao nao transforma o backend em aplicativo Android e nao implementa, por si so, a IA generativa ou motores de criacao de assets. Continuam pendentes:

- Integracao real com provedor de IA generativa (o metodo atual continua sendo ponto de extensao, nao uma chamada funcional).
- Pesquisa dedicada de imagens.
- Geracao de texturas, modelos 3D, animacoes e sons.
- Sincronizacao remota (`POST /api/sync` continua respondendo 501).
- Validacao de pesquisa web contra a internet real em ambiente com conectividade.
- Aplicativo/servico Android para hospedar o backend e manter o processo ativo no celular.
- Integracao do AddonForge com o novo endpoint de download e teste ponta a ponta no navegador Android.

## Configuracao CORS

No `.env`, ajuste `CORS_ALLOWED_ORIGINS`. Exemplo para HTML local:

```env
CORS_ALLOWED_ORIGINS=null
```

Se o AddonForge for servido por um endereco web, substitua `null` pela origem exata, por exemplo `https://seu-dominio.example`. Multiplas origens podem ser separadas por `;`.
