# Affiliate / influencer programme

Influencers promote the academy on their own social media and are paid a **percentage of what the people they bring actually pay**.
Nothing is paid up front.

## How a person is tied to an influencer
1. The influencer shares their personal link, for example `https://yourdomain.com/r/chioma`.
   Any page also works with `?ref=chioma` on the end (e.g. `https://yourdomain.com/courses?ref=chioma`).
2. When someone opens the link, the browser remembers the influencer for **one year** (a signed cookie).
   **First link wins:** if the person later opens a different influencer's link, the first one is kept.
3. **The moment that person creates an account, the influencer is written onto the account permanently.**
   From then on the link no longer matters. The person can close the browser, come back days later by typing the normal address, or log in on
   another phone, and every course they buy is still credited to that influencer.

### Things that are deliberately NOT attributed
* People who already had an account before they followed a link (the programme rewards *new* students only).
* Visitors who never create an account on a browser that still holds the link cookie (a different phone, cleared cookies or a different
  browser *before* signing up cannot be recognised; once they have an account on a link-following browser, it is permanent).
* An influencer's own purchases.
* Link-preview robots (WhatsApp, Facebook, etc.) do not count as clicks and do not set cookies.

## Admin: Affiliates (needs the `affiliates.manage` permission; the owner always has it)
**Admin > Affiliates**
* **Default commission %**: one box at the top. Applies to **future** sales only. Every sale remembers the percentage that applied
  when the payment was approved, so changing it never rewrites history.
* **Add an affiliate**: enter their email (and full name if they have no account yet) and the link name they want. If the email already has
  an account it is upgraded; otherwise an account is created and you are shown a **7-day password-setup link** to send them
  (it is also emailed when SMTP is configured). Optional **personal commission %** overrides the default for that one person.
* **Manage** (per affiliate): see clicks, sign-ups, buyers, earnings and the list of people tied to them; change their link name or
  personal rate; **remove** or **restore** them.
* **Remove** = the link stops working, nothing new is earned (even from people already tied to them), they leave the active list.
  Money already earned stays theirs and can still be paid out. **Restore** switches everything back on.
* **Withdrawal requests** tab: affiliates request a payout from their balance; open their page, upload the transfer receipt (required)
  and tick *Mark as paid*, or decline with a reason. The affiliate is notified and can open the receipt.
* **Affiliate settings** (Admin menu): programme on/off, default %, whether subscription plans also earn commission (default: courses only),
  minimum withdrawal, withdrawals on/off, and the message shown on the affiliate page.

## Affiliate: "My affiliate link"
Every affiliate gets an **Affiliate** link in their dashboard menu: their link with a Copy button, clicks / sign-ups / buyers, balance,
commission history, bank details, withdrawal requests and receipts. They may rename their own link (the old link then stops working).
Other students' names are shown masked (e.g. "Ada O."), never emails.

## Money rules
* Commission = rate x **what the student actually paid** (after promo discounts). Free (100% promo) purchases earn nothing.
* Credited **only when the payment is approved**, exactly once (double approval cannot double-credit; the database enforces it).
* A refund reverses the commission automatically.
* Tutor share and affiliate commission are independent and both come out of the sale. Keep **tutor % + affiliate %** comfortably below 100%.

## Technical notes
* Migration `005_affiliates.sql` (applied automatically on start) adds `affiliates`, `affiliate_clicks`, `affiliate_earnings`, `affiliate_payouts`
  and two columns on `users` (`referred_by_affiliate`, `referred_at`). Existing data is untouched.
* Code: `dagba/services/affiliates.py`, `dagba/blueprints/affiliates.py`, hooks in `services/payments.py` (approve / refund) and `blueprints/auth.py` (sign-up).
* Behind HTTPS set `COOKIE_SECURE=true` (already recommended) so the tracking cookie is also marked secure.
* Tests: `tests/test_affiliates.py`.
