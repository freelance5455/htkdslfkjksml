# Tutor Memorandum of Understanding (MOU) and electronic signature

Applicants must read and sign the academy's MOU before a **tutor application** can be submitted. Existing tutors who submit extra courses are never asked.

## Admin
* **Tutors > Tutor MOU Management** (permission `mou.manage`): start a draft, edit it in the rich-text editor, save, preview exactly as applicants see it, publish. Publishing creates the next version (the first is 1.0; "update" gives 1.1, "major revision" gives 2.0). Published versions are immutable; every version can be viewed and downloaded as PDF; the history shows created / edited / published times and how many tutors signed each version.
* **Tutors > Signed MOU records** (permission `tutors.manage` or `mou.manage`): search by name/email/reference, filter by version, date, status, account type; view or download any agreement; export the register as CSV.
* Tutor profile (**Tutors > select tutor**) and the application page show the tutor's agreements, including earlier versions.
* The first draft starts from a plain template. **Have your own wording reviewed by a legal adviser before publishing.** Until a version is published, applications can be saved but not submitted.

## Applicant and tutor
* The application page has "4. Review and Sign Tutor Memorandum of Understanding" (viewer, full-screen reader, unsigned PDF, tick box, typed-name signature). Draft saving never needs a signature.
* The server re-checks on submit: a published MOU exists, the posted version is the current one, the applicant was shown it, the box is ticked, and the typed name equals the account's full name (case/spacing/Unicode-normalised). The agreement and the submission commit in one transaction.
* Someone who already signed the current version is not asked again (e.g. when resubmitting after a revision request); a newer published version must be signed.
* Approved tutors: **Teaching > My Agreement / Signed MOU** (view, PDF). Tutors only ever reach their own agreements (others get 404).

## Data and integrity
Migration `021_tutor_mou.sql`: `mou_documents`, `mou_versions`, `mou_views`, `mou_acceptances`. Triggers make published versions and signed agreements immutable and undeletable, and refuse an acceptance whose text hash differs from the published version. Each acceptance stores the exact text, the SHA-256 of the text and of the full record, a random reference (`DDA-MOU-YYYY-XXXXXXXX`), IP and user-agent. PDFs are always built from the stored snapshot (`services/mou.py: agreement_pdf`).
A typed name is an electronic signature recording acceptance; it is not identity verification and the system does not claim enforceability.

## PDF fonts
DejaVu Serif or Liberation Serif is used when installed (full accent support, e.g. Yoruba); otherwise the Vera font bundled with reportlab. Characters a font cannot draw are replaced.
