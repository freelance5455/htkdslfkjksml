TPH-X FLIGHT RADAR - BACKEND SERVICE
======================================

A python operational environment optimized for normalizing and serving structural stream requests cleanly without exposing secret credentials to static client bundles.

FAST DEPLOYMENT INSTRUCTIONS
----------------------------
1. Install Python 3.10+
2. Run installation commands:
   $ pip install -r requirements.txt
3. Duplicate configuration framework:
   $ cp .env.example .env
4. Launch the local microservice execution target:
   $ uvicorn main:app --reload --host 127.0.0.1 --port 8000
