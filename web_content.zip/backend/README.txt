GERÇEK YAPAY ZEKÂ BAĞLANTISI HAKKINDA

Bu proje şu anda sohbet ekranı demosudur; gerçek Claude modeline bağlı değildir.

Gerçek bağlantı için:
1. Bir sunucuda güvenli backend kurulmalıdır.
2. Anthropic API anahtarı yalnızca sunucuda saklanmalıdır; Android uygulamasına gömülmemelidir.
3. Backend, uygulamadan gelen mesajları doğrulayıp modele iletmeli ve yanıtı geri göndermelidir.
4. API kullanımı ücret ve sağlayıcı limitlerine tabi olabilir. Sınırsız kullanım garanti edilemez.

Bu klasörde hazır bir API anahtarı veya çalışan sunucu bulunmaz.
