BACKEND CHALANE KE TAREEKE (apne PC / VPS par)

A) Ek saath (Docker): is folder me
     docker compose up -d
   -> Node backend :5000, LiveKit :7880

B) Alag-alag:
     npm install
     node server.js
     docker run -d --rm -p 7880:7880 -p 7881:7881 -p 50000-50050:50000-50050/udp livekit/livekit-server --dev

Check: browser me http://SERVER_IP:5000/health  ->  {"ok":true}

APP ME: Me tab -> "Backend server" -> URL daalo (jaise http://SERVER_IP:5000), LiveKit URL optional (ws://SERVER_IP:7880).

DHYAN:
- Public internet par HTTPS (domain + Nginx/Caddy) lagao.
- LiveKit --dev me keys devkey/secret hoti hain: sirf testing.
- Login: Google idToken se (GOOGLE-LOGIN-SETUP.txt). Socket ko session token chahiye; senderId server login se leta hai.
- Purchase verify abhi band hai (free coins se bachne ke liye).
