import { PrismaClient, Role, LifetimeTier, NumberStatus } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding TempBox database...');

  // 1. Create Admin User
  const adminPassword = await bcrypt.hash('AdminSecret123!', 10);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@tempbox.io' },
    update: {},
    create: {
      email: 'admin@tempbox.io',
      passwordHash: adminPassword,
      role: Role.ADMIN,
      credits: 9999,
      isGuest: false,
    },
  });

  // 2. Create Demo User
  const demoPassword = await bcrypt.hash('DemoPass123!', 10);
  const demoUser = await prisma.user.upsert({
    where: { email: 'user@tempbox.io' },
    update: {},
    create: {
      email: 'user@tempbox.io',
      passwordHash: demoPassword,
      role: Role.USER,
      credits: 65,
      isGuest: false,
    },
  });

  // 3. Create Sample Active Mailbox
  const sampleMailbox = await prisma.mailbox.upsert({
    where: { address: 'verify-fast@tempbox.io' },
    update: {},
    create: {
      userId: demoUser.id,
      address: 'verify-fast@tempbox.io',
      username: 'verify-fast',
      domain: 'tempbox.io',
      lifetimeTier: LifetimeTier.TWENTY_FOUR_HOURS,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      isCustom: true,
    },
  });

  // 4. Create Sample Message with OTP
  await prisma.message.create({
    data: {
      mailboxId: sampleMailbox.id,
      fromAddress: 'security@github.com',
      fromName: 'GitHub Security',
      toAddress: sampleMailbox.address,
      subject: 'Your GitHub verification code is 492019',
      encryptedBody: 'mock_encrypted_body',
      iv: 'mock_iv',
      authTag: 'mock_authtag',
      textPreview: 'Please enter verification code 492019 to complete sign in.',
      extractedOtp: '492019',
      verificationUrl: 'https://github.com/sessions/two-factor',
      isRead: false,
      sizeBytes: 1240,
    },
  });

  // 5. Create Sample Rented Phone Number
  const sampleNumber = await prisma.phoneNumber.upsert({
    where: { number: '+1 (415) 802-3921' },
    update: {},
    create: {
      userId: demoUser.id,
      number: '+1 (415) 802-3921',
      countryCode: 'US',
      provider: 'mock',
      status: NumberStatus.ACTIVE,
      expiresAt: new Date(Date.now() + 20 * 60 * 1000),
      creditsCost: 15,
      receivedSmsQty: 1,
    },
  });

  // 6. Create Sample SMS
  await prisma.smsMessage.create({
    data: {
      phoneNumberId: sampleNumber.id,
      fromNumber: '+1 (800) 555-0199',
      encryptedText: 'mock_sms_encrypted',
      iv: 'mock_iv',
      authTag: 'mock_tag',
      preview: 'Uber code: 7391. Reply STOP to cancel.',
      extractedOtp: '7391',
    },
  });

  console.log('✅ Seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
