#!/usr/bin/env bash
# Consistent backup of the database (SQLite online backup API: safe while the site is running) + uploads, verified, rotated, optionally copied off-site.
# Usage: backup.sh            (uses env vars from /etc/dagba/dagba.env; works for Termux too by exporting the same variables)
set -euo pipefail
APP_DIR="${APP_DIR:-/opt/dagba/current}"; PY="${DAGBA_PY:-/opt/dagba/venv/bin/python}"
DB="${DATABASE_PATH:-/var/lib/dagba/dagba.db}"; PRIV="${PRIVATE_UPLOAD_DIR:-/var/lib/dagba/private}"; PUB="${PUBLIC_UPLOAD_DIR:-/var/lib/dagba/public}"
OUT="${BACKUP_DIR:-/var/lib/dagba/backups}"; KEEP_DAYS="${BACKUP_KEEP_DAYS:-30}"; STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$OUT"; cd "$APP_DIR"
DBOUT="$OUT/dagba-$STAMP.db"
DATABASE_PATH="$DB" "$PY" manage.py backup "$DBOUT" >/dev/null
# verify the copy before trusting it
"$PY" - "$DBOUT" <<'PY'
import sqlite3, sys
c = sqlite3.connect(sys.argv[1]); r = c.execute("PRAGMA integrity_check").fetchone()[0]
n = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
if r != "ok": sys.exit("BACKUP FAILED integrity_check: " + r)
print(f"db ok: {n} users")
PY
gzip -f "$DBOUT"
# uploads change rarely and are large: archive only at the 02:xx run (or when FULL=1), otherwise rely on rsync-style off-site copy
if [ "${FULL:-0}" = 1 ] || [ "$(date -u +%H)" = "02" ]; then
  tar -czf "$OUT/dagba-uploads-$STAMP.tar.gz" -C "$(dirname "$PRIV")" "$(basename "$PRIV")" -C "$(dirname "$PUB")" "$(basename "$PUB")"
fi
( cd "$OUT" && sha256sum dagba-"$STAMP"* > "SHA256SUMS-$STAMP" )
if [ -n "${BACKUP_REMOTE:-}" ]; then
  command -v rclone >/dev/null || { echo "BACKUP_REMOTE is set but rclone is not installed" >&2; exit 2; }
  rclone copy "$OUT" "$BACKUP_REMOTE" --include "dagba-$STAMP*" --include "SHA256SUMS-$STAMP" --quiet
  rclone sync "$PRIV" "$BACKUP_REMOTE/uploads-private" --quiet; rclone sync "$PUB" "$BACKUP_REMOTE/uploads-public" --quiet    # sync = mirror of CURRENT files; deleted uploads vanish there too, so rely on the dated tar archives for history
  echo "off-site copy done"
else echo "WARNING: BACKUP_REMOTE not set - backups exist ONLY on this server" >&2; fi
find "$OUT" -type f -name 'dagba-*' -mtime +"$KEEP_DAYS" -delete; find "$OUT" -type f -name 'SHA256SUMS-*' -mtime +"$KEEP_DAYS" -delete
echo "backup complete: $OUT ($STAMP)"
