#!/usr/bin/env bash
# Cron/monitor helper: exit 1 (and print) if the site is down. Pair with a free uptime monitor (e.g. UptimeRobot) pointed at https://dagbadigitalacademy.com/healthz
curl -fsS --max-time 10 "${1:-http://127.0.0.1:8000}/healthz" >/dev/null && echo up || { echo DOWN; exit 1; }
