#!/usr/bin/env bash
# Restore from backups. SAFE BY DESIGN: stops the site, keeps a copy of the CURRENT data first, asks you to type RESTORE, verifies the database before switching.
# Usage: restore.sh <dagba-....db.gz|.db> [dagba-uploads-....tar.gz]
set -euo pipefail
DB_SRC="${1:?usage: restore.sh <db backup> [uploads tar.gz]}"; UP_SRC="${2:-}"
DB="${DATABASE_PATH:-/var/lib/dagba/dagba.db}"; DATA="$(dirname "$DB")"; PY="${DAGBA_PY:-/opt/dagba/venv/bin/python}"
SAFE="$DATA/pre-restore-$(date -u +%Y%m%dT%H%M%SZ)"
[ -f "$DB_SRC" ] || { echo "No such file: $DB_SRC"; exit 1; }
echo "This will REPLACE the live database${UP_SRC:+ and uploads}. The current data is first copied to $SAFE."
read -r -p "Type RESTORE to continue: " ans; [ "$ans" = RESTORE ] || { echo "Cancelled."; exit 1; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
case "$DB_SRC" in *.gz) gzip -dc "$DB_SRC" > "$TMP/restore.db";; *) cp "$DB_SRC" "$TMP/restore.db";; esac
"$PY" - "$TMP/restore.db" <<'PY'
import sqlite3, sys
c = sqlite3.connect(sys.argv[1]); assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok", "backup is corrupt"
print("backup verified:", c.execute("SELECT COUNT(*) FROM users").fetchone()[0], "users,", c.execute("SELECT COUNT(*) FROM courses").fetchone()[0], "courses")
PY
systemctl stop dagba 2>/dev/null || true
mkdir -p "$SAFE"; [ -f "$DB" ] && cp "$DB" "$SAFE/dagba.db"; rm -f "$DB-wal" "$DB-shm"
[ -n "$UP_SRC" ] && { cp -a "$(dirname "$DB")/private" "$SAFE/private" 2>/dev/null || true; cp -a "$(dirname "$DB")/public" "$SAFE/public" 2>/dev/null || true; }
cp "$TMP/restore.db" "$DB"; chown dagba:dagba "$DB" 2>/dev/null || true
if [ -n "$UP_SRC" ]; then tar -xzf "$UP_SRC" -C "$DATA"; chown -R dagba:dagba "$DATA/private" "$DATA/public" 2>/dev/null || true; fi
systemctl start dagba 2>/dev/null || true
echo "Restored. Previous data kept in $SAFE (delete it yourself once you are sure)."
