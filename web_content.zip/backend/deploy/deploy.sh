#!/usr/bin/env bash
# Zero-surprise release: backup -> unpack new code beside the old -> install deps -> run ADDITIVE migrations -> switch -> health check -> automatic rollback on failure.
# Usage: deploy.sh <release.tar.gz>        (the tarball is the dagba/ source folder, e.g. made with: tar czf release.tar.gz -C dagba .)
set -euo pipefail
TAR="${1:?usage: deploy.sh <release.tar.gz>}"; R=/opt/dagba/releases; NEW="$R/$(date -u +%Y%m%dT%H%M%SZ)"; CUR=/opt/dagba/current; PY=/opt/dagba/venv/bin/python
set -a; . /etc/dagba/dagba.env; set +a
echo ">> 1/6 backup before deploy"; FULL=0 BACKUP_DIR=/var/lib/dagba/backups "$CUR/deploy/backup.sh" 2>/dev/null || [ ! -e "$CUR" ] || { echo "Backup failed - aborting deploy."; exit 1; }
echo ">> 2/6 unpack"; mkdir -p "$NEW"; tar -xzf "$TAR" -C "$NEW"; chown -R dagba:dagba "$NEW"
echo ">> 3/6 dependencies"; sudo -u dagba "$PY" -m pip install -q -r "$NEW/requirements.txt" -r "$NEW/requirements-prod.txt"; [ -f "$NEW/requirements-store.txt" ] && sudo -u dagba "$PY" -m pip install -q -r "$NEW/requirements-store.txt" || true
echo ">> 4/6 migrations (additive, applied once, never drop data)"; (cd "$NEW" && sudo -E -u dagba "$PY" manage.py migrate)
PREV="$(readlink -f "$CUR" 2>/dev/null || true)"
echo ">> 5/6 switch + restart"; ln -sfn "$NEW" "$CUR"; systemctl restart dagba
echo ">> 6/6 health check"; for i in $(seq 1 20); do sleep 2; if curl -fsS http://127.0.0.1:8000/healthz >/dev/null 2>&1; then echo "Healthy. Deployed $NEW"; ls -1dt "$R"/* | tail -n +6 | xargs -r rm -rf; exit 0; fi; done
echo "!! health check failed - rolling back"; [ -n "$PREV" ] && ln -sfn "$PREV" "$CUR" && systemctl restart dagba; echo "Rolled back to $PREV. (Migrations are additive, so the old code still works with the migrated database.)"; exit 1
