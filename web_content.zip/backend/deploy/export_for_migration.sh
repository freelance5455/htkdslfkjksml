#!/usr/bin/env bash
# Run this on the CURRENT host (Termux or any machine). READ-ONLY toward your live data: it makes a consistent copy and a manifest; nothing is deleted or modified.
# Usage: export_for_migration.sh [outfile.tar]   -> default ~/dagba-migration-<date>.tar
set -euo pipefail
APP="${APP_DIR:-$HOME/dagba}"; DATA="${DATA_DIR:-$HOME/dagba-data}"; OUT="${1:-$HOME/dagba-migration-$(date -u +%Y%m%dT%H%M%SZ).tar}"
DB="${DATABASE_PATH:-$DATA/dagba.db}"; PY="${DAGBA_PY:-python}"; [ -f "$DB" ] || { echo "Database not found at $DB (set DATABASE_PATH)"; exit 1; }
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT; mkdir -p "$W/m"
( cd "$APP" && DATABASE_PATH="$DB" "$PY" manage.py backup "$W/m/dagba.db" >/dev/null )
"$PY" - "$W/m/dagba.db" "$W/m/manifest.txt" <<'PY'
import sqlite3, sys
c = sqlite3.connect(sys.argv[1]); assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
with open(sys.argv[2], "w") as f:
    for t in ("users","courses","lessons","transactions","entitlements","certificates","progress","payouts","submissions"):
        try: f.write(f"{t}={c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]}\n")
        except Exception: pass
print(open(sys.argv[2]).read())
PY
tar -cf "$W/m/uploads.tar" -C "$DATA" private public 2>/dev/null || tar -cf "$W/m/uploads.tar" -C "$DATA" $(cd "$DATA" && ls -d private public 2>/dev/null)
( cd "$W/m" && sha256sum dagba.db uploads.tar manifest.txt > SHA256SUMS )
tar -cf "$OUT" -C "$W/m" .
echo "Created $OUT  ($(du -h "$OUT" | cut -f1)). Copy it to the new server (scp/rsync), then run deploy/import_migration.sh there. Your phone's data is untouched."
