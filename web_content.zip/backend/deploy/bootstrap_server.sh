#!/usr/bin/env bash
# One-time setup of a fresh Ubuntu 22.04/24.04 or Debian 12 VPS. Idempotent and NON-DESTRUCTIVE: it never touches existing data directories' contents.
# Run as root:  bash deploy/bootstrap_server.sh
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Run as root (sudo)."; exit 1; }
apt-get update -y
apt-get install -y python3 python3-venv python3-pip rsync curl ufw fail2ban unattended-upgrades logrotate
id dagba >/dev/null 2>&1 || useradd --system --create-home --home-dir /opt/dagba --shell /usr/sbin/nologin dagba
install -d -o dagba -g dagba -m 750 /opt/dagba /opt/dagba/releases /var/lib/dagba /var/lib/dagba/private /var/lib/dagba/public /var/lib/dagba/backups /var/log/dagba
install -d -o root -g dagba -m 750 /etc/dagba /etc/dagba/secrets
[ -f /etc/dagba/dagba.env ] || { install -m 640 -o root -g dagba "$(dirname "$0")/dagba.env.example" /etc/dagba/dagba.env; echo ">> Edit /etc/dagba/dagba.env now (SECRET_KEY!)"; }
[ -d /opt/dagba/venv ] || sudo -u dagba python3 -m venv /opt/dagba/venv
install -m 644 "$(dirname "$0")/dagba.service" /etc/systemd/system/dagba.service
install -m 644 "$(dirname "$0")/dagba-backup.service" /etc/systemd/system/dagba-backup.service
install -m 644 "$(dirname "$0")/dagba-backup.timer" /etc/systemd/system/dagba-backup.timer
install -m 644 "$(dirname "$0")/logrotate.dagba" /etc/logrotate.d/dagba
systemctl daemon-reload; systemctl enable dagba-backup.timer
# Firewall: SSH only. Web traffic arrives through Cloudflare Tunnel (no open port) or, with Caddy, add: ufw allow 80,443/tcp
ufw allow OpenSSH >/dev/null; ufw --force enable
systemctl enable --now fail2ban unattended-upgrades >/dev/null 2>&1 || true
echo "Bootstrap complete. Next: edit /etc/dagba/dagba.env, import your data (deploy/import_migration.sh) and deploy a release (deploy/deploy.sh)."
