#!/usr/bin/env bash
# Run on the NEW server after bootstrap_server.sh. Verifies checksums and record counts. REFUSES to overwrite a database that already contains users.
# Usage: import_migration.sh <dagba-migration-*.tar>
set -euo pipefail
TAR="${1:?usage: import_migration.sh <migration tar>}"; DB="${DATABASE_PATH:-/var/lib/dagba/dagba.db}"; DATA="$(dirname "$DB")"; PY="${DAGBA_PY:-/opt/dagba/venv/bin/python}"
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT; tar -xf "$TAR" -C "$W"
( cd "$W" && sha256sum -c SHA256SUMS ) || { echo "Checksum mismatch: the file was damaged in transfer. Nothing was imported."; exit 1; }
if [ -f "$DB" ] && "$PY" -c "import sqlite3,sys;c=sqlite3.connect('$DB');sys.exit(0 if c.execute('SELECT COUNT(*) FROM users').fetchone()[0]>0 else 1)" 2>/dev/null; then
  echo "The target already has user accounts. Refusing to overwrite. If this is intentional, run deploy/backup.sh first and move $DB aside yourself."; exit 1; fi
systemctl stop dagba 2>/dev/null || true
install -d -o dagba -g dagba "$DATA"; cp "$W/dagba.db" "$DB"; tar -xf "$W/uploads.tar" -C "$DATA"; chown -R dagba:dagba "$DATA"
echo "--- record counts: expected (from source) vs imported ---"
"$PY" - "$DB" "$W/manifest.txt" <<'PY'
import sqlite3, sys
c = sqlite3.connect(sys.argv[1]); bad = 0
for line in open(sys.argv[2]):
    t, n = line.strip().split("="); got = c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]; ok = int(n) == got; bad += not ok
    print(f"{t:14} {n:>8} {got:>8}  {'OK' if ok else 'MISMATCH'}")
sys.exit(1 if bad else 0)
PY
echo "Import verified. Next: deploy a release (deploy/deploy.sh), test with a hosts-file override, THEN switch DNS/tunnel. The source (your phone) still has every record."
