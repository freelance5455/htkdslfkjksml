#!/usr/bin/env python3
"""Dagba Digital Academy management CLI.  Usage: python manage.py <command>
  migrate | seed | create-admin | seed-demo | expire-subscriptions | audit-divisions | backup [path] | run"""
import os, sys, getpass, sqlite3
from werkzeug.security import generate_password_hash
from dagba import create_app, db as dbm
from dagba.config import Config

HERE = os.path.dirname(os.path.abspath(__file__))
MIG = os.path.join(HERE, "migrations")

def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"
    app = create_app()
    if cmd == "migrate":
        print("Applied:", dbm.migrate(app.config["DATABASE"], MIG) or "nothing (up to date)")
    elif cmd == "seed":
        dbm.migrate(app.config["DATABASE"], MIG)
        with app.app_context():
            from dagba.seed import seed_structure; seed_structure()
        print("Structure seeded (categories, policy templates, FAQs, inactive plans).")
    elif cmd == "create-admin":
        dbm.migrate(app.config["DATABASE"], MIG)
        email = os.environ.get("ADMIN_EMAIL") or input("Owner email: ").strip().lower()
        name = os.environ.get("ADMIN_NAME") or input("Owner full name: ").strip()
        pw = os.environ.get("ADMIN_PASSWORD") or getpass.getpass("Password (min 8, letters+numbers): ")
        from dagba.blueprints.auth import check_password_strength
        err = check_password_strength(pw, email)
        if err: sys.exit(err)
        with app.app_context():
            if dbm.val("SELECT 1 FROM users WHERE email=?", (email,)):
                dbm.ex("UPDATE users SET role='admin', is_owner=1, is_active=1, password_hash=? WHERE email=?", (generate_password_hash(pw), email)); print("Existing user promoted to owner.")
            else:
                dbm.ex("INSERT INTO users(email,password_hash,full_name,role,is_owner) VALUES (?,?,?,'admin',1)", (email, generate_password_hash(pw), name)); print("Owner account created.")
    elif cmd == "seed-demo":
        with app.app_context():
            from dagba.demo import seed_demo; seed_demo()
        print("Demo content created. Every demo item is labelled [DEMO]; delete it from the admin dashboard before launch.")
    elif cmd == "expire-subscriptions":
        with app.app_context():
            from dagba.services.access import expire_notifications; print("Notified", expire_notifications(), "expired subscriptions")
    elif cmd == "audit-divisions":      # read-only report: nothing is changed
        with app.app_context():
            rows = dbm.q("""SELECT c.id, c.title, c.division, c.academic_level, c.status, cat.name AS category, cat.division AS cat_division, cat.level AS cat_level FROM courses c LEFT JOIN categories cat ON cat.id=c.category_id
                            WHERE (cat.id IS NOT NULL AND cat.division<>c.division) OR (c.division='academic' AND cat.id IS NOT NULL AND COALESCE(c.academic_level,'basic')<>COALESCE(cat.level,'basic'))
                               OR (c.division<>'academic' AND c.academic_level IS NOT NULL) OR (c.division='income' AND c.academic_level IS NOT NULL) ORDER BY c.id""")
            print("Courses whose division, level and category disagree:", len(rows) or "none")
            for r in rows: print(f"  #{r['id']} {r['title']!r} division={r['division']} level={r['academic_level']} status={r['status']} category={r['category']!r} ({r['cat_division']}/{r['cat_level']})")
            print("Counts by division (published):", {r[0]: r[1] for r in dbm.q("SELECT division, COUNT(*) FROM courses WHERE status='published' GROUP BY division")})
    elif cmd == "backup":
        dest = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "backups", "dagba-backup.db")
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        s = sqlite3.connect(app.config["DATABASE"]); d = sqlite3.connect(dest); s.backup(d); d.close(); s.close(); print("Database backed up to", dest, "(also copy instance/private and instance/public)")
    elif cmd == "run":
        dbm.migrate(app.config["DATABASE"], MIG); app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
    else:
        print(__doc__)

if __name__ == "__main__": main()
