ARCHITECTURE BACKEND À PRÉVOIR
===============================

Le navigateur ne doit jamais contenir de clé API privée.
Architecture recommandée :
Téléphone (application) -> API HTTPS contrôlée -> fournisseur IA.

Le serveur doit :
- authentifier les utilisateurs et vérifier leurs autorisations ;
- stocker les clés dans des variables d'environnement ou un gestionnaire de secrets ;
- limiter le nombre et la taille des requêtes ;
- valider les fichiers et les entrées ;
- appliquer des quotas et journaliser les erreurs sans enregistrer les secrets ;
- retourner des états explicites (en attente, terminé, échec) pour les tâches longues ;
- protéger les données des projets et permettre leur suppression.

Routes à concevoir et tester avant activation :
POST /api/chat
POST /api/image/jobs
POST /api/video/jobs
POST /api/music/jobs
GET  /api/jobs/{id}
GET  /api/projects
POST /api/projects
DELETE /api/projects/{id}

Aucune de ces routes n'est implémentée dans ce ZIP. Ce document est un plan, pas un backend opérationnel.
