import { router, json, error, secrets } from '@appdeploy/sdk';

type ChatMessage = { role: 'user' | 'assistant'; content: string };
const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta';
const RUNWAY_BASE = 'https://api.dev.runwayml.com/v1';
const RUNWAY_VERSION = '2024-11-06';

async function getGeminiKey() {
  try {
    return await secrets.readSecret('GEMINI_API_KEY');
  } catch {
    return null;
  }
}

async function getRunwayKey() {
  try {
    return await secrets.readSecret('RUNWAYML_API_SECRET');
  } catch {
    return null;
  }
}

async function getLumaKey() {
  try {
    return await secrets.readSecret('LUMA_API_KEY');
  } catch {
    return null;
  }
}

async function geminiRequest(model: string, apiKey: string, body: Record<string, unknown>) {
  const response = await fetch(`${GEMINI_BASE}/models/${model}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const details = await response.json().catch(() => ({})) as { error?: { message?: string } };
    console.error('Gemini API request failed', { model, status: response.status, message: details.error?.message || 'No provider details' });
    throw new Error(`Gemini request failed with status ${response.status}`);
  }
  return await response.json() as {
    candidates?: Array<{
      content?: {
        parts?: Array<{
          text?: string;
          inlineData?: { data?: string; mimeType?: string };
          inline_data?: { data?: string; mime_type?: string };
        }>;
      };
    }>;
  };
}

async function runwayRequest(path: string, apiKey: string, init?: RequestInit) {
  const response = await fetch(`${RUNWAY_BASE}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
      'X-Runway-Version': RUNWAY_VERSION,
      ...(init?.headers || {}),
    },
  });
  const payload = await response.json().catch(() => ({})) as Record<string, unknown> & {
    error?: string | { message?: string };
    id?: string;
    status?: string;
    output?: string[];
  };
  if (!response.ok) {
    const providerMessage = typeof payload.error === 'string' ? payload.error : payload.error?.message;
    console.error('Runway API request failed', { path, status: response.status, message: providerMessage || 'No provider details' });
    if (response.status === 401) throw new Error('Runway rejected the API key. Check the RUNWAYML_API_SECRET setting.');
    if (response.status === 402 || response.status === 429) throw new Error('Runway could not start this generation. Check available credits and API usage limits.');
    throw new Error(`Runway request failed (HTTP ${response.status}). ${providerMessage || 'Please try again.'}`);
  }
  return payload;
}

async function lumaRequest(path: string, apiKey: string, init?: RequestInit) {
  const response = await fetch(`https://api.lumalabs.ai/dream-machine/v1${path}`, {
    ...init,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
      ...(init?.headers || {}),
    },
  });
  const payload = await response.json().catch(() => ({})) as Record<string, unknown> & {
    detail?: string;
    id?: string;
    state?: string;
    failure_reason?: string;
    assets?: { video?: string };
  };
  if (!response.ok) {
    const detail = typeof payload.detail === 'string' ? payload.detail : 'No provider details';
    console.error('Luma API request failed', { path, status: response.status, message: detail });
    if (response.status === 401 || response.status === 403) throw new Error('Luma rejected the API key or this key does not have video API access. Check the key in your Luma API dashboard.');
    if (response.status === 402 || response.status === 429) throw new Error('Luma could not start this video. Check your API credits and usage limits.');
    throw new Error(`Luma request failed (HTTP ${response.status}). ${detail}`);
  }
  return payload;
}

export const handler = router({
  'GET /api/_healthcheck': [async () => json({ message: 'Success' })],
  'GET /api/integrations/gemini/status': [async () => {
    const names = await secrets.listSecretNames();
    return json({ configured: names.includes('GEMINI_API_KEY') });
  }],
  'GET /api/integrations/runway/status': [async () => {
    const names = await secrets.listSecretNames();
    return json({ configured: names.includes('RUNWAYML_API_SECRET') });
  }],
  'GET /api/integrations/luma/status': [async () => {
    const names = await secrets.listSecretNames();
    return json({ configured: names.includes('LUMA_API_KEY') });
  }],
  'POST /api/chat': [async ({ body }) => {
    try {
      const payload = body as { messages?: ChatMessage[] };
      const messages = Array.isArray(payload?.messages) ? payload.messages.slice(-20) : [];
      if (!messages.length || messages.some(m => !m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string')) {
        return error('Please send a valid conversation.', 400);
      }
      const apiKey = await getGeminiKey();
      if (!apiKey) return error('Google AI is not connected yet. Configure the GEMINI_API_KEY secret in AppDeploy.', 503);
      const contents = messages.map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content.slice(0, 12000) }],
      }));
      const result = await geminiRequest('gemini-3.5-flash', apiKey, {
        systemInstruction: { parts: [{ text: 'You are pretixbot.beta, a helpful general-purpose AI assistant. Answer questions across science, math, homework, writing, coding, reasoning, and everyday topics. Explain hard ideas clearly, solve math step by step when useful, support learning, and be honest when uncertain.' }] },
        contents,
        generationConfig: { maxOutputTokens: 4096 },
      });
      const answer = result.candidates?.[0]?.content?.parts?.map(part => part.text || '').filter(Boolean).join('\n').trim();
      return answer ? json({ answer }) : error('Google AI returned an empty answer. Please try again.', 502);
    } catch (e) {
      console.error('Gemini chat request failed', e);
      return error('Google AI could not answer. Check that the API key is valid and the model is enabled for your Google AI project.', 503);
    }
  }],
  'POST /api/pixelster/image': [async ({ body }) => {
    try {
      const payload = body as { prompt?: string; ratio?: string };
      const prompt = typeof payload?.prompt === 'string' ? payload.prompt.trim().slice(0, 1800) : '';
      const allowedRatios = ['1:1', '16:9', '9:16', '4:3', '3:4', '2:1', '1:2', '3:2', '2:3', '4:5', '5:4'];
      const ratio = allowedRatios.includes(String(payload?.ratio)) ? String(payload?.ratio) : '16:9';
      if (!prompt) return error('Please describe the image you want.', 400);
      const response = await fetch('https://ahm7xmakki.com/api/tti', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, ratio }),
      });
      const result = await response.json().catch(() => ({})) as { success?: boolean; imageUrl?: string; error?: string; message?: string };
      if (!response.ok || !result.success || typeof result.imageUrl !== 'string' || !result.imageUrl.startsWith('https://')) {
        console.error('PixelSter image generation failed', { status: response.status, message: result.message || result.error || 'No provider details' });
        return error(result.message || result.error || 'PixelSter could not create the image. Please try again shortly.', response.status === 429 ? 429 : 502);
      }
      return json({ imageUrl: result.imageUrl, mimeType: 'image/png', provider: 'pixelster' });
    } catch (e) {
      console.error('PixelSter image generation request failed', e);
      return error('Could not reach the free image generator. Please try again later.', 503);
    }
  }],
  'POST /api/pixelster/video': [async ({ body }) => {
    try {
      const payload = body as { prompt?: string; ratio?: string; duration?: number; imageBase64?: string; imageUrl?: string };
      const prompt = typeof payload?.prompt === 'string' ? payload.prompt.trim().slice(0, 1200) : '';
      let imageBase64 = typeof payload?.imageBase64 === 'string' ? (payload.imageBase64.includes(',') ? payload.imageBase64.slice(payload.imageBase64.indexOf(',') + 1) : payload.imageBase64) : '';
      let imageUrl = typeof payload?.imageUrl === 'string' && payload.imageUrl.startsWith('https://') ? payload.imageUrl : '';
      const ratio = payload?.ratio === '9:16' ? '9:16' : '16:9';
      const requestedDuration = Math.round(Number(payload?.duration) || 10);
      const duration = [5, 10, 15, 20].reduce((best, candidate) => Math.abs(candidate - requestedDuration) < Math.abs(best - requestedDuration) ? candidate : best, 10);
      if (!prompt) return error('Please describe the scene and motion for your video.', 400);

      // Text-to-video now accepts a starting image generated in a separate request,
      // so image generation and motion synthesis do not share one long request.
      const hasUploadedImage = Boolean(imageBase64);
      if (!imageBase64 && !imageUrl) {
        const framePrompt = 'Create one clear, high-quality starting frame for a video based on this scene. Preserve the requested subject and visual style and compose it for natural animation. If visible words are requested, include them in the scene: ' + prompt;
        const imageResponse = await fetch('https://ahm7xmakki.com/api/tti', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: framePrompt.slice(0, 1800), ratio }),
        });
        const imageResult = await imageResponse.json().catch(() => ({})) as { success?: boolean; imageUrl?: string; error?: string; message?: string };
        if (!imageResponse.ok || !imageResult.success || typeof imageResult.imageUrl !== 'string' || !imageResult.imageUrl.startsWith('https://')) {
          console.error('Text-to-video starting image failed', { status: imageResponse.status, message: imageResult.message || imageResult.error || 'No provider details' });
          return error(imageResult.message || imageResult.error || 'Could not create a starting image for this text-to-video request. Try again or upload a photo.', imageResponse.status === 429 ? 429 : 502);
        }
        imageUrl = imageResult.imageUrl;
      }

      if (!imageBase64 && imageUrl) {
        let parsedImageUrl: URL;
        try { parsedImageUrl = new URL(imageUrl); } catch { return error('The starting image link was invalid. Please retry.', 400); }
        const imageHost = parsedImageUrl.hostname.toLowerCase();
        const isIpLiteral = imageHost.includes(':') || /^\d{1,3}(?:\.\d{1,3}){3}$/.test(imageHost);
        const isLocalHost = !imageHost.includes('.') || imageHost === 'localhost' || imageHost.endsWith('.localhost') || imageHost.endsWith('.local') || imageHost.endsWith('.internal');
        if (parsedImageUrl.protocol !== 'https:' || isIpLiteral || isLocalHost || parsedImageUrl.username || parsedImageUrl.password) {
          return error('The starting image link is not a valid public HTTPS image link. Please retry.', 400);
        }
        const frameResponse = await fetch(parsedImageUrl.toString());
        if (!frameResponse.ok) return error('The starting image was created but could not be loaded for animation. Please retry.', 502);
        const frameBytes = new Uint8Array(await frameResponse.arrayBuffer());
        if (frameBytes.length > 3500000) return error('The generated starting image is too large for the video service. Please retry with a simpler prompt.', 413);
        let binary = '';
        for (let i = 0; i < frameBytes.length; i += 0x8000) binary += String.fromCharCode(...frameBytes.subarray(i, i + 0x8000));
        imageBase64 = btoa(binary);
      }

      if (imageBase64.length > 5000000) return error('Use a smaller source image to create a video.', 400);
      const motionPrompt = hasUploadedImage ? prompt : 'Animate this generated starting frame into a coherent video. Show clear visible motion and camera movement when appropriate. Scene and action: ' + prompt;
      const response = await fetch('https://ahm7xmakki.com/api/ptv', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: motionPrompt, ratio, duration, imageBase64 }),
      });
      const result = await response.json().catch(() => ({})) as { success?: boolean; videoUrl?: string; error?: string; message?: string };
      if (!response.ok || !result.success || typeof result.videoUrl !== 'string' || !result.videoUrl.startsWith('https://')) {
        console.error('PixelSter video generation failed', { status: response.status, message: result.message || result.error || 'No provider details' });
        return error(result.message || result.error || 'The video service could not animate this scene. Try a simpler prompt or upload a photo.', response.status === 429 ? 429 : 502);
      }
      return json({ videoUrl: result.videoUrl, mimeType: 'video/mp4', provider: 'pixelster', duration, mode: hasUploadedImage ? 'image-to-video' : 'text-to-video' });
    } catch (e) {
      console.error('PixelSter video generation request failed', e);
      return error('Could not reach the video or starting-image service. Please try again later.', 503);
    }
  }],
  'POST /api/image': [async ({ body }) => {
    try {
      const payload = body as { prompt?: string };
      const prompt = typeof payload?.prompt === 'string' ? payload.prompt.trim().slice(0, 1800) : '';
      if (!prompt) return error('Please describe the image you want.', 400);
      const apiKey = await getGeminiKey();
      if (!apiKey) return error('Google AI is not connected yet. Configure the GEMINI_API_KEY secret in AppDeploy.', 503);
      const result = await geminiRequest('gemini-3.1-flash-image', apiKey, {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseModalities: ['TEXT', 'IMAGE'] },
      });
      const parts = result.candidates?.[0]?.content?.parts || [];
      const imagePart = parts.find(part => part.inlineData?.data || part.inline_data?.data);
      const imageData = imagePart?.inlineData?.data || imagePart?.inline_data?.data;
      const mimeType = imagePart?.inlineData?.mimeType || imagePart?.inline_data?.mime_type || 'image/png';
      return imageData ? json({ image: imageData, mimeType }) : error('Google AI did not return an image. Check model access or try a different prompt.', 502);
    } catch (e) {
      console.error('Gemini image request failed', e);
      return error('Image generation failed. Check the GEMINI_API_KEY secret, model access, and Google AI quota/billing.', 503);
    }
  }],
  'POST /api/video': [async ({ body }) => {
    try {
      const payload = body as { prompt?: string; duration?: number; provider?: string };
      const prompt = typeof payload?.prompt === 'string' ? payload.prompt.trim().slice(0, 1800) : '';
      const provider = payload?.provider === 'luma' ? 'luma' : 'runway';
      const duration = [5, 8, 9, 10].includes(Number(payload?.duration)) ? Number(payload.duration) : (provider === 'luma' ? 5 : 8);
      if (!prompt) return error('Please describe the video you want.', 400);
      if (provider === 'luma') {
        const apiKey = await getLumaKey();
        if (!apiKey) return error('Luma is not connected yet. Add the LUMA_API_KEY secret in AppDeploy.', 503);
        const lumaDuration = duration >= 8 ? '9s' : '5s';
        const task = await lumaRequest('/generations/video', apiKey, {
          method: 'POST',
          body: JSON.stringify({ model: 'ray-2', prompt, aspect_ratio: '16:9', resolution: '720p', duration: lumaDuration, loop: false }),
        });
        if (typeof task.id !== 'string' || !task.id) return error('Luma did not return a video generation ID. Please try again.', 502);
        return json({ taskId: task.id, duration: lumaDuration === '9s' ? 9 : 5, provider });
      }
      const apiKey = await getRunwayKey();
      if (!apiKey) return error('Runway is not connected yet. Add the RUNWAYML_API_SECRET key in AppDeploy.', 503);
      const runwayDuration = [5, 8, 10].includes(duration) ? duration : 8;
      const task = await runwayRequest('/image_to_video', apiKey, {
        method: 'POST',
        body: JSON.stringify({ model: 'gen4.5', promptText: prompt, ratio: '1280:720', duration: runwayDuration }),
      });
      if (typeof task.id !== 'string' || !task.id) return error('Runway did not return a video task ID. Please try again.', 502);
      return json({ taskId: task.id, duration: runwayDuration, provider });
    } catch (e) {
      console.error('Video generation start failed', e);
      return error(e instanceof Error ? e.message : 'The video provider could not start generation. Check API access and credits.', 503);
    }
  }],
  'POST /api/video/status': [async ({ body }) => {
    try {
      const payload = body as { taskId?: string; provider?: string };
      const taskId = typeof payload?.taskId === 'string' ? payload.taskId : '';
      const provider = payload?.provider === 'luma' ? 'luma' : 'runway';
      if (!/^[a-zA-Z0-9-]{8,100}$/.test(taskId)) return error('Invalid video task ID.', 400);
      let videoUrl = '';
      if (provider === 'luma') {
        const apiKey = await getLumaKey();
        if (!apiKey) return error('Luma is not connected yet. Add the LUMA_API_KEY secret in AppDeploy.', 503);
        const task = await lumaRequest(`/generations/${encodeURIComponent(taskId)}`, apiKey);
        if (task.state === 'failed') {
          console.error('Luma video generation failed', { taskId, reason: task.failure_reason || 'No failure reason provided' });
          return error(`Luma could not generate this video. ${task.failure_reason || 'Try a different prompt or check API access and credits.'}`, 502);
        }
        if (task.state !== 'completed') return json({ done: false, status: task.state || 'queued' });
        videoUrl = typeof task.assets?.video === 'string' ? task.assets.video : '';
      } else {
        const apiKey = await getRunwayKey();
        if (!apiKey) return error('Runway is not connected yet. Add the RUNWAYML_API_SECRET key in AppDeploy.', 503);
        const task = await runwayRequest(`/tasks/${encodeURIComponent(taskId)}`, apiKey);
        if (task.status === 'FAILED' || task.status === 'CANCELED') {
          console.error('Runway video task did not succeed', { taskId, status: task.status, failureCode: task.failureCode });
          return error('Runway could not generate this video. Try another prompt or check your credits.', 502);
        }
        if (task.status !== 'SUCCEEDED') return json({ done: false, status: task.status || 'PENDING' });
        videoUrl = Array.isArray(task.output) && typeof task.output[0] === 'string' ? task.output[0] : '';
      }
      if (!videoUrl.startsWith('https://')) return error('The video provider finished without returning a video file.', 502);
      const videoResponse = await fetch(videoUrl);
      if (!videoResponse.ok) {
        console.error('Generated video download failed', { provider, status: videoResponse.status });
        return error('The provider created the video, but it could not be downloaded. Please retry.', 502);
      }
      const bytes = new Uint8Array(await videoResponse.arrayBuffer());
      let binary = '';
      for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
      return json({ done: true, video: btoa(binary), mimeType: 'video/mp4' });
    } catch (e) {
      console.error('Video status/download failed', e);
      return error(e instanceof Error ? e.message : 'Video generation or download failed. Please try again.', 503);
    }
  }],
});