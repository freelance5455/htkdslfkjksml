# MasterFlow Trading — Trusted Market Gateway v7

MasterFlow v7 uses **Twelve Data as the sole market-data provider** for quote and historical OHLCV analysis. There is deliberately **no Yahoo Finance/demo fallback** so the app never mixes an unverified public fallback into trading signals.

## Important timing
- **US:** Twelve Data lists real-time stock data, subject to account/exchange entitlement.
- **IDX/XIDX:** Twelve Data currently lists Indonesia Stock Exchange as **EOD**. Therefore MasterFlow labels IDX analysis as `EOD`, not `LIVE`.
- Other exchanges use the timing/entitlement exposed by Twelve Data and are labeled `PROVIDER` when the feed timing is not asserted by this backend.

## Setup
1. Create a Twelve Data API key.
2. Copy `.env.example` to `.env`.
3. Set `TWELVEDATA_API_KEY`.
4. Install requirements.
5. Run:

```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

The APK/frontend talks only to this backend. Keep the API key out of the APK.

## Analysis
The backend calculates Trend, Momentum, Volume, Volatility, RSI, MACD, confluence, entry, stop loss, TP1 and R:R from Twelve Data OHLCV. These are analytical calculations and do not guarantee profit.

Auto-trading/order execution is intentionally disabled.
