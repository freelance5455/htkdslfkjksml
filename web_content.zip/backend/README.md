# Backend
The shared Supabase backend is already connected and active in project `tysaigoafdsjztsbjuso`.
- Edge Function `hanimex-care-admin` is deployed (version 3, JWT verification enabled).
- The migration SQL documents the database schema/RLS/realtime changes already applied.
- The apps contain only the public publishable key. The service-role key remains server-side in Supabase Edge Function secrets.
