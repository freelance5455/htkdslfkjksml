# V1 IA — guia de instalação

Sua V1 IA é um chat responsivo para celular e computador, com interface inspirada em aplicativos modernos de conversa e backend Node.js para manter a chave da API fora do navegador.

## O que vem neste projeto

- `public/index.html`: estrutura da interface.
- `public/styles.css`: visual responsivo, tema escuro/claro.
- `public/app.js`: lógica do chat, sugestões, histórico temporário e cópia de respostas.
- `server.js`: servidor e integração com a API.
- `.env.example`: modelo de configuração da chave.
- `package.json`: dependências e comandos.

## Requisitos

- Node.js 20 ou superior.
- Uma chave de API válida da OpenAI e uma conta de API com faturamento/limites configurados. A assinatura do ChatGPT não inclui automaticamente créditos da API; o uso da API pode ser cobrado separadamente.

## Instalação no computador

1. Extraia o ZIP para uma pasta.
2. Instale Node.js 20 ou superior: https://nodejs.org/
3. Abra o terminal dentro da pasta `v1_ia`.
4. Instale as dependências:

   ```bash
   npm install
   ```

5. Copie `.env.example` para um arquivo chamado `.env`.
   - Windows PowerShell: `Copy-Item .env.example .env`
   - macOS/Linux: `cp .env.example .env`

6. Abra `.env` e substitua `cole_sua_chave_aqui` pela sua chave de API. Você pode ajustar `OPENAI_MODEL` para um modelo disponível na sua conta.
7. Inicie o servidor:

   ```bash
   npm start
   ```

8. Abra http://localhost:3000 no navegador.

## Usar no celular

O jeito mais simples é executar o servidor num computador e abrir o endereço local desse computador no celular, ambos conectados à mesma rede Wi-Fi. No celular, use `http://IP-LOCAL-DO-COMPUTADOR:3000` (descubra o IP local do computador). Talvez seja necessário permitir a conexão na firewall. Para acessar pela internet, publique o backend em um serviço de hospedagem com HTTPS e configure a chave como variável de ambiente.

## Segurança

- **Nunca coloque a chave de API no HTML ou no JavaScript do navegador.** Ela fica no `.env` e o servidor faz a chamada à API.
- Nunca publique o `.env`, tire-o do ZIP que for compartilhar e não envie sua chave a ninguém.
- O servidor inclui limite simples de requisições e limite do tamanho das mensagens, mas antes de publicar para outras pessoas adicione autenticação, monitoramento, limites de custo e proteção contra abuso.
- A interface não salva as conversas permanentemente: elas ficam apenas na memória da página e desaparecem ao recarregar/fechar.

## Solução de problemas

- **“A API ainda não foi configurada”**: confirme que criou `.env` na mesma pasta que `server.js`.
- **Chave recusada**: confira a chave e se a conta da API está habilitada.
- **Limite ou crédito da API atingido**: confira os limites e faturamento da conta de API.
- **Não foi possível acessar o servidor**: execute `npm start` no terminal e mantenha essa janela aberta.
- **Porta em uso**: altere `PORT=3000` no `.env` para outra porta, como `PORT=3001`.

## Observações

Este é um projeto inicial funcional, não uma cópia do ChatGPT nem um modelo de IA treinado por você. As respostas inteligentes vêm do modelo indicado em `OPENAI_MODEL` por meio da API. A disponibilidade e o custo dependem da sua conta e do modelo escolhido.
