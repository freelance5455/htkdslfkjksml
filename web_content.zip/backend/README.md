# MasterFlow Multi-Market Public Gateway

Providers:
- IDX: GOAPI when `GOAPI_API_KEY` is configured; documentation states IDX prices are delayed about 3–10 minutes.
- Global/US/HK/JP/SG: Alpha Vantage when `ALPHAVANTAGE_API_KEY` is configured. Its documentation supports global equities; free/public quote freshness is not assumed realtime.
- Fallback: Yahoo Finance public chart endpoint.

Secrets stay on the backend. Never place provider keys in the APK or chat.

Run: `pip install -r requirements.txt && uvicorn main:app --host 0.0.0.0 --port 8000`
