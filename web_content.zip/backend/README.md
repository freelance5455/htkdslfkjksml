# Backend setup

1. Install Node.js 20+.
2. Install PostgreSQL.
3. Create a database named `rewarded_ssv`.
4. Copy `.env.example` to `.env`.
5. Set `DATABASE_URL`.
6. Run:

```bash
npm install
psql "$DATABASE_URL" -f sql/schema.sql
npm start
```

The SSV endpoint is:

`GET /v1/admob/ssv`

For production, expose it through HTTPS and configure that URL in the AdMob
rewarded ad unit's Server-side verification settings.

The sample's `/api/bootstrap` and `X-User-Id` mechanism is intentionally simple.
Replace it with the authentication system from the real Messenger backend.
