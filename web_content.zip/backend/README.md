# MasterFlow Live Gateway

Backend-only live data gateway. No order, cancel, withdrawal, or transfer endpoints.

## US / Webull
1. Copy `.env.example` to `.env` on your server.
2. Put Webull OpenAPI credentials in the server environment only.
3. Activate the required Webull OpenAPI market-data subscription.
4. Set `WEBULL_ENABLED=true`.
5. Run: `pip install -r requirements.txt && uvicorn main:app --host 0.0.0.0 --port 8000`

Endpoints:
- `/health`
- `/provider-status`
- `/live/quote?symbol=AAPL`
- `/analyze?symbol=AAPL`

The APK/browser must never receive `WEBULL_APP_SECRET`.

## IDX
`/idx/quote` is an adapter placeholder for a licensed IDX data provider. Do not label IDX as LIVE until a provider is connected and returning current market data.
