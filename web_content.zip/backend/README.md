# Dagba Digital Academy: Website + Learning Management System

*Simplifying Knowledge. Building Excellence. Equipping for the Real World.*

A complete, self-hostable academy platform: public website, LMS, student / instructor / writer / admin dashboards,
**manual Nigerian bank-transfer payments (works at launch with no gateway account)**, subscriptions with separate entitlements,
certificates with public verification, blog / nuggets / testimonials CMS, notifications, audit log and reports.

**Stack:** Python 3.12, Flask (modular monolith), SQLite (WAL) with SQL migrations, Jinja2 templates, hand-written responsive CSS,
ReportLab (certificates + QR), Pillow (image validation). No JavaScript framework, no proprietary services.
> The original brief preferred React/Node/PostgreSQL/Tailwind. The build environment had no internet access, so that stack could not be
> installed or tested. Everything here was built and tested with what could actually run. See `docs/STATUS.md` for the honest list of differences and limitations.

## Quick start (5 minutes)
```bash
python3 -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt                        # exact tested versions: requirements.lock
cp .env.example .env                                   # edit SECRET_KEY and SITE_URL
python manage.py migrate
python manage.py seed                                  # categories, policy templates, FAQs, inactive plans (no fake content)
python manage.py create-admin                          # creates the OWNER account
python manage.py run                                   # http://localhost:5000
python -m unittest discover -s tests -t .              # 269 automated tests
```
Optional: `python manage.py seed-demo` adds clearly-labelled **[DEMO]** courses/users (instructor@demo.test, writer@demo.test, student@demo.test, password `Demo12345`) for trying things out. Delete them before launch.

## Adding a course (one page)
Admin > **+ New course** (or **Course catalog**): everything on a single page, saved in one click.
1. **Basics**: title, division, category, summary, description, cover image.
2. **Price & access** (admin).
3. **Curriculum**: add modules and lessons. For video lessons choose a file from your phone/computer: it uploads **directly to your own server** (MP4 or WebM, default limit 500 MB, adjustable in Site settings). Large videos upload in small pieces and **resume automatically** if the connection drops. Or paste a YouTube/Vimeo link instead. Attach PDFs/documents, add notes, mark free previews.
4. **Quiz** (optional) with questions and a correct answer.
5. **Save as draft**, or **Save & publish** (instructors: *submit for review*). Editing later keeps learner progress.

**Admin > Course catalog** lists every course as cards with status, price, lessons, uploaded videos, quizzes, learners and (with the right permission) revenue; filter, search, sort, publish/unpublish/archive, export CSV.

## Faith & Spiritual Growth
Bible studies, Christian living, prayer, biblical wisdom, relationships and spiritual growth as video, audio and study-material lessons, inside the same site, accounts and admin. Each series is a paid course with free preview lessons. See `docs/FAITH.md`.

## Academic section
Academic courses are organised into **Basic** (secondary school), **Advanced** (university level) and **Professional Development** (coming soon), each with its own subjects. See `docs/ADMIN_GUIDE.md`.

## Tutor earnings
Tutors get a dashboard of purchases and earnings (40% of each individual course sale, configurable) and can request withdrawals; admins pay them and upload a receipt before the request is completed. See `docs/ADMIN_GUIDE.md`.

## Website theme
**Admin > Theme & colours** changes the whole site's look (colours, fonts, corner roundness, width, banner style, dark mode, optional custom CSS) with ready-made
presets and a live preview; one click restores the original. Visitors get a **moon / sun button in the header** to switch the whole site between light and dark mode. See `docs/THEME.md`.

## Affiliates / influencers
Influencers get a personal link (`/r/their-name`). Anyone who signs up through it is tied to them permanently, so every course that person buys later
(even from another phone, using the normal web address) earns the influencer a percentage. The owner sets the default percentage, can give individual
affiliates their own rate, and can add / remove affiliates from **Admin > Affiliates**; affiliates withdraw their earnings by bank transfer like tutors do.
See `docs/AFFILIATES.md`.

## Editing the website without code
**Admin > Website text & menus** edits the wording of every public page, the header menu and footer, homepage sections (show/hide, cards, steps), headings, buttons and messages, payment-page and notification wording; **Branding** uploads your logo/favicon and sets colours; **Pages** creates new pages. See `docs/ADMIN_GUIDE.md`; `docs/STATUS.md` lists exactly what remains in code.

## First steps as owner
1. Log in, open **Bank transfer**, enter your bank name, account name, account number. Students see it instantly.
2. **Subscription plans**: set prices, then tick *Active*. **Categories / Courses**: add your content.
3. **Site settings / Homepage / Branding**: edit contact details, hero text, colours.
4. Review the **Pages** (Privacy, Terms, Refund). They are *templates*; have them reviewed before launch.
5. **Users**: create instructors / writers / payment officers and tick the exact permissions each staff member needs.

## Run it on an Android phone
See `docs/TERMUX_GUIDE.md` (step-by-step, with one-command scripts in `scripts/`). Fine for demos and pilots, not a substitute for a real server.

## Documentation (`docs/`)
`INSTALL.md` · `ENVIRONMENT.md` · `DATABASE.md` · `ADMIN_GUIDE.md` · `PAYMENTS.md` (bank transfer setup, verifying payments, future gateways) · `DEPLOYMENT.md` · `BACKUP_RECOVERY.md` · `TROUBLESHOOTING.md` · `STATUS.md`
