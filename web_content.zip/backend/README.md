# MDCAT/NUMS Prep backend — next step

This version adds:
- student registration/login with hashed passwords
- JWT authentication
- SQLite database
- progress synchronization
- mistake synchronization
- question bank storage
- premium-only questions
- Google Play subscription verification

## Run
1. Install Node.js.
2. Copy `.env.example` to `.env`.
3. Set a strong JWT_SECRET.
4. Configure Google Play service-account credentials for billing verification.
5. `npm install`
6. `npm start`

## Endpoints
POST /api/auth/register
POST /api/auth/login
GET /api/me
GET /api/questions
GET /api/progress
POST /api/progress
POST /api/play/verify-subscription

Do not put `.env` or the Google service-account key into the APK or Git.
Use HTTPS when deployed.
For production, add Google Play RTDN handling, backups, rate limiting, audit logging and a managed database.


## New production pieces
- `/api/play/rtdn` receives Google Play Real-time Developer Notifications through Pub/Sub.
- `/api/admin/questions/import` imports your original/licensed question bank using an admin token.
- Subscription state is refreshed when RTDN events arrive.

For production, authenticate Pub/Sub push requests, configure HTTPS, rate-limit endpoints, and use a managed database rather than local SQLite if you expect significant traffic.
