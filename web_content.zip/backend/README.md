# ADAM KNOWLEDGE — Backend (Primeira Etapa)

Núcleo de inteligência, pesquisa, banco de dados e API de comunicação com o
AddonForge. Esta é a **fundação real** do sistema: código funcional, testado,
sem simulações nem funções vazias.

> Para a arquitetura completa, o que foi realmente concluído e o que ainda
> falta, veja [`docs/STATUS.md`](docs/STATUS.md).

## Por que não há dependências externas obrigatórias

Esta primeira versão foi construída usando **apenas recursos nativos do
Node.js 22** (SQLite embutido via `node:sqlite`, `fetch` nativo, um roteador
HTTP próprio sobre `node:http`). Isso foi uma decisão deliberada: o ambiente
onde a primeira versão foi escrita não tinha acesso à internet para rodar
`npm install`, então o núcleo foi construído para funcionar sem isso. Na sua
máquina, com internet disponível, você pode (e deve, eventualmente) trocar
peças por bibliotecas mais robustas — isso está documentado em
`docs/ARCHITECTURE.md`, seção "Pontos de evolução".

## Requisitos

- Node.js **22 ou superior** (usa o módulo experimental `node:sqlite`)
- Nenhuma dependência externa é necessária para rodar o núcleo

## Instalação e execução

```bash
# 1. Copie o arquivo de ambiente e configure os valores (principalmente o token)
cp .env.example .env
# edite o .env e defina um ADDONFORGE_TOKEN forte

# 2. Rode as migrations (cria o banco SQLite e as tabelas)
npm run migrate

# 3. Inicie o servidor
npm start
```

O servidor sobe por padrão em `http://127.0.0.1:4100`. Veja todos os
endpoints em [`docs/API.md`](docs/API.md).

### Habilitando pesquisa web real

Sem configuração, o sistema **informa claramente** que a pesquisa web não
está disponível — ele nunca inventa resultados. Para habilitar:

```bash
# no .env:
WEB_SEARCH_PROVIDER=duckduckgo_html   # funciona sem chave de API (ver limitações abaixo)
```

Para um provedor de produção mais estável (com API oficial e chave), veja
`src/research/search-providers/generic-api-provider.js` e configure:

```bash
WEB_SEARCH_PROVIDER=generic_api
WEB_SEARCH_API_KEY=sua-chave-aqui
```

### Habilitando um provedor de IA real

Também desligado por padrão, e também informado claramente quando ausente:

```bash
AI_PROVIDER=anthropic
AI_API_KEY=sua-chave-aqui
AI_MODEL=claude-sonnet-4-6
```

A chamada real ao provedor (`IntelligenceOrchestrator.callAiProvider`) está
preparada como ponto de extensão, mas a implementação completa da integração
é um item da próxima etapa (ver `docs/STATUS.md`).

## Rodando os testes

```bash
npm test
```

Isso executa a suíte completa (44 testes nesta versão) usando o test runner
nativo do Node (`node --test`), cobrindo banco de dados, task engine,
request analyzer, leitura de páginas web e a API HTTP de ponta a ponta. Veja
o relatório completo em [`docs/TEST_REPORT.md`](docs/TEST_REPORT.md).

## Estrutura do projeto

```
adam-knowledge/
├── src/
│   ├── config/            # carregamento de configuração/.env
│   ├── core/               # ADAM KNOWLEDGE CORE: orquestrador, task engine, analisador de pedidos
│   ├── database/           # conexão SQLite, migrations, repositories
│   ├── research/           # ADAM WEB RESEARCH ENGINE: pesquisa web + leitura de páginas
│   ├── resources/          # ADAM RESOURCE LIBRARY: texturas, modelos, animações, sons, docs
│   ├── communication/      # ADAM ADDONFORGE BRIDGE: API HTTP, autenticação
│   ├── monitor/            # ADAM SYSTEM MONITOR: diagnóstico real do sistema
│   ├── utils/              # logger
│   ├── app.js              # fábrica do servidor (sem iniciar)
│   └── server.js           # ponto de entrada (roda migrations + inicia o servidor)
├── tests/                  # testes automatizados (node --test)
├── storage/
│   ├── database/           # arquivo .db do SQLite (gerado, não versionado)
│   └── resources/          # arquivos reais de texturas/modelos/animações/sons/docs
├── docs/                   # documentação detalhada
├── package.json
└── .env.example
```

## O que esta primeira etapa NÃO inclui (de propósito)

Conforme a especificação original (seção 18, "limites desta primeira
etapa"), os motores avançados de **criação** (geração de texturas, modelos
3D, animações, sons) ficam para a segunda etapa. Esta entrega cobre a
**fundação de pesquisa, armazenamento, orquestração e comunicação**. Lista
completa em `docs/STATUS.md`.

## Preparação para APK Android

Este ZIP contém o backend Node.js, não um projeto Android. Antes de empacotar, confirme se a ferramenta escolhida executa Node.js no Android ou se apenas cria uma WebView para HTML. Um empacotador somente-HTML não executa este servidor nem hospeda o SQLite. Consulte [`docs/APKFORGE_PREPARACAO.md`](docs/APKFORGE_PREPARACAO.md) para os requisitos e limitações.

## Próximos passos sugeridos

1. Revisar `docs/STATUS.md` e priorizar os itens pendentes.
2. Trocar o roteador HTTP caseiro por Express/Fastify quando `npm install`
   estiver disponível no ambiente de desenvolvimento (opcional — o atual
   funciona, mas um framework maduro reduz manutenção a longo prazo).
3. Implementar o `ADAM IMAGE RESEARCH` dedicado (hoje reaproveita a pesquisa
   web genérica).
4. Implementar a integração real com um provedor de IA.
5. Começar o desenvolvimento do aplicativo Android, consumindo esta API
   (contrato já documentado e estável em `docs/API.md`).
