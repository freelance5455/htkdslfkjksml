package com.webapk.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewFeature
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private lateinit var overlay: View

    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private var pendingPermRequest: PermissionRequest? = null
    private var pendingChooser: (() -> Unit)? = null
    private var pendingDownload: (() -> Unit)? = null

    private val siteHost = Uri.parse(BuildConfig.SITE_URL).host ?: ""

    // www/ ফোল্ডারের ফাইল https://appassets.androidplatform.net/assets/... ঠিকানায় সার্ভ হয়
    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    // ---------- Activity result launchers ----------
    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val cb = filePathCallback ?: return@registerForActivityResult
        var results: Array<Uri>? = null
        if (res.resultCode == RESULT_OK) {
            val data = res.data
            val clip = data?.clipData
            results = when {
                clip != null -> Array(clip.itemCount) { clip.getItemAt(it).uri }
                data?.data != null -> arrayOf(data.data!!)
                cameraUri != null -> arrayOf(cameraUri!!)
                else -> null
            }
        }
        cb.onReceiveValue(results)
        filePathCallback = null
    }
    private val webPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        pendingPermRequest?.let { req ->
            val ok = req.resources.filter { r -> androidPerm(r)?.let { granted(it) } == true }
            if (ok.isNotEmpty()) req.grant(ok.toTypedArray()) else req.deny()
        }
        pendingPermRequest = null
    }
    private val cameraPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pendingChooser?.invoke(); pendingChooser = null
    }
    private val storagePermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pendingDownload?.invoke() else toast(R.string.download_failed)
        pendingDownload = null
    }

    private val chrome = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, p: Int) {
            progress.progress = p
            progress.visibility = if (p < 100) View.VISIBLE else View.GONE
        }

        override fun onShowFileChooser(wv: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = cb
            if (granted(Manifest.permission.CAMERA)) launchChooser(params)
            else { pendingChooser = { launchChooser(params) }; cameraPermLauncher.launch(Manifest.permission.CAMERA) }
            return true
        }

        override fun onPermissionRequest(request: PermissionRequest) {
            runOnUiThread {
                val host = request.origin.host
                val grantable = request.resources.filter { androidPerm(it) != null }
                if (!isSiteHost(host) || grantable.isEmpty()) { request.deny(); return@runOnUiThread }
                val missing = grantable.mapNotNull { androidPerm(it) }.filter { !granted(it) }
                if (missing.isEmpty()) request.grant(grantable.toTypedArray())
                else { pendingPermRequest = request; webPermLauncher.launch(missing.toTypedArray()) }
            }
        }

        override fun onShowCustomView(view: View, cb: CustomViewCallback) {
            if (customView != null) { cb.onCustomViewHidden(); return }
            customView = view; customCallback = cb
            root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            swipe.visibility = View.GONE
            setBars(false)
        }

        override fun onHideCustomView() {
            customView?.let { root.removeView(it) }
            customView = null
            customCallback?.onCustomViewHidden(); customCallback = null
            swipe.visibility = View.VISIBLE
            if (!BuildConfig.FULLSCREEN) setBars(true)
        }
    }

    // ---------- JS bridge (share / copy / retry) ----------
    inner class Bridge {
        @JavascriptInterface fun share(title: String?, text: String?, url: String?) {
            runOnUiThread {
                val body = listOfNotNull(text, url).filter { it.isNotBlank() }.joinToString("\n")
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, title); putExtra(Intent.EXTRA_TEXT, body)
                }
                startActivity(Intent.createChooser(i, null))
            }
        }
        @JavascriptInterface fun copy(text: String?) {
            runOnUiThread {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("text", text ?: ""))
                toast(R.string.copied)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        requestedOrientation = when (BuildConfig.ORIENTATION) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        root = findViewById(R.id.root); webView = findViewById(R.id.webview)
        swipe = findViewById(R.id.swipe); progress = findViewById(R.id.progress); overlay = findViewById(R.id.overlay)
        if (BuildConfig.FULLSCREEN) setBars(false)

        setupWebView()
        swipe.setOnRefreshListener { refresh() }
        swipe.setOnChildScrollUpCallback { _, _ -> webView.scrollY > 0 }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> chrome.onHideCustomView()
                    webView.canGoBack() -> webView.goBack()
                    else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })

        if (savedInstanceState != null) webView.restoreState(savedInstanceState) else loadSite(deepLink(intent) ?: BuildConfig.SITE_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(webView, true) }
        applyDarkening()
        webView.addJavascriptInterface(Bridge(), "AndroidApp")
        webView.webChromeClient = chrome

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                return when (uri.scheme) {
                    "https" -> if (isSiteHost(uri.host)) false else { openExternal(Intent(Intent.ACTION_VIEW, uri)); true }
                    "http" -> false // cleartext is blocked by the app config -> shows error page
                    "file", "javascript", "data", "blob" -> true
                    "intent" -> {
                        try {
                            val i = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                            i.component = null; i.selector = null; i.addCategory(Intent.CATEGORY_BROWSABLE)
                            openExternal(i)
                        } catch (e: Exception) { toast(R.string.no_app) }
                        true
                    }
                    else -> { openExternal(Intent(Intent.ACTION_VIEW, uri)); true } // tel:, mailto:, sms:, geo:, ...
                }
            }
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                progress.visibility = View.VISIBLE
            }
            override fun onPageFinished(view: WebView, url: String?) {
                swipe.isRefreshing = false
                overlay.visibility = View.GONE
                view.evaluateJavascript(SHARE_POLYFILL, null)
            }
        }

        webView.setDownloadListener { url, ua, cd, mime, _ ->
            if (url.startsWith("blob:") || url.startsWith("data:")) { toast(R.string.download_unsupported); return@setDownloadListener }
            val start = {
                try {
                    val name = URLUtil.guessFileName(url, cd, mime)
                    val req = DownloadManager.Request(Uri.parse(url)).apply {
                        setMimeType(mime); addRequestHeader("User-Agent", ua)
                        CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                        setTitle(name)
                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                    }
                    (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                    toast(R.string.download_started)
                } catch (e: Exception) { toast(R.string.download_failed) }
            }
            if (Build.VERSION.SDK_INT <= 28 && !granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                pendingDownload = start; storagePermLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            } else start()
        }
    }

    // ---------- helpers ----------
    private fun loadSite(url: String) { webView.loadUrl(url) }
    private fun refresh() { if (webView.url == null) loadSite(BuildConfig.SITE_URL) else webView.reload() }
    private fun isSiteHost(h: String?): Boolean {
        if (h == null || siteHost.isEmpty()) return false
        val base = siteHost.removePrefix("www."); val x = h.removePrefix("www.")
        return x == base || x.endsWith(".$base")
    }
    private fun deepLink(i: Intent?): String? {
        val u = i?.data ?: return null
        return if (u.scheme == "https" && isSiteHost(u.host)) u.toString() else null
    }
    private fun openExternal(i: Intent) {
        try { startActivity(i) } catch (e: ActivityNotFoundException) { toast(R.string.no_app) }
    }
    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun androidPerm(res: String) = when (res) {
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
        else -> null
    }
    private fun toast(id: Int) = Toast.makeText(this, id, Toast.LENGTH_SHORT).show()

    private fun setBars(show: Boolean) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (show) c.show(WindowInsetsCompat.Type.systemBars())
        else {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }
    private fun applyDarkening() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(webView.settings, night)
        }
    }

    private fun launchChooser(params: WebChromeClient.FileChooserParams) {
        val accept = params.acceptTypes.map { it.trim() }.filter { it.isNotEmpty() }.mapNotNull {
            if (it.startsWith(".")) MimeTypeMap.getSingleton().getMimeTypeFromExtension(it.substring(1).lowercase()) else it
        }
        val wantsImage = accept.isEmpty() || accept.any { it.startsWith("image") || it == "*/*" }
        val wantsVideo = accept.any { it.startsWith("video") }
        val cams = mutableListOf<Intent>()
        cameraUri = null
        if (granted(Manifest.permission.CAMERA)) {
            if (wantsImage) {
                try {
                    val dir = File(cacheDir, "captures").apply { mkdirs() }
                    cameraUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", File.createTempFile("IMG_", ".jpg", dir))
                    cams += Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).putExtra(android.provider.MediaStore.EXTRA_OUTPUT, cameraUri)
                } catch (e: Exception) { cameraUri = null }
            }
            if (wantsVideo) cams += Intent(android.provider.MediaStore.ACTION_VIDEO_CAPTURE)
        }
        val intent = if (params.isCaptureEnabled && cams.isNotEmpty()) cams[0] else {
            val content = Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = if (accept.size == 1) accept[0] else "*/*"
                if (accept.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, accept.toTypedArray())
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
            }
            Intent.createChooser(content, null).putExtra(Intent.EXTRA_INITIAL_INTENTS, cams.toTypedArray())
        }
        try { fileLauncher.launch(intent) } catch (e: Exception) {
            filePathCallback?.onReceiveValue(null); filePathCallback = null
        }
    }

    // ---------- lifecycle ----------
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        deepLink(intent)?.let { loadSite(it) }
    }
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig); applyDarkening()
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && (BuildConfig.FULLSCREEN || customView != null)) setBars(false)
    }
    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); webView.saveState(outState) }
    override fun onResume() { super.onResume(); webView.onResume() }
    override fun onDestroy() { webView.destroy(); super.onDestroy() }

    companion object {
        private const val SHARE_POLYFILL = """
            (function(){ try{ if(!window.AndroidApp) return;
              navigator.share=function(d){d=d||{};AndroidApp.share(d.title||'',d.text||'',d.url||'');return Promise.resolve();};
              navigator.canShare=function(d){return !(d&&d.files&&d.files.length);};
            }catch(e){} })();
        """
    }
}
