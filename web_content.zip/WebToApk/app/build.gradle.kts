plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.webapk.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.webapk.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // www/ ফোল্ডারের index.html অ্যাপের ভিতরে চলবে
        buildConfigField("String", "SITE_URL", "\"https://appassets.androidplatform.net/assets/index.html\"")
        // "auto" | "portrait" | "landscape"
        buildConfigField("String", "ORIENTATION", "\"auto\"")
        // true হলে স্ট্যাটাস/নেভিগেশন বার লুকানো থাকবে
        buildConfigField("boolean", "FULLSCREEN", "false")
    }
    buildFeatures { buildConfig = true }
    sourceSets { getByName("main") { assets.srcDirs("../www") } }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
