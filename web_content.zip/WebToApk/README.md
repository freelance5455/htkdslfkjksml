# Website → APK (offline, সব ফাইল অ্যাপের ভিতরে)

1. আপনার পুরো ওয়েবসাইট (index.html, css, js, images...) `www/` ফোল্ডারে রাখুন। `www/index.html` প্রথমে খুলবে।
2. Android Studio তে Open → Sync → Build → Build APK(s)।
3. নাম: `res/values/strings.xml` (app_name), আইডি: `applicationId` (app/build.gradle.kts)।
4. ফাইলের লিংক relative দিন (`css/style.css`), `/css/..` নয়।
