StudyGrid - offline installable app (PWA)

1. Unzip this folder.
2. Serve it over https or localhost (browsers only allow install/offline from those):
   - Quick local test:  python3 -m http.server 8080   then open http://localhost:8080
   - Or upload the folder to any static host (Netlify, GitHub Pages, Cloudflare Pages).
3. Open it in Chrome/Edge/Safari and choose "Install app" / "Add to Home Screen".
After the first load it works fully offline. Data is saved on the device.
