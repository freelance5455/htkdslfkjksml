# LiquiSound - Android APK Build Guide

This directory contains the complete source code for **LiquiSound**, ready to run offline or package as an Android APK!

## Option 1: Run Instantly on any Device
Simply double-click `index.html` in any web browser (Chrome, Edge, Safari, Firefox). No build step required!

## Option 2: 1-Click Android APK (via PWA2APK / Bubblewrap)
1. Upload this folder to GitHub Pages, Netlify, or Vercel.
2. Go to [pwabuilder.com](https://www.pwabuilder.com/)
3. Enter your deployed URL.
4. Click **"Generate Android APK"** and download your signed `.apk` installer directly to your Android device!

## Option 3: Compile with Capacitor / Android Studio
Run the following in this folder:
```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init LiquiSound com.liquisound.app --web-dir .
npx cap add android
npx cap open android
```
Inside Android Studio:
Click **Build > Build Bundle(s) / APK(s) > Build APK(s)** to generate your `app-debug.apk`!

Enjoy the music and liquid glass reflections!
