const scene = new THREE.Scene();
scene.background = new THREE.Color(0x63b8ff);
scene.fog = new THREE.FogExp2(0x98d4ff, 0.0034);

const camera = new THREE.PerspectiveCamera(
  65,
  Math.max(1, window.innerWidth) / Math.max(1, window.innerHeight),
  0.1,
  450
);

const renderer = new THREE.WebGLRenderer({
  antialias: true,
  powerPreference: "high-performance"
});
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);

// Procedural Terrain Texture for Realistic Ground
function createTerrainTexture() {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#477a32';
  ctx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 2400; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const r = 1 + Math.random() * 2.4;
    ctx.fillStyle = i % 3 === 0 ? 'rgba(110, 172, 68, 0.28)' : 'rgba(38, 76, 25, 0.24)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(38, 38);
  return tex;
}

// Sky Dome + Glowing Sun
const skyDome = new THREE.Mesh(
  new THREE.SphereGeometry(330, 24, 16),
  new THREE.MeshBasicMaterial({ color: 0x5ab2fa, side: THREE.BackSide })
);
scene.add(skyDome);

const sunPos = new THREE.Vector3(90, 120, 75);
const sunMesh = new THREE.Mesh(
  new THREE.SphereGeometry(13, 16, 16),
  new THREE.MeshBasicMaterial({ color: 0xfff5b8 })
);
sunMesh.position.copy(sunPos);
scene.add(sunMesh);

// Smooth Lighting + Shadows
const hemiLight = new THREE.HemisphereLight(0xe6f4ff, 0x385925, 1.0);
scene.add(hemiLight);

const dirLight = new THREE.DirectionalLight(0xfff3d8, 1.22);
dirLight.position.copy(sunPos);
dirLight.castShadow = true;
dirLight.shadow.mapSize.width = 1024;
dirLight.shadow.mapSize.height = 1024;
dirLight.shadow.camera.near = 15;
dirLight.shadow.camera.far = 300;
const shadowBound = 115;
dirLight.shadow.camera.left = -shadowBound;
dirLight.shadow.camera.right = shadowBound;
dirLight.shadow.camera.top = shadowBound;
dirLight.shadow.camera.bottom = -shadowBound;
scene.add(dirLight);

// Ground & Safe Zone
const terrainTex = createTerrainTexture();
const groundGeo = new THREE.PlaneGeometry(340, 340, 24, 24);
groundGeo.rotateX(-Math.PI / 2);
const groundMat = new THREE.MeshStandardMaterial({
  map: terrainTex,
  roughness: 0.8,
  metalness: 0.04
});
const ground = new THREE.Mesh(groundGeo, groundMat);
ground.receiveShadow = true;
scene.add(ground);

let zoneRadius = 125;
const zoneGeo = new THREE.CylinderGeometry(1, 1, 45, 32, 1, true);
const zoneMat = new THREE.MeshBasicMaterial({
  color: 0x0099ff,
  transparent: true,
  opacity: 0.22,
  side: THREE.DoubleSide
});
const zoneMesh = new THREE.Mesh(zoneGeo, zoneMat);
zoneMesh.scale.set(zoneRadius, 1, zoneRadius);
zoneMesh.position.y = 22.5;
scene.add(zoneMesh);

// Gloo Wall Mesh Builder
const glooShellMat = new THREE.MeshStandardMaterial({
  color: 0xdff7ff,
  transparent: true,
  opacity: 0.72,
  roughness: 0.22,
  metalness: 0.15
});
const glooCoreMat = new THREE.MeshStandardMaterial({
  color: 0x90e0ef,
  transparent: true,
  opacity: 0.45,
  roughness: 0.35
});

function createGlooWallMesh() {
  const g = new THREE.Group();
  const mainShield = new THREE.Mesh(new THREE.BoxGeometry(3.8, 2.5, 0.45), glooShellMat);
  mainShield.position.y = 1.25;
  mainShield.castShadow = true;
  mainShield.receiveShadow = true;

  const topArch = new THREE.Mesh(new THREE.CylinderGeometry(1.9, 1.9, 0.45, 16, 1, false, 0, Math.PI), glooCoreMat);
  topArch.rotation.z = Math.PI / 2;
  topArch.rotation.y = Math.PI / 2;
  topArch.position.y = 2.5;

  g.add(mainShield, topArch);
  return g;
}

// Realistic Human Proportions (Male & Female Adults, Knee & Elbow Joints, Different T-Shirts)
function createSmoothCharacter(options) {
  const opts = options || {};
  const gender = opts.gender === 'female' ? 'female' : 'male';
  const topColor = opts.topColor || 0x1e88e5;
  const bottomColor = opts.bottomColor || 0x263238;
  const hairColor = opts.hairColor || 0x1b1714;
  const skinColor = opts.skinColor || 0xf1be96;

  const rootGroup = new THREE.Group();
  const bodyRig = new THREE.Group();
  rootGroup.add(bodyRig);

  const skinMat = new THREE.MeshStandardMaterial({ color: skinColor, roughness: 0.58 });
  const hairMat = new THREE.MeshStandardMaterial({ color: hairColor, roughness: 0.68 });
  const shirtMat = new THREE.MeshStandardMaterial({ color: topColor, roughness: 0.55 });
  const pantsMat = new THREE.MeshStandardMaterial({ color: bottomColor, roughness: 0.7 });
  const bootMat = new THREE.MeshStandardMaterial({ color: 0x14171c, roughness: 0.5 });
  const soleMat = new THREE.MeshStandardMaterial({ color: 0xe6e9ef, roughness: 0.65 });
  const gunMat = new THREE.MeshStandardMaterial({ color: 0x22272f, metalness: 0.62, roughness: 0.28 });

  const isFemale = gender === 'female';
  const heightScale = isFemale ? 0.96 : 1.03;

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.105, 0.125, 0.16, 12), skinMat);
  neck.position.y = 1.75;
  neck.castShadow = true;
  bodyRig.add(neck);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.275, 16, 14), skinMat);
  head.scale.set(0.9, 1.08, 0.96);
  head.position.y = 2.06;
  head.castShadow = true;
  bodyRig.add(head);

  const nose = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.08, 0.08), skinMat);
  nose.position.set(0, 2.04, 0.265);
  nose.castShadow = true;
  bodyRig.add(nose);

  [-0.245, 0.245].forEach(function(ex) {
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 10), skinMat);
    ear.scale.set(0.5, 0.9, 0.7);
    ear.position.set(ex, 2.05, -0.01);
    bodyRig.add(ear);
  });

  if (!isFemale) {
    const maleHair = new THREE.Mesh(new THREE.SphereGeometry(0.292, 14, 12), hairMat);
    maleHair.scale.set(0.95, 0.64, 1.03);
    maleHair.position.set(0, 2.18, -0.025);
    maleHair.castShadow = true;
    bodyRig.add(maleHair);
  } else {
    const femaleCrown = new THREE.Mesh(new THREE.SphereGeometry(0.302, 16, 14), hairMat);
    femaleCrown.scale.set(0.98, 0.86, 1.04);
    femaleCrown.position.set(0, 2.13, -0.03);
    femaleCrown.castShadow = true;

    const backHair = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.66, 0.16), hairMat);
    backHair.position.set(0, 1.82, -0.22);
    backHair.rotation.x = 0.14;
    backHair.castShadow = true;

    bodyRig.add(femaleCrown, backHair);
  }

  const chestW = isFemale ? 0.32 : 0.41;
  const waistW = isFemale ? 0.245 : 0.33;
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(chestW, waistW, 0.82, 14), shirtMat);
  torso.scale.set(1.06, 1, 0.62);
  torso.position.y = 1.32;
  torso.castShadow = true;
  bodyRig.add(torso);

  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.135, 0.025, 8, 16), shirtMat);
  collar.rotation.x = Math.PI / 2;
  collar.position.set(0, 1.72, 0.02);
  bodyRig.add(collar);

  function buildLeg(side) {
    const xOff = side * (isFemale ? 0.14 : 0.17);
    const hipPivot = new THREE.Group();
    hipPivot.position.set(xOff, 0.9, 0);

    const thigh = new THREE.Mesh(new THREE.CylinderGeometry(0.112, 0.092, 0.42, 12), pantsMat);
    thigh.position.y = -0.21;
    thigh.castShadow = true;
    hipPivot.add(thigh);

    const kneeJoint = new THREE.Mesh(new THREE.SphereGeometry(0.092, 10, 10), pantsMat);
    kneeJoint.position.y = -0.42;
    kneeJoint.castShadow = true;
    hipPivot.add(kneeJoint);

    const kneePivot = new THREE.Group();
    kneePivot.position.set(0, -0.42, 0);

    const shin = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.072, 0.4, 12), isFemale ? skinMat : pantsMat);
    shin.position.y = -0.2;
    shin.castShadow = true;

    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.11, 0.29), bootMat);
    boot.position.set(0, -0.41, 0.045);
    boot.castShadow = true;

    const sole = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.035, 0.3), soleMat);
    sole.position.set(0, -0.465, 0.045);

    kneePivot.add(shin, boot, sole);
    hipPivot.add(kneePivot);

    bodyRig.add(hipPivot);
    return { hip: hipPivot, knee: kneePivot };
  }

  function buildArm(side) {
    const xOff = side * (isFemale ? 0.365 : 0.445);
    const shoulderPivot = new THREE.Group();
    shoulderPivot.position.set(xOff, 1.66, 0);

    const sleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.092, 0.086, 0.2, 12), shirtMat);
    sleeve.position.y = -0.09;
    sleeve.castShadow = true;
    shoulderPivot.add(sleeve);

    const upperArm = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.07, 0.32, 12), skinMat);
    upperArm.position.y = -0.16;
    upperArm.castShadow = true;
    shoulderPivot.add(upperArm);

    const elbowPivot = new THREE.Group();
    elbowPivot.position.set(0, -0.32, 0);

    const foreArm = new THREE.Mesh(new THREE.CylinderGeometry(0.068, 0.056, 0.32, 12), skinMat);
    foreArm.position.y = -0.16;
    foreArm.castShadow = true;

    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.066, 10, 10), skinMat);
    hand.scale.set(0.9, 1.15, 0.8);
    hand.position.y = -0.33;
    hand.castShadow = true;

    elbowPivot.add(foreArm, hand);
    shoulderPivot.add(elbowPivot);

    bodyRig.add(shoulderPivot);
    return { shoulder: shoulderPivot, elbow: elbowPivot };
  }

  const leftLeg = buildLeg(-1);
  const rightLeg = buildLeg(1);
  const leftArm = buildArm(-1);
  const rightArm = buildArm(1);

  const rifle = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.14, 0.88), gunMat);
  rifle.position.set(0, -0.26, 0.34);
  rifle.castShadow = true;
  rightArm.elbow.add(rifle);

  rightArm.shoulder.rotation.x = -0.65;
  rightArm.elbow.rotation.x = -0.55;

  rootGroup.scale.setScalar(heightScale);

  rootGroup.userData = {
    gender: gender,
    bodyRig: bodyRig,
    leftLeg: leftLeg.hip,
    leftKnee: leftLeg.knee,
    rightLeg: rightLeg.hip,
    rightKnee: rightLeg.knee,
    leftArm: leftArm.shoulder,
    leftElbow: leftArm.elbow,
    rightArm: rightArm.shoulder,
    rightElbow: rightArm.elbow,
    walkTime: 0,
    landSquash: 0
  };
  return rootGroup;
}

function createLowPolyCharacter(shirtColor, pantsColor, gender) {
  return createSmoothCharacter({
    gender: gender || 'male',
    topColor: shirtColor,
    bottomColor: pantsColor
  });
}

// Hollow Buildings with Stairs + Wall Colliders
const colliders = [];
const stairsList = [];

const wallMat = new THREE.MeshStandardMaterial({ color: 0xd6dde6, roughness: 0.72 });
const trimMat = new THREE.MeshStandardMaterial({ color: 0xb83227, roughness: 0.62 });
const stairMat = new THREE.MeshStandardMaterial({ color: 0x78848e, roughness: 0.78 });

function addWallCollider(x, z, w, d) {
  colliders.push({
    x: x,
    z: z,
    hw: w / 2 + 0.35,
    hd: d / 2 + 0.35
  });
}

function createHollowBuildingWithStairs(cx, cz, width, depth, wallHeight) {
  const group = new THREE.Group();
  group.position.set(cx, 0, cz);

  const thickness = 0.8;
  const doorGap = 3.2;

  const backZ = -depth / 2 + thickness / 2;
  const backWall = new THREE.Mesh(new THREE.BoxGeometry(width, wallHeight, thickness), wallMat);
  backWall.position.set(0, wallHeight / 2, backZ);
  backWall.castShadow = true;
  backWall.receiveShadow = true;
  group.add(backWall);
  addWallCollider(cx, cz + backZ, width, thickness);

  const leftX = -width / 2 + thickness / 2;
  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(thickness, wallHeight, depth), wallMat);
  leftWall.position.set(leftX, wallHeight / 2, 0);
  leftWall.castShadow = true;
  leftWall.receiveShadow = true;
  group.add(leftWall);
  addWallCollider(cx + leftX, cz, thickness, depth);

  const rightX = width / 2 - thickness / 2;
  const rightWall = new THREE.Mesh(new THREE.BoxGeometry(thickness, wallHeight, depth), wallMat);
  rightWall.position.set(rightX, wallHeight / 2, 0);
  rightWall.castShadow = true;
  rightWall.receiveShadow = true;
  group.add(rightWall);
  addWallCollider(cx + rightX, cz, thickness, depth);

  const frontZ = depth / 2 - thickness / 2;
  const sidePartW = Math.max(1.5, (width - doorGap) / 2);

  const frontLeft = new THREE.Mesh(new THREE.BoxGeometry(sidePartW, wallHeight, thickness), wallMat);
  frontLeft.position.set(-width / 2 + sidePartW / 2, wallHeight / 2, frontZ);
  frontLeft.castShadow = true;
  frontLeft.receiveShadow = true;

  const frontRight = new THREE.Mesh(new THREE.BoxGeometry(sidePartW, wallHeight, thickness), wallMat);
  frontRight.position.set(width / 2 - sidePartW / 2, wallHeight / 2, frontZ);
  frontRight.castShadow = true;
  frontRight.receiveShadow = true;

  const lintelH = 1.0;
  const frontTop = new THREE.Mesh(new THREE.BoxGeometry(doorGap, lintelH, thickness), trimMat);
  frontTop.position.set(0, wallHeight - lintelH / 2, frontZ);
  frontTop.castShadow = true;

  group.add(frontLeft, frontRight, frontTop);
  addWallCollider(cx - width / 2 + sidePartW / 2, cz + frontZ, sidePartW, thickness);
  addWallCollider(cx + width / 2 - sidePartW / 2, cz + frontZ, sidePartW, thickness);

  const deckDepth = depth * 0.42;
  const deckZ = -depth / 2 + deckDepth / 2 + thickness / 2;
  const deck = new THREE.Mesh(new THREE.BoxGeometry(width - thickness, 0.4, deckDepth), trimMat);
  deck.position.set(0, wallHeight, deckZ);
  deck.castShadow = true;
  deck.receiveShadow = true;
  group.add(deck);

  const stepsCount = 8;
  const stepRise = wallHeight / stepsCount;
  const stepRun = 0.65;
  const stairX = width / 2 - thickness - 1.3;
  const startStepZ = deckZ + deckDepth / 2 + stepsCount * stepRun * 0.45;

  for (let s = 0; s < stepsCount; s++) {
    const h = (s + 1) * stepRise;
    const step = new THREE.Mesh(
      new THREE.BoxGeometry(1.8, h, stepRun),
      stairMat
    );
    const sz = startStepZ - s * stepRun;
    step.position.set(stairX, h / 2, sz);
    step.castShadow = true;
    step.receiveShadow = true;
    group.add(step);

    stairsList.push({
      x: cx + stairX,
      z: cz + sz,
      hw: 1.0,
      hd: stepRun * 0.65,
      topY: h
    });
  }

  scene.add(group);
}

const buildingCoords = [
  [-32, -28, 12, 12, 4.8],
  [36, -34, 14, 12, 5.2],
  [-45, 38, 12, 14, 4.8],
  [42, 35, 13, 13, 5.0],
  [0, -68, 14, 12, 5.2],
  [-75, -10, 12, 12, 4.6],
  [78, 8, 12, 12, 4.6],
  [12, 72, 13, 12, 5.0]
];

buildingCoords.forEach(function(b) {
  createHollowBuildingWithStairs(b[0], b[1], b[2], b[3], b[4]);
});

// Big Trees
const bigTrunkMat = new THREE.MeshStandardMaterial({ color: 0x59371e, roughness: 0.88 });
const bigLeafMat1 = new THREE.MeshStandardMaterial({ color: 0x236827, roughness: 0.78 });
const bigLeafMat2 = new THREE.MeshStandardMaterial({ color: 0x2e8532, roughness: 0.75 });

for (let i = 0; i < 34; i++) {
  const x = (Math.random() - 0.5) * 260;
  const z = (Math.random() - 0.5) * 260;
  if (Math.hypot(x, z) < 12) continue;

  const scaleFactor = 1.4 + Math.random() * 1.1;
  const treeGroup = new THREE.Group();
  treeGroup.position.set(x, 0, z);

  const trunkH = 5.5 * scaleFactor;
  const trunkR = 0.55 * scaleFactor;
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(trunkR * 0.72, trunkR, trunkH, 8),
    bigTrunkMat
  );
  trunk.position.y = trunkH / 2;
  trunk.castShadow = true;
  trunk.receiveShadow = true;
  treeGroup.add(trunk);

  const crown1 = new THREE.Mesh(
    new THREE.ConeGeometry(4.2 * scaleFactor, 7.5 * scaleFactor, 8),
    bigLeafMat1
  );
  crown1.position.y = trunkH + 2.6 * scaleFactor;
  crown1.castShadow = true;

  const crown2 = new THREE.Mesh(
    new THREE.ConeGeometry(3.2 * scaleFactor, 6.2 * scaleFactor, 8),
    bigLeafMat2
  );
  crown2.position.y = trunkH + 5.2 * scaleFactor;
  crown2.castShadow = true;

  treeGroup.add(crown1, crown2);
  scene.add(treeGroup);

  colliders.push({
    x: x,
    z: z,
    hw: trunkR + 0.4,
    hd: trunkR + 0.4
  });
}

// Loot & Medkit Crates
const loots = [];
const lootGeo = new THREE.BoxGeometry(1.0, 1.0, 1.0);
const lootMat = new THREE.MeshStandardMaterial({
  color: 0x00ff88,
  emissive: 0x004d22,
  roughness: 0.35
});

for (let i = 0; i < 16; i++) {
  const crate = new THREE.Mesh(lootGeo, lootMat);
  crate.position.set((Math.random() - 0.5) * 180, 0.65, (Math.random() - 0.5) * 180);
  crate.castShadow = true;
  scene.add(crate);
  loots.push(crate);
}

function animateLimbs(char, isMoving, dt, isAirborne) {
  if (!char || !char.userData) return;
  const u = char.userData;

  if (u.landSquash && u.landSquash > 0) {
    u.landSquash = Math.max(0, u.landSquash - dt * 5.5);
  }
  const squash = u.landSquash || 0;

  if (u.bodyRig) {
    u.bodyRig.position.y = -squash * 0.14;
    u.bodyRig.scale.set(1 + squash * 0.08, 1 - squash * 0.11, 1 + squash * 0.08);
    u.bodyRig.rotation.x = isAirborne ? -0.08 : (isMoving ? 0.06 : 0);
  }

  if (isAirborne) {
    u.leftLeg.rotation.x = -0.58;
    u.rightLeg.rotation.x = -0.32;
    if (u.leftKnee) u.leftKnee.rotation.x = 0.85;
    if (u.rightKnee) u.rightKnee.rotation.x = 0.55;

    u.leftArm.rotation.x = 0.35;
    if (u.leftElbow) u.leftElbow.rotation.x = -0.45;
    u.rightArm.rotation.x = -0.75;
    if (u.rightElbow) u.rightElbow.rotation.x = -0.55;
    return;
  }

  if (isMoving) {
    u.walkTime += dt * 13.5;
    const t = u.walkTime;
    const swing = Math.sin(t) * 0.72;
    const kneeBendL = Math.max(0, -Math.cos(t)) * 0.88 + squash * 0.45;
    const kneeBendR = Math.max(0, Math.cos(t)) * 0.88 + squash * 0.45;

    u.leftLeg.rotation.x = swing;
    u.rightLeg.rotation.x = -swing;
    if (u.leftKnee) u.leftKnee.rotation.x = kneeBendL;
    if (u.rightKnee) u.rightKnee.rotation.x = kneeBendR;

    u.leftArm.rotation.x = -swing * 0.65;
    if (u.leftElbow) u.leftElbow.rotation.x = -0.35 - Math.max(0, Math.sin(t)) * 0.3;

    u.rightArm.rotation.x = -0.65 + swing * 0.18;
    if (u.rightElbow) u.rightElbow.rotation.x = -0.55;
  } else {
    u.leftLeg.rotation.x = 0;
    u.rightLeg.rotation.x = 0;
    if (u.leftKnee) u.leftKnee.rotation.x = 0.06 + squash * 0.4;
    if (u.rightKnee) u.rightKnee.rotation.x = 0.06 + squash * 0.4;
    u.leftArm.rotation.x = 0;
    if (u.leftElbow) u.leftElbow.rotation.x = -0.2;
    u.rightArm.rotation.x = -0.65;
    if (u.rightElbow) u.rightElbow.rotation.x = -0.55;
  }
}

window.addEventListener('resize', function() {
  camera.aspect = Math.max(1, window.innerWidth) / Math.max(1, window.innerHeight);
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
