function draw() {
  if (!ctx || !canvas.width || !canvas.height) {
    return;
  }

  // Background
  ctx.fillStyle = "#101522";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Grid
  ctx.strokeStyle = "#202c42";
  ctx.lineWidth = 1;

  for (var x = 0; x <= COLS; x++) {
    ctx.beginPath();
    ctx.moveTo(x * CELL, 0);
    ctx.lineTo(x * CELL, canvas.height);
    ctx.stroke();
  }

  for (var y = 0; y <= ROWS; y++) {
    ctx.beginPath();
    ctx.moveTo(0, y * CELL);
    ctx.lineTo(canvas.width, y * CELL);
    ctx.stroke();
  }

  // Food
  if (food) {
    ctx.fillStyle = "#ff4757";
    ctx.beginPath();

    ctx.arc(
      food.x * CELL + CELL / 2,
      food.y * CELL + CELL / 2,
      CELL * 0.36,
      0,
      Math.PI * 2
    );

    ctx.fill();
  }

  // Snake
  snake.forEach(function (part, index) {
    var padding = Math.max(1, CELL * 0.07);
    var radius = Math.max(2, CELL * 0.2);

    ctx.fillStyle = index === 0 ? "#a8ff60" : "#35d07f";

    var px = part.x * CELL + padding;
    var py = part.y * CELL + padding;
    var size = CELL - padding * 2;

    ctx.beginPath();

    if (typeof ctx.roundRect === "function") {
      ctx.roundRect(px, py, size, size, radius);
    } else {
      ctx.rect(px, py, size, size);
    }

    ctx.fill();

    // Snake eyes
    if (index === 0) {
      ctx.fillStyle = "#101522";

      var eyeSize = Math.max(1.5, CELL * 0.08);

      var eye1x = part.x * CELL + CELL * 0.35;
      var eye2x = part.x * CELL + CELL * 0.65;
      var eyeY = part.y * CELL + CELL * 0.35;

      ctx.beginPath();

      ctx.arc(eye1x, eyeY, eyeSize, 0, Math.PI * 2);
      ctx.arc(eye2x, eyeY, eyeSize, 0, Math.PI * 2);

      ctx.fill();
    }
  });

  // Score
  document.getElementById("score").textContent = score;
  document.getElementById("best").textContent = best;
}