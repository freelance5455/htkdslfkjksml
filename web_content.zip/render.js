if(!CanvasRenderingContext2D.prototype.roundRect){CanvasRenderingContext2D.prototype.roundRect=function(x,y,w,h,r){this.rect(x,y,w,h);return this}}
function renderCatBody(g,x,y,aimA,col,helm,acc,cType,wpId,moving,furious,boss,scale){
  var t=Date.now()/140,faceLeft=(Math.cos(aimA)<-0.15),dir=faceLeft?-1:1,walk=moving?Math.sin(t*1.8)*6:Math.sin(t*0.5)*1.2,bob=moving?Math.abs(Math.sin(t*1.8))*-3:Math.sin(t*0.5)*1.5;
  g.save();g.translate(x,y);g.scale(scale,scale);
  g.fillStyle="rgba(0,0,0,0.38)";g.beginPath();g.ellipse(0,26,22,8,0,0,6.28);g.fill();
  if(furious||boss){g.strokeStyle=furious?"#fbc531":"#ff4757";g.lineWidth=2.5;g.beginPath();g.ellipse(0,26,26+Math.sin(t)*2,10,0,0,6.28);g.stroke()}
  g.save();g.translate(0,bob);
  g.save();g.scale(dir,1);g.strokeStyle=col;g.lineWidth=5.5;g.lineCap="round";g.beginPath();g.moveTo(-12,10);g.quadraticCurveTo(-28,2+Math.sin(t)*7,-24,-12+Math.cos(t)*6);g.stroke();g.restore();
  g.fillStyle=col;g.strokeStyle="#111";g.lineWidth=2;
  g.beginPath();g.roundRect(-12,14-walk*0.6,9,13,4);g.fill();g.stroke();
  g.beginPath();g.roundRect(3,14+walk*0.6,9,13,4);g.fill();g.stroke();
  g.fillStyle=col;g.beginPath();g.roundRect(-15,-6,30,26,10);g.fill();g.stroke();
  g.fillStyle=helm;g.fillRect(-14,6,28,5);g.fillStyle=acc||"#fff";g.beginPath();g.arc(0,8.5,3.5,0,6.28);g.fill();
  if(cType==4){g.fillStyle=helm;g.beginPath();g.moveTo(-15,-4);g.lineTo(-20,18);g.lineTo(20,18);g.lineTo(15,-4);g.closePath();g.fill();g.stroke()}
  g.fillStyle=col;g.beginPath();g.arc(0,-18,17.5,0,6.28);g.fill();g.stroke();
  g.beginPath();g.moveTo(-14,-27);g.lineTo(-18,-42);g.lineTo(-5,-33);g.closePath();g.fill();g.stroke();
  g.beginPath();g.moveTo(14,-27);g.lineTo(18,-42);g.lineTo(5,-33);g.closePath();g.fill();g.stroke();
  g.fillStyle=helm;
  if(cType==4){g.beginPath();g.moveTo(-21,-26);g.lineTo(21,-26);g.lineTo(0,-52);g.closePath();g.fill();g.stroke()}
  else if(boss){g.fillStyle="#fbc531";g.beginPath();g.moveTo(-15,-29);g.lineTo(-15,-43);g.lineTo(-7,-35);g.lineTo(0,-46);g.lineTo(7,-35);g.lineTo(15,-43);g.lineTo(15,-29);g.closePath();g.fill();g.stroke()}
  else{g.beginPath();g.arc(0,-20,17,Math.PI,0);g.closePath();g.fill();g.stroke()}
  g.fillStyle=(cType==3)?"#00f2fe":(acc||"#fff");g.fillRect(-11,-24,22,4.5);
  var lookX=dir*2.5;
  g.fillStyle=(furious||boss)?"#ff2a2a":"#fff";g.beginPath();g.arc(-6+lookX,-15,3.8,0,6.28);g.arc(6+lookX,-15,3.8,0,6.28);g.fill();
  g.fillStyle="#111";g.beginPath();g.arc(-5.5+lookX*1.2,-15,1.9,0,6.28);g.arc(6.5+lookX*1.2,-15,1.9,0,6.28);g.fill();
  g.fillStyle="#ff7675";g.beginPath();g.arc(lookX,-10.5,2.2,0,6.28);g.fill();
  g.strokeStyle="#111";g.lineWidth=1.2;g.beginPath();g.moveTo(-10,-10);g.lineTo(-18,-11);g.moveTo(-10,-8);g.lineTo(-18,-7);g.moveTo(10,-10);g.lineTo(18,-11);g.moveTo(10,-8);g.lineTo(18,-7);g.stroke();
  var wp=WEAPONS[Math.min(3,Math.max(0,(wpId||1)-1))];
  g.save();g.translate(0,4);g.rotate(aimA);if(faceLeft)g.scale(1,-1);
  var wLen=(cType==2||boss)?30:25,wH=(cType==2||boss)?10:7.5;
  g.fillStyle=wp.col;g.strokeStyle="#111";g.lineWidth=1.8;g.beginPath();g.roundRect(4,-wH/2,wLen,wH,3);g.fill();g.stroke();
  g.fillStyle=wp.tip;g.fillRect(4+wLen-6,-wH/2+1,5,wH-2);
  g.fillStyle=col;g.beginPath();g.arc(10,2,4.8,0,6.28);g.fill();g.stroke();
  g.restore();g.restore();g.restore();
}
function drwCat(x,y,a,col,helm,acc,cType,wpId,hp,mhp,isp,boss,moving){
  var sc=boss?1.65:1.05,fur=(isp&&p.fu>0);
  renderCatBody(ctx,x,y,a,col,helm,acc,cType,wpId,moving,fur,boss,sc);
  var bw=boss?86:52,by=boss?92:56;
  ctx.fillStyle="#111";ctx.fillRect(x-bw/2,y-by,bw,7);
  ctx.fillStyle=isp?(fur?"#fbc531":"#2ecc71"):(boss?"#e84118":"#e74c3c");
  ctx.fillRect(x-bw/2,y-by,bw*Math.max(0,hp/mhp),7);
  if(isp)for(var m=0;m<3;m++){ctx.fillStyle=m<p.am?"#fbc531":"#555";ctx.fillRect(x-25+m*17,y-47,15,4)}
}
function drwWall(w){
  var x=w.x,y=w.y;
  ctx.fillStyle="rgba(0,0,0,0.32)";ctx.beginPath();ctx.roundRect(x+4,y+10,70,66,8);ctx.fill();
  ctx.fillStyle="#3d4652";ctx.strokeStyle="#1e272e";ctx.lineWidth=3;ctx.beginPath();ctx.roundRect(x,y+14,70,56,6);ctx.fill();ctx.stroke();
  ctx.fillStyle="#6c7a89";ctx.beginPath();ctx.roundRect(x,y-8,70,56,8);ctx.fill();ctx.stroke();
  ctx.strokeStyle="rgba(30,39,46,0.45)";ctx.lineWidth=2;ctx.beginPath();
  ctx.moveTo(x+35,y-8);ctx.lineTo(x+35,y+18);ctx.moveTo(x,y+18);ctx.lineTo(x+70,y+18);
  ctx.moveTo(x+20,y+18);ctx.lineTo(x+20,y+48);ctx.moveTo(x+50,y+18);ctx.lineTo(x+50,y+48);ctx.moveTo(x+35,y+48);ctx.lineTo(x+35,y+70);ctx.stroke();
  ctx.fillStyle="#2ecc71";ctx.beginPath();ctx.arc(x+14,y-4,6,0,6.28);ctx.arc(x+22,y-5,4,0,6.28);ctx.fill();
}
function drwBox(b){
  var x=b.x,y=b.y;
  ctx.fillStyle="rgba(0,0,0,0.3)";ctx.beginPath();ctx.roundRect(x+3,y+6,40,38,6);ctx.fill();
  ctx.fillStyle="#a04000";ctx.strokeStyle="#2c1608";ctx.lineWidth=2.5;ctx.beginPath();ctx.roundRect(x,y+8,40,32,5);ctx.fill();ctx.stroke();
  ctx.fillStyle="#e67e22";ctx.beginPath();ctx.roundRect(x,y-6,40,32,5);ctx.fill();ctx.stroke();
  ctx.fillStyle="#d35400";ctx.fillRect(x+5,y-1,30,22);
  ctx.strokeStyle="#f39c12";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x+6,y);ctx.lineTo(x+34,y+20);ctx.stroke();
  ctx.fillStyle="#bdc3c7";ctx.beginPath();ctx.arc(x+4,y-2,1.8,0,6.28);ctx.arc(x+36,y-2,1.8,0,6.28);ctx.arc(x+4,y+22,1.8,0,6.28);ctx.arc(x+36,y+22,1.8,0,6.28);ctx.fill();
  ctx.fillStyle="#fff";ctx.font="bold 10px sans-serif";ctx.textAlign="center";ctx.fillText(Math.ceil(b.hp),x+20,y-11);
}
function drwBush(b){
  var x=b.x,y=b.y,sway=Math.sin(Date.now()/350+x)*2,inside=(Math.hypot(p.x-x,p.y-y)<55);
  ctx.save();if(inside)ctx.globalAlpha=0.55;
  ctx.fillStyle="rgba(0,0,0,0.28)";ctx.beginPath();ctx.ellipse(x,y+18,42,18,0,0,6.28);ctx.fill();
  ctx.fillStyle="#6e2c00";ctx.strokeStyle="#2c1608";ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(x-7,y-2,14,20,3);ctx.fill();ctx.stroke();
  ctx.fillStyle="#1e8449";ctx.strokeStyle="#145a32";ctx.lineWidth=2.5;ctx.beginPath();ctx.arc(x-18+sway,y-6,22,0,6.28);ctx.arc(x+18+sway,y-6,22,0,6.28);ctx.arc(x+sway,y-22,25,0,6.28);ctx.fill();ctx.stroke();
  ctx.fillStyle="#2ecc71";ctx.beginPath();ctx.arc(x-14+sway,y-10,16,0,6.28);ctx.arc(x+14+sway,y-10,16,0,6.28);ctx.arc(x+sway,y-25,19,0,6.28);ctx.fill();
  ctx.fillStyle="#ff4757";ctx.beginPath();ctx.arc(x-10+sway,y-14,3,0,6.28);ctx.arc(x+12+sway,y-8,3,0,6.28);ctx.arc(x+2+sway,y-28,3,0,6.28);ctx.fill();
  ctx.restore();
}
function drwFish(x,y){ctx.save();ctx.translate(x,y);ctx.fillStyle="#2ecc71";ctx.beginPath();ctx.arc(0,0,13,0,6.28);ctx.fill();ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.stroke();ctx.strokeStyle="#fff";ctx.lineWidth=2.5;ctx.beginPath();ctx.moveTo(-7,0);ctx.lineTo(5,0);ctx.moveTo(-3,-4);ctx.lineTo(-3,4);ctx.moveTo(1,-4);ctx.lineTo(1,4);ctx.moveTo(5,0);ctx.lineTo(9,-4);ctx.moveTo(5,0);ctx.lineTo(9,4);ctx.stroke();ctx.restore()}
function drwMM(){var s=90/M;mctx.clearRect(0,0,90,90);mctx.fillStyle="#c0392b";box.forEach(function(x){mctx.fillRect(x.x*s,x.y*s,2.5,2.5)});mctx.fillStyle="#95a5a6";wal.forEach(function(w){mctx.fillRect(w.x*s,w.y*s,4,4)});mctx.fillStyle="#2ecc71";bus.forEach(function(b){mctx.fillRect(b.x*s-1.5,b.y*s-1.5,3,3)});bot.forEach(function(o){if(o.boss||!bus.some(function(b){return Math.hypot(o.x-b.x,o.y-b.y)<50})||Math.hypot(p.x-o.x,p.y-o.y)<75){mctx.fillStyle=o.boss?"#fbc531":"#ff4757";mctx.beginPath();mctx.arc(o.x*s,o.y*s,o.boss?4.5:2.5,0,6.28);mctx.fill()}});if(p2&&p2.hp>0&&(!p2.b||Math.hypot(p.x-p2.x,p.y-p2.y)<75)){mctx.fillStyle="#00a8ff";mctx.beginPath();mctx.arc(p2.x*s,p2.y*s,3,0,6.28);mctx.fill()}mctx.fillStyle="#fff";mctx.beginPath();mctx.arc(p.x*s,p.y*s,3,0,6.28);mctx.fill();mctx.strokeStyle="#2ecc71";mctx.lineWidth=1.5;mctx.strokeRect((st.x-st.r)*s,(st.y-st.r)*s,st.r*2*s,st.r*2*s)}
function drwMeteor(m){var prog=1-(m.t/m.maxT);ctx.save();ctx.fillStyle="rgba(231,76,60,"+(0.15+prog*0.25)+")";ctx.beginPath();ctx.arc(m.x,m.y,m.r,0,6.28);ctx.fill();ctx.strokeStyle="#ff4757";ctx.lineWidth=3;ctx.beginPath();ctx.arc(m.x,m.y,m.r*prog,0,6.28);ctx.stroke();var dropY=m.y-(1-prog)*450,dropX=m.x+(1-prog)*140;ctx.fillStyle="#ff9f43";ctx.beginPath();ctx.arc(dropX,dropY,22,0,6.28);ctx.fill();ctx.fillStyle="#ff4757";ctx.beginPath();ctx.arc(dropX,dropY,14,0,6.28);ctx.fill();ctx.fillStyle="#fff200";ctx.beginPath();ctx.arc(dropX,dropY,7,0,6.28);ctx.fill();ctx.restore()}
function drwPowerUp(u){var bob=Math.sin(Date.now()/160+u.x)*3,cols=new Array("#a55eea","#00d2d3","#fbc531"),icons=new Array("⚡","🛡️","🔥"),col=cols.at(u.tp);ctx.save();ctx.translate(u.x,u.y+bob);ctx.fillStyle=col;ctx.globalAlpha=0.3;ctx.beginPath();ctx.arc(0,0,18,0,6.28);ctx.fill();ctx.globalAlpha=1;ctx.fillStyle=col;ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,-13);ctx.lineTo(11,0);ctx.lineTo(0,13);ctx.lineTo(-11,0);ctx.closePath();ctx.fill();ctx.stroke();ctx.font="11px sans-serif";ctx.textAlign="center";ctx.fillText(icons.at(u.tp),0,4);ctx.restore()}

