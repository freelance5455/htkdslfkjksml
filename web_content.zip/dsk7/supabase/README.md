# Supabase backend for DSK 7

`replica/schema.sql` is the source of truth. `migrations/0001_init.sql` is a copy for the Supabase CLI. Keep them in step:

    cp replica/schema.sql supabase/migrations/0001_init.sql

Checks: `replica/schema-tests/run.sh` loads the schema into a throwaway Postgres and runs 41 access-rule and function checks.

## One-time setup (you, in your Supabase account)

1. Create a project at supabase.com (free tier). Note the project URL and the anon key.
2. Create a private storage bucket named `audio`. Upload the seed tones to `seed/seed-1.mp3`, `seed/seed-2.mp3`, `seed/seed-3.mp3` (from `mobile/assets/seed/`).
3. Install the CLI on your PC and link the project:
   ```bash
   npm install -g supabase
   supabase login
   supabase link --project-ref YOUR_PROJECT_REF
   supabase db push                 # runs migrations/0001_init.sql
   supabase db execute --file supabase/seed.sql   # dev data only
   ```
4. Auth: enable Email. Turn on email OTP (one-time code), and set the "Magic Link" email template to show `{{ .Token }}` so the code appears in the email.
5. Create your first admin. Sign up once in the app, then in the SQL editor (service role, bypasses RLS):
   ```sql
   insert into staff_roles (user_id, role) values ('<your auth user id>', 'admin');
   ```
6. Secrets for the Edge Functions (never in the app):
   ```bash
   supabase secrets set JAMENDO_CLIENT_ID=... MOCK_BILLING=true
   ```
7. Deploy the functions: `supabase functions deploy`.

## Edge Functions

| function | who calls it | what it does |
| --- | --- | --- |
| `sync-catalogue` | scheduled (pg_cron) or an admin | pulls tracks from Jamendo, keeps only the allowed licences, stores them as drafts |
| `admin-set-plan` | admin panel | changes a user's plan (clients cannot change it themselves) |
| `mock-checkout` | the app (Pro button) | sets plan to pro. Works only when `MOCK_BILLING=true`. Off in production |
| `delete-account` | the app | deletes the user, and every row linked to them cascades |

All functions check the caller's token. Only `service role` code is allowed to write `profiles.plan`.

## Status

Written, not yet run against a real project. The SQL is tested locally (see above). The functions and the app's Supabase layer follow the documented supabase-js and Deno APIs and must be checked on first deploy.
