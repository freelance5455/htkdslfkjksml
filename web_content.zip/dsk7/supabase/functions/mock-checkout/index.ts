// The Pro button, for the portfolio build. No money changes hands.
// Refuses to run unless MOCK_BILLING=true is set, so it cannot be used in a real launch.
import { callerOf, json, preflight, serviceClient } from "../_shared/auth.ts";

Deno.serve(async (req) => {
  const pre = preflight(req);
  if (pre) return pre;
  if (req.method !== "POST") return json({ error: "Use POST." }, 405);
  if (Deno.env.get("MOCK_BILLING") !== "true") return json({ error: "Not available." }, 404);

  const caller = await callerOf(req);
  if (!caller) return json({ error: "Log in first." }, 401);

  const { data, error } = await serviceClient()
    .from("profiles")
    .update({ plan: "pro" })
    .eq("id", caller.id)
    .select("id, plan")
    .maybeSingle();
  if (error || !data) return json({ error: "Could not switch to Pro. Try again." }, 500);
  return json(data);
});
