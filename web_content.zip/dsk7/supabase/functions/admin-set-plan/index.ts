// POST { userId, plan: "free" | "pro" }. Admins only. Clients cannot change plans themselves.
import { callerOf, json, preflight, serviceClient, staffRoleOf } from "../_shared/auth.ts";

Deno.serve(async (req) => {
  const pre = preflight(req);
  if (pre) return pre;
  if (req.method !== "POST") return json({ error: "Use POST." }, 405);

  const caller = await callerOf(req);
  if (!caller) return json({ error: "Log in first." }, 401);
  if ((await staffRoleOf(caller.id)) !== "admin") return json({ error: "Only admins can do that." }, 403);

  let body: { userId?: unknown; plan?: unknown };
  try { body = await req.json(); } catch { return json({ error: "Send JSON." }, 400); }
  if (typeof body.userId !== "string" || !/^[0-9a-f-]{36}$/i.test(body.userId)) return json({ error: "Bad user id." }, 400);
  if (body.plan !== "free" && body.plan !== "pro") return json({ error: "Plan must be free or pro." }, 400);

  const { data, error } = await serviceClient()
    .from("profiles")
    .update({ plan: body.plan })
    .eq("id", body.userId)
    .select("id, plan")
    .maybeSingle();
  if (error) return json({ error: "Could not save. Try again." }, 500);
  if (!data) return json({ error: "No such user." }, 404);
  return json(data);
});
