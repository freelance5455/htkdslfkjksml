// Shared checks for Edge Functions. Every function calls one of these before it does anything.
import { createClient, type SupabaseClient, type User } from "npm:@supabase/supabase-js@2";

export const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
export const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
export const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

/** Service role client: bypasses row level security. Use only after the caller is checked. */
export function serviceClient(): SupabaseClient {
  return createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false } });
}

/** The user behind the request's bearer token, or null. */
export async function callerOf(req: Request): Promise<User | null> {
  const header = req.headers.get("Authorization") ?? "";
  if (!header.startsWith("Bearer ")) return null;
  const client = createClient(SUPABASE_URL, ANON_KEY, {
    global: { headers: { Authorization: header } },
    auth: { persistSession: false },
  });
  const { data, error } = await client.auth.getUser();
  if (error || !data.user) return null;
  return data.user;
}

/** Staff role for a user, or null. Reads with the service role, so it works regardless of RLS. */
export async function staffRoleOf(userId: string): Promise<"admin" | "editor" | "viewer" | null> {
  const { data } = await serviceClient().from("staff_roles").select("role").eq("user_id", userId).maybeSingle();
  return (data?.role as "admin" | "editor" | "viewer" | undefined) ?? null;
}

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json",
      // The admin panel is a web page on another origin, so it needs these to call us.
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
    },
  });
}

export function preflight(req: Request): Response | null {
  return req.method === "OPTIONS" ? json({}, 204) : null;
}
