// Deletes the caller's account. Their profile, likes, follows, saves, history and
// playlists go too, through the ON DELETE CASCADE rules in the schema.
// Apple and Google both require this for apps with sign-up.
import { callerOf, json, preflight, serviceClient } from "../_shared/auth.ts";

Deno.serve(async (req) => {
  const pre = preflight(req);
  if (pre) return pre;
  if (req.method !== "POST") return json({ error: "Use POST." }, 405);

  const caller = await callerOf(req);
  if (!caller) return json({ error: "Log in first." }, 401);

  const { error } = await serviceClient().auth.admin.deleteUser(caller.id);
  if (error) return json({ error: "Could not delete the account. Try again." }, 500);
  return json({ deleted: true });
});
