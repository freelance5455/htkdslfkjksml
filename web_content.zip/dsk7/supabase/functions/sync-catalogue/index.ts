// POST { limit?: number } (default 50, max 200). Pulls tracks from the Jamendo API
// and stores the ones with a licence we allow as DRAFTS. An editor publishes them
// in the admin panel after listening to them.
//
// Allowed: CC BY, CC BY-SA, CC0. Not allowed: anything NC (non-commercial) or ND (no derivatives).
// Callers: a staff editor or admin (their token), or a scheduled job with SYNC_SECRET.
//
// NOT YET RUN. Check the Jamendo field names and their terms (caching, offline use)
// before the first real sync. Jamendo needs your own client id: JAMENDO_CLIENT_ID.
import { callerOf, json, preflight, serviceClient, staffRoleOf } from "../_shared/auth.ts";

const ALLOWED = /\/licenses\/(by|by-sa)\/([\d.]+)\/|\/publicdomain\/zero\//;

function licenceName(url: string): string | null {
  const m = url.match(/\/licenses\/(by|by-sa)\/([\d.]+)\//);
  if (m) return `CC ${m[1]!.toUpperCase()} ${m[2]}`;
  if (url.includes("/publicdomain/zero/")) return "CC0 1.0";
  return null;
}

interface JamendoTrack {
  id: number | string;
  name: string;
  duration: number;
  artist_id: number | string;
  artist_name: string;
  album_id: number | string;
  album_name: string;
  album_image: string;
  audio: string;
  license_ccurl: string;
}

Deno.serve(async (req) => {
  const pre = preflight(req);
  if (pre) return pre;
  if (req.method !== "POST") return json({ error: "Use POST." }, 405);

  // Who is asking?
  const scheduled = req.headers.get("x-sync-secret") === Deno.env.get("SYNC_SECRET") && !!Deno.env.get("SYNC_SECRET");
  if (!scheduled) {
    const caller = await callerOf(req);
    if (!caller) return json({ error: "Log in first." }, 401);
    const role = await staffRoleOf(caller.id);
    if (role !== "admin" && role !== "editor") return json({ error: "Only editors can sync." }, 403);
  }

  const key = Deno.env.get("JAMENDO_CLIENT_ID");
  if (!key) return json({ error: "JAMENDO_CLIENT_ID is not set." }, 500);

  let limit = 50;
  try { limit = Math.min(Math.max(Number((await req.json()).limit) || 50, 1), 200); } catch { /* no body is fine */ }

  const params = new URLSearchParams({
    client_id: key,
    format: "json",
    limit: String(limit),
    audioformat: "mp31",
    fields: "id,name,duration,artist_id,artist_name,album_id,album_name,album_image,audio,license_ccurl",
    order: "popularity_week",
  });
  const res = await fetch(`https://api.jamendo.com/v3.0/tracks/?${params}`);
  if (!res.ok) return json({ error: `Jamendo answered ${res.status}.` }, 502);
  const body = (await res.json()) as { results?: JamendoTrack[] };

  const db = serviceClient();
  let kept = 0;
  let skipped = 0;
  for (const t of body.results ?? []) {
    const license = t.license_ccurl ? licenceName(t.license_ccurl) : null;
    if (!license || !ALLOWED.test(t.license_ccurl) || !t.audio) { skipped++; continue; }

    const artistSrc = String(t.artist_id);
    const { data: artist, error: aErr } = await db
      .from("artists")
      .upsert({ name: t.artist_name, source: "jamendo", source_id: artistSrc }, { onConflict: "source,source_id" })
      .select("id")
      .single();
    if (aErr) return json({ error: "Could not save artists.", kept }, 500);

    const { data: album, error: alErr } = await db
      .from("albums")
      .upsert(
        { title: t.album_name, artist_id: artist.id, cover_url: t.album_image || null, source: "jamendo", source_id: String(t.album_id) },
        { onConflict: "source,source_id" },
      )
      .select("id")
      .single();
    if (alErr) return json({ error: "Could not save albums.", kept }, 500);

    const { data: song, error: sErr } = await db
      .from("songs")
      .upsert(
        {
          title: t.name,
          album_id: album.id,
          duration_s: Math.max(1, Math.round(t.duration)),
          audio_url: t.audio,
          license: license,
          license_url: t.license_ccurl,
          attribution: `${t.artist_name} · ${license}`,
          source: "jamendo",
          source_id: String(t.id),
          published: false, // drafts until an editor has listened
        },
        { onConflict: "source,source_id", ignoreDuplicates: false },
      )
      .select("id")
      .single();
    if (sErr) return json({ error: "Could not save songs.", kept }, 500);

    await db.from("song_artists").upsert({ song_id: song.id, artist_id: artist.id, role: "primary", position: 0 });
    kept++;
  }
  return json({ saved_as_drafts: kept, skipped_licence_or_no_audio: skipped });
});
