-- Development data: our own invented artists and songs, matching mobile/src/data/seed.ts.
-- Audio is our generated tones, uploaded to the private `audio` bucket at seed/seed-N.mp3.
-- Safe to run more than once. Do not run in production.
-- Ids are fixed, so the admin panel and the app can be checked against the same rows.

insert into artists (id, name, source) values
  ('5eed0000-0000-4000-8000-0000000000a1', 'Orbit Kiln', 'upload'),
  ('5eed0000-0000-4000-8000-0000000000a2', 'Static Bloom', 'upload'),
  ('5eed0000-0000-4000-8000-0000000000a3', 'Lantern Coast', 'upload')
on conflict do nothing;

insert into albums (id, title, artist_id, source) values
  ('5eed0000-0000-4000-8000-0000000000b1', 'Tide Sketches', '5eed0000-0000-4000-8000-0000000000a1', 'upload'),
  ('5eed0000-0000-4000-8000-0000000000b2', 'Night Notes', '5eed0000-0000-4000-8000-0000000000a2', 'upload'),
  ('5eed0000-0000-4000-8000-0000000000b3', 'Harbour', '5eed0000-0000-4000-8000-0000000000a3', 'upload')
on conflict do nothing;

insert into songs (id, title, album_id, duration_s, storage_path, language, license, attribution, published, source) values
  ('5eed0000-0000-4000-8000-0000000000c1', 'Low Tide Sketch', '5eed0000-0000-4000-8000-0000000000b1', 35, 'seed/seed-1.mp3', 'en', 'DSK generated tone (own work)', 'Orbit Kiln', true, 'upload'),
  ('5eed0000-0000-4000-8000-0000000000c2', 'Paper Lantern', '5eed0000-0000-4000-8000-0000000000b1', 35, 'seed/seed-2.mp3', 'en', 'DSK generated tone (own work)', 'Orbit Kiln', true, 'upload'),
  ('5eed0000-0000-4000-8000-0000000000c3', 'Night Transit', '5eed0000-0000-4000-8000-0000000000b2', 35, 'seed/seed-3.mp3', 'en', 'DSK generated tone (own work)', 'Static Bloom', true, 'upload'),
  ('5eed0000-0000-4000-8000-0000000000c4', 'Harbour Light', '5eed0000-0000-4000-8000-0000000000b3', 35, 'seed/seed-1.mp3', 'en', 'DSK generated tone (own work)', 'Lantern Coast', true, 'upload'),
  ('5eed0000-0000-4000-8000-0000000000c5', 'A Very Long Title That Keeps Going Past The Edge Of The Screen', '5eed0000-0000-4000-8000-0000000000b2', 35, 'seed/seed-2.mp3', 'en', 'DSK generated tone (own work)', 'Static Bloom', false, 'upload')
on conflict do nothing;

insert into song_artists (song_id, artist_id, role, position) values
  ('5eed0000-0000-4000-8000-0000000000c1', '5eed0000-0000-4000-8000-0000000000a1', 'primary', 0),
  ('5eed0000-0000-4000-8000-0000000000c2', '5eed0000-0000-4000-8000-0000000000a1', 'primary', 0),
  ('5eed0000-0000-4000-8000-0000000000c3', '5eed0000-0000-4000-8000-0000000000a2', 'primary', 0),
  ('5eed0000-0000-4000-8000-0000000000c4', '5eed0000-0000-4000-8000-0000000000a3', 'primary', 0),
  ('5eed0000-0000-4000-8000-0000000000c5', '5eed0000-0000-4000-8000-0000000000a2', 'primary', 0)
on conflict do nothing;

insert into playlists (id, owner_id, title, description, kind, is_public) values
  ('5eed0000-0000-4000-8000-0000000000d1', null, 'Quiet Evenings', 'Slow, low-key tracks', 'mood', true),
  ('5eed0000-0000-4000-8000-0000000000d2', null, 'Top This Week', null, 'chart', true)
on conflict do nothing;

insert into playlist_items (playlist_id, song_id, position) values
  ('5eed0000-0000-4000-8000-0000000000d1', '5eed0000-0000-4000-8000-0000000000c1', 0),
  ('5eed0000-0000-4000-8000-0000000000d1', '5eed0000-0000-4000-8000-0000000000c2', 1),
  ('5eed0000-0000-4000-8000-0000000000d1', '5eed0000-0000-4000-8000-0000000000c4', 2),
  ('5eed0000-0000-4000-8000-0000000000d2', '5eed0000-0000-4000-8000-0000000000c3', 0),
  ('5eed0000-0000-4000-8000-0000000000d2', '5eed0000-0000-4000-8000-0000000000c4', 1)
on conflict do nothing;

insert into home_sections (id, title, kind, position, is_active) values
  ('5eed0000-0000-4000-8000-0000000000e1', 'Quiet Evenings', 'playlists', 0, true),
  ('5eed0000-0000-4000-8000-0000000000e2', 'Top this week', 'playlists', 1, true)
on conflict do nothing;

insert into home_section_items (section_id, item_id, position) values
  ('5eed0000-0000-4000-8000-0000000000e1', '5eed0000-0000-4000-8000-0000000000d1', 0),
  ('5eed0000-0000-4000-8000-0000000000e2', '5eed0000-0000-4000-8000-0000000000d2', 0)
on conflict do nothing;
