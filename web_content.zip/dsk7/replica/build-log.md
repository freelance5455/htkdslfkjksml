# DSK 7 build log

Each line: ID, date, status (done / partial / no), what is missing, what was harder than expected.

## Shell and design

| item | date | status | missing | notes |
| --- | --- | --- | --- | --- |
| Tokens and generator | 2026-10-18 | done | nothing | 28 contrast pairs pass AA. `build-tokens.py --mobile` writes `tokens.generated.ts` with camelCase colour keys. Caught one bad pair of my own (on-accent on surface-raised, not used in the UI) and removed it |
| Component specs | 2026-10-18 | done (spec) | Storybook / `/design` page not built | `components.md` covers 18 components |
| Expo scaffold | 2026-10-18 | partial | not created | npm registry is blocked from this sandbox (403 from the egress proxy), so `create-expo-app` could not run here. Files are written; the scaffold is a step for the user's PC (see `mobile/SETUP.md`) |

## Core logic (tested here, no device needed)

| item | date | status | missing | notes |
| --- | --- | --- | --- | --- |
| queue.ts (next, previous, shuffle, repeat, add, remove, move) | 2026-10-18 | done | nothing | 17 tests |
| playTracker.ts (30 s rule, seek and pause do not count) | 2026-10-18 | done | nothing | 8 tests. Records are idempotent through a client-made id |
| format.ts and cover.ts | 2026-10-18 | done | nothing | 8 tests. Hindi and symbol titles handled |
| controller.ts (ties queue, engine, tracking together) | 2026-10-18 | done | nothing on a device | 18 tests with a fake engine. Found and fixed: after autoplay on an engine that sends no state, status stayed "loading" |
| Strict TypeScript on core and data | 2026-10-18 | done | nothing | `tsc --strict` clean except test files that need `@types/node` (present once the Expo project installs it) |

Run from `mobile/`: `node --experimental-strip-types --test src/core/*.test.ts` (51 tests, all pass: queue 17, playTracker 8, format and cover 8, controller 18).

## Data and audio

| item | date | status | missing | notes |
| --- | --- | --- | --- | --- |
| DataLayer interface | 2026-10-18 | done | nothing | screens depend only on this |
| Seed data layer | 2026-10-18 | done | nothing | invented artists, three generated tones (ffmpeg, our own work). Not a real catalogue |
| Supabase data layer | 2026-10-18 | partial | run against a real project | written from the supabase-js v2 API. 41 database checks pass on local Postgres, but the client code has never run against Supabase |
| TrackPlayer adapter | 2026-10-18 | partial | verification | written from the v4 API as known. Must be checked against the installed version before device testing. No playback service registered yet, so lock-screen buttons may not reach the controller while the app is in the background |

## Backend (replica-backend)

| item | date | status | missing | notes |
| --- | --- | --- | --- | --- |
| Schema, RLS, staff roles | 2026-10-18 | done (tested locally) | first `supabase db push` | 41 checks pass on local Postgres 16: second-user access, viewer and editor limits |
| Migration and seed copies | 2026-10-18 | done | nothing | `supabase/migrations/0001_init.sql` and `supabase/seed.sql` match `replica/` (checked by diff) |
| Edge Functions (sync-catalogue, admin-set-plan, mock-checkout, delete-account) | 2026-10-18 | partial | deploy and run | written and syntax-checked only; Deno and the Supabase CLI are not reachable from this sandbox |
| App session storage | 2026-10-18 | done (written) | run on device | AsyncStorage added to the Supabase client; `@react-native-async-storage/async-storage` in SETUP.md |
| Admin panel live mode | 2026-10-18 | partial | real project test | 14 checks against a fake Supabase client; 24 demo-mode browser checks. Cannot add songs yet (no upload screen) |

Full checklist and what is verified: `replica/backend.md`. Setup steps: `supabase/README.md`.

## Screens (vertical slice)

| ID | screen | date | status | missing | notes |
| --- | --- | --- | --- | --- | --- |
| S02 | Login (email code) | 2026-10-18 | partial | Google sign-in, real OTP | code is 123456 in the seed build. Layout not seen on a device |
| S03 | Home (3 rows, all states) | 2026-10-18 | partial | real feed, language filter | loading, error, empty and filled are written. Not seen on a device |
| S09 | Playlist detail (play, shuffle, empty, missing) | 2026-10-18 | partial | edit, remove, reorder | |
| S12 | Mini player | 2026-10-18 | partial | queue preview | error state has a retry button |
| S13 | Now playing (controls, seek, like, attribution, error) | 2026-10-18 | partial | queue view (S14) | |
| S04, S14, S15-S22 | | | no | milestone 2 and later | Search and Library are stub tabs |

## What is untested, and why

- **Nothing has run on a device or in a simulator.** The sandbox cannot install npm packages (registry blocked), so React Native and Expo are unchecked. The logic underneath is tested; the screens are not.
- **Screenshots** for `replica/clone-screens/` are not taken, because there is no running app. The diff step needs them.
- **Original screenshots** are still missing from `replica/screens/`. The design values were not measured from the original.
- **Accessibility** is written into the components (labels, roles, live regions, reduced motion) but not checked with TalkBack.

## What was harder than it looked

- Shuffle: the queue must keep the original order so that turning shuffle off restores it. Solved with two arrays (`order`, `original`) and tests for both.
- Seeking: a jump of 200 seconds must not count as 200 seconds listened. Solved with a tick-gap limit (2.5 s) in the play tracker.
- Race: a slow song that finishes loading after the user has moved on must not start playing. Solved with a load token in the controller, with a test.
- The status of the player can stick at "loading" when an engine sends no state after load. Fixed in the controller.

## Next

1. On the user's PC: scaffold the Expo project and copy these files in (see `mobile/SETUP.md`).
2. Run the core tests there too, then the app on an Android device or emulator.
3. Verify the TrackPlayer calls against the installed version, and register the playback service.
4. Take screenshots of S02, S03, S09, S12, S13 into `replica/clone-screens/`.
5. You: create the Supabase project and follow `supabase/README.md`. Send the first error from `db push` or `functions deploy`.
6. Then `/replica-test` against the live project.
