# DSK 7 backend

Stack: Supabase (Postgres, auth, storage, Edge Functions). Schema: `schema.sql`. Setup steps for you: `supabase/README.md`.

## What exists

| part | file | verified? |
| --- | --- | --- |
| Schema, RLS, functions | `replica/schema.sql` | yes: 41 checks pass on local Postgres 16 (`replica/schema-tests/run.sh`) |
| Staff roles and write rules | `schema.sql` (is_staff, staff_roles) | yes, in the same 41 checks |
| Dev seed | `replica/seed.sql` | loads cleanly; same invented songs as the app |
| Migration copy for the CLI | `supabase/migrations/0001_init.sql` | copy of schema.sql |
| App data layer | `mobile/src/data/supabase.ts` | **no**: written from the supabase-js v2 API, never run against a project |
| Edge: sync-catalogue (Jamendo, drafts only) | `supabase/functions/sync-catalogue` | **no** |
| Edge: admin-set-plan | `supabase/functions/admin-set-plan` | **no** |
| Edge: mock-checkout (Pro, mock) | `supabase/functions/mock-checkout` | **no** |
| Edge: delete-account | `supabase/functions/delete-account` | **no** |
| Shared auth helper | `supabase/functions/_shared/auth.ts` | **no** |
| Admin panel, live mode | `admin/index.html` + `admin/config.js` | partly: 14 checks against a fake Supabase client (the write calls are right; the real API is not tested) |
| Admin panel, demo mode | `admin/index.html` | yes: 24 browser checks |

## Auth

- [x] Email one-time code for listeners (app). Needs the OTP email template to show the code.
- [x] Staff sign-in with email and password (admin panel). Accounts are created in the Supabase dashboard.
- [ ] Google and Apple sign-in. Needs your own developer apps. Not built.
- [ ] Password reset for staff. Works through the Supabase dashboard; no screen yet.
- [x] Sessions: the app keeps them in AsyncStorage (React Native has no localStorage). The admin panel uses Supabase's browser session.
- [ ] Sign out everywhere. Not built; `signOut()` ends the current session only.
- [x] Roles: owner / admin / editor / viewer for staff (`staff_roles`), one function `is_staff(role)` used by every staff rule.
- [x] Account deletion: `delete-account` removes the auth user, and every row linked to them cascades. Needs the app's Profile screen (not built) to call it.

## Database

- [x] Migrations from `architecture.md` in `schema.sql`.
- [x] Access rules on every table (RLS). Tested with a second user: a listener cannot read or change another listener's likes, playlists, history or staff rows; a viewer cannot write; an editor cannot make themselves admin or change a plan.
- [x] Seed script with invented data, no real people.
- [ ] Backups. Supabase's free tier has daily backups only on paid plans. Check the dashboard, or upgrade before launch.
- [ ] The weekly chart refresh (pg_cron). The SQL is in `schema.sql` as a comment; enable pg_cron and run it.

## Payments

- [x] Mock only: `mock-checkout` sets Pro with no money. It refuses to run unless `MOCK_BILLING=true`.
- [ ] Stripe. Not used. Not needed for the portfolio build. Before any real billing: Stripe Checkout, the Customer Portal, webhook signature checks, idempotent handlers (see the skill's list of events).
- Cancelling: none to cancel while billing is mock.

## Email and jobs

- [ ] Transactional email from your own domain. Supabase's built-in email is limited to a few messages an hour. Connect Resend or Postmark as custom SMTP before you invite anyone.
- [x] Catalogue sync is written: `sync-catalogue`, run by an editor or by a scheduled call with `SYNC_SECRET`. Not scheduled yet.
- [ ] Scheduling for the sync and the chart refresh (pg_cron). Times are UTC; the app shows them in the user's time zone.
- [ ] Dead-letter log for failed jobs. Not built; failures return an error to the caller.

## Integrations

### Jamendo (catalogue)

- Official API, your own client id (`JAMENDO_CLIENT_ID`).
- Licences kept: CC BY, CC BY-SA, CC0. Anything NC or ND is skipped in code.
- Tracks are stored as **drafts** (`published = false`). An editor listens and publishes in the admin.
- **Before the first sync:** read Jamendo's API terms on caching and on how long a stream URL may be used. The app streams from the URL Jamendo gives. If the terms do not allow it, store the file yourself or stop using Jamendo.
- OAuth scopes: none (public API key).
- Rate limits: check Jamendo's current limits. The function asks for 50 tracks per call by default.

### Google sign-in (not built)

- Needs your Google Cloud project and OAuth consent screen. Sign-in with only basic scopes does not need Google's review. Start the project early anyway; the consent screen takes a few days to set up.

## Security checklist

- [x] Secrets only in environment variables. The app and admin hold only the anon key. The service role key is only in Edge Function secrets.
- [x] `.env*` is in `.gitignore`; `.env.example` lists the names with no values.
- [x] Input checked on the server in every Edge Function (user id format, plan value, licence list, limit range).
- [x] Authorisation on every read and write: RLS in the database, and a staff check in each Edge Function. Tested in the SQL checks.
- [ ] Rate limits on sign-in, sign-up and email sending. Supabase applies its defaults; set your own in the dashboard. Edge Functions are not rate limited yet.
- [ ] Webhooks verify signatures. None yet (no Stripe).
- [ ] Uploads: size and type limits. The `audio` bucket is private, but no size or MIME limit is set. Set them in the dashboard before accepting uploads.
- [x] No user data in URLs. The functions log nothing about users.
- [ ] Dependencies audited (`npm audit`). Not run: npm is blocked in this sandbox. Run it on your PC.
- [ ] Privacy policy lists every processor. Supabase (database, auth, storage, functions), Jamendo (catalogue), and any email provider. Staff can read profiles and plays (`is_staff('viewer')`), so the policy must say so.

## Known gaps, in plain words

- The admin cannot add songs in live mode yet. Adding needs an audio upload, and the upload screen is not built. Editing and publishing existing songs works.
- Staff roles are changed in Supabase, not in the admin panel.
- The admin's Users table shows names, not emails. Emails are in Supabase's auth table, which the browser cannot read safely.
- Nothing above has run against a live Supabase project. The first `supabase db push` and the first function deploy are the real tests. Expect small fixes.

## Next

1. You: create the Supabase project, upload the seed audio, run `supabase db push`, set the secrets, deploy the functions (steps in `supabase/README.md`).
2. Send me the first error, if any, from the push or the deploy.
3. Then `/replica-test`, which covers the app and the admin against the live project.
