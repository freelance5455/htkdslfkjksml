# Architecture: DSK 7 (a rebuild of JioSaavn's core features, Android)

Scope and screen IDs (S01-S22), flows (F01-F08) and the feature matrix come from `recon.md` and `features.csv`. The database is in `schema.sql`, with tests in `schema-tests/`.

## Assumptions to confirm

- **Expo (React Native) over native Kotlin.** Expo is the default and reuses JavaScript. The risk is background audio, which needs a native module in a development build (not Expo Go). If you would rather learn Android properly for your portfolio, Kotlin + Jetpack Compose + Media3 is the stronger choice. It costs more time and changes the stack table only; the schema and API stay the same.
- **Email code and Google sign-in, not phone OTP.** The original may log in by phone (unconfirmed). Phone OTP needs a paid SMS provider, so it is left out.
- **Music comes from the Jamendo API plus your own uploads.** Both are legal sources. Jamendo's API terms and each track's licence must be checked before the first sync.

## Stack

| layer | choice | why |
| --- | --- | --- |
| mobile app | Expo (React Native) + TypeScript, built as a development build with EAS Build | Android target, one language, and a dev build allows native audio |
| playback | react-native-track-player | background playback, media notification, lock-screen and Bluetooth buttons through Android's media session. Confirm its current Expo compatibility when building; fallback is Kotlin + Media3 |
| styling | NativeWind (Tailwind for React Native), tokens from replica-design | tokens in one file, matches the pack's default |
| database | Postgres on Supabase (free tier) | one managed database, built-in auth and storage |
| data access | supabase-js with generated types, migrations through the Supabase CLI | no ORM or server of our own for plain reads and writes; RLS does the access control |
| auth | Supabase Auth: Google sign-in and email one-time code | free, and works with RLS through `auth.uid()` |
| payments | none. The Pro paywall (S22) is a mock | portfolio build. If it is ever published: Google Play Billing through RevenueCat |
| email | Resend over SMTP for the auth emails | Supabase's built-in email is heavily rate limited |
| jobs | pg_cron plus one Edge Function | catalogue sync and the weekly-top refresh |
| files | Supabase Storage for your own audio and cover art | signed URLs, private bucket |
| search | Postgres `pg_trgm` and `ilike` (the `search_catalog` function) | no separate search service at this size |
| catalogue source | Jamendo API (your own client id) + your own uploads | legal audio with a licence stored on every song |
| hosting | Supabase for the backend, EAS Build for the APK / AAB | no web host needed |

One database, no microservices, no server of our own except three small Edge Functions.

## Schema

Tables: 15, plus one materialized view (`weekly_top_songs`). Access rules: Postgres row level security on every table.

- **Catalogue** (artists, albums, songs, song_artists, stations, station_songs, home_sections, home_section_items): anyone can read. No client write policies exist, so only the service role (the sync job) can write.
- **User data** (profiles, likes, artist_follows, album_saves, play_history): each user sees and changes only their own rows.
- **Playlists:** public and curated ones are readable by everyone, user playlists are writable only by the owner, and clients cannot create curated kinds.
- **`profiles.plan` cannot be changed by the client.** Column grants allow only `display_name` and `languages`.
- **Hard constraints in the database:** a song can appear once per playlist (`unique (playlist_id, song_id)`), a play id can be written once (idempotent retries), curated playlists must be public, and every song has either an audio URL or a storage path.
- **Deliberate gap:** `home_section_items.item_id` points at a different table depending on the section's kind, so it has no foreign key. The curation code keeps it clean.

Full SQL: `schema.sql`. It was applied to a clean Postgres 16 with a Supabase-style stub, and `schema-tests/10-rls-and-rpc.test.sql` passes: another user cannot read or change your data, the plan cannot be edited, a duplicate song and a duplicate play id are rejected, search finds prefixes, mid-title words, different capitals and a typo, and a wildcard or one-letter query returns nothing.

## API

Most routes are direct table calls through supabase-js, protected by RLS. Four are SQL functions and three are Edge Functions. "who" says who may call it.

| # | method path | does | who | input | output | flow |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | auth.signInWithOtp | email a one-time code | anyone | email | session | F08 |
| 2 | auth.signInWithOAuth (Google) | Google sign-in | anyone | none | session | F08 |
| 3 | auth.signOut | end session | user | none | none | S21 |
| 4 | GET profiles (own row) | load profile | user | none | profile | F08 |
| 5 | PATCH profiles | set name and languages | user | display_name, languages | profile | F08 |
| 6 | GET home_sections + home_section_items, then batch-fetch items by kind | home rows | anyone | languages | rows with items | F01 |
| 7 | GET albums order released_on desc | New Releases | anyone | page | albums | S05 |
| 8 | GET playlists kind=chart, joined with weekly_top_songs | Top Charts | anyone | none | charts | S06 |
| 9 | GET playlists kind in (editorial, mood) | top playlists, genres, moods | anyone | language | playlists | S07 |
| 10 | GET stations | radio list | anyone | none | stations | F06 |
| 11 | GET playlists/:id with playlist_items and songs | playlist detail | anyone if public, else owner | id | playlist and songs | F01, F04 |
| 12 | GET albums/:id with songs | album detail | anyone | id | album and songs | S10 |
| 13 | GET artists/:id with songs and albums | artist page | anyone | id | artist, songs, albums | S11 |
| 14 | RPC search_catalog(q, max_results) | search songs, albums, artists, playlists | anyone (private playlists only to owner) | q, 2+ characters | ranked rows | F02 |
| 15 | GET songs?id=in.(...) | song details and stream URL, used to restore the queue | anyone | ids | songs | F01, F05 |
| 16 | POST play_history (upsert, ignore duplicates, client-made uuid) | record a play after 30 s listened | user | id, song_id, listened_s | none | F01 |
| 17 | RPC next_station_songs(station_id, exclude, limit) | next radio batch | anyone | station_id, played ids | songs | F06 |
| 18 | storage.createSignedUrl | short-lived URL for your own uploaded audio | anyone | path | URL, valid 1 hour | F01 |
| 19 | POST likes | like a song | user | song_id | none | F03 |
| 20 | DELETE likes | unlike | user | song_id | none | F03 |
| 21 | GET likes order created_at desc, with songs | Liked Songs | user | page | songs | F03 |
| 22 | GET play_history newest first, with songs (app removes repeats) | History | user | page | songs | F07 |
| 23 | DELETE play_history | clear history | user | none | none | F07 |
| 24 | POST / DELETE artist_follows | follow, unfollow | user | artist_id | none | S11 |
| 25 | POST / DELETE album_saves | save, unsave | user | album_id | none | S10 |
| 26 | GET playlists (owner), artist_follows, album_saves | Library tabs | user | none | library | F04 |
| 27 | POST playlists | create playlist | user | title | playlist | F04 |
| 28 | PATCH playlists | rename, make public | owner | title, is_public | playlist | F04 |
| 29 | DELETE playlists | delete playlist | owner | id | none | F04 |
| 30 | POST playlist_items | add a song (a duplicate returns a conflict, shown as "already in playlist") | owner | playlist_id, song_id, position | none | F04 |
| 31 | DELETE playlist_items | remove a song | owner | playlist_id, song_id | none | F04 |
| 32 | RPC reorder_playlist_items(playlist_id, song_ids) | set the order | owner | ordered ids | none | F04 |
| 33 | RPC save_queue_as_playlist(title, song_ids) | turn the queue into a playlist | user | title, ids | playlist id | F05 |
| 34 | Edge Function POST /mock-checkout | set plan to pro. Works only when `MOCK_BILLING=true` | user | none | profile | S22 |
| 35 | Edge Function sync-catalogue | pull tracks from Jamendo into artists, albums, songs, song_artists with licence | service role (job only) | filters | counts | seed |
| 36 | Edge Function POST /delete-account | delete the auth user; everything cascades | user | none | none | S21 |

Webhooks in: none (no payments, no calendar). Webhooks out: none.

Jobs:
- `sync-catalogue`: weekly, Sunday 02:00 UTC, through pg_cron calling the Edge Function. Adds new tracks and skips any licence that is not on the allowed list.
- `refresh weekly_top_songs`: every 15 minutes, through pg_cron (the command is in `schema.sql`).

The app never calls Jamendo directly, so its rate limits and key stay on the server. Only official, public APIs are used. JioSaavn's private endpoints are never touched.

## The parts that bite

- **Background playback.** Android needs a foreground service for audio, handles audio focus (a call or another app interrupts playback), kills background work in Doze, and Android 14 requires the media-playback service type. Test on a real phone with the screen off, with Bluetooth, and during a call. This is the biggest risk.
- **Licences and attribution.** Many Creative Commons tracks require the artist's name and licence to be shown, so Now Playing must display `attribution` and `license`. Non-commercial licences are fine for a portfolio but block any later monetisation, so the sync job keeps an allow-list. Check Jamendo's API terms for caching and offline use before building downloads.
- **Streaming reliability.** Signed URLs for your own files expire after an hour. On a playback error the app asks for a fresh URL and resumes. Handle buffering, network changes and a song URL that has gone missing.
- **Idempotency.** A retried play write must not count twice. The client creates the play id, and the insert ignores a duplicate. Likes are idempotent because the primary key is `(user_id, song_id)`.
- **Races.** Two devices reordering the same playlist: last write wins, in one statement. Two adds of the same song: the unique constraint decides.
- **Time zones.** All times are `timestamptz` in UTC. "Weekly" charts use a rolling 7 days, not a calendar week, so no time zone is involved.
- **Search.** Needs 2+ characters. Trigram indexes keep it fast for a catalogue of tens of thousands of tracks. Past that, move to full-text search or a search service.
- **Rate limits.** Supabase's free tier pauses an idle project and limits email sending. Use Resend and keep the project active.
- **Deletion and privacy.** Deleting the auth user removes the profile, likes, follows, saves, history and playlists through cascades. Google Play requires in-app account deletion and a data-safety form for any published app that has accounts.
- **Multi-tenancy.** None. Everything is single tenant, with per-user RLS.
- **Offline.** Downloads (a could-have) must store only your own or permitted audio, and should live in app-private storage.

## Build order

1. **Vertical slice: get a song playing, ugly.** Proves the stack and the hardest risk first.
   - Screens: S02 login, S03 home (one row), S09 playlist detail, S12 mini player, S13 now playing.
   - Tables: profiles, artists, albums, songs, song_artists, playlists, playlist_items, home_sections, home_section_items, play_history.
   - Routes: 1, 2, 4, 5, 6, 11, 15, 16, 35 (seed about 100 real tracks), 18 if you upload your own.
   - Done when a cold open reaches a playing song in 3 taps, audio keeps playing with the screen off, and lock-screen controls work, on a real phone.
2. **Must-haves** (12 in `features.csv`).
   - Screens: S04 search, S10 album, S14 queue, S15 library, S16 liked songs, S18 playlist editor, S19 add-to-playlist sheet, S20 song menu, and the polish of S12 and S13.
   - Tables: likes.
   - Routes: 12, 14, 19, 20, 21, 26, 27, 28, 29, 30, 31, 32, 33.
3. **Should-haves** (9).
   - Screens: S01 language picker, S05 New Releases, S06 Top Charts, S07 Top Playlists, S08 Radio, S11 artist page, S17 history, S21 settings (audio quality), shuffle and repeat.
   - Tables: stations, station_songs, weekly_top_songs.
   - Routes: 3, 7, 8, 9, 10, 13, 17, 22, 23, 36 (before any Play Store release).
4. **Could-haves** (10), as time allows.
   - S22 mock paywall (route 34), follows and saves (24, 25), share link (a deep link to public playlists), offline downloads of permitted audio, lyrics from your own text, sleep timer, podcasts, simple recommendations.
5. **Fixes from replica-entrepreneur:** added after that skill has read the reviews.
