# DSK 7 component specs

Tokens come from `tokens.json` (roles like `bg`, `surface`, `accent`). Components use class names such as `bg-surface text-muted`, never raw hex. Screen IDs (S01-S22) come from `recon.md`.

**Not measured from the original.** There were no screenshots, so these specs follow common Android and dark music-player conventions. After the user captures screenshots, compare and adjust values in `tokens.json`, not in components.

## Rules for every component

- **Touch targets:** at least 48 x 48 dp (`min-h-touch min-w-touch`). Small visuals get padding or `hitSlop` to reach it.
- **Icons:** Lucide (`lucide-react-native`, ISC licence), 24 dp, 2 dp stroke, colour from tokens. Names in use: `play`, `pause`, `skip-back`, `skip-forward`, `shuffle`, `repeat`, `repeat-1`, `heart`, `list-music`, `search`, `house`, `library`, `ellipsis-vertical`, `plus`, `chevron-down`, `x`, `download`, `share-2`, `clock`, `radio`, `check`, `alert-triangle`.
- **No JioSaavn assets.** No logo, icon, illustration, photo, sound, font or copy from the original. Empty states are an icon plus a short sentence. Cover art that is missing falls back to the generated tile below.
- **TalkBack:** every control has `accessibilityRole` and a label that says what it does (for example "Like Moonlight Drive", not "heart"). State goes in `accessibilityState` (selected, disabled, busy, checked). Nothing is told by colour alone: the playing song also gets an animated bars icon, a selected tab also gets a heavier label.
- **Focus:** a visible 2 dp `accent` ring on keyboard or switch focus.
- **Motion:** `motion.fast` (120 ms) for press feedback, `motion.base` (200 ms) for sheets and fades. When the system "remove animations" setting is on, use no movement, only fades.
- **Fonts:** Inter, loaded with `@expo-google-fonts/inter`. React Native has one font family per weight, so use `font-sans`, `font-sans-medium`, `font-sans-semibold`, `font-sans-bold`.
- **Spacing:** only `0, 1, 2, 3, 4, 6, 8, 12, 16` (4, 8, 12, 16, 24, 32, 48, 64 dp). Screen gutter is 16 dp.
- **Elevation:** on a dark theme, depth comes from the surface steps `bg` < `surface` < `surface-raised`. Android gets `elevation` 2 (cards) and 8 (sheets). Shadows are only for sheets and toasts.

## CoverArt (fallback tile)

```
CoverArt
  variants  square (songs, albums, playlists), circle (artists), station (square with radio icon)
  sizes     thumb 48, row 56, card 140, hero = screen width minus 48
  states    loading (surface-raised block), loaded, error or missing (generated tile)
  tokens    radius md (circle: pill), bg surface-raised
  fallback  a gradient tile generated from the item id, with the first letter of the title.
            Our own design: two colours taken from a fixed 8-colour set, never the original's art.
  a11y      decorative (accessibilityElementsHidden) when the title is next to it
  used on   S03-S11, S13, S14, S16-S18
```

## Button

```
Button
  variants  primary (accent fill), secondary (surface-raised fill, border), ghost (text only), danger
  sizes     sm 36 dp, md 48 dp, lg 56 dp (md is the default; sm still gets a 48 dp hit area)
  states    default, pressed (10% darker fill, motion fast), focus (2 dp accent ring), disabled (40% opacity, not pressable), loading (spinner replaces the icon, label stays for TalkBack)
  tokens    primary: bg accent, text on-accent; secondary: bg surface-raised, text text; radius pill; font sm 600
  a11y      role button; loading sets accessibilityState busy; disabled sets disabled
  used on   S01, S02, S18, S22
```

## IconButton

```
IconButton
  variants  plain, filled (surface-raised), accent (play button on Now Playing)
  sizes     md 48 dp, lg 64 dp (main play button)
  states    default, pressed, focus, disabled, toggled-on (heart and shuffle show accent colour and a filled icon)
  tokens    icon text or accent; toggled-on adds the filled icon so colour is not the only signal
  a11y      role button, label says the action; toggles use accessibilityState checked
  used on   S12, S13, S14, S20
```

## ContentCard

```
ContentCard
  variants  song, album, playlist, artist (circle art), station
  sizes     row card 140 dp wide (horizontal rows), grid card fills half the width minus the gap (S05-S08)
  states    default, pressed (scale .98, fade), playing (accent title and bars icon), loading (skeleton)
  tokens    art radius md; title sm 600 text, one line; subtitle xs text-muted, one line; gap 2
  a11y      role button; label "Title, by Artist, album"; the whole card is one target
  used on   S03, S05, S06, S07, S08, S11
```

## SectionRow

```
SectionRow
  variants  with "See all" action, without
  sizes     title lg; row height is card height plus 56
  states    loading (3 skeleton cards), filled, error (message plus retry button), empty (row is hidden)
  tokens    title text, action text-muted xs 500, gutter 16, card gap 12, snap to card edges
  a11y      the title is a header; the list announces "n items"
  used on   S03
```

## SongRow

```
SongRow
  variants  with art (default), with index number (album and chart), with drag handle (queue and playlist editor)
  sizes     56 dp tall (min), art 48
  states    default, pressed (surface), playing (accent title plus animated bars), unavailable (50% opacity, "Not available" in text-muted), dragging (surface-raised, elevation card)
  tokens    title sm 600 text, subtitle xs text-muted, duration xs text-muted, more button on the right
  a11y      role button; label "Title, by Artist, 3 minutes 20"; the more button is its own control; drag handle offers move up and move down actions
  used on   S09, S10, S14, S16, S17, S18
```

## MiniPlayer

```
MiniPlayer
  variants  none
  sizes     64 dp tall, sits above bottom navigation, full width
  states    hidden (nothing queued), playing, paused, buffering (thin indeterminate bar on top), error ("Can't play this song" with a skip button)
  tokens    bg surface-raised, border top 1 dp border, art 48, title sm 600, artist xs text-muted, a 2 dp progress line on top in accent
  a11y      the bar opens Now Playing (role button, label "Open player, Title, by Artist"); play and pause and next are separate controls; progress is announced only on request
  used on   all main screens (S03-S11, S15-S17)
```

## SeekBar

```
SeekBar
  variants  none
  sizes     track 4 dp (8 dp while dragging), thumb 16 dp, touch height 48 dp
  states    idle, dragging (thumb grows, time labels show the drag position), buffering (the buffered part drawn as a lighter track), disabled
  tokens    filled part accent, unfilled part track, thumb accent; times xs text-muted
  a11y      role adjustable; accessibilityValue gives "1 minute 12 of 3 minutes 20"; swipe up or down seeks 10 seconds
  used on   S13
```

## PlayerControls

```
PlayerControls
  variants  none (shuffle, previous, play or pause, next, repeat in one row)
  sizes     play button 64 dp, others 48 dp
  states    playing, paused, loading (spinner on the play button), error (play button becomes a retry), shuffle on or off, repeat off, repeat all, repeat one
  tokens    play button accent fill with on-accent icon; others plain icons in text; active toggles in accent
  a11y      labels such as "Pause", "Next song", "Repeat: off"; the repeat button announces its new mode
  used on   S13
```

## SearchField

```
SearchField
  variants  idle (a tappable field on the Search tab), active (focused, with results below)
  sizes     48 dp tall, radius pill
  states    empty (placeholder), typing (clear button appears), results, no results, error, short query (fewer than 2 characters shows recent searches, not an error)
  tokens    bg surface-raised, border border-input when focused, text text, placeholder text-muted
  a11y      role search; clear button labelled "Clear search"; result count is announced after typing stops
  used on   S04
```

## Chips and tabs

```
Chip / Tab
  variants  filter chip (search result types, language picker), library tab (underlined)
  sizes     chip 36 dp tall with 48 dp hit area; tab 48 dp
  states    unselected (border), selected (accent fill with on-accent text; tab: accent underline and 600 weight), pressed, disabled
  tokens    chip radius pill, font sm 500; tab font sm 600
  a11y      role tab inside a tablist, or checkbox for multi-select chips (S01); selected state is announced
  used on   S01, S04, S15
```

## BottomNav

```
BottomNav
  variants  none (Home, Search, Library; Pro is not a tab)
  sizes     56 dp plus the system navigation inset
  states    selected (accent icon, filled style, 600 label), unselected (text-muted), pressed
  tokens    bg surface, border top 1 dp border, label xs
  a11y      role tablist; each item is a tab with its label; selected state announced
  used on   S03, S04, S15 (hidden on S13 Now Playing)
```

## BottomSheet

```
BottomSheet
  variants  action list (song menu S20), picker (add to playlist S19), confirm
  sizes     height fits content up to 90% of the screen; radius lg on the top corners
  states    closed, opening (motion base), open, dragging down to dismiss, closing
  tokens    bg surface-raised, elevation pop, scrim black at 60%, drag handle 32 x 4 dp in track colour
  a11y      focus moves into the sheet when it opens and back to the trigger when it closes; the scrim and the back button close it; the title is a header
  used on   S19, S20, S22
```

## Toast

```
Toast
  variants  info, success, error
  sizes     one line (two at most), sits 8 dp above the mini player
  states    entering, visible (3 seconds, or 6 with an action), leaving
  tokens    bg surface-raised, elevation pop, left icon in success, danger or text
  a11y      announced as a live region (polite; assertive for error); actions such as "Undo" are reachable
  used on   all screens (copy such as "Added to Road trip", "Already in this playlist")
```

## EmptyState

```
EmptyState
  variants  per screen (queue, liked songs, history, playlist, library when logged out, search with no results)
  sizes     centred in the available space, icon 48 dp
  states    default; with a button when there is an action to take
  tokens    icon text-muted, title base 600 text, body sm text-muted, max width 280
  copy      written fresh, for example:
            Queue: "Nothing up next. Add songs from any menu."
            Liked songs: "No likes yet. Tap the heart on a song to keep it here."
            History: "Nothing played yet."
            Library (logged out): "Log in to keep your likes and playlists." (button: "Log in")
            Search no results: "No matches for that. Try a shorter word."
  a11y      the title is a header
  used on   S04, S14, S15, S16, S17, S18
```

## Skeleton

```
Skeleton
  variants  card, song row, header
  states    shimmering (a slow fade between surface and surface-raised, 1.2 s; static when reduce motion is on)
  tokens    bg surface-raised, same radius as the thing it replaces
  a11y      hidden from TalkBack; the screen announces "Loading" once
  used on   S03-S11, S15-S17
```

## Attribution

```
Attribution
  variants  inline (one line under the title on Now Playing), full (details sheet with a link)
  states    default; missing (never shown as blank, the licence name is always known)
  tokens    xs text-muted; the licence name is a link in accent text
  a11y      the link has the label "Licence: CC BY 4.0, open details"
  note      required by the schema: every song carries `attribution` and `license`, and Creative Commons tracks must credit the artist
  used on   S13
```

## PlanCard

```
PlanCard
  variants  monthly, student, lite (mock plans for the portfolio build; the prices are placeholders, not the original's)
  sizes     full width, 96 dp tall
  states    default (border), selected (accent border 2 dp and a check icon), disabled
  tokens    bg surface, selected bg surface-raised, price lg 600, description sm text-muted
  a11y      role radio inside a radio group; "Monthly plan, selected"
  used on   S22
```
