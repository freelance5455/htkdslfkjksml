-- Staff roles: viewer reads drafts, editor writes the catalogue, admin manages staff.
-- Run after 10-rls-and-rpc.test.sql (it leaves the catalogue in place).
-- Output: one PASS or FAIL line per check.
\set ON_ERROR_STOP off

create or replace function t_expect_error(label text, stmt text) returns void
language plpgsql as $$
begin
  execute stmt;
  raise notice 'FAIL (allowed, expected a refusal): %', label;
exception when others then
  raise notice 'PASS: % (refused: %)', label, left(sqlerrm, 60);
end $$;

create or replace function t_expect_rows(label text, stmt text, want bigint) returns void
language plpgsql as $$
declare n bigint;
begin
  execute 'select count(*) from (' || stmt || ') q' into n;
  if n = want then raise notice 'PASS: % (% rows)', label, n;
  else raise notice 'FAIL: % (got % rows, want %)', label, n, want; end if;
end $$;

-- users and roles (superuser)
insert into auth.users (id) values
  ('00000000-0000-0000-0000-0000000000c3'),  -- viewer
  ('00000000-0000-0000-0000-0000000000d4'),  -- editor
  ('00000000-0000-0000-0000-0000000000e5'),  -- admin
  ('00000000-0000-0000-0000-0000000000f6')   -- a second viewer, added by the admin below
on conflict do nothing;
insert into staff_roles (user_id, role) values
  ('00000000-0000-0000-0000-0000000000c3', 'viewer'),
  ('00000000-0000-0000-0000-0000000000d4', 'editor'),
  ('00000000-0000-0000-0000-0000000000e5', 'admin');
-- one draft song only staff should see
insert into songs (id, title, duration_s, audio_url, license, published) values
  ('22222222-2222-2222-2222-222222222229', 'Draft Song', 90, 'http://x/d.mp3', 'CC0 1.0', false);

-- plain user: no drafts, no staff writes
set role authenticated;
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000a1';
select t_expect_rows('user does not see drafts', $q$select id from songs where title = 'Draft Song'$q$, 0);
select t_expect_error('user cannot add a song', $q$insert into songs (title, duration_s, audio_url, license) values ('Hack', 60, 'x', 'CC0 1.0')$q$);
select t_expect_error('user cannot read other profiles', $q$insert into staff_roles (user_id, role) values (auth.uid(), 'admin')$q$);

-- viewer: sees drafts and staff list (own row), cannot write
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000c3';
select t_expect_rows('viewer sees the draft', $q$select id from songs where title = 'Draft Song'$q$, 1);
select t_expect_rows('viewer sees only their own staff row', $q$select user_id from staff_roles$q$, 1);
select t_expect_error('viewer cannot add a song', $q$insert into songs (title, duration_s, audio_url, license) values ('Hack', 60, 'x', 'CC0 1.0')$q$);
update songs set title = 'Hacked' where title = 'Draft Song';
select t_expect_rows('viewer update changed nothing', $q$select id from songs where title = 'Hacked'$q$, 0);

-- editor: writes the catalogue and curated playlists, not staff roles
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000d4';
select t_expect_rows('editor sees the draft', $q$select id from songs where title = 'Draft Song'$q$, 1);
insert into songs (id, title, duration_s, audio_url, license, published) values
  ('22222222-2222-2222-2222-22222222222a', 'Editor Song', 120, 'http://x/e.mp3', 'CC BY 4.0', true);
select t_expect_rows('editor added a published song', $q$select id from songs where title = 'Editor Song' and published$q$, 1);
update songs set published = true where title = 'Draft Song';
select t_expect_rows('editor published a draft', $q$select id from songs where title = 'Draft Song' and published$q$, 1);
insert into playlists (title, kind, is_public) values ('Editor Mix', 'editorial', true);
select t_expect_rows('editor created an editorial playlist', $q$select id from playlists where title = 'Editor Mix'$q$, 1);
select t_expect_error('editor cannot make a user playlist for someone else', $q$insert into playlists (owner_id, title, kind) values ('00000000-0000-0000-0000-0000000000a1', 'Not mine', 'user')$q$);
select t_expect_error('editor cannot make themselves admin', $q$insert into staff_roles (user_id, role) values (auth.uid(), 'admin')$q$);
update staff_roles set role = 'admin' where user_id = auth.uid();
select t_expect_rows('editor role change had no effect', $q$select user_id from staff_roles where role = 'admin' and user_id = '00000000-0000-0000-0000-0000000000d4'$q$, 0);
select t_expect_error('editor cannot change a plan (column grant)', $q$update profiles set plan = 'pro' where id = auth.uid()$q$);

-- admin: manages staff
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000e5';
insert into staff_roles (user_id, role) values ('00000000-0000-0000-0000-0000000000f6', 'viewer');
select t_expect_rows('admin sees all staff rows', $q$select user_id from staff_roles$q$, 4);

reset role;
