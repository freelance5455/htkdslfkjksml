-- Plain user rules, functions, and search. Every check prints PASS or FAIL.
-- Supabase grants table access by default; the stub db does the same in 00-supabase-stub.sql.

-- users and catalogue (superuser, as the sync job would write it)
insert into auth.users (id) values ('00000000-0000-0000-0000-0000000000a1'), ('00000000-0000-0000-0000-0000000000b2');
insert into artists (id, name) values ('11111111-1111-1111-1111-111111111111', 'Test Artist');
insert into songs (id, title, duration_s, audio_url, license, published) values
 ('22222222-2222-2222-2222-222222222221', 'Moonlight Drive', 200, 'http://x/1.mp3', 'CC-BY', true),
 ('22222222-2222-2222-2222-222222222222', 'Monsoon Beat', 180, 'http://x/2.mp3', 'CC-BY', true),
 ('22222222-2222-2222-2222-222222222223', 'Sunrise Raga', 240, 'http://x/3.mp3', 'CC-BY', true);
select t_expect_rows('a profile is created for each sign-up', $q$select id from profiles$q$, 2);

-- user A
set role authenticated;
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000a1';
select t_expect_rows('user sees the 3 published songs', $q$select id from songs$q$, 3);
insert into likes (user_id, song_id) values (auth.uid(), '22222222-2222-2222-2222-222222222221');
select t_expect_error('a like cannot be written for another user', $q$insert into likes (user_id, song_id) values ('00000000-0000-0000-0000-0000000000b2', '22222222-2222-2222-2222-222222222221')$q$);
select t_expect_error('a user cannot create an editorial playlist', $q$insert into playlists (owner_id, title, kind, is_public) values (auth.uid(), 'Hack', 'editorial', true)$q$);
select t_expect_error('a user cannot change their own plan', $q$update profiles set plan = 'pro' where id = auth.uid()$q$);
update profiles set display_name = 'Asha', languages = '{hi,en}' where id = auth.uid();
select t_expect_true('display name can be changed', (select display_name = 'Asha' from profiles where id = auth.uid()));
select save_queue_as_playlist('Road trip', array['22222222-2222-2222-2222-222222222221','22222222-2222-2222-2222-222222222222','22222222-2222-2222-2222-222222222223','22222222-2222-2222-2222-222222222221']::uuid[]);
select t_expect_rows('saved queue keeps each song once', $q$select pi.id from playlist_items pi join playlists p on p.id = pi.playlist_id where p.title = 'Road trip'$q$, 3);
select t_expect_error('a song cannot appear twice in one playlist', $q$insert into playlist_items (playlist_id, song_id, position) values ((select id from playlists where title = 'Road trip'), '22222222-2222-2222-2222-222222222222', 9)$q$);
select reorder_playlist_items((select id from playlists where title = 'Road trip'), array['22222222-2222-2222-2222-222222222223','22222222-2222-2222-2222-222222222222','22222222-2222-2222-2222-222222222221']::uuid[]);
select t_expect_true('reorder sets the new order', (
  select string_agg(s.title, ' > ' order by pi.position) = 'Sunrise Raga > Monsoon Beat > Moonlight Drive'
  from playlist_items pi join songs s on s.id = pi.song_id
  where pi.playlist_id = (select id from playlists where title = 'Road trip')));
insert into play_history (id, user_id, song_id, listened_s) values ('33333333-3333-3333-3333-333333333333', auth.uid(), '22222222-2222-2222-2222-222222222221', 45);
select t_expect_error('the same play cannot be recorded twice', $q$insert into play_history (id, user_id, song_id, listened_s) values ('33333333-3333-3333-3333-333333333333', auth.uid(), '22222222-2222-2222-2222-222222222221', 45)$q$);

-- search
select t_expect_true('search finds a prefix', (select exists (select 1 from search_catalog('moon') where title = 'Moonlight Drive')));
select t_expect_true('search ignores capitals', (select exists (select 1 from search_catalog('MOON') where title = 'Moonlight Drive')));
select t_expect_true('search finds a word inside a title', (select exists (select 1 from search_catalog('drive') where title = 'Moonlight Drive')));
select t_expect_true('search finds an artist', (select exists (select 1 from search_catalog('test art') where kind = 'artist')));
select t_expect_true('search tolerates a typo', (select exists (select 1 from search_catalog('monsoom') where title = 'Monsoon Beat')));
select t_expect_rows('one letter returns nothing', $q$select * from search_catalog('m')$q$, 0);
select t_expect_rows('a wildcard is treated as plain text', $q$select * from search_catalog('%%')$q$, 0);
select t_expect_true('the closer title ranks first', (select title = 'Moonlight Drive' from search_catalog('mo') limit 1));

-- user B cannot see or touch A's data
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000b2';
select t_expect_rows('B sees none of A''s likes', $q$select * from likes$q$, 0);
select t_expect_rows('B sees none of A''s private playlists', $q$select * from playlists where title = 'Road trip'$q$, 0);
select t_expect_rows('B sees none of A''s playlist items', $q$select * from playlist_items$q$, 0);
select t_expect_rows('B sees none of A''s history', $q$select * from play_history$q$, 0);
update playlist_items set position = 99;
delete from playlists where title = 'Road trip';
reset role;
select t_expect_rows('B could not change A''s playlist order', $q$select id from playlist_items where position = 99$q$, 0);
select t_expect_rows('B could not delete A''s playlist', $q$select id from playlists where title = 'Road trip'$q$, 1);

-- the weekly counts refresh and hold the one play recorded above
refresh materialized view concurrently weekly_top_songs;
select t_expect_rows('weekly top has the song that was played', $q$select song_id from weekly_top_songs$q$, 1);
