-- Shared check helpers. Each check prints one PASS or FAIL line.

create or replace function t_expect_error(label text, stmt text) returns void
language plpgsql as $$
begin
  execute stmt;
  raise notice 'FAIL (allowed, expected a refusal): %', label;
exception when others then
  -- Count only the refusals we mean: constraint violations (23xxx) and
  -- row level security or permission denied (42501). A syntax error is a FAIL.
  if sqlstate like '23%' or sqlstate = '42501' then
    raise notice 'PASS: % (refused: %)', label, left(sqlerrm, 60);
  else
    raise notice 'FAIL: % (wrong error %: %)', label, sqlstate, sqlerrm;
  end if;
end $$;

create or replace function t_expect_rows(label text, stmt text, want bigint) returns void
language plpgsql as $$
declare n bigint;
begin
  execute 'select count(*) from (' || stmt || ') q' into n;
  if n = want then raise notice 'PASS: % (% rows)', label, n;
  else raise notice 'FAIL: % (got % rows, want %)', label, n, want; end if;
end $$;

create or replace function t_expect_true(label text, cond boolean) returns void
language plpgsql as $$
begin
  if cond then raise notice 'PASS: %', label;
  else raise notice 'FAIL: %', label; end if;
end $$;
