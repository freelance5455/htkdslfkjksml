# Schema tests

Checks `../schema.sql` on a throwaway local Postgres 15+ (no Supabase needed).

```bash
createdb dsk7_test
psql -d dsk7_test -v ON_ERROR_STOP=1 -f 00-supabase-stub.sql   # fake auth schema, anon/authenticated roles
psql -d dsk7_test -v ON_ERROR_STOP=1 -f ../schema.sql
psql -d dsk7_test -f 10-rls-and-rpc.test.sql                    # read the output
```

Lines that say `expect ERROR` must be followed by an ERROR. The others must show
the value in the label. Run this again after every schema change.
