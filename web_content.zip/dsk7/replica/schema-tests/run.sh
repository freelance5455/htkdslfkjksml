#!/usr/bin/env bash
# Loads the schema into a throwaway Postgres 15+ and runs every check.
# Needs psql, initdb and pg_ctl on the PATH (or PG_BIN=/path/to/bin). Exit 1 on any FAIL.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BIN="${PG_BIN:-$(dirname "$(readlink -f "$(command -v pg_ctl || ls /usr/lib/postgresql/*/bin/pg_ctl 2>/dev/null | head -1)")")}"
# Postgres refuses to run as root, so as root we act as the postgres user.
AS=()
if [ "$(id -u)" -eq 0 ]; then AS=(runuser -u postgres --); fi
D="$(mktemp -d /var/tmp/dsk7pg.XXXXXX)"
[ "$(id -u)" -eq 0 ] && chown postgres:postgres "$D"
PORT="${DSK7_PG_PORT:-55432}"
"${AS[@]}" "$BIN/initdb" -D "$D/data" -A trust >/dev/null || exit 2
"${AS[@]}" "$BIN/pg_ctl" -D "$D/data" -o "-p $PORT -k $D -c listen_addresses=''" -l "$D/log" -w start >/dev/null || exit 2
trap '"${AS[@]}" "$BIN/pg_ctl" -D "$D/data" stop -m immediate >/dev/null 2>&1; rm -rf "$D"' EXIT
P=("${AS[@]}" "$BIN/psql" -h "$D" -p "$PORT" -X -q -v ON_ERROR_STOP=1)
"${P[@]}" -d postgres -c "create database dsk7" || exit 2
for f in 00-supabase-stub.sql ../schema.sql 05-helpers.sql 10-rls-and-rpc.test.sql 20-staff.test.sql; do
  "${P[@]}" -d dsk7 -f "$HERE/$f" > "$D/out.txt" 2>&1 || true
  # the runner reads the output file, so make it readable for the postgres user's output
  true
  case "$f" in *test.sql) if ! grep -qE "PASS|FAIL" "$D/out.txt"; then echo "no checks reported by $f:"; head -8 "$D/out.txt"; fi;; esac
  grep -E "PASS|FAIL" "$D/out.txt" | sed -E 's/^psql:[^ ]+ //; s/^[A-Z]+:[[:space:]]+//'
  if grep -qE "^ERROR:" "$D/out.txt"; then
    echo "ERROR while running $f:"; grep -E "^ERROR:" "$D/out.txt" | head -3; echo "RESULT: failures found"; exit 1
  fi
done
echo "--"
if "${P[@]}" -d dsk7 -f "$HERE/../seed.sql" > "$D/seed.txt" 2>&1; then echo "seed.sql loads cleanly"; else echo "seed.sql FAILED"; exit 1; fi
