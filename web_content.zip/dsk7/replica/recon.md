# Recon map: JioSaavn (Android), cloned as "DSK 7"

Scope: core loop only. Browse and search, play music, queue, likes, playlists, library, history. Podcasts, downloads and payments are lower priority.
For: the user's own portfolio and learning project. Not a commercial launch.
Date: 2026-10-18

**Evidence caveat.** This map comes from public pages only: the web home page, the App Store listing, a pricing article and Wikipedia. No Android screenshots were captured and no account was used. Android screens below are inferred from the web layout and the store text, so each one carries a confidence level. Before `/replica-design`, the user should drive their own JioSaavn account on a phone and add screenshots to `replica/screens/`.

## Sources

| # | source | URL | notes |
| --- | --- | --- | --- |
| 1 | marketing site / web player (home page) | https://www.jiosaavn.com | read: nav, browse and library menus, home rows, queue panel, player bar. Login UI not visible in the capture |
| 2 | App Store listing | https://apps.apple.com/app/id441813332 | read: feature pitch, languages, Pro features, price list. Screenshots had no captions |
| 3 | pricing article (Sep 2025) | https://www.thetechoutlook.com/news/apps/jiosaavn-now-offering-pro-subscription-at-₹9-for-first-two-months/ | Pro plans and prices, third-party reporting |
| 4 | Wikipedia | https://en.wikipedia.org/wiki/JioSaavn | content model, licensing, tier history |
| 5 | help center | not found | official help articles did not surface in search; gap. Settings and error states are therefore guesses |
| 6 | Google Play listing | not read | gap. Needed for the Android screenshots and feature text |

## Core loop

Open the app, find music through the home rows or search, tap a song, and keep listening while the queue plays on, saving what you like into Liked Songs and your own playlists.

## Screens

| ID | screen | route / how to reach | purpose | key components | states seen | confidence |
| --- | --- | --- | --- | --- | --- | --- |
| S01 | Language picker / onboarding | first launch | choose music languages | language chips, continue button | first run | guess |
| S02 | Login / sign up | first launch or Library | create or enter account | phone, email or Google field, OTP | empty, error | guess |
| S03 | Home | bottom nav: Home | curated discovery | horizontal rows, cards, mini player | loading, filled | high (web) |
| S04 | Search | bottom nav: Search | find songs, albums, artists, playlists | search field, result tabs, recents | empty, results, no results | high |
| S05 | Browse: New Releases | Home > Browse | recent albums and songs | card grid | filled | high (web menu) |
| S06 | Browse: Top Charts | Home > Browse | chart playlists | chart cards | filled | high |
| S07 | Browse: Top Playlists / Genres and Moods | Home > Browse | playlists by genre and mood | cards | filled | high |
| S08 | Radio stations | Home > Browse | mood and artist stations | station cards | filled | high |
| S09 | Playlist detail | tap a playlist | song list, play all | header art, song rows, play and shuffle buttons | filled, empty (own playlist) | high |
| S10 | Album detail | tap an album | track list | header art, track rows | filled | high |
| S11 | Artist page | tap an artist | top songs, albums | header, top songs, follow button | filled | medium |
| S12 | Mini player | persistent bar | quick controls | art, title, play and pause, next | hidden, playing, paused | high |
| S13 | Now Playing | expand mini player | full playback controls | art, seek bar, prev, next, shuffle, repeat, like, queue | loading, playing, paused, error | high |
| S14 | Queue | from Now Playing | see and edit up next | song rows, drag handle, clear, save | empty, filled | high (web panel) |
| S15 | Library | bottom nav: Library | your saved items | tabs for Liked Songs, Albums, Podcasts, Artists, Playlists, History | empty, filled, logged out | high (web menu) |
| S16 | Liked Songs | Library | songs you liked | song rows, play all | empty, filled | high |
| S17 | Listening History | Library | recently played | song rows | empty, filled | high |
| S18 | Create / edit playlist | Library > New Playlist | name and manage a playlist | name field, song rows, reorder | empty, filled | medium |
| S19 | Add to playlist sheet | song overflow menu | add a song to a playlist | playlist list, new playlist row | filled | medium |
| S20 | Song overflow menu | three dots on a song | like, add, queue, share | action list | n/a | medium |
| S21 | Settings | profile icon | audio quality, language, account | toggles, quality picker | default | guess |
| S22 | Pro upsell / paywall | locked feature | sell Pro | plan cards, price, CTA | n/a | medium |

## Flows

```
F01 Play a song from home
    S03 home -> S09 playlist detail -> S13 now playing
    happy path clicks: 3 (open playlist, tap song, expand player optional)
    edge: no network, song unavailable, audio focus lost to a call

F02 Search and play
    S04 search -> (type) -> results -> S13 now playing
    happy path clicks: 3
    edge: no results, typo, slow network, empty query

F03 Like a song
    S13 now playing -> like button -> S16 liked songs
    happy path clicks: 1
    edge: logged out (prompt to log in), toggle off

F04 Create a playlist and add songs
    S15 library -> S18 create playlist -> S20 song overflow menu -> S19 add to playlist
    happy path clicks: 6
    edge: duplicate name, empty playlist, song already in playlist

F05 Manage the queue
    S20 overflow menu -> add to queue -> S14 queue -> reorder or clear
    happy path clicks: 3
    edge: empty queue shows "Play Weekly Top Songs" prompt on web

F06 Start a radio station
    S08 radio -> station -> S13 now playing
    happy path clicks: 2
    edge: station has no more songs

F07 Review history
    S15 library -> S17 history -> S13 now playing
    happy path clicks: 3
    edge: empty history, logged out

F08 Log in and set languages (first run)
    S01 language picker -> S02 login -> S03 home
    happy path clicks: unknown (screens inferred)
    edge: wrong OTP, skip login
```

Number to beat: a song plays in 3 taps from a cold open.

## Components

| component | variants | states | used on |
| --- | --- | --- | --- |
| Button | primary, secondary, ghost, icon | default, pressed, disabled, loading | all |
| Content card (square art, title, subtitle) | song, album, playlist, artist (round), station | default, pressed, playing | S03, S05-S08, S11 |
| Horizontal row with section title | with "see all" | loading skeleton, filled | S03 |
| Song row | with art, with index, with drag handle | default, playing, unavailable | S09, S10, S14, S16, S17 |
| Mini player bar | n/a | hidden, playing, paused, buffering | all main screens |
| Seek bar | n/a | idle, dragging, buffering | S13 |
| Player controls | n/a | play, pause, loading, error | S13 |
| Search field | n/a | empty, typing, results, clear | S04 |
| Tabs / chips | filter, library tabs, language | selected, unselected | S01, S04, S15 |
| Bottom navigation | 4 items | selected, unselected | main screens |
| Bottom sheet (overflow, add to playlist) | n/a | open, closed | S19, S20 |
| Toast / snackbar | success, error | n/a | all |
| Empty state | per screen | n/a | S14, S15-S18 |
| Paywall plan card | monthly, student, lite | selected | S22 |

## Inferred data model

```
User         id, name, email or phone, languages[], plan (free | pro), created_at
             evidence: S01, S02, S21, pricing article
             confidence: medium

Artist       id, name, image_url, follower_count
             evidence: S11, home rows ("follower count" shown on cards)
             confidence: high

Album        id, title, artist_id, cover_url, year
             evidence: S10, home "New Releases"
             confidence: high

Song         id, title, album_id, duration_s, audio_url, language, explicit
             evidence: S09, S10, S13
             confidence: high

SongArtist   song_id, artist_id, role
             evidence: songs list several artists
             confidence: medium

Playlist     id, title, owner_id (null for editorial), cover_url, kind (editorial | chart | mood | user), follower_count
             evidence: S07, S09, S18, home rows
             confidence: high

PlaylistItem playlist_id, song_id, position, added_at
             evidence: S09, S18
             confidence: high

Like         user_id, song_id, created_at
             evidence: S13, S16
             confidence: high

Follow       user_id, artist_id (and album saves in the same shape)
             evidence: S11, S15 tabs
             confidence: medium

PlayHistory  user_id, song_id, played_at
             evidence: S17, web "History" link
             confidence: high

Station      id, title, kind (mood | artist), seed_artist_id
             evidence: S08, home "Radio Stations", "Artist Stations"
             confidence: medium

Chart        id, title, period, playlist_id
             evidence: S06
             confidence: medium

QueueItem    song_id, position   (client state, saved queue optional)
             evidence: web queue panel with Save and Clear
             confidence: medium
```

Relationships: User 1-n Playlist, Playlist 1-n PlaylistItem n-1 Song, Song n-1 Album, Song n-n Artist, User n-n Song (Like), User n-n Artist (Follow), User 1-n PlayHistory, Station n-1 Artist.

## Feature matrix

See `features.csv`. Must: 12, should: 9, could: 10, skip: 5.

## Out of scope (cannot or should not be cloned)

- The licensed catalogue: 80 million plus tracks under deals with 900+ labels. DSK 7 must use its own, royalty-free or Creative Commons audio (for example Jamendo or the Free Music Archive, checking each licence) or audio the user owns. It must not rip or stream JioSaavn's or anyone's copyrighted music.
- Label exclusives, Artist Originals and podcast partnerships.
- JioTunes caller tunes, which depend on Jio's telecom network.
- The user base, social graph and chat.
- Song recognition, which is third-party technology.
- Lyrics: licensed. Use original text or none.
- Real subscription billing: mock the paywall for the portfolio version.
- JioSaavn's logo, name, copy, editorial playlist names and artwork. DSK 7 gets its own brand and its own editorial lists.

## Size

Screens 22, flows 8, entities 13. Hard parts: reliable background playback with media session and audio focus on Android, a music catalogue with enough legal audio to feel real, search that stays fast as the catalogue grows. Size: M (a few weeks), because Android alone with a small legal catalogue and no real billing keeps it out of L.
