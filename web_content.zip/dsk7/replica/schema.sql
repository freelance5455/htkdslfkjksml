-- DSK 7 schema. Postgres 15+ on Supabase.
-- Access rules: Postgres row level security (RLS) on every table.
-- Catalogue tables are public read, written only by the service role (the sync job).
-- User tables are owner only. Times are timestamptz (UTC).
-- Pure join tables use a composite primary key instead of an id column.

create extension if not exists pg_trgm;

create or replace function set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------------------------------------------------------------- users

-- One row per auth user. id is the auth user id (no default on purpose).
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  languages text[] not null default '{}',
  plan text not null default 'free' check (plan in ('free', 'pro')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_updated before update on profiles
  for each row execute function set_updated_at();

create function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', ''));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- ------------------------------------------------------------ catalogue

create table artists (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  image_url text,
  source text not null default 'upload' check (source in ('jamendo', 'upload')),
  source_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (source, source_id)
);
create index artists_name_trgm on artists using gin (name gin_trgm_ops);
create trigger artists_updated before update on artists
  for each row execute function set_updated_at();

create table albums (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  artist_id uuid references artists(id) on delete set null,
  cover_url text,
  released_on date,
  source text not null default 'upload' check (source in ('jamendo', 'upload')),
  source_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (source, source_id)
);
create index albums_artist_idx on albums (artist_id);
create index albums_released_idx on albums (released_on desc);
create index albums_title_trgm on albums using gin (title gin_trgm_ops);
create trigger albums_updated before update on albums
  for each row execute function set_updated_at();

-- Every song carries its licence. Attribution is shown on Now Playing.
create table songs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  album_id uuid references albums(id) on delete set null,
  duration_s integer not null check (duration_s > 0),
  audio_url text,
  storage_path text,
  language text,
  explicit boolean not null default false,
  license text not null,
  license_url text,
  attribution text not null default '',
  source text not null default 'upload' check (source in ('jamendo', 'upload')),
  source_id text,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (source, source_id),
  constraint songs_has_audio check (audio_url is not null or storage_path is not null)
);
create index songs_album_idx on songs (album_id);
create index songs_language_idx on songs (language);
create index songs_title_trgm on songs using gin (title gin_trgm_ops);
create trigger songs_updated before update on songs
  for each row execute function set_updated_at();

create table song_artists (
  song_id uuid not null references songs(id) on delete cascade,
  artist_id uuid not null references artists(id) on delete cascade,
  role text not null default 'primary' check (role in ('primary', 'featured')),
  position integer not null default 0,
  primary key (song_id, artist_id)
);
create index song_artists_artist_idx on song_artists (artist_id);

-- --------------------------------------------------- playlists and radio

-- owner_id is null for editorial, chart and mood playlists.
create table playlists (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade,
  title text not null,
  description text,
  cover_url text,
  kind text not null default 'user' check (kind in ('user', 'editorial', 'chart', 'mood')),
  chart_period text check (chart_period in ('weekly', 'monthly', 'decade')),
  is_public boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint playlists_owner_matches_kind check ((kind = 'user') = (owner_id is not null)),
  constraint playlists_curated_are_public check (kind = 'user' or is_public)
);
create index playlists_owner_idx on playlists (owner_id);
create index playlists_kind_idx on playlists (kind);
create index playlists_title_trgm on playlists using gin (title gin_trgm_ops);
create trigger playlists_updated before update on playlists
  for each row execute function set_updated_at();

-- Ownership comes from the parent playlist. unique(playlist_id, song_id)
-- is what stops "song already in playlist".
create table playlist_items (
  id uuid primary key default gen_random_uuid(),
  playlist_id uuid not null references playlists(id) on delete cascade,
  song_id uuid not null references songs(id) on delete cascade,
  position integer not null,
  added_at timestamptz not null default now(),
  unique (playlist_id, song_id)
);
create index playlist_items_order_idx on playlist_items (playlist_id, position);
create index playlist_items_song_idx on playlist_items (song_id);

create table stations (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  kind text not null check (kind in ('mood', 'artist')),
  seed_artist_id uuid references artists(id) on delete cascade,
  cover_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint stations_seed_matches_kind check ((kind = 'artist') = (seed_artist_id is not null))
);
create index stations_seed_idx on stations (seed_artist_id);
create trigger stations_updated before update on stations
  for each row execute function set_updated_at();

-- The pool of songs a station draws from.
create table station_songs (
  station_id uuid not null references stations(id) on delete cascade,
  song_id uuid not null references songs(id) on delete cascade,
  primary key (station_id, song_id)
);
create index station_songs_song_idx on station_songs (song_id);

-- ----------------------------------------------------------- home feed

-- Each section holds one kind of item, so item_id points at one known table.
-- No foreign key is possible on a polymorphic id; the curation code keeps it clean.
create table home_sections (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  kind text not null check (kind in ('playlists', 'albums', 'artists', 'stations', 'songs')),
  position integer not null,
  language text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create index home_sections_order_idx on home_sections (is_active, position);

create table home_section_items (
  section_id uuid not null references home_sections(id) on delete cascade,
  item_id uuid not null,
  position integer not null,
  primary key (section_id, item_id)
);
create index home_section_items_order_idx on home_section_items (section_id, position);

-- ---------------------------------------------------------- user library

create table likes (
  user_id uuid not null references auth.users(id) on delete cascade,
  song_id uuid not null references songs(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, song_id)
);
create index likes_recent_idx on likes (user_id, created_at desc);
create index likes_song_idx on likes (song_id);

create table artist_follows (
  user_id uuid not null references auth.users(id) on delete cascade,
  artist_id uuid not null references artists(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, artist_id)
);
create index artist_follows_artist_idx on artist_follows (artist_id);

create table album_saves (
  user_id uuid not null references auth.users(id) on delete cascade,
  album_id uuid not null references albums(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, album_id)
);
create index album_saves_album_idx on album_saves (album_id);

-- id is generated by the app so a retried request cannot count a play twice.
-- The app only writes a row after the listener has heard 30 seconds or the whole song.
create table play_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  song_id uuid not null references songs(id) on delete cascade,
  played_at timestamptz not null default now(),
  listened_s integer not null check (listened_s > 0)
);
create index play_history_user_idx on play_history (user_id, played_at desc);
create index play_history_song_idx on play_history (song_id, played_at);

-- Powers Top Charts and the "Play Weekly Top Songs" prompt.
-- Counts only, no user ids. Refresh every 15 minutes (see the cron note below).
create materialized view weekly_top_songs as
  select song_id, count(*)::integer as plays
  from play_history
  where played_at > now() - interval '7 days'
  group by song_id;
create unique index weekly_top_songs_pk on weekly_top_songs (song_id);

-- Enable the pg_cron extension in the Supabase dashboard, then run:
-- select cron.schedule('refresh-weekly-top', '*/15 * * * *',
--   'refresh materialized view concurrently weekly_top_songs');

-- -------------------------------------------------------- functions (RPC)

-- Search across songs, albums, artists and visible playlists, built for
-- search-as-you-type: a prefix match scores highest, a match anywhere in the
-- title next, and a trigram match catches typos. Needs 2+ characters.
-- Runs as the caller, so playlist visibility follows RLS.
create function search_catalog(q text, max_results integer default 20)
returns table (kind text, id uuid, title text, image_url text, score real)
language sql stable as $$
  with p as (
    select btrim(q) as raw,
           length(btrim(q)) >= 2 as ok,
           '%' || replace(replace(replace(btrim(q), '\', '\\'), '%', '\%'), '_', '\_') || '%' as contains_pat,
           replace(replace(replace(btrim(q), '\', '\\'), '%', '\%'), '_', '\_') || '%' as prefix_pat
  )
  select * from (
    select 'song'::text as kind, s.id, s.title, al.cover_url as image_url,
           greatest(
             similarity(s.title, p.raw),
             case when s.title ilike p.prefix_pat then 0.9::real
                  when s.title ilike p.contains_pat then 0.6::real
                  else 0::real end
           )::real as score
    from p, songs s
    left join albums al on al.id = s.album_id
    where p.ok and (s.title ilike p.contains_pat or s.title % p.raw)
    union all
    select 'album'::text, a.id, a.title, a.cover_url,
           greatest(similarity(a.title, p.raw),
                    case when a.title ilike p.prefix_pat then 0.9::real
                         when a.title ilike p.contains_pat then 0.6::real
                         else 0::real end)::real
    from p, albums a
    where p.ok and (a.title ilike p.contains_pat or a.title % p.raw)
    union all
    select 'artist'::text, ar.id, ar.name, ar.image_url,
           greatest(similarity(ar.name, p.raw),
                    case when ar.name ilike p.prefix_pat then 0.9::real
                         when ar.name ilike p.contains_pat then 0.6::real
                         else 0::real end)::real
    from p, artists ar
    where p.ok and (ar.name ilike p.contains_pat or ar.name % p.raw)
    union all
    select 'playlist'::text, pl.id, pl.title, pl.cover_url,
           greatest(similarity(pl.title, p.raw),
                    case when pl.title ilike p.prefix_pat then 0.9::real
                         when pl.title ilike p.contains_pat then 0.6::real
                         else 0::real end)::real
    from p, playlists pl
    where p.ok and (pl.title ilike p.contains_pat or pl.title % p.raw)
      and (pl.is_public or pl.owner_id = auth.uid())
  ) r
  order by score desc
  limit max_results
$$;

-- Next batch of songs for a radio station, skipping what already played.
create function next_station_songs(
  p_station_id uuid, p_exclude uuid[] default '{}', p_limit integer default 10
) returns setof songs
language sql stable as $$
  select s.*
  from station_songs ss
  join songs s on s.id = ss.song_id
  where ss.station_id = p_station_id and s.id <> all (p_exclude)
  order by random()
  limit p_limit
$$;

-- Set a playlist's order in one statement (last write wins).
-- Runs as the caller, so RLS only lets the owner do this.
create function reorder_playlist_items(p_playlist_id uuid, p_song_ids uuid[])
returns void language sql as $$
  update playlist_items pi
  set position = o.ord::integer
  from unnest(p_song_ids) with ordinality as o(song_id, ord)
  where pi.playlist_id = p_playlist_id and pi.song_id = o.song_id
$$;

-- "Save" on the queue screen: turn the queue into a new playlist.
create function save_queue_as_playlist(p_title text, p_song_ids uuid[])
returns uuid language plpgsql as $$
declare
  v_id uuid;
begin
  insert into playlists (owner_id, title, kind)
  values (auth.uid(), p_title, 'user')
  returning id into v_id;

  insert into playlist_items (playlist_id, song_id, position)
  select v_id, q.song_id, min(q.ord)::integer
  from unnest(p_song_ids) with ordinality as q(song_id, ord)
  group by q.song_id;

  return v_id;
end $$;

-- ----------------------------------------------------------------- staff

-- Who may use the admin panel. Only an admin can change this table.
-- Bootstrap the first admin once, with the service role, in the SQL editor.
create table staff_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin', 'editor', 'viewer')),
  created_at timestamptz not null default now()
);

-- True when the caller has at least the given role.
create function is_staff(min_role text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from staff_roles
    where user_id = auth.uid()
      and case role when 'admin' then 3 when 'editor' then 2 else 1 end
        >= case min_role when 'admin' then 3 when 'editor' then 2 else 1 end
  )
$$;

-- ------------------------------------------------------ row level security

alter table profiles          enable row level security;
alter table artists           enable row level security;
alter table albums            enable row level security;
alter table songs             enable row level security;
alter table song_artists      enable row level security;
alter table playlists         enable row level security;
alter table playlist_items    enable row level security;
alter table stations          enable row level security;
alter table station_songs     enable row level security;
alter table home_sections     enable row level security;
alter table home_section_items enable row level security;
alter table likes             enable row level security;
alter table artist_follows    enable row level security;
alter table album_saves       enable row level security;
alter table play_history      enable row level security;

-- Catalogue: anyone can read. No client write policies, so only the
-- service role (the sync job) can write.
create policy artists_read            on artists            for select using (true);
create policy albums_read             on albums             for select using (true);
create policy songs_read              on songs              for select using (published or is_staff('viewer'));
create policy song_artists_read       on song_artists       for select using (true);
create policy stations_read           on stations           for select using (true);
create policy station_songs_read      on station_songs      for select using (true);
create policy home_sections_read      on home_sections      for select using (is_active or is_staff('viewer'));
create policy home_section_items_read on home_section_items for select using (true);

-- Staff write the catalogue and curated playlists. Editors and admins can write;
-- viewers can read everything above, including drafts and hidden rows.
create policy artists_staff_write on artists for all
  using (is_staff('editor')) with check (is_staff('editor'));
create policy albums_staff_write on albums for all
  using (is_staff('editor')) with check (is_staff('editor'));
create policy songs_staff_write on songs for all
  using (is_staff('editor')) with check (is_staff('editor'));
create policy song_artists_staff_write on song_artists for all
  using (is_staff('editor')) with check (is_staff('editor'));
create policy stations_staff_write on stations for all
  using (is_staff('editor')) with check (is_staff('editor'));
create policy station_songs_staff_write on station_songs for all
  using (is_staff('editor')) with check (is_staff('editor'));
create policy home_sections_staff_write on home_sections for all
  using (is_staff('editor')) with check (is_staff('editor'));
create policy home_section_items_staff_write on home_section_items for all
  using (is_staff('editor')) with check (is_staff('editor'));

create policy playlists_staff on playlists for all
  using (is_staff('editor') and kind <> 'user')
  with check (is_staff('editor') and kind <> 'user');
create policy playlist_items_staff on playlist_items for all
  using (is_staff('editor') and exists (
    select 1 from playlists p where p.id = playlist_items.playlist_id and p.kind <> 'user'))
  with check (is_staff('editor') and exists (
    select 1 from playlists p where p.id = playlist_items.playlist_id and p.kind <> 'user'));

-- Viewers see every profile and every play, for the admin dashboard.
-- Staff reads are not a product feature; list them in the privacy policy.
create policy profiles_staff_read on profiles for select using (is_staff('viewer'));
create policy play_history_staff_read on play_history for select using (is_staff('viewer'));

-- Staff roles: each person sees their own row; admins manage the table.
alter table staff_roles enable row level security;
create policy staff_roles_read on staff_roles for select
  using (user_id = auth.uid() or is_staff('admin'));
create policy staff_roles_admin_write on staff_roles for all
  using (is_staff('admin')) with check (is_staff('admin'));
grant select on staff_roles to authenticated;

-- Profiles: own row only. The client may change display_name and languages,
-- never plan (column grants below).
create policy profiles_select_own on profiles for select using (id = auth.uid());
create policy profiles_update_own on profiles for update
  using (id = auth.uid()) with check (id = auth.uid());
revoke update on profiles from authenticated;
grant update (display_name, languages) on profiles to authenticated;

-- Playlists: curated and public ones are readable by everyone, user playlists
-- are writable by their owner only, and clients cannot create curated kinds.
create policy playlists_select on playlists for select
  using (is_public or owner_id = auth.uid());
create policy playlists_insert on playlists for insert
  with check (owner_id = auth.uid() and kind = 'user');
create policy playlists_update on playlists for update
  using (owner_id = auth.uid())
  with check (owner_id = auth.uid() and kind = 'user');
create policy playlists_delete on playlists for delete
  using (owner_id = auth.uid());

create policy playlist_items_select on playlist_items for select
  using (exists (
    select 1 from playlists p
    where p.id = playlist_items.playlist_id
      and (p.is_public or p.owner_id = auth.uid())
  ));
create policy playlist_items_write on playlist_items for all
  using (exists (
    select 1 from playlists p
    where p.id = playlist_items.playlist_id and p.owner_id = auth.uid()
  ))
  with check (exists (
    select 1 from playlists p
    where p.id = playlist_items.playlist_id and p.owner_id = auth.uid()
  ));

-- Library tables: the owner reads and writes their own rows.
create policy likes_own on likes for all
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy artist_follows_own on artist_follows for all
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy album_saves_own on album_saves for all
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- History: read, add and clear your own. No update.
create policy play_history_select on play_history for select using (user_id = auth.uid());
create policy play_history_insert on play_history for insert with check (user_id = auth.uid());
create policy play_history_delete on play_history for delete using (user_id = auth.uid());

-- The weekly counts hold no user data, so they are readable by the app.
grant select on weekly_top_songs to anon, authenticated;
