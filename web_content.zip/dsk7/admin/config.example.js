// Copy to config.js and fill in to use the live Supabase database.
// The anon key is public by design: row level security protects the data.
// Never put the service role key here.
window.DSK7_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabaseAnonKey: "YOUR-ANON-KEY",
};
