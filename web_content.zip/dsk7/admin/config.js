// Demo mode: no Supabase. Copy config.example.js to enable live mode.
window.DSK7_CONFIG = { supabaseUrl: "", supabaseAnonKey: "" };
