// A PlayerService with no sound. Used by the unit tests and by the dev screens.
// The test drives it by calling emit* methods, as the real engine would.

import type { PlayerService, PlayerServiceEvents, PlayerTrack } from "../core/types.ts";

export class FakePlayer implements PlayerService {
  events: PlayerServiceEvents | null = null;
  loaded: PlayerTrack | null = null;
  position = 0;
  playing = false;
  calls: string[] = [];
  failLoad: string | null = null;

  async setup(events: PlayerServiceEvents) {
    this.events = events;
  }
  async load(track: PlayerTrack, autoplay: boolean) {
    this.calls.push(`load:${track.id}`);
    if (this.failLoad) {
      const message = this.failLoad;
      this.failLoad = null;
      throw new Error(message);
    }
    this.loaded = track;
    this.position = 0;
    this.playing = autoplay;
    this.events?.onState(autoplay ? "playing" : "paused");
  }
  async play() {
    this.calls.push("play");
    this.playing = true;
    this.events?.onState("playing");
  }
  async pause() {
    this.calls.push("pause");
    this.playing = false;
    this.events?.onState("paused");
  }
  async seekTo(positionS: number) {
    this.calls.push(`seek:${positionS}`);
    this.position = positionS;
  }
  async stop() {
    this.calls.push("stop");
    this.loaded = null;
    this.playing = false;
    this.events?.onState("idle");
  }

  // ---- test helpers
  tick(positionS: number) {
    this.position = positionS;
    const dur = this.loaded?.durationS ?? 0;
    this.events?.onProgress(positionS, dur);
  }
  end() {
    this.events?.onEnded();
  }
  fail(message: string) {
    this.playing = false;
    this.events?.onError(message);
  }
  remote(action: "next" | "previous" | "play" | "pause") {
    this.events?.onRemote(action);
  }
}
