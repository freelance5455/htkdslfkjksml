// The real engine on Android: react-native-track-player.
//
// NOT YET VERIFIED. The calls below follow the v4 API as we know it. Before the
// first device build, check each one against the installed version's typings
// (node_modules/react-native-track-player). Changes are expected to be small.
//
// Background audio also needs a playback service registered in index.js:
//   TrackPlayer.registerPlaybackService(() => require("./src/audio/playbackService"));

import TrackPlayer, { Event, State, Capability, AppKilledPlaybackBehavior } from "react-native-track-player";
import type { PlayerService, PlayerServiceEvents, PlayerTrack } from "../core/types.ts";

let ready: Promise<void> | null = null;

function ensureSetup(): Promise<void> {
  if (!ready) {
    ready = (async () => {
      await TrackPlayer.setupPlayer({ autoHandleInterruptions: true });
      await TrackPlayer.updateOptions({
        capabilities: [
          Capability.Play,
          Capability.Pause,
          Capability.SkipToNext,
          Capability.SkipToPrevious,
          Capability.SeekTo,
        ],
        compactCapabilities: [Capability.Play, Capability.Pause, Capability.SkipToNext],
        android: { appKilledPlaybackBehavior: AppKilledPlaybackBehavior.StopPlaybackAndRemoveNotification },
      });
    })();
  }
  return ready;
}

export class TrackPlayerService implements PlayerService {
  async setup(events: PlayerServiceEvents): Promise<void> {
    await ensureSetup();
    TrackPlayer.addEventListener(Event.PlaybackProgressUpdated, (e) => {
      events.onProgress(e.position, e.duration);
    });
    TrackPlayer.addEventListener(Event.PlaybackState, (e) => {
      if (e.state === State.Playing) events.onState("playing");
      else if (e.state === State.Paused || e.state === State.Ready) events.onState("paused");
      else if (e.state === State.Buffering || e.state === State.Loading) events.onState("buffering");
      else if (e.state === State.None) events.onState("idle");
    });
    TrackPlayer.addEventListener(Event.PlaybackError, (e) => {
      events.onError(e.message ?? "This song couldn't be played.");
    });
    TrackPlayer.addEventListener(Event.PlaybackQueueEnded, () => events.onEnded());
    TrackPlayer.addEventListener(Event.RemoteNext, () => events.onRemote("next"));
    TrackPlayer.addEventListener(Event.RemotePrevious, () => events.onRemote("previous"));
    TrackPlayer.addEventListener(Event.RemotePlay, () => events.onRemote("play"));
    TrackPlayer.addEventListener(Event.RemotePause, () => events.onRemote("pause"));
  }

  async load(track: PlayerTrack, autoplay: boolean): Promise<void> {
    await ensureSetup();
    await TrackPlayer.reset();
    await TrackPlayer.add({
      id: track.id,
      url: track.url,
      title: track.title,
      artist: track.artist,
      artwork: track.artworkUrl,
      duration: track.durationS,
    });
    if (autoplay) await TrackPlayer.play();
  }

  async play() {
    await TrackPlayer.play();
  }
  async pause() {
    await TrackPlayer.pause();
  }
  async seekTo(positionS: number) {
    await TrackPlayer.seekTo(positionS);
  }
  async stop() {
    await TrackPlayer.reset();
  }
}
