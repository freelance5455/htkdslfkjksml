// The real data layer: Supabase. Implements the same DataLayer as seed.ts.
//
// NOT YET RUN against a live project. Written from the supabase-js v2 API.
// Check on the first run: the embedded select shapes, the RPC name, and the
// OTP email template (it must show {{ .Token }}).

import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { DataLayer } from "./dataLayer.ts";
import { DataError } from "./dataLayer.ts";
import type { HomeSection, Playlist, PlaylistWithSongs, PlayerTrack, Profile, Song } from "../core/types.ts";

// Rows as PostgREST returns them, with the embedded relations we ask for.
interface ArtistLink { role: string; position: number; artists: { id: string; name: string } | null }
interface SongRow {
  id: string; title: string; album_id: string | null; duration_s: number; audio_url: string | null;
  storage_path: string | null; language: string | null; explicit: boolean; license: string;
  license_url: string | null; attribution: string; song_artists?: ArtistLink[];
  albums?: { cover_url: string | null } | null;
}
interface PlaylistRow {
  id: string; owner_id: string | null; title: string; description: string | null; cover_url: string | null;
  kind: Playlist["kind"]; is_public: boolean; playlist_items?: { count: number }[];
}

const SONG_SELECT = "*, song_artists(role, position, artists(id, name)), albums(cover_url)";

function toSong(r: SongRow): Song {
  const artists = (r.song_artists ?? [])
    .filter((l) => l.artists)
    .sort((a, b) => a.position - b.position)
    .map((l) => ({ id: l.artists!.id, name: l.artists!.name }));
  return {
    id: r.id,
    title: r.title,
    album_id: r.album_id,
    duration_s: r.duration_s,
    audio_url: r.audio_url,
    storage_path: r.storage_path,
    language: r.language,
    explicit: r.explicit,
    license: r.license,
    license_url: r.license_url,
    attribution: r.attribution,
    artists,
    cover_url: r.albums?.cover_url ?? null,
  };
}

function toPlaylist(r: PlaylistRow): Playlist {
  return {
    id: r.id,
    owner_id: r.owner_id,
    title: r.title,
    description: r.description,
    cover_url: r.cover_url,
    kind: r.kind,
    is_public: r.is_public,
    song_count: r.playlist_items?.[0]?.count ?? 0,
  };
}

function mapError(e: { code?: string; message?: string } | null | undefined): DataError {
  if (!e) return new DataError("unknown", "Something went wrong. Try again.");
  if (e.code === "42501") return new DataError("unauthorised", "Log in to do that.");
  if (e.code === "23505") return new DataError("duplicate", "That's already there.");
  if (e.message && /fetch|network|failed to/i.test(e.message)) {
    return new DataError("network", "Can't reach the server. Check your connection and try again.");
  }
  return new DataError("unknown", e.message ?? "Something went wrong. Try again.");
}

export function createSupabaseDataLayer(url: string, anonKey: string): DataLayer & { client: SupabaseClient } {
  // React Native has no localStorage, so the session is kept in AsyncStorage.
  const client = createClient(url, anonKey, {
    auth: { storage: AsyncStorage, persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
  });

  async function userId(): Promise<string> {
    const { data } = await client.auth.getSession();
    const id = data.session?.user.id;
    if (!id) throw new DataError("unauthorised", "Log in to do that.");
    return id;
  }

  async function songsByIds(ids: string[]): Promise<Song[]> {
    if (ids.length === 0) return [];
    const { data, error } = await client.from("songs").select(SONG_SELECT).in("id", ids);
    if (error) throw mapError(error);
    const byId = new Map((data as SongRow[]).map((r) => [r.id, toSong(r)]));
    return ids.map((id) => byId.get(id)).filter((s): s is Song => !!s);
  }

  return {
    client,

    async getSession(): Promise<Profile | null> {
      const { data } = await client.auth.getSession();
      if (!data.session) return null;
      const { data: row, error } = await client
        .from("profiles")
        .select("id, display_name, languages, plan")
        .eq("id", data.session.user.id)
        .maybeSingle();
      if (error) throw mapError(error);
      return (row as Profile | null) ?? null;
    },

    async signInWithEmail(email) {
      const { error } = await client.auth.signInWithOtp({ email, options: { shouldCreateUser: true } });
      if (error) throw mapError(error);
      return { sentTo: email };
    },

    async verifyCode(email, code) {
      const { error } = await client.auth.verifyOtp({ email, token: code, type: "email" });
      if (error) throw new DataError("unauthorised", "That code didn't work. Check it and try again.");
      const profile = await this.getSession();
      if (!profile) throw new DataError("unknown", "Signed in, but no profile was found. Try again.");
      return profile;
    },

    async signOut() {
      const { error } = await client.auth.signOut();
      if (error) throw mapError(error);
    },

    async getHome(languages): Promise<HomeSection[]> {
      const { data, error } = await client
        .from("home_sections")
        .select("id, title, kind, position, language, home_section_items(item_id, position)")
        .eq("is_active", true)
        .order("position");
      if (error) throw mapError(error);

      const sections = (data ?? []).filter((s: { language: string | null }) =>
        !s.language || languages.length === 0 || languages.includes(s.language),
      );
      const out: HomeSection[] = [];
      for (const s of sections as {
        id: string; title: string; kind: string; home_section_items: { item_id: string; position: number }[];
      }[]) {
        const ids = s.home_section_items.sort((a, b) => a.position - b.position).map((i) => i.item_id);
        if (s.kind === "songs") {
          out.push({ id: s.id, title: s.title, kind: "songs", items: await songsByIds(ids) });
        } else {
          if (ids.length === 0) continue;
          const { data: pls, error: e2 } = await client
            .from("playlists")
            .select("id, owner_id, title, description, cover_url, kind, is_public, playlist_items(count)")
            .in("id", ids);
          if (e2) throw mapError(e2);
          const byId = new Map((pls as PlaylistRow[]).map((p) => [p.id, toPlaylist(p)]));
          out.push({ id: s.id, title: s.title, kind: "playlists", items: ids.map((i) => byId.get(i)).filter((p): p is Playlist => !!p) });
        }
      }
      return out;
    },

    async getPlaylist(id): Promise<PlaylistWithSongs | null> {
      const { data, error } = await client
        .from("playlists")
        .select(`id, owner_id, title, description, cover_url, kind, is_public, playlist_items(position, song_id)`)
        .eq("id", id)
        .maybeSingle();
      if (error) throw mapError(error);
      if (!data) return null;
      const row = data as PlaylistRow & { playlist_items: { position: number; song_id: string }[] };
      const ids = [...row.playlist_items].sort((a, b) => a.position - b.position).map((i) => i.song_id);
      const songs = await songsByIds(ids);
      return { ...toPlaylist({ ...row, playlist_items: [{ count: ids.length }] }), songs };
    },

    async getSong(id): Promise<Song | null> {
      const { data, error } = await client.from("songs").select(SONG_SELECT).eq("id", id).maybeSingle();
      if (error) throw mapError(error);
      return data ? toSong(data as SongRow) : null;
    },

    async search(query): Promise<Song[]> {
      const q = query.trim();
      if (q.length < 2) return [];
      const { data, error } = await client.rpc("search_catalog", { q, max_results: 20 });
      if (error) throw mapError(error);
      const songIds = (data as { kind: string; id: string }[]).filter((r) => r.kind === "song").map((r) => r.id);
      return songsByIds(songIds);
    },

    async listLikes(): Promise<Song[]> {
      const { data, error } = await client
        .from("likes")
        .select(`created_at, songs(${SONG_SELECT})`)
        .order("created_at", { ascending: false });
      if (error) throw mapError(error);
      return (data as unknown as { songs: SongRow | null }[])
        .map((r) => r.songs)
        .filter((s): s is SongRow => !!s)
        .map(toSong);
    },

    async isLiked(songId): Promise<boolean> {
      const { data, error } = await client.from("likes").select("song_id").eq("song_id", songId).maybeSingle();
      if (error) throw mapError(error);
      return !!data;
    },

    async setLiked(songId, liked): Promise<void> {
      if (liked) {
        const uid = await userId();
        const { error } = await client
          .from("likes")
          .upsert({ user_id: uid, song_id: songId }, { onConflict: "user_id,song_id", ignoreDuplicates: true });
        if (error) throw mapError(error);
      } else {
        const { error } = await client.from("likes").delete().eq("song_id", songId);
        if (error) throw mapError(error);
      }
    },

    async listMyPlaylists(): Promise<Playlist[]> {
      const { data, error } = await client
        .from("playlists")
        .select("id, owner_id, title, description, cover_url, kind, is_public, playlist_items(count)")
        .eq("kind", "user")
        .order("created_at", { ascending: false });
      if (error) throw mapError(error);
      return (data as PlaylistRow[]).map(toPlaylist);
    },

    async addToPlaylist(playlistId, songId): Promise<"added" | "duplicate"> {
      const { data: last } = await client
        .from("playlist_items")
        .select("position")
        .eq("playlist_id", playlistId)
        .order("position", { ascending: false })
        .limit(1)
        .maybeSingle();
      const position = ((last as { position: number } | null)?.position ?? -1) + 1;
      const { error } = await client.from("playlist_items").insert({ playlist_id: playlistId, song_id: songId, position });
      if (error?.code === "23505") return "duplicate";
      if (error) throw mapError(error);
      return "added";
    },

    async resolveTrack(song): Promise<PlayerTrack> {
      let url: string | null = song.audio_url;
      if (song.storage_path) {
        // Private bucket: a signed URL that lasts an hour. Ask again on retry.
        const { data, error } = await client.storage.from("audio").createSignedUrl(song.storage_path, 3600);
        if (error || !data) throw new DataError("network", "This song couldn't be loaded. Try again.");
        url = data.signedUrl;
      }
      if (!url) throw new DataError("not_found", "This song isn't available right now.");
      return {
        id: song.id,
        url,
        title: song.title,
        artist: song.artists.map((a) => a.name).join(", "),
        durationS: song.duration_s,
      };
    },

    async recordPlay(id, songId, listenedS): Promise<void> {
      const uid = await userId();
      // The client makes the id, so a retry cannot count the same play twice.
      const { error } = await client
        .from("play_history")
        .upsert({ id, user_id: uid, song_id: songId, listened_s: listenedS }, { onConflict: "id", ignoreDuplicates: true });
      if (error) throw mapError(error);
    },
  };
}
