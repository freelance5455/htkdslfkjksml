// Development data. Our own invented artists, albums and songs, and our own
// generated audio (assets/seed). Nothing here is copied from any app or catalogue.
// Replaced by the Supabase data layer in replica-backend.

import type { DataLayer } from "./dataLayer.ts";
import { DataError } from "./dataLayer.ts";
import type { Playlist, PlaylistWithSongs, Profile, Song, HomeSection, PlayerTrack } from "../core/types.ts";

// Metro needs static require() calls for bundled audio, so the map is written out.
const AUDIO: Record<string, number> = {
  "seed:1": require("../../assets/seed/seed-1.mp3"),
  "seed:2": require("../../assets/seed/seed-2.mp3"),
  "seed:3": require("../../assets/seed/seed-3.mp3"),
};

const LICENCE = "DSK 7 generated tone (own work, no licence needed)";

const artists = [
  { id: "ar1", name: "Orbit Kiln" },
  { id: "ar2", name: "Static Bloom" },
  { id: "ar3", name: "Lantern Coast" },
];

export const seedSongs: Song[] = [
  {
    id: "s1", title: "Low Tide Sketch", album_id: "al1", duration_s: 35, audio_url: "seed:1",
    storage_path: null, language: "en", explicit: false, license: LICENCE, license_url: null,
    attribution: "Orbit Kiln", artists: [artists[0]!], cover_url: null,
  },
  {
    id: "s2", title: "Paper Lantern", album_id: "al1", duration_s: 35, audio_url: "seed:2",
    storage_path: null, language: "en", explicit: false, license: LICENCE, license_url: null,
    attribution: "Orbit Kiln", artists: [artists[0]!], cover_url: null,
  },
  {
    id: "s3", title: "Night Transit", album_id: "al2", duration_s: 35, audio_url: "seed:3",
    storage_path: null, language: "en", explicit: false, license: LICENCE, license_url: null,
    attribution: "Static Bloom", artists: [artists[1]!], cover_url: null,
  },
  {
    id: "s4", title: "Harbour Light", album_id: "al3", duration_s: 35, audio_url: "seed:1",
    storage_path: null, language: "en", explicit: false, license: LICENCE, license_url: null,
    attribution: "Lantern Coast", artists: [artists[2]!], cover_url: null,
  },
  {
    id: "s5", title: "A Very Long Title That Keeps Going Past The Edge Of The Screen", album_id: "al2",
    duration_s: 35, audio_url: "seed:2", storage_path: null, language: "en", explicit: false,
    license: LICENCE, license_url: null, attribution: "Static Bloom", artists: [artists[1]!], cover_url: null,
  },
];

const songById = new Map(seedSongs.map((s) => [s.id, s]));

const playlists: (Playlist & { songIds: string[] })[] = [
  {
    id: "pl1", owner_id: null, title: "Quiet Evenings", description: "Slow, low-key tracks", cover_url: null,
    kind: "mood", is_public: true, song_count: 3, songIds: ["s1", "s2", "s4"],
  },
  {
    id: "pl2", owner_id: null, title: "Top This Week", description: null, cover_url: null,
    kind: "chart", is_public: true, song_count: 3, songIds: ["s3", "s4", "s5"],
  },
  {
    id: "pl3", owner_id: "me", title: "My Road Trip", description: null, cover_url: null,
    kind: "user", is_public: false, song_count: 2, songIds: ["s2", "s3"],
  },
];

const playlistById = new Map(playlists.map((p) => [p.id, p]));

function toPlaylist(p: Playlist & { songIds: string[] }): Playlist {
  const { id, owner_id, title, description, cover_url, kind, is_public, song_count } = p;
  return { id, owner_id, title, description, cover_url, kind, is_public, song_count };
}

// Simulated network delay, so skeletons and loading states can be seen in dev.
const DELAY_MS = 350;
const wait = <T,>(value: T, ms = DELAY_MS): Promise<T> =>
  new Promise((resolve) => setTimeout(() => resolve(value), ms));

export interface SeedOptions {
  /** Force the next call to fail, to test error states. */
  failNext?: boolean;
  /** Make the playlist that already holds the song say so. */
  delayMs?: number;
}

export function createSeedDataLayer(options: SeedOptions = {}): DataLayer & { reset(): void } {
  let profile: Profile | null = null;
  let likes = new Set<string>(["s1", "s3"]);
  let pending: string | null = null;
  let failNext = !!options.failNext;
  const ms = options.delayMs ?? DELAY_MS;

  const maybeFail = () => {
    if (failNext) {
      failNext = false;
      throw new DataError("network", "Can't reach the server. Check your connection and try again.");
    }
  };
  const later = <T,>(value: T) => {
    maybeFail();
    return wait(value, ms);
  };

  const playlistWithSongs = (p: Playlist & { songIds: string[] }): PlaylistWithSongs => ({
    id: p.id, owner_id: p.owner_id, title: p.title, description: p.description, cover_url: p.cover_url,
    kind: p.kind, is_public: p.is_public, song_count: p.songIds.length,
    songs: p.songIds.map((id) => songById.get(id)).filter((s): s is Song => !!s),
  });

  return {
    async getSession() {
      return later(profile);
    },
    async signInWithEmail(email) {
      maybeFail();
      if (!email.includes("@")) throw new DataError("unknown", "That email doesn't look right.");
      pending = email;
      return wait({ sentTo: email }, ms);
    },
    async verifyCode(email, code) {
      maybeFail();
      if (pending !== email || code !== "123456") {
        throw new DataError("unauthorised", "That code didn't work. Check it and try again.");
      }
      profile = { id: "me", display_name: email.split("@")[0] ?? "listener", languages: ["en"], plan: "free" };
      return wait(profile, ms);
    },
    async signOut() {
      profile = null;
      return wait(undefined, ms);
    },

    async getHome(_languages) {
      // The seed has English only. The Supabase layer filters by languages.
      return later<HomeSection[]>([
        { id: "h1", title: "Quiet Evenings", kind: "playlists", items: [playlists[0]!] as Playlist[] },
        { id: "h2", title: "Top this week", kind: "playlists", items: [playlists[1]!] as Playlist[] },
        { id: "h3", title: "Recently added", kind: "songs", items: seedSongs.slice(0, 4) },
      ]);
    },
    async getPlaylist(id) {
      const p = playlistById.get(id);
      if (!p) return later(null);
      if (p.owner_id !== null && p.owner_id !== profile?.id) {
        throw new DataError("not_found", "This playlist isn't available.");
      }
      return later(playlistWithSongs(p));
    },
    async getSong(id) {
      return later(songById.get(id) ?? null);
    },
    async search(query) {
      const q = query.trim().toLowerCase();
      if (q.length < 2) return later([]);
      return later(
        seedSongs.filter(
          (s) => s.title.toLowerCase().includes(q) || s.artists.some((a) => a.name.toLowerCase().includes(q)),
        ),
      );
    },

    async listLikes() {
      return later(seedSongs.filter((s) => likes.has(s.id)));
    },
    async isLiked(songId) {
      return later(likes.has(songId));
    },
    async setLiked(songId, liked) {
      maybeFail();
      if (!profile) throw new DataError("unauthorised", "Log in to keep your likes.");
      if (liked) likes.add(songId);
      else likes.delete(songId);
      return wait(undefined, ms);
    },
    async listMyPlaylists() {
      return later(playlists.filter((p) => p.owner_id === "me").map(toPlaylist));
    },
    async addToPlaylist(playlistId, songId) {
      maybeFail();
      const p = playlistById.get(playlistId);
      if (!p) throw new DataError("not_found", "That playlist was deleted.");
      if (p.songIds.includes(songId)) return wait("duplicate" as const, ms);
      p.songIds.push(songId);
      p.song_count = p.songIds.length;
      return wait("added" as const, ms);
    },

    async resolveTrack(song) {
      maybeFail();
      const key = song.audio_url;
      const url = key && AUDIO[key];
      if (url === undefined) throw new DataError("not_found", "This song isn't available right now.");
      const track: PlayerTrack = {
        id: song.id,
        url,
        title: song.title,
        artist: song.artists.map((a) => a.name).join(", "),
        durationS: song.duration_s,
      };
      return wait(track, 80);
    },
    async recordPlay() {
      // In the seed build plays are kept only in memory. The Supabase layer writes play_history.
      return wait(undefined, 0);
    },

    reset() {
      profile = null;
      likes = new Set(["s1", "s3"]);
      pending = null;
      failNext = false;
    },
  };
}
