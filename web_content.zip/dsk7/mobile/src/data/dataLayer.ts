// The one interface screens talk to. Two implementations:
//   seed.ts      in-memory data and bundled audio, used now and in tests
//   supabase.ts  the real backend, written in replica-backend (not yet)
// Screens never import either one directly. They use the DataProvider below,
// so swapping implementations changes no screen code.

import type { HomeSection, Playlist, PlaylistWithSongs, PlayerTrack, Profile, Song } from "../core/types.ts";

export interface DataLayer {
  // auth
  getSession(): Promise<Profile | null>;
  signInWithEmail(email: string): Promise<{ sentTo: string }>;
  verifyCode(email: string, code: string): Promise<Profile>;
  signOut(): Promise<void>;

  // browsing
  getHome(languages: string[]): Promise<HomeSection[]>;
  getPlaylist(id: string): Promise<PlaylistWithSongs | null>;
  getSong(id: string): Promise<Song | null>;
  search(query: string): Promise<Song[]>;

  // library
  listLikes(): Promise<Song[]>;
  isLiked(songId: string): Promise<boolean>;
  setLiked(songId: string, liked: boolean): Promise<void>;
  listMyPlaylists(): Promise<Playlist[]>;
  addToPlaylist(playlistId: string, songId: string): Promise<"added" | "duplicate">;

  // playback
  resolveTrack(song: Song): Promise<PlayerTrack>;
  recordPlay(id: string, songId: string, listenedS: number): Promise<void>;
}

// Errors the screens can show. Keep the messages short and in our own words.
export class DataError extends Error {
  constructor(
    public readonly code: "network" | "not_found" | "unauthorised" | "duplicate" | "unknown",
    message: string,
  ) {
    super(message);
  }
}
