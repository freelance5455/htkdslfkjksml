import { createContext, useContext, useMemo, type ReactNode } from "react";
import type { DataLayer } from "./dataLayer";
import { createSeedDataLayer } from "./seed";
import { createSupabaseDataLayer } from "./supabase";

// With EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY set, the app uses Supabase.
// Without them (tests, a quick look without an account), it uses the seed data.
const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

const DataCtx = createContext<DataLayer | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const value = useMemo<DataLayer>(
    () => (url && anonKey ? createSupabaseDataLayer(url, anonKey) : createSeedDataLayer()),
    [],
  );
  return <DataCtx.Provider value={value}>{children}</DataCtx.Provider>;
}

export function useData(): DataLayer {
  const value = useContext(DataCtx);
  if (!value) throw new Error("useData must be used inside DataProvider");
  return value;
}
