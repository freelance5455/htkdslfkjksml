import { ActivityIndicator, Pressable, Text } from "react-native";
import type { LucideIcon } from "lucide-react-native";
import { colors, layout } from "../theme/tokens.generated";

type Variant = "primary" | "secondary" | "ghost" | "danger";

interface Props {
  label: string;
  onPress: () => void;
  variant?: Variant;
  icon?: LucideIcon;
  disabled?: boolean;
  loading?: boolean;
  accessibilityHint?: string;
}

const box: Record<Variant, string> = {
  primary: "bg-accent",
  secondary: "bg-surface-raised border border-border",
  ghost: "bg-transparent",
  danger: "bg-danger",
};

const text: Record<Variant, string> = {
  primary: "text-on-accent",
  secondary: "text-text",
  ghost: "text-accent",
  danger: "text-on-accent",
};

export function Button({ label, onPress, variant = "primary", icon: Icon, disabled, loading, accessibilityHint }: Props) {
  const off = disabled || loading;
  const iconColor = variant === "primary" || variant === "danger" ? colors.onAccent : colors.text;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityHint={accessibilityHint}
      accessibilityState={{ disabled: !!off, busy: !!loading }}
      disabled={off}
      onPress={onPress}
      style={({ pressed }) => ({
        minHeight: layout["touch-min"],
        minWidth: layout["touch-min"],
        borderRadius: 999,
        opacity: off ? 0.4 : pressed ? 0.85 : 1,
      })}
      className={`flex-row items-center justify-center px-6 ${box[variant]}`}
    >
      {loading ? <ActivityIndicator color={variant === "ghost" ? colors.accent : colors.onAccent} /> : null}
      {!loading && Icon ? <Icon size={20} color={iconColor} style={{ marginRight: 8 }} /> : null}
      <Text className={`text-base font-sans-semibold ${text[variant]} ${loading ? "ml-2" : ""}`}>{label}</Text>
    </Pressable>
  );
}
