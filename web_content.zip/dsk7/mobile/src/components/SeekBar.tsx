import { useState } from "react";
import { Text, View } from "react-native";
import Slider from "@react-native-community/slider";
import { formatTime, spokenDuration } from "../core/format";
import { colors } from "../theme/tokens.generated";

interface Props {
  positionS: number;
  durationS: number;
  onSeek: (positionS: number) => void;
}

/** Shows the live position, but while the finger is down it shows where the drag is. */
export function SeekBar({ positionS, durationS, onSeek }: Props) {
  const [dragging, setDragging] = useState<number | null>(null);
  const shown = dragging ?? positionS;
  const max = durationS > 0 ? durationS : 1;
  return (
    <View>
      <Slider
        minimumValue={0}
        maximumValue={max}
        value={Math.min(shown, max)}
        minimumTrackTintColor={colors.accent}
        maximumTrackTintColor={colors.track}
        thumbTintColor={colors.accent}
        onSlidingStart={(v) => setDragging(v)}
        onValueChange={(v) => setDragging(v)}
        onSlidingComplete={(v) => {
          setDragging(null);
          onSeek(v);
        }}
        accessibilityLabel="Playback position"
        accessibilityValue={{ text: `${spokenDuration(shown)} of ${spokenDuration(durationS)}` }}
        style={{ height: 48 }}
      />
      <View className="flex-row justify-between px-1">
        <Text className="text-xs text-text-muted">{formatTime(shown)}</Text>
        <Text className="text-xs text-text-muted">{formatTime(durationS)}</Text>
      </View>
    </View>
  );
}
