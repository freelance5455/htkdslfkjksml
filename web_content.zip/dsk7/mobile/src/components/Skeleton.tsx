import { useEffect, useRef } from "react";
import { AccessibilityInfo, Animated, View, type DimensionValue } from "react-native";
import { colors } from "../theme/tokens.generated";

/** A pulsing placeholder. Still when the system asks for reduced motion. Hidden from TalkBack. */
export function Skeleton({ width, height, radius = 8 }: { width: DimensionValue; height: number; radius?: number }) {
  const opacity = useRef(new Animated.Value(0.5)).current;
  useEffect(() => {
    let loop: Animated.CompositeAnimation | null = null;
    let cancelled = false;
    AccessibilityInfo.isReduceMotionEnabled().then((reduce) => {
      if (cancelled || reduce) return;
      loop = Animated.loop(
        Animated.sequence([
          Animated.timing(opacity, { toValue: 1, duration: 600, useNativeDriver: true }),
          Animated.timing(opacity, { toValue: 0.5, duration: 600, useNativeDriver: true }),
        ]),
      );
      loop.start();
    });
    return () => {
      cancelled = true;
      loop?.stop();
    };
  }, [opacity]);
  return (
    <Animated.View
      accessibilityElementsHidden
      importantForAccessibility="no"
      style={{ width, height, borderRadius: radius, backgroundColor: colors.surfaceRaised, opacity }}
    />
  );
}

export function SongRowSkeleton() {
  return (
    <View className="flex-row items-center px-4 py-2" style={{ minHeight: 56 }}>
      <Skeleton width={48} height={48} />
      <View className="ml-3 flex-1" style={{ gap: 6 }}>
        <Skeleton width="70%" height={14} />
        <Skeleton width="45%" height={12} />
      </View>
    </View>
  );
}
