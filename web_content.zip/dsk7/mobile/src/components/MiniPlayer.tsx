import { Pressable, Text, View } from "react-native";
import { router } from "expo-router";
import { AlertTriangle, Pause, Play, SkipForward } from "lucide-react-native";
import { usePlayer } from "../player/PlayerProvider";
import { useCurrentSong } from "../player/useCurrentSong";
import { CoverArt } from "./CoverArt";
import { IconButton } from "./IconButton";
import { colors, layout } from "../theme/tokens.generated";

/** Sits above the bottom navigation. Hidden until something is queued. */
export function MiniPlayer() {
  const { status, positionS, durationS, currentSongId, controller } = usePlayer();
  const song = useCurrentSong(currentSongId);
  if (!currentSongId || !song) return null;

  const isPlaying = status === "playing";
  const progress = durationS > 0 ? Math.min(positionS / durationS, 1) : 0;
  const playLabel = status === "error" ? "Try again" : isPlaying ? "Pause" : "Play";

  return (
    <View className="bg-surface-raised border-t border-border" style={{ height: layout["mini-player-height"] }}>
      <View style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, backgroundColor: colors.track }}>
        <View style={{ width: `${progress * 100}%`, height: 2, backgroundColor: colors.accent }} />
      </View>
      <View className="flex-1 flex-row items-center pl-3 pr-1">
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Open player. ${song.title}, by ${song.artists.map((a) => a.name).join(", ")}`}
          onPress={() => router.push("/now-playing")}
          className="flex-1 flex-row items-center"
        >
          <CoverArt id={song.id} title={song.title} uri={song.cover_url} size={48} />
          <View className="ml-3 flex-1">
            <Text numberOfLines={1} className="text-sm font-sans-semibold text-text">
              {song.title}
            </Text>
            <Text numberOfLines={1} className="text-xs text-text-muted">
              {status === "error" ? "Can't play this song" : song.artists.map((a) => a.name).join(", ")}
            </Text>
          </View>
        </Pressable>
        {status === "error" ? (
          <IconButton icon={AlertTriangle} label="Try again" tone="accent" onPress={() => void controller.retry()} />
        ) : (
          <IconButton
            icon={isPlaying ? Pause : Play}
            label={playLabel}
            filled
            onPress={() => void controller.togglePlay()}
            disabled={status === "loading"}
          />
        )}
        <IconButton icon={SkipForward} label="Next song" onPress={() => void controller.next()} />
      </View>
    </View>
  );
}
