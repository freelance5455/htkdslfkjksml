import { Pressable, Text, View } from "react-native";
import { CoverArt } from "./CoverArt";
import { colors } from "../theme/tokens.generated";

interface Props {
  id: string;
  title: string;
  subtitle?: string;
  uri?: string | null;
  shape?: "square" | "circle";
  width?: number;
  onPress: () => void;
}

export function ContentCard({ id, title, subtitle, uri, shape = "square", width = 140, onPress }: Props) {
  const label = subtitle ? `${title}, ${subtitle}` : title;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => ({ width, opacity: pressed ? 0.7 : 1 })}
    >
      <CoverArt id={id} title={title} uri={uri} size={width} shape={shape} />
      <View className="mt-2" style={{ width }}>
        <Text numberOfLines={1} className="text-sm font-sans-semibold text-text">
          {title}
        </Text>
        {subtitle ? (
          <Text numberOfLines={1} className="text-xs text-text-muted" style={{ color: colors.textMuted }}>
            {subtitle}
          </Text>
        ) : null}
      </View>
    </Pressable>
  );
}
