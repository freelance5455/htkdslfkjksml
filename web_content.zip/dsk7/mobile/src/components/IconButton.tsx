import { Pressable, type ViewStyle } from "react-native";
import type { LucideIcon } from "lucide-react-native";
import { colors, layout } from "../theme/tokens.generated";

interface Props {
  icon: LucideIcon;
  label: string;
  onPress: () => void;
  size?: "md" | "lg";
  active?: boolean;
  disabled?: boolean;
  /** Filled style for a toggle that is on (for example the heart). */
  filled?: boolean;
  tone?: "text" | "muted" | "accent" | "on-accent";
  /** Solid circle behind the icon (the big play button). Use with tone="on-accent". */
  background?: "accent";
  hitSlop?: number;
}

const toneColor: Record<NonNullable<Props["tone"]>, string> = {
  text: colors.text,
  muted: colors.textMuted,
  accent: colors.accent,
  "on-accent": colors.onAccent,
};

export function IconButton({
  icon: Icon, label, onPress, size = "md", active, disabled, filled, tone, background, hitSlop,
}: Props) {
  const px = size === "lg" ? 64 : layout["touch-min"];
  const color = tone ? toneColor[tone] : active ? colors.accent : colors.text;
  const style: ViewStyle = {
    width: px,
    height: px,
    borderRadius: px / 2,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: background === "accent" ? colors.accent : "transparent",
  };
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled: !!disabled, selected: !!active }}
      disabled={disabled}
      onPress={onPress}
      hitSlop={hitSlop}
      style={({ pressed }) => ({ ...style, opacity: disabled ? 0.4 : pressed ? 0.7 : 1 })}
    >
      <Icon size={size === "lg" ? 32 : 24} color={color} strokeWidth={2} fill={filled ? color : "none"} />
    </Pressable>
  );
}
