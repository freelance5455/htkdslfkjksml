import { Image, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { coverPair, coverLetter } from "../core/cover";
import { coverColors, colors } from "../theme/tokens.generated";

interface Props {
  id: string;
  title: string;
  uri?: string | null;
  size: number;
  shape?: "square" | "circle";
}

/** Artwork when we have it, otherwise our own generated tile (see cover.ts). */
export function CoverArt({ id, title, uri, size, shape = "square" }: Props) {
  const radius = shape === "circle" ? size / 2 : 8;
  if (uri) {
    return (
      <Image
        source={{ uri }}
        accessibilityIgnoresInvertColors
        accessibilityElementsHidden
        importantForAccessibility="no"
        style={{ width: size, height: size, borderRadius: radius, backgroundColor: colors.surfaceRaised }}
      />
    );
  }
  const [from, to] = coverPair(id, coverColors);
  return (
    <LinearGradient
      colors={[from, to]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      accessible={false}
      importantForAccessibility="no"
      style={{ width: size, height: size, borderRadius: radius, alignItems: "center", justifyContent: "center" }}
    >
      <View accessible={false}>
        <Text
          style={{ fontSize: Math.round(size * 0.42), fontWeight: "700", color: colors.text, opacity: 0.9 }}
          importantForAccessibility="no"
        >
          {coverLetter(title)}
        </Text>
      </View>
    </LinearGradient>
  );
}
