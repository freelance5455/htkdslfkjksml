import { ActivityIndicator, View } from "react-native";
import { Pause, Play, Repeat, Repeat1, Shuffle, SkipBack, SkipForward } from "lucide-react-native";
import type { PlayerController } from "../core/controller";
import type { PlayerStatus } from "../core/types";
import type { RepeatMode } from "../core/queue";
import { IconButton } from "./IconButton";
import { colors } from "../theme/tokens.generated";

interface Props {
  status: PlayerStatus;
  shuffle: boolean;
  repeat: RepeatMode;
  controller: PlayerController;
}

const repeatLabel: Record<RepeatMode, string> = {
  off: "Repeat: off",
  all: "Repeat: all songs",
  one: "Repeat: this song",
};

export function PlayerControls({ status, shuffle, repeat, controller }: Props) {
  const loading = status === "loading" || status === "buffering";
  const isPlaying = status === "playing";
  const playLabel = status === "error" ? "Try again" : isPlaying ? "Pause" : "Play";
  return (
    <View className="flex-row items-center justify-between px-2">
      <IconButton
        icon={Shuffle}
        label={shuffle ? "Shuffle: on" : "Shuffle: off"}
        active={shuffle}
        onPress={() => controller.toggleShuffle()}
      />
      <IconButton icon={SkipBack} label="Previous song" onPress={() => void controller.previous()} />
      {loading ? (
        <View style={{ width: 64, height: 64, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator size="large" color={colors.accent} accessibilityLabel="Loading" />
        </View>
      ) : (
        <IconButton
          icon={isPlaying ? Pause : Play}
          label={playLabel}
          size="lg"
          filled
          background="accent"
          tone="on-accent"
          onPress={() => void controller.togglePlay()}
        />
      )}
      <IconButton icon={SkipForward} label="Next song" onPress={() => void controller.next()} />
      <IconButton
        icon={repeat === "one" ? Repeat1 : Repeat}
        label={repeatLabel[repeat]}
        active={repeat !== "off"}
        onPress={() => controller.cycleRepeat()}
      />
    </View>
  );
}
