import { Pressable, Text, View } from "react-native";
import { EllipsisVertical, Volume2 } from "lucide-react-native";
import type { Song } from "../core/types";
import { artistNames, spokenDuration, formatTime } from "../core/format";
import { CoverArt } from "./CoverArt";
import { IconButton } from "./IconButton";
import { colors, layout } from "../theme/tokens.generated";

interface Props {
  song: Song;
  playing?: boolean;
  onPress: () => void;
  onMore?: () => void;
}

export function SongRow({ song, playing, onPress, onMore }: Props) {
  const artists = artistNames(song.artists);
  const label = `${song.title}, by ${artists}, ${spokenDuration(song.duration_s)}${playing ? ", now playing" : ""}`;
  return (
    <View className="flex-row items-center" style={{ minHeight: layout["art-row"], paddingRight: 4 }}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={label}
        onPress={onPress}
        className="flex-1 flex-row items-center py-2 pl-4"
        style={({ pressed }) => ({ opacity: pressed ? 0.7 : 1 })}
      >
        <CoverArt id={song.id} title={song.title} uri={song.cover_url} size={layout["art-thumb"]} />
        <View className="ml-3 flex-1">
          <Text numberOfLines={1} className={`text-base font-sans-semibold ${playing ? "text-accent" : "text-text"}`}>
            {song.title}
          </Text>
          <View className="flex-row items-center">
            {playing ? <Volume2 size={14} color={colors.accent} style={{ marginRight: 4 }} /> : null}
            <Text numberOfLines={1} className="text-xs text-text-muted">
              {artists} · {formatTime(song.duration_s)}
            </Text>
          </View>
        </View>
      </Pressable>
      {onMore ? (
        <IconButton icon={EllipsisVertical} label={`More options for ${song.title}`} onPress={onMore} tone="muted" />
      ) : null}
    </View>
  );
}
