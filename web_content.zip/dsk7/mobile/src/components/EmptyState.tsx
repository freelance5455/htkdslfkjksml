import { Text, View } from "react-native";
import type { LucideIcon } from "lucide-react-native";
import { Button } from "./Button";
import { colors } from "../theme/tokens.generated";

interface Props {
  icon: LucideIcon;
  title: string;
  body?: string;
  action?: { label: string; onPress: () => void };
}

export function EmptyState({ icon: Icon, title, body, action }: Props) {
  return (
    <View className="flex-1 items-center justify-center px-8 py-12" accessible accessibilityLabel={`${title}. ${body ?? ""}`}>
      <Icon size={48} color={colors.textMuted} strokeWidth={1.5} />
      <Text accessibilityRole="header" className="mt-4 text-base font-sans-semibold text-text text-center">
        {title}
      </Text>
      {body ? <Text className="mt-2 text-sm text-text-muted text-center" style={{ maxWidth: 280 }}>{body}</Text> : null}
      {action ? (
        <View className="mt-6">
          <Button label={action.label} onPress={action.onPress} variant="secondary" />
        </View>
      ) : null}
    </View>
  );
}
