import { test } from "node:test";
import assert from "node:assert/strict";
import { PlayerController } from "./controller.ts";
import type { PlayerTrack } from "./types.ts";
import { FakePlayer } from "../audio/fakePlayer.ts";
import type { PlayRecord } from "./playTracker.ts";

const durations: Record<string, number> = { a: 200, b: 200, c: 200, short: 12 };

function setup(opts: { failResolveFor?: string } = {}) {
  const service = new FakePlayer();
  const plays: PlayRecord[] = [];
  let n = 0;
  const controller = new PlayerController({
    service,
    resolveTrack: async (id: string): Promise<PlayerTrack> => {
      if (opts.failResolveFor === id) throw new Error("This song isn't available right now.");
      return { id, url: "u-" + id, title: id.toUpperCase(), artist: "Test", durationS: durations[id] ?? 100 };
    },
    recordPlay: (r) => plays.push(r),
    newId: () => "p" + ++n,
    rng: () => 0.5,
  });
  return { service, controller, plays };
}

test("playQueue loads the first song and starts playing", async () => {
  const { service, controller } = setup();
  await controller.init();
  await controller.playQueue(["a", "b"]);
  const s = controller.getSnapshot();
  assert.equal(s.currentSongId, "a");
  assert.equal(s.status, "playing");
  assert.equal(s.durationS, 200);
  assert.equal(service.loaded?.id, "a");
});

test("progress records one play after 30 seconds, and only one", async () => {
  const { service, controller, plays } = setup();
  await controller.init();
  await controller.playQueue(["a"]);
  for (let p = 0; p <= 60; p++) service.tick(p);
  assert.equal(plays.length, 1);
  assert.equal(plays[0]?.songId, "a");
});

test("a seek does not count toward a play", async () => {
  const { service, controller, plays } = setup();
  await controller.init();
  await controller.playQueue(["a"]);
  for (let p = 0; p <= 10; p++) service.tick(p);
  service.tick(150);
  service.tick(160);
  assert.equal(plays.length, 0);
});

test("the queue advances on end, and pauses at the end of the queue", async () => {
  const { service, controller } = setup();
  await controller.init();
  await controller.playQueue(["a", "b"]);
  service.end();
  await flush();
  assert.equal(controller.getSnapshot().currentSongId, "b");
  assert.equal(controller.getSnapshot().status, "playing");
  service.end();
  await flush();
  const s = controller.getSnapshot();
  assert.equal(s.currentSongId, "b");
  assert.equal(s.status, "paused");
  assert.equal(s.positionS, 0);
});

test("repeat one replays the same song on end", async () => {
  const { service, controller } = setup();
  await controller.init();
  await controller.playQueue(["a", "b"]);
  controller.cycleRepeat();
  controller.cycleRepeat();
  service.end();
  await flush();
  assert.equal(controller.getSnapshot().currentSongId, "a");
  assert.equal(controller.getSnapshot().status, "playing");
});

test("Next moves on even with repeat one", async () => {
  const { controller } = setup();
  await controller.init();
  await controller.playQueue(["a", "b"]);
  controller.cycleRepeat();
  controller.cycleRepeat();
  await controller.next();
  assert.equal(controller.getSnapshot().currentSongId, "b");
});

test("Previous after 3 seconds restarts; at the start it goes back", async () => {
  const { service, controller } = setup();
  await controller.init();
  await controller.playQueue(["a", "b"], 1);
  service.tick(20);
  await controller.previous();
  assert.equal(controller.getSnapshot().currentSongId, "b", "restarts, does not go back");
  assert.ok(service.calls.includes("seek:0"));
  service.tick(1);
  await controller.previous();
  assert.equal(controller.getSnapshot().currentSongId, "a");
});

test("a failed song shows an error, and retry resumes at the same place", async () => {
  const { service, controller } = setup();
  await controller.init();
  await controller.playQueue(["a"]);
  service.tick(42);
  service.fail("Network dropped");
  assert.equal(controller.getSnapshot().status, "error");
  assert.equal(controller.getSnapshot().error, "Network dropped");
  await controller.retry();
  const s = controller.getSnapshot();
  assert.equal(s.status, "playing");
  assert.equal(s.error, null);
  assert.ok(service.calls.includes("seek:42"));
});

test("a song that cannot be resolved goes to error and can be retried", async () => {
  const { controller } = setup({ failResolveFor: "b" });
  await controller.init();
  await controller.playQueue(["a", "b"]);
  await controller.next();
  assert.equal(controller.getSnapshot().status, "error");
  assert.equal(controller.getSnapshot().currentSongId, "b");
});

test("a newer load wins over an older one still loading", async () => {
  const service = new FakePlayer();
  let release!: () => void;
  const slow = new Promise<void>((r) => (release = r));
  const controller = new PlayerController({
    service,
    resolveTrack: async (id) => {
      if (id === "a") await slow;
      return { id, url: id, title: id, artist: "", durationS: 100 };
    },
    recordPlay: () => {},
    newId: () => "x",
  });
  await controller.init();
  const first = controller.playQueue(["a"]); // slow to resolve
  await controller.playQueue(["b"]); // starts and finishes first
  release();
  await first;
  assert.equal(controller.getSnapshot().currentSongId, "b");
  assert.equal(service.loaded?.id, "b");
});

test("addToQueue on an empty player starts the song", async () => {
  const { service, controller } = setup();
  await controller.init();
  await controller.addToQueue("a", "end");
  assert.equal(service.loaded?.id, "a");
  await controller.addToQueue("b", "end");
  assert.deepEqual(controller.getSnapshot().queue.order, ["a", "b"]);
});

test("removing the playing song moves on and keeps playing if it was playing", async () => {
  const { service, controller } = setup();
  await controller.init();
  await controller.playQueue(["a", "b", "c"]);
  await controller.removeAt(0);
  assert.equal(controller.getSnapshot().currentSongId, "b");
  assert.equal(service.loaded?.id, "b");
  assert.equal(controller.getSnapshot().status, "playing");
});

test("removing the only song stops the player", async () => {
  const { service, controller } = setup();
  await controller.init();
  await controller.playQueue(["a"]);
  await controller.removeAt(0);
  const s = controller.getSnapshot();
  assert.equal(s.currentSongId, null);
  assert.equal(s.status, "idle");
  assert.ok(service.calls.includes("stop"));
});

test("lock screen next and previous go through the same rules", async () => {
  const { service, controller } = setup();
  await controller.init();
  await controller.playQueue(["a", "b"]);
  service.remote("next");
  await flush();
  assert.equal(controller.getSnapshot().currentSongId, "b");
});

test("pause and play toggle", async () => {
  const { controller } = setup();
  await controller.init();
  await controller.playQueue(["a"]);
  await controller.togglePlay();
  assert.equal(controller.getSnapshot().status, "paused");
  await controller.togglePlay();
  assert.equal(controller.getSnapshot().status, "playing");
});

test("a short song counts as a play once heard in full", async () => {
  const { service, controller, plays } = setup();
  await controller.init();
  await controller.playQueue(["short"]);
  for (let p = 0; p <= 12; p++) service.tick(p);
  assert.equal(plays.length, 1);
});

test("shuffle and repeat change the snapshot", async () => {
  const { controller } = setup();
  await controller.init();
  await controller.playQueue(["a", "b", "c"]);
  controller.toggleShuffle();
  assert.equal(controller.getSnapshot().queue.shuffle, true);
  assert.equal(controller.getSnapshot().currentSongId, "a");
  controller.cycleRepeat();
  assert.equal(controller.getSnapshot().queue.repeat, "all");
});

test("subscribers hear every change and can unsubscribe", async () => {
  const { controller } = setup();
  await controller.init();
  let count = 0;
  const off = controller.subscribe(() => count++);
  await controller.playQueue(["a"]);
  const seen = count;
  assert.ok(seen > 0);
  off();
  controller.cycleRepeat();
  assert.equal(count, seen);
});

function flush(): Promise<void> {
  return new Promise((r) => setTimeout(r, 0));
}
