// The generated cover tile used when an item has no artwork. Our own design:
// the same id always gets the same two colours, taken from the token palette.

/** FNV-1a, 32 bit. Stable across devices and runs. */
export function hashString(value: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < value.length; i++) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

export function coverPair<T>(id: string, palette: readonly T[]): [T, T] {
  const n = palette.length;
  const i = hashString(id) % n;
  return [palette[i] as T, palette[(i + 3) % n] as T];
}

/** First letter or digit of the title, upper case. "#" when there is none. */
export function coverLetter(title: string): string {
  const match = title.match(/[\p{L}\p{N}]/u);
  return match ? match[0].toUpperCase() : "#";
}
