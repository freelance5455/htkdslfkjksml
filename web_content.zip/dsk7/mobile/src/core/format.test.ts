import { test } from "node:test";
import assert from "node:assert/strict";
import { artistNames, formatTime, spokenDuration } from "./format.ts";
import { coverLetter, coverPair, hashString } from "./cover.ts";

test("formatTime", () => {
  assert.equal(formatTime(0), "0:00");
  assert.equal(formatTime(9), "0:09");
  assert.equal(formatTime(200), "3:20");
  assert.equal(formatTime(3725), "1:02:05");
  assert.equal(formatTime(59.9), "0:59");
});

test("formatTime survives bad input", () => {
  assert.equal(formatTime(NaN), "0:00");
  assert.equal(formatTime(-4), "0:00");
  assert.equal(formatTime(Infinity), "0:00");
});

test("spokenDuration reads naturally and uses singular words", () => {
  assert.equal(spokenDuration(200), "3 minutes 20 seconds");
  assert.equal(spokenDuration(61), "1 minute 1 second");
  assert.equal(spokenDuration(60), "1 minute");
  assert.equal(spokenDuration(45), "45 seconds");
  assert.equal(spokenDuration(3600), "1 hour");
  assert.equal(spokenDuration(0), "0 seconds");
});

test("artistNames joins with commas", () => {
  assert.equal(artistNames([{ name: "A" }, { name: "B" }]), "A, B");
  assert.equal(artistNames([]), "");
});

test("hashString is stable and spreads", () => {
  assert.equal(hashString("song-1"), hashString("song-1"));
  assert.notEqual(hashString("song-1"), hashString("song-2"));
  assert.equal(hashString(""), 0x811c9dc5);
});

test("coverPair is deterministic and always picks two palette colours", () => {
  const palette = ["p0", "p1", "p2", "p3", "p4", "p5", "p6", "p7"];
  const [a, b] = coverPair("song-1", palette);
  assert.deepEqual(coverPair("song-1", palette), [a, b]);
  assert.ok(palette.includes(a) && palette.includes(b));
  assert.notEqual(a, b);
});

test("coverPair uses every colour across many ids", () => {
  const palette = ["p0", "p1", "p2", "p3", "p4", "p5", "p6", "p7"];
  const used = new Set<string>();
  for (let i = 0; i < 200; i++) used.add(coverPair("id-" + i, palette)[0]);
  assert.equal(used.size, 8);
});

test("coverLetter skips symbols, handles Hindi and empty titles", () => {
  assert.equal(coverLetter("moonlight"), "M");
  assert.equal(coverLetter("  \"Rain\" song"), "R");
  assert.equal(coverLetter("1990s mix"), "1");
  assert.equal(coverLetter("बारिश"), "ब");
  assert.equal(coverLetter("***"), "#");
  assert.equal(coverLetter(""), "#");
});
