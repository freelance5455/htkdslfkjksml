// Ties the queue, the audio engine and play tracking together. Platform free:
// the audio engine is passed in, so tests use a fake one and the app uses
// HTML audio (web) or react-native-track-player (Android).

import type { PlayerService, PlayerStatus, PlayerTrack } from "./types.ts";
import * as Q from "./queue.ts";
import * as T from "./playTracker.ts";

export interface PlayerSnapshot {
  queue: Q.QueueState;
  currentSongId: string | null;
  status: PlayerStatus;
  positionS: number;
  durationS: number;
  error: string | null;
}

export interface ControllerDeps {
  service: PlayerService;
  /** Turns a song id into something playable. Called again on retry, so an expired URL is replaced. */
  resolveTrack(songId: string): Promise<PlayerTrack>;
  recordPlay(record: T.PlayRecord): void;
  newId(): string;
  rng?: () => number;
}

type Listener = (snapshot: PlayerSnapshot) => void;

function messageOf(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

export class PlayerController {
  private deps: ControllerDeps;
  private snap: PlayerSnapshot;
  private listeners: Set<Listener> = new Set();
  private loadToken = 0;
  private tracker: T.TrackerState | null = null;

  constructor(deps: ControllerDeps) {
    this.deps = deps;
    this.snap = {
      queue: Q.emptyQueue(),
      currentSongId: null,
      status: "idle",
      positionS: 0,
      durationS: 0,
      error: null,
    };
  }

  async init(): Promise<void> {
    await this.deps.service.setup({
      onProgress: (pos, dur) => this.handleProgress(pos, dur),
      onEnded: () => void this.handleEnded(),
      onError: (message) => this.handleError(message),
      onState: (state) => this.handleState(state),
      onRemote: (action) => void this.handleRemote(action),
    });
  }

  getSnapshot(): PlayerSnapshot {
    return this.snap;
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  // ---- commands from the UI ------------------------------------------------

  async playQueue(ids: string[], startIndex = 0): Promise<void> {
    await this.startCurrent(Q.createQueue(ids, startIndex), true, 0);
  }

  async togglePlay(): Promise<void> {
    const { status, currentSongId } = this.snap;
    if (currentSongId === null) return;
    if (status === "playing" || status === "buffering") {
      await this.deps.service.pause();
      this.set({ status: "paused" });
    } else if (status === "paused") {
      await this.deps.service.play();
      this.set({ status: "playing" });
    } else if (status === "error") {
      await this.retry();
    } else if (status === "idle") {
      await this.startCurrent(this.snap.queue, true, 0);
    }
  }

  async next(): Promise<void> {
    const r = Q.next(this.snap.queue, false);
    if (r.action === "end") {
      await this.rewindAndPause();
      return;
    }
    await this.startCurrent(r.state, true, 0);
  }

  async previous(): Promise<void> {
    const r = Q.previous(this.snap.queue, this.snap.positionS);
    if (r.action === "restart") {
      await this.restartCurrent();
      return;
    }
    await this.startCurrent(r.state, true, 0);
  }

  async seek(positionS: number): Promise<void> {
    const max = this.snap.durationS > 0 ? this.snap.durationS : positionS;
    const clamped = Math.min(Math.max(positionS, 0), max);
    await this.deps.service.seekTo(clamped);
    this.set({ positionS: clamped });
  }

  async jumpTo(index: number): Promise<void> {
    const queue = Q.jumpTo(this.snap.queue, index);
    if (queue === this.snap.queue) return;
    await this.startCurrent(queue, true, 0);
  }

  toggleShuffle(): void {
    this.set({ queue: Q.toggleShuffle(this.snap.queue, this.deps.rng) });
  }

  cycleRepeat(): void {
    this.set({ queue: Q.cycleRepeat(this.snap.queue) });
  }

  /** Add to the queue. If nothing is queued yet, this also starts playing it. */
  async addToQueue(songId: string, where: "end" | "next"): Promise<void> {
    const wasEmpty = this.snap.queue.order.length === 0;
    const queue = Q.addToQueue(this.snap.queue, songId, where);
    if (wasEmpty) await this.startCurrent(queue, true, 0);
    else this.set({ queue });
  }

  async removeAt(index: number): Promise<void> {
    const { state, removedCurrent } = Q.removeAt(this.snap.queue, index);
    if (!removedCurrent) {
      this.set({ queue: state });
      return;
    }
    if (state.order.length === 0) {
      this.loadToken++;
      await this.deps.service.stop();
      this.tracker = null;
      this.set({ queue: state, currentSongId: null, status: "idle", positionS: 0, durationS: 0, error: null });
      return;
    }
    await this.startCurrent(state, this.snap.status === "playing", 0);
  }

  moveItem(from: number, to: number): void {
    this.set({ queue: Q.moveItem(this.snap.queue, from, to) });
  }

  /** After an error: ask for a fresh URL and carry on from where it stopped. */
  async retry(): Promise<void> {
    if (this.snap.currentSongId === null) return;
    await this.startCurrent(this.snap.queue, true, this.snap.positionS);
  }

  // ---- internals -----------------------------------------------------------

  private set(patch: Partial<PlayerSnapshot>): void {
    this.snap = { ...this.snap, ...patch };
    for (const listener of this.listeners) listener(this.snap);
  }

  /** Load whatever the queue points at. A newer call always wins over an older one still loading. */
  private async startCurrent(queue: Q.QueueState, autoplay: boolean, resumeAtS: number): Promise<void> {
    const id = Q.currentId(queue);
    const token = ++this.loadToken;
    this.set({
      queue,
      currentSongId: id,
      status: id === null ? "idle" : "loading",
      positionS: resumeAtS,
      durationS: 0,
      error: null,
    });
    if (id === null) {
      await this.deps.service.stop();
      return;
    }
    try {
      const track = await this.deps.resolveTrack(id);
      if (token !== this.loadToken) return;
      this.tracker = T.startTracking(id, track.durationS);
      this.set({ durationS: track.durationS });
      await this.deps.service.load(track, autoplay);
      if (token !== this.loadToken) return;
      if (resumeAtS > 0) await this.deps.service.seekTo(resumeAtS);
      // Some engines do not report a state after load. Do not stay on "loading".
      if (this.snap.status === "loading") this.set({ status: autoplay ? "playing" : "paused" });
    } catch (e) {
      if (token !== this.loadToken) return;
      this.set({ status: "error", error: messageOf(e) });
    }
  }

  private async restartCurrent(): Promise<void> {
    const id = this.snap.currentSongId;
    await this.deps.service.seekTo(0);
    if (id !== null) this.tracker = T.startTracking(id, this.snap.durationS);
    this.set({ positionS: 0 });
    if (this.snap.status === "paused") {
      await this.deps.service.play();
      this.set({ status: "playing" });
    }
  }

  private async rewindAndPause(): Promise<void> {
    await this.deps.service.seekTo(0);
    await this.deps.service.pause();
    this.set({ positionS: 0, status: "paused" });
  }

  private handleProgress(positionS: number, durationS: number): void {
    if (this.snap.status === "error") return;
    const patch: Partial<PlayerSnapshot> = { positionS };
    if (durationS > 0 && durationS !== this.snap.durationS) patch.durationS = durationS;
    this.set(patch);
    if (this.tracker !== null) {
      const { state, record } = T.onProgress(this.tracker, positionS, this.snap.status === "playing", this.deps.newId);
      this.tracker = state;
      if (record !== null) this.deps.recordPlay(record);
    }
  }

  private async handleEnded(): Promise<void> {
    const r = Q.next(this.snap.queue, true);
    if (r.action === "replay") {
      await this.restartCurrent();
      await this.deps.service.play();
      this.set({ status: "playing" });
    } else if (r.action === "advance") {
      await this.startCurrent(r.state, true, 0);
    } else {
      await this.rewindAndPause();
    }
  }

  private handleError(message: string): void {
    this.set({ status: "error", error: message });
  }

  private handleState(state: "playing" | "paused" | "buffering" | "idle"): void {
    // Ignore engine noise while loading or after an error. startCurrent resets
    // the status, so a retry can move out of "error".
    if (state === "idle") return;
    if (this.snap.status === "error" || this.snap.status === "loading") {
      if (state !== "playing") return;
    }
    this.set({ status: state });
  }

  private async handleRemote(action: "next" | "previous" | "play" | "pause"): Promise<void> {
    if (action === "next") await this.next();
    else if (action === "previous") await this.previous();
    else if (action === "play" && this.snap.status === "paused") await this.togglePlay();
    else if (action === "pause" && this.snap.status === "playing") await this.togglePlay();
  }
}
