import { test } from "node:test";
import assert from "node:assert/strict";
import * as Q from "./queue.ts";

const ids = ["a", "b", "c", "d"];

// A fixed "random" so shuffle tests do not flake.
function seeded(): () => number {
  let x = 7;
  return () => {
    x = (x * 16807) % 2147483647;
    return x / 2147483647;
  };
}

test("createQueue clamps the start index and handles an empty list", () => {
  assert.equal(Q.createQueue(ids, 99).index, 3);
  assert.equal(Q.createQueue(ids, -5).index, 0);
  assert.equal(Q.currentId(Q.createQueue([])), null);
});

test("next advances, and at the end stops unless repeat all", () => {
  let q = Q.createQueue(ids, 2);
  let r = Q.next(q, true);
  assert.equal(r.action, "advance");
  assert.equal(Q.currentId(r.state), "d");
  q = r.state;
  r = Q.next(q, true);
  assert.equal(r.action, "end");
  assert.equal(r.state.index, 3, "stays on the last song");
  r = Q.next({ ...q, repeat: "all" }, true);
  assert.equal(r.action, "advance");
  assert.equal(Q.currentId(r.state), "a");
});

test("repeat one replays on auto end but Next still moves on", () => {
  const q = { ...Q.createQueue(ids, 1), repeat: "one" as const };
  assert.equal(Q.next(q, true).action, "replay");
  const manual = Q.next(q, false);
  assert.equal(manual.action, "advance");
  assert.equal(Q.currentId(manual.state), "c");
});

test("previous restarts after 3 seconds, otherwise goes back", () => {
  const q = Q.createQueue(ids, 2);
  assert.equal(Q.previous(q, 10).action, "restart");
  const back = Q.previous(q, 1);
  assert.equal(back.action, "back");
  assert.equal(Q.currentId(back.state), "b");
});

test("previous on the first song restarts, or wraps with repeat all", () => {
  const q = Q.createQueue(ids, 0);
  assert.equal(Q.previous(q, 0).action, "restart");
  const wrap = Q.previous({ ...q, repeat: "all" }, 0);
  assert.equal(Q.currentId(wrap.state), "d");
});

test("cycleRepeat goes off, all, one, off", () => {
  let q = Q.createQueue(ids);
  const seen: string[] = [];
  for (let i = 0; i < 4; i++) {
    q = Q.cycleRepeat(q);
    seen.push(q.repeat);
  }
  assert.deepEqual(seen, ["all", "one", "off", "all"]);
});

test("shuffle on keeps the current song first and the same songs", () => {
  const q = Q.createQueue(ids, 2);
  const s = Q.toggleShuffle(q, seeded());
  assert.equal(s.shuffle, true);
  assert.equal(Q.currentId(s), "c");
  assert.equal(s.index, 0);
  assert.deepEqual([...s.order].sort(), [...ids].sort());
  assert.deepEqual(s.original, ids, "original order is kept");
});

test("shuffle off restores the original order at the current song", () => {
  const on = Q.toggleShuffle(Q.createQueue(ids, 1), seeded());
  const off = Q.toggleShuffle(on, seeded());
  assert.equal(off.shuffle, false);
  assert.deepEqual(off.order, ids);
  assert.equal(Q.currentId(off), "b");
});

test("addToQueue at the end and as play next", () => {
  const q = Q.createQueue(["a", "b", "c"], 0);
  const end = Q.addToQueue(q, "x", "end");
  assert.deepEqual(end.order, ["a", "b", "c", "x"]);
  const nextUp = Q.addToQueue(q, "y", "next");
  assert.deepEqual(nextUp.order, ["a", "y", "b", "c"]);
  assert.deepEqual(nextUp.original, ["a", "y", "b", "c"]);
  assert.deepEqual(Q.upNext(nextUp), ["y", "b", "c"]);
});

test("addToQueue on an empty queue makes it the current song", () => {
  const q = Q.addToQueue(Q.emptyQueue(), "x", "end");
  assert.equal(Q.currentId(q), "x");
});

test("removeAt before the current song keeps the same song current", () => {
  const q = Q.createQueue(ids, 2);
  const { state, removedCurrent } = Q.removeAt(q, 0);
  assert.equal(removedCurrent, false);
  assert.equal(Q.currentId(state), "c");
  assert.deepEqual(state.order, ["b", "c", "d"]);
  assert.deepEqual(state.original, ["b", "c", "d"]);
});

test("removeAt the current song reports it and points at the next one", () => {
  const { state, removedCurrent } = Q.removeAt(Q.createQueue(ids, 1), 1);
  assert.equal(removedCurrent, true);
  assert.equal(Q.currentId(state), "c");
});

test("removeAt the last song when it is current moves back", () => {
  const { state } = Q.removeAt(Q.createQueue(ids, 3), 3);
  assert.equal(Q.currentId(state), "c");
});

test("removeAt the only song empties the queue", () => {
  const { state, removedCurrent } = Q.removeAt(Q.createQueue(["a"]), 0);
  assert.equal(removedCurrent, true);
  assert.equal(Q.currentId(state), null);
});

test("moveItem keeps the current song current in every direction", () => {
  const q = Q.createQueue(ids, 1); // current b
  assert.equal(Q.currentId(Q.moveItem(q, 0, 3)), "b"); // a moved after b
  assert.equal(Q.currentId(Q.moveItem(q, 3, 0)), "b"); // d moved before b
  const moved = Q.moveItem(q, 1, 3); // b itself moves
  assert.equal(moved.index, 3);
  assert.equal(Q.currentId(moved), "b");
  assert.deepEqual(moved.order, ["a", "c", "d", "b"]);
});

test("moveItem with shuffle on leaves the original order for later", () => {
  const on = Q.toggleShuffle(Q.createQueue(ids, 0), seeded());
  const moved = Q.moveItem(on, 1, 2);
  assert.deepEqual(moved.original, ids);
});

test("bad indexes do nothing", () => {
  const q = Q.createQueue(ids, 1);
  assert.equal(Q.moveItem(q, 9, 0), q);
  assert.equal(Q.jumpTo(q, -1), q);
  assert.equal(Q.removeAt(q, 9).state, q);
});
