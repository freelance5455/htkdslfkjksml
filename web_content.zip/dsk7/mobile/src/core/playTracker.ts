// Decides when a play counts. A play is recorded once the listener has really
// heard 30 seconds (or the whole song, if it is shorter than that).
// Seeking, pausing and buffering do not add listening time.

export const MIN_LISTEN_S = 30;
/** Progress ticks arrive about once a second. A bigger jump is a seek, not listening. */
export const MAX_TICK_GAP_S = 2.5;

export interface TrackerState {
  songId: string;
  durationS: number;
  listenedS: number;
  lastPos: number | null;
  recorded: boolean;
}

export interface PlayRecord {
  /** Made on the device so a retried request cannot count the play twice. */
  id: string;
  songId: string;
  listenedS: number;
}

export function startTracking(songId: string, durationS: number): TrackerState {
  return { songId, durationS, listenedS: 0, lastPos: null, recorded: false };
}

export function threshold(durationS: number): number {
  return durationS > 0 ? Math.min(MIN_LISTEN_S, durationS) : MIN_LISTEN_S;
}

export function onProgress(
  s: TrackerState,
  positionS: number,
  playing: boolean,
  newId: () => string,
): { state: TrackerState; record: PlayRecord | null } {
  let listenedS = s.listenedS;
  if (playing && s.lastPos !== null) {
    const delta = positionS - s.lastPos;
    if (delta > 0 && delta <= MAX_TICK_GAP_S) listenedS += delta;
  }
  let state: TrackerState = { ...s, listenedS, lastPos: positionS };
  if (!state.recorded && listenedS >= threshold(s.durationS)) {
    state = { ...state, recorded: true };
    return { state, record: { id: newId(), songId: s.songId, listenedS: Math.max(1, Math.round(listenedS)) } };
  }
  return { state, record: null };
}
