/** 200 -> "3:20", 3725 -> "1:02:05". Bad input gives "0:00". */
export function formatTime(totalSeconds: number): string {
  const s = Number.isFinite(totalSeconds) && totalSeconds > 0 ? Math.floor(totalSeconds) : 0;
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const two = (n: number) => (n < 10 ? "0" + n : String(n));
  return h > 0 ? `${h}:${two(m)}:${two(sec)}` : `${m}:${two(sec)}`;
}

function unit(n: number, word: string): string {
  return `${n} ${word}${n === 1 ? "" : "s"}`;
}

/** For screen readers: 200 -> "3 minutes 20 seconds". */
export function spokenDuration(totalSeconds: number): string {
  const s = Number.isFinite(totalSeconds) && totalSeconds > 0 ? Math.floor(totalSeconds) : 0;
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const parts: string[] = [];
  if (h > 0) parts.push(unit(h, "hour"));
  if (m > 0) parts.push(unit(m, "minute"));
  if (sec > 0 || parts.length === 0) parts.push(unit(sec, "second"));
  return parts.join(" ");
}

/** "Orbit Kiln, Static Bloom" from a list of artists. */
export function artistNames(artists: { name: string }[]): string {
  return artists.map((a) => a.name).join(", ");
}
