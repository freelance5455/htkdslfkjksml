// Domain types. They mirror replica/schema.sql, so the fake data layer and the
// Supabase data layer return the same shapes and no screen has to change.

export interface ArtistRef {
  id: string;
  name: string;
}

export interface Song {
  id: string;
  title: string;
  album_id: string | null;
  duration_s: number;
  /** A playable URL, or "seed:<key>" for audio bundled with the app (dev seed only). */
  audio_url: string | null;
  /** Path in the private Supabase Storage bucket, for your own uploads. */
  storage_path: string | null;
  language: string | null;
  explicit: boolean;
  license: string;
  license_url: string | null;
  attribution: string;
  artists: ArtistRef[];
  cover_url: string | null;
}

export type PlaylistKind = "user" | "editorial" | "chart" | "mood";

export interface Playlist {
  id: string;
  owner_id: string | null;
  title: string;
  description: string | null;
  cover_url: string | null;
  kind: PlaylistKind;
  is_public: boolean;
  song_count: number;
}

export interface PlaylistWithSongs extends Playlist {
  songs: Song[];
}

export type HomeSection =
  | { id: string; title: string; kind: "playlists"; items: Playlist[] }
  | { id: string; title: string; kind: "songs"; items: Song[] };

export interface Profile {
  id: string;
  display_name: string;
  languages: string[];
  plan: "free" | "pro";
}

/** What the audio engine needs to play one song. */
export interface PlayerTrack {
  id: string;
  url: string | number;
  title: string;
  artist: string;
  artworkUrl?: string;
  durationS: number;
}

export type PlayerStatus = "idle" | "loading" | "playing" | "paused" | "buffering" | "error";

export interface PlayerServiceEvents {
  onProgress(positionS: number, durationS: number): void;
  onEnded(): void;
  onError(message: string): void;
  onState(state: "playing" | "paused" | "buffering" | "idle"): void;
  onRemote(action: "next" | "previous" | "play" | "pause"): void;
}

/** One adapter per platform: HTML audio on web, react-native-track-player on Android. */
export interface PlayerService {
  setup(events: PlayerServiceEvents): Promise<void>;
  load(track: PlayerTrack, autoplay: boolean): Promise<void>;
  play(): Promise<void>;
  pause(): Promise<void>;
  seekTo(positionS: number): Promise<void>;
  stop(): Promise<void>;
}
