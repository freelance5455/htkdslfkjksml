import { test } from "node:test";
import assert from "node:assert/strict";
import * as T from "./playTracker.ts";

let counter = 0;
const newId = () => "play-" + ++counter;

/** Feed one progress tick per second from `from` to `to`. */
function listen(s: T.TrackerState, from: number, to: number, playing = true) {
  let state = s;
  const records: T.PlayRecord[] = [];
  for (let p = from; p <= to; p++) {
    const r = T.onProgress(state, p, playing, newId);
    state = r.state;
    if (r.record) records.push(r.record);
  }
  return { state, records };
}

test("a play is recorded once, after 30 seconds of listening", () => {
  const { records, state } = listen(T.startTracking("s1", 200), 0, 100);
  assert.equal(records.length, 1);
  assert.equal(records[0]?.songId, "s1");
  assert.equal(records[0]?.listenedS, 30);
  assert.equal(state.recorded, true);
});

test("29 seconds is not enough", () => {
  const { records } = listen(T.startTracking("s1", 200), 0, 29);
  assert.equal(records.length, 0);
});

test("a song shorter than 30 seconds counts when it has been heard in full", () => {
  const { records } = listen(T.startTracking("short", 12), 0, 12);
  assert.equal(records.length, 1);
});

test("paused time does not count", () => {
  const { records } = listen(T.startTracking("s1", 200), 0, 100, false);
  assert.equal(records.length, 0);
});

test("seeking does not count as listening", () => {
  let s = T.startTracking("s1", 300);
  s = listen(s, 0, 10).state; // 10 s heard
  s = listen(s, 200, 215).state; // jumped to 200, then 15 s heard
  assert.ok(s.listenedS >= 24 && s.listenedS <= 26, "about 25 s, not 215");
  assert.equal(s.recorded, false);
});

test("going backwards does not count", () => {
  let s = T.startTracking("s1", 300);
  s = listen(s, 50, 60).state;
  const before = s.listenedS;
  s = T.onProgress(s, 20, true, newId).state;
  assert.equal(s.listenedS, before);
});

test("each record gets its own id", () => {
  const a = listen(T.startTracking("a", 100), 0, 40).records[0];
  const b = listen(T.startTracking("b", 100), 0, 40).records[0];
  assert.notEqual(a?.id, b?.id);
});

test("an unknown duration still uses the 30 second rule", () => {
  assert.equal(T.threshold(0), 30);
  assert.equal(T.threshold(500), 30);
  assert.equal(T.threshold(20), 20);
});
