// The play queue as plain, immutable data. No React, no audio, so it is easy to test.
// `order` is the order songs will play in. `original` is the order before shuffle.
// A queue may hold the same song twice (the user can add it again).

export type RepeatMode = "off" | "all" | "one";

export interface QueueState {
  order: string[];
  original: string[];
  index: number;
  shuffle: boolean;
  repeat: RepeatMode;
}

export type NextAction = "advance" | "replay" | "end";
export type PreviousAction = "restart" | "back";

export function createQueue(ids: string[], startIndex = 0): QueueState {
  const index = ids.length === 0 ? 0 : Math.min(Math.max(startIndex, 0), ids.length - 1);
  return { order: [...ids], original: [...ids], index, shuffle: false, repeat: "off" };
}

export function emptyQueue(): QueueState {
  return createQueue([]);
}

export function currentId(q: QueueState): string | null {
  return q.order[q.index] ?? null;
}

export function upNext(q: QueueState): string[] {
  return q.order.slice(q.index + 1);
}

/**
 * Where to go when a song ends (auto = true) or the user taps Next (auto = false).
 * Repeat-one only repeats on its own; an explicit Next still moves on.
 */
export function next(q: QueueState, auto: boolean): { state: QueueState; action: NextAction } {
  if (q.order.length === 0) return { state: q, action: "end" };
  if (auto && q.repeat === "one") return { state: q, action: "replay" };
  if (q.index < q.order.length - 1) return { state: { ...q, index: q.index + 1 }, action: "advance" };
  if (q.repeat === "all") return { state: { ...q, index: 0 }, action: "advance" };
  return { state: q, action: "end" };
}

/** More than 3 seconds in: restart this song. Otherwise go to the one before. */
export function previous(q: QueueState, positionS: number): { state: QueueState; action: PreviousAction } {
  if (positionS > 3 || q.order.length === 0) return { state: q, action: "restart" };
  if (q.index > 0) return { state: { ...q, index: q.index - 1 }, action: "back" };
  if (q.repeat === "all") return { state: { ...q, index: q.order.length - 1 }, action: "back" };
  return { state: q, action: "restart" };
}

export function jumpTo(q: QueueState, index: number): QueueState {
  if (index < 0 || index >= q.order.length) return q;
  return { ...q, index };
}

export function cycleRepeat(q: QueueState): QueueState {
  const repeat: RepeatMode = q.repeat === "off" ? "all" : q.repeat === "all" ? "one" : "off";
  return { ...q, repeat };
}

function shuffled<T>(items: T[], rng: () => number): T[] {
  const out = [...items];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i] as T;
    out[i] = out[j] as T;
    out[j] = tmp;
  }
  return out;
}

/**
 * Turning shuffle on keeps the current song first and shuffles the rest.
 * Turning it off restores the original order, with the current song still current.
 */
export function toggleShuffle(q: QueueState, rng: () => number = Math.random): QueueState {
  const current = currentId(q);
  if (current === null) return { ...q, shuffle: !q.shuffle };
  if (!q.shuffle) {
    const rest = q.order.filter((_, i) => i !== q.index);
    return { ...q, shuffle: true, order: [current, ...shuffled(rest, rng)], index: 0 };
  }
  const at = q.original.indexOf(current);
  return { ...q, shuffle: false, order: [...q.original], index: at === -1 ? 0 : at };
}

/** Add a song to the end of the queue, or right after the current song ("play next"). */
export function addToQueue(q: QueueState, id: string, where: "end" | "next"): QueueState {
  if (q.order.length === 0) return createQueue([id]);
  if (where === "end") {
    return { ...q, order: [...q.order, id], original: [...q.original, id] };
  }
  const order = [...q.order];
  order.splice(q.index + 1, 0, id);
  const original = [...q.original];
  const current = currentId(q);
  const at = current === null ? -1 : original.indexOf(current);
  original.splice(at + 1, 0, id);
  return { ...q, order, original };
}

/** Remove the song at `i` in play order. Says whether it was the one playing. */
export function removeAt(q: QueueState, i: number): { state: QueueState; removedCurrent: boolean } {
  if (i < 0 || i >= q.order.length) return { state: q, removedCurrent: false };
  const id = q.order[i] as string;
  const order = q.order.filter((_, n) => n !== i);
  const original = [...q.original];
  const at = original.indexOf(id);
  if (at !== -1) original.splice(at, 1);
  const removedCurrent = i === q.index;
  let index = q.index;
  if (i < q.index) index -= 1;
  index = order.length === 0 ? 0 : Math.min(index, order.length - 1);
  return { state: { ...q, order, original, index }, removedCurrent };
}

/** Drag a song from one position to another. The current song stays current. */
export function moveItem(q: QueueState, from: number, to: number): QueueState {
  const n = q.order.length;
  if (from === to || from < 0 || to < 0 || from >= n || to >= n) return q;
  const order = [...q.order];
  const [item] = order.splice(from, 1) as [string];
  order.splice(to, 0, item);
  let index = q.index;
  if (from === q.index) index = to;
  else if (from < q.index && to >= q.index) index -= 1;
  else if (from > q.index && to <= q.index) index += 1;
  // With shuffle off the visible order is the real order. With shuffle on, the
  // original order is left alone, so turning shuffle off still restores it.
  const original = q.shuffle ? q.original : [...order];
  return { ...q, order, original, index };
}
