import { createContext, useContext, useEffect, useMemo, useSyncExternalStore, type ReactNode } from "react";
import { Platform } from "react-native";
import * as Crypto from "expo-crypto";
import { PlayerController, type PlayerSnapshot } from "../core/controller";
import type { PlayerService } from "../core/types";
import { FakePlayer } from "../audio/fakePlayer";
import { TrackPlayerService } from "../audio/trackPlayerAdapter";
import { useData } from "../data/DataProvider";
import type { DataLayer } from "../data/dataLayer";

const PlayerCtx = createContext<PlayerController | null>(null);

// Android gets the real engine. Web and iOS get a silent one, so the screens still work in dev.
function makeService(): PlayerService {
  return Platform.OS === "android" ? new TrackPlayerService() : new FakePlayer();
}

function createController(data: DataLayer): PlayerController {
  return new PlayerController({
    service: makeService(),
    resolveTrack: async (songId) => {
      const song = await data.getSong(songId);
      if (!song) throw new Error("This song isn't available right now.");
      return data.resolveTrack(song);
    },
    recordPlay: (r) => {
      // A failed play write is not worth interrupting the listener for.
      void data.recordPlay(r.id, r.songId, r.listenedS).catch(() => {});
    },
    newId: () => Crypto.randomUUID(),
  });
}

export function PlayerProvider({ children }: { children: ReactNode }) {
  const data = useData();
  const controller = useMemo(() => createController(data), [data]);
  useEffect(() => {
    void controller.init();
  }, [controller]);
  return <PlayerCtx.Provider value={controller}>{children}</PlayerCtx.Provider>;
}

/** The player state, re-rendering whenever it changes, plus the controller for commands. */
export function usePlayer(): PlayerSnapshot & { controller: PlayerController } {
  const controller = useContext(PlayerCtx);
  if (!controller) throw new Error("usePlayer must be used inside PlayerProvider");
  const snap = useSyncExternalStore(
    (onChange) => controller.subscribe(onChange),
    () => controller.getSnapshot(),
  );
  return { ...snap, controller };
}
