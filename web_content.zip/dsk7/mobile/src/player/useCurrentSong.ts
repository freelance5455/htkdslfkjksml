import { useEffect, useState } from "react";
import type { Song } from "../core/types";
import { useData } from "../data/DataProvider";

/** Loads the song that is playing, so the player UI can show its title and artwork. */
export function useCurrentSong(songId: string | null): Song | null {
  const data = useData();
  const [song, setSong] = useState<Song | null>(null);
  useEffect(() => {
    let live = true;
    if (!songId) {
      setSong(null);
      return;
    }
    data.getSong(songId).then((s) => {
      if (live) setSong(s);
    });
    return () => {
      live = false;
    };
  }, [data, songId]);
  return song;
}
