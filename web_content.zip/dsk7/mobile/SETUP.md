# Setting up the DSK 7 app on your computer

These files were written in a sandbox that cannot install npm packages. Nothing in the UI has been run yet. The steps below turn them into a working Expo app.

## 1. Create the project

```bash
npx create-expo-app@latest dsk7-app --template blank-typescript
cd dsk7-app
```

## 2. Install the dependencies

Use `npx expo install` so the versions match your Expo SDK:

```bash
npx expo install expo-router expo-linking expo-constants expo-status-bar react-native-safe-area-context react-native-screens
npx expo install expo-font expo-splash-screen expo-linear-gradient expo-crypto
npx expo install @expo-google-fonts/inter
npx expo install @react-native-async-storage/async-storage
npm install @supabase/supabase-js
npx expo install @react-native-community/slider
npx expo install react-native-track-player
npm install lucide-react-native nativewind tailwindcss@3
npm install --save-dev @types/node
```

`react-native-track-player` needs a development build, not Expo Go:

```bash
npx expo install expo-dev-client
npx expo run:android
```

## 3. Copy the files

From the folder that holds `replica/` and `mobile/`, copy into the new project:

- `mobile/app/` to `dsk7-app/app/` (replaces the template's `app/`)
- `mobile/src/` to `dsk7-app/src/`
- `mobile/assets/seed/` to `dsk7-app/assets/seed/`
- `mobile/tailwind.tokens.js` to the project root

## 4. Wire up NativeWind and the tokens

`tailwind.config.js`:

```js
const dsk7 = require("./tailwind.tokens.js");

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{ts,tsx}", "./src/**/*.{ts,tsx}"],
  presets: [require("nativewind/preset")],
  theme: { extend: dsk7 },
  plugins: [],
};
```

`global.css`:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

`babel.config.js`:

```js
module.exports = function (api) {
  api.cache(true);
  return {
    presets: [["babel-preset-expo", { jsxImportSource: "nativewind" }], "nativewind/babel"],
  };
};
```

`metro.config.js`:

```js
const { getDefaultConfig } = require("expo/metro-config");
const { withNativeWind } = require("nativewind/metro");
const config = getDefaultConfig(__dirname);
module.exports = withNativeWind(config, { input: "./global.css" });
```

Add `"main": "expo-router/entry"` in `package.json` and set `"scheme": "dsk7"` in `app.json`.

## 5. Check before running

```bash
# core logic: 51 tests, no device needed
node --experimental-strip-types --test src/core/*.test.ts

# types
npx tsc --noEmit
```

Expect these to fail the first time, and fix them as they come up:

- `react-native-track-player` method names and event payloads (see `src/audio/trackPlayerAdapter.ts`, marked NOT YET VERIFIED).
- NativeWind class names that don't exist in your Tailwind version.
- `@react-native-community/slider` props on your SDK version.

## 6. Background playback

`react-native-track-player` needs a playback service. Create `index.js` in the project root that registers it before Expo Router loads, or follow the library's guide for your SDK. Lock-screen next and previous only work once that is registered. This is not written yet.

## 7. Build the APK with EAS (cloud build)

Expo builds the Android app on its servers, so you do not need Android Studio. You need a free Expo account.

```bash
npm install -g eas-cli
eas login                      # free Expo account
eas build:configure            # creates eas.json, answer Android if asked
```

Set the Android build to APK (a file you can install directly) in `eas.json`:

```json
{
  "cli": { "version": ">= 12.0.0" },
  "build": {
    "development": { "developmentClient": true, "distribution": "internal" },
    "preview": { "distribution": "internal", "android": { "buildType": "apk" } },
    "production": { "android": { "buildType": "app-bundle" } }
  }
}
```

Then build:

```bash
eas build -p android --profile preview
```

When it finishes, EAS prints a download link for the `.apk`. Open it on an Android phone (allow "install unknown apps" for your browser) to install.

The first cloud build often fails on a version mismatch or a native module. If it does, send the log to the assistant and it will be fixed in the code.

Note: this build uses the seed data and the silent fake player on non-Android platforms. Android uses the real engine (`react-native-track-player`), which has not been verified on a device yet.
