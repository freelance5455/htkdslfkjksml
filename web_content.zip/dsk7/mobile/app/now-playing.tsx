import { useEffect, useState } from "react";
import { Text, useWindowDimensions, View } from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ChevronDown, Heart, AlertTriangle } from "lucide-react-native";
import { usePlayer } from "../src/player/PlayerProvider";
import { useCurrentSong } from "../src/player/useCurrentSong";
import { useData } from "../src/data/DataProvider";
import { CoverArt } from "../src/components/CoverArt";
import { SeekBar } from "../src/components/SeekBar";
import { PlayerControls } from "../src/components/PlayerControls";
import { IconButton } from "../src/components/IconButton";
import { Button } from "../src/components/Button";
import { artistNames } from "../src/core/format";
import { colors } from "../src/theme/tokens.generated";

// S13: now playing. Full controls, like, attribution, and an error state with retry.
export default function NowPlaying() {
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const data = useData();
  const { controller, status, positionS, durationS, currentSongId, queue, error } = usePlayer();
  const song = useCurrentSong(currentSongId);
  const [liked, setLiked] = useState(false);
  const [likeError, setLikeError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    if (!currentSongId) return;
    data.isLiked(currentSongId).then((v) => live && setLiked(v));
    return () => {
      live = false;
    };
  }, [data, currentSongId]);

  // With nothing playing there is nothing to show, so go back to where the user came from.
  useEffect(() => {
    if (!currentSongId) router.back();
  }, [currentSongId]);

  if (!song) return <View className="flex-1 bg-bg" />;

  const artists = artistNames(song.artists);
  const artSize = Math.min(width - 48, 320);

  const toggleLike = async () => {
    const next = !liked;
    setLiked(next);
    setLikeError(null);
    try {
      await data.setLiked(song.id, next);
    } catch (e) {
      setLiked(!next);
      setLikeError(e instanceof Error ? e.message : "Couldn't update your like.");
    }
  };

  return (
    <View className="flex-1 bg-bg" style={{ paddingTop: insets.top + 8, paddingBottom: insets.bottom + 16 }}>
      <View className="flex-row items-center justify-between px-2">
        <IconButton icon={ChevronDown} label="Close player" onPress={() => router.back()} />
        <Text className="text-xs font-sans-medium text-text-muted">Now playing</Text>
        <View style={{ width: 48 }} />
      </View>

      <View className="flex-1 justify-center px-6" style={{ gap: 20 }}>
        <View className="items-center">
          <CoverArt id={song.id} title={song.title} uri={song.cover_url} size={artSize} />
        </View>

        <View className="flex-row items-center">
          <View className="flex-1 pr-2">
            <Text accessibilityRole="header" numberOfLines={2} className="text-xl font-sans-bold text-text">
              {song.title}
            </Text>
            <Text numberOfLines={1} className="text-base text-text-muted">{artists}</Text>
          </View>
          <IconButton
            icon={Heart}
            label={liked ? "Unlike" : "Like"}
            filled={liked}
            active={liked}
            onPress={() => void toggleLike()}
          />
        </View>
        {likeError ? <Text accessibilityLiveRegion="polite" className="text-sm text-danger">{likeError}</Text> : null}

        {status === "error" ? (
          <View className="items-center" style={{ gap: 12 }}>
            <AlertTriangle size={24} color={colors.danger} />
            <Text accessibilityLiveRegion="polite" className="text-sm text-danger text-center">
              {error ?? "This song couldn't be played."}
            </Text>
            <Button label="Try again" onPress={() => void controller.retry()} />
          </View>
        ) : (
          <SeekBar positionS={positionS} durationS={durationS} onSeek={(p) => void controller.seek(p)} />
        )}

        <PlayerControls status={status} shuffle={queue.shuffle} repeat={queue.repeat} controller={controller} />

        <Text accessibilityLabel={`${song.attribution ? `By ${song.attribution}. ` : ""}Licence: ${song.license}`} className="text-xs text-text-muted text-center">
          {song.attribution ? `By ${song.attribution} · ` : ""}
          {song.license}
        </Text>
      </View>
    </View>
  );
}
