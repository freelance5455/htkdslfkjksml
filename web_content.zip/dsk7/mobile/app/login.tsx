import { useState } from "react";
import { KeyboardAvoidingView, Platform, Text, TextInput, View } from "react-native";
import { router } from "expo-router";
import { useData } from "../src/data/DataProvider";
import { DataError } from "../src/data/dataLayer";
import { Button } from "../src/components/Button";
import { colors } from "../src/theme/tokens.generated";

function messageOf(e: unknown): string {
  return e instanceof DataError || e instanceof Error ? e.message : "Something went wrong. Try again.";
}

// S02: log in with an emailed code. No password is ever asked for.
export default function Login() {
  const data = useData();
  const [step, setStep] = useState<"email" | "code">("email");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendCode = async () => {
    setBusy(true);
    setError(null);
    try {
      await data.signInWithEmail(email.trim());
      setStep("code");
    } catch (e) {
      setError(messageOf(e));
    } finally {
      setBusy(false);
    }
  };

  const verify = async () => {
    setBusy(true);
    setError(null);
    try {
      await data.verifyCode(email.trim(), code.trim());
      router.replace("/(tabs)");
    } catch (e) {
      setError(messageOf(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} className="flex-1 bg-bg px-6 justify-center">
      <Text accessibilityRole="header" className="text-xl font-sans-bold text-text">
        Log in to DSK 7
      </Text>
      <Text className="mt-2 text-base text-text-muted">We'll email you a 6-digit code. No password needed.</Text>

      {step === "email" ? (
        <View className="mt-8" style={{ gap: 16 }}>
          <Text nativeID="email-label" className="text-sm font-sans-medium text-text">
            Email
          </Text>
          <TextInput
            accessibilityLabelledBy="email-label"
            value={email}
            onChangeText={setEmail}
            placeholder="you@example.com"
            placeholderTextColor={colors.textMuted}
            autoCapitalize="none"
            autoComplete="email"
            keyboardType="email-address"
            textContentType="emailAddress"
            returnKeyType="send"
            onSubmitEditing={() => email.includes("@") && sendCode()}
            className="h-12 rounded-md border border-border-input bg-surface-raised px-4 text-base text-text"
          />
          {error ? <Text accessibilityLiveRegion="polite" className="text-sm text-danger">{error}</Text> : null}
          <Button label="Send code" onPress={sendCode} loading={busy} disabled={!email.includes("@")} />
        </View>
      ) : (
        <View className="mt-8" style={{ gap: 16 }}>
          <Text className="text-base text-text">Enter the code we sent to {email.trim()}.</Text>
          <TextInput
            accessibilityLabel="6-digit code"
            value={code}
            onChangeText={(v) => setCode(v.replace(/\D/g, "").slice(0, 6))}
            placeholder="123456"
            placeholderTextColor={colors.textMuted}
            keyboardType="number-pad"
            autoComplete="one-time-code"
            textContentType="oneTimeCode"
            returnKeyType="done"
            onSubmitEditing={() => code.length === 6 && verify()}
            className="h-12 rounded-md border border-border-input bg-surface-raised px-4 text-lg text-text tracking-widest"
          />
          {error ? <Text accessibilityLiveRegion="polite" className="text-sm text-danger">{error}</Text> : null}
          <Button label="Log in" onPress={verify} loading={busy} disabled={code.length !== 6} />
          <Button
            label="Use a different email"
            variant="ghost"
            onPress={() => {
              setStep("email");
              setCode("");
              setError(null);
            }}
          />
          {__DEV__ ? <Text className="text-xs text-text-muted">Dev build: the code is 123456.</Text> : null}
        </View>
      )}
    </KeyboardAvoidingView>
  );
}
