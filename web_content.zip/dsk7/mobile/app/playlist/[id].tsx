import { useEffect, useState } from "react";
import { FlatList, Text, View } from "react-native";
import { useLocalSearchParams, Stack } from "expo-router";
import { ListMusic, Shuffle, Play } from "lucide-react-native";
import type { PlaylistWithSongs } from "../../src/core/types";
import { useData } from "../../src/data/DataProvider";
import { DataError } from "../../src/data/dataLayer";
import { usePlayer } from "../../src/player/PlayerProvider";
import { CoverArt } from "../../src/components/CoverArt";
import { SongRow } from "../../src/components/SongRow";
import { EmptyState } from "../../src/components/EmptyState";
import { Button } from "../../src/components/Button";
import { SongRowSkeleton, Skeleton } from "../../src/components/Skeleton";
import { layout } from "../../src/theme/tokens.generated";

type State =
  | { kind: "loading" }
  | { kind: "missing" }
  | { kind: "error"; message: string }
  | { kind: "ready"; playlist: PlaylistWithSongs };

// S09: playlist detail. Header with play and shuffle, then the songs.
export default function PlaylistScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const data = useData();
  const { controller, currentSongId, status } = usePlayer();
  const [state, setState] = useState<State>({ kind: "loading" });

  const load = () => {
    setState({ kind: "loading" });
    data
      .getPlaylist(id)
      .then((p) => setState(p ? { kind: "ready", playlist: p } : { kind: "missing" }))
      .catch((e: unknown) => {
        if (e instanceof DataError && e.code === "not_found") setState({ kind: "missing" });
        else setState({ kind: "error", message: e instanceof Error ? e.message : "Something went wrong." });
      });
  };

  useEffect(() => {
    load();
    // load depends on id only; data is stable for the life of the app.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (state.kind === "loading") {
    return (
      <View className="flex-1 bg-bg">
        <Stack.Screen options={{ title: "" }} />
        <View className="items-center py-6" style={{ gap: 16 }}>
          <Skeleton width={200} height={200} />
          <Skeleton width={160} height={20} />
        </View>
        <SongRowSkeleton />
        <SongRowSkeleton />
      </View>
    );
  }

  if (state.kind === "missing") {
    return (
      <View className="flex-1 bg-bg">
        <Stack.Screen options={{ title: "Playlist" }} />
        <EmptyState icon={ListMusic} title="This playlist isn't available" body="It may have been removed or made private." />
      </View>
    );
  }

  if (state.kind === "error") {
    return (
      <View className="flex-1 bg-bg">
        <Stack.Screen options={{ title: "Playlist" }} />
        <EmptyState icon={ListMusic} title="Couldn't load this playlist" body={state.message} action={{ label: "Try again", onPress: load }} />
      </View>
    );
  }

  const { playlist } = state;
  const ids = playlist.songs.map((s) => s.id);
  const playAll = (shuffle: boolean) => {
    void controller.playQueue(ids, 0).then(() => {
      if (shuffle) controller.toggleShuffle();
    });
  };

  return (
    <View className="flex-1 bg-bg">
      <Stack.Screen options={{ title: playlist.title }} />
      <FlatList
        data={playlist.songs}
        keyExtractor={(s) => s.id}
        ListHeaderComponent={
          <View className="items-center px-4 pb-6 pt-2" style={{ gap: 12 }}>
            <CoverArt id={playlist.id} title={playlist.title} uri={playlist.cover_url} size={200} />
            <Text accessibilityRole="header" className="text-xl font-sans-bold text-text text-center">
              {playlist.title}
            </Text>
            {playlist.description ? (
              <Text className="text-sm text-text-muted text-center">{playlist.description}</Text>
            ) : null}
            <Text className="text-xs text-text-muted">{playlist.songs.length} songs</Text>
            {playlist.songs.length > 0 ? (
              <View className="flex-row" style={{ gap: 12 }}>
                <Button label="Play" icon={Play} onPress={() => playAll(false)} />
                <Button label="Shuffle" variant="secondary" icon={Shuffle} onPress={() => playAll(true)} />
              </View>
            ) : null}
          </View>
        }
        ListEmptyComponent={
          <EmptyState icon={ListMusic} title="No songs yet" body="Songs you add will show up here." />
        }
        renderItem={({ item, index }) => (
          <SongRow
            song={item}
            playing={item.id === currentSongId && status === "playing"}
            onPress={() => void controller.playQueue(ids, index)}
          />
        )}
        contentContainerStyle={{ paddingBottom: layout["mini-player-height"] + 16 }}
      />
    </View>
  );
}
