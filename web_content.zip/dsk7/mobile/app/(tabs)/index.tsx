import { useCallback, useEffect, useState } from "react";
import { FlatList, ScrollView, Text, View } from "react-native";
import { router } from "expo-router";
import { ListMusic, AlertTriangle } from "lucide-react-native";
import type { HomeSection } from "../../src/core/types";
import { useData } from "../../src/data/DataProvider";
import { usePlayer } from "../../src/player/PlayerProvider";
import { ContentCard } from "../../src/components/ContentCard";
import { SongRow } from "../../src/components/SongRow";
import { EmptyState } from "../../src/components/EmptyState";
import { SongRowSkeleton, Skeleton } from "../../src/components/Skeleton";

type State =
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "ready"; sections: HomeSection[] };

// S03: home. Curated rows, each one a horizontal shelf of playlists, or a list of songs.
export default function Home() {
  const data = useData();
  const { controller, currentSongId, status } = usePlayer();
  const [state, setState] = useState<State>({ kind: "loading" });

  const load = useCallback(() => {
    setState({ kind: "loading" });
    data
      .getHome([])
      .then((sections) => setState({ kind: "ready", sections }))
      .catch((e: Error) => setState({ kind: "error", message: e.message }));
  }, [data]);

  useEffect(() => {
    load();
  }, [load]);

  if (state.kind === "loading") {
    return (
      <View className="flex-1 bg-bg pt-16">
        <View className="px-4" style={{ gap: 16 }}>
          <Skeleton width={180} height={24} />
          <View className="flex-row" style={{ gap: 12 }}>
            <Skeleton width={140} height={140} />
            <Skeleton width={140} height={140} />
          </View>
        </View>
        <SongRowSkeleton />
        <SongRowSkeleton />
      </View>
    );
  }

  if (state.kind === "error") {
    return (
      <View className="flex-1 bg-bg">
        <EmptyState
          icon={AlertTriangle}
          title="Couldn't load your home"
          body={state.message}
          action={{ label: "Try again", onPress: load }}
        />
      </View>
    );
  }

  if (state.sections.length === 0) {
    return (
      <View className="flex-1 bg-bg">
        <EmptyState icon={ListMusic} title="Nothing here yet" body="New music will show up here soon." />
      </View>
    );
  }

  return (
    <ScrollView className="flex-1 bg-bg" contentContainerStyle={{ paddingTop: 64, paddingBottom: 24 }}>
      <Text accessibilityRole="header" className="px-4 mb-6 text-xl font-sans-bold text-text">
        Home
      </Text>
      {state.sections.map((section) => (
        <View key={section.id} className="mb-8">
          <Text accessibilityRole="header" className="px-4 mb-3 text-lg font-sans-semibold text-text">
            {section.title}
          </Text>
          {section.kind === "playlists" ? (
            <FlatList
              horizontal
              data={section.items}
              keyExtractor={(p) => p.id}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16, gap: 12 }}
              renderItem={({ item }) => (
                <ContentCard
                  id={item.id}
                  title={item.title}
                  subtitle={`${item.song_count} songs`}
                  uri={item.cover_url}
                  onPress={() => router.push(`/playlist/${item.id}`)}
                />
              )}
            />
          ) : (
            section.items.map((song, index) => (
              <SongRow
                key={song.id}
                song={song}
                playing={song.id === currentSongId && status === "playing"}
                onPress={() =>
                  void controller.playQueue(
                    section.items.map((s) => s.id),
                    index,
                  )
                }
              />
            ))
          )}
        </View>
      ))}
    </ScrollView>
  );
}
