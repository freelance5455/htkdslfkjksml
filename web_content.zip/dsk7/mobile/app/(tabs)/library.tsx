import { Library } from "lucide-react-native";
import { EmptyState } from "../../src/components/EmptyState";

// Stub. Library (likes, playlists, history) is milestone 2.
export default function LibraryStub() {
  return (
    <EmptyState
      icon={Library}
      title="Your library is coming next"
      body="Likes and playlists will show up here."
    />
  );
}
