import { useEffect } from "react";
import { View } from "react-native";
import { router, Tabs } from "expo-router";
import { BottomTabBar } from "@react-navigation/bottom-tabs";
import { House, Library, Search } from "lucide-react-native";
import { useData } from "../../src/data/DataProvider";
import { MiniPlayer } from "../../src/components/MiniPlayer";
import { colors } from "../../src/theme/tokens.generated";

// Logged-out users are sent to the login screen. The tabs are only shown once there is a session.
export default function TabsLayout() {
  const data = useData();
  useEffect(() => {
    data.getSession().then((profile) => {
      if (!profile) router.replace("/login");
    });
  }, [data]);

  return (
    <Tabs
      tabBar={(props) => (
        <View>
          <MiniPlayer />
          <BottomTabBar {...props} />
        </View>
      )}
      screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.textMuted,
      }}
    >
      <Tabs.Screen name="index" options={{ title: "Home", tabBarIcon: ({ color, size }) => <House color={color} size={size} /> }} />
      <Tabs.Screen name="search" options={{ title: "Search", tabBarIcon: ({ color, size }) => <Search color={color} size={size} /> }} />
      <Tabs.Screen name="library" options={{ title: "Library", tabBarIcon: ({ color, size }) => <Library color={color} size={size} /> }} />
    </Tabs>
  );
}
