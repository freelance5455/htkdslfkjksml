import { Search as SearchIcon } from "lucide-react-native";
import { EmptyState } from "../../src/components/EmptyState";

// Stub. Search is milestone 2 (features.csv: "Search songs / albums / artists / playlists").
export default function SearchStub() {
  return (
    <EmptyState
      icon={SearchIcon}
      title="Search is coming next"
      body="For now, use the Home tab to find music."
    />
  );
}
