"use strict";
/**
 * Sandrone Ai: сервер входа по SMS-коду (SMS.ru) и по почте.
 * Запуск: npm install && npm start
 */
const express = require("express");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");

const PORT = process.env.PORT || 3000;
const SMSRU_API_ID = process.env.SMSRU_API_ID || "";
const SESSION_SECRET = process.env.SESSION_SECRET || "";
const DEV_MODE = process.env.DEV_MODE === "1"; // код выводится в консоль, SMS не отправляется
const CODE_TTL_MS = 5 * 60 * 1000;
const RESEND_MS = 60 * 1000;
const MAX_ATTEMPTS = 5;
const SESSION_DAYS = 30;

if (!SESSION_SECRET) {
  console.error("Задайте SESSION_SECRET в файле .env");
  process.exit(1);
}
if (!SMSRU_API_ID && !DEV_MODE) {
  console.error("Задайте SMSRU_API_ID в файле .env (или включите DEV_MODE=1 для проверки без SMS)");
  process.exit(1);
}

const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "10kb" }));

/* ---------- простое хранилище в файле ---------- */
const DB_FILE = path.join(__dirname, "data", "users.json");
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
let users = {};
try { users = JSON.parse(fs.readFileSync(DB_FILE, "utf8")); } catch (e) { users = {}; }
function saveUsers() {
  const tmp = DB_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(users));
  fs.renameSync(tmp, DB_FILE);
}

/* ---------- утилиты ---------- */
const hash = (s) => crypto.createHash("sha256").update(s + SESSION_SECRET).digest("hex");
const rnd = (n) => crypto.randomBytes(n).toString("hex");

function normalizePhone(raw) {
  let d = String(raw || "").replace(/\D/g, "");
  if (d.length === 11 && d[0] === "8") d = "7" + d.slice(1);
  if (d.length === 10) d = "7" + d;
  if (d.length < 11 || d.length > 15) return null;
  return d;
}

/* ---------- ограничение частоты по IP ---------- */
const hits = new Map();
function limit(max, windowMs) {
  return (req, res, next) => {
    const key = req.ip + req.path;
    const now = Date.now();
    const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
    if (arr.length >= max) return res.status(429).json({ error: "Слишком много запросов. Подождите немного." });
    arr.push(now);
    hits.set(key, arr);
    next();
  };
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of hits) if (!v.some((t) => now - t < 3600000)) hits.delete(k);
}, 600000).unref();

/* ---------- коды и сессии ---------- */
const codes = new Map();    // phone -> { hash, exp, attempts, sentAt }
const sessions = new Map(); // token hash -> { userId, exp }
try {
  const s = JSON.parse(fs.readFileSync(path.join(__dirname, "data", "sessions.json"), "utf8"));
  for (const [k, v] of Object.entries(s)) if (v.exp > Date.now()) sessions.set(k, v);
} catch (e) {}
function saveSessions() {
  fs.writeFileSync(path.join(__dirname, "data", "sessions.json"), JSON.stringify(Object.fromEntries(sessions)));
}
function createSession(userId) {
  const token = rnd(32);
  sessions.set(hash(token), { userId, exp: Date.now() + SESSION_DAYS * 86400000 });
  saveSessions();
  return token;
}
function authed(req) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : "";
  const s = token && sessions.get(hash(token));
  if (!s || s.exp < Date.now()) return null;
  return { token, user: users[s.userId] };
}

/* ---------- отправка SMS через SMS.ru ---------- */
async function sendSms(phone, text) {
  if (DEV_MODE) {
    console.log(`[DEV] SMS на +${phone}: ${text}`);
    return;
  }
  const url = new URL("https://sms.ru/sms/send");
  url.searchParams.set("api_id", SMSRU_API_ID);
  url.searchParams.set("to", phone);
  url.searchParams.set("msg", text);
  url.searchParams.set("json", "1");
  const r = await fetch(url, { signal: AbortSignal.timeout(10000) });
  const j = await r.json();
  const item = j.sms && j.sms[phone];
  if (j.status !== "OK" || !item || item.status !== "OK") {
    console.error("SMS.ru ошибка:", JSON.stringify(j));
    const err = new Error("sms_failed");
    err.code = item ? item.status_code : j.status_code;
    throw err;
  }
}

/* ---------- API: SMS ---------- */
app.post("/api/sms/send", limit(10, 3600000), async (req, res) => {
  const phone = normalizePhone(req.body.phone);
  if (!phone) return res.status(400).json({ error: "Введите номер телефона полностью." });
  const prev = codes.get(phone);
  if (prev && Date.now() - prev.sentAt < RESEND_MS) {
    const wait = Math.ceil((RESEND_MS - (Date.now() - prev.sentAt)) / 1000);
    return res.status(429).json({ error: `Повторно код можно запросить через ${wait} сек.`, wait });
  }
  const code = String(crypto.randomInt(0, 10000)).padStart(4, "0");
  try {
    await sendSms(phone, `Sandrone Ai: код входа ${code}. Никому его не сообщайте.`);
  } catch (e) {
    const msg = e.code === 200 ? "Неверный ключ SMS.ru (api_id)."
      : e.code === 201 ? "На балансе SMS.ru не хватает средств."
      : e.code === 207 ? "На этот номер нельзя отправить SMS."
      : "Не удалось отправить SMS. Попробуйте позже.";
    return res.status(502).json({ error: msg });
  }
  codes.set(phone, { hash: hash(phone + code), exp: Date.now() + CODE_TTL_MS, attempts: 0, sentAt: Date.now() });
  res.json({ ok: true, resendIn: RESEND_MS / 1000 });
});

app.post("/api/sms/verify", limit(30, 3600000), (req, res) => {
  const phone = normalizePhone(req.body.phone);
  const code = String(req.body.code || "").trim();
  const rec = phone && codes.get(phone);
  if (!rec || rec.exp < Date.now()) return res.status(400).json({ error: "Код не найден или устарел. Запросите новый." });
  if (rec.attempts >= MAX_ATTEMPTS) { codes.delete(phone); return res.status(429).json({ error: "Слишком много попыток. Запросите новый код." }); }
  rec.attempts++;
  const a = Buffer.from(rec.hash), b = Buffer.from(hash(phone + code));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(400).json({ error: "Неверный код." });
  codes.delete(phone);
  const id = "p" + phone;
  const isNew = !users[id];
  if (isNew) users[id] = { id, phone: "+" + phone, createdAt: Date.now() };
  saveUsers();
  res.json({ token: createSession(id), user: { name: users[id].phone }, isNew });
});

/* ---------- API: почта и пароль ---------- */
function pwHash(pw, salt) { return crypto.scryptSync(pw, salt, 32).toString("hex"); }
app.post("/api/email/auth", limit(20, 3600000), (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const pw = String(req.body.password || "");
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || email.length > 120) return res.status(400).json({ error: "Проверьте адрес почты." });
  if (pw.length < 6 || pw.length > 100) return res.status(400).json({ error: "Пароль должен быть от 6 символов." });
  const id = "e" + hash(email).slice(0, 24);
  let u = users[id];
  if (!u) {
    const salt = rnd(16);
    u = users[id] = { id, email, salt, pw: pwHash(pw, salt), createdAt: Date.now() };
    saveUsers();
    return res.json({ token: createSession(id), user: { name: email }, isNew: true });
  }
  const ok = crypto.timingSafeEqual(Buffer.from(u.pw), Buffer.from(pwHash(pw, u.salt)));
  if (!ok) return res.status(401).json({ error: "Неверный пароль." });
  res.json({ token: createSession(id), user: { name: email }, isNew: false });
});

/* ---------- API: сессия ---------- */
app.get("/api/me", (req, res) => {
  const a = authed(req);
  if (!a || !a.user) return res.status(401).json({ error: "Не авторизован" });
  res.json({ user: { name: a.user.phone || a.user.email } });
});
app.post("/api/logout", (req, res) => {
  const a = authed(req);
  if (a) { sessions.delete(hash(a.token)); saveSessions(); }
  res.json({ ok: true });
});

/* ---------- ВК, Telegram, Max: нужны отдельные ключи ---------- */
app.all("/api/oauth/:provider", (req, res) => {
  res.status(501).json({ error: "Этот способ входа пока не подключён. Войдите по SMS или почте." });
});

app.get("/health", (req, res) => res.json({ ok: true }));

/* ---------- статика ---------- */
app.use(express.static(path.join(__dirname, "public"), {
  setHeaders(res, p) { if (p.endsWith("sw.js")) res.setHeader("Cache-Control", "no-cache"); }
}));

app.listen(PORT, () => console.log(`Sandrone Ai запущен: http://localhost:${PORT}${DEV_MODE ? " (DEV_MODE)" : ""}`));
