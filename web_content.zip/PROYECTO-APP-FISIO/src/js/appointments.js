const AppointmentsController = {
    init: function() {
        this.cacheDOM();
        this.bindEvents();
        this.renderList();
        this.loadPatientsDropdown();
    },

    cacheDOM: function() {
        this.listContainer = document.getElementById('appointments-list');
        this.modal = document.getElementById('modal-appointment');
        this.form = document.getElementById('form-appointment');
        this.btnShowForm = document.getElementById('btn-show-appointment-form');
        this.btnCancel = document.getElementById('btn-cancel-appointment');
        this.linkNewPatient = document.getElementById('link-new-patient');
        
        this.inputId = document.getElementById('appointment-id');
        this.inputPatient = document.getElementById('appt-patient');
        this.inputReason = document.getElementById('appt-reason');
        this.inputDate = document.getElementById('appt-date');
        this.inputTime = document.getElementById('appt-time');
        this.inputDuration = document.getElementById('appt-duration');
        this.inputPrice = document.getElementById('appt-price');
        this.inputStatus = document.getElementById('appt-status');
        this.modalTitle = document.getElementById('modal-appointment-title');
        
        this.inputSearch = document.getElementById('search-appointment');
        this.selectFilter = document.getElementById('filter-status-appointment');
    },

    bindEvents: function() {
        this.btnShowForm.addEventListener('click', () => this.openModal());
        this.btnCancel.addEventListener('click', () => this.closeModal());
        this.form.addEventListener('submit', (e) => this.saveAppointment(e));
        
        this.inputSearch.addEventListener('input', () => this.renderList());
        this.selectFilter.addEventListener('change', () => this.renderList());

        this.linkNewPatient.addEventListener('click', (e) => {
            e.preventDefault();
            PatientsController.openModal(); 
        });

        document.addEventListener('pacienteGuardado', (e) => {
            this.loadPatientsDropdown();
            this.inputPatient.value = e.detail.id; 
        });
    },

    loadPatientsDropdown: function() {
        let pacientes = StorageManager.getData('pacientes');
        this.inputPatient.innerHTML = '<option value="">Seleccione un paciente</option>';
        pacientes.forEach(p => {
            const option = document.createElement('option');
            option.value = p.id;
            option.textContent = p.nombre;
            this.inputPatient.appendChild(option);
        });
    },

    openModal: function(appointment = null) {
        this.loadPatientsDropdown(); 
        if (appointment) {
            this.modalTitle.textContent = 'Editar Cita';
            this.inputId.value = appointment.id;
            this.inputPatient.value = appointment.pacienteId;
            this.inputReason.value = appointment.motivo;
            this.inputDate.value = appointment.fecha;
            this.inputTime.value = appointment.hora;
            this.inputDuration.value = appointment.duracion || '';
            this.inputPrice.value = appointment.precio || '';
            this.inputStatus.value = appointment.estado;
        } else {
            this.modalTitle.textContent = 'Nueva Cita';
            this.form.reset();
            this.inputId.value = '';
            this.inputStatus.value = 'Pendiente';
        }
        this.modal.style.display = 'flex';
    },

    closeModal: function() {
        this.modal.style.display = 'none';
        this.form.reset();
    },

    timeToMinutes: function(timeStr) {
        const partes = timeStr.split(':');
        return parseInt(partes[0]) * 60 + parseInt(partes[1]);
    },

    saveAppointment: function(e) {
        e.preventDefault(); 
        
        const pacienteId = this.inputPatient.value;
        const motivo = this.inputReason.value.trim();
        const fecha = this.inputDate.value;
        const hora = this.inputTime.value;
        const duracion = this.inputDuration.value;
        const precio = this.inputPrice.value;
        const estado = this.inputStatus.value;
        const id = this.inputId.value || Date.now().toString(); 

        if (pacienteId === "") {
            alert("Por favor, seleccione un paciente.");
            return;
        }

        if (motivo === "" || motivo.length > 35) {
            alert("El motivo es obligatorio y no puede superar los 35 caracteres.");
            return;
        }

        const fechaMinima = new Date('2026-10-15T00:00:00');
        const fechaIngresada = new Date(fecha + 'T00:00:00'); 
        if (fechaIngresada < fechaMinima) {
            alert("No se pueden asignar citas en fechas anteriores al 15 de Octubre de 2026.");
            return;
        }

        if (duracion !== "" && (parseInt(duracion) < 1 || parseInt(duracion) > 60)) {
            alert("La duración no puede superar los 60 minutos.");
            return;
        }

        let citas = StorageManager.getData('citas');

        const nuevaDuracionNum = parseInt(duracion) || 1; 
        const nuevoInicio = this.timeToMinutes(hora);
        const nuevoFin = nuevoInicio + nuevaDuracionNum;

        const citaConflictiva = citas.find(c => {
            if (c.id === id) return false; 
            if (c.estado === 'Cancelada') return false; 
            if (c.fecha !== fecha) return false; 

            const duracionExistente = parseInt(c.duracion) || 1;
            const inicioExistente = this.timeToMinutes(c.hora);
            const finExistente = inicioExistente + duracionExistente;

            return (nuevoInicio < finExistente && nuevoFin > inicioExistente);
        });

        if (citaConflictiva) {
            const pacientes = StorageManager.getData('pacientes');
            const pacienteConflicto = pacientes.find(p => p.id === citaConflictiva.pacienteId);
            const nombrePaciente = pacienteConflicto ? pacienteConflicto.nombre : 'Desconocido';
            
            alert(`Ya hay una cita asignada en esta hora al Paciente: ${nombrePaciente}`);
            return; 
        }

        const citaData = { id, pacienteId, motivo, fecha, hora, duracion, precio, estado };

        if (this.inputId.value) {
            citas = citas.map(c => c.id === id ? citaData : c);
        } else {
            citas.push(citaData);
        }

        citas.sort((a, b) => {
            let dateA = new Date(a.fecha + 'T' + a.hora);
            let dateB = new Date(b.fecha + 'T' + b.hora);
            return dateA - dateB;
        });

        StorageManager.saveData('citas', citas);
        this.closeModal();
        this.renderList();
    },

    deleteAppointment: function(id) {
        if (confirm('¿Estás seguro de eliminar esta cita?')) {
            let citas = StorageManager.getData('citas');
            citas = citas.filter(c => c.id !== id);
            StorageManager.saveData('citas', citas);
            this.renderList();
        }
    },

    formatDateEsp: function(dateStr) {
        if(!dateStr) return '';
        const partes = dateStr.split('-');
        const meses = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
        const dia = partes[2];
        const mes = meses[parseInt(partes[1]) - 1];
        const anio = partes[0];
        return `${dia} de ${mes} de ${anio}`;
    },

    formatCurrency: function(amount) {
        if (!amount) return '';
        return '$' + parseInt(amount).toLocaleString('es-CO');
    },

    // NUEVO: Función para convertir hora militar a formato AM/PM
    formatTimeAMPM: function(timeStr) {
        if (!timeStr) return '';
        let partes = timeStr.split(':');
        let horas = parseInt(partes[0]);
        let minutos = partes[1];
        let ampm = horas >= 12 ? 'PM' : 'AM';
        
        horas = horas % 12;
        horas = horas ? horas : 12; // Si la hora es 0 (medianoche), mostrar 12
        
        return `${horas}:${minutos} ${ampm}`;
    },

    autoUpdatePastAppointments: function() {
        let citas = StorageManager.getData('citas');
        let huboCambios = false;
        const ahora = new Date();

        const citasActualizadas = citas.map(c => {
            if (c.estado === 'Pendiente') {
                const fechaHoraCita = new Date(`${c.fecha}T${c.hora}:00`);
                if (ahora >= fechaHoraCita) {
                    c.estado = 'Realizada';
                    huboCambios = true;
                }
            }
            return c;
        });

        if (huboCambios) {
            StorageManager.saveData('citas', citasActualizadas);
        }
        return citasActualizadas;
    },

    sendWhatsApp: function(id) {
        const citas = StorageManager.getData('citas');
        const pacientes = StorageManager.getData('pacientes');
        
        const cita = citas.find(c => c.id === id);
        if (!cita) return;
        
        const paciente = pacientes.find(p => p.id === cita.pacienteId);
        if (!paciente) return;

        const celular = "57" + paciente.celular; 
        const fechaEsp = this.formatDateEsp(cita.fecha);
        const horaFormateada = this.formatTimeAMPM(cita.hora); // Aplicamos la conversión aquí
        
        const mensaje = `Hola ${paciente.nombre}, te recordamos tu cita de fisioterapia programada para el ${fechaEsp} a las ${horaFormateada}. Motivo: ${cita.motivo}. ¡Te esperamos!`;
        
        //const url = `https://wa.me/${celular}?text=${encodeURIComponent(mensaje)}`;
        //La siguiente línea es la solución al envío de mensajes en whatsapp 17:58 04 de Noviembre
        const url = "https://api.whatsapp.com/send?phone=" + celular + "&text=" + mensaje;
        
        window.open(url, '_blank');
    },

    renderList: function() {
        let citas = this.autoUpdatePastAppointments();
        let pacientes = StorageManager.getData('pacientes');
        
        this.listContainer.innerHTML = ''; 

        const textoBusqueda = this.inputSearch.value.toLowerCase().trim();
        const filtroEstado = this.selectFilter.value;

        citas = citas.filter(cita => {
            const paciente = pacientes.find(p => p.id === cita.pacienteId) || { nombre: 'Desconocido' };
            const cumpleEstado = (filtroEstado === 'Todas') || (cita.estado === filtroEstado);
            const cumpleBusqueda = (textoBusqueda === '') || 
                                   paciente.nombre.toLowerCase().includes(textoBusqueda) ||
                                   cita.motivo.toLowerCase().includes(textoBusqueda) ||
                                   this.formatDateEsp(cita.fecha).toLowerCase().includes(textoBusqueda);
            
            return cumpleEstado && cumpleBusqueda;
        });

        if (citas.length === 0) {
            this.listContainer.innerHTML = `<p style="text-align:center; color:#888; margin-top:20px;">No se encontraron citas.</p>`;
            return;
        }

        const ahora = new Date();

        citas.forEach(cita => {
            const paciente = pacientes.find(p => p.id === cita.pacienteId) || { nombre: 'Paciente Eliminado' };
            
            let detallesHTML = `📅 ${this.formatDateEsp(cita.fecha)} &nbsp; 🕒 ${cita.hora}`; 
            if (cita.duracion) detallesHTML += ` &nbsp; ⏱️ ${cita.duracion} min`;
            if (cita.precio) detallesHTML += ` &nbsp; 💰 ${this.formatCurrency(cita.precio)}`;

            const badgeClass = `badge badge-${cita.estado.toLowerCase()}`;
            
            let badgeRecordatorio = '';
            let waButton = '';

            if (cita.estado === 'Pendiente') {
                const fechaHoraCita = new Date(`${cita.fecha}T${cita.hora}:00`);
                const diffMs = fechaHoraCita - ahora;
                const diffHoras = diffMs / (1000 * 60 * 60);

                waButton = `<button class="btn-whatsapp" onclick="AppointmentsController.sendWhatsApp('${cita.id}')" title="Enviar recordatorio por WhatsApp">💬</button>`;

                if (diffHoras > 0 && diffHoras <= 24) {
                    badgeRecordatorio = `<span class="badge badge-warning" style="margin-left: 10px;">¡Recordar hoy!</span>`;
                }
            }

            const li = document.createElement('li');
            li.className = 'data-item';
            li.innerHTML = `
                <div class="data-item-info">
                    <h4>${paciente.nombre}</h4>
                    <p class="subtitle">${cita.motivo}</p>
                    <div class="details">${detallesHTML} ${badgeRecordatorio}</div>
                </div>
                <div class="data-item-actions">
                    <span class="${badgeClass}">${cita.estado}</span>
                    <div class="action-buttons">
                        ${waButton}
                        <button class="btn-edit" onclick="AppointmentsController.openModal({
                            id: '${cita.id}', pacienteId: '${cita.pacienteId}', motivo: '${cita.motivo}', 
                            fecha: '${cita.fecha}', hora: '${cita.hora}', duracion: '${cita.duracion || ''}', 
                            precio: '${cita.precio || ''}', estado: '${cita.estado}'
                        })">✏️</button>
                        <button class="btn-delete" onclick="AppointmentsController.deleteAppointment('${cita.id}')">🗑️</button>
                    </div>
                </div>
            `;
            this.listContainer.appendChild(li);
        });
    }
};

document.addEventListener('DOMContentLoaded', () => {
    AppointmentsController.init();
});
