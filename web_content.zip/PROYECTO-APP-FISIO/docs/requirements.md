
# Requisitos del Proyecto: WebAppFisio

## 1. Visión del Producto
Aplicación web diseñada para móviles, orientada a la gestión autónoma, local y offline de pacientes y sus respectivas citas de fisioterapia[cite: 1].

## 2. Requisitos Funcionales
### 2.1 Módulo de Pacientes (CRUD)
- Crear, Leer, Actualizar y Eliminar registros de pacientes[cite: 1].
- **Campos obligatorios:** Nombre completo, Número de Celular[cite: 1].
- **Búsqueda:** Permitir localizar pacientes introduciendo fragmentos de su nombre o número de celular.

### 2.2 Módulo de Citas (CRUD)
- Crear, Leer, Actualizar y Eliminar citas vinculadas a un paciente[cite: 1].
- **Campos:** Paciente, Fecha, Hora, Motivo, Estado de Pago, Método de Pago[cite: 1].

## 3. Reglas de Negocio
- **RN01 - Restricción de Fecha:** El sistema no permitirá agendar citas en fechas anteriores al 15 de Octubre de 2026. Los días previos estarán bloqueados en el calendario y se mostrará advertencia visual si se ingresan manualmente[cite: 1].
- **RN02 - Formato de Hora:** La asignación de hora debe manejar formato AM/PM e incluir selección específica de minutos[cite: 1].
- **RN03 - Prevención de Cruces:** El sistema bloqueará la creación de una cita si ya existe otra agendada exactamente en la misma fecha y hora.
- **RN04 - Límite de Motivo:** El campo "Motivo de la cita" tendrá una longitud máxima estricta de 35 caracteres[cite: 1].
- **RN05 - Lógica de Pago:** El campo "Pagada" es de tipo Sí/No. Si se marca "Sí", el sistema obligará a seleccionar el método: "Nequi" o "Efectivo"[cite: 1].

## 4. Exportación de Datos
- Planeada para futuras versiones (Fuera del alcance de la V1).
