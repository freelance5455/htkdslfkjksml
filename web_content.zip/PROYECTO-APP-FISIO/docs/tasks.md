# Lista de Tareas: WebAppFisio

- [ ] **T001:** Inicializar repositorio Git y crear estructura de carpetas `docs` y `src`[cite: 1]. *(EN DESARROLLO)*
- [ ] **T002:** Crear archivos base en `src/` (`index.html`, `css/styles.css`, `js/app.js`, `js/storage.js`, `js/patients.js`, `js/appointments.js`)[cite: 1].
- [ ] **T003:** Diseñar maquetación HTML/CSS del Dashboard mobile (navegación inferior y contenedores principales).
- [ ] **T004:** Implementar el controlador `storage.js` para leer y escribir en `localStorage` del celular.
- [ ] **T005:** Implementar Interfaz y Lógica (CRUD) para la gestión de Pacientes.
- [ ] **T006:** Implementar la barra de búsqueda de pacientes (por nombre o celular).
- [ ] **T007:** Implementar Interfaz y Lógica (CRUD) para la gestión de Citas (incluyendo validaciones de Fecha >= 15-Oct-2026, hora, y motivo <= 35 caracteres)[cite: 1].
- [ ] **T008:** Implementar lógica condicional del formulario de pagos (Nequi/Efectivo) y validación para evitar cruce de horarios[cite: 1].
