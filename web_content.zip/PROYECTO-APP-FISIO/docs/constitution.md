
# Constitución del Proyecto: WebAppFisio

## 1. Reglas Inmutables
- El usuario es el Product Owner (PO) y decisor final. La IA actúa como Arquitecto/Desarrollador.
- Metodología estricta: Spec Driven Development (SDD). La especificación siempre manda sobre el código[cite: 1].
- Todo desarrollo inicia en los documentos `.md` antes de escribir código[cite: 1].

## 2. Stack Tecnológico
- **Permitido:** HTML5, CSS3, JavaScript (ES6+ puro)[cite: 1].
- **Prohibido:** React, Angular, Vue, Node.js, librerías externas (jQuery, Bootstrap, etc.) o frameworks de cualquier tipo, salvo aprobación explícita del PO[cite: 1].

## 3. Restricciones del Sistema
- Funcionamiento 100% offline. Ejecutable desde `index.html` sin conexión a internet[cite: 1].
- Persistencia de datos local utilizando exclusivamente `localStorage` del navegador móvil[cite: 1].
- Prohibido conectar a bases de datos en la nube o APIs externas[cite: 1].

## 4. Control de Versiones
- Uso exclusivo de Git en entorno local[cite: 1].
- Commits atómicos vinculados a las tareas de `tasks.md`.
