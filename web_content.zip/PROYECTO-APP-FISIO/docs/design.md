
# Diseño y Arquitectura: WebAppFisio

## 1. Arquitectura
- **Tipo:** Monolito Front-end[cite: 1].
- **Patrón:** Modelo-Vista-Controlador (MVC) adaptado para JavaScript puro.
  - *Modelo:* Gestión de `localStorage`.
  - *Vista:* Archivos HTML y manipulación del DOM (CSS para estilos).
  - *Controlador:* Funciones JS que conectan eventos de la UI con los datos.

## 2. Interfaz de Usuario (UI)
- **Estilo:** Mobile-First. Diseño táctil con botones amplios.
- **Paleta de colores:** Tonos médicos (azules corporativos, blancos limpios para fondos, alertas rojas suaves para errores).
- **Flujo:** Pantalla de Inicio (Dashboard) con menú de navegación inferior táctil para alternar entre los módulos "Pacientes" y "Citas". Modales o paneles superpuestos para los formularios de creación/edición.

## 3. Estructura de Datos (localStorage)
La base de datos en memoria celular se dividirá en dos colecciones en formato JSON:
- `pacientes`: `[{ id, nombre, celular }]`
- `citas`: `[{ id, idPaciente, fecha, hora, motivo, pagada, metodoPago }]`
