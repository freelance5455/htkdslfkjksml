const CATS = {
 vocabulary:{name:"لغات روزانه",icon:"🔤"}, reading:{name:"روخوانی",icon:"📖"},
 grammar:{name:"گرامر",icon:"🧩"}, conversation:{name:"مکالمه",icon:"💬"},
 listening:{name:"شنیداری",icon:"🎧"}, notes:{name:"یادداشت‌ها",icon:"📝"}
};
const $ = id => document.getElementById(id);
const KEY = "hamidBookLessons_v1";
let lessons = load(), filter = "all", favoritesOnly = false, viewedId = null;
function load(){try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch(e){return []}}
function save(){localStorage.setItem(KEY,JSON.stringify(lessons));render()}
function today(){return new Date().toISOString().slice(0,10)}
function faNum(n){return String(n).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[d])}
function dateLabel(d){if(!d)return "";try{return new Date(d+"T12:00:00").toLocaleDateString("fa-IR")}catch(e){return d}}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function renderCategories(){
  const root=$("categories");root.innerHTML="";
  Object.entries(CATS).forEach(([id,c])=>{
    const count=lessons.filter(x=>x.category===id).length;
    const b=document.createElement("button");b.className="category"+(filter===id?" selected":"");
    b.innerHTML=`<span class="emoji">${c.icon}</span><b>${c.name}</b><small>${faNum(count)} درس</small>`;
    b.onclick=()=>{filter=filter===id?"all":id;favoritesOnly=false;render()};root.appendChild(b);
  });
}
function render(){
  renderCategories();
  const q=$("searchInput").value.trim().toLocaleLowerCase();
  let list=lessons.filter(x=>(filter==="all"||x.category===filter)&&(!favoritesOnly||x.favorite)&&(!q||[x.title,x.content,x.notes,CATS[x.category]?.name].join(" ").toLocaleLowerCase().includes(q)));
  list.sort((a,b)=>(b.updated||b.created).localeCompare(a.updated||a.created));
  $("totalCount").textContent=faNum(lessons.length);$("favoriteCount").textContent=faNum(lessons.filter(x=>x.favorite).length);
  $("listTitle").textContent=favoritesOnly?"علاقه‌مندی‌ها":filter==="all"?"همه درس‌ها":CATS[filter].name;
  $("resultCount").textContent=faNum(list.length)+" درس";
  const root=$("lessonList");root.innerHTML="";
  list.forEach(x=>{
    const c=CATS[x.category]||CATS.notes;
    const card=document.createElement("div");card.className="lesson-card";
    const excerpt=(x.content||"").replace(/\s+/g," ").slice(0,85);
    card.innerHTML=`<div class="lesson-icon">${c.icon}</div><div class="lesson-info"><h4></h4><p></p><div class="lesson-date">${dateLabel(x.date||x.created.slice(0,10))} · ${c.name}</div></div><div class="card-actions"><button class="mini-btn ${x.favorite?"fav":""}" title="علاقه‌مندی">${x.favorite?"♥":"♡"}</button><button class="mini-btn" title="ویرایش">✎</button><button class="mini-btn" title="حذف">⌫</button></div>`;
    card.querySelector("h4").textContent=x.title;card.querySelector("p").textContent=excerpt;
    card.querySelector(".lesson-info").onclick=()=>openView(x.id);
    const buttons=card.querySelectorAll(".mini-btn");
    buttons[0].onclick=()=>{x.favorite=!x.favorite;save()};
    buttons[1].onclick=()=>openEditor(x);
    buttons[2].onclick=()=>{if(confirm("این درس حذف شود؟")){lessons=lessons.filter(y=>y.id!==x.id);save();toast("درس حذف شد")}};
    root.appendChild(card);
  });
  $("emptyState").classList.toggle("show",list.length===0);
}
function openEditor(x=null){
  $("lessonForm").reset();$("lessonId").value=x?.id||"";$("dialogTitle").textContent=x?"ویرایش درس":"افزودن درس جدید";
  $("lessonTitle").value=x?.title||"";$("lessonCategory").value=x?.category|| (filter!=="all"?filter:"vocabulary");
  $("lessonDate").value=x?.date||today();$("lessonContent").value=x?.content||"";$("lessonNotes").value=x?.notes||"";
  $("lessonDialog").showModal();
}
function openView(id){
  const x=lessons.find(y=>y.id===id);if(!x)return;viewedId=id;
  $("viewCategory").textContent=CATS[x.category]?.name||"درس";$("viewTitle").textContent=x.title;
  $("viewDate").textContent=dateLabel(x.date||x.created.slice(0,10));
  $("viewContent").textContent=x.content;$("viewNotes").textContent=x.notes? "یادداشت: "+x.notes:"";
  $("viewDialog").showModal();
}
$("lessonForm").addEventListener("submit",e=>{
  e.preventDefault();const id=$("lessonId").value,old=lessons.find(x=>x.id===id);
  const item={id:id||crypto.randomUUID(),title:$("lessonTitle").value.trim(),category:$("lessonCategory").value,date:$("lessonDate").value,content:$("lessonContent").value.trim(),notes:$("lessonNotes").value.trim(),favorite:old?.favorite||false,created:old?.created||new Date().toISOString(),updated:new Date().toISOString()};
  if(!item.title||!item.content){toast("عنوان و متن درس را وارد کن");return}
  if(old)lessons=lessons.map(x=>x.id===id?item:x);else lessons.push(item);
  $("lessonDialog").close();save();toast(old?"درس ویرایش شد":"درس ذخیره شد");
});
$("addBtn").onclick=$("emptyAddBtn").onclick=()=>openEditor();
$("closeDialog").onclick=$("cancelDialog").onclick=()=>$("lessonDialog").close();
$("closeView").onclick=$("closeViewBottom").onclick=()=>$("viewDialog").close();
$("editViewed").onclick=()=>{const x=lessons.find(y=>y.id===viewedId);$("viewDialog").close();openEditor(x)};
$("searchInput").addEventListener("input",render);
$("clearSearch").onclick=()=>{$("searchInput").value="";render()};
$("allFilter").onclick=()=>{filter="all";favoritesOnly=false;render()};
$("homeNav").onclick=()=>{filter="all";favoritesOnly=false;$("searchInput").value="";setNav("homeNav");render()};
$("favoritesNav").onclick=()=>{favoritesOnly=true;filter="all";setNav("favoritesNav");render()};
$("backupBtn").onclick=$("backupNav").onclick=backupMenu;
function setNav(id){document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("active"));$(id).classList.add("active")}
function download(data,name,type){const blob=new Blob([data],{type}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)}
function backupMenu(){const choice=prompt("برای پشتیبان‌گیری عدد ۱ و برای بازیابی پشتیبان عدد ۲ را وارد کن.");if(choice==="1"){download(JSON.stringify({app:"Hamid Book",version:1,lessons},null,2),"hamid-book-backup.json","application/json");toast("فایل پشتیبان آماده شد")}else if(choice==="2")$("importFile").click()}
$("importFile").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const data=JSON.parse(await f.text());const incoming=Array.isArray(data)?data:data.lessons;if(!Array.isArray(incoming))throw Error();if(confirm("درس‌های فایل به درس‌های فعلی اضافه شوند؟ (موارد تکراری با شناسه یکسان جایگزین می‌شوند)")){const map=new Map(lessons.map(x=>[x.id,x]));incoming.forEach(x=>{if(x.id&&x.title&&x.content)map.set(x.id,x)});lessons=[...map.values()];save();toast("بازیابی انجام شد")}}catch(err){alert("فایل پشتیبان معتبر نیست.")}e.target.value=""};
if("serviceWorker" in navigator && location.protocol!=="file:"){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}))}
render();
