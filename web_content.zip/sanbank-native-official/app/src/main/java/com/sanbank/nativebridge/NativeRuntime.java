package com.sanbank.nativebridge;

/** Ponte nativa empacotada nas quatro ABIs; não armazena dados do usuário. */
public final class NativeRuntime {
    private static final boolean LOADED;
    static {
        System.loadLibrary("sanbanknative");
        LOADED = true;
    }

    private NativeRuntime() { }

    public static boolean isLoaded() {
        return LOADED;
    }
}
