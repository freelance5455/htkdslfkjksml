package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Tela própria para acompanhar a aprovação e a liquidação de uma operação. */
public abstract class OperationStatusActivity extends NativeModuleActivity {
    private final Handler operationHandler = new Handler(Looper.getMainLooper());
    private final Runnable operationPoller = this::pollOperation;
    private String operationId = "";
    private String operationKind = "";
    private JSONObject operationMetadata = new JSONObject();
    private JSONObject operationRecord;
    private TextView statusView;
    private TextView detailsView;
    private ProgressBar spinner;
    private Button receiptButton;
    private Button shareButton;
    private boolean requestInProgress;
    private boolean settlementInProgress;
    private boolean recipientCreditInProgress;
    private boolean finished;
    private LinearLayout actions;

    protected abstract String operationType();

    @Override protected void onModuleReady() {
        operationKind = operationType();
        operationId = getIntent() == null ? "" : getIntent().getStringExtra("operation_id");
        String metadata = getIntent() == null ? "" : getIntent().getStringExtra("operation_metadata");
        try { if (metadata != null && !metadata.isEmpty()) operationMetadata = new JSONObject(metadata); } catch (Exception ignored) { }
        showOperationScreen();
        pollOperation();
    }

    private void showOperationScreen() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(16), dp(14), dp(28));
        addDashboardStyleHeader(page);
        String title = "DEM".equals(operationKind) ? "Acompanhamento da Transferência DEM" : "PIX".equals(operationKind) ? "Acompanhamento do Pix via Neo" : "QR".equals(operationKind) ? "Acompanhamento do pagamento QR" : "BILL".equals(operationKind) ? "Acompanhamento do pagamento do boleto" : "INVOICE".equals(operationKind) ? "Acompanhamento do pagamento da fatura Neo" : "Acompanhamento do aumento de limite Neo";
        String subtitle = "LIMIT_INCREASE".equals(operationKind) ? "O novo limite só será aplicado depois da aprovação do gerente administrativo." : "A operação só será debitada e enviada ao destinatário depois da confirmação administrativa.";
        page.addView(text(title, 22, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 5));
        page.addView(text(subtitle, 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));

        LinearLayout card = stageCard("Status da operação");
        spinner = new ProgressBar(this, null, android.R.attr.progressBarStyleLarge);
        spinner.setIndeterminate(true);
        styleProgressBar(spinner);
        card.addView(spinner, new LinearLayout.LayoutParams(dp(52), dp(52)));
        statusView = text("Aguardando consulta...", 17, Color.rgb(125, 211, 252), true); statusView.setGravity(Gravity.CENTER); card.addView(statusView, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        detailsView = text("Nenhum valor foi debitado.", 13, MUTED, false); detailsView.setGravity(Gravity.CENTER); detailsView.setPadding(dp(10), dp(10), dp(10), dp(10)); detailsView.setBackground(rounded(Color.argb(218, 7, 39, 54), Color.argb(82, 45, 212, 191), 17)); card.addView(detailsView, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setVisibility(View.GONE);
        receiptButton = primaryButton("Abrir PDF"); receiptButton.setOnClickListener(v -> openOperationReceipt());
        shareButton = secondaryButton("Compartilhar PDF"); shareButton.setOnClickListener(v -> shareOperationReceipt());
        actions.addView(receiptButton, new LinearLayout.LayoutParams(0, dp(50), 1));
        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(0, dp(50), 1); shareParams.setMargins(dp(8), 0, 0, 0); actions.addView(shareButton, shareParams);
        page.addView(actions, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 10));
        Button back = secondaryButton("Voltar ao painel"); back.setOnClickListener(v -> finish()); page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        scroll.addView(page); root.addView(scroll, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void pollOperation() {
        if (!activityResumed || isFinishing() || finished || requestInProgress || operationId.isEmpty() || currentUser == null) return;
        requestInProgress = true;
        listTab("pendentes", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                JSONObject found = null;
                for (int i = 0; i < records.length(); i++) {
                    JSONObject item = records.optJSONObject(i);
                    if (item != null && operationId.equals(field(item, "id"))) { found = normalizeRecord(item); break; }
                }
                JSONObject result = found;
                runOnUiThread(() -> { requestInProgress = false; if (result == null) renderError("Não foi possível localizar esta operação agora."); else handleOperation(result); scheduleNextPoll(); });
            }
            @Override public void failure(String message) { runOnUiThread(() -> { requestInProgress = false; if (!finished) { statusView.setText("Aguardando conexão com o SANBANK BR DIGITAL..."); detailsView.setText("A consulta será repetida automaticamente."); scheduleNextPoll(); } }); }
        });
    }

    private void scheduleNextPoll() {
        operationHandler.removeCallbacks(operationPoller);
        if (activityResumed && !isFinishing() && !finished) operationHandler.postDelayed(operationPoller, 3500L);
    }

    private void handleOperation(JSONObject record) {
        operationRecord = record;
        String settlement = normalizePendingStatus(field(record, "settlement_status"));
        String status = normalizePendingStatus(field(record, "status", "pending"));
        if ("completed".equals(settlement) || "settled".equals(settlement) || "debited".equals(settlement)) { if ("LIMIT_INCREASE".equals(operationKind)) showLimitCompleted(record); else if ("INVOICE".equals(operationKind)) ensureInvoiceCardAfterRemote(record); else if ("PIX".equals(operationKind)) ensurePixCardAfterRemote(record); else creditRecipientThenShow(record, debitSource(record), decimal(firstField(record, "settlement_amount", "debited_amount", "amount"))); return; }
        if (isRejectedStatus(status)) { showRejected(record); return; }
        // Uma operação insuficiente pode ser reenviada para aprovação mantendo o antigo
        // settlement_status; a aprovação nova precisa prevalecer e chamar o RPC idempotente.
        if (isApprovedStatus(status) || isApprovedStatus(settlement)) {
            if (!settlementInProgress) {
                settlementInProgress = true;
                if ("LIMIT_INCREASE".equals(operationKind)) { statusView.setText("Gerente aprovou. Aplicando o novo limite..."); detailsView.setText("Atualizando o limite total do Cartão Neo sem realizar qualquer débito."); applyApprovedLimitIncrease(record); }
                else { statusView.setText("Administrador confirmou. Processando o débito..."); detailsView.setText("Verificando saldo disponível e limite do Cheque Especial."); settleApproved(record); }
            }
            return;
        }
        if (isInsufficientStatus(status) || "insufficient_balance".equals(settlement) || "saldo_insuficiente".equals(settlement)) { showInsufficient(record); return; }
        spinner.setVisibility(View.VISIBLE); statusView.setText("Aguardando confirmação do administrador"); statusView.setTextColor(Color.rgb(125, 211, 252)); detailsView.setText("Identificador: " + operationId + "\nNenhum valor foi debitado. A tela será atualizada automaticamente após a análise.");
    }

    private void settleApproved(JSONObject record) {
        spinner.setVisibility(View.VISIBLE);
        JSONObject body = new JSONObject();
        try { body.put("p_id", operationId); } catch (Exception ignored) { }
        rpc("sanbank_settle_approved_operation", body, new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject response = result instanceof JSONObject ? (JSONObject) result : firstObject(result);
                if (response != null && response.has("settlement_status")) {
                    runOnUiThread(() -> { settlementInProgress = false; handleSettlementResponse(response, record); });
                } else {
                    showSettlementRetry("O servidor ainda não confirmou o resultado. A mesma operação será consultada novamente.");
                }
            }
            @Override public void failure(String message) {
                // Falha de rede não autoriza débito local: o backend é a única fonte de liquidação.
                // A próxima tentativa usa o mesmo identificador, então o servidor pode responder idempotentemente.
                showSettlementRetry("Não foi possível obter a confirmação do servidor. A tentativa será repetida automaticamente.");
            }
        });
    }

    private void showSettlementRetry(String message) {
        runOnUiThread(() -> {
            settlementInProgress = false;
            if (finished || isFinishing()) return;
            spinner.setVisibility(View.VISIBLE);
            statusView.setText("Aguardando confirmação do servidor");
            statusView.setTextColor(Color.rgb(251, 191, 36));
            detailsView.setText("Identificador: " + operationId + "\n\n" + message + "\nNão envie uma nova transferência enquanto esta confirmação estiver sendo verificada.");
            scheduleNextPoll();
        });
    }

    private void handleSettlementResponse(JSONObject response, JSONObject record) {
        String status = normalizePendingStatus(firstField(response, "settlement_status", "status"));
        if (isInsufficientStatus(status) || "saldo_insuficiente".equals(status) || "insufficient_balance".equals(status)) {
            showInsufficient(response);
        } else if ("completed".equals(status) || "settled".equals(status) || "debited".equals(status)) {
            if ("INVOICE".equals(operationKind)) ensureInvoiceCardAfterRemote(response);
            else if ("PIX".equals(operationKind)) ensurePixCardAfterRemote(response);
            else creditRecipientThenShow(response, debitSource(response), decimal(firstField(response, "settlement_amount", "amount")));
        } else if (isRejectedStatus(status)) {
            showRejected(response);
        } else {
            showSettlementRetry("O servidor retornou o status '" + (status.isEmpty() ? "vazio" : status) + "'. A mesma operação será consultada novamente, sem débito local.");
        }
    }

    private void applyApprovedLimitIncrease(JSONObject pending) {
        double requested = decimal(firstField(operationMetadata, "requested_limit"));
        if (requested <= 0) requested = decimal(firstField(pending, "requested_limit", "limit_increase_requested_limit", "amount"));
        final double approvedLimit = roundMoney(requested);
        if (approvedLimit <= 0) { finishSettlementError("O novo limite informado não é válido."); return; }
        listTab("cartoes_neo", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray cards) {
                JSONObject card = normalizeRecord(latestRecord(cards));
                if (card == null) { finishSettlementError("Não foi possível localizar o Cartão Neo para aplicar o aumento."); return; }
                if (operationId.equals(field(card, "limit_increase_last_id"))) { markLimitIncreaseCompleted(pending, approvedLimit); return; }
                double previous = decimal(field(card, "limit_total"));
                JSONObject update = new JSONObject(); copyJsonValues(update, card);
                try {
                    update.put("limit_total", String.format(Locale.US, "%.2f", approvedLimit));
                    update.put("limit_increase_previous_limit", String.format(Locale.US, "%.2f", previous));
                    update.put("limit_increase_requested_limit", String.format(Locale.US, "%.2f", approvedLimit));
                    update.put("limit_increase_status", "approved");
                    update.put("limit_increase_last_id", operationId);
                    update.put("limit_increase_approved_at", isoNow());
                    update.put("limit_increase_approved_by", firstField(pending, "approved_by", "reviewed_by", "admin"));
                } catch (Exception ignored) { }
                apiUpsert("cartoes_neo", update, new RpcCallback() {
                    @Override public void success(Object ignored) { markLimitIncreaseCompleted(pending, approvedLimit); }
                    @Override public void failure(String message) { finishSettlementError("O gerente aprovou, mas não foi possível atualizar o limite. A tentativa será repetida."); }
                });
            }
            @Override public void failure(String message) { finishSettlementError("Não foi possível consultar o Cartão Neo após a aprovação."); }
        });
    }

    private void markLimitIncreaseCompleted(JSONObject pending, double approvedLimit) {
        JSONObject update = new JSONObject(); copyJsonValues(update, pending);
        try {
            update.put("status", "completed");
            update.put("settlement_status", "completed");
            update.put("operation_result", "limit_increased");
            update.put("limit_increase_status", "approved");
            update.put("limit_total_after", String.format(Locale.US, "%.2f", approvedLimit));
            update.put("completed_at", isoNow());
        } catch (Exception ignored) { }
        apiUpsert("pendentes", update, new RpcCallback() {
            @Override public void success(Object ignored) { runOnUiThread(() -> { settlementInProgress = false; showLimitCompleted(update); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { settlementInProgress = false; showLimitCompleted(update); }); }
        });
    }

    private void ensureInvoiceCardAfterRemote(JSONObject response) {
        double amount = decimal(firstField(response, "settlement_amount", "amount"));
        String source = debitSource(response);
        listTab("cartoes_neo", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray cards) {
                JSONObject card = normalizeRecord(latestRecord(cards));
                if (card == null) { creditRecipientThenShow(response, source, amount); return; }
                if (operationId.equals(field(card, "invoice_payment_last_id"))) { creditRecipientThenShow(response, source, amount); return; }
                double oldInvoice = decimal(firstField(card, "invoice_amount", "fatura", "limit_used", "0"));
                double oldUsed = decimal(firstField(card, "limit_used", "invoice_amount", "fatura", "0"));
                JSONObject update = new JSONObject(); copyJsonValues(update, card);
                try { update.put("invoice_amount", String.format(Locale.US, "%.2f", Math.max(0, roundMoney(oldInvoice - amount)))); update.put("fatura", String.format(Locale.US, "%.2f", Math.max(0, roundMoney(oldInvoice - amount)))); update.put("limit_used", String.format(Locale.US, "%.2f", Math.max(0, roundMoney(oldUsed - amount)))); update.put("invoice_payment_last_id", operationId); update.put("invoice_payment_at", isoNow()); update.put("invoice_payment_status", "approved_and_paid"); } catch (Exception ignored) { }
                apiUpsert("cartoes_neo", update, new RpcCallback() {
                    @Override public void success(Object ignored) { creditRecipientThenShow(response, source, amount); }
                    @Override public void failure(String message) { runOnUiThread(() -> renderError("O débito foi confirmado, mas a fatura ainda não sincronizou. Tente atualizar a tela.")); }
                });
            }
            @Override public void failure(String message) { creditRecipientThenShow(response, source, amount); }
        });
    }

    private void ensurePixCardAfterRemote(JSONObject response) {
        double resolvedAmount = decimal(firstField(response, "settlement_amount", "amount"));
        if (resolvedAmount <= 0) resolvedAmount = operationSettlementAmount(response);
        final double amount = resolvedAmount;
        String source = debitSource(response);
        listTab("cartoes_neo", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray cards) {
                JSONObject card = normalizeRecord(latestRecord(cards));
                if (card == null || operationId.equals(field(card, "pix_payment_last_id"))) { creditRecipientThenShow(response, source, amount); return; }
                double oldInvoice = decimal(firstField(card, "invoice_amount", "fatura", "limit_used", "0"));
                double oldUsed = decimal(firstField(card, "limit_used", "invoice_amount", "fatura", "0"));
                JSONObject update = new JSONObject(); copyJsonValues(update, card);
                try {
                    double newInvoice = Math.max(0, roundMoney(oldInvoice + amount));
                    double newUsed = Math.max(0, roundMoney(oldUsed + amount));
                    update.put("invoice_amount", String.format(Locale.US, "%.2f", newInvoice));
                    update.put("fatura", String.format(Locale.US, "%.2f", newInvoice));
                    update.put("next_invoice_amount", String.format(Locale.US, "%.2f", newInvoice));
                    update.put("proxima_fatura", String.format(Locale.US, "%.2f", newInvoice));
                    update.put("limit_used", String.format(Locale.US, "%.2f", newUsed));
                    update.put("pix_payment_last_id", operationId);
                    update.put("pix_payment_at", isoNow());
                    update.put("pix_payment_status", "approved_and_paid");
                } catch (Exception ignored) { }
                apiUpsert("cartoes_neo", update, new RpcCallback() {
                    @Override public void success(Object ignored) { creditRecipientThenShow(response, source, amount); }
                    @Override public void failure(String message) { runOnUiThread(() -> renderError("O Pix foi debitado, mas o limite usado do Cartão Neo ainda não sincronizou.")); }
                });
            }
            @Override public void failure(String message) { creditRecipientThenShow(response, source, amount); }
        });
    }

    private void creditRecipientThenShow(JSONObject record, String source, double amount) {
        String target = firstField(operationMetadata, "target_account", "recipient_account", "target");
        if (target.isEmpty()) target = firstField(record, "target_account", "recipient_account", "target");
        if (target.isEmpty()) target = operationTargetFromPayload(record);
        if (target.isEmpty() || !target.matches("\\d{6}") || target.equals(field(currentUser, "account")) || "ADMIN".equalsIgnoreCase(target)) {
            if ("DEM".equals(operationKind)) {
                showRecipientCreditPending(record, source, amount, "Não foi possível validar a conta destinatária. A operação não será marcada como concluída até a confirmação do crédito.");
            } else {
                showCompleted(record, source, amount);
            }
            return;
        }
        if (recipientCreditInProgress) return;
        recipientCreditInProgress = true;
        JSONObject body = new JSONObject();
        try { body.put("p_id", operationId); } catch (Exception ignored) { }
        rpc("sanbank_credit_operation_recipient", body, new RpcCallback() {
            @Override public void success(Object result) {
                recipientCreditInProgress = false;
                JSONObject response = result instanceof JSONObject ? (JSONObject) result : firstObject(result);
                String creditStatus = response == null ? "" : normalizePendingStatus(firstField(response, "status", "recipient_credit_status"));
                runOnUiThread(() -> {
                    if (isRecipientCreditConfirmed(creditStatus)) showCompleted(record, source, amount);
                    else if (creditStatus.contains("not_found") || creditStatus.contains("pending") || creditStatus.contains("external")) showRecipientCreditPending(record, source, amount, "A conta de destino ainda não foi confirmada pelo backend (" + creditStatus + ").");
                    else showRecipientCreditPending(record, source, amount, "O débito foi confirmado, mas o crédito do destinatário ainda não foi confirmado. A sincronização será repetida automaticamente.");
                });
            }
            @Override public void failure(String message) {
                recipientCreditInProgress = false;
                runOnUiThread(() -> showRecipientCreditPending(record, source, amount, "A comunicação com o crédito do destinatário falhou temporariamente. A tentativa será repetida automaticamente."));
            }
        });
    }

    private boolean isRecipientCreditConfirmed(String status) {
        return "completed".equals(status) || "already_completed".equals(status) || "credited".equals(status) || "credit_completed".equals(status);
    }

    private String operationTargetFromPayload(JSONObject record) {
        if (record == null) return "";
        String raw = field(record, "operation_data");
        if (raw.isEmpty()) return "";
        try {
            JSONObject metadata = new JSONObject(raw);
            return firstField(metadata, "target_account", "recipient_account", "target");
        } catch (Exception ignored) { return ""; }
    }

    private void showRecipientCreditPending(JSONObject record, String source, double amount, String reason) {
        finished = false;
        settlementInProgress = false;
        operationRecord = record;
        spinner.setVisibility(View.VISIBLE);
        actions.setVisibility(View.GONE);
        statusView.setText("Débito confirmado; crédito do destinatário pendente");
        statusView.setTextColor(Color.rgb(251, 191, 36));
        detailsView.setText("Identificador: " + operationId + "\nValor debitado: " + formatMoney(Math.abs(amount)) + "\nOrigem do débito: " + sourceLabel(source) + "\n\n" + reason + "\nNenhum novo débito será feito. A sincronização continuará automaticamente.");
        scheduleNextPoll();
    }

    private double operationSettlementAmount(JSONObject pending) {
        double amount = decimal(field(pending, "amount"));
        if ("PIX".equals(operationKind)) {
            try { String raw = field(pending, "operation_data"); if (!raw.isEmpty()) { JSONObject metadata = new JSONObject(raw); amount = decimal(firstField(metadata, "invoice_total", "amount", "pix_amount")); } } catch (Exception ignored) { }
        }
        return roundMoney(amount);
    }

    private void showCompleted(JSONObject record, String source, double amount) {
        finished = true; operationRecord = record; operationHandler.removeCallbacks(operationPoller); spinner.setVisibility(View.GONE); actions.setVisibility(("INVOICE".equals(operationKind) || "QR".equals(operationKind) || "BILL".equals(operationKind)) ? View.GONE : View.VISIBLE); statusView.setText("DEM".equals(operationKind) ? "Transferência DEM concluída" : "Pagamento confirmado e debitado"); statusView.setTextColor(Color.rgb(110, 231, 183));
        String completionMessage;
        if ("INVOICE".equals(operationKind)) completionMessage = "\nA fatura e o limite usado do Cartão Neo foram atualizados.";
        else if ("DEM".equals(operationKind)) completionMessage = "\nO crédito do destinatário foi confirmado.";
        else if ("QR".equals(operationKind) || "PIX".equals(operationKind)) completionMessage = "\nA operação foi confirmada e o processamento do destinatário foi concluído.";
        else completionMessage = "\nO administrador confirmou a operação e o extrato foi atualizado.";
        detailsView.setText("Identificador: " + operationId + "\nValor debitado: " + formatMoney(Math.abs(amount)) + "\nOrigem do débito: " + sourceLabel(source) + completionMessage);
    }

    private void showLimitCompleted(JSONObject record) {
        finished = true; operationRecord = record; operationHandler.removeCallbacks(operationPoller); spinner.setVisibility(View.GONE); actions.setVisibility(View.GONE); statusView.setText("Aumento de limite aprovado"); statusView.setTextColor(Color.rgb(110, 231, 183));
        double previous = decimal(firstField(record, "current_limit", "limit_increase_previous_limit"));
        double approved = decimal(firstField(record, "limit_total_after", "requested_limit", "limit_increase_requested_limit"));
        detailsView.setText("Identificador: " + operationId + "\nLimite anterior: " + formatMoney(previous) + "\nNovo limite: " + formatMoney(approved) + "\n\nO gerente administrativo aprovou a solicitação. Nenhum valor foi debitado.");
    }

    private void showInsufficient(JSONObject record) {
        // A operação pode ser reenviada para nova aprovação após regularizar o saldo.
        // Mantém a consulta ativa para que esta mesma tela acompanhe a reapresentação.
        finished = false;
        operationRecord = record;
        spinner.setVisibility(View.GONE);
        actions.setVisibility(View.GONE);
        statusView.setText("Saldo insuficiente — aguardando nova aprovação");
        statusView.setTextColor(Color.rgb(251, 191, 36));
        detailsView.setText("Identificador: " + operationId + "\n\nA liquidação não foi concluída por falta de saldo disponível. Se o Administrador reenviar a operação para aprovação, esta tela atualizará o status automaticamente.");
        scheduleNextPoll();
    }
    private void showRejected(JSONObject record) { finished = true; operationRecord = record; operationHandler.removeCallbacks(operationPoller); spinner.setVisibility(View.GONE); actions.setVisibility(View.GONE); statusView.setText("LIMIT_INCREASE".equals(operationKind) ? "Aumento de limite recusado" : "Pagamento recusado"); statusView.setTextColor(Color.rgb(251, 113, 133)); detailsView.setText("O administrador recusou a operação. Nenhum valor foi debitado e o limite atual foi preservado."); }
    private void renderError(String message) { if (finished) return; spinner.setVisibility(View.GONE); statusView.setText("Não foi possível concluir a consulta"); statusView.setTextColor(Color.rgb(251, 191, 36)); detailsView.setText(message); }
    private void finishSettlementError(String message) { runOnUiThread(() -> { settlementInProgress = false; renderError(message); scheduleNextPoll(); }); }

    private void openOperationReceipt() { if (operationRecord == null || "INVOICE".equals(operationKind)) return; if ("DEM".equals(operationKind)) openDemReceipt(operationRecord, operationMetadata); else openPixReceipt(operationRecord, operationMetadata); }
    private void shareOperationReceipt() { if (operationRecord == null || "INVOICE".equals(operationKind)) return; if ("DEM".equals(operationKind)) shareDemReceipt(operationRecord, operationMetadata); else sharePixReceipt(operationRecord, operationMetadata); }

    private String debitSource(JSONObject record) { String source = field(record, "debit_source"); return source.isEmpty() ? "saldo_disponivel" : source; }
    private String sourceLabel(String source) { return source != null && source.contains("cheque") ? "Cheque Especial disponível" : "Saldo disponível"; }
    private boolean isApprovedStatus(String status) { String value = normalizePendingStatus(status); return value.contains("approv") || value.contains("aprov") || value.contains("process") || value.equals("paid") || value.equals("completed") || value.equals("liberado"); }
    private boolean isRejectedStatus(String status) { String value = normalizePendingStatus(status); return value.contains("reject") || value.contains("recus") || value.contains("cancel") || value.contains("denied"); }
    private boolean isInsufficientStatus(String status) { String value = normalizePendingStatus(status); return value.contains("insufficient") || value.contains("insuficiente") || value.contains("saldo_insuficiente"); }

    @Override protected void onResume() {
        super.onResume();
        if (!finished && !operationId.isEmpty()) pollOperation();
    }

    @Override protected void onPause() {
        operationHandler.removeCallbacks(operationPoller);
        super.onPause();
    }

    @Override protected void onDestroy() {
        operationHandler.removeCallbacks(operationPoller);
        super.onDestroy();
    }
}
