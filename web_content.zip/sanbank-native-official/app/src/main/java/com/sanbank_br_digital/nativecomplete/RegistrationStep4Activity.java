package com.sanbank_br_digital.app;

/** Etapa 4 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep4Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 4; }
}
