package com.sanbank_br_digital.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Retoma o SANBANK BR DIGITAL depois que o instalador conclui o PAY. */
public final class PayPackageAddedReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getData() == null) return;
        if (!"com.sanbank.services.pay".equals(intent.getData().getSchemeSpecificPart())) return;
        Intent main = new Intent(context, LoginActivity.class);
        main.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        main.putExtra("pay_just_installed", true);
        context.startActivity(main);
    }
}
