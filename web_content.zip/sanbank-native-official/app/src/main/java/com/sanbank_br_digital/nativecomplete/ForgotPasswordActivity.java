package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.net.Uri;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.ImageView;

import org.json.JSONArray;
import org.json.JSONObject;

/** Recuperação de acesso por conta ou CPF, com nova senha numérica de oito dígitos. */
public final class ForgotPasswordActivity extends NativeBaseActivity {
    private EditText identity;
    private Spinner identityType;
    private EditText newPassword;
    private EditText confirmPassword;
    private Button lookupButton;
    private Button updateButton;
    private TextView status;
    private TextView found;
    private LinearLayout receiptActions;
    private Uri receiptUri;
    private String account = "";
    private String name = "";
    private LinearLayout passwordCard;

    @Override protected void onCreate(android.os.Bundle state) {
        super.onCreate(state);
        mainHandler.post(this::showRecoveryScreen);
    }

    private void showRecoveryScreen() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(15), dp(20), dp(15), dp(28));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = roundedSanbankLogo();
        brand.addView(logo, new LinearLayout.LayoutParams(dp(92), dp(68)));
        TextView title = text("Esqueci a senha", 23, TEXT, true); title.setGravity(Gravity.CENTER);
        brand.addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(36), 0, 3));
        TextView subtitle = text("Recupere seu acesso com uma validação segura.", 12, MUTED, false); subtitle.setGravity(Gravity.CENTER);
        brand.addView(subtitle, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 16));
        page.addView(brand, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));

        LinearLayout card = surfaceCard();
        card.addView(text("Identificar conta", 17, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 5));
        card.addView(text("Informe sua conta ou o CPF cadastrado para localizar o perfil.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        identityType = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, new String[]{"Número da conta", "CPF"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        identityType.setAdapter(adapter);
        card.addView(identityType, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8));
        identity = input("Conta com 6 dígitos", false);
        identity.setInputType(InputType.TYPE_CLASS_NUMBER);
        identity.setFilters(new InputFilter[]{new InputFilter.LengthFilter(11)});
        card.addView(identity, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 10));
        lookupButton = primaryButton("Consultar dados");
        lookupButton.setOnClickListener(v -> lookupIdentity());
        card.addView(lookupButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        found = text("Nenhuma conta validada.", 12, MUTED, false);
        found.setPadding(dp(12), dp(10), dp(12), dp(10));
        found.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
        card.addView(found, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        passwordCard = surfaceCard();
        passwordCard.setVisibility(View.GONE);
        passwordCard.addView(text("Criar nova senha", 17, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 5));
        passwordCard.addView(text("A senha deve conter exatamente 8 números.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        newPassword = input("Nova senha de 8 dígitos", true); passwordCard.addView(newPassword, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        confirmPassword = input("Confirmar nova senha", true); passwordCard.addView(confirmPassword, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 11));
        updateButton = primaryButton("Alterar senha"); updateButton.setOnClickListener(v -> updatePassword());
        passwordCard.addView(updateButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        page.addView(passwordCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        status = text("", 12, MUTED, false); status.setGravity(Gravity.CENTER); page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        receiptActions = new LinearLayout(this);
        receiptActions.setOrientation(LinearLayout.HORIZONTAL);
        receiptActions.setVisibility(View.GONE);
        Button openReceipt = primaryButton("Abrir PDF");
        Button shareReceipt = secondaryButton("Compartilhar PDF");
        openReceipt.setOnClickListener(v -> AccessReceiptHelper.open(this, receiptUri));
        shareReceipt.setOnClickListener(v -> AccessReceiptHelper.share(this, receiptUri, "Comprovante de alteração de senha SANBANK BR DIGITAL"));
        receiptActions.addView(openReceipt, new LinearLayout.LayoutParams(0, dp(50), 1));
        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(0, dp(50), 1); shareParams.setMargins(dp(8), 0, 0, 0);
        receiptActions.addView(shareReceipt, shareParams);
        page.addView(receiptActions, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 10));
        Button back = secondaryButton("Voltar ao login"); back.setOnClickListener(v -> finish()); page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        identityType.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { identity.setHint(position == 1 ? "CPF com 11 dígitos" : "Conta com 6 dígitos"); identity.setFilters(new InputFilter[]{new InputFilter.LengthFilter(position == 1 ? 11 : 6)}); identity.setText(""); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        scroll.addView(page);
        root.addView(scroll, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void lookupIdentity() {
        String value = identity.getText().toString().replaceAll("\\D", "");
        boolean cpf = identityType.getSelectedItemPosition() == 1;
        if ((cpf && value.length() != 11) || (!cpf && value.length() != 6)) { status.setText(cpf ? "Informe os 11 dígitos do CPF." : "Informe os 6 dígitos da conta."); return; }
        lookupButton.setEnabled(false); status.setText("Consultando os dados do SANBANK...");
        if (cpf) {
            JSONObject filters = new JSONObject(); try { filters.put("cpf", value); } catch (Exception ignored) { }
            listTabWithFilters("dados_pessoais", filters, new ListCallback() {
                @Override public void success(JSONArray records) {
                    JSONObject profile = records.length() > 0 ? records.optJSONObject(0) : null;
                    if (profile == null) { finishLookup(null); return; }
                    String foundAccount = firstField(profile, "account", "conta");
                    if (foundAccount.isEmpty()) { finishLookup(null); return; }
                    loadAccount(foundAccount);
                }
                @Override public void failure(String message) { runOnUiThread(() -> finishLookup(null)); }
            });
        } else {
            JSONObject body = new JSONObject(); try { body.put("p_account", value); body.put("p_role", JSONObject.NULL); } catch (Exception ignored) { }
            rpc("sanbank_account_search", body, new RpcCallback() {
                @Override public void success(Object result) { runOnUiThread(() -> finishLookup(firstObject(result))); }
                @Override public void failure(String message) { runOnUiThread(() -> finishLookup(null)); }
            });
        }
    }

    private void loadAccount(String value) {
        JSONObject body = new JSONObject(); try { body.put("p_account", value); body.put("p_role", JSONObject.NULL); } catch (Exception ignored) { }
        rpc("sanbank_account_search", body, new RpcCallback() {
            @Override public void success(Object result) { runOnUiThread(() -> finishLookup(firstObject(result))); }
            @Override public void failure(String message) { runOnUiThread(() -> finishLookup(null)); }
        });
    }

    private void finishLookup(JSONObject record) {
        lookupButton.setEnabled(true);
        if (record == null || firstField(record, "account", "conta").isEmpty()) {
            account = ""; passwordCard.setVisibility(View.GONE); found.setText("Nenhuma conta foi localizada com os dados informados."); status.setText("Confira os dados e tente novamente."); return;
        }
        account = firstField(record, "account", "conta"); name = firstField(record, "name", "nome", "Usuário SANBANK");
        found.setText("✓ Conta localizada: " + account + "\nTitular: " + name + "\nA consulta foi concluída sem exibir sua senha atual.");
        found.setTextColor(Color.rgb(167, 243, 208)); passwordCard.setVisibility(View.VISIBLE); status.setText("Agora informe e confirme a nova senha.");
    }

    private void updatePassword() {
        String first = newPassword.getText().toString().replaceAll("\\D", "");
        String second = confirmPassword.getText().toString().replaceAll("\\D", "");
        if (!first.matches("\\d{8}") || !first.equals(second)) { status.setText("As duas senhas precisam ter exatamente 8 dígitos iguais."); return; }
        updateButton.setEnabled(false); status.setText("Salvando a nova senha com segurança...");
        JSONObject payload = new JSONObject(); try { payload.put("password", first); } catch (Exception ignored) { }
        accountUpdate(account, payload, new RpcCallback() {
            @Override public void success(Object result) { runOnUiThread(() -> { status.setText("Senha alterada com sucesso para a conta " + account + "."); found.setText("✓ Senha atualizada\nTitular: " + name + "\nUse a nova senha de 8 dígitos no login."); updateButton.setText("Senha alterada"); newPassword.setEnabled(false); confirmPassword.setEnabled(false); receiptUri = AccessReceiptHelper.createPasswordReceipt(ForgotPasswordActivity.this, account, name, first, "Alterada com sucesso", "PWD-" + account + "-" + System.currentTimeMillis()); if (receiptUri != null) receiptActions.setVisibility(View.VISIBLE); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { updateButton.setEnabled(true); status.setText("Não foi possível alterar a senha agora. Tente novamente."); }); }
        });
    }
}
