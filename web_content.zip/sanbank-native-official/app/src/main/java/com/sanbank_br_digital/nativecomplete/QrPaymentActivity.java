package com.sanbank_br_digital.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Pagamento QR exclusivamente por leitura da câmera e confirmação dos dados escaneados. */
public final class QrPaymentActivity extends FunctionActivityBase {
    private static final int REQUEST_CAMERA = 8401;
    private TextView scannerStatus;
    private TextView reviewStatus;
    private WebView scannerView;
    private Button scannerButton;
    private Button payButton;
    private LinearLayout reviewCard;
    private String targetAccount = "";
    private String targetName = "";
    private String description = "";
    private double scannedAmount;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Pagar QR", "Escaneie o QR Code da cobrança. Não é possível digitar manualmente os dados do pagamento.");
        addScannerCard();
        addReviewCard();
        addBackButton();
        // O leitor é aberto automaticamente ao entrar na função Pagar QR.
        mainHandler.postDelayed(this::requestCameraPermission, 220L);
    }

    private void addScannerCard() {
        LinearLayout card = surfaceCard();
        card.addView(text("Leitor de QR Code", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 4));
        scannerStatus = text("Abrindo automaticamente a câmera traseira...", 11, MUTED, false);
        card.addView(scannerStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 8));
        scannerView = new WebView(this);
        scannerView.setVisibility(View.GONE);
        scannerView.setBackgroundColor(Color.rgb(2, 6, 23));
        scannerView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scannerView.setVerticalScrollBarEnabled(false);
        scannerView.setMinimumHeight(dp(390));
        WebSettings settings = scannerView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        scannerView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= 21) runOnUiThread(() -> request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE}));
            }
        });
        int scannerHeight = Math.max(dp(390), Math.min(dp(520), getResources().getDisplayMetrics().heightPixels - dp(260)));
        card.addView(scannerView, lp(ViewGroup.LayoutParams.MATCH_PARENT, scannerHeight, 0, 8));
        scannerButton = secondaryButton("Ler outro QR Code");
        scannerButton.setVisibility(View.GONE);
        card.addView(scannerButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 0));
        scannerButton.setOnClickListener(v -> requestCameraPermission());
        addCard(card, 10);
    }

    private void addReviewCard() {
        reviewCard = surfaceCard();
        reviewCard.setVisibility(View.GONE);
        reviewCard.addView(text("Confira antes de pagar", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 8));
        reviewCard.addView(text("Destinatário", 11, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 2));
        reviewCard.addView(text("", 14, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 6));
        reviewCard.addView(text("Conta", 11, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 2));
        reviewCard.addView(text("", 13, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        reviewCard.addView(text("Valor", 11, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 2));
        reviewCard.addView(text("", 23, Color.rgb(110, 231, 183), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(34), 0, 6));
        reviewCard.addView(text("", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        reviewStatus = text("QR Code validado.", 12, Color.rgb(167, 243, 208), false);
        reviewStatus.setPadding(dp(10), dp(9), dp(10), dp(9));
        reviewStatus.setBackground(rounded(Color.argb(25, 16, 185, 129), Color.argb(65, 110, 231, 183), 12));
        reviewCard.addView(reviewStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 9));
        payButton = primaryButton("Confirmar e pagar");
        reviewCard.addView(payButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        payButton.setOnClickListener(v -> submitPayment(payButton));
        page.addView(reviewCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
    }

    private void requestCameraPermission() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
            scannerStatus.setText("Autorize a câmera para iniciar o leitor automaticamente.");
            return;
        }
        startScanner();
    }

    private void startScanner() {
        scannerView.setVisibility(View.VISIBLE);
        scannerButton.setVisibility(View.GONE);
        scannerStatus.setText("Câmera ativa automaticamente. Aponte para o QR Code da cobrança.");
        scannerView.addJavascriptInterface(new QrBridge(), "SanbankQR");
        String html = readAssetText("qr_scanner.html");
        String library = readAssetText("html5-qrcode.js");
        html = html.replace("<!--__HTML5_QR_LIBRARY__-->", "<script>" + library + "</script>");
        scannerView.loadDataWithBaseURL("https://sanbank.local/", html, "text/html", "UTF-8", null);
        scannerButton.setOnClickListener(v -> closeScanner());
    }

    private void closeScanner() {
        if (scannerView != null) {
            if (Build.VERSION.SDK_INT >= 19) scannerView.evaluateJavascript("typeof stopScanner==='function'&&stopScanner();", null);
            scannerView.setVisibility(View.GONE);
        }
        if (scannerButton != null) {
            scannerButton.setVisibility(View.VISIBLE);
            scannerButton.setText("Ler outro QR Code");
            scannerButton.setOnClickListener(v -> requestCameraPermission());
        }
    }

    private final class QrBridge {
        @JavascriptInterface public void onScan(String decodedText) {
            runOnUiThread(() -> {
                closeScanner();
                if (parseScannedQr(decodedText)) {
                    scannerStatus.setText("QR Code lido com sucesso. Confira os dados antes de pagar.");
                    reviewCard.setVisibility(View.VISIBLE);
                } else {
                    scannerStatus.setText("QR Code inválido ou sem valor de cobrança. Leia outro código.");
                    reviewCard.setVisibility(View.GONE);
                }
            });
        }
        @JavascriptInterface public void onError(String message) {
            runOnUiThread(() -> scannerStatus.setText("Não foi possível abrir a câmera. Verifique a permissão."));
        }
    }

    private boolean parseScannedQr(String raw) {
        targetAccount = "";
        targetName = "";
        description = "";
        scannedAmount = 0;
        if (raw == null || raw.trim().isEmpty()) return false;
        try {
            JSONObject json = new JSONObject(raw.trim());
            targetAccount = json.optString("account", json.optString("conta", "")).trim();
            targetName = json.optString("name", json.optString("nome", "Destinatário QR")).trim();
            description = json.optString("desc", json.optString("description", "Cobrança QR")).trim();
            scannedAmount = json.optDouble("amount", json.optDouble("valor", 0));
        } catch (Exception error) {
            targetAccount = "";
            String[] parts = raw.split("[;|&]");
            for (String part : parts) {
                String[] pair = part.split("=", 2);
                if (pair.length != 2) continue;
                if (pair[0].trim().matches("(?i)account|conta")) targetAccount = pair[1].trim();
                if (pair[0].trim().matches("(?i)name|nome")) targetName = pair[1].trim();
                if (pair[0].trim().matches("(?i)amount|valor")) scannedAmount = decimal(pair[1]);
                if (pair[0].trim().matches("(?i)desc|description")) description = pair[1].trim();
            }
        }
        if (targetName.isEmpty()) targetName = "Destinatário QR";
        if (description.isEmpty()) description = "Cobrança QR";
        if (targetAccount.isEmpty() || targetAccount.equals(field(currentUser, "account")) || scannedAmount <= 0) return false;
        if (reviewCard != null && reviewCard.getChildCount() >= 8) {
            ((TextView) reviewCard.getChildAt(2)).setText(targetName);
            ((TextView) reviewCard.getChildAt(4)).setText(targetAccount);
            ((TextView) reviewCard.getChildAt(6)).setText(formatMoney(scannedAmount));
            ((TextView) reviewCard.getChildAt(7)).setText(description);
        }
        return true;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_CAMERA && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startScanner();
        else if (requestCode == REQUEST_CAMERA && scannerStatus != null) {
            scannerStatus.setText("Permissão da câmera não concedida. Toque em Ler outro QR Code para tentar novamente.");
            if (scannerButton != null) scannerButton.setVisibility(View.VISIBLE);
        }
    }

    @Override protected void onPause() {
        if (scannerView != null && scannerView.getVisibility() == View.VISIBLE && Build.VERSION.SDK_INT >= 19) scannerView.evaluateJavascript("typeof stopScanner==='function'&&stopScanner();", null);
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (scannerView != null) scannerView.destroy();
        super.onDestroy();
    }

    private void submitPayment(Button button) {
        button.setEnabled(false);
        reviewStatus.setText("Registrando pagamento para aprovação...");
        JSONObject payload = new JSONObject();
        try {
            payload.put("id", "PAYMENT_QR-" + field(currentUser, "account") + "-" + System.currentTimeMillis());
            payload.put("account", field(currentUser, "account"));
            payload.put("sender_account", field(currentUser, "account"));
            payload.put("target_account", targetAccount);
            payload.put("target_name", targetName);
            payload.put("amount", Math.round(scannedAmount * 100.0) / 100.0);
            payload.put("transaction_type", "PAYMENT_QR");
            payload.put("description", "Pagamento QR para " + targetName + " — " + description);
            payload.put("status", "pending");
            payload.put("created_at", isoNow());
        } catch (Exception ignored) { }
        apiUpsert("pendentes", payload, new RpcCallback() {
            @Override public void success(Object result) { runOnUiThread(() -> { button.setEnabled(true); reviewStatus.setText("Pagamento QR registrado e aguardando aprovação administrativa."); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); reviewStatus.setText(message); }); }
        });
    }
}
