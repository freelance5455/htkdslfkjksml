package com.sanbank_br_digital.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/** Face nativa reutilizável do Cartão Neo, com chip EMV desenhado em Canvas. */
public final class NeoCardFaceView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private String holder = "CLIENTE SANBANK";
    private String brand = "VISA";
    private String cardNumber = "";
    private String cardStatus = "ATIVO";
    private boolean numberVisible;
    private boolean blocked;

    public NeoCardFaceView(Context context) { super(context); init(); }
    public NeoCardFaceView(Context context, AttributeSet attrs) { super(context, attrs); init(); }
    public NeoCardFaceView(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); init(); }

    private void init() {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setContentDescription("Cartão de crédito Neo Bradesco, número protegido");
    }

    public void setCardData(String holder, String brand, String cardNumber, String status, boolean blocked) {
        this.holder = clean(holder).isEmpty() ? "CLIENTE SANBANK" : clean(holder).toUpperCase(java.util.Locale.ROOT);
        this.brand = clean(brand).isEmpty() ? "VISA" : clean(brand).toUpperCase(java.util.Locale.ROOT);
        this.cardNumber = clean(cardNumber);
        this.cardStatus = clean(status).isEmpty() ? (blocked ? "BLOQUEADO" : "ATIVO") : clean(status).toUpperCase(java.util.Locale.ROOT);
        this.blocked = blocked;
        updateDescription();
        invalidate();
    }

    public void setNumberVisible(boolean visible) {
        numberVisible = visible;
        updateDescription();
        invalidate();
    }

    private void updateDescription() {
        String digits = digits(cardNumber);
        String lastFour = digits.length() >= 4 ? digits.substring(digits.length() - 4) : "não disponível";
        setContentDescription("Cartão de crédito Neo Bradesco, final " + lastFour + (numberVisible ? ", número revelado" : ", número protegido") + ", chip EMV dourado, status " + cardStatus);
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        if (width <= 0) width = dp(340);
        int desiredHeight = Math.round(width / 1.586f);
        int height = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(resolveSize(width, widthMeasureSpec), height);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float radius = Math.min(w, h) * 0.09f;
        RectF bounds = new RectF(1.5f, 1.5f, w - 1.5f, h - 1.5f);
        Path clip = new Path();
        clip.addRoundRect(bounds, radius, radius, Path.Direction.CW);
        canvas.save();
        canvas.clipPath(clip);

        paint.setShader(new LinearGradient(0, 0, w, h,
                new int[]{Color.rgb(7, 24, 52), Color.rgb(16, 59, 105), Color.rgb(41, 28, 72)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRoundRect(bounds, radius, radius, paint);
        paint.setShader(null);

        // Reflexo suave e linhas de acabamento dão profundidade sem competir com os dados.
        paint.setColor(Color.argb(19, 160, 205, 255));
        Path sheen = new Path();
        sheen.moveTo(0, h * 0.05f); sheen.quadTo(w * 0.45f, h * 0.30f, w, h * 0.05f);
        sheen.lineTo(w, h * 0.26f); sheen.quadTo(w * 0.46f, h * 0.47f, 0, h * 0.20f); sheen.close();
        canvas.drawPath(sheen, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, h * 0.006f));
        paint.setColor(Color.argb(29, 190, 218, 255));
        for (int i = 0; i < 4; i++) {
            Path arc = new Path();
            arc.moveTo(w * (0.62f + i * 0.035f), h * 1.08f);
            arc.cubicTo(w * (0.48f + i * 0.035f), h * 0.63f, w * (0.99f + i * 0.035f), h * 0.48f, w * 0.91f, -h * 0.08f);
            canvas.drawPath(arc, paint);
        }
        paint.setStyle(Paint.Style.FILL);

        // Marca e status.
        drawText(canvas, "BRADESCO", w * 0.075f, h * 0.165f, h * 0.092f, Color.WHITE, Typeface.BOLD, Paint.Align.LEFT);
        drawText(canvas, "CARTÃO DE CRÉDITO", w * 0.078f, h * 0.225f, h * 0.043f, Color.argb(205, 210, 226, 246), Typeface.NORMAL, Paint.Align.LEFT);
        drawText(canvas, "NEO", w * 0.79f, h * 0.17f, h * 0.105f, Color.rgb(245, 198, 115), Typeface.BOLD, Paint.Align.LEFT);
        drawStatus(canvas, w * 0.84f, h * 0.285f, w, h);

        // Chip EMV dourado com contatos segmentados e relevo.
        drawChip(canvas, w * 0.078f, h * 0.325f, w * 0.185f, h * 0.205f);
        drawContactless(canvas, w * 0.30f, h * 0.42f, h * 0.072f);

        String displayNumber = numberVisible ? groupedNumber(cardNumber) : maskedNumber(cardNumber);
        drawFittedNumber(canvas, displayNumber, w * 0.078f, h * 0.704f, w * 0.85f, h * 0.102f);
        drawText(canvas, "TITULAR", w * 0.08f, h * 0.825f, h * 0.041f, Color.argb(185, 202, 221, 244), Typeface.BOLD, Paint.Align.LEFT);
        drawText(canvas, fitted(holder, w * 0.67f, h * 0.067f), w * 0.08f, h * 0.916f, h * 0.066f, Color.WHITE, Typeface.BOLD, Paint.Align.LEFT);
        drawText(canvas, brand, w * 0.92f, h * 0.91f, h * 0.105f, Color.WHITE, Typeface.BOLD, Paint.Align.RIGHT);

        canvas.restore();
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1.2f, h * 0.007f));
        paint.setColor(Color.argb(105, 204, 220, 241));
        canvas.drawRoundRect(bounds, radius, radius, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawChip(Canvas canvas, float x, float y, float width, float height) {
        RectF chip = new RectF(x, y, x + width, y + height);
        float r = height * 0.16f;
        paint.setShader(new LinearGradient(x, y, x + width, y + height,
                new int[]{Color.rgb(146, 103, 38), Color.rgb(250, 220, 145), Color.rgb(196, 145, 59)},
                null, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(chip, r, r, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, height * 0.026f));
        paint.setColor(Color.argb(210, 255, 238, 184));
        RectF inner = new RectF(x + width * 0.055f, y + height * 0.075f, x + width * 0.945f, y + height * 0.925f);
        canvas.drawRoundRect(inner, r * 0.65f, r * 0.65f, paint);
        paint.setColor(Color.argb(170, 114, 75, 24));
        paint.setStrokeWidth(Math.max(0.8f, height * 0.019f));
        float midX = x + width * 0.5f;
        canvas.drawLine(midX, inner.top, midX, inner.bottom, paint);
        canvas.drawLine(inner.left, y + height * 0.36f, inner.right, y + height * 0.36f, paint);
        canvas.drawLine(inner.left, y + height * 0.64f, inner.right, y + height * 0.64f, paint);
        RectF center = new RectF(x + width * 0.34f, y + height * 0.37f, x + width * 0.66f, y + height * 0.63f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(110, 255, 246, 205));
        canvas.drawRoundRect(center, height * 0.045f, height * 0.045f, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawContactless(Canvas canvas, float x, float centerY, float size) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(1.6f, size * 0.105f));
        paint.setColor(Color.argb(210, 230, 241, 255));
        for (int i = 1; i <= 3; i++) {
            float r = size * i * 0.30f;
            RectF arc = new RectF(x - r, centerY - r, x + r, centerY + r);
            canvas.drawArc(arc, -58, 116, false, paint);
        }
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(x, centerY, size * 0.10f, paint);
        paint.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawStatus(Canvas canvas, float centerX, float centerY, float w, float h) {
        String label = blocked ? "BLOQUEADO" : "ATIVO";
        float font = h * 0.047f;
        paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        paint.setTextSize(font);
        float tw = paint.measureText(label);
        RectF pill = new RectF(centerX - tw * 0.5f - h * 0.075f, centerY - h * 0.055f,
                centerX + tw * 0.5f + h * 0.075f, centerY + h * 0.055f);
        paint.setColor(blocked ? Color.argb(205, 110, 25, 47) : Color.argb(165, 12, 110, 88));
        canvas.drawRoundRect(pill, h * 0.055f, h * 0.055f, paint);
        paint.setColor(blocked ? Color.rgb(255, 195, 204) : Color.rgb(190, 255, 229));
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(label, centerX, centerY + font * 0.34f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawFittedNumber(Canvas canvas, String value, float x, float baseline, float maxWidth, float size) {
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.LEFT);
        float font = size;
        paint.setTextSize(font);
        while (paint.measureText(value) > maxWidth && font > size * 0.72f) {
            font -= 0.5f;
            paint.setTextSize(font);
        }
        paint.setColor(Color.WHITE);
        canvas.drawText(value, x, baseline, paint);
    }

    private void drawText(Canvas canvas, String value, float x, float baseline, float size, int color, int style, Paint.Align align) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create("sans-serif", style));
        paint.setTextAlign(align);
        paint.setTextSize(size);
        paint.setColor(color);
        canvas.drawText(value == null ? "" : value, x, baseline, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private String maskedNumber(String value) {
        String raw = digits(value);
        if (raw.length() < 4) return "•••• •••• •••• ••••";
        return "•••• •••• •••• " + raw.substring(raw.length() - 4);
    }

    private String groupedNumber(String value) {
        String raw = digits(value);
        if (raw.isEmpty()) return "Número indisponível";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            if (i > 0 && i % 4 == 0) out.append(' ');
            out.append(raw.charAt(i));
        }
        return out.toString();
    }

    private String fitted(String value, float maxWidth, float size) {
        String result = clean(value);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(size);
        while (paint.measureText(result) > maxWidth && result.length() > 8) result = result.substring(0, result.length() - 1);
        if (!result.equals(clean(value)) && result.length() > 3) result = result.substring(0, Math.max(3, result.length() - 1)) + "…";
        return result;
    }

    private String digits(String value) { return clean(value).replaceAll("\\D", ""); }
    private String clean(String value) { return value == null ? "" : value.trim(); }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
