package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.text.InputType;
import android.util.Base64;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

/** Cobrança QR com geração visual local e payload copiável. */
public final class QrChargeActivity extends FunctionActivityBase {
    private EditText amountInput;
    private EditText descriptionInput;
    private EditText accountInput;
    private TextView status;
    private WebView qrView;
    private String payloadText = "";

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Cobrar QR", "Gere uma cobrança para receber de outra pessoa.");
        LinearLayout form = surfaceCard();
        form.addView(text("Conta que receberá", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        accountInput = functionInput("Conta de recebimento");
        accountInput.setSingleLine(true);
        accountInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        accountInput.setText(field(currentUser, "account"));
        accountInput.setEnabled(false);
        form.addView(accountInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        form.addView(text("Valor da cobrança", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        amountInput = functionInput("R$ 0,00");
        amountInput.setSingleLine(true);
        amountInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        form.addView(amountInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        descriptionInput = functionInput("Descrição opcional");
        descriptionInput.setSingleLine(true);
        descriptionInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        form.addView(descriptionInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        Button generate = primaryButton("Gerar cobrança QR");
        form.addView(generate, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(form, 10);
        status = statusText("A cobrança será válida enquanto o QR permanecer disponível nesta tela.");

        LinearLayout qrCard = surfaceCard();
        qrCard.addView(text("QR Code da cobrança", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 8));
        qrView = new WebView(this);
        qrView.setBackgroundColor(Color.WHITE);
        WebSettings settings = qrView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDomStorageEnabled(false);
        qrCard.addView(qrView, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(230), 0, 8));
        Button copy = secondaryButton("Copiar payload da cobrança");
        qrCard.addView(copy, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 0));
        copy.setOnClickListener(v -> copyPayload());
        addCard(qrCard, 10);
        generate.setOnClickListener(v -> generateQr(generate));
        addBackButton();
    }

    private void generateQr(Button button) {
        double amount = decimal(amountInput.getText().toString());
        if (amount <= 0) { amountInput.setError("Informe um valor maior que zero."); return; }
        button.setEnabled(false);
        try {
            JSONObject payload = new JSONObject();
            payload.put("id", "QR" + System.currentTimeMillis());
            payload.put("account", field(currentUser, "account"));
            payload.put("name", field(currentUser, "name", "SANBANK BR DIGITAL"));
            payload.put("amount", Math.round(amount * 100.0) / 100.0);
            payload.put("desc", descriptionInput.getText().toString().trim().isEmpty() ? "Cobrança SANBANK" : descriptionInput.getText().toString().trim());
            payloadText = payload.toString();
            renderQr(payloadText);
            status.setText("QR Code gerado. Compartilhe ou mostre esta tela ao pagador.");
            JSONObject record = new JSONObject();
            copyJsonValues(record, payload);
            record.put("transaction_type", "CHARGE_QR");
            record.put("status", "pending");
            record.put("created_at", isoNow());
            apiUpsert("Pix", record, new RpcCallback() {
                @Override public void success(Object result) { runOnUiThread(() -> button.setEnabled(true)); }
                @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); status.setText("QR gerado localmente; não foi possível registrar a cobrança agora."); }); }
            });
        } catch (Exception error) {
            button.setEnabled(true);
            status.setText("Não foi possível gerar a cobrança.");
        }
    }

    private void renderQr(String value) {
        String encoded = Base64.encodeToString(value.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        String html = "<!doctype html><html><body style='margin:0;background:#fff;display:flex;align-items:center;justify-content:center;height:100vh'><div id='qrcode'></div><script src='qrcode.min.js'></script><script>new QRCode(document.getElementById('qrcode'),{text:atob('" + encoded + "'),width:190,height:190,colorDark:'#0f172a',colorLight:'#ffffff'});</script></body></html>";
        qrView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private void copyPayload() {
        if (payloadText.isEmpty()) { status.setText("Gere uma cobrança antes de copiar."); return; }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Cobrança QR SANBANK", payloadText));
        status.setText("Payload copiado para a área de transferência.");
    }
}
