package com.sanbank_br_digital.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;

/** Agenda a sincronização periódica sem exigir um serviço privilegiado. */
public final class NativeSyncScheduler {
    private static final int REQUEST_CODE = 7341;
    private static final long PERIOD_MS = 30L * 60L * 1000L;

    private NativeSyncScheduler() { }

    public static void schedule(Context context) {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        PendingIntent pending = pendingIntent(context);
        long first = SystemClock.elapsedRealtime() + 15000L;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarms.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, first, pending);
        else alarms.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, first, PERIOD_MS, pending);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarms.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, first + PERIOD_MS, PERIOD_MS, pending);
    }

    public static void cancel(Context context) {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms != null) alarms.cancel(pendingIntent(context));
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, NativeSyncReceiver.class);
        intent.setAction("com.sanbank_br_digital.app.SYNC");
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags);
    }
}
