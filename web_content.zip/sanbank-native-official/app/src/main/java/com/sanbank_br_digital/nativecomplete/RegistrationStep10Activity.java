package com.sanbank_br_digital.app;

/** Etapa 10 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep10Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 10; }
}
