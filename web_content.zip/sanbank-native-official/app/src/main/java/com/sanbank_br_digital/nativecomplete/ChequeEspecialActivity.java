package com.sanbank_br_digital.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Consulta nativa do Cheque Especial; ativação/desativação fica informativa até ser habilitada. */
public final class ChequeEspecialActivity extends FunctionActivityBase {
    @Override
    protected void onModuleReady() {
        beginFunctionPage("Cheque Especial", "Acompanhe limite, utilização e condições do serviço.");

        boolean enabled = isOverdraftVisible();
        double total = overdraftTotalLimit();
        double used = enabled ? Math.min(total, overdraftUsedAmount()) : 0;
        double available = availableOverdraft();

        LinearLayout statusCard = surfaceCard();
        statusCard.setOrientation(LinearLayout.HORIZONTAL);
        statusCard.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int iconId = getResources().getIdentifier("ic_overdraft", "drawable", getPackageName());
        if (iconId != 0) {
            try {
                Drawable drawable = getResources().getDrawable(iconId).mutate();
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) drawable.setTint(Color.rgb(125, 211, 252));
                icon.setImageDrawable(drawable);
            } catch (Exception ignored) { }
        }
        icon.setPadding(dp(11), dp(11), dp(11), dp(11));
        icon.setBackground(rounded(Color.argb(40, 56, 189, 248), Color.argb(75, 94, 234, 212), 18));
        statusCard.addView(icon, new LinearLayout.LayoutParams(dp(58), dp(58)));

        LinearLayout statusCopy = new LinearLayout(this);
        statusCopy.setOrientation(LinearLayout.VERTICAL);
        statusCopy.setPadding(dp(13), 0, dp(4), 0);
        statusCopy.addView(text("Cheque Especial", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 3));
        statusCopy.addView(text(enabled ? "Disponível conforme as regras da conta" : "Não habilitado nesta conta", 11, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        statusCard.addView(statusCopy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView statusBadge = text(enabled ? "ATIVO" : "INATIVO", 9, enabled ? Color.rgb(52, 211, 153) : Color.rgb(191, 219, 254), true);
        statusBadge.setGravity(Gravity.CENTER);
        statusBadge.setPadding(dp(9), dp(7), dp(9), dp(7));
        statusBadge.setBackground(rounded(enabled ? Color.argb(30, 52, 211, 153) : Color.argb(35, 148, 163, 184), enabled ? Color.argb(100, 52, 211, 153) : Color.argb(75, 148, 163, 184), 14));
        statusCard.addView(statusBadge, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(31)));
        addCard(statusCard, 11);

        LinearLayout limits = surfaceCard();
        limits.addView(text("Resumo do limite", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 7));
        addDetailRow(limits, "Limite contratado", formatMoney(total), TEXT);
        addDetailRow(limits, "Valor utilizado", formatMoney(used), Color.rgb(248, 113, 113));
        addDetailRow(limits, "Disponível para uso", formatMoney(available), Color.rgb(52, 211, 153));
        addCard(limits, 11);

        LinearLayout conditions = surfaceCard();
        conditions.addView(text("Condições atuais", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 7));
        String rate = String.format(new Locale("pt", "BR"), "%.1f%% ao mês", overdraftInterestRate() * 100.0);
        addDetailRow(conditions, "Taxa de juros", rate, Color.rgb(251, 191, 36));
        addDetailRow(conditions, "Período de carência", overdraftGraceDays() + " dias", TEXT);
        TextView note = text("Os valores seguem os dados e as condições registrados para sua conta.", 10, MUTED, false);
        note.setPadding(0, dp(6), 0, 0);
        conditions.addView(note, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        addCard(conditions, 11);

        LinearLayout notice = surfaceCard();
        notice.setBackground(rounded(Color.argb(48, 245, 158, 11), Color.argb(100, 245, 158, 11), 19));
        notice.addView(text("Ativar ou desativar", 14, Color.rgb(253, 230, 138), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 5));
        notice.addView(text("Essa opção ainda não está disponível. Em breve você poderá gerenciar o Cheque Especial por aqui.", 11, Color.rgb(254, 240, 194), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        addCard(notice, 10);

        Button manage = primaryButton(enabled ? "Desativar Cheque Especial" : "Ativar Cheque Especial");
        manage.setOnClickListener(v -> showComingSoonNotice());
        page.addView(manage, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 10));
        TextView safety = text("Tocar no botão apenas mostra este aviso; nenhuma alteração é feita na sua conta.", 10, MUTED, false);
        safety.setGravity(Gravity.CENTER);
        safety.setPadding(dp(8), dp(2), dp(8), dp(8));
        page.addView(safety, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        addBackButton();
    }

    private void addDetailRow(LinearLayout parent, String label, String value, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView left = text(label, 12, MUTED, false);
        row.addView(left, new LinearLayout.LayoutParams(0, dp(29), 1));
        TextView right = text(value, 13, color, true);
        right.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        row.addView(right, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(29)));
        parent.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(31), 0, 1));
    }

    private void showComingSoonNotice() {
        new AlertDialog.Builder(this)
                .setTitle("Função em breve")
                .setMessage("A ativação e a desativação do Cheque Especial ainda não estão disponíveis. Nenhuma alteração foi feita na sua conta.")
                .setPositiveButton("Entendi", null)
                .show();
    }
}
