package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Fluxo protegido para solicitar o cancelamento da conta digital. */
public final class CancelAccountActivity extends FunctionActivityBase {
    private TextView status;
    private CheckBox confirmation;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Cancelar conta digital", "Leia as condições antes de enviar a solicitação de encerramento.");
        LinearLayout warning = surfaceCard();
        warning.setBackground(rounded(Color.argb(34, 190, 24, 93), Color.argb(100, 251, 113, 133), 18));
        warning.addView(text("Atenção", 17, Color.rgb(253, 164, 175), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 7));
        warning.addView(text("O cancelamento encerra o acesso à conta e precisa ser confirmado pelo atendimento ou pelo Administrador. Verifique seu saldo e operações pendentes antes de continuar.", 13, Color.rgb(254, 226, 226), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        addCard(warning, 10);
        LinearLayout confirmCard = surfaceCard();
        confirmation = new CheckBox(this);
        confirmation.setText("Li o aviso e quero solicitar o cancelamento da minha conta");
        confirmation.setTextColor(Color.rgb(219, 234, 254));
        confirmCard.addView(confirmation, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        Button cancel = primaryButton("Enviar solicitação de cancelamento");
        confirmCard.addView(cancel, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(confirmCard, 10);
        status = statusText("Nenhuma solicitação foi enviada.");
        cancel.setOnClickListener(v -> requestCancellation(cancel));
        addBackButton();
    }

    private void requestCancellation(Button button) {
        if (!confirmation.isChecked()) { status.setText("Marque a confirmação para continuar."); return; }
        new android.app.AlertDialog.Builder(this)
                .setTitle("Confirmar cancelamento")
                .setMessage("Deseja realmente enviar a solicitação de cancelamento da conta?")
                .setNegativeButton("Voltar", null)
                .setPositiveButton("Confirmar", (dialog, which) -> sendCancellation(button))
                .show();
    }

    private void sendCancellation(Button button) {
        button.setEnabled(false);
        status.setText("Enviando solicitação para análise...");
        JSONObject payload = new JSONObject();
        try {
            payload.put("account_status", "cancelamento_solicitado");
            payload.put("cancellation_requested", "TRUE");
            payload.put("cancellation_requested_at", isoNow());
            payload.put("cancellation_reason", "Solicitação feita pelo usuário");
        } catch (Exception ignored) { }
        accountUpdate(field(currentUser, "account"), payload, new RpcCallback() {
            @Override public void success(Object result) { runOnUiThread(() -> { button.setEnabled(true); status.setText("Solicitação registrada. Aguarde a análise do atendimento SANBANK."); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); status.setText(message); }); }
        });
    }
}
