package com.sanbank_br_digital.app;

/** Acompanha a aprovação administrativa e a aplicação do novo limite Neo. */
public final class LimitIncreaseOperationActivity extends OperationStatusActivity {
    @Override protected String operationType() { return "LIMIT_INCREASE"; }
}
