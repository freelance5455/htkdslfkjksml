package com.sanbank_br_digital.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.text.InputType;
import android.widget.CheckBox;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Fase 2 da migração nativa do SANBANK BR DIGITAL.
 * O APK oficial continua separado até todos os módulos serem migrados.
 */
public class NativeBaseActivity extends Activity {
    protected static final String SUPABASE_URL = "https://tvkcjntieqierukjnnjx.supabase.co";
    protected static final String SUPABASE_PUBLISHABLE_KEY = "sb_publishable_ZI8YSTPyPbA-Jyv99lTZBA_f72vhQui";
    protected static final String PREFS = "sanbank_native_preview";
    protected static final String PREF_DOWNLOAD_ID = "pending_download_id";
    protected static final String PREF_UPDATE_URL = "pending_update_url";
    protected static final String STATEMENT_FOLDER = "extrato sanbank";
    protected static final int REQUEST_STORAGE = 5101;
    protected static final int DEFAULT_NEO_USAGE_LIMIT = 13;
    protected static final String OVERDRAFT_INTEREST_FUND_ACCOUNT = "121212";

    protected int neoOperationLimit(JSONObject record) {
        String configured = field(record, "security_limit_operations").trim();
        try {
            if (configured.matches("[0-9]{1,4}")) {
                int parsed = Integer.parseInt(configured);
                if (parsed >= 1 && parsed <= 9999) return parsed;
            }
        } catch (Exception ignored) { }
        return DEFAULT_NEO_USAGE_LIMIT;
    }

    protected int neoOperationLimit() { return neoOperationLimit(currentUser); }
    protected static final double DEFAULT_OVERDRAFT_INTEREST_RATE = 0.034;
    protected static final int DEFAULT_OVERDRAFT_GRACE_DAYS = 5;
    protected static final int NEO_INVOICE_CLOSING_DAY = 20;
    protected static final int NEO_INVOICE_DUE_DAY = 29;

    protected final ExecutorService network = Executors.newSingleThreadExecutor();
    protected final Handler mainHandler = new Handler(Looper.getMainLooper());
    protected final Handler securityHandler = new Handler(Looper.getMainLooper());
    protected final Handler supportHandler = new Handler(Looper.getMainLooper());
    protected final Handler notificationHandler = new Handler(Looper.getMainLooper());
    protected final Handler pendingHandler = new Handler(Looper.getMainLooper());
    protected final Handler dashboardBalanceHandler = new Handler(Looper.getMainLooper());
    protected final Handler appAccessHandler = new Handler(Looper.getMainLooper());
    protected boolean appAccessCheckInProgress;
    protected boolean notificationPolling;
    protected boolean pendingPolling;
    protected boolean activityResumed;
    protected boolean dashboardBalanceRefreshInProgress;
    protected boolean supportScreenVisible;
    protected boolean supportRefreshInProgress;
    protected int supportRefreshToken;
    protected ScrollView supportScrollView;
    protected TextView supportStatusView;
    protected LinearLayout supportMessagesView;
    protected final Runnable supportPoller = new Runnable() {
        @Override public void run() {
            if (supportScreenVisible) {
                if (!supportRefreshInProgress) refreshSupportMessages(supportStatusView, supportMessagesView);
                supportHandler.postDelayed(this, 5000L);
            }
        }
    };
    protected final Runnable notificationPoller = new Runnable() {
        @Override public void run() {
            if (notificationPolling) {
                refreshNativeNotifications(null, null);
                notificationHandler.postDelayed(this, 30000L);
            }
        }
    };
    protected final Runnable pendingPoller = new Runnable() {
        @Override public void run() {
            if (pendingPolling) {
                syncPendingStatuses();
                pendingHandler.postDelayed(this, 5000L);
            }
        }
    };
    protected final Runnable dashboardBalancePoller = new Runnable() {
        @Override public void run() {
            if (activityResumed && dashboardVisible && currentUser != null) {
                refreshDashboardAccount();
                dashboardBalanceHandler.postDelayed(this, 15000L);
            }
        }
    };
    protected final Runnable appAccessPoller = new Runnable() {
        @Override public void run() {
            if (activityResumed && shouldMonitorAppAccess()) {
                checkAppAccessStatus(true);
                appAccessHandler.postDelayed(this, 30000L);
            }
        }
    };
    protected final Runnable securityPoller = new Runnable() {
        @Override public void run() {
            pollSecurityUnlockCommand();
            if (securityScreenVisible) securityHandler.postDelayed(this, 5000L);
        }
    };

    protected FrameLayout root;
    protected TextView loginStatus;
    protected TextView securityStatus;
    protected TextView loadingStatus;
    protected ProgressBar loadingProgress;
    protected boolean loadingScreenVisible;
    protected boolean loadingFinishScheduled;
    protected long loadingStartedAt;
    protected long loadingMinimumMillis;
    protected JSONObject currentUser;
    protected JSONObject adminTarget;
    protected View neoActionModal;
    protected TextView neoActionStatus;
    protected Button neoActionConfirm;
    protected JSONObject userFeatureVisibility = new JSONObject();
    protected boolean userFeatureVisibilityLoaded;
    protected boolean dashboardVisible;
    private DashboardPromoCarousel dashboardPromoCarouselView;
    protected boolean dashboardNeedsRebuild;
    protected String dashboardRenderedAccountState = "";
    protected boolean adminSyncInProgress;
    protected long lastAdminSyncAt;
    protected String sessionToken = "";
    protected String securityUnlockCommandSeen = "";
    protected boolean securityScreenVisible;
    protected boolean accountCommandScreenVisible;
    protected boolean nativePixSecurityCheckPassed;
    protected boolean overdraftInterestSyncInProgress;
    protected long lastOverdraftInterestSyncAt;
    protected boolean yieldAutoCheckInProgress;
    protected String pendingStatementAccount;
    protected long pendingDownloadId = -1L;
    protected String pendingUpdateUrl = "";
    protected String pendingUpdateVersion = "";
    protected static final int BLUE = Color.rgb(14, 165, 233);
    protected static final int BLUE_DEEP = Color.rgb(37, 99, 235);
    protected static final int TEAL = Color.rgb(45, 212, 191);
    protected static final int RED = Color.rgb(225, 29, 72);
    protected static final int NIGHT = Color.rgb(3, 14, 27);
    protected static final int SURFACE = Color.rgb(8, 27, 45);
    protected static final int TEXT = Color.rgb(248, 250, 252);
    protected static final int MUTED = Color.rgb(171, 199, 220);

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        try { com.sanbank.nativebridge.NativeRuntime.isLoaded(); } catch (Throwable ignored) { }
        getWindow().setStatusBarColor(Color.rgb(4, 20, 34));
        getWindow().setNavigationBarColor(Color.rgb(3, 14, 27));
        root = new FrameLayout(this);
        setContentView(root);
        NativeNotificationHelper.createChannels(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5102);
        // SharedPreferences só pode ser obtido após o contexto estar pronto.
        loadPendingDownload();
        showLoadingScreen("Carregando os dados", "Por favor, aguarde...");
        handleInstallIntent(getIntent());
        if (getIntent() != null && getIntent().getBooleanExtra("open_notifications", false)) showNotificationsScreen();
    }

    protected SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    protected ImageView roundedSanbankLogo() {
        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setPadding(dp(4), dp(4), dp(4), dp(4));
        logo.setBackground(rounded(Color.WHITE, Color.argb(92, 191, 219, 254), 22));
        int logoId = getResources().getIdentifier("sanbank_header_logo", "drawable", getPackageName());
        if (logoId != 0) logo.setImageResource(logoId);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) logo.setClipToOutline(true);
        logo.setElevation(dp(2));
        return logo;
    }

    /** Cabeçalho compartilhado das telas internas, seguindo o painel principal. */
    protected void addDashboardStyleHeader(LinearLayout page) {
        addDashboardStyleHeader(page, true);
    }

    /** Cabeçalho sem botão de saída para fluxos que exigem confirmação antes do acesso. */
    protected void addDashboardStyleHeader(LinearLayout page, boolean showBack) {
        if (page == null) return;
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(9), dp(8), dp(8), dp(8));
        bar.setBackground(gradient(Color.rgb(7, 36, 58), Color.rgb(10, 70, 87), Color.rgb(12, 96, 91), 22));
        ImageView logo = roundedSanbankLogo();
        bar.addView(logo, new LinearLayout.LayoutParams(dp(70), dp(47)));
        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.VERTICAL);
        identity.setPadding(dp(10), 0, dp(6), 0);
        identity.addView(text(field(currentUser, "name", "Cliente"), 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 1));
        identity.addView(text("Conta: " + field(currentUser, "account", "--"), 11, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 0));
        bar.addView(identity, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        if (showBack) {
            Button back = secondaryButton("‹");
            back.setTextSize(25);
            back.setTextColor(Color.WHITE);
            back.setGravity(Gravity.CENTER);
            back.setMinHeight(dp(40));
            back.setPadding(0, 0, 0, dp(3));
            back.setBackground(rounded(Color.argb(28, 255, 255, 255), Color.argb(70, 191, 219, 254), 13));
            back.setOnClickListener(v -> finish());
            bar.addView(back, new LinearLayout.LayoutParams(dp(46), dp(42)));
        }
        page.addView(bar, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 15));
    }

    /**
     * Fundo visual local: CSS e JavaScript são usados somente para a camada estética.
     * Toda interação e regra de negócio continuam nas Activities nativas.
     */
    protected void resetRoot() {
        root.removeAllViews();
        WebView backdrop = new WebView(this);
        backdrop.setBackgroundColor(Color.TRANSPARENT);
        backdrop.setAlpha(0.98f);
        backdrop.setClickable(false);
        backdrop.setFocusable(false);
        backdrop.setFocusableInTouchMode(false);
        if (Build.VERSION.SDK_INT >= 16) backdrop.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        WebSettings settings = backdrop.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        backdrop.loadUrl("file:///android_asset/theme_backdrop.html");
        root.addView(backdrop, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Restaura somente a sessão já criada pelo login; nenhuma senha é persistida. */
    protected boolean restoreSavedSession() {
        SharedPreferences saved = prefs();
        sessionToken = saved.getString("session_token", "");
        String account = saved.getString("session_account", "");
        String json = saved.getString("session_user_json", "");
        if (sessionToken.trim().isEmpty() || account.trim().isEmpty()) return false;
        try {
            currentUser = json.trim().isEmpty() ? new JSONObject() : new JSONObject(json);
            if (!currentUser.has("account")) currentUser.put("account", account);
        } catch (Exception error) {
            currentUser = new JSONObject();
            try { currentUser.put("account", account); } catch (Exception ignored) { }
        }
        restoreCachedFeatureVisibility();
        return true;
    }

    protected void launchModule(Class<? extends Activity> module) {
        if (!moduleFeaturesEnabled(module)) {
            Toast.makeText(this, "Esta função está desabilitada pelo Administrador.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Intent intent = new Intent(this, module);
            startActivity(intent);
        } catch (Exception error) {
            Toast.makeText(this, "Não foi possível abrir esta função agora.", Toast.LENGTH_LONG).show();
        }
    }

    protected boolean featureVisible(String featureId) {
        if (featureId == null || featureId.trim().isEmpty() || !userFeatureVisibilityLoaded) return true;
        return userFeatureVisibility.optBoolean(featureId, true);
    }

    protected boolean moduleFeaturesEnabled(Class<?> module) {
        for (String featureId : featureIdsForModule(module)) if (!featureVisible(featureId)) return false;
        return true;
    }

    private String[] featureIdsForModule(Class<?> module) {
        if (module == null) return new String[0];
        if (module == PixActivity.class) return new String[]{"pix", "neo_card"};
        if (module == NeoCardActivity.class || module == NeoVirtualCardActivity.class || module == NeoAvailableLimitActivity.class || module == NeoLimitSharingActivity.class || module == NeoTrackingActivity.class || module == NeoLimitIncreaseActivity.class || module == NeoCardLossActivity.class || module == NeoCardSecurityActivity.class || module == NeoTokenApprovalActivity.class) return new String[]{"neo_card"};
        if (module == NeoInvoiceActivity.class || module == BillPaymentActivity.class) return new String[]{"card_bill"};
        if (module == DemTransferActivity.class) return new String[]{"transfer"};
        if (module == QrPaymentActivity.class) return new String[]{"pay_qr"};
        if (module == QrChargeActivity.class) return new String[]{"charge_qr"};
        if (module == StatementActivity.class || module == StatementEntriesActivity.class || module == StatementOutgoingActivity.class || module == StatementFutureActivity.class || module == StatementLoansActivity.class || module == StatementAutoDebitsActivity.class || module == StatementDiscountsActivity.class || module == StatementCategoryActivity.class) return new String[]{"statement"};
        if (module == InvestmentActivity.class) return new String[]{"balance_yield"};
        if (module == LimitsActivity.class) return new String[]{"limits"};
        if (module == ChequeEspecialActivity.class) return new String[]{"overdraft"};
        if (module == ProfileActivity.class) return new String[]{"profile"};
        if (module == AuraActivity.class) return new String[]{"aura"};
        if (module == ConsignedLoanActivity.class) return new String[]{"loan"};
        if (module == PersonalLoanActivity.class) return new String[]{"personal_loan"};
        if (module == NotificationsActivity.class) return new String[]{"notifications"};
        if (module == SupportActivity.class) return new String[]{"support"};
        if (module == CancelAccountActivity.class) return new String[]{"cancel_account"};
        if (module == AboutActivity.class) return new String[]{"about"};
        return new String[0];
    }

    private JSONObject defaultAdministrativeFeatureVisibility() {
        JSONObject defaults = new JSONObject();
        String[] ids = {"balance", "overdraft", "balance_yield", "transfer", "pay_qr", "pix", "charge_qr", "neo_card", "statement", "notifications", "limits", "profile", "aura", "loan", "personal_loan", "card_bill", "cancel_account", "support", "about"};
        for (String id : ids) try { defaults.put(id, true); } catch (Exception ignored) { }
        return defaults;
    }

    private void restoreCachedFeatureVisibility() {
        String cached = prefs().getString("user_feature_visibility", "");
        if (cached.trim().isEmpty()) return;
        try {
            JSONObject source = new JSONObject(cached);
            JSONObject normalized = defaultAdministrativeFeatureVisibility();
            for (String key : keysOf(normalized)) if (source.has(key)) normalized.put(key, truthy(String.valueOf(source.opt(key))) || "true".equalsIgnoreCase(String.valueOf(source.opt(key))));
            userFeatureVisibility = normalized;
            userFeatureVisibilityLoaded = true;
        } catch (Exception ignored) { }
    }

    private java.util.List<String> keysOf(JSONObject object) {
        java.util.ArrayList<String> keys = new java.util.ArrayList<>();
        java.util.Iterator<String> iterator = object.keys();
        while (iterator.hasNext()) keys.add(iterator.next());
        return keys;
    }

    protected void onAdministrativeVisibilityUpdated() {
        if (this instanceof NativeModuleActivity && !moduleFeaturesEnabled(getClass())) {
            Toast.makeText(this, "Esta função foi desabilitada pelo Administrador.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    /** Sincroniza os comandos administrativos antes de liberar as funções do usuário. */
    protected void syncAdministrativeControls() {
        if (currentUser == null || sessionToken.isEmpty()) return;
        long now = System.currentTimeMillis();
        if (adminSyncInProgress || now - lastAdminSyncAt < 2500L) return;
        adminSyncInProgress = true;
        lastAdminSyncAt = now;
        JSONObject body = new JSONObject();
        try { body.put("p_account", field(currentUser, "account")); body.put("p_role", JSONObject.NULL); } catch (Exception ignored) { }
        rpc("sanbank_account_search", body, new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject record = firstObject(result);
                if (record != null) {
                    String previousDashboardState = dashboardAccountSignature(currentUser);
                    JSONObject normalized = normalizeRecord(record);
                    String refreshedDashboardState = dashboardAccountSignature(normalized);
                    currentUser = normalized;
                    prefs().edit().putString("session_user_json", currentUser.toString()).apply();
                    runOnUiThread(() -> {
                        if (isFinishing()) return;
                        if (!activityResumed) {
                            if (!dashboardRenderedAccountState.isEmpty()) dashboardNeedsRebuild = true;
                            return;
                        }
                        String accountStatus = firstField(currentUser, "account_status", "accountStatus", "status").toLowerCase(Locale.ROOT);
                        if (accountStatus.matches(".*(cancelad|encerrad|bloqueio_definitivo|permanente).*") && !accountStatus.contains("solicit")) {
                            showAccountCommandScreen();
                        } else if (isSecurityLocked(currentUser) && !securityScreenVisible) {
                            showSecurityLockScreen(number(field(currentUser, "security_lock_count")));
                        } else if (!isSecurityLocked(currentUser) && securityScreenVisible) {
                            showDashboard();
                        } else if (accountCommandScreenVisible) {
                            showDashboard();
                        } else if (dashboardVisible && !previousDashboardState.equals(refreshedDashboardState)) {
                            showDashboard();
                        }
                    });
                }
                loadAdministrativeVisibility();
                loadAdministrativeAlert();
                syncPendingStatuses();
                adminSyncInProgress = false;
            }
            @Override public void failure(String message) {
                adminSyncInProgress = false;
            }
        });
    }

    protected String dashboardAccountSignature(JSONObject record) {
        String[] keys = {"balance", "overdraft_enabled", "overdraft_limit", "security_locked", "account_locked", "user_blocked", "security_status", "security_balance_blocked", "available_balance_blocked", "balance_security_blocked", "balance_status", "account_status", "approval_status"};
        StringBuilder signature = new StringBuilder();
        for (String key : keys) signature.append(key).append('=').append(field(record, key)).append('|');
        return signature.toString();
    }

    protected void startDashboardBalancePolling() {
        if (!dashboardVisible || !activityResumed || currentUser == null) return;
        dashboardBalanceHandler.removeCallbacks(dashboardBalancePoller);
        dashboardBalanceHandler.postDelayed(dashboardBalancePoller, 12000L);
    }

    protected void stopDashboardBalancePolling() {
        dashboardBalanceHandler.removeCallbacks(dashboardBalancePoller);
    }

    /** Confere a liquidação no servidor enquanto o painel está ativo, sem fazer crédito no cliente. */
    protected void maybeSettleDailyYield() {
        if (currentUser == null || sessionToken.isEmpty() || "admin".equalsIgnoreCase(field(currentUser, "role")) || yieldAutoCheckInProgress) return;
        String account = field(currentUser, "account");
        if (account.isEmpty()) return;
        long now = System.currentTimeMillis();
        String key = "sanbank_cdi_auto_check_" + account;
        long previous = prefs().getLong(key, 0L);
        if (previous > 0L && now >= previous && now - previous < 6L * 60L * 60L * 1000L) return;
        prefs().edit().putLong(key, now).apply();
        yieldAutoCheckInProgress = true;
        rpc("sanbank_settle_daily_yield", new JSONObject(), new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject response = firstObject(result);
                mainHandler.post(() -> {
                    yieldAutoCheckInProgress = false;
                    if (response == null || !response.optBoolean("credited", false) || currentUser == null || !account.equals(field(currentUser, "account"))) return;
                    try {
                        currentUser.put("balance", String.format(Locale.US, "%.2f", response.optDouble("balance", decimal(field(currentUser, "balance")))));
                        prefs().edit().putString("session_user_json", currentUser.toString()).apply();
                    } catch (Exception ignored) { }
                });
            }
            @Override public void failure(String message) {
                mainHandler.post(() -> yieldAutoCheckInProgress = false);
            }
        });
    }

    /** Atualiza o saldo do destinatário enquanto o painel estiver visível. */
    protected void refreshDashboardAccount() {
        if (!activityResumed || !dashboardVisible || currentUser == null || sessionToken.isEmpty() || dashboardBalanceRefreshInProgress) return;
        maybeSettleDailyYield();
        dashboardBalanceRefreshInProgress = true;
        JSONObject body = new JSONObject();
        try { body.put("p_account", field(currentUser, "account")); body.put("p_role", JSONObject.NULL); }
        catch (Exception ignored) { dashboardBalanceRefreshInProgress = false; return; }
        rpc("sanbank_account_search", body, new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject latest = firstObject(result);
                if (latest == null) { mainHandler.post(() -> dashboardBalanceRefreshInProgress = false); return; }
                JSONObject normalized = normalizeRecord(latest);
                String refreshedState = dashboardAccountSignature(normalized);
                mainHandler.post(() -> {
                    dashboardBalanceRefreshInProgress = false;
                    if (isFinishing() || currentUser == null) return;
                    String previousState = dashboardAccountSignature(currentUser);
                    currentUser = normalized;
                    prefs().edit().putString("session_user_json", currentUser.toString()).apply();
                    if (!activityResumed || !dashboardVisible || previousState.equals(refreshedState)) return;
                    String accountStatus = firstField(currentUser, "account_status", "accountStatus", "status").toLowerCase(Locale.ROOT);
                    if (accountStatus.matches(".*(cancelad|encerrad|bloqueio_definitivo|permanente).*") && !accountStatus.contains("solicit")) {
                        showAccountCommandScreen();
                    } else if (isSecurityLocked(currentUser)) {
                        showSecurityLockScreen(number(field(currentUser, "security_lock_count")));
                    } else {
                        showDashboard();
                    }
                });
            }
            @Override public void failure(String message) { mainHandler.post(() -> dashboardBalanceRefreshInProgress = false); }
        });
    }

    protected void loadAdministrativeVisibility() {
        JSONObject filters = new JSONObject();
        try { filters.put("id", "USER_FEATURE_VISIBILITY"); } catch (Exception ignored) { }
        listTabWithFilters("avisos_sistema", filters, new ListCallback() {
            @Override public void success(JSONArray records) {
                JSONObject record = records.length() > 0 ? records.optJSONObject(0) : null;
                JSONObject loaded = defaultAdministrativeFeatureVisibility();
                if (record != null) {
                    try {
                        JSONObject source = new JSONObject();
                        String message = field(record, "message");
                        if (!message.isEmpty()) source = new JSONObject(message);
                        else copyJsonValues(source, record);
                        JSONObject features = source.optJSONObject("features");
                        if (features == null) features = source;
                        java.util.Iterator<String> keys = features.keys();
                        while (keys.hasNext()) {
                            String key = keys.next();
                            if (loaded.has(key)) {
                                Object raw = features.opt(key);
                                String value = raw == null ? "" : String.valueOf(raw);
                                loaded.put(key, truthy(value) || "true".equalsIgnoreCase(value));
                            }
                        }
                    } catch (Exception ignored) { }
                }
                boolean visibilityChanged = false;
                if (!userFeatureVisibilityLoaded) visibilityChanged = true;
                else {
                    java.util.Iterator<String> keys = loaded.keys();
                    while (keys.hasNext()) {
                        String key = keys.next();
                        if (userFeatureVisibility.optBoolean(key, true) != loaded.optBoolean(key, true)) { visibilityChanged = true; break; }
                    }
                }
                userFeatureVisibility = loaded;
                userFeatureVisibilityLoaded = true;
                prefs().edit().putString("user_feature_visibility", loaded.toString()).apply();
                if (visibilityChanged) runOnUiThread(() -> {
                    if (isFinishing()) return;
                    if (dashboardVisible) {
                        if (activityResumed) showDashboard();
                        else if (!dashboardRenderedAccountState.isEmpty()) dashboardNeedsRebuild = true;
                    } else onAdministrativeVisibilityUpdated();
                });
            }
            @Override public void failure(String message) { }
        });
    }

    protected void loadAdministrativeAlert() {
        JSONObject filters = new JSONObject();
        try { filters.put("id", "SYSTEM_ALERT"); } catch (Exception ignored) { }
        listTabWithFilters("avisos_sistema", filters, new ListCallback() {
            @Override public void success(JSONArray records) {
                JSONObject record = records.length() > 0 ? records.optJSONObject(0) : null;
                if (record == null || !enabledNotification(field(record, "enabled", field(record, "ativo", "")))) return;
                String message = field(record, "message", field(record, "mensagem", ""));
                String id = field(record, "updated_at", field(record, "id", "SYSTEM_ALERT"));
                if (message.isEmpty() || id.equals(prefs().getString("last_admin_alert", ""))) return;
                prefs().edit().putString("last_admin_alert", id).apply();
                runOnUiThread(() -> new AlertDialog.Builder(NativeBaseActivity.this).setTitle(field(record, "type", "Aviso do Administrador")).setMessage(message).setPositiveButton("Entendi", null).show());
            }
            @Override public void failure(String message) { }
        });
    }

    protected void showAccountCommandScreen() {
        loadingScreenVisible = false;
        loadingFinishScheduled = false;
        loadingStatus = null;
        loadingProgress = null;
        dashboardVisible = false;
        securityScreenVisible = false;
        accountCommandScreenVisible = true;
        dashboardNeedsRebuild = false;
        stopDashboardBalancePolling();
        stopSecurityPolling();
        resetRoot();
        root.setBackground(gradient(Color.rgb(45, 12, 30), Color.rgb(32, 17, 50), Color.rgb(5, 11, 24), 0));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(24), dp(60), dp(24), dp(30));
        TextView icon = text("!", 34, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(gradient(RED, Color.rgb(190, 24, 93), BLUE_DEEP, 28));
        page.addView(icon, new LinearLayout.LayoutParams(dp(78), dp(78)));
        TextView title = text("Acesso encerrado pelo Administrador", 22, TEXT, true);
        title.setGravity(Gravity.CENTER);
        page.addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        TextView message = text("Esta conta recebeu um comando administrativo de encerramento ou bloqueio definitivo. Fale com o suporte para revisar a situação.", 14, MUTED, false);
        message.setGravity(Gravity.CENTER);
        page.addView(message, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 20));
        Button support = secondaryButton("Falar com suporte");
        support.setOnClickListener(v -> openSupportScreen());
        page.addView(support, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        Button logout = primaryButton("Voltar ao login");
        logout.setOnClickListener(v -> { sessionToken = ""; currentUser = null; prefs().edit().remove("session_token").remove("session_account").remove("session_user_json").apply(); showLogin(); });
        page.addView(logout, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    protected int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    protected GradientDrawable gradient(int start, int middle, int end, float radius) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{start, middle, end});
        drawable.setCornerRadius(dp(radius));
        if (radius > 1) drawable.setStroke(dp(1), Color.argb(62, 94, 234, 212));
        drawable.setDither(true);
        return drawable;
    }

    protected LinearLayout surfaceCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setBackground(rounded(Color.argb(238, 8, 27, 45), Color.argb(92, 45, 212, 191), 22));
        card.setElevation(dp(2));
        return card;
    }

    protected GradientDrawable rounded(int fill, int stroke, float radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) drawable.setStroke(dp(1), stroke);
        drawable.setDither(true);
        return drawable;
    }

    /** Estilo de carregamento único: trilha discreta e destaque turquesa. */
    protected void styleProgressBar(ProgressBar progress) {
        if (progress == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        android.content.res.ColorStateList accent = android.content.res.ColorStateList.valueOf(TEAL);
        progress.setIndeterminateTintList(accent);
        progress.setProgressTintList(accent);
        progress.setSecondaryProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(103, 232, 249)));
        progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.argb(70, 108, 141, 160)));
    }

    protected TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(false);
        view.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    protected LinearLayout.LayoutParams lp(int width, int height, int top, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
        params.setMargins(0, dp(top), 0, dp(bottom));
        return params;
    }

    protected EditText input(String hint, boolean password) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setHintTextColor(Color.rgb(123, 158, 188));
        field.setTextColor(TEXT);
        field.setTextSize(16);
        field.setSingleLine(true);
        field.setPadding(dp(15), 0, dp(15), 0);
        field.setBackground(rounded(Color.argb(228, 8, 25, 42), Color.argb(112, 65, 139, 154), 18));
        field.setInputType(password
                ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_NORMAL);
        return field;
    }

    protected EditText textInput(String hint) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setHintTextColor(Color.rgb(123, 158, 188));
        field.setTextColor(TEXT);
        field.setTextSize(14);
        field.setGravity(Gravity.TOP | Gravity.START);
        field.setPadding(dp(14), dp(12), dp(14), dp(12));
        field.setBackground(rounded(Color.argb(228, 8, 25, 42), Color.argb(112, 65, 139, 154), 18));
        field.setSingleLine(false);
        return field;
    }

    protected Button primaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setMinHeight(dp(52));
        button.setPadding(dp(14), 0, dp(14), 0);
        button.setBackground(gradient(Color.rgb(9, 145, 178), BLUE_DEEP, Color.rgb(13, 148, 136), 19));
        button.setElevation(dp(2));
        applyIcon(button, iconNameForLabel(label), Color.WHITE);
        return button;
    }

    protected Button secondaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(Color.rgb(191, 219, 254));
        button.setTextSize(13);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setMinHeight(dp(48));
        button.setPadding(dp(12), 0, dp(12), 0);
        button.setBackground(rounded(Color.argb(220, 10, 37, 56), Color.argb(105, 94, 234, 212), 18));
        button.setElevation(dp(1));
        return button;
    }

    protected Button actionButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(Color.rgb(219, 234, 254));
        button.setTextSize(12);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(72));
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(rounded(Color.argb(225, 9, 34, 53), Color.argb(96, 45, 212, 191), 21));
        button.setElevation(dp(1));
        applyIcon(button, iconNameForLabel(label), Color.rgb(125, 211, 252));
        return button;
    }

    protected String iconNameForLabel(String label) {
        if (label == null) return "";
        String normalizedLabel = label.toLowerCase(Locale.ROOT);
        if (normalizedLabel.contains("compartilhar")) return "ic_transfer";
        if (normalizedLabel.contains("cheque especial")) return "ic_overdraft";
        if (normalizedLabel.contains("segurança")) return "ic_shield";
        if (normalizedLabel.contains("limite")) return "ic_card";
        if (label.contains("aprovação") || label.contains("desbloquear") || label.contains("Validar")) return "ic_shield";
        if (label.contains("Enviar") || label.contains("transferência")) return "ic_transfer";
        if (label.contains("Atualizar") || label.contains("Consultar")) return "ic_update";
        if ("Pix Neo".equals(label)) return "ic_pix";
        if ("Transferência DEM".equals(label) || "Transferir DEM".equals(label)) return "ic_transfer";
        if ("Cartão Neo".equals(label) || "Neo Bradesco".equals(label)) return "ic_card";
        if ("Extrato PDF".equals(label) || "Extrato".equals(label)) return "ic_receipt";
        if ("Atualizações".equals(label) || label.contains("Rastreamento")) return "ic_update";
        if ("Notificações".equals(label)) return "ic_bell";
        if ("Suporte".equals(label)) return "ic_support";
        if ("Segurança".equals(label) || label.contains("Cancelar")) return "ic_shield";
        if (label.contains("perfil")) return "ic_home";
        if (label.contains("virtual")) return "ic_card";
        if (label.contains("limites") || label.contains("Limite")) return "ic_card";
        if (label.contains("Aura") || label.contains("consignado")) return "ic_shield";
        if (label.contains("Empréstimo pessoal")) return "ic_transfer";
        if (label.contains("boleto") || label.contains("Fatura")) return "ic_receipt";
        if (label.contains("CDI") || label.contains("rendimento")) return "ic_update";
        if (label.contains("senha")) return "ic_shield";
        if (label.contains("QR")) return "ic_pix";
        if (label.contains("Sobre")) return "ic_update";
        if ("Início".equals(label)) return "ic_home";
        if ("Operações".equals(label) || "Mais".equals(label) || "Mais funções".equals(label)) return "ic_operations";
        return "";
    }

    protected void applyIcon(Button button, String resourceName, int tint) {
        if (button == null || resourceName == null || resourceName.isEmpty()) return;
        int resourceId = getResources().getIdentifier(resourceName, "drawable", getPackageName());
        if (resourceId == 0) return;
        try {
            Drawable drawable = getResources().getDrawable(resourceId);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) drawable.setTint(tint);
            button.setCompoundDrawablesWithIntrinsicBounds(null, drawable, null, null);
            button.setCompoundDrawablePadding(dp(4));
        } catch (Exception ignored) { }
    }

    protected Button navButton(String label, boolean active) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(active ? Color.WHITE : Color.rgb(148, 163, 184));
        button.setTextSize(10);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setMinHeight(dp(48));
        button.setPadding(dp(3), 0, dp(3), 0);
        button.setBackground(active
                ? rounded(Color.argb(170, 13, 111, 125), Color.argb(145, 94, 234, 212), 17)
                : rounded(Color.TRANSPARENT, Color.TRANSPARENT, 17));
        applyIcon(button, iconNameForLabel(label), active ? Color.WHITE : Color.rgb(148, 163, 184));
        return button;
    }

    protected void showLoadingScreen(String title, String message) {
        showLoadingScreen(title, message, 1400L);
    }

    protected void showLoadingScreen(String title, String message, long minimumMillis) {
        loadingScreenVisible = true;
        loadingFinishScheduled = false;
        loadingStartedAt = System.currentTimeMillis();
        loadingMinimumMillis = Math.max(0L, minimumMillis);
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(28));

        ImageView logo = roundedSanbankLogo();
        page.addView(logo, new LinearLayout.LayoutParams(dp(106), dp(78)));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(22), dp(22), dp(22), dp(22));
        card.setBackground(rounded(Color.argb(242, 7, 25, 42), Color.argb(112, 45, 212, 191), 27));
        card.setElevation(dp(6));
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 18, 0));

        TextView category = text("SINCRONIZAÇÃO SEGURA", 11, Color.rgb(125, 211, 252), true);
        category.setGravity(Gravity.CENTER);
        card.addView(category, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 7));

        TextView heading = text(title, 21, TEXT, true);
        heading.setGravity(Gravity.CENTER);
        card.addView(heading, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(34), 0, 2));

        TextView subtitle = text("Aguarde enquanto preparamos o seu acesso.", 12, MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        card.addView(subtitle, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 17));

        loadingProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleLarge);
        loadingProgress.setIndeterminate(true);
        styleProgressBar(loadingProgress);
        card.addView(loadingProgress, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 14));

        TextView statusLabel = text("STATUS ATUAL", 10, Color.rgb(148, 163, 184), true);
        card.addView(statusLabel, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 4));
        loadingStatus = text(message, 13, Color.rgb(219, 234, 254), false);
        loadingStatus.setGravity(Gravity.CENTER_VERTICAL);
        loadingStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        loadingStatus.setBackground(rounded(Color.argb(218, 7, 39, 54), Color.argb(82, 45, 212, 191), 17));
        card.addView(loadingStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 16));

        LinearLayout steps = new LinearLayout(this);
        steps.setOrientation(LinearLayout.VERTICAL);
        steps.setPadding(dp(12), dp(10), dp(12), dp(10));
        steps.setBackground(rounded(Color.argb(18, 255, 255, 255), Color.argb(35, 148, 163, 184), 13));
        steps.addView(text("•  Sessão segura", 12, Color.rgb(167, 243, 208), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(23), 0, 2));
        steps.addView(text("•  Dados da conta", 12, Color.rgb(191, 219, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(23), 0, 2));
        steps.addView(text("•  Comandos administrativos", 12, Color.rgb(191, 219, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(23), 0, 0));
        card.addView(steps, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 15));

        TextView notice = text("Por favor, aguarde. Não feche o aplicativo durante o carregamento.", 11, MUTED, false);
        notice.setGravity(Gravity.CENTER);
        card.addView(notice, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Mantém a tela de carregamento visível pelo tempo mínimo e só depois troca de tela. */
    protected void completeLoadingThen(Runnable next) {
        if (next == null) return;
        if (!loadingScreenVisible) { next.run(); return; }
        if (loadingFinishScheduled) return;
        long elapsed = System.currentTimeMillis() - loadingStartedAt;
        long remaining = Math.max(0L, loadingMinimumMillis - elapsed);
        if (remaining > 0L) {
            loadingFinishScheduled = true;
            mainHandler.postDelayed(() -> {
                loadingFinishScheduled = false;
                loadingScreenVisible = false;
                loadingStatus = null;
                loadingProgress = null;
                next.run();
            }, remaining);
            return;
        }
        loadingScreenVisible = false;
        loadingStatus = null;
        loadingProgress = null;
        next.run();
    }

    protected void loadingMessage(String message) {
        if (loadingStatus != null) loadingStatus.setText(message);
    }

    protected void showLogin() {
        loadingScreenVisible = false;
        loadingFinishScheduled = false;
        loadingStatus = null;
        loadingProgress = null;
        dashboardVisible = false;
        accountCommandScreenVisible = false;
        securityScreenVisible = false;
        dashboardNeedsRebuild = false;
        dashboardRenderedAccountState = "";
        stopDashboardBalancePolling();
        stopSecurityPolling();
        stopSupportPolling();
        stopNativeNotificationPolling();
        stopPendingStatusPolling();
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(24), dp(40), dp(24), dp(32));

        ImageView logo = roundedSanbankLogo();
        page.addView(logo, new LinearLayout.LayoutParams(dp(112), dp(82)));

        TextView title = text("SANBANK BR DIGITAL", 22, TEXT, true);
        title.setGravity(Gravity.CENTER);
        page.addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(34), 18, 3));
        TextView subtitle = text("Migração nativa · fase 2", 13, MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 24));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(20), dp(18), dp(20));
        card.setBackground(rounded(Color.argb(210, 10, 30, 57), Color.argb(75, 56, 189, 248), 28));
        card.setElevation(dp(3));
        page.addView(card, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        card.addView(text("Acesse sua conta", 18, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(30), 0, 4));
        card.addView(text("Login e módulos desta fase usam a sessão segura do Supabase.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 16));
        EditText account = input("Conta com 6 dígitos", false);
        account.setMaxLines(1);
        card.addView(account, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 11));
        EditText password = input("Senha com 8 dígitos", true);
        card.addView(password, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 16));
        Button login = primaryButton("Entrar no SANBANK");
        card.addView(login, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        loginStatus = text("", 12, MUTED, false);
        loginStatus.setGravity(Gravity.CENTER);
        card.addView(loginStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(36), 0, 0));

        TextView forgot = text("🔑  Esqueci a senha", 13, Color.rgb(125, 211, 252), true);
        forgot.setGravity(Gravity.CENTER);
        forgot.setPadding(dp(10), dp(10), dp(10), dp(8));
        forgot.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 13));
        card.addView(forgot, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(44), 0, 8));

        TextView openAccount = text("＋  Abrir uma nova conta", 13, Color.rgb(110, 231, 183), true);
        openAccount.setGravity(Gravity.CENTER);
        openAccount.setPadding(dp(10), dp(10), dp(10), dp(8));
        openAccount.setBackground(rounded(Color.argb(24, 16, 185, 129), Color.argb(65, 110, 231, 183), 13));
        card.addView(openAccount, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(44), 0, 0));

        TextView note = text("O cliente oficial continua disponível enquanto a migração nativa avança por módulos.", 11, MUTED, false);
        note.setGravity(Gravity.CENTER);
        page.addView(note, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(42), 18, 0));
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        login.setOnClickListener(v -> login(account.getText().toString().trim(), password.getText().toString().trim(), login));
        forgot.setOnClickListener(v -> startActivity(new Intent(this, ForgotPasswordActivity.class)));
        openAccount.setOnClickListener(v -> startActivity(new Intent(this, OpenAccountActivity.class)));
    }

    protected void login(String account, String password, Button button) {
        if (!account.matches("\\d{6}")) { loginStatus.setText("A conta precisa ter 6 dígitos."); return; }
        if (!password.matches("\\d{8}")) { loginStatus.setText("A senha precisa ter 8 dígitos."); return; }
        button.setEnabled(false);
        loginStatus.setText("Autenticando no Supabase...");
        JSONObject body = new JSONObject();
        try { body.put("p_account", account); body.put("p_password", password); }
        catch (Exception error) { button.setEnabled(true); loginStatus.setText("Não foi possível preparar o acesso."); return; }
        rpc("sanbank_login_session", body, new RpcCallback() {
            @Override public void success(Object result) {
                runOnUiThread(() -> {
                    button.setEnabled(true);
                    JSONObject record = firstObject(result);
                    if (record == null || !record.has("account")) { loginStatus.setText("Conta ou senha incorretos."); return; }
                    showLoadingScreen("Carregando os dados", "Login confirmado. Por favor, aguarde...", 10000L);
                    sessionToken = record.optString("session_token", "");
                    prefs().edit().putString("session_token", sessionToken).putString("session_account", account).apply();
                    NativeNotificationHelper.createChannels(NativeBaseActivity.this);
                    NativeSyncScheduler.schedule(NativeBaseActivity.this);
                    NativeNotificationService.start(NativeBaseActivity.this);
                    currentUser = normalizeRecord(record);
                    prefs().edit().putString("session_user_json", currentUser.toString()).apply();
                    checkSecurityThenOpen();
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> { button.setEnabled(true); loginStatus.setText(message); });
            }
        });
    }

    /** Bloqueia somente os recursos disponíveis após o limite de operações, sem encerrar a sessão da conta. */
    protected void blockAvailableBalanceAndNeoCard(int count) {
        int operationLimit = neoOperationLimit(currentUser);
        JSONObject payload = new JSONObject();
        String reason = "Saldo disponível e Cartão Neo Bradesco bloqueados após atingir o limite de segurança de " + operationLimit + " operações.";
        try {
            payload.put("security_balance_blocked", "TRUE");
            payload.put("available_balance_blocked", "TRUE");
            payload.put("neo_card_security_blocked", "TRUE");
            payload.put("neo_card_security_status", "bloqueado_por_seguranca");
            payload.put("balance_status", "bloqueado_por_motivo_de_seguranca");
            payload.put("security_status", "saldo_bloqueado");
            payload.put("security_lock_reason", reason);
            payload.put("security_lock_card", "Cartão de Crédito Neo Bradesco");
            payload.put("security_lock_count", count);
            payload.put("security_locked_at", isoNow());
            payload.put("security_limit_operations", operationLimit);
        } catch (Exception ignored) { }
        accountUpdate(field(currentUser, "account"), payload, new RpcCallback() {
            @Override public void success(Object ignored) { }
            @Override public void failure(String ignored) { }
        });
        try {
            currentUser.put("security_balance_blocked", "TRUE");
            currentUser.put("available_balance_blocked", "TRUE");
            currentUser.put("neo_card_security_blocked", "TRUE");
            currentUser.put("neo_card_security_status", "bloqueado_por_seguranca");
            currentUser.put("balance_status", "bloqueado_por_motivo_de_seguranca");
            currentUser.put("security_status", "saldo_bloqueado");
            currentUser.put("security_lock_count", count);
            currentUser.put("security_lock_reason", reason);
            currentUser.put("security_limit_operations", operationLimit);
            prefs().edit().putString("session_user_json", currentUser.toString()).apply();
        } catch (Exception ignored) { }
    }

    protected void checkSecurityThenOpen() {
        final JSONObject record = currentUser;
        if (record == null || "admin".equalsIgnoreCase(field(record, "role"))) { completeLoadingThen(this::showDashboard); return; }
        verifyAppAccessBeforeProceed(() -> checkSecurityAfterAppAccess(record));
    }

    private void checkSecurityAfterAppAccess(final JSONObject record) {
        final int operationLimit = neoOperationLimit(record);
        loginStatusSafe("Consultando a proteção do Cartão Neo...");
        loadingMessage("Consultando a proteção da conta. Por favor, aguarde...");
        countNeoOperations(field(record, "account"), new OperationCallback() {
            @Override public void success(int count) {
                runOnUiThread(() -> {
                    boolean locked = isSecurityLocked(record);
                    int unlockedCount = number(field(record, "security_unlock_usage_count"));
                    boolean limitReached = count >= operationLimit && count > unlockedCount;
                    if (limitReached && !locked) blockAvailableBalanceAndNeoCard(count);
                    if (locked) completeLoadingThen(() -> showSecurityLockScreen(count));
                    else completeLoadingThen(NativeBaseActivity.this::showDashboard);
                });
            }
            @Override public void failure(String ignored) {
                runOnUiThread(() -> {
                    if (isSecurityLocked(record)) completeLoadingThen(() -> showSecurityLockScreen(number(field(record, "security_lock_count"))));
                    else completeLoadingThen(NativeBaseActivity.this::showDashboard);
                });
            }
        });
    }

    protected void verifyAppAccessBeforeProceed(Runnable allowed) {
        if (currentUser == null || sessionToken.isEmpty() || "admin".equalsIgnoreCase(field(currentUser, "role"))) {
            if (allowed != null) allowed.run();
            return;
        }
        JSONObject body = new JSONObject();
        rpc("sanbank_check_my_app_access", body, new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject state = firstObject(result);
                mainHandler.post(() -> {
                    if (isFinishing()) return;
                    if (state == null) { showAppAccessCheckFailure(); return; }
                    prefs().edit().putLong("app_access_last_check_ms", System.currentTimeMillis()).putString("app_access_last_check_account", field(currentUser, "account")).apply();
                    if (state.optBoolean("blocked", false)) {
                        Intent intent = new Intent(NativeBaseActivity.this, AppAccessBlockedActivity.class);
                        intent.putExtra("block_id", state.optString("block_id", ""));
                        intent.putExtra("block_reason", state.optString("reason", ""));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                        return;
                    }
                    if (allowed != null) allowed.run();
                });
            }
            @Override public void failure(String message) { mainHandler.post(NativeBaseActivity.this::showAppAccessCheckFailure); }
        });
    }

    private void showAppAccessCheckFailure() {
        Toast.makeText(this, "Não foi possível confirmar o acesso ao SANBANK. Tente novamente.", Toast.LENGTH_LONG).show();
        if (this instanceof LoginActivity) {
            ((LoginActivity) this).showLogin();
        } else {
            Intent login = new Intent(this, LoginActivity.class);
            login.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(login);
            finish();
        }
    }

    protected void loginStatusSafe(String message) {
        if (loginStatus != null) loginStatus.setText(message);
        if (loadingScreenVisible) loadingMessage(message);
    }

    protected void showDashboard() {
        loadingScreenVisible = false;
        loadingFinishScheduled = false;
        loadingStatus = null;
        loadingProgress = null;
        dashboardVisible = true;
        securityScreenVisible = false;
        accountCommandScreenVisible = false;
        dashboardNeedsRebuild = false;
        dashboardRenderedAccountState = dashboardAccountSignature(currentUser);
        stopSecurityPolling();
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(10), dp(10), dp(10), 0);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10), dp(9), dp(10), dp(9));
        header.setBackground(gradient(Color.rgb(7, 36, 58), Color.rgb(10, 70, 87), Color.rgb(12, 96, 91), 24));
        ImageView headerLogo = roundedSanbankLogo();
        header.addView(headerLogo, new LinearLayout.LayoutParams(dp(82), dp(56)));
        LinearLayout identity = new LinearLayout(this);
        identity.setPadding(dp(11), 0, dp(8), 0);
        identity.setOrientation(LinearLayout.VERTICAL);
        identity.addView(text(field(currentUser, "name", "Cliente"), 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 1));
        identity.addView(text("Conta: " + field(currentUser, "account", "--"), 12, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 0));
        header.addView(identity, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button logout = secondaryButton("Sair");
        logout.setTextSize(12);
        logout.setMinHeight(dp(42));
        logout.setBackground(gradient(Color.rgb(88, 43, 105), Color.rgb(112, 31, 87), Color.rgb(143, 29, 69), 16));
        logout.setTextColor(Color.WHITE);
        logout.setOnClickListener(v -> { sessionToken = ""; currentUser = null; prefs().edit().remove("session_token").remove("session_account").remove("session_user_json").apply(); NativeSyncScheduler.cancel(NativeBaseActivity.this); NativeNotificationService.stop(NativeBaseActivity.this); stopSupportPolling(); stopPendingStatusPolling(); showLogin(); });
        header.addView(logout, new LinearLayout.LayoutParams(dp(76), dp(44)));
        shell.addView(header, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(12), dp(14), dp(20));

        LinearLayout balance = new LinearLayout(this);
        balance.setOrientation(LinearLayout.VERTICAL);
        balance.setPadding(dp(17), dp(17), dp(17), dp(17));
        balance.setBackground(gradient(Color.rgb(8, 57, 105), Color.rgb(29, 16, 59), Color.rgb(91, 15, 47), 27));

        LinearLayout balanceHead = new LinearLayout(this);
        balanceHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView balanceLabel = text("SALDO EM CONTA", 12, Color.rgb(191, 219, 254), true);
        balanceLabel.setGravity(Gravity.CENTER_VERTICAL);
        balanceHead.addView(balanceLabel, new LinearLayout.LayoutParams(0, dp(28), 1));
        TextView eye = text("◉", 16, Color.rgb(191, 219, 254), true);
        eye.setGravity(Gravity.CENTER);
        eye.setBackground(rounded(Color.argb(32, 125, 211, 252), Color.argb(55, 125, 211, 252), 12));
        balanceHead.addView(eye, new LinearLayout.LayoutParams(dp(36), dp(28)));
        Button cdi = secondaryButton("↗ CDI");
        cdi.setTextSize(11);
        cdi.setMinHeight(dp(34));
        cdi.setPadding(dp(8), 0, dp(8), 0);
        cdi.setTextColor(Color.rgb(125, 211, 252));
        cdi.setBackground(rounded(Color.argb(35, 37, 99, 235), Color.argb(80, 56, 189, 248), 10));
        cdi.setOnClickListener(v -> launchModule(InvestmentActivity.class));
        LinearLayout.LayoutParams cdiParams = new LinearLayout.LayoutParams(dp(66), dp(34));
        cdiParams.setMargins(dp(8), 0, 0, 0);
        balanceHead.addView(cdi, cdiParams);
        balance.addView(balanceHead, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(30), 0, 5));

        final String balanceStatus = accountBalanceStatus();
        final boolean availableBalanceBlocked = isBalanceSecurityBlocked();
        if (availableBalanceBlocked || isAdminApprovalPendingStatus(balanceStatus)) {
            boolean blockedBalance = availableBalanceBlocked;
            TextView balanceStatusView = text(blockedBalance ? "BLOQUEADO · MOTIVO DE SEGURANÇA" : "AGUARDANDO APROVAÇÃO DO ADMINISTRADOR", 10, statusDisplayColor(blockedBalance ? "saldo_bloqueado" : balanceStatus), true);
            balanceStatusView.setGravity(Gravity.CENTER);
            balanceStatusView.setPadding(dp(9), dp(7), dp(9), dp(7));
            balanceStatusView.setBackground(statusDisplayBackground(blockedBalance ? "saldo_bloqueado" : balanceStatus));
            balance.addView(balanceStatusView, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        }

        final double accountBalance = decimal(field(currentUser, "balance"));
        final String rawAccountBalance = field(currentUser, "balance");
        final String balanceDisplay = availableBalanceBlocked ? "BLOQUEADO" : formatDashboardMoney(accountBalance);
        final TextView balanceValue = text(balanceDisplay, 30, signedDisplayColor(rawAccountBalance, availableBalanceBlocked ? "saldo_bloqueado" : balanceStatus), true);
        balanceValue.setGravity(Gravity.CENTER);
        balance.addView(balanceValue, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(49), 0, 8));
        final boolean[] balanceShown = {true};
        eye.setOnClickListener(v -> {
            balanceShown[0] = !balanceShown[0];
            balanceValue.setText(balanceShown[0] ? balanceDisplay : "••••••••");
            balanceValue.setTextColor(balanceShown[0] ? signedDisplayColor(rawAccountBalance, availableBalanceBlocked ? "saldo_bloqueado" : balanceStatus) : TEXT);
            eye.setText(balanceShown[0] ? "◉" : "○");
        });

        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(14), dp(10), dp(14), dp(10));
        details.setBackground(rounded(Color.argb(33, 255, 255, 255), Color.argb(58, 148, 163, 184), 18));
        LinearLayout overdraftRow = new LinearLayout(this);
        overdraftRow.setGravity(Gravity.CENTER_VERTICAL);
        overdraftRow.addView(text("Cheque Especial:", 13, Color.rgb(191, 219, 254), false), new LinearLayout.LayoutParams(0, dp(25), 1));
        boolean overdraftEnabled = isOverdraftVisible();
        TextView enabled = text(overdraftEnabled ? "●" : "○", 17, overdraftEnabled ? Color.rgb(52, 211, 153) : MUTED, true);
        enabled.setGravity(Gravity.CENTER);
        overdraftRow.addView(enabled, new LinearLayout.LayoutParams(dp(27), dp(25)));
        details.addView(overdraftRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 1));
        LinearLayout limitRow = new LinearLayout(this);
        limitRow.setGravity(Gravity.CENTER_VERTICAL);
        limitRow.addView(text("Limite Disponível:", 13, Color.rgb(191, 219, 254), false), new LinearLayout.LayoutParams(0, dp(25), 1));
        double overdraftAvailable = availableOverdraft();
        double available = transferAvailable();
        TextView availableText = text(formatMoney(overdraftAvailable), 13, signedDisplayColor(String.valueOf(overdraftAvailable), availableBalanceBlocked ? "saldo_bloqueado" : balanceStatus), false);
        availableText.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        limitRow.addView(availableText, new LinearLayout.LayoutParams(dp(115), dp(25)));
        details.addView(limitRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 4));
        View detailDivider = new View(this);
        detailDivider.setBackgroundColor(Color.argb(55, 191, 219, 254));
        details.addView(detailDivider, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(1), 0, 4));
        LinearLayout totalRow = new LinearLayout(this);
        totalRow.setGravity(Gravity.CENTER_VERTICAL);
        totalRow.addView(text("Total Disponível para Uso:", 13, TEXT, true), new LinearLayout.LayoutParams(0, dp(26), 1));
        TextView totalText = text(formatMoney(available), 13, signedDisplayColor(String.valueOf(available), availableBalanceBlocked ? "saldo_bloqueado" : balanceStatus), true);
        totalText.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        totalRow.addView(totalText, new LinearLayout.LayoutParams(dp(115), dp(26)));
        details.addView(totalRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 5));
        String interestRate = field(currentUser, "overdraft_interest_rate", "3,4%");
        String graceDays = field(currentUser, "overdraft_grace_days", "5");
        String warningMessage = availableBalanceBlocked ? "Saldo disponível bloqueado por segurança após atingir " + neoOperationLimit(currentUser) + " operações." : (overdraftEnabled ? "⚠  Juros de " + interestRate + " após " + graceDays + " dias; sem aumento neste ciclo." : "Cheque especial desabilitado para esta conta.");
        TextView warning = text(warningMessage, 11, Color.rgb(191, 219, 254), false);
        warning.setSingleLine(false);
        warning.setMaxLines(3);
        details.addView(warning, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 4));
        double overdraftInterest = overdraftInterestAmount(currentUser);
        if (overdraftInterest > 0 && overdraftUsedAmount() > 0) {
            LinearLayout interestRow = new LinearLayout(this);
            interestRow.setGravity(Gravity.CENTER_VERTICAL);
            interestRow.addView(text("Juros do Cheque Especial:", 12, Color.rgb(239, 68, 68), true), new LinearLayout.LayoutParams(0, dp(26), 1));
            TextView interestValue = text("- " + formatMoney(overdraftInterest), 13, Color.rgb(239, 68, 68), true);
            interestValue.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            interestRow.addView(interestValue, new LinearLayout.LayoutParams(dp(135), dp(26)));
            details.addView(interestRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 2));
            TextView interestDestination = text("Cobrança automática registrada no extrato.", 10, Color.rgb(248, 113, 113), false);
            interestDestination.setSingleLine(false);
            interestDestination.setMaxLines(2);
            details.addView(interestDestination, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        }
        balance.setElevation(dp(4));
        if (featureVisible("balance")) {
            shell.addView(balance, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
            content.addView(details, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        }

        TextView section = text("ACESSO RÁPIDO", 13, Color.rgb(191, 219, 254), true);
        section.setPadding(dp(4), 0, 0, 0);
        content.addView(section, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 5));
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        if (featureVisible("transfer")) addAction(grid, "Transferir DEM", () -> launchModule(DemTransferActivity.class));
        if (featureVisible("pay_qr")) addAction(grid, "Pagar QR", () -> launchModule(QrPaymentActivity.class));
        if (featureVisible("charge_qr")) addAction(grid, "Cobrar QR", () -> launchModule(QrChargeActivity.class));
        if (featureVisible("neo_card")) addAction(grid, "Neo Bradesco", () -> launchModule(NeoCardActivity.class));
        if (featureVisible("statement")) addAction(grid, "Extrato", () -> launchModule(StatementActivity.class));
        if (featureVisible("overdraft")) addAction(grid, "Cheque Especial", () -> launchModule(ChequeEspecialActivity.class));
        content.addView(grid, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        if (featureVisible("neo_card")) addDashboardNeoReview(content);
        addDashboardFunctionCarousel(content);

        TextView notice = text("As demais funções ficam disponíveis em Mais funções.", 11, MUTED, false);
        notice.setGravity(Gravity.CENTER);
        notice.setPadding(dp(12), dp(9), dp(12), dp(9));
        notice.setBackground(rounded(Color.argb(218, 7, 39, 54), Color.argb(72, 45, 212, 191), 17));
        content.addView(notice, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        scroll.addView(content);
        shell.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(5), dp(6), dp(5), dp(8));
        nav.setBackground(rounded(Color.argb(238, 8, 20, 39), Color.argb(64, 125, 211, 252), 22));
        nav.setElevation(dp(4));
        List<String> navItems = new ArrayList<>();
        navItems.add("Mais");
        if (featureVisible("statement")) navItems.add("Extrato");
        if (featureVisible("notifications")) navItems.add("Notificações");
        if (featureVisible("support")) navItems.add("Suporte");
        for (String item : navItems) {
            Button navButton = navButton(item, "Mais".equals(item));
            navButton.setOnClickListener(v -> {
                if ("Mais".equals(item)) launchModule(MoreActivity.class);
                else if ("Extrato".equals(item)) launchModule(StatementActivity.class);
                else if ("Notificações".equals(item)) launchModule(NotificationsActivity.class);
                else if ("Suporte".equals(item)) launchModule(SupportActivity.class);
            });
            nav.addView(navButton, new LinearLayout.LayoutParams(0, dp(50), 1));
        }
        shell.addView(nav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(68)));
        root.addView(shell, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        NativeSyncScheduler.schedule(this);
        NativeNotificationService.start(this);
        checkForUpdate(false);
        startNativeNotificationPolling();
        startPendingStatusPolling();
        syncOverdraftInterest();
        startDashboardBalancePolling();
    }

    protected void openNeoCardScreen() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));

        // Cabeçalho, saldo e navegação ficam fora da área rolável.
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(10), dp(8), dp(10), dp(3));
        addDashboardStyleHeader(screen);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(10), dp(14), dp(24));
        page.addView(text("VISÃO GERAL", 11, TEAL, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 3));
        page.addView(text("Cartão Neo Bradesco", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(34), 0, 2));
        page.addView(text("Seu cartão, limite e fatura em um só lugar.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 10));
        TextView status = text("Consultando os dados do cartão...", 13, MUTED, false);
        status.setPadding(dp(13), dp(11), dp(13), dp(11));
        status.setBackground(rounded(Color.argb(225, 8, 34, 51), Color.argb(84, 45, 212, 191), 16));
        page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        scroll.addView(page);
        screen.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        screen.addView(createNeoFixedBottomNavigation(), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(66), 7, 0));
        root.addView(screen, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        listTab("cartoes_neo", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                JSONObject card = normalizeRecord(latestRecord(records));
                runOnUiThread(() -> {
                    if (card == null) {
                        status.setText("Nenhum Cartão Neo foi encontrado para esta conta.");
                        return;
                    }
                    renderNativeNeoCard(page, card, status);
                });
            }
            @Override public void failure(String message) { runOnUiThread(() -> status.setText("Não foi possível carregar o Cartão Neo agora.")); }
        });
    }

    /** Navegação inferior permanece visível enquanto a página do cartão rola. */
    protected LinearLayout createNeoFixedBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(5), dp(5), dp(5), dp(5));
        nav.setBackground(rounded(Color.argb(246, 6, 20, 36), Color.argb(83, 94, 234, 212), 22));
        nav.setElevation(dp(6));
        List<String> navItems = new ArrayList<>();
        navItems.add("Mais");
        if (featureVisible("statement")) navItems.add("Extrato");
        if (featureVisible("notifications")) navItems.add("Notificações");
        if (featureVisible("support")) navItems.add("Suporte");
        for (String item : navItems) {
            Button button = navButton(item, "Mais".equals(item));
            button.setOnClickListener(v -> {
                if ("Mais".equals(item)) launchModule(MoreActivity.class);
                else if ("Extrato".equals(item)) launchModule(StatementActivity.class);
                else if ("Notificações".equals(item)) launchModule(NotificationsActivity.class);
                else if ("Suporte".equals(item)) launchModule(SupportActivity.class);
            });
            nav.addView(button, new LinearLayout.LayoutParams(0, dp(52), 1));
        }
        return nav;
    }

    /** Uma única barra segmentada: usado em vermelho e disponível em verde. */
    protected LinearLayout buildNeoLimitOverview(double total, double used, double available) {
        LinearLayout card = surfaceCard();
        card.setPadding(dp(15), dp(14), dp(15), dp(13));
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(text("Limite do cartão", 14, TEXT, true), new LinearLayout.LayoutParams(0, dp(24), 1));
        TextView totalValue = text("Total " + formatMoney(total), 11, MUTED, true);
        totalValue.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        titleRow.addView(totalValue, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(24)));
        card.addView(titleRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 10));

        View bar = new View(this) {
            private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                float inset = dp(1);
                float top = dp(2);
                float bottom = getHeight() - dp(2);
                float right = Math.max(inset, getWidth() - inset);
                RectF bounds = new RectF(inset, top, right, bottom);
                float radius = (bottom - top) / 2f;
                barPaint.setColor(Color.rgb(34, 52, 66));
                canvas.drawRoundRect(bounds, radius, radius, barPaint);
                if (total <= 0 || right <= inset) return;
                Path clip = new Path();
                clip.addRoundRect(bounds, radius, radius, Path.Direction.CW);
                float width = right - inset;
                float usedWidth = width * (float) Math.min(1d, Math.max(0d, used / total));
                float availableWidth = width * (float) Math.min(1d, Math.max(0d, available / total));
                canvas.save();
                canvas.clipPath(clip);
                barPaint.setColor(Color.rgb(248, 113, 113));
                if (usedWidth > 0) canvas.drawRect(inset, top, inset + usedWidth, bottom, barPaint);
                barPaint.setColor(Color.rgb(52, 211, 153));
                if (availableWidth > 0) canvas.drawRect(inset + usedWidth, top, Math.min(right, inset + usedWidth + availableWidth), bottom, barPaint);
                canvas.restore();
            }
        };
        bar.setContentDescription("Limite utilizado " + formatMoney(used) + "; disponível para uso " + formatMoney(available));
        card.addView(bar, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(17), 0, 10));

        LinearLayout values = new LinearLayout(this);
        values.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout usedColumn = new LinearLayout(this);
        usedColumn.setOrientation(LinearLayout.VERTICAL);
        TextView usedLabel = text("UTILIZADO", 9, MUTED, true);
        usedColumn.addView(usedLabel, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(16), 0, 1));
        usedColumn.addView(text(formatMoney(used), 13, Color.rgb(248, 113, 113), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(21), 0, 0));
        LinearLayout availableColumn = new LinearLayout(this);
        availableColumn.setOrientation(LinearLayout.VERTICAL);
        TextView availableLabel = text("DISPONÍVEL PARA USO", 9, MUTED, true);
        availableLabel.setGravity(Gravity.RIGHT);
        availableColumn.addView(availableLabel, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(16), 0, 1));
        TextView availableValue = text(formatMoney(available), 13, Color.rgb(52, 211, 153), true);
        availableValue.setGravity(Gravity.RIGHT);
        availableColumn.addView(availableValue, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(21), 0, 0));
        values.addView(usedColumn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        values.addView(availableColumn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        card.addView(values, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        return card;
    }

    protected String neoCardLastFour(String number) {
        if (number == null) return "— — — —";
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < number.length(); i++) {
            char c = number.charAt(i);
            if (c >= '0' && c <= '9') digits.append(c);
        }
        return digits.length() >= 4 ? digits.substring(digits.length() - 4) : "— — — —";
    }

    /** Prévia compacta do Cartão Neo no painel, logo abaixo de Acesso rápido. */
    protected void addDashboardNeoReview(LinearLayout content) {
        LinearLayout preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setPadding(0, 0, 0, dp(3));
        TextView loading = text("Carregando a visão geral do Cartão Neo...", 12, MUTED, false);
        loading.setPadding(dp(14), dp(13), dp(14), dp(13));
        loading.setBackground(rounded(Color.argb(218, 8, 27, 45), Color.argb(70, 94, 234, 212), 17));
        preview.addView(loading, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        content.addView(preview, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 13));

        listTab("cartoes_neo", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                JSONObject card = normalizeRecord(latestRecord(records));
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    preview.removeAllViews();
                    preview.addView(text("VISÃO GERAL · CARTÃO NEO", 11, TEAL, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(21), 0, 7));
                    if (card == null) {
                        TextView empty = text("Nenhum Cartão Neo foi encontrado para esta conta.", 12, MUTED, false);
                        empty.setPadding(dp(14), dp(13), dp(14), dp(13));
                        empty.setBackground(rounded(Color.argb(218, 8, 27, 45), Color.argb(70, 94, 234, 212), 17));
                        preview.addView(empty, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
                        return;
                    }
                    String number = firstField(card, "card_number", "number");
                    String lastFour = neoCardLastFour(number);
                    if ("— — — —".equals(lastFour)) {
                        String storedLastFour = firstField(card, "card_last_four", "last_four", "card_last4");
                        lastFour = neoCardLastFour(storedLastFour);
                        if (number.isEmpty()) number = storedLastFour;
                    }
                    String holder = field(card, "card_holder", field(currentUser, "name", "Cliente")).toUpperCase(Locale.ROOT);
                    String brand = field(card, "brand", field(card, "card_brand", "VISA")).toUpperCase(Locale.ROOT);
                    boolean blocked = isBlockedStatus(field(card, "status", "ativo")) || isNeoCardSecurityBlocked();
                    NeoCardFaceView face = new NeoCardFaceView(NativeBaseActivity.this);
                    face.setCardData(holder, brand, number, blocked ? "BLOQUEADO" : "ATIVO", blocked);
                    preview.addView(face, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 7));

                    LinearLayout numberRow = new LinearLayout(NativeBaseActivity.this);
                    numberRow.setGravity(Gravity.CENTER_VERTICAL);
                    numberRow.setPadding(dp(12), dp(7), dp(12), dp(7));
                    numberRow.setBackground(rounded(Color.argb(190, 8, 27, 45), Color.argb(65, 94, 234, 212), 14));
                    numberRow.addView(text("Neo Bradesco", 10, MUTED, true), new LinearLayout.LayoutParams(0, dp(21), 1));
                    TextView finalDigits = text("•••• " + lastFour, 12, TEXT, true);
                    finalDigits.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
                    numberRow.addView(finalDigits, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(21)));
                    numberRow.setContentDescription("Cartão Neo Bradesco, final " + lastFour);
                    preview.addView(numberRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 9));

                    double total = Math.max(0, decimal(field(card, "limit_total")));
                    double used = Math.min(total, Math.max(0, decimal(field(card, "limit_used"))));
                    double available = blocked ? 0 : Math.max(0, total - used);
                    preview.addView(buildNeoLimitOverview(total, used, available), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
                    Button openCard = secondaryButton("Abrir cartão e opções");
                    openCard.setOnClickListener(v -> launchModule(NeoCardActivity.class));
                    preview.addView(openCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(46), 0, 0));
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    loading.setText("Não foi possível atualizar a prévia do Cartão Neo.");
                });
            }
        });
    }

    private static final class DashboardPromoItem {
        final String title;
        final String description;
        final String iconName;
        final Class<? extends Activity> destination;
        DashboardPromoItem(String title, String description, String iconName, Class<? extends Activity> destination) {
            this.title = title;
            this.description = description;
            this.iconName = iconName;
            this.destination = destination;
        }
    }

    private void addDashboardFunctionCarousel(LinearLayout content) {
        List<DashboardPromoItem> items = dashboardPromoItems();
        if (items.isEmpty()) return;
        DashboardPromoCarousel carousel = new DashboardPromoCarousel(items);
        dashboardPromoCarouselView = carousel;
        content.addView(carousel, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
    }

    /** Coleção do carrossel: cada slide apresenta uma função real disponível no app. */
    private List<DashboardPromoItem> dashboardPromoItems() {
        List<DashboardPromoItem> items = new ArrayList<>();
        addPromo(items, featureVisible("transfer"), "Transferência DEM", "Envie uma transferência interna com revisão e acompanhamento do pedido.", "ic_transfer", DemTransferActivity.class);
        addPromo(items, featureVisible("pay_qr"), "Pagar com QR Code", "Escaneie o código, confira os dados e confirme o pagamento.", "ic_pix", QrPaymentActivity.class);
        addPromo(items, featureVisible("charge_qr"), "Cobrar por QR Code", "Gere um QR Code para facilitar o recebimento.", "ic_pix", QrChargeActivity.class);
        addPromo(items, featureVisible("neo_card"), "Cartão Neo Bradesco", "Veja a prévia protegida, acompanhe o limite e acesse as opções do cartão.", "ic_card", NeoCardActivity.class);
        addPromo(items, featureVisible("neo_card"), "Cartão virtual Neo", "Acesse os dados virtuais do cartão com proteção do titular.", "ic_card", NeoVirtualCardActivity.class);
        addPromo(items, featureVisible("neo_card"), "Limite Neo disponível", "Confira o total, o valor utilizado e o limite liberado para uso.", "ic_card", NeoAvailableLimitActivity.class);
        addPromo(items, featureVisible("card_bill"), "Fatura Neo", "Consulte a fatura e acompanhe as opções de pagamento.", "ic_receipt", NeoInvoiceActivity.class);
        addPromo(items, featureVisible("card_bill"), "Pagar boleto Neo", "Envie o pagamento do boleto do cartão para acompanhamento.", "ic_receipt", BillPaymentActivity.class);
        addPromo(items, featureVisible("pix") && featureVisible("neo_card"), "Pix no Cartão Neo", "Revise o valor e as condições antes de enviar sua solicitação.", "ic_pix", PixActivity.class);
        addPromo(items, featureVisible("neo_card"), "Compartilhar limite", "Ajuste a distribuição disponível entre Neo e Cheque Especial.", "ic_transfer", NeoLimitSharingActivity.class);
        addPromo(items, featureVisible("neo_card"), "Aumento de limite", "Solicite a análise de um novo limite para o Cartão Neo.", "ic_card", NeoLimitIncreaseActivity.class);
        addPromo(items, featureVisible("neo_card"), "Segurança do cartão", "Consulte a proteção e o status de segurança do cartão.", "ic_shield", NeoCardSecurityActivity.class);
        addPromo(items, featureVisible("neo_card"), "Rastreamento Neo", "Acompanhe as informações de entrega do cartão.", "ic_update", NeoTrackingActivity.class);
        addPromo(items, featureVisible("neo_card"), "Perda ou roubo", "Acesse a opção de bloqueio de segurança do cartão.", "ic_shield", NeoCardLossActivity.class);
        addPromo(items, featureVisible("neo_card"), "Validar compra Neo", "Revise os dados e confirme pelo titular no próprio aplicativo.", "ic_shield", NeoTokenApprovalActivity.class);
        addPromo(items, featureVisible("statement"), "Extrato completo", "Consulte lançamentos, filtros e comprovantes da conta.", "ic_receipt", StatementActivity.class);
        addPromo(items, featureVisible("statement"), "Entradas e saídas", "Veja os lançamentos de crédito e débito por categoria.", "ic_transfer", StatementEntriesActivity.class);
        addPromo(items, featureVisible("statement"), "Lançamentos futuros", "Confira os lançamentos futuros apresentados no extrato.", "ic_update", StatementFutureActivity.class);
        addPromo(items, featureVisible("statement"), "Empréstimos no extrato", "Consulte os registros relacionados a empréstimos.", "ic_receipt", StatementLoansActivity.class);
        addPromo(items, featureVisible("statement"), "Débitos automáticos", "Revise os débitos automáticos lançados na conta.", "ic_receipt", StatementAutoDebitsActivity.class);
        addPromo(items, featureVisible("statement"), "Descontos", "Acompanhe os descontos registrados no extrato.", "ic_receipt", StatementDiscountsActivity.class);
        addPromo(items, featureVisible("balance_yield"), "Saldo e CDI", "Acompanhe rendimento, liquidez, histórico e simulações.", "ic_update", InvestmentActivity.class);
        addPromo(items, featureVisible("limits"), "Meus limites", "Consulte os limites disponíveis associados à conta.", "ic_card", LimitsActivity.class);
        addPromo(items, featureVisible("overdraft"), "Cheque Especial", "Consulte limite, utilização, disponibilidade e condições do serviço.", "ic_overdraft", ChequeEspecialActivity.class);
        addPromo(items, featureVisible("profile"), "Meu perfil", "Consulte seus dados pessoais e informações de contato.", "ic_home", ProfileActivity.class);
        addPromo(items, featureVisible("aura"), "Aura Previdência", "Acesse informações e consultas previdenciárias.", "ic_shield", AuraActivity.class);
        addPromo(items, featureVisible("loan"), "Empréstimo consignado", "Confira a simulação e envie uma solicitação para análise.", "ic_transfer", ConsignedLoanActivity.class);
        addPromo(items, featureVisible("personal_loan"), "Empréstimo pessoal", "Simule parcelas e acompanhe o envio da solicitação.", "ic_transfer", PersonalLoanActivity.class);
        addPromo(items, true, "Alterar senha", "Atualize sua senha com a confirmação de segurança do aplicativo.", "ic_shield", ChangePasswordActivity.class);
        addPromo(items, true, "Privacidade do aparelho", "Consulte e controle o cadastro técnico autorizado do dispositivo.", "ic_shield", DevicePrivacyActivity.class);
        addPromo(items, true, "Segurança e acesso", "Acesse as opções de proteção e segurança da conta.", "ic_shield", SecurityActivity.class);
        addPromo(items, true, "Atualizações", "Consulte a versão e as novidades disponíveis do SANBANK.", "ic_update", UpdatesActivity.class);
        addPromo(items, featureVisible("notifications"), "Notificações", "Veja avisos e atualizações relacionados à sua conta.", "ic_bell", NotificationsActivity.class);
        addPromo(items, featureVisible("support"), "Suporte direto", "Converse com o atendimento SANBANK em uma tela dedicada.", "ic_support", SupportActivity.class);
        addPromo(items, featureVisible("cancel_account"), "Cancelar conta", "Registre uma solicitação protegida de encerramento.", "ic_shield", CancelAccountActivity.class);
        addPromo(items, true, "Relatar erro", "Descreva um problema do aplicativo para análise administrativa.", "ic_support", ErrorReportActivity.class);
        addPromo(items, featureVisible("about"), "Sobre o SANBANK", "Consulte informações, versão e compatibilidade do aplicativo.", "ic_update", AboutActivity.class);
        addPromo(items, true, "Mais funções", "Encontre as demais opções disponíveis para sua conta.", "ic_operations", MoreActivity.class);
        return items;
    }

    private void addPromo(List<DashboardPromoItem> items, boolean enabled, String title, String description, String iconName, Class<? extends Activity> destination) {
        if (enabled) items.add(new DashboardPromoItem(title, description, iconName, destination));
    }

    /** Carrossel de cards ilustrados: navegação manual e troca automática a cada 10 segundos. */
    private final class DashboardPromoCarousel extends LinearLayout {
        private final List<DashboardPromoItem> items;
        private final FrameLayout slideHost;
        private final TextView pageCounter;
        private final ProgressBar progress;
        private final Handler carouselHandler = new Handler(Looper.getMainLooper());
        private final Runnable autoAdvance;
        private int position;
        private boolean autoRunning;

        DashboardPromoCarousel(List<DashboardPromoItem> items) {
            super(NativeBaseActivity.this);
            this.items = items;
            this.autoAdvance = new Runnable() {
                @Override public void run() {
                    if (!autoRunning || DashboardPromoCarousel.this.items.size() < 2) return;
                    position = (position + 1) % DashboardPromoCarousel.this.items.size();
                    showSlide(true);
                    carouselHandler.postDelayed(this, 10000L);
                }
            };
            setOrientation(LinearLayout.VERTICAL);
            setPadding(0, dp(2), 0, dp(3));

            TextView title = text("Descubra as funções", 15, TEXT, true);
            addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 2));
            TextView subtitle = text("Um recurso por card · troca automática a cada 10 segundos", 10, MUTED, false);
            addView(subtitle, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(19), 0, 8));

            FrameLayout stage = new FrameLayout(NativeBaseActivity.this);
            slideHost = new FrameLayout(NativeBaseActivity.this);
            stage.addView(slideHost, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            addView(stage, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(184), 0, 8));

            LinearLayout controls = new LinearLayout(NativeBaseActivity.this);
            controls.setGravity(Gravity.CENTER_VERTICAL);
            Button previous = carouselArrow("‹");
            previous.setContentDescription("Card anterior");
            previous.setOnClickListener(v -> moveBy(-1));
            controls.addView(previous, new LinearLayout.LayoutParams(dp(38), dp(34)));
            progress = new ProgressBar(NativeBaseActivity.this, null, android.R.attr.progressBarStyleHorizontal);
            progress.setMax(Math.max(1, items.size()));
            progress.setProgress(1);
            styleProgressBar(progress);
            LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(0, dp(7), 1);
            progressParams.setMargins(dp(10), 0, dp(10), 0);
            controls.addView(progress, progressParams);
            pageCounter = text("01 / " + String.format(Locale.ROOT, "%02d", items.size()), 9, MUTED, true);
            pageCounter.setGravity(Gravity.CENTER);
            controls.addView(pageCounter, new LinearLayout.LayoutParams(dp(48), dp(30)));
            Button next = carouselArrow("›");
            next.setContentDescription("Próximo card");
            next.setOnClickListener(v -> moveBy(1));
            controls.addView(next, new LinearLayout.LayoutParams(dp(38), dp(34)));
            addView(controls, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(36), 0, 0));
            showSlide(false);
        }

        private Button carouselArrow(String symbol) {
            Button button = new Button(NativeBaseActivity.this);
            button.setText(symbol);
            button.setTextSize(22);
            button.setTextColor(Color.rgb(224, 247, 250));
            button.setGravity(Gravity.CENTER);
            button.setPadding(0, 0, 0, dp(3));
            button.setMinHeight(dp(32));
            button.setBackground(rounded(Color.argb(210, 8, 37, 54), Color.argb(86, 94, 234, 212), 14));
            return button;
        }

        private void moveBy(int delta) {
            if (items.isEmpty()) return;
            position = (position + delta + items.size()) % items.size();
            showSlide(true);
            if (autoRunning) {
                carouselHandler.removeCallbacks(autoAdvance);
                carouselHandler.postDelayed(autoAdvance, 10000L);
            }
        }

        private void showSlide(boolean animate) {
            Runnable replace = () -> {
                slideHost.removeAllViews();
                FrameLayout card = createPromoCard(items.get(position), position);
                slideHost.addView(card, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                pageCounter.setText(String.format(Locale.ROOT, "%02d / %02d", position + 1, items.size()));
                pageCounter.setContentDescription("Recurso " + (position + 1) + " de " + items.size());
                progress.setProgress(position + 1);
            };
            if (!animate) {
                replace.run();
                return;
            }
            slideHost.animate().cancel();
            slideHost.animate().alpha(0f).setDuration(150L).withEndAction(() -> {
                replace.run();
                slideHost.setAlpha(0f);
                slideHost.animate().alpha(1f).setDuration(230L).start();
            }).start();
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            startAutoAdvance();
        }

        @Override protected void onDetachedFromWindow() {
            stopAutoAdvance();
            super.onDetachedFromWindow();
        }

        void startAutoAdvance() {
            if (!activityResumed || items.size() < 2 || autoRunning) return;
            autoRunning = true;
            carouselHandler.removeCallbacks(autoAdvance);
            carouselHandler.postDelayed(autoAdvance, 10000L);
        }

        void stopAutoAdvance() {
            autoRunning = false;
            carouselHandler.removeCallbacks(autoAdvance);
        }

        private FrameLayout createPromoCard(DashboardPromoItem item, int itemIndex) {
            int[][] palette = {
                    {Color.rgb(8, 51, 86), Color.rgb(8, 104, 116), Color.rgb(11, 133, 120)},
                    {Color.rgb(30, 39, 86), Color.rgb(47, 64, 133), Color.rgb(82, 45, 122)},
                    {Color.rgb(10, 53, 71), Color.rgb(13, 104, 101), Color.rgb(35, 116, 87)},
                    {Color.rgb(57, 34, 78), Color.rgb(111, 42, 93), Color.rgb(155, 57, 77)},
                    {Color.rgb(12, 47, 83), Color.rgb(22, 96, 138), Color.rgb(27, 122, 142)}
            };
            int[] colors = palette[itemIndex % palette.length];
            FrameLayout card = new FrameLayout(NativeBaseActivity.this);
            card.setPadding(dp(17), dp(14), dp(17), dp(14));
            card.setBackground(gradient(colors[0], colors[1], colors[2], 25));
            card.setElevation(dp(3));
            card.setClickable(true);
            card.setFocusable(true);
            card.setOnClickListener(v -> { if (item.destination != null) launchModule(item.destination); });

            View halo = new View(NativeBaseActivity.this);
            halo.setBackground(rounded(Color.argb(27, 255, 255, 255), Color.argb(35, 255, 255, 255), 80));
            FrameLayout.LayoutParams haloParams = new FrameLayout.LayoutParams(dp(112), dp(112), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            haloParams.rightMargin = dp(17);
            card.addView(halo, haloParams);
            ImageView icon = new ImageView(NativeBaseActivity.this);
            icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            int iconId = getResources().getIdentifier(item.iconName, "drawable", getPackageName());
            if (iconId != 0) {
                try {
                    Drawable drawable = getResources().getDrawable(iconId).mutate();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) drawable.setTint(Color.WHITE);
                    icon.setImageDrawable(drawable);
                } catch (Exception ignored) { }
            }
            icon.setContentDescription(item.title);
            icon.setBackground(rounded(Color.argb(43, 255, 255, 255), Color.argb(79, 255, 255, 255), 22));
            FrameLayout.LayoutParams iconParams = new FrameLayout.LayoutParams(dp(63), dp(63), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            iconParams.rightMargin = dp(41);
            card.addView(icon, iconParams);

            LinearLayout textBlock = new LinearLayout(NativeBaseActivity.this);
            textBlock.setOrientation(LinearLayout.VERTICAL);
            textBlock.setPadding(0, dp(3), dp(83), dp(1));
            TextView badge = text("SANBANK  ·  RECURSO " + String.format(Locale.ROOT, "%02d", itemIndex + 1), 8, Color.rgb(221, 250, 246), true);
            badge.setPadding(dp(8), dp(4), dp(8), dp(4));
            badge.setBackground(rounded(Color.argb(43, 255, 255, 255), Color.argb(50, 255, 255, 255), 11));
            textBlock.addView(badge, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(23), 0, 7));
            TextView cardTitle = text(item.title, 17, Color.WHITE, true);
            cardTitle.setMaxLines(2);
            textBlock.addView(cardTitle, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 4));
            TextView cardDescription = text(item.description, 10, Color.rgb(226, 241, 248), false);
            cardDescription.setMaxLines(3);
            cardDescription.setLineSpacing(dp(1), 1f);
            textBlock.addView(cardDescription, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
            TextView cta = text("TOQUE PARA CONHECER  →", 8, Color.rgb(220, 252, 250), true);
            textBlock.addView(cta, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 4, 0));
            card.addView(textBlock, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return card;
        }
    }

    protected void renderNativeNeoCard(LinearLayout page, JSONObject card, TextView status) {
        page.removeAllViews();
        page.addView(text("VISÃO GERAL", 11, TEAL, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 3));
        page.addView(text("Cartão Neo Bradesco", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(34), 0, 2));
        page.addView(text("Seu cartão, limite e fatura em um só lugar.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 12));

        double total = Math.max(0, decimal(field(card, "limit_total")));
        double used = Math.min(total, Math.max(0, decimal(field(card, "limit_used"))));
        boolean resourceSecurityBlocked = isNeoCardSecurityBlocked();
        String state = field(card, "status", "ativo");
        boolean blocked = isBlockedStatus(state) || resourceSecurityBlocked;
        double available = blocked ? 0 : Math.max(0, total - used);
        double invoice = field(card, "invoice_amount").isEmpty() ? used : decimal(field(card, "invoice_amount"));
        String holder = field(card, "card_holder", field(currentUser, "name", "Cliente")).toUpperCase(Locale.ROOT);
        String cardBrand = field(card, "brand", field(card, "card_brand", "VISA")).toUpperCase(Locale.ROOT);

        String cardNumber = firstField(card, "card_number", "number");
        String lastFour = neoCardLastFour(cardNumber);
        if ("— — — —".equals(lastFour)) {
            String storedLastFour = firstField(card, "card_last_four", "last_four", "card_last4");
            lastFour = neoCardLastFour(storedLastFour);
            if (cardNumber.isEmpty()) cardNumber = storedLastFour;
        }
        NeoCardFaceView neoCard = new NeoCardFaceView(this);
        neoCard.setCardData(holder, cardBrand, cardNumber, blocked ? "BLOQUEADO" : "ATIVO", blocked);
        page.addView(neoCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));

        LinearLayout cardNumberLine = new LinearLayout(this);
        cardNumberLine.setGravity(Gravity.CENTER_VERTICAL);
        cardNumberLine.setPadding(dp(13), dp(8), dp(13), dp(8));
        cardNumberLine.setBackground(rounded(Color.argb(190, 8, 27, 45), Color.argb(70, 94, 234, 212), 15));
        cardNumberLine.addView(text("CARTÃO NEO BRADESCO", 10, MUTED, true), new LinearLayout.LayoutParams(0, dp(22), 1));
        TextView lastFourText = text("•••• " + lastFour, 13, TEXT, true);
        lastFourText.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        cardNumberLine.addView(lastFourText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(22)));
        cardNumberLine.setContentDescription("Cartão Neo Bradesco, final " + lastFour);
        page.addView(cardNumberLine, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        page.addView(buildNeoLimitOverview(total, used, available), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));

        HorizontalScrollView quickScroll = new HorizontalScrollView(this);
        quickScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        Button virtual = actionButton("Cartão virtual");
        virtual.setTextSize(12);
        virtual.setOnClickListener(v -> launchModule(NeoVirtualCardActivity.class));
        quickRow.addView(virtual, new LinearLayout.LayoutParams(dp(154), dp(66)));
        Button limit = actionButton("Limite disponível");
        limit.setTextSize(12);
        limit.setOnClickListener(v -> launchModule(NeoAvailableLimitActivity.class));
        LinearLayout.LayoutParams limitParams = new LinearLayout.LayoutParams(dp(154), dp(66));
        limitParams.setMargins(dp(9), 0, 0, 0);
        quickRow.addView(limit, limitParams);
        Button trackingQuick = actionButton("Rastreamento");
        trackingQuick.setTextSize(12);
        trackingQuick.setOnClickListener(v -> launchModule(NeoTrackingActivity.class));
        LinearLayout.LayoutParams trackingParams = new LinearLayout.LayoutParams(dp(140), dp(66));
        trackingParams.setMargins(dp(9), 0, 0, 0);
        quickRow.addView(trackingQuick, trackingParams);
        Button invoiceQuick = actionButton("Fatura / pagamento");
        invoiceQuick.setTextSize(12);
        invoiceQuick.setOnClickListener(v -> launchModule(NeoInvoiceActivity.class));
        LinearLayout.LayoutParams invoiceParams = new LinearLayout.LayoutParams(dp(154), dp(66));
        invoiceParams.setMargins(dp(9), 0, 0, 0);
        quickRow.addView(invoiceQuick, invoiceParams);
        Button sharingQuick = actionButton("Compartilhar limite");
        sharingQuick.setTextSize(12);
        sharingQuick.setOnClickListener(v -> launchModule(NeoLimitSharingActivity.class));
        LinearLayout.LayoutParams sharingParams = new LinearLayout.LayoutParams(dp(154), dp(66));
        sharingParams.setMargins(dp(9), 0, 0, 0);
        quickRow.addView(sharingQuick, sharingParams);
        Button securityQuick = actionButton("Status de segurança");
        securityQuick.setTextSize(12);
        securityQuick.setOnClickListener(v -> launchModule(NeoCardSecurityActivity.class));
        LinearLayout.LayoutParams securityParams = new LinearLayout.LayoutParams(dp(154), dp(66));
        securityParams.setMargins(dp(9), 0, 0, 0);
        quickRow.addView(securityQuick, securityParams);
        quickScroll.addView(quickRow);
        page.addView(quickScroll, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(75), 0, 14));

        String trackingCode = firstField(card, "tracking_code", "codigo_rastreio", "tracking");
        if (trackingCode.isEmpty()) trackingCode = "não informado";
        LinearLayout trackingCard = surfaceCard();
        trackingCard.setPadding(dp(15), dp(14), dp(15), dp(14));
        trackingCard.addView(text("●  Rastreamento do cartão", 15, Color.rgb(96, 165, 250), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(27), 0, 5));
        trackingCard.addView(text("Código: " + trackingCode, 17, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 3));
        trackingCard.addView(text("Status: " + field(card, "tracking_status", field(card, "status_rastreio", "Postado")), 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(23), 0, 0));
        page.addView(trackingCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        LinearLayout details = surfaceCard();
        details.addView(text("Resumo do cartão", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(27), 0, 6));
        details.addView(text("Titular: " + holder, 13, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 2));
        details.addView(text("Fatura atual: " + formatMoney(invoice), 13, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 2));
        details.addView(text("Fechamento: " + formatNeoBillingDate(firstField(card, "invoice_closing_date", "closing_date", "invoice_closing_day", "closing_day", "data_fechamento", "close_date", "invoice_close_date"), NEO_INVOICE_CLOSING_DAY), 13, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 2));
        details.addView(text("Vencimento: " + formatNeoBillingDate(firstField(card, "invoice_due_date", "due_date", "invoice_due_day", "due_day", "data_vencimento", "payment_due_date"), NEO_INVOICE_DUE_DAY), 13, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 0));
        page.addView(details, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        status.setText(resourceSecurityBlocked ? "Cartão bloqueado por segurança: limite de " + neoOperationLimit(currentUser) + " operações atingido." : (blocked ? "Cartão bloqueado ou suspenso." : "Cartão ativo e disponível para operações."));
        status.setPadding(dp(12), dp(10), dp(12), dp(10));
        status.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
        page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        Button authorizeNeo = primaryButton("Validar transação Neo com token");
        authorizeNeo.setEnabled(!blocked);
        authorizeNeo.setOnClickListener(v -> launchModule(NeoTokenApprovalActivity.class));
        page.addView(authorizeNeo, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        Button increase = primaryButton("Solicitar aumento de limite");
        increase.setOnClickListener(v -> launchModule(NeoLimitIncreaseActivity.class));
        page.addView(increase, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        Button lost = blocked ? secondaryButton("Perda ou roubo · cartão bloqueado") : primaryButton("Perdi meu Cartão / Roubo (Bloquear)");
        if (!blocked) {
            lost.setBackground(gradient(Color.rgb(96, 165, 250), Color.rgb(37, 99, 235), Color.rgb(225, 29, 72), 17));
            lost.setTextColor(Color.rgb(255, 190, 203));
        }
        lost.setOnClickListener(v -> launchModule(NeoCardLossActivity.class));
        page.addView(lost, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(54), 0, 9));
        TextView note = text("Ao sinalizar perda ou roubo, o cartão atual é cancelado imediatamente por segurança e uma 2ª via é emitida.", 11, MUTED, false);
        note.setGravity(Gravity.CENTER);
        page.addView(note, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        this.currentNeoPreviewCard = card;
    }

    protected void showNativeLimitSharingDialog(JSONObject card) {
        if (card == null || currentUser == null) return;
        if (isNeoCardSecurityBlocked() || isBlockedStatus(field(card, "status", "ativo"))) {
            Toast.makeText(this, "Não é possível compartilhar limite com o Cartão Neo bloqueado.", Toast.LENGTH_LONG).show();
            return;
        }
        double cardTotal = Math.max(0, decimal(field(card, "limit_total")));
        double cardUsed = Math.min(cardTotal, Math.max(0, decimal(field(card, "limit_used"))));
        double cardAvailable = Math.max(0, cardTotal - cardUsed);
        double overdraftTotal = overdraftTotalLimit();
        double overdraftAvailable = availableOverdraft();

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(5), dp(20), 0);
        panel.addView(text("Mova somente o limite disponível entre o Cheque Especial e o Cartão Neo.", 12, MUTED, false), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        Spinner direction = new Spinner(this);
        String[] options = {"Cheque Especial → Cartão Neo", "Cartão Neo → Cheque Especial"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, options) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(Color.rgb(219, 234, 254)); view.setTextSize(13); view.setPadding(dp(10), 0, dp(10), 0); return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        direction.setAdapter(adapter);
        panel.addView(direction, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        EditText amount = textInput("Valor a compartilhar");
        amount.setSingleLine(true);
        amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        panel.addView(amount, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        TextView info = text("", 11, MUTED, false);
        info.setPadding(0, dp(9), 0, 0);
        panel.addView(info, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        Runnable updateInfo = () -> {
            boolean fromOverdraft = direction.getSelectedItemPosition() == 0;
            double source = fromOverdraft ? overdraftAvailable : cardAvailable;
            double targetAfter = (fromOverdraft ? cardTotal : overdraftTotal) + decimal(amount.getText().toString());
            info.setText((fromOverdraft ? "Disponível no Cheque Especial: " + formatMoney(source) : "Disponível no Cartão Neo: " + formatMoney(source)) + "\nLimite total do destino após a operação: " + formatMoney(targetAfter));
        };
        direction.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { updateInfo.run(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { updateInfo.run(); }
        });
        amount.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateInfo.run(); }
            @Override public void afterTextChanged(android.text.Editable s) { }
        });
        updateInfo.run();
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Compartilhar limite")
                .setView(panel)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Compartilhar", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            boolean fromOverdraft = direction.getSelectedItemPosition() == 0;
            double source = fromOverdraft ? overdraftAvailable : cardAvailable;
            double value = decimal(amount.getText().toString());
            if (value <= 0 || value > source) {
                amount.setError("Informe um valor até " + formatMoney(source));
                return;
            }
            submitNativeLimitSharing(card, fromOverdraft, value, dialog, info, dialog.getButton(AlertDialog.BUTTON_POSITIVE));
        }));
        dialog.show();
    }

    protected void onNativeNeoCardMutationComplete() {
        openNeoCardScreen();
    }

    protected void submitNativeLimitSharing(JSONObject card, boolean fromOverdraft, double amount, AlertDialog dialog, TextView info, Button button) {
        double cardTotal = Math.max(0, decimal(field(card, "limit_total")));
        double cardUsed = Math.min(cardTotal, Math.max(0, decimal(field(card, "limit_used"))));
        double overdraftTotal = overdraftTotalLimit();
        double sourceAvailable = fromOverdraft ? availableOverdraft() : Math.max(0, cardTotal - cardUsed);
        if (amount <= 0 || amount > sourceAvailable) { info.setText("O valor ultrapassa o limite disponível para compartilhar."); return; }
        double newOverdraftTotal = fromOverdraft ? Math.max(0, overdraftTotal - amount) : overdraftTotal + amount;
        double newCardTotal = fromOverdraft ? cardTotal + amount : Math.max(cardUsed, cardTotal - amount);
        button.setEnabled(false);
        info.setText("Atualizando os dois limites...");
        JSONObject oldAccount = new JSONObject();
        JSONObject accountPayload = new JSONObject();
        try {
            oldAccount.put("overdraft_enabled", isOverdraftVisible() ? "TRUE" : "FALSE");
            oldAccount.put("overdraft_limit", String.format(Locale.US, "%.2f", overdraftTotal));
            accountPayload.put("overdraft_enabled", newOverdraftTotal > 0 ? "TRUE" : "FALSE");
            accountPayload.put("overdraft_limit", String.format(Locale.US, "%.2f", newOverdraftTotal));
            accountPayload.put("limit_sharing_direction", fromOverdraft ? "overdraft_to_neo" : "neo_to_overdraft");
            accountPayload.put("limit_sharing_amount", String.format(Locale.US, "%.2f", amount));
            accountPayload.put("limit_sharing_at", isoNow());
        } catch (Exception ignored) { }
        accountUpdate(field(currentUser, "account"), accountPayload, new RpcCallback() {
            @Override public void success(Object ignored) {
                JSONObject cardPayload = new JSONObject();
                copyJsonValues(cardPayload, card);
                try {
                    cardPayload.put("limit_total", String.format(Locale.US, "%.2f", newCardTotal));
                    cardPayload.put("limit_sharing_direction", fromOverdraft ? "overdraft_to_neo" : "neo_to_overdraft");
                    cardPayload.put("limit_sharing_amount", String.format(Locale.US, "%.2f", amount));
                    cardPayload.put("limit_sharing_at", isoNow());
                } catch (Exception ignoredCard) { }
                apiUpsert("cartoes_neo", cardPayload, new RpcCallback() {
                    @Override public void success(Object result) {
                        runOnUiThread(() -> {
                            try {
                                currentUser.put("overdraft_enabled", newOverdraftTotal > 0 ? "TRUE" : "FALSE");
                                currentUser.put("overdraft_limit", String.format(Locale.US, "%.2f", newOverdraftTotal));
                                prefs().edit().putString("session_user_json", currentUser.toString()).apply();
                            } catch (Exception ignoredUpdate) { }
                            if (dialog != null) dialog.dismiss();
                            Toast.makeText(NativeBaseActivity.this, "Limite compartilhado com sucesso.", Toast.LENGTH_LONG).show();
                            onNativeNeoCardMutationComplete();
                        });
                    }
                    @Override public void failure(String message) {
                        accountUpdate(field(currentUser, "account"), oldAccount, new RpcCallback() {
                            @Override public void success(Object ignoredRollback) { }
                            @Override public void failure(String ignoredRollback) { }
                        });
                        runOnUiThread(() -> { button.setEnabled(true); info.setText("Não foi possível atualizar o limite do Cartão Neo."); });
                    }
                });
            }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); info.setText("Não foi possível atualizar o limite do Cheque Especial."); }); }
        });
    }

    protected JSONObject currentNeoPreviewCard;

    protected String maskedCardNumber(String number) {
        if (number == null || number.length() < 4) return "•••• •••• •••• ••••";
        return "•••• •••• •••• " + number.substring(number.length() - 4);
    }

    protected boolean isBalanceSecurityBlocked(JSONObject record) {
        if (record == null) return false;
        String status = firstField(record, "balance_status", "available_balance_status", "security_status", "security_lock_reason");
        return truthy(firstField(record, "security_balance_blocked", "available_balance_blocked", "balance_security_blocked"))
                || status.toLowerCase(Locale.ROOT).matches(".*(saldo.*bloquead|balance.*blocked|bloquead.*seguran|security.*balance).*" );
    }

    protected boolean isBalanceSecurityBlocked() { return isBalanceSecurityBlocked(currentUser); }

    protected boolean isNeoCardSecurityBlocked(JSONObject record) {
        if (record == null) return false;
        String status = firstField(record, "neo_card_security_status", "card_security_status", "security_lock_card");
        return truthy(firstField(record, "neo_card_security_blocked", "card_security_blocked"))
                || status.toLowerCase(Locale.ROOT).matches(".*(cart[aã]o.*bloquead|card.*blocked|bloquead.*seguran|security.*card).*" );
    }

    protected boolean isNeoCardSecurityBlocked() { return isNeoCardSecurityBlocked(currentUser); }

    protected boolean isSecurityResourceBlocked(JSONObject record) {
        return isSecurityLocked(record) || isBalanceSecurityBlocked(record) || isNeoCardSecurityBlocked(record);
    }

    protected boolean isBlockedStatus(String status) {
        String value = String.valueOf(status == null ? "" : status).toLowerCase(Locale.US).replace(' ', '_');
        return value.contains("bloque") || value.contains("cancel") || value.contains("suspens") || "blocked".equals(value) || "suspended".equals(value);
    }

    protected void showNativeLimitIncreaseDialog(JSONObject card) {
        showNeoCardActionModal(card, "increase");
    }

    /** Modal nativo das ações do Cartão Neo: sem WebView, HTML ou JavaScript. */
    protected void showNeoCardActionModal(JSONObject card, String action) {
        closeNeoCardActionModal();
        double total = decimal(field(card, "limit_total"));
        double used = decimal(field(card, "limit_used"));
        double available = isNeoCardSecurityBlocked() ? 0 : Math.max(0, total - used);
        boolean increase = "increase".equals(action);

        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.argb(195, 2, 6, 23));
        overlay.setClickable(true);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(16), dp(18), dp(16), dp(18));
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(19), dp(18), dp(19), dp(18));
        panel.setBackground(gradient(Color.rgb(15, 38, 74), Color.rgb(21, 21, 61), Color.rgb(79, 17, 54), 26));
        panel.setElevation(dp(8));
        panel.setClickable(true);
        scroll.addView(panel, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        overlay.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = text(increase ? "↑" : "₿", 23, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(gradient(BLUE, BLUE_DEEP, RED, 15));
        heading.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(11), 0, dp(7), 0);
        titleBox.addView(text("CARTÃO NEO BRADESCO", 10, Color.rgb(125, 211, 252), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 3));
        titleBox.addView(text(increase ? "Solicitar aumento" : "Limite disponível", 19, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 0));
        heading.addView(titleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button close = secondaryButton("×");
        close.setTextSize(22);
        close.setGravity(Gravity.CENTER);
        close.setMinHeight(dp(38));
        close.setPadding(0, 0, 0, dp(2));
        close.setOnClickListener(v -> closeNeoCardActionModal());
        heading.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38)));
        panel.addView(heading, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 14));
        panel.addView(text(increase ? "Informe um novo limite total. A solicitação será enviada para análise administrativa." : "Confira o limite do Cartão Neo de forma rápida e organizada.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 15));

        final EditText newLimit;
        if (increase) {
            panel.addView(text("Novo limite total", 11, Color.rgb(199, 217, 239), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 6));
            newLimit = textInput("Ex.: 8.000,00");
            newLimit.setSingleLine(true);
            newLimit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            newLimit.setTextSize(18);
            newLimit.setPadding(dp(14), 0, dp(14), 0);
            panel.addView(newLimit, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(54), 0, 7));
            panel.addView(text("Limite atual: " + formatMoney(total) + " · o novo valor deve ser maior.", 10, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 14));
        } else {
            newLimit = null;
            LinearLayout metricRow = new LinearLayout(this);
            metricRow.setGravity(Gravity.CENTER);
            metricRow.addView(neoNativeMetric("Limite total", formatMoney(total), false), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            LinearLayout.LayoutParams usedParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            usedParams.setMargins(dp(9), 0, 0, 0);
            metricRow.addView(neoNativeMetric("Limite usado", formatMoney(used), false), usedParams);
            panel.addView(metricRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 9));
            panel.addView(neoNativeMetric("Disponível para uso", formatMoney(available), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
            int percent = total > 0 ? Math.min(100, Math.max(0, (int) Math.round((used / total) * 100))) : 0;
            LinearLayout percentRow = new LinearLayout(this);
            percentRow.setGravity(Gravity.CENTER_VERTICAL);
            percentRow.addView(text("Utilização do limite", 10, MUTED, false), new LinearLayout.LayoutParams(0, dp(20), 1));
            TextView percentText = text(percent + "%", 11, TEXT, true);
            percentText.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            percentRow.addView(percentText, new LinearLayout.LayoutParams(dp(48), dp(20)));
            panel.addView(percentRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 5));
            ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progress.setMax(100);
            progress.setProgress(percent);
            styleProgressBar(progress);
            progress.setProgressTintList(android.content.res.ColorStateList.valueOf(TEAL));
            progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.argb(60, 148, 163, 184)));
            panel.addView(progress, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(8), 0, 0));
        }

        neoActionStatus = text("", 12, MUTED, false);
        neoActionStatus.setPadding(dp(11), dp(10), dp(11), dp(10));
        neoActionStatus.setVisibility(View.GONE);
        panel.addView(neoActionStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 13));
        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER);
        Button cancel = secondaryButton("Cancelar");
        cancel.setOnClickListener(v -> closeNeoCardActionModal());
        actions.addView(cancel, new LinearLayout.LayoutParams(0, dp(50), 1));
        neoActionConfirm = primaryButton(increase ? "Solicitar análise" : "Entendi");
        if (!increase) neoActionConfirm.setOnClickListener(v -> closeNeoCardActionModal());
        else neoActionConfirm.setOnClickListener(v -> submitNativeLimitIncrease(card, newLimit, neoActionConfirm));
        LinearLayout.LayoutParams confirmParams = new LinearLayout.LayoutParams(0, dp(50), 1);
        confirmParams.setMargins(dp(9), 0, 0, 0);
        actions.addView(neoActionConfirm, confirmParams);
        panel.addView(actions, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 14));
        TextView note = text("Dados consultados da conta autenticada SANBANK BR DIGITAL.", 10, Color.rgb(130, 156, 188), false);
        note.setGravity(Gravity.CENTER);
        panel.addView(note, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));

        neoActionModal = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (increase) mainHandler.postDelayed(() -> { if (newLimit != null) newLimit.requestFocus(); }, 180L);
    }

    protected LinearLayout neoNativeMetric(String label, String value, boolean highlighted) {
        LinearLayout metric = new LinearLayout(this);
        metric.setOrientation(LinearLayout.VERTICAL);
        metric.setPadding(dp(12), dp(11), dp(12), dp(11));
        metric.setBackground(rounded(highlighted ? Color.argb(30, 16, 185, 129) : Color.argb(28, 255, 255, 255), highlighted ? Color.argb(100, 110, 231, 183) : Color.argb(45, 125, 211, 252), 16));
        boolean usedMetric = label != null && label.toLowerCase(Locale.ROOT).contains("usado");
        int metricValueColor = usedMetric ? Color.rgb(248, 113, 113) : (highlighted ? Color.rgb(110, 231, 183) : TEXT);
        int metricLabelColor = usedMetric ? Color.rgb(254, 164, 164) : MUTED;
        metric.addView(text(label, 10, metricLabelColor, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 4));
        metric.addView(text(value, 16, metricValueColor, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 0));
        return metric;
    }

    protected void setNativeNeoActionStatus(String message, boolean success) {
        if (neoActionStatus == null) return;
        neoActionStatus.setVisibility(View.VISIBLE);
        neoActionStatus.setText(message == null ? "" : message);
        neoActionStatus.setTextColor(success ? Color.rgb(187, 247, 208) : Color.rgb(254, 205, 211));
        neoActionStatus.setBackground(rounded(success ? Color.argb(30, 16, 185, 129) : Color.argb(30, 225, 29, 72), success ? Color.argb(80, 110, 231, 183) : Color.argb(80, 251, 113, 133), 13));
    }

    protected void submitNativeLimitIncrease(JSONObject card, EditText input, Button button) {
        if (input == null || button == null) return;
        if (isNeoCardSecurityBlocked()) { setNativeNeoActionStatus("O Cartão Neo está bloqueado por segurança após atingir o limite de operações.", false); return; }
        double requested = decimal(input.getText().toString());
        double current = decimal(field(card, "limit_total"));
        if (requested <= current) {
            setNativeNeoActionStatus("O novo limite precisa ser maior que " + formatMoney(current) + ".", false);
            return;
        }
        JSONObject payload = new JSONObject();
        copyJsonValues(payload, card);
        try {
            payload.put("limit_total", String.format(Locale.US, "%.2f", requested));
            payload.put("limit_increase_requested_limit", "");
            payload.put("limit_increase_status", "concluido");
            payload.put("limit_increase_requested_at", isoNow());
        } catch (Exception ignored) { }
        button.setEnabled(false);
        button.setText("Enviando...");
        setNativeNeoActionStatus("Enviando a solicitação para análise administrativa...", true);
        apiUpsert("cartoes_neo", payload, new RpcCallback() {
            @Override public void success(Object result) {
                runOnUiThread(() -> {
                    setNativeNeoActionStatus("Limite atualizado com sucesso. Recarregando o cartão...", true);
                    mainHandler.postDelayed(() -> { closeNeoCardActionModal(); Toast.makeText(NativeBaseActivity.this, "Limite do Cartão Neo atualizado.", Toast.LENGTH_LONG).show(); openNeoCardScreen(); }, 1100L);
                });
            }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); button.setText("Solicitar análise"); setNativeNeoActionStatus(message, false); }); }
        });
    }

    protected void closeNeoCardActionModal() {
        if (neoActionModal == null) return;
        try { root.removeView(neoActionModal); } catch (Exception ignored) { }
        neoActionModal = null;
        neoActionStatus = null;
        neoActionConfirm = null;
    }

    protected void confirmNativeCardBlock(JSONObject card) {
        new AlertDialog.Builder(this).setTitle("Comunicar perda ou roubo").setMessage("O cartão será bloqueado imediatamente. Deseja continuar?").setNegativeButton("Cancelar", null).setPositiveButton("Bloquear cartão", (dialog, which) -> {
            JSONObject payload = new JSONObject(); copyJsonValues(payload, card);
            try { payload.put("status", "cancelado_perda"); payload.put("blocked_at", isoNow()); } catch (Exception ignored) { }
            apiUpsert("cartoes_neo", payload, new RpcCallback() {
                @Override public void success(Object result) { runOnUiThread(() -> { Toast.makeText(NativeBaseActivity.this, "Cartão bloqueado por segurança.", Toast.LENGTH_LONG).show(); onNativeNeoCardMutationComplete(); }); }
                @Override public void failure(String message) { runOnUiThread(() -> Toast.makeText(NativeBaseActivity.this, message, Toast.LENGTH_LONG).show()); }
            });
        }).show();
    }

    protected void openPixScreen() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);
        page.addView(text("Pix com Cartão Neo", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 3));
        page.addView(text("Solicitação em 3 etapas: dados, revisão e aprovação", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 14));
        TextView cardStatus = text("Consultando cartão e limite disponível...", 13, MUTED, false); cardStatus.setPadding(dp(12), dp(10), dp(12), dp(10)); cardStatus.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
        page.addView(cardStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        EditText amount = textInput("Valor enviado ao Pix"); amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); amount.setSingleLine(true);
        page.addView(amount, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(54), 0, 9));
        EditText key = textInput("Chave Pix do destinatário"); key.setSingleLine(true); key.setInputType(InputType.TYPE_CLASS_TEXT);
        page.addView(key, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(54), 0, 9));
        CheckBox parcelado = new CheckBox(this); parcelado.setText("Pix parcelado de 2 a 48 vezes"); parcelado.setTextColor(TEXT); parcelado.setButtonTintList(android.content.res.ColorStateList.valueOf(BLUE));
        page.addView(parcelado, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(42), 0, 4));
        EditText installments = textInput("Número de parcelas (2 a 48)"); installments.setInputType(InputType.TYPE_CLASS_NUMBER); installments.setSingleLine(true); installments.setText("2");
        page.addView(installments, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(54), 0, 9));
        CheckBox approval = new CheckBox(this); approval.setText("Confirmo a aprovação de segurança obrigatória"); approval.setTextColor(TEXT); approval.setChecked(true); approval.setButtonTintList(android.content.res.ColorStateList.valueOf(BLUE));
        page.addView(approval, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(42), 0, 8));
        TextView summary = text("Taxa: R$ 2,00 + 4% · O envio depende de aprovação administrativa.", 13, MUTED, false); summary.setPadding(dp(12), dp(12), dp(12), dp(12)); summary.setBackground(rounded(Color.argb(24, 225, 29, 72), Color.argb(72, 251, 113, 133), 14));
        page.addView(summary, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        Button submit = primaryButton("Solicitar aprovação segura"); page.addView(submit, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(54), 0, 9));
        TextView status = text("", 12, MUTED, false); status.setGravity(Gravity.CENTER); page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(42), 0, 9));
        Button back = secondaryButton("Voltar ao painel"); page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 0)); back.setOnClickListener(v -> showDashboard());
        scroll.addView(page); root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final JSONObject[] cardHolder = {null};
        listTab("cartoes_neo", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) { JSONObject card = normalizeRecord(latestRecord(records)); cardHolder[0] = card; runOnUiThread(() -> { if (card == null) cardStatus.setText("Nenhum Cartão Neo encontrado."); else updatePixCardStatus(cardStatus, card); }); }
            @Override public void failure(String message) { runOnUiThread(() -> cardStatus.setText("Não foi possível consultar o Cartão Neo.")); }
        });
        submit.setOnClickListener(v -> submitNativePix(cardHolder[0], amount, key, parcelado, installments, approval, submit, status));
    }

    protected void updatePixCardStatus(TextView status, JSONObject card) {
        double available = isNeoCardSecurityBlocked() ? 0 : Math.max(0, decimal(field(card, "limit_total")) - decimal(field(card, "limit_used")));
        String state = isNeoCardSecurityBlocked() ? "BLOQUEADO POR SEGURANÇA" : field(card, "status", "ativo").toUpperCase(Locale.ROOT);
        status.setText("Neo final " + maskedCardNumber(field(card, "card_number")).replace("•••• •••• •••• ", "") + " · disponível " + formatMoney(available) + " · " + state);
    }

    protected void submitNativePix(JSONObject card, EditText amountInput, EditText keyInput, CheckBox parcelado, EditText installmentsInput, CheckBox approval, Button button, TextView status) {
        if (card == null) { status.setText("Nenhum Cartão Neo disponível."); return; }
        if (isBlockedStatus(field(card, "status", "ativo")) || isNeoCardSecurityBlocked()) { status.setText(isNeoCardSecurityBlocked() ? "O Cartão Neo está bloqueado por segurança após atingir o limite de operações." : "O Cartão Neo está bloqueado."); return; }
        double amount = decimal(amountInput.getText().toString());
        String key = keyInput.getText().toString().trim();
        boolean isInstallment = parcelado.isChecked();
        int installments = isInstallment ? number(installmentsInput.getText().toString()) : 1;
        double fee = roundMoney(2.0 + (amount * 0.04));
        double total = roundMoney(amount + fee);
        double available = Math.max(0, decimal(field(card, "limit_total")) - decimal(field(card, "limit_used")));
        if (amount <= 0) { status.setText("Informe um valor maior que zero."); return; }
        if (key.length() < 3) { status.setText("Informe uma chave Pix válida."); return; }
        if (isInstallment && (installments < 2 || installments > 48)) { status.setText("Escolha entre 2 e 48 parcelas."); return; }
        if (!approval.isChecked()) { status.setText("A aprovação de segurança é obrigatória."); return; }
        if (total > available) { status.setText("O total da fatura excede o limite disponível de " + formatMoney(available) + "."); return; }
        if (!nativePixSecurityCheckPassed) {
            button.setEnabled(false);
            status.setText("Validando o limite de segurança do Cartão Neo...");
            countNeoOperations(field(currentUser, "account"), new OperationCallback() {
                @Override public void success(int count) {
                    int unlockedCount = number(field(currentUser, "security_unlock_usage_count"));
                    int operationLimit = neoOperationLimit(currentUser);
                    if (count >= operationLimit && count > unlockedCount) {
                        blockAvailableBalanceAndNeoCard(count);
                        runOnUiThread(() -> {
                            nativePixSecurityCheckPassed = false;
                            button.setEnabled(true);
                            status.setText("Transação bloqueada: saldo disponível e Cartão Neo bloqueados após " + operationLimit + " operações.");
                            showDashboard();
                        });
                    } else {
                        nativePixSecurityCheckPassed = true;
                        runOnUiThread(() -> submitNativePix(card, amountInput, keyInput, parcelado, installmentsInput, approval, button, status));
                    }
                }
                @Override public void failure(String message) {
                    nativePixSecurityCheckPassed = false;
                    runOnUiThread(() -> { button.setEnabled(true); status.setText("Não foi possível validar a segurança da transação. Tente novamente."); });
                }
            });
            return;
        }
        nativePixSecurityCheckPassed = false;
        double monthly = isInstallment ? roundMoney(total / installments) : total;
        String txId = "TX" + System.currentTimeMillis();
        JSONObject metadata = new JSONObject();
        try {
            metadata.put("pix_key", key); metadata.put("payment_mode", isInstallment ? "parcelado" : "avista"); metadata.put("installments", installments);
            metadata.put("fee_fixed", 2.0); metadata.put("fee_percent", 4.0); metadata.put("fee_total", fee); metadata.put("invoice_total", total); metadata.put("monthly_installment", monthly);
            metadata.put("card_account", field(currentUser, "account")); metadata.put("card_last_four", lastFour(field(card, "card_number"))); metadata.put("security_approval", true); metadata.put("settlement_model", "pix_sent_upfront_card_invoice"); metadata.put("provider_status", "awaiting_official_provider"); metadata.put("sender_account", field(currentUser, "account")); metadata.put("target_account", "");
        } catch (Exception error) { status.setText("Não foi possível preparar os dados do Pix."); return; }
        JSONObject tx = new JSONObject();
        try {
            tx.put("id", txId); tx.put("sender", field(currentUser, "account")); tx.put("sender_account", field(currentUser, "account")); tx.put("target", ""); tx.put("target_account", ""); tx.put("amount", String.format(Locale.US, "%.2f", amount));
            tx.put("title", "Pix " + (isInstallment ? "parcelado" : "à vista") + " via Neo Bradesco");
            tx.put("description", "Pix via cartão Neo — conta de saída " + field(currentUser, "account") + ". SANBANK_TYPE:PIX_CARTAO_NEO PIX_CARTAO_META:" + metadata.toString());
            tx.put("transaction_type", "PIX_CARTAO_NEO"); tx.put("type", "PIX_CARTAO_NEO"); tx.put("date", isoNow()); tx.put("status", "pending"); tx.put("operation_data", metadata.toString());
        } catch (Exception error) { status.setText("Não foi possível preparar a solicitação."); return; }
        button.setEnabled(false); status.setText("Enviando para aprovação administrativa...");
        apiUpsert("pendentes", tx, new RpcCallback() {
            @Override public void success(Object result) { trackPendingTransaction(tx); runOnUiThread(() -> { button.setEnabled(true); status.setText("Solicitação enviada. Aguardando confirmação do administrador."); openOperationStatusActivity(PixNeoOperationActivity.class, tx, metadata); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); status.setText(message); }); }
        });
    }

    protected double roundMoney(double value) { return Math.round(value * 100.0) / 100.0; }
    protected String lastFour(String number) { String clean = String.valueOf(number == null ? "" : number).replaceAll("\\D", ""); return clean.length() >= 4 ? clean.substring(clean.length() - 4) : "••••"; }

    protected void openOperationStatusActivity(Class<? extends Activity> activity, JSONObject tx, JSONObject metadata) {
        if (activity == null || tx == null) return;
        Intent intent = new Intent(this, activity);
        intent.putExtra("operation_id", field(tx, "id"));
        intent.putExtra("operation_kind", field(tx, "transaction_type", "type"));
        intent.putExtra("operation_metadata", metadata == null ? "{}" : metadata.toString());
        startActivity(intent);
    }

    protected void showPixReceiptDialog(JSONObject tx, JSONObject metadata, String status) {
        double amount = decimal(field(tx, "amount")); double fee = decimal(field(metadata, "fee_total")); double total = decimal(field(metadata, "invoice_total")); int installments = number(field(metadata, "installments"));
        String mode = "parcelado".equalsIgnoreCase(field(metadata, "payment_mode")) ? "Pix parcelado" : "Pix à vista";
        String message = "Status: Solicitação registrada / aguardando aprovação\n\nIdentificador: " + field(tx, "id") + "\nValor enviado: " + formatMoney(amount) + "\nTaxa Pix: " + formatMoney(fee) + "\nTotal previsto na fatura: " + formatMoney(total) + "\nForma: " + mode + ("Pix parcelado".equals(mode) ? "\nParcelas: " + installments + "x de aproximadamente " + formatMoney(decimal(field(metadata, "monthly_installment"))) : "") + "\nChave Pix: " + field(metadata, "pix_key") + "\n\nO envio externo depende do provedor Pix oficial.";
        new AlertDialog.Builder(this).setTitle("Comprovante Pix").setMessage(message).setNegativeButton("Fechar", null).setNeutralButton("Compartilhar PDF", (dialog, which) -> sharePixReceipt(tx, metadata)).setPositiveButton("Abrir PDF", (dialog, which) -> openPixReceipt(tx, metadata)).show();
    }

    protected void openPixReceipt(JSONObject tx, JSONObject metadata) { Uri uri = createPixReceiptUri(tx, metadata); if (uri != null) openPdf(uri); }
    protected void sharePixReceipt(JSONObject tx, JSONObject metadata) { Uri uri = createPixReceiptUri(tx, metadata); if (uri == null) return; try { Intent intent = new Intent(Intent.ACTION_SEND); intent.setType("application/pdf"); intent.putExtra(Intent.EXTRA_STREAM, uri); intent.putExtra(Intent.EXTRA_TEXT, "Comprovante Pix SANBANK BR DIGITAL"); intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(Intent.createChooser(intent, "Compartilhar comprovante Pix")); } catch (ActivityNotFoundException error) { Toast.makeText(this, "Nenhum aplicativo disponível para compartilhar o PDF.", Toast.LENGTH_LONG).show(); } }

    protected Uri createPixReceiptUri(JSONObject tx, JSONObject metadata) {
        String safe = field(tx, "id", "pix").replaceAll("[^a-zA-Z0-9_-]", "-"); File folder = new File(getCacheDir(), "shared"); if (!folder.exists() && !folder.mkdirs()) return null; File file = new File(folder, "comprovante-pix-" + safe + ".pdf");
        PdfDocument document = new PdfDocument(); PdfDocument.Page page = document.startPage(new PdfDocument.PageInfo.Builder(595, 842, 1).create()); Canvas canvas = page.getCanvas(); Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG); canvas.drawColor(Color.rgb(7, 16, 35));
        paint.setColor(Color.rgb(139, 220, 255)); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(12); canvas.drawText("SANBANK BR DIGITAL", 28, 35, paint); paint.setColor(Color.WHITE); paint.setTextSize(25); canvas.drawText("Comprovante Pix", 28, 78, paint); paint.setColor(Color.rgb(251, 191, 36)); paint.setTextSize(13); canvas.drawText("Solicitação registrada / aguardando aprovação", 28, 106, paint); paint.setColor(Color.rgb(69, 111, 255)); canvas.drawRect(28, 123, 567, 126, paint);
        String[][] rows = {{"Identificador", field(tx, "id")}, {"Data", field(tx, "date")}, {"Conta de saída", field(metadata, "sender_account", field(currentUser, "account"))}, {"Chave Pix", field(metadata, "pix_key")}, {"Valor enviado", formatMoney(decimal(field(tx, "amount")))}, {"Taxa Pix", formatMoney(decimal(field(metadata, "fee_total")))}, {"Total na fatura", formatMoney(decimal(field(metadata, "invoice_total")))}, {"Forma de pagamento", "parcelado".equalsIgnoreCase(field(metadata, "payment_mode")) ? "Pix parcelado" : "Pix à vista"}, {"Parcelas", String.valueOf(number(field(metadata, "installments"))) + "x de " + formatMoney(decimal(field(metadata, "monthly_installment")))}, {"Cartão", "Neo Bradesco · final " + field(metadata, "card_last_four", "••••")}};
        int y = 160; paint.setTextSize(11); for (String[] row : rows) { paint.setColor(Color.rgb(159, 197, 232)); paint.setTypeface(Typeface.DEFAULT_BOLD); canvas.drawText(row[0] + ":", 28, y, paint); paint.setColor(Color.WHITE); paint.setTypeface(Typeface.DEFAULT); canvas.drawText(shortText(row[1], 60), 170, y, paint); y += 38; }
        paint.setColor(Color.rgb(130, 152, 180)); paint.setTextSize(9); canvas.drawText("Este comprovante registra os dados da solicitação no SANBANK BR DIGITAL.", 28, 780, paint); canvas.drawText("O envio externo depende da confirmação do provedor Pix oficial.", 28, 798, paint); document.finishPage(page);
        try (OutputStream output = new FileOutputStream(file)) { document.writeTo(output); document.close(); return SanbankFileProvider.uriForFile(this, file, "shared"); } catch (Exception error) { try { document.close(); } catch (Exception ignored) { } Toast.makeText(this, "Não foi possível preparar o comprovante PDF.", Toast.LENGTH_LONG).show(); return null; }
    }

    protected void addAction(GridLayout grid, String label, final Runnable action) {
        Button item = actionButton(label);
        item.setTextSize(12);
        item.setOnClickListener(v -> action.run());
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = dp(106);
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.setMargins(dp(4), dp(4), dp(4), dp(4));
        grid.addView(item, params);
    }

    protected void openSecurityModule() {
        if ("admin".equalsIgnoreCase(field(currentUser, "role"))) showAdminSecurityScreen();
        else showSecurityStatus(number(field(currentUser, "security_lock_count")));
    }

    protected void showSecurityStatus(int count) {
        boolean resourcesBlocked = isBalanceSecurityBlocked() || isNeoCardSecurityBlocked();
        new AlertDialog.Builder(this)
                .setTitle("Segurança do Cartão Neo")
                .setMessage("Limite automático: " + neoOperationLimit(currentUser) + " operações.\nOperações agrupadas nesta sessão: " + count + ".\n\n" + (resourcesBlocked ? "O saldo disponível e o Cartão Neo estão bloqueados por segurança. O desbloqueio administrativo será recebido automaticamente." : "O saldo disponível e o Cartão Neo permanecem liberados até atingir o limite de operações."))
                .setPositiveButton("Entendi", null)
                .show();
    }

    /** O limite restante do cheque especial acompanha o saldo negativo utilizado. */
    protected boolean isOverdraftVisible() {
        return currentUser != null
                && truthy(firstField(currentUser, "overdraft_enabled", "overdraftEnabled"))
                && decimal(firstField(currentUser, "overdraft_limit", "overdraftLimit")) > 0;
    }

    protected double overdraftTotalLimit() {
        return isOverdraftVisible() ? Math.max(0, decimal(firstField(currentUser, "overdraft_limit", "overdraftLimit"))) : 0;
    }

    protected double normalizedInterestRate(String raw, double fallback) {
        double value = decimal(raw);
        if (value <= 0) return fallback;
        return value > 1 ? value / 100.0 : value;
    }

    protected double overdraftInterestRate() {
        return normalizedInterestRate(firstField(currentUser, "overdraft_interest_rate", "overdraft_interest", "interest_rate"), DEFAULT_OVERDRAFT_INTEREST_RATE);
    }

    protected int overdraftGraceDays() {
        int days = number(firstField(currentUser, "overdraft_grace_days", "overdraft_grace_period_days"));
        return days > 0 ? days : DEFAULT_OVERDRAFT_GRACE_DAYS;
    }

    protected double overdraftUsedAmount() {
        if (currentUser == null) return 0;
        return Math.max(0, -decimal(field(currentUser, "balance")));
    }

    protected double overdraftInterestAmount(JSONObject source) {
        String explicit = firstField(source, "interest_amount", "overdraft_interest_amount", "juros_cobrados", "juros_amount");
        if (!explicit.isEmpty() && decimal(explicit) > 0) return roundMoney(decimal(explicit));
        double borrowed = decimal(firstField(source, "max_borrowed_amount", "borrowed_amount", "overdraft_used_amount"));
        if (borrowed <= 0) borrowed = overdraftUsedAmount();
        double rate = normalizedInterestRate(firstField(source, "interest_rate", "overdraft_interest_rate"), overdraftInterestRate());
        return roundMoney(Math.max(0, borrowed) * rate);
    }

    protected boolean overdraftInterestIsDue(JSONObject record) {
        if (record == null) return false;
        if (truthy(firstField(record, "interest_due", "overdraft_interest_due", "charge_interest", "overdue"))) return true;
        String status = firstField(record, "status", "overdraft_auto_status", "interest_charge_status").toLowerCase(Locale.ROOT);
        return status.matches(".*(atrasad|overdue|juros.*devid|interest.*due|cobran[cç]a).*" );
    }

    protected void syncOverdraftInterest() {
        if (currentUser == null || "admin".equalsIgnoreCase(field(currentUser, "role")) || !isOverdraftVisible()) return;
        long now = System.currentTimeMillis();
        if (overdraftInterestSyncInProgress || now - lastOverdraftInterestSyncAt < 15000L) return;
        overdraftInterestSyncInProgress = true;
        lastOverdraftInterestSyncAt = now;
        String account = field(currentUser, "account");
        listTab("analise_cheque_especial", account, new ListCallback() {
            @Override public void success(JSONArray records) {
                JSONObject due = null;
                for (int i = records.length() - 1; i >= 0; i--) {
                    JSONObject item = records.optJSONObject(i);
                    if (item == null || !overdraftInterestIsDue(item)) continue;
                    String charged = firstField(item, "interest_charge_status", "interest_charged");
                    if ("TRUE".equalsIgnoreCase(charged) || "charged".equalsIgnoreCase(charged) || "concluido".equalsIgnoreCase(charged) || "concluído".equalsIgnoreCase(charged)) continue;
                    if (overdraftInterestAmount(item) > 0) { due = item; break; }
                }
                if (due == null) { overdraftInterestSyncInProgress = false; return; }
                final JSONObject candidate = due;
                final String usageId = firstField(candidate, "usage_id", "id", "overdraft_usage_id");
                final double interest = overdraftInterestAmount(candidate);
                listTab("extrato", account, new ListCallback() {
                    @Override public void success(JSONArray statement) {
                        String chargeId = "JUROS-CHEQUE-" + (usageId.isEmpty() ? account : usageId);
                        for (int i = 0; i < statement.length(); i++) {
                            JSONObject item = statement.optJSONObject(i);
                            if (item != null && chargeId.equals(firstField(item, "id", "transaction_id"))) { overdraftInterestSyncInProgress = false; return; }
                        }
                        queueOverdraftInterestCharge(candidate, chargeId, interest);
                    }
                    @Override public void failure(String ignored) { overdraftInterestSyncInProgress = false; }
                });
            }
            @Override public void failure(String ignored) { overdraftInterestSyncInProgress = false; }
        });
    }

    /** Cobra os juros automaticamente, sem criar pendência de aprovação administrativa. */
    protected void queueOverdraftInterestCharge(JSONObject analysis, String chargeId, double interest) {
        if (currentUser == null || interest <= 0) { overdraftInterestSyncInProgress = false; return; }
        final String account = field(currentUser, "account");
        final double oldBalance = decimal(field(currentUser, "balance"));
        final double newBalance = roundMoney(oldBalance - interest);
        JSONObject accountPayload = new JSONObject();
        try {
            accountPayload.put("balance", String.format(Locale.US, "%.2f", newBalance));
            accountPayload.put("overdraft_interest_last_charge_amount", String.format(Locale.US, "%.2f", interest));
            accountPayload.put("overdraft_interest_last_charge_at", isoNow());
            accountPayload.put("overdraft_interest_last_destination", OVERDRAFT_INTEREST_FUND_ACCOUNT);
        } catch (Exception ignored) { }
        accountUpdate(account, accountPayload, new RpcCallback() {
            @Override public void success(Object ignored) {
                JSONObject metadata = new JSONObject();
                try {
                    metadata.put("interest_rate", overdraftInterestRate());
                    metadata.put("grace_days", overdraftGraceDays());
                    metadata.put("overdraft_usage_id", firstField(analysis, "usage_id", "id"));
                    metadata.put("fund_name", "Fundo de emergência SANBANK BR DIGITAL");
                    metadata.put("fund_account", OVERDRAFT_INTEREST_FUND_ACCOUNT);
                    metadata.put("charge_type", "JUROS_CHEQUE_ESPECIAL");
                    metadata.put("approval_required", false);
                    metadata.put("settlement_mode", "automatic");
                } catch (Exception ignoredError) { }
                JSONObject tx = new JSONObject();
                try {
                    tx.put("id", chargeId);
                    tx.put("account", account);
                    tx.put("sender", account);
                    tx.put("sender_account", account);
                    tx.put("target", OVERDRAFT_INTEREST_FUND_ACCOUNT);
                    tx.put("target_account", OVERDRAFT_INTEREST_FUND_ACCOUNT);
                    tx.put("amount", String.format(Locale.US, "%.2f", interest));
                    tx.put("title", "Juros do Cheque Especial");
                    tx.put("description", "Cobrança automática de juros do Cheque Especial. Destino: Fundo de emergência SANBANK BR DIGITAL, conta " + OVERDRAFT_INTEREST_FUND_ACCOUNT + ". Sem aprovação administrativa. SANBANK_TYPE:JUROS_CHEQUE_ESPECIAL SANBANK_META:" + metadata.toString());
                    tx.put("transaction_type", "JUROS_CHEQUE_ESPECIAL");
                    tx.put("type", "out");
                    tx.put("date", isoNow());
                    tx.put("status", "completed");
                    tx.put("approval_required", false);
                    tx.put("approved_by", "SANBANK_AUTOMATIC_OVERDRAFT_INTEREST");
                    tx.put("settlement_status", "completed");
                    tx.put("bank_funds", OVERDRAFT_INTEREST_FUND_ACCOUNT);
                    tx.put("operation_data", metadata.toString());
                } catch (Exception error) {
                    overdraftInterestSyncInProgress = false;
                    return;
                }
                apiUpsert("extrato", tx, new RpcCallback() {
                    @Override public void success(Object result) {
                        try {
                            currentUser.put("balance", String.format(Locale.US, "%.2f", newBalance));
                            currentUser.put("overdraft_interest_last_charge_amount", String.format(Locale.US, "%.2f", interest));
                            currentUser.put("overdraft_interest_last_destination", OVERDRAFT_INTEREST_FUND_ACCOUNT);
                            prefs().edit().putString("session_user_json", currentUser.toString()).apply();
                        } catch (Exception ignored) { }
                        JSONObject update = new JSONObject();
                        copyJsonValues(update, analysis);
                        try {
                            update.put("interest_charge_status", "charged");
                            update.put("interest_charged", "TRUE");
                            update.put("interest_amount", String.format(Locale.US, "%.2f", interest));
                            update.put("interest_destination_account", OVERDRAFT_INTEREST_FUND_ACCOUNT);
                            update.put("interest_destination_name", "Fundo de emergência SANBANK BR DIGITAL");
                            update.put("interest_charged_at", isoNow());
                            update.put("approval_required", false);
                        } catch (Exception ignored) { }
                        apiDelete("pendentes", chargeId, new RpcCallback() {
                            @Override public void success(Object ignored) { }
                            @Override public void failure(String ignored) { }
                        });
                        apiUpsert("analise_cheque_especial", update, new RpcCallback() {
                            @Override public void success(Object ignored) { overdraftInterestSyncInProgress = false; }
                            @Override public void failure(String ignored) { overdraftInterestSyncInProgress = false; }
                        });
                    }
                    @Override public void failure(String ignored) {
                        JSONObject rollback = new JSONObject();
                        try { rollback.put("balance", String.format(Locale.US, "%.2f", oldBalance)); } catch (Exception error) { }
                        accountUpdate(account, rollback, new RpcCallback() {
                            @Override public void success(Object ignored) { overdraftInterestSyncInProgress = false; }
                            @Override public void failure(String ignored) { overdraftInterestSyncInProgress = false; }
                        });
                    }
                });
            }
            @Override public void failure(String ignored) { overdraftInterestSyncInProgress = false; }
        });
    }

    protected double availableOverdraft() {
        if (isBalanceSecurityBlocked()) return 0;
        if (!isOverdraftVisible()) return 0;
        double balance = decimal(field(currentUser, "balance"));
        double totalLimit = overdraftTotalLimit();
        if (balance < 0) return Math.max(0, totalLimit + balance);
        return totalLimit;
    }

    /** Poder de uso: saldo positivo + limite restante do cheque especial. */
    protected double transferAvailable() {
        if (isBalanceSecurityBlocked()) return 0;
        double balance = decimal(field(currentUser, "balance"));
        return Math.max(0, balance) + availableOverdraft();
    }

    protected LinearLayout stageCard(String title) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(14), dp(15), dp(14));
        card.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 18));
        card.addView(text(title, 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 9));
        return card;
    }

    /** Converte estritamente o valor digitado na transferência DEM; nunca trata a vírgula/ponto como multiplicador. */
    protected double parseDemTransferAmount(String inputValue) {
        String raw = String.valueOf(inputValue == null ? "" : inputValue).trim();
        if (raw.isEmpty()) return 0;
        raw = raw.replace("R$", "").trim();
        if (raw.isEmpty() || raw.matches(".*\\s+.*") || raw.startsWith("-") || raw.startsWith("+")) return Double.NaN;

        String normalized;
        if (raw.matches("\\d+")) {
            normalized = raw;
        } else if (raw.matches("\\d+[,.]\\d{1,2}")) {
            normalized = raw.replace(',', '.');
        } else if (raw.matches("\\d{1,3}(?:\\.\\d{3})+,\\d{1,2}")) {
            normalized = raw.replace(".", "").replace(',', '.');
        } else if (raw.matches("\\d{1,3}(?:,\\d{3})+\\.\\d{1,2}")) {
            normalized = raw.replace(",", "");
        } else if (raw.matches("\\d{1,3}(?:\\.\\d{3})+")) {
            normalized = raw.replace(".", "");
        } else if (raw.matches("\\d{1,3}(?:,\\d{3})+")) {
            normalized = raw.replace(",", "");
        } else {
            return Double.NaN;
        }

        try {
            double amount = Double.parseDouble(normalized);
            if (Double.isNaN(amount) || Double.isInfinite(amount)) return Double.NaN;
            return roundMoney(amount);
        } catch (Exception ignored) {
            return Double.NaN;
        }
    }

    protected boolean isValidDemTransferAmount(double amount) {
        return !Double.isNaN(amount) && !Double.isInfinite(amount) && amount > 0;
    }

    protected void openDemScreen() {
        stopSupportPolling();
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);
        page.addView(text("Transferência DEM", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 3));
        page.addView(text("Fluxo nativo em 4 etapas com aprovação administrativa", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 14));
        TextView available = text("Disponível para transferência: " + formatMoney(transferAvailable()), 13, Color.rgb(191, 219, 254), true); available.setPadding(dp(12), dp(10), dp(12), dp(10)); available.setBackground(rounded(Color.argb(24, 16, 185, 129), Color.argb(75, 110, 231, 183), 14)); page.addView(available, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        LinearLayout stage1 = stageCard("Etapa 1 — informe o valor");
        EditText amount = textInput("Ex.: 5 ou 5,00"); amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); amount.setSingleLine(true); stage1.addView(amount, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(54), 0, 9));
        TextView amountStatus = text("Digite o valor em reais; 5 será interpretado como R$ 5,00.", 12, MUTED, false); stage1.addView(amountStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(36), 0, 8));
        amount.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String entered = s == null ? "" : s.toString();
                if (entered.trim().isEmpty()) { amountStatus.setText("Digite o valor em reais; 5 será interpretado como R$ 5,00."); return; }
                double enteredAmount = parseDemTransferAmount(entered);
                if (!isValidDemTransferAmount(enteredAmount)) amountStatus.setText("Formato inválido. Use, por exemplo, 5 ou 5,00 (até duas casas decimais).");
                else amountStatus.setText("Valor interpretado: " + formatMoney(enteredAmount) + " — esse valor será enviado.");
            }
            @Override public void afterTextChanged(android.text.Editable s) { }
        });
        Button next1 = primaryButton("Continuar para destinatário"); stage1.addView(next1, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0)); page.addView(stage1, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        LinearLayout stage2 = stageCard("Etapa 2 — destinatário validado"); stage2.setVisibility(View.GONE);
        EditText target = input("Conta de destino com 6 dígitos", false); target.setMaxLines(1); stage2.addView(target, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        TextView targetStatus = text("Informe a conta e valide os dados do destinatário.", 12, MUTED, false); stage2.addView(targetStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        Button validateTarget = secondaryButton("Validar destinatário"); stage2.addView(validateTarget, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8));
        Button next2 = primaryButton("Continuar para revisão"); next2.setEnabled(false); stage2.addView(next2, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0)); page.addView(stage2, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        LinearLayout stage3 = stageCard("Etapa 3 — revisão da operação"); stage3.setVisibility(View.GONE);
        TextView review = text("Revise os dados antes de confirmar.", 13, MUTED, false); review.setPadding(dp(10), dp(10), dp(10), dp(10)); review.setBackground(rounded(Color.argb(20, 255, 255, 255), Color.argb(55, 148, 163, 184), 12)); stage3.addView(review, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        Button next3 = primaryButton("Continuar para aprovação"); stage3.addView(next3, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0)); page.addView(stage3, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        LinearLayout stage4 = stageCard("Etapa 4 — envio para aprovação"); stage4.setVisibility(View.GONE);
        CheckBox security = new CheckBox(this); security.setText("Confirmo os dados e autorizo a análise administrativa"); security.setTextColor(TEXT); security.setButtonTintList(android.content.res.ColorStateList.valueOf(BLUE)); stage4.addView(security, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8));
        TextView submitStatus = text("A confirmação é obrigatória para enviar.", 12, MUTED, false); stage4.addView(submitStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        Button submit = primaryButton("Enviar para aprovação"); submit.setEnabled(false); stage4.addView(submit, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(54), 0, 0)); page.addView(stage4, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        Button back = secondaryButton("Voltar ao painel"); page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 0)); back.setOnClickListener(v -> showDashboard());
        scroll.addView(page); root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final JSONObject[] recipient = {null};
        final int[] currentStage = {1};
        Runnable showStage = () -> { stage1.setVisibility(currentStage[0] == 1 ? View.VISIBLE : View.GONE); stage2.setVisibility(currentStage[0] == 2 ? View.VISIBLE : View.GONE); stage3.setVisibility(currentStage[0] == 3 ? View.VISIBLE : View.GONE); stage4.setVisibility(currentStage[0] == 4 ? View.VISIBLE : View.GONE); };
        next1.setOnClickListener(v -> {
            double value = parseDemTransferAmount(amount.getText().toString());
            if (!isValidDemTransferAmount(value)) { amountStatus.setText("Formato ou valor inválido. Digite, por exemplo, 5 ou 5,00."); return; }
            amountStatus.setText("Valor conferido: " + formatMoney(value) + ". O saldo será conferido após a aprovação administrativa.");
            currentStage[0] = 2; showStage.run();
        });
        validateTarget.setOnClickListener(v -> { String account = target.getText().toString().trim(); if (!account.matches("\\d{6}")) { targetStatus.setText("A conta precisa ter 6 dígitos."); return; } if (account.equals(field(currentUser, "account"))) { targetStatus.setText("A conta de destino não pode ser a própria conta."); return; } validateTarget.setEnabled(false); targetStatus.setText("Consultando conta de destino..."); JSONObject body = new JSONObject(); try { body.put("p_account", account); body.put("p_role", JSONObject.NULL); } catch (Exception ignored) { } rpc("sanbank_account_search", body, new RpcCallback() { @Override public void success(Object result) { JSONObject found = firstObject(result); runOnUiThread(() -> { validateTarget.setEnabled(true); recipient[0] = found == null ? null : normalizeRecord(found); if (recipient[0] == null) { targetStatus.setText("Conta não encontrada."); next2.setEnabled(false); } else { targetStatus.setText("Destinatário validado: " + field(recipient[0], "name", "Conta " + account) + " · conta " + field(recipient[0], "account")); next2.setEnabled(true); } }); } @Override public void failure(String message) { runOnUiThread(() -> { validateTarget.setEnabled(true); targetStatus.setText("Não foi possível validar o destinatário."); }); } }); });
        next2.setOnClickListener(v -> {
            if (recipient[0] == null) { targetStatus.setText("Valide o destinatário antes de continuar."); return; }
            double transferAmount = parseDemTransferAmount(amount.getText().toString());
            if (!isValidDemTransferAmount(transferAmount)) { amountStatus.setText("Formato ou valor inválido. Digite, por exemplo, 5 ou 5,00."); currentStage[0] = 1; showStage.run(); return; }
            review.setText("Valor: " + formatMoney(transferAmount) + "\nConta de saída: " + field(currentUser, "account") + "\nDestinatário: " + field(recipient[0], "name", "Cliente") + "\nConta de destino: " + field(recipient[0], "account") + "\nAprovação administrativa: obrigatória");
            currentStage[0] = 3; showStage.run();
        });
        next3.setOnClickListener(v -> { submitStatus.setText("Confira a revisão e marque a confirmação para liberar o envio."); currentStage[0] = 4; showStage.run(); });
        security.setOnCheckedChangeListener((buttonView, checked) -> submit.setEnabled(checked));
        submit.setOnClickListener(v -> {
            double transferAmount = parseDemTransferAmount(amount.getText().toString());
            if (!isValidDemTransferAmount(transferAmount)) { submitStatus.setText("O valor não é válido. Volte e digite, por exemplo, 5 ou 5,00."); currentStage[0] = 1; showStage.run(); return; }
            submitNativeDemTransfer(transferAmount, recipient[0], submit, submitStatus);
        });
    }

    protected void submitNativeDemTransfer(double amount, JSONObject recipient, Button submit, TextView status) {
        if (recipient == null || !isValidDemTransferAmount(amount)) { status.setText("Revise o valor em reais e o destinatário antes de enviar."); return; }
        String txId = "TX" + System.currentTimeMillis();
        JSONObject metadata = new JSONObject(); JSONObject tx = new JSONObject();
        try {
            metadata.put("flow_steps", 4); metadata.put("flow_name", "transferencia_dem"); metadata.put("approval_required", true); metadata.put("reviewed_at", isoNow()); metadata.put("sender_name", field(currentUser, "name", "Cliente")); metadata.put("target_name", field(recipient, "name", "Destinatário")); metadata.put("sender_account", field(currentUser, "account")); metadata.put("target_account", field(recipient, "account"));
            tx.put("id", txId); tx.put("sender", field(currentUser, "account")); tx.put("sender_account", field(currentUser, "account")); tx.put("target", field(recipient, "account")); tx.put("target_account", field(recipient, "account")); tx.put("amount", String.format(Locale.US, "%.2f", amount)); tx.put("title", "Transferência DEM para " + field(recipient, "name", field(recipient, "account"))); tx.put("description", "Transferência DEM de " + field(currentUser, "name", field(currentUser, "account")) + " para " + field(recipient, "name", field(recipient, "account")) + ". SANBANK_TYPE:TRANSFER SANBANK_META:" + metadata.toString()); tx.put("transaction_type", "TRANSFER"); tx.put("type", "TRANSFER"); tx.put("date", isoNow()); tx.put("status", "pending"); tx.put("operation_data", metadata.toString());
        } catch (Exception error) { status.setText("Não foi possível preparar a transferência."); return; }
        submit.setEnabled(false); status.setText("Registrando a transferência para aprovação...");
        apiUpsert("pendentes", tx, new RpcCallback() { @Override public void success(Object result) { trackPendingTransaction(tx); runOnUiThread(() -> { submit.setEnabled(true); status.setText("Solicitação enviada. Aguardando confirmação do administrador."); openOperationStatusActivity(DemOperationActivity.class, tx, metadata); }); } @Override public void failure(String message) { runOnUiThread(() -> { submit.setEnabled(true); status.setText(message); }); } });
    }

    protected void showDemReceiptDialog(JSONObject tx, JSONObject metadata) {
        String message = "Status: Solicitação registrada / aguardando aprovação\n\nIdentificador: " + field(tx, "id") + "\nValor: " + formatMoney(decimal(field(tx, "amount"))) + "\nConta de saída: " + field(metadata, "sender_account") + "\nConta de destino: " + field(metadata, "target_account") + "\nDestinatário: " + field(metadata, "target_name") + "\n\nNenhum saldo foi movimentado antes da aprovação administrativa.";
        new AlertDialog.Builder(this).setTitle("Comprovante Transferência DEM").setMessage(message).setNegativeButton("Fechar", null).setNeutralButton("Compartilhar PDF", (dialog, which) -> shareDemReceipt(tx, metadata)).setPositiveButton("Abrir PDF", (dialog, which) -> openDemReceipt(tx, metadata)).show();
    }

    protected void openDemReceipt(JSONObject tx, JSONObject metadata) { Uri uri = createDemReceiptUri(tx, metadata); if (uri != null) openPdf(uri); }
    protected void shareDemReceipt(JSONObject tx, JSONObject metadata) { Uri uri = createDemReceiptUri(tx, metadata); if (uri == null) return; try { Intent intent = new Intent(Intent.ACTION_SEND); intent.setType("application/pdf"); intent.putExtra(Intent.EXTRA_STREAM, uri); intent.putExtra(Intent.EXTRA_TEXT, "Comprovante Transferência DEM SANBANK BR DIGITAL"); intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(Intent.createChooser(intent, "Compartilhar comprovante DEM")); } catch (ActivityNotFoundException error) { Toast.makeText(this, "Nenhum aplicativo disponível para compartilhar o PDF.", Toast.LENGTH_LONG).show(); } }

    protected Uri createDemReceiptUri(JSONObject tx, JSONObject metadata) {
        String safe = field(tx, "id", "dem").replaceAll("[^a-zA-Z0-9_-]", "-"); File folder = new File(getCacheDir(), "shared"); if (!folder.exists() && !folder.mkdirs()) return null; File file = new File(folder, "comprovante-dem-" + safe + ".pdf"); PdfDocument document = new PdfDocument(); PdfDocument.Page page = document.startPage(new PdfDocument.PageInfo.Builder(595, 842, 1).create()); Canvas canvas = page.getCanvas(); Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG); canvas.drawColor(Color.rgb(6, 26, 40)); paint.setColor(Color.rgb(167, 243, 208)); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(12); canvas.drawText("SANBANK BR DIGITAL", 28, 35, paint); paint.setColor(Color.WHITE); paint.setTextSize(24); canvas.drawText("Comprovante de transferência DEM", 28, 78, paint); paint.setColor(Color.rgb(251, 191, 36)); paint.setTextSize(13); canvas.drawText("Solicitação registrada / aguardando aprovação", 28, 106, paint); paint.setColor(Color.rgb(52, 211, 153)); canvas.drawRect(28, 123, 567, 126, paint);
        String[][] rows = {{"Identificador", field(tx, "id")}, {"Data e hora", field(tx, "date")}, {"Conta de saída", field(metadata, "sender_account")}, {"Conta de destino", field(metadata, "target_account")}, {"Destinatário", field(metadata, "target_name")}, {"Valor", formatMoney(decimal(field(tx, "amount")))}, {"Aprovação", "Aguardando Administrador"}, {"Rota", "Fundo administrativo → destinatário"}}; int y = 160; paint.setTextSize(11); for (String[] row : rows) { paint.setColor(Color.rgb(159, 197, 232)); paint.setTypeface(Typeface.DEFAULT_BOLD); canvas.drawText(row[0] + ":", 28, y, paint); paint.setColor(Color.WHITE); paint.setTypeface(Typeface.DEFAULT); canvas.drawText(shortText(row[1], 60), 170, y, paint); y += 38; } paint.setColor(Color.rgb(130, 180, 172)); paint.setTextSize(9); canvas.drawText("Nenhum saldo foi movimentado antes da aprovação administrativa.", 28, 780, paint); canvas.drawText("Guarde este comprovante para consulta futura.", 28, 798, paint); document.finishPage(page);
        try (OutputStream output = new FileOutputStream(file)) { document.writeTo(output); document.close(); return SanbankFileProvider.uriForFile(this, file, "shared"); } catch (Exception error) { try { document.close(); } catch (Exception ignored) { } Toast.makeText(this, "Não foi possível preparar o comprovante PDF.", Toast.LENGTH_LONG).show(); return null; }
    }

    protected void startNativeNotificationPolling() { notificationPolling = true; notificationHandler.removeCallbacks(notificationPoller); notificationHandler.post(notificationPoller); }
    protected void stopNativeNotificationPolling() { notificationPolling = false; notificationHandler.removeCallbacks(notificationPoller); }
    protected void startPendingStatusPolling() { pendingPolling = true; pendingHandler.removeCallbacks(pendingPoller); pendingHandler.post(pendingPoller); }
    protected void stopPendingStatusPolling() { pendingPolling = false; pendingHandler.removeCallbacks(pendingPoller); }

    protected void syncPendingStatuses() {
        if (currentUser == null || field(currentUser, "account").isEmpty()) return;
        listTab("pendentes", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                for (int i = 0; i < records.length(); i++) {
                    JSONObject item = records.optJSONObject(i); if (item == null) continue;
                    String sender = firstField(item, "sender_account", "sender");
                    if (!field(currentUser, "account").equals(sender)) continue;
                    String id = field(item, "id"); String status = normalizePendingStatus(field(item, "status", "pending"));
                    if (id.isEmpty() || status.isEmpty()) continue;
                    requestRecipientCreditIfCompleted(item, status);
                    String prefKey = "pending_status_" + id;
                    String previous = prefs().getString(prefKey, "");
                    if (previous.isEmpty()) { prefs().edit().putString(prefKey, status).apply(); continue; }
                    if (previous.equals(status)) continue;
                    prefs().edit().putString(prefKey, status).apply();
                    String label = pendingStatusLabel(status);
                    NativeNotificationHelper.post(NativeBaseActivity.this, "Transferência / Pix " + label, "A operação " + id + " foi atualizada para: " + label + ".", "operacao", "pending-status:" + id + ":" + status);
                    runOnUiThread(() -> Toast.makeText(NativeBaseActivity.this, "A operação " + id + " foi atualizada: " + label + ".", Toast.LENGTH_LONG).show());
                }
            }
            @Override public void failure(String ignored) { }
        });
    }

    protected void requestRecipientCreditIfCompleted(JSONObject operation, String normalizedStatus) {
        if (operation == null || currentUser == null) return;
        String settlement = normalizePendingStatus(field(operation, "settlement_status", ""));
        boolean completed = normalizedStatus.contains("complete") || normalizedStatus.contains("conclu") || normalizedStatus.equals("paid") || settlement.contains("complete") || settlement.contains("settled") || settlement.equals("debited");
        if (!completed) return;
        String target = firstField(operation, "target_account", "target", "recipient_account");
        if (target.isEmpty()) {
            try {
                String operationData = field(operation, "operation_data");
                if (!operationData.isEmpty()) target = firstField(new JSONObject(operationData), "target_account", "recipient_account", "target");
            } catch (Exception ignored) { }
        }
        if (target.isEmpty() || !target.matches("\\d{6}") || target.equals(field(currentUser, "account")) || "ADMIN".equalsIgnoreCase(target)) return;
        String type = firstField(operation, "transaction_type", "type").toLowerCase(Locale.ROOT);
        String title = field(operation, "title", "").toLowerCase(Locale.ROOT);
        String description = field(operation, "description", "").toLowerCase(Locale.ROOT);
        boolean internalTransfer = type.contains("transfer") || type.contains("dem") || type.contains("qr") || type.contains("pix") || title.contains("transferência dem") || description.contains("transferência dem") || description.contains("sanbank_type:transfer");
        if (!internalTransfer) return;
        JSONObject body = new JSONObject();
        try { body.put("p_id", field(operation, "id")); } catch (Exception ignored) { }
        rpc("sanbank_credit_operation_recipient", body, new RpcCallback() {
            @Override public void success(Object result) { }
            @Override public void failure(String message) { }
        });
    }

    protected void trackPendingTransaction(JSONObject tx) {
        String id = field(tx, "id"); if (id.isEmpty()) return;
        prefs().edit().putString("pending_status_" + id, "pending").apply();
        startPendingStatusPolling();
    }

    protected String normalizePendingStatus(String value) { return String.valueOf(value == null ? "pending" : value).trim().toLowerCase(Locale.US).replace(' ', '_').replace('-', '_'); }
    protected String pendingStatusLabel(String status) { if (status.contains("complete") || status.contains("conclu") || status.equals("paid")) return "concluída"; if (status.contains("reject") || status.contains("recus") || status.contains("cancel")) return "recusada"; if (status.contains("approv") || status.contains("aprov") || status.contains("process")) return "aprovada / em processamento"; return "pendente"; }

    protected void showNotificationsScreen() {
        if (currentUser == null) { Toast.makeText(this, "Faça login para ver suas notificações.", Toast.LENGTH_LONG).show(); return; }
        supportScreenVisible = false; stopSupportPolling(); resetRoot(); root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0)); ScrollView scroll = new ScrollView(this); LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(14), dp(14), dp(14), dp(28)); addDashboardStyleHeader(page); page.addView(text("Minhas notificações", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 3)); page.addView(text("Avisos individuais sincronizados com a conta", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 12)); TextView status = text("Carregando notificações...", 12, MUTED, false); page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(30), 0, 8)); LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); page.addView(list, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12)); Button refresh = secondaryButton("Atualizar notificações"); page.addView(refresh, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 9)); Button back = secondaryButton("Voltar ao painel"); page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 0)); back.setOnClickListener(v -> showDashboard()); refresh.setOnClickListener(v -> refreshNativeNotifications(status, list)); scroll.addView(page); root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); refreshNativeNotifications(status, list);
    }

    protected void refreshNativeNotifications(TextView status, LinearLayout list) {
        if (currentUser == null) return; listTab("notificacoes_usuarios", field(currentUser, "account"), new ListCallback() { @Override public void success(JSONArray records) { JSONArray filtered = new JSONArray(); for (int i = 0; i < records.length(); i++) { JSONObject item = records.optJSONObject(i); if (item != null && field(item, "account").equals(field(currentUser, "account")) && enabledNotification(field(item, "enabled")) && !field(item, "message").isEmpty()) { filtered.put(item); if (field(item, "read_at").isEmpty()) NativeNotificationHelper.post(NativeBaseActivity.this, field(item, "title", "Notificação SANBANK"), field(item, "message"), field(item, "type", "informativo"), "user-notification:" + field(currentUser, "account") + ":" + field(item, "id", String.valueOf(i))); } } runOnUiThread(() -> renderNativeNotifications(filtered, status, list)); } @Override public void failure(String message) { if (status != null) runOnUiThread(() -> status.setText("A central de notificações ainda não está disponível.")); } });
    }

    protected void renderNativeNotifications(JSONArray records, TextView status, LinearLayout list) { if (list == null) return; list.removeAllViews(); if (records.length() == 0) { if (status != null) status.setText("Nenhuma notificação disponível para esta conta."); list.addView(text("Os avisos enviados pelo Administrador aparecerão aqui.", 13, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(60), 0, 0)); return; } if (status != null) status.setText(records.length() + " notificação(ões) encontrada(s)."); for (int i = records.length() - 1; i >= 0; i--) { JSONObject item = records.optJSONObject(i); if (item == null) continue; LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(13), dp(12), dp(13), dp(12)); card.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 15)); card.addView(text(field(item, "title", "Notificação SANBANK"), 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(27), 0, 3)); card.addView(text(field(item, "type", "informativo") + " · " + field(item, "created_at", "Data não informada"), 11, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(23), 0, 5)); card.addView(text(field(item, "message"), 13, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 7)); if (field(item, "read_at").isEmpty() && !field(item, "id").isEmpty()) { Button read = secondaryButton("Marcar como lida"); read.setOnClickListener(v -> { JSONObject payload = new JSONObject(); copyJsonValues(payload, item); try { payload.put("read_at", isoNow()); } catch (Exception ignored) { } apiUpsert("notificacoes_usuarios", payload, new RpcCallback() { @Override public void success(Object result) { runOnUiThread(() -> refreshNativeNotifications(status, list)); } @Override public void failure(String message) { runOnUiThread(() -> Toast.makeText(NativeBaseActivity.this, message, Toast.LENGTH_LONG).show()); } }); }); card.addView(read, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(44), 0, 0)); } list.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8)); } }
    protected boolean enabledNotification(String value) { return value.isEmpty() || truthy(value) || "ativo".equalsIgnoreCase(value) || "ativada".equalsIgnoreCase(value); }

    protected void openSupportScreen() {
        if (currentUser == null) { Toast.makeText(this, "Faça login para falar com o suporte.", Toast.LENGTH_LONG).show(); return; }
        stopSupportPolling(); stopNativeNotificationPolling(); supportScreenVisible = true; resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 39, 57), Color.rgb(4, 17, 32), 0));
        LinearLayout screen = new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(13), dp(12), dp(13), dp(12));
        root.addView(screen, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.HORIZONTAL); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(9), dp(9), dp(8), dp(9));
        header.setBackground(gradient(Color.rgb(11, 55, 76), Color.rgb(15, 66, 84), Color.rgb(12, 46, 69), 19));
        Button back = secondaryButton("‹"); back.setTextSize(24); back.setPadding(0, 0, 0, dp(4)); back.setContentDescription("Voltar");
        header.addView(back, new LinearLayout.LayoutParams(dp(43), dp(43)));
        ImageView avatar = supportBrandAvatar(43);
        LinearLayout.LayoutParams avatarParams = new LinearLayout.LayoutParams(dp(43), dp(43)); avatarParams.setMargins(dp(8), 0, dp(10), 0); header.addView(avatar, avatarParams);
        LinearLayout identity = new LinearLayout(this); identity.setOrientation(LinearLayout.VERTICAL);
        identity.addView(text("Suporte SANBANK", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 1));
        identity.addView(text("Atendimento humano · conversa protegida", 10, Color.rgb(165, 205, 220), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 0));
        header.addView(identity, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button refresh = secondaryButton("↻"); refresh.setTextSize(20); refresh.setContentDescription("Atualizar conversa");
        header.addView(refresh, new LinearLayout.LayoutParams(dp(42), dp(42)));
        screen.addView(header, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 9));

        TextView status = text("Carregando atendimento...", 11, Color.rgb(173, 211, 225), false); status.setPadding(dp(12), dp(8), dp(12), dp(8));
        status.setBackground(rounded(Color.argb(160, 12, 42, 58), Color.argb(70, 125, 211, 252), 13)); supportStatusView = status;
        screen.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 7));

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.setClipToPadding(false); scroll.setVerticalScrollBarEnabled(false); supportScrollView = scroll;
        LinearLayout messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); messages.setPadding(dp(3), dp(8), dp(3), dp(12)); supportMessagesView = messages;
        scroll.addView(messages, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        screen.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout composer = new LinearLayout(this); composer.setOrientation(LinearLayout.HORIZONTAL); composer.setGravity(Gravity.CENTER_VERTICAL); composer.setPadding(dp(7), dp(5), dp(6), dp(5));
        composer.setBackground(rounded(Color.rgb(21, 56, 73), Color.argb(85, 125, 211, 252), 27));
        EditText input = textInput("Escreva uma mensagem..."); input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setSingleLine(false); input.setMinLines(1); input.setMaxLines(4); input.setGravity(Gravity.CENTER_VERTICAL | Gravity.START); input.setBackgroundColor(Color.TRANSPARENT); input.setPadding(dp(12), dp(8), dp(8), dp(8));
        composer.addView(input, new LinearLayout.LayoutParams(0, dp(50), 1));
        Button send = primaryButton("➤"); send.setTextSize(22); send.setPadding(0, 0, 0, dp(2)); send.setMinHeight(0); send.setBackground(gradient(Color.rgb(32, 119, 239), Color.rgb(25, 91, 210), Color.rgb(32, 119, 239), 26)); send.setContentDescription("Enviar mensagem");
        composer.addView(send, new LinearLayout.LayoutParams(dp(49), dp(49)));
        screen.addView(composer, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 5));
        screen.addView(text("Atendimento direto com a equipe SANBANK", 10, Color.rgb(131, 169, 190), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(21), 0, 0));

        boolean lockedSupportMode = getIntent() != null && getIntent().getBooleanExtra("app_access_locked_support", false);
        back.setOnClickListener(v -> { stopSupportPolling(); if (lockedSupportMode) finish(); else showDashboard(); });
        refresh.setOnClickListener(v -> refreshSupportMessages(status, messages));
        send.setOnClickListener(v -> {
            String body = input.getText().toString().trim();
            if (body.isEmpty()) { input.setError("Digite uma mensagem."); return; }
            send.setEnabled(false); status.setText("Enviando mensagem para o atendimento...");
            JSONObject payload = new JSONObject();
            try { payload.put("id", "CHAT-" + field(currentUser, "account") + "-" + System.nanoTime()); payload.put("account", field(currentUser, "account")); payload.put("sender_role", "user"); payload.put("role", "user"); payload.put("sender", "user"); payload.put("sender_name", field(currentUser, "name", "Cliente")); payload.put("message", body); payload.put("created_at", isoNow()); payload.put("status", "open"); } catch (Exception ignored) { }
            apiUpsert("chat_suporte", payload, new RpcCallback() {
                @Override public void success(Object result) { runOnUiThread(() -> { input.setText(""); send.setEnabled(true); status.setText("Mensagem enviada ao atendimento."); refreshSupportMessages(status, messages); }); }
                @Override public void failure(String error) { runOnUiThread(() -> { send.setEnabled(true); status.setText("Não foi possível enviar a mensagem. Tente novamente."); }); }
            });
        });
        refreshSupportMessages(status, messages); supportHandler.removeCallbacks(supportPoller); supportHandler.postDelayed(supportPoller, 5000L);
    }

    private void openSupportScreenLegacy() {
        if (currentUser == null) { Toast.makeText(this, "Faça login para falar com o suporte.", Toast.LENGTH_LONG).show(); return; }
        stopSupportPolling(); stopNativeNotificationPolling(); supportScreenVisible = true; resetRoot(); root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0)); ScrollView scroll = new ScrollView(this); supportScrollView = scroll; LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(14), dp(14), dp(14), dp(28)); addDashboardStyleHeader(page); page.addView(text("Suporte ao cliente", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 3)); page.addView(text("Atendimento direto com um atendente SANBANK", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 12)); TextView status = text("Carregando atendimento...", 12, MUTED, false); supportStatusView = status; page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(30), 0, 7)); LinearLayout messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); supportMessagesView = messages; page.addView(messages, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10)); EditText input = textInput("Escreva sua mensagem para o atendente..."); input.setMinLines(3); page.addView(input, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(92), 0, 8)); Button send = primaryButton("Enviar mensagem"); page.addView(send, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 8)); Button refresh = secondaryButton("Atualizar conversa"); page.addView(refresh, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8)); boolean lockedSupportMode = getIntent() != null && getIntent().getBooleanExtra("app_access_locked_support", false); Button back = secondaryButton(lockedSupportMode ? "Voltar ao aviso de bloqueio" : "Voltar ao painel"); page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 0)); back.setOnClickListener(v -> { stopSupportPolling(); if (lockedSupportMode) finish(); else showDashboard(); }); refresh.setOnClickListener(v -> refreshSupportMessages(status, messages)); send.setOnClickListener(v -> { String message = input.getText().toString().trim(); if (message.isEmpty()) { input.setError("Digite uma mensagem."); return; } send.setEnabled(false); JSONObject payload = new JSONObject(); try { payload.put("id", "CHAT-" + field(currentUser, "account") + "-" + System.nanoTime()); payload.put("account", field(currentUser, "account")); payload.put("sender_role", "user"); payload.put("role", "user"); payload.put("sender", "user"); payload.put("sender_name", field(currentUser, "name", "Cliente")); payload.put("message", message); payload.put("created_at", isoNow()); payload.put("status", "open"); } catch (Exception ignored) { } apiUpsert("chat_suporte", payload, new RpcCallback() { @Override public void success(Object result) { runOnUiThread(() -> { input.setText(""); send.setEnabled(true); status.setText("Mensagem enviada ao atendimento."); refreshSupportMessages(status, messages); }); } @Override public void failure(String error) { runOnUiThread(() -> { send.setEnabled(true); status.setText(error); }); } }); }); scroll.addView(page); root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); refreshSupportMessages(status, messages); supportHandler.removeCallbacks(supportPoller); supportHandler.postDelayed(supportPoller, 5000L);
    }

    protected void refreshSupportMessages(TextView status, LinearLayout list) {
        if (currentUser == null || status == null || list == null || !supportScreenVisible || supportRefreshInProgress) return;
        String account = field(currentUser, "account");
        if (account.isEmpty()) {
            status.setText("Não foi possível identificar a conta do atendimento.");
            return;
        }
        supportRefreshInProgress = true;
        int requestToken = ++supportRefreshToken;
        listTab("chat_suporte", account, new ListCallback() {
            @Override public void success(JSONArray records) {
                JSONArray filtered = new JSONArray();
                for (int i = 0; i < records.length(); i++) {
                    JSONObject item = records.optJSONObject(i);
                    if (item != null && account.equals(field(item, "account")) && !"closed".equalsIgnoreCase(field(item, "status", "open"))) filtered.put(item);
                }
                runOnUiThread(() -> {
                    if (requestToken != supportRefreshToken) return;
                    supportRefreshInProgress = false;
                    if (!supportScreenVisible || supportStatusView != status || supportMessagesView != list) return;
                    renderSupportMessagesNative(filtered, status, list);
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> {
                    if (requestToken != supportRefreshToken) return;
                    supportRefreshInProgress = false;
                    if (supportScreenVisible && supportStatusView == status) status.setText("Não foi possível atualizar o atendimento. Tentando novamente...");
                });
            }
        });
    }
    private ImageView supportBrandAvatar(int sizeDp) {
        ImageView avatar = new ImageView(this);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        int iconId = getResources().getIdentifier("ic_sanbank_user_icon", "drawable", getPackageName());
        if (iconId != 0) avatar.setImageResource(iconId);
        avatar.setContentDescription("SANBANK BR DIGITAL");
        avatar.setBackground(rounded(Color.WHITE, Color.argb(170, 125, 211, 252), 14));
        avatar.setPadding(dp(2), dp(2), dp(2), dp(2));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) avatar.setClipToOutline(true);
        avatar.setElevation(dp(2));
        return avatar;
    }

    private TextView supportUserAvatar() {
        TextView avatar = text("🚹", 17, Color.WHITE, false);
        avatar.setGravity(Gravity.CENTER);
        avatar.setContentDescription("Você");
        avatar.setBackground(rounded(Color.rgb(28, 101, 220), Color.argb(125, 147, 197, 253), 18));
        return avatar;
    }

    protected void renderSupportMessagesNative(JSONArray records, TextView status, LinearLayout list) {
        if (list == null) return;
        ScrollView activeScroll = supportScrollView;
        int previousY = activeScroll == null ? 0 : activeScroll.getScrollY();
        boolean followLatest = activeScroll == null || activeScroll.getChildCount() == 0;
        if (activeScroll != null && activeScroll.getChildCount() > 0) {
            View content = activeScroll.getChildAt(0);
            int remaining = content.getHeight() - (activeScroll.getScrollY() + activeScroll.getHeight());
            followLatest = remaining <= dp(96);
        }
        list.removeAllViews();
        LinearLayout dividerRow = new LinearLayout(this); dividerRow.setGravity(Gravity.CENTER);
        TextView divider = text("CONVERSA DE SUPORTE", 9, Color.rgb(174, 212, 228), true); divider.setGravity(Gravity.CENTER); divider.setPadding(dp(12), dp(5), dp(12), dp(5));
        divider.setBackground(rounded(Color.argb(165, 12, 47, 66), Color.argb(50, 125, 211, 252), 16));
        dividerRow.addView(divider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        list.addView(dividerRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 13));
        if (records.length() == 0) {
            LinearLayout empty = new LinearLayout(this); empty.setOrientation(LinearLayout.VERTICAL); empty.setPadding(dp(15), dp(14), dp(15), dp(14));
            empty.setBackground(rounded(Color.rgb(16, 52, 69), Color.argb(75, 125, 211, 252), 18));
            empty.addView(text("Ainda não há mensagens", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 4));
            empty.addView(text("Escreva sua dúvida abaixo para iniciar o atendimento humano.", 12, Color.rgb(173, 205, 219), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
            list.addView(empty, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 8, 0));
            if (status != null) status.setText("Conversa pronta · atendimento SANBANK");
            restoreSupportScroll(activeScroll, previousY, true);
            return;
        }
        if (status != null) status.setText("Atendimento aberto · " + records.length() + (records.length() == 1 ? " mensagem" : " mensagens"));
        int maxWidth = Math.round(getResources().getDisplayMetrics().widthPixels * 0.78f);
        for (int i = 0; i < records.length(); i++) {
            JSONObject item = records.optJSONObject(i);
            if (item == null) continue;
            String role = firstField(item, "sender_role", "role", "sender").toLowerCase(Locale.ROOT);
            boolean fromAdmin = "admin".equals(role) || "administrator".equals(role) || "atendente".equals(role);
            boolean fromSystem = "system".equals(role);
            String sender = fromAdmin ? "ATENDENTE SANBANK" : fromSystem ? "SANBANK" : "VOCÊ";
            String body = firstField(item, "message", "text");
            int fill = fromAdmin ? Color.rgb(22, 61, 77) : fromSystem ? Color.rgb(70, 58, 38) : Color.rgb(28, 101, 220);
            int stroke = fromAdmin ? Color.argb(90, 94, 234, 212) : fromSystem ? Color.argb(80, 251, 191, 36) : Color.argb(55, 147, 197, 253);
            int foreground = fromSystem ? Color.rgb(255, 231, 171) : Color.rgb(239, 247, 255);
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(fromSystem ? Gravity.CENTER : fromAdmin ? Gravity.LEFT : Gravity.RIGHT);
            LinearLayout bubble = new LinearLayout(this); bubble.setOrientation(LinearLayout.VERTICAL); bubble.setPadding(dp(13), dp(9), dp(13), dp(7)); bubble.setBackground(rounded(fill, stroke, 18));
            TextView senderView = text(sender, 9, fromAdmin ? Color.rgb(144, 222, 211) : fromSystem ? Color.rgb(248, 199, 97) : Color.rgb(207, 226, 255), true); senderView.setMaxWidth(maxWidth);
            TextView bodyView = text(body, 14, foreground, false); bodyView.setGravity(Gravity.START | Gravity.CENTER_VERTICAL); bodyView.setMaxWidth(maxWidth); bodyView.setLineSpacing(dp(2), 1.02f);
            TextView timeView = text(supportChatTime(firstField(item, "created_at", "date")), 9, Color.argb(205, 214, 230, 244), false); timeView.setGravity(Gravity.RIGHT); timeView.setMaxWidth(maxWidth);
            bubble.addView(senderView, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(15), 0, 3));
            bubble.addView(bodyView, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 5));
            bubble.addView(timeView, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(14), 0, 0));
            if (fromAdmin || fromSystem) {
                ImageView companyAvatar = supportBrandAvatar(30);
                LinearLayout.LayoutParams companyAvatarParams = new LinearLayout.LayoutParams(dp(30), dp(30));
                companyAvatarParams.setMargins(0, dp(2), dp(6), 0);
                row.addView(companyAvatar, companyAvatarParams);
            }
            row.addView(bubble, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            if (!fromAdmin && !fromSystem) {
                TextView userAvatar = supportUserAvatar();
                LinearLayout.LayoutParams userAvatarParams = new LinearLayout.LayoutParams(dp(30), dp(30));
                userAvatarParams.setMargins(dp(6), dp(2), 0, 0);
                row.addView(userAvatar, userAvatarParams);
            }
            list.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        }
        restoreSupportScroll(activeScroll, previousY, followLatest);
    }

    private String supportChatTime(String raw) {
        String value = raw == null ? "" : raw.trim().replace('T', ' ');
        if (value.length() >= 16) return value.substring(11, 16);
        return value.isEmpty() ? "Agora" : value;
    }

    private void renderSupportMessagesNativeLegacy(JSONArray records, TextView status, LinearLayout list) {
        if (list == null) return;
        ScrollView activeScroll = supportScrollView;
        int previousY = activeScroll == null ? 0 : activeScroll.getScrollY();
        boolean followLatest = activeScroll == null || activeScroll.getChildCount() == 0;
        if (activeScroll != null && activeScroll.getChildCount() > 0) {
            View content = activeScroll.getChildAt(0);
            int remaining = content.getHeight() - (activeScroll.getScrollY() + activeScroll.getHeight());
            followLatest = remaining <= dp(96);
        }
        list.removeAllViews();
        if (records.length() == 0) {
            if (status != null) status.setText("Nenhuma mensagem ainda. Escreva para iniciar o atendimento.");
            restoreSupportScroll(activeScroll, previousY, followLatest);
            return;
        }
        if (status != null) status.setText("Atendimento aberto · " + records.length() + " mensagem(ões)");
        for (int i = 0; i < records.length(); i++) {
            JSONObject item = records.optJSONObject(i);
            if (item == null) continue;
            // Older manager builds wrote `sender` instead of `sender_role`; accept both formats.
            String role = firstField(item, "sender_role", "role", "sender").toLowerCase(Locale.ROOT);
            boolean fromAdmin = "admin".equals(role) || "administrator".equals(role) || "atendente".equals(role);
            boolean fromSystem = "system".equals(role);
            String label = fromAdmin ? "Atendente: " : fromSystem ? "SANBANK: " : "Você: ";
            String body = firstField(item, "message", "text");
            int foreground = fromAdmin ? Color.rgb(167, 243, 208) : fromSystem ? Color.rgb(253, 230, 138) : Color.rgb(219, 234, 254);
            int background = fromAdmin ? Color.argb(32, 16, 185, 129) : fromSystem ? Color.argb(32, 245, 158, 11) : Color.argb(25, 14, 165, 233);
            TextView message = text(label + body, 13, foreground, false);
            message.setPadding(dp(12), dp(10), dp(12), dp(10));
            message.setBackground(rounded(background, Color.argb(55, 125, 211, 252), 14));
            list.addView(message, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 7));
        }
        restoreSupportScroll(activeScroll, previousY, followLatest);
    }

    private void restoreSupportScroll(ScrollView scroll, int previousY, boolean followLatest) {
        if (scroll == null) return;
        scroll.post(() -> {
            if (supportScrollView != scroll) return;
            if (followLatest) scroll.fullScroll(View.FOCUS_DOWN);
            else scroll.scrollTo(0, previousY);
        });
    }
    protected void stopSupportPolling() { supportScreenVisible = false; supportRefreshToken++; supportRefreshInProgress = false; supportHandler.removeCallbacks(supportPoller); supportScrollView = null; supportStatusView = null; supportMessagesView = null; }

    protected void showSecurityLockScreen(int count) {
        loadingScreenVisible = false;
        loadingFinishScheduled = false;
        loadingStatus = null;
        loadingProgress = null;
        securityScreenVisible = true;
        dashboardVisible = false;
        accountCommandScreenVisible = false;
        dashboardNeedsRebuild = false;
        stopDashboardBalancePolling();
        resetRoot();
        root.setBackground(gradient(Color.rgb(39, 13, 32), Color.rgb(53, 18, 42), Color.rgb(7, 30, 58), 0));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(22), dp(45), dp(22), dp(28));
        TextView icon = text("!", 36, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(gradient(RED, Color.rgb(190, 24, 93), BLUE_DEEP, 28));
        page.addView(icon, new LinearLayout.LayoutParams(dp(78), dp(78)));
        TextView title = text("Acesso temporariamente bloqueado", 22, TEXT, true);
        title.setGravity(Gravity.CENTER);
        page.addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(60), 18, 6));
        TextView description = text("Identificamos um volume de utilizações acima do limite de segurança do Cartão Neo Bradesco. O acesso ficará interrompido até uma revisão administrativa.", 14, MUTED, false);
        description.setGravity(Gravity.CENTER);
        page.addView(description, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 18));
        TextView reason = text("Utilizações agrupadas: " + count + "\nLimite automático: " + neoOperationLimit(currentUser), 14, Color.rgb(254, 226, 226), true);
        reason.setGravity(Gravity.CENTER);
        reason.setPadding(dp(15), dp(14), dp(15), dp(14));
        reason.setBackground(rounded(Color.argb(32, 244, 63, 94), Color.argb(95, 251, 113, 133), 16));
        page.addView(reason, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 18));
        securityStatus = text("Aguardando o comando administrativo de desbloqueio...", 13, MUTED, false);
        securityStatus.setGravity(Gravity.CENTER);
        page.addView(securityStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8));
        Button support = secondaryButton("Falar com o suporte");
        support.setOnClickListener(v -> Toast.makeText(this, "O suporte poderá orientar a revisão desta conta.", Toast.LENGTH_LONG).show());
        page.addView(support, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        securityUnlockCommandSeen = field(currentUser, "security_unlock_command");
        stopSecurityPolling();
        securityHandler.post(securityPoller);
    }

    protected void showAdminSecurityScreen() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(24));
        addDashboardStyleHeader(page);
        page.addView(text("Revisão de segurança", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 4));
        page.addView(text("Administração nativa · desbloqueio com motivo, justificativa e comando único", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 16));
        EditText account = input("Conta do usuário", false);
        page.addView(account, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        Button search = primaryButton("Consultar conta");
        page.addView(search, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 12));
        TextView resultStatus = text("Nenhuma conta consultada.", 13, MUTED, false);
        resultStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        resultStatus.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
        page.addView(resultStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        EditText reason = textInput("Motivo confirmado do desbloqueio");
        page.addView(reason, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(70), 0, 9));
        EditText notes = textInput("Justificativa e observações da revisão");
        page.addView(notes, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(100), 0, 12));
        Button unlock = primaryButton("Confirmar motivo e desbloquear");
        unlock.setEnabled(false);
        page.addView(unlock, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(54), 0, 9));
        TextView actionStatus = text("", 12, MUTED, false);
        actionStatus.setGravity(Gravity.CENTER);
        page.addView(actionStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 12));
        Button back = secondaryButton("Voltar ao painel");
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 0));
        back.setOnClickListener(v -> showDashboard());
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        search.setOnClickListener(v -> {
            String value = account.getText().toString().trim();
            if (!value.matches("\\d{6}")) { resultStatus.setText("Informe uma conta com 6 dígitos."); return; }
            search.setEnabled(false);
            resultStatus.setText("Consultando o status de segurança...");
            JSONObject payload = new JSONObject();
            try { payload.put("p_account", value); payload.put("p_role", JSONObject.NULL); } catch (Exception ignored) { }
            rpc("sanbank_account_search", payload, new RpcCallback() {
                @Override public void success(Object data) {
                    runOnUiThread(() -> {
                        search.setEnabled(true);
                        adminTarget = firstObject(data);
                        if (adminTarget == null) {
                            resultStatus.setText("Conta não encontrada.");
                            unlock.setEnabled(false);
                            return;
                        }
                        adminTarget = normalizeRecord(adminTarget);
                        boolean locked = isSecurityResourceBlocked(adminTarget);
                        int count = number(field(adminTarget, "security_lock_count"));
                        resultStatus.setText("Conta " + field(adminTarget, "account") + " — " + (locked ? "RECURSOS BLOQUEADOS" : "liberada") + "\nUtilizações registradas: " + count);
                        unlock.setEnabled(locked);
                    });
                }
                @Override public void failure(String message) { runOnUiThread(() -> { search.setEnabled(true); resultStatus.setText(message); }); }
            });
        });

        unlock.setOnClickListener(v -> {
            if (adminTarget == null || !isSecurityResourceBlocked(adminTarget)) { actionStatus.setText("Consulte uma conta com recursos bloqueados antes de desbloquear."); return; }
            String reasonValue = reason.getText().toString().trim();
            String notesValue = notes.getText().toString().trim();
            if (reasonValue.isEmpty() || notesValue.isEmpty()) { actionStatus.setText("Informe o motivo e a justificativa da revisão."); return; }
            new AlertDialog.Builder(this).setTitle("Confirmar desbloqueio")
                    .setMessage("Desbloquear a conta " + field(adminTarget, "account") + "?\n\nMotivo: " + reasonValue)
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Confirmar", (dialog, which) -> performAdminUnlock(reasonValue, notesValue, unlock, actionStatus, resultStatus))
                    .show();
        });
    }

    protected void performAdminUnlock(String reason, String notes, Button button, TextView actionStatus, TextView resultStatus) {
        button.setEnabled(false);
        actionStatus.setText("Registrando a revisão de segurança...");
        String now = isoNow();
        JSONObject payload = new JSONObject();
        try {
            payload.put("security_locked", "FALSE");
            payload.put("account_locked", "FALSE");
            payload.put("security_status", "desbloqueado");
            payload.put("security_unlock_reason", reason);
            payload.put("security_unlock_notes", notes);
            payload.put("security_unlocked_by", field(currentUser, "account", "admin"));
            payload.put("security_unlocked_at", now);
            payload.put("security_unlock_command", "UNLOCK-" + field(adminTarget, "account") + "-" + System.currentTimeMillis());
            payload.put("security_unlock_command_at", now);
            payload.put("security_unlock_usage_count", number(field(adminTarget, "security_lock_count")));
            payload.put("security_balance_blocked", "FALSE");
            payload.put("available_balance_blocked", "FALSE");
            payload.put("neo_card_security_blocked", "FALSE");
            payload.put("neo_card_security_status", "desbloqueado");
            payload.put("balance_status", "desbloqueado");
            payload.put("security_lock_reason", "");
        } catch (Exception error) {
            button.setEnabled(true);
            actionStatus.setText("Não foi possível preparar o desbloqueio.");
            return;
        }
        accountUpdate(field(adminTarget, "account"), payload, new RpcCallback() {
            @Override public void success(Object result) {
                runOnUiThread(() -> {
                    button.setEnabled(false);
                    copyJsonValues(adminTarget, payload);
                    resultStatus.setText("Conta " + field(adminTarget, "account") + " — liberada\nComando de desbloqueio enviado ao aplicativo do usuário.");
                    actionStatus.setText("Desbloqueio confirmado em " + new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("pt", "BR")).format(new Date()) + ".");
                    Toast.makeText(NativeBaseActivity.this, "Conta desbloqueada com o motivo registrado.", Toast.LENGTH_LONG).show();
                });
            }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); actionStatus.setText(message); }); }
        });
    }

    protected void pollSecurityUnlockCommand() {
        if (!securityScreenVisible || currentUser == null) return;
        JSONObject payload = new JSONObject();
        try { payload.put("p_account", field(currentUser, "account")); payload.put("p_role", JSONObject.NULL); } catch (Exception ignored) { }
        rpc("sanbank_account_search", payload, new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject record = firstObject(result);
                if (record == null) return;
                record = normalizeRecord(record);
                if (isSecurityLocked(record)) return;
                String command = field(record, "security_unlock_command");
                if (command.isEmpty() || command.equals(securityUnlockCommandSeen)) return;
                securityUnlockCommandSeen = command;
                currentUser = record;
                runOnUiThread(() -> { stopSecurityPolling(); Toast.makeText(NativeBaseActivity.this, "Comando recebido. Sua conta está liberada.", Toast.LENGTH_LONG).show(); showDashboard(); });
            }
            @Override public void failure(String ignored) { }
        });
    }

    protected void stopSecurityPolling() {
        securityScreenVisible = false;
        securityHandler.removeCallbacks(securityPoller);
    }

    protected void countNeoOperations(String account, OperationCallback callback) {
        if (account == null || account.trim().isEmpty()) { callback.failure("Conta vazia"); return; }
        listTab("extrato", account, new ListCallback() {
            @Override public void success(JSONArray statements) {
                listTab("Pix", account, new ListCallback() {
                    @Override public void success(JSONArray pix) { callback.success(countOperationKeys(statements, pix)); }
                    @Override public void failure(String message) { callback.success(countOperationKeys(statements, new JSONArray())); }
                });
            }
            @Override public void failure(String message) {
                listTab("Pix", account, new ListCallback() {
                    @Override public void success(JSONArray pix) { callback.success(countOperationKeys(new JSONArray(), pix)); }
                    @Override public void failure(String ignored) { callback.failure(message); }
                });
            }
        });
    }

    protected int countOperationKeys(JSONArray statements, JSONArray pix) {
        Set<String> keys = new HashSet<>();
        addOperationKeys(keys, statements);
        addOperationKeys(keys, pix);
        return keys.size();
    }

    protected void addOperationKeys(Set<String> keys, JSONArray records) {
        for (int i = 0; i < records.length(); i++) {
            JSONObject record = records.optJSONObject(i);
            if (record == null) continue;
            String marker = (field(record, "title") + " " + field(record, "description") + " " + field(record, "transaction_type") + " " + field(record, "category") + " " + field(record, "biller")).toLowerCase(Locale.US);
            boolean pixCard = !field(record, "pix_key").isEmpty() || !field(record, "card_account").isEmpty() || field(record, "id").matches("(?i)^PIX-CARTAO-.*");
            boolean mentionsNeo = marker.matches(".*(neo|bradesco|cart[aã]o).*" ) || pixCard;
            boolean payment = marker.matches(".*(pagamento|fatura|boleto|quita[cç][aã]o).*" ) && !pixCard;
            if (!mentionsNeo || payment) continue;
            String key = operationKey(record);
            if (!key.isEmpty()) keys.add(key);
        }
    }

    protected String operationKey(JSONObject record) {
        String transaction = field(record, "transaction_id");
        if (transaction.isEmpty()) transaction = field(record, "operation_id");
        if (!transaction.isEmpty()) return "transaction:" + transaction.replaceFirst("(?i)^PIX-CARTAO-", "");
        String pixId = field(record, "pix_record_id");
        if (pixId.matches("(?i)^PIX-CARTAO-.*")) return "transaction:" + pixId.replaceFirst("(?i)^PIX-CARTAO-", "");
        String id = field(record, "id");
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("(?i)^EXTRATO-(PIX-CARTAO-.+?)-\\d+$").matcher(id);
        if (matcher.find()) return "transaction:" + matcher.group(1).replaceFirst("(?i)^PIX-CARTAO-", "");
        if (id.matches("(?i)^PIX-CARTAO-.*")) return "transaction:" + id.replaceFirst("(?i)^PIX-CARTAO-", "");
        String fallback = field(record, "account") + "|" + field(record, "pix_key") + "|" + field(record, "description").replaceAll("(?i)parcela\\s+\\d+/\\d+", "") + "|" + field(record, "amount");
        return fallback.replace("|", "").trim().isEmpty() ? "" : "fallback:" + fallback;
    }

    protected void exportStatementPdf() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT <= Build.VERSION_CODES.P && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingStatementAccount = field(currentUser, "account");
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_STORAGE);
            Toast.makeText(this, "Permita o armazenamento para salvar o extrato.", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Consultando lançamentos do extrato...", Toast.LENGTH_SHORT).show();
        listTab("extrato", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) { runOnUiThread(() -> createAndOpenStatement(records)); }
            @Override public void failure(String message) { runOnUiThread(() -> Toast.makeText(NativeBaseActivity.this, message, Toast.LENGTH_LONG).show()); }
        });
    }

    protected void createAndOpenStatement(JSONArray records) {
        if (records == null || records.length() == 0) { Toast.makeText(this, "Não há transações disponíveis para exportar.", Toast.LENGTH_LONG).show(); return; }
        String name = "extrato-sanbank-" + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()) + ".pdf";
        PdfDocument document = new PdfDocument();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        int pageNumber = 1;
        PdfDocument.Page page = null;
        Canvas canvas = null;
        int y = 0;
        try {
            for (int i = 0; i < records.length(); i++) {
                if (page == null || y > 770) {
                    if (page != null) document.finishPage(page);
                    PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, pageNumber++).create();
                    page = document.startPage(info);
                    canvas = page.getCanvas();
                    paint.setColor(Color.rgb(15, 23, 42));
                    canvas.drawColor(Color.WHITE);
                    canvas.drawRect(0, 0, 595, 66, paint);
                    paint.setColor(Color.rgb(56, 189, 248)); canvas.drawRect(0, 62, 595, 66, paint);
                    paint.setColor(Color.WHITE); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(20); canvas.drawText("SANBANK BR DIGITAL", 28, 28, paint);
                    paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(10); paint.setColor(Color.rgb(186, 230, 253)); canvas.drawText("EXTRATO FINANCEIRO  ·  CONTA " + field(currentUser, "account"), 28, 48, paint);
                    paint.setColor(Color.rgb(15, 23, 42)); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(11); canvas.drawText("Data", 24, 91, paint); canvas.drawText("Operação", 122, 91, paint); canvas.drawText("Detalhes", 310, 91, paint); canvas.drawText("Valor", 510, 91, paint);
                    paint.setColor(Color.rgb(226, 232, 240)); canvas.drawRect(22, 99, 573, 100, paint);
                    y = 122;
                }
                JSONObject record = records.optJSONObject(i);
                if (record == null) continue;
                paint.setColor(Color.rgb(30, 41, 59)); paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(9);
                canvas.drawText(shortText(field(record, "date", field(record, "created_at", "--")), 16), 24, y, paint);
                canvas.drawText(shortText(field(record, "title", field(record, "transaction_type", "Transação")), 27), 122, y, paint);
                canvas.drawText(shortText(statementUserDescription(record).isEmpty() ? "--" : statementUserDescription(record), 28), 310, y, paint);
                paint.setColor(statementAmountColor(record));
                canvas.drawText(shortText(statementAmountLabel(record), 15), 498, y, paint);
                paint.setColor(Color.rgb(226, 232, 240)); canvas.drawRect(22, y + 9, 573, y + 10, paint);
                y += 28;
            }
            if (page != null) {
                paint.setColor(Color.rgb(100, 116, 139)); paint.setTextSize(8); paint.setTypeface(Typeface.DEFAULT);
                canvas.drawText("Documento informativo · SANBANK BR DIGITAL", 24, 820, paint);
                document.finishPage(page);
            }
            Uri uri = savePdf(document, name);
            document.close();
            if (uri != null) { Toast.makeText(this, "Extrato salvo em Download/" + STATEMENT_FOLDER + ".", Toast.LENGTH_LONG).show(); openPdf(uri); }
            else Toast.makeText(this, "Não foi possível salvar o extrato.", Toast.LENGTH_LONG).show();
        } catch (Exception error) {
            try { document.close(); } catch (Exception ignored) { }
            Toast.makeText(this, "Não foi possível gerar o PDF do extrato.", Toast.LENGTH_LONG).show();
        }
    }

    protected Uri savePdf(PdfDocument document, String name) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + STATEMENT_FOLDER);
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Não foi possível criar o arquivo.");
            try (OutputStream output = getContentResolver().openOutputStream(uri)) { document.writeTo(output); }
            values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0); getContentResolver().update(uri, values, null, null);
            return uri;
        }
        File folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), STATEMENT_FOLDER);
        if (!folder.exists() && !folder.mkdirs()) throw new IOException("Pasta indisponível");
        File file = new File(folder, name);
        try (OutputStream output = new FileOutputStream(file)) { document.writeTo(output); }
        return SanbankFileProvider.uriForFile(this, file, "external");
    }

    protected void openPdf(Uri uri) {
        if (uri == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (ActivityNotFoundException error) { Toast.makeText(this, "Nenhum aplicativo consegue abrir PDF neste aparelho.", Toast.LENGTH_LONG).show(); }
    }

    protected void checkForUpdate(boolean interactive) {
        JSONObject payload = new JSONObject();
        try { payload.put("p_source_tab", "atualizacao"); payload.put("p_filters", new JSONObject()); } catch (Exception ignored) { }
        rpc("sanbank_api_list", payload, new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject latest = latestUpdate(result);
                if (latest == null) { if (interactive) runOnUiThread(() -> Toast.makeText(NativeBaseActivity.this, "Nenhuma versão publicada para este aplicativo.", Toast.LENGTH_LONG).show()); return; }
                String current = installedVersion();
                if (compareVersions(latest.optString("version"), current) <= 0) { if (interactive) runOnUiThread(() -> Toast.makeText(NativeBaseActivity.this, "O aplicativo já está atualizado.", Toast.LENGTH_SHORT).show()); return; }
                runOnUiThread(() -> showUpdateDialog(latest, current));
            }
            @Override public void failure(String message) { if (interactive) runOnUiThread(() -> Toast.makeText(NativeBaseActivity.this, message, Toast.LENGTH_LONG).show()); }
        });
    }

    protected JSONObject latestUpdate(Object result) {
        JSONArray array = result instanceof JSONArray ? (JSONArray) result : new JSONArray();
        JSONObject best = null;
        for (int i = 0; i < array.length(); i++) {
            JSONObject item = array.optJSONObject(i);
            if (item == null) continue;
            String pkg = firstField(item, "package_name", "package", "packageId", "app_package", "android_package");
            if (!pkg.isEmpty() && !getPackageName().equals(pkg)) continue;
            String version = firstField(item, "version_name", "version", "app_version", "versao", "versão");
            String url = firstField(item, "download_url", "apk_url", "url", "link");
            if (version.isEmpty() || !url.startsWith("https://")) continue;
            if (best == null || compareVersions(version, best.optString("version")) > 0) {
                try { item.put("version", version); item.put("downloadUrl", url); item.put("notes", firstField(item, "release_notes", "notes", "changelog", "novidades")); best = item; } catch (Exception ignored) { }
            }
        }
        return best;
    }

    protected void showUpdateDialog(JSONObject update, String current) {
        String notes = update.optString("notes", "Nenhum changelog informado.");
        new AlertDialog.Builder(this).setTitle("Nova versão " + update.optString("version"))
                .setMessage("Versão instalada: " + current + "\n\nNovidades:\n" + notes)
                .setNegativeButton("Agora não", null)
                .setPositiveButton("Baixar atualização", (dialog, which) -> {
                    Intent intent = new Intent(this, UpdateDownloadActivity.class);
                    intent.putExtra("download_url", update.optString("downloadUrl"));
                    intent.putExtra("update_version", update.optString("version"));
                    intent.putExtra("update_notes", notes);
                    startActivity(intent);
                })
                .show();
    }

    protected void enqueueUpdate(String url, String version) {
        if (!url.startsWith("https://")) { Toast.makeText(this, "O link de atualização não é seguro.", Toast.LENGTH_LONG).show(); return; }
        try {
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle("SANBANK BR DIGITAL " + version);
            request.setDescription("Baixando atualização do aplicativo");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "SANBANK-" + version + ".apk");
            pendingDownloadId = manager.enqueue(request);
            pendingUpdateUrl = url;
            pendingUpdateVersion = version;
            prefs().edit().putLong(PREF_DOWNLOAD_ID, pendingDownloadId).putString(PREF_UPDATE_URL, url).apply();
            Toast.makeText(this, "Download iniciado. Ao terminar, a Activity de instalação será aberta.", Toast.LENGTH_LONG).show();
            monitorDownload(pendingDownloadId);
        } catch (Exception error) { Toast.makeText(this, "Não foi possível iniciar a atualização.", Toast.LENGTH_LONG).show(); }
    }

    protected void monitorDownload(final long id) {
        mainHandler.postDelayed(new Runnable() {
            @Override public void run() {
                DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Query query = new DownloadManager.Query().setFilterById(id);
                android.database.Cursor cursor = manager == null ? null : manager.query(query);
                boolean again = true;
                if (cursor != null) {
                    if (cursor.moveToFirst()) {
                        int status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                        if (status == DownloadManager.STATUS_SUCCESSFUL) { again = false; openUpdateInstaller(id); }
                        else if (status == DownloadManager.STATUS_FAILED) { again = false; Toast.makeText(NativeBaseActivity.this, "O download da atualização falhou.", Toast.LENGTH_LONG).show(); clearPendingDownload(); }
                    }
                    cursor.close();
                }
                if (again && pendingDownloadId == id) mainHandler.postDelayed(this, 1000L);
            }
        }, 800L);
    }

    protected void openUpdateInstaller(long id) {
        Intent intent = new Intent(this, UpdateInstallerActivity.class);
        intent.putExtra("download_id", id);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try { startActivity(intent); }
        catch (Exception error) { Toast.makeText(this, "Não foi possível abrir a Activity de instalação.", Toast.LENGTH_LONG).show(); }
    }

    protected void installDownloadedApk(long id) {
        openUpdateInstaller(id);
    }

    protected void loadPendingDownload() {
        pendingDownloadId = prefs().getLong(PREF_DOWNLOAD_ID, -1L);
        pendingUpdateUrl = prefs().getString(PREF_UPDATE_URL, "");
        if (pendingDownloadId >= 0) monitorDownload(pendingDownloadId);
    }

    protected void clearPendingDownload() {
        pendingDownloadId = -1L;
        prefs().edit().remove(PREF_DOWNLOAD_ID).remove(PREF_UPDATE_URL).apply();
    }

    protected void handleInstallIntent(Intent intent) {
        if (intent != null && intent.getBooleanExtra("download_complete", false) && pendingDownloadId >= 0) installDownloadedApk(pendingDownloadId);
    }

    protected String installedVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception error) { return "0.1.0"; }
    }

    protected int compareVersions(String a, String b) {
        String[] left = String.valueOf(a == null ? "0" : a).replaceAll("[^0-9.]", "").split("\\.");
        String[] right = String.valueOf(b == null ? "0" : b).replaceAll("[^0-9.]", "").split("\\.");
        for (int i = 0; i < Math.max(left.length, right.length); i++) {
            int x = i < left.length && !left[i].isEmpty() ? Integer.parseInt(left[i]) : 0;
            int y = i < right.length && !right[i].isEmpty() ? Integer.parseInt(right[i]) : 0;
            if (x != y) return x > y ? 1 : -1;
        }
        return 0;
    }

    /** Envia somente os dados técnicos autorizados na tela de privacidade. */
    protected void recordDeviceRegistration(RpcCallback callback) {
        String consent = prefs().getString("device_privacy_decision", "");
        if (!"accepted".equals(consent) || currentUser == null || sessionToken.trim().isEmpty()) {
            if (callback != null) callback.failure("Consentimento ou sessão indisponível.");
            return;
        }
        String account = field(currentUser, "account");
        if (!account.matches("\\d{6}") || "admin".equalsIgnoreCase(field(currentUser, "role"))) {
            if (callback != null) callback.failure("Esta conta não pode registrar um aparelho cliente.");
            return;
        }
        String installId = prefs().getString("device_install_id", "");
        if (!installId.matches("[0-9a-fA-F-]{36}")) {
            installId = UUID.randomUUID().toString();
            prefs().edit().putString("device_install_id", installId).apply();
        }
        JSONObject payload = new JSONObject();
        try {
            payload.put("account", account);
            payload.put("consent_status", "accepted");
            payload.put("consent_version", prefs().getString("device_privacy_version", "2026-09-v1"));
            payload.put("installation_id", installId);
            payload.put("device_manufacturer", Build.MANUFACTURER == null ? "" : Build.MANUFACTURER);
            payload.put("device_model", Build.MODEL == null ? "" : Build.MODEL);
            payload.put("android_version", Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE);
            payload.put("android_sdk", Build.VERSION.SDK_INT);
            String appVersion = "";
            try { appVersion = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
            payload.put("app_version", appVersion == null ? "" : appVersion);
            addApproximateLocation(payload);
        } catch (Exception ignored) { }
        JSONObject body = new JSONObject();
        try { body.put("p_payload", payload); } catch (Exception ignored) { }
        rpc("sanbank_record_device_registration", body, callback == null ? new RpcCallback() {
            @Override public void success(Object result) { }
            @Override public void failure(String message) { }
        } : callback);
    }

    private void addApproximateLocation(JSONObject payload) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        try {
            LocationManager manager = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (manager == null) return;
            Location location = null;
            try { location = manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); } catch (Exception ignored) { }
            if (location == null) try { location = manager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER); } catch (Exception ignored) { }
            if (location == null) return;
            double latitude = Math.round(location.getLatitude() * 100.0d) / 100.0d;
            double longitude = Math.round(location.getLongitude() * 100.0d) / 100.0d;
            payload.put("approx_latitude", latitude);
            payload.put("approx_longitude", longitude);
            payload.put("approx_location_time", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(new Date(location.getTime())));
            payload.put("approx_location_accuracy_m", Math.max(0, Math.round(location.getAccuracy())));
        } catch (Exception ignored) { }
    }

    /** Apaga o cadastro remoto da instalação após o usuário revogar o consentimento. */
    protected void deleteDeviceRegistration(RpcCallback callback) {
        String account = currentUser == null ? prefs().getString("session_account", "") : field(currentUser, "account");
        String installId = prefs().getString("device_install_id", "");
        if (!account.matches("\\d{6}") || !installId.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")) {
            if (callback != null) callback.success(new JSONObject());
            return;
        }
        if (sessionToken.trim().isEmpty()) {
            if (callback != null) callback.failure("Sessão indisponível para remover o cadastro remoto.");
            return;
        }
        JSONObject body = new JSONObject();
        try { body.put("p_installation_id", installId); } catch (Exception ignored) { }
        rpc("sanbank_delete_device_registration", body, callback == null ? new RpcCallback() {
            @Override public void success(Object result) { }
            @Override public void failure(String message) { }
        } : callback);
    }

    protected void accountUpdate(String account, JSONObject payload, RpcCallback callback) {
        JSONObject body = new JSONObject();
        try { body.put("p_account", account); body.put("p_payload", payload); } catch (Exception ignored) { }
        rpc("sanbank_api_account_update", body, callback);
    }

    protected void apiUpsert(String tab, JSONObject payload, RpcCallback callback) {
        JSONObject body = new JSONObject();
        try { body.put("p_source_tab", tab); body.put("p_payload", payload); } catch (Exception ignored) { }
        rpc("sanbank_api_upsert", body, callback);
    }

    protected void apiDelete(String tab, String id, RpcCallback callback) {
        JSONObject body = new JSONObject();
        try { body.put("p_source_tab", tab); body.put("p_id", id); } catch (Exception ignored) { }
        rpc("sanbank_api_delete", body, callback);
    }

    protected void listTab(String tab, String account, ListCallback callback) {
        JSONObject filters = new JSONObject();
        try { filters.put("account", account); } catch (Exception ignored) { }
        listTabWithFilters(tab, filters, callback);
    }

    protected void listTabWithFilters(String tab, JSONObject filters, ListCallback callback) {
        JSONObject payload = new JSONObject();
        try { payload.put("p_source_tab", tab); payload.put("p_filters", filters == null ? new JSONObject() : filters); } catch (Exception ignored) { }
        rpc("sanbank_api_list", payload, new RpcCallback() {
            @Override public void success(Object result) { callback.success(result instanceof JSONArray ? (JSONArray) result : new JSONArray()); }
            @Override public void failure(String message) { callback.failure(message); }
        });
    }

    protected interface RpcCallback { void success(Object result); void failure(String message); }
    protected interface ListCallback { void success(JSONArray records); void failure(String message); }
    protected interface OperationCallback { void success(int count); void failure(String message); }

    /** Hooks para mostrar o carregamento circular nas Activities de funções. */
    protected void onNetworkRequestStarted() { }
    protected void onNetworkRequestFinished() { }

    protected void rpc(String function, JSONObject body, RpcCallback callback) {
        onNetworkRequestStarted();
        network.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(SUPABASE_URL + "/rest/v1/rpc/" + function);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST"); connection.setConnectTimeout(15000); connection.setReadTimeout(20000); connection.setDoOutput(true);
                connection.setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY);
                connection.setRequestProperty("Authorization", "Bearer " + SUPABASE_PUBLISHABLE_KEY);
                connection.setRequestProperty("Content-Type", "application/json");
                if (!sessionToken.isEmpty()) connection.setRequestProperty("x-sanbank-session", sessionToken);
                byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream output = connection.getOutputStream()) { output.write(data); output.flush(); }
                int code = connection.getResponseCode();
                String response = read(code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream());
                if (code < 200 || code >= 300) throw new IOException("Não foi possível consultar o Supabase agora.");
                String clean = response == null || response.trim().isEmpty() ? "{}" : response.trim();
                Object parsed = clean.startsWith("[") ? new JSONArray(clean) : new JSONObject(clean);
                callback.success(parsed);
            } catch (Exception error) { callback.failure("Não foi possível conectar ao SANBANK agora."); }
            finally {
                if (connection != null) connection.disconnect();
                onNetworkRequestFinished();
            }
        });
    }

    protected String read(InputStream stream) throws IOException {
        if (stream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder result = new StringBuilder(); String line;
        while ((line = reader.readLine()) != null) result.append(line);
        reader.close(); return result.toString();
    }

    protected String readAssetText(String assetName) {
        try (InputStream input = getAssets().open(assetName)) { return read(input); }
        catch (Exception error) { return ""; }
    }

    protected JSONObject firstObject(Object result) {
        if (result instanceof JSONObject) return (JSONObject) result;
        if (result instanceof JSONArray) return ((JSONArray) result).optJSONObject(0);
        return null;
    }

    protected JSONObject latestRecord(JSONArray records) {
        return records == null || records.length() == 0 ? null : records.optJSONObject(records.length() - 1);
    }

    protected void copyJsonValues(JSONObject target, JSONObject source) {
        if (target == null || source == null) return;
        try {
            java.util.Iterator<String> iterator = source.keys();
            while (iterator.hasNext()) {
                String key = iterator.next();
                target.put(key, source.opt(key));
            }
        } catch (Exception ignored) { }
    }

    protected JSONObject normalizeRecord(JSONObject record) {
        JSONObject normalized = new JSONObject();
        try {
            JSONObject legacy = record.optJSONObject("legacy_data");
            copyJsonValues(normalized, legacy);
            copyJsonValues(normalized, record);
            if (legacy != null) {
                String[] securityKeys = {"security_locked", "account_locked", "user_blocked", "security_status", "security_lock_reason", "security_lock_count", "security_locked_at", "security_unlock_reason", "security_unlock_notes", "security_unlocked_by", "security_unlocked_at", "security_unlock_command", "security_unlock_command_at", "security_unlock_usage_count", "neo_security_unlock_usage_count", "security_balance_blocked", "available_balance_blocked", "balance_security_blocked", "balance_status", "neo_card_security_blocked", "card_security_blocked", "neo_card_security_status", "card_security_status", "security_limit_operations"};
                for (String key : securityKeys) if (legacy.has(key)) normalized.put(key, legacy.opt(key));
            }
        } catch (Exception ignored) { return record; }
        return normalized;
    }

    protected String field(JSONObject object, String key) { return field(object, key, ""); }
    protected String field(JSONObject object, String key, String fallback) {
        if (object == null) return fallback;
        Object value = object.opt(key);
        if (value == null || value == JSONObject.NULL || String.valueOf(value).trim().isEmpty()) {
            JSONObject legacy = object.optJSONObject("legacy_data");
            if (legacy != null) value = legacy.opt(key);
        }
        return value == null || value == JSONObject.NULL ? fallback : String.valueOf(value).trim();
    }

    protected String firstField(JSONObject object, String... keys) { for (String key : keys) { String value = field(object, key); if (!value.isEmpty()) return value; } return ""; }
    protected int number(String value) { try { return Math.max(0, (int) Math.floor(Double.parseDouble(value.replace(".", ".").replace(",", ".")))); } catch (Exception error) { return 0; } }
    protected double decimal(String value) {
        try {
            String raw = String.valueOf(value == null ? "" : value).trim().replaceAll("[^0-9,.-]", "");
            if (raw.contains(",")) raw = raw.replace(".", "").replace(",", ".");
            return raw.isEmpty() ? 0 : Double.parseDouble(raw);
        } catch (Exception error) { return 0; }
    }
    protected String formatMoney(double value) {
        String number = String.format(new Locale("pt", "BR"), "%,.2f", Math.abs(value));
        return (value < 0 ? "-R$ " : "R$ ") + number;
    }
    protected String formatCardDate(String value) {
        String raw = String.valueOf(value == null ? "" : value).trim();
        if (raw.isEmpty()) return "Não informado";
        if (raw.matches("\\d{4}-\\d{2}-\\d{2}.*")) {
            String date = raw.substring(0, 10);
            return date.substring(8, 10) + "/" + date.substring(5, 7) + "/" + date.substring(0, 4);
        }
        return raw;
    }
    protected String formatNeoBillingDate(String value, int fallbackDay) {
        String raw = String.valueOf(value == null ? "" : value).trim();
        if (raw.isEmpty()) return "Todo dia " + fallbackDay;
        if (raw.matches("\\d{1,2}")) {
            int day = number(raw);
            return "Todo dia " + (day >= 1 && day <= 31 ? day : fallbackDay);
        }
        return formatCardDate(raw);
    }
    protected boolean isSecurityDisplayStatus(String status) {
        String value = String.valueOf(status == null ? "" : status).toLowerCase(Locale.ROOT);
        boolean explicitlyUnlocked = value.matches(".*(desbloquead|unlocked|liberad).*" );
        boolean resourceBlocked = value.matches(".*(saldo[_ ]?bloquead|balance[_ ]?blocked|cart[aã]o[_ ]?bloquead|card[_ ]?blocked|bloquead[_ ]?por[_ ]?(motivo[_ ]?de[_ ]?)?seguran|security[_ ]?(balance|card)[_ ]?blocked).*" );
        if (explicitlyUnlocked && !resourceBlocked) return false;
        return value.matches(".*(bloquead|seguran|security|locked|motivo de seguran|motivo_de_seguran).*" );
    }

    protected boolean isAdminApprovalPendingStatus(String status) {
        String value = String.valueOf(status == null ? "" : status).toLowerCase(Locale.ROOT);
        return value.matches(".*(aguard|pendente|pending|aprova[cç][aã]o|approval|em_an[aá]lise|em analise|an[aá]lise administrativa).*" );
    }

    protected int statusDisplayColor(String status) {
        if (isSecurityDisplayStatus(status)) return Color.rgb(30, 64, 175);
        if (isAdminApprovalPendingStatus(status)) return Color.rgb(251, 191, 36);
        return Color.rgb(186, 230, 253);
    }

    protected GradientDrawable statusDisplayBackground(String status) {
        if (isSecurityDisplayStatus(status)) return rounded(Color.argb(175, 15, 34, 69), Color.argb(150, 30, 64, 175), 11);
        if (isAdminApprovalPendingStatus(status)) return rounded(Color.argb(42, 245, 158, 11), Color.argb(145, 251, 191, 36), 11);
        return rounded(Color.argb(218, 7, 39, 54), Color.argb(82, 45, 212, 191), 16);
    }

    protected String accountBalanceStatus() {
        if (currentUser == null) return "";
        return field(currentUser, "balance_status") + " " + field(currentUser, "balance_approval_status") + " "
                + field(currentUser, "account_status") + " " + field(currentUser, "approval_status") + " "
                + field(currentUser, "security_status") + " " + field(currentUser, "security_lock_reason");
    }

    protected String comparableSignedValue(String rawValue) {
        return String.valueOf(rawValue == null ? "" : rawValue)
                .replace("R$", "")
                .replace("BRL", "")
                .replace("brl", "")
                .replace("\u00A0", " ")
                .trim();
    }

    protected int signedDisplayColor(String rawValue) {
        String raw = comparableSignedValue(rawValue);
        if (raw.startsWith("-") || raw.startsWith("−")) return Color.rgb(239, 68, 68);
        if (raw.startsWith("+")) return Color.rgb(34, 197, 94);
        return TEXT;
    }

    protected int signedDisplayColor(String rawValue, String status) {
        if (isSecurityDisplayStatus(status)) return Color.rgb(30, 58, 138);
        if (isAdminApprovalPendingStatus(status)) return Color.rgb(251, 191, 36);
        return signedDisplayColor(rawValue);
    }

    protected String statementSearchText(JSONObject record) {
        return (firstField(record, "status", "state", "") + " " + firstField(record, "title", "transaction_type", "category", "type", "") + " "
                + firstField(record, "description", "details", "detail", "biller", "") + " " + firstField(record, "date", "created_at", "", ""))
                .toLowerCase(Locale.ROOT);
    }

    protected boolean isScheduledStatementRecord(JSONObject record) {
        String marker = statementSearchText(record);
        return marker.matches(".*(agendad|agendamento|scheduled|schedule|programad).*" );
    }

    protected boolean isFutureBenefitStatementRecord(JSONObject record) {
        String marker = statementSearchText(record);
        boolean benefit = marker.matches(".*(inss|aura\\s+previd[eê]ncia|aura\\s+previdencia).*" );
        boolean future = marker.matches(".*(futur|previst|lan[cç]amento\\s+futuro|benef[ií]cio\\s+futuro).*" )
                || truthy(firstField(record, "future", "is_future", "lancamento_futuro", "future_entry"));
        return benefit && (future || isScheduledStatementRecord(record));
    }

    protected boolean isOverdraftInterestStatementRecord(JSONObject record) {
        String marker = statementSearchText(record);
        return marker.matches(".*(juros.*cheque.*especial|cheque.*especial.*juros|juros_cheque_especial|overdraft.*interest).*" );
    }

    protected String statementUserDescription(JSONObject record) {
        if (isOverdraftInterestStatementRecord(record)) return "Cobrança automática de juros do Cheque Especial.";
        return firstField(record, "description", "details", "detail", "biller");
    }

    protected double statementSignedAmount(JSONObject record) {
        String raw = firstField(record, "amount", "value", "valor", "0");
        double amount = Math.abs(decimal(raw));
        if (raw.trim().startsWith("-")) return -amount;

        String direction = firstField(record, "direction", "flow", "movement", "type").trim().toLowerCase(Locale.ROOT);
        String transactionType = firstField(record, "transaction_type", "operation_type", "category").trim().toLowerCase(Locale.ROOT);
        boolean explicitDebit = direction.equals("out") || direction.equals("outgoing") || direction.equals("debit")
                || direction.equals("debito") || direction.equals("débito") || direction.endsWith("_debit") || direction.endsWith("_out")
                || transactionType.equals("debit") || transactionType.endsWith("_debit") || transactionType.endsWith("_out");
        if (explicitDebit) return -amount;

        boolean explicitCredit = direction.equals("in") || direction.equals("incoming") || direction.equals("credit")
                || direction.equals("credito") || direction.equals("crédito") || direction.endsWith("_credit") || direction.endsWith("_in")
                || transactionType.equals("credit") || transactionType.endsWith("_credit") || transactionType.endsWith("_in");
        if (explicitCredit) return amount;

        String marker = (firstField(record, "title", "transaction_type", "category", "type", "") + " "
                + firstField(record, "description", "details", "biller", "") + " "
                + firstField(record, "direction", "flow", "movement", "")).toLowerCase(Locale.ROOT);
        // A palavra “transferência” não indica sozinha o sentido: recebimentos DEM também a contêm.
        if (marker.matches(".*(entrada|cr[eé]dito|credito|recebid|recebimento|dep[oó]sito|cashback|income|incoming|inbound|credit).*")) return amount;

        String account = firstField(record, "account", "account_number", "owner_account");
        String sender = firstField(record, "sender_account", "sender", "from_account");
        String target = firstField(record, "target_account", "target", "to_account", "destination_account");
        boolean transferRecord = marker.contains("dem") || marker.contains("transfer");
        if (transferRecord && account.matches("\\d{6}") && sender.matches("\\d{6}") && target.matches("\\d{6}")) {
            if (account.equals(target) && !account.equals(sender)) return amount;
            if (account.equals(sender) && !account.equals(target)) return -amount;
        }

        boolean outgoingText = marker.matches(".*(sa[ií]da|debito|débito|pagamento|pix|compra|fatura|boleto|juros|interest|cobran[cç]a|cobranca|withdraw|retirada|outgoing|debit|enviad|sent).*" );
        return outgoingText ? -amount : amount;
    }

    protected String statementAmountLabel(JSONObject record) {
        double amount = Math.abs(decimal(firstField(record, "amount", "value", "valor", "0")));
        if (isFutureBenefitStatementRecord(record)) return "$ " + formatMoney(amount);
        if (isScheduledStatementRecord(record)) return "? " + formatMoney(amount);
        double signed = statementSignedAmount(record);
        if (signed < 0) return "- " + formatMoney(amount);
        if (signed > 0) return "+ " + formatMoney(amount);
        return formatMoney(amount);
    }

    protected int statementAmountColor(JSONObject record) {
        if (isOverdraftInterestStatementRecord(record)) return Color.rgb(239, 68, 68);
        String status = firstField(record, "status", "state");
        if (isSecurityDisplayStatus(status)) return Color.rgb(30, 64, 175);
        if (isAdminApprovalPendingStatus(status)) return Color.rgb(251, 191, 36);
        if (isFutureBenefitStatementRecord(record)) return Color.rgb(96, 165, 250);
        if (isScheduledStatementRecord(record)) return Color.rgb(251, 146, 60);
        double signed = statementSignedAmount(record);
        if (signed < 0) return Color.rgb(253, 164, 175);
        if (signed > 0) return Color.rgb(110, 231, 183);
        return TEXT;
    }

    protected int statementStatusColor(JSONObject record, String status) {
        if (isSecurityDisplayStatus(status)) return statusDisplayColor(status);
        if (isAdminApprovalPendingStatus(status)) return statusDisplayColor(status);
        if (isFutureBenefitStatementRecord(record)) return Color.rgb(96, 165, 250);
        if (isScheduledStatementRecord(record)) return Color.rgb(251, 146, 60);
        return statusDisplayColor(status);
    }

    protected GradientDrawable statementStatusBackground(JSONObject record, String status) {
        if (isFutureBenefitStatementRecord(record)) return rounded(Color.argb(30, 37, 99, 235), Color.argb(135, 96, 165, 250), 11);
        if (isScheduledStatementRecord(record)) return rounded(Color.argb(40, 245, 158, 11), Color.argb(145, 251, 146, 60), 11);
        return statusDisplayBackground(status);
    }

    protected String formatDashboardMoney(double value) {
        if (value < 0) return "-" + formatMoney(Math.abs(value));
        return formatMoney(value);
    }
    protected String isoNow() { return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(new Date()); }
    protected boolean truthy(String value) { return "true".equalsIgnoreCase(value) || "1".equals(value) || "sim".equalsIgnoreCase(value) || "bloqueado".equalsIgnoreCase(value) || "blocked".equalsIgnoreCase(value) || "locked".equalsIgnoreCase(value); }
    protected boolean isSecurityLocked(JSONObject record) { String status = field(record, "security_status"); return truthy(field(record, "security_locked")) || truthy(field(record, "account_locked")) || truthy(field(record, "user_blocked")) || "bloqueado".equalsIgnoreCase(status) || "blocked".equalsIgnoreCase(status) || "locked".equalsIgnoreCase(status); }
    protected String shortText(String value, int max) { String clean = String.valueOf(value == null ? "" : value).replaceAll("\\s+", " ").trim(); return clean.length() > max ? clean.substring(0, Math.max(0, max - 1)) + "…" : clean; }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_STORAGE && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && pendingStatementAccount != null) {
            pendingStatementAccount = null; exportStatementPdf();
        }
    }

    protected void reconcileAccountScreenAfterResume() {
        if (currentUser == null || isFinishing()) return;
        String accountStatus = firstField(currentUser, "account_status", "accountStatus", "status").toLowerCase(Locale.ROOT);
        boolean terminalAccount = accountStatus.matches(".*(cancelad|encerrad|bloqueio_definitivo|permanente).*") && !accountStatus.contains("solicit");
        if (terminalAccount) {
            if (dashboardVisible || securityScreenVisible || accountCommandScreenVisible || !dashboardRenderedAccountState.isEmpty()) showAccountCommandScreen();
            return;
        }
        if (isSecurityLocked(currentUser)) {
            if (dashboardVisible || accountCommandScreenVisible || !dashboardRenderedAccountState.isEmpty()) showSecurityLockScreen(number(field(currentUser, "security_lock_count")));
            return;
        }
        if (securityScreenVisible || accountCommandScreenVisible) {
            showDashboard();
            return;
        }
        String currentState = dashboardAccountSignature(currentUser);
        if (dashboardVisible && (dashboardNeedsRebuild || !dashboardRenderedAccountState.equals(currentState))) showDashboard();
    }

    protected boolean shouldMonitorAppAccess() {
        return currentUser != null && !sessionToken.isEmpty()
                && !"admin".equalsIgnoreCase(field(currentUser, "role"))
                && !(this instanceof LoginActivity)
                && !(this instanceof AppAccessBlockedActivity)
                && !(this instanceof SupportActivity);
    }

    protected void checkAppAccessStatus(boolean force) {
        if (!shouldMonitorAppAccess() || appAccessCheckInProgress) return;
        long now = System.currentTimeMillis();
        long lastCheck = prefs().getLong("app_access_last_check_ms", 0L);
        String lastAccount = prefs().getString("app_access_last_check_account", "");
        if (!force && field(currentUser, "account").equals(lastAccount) && now - lastCheck < 10000L) return;
        appAccessCheckInProgress = true;
        rpc("sanbank_check_my_app_access", new JSONObject(), new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject state = firstObject(result);
                mainHandler.post(() -> {
                    appAccessCheckInProgress = false;
                    if (isFinishing() || state == null) return;
                    prefs().edit().putLong("app_access_last_check_ms", System.currentTimeMillis()).putString("app_access_last_check_account", field(currentUser, "account")).apply();
                    if (state.optBoolean("blocked", false)) {
                        Intent intent = new Intent(NativeBaseActivity.this, AppAccessBlockedActivity.class);
                        intent.putExtra("block_id", state.optString("block_id", ""));
                        intent.putExtra("block_reason", state.optString("reason", ""));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    }
                });
            }
            @Override public void failure(String message) {
                mainHandler.post(() -> appAccessCheckInProgress = false);
            }
        });
    }

    @Override protected void onResume() {
        super.onResume();
        activityResumed = true;
        boolean accessBlockedPage = this instanceof AppAccessBlockedActivity;
        if (!accessBlockedPage) {
            reconcileAccountScreenAfterResume();
            syncAdministrativeControls();
            checkAppAccessStatus(false);
            appAccessHandler.removeCallbacks(appAccessPoller);
            if (shouldMonitorAppAccess()) appAccessHandler.postDelayed(appAccessPoller, 30000L);
        }
        if (dashboardVisible) {
            refreshDashboardAccount();
            startDashboardBalancePolling();
            if (dashboardPromoCarouselView != null) dashboardPromoCarouselView.startAutoAdvance();
        }
        if (pendingDownloadId >= 0) monitorDownload(pendingDownloadId);
        if (pendingDownloadId >= 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && getPackageManager().canRequestPackageInstalls()) installDownloadedApk(pendingDownloadId);
    }

    @Override protected void onPause() {
        activityResumed = false;
        appAccessHandler.removeCallbacks(appAccessPoller);
        stopDashboardBalancePolling();
        if (dashboardPromoCarouselView != null) dashboardPromoCarouselView.stopAutoAdvance();
        super.onPause();
    }

    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); handleInstallIntent(intent); }

    @Override protected void onDestroy() {
        activityResumed = false;
        closeNeoCardActionModal();
        stopDashboardBalancePolling(); dashboardBalanceHandler.removeCallbacksAndMessages(null);
        appAccessHandler.removeCallbacksAndMessages(null);
        stopSecurityPolling(); stopSupportPolling(); stopNativeNotificationPolling(); stopPendingStatusPolling(); if (dashboardPromoCarouselView != null) dashboardPromoCarouselView.stopAutoAdvance(); mainHandler.removeCallbacksAndMessages(null); network.shutdownNow(); super.onDestroy();
    }
}
