package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

/** Informações do aplicativo e compatibilidade. */
public final class AboutActivity extends FunctionActivityBase {
    @Override
    protected void onModuleReady() {
        beginFunctionPage("Sobre o SANBANK", "Informações da versão nativa completa.");
        LinearLayout brand = surfaceCard();
        brand.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        brand.addView(text("SANBANK BR DIGITAL", 22, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(34), 0, 4));
        brand.addView(text("Versão oficial · " + installedVersion(), 13, Color.rgb(125, 211, 252), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 12));
        brand.addView(text("Interface nativa por Activities independentes, com camada visual local em CSS/JavaScript.", 13, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        addCard(brand, 10);
        LinearLayout compatibility = surfaceCard();
        compatibility.addView(text("Compatibilidade", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 7));
        compatibility.addView(text("Android 5.0/API 21 até Android 17/API 37\nABIs: armeabi-v7a · arm64-v8a · x86 · x86_64\nPacote oficial: " + getPackageName(), 13, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        addCard(compatibility, 10);
        LinearLayout security = surfaceCard();
        security.addView(text("Segurança", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 7));
        security.addView(text("O aplicativo não persiste a senha. Sessões e operações usam os RPCs protegidos do SANBANK; pagamentos e cancelamentos continuam sujeitos à aprovação quando aplicável.", 13, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        addCard(security, 10);
        Button updates = secondaryButton("Verificar atualizações");
        page.addView(updates, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8));
        updates.setOnClickListener(v -> launchModule(UpdateCheckActivity.class));
        addBackButton();
    }
}
