package com.sanbank_br_digital.app;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/** Activity exclusiva para consultar e visualizar a distribuição do limite do Cartão Neo. */
public final class NeoAvailableLimitActivity extends NeoCardFunctionActivity {
    private static final int AVAILABLE_GREEN = Color.rgb(16, 185, 129);
    private static final int USED_RED = Color.rgb(239, 68, 68);
    private static final int TRACK = Color.rgb(31, 55, 84);

    @Override
    protected void onModuleReady() {
        beginNeoFunction("Limite disponível", "Visualize o limite total, o valor utilizado e o saldo disponível do Cartão Neo.");
        LinearLayout metrics = surfaceCard();
        addCard(metrics, 10);
        addBackButton();
        loadNeoCard(value -> {
            metrics.removeAllViews();
            double total = Math.max(0, neoTotal(value));
            double used = Math.min(total, Math.max(0, neoUsed(value)));
            double available = Math.min(total, Math.max(0, neoAvailable(value)));
            if (isNeoCardSecurityBlocked()) available = 0;
            int usedPercent = total > 0 ? clampPercent(Math.round((float) ((used / total) * 100))) : 0;
            int availablePercent = total > 0 ? clampPercent(Math.round((float) ((available / total) * 100))) : 0;

            metrics.addView(text("Distribuição do limite", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(27), 0, 3));
            metrics.addView(text("Acompanhe o que está disponível e o que já foi gasto.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 13));

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(neoNativeMetric("Limite total", formatMoney(total), false), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            LinearLayout.LayoutParams usedParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            usedParams.setMargins(dp(9), 0, 0, 0);
            row.addView(neoNativeMetric("Limite gasto", formatMoney(used), false), usedParams);
            metrics.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
            metrics.addView(neoNativeMetric("Disponível para uso", formatMoney(available), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));

            metrics.addView(progressLegend(), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(29), 0, 8));
            addProgressMetric(metrics, "Disponível", formatMoney(available), availablePercent, AVAILABLE_GREEN);
            addProgressMetric(metrics, "Gasto", formatMoney(used), usedPercent, USED_RED);

            LinearLayout summary = new LinearLayout(this);
            summary.setGravity(Gravity.CENTER_VERTICAL);
            summary.setPadding(dp(12), dp(10), dp(12), dp(10));
            summary.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
            TextView summaryLabel = text("Percentual utilizado", 12, MUTED, false);
            summary.addView(summaryLabel, new LinearLayout.LayoutParams(0, dp(24), 1));
            TextView summaryValue = text(usedPercent + "%", 20, USED_RED, true);
            summaryValue.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            summary.addView(summaryValue, new LinearLayout.LayoutParams(dp(68), dp(28)));
            metrics.addView(summary, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
            cardStatus.setText(isNeoCardSecurityBlocked() ? "O limite disponível está bloqueado por segurança." : "Limite consultado com sucesso.");
        });
    }

    private LinearLayout progressLegend() {
        LinearLayout legend = new LinearLayout(this);
        legend.setGravity(Gravity.CENTER_VERTICAL);
        TextView available = text("● Disponível", 11, AVAILABLE_GREEN, true);
        TextView used = text("● Gasto", 11, USED_RED, true);
        legend.addView(available, new LinearLayout.LayoutParams(0, dp(24), 1));
        legend.addView(used, new LinearLayout.LayoutParams(0, dp(24), 1));
        return legend;
    }

    private void addProgressMetric(LinearLayout parent, String label, String amount, int percent, int color) {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label + "  ·  " + amount, 12, color, true);
        header.addView(name, new LinearLayout.LayoutParams(0, dp(25), 1));
        TextView value = text(percent + "%", 12, color, true);
        value.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        header.addView(value, new LinearLayout.LayoutParams(dp(52), dp(25)));
        parent.addView(header, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 3));

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(percent);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            progress.setProgressTintList(ColorStateList.valueOf(color));
            progress.setProgressBackgroundTintList(ColorStateList.valueOf(TRACK));
        } else {
            progress.setProgressDrawable(progressDrawable(color));
        }
        parent.addView(progress, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(11), 0, 12));
    }

    private Drawable progressDrawable(int color) {
        GradientDrawable background = new GradientDrawable();
        background.setColor(TRACK);
        background.setCornerRadius(dp(7));
        GradientDrawable foreground = new GradientDrawable();
        foreground.setColor(color);
        foreground.setCornerRadius(dp(7));
        LayerDrawable layers = new LayerDrawable(new Drawable[]{background, new ClipDrawable(foreground, Gravity.LEFT, ClipDrawable.HORIZONTAL)});
        layers.setId(0, android.R.id.background);
        layers.setId(1, android.R.id.progress);
        return layers;
    }

    private int clampPercent(int value) { return Math.max(0, Math.min(100, value)); }
}
