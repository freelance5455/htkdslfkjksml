package com.sanbank_br_digital.app;

import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Alteração segura da senha com confirmação numérica de oito dígitos. */
public final class ChangePasswordActivity extends FunctionActivityBase {
    private EditText passwordInput;
    private EditText confirmInput;
    private TextView status;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Alterar senha", "Crie uma nova senha numérica de 8 dígitos para a sessão autenticada.");
        LinearLayout form = surfaceCard();
        passwordInput = numeric("Nova senha com 8 dígitos");
        confirmInput = numeric("Confirme a nova senha");
        form.addView(passwordInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        form.addView(confirmInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 12));
        Button save = primaryButton("Alterar senha");
        form.addView(save, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(form, 10);
        status = statusText("A senha nunca é exibida nem enviada ao aplicativo Services PAY.");
        save.setOnClickListener(v -> save(save));
        addBackButton();
    }

    private EditText numeric(String hint) {
        EditText field = functionInput(hint);
        field.setSingleLine(true);
        field.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        return field;
    }

    private void save(Button button) {
        String password = passwordInput.getText().toString().trim();
        String confirm = confirmInput.getText().toString().trim();
        if (!password.matches("\\d{8}")) { passwordInput.setError("Use exatamente 8 dígitos."); return; }
        if (!password.equals(confirm)) { confirmInput.setError("As senhas não coincidem."); return; }
        button.setEnabled(false);
        status.setText("Atualizando senha...");
        JSONObject payload = new JSONObject();
        try { payload.put("password", password); payload.put("password_updated_at", isoNow()); } catch (Exception ignored) { }
        accountUpdate(field(currentUser, "account"), payload, new RpcCallback() {
            @Override public void success(Object result) { runOnUiThread(() -> { button.setEnabled(true); passwordInput.setText(""); confirmInput.setText(""); status.setText("Senha alterada com sucesso."); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); status.setText(message); }); }
        });
    }
}
