package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** CDI, liquidação diária no servidor e histórico real da conta. */
public final class InvestmentActivity extends FunctionActivityBase {
    private final String[] tabs = {"Visão geral", "Elegível", "Rendimento", "Taxa CDI", "Liquidez", "24 horas", "Regras", "Histórico", "Gráficos", "Simulação"};
    private TextView panel;
    private TextView status;
    private Button refreshButton;
    private JSONObject yieldData = new JSONObject();
    private JSONArray history = new JSONArray();
    private int selectedTab;
    private boolean requestInProgress;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Saldo e CDI", "Liquidação de rendimento registrada no saldo e no extrato.");
        HorizontalScrollView scrollTabs = new HorizontalScrollView(this);
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setPadding(0, 0, 0, dp(6));
        for (int i = 0; i < tabs.length; i++) {
            final int index = i;
            Button tab = secondaryButton(tabs[i]);
            tab.setTextSize(11);
            tab.setMinHeight(dp(42));
            tab.setOnClickListener(v -> showTab(index));
            tabRow.addView(tab, new LinearLayout.LayoutParams(dp(128), dp(44)));
        }
        scrollTabs.addView(tabRow);
        page.addView(scrollTabs, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 8));

        panel = text("Consultando apuração de rendimento...", 13, Color.rgb(219, 234, 254), false);
        panel.setGravity(Gravity.TOP | Gravity.START);
        panel.setPadding(dp(15), dp(16), dp(15), dp(16));
        panel.setBackground(rounded(Color.argb(238, 8, 27, 45), Color.argb(92, 45, 212, 191), 22));
        page.addView(panel, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));

        status = text("A apuração usa o horário e o cálculo do servidor.", 11, MUTED, false);
        status.setSingleLine(false);
        page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 5));
        refreshButton = secondaryButton("Atualizar rendimento");
        refreshButton.setOnClickListener(v -> settleYield());
        page.addView(refreshButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(46), 0, 8));
        TextView notice = text("Somente saldo positivo participa; Cheque Especial não rende. Crédito efetivado aparece no saldo e no extrato. Estimativas não são valores creditados.", 11, MUTED, false);
        notice.setSingleLine(false);
        notice.setPadding(dp(12), dp(10), dp(12), dp(10));
        page.addView(notice, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        showTab(0);
        addBackButton();
        settleYield();
    }

    private void settleYield() {
        if (requestInProgress || refreshButton == null) return;
        requestInProgress = true;
        refreshButton.setEnabled(false);
        status.setText("Verificando saldo elegível e período de liquidez...");
        status.setTextColor(Color.rgb(125, 211, 252));
        rpc("sanbank_settle_daily_yield", new JSONObject(), new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject response = firstObject(result);
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    requestInProgress = false;
                    refreshButton.setEnabled(true);
                    if (response == null || !response.optBoolean("ok", false)) {
                        showUnavailable("O servidor não confirmou a apuração. Nenhum valor estimado será apresentado como crédito.");
                        return;
                    }
                    yieldData = response;
                    JSONArray serverHistory = response.optJSONArray("history");
                    history = serverHistory == null ? new JSONArray() : serverHistory;
                    if (response.optBoolean("credited", false) && currentUser != null) {
                        try {
                            currentUser.put("balance", String.format(Locale.US, "%.2f", response.optDouble("balance", 0)));
                            prefs().edit().putString("session_user_json", currentUser.toString()).apply();
                        } catch (Exception ignored) { }
                    }
                    updateStatus(response);
                    showTab(selectedTab);
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    requestInProgress = false;
                    refreshButton.setEnabled(true);
                    showUnavailable("Não foi possível confirmar a liquidação. Confira sua conexão e o extrato; o servidor impede créditos duplicados.");
                });
            }
        });
    }

    private void showUnavailable(String message) {
        if (status != null) {
            status.setText(message);
            status.setTextColor(Color.rgb(251, 191, 36));
        }
        if (yieldData.length() == 0 && panel != null) {
            panel.setText("A liquidação CDI ainda não foi confirmada pelo servidor. O saldo não é alterado por uma estimativa.");
        }
    }

    private void updateStatus(JSONObject response) {
        if (status == null) return;
        boolean credited = response.optBoolean("credited", false);
        String reason = response.optString("reason", "");
        String due = formatInstant(response.optString("next_settlement_at", ""));
        if (credited) {
            status.setText("Rendimento de " + formatMoney(response.optDouble("amount", 0)) + " creditado no saldo e registrado no extrato.");
            status.setTextColor(Color.rgb(52, 211, 153));
        } else if ("aguardando_carencia".equals(reason)) {
            status.setText("Carência de " + trimNumber(response.optDouble("grace_hours", 24)) + " horas em andamento. Previsão da próxima apuração: " + due + ".");
            status.setTextColor(Color.rgb(245, 158, 11));
        } else if ("aguardando_proxima_liquidacao".equals(reason)) {
            status.setText("O próximo crédito diário poderá ser apurado em " + due + ".");
            status.setTextColor(Color.rgb(245, 158, 11));
        } else if ("rendimento_abaixo_de_um_centavo".equals(reason)) {
            status.setText("Saldo em apuração. O crédito será lançado quando o rendimento acumulado atingir R$ 0,01.");
            status.setTextColor(Color.rgb(245, 158, 11));
        } else if ("liquidacao_ja_registrada".equals(reason)) {
            status.setText("Este período já tem lançamento registrado. Nenhum crédito duplicado foi feito.");
            status.setTextColor(Color.rgb(125, 211, 252));
        } else if ("sem_saldo_elegivel".equals(reason)) {
            status.setText("Não há saldo positivo elegível para rendimento neste momento.");
            status.setTextColor(MUTED);
        } else {
            status.setText("Apuração consultada no servidor. Próxima data: " + due + ".");
            status.setTextColor(Color.rgb(125, 211, 252));
        }
    }

    private void showTab(int index) {
        selectedTab = Math.max(0, Math.min(tabs.length - 1, index));
        if (panel == null) return;
        double balance = currentUser == null ? 0 : Math.max(0, decimal(field(currentUser, "balance")));
        double principal = yieldData.optDouble("eligible_balance", balance);
        double annual = yieldData.optDouble("cdi_annual_rate", 14.65);
        double productPercent = yieldData.optDouble("product_percent", 102);
        double dailyRate = (Math.pow(1 + annual / 100.0, 1.0 / 365.0) - 1) * (productPercent / 100.0);
        double dailyEstimate = Math.max(0, principal * dailyRate);
        double pendingEstimate = Math.max(0, yieldData.optDouble("estimated_accrued", 0));
        double totalCredited = totalHistoryAmount();
        String due = formatInstant(yieldData.optString("next_settlement_at", ""));
        String idleSince = formatInstant(yieldData.optString("idle_since", ""));
        String body;
        switch (selectedTab) {
            case 1:
                body = "Saldo elegível\n\n" + formatMoney(principal) + "\n\nSomente o saldo positivo da conta participa. Limite do Cheque Especial é excluído.";
                break;
            case 2:
                body = "Rendimento\n\nCréditos efetivados: " + formatMoney(totalCredited)
                        + "\nEm apuração (estimativa): " + formatMoney(pendingEstimate)
                        + "\nEstimativa para 24 horas: " + formatMoney(dailyEstimate)
                        + "\n\nA estimativa só vira crédito quando a liquidação do servidor é efetivada.";
                break;
            case 3:
                body = "Taxa CDI\n\nCDI anual de referência: " + percent(annual)
                        + "\nProduto: " + trimNumber(productPercent) + "% do CDI"
                        + "\nTaxa contratada aproximada: " + percent(annual * productPercent / 100.0)
                        + "\n\nA taxa aplicada segue a configuração do servidor.";
                break;
            case 4:
                body = "Liquidez diária\n\nApós o período mínimo configurado, o servidor apura o crédito diário e o registra no saldo e no extrato. O crédito só é considerado efetivado depois da confirmação do servidor.";
                break;
            case 5:
                body = "Contagem de 24 horas\n\nSaldo acompanhado desde: " + idleSince
                        + "\nPróxima apuração prevista: " + due
                        + "\n\nMudanças no saldo reiniciam a carência para o saldo atualizado.";
                break;
            case 6:
                body = "Regras\n\n• Apenas saldo positivo elegível.\n• Cheque Especial não rende.\n• Carência configurada: " + trimNumber(yieldData.optDouble("grace_hours", 24)) + " horas.\n• Crédito mínimo: R$ 0,01.\n• A liquidação é idempotente e registrada uma única vez no extrato.";
                break;
            case 7:
                body = historyText();
                break;
            case 8:
                body = "Resumo do histórico real\n\nCréditos encontrados: " + history.length()
                        + "\nTotal creditado: " + formatMoney(totalCredited)
                        + "\nÚltimo lançamento: " + (history.length() == 0 ? "Ainda não há créditos registrados." : formatInstant(history.optJSONObject(0).optString("date", "")))
                        + "\n\nO resumo usa somente lançamentos efetivamente registrados.";
                break;
            case 9:
                body = "Simulação futura (estimativa)\n\nSaldo elegível de referência: " + formatMoney(principal)
                        + "\nEstimativa diária: " + formatMoney(dailyEstimate)
                        + "\nProjeção simples em 30 dias: " + formatMoney(principal + dailyEstimate * 30)
                        + "\nProjeção estimada em 12 meses: " + formatMoney(principal * Math.pow(1 + dailyRate, 365))
                        + "\n\nA simulação não altera saldo e não garante resultado futuro.";
                break;
            default:
                body = "Visão geral\n\nSaldo atual: " + formatMoney(balance)
                        + "\nSaldo elegível: " + formatMoney(principal)
                        + "\nCDI anual: " + percent(annual)
                        + "\nProduto: " + trimNumber(productPercent) + "% do CDI"
                        + "\nLiquidez: diária\nCarência: " + trimNumber(yieldData.optDouble("grace_hours", 24)) + " horas"
                        + "\n\nTotal efetivamente creditado: " + formatMoney(totalCredited);
        }
        panel.setText(body);
    }

    private String historyText() {
        if (history.length() == 0) return "Histórico\n\nNenhum crédito CDI foi registrado para esta conta ainda.";
        StringBuilder text = new StringBuilder("Histórico de créditos efetivados\n\n");
        int count = Math.min(history.length(), 12);
        for (int i = 0; i < count; i++) {
            JSONObject row = history.optJSONObject(i);
            if (row == null) continue;
            text.append(formatInstant(row.optString("date", "")))
                    .append("  ·  ")
                    .append(formatMoney(row.optDouble("amount", 0)))
                    .append('\n');
        }
        if (history.length() > count) text.append("\nMostrando os 12 lançamentos mais recentes.");
        return text.toString();
    }

    private double totalHistoryAmount() {
        double total = 0;
        for (int i = 0; i < history.length(); i++) {
            JSONObject row = history.optJSONObject(i);
            if (row != null) total += Math.max(0, row.optDouble("amount", 0));
        }
        return total;
    }

    private String percent(double value) {
        return String.format(new Locale("pt", "BR"), "%.2f%%", value);
    }

    private String trimNumber(double value) {
        return String.format(Locale.US, "%.2f", value).replaceAll("\\.?0+$", "").replace('.', ',');
    }

    private String formatInstant(String value) {
        if (value == null || value.trim().isEmpty()) return "aguardando primeira apuração";
        try {
            SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            input.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date date = input.parse(value.trim());
            if (date != null) return new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("pt", "BR")).format(date);
        } catch (Exception ignored) { }
        return value;
    }
}
