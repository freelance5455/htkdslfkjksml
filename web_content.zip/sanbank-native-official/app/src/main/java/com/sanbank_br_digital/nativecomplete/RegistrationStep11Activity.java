package com.sanbank_br_digital.app;

/** Etapa 11 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep11Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 11; }
}
