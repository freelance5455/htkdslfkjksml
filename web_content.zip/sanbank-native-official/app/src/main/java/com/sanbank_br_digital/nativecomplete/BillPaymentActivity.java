package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Pagamento do boleto do Cartão Neo, enviado para aprovação administrativa. */
public final class BillPaymentActivity extends FunctionActivityBase {
    private EditText barcodeInput;
    private EditText amountInput;
    private CheckBox security;
    private TextView status;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Pagar boleto", "Envie o pagamento do boleto do Cartão Neo para aprovação.");
        LinearLayout form = surfaceCard();
        form.addView(text("Linha digitável", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        barcodeInput = functionInput("Digite os números do boleto");
        barcodeInput.setSingleLine(true);
        barcodeInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        form.addView(barcodeInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        form.addView(text("Valor do pagamento", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        amountInput = functionInput("R$ 0,00");
        amountInput.setSingleLine(true);
        amountInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        form.addView(amountInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 7));
        security = new CheckBox(this);
        security.setText("Confirmei beneficiário e valor antes de enviar");
        security.setTextColor(Color.rgb(219, 234, 254));
        form.addView(security, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(46), 0, 9));
        Button send = primaryButton("Enviar para aprovação");
        form.addView(send, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(form, 10);
        status = statusText("O saldo só será alterado após a aprovação administrativa.");
        send.setOnClickListener(v -> submit(send));
        addBackButton();
    }

    private void submit(Button button) {
        String barcode = barcodeInput.getText().toString().replaceAll("\\D", "");
        double amount = decimal(amountInput.getText().toString());
        if (barcode.length() < 44) { barcodeInput.setError("Informe pelo menos 44 números."); return; }
        if (amount <= 0) { amountInput.setError("Informe um valor maior que zero."); return; }
        if (!security.isChecked()) { status.setText("Marque a confirmação de segurança para continuar."); return; }
        button.setEnabled(false);
        status.setText("Registrando pagamento para aprovação...");
        JSONObject payload = new JSONObject();
        try {
            payload.put("id", "BOLETO-" + field(currentUser, "account") + "-" + System.currentTimeMillis());
            payload.put("account", field(currentUser, "account"));
            payload.put("sender_account", field(currentUser, "account"));
            payload.put("amount", Math.round(amount * 100.0) / 100.0);
            payload.put("barcode", barcode);
            payload.put("transaction_type", "PAGAMENTO_BOLETO_CARTAO");
            payload.put("description", "Pagamento de boleto do Cartão Neo");
            payload.put("status", "pending");
            payload.put("created_at", isoNow());
        } catch (Exception ignored) { }
        apiUpsert("pendentes", payload, new RpcCallback() {
            @Override public void success(Object result) { runOnUiThread(() -> { button.setEnabled(true); status.setText("Pagamento registrado e aguardando aprovação administrativa."); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); status.setText(message); }); }
        });
    }
}
