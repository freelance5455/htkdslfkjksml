package com.sanbank_br_digital.app;

/** Etapa 7 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep7Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 7; }
}
