package com.sanbank_br_digital.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONObject;

/** Tela de acesso e porta de entrada da sessão nativa. */
public final class LoginActivity extends NativeBaseActivity {
    private boolean accessCheckInProgress;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (restoreSavedSession()) {
            showLoadingScreen("Carregando os dados", "Sessão salva encontrada. Por favor, aguarde...", 3000L);
            completeLoadingThen(this::openMain);
        } else {
            completeLoadingThen(this::showLogin);
        }
    }

    @Override
    protected void showDashboard() {
        openMain();
    }

    private void openMain() {
        if (currentUser != null) {
            boolean policyAccepted = prefs().getBoolean("privacy_policy_accepted", false);
            String policyVersion = prefs().getString("privacy_policy_version", "");
            if (!policyAccepted || !DevicePrivacyActivity.POLICY_VERSION.equals(policyVersion)) {
                startActivity(new Intent(this, DevicePrivacyActivity.class).putExtra("privacy_after_login", true));
                finish();
                return;
            }
            if (!"admin".equalsIgnoreCase(field(currentUser, "role"))) {
                checkAppAccess();
                return;
            }
        }
        launchMainActivity();
    }

    private void checkAppAccess() {
        if (accessCheckInProgress) return;
        String account = field(currentUser, "account", "");
        long lastSuccess = prefs().getLong("app_access_last_check_ms", 0L);
        String lastAccount = prefs().getString("app_access_last_check_account", "");
        if (!account.isEmpty() && account.equals(lastAccount)
                && System.currentTimeMillis() - lastSuccess >= 0L
                && System.currentTimeMillis() - lastSuccess < 10000L) {
            launchMainActivity();
            return;
        }
        accessCheckInProgress = true;
        JSONObject body = new JSONObject();
        rpc("sanbank_check_my_app_access", body, new RpcCallback() {
            @Override public void success(Object result) {
                runOnUiThread(() -> {
                    accessCheckInProgress = false;
                    JSONObject state = firstObject(result);
                    if (state == null) {
                        showAccessCheckFailure();
                        return;
                    }
                    prefs().edit().putLong("app_access_last_check_ms", System.currentTimeMillis())
                            .putString("app_access_last_check_account", field(currentUser, "account", ""))
                            .apply();
                    if (state.optBoolean("blocked", false)) {
                        Intent blocked = new Intent(LoginActivity.this, AppAccessBlockedActivity.class);
                        blocked.putExtra("block_id", state.optString("block_id", ""));
                        blocked.putExtra("block_reason", state.optString("reason", ""));
                        blocked.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(blocked);
                        finish();
                        return;
                    }
                    launchMainActivity();
                });
            }
            @Override public void failure(String error) {
                runOnUiThread(() -> {
                    accessCheckInProgress = false;
                    showAccessCheckFailure();
                });
            }
        });
    }

    private void showAccessCheckFailure() {
        Toast.makeText(this, "Não foi possível confirmar o acesso ao SANBANK. Entre novamente para tentar.", Toast.LENGTH_LONG).show();
        showLogin();
    }

    private void launchMainActivity() {
        if (currentUser != null) {
            if (prefs().getBoolean("device_registration_revoke_pending", false)) {
                deleteDeviceRegistration(new RpcCallback() {
                    @Override public void success(Object result) { prefs().edit().putBoolean("device_registration_revoke_pending", false).apply(); }
                    @Override public void failure(String message) { }
                });
            } else if ("accepted".equals(prefs().getString("device_privacy_decision", ""))) {
                recordDeviceRegistration(null);
            }
        }
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
