package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Meu perfil: leitura e atualização dos dados básicos sem guardar senha. */
public final class ProfileActivity extends FunctionActivityBase {
    private EditText nameInput;
    private EditText emailInput;
    private EditText phoneInput;
    private EditText addressInput;
    private TextView status;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Meu perfil", "Confira seus dados e atualize o cadastro da conta autenticada.");
        LinearLayout accountCard = surfaceCard();
        accountCard.addView(text("Conta " + field(currentUser, "account", "--"), 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 4));
        accountCard.addView(text("CPF: " + field(currentUser, "cpf", "Não informado"), 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 0));
        addCard(accountCard, 10);

        LinearLayout form = surfaceCard();
        form.addView(text("Dados editáveis", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 8));
        nameInput = editable("Nome completo", field(currentUser, "name", field(currentUser, "nome", "")));
        emailInput = editable("E-mail", field(currentUser, "email", ""));
        phoneInput = editable("Celular", field(currentUser, "phone", field(currentUser, "telefone", "")));
        addressInput = editable("Endereço", field(currentUser, "address", field(currentUser, "endereco", "")));
        form.addView(nameInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 8));
        form.addView(emailInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 8));
        form.addView(phoneInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 8));
        form.addView(addressInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 12));
        Button save = primaryButton("Salvar alterações");
        form.addView(save, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(form, 10);
        status = statusText("Nenhuma alteração pendente.");
        save.setOnClickListener(v -> saveProfile(save));
        addBackButton();
    }

    private EditText editable(String hint, String value) {
        EditText field = functionInput(hint);
        field.setSingleLine(true);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        field.setText(value);
        return field;
    }

    private void saveProfile(Button button) {
        String account = field(currentUser, "account");
        if (account.isEmpty()) return;
        String name = nameInput.getText().toString().trim();
        if (name.length() < 3) { nameInput.setError("Informe seu nome completo."); return; }
        button.setEnabled(false);
        status.setText("Salvando dados do perfil...");
        JSONObject payload = new JSONObject();
        try {
            payload.put("name", name);
            payload.put("email", emailInput.getText().toString().trim());
            payload.put("phone", phoneInput.getText().toString().trim());
            payload.put("address", addressInput.getText().toString().trim());
        } catch (Exception ignored) { }
        accountUpdate(account, payload, new RpcCallback() {
            @Override public void success(Object result) {
                runOnUiThread(() -> {
                    copyJsonValues(currentUser, payload);
                    prefs().edit().putString("session_user_json", currentUser.toString()).apply();
                    button.setEnabled(true);
                    status.setText("Perfil atualizado com sucesso.");
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> { button.setEnabled(true); status.setText(message); });
            }
        });
    }
}
