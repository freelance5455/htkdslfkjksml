package com.sanbank_br_digital.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/** Base das telas de funcionalidade; cada módulo vive em sua própria Activity. */
public abstract class NativeModuleActivity extends NativeBaseActivity {
    protected boolean sessionReady;
    private View functionLoadingOverlay;
    private boolean functionLoadingVisible;
    private long functionLoadingStartedAt;
    private int activeFunctionRequests;
    private final Runnable functionLoadingFinisher = this::maybeFinishFunctionLoading;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        sessionReady = restoreSavedSession();
        if (!sessionReady) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        if (!moduleFeaturesEnabled(getClass())) {
            Toast.makeText(this, "Esta função está desabilitada pelo Administrador.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        onModuleReady();
        // A tela da função já foi montada; o overlay cobre a consulta inicial sem esconder
        // a identificação da função selecionada.
        mainHandler.post(this::showFunctionLoadingOverlay);
    }

    protected abstract void onModuleReady();

    protected void showFunctionLoadingOverlay() {
        if (isFinishing() || root == null || !sessionReady || functionLoadingVisible) return;
        functionLoadingVisible = true;
        functionLoadingStartedAt = System.currentTimeMillis();
        FrameLayout overlay = new FrameLayout(this);
        overlay.setClickable(true);
        overlay.setFocusable(true);
        overlay.setBackgroundColor(Color.argb(188, 3, 14, 27));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(23), dp(22), dp(23), dp(22));
        card.setBackground(rounded(Color.argb(248, 7, 25, 42), Color.argb(125, 45, 212, 191), 26));
        card.setElevation(dp(10));
        ImageView brand = new ImageView(this);
        brand.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int brandIconId = getResources().getIdentifier("ic_sanbank_user_icon", "drawable", getPackageName());
        if (brandIconId != 0) brand.setImageResource(brandIconId);
        brand.setContentDescription("Logo SANBANK BR DIGITAL");
        brand.setBackground(rounded(Color.WHITE, Color.argb(130, 125, 211, 252), 18));
        brand.setPadding(dp(2), dp(2), dp(2), dp(2));
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) brand.setClipToOutline(true);
        card.addView(brand, lp(dp(58), dp(58), 0, 11));
        card.addView(text("SINCRONIZAÇÃO SEGURA", 10, TEAL, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 5));
        TextView selected = text("Selecionado: " + selectedFunctionName(), 20, TEXT, true);
        selected.setGravity(Gravity.CENTER);
        selected.setSingleLine(false);
        card.addView(selected, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        ProgressBar spinner = new ProgressBar(this, null, android.R.attr.progressBarStyleLarge);
        spinner.setIndeterminate(true);
        styleProgressBar(spinner);
        card.addView(spinner, new LinearLayout.LayoutParams(dp(54), dp(54)));
        TextView status = text("Sincronizando dados da sua conta...", 12, MUTED, false);
        status.setGravity(Gravity.CENTER);
        card.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 7));
        TextView note = text("As ações ficam prontas quando as consultas iniciais terminarem.", 11, Color.rgb(191, 219, 254), false);
        note.setGravity(Gravity.CENTER);
        note.setSingleLine(false);
        card.addView(note, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.gravity = Gravity.CENTER;
        cardParams.setMargins(dp(28), dp(28), dp(28), dp(28));
        overlay.addView(card, cardParams);
        functionLoadingOverlay = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        maybeFinishFunctionLoading();
    }

    protected void hideFunctionLoadingOverlay() {
        if (!functionLoadingVisible) return;
        functionLoadingVisible = false;
        mainHandler.removeCallbacks(functionLoadingFinisher);
        if (functionLoadingOverlay != null && root != null) {
            try { root.removeView(functionLoadingOverlay); } catch (Exception ignored) { }
        }
        functionLoadingOverlay = null;
    }

    private void maybeFinishFunctionLoading() {
        if (!functionLoadingVisible) return;
        synchronized (this) {
            if (activeFunctionRequests > 0) return;
        }
        long elapsed = System.currentTimeMillis() - functionLoadingStartedAt;
        long remaining = Math.max(0L, 650L - elapsed);
        if (remaining > 0L) {
            mainHandler.removeCallbacks(functionLoadingFinisher);
            mainHandler.postDelayed(functionLoadingFinisher, remaining);
            return;
        }
        hideFunctionLoadingOverlay();
    }

    private String selectedFunctionName() {
        String name = getClass().getSimpleName();
        if (name.endsWith("Activity")) name = name.substring(0, name.length() - 8);
        if (name.startsWith("StatementEntries")) return "Entradas";
        if (name.startsWith("StatementOutgoing")) return "Saídas";
        if (name.startsWith("StatementFuture")) return "Lançamentos futuros";
        if (name.startsWith("StatementLoans")) return "Empréstimos";
        if (name.startsWith("StatementAutoDebits")) return "Débitos automáticos";
        if (name.startsWith("StatementDiscounts")) return "Descontos";
        if (name.startsWith("Statement")) return "Extrato";
        if (name.startsWith("NeoVirtualCard")) return "Cartão virtual Neo";
        if (name.startsWith("NeoAvailableLimit")) return "Limite disponível Neo";
        if (name.startsWith("NeoLimitSharing")) return "Compartilhar limite";
        if (name.startsWith("NeoTracking")) return "Rastreamento do cartão";
        if (name.startsWith("NeoLimitIncrease")) return "Aumento de limite";
        if (name.startsWith("NeoCardLoss")) return "Perda ou roubo do cartão";
        if (name.startsWith("NeoCardSecurity")) return "Segurança do Cartão Neo";
        if (name.startsWith("NeoInvoice")) return "Fatura do Cartão Neo";
        if (name.startsWith("NeoCard")) return "Cartão Neo Bradesco";
        if (name.startsWith("ErrorReport")) return "Relatar erro do aplicativo";
        if (name.startsWith("DemTransfer")) return "Transferência DEM";
        if (name.startsWith("QrPayment")) return "Pagar QR";
        if (name.startsWith("QrCharge")) return "Cobrar QR";
        if (name.startsWith("Pix")) return "Pix com Cartão Neo";
        if (name.startsWith("Notifications")) return "Notificações";
        if (name.startsWith("Support")) return "Suporte";
        if (name.startsWith("Security")) return "Segurança";
        if (name.startsWith("About")) return "Sobre";
        if (name.startsWith("More")) return "Mais funções";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (i > 0 && Character.isUpperCase(c)) result.append(' ');
            result.append(c);
        }
        return result.toString();
    }

    @Override
    protected void onNetworkRequestStarted() {
        synchronized (this) { activeFunctionRequests++; }
        if (functionLoadingVisible) mainHandler.removeCallbacks(functionLoadingFinisher);
    }

    @Override
    protected void onNetworkRequestFinished() {
        synchronized (this) { if (activeFunctionRequests > 0) activeFunctionRequests--; }
        if (functionLoadingVisible) mainHandler.post(this::maybeFinishFunctionLoading);
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacks(functionLoadingFinisher);
        functionLoadingOverlay = null;
        functionLoadingVisible = false;
        super.onDestroy();
    }

    /** Botões “voltar ao painel” das telas antigas retornam para a Activity anterior. */
    @Override
    protected void showDashboard() {
        finish();
    }
}
