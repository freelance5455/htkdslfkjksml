package com.sanbank_br_digital.app;

/** Etapa 12 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep12Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 12; }
}
