package com.sanbank_br_digital.app;

import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Simulação e solicitação de empréstimo consignado AURA/INSS. */
public final class ConsignedLoanActivity extends FunctionActivityBase {
    private EditText amountInput;
    private EditText monthsInput;
    private TextView status;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Empréstimo consignado", "Simule de 2 a 48 parcelas. A solicitação fica sujeita à análise e aprovação.");
        LinearLayout form = surfaceCard();
        form.addView(text("Valor desejado", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        amountInput = numeric("Ex.: 1000,00", false);
        form.addView(amountInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        form.addView(text("Quantidade de parcelas", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        monthsInput = numeric("Entre 2 e 48", true);
        form.addView(monthsInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        Button simulate = primaryButton("Simular consignado");
        form.addView(simulate, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(form, 10);
        status = statusText("Taxa estimada: 1,84% ao mês. O valor final depende da análise.");
        simulate.setOnClickListener(v -> submit(simulate));
        addBackButton();
    }

    private EditText numeric(String hint, boolean integer) {
        EditText input = functionInput(hint);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | (integer ? 0 : InputType.TYPE_NUMBER_FLAG_DECIMAL));
        return input;
    }

    private void submit(Button button) {
        double amount = decimal(amountInput.getText().toString());
        int months = number(monthsInput.getText().toString());
        if (amount <= 0 || months < 2 || months > 48) { status.setText("Informe um valor válido e entre 2 e 48 parcelas."); return; }
        double rate = 0.0184;
        double payment = amount * rate / (1 - Math.pow(1 + rate, -months));
        button.setEnabled(false);
        status.setText("Enviando solicitação para análise administrativa...");
        JSONObject payload = new JSONObject();
        try {
            payload.put("id", "AURA-CONSIG-" + field(currentUser, "account") + "-" + System.currentTimeMillis());
            payload.put("account", field(currentUser, "account"));
            payload.put("valorSolicitado", amount);
            payload.put("valorParcela", Math.round(payment * 100.0) / 100.0);
            payload.put("parcelas", months);
            payload.put("status", "em_analise");
            payload.put("tipo", "consignado_aura");
            payload.put("date", isoNow());
        } catch (Exception ignored) { }
        apiUpsert("emprestimos", payload, new RpcCallback() {
            @Override public void success(Object result) { runOnUiThread(() -> { button.setEnabled(true); status.setText("Solicitação registrada. Parcela estimada: " + formatMoney(payment) + ". Aguarde a análise."); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); status.setText(message); }); }
        });
    }
}
