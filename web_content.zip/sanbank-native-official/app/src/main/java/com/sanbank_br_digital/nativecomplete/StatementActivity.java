package com.sanbank_br_digital.app;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Extrato nativo com visualização, filtros, resumo e comprovante em PDF. */
public final class StatementActivity extends NativeModuleActivity {
    private TextView statementStatus;
    private ProgressBar statementProgress;
    private LinearLayout statementList;
    private EditText searchInput;
    private Spinner periodSpinner;
    private TextView incomingValue;
    private TextView outgoingValue;
    private TextView netValue;
    private Button customStartButton;
    private Button customEndButton;
    private Button statementRefreshButton;
    private Spinner categorySpinner;
    private Button openCategoryButton;
    private long customStartMillis;
    private long customEndMillis;
    private final List<JSONObject> allRecords = new ArrayList<>();
    private final Handler statementHandler = new Handler(Looper.getMainLooper());
    private boolean statementScreenActive;
    private boolean statementRequestInProgress;
    private String lastStatementSignature;
    private ScrollView statementScroll;
    private final Runnable statementPoller = new Runnable() {
        @Override public void run() {
            if (!statementScreenActive || isFinishing()) return;
            if (!statementRequestInProgress) loadStatement(null, true);
            statementHandler.postDelayed(this, 20000L);
        }
    };

    @Override
    protected void onModuleReady() {
        showStatementHome();
    }

    private void showStatementHome() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        statementScroll = scroll;
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);

        TextView title = text("Extrato da conta", 23, TEXT, true);
        page.addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 3));
        page.addView(text("Visualize, filtre seus lançamentos e gere o documento completo em PDF.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(36), 0, 8));
        TextView legend = text("- saída  ·  + entrada  ·  ? agendamento  ·  $ lançamento futuro INSS/Aura Previdência", 10, Color.rgb(191, 219, 254), false);
        legend.setSingleLine(false);
        legend.setMaxLines(3);
        page.addView(legend, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        LinearLayout balanceCard = new LinearLayout(this);
        balanceCard.setOrientation(LinearLayout.VERTICAL);
        balanceCard.setPadding(dp(16), dp(15), dp(16), dp(15));
        balanceCard.setBackground(gradient(Color.rgb(7, 36, 58), Color.rgb(10, 70, 87), Color.rgb(12, 96, 91), 22));
        balanceCard.addView(text("CONTA " + field(currentUser, "account", "--"), 11, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 3));
        String statementBalanceRaw = field(currentUser, "balance");
        boolean statementBalanceBlocked = isBalanceSecurityBlocked();
        TextView statementBalanceValue = text(statementBalanceBlocked ? "BLOQUEADO" : formatDashboardMoney(decimal(statementBalanceRaw)), 24, statementBalanceBlocked ? signedDisplayColor(statementBalanceRaw, "saldo_bloqueado") : signedDisplayColor(statementBalanceRaw, accountBalanceStatus()), true);
        balanceCard.addView(statementBalanceValue, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(34), 0, 2));
        balanceCard.addView(text(statementBalanceBlocked ? "Saldo disponível bloqueado por segurança" : "Saldo informado no cadastro autenticado", 11, Color.rgb(191, 219, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 0));
        page.addView(balanceCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        LinearLayout filterCard = new LinearLayout(this);
        filterCard.setOrientation(LinearLayout.VERTICAL);
        filterCard.setPadding(dp(14), dp(13), dp(14), dp(13));
        filterCard.setBackground(rounded(Color.argb(238, 8, 27, 45), Color.argb(82, 45, 212, 191), 21));
        filterCard.addView(text("Filtrar extrato", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 8));
        searchInput = textInput("Buscar por descrição, operação ou valor...");
        searchInput.setSingleLine(true);
        searchInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        filterCard.addView(searchInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 8));
        periodSpinner = new Spinner(this);
        periodSpinner.setBackground(rounded(Color.argb(20, 255, 255, 255), Color.argb(70, 125, 211, 252), 13));
        periodSpinner.setPadding(dp(10), 0, dp(10), 0);
        String[] periods = {"Todos os períodos", "Hoje", "Últimos 7 dias", "Últimos 30 dias", "Últimos 90 dias", "Período personalizado"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, periods) {
            @Override public View getView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(Color.rgb(219, 234, 254));
                view.setTextSize(13);
                view.setGravity(Gravity.CENTER_VERTICAL);
                return view;
            }
            @Override public View getDropDownView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                view.setTextColor(Color.rgb(15, 23, 42));
                view.setTextSize(13);
                view.setPadding(dp(12), dp(12), dp(12), dp(12));
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        periodSpinner.setAdapter(adapter);
        filterCard.addView(periodSpinner, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 8));

        LinearLayout datesRow = new LinearLayout(this);
        datesRow.setGravity(Gravity.CENTER_VERTICAL);
        customStartButton = secondaryButton("Data inicial");
        customEndButton = secondaryButton("Data final");
        customStartButton.setTextSize(12);
        customEndButton.setTextSize(12);
        datesRow.addView(customStartButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        datesRow.addView(customEndButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        filterCard.addView(datesRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(46), 0, 0));
        customStartButton.setOnClickListener(v -> pickCustomDate(true));
        customEndButton.setOnClickListener(v -> pickCustomDate(false));
        updateCustomDateLabels();
        page.addView(filterCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        LinearLayout summaryCard = new LinearLayout(this);
        summaryCard.setOrientation(LinearLayout.VERTICAL);
        summaryCard.setPadding(dp(14), dp(13), dp(14), dp(13));
        summaryCard.setBackground(rounded(Color.argb(24, 16, 185, 129), Color.argb(62, 110, 231, 183), 17));
        summaryCard.addView(text("Resumo do período filtrado", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 8));
        LinearLayout summaryRow = new LinearLayout(this);
        summaryRow.setGravity(Gravity.CENTER_VERTICAL);
        incomingValue = summaryMetric(summaryRow, "Entradas", Color.rgb(110, 231, 183));
        outgoingValue = summaryMetric(summaryRow, "Saídas", Color.rgb(253, 164, 175));
        netValue = summaryMetric(summaryRow, "Total líquido", Color.rgb(191, 219, 254));
        summaryCard.addView(summaryRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(58), 0, 3));
        summaryCard.addView(text("Total líquido = entradas − saídas", 10, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 0));
        page.addView(summaryCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        statementStatus = text("Carregando lançamentos...", 12, MUTED, false);
        statementStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        statementStatus.setBackground(rounded(Color.argb(218, 7, 39, 54), Color.argb(82, 45, 212, 191), 16));
        page.addView(statementStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        statementProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleLarge);
        statementProgress.setIndeterminate(true);
        styleProgressBar(statementProgress);
        page.addView(statementProgress, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 5));

        statementList = new LinearLayout(this);
        statementList.setOrientation(LinearLayout.VERTICAL);
        page.addView(statementList, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        Button refresh = secondaryButton("Atualizar visualização");
        statementRefreshButton = refresh;
        page.addView(refresh, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8));
        refresh.setOnClickListener(v -> loadStatement(refresh));

        LinearLayout pdfCard = new LinearLayout(this);
        pdfCard.setOrientation(LinearLayout.VERTICAL);
        pdfCard.setPadding(dp(15), dp(14), dp(15), dp(14));
        pdfCard.setBackground(rounded(Color.argb(228, 8, 27, 45), Color.argb(88, 45, 212, 191), 22));
        pdfCard.addView(text("Documento completo", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 3));
        pdfCard.addView(text("Abra ou compartilhe o extrato em PDF depois da consulta.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 8));
        Button generate = primaryButton("Gerar extrato em PDF");
        pdfCard.addView(generate, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        generate.setOnClickListener(v -> {
            generate.setEnabled(false);
            exportStatementPdf();
            generate.postDelayed(() -> generate.setEnabled(true), 900L);
        });
        page.addView(pdfCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        Button back = secondaryButton("Voltar ao painel");
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        back.setOnClickListener(v -> finish());
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { applyFilters(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        periodSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { applyFilters(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { applyFilters(); }
        });
        scroll.addView(page);
        FrameLayout.LayoutParams scrollParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollParams.bottomMargin = dp(84);
        root.addView(scroll, scrollParams);
        addCategoryBottomMenu();
        loadStatement(refresh);
    }

    private void addCategoryBottomMenu() {
        HorizontalScrollView menuScroll = new HorizontalScrollView(this);
        menuScroll.setHorizontalScrollBarEnabled(false);
        menuScroll.setFillViewport(false);
        menuScroll.setPadding(dp(7), dp(6), dp(7), dp(6));
        menuScroll.setBackground(rounded(Color.argb(244, 8, 20, 39), Color.argb(82, 125, 211, 252), 21));
        menuScroll.setElevation(dp(7));
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.HORIZONTAL);
        String[] labels = {"Entradas", "Saídas", "Futuros", "Empréstimos", "Débitos", "Descontos"};
        String[] icons = {"ic_transfer", "ic_transfer", "ic_update", "ic_card", "ic_receipt", "ic_operations"};
        int[] colors = {Color.rgb(16, 185, 129), Color.rgb(239, 68, 68), Color.rgb(96, 165, 250), Color.rgb(167, 139, 250), Color.rgb(251, 146, 60), Color.rgb(244, 114, 182)};
        for (int i = 0; i < labels.length; i++) {
            final int position = i + 1;
            Button item = actionButton(labels[i]);
            item.setTextSize(10);
            item.setContentDescription("Categoria " + labels[i]);
            applyIcon(item, icons[i], colors[i]);
            item.setOnClickListener(v -> {
                Class<? extends android.app.Activity> target = categoryActivity(position);
                if (target != null) startActivity(new Intent(this, target));
            });
            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(dp(112), dp(68));
            if (i > 0) itemParams.setMargins(dp(6), 0, 0, 0);
            menu.addView(item, itemParams);
        }
        menuScroll.addView(menu, new HorizontalScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        FrameLayout.LayoutParams menuParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(84));
        menuParams.gravity = Gravity.BOTTOM;
        menuParams.setMargins(dp(7), 0, dp(7), dp(7));
        root.addView(menuScroll, menuParams);
    }

    private void addCategorySelector(LinearLayout page) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(13), dp(14), dp(13));
        card.setBackground(rounded(Color.argb(238, 8, 27, 45), Color.argb(82, 45, 212, 191), 21));
        card.addView(text("Categorias do extrato", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 3));
        card.addView(text("Selecione uma categoria para abrir sua Activity própria.", 11, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(23), 0, 8));
        categorySpinner = new Spinner(this);
        categorySpinner.setBackground(rounded(Color.argb(20, 255, 255, 255), Color.argb(70, 125, 211, 252), 13));
        categorySpinner.setPadding(dp(10), 0, dp(10), 0);
        String[] categories = {"Selecionar categoria", "Entradas", "Saídas", "Lançamentos futuros", "Empréstimos", "Débitos automáticos", "Descontos"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(Color.rgb(219, 234, 254));
                view.setTextSize(13);
                view.setGravity(Gravity.CENTER_VERTICAL);
                applyCategoryIcon(view, position, true);
                return view;
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                view.setTextColor(Color.rgb(15, 23, 42));
                view.setTextSize(13);
                view.setPadding(dp(12), dp(12), dp(12), dp(12));
                applyCategoryIcon(view, position, false);
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);
        card.addView(categorySpinner, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        openCategoryButton = primaryButton("Abrir categoria");
        openCategoryButton.setEnabled(false);
        card.addView(openCategoryButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        categorySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { if (openCategoryButton != null) openCategoryButton.setEnabled(position > 0); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { if (openCategoryButton != null) openCategoryButton.setEnabled(false); }
        });
        openCategoryButton.setOnClickListener(v -> {
            Class<? extends android.app.Activity> target = categoryActivity(categorySpinner.getSelectedItemPosition());
            if (target != null) startActivity(new Intent(this, target));
        });
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
    }

    private void applyCategoryIcon(TextView view, int position, boolean selected) {
        if (view == null || position <= 0) {
            if (view != null) view.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
            return;
        }
        String iconName;
        int tint;
        switch (position) {
            case 1: iconName = "ic_transfer"; tint = Color.rgb(16, 185, 129); break;
            case 2: iconName = "ic_transfer"; tint = Color.rgb(239, 68, 68); break;
            case 3: iconName = "ic_update"; tint = Color.rgb(96, 165, 250); break;
            case 4: iconName = "ic_card"; tint = Color.rgb(167, 139, 250); break;
            case 5: iconName = "ic_receipt"; tint = Color.rgb(251, 146, 60); break;
            case 6: iconName = "ic_operations"; tint = Color.rgb(244, 114, 182); break;
            default: iconName = ""; tint = selected ? Color.rgb(219, 234, 254) : Color.rgb(15, 23, 42);
        }
        int drawableId = getResources().getIdentifier(iconName, "drawable", getPackageName());
        if (drawableId == 0) return;
        try {
            Drawable icon = getResources().getDrawable(drawableId).mutate();
            icon.setTint(tint);
            view.setCompoundDrawablesWithIntrinsicBounds(icon, null, null, null);
            view.setCompoundDrawablePadding(dp(8));
        } catch (Exception ignored) { }
    }

    private Class<? extends android.app.Activity> categoryActivity(int position) {
        switch (position) {
            case 1: return StatementEntriesActivity.class;
            case 2: return StatementOutgoingActivity.class;
            case 3: return StatementFutureActivity.class;
            case 4: return StatementLoansActivity.class;
            case 5: return StatementAutoDebitsActivity.class;
            case 6: return StatementDiscountsActivity.class;
            default: return null;
        }
    }

    private TextView summaryMetric(LinearLayout row, String label, int color) {
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        TextView value = text("R$ 0,00", 14, color, true);
        column.addView(value, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 1));
        column.addView(text(label, 10, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(20), 0, 0));
        row.addView(column, new LinearLayout.LayoutParams(0, dp(48), 1));
        return value;
    }

    private void pickCustomDate(boolean startDate) {
        Calendar initial = Calendar.getInstance();
        long selected = startDate ? customStartMillis : customEndMillis;
        if (selected > 0) initial.setTimeInMillis(selected);
        DatePickerDialog picker = new DatePickerDialog(this, (view, year, month, day) -> {
            Calendar chosen = Calendar.getInstance();
            chosen.set(Calendar.YEAR, year);
            chosen.set(Calendar.MONTH, month);
            chosen.set(Calendar.DAY_OF_MONTH, day);
            chosen.set(Calendar.HOUR_OF_DAY, startDate ? 0 : 23);
            chosen.set(Calendar.MINUTE, startDate ? 0 : 59);
            chosen.set(Calendar.SECOND, startDate ? 0 : 59);
            chosen.set(Calendar.MILLISECOND, startDate ? 0 : 999);
            if (startDate) {
                customStartMillis = chosen.getTimeInMillis();
                if (customEndMillis > 0 && customEndMillis < customStartMillis) customEndMillis = customStartMillis + 86399999L;
            } else {
                customEndMillis = chosen.getTimeInMillis();
                if (customStartMillis > 0 && customEndMillis < customStartMillis) {
                    Toast.makeText(this, "A data final precisa ser igual ou posterior à inicial.", Toast.LENGTH_LONG).show();
                    customEndMillis = customStartMillis + 86399999L;
                }
            }
            if (periodSpinner != null && periodSpinner.getSelectedItemPosition() != 5) periodSpinner.setSelection(5);
            updateCustomDateLabels();
            applyFilters();
        }, initial.get(Calendar.YEAR), initial.get(Calendar.MONTH), initial.get(Calendar.DAY_OF_MONTH));
        picker.show();
    }

    private void updateCustomDateLabels() {
        if (customStartButton != null) customStartButton.setText(customStartMillis > 0 ? "Inicial: " + displayDate(customStartMillis) : "Data inicial");
        if (customEndButton != null) customEndButton.setText(customEndMillis > 0 ? "Final: " + displayDate(customEndMillis) : "Data final");
    }

    private String displayDate(long millis) {
        return new SimpleDateFormat("dd/MM/yyyy", new Locale("pt", "BR")).format(new Date(millis));
    }

    private void loadStatement(Button refresh) {
        loadStatement(refresh, false);
    }

    private void loadStatement(Button refresh, boolean automatic) {
        if (statementStatus == null || statementList == null || statementRequestInProgress) return;
        statementRequestInProgress = true;
        if (statementRefreshButton != null) statementRefreshButton.setEnabled(false);
        else if (refresh != null) refresh.setEnabled(false);
        boolean keepVisibleStatement = automatic && !allRecords.isEmpty();
        if (statementProgress != null) statementProgress.setVisibility(keepVisibleStatement ? View.GONE : View.VISIBLE);
        if (!keepVisibleStatement) statementStatus.setText(allRecords.isEmpty() ? "Consultando lançamentos da conta..." : "Atualizando lançamentos da conta...");

        listTab("extrato", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                runOnUiThread(() -> {
                    statementRequestInProgress = false;
                    if (isFinishing() || isDestroyed() || statementStatus == null) return;
                    if (statementProgress != null) statementProgress.setVisibility(View.GONE);
                    String newSignature = statementRecordsSignature(records);
                    boolean changed = lastStatementSignature == null || !lastStatementSignature.equals(newSignature);
                    int previousScroll = statementScroll == null ? 0 : statementScroll.getScrollY();
                    if (changed) {
                        allRecords.clear();
                        for (int i = 0; i < records.length(); i++) {
                            JSONObject record = records.optJSONObject(i);
                            if (record != null) allRecords.add(record);
                        }
                        lastStatementSignature = newSignature;
                        applyFilters();
                        if (statementScroll != null) statementScroll.post(() -> statementScroll.scrollTo(0, previousScroll));
                    }
                    if (statementRefreshButton != null) statementRefreshButton.setEnabled(true);
                    else if (refresh != null) refresh.setEnabled(true);
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> {
                    statementRequestInProgress = false;
                    if (statementProgress != null) statementProgress.setVisibility(View.GONE);
                    if (statementStatus == null || isFinishing() || isDestroyed()) return;
                    if (allRecords.isEmpty()) statementStatus.setText("Não foi possível carregar o extrato agora. Tente atualizar novamente em alguns instantes.");
                    else statementStatus.setText("Não foi possível atualizar. Os lançamentos já carregados continuam exibidos.");
                    if (statementRefreshButton != null) statementRefreshButton.setEnabled(true);
                    else if (refresh != null) refresh.setEnabled(true);
                });
            }
        });
    }

    private String statementRecordsSignature(JSONArray records) {
        List<String> keys = new ArrayList<>();
        if (records != null) {
            for (int i = 0; i < records.length(); i++) {
                JSONObject record = records.optJSONObject(i);
                if (record != null) keys.add(statementRecordSignature(record));
            }
        }
        Collections.sort(keys);
        return keys.toString();
    }

    private String statementRecordSignature(JSONObject record) {
        String id = firstField(record, "id", "transaction_id", "tx_id", "reference", "codigo");
        String marker = firstField(record, "status", "state", "situacao") + "|"
                + firstField(record, "amount", "value", "valor", "net_amount") + "|"
                + firstField(record, "updated_at", "date", "created_at") + "|"
                + firstField(record, "transaction_type", "operation_type", "category", "type") + "|"
                + firstField(record, "title", "name", "transaction_title") + "|"
                + firstField(record, "description", "details", "message");
        return (id.isEmpty() ? record.toString() : id) + "|" + marker;
    }

    private void applyFilters() {
        if (statementStatus == null || statementList == null) return;
        String query = searchInput == null ? "" : searchInput.getText().toString().trim().toLowerCase(Locale.ROOT);
        long start = periodStartMillis();
        long end = periodEndMillis();
        List<JSONObject> filtered = new ArrayList<>();
        double incoming = 0;
        double outgoing = 0;
        for (JSONObject record : allRecords) {
            if (!matchesQuery(record, query)) continue;
            Date date = recordDate(record);
            if (date != null && start > 0 && date.getTime() < start) continue;
            if (date != null && end > 0 && date.getTime() > end) continue;
            filtered.add(record);
            double signed = signedAmount(record);
            if (signed >= 0) incoming += signed;
            else outgoing += Math.abs(signed);
        }
        double net = incoming - outgoing;
        if (incomingValue != null) incomingValue.setText(formatMoney(incoming));
        if (outgoingValue != null) outgoingValue.setText(formatMoney(outgoing));
        if (netValue != null) {
            netValue.setText(formatMoney(net));
            netValue.setTextColor(net >= 0 ? Color.rgb(110, 231, 183) : Color.rgb(253, 164, 175));
        }
        renderStatement(filtered);
    }

    private boolean matchesQuery(JSONObject record, String query) {
        if (query.isEmpty()) return true;
        String searchable = (firstField(record, "title", "transaction_type", "category", "type", "") + " "
                + firstField(record, "description", "details", "detail", "biller", "") + " "
                + firstField(record, "amount", "value", "valor", "") + " "
                + firstField(record, "status", "state", "")).toLowerCase(Locale.ROOT);
        return searchable.contains(query);
    }

    private long periodStartMillis() {
        int position = periodSpinner == null ? 0 : periodSpinner.getSelectedItemPosition();
        if (position <= 0) return 0L;
        if (position == 5) return customStartMillis;
        int days = position == 1 ? 1 : position == 2 ? 7 : position == 3 ? 30 : 90;
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        calendar.add(Calendar.DAY_OF_YEAR, -(days - 1));
        return calendar.getTimeInMillis();
    }

    private long periodEndMillis() {
        int position = periodSpinner == null ? 0 : periodSpinner.getSelectedItemPosition();
        return position == 5 ? customEndMillis : 0L;
    }

    private Date recordDate(JSONObject record) {
        String value = firstField(record, "date", "created_at", "updated_at", "");
        if (value.isEmpty()) return null;
        String[] patterns = {"yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "dd/MM/yyyy", "dd-MM-yyyy"};
        for (String pattern : patterns) {
            try {
                SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
                format.setLenient(false);
                ParsePosition position = new ParsePosition(0);
                Date parsed = format.parse(value, position);
                if (parsed != null && position.getIndex() > 0) return parsed;
            } catch (Exception ignored) { }
        }
        return null;
    }

    private double signedAmount(JSONObject record) {
        return statementSignedAmount(record);
    }

    private void renderStatement(List<JSONObject> records) {
        statementList.removeAllViews();
        if (records == null || records.isEmpty()) {
            statementStatus.setText(allRecords.isEmpty() ? "Nenhum lançamento encontrado para esta conta." : "Nenhum lançamento corresponde aos filtros.");
            TextView empty = text(allRecords.isEmpty() ? "Quando houver operações, elas aparecerão aqui com data, descrição, valor e status." : "Ajuste a busca ou o período para visualizar outros lançamentos.", 13, MUTED, false);
            empty.setPadding(dp(14), dp(16), dp(14), dp(16));
            empty.setBackground(rounded(Color.argb(22, 148, 163, 184), Color.argb(46, 148, 163, 184), 15));
            statementList.addView(empty, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
            return;
        }
        statementStatus.setText(records.size() + " lançamento(s) exibido(s)");
        for (int i = records.size() - 1; i >= 0; i--) {
            statementList.addView(statementCard(records.get(i)), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        }
    }

    private String displayTransactionAmount(JSONObject record) {
        return statementAmountLabel(record);
    }

    private int transactionAmountColor(JSONObject record) {
        return statementAmountColor(record);
    }

    private void addTransactionDetail(LinearLayout panel, String label, String value) {
        String clean = value == null || value.trim().isEmpty() ? "Não informado" : value.trim();
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.TOP);
        TextView labelView = text(label, 10, MUTED, true);
        row.addView(labelView, new LinearLayout.LayoutParams(dp(105), ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView valueView = text(clean, 11, Color.rgb(219, 234, 254), false);
        valueView.setSingleLine(false);
        valueView.setMaxLines(Integer.MAX_VALUE);
        valueView.setHorizontallyScrolling(false);
        valueView.setGravity(Gravity.RIGHT);
        row.addView(valueView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        panel.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6));
    }

    private View statementCard(JSONObject record) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(13), dp(14), dp(13));
        card.setBackground(rounded(Color.argb(28, 15, 42, 74), Color.argb(62, 125, 211, 252), 17));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        String transactionName = firstField(record, "title", "transaction_type", "category", "type");
        if (transactionName.isEmpty()) transactionName = "Operação";
        TextView title = text(transactionName, 15, TEXT, true);
        title.setSingleLine(false);
        title.setMaxLines(Integer.MAX_VALUE);
        title.setHorizontallyScrolling(false);
        title.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        double signed = signedAmount(record);
        TextView amountView = text(displayTransactionAmount(record), 15, transactionAmountColor(record), true);
        amountView.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        amountView.setSingleLine(false);
        amountView.setMaxLines(2);
        top.addView(amountView, new LinearLayout.LayoutParams(dp(132), ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(top);

        String date = firstField(record, "date", "created_at", "updated_at");
        if (date.isEmpty()) date = "Data não informada";
        String description = statementUserDescription(record);
        if (description.isEmpty()) description = "Sem descrição";
        String status = firstField(record, "status", "state");
        if (status.isEmpty()) status = "Situação não informada";
        TextView summaryLabel = text("RESUMO DA MOVIMENTAÇÃO", 10, Color.rgb(125, 211, 252), true);
        card.addView(summaryLabel, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 4, 2));
        TextView summary = text(description, 12, Color.rgb(219, 234, 254), false);
        summary.setSingleLine(false);
        summary.setMaxLines(Integer.MAX_VALUE);
        summary.setHorizontallyScrolling(false);
        summary.setPadding(0, 0, 0, dp(5));
        card.addView(summary, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));

        LinearLayout meta = new LinearLayout(this);
        meta.setGravity(Gravity.CENTER_VERTICAL);
        TextView dateView = text(date, 11, MUTED, false);
        dateView.setSingleLine(false);
        dateView.setMaxLines(Integer.MAX_VALUE);
        dateView.setHorizontallyScrolling(false);
        meta.addView(dateView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView statusView = text(status.isEmpty() ? "registrada" : status, 11, Color.rgb(186, 230, 253), false);
        statusView.setSingleLine(false);
        statusView.setMaxLines(Integer.MAX_VALUE);
        statusView.setHorizontallyScrolling(false);
        statusView.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        statusView.setTextColor(statementStatusColor(record, status));
        statusView.setPadding(dp(7), dp(3), dp(7), dp(3));
        statusView.setBackground(statementStatusBackground(record, status));
        meta.addView(statusView, new LinearLayout.LayoutParams(dp(145), ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(meta);

        LinearLayout detailsPanel = new LinearLayout(this);
        detailsPanel.setOrientation(LinearLayout.VERTICAL);
        detailsPanel.setPadding(dp(12), dp(11), dp(12), dp(11));
        detailsPanel.setBackground(rounded(Color.argb(28, 2, 6, 23), Color.argb(50, 125, 211, 252), 14));
        addTransactionDetail(detailsPanel, "Nome da transação", transactionName);
        addTransactionDetail(detailsPanel, "Valor", displayTransactionAmount(record));
        addTransactionDetail(detailsPanel, "Data e hora", date);
        String transactionType = firstField(record, "transaction_type", "type", "category");
        if (transactionType.isEmpty()) transactionType = "Não informado";
        addTransactionDetail(detailsPanel, "Tipo", transactionType);
        addTransactionDetail(detailsPanel, "Situação", status);
        String account = firstField(record, "account", "sender_account", "source_account");
        if (account.isEmpty()) account = "Não informada";
        addTransactionDetail(detailsPanel, "Conta", account);
        if (!isOverdraftInterestStatementRecord(record)) {
            String recipient = firstField(record, "target_name", "recipient_name", "beneficiary_name", "target_account", "recipient_account");
            if (!recipient.isEmpty()) addTransactionDetail(detailsPanel, "Destinatário", recipient);
        }
        addTransactionDetail(detailsPanel, "Descrição completa", description);
        String identifier = firstField(record, "id", "transaction_id", "operation_id", "pix_record_id");
        if (!identifier.isEmpty()) addTransactionDetail(detailsPanel, "Identificador", identifier);
        detailsPanel.setVisibility(View.GONE);
        card.addView(detailsPanel, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 9));

        Button detailsButton = secondaryButton("Mostrar detalhes");
        detailsButton.setTextSize(12);
        detailsButton.setOnClickListener(v -> {
            boolean visible = detailsPanel.getVisibility() == View.VISIBLE;
            detailsPanel.setVisibility(visible ? View.GONE : View.VISIBLE);
            detailsButton.setText(visible ? "Mostrar detalhes" : "Ocultar detalhes");
        });
        card.addView(detailsButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(44), 0, 0));
        return card;
    }

    @Override protected void onResume() {
        super.onResume();
        statementScreenActive = true;
        statementHandler.removeCallbacks(statementPoller);
        statementHandler.postDelayed(statementPoller, 20000L);
    }

    @Override protected void onPause() {
        statementScreenActive = false;
        statementHandler.removeCallbacks(statementPoller);
        super.onPause();
    }

    @Override protected void onDestroy() {
        statementScreenActive = false;
        statementHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
