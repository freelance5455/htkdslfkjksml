package com.sanbank_br_digital.app;

import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Procura o PAY baixado e abre o instalador oficial do Android. */
public final class PayInstallerActivity extends NativeModuleActivity {
    private TextView status;
    private TextView fileInfo;
    private Button installButton;
    private Uri apkUri;
    private long downloadId = -1L;
    private boolean waitingPermission;
    private boolean autoOpened;

    @Override protected void onModuleReady() {
        showInstallerPage();
        findDownloadedPay();
    }

    private void showInstallerPage() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);
        page.addView(text("Instalar Sanbank Services PAY", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 3));
        page.addView(text("O APK foi baixado. O Android abrirá agora o instalador oficial do aplicativo.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        status = text("Procurando o APK concluído...", 13, MUTED, false);
        status.setPadding(dp(12), dp(11), dp(12), dp(11));
        status.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
        page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        fileInfo = text("Nenhum arquivo localizado ainda.", 12, Color.rgb(219, 234, 254), false);
        page.addView(fileInfo, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        installButton = primaryButton("Abrir instalador do Android");
        installButton.setEnabled(false);
        installButton.setOnClickListener(v -> openInstaller());
        page.addView(installButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        Button retry = secondaryButton("Procurar novamente");
        retry.setOnClickListener(v -> findDownloadedPay());
        page.addView(retry, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        Button back = secondaryButton("Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void findDownloadedPay() {
        status.setText("Procurando o APK baixado...");
        fileInfo.setText("Consultando os downloads concluídos do Android...");
        installButton.setEnabled(false);
        apkUri = null;
        downloadId = getIntent().getLongExtra("download_id", -1L);
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        long found = manager == null ? -1L : findCompleted(manager, downloadId);
        if (found < 0) {
            status.setText("Nenhum APK do PAY foi localizado.");
            fileInfo.setText("Volte para a etapa de download e aguarde 100%.");
            return;
        }
        Uri uri = manager.getUriForDownloadedFile(found);
        if (uri == null) {
            status.setText("O APK foi baixado, mas não está disponível para instalação.");
            return;
        }
        downloadId = found;
        apkUri = uri;
        installButton.setEnabled(true);
        status.setText("Sanbank Services PAY localizado.");
        fileInfo.setText("Download ID: " + found + "\nURI protegida pronta para o instalador do Android.");
        if (!autoOpened) {
            autoOpened = true;
            mainHandler.postDelayed(this::openInstaller, 450L);
        }
    }

    private long findCompleted(DownloadManager manager, long preferred) {
        if (preferred >= 0 && completed(manager, preferred)) return preferred;
        Cursor cursor = manager.query(new DownloadManager.Query());
        if (cursor == null) return -1L;
        long found = -1L;
        long highest = -1L;
        try {
            int idIndex = cursor.getColumnIndex(DownloadManager.COLUMN_ID);
            int statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
            int titleIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TITLE);
            int uriIndex = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI);
            while (cursor.moveToNext()) {
                if (idIndex < 0 || statusIndex < 0 || cursor.getInt(statusIndex) != DownloadManager.STATUS_SUCCESSFUL) continue;
                long id = cursor.getLong(idIndex);
                String title = titleIndex < 0 ? "" : cursor.getString(titleIndex);
                String local = uriIndex < 0 ? "" : cursor.getString(uriIndex);
                boolean isPay = String.valueOf(title).toLowerCase().contains("services pay") || String.valueOf(local).toLowerCase().contains("services-pay");
                if (isPay && id > highest) { highest = id; found = id; }
            }
        } finally { cursor.close(); }
        return found;
    }

    private boolean completed(DownloadManager manager, long id) {
        Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(id));
        if (cursor == null) return false;
        try { return cursor.moveToFirst() && cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL; }
        finally { cursor.close(); }
    }

    private void openInstaller() {
        if (apkUri == null) {
            status.setText("Localize o APK do PAY antes de abrir o instalador.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !getPackageManager().canRequestPackageInstalls()) {
            waitingPermission = true;
            status.setText("Autorize a instalação desta fonte e volte para continuar.");
            try { startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()))); }
            catch (Exception ignored) { }
            return;
        }
        try {
            Intent install = new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(apkUri, "application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(install);
            waitingPermission = false;
        } catch (ActivityNotFoundException error) {
            status.setText("Não foi possível abrir o instalador oficial do Android.");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (waitingPermission && (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || getPackageManager().canRequestPackageInstalls())) {
            waitingPermission = false;
            openInstaller();
        }
    }
}
