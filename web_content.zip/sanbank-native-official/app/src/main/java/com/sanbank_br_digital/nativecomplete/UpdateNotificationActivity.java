package com.sanbank_br_digital.app;

/** Detalhe opcional de atualização; o botão leva à aba de atualizações disponíveis. */
public final class UpdateNotificationActivity extends NotificationDetailActivity { }
