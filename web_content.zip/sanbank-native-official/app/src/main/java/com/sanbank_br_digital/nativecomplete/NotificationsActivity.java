package com.sanbank_br_digital.app;

/** Central de notificações individuais e avisos de operação. */
public final class NotificationsActivity extends NativeModuleActivity {
    @Override
    protected void onModuleReady() {
        showNotificationsScreen();
    }
}
