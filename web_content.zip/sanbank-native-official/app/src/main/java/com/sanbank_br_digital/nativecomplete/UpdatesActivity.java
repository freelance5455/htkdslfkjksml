package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Atualização nativa com DownloadManager e instalador oficial do Android. */
public final class UpdatesActivity extends NativeModuleActivity {
    @Override
    protected void onModuleReady() {
        showUpdateHome();
        if (getIntent() != null && getIntent().getBooleanExtra("open_update_available", false)) {
            mainHandler.postDelayed(() -> checkForUpdate(false), 350L);
        }
    }

    private void showUpdateHome() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);
        page.addView(text("Atualizações do aplicativo", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 3));
        page.addView(text("A versão publicada é consultada no Supabase e o instalador oficial do Android é usado para concluir a atualização.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(rounded(Color.argb(238, 8, 27, 45), Color.argb(92, 45, 212, 191), 22));
        card.addView(text("SANBANK BR DIGITAL", 17, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(30), 0, 5));
        card.addView(text("Versão instalada: " + installedVersion(), 13, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 5));
        card.addView(text("Compatibilidade: Android 5.0/API 21 até Android 17/API 37", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 14));
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));

        TextView status = text("Toque para consultar a versão mais recente.", 12, MUTED, false);
        page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(34), 0, 8));
        Button check = primaryButton("Consultar atualizações");
        page.addView(check, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        Button back = secondaryButton("Voltar ao painel");
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        back.setOnClickListener(v -> finish());
        check.setOnClickListener(v -> {
            check.setEnabled(false);
            status.setText("Consultando versão publicada...");
            checkForUpdate(true);
            check.postDelayed(() -> {
                check.setEnabled(true);
                status.setText("Consulta concluída. Se houver versão nova, aparecerá a confirmação de instalação.");
            }, 900L);
        });
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }
}
