package com.sanbank_br_digital.app;

import android.app.DownloadManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Handler;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

/** Baixa automaticamente o Sanbank Services PAY pelo link publicado no Supabase. */
public final class PayDownloadActivity extends NativeModuleActivity {
    private final Handler handler = new Handler();
    private long downloadId = -1L;
    private boolean started;
    private TextView status;
    private TextView details;
    private ProgressBar progress;

    private final Runnable poller = new Runnable() {
        @Override public void run() {
            updateProgress();
            if (downloadId >= 0 && !isFinished()) handler.postDelayed(this, 700L);
        }
    };

    @Override protected void onModuleReady() {
        showDownloadPage();
        handler.postDelayed(this::startDownload, 250L);
    }

    private void showDownloadPage() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);
        page.addView(text("Instalar Sanbank Services PAY", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 3));
        page.addView(text("O componente de segurança é obrigatório para liberar o SANBANK BR DIGITAL.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        LinearLayout card = surfaceCard();
        card.addView(text("Download automático", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 7));
        status = text("Preparando o download do PAY...", 13, Color.rgb(191, 219, 254), false);
        status.setPadding(dp(12), dp(11), dp(12), dp(11));
        status.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
        card.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        styleProgressBar(progress);
        card.addView(progress, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(9), 0, 9));
        details = text("Aguardando o Android iniciar a transferência...", 11, MUTED, false);
        card.addView(details, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        Button back = secondaryButton("Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void startDownload() {
        if (started) return;
        started = true;
        String url = getIntent().getStringExtra("download_url");
        String version = getIntent().getStringExtra("update_version");
        if (url == null || !url.startsWith("https://")) {
            status.setText("O link do Sanbank Services PAY não está disponível.");
            details.setText("A publicação precisa conter um link HTTPS na aba atualizacao do Supabase.");
            return;
        }
        try {
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(android.net.Uri.parse(url));
            request.setTitle("Sanbank Services PAY " + (version == null ? "" : version));
            request.setDescription("Baixando componente obrigatório de segurança");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.setDestinationInExternalFilesDir(this, android.os.Environment.DIRECTORY_DOWNLOADS, "SANBANK-SERVICES-PAY-" + (version == null || version.isEmpty() ? "latest" : version) + ".apk");
            downloadId = manager.enqueue(request);
            status.setText("Download do PAY iniciado automaticamente...");
            handler.post(poller);
        } catch (Exception error) {
            status.setText("Não foi possível iniciar o download do PAY.");
            details.setText("Verifique a conexão e tente novamente.");
        }
    }

    private boolean isFinished() {
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        Cursor cursor = manager == null || downloadId < 0 ? null : manager.query(new DownloadManager.Query().setFilterById(downloadId));
        if (cursor == null) return true;
        try {
            return cursor.moveToFirst() && (cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL || cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_FAILED);
        } finally { cursor.close(); }
    }

    private void updateProgress() {
        if (downloadId < 0 || status == null) return;
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        Cursor cursor = manager == null ? null : manager.query(new DownloadManager.Query().setFilterById(downloadId));
        if (cursor == null) return;
        try {
            if (!cursor.moveToFirst()) return;
            int state = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            long current = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            if (state == DownloadManager.STATUS_PENDING || state == DownloadManager.STATUS_RUNNING) {
                int percent = total > 0 ? (int) Math.min(100, (current * 100L) / total) : 0;
                progress.setProgress(percent);
                status.setText("Baixando Sanbank Services PAY... " + percent + "%");
                details.setText(total > 0 ? current + " / " + total + " bytes" : "O Android está preparando a transferência...");
            } else if (state == DownloadManager.STATUS_SUCCESSFUL) {
                progress.setProgress(100);
                status.setText("Download concluído em 100%. Procurando o APK...");
                details.setText("A próxima Activity abrirá o instalador oficial do Android.");
                handler.postDelayed(() -> openPayInstaller(), 350L);
            } else if (state == DownloadManager.STATUS_FAILED) {
                status.setText("O download do PAY falhou.");
                details.setText("Volte e tente novamente.");
            }
        } finally { cursor.close(); }
    }

    private void openPayInstaller() {
        if (downloadId < 0) return;
        android.content.Intent intent = new android.content.Intent(this, PayInstallerActivity.class);
        intent.putExtra("download_id", downloadId);
        startActivity(intent);
        finish();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
