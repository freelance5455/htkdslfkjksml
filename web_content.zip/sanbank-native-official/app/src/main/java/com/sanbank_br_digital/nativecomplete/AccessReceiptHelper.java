package com.sanbank_br_digital.app;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Gera comprovantes privados de recuperação de senha e abertura de conta. */
public final class AccessReceiptHelper {
    private AccessReceiptHelper() { }

    public static Uri createPasswordReceipt(Context context, String account, String name, String password, String status, String identifier) {
        String date = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US).format(new Date());
        String[] labels = {"Conta", "Nome do usuário", "Nova senha", "Status", "Data e hora", "Identificador"};
        String[] values = {account, name, password, status, date, identifier};
        return create(context, "Comprovante de alteração de senha", "Alteração concluída com sucesso", "comprovante-senha-" + safe(account) + "-" + System.currentTimeMillis() + ".pdf", labels, values, "Este comprovante contém sua senha nova. Guarde-o em local privado.");
    }

    public static Uri createAccountReceipt(Context context, String account, String name, String email, String phone, String password) {
        String date = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US).format(new Date());
        String[] labels = {"Conta criada", "Titular", "E-mail", "Celular", "Senha", "Data e hora", "Status"};
        String[] values = {account, name, email, phone, password, date, "Conta aberta com sucesso"};
        return create(context, "Comprovante de abertura de conta", "Cadastro concluído com sucesso", "comprovante-conta-" + safe(account) + "-" + System.currentTimeMillis() + ".pdf", labels, values, "Este comprovante contém dados de acesso. Guarde-o em local privado.");
    }

    private static Uri create(Context context, String title, String subtitle, String fileName, String[] labels, String[] values, String warning) {
        if (context == null) return null;
        File folder = new File(context.getCacheDir(), "shared");
        if (!folder.exists() && !folder.mkdirs()) return null;
        File file = new File(folder, fileName);
        android.graphics.pdf.PdfDocument document = new android.graphics.pdf.PdfDocument();
        android.graphics.pdf.PdfDocument.Page page = document.startPage(new android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create());
        Canvas canvas = page.getCanvas();
        canvas.drawColor(Color.rgb(7, 18, 35));
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.rgb(139, 220, 255)); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(12); canvas.drawText("SANBANK BR DIGITAL", 28, 35, paint);
        paint.setColor(Color.WHITE); paint.setTextSize(22); canvas.drawText(title, 28, 78, paint);
        paint.setColor(Color.rgb(110, 231, 183)); paint.setTextSize(12); canvas.drawText(subtitle, 28, 105, paint);
        paint.setColor(Color.rgb(56, 189, 248)); canvas.drawRect(28, 122, 567, 125, paint);
        int y = 160;
        for (int i = 0; i < labels.length; i++) {
            paint.setColor(Color.rgb(159, 197, 232)); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(11); canvas.drawText(labels[i] + ":", 28, y, paint);
            paint.setColor("Nova senha".equals(labels[i]) || "Senha".equals(labels[i]) ? Color.rgb(110, 231, 183) : Color.WHITE); paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(11);
            String value = values != null && i < values.length ? String.valueOf(values[i]) : "—";
            canvas.drawText(shortText(value, 54), 170, y, paint);
            y += 38;
        }
        paint.setColor(Color.rgb(253, 164, 175)); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(9); canvas.drawText("ATENÇÃO: " + shortText(warning, 88), 28, 765, paint);
        paint.setColor(Color.rgb(190, 205, 220)); paint.setTypeface(Typeface.DEFAULT); canvas.drawText("Não compartilhe seus dados de acesso com terceiros.", 28, 790, paint);
        document.finishPage(page);
        try (FileOutputStream output = new FileOutputStream(file)) {
            document.writeTo(output);
            document.close();
            return SanbankFileProvider.uriForFile(context, file, "shared");
        } catch (Exception error) {
            try { document.close(); } catch (Exception ignored) { }
            return null;
        }
    }

    public static void open(Context context, Uri uri) {
        if (context == null || uri == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW); intent.setDataAndType(uri, "application/pdf"); intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(intent);
        } catch (ActivityNotFoundException error) { Toast.makeText(context, "Nenhum aplicativo consegue abrir o PDF neste aparelho.", Toast.LENGTH_LONG).show(); }
    }

    public static void share(Context context, Uri uri, String subject) {
        if (context == null || uri == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_SEND); intent.setType("application/pdf"); intent.putExtra(Intent.EXTRA_STREAM, uri); intent.putExtra(Intent.EXTRA_TEXT, subject); intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(Intent.createChooser(intent, "Compartilhar comprovante PDF"));
        } catch (ActivityNotFoundException error) { Toast.makeText(context, "Nenhum aplicativo disponível para compartilhar o PDF.", Toast.LENGTH_LONG).show(); }
    }

    private static String safe(String value) { return String.valueOf(value == null ? "conta" : value).replaceAll("[^A-Za-z0-9_-]", "-"); }
    private static String shortText(String value, int max) { String clean = String.valueOf(value == null ? "" : value).replaceAll("\\s+", " ").trim(); return clean.length() > max ? clean.substring(0, Math.max(0, max - 1)) + "…" : clean; }
}
