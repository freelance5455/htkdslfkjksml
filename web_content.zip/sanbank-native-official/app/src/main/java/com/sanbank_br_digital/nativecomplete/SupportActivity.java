package com.sanbank_br_digital.app;

/** Atendimento direto com o suporte SANBANK. */
public final class SupportActivity extends NativeModuleActivity {
    @Override
    protected void onModuleReady() {
        openSupportScreen();
    }
}
