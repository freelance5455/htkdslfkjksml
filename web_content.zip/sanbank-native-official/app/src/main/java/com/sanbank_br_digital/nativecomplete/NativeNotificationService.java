package com.sanbank_br_digital.app;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/** Serviço foreground que mantém a sincronização individual ativa em segundo plano. */
public final class NativeNotificationService extends Service {
    public static final int NOTIFICATION_ID = 9801;
    private static final long SYNC_INTERVAL_MS = 60L * 1000L;
    private static final long OTP_POLL_INTERVAL_MS = 10L * 1000L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable syncLoop = new Runnable() {
        @Override public void run() {
            NativeSyncReceiver.syncNow(getApplicationContext());
            handler.postDelayed(this, SYNC_INTERVAL_MS);
        }
    };
    private final Runnable otpLoop = new Runnable() {
        @Override public void run() {
            NativeSyncReceiver.pollNeoOtpNow(getApplicationContext());
            handler.postDelayed(this, OTP_POLL_INTERVAL_MS);
        }
    };

    public static void start(Context context) {
        if (context == null) return;
        Intent intent = new Intent(context, NativeNotificationService.class);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent);
            else context.startService(intent);
        } catch (Exception ignored) { }
    }

    public static void stop(Context context) {
        if (context == null) return;
        try { context.stopService(new Intent(context, NativeNotificationService.class)); } catch (Exception ignored) { }
    }

    @Override public void onCreate() {
        super.onCreate();
        NativeNotificationHelper.createChannels(this);
        startForeground(NOTIFICATION_ID, NativeNotificationHelper.backgroundNotification(this));
        handler.post(syncLoop);
        handler.post(otpLoop);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // START_STICKY permite que o Android recrie o serviço quando a memória for recuperada.
        return START_STICKY;
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
