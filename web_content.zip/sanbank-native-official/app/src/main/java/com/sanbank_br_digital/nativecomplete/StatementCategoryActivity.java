package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Base das Activities independentes das categorias do extrato. */
public abstract class StatementCategoryActivity extends NativeModuleActivity {
    protected TextView categoryStatus;
    protected TextView categorySummary;
    protected LinearLayout categoryList;
    protected LinearLayout loadingPanel;
    protected ProgressBar categoryProgress;
    protected Button refreshButton;
    protected final List<JSONObject> categoryRecords = new ArrayList<>();

    protected abstract String categoryTitle();
    protected abstract String categoryDescription();
    protected abstract String categoryKey();
    protected abstract String categoryIconName();

    @Override
    protected void onModuleReady() {
        showCategoryHome();
        loadCategory();
    }

    private void showCategoryHome() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        ImageView categoryIcon = new ImageView(this);
        int iconId = getResources().getIdentifier(categoryIconName(), "drawable", getPackageName());
        if (iconId != 0) {
            try {
                Drawable icon = getResources().getDrawable(iconId).mutate();
                icon.setTint(Color.rgb(125, 211, 252));
                categoryIcon.setImageDrawable(icon);
            } catch (Exception ignored) { }
        }
        titleRow.addView(categoryIcon, new LinearLayout.LayoutParams(dp(38), dp(38)));
        titleRow.addView(text(categoryTitle(), 23, TEXT, true), new LinearLayout.LayoutParams(0, dp(42), 1));
        page.addView(titleRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(44), 0, 3));
        page.addView(text(categoryDescription(), 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        loadingPanel = surfaceCategoryCard();
        loadingPanel.setGravity(Gravity.CENTER);
        LinearLayout loadingRow = new LinearLayout(this);
        loadingRow.setGravity(Gravity.CENTER_VERTICAL);
        categoryProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleLarge);
        categoryProgress.setIndeterminate(true);
        styleProgressBar(categoryProgress);
        loadingRow.addView(categoryProgress, new LinearLayout.LayoutParams(dp(38), dp(38)));
        TextView loadingText = text("Carregando " + categoryTitle().toLowerCase(Locale.ROOT) + "...", 13, Color.rgb(191, 219, 254), true);
        loadingText.setPadding(dp(12), 0, 0, 0);
        loadingRow.addView(loadingText, new LinearLayout.LayoutParams(0, dp(40), 1));
        loadingPanel.addView(loadingRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(42), 0, 0));
        page.addView(loadingPanel, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        LinearLayout summaryCard = surfaceCategoryCard();
        summaryCard.addView(text("Categoria selecionada", 11, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(21), 0, 3));
        categorySummary = text("Consultando lançamentos...", 18, Color.rgb(125, 211, 252), true);
        summaryCard.addView(categorySummary, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        page.addView(summaryCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        categoryStatus = text("Carregando lançamentos da categoria...", 12, MUTED, false);
        categoryStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        categoryStatus.setBackground(rounded(Color.argb(218, 7, 39, 54), Color.argb(82, 45, 212, 191), 16));
        page.addView(categoryStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));

        categoryList = new LinearLayout(this);
        categoryList.setOrientation(LinearLayout.VERTICAL);
        page.addView(categoryList, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        refreshButton = secondaryButton("Atualizar categoria");
        refreshButton.setOnClickListener(v -> loadCategory());
        page.addView(refreshButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8));
        Button back = secondaryButton("Voltar ao extrato");
        back.setOnClickListener(v -> finish());
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private LinearLayout surfaceCategoryCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setBackground(rounded(Color.argb(238, 8, 27, 45), Color.argb(92, 45, 212, 191), 22));
        card.setElevation(dp(2));
        return card;
    }

    protected void loadCategory() {
        if (refreshButton != null) refreshButton.setEnabled(false);
        if (loadingPanel != null) loadingPanel.setVisibility(View.VISIBLE);
        if (categoryProgress != null) categoryProgress.setVisibility(View.VISIBLE);
        if (categorySummary != null) categorySummary.setText("Selecionado: " + categoryTitle() + "\nCarregando lançamentos...");
        if (categoryStatus != null) categoryStatus.setText("Consultando lançamentos de " + categoryTitle().toLowerCase(Locale.ROOT) + "...");
        if (categoryList != null) categoryList.removeAllViews();
        listTab("extrato", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                List<JSONObject> filtered = new ArrayList<>();
                for (int i = 0; i < records.length(); i++) {
                    JSONObject record = records.optJSONObject(i);
                    if (record != null && belongsToCategory(record)) filtered.add(record);
                }
                runOnUiThread(() -> {
                    if (loadingPanel != null) loadingPanel.setVisibility(View.GONE);
                    if (categoryProgress != null) categoryProgress.setVisibility(View.GONE);
                    categoryRecords.clear();
                    categoryRecords.addAll(filtered);
                    renderCategory();
                    if (refreshButton != null) refreshButton.setEnabled(true);
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> {
                    if (loadingPanel != null) loadingPanel.setVisibility(View.GONE);
                    if (categoryProgress != null) categoryProgress.setVisibility(View.GONE);
                    if (categoryStatus != null) categoryStatus.setText("Não foi possível carregar esta categoria agora.");
                    if (categorySummary != null) categorySummary.setText("Selecionado: " + categoryTitle() + "\nNão foi possível carregar agora.");
                    if (refreshButton != null) refreshButton.setEnabled(true);
                });
            }
        });
    }

    protected boolean belongsToCategory(JSONObject record) {
        String key = categoryKey();
        boolean future = isFutureCategory(record);
        if ("future".equals(key)) return future;
        if ("entries".equals(key)) return !future && statementSignedAmount(record) >= 0;
        if ("outgoing".equals(key)) return !future && statementSignedAmount(record) < 0;
        String marker = statementSearchText(record);
        if ("loans".equals(key)) return marker.matches(".*(empr[eé]stimo|consignad|cr[eé]dito\\s+pessoal|personal[_ ]loan|loan).*" );
        if ("auto_debits".equals(key)) return marker.matches(".*(d[eé]bito\\s+autom[aá]tico|debito_automatico|auto[_ ]debit|automatic[_ ]debit).*" );
        if ("discounts".equals(key)) return marker.matches(".*(desconto|discount|abatimento|rebate).*" );
        return false;
    }

    protected boolean isFutureCategory(JSONObject record) {
        String marker = statementSearchText(record);
        return isFutureBenefitStatementRecord(record) || isScheduledStatementRecord(record)
                || marker.matches(".*(lan[cç]amento\\s+futuro|futur|previst|future|agendad|scheduled|programad).*" )
                || truthy(firstField(record, "future", "is_future", "lancamento_futuro", "future_entry"));
    }

    private void renderCategory() {
        double entries = 0;
        double outgoing = 0;
        for (JSONObject record : categoryRecords) {
            double signed = statementSignedAmount(record);
            if (signed >= 0) entries += signed; else outgoing += Math.abs(signed);
        }
        categorySummary.setText("Selecionado: " + categoryTitle() + "\n" + categoryRecords.size() + " lançamento(s)   ·   Entradas: " + formatMoney(entries) + "   ·   Saídas: " + formatMoney(outgoing));
        categoryList.removeAllViews();
        if (categoryRecords.isEmpty()) {
            categoryStatus.setText("Nenhum lançamento encontrado em " + categoryTitle().toLowerCase(Locale.ROOT) + ".");
            TextView empty = text("Quando houver lançamentos nesta categoria, eles aparecerão aqui.", 13, MUTED, false);
            empty.setPadding(dp(14), dp(16), dp(14), dp(16));
            empty.setBackground(rounded(Color.argb(22, 148, 163, 184), Color.argb(46, 148, 163, 184), 15));
            categoryList.addView(empty, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
            return;
        }
        categoryStatus.setText(categoryRecords.size() + " lançamento(s) exibido(s) nesta categoria.");
        for (int i = categoryRecords.size() - 1; i >= 0; i--) {
            categoryList.addView(categoryCard(categoryRecords.get(i)), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        }
    }

    private View categoryCard(JSONObject record) {
        LinearLayout card = surfaceCategoryCard();
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        String title = firstField(record, "title", "transaction_type", "category", "type", "Operação");
        TextView titleView = text(title, 15, TEXT, true);
        titleView.setSingleLine(false);
        titleView.setMaxLines(Integer.MAX_VALUE);
        top.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView amount = text(statementAmountLabel(record), 15, statementAmountColor(record), true);
        amount.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        amount.setSingleLine(false);
        top.addView(amount, new LinearLayout.LayoutParams(dp(135), ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(top);
        String description = statementUserDescription(record);
        if (description.isEmpty()) description = "Sem descrição";
        card.addView(text(description, 12, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6));
        String status = firstField(record, "status", "state", "Situação não informada");
        String date = firstField(record, "date", "created_at", "updated_at", "Data não informada");
        TextView meta = text(date + "   ·   " + status, 11, statementStatusColor(record, status), false);
        meta.setSingleLine(false);
        card.addView(meta, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        LinearLayout details = surfaceCategoryCard();
        addCategoryDetail(details, "Categoria", categoryTitle());
        addCategoryDetail(details, "Nome da transação", title);
        addCategoryDetail(details, "Valor", statementAmountLabel(record));
        addCategoryDetail(details, "Data e hora", date);
        addCategoryDetail(details, "Situação", status);
        addCategoryDetail(details, "Conta", firstField(record, "account", "sender_account", "source_account", "Não informada"));
        if (!isOverdraftInterestStatementRecord(record)) {
            String target = firstField(record, "target_name", "recipient_name", "beneficiary_name", "target_account", "recipient_account");
            if (!target.isEmpty()) addCategoryDetail(details, "Destinatário", target);
        }
        addCategoryDetail(details, "Descrição completa", description);
        details.setVisibility(View.GONE);
        card.addView(details, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        Button detailsButton = secondaryButton("Mostrar detalhes");
        detailsButton.setTextSize(12);
        detailsButton.setOnClickListener(v -> {
            boolean visible = details.getVisibility() == View.VISIBLE;
            details.setVisibility(visible ? View.GONE : View.VISIBLE);
            detailsButton.setText(visible ? "Mostrar detalhes" : "Ocultar detalhes");
        });
        card.addView(detailsButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(44), 0, 0));
        return card;
    }

    private void addCategoryDetail(LinearLayout panel, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.TOP);
        row.addView(text(label, 10, MUTED, true), new LinearLayout.LayoutParams(dp(105), ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView valueView = text(value == null || value.trim().isEmpty() ? "Não informado" : value, 11, Color.rgb(219, 234, 254), false);
        valueView.setSingleLine(false);
        valueView.setMaxLines(Integer.MAX_VALUE);
        valueView.setGravity(Gravity.RIGHT);
        row.addView(valueView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        panel.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6));
    }
}
