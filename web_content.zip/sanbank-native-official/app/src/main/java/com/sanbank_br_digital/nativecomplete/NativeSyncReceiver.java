package com.sanbank_br_digital.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Sincroniza avisos individuais, operações e atualizações mesmo sem Activity aberta. */
public class NativeSyncReceiver extends BroadcastReceiver {
    private static final String SUPABASE_URL = "https://tvkcjntieqierukjnnjx.supabase.co";
    private static final String PUBLISHABLE_KEY = "sb_publishable_ZI8YSTPyPbA-Jyv99lTZBA_f72vhQui";
    private static final String PREFS = "sanbank_native_preview";
    private static final ExecutorService EXECUTOR = Executors.newCachedThreadPool();
    private static final java.util.concurrent.atomic.AtomicBoolean OTP_POLL_RUNNING = new java.util.concurrent.atomic.AtomicBoolean(false);

    @Override public void onReceive(Context context, Intent intent) {
        Context app = context.getApplicationContext();
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent == null ? "" : intent.getAction())) {
            NativeSyncScheduler.schedule(app);
            if (hasSession(app)) NativeNotificationService.start(app);
            return;
        }
        PendingResult result = goAsync();
        EXECUTOR.execute(() -> {
            try { sync(app); } finally { result.finish(); }
        });
    }

    /** Chamado pelo serviço foreground para fazer uma consulta fora da UI. */
    public static void syncNow(Context context) {
        if (context == null) return;
        Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> new NativeSyncReceiver().sync(app));
    }

    /** Busca tokens Neo apenas durante uma sessão autenticada; o código vem do inbox privado do titular. */
    public static void pollNeoOtpNow(Context context) {
        if (context == null || !OTP_POLL_RUNNING.compareAndSet(false, true)) return;
        Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                android.content.SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                String account = prefs.getString("session_account", "").trim();
                String token = prefs.getString("session_token", "").trim();
                if (account.isEmpty() || token.isEmpty()) return;
                Object result = rpcFunction("sanbank_neo_terminal_inbox", new JSONObject(), token);
                if (!(result instanceof JSONObject)) return;
                JSONObject item = (JSONObject) result;
                if (!item.optBoolean("pending", false)) return;
                String code = field(item, "code");
                String challenge = field(item, "challenge_id");
                if (!code.matches("[0-9]{6}") || challenge.isEmpty()) return;
                String description = field(item, "description", "Compra no Cartão Neo");
                String amount = formatNeoAmount(field(item, "amount", "0"));
                int ttlSeconds = Math.max(1, item.optInt("ttl_seconds", 60));
                NativeNotificationHelper.postNeoOtp(app, code, challenge, description, amount, ttlSeconds);
            } catch (Exception ignored) {
            } finally {
                OTP_POLL_RUNNING.set(false);
            }
        });
    }

    private static String formatNeoAmount(String input) {
        try {
            String raw = String.valueOf(input == null ? "0" : input).replace("R$", "").trim().replaceAll("[^0-9,.-]", "");
            if (raw.contains(",")) raw = raw.replace(".", "").replace(',', '.');
            return NumberFormat.getCurrencyInstance(new Locale("pt", "BR")).format(new BigDecimal(raw));
        } catch (Exception ignored) { return "R$ " + String.valueOf(input == null ? "0" : input); }
    }

    private static boolean hasSession(Context context) {
        android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return !prefs.getString("session_account", "").trim().isEmpty() && !prefs.getString("session_token", "").trim().isEmpty();
    }

    private void sync(Context context) {
        String account = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("session_account", "").trim();
        String token = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("session_token", "").trim();
        if (account.isEmpty() || token.isEmpty()) return;
        try {
            JSONObject filters = new JSONObject(); filters.put("account", account);
            JSONObject payload = new JSONObject(); payload.put("p_source_tab", "notificacoes_usuarios"); payload.put("p_filters", filters);
            Object result = rpc(payload, token);
            if (result instanceof JSONArray) syncUserNotifications(context, account, (JSONArray) result);
            syncPendingTransactions(context, account, token);
            syncExtratoTransactions(context, account, token);
            syncUpdate(context, token);
        } catch (Exception ignored) { }
    }

    private void syncUserNotifications(Context context, String account, JSONArray records) {
        for (int i = 0; i < records.length(); i++) {
            JSONObject item = records.optJSONObject(i);
            if (item == null || !account.equals(field(item, "account"))) continue;
            if (!enabled(field(item, "enabled")) || field(item, "message").isEmpty() || !field(item, "read_at").isEmpty()) continue;
            String id = field(item, "id", "notification-" + i);
            String detail = firstField(item, "details", "detail", "description", "body", "long_message", "message");
            NativeNotificationHelper.post(context,
                    field(item, "title", "Notificação SANBANK"),
                    field(item, "message"),
                    field(item, "type", "informativo"),
                    "user-notification:" + account + ":" + id,
                    detail,
                    field(item, "created_at", "Agora"));
        }
    }

    private void syncPendingTransactions(Context context, String account, String token) {
        try {
            JSONObject filters = new JSONObject(); filters.put("account", account);
            JSONObject payload = new JSONObject(); payload.put("p_source_tab", "pendentes"); payload.put("p_filters", filters);
            Object result = rpc(payload, token);
            if (!(result instanceof JSONArray)) return;
            JSONArray records = (JSONArray) result;
            for (int i = 0; i < records.length(); i++) {
                JSONObject item = records.optJSONObject(i); if (item == null) continue;
                if (!account.equals(firstField(item, "sender_account", "sender", "account"))) continue;
                String id = field(item, "id"); String status = normalizeStatus(field(item, "status", "pending")); if (id.isEmpty()) continue;
                String key = "pending_status_" + id; String previous = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, "");
                if (previous.isEmpty()) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(key, status).apply(); continue; }
                if (!previous.equals(status)) {
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(key, status).apply();
                    String label = statusLabel(status);
                    String title = isDem(item) ? "Transferência DEM enviada" : "Operação atualizada";
                    String type = isDem(item) ? "dem_enviada" : "transacao";
                    String detail = transactionDetail(item, label);
                    NativeNotificationHelper.post(context, title, "A operação " + id + " está " + label + ".", type, "pending-status:" + id + ":" + status, detail, field(item, "updated_at", field(item, "date", "Agora")));
                }
            }
        } catch (Exception ignored) { }
    }

    private void syncExtratoTransactions(Context context, String account, String token) {
        try {
            JSONObject filters = new JSONObject(); filters.put("account", account);
            JSONObject payload = new JSONObject(); payload.put("p_source_tab", "extrato"); payload.put("p_filters", filters);
            Object result = rpc(payload, token);
            if (!(result instanceof JSONArray)) return;
            JSONArray records = (JSONArray) result;
            android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String baselineKey = "transactions_baseline_" + account;
            boolean baseline = prefs.getBoolean(baselineKey, false);
            android.content.SharedPreferences.Editor editor = prefs.edit();
            for (int i = 0; i < records.length(); i++) {
                JSONObject item = records.optJSONObject(i); if (item == null || !relatedToAccount(item, account)) continue;
                String id = firstField(item, "id", "transaction_id", "tx_id", "reference", "codigo");
                if (id.isEmpty()) id = "hash-" + Integer.toHexString(item.toString().hashCode());
                String marker = transactionMarker(item);
                String key = "transaction_marker_" + id;
                String previous = prefs.getString(key, "");
                editor.putString(key, marker);
                // Depois da linha de base, um ID nunca visto é uma transação nova e precisa notificar.
                // Ignorar `previous.isEmpty()` aqui fazia o primeiro crédito DEM recebido passar sem aviso.
                if (!baseline || (!previous.isEmpty() && previous.equals(marker))) continue;
                String category = transactionCategory(item, account);
                String title = titleFor(category, item);
                String amount = firstField(item, "amount", "value", "valor", "net_amount");
                String message = amount.isEmpty() ? title + " registrada." : title + ": " + amount;
                NativeNotificationHelper.post(context, title, message, category, "transaction:" + id + ":" + marker, transactionDetail(item, field(item, "status", "registrada")), field(item, "date", field(item, "created_at", "Agora")));
            }
            editor.putBoolean(baselineKey, true).apply();
        } catch (Exception ignored) { }
    }

    private String transactionCategory(JSONObject item, String account) {
        if (!isDem(item)) return "transacao";
        String sender = firstField(item, "sender_account", "sender", "from_account");
        String target = firstField(item, "target_account", "target", "to_account", "destination_account", "recipient_account");
        if (account.equals(target) && !account.equals(sender)) return "dem_recebida";
        if (account.equals(sender) && !account.equals(target)) return "dem_enviada";

        // Alguns registros legados do extrato só trazem a conta proprietária, type=in,
        // transaction_type=TRANSFER_CREDIT e o título; ainda assim precisam ser recebidos.
        String flow = firstField(item, "direction", "flow", "movement", "type").toLowerCase(Locale.ROOT);
        String transactionType = firstField(item, "transaction_type", "operation_type", "category").toLowerCase(Locale.ROOT);
        String marker = (firstField(item, "title", "name", "transaction_title", "") + " "
                + firstField(item, "description", "details", "message", "")).toLowerCase(Locale.ROOT);
        boolean incoming = flow.equals("in") || flow.equals("incoming") || flow.equals("credit")
                || flow.equals("credito") || flow.equals("crédito") || flow.endsWith("_credit") || flow.endsWith("_in")
                || transactionType.contains("credit") || transactionType.contains("credito") || transactionType.contains("crédito")
                || marker.contains("recebid") || marker.contains("recebimento") || marker.contains("crédito") || marker.contains("credito");
        return incoming ? "dem_recebida" : "dem_enviada";
    }

    private String titleFor(String category, JSONObject item) {
        if ("dem_recebida".equals(category)) return "Transferência DEM recebida";
        if ("dem_enviada".equals(category)) return "Transferência DEM enviada";
        return firstField(item, "title", "name", "transaction_title").isEmpty() ? "Nova transação" : firstField(item, "title", "name", "transaction_title");
    }

    private String transactionDetail(JSONObject item, String status) {
        StringBuilder detail = new StringBuilder();
        String amount = firstField(item, "amount", "value", "valor", "net_amount");
        String date = firstField(item, "date", "created_at", "updated_at");
        String description = firstField(item, "description", "details", "message", "title");
        if (!amount.isEmpty()) detail.append("Valor: ").append(amount).append('\n');
        if (!status.isEmpty()) detail.append("Status: ").append(status).append('\n');
        if (!date.isEmpty()) detail.append("Data: ").append(date).append('\n');
        if (!description.isEmpty()) detail.append("Descrição: ").append(description);
        return detail.length() == 0 ? "Detalhes disponíveis no extrato do SANBANK BR DIGITAL." : detail.toString().trim();
    }

    private String transactionMarker(JSONObject item) {
        return firstField(item, "status", "state", "situacao") + "|"
                + firstField(item, "amount", "value", "valor", "net_amount") + "|"
                + firstField(item, "updated_at", "date", "created_at") + "|"
                + firstField(item, "transaction_type", "operation_type", "category") + "|"
                + firstField(item, "type", "direction", "flow", "movement") + "|"
                + firstField(item, "sender_account", "sender", "from_account") + "|"
                + firstField(item, "target_account", "target", "to_account", "recipient_account") + "|"
                + firstField(item, "title", "name", "transaction_title") + "|"
                + firstField(item, "description", "details", "message");
    }

    private boolean relatedToAccount(JSONObject item, String account) {
        String[] keys = {"account", "account_number", "owner_account", "sender_account", "sender", "from_account", "target_account", "target", "to_account", "destination_account", "recipient_account", "receiver_account"};
        for (String key : keys) if (account.equals(field(item, key))) return true;
        return false;
    }

    private boolean isDem(JSONObject item) {
        String text = (item == null ? "" : item.toString()).toLowerCase(Locale.ROOT);
        return text.contains("dem") || text.contains("transferência_dem") || text.contains("transferencia_dem") || text.contains("transferencia dem");
    }

    private String normalizeStatus(String value) { return String.valueOf(value == null ? "pending" : value).trim().toLowerCase(Locale.US).replace(' ', '_').replace('-', '_'); }
    private String statusLabel(String status) { if (status.contains("complete") || status.contains("conclu") || status.equals("paid")) return "concluída"; if (status.contains("reject") || status.contains("recus") || status.contains("cancel")) return "recusada"; if (status.contains("approv") || status.contains("aprov") || status.contains("process")) return "aprovada / em processamento"; return "pendente"; }

    private void syncUpdate(Context context, String token) throws Exception {
        JSONObject filters = new JSONObject(); JSONObject payload = new JSONObject(); payload.put("p_source_tab", "atualizacao"); payload.put("p_filters", filters);
        Object result = rpc(payload, token);
        if (!(result instanceof JSONArray)) return;
        String installed = "0";
        try { PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0); installed = info.versionName; } catch (Exception ignored) { }
        JSONObject best = null;
        JSONArray records = (JSONArray) result;
        for (int i = 0; i < records.length(); i++) {
            JSONObject item = records.optJSONObject(i); if (item == null) continue;
            String pkg = firstField(item, "package_name", "package", "packageId", "app_package", "android_package");
            String version = firstField(item, "version_name", "version", "app_version", "versao", "versão");
            String url = firstField(item, "download_url", "apk_url", "url", "link");
            if ((!pkg.isEmpty() && !context.getPackageName().equals(pkg)) || version.isEmpty() || !url.startsWith("https://")) continue;
            if (compare(version, installed) > 0 && (best == null || compare(version, field(best, "version")) > 0)) { item.put("version", version); item.put("downloadUrl", url); best = item; }
        }
        if (best != null) {
            String version = field(best, "version");
            String notes = firstField(best, "release_notes", "changelog", "descricao", "notes");
            NativeNotificationHelper.post(context, "Nova atualização disponível", "A versão " + version + " do SANBANK está disponível.", "atualizacao", "app-update:" + version + ":" + field(best, "downloadUrl"), notes.isEmpty() ? "Abra a aba Atualizações disponíveis para consultar o changelog e iniciar a instalação." : notes, field(best, "published_at", field(best, "updated_at", "Agora")));
        }
    }

    private Object rpc(JSONObject payload, String token) throws Exception {
        return rpcFunction("sanbank_api_list", payload, token);
    }

    private static Object rpcFunction(String function, JSONObject payload, String token) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(SUPABASE_URL + "/rest/v1/rpc/" + function).openConnection();
        connection.setRequestMethod("POST"); connection.setConnectTimeout(12000); connection.setReadTimeout(16000); connection.setDoOutput(true);
        connection.setRequestProperty("apikey", PUBLISHABLE_KEY); connection.setRequestProperty("Authorization", "Bearer " + PUBLISHABLE_KEY); connection.setRequestProperty("x-sanbank-session", token); connection.setRequestProperty("Content-Type", "application/json");
        try (OutputStream out = connection.getOutputStream()) { out.write(payload.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = connection.getResponseCode(); String response = read(code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream()); connection.disconnect();
        if (code < 200 || code >= 300) throw new IllegalStateException("sync failed");
        String clean = response == null || response.trim().isEmpty() ? "[]" : response.trim(); return clean.startsWith("[") ? new JSONArray(clean) : new JSONObject(clean);
    }

    private static String read(InputStream stream) throws Exception { if (stream == null) return ""; BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8)); StringBuilder result = new StringBuilder(); String line; while ((line = reader.readLine()) != null) result.append(line); reader.close(); return result.toString(); }
    private static String field(JSONObject item, String key) { return field(item, key, ""); }
    private static String field(JSONObject item, String key, String fallback) { if (item == null) return fallback; Object value = item.opt(key); if (value == null || value == JSONObject.NULL || String.valueOf(value).trim().isEmpty()) { Iterator<String> keys = item.keys(); while (keys.hasNext()) { String candidate = keys.next(); if (candidate.trim().equalsIgnoreCase(key.trim())) { value = item.opt(candidate); break; } } } return value == null || value == JSONObject.NULL ? fallback : String.valueOf(value).trim(); }
    private String firstField(JSONObject item, String... keys) { for (String key : keys) { String value = field(item, key); if (!value.isEmpty()) return value; } return ""; }
    private boolean enabled(String value) { return value.isEmpty() || "true".equalsIgnoreCase(value) || "1".equals(value) || "sim".equalsIgnoreCase(value) || "ativo".equalsIgnoreCase(value); }
    private int compare(String a, String b) { String[] x = String.valueOf(a).replaceAll("[^0-9.]", "").split("\\."); String[] y = String.valueOf(b).replaceAll("[^0-9.]", "").split("\\."); for (int i = 0; i < Math.max(x.length, y.length); i++) { int xi = i < x.length && !x[i].isEmpty() ? Integer.parseInt(x[i]) : 0; int yi = i < y.length && !y[i].isEmpty() ? Integer.parseInt(y[i]) : 0; if (xi != yi) return xi > yi ? 1 : -1; } return 0; }
}
