package com.sanbank_br_digital.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Aceite obrigatório da Política de Privacidade e controles do cadastro do aparelho. */
public final class DevicePrivacyActivity extends FunctionActivityBase {
    private static final int REQUEST_COARSE_LOCATION = 7712;
    static final String POLICY_VERSION = "2026-09-v2";
    private boolean openedAfterLogin;
    private boolean requiresPolicyAcceptance;
    private TextView status;
    private Button acceptButton;
    private Button revokeButton;

    @Override protected void onModuleReady() {
        openedAfterLogin = getIntent() != null && getIntent().getBooleanExtra("privacy_after_login", false);
        requiresPolicyAcceptance = openedAfterLogin;
        buildScreen();
    }

    private void buildScreen() {
        String consent = prefs().getString("device_privacy_decision", "");
        suppressFunctionBack = requiresPolicyAcceptance;
        beginFunctionPage("Política de Privacidade", requiresPolicyAcceptance ? "A aceitação é necessária para acessar o SANBANK BR DIGITAL." : "Consulte ou atualize as permissões de privacidade do aparelho.");

        LinearLayout notice = surfaceCard();
        notice.addView(text("Política de Privacidade — dados do aparelho", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 9));
        notice.addView(text("Finalidade: apoiar a análise de acessos suspeitos e a segurança da conta. Isso é um sinal adicional e não garante que uma fraude seja evitada ou que um aparelho perdido seja localizado.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        notice.addView(text("Ao aceitar esta Política, o SANBANK registrará: modelo e fabricante do aparelho, versão do Android e do aplicativo, um identificador aleatório desta instalação, data e hora do último acesso e o IP público observado pelo servidor. O IP pode mudar ou refletir VPN/proxy; não indica com precisão onde você está.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        notice.addView(text("Localização é opcional: somente será enviada se você também permitir o acesso aproximado nas permissões do Android. Será usada a localização aproximada mais recente disponível enquanto o aplicativo estiver aberto; não há rastreamento contínuo em segundo plano. Sem permissão ou sinal disponível, não será enviada.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        notice.addView(text("O MAC real do aparelho não é coletado. As informações de cadastro do dispositivo ficam visíveis a administradores autorizados do Gerente SANBANK e são mantidas pelo tempo necessário à finalidade de segurança e às obrigações aplicáveis. Para dúvidas ou solicitações, use o Suporte do aplicativo.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        notice.addView(text("A aceitação desta Política de Privacidade é necessária para acessar o SANBANK BR DIGITAL. Depois, você pode revogar o cadastro técnico em Mais funções > Privacidade do aparelho. A localização aproximada continua opcional e pode ser negada nas configurações do Android. Esses dados não recuperam automaticamente dinheiro nem limite não usado do cartão. Em caso de perda/roubo, procure o suporte para bloquear o acesso ou o cartão.", 12, Color.rgb(253, 230, 138), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        addCard(notice, 12);

        status = statusText(requiresPolicyAcceptance
                ? "Leia a política e aceite para continuar. A localização aproximada é opcional."
                : "Nenhum cadastro técnico do aparelho será salvo sem sua autorização.");
        if (!requiresPolicyAcceptance) {
            if ("accepted".equals(consent)) status.setText("Cadastro ativo. O registro é atualizado quando você entra ou abre o aplicativo.");
            else if ("declined".equals(consent) || "revoked".equals(consent)) status.setText("Cadastro desativado. Você pode ativá-lo novamente quando quiser.");
        }

        String acceptLabel = requiresPolicyAcceptance
                ? "Aceito os termos da Política de Privacidade"
                : ("accepted".equals(consent) ? "Atualizar meu cadastro" : "Ativar cadastro do aparelho");
        acceptButton = primaryButton(acceptLabel);
        page.addView(acceptButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 8));
        acceptButton.setOnClickListener(v -> acceptAndRegister());

        revokeButton = secondaryButton("Revogar e remover meu registro");
        revokeButton.setTextColor(Color.rgb(251, 113, 133));
        page.addView(revokeButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8));
        revokeButton.setVisibility(!requiresPolicyAcceptance && "accepted".equals(consent) ? View.VISIBLE : View.GONE);
        revokeButton.setOnClickListener(v -> confirmRevocation());

        if (!requiresPolicyAcceptance) {
            Button back = secondaryButton("Voltar");
            page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 0));
            back.setOnClickListener(v -> finish());
        }
    }

    private void acceptAndRegister() {
        prefs().edit().putBoolean("privacy_policy_accepted", true)
                .putString("privacy_policy_version", POLICY_VERSION)
                .putString("device_privacy_decision", "accepted")
                .putString("device_privacy_version", POLICY_VERSION)
                .putBoolean("device_registration_revoke_pending", false).apply();
        acceptButton.setEnabled(false);
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            status.setText("O acesso à localização aproximada é opcional. Você pode permitir ou negar no próximo aviso do Android.");
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_COARSE_LOCATION);
        } else {
            registerAndContinue();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_COARSE_LOCATION) registerAndContinue();
    }

    private void registerAndContinue() {
        if (status != null) status.setText("Registrando os dados autorizados do aparelho...");
        recordDeviceRegistration(new RpcCallback() {
            @Override public void success(Object result) {
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    acceptButton.setEnabled(true);
                    revokeButton.setVisibility(View.VISIBLE);
                    status.setText("Política aceita. Modelo, Android, versão do app, horário e IP do servidor serão atualizados nos acessos; localização somente se autorizada.");
                    if (openedAfterLogin) continueToMain();
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    acceptButton.setEnabled(true);
                    revokeButton.setVisibility(View.VISIBLE);
                    status.setText("Política aceita neste aparelho, mas o registro técnico não sincronizou. Tentaremos novamente no próximo acesso.");
                    if (openedAfterLogin) continueToMain();
                });
            }
        });
    }

    private void confirmRevocation() {
        new AlertDialog.Builder(this).setTitle("Revogar consentimento?")
                .setMessage("O compartilhamento será desativado e o registro desta instalação será removido do cadastro de dispositivos quando houver conexão. O uso do aplicativo continuará normalmente.")
                .setNegativeButton("Manter consentimento", null)
                .setPositiveButton("Revogar", (dialog, which) -> revokeConsent())
                .show();
    }

    private void revokeConsent() {
        prefs().edit().putString("device_privacy_decision", "revoked")
                .putString("device_privacy_version", POLICY_VERSION)
                .putBoolean("device_registration_revoke_pending", true).apply();
        acceptButton.setEnabled(false);
        revokeButton.setEnabled(false);
        status.setText("Removendo o registro do servidor...");
        deleteDeviceRegistration(new RpcCallback() {
            @Override public void success(Object result) {
                runOnUiThread(() -> {
                    prefs().edit().putBoolean("device_registration_revoke_pending", false).apply();
                    revokeButton.setEnabled(true);
                    revokeButton.setVisibility(View.GONE);
                    acceptButton.setEnabled(true);
                    status.setText("Cadastro revogado e registro removido. O aplicativo continuará funcionando.");
                    if (openedAfterLogin) continueToMain();
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> {
                    revokeButton.setEnabled(true);
                    acceptButton.setEnabled(true);
                    status.setText("Cadastro revogado neste aparelho. A remoção será tentada novamente no próximo acesso à conta.");
                    if (openedAfterLogin) continueToMain();
                });
            }
        });
    }

    private void continueToMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
