package com.sanbank_br_digital.app;

/** Activity da categoria Débitos automáticos do extrato. */
public final class StatementAutoDebitsActivity extends StatementCategoryActivity {
    @Override protected String categoryTitle() { return "Débitos automáticos"; }
    @Override protected String categoryDescription() { return "Veja cobranças e pagamentos programados como débito automático."; }
    @Override protected String categoryKey() { return "auto_debits"; }
    @Override protected String categoryIconName() { return "ic_receipt"; }
}
