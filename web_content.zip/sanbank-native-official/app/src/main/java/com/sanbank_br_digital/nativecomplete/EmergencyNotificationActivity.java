package com.sanbank_br_digital.app;

public final class EmergencyNotificationActivity extends NotificationDetailActivity { }
