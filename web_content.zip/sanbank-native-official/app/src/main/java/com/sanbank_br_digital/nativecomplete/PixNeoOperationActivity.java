package com.sanbank_br_digital.app;

/** Acompanha a aprovação e o débito de um Pix feito com o Cartão Neo Bradesco. */
public final class PixNeoOperationActivity extends OperationStatusActivity {
    @Override protected String operationType() { return "PIX"; }
}
