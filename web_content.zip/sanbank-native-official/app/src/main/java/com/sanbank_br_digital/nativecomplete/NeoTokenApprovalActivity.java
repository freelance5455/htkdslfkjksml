package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.text.InputFilter;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** O titular revisa e confirma no próprio SANBANK; o terminal não recebe o token. */
public final class NeoTokenApprovalActivity extends FunctionActivityBase {
    private String challengeId = "";
    private String description = "";
    private String amount = "";
    private String cardLastFour = "••••";
    private String suppliedCode = "";
    private int ttlSeconds = 60;
    private boolean busy;
    private TextView transactionDetails;
    private TextView status;
    private TextView countdown;
    private EditText codeField;
    private Button approve;
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private long expiresElapsed;
    private final Runnable timer = new Runnable() {
        @Override public void run() {
            if (countdown == null || challengeId.isEmpty()) return;
            long left = Math.max(0, (expiresElapsed - android.os.SystemClock.elapsedRealtime() + 999L) / 1000L);
            countdown.setText("Token expira em " + left + " s");
            if (left <= 0) {
                countdown.setTextColor(Color.rgb(253, 164, 175));
                status.setText("O token expirou. Solicite uma nova autorização na maquininha do Gerente.");
                approve.setEnabled(false);
                return;
            }
            handler.postDelayed(this, 1000L);
        }
    };

    @Override protected void onModuleReady() {
        challengeId = clean(getIntent().getStringExtra("neo_challenge_id"));
        suppliedCode = clean(getIntent().getStringExtra("neo_code"));
        description = clean(getIntent().getStringExtra("neo_description"));
        amount = clean(getIntent().getStringExtra("neo_amount"));
        ttlSeconds = Math.max(1, getIntent().getIntExtra("neo_ttl_seconds", 60));
        beginFunctionPage("Confirmar transação Neo", "Confira o valor e o estabelecimento; só o titular confirma pelo SANBANK BR DIGITAL.");

        LinearLayout card = surfaceCard();
        card.addView(text("SOLICITAÇÃO DE COMPRA", 11, Color.rgb(125, 211, 252), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 7));
        transactionDetails = text("Consultando a operação pendente…", 15, TEXT, true);
        card.addView(transactionDetails, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        if (!suppliedCode.isEmpty()) {
            TextView received = text("Token recebido: " + suppliedCode, 20, Color.rgb(167, 243, 208), true);
            received.setGravity(android.view.Gravity.CENTER);
            received.setPadding(dp(12), dp(13), dp(12), dp(13));
            received.setBackground(rounded(Color.argb(35, 16, 185, 129), Color.argb(100, 110, 231, 183), 16));
            card.addView(received, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 11));
        }
        card.addView(text(suppliedCode.isEmpty() ? "Digite os 6 dígitos recebidos na notificação para confirmar esta compra." : "Token carregado da notificação. Revise o estabelecimento e o valor antes de autorizar.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        codeField = functionInput("Token de 6 dígitos");
        codeField.setSingleLine(true);
        codeField.setInputType(InputType.TYPE_CLASS_NUMBER);
        codeField.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        codeField.setGravity(android.view.Gravity.CENTER);
        codeField.setTextSize(21);
        codeField.setLetterSpacing(0.18f);
        if (!suppliedCode.isEmpty()) codeField.setText(suppliedCode);
        card.addView(codeField, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(56), 0, 8));
        countdown = text("", 12, Color.rgb(253, 230, 138), true);
        countdown.setGravity(android.view.Gravity.CENTER);
        card.addView(countdown, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 0));
        addCard(card, 10);

        status = statusText("O lançamento só será feito após a confirmação do titular.");
        approve = primaryButton("Confirmar compra e validar token");
        approve.setOnClickListener(v -> confirmToken());
        page.addView(approve, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        Button refresh = secondaryButton("Atualizar solicitação pendente");
        refresh.setOnClickListener(v -> loadPending());
        page.addView(refresh, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 9));
        addBackButton();

        loadPending();
        loadCardLastFour();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void loadCardLastFour() {
        listTab("cartoes_neo", field(currentUser, "account"), new ListCallback() {
            @Override public void success(org.json.JSONArray records) {
                JSONObject loaded = normalizeRecord(latestRecord(records));
                String digits = firstField(loaded, "card_number", "numero_cartao", "number").replaceAll("\\D", "");
                String finalFour = digits.length() >= 4 ? digits.substring(digits.length() - 4) : "••••";
                runOnUiThread(() -> {
                    cardLastFour = finalFour;
                    if (!challengeId.isEmpty()) renderChallenge();
                });
            }
            @Override public void failure(String message) { }
        });
    }

    private void loadPending() {
        if (busy) return;
        busy = true;
        JSONObject body = new JSONObject();
        rpc("sanbank_neo_terminal_pending", body, new RpcCallback() {
            @Override public void success(Object result) {
                busy = false;
                JSONObject item = asObject(result);
                if (item == null || !item.optBoolean("pending", false)) {
                    challengeId = "";
                    transactionDetails.setText("Nenhuma compra está aguardando sua confirmação.");
                    status.setText("Quando o Gerente iniciar uma compra, você receberá uma notificação privada com o token.");
                    approve.setEnabled(false);
                    countdown.setText("");
                    return;
                }
                String notifiedChallenge = challengeId;
                challengeId = item.optString("challenge_id", "");
                if (!notifiedChallenge.isEmpty() && !notifiedChallenge.equals(challengeId)) suppliedCode = "";
                amount = item.optString("amount", "");
                description = item.optString("description", "Compra no Cartão Neo");
                ttlSeconds = Math.max(1, item.optInt("ttl_seconds", 60));
                renderChallenge();
            }
            @Override public void failure(String message) {
                busy = false;
                transactionDetails.setText("Não foi possível consultar a solicitação.");
                status.setText("Confira sua conexão e atualize novamente.");
            }
        });
    }

    private void renderChallenge() {
        if (challengeId.isEmpty()) {
            transactionDetails.setText("Nenhuma solicitação encontrada.");
            approve.setEnabled(false);
            return;
        }
        transactionDetails.setText("Cartão: Neo Bradesco · final " + cardLastFour + "\nEstabelecimento: " + (description.isEmpty() ? "não informado" : description)
                + "\nValor da compra: " + formatMoney(decimal(amount)) + "\n\nLançamento interno do SANBANK; não é autorização externa Visa.");
        status.setText("Confira os dados antes de confirmar. O token é válido por 1 minuto.");
        approve.setEnabled(true);
        expiresElapsed = android.os.SystemClock.elapsedRealtime() + ttlSeconds * 1000L;
        handler.removeCallbacks(timer);
        handler.post(timer);
    }

    private void confirmToken() {
        if (busy || challengeId.isEmpty()) return;
        String code = codeField.getText() == null ? "" : codeField.getText().toString().trim();
        if (!code.matches("[0-9]{6}")) {
            codeField.setError("Digite os 6 dígitos recebidos.");
            codeField.requestFocus();
            return;
        }
        if (android.os.SystemClock.elapsedRealtime() >= expiresElapsed) {
            status.setText("Token expirado. Peça ao Gerente para iniciar uma nova solicitação.");
            approve.setEnabled(false);
            return;
        }
        busy = true;
        approve.setEnabled(false);
        status.setText("Validando token no servidor seguro…");
        JSONObject body = new JSONObject();
        try { body.put("p_challenge_id", challengeId); body.put("p_code", code); } catch (Exception ignored) { }
        rpc("sanbank_neo_terminal_confirm", body, new RpcCallback() {
            @Override public void success(Object result) {
                busy = false;
                JSONObject item = asObject(result);
                if (item == null || !item.optBoolean("ok", false)) {
                    String reason = item == null ? "" : item.optString("code", "");
                    if ("TOKEN_INVALID".equals(reason)) {
                        int left = item.optInt("attempts_left", 0);
                        status.setText("Token incorreto. Tentativas restantes: " + left + ".");
                        approve.setEnabled(left > 0 && android.os.SystemClock.elapsedRealtime() < expiresElapsed);
                    } else {
                        status.setText("TOKEN_EXPIRED".equals(reason) ? "Token expirado; solicite uma nova operação." : "A operação foi recusada. Atualize o status ou fale com o Gerente.");
                        approve.setEnabled(false);
                    }
                    return;
                }
                handler.removeCallbacks(timer);
                countdown.setText("Token validado ✓");
                countdown.setTextColor(Color.rgb(167, 243, 208));
                codeField.setEnabled(false);
                status.setText("Compra interna aprovada. Fatura, limite e extrato foram atualizados.");
                transactionDetails.setText("Compra concluída\nCartão Neo Bradesco · final " + cardLastFour + "\nEstabelecimento: " + description
                        + "\nValor: " + formatMoney(decimal(item.optString("amount", amount)))
                        + "\nFatura atualizada: " + formatMoney(decimal(item.optString("invoice_amount", "0")))
                        + "\nLimite disponível: " + formatMoney(decimal(item.optString("limit_available", "0")))
                        + "\nIdentificador: " + item.optString("transaction_id", "")
                        + "\n\nLedger interno SANBANK; nenhuma autorização externa Visa.");
                approve.setText("Compra confirmada");
                approve.setEnabled(false);
            }
            @Override public void failure(String message) {
                busy = false;
                status.setText("Não foi possível validar agora. Tente novamente antes do vencimento do token.");
                approve.setEnabled(true);
            }
        });
    }

    private JSONObject asObject(Object value) {
        if (value instanceof JSONObject) return (JSONObject) value;
        if (value instanceof org.json.JSONArray && ((org.json.JSONArray) value).length() > 0) return ((org.json.JSONArray) value).optJSONObject(0);
        return null;
    }

    private String clean(String value) { return value == null ? "" : value.trim(); }
}
