package com.sanbank_br_digital.app;

/** Etapa 3 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep3Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 3; }
}
