package com.sanbank_br_digital.app;

/** Cartão Neo Bradesco: cartão virtual, limite, bloqueio e rastreamento. */
public final class NeoCardActivity extends NativeModuleActivity {
    @Override
    protected void onModuleReady() {
        openNeoCardScreen();
    }
}
