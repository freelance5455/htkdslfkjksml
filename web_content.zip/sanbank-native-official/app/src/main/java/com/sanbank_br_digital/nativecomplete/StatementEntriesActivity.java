package com.sanbank_br_digital.app;

/** Activity da categoria Entradas do extrato. */
public final class StatementEntriesActivity extends StatementCategoryActivity {
    @Override protected String categoryTitle() { return "Entradas"; }
    @Override protected String categoryDescription() { return "Veja os créditos e valores recebidos na conta."; }
    @Override protected String categoryKey() { return "entries"; }
    @Override protected String categoryIconName() { return "ic_transfer"; }
}
