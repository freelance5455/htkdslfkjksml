package com.sanbank_br_digital.app;

import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Terceira etapa: procura o APK baixado e abre o instalador oficial do Android. */
public final class UpdateInstallerActivity extends NativeModuleActivity {
    private TextView status;
    private TextView fileInfo;
    private Button installButton;
    private Uri apkUri;
    private long apkDownloadId = -1L;
    private boolean waitingPermission;
    private boolean autoOpen = true;

    @Override
    protected void onModuleReady() {
        showInstallerScreen();
        findDownloadedApk();
    }

    private void showInstallerScreen() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);
        page.addView(text("Localizar e instalar atualização", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 3));
        page.addView(text("A Activity procura o APK concluído pelo DownloadManager e abre o instalador oficial, sem instalação silenciosa.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        status = text("Procurando o aplicativo baixado...", 12, MUTED, false);
        status.setPadding(dp(12), dp(11), dp(12), dp(11));
        status.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
        page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        fileInfo = text("Nenhum APK localizado ainda.", 13, Color.rgb(219, 234, 254), false);
        fileInfo.setPadding(dp(12), dp(12), dp(12), dp(12));
        fileInfo.setBackground(rounded(Color.argb(24, 255, 255, 255), Color.argb(55, 148, 163, 184), 14));
        page.addView(fileInfo, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        installButton = primaryButton("Abrir instalador do Android");
        installButton.setEnabled(false);
        installButton.setOnClickListener(v -> openInstaller());
        page.addView(installButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        Button search = secondaryButton("Procurar novamente");
        search.setOnClickListener(v -> findDownloadedApk());
        page.addView(search, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        Button back = secondaryButton("Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void findDownloadedApk() {
        status.setText("Procurando o APK baixado...");
        fileInfo.setText("Consultando os downloads concluídos do Android...");
        installButton.setEnabled(false);
        apkUri = null;
        long preferred = getIntent().getLongExtra("download_id", -1L);
        if (preferred < 0) preferred = pendingDownloadId;
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (manager == null) {
            status.setText("O gerenciador de downloads do Android não está disponível.");
            return;
        }
        long foundId = findSuccessfulDownload(manager, preferred);
        if (foundId < 0) {
            status.setText("Nenhum APK concluído foi localizado.");
            fileInfo.setText("Volte para a etapa de download e aguarde a conclusão.");
            return;
        }
        Uri foundUri = manager.getUriForDownloadedFile(foundId);
        if (foundUri == null) {
            status.setText("O APK foi encontrado, mas a URI de instalação não está disponível.");
            return;
        }
        apkDownloadId = foundId;
        apkUri = foundUri;
        installButton.setEnabled(true);
        status.setText("APK localizado. Preparando o instalador oficial...");
        fileInfo.setText("Download ID: " + foundId + "\nURI protegida do Android pronta para instalação.");
        if (autoOpen) {
            autoOpen = false;
            mainHandler.postDelayed(this::openInstaller, 500L);
        }
    }

    private long findSuccessfulDownload(DownloadManager manager, long preferred) {
        if (preferred >= 0 && isSuccessful(manager, preferred)) return preferred;
        Cursor cursor = manager.query(new DownloadManager.Query());
        if (cursor == null) return -1L;
        long found = -1L;
        long highest = -1L;
        try {
            int idIndex = cursor.getColumnIndex(DownloadManager.COLUMN_ID);
            int statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
            int titleIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TITLE);
            int uriIndex = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI);
            while (cursor.moveToNext()) {
                if (idIndex < 0 || statusIndex < 0) continue;
                long id = cursor.getLong(idIndex);
                if (cursor.getInt(statusIndex) != DownloadManager.STATUS_SUCCESSFUL) continue;
                String title = titleIndex >= 0 ? cursor.getString(titleIndex) : "";
                String localUri = uriIndex >= 0 ? cursor.getString(uriIndex) : "";
                boolean apk = String.valueOf(title).toLowerCase().contains("sanbank") || String.valueOf(localUri).toLowerCase().endsWith(".apk");
                if (apk && id > highest) { highest = id; found = id; }
            }
        } finally { cursor.close(); }
        return found;
    }

    private boolean isSuccessful(DownloadManager manager, long id) {
        Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(id));
        if (cursor == null) return false;
        try {
            return cursor.moveToFirst() && cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL;
        } finally { cursor.close(); }
    }

    private void openInstaller() {
        if (apkUri == null) {
            status.setText("Localize um APK baixado antes de abrir o instalador.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !getPackageManager().canRequestPackageInstalls()) {
            waitingPermission = true;
            status.setText("Autorize a instalação de aplicativos desta fonte e volte para continuar.");
            try { startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()))); }
            catch (Exception ignored) { }
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            waitingPermission = false;
            clearPendingDownload();
        } catch (ActivityNotFoundException error) {
            status.setText("Não foi possível abrir o instalador oficial neste aparelho.");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (waitingPermission && (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || getPackageManager().canRequestPackageInstalls())) {
            waitingPermission = false;
            if (apkUri != null) openInstaller();
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        autoOpen = true;
        findDownloadedApk();
    }
}
