package com.sanbank_br_digital.app;

/** Etapa 2 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep2Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 2; }
}
