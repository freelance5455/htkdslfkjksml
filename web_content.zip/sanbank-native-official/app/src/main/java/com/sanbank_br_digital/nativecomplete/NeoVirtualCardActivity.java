package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Activity exclusiva do Cartão virtual Neo. */
public final class NeoVirtualCardActivity extends NeoCardFunctionActivity {
    @Override
    protected void onModuleReady() {
        beginNeoFunction("Cartão virtual Neo", "Consulte o número do cartão virtual em uma tela independente.");
        NeoCardFaceView cardFace = new NeoCardFaceView(this);
        cardFace.setCardData(field(currentUser, "name", "Cliente"), "VISA", "", "CARREGANDO", false);
        page.addView(cardFace, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        LinearLayout cardView = surfaceCard();
        TextView details = text("Carregando dados do cartão...", 12, Color.rgb(191, 219, 254), false);
        cardView.addView(details, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        Button reveal = primaryButton("Mostrar número completo");
        reveal.setEnabled(false);
        cardView.addView(reveal, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        addCard(cardView, 10);
        addBackButton();
        loadNeoCard(value -> {
            final String raw = field(value, "card_number").trim();
            final boolean blocked = neoBlocked(value);
            final String holder = field(value, "card_holder", field(currentUser, "name", "Cliente"));
            final String cardBrand = field(value, "brand", field(value, "card_brand", "VISA"));
            cardFace.setCardData(holder, cardBrand, raw, neoStatusText(value), blocked);
            details.setText("Titular: " + holder + "\nBandeira: " + cardBrand + "\nStatus: " + neoStatusText(value));
            reveal.setEnabled(!blocked && !raw.isEmpty());
            final boolean[] visible = {false};
            reveal.setOnClickListener(v -> {
                visible[0] = !visible[0];
                cardFace.setNumberVisible(visible[0]);
                reveal.setText(visible[0] ? "Ocultar número" : "Mostrar número completo");
            });
            if (blocked) cardStatus.setText("O cartão virtual está indisponível enquanto o cartão estiver bloqueado.");
        });
    }
}
