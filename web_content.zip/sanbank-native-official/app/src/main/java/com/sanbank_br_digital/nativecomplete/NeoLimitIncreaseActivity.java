package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.Locale;

/** Activity exclusiva para solicitar e registrar aumento de limite do Cartão Neo. */
public final class NeoLimitIncreaseActivity extends NeoCardFunctionActivity {
    private EditText requestedLimit;
    private TextView operationStatus;
    private Button submitButton;

    @Override
    protected void onModuleReady() {
        beginNeoFunction("Aumento de limite", "Solicite um novo limite total para o Cartão Neo em uma etapa independente.");
        LinearLayout form = surfaceCard();
        form.addView(text("Limite atual", 12, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 3));
        TextView current = text("Carregando...", 23, Color.rgb(125, 211, 252), true);
        form.addView(current, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(35), 0, 12));
        form.addView(text("Novo limite total desejado", 13, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 5));
        requestedLimit = functionInput("Ex.: 8.000,00");
        requestedLimit.setSingleLine(true);
        requestedLimit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        form.addView(requestedLimit, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 10));
        operationStatus = text("Carregando dados do cartão...", 12, MUTED, false);
        operationStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        operationStatus.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
        form.addView(operationStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        submitButton = primaryButton("Solicitar aumento");
        submitButton.setEnabled(false);
        form.addView(submitButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(form, 10);
        addBackButton();
        loadNeoCard(value -> {
            double currentLimit = neoTotal(value);
            current.setText(formatMoney(currentLimit));
            requestedLimit.setHint("Maior que " + formatMoney(currentLimit));
            submitButton.setEnabled(!neoBlocked(value));
            operationStatus.setText(neoBlocked(value) ? "O aumento está indisponível enquanto o cartão estiver bloqueado." : "Informe um valor maior que o limite atual.");
            submitButton.setOnClickListener(v -> submit(value, currentLimit));
        });
    }

    private void submit(JSONObject value, double currentLimit) {
        if (neoBlocked(value)) {
            operationStatus.setText("O Cartão Neo está bloqueado e não pode receber aumento de limite.");
            return;
        }
        double requested = decimal(requestedLimit.getText().toString());
        if (requested <= currentLimit) {
            requestedLimit.setError("Informe um valor maior que " + formatMoney(currentLimit));
            return;
        }
        submitButton.setEnabled(false);
        submitButton.setText("Enviando para aprovação...");
        operationStatus.setText("Registrando a solicitação para análise do gerente...");
        JSONObject payload = new JSONObject();
        JSONObject operationData = new JSONObject();
        try {
            String account = field(currentUser, "account");
            String operationId = "AUMENTO-LIMITE-" + account + "-" + System.currentTimeMillis();
            payload.put("id", operationId);
            payload.put("account", account);
            payload.put("sender_account", account);
            payload.put("sender", account);
            payload.put("amount", String.format(Locale.US, "%.2f", requested));
            payload.put("title", "Aumento de limite do Cartão Neo");
            payload.put("description", "Solicitação de aumento do limite do Cartão Neo — aprovação obrigatória do gerente administrativo.");
            payload.put("transaction_type", "LIMIT_INCREASE");
            payload.put("type", "LIMIT_INCREASE");
            payload.put("status", "pending");
            payload.put("approval_required", true);
            payload.put("created_at", isoNow());
            payload.put("requested_limit", String.format(Locale.US, "%.2f", requested));
            payload.put("current_limit", String.format(Locale.US, "%.2f", currentLimit));
            payload.put("limit_increase_status", "pending_approval");
            operationData.put("operation", "LIMIT_INCREASE");
            operationData.put("current_limit", currentLimit);
            operationData.put("requested_limit", requested);
            operationData.put("card_account", account);
            operationData.put("card_last_four", neoLastFour(value));
            operationData.put("approval_rule", "gerente_administrativo");
            payload.put("operation_data", operationData.toString());
        } catch (Exception ignored) { }
        apiUpsert("pendentes", payload, new RpcCallback() {
            @Override public void success(Object result) {
                trackPendingTransaction(payload);
                runOnUiThread(() -> {
                    submitButton.setText("Aguardando aprovação");
                    operationStatus.setText("Solicitação enviada ao gerente. O novo limite só será aplicado após a aprovação administrativa.");
                    Toast.makeText(NeoLimitIncreaseActivity.this, "Solicitação enviada para aprovação do gerente.", Toast.LENGTH_LONG).show();
                    openOperationStatusActivity(LimitIncreaseOperationActivity.class, payload, operationData);
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> { submitButton.setEnabled(true); submitButton.setText("Solicitar aumento"); operationStatus.setText(message); });
            }
        });
    }
}
