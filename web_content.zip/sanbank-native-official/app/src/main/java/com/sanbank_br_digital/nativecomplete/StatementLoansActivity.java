package com.sanbank_br_digital.app;

/** Activity da categoria Empréstimos do extrato. */
public final class StatementLoansActivity extends StatementCategoryActivity {
    @Override protected String categoryTitle() { return "Empréstimos"; }
    @Override protected String categoryDescription() { return "Veja lançamentos relacionados a empréstimos, crédito pessoal e consignado."; }
    @Override protected String categoryKey() { return "loans"; }
    @Override protected String categoryIconName() { return "ic_card"; }
}
