package com.sanbank_br_digital.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Tela detalhada compartilhada pelas Activities de cada categoria de notificação. */
public class NotificationDetailActivity extends Activity {
    protected int blue = Color.rgb(14, 165, 233);
    protected int text = Color.rgb(241, 248, 255);
    protected int muted = Color.rgb(174, 202, 226);

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(4, 20, 34));
        getWindow().setNavigationBarColor(Color.rgb(3, 14, 27));
        render();
    }

    protected String categoryKey() { return clean(getIntent().getStringExtra("notification_type"), "informativo"); }

    protected void render() {
        String type = categoryKey();
        String title = clean(getIntent().getStringExtra("notification_title"), "Notificação SANBANK");
        String message = clean(getIntent().getStringExtra("notification_message"), "Você recebeu uma nova notificação.");
        String detail = clean(getIntent().getStringExtra("notification_detail"), message);
        String created = clean(getIntent().getStringExtra("notification_created_at"), "Agora");
        String eventId = clean(getIntent().getStringExtra("notification_event_id"), "Não informado");

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(18), dp(16), dp(28));
        page.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27)));

        TextView top = label("SANBANK BR DIGITAL", 12, Color.rgb(191, 219, 254), true);
        top.setGravity(Gravity.CENTER);
        top.setPadding(0, 0, 0, dp(14));
        page.addView(top, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 0));

        FrameLayout iconBadge = new FrameLayout(this);
        GradientDrawable iconBackground = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{accentFor(type), darken(accentFor(type)), Color.rgb(8, 80, 104)});
        iconBackground.setCornerRadius(dp(36));
        iconBackground.setStroke(dp(1), Color.argb(120, 220, 246, 255));
        iconBadge.setBackground(iconBackground);
        iconBadge.setElevation(dp(5));
        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int iconId = getResources().getIdentifier(iconDrawableFor(type), "drawable", getPackageName());
        if (iconId != 0) {
            Drawable glyph = getResources().getDrawable(iconId).mutate();
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) glyph.setTint(Color.WHITE);
            icon.setImageDrawable(glyph);
        }
        FrameLayout.LayoutParams iconParams = new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER);
        iconBadge.addView(icon, iconParams);
        LinearLayout iconRow = new LinearLayout(this); iconRow.setGravity(Gravity.CENTER);
        iconRow.addView(iconBadge, new LinearLayout.LayoutParams(dp(72), dp(72)));
        page.addView(iconRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(82), 0, 13));

        TextView category = label(categoryLabel(type), 11, Color.WHITE, true);
        category.setGravity(Gravity.CENTER);
        category.setPadding(dp(13), dp(8), dp(13), dp(8));
        category.setBackground(rounded(Color.argb(42, Color.red(accentFor(type)), Color.green(accentFor(type)), Color.blue(accentFor(type))), Color.argb(105, Color.red(accentFor(type)), Color.green(accentFor(type)), Color.blue(accentFor(type))), 30));
        page.addView(category, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));

        TextView heading = label(title, 24, text, true);
        heading.setGravity(Gravity.CENTER);
        heading.setLineSpacing(dp(2), 1.05f);
        page.addView(heading, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 9));
        TextView time = label(created, 12, muted, false);
        time.setGravity(Gravity.CENTER);
        page.addView(time, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 16));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(rounded(Color.argb(238, 8, 27, 45), Color.argb(92, 45, 212, 191), 23));
        TextView summaryTitle = label("Detalhes da notificação", 16, text, true);
        card.addView(summaryTitle, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(29), 0, 9));
        TextView body = label(message, 15, Color.rgb(226, 238, 252), false);
        body.setLineSpacing(dp(3), 1.12f);
        card.addView(body, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        TextView expanded = label(detail, 13, muted, false);
        expanded.setLineSpacing(dp(2), 1.08f);
        expanded.setPadding(dp(12), dp(11), dp(12), dp(11));
        expanded.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 15));
        card.addView(expanded, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 11));
        TextView id = label("Identificador: " + eventId, 11, Color.rgb(143, 177, 207), false);
        card.addView(id, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 18));

        if ("atualizacao".equals(type)) {
            Button updates = primaryButton("Abrir atualizações disponíveis");
            updates.setOnClickListener(v -> openUpdates());
            page.addView(updates, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 9));
        }
        Button back = secondaryButton("Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(page);
        setContentView(scroll);
    }

    protected void openUpdates() {
        Intent intent = new Intent(this, UpdatesActivity.class);
        intent.putExtra("open_update_available", true);
        startActivity(intent);
        finish();
    }

    protected String categoryLabel(String type) {
        if ("aviso".equals(type)) return "AVISO";
        if ("atualizacao".equals(type)) return "ATUALIZAÇÃO DISPONÍVEL";
        if ("emergencia".equals(type)) return "EMERGÊNCIA";
        if ("dem_recebida".equals(type)) return "TRANSFERÊNCIA DEM RECEBIDA";
        if ("dem_enviada".equals(type)) return "TRANSFERÊNCIA DEM ENVIADA";
        if ("transacao".equals(type)) return "TRANSAÇÃO";
        return "INFORMAÇÃO";
    }

    protected String iconDrawableFor(String type) {
        if ("aviso".equals(type)) return "ic_notification_warning";
        if ("atualizacao".equals(type)) return "ic_notification_update";
        if ("emergencia".equals(type)) return "ic_notification_emergency";
        if ("dem_recebida".equals(type)) return "ic_notification_dem_received";
        if ("dem_enviada".equals(type)) return "ic_notification_dem_sent";
        if ("transacao".equals(type)) return "ic_notification_transaction";
        return "ic_notification_info";
    }

    protected int accentFor(String type) {
        if ("aviso".equals(type)) return Color.rgb(245, 158, 11);
        if ("atualizacao".equals(type)) return Color.rgb(16, 185, 129);
        if ("emergencia".equals(type)) return Color.rgb(225, 29, 72);
        if ("dem_recebida".equals(type)) return Color.rgb(16, 185, 129);
        if ("dem_enviada".equals(type)) return Color.rgb(168, 85, 247);
        if ("transacao".equals(type)) return Color.rgb(59, 130, 246);
        return Color.rgb(14, 165, 233);
    }

    protected TextView label(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(android.graphics.Typeface.DEFAULT, bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        return view;
    }

    protected Button primaryButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setMinHeight(dp(50));
        button.setBackground(gradient(Color.rgb(9, 145, 178), Color.rgb(37, 99, 235), Color.rgb(13, 148, 136)));
        return button;
    }

    protected Button secondaryButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextColor(Color.rgb(219, 234, 254));
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setMinHeight(dp(49));
        button.setBackground(rounded(Color.argb(220, 10, 37, 56), Color.argb(105, 94, 234, 212), 18));
        return button;
    }

    protected LinearLayout.LayoutParams lp(int width, int height, int left, int bottom) {
        LinearLayout.LayoutParams result = new LinearLayout.LayoutParams(width, height);
        result.setMargins(dp(left), 0, dp(left), dp(bottom));
        return result;
    }

    protected int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    protected String clean(String value, String fallback) { return value == null || value.trim().isEmpty() ? fallback : value.trim(); }
    protected GradientDrawable rounded(int fill, int stroke, int radius) { GradientDrawable drawable = new GradientDrawable(); drawable.setColor(fill); drawable.setCornerRadius(dp(radius)); drawable.setStroke(dp(1), stroke); return drawable; }
    protected GradientDrawable gradient(int first, int second, int third) { GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{first, second, third}); drawable.setCornerRadius(dp(28)); return drawable; }
    protected int darken(int color) { return Color.rgb(Math.max(0, Color.red(color) - 45), Math.max(0, Color.green(color) - 45), Math.max(0, Color.blue(color) - 45)); }
}
