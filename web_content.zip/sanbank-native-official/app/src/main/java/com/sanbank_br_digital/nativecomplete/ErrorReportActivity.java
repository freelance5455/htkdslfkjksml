package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.text.InputFilter;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

/** Envio transparente de um relato de erro, sem captura de tela ou dados de autenticação. */
public final class ErrorReportActivity extends NativeModuleActivity {
    private static final int MAX_DESCRIPTION = 2000;
    private EditText locationInput;
    private EditText descriptionInput;
    private TextView status;
    private Button sendButton;

    @Override protected void onModuleReady() {
        showReportForm();
    }

    private void showReportForm() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);
        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        heading.setPadding(dp(16), dp(15), dp(16), dp(15));
        heading.setBackground(rounded(Color.argb(238, 8, 27, 45), Color.argb(92, 45, 212, 191), 22));
        heading.addView(text("RELACIONAMENTO SANBANK", 9, TEAL, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 4));
        heading.addView(text("Relatar erro do aplicativo", 22, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 5));
        heading.addView(text("Descreva o que aconteceu para o administrador analisar.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        page.addView(heading, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(16), dp(16), dp(16), dp(16));
        form.setBackground(rounded(Color.argb(238, 8, 27, 45), Color.argb(88, 45, 212, 191), 22));
        form.setElevation(dp(2));
        form.addView(text("Tela ou função (opcional)", 12, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 5));
        locationInput = textInput("Ex.: transferência DEM, login, extrato");
        locationInput.setSingleLine(true);
        locationInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(120)});
        form.addView(locationInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 12));
        form.addView(text("O que aconteceu?", 12, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 5));
        descriptionInput = textInput("Descreva o erro e os passos para reproduzi-lo");
        descriptionInput.setSingleLine(false);
        descriptionInput.setMinLines(5);
        descriptionInput.setMaxLines(10);
        descriptionInput.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        descriptionInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_DESCRIPTION)});
        form.addView(descriptionInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(145), 0, 11));
        TextView privacy = text("O relato será enviado ao administrador do Gerente SANBANK. Não inclua senha, código de acesso, token ou número completo de cartão. O app não envia captura de tela nem esses dados automaticamente.", 11, Color.rgb(191, 219, 254), false);
        privacy.setSingleLine(false);
        form.addView(privacy, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        page.addView(form, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        status = text("", 12, MUTED, false);
        status.setSingleLine(false);
        status.setPadding(dp(12), dp(10), dp(12), dp(10));
        status.setBackground(rounded(Color.argb(218, 7, 39, 54), Color.argb(82, 45, 212, 191), 17));
        page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 7));
        sendButton = primaryButton("Enviar relato ao administrador");
        sendButton.setOnClickListener(v -> sendReport());
        page.addView(sendButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 8));
        Button back = secondaryButton("Voltar ao menu Mais");
        back.setOnClickListener(v -> finish());
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        scroll.addView(page);
        root.addView(scroll, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void sendReport() {
        String description = descriptionInput == null ? "" : descriptionInput.getText().toString().trim();
        String location = locationInput == null ? "" : locationInput.getText().toString().trim();
        if (description.isEmpty()) {
            if (descriptionInput != null) { descriptionInput.setError("Descreva o problema antes de enviar."); descriptionInput.requestFocus(); }
            return;
        }
        if (description.length() > MAX_DESCRIPTION) {
            if (descriptionInput != null) descriptionInput.setError("O relato pode ter até " + MAX_DESCRIPTION + " caracteres.");
            return;
        }
        if (currentUser == null || field(currentUser, "account").isEmpty()) {
            if (status != null) status.setText("Entre na sua conta para enviar o relato com segurança.");
            return;
        }

        sendButton.setEnabled(false);
        status.setText("Enviando relato ao administrador...");
        status.setTextColor(Color.rgb(125, 211, 252));
        String account = field(currentUser, "account");
        String report = "[SANBANK_ERROR_REPORT]\n"
                + "Aplicativo: SANBANK BR DIGITAL\n"
                + "Versão: " + installedVersion() + "\n"
                + "Conta: " + account + "\n"
                + "Tela/função: " + (location.isEmpty() ? "Não informada" : location) + "\n"
                + "Descrição:\n" + description;
        JSONObject payload = new JSONObject();
        try {
            payload.put("id", "ERR-" + account + "-" + System.currentTimeMillis());
            payload.put("account", account);
            payload.put("sender_role", "user");
            payload.put("role", "user");
            payload.put("sender", "user");
            payload.put("sender_name", field(currentUser, "name", "Cliente SANBANK"));
            payload.put("message", report);
            payload.put("status", "open");
            payload.put("created_at", isoNow());
        } catch (Exception ignored) { }

        apiUpsert("chat_suporte", payload, new RpcCallback() {
            @Override public void success(Object result) {
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    status.setText("Relato enviado ao administrador do Gerente SANBANK.");
                    status.setTextColor(Color.rgb(52, 211, 153));
                    Toast.makeText(ErrorReportActivity.this, "Relato enviado.", Toast.LENGTH_LONG).show();
                    mainHandler.postDelayed(ErrorReportActivity.this::finish, 900L);
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    sendButton.setEnabled(true);
                    status.setText("Não foi possível enviar agora. Confira a conexão e tente novamente.");
                    status.setTextColor(Color.rgb(251, 191, 36));
                });
            }
        });
    }
}
