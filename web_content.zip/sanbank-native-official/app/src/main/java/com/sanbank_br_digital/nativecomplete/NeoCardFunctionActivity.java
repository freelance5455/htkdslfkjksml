package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Base das Activities independentes de cada função do Cartão Neo Bradesco. */
public abstract class NeoCardFunctionActivity extends FunctionActivityBase {
    protected JSONObject card;
    protected TextView cardStatus;

    protected void beginNeoFunction(String title, String subtitle) {
        beginFunctionPage(title, subtitle);
        cardStatus = statusText("Consultando os dados do Cartão Neo...");
    }

    protected void loadNeoCard(final NeoCardCallback callback) {
        listTab("cartoes_neo", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                JSONObject loaded = normalizeRecord(latestRecord(records));
                card = loaded;
                runOnUiThread(() -> {
                    if (loaded == null) {
                        if (cardStatus != null) cardStatus.setText("Nenhum Cartão Neo foi encontrado para esta conta.");
                        return;
                    }
                    if (cardStatus != null) cardStatus.setText("Dados do Cartão Neo carregados.");
                    callback.loaded(loaded);
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> { if (cardStatus != null) cardStatus.setText("Não foi possível carregar o Cartão Neo agora."); });
            }
        });
    }

    protected boolean neoBlocked(JSONObject value) {
        return value == null || isBlockedStatus(field(value, "status", "ativo")) || isNeoCardSecurityBlocked();
    }

    protected double neoTotal(JSONObject value) { return Math.max(0, decimal(field(value, "limit_total"))); }
    protected double neoUsed(JSONObject value) { return Math.max(0, decimal(field(value, "limit_used"))); }
    protected double neoAvailable(JSONObject value) {
        return isNeoCardSecurityBlocked() ? 0 : Math.max(0, neoTotal(value) - neoUsed(value));
    }
    protected double neoInvoice(JSONObject value) {
        String raw = firstField(value, "invoice_amount", "fatura", "current_invoice");
        return raw.isEmpty() ? neoUsed(value) : Math.max(0, decimal(raw));
    }
    protected String neoLastFour(JSONObject value) {
        String number = field(value, "card_number").replaceAll("\\D", "");
        return number.length() >= 4 ? number.substring(number.length() - 4) : "••••";
    }

    protected LinearLayout neoSummaryCard(JSONObject value) {
        LinearLayout summary = surfaceCard();
        summary.addView(text("Cartão Neo Bradesco", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(27), 0, 4));
        summary.addView(text("Titular: " + field(value, "card_holder", field(currentUser, "name", "Cliente")), 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(23), 0, 3));
        summary.addView(text("Cartão final " + neoLastFour(value) + " · " + field(value, "status", "ativo"), 12, Color.rgb(191, 219, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(23), 0, 0));
        return summary;
    }

    protected String neoStatusText(JSONObject value) {
        if (isNeoCardSecurityBlocked()) return "BLOQUEADO POR SEGURANÇA";
        return field(value, "status", "ativo").toUpperCase(Locale.ROOT);
    }

    protected interface NeoCardCallback { void loaded(JSONObject value); }
}
