package com.sanbank_br_digital.app;

/** Pix no cartão Neo: pagamento à vista ou parcelado e comprovante. */
public final class PixActivity extends NativeModuleActivity {
    @Override
    protected void onModuleReady() {
        openPixScreen();
    }
}
