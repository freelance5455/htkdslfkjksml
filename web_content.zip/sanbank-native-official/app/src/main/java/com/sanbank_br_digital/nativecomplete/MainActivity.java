package com.sanbank_br_digital.app;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.UUID;

/** Painel principal oficial do SANBANK BR DIGITAL com verificação obrigatória do PAY. */
public final class MainActivity extends NativeBaseActivity {
    private static final String PAY_PACKAGE = "com.sanbank.services.pay";
    private static final String PAY_ACTIVITY = "com.sanbank.services.pay.MainActivity";
    private static final String PAY_SECURITY_REQUEST = "sanbank_pay_security_check";
    private static final String PAY_SECURITY_RESULT = "sanbank_pay_security_ok";
    private static final String PAY_SECURITY_NONCE = "sanbank_pay_security_nonce";
    private static final int REQUEST_PAY_SECURITY = 9421;
    private boolean payCheckStarted;
    private boolean payDialogShown;
    private String payNonce = "";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (!restoreSavedSession()) {
            completeLoadingThen(this::launchLogin);
            return;
        }
        showLoadingScreen("Verificando o Sanbank Services PAY", "A proteção obrigatória está sendo consultada...", 10000L);
        checkPayThenOpen();
    }

    private void launchLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    private void checkPayThenOpen() {
        if (payCheckStarted || isFinishing()) return;
        payCheckStarted = true;
        loadingMessage("Verificando se o Sanbank Services PAY está instalado e assinado...");
        String installationError = payInstallationError();
        if (!installationError.isEmpty()) {
            payCheckStarted = false;
            fetchPayUpdateAndOfferDownload(installationError);
            return;
        }
        startPaySecurityHandshake();
    }

    private String payInstallationError() {
        try {
            PackageManager manager = getPackageManager();
            manager.getApplicationInfo(PAY_PACKAGE, 0);
            if (manager.checkSignatures(getPackageName(), PAY_PACKAGE) != PackageManager.SIGNATURE_MATCH) return "A assinatura do PAY não corresponde à assinatura SANBANK.";
            manager.getActivityInfo(new ComponentName(PAY_PACKAGE, PAY_ACTIVITY), 0);
            return "";
        } catch (PackageManager.NameNotFoundException error) {
            return "O Sanbank Services PAY não está instalado neste aparelho.";
        } catch (Exception error) {
            return "Não foi possível verificar o Sanbank Services PAY.";
        }
    }

    private void startPaySecurityHandshake() {
        payNonce = UUID.randomUUID().toString();
        Intent request = new Intent();
        request.setComponent(new ComponentName(PAY_PACKAGE, PAY_ACTIVITY));
        request.putExtra(PAY_SECURITY_REQUEST, true);
        request.putExtra("caller_package", getPackageName());
        request.putExtra("return_package", getPackageName());
        request.putExtra(PAY_SECURITY_NONCE, payNonce);
        try {
            loadingMessage("Abrindo a Activity de segurança do PAY...");
            startActivityForResult(request, REQUEST_PAY_SECURITY);
        } catch (ActivityNotFoundException error) {
            payCheckStarted = false;
            fetchPayUpdateAndOfferDownload("A Activity de segurança do PAY não está disponível.");
        }
    }

    private void fetchPayUpdateAndOfferDownload(String reason) {
        loadingMessage(reason + " Consultando a publicação do PAY no Supabase...");
        JSONObject body = new JSONObject();
        try { body.put("p_source_tab", "atualizacao"); body.put("p_filters", new JSONObject()); } catch (Exception ignored) { }
        rpc("sanbank_api_list", body, new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject update = latestPayUpdate(result);
                runOnUiThread(() -> showPayDownloadDialog(reason, update));
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> showPayDownloadDialog(reason, null));
            }
        });
    }

    private JSONObject latestPayUpdate(Object result) {
        if (!(result instanceof JSONArray)) return null;
        JSONArray records = (JSONArray) result;
        JSONObject best = null;
        for (int i = 0; i < records.length(); i++) {
            JSONObject item = records.optJSONObject(i);
            if (item == null) continue;
            String pkg = firstField(item, "package_name", "package", "packageId", "app_package", "android_package");
            if (!PAY_PACKAGE.equals(pkg)) continue;
            String version = firstField(item, "version_name", "version", "app_version", "versao", "versão");
            String url = firstField(item, "download_url", "apk_url", "url", "link");
            if (version.isEmpty() || !url.startsWith("https://")) continue;
            if (best == null || compareVersions(version, firstField(best, "version_name", "version", "app_version", "versao", "versão")) < 0) continue;
            try {
                item.put("pay_version", version);
                item.put("pay_download_url", url);
                item.put("pay_notes", firstField(item, "release_notes", "notes", "changelog", "novidades"));
                best = item;
            } catch (Exception ignored) { }
        }
        return best;
    }

    private void showPayDownloadDialog(String reason, JSONObject update) {
        if (isFinishing() || payDialogShown) return;
        payDialogShown = true;
        if (update == null) {
            new AlertDialog.Builder(this)
                    .setTitle("Sanbank Services PAY obrigatório")
                    .setMessage(reason + "\n\nNão foi encontrada uma publicação HTTPS do PAY na API Supabase.")
                    .setCancelable(false)
                    .setPositiveButton("Tentar novamente", (d, w) -> { payDialogShown = false; payCheckStarted = false; checkPayThenOpen(); })
                    .setNegativeButton("Sair", (d, w) -> finish())
                    .show();
            return;
        }
        String version = update.optString("pay_version", "");
        String notes = update.optString("pay_notes", "Atualização do componente obrigatório de segurança.");
        new AlertDialog.Builder(this)
                .setTitle("Instale o Sanbank Services PAY")
                .setMessage(reason + "\n\nVersão disponível: " + version + "\n\n" + notes + "\n\nO download começará automaticamente e, ao atingir 100%, o instalador oficial do Android será aberto.")
                .setCancelable(false)
                .setPositiveButton("Baixar agora", (d, w) -> {
                    Intent download = new Intent(this, PayDownloadActivity.class);
                    download.putExtra("download_url", update.optString("pay_download_url"));
                    download.putExtra("update_version", version);
                    download.putExtra("update_notes", notes);
                    startActivity(download);
                })
                .setNegativeButton("Sair", (d, w) -> finish())
                .show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PAY_SECURITY) return;
        boolean ok = resultCode == RESULT_OK && data != null
                && data.getBooleanExtra(PAY_SECURITY_RESULT, false)
                && payNonce.equals(data.getStringExtra(PAY_SECURITY_NONCE));
        if (ok) {
            loadingMessage("Verificação do PAY concluída. Consultando a proteção da conta...");
            checkSecurityThenOpen();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Verificação de segurança não confirmada")
                    .setMessage("O SANBANK BR DIGITAL só pode continuar depois que o Sanbank Services PAY concluir a verificação obrigatória.")
                    .setCancelable(false)
                    .setPositiveButton("Tentar novamente", (d, w) -> { payCheckStarted = false; checkPayThenOpen(); })
                    .setNegativeButton("Sair", (d, w) -> finish())
                    .show();
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("pay_just_installed", false)) {
            payCheckStarted = false;
            payDialogShown = false;
            checkPayThenOpen();
        }
    }
}
