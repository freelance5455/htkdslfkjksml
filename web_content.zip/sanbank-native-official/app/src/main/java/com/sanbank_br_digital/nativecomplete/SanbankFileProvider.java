package com.sanbank_br_digital.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

/** Provider somente leitura para abrir o extrato PDF sem expor file://. */
public class SanbankFileProvider extends ContentProvider {
    private static final String SHARED_FOLDER = "shared";
    private static final String EXTERNAL_STATEMENT_FOLDER = "external";

    public static Uri uriForFile(Context context, File file, String folder) {
        return new Uri.Builder().scheme("content")
                .authority(context.getPackageName() + ".fileprovider")
                .appendPath(folder).appendPath(file.getName()).build();
    }

    @Override public boolean onCreate() { return true; }
    @Override public String getType(Uri uri) { return "application/pdf"; }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (mode == null || !mode.startsWith("r")) throw new FileNotFoundException("Somente leitura");
        File file = resolveFile(uri);
        if (!file.isFile()) throw new FileNotFoundException(file.getAbsolutePath());
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        File file;
        try { file = resolveFile(uri); } catch (FileNotFoundException error) { return null; }
        String[] columns = projection == null ? new String[]{"_display_name", "_size"} : projection;
        MatrixCursor cursor = new MatrixCursor(columns, 1);
        Object[] row = new Object[columns.length];
        for (int i = 0; i < columns.length; i++) {
            if ("_display_name".equals(columns[i])) row[i] = file.getName();
            else if ("_size".equals(columns[i])) row[i] = file.length();
        }
        cursor.addRow(row);
        return cursor;
    }

    @Override public int delete(Uri uri, String selection, String[] selectionArgs) {
        try { return resolveFile(uri).delete() ? 1 : 0; } catch (FileNotFoundException error) { return 0; }
    }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException("Provider somente leitura"); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { throw new UnsupportedOperationException("Provider somente leitura"); }

    private File resolveFile(Uri uri) throws FileNotFoundException {
        if (getContext() == null || uri == null) throw new FileNotFoundException("URI inválida");
        List<String> segments = uri.getPathSegments();
        if (segments == null || segments.size() != 2 || !(SHARED_FOLDER.equals(segments.get(0)) || EXTERNAL_STATEMENT_FOLDER.equals(segments.get(0)))) throw new FileNotFoundException("Caminho não autorizado");
        File root;
        if (SHARED_FOLDER.equals(segments.get(0))) root = new File(getContext().getCacheDir(), SHARED_FOLDER);
        else if (EXTERNAL_STATEMENT_FOLDER.equals(segments.get(0))) root = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "extrato sanbank");
        else throw new FileNotFoundException("Caminho não autorizado");
        File requested = new File(root, segments.get(1));
        try {
            File canonicalRoot = root.getCanonicalFile();
            File canonicalRequested = requested.getCanonicalFile();
            String rootPath = canonicalRoot.getPath() + File.separator;
            if (!canonicalRequested.getPath().startsWith(rootPath)) throw new FileNotFoundException("Caminho não autorizado");
            return canonicalRequested;
        } catch (IOException error) { throw new FileNotFoundException("Não foi possível abrir o arquivo"); }
    }
}
