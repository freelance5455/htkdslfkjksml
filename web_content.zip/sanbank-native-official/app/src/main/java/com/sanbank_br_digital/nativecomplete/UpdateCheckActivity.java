package com.sanbank_br_digital.app;

import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

/** Primeira etapa do fluxo de atualização: consulta a versão disponível. */
public final class UpdateCheckActivity extends NativeModuleActivity {
    private TextView status;
    private TextView availableVersion;
    private TextView releaseNotes;
    private Button checkButton;
    private Button downloadButton;
    private JSONObject latest;

    @Override
    protected void onModuleReady() {
        showCheckScreen();
        queryUpdate();
    }

    private void showCheckScreen() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);
        page.addView(text("Verificar atualização", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 3));
        page.addView(text("Activity exclusiva para consultar a publicação mais recente do SANBANK BR DIGITAL.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));

        LinearLayout installed = surfaceCard();
        installed.addView(text("Versão instalada", 12, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 3));
        installed.addView(text(installedVersion(), 21, Color.rgb(125, 211, 252), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(32), 0, 0));
        page.addView(installed, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        status = text("Consultando atualizações disponíveis...", 12, MUTED, false);
        status.setPadding(dp(12), dp(11), dp(12), dp(11));
        status.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
        page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        LinearLayout available = surfaceCard();
        available.addView(text("Atualização encontrada", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(27), 0, 4));
        availableVersion = text("Nenhuma versão nova consultada.", 18, Color.rgb(167, 243, 208), true);
        available.addView(availableVersion, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(30), 0, 5));
        releaseNotes = text("O changelog será mostrado aqui quando houver uma nova publicação.", 12, MUTED, false);
        releaseNotes.setSingleLine(false);
        releaseNotes.setMaxLines(Integer.MAX_VALUE);
        available.addView(releaseNotes, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        page.addView(available, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));

        checkButton = secondaryButton("Consultar novamente");
        page.addView(checkButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 8));
        checkButton.setOnClickListener(v -> queryUpdate());
        downloadButton = primaryButton("Ir para download");
        downloadButton.setVisibility(View.GONE);
        page.addView(downloadButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 8));
        downloadButton.setOnClickListener(v -> beginDownload());
        Button back = secondaryButton("Voltar");
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        back.setOnClickListener(v -> finish());
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void queryUpdate() {
        if (checkButton != null) checkButton.setEnabled(false);
        if (downloadButton != null) downloadButton.setVisibility(View.GONE);
        if (status != null) status.setText("Consultando versão publicada no Supabase...");
        JSONObject payload = new JSONObject();
        try { payload.put("p_source_tab", "atualizacao"); payload.put("p_filters", new JSONObject()); } catch (Exception ignored) { }
        rpc("sanbank_api_list", payload, new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject update = latestUpdate(result);
                String current = installedVersion();
                runOnUiThread(() -> {
                    if (checkButton != null) checkButton.setEnabled(true);
                    latest = update;
                    if (update == null) {
                        status.setText("Nenhuma publicação compatível foi encontrada.");
                        availableVersion.setText("Nenhuma versão nova");
                        releaseNotes.setText("A API não retornou uma atualização para este pacote.");
                        return;
                    }
                    String version = update.optString("version", "--");
                    if (compareVersions(version, current) <= 0) {
                        status.setText("O aplicativo já está atualizado.");
                        availableVersion.setText("Versão atual: " + current);
                        releaseNotes.setText("Nenhuma atualização pendente no momento.");
                        return;
                    }
                    status.setText("Nova atualização disponível.");
                    availableVersion.setText("Versão nova: " + version);
                    releaseNotes.setText(update.optString("notes", "Nenhum changelog informado."));
                    downloadButton.setVisibility(View.VISIBLE);
                });
            }
            @Override public void failure(String message) {
                runOnUiThread(() -> {
                    if (checkButton != null) checkButton.setEnabled(true);
                    status.setText("Não foi possível consultar a atualização agora.");
                });
            }
        });
    }

    private void beginDownload() {
        if (latest == null) return;
        Intent intent = new Intent(this, UpdateDownloadActivity.class);
        intent.putExtra("download_url", latest.optString("downloadUrl"));
        intent.putExtra("update_version", latest.optString("version"));
        intent.putExtra("update_notes", latest.optString("notes"));
        startActivity(intent);
    }
}
