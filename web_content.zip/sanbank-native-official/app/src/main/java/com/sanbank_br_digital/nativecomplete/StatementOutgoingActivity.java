package com.sanbank_br_digital.app;

/** Activity da categoria Saídas do extrato. */
public final class StatementOutgoingActivity extends StatementCategoryActivity {
    @Override protected String categoryTitle() { return "Saídas"; }
    @Override protected String categoryDescription() { return "Veja os débitos e valores que saíram da conta."; }
    @Override protected String categoryKey() { return "outgoing"; }
    @Override protected String categoryIconName() { return "ic_transfer"; }
}
