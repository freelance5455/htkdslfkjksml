package com.sanbank_br_digital.app;

/** Etapa 8 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep8Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 8; }
}
