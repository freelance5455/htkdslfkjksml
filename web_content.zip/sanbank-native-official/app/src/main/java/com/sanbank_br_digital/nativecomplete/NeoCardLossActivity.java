package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

/** Activity exclusiva para comunicar perda ou roubo e bloquear o Cartão Neo. */
public final class NeoCardLossActivity extends NeoCardFunctionActivity {
    private Button blockButton;

    @Override
    protected void onModuleReady() {
        beginNeoFunction("Perda ou roubo do cartão", "Bloqueie imediatamente o Cartão Neo em caso de perda ou roubo.");
        LinearLayout warning = surfaceCard();
        warning.addView(text("Bloqueio de segurança", 16, Color.rgb(251, 113, 133), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 6));
        warning.addView(text("Ao confirmar, o cartão atual será marcado como cancelado por perda ou roubo e não poderá continuar sendo usado.", 13, Color.rgb(254, 205, 211), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        blockButton = primaryButton("Bloquear cartão agora");
        warning.addView(blockButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(warning, 10);
        addBackButton();
        loadNeoCard(value -> {
            boolean alreadyBlocked = isBlockedStatus(field(value, "status", "ativo"));
            blockButton.setEnabled(!alreadyBlocked);
            blockButton.setText(alreadyBlocked ? "Cartão já bloqueado" : "Bloquear cartão agora");
            cardStatus.setText(alreadyBlocked ? "Este Cartão Neo já está bloqueado." : "Confirme somente se o cartão foi perdido ou roubado.");
            blockButton.setOnClickListener(v -> confirmNativeCardBlock(value));
        });
    }

    @Override
    protected void onNativeNeoCardMutationComplete() {
        finish();
    }
}
