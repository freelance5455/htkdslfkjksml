package com.sanbank_br_digital.app;

/** Etapa 5 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep5Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 5; }
}
