package com.sanbank_br_digital.app;

/** Etapa 9 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep9Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 9; }
}
