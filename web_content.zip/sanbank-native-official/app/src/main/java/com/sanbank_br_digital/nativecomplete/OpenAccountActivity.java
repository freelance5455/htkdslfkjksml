package com.sanbank_br_digital.app;

/** Primeira etapa do fluxo de abertura de conta. */
public final class OpenAccountActivity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 1; }
}
