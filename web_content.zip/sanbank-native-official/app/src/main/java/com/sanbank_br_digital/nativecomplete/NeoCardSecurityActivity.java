package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Activity exclusiva para consultar o status de segurança do Cartão Neo. */
public final class NeoCardSecurityActivity extends NeoCardFunctionActivity {
    private LinearLayout securityCard;

    @Override
    protected void onModuleReady() {
        beginNeoFunction("Segurança do Cartão Neo", "Consulte bloqueios, uso detectado e o estado de liberação do cartão.");
        securityCard = surfaceCard();
        addCard(securityCard, 10);
        addBackButton();
        loadNeoCard(this::renderSecurity);
    }

    private void renderSecurity(JSONObject value) {
        securityCard.removeAllViews();
        boolean cardBlocked = isNeoCardSecurityBlocked() || isBlockedStatus(field(value, "status", "ativo"));
        boolean accountBlocked = isSecurityLocked(currentUser);
        boolean balanceBlocked = isBalanceSecurityBlocked();
        int usage = number(firstField(currentUser, "security_lock_usage_count", "security_unlock_usage_count", "neo_card_security_usage_count", "security_lock_count"));
        String unlockCommand = firstField(currentUser, "security_unlock_command", "security_unlock_reason");
        securityCard.addView(text("Status atual", 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(27), 0, 5));
        TextView state = text(cardBlocked ? "BLOQUEADO" : "LIBERADO", 23, cardBlocked ? Color.rgb(147, 197, 253) : Color.rgb(110, 231, 183), true);
        securityCard.addView(state, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(35), 0, 10));
        securityCard.addView(text("Cartão: " + (isBlockedStatus(field(value, "status", "ativo")) ? field(value, "status", "bloqueado") : "ativo") + "\nBloqueio do cartão por segurança: " + (isNeoCardSecurityBlocked() ? "sim" : "não") + "\nBloqueio do saldo disponível: " + (balanceBlocked ? "sim" : "não") + "\nConta em bloqueio geral: " + (accountBlocked ? "sim" : "não"), 13, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 11));
        securityCard.addView(text("Operações consolidadas: " + usage + "\nLimite automático: " + neoOperationLimit(currentUser) + " operações\nComando administrativo: " + (unlockCommand.isEmpty() ? "nenhum pendente" : unlockCommand), 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 11));
        cardStatus.setText(cardBlocked ? "O Cartão Neo está bloqueado. Aguarde o desbloqueio administrativo quando aplicável." : "O Cartão Neo está liberado para uso dentro das regras de segurança.");
    }
}
