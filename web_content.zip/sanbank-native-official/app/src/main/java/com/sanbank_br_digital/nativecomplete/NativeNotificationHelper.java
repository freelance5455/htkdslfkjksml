package com.sanbank_br_digital.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import java.util.Locale;

/** Central nativa de notificações individuais, operações e atualizações do SANBANK. */
public final class NativeNotificationHelper {
    private static final String VERSION = "_v4";
    public static final String CHANNEL_INFORMATION = "sanbank_native_information" + VERSION;
    public static final String CHANNEL_WARNING = "sanbank_native_warning" + VERSION;
    public static final String CHANNEL_UPDATE = "sanbank_native_update" + VERSION;
    public static final String CHANNEL_EMERGENCY = "sanbank_native_emergency" + VERSION;
    public static final String CHANNEL_DEM_RECEIVED = "sanbank_native_dem_received" + VERSION;
    public static final String CHANNEL_DEM_SENT = "sanbank_native_dem_sent" + VERSION;
    public static final String CHANNEL_TRANSACTION = "sanbank_native_transaction" + VERSION;
    public static final String CHANNEL_BACKGROUND = "sanbank_native_background" + VERSION;
    private static final String PREFS = "sanbank_native_preview";

    private NativeNotificationHelper() { }

    public static void createChannels(Context context) {
        if (context == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        create(manager, context, CHANNEL_INFORMATION, "Informações SANBANK", "Informações individuais da sua conta", NotificationManager.IMPORTANCE_DEFAULT, "notif_information", true);
        create(manager, context, CHANNEL_WARNING, "Avisos SANBANK", "Avisos importantes da sua conta", NotificationManager.IMPORTANCE_HIGH, "notif_warning", true);
        create(manager, context, CHANNEL_UPDATE, "Atualizações disponíveis", "Novas versões do SANBANK BR DIGITAL", NotificationManager.IMPORTANCE_HIGH, "notif_update", true);
        create(manager, context, CHANNEL_EMERGENCY, "Emergências SANBANK", "Alertas de emergência e segurança", NotificationManager.IMPORTANCE_HIGH, "notif_emergency", true);
        create(manager, context, CHANNEL_DEM_RECEIVED, "Transferência DEM recebida", "Avisos de transferências DEM recebidas", NotificationManager.IMPORTANCE_HIGH, "notif_dem_received", true);
        create(manager, context, CHANNEL_DEM_SENT, "Transferência DEM enviada", "Avisos de transferências DEM enviadas", NotificationManager.IMPORTANCE_DEFAULT, "notif_dem_sent", true);
        create(manager, context, CHANNEL_TRANSACTION, "Outras transações", "Avisos de outras movimentações da conta", NotificationManager.IMPORTANCE_DEFAULT, "notif_transaction", true);
        NotificationChannel background = new NotificationChannel(CHANNEL_BACKGROUND, "Proteção em segundo plano", NotificationManager.IMPORTANCE_LOW);
        background.setDescription("Mantém a sincronização individual ativa em segundo plano");
        background.setShowBadge(false);
        background.enableVibration(false);
        background.setSound(null, null);
        manager.createNotificationChannel(background);
    }

    private static void create(NotificationManager manager, Context context, String id, String name, String description, int importance, String sound, boolean badge) {
        NotificationChannel channel = new NotificationChannel(id, name, importance);
        channel.setDescription(description);
        channel.enableVibration(true);
        channel.setShowBadge(badge);
        Uri uri = soundUri(context, sound);
        if (uri != null) {
            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            channel.setSound(uri, attributes);
        }
        manager.createNotificationChannel(channel);
    }

    public static void post(Context context, String title, String message, String type, String eventId) {
        post(context, title, message, type, eventId, message, "");
    }

    public static void post(Context context, String title, String message, String type, String eventId, String detail) {
        post(context, title, message, type, eventId, detail, "");
    }

    public static void post(Context context, String title, String message, String type, String eventId, String detail, String createdAt) {
        if (context == null || message == null || message.trim().isEmpty()) return;
        createChannels(context);
        String safeTitle = title == null || title.trim().isEmpty() ? "SANBANK BR DIGITAL" : title.trim();
        String safeMessage = message.trim();
        String identity = eventId == null || eventId.trim().isEmpty()
                ? "notification:" + safeTitle + ":" + safeMessage : eventId.trim();
        String key = "native_notification_" + Integer.toHexString(identity.hashCode());
        if (context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(key, false)) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(key, true).apply();

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        String category = canonicalType(type, safeTitle, safeMessage, identity);
        String channel = channelFor(category);
        Intent open;
        if ("atualizacao".equals(category)) {
            open = new Intent(context, UpdatesActivity.class);
            open.putExtra("open_update_available", true);
        } else {
            open = new Intent(context, activityFor(category));
        }
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        open.putExtra("notification_title", safeTitle);
        open.putExtra("notification_message", safeMessage);
        open.putExtra("notification_type", category);
        open.putExtra("notification_detail", detail == null || detail.trim().isEmpty() ? safeMessage : detail.trim());
        open.putExtra("notification_event_id", identity);
        open.putExtra("notification_created_at", createdAt == null || createdAt.trim().isEmpty() ? "Agora" : createdAt.trim());
        int notificationId = identity.hashCode() & 0x7fffffff;
        if (notificationId == 0) notificationId = 1;
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(context, notificationId, open, flags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, channel) : new Notification.Builder(context);
        int color = colorFor(category);
        builder.setSmallIcon(smallIcon(context, category))
                .setLargeIcon(largeIcon(context, category))
                .setColor(color)
                .setContentTitle(safeTitle)
                .setContentText(safeMessage)
                .setStyle(new Notification.BigTextStyle().bigText(safeMessage))
                .setAutoCancel(true)
                .setContentIntent(pending)
                .setWhen(System.currentTimeMillis())
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory("emergencia".equals(category) ? Notification.CATEGORY_ALARM : ("atualizacao".equals(category) ? Notification.CATEGORY_EVENT : Notification.CATEGORY_MESSAGE));
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            Uri sound = soundUri(context, soundFor(category));
            if (sound != null) builder.setSound(sound);
            builder.setVibrate(new long[]{0, 180, 100, 220});
            builder.setPriority("emergencia".equals(category) || "aviso".equals(category) || "atualizacao".equals(category) ? Notification.PRIORITY_HIGH : Notification.PRIORITY_DEFAULT);
        }
        manager.notify(notificationId, builder.build());
    }

    /** Exibe o token Neo de forma privada, ocultando-o na tela bloqueada. */
    public static void postNeoOtp(Context context, String code, String challengeId, String description, String amount, int ttlSeconds) {
        if (context == null || code == null || !code.matches("[0-9]{6}")) return;
        createChannels(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        String identity = "neo-otp:" + (challengeId == null ? "" : challengeId);
        String seenKey = "native_neo_otp_" + Integer.toHexString(identity.hashCode());
        if (context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(seenKey, false)) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !manager.areNotificationsEnabled()) return;
        String title = "Token de confirmação Neo";
        String safeDescription = description == null || description.trim().isEmpty() ? "Compra no Cartão Neo" : description.trim();
        String safeAmount = amount == null || amount.trim().isEmpty() ? "Valor não informado" : amount.trim();
        String message = "Token: " + code + " · expira em " + Math.max(1, ttlSeconds) + " s · toque para revisar";
        Intent open = new Intent(context, NeoTokenApprovalActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        open.putExtra("neo_challenge_id", challengeId);
        open.putExtra("neo_code", code);
        open.putExtra("neo_description", safeDescription);
        open.putExtra("neo_amount", amount == null ? "" : amount);
        open.putExtra("neo_ttl_seconds", Math.max(1, ttlSeconds));
        int computedNotificationId = identity.hashCode() & 0x7fffffff;
        final int notificationId = computedNotificationId == 0 ? 1 : computedNotificationId;
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(context, notificationId, open, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_TRANSACTION) : new Notification.Builder(context);
        builder.setSmallIcon(smallIcon(context, "neo")).setLargeIcon(largeIcon(context, "neo")).setColor(Color.rgb(37, 99, 235))
                .setContentTitle(title).setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText("Token de autorização: " + code + "\nEstabelecimento: " + safeDescription + "\nValor: " + safeAmount + "\nExpira em " + Math.max(1, ttlSeconds) + " segundos. Toque para revisar e confirmar dentro do SANBANK BR DIGITAL."))
                .setAutoCancel(true).setContentIntent(pending).setWhen(System.currentTimeMillis())
                .setVisibility(Notification.VISIBILITY_PRIVATE).setCategory(Notification.CATEGORY_MESSAGE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Notification.Builder publicVersion = new Notification.Builder(context)
                    .setSmallIcon(smallIcon(context, "neo")).setLargeIcon(largeIcon(context, "neo"))
                    .setContentTitle("Confirmação de compra Neo")
                    .setContentText("Abra o SANBANK para revisar a operação.");
            builder.setPublicVersion(publicVersion.build());
        } else {
            Uri sound = soundUri(context, soundFor("transacao"));
            if (sound != null) builder.setSound(sound);
            builder.setPriority(Notification.PRIORITY_HIGH);
        }
        manager.notify(notificationId, builder.build());
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(seenKey, true).apply();
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            try { manager.cancel(notificationId); } catch (Exception ignored) { }
        }, Math.max(1, ttlSeconds) * 1000L);
    }

    public static void postBackground(Context context) {
        if (context == null) return;
        createChannels(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        manager.notify(NativeNotificationService.NOTIFICATION_ID, backgroundNotification(context));
    }

    public static Notification backgroundNotification(Context context) {
        Intent open = new Intent(context, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(context, 9801, open, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_BACKGROUND) : new Notification.Builder(context);
        builder.setSmallIcon(smallIcon(context, "service")).setLargeIcon(largeIcon(context, "service")).setColor(Color.rgb(14, 165, 233))
                .setContentTitle("SANBANK BR DIGITAL")
                .setContentText("Notificações em segundo plano ativas")
                .setContentIntent(pending).setOngoing(true).setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE).setShowWhen(false);
        return builder.build();
    }

    public static String canonicalType(String value, String title, String message, String eventId) {
        String text = ((value == null ? "" : value) + " " + (title == null ? "" : title) + " " + (message == null ? "" : message) + " " + (eventId == null ? "" : eventId)).toLowerCase(Locale.ROOT);
        if (text.contains("emerg") || text.contains("critical") || text.contains("segurança urgente")) return "emergencia";
        if (text.contains("atualiz") || text.contains("update") || text.contains("app-update:")) return "atualizacao";
        if (text.contains("dem_receb") || text.contains("dem recebido") || text.contains("transferência dem receb") || text.contains("transferencia dem receb")) return "dem_recebida";
        if (text.contains("dem_envi") || text.contains("dem enviado") || text.contains("transferência dem envi") || text.contains("transferencia dem envi")) return "dem_enviada";
        if (text.contains("aviso") || text.contains("warning") || text.contains("alerta") || text.contains("manuten")) return "aviso";
        if (text.contains("transa") || text.contains("opera") || text.contains("pix") || text.contains("transfer")) return "transacao";
        return "informativo";
    }

    private static String channelFor(String category) {
        if ("aviso".equals(category)) return CHANNEL_WARNING;
        if ("atualizacao".equals(category)) return CHANNEL_UPDATE;
        if ("emergencia".equals(category)) return CHANNEL_EMERGENCY;
        if ("dem_recebida".equals(category)) return CHANNEL_DEM_RECEIVED;
        if ("dem_enviada".equals(category)) return CHANNEL_DEM_SENT;
        if ("transacao".equals(category)) return CHANNEL_TRANSACTION;
        return CHANNEL_INFORMATION;
    }

    private static String soundFor(String category) {
        if ("aviso".equals(category)) return "notif_warning";
        if ("atualizacao".equals(category)) return "notif_update";
        if ("emergencia".equals(category)) return "notif_emergency";
        if ("dem_recebida".equals(category)) return "notif_dem_received";
        if ("dem_enviada".equals(category)) return "notif_dem_sent";
        if ("transacao".equals(category)) return "notif_transaction";
        return "notif_information";
    }

    private static int colorFor(String category) {
        if ("aviso".equals(category)) return Color.rgb(245, 158, 11);
        if ("atualizacao".equals(category)) return Color.rgb(16, 185, 129);
        if ("emergencia".equals(category)) return Color.rgb(225, 29, 72);
        if ("dem_recebida".equals(category)) return Color.rgb(16, 185, 129);
        if ("dem_enviada".equals(category)) return Color.rgb(168, 85, 247);
        if ("transacao".equals(category)) return Color.rgb(59, 130, 246);
        return Color.rgb(14, 165, 233);
    }

    private static Class<?> activityFor(String category) {
        if ("aviso".equals(category)) return WarningNotificationActivity.class;
        if ("emergencia".equals(category)) return EmergencyNotificationActivity.class;
        if ("dem_recebida".equals(category)) return DemReceivedNotificationActivity.class;
        if ("dem_enviada".equals(category)) return DemSentNotificationActivity.class;
        if ("transacao".equals(category)) return TransactionNotificationActivity.class;
        return InformationNotificationActivity.class;
    }

    private static int smallIcon(Context context, String category) {
        int icon = context.getResources().getIdentifier(iconNameFor(category), "drawable", context.getPackageName());
        if (icon == 0) icon = context.getResources().getIdentifier("ic_notification_brand", "drawable", context.getPackageName());
        return icon == 0 ? android.R.drawable.ic_dialog_info : icon;
    }

    /** Ícone circular com acabamento em degradê para o cartão expandido do Android. */
    private static Bitmap largeIcon(Context context, String category) {
        float density = context.getResources().getDisplayMetrics().density;
        int size = Math.max(64, Math.round(64 * density));
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        bitmap.setDensity(context.getResources().getDisplayMetrics().densityDpi);
        Canvas canvas = new Canvas(bitmap);
        float center = size / 2f;
        float radius = size * 0.47f;
        int accent = "neo".equals(category) ? Color.rgb(37, 99, 235) : colorFor(category);
        int deep = blendColors(accent, Color.rgb(5, 19, 39), 0.72f);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setShader(new LinearGradient(0, 0, size, size, deep, accent, Shader.TileMode.CLAMP));
        canvas.drawCircle(center, center, radius, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, size * 0.025f));
        paint.setColor(Color.argb(180, 220, 246, 255));
        canvas.drawCircle(center, center, radius - size * 0.045f, paint);
        paint.setStrokeWidth(Math.max(1f, size * 0.012f));
        paint.setColor(Color.argb(54, 255, 255, 255));
        canvas.drawCircle(center, center, radius * 0.72f, paint);
        paint.setStyle(Paint.Style.FILL);
        String name = iconNameFor(category);
        int resource = context.getResources().getIdentifier(name, "drawable", context.getPackageName());
        if (resource == 0) resource = context.getResources().getIdentifier("ic_notification_brand", "drawable", context.getPackageName());
        if (resource != 0) {
            Drawable glyph = context.getDrawable(resource);
            if (glyph != null) {
                glyph.setTint(Color.WHITE);
                int glyphSize = Math.round(size * 0.48f);
                int inset = (size - glyphSize) / 2;
                glyph.setBounds(inset, inset, inset + glyphSize, inset + glyphSize);
                glyph.draw(canvas);
            }
        }
        return bitmap;
    }

    private static String iconNameFor(String category) {
        if ("aviso".equals(category)) return "ic_notification_warning";
        if ("atualizacao".equals(category)) return "ic_notification_update";
        if ("emergencia".equals(category)) return "ic_notification_emergency";
        if ("dem_recebida".equals(category)) return "ic_notification_dem_received";
        if ("dem_enviada".equals(category)) return "ic_notification_dem_sent";
        if ("transacao".equals(category) || "neo".equals(category)) return "ic_notification_transaction";
        if ("service".equals(category)) return "ic_notification_service";
        if ("informativo".equals(category)) return "ic_notification_info";
        return "ic_notification_brand";
    }

    private static int blendColors(int foreground, int background, float foregroundRatio) {
        float ratio = Math.max(0f, Math.min(1f, foregroundRatio));
        float inverse = 1f - ratio;
        return Color.rgb(
                Math.round(Color.red(foreground) * ratio + Color.red(background) * inverse),
                Math.round(Color.green(foreground) * ratio + Color.green(background) * inverse),
                Math.round(Color.blue(foreground) * ratio + Color.blue(background) * inverse));
    }

    private static Uri soundUri(Context context, String rawName) {
        int id = context.getResources().getIdentifier(rawName, "raw", context.getPackageName());
        return id == 0 ? null : Uri.parse("android.resource://" + context.getPackageName() + "/" + id);
    }
}
