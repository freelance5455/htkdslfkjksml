package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Fatura do Cartão Neo e envio de pagamento para aprovação. */
public final class NeoInvoiceActivity extends FunctionActivityBase {
    private TextView invoiceValue;
    private TextView closingDate;
    private TextView dueDate;
    private TextView nextInvoiceNotice;
    private EditText amountInput;
    private Button payButton;
    private Button anticipateButton;
    private TextView status;
    private JSONObject card;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Fatura do Cartão Neo", "Consulte a fatura atual e envie um pagamento com confirmação.");
        LinearLayout summary = surfaceCard();
        summary.addView(text("Fatura atual", 14, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(23), 0, 3));
        invoiceValue = text("Carregando...", 27, TEXT, true);
        summary.addView(invoiceValue, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(38), 0, 3));
        closingDate = text("Fechamento: consultando...", 12, Color.rgb(191, 219, 254), false);
        summary.addView(closingDate, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 2));
        dueDate = text("Vencimento: consultando...", 12, Color.rgb(191, 219, 254), false);
        summary.addView(dueDate, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 0));
        addCard(summary, 10);

        LinearLayout nextInvoice = surfaceCard();
        nextInvoice.addView(text("Próxima fatura a vencer", 15, Color.rgb(251, 191, 36), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(26), 0, 4));
        nextInvoiceNotice = text("Consultando valor e vencimento...", 12, MUTED, false);
        nextInvoice.addView(nextInvoiceNotice, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 9));
        anticipateButton = primaryButton("Antecipar pagamento da fatura");
        anticipateButton.setEnabled(false);
        nextInvoice.addView(anticipateButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        addCard(nextInvoice, 10);

        LinearLayout payment = surfaceCard();
        payment.addView(text("Valor a pagar", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        amountInput = functionInput("Até o valor total da fatura");
        amountInput.setSingleLine(true);
        amountInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        payment.addView(amountInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        payButton = primaryButton("Enviar pagamento para aprovação");
        payment.addView(payButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(payment, 10);
        status = statusText("O saldo será atualizado somente depois da aprovação.");
        payButton.setOnClickListener(v -> submit(payButton));
        anticipateButton.setOnClickListener(v -> { if (card == null) return; double value = decimal(firstField(card, "next_invoice_amount", "proxima_fatura", "invoice_amount", "fatura", "limit_used", "0")); amountInput.setText(String.format(Locale.US, "%.2f", value)); submit(payButton); });
        addBackButton();
        loadCard();
    }

    private void loadCard() {
        listTab("cartoes_neo", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                runOnUiThread(() -> {
                    card = normalizeRecord(latestRecord(records));
                    if (card == null) { invoiceValue.setText("Não encontrada"); closingDate.setText("Nenhum Cartão Neo cadastrado."); dueDate.setText("Nenhum Cartão Neo cadastrado."); nextInvoiceNotice.setText("Nenhuma fatura disponível para antecipação."); anticipateButton.setEnabled(false); return; }
                    double invoice = decimal(firstField(card, "next_invoice_amount", "proxima_fatura", "invoice_amount", "fatura", "limit_used", "0"));
                    String closing = formatNeoBillingDate(firstField(card, "invoice_closing_date", "closing_date", "invoice_closing_day", "closing_day", "data_fechamento", "close_date", "invoice_close_date"), NEO_INVOICE_CLOSING_DAY);
                    String due = formatNeoBillingDate(firstField(card, "invoice_due_date", "due_date", "invoice_due_day", "due_day", "data_vencimento", "payment_due_date"), NEO_INVOICE_DUE_DAY);
                    invoiceValue.setText(formatMoney(invoice));
                    closingDate.setText("Fechamento: " + closing);
                    dueDate.setText("Vencimento: " + due);
                    nextInvoiceNotice.setText("Valor: " + formatMoney(invoice) + "\n" + closingDate.getText() + "\n" + dueDate.getText() + "\n\nA antecipação seguirá para aprovação administrativa.");
                    anticipateButton.setEnabled(invoice > 0);
                    amountInput.setText(invoice > 0 ? String.format(Locale.US, "%.2f", invoice) : "");
                    amountInput.setHint("Até " + formatMoney(invoice));
                });
            }
            @Override public void failure(String message) { runOnUiThread(() -> { invoiceValue.setText("Indisponível"); closingDate.setText("Não foi possível consultar o fechamento."); dueDate.setText("Não foi possível consultar o vencimento."); nextInvoiceNotice.setText("Não foi possível consultar a próxima fatura."); anticipateButton.setEnabled(false); }); }
        });
    }

    private void submit(Button button) {
        if (card == null) { status.setText("Aguarde o carregamento do cartão."); return; }
        if (isNeoCardSecurityBlocked() || isBlockedStatus(field(card, "status", "ativo"))) { status.setText("O Cartão Neo está bloqueado e não pode receber pagamento."); return; }
        double invoice = decimal(firstField(card, "next_invoice_amount", "proxima_fatura", "invoice_amount", "fatura", "limit_used", "0"));
        double amount = decimal(amountInput.getText().toString());
        if (amount <= 0 || amount > invoice) { amountInput.setError("Informe um valor até " + formatMoney(invoice)); return; }
        button.setEnabled(false);
        if (anticipateButton != null) anticipateButton.setEnabled(false);
        status.setText("Registrando pagamento da fatura...");
        JSONObject payload = new JSONObject();
        JSONObject operationData = new JSONObject();
        try {
            payload.put("id", "PAGAMENTO-FATURA-" + field(currentUser, "account") + "-" + System.currentTimeMillis());
            payload.put("account", field(currentUser, "account"));
            payload.put("sender_account", field(currentUser, "account"));
            payload.put("sender", field(currentUser, "account"));
            payload.put("amount", Math.round(amount * 100.0) / 100.0);
            payload.put("transaction_type", "PAGAMENTO_FATURA_CARTAO");
            payload.put("type", "PAGAMENTO_FATURA_CARTAO");
            payload.put("description", "Pagamento de fatura do Cartão Neo");
            payload.put("status", "pending");
            payload.put("approval_required", true);
            payload.put("created_at", isoNow());
            operationData.put("invoice_amount", amount);
            operationData.put("card_account", field(currentUser, "account"));
            operationData.put("settlement_model", "saldo_ou_cheque_especial");
            payload.put("operation_data", operationData.toString());
        } catch (Exception ignored) { }
        apiUpsert("pendentes", payload, new RpcCallback() {
            @Override public void success(Object result) { trackPendingTransaction(payload); runOnUiThread(() -> { button.setEnabled(false); status.setText("Pagamento enviado. Aguardando confirmação do administrador."); openOperationStatusActivity(InvoicePaymentOperationActivity.class, payload, operationData); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); if (anticipateButton != null) anticipateButton.setEnabled(true); status.setText(message); }); }
        });
    }
}
