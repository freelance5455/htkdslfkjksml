package com.sanbank_br_digital.app;

import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Empréstimo pessoal com simulação e envio para a aba emprestimos. */
public final class PersonalLoanActivity extends FunctionActivityBase {
    private EditText amountInput;
    private EditText monthsInput;
    private TextView status;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Empréstimo pessoal", "Simule o valor e envie a solicitação para aprovação administrativa.");
        LinearLayout form = surfaceCard();
        form.addView(text("Valor do empréstimo", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        amountInput = loanInput("Entre R$ 100,00 e R$ 5.000,00", false);
        form.addView(amountInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        form.addView(text("Parcelas", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 6));
        monthsInput = loanInput("Entre 2 e 48 parcelas", true);
        form.addView(monthsInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        Button request = primaryButton("Simular e solicitar");
        form.addView(request, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(form, 10);
        status = statusText("A solicitação não altera o saldo antes da aprovação.");
        request.setOnClickListener(v -> submit(request));
        addBackButton();
    }

    private EditText loanInput(String hint, boolean integer) {
        EditText input = functionInput(hint);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | (integer ? 0 : InputType.TYPE_NUMBER_FLAG_DECIMAL));
        return input;
    }

    private void submit(Button button) {
        double amount = decimal(amountInput.getText().toString());
        int months = number(monthsInput.getText().toString());
        if (amount < 100 || amount > 5000 || months < 2 || months > 48) { status.setText("Informe um valor entre R$ 100 e R$ 5.000 e entre 2 e 48 parcelas."); return; }
        double rate = 0.0184;
        double payment = amount * rate / (1 - Math.pow(1 + rate, -months));
        button.setEnabled(false);
        status.setText("Enviando solicitação para análise...");
        JSONObject payload = new JSONObject();
        try {
            payload.put("id", "SANBANK-PESSOAL-" + field(currentUser, "account") + "-" + System.currentTimeMillis());
            payload.put("account", field(currentUser, "account"));
            payload.put("amount", Math.round(amount * 100.0) / 100.0);
            payload.put("months", months);
            payload.put("estimated_payment", Math.round(payment * 100.0) / 100.0);
            payload.put("date", isoNow());
            payload.put("status", "em_analise");
        } catch (Exception ignored) { }
        apiUpsert("emprestimos", payload, new RpcCallback() {
            @Override public void success(Object result) { runOnUiThread(() -> { button.setEnabled(true); status.setText("Solicitação registrada. Parcela estimada: " + formatMoney(payment) + "."); }); }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); status.setText(message); }); }
        });
    }
}
