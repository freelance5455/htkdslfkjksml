package com.sanbank_br_digital.app;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Fluxo de abertura de conta dividido em 13 Activities independentes. */
public abstract class AccountRegistrationStepActivity extends NativeBaseActivity {
    private EditText activeField;
    private EditText passwordField;
    private EditText confirmationField;
    private Button nextButton;
    private TextView status;
    private LinearLayout receiptActions;
    private Uri receiptUri;
    private String createdAccount = "";

    protected abstract int registrationStep();

    @Override protected void onCreate(android.os.Bundle state) {
        super.onCreate(state);
        mainHandler.post(() -> {
            if (registrationStep() == 1) clearRegistrationDraft();
            showRegistrationStep();
        });
    }

    private void showRegistrationStep() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(15), dp(18), dp(15), dp(28));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = roundedSanbankLogo();
        brand.addView(logo, new LinearLayout.LayoutParams(dp(82), dp(61)));
        TextView title = text("Abrir uma nova conta", 22, TEXT, true); title.setGravity(Gravity.CENTER);
        brand.addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(34), 0, 2));
        TextView progress = text("ETAPA " + registrationStep() + " DE 13", 11, Color.rgb(125, 211, 252), true); progress.setGravity(Gravity.CENTER);
        brand.addView(progress, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 0));
        page.addView(brand, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        LinearLayout card = surfaceCard();
        TextView heading = text(stepTitle(), 18, TEXT, true);
        card.addView(heading, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 6));
        TextView help = text(stepHelp(), 12, MUTED, false);
        card.addView(help, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));

        if (registrationStep() == 13) {
            passwordField = input("Senha numérica de 8 dígitos", true);
            card.addView(passwordField, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 10));
            confirmationField = input("Confirmar senha", true);
            card.addView(confirmationField, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 12));
            passwordField.setText(draft("password"));
            confirmationField.setText(draft("password_confirmation"));
        } else {
            activeField = createStepField(card);
            String saved = draft(stepKey());
            if (registrationStep() == 2) saved = maskBirthDate(saved);
            activeField.setText(saved);
            if (registrationStep() == 2) attachBirthDateMask(activeField);
            activeField.setSelection(activeField.length());
            activeField.requestFocus();
        }

        nextButton = primaryButton(registrationStep() == 13 ? "Criar minha conta" : "Continuar");
        nextButton.setOnClickListener(v -> nextStep());
        card.addView(nextButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 10));
        status = text("", 12, MUTED, false); status.setGravity(Gravity.CENTER);
        card.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));

        if (registrationStep() == 13) addReceiptActions(page);
        Button back = secondaryButton(registrationStep() == 1 ? "Voltar ao login" : "Voltar à etapa anterior");
        back.setOnClickListener(v -> finish());
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        scroll.addView(page);
        root.addView(scroll, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void addReceiptActions(LinearLayout page) {
        receiptActions = new LinearLayout(this);
        receiptActions.setOrientation(LinearLayout.HORIZONTAL);
        receiptActions.setVisibility(View.GONE);
        Button open = primaryButton("Abrir PDF");
        Button share = secondaryButton("Compartilhar PDF");
        open.setOnClickListener(v -> AccessReceiptHelper.open(this, receiptUri));
        share.setOnClickListener(v -> AccessReceiptHelper.share(this, receiptUri, "Comprovante de abertura de conta SANBANK BR DIGITAL"));
        receiptActions.addView(open, new LinearLayout.LayoutParams(0, dp(50), 1));
        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(0, dp(50), 1);
        shareParams.setMargins(dp(8), 0, 0, 0);
        receiptActions.addView(share, shareParams);
        page.addView(receiptActions, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 10));
    }

    private EditText createStepField(LinearLayout card) {
        EditText field = input(stepHint(), false);
        int step = registrationStep();
        if (step == 5) {
            field.setInputType(InputType.TYPE_CLASS_NUMBER);
            field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(11)});
        } else if (step == 2) {
            field.setInputType(InputType.TYPE_CLASS_DATETIME | InputType.TYPE_DATETIME_VARIATION_DATE);
            field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        } else if (step == 12) {
            field.setInputType(InputType.TYPE_CLASS_PHONE);
            field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(13)});
        } else if (step == 11) {
            field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        } else {
            field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS | InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
        }
        card.addView(field, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        return field;
    }

    private void nextStep() {
        if (registrationStep() == 13) { createAccount(); return; }
        String value = activeField == null ? "" : activeField.getText().toString().trim();
        String error = validateValue(value);
        if (!error.isEmpty()) { status.setText(error); return; }
        prefs().edit().putString("registration_" + stepKey(), value).apply();
        Intent next = new Intent(this, activityForStep(registrationStep() + 1));
        startActivity(next);
    }

    private String validateValue(String value) {
        if (value.isEmpty()) return "Preencha este campo para continuar.";
        if (registrationStep() == 2 && !validBirthDate(value)) return "Informe uma data de nascimento válida.";
        if (registrationStep() == 5 && digits(value).length() != 11) return "O CPF precisa ter 11 dígitos.";
        if (registrationStep() == 11 && !value.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) return "Informe um e-mail válido.";
        if (registrationStep() == 12 && (digits(value).length() < 10 || digits(value).length() > 13)) return "Informe um celular válido com DDD.";
        return "";
    }

    private boolean validBirthDate(String value) {
        String normalized = normalizeBirthDate(value);
        if (normalized.isEmpty()) return false;
        try {
            java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US);
            format.setLenient(false);
            java.util.Date date = format.parse(normalized);
            return date != null && !date.after(new java.util.Date());
        } catch (Exception error) { return false; }
    }

    private String normalizeBirthDate(String value) {
        String clean = value == null ? "" : value.trim();
        if (clean.matches("\\d{2}/\\d{2}/\\d{4}")) return clean.substring(6) + "-" + clean.substring(3, 5) + "-" + clean.substring(0, 2);
        if (clean.matches("\\d{4}-\\d{2}-\\d{2}")) return clean;
        return "";
    }

    /** Mascara a data durante a digitação: 01011990 vira 01/01/1990. */
    private void attachBirthDateMask(final EditText field) {
        field.addTextChangedListener(new TextWatcher() {
            private boolean formatting;
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable editable) {
                if (formatting) return;
                String masked = maskBirthDate(editable == null ? "" : editable.toString());
                String current = editable == null ? "" : editable.toString();
                if (masked.equals(current)) return;
                formatting = true;
                field.setText(masked);
                field.setSelection(masked.length());
                formatting = false;
            }
        });
    }

    private String maskBirthDate(String value) {
        String digitsOnly = digits(value);
        if (digitsOnly.length() > 8) digitsOnly = digitsOnly.substring(0, 8);
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < digitsOnly.length(); i++) {
            if (i == 2 || i == 4) result.append('/');
            result.append(digitsOnly.charAt(i));
        }
        return result.toString();
    }

    private void createAccount() {
        String pass = digits(passwordField == null ? "" : passwordField.getText().toString());
        String confirm = digits(confirmationField == null ? "" : confirmationField.getText().toString());
        if (!pass.matches("\\d{8}") || !pass.equals(confirm)) { status.setText("As senhas precisam ter exatamente 8 números iguais."); return; }
        String fullName = draft("full_name");
        String cpfValue = digits(draft("cpf"));
        String emailValue = draft("email");
        String phoneValue = digits(draft("phone"));
        if (!fullName.isEmpty()) prefs().edit().putString("registration_password", pass).putString("registration_password_confirmation", confirm).apply();
        if (!prefs().getString("sanbank_open_account_cpf_" + cpfValue, "").isEmpty()) { status.setText("Este CPF já possui uma abertura de conta neste aplicativo. Use a conta existente ou a recuperação de senha."); return; }
        nextButton.setEnabled(false);
        status.setText("Validando o CPF e procurando uma conta disponível...");
        verifyCpfBeforeCreate(fullName, cpfValue, emailValue, phoneValue, pass);
    }

    private void verifyCpfBeforeCreate(String fullName, String cpfValue, String emailValue, String phoneValue, String pass) {
        JSONObject digitsFilter = new JSONObject(); try { digitsFilter.put("cpf", cpfValue); } catch (Exception ignored) { }
        listTabWithFilters("dados_pessoais", digitsFilter, new ListCallback() {
            @Override public void success(JSONArray records) {
                if (records.length() > 0) { duplicateCpf(); return; }
                JSONObject formattedFilter = new JSONObject(); try { formattedFilter.put("cpf", formatCpf(cpfValue)); } catch (Exception ignored) { }
                listTabWithFilters("dados_pessoais", formattedFilter, new ListCallback() {
                    @Override public void success(JSONArray formattedRecords) { if (formattedRecords.length() > 0) duplicateCpf(); else findFreeAccount(fullName, cpfValue, emailValue, phoneValue, pass, 0); }
                    @Override public void failure(String message) { fail("Não foi possível validar o CPF agora."); }
                });
            }
            @Override public void failure(String message) { fail("Não foi possível validar o CPF agora."); }
        });
    }

    private void duplicateCpf() { fail("Este CPF já possui cadastro no SANBANK. Não é possível criar outra conta para o mesmo CPF. Use a recuperação de senha ou faça login."); }
    private void fail(String message) { runOnUiThread(() -> { if (nextButton != null) nextButton.setEnabled(true); if (status != null) status.setText(message); }); }

    private void findFreeAccount(String fullName, String cpfValue, String emailValue, String phoneValue, String pass, int attempt) {
        if (attempt >= 30) { fail("Não foi possível gerar uma conta disponível. Tente novamente."); return; }
        String candidate = String.format(Locale.US, "%06d", 100000 + (int) (Math.random() * 900000));
        JSONObject query = new JSONObject(); try { query.put("p_account", candidate); query.put("p_role", JSONObject.NULL); } catch (Exception ignored) { }
        rpc("sanbank_account_search", query, new RpcCallback() {
            @Override public void success(Object result) { if (firstObject(result) != null) findFreeAccount(fullName, cpfValue, emailValue, phoneValue, pass, attempt + 1); else createAccountRecord(candidate, fullName, cpfValue, emailValue, phoneValue, pass); }
            @Override public void failure(String message) { fail("Não foi possível consultar a disponibilidade da conta."); }
        });
    }

    private void createAccountRecord(String accountNumber, String fullName, String cpfValue, String emailValue, String phoneValue, String pass) {
        JSONObject payload = accountPayload(accountNumber, fullName, cpfValue, emailValue, phoneValue, pass);
        rpc("sanbank_api_account_create", envelope(payload), new RpcCallback() {
            @Override public void success(Object result) {
                prefs().edit().putString("sanbank_open_account_cpf_" + cpfValue, accountNumber).apply();
                registerProfile(accountNumber, fullName, cpfValue, emailValue, phoneValue, pass);
            }
            @Override public void failure(String message) { fail("A API não aceitou a abertura da conta. Tente novamente."); }
        });
    }

    private JSONObject accountPayload(String accountNumber, String fullName, String cpfValue, String emailValue, String phoneValue, String pass) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("account", accountNumber); payload.put("password", pass); payload.put("name", fullName); payload.put("balance", 0); payload.put("role", "user"); payload.put("overdraft_enabled", "FALSE"); payload.put("overdraft_limit", 0);
            payload.put("cpf", cpfValue); payload.put("email", emailValue); payload.put("phone", phoneValue); payload.put("birth_date", normalizeBirthDate(draft("birth_date"))); payload.put("mother_name", draft("mother_name")); payload.put("father_name", draft("father_name")); payload.put("address", draft("address")); payload.put("street", draft("street")); payload.put("neighborhood", draft("neighborhood")); payload.put("city", draft("city")); payload.put("state", draft("state")); payload.put("country", "Brasil"); payload.put("created_at", isoNow());
        } catch (Exception ignored) { }
        return payload;
    }

    private void registerProfile(String accountNumber, String fullName, String cpfValue, String emailValue, String phoneValue, String pass) {
        JSONObject loginBody = new JSONObject(); try { loginBody.put("p_account", accountNumber); loginBody.put("p_password", pass); } catch (Exception ignored) { }
        rpc("sanbank_login_session", loginBody, new RpcCallback() {
            @Override public void success(Object result) {
                JSONObject session = firstObject(result); String token = session == null ? "" : session.optString("session_token", "");
                if (token.isEmpty()) { pendingProfile("A conta foi reservada, mas o perfil não pôde ser finalizado agora. Não tente abrir outra conta para este CPF."); return; }
                sessionToken = token;
                JSONObject profile = accountPayload(accountNumber, fullName, cpfValue, emailValue, phoneValue, pass);
                // A senha nunca entra no perfil nem é persistida em dados_pessoais.
                profile.remove("password");
                try { profile.put("id", "PROFILE-" + accountNumber); } catch (Exception ignored) { }
                apiUpsert("dados_pessoais", profile, new RpcCallback() {
                    @Override public void success(Object ignored) { sessionToken = ""; runOnUiThread(() -> showCreated(accountNumber, fullName, emailValue, phoneValue, pass)); }
                    @Override public void failure(String message) { rollbackAccount(accountNumber, cpfValue); }
                });
            }
            @Override public void failure(String message) { pendingProfile("A conta foi reservada, mas não foi possível finalizar o perfil. Não tente abrir outra conta para este CPF."); }
        });
    }

    private void pendingProfile(String message) { runOnUiThread(() -> { if (nextButton != null) nextButton.setEnabled(true); if (status != null) status.setText(message); }); }

    private void rollbackAccount(String accountNumber, String cpfValue) {
        JSONObject body = new JSONObject(); try { body.put("p_account", accountNumber); } catch (Exception ignored) { }
        rpc("sanbank_api_account_delete", body, new RpcCallback() {
            @Override public void success(Object ignored) { sessionToken = ""; prefs().edit().remove("sanbank_open_account_cpf_" + cpfValue).apply(); fail("Não foi possível concluir a abertura. Nenhuma conta foi criada."); }
            @Override public void failure(String message) { pendingProfile("Não foi possível concluir o cadastro. Não tente criar outra conta para este CPF agora."); }
        });
    }

    private void showCreated(String accountNumber, String fullName, String emailValue, String phoneValue, String pass) {
        createdAccount = accountNumber;
        prefs().edit().remove("registration_full_name").remove("registration_birth_date").remove("registration_mother_name").remove("registration_father_name").remove("registration_cpf").remove("registration_address").remove("registration_street").remove("registration_neighborhood").remove("registration_city").remove("registration_state").remove("registration_email").remove("registration_phone").remove("registration_password").remove("registration_password_confirmation").apply();
        if (nextButton != null) { nextButton.setEnabled(false); nextButton.setText("Conta criada"); }
        if (status != null) { status.setText("Conta aberta com sucesso. Anote o número e use a senha cadastrada para entrar."); status.setTextColor(Color.rgb(167, 243, 208)); }
        receiptUri = AccessReceiptHelper.createAccountReceipt(this, accountNumber, fullName, emailValue, phoneValue, pass);
        if (receiptUri != null && receiptActions != null) receiptActions.setVisibility(View.VISIBLE);
        new android.app.AlertDialog.Builder(this).setTitle("Conta criada com sucesso")
                .setMessage("Titular: " + fullName + "\n\nNúmero da conta: " + accountNumber + "\n\nSua senha foi cadastrada com segurança. Guarde o número da conta para fazer login.")
                .setCancelable(false).setNeutralButton("Abrir PDF", (d, w) -> AccessReceiptHelper.open(this, receiptUri)).setPositiveButton("Ir para o login", (d, w) -> goToLogin()).show();
    }

    private void goToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    private Class<?> activityForStep(int step) {
        switch (step) {
            case 2: return RegistrationStep2Activity.class; case 3: return RegistrationStep3Activity.class; case 4: return RegistrationStep4Activity.class; case 5: return RegistrationStep5Activity.class; case 6: return RegistrationStep6Activity.class; case 7: return RegistrationStep7Activity.class; case 8: return RegistrationStep8Activity.class; case 9: return RegistrationStep9Activity.class; case 10: return RegistrationStep10Activity.class; case 11: return RegistrationStep11Activity.class; case 12: return RegistrationStep12Activity.class; default: return RegistrationStep13Activity.class;
        }
    }

    private String stepKey() {
        switch (registrationStep()) {
            case 1: return "full_name"; case 2: return "birth_date"; case 3: return "mother_name"; case 4: return "father_name"; case 5: return "cpf"; case 6: return "address"; case 7: return "street"; case 8: return "neighborhood"; case 9: return "city"; case 10: return "state"; case 11: return "email"; default: return "phone";
        }
    }

    private String stepTitle() {
        switch (registrationStep()) {
            case 1: return "Nome completo"; case 2: return "Data de nascimento"; case 3: return "Nome da mãe"; case 4: return "Nome do pai"; case 5: return "CPF"; case 6: return "Endereço"; case 7: return "Rua"; case 8: return "Bairro"; case 9: return "Cidade"; case 10: return "Estado"; case 11: return "E-mail"; case 12: return "Celular"; default: return "Senha de acesso";
        }
    }

    private String stepHelp() {
        switch (registrationStep()) {
            case 1: return "Informe seu nome completo como consta no documento."; case 2: return "Use o formato DD/MM/AAAA."; case 3: return "Informe o nome completo da sua mãe."; case 4: return "Informe o nome completo do seu pai."; case 5: return "Digite os 11 números do CPF."; case 6: return "Informe o endereço ou número da residência."; case 7: return "Informe o nome da rua."; case 8: return "Informe o bairro."; case 9: return "Informe a cidade."; case 10: return "Informe o estado."; case 11: return "Informe um e-mail válido para contato."; case 12: return "Informe o celular com DDD."; default: return "Crie uma senha numérica com exatamente 8 dígitos.";
        }
    }

    private String stepHint() {
        switch (registrationStep()) {
            case 1: return "Digite seu nome completo"; case 2: return "00/00/0000"; case 3: return "Nome completo da mãe"; case 4: return "Nome completo do pai"; case 5: return "CPF com 11 dígitos"; case 6: return "Endereço / número"; case 7: return "Nome da rua"; case 8: return "Nome do bairro"; case 9: return "Nome da cidade"; case 10: return "Estado"; case 11: return "E-mail"; default: return "Celular com DDD";
        }
    }

    private String draft(String key) { return prefs().getString("registration_" + key, ""); }
    private void clearRegistrationDraft() { prefs().edit().remove("registration_full_name").remove("registration_birth_date").remove("registration_mother_name").remove("registration_father_name").remove("registration_cpf").remove("registration_address").remove("registration_street").remove("registration_neighborhood").remove("registration_city").remove("registration_state").remove("registration_email").remove("registration_phone").remove("registration_password").remove("registration_password_confirmation").apply(); }
    private String digits(String value) { return value == null ? "" : value.replaceAll("\\D", ""); }
    private String formatCpf(String value) { return value.length() == 11 ? value.substring(0, 3) + "." + value.substring(3, 6) + "." + value.substring(6, 9) + "-" + value.substring(9) : value; }
    private JSONObject envelope(JSONObject payload) { JSONObject body = new JSONObject(); try { body.put("p_payload", payload); } catch (Exception ignored) { } return body; }
}
