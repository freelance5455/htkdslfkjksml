package com.sanbank_br_digital.app;

/** Acompanha a aprovação e o débito de uma Transferência DEM. */
public final class DemOperationActivity extends OperationStatusActivity {
    @Override protected String operationType() { return "DEM"; }
}
