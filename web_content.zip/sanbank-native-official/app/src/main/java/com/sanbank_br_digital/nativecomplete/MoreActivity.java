package com.sanbank_br_digital.app;

/** Menu Mais: reúne as funções adicionais do cliente em Activities independentes. */
public final class MoreActivity extends FunctionActivityBase {
    @Override
    protected void onModuleReady() {
        beginFunctionPage("Mais funções", "Acesse todos os serviços disponíveis para sua conta SANBANK.");
        if (featureVisible("profile")) menuAction("Meu perfil", "Dados pessoais, contato e atualização do cadastro.", ProfileActivity.class);
        if (featureVisible("limits")) menuAction("Meus limites", "Neo, empréstimo pessoal e limites disponíveis.", LimitsActivity.class);
        if (featureVisible("overdraft")) menuAction("Cheque Especial", "Consulte limite, utilização, juros e disponibilidade.", ChequeEspecialActivity.class);
        if (featureVisible("balance_yield")) menuAction("Saldo e CDI", "Rendimento, liquidez, regras e simulações.", InvestmentActivity.class);
        if (featureVisible("card_bill")) menuAction("Fatura Neo", "Consultar fatura e enviar pagamento.", NeoInvoiceActivity.class);
        if (featureVisible("pix") && featureVisible("neo_card")) menuAction("Pix no Cartão Neo", "Solicite um Pix à vista ou parcelado no cartão.", PixActivity.class);
        menuAction("Alterar senha", "Atualize sua senha com confirmação de 8 dígitos.", ChangePasswordActivity.class);
        if (featureVisible("aura")) menuAction("Aura Previdência", "Consulta de benefício e dados previdenciários.", AuraActivity.class);
        if (featureVisible("loan")) menuAction("Empréstimo consignado", "Simulação AURA/INSS com análise administrativa.", ConsignedLoanActivity.class);
        if (featureVisible("personal_loan")) menuAction("Empréstimo pessoal", "Simule parcelas e envie sua solicitação.", PersonalLoanActivity.class);
        if (featureVisible("card_bill")) menuAction("Pagar boleto", "Pagamento do boleto do Cartão Neo.", BillPaymentActivity.class);
        if (featureVisible("pay_qr")) menuAction("Pagar QR", "Escaneie um QR Code para pagar.", QrPaymentActivity.class);
        if (featureVisible("charge_qr")) menuAction("Cobrar QR", "Crie uma cobrança para receber de outra pessoa.", QrChargeActivity.class);
        if (featureVisible("cancel_account")) menuAction("Cancelar conta", "Solicitação protegida de encerramento da conta.", CancelAccountActivity.class);
        menuAction("Relatar erro do aplicativo", "Descreva um problema e envie o relato ao administrador SANBANK.", ErrorReportActivity.class);
        if (featureVisible("about")) menuAction("Sobre", "Versão, compatibilidade e informações do aplicativo.", AboutActivity.class);
        menuAction("Privacidade do aparelho", "Consultar, autorizar ou revogar o cadastro técnico do dispositivo.", DevicePrivacyActivity.class);
        addBackButton();
    }

    @Override
    protected void onAdministrativeVisibilityUpdated() {
        super.onAdministrativeVisibilityUpdated();
        if (!isFinishing()) onModuleReady();
    }
}
