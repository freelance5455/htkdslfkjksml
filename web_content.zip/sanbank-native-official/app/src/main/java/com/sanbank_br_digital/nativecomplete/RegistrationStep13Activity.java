package com.sanbank_br_digital.app;

/** Etapa 13 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep13Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 13; }
}
