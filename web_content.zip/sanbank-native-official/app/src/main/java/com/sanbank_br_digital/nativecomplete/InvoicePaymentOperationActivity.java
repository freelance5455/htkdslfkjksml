package com.sanbank_br_digital.app;

/** Acompanha a aprovação, o débito e a baixa da fatura Neo Bradesco. */
public final class InvoicePaymentOperationActivity extends OperationStatusActivity {
    @Override protected String operationType() { return "INVOICE"; }
}
