package com.sanbank_br_digital.app;

/** Activity da categoria Descontos do extrato. */
public final class StatementDiscountsActivity extends StatementCategoryActivity {
    @Override protected String categoryTitle() { return "Descontos"; }
    @Override protected String categoryDescription() { return "Veja descontos, abatimentos e reduções lançados na conta."; }
    @Override protected String categoryKey() { return "discounts"; }
    @Override protected String categoryIconName() { return "ic_operations"; }
}
