package com.sanbank_br_digital.app;

/** Etapa 6 de 13 da abertura de conta SANBANK. */
public final class RegistrationStep6Activity extends AccountRegistrationStepActivity {
    @Override protected int registrationStep() { return 6; }
}
