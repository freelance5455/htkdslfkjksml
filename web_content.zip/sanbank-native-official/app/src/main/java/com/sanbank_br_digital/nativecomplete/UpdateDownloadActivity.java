package com.sanbank_br_digital.app;

import android.app.DownloadManager;
import android.graphics.Color;
import android.os.Handler;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import android.database.Cursor;

/** Segunda etapa do fluxo: inicia e acompanha automaticamente o download do APK. */
public final class UpdateDownloadActivity extends NativeModuleActivity {
    private final Handler progressHandler = new Handler();
    private TextView status;
    private TextView details;
    private ProgressBar progress;
    private long downloadId = -1L;
    private String version = "";
    private boolean started;

    private final Runnable progressPoller = new Runnable() {
        @Override public void run() {
            updateProgress();
            if (downloadId >= 0 && !isFinished()) progressHandler.postDelayed(this, 700L);
        }
    };

    @Override
    protected void onModuleReady() {
        version = getIntent().getStringExtra("update_version");
        if (version == null) version = "";
        showDownloadScreen();
        progressHandler.postDelayed(this::startAutomaticDownload, 250L);
    }

    private void showDownloadScreen() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(28));
        addDashboardStyleHeader(page);
        page.addView(text("Baixar atualização", 23, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40), 0, 3));
        page.addView(text("A Activity de download trabalha automaticamente com o DownloadManager do Android.", 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        LinearLayout card = surfaceCard();
        card.addView(text("Versão selecionada", 12, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 3));
        card.addView(text(version.isEmpty() ? "Atualização SANBANK" : version, 20, Color.rgb(125, 211, 252), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(32), 0, 4));
        status = text("Preparando download automático...", 12, MUTED, false);
        status.setPadding(dp(11), dp(10), dp(11), dp(10));
        status.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 13));
        card.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        styleProgressBar(progress);
        progress.setProgress(0);
        card.addView(progress, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(9), 0, 8));
        details = text("Aguardando o Android iniciar a transferência...", 11, MUTED, false);
        card.addView(details, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        Button back = secondaryButton("Voltar");
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        back.setOnClickListener(v -> finish());
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void startAutomaticDownload() {
        if (started) return;
        started = true;
        String url = getIntent().getStringExtra("download_url");
        if (url == null || !url.startsWith("https://")) {
            status.setText("O link da atualização não é seguro ou não foi informado.");
            return;
        }
        if (pendingDownloadId >= 0) {
            downloadId = pendingDownloadId;
            status.setText("Retomando download existente...");
            progressHandler.post(progressPoller);
            return;
        }
        enqueueUpdate(url, version);
        downloadId = pendingDownloadId;
        if (downloadId < 0) {
            status.setText("Não foi possível iniciar o download.");
            return;
        }
        status.setText("Download automático iniciado...");
        progressHandler.post(progressPoller);
    }

    private boolean isFinished() {
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (manager == null || downloadId < 0) return true;
        Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(downloadId));
        if (cursor == null) return false;
        try {
            if (!cursor.moveToFirst()) return false;
            int state = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            return state == DownloadManager.STATUS_SUCCESSFUL || state == DownloadManager.STATUS_FAILED;
        } finally { cursor.close(); }
    }

    private void updateProgress() {
        if (downloadId < 0 || status == null) return;
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (manager == null) return;
        Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(downloadId));
        if (cursor == null) return;
        try {
            if (!cursor.moveToFirst()) return;
            int state = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            long downloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            if (state == DownloadManager.STATUS_RUNNING || state == DownloadManager.STATUS_PENDING) {
                int percent = total > 0 ? (int) Math.min(100, Math.max(0, (downloaded * 100L) / total)) : 0;
                progress.setProgress(percent);
                status.setText("Baixando atualização... " + percent + "%");
                details.setText(total > 0 ? downloaded + " / " + total + " bytes" : "O Android está preparando a transferência...");
            } else if (state == DownloadManager.STATUS_SUCCESSFUL) {
                progress.setProgress(100);
                status.setText("Download concluído. Abrindo a Activity para localizar e instalar o APK...");
                details.setText("O instalador oficial do Android será aberto na próxima etapa.");
            } else if (state == DownloadManager.STATUS_FAILED) {
                status.setText("O download da atualização falhou.");
                details.setText("Volte e tente consultar a atualização novamente.");
            }
        } finally { cursor.close(); }
    }

    @Override protected void onDestroy() {
        progressHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
