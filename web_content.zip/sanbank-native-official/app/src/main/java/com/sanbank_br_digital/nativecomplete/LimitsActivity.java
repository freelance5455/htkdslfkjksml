package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/** Visão consolidada dos limites do cliente. */
public final class LimitsActivity extends FunctionActivityBase {
    private TextView status;
    private LinearLayout cards;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Meus limites", "Acompanhe o uso do Cartão Neo, crédito pessoal e saldo disponível.");
        status = statusText("Atualizando seus limites...");
        cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.VERTICAL);
        page.addView(cards, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        Button refresh = secondaryButton("Atualizar limites");
        page.addView(refresh, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8));
        refresh.setOnClickListener(v -> loadLimits(refresh));
        addBackButton();
        loadLimits(refresh);
    }

    private void loadLimits(Button refresh) {
        if (refresh != null) refresh.setEnabled(false);
        cards.removeAllViews();
        double overdraftTotal = overdraftTotalLimit();
        double overdraftAvailable = availableOverdraft();
        double overdraftUsed = Math.max(0, overdraftTotal - overdraftAvailable);
        String rawBalance = field(currentUser, "balance");
        String balanceStatus = accountBalanceStatus();
        addMetric("Saldo disponível", formatDashboardMoney(decimal(rawBalance)), "Saldo atual da conta", signedDisplayColor(rawBalance, balanceStatus));
        addMetric("Cheque especial disponível", formatMoney(overdraftAvailable), "Limite total " + formatMoney(overdraftTotal) + " · usado " + formatMoney(overdraftUsed), signedDisplayColor(String.valueOf(overdraftAvailable), balanceStatus));
        double overdraftInterest = overdraftInterestAmount(currentUser);
        if (overdraftInterest > 0 && overdraftUsedAmount() > 0) {
            addMetric("Juros do Cheque Especial", "- " + formatMoney(overdraftInterest), "Cobrança automática registrada no extrato", Color.rgb(239, 68, 68));
        }
        status.setText("Consultando o limite do Cartão Neo...");
        listTab("cartoes_neo", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                JSONObject card = latestRecord(records);
                runOnUiThread(() -> {
                    if (card != null) {
                        double total = decimal(field(card, "limit_total"));
                        double used = decimal(field(card, "limit_used"));
                        addMetric("Cartão Neo disponível", formatMoney(Math.max(0, total - used)), "Total " + formatMoney(total) + " · usado " + formatMoney(used), Color.rgb(125, 211, 252));
                    } else addMetric("Cartão Neo", "Não encontrado", "Nenhum cartão cadastrado para a conta", MUTED);
                    loadLoanLimit(refresh);
                });
            }
            @Override public void failure(String message) { runOnUiThread(() -> { addMetric("Cartão Neo", "Indisponível", "Não foi possível atualizar agora", Color.rgb(253, 164, 175)); loadLoanLimit(refresh); }); }
        });
    }

    private void loadLoanLimit(Button refresh) {
        listTab("emprestimos", field(currentUser, "account"), new ListCallback() {
            @Override public void success(JSONArray records) {
                runOnUiThread(() -> {
                    double approved = 0;
                    for (int i = 0; i < records.length(); i++) {
                        JSONObject item = records.optJSONObject(i);
                        if (item != null && field(item, "status").matches("(?i).*(aprov|ativo|paid).*")) approved += decimal(firstField(item, "amount", "valor", "value"));
                    }
                    addMetric("Empréstimo pessoal usado", formatMoney(approved), "Contratos aprovados identificados", Color.rgb(196, 181, 253));
                    status.setText("Limites atualizados.");
                    if (refresh != null) refresh.setEnabled(true);
                });
            }
            @Override public void failure(String message) { runOnUiThread(() -> { addMetric("Empréstimo pessoal", "Sem dados", "A aba de contratos não respondeu", MUTED); status.setText("Alguns limites foram carregados parcialmente."); if (refresh != null) refresh.setEnabled(true); }); }
        });
    }

    private void addMetric(String title, String value, String note, int color) {
        LinearLayout card = surfaceCard();
        card.addView(text(title, 13, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(22), 0, 3));
        card.addView(text(value, 22, color, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(32), 0, 3));
        card.addView(text(note, 11, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        cards.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
    }
}
