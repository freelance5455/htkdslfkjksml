package com.sanbank_br_digital.app;

/** Activity da categoria Lançamentos futuros do extrato. */
public final class StatementFutureActivity extends StatementCategoryActivity {
    @Override protected String categoryTitle() { return "Lançamentos futuros"; }
    @Override protected String categoryDescription() { return "Veja lançamentos agendados, previstos e benefícios futuros."; }
    @Override protected String categoryKey() { return "future"; }
    @Override protected String categoryIconName() { return "ic_update"; }
}
