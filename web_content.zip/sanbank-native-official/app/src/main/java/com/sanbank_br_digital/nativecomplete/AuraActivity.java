package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/** Consulta nativa da base Aura Previdência. */
public final class AuraActivity extends FunctionActivityBase {
    private EditText valueInput;
    private TextView status;
    private LinearLayout result;

    @Override
    protected void onModuleReady() {
        beginFunctionPage("Aura Previdência", "Consulte benefício, conta ou CPF na base disponível para o SANBANK.");
        LinearLayout search = surfaceCard();
        search.addView(text("Valor da consulta", 14, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 7));
        valueInput = functionInput("CPF, conta ou número do benefício");
        valueInput.setSingleLine(true);
        valueInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);
        valueInput.setText(field(currentUser, "account"));
        search.addView(valueInput, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 10));
        Button consult = primaryButton("Consultar Aura");
        search.addView(consult, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(search, 10);
        status = statusText("Informe os dados e toque em consultar.");
        result = new LinearLayout(this);
        result.setOrientation(LinearLayout.VERTICAL);
        page.addView(result, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        consult.setOnClickListener(v -> consult(consult));
        addBackButton();
    }

    private void consult(Button button) {
        String value = valueInput.getText().toString().trim();
        if (value.isEmpty()) { valueInput.setError("Informe conta, CPF ou benefício."); return; }
        button.setEnabled(false);
        status.setText("Consultando a base Aura Previdência...");
        result.removeAllViews();
        JSONObject filters = new JSONObject();
        try {
            if (value.matches("\\d{6}")) filters.put("account", value);
            else if (value.replaceAll("\\D", "").length() == 11) filters.put("cpf", value.replaceAll("\\D", ""));
            else filters.put("beneficio", value);
        } catch (Exception ignored) { }
        listTabWithFilters("aura_previdencia", filters, new ListCallback() {
            @Override public void success(JSONArray records) {
                runOnUiThread(() -> {
                    button.setEnabled(true);
                    if (records.length() == 0) { status.setText("Nenhum registro encontrado."); return; }
                    status.setText("Consulta realizada com sucesso.");
                    JSONObject item = records.optJSONObject(0);
                    if (item != null) renderResult(item);
                });
            }
            @Override public void failure(String message) { runOnUiThread(() -> { button.setEnabled(true); status.setText("A base Aura não respondeu agora."); }); }
        });
    }

    private void renderResult(JSONObject item) {
        LinearLayout card = surfaceCard();
        card.addView(text("Dados encontrados", 16, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 8));
        addRow(card, "Nome", firstField(item, "nome", "name", "titular", "Não informado"));
        addRow(card, "CPF", firstField(item, "cpf", "CPF", "Não informado"));
        addRow(card, "Conta", firstField(item, "account", "conta", "Não informado"));
        addRow(card, "Benefício", firstField(item, "numeroBeneficio", "beneficio", "Não informado"));
        addRow(card, "Valor", formatMoney(decimal(firstField(item, "valor", "amount", "value", "0"))));
        addRow(card, "Data", firstField(item, "dataPagamento", "data", "Não informado"));
        result.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
    }

    private void addRow(LinearLayout parent, String label, String value) {
        parent.addView(text(label + ": " + (value.isEmpty() ? "Não informado" : value), 13, Color.rgb(219, 234, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(27), 0, 2));
    }
}
