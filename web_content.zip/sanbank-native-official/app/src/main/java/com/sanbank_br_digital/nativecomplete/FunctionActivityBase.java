package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Componentes visuais compartilhados pelas novas telas do menu Mais. */
public abstract class FunctionActivityBase extends NativeModuleActivity {
    protected LinearLayout page;
    protected boolean suppressFunctionBack;

    protected LinearLayout beginFunctionPage(String title, String subtitle) {
        resetRoot();
        root.setBackground(gradient(Color.rgb(5, 20, 36), Color.rgb(8, 38, 58), Color.rgb(3, 14, 27), 0));
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(15), dp(16), dp(30));
        addDashboardStyleHeader(page, !suppressFunctionBack);
        LinearLayout heading = surfaceCard();
        heading.addView(text("SANBANK BR DIGITAL  ·  ÁREA SEGURA", 9, TEAL, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(18), 0, 4));
        heading.addView(text(title, 22, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, subtitle == null || subtitle.isEmpty() ? 0 : 5));
        if (subtitle != null && !subtitle.isEmpty()) heading.addView(text(subtitle, 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        page.addView(heading, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return page;
    }

    protected LinearLayout surfaceCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setBackground(rounded(Color.argb(238, 8, 27, 45), Color.argb(92, 45, 212, 191), 22));
        card.setElevation(dp(2));
        return card;
    }

    protected void addCard(LinearLayout card, int bottom) {
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, bottom));
    }

    protected EditText functionInput(String hint) {
        return textInput(hint);
    }

    protected void addBackButton() {
        Button back = secondaryButton("Voltar");
        page.addView(back, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 0));
        back.setOnClickListener(v -> finish());
    }

    protected TextView statusText(String initial) {
        TextView status = text(initial, 12, MUTED, false);
        status.setPadding(dp(12), dp(10), dp(12), dp(10));
        status.setBackground(rounded(Color.argb(214, 8, 34, 51), Color.argb(84, 45, 212, 191), 17));
        page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        return status;
    }

    protected Button menuAction(String label, String description, Class<? extends android.app.Activity> target) {
        LinearLayout card = surfaceCard();
        card.setOrientation(LinearLayout.HORIZONTAL);
        Button action = actionButton(label);
        action.setGravity(Gravity.CENTER);
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(dp(12), 0, dp(4), 0);
        copy.addView(text(label, 15, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(27), 0, 3));
        copy.addView(text(description, 11, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        card.removeAllViews();
        card.addView(action, new LinearLayout.LayoutParams(dp(116), dp(70)));
        card.addView(copy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        action.setOnClickListener(v -> launchModule(target));
        page.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 9));
        return action;
    }
}
