package com.sanbank_br_digital.app;

public final class DemSentNotificationActivity extends NotificationDetailActivity { }
