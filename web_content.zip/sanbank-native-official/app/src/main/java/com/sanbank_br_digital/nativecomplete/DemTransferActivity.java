package com.sanbank_br_digital.app;

/** Transferência DEM em quatro etapas, com destinatário validado e aprovação. */
public final class DemTransferActivity extends NativeModuleActivity {
    @Override
    protected void onModuleReady() {
        openDemScreen();
    }
}
