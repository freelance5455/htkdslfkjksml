package com.sanbank_br_digital.app;

public final class WarningNotificationActivity extends NotificationDetailActivity { }
