package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONObject;

/** Activity exclusiva para compartilhar limite entre Cheque Especial e Cartão Neo. */
public final class NeoLimitSharingActivity extends NeoCardFunctionActivity {
    private Spinner direction;
    private EditText amount;
    private TextView operationStatus;
    private Button confirm;
    private double cardTotal;
    private double cardUsed;
    private double cardAvailable;
    private double overdraftTotal;
    private double overdraftAvailable;

    @Override
    protected void onModuleReady() {
        beginNeoFunction("Compartilhar limite", "Mova o limite disponível entre o Cheque Especial e o Cartão Neo.");
        LinearLayout form = surfaceCard();
        form.addView(text("Direção do compartilhamento", 13, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 5));
        direction = new Spinner(this);
        String[] options = {"Cheque Especial → Cartão Neo", "Cartão Neo → Cheque Especial"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, options) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(Color.rgb(219, 234, 254)); view.setTextSize(13); view.setPadding(dp(10), 0, dp(10), 0); return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        direction.setAdapter(adapter);
        form.addView(direction, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 10));
        form.addView(text("Valor a compartilhar", 13, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(24), 0, 5));
        amount = functionInput("Ex.: 500,00");
        amount.setSingleLine(true);
        amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        form.addView(amount, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 10));
        operationStatus = text("Carregando os limites disponíveis...", 12, MUTED, false);
        operationStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        operationStatus.setBackground(rounded(Color.argb(220, 8, 34, 51), Color.argb(84, 45, 212, 191), 14));
        form.addView(operationStatus, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 10));
        confirm = primaryButton("Compartilhar limite");
        confirm.setEnabled(false);
        form.addView(confirm, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 0));
        addCard(form, 10);
        addBackButton();
        direction.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { updateStatus(); }
            @Override public void onNothingSelected(AdapterView<?> parent) { updateStatus(); }
        });
        amount.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateStatus(); }
            @Override public void afterTextChanged(android.text.Editable s) { }
        });
        loadNeoCard(value -> {
            cardTotal = neoTotal(value);
            cardUsed = Math.min(cardTotal, neoUsed(value));
            cardAvailable = neoAvailable(value);
            overdraftTotal = overdraftTotalLimit();
            overdraftAvailable = availableOverdraft();
            confirm.setEnabled(!neoBlocked(value));
            updateStatus();
            confirm.setOnClickListener(v -> submit());
        });
    }

    private void updateStatus() {
        if (operationStatus == null || direction == null || amount == null) return;
        boolean fromOverdraft = direction.getSelectedItemPosition() == 0;
        double source = fromOverdraft ? overdraftAvailable : cardAvailable;
        double value = decimal(amount.getText().toString());
        double targetAfter = (fromOverdraft ? cardTotal : overdraftTotal) + value;
        operationStatus.setText("Disponível para compartilhar: " + formatMoney(source) + "\nLimite total do destino após a operação: " + formatMoney(targetAfter));
        if (value > source && value > 0) amount.setError("O valor não pode ultrapassar " + formatMoney(source));
    }

    private void submit() {
        if (card == null) return;
        if (neoBlocked(card)) {
            operationStatus.setText("O compartilhamento está indisponível com o Cartão Neo bloqueado.");
            return;
        }
        boolean fromOverdraft = direction.getSelectedItemPosition() == 0;
        double source = fromOverdraft ? overdraftAvailable : cardAvailable;
        double value = decimal(amount.getText().toString());
        if (value <= 0 || value > source) {
            amount.setError("Informe um valor entre R$ 0,01 e " + formatMoney(source));
            return;
        }
        submitNativeLimitSharing(card, fromOverdraft, value, null, operationStatus, confirm);
    }

    @Override
    protected void onNativeNeoCardMutationComplete() {
        finish();
    }
}
