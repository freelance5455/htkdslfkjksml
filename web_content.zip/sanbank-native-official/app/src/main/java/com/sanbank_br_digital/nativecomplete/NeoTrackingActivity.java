package com.sanbank_br_digital.app;

import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

/** Activity exclusiva para rastrear a entrega do Cartão Neo. */
public final class NeoTrackingActivity extends NeoCardFunctionActivity {
    @Override
    protected void onModuleReady() {
        beginNeoFunction("Rastreamento do cartão", "Consulte o código e o status de entrega do Cartão Neo.");
        LinearLayout tracking = surfaceCard();
        addCard(tracking, 10);
        Button refresh = secondaryButton("Atualizar rastreamento");
        page.addView(refresh, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 0, 9));
        addBackButton();
        refresh.setOnClickListener(v -> loadNeoCard(this::renderTracking));
        loadNeoCard(this::renderTracking);
        this.trackingCard = tracking;
    }

    private LinearLayout trackingCard;

    private void renderTracking(org.json.JSONObject value) {
        if (trackingCard == null) return;
        trackingCard.removeAllViews();
        String code = firstField(value, "tracking_code", "codigo_rastreio", "tracking");
        if (code.isEmpty()) code = "Não informado";
        String trackingStatus = firstField(value, "tracking_status", "status_rastreio", "delivery_status", "Postado");
        trackingCard.addView(text("Rastreamento do Cartão Neo", 16, Color.rgb(96, 165, 250), true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 7));
        trackingCard.addView(text("Código de rastreio", 11, MUTED, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(21), 0, 2));
        trackingCard.addView(text(code, 20, TEXT, true), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(32), 0, 9));
        trackingCard.addView(text("Status: " + trackingStatus, 13, Color.rgb(191, 219, 254), false), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(25), 0, 4));
        trackingCard.addView(text("Data de envio: " + firstField(value, "shipped_at", "data_envio", "sent_at", "Não informada") + "\nPrevisão: " + firstField(value, "estimated_delivery", "previsao_entrega", "delivery_date", "Não informada"), 12, MUTED, false), lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0));
        cardStatus.setText("Rastreamento atualizado.");
    }
}
