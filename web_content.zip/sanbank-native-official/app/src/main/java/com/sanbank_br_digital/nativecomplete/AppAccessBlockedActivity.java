package com.sanbank_br_digital.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

/** Tela de bloqueio do aplicativo; mantém disponível o atendimento e aguarda liberação administrativa. */
public final class AppAccessBlockedActivity extends NativeBaseActivity {
    private final Handler accessHandler = new Handler(Looper.getMainLooper());
    private TextView status;
    private Button supportButton;
    private String blockId = "";
    private boolean checking;

    private final Runnable unlockPoller = new Runnable() {
        @Override public void run() {
            if (!isFinishing()) {
                checkAccess(false);
                accessHandler.postDelayed(this, 15000L);
            }
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (!restoreSavedSession()) {
            startActivity(new Intent(this, LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            finish();
            return;
        }
        blockId = getIntent() == null ? "" : getIntent().getStringExtra("block_id");
        if (blockId == null) blockId = "";
        renderBlockedScreen();
        checkAccess(true);
    }

    private void renderBlockedScreen() {
        resetRoot();
        root.setBackground(gradient(Color.rgb(45, 8, 23), Color.rgb(22, 10, 28), Color.rgb(3, 7, 18), 0));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(28));
        page.addView(roundedSanbankLogo(), new LinearLayout.LayoutParams(dp(92), dp(72)));
        TextView heading = text("Acesso temporariamente bloqueado", 22, TEXT, true);
        heading.setGravity(Gravity.CENTER);
        page.addView(heading, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 15));
        TextView notice = text("Por causa de movimentações suspeitas ou de um componente estranho, bloqueamos seu acesso. Entre em contato com o suporte pelo botão abaixo.", 15, Color.rgb(254, 226, 226), false);
        notice.setGravity(Gravity.CENTER);
        notice.setLineSpacing(dp(3), 1.0f);
        page.addView(notice, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 14));
        TextView account = text("Conta: " + field(currentUser, "account", "--"), 13, MUTED, true);
        account.setGravity(Gravity.CENTER);
        page.addView(account, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(28), 0, 10));
        status = text("Aguardando confirmação do bloqueio...", 12, MUTED, false);
        status.setGravity(Gravity.CENTER);
        page.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 12));
        supportButton = primaryButton("Falar com o suporte");
        page.addView(supportButton, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 0, 10));
        Button check = secondaryButton("Verificar desbloqueio");
        page.addView(check, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), 0, 8));
        TextView footer = text("O acesso será liberado após o desbloqueio pelo administrador. O suporte continua disponível nesta tela.", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        page.addView(footer, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 8));
        scroll.addView(page);
        root.addView(scroll, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        supportButton.setOnClickListener(v -> sendLockNoticeAndOpenChat());
        check.setOnClickListener(v -> checkAccess(true));
    }

    private void checkAccess(boolean showProgress) {
        if (checking || currentUser == null || sessionToken.isEmpty()) return;
        checking = true;
        if (showProgress && status != null) status.setText("Verificando o status do acesso...");
        rpc("sanbank_check_my_app_access", new JSONObject(), new RpcCallback() {
            @Override public void success(Object result) {
                runOnUiThread(() -> {
                    checking = false;
                    JSONObject state = firstObject(result);
                    if (state == null) {
                        if (status != null) status.setText("Não foi possível confirmar o status. Tentaremos novamente.");
                        return;
                    }
                    prefs().edit().putLong("app_access_last_check_ms", System.currentTimeMillis())
                            .putString("app_access_last_check_account", field(currentUser, "account", ""))
                            .apply();
                    if (!state.optBoolean("blocked", false)) {
                        openLoginAfterUnlock();
                        return;
                    }
                    String received = state.optString("block_id", "");
                    if (!received.isEmpty()) blockId = received;
                    if (status != null) status.setText("Acesso bloqueado. Aguardando análise e liberação do administrador.");
                });
            }
            @Override public void failure(String error) {
                runOnUiThread(() -> {
                    checking = false;
                    if (status != null) status.setText("Não foi possível consultar o status agora. O acesso permanece protegido; tente novamente.");
                });
            }
        });
    }

    private void sendLockNoticeAndOpenChat() {
        if (currentUser == null) return;
        String account = field(currentUser, "account", "");
        if (!account.matches("\\d{6}")) {
            status.setText("Não foi possível identificar a conta para abrir o atendimento.");
            return;
        }
        String stableBlockId = blockId.isEmpty() ? "pendente" : blockId;
        String sentKey = "app_access_support_sent_" + account;
        if (stableBlockId.equals(prefs().getString(sentKey, ""))) {
            openLockedSupport();
            return;
        }
        supportButton.setEnabled(false);
        status.setText("Enviando automaticamente sua solicitação ao suporte...");
        JSONObject payload = new JSONObject();
        try {
            payload.put("id", "APP-LOCK-" + account + "-" + stableBlockId);
            payload.put("account", account);
            payload.put("sender_role", "user");
            payload.put("role", "user");
            payload.put("sender", "user");
            payload.put("sender_name", field(currentUser, "name", "Cliente"));
            payload.put("message", "Olá, meu acesso ao SANBANK BR DIGITAL foi bloqueado por movimentações suspeitas ou por um componente estranho. Solicito análise e desbloqueio. Conta: " + account + ".");
            payload.put("created_at", isoNow());
            payload.put("status", "open");
        } catch (Exception ignored) { }
        apiUpsert("chat_suporte", payload, new RpcCallback() {
            @Override public void success(Object result) {
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    prefs().edit().putString(sentKey, stableBlockId).apply();
                    supportButton.setEnabled(true);
                    status.setText("Solicitação enviada. O acesso continua bloqueado até a liberação do administrador.");
                    openLockedSupport();
                });
            }
            @Override public void failure(String error) {
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    supportButton.setEnabled(true);
                    status.setText("Não foi possível enviar agora. Toque novamente para tentar; a mensagem não será repetida se já tiver sido registrada.");
                });
            }
        });
    }

    private void openLockedSupport() {
        Intent intent = new Intent(this, SupportActivity.class);
        intent.putExtra("app_access_locked_support", true);
        startActivity(intent);
    }

    private void openLoginAfterUnlock() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override protected void onResume() {
        super.onResume();
        accessHandler.removeCallbacks(unlockPoller);
        accessHandler.postDelayed(unlockPoller, 15000L);
    }

    @Override protected void onPause() {
        accessHandler.removeCallbacks(unlockPoller);
        super.onPause();
    }

    @Override protected void onDestroy() {
        accessHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
