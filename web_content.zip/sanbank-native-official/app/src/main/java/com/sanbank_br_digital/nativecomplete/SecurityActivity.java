package com.sanbank_br_digital.app;

/** Segurança da conta e bloqueio/desbloqueio protegido do Cartão Neo. */
public final class SecurityActivity extends NativeModuleActivity {
    @Override
    protected void onModuleReady() {
        openSecurityModule();
    }
}
