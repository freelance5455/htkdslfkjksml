(function () {
  'use strict';
  var started = Date.now();
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var glow = document.querySelector('.glow');
  if (!glow || reduceMotion) return;
  function pulse() {
    var elapsed = (Date.now() - started) / 1000;
    var x = 50 + Math.sin(elapsed / 4.8) * 8;
    var y = 18 + Math.cos(elapsed / 6.4) * 5;
    glow.style.background = 'radial-gradient(circle at ' + x + '% ' + y + '%, rgba(14,165,233,.13), transparent 31%), radial-gradient(circle at 90% 90%, rgba(236,72,153,.10), transparent 34%)';
    window.requestAnimationFrame(pulse);
  }
  window.requestAnimationFrame(pulse);
})();
