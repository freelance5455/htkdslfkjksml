# SANBANK BR DIGITAL — Migração nativa

Este diretório inicia a migração 100% nativa do SANBANK BR DIGITAL sem substituir o APK oficial que já funciona.

## Status da fase 5 / auditoria final estática

- Activity nativa em Java, sem WebView para login, dashboard e módulos migrados.
- Transferência DEM nativa em 4 etapas: valor, destinatário validado, revisão e envio para aprovação.
- Pix à vista e parcelado, Cartão Neo, segurança e extrato PDF preservados.
- Comprovantes DEM e Pix com abrir/compartilhar PDF.
- Notificações individuais nativas com canais Android e marcação como lida.
- Sincronização de notificações e status da aba `pendentes` enquanto o app está aberto.
- Sincronização em segundo plano por `AlarmManager`, inclusive após inicialização do aparelho.
- Avisos nativos de novas versões publicados para o pacote instalado.
- Suporte nativo direto com atendente humano pela aba `chat_suporte`, sem menu de assuntos.
- Quando uma operação muda de status, o aplicativo gera um aviso nativo deduplicado.
- RPCs públicos de notificações, suporte e atualizações responderam HTTP 200 no smoke test.
- Compilação, assinatura e manifesto auditados.

## Validação pendente

A ponte ADB e um aparelho Android físico não estavam disponíveis no ambiente da auditoria. Câmera, notificações em segundo plano, reinicialização, DownloadManager, login real, gravação de pendentes e abertura/compartilhamento de PDF ainda precisam ser testados em aparelho real antes de substituir o cliente oficial.

O APK oficial continua sendo a versão de produção durante a migração. A prévia nativa não deve ser publicada como substituta até que todos os módulos estejam migrados e testados.
