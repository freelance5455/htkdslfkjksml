PROJETO SOLAR — PROJETO ANDROID NATIVO (FONTE)

Este pacote é um projeto Android Gradle que inclui a interface web local em:
app/src/main/assets/index.html

IDENTIFICADOR: com.projeto.solar
NOME: Projeto Solar

IMPORTANTE:
- Este ZIP contém os arquivos-fonte do projeto Android, NÃO um APK compilado.
- Não inclui gradle-wrapper.jar nem SDK Android; o ambiente de compilação precisa obter/configurar esses componentes.
- Abra a pasta do projeto em um ambiente Android/Gradle que aceite projetos Android nativos.
- O aplicativo carrega o HTML de dentro do APK e não precisa de hospedagem para abrir a interface.
- O armazenamento local do WebView fica no aparelho; desinstalar ou limpar os dados do app pode apagar os dados.
- A interface atual usa estimativas de dimensionamento. Cabos e proteções devem ser validados por profissional qualificado.
