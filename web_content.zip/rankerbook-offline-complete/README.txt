RANKERBOOK OFFLINE LR MANAGER — HTML TO APK PACKAGE

CONTENTS
- www/index.html: complete app interface
- www/assets/style.css: responsive mobile styling
- www/assets/app.js: signup/login/profile/LR CRUD/local storage/backup logic
- www/data/stations.json: editable sample station code/name list
- www/manifest.json: app metadata for compatible wrappers
- config.xml: Cordova metadata (optional for converters that accept it)

FOR ONLINE HTML-TO-APK CONVERTERS
1. Upload the entire www folder if the converter accepts a website folder/project.
2. If it accepts only a single HTML file, upload index.html only if it can also include the assets and data folders. Otherwise, first put the contents of www into one ZIP and select that ZIP as the website/project input.
3. Set the start page / entry page to index.html.
4. Enable local/offline assets and WebView DOM storage/localStorage. Do not set a remote website URL as the start page.
5. Use app name: RANKERBOOK LR Manager.

IMPORTANT OFFLINE BEHAVIOUR
- This is a fully local, standalone HTML app; it does not call WordPress or your website's PHP.
- Accounts and LR records are stored in browser/WebView localStorage on that device. Different phones do not share records.
- Passwords are stored as salted PBKDF2-SHA256 hashes, not plaintext. Use a modern Android WebView that supports Web Crypto.
- Export JSON backup regularly. Clearing app data or uninstalling can remove local data.
- The station list is a small sample, not a complete official Indian Railways database. Add verified stations to www/data/stations.json. Users can still type unlisted station names manually.
- Export/Import backup currently covers LR entries for the signed-in account. Do not upload this private backup to a public website.

FEATURES
- HRMS ID/name/mobile/password signup
- HRMS ID/password login
- Profile option at top
- LR entries list and empty state
- Add multiple rows, edit, delete, save, go back
- From/To station suggestions, side Up/Down/Both, last drive calendar date
- Password-confirmed account deletion
- JSON backup export/import

For converter troubleshooting, check that the final APK has JavaScript enabled, DOM storage enabled, and the app starts from www/index.html. The package does not include a compiled APK.
