# Naxe AI — Document Chatbot
Upload PDF/DOCX/XLSX/PPTX/TXT/MD/CSV/JSON/XML/HTML, ask questions, get answers with clickable citations.

## Run (computer, or Termux on Android)
1. Install Node.js 18+.  2. `npm install`
3. `cp .env.example .env` and put your key in `.env` (never commit it; never put it in frontend code).
4. `npm start` → open http://localhost:3000

## Test
Upload a PDF, ask "What does page 2 say about …?". Tap a [S1] chip to see the exact passage used.

## Deploy (phone-friendly)
Push to a private GitHub repo (`.env` is git-ignored) → create a Web Service on Render.com → build `npm install`, start `npm start` → add `ANTHROPIC_API_KEY` under Environment.

## Privacy & limits
- Relevant document passages are sent to Anthropic's API to generate answers.
- Files stay in server memory only (never saved to disk), cleared after 2h idle or on restart.
- Not included: OCR (scanned PDFs/images), ZIP files, image uploads. Keyword (BM25) retrieval, not embeddings.
- Costs: Claude API usage per question + hosting (free tiers sleep/limit memory).
