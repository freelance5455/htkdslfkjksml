const path = require('path');
const EXT = ['pdf','docx','txt','md','csv','xlsx','xls','pptx','json','xml','html'];
const strip = h => h.replace(/<(script|style)[\s\S]*?<\/\1>/gi,' ').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();

async function extract(name, buf) {
  const ext = path.extname(name).slice(1).toLowerCase();
  if (!EXT.includes(ext)) throw new Error(`Unsupported file type ".${ext}". Supported: ${EXT.join(', ')}`);
  let segs = [];
  try {
    if (ext === 'pdf') {
      const pdf = require('pdf-parse/lib/pdf-parse.js');
      await pdf(buf, { pagerender: async p => {
        const t = await p.getTextContent();
        segs.push({ text: t.items.map(i => i.str).join(' '), loc: 'page ' + (segs.length + 1) });
        return '';
      }});
    } else if (ext === 'docx') {
      const r = await require('mammoth').extractRawText({ buffer: buf });
      segs = [{ text: r.value, loc: 'Word document' }];
    } else if (ext === 'xlsx' || ext === 'xls') {
      const X = require('xlsx'); const wb = X.read(buf, { type: 'buffer' });
      segs = wb.SheetNames.map(n => ({ text: X.utils.sheet_to_csv(wb.Sheets[n]), loc: 'sheet "' + n + '"' }));
    } else if (ext === 'pptx') {
      const zip = await require('jszip').loadAsync(buf);
      const slides = Object.keys(zip.files).filter(f => /^ppt\/slides\/slide\d+\.xml$/.test(f))
        .sort((a, b) => parseInt(a.match(/\d+/)) - parseInt(b.match(/\d+/)));
      for (const f of slides) {
        const xml = await zip.files[f].async('string');
        const text = [...xml.matchAll(/<a:t>([^<]*)<\/a:t>/g)].map(m => m[1]).join(' ');
        segs.push({ text, loc: 'slide ' + f.match(/\d+/)[0] });
      }
    } else if (ext === 'html' || ext === 'xml') {
      segs = [{ text: strip(buf.toString('utf8')), loc: ext.toUpperCase() + ' file' }];
    } else {
      segs = [{ text: buf.toString('utf8'), loc: 'text' }];
    }
  } catch (e) {
    if (/password|encrypt/i.test(e.message)) throw new Error('File is encrypted or password-protected.');
    throw new Error('File could not be read (corrupted or invalid): ' + e.message);
  }
  segs = segs.filter(s => s.text && s.text.trim());
  if (!segs.length) throw new Error('No readable text found. It may be a scanned file (OCR is not included in this version).');
  return { format: ext.toUpperCase(), segs };
}
module.exports = { extract, EXT };
