const tok = s => s.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(w => w.length > 1);

function chunk(segs, size = 1200, overlap = 200) {
  const out = [];
  for (const s of segs) {
    const t = s.text.replace(/[ \t]+/g, ' ').trim();
    for (let i = 0; i < t.length; i += size - overlap) {
      out.push({ text: t.slice(i, i + size), loc: s.loc });
      if (i + size >= t.length) break;
    }
  }
  return out;
}

// BM25 keyword search across all docs; boosts "page N"/"slide N" mentions.
function search(docs, query, k = 8) {
  const all = [];
  docs.forEach(d => d.chunks.forEach((c, idx) => all.push({ doc: d, idx, c, toks: tok(c.text) })));
  if (!all.length) return [];
  const q = [...new Set(tok(query))];
  const N = all.length, avg = all.reduce((a, x) => a + x.toks.length, 0) / N || 1;
  const df = {}; q.forEach(w => df[w] = all.filter(x => x.toks.includes(w)).length);
  const want = [...query.matchAll(/\b(page|slide|पृष्ठ)\s*(\d+)/gi)].map(m => m[2]);
  const fileHit = d => query.toLowerCase().includes(d.name.toLowerCase());
  all.forEach(x => {
    let s = 0;
    q.forEach(w => {
      const f = x.toks.filter(t => t === w).length; if (!f) return;
      const idf = Math.log(1 + (N - df[w] + 0.5) / (df[w] + 0.5));
      s += idf * (f * 2.2) / (f + 1.2 * (0.25 + 0.75 * x.toks.length / avg));
    });
    if (want.some(n => x.c.loc === 'page ' + n || x.c.loc === 'slide ' + n)) s += 5;
    if (fileHit(x.doc)) s += 1;
    x.score = s;
  });
  let top = all.filter(x => x.score > 0).sort((a, b) => b.score - a.score).slice(0, k);
  if (!top.length) { // generic request (e.g. "summarize"): sample evenly from each doc
    const per = Math.max(2, Math.floor(k / docs.length));
    docs.forEach(d => {
      const items = all.filter(x => x.doc === d), step = Math.max(1, Math.floor(items.length / per));
      for (let i = 0; i < items.length && top.length < k * 2; i += step) top.push(items[i]);
    });
    top = top.slice(0, k);
  }
  return top;
}
module.exports = { chunk, search };
