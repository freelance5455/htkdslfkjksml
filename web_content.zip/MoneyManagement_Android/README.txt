MONEY MANAGEMENT — Android Studio project
=========================================

This project wraps the previous MoneyFlow v3 HTML app in an Android WebView.
- App display name: Money Management
- Launcher icon: supplied Money Management cover image
- Uses the earlier v3 file; the additional v4 charts are not included.
- Offline HTML app; records use browser localStorage on this device.

Build APK:
1. Install Android Studio on Windows and let it install Android SDK Platform 35.
2. Open this folder (the folder containing settings.gradle) in Android Studio.
3. Wait for Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show a link to the generated APK, normally:
   app/build/outputs/apk/debug/app-debug.apk

Important:
- This folder is Android source code, not a precompiled APK.
- An Android SDK/Gradle build environment was not available in the file-generation environment, so a real APK could not be compiled and tested here.
- This is a local money-tracking app; it does not connect to actual bank, bKash or Nagad accounts.
- Keep backups of financial records.
