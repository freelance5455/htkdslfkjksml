const CACHE='konter-struk-pro-v6-3-auto-ocr';
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['./','./index.html','./manifest.webmanifest']))));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{
 const u=new URL(e.request.url);
 if(e.request.method==='POST' && u.pathname.endsWith('/share-target')){
  e.respondWith((async()=>{const fd=await e.request.formData();const f=fd.get('files');if(f){const db=await new Promise((res,rej)=>{let q=indexedDB.open('konter-share',1);q.onupgradeneeded=()=>q.result.createObjectStore('inbox');q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});await new Promise((res,rej)=>{let tx=db.transaction('inbox','readwrite');tx.objectStore('inbox').put(f,'shared-image');tx.oncomplete=res;tx.onerror=()=>rej(tx.error)});db.close()}return Response.redirect('./?shared=1',303)})());
 } else if(e.request.method==='GET') e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).catch(()=>caches.match('./index.html'))));
});