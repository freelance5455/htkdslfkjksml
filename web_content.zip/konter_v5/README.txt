KONTER STRUK PRO V6.3 - PERBAIKAN PEMETAAN OCR

Berbasis V6.2, mempertahankan fitur sebelumnya.
Perbaikan:
- OCR otomatis berjalan setelah gambar dipilih dan saat gambar diganti.
- Pemetaan label IDPEL, NAMA, TRF/DAYA, NOMINAL, RP TOKEN, dan JML KWH diperketat.
- Mencegah header NAMA KONTER dibaca sebagai nama pemilik meter.
- Mencegah nilai TARIF/DAYA masuk ke NAMA dan NO REF masuk ke TRF/DAYA.
- Mendeteksi pola tarif R1/R2/R3 dengan daya, serta token 20 digit.
- Kolom hasil OCR yang tidak ditemukan dikosongkan, tidak memakai nilai lama atau tebakan.

Catatan pengujian:
JavaScript diperiksa dengan node --check dan arsip ZIP diperiksa integritasnya.
OCR tetap perlu diuji dengan screenshot transaksi asli; kualitas hasil bergantung pada gambar dan teks sumber.
