(() => {
  if (window.__vennNeuralBackground) return;
  window.__vennNeuralBackground = true;

  const canvas = document.createElement('canvas');
  canvas.className = 'neural-background';
  canvas.setAttribute('aria-hidden', 'true');
  document.body.prepend(canvas);

  const context = canvas.getContext('2d');
  if (!context) {
    canvas.remove();
    return;
  }

  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  const colors = ['57,213,255', '83,139,255', '175,123,255', '224,86,216'];
  let width = 0;
  let height = 0;
  let scale = 1;
  let particles = [];
  let orbits = [];
  let frameId = 0;
  let lastFrame = 0;
  let mobile = false;
  let resizeTimer = 0;

  function makeAmbientParticle() {
    const colorRoll = Math.random();
    const colorIndex = colorRoll < 0.35 ? 0 : colorRoll < 0.65 ? 1 : colorRoll < 0.93 ? 2 : 3;
    return {
      kind: 'ambient',
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 9,
      vy: (Math.random() - 0.5) * 9,
      radius: 0.7 + Math.random() * (mobile ? 0.7 : 1.1),
      phase: Math.random() * Math.PI * 2,
      color: colors[colorIndex]
    };
  }

  function makeOrbitalParticle(index) {
    const orbitIndex = index % orbits.length;
    return {
      kind: 'orbital',
      orbitIndex,
      angle: Math.random() * Math.PI * 2,
      speed: (index % 2 ? -1 : 1) * (0.08 + Math.random() * 0.08),
      radius: 1 + Math.random() * 0.7,
      phase: Math.random() * Math.PI * 2,
      color: orbits[orbitIndex].color
    };
  }

  function setOrbitalPosition(particle) {
    const orbit = orbits[particle.orbitIndex];
    particle.x = orbit.x + Math.cos(particle.angle) * orbit.rx;
    particle.y = orbit.y + Math.sin(particle.angle) * orbit.ry;
  }

  function resize() {
    width = window.innerWidth;
    height = window.innerHeight;
    mobile = Math.min(width, height) < 640;
    scale = Math.min(window.devicePixelRatio || 1, 1.5);

    canvas.width = Math.round(width * scale);
    canvas.height = Math.round(height * scale);
    context.setTransform(scale, 0, 0, scale, 0, 0);

    const shortSide = Math.min(width, height);
    const centerX = width * 0.5;
    const centerY = height * 0.51;
    orbits = [
      {
        x: centerX, y: centerY,
        rx: Math.min(width * 0.46, shortSide * 0.62),
        ry: Math.min(height * 0.42, shortSide * 0.48),
        color: colors[0]
      },
      {
        x: centerX, y: centerY,
        rx: Math.min(width * 0.34, shortSide * 0.47),
        ry: Math.min(height * 0.31, shortSide * 0.36),
        color: colors[2]
      },
      {
        x: centerX, y: centerY,
        rx: Math.min(width * 0.22, shortSide * 0.31),
        ry: Math.min(height * 0.2, shortSide * 0.24),
        color: colors[1]
      }
    ];

    const area = width * height;
    const ambientCount = Math.min(
      mobile ? 24 : 52,
      Math.max(mobile ? 12 : 24, Math.round(area / (mobile ? 15000 : 22000)))
    );
    const orbitalCount = mobile ? 4 : 8;
    particles = Array.from({ length: ambientCount }, makeAmbientParticle);
    for (let i = 0; i < orbitalCount; i++) {
      const particle = makeOrbitalParticle(i);
      setOrbitalPosition(particle);
      particles.push(particle);
    }

    draw(0);
    lastFrame = 0;
    start();
  }

  function update(delta) {
    for (const particle of particles) {
      if (particle.kind === 'orbital') {
        particle.angle += particle.speed * delta;
        setOrbitalPosition(particle);
        continue;
      }

      particle.x += particle.vx * delta;
      particle.y += particle.vy * delta;
      if (particle.x < -8) particle.x = width + 8;
      if (particle.x > width + 8) particle.x = -8;
      if (particle.y < -8) particle.y = height + 8;
      if (particle.y > height + 8) particle.y = -8;
    }
  }

  function drawConnections() {
    const maxDistance = mobile ? 88 : 132;
    const maxDistanceSquared = maxDistance * maxDistance;
    context.lineWidth = 0.7;

    for (let i = 0; i < particles.length; i++) {
      const first = particles[i];
      for (let j = i + 1; j < particles.length; j++) {
        const second = particles[j];
        const dx = first.x - second.x;
        const dy = first.y - second.y;
        const distanceSquared = dx * dx + dy * dy;
        if (distanceSquared >= maxDistanceSquared) continue;

        const alpha = (1 - Math.sqrt(distanceSquared) / maxDistance) * 0.16;
        context.strokeStyle = `rgba(${first.color},${alpha})`;
        context.beginPath();
        context.moveTo(first.x, first.y);
        context.lineTo(second.x, second.y);
        context.stroke();
      }
    }
  }

  function draw(time) {
    context.clearRect(0, 0, width, height);

    for (const orbit of orbits) {
      context.beginPath();
      context.ellipse(orbit.x, orbit.y, orbit.rx, orbit.ry, 0, 0, Math.PI * 2);
      context.strokeStyle = `rgba(${orbit.color},${mobile ? 0.04 : 0.055})`;
      context.lineWidth = 0.8;
      context.stroke();

      const pulseAngle = time * 0.00008 * (orbit.color === colors[2] ? -1 : 1);
      context.beginPath();
      context.arc(
        orbit.x + Math.cos(pulseAngle) * orbit.rx,
        orbit.y + Math.sin(pulseAngle) * orbit.ry,
        1.6,
        0,
        Math.PI * 2
      );
      context.fillStyle = `rgba(${orbit.color},0.42)`;
      context.fill();
    }

    drawConnections();

    for (const particle of particles) {
      const pulse = 0.7 + Math.sin(time * 0.001 + particle.phase) * 0.3;
      const alpha = particle.kind === 'orbital' ? 0.45 * pulse : 0.3 * pulse;
      const radius = particle.radius * (particle.kind === 'orbital' ? 1 : 0.8 + pulse * 0.2);

      context.beginPath();
      context.arc(particle.x, particle.y, radius * 3, 0, Math.PI * 2);
      context.fillStyle = `rgba(${particle.color},${alpha * 0.18})`;
      context.fill();

      context.beginPath();
      context.arc(particle.x, particle.y, radius, 0, Math.PI * 2);
      context.fillStyle = `rgba(${particle.color},${alpha})`;
      context.fill();
    }
  }

  function animate(time) {
    frameId = window.requestAnimationFrame(animate);
    const interval = mobile ? 1000 / 30 : 1000 / 45;
    if (time - lastFrame < interval) return;

    const delta = lastFrame ? Math.min((time - lastFrame) / 1000, 0.05) : 0;
    lastFrame = time;
    update(delta);
    draw(time);
  }

  function stop() {
    if (!frameId) return;
    window.cancelAnimationFrame(frameId);
    frameId = 0;
  }

  function start() {
    if (motionPreference.matches || document.hidden || frameId) return;
    frameId = window.requestAnimationFrame(animate);
  }

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      stop();
    } else {
      lastFrame = 0;
      start();
    }
  });

  motionPreference.addEventListener('change', () => {
    stop();
    if (!motionPreference.matches) {
      lastFrame = 0;
      start();
    }
  });

  window.addEventListener('resize', () => {
    window.clearTimeout(resizeTimer);
    resizeTimer = window.setTimeout(resize, 120);
  }, { passive: true });

  resize();
})();
