FunPlay Voice Rooms prototype

Upload this ZIP to your HTML-to-app builder.
Included prototype screens: Home, Voice Rooms, room detail/seats, Games, Ludo entry screen, Gifts, Wallet (demo coins), VIP, Profile (mobile field UI).
Important: This is a front-end prototype. Real voice chat, authentication/OTP, multiplayer Ludo, server-side owner/admin controls, gift payments, wallet, and VIP purchase are NOT implemented. Do not use this prototype to accept real payments or personal financial data.
