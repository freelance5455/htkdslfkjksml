// Hash GPT login. Demo only: accounts live in this browser's localStorage.
// For a real app, check passwords on a server.
const $ = id => document.getElementById(id);
const APP_PAGE = 'hash-gpt.html';   // page opened after login
let mode = 'login';

async function hash(text){
  try{
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('hashgpt:' + text));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
  }catch(e){
    let h = 5381; for (const c of 'hashgpt:' + text) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0;
    return 'x' + h.toString(16);
  }
}
const users = () => { try { return JSON.parse(localStorage.getItem('hashgpt_users') || '{}'); } catch(e){ return {}; } };
const saveUsers = u => localStorage.setItem('hashgpt_users', JSON.stringify(u));
function say(t, ok){ $('msg').textContent = t; $('msg').className = 'msg' + (ok ? ' ok' : ''); }

function setMode(m){
  mode = m;
  $('tabLogin').classList.toggle('on', m === 'login');
  $('tabSignup').classList.toggle('on', m === 'signup');
  $('confirmRow').hidden = m === 'login';
  $('submit').textContent = m === 'login' ? 'Log in' : 'Create account';
  $('sub').textContent = m === 'login' ? 'Log in to ask your questions.' : 'Make an account to get started.';
  $('pass').autocomplete = m === 'login' ? 'current-password' : 'new-password';
  say('');
}
$('tabLogin').onclick = () => setMode('login');
$('tabSignup').onclick = () => setMode('signup');
$('show').onclick = () => {
  const hidden = $('pass').type === 'password';
  $('pass').type = hidden ? 'text' : 'password';
  $('show').textContent = hidden ? 'Hide' : 'Show';
};

// Already logged in? Go straight to the app.
try { if (sessionStorage.getItem('hashgpt_session')) location.replace(APP_PAGE); } catch(e){}

$('form').addEventListener('submit', async e => {
  e.preventDefault();
  const name = $('user').value.trim().toLowerCase();
  const pass = $('pass').value;
  if (!name || !pass) return say('Enter your username and password.');
  let db;
  try { db = users(); } catch(e){ return say('Your browser is blocking storage. Open this page in Chrome or Safari.'); }

  if (mode === 'signup'){
    if (name.length < 3) return say('Username must be at least 3 characters.');
    if (pass.length < 6) return say('Password must be at least 6 characters.');
    if (pass !== $('pass2').value) return say('Passwords do not match.');
    if (db[name]) return say('That username is taken. Try another.');
    db[name] = await hash(pass);
    try { saveUsers(db); } catch(e){ return say('Could not save your account.'); }
    say('Account created. Logging you in…', true);
  } else {
    if (!db[name] || db[name] !== await hash(pass)) return say('Wrong username or password.');
    say('Welcome back!', true);
  }
  try { sessionStorage.setItem('hashgpt_session', name); } catch(e){}
  setTimeout(() => location.href = APP_PAGE, 400);
});
