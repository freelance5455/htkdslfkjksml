# V62 — Excel WebView file-input + in-app picker fix

V61 still preferred the `AndroidDPM.pickImportFile()` bridge, which could produce
the misleading “Android file picker is unavailable in this app build” message
when the bridge was not available.

V62 changes the Excel **Choose File** button to trigger the normal HTML
`<input type="file">` directly from the user's tap.

On Android, `MainActivity.onShowFileChooser()` now routes that HTML request to
the app's in-app Downloads picker. Selecting a file returns the content URI to
WebView, where the existing JavaScript Excel/CSV parser processes it.

The explicit `AndroidDPM` picker remains available as a fallback for other
native flows.

The Excel template download continues to use Android Downloads/MediaStore.

Version 2.28 / versionCode 32.
