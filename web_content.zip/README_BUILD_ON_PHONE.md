# Build JARVIS Offline AI APK from your phone

1. Download and extract `JARVIS_Offline_AI_Source.zip`.
2. Open `https://github.com/new` and create a private repository.
3. Upload all files inside the extracted folder, including the hidden `.github` folder. Do not upload only the outer folder.
4. In the repository, open **Actions**. If asked, enable workflows.
5. Select **Build JARVIS APK**, tap **Run workflow**, then wait for the workflow to finish.
6. Open the successful workflow run and download the `JARVIS-Assistant-APK` artifact.
7. Extract the artifact and install `app-debug.apk`. Approve Android's install-from-this-source prompt if it appears.
8. Open JARVIS → menu → **AI Settings** → **Download model**. This one-time download is about 586 MB.
9. Tap **Load model** and wait for the ready message.
10. Test a general question. Then turn on airplane mode and test another question. If it works, the language model is running locally.

If the build fails, open the failed workflow, expand the red error step, and share the error text. The source has not been compiled on the authoring machine, so the CI build result matters.
