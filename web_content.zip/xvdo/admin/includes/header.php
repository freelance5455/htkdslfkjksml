<?php
/**
 * XVDO - Admin Panel Header
 */
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

requireAdminLogin();
$admin = getCurrentAdmin();
$siteName = getSetting('site_name', 'MTX');
$flash = getFlash();
$currentScript = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' - ' : '' ?>MTX Admin Portal</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        darkBg: '#090C12',
                        darkSidebar: '#0E131E',
                        darkCard: '#151B27',
                        darkCardHover: '#1C2333',
                        darkBorder: '#232C3D',
                        accentBlue: '#3B82F6',
                        accentPurple: '#8B5CF6'
                    }
                }
            }
        }
    </script>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/custom.css">
</head>
<body class="bg-[#090C12] text-slate-100 flex min-h-screen">

    <!-- Admin Sidebar Navigation -->
    <aside class="w-64 bg-[#0E131E] border-r border-[#232C3D] flex flex-col justify-between flex-shrink-0 min-h-screen hidden md:flex">
        <div>
            <!-- Brand -->
            <div class="h-16 px-6 flex items-center gap-3 border-b border-[#232C3D]">
                <div class="w-9 h-9 rounded-xl xvdo-btn-gradient flex items-center justify-center text-white font-black text-sm shadow">
                    <i class="fa-solid fa-play ml-0.5"></i>
                </div>
                <div>
                    <span class="text-xl font-black text-white tracking-wider">
                        M<span class="text-purple-400">TX</span>
                    </span>
                    <span class="text-[10px] font-bold uppercase tracking-widest text-slate-500 block">Admin Portal</span>
                </div>
            </div>

            <!-- Nav Links -->
            <nav class="p-4 space-y-1.5 text-xs font-semibold">
                <a href="dashboard.php" class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition <?= $currentScript === 'dashboard.php' ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-white hover:bg-slate-800/60' ?>">
                    <i class="fa-solid fa-chart-pie w-4 text-center"></i>
                    <span>Overview & Stats</span>
                </a>

                <div class="pt-3 pb-1 px-3 text-[10px] uppercase font-bold text-slate-500 tracking-wider">Content Management</div>

                <a href="videos.php" class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition <?= in_array($currentScript, ['videos.php', 'edit-video.php']) ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-white hover:bg-slate-800/60' ?>">
                    <i class="fa-solid fa-video w-4 text-center"></i>
                    <span>All Videos</span>
                </a>

                <a href="upload.php" class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition <?= $currentScript === 'upload.php' ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-white hover:bg-slate-800/60' ?>">
                    <i class="fa-solid fa-cloud-arrow-up w-4 text-center"></i>
                    <span>Upload New Video</span>
                </a>

                <a href="categories.php" class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition <?= $currentScript === 'categories.php' ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-white hover:bg-slate-800/60' ?>">
                    <i class="fa-solid fa-layer-group w-4 text-center"></i>
                    <span>Categories</span>
                </a>

                <div class="pt-3 pb-1 px-3 text-[10px] uppercase font-bold text-slate-500 tracking-wider">Administration</div>

                <a href="users.php" class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition <?= $currentScript === 'users.php' ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-white hover:bg-slate-800/60' ?>">
                    <i class="fa-solid fa-users-gear w-4 text-center"></i>
                    <span>User Accounts</span>
                </a>

                <a href="settings.php" class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition <?= $currentScript === 'settings.php' ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-white hover:bg-slate-800/60' ?>">
                    <i class="fa-solid fa-sliders w-4 text-center"></i>
                    <span>Portal Settings</span>
                </a>
            </nav>
        </div>

        <!-- Admin Profile Bottom -->
        <div class="p-4 border-t border-[#232C3D] space-y-3">
            <div class="flex items-center gap-3 px-2">
                <div class="w-8 h-8 rounded-lg bg-purple-600 text-white font-bold flex items-center justify-center text-xs">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
                <div class="overflow-hidden">
                    <p class="text-xs font-bold text-white truncate"><?= e($admin['full_name']) ?></p>
                    <p class="text-[10px] text-slate-400 truncate"><?= e($admin['email']) ?></p>
                </div>
            </div>
            <div class="flex items-center gap-2 pt-1">
                <a href="../dashboard.php" target="_blank" class="flex-1 py-1.5 text-center rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition">
                    <i class="fa-solid fa-arrow-up-right-from-square mr-1 text-[10px]"></i> View Site
                </a>
                <a href="logout.php" class="py-1.5 px-3 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-[11px] font-medium transition" title="Sign Out">
                    <i class="fa-solid fa-power-off"></i>
                </a>
            </div>
        </div>
    </aside>

    <!-- Content Area -->
    <div class="flex-1 flex flex-col min-w-0 overflow-y-auto">
        <!-- Top Header Bar -->
        <header class="h-16 bg-[#0E131E] border-b border-[#232C3D] px-4 sm:px-8 flex items-center justify-between sticky top-0 z-40">
            <div class="flex items-center gap-3">
                <!-- Mobile Menu Button -->
                <button onclick="document.getElementById('mobileAdminNav').classList.toggle('hidden')" class="md:hidden text-slate-400 hover:text-white p-2">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <h2 class="text-sm sm:text-base font-bold text-white"><?= isset($pageTitle) ? e($pageTitle) : 'Admin Panel' ?></h2>
            </div>
            <div class="flex items-center gap-3">
                <a href="upload.php" class="px-3.5 py-1.5 rounded-xl text-xs font-bold text-white xvdo-btn-gradient shadow flex items-center gap-1.5">
                    <i class="fa-solid fa-plus text-[10px]"></i>
                    <span class="hidden sm:inline">Add Video</span>
                </a>
                <a href="../index.php" target="_blank" class="text-xs font-semibold text-slate-400 hover:text-white px-2 py-1">
                    <i class="fa-solid fa-globe mr-1"></i> Public Site
                </a>
            </div>
        </header>

        <!-- Mobile Drawer Menu -->
        <div id="mobileAdminNav" class="hidden md:hidden bg-[#0E131E] border-b border-[#232C3D] p-4 space-y-2 text-xs font-medium">
            <a href="dashboard.php" class="block px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-800">Overview & Stats</a>
            <a href="videos.php" class="block px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-800">All Videos</a>
            <a href="upload.php" class="block px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-800">Upload Video</a>
            <a href="categories.php" class="block px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-800">Categories</a>
            <a href="users.php" class="block px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-800">User Accounts</a>
            <a href="settings.php" class="block px-3 py-2 rounded-lg text-slate-300 hover:bg-slate-800">Settings</a>
            <a href="logout.php" class="block px-3 py-2 rounded-lg text-red-400 hover:bg-red-500/10">Sign Out</a>
        </div>

        <!-- Flash Notice -->
        <?php if ($flash): ?>
            <div class="px-4 sm:px-8 pt-4">
                <?php
                $bgColor = match($flash['type']) {
                    'success' => 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300',
                    'danger' => 'bg-rose-500/15 border-rose-500/40 text-rose-300',
                    'warning' => 'bg-amber-500/15 border-amber-500/40 text-amber-300',
                    default => 'bg-blue-500/15 border-blue-500/40 text-blue-300'
                };
                ?>
                <div class="flex items-center gap-3 p-3.5 rounded-xl border <?= $bgColor ?> text-xs font-medium">
                    <i class="fa-solid fa-circle-info"></i>
                    <span><?= e($flash['message']) ?></span>
                </div>
            </div>
        <?php endif; ?>

        <!-- Main Admin Body -->
        <main class="p-4 sm:p-8 flex-grow">
