<?php
/**
 * XVDO - Admin Panel Footer
 */
?>
        </main>

        <!-- Admin Footer -->
        <footer class="h-14 border-t border-[#232C3D] px-4 sm:px-8 flex items-center justify-between text-xs text-slate-500 bg-[#0E131E]">
            <div>
                XVDO Streaming Administrator &bull; PHP <?= PHP_VERSION ?> &bull; MySQL PDO
            </div>
            <div>
                System Status: <span class="text-emerald-400 font-semibold"><i class="fa-solid fa-circle text-[8px] mr-1"></i>Operational</span>
            </div>
        </footer>
    </div>
</body>
</html>
