<?php
/**
 * XVDO - Admin Dashboard & Analytics
 */
$pageTitle = 'Overview & Statistics';
require_once __DIR__ . '/includes/header.php';

$totalUsers = 0;
$totalVideos = 0;
$totalViews = 0;
$totalCategories = 0;
$recentVideos = [];
$recentUsers = [];

try {
    $pdo = getDBConnection();

    // 1. Total Registered Users
    $userCountStmt = $pdo->query("SELECT COUNT(*) FROM users");
    $totalUsers = (int)$userCountStmt->fetchColumn();

    // 2. Total Videos
    $videoCountStmt = $pdo->query("SELECT COUNT(*) FROM videos");
    $totalVideos = (int)$videoCountStmt->fetchColumn();

    // 3. Total Video Views
    $viewsSumStmt = $pdo->query("SELECT COALESCE(SUM(views), 0) FROM videos");
    $totalViews = (int)$viewsSumStmt->fetchColumn();

    // 4. Total Categories
    $catCountStmt = $pdo->query("SELECT COUNT(*) FROM categories");
    $totalCategories = (int)$catCountStmt->fetchColumn();

    // 5. Recent 5 Videos
    $recVidStmt = $pdo->query("
        SELECT v.*, c.name AS category_name 
        FROM videos v 
        LEFT JOIN categories c ON v.category_id = c.id 
        ORDER BY v.id DESC LIMIT 5
    ");
    $recentVideos = $recVidStmt->fetchAll();

    // 6. Recent 5 Users
    $recUserStmt = $pdo->query("SELECT id, full_name, email, status, created_at FROM users ORDER BY id DESC LIMIT 5");
    $recentUsers = $recUserStmt->fetchAll();

} catch (Exception $e) {
    error_log("Admin dashboard stats error: " . $e->getMessage());
}
?>

<div class="space-y-8">

    <!-- Top Banner -->
    <div class="bg-gradient-to-r from-[#151B27] via-[#151B27] to-purple-950/30 border border-[#232C3D] rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
        <div>
            <span class="text-xs font-bold uppercase tracking-wider text-purple-400">Control Panel Overview</span>
            <h1 class="text-2xl sm:text-3xl font-black text-white mt-1">Platform Analytics</h1>
            <p class="text-xs text-slate-400 mt-1">Real-time statistics across users, streaming content, and viewer engagement.</p>
        </div>
        <div class="flex items-center gap-3">
            <a href="upload.php" class="px-5 py-2.5 rounded-xl text-xs font-bold text-white xvdo-btn-gradient shadow flex items-center gap-2">
                <i class="fa-solid fa-cloud-arrow-up"></i>
                <span>Upload Video</span>
            </a>
            <a href="categories.php" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 border border-[#232C3D] transition">
                Manage Categories
            </a>
        </div>
    </div>

    <!-- 4 Stats Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        <!-- Total Users -->
        <div class="bg-[#151B27] border border-[#232C3D] rounded-2xl p-5 shadow-lg relative overflow-hidden group">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold uppercase tracking-wider text-slate-400">Registered Users</span>
                <div class="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center text-base">
                    <i class="fa-solid fa-users"></i>
                </div>
            </div>
            <div class="mt-4">
                <span class="text-3xl font-extrabold text-white"><?= number_format($totalUsers) ?></span>
                <span class="text-[11px] text-emerald-400 font-semibold ml-2"><i class="fa-solid fa-check mr-0.5"></i>Active</span>
            </div>
            <a href="users.php" class="mt-3 inline-flex items-center gap-1 text-[11px] font-semibold text-blue-400 hover:text-blue-300">
                <span>View all users</span>
                <i class="fa-solid fa-arrow-right text-[9px]"></i>
            </a>
        </div>

        <!-- Total Videos -->
        <div class="bg-[#151B27] border border-[#232C3D] rounded-2xl p-5 shadow-lg relative overflow-hidden group">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold uppercase tracking-wider text-slate-400">Total Videos</span>
                <div class="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center text-base">
                    <i class="fa-solid fa-film"></i>
                </div>
            </div>
            <div class="mt-4">
                <span class="text-3xl font-extrabold text-white"><?= number_format($totalVideos) ?></span>
                <span class="text-[11px] text-slate-400 font-medium ml-2">in catalog</span>
            </div>
            <a href="videos.php" class="mt-3 inline-flex items-center gap-1 text-[11px] font-semibold text-purple-400 hover:text-purple-300">
                <span>Manage videos</span>
                <i class="fa-solid fa-arrow-right text-[9px]"></i>
            </a>
        </div>

        <!-- Total Views -->
        <div class="bg-[#151B27] border border-[#232C3D] rounded-2xl p-5 shadow-lg relative overflow-hidden group">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold uppercase tracking-wider text-slate-400">Total Stream Views</span>
                <div class="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center text-base">
                    <i class="fa-solid fa-play"></i>
                </div>
            </div>
            <div class="mt-4">
                <span class="text-3xl font-extrabold text-white"><?= number_format($totalViews) ?></span>
                <span class="text-[11px] text-slate-400 font-medium ml-2">plays</span>
            </div>
            <span class="mt-3 text-[11px] text-slate-500 block">Logged across all videos</span>
        </div>

        <!-- Total Categories -->
        <div class="bg-[#151B27] border border-[#232C3D] rounded-2xl p-5 shadow-lg relative overflow-hidden group">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold uppercase tracking-wider text-slate-400">Categories</span>
                <div class="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center text-base">
                    <i class="fa-solid fa-shapes"></i>
                </div>
            </div>
            <div class="mt-4">
                <span class="text-3xl font-extrabold text-white"><?= number_format($totalCategories) ?></span>
                <span class="text-[11px] text-slate-400 font-medium ml-2">active genres</span>
            </div>
            <a href="categories.php" class="mt-3 inline-flex items-center gap-1 text-[11px] font-semibold text-amber-400 hover:text-amber-300">
                <span>Organize genres</span>
                <i class="fa-solid fa-arrow-right text-[9px]"></i>
            </a>
        </div>

    </div>

    <!-- 2 Columns: Recent Videos & Recent Users -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- Left: Recent Videos (7 cols) -->
        <div class="lg:col-span-7 bg-[#151B27] border border-[#232C3D] rounded-3xl p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-[#232C3D]">
                <div>
                    <h3 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                        <i class="fa-solid fa-video text-purple-400"></i> Recently Added Videos
                    </h3>
                </div>
                <a href="videos.php" class="text-xs text-purple-400 hover:text-purple-300 font-semibold">View all &rarr;</a>
            </div>

            <div class="divide-y divide-[#232C3D]/60">
                <?php foreach ($recentVideos as $vid): ?>
                    <div class="py-3 flex items-center justify-between gap-4">
                        <div class="flex items-center gap-3 overflow-hidden">
                            <img src="<?= e($vid['thumbnail_path']) ?>" alt="" class="w-16 aspect-video rounded-lg object-cover bg-black flex-shrink-0">
                            <div class="overflow-hidden">
                                <h4 class="text-xs font-bold text-white truncate"><?= e($vid['title']) ?></h4>
                                <div class="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                                    <span><?= e($vid['category_name'] ?: 'Uncategorized') ?></span>
                                    <span>&bull;</span>
                                    <span><?= formatViews((int)$vid['views']) ?> views</span>
                                </div>
                            </div>
                        </div>

                        <div class="flex items-center gap-2 flex-shrink-0">
                            <span class="px-2 py-0.5 rounded text-[10px] font-semibold <?= $vid['status'] === 'published' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-700 text-slate-400' ?>">
                                <?= ucfirst($vid['status']) ?>
                            </span>
                            <a href="edit-video.php?id=<?= (int)$vid['id'] ?>" class="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs" title="Edit">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Right: Recent Users (5 cols) -->
        <div class="lg:col-span-5 bg-[#151B27] border border-[#232C3D] rounded-3xl p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-[#232C3D]">
                <h3 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <i class="fa-solid fa-users text-blue-400"></i> Recent Registrations
                </h3>
                <a href="users.php" class="text-xs text-blue-400 hover:text-blue-300 font-semibold">View all &rarr;</a>
            </div>

            <div class="divide-y divide-[#232C3D]/60">
                <?php foreach ($recentUsers as $u): ?>
                    <div class="py-3 flex items-center justify-between gap-3">
                        <div class="flex items-center gap-3 overflow-hidden">
                            <div class="w-8 h-8 rounded-full bg-slate-800 text-blue-400 font-bold flex items-center justify-center text-xs flex-shrink-0">
                                <?= strtoupper(substr($u['full_name'], 0, 1)) ?>
                            </div>
                            <div class="overflow-hidden">
                                <p class="text-xs font-bold text-white truncate"><?= e($u['full_name']) ?></p>
                                <p class="text-[10px] text-slate-400 truncate"><?= e($u['email']) ?></p>
                            </div>
                        </div>

                        <span class="px-2 py-0.5 rounded text-[10px] font-semibold flex-shrink-0 <?= $u['status'] === 'active' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400' ?>">
                            <?= ucfirst($u['status']) ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
