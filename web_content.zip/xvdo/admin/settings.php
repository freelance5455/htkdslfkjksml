<?php
/**
 * XVDO - Admin Settings Portal
 */
$pageTitle = 'Portal Settings';
require_once __DIR__ . '/includes/header.php';

$pdo = getDBConnection();
$admin = getCurrentAdmin();
$errors = [];
$successMsg = '';

// Handle Settings or Password Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Security token invalid. Please refresh the page.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'update_site_settings') {
            $siteName = trim($_POST['site_name'] ?? 'XVDO');
            $siteTagline = trim($_POST['site_tagline'] ?? '');
            $contactEmail = trim($_POST['contact_email'] ?? '');
            $allowRegistrations = isset($_POST['allow_registrations']) ? '1' : '0';

            $settingsMap = [
                'site_name' => $siteName,
                'site_tagline' => $siteTagline,
                'contact_email' => $contactEmail,
                'allow_registrations' => $allowRegistrations
            ];

            foreach ($settingsMap as $key => $val) {
                $upsert = $pdo->prepare("
                    INSERT INTO settings (setting_key, setting_value, updated_at) 
                    VALUES (?, ?, NOW()) 
                    ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
                ");
                $upsert->execute([$key, $val]);
            }

            setFlash('success', 'Website settings updated successfully.');
            header('Location: settings.php');
            exit;
        } elseif ($action === 'change_admin_password') {
            $currentPass = $_POST['current_password'] ?? '';
            $newPass = $_POST['new_password'] ?? '';
            $confirmPass = $_POST['confirm_password'] ?? '';

            $adminStmt = $pdo->prepare("SELECT password FROM admins WHERE id = ? LIMIT 1");
            $adminStmt->execute([$admin['id']]);
            $hashRow = $adminStmt->fetch();

            if (!$hashRow || !password_verify($currentPass, $hashRow['password'])) {
                $errors[] = 'Current administrator password was incorrect.';
            } elseif (strlen($newPass) < 6) {
                $errors[] = 'New password must be at least 6 characters.';
            } elseif ($newPass !== $confirmPass) {
                $errors[] = 'New password and confirmation do not match.';
            } else {
                $newHash = password_hash($newPass, PASSWORD_BCRYPT);
                $updatePass = $pdo->prepare("UPDATE admins SET password = ? WHERE id = ?");
                $updatePass->execute([$newHash, $admin['id']]);
                setFlash('success', 'Admin password changed successfully.');
                header('Location: settings.php');
                exit;
            }
        }
    }
}

$siteNameVal = getSetting('site_name', 'XVDO');
$siteTaglineVal = getSetting('site_tagline', 'Next-Generation High-Definition Video Streaming');
$contactEmailVal = getSetting('contact_email', 'support@xvdo.com');
$allowRegistrationsVal = getSetting('allow_registrations', '1');
?>

<div class="max-w-4xl mx-auto space-y-8">

    <!-- Header -->
    <div class="flex items-center justify-between pb-4 border-b border-[#232C3D]">
        <div>
            <h1 class="text-2xl font-black text-white">System & Portal Settings</h1>
            <p class="text-xs text-slate-400 mt-0.5">Configure platform branding, security credentials, and server upload parameters</p>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="p-4 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs space-y-1">
            <?php foreach ($errors as $err): ?>
                <div class="flex items-center gap-2">
                    <i class="fa-solid fa-circle-exclamation flex-shrink-0"></i>
                    <span><?= e($err) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- Left: General Website Settings (7 cols) -->
        <div class="lg:col-span-7 bg-[#151B27] border border-[#232C3D] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <h3 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                <i class="fa-solid fa-gear text-purple-400"></i> Website Branding & Configuration
            </h3>

            <form action="settings.php" method="POST" class="space-y-4">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="update_site_settings">

                <div>
                    <label for="site_name" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        Platform Name
                    </label>
                    <input type="text" id="site_name" name="site_name" value="<?= e($siteNameVal) ?>" required
                           class="w-full bg-[#090C12] text-sm text-white rounded-xl px-4 py-2.5 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                </div>

                <div>
                    <label for="site_tagline" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        Site Tagline
                    </label>
                    <input type="text" id="site_tagline" name="site_tagline" value="<?= e($siteTaglineVal) ?>"
                           class="w-full bg-[#090C12] text-sm text-white rounded-xl px-4 py-2.5 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                </div>

                <div>
                    <label for="contact_email" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        System Contact / Support Email
                    </label>
                    <input type="email" id="contact_email" name="contact_email" value="<?= e($contactEmailVal) ?>"
                           class="w-full bg-[#090C12] text-sm text-white rounded-xl px-4 py-2.5 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                </div>

                <div class="flex items-center gap-3 p-3.5 rounded-xl bg-[#0E131E] border border-[#232C3D]">
                    <input type="checkbox" id="allow_registrations" name="allow_registrations" value="1" <?= $allowRegistrationsVal === '1' ? 'checked' : '' ?> class="w-4 h-4 rounded text-purple-600 accent-purple-500">
                    <label for="allow_registrations" class="text-xs font-bold text-white cursor-pointer">
                        Allow Public User Registrations
                    </label>
                </div>

                <button type="submit" class="w-full py-3 px-4 rounded-xl text-white font-bold text-xs xvdo-btn-gradient shadow">
                    Save Platform Settings
                </button>
            </form>
        </div>

        <!-- Right: Admin Password & Host Status (5 cols) -->
        <div class="lg:col-span-5 space-y-6">

            <!-- Change Admin Password -->
            <div class="bg-[#151B27] border border-[#232C3D] rounded-3xl p-6 shadow-xl space-y-4">
                <h3 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <i class="fa-solid fa-lock text-purple-400"></i> Change Admin Password
                </h3>

                <form action="settings.php" method="POST" class="space-y-4">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="change_admin_password">

                    <div>
                        <label for="current_password" class="block text-xs font-semibold text-slate-400 mb-1">Current Password</label>
                        <input type="password" id="current_password" name="current_password" required
                               class="w-full bg-[#090C12] text-sm text-white rounded-xl px-3.5 py-2.5 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                    </div>

                    <div>
                        <label for="new_password" class="block text-xs font-semibold text-slate-400 mb-1">New Admin Password</label>
                        <input type="password" id="new_password" name="new_password" required minlength="6"
                               class="w-full bg-[#090C12] text-sm text-white rounded-xl px-3.5 py-2.5 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                    </div>

                    <div>
                        <label for="confirm_password" class="block text-xs font-semibold text-slate-400 mb-1">Confirm New Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required minlength="6"
                               class="w-full bg-[#090C12] text-sm text-white rounded-xl px-3.5 py-2.5 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                    </div>

                    <button type="submit" class="w-full py-2.5 rounded-xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 transition shadow">
                        Update Password
                    </button>
                </form>
            </div>

            <!-- Server Environment Info Card -->
            <div class="bg-[#151B27] border border-[#232C3D] rounded-3xl p-6 shadow-xl space-y-3 text-xs">
                <h4 class="font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-server text-blue-400"></i> Server Environment
                </h4>
                <div class="space-y-1.5 text-slate-400">
                    <div class="flex justify-between">
                        <span>PHP Version:</span>
                        <strong class="text-white"><?= PHP_VERSION ?></strong>
                    </div>
                    <div class="flex justify-between">
                        <span>PDO MySQL Driver:</span>
                        <strong class="text-emerald-400">Enabled</strong>
                    </div>
                    <div class="flex justify-between">
                        <span>Upload Max Filesize:</span>
                        <strong class="text-white"><?= ini_get('upload_max_filesize') ?></strong>
                    </div>
                    <div class="flex justify-between">
                        <span>Post Max Size:</span>
                        <strong class="text-white"><?= ini_get('post_max_size') ?></strong>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
