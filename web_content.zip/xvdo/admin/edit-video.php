<?php
/**
 * XVDO - Admin Edit Video
 */
$pageTitle = 'Edit Video';
require_once __DIR__ . '/includes/header.php';

$pdo = getDBConnection();
$videoId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($videoId <= 0) {
    setFlash('warning', 'Invalid video selected.');
    header('Location: videos.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM videos WHERE id = ? LIMIT 1");
$stmt->execute([$videoId]);
$video = $stmt->fetch();

if (!$video) {
    setFlash('danger', 'Video not found.');
    header('Location: videos.php');
    exit;
}

$categories = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Security token invalid. Please refresh the page.';
    } else {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $categoryId = (int)($_POST['category_id'] ?? 0);
        $duration = trim($_POST['duration'] ?? $video['duration']);
        $videoPath = trim($_POST['video_path'] ?? $video['video_path']);
        $isFeatured = isset($_POST['is_featured']) ? 1 : 0;
        $status = in_array($_POST['status'] ?? '', ['published', 'unpublished']) ? $_POST['status'] : 'published';

        if (empty($title)) {
            $errors[] = 'Video title is required.';
        }

        if ($categoryId <= 0) {
            $errors[] = 'Please select a valid category.';
        }

        // Process Thumbnail replacement if uploaded
        $thumbnailPath = $video['thumbnail_path'];
        if (isset($_FILES['thumb_file']) && $_FILES['thumb_file']['error'] === UPLOAD_ERR_OK) {
            $thumbResult = uploadSecureFile(
                $_FILES['thumb_file'],
                __DIR__ . '/../uploads/thumbnails',
                ['image/jpeg', 'image/png', 'image/webp'],
                ['jpg', 'jpeg', 'png', 'webp'],
                5 * 1024 * 1024
            );
            if ($thumbResult['success']) {
                $thumbnailPath = 'uploads/thumbnails/' . $thumbResult['fileName'];
            } else {
                $errors[] = 'Thumbnail Upload Error: ' . $thumbResult['error'];
            }
        } elseif (!empty($_POST['thumb_url']) && filter_var($_POST['thumb_url'], FILTER_VALIDATE_URL)) {
            $thumbnailPath = trim($_POST['thumb_url']);
        }

        if (empty($errors)) {
            try {
                $updateStmt = $pdo->prepare("
                    UPDATE videos 
                    SET title = ?, description = ?, category_id = ?, duration = ?, video_path = ?, thumbnail_path = ?, is_featured = ?, status = ?, updated_at = NOW()
                    WHERE id = ?
                ");
                $updateStmt->execute([
                    $title,
                    $description,
                    $categoryId,
                    $duration,
                    $videoPath,
                    $thumbnailPath,
                    $isFeatured,
                    $status,
                    $videoId
                ]);

                setFlash('success', 'Video "' . $title . '" updated successfully!');
                header('Location: videos.php');
                exit;
            } catch (Exception $e) {
                error_log("Edit video database error: " . $e->getMessage());
                $errors[] = 'Database error: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="max-w-4xl mx-auto space-y-6">

    <!-- Header -->
    <div class="flex items-center justify-between pb-4 border-b border-[#232C3D]">
        <div>
            <h1 class="text-2xl font-black text-white">Edit Video</h1>
            <p class="text-xs text-slate-400 mt-0.5">Modify video metadata, category assignment, thumbnail and visibility</p>
        </div>
        <div class="flex items-center gap-2">
            <a href="../watch.php?id=<?= (int)$video['id'] ?>" target="_blank" class="text-xs font-semibold text-slate-300 hover:text-white px-3 py-1.5 rounded-lg bg-slate-800 transition">
                <i class="fa-solid fa-eye mr-1"></i> Preview
            </a>
            <a href="videos.php" class="text-xs font-semibold text-slate-400 hover:text-white px-3 py-1.5 rounded-lg bg-slate-800 transition">
                <i class="fa-solid fa-arrow-left mr-1"></i> Back
            </a>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="p-4 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs space-y-1">
            <?php foreach ($errors as $err): ?>
                <div class="flex items-center gap-2">
                    <i class="fa-solid fa-circle-exclamation flex-shrink-0"></i>
                    <span><?= e($err) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form action="edit-video.php?id=<?= (int)$video['id'] ?>" method="POST" enctype="multipart/form-data" class="bg-[#151B27] border border-[#232C3D] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
        <?= csrfField() ?>

        <div class="space-y-4">
            <!-- Title -->
            <div>
                <label for="title" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Video Title <span class="text-rose-400">*</span>
                </label>
                <input type="text" id="title" name="title" required value="<?= e($video['title']) ?>"
                       class="w-full bg-[#090C12] text-sm text-white rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Category -->
                <div>
                    <label for="category_id" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        Category <span class="text-rose-400">*</span>
                    </label>
                    <select id="category_id" name="category_id" required
                            class="w-full bg-[#090C12] text-sm text-slate-300 rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= (int)$cat['id'] ?>" <?= (int)$video['category_id'] === (int)$cat['id'] ? 'selected' : '' ?>>
                                <?= e($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Duration -->
                <div>
                    <label for="duration" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        Duration
                    </label>
                    <input type="text" id="duration" name="duration" value="<?= e($video['duration']) ?>"
                           class="w-full bg-[#090C12] text-sm text-white font-mono rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                </div>
            </div>

            <!-- Video File / URL Path -->
            <div>
                <label for="video_path" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Video Stream Source Path or URL
                </label>
                <input type="text" id="video_path" name="video_path" required value="<?= e($video['video_path']) ?>"
                       class="w-full bg-[#090C12] text-xs text-white font-mono rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500">
            </div>

            <!-- Thumbnail Current Preview & Update -->
            <div class="p-4 rounded-2xl bg-[#0E131E] border border-[#232C3D] space-y-3">
                <label class="block text-xs font-bold uppercase tracking-wider text-purple-400">
                    Thumbnail Image
                </label>
                <div class="flex items-center gap-4">
                    <img src="<?= e($video['thumbnail_path']) ?>" alt="" class="w-32 aspect-video rounded-xl object-cover bg-black border border-[#232C3D]">
                    <div class="space-y-2 flex-1">
                        <label class="block text-[11px] text-slate-400">Upload New Thumbnail Image (JPG/PNG/WebP):</label>
                        <input type="file" name="thumb_file" accept="image/jpeg,image/png,image/webp"
                               class="w-full bg-[#090C12] text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-purple-600 file:text-white rounded-xl p-1.5 border border-[#232C3D]">
                        
                        <input type="url" name="thumb_url" placeholder="Or enter new image URL..."
                               class="w-full bg-[#090C12] text-xs text-white rounded-xl px-3 py-2 border border-[#232C3D] focus:outline-none">
                    </div>
                </div>
            </div>

            <!-- Description -->
            <div>
                <label for="description" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Description & Overview
                </label>
                <textarea id="description" name="description" rows="4"
                          class="w-full bg-[#090C12] text-sm text-white rounded-xl p-4 border border-[#232C3D] focus:outline-none focus:border-purple-500"><?= e($video['description']) ?></textarea>
            </div>

            <!-- Options -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div class="flex items-center gap-3 p-3.5 rounded-xl bg-[#0E131E] border border-[#232C3D]">
                    <input type="checkbox" id="is_featured" name="is_featured" value="1" <?= $video['is_featured'] ? 'checked' : '' ?> class="w-4 h-4 rounded text-purple-600 accent-purple-500">
                    <label for="is_featured" class="text-xs font-bold text-white cursor-pointer">
                        Featured on Hero Banner
                    </label>
                </div>

                <div>
                    <select name="status" class="w-full bg-[#0E131E] text-xs font-semibold text-slate-300 rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none">
                        <option value="published" <?= $video['status'] === 'published' ? 'selected' : '' ?>>Status: Published (Visible)</option>
                        <option value="unpublished" <?= $video['status'] === 'unpublished' ? 'selected' : '' ?>>Status: Draft / Unpublished</option>
                    </select>
                </div>
            </div>

            <div class="pt-4 flex items-center justify-between gap-4">
                <button type="submit" class="flex-1 py-3 px-6 rounded-xl text-white font-bold text-sm xvdo-btn-gradient shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2">
                    <i class="fa-solid fa-floppy-disk"></i>
                    <span>Save Changes</span>
                </button>
                <a href="videos.php" class="px-6 py-3 rounded-xl text-xs font-semibold text-slate-400 hover:text-white bg-slate-800 transition">
                    Cancel
                </a>
            </div>
        </div>
    </form>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
