<?php
/**
 * XVDO - Admin Category Management
 */
$pageTitle = 'Category Management';
require_once __DIR__ . '/includes/header.php';

$pdo = getDBConnection();
$errors = [];
$editCategory = null;

// Handle Edit Mode Request
$editId = (int)($_GET['edit'] ?? 0);
if ($editId > 0) {
    $editStmt = $pdo->prepare("SELECT * FROM categories WHERE id = ? LIMIT 1");
    $editStmt->execute([$editId]);
    $editCategory = $editStmt->fetch();
}

// Handle POST submissions (Create, Update, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Security token invalid. Please refresh the page.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'create') {
            $name = trim($_POST['name'] ?? '');
            $slug = strtolower(trim($_POST['slug'] ?? ''));
            $description = trim($_POST['description'] ?? '');
            $icon = trim($_POST['icon'] ?? 'fa-solid fa-film');

            if (empty($name)) {
                $errors[] = 'Category name is required.';
            }

            if (empty($slug)) {
                $slug = preg_replace('/[^a-z0-9]+/i', '-', strtolower($name));
                $slug = trim($slug, '-');
            }

            // Check slug uniqueness
            $check = $pdo->prepare("SELECT id FROM categories WHERE slug = ? LIMIT 1");
            $check->execute([$slug]);
            if ($check->fetch()) {
                $errors[] = 'A category with this URL slug already exists.';
            }

            if (empty($errors)) {
                $insert = $pdo->prepare("INSERT INTO categories (name, slug, description, icon, created_at) VALUES (?, ?, ?, ?, NOW())");
                $insert->execute([$name, $slug, $description, $icon]);
                setFlash('success', 'Category "' . $name . '" created successfully.');
                header('Location: categories.php');
                exit;
            }
        } elseif ($action === 'update') {
            $catId = (int)($_POST['category_id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $slug = strtolower(trim($_POST['slug'] ?? ''));
            $description = trim($_POST['description'] ?? '');
            $icon = trim($_POST['icon'] ?? 'fa-solid fa-film');

            if (empty($name)) {
                $errors[] = 'Category name is required.';
            }

            if (empty($errors)) {
                $update = $pdo->prepare("UPDATE categories SET name = ?, slug = ?, description = ?, icon = ? WHERE id = ?");
                $update->execute([$name, $slug, $description, $icon, $catId]);
                setFlash('success', 'Category updated successfully.');
                header('Location: categories.php');
                exit;
            }
        } elseif ($action === 'delete') {
            $catId = (int)($_POST['category_id'] ?? 0);
            
            // Check attached videos
            $countStmt = $pdo->prepare("SELECT COUNT(*) FROM videos WHERE category_id = ?");
            $countStmt->execute([$catId]);
            $attachedVideos = (int)$countStmt->fetchColumn();

            if ($attachedVideos > 0) {
                // Reassign to null or uncategorized
                $pdo->prepare("UPDATE videos SET category_id = NULL WHERE category_id = ?")->execute([$catId]);
            }

            $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$catId]);
            setFlash('success', 'Category deleted successfully.');
            header('Location: categories.php');
            exit;
        }
    }
}

// Fetch all categories with video count
$categories = $pdo->query("
    SELECT c.*, COUNT(v.id) AS video_count 
    FROM categories c 
    LEFT JOIN videos v ON c.id = v.category_id 
    GROUP BY c.id 
    ORDER BY c.name ASC
")->fetchAll();
?>

<div class="space-y-8">

    <!-- Header -->
    <div class="flex items-center justify-between pb-4 border-b border-[#232C3D]">
        <div>
            <h1 class="text-2xl font-black text-white">Categories Management</h1>
            <p class="text-xs text-slate-400 mt-0.5">Organize video streams into genres and thematic libraries</p>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="p-4 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs space-y-1">
            <?php foreach ($errors as $err): ?>
                <div class="flex items-center gap-2">
                    <i class="fa-solid fa-circle-exclamation flex-shrink-0"></i>
                    <span><?= e($err) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- Left: Form to Add or Edit Category (5 cols) -->
        <div class="lg:col-span-5 bg-[#151B27] border border-[#232C3D] rounded-3xl p-6 shadow-xl space-y-4">
            <h3 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                <i class="fa-solid fa-folder-plus text-purple-400"></i>
                <?= $editCategory ? 'Edit Category: ' . e($editCategory['name']) : 'Create New Category' ?>
            </h3>

            <form action="categories.php" method="POST" class="space-y-4">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="<?= $editCategory ? 'update' : 'create' ?>">
                <?php if ($editCategory): ?>
                    <input type="hidden" name="category_id" value="<?= (int)$editCategory['id'] ?>">
                <?php endif; ?>

                <div>
                    <label for="name" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        Category Name <span class="text-rose-400">*</span>
                    </label>
                    <input type="text" id="name" name="name" required placeholder="e.g. Cyberpunk & Sci-Fi"
                           value="<?= e($editCategory['name'] ?? '') ?>"
                           class="w-full bg-[#090C12] text-sm text-white rounded-xl px-4 py-2.5 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                </div>

                <div>
                    <label for="slug" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        URL Slug
                    </label>
                    <input type="text" id="slug" name="slug" placeholder="e.g. sci-fi"
                           value="<?= e($editCategory['slug'] ?? '') ?>"
                           class="w-full bg-[#090C12] text-sm text-white rounded-xl px-4 py-2.5 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                    <span class="text-[10px] text-slate-500 mt-1 block">Leave empty to generate automatically from name</span>
                </div>

                <div>
                    <label for="icon" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        Font Awesome Icon Class
                    </label>
                    <div class="relative">
                        <input type="text" id="icon" name="icon" placeholder="fa-solid fa-rocket"
                               value="<?= e($editCategory['icon'] ?? 'fa-solid fa-film') ?>"
                               class="w-full bg-[#090C12] text-sm text-white rounded-xl pl-10 pr-4 py-2.5 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                        <i class="fa-solid fa-icons absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-xs"></i>
                    </div>
                    <span class="text-[10px] text-slate-500 mt-1 block">Examples: <code>fa-solid fa-fire</code>, <code>fa-solid fa-robot</code>, <code>fa-solid fa-gamepad</code></span>
                </div>

                <div>
                    <label for="description" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        Description
                    </label>
                    <textarea id="description" name="description" rows="3" placeholder="Category synopsis shown on category pages..."
                              class="w-full bg-[#090C12] text-sm text-white rounded-xl p-3 border border-[#232C3D] focus:outline-none focus:border-purple-500"><?= e($editCategory['description'] ?? '') ?></textarea>
                </div>

                <div class="pt-2 flex items-center gap-3">
                    <button type="submit" class="flex-1 py-2.5 px-4 rounded-xl text-white font-bold text-xs xvdo-btn-gradient shadow">
                        <?= $editCategory ? 'Save Category Changes' : 'Create Category' ?>
                    </button>
                    <?php if ($editCategory): ?>
                        <a href="categories.php" class="py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-400 hover:text-white bg-slate-800 transition">
                            Cancel
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Right: Existing Categories List (7 cols) -->
        <div class="lg:col-span-7 bg-[#151B27] border border-[#232C3D] rounded-3xl overflow-hidden shadow-xl">
            <div class="p-4 sm:p-6 border-b border-[#232C3D] flex items-center justify-between">
                <h3 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <i class="fa-solid fa-list text-blue-400"></i> All Categories (<?= count($categories) ?>)
                </h3>
            </div>

            <div class="divide-y divide-[#232C3D]/60 text-xs">
                <?php foreach ($categories as $cat): ?>
                    <div class="p-4 flex items-center justify-between gap-4 hover:bg-[#1C2333]/40 transition">
                        <div class="flex items-center gap-3.5 overflow-hidden">
                            <div class="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center text-sm flex-shrink-0">
                                <i class="<?= e($cat['icon'] ?: 'fa-solid fa-film') ?>"></i>
                            </div>
                            <div class="overflow-hidden">
                                <h4 class="font-bold text-white text-sm"><?= e($cat['name']) ?></h4>
                                <span class="text-[10px] text-slate-500 font-mono">slug: /category.php?slug=<?= e($cat['slug']) ?></span>
                                <?php if (!empty($cat['description'])): ?>
                                    <p class="text-[11px] text-slate-400 line-clamp-1 mt-0.5"><?= e($cat['description']) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 flex-shrink-0">
                            <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-800 text-blue-400 border border-slate-700">
                                <?= (int)$cat['video_count'] ?> videos
                            </span>

                            <a href="categories.php?edit=<?= (int)$cat['id'] ?>" class="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-blue-400 text-xs" title="Edit">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>

                            <form method="POST" action="categories.php" onsubmit="return confirm('Delete category <?= e($cat['name']) ?>? Attached videos will remain published without category.');" class="inline">
                                <?= csrfField() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="category_id" value="<?= (int)$cat['id'] ?>">
                                <button type="submit" class="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs" title="Delete">
                                    <i class="fa-solid fa-trash-can"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
