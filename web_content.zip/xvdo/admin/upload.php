<?php
/**
 * XVDO - Admin Video Upload
 */
$pageTitle = 'Upload Video';
require_once __DIR__ . '/includes/header.php';

$pdo = getDBConnection();
$errors = [];
$success = '';

// Server PHP upload configuration limits
$maxUploadIni = ini_get('upload_max_filesize');
$maxPostIni = ini_get('post_max_size');

// Fetch categories
$categories = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Security token invalid. Please refresh the page.';
    } else {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $categoryId = (int)($_POST['category_id'] ?? 0);
        $duration = trim($_POST['duration'] ?? '00:00');
        $videoSourceType = $_POST['video_source_type'] ?? 'url'; // 'file' or 'url'
        $isFeatured = isset($_POST['is_featured']) ? 1 : 0;
        $status = in_array($_POST['status'] ?? '', ['published', 'unpublished']) ? $_POST['status'] : 'published';

        if (empty($title)) {
            $errors[] = 'Video title is required.';
        }

        if ($categoryId <= 0) {
            $errors[] = 'Please select a valid category.';
        }

        // 1. Process Video Source
        $finalVideoPath = '';
        $finalVideoType = 'url';

        if ($videoSourceType === 'file') {
            if (isset($_FILES['video_file']) && $_FILES['video_file']['error'] === UPLOAD_ERR_OK) {
                $uploadResult = uploadSecureFile(
                    $_FILES['video_file'],
                    __DIR__ . '/../uploads/videos',
                    ['video/mp4', 'video/webm', 'video/quicktime'],
                    ['mp4', 'webm', 'mov'],
                    100 * 1024 * 1024 // 100MB max default limit
                );

                if ($uploadResult['success']) {
                    $finalVideoPath = 'uploads/videos/' . $uploadResult['fileName'];
                    $finalVideoType = 'upload';
                } else {
                    $errors[] = 'Video Upload Error: ' . $uploadResult['error'];
                }
            } else {
                $errors[] = 'Please select a valid video file to upload, or switch to External Video URL.';
            }
        } else {
            $videoUrl = trim($_POST['video_url'] ?? '');
            if (empty($videoUrl) || !filter_var($videoUrl, FILTER_VALIDATE_URL)) {
                $errors[] = 'Please provide a valid external video URL (e.g. direct MP4, WebM, or YouTube link).';
            } else {
                $finalVideoPath = $videoUrl;
                $finalVideoType = 'url';
            }
        }

        // 2. Process Thumbnail
        $finalThumbPath = 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&auto=format&fit=crop&q=80';
        $thumbSourceType = $_POST['thumb_source_type'] ?? 'file';

        if ($thumbSourceType === 'file' && isset($_FILES['thumb_file']) && $_FILES['thumb_file']['error'] === UPLOAD_ERR_OK) {
            $thumbResult = uploadSecureFile(
                $_FILES['thumb_file'],
                __DIR__ . '/../uploads/thumbnails',
                ['image/jpeg', 'image/png', 'image/webp'],
                ['jpg', 'jpeg', 'png', 'webp'],
                5 * 1024 * 1024 // 5MB
            );

            if ($thumbResult['success']) {
                $finalThumbPath = 'uploads/thumbnails/' . $thumbResult['fileName'];
            } else {
                $errors[] = 'Thumbnail Upload Error: ' . $thumbResult['error'];
            }
        } elseif (!empty($_POST['thumb_url']) && filter_var($_POST['thumb_url'], FILTER_VALIDATE_URL)) {
            $finalThumbPath = trim($_POST['thumb_url']);
        }

        // 3. Insert Record
        if (empty($errors)) {
            try {
                $insertStmt = $pdo->prepare("
                    INSERT INTO videos (category_id, title, description, video_type, video_path, thumbnail_path, duration, views, is_featured, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, NOW(), NOW())
                ");
                $insertStmt->execute([
                    $categoryId,
                    $title,
                    $description,
                    $finalVideoType,
                    $finalVideoPath,
                    $finalThumbPath,
                    $duration,
                    $isFeatured,
                    $status
                ]);

                setFlash('success', 'Video "' . $title . '" published successfully to catalogue!');
                header('Location: videos.php');
                exit;
            } catch (Exception $e) {
                error_log("Upload database error: " . $e->getMessage());
                $errors[] = 'Failed to save video to database: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="max-w-4xl mx-auto space-y-6">

    <!-- Header -->
    <div class="flex items-center justify-between pb-4 border-b border-[#232C3D]">
        <div>
            <h1 class="text-2xl font-black text-white">Upload New Video</h1>
            <p class="text-xs text-slate-400 mt-0.5">Publish videos to the XVDO platform via local file or cloud CDN stream</p>
        </div>
        <a href="videos.php" class="text-xs font-semibold text-slate-400 hover:text-white px-3 py-1.5 rounded-lg bg-slate-800 transition">
            <i class="fa-solid fa-arrow-left mr-1"></i> Back to Videos
        </a>
    </div>

    <!-- Server Upload Limit Notice -->
    <div class="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 text-xs text-indigo-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow">
        <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-lg bg-indigo-600/30 text-indigo-400 flex items-center justify-center flex-shrink-0">
                <i class="fa-solid fa-server"></i>
            </div>
            <div>
                <strong class="font-bold text-white">Server File Upload Capacity:</strong>
                <span>upload_max_filesize = <?= e($maxUploadIni) ?>, post_max_size = <?= e($maxPostIni) ?></span>
                <p class="text-[11px] text-indigo-300 mt-0.5">For files exceeding server limits, select <strong>External Stream URL</strong> (YouTube or direct cloud MP4) without hitting server storage constraints.</p>
            </div>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="p-4 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs space-y-1">
            <?php foreach ($errors as $err): ?>
                <div class="flex items-center gap-2">
                    <i class="fa-solid fa-circle-exclamation flex-shrink-0"></i>
                    <span><?= e($err) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Upload Form -->
    <form action="upload.php" method="POST" enctype="multipart/form-data" class="bg-[#151B27] border border-[#232C3D] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
        <?= csrfField() ?>

        <div class="space-y-4">
            <!-- Video Title -->
            <div>
                <label for="title" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Video Title <span class="text-rose-400">*</span>
                </label>
                <input type="text" id="title" name="title" required placeholder="e.g. Cyberpunk 2077 - Cinematic 4K Showcase"
                       class="w-full bg-[#090C12] text-sm text-white rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Category -->
                <div>
                    <label for="category_id" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        Category <span class="text-rose-400">*</span>
                    </label>
                    <select id="category_id" name="category_id" required
                            class="w-full bg-[#090C12] text-sm text-slate-300 rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                        <option value="">-- Choose Category --</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= (int)$cat['id'] ?>"><?= e($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Duration -->
                <div>
                    <label for="duration" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                        Duration (MM:SS or HH:MM:SS)
                    </label>
                    <input type="text" id="duration" name="duration" placeholder="12:45"
                           class="w-full bg-[#090C12] text-sm text-white font-mono rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                </div>
            </div>

            <!-- Video Source Selection -->
            <div class="p-4 rounded-2xl bg-[#0E131E] border border-[#232C3D] space-y-3">
                <label class="block text-xs font-bold uppercase tracking-wider text-purple-400">
                    Video Storage Method
                </label>
                <div class="flex items-center gap-6 text-xs font-semibold text-slate-300">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="radio" name="video_source_type" value="url" checked onchange="toggleVideoInputs('url')" class="accent-purple-500">
                        <span>External Video URL (Recommended for high speed)</span>
                    </label>
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="radio" name="video_source_type" value="file" onchange="toggleVideoInputs('file')" class="accent-purple-500">
                        <span>Upload MP4 / WebM File</span>
                    </label>
                </div>

                <!-- URL input -->
                <div id="videoUrlGroup">
                    <input type="url" name="video_url" id="video_url" 
                           placeholder="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                           class="w-full bg-[#090C12] text-xs text-white rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                    <span class="text-[11px] text-slate-500 mt-1 block">Supports direct video URLs (.mp4, .webm) and YouTube watch URLs</span>
                </div>

                <!-- File input -->
                <div id="videoFileGroup" class="hidden">
                    <input type="file" name="video_file" id="video_file" accept="video/mp4,video/webm"
                           class="w-full bg-[#090C12] text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700 rounded-xl p-2 border border-[#232C3D]">
                    <span class="text-[11px] text-slate-500 mt-1 block">Supported: MP4, WebM (Max <?= e($maxUploadIni) ?>)</span>
                </div>
            </div>

            <!-- Thumbnail Selection -->
            <div class="p-4 rounded-2xl bg-[#0E131E] border border-[#232C3D] space-y-3">
                <label class="block text-xs font-bold uppercase tracking-wider text-purple-400">
                    Thumbnail Image
                </label>
                <div class="flex items-center gap-6 text-xs font-semibold text-slate-300">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="radio" name="thumb_source_type" value="file" checked onchange="toggleThumbInputs('file')" class="accent-purple-500">
                        <span>Upload JPG/PNG File</span>
                    </label>
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="radio" name="thumb_source_type" value="url" onchange="toggleThumbInputs('url')" class="accent-purple-500">
                        <span>External Image URL</span>
                    </label>
                </div>

                <div id="thumbFileGroup">
                    <input type="file" name="thumb_file" id="thumb_file" accept="image/jpeg,image/png,image/webp"
                           class="w-full bg-[#090C12] text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700 rounded-xl p-2 border border-[#232C3D]">
                </div>

                <div id="thumbUrlGroup" class="hidden">
                    <input type="url" name="thumb_url" id="thumb_url" placeholder="https://images.unsplash.com/photo-..."
                           class="w-full bg-[#090C12] text-xs text-white rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                </div>
            </div>

            <!-- Description -->
            <div>
                <label for="description" class="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Description & Overview
                </label>
                <textarea id="description" name="description" rows="4" placeholder="Brief summary of the stream, actors, production credits..."
                          class="w-full bg-[#090C12] text-sm text-white rounded-xl p-4 border border-[#232C3D] focus:outline-none focus:border-purple-500"></textarea>
            </div>

            <!-- Options: Featured & Status -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div class="flex items-center gap-3 p-3.5 rounded-xl bg-[#0E131E] border border-[#232C3D]">
                    <input type="checkbox" id="is_featured" name="is_featured" value="1" class="w-4 h-4 rounded text-purple-600 accent-purple-500">
                    <label for="is_featured" class="text-xs font-bold text-white cursor-pointer">
                        Featured on Hero Banner
                    </label>
                </div>

                <div>
                    <select name="status" class="w-full bg-[#0E131E] text-xs font-semibold text-slate-300 rounded-xl px-4 py-3 border border-[#232C3D] focus:outline-none">
                        <option value="published">Status: Published (Visible)</option>
                        <option value="unpublished">Status: Draft / Unpublished</option>
                    </select>
                </div>
            </div>

            <div class="pt-4">
                <button type="submit" class="w-full py-3.5 px-6 rounded-xl text-white font-bold text-sm xvdo-btn-gradient shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2">
                    <i class="fa-solid fa-cloud-arrow-up"></i>
                    <span>Publish Video to XVDO</span>
                </button>
            </div>
        </div>
    </form>

</div>

<script>
function toggleVideoInputs(type) {
    document.getElementById('videoUrlGroup').classList.toggle('hidden', type !== 'url');
    document.getElementById('videoFileGroup').classList.toggle('hidden', type !== 'file');
}
function toggleThumbInputs(type) {
    document.getElementById('thumbFileGroup').classList.toggle('hidden', type !== 'file');
    document.getElementById('thumbUrlGroup').classList.toggle('hidden', type !== 'url');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
