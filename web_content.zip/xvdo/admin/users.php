<?php
/**
 * XVDO - Admin User Accounts Management
 */
$pageTitle = 'User Management';
require_once __DIR__ . '/includes/header.php';

$pdo = getDBConnection();

// Handle Actions (Toggle Active/Inactive & Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (verifyCsrfToken($token)) {
        $action = $_POST['action'] ?? '';
        $targetUserId = (int)($_POST['user_id'] ?? 0);

        if ($targetUserId > 0) {
            if ($action === 'toggle_status') {
                $statusStmt = $pdo->prepare("SELECT status FROM users WHERE id = ?");
                $statusStmt->execute([$targetUserId]);
                $curr = $statusStmt->fetchColumn();
                $newStatus = ($curr === 'active') ? 'inactive' : 'active';

                $update = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
                $update->execute([$newStatus, $targetUserId]);
                setFlash('success', "User account status changed to {$newStatus}.");
            } elseif ($action === 'delete') {
                // Remove user watch history & views
                $pdo->prepare("DELETE FROM watch_history WHERE user_id = ?")->execute([$targetUserId]);
                $pdo->prepare("DELETE FROM video_views WHERE user_id = ?")->execute([$targetUserId]);
                $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$targetUserId]);

                setFlash('success', 'User account permanently deleted.');
            }
        }
    }
}

// Search filter
$search = trim($_GET['search'] ?? '');
$statusFilter = $_GET['status'] ?? '';

$sql = "
    SELECT u.*, COUNT(wh.id) AS watched_count 
    FROM users u 
    LEFT JOIN watch_history wh ON u.id = wh.user_id 
    WHERE 1=1
";
$params = [];

if (!empty($search)) {
    $sql .= " AND (u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

if (!empty($statusFilter) && in_array($statusFilter, ['active', 'inactive'])) {
    $sql .= " AND u.status = ?";
    $params[] = $statusFilter;
}

$sql .= " GROUP BY u.id ORDER BY u.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();
?>

<div class="space-y-6">

    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-black text-white">Registered Users</h1>
            <p class="text-xs text-slate-400 mt-0.5">Manage streaming accounts, investigate activity, and toggle membership status</p>
        </div>
        <div class="text-xs text-slate-400 font-semibold bg-[#151B27] px-4 py-2 rounded-xl border border-[#232C3D]">
            Total Users: <strong class="text-white"><?= count($users) ?></strong>
        </div>
    </div>

    <!-- Filters Bar -->
    <div class="bg-[#151B27] border border-[#232C3D] rounded-2xl p-4 shadow">
        <form method="GET" action="users.php" class="flex flex-wrap items-center justify-between gap-4">
            <div class="flex flex-wrap items-center gap-3 flex-1">
                <!-- Search input -->
                <div class="relative min-w-[220px] flex-1 max-w-sm">
                    <input type="text" name="search" value="<?= e($search) ?>" placeholder="Search by name, email, or phone..."
                           class="w-full bg-[#090C12] text-xs text-white rounded-xl pl-8 pr-3 py-2 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                    <i class="fa-solid fa-magnifying-glass absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 text-xs"></i>
                </div>

                <!-- Status filter -->
                <select name="status" class="bg-[#090C12] text-xs text-slate-300 rounded-xl px-3 py-2 border border-[#232C3D] focus:outline-none">
                    <option value="">All Statuses</option>
                    <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>Active Only</option>
                    <option value="inactive" <?= $statusFilter === 'inactive' ? 'selected' : '' ?>>Inactive Only</option>
                </select>

                <button type="submit" class="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 transition">
                    Search
                </button>
            </div>

            <?php if (!empty($search) || !empty($statusFilter)): ?>
                <a href="users.php" class="text-xs text-slate-400 hover:text-white underline">Clear filters</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Users Table -->
    <div class="bg-[#151B27] border border-[#232C3D] rounded-3xl overflow-hidden shadow-xl">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead class="bg-[#0E131E] border-b border-[#232C3D] text-slate-400 uppercase tracking-wider font-bold text-[10px]">
                    <tr>
                        <th class="py-3.5 px-4">User</th>
                        <th class="py-3.5 px-4">Email</th>
                        <th class="py-3.5 px-4">Phone</th>
                        <th class="py-3.5 px-4">Streams Watched</th>
                        <th class="py-3.5 px-4">Status</th>
                        <th class="py-3.5 px-4">Registered Date</th>
                        <th class="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#232C3D]/60 text-slate-300">
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-10 text-slate-500">
                                No registered users found.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($users as $u): ?>
                            <tr class="hover:bg-[#1C2333]/50 transition">
                                <!-- User Avatar & Name -->
                                <td class="py-3 px-4 whitespace-nowrap">
                                    <div class="flex items-center gap-3">
                                        <div class="w-9 h-9 rounded-full bg-gradient-to-tr from-blue-600 to-purple-600 text-white font-bold flex items-center justify-center text-xs shadow">
                                            <?= strtoupper(substr($u['full_name'], 0, 1)) ?>
                                        </div>
                                        <div>
                                            <span class="font-bold text-white block"><?= e($u['full_name']) ?></span>
                                            <span class="text-[10px] text-slate-500 font-mono">UID #<?= (int)$u['id'] ?></span>
                                        </div>
                                    </div>
                                </td>

                                <!-- Email -->
                                <td class="py-3 px-4 whitespace-nowrap text-slate-300">
                                    <?= e($u['email']) ?>
                                </td>

                                <!-- Phone -->
                                <td class="py-3 px-4 whitespace-nowrap text-slate-400">
                                    <?= e($u['phone'] ?: '—') ?>
                                </td>

                                <!-- Watched -->
                                <td class="py-3 px-4 whitespace-nowrap">
                                    <span class="px-2 py-0.5 rounded bg-slate-800 text-blue-400 font-bold text-[11px]">
                                        <i class="fa-solid fa-play text-[9px] mr-1"></i><?= (int)$u['watched_count'] ?>
                                    </span>
                                </td>

                                <!-- Status Toggle Button -->
                                <td class="py-3 px-4 whitespace-nowrap">
                                    <form method="POST" action="users.php" class="inline">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                                        <input type="hidden" name="action" value="toggle_status">
                                        <button type="submit" class="px-2.5 py-1 rounded-full text-[10px] font-semibold transition <?= $u['status'] === 'active' ? 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20' : 'bg-rose-500/10 text-rose-400 hover:bg-rose-500/20' ?>" title="Click to toggle status">
                                            <i class="fa-solid fa-circle text-[7px] mr-1.5 <?= $u['status'] === 'active' ? 'text-emerald-400' : 'text-rose-500' ?>"></i>
                                            <?= ucfirst($u['status']) ?>
                                        </button>
                                    </form>
                                </td>

                                <!-- Registered Date -->
                                <td class="py-3 px-4 whitespace-nowrap text-slate-500 text-[11px]">
                                    <?= date('M j, Y', strtotime($u['created_at'])) ?>
                                </td>

                                <!-- Actions -->
                                <td class="py-3 px-4 text-right whitespace-nowrap">
                                    <form method="POST" action="users.php" onsubmit="return confirm('Permanently delete user <?= e($u['full_name']) ?> and their entire history?');" class="inline">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <button type="submit" class="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs transition" title="Delete User">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
