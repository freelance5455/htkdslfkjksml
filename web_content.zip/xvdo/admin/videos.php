<?php
/**
 * XVDO - Admin Video Management
 */
$pageTitle = 'Video Management';
require_once __DIR__ . '/includes/header.php';

$pdo = getDBConnection();

// Handle Actions (Publish/Unpublish Toggle & Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (verifyCsrfToken($token)) {
        $action = $_POST['action'] ?? '';
        $targetId = (int)($_POST['video_id'] ?? 0);

        if ($targetId > 0) {
            if ($action === 'toggle_status') {
                $statusStmt = $pdo->prepare("SELECT status FROM videos WHERE id = ?");
                $statusStmt->execute([$targetId]);
                $curr = $statusStmt->fetchColumn();
                $newStatus = ($curr === 'published') ? 'unpublished' : 'published';

                $update = $pdo->prepare("UPDATE videos SET status = ? WHERE id = ?");
                $update->execute([$newStatus, $targetId]);
                setFlash('success', "Video status changed to {$newStatus}.");
            } elseif ($action === 'toggle_featured') {
                $featStmt = $pdo->prepare("SELECT is_featured FROM videos WHERE id = ?");
                $featStmt->execute([$targetId]);
                $curr = (int)$featStmt->fetchColumn();
                $newFeat = ($curr === 1) ? 0 : 1;

                $update = $pdo->prepare("UPDATE videos SET is_featured = ? WHERE id = ?");
                $update->execute([$newFeat, $targetId]);
                setFlash('success', "Featured status updated.");
            } elseif ($action === 'delete') {
                // Fetch paths to remove local files
                $pathStmt = $pdo->prepare("SELECT video_type, video_path, thumbnail_path FROM videos WHERE id = ?");
                $pathStmt->execute([$targetId]);
                $paths = $pathStmt->fetch();

                if ($paths) {
                    if ($paths['video_type'] === 'upload' && !empty($paths['video_path'])) {
                        $fullVidPath = __DIR__ . '/../' . ltrim($paths['video_path'], '/');
                        if (file_exists($fullVidPath) && is_file($fullVidPath)) {
                            @unlink($fullVidPath);
                        }
                    }
                    if (!empty($paths['thumbnail_path']) && str_contains($paths['thumbnail_path'], 'uploads/thumbnails/')) {
                        $fullThumbPath = __DIR__ . '/../' . ltrim($paths['thumbnail_path'], '/');
                        if (file_exists($fullThumbPath) && is_file($fullThumbPath)) {
                            @unlink($fullThumbPath);
                        }
                    }

                    // Delete related views and history
                    $pdo->prepare("DELETE FROM watch_history WHERE video_id = ?")->execute([$targetId]);
                    $pdo->prepare("DELETE FROM video_views WHERE video_id = ?")->execute([$targetId]);
                    $pdo->prepare("DELETE FROM videos WHERE id = ?")->execute([$targetId]);

                    setFlash('success', 'Video deleted successfully.');
                }
            }
        }
    }
}

// Search and filter parameters
$search = trim($_GET['search'] ?? '');
$catFilter = (int)($_GET['cat'] ?? 0);
$statusFilter = $_GET['status'] ?? '';

$sql = "
    SELECT v.*, c.name AS category_name 
    FROM videos v 
    LEFT JOIN categories c ON v.category_id = c.id 
    WHERE 1=1
";
$params = [];

if (!empty($search)) {
    $sql .= " AND (v.title LIKE ? OR v.description LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

if ($catFilter > 0) {
    $sql .= " AND v.category_id = ?";
    $params[] = $catFilter;
}

if (!empty($statusFilter) && in_array($statusFilter, ['published', 'unpublished'])) {
    $sql .= " AND v.status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY v.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$videos = $stmt->fetchAll();

// Categories for filter
$cats = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll();
?>

<div class="space-y-6">

    <!-- Top Action Header -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-black text-white">Video Library</h1>
            <p class="text-xs text-slate-400 mt-0.5">Manage, publish, edit, or remove videos from the streaming catalogue</p>
        </div>
        <a href="upload.php" class="px-5 py-2.5 rounded-xl text-xs font-bold text-white xvdo-btn-gradient shadow flex items-center gap-2 self-start sm:self-auto">
            <i class="fa-solid fa-plus text-xs"></i>
            <span>Upload New Video</span>
        </a>
    </div>

    <!-- Filters Bar -->
    <div class="bg-[#151B27] border border-[#232C3D] rounded-2xl p-4 shadow">
        <form method="GET" action="videos.php" class="flex flex-wrap items-center justify-between gap-4">
            <div class="flex flex-wrap items-center gap-3 flex-1">
                <!-- Search input -->
                <div class="relative min-w-[200px] flex-1 max-w-xs">
                    <input type="text" name="search" value="<?= e($search) ?>" placeholder="Search by title..."
                           class="w-full bg-[#090C12] text-xs text-white rounded-xl pl-8 pr-3 py-2 border border-[#232C3D] focus:outline-none focus:border-purple-500">
                    <i class="fa-solid fa-magnifying-glass absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 text-xs"></i>
                </div>

                <!-- Category filter -->
                <select name="cat" class="bg-[#090C12] text-xs text-slate-300 rounded-xl px-3 py-2 border border-[#232C3D] focus:outline-none">
                    <option value="0">All Categories</option>
                    <?php foreach ($cats as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= $catFilter === (int)$c['id'] ? 'selected' : '' ?>>
                            <?= e($c['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <!-- Status filter -->
                <select name="status" class="bg-[#090C12] text-xs text-slate-300 rounded-xl px-3 py-2 border border-[#232C3D] focus:outline-none">
                    <option value="">All Statuses</option>
                    <option value="published" <?= $statusFilter === 'published' ? 'selected' : '' ?>>Published</option>
                    <option value="unpublished" <?= $statusFilter === 'unpublished' ? 'selected' : '' ?>>Unpublished</option>
                </select>

                <button type="submit" class="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 transition">
                    Filter
                </button>
            </div>

            <span class="text-xs text-slate-400"><?= count($videos) ?> videos listed</span>
        </form>
    </div>

    <!-- Videos Table -->
    <div class="bg-[#151B27] border border-[#232C3D] rounded-3xl overflow-hidden shadow-xl">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead class="bg-[#0E131E] border-b border-[#232C3D] text-slate-400 uppercase tracking-wider font-bold text-[10px]">
                    <tr>
                        <th class="py-3.5 px-4">Video</th>
                        <th class="py-3.5 px-4">Category</th>
                        <th class="py-3.5 px-4">Duration</th>
                        <th class="py-3.5 px-4">Views</th>
                        <th class="py-3.5 px-4">Featured</th>
                        <th class="py-3.5 px-4">Status</th>
                        <th class="py-3.5 px-4">Date</th>
                        <th class="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#232C3D]/60 text-slate-300">
                    <?php if (empty($videos)): ?>
                        <tr>
                            <td colspan="8" class="text-center py-10 text-slate-500">
                                No videos found matching your filters.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($videos as $v): ?>
                            <tr class="hover:bg-[#1C2333]/50 transition">
                                <!-- Video Thumbnail & Title -->
                                <td class="py-3 px-4">
                                    <div class="flex items-center gap-3">
                                        <img src="<?= e($v['thumbnail_path']) ?>" alt="" class="w-16 aspect-video rounded-lg object-cover bg-black flex-shrink-0">
                                        <div class="max-w-xs">
                                            <a href="../watch.php?id=<?= (int)$v['id'] ?>" target="_blank" class="font-bold text-white hover:text-purple-400 line-clamp-1 transition">
                                                <?= e($v['title']) ?>
                                            </a>
                                            <span class="text-[10px] text-slate-500 uppercase tracking-wider">
                                                <?= $v['video_type'] === 'upload' ? 'Local MP4' : 'External Stream' ?>
                                            </span>
                                        </div>
                                    </div>
                                </td>

                                <!-- Category -->
                                <td class="py-3 px-4 whitespace-nowrap font-medium text-slate-300">
                                    <?= e($v['category_name'] ?: 'None') ?>
                                </td>

                                <!-- Duration -->
                                <td class="py-3 px-4 whitespace-nowrap text-slate-400 font-mono">
                                    <?= e(formatDuration($v['duration'])) ?>
                                </td>

                                <!-- Views -->
                                <td class="py-3 px-4 whitespace-nowrap font-bold text-white">
                                    <?= number_format((int)$v['views']) ?>
                                </td>

                                <!-- Featured Toggle -->
                                <td class="py-3 px-4 whitespace-nowrap">
                                    <form method="POST" action="videos.php">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="video_id" value="<?= (int)$v['id'] ?>">
                                        <input type="hidden" name="action" value="toggle_featured">
                                        <button type="submit" class="px-2 py-0.5 rounded text-[10px] font-bold <?= $v['is_featured'] ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-slate-800 text-slate-500' ?>" title="Click to toggle featured status">
                                            <i class="fa-solid fa-star mr-1"></i><?= $v['is_featured'] ? 'Featured' : 'Standard' ?>
                                        </button>
                                    </form>
                                </td>

                                <!-- Status Toggle -->
                                <td class="py-3 px-4 whitespace-nowrap">
                                    <form method="POST" action="videos.php">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="video_id" value="<?= (int)$v['id'] ?>">
                                        <input type="hidden" name="action" value="toggle_status">
                                        <button type="submit" class="px-2.5 py-1 rounded-full text-[10px] font-semibold <?= $v['status'] === 'published' ? 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20' : 'bg-slate-800 text-slate-400 hover:bg-slate-700' ?>" title="Click to toggle status">
                                            <i class="fa-solid fa-circle text-[7px] mr-1.5 <?= $v['status'] === 'published' ? 'text-emerald-400' : 'text-slate-500' ?>"></i>
                                            <?= ucfirst($v['status']) ?>
                                        </button>
                                    </form>
                                </td>

                                <!-- Date -->
                                <td class="py-3 px-4 whitespace-nowrap text-slate-500 text-[11px]">
                                    <?= date('M j, Y', strtotime($v['created_at'])) ?>
                                </td>

                                <!-- Actions -->
                                <td class="py-3 px-4 text-right whitespace-nowrap">
                                    <div class="flex items-center justify-end gap-2">
                                        <a href="../watch.php?id=<?= (int)$v['id'] ?>" target="_blank" class="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs" title="Preview Video">
                                            <i class="fa-solid fa-eye"></i>
                                        </a>
                                        <a href="edit-video.php?id=<?= (int)$v['id'] ?>" class="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-blue-400 text-xs" title="Edit Video">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </a>
                                        <form method="POST" action="videos.php" onsubmit="return confirm('Permanently delete this video and related data?');" class="inline">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="video_id" value="<?= (int)$v['id'] ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <button type="submit" class="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs" title="Delete">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
