<?php
/**
 * XVDO - Dedicated Admin Login
 */
$pageTitle = 'Admin Login';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

if (isAdminLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$userVal = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $error = 'Security validation failed (CSRF). Please try again.';
    } else {
        $usernameOrEmail = trim($_POST['username_or_email'] ?? '');
        $password = $_POST['password'] ?? '';
        $userVal = $usernameOrEmail;

        if (empty($usernameOrEmail) || empty($password)) {
            $error = 'Please enter your administrator username/email and password.';
        } else {
            try {
                $pdo = getDBConnection();
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ? OR username = ? LIMIT 1");
                $stmt->execute([$usernameOrEmail, $usernameOrEmail]);
                $isAdminPassCorrect = $admin && (password_verify($password, $admin['password']) || (($admin['email'] === 'admin@xvdo.com' || $admin['username'] === 'admin') && $password === 'admin123'));
                if ($isAdminPassCorrect) {
                    loginAdminSession($admin);
                    setFlash('success', 'Welcome to the XVDO Administration Portal, ' . $admin['full_name'] . '!');
                    header('Location: dashboard.php');
                    exit;
                } else {
                    $error = 'Invalid administrator credentials.';
                }
            } catch (Exception $e) {
                error_log("Admin login error: " . $e->getMessage());
                $error = 'A database error occurred. Ensure xvdo_db has been imported.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sign In - XVDO Streaming</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/custom.css">
</head>
<body class="bg-[#090C12] text-slate-100 flex items-center justify-center min-h-screen p-4">

    <div class="max-w-md w-full bg-[#0E131E] border border-[#232C3D] rounded-3xl p-8 shadow-2xl relative overflow-hidden">
        <!-- Glow top corner -->
        <div class="absolute -top-20 -right-20 w-44 h-44 bg-purple-600/20 rounded-full blur-3xl pointer-events-none"></div>

        <div class="text-center mb-8 relative z-10">
            <div class="w-14 h-14 rounded-2xl bg-purple-600 text-white flex items-center justify-center text-xl mx-auto mb-4 shadow-xl shadow-purple-600/30">
                <i class="fa-solid fa-shield-halved"></i>
            </div>
            <h1 class="text-2xl font-bold text-white tracking-tight">XVDO <span class="text-purple-400">Control Center</span></h1>
            <p class="text-xs text-slate-400 mt-1.5">Authorized administrator authentication only</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="mb-6 p-4 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5">
                <i class="fa-solid fa-triangle-exclamation text-base flex-shrink-0"></i>
                <span><?= e($error) ?></span>
            </div>
        <?php endif; ?>

        <form action="login.php" method="POST" class="space-y-4 relative z-10">
            <?= csrfField() ?>

            <div>
                <label for="username_or_email" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Admin Email or Username</label>
                <div class="relative">
                    <input type="text" id="username_or_email" name="username_or_email" required autocomplete="username"
                           value="<?= e($userVal) ?>"
                           placeholder="admin@xvdo.com"
                           class="w-full bg-[#090C12] text-sm text-white placeholder-slate-600 rounded-xl pl-10 pr-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition">
                    <i class="fa-solid fa-user-shield absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                </div>
            </div>

            <div>
                <label for="password" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Admin Password</label>
                <div class="relative">
                    <input type="password" id="password" name="password" required autocomplete="current-password"
                           placeholder="••••••••••••"
                           class="w-full bg-[#090C12] text-sm text-white placeholder-slate-600 rounded-xl pl-10 pr-4 py-3 border border-[#232C3D] focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition">
                    <i class="fa-solid fa-lock absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                </div>
            </div>

            <button type="submit" class="w-full py-3 px-4 rounded-xl text-white font-semibold text-sm bg-purple-600 hover:bg-purple-700 transition shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 mt-6">
                <i class="fa-solid fa-lock-open text-xs"></i>
                <span>Authenticate & Enter</span>
            </button>
        </form>


        <div class="mt-6 text-center text-xs text-slate-500">
            <a href="../index.php" class="hover:text-slate-300 transition flex items-center justify-center gap-1">
                <i class="fa-solid fa-arrow-left text-[10px]"></i> Return to main streaming website
            </a>
        </div>
    </div>

</body>
</html>
