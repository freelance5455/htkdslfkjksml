<?php
/**
 * XVDO - Admin Logout
 */
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

logoutAdmin();
setFlash('info', 'Admin signed out successfully.');
header('Location: login.php');
exit;
