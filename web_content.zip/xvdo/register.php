<?php
/**
 * XVDO - User Registration
 */
$pageTitle = 'Create Account';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

// Redirect if already authenticated
if (isUserLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];
$fullName = '';
$email = '';
$phone = '';

// Handle POST Registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Security token invalid. Please refresh the page and submit again.';
    } else {
        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        // Validation rules
        if (empty($fullName) || mb_strlen($fullName) < 3) {
            $errors[] = 'Full name must be at least 3 characters.';
        }

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'A valid email address is required.';
        }

        if (empty($phone) || strlen($phone) < 7) {
            $errors[] = 'Please enter a valid phone number.';
        }

        if (empty($password) || strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters long.';
        }

        if ($password !== $confirmPassword) {
            $errors[] = 'The password and password confirmation do not match.';
        }

        if (empty($errors)) {
            try {
                $pdo = getDBConnection();

                // Check duplicate email
                $checkStmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
                $checkStmt->execute([$email]);
                if ($checkStmt->fetch()) {
                    $errors[] = 'An account with this email address already exists. Please log in.';
                } else {
                    // Hash password
                    $passwordHash = password_hash($password, PASSWORD_BCRYPT);

                    // Insert user record
                    $insertStmt = $pdo->prepare("
                        INSERT INTO users (full_name, email, phone, password, status, created_at, updated_at) 
                        VALUES (?, ?, ?, ?, 'active', NOW(), NOW())
                    ");
                    $insertStmt->execute([$fullName, $email, $phone, $passwordHash]);
                    $userId = (int)$pdo->lastInsertId();

                    // Automatically authenticate user
                    loginUserSession([
                        'id' => $userId,
                        'full_name' => $fullName,
                        'email' => $email
                    ]);

                    setFlash('success', 'Your XVDO account was created successfully! Welcome aboard, ' . e($fullName) . '.');
                    header('Location: dashboard.php');
                    exit;
                }
            } catch (Exception $e) {
                error_log("Registration error: " . $e->getMessage());
                $errors[] = 'Database error during registration. Please verify your MySQL setup.';
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="max-w-lg mx-auto px-4 py-12 sm:py-20">
    <div class="bg-darkCard border border-darkBorder rounded-3xl p-8 shadow-2xl relative overflow-hidden">
        <div class="text-center mb-8">
            <div class="w-14 h-14 rounded-2xl xvdo-btn-gradient flex items-center justify-center text-white text-xl mx-auto mb-4 shadow-lg shadow-indigo-500/30">
                <i class="fa-solid fa-user-plus"></i>
            </div>
            <h1 class="text-2xl font-bold text-white tracking-tight">Join <span class="xvdo-gradient-text">XVDO</span> Streaming</h1>
            <p class="text-xs text-slate-400 mt-2">Create your free account to watch unlimited high-definition videos</p>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="mb-6 p-4 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs space-y-1.5">
                <?php foreach ($errors as $err): ?>
                    <div class="flex items-center gap-2">
                        <i class="fa-solid fa-circle-exclamation flex-shrink-0"></i>
                        <span><?= e($err) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form action="register.php" method="POST" class="space-y-4">
            <?= csrfField() ?>

            <div>
                <label for="full_name" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Full Name</label>
                <div class="relative">
                    <input type="text" id="full_name" name="full_name" required
                           value="<?= e($fullName) ?>"
                           placeholder="John Doe"
                           class="w-full bg-[#0B0E14] text-sm text-white placeholder-slate-600 rounded-xl pl-10 pr-4 py-2.5 border border-darkBorder focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition">
                    <i class="fa-solid fa-user absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                </div>
            </div>

            <div>
                <label for="email" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Email Address</label>
                <div class="relative">
                    <input type="email" id="email" name="email" required autocomplete="email"
                           value="<?= e($email) ?>"
                           placeholder="john@example.com"
                           class="w-full bg-[#0B0E14] text-sm text-white placeholder-slate-600 rounded-xl pl-10 pr-4 py-2.5 border border-darkBorder focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition">
                    <i class="fa-solid fa-envelope absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                </div>
            </div>

            <div>
                <label for="phone" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Phone Number</label>
                <div class="relative">
                    <input type="tel" id="phone" name="phone" required
                           value="<?= e($phone) ?>"
                           placeholder="+1 (555) 000-1234"
                           class="w-full bg-[#0B0E14] text-sm text-white placeholder-slate-600 rounded-xl pl-10 pr-4 py-2.5 border border-darkBorder focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition">
                    <i class="fa-solid fa-phone absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label for="password" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Password</label>
                    <div class="relative">
                        <input type="password" id="password" name="password" required autocomplete="new-password"
                               placeholder="Min. 6 chars"
                               class="w-full bg-[#0B0E14] text-sm text-white placeholder-slate-600 rounded-xl pl-10 pr-4 py-2.5 border border-darkBorder focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition">
                        <i class="fa-solid fa-lock absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                    </div>
                </div>

                <div>
                    <label for="confirm_password" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Confirm Password</label>
                    <div class="relative">
                        <input type="password" id="confirm_password" name="confirm_password" required autocomplete="new-password"
                               placeholder="Repeat password"
                               class="w-full bg-[#0B0E14] text-sm text-white placeholder-slate-600 rounded-xl pl-10 pr-4 py-2.5 border border-darkBorder focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition">
                        <i class="fa-solid fa-shield-halved absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                    </div>
                </div>
            </div>

            <div class="pt-2">
                <button type="submit" class="w-full py-3 px-4 rounded-xl text-white font-semibold text-sm xvdo-btn-gradient shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2">
                    <i class="fa-solid fa-user-plus text-xs"></i>
                    <span>Create My Account</span>
                </button>
            </div>
        </form>

        <div class="mt-6 text-center text-xs text-slate-400">
            Already registered? 
            <a href="login.php" class="text-blue-400 hover:text-blue-300 font-semibold ml-1">Sign in here</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
