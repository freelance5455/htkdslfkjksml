<?php
/**
 * XVDO - User Profile & Watch History
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireUserLogin();
$user = getCurrentUser();
$pageTitle = 'My Profile';

$successMsg = '';
$errorMsg = '';

// Handle Profile Updates or Password Change
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errorMsg = 'Security validation failed. Please try again.';
    } else {
        $action = $_POST['action'] ?? '';
        $pdo = getDBConnection();

        if ($action === 'update_profile') {
            $fullName = trim($_POST['full_name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');

            if (empty($fullName) || mb_strlen($fullName) < 3) {
                $errorMsg = 'Full name must be at least 3 characters.';
            } else {
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, phone = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$fullName, $phone, $user['id']]);
                $_SESSION['user_name'] = $fullName;
                $user['full_name'] = $fullName;
                $user['phone'] = $phone;
                $successMsg = 'Profile information updated successfully.';
            }
        } elseif ($action === 'change_password') {
            $currentPass = $_POST['current_password'] ?? '';
            $newPass = $_POST['new_password'] ?? '';
            $confirmPass = $_POST['confirm_password'] ?? '';

            $userPassStmt = $pdo->prepare("SELECT password FROM users WHERE id = ? LIMIT 1");
            $userPassStmt->execute([$user['id']]);
            $hashRow = $userPassStmt->fetch();

            if (!$hashRow || !password_verify($currentPass, $hashRow['password'])) {
                $errorMsg = 'Your current password was entered incorrectly.';
            } elseif (strlen($newPass) < 6) {
                $errorMsg = 'New password must be at least 6 characters.';
            } elseif ($newPass !== $confirmPass) {
                $errorMsg = 'New password confirmation does not match.';
            } else {
                $newHash = password_hash($newPass, PASSWORD_BCRYPT);
                $updateStmt = $pdo->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
                $updateStmt->execute([$newHash, $user['id']]);
                $successMsg = 'Password changed successfully.';
            }
        } elseif ($action === 'clear_history') {
            $clearStmt = $pdo->prepare("DELETE FROM watch_history WHERE user_id = ?");
            $clearStmt->execute([$user['id']]);
            $successMsg = 'Watch history cleared successfully.';
        }
    }
}

// Fetch Full Watch History
$watchHistory = [];
try {
    $pdo = getDBConnection();
    $histStmt = $pdo->prepare("
        SELECT wh.id AS history_id, wh.watched_at, v.*, c.name AS category_name 
        FROM watch_history wh 
        JOIN videos v ON wh.video_id = v.id 
        LEFT JOIN categories c ON v.category_id = c.id 
        WHERE wh.user_id = ? 
        ORDER BY wh.watched_at DESC
    ");
    $histStmt->execute([$user['id']]);
    $watchHistory = $histStmt->fetchAll();
} catch (Exception $e) {
    error_log("Profile watch history fetch error: " . $e->getMessage());
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">

    <!-- Profile Overview Card -->
    <div class="bg-gradient-to-r from-darkCard via-darkCard to-indigo-950/30 border border-darkBorder rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
        <div class="flex items-center gap-5 text-center sm:text-left flex-col sm:flex-row">
            <div class="w-20 h-20 rounded-2xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-white text-3xl font-black shadow-xl shadow-indigo-500/20">
                <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
            </div>
            <div>
                <h1 class="text-2xl font-bold text-white"><?= e($user['full_name']) ?></h1>
                <p class="text-xs text-slate-400 mt-0.5"><?= e($user['email']) ?> &bull; <?= e($user['phone'] ?: 'No phone added') ?></p>
                <div class="flex flex-wrap items-center gap-2 mt-2 justify-center sm:justify-start">
                    <span class="px-2.5 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        <i class="fa-solid fa-check-circle mr-1"></i>Active Account
                    </span>
                    <span class="text-[11px] text-slate-500">
                        Member since <?= date('M Y', strtotime($user['created_at'])) ?>
                    </span>
                </div>
            </div>
        </div>

        <a href="logout.php" class="px-5 py-2.5 rounded-xl text-xs font-semibold text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 transition flex items-center gap-2">
            <i class="fa-solid fa-arrow-right-from-bracket"></i>
            <span>Sign Out</span>
        </a>
    </div>

    <?php if (!empty($successMsg)): ?>
        <div class="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2.5">
            <i class="fa-solid fa-circle-check text-base"></i>
            <span><?= e($successMsg) ?></span>
        </div>
    <?php endif; ?>

    <?php if (!empty($errorMsg)): ?>
        <div class="p-4 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2.5">
            <i class="fa-solid fa-circle-exclamation text-base"></i>
            <span><?= e($errorMsg) ?></span>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- Left Column: Edit Info & Password (5 cols) -->
        <div class="lg:col-span-5 space-y-6">

            <!-- Edit Personal Info -->
            <div class="bg-darkCard border border-darkBorder rounded-3xl p-6 shadow-xl space-y-4">
                <h3 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <i class="fa-solid fa-user-pen text-blue-400"></i> Edit Profile Details
                </h3>

                <form action="profile.php" method="POST" class="space-y-4">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="update_profile">

                    <div>
                        <label for="full_name" class="block text-xs font-semibold uppercase text-slate-400 mb-1">Full Name</label>
                        <input type="text" id="full_name" name="full_name" required value="<?= e($user['full_name']) ?>"
                               class="w-full bg-[#0B0E14] text-sm text-white rounded-xl px-3.5 py-2.5 border border-darkBorder focus:outline-none focus:border-blue-500">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold uppercase text-slate-400 mb-1">Email Address (Locked)</label>
                        <input type="email" disabled value="<?= e($user['email']) ?>"
                               class="w-full bg-slate-900/60 text-sm text-slate-500 rounded-xl px-3.5 py-2.5 border border-darkBorder cursor-not-allowed">
                        <span class="text-[10px] text-slate-500 mt-1 block">Contact administrator to modify primary email</span>
                    </div>

                    <div>
                        <label for="phone" class="block text-xs font-semibold uppercase text-slate-400 mb-1">Phone Number</label>
                        <input type="text" id="phone" name="phone" value="<?= e($user['phone']) ?>"
                               class="w-full bg-[#0B0E14] text-sm text-white rounded-xl px-3.5 py-2.5 border border-darkBorder focus:outline-none focus:border-blue-500">
                    </div>

                    <button type="submit" class="w-full py-2.5 rounded-xl text-xs font-bold text-white xvdo-btn-gradient shadow">
                        Save Profile Changes
                    </button>
                </form>
            </div>

            <!-- Change Password Card -->
            <div class="bg-darkCard border border-darkBorder rounded-3xl p-6 shadow-xl space-y-4">
                <h3 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <i class="fa-solid fa-lock text-purple-400"></i> Change Password
                </h3>

                <form action="profile.php" method="POST" class="space-y-4">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="change_password">

                    <div>
                        <label for="current_password" class="block text-xs font-semibold uppercase text-slate-400 mb-1">Current Password</label>
                        <input type="password" id="current_password" name="current_password" required
                               class="w-full bg-[#0B0E14] text-sm text-white rounded-xl px-3.5 py-2.5 border border-darkBorder focus:outline-none focus:border-purple-500">
                    </div>

                    <div>
                        <label for="new_password" class="block text-xs font-semibold uppercase text-slate-400 mb-1">New Password</label>
                        <input type="password" id="new_password" name="new_password" required minlength="6"
                               class="w-full bg-[#0B0E14] text-sm text-white rounded-xl px-3.5 py-2.5 border border-darkBorder focus:outline-none focus:border-purple-500">
                    </div>

                    <div>
                        <label for="confirm_password" class="block text-xs font-semibold uppercase text-slate-400 mb-1">Confirm New Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required minlength="6"
                               class="w-full bg-[#0B0E14] text-sm text-white rounded-xl px-3.5 py-2.5 border border-darkBorder focus:outline-none focus:border-purple-500">
                    </div>

                    <button type="submit" class="w-full py-2.5 rounded-xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 transition shadow">
                        Update Password
                    </button>
                </form>
            </div>

        </div>

        <!-- Right Column: Watch History (7 cols) -->
        <div id="history" class="lg:col-span-7 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-darkBorder">
                <div>
                    <h3 class="text-base font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-clock-rotate-left text-blue-400"></i> My Watch History
                    </h3>
                    <p class="text-xs text-slate-400 mt-0.5">Videos you have streamed on XVDO</p>
                </div>

                <?php if (!empty($watchHistory)): ?>
                    <form action="profile.php" method="POST" onsubmit="return confirm('Clear your entire streaming watch history?');">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="clear_history">
                        <button type="submit" class="text-xs text-rose-400 hover:text-rose-300 font-semibold px-2 py-1 rounded hover:bg-rose-500/10 transition">
                            <i class="fa-solid fa-trash-can mr-1"></i> Clear History
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <?php if (empty($watchHistory)): ?>
                <div class="bg-darkCard border border-darkBorder rounded-3xl p-10 text-center">
                    <i class="fa-solid fa-film text-3xl text-slate-600 mb-2"></i>
                    <p class="text-sm font-semibold text-slate-300">No watch history yet</p>
                    <p class="text-xs text-slate-500 mt-1">Videos you watch will automatically be logged here.</p>
                    <a href="dashboard.php" class="mt-4 inline-flex items-center gap-1.5 text-xs text-blue-400 font-semibold hover:underline">
                        Explore streams <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>
            <?php else: ?>
                <div class="space-y-3">
                    <?php foreach ($watchHistory as $item): ?>
                        <div class="bg-darkCard border border-darkBorder rounded-2xl p-3 flex gap-4 items-center justify-between shadow">
                            <div class="flex gap-3 items-center overflow-hidden">
                                <a href="watch.php?id=<?= (int)$item['id'] ?>" class="relative w-28 sm:w-36 aspect-video rounded-xl overflow-hidden bg-black flex-shrink-0 group">
                                    <img src="<?= e($item['thumbnail_path']) ?>" alt="<?= e($item['title']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform">
                                    <span class="absolute bottom-1 right-1 bg-black/80 backdrop-blur text-white text-[9px] font-semibold px-1 rounded">
                                        <?= e(formatDuration($item['duration'])) ?>
                                    </span>
                                </a>
                                <div class="overflow-hidden">
                                    <span class="text-[10px] font-semibold text-blue-400 uppercase tracking-wider block">
                                        <?= e($item['category_name'] ?: 'Video') ?>
                                    </span>
                                    <a href="watch.php?id=<?= (int)$item['id'] ?>" class="text-xs sm:text-sm font-bold text-white hover:text-blue-400 line-clamp-1 block transition">
                                        <?= e($item['title']) ?>
                                    </a>
                                    <span class="text-[10px] text-slate-500 block mt-1">
                                        Streamed <?= timeAgo($item['watched_at']) ?>
                                    </span>
                                </div>
                            </div>

                            <a href="watch.php?id=<?= (int)$item['id'] ?>" class="p-2 sm:px-3 sm:py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 flex-shrink-0 transition">
                                <i class="fa-solid fa-play text-[10px]"></i>
                                <span class="hidden sm:inline">Watch Again</span>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
