-- =====================================================================
-- XVDO - Next-Generation Video Streaming Web Application
-- Complete MySQL Database Schema and Seed Data
-- =====================================================================

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS `xvdo_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `xvdo_db`;

-- Disable foreign key checks during import
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- Table 1: users
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `phone` VARCHAR(30) NULL,
  `password` VARCHAR(255) NOT NULL,
  `status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  `avatar` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  INDEX `idx_users_email` (`email`),
  INDEX `idx_users_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 2: admins
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `role` VARCHAR(50) NOT NULL DEFAULT 'superadmin',
  `created_at` DATETIME NOT NULL,
  INDEX `idx_admins_email` (`email`),
  INDEX `idx_admins_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 3: categories
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `description` TEXT NULL,
  `icon` VARCHAR(100) NOT NULL DEFAULT 'fa-solid fa-film',
  `created_at` DATETIME NOT NULL,
  INDEX `idx_categories_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 4: videos
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `videos`;
CREATE TABLE `videos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `video_type` ENUM('upload', 'url') NOT NULL DEFAULT 'url',
  `video_path` TEXT NOT NULL,
  `thumbnail_path` TEXT NOT NULL,
  `duration` VARCHAR(20) NOT NULL DEFAULT '00:00',
  `views` INT UNSIGNED NOT NULL DEFAULT 0,
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
  `status` ENUM('published', 'unpublished') NOT NULL DEFAULT 'published',
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  INDEX `idx_videos_category` (`category_id`),
  INDEX `idx_videos_status` (`status`),
  INDEX `idx_videos_featured` (`is_featured`),
  INDEX `idx_videos_views` (`views`),
  CONSTRAINT `fk_videos_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 5: watch_history
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `watch_history`;
CREATE TABLE `watch_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `video_id` INT NOT NULL,
  `watched_at` DATETIME NOT NULL,
  `duration_watched` INT NOT NULL DEFAULT 0,
  INDEX `idx_history_user` (`user_id`),
  INDEX `idx_history_video` (`video_id`),
  CONSTRAINT `fk_history_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_history_video` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 6: video_views
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `video_views`;
CREATE TABLE `video_views` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `video_id` INT NOT NULL,
  `user_id` INT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `user_agent` VARCHAR(255) NULL,
  `viewed_at` DATETIME NOT NULL,
  INDEX `idx_views_video` (`video_id`),
  INDEX `idx_views_user` (`user_id`),
  CONSTRAINT `fk_views_video` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_views_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 7: settings
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `setting_key` VARCHAR(100) NOT NULL UNIQUE,
  `setting_value` TEXT NULL,
  `updated_at` DATETIME NOT NULL,
  INDEX `idx_settings_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;


-- =====================================================================
-- INITIAL SEED DATA
-- =====================================================================

-- 1. Default Super Administrator
-- Credentials: Email: admin@xvdo.com | Password: admin123
INSERT INTO `admins` (`id`, `username`, `email`, `password`, `full_name`, `role`, `created_at`) 
VALUES (1, 'admin', 'admin@xvdo.com', '$2y$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW', 'XVDO Administrator', 'superadmin', NOW());

-- 2. Default Demo User
-- Credentials: Email: demo@xvdo.com | Password: user123
INSERT INTO `users` (`id`, `full_name`, `email`, `phone`, `password`, `status`, `avatar`, `created_at`, `updated_at`) 
VALUES (1, 'Alex Rivera', 'demo@xvdo.com', '+1 (555) 234-5678', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', NULL, NOW(), NOW());

-- 3. Categories
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `icon`, `created_at`) VALUES
(1, 'Action & Thrillers', 'action', 'Heart-pounding chases, martial arts battles, and explosive cinematic action sequences.', 'fa-solid fa-fire', NOW()),
(2, 'Sci-Fi & Cyber', 'sci-fi', 'Futuristic cyberpunk worlds, artificial intelligence sagas, and deep space exploration.', 'fa-solid fa-robot', NOW()),
(3, 'Documentaries', 'documentaries', 'Deep-dive investigative investigations, technological breakthroughs, and history.', 'fa-solid fa-earth-americas', NOW()),
(4, 'Tech & Gaming', 'tech-gaming', 'Next-gen gaming walkthroughs, unreal engine showcases, hardware engineering and coding.', 'fa-solid fa-gamepad', NOW()),
(5, 'Nature & Wildlife', 'nature', 'Stunning 4K visual expeditions through lush rainforests, deep oceans, and arctic tundra.', 'fa-solid fa-tree', NOW()),
(6, 'Music & Soundtracks', 'music', 'Original cinematic scores, synthwave live streams, and audiovisual spectacles.', 'fa-solid fa-headphones', NOW());

-- 4. Initial Streaming Videos
INSERT INTO `videos` (`id`, `category_id`, `title`, `description`, `video_type`, `video_path`, `thumbnail_path`, `duration`, `views`, `is_featured`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 'Tears of Steel: Cyberpunk Sci-Fi Odyssey', 'Set in a dystopian future where humanity struggles for survival against automated robotic legions in Amsterdam. Exploring cybernetic enhancements, rogue drones, and neural interfaces.', 'url', 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4', 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1200&auto=format&fit=crop&q=80', '12:14', 18450, 1, 'published', NOW(), NOW()),

(2, 5, 'Big Buck Bunny: The Wild Forest Adventure', 'A large, gentle forest rabbit seeks retribution against a trio of mischievous bullying woodland creatures. Full 4K remaster with rich orchestral sound effects and pristine animation.', 'url', 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', 'https://images.unsplash.com/photo-1535083783855-76ae62b2914e?w=1200&auto=format&fit=crop&q=80', '09:56', 29310, 0, 'published', NOW(), NOW()),

(3, 1, 'Sintel: The Dragon Chronicles', 'A lonely nomad searches the desolate mountain badlands for her lost companion, an orphaned baby dragon kidnapped by an airborne beast. An emotional fantasy quest.', 'url', 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4', 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&auto=format&fit=crop&q=80', '14:48', 42100, 0, 'published', NOW(), NOW()),

(4, 4, 'Cyber Runner 2099 - Unreal Engine 5 Showcase', 'Incredible real-time ray-traced visuals through a neon-drenched metropolis with reflections, dynamic weather cycles, and high-octane flying vehicle pursuits.', 'url', 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4', 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&auto=format&fit=crop&q=80', '10:54', 15280, 0, 'published', NOW(), NOW()),

(5, 3, 'Deep Ocean Wonders: Bioluminescent Abyss', 'Journey down past 3,000 meters into the Mariana Trench and midnight zone to witness luminous jellyfish, siphonophores, and uncharted deep-sea ecosystems.', 'url', 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4', 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=1200&auto=format&fit=crop&q=80', '08:22', 8720, 0, 'published', NOW(), NOW()),

(6, 6, 'Synthwave Sunset: Neon Beats & Retrowave Visuals', 'An 80s inspired retro-future journey across neon grids, grid-lines, and sunset horizons accompanied by analog synthesizer arpeggios and punchy drum machines.', 'url', 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4', 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=1200&auto=format&fit=crop&q=80', '06:15', 6590, 0, 'published', NOW(), NOW()),

(7, 2, 'Chronos: The Relativistic Space Voyage', 'A crew aboard an interstellar generational ship encounters a spinning black hole where gravitational time dilation causes minutes to equal decades on Earth.', 'url', 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4', 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200&auto=format&fit=crop&q=80', '11:30', 12340, 0, 'published', NOW(), NOW()),

(8, 4, 'Quantum Computing Architecture: Behind The Silicon', 'Inside the cryogenic dilution refrigerators where superconducting qubits are stabilized at near absolute zero temperatures to solve impossible mathematical equations.', 'url', 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4', 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1200&auto=format&fit=crop&q=80', '15:10', 9410, 0, 'published', NOW(), NOW());

-- 5. Initial Watch History for Demo User
INSERT INTO `watch_history` (`user_id`, `video_id`, `watched_at`, `duration_watched`) VALUES
(1, 1, DATE_SUB(NOW(), INTERVAL 2 HOUR), 500),
(1, 2, DATE_SUB(NOW(), INTERVAL 1 DAY), 320),
(1, 4, DATE_SUB(NOW(), INTERVAL 3 DAY), 600);

-- 6. Platform Settings
INSERT INTO `settings` (`setting_key`, `setting_value`, `updated_at`) VALUES
('site_name', 'XVDO', NOW()),
('site_tagline', 'Next-Generation High-Definition Video Streaming', NOW()),
('site_logo', '', NOW()),
('contact_email', 'support@xvdo.com', NOW()),
('allow_registrations', '1', NOW());
