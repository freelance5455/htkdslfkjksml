<?php
/**
 * XVDO - Search Page
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$query = trim($_GET['q'] ?? '');
$categoryFilter = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$sortBy = $_GET['sort'] ?? 'latest';

$results = [];
$categories = [];

try {
    $pdo = getDBConnection();

    // Fetch categories for filter dropdown
    $catStmt = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
    $categories = $catStmt->fetchAll();

    // Build search query safely
    $sql = "
        SELECT v.*, c.name AS category_name, c.slug AS category_slug 
        FROM videos v 
        LEFT JOIN categories c ON v.category_id = c.id 
        WHERE v.status = 'published'
    ";
    $params = [];

    if (!empty($query)) {
        $sql .= " AND (v.title LIKE ? OR v.description LIKE ?)";
        $searchTerm = '%' . $query . '%';
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }

    if ($categoryFilter > 0) {
        $sql .= " AND v.category_id = ?";
        $params[] = $categoryFilter;
    }

    $sql .= match ($sortBy) {
        'popular' => " ORDER BY v.views DESC, v.id DESC",
        'oldest' => " ORDER BY v.id ASC",
        default => " ORDER BY v.id DESC"
    };

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll();

} catch (Exception $e) {
    error_log("Search error: " . $e->getMessage());
}

$pageTitle = !empty($query) ? 'Search: ' . $query : 'Search Videos';
require_once __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">

    <!-- Search Bar & Filters Form -->
    <div class="bg-darkCard border border-darkBorder rounded-3xl p-6 sm:p-8 shadow-xl">
        <form action="search.php" method="GET" class="space-y-4">
            <div class="relative">
                <input type="text" name="q" value="<?= e($query) ?>" 
                       placeholder="Search videos by title, actor, topic or keywords..." 
                       class="w-full bg-[#0B0E14] text-white text-base rounded-2xl pl-12 pr-4 py-3.5 border border-darkBorder focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 shadow-inner transition">
                <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-lg"></i>
            </div>

            <div class="flex flex-wrap items-center justify-between gap-4 pt-1">
                <div class="flex flex-wrap items-center gap-3">
                    <!-- Category Filter -->
                    <div class="flex items-center gap-2">
                        <label for="cat" class="text-xs text-slate-400 font-medium">Category:</label>
                        <select name="cat" id="cat" class="bg-[#0B0E14] border border-darkBorder text-slate-300 text-xs rounded-xl px-3 py-2 focus:outline-none">
                            <option value="0">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= (int)$cat['id'] ?>" <?= $categoryFilter === (int)$cat['id'] ? 'selected' : '' ?>>
                                    <?= e($cat['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Sort Order -->
                    <div class="flex items-center gap-2">
                        <label for="sort" class="text-xs text-slate-400 font-medium">Sort:</label>
                        <select name="sort" id="sort" class="bg-[#0B0E14] border border-darkBorder text-slate-300 text-xs rounded-xl px-3 py-2 focus:outline-none">
                            <option value="latest" <?= $sortBy === 'latest' ? 'selected' : '' ?>>Latest First</option>
                            <option value="popular" <?= $sortBy === 'popular' ? 'selected' : '' ?>>Most Popular</option>
                            <option value="oldest" <?= $sortBy === 'oldest' ? 'selected' : '' ?>>Oldest First</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="px-6 py-2.5 rounded-xl text-xs font-bold text-white xvdo-btn-gradient shadow flex items-center gap-2">
                    <i class="fa-solid fa-filter text-xs"></i>
                    <span>Apply Filters</span>
                </button>
            </div>
        </form>
    </div>

    <!-- Results Header -->
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-bold text-white flex items-center gap-2">
                <i class="fa-solid fa-list-check text-blue-400"></i>
                <?php if (!empty($query)): ?>
                    Results for "<span class="text-blue-400"><?= e($query) ?></span>"
                <?php else: ?>
                    All Videos
                <?php endif; ?>
            </h1>
            <p class="text-xs text-slate-400 mt-0.5">Found <?= count($results) ?> <?= count($results) === 1 ? 'match' : 'matches' ?></p>
        </div>
    </div>

    <!-- Search Results Grid -->
    <?php if (empty($results)): ?>
        <div class="bg-darkCard border border-darkBorder rounded-3xl p-12 text-center max-w-md mx-auto my-8">
            <div class="w-14 h-14 rounded-2xl bg-slate-800 text-slate-500 flex items-center justify-center text-xl mx-auto mb-4">
                <i class="fa-solid fa-magnifying-glass"></i>
            </div>
            <h3 class="text-base font-bold text-white">No results found</h3>
            <p class="text-xs text-slate-400 mt-1">We couldn't find any streams matching your search terms. Try searching for different keywords.</p>
            <a href="dashboard.php" class="mt-4 inline-flex items-center gap-2 text-xs font-semibold text-blue-400 hover:text-blue-300">
                <i class="fa-solid fa-arrow-left text-[10px]"></i> Return to Dashboard
            </a>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            <?php foreach ($results as $video): ?>
                <div class="video-card bg-darkCard border border-darkBorder rounded-2xl overflow-hidden shadow-lg flex flex-col">
                    <a href="watch.php?id=<?= (int)$video['id'] ?>" class="relative block aspect-video overflow-hidden bg-black group">
                        <img src="<?= e($video['thumbnail_path']) ?>" alt="<?= e($video['title']) ?>" class="video-card-thumb w-full h-full object-cover">
                        <div class="absolute bottom-2 right-2 bg-black/80 backdrop-blur text-white text-[11px] font-semibold px-2 py-0.5 rounded">
                            <?= e(formatDuration($video['duration'])) ?>
                        </div>
                        <div class="video-card-play-overlay absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 transition-opacity">
                            <div class="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm shadow-lg">
                                <i class="fa-solid fa-play ml-0.5"></i>
                            </div>
                        </div>
                    </a>

                    <div class="p-3.5 flex flex-col flex-grow justify-between">
                        <div>
                            <div class="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                                <span class="text-blue-400 font-semibold"><?= e($video['category_name'] ?: 'Video') ?></span>
                                <span><i class="fa-solid fa-eye mr-1"></i><?= formatViews((int)$video['views']) ?></span>
                            </div>
                            <a href="watch.php?id=<?= (int)$video['id'] ?>" class="text-sm font-bold text-white hover:text-blue-400 line-clamp-2 transition leading-snug">
                                <?= e($video['title']) ?>
                            </a>
                        </div>
                        <div class="text-[11px] text-slate-500 pt-2 border-t border-darkBorder/40 mt-3 flex items-center justify-between">
                            <span><?= timeAgo($video['created_at']) ?></span>
                            <span class="text-xs text-blue-400 font-semibold hover:underline">Watch</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
