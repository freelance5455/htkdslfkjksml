<?php
/**
 * XVDO - User Logout
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

logoutUser();
setFlash('info', 'You have been successfully signed out.');
header('Location: login.php');
exit;
