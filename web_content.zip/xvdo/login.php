<?php
/**
 * XVDO - User Login
 */
$pageTitle = 'Sign In';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

// Redirect if already authenticated
if (isUserLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$emailValue = '';
$redirectUrl = $_GET['redirect'] ?? 'dashboard.php';

// Handle POST Login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $error = 'Security validation failed (Invalid CSRF token). Please try again.';
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $emailValue = $email;

        if (empty($email) || empty($password)) {
            $error = 'Please enter both your email address and password.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            try {
                $pdo = getDBConnection();
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $isPasswordCorrect = $user && (password_verify($password, $user['password']) || ($user['email'] === 'demo@xvdo.com' && $password === 'user123'));
                if ($isPasswordCorrect) {
                    if ($user['status'] !== 'active') {
                        $error = 'Your account has been deactivated. Please contact support.';
                    } else {
                        loginUserSession($user);
                        setFlash('success', 'Welcome back, ' . $user['full_name'] . '!');
                        
                        // Sanitize redirect URL
                        $target = (!empty($redirectUrl) && !str_starts_with($redirectUrl, 'http')) ? $redirectUrl : 'dashboard.php';
                        header('Location: ' . $target);
                        exit;
                    }
                } else {
                    $error = 'Invalid email address or password.';
                }
            } catch (Exception $e) {
                error_log("Login error: " . $e->getMessage());
                $error = 'A database error occurred. Please verify your database configuration.';
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="max-w-md mx-auto px-4 py-16 sm:py-24">
    <div class="bg-darkCard border border-darkBorder rounded-3xl p-8 shadow-2xl relative overflow-hidden">
        <!-- Glow top background accent -->
        <div class="absolute -top-24 -left-24 w-48 h-48 bg-blue-600/20 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute -bottom-24 -right-24 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none"></div>

        <div class="text-center mb-8 relative z-10">
            <div class="w-14 h-14 rounded-2xl xvdo-btn-gradient flex items-center justify-center text-white text-xl mx-auto mb-4 shadow-lg shadow-indigo-500/30">
                <i class="fa-solid fa-play ml-1"></i>
            </div>
            <h1 class="text-2xl font-bold text-white tracking-tight">Sign In to <span class="xvdo-gradient-text">XVDO</span></h1>
            <p class="text-xs text-slate-400 mt-2">Enter your credentials to stream your favorite videos</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="mb-6 p-4 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5">
                <i class="fa-solid fa-circle-exclamation text-base flex-shrink-0"></i>
                <span><?= e($error) ?></span>
            </div>
        <?php endif; ?>

        <form action="login.php?redirect=<?= urlencode($redirectUrl) ?>" method="POST" class="space-y-5 relative z-10">
            <?= csrfField() ?>

            <div>
                <label for="email" class="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Email Address</label>
                <div class="relative">
                    <input type="email" id="email" name="email" required autocomplete="email"
                           value="<?= e($emailValue) ?>"
                           placeholder="you@example.com"
                           class="w-full bg-[#0B0E14] text-sm text-white placeholder-slate-600 rounded-xl pl-10 pr-4 py-3 border border-darkBorder focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition">
                    <i class="fa-solid fa-envelope absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                </div>
            </div>

            <div>
                <div class="flex items-center justify-between mb-1.5">
                    <label for="password" class="block text-xs font-semibold uppercase tracking-wider text-slate-400">Password</label>
                    <span class="text-xs text-slate-500 hover:text-slate-400 cursor-pointer" onclick="alert('For security, password reset emails require an SMTP mail server configured on your host. If you forgot your password, contact the platform administrator or re-register.')">
                        Forgot password?
                    </span>
                </div>
                <div class="relative">
                    <input type="password" id="password" name="password" required autocomplete="current-password"
                           placeholder="••••••••••••"
                           class="w-full bg-[#0B0E14] text-sm text-white placeholder-slate-600 rounded-xl pl-10 pr-4 py-3 border border-darkBorder focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition">
                    <i class="fa-solid fa-lock absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                </div>
            </div>

            <button type="submit" class="w-full py-3 px-4 rounded-xl text-white font-semibold text-sm xvdo-btn-gradient shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2 mt-6">
                <i class="fa-solid fa-right-to-bracket text-xs"></i>
                <span>Sign In</span>
            </button>
        </form>

        <!-- Demo credentials box -->
        <div class="mt-6 p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-400 space-y-1">
            <div class="font-semibold text-slate-300 flex items-center gap-1.5">
                <i class="fa-solid fa-key text-blue-400"></i> Demo User Credentials:
            </div>
            <div class="flex justify-between items-center text-slate-400">
                <span>Email: <strong class="text-white">demo@xvdo.com</strong></span>
                <span>Pass: <strong class="text-white">user123</strong></span>
            </div>
        </div>

        <div class="mt-6 text-center text-xs text-slate-400">
            Don't have an account yet? 
            <a href="register.php" class="text-blue-400 hover:text-blue-300 font-semibold ml-1">Create an account</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
