<?php
/**
 * XVDO - Category Video Browser
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$slug = trim($_GET['slug'] ?? '');
if (empty($slug)) {
    header('Location: dashboard.php');
    exit;
}

$category = null;
$videos = [];
$sortBy = $_GET['sort'] ?? 'latest';

try {
    $pdo = getDBConnection();

    // Fetch category
    $catStmt = $pdo->prepare("SELECT * FROM categories WHERE slug = ? LIMIT 1");
    $catStmt->execute([$slug]);
    $category = $catStmt->fetch();

    if (!$category) {
        setFlash('warning', 'Category not found.');
        header('Location: dashboard.php');
        exit;
    }

    // Determine sorting order
    $orderBy = match ($sortBy) {
        'popular' => 'v.views DESC, v.id DESC',
        'oldest' => 'v.id ASC',
        default => 'v.id DESC'
    };

    // Fetch videos for this category
    $videoStmt = $pdo->prepare("
        SELECT v.*, c.name AS category_name, c.slug AS category_slug 
        FROM videos v 
        JOIN categories c ON v.category_id = c.id 
        WHERE v.category_id = ? AND v.status = 'published' 
        ORDER BY {$orderBy}
    ");
    $videoStmt->execute([$category['id']]);
    $videos = $videoStmt->fetchAll();

} catch (Exception $e) {
    error_log("Category page error: " . $e->getMessage());
}

$pageTitle = $category ? $category['name'] : 'Category';
require_once __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">

    <!-- Category Header Banner -->
    <div class="bg-gradient-to-r from-darkCard via-darkCard to-indigo-950/30 border border-darkBorder rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 shadow-xl">
        <div class="flex items-center gap-4">
            <div class="w-16 h-16 rounded-2xl bg-purple-600/20 border border-purple-500/30 text-purple-400 flex items-center justify-center text-2xl shadow-lg">
                <i class="<?= e($category['icon'] ?: 'fa-solid fa-shapes') ?>"></i>
            </div>
            <div>
                <div class="flex items-center gap-2">
                    <span class="text-xs uppercase font-bold tracking-wider text-purple-400">Category</span>
                    <span class="text-xs text-slate-500">&bull;</span>
                    <span class="text-xs text-slate-400"><?= count($videos) ?> <?= count($videos) === 1 ? 'Video' : 'Videos' ?></span>
                </div>
                <h1 class="text-2xl sm:text-3xl font-extrabold text-white mt-0.5"><?= e($category['name']) ?></h1>
                <?php if (!empty($category['description'])): ?>
                    <p class="text-xs text-slate-400 mt-1 max-w-xl"><?= e($category['description']) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sorting selector -->
        <form method="GET" action="category.php" class="flex items-center gap-2">
            <input type="hidden" name="slug" value="<?= e($slug) ?>">
            <label for="sort" class="text-xs text-slate-400 font-semibold whitespace-nowrap">Sort by:</label>
            <select name="sort" id="sort" onchange="this.form.submit()" 
                    class="bg-[#0B0E14] border border-darkBorder text-slate-300 text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-purple-500">
                <option value="latest" <?= $sortBy === 'latest' ? 'selected' : '' ?>>Latest Releases</option>
                <option value="popular" <?= $sortBy === 'popular' ? 'selected' : '' ?>>Most Popular</option>
                <option value="oldest" <?= $sortBy === 'oldest' ? 'selected' : '' ?>>Oldest First</option>
            </select>
        </form>
    </div>

    <!-- Video Grid -->
    <?php if (empty($videos)): ?>
        <div class="bg-darkCard border border-darkBorder rounded-3xl p-12 text-center max-w-md mx-auto my-8">
            <div class="w-14 h-14 rounded-2xl bg-slate-800 text-slate-500 flex items-center justify-center text-xl mx-auto mb-4">
                <i class="fa-solid fa-video-slash"></i>
            </div>
            <h3 class="text-base font-bold text-white">No videos found</h3>
            <p class="text-xs text-slate-400 mt-1">There are currently no published videos in this category.</p>
            <a href="dashboard.php" class="mt-4 inline-flex items-center gap-2 text-xs font-semibold text-blue-400 hover:text-blue-300">
                <i class="fa-solid fa-arrow-left text-[10px]"></i> Back to all categories
            </a>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            <?php foreach ($videos as $video): ?>
                <div class="video-card bg-darkCard border border-darkBorder rounded-2xl overflow-hidden shadow-lg flex flex-col">
                    <a href="watch.php?id=<?= (int)$video['id'] ?>" class="relative block aspect-video overflow-hidden bg-black group">
                        <img src="<?= e($video['thumbnail_path']) ?>" alt="<?= e($video['title']) ?>" class="video-card-thumb w-full h-full object-cover">
                        <div class="absolute bottom-2 right-2 bg-black/80 backdrop-blur text-white text-[11px] font-semibold px-2 py-0.5 rounded">
                            <?= e(formatDuration($video['duration'])) ?>
                        </div>
                        <div class="video-card-play-overlay absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 transition-opacity">
                            <div class="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm shadow-lg">
                                <i class="fa-solid fa-play ml-0.5"></i>
                            </div>
                        </div>
                    </a>

                    <div class="p-3.5 flex flex-col flex-grow justify-between">
                        <div>
                            <div class="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                                <span class="text-purple-400 font-semibold"><?= e($category['name']) ?></span>
                                <span><i class="fa-solid fa-eye mr-1"></i><?= formatViews((int)$video['views']) ?> views</span>
                            </div>
                            <a href="watch.php?id=<?= (int)$video['id'] ?>" class="text-sm font-bold text-white hover:text-blue-400 line-clamp-2 transition leading-snug">
                                <?= e($video['title']) ?>
                            </a>
                        </div>
                        <div class="text-[11px] text-slate-500 pt-2 border-t border-darkBorder/40 mt-3 flex items-center justify-between">
                            <span>Uploaded <?= timeAgo($video['created_at']) ?></span>
                            <span class="text-xs text-blue-400 font-semibold hover:underline">Watch</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
