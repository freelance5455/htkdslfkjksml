<?php
/**
 * XVDO - User Streaming Dashboard
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireUserLogin();
$user = getCurrentUser();
$pageTitle = 'Dashboard';

$featuredVideo = null;
$recentlyWatched = [];
$latestVideos = [];
$popularVideos = [];
$categories = [];

try {
    $pdo = getDBConnection();

    // 1. Featured Video (hero)
    $featStmt = $pdo->query("
        SELECT v.*, c.name AS category_name, c.slug AS category_slug 
        FROM videos v 
        LEFT JOIN categories c ON v.category_id = c.id 
        WHERE v.status = 'published' AND v.is_featured = 1 
        ORDER BY v.id DESC LIMIT 1
    ");
    $featuredVideo = $featStmt->fetch();

    if (!$featuredVideo) {
        $featFallback = $pdo->query("
            SELECT v.*, c.name AS category_name, c.slug AS category_slug 
            FROM videos v 
            LEFT JOIN categories c ON v.category_id = c.id 
            WHERE v.status = 'published' 
            ORDER BY v.views DESC LIMIT 1
        ");
        $featuredVideo = $featFallback->fetch();
    }

    // 2. Recently Watched Videos by this user
    $historyStmt = $pdo->prepare("
        SELECT wh.watched_at, v.*, c.name AS category_name, c.slug AS category_slug 
        FROM watch_history wh 
        JOIN videos v ON wh.video_id = v.id 
        LEFT JOIN categories c ON v.category_id = c.id 
        WHERE wh.user_id = ? AND v.status = 'published' 
        ORDER BY wh.watched_at DESC LIMIT 6
    ");
    $historyStmt->execute([$user['id']]);
    $recentlyWatched = $historyStmt->fetchAll();

    // 3. Latest Uploaded Videos
    $latestStmt = $pdo->query("
        SELECT v.*, c.name AS category_name, c.slug AS category_slug 
        FROM videos v 
        LEFT JOIN categories c ON v.category_id = c.id 
        WHERE v.status = 'published' 
        ORDER BY v.id DESC LIMIT 8
    ");
    $latestVideos = $latestStmt->fetchAll();

    // 4. Popular Videos (sorted by views)
    $popularStmt = $pdo->query("
        SELECT v.*, c.name AS category_name, c.slug AS category_slug 
        FROM videos v 
        LEFT JOIN categories c ON v.category_id = c.id 
        WHERE v.status = 'published' 
        ORDER BY v.views DESC LIMIT 8
    ");
    $popularVideos = $popularStmt->fetchAll();

    // 5. Video Categories
    $catStmt = $pdo->query("
        SELECT c.*, COUNT(v.id) AS video_count 
        FROM categories c 
        LEFT JOIN videos v ON c.id = v.category_id AND v.status = 'published' 
        GROUP BY c.id 
        ORDER BY c.name ASC
    ");
    $categories = $catStmt->fetchAll();

} catch (Exception $e) {
    error_log("Dashboard query error: " . $e->getMessage());
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">

    <!-- Top User Welcome Banner -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-darkCard via-darkCard to-indigo-950/40 border border-darkBorder shadow-xl">
        <div class="flex items-center gap-4">
            <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-white font-extrabold text-xl shadow-lg shadow-indigo-500/20">
                <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
            </div>
            <div>
                <div class="flex items-center gap-2">
                    <h1 class="text-xl sm:text-2xl font-bold text-white tracking-tight">
                        Welcome back, <span class="xvdo-gradient-text"><?= e($user['full_name']) ?></span>!
                    </h1>
                    <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        Active Member
                    </span>
                </div>
                <p class="text-xs text-slate-400 mt-1">Ready for your next streaming session? Explore curated releases below.</p>
            </div>
        </div>

        <!-- Quick actions -->
        <div class="flex items-center gap-3">
            <a href="profile.php" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 border border-darkBorder transition flex items-center gap-1.5">
                <i class="fa-solid fa-user-circle text-purple-400"></i> My Profile
            </a>
            <a href="logout.php" class="px-4 py-2 rounded-xl text-xs font-semibold text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 transition flex items-center gap-1.5">
                <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
        </div>
    </div>

    <!-- Featured Video Billboard / Hero Banner -->
    <?php if ($featuredVideo): ?>
        <section class="relative rounded-3xl overflow-hidden border border-darkBorder bg-darkCard shadow-2xl group">
            <div class="grid grid-cols-1 lg:grid-cols-12 min-h-[380px]">
                <!-- Info pane -->
                <div class="lg:col-span-5 p-6 sm:p-10 flex flex-col justify-between z-10 bg-gradient-to-t lg:bg-gradient-to-r from-[#0B0E14] via-[#0B0E14]/90 to-transparent">
                    <div class="space-y-4">
                        <div class="flex items-center gap-2">
                            <span class="px-2.5 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider bg-purple-600 text-white shadow">
                                <i class="fa-solid fa-star text-amber-300 mr-1"></i>Featured
                            </span>
                            <span class="px-2.5 py-1 rounded-md text-[11px] font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                                <?= e($featuredVideo['category_name'] ?: 'Video') ?>
                            </span>
                        </div>
                        <h2 class="text-2xl sm:text-3xl font-black text-white leading-tight">
                            <?= e($featuredVideo['title']) ?>
                        </h2>
                        <p class="text-xs sm:text-sm text-slate-300 line-clamp-3 leading-relaxed">
                            <?= e($featuredVideo['description']) ?>
                        </p>
                    </div>

                    <div class="pt-6 flex flex-wrap items-center gap-4">
                        <a href="watch.php?id=<?= (int)$featuredVideo['id'] ?>" class="px-6 py-3 rounded-xl text-sm font-bold text-white xvdo-btn-gradient shadow-lg shadow-indigo-600/30 flex items-center gap-2 group-hover:scale-105 transition-transform">
                            <i class="fa-solid fa-play text-xs"></i>
                            <span>Watch Now</span>
                        </a>
                        <div class="flex items-center gap-4 text-xs text-slate-400">
                            <span><i class="fa-solid fa-clock mr-1 text-slate-500"></i><?= e(formatDuration($featuredVideo['duration'])) ?></span>
                            <span><i class="fa-solid fa-eye mr-1 text-slate-500"></i><?= formatViews((int)$featuredVideo['views']) ?> views</span>
                        </div>
                    </div>
                </div>

                <!-- Thumbnail pane -->
                <div class="lg:col-span-7 relative min-h-[240px] lg:min-h-[380px] bg-black">
                    <img src="<?= e($featuredVideo['thumbnail_path']) ?>" 
                         alt="<?= e($featuredVideo['title']) ?>"
                         class="w-full h-full object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-[#0B0E14] lg:from-transparent to-transparent"></div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- Category Filter Chips -->
    <section>
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-bold text-white flex items-center gap-2">
                <i class="fa-solid fa-shapes text-purple-400"></i>Browse by Category
            </h2>
        </div>
        <div class="flex items-center gap-2.5 overflow-x-auto pb-2 scrollbar-none">
            <a href="dashboard.php" class="flex-shrink-0 px-4 py-2 rounded-xl text-xs font-semibold bg-blue-600 text-white shadow-md shadow-blue-600/20">
                All Categories
            </a>
            <?php foreach ($categories as $cat): ?>
                <a href="category.php?slug=<?= urlencode($cat['slug']) ?>" 
                   class="flex-shrink-0 px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white bg-darkCard hover:bg-darkCardHover border border-darkBorder flex items-center gap-2 transition">
                    <i class="<?= e($cat['icon'] ?: 'fa-solid fa-film') ?> text-indigo-400 text-xs"></i>
                    <span><?= e($cat['name']) ?></span>
                    <span class="text-[10px] text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded-full"><?= (int)$cat['video_count'] ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Recently Watched History -->
    <?php if (!empty($recentlyWatched)): ?>
        <section>
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h2 class="text-lg font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-clock-rotate-left text-blue-400"></i>Continue Watching
                    </h2>
                    <p class="text-xs text-slate-400 mt-0.5">Jump back into what you started</p>
                </div>
                <a href="profile.php#history" class="text-xs text-blue-400 hover:text-blue-300 font-semibold">
                    View History <i class="fa-solid fa-chevron-right ml-1 text-[10px]"></i>
                </a>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                <?php foreach ($recentlyWatched as $item): ?>
                    <div class="video-card bg-darkCard border border-darkBorder rounded-2xl overflow-hidden shadow flex flex-col group">
                        <a href="watch.php?id=<?= (int)$item['id'] ?>" class="relative block aspect-video overflow-hidden bg-black">
                            <img src="<?= e($item['thumbnail_path']) ?>" alt="<?= e($item['title']) ?>" class="video-card-thumb w-full h-full object-cover">
                            <div class="absolute bottom-1.5 right-1.5 bg-black/80 backdrop-blur text-white text-[10px] font-semibold px-1.5 py-0.5 rounded">
                                <?= e(formatDuration($item['duration'])) ?>
                            </div>
                            <div class="video-card-play-overlay absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 transition-opacity">
                                <div class="w-9 h-9 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs shadow">
                                    <i class="fa-solid fa-play ml-0.5"></i>
                                </div>
                            </div>
                        </a>
                        <div class="p-3 flex flex-col justify-between flex-grow">
                            <div>
                                <span class="text-[10px] text-blue-400 font-medium"><?= e($item['category_name']) ?></span>
                                <a href="watch.php?id=<?= (int)$item['id'] ?>" class="block text-xs font-semibold text-white hover:text-blue-400 line-clamp-1 mt-0.5">
                                    <?= e($item['title']) ?>
                                </a>
                            </div>
                            <div class="text-[10px] text-slate-500 mt-2">
                                Watched <?= timeAgo($item['watched_at']) ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <!-- Latest Uploaded Videos -->
    <section>
        <div class="flex items-center justify-between mb-4">
            <div>
                <h2 class="text-lg font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-sparkles text-indigo-400"></i>Latest Releases
                </h2>
                <p class="text-xs text-slate-400 mt-0.5">Freshly uploaded videos on XVDO</p>
            </div>
            <a href="search.php?sort=latest" class="text-xs text-blue-400 hover:text-blue-300 font-semibold">
                Explore All <i class="fa-solid fa-chevron-right ml-1 text-[10px]"></i>
            </a>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            <?php foreach ($latestVideos as $video): ?>
                <div class="video-card bg-darkCard border border-darkBorder rounded-2xl overflow-hidden shadow-lg flex flex-col">
                    <a href="watch.php?id=<?= (int)$video['id'] ?>" class="relative block aspect-video overflow-hidden bg-black group">
                        <img src="<?= e($video['thumbnail_path']) ?>" alt="<?= e($video['title']) ?>" class="video-card-thumb w-full h-full object-cover">
                        <div class="absolute bottom-2 right-2 bg-black/80 backdrop-blur text-white text-[11px] font-semibold px-2 py-0.5 rounded">
                            <?= e(formatDuration($video['duration'])) ?>
                        </div>
                        <div class="video-card-play-overlay absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 transition-opacity">
                            <div class="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm shadow-lg">
                                <i class="fa-solid fa-play ml-0.5"></i>
                            </div>
                        </div>
                    </a>

                    <div class="p-3.5 flex flex-col flex-grow justify-between">
                        <div>
                            <div class="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                                <span class="text-blue-400 font-semibold"><?= e($video['category_name'] ?: 'Video') ?></span>
                                <span><i class="fa-solid fa-eye mr-1"></i><?= formatViews((int)$video['views']) ?></span>
                            </div>
                            <a href="watch.php?id=<?= (int)$video['id'] ?>" class="text-sm font-bold text-white hover:text-blue-400 line-clamp-2 transition leading-snug">
                                <?= e($video['title']) ?>
                            </a>
                        </div>
                        <div class="text-[11px] text-slate-500 pt-2 border-t border-darkBorder/40 mt-3 flex items-center justify-between">
                            <span>Uploaded <?= timeAgo($video['created_at']) ?></span>
                            <span class="text-xs text-blue-400 font-semibold hover:underline">Watch</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Popular Videos (Ordered by Views) -->
    <section>
        <div class="flex items-center justify-between mb-4">
            <div>
                <h2 class="text-lg font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-fire text-amber-400"></i>Most Popular Streams
                </h2>
                <p class="text-xs text-slate-400 mt-0.5">Highest rated and most watched videos</p>
            </div>
            <a href="search.php?sort=popular" class="text-xs text-blue-400 hover:text-blue-300 font-semibold">
                See Ranking <i class="fa-solid fa-chevron-right ml-1 text-[10px]"></i>
            </a>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            <?php foreach ($popularVideos as $video): ?>
                <div class="video-card bg-darkCard border border-darkBorder rounded-2xl overflow-hidden shadow-lg flex flex-col">
                    <a href="watch.php?id=<?= (int)$video['id'] ?>" class="relative block aspect-video overflow-hidden bg-black group">
                        <img src="<?= e($video['thumbnail_path']) ?>" alt="<?= e($video['title']) ?>" class="video-card-thumb w-full h-full object-cover">
                        <div class="absolute bottom-2 right-2 bg-black/80 backdrop-blur text-white text-[11px] font-semibold px-2 py-0.5 rounded">
                            <?= e(formatDuration($video['duration'])) ?>
                        </div>
                        <div class="video-card-play-overlay absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 transition-opacity">
                            <div class="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm shadow-lg">
                                <i class="fa-solid fa-play ml-0.5"></i>
                            </div>
                        </div>
                    </a>

                    <div class="p-3.5 flex flex-col flex-grow justify-between">
                        <div>
                            <div class="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                                <span class="text-purple-400 font-semibold"><?= e($video['category_name'] ?: 'Video') ?></span>
                                <span><i class="fa-solid fa-eye mr-1"></i><?= formatViews((int)$video['views']) ?> views</span>
                            </div>
                            <a href="watch.php?id=<?= (int)$video['id'] ?>" class="text-sm font-bold text-white hover:text-blue-400 line-clamp-2 transition leading-snug">
                                <?= e($video['title']) ?>
                            </a>
                        </div>
                        <div class="text-[11px] text-slate-500 pt-2 border-t border-darkBorder/40 mt-3 flex items-center justify-between">
                            <span><?= timeAgo($video['created_at']) ?></span>
                            <span class="text-xs text-purple-400 font-semibold hover:underline">Watch</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
