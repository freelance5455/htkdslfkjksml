<?php
/**
 * XVDO - Home & Landing Page
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

// If logged in, redirect directly to dashboard
if (isUserLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$pageTitle = 'Home';

$featuredVideo = null;
$popularVideos = [];
$categories = [];

try {
    $pdo = getDBConnection();

    // Featured video
    $featStmt = $pdo->query("
        SELECT v.*, c.name AS category_name, c.slug AS category_slug 
        FROM videos v 
        LEFT JOIN categories c ON v.category_id = c.id 
        WHERE v.status = 'published' AND v.is_featured = 1 
        ORDER BY v.id DESC LIMIT 1
    ");
    $featuredVideo = $featStmt->fetch();

    if (!$featuredVideo) {
        $featFallback = $pdo->query("
            SELECT v.*, c.name AS category_name, c.slug AS category_slug 
            FROM videos v 
            LEFT JOIN categories c ON v.category_id = c.id 
            WHERE v.status = 'published' 
            ORDER BY v.views DESC LIMIT 1
        ");
        $featuredVideo = $featFallback->fetch();
    }

    // Popular videos
    $popStmt = $pdo->query("
        SELECT v.*, c.name AS category_name, c.slug AS category_slug 
        FROM videos v 
        LEFT JOIN categories c ON v.category_id = c.id 
        WHERE v.status = 'published' 
        ORDER BY v.views DESC LIMIT 8
    ");
    $popularVideos = $popStmt->fetchAll();

    // Categories
    $catStmt = $pdo->query("
        SELECT c.*, COUNT(v.id) AS video_count 
        FROM categories c 
        LEFT JOIN videos v ON c.id = v.category_id AND v.status = 'published' 
        GROUP BY c.id 
        ORDER BY video_count DESC LIMIT 6
    ");
    $categories = $catStmt->fetchAll();

} catch (Exception $e) {
    error_log("Landing page error: " . $e->getMessage());
}

require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Showcase Section -->
<section class="relative overflow-hidden pt-8 pb-16 lg:py-20 border-b border-darkBorder">
    <!-- Ambient glow lights -->
    <div class="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-to-r from-blue-600/20 to-purple-600/20 blur-[120px] pointer-events-none"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <!-- Left Copy -->
            <div class="lg:col-span-7 space-y-6 text-center lg:text-left">
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-semibold">
                    <span class="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
                    <span>Next-Gen Streaming Platform</span>
                </div>
                <h1 class="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight">
                    Unlimited HD Videos, <br>
                    <span class="xvdo-gradient-text">Zero Compromises.</span>
                </h1>
                <p class="text-base sm:text-lg text-slate-400 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                    Stream blockbuster actions, insightful documentaries, high-tech tutorials, and creative indie reels. Join XVDO today for free.
                </p>
                <div class="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                    <a href="register.php" class="w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold text-sm text-white xvdo-btn-gradient shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2">
                        <i class="fa-solid fa-play text-xs"></i>
                        <span>Start Watching Now</span>
                    </a>
                    <a href="login.php" class="w-full sm:w-auto px-6 py-3.5 rounded-xl font-semibold text-sm text-slate-300 hover:text-white bg-darkCard hover:bg-darkCardHover border border-darkBorder flex items-center justify-center gap-2 transition">
                        <i class="fa-solid fa-lock text-xs"></i>
                        <span>Sign In</span>
                    </a>
                </div>
                <!-- Platform specs -->
                <div class="grid grid-cols-3 gap-4 pt-6 border-t border-darkBorder/60 max-w-md mx-auto lg:mx-0">
                    <div>
                        <div class="text-xl font-bold text-white">4K UHD</div>
                        <div class="text-xs text-slate-500">Crystal Quality</div>
                    </div>
                    <div>
                        <div class="text-xl font-bold text-white">100% Free</div>
                        <div class="text-xs text-slate-500">Instant Access</div>
                    </div>
                    <div>
                        <div class="text-xl font-bold text-white">Multi-Device</div>
                        <div class="text-xs text-slate-500">Mobile & Web</div>
                    </div>
                </div>
            </div>

            <!-- Right Featured Card -->
            <div class="lg:col-span-5">
                <?php if ($featuredVideo): ?>
                    <div class="bg-darkCard border border-darkBorder rounded-3xl p-3 shadow-2xl relative group">
                        <div class="relative rounded-2xl overflow-hidden aspect-video bg-black">
                            <img src="<?= e($featuredVideo['thumbnail_path']) ?>" 
                                 alt="<?= e($featuredVideo['title']) ?>"
                                 class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                            
                            <!-- Badges -->
                            <div class="absolute top-3 left-3 bg-purple-600 text-white text-[11px] font-bold px-2.5 py-1 rounded-md shadow uppercase tracking-wider flex items-center gap-1">
                                <i class="fa-solid fa-fire text-amber-300"></i> Featured
                            </div>
                            <div class="absolute bottom-3 right-3 bg-black/80 backdrop-blur text-white text-xs font-semibold px-2 py-0.5 rounded">
                                <?= e(formatDuration($featuredVideo['duration'])) ?>
                            </div>

                            <!-- Play trigger overlay -->
                            <a href="watch.php?id=<?= (int)$featuredVideo['id'] ?>" class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <div class="w-14 h-14 rounded-full bg-blue-600 text-white flex items-center justify-center text-lg shadow-xl shadow-blue-500/50 transform group-hover:scale-110 transition-transform">
                                    <i class="fa-solid fa-play ml-1"></i>
                                </div>
                            </a>
                        </div>
                        <div class="p-4 space-y-2">
                            <div class="flex items-center justify-between text-xs text-slate-400">
                                <span class="text-blue-400 font-semibold"><?= e($featuredVideo['category_name'] ?: 'Video') ?></span>
                                <span><i class="fa-solid fa-eye mr-1"></i><?= formatViews((int)$featuredVideo['views']) ?> views</span>
                            </div>
                            <h3 class="text-base font-bold text-white line-clamp-1"><?= e($featuredVideo['title']) ?></h3>
                            <p class="text-xs text-slate-400 line-clamp-2"><?= e($featuredVideo['description']) ?></p>
                            <a href="watch.php?id=<?= (int)$featuredVideo['id'] ?>" class="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-blue-400 hover:text-blue-300">
                                <span>Watch Preview</span>
                                <i class="fa-solid fa-arrow-right text-[10px]"></i>
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="aspect-video bg-darkCard border border-darkBorder rounded-3xl flex flex-col items-center justify-center p-8 text-center">
                        <i class="fa-solid fa-clapperboard text-4xl text-slate-600 mb-3"></i>
                        <h4 class="text-white font-semibold text-sm">Welcome to XVDO</h4>
                        <p class="text-xs text-slate-500 mt-1">Upload videos via the Admin panel to begin streaming</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Categories Bar -->
<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h2 class="text-xl font-bold text-white flex items-center gap-2">
                <i class="fa-solid fa-layer-group text-blue-400"></i>Browse by Category
            </h2>
            <p class="text-xs text-slate-400 mt-0.5">Find high-energy action, documentaries, tutorials and more</p>
        </div>
    </div>

    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <?php foreach ($categories as $cat): ?>
            <a href="category.php?slug=<?= urlencode($cat['slug']) ?>" 
               class="bg-darkCard hover:bg-darkCardHover border border-darkBorder hover:border-slate-600 p-4 rounded-2xl flex flex-col items-center text-center group transition">
                <div class="w-12 h-12 rounded-xl bg-slate-800/80 group-hover:bg-blue-600/20 text-blue-400 group-hover:text-blue-300 flex items-center justify-center text-lg mb-3 transition">
                    <i class="<?= e($cat['icon'] ?: 'fa-solid fa-film') ?>"></i>
                </div>
                <span class="text-xs font-semibold text-white group-hover:text-blue-400 transition"><?= e($cat['name']) ?></span>
                <span class="text-[11px] text-slate-500 mt-0.5"><?= (int)$cat['video_count'] ?> videos</span>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<!-- Trending Videos Section -->
<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-16">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h2 class="text-xl font-bold text-white flex items-center gap-2">
                <i class="fa-solid fa-fire text-amber-400"></i>Trending on XVDO
            </h2>
            <p class="text-xs text-slate-400 mt-0.5">Most watched streams by our community</p>
        </div>
        <a href="login.php" class="text-xs font-semibold text-blue-400 hover:text-blue-300">
            Sign In to Watch All <i class="fa-solid fa-chevron-right ml-1 text-[10px]"></i>
        </a>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
        <?php foreach ($popularVideos as $video): ?>
            <div class="video-card bg-darkCard border border-darkBorder rounded-2xl overflow-hidden shadow-lg flex flex-col">
                <a href="watch.php?id=<?= (int)$video['id'] ?>" class="relative block aspect-video overflow-hidden bg-black group">
                    <img src="<?= e($video['thumbnail_path']) ?>" 
                         alt="<?= e($video['title']) ?>"
                         class="video-card-thumb w-full h-full object-cover">
                    
                    <div class="absolute bottom-2 right-2 bg-black/80 backdrop-blur text-white text-[11px] font-semibold px-2 py-0.5 rounded">
                        <?= e(formatDuration($video['duration'])) ?>
                    </div>

                    <div class="video-card-play-overlay absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 transition-opacity">
                        <div class="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm shadow-lg">
                            <i class="fa-solid fa-play ml-0.5"></i>
                        </div>
                    </div>
                </a>

                <div class="p-3.5 flex flex-col flex-grow justify-between">
                    <div>
                        <div class="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                            <span class="text-blue-400 font-semibold"><?= e($video['category_name'] ?: 'Video') ?></span>
                            <span><i class="fa-solid fa-eye mr-1"></i><?= formatViews((int)$video['views']) ?></span>
                        </div>
                        <a href="watch.php?id=<?= (int)$video['id'] ?>" class="text-sm font-bold text-white hover:text-blue-400 line-clamp-2 transition leading-snug">
                            <?= e($video['title']) ?>
                        </a>
                    </div>
                    <div class="text-[11px] text-slate-500 pt-2 border-t border-darkBorder/40 mt-3 flex items-center justify-between">
                        <span><?= timeAgo($video['created_at']) ?></span>
                        <a href="watch.php?id=<?= (int)$video['id'] ?>" class="text-blue-400 hover:underline">Watch</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
