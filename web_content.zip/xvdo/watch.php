<?php
/**
 * XVDO - Video Player Page
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

// Enforce login to watch
requireUserLogin();
$user = getCurrentUser();

$videoId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($videoId <= 0) {
    setFlash('warning', 'Invalid video selected.');
    header('Location: dashboard.php');
    exit;
}

$video = null;
$relatedVideos = [];
$category = null;

try {
    $pdo = getDBConnection();

    // Fetch video details
    $stmt = $pdo->prepare("
        SELECT v.*, c.name AS category_name, c.slug AS category_slug, c.icon AS category_icon
        FROM videos v 
        LEFT JOIN categories c ON v.category_id = c.id 
        WHERE v.id = ? AND v.status = 'published' 
        LIMIT 1
    ");
    $stmt->execute([$videoId]);
    $video = $stmt->fetch();

    if (!$video) {
        setFlash('danger', 'Video not found or is currently unpublished.');
        header('Location: dashboard.php');
        exit;
    }

    // 1. Record view in video_views table (one per session/ip window)
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $userAgent = substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown', 0, 255);

    $viewCheck = $pdo->prepare("
        SELECT id FROM video_views 
        WHERE video_id = ? AND user_id = ? AND viewed_at > DATE_SUB(NOW(), INTERVAL 1 HOUR) 
        LIMIT 1
    ");
    $viewCheck->execute([$videoId, $user['id']]);

    if (!$viewCheck->fetch()) {
        $insertView = $pdo->prepare("
            INSERT INTO video_views (video_id, user_id, ip_address, user_agent, viewed_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        $insertView->execute([$videoId, $user['id'], $ip, $userAgent]);

        // Increment views on video record
        $updateViews = $pdo->prepare("UPDATE videos SET views = views + 1 WHERE id = ?");
        $updateViews->execute([$videoId]);
        $video['views']++;
    }

    // 2. Update or insert watch_history for current user
    $historyCheck = $pdo->prepare("SELECT id FROM watch_history WHERE user_id = ? AND video_id = ? LIMIT 1");
    $historyCheck->execute([$user['id'], $videoId]);
    $historyRow = $historyCheck->fetch();

    if ($historyRow) {
        $updateHistory = $pdo->prepare("UPDATE watch_history SET watched_at = NOW() WHERE id = ?");
        $updateHistory->execute([$historyRow['id']]);
    } else {
        $insertHistory = $pdo->prepare("
            INSERT INTO watch_history (user_id, video_id, watched_at, duration_watched) 
            VALUES (?, ?, NOW(), 0)
        ");
        $insertHistory->execute([$user['id'], $videoId]);
    }

    // 3. Fetch Related Videos (same category or popular)
    $relatedStmt = $pdo->prepare("
        SELECT v.*, c.name AS category_name 
        FROM videos v 
        LEFT JOIN categories c ON v.category_id = c.id 
        WHERE v.id != ? AND v.status = 'published' AND (v.category_id = ? OR ? = 0) 
        ORDER BY v.views DESC 
        LIMIT 6
    ");
    $relatedStmt->execute([$videoId, $video['category_id'] ?? 0, $video['category_id'] ?? 0]);
    $relatedVideos = $relatedStmt->fetchAll();

    if (empty($relatedVideos)) {
        $fallbackStmt = $pdo->prepare("
            SELECT v.*, c.name AS category_name 
            FROM videos v 
            LEFT JOIN categories c ON v.category_id = c.id 
            WHERE v.id != ? AND v.status = 'published' 
            ORDER BY v.id DESC 
            LIMIT 6
        ");
        $fallbackStmt->execute([$videoId]);
        $relatedVideos = $fallbackStmt->fetchAll();
    }

} catch (Exception $e) {
    error_log("Watch page error: " . $e->getMessage());
    setFlash('danger', 'An error occurred while loading the video.');
    header('Location: dashboard.php');
    exit;
}

$pageTitle = $video['title'];
require_once __DIR__ . '/includes/header.php';

// Determine video player source
$videoSource = $video['video_path'];
$isYouTube = false;
$youtubeEmbedUrl = '';

if (preg_match('/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $videoSource, $matches)) {
    $isYouTube = true;
    $youtubeEmbedUrl = 'https://www.youtube-nocookie.com/embed/' . $matches[1] . '?autoplay=1&rel=0&modestbranding=1';
}
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">

        <!-- Left / Main: Video Player & Details (8 cols) -->
        <div class="lg:col-span-8 space-y-6">

            <!-- Video Player Box -->
            <div class="relative bg-black rounded-3xl overflow-hidden shadow-2xl border border-darkBorder">
                <div class="video-player-container">
                    <?php if ($isYouTube): ?>
                        <iframe src="<?= e($youtubeEmbedUrl) ?>" 
                                title="<?= e($video['title']) ?>" 
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                                allowfullscreen></iframe>
                    <?php else: ?>
                        <video id="xvdoMainPlayer" 
                               controls 
                               playsinline 
                               autoplay 
                               poster="<?= e($video['thumbnail_path']) ?>" 
                               class="w-full h-full object-contain focus:outline-none">
                            <source src="<?= e($videoSource) ?>" type="video/mp4">
                            <source src="<?= e($videoSource) ?>" type="video/webm">
                            <p class="text-slate-400 p-8 text-center text-sm">
                                Your browser does not support the HTML5 video tag.
                            </p>
                        </video>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Video Info & Meta -->
            <div class="bg-darkCard border border-darkBorder rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
                <!-- Title & Meta Bar -->
                <div>
                    <div class="flex flex-wrap items-center gap-2 mb-3">
                        <?php if ($video['category_name']): ?>
                            <a href="category.php?slug=<?= urlencode($video['category_slug']) ?>" 
                               class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30 hover:bg-purple-500/30 transition">
                                <i class="<?= e($video['category_icon'] ?: 'fa-solid fa-tag') ?>"></i>
                                <span><?= e($video['category_name']) ?></span>
                            </a>
                        <?php endif; ?>
                        
                        <?php if ($video['is_featured']): ?>
                            <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                <i class="fa-solid fa-star"></i> Featured
                            </span>
                        <?php endif; ?>

                        <span class="text-xs text-slate-400 ml-auto flex items-center gap-1.5">
                            <i class="fa-solid fa-clock text-slate-500"></i>
                            <?= e(formatDuration($video['duration'])) ?>
                        </span>
                    </div>

                    <h1 class="text-xl sm:text-2xl lg:text-3xl font-extrabold text-white tracking-tight leading-snug">
                        <?= e($video['title']) ?>
                    </h1>

                    <div class="flex flex-wrap items-center justify-between gap-4 mt-4 pt-4 border-t border-darkBorder/60 text-xs text-slate-400">
                        <div class="flex items-center gap-4">
                            <span class="flex items-center gap-1.5 font-semibold text-slate-300">
                                <i class="fa-solid fa-eye text-blue-400"></i>
                                <?= number_format((int)$video['views']) ?> views
                            </span>
                            <span>&bull;</span>
                            <span class="flex items-center gap-1.5">
                                <i class="fa-regular fa-calendar text-slate-500"></i>
                                <?= date('M j, Y', strtotime($video['created_at'])) ?>
                            </span>
                        </div>

                        <!-- Player action shortcuts -->
                        <div class="flex items-center gap-2">
                            <button onclick="navigator.clipboard.writeText(window.location.href); alert('Streaming link copied to clipboard!');" 
                                    class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition">
                                <i class="fa-solid fa-share-nodes text-blue-400"></i>
                                <span>Share</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Description Block -->
                <div class="bg-[#0B0E14] border border-darkBorder rounded-2xl p-5">
                    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Description</h3>
                    <p class="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                        <?= nl2br(e($video['description'])) ?>
                    </p>
                </div>

                <!-- Keyboard shortcuts note for HTML5 player -->
                <?php if (!$isYouTube): ?>
                    <div class="text-[11px] text-slate-500 flex flex-wrap items-center gap-3">
                        <span class="font-semibold text-slate-400"><i class="fa-solid fa-keyboard mr-1"></i>Player shortcuts:</span>
                        <span><kbd class="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">Space</kbd> Play / Pause</span>
                        <span><kbd class="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">F</kbd> Fullscreen</span>
                        <span><kbd class="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">&larr; / &rarr;</kbd> Seek 10s</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Right: Related Videos Sidebar (4 cols) -->
        <div class="lg:col-span-4 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-darkBorder">
                <h2 class="text-base font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-film text-purple-400"></i>Related Streams
                </h2>
                <span class="text-xs text-slate-500"><?= count($relatedVideos) ?> recommended</span>
            </div>

            <div class="space-y-3">
                <?php foreach ($relatedVideos as $rel): ?>
                    <a href="watch.php?id=<?= (int)$rel['id'] ?>" 
                       class="group bg-darkCard hover:bg-darkCardHover border border-darkBorder hover:border-slate-700 rounded-2xl p-2.5 flex gap-3 transition shadow">
                        
                        <!-- Thumbnail -->
                        <div class="relative w-36 aspect-video rounded-xl overflow-hidden bg-black flex-shrink-0">
                            <img src="<?= e($rel['thumbnail_path']) ?>" 
                                 alt="<?= e($rel['title']) ?>" 
                                 class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                            <span class="absolute bottom-1 right-1 bg-black/80 backdrop-blur text-white text-[9px] font-semibold px-1 rounded">
                                <?= e(formatDuration($rel['duration'])) ?>
                            </span>
                        </div>

                        <!-- Info -->
                        <div class="flex flex-col justify-between py-0.5 overflow-hidden">
                            <div>
                                <span class="text-[10px] font-semibold text-blue-400 uppercase tracking-wider block truncate">
                                    <?= e($rel['category_name'] ?: 'Video') ?>
                                </span>
                                <h4 class="text-xs font-bold text-white group-hover:text-blue-400 line-clamp-2 transition mt-0.5">
                                    <?= e($rel['title']) ?>
                                </h4>
                            </div>
                            <div class="text-[10px] text-slate-500 flex items-center gap-2">
                                <span><i class="fa-solid fa-eye mr-0.5"></i><?= formatViews((int)$rel['views']) ?></span>
                                <span>&bull;</span>
                                <span><?= timeAgo($rel['created_at']) ?></span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
