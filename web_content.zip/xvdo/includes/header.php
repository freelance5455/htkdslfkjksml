<?php
/**
 * XVDO - Main Site Header
 */
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$user = getCurrentUser();
$siteName = getSetting('site_name', 'MTX');
$siteLogo = getSetting('site_logo', '');
$categories = [];

try {
    $pdo = getDBConnection();
    $catStmt = $pdo->query("SELECT id, name, slug, icon FROM categories ORDER BY name ASC LIMIT 12");
    $categories = $catStmt->fetchAll();
} catch (Exception $e) {
    // Graceful fallback
}

$flash = getFlash();
$currentScript = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' - ' . e($siteName) : e($siteName) . ' - Premium Video Streaming' ?></title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        darkBg: '#0B0E14',
                        darkCard: '#151A24',
                        darkCardHover: '#1E2534',
                        darkBorder: '#252D3D',
                        accentBlue: '#3B82F6',
                        accentPurple: '#8B5CF6'
                    }
                }
            }
        }
    </script>
    <!-- Font Awesome Icons CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/custom.css">
</head>
<body class="bg-darkBg text-slate-100 flex flex-col min-h-screen">

<!-- Top Navigation Bar -->
<header class="sticky top-0 z-50 bg-[#0B0E14]/95 backdrop-blur-md border-b border-darkBorder">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16 gap-4">
            <!-- Brand Logo -->
            <div class="flex items-center gap-3">
                <a href="<?= isUserLoggedIn() ? 'dashboard.php' : 'index.php' ?>" class="flex items-center gap-2 group">
                    <div class="w-10 h-10 rounded-xl xvdo-btn-gradient flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
                        <i class="fa-solid fa-play text-sm ml-0.5"></i>
                    </div>
                    <span class="text-2xl font-black tracking-wider text-white">
                        M<span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">TX</span>
                    </span>
                </a>

                <!-- Desktop Nav Links -->
                <nav class="hidden md:flex items-center gap-1 ml-6 text-sm font-medium">
                    <a href="<?= isUserLoggedIn() ? 'dashboard.php' : 'index.php' ?>" 
                       class="px-3 py-2 rounded-lg transition <?= in_array($currentScript, ['index.php', 'dashboard.php']) ? 'text-white bg-darkCard font-semibold' : 'text-slate-400 hover:text-white hover:bg-darkCard/60' ?>">
                        <i class="fa-solid fa-compass mr-1.5 text-blue-400"></i>Browse
                    </a>

                    <!-- Categories Dropdown Trigger -->
                    <div class="relative group">
                        <button class="px-3 py-2 rounded-lg text-slate-400 hover:text-white hover:bg-darkCard/60 flex items-center gap-1.5 transition">
                            <i class="fa-solid fa-shapes mr-0.5 text-purple-400"></i>Categories
                            <i class="fa-solid fa-chevron-down text-xs transition-transform group-hover:rotate-180"></i>
                        </button>
                        <div class="absolute left-0 mt-1 w-56 bg-darkCard border border-darkBorder rounded-xl shadow-2xl p-2 hidden group-hover:block z-50">
                            <div class="grid grid-cols-1 gap-1 max-h-80 overflow-y-auto">
                                <?php foreach ($categories as $cat): ?>
                                    <a href="category.php?slug=<?= urlencode($cat['slug']) ?>" class="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition">
                                        <i class="<?= e($cat['icon'] ?: 'fa-solid fa-film') ?> text-indigo-400 w-4 text-center"></i>
                                        <span><?= e($cat['name']) ?></span>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>

            <!-- Central Search Bar -->
            <div class="flex-1 max-w-lg hidden sm:block">
                <form action="search.php" method="GET" class="relative">
                    <input type="text" name="q" placeholder="Search videos, topics, creators..." 
                           value="<?= isset($_GET['q']) ? e($_GET['q']) : '' ?>"
                           class="w-full bg-[#151A24] text-sm text-white placeholder-slate-500 rounded-full pl-10 pr-4 py-2 border border-darkBorder focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition">
                    <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                </form>
            </div>

            <!-- Right User / Auth Actions -->
            <div class="flex items-center gap-3">
                <!-- Mobile Search Icon Button -->
                <a href="search.php" class="sm:hidden p-2 text-slate-400 hover:text-white">
                    <i class="fa-solid fa-magnifying-glass text-lg"></i>
                </a>

                <?php if (isUserLoggedIn() && $user): ?>
                    <!-- Logged in User Menu -->
                    <div class="relative">
                        <button id="userDropdownBtn" class="flex items-center gap-2.5 p-1.5 rounded-full hover:bg-darkCard transition focus:outline-none">
                            <div class="w-9 h-9 rounded-full bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow">
                                <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                            </div>
                            <span class="hidden lg:inline text-sm font-medium text-slate-200">
                                <?= e(explode(' ', $user['full_name'])[0]) ?>
                            </span>
                            <i class="fa-solid fa-chevron-down text-xs text-slate-400 hidden lg:inline"></i>
                        </button>

                        <!-- Dropdown Menu -->
                        <div id="userDropdownMenu" class="hidden absolute right-0 mt-2 w-60 bg-darkCard border border-darkBorder rounded-2xl shadow-2xl py-2 z-50">
                            <div class="px-4 py-3 border-b border-darkBorder">
                                <p class="text-sm font-semibold text-white truncate"><?= e($user['full_name']) ?></p>
                                <p class="text-xs text-slate-400 truncate"><?= e($user['email']) ?></p>
                            </div>
                            <div class="py-1">
                                <a href="dashboard.php" class="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-300 hover:text-white hover:bg-darkCardHover transition">
                                    <i class="fa-solid fa-table-columns text-blue-400 w-4"></i>Dashboard
                                </a>
                                <a href="profile.php" class="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-300 hover:text-white hover:bg-darkCardHover transition">
                                    <i class="fa-solid fa-user-gear text-purple-400 w-4"></i>My Profile & History
                                </a>
                            </div>
                            <div class="border-t border-darkBorder pt-1">
                                <a href="logout.php" class="flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 transition">
                                    <i class="fa-solid fa-arrow-right-from-bracket w-4"></i>Sign Out
                                </a>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Guest Login / Register buttons -->
                    <a href="login.php" class="text-sm font-medium text-slate-300 hover:text-white px-3 py-2 rounded-lg transition">
                        Sign In
                    </a>
                    <a href="register.php" class="text-sm font-semibold text-white xvdo-btn-gradient px-4 py-2 rounded-lg shadow transition flex items-center gap-1.5">
                        <i class="fa-solid fa-user-plus text-xs"></i>
                        <span>Register</span>
                    </a>
                <?php endif; ?>

                <!-- Mobile Menu Button -->
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-400 hover:text-white focus:outline-none">
                    <i class="fa-solid fa-bars text-xl"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile Navigation Drawer -->
    <div id="mobileMenu" class="hidden md:hidden border-t border-darkBorder bg-[#0F141F] px-4 pt-3 pb-6 space-y-3">
        <form action="search.php" method="GET" class="relative">
            <input type="text" name="q" placeholder="Search videos..." 
                   class="w-full bg-[#151A24] text-sm text-white placeholder-slate-500 rounded-lg pl-10 pr-4 py-2.5 border border-darkBorder focus:outline-none">
            <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
        </form>

        <div class="space-y-1 text-sm font-medium">
            <a href="<?= isUserLoggedIn() ? 'dashboard.php' : 'index.php' ?>" class="block px-3 py-2 rounded-lg text-slate-200 hover:bg-darkCard">
                <i class="fa-solid fa-compass mr-2 text-blue-400"></i>Browse
            </a>
            <div class="px-3 py-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Categories</div>
            <div class="grid grid-cols-2 gap-2 pl-2">
                <?php foreach ($categories as $cat): ?>
                    <a href="category.php?slug=<?= urlencode($cat['slug']) ?>" class="flex items-center gap-2 text-xs text-slate-300 hover:text-white py-1">
                        <i class="<?= e($cat['icon'] ?: 'fa-solid fa-play') ?> text-indigo-400 text-xs"></i>
                        <span class="truncate"><?= e($cat['name']) ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</header>

<!-- Global Flash Alert Notification -->
<?php if ($flash): ?>
    <div id="flashAlert" class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
        <?php
        $bgColor = match($flash['type']) {
            'success' => 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300',
            'danger' => 'bg-rose-500/15 border-rose-500/40 text-rose-300',
            'warning' => 'bg-amber-500/15 border-amber-500/40 text-amber-300',
            default => 'bg-blue-500/15 border-blue-500/40 text-blue-300'
        };
        $icon = match($flash['type']) {
            'success' => 'fa-circle-check',
            'danger' => 'fa-circle-exclamation',
            'warning' => 'fa-triangle-exclamation',
            default => 'fa-circle-info'
        };
        ?>
        <div class="flex items-center gap-3 p-4 rounded-xl border <?= $bgColor ?> backdrop-blur-sm shadow-lg">
            <i class="fa-solid <?= $icon ?> text-lg"></i>
            <span class="text-sm font-medium"><?= e($flash['message']) ?></span>
        </div>
    </div>
<?php endif; ?>

<!-- Main Page Content Wrapper -->
<main class="flex-grow">
