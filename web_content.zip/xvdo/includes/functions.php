<?php
/**
 * XVDO - Common Helper Functions
 */

if (session_status() === PHP_SESSION_NONE) {
    // Configure secure session cookie parameters
    $cookieParams = session_get_cookie_params();
    session_set_cookie_params([
        'lifetime' => 86400 * 7, // 7 days
        'path' => '/',
        'domain' => $cookieParams['domain'],
        'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

require_once __DIR__ . '/../config/database.php';

/**
 * XSS escape string helper
 */
function e(?string $string): string {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * CSRF token generation
 */
function generateCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * CSRF input field HTML
 */
function csrfField(): string {
    return '<input type="hidden" name="csrf_token" value="' . e(generateCsrfToken()) . '">';
}

/**
 * Verify CSRF token from POST
 */
function verifyCsrfToken(?string $token): bool {
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Set flash message
 */
function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'info', 'warning'
        'message' => $message
    ];
}

/**
 * Get and clear flash message
 */
function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Format view count (e.g., 1500 -> 1.5K)
 */
function formatViews(int $views): string {
    if ($views >= 1000000) {
        return round($views / 1000000, 1) . 'M';
    } elseif ($views >= 1000) {
        return round($views / 1000, 1) . 'K';
    }
    return (string)$views;
}

/**
 * Format relative time ago (e.g. 2 hours ago)
 */
function timeAgo(string $datetime): string {
    $time = strtotime($datetime);
    if (!$time) return 'Recently';
    $diff = time() - $time;
    if ($diff < 60) return 'Just now';
    if ($diff < 3600) return floor($diff / 60) . ' mins ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hours ago';
    if ($diff < 604800) return floor($diff / 86400) . ' days ago';
    if ($diff < 2592000) return floor($diff / 604800) . ' weeks ago';
    return date('M j, Y', $time);
}

/**
 * Format duration string from seconds or standard MM:SS
 */
function formatDuration(?string $duration): string {
    if (empty($duration)) return '00:00';
    if (strpos($duration, ':') !== false) return $duration;
    $secs = (int)$duration;
    $hours = floor($secs / 3600);
    $minutes = floor(($secs % 3600) / 60);
    $seconds = $secs % 60;
    if ($hours > 0) {
        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
    }
    return sprintf('%02d:%02d', $minutes, $seconds);
}

/**
 * Fetch setting value from database
 */
function getSetting(string $key, string $default = ''): string {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? $row['setting_value'] : $default;
    } catch (Exception $e) {
        return $default;
    }
}

/**
 * Handle secure file uploads
 * 
 * @param array $file $_FILES['input_name']
 * @param string $destinationDir Absolute destination folder
 * @param array $allowedMimes Array of allowed mime types
 * @param array $allowedExtensions Array of allowed file extensions
 * @param int $maxSizeBytes Max file size in bytes
 * @return array ['success' => bool, 'fileName' => string|null, 'error' => string|null]
 */
function uploadSecureFile(array $file, string $destinationDir, array $allowedMimes, array $allowedExtensions, int $maxSizeBytes): array {
    if (!isset($file['error']) || is_array($file['error'])) {
        return ['success' => false, 'fileName' => null, 'error' => 'Invalid file upload parameter.'];
    }

    switch ($file['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            return ['success' => false, 'fileName' => null, 'error' => 'No file sent.'];
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return ['success' => false, 'fileName' => null, 'error' => 'Exceeded server upload file size limit.'];
        default:
            return ['success' => false, 'fileName' => null, 'error' => 'Unknown upload error occurred.'];
    }

    if ($file['size'] > $maxSizeBytes) {
        $maxMb = round($maxSizeBytes / 1048576, 1);
        return ['success' => false, 'fileName' => null, 'error' => "File size exceeds limit of {$maxMb}MB."];
    }

    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, $allowedExtensions, true)) {
        return ['success' => false, 'fileName' => null, 'error' => 'File extension not permitted. Allowed: ' . implode(', ', $allowedExtensions)];
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    if (!in_array($mimeType, $allowedMimes, true)) {
        return ['success' => false, 'fileName' => null, 'error' => 'Invalid file MIME type (' . $mimeType . ').'];
    }

    if (!is_dir($destinationDir)) {
        mkdir($destinationDir, 0755, true);
    }

    // Generate cryptographically random safe filename
    $newFileName = bin2hex(random_bytes(16)) . '.' . $extension;
    $targetPath = rtrim($destinationDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $newFileName;

    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => false, 'fileName' => null, 'error' => 'Failed to move uploaded file to destination. Check directory write permissions.'];
    }

    return ['success' => true, 'fileName' => $newFileName, 'error' => null];
}
