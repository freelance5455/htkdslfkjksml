<?php
/**
 * XVDO - Authentication & Access Control
 */

require_once __DIR__ . '/functions.php';

/**
 * Check if regular user is logged in
 */
function isUserLoggedIn(): bool {
    return !empty($_SESSION['user_id']) && !empty($_SESSION['user_email']);
}

/**
 * Enforce regular user authentication
 */
function requireUserLogin(): void {
    if (!isUserLoggedIn()) {
        $currentUri = $_SERVER['REQUEST_URI'] ?? 'dashboard.php';
        setFlash('warning', 'Please log in to your XVDO account to access this page.');
        header('Location: login.php?redirect=' . urlencode($currentUri));
        exit;
    }
}

/**
 * Get current logged in user details from database
 */
function getCurrentUser(): ?array {
    if (!isUserLoggedIn()) {
        return null;
    }
    static $currentUser = null;
    if ($currentUser === null) {
        try {
            $pdo = getDBConnection();
            $stmt = $pdo->prepare("SELECT id, full_name, email, phone, status, avatar, created_at FROM users WHERE id = ? LIMIT 1");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            if ($user && $user['status'] === 'active') {
                $currentUser = $user;
            } else {
                // If account deactivated or deleted, clear session
                logoutUser();
                header('Location: login.php?error=deactivated');
                exit;
            }
        } catch (Exception $e) {
            return null;
        }
    }
    return $currentUser;
}

/**
 * Start user session securely
 */
function loginUserSession(array $user): void {
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['full_name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['last_activity'] = time();
}

/**
 * Destroy user session
 */
function logoutUser(): void {
    unset($_SESSION['user_id']);
    unset($_SESSION['user_name']);
    unset($_SESSION['user_email']);
    unset($_SESSION['last_activity']);
    session_regenerate_id(true);
}

/**
 * Check if administrator is logged in
 */
function isAdminLoggedIn(): bool {
    return !empty($_SESSION['admin_id']) && !empty($_SESSION['admin_email']);
}

/**
 * Enforce administrator authentication
 */
function requireAdminLogin(): void {
    if (!isAdminLoggedIn()) {
        setFlash('warning', 'Administrator authentication required.');
        header('Location: login.php');
        exit;
    }
}

/**
 * Get current logged in admin
 */
function getCurrentAdmin(): ?array {
    if (!isAdminLoggedIn()) {
        return null;
    }
    static $currentAdmin = null;
    if ($currentAdmin === null) {
        try {
            $pdo = getDBConnection();
            $stmt = $pdo->prepare("SELECT id, username, email, full_name, role, created_at FROM admins WHERE id = ? LIMIT 1");
            $stmt->execute([$_SESSION['admin_id']]);
            $currentAdmin = $stmt->fetch() ?: null;
        } catch (Exception $e) {
            return null;
        }
    }
    return $currentAdmin;
}

/**
 * Start admin session securely
 */
function loginAdminSession(array $admin): void {
    session_regenerate_id(true);
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['admin_name'] = $admin['full_name'];
    $_SESSION['admin_email'] = $admin['email'];
    $_SESSION['admin_role'] = $admin['role'] ?? 'admin';
    $_SESSION['admin_last_activity'] = time();
}

/**
 * Destroy admin session
 */
function logoutAdmin(): void {
    unset($_SESSION['admin_id']);
    unset($_SESSION['admin_username']);
    unset($_SESSION['admin_name']);
    unset($_SESSION['admin_email']);
    unset($_SESSION['admin_role']);
    unset($_SESSION['admin_last_activity']);
    session_regenerate_id(true);
}
