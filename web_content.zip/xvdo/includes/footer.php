<?php
/**
 * XVDO - Main Site Footer
 */
$siteName = getSetting('site_name', 'XVDO');
$siteTagline = getSetting('site_tagline', 'Next-Generation High-Definition Video Streaming');
?>
</main>

<footer class="mt-20 border-t border-darkBorder bg-[#080B10] text-slate-400 text-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
            <!-- Brand Info -->
            <div class="space-y-4 md:col-span-1">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-lg xvdo-btn-gradient flex items-center justify-center text-white text-xs">
                        <i class="fa-solid fa-play ml-0.5"></i>
                    </div>
                    <span class="text-xl font-black tracking-wider text-white">
                        XV<span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">DO</span>
                    </span>
                </div>
                <p class="text-xs text-slate-400 leading-relaxed">
                    <?= e($siteTagline) ?>. Fast, secure, and responsive streaming powered by native HTML5 and PHP.
                </p>
                <div class="flex items-center gap-3 text-slate-400">
                    <span class="text-xs font-semibold px-2 py-0.5 rounded bg-darkCard border border-darkBorder text-blue-400">
                        <i class="fa-brands fa-php mr-1"></i>PHP 8+
                    </span>
                    <span class="text-xs font-semibold px-2 py-0.5 rounded bg-darkCard border border-darkBorder text-purple-400">
                        <i class="fa-solid fa-database mr-1"></i>MySQL PDO
                    </span>
                </div>
            </div>

            <!-- Quick Navigation -->
            <div>
                <h4 class="text-xs font-semibold uppercase tracking-wider text-white mb-4">Explore</h4>
                <ul class="space-y-2 text-xs">
                    <li><a href="dashboard.php" class="hover:text-blue-400 transition">Streaming Home</a></li>
                    <li><a href="search.php" class="hover:text-blue-400 transition">Search Library</a></li>
                    <li><a href="register.php" class="hover:text-blue-400 transition">Create Account</a></li>
                    <li><a href="login.php" class="hover:text-blue-400 transition">User Login</a></li>
                </ul>
            </div>

            <!-- Categories -->
            <div>
                <h4 class="text-xs font-semibold uppercase tracking-wider text-white mb-4">Popular Genres</h4>
                <ul class="space-y-2 text-xs">
                    <li><a href="category.php?slug=action" class="hover:text-purple-400 transition">Action & Adventure</a></li>
                    <li><a href="category.php?slug=sci-fi" class="hover:text-purple-400 transition">Sci-Fi & Cyber</a></li>
                    <li><a href="category.php?slug=documentaries" class="hover:text-purple-400 transition">Documentaries</a></li>
                    <li><a href="category.php?slug=tech-gaming" class="hover:text-purple-400 transition">Tech & Gaming</a></li>
                </ul>
            </div>

            <!-- Administration / Hosting Support -->
            <div>
                <h4 class="text-xs font-semibold uppercase tracking-wider text-white mb-4">Administration</h4>
                <p class="text-xs text-slate-400 mb-3">
                    Authorized staff and platform administrators can manage content and users via the secure panel.
                </p>
                <a href="admin/login.php" class="inline-flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-white bg-darkCard hover:bg-darkCardHover border border-darkBorder px-3 py-2 rounded-lg transition">
                    <i class="fa-solid fa-lock text-purple-400"></i>
                    <span>Admin Control Center</span>
                </a>
            </div>
        </div>

        <!-- Bottom Copyright -->
        <div class="border-t border-darkBorder/60 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <p>&copy; <?= date('Y') ?> <?= e($siteName) ?>. All rights reserved.</p>
            <div class="flex items-center gap-6">
                <span>Tailwind CSS</span>
                <span>Vanilla JS</span>
                <span>Shared-Hosting Ready</span>
            </div>
        </div>
    </div>
</footer>

<!-- Vanilla JS Scripts -->
<script src="assets/js/main.js"></script>
</body>
</html>
