<?php
/**
 * XVDO - Video Streaming Web Application
 * Database Configuration using PDO
 */

// Database credentials - update these for your hosting environment
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'xvdo_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');

/**
 * Returns a singleton PDO instance with safe defaults
 * 
 * @return PDO
 */
function getDBConnection(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // In production, log error instead of exposing raw database messages
            error_log("Database connection error: " . $e->getMessage());
            die("
            <div style='background-color:#0B0E14; color:#fff; font-family:sans-serif; padding:40px; text-align:center; min-height:100vh;'>
                <h1 style='color:#EF4444; font-size:2rem; margin-bottom:1rem;'>XVDO Database Connection Error</h1>
                <p style='color:#94A3B8; font-size:1.1rem; max-width:600px; margin:0 auto 1.5rem;'>
                    Unable to connect to the MySQL database. Please verify your database settings in <code>config/database.php</code> and ensure the database <code>" . htmlspecialchars(DB_NAME) . "</code> has been imported using <code>database.sql</code>.
                </p>
                <div style='background:#1E293B; border:1px solid #334155; padding:15px; border-radius:8px; display:inline-block; text-align:left; font-size:0.9rem;'>
                    <strong>Host:</strong> " . htmlspecialchars(DB_HOST) . "<br>
                    <strong>Database:</strong> " . htmlspecialchars(DB_NAME) . "<br>
                    <strong>User:</strong> " . htmlspecialchars(DB_USER) . "
                </div>
            </div>");
        }
    }
    return $pdo;
}
