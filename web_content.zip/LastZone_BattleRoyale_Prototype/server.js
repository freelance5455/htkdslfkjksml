const WebSocket = require('ws');
const http = require('http');
const PORT = process.env.PORT || 8080;
const server = http.createServer((req,res)=>{
  res.writeHead(200, {'content-type':'text/plain; charset=utf-8'});
  res.end('Last Zone WebSocket server is running. Connect clients to / using ws:// or wss://.');
});
const wss = new WebSocket.Server({server, maxPayload: 4096});
const clients = new Map();
const MAX_PLAYERS = 50;
const clamp=(v,min,max)=>Math.max(min,Math.min(max,Number(v)||0));
function broadcastState(){
  const state={type:'state',players:[...clients.values()].map(p=>({id:p.id,name:p.name,x:p.x,y:p.y,angle:p.angle,hp:p.hp,alive:p.alive}))};
  const msg=JSON.stringify(state);
  for(const c of wss.clients) if(c.readyState===WebSocket.OPEN) c.send(msg);
}
wss.on('connection',(socket)=>{
  if(clients.size>=MAX_PLAYERS){socket.send(JSON.stringify({type:'error',message:'Match full (50 players max)'}));socket.close();return;}
  const id='p_'+Math.random().toString(36).slice(2,10);
  const player={id,name:'Player',x:1200,y:900,angle:0,hp:100,alive:true,socket};
  clients.set(id,player);
  socket.send(JSON.stringify({type:'welcome',id,maxPlayers:MAX_PLAYERS}));
  socket.on('message',(raw)=>{
    let data;try{data=JSON.parse(raw.toString())}catch{return}
    if(data.type==='join'){player.name=String(data.name||'Player').slice(0,16);player.x=clamp(data.x,0,2400);player.y=clamp(data.y,0,1800)}
    if(data.type==='move'){
      // Prototype relay: production servers should validate movement, combat and zone damage server-side.
      player.x=clamp(data.x,0,2400);player.y=clamp(data.y,0,1800);
      player.angle=clamp(data.angle,-1000,1000);player.hp=clamp(data.hp,0,100);player.alive=Boolean(data.alive);
    }
  });
  socket.on('close',()=>{clients.delete(id);broadcastState()});
  broadcastState();
});
setInterval(broadcastState,100);
server.listen(PORT,()=>console.log(`Last Zone server listening on ${PORT} (max ${MAX_PLAYERS} clients)`));
