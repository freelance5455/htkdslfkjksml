LAST ZONE — ONLINE BATTLE ROYALE PROTOTYPE
===========================================

Included:
- index.html: playable top-down shooter demo, browser keyboard/mouse and mobile touch controls
- server.js: minimal WebSocket position-sync server, capped at 50 connected clients
- package.json: Node.js server dependency

PLAY LOCALLY
1. Extract this ZIP.
2. Open index.html in Chrome/Edge. Select PLAY DEMO.
3. Move with WASD/arrow keys; aim with mouse and click to fire. On touch devices, use the left joystick and FIRE button.

RUN THE MULTIPLAYER SERVER
1. Install Node.js 18+ on a computer/server.
2. In this folder run: npm install
3. Run: npm start
4. Host the server on a public service that supports persistent WebSocket connections.
5. Enter the server URL in the page:
   - local LAN: ws://COMPUTER-LAN-IP:8080
   - public hosting should use wss://your-domain (TLS reverse proxy required)
6. Other players need the same HTML page and the public server URL.

IMPORTANT LIMITATIONS
- This is a first playable prototype, not a finished realistic 3D game and not a production-ready competitive server.
- Server currently relays player positions and caps connections at 50; it does NOT yet implement authoritative shooting, matchmaking, anti-cheat, accounts, persistence, lag compensation, or a full battle-royale elimination flow.
- The local practice demo spawns bots; multiplayer networking is a basic position-sync foundation.
- For a realistic 3D Android + PC release, use Unity or Unreal Engine, 3D assets, platform builds, a hardened authoritative server, and substantial testing. The ZIP does not produce an APK by itself.
- Do not place passwords, API secrets, or payment credentials in client HTML.
