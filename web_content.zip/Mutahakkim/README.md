# متحكم v2.2 — مشروع أندرويد جاهز للبناء

الواجهة موجودة في `app/src/main/assets/index.html` وتُعرض داخل WebView.

## البناء (الطريقة الأسهل: Android Studio)
1. ثبّت Android Studio (إصدار Koala أو أحدث) ويتضمن JDK 17.
2. File ▸ Open ▸ اختر مجلد المشروع، وانتظر مزامنة Gradle.
3. Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s).
4. الملف الناتج: `app/build/outputs/apk/debug/app-debug.apk`

## البناء من سطر الأوامر
يلزم JDK 17 وAndroid SDK (متغير ANDROID_HOME) وGradle 8.7:

    gradle wrapper --gradle-version 8.7
    ./gradlew assembleDebug

للنشر على المتجر: أنشئ مفتاح توقيع وبدّل `signingConfig signingConfigs.debug`
في `app/build.gradle`، ثم نفّذ `./gradlew assembleRelease` (أو bundleRelease).

## تعديل الواجهة
عدّل `app/src/main/assets/index.html` ثم أعد البناء.

## ملاحظات
- المشروع بُني دون تشغيل Gradle في بيئة الإنشاء، فجرّب البناء أولاً وأخبرني بأي خطأ.
- الحد الأدنى للنظام: أندرويد 8.0 (API 26).
- الأذونات: الموقع والكاميرا (للمصباح) والميكروفون والاهتزاز. تُطلب عند الحاجة.
- تتبّع الموقع وإنذار السرقة لا يعملان والتطبيق مغلق تماماً. للعمل في الخلفية تلزم Foreground Service (إصدار لاحق).
- تغيير DNS الهاتف وحظر الإعلانات على مستوى النظام يتمّان من إعدادات DNS الخاص في الهاتف.
