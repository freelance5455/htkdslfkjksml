# Ultimate Website Builder — Futuristic AI Studio

Aplikasi editor website berbasis HTML, CSS, dan JavaScript murni, dibuat agar nyaman dipakai dari browser Android.

## Cara menjalankan
1. Ekstrak `Ultimate-Website-Builder-Futuristic-AI.zip`.
2. Buka `index.html` di browser untuk mencoba tampilan. Beberapa fitur browser (service worker/PWA) hanya berjalan saat file disajikan melalui HTTPS atau localhost.
3. Untuk hasil paling konsisten di Android, unggah folder hasil ekstrak ke hosting statis seperti GitHub Pages, Netlify, atau Cloudflare Pages.
4. Pilih template, edit tab `index.html`, `style.css`, dan `script.js`, lalu lihat panel Preview.
5. Tekan **Simpan Proyek** untuk menyimpan ke localStorage browser. Tekan **Ekspor ZIP** untuk mengunduh file website.

## Fitur yang bekerja
- Tampilan responsif untuk HP dan desktop.
- 4 template awal: landing page, game store, portfolio, halaman kosong.
- Editor untuk HTML, CSS, dan JavaScript.
- Preview otomatis melalui iframe sandbox.
- Simpan proyek dan riwayat lokal pada browser/perangkat yang sama.
- Upload gambar lokal untuk preview dan memasukkannya ke ZIP.
- Pemeriksaan HTML dasar (bukan validator lengkap).
- Ekspor proyek menjadi ZIP.
- PWA/service worker dasar saat disajikan lewat HTTPS/localhost.

## Ketergantungan eksternal dan batasan
- **Ekspor ZIP:** memakai JSZip dari jsDelivr CDN, jadi perlu internet agar library termuat. Jika CDN gagal, editor dan preview tetap bisa dipakai, tetapi ekspor ZIP tidak dapat berjalan sampai koneksi/CDN pulih.
- **Font:** memakai Google Fonts; jika offline, font sistem menjadi pengganti.
- **AI sungguhan:** tombol AI Quick Assist saat ini adalah saran berbasis aturan lokal, bukan model AI generatif. AI online membutuhkan API/provider eksternal dan sebaiknya dipanggil lewat backend agar API key tidak bocor.
- **Hosting/domain:** aplikasi ini tidak otomatis memublikasikan website. Unggah file ZIP ke layanan hosting statis dan atur domain sendiri.
- **Database dan akun:** tidak ada database server atau autentikasi aman di paket ini. localStorage hanya menyimpan data di browser yang sama dan bisa terhapus saat data browser dibersihkan.
- **Pembayaran, WhatsApp, formulir server, dan sinkronisasi lintas perangkat:** perlu tautan/konfigurasi layanan dan/atau backend sesuai kebutuhan.
- **APK:** paket ini bukan compiler APK. Mengubah website menjadi APK membutuhkan tool/build service Android tambahan.

## Keamanan
Editor ini ditujukan untuk proyek lokal. Jangan memasukkan API key rahasia ke kode frontend. Kode preview berjalan dalam iframe sandbox, tetapi tetap perlakukan kode proyek yang tidak dikenal dengan hati-hati.
