(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const STORAGE_KEY = "ultimateBuilderFuturisticProjectV1";
  const HISTORY_KEY = "ultimateBuilderFuturisticHistoryV1";
  const templates = {
    landing: {
      html: `<!doctype html>
<html lang="id">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Nova Studio</title><link rel="stylesheet" href="style.css"></head>
<body><header class="nav"><a class="logo" href="#">NOVA<span>✦</span></a><nav><a href="#fitur">Fitur</a><a href="#tentang">Tentang</a></nav><a class="nav-cta" href="#mulai">Mulai sekarang ↗</a></header>
<main><section class="hero"><div class="pill">✦ IDEAS INTO REALITY</div><h1>Bangun ide hebat<br><span>mulai hari ini.</span></h1><p>Landing page modern untuk memperkenalkan produk, layanan, atau ide kreatifmu kepada dunia.</p><a class="cta" href="#mulai">Jelajahi sekarang →</a><div class="hero-orb">✦</div></section>
<section id="fitur" class="features"><div><small>01 / DESAIN</small><h2>Terlihat profesional.</h2><p>Tampilan bersih yang fokus pada pesan utama dan pengalaman pengunjung.</p></div><div><small>02 / RESPONSIF</small><h2>Siap untuk mobile.</h2><p>Layout menyesuaikan layar ponsel, tablet, dan desktop.</p></div><div><small>03 / KREATIF</small><h2>Dibuat untuk ide.</h2><p>Mulai dengan template ini lalu ubah teks dan gaya sesuai kebutuhanmu.</p></div></section><section id="tentang" class="end"><small>NOVA STUDIO</small><h2>Langkah pertama dimulai di sini.</h2><p>Ganti konten ini dengan cerita brand-mu.</p><a class="cta" id="mulai" href="mailto:halo@example.com">Hubungi kami</a></section></main><footer>© 2026 Nova Studio · Dibuat dengan kreativitas</footer></body></html>`,
      css: `*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;color:#11162b;background:#f8f9ff}.nav{height:74px;display:flex;align-items:center;justify-content:space-between;padding:0 8%;background:#fff}.logo{font-weight:900;letter-spacing:2px;text-decoration:none;color:#161d3c}.logo span{color:#7757ff;margin-left:5px}nav{display:flex;gap:25px}nav a{font-size:13px;color:#606780;text-decoration:none}.nav-cta,.cta{background:#6b55ed;color:white;text-decoration:none;padding:12px 17px;border-radius:9px;font-size:13px;font-weight:bold}.hero{padding:95px 10% 105px;position:relative;overflow:hidden;background:linear-gradient(120deg,#f5f2ff,#e8f5ff)}.pill{display:inline-block;background:white;color:#6b55ed;padding:8px 12px;border-radius:20px;font-size:10px;letter-spacing:1.5px;font-weight:bold}.hero h1{font-size:clamp(42px,7vw,76px);line-height:1.03;letter-spacing:-3px;margin:22px 0}.hero h1 span{color:#7255f4}.hero p{max-width:460px;color:#68708b;line-height:1.8;margin-bottom:28px}.hero-orb{position:absolute;right:12%;top:22%;font-size:75px;color:white;display:grid;place-items:center;width:190px;height:190px;border-radius:55px;background:linear-gradient(135deg,#a07cff,#4b9bff);box-shadow:0 25px 60px #7e78e755;transform:rotate(10deg)}.features{display:grid;grid-template-columns:repeat(3,1fr);gap:28px;padding:65px 9%}.features>div{padding:20px 0}.features small,.end small{color:#7757ff;letter-spacing:1.5px;font-size:10px;font-weight:bold}.features h2{font-size:20px}.features p,.end p{color:#727a92;font-size:14px;line-height:1.8}.end{text-align:center;padding:65px 20px;background:#fff}.end h2{font-size:clamp(28px,4vw,42px);margin:15px 0}footer{text-align:center;padding:22px;color:#8a90a5;font-size:11px}@media(max-width:650px){.nav{padding:0 5%;height:65px}.nav nav{display:none}.nav-cta{font-size:10px;padding:10px}.hero{padding:75px 7%}.hero-orb{right:-60px;top:40%;opacity:.2;width:150px;height:150px}.hero h1{font-size:48px}.features{grid-template-columns:1fr;gap:0;padding:35px 8%}.features>div{padding:15px 0;border-bottom:1px solid #e7e8f0}}`,
      js: `document.querySelectorAll('a[href^="#"]').forEach(link=>link.addEventListener('click',event=>{const target=document.querySelector(link.getAttribute('href'));if(target){event.preventDefault();target.scrollIntoView({behavior:'smooth'});}}));`
    },
    store: {
      html: `<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pixel Game Store</title><link rel="stylesheet" href="style.css"></head><body><header><a class="logo" href="#">PIXEL<span>STORE</span></a><a class="cart" href="#produk">Lihat katalog ↓</a></header><main><section class="hero"><div class="tag">GAME TOP-UP & DIGITAL</div><h1>Level up.<br><span>Play more.</span></h1><p>Temukan pilihan produk digital favoritmu dengan proses pemesanan yang mudah.</p><a class="button" href="#produk">Jelajahi produk</a><div class="game-symbol">⌁</div></section><section id="produk" class="products"><div class="section-title"><small>PILIHAN KAMI</small><h2>Katalog Populer</h2></div><div class="cards"><article><div class="cover purple">FF</div><h3>Game Credits</h3><p>Paket digital pilihan</p><strong>Mulai Rp 5.000</strong><button class="order" data-item="Game Credits">Pilih produk</button></article><article><div class="cover blue">ML</div><h3>Mobile Game</h3><p>Top up praktis</p><strong>Mulai Rp 10.000</strong><button class="order" data-item="Mobile Game">Pilih produk</button></article><article><div class="cover orange">✦</div><h3>Digital Items</h3><p>Produk pilihan lainnya</p><strong>Hubungi admin</strong><button class="order" data-item="Digital Items">Pilih produk</button></article></div><p id="message" class="message" aria-live="polite"></p></section></main><footer>© 2026 Pixel Store · Template demo, ganti harga dan kontak sebelum digunakan.</footer><script src="script.js"></script></body></html>`,
      css: `*{box-sizing:border-box}body{margin:0;background:#f7f8fc;color:#1b2040;font-family:Arial,sans-serif}header{height:70px;display:flex;align-items:center;justify-content:space-between;padding:0 8%;background:white}.logo{font-weight:900;letter-spacing:2px;text-decoration:none;color:#202342}.logo span{color:#7956ed}.cart{font-size:12px;text-decoration:none;color:#6c57e9;font-weight:bold}.hero{padding:75px 9%;background:linear-gradient(115deg,#191735,#3c2b7c);color:white;position:relative;overflow:hidden}.tag{font-size:10px;letter-spacing:2px;color:#c8b9ff}.hero h1{font-size:clamp(44px,7vw,70px);line-height:1.02;margin:20px 0}.hero h1 span{color:#a99aff}.hero p{max-width:430px;color:#d2cfea;line-height:1.8}.button,.order{display:inline-block;border:0;border-radius:9px;background:#8064ff;color:#fff;padding:13px 17px;text-decoration:none;font-weight:bold;font-size:12px;cursor:pointer;margin-top:15px}.game-symbol{position:absolute;right:12%;top:20%;font-size:120px;color:#ffffff17}.products{padding:55px 8%}.section-title small{color:#7956ed;letter-spacing:2px;font-size:10px;font-weight:bold}.section-title h2{font-size:30px;margin:10px 0 25px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.cards article{background:white;border:1px solid #e8e9f2;border-radius:15px;padding:15px;box-shadow:0 12px 30px #20264b08}.cover{height:120px;border-radius:10px;display:grid;place-items:center;color:white;font-size:35px;font-weight:900}.cover.purple{background:linear-gradient(135deg,#a252ff,#613be5)}.cover.blue{background:linear-gradient(135deg,#38baff,#3e5bdb)}.cover.orange{background:linear-gradient(135deg,#ffad5c,#f05b8c)}.cards h3{margin:17px 0 6px}.cards p{font-size:12px;color:#858ba2}.cards strong{font-size:12px;display:block}.order{width:100%;background:#1e2447}.message{color:#6550da;font-size:13px;min-height:20px}footer{text-align:center;padding:24px;color:#8c91a5;font-size:11px}@media(max-width:650px){header{padding:0 5%}.hero{padding:60px 7%}.game-symbol{right:-20px;opacity:.5}.cards{grid-template-columns:1fr}.cover{height:140px}.products{padding:40px 6%}}`,
      js: `document.querySelectorAll('.order').forEach(button=>button.addEventListener('click',()=>{const message=document.getElementById('message');message.textContent='Kamu memilih: '+button.dataset.item+'. Atur tautan pemesanan admin sebelum website dipublikasikan.';button.textContent='Dipilih ✓';setTimeout(()=>button.textContent='Pilih produk',1800);}));`
    },
    portfolio: {
      html: `<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Creative Portfolio</title><link rel="stylesheet" href="style.css"></head><body><header><a class="logo" href="#">AR<span>✦</span></a><nav><a href="#work">Karya</a><a href="#about">Tentang</a><a href="#contact">Kontak</a></nav></header><main><section class="hero"><div class="eyebrow">DESAINER DIGITAL · KREATOR</div><h1>Halo, aku<br><span>kreator visual.</span></h1><p>Aku membantu ide menjadi pengalaman digital yang menarik, sederhana, dan bermakna.</p><a class="cta" href="#work">Lihat karya ↘</a><div class="shape">✳</div></section><section id="work" class="work"><small>SELECTED WORK</small><h2>Proyek pilihan</h2><div class="tiles"><article><span>01</span><h3>Brand Identity</h3><p>Sistem visual yang berkarakter.</p></article><article><span>02</span><h3>Web Experience</h3><p>Website responsif dan modern.</p></article><article><span>03</span><h3>Social Content</h3><p>Konten kreatif untuk audiens.</p></article></div></section><section id="about" class="about"><h2>Desain yang punya tujuan.</h2><p>Tambahkan bio, pengalaman, dan pencapaianmu di bagian ini.</p></section><section id="contact" class="contact"><h2>Ada ide menarik?</h2><a class="cta" href="mailto:halo@example.com">Mari ngobrol ↗</a></section></main><footer>© 2026 Creative Portfolio</footer></body></html>`,
      css: `*{box-sizing:border-box}body{margin:0;background:#f7f7fb;color:#191b2d;font-family:Arial,sans-serif}header{height:75px;padding:0 9%;display:flex;align-items:center;justify-content:space-between;background:#fff}.logo{font-size:23px;font-weight:900;text-decoration:none;color:#24203f}.logo span{color:#8060ed}nav{display:flex;gap:24px}nav a{font-size:12px;color:#65677b;text-decoration:none}.hero{padding:100px 10%;background:#eeeaff;position:relative;overflow:hidden}.eyebrow,small{font-size:10px;letter-spacing:2px;color:#8060ed;font-weight:bold}.hero h1{font-size:clamp(45px,7vw,78px);line-height:1.03;letter-spacing:-3px;margin:20px 0}.hero h1 span{color:#8060ed}.hero p{max-width:450px;line-height:1.8;color:#696b80}.cta{display:inline-block;background:#8060ed;color:white;text-decoration:none;padding:13px 18px;border-radius:8px;font-size:12px;font-weight:bold;margin-top:12px}.shape{position:absolute;right:14%;top:20%;font-size:100px;color:#b4a5ff;transform:rotate(18deg)}.work{padding:65px 9%}.work h2,.about h2,.contact h2{font-size:32px}.tiles{display:grid;grid-template-columns:repeat(3,1fr);gap:15px;margin-top:25px}.tiles article{min-height:170px;background:#fff;border:1px solid #e7e5f1;border-radius:13px;padding:22px}.tiles span{color:#8060ed;font-size:11px}.tiles h3{margin-top:35px}.tiles p,.about p{font-size:13px;color:#7a7b8f;line-height:1.7}.about{padding:55px 9%;background:#fff}.contact{text-align:center;padding:55px 20px}.contact h2{margin-bottom:10px}footer{text-align:center;color:#9294a5;padding:20px;font-size:11px}@media(max-width:650px){header{padding:0 6%}nav{gap:10px}nav a{font-size:10px}.hero{padding:75px 7%}.hero h1{font-size:48px}.shape{right:-20px;opacity:.4}.tiles{grid-template-columns:1fr}.tiles article{min-height:130px}.tiles h3{margin-top:20px}.work{padding:45px 7%}}`,
      js: `document.querySelectorAll('a[href^="#"]').forEach(link=>link.addEventListener('click',event=>{const target=document.querySelector(link.getAttribute('href'));if(target){event.preventDefault();target.scrollIntoView({behavior:'smooth'});}}));`
    },
    blank: {
      html: `<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Website Baru</title><link rel="stylesheet" href="style.css"></head><body><main class="page"><h1>Website Baru</h1><p>Mulai tulis konten website kamu di sini.</p><button id="helloButton">Coba tombol</button><p id="message"></p></main><script src="script.js"></script></body></html>`,
      css: `*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:#f6f7fb;color:#20243a}.page{max-width:850px;margin:12vh auto;padding:30px}.page h1{font-size:42px}.page p{color:#69718a;line-height:1.7}button{border:0;background:#7257ed;color:white;padding:12px 18px;border-radius:8px;font-weight:bold;cursor:pointer}`,
      js: `const button=document.getElementById('helloButton');if(button){button.addEventListener('click',()=>{document.getElementById('message').textContent='Tombol berfungsi! Silakan edit kode ini.';});}`
    }
  };
  let currentFile = "html";
  let project = { name: "My Website", ...templates.landing };
  let imageData = null;
  let toastTimer = null;

  function toast(message) {
    const node = $("toast"); node.textContent = message; node.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => node.classList.remove("show"), 2600);
  }
  function log(message, warning=false) {
    const p = document.createElement("p");
    const dot = document.createElement("span"); dot.className = warning ? "log-warn" : "log-ok"; dot.textContent = "●";
    p.append(dot, document.createTextNode(" " + message)); $("activityLog").prepend(p);
  }
  function showModal(title, html) {
    $("modalTitle").textContent = title; $("modalBody").innerHTML = html;
    if (typeof $("modal").showModal === "function") $("modal").showModal();
    else toast(title + ": " + $("modalBody").textContent.slice(0,100));
  }
  function getFile() { return currentFile === "html" ? "html" : currentFile === "css" ? "css" : "js"; }
  function updateStats() {
    $("projectNameStat").textContent = project.name || "My Website";
    $("fileCount").textContent = (imageData ? "4 file" : "3 file");
    $("lineCount").textContent = Math.max(1, $("codeEditor").value.split("\n").length) + " baris";
  }
  function renderEditor() {
    $("codeEditor").value = project[getFile()] || "";
    $("editorFilename").textContent = currentFile === "html" ? "index.html" : currentFile === "css" ? "style.css" : "script.js";
    document.querySelectorAll(".file-tab").forEach(tab => tab.classList.toggle("active", tab.dataset.file === currentFile));
    updateStats();
  }
  function syncEditor() {
    project[getFile()] = $("codeEditor").value;
    updateStats();
    saveLocal(false);
    clearTimeout(syncEditor.timer);
    syncEditor.timer = setTimeout(renderPreview, 250);
  }
  function buildPreviewDocument() {
    let html = project.html || "";
    const css = project.css || "";
    const js = project.js || "";
    html = html.replace(/<link\b[^>]*href=["']style\.css["'][^>]*>/i, "");
    html = html.replace(/<script\b[^>]*src=["']script\.js["'][^>]*><\/script>/i, "");
    const styleTag = "<style>" + css.replace(/<\/style/gi, "<\\/style") + "</style>";
    const scriptTag = "<script>" + js.replace(/<\/script/gi, "<\\/script") + "<\/script>";
    if (/<\/head>/i.test(html)) html = html.replace(/<\/head>/i, styleTag + "</head>");
    else html = styleTag + html;
    if (/<\/body>/i.test(html)) html = html.replace(/<\/body>/i, scriptTag + "</body>");
    else html += scriptTag;
    if (imageData) {
      const imageTag = '<div style="position:fixed;right:12px;bottom:12px;z-index:9999;background:#fff;padding:6px;border-radius:10px;box-shadow:0 3px 20px #0003;font:12px Arial"><img alt="Gambar lokal" src="' + imageData + '" style="max-width:70px;max-height:55px;display:block"><span>Gambar lokal terpilih</span></div>';
      html = html.replace(/<\/body>/i, imageTag + "</body>");
    }
    return html;
  }
  function renderPreview() {
    const frame = $("previewFrame");
    frame.srcdoc = buildPreviewDocument();
  }
  function saveLocal(showMessage=true) {
    project.name = $("projectName").value.trim() || "My Website";
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(project));
      const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
      const entry = { ...project, savedAt: new Date().toISOString() };
      const filtered = history.filter(item => item.name !== entry.name);
      filtered.unshift(entry);
      localStorage.setItem(HISTORY_KEY, JSON.stringify(filtered.slice(0,10)));
      updateStats();
      if (showMessage) { toast("Proyek tersimpan di browser perangkat ini."); log("Proyek '" + project.name + "' disimpan ke penyimpanan lokal."); }
      return true;
    } catch (error) {
      toast("Penyimpanan gagal. Ruang browser mungkin penuh.");
      log("Penyimpanan lokal gagal: " + error.message, true);
      return false;
    }
  }
  function loadLocal() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (saved && saved.html) { project = { name: saved.name || "My Website", html: saved.html, css: saved.css || "", js: saved.js || "" }; $("projectName").value = project.name; }
    } catch (_) {}
  }
  function applyTemplate(name) {
    const template = templates[name] || templates.landing;
    project = { name: $("projectName").value.trim() || "My Website", html: template.html, css: template.css, js: template.js };
    imageData = null; currentFile = "html"; renderEditor(); renderPreview(); saveLocal(false);
    toast("Template berhasil diterapkan."); log("Template '" + name + "' diterapkan.");
  }
  function checkHtml() {
    syncEditor();
    const html = project.html;
    const problems = [];
    if (!/<html[\s>]/i.test(html)) problems.push("Tag <html> tidak ditemukan.");
    if (!/<head[\s>]/i.test(html)) problems.push("Tag <head> tidak ditemukan.");
    if (!/<body[\s>]/i.test(html)) problems.push("Tag <body> tidak ditemukan.");
    if (!/<meta[^>]+name=["']viewport["']/i.test(html)) problems.push("Meta viewport belum ditemukan; tampilan HP mungkin tidak responsif.");
    const openTags = (html.match(/<(div|section|main|header|footer|nav|article|p|h1|h2|button)\b/gi) || []).length;
    const closeTags = (html.match(/<\/(div|section|main|header|footer|nav|article|p|h1|h2|button)\s*>/gi) || []).length;
    if (openTags !== closeTags) problems.push("Jumlah tag umum pembuka dan penutup berbeda. Periksa markup secara manual.");
    if (!problems.length) {
      showModal("Pemeriksaan HTML", "<p>✓ Pemeriksaan dasar selesai. Tidak ditemukan masalah umum yang diperiksa.</p><p><b>Catatan:</b> ini bukan validator HTML lengkap dan tidak menjamin semua kode bebas error.</p>");
      log("Pemeriksaan HTML dasar selesai: tidak ada temuan.");
    } else {
      showModal("Pemeriksaan HTML", "<p>Ditemukan " + problems.length + " catatan:</p><ul>" + problems.map(item => "<li>" + escapeHtml(item) + "</li>").join("") + "</ul><p>Perbaiki di editor, lalu periksa kembali.</p>");
      log("Pemeriksaan HTML menemukan " + problems.length + " catatan.", true);
    }
  }
  function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c])); }
  function formatCode() {
    const value = $("codeEditor").value;
    // Conservative formatter: trim line edges only; avoids corrupting embedded scripts/strings.
    $("codeEditor").value = value.split("\n").map(line => line.trimEnd()).join("\n").trim() + "\n";
    syncEditor(); toast("Spasi akhir dirapikan."); log("Kode dirapikan secara ringan (tanpa mengubah struktur).");
  }
  function exportProject() {
    syncEditor();
    if (!window.JSZip) {
      showModal("Ekspor ZIP membutuhkan koneksi", "<p>Library pembuat ZIP belum termuat. Sambungkan internet, lalu muat ulang halaman dan coba lagi.</p><p>Editor dan preview tetap bisa dipakai offline setelah halaman dimuat, tetapi ekspor ZIP memakai JSZip dari CDN.</p>");
      log("Ekspor ZIP gagal karena library JSZip tidak tersedia.", true); return;
    }
    const zip = new JSZip();
    zip.file("index.html", project.html || "");
    zip.file("style.css", project.css || "");
    zip.file("script.js", project.js || "");
    zip.file("README.txt", "Website dibuat dengan Ultimate Website Builder — Futuristic AI Studio.\\n\\nCara pakai:\\n1. Ekstrak file ZIP.\\n2. Buka index.html di browser untuk uji lokal.\\n3. Upload semua file ke hosting statis untuk membuatnya online.\\n\\nCatatan: tautan, formulir, pembayaran, database, dan fitur server harus dikonfigurasi sesuai layanan yang digunakan.\\n");
    if (imageData) {
      const match = imageData.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
      if (match) {
        const ext = match[1].split("/")[1].replace("jpeg","jpg").replace(/[^a-z0-9]/gi,"") || "png";
        zip.file("assets/gambar." + ext, match[2], {base64:true});
      }
    }
    const filename = (project.name || "website").toLowerCase().replace(/[^a-z0-9-_]+/g,"-").replace(/^-+|-+$/g,"") || "website";
    toast("Sedang membuat ZIP…");
    zip.generateAsync({type:"blob"}).then(blob => {
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a"); link.href = url; link.download = filename + ".zip"; document.body.appendChild(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      toast("ZIP berhasil dibuat."); log("ZIP '" + filename + ".zip' berhasil diekspor.");
    }).catch(error => { toast("Gagal membuat ZIP."); log("Ekspor ZIP gagal: " + error.message, true); });
  }
  function openPreviewTab() {
    const blob = new Blob([buildPreviewDocument()], {type:"text/html"});
    const url = URL.createObjectURL(blob);
    const opened = window.open(url, "_blank", "noopener");
    if (!opened) { toast("Popup diblokir. Gunakan preview di panel ini."); }
    else toast("Preview dibuka di tab baru.");
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
  function quickAssist() {
    const prompt = $("aiPrompt").value.trim().toLowerCase();
    if (!prompt) { toast("Tulis dulu ide yang ingin dibuat."); $("aiPrompt").focus(); return; }
    let suggestion = "";
    if (prompt.includes("toko") || prompt.includes("store") || prompt.includes("game")) suggestion = "store";
    else if (prompt.includes("portofolio") || prompt.includes("portfolio") || prompt.includes("kreator")) suggestion = "portfolio";
    else suggestion = "landing";
    showModal("AI Quick Assist — Saran Lokal", "<p>Ide kamu cocok dimulai dari template <b>" + suggestion + "</b>.</p><p>Asisten ini bekerja dengan aturan/pola yang ada di dalam aplikasi, bukan model AI online. Klik <b>Terapkan Template</b> untuk memakainya.</p><p>Untuk generasi kode AI sungguhan, sambungkan backend aman ke API AI. Jangan simpan API key rahasia di JavaScript frontend.</p><button id='useSuggestion' class='btn btn-primary'>Terapkan saran</button>");
    setTimeout(() => { const button = document.getElementById("useSuggestion"); if (button) button.addEventListener("click", () => { $("templateSelect").value = suggestion; $("modal").close(); applyTemplate(suggestion); }); }, 0);
    log("Quick Assist memberi saran template: " + suggestion + ".", true);
  }
  function showHistory() {
    let history = [];
    try { history = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]"); } catch (_) {}
    if (!history.length) { showModal("Riwayat Proyek", "<p>Belum ada riwayat. Tekan <b>Simpan Proyek</b> untuk menyimpan proyek di perangkat ini.</p>"); return; }
    const list = history.map((item,index) => "<li><b>" + escapeHtml(item.name || "My Website") + "</b><br><small>" + escapeHtml(new Date(item.savedAt || Date.now()).toLocaleString("id-ID")) + "</small><br><button class='small-btn history-load' data-index='" + index + "'>Buka proyek</button></li>").join("");
    showModal("Riwayat Proyek", "<ul class='history-list'>" + list + "</ul><p>Riwayat tersimpan hanya pada browser dan perangkat ini.</p>");
    setTimeout(() => document.querySelectorAll(".history-load").forEach(button => button.addEventListener("click", () => {
      const item = history[Number(button.dataset.index)]; if (!item) return;
      project = {name:item.name || "My Website",html:item.html || "",css:item.css || "",js:item.js || ""};
      $("projectName").value = project.name; imageData = null; currentFile = "html"; renderEditor(); renderPreview(); saveLocal(false); $("modal").close(); toast("Proyek riwayat dibuka."); log("Proyek dari riwayat dibuka.");
    })), 0);
  }
  $("codeEditor").addEventListener("input", syncEditor);
  $("projectName").addEventListener("input", () => { project.name = $("projectName").value.trim() || "My Website"; updateStats(); saveLocal(false); });
  document.querySelectorAll(".file-tab").forEach(tab => tab.addEventListener("click", () => { syncEditor(); currentFile = tab.dataset.file; renderEditor(); }));
  $("applyTemplateBtn").addEventListener("click", () => applyTemplate($("templateSelect").value));
  $("newProjectBtn").addEventListener("click", () => {
    if (confirm("Buat proyek baru? Perubahan yang belum disimpan di luar penyimpanan browser bisa hilang.")) {
      $("projectName").value = "My Website"; applyTemplate("blank"); toast("Proyek baru siap.");
    }
  });
  $("saveBtn").addEventListener("click", () => { syncEditor(); saveLocal(true); });
  $("checkBtn").addEventListener("click", checkHtml);
  $("historyBtn").addEventListener("click", showHistory);
  $("aiBtn").addEventListener("click", quickAssist);
  $("uploadBtn").addEventListener("click", () => $("imageInput").click());
  $("imageInput").addEventListener("change", event => {
    const file = event.target.files && event.target.files[0]; if (!file) return;
    if (!file.type.startsWith("image/")) { toast("Pilih file gambar."); return; }
    if (file.size > 5 * 1024 * 1024) { toast("Ukuran gambar maksimal 5 MB."); event.target.value = ""; return; }
    const reader = new FileReader();
    reader.onload = () => { imageData = String(reader.result); renderPreview(); updateStats(); toast("Gambar dimuat untuk preview dan ekspor."); log("Gambar '" + file.name + "' dimuat. File akan dimasukkan ke ZIP sebagai assets/gambar."); };
    reader.onerror = () => toast("Gambar tidak dapat dibaca.");
    reader.readAsDataURL(file);
  });
  $("refreshPreviewBtn").addEventListener("click", () => { syncEditor(); renderPreview(); toast("Preview diperbarui."); });
  $("openPreviewBtn").addEventListener("click", openPreviewTab);
  $("exportBtn").addEventListener("click", exportProject);
  $("formatBtn").addEventListener("click", formatCode);
  $("clearLogBtn").addEventListener("click", () => { $("activityLog").innerHTML = ""; log("Log aktivitas dibersihkan."); });
  $("helpBtn").addEventListener("click", () => showModal("Panduan Studio", "<p><b>Mulai cepat:</b></p><ul><li>Pilih template lalu tekan Terapkan Template.</li><li>Edit HTML, CSS, atau JavaScript lewat tab editor.</li><li>Preview diperbarui otomatis setelah perubahan.</li><li>Tekan Simpan Proyek agar data tersimpan di browser ini.</li><li>Tekan Ekspor ZIP untuk mengunduh website.</li></ul><p><b>Yang belum otomatis:</b> database, login aman, pembayaran, hosting, dan AI online membutuhkan layanan/backend terpisah.</p>"));
  $("modalClose").addEventListener("click", () => $("modal").close());
  $("modalOk").addEventListener("click", () => $("modal").close());
  $("modal").addEventListener("click", event => { if (event.target === $("modal")) $("modal").close(); });
  loadLocal(); renderEditor(); renderPreview();
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
  }
})();