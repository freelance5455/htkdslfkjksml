# Ember Drift (Android)

A WebView wrapper around the game. The game lives in app/src/main/assets/index.html.

## Build with Android Studio
1. Open this folder in Android Studio and let Gradle sync.
2. Build > Build APK(s).
3. The APK is at app/build/outputs/apk/debug/app-debug.apk

## Build in the cloud (GitHub Actions)
1. Put these files in a new GitHub repository, on the main branch.
2. Open the Actions tab, run "Build APK", then download the ember-drift-apk artifact.

## Install
Copy the APK to your phone, open it, and allow "Install unknown apps" for your file manager or browser.
This is a debug-signed APK, fine for personal use. Google Play needs a signed release build.
