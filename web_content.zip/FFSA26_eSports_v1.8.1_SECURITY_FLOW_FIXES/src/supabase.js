import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL?.trim();
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY?.trim();

export const supabaseConfigured = Boolean(url && key && !url.includes('YOUR_PROJECT'));
export const supabase = supabaseConfigured
  ? createClient(url, key, {
      auth: { autoRefreshToken: true, persistSession: true, detectSessionInUrl: true },
    })
  : null;

const call = async (name, body = {}) => {
  if (!supabase) return { data: null, error: new Error('Supabase is not configured') };
  return supabase.functions.invoke(name, { body });
};

export async function getOrCreateAnonymousSession() {
  if (!supabase) return { user: null, error: null };
  const { data: existing } = await supabase.auth.getSession();
  if (existing?.session?.user) return { user: existing.session.user, error: null };
  const { data, error } = await supabase.auth.signInAnonymously();
  return { user: data?.user ?? null, error };
}

export async function upsertPlayer(player, userId) {
  if (!supabase || !userId || !player) return { data: null, error: null };
  return supabase.from('profiles').upsert({
    user_id: userId,
    free_fire_id: player.freeFireId?.trim() || null,
    in_game_name: player.inGameName?.trim() || null,
    phone: player.phone?.trim() || null,
    email: player.email?.trim().toLowerCase() || null,
    updated_at: new Date().toISOString(),
  });
}

export async function loadPlayer(userId) {
  if (!supabase || !userId) return { data: null, error: null };
  return supabase.from('profiles').select('*').eq('user_id', userId).maybeSingle();
}

export async function createTeam(userId, name, tag, description = '') {
  if (!supabase || !userId) return { data: null, error: new Error('Supabase is not configured') };
  return supabase.rpc('create_team', { p_name: name, p_tag: tag, p_description: description || null });
}

export async function joinTeam(code) {
  if (!supabase) return { data: null, error: new Error('Supabase is not configured') };
  return supabase.rpc('join_team', { p_code: code });
}

export async function loadTeamRoster(teamId) {
  if (!supabase || !teamId) return { data: [], error: null };
  return supabase.rpc('get_team_roster', { p_team_id: teamId });
}

export async function loadMyTeams(userId) {
  if (!supabase || !userId) return { data: [], error: null };
  return supabase.rpc('get_my_teams');
}

export async function loadTournaments() {
  if (!supabase) return { data: [], error: null };
  return supabase.from('tournaments').select('*').order('start_at', { ascending: true, nullsFirst: false });
}

export async function loadMyRegistrations(userId) {
  if (!supabase || !userId) return { data: [], error: null };
  return supabase.from('registrations').select('*,tournaments(name,mode,start_at,capacity,entry_fee,map_name,prize_data,status)').eq('user_id', userId).order('created_at', { ascending: false });
}

export async function createRegistration(payload) {
  if (!supabase) return { data: null, error: new Error('Supabase is not configured') };
  return supabase.rpc('create_registration', {
    p_tournament_id: payload.tournament_id,
    p_team_id: payload.team_id || null,
    p_free_fire_id: payload.free_fire_id,
    p_in_game_name: payload.in_game_name,
    p_phone: payload.phone || null,
    p_players: payload.players || [],
    p_payment_method: payload.payment_method || 'Wallet',
  });
}

export async function cancelPendingRegistration(id) {
  if (!supabase || !id) return { data: null, error: new Error('Supabase is not configured') };
  return supabase.rpc('cancel_pending_registration', { p_registration_id: id });
}

export async function updateRegistration(id, patch) {
  if (!supabase || !id) return { data: null, error: null };
  return supabase.from('registrations').update(patch).eq('id', id).select().single();
}

export async function loadWallet(userId) {
  if (!supabase || !userId) return { data: null, error: null };
  return supabase.from('wallets').select('user_id,balance,currency,updated_at').eq('user_id', userId).maybeSingle();
}

export async function loadWalletTransactions(userId) {
  if (!supabase || !userId) return { data: [], error: null };
  return supabase.from('wallet_transactions').select('*').eq('user_id', userId).order('created_at', { ascending: false });
}

export async function loadPendingTopups(userId) {
  if (!supabase || !userId) return { data: [], error: null };
  return supabase.from('wallet_topups').select('*').eq('user_id', userId).order('created_at', { ascending: false });
}

export async function loadWithdrawals(userId) {
  if (!supabase || !userId) return { data: [], error: null };
  return supabase.from('wallet_withdrawals').select('*').eq('user_id', userId).order('created_at', { ascending: false });
}

export async function requestTopup(userId, amount) {
  if (!supabase || !userId) return { data: null, error: new Error('Supabase is not configured') };
  return call('payu-create-topup', { amount });
}

export async function requestWithdrawal(userId, amount, method, identifier) {
  if (!supabase || !userId) return { data: null, error: new Error('Supabase is not configured') };
  return supabase.rpc('request_wallet_withdrawal', { p_amount: amount, p_method: method, p_identifier: identifier });
}

export async function payTournamentEntry(userId, tournamentId, amount, registrationId) {
  if (!supabase || !userId) return { data: null, error: new Error('Supabase is not configured') };
  return supabase.rpc('debit_tournament_entry', { p_tournament_id: tournamentId, p_amount: amount, p_registration_id: registrationId });
}

export async function submitPaymentProof({ registrationId, reference, file, userId }) {
  if (!supabase || !userId || !registrationId || !reference || !file) return { data: null, error: new Error('Payment proof is incomplete') };
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const path = `${userId}/${registrationId}/${Date.now()}-${safeName}`;
  const upload = await supabase.storage.from('payment-screenshots').upload(path, file, { upsert: false, contentType: file.type || 'image/*' });
  if (upload.error) return { data: null, error: upload.error };
  const result = await supabase.from('payment_submissions').insert({ user_id: userId, registration_id: registrationId, reference: reference.trim(), screenshot_path: path, status: 'pending' }).select().single();
  if (result.error) await supabase.storage.from('payment-screenshots').remove([path]);
  return result;
}

export async function loadNotifications(userId) {
  if (!supabase || !userId) return { data: [], error: null };
  return supabase.from('notifications').select('*').eq('user_id', userId).order('created_at', { ascending: false }).limit(50);
}

export async function submitSupportTicket(userId, subject, message) {
  if (!supabase || !userId) return { data: null, error: new Error('Supabase is not configured') };
  return supabase.from('support_tickets').insert({ user_id: userId, subject: subject.trim(), message: message.trim(), status: 'open' }).select().single();
}

export async function markNotificationRead(id) {
  if (!supabase || !id) return { data: null, error: null };
  return supabase.from('notifications').update({ read_at: new Date().toISOString() }).eq('id', id).select().single();
}

export async function cancelRegistration(id) {
  if (!supabase || !id) return { data: null, error: new Error('Supabase is not configured') };
  return supabase.rpc('cancel_registration', { p_registration_id: id });
}

export async function loadPublishedResults() {
  if (!supabase) return { data: [], error: null };
  return supabase.from('tournament_results').select('*,tournaments(name,mode,start_at,map_name)').order('declared_at', { ascending: false });
}
