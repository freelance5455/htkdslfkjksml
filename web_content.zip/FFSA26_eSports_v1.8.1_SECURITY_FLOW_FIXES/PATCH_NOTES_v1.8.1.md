# FFSA26 eSports v1.8.1 — Bug & Flow Fixes

## Frontend fixes
- Home now prefers an actual upcoming/open tournament instead of blindly selecting the first record.
- Tournament details show the real status and prevent registration when the tournament is not open.
- Player details now support email required for PayU wallet checkout while phone/email remain outside tournament registration.
- Duo/Squad registration requires a real team roster with the correct number of completed player profiles.
- Duplicate registration is blocked by the database function and surfaced to the player.
- Match status/history can load multiple cloud registrations instead of only one local record.
- Registration cancellation is protected and shows a refund when a wallet-paid registration is cancelled before room release.
- Withdrawal method mismatch fixed: UI now sends `BANK`, matching the database RPC.
- Payment proof now uploads to the private `payment-screenshots` bucket and creates a real payment-submission row.
- Notifications load from Supabase and can be marked read.
- Support requests are persisted as real support tickets when Supabase is connected.
- Local storage parsing is guarded against corrupted JSON.
- Wallet transaction types are normalized so top-ups, winnings, refunds and withdrawals appear in the correct sections.

## Backend/database fixes
- Registration creation moved behind a SECURITY DEFINER validation function.
- Tournament entry debit is idempotent and validates registration ownership/tournament ownership.
- Capacity is checked while the tournament row is locked.
- Wallet withdrawal uses the correct `BANK` method value and row locking.
- Player cancellation is server-controlled and refunds a wallet-paid entry only when room credentials have not been released.
- Team creation generates a unique join code and owner membership atomically.
- Team joining is performed by a server-side RPC.
- Team roster is exposed only to authenticated members through a controlled RPC.
- Added notifications and support-ticket tables with RLS.
- Added top-up idempotency/provider transaction fields.
- PayU top-up checkout and callback live in Supabase Edge Functions; merchant secrets are never exposed to the browser.

## Intentionally not faked
- No fake wallet credits.
- No fake winnings/refunds.
- No fake tournament records.
- No client-side payment-success crediting.
- No fabricated team search results.
