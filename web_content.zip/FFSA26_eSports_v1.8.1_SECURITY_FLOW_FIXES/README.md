# FFSA26 eSports v1.8.1 — Wallet Home

Mobile-only FFSA26 eSports frontend update based on v1.6.0.

## Changes
- Upcoming Tournaments moved to the top of Home.
- Explore Bermuda moved directly below Upcoming Tournaments.
- Added Wallet section and navigation.
- Added wallet balance (starts at ₹0; no dummy funds).
- Add Money flow with PayU server-verification boundary.
- Pending top-up tracking.
- Withdrawal request flow for UPI/bank destinations.
- Wallet transaction ledger and transaction detail page.
- Winnings and Refunds/Reversals pages.
- Wallet Limits & Security page.
- Tournament registration now uses wallet balance for entry fee. Insufficient balance blocks payment and routes to Add Money.
- No client-side wallet credit, fake winnings, fake refunds, or fake successful payments.
- Existing legacy Payment Verification page remains available from Menu so an existing feature is not removed.

## Production wallet backend contract
The included Supabase Edge Functions provide the PayU wallet top-up initiation and callback verification boundary. The frontend never credits money from a client redirect. Withdrawal processing and organizer winnings/refunds still require a trusted admin/backend operation; the client cannot call the wallet-credit function.

Suggested authenticated endpoints:
- `POST /api/wallet/topups/create`
- `POST /api/wallet/topups/verify`
- `GET /api/wallet`
- `GET /api/wallet/transactions`
- `POST /api/wallet/withdrawals`
- `GET /api/wallet/withdrawals`
- `GET /api/wallet/transaction/:id`

PayU credentials must remain backend-only.

## Termux
Run `bash setup-termux.sh` from the extracted folder. The setup script copies the project into Termux private storage before installing dependencies.


## Supabase backend

This version adds Supabase Auth + Postgres + RLS as the cloud persistence layer. The browser uses only the Supabase publishable key. Configure:

```bash
cp .env.example .env
# edit .env with your Supabase project URL and publishable key
```

Then run `supabase/schema.sql` in the Supabase SQL Editor. Anonymous Auth must be enabled if you want the existing login-free player flow; Supabase documents anonymous sign-in as an authenticated session protected by RLS.

The app keeps a local fallback when Supabase is not configured. Wallet credits are intentionally not client-controlled: top-ups remain pending until server-side PayU verification, and wallet withdrawal/entry-fee debit operations use database RPCs with row locking. Supabase recommends RLS for exposed tables and keeping secret/service keys server-side.

Official docs: https://supabase.com/docs/guides/auth/auth-anonymous and https://supabase.com/docs/guides/database/row-level-security
