alter table public.profiles add column if not exists email text;
-- FFSA26 eSports v1.8.1 security/data-integrity patch
-- Run after the original v1.8.0 schema.sql.

alter table public.teams add column if not exists join_code text;
update public.teams set join_code = upper(substr(encode(gen_random_bytes(5),'hex'),1,8)) where join_code is null;
alter table public.teams alter column join_code set not null;
create unique index if not exists teams_join_code_uidx on public.teams(join_code);

alter table public.registrations add column if not exists players jsonb not null default '[]'::jsonb;
alter table public.registrations add column if not exists room_id text;
alter table public.registrations add column if not exists room_password text;
alter table public.registrations add column if not exists room_released_at timestamptz;
alter table public.registrations add column if not exists match_at timestamptz;
alter table public.registrations add column if not exists prize_amount numeric(12,2);
create index if not exists registrations_tournament_status_idx on public.registrations(tournament_id,status,created_at);
create unique index if not exists registrations_tournament_team_uidx on public.registrations(tournament_id,team_id) where team_id is not null and status <> 'cancelled';

alter table public.wallet_topups add column if not exists idempotency_key text;
alter table public.wallet_topups add column if not exists provider text not null default 'PayU';
alter table public.wallet_topups add column if not exists provider_transaction_id text;
create unique index if not exists wallet_topups_idempotency_uidx on public.wallet_topups(user_id,idempotency_key) where idempotency_key is not null;
create unique index if not exists wallet_topups_provider_tx_uidx on public.wallet_topups(provider_transaction_id) where provider_transaction_id is not null;

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null,
  title text not null,
  message text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_created_idx on public.notifications(user_id,created_at desc);
alter table public.notifications enable row level security;
drop policy if exists notifications_owner_select on public.notifications;
create policy notifications_owner_select on public.notifications for select to authenticated using (auth.uid()=user_id);
drop policy if exists notifications_owner_update on public.notifications;
create policy notifications_owner_update on public.notifications for update to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null,
  message text not null,
  status text not null default 'open' check (status in ('open','in_progress','resolved','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists support_tickets_user_created_idx on public.support_tickets(user_id,created_at desc);
alter table public.support_tickets enable row level security;
drop policy if exists support_owner_select on public.support_tickets;
create policy support_owner_select on public.support_tickets for select to authenticated using (auth.uid()=user_id);
drop policy if exists support_owner_insert on public.support_tickets;
create policy support_owner_insert on public.support_tickets for insert to authenticated with check (auth.uid()=user_id and status='open');

-- Create a real team and its owner membership atomically.
create or replace function public.create_team(p_name text,p_tag text,p_description text default null)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_team_id uuid; v_code text; v_name text; v_tag text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  v_name := trim(coalesce(p_name,''));
  v_tag := upper(trim(coalesce(p_tag,'')));
  if length(v_name) < 2 or length(v_name) > 40 then raise exception 'Team name must be 2-40 characters'; end if;
  if v_tag !~ '^[A-Z0-9]{2,5}$' then raise exception 'Team tag must be 2-5 letters/numbers'; end if;
  loop
    v_code := upper(substr(encode(gen_random_bytes(6),'hex'),1,8));
    exit when not exists(select 1 from public.teams where join_code=v_code);
  end loop;
  insert into public.teams(owner_id,name,tag,description,join_code)
    values(auth.uid(),v_name,v_tag,nullif(trim(p_description),''),v_code)
    returning id into v_team_id;
  insert into public.team_members(team_id,user_id,role) values(v_team_id,auth.uid(),'owner');
  return jsonb_build_object('id',v_team_id,'name',v_name,'tag',v_tag,'description',nullif(trim(p_description),''),'join_code',v_code);
end;
$$;

grant execute on function public.create_team(text,text,text) to authenticated;

-- Join by a real team code. No fabricated search result is possible.
create or replace function public.join_team(p_code text)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_team public.teams%rowtype;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into v_team from public.teams where join_code=upper(trim(coalesce(p_code,''))) for update;
  if not found then raise exception 'Team code not found'; end if;
  if exists(select 1 from public.team_members where team_id=v_team.id and user_id=auth.uid()) then
    return jsonb_build_object('id',v_team.id,'name',v_team.name,'tag',v_team.tag,'description',v_team.description,'join_code',v_team.join_code,'already_member',true);
  end if;
  insert into public.team_members(team_id,user_id,role) values(v_team.id,auth.uid(),'member');
  return jsonb_build_object('id',v_team.id,'name',v_team.name,'tag',v_team.tag,'description',v_team.description,'join_code',v_team.join_code,'already_member',false);
end;
$$;
grant execute on function public.join_team(text) to authenticated;

-- Create a pending registration only after validating tournament/team and duplicate state.
drop function if exists public.create_registration(uuid,uuid,text,text,text,jsonb);
create or replace function public.create_registration(
  p_tournament_id uuid,
  p_team_id uuid,
  p_free_fire_id text,
  p_in_game_name text,
  p_phone text default null,
  p_players jsonb default '[]'::jsonb,
  p_payment_method text default 'Wallet'
)
returns public.registrations language plpgsql security definer set search_path=public
as $$
declare v_t public.tournaments%rowtype; v_r public.registrations%rowtype; v_count integer; v_players jsonb;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into v_t from public.tournaments where id=p_tournament_id for update;
  if not found then raise exception 'Tournament not found'; end if;
  if v_t.status <> 'open' then raise exception 'Tournament is not open'; end if;
  if exists(select 1 from public.registrations where user_id=auth.uid() and tournament_id=p_tournament_id and status <> 'cancelled') then raise exception 'Already registered for this tournament'; end if;
  if p_team_id is not null and exists(select 1 from public.registrations where team_id=p_team_id and tournament_id=p_tournament_id and status <> 'cancelled') then raise exception 'This team is already registered for this tournament'; end if;
  if v_t.mode='Solo' then
    if p_team_id is not null then raise exception 'Solo tournaments do not use teams'; end if;
    v_players := jsonb_build_array(jsonb_build_object('free_fire_id',trim(p_free_fire_id),'in_game_name',trim(p_in_game_name)));
  else
    if p_team_id is null or not exists(select 1 from public.team_members where team_id=p_team_id and user_id=auth.uid()) then raise exception 'Select a team you belong to'; end if;
    v_players := coalesce(p_players,'[]'::jsonb);
    if jsonb_array_length(v_players) <> case when v_t.mode='Duo' then 2 else 4 end then raise exception 'Team registration requires the correct number of players'; end if;
  end if;
  if trim(coalesce(p_free_fire_id,''))='' or trim(coalesce(p_in_game_name,''))='' then raise exception 'Player Free Fire ID and in-game name are required'; end if;
  select count(*) into v_count from public.registrations where tournament_id=p_tournament_id and status='registered';
  if v_t.capacity > 0 and v_count >= v_t.capacity then raise exception 'Tournament registration is full'; end if;
  if p_payment_method not in ('Wallet','Manual') then raise exception 'Invalid payment method'; end if;
  insert into public.registrations(user_id,tournament_id,team_id,free_fire_id,in_game_name,phone,status,payment_method,payment_status,players)
  values(auth.uid(),p_tournament_id,p_team_id,trim(p_free_fire_id),trim(p_in_game_name),nullif(trim(p_phone),''),'payment_pending',p_payment_method,'pending',v_players)
    returning * into v_r;
  return v_r;
end;
$$;
grant execute on function public.create_registration(uuid,uuid,text,text,text,jsonb,text) to authenticated;

-- Idempotent, ownership-checked entry debit. It cannot charge a registration twice.
create or replace function public.debit_tournament_entry(p_tournament_id uuid,p_amount numeric,p_registration_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_balance numeric(12,2); v_fee numeric(12,2); v_status text; v_reg public.registrations%rowtype; v_count integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into v_reg from public.registrations where id=p_registration_id and user_id=auth.uid() and tournament_id=p_tournament_id for update;
  if not found then raise exception 'Registration not found'; end if;
  if exists(select 1 from public.wallet_transactions where registration_id=p_registration_id and type='tournament_entry' and status='completed') then
    select balance into v_balance from public.wallets where user_id=auth.uid();
    return jsonb_build_object('ok',true,'already_charged',true,'balance',v_balance);
  end if;
  select entry_fee,status into v_fee,v_status from public.tournaments where id=p_tournament_id for update;
  if v_fee is null then raise exception 'Tournament not found'; end if;
  if v_status <> 'open' then raise exception 'Tournament is not open'; end if;
  if p_amount <> v_fee then raise exception 'Entry fee mismatch'; end if;
  select count(*) into v_count from public.registrations where tournament_id=p_tournament_id and status='registered';
  if (select capacity from public.tournaments where id=p_tournament_id) > 0 and v_count >= (select capacity from public.tournaments where id=p_tournament_id) then raise exception 'Tournament registration is full'; end if;
  select balance into v_balance from public.wallets where user_id=auth.uid() for update;
  if v_balance is null or v_balance < v_fee then raise exception 'Insufficient wallet balance'; end if;
  update public.wallets set balance=balance-v_fee,updated_at=now() where user_id=auth.uid();
  update public.registrations set status='registered',payment_status='paid',updated_at=now() where id=p_registration_id;
  insert into public.wallet_transactions(user_id,type,amount,status,tournament_id,registration_id,reference)
    values(auth.uid(),'tournament_entry',-v_fee,'completed',p_tournament_id,p_registration_id,p_registration_id::text);
  return jsonb_build_object('ok',true,'already_charged',false,'balance',v_balance-v_fee);
end;
$$;
grant execute on function public.debit_tournament_entry(uuid,numeric,uuid) to authenticated;

-- Fix the withdrawal method mismatch and keep the operation atomic/idempotent at the DB boundary.
create or replace function public.request_wallet_withdrawal(p_amount numeric,p_method text,p_identifier text)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_balance numeric(12,2); v_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Invalid withdrawal amount'; end if;
  if p_method not in ('UPI','BANK') then raise exception 'Invalid withdrawal method'; end if;
  if coalesce(trim(p_identifier),'') = '' then raise exception 'Withdrawal identifier required'; end if;
  select balance into v_balance from public.wallets where user_id=auth.uid() for update;
  if v_balance is null then raise exception 'Wallet not found'; end if;
  if v_balance < p_amount then raise exception 'Insufficient wallet balance'; end if;
  update public.wallets set balance=balance-p_amount,updated_at=now() where user_id=auth.uid();
  insert into public.wallet_withdrawals(user_id,amount,method,identifier) values(auth.uid(),p_amount,p_method,trim(p_identifier)) returning id into v_id;
  insert into public.wallet_transactions(user_id,type,amount,status,reference,metadata) values(auth.uid(),'withdrawal',-p_amount,'pending',v_id::text,jsonb_build_object('method',p_method));
  return jsonb_build_object('withdrawal_id',v_id,'balance',v_balance-p_amount);
end;
$$;
grant execute on function public.request_wallet_withdrawal(numeric,text,text) to authenticated;

-- Clients can no longer directly create/update registrations; registration-create RPC is the only path.
drop policy if exists registrations_owner_insert on public.registrations;
drop policy if exists registrations_owner_update on public.registrations;

-- The client may create only a pending payment-submission record for itself.
drop policy if exists payment_submissions_owner_insert on public.payment_submissions;
create policy payment_submissions_owner_insert on public.payment_submissions for insert to authenticated
with check (auth.uid()=user_id and status='pending');


create or replace function public.get_team_roster(p_team_id uuid)
returns table(user_id uuid, role text, free_fire_id text, in_game_name text)
language plpgsql security definer set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not exists(select 1 from public.team_members where team_id=p_team_id and user_id=auth.uid()) then raise exception 'You are not a team member'; end if;
  return query
    select tm.user_id,tm.role,p.free_fire_id,p.in_game_name
    from public.team_members tm
    left join public.profiles p on p.user_id=tm.user_id
    where tm.team_id=p_team_id
    order by case when tm.role='owner' then 0 else 1 end, tm.created_at;
end;
$$;
grant execute on function public.get_team_roster(uuid) to authenticated;


create or replace function public.cancel_pending_registration(p_registration_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_status text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select status into v_status from public.registrations where id=p_registration_id and user_id=auth.uid() for update;
  if v_status is null then raise exception 'Registration not found'; end if;
  if v_status not in ('payment_pending','payment_failed') then raise exception 'This registration can no longer be cancelled'; end if;
  update public.registrations set status='cancelled',payment_status='cancelled',updated_at=now() where id=p_registration_id and user_id=auth.uid();
  return jsonb_build_object('ok',true);
end;
$$;
grant execute on function public.cancel_pending_registration(uuid) to authenticated;


create or replace function public.cancel_registration(p_registration_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_reg public.registrations%rowtype; v_ref text; v_refund numeric(12,2);
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into v_reg from public.registrations where id=p_registration_id and user_id=auth.uid() for update;
  if not found then raise exception 'Registration not found'; end if;
  if v_reg.status='cancelled' then return jsonb_build_object('ok',true,'already_cancelled',true); end if;
  if v_reg.room_id is not null then raise exception 'Cancellation is not allowed after room details are released'; end if;
  if v_reg.status in ('completed','closed','started') then raise exception 'This registration can no longer be cancelled'; end if;
  select amount,reference into v_refund,v_ref from public.wallet_transactions where registration_id=v_reg.id and type='tournament_entry' and status='completed' order by created_at desc limit 1;
  if v_refund is not null then
    perform public.credit_wallet(auth.uid(),abs(v_refund),'refund',v_reg.id::text,v_reg.tournament_id,jsonb_build_object('reason','player_cancellation'));
  end if;
  update public.registrations set status='cancelled',payment_status=case when v_refund is not null then 'refunded' else payment_status end,updated_at=now() where id=v_reg.id;
  return jsonb_build_object('ok',true,'refunded',v_refund is not null,'refund_amount',coalesce(abs(v_refund),0));
end;
$$;
grant execute on function public.cancel_registration(uuid) to authenticated;


-- Prevent browser-side bypass of the server-side team/top-up creation flows.
drop policy if exists teams_owner_insert on public.teams;
drop policy if exists teams_owner_update on public.teams;
drop policy if exists teams_owner_delete on public.teams;
drop policy if exists wallet_topups_owner_insert on public.wallet_topups;


create or replace function public.credit_wallet(p_user_id uuid,p_amount numeric,p_type text,p_reference text,p_tournament_id uuid default null,p_metadata jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_balance numeric(12,2); v_existing numeric(12,2);
begin
  if p_amount <= 0 then raise exception 'Credit amount must be positive'; end if;
  if exists(select 1 from public.wallet_transactions where user_id=p_user_id and type=p_type and reference=p_reference and status='completed') then
    select balance into v_balance from public.wallets where user_id=p_user_id;
    return jsonb_build_object('ok',true,'already_credited',true,'balance',v_balance);
  end if;
  update public.wallets set balance=balance+p_amount,updated_at=now() where user_id=p_user_id returning balance into v_balance;
  if v_balance is null then raise exception 'Wallet not found'; end if;
  insert into public.wallet_transactions(user_id,type,amount,status,reference,tournament_id,metadata)
    values(p_user_id,p_type,p_amount,'completed',p_reference,p_tournament_id,coalesce(p_metadata,'{}'::jsonb));
  return jsonb_build_object('ok',true,'already_credited',false,'balance',v_balance);
end;
$$;
revoke all on function public.credit_wallet(uuid,numeric,text,text,uuid,jsonb) from anon,authenticated;


create or replace function public.get_my_teams()
returns table(id uuid, owner_id uuid, name text, tag text, description text, join_code text, created_at timestamptz, updated_at timestamptz)
language sql security definer set search_path=public
as $$
  select t.id,t.owner_id,t.name,t.tag,t.description,t.join_code,t.created_at,t.updated_at
  from public.teams t
  where t.owner_id=auth.uid() or exists(select 1 from public.team_members tm where tm.team_id=t.id and tm.user_id=auth.uid())
  order by t.created_at desc;
$$;
grant execute on function public.get_my_teams() to authenticated;


create table if not exists public.tournament_results (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null unique references public.tournaments(id) on delete cascade,
  winner_user_id uuid references auth.users(id) on delete set null,
  winner_name text not null,
  winner_free_fire_id text,
  winner_team text,
  winning_prize numeric(12,2) not null default 0 check (winning_prize >= 0),
  participants jsonb not null default '[]'::jsonb,
  declared_at timestamptz not null default now()
);
create index if not exists tournament_results_declared_idx on public.tournament_results(declared_at desc);
alter table public.tournament_results enable row level security;
drop policy if exists tournament_results_public_select on public.tournament_results;
create policy tournament_results_public_select on public.tournament_results for select to anon,authenticated using (true);
