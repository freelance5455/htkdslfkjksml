import { createClient } from 'npm:@supabase/supabase-js@2'

async function sha512(value: string) {
  const bytes = new TextEncoder().encode(value)
  const digest = await crypto.subtle.digest('SHA-512', bytes)
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, '0')).join('')
}

function secretKey() {
  const raw = Deno.env.get('SUPABASE_SECRET_KEYS')
  if (raw) {
    try { return JSON.parse(raw).default } catch { /* fall through */ }
  }
  return Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
}

function formToObject(form: FormData) {
  const out: Record<string,string> = {}
  for (const [key, value] of form.entries()) out[key] = String(value)
  return out
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 })
  const form = await req.formData()
  const p = formToObject(form)
  const returnUrl = new URL(req.url).searchParams.get('return_url') || ''
  const txnid = p.txnid || ''
  const status = (p.status || 'failed').toLowerCase()
  const amount = p.amount || ''
  const topupId = p.udf1 || ''
  const receivedHash = p.hash || ''

  const merchantKey = Deno.env.get('PAYU_MERCHANT_KEY') || ''
  const salt = Deno.env.get('PAYU_MERCHANT_SALT') || ''
  let verified = false
  if (merchantKey && salt && receivedHash && txnid && amount) {
    const reverse = [salt, status, '', '', '', '', '', p.udf5 || '', p.udf4 || '', p.udf3 || '', p.udf2 || '', p.udf1 || '', p.email || '', p.firstname || '', p.productinfo || '', amount, txnid, merchantKey].join('|')
    const calculated = await sha512(reverse)
    verified = calculated.toLowerCase() === receivedHash.toLowerCase()
  }

  const admin = createClient(Deno.env.get('SUPABASE_URL')!, secretKey())
  const topupQuery = topupId
    ? admin.from('wallet_topups').select('*').eq('id', topupId).maybeSingle()
    : admin.from('wallet_topups').select('*').eq('provider_transaction_id', txnid).maybeSingle()
  const { data: topup } = await topupQuery
  if (topup && verified) {
    const success = status === 'success' || p.unmappedstatus === 'captured'
    if (success && topup.status === 'pending') {
      await admin.rpc('credit_wallet', { p_user_id: topup.user_id, p_amount: topup.amount, p_type: 'topup', p_reference: txnid, p_metadata: { gateway: 'PayU', mihpayid: p.mihpayid || null, status } })
      await admin.from('wallet_topups').update({ status: 'verified', metadata: { ...topup.metadata, payu: { mihpayid: p.mihpayid || null, status, verified_at: new Date().toISOString() } } }).eq('id', topup.id)
    } else if (!success && topup.status === 'pending') {
      await admin.from('wallet_topups').update({ status: 'failed', metadata: { ...topup.metadata, payu: { status, failed_at: new Date().toISOString() } } }).eq('id', topup.id)
    }
  }

  const target = /^https?:\/\//i.test(returnUrl) ? returnUrl : null
  if (target) {
    const u = new URL(target)
    u.searchParams.set('wallet_topup', topup?.id || topupId || '')
    u.searchParams.set('payment_status', verified ? status : 'verification_failed')
    return Response.redirect(u.toString(), 303)
  }
  return new Response(verified ? 'Payment callback processed.' : 'Payment callback verification failed.', { status: verified ? 200 : 400 })
})
