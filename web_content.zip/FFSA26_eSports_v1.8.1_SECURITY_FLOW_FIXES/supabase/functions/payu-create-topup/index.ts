import { createClient } from 'npm:@supabase/supabase-js@2'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } })

async function sha512(value: string) {
  const bytes = new TextEncoder().encode(value)
  const digest = await crypto.subtle.digest('SHA-512', bytes)
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, '0')).join('')
}

function secretKey() {
  const raw = Deno.env.get('SUPABASE_SECRET_KEYS')
  if (raw) {
    try { return JSON.parse(raw).default } catch { /* fall through */ }
  }
  return Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
}

function publishableKey() {
  const raw = Deno.env.get('SUPABASE_PUBLISHABLE_KEYS')
  if (raw) {
    try { return JSON.parse(raw).default } catch { /* fall through */ }
  }
  return Deno.env.get('SUPABASE_ANON_KEY') || ''
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

  const auth = req.headers.get('Authorization') || ''
  if (!auth.startsWith('Bearer ')) return json({ error: 'Authentication required' }, 401)

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const client = createClient(supabaseUrl, publishableKey(), { global: { headers: { Authorization: auth } } })
  const { data: { user }, error: userError } = await client.auth.getUser()
  if (userError || !user) return json({ error: 'Authentication required' }, 401)

  const body = await req.json().catch(() => ({}))
  const amount = Number(body.amount)
  const returnUrl = String(body.returnUrl || '')
  if (!Number.isFinite(amount) || amount < 10 || amount > 10000) return json({ error: 'Amount must be between ₹10 and ₹10,000' }, 400)
  if (!/^https?:\/\//i.test(returnUrl)) return json({ error: 'A valid app return URL is required' }, 400)

  const admin = createClient(supabaseUrl, secretKey())
  const { data: profile, error: profileError } = await admin.from('profiles').select('in_game_name,phone,email').eq('user_id', user.id).maybeSingle()
  if (profileError) return json({ error: profileError.message }, 500)
  if (!profile?.in_game_name || !profile?.phone || !profile?.email) return json({ error: 'Complete player name, phone and email in Player Details before adding money.' }, 400)

  const topupId = crypto.randomUUID()
  const txnid = `FF26${crypto.randomUUID().replaceAll('-', '').slice(0, 12)}`
  const insert = await admin.from('wallet_topups').insert({
    id: topupId,
    user_id: user.id,
    amount,
    status: 'pending',
    gateway: 'PayU',
    provider: 'PayU',
    provider_transaction_id: txnid,
    idempotency_key: topupId,
    metadata: { return_url: returnUrl },
  }).select().single()
  if (insert.error) return json({ error: insert.error.message }, 500)

  const merchantKey = Deno.env.get('PAYU_MERCHANT_KEY') || ''
  const salt = Deno.env.get('PAYU_MERCHANT_SALT') || ''
  if (!merchantKey || !salt) return json({ error: 'PayU backend credentials are not configured.' }, 503)

  const callbackBase = `${supabaseUrl}/functions/v1/payu-callback`
  const productinfo = 'FFSA26 eSports Wallet Top-up'
  const firstname = String(profile.in_game_name).slice(0, 60)
  const email = String(profile.email).slice(0, 50)
  const phone = String(profile.phone).slice(0, 50)
  const hashString = [merchantKey, txnid, amount.toFixed(2), productinfo, firstname, email, '', '', '', '', '', '', '', '', '', '', salt].join('|')
  const hash = await sha512(hashString)
  const mode = (Deno.env.get('PAYU_MODE') || 'test').toLowerCase()
  const endpoint = mode === 'production' ? 'https://secure.payu.in/_payment' : 'https://test.payu.in/_payment'

  return json({
    topup: { id: topupId, amount, status: 'pending', txnid },
    checkout: {
      endpoint,
      fields: {
        key: merchantKey,
        txnid,
        amount: amount.toFixed(2),
        productinfo,
        firstname,
        email,
        phone,
        surl: `${callbackBase}?return_url=${encodeURIComponent(returnUrl)}`,
        furl: `${callbackBase}?return_url=${encodeURIComponent(returnUrl)}`,
        curl: `${callbackBase}?return_url=${encodeURIComponent(returnUrl)}`,
        hash,
        udf1: topupId,
      },
    },
  })
})
