#!/data/data/com.termux/files/usr/bin/bash
set -e
SRC="$(pwd -P)"
NAME="FFSA26_eSports_v1.8.1_SECURITY_FLOW_FIXES"
HOME_PROJECT="$HOME/$NAME"
case "$SRC" in
  /storage/*|/sdcard/*|$HOME/storage/*)
    echo "FFSA26 eSports — copying project to Termux private storage..."
    rm -rf "$HOME_PROJECT"
    mkdir -p "$HOME_PROJECT"
    cp -a "$SRC"/. "$HOME_PROJECT"/
    cd "$HOME_PROJECT"
    ;;
esac
case "$(pwd -P)" in
  /storage/*|/sdcard/*|$HOME/storage/*)
    echo "ERROR: Project is still in Android shared storage."
    echo "Run setup-termux.sh from the extracted project; it must be copied into Termux home before npm install."
    exit 1
    ;;
esac
echo "FFSA26 eSports — installing dependencies in: $(pwd)"
rm -rf node_modules
npm install
npm run build
echo
echo "Setup complete. Start with:"
echo "cd $HOME_PROJECT && npm run dev"
