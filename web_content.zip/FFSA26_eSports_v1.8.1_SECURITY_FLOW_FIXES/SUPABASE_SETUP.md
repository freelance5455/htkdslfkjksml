# FFSA26 eSports — Supabase setup

1. Create a Supabase project.
2. In **Authentication → Providers/Sign-in**, enable **Anonymous Sign-Ins** because FFSA26 keeps the player flow login-free. Supabase anonymous users still use the authenticated database role and can be protected with RLS.
3. Open **SQL Editor** and run `supabase/schema.sql`.
4. In the project settings, copy the project URL and the browser-safe **publishable key**. Do not put a Supabase secret/service key in the Vite app.
5. From the project root:

```bash
cp .env.example .env
nano .env
```

Set:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

6. Start normally:

```bash
npm install
npm run build
npm run dev
```

## What is cloud-backed

- Anonymous player identity/session
- Player profile
- Teams owned by the player
- Published tournaments
- Registrations
- Wallet balance
- Wallet transaction ledger
- Pending PayU top-ups
- Withdrawals
- Payment screenshot storage bucket

## Wallet security

The browser never receives a service/secret key. Tournament entry deductions and withdrawals use locked Postgres functions. Wallet credits for verified PayU payments, organizer winnings, refunds and reversals must be performed by a trusted backend/Edge Function after validating the external event and idempotency.

## Important

The app intentionally falls back to local storage when Supabase is not configured. It does not create fake cloud balances, tournaments, winnings or payments. Populate real tournaments from the admin/backend side before using the cloud tournament-registration flow.

## v1.8.1 security patch

After the original schema is installed, run `supabase/patch_v1.8.1.sql` in SQL Editor. This patch adds team join codes/rosters, safe registration creation, idempotent tournament entry debits, cancellation/refund protection, notifications, support tickets, payment-proof storage, and wallet top-up metadata.

### PayU wallet top-ups

Real wallet top-ups use a Supabase Edge Function so the PayU merchant key and salt never reach the browser. PayU's Hosted Checkout requires a server-generated hash and server-side verification; the app must not credit the wallet merely because the browser returned from PayU. See the official PayU hosted-checkout and hash guidance.

Create/deploy these functions:

- `supabase/functions/payu-create-topup`
- `supabase/functions/payu-callback` (also usable as the PayU payment webhook endpoint)

Set the server-only secrets in Supabase **Edge Functions → Secrets** (or with the Supabase CLI):

```text
PAYU_MERCHANT_KEY
PAYU_MERCHANT_SALT
PAYU_MODE=test
```

For local Edge Function development, copy `supabase/functions/.env.example` to `supabase/functions/.env` and fill in the values. Never put the PayU salt or Supabase secret key into `.env` variables beginning with `VITE_`.

PayU test Hosted Checkout endpoint:

```text
https://test.payu.in/_payment
```

Production:

```text
https://secure.payu.in/_payment
```

Configure PayU payment webhooks to a publicly accessible HTTPS webhook endpoint when moving beyond local testing. The webhook/callback must validate the PayU response hash and handle duplicate events idempotently before crediting the wallet.
