# HTML → APK গাইড (Income & Expense)

অ্যাপ ID: `com.nextgenprime.incomeexpense` · সব সাইনিং কী ও অ্যাকাউন্ট আপনার নিজের থাকবে।

## কোন পথটি নেবেন?

| | **পথ ১: TWA (প্রস্তাবিত)** | **পথ ২: Capacitor** |
|---|---|---|
| কীভাবে চলে | Chrome ইঞ্জিনে, আপনার হোস্ট করা সাইট | ফোনের ভেতরে ফাইল রেখে WebView-তে |
| ইন্টারনেট দরকার | শুধু প্রথম ইনস্টল/আপডেটে | কখনো না (ফাইল APK-তেই আছে) |
| Google সাইন-ইন | **কাজ করে** | **কাজ করে না** (Google WebView-তে OAuth আটকায়); শুধু ইমেইল/পাসওয়ার্ড |
| আপডেট | সাইট ডিপ্লয় করলেই | নতুন APK বানাতে হবে |
| Play Store | হ্যাঁ (AAB) | হ্যাঁ (AAB) |

ক্লাউড সিঙ্কে Google লগইন চাইলে **পথ ১** নিন।

---
## পথ ১: TWA (Bubblewrap বা PWABuilder)

**ধাপ ১ — সাইট হোস্ট করুন (Firebase Hosting, বিনামূল্যে):**
`firebase deploy --only hosting` (README.md-তে Firebase সেটআপ দেখুন)। ধরুন ঠিকানা `https://my-app.web.app`।

**ধাপ ২ (সবচেয়ে সহজ) — PWABuilder:** https://www.pwabuilder.com এ আপনার সাইটের URL দিন → **Package for stores → Android** → Package ID `com.nextgenprime.incomeexpense` → ডাউনলোড। ZIP-এ APK/AAB ও signing key থাকবে। **key-টি নিরাপদ জায়গায় রাখুন, হারালে আপডেট দেওয়া যাবে না।**

**ধাপ ২ (বিকল্প) — Bubblewrap:**
```
npm i -g @bubblewrap/cli
bubblewrap init --manifest=https://my-app.web.app/manifest.webmanifest
#   Package name: com.nextgenprime.incomeexpense   (আগে থেকে ভরা twa-manifest.json রেফারেন্সের জন্য দেওয়া আছে)
bubblewrap build        # app-release-signed.apk + app-release-bundle.aab তৈরি হয়
```

**ধাপ ৩ — ঠিকানা যাচাই (Digital Asset Links), না করলে অ্যাপে ব্রাউজারের ঠিকানা-বার দেখা যাবে:**
1. কীটির SHA-256 নিন: `keytool -list -v -keystore android.keystore -alias incomeexpense` (Play App Signing ব্যবহার করলে Play Console → App integrity থেকে নিন)।
2. `apk/assetlinks.template.json` কপি করে `.well-known/assetlinks.json` নামে প্রজেক্টের রুটে রাখুন, fingerprint বসান।
3. আবার `firebase deploy --only hosting`। (firebase.json এ `.well-known` ডিপ্লয় হওয়ার সেটিং করা আছে।)

---
## পথ ২: Capacitor (অফলাইন ফাইল সহ APK)

দরকার: Node 18+, JDK 17, Android Studio (Android SDK)।
```
cd apk/capacitor
npm install
npx cap add android        # একবারই
npm run assets             # resources/icon.png ও splash.png থেকে আইকন/স্প্ল্যাশ বানায়
npm run debug-apk          # → android/app/build/outputs/apk/debug/app-debug.apk
```
Play Store-এর জন্য: `npm run release-aab`, তার আগে Android Studio তে **Build → Generate Signed Bundle** দিয়ে নিজের keystore বানান (বা gradle-এ signingConfig দিন)।

> Capacitor APK-তে ফাইল `https://localhost` থেকে চলে, তাই এনক্রিপশন, IndexedDB ও সার্ভিস ওয়ার্কার ঠিকমতো চলে। Firebase Console → Authentication → Authorized domains এ `localhost` থাকে।

---
## Play Store-এর জন্য মনে রাখুন
- Play Console আপনার নিজের অ্যাকাউন্টে খুলুন (এককালীন ফি)। নতুন ব্যক্তিগত অ্যাকাউন্টে প্রোডাকশনের আগে সাধারণত ক্লোজড টেস্ট (টেস্টার সহ) লাগে। বর্তমান নিয়ম Play Console-এ যাচাই করুন।
- **Privacy Policy** URL ও **Data safety** ফর্ম লাগবে।
- লোগোর এক্সেল-স্টাইল আইকন Microsoft-এর ট্রেডমার্কের মতো দেখায়, তাই রিভিউতে আপত্তি আসতে পারে। ঝুঁকি আপনার সিদ্ধান্তের উপর।

## যা আমি এখানে চালিয়ে দেখতে পারিনি
এই পরিবেশে ইন্টারনেট ও Android SDK নেই, তাই **APK বানানো ও ফোনে ইনস্টল** আমি করিনি। এই ফাইলগুলো (`twa-manifest.json`, Capacitor কনফিগ, স্ক্রিপ্ট) লেখা হয়েছে। শুধু `prepare-www.sh` চালিয়ে দেখেছি যে কপি করা ফোল্ডার ব্রাউজারে ঠিকমতো চালু হয়।
