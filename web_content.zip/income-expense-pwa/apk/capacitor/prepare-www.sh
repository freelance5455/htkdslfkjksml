#!/bin/sh
# Copies the web app (one folder up from /apk) into ./www for Capacitor. Tests, docs and Firebase files are left out.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
rm -rf www && mkdir -p www
cp "$ROOT/index.html" "$ROOT/manifest.webmanifest" "$ROOT/sw.js" www/
cp -r "$ROOT/css" "$ROOT/js" www/
mkdir -p www/icons && cp "$ROOT"/icons/logo-64.png "$ROOT"/icons/logo-192.png "$ROOT"/icons/logo-512.png "$ROOT"/icons/maskable-512.png www/icons/
echo "www ready: $(find www -type f | wc -l) files"
