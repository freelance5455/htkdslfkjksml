// Service worker: makes the app open and work with no connection.
// App files are cached on install. Firebase SDK files (gstatic) are cached the first time they load.
// Firestore/Auth/Storage API traffic is never cached.
const VERSION = 'ie-v1';
const SHELL = ['./', 'index.html', 'manifest.webmanifest', 'css/app.css',
  'js/app.js', 'js/calc.js', 'js/cloud.js', 'js/config.js', 'js/crypto.js', 'js/ctx.js', 'js/db.js', 'js/i18n.js', 'js/img.js', 'js/store.js', 'js/strings.js',
  'js/sync-core.js', 'js/sync.js', 'js/ui.js', 'js/util.js', 'js/views-home.js', 'js/views-menu.js',
  'icons/logo-64.png', 'icons/logo-192.png', 'icons/logo-512.png', 'icons/maskable-512.png'];

self.addEventListener('install', e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim())); });

self.addEventListener('fetch', e => {
  const req = e.request; if (req.method !== 'GET') return;
  const url = new URL(req.url);
  const sameOrigin = url.origin === location.origin, sdk = url.hostname === 'www.gstatic.com' && url.pathname.startsWith('/firebasejs/');
  if (!sameOrigin && !sdk) return;                                  // let API calls go straight to the network
  if (req.mode === 'navigate') { e.respondWith(fetch(req).then(r => { const cp = r.clone(); caches.open(VERSION).then(c => c.put('index.html', cp)); return r; }).catch(() => caches.match('index.html'))); return; }
  // stale-while-revalidate: instant from cache, refreshed in the background
  e.respondWith(caches.open(VERSION).then(async c => {
    const hit = await c.match(req, { ignoreSearch: true });
    const net = fetch(req).then(r => { if (r.ok) c.put(req, r.clone()); return r; }).catch(() => hit);
    return hit || net;
  }));
});
