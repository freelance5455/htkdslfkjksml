// Shared application context. app.js fills it in; every view module imports it.
import { money, todayStr, monthKey, esc } from './util.js';
import { accountBalance } from './calc.js';
import { t as tr } from './i18n.js';

export const C = {
  store: null, sync: null, cloud: null,
  privacy: false,
  actions: {},
  S: {
    route: 'home', period: 'month', month: monthKey(todayStr()), accountId: 'all', kind: '', categoryId: '', q: '',
    tasksTab: 'active', duesQ: '', duesFilter: 'all', budgetMonth: monthKey(todayStr()), notesView: 'grid', notesQ: '', syncInfo: { status: 'idle' },
  },
  render: () => {},
  go: () => {},
};
export const t = tr;
export const act = (name, fn) => { C.actions[name] = fn; };

export const DEFAULT_SETTINGS = { lang: 'bn', currency: 'BDT', theme: 'taka', mode: 'auto', company: {}, autoLock: 60 };
export const settings = () => ({ ...DEFAULT_SETTINGS, ...(C.store.get('settings')?.payload || {}) });
export const lang = () => settings().lang;
export const defCur = () => settings().currency;

export const accounts = ({ archived = false } = {}) =>
  C.store.list('account').filter(a => archived || !a.payload.archived).sort((a, b) => (a.payload.order ?? 0) - (b.payload.order ?? 0) || a.updatedAt - b.updatedAt);
export const account = id => C.store.get(id);
export const categories = kind => C.store.list('category').filter(c => !c.payload.hidden && (!kind || c.payload.kind === kind)).sort((a, b) => a.updatedAt - b.updatedAt);
export const category = id => C.store.get(id);
export const catName = id => { const c = category(id); return c ? c.payload.name : t('uncategorized'); };
export const curOf = accId => account(accId)?.payload.currency || defCur();

/** Format money honouring language, currency and privacy mode. */
export const fmt = (p, cur, o = {}) => money(p, { lang: lang(), currency: cur || defCur(), privacy: C.privacy && !o.show, ...o });

export function balanceOf(acc) {
  const s = C.store;
  return accountBalance(acc, { txns: s.list('txn'), transfers: s.list('transfer'), duePayments: s.list('duePayment'), dues: s.list('due') });
}

/** One-line human description of any record (for trash, conflicts, history). */
export function describe(rec, payload = rec.payload, deleted = rec.deleted) {
  const p = payload, L = lang(); let s;
  switch (rec.type) {
    case 'txn': s = `${t(p.kind)} ${fmt(p.amount, curOf(p.accountId), { show: true })} · ${catName(p.categoryId)} · ${p.date}${p.note ? ' · ' + p.note : ''}`; break;
    case 'transfer': s = `${t('transfer')} ${fmt(p.amount, curOf(p.fromId), { show: true })} · ${account(p.fromId)?.payload.name || '?'} → ${account(p.toId)?.payload.name || '?'} · ${p.date}`; break;
    case 'due': s = `${t(p.kind)} · ${p.person} · ${fmt(p.total, defCur(), { show: true })}`; break;
    case 'duePayment': s = `${t('payment')} ${fmt(p.amount, defCur(), { show: true })} · ${p.date}`; break;
    case 'task': s = p.title; break;
    case 'note': s = p.title || (p.body || '').slice(0, 40); break;
    case 'account': s = `${t('account')} · ${p.name} (${p.currency})`; break;
    case 'category': s = `${t('category')} · ${p.name}`; break;
    case 'budget': s = `${t('budget')} · ${p.month} · ${p.categoryId ? catName(p.categoryId) : t('overall')} · ${fmt(p.amount, defCur(), { show: true })}`; break;
    case 'saving': s = `${t('savings')} · ${p.name} · ${fmt(p.target, defCur(), { show: true })}`; break;
    case 'savingEntry': s = `${t(p.kind)} ${fmt(p.amount, defCur(), { show: true })} · ${p.date}`; break;
    case 'recurringRule': s = `${t('recurring')} · ${t(p.kind)} ${fmt(p.amount, curOf(p.accountId), { show: true })} · ${t(p.freq)}`; break;
    case 'attachment': s = t('receipt'); break;
    default: s = rec.type;
  }
  return (deleted ? '🗑 ' : '') + s;
}

export const el = sel => document.querySelector(sel);
export { esc };
