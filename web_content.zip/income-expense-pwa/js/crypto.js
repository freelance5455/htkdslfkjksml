// Web Crypto helpers. AES-256-GCM for data, PBKDF2-SHA256 for PIN/password keys.
const subtle = globalThis.crypto.subtle;
const enc = new TextEncoder(), dec = new TextDecoder();

export const randomBytes = n => crypto.getRandomValues(new Uint8Array(n));
export const b64 = buf => { let s = ''; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };
export const unb64 = str => Uint8Array.from(atob(str), c => c.charCodeAt(0));

export const PBKDF2_ITER = 310000;

export async function deriveKey(secret, salt, iter = PBKDF2_ITER) {
  const base = await subtle.importKey('raw', enc.encode(secret), 'PBKDF2', false, ['deriveKey']);
  return subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, base,
    { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
export const importRawKey = (raw, extractable = false) =>
  subtle.importKey('raw', raw, 'AES-GCM', extractable, ['encrypt', 'decrypt']);
export const newDeviceKey = () => subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);

export async function encryptBytes(key, bytes) {
  const iv = randomBytes(12);
  const ct = await subtle.encrypt({ name: 'AES-GCM', iv }, key, bytes);
  return { iv, ct };
}
export async function decryptBytes(key, { iv, ct }) {
  return new Uint8Array(await subtle.decrypt({ name: 'AES-GCM', iv }, key, ct));
}
export const encryptJSON = (key, obj) => encryptBytes(key, enc.encode(JSON.stringify(obj)));
export async function decryptJSON(key, box) { return JSON.parse(dec.decode(await decryptBytes(key, box))); }

/** Password-protected backup text (self-contained JSON string). */
export async function passwordEncrypt(text, password) {
  const salt = randomBytes(16); const key = await deriveKey(password, salt);
  const { iv, ct } = await encryptBytes(key, enc.encode(text));
  return JSON.stringify({ enc: 'aes-gcm-pbkdf2', iter: PBKDF2_ITER, salt: b64(salt), iv: b64(iv), ct: b64(ct) });
}
export async function passwordDecrypt(json, password) {
  const o = typeof json === 'string' ? JSON.parse(json) : json;
  const key = await deriveKey(password, unb64(o.salt), o.iter);
  return dec.decode(await decryptBytes(key, { iv: unb64(o.iv), ct: unb64(o.ct) }));
}

export async function sha256hex(text) {
  const h = new Uint8Array(await subtle.digest('SHA-256', enc.encode(text)));
  return [...h].map(b => b.toString(16).padStart(2, '0')).join('');
}
