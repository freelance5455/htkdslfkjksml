// Storage backends. The app uses IndexedDB; tests use the in-memory backend with the same interface.
export const STORES = { records: 'id', versions: 'key', blobs: 'id', conflicts: 'id', meta: 'key' };

export function memoryBackend() {
  const data = {}; for (const s in STORES) data[s] = new Map();
  const kp = s => STORES[s];
  return {
    async open() {},
    async get(s, k) { const v = data[s].get(k); return v === undefined ? undefined : structuredClone(v); },
    async put(s, v) { data[s].set(v[kp(s)], structuredClone(v)); },
    async getAll(s) { return [...data[s].values()].map(v => structuredClone(v)); },
    async delete(s, k) { data[s].delete(k); },
    async clear(s) { data[s].clear(); },
  };
}

export function idbBackend(name = 'income-expense') {
  let db;
  const tx = (s, mode, fn) => new Promise((res, rej) => {
    const t = db.transaction(s, mode); const st = t.objectStore(s);
    let out; const r = fn(st);
    if (r) r.onsuccess = () => { out = r.result; };
    t.oncomplete = () => res(out);
    t.onerror = () => rej(t.error); t.onabort = () => rej(t.error || new Error('IndexedDB transaction aborted'));
  });
  return {
    open() {
      return new Promise((res, rej) => {
        const req = indexedDB.open(name, 1);
        req.onupgradeneeded = () => { for (const s in STORES) if (!req.result.objectStoreNames.contains(s)) req.result.createObjectStore(s, { keyPath: STORES[s] }); };
        req.onsuccess = () => { db = req.result; res(); };
        req.onerror = () => rej(req.error);
      });
    },
    get: (s, k) => tx(s, 'readonly', st => st.get(k)),
    put: (s, v) => tx(s, 'readwrite', st => st.put(v)),
    getAll: s => tx(s, 'readonly', st => st.getAll()),
    delete: (s, k) => tx(s, 'readwrite', st => st.delete(k)),
    clear: s => tx(s, 'readwrite', st => st.clear()),
  };
}
