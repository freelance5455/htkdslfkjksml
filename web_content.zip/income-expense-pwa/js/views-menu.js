// Menu tab and its sub-pages: security, backup/restore, trash, cloud sync, conflicts, language/currency.
import { C, t, act, lang, settings, describe, fmt } from './ctx.js';
import { html, icon, raw, formSheet, openSheet, toast, confirmBox, H } from './ui.js';
import { CURRENCIES, fmtDate } from './util.js';
import { passwordEncrypt, passwordDecrypt } from './crypto.js';
import { setLang } from './i18n.js';

export const LS = { get: (k, d) => { try { return localStorage.getItem(k) ?? d; } catch { return d; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } } };

export async function saveSettings(patch) {
  const next = { ...settings(), ...patch };
  await C.store.save('setting', next, 'settings');
  LS.set('ie_ui', JSON.stringify({ lang: next.lang, theme: next.theme, mode: next.mode }));
  if (patch.lang) setLang(next.lang);
}

const row = (ic, label, sub, act_, extra = '') => html`<button class="mrow" data-act="${act_}">${icon(ic)}<span class="grow"><b>${label}</b>${sub ? html`<small class="muted">${sub}</small>` : ''}</span>${extra}${icon('chevR', 'sm muted')}</button>`;

export function syncSummary() {
  const s = C.S.syncInfo, n = C.store.pending().length;
  if (!C.cloud?.available) return t('sync_unconfigured');
  if (!C.cloud.uid()) return t('sync_signedout');
  const m = { synced: 'sync_synced', syncing: 'sync_syncing', offline: 'sync_offline', error: 'sync_error', locked: 'sync_locked' }[s.status] || 'sync_idle';
  return t(m) + (n && s.status !== 'synced' ? ' · ' + t('pending_n', { n }) : '');
}

export function menuView() {
  const S = settings(), nConf = C.store.conflictList().length;
  return html`<div class="menu">
    ${C.installEvt ? row('download', t('install_app'), '', 'install') : ''}
    ${row('cloud', t('cloud_sync'), syncSummary(), 'go-sync', C.store.pending().length ? html`<span class="badge">${C.store.pending().length}</span>` : '')}
    ${nConf ? row('alert', t('conflicts'), t('notice_conflict'), 'go-conflicts', html`<span class="badge warn">${nConf}</span>`) : ''}
    ${row('shield', t('security'), C.store.hasPin() ? t('pin_lock') + ' ✓' : t('set_pin'), 'go-security')}
    ${row('download', t('backup_restore'), '', 'go-backup')}
    ${row('trash', t('trash'), '', 'go-trash')}
    <section class="card form-card">
      <div class="fld"><span>${t('language')}</span><div class="seg"><label><input type="radio" name="lang" value="bn" ${S.lang === 'bn' ? 'checked' : ''} data-act="set-lang"><span>বাংলা</span></label><label><input type="radio" name="lang" value="en" ${S.lang === 'en' ? 'checked' : ''} data-act="set-lang"><span>English</span></label></div></div>
      <label class="fld"><span>${t('currency')}</span><select data-act="set-cur">${Object.keys(CURRENCIES).map(c => html`<option value="${c}" ${S.currency === c ? 'selected' : ''}>${c} ${CURRENCIES[c].trim()}</option>`)}</select></label>
      <label class="chk"><input type="checkbox" data-act="set-privacy" ${C.privacy ? 'checked' : ''}><span><b>${t('privacy_mode')}</b><small class="muted">${t('privacy_hint')}</small></span></label>
    </section></div>`;
}

// ---- security ----------------------------------------------------------------------------------------------------------------
const validPin = p => /^\d{4,8}$/.test(p);
export function securityView() {
  const has = C.store.hasPin(), al = LS.get('ie_autolock', '60');
  return html`<div class="menu">
    <section class="card form-card"><div class="row"><span class="grow"><b>${t('pin_lock')}</b><small class="muted">${has ? '✓' : ''}</small></span></div>
      <p class="hint">${t('pin_note')}</p>
      <div class="row gap wrap">${has ? html`<button class="btn" data-act="pin-change">${t('change_pin')}</button><button class="btn danger" data-act="pin-remove">${t('remove_pin')}</button>` : html`<button class="btn primary" data-act="pin-set">${t('set_pin')}</button>`}</div></section>
    ${has ? html`<label class="fld card form-card"><span>${t('auto_lock')}</span><select data-act="set-autolock">${[['0', 'immediately'], ['60', 'min1'], ['300', 'min5'], ['-1', 'never']].map(([v, k]) => html`<option value="${v}" ${al === v ? 'selected' : ''}>${t(k)}</option>`)}</select></label>` : ''}</div>`;
}
function pinForm(title, withOld, onOk) {
  formSheet({ title, fields: [
    ...(withOld ? [{ n: 'old', type: 'password', label: t('current_pin'), req: true, max: 8 }] : []),
    ...(onOk.needNew === false ? [] : [{ n: 'p1', type: 'password', label: t('new_pin'), req: true, max: 8 }, { n: 'p2', type: 'password', label: t('confirm_pin'), req: true, max: 8 }]),
  ], onMount: ({ form }) => form.querySelectorAll('input[type=password]').forEach(i => { i.inputMode = 'numeric'; i.autocomplete = 'off'; }),
  onSubmit: v => onOk(v) });
}

export function registerMenu() {
  act('set-lang', async (d, el) => { await saveSettings({ lang: el.value }); C.render(); });
  act('set-cur', async (d, el) => { await saveSettings({ currency: el.value }); C.render(); });
  act('set-privacy', (d, el) => { C.privacy = el.checked; LS.set('ie_privacy', el.checked ? '1' : '0'); C.render(); });
  act('set-autolock', (d, el) => LS.set('ie_autolock', el.value));
  for (const r of ['sync', 'conflicts', 'security', 'backup', 'trash']) act('go-' + r, () => C.go(r));

  act('pin-set', () => pinForm(t('set_pin'), false, async v => {
    if (!validPin(v.p1)) throw new Error(t('pin_rule')); if (v.p1 !== v.p2) throw new Error(t('pin_mismatch'));
    await C.store.setPin(v.p1); toast(t('pin_set_done')); C.render();
  }));
  act('pin-change', () => pinForm(t('change_pin'), true, async v => {
    if (!validPin(v.p1)) throw new Error(t('pin_rule')); if (v.p1 !== v.p2) throw new Error(t('pin_mismatch'));
    if (!(await C.store.changePin(v.old, v.p1))) throw new Error(t('wrong_pin')); toast(t('pin_set_done'));
  }));
  const rm = async v => { if (!(await C.store.removePin(v.old))) throw new Error(t('wrong_pin')); C.render(); };
  rm.needNew = false;
  act('pin-remove', () => pinForm(t('remove_pin'), true, rm));

  act('backup-export', () => formSheet({ title: t('export_backup'), submit: t('export_backup'), fields: [
    { n: 'pw', type: 'password', label: t('backup_password') }, { n: 'blobs', type: 'check', label: t('include_receipts'), v: true }],
    onSubmit: async v => {
      const data = await C.store.exportAll({ withBlobs: v.blobs });
      let text = JSON.stringify(data); if (v.pw) text = await passwordEncrypt(text, v.pw);
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
      a.download = `income-expense-backup-${new Date().toISOString().slice(0, 10)}${v.pw ? '-locked' : ''}.json`; document.body.append(a); a.click(); a.remove();
      toast(t('backup_done'));
    } }));
  act('backup-import', () => {
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json,application/json';
    inp.onchange = async () => {
      const f = inp.files[0]; if (!f) return; const text = await f.text();
      const finish = async txt => {
        try { const r = await C.store.importAll(JSON.parse(txt)); toast(t('import_done', { a: r.added, s: r.same, c: r.conflicted }), { ms: 7000 }); C.render(); }
        catch { toast(t('bad_backup')); }
      };
      let o; try { o = JSON.parse(text); } catch { return toast(t('bad_backup')); }
      if (o.enc) formSheet({ title: t('backup_pw_ask'), fields: [{ n: 'pw', type: 'password', label: t('password'), req: true }],
        onSubmit: async v => { try { await finish(await passwordDecrypt(o, v.pw)); } catch { throw new Error(t('bad_backup')); } } });
      else finish(text);
    };
    inp.click();
  });
  act('trash-restore', async d => { await C.store.restore(d.id); toast(t('restored')); });
  act('conf-keep', async d => { await C.store.resolveConflict(d.id, +d.i, false); });
  act('conf-use', async d => { await C.store.resolveConflict(d.id, +d.i, true); });

  act('sign-in', () => {
    if (!navigator.onLine) return toast(t('need_online'));
    const s = openSheet({ title: t('sign_in'), body: html`<form class="form" id="authform">
      <button type="button" class="btn grow" data-g>${t('google_sign_in')}</button>
      <label class="fld"><span>${t('email')}</span><input name="email" type="email" autocomplete="email" required></label>
      <label class="fld"><span>${t('password')}</span><input name="pw" type="password" autocomplete="current-password" minlength="6" required></label>
      <p class="err" role="alert"></p>
      <div class="row gap wrap"><button class="btn primary grow" data-m="in">${t('sign_in')}</button><button type="button" class="btn grow" data-m="up">${t('sign_up')}</button></div>
      <button type="button" class="link" data-m="reset">${t('reset_pw')}</button></form>`,
    onMount: s => {
      const f = s.body.querySelector('form'), err = f.querySelector('.err');
      const run = async fn => { err.textContent = ''; try { await fn(); } catch (e) { err.textContent = (e.code || e.message || String(e)).replace('auth/', '').replace(/-/g, ' '); } };
      f.querySelector('[data-g]').onclick = () => run(async () => { await C.cloud.signInGoogle(); s.close(); });
      f.addEventListener('submit', e => { e.preventDefault(); run(async () => { await C.cloud.signInEmail(f.email.value.trim(), f.pw.value); s.close(); }); });
      f.querySelector('[data-m=up]').onclick = () => run(async () => { if (!f.reportValidity()) return; await C.cloud.signUp(f.email.value.trim(), f.pw.value); s.close(); });
      f.querySelector('[data-m=reset]').onclick = () => run(async () => { if (!f.email.value) return; await C.cloud.reset(f.email.value.trim()); toast(t('reset_sent')); });
    } });
  });
  act('install', async () => { const e = C.installEvt; if (!e) return; e.prompt(); await e.userChoice; C.installEvt = null; C.render(); });
  act('sign-out', async () => { await C.cloud.signOut(); C.render(); });
  act('set-storage', async (d, el) => { C.S.storageOn = el.checked; await C.store.setMeta('storageEnabled', el.checked); C.cloud.setStorageEnabled(el.checked); C.sync?.run(); });
}

// ---- sub pages --------------------------------------------------------------------------------------------------------------
export function backupView() {
  return html`<div class="menu"><section class="card form-card"><p class="hint">${t('backup_note')}</p>
    <div class="row gap wrap"><button class="btn primary grow" data-act="backup-export">${icon('download')}<span>${t('export_backup')}</span></button><button class="btn grow" data-act="backup-import">${icon('upload')}<span>${t('import_backup')}</span></button></div></section></div>`;
}
export function trashView() {
  const rows = C.store.all().filter(r => r.deleted && r.type !== 'setting' && r.type !== 'attachment').sort((a, b) => b.updatedAt - a.updatedAt);
  return html`<p class="hint pad">${t('trash_note')}</p>${rows.length ? html`<ul class="list">${rows.map(r => html`<li class="item"><span class="grow">${describe(r).replace('🗑 ', '')}<small class="muted">${new Date(r.updatedAt).toLocaleString(lang() === 'bn' ? 'bn-BD' : 'en-GB')}</small></span><button class="btn small" data-act="trash-restore" data-id="${r.id}">${t('restore')}</button></li>`)}</ul>` : html`<div class="empty">${icon('trash')}<p>${t('trash_empty')}</p></div>`}`;
}
export function syncView() {
  const info = C.S.syncInfo, signed = C.cloud?.uid?.(), n = C.store.pending().length;
  return html`<div class="menu"><section class="card form-card">
    <p class="syncline ${info.status}"><b>${syncSummary()}</b></p>
    ${info.error ? html`<p class="err">${info.error}</p>` : ''}
    ${info.last ? html`<small class="muted">${t('last_sync')}: ${new Date(info.last).toLocaleString(lang() === 'bn' ? 'bn-BD' : 'en-GB')}</small>` : ''}
    ${C.store.loadErrors ? html`<p class="err">${t('load_errors', { n: C.store.loadErrors })}</p>` : ''}
    ${C.cloud?.available ? (signed ? html`<p>${t('signed_in_as', { e: C.cloud.email() || signed })}</p><button class="btn danger" data-act="sign-out">${t('sign_out')}</button>` : html`<button class="btn primary" data-act="sign-in">${t('sign_in')}</button>`) : ''}
  </section>
  ${signed ? html`<section class="card form-card"><label class="chk"><input type="checkbox" data-act="set-storage" ${C.S.storageOn ? 'checked' : ''}><span><b>${t('storage_receipts')}</b><small class="muted">${t('storage_warn')}</small></span></label></section>` : ''}</div>`;
}
export function conflictsView() {
  const list = C.store.conflictList();
  if (!list.length) return html`<div class="empty">${icon('check')}<p>${t('conflict_none')}</p></div>`;
  return html`<p class="hint pad">${t('conflict_intro')}</p>${list.map(c => c.others.map((o, i) => html`<section class="card conflict">
    <div><small class="muted">${t('current_version')}</small><p>${describe(c.current)}</p></div>
    <div><small class="muted">${t('other_version')} · ${o.source === 'backup' ? t('import_backup') : t('cloud_sync')}</small><p>${describe(c.current, o.payload, o.deleted)}</p></div>
    <div class="row gap"><button class="btn grow" data-act="conf-keep" data-id="${c.id}" data-i="${i}">${t('keep_current')}</button><button class="btn primary grow" data-act="conf-use" data-id="${c.id}" data-i="${i}">${t('use_other')}</button></div></section>`))}`;
}
