// Automatic sync engine: local store <-> a "remote" adapter (Firebase in the app, a fake in tests).
// The UI never waits for this. Offline, nothing here runs; edits simply stay pending and are sent later.
export const isNetworkError = e => {
  const c = e?.code || '', m = String(e?.message || e);
  return /unavailable|deadline|network|offline|timeout/i.test(c + ' ' + m) || /Failed to fetch|Load failed|NetworkError/i.test(m);
};

export function createSync({ store, remote, online = () => navigator.onLine, onStatus = () => {}, notice = () => {} }) {
  let running = false, again = false, off = null, timer = null;
  const st = { status: 'idle', error: null, last: null };
  const set = (status, error = null) => { st.status = status; st.error = error; if (status === 'synced') st.last = Date.now(); onStatus({ ...st, pending: store.pending().length }); };

  async function pushAll() {
    const recs = store.pending().sort((a, b) => a.updatedAt - b.updatedAt);
    for (const r of recs) {
      const lv = r.lv;
      const res = await remote.push({ id: r.id, type: r.type, rev: r.rev, deleted: r.deleted, payload: r.payload, updatedAt: r.updatedAt, deviceId: r.deviceId });
      if (res.conflict) { const m = await store.applyRemote(res.server); if (m.note) notice(m.note, r); }
      else await store.markSynced(r.id, res.rev, lv);
    }
  }
  async function pullAll() {
    let cursor = (await store.getMeta('cursor')) || 0;
    for (let i = 0; i < 50; i++) {
      const { records, cursor: next, more } = await remote.pull(cursor);
      for (const rec of records) { const m = await store.applyRemote(rec); if (m.note) notice(m.note, rec); }
      if (next > cursor) { cursor = next; await store.setMeta('cursor', cursor); }
      if (!more) break;
    }
    return cursor;
  }
  async function uploadFiles() {
    if (!remote.canUploadFiles?.()) return;
    for (const id of await store.blobsToUpload()) {
      const b = await store.getBlob(id); if (!b) continue;
      const path = await remote.upload(id, b.bytes, b.mime);
      await store.markBlobUploaded(id);
      const att = store.get(id);
      if (att && !att.payload.uploaded) await store.patch(id, p => ({ ...p, uploaded: true, path }));
    }
  }

  async function run() {
    if (running) { again = true; return; }
    running = true;
    try {
      for (let i = 0; i < 4; i++) {
        if (!store.unlocked) { set('locked'); break; }
        if (!remote.uid()) { set('signedout'); break; }
        if (!online()) { set('offline'); break; }
        set('syncing');
        await pushAll();
        const cursor = await pullAll();
        await uploadFiles();
        if (!off && remote.listen) off = remote.listen(cursor, async recs => { for (const r of recs) await store.applyRemote(r); if (store.pending().length) run(); });
        if (!store.pending().length) { set('synced'); break; }
        if (i === 3) set('synced');
      }
    } catch (e) {
      set(isNetworkError(e) || !online() ? 'offline' : 'error', String(e?.message || e));
    } finally { running = false; if (again) { again = false; setTimeout(run, 300); } }
  }

  return {
    run, state: st,
    start() {
      addEventListener?.('online', run);
      document?.addEventListener?.('visibilitychange', () => { if (document.visibilityState === 'visible') run(); });
      store.on(e => { if (e.local && e.kind === 'change') { clearTimeout(timer); timer = setTimeout(run, 700); } });
      timer = setTimeout(run, 100);
      setInterval(run, 60000);
    },
    reset() { if (off) { off(); off = null; } },
  };
}
