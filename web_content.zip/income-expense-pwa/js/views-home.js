// Home tab: income/expense records, summaries, categories, receipts.
import { C, t, act, accounts, account, categories, category, catName, fmt, lang, defCur, curOf, balanceOf, settings } from './ctx.js';
import { html, icon, raw, formSheet, openSheet, toast, confirmBox, H } from './ui.js';
import { summarize, inPeriod } from './calc.js';
import { todayStr, nowTime, fmtDate, fmtMonth, fmtTime, addMonths, uuid, num } from './util.js';
import { compress } from './img.js';

export const PALETTE = ['#1f8a4c', '#d3342a', '#e0a100', '#2a6fdb', '#8a4fd0', '#0f9aa8', '#e0629a', '#7a5a3a', '#4c5b66', '#f07b2a'];

export function seedDefaults(l) {
  const S = C.store, tt = k => ({ en: ENG, bn: BNG }[l][k]);
  const ENG = { personal: 'Personal', salary: 'Salary', business: 'Business', gift: 'Gift', otherI: 'Other income', food: 'Food', transport: 'Transport', bills: 'Bills', shopping: 'Shopping', health: 'Health', education: 'Education', otherE: 'Other' };
  const BNG = { personal: 'ব্যক্তিগত', salary: 'বেতন', business: 'ব্যবসা', gift: 'উপহার', otherI: 'অন্যান্য আয়', food: 'খাবার', transport: 'যাতায়াত', bills: 'বিল', shopping: 'কেনাকাটা', health: 'চিকিৎসা', education: 'শিক্ষা', otherE: 'অন্যান্য' };
  const jobs = [];
  if (!S.get('acc_personal')) jobs.push(S.save('account', { name: tt('personal'), currency: settings().currency, openingBalance: 0, seed: true }, 'acc_personal'));
  const cats = [['salary', 'income'], ['business', 'income'], ['gift', 'income'], ['otherI', 'income'], ['food', 'expense'], ['transport', 'expense'], ['bills', 'expense'], ['shopping', 'expense'], ['health', 'expense'], ['education', 'expense'], ['otherE', 'expense']];
  cats.forEach(([k, kind], i) => { if (!S.get('cat_' + k)) jobs.push(S.save('category', { name: tt(k), kind, color: PALETTE[i % PALETTE.length], seed: true }, 'cat_' + k)); });
  return Promise.all(jobs);
}

// ---- receipts ---------------------------------------------------------------------------------------------------
export async function receiptURL(attId) {
  const b = await C.store.getBlob(attId);
  if (b) return URL.createObjectURL(new Blob([b.bytes], { type: b.mime }));
  const att = C.store.get(attId);
  if (att?.payload.path && C.cloud?.download && navigator.onLine) {
    try { const d = await C.cloud.download(att.payload.path); await C.store.putBlob(attId, d.bytes, d.mime); await C.store.markBlobUploaded(attId); return URL.createObjectURL(new Blob([d.bytes], { type: d.mime })); } catch { /* fall through */ }
  }
  return null;
}
async function saveReceipt(file, txnId) {
  const { bytes, mime } = await compress(file);
  const attId = uuid();
  await C.store.putBlob(attId, bytes, mime);
  await C.store.save('attachment', { mime, size: bytes.length, txnId, uploaded: false }, attId);
  return attId;
}

// ---- transaction sheet --------------------------------------------------------------------------------------------
export function openTxnSheet({ id = null, kind = 'expense', accountId = null } = {}) {
  const ex = id ? C.store.get(id) : null, p = ex?.payload;
  const txId = id || uuid();                                  // fixed up front: a double tap overwrites instead of duplicating
  const accs = accounts(); const accId = p?.accountId || accountId || (C.S.accountId !== 'all' ? C.S.accountId : null) || accs[0]?.id;
  const catOpts = k => { const l = categories(k); return l.length ? l.map(c => ({ v: c.id, l: c.payload.name })) : [{ v: '', l: t('uncategorized') }]; };
  let removeReceipt = false;
  const fields = [
    { n: 'kind', type: 'seg', v: p?.kind || kind, opts: [{ v: 'income', l: t('income'), cls: 'inc' }, { v: 'expense', l: t('expense'), cls: 'exp' }],
      onChange: (v, { form }) => { const sel = form.elements.categoryId; sel.innerHTML = catOpts(v).map(o => `<option value="${o.v}">${o.l.replace(/</g, '&lt;')}</option>`).join(''); } },
    { n: 'amount', type: 'amount', label: t('amount'), v: p ? (p.amount / 100).toString() : '', req: true, ph: '0' },
    { n: 'categoryId', type: 'select', label: t('category'), v: p?.categoryId, opts: catOpts(p?.kind || kind) },
    ...(accs.length > 1 ? [{ n: 'accountId', type: 'select', label: t('account'), v: accId, opts: accs.map(a => ({ v: a.id, l: `${a.payload.name} (${a.payload.currency})` })) }] : []),
    { n: 'date', type: 'date', label: t('date'), v: p?.date || todayStr(), req: true },
    { n: 'time', type: 'time', label: t('time'), v: p?.time || nowTime() },
    { n: 'note', type: 'text', label: t('description_opt'), v: p?.note || '', max: 200 },
    { n: 'receipt', type: 'file', label: t('receipt'), prev: p?.attachmentId ? raw('<span class="muted">…</span>') : '' },
  ];
  formSheet({
    title: ex ? t('edit_record') : t('new_record'), fields, submit: ex ? t('save') : t('add'),
    extra: html`<div class="row gap wrap"><button type="button" class="btn small ghost" data-newcat>${icon('plus')}<span>${t('new_category')}</span></button>${p?.attachmentId ? html`<button type="button" class="btn small ghost" data-rmrcpt>${icon('trash')}<span>${t('remove_receipt')}</span></button>` : ''}</div>`,
    onMount: async ({ form }) => {
      form.querySelector('[data-newcat]').onclick = () => openCategorySheet({ kind: form.querySelector('[name=kind]:checked').value, onSaved: c => {
        const sel = form.elements.categoryId; sel.innerHTML = catOpts(c.payload.kind).map(o => `<option value="${o.v}">${o.l.replace(/</g, '&lt;')}</option>`).join(''); sel.value = c.id; } });
      const prev = form.querySelector('[data-prev=receipt]');
      if (p?.attachmentId) {
        const u = await receiptURL(p.attachmentId);
        prev.innerHTML = u ? `<img src="${u}" alt="">` : `<span class="muted">${t('receipt_pending')}</span>`;
        form.querySelector('[data-rmrcpt]').onclick = e => { removeReceipt = true; prev.innerHTML = ''; e.currentTarget.remove(); };
      }
      form.elements.receipt.addEventListener('change', async e => { const f = e.target.files[0]; if (f) prev.innerHTML = `<img src="${URL.createObjectURL(f)}" alt="">`; });
    },
    onSubmit: async v => {
      let attachmentId = p?.attachmentId || null;
      if (v.receipt) { if (attachmentId) await C.store.remove(attachmentId); attachmentId = await saveReceipt(v.receipt, txId); }
      else if (removeReceipt && attachmentId) { await C.store.remove(attachmentId); attachmentId = null; }
      await C.store.save('txn', { kind: v.kind, amount: v.amount, categoryId: v.categoryId || null, accountId: v.accountId || accId, date: v.date, time: v.time, note: v.note, attachmentId, ...(p?.recurring ? { recurring: p.recurring } : {}) }, txId);
    },
    onDelete: ex ? async () => { await C.store.remove(id); toast(t('deleted'), { undo: () => C.store.restore(id) }); return true; } : null,
  });
}

// ---- categories ---------------------------------------------------------------------------------------------------
export function openCategorySheet({ id = null, kind = 'expense', onSaved } = {}) {
  const ex = id ? C.store.get(id) : null, p = ex?.payload;
  formSheet({
    title: ex ? t('edit_category') : t('new_category'),
    fields: [
      { n: 'kind', type: 'seg', v: p?.kind || kind, opts: [{ v: 'income', l: t('income'), cls: 'inc' }, { v: 'expense', l: t('expense'), cls: 'exp' }] },
      { n: 'name', type: 'text', label: t('name'), v: p?.name || '', req: true, max: 40 },
      { n: 'color', type: 'color', label: t('color'), v: p?.color || PALETTE[Math.floor(Math.random() * PALETTE.length)] },
      ...(ex ? [{ n: 'hidden', type: 'check', label: t('hide_category'), v: p.hidden }] : []),
    ],
    onSubmit: async v => { const r = await C.store.save('category', { name: v.name, kind: v.kind, color: v.color, hidden: !!v.hidden }, id); onSaved?.(r); },
  });
}
export function openCategoryManager() {
  const draw = () => {
    const list = C.store.list('category').sort((a, b) => a.updatedAt - b.updatedAt);
    return html`<div class="row end"><button class="btn primary small" data-newcat>${icon('plus')}<span>${t('new_category')}</span></button></div>
      ${['income', 'expense'].map(k => html`<h3 class="sec">${t(k)}</h3><ul class="list">${list.filter(c => c.payload.kind === k).map(c => html`
        <li class="item ${c.payload.hidden ? 'dim' : ''}" data-cat="${c.id}"><span class="dot" style="background:${c.payload.color}"></span><span class="grow">${c.payload.name}${c.payload.hidden ? html` <small class="muted">(${t('hidden')})</small>` : ''}</span>${icon('edit')}</li>`)}</ul>`)}`;
  };
  const s = openSheet({ title: t('categories'), body: draw(), onMount: s => {
    const redraw = () => { s.body.innerHTML = H(draw()); };
    s.body.addEventListener('click', e => {
      if (e.target.closest('[data-newcat]')) openCategorySheet({ onSaved: redraw });
      const li = e.target.closest('[data-cat]'); if (li) openCategorySheet({ id: li.dataset.cat, onSaved: redraw });
    });
    const off = C.store.on(ev => { if (ev.type === 'category') redraw(); }); s.onClose = off;
  } });
  return s;
}

// ---- home view ----------------------------------------------------------------------------------------------------
function scope() {
  const accs = accounts(); const acc = C.S.accountId === 'all' ? null : account(C.S.accountId);
  if (C.S.accountId !== 'all' && (!acc || acc.deleted)) C.S.accountId = 'all';
  const cur = acc ? acc.payload.currency : defCur();
  const list = acc ? [acc] : accs.filter(a => a.payload.currency === cur);
  return { acc, cur, ids: new Set(list.map(a => a.id)), list, mixed: !acc && accs.some(a => a.payload.currency !== cur) };
}

export function txListHtml() {
  const { S } = C, sc = scope(), today = todayStr(), q = S.q.trim().toLowerCase();
  let rows = C.store.list('txn').filter(r => sc.ids.has(r.payload.accountId) && inPeriod(r.payload.date, S.period, S.month, today));
  const sum = summarize(rows);
  if (S.kind) rows = rows.filter(r => r.payload.kind === S.kind);
  if (S.categoryId) rows = rows.filter(r => r.payload.categoryId === S.categoryId);
  if (q) rows = rows.filter(r => (r.payload.note + ' ' + catName(r.payload.categoryId) + ' ' + r.payload.amount / 100).toLowerCase().includes(q));
  rows.sort((a, b) => (b.payload.date + (b.payload.time || '')).localeCompare(a.payload.date + (a.payload.time || '')) || b.updatedAt - a.updatedAt);
  if (!rows.length) {
    const msg = S.period === 'today' ? t('no_tx_today') : S.period === 'all' ? t('no_tx_all') : t('no_tx_month', { m: fmtMonth(S.month, lang()) });
    return html`<div class="empty">${icon('note')}<p>${S.kind === 'income' ? t('no_income') : S.kind === 'expense' ? t('no_expense') : msg}</p></div>`;
  }
  const groups = []; for (const r of rows) { const g = groups[groups.length - 1]; if (g && g.d === r.payload.date) g.r.push(r); else groups.push({ d: r.payload.date, r: [r] }); }
  return html`${groups.map(g => { const gs = summarize(g.r); return html`<div class="day"><span>${g.d === today ? t('today') : fmtDate(g.d, lang())}</span><span class="${gs.balance < 0 ? 'neg' : 'pos'}">${fmt(gs.balance, sc.cur, { sign: true })}</span></div>
    <ul class="list">${g.r.map(r => { const p = r.payload, c = category(p.categoryId); return html`<li class="item tx" data-act="txn-edit" data-id="${r.id}">
      <span class="dot lg" style="background:${c?.payload.color || '#999'}"></span>
      <span class="grow"><b>${catName(p.categoryId)}</b><small class="muted">${p.note ? p.note + ' · ' : ''}${fmtTime(p.time, lang())}${sc.list.length > 1 ? ' · ' + (account(p.accountId)?.payload.name || '') : ''}</small></span>
      ${p.attachmentId ? icon('image', 'sm muted') : ''}${p.recurring ? icon('repeat', 'sm muted') : ''}
      <span class="amt ${p.kind === 'income' ? 'pos' : 'neg'}">${fmt(p.kind === 'income' ? p.amount : -p.amount, curOf(p.accountId), { sign: true })}</span></li>`; })}</ul>`; })}`;
}

export function homeView() {
  const { S } = C, sc = scope(), today = todayStr(), accs = accounts();
  const inP = C.store.list('txn').filter(r => sc.ids.has(r.payload.accountId) && inPeriod(r.payload.date, S.period, S.month, today));
  const sum = summarize(inP), tot = sum.income + sum.expense, ip = tot ? Math.round(sum.income / tot * 100) : 50;
  const walletBal = sc.list.reduce((s, a) => s + balanceOf(a), 0);
  const mlabel = fmtMonth(S.month, lang());
  const catFilter = S.categoryId ? catName(S.categoryId) : '';
  return html`
  ${accs.length > 1 ? html`<div class="chips" role="tablist"><button class="chip ${S.accountId === 'all' ? 'on' : ''}" data-act="acc" data-id="all">${t('all_accounts')}</button>${accs.map(a => html`<button class="chip ${S.accountId === a.id ? 'on' : ''}" data-act="acc" data-id="${a.id}">${a.payload.name}</button>`)}</div>` : ''}
  <section class="card summary">
    <div class="period">
      <button class="pbtn ${S.period === 'today' ? 'on' : ''}" data-act="period" data-p="today">${t('today')}</button>
      <div class="pmonth ${S.period === 'month' ? 'on' : ''}"><button data-act="mprev" aria-label="${t('prev')}">${icon('chevL')}</button><button class="mlabel" data-act="period" data-p="month">${mlabel}</button><button data-act="mnext" aria-label="${t('next')}">${icon('chevR')}</button></div>
      <button class="pbtn ${S.period === 'all' ? 'on' : ''}" data-act="period" data-p="all">${t('total')}</button>
    </div>
    <div class="splitbar" aria-hidden="true"><i style="width:${ip}%"></i><b></b></div>
    <div class="trio">
      <button data-act="kind" data-k="income" class="${S.kind === 'income' ? 'sel' : ''}"><small>${t('income')}</small><strong class="pos">${fmt(sum.income, sc.cur)}</strong></button>
      <button data-act="kind" data-k="expense" class="${S.kind === 'expense' ? 'sel' : ''}"><small>${t('expense')}</small><strong class="neg">${fmt(sum.expense, sc.cur)}</strong></button>
      <button data-act="kind" data-k="" class="${S.kind === '' ? 'sel' : ''}"><small>${t('remaining')}</small><strong class="${sum.balance < 0 ? 'neg' : 'blu'}">${fmt(sum.balance, sc.cur)}</strong></button>
    </div>
    <div class="wallet-line"><span>${icon('wallet', 'sm')} ${t('balance_now')}</span><strong>${fmt(walletBal, sc.cur)}</strong></div>
    ${sc.mixed ? html`<p class="hint">${t('mixed_currency', { c: sc.cur })}</p>` : ''}
  </section>
  <div class="toolbar">
    <label class="search">${icon('search')}<input id="q" data-input="home-q" type="search" value="${S.q}" placeholder="${t('search')}" autocomplete="off"></label>
    <button class="icon-btn ${S.categoryId ? 'on' : ''}" data-act="cat-filter" aria-label="${t('filter')}">${icon('filter')}</button>
    <button class="icon-btn" data-act="cat-manage" aria-label="${t('categories')}">${icon('tag')}</button>
  </div>
  ${catFilter ? html`<div class="chips"><button class="chip on" data-act="cat-clear">${catFilter} ✕</button></div>` : ''}
  <div id="txlist">${txListHtml()}</div>
  <button class="fab" data-act="txn-add" aria-label="${t('add')}">${icon('plus')}</button>`;
}

export function registerHome() {
  act('period', d => { C.S.period = d.p; C.render(); });
  act('mprev', () => { C.S.month = addMonths(C.S.month, -1); C.S.period = 'month'; C.render(); });
  act('mnext', () => { C.S.month = addMonths(C.S.month, 1); C.S.period = 'month'; C.render(); });
  act('acc', d => { C.S.accountId = d.id; C.render(); });
  act('kind', d => { C.S.kind = C.S.kind === d.k ? '' : d.k; C.render(); });
  act('txn-add', () => openTxnSheet({}));
  act('txn-edit', d => openTxnSheet({ id: d.id }));
  act('cat-manage', () => openCategoryManager());
  act('cat-clear', () => { C.S.categoryId = ''; C.render(); });
  act('cat-filter', () => {
    const cs = categories(); const s = openSheet({ title: t('filter_category'), body: html`<ul class="list"><li class="item" data-c=""><span class="grow">${t('all')}</span></li>${cs.map(c => html`<li class="item" data-c="${c.id}"><span class="dot" style="background:${c.payload.color}"></span><span class="grow">${c.payload.name}</span><small class="muted">${t(c.payload.kind)}</small></li>`)}</ul>`,
      onMount: s => s.body.addEventListener('click', e => { const li = e.target.closest('[data-c]'); if (li) { C.S.categoryId = li.dataset.c; s.close(); C.render(); } }) });
  });
}
