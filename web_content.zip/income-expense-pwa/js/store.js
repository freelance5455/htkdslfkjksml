// Local, encrypted, offline-first record store.
// - Every record payload is AES-GCM encrypted on disk; the decrypted copy lives only in memory while unlocked.
// - Edits never destroy history: the previous state of a record is kept in the `versions` store.
// - Deleting is soft (trash). Records are never hard-deleted locally or in the cloud.
import { uuid } from './util.js';
import {
  randomBytes, deriveKey, importRawKey, newDeviceKey, encryptBytes, decryptBytes, encryptJSON, decryptJSON, b64, unb64, PBKDF2_ITER,
} from './crypto.js';
import { mergeRemote, same } from './sync-core.js';

export function createStore(backend) {
  const listeners = new Set();
  const cache = new Map();          // id -> record (decrypted, in memory)
  const conflicts = new Map();      // id -> [{payload, deleted, updatedAt, deviceId, at, source}]
  let dek = null, rawDek = null, deviceId = null, keyring = null, loadErrors = 0;

  const emit = e => listeners.forEach(fn => { try { fn(e); } catch (err) { console.error(err); } });
  const metaGet = async k => (await backend.get('meta', k))?.value;
  const metaSet = (k, value) => backend.put('meta', { key: k, value });

  async function toDisk(r) {
    return { id: r.id, type: r.type, dirty: r.dirty ? 1 : 0, deleted: r.deleted ? 1 : 0, rev: r.rev,
      enc: await encryptJSON(dek, { payload: r.payload, lv: r.lv, updatedAt: r.updatedAt, deviceId: r.deviceId }) };
  }
  async function persist(rec, prev) {
    cache.set(rec.id, rec);
    if (prev && (prev.deleted !== rec.deleted || !same(prev, rec)) && (prev.payload)) {
      await backend.put('versions', { key: `${rec.id}@${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, id: rec.id, at: Date.now(),
        enc: await encryptJSON(dek, { payload: prev.payload, deleted: prev.deleted, rev: prev.rev, updatedAt: prev.updatedAt, deviceId: prev.deviceId }) });
    }
    await backend.put('records', await toDisk(rec));
  }

  async function loadAll() {
    cache.clear(); conflicts.clear(); loadErrors = 0;
    for (const row of await backend.getAll('records')) {
      try {
        const d = await decryptJSON(dek, row.enc);
        cache.set(row.id, { id: row.id, type: row.type, rev: row.rev, dirty: !!row.dirty, deleted: !!row.deleted, ...d });
      } catch { loadErrors++; }
    }
    for (const row of await backend.getAll('conflicts')) {
      try { conflicts.set(row.id, await decryptJSON(dek, row.enc)); } catch { loadErrors++; }
    }
  }
  async function setKey(raw) { rawDek = raw; dek = await importRawKey(raw, false); await loadAll(); emit({ kind: 'unlock' }); }

  const api = {
    on(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    get deviceId() { return deviceId; },
    get loadErrors() { return loadErrors; },
    get unlocked() { return !!dek; },
    getMeta: metaGet, setMeta: metaSet,

    /** Opens the DB. Returns {locked}. A fresh install creates a random data key wrapped by a device key. */
    async init() {
      await backend.open();
      deviceId = await metaGet('deviceId');
      if (!deviceId) { deviceId = uuid(); await metaSet('deviceId', deviceId); }
      keyring = await metaGet('keyring');
      if (!keyring) {
        const raw = randomBytes(32), dk = await newDeviceKey();
        await metaSet('deviceKey', dk);
        keyring = { mode: 'device', wrapped: await encryptBytes(dk, raw) };
        await metaSet('keyring', keyring);
      }
      if (keyring.mode === 'device') {
        const dk = await metaGet('deviceKey');
        await setKey(await decryptBytes(dk, keyring.wrapped));
        return { locked: false };
      }
      return { locked: true };
    },
    hasPin: () => keyring?.mode === 'pin',

    async unlockPin(pin) {
      if (keyring.mode !== 'pin') return true;
      try {
        const kek = await deriveKey(pin, unb64(keyring.salt), keyring.iter);
        await setKey(await decryptBytes(kek, keyring.wrapped)); return true;
      } catch { return false; }
    },
    async setPin(pin) {
      if (!dek) throw new Error('locked');
      const salt = randomBytes(16), kek = await deriveKey(pin, salt);
      keyring = { mode: 'pin', salt: b64(salt), iter: PBKDF2_ITER, wrapped: await encryptBytes(kek, rawDek) };
      await metaSet('keyring', keyring); await backend.delete('meta', 'deviceKey');
    },
    async removePin(pin) {
      if (!(await verifyPin(pin))) return false;
      const dk = await newDeviceKey();
      keyring = { mode: 'device', wrapped: await encryptBytes(dk, rawDek) };
      await metaSet('deviceKey', dk); await metaSet('keyring', keyring); await backend.delete('meta', 'bio');
      return true;
    },
    async changePin(oldPin, newPin) { if (!(await verifyPin(oldPin))) return false; await api.setPin(newPin); return true; },
    verifyPin: pin => verifyPin(pin),
    lock() { dek = null; rawDek = null; cache.clear(); conflicts.clear(); emit({ kind: 'lock' }); },

    // Biometric (WebAuthn PRF) wrapping. keyBytes = 32 secret bytes produced by the authenticator.
    async enableBio(keyBytes, info) {
      if (!dek) throw new Error('locked');
      await metaSet('bio', { ...info, wrapped: await encryptBytes(await importRawKey(keyBytes), rawDek) });
    },
    async unlockBio(keyBytes) {
      const bio = await metaGet('bio'); if (!bio) return false;
      try { await setKey(await decryptBytes(await importRawKey(keyBytes), bio.wrapped)); return true; } catch { return false; }
    },
    getBio: () => metaGet('bio'),
    disableBio: () => backend.delete('meta', 'bio'),

    // ---- records -----------------------------------------------------------------------------------------
    list(type, { deleted = false } = {}) {
      const out = []; for (const r of cache.values()) if (r.type === type && (deleted ? r.deleted : !r.deleted)) out.push(r);
      return out;
    },
    all: () => [...cache.values()],
    get: id => cache.get(id),
    pending: () => [...cache.values()].filter(r => r.dirty),

    /** Create (id omitted) or edit. The previous state is archived in `versions`. */
    async save(type, payload, id = null) {
      const prev = id ? cache.get(id) : null, now = Date.now();
      const rec = prev
        ? { ...prev, payload, deleted: false, dirty: true, lv: prev.lv + 1, updatedAt: now, deviceId }
        : { id: id || uuid(), type, rev: 0, lv: 1, dirty: true, deleted: false, payload, updatedAt: now, deviceId };
      await persist(rec, prev); emit({ kind: 'change', id: rec.id, type, local: true });
      return rec;
    },
    async patch(id, fn) { const r = cache.get(id); return api.save(r.type, fn(structuredClone(r.payload)), id); },
    async remove(id) {
      const prev = cache.get(id); if (!prev || prev.deleted) return;
      await persist({ ...prev, deleted: true, dirty: true, lv: prev.lv + 1, updatedAt: Date.now(), deviceId }, prev);
      emit({ kind: 'change', id, type: prev.type, local: true });
    },
    async restore(id) {
      const prev = cache.get(id); if (!prev || !prev.deleted) return;
      await persist({ ...prev, deleted: false, dirty: true, lv: prev.lv + 1, updatedAt: Date.now(), deviceId }, prev);
      emit({ kind: 'change', id, type: prev.type, local: true });
    },
    async history(id) {
      const rows = (await backend.getAll('versions')).filter(v => v.id === id).sort((a, b) => b.at - a.at);
      const out = []; for (const v of rows) { try { out.push({ at: v.at, ...(await decryptJSON(dek, v.enc)) }); } catch { /* skip */ } }
      return out;
    },

    // ---- sync hooks --------------------------------------------------------------------------------------
    async markSynced(id, newRev, lvAtPush) {
      const r = cache.get(id); if (!r) return;
      await persist({ ...r, rev: newRev, dirty: r.lv !== lvAtPush }, null);
    },
    /** Apply a cloud record. Never overwrites local unsynced work: see mergeRemote. */
    async applyRemote(remote) {
      const local = cache.get(remote.id);
      const res = mergeRemote(local, remote);
      if (res.record) await persist(res.record, local);
      if (res.conflict) await addConflict(remote.id, { ...res.conflict.other, at: Date.now(), source: 'sync' });
      if (res.record || res.conflict) emit({ kind: 'change', id: remote.id, type: remote.type, remote: true, note: res.note, conflict: !!res.conflict });
      return res;
    },
    async markAllForUpload() {   // used when the signed-in cloud account changes
      for (const r of [...cache.values()]) await persist({ ...r, rev: 0, dirty: true, lv: r.lv + 1 }, null);
    },

    // ---- conflicts ---------------------------------------------------------------------------------------
    conflictList() { return [...conflicts.entries()].map(([id, others]) => ({ id, current: cache.get(id), others })).filter(c => c.current); },
    async resolveConflict(id, index, useOther) {
      const arr = conflicts.get(id) || []; const other = arr[index]; if (!other) return;
      if (useOther) await api.save(cache.get(id).type, other.payload, id);
      arr.splice(index, 1);
      if (arr.length) { await backend.put('conflicts', { id, enc: await encryptJSON(dek, arr) }); } else { conflicts.delete(id); await backend.delete('conflicts', id); }
      emit({ kind: 'change', id, type: cache.get(id).type, local: true });
    },

    // ---- receipt blobs -----------------------------------------------------------------------------------
    async putBlob(id, bytes, mime) {
      await backend.put('blobs', { id, mime, uploaded: 0, enc: await encryptBytes(dek, bytes) });
    },
    async getBlob(id) {
      const row = await backend.get('blobs', id); if (!row) return null;
      return { bytes: await decryptBytes(dek, row.enc), mime: row.mime, uploaded: !!row.uploaded };
    },
    async blobsToUpload() { return (await backend.getAll('blobs')).filter(b => !b.uploaded).map(b => b.id); },
    async markBlobUploaded(id) { const row = await backend.get('blobs', id); if (row) await backend.put('blobs', { ...row, uploaded: 1 }); },

    // ---- backup / restore -------------------------------------------------------------------------------
    async exportAll({ withBlobs = true, withVersions = true } = {}) {
      const out = { format: 'income-expense-backup', version: 1, exportedAt: new Date().toISOString(), deviceId,
        records: api.all().map(r => ({ id: r.id, type: r.type, rev: r.rev, deleted: r.deleted, payload: r.payload, updatedAt: r.updatedAt, deviceId: r.deviceId })) };
      if (withVersions) { out.versions = []; for (const r of out.records) for (const h of await api.history(r.id)) out.versions.push({ id: r.id, ...h }); }
      if (withBlobs) { out.blobs = []; for (const row of await backend.getAll('blobs')) { const b = await api.getBlob(row.id); if (b) out.blobs.push({ id: row.id, mime: b.mime, data: b64(b.bytes) }); } }
      return out;
    },
    /** Additive restore. Never deletes. New ids are added; an id that exists with different content keeps the current
     *  version and stores the backup's version as a conflict for the user to review. */
    async importAll(data) {
      if (data?.format !== 'income-expense-backup' || !Array.isArray(data.records)) throw new Error('Not a backup file');
      let added = 0, same_ = 0, conflicted = 0;
      for (const r of data.records) {
        const local = cache.get(r.id);
        if (!local) {
          await persist({ id: r.id, type: r.type, rev: 0, lv: 1, dirty: true, deleted: !!r.deleted, payload: r.payload, updatedAt: r.updatedAt || Date.now(), deviceId: r.deviceId || deviceId }, null);
          added++;
        } else if (same(local, r)) same_++;
        else if (local.type === 'setting') same_++;
        else { await addConflict(r.id, { payload: r.payload, deleted: !!r.deleted, updatedAt: r.updatedAt, deviceId: r.deviceId, at: Date.now(), source: 'backup' }); conflicted++; }
      }
      for (const b of data.blobs || []) if (!(await backend.get('blobs', b.id))) await api.putBlob(b.id, unb64(b.data), b.mime);
      emit({ kind: 'change', local: true });
      return { added, same: same_, conflicted };
    },
    async wipeEverything() {
      for (const s of ['records', 'versions', 'blobs', 'conflicts']) await backend.clear(s);
      cache.clear(); conflicts.clear(); await backend.delete('meta', 'cursor'); emit({ kind: 'change', local: true });
    },
  };

  async function verifyPin(pin) {
    if (keyring.mode !== 'pin') return false;
    try { const kek = await deriveKey(pin, unb64(keyring.salt), keyring.iter); await decryptBytes(kek, keyring.wrapped); return true; } catch { return false; }
  }
  async function addConflict(id, other) {
    const arr = conflicts.get(id) || [];
    if (arr.some(o => same(o, other))) return;
    arr.push(other); conflicts.set(id, arr);
    await backend.put('conflicts', { id, enc: await encryptJSON(dek, arr) });
  }
  return api;
}
