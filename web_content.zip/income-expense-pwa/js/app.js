// App bootstrap: storage → lock screen → seed → sync → render. The UI never waits for the network.
import { C, t, act, settings, lang } from './ctx.js';
import { createStore } from './store.js';
import { idbBackend } from './db.js';
import { createSync } from './sync.js';
import { createCloud } from './cloud.js';
import { firebaseConfig } from './config.js';
import { setLang } from './i18n.js';
import { html, icon, H, toast, confirmBox, closeAllSheets, sheetDepth } from './ui.js';
import { registerHome, homeView, txListHtml, seedDefaults, openTxnSheet } from './views-home.js';
import { registerMenu, menuView, securityView, backupView, trashView, syncView, conflictsView, saveSettings, LS, syncSummary } from './views-menu.js';

const $ = s => document.querySelector(s);
const TABS = [['home', 'home'], ['menu', 'menu']];
const SUB = { sync: ['cloud_sync', syncView], conflicts: ['conflicts', conflictsView], security: ['security', securityView], backup: ['backup_restore', backupView], trash: ['trash', trashView] };
let started = false, renderQueued = false;

// ---- theme / language from local mirror (available even before unlock) ----------------------------------------------------------
function applyUi() {
  let ui = {}; try { ui = JSON.parse(LS.get('ie_ui', '{}')); } catch { /* ignore */ }
  setLang(ui.lang || 'bn');
  document.documentElement.dataset.theme = ui.theme || 'taka'; document.documentElement.dataset.mode = ui.mode || 'auto';
}

// ---- rendering ----------------------------------------------------------------------------------------------------------------------------
function render() {
  if (!C.store?.unlocked) return;
  const active = document.activeElement, keep = active && active.id === 'q' ? { v: active.value, s: active.selectionStart } : null;
  const r = C.S.route, sub = SUB[r], info = C.S.syncInfo;
  const body = sub ? sub[1]() : r === 'menu' ? menuView() : homeView();
  const head = sub
    ? html`<header class="bar"><button class="icon-btn" data-act="back" aria-label="${t('close')}">${icon('back')}</button><h1>${t(sub[0])}</h1></header>`
    : html`<header class="bar"><img class="logo" src="icons/logo-64.png" alt=""><h1>${t('app_name')}</h1><span class="grow"></span>
      <span class="sdot ${info.status}" title="${syncSummary()}" data-act="go-sync"></span>
      <button class="icon-btn" data-act="toggle-privacy" aria-label="${t('privacy_mode')}">${icon(C.privacy ? 'eyeoff' : 'eye')}</button></header>`;
  $('#app').innerHTML = H(html`${head}<main id="main" class="${sub ? 'sub' : ''}">${body}</main>
    ${sub ? '' : html`<nav class="tabs">${TABS.map(([k, ic]) => html`<button class="${r === k ? 'on' : ''}" data-act="tab" data-t="${k}">${icon(ic)}<span>${t(k)}</span></button>`)}</nav>`}`);
  if (keep) { const q = $('#q'); if (q) { q.focus(); q.setSelectionRange(keep.s, keep.s); } }
}
const queueRender = () => { if (renderQueued) return; renderQueued = true; requestAnimationFrame(() => { renderQueued = false; render(); }); };
C.render = queueRender;
C.go = name => { location.hash = '#/' + name; };

function route() {
  const h = location.hash.replace(/^#\/?/, '');
  const [name, arg] = h.split('/');
  if (name === 'add' && C.store?.unlocked) { history.replaceState(null, '', '#/home'); C.S.route = 'home'; render(); openTxnSheet({ kind: arg === 'income' ? 'income' : 'expense' }); return; }
  C.S.route = (name === 'menu' || SUB[name]) ? name : 'home';
  render();
}

// ---- lock screen ----------------------------------------------------------------------------------------------------------------------------
function showLock() {
  closeAllSheets(); $('#app').innerHTML = '';
  const box = $('#lock'); box.hidden = false;
  const draw = msg => {
    box.innerHTML = H(html`<div class="lockbox"><img class="logo big" src="icons/logo-192.png" alt=""><h1>${t('app_name')}</h1><p>${t('locked_title')}</p>
      <form id="pinform"><input id="pin" type="password" inputmode="numeric" autocomplete="off" maxlength="8" placeholder="${t('enter_pin')}" aria-label="${t('enter_pin')}">
      <p class="err" role="alert">${msg || ''}</p><button class="btn primary" type="submit">${t('unlock')}</button></form></div>`);
    const f = $('#pinform'), inp = $('#pin'); inp.focus();
    f.onsubmit = async e => {
      e.preventDefault();
      const until = (await C.store.getMeta('lockUntil')) || 0, wait = Math.ceil((until - Date.now()) / 1000);
      if (wait > 0) return draw(t('try_later', { s: wait }));
      if (await C.store.unlockPin(inp.value)) { await C.store.setMeta('pinFails', 0); box.hidden = true; box.innerHTML = ''; await afterUnlock(); }
      else {
        const n = ((await C.store.getMeta('pinFails')) || 0) + 1; await C.store.setMeta('pinFails', n);
        if (n >= 5) await C.store.setMeta('lockUntil', Date.now() + Math.min(900, 15 * 2 ** (n - 5)) * 1000);
        draw(t('wrong_pin'));
      }
    };
  };
  draw();
}

// ---- after unlock ------------------------------------------------------------------------------------------------------------------------
async function afterUnlock() {
  if (!C.store.get('settings')) { let ui = {}; try { ui = JSON.parse(LS.get('ie_ui', '{}')); } catch { /* */ } await saveSettings({ lang: ui.lang || 'bn' }); }
  setLang(settings().lang);
  await seedDefaults(settings().lang);
  C.S.storageOn = !!(await C.store.getMeta('storageEnabled')); C.cloud.setStorageEnabled?.(C.S.storageOn);
  if (!started) { started = true; startSync(); }
  else C.sync?.run();
  route();
}

function startSync() {
  C.sync = createSync({
    store: C.store, remote: C.cloud,
    onStatus: s => { C.S.syncInfo = s; if (['home', 'menu', 'sync'].includes(C.S.route)) queueRender(); },
    notice: note => toast(t('notice_' + note), { ms: 7000 }),
  });
  C.store.on(e => {
    if (e.kind === 'change') { if (e.conflict) toast(t('notice_conflict'), { ms: 7000 }); queueRender(); }
  });
  C.sync.start();
  if (C.cloud.available) C.cloud.onAuth(onAuth);
  if (C.cloud.available && navigator.onLine) C.cloud.init().catch(() => {});
  addEventListener('online', () => { if (C.cloud.available) C.cloud.init().then(() => C.sync.run()).catch(() => {}); });
}

async function onAuth(user) {
  if (!user || !C.store.unlocked) { C.sync?.run(); queueRender(); return; }
  const prev = await C.store.getMeta('syncUid');
  if (prev && prev !== user.uid) {
    const yes = await confirmBox({ title: t('switch_title'), message: t('switch_msg'), ok: t('switch_yes') });
    if (!yes) { await C.cloud.signOut(); return; }
    await C.store.markAllForUpload(); await C.store.setMeta('cursor', 0); C.sync.reset();
  }
  await C.store.setMeta('syncUid', user.uid);
  C.sync.run(); queueRender();
}

// ---- global events ----------------------------------------------------------------------------------------------------------------------
function wire() {
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-act]'); if (!el || /^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName)) return;
    const fn = C.actions[el.dataset.act]; if (fn) { e.preventDefault(); fn(el.dataset, el, e); }
  });
  document.addEventListener('change', e => {
    const el = e.target.closest('[data-act]'); if (!el || !/^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName)) return;
    C.actions[el.dataset.act]?.(el.dataset, el, e);
  });
  document.addEventListener('input', e => { const n = e.target.dataset?.input; if (n && C.inputs[n]) C.inputs[n](e.target.value); });
  addEventListener('hashchange', route);
  document.addEventListener('visibilitychange', () => {
    if (!C.store.hasPin()) return;
    if (document.visibilityState === 'hidden') LS.set('ie_hidden', String(Date.now()));
    else if (C.store.unlocked) {
      const lim = +LS.get('ie_autolock', '60'); const away = Date.now() - +LS.get('ie_hidden', String(Date.now()));
      if (lim >= 0 && away >= lim * 1000) { C.store.lock(); showLock(); }
    }
  });
  addEventListener('beforeinstallprompt', e => { e.preventDefault(); C.installEvt = e; if (C.store?.unlocked) queueRender(); });
  addEventListener('appinstalled', () => { C.installEvt = null; });
  C.inputs = { 'home-q': v => { C.S.q = v; const l = $('#txlist'); if (l) l.innerHTML = H(txListHtml()); } };
  act('tab', d => C.go(d.t));
  act('back', () => { if (history.length > 1) history.back(); else C.go('menu'); });
  act('toggle-privacy', () => { C.privacy = !C.privacy; LS.set('ie_privacy', C.privacy ? '1' : '0'); render(); });
  registerHome(); registerMenu();
}

// ---- boot --------------------------------------------------------------------------------------------------------------------------------------
async function boot() {
  applyUi(); C.privacy = LS.get('ie_privacy', '0') === '1';
  if ('serviceWorker' in navigator && window.isSecureContext) navigator.serviceWorker.register('sw.js').catch(() => {});
  navigator.storage?.persist?.().catch(() => {});
  C.store = createStore(idbBackend());
  C.cloud = globalThis.__testCloud || createCloud(firebaseConfig);
  wire();
  const { locked } = await C.store.init();
  document.getElementById('boot')?.remove();
  if (locked) showLock(); else await afterUnlock();
  globalThis.__ie = C;   // handy for debugging in the browser console
}
boot().catch(e => { document.getElementById('boot').textContent = 'Startup error: ' + e.message; console.error(e); });
