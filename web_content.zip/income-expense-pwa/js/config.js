// Paste YOUR Firebase web config here (Firebase console → Project settings → Your apps → Web app → SDK setup).
// Leave as null and the app runs fully offline on the phone without cloud sync.
// These values are not secrets; your Firestore/Storage security rules are what protect the data.
export const firebaseConfig = null;
/* Example:
export const firebaseConfig = {
  apiKey: "AIza...", authDomain: "your-project.firebaseapp.com", projectId: "your-project",
  storageBucket: "your-project.firebasestorage.app", messagingSenderId: "...", appId: "1:...:web:..."
};
*/
