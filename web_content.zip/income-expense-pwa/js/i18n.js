import { STR } from './strings.js';
let current = 'bn';
export const setLang = l => { current = l === 'en' ? 'en' : 'bn'; document.documentElement.lang = current; };
export const getLang = () => current;
/** t('key', {n: 3}) — falls back to English, then to the key itself. */
export function t(key, vars) {
  let s = STR[current]?.[key] ?? STR.en[key] ?? key;
  if (vars) for (const k in vars) s = s.replaceAll(`{${k}}`, vars[k]);
  return s;
}
