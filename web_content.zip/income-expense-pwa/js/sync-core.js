// Pure merge rules. No I/O. This is the heart of "never silently lose a financial record".
//
// A local record: {id,type,rev,lv,dirty,deleted,payload,updatedAt,deviceId}
//   rev   = last cloud revision this device knows about (0 = never synced)
//   dirty = has local changes not yet confirmed by the cloud
// A remote record: {id,type,rev,deleted,payload,updatedAt,deviceId}

export function canon(v) {
  if (Array.isArray(v)) return '[' + v.map(canon).join(',') + ']';
  if (v && typeof v === 'object') return '{' + Object.keys(v).sort().filter(k => v[k] !== undefined).map(k => JSON.stringify(k) + ':' + canon(v[k])).join(',') + '}';
  return JSON.stringify(v);
}
export const same = (a, b) => !!a.deleted === !!b.deleted && canon(a.payload) === canon(b.payload);

const clean = r => ({ id: r.id, type: r.type, rev: r.rev, lv: 0, dirty: false, deleted: !!r.deleted, payload: r.payload, updatedAt: r.updatedAt, deviceId: r.deviceId });

/**
 * Decide what to do when cloud record `remote` arrives and we hold `local` (maybe undefined).
 * Returns { record, conflict?, note? }
 *   record   - the record state to keep as "current" (null = leave local untouched)
 *   conflict - { other: {payload, deleted, updatedAt} } a competing version kept for the user to choose
 *   note     - 'edit-kept' (a local delete lost to a remote edit) | 'revived' (local edit revived a remote delete)
 */
export function mergeRemote(local, remote) {
  if (!local) return { record: clean(remote) };
  if (!local.dirty) return remote.rev > local.rev ? { record: clean(remote) } : { record: null };
  // local has unsynced changes
  if (remote.rev <= local.rev) return { record: null };             // not diverged: our push will go through
  if (same(local, remote)) return { record: clean(remote) };          // both sides arrived at the same content
  if (local.type === 'setting') {                                    // non-financial preferences: newest wins
    return local.updatedAt > remote.updatedAt ? { record: { ...local, rev: remote.rev } } : { record: clean(remote) };
  }
  if (local.payload?.seed && remote.payload?.seed) return { record: clean(remote) }; // untouched default data from two devices
  if (local.deleted && remote.deleted) return { record: clean(remote) };
  if (local.deleted && !remote.deleted) return { record: clean(remote), note: 'edit-kept' };   // edit beats delete
  if (!local.deleted && remote.deleted) return { record: { ...local, rev: remote.rev, deleted: false, dirty: true, lv: local.lv + 1 }, note: 'revived' };
  // both edited differently: the cloud version becomes current, ours is kept as a conflict for the user to decide
  return {
    record: clean(remote),
    conflict: { other: { payload: local.payload, deleted: false, updatedAt: local.updatedAt, deviceId: local.deviceId } },
  };
}

/**
 * Decide what a push should do given the cloud's current copy (or undefined). Used inside the Firestore transaction
 * and by the test fake, so the real rule is what gets tested.
 *   'write'    - cloud is at the revision we based our edit on (or has nothing): write rev+1
 *   'already'  - cloud already holds exactly our change (an earlier attempt succeeded but its reply was lost)
 *   'conflict' - someone else changed it: do NOT write; merge instead
 */
export function decidePush(server, rec) {
  if (!server) return 'write';
  if (server.rev === rec.rev) return 'write';
  if (server.rev === rec.rev + 1 && same(server, rec)) return 'already';
  return 'conflict';
}
