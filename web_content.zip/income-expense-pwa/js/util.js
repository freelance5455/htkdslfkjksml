// Small shared helpers: ids, money, dates, escaping.
export const uuid = () =>
  (globalThis.crypto && crypto.randomUUID) ? crypto.randomUUID()
  : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16);
    });

export const CURRENCIES = {
  BDT: '৳', USD: '$', EUR: '€', GBP: '£', INR: '₹', SAR: 'SAR ', AED: 'AED ',
  MYR: 'RM ', PKR: 'Rs ', JPY: '¥', CAD: 'C$', AUD: 'A$', SGD: 'S$', QAR: 'QAR ', KWD: 'KWD ',
};

const BN = '০১২৩৪৫৬৭৮৯';
export const toEnDigits = s => String(s).replace(/[০-৯]/g, d => BN.indexOf(d));
export const toBnDigits = s => String(s).replace(/[0-9]/g, d => BN[d]);

/** Parse a user-typed amount (Bengali or English digits, commas) into integer paisa. Returns NaN if invalid. */
export function parseAmount(str) {
  if (typeof str === 'number') return Math.round(str * 100);
  const s = toEnDigits(str).replace(/[,\s৳$]/g, '').replace('٫', '.');
  if (!/^\d*\.?\d{0,2}$/.test(s) || s === '' || s === '.') return NaN;
  return Math.round(parseFloat(s) * 100);
}

/** Format integer paisa. opts: {lang, currency, privacy, sign, noSymbol} */
export function money(p, o = {}) {
  const { lang = 'en', currency = 'BDT', privacy = false, sign = false, noSymbol = false } = o;
  const sym = noSymbol ? '' : (CURRENCIES[currency] ?? currency + ' ');
  if (privacy) return sym + '••••';
  const neg = p < 0, abs = Math.abs(p);
  const whole = Math.floor(abs / 100), frac = abs % 100;
  const loc = lang === 'bn' ? 'bn-BD' : 'en-IN';
  let s = new Intl.NumberFormat(loc).format(whole);
  if (frac) { const f = String(frac).padStart(2, '0'); s += '.' + (lang === 'bn' ? toBnDigits(f) : f); }
  return (neg ? '−' : (sign && p > 0 ? '+' : '')) + sym + s;
}
export const num = (n, lang) => lang === 'bn' ? toBnDigits(n) : String(n);

export const pad = n => String(n).padStart(2, '0');
export const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const todayStr = () => ymd(new Date());
export const nowTime = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
export const monthKey = s => s.slice(0, 7);
export const parseYmd = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
export function addMonths(key, n) {
  const [y, m] = key.split('-').map(Number); const d = new Date(y, m - 1 + n, 1);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
}
export function addDays(s, n) { const d = parseYmd(s); d.setDate(d.getDate() + n); return ymd(d); }
const loc = lang => lang === 'bn' ? 'bn-BD' : 'en-GB';
export function fmtDate(s, lang) {
  if (!s) return '';
  return new Intl.DateTimeFormat(loc(lang), { day: 'numeric', month: 'short', year: 'numeric' }).format(parseYmd(s));
}
export function fmtMonth(key, lang) {
  const [y, m] = key.split('-').map(Number);
  return new Intl.DateTimeFormat(loc(lang), { month: 'long', year: 'numeric' }).format(new Date(y, m - 1, 1));
}
export function fmtTime(hhmm, lang) {
  if (!hhmm) return '';
  const [h, m] = hhmm.split(':').map(Number);
  return new Intl.DateTimeFormat(lang === 'bn' ? 'bn-BD' : 'en-US', { hour: 'numeric', minute: '2-digit', hour12: true }).format(new Date(2000, 0, 1, h, m));
}

export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export const sleep = ms => new Promise(r => setTimeout(r, ms));
export const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
