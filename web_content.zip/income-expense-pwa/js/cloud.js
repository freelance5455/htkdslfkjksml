// Firebase adapter (Auth + Firestore + optional Storage), loaded lazily so the app never depends on it to start.
// It implements the same "remote" interface the sync engine and the tests use.
import { decidePush } from './sync-core.js';

const V = '10.14.1', BASE = `https://www.gstatic.com/firebasejs/${V}/`;
const withTimeout = (p, ms = 25000) => Promise.race([p, new Promise((_, rej) => setTimeout(() => { const e = new Error('timeout'); e.code = 'deadline-exceeded'; rej(e); }, ms))]);

export function createCloud(config) {
  const authCbs = new Set();
  let app, auth, db, A, F, S, storage, user = null, loading = null, storageOn = false, storageMod = null;

  async function init() {
    if (!config) throw new Error('not configured');
    if (loading) return loading;
    loading = (async () => {
      const [{ initializeApp }, a, f] = await Promise.all([import(BASE + 'firebase-app.js'), import(BASE + 'firebase-auth.js'), import(BASE + 'firebase-firestore.js')]);
      A = a; F = f; app = initializeApp(config); auth = A.getAuth(app); db = F.getFirestore(app);
      A.onAuthStateChanged(auth, u => { user = u; authCbs.forEach(cb => cb(u)); });
      try { await A.getRedirectResult(auth); } catch { /* ignore */ }
    })().catch(e => { loading = null; throw e; });
    return loading;
  }
  const rec = (id, d) => ({ id, type: d.type, rev: d.rev, deleted: !!d.deleted, payload: JSON.parse(d.payload), updatedAt: d.updatedAt, deviceId: d.deviceId, srv: d.srv?.toMillis?.() ?? 0 });
  const col = () => F.collection(db, 'users', user.uid, 'records');

  const api = {
    available: !!config,
    init,
    get user() { return user; },
    uid: () => user?.uid || null,
    email: () => user?.email || null,
    onAuth(cb) { authCbs.add(cb); return () => authCbs.delete(cb); },
    async signInGoogle() {
      await init(); const p = new A.GoogleAuthProvider();
      try { await A.signInWithPopup(auth, p); } catch (e) { if (e.code === 'auth/popup-blocked' || e.code === 'auth/operation-not-supported-in-this-environment') await A.signInWithRedirect(auth, p); else throw e; }
    },
    async signInEmail(e, p) { await init(); await A.signInWithEmailAndPassword(auth, e, p); },
    async signUp(e, p) { await init(); await A.createUserWithEmailAndPassword(auth, e, p); },
    async reset(e) { await init(); await A.sendPasswordResetEmail(auth, e); },
    async signOut() { await init(); await A.signOut(auth); },

    // ---- remote interface used by the sync engine ----
    async push(r) {
      await init(); if (!user) throw Object.assign(new Error('signed out'), { code: 'unauthenticated' });
      const ref = F.doc(db, 'users', user.uid, 'records', r.id);
      return withTimeout(F.runTransaction(db, async tx => {
        const snap = await tx.get(ref);
        const server = snap.exists() ? rec(snap.id, snap.data()) : undefined;
        const d = decidePush(server, r);
        if (d === 'conflict') return { conflict: true, server };
        if (d === 'already') return { ok: true, rev: server.rev };
        const rev = r.rev + 1;
        const data = { type: r.type, rev, deleted: !!r.deleted, payload: JSON.stringify(r.payload), updatedAt: r.updatedAt, deviceId: r.deviceId };
        tx.set(ref, { ...data, srv: F.serverTimestamp() });
        tx.set(F.doc(db, 'users', user.uid, 'versions', `${r.id}_${rev}`), { ...data, recordId: r.id, srv: F.serverTimestamp() });
        return { ok: true, rev };
      }));
    },
    async pull(cursor) {
      await init(); const PAGE = 300;
      const q = F.query(col(), F.where('srv', '>=', F.Timestamp.fromMillis(cursor)), F.orderBy('srv'), F.limit(PAGE));
      const snap = await withTimeout(F.getDocs(q));
      const records = snap.docs.map(d => rec(d.id, d.data()));
      return { records, cursor: records.reduce((m, r) => Math.max(m, r.srv), cursor), more: snap.size === PAGE && records[records.length - 1].srv > cursor };
    },
    listen(cursor, cb) {
      const q = F.query(col(), F.where('srv', '>=', F.Timestamp.fromMillis(cursor)), F.orderBy('srv'));
      return F.onSnapshot(q, snap => {
        const recs = snap.docChanges().filter(c => c.type !== 'removed' && !c.doc.metadata.hasPendingWrites && c.doc.data().srv).map(c => rec(c.doc.id, c.doc.data()));
        if (recs.length) cb(recs);
      }, () => { /* listener errors are non-fatal: the periodic pull still runs */ });
    },

    // ---- receipt files (Firebase Storage; only used if the owner enabled it) ----
    setStorageEnabled(on) { storageOn = !!on; },
    canUploadFiles: () => storageOn && !!user,
    async storageApi() {
      await init(); if (!S) S = await import(BASE + 'firebase-storage.js');
      if (!storage) storage = S.getStorage(app); return S;
    },
    async upload(id, bytes, mime) {
      const m = await api.storageApi(); const path = `users/${user.uid}/receipts/${id}`;
      await withTimeout(m.uploadBytes(m.ref(storage, path), bytes, { contentType: mime }), 60000); return path;
    },
    async download(path) {
      const m = await api.storageApi(); const r = m.ref(storage, path);
      const [bytes, meta] = await Promise.all([m.getBytes(r), m.getMetadata(r)]); return { bytes: new Uint8Array(bytes), mime: meta.contentType || 'image/jpeg' };
    },
  };
  return api;
}
