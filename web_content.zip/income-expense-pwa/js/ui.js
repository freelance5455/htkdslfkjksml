// UI building blocks: safe html templates, icons, sheets, toasts, confirm and a small form builder.
import { esc, parseAmount, toEnDigits } from './util.js';
import { t } from './i18n.js';

export const raw = s => ({ __raw: String(s) });
const val = v => v == null || v === false ? '' : Array.isArray(v) ? v.map(val).join('') : v.__raw !== undefined ? v.__raw : esc(v);
/** Tagged template: interpolated values are HTML-escaped unless they came from html`` / raw(). */
export const html = (s, ...v) => raw(s.reduce((o, x, i) => o + x + (i < v.length ? val(v[i]) : ''), ''));
export const H = x => val(x);

const P = {
  home: '<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  dues: '<path d="M7 4v14m0 0l-3-3m3 3l3-3M17 20V6m0 0l-3 3m3-3l3 3"/>',
  tasks: '<path d="M9 6h11M9 12h11M9 18h11M3.5 6l1.5 1.5L7 5M3.5 12l1.5 1.5L7 11M3.5 18l1.5 1.5L7 17"/>',
  budget: '<path d="M4 20V10m6 10V4m6 16v-7m4 7H2"/>',
  savings: '<circle cx="12" cy="12" r="8"/><path d="M12 7.5v9m-2.6-6.8h4a1.6 1.6 0 0 1 0 3.2h-3.1a1.6 1.6 0 0 0 0 3.2h4"/>',
  menu: '<path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', back: '<path d="M15 5l-7 7 7 7"/>', chevR: '<path d="M9 5l7 7-7 7"/>', chevL: '<path d="M15 5l-7 7 7 7"/>',
  trash: '<path d="M4 7h16M10 11v6m4-6v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16zM13 7l4 4"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M3 3l18 18M10.6 5.1A9.7 9.7 0 0 1 12 5c6 0 10 7 10 7a17 17 0 0 1-3.2 3.9M6.6 6.6C3.7 8.5 2 12 2 12s4 7 10 7c1.6 0 3-.4 4.3-1M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>',
  filter: '<path d="M3 5h18l-7 8v6l-4-2v-4z"/>',
  download: '<path d="M12 4v11m0 0l-4-4m4 4l4-4M5 20h14"/>', upload: '<path d="M12 16V5m0 0L8 9m4-4l4 4M5 20h14"/>',
  cloud: '<path d="M7 18a4 4 0 0 1-.6-8A6 6 0 0 1 18 9.5 4.3 4.3 0 0 1 17.5 18z"/>',
  dots: '<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>',
  calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4m8-4v4"/>',
  clock: '<circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="M4 18l5-5 4 4 3-3 4 4"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>', check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
  bell: '<path d="M6 17V11a6 6 0 0 1 12 0v6l2 2H4zM10 21h4"/>',
  wallet: '<path d="M4 7a2 2 0 0 1 2-2h12v4M4 7v11a2 2 0 0 0 2 2h14V9H6a2 2 0 0 1-2-2z"/><circle cx="16.5" cy="14.5" r="1"/>',
  note: '<path d="M6 3h9l4 4v14H6zM14 3v5h5M9 13h7M9 17h7"/>',
  repeat: '<path d="M17 3l3 3-3 3M4 11V9a3 3 0 0 1 3-3h13M7 21l-3-3 3-3m13-2v2a3 3 0 0 1-3 3H4"/>',
  report: '<path d="M6 3h9l4 4v14H6zM9 17v-3m3 3v-6m3 6v-4"/>',
  palette: '<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2s0-2.5 1.5-2.5H17a4 4 0 0 0 4-4C21 6.5 17 3 12 3z"/><circle cx="8" cy="11" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="16" cy="11" r="1"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M12 3v3m0 12v3M3 12h3m12 0h3M5.6 5.6l2.1 2.1m8.6 8.6l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
  alert: '<path d="M12 4l9 16H3zM12 10v4m0 3v.01"/>', swap: '<path d="M7 7h13l-3-3m3 13H7l3 3"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>', tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1"/>',
  pin: '<path d="M12 3l4 5-1 5 3 3H6l3-3-1-5zM12 16v5"/>',
  sync: '<path d="M4 12a8 8 0 0 1 14-5.3L20 9M20 4v5h-5M20 12a8 8 0 0 1-14 5.3L4 15M4 20v-5h5"/>',
  folder: '<path d="M3 6a2 2 0 0 1 2-2h4l2 3h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  print: '<path d="M7 9V3h10v6M7 17H5a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2M7 14h10v7H7z"/>',
};
export const icon = (n, cls = '') => raw(`<svg class="ic ${cls}" viewBox="0 0 24 24" aria-hidden="true">${P[n] || ''}</svg>`);

// ---- sheets (bottom sheets / dialogs) ------------------------------------------------------------------------
const stack = [];
let popping = false;
const host = () => document.getElementById('sheets');

export function openSheet({ title, body, onMount, full = false, onClose }) {
  const ov = document.createElement('div');
  ov.className = 'overlay';
  ov.innerHTML = `<div class="sheet ${full ? 'full' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <div class="grab"></div><div class="sheet-h"><h2>${esc(title)}</h2><button class="icon-btn" data-sheet-close aria-label="${esc(t('close'))}">${icon('close').__raw}</button></div>
    <div class="sheet-b">${H(body)}</div></div>`;
  host().append(ov);
  const s = { el: ov, body: ov.querySelector('.sheet-b'), onClose, close() { closeSheet(s); } };
  stack.push(s);
  history.pushState({ sheet: stack.length }, '');
  ov.addEventListener('mousedown', e => { if (e.target === ov) s.close(); });
  ov.querySelector('[data-sheet-close]').onclick = () => s.close();
  requestAnimationFrame(() => ov.classList.add('in'));
  onMount?.(s);
  return s;
}
export function closeSheet(s) {
  const i = stack.indexOf(s); if (i < 0) return;
  stack.splice(i, 1); s.el.remove(); s.onClose?.();
  if (!popping) { popping = true; history.back(); setTimeout(() => { popping = false; }, 60); }
}
export function closeAllSheets() { while (stack.length) closeSheet(stack[stack.length - 1]); }
export const sheetDepth = () => stack.length;
addEventListener('popstate', () => { if (popping) { popping = false; return; } const s = stack[stack.length - 1]; if (s) { popping = true; stack.pop(); s.el.remove(); s.onClose?.(); setTimeout(() => { popping = false; }, 0); } });

export function toast(msg, { undo, ms = 4500 } = {}) {
  const box = document.getElementById('toasts'); const d = document.createElement('div'); d.className = 'toast';
  d.innerHTML = `<span>${esc(msg)}</span>${undo ? `<button class="link">${esc(t('undo'))}</button>` : ''}`;
  box.append(d); const kill = () => d.remove();
  if (undo) d.querySelector('button').onclick = () => { undo(); kill(); };
  setTimeout(kill, ms);
}

export function confirmBox({ title, message, ok = t('ok'), danger = false }) {
  return new Promise(res => {
    let done = false; const fin = v => { if (!done) { done = true; res(v); } };
    const s = openSheet({ title: title || t('confirm'), body: html`<p class="msg">${message}</p><div class="row end gap"><button class="btn ghost" data-r="0">${t('cancel')}</button><button class="btn ${danger ? 'danger' : 'primary'}" data-r="1">${ok}</button></div>`,
      onClose: () => fin(false), onMount: s => s.body.addEventListener('click', e => { const b = e.target.closest('[data-r]'); if (b) { fin(b.dataset.r === '1'); s.close(); } }) });
  });
}

// ---- form builder --------------------------------------------------------------------------------------------
const fieldHtml = f => {
  const id = 'f_' + f.n, req = f.req ? 'required' : '', v = f.v ?? '';
  if (f.type === 'hint') return html`<p class="hint">${f.label}</p>`;
  if (f.type === 'seg') return html`<div class="seg" role="radiogroup" data-seg="${f.n}">${f.opts.map(o => html`<label class="${o.cls || ''}"><input type="radio" name="${f.n}" value="${o.v}" ${String(o.v) === String(v) ? 'checked' : ''}><span>${o.l}</span></label>`)}</div>`;
  if (f.type === 'check') return html`<label class="chk"><input type="checkbox" name="${f.n}" ${v ? 'checked' : ''}><span>${f.label}</span></label>`;
  if (f.type === 'file') return html`<div class="fld"><span>${f.label}</span><div class="filebox"><input id="${id}" type="file" name="${f.n}" accept="${f.accept || 'image/*'}"><div class="filepreview" data-prev="${f.n}">${f.prev || ''}</div></div></div>`;
  let inner;
  if (f.type === 'select') inner = html`<select id="${id}" name="${f.n}" ${req}>${f.opts.map(o => html`<option value="${o.v}" ${String(o.v) === String(v) ? 'selected' : ''}>${o.l}</option>`)}</select>`;
  else if (f.type === 'textarea') inner = html`<textarea id="${id}" name="${f.n}" rows="${f.rows || 4}" placeholder="${f.ph || ''}" ${req}>${v}</textarea>`;
  else {
    const type = f.type === 'amount' ? 'text' : (f.type || 'text');
    inner = html`<input id="${id}" name="${f.n}" type="${type}" value="${v}" placeholder="${f.ph || ''}" ${req} ${f.type === 'amount' ? raw('inputmode="decimal" autocomplete="off"') : ''} ${f.list ? raw(`list="${esc(f.list)}"`) : ''} ${f.max ? raw(`maxlength="${f.max}"`) : ''} ${f.type === 'color' ? '' : raw('')}>`;
  }
  return html`<label class="fld" for="${id}"><span>${f.label}</span>${inner}</label>`;
};

/**
 * formSheet({title, fields, submit, onSubmit(values, api), onDelete, extra, onMount})
 * values: amounts are integer paisa, checkboxes booleans, files are File objects.
 * onSubmit may return false or throw Error(msg) to keep the sheet open and show msg.
 */
export function formSheet({ title, fields, submit = t('save'), onSubmit, onDelete, deleteLabel = t('delete'), extra, onMount, full = false }) {
  const body = html`<form class="form" novalidate>${fields.map(fieldHtml)}${extra || ''}<p class="err" role="alert"></p>
    <div class="row gap"><button type="submit" class="btn primary grow">${submit}</button>${onDelete ? html`<button type="button" class="btn danger" data-del>${icon('trash')}<span>${deleteLabel}</span></button>` : ''}</div></form>`;
  return openSheet({ title, body, full, onMount: s => {
    const form = s.body.querySelector('form'), err = form.querySelector('.err'), btn = form.querySelector('[type=submit]');
    let busy = false;
    const read = () => {
      const v = {};
      for (const f of fields) {
        if (f.type === 'hint') continue;
        const els = form.elements[f.n];
        if (f.type === 'check') v[f.n] = els.checked;
        else if (f.type === 'seg') v[f.n] = form.querySelector(`[name="${f.n}"]:checked`)?.value;
        else if (f.type === 'file') v[f.n] = els.files[0] || null;
        else if (f.type === 'amount') { const raw = els.value.trim(); v[f.n] = raw === '' ? null : parseAmount(raw); }
        else v[f.n] = (els.value ?? '').trim();
      }
      return v;
    };
    form.addEventListener('submit', async e => {
      e.preventDefault(); if (busy) return; err.textContent = '';
      const v = read();
      for (const f of fields) {
        if (f.type === 'hint' || f.type === 'check' || f.type === 'file') continue;
        if (f.type === 'amount') {
          if (v[f.n] === null) { if (f.req) { err.textContent = t('err_amount'); return; } continue; }
          if (Number.isNaN(v[f.n]) || v[f.n] < 0 || (f.req && v[f.n] <= 0 && !f.allowZero)) { err.textContent = t('err_amount'); return; }
        } else if (f.req && !v[f.n]) { err.textContent = t('err_required', { f: f.label }); return; }
      }
      busy = true; btn.disabled = true;
      try { const r = await onSubmit(v, { close: () => s.close(), form, sheet: s }); if (r === false) { busy = false; btn.disabled = false; } else s.close(); }
      catch (ex) { err.textContent = ex.message || String(ex); busy = false; btn.disabled = false; }
    });
    form.querySelector('[data-del]')?.addEventListener('click', async () => { if (await onDelete(s)) s.close(); });
    form.addEventListener('change', e => { const f = fields.find(x => x.n === e.target.name); f?.onChange?.(e.target.value, { form, read }); });
    onMount?.({ form, sheet: s, read });
    form.querySelector('input:not([type=radio]):not([type=checkbox]):not([type=file]),textarea')?.focus({ preventScroll: true });
  } });
}
export { toEnDigits };
