// Pure financial calculations. Nothing here touches storage or the DOM.
// All amounts are integer paisa. Totals are ALWAYS derived from records, never stored.
import { addDays, addMonths, parseYmd, pad } from './util.js';

/** Balance of one account. Inputs are record lists ({id, deleted, payload}); deleted ones are ignored. */
export function accountBalance(acc, { txns = [], transfers = [], duePayments = [], dues = [] }) {
  const id = acc.id;
  let b = acc.payload.openingBalance || 0;
  for (const t of txns) {
    if (t.deleted || t.payload.accountId !== id) continue;
    b += t.payload.kind === 'income' ? t.payload.amount : -t.payload.amount;
  }
  for (const t of transfers) {
    if (t.deleted) continue;
    if (t.payload.fromId === id) b -= t.payload.amount;
    if (t.payload.toId === id) b += t.payload.toAmount ?? t.payload.amount;
  }
  const dueById = new Map(dues.map(d => [d.id, d]));
  for (const p of duePayments) {
    if (p.deleted || p.payload.accountId !== id) continue;
    const d = dueById.get(p.payload.dueId); if (!d || d.deleted) continue;
    b += d.payload.kind === 'receivable' ? p.payload.amount : -p.payload.amount;
  }
  return b;
}

export function summarize(txns) {
  let income = 0, expense = 0;
  for (const t of txns) {
    if (t.deleted) continue;
    if (t.payload.kind === 'income') income += t.payload.amount; else expense += t.payload.amount;
  }
  return { income, expense, balance: income - expense };
}

export function inPeriod(dateStr, period, monthKey, today) {
  if (period === 'all') return true;
  if (period === 'today') return dateStr === today;
  return dateStr.slice(0, 7) === monthKey;
}

export function dueStatus(due, payments) {
  const paid = payments.filter(p => !p.deleted && p.payload.dueId === due.id).reduce((s, p) => s + p.payload.amount, 0);
  const total = due.payload.total;
  return { paid, total, remaining: Math.max(0, total - paid), over: Math.max(0, paid - total), settled: paid >= total };
}

export function savingStatus(sv, entries) {
  let saved = 0;
  for (const e of entries) {
    if (e.deleted || e.payload.savingId !== sv.id) continue;
    saved += e.payload.kind === 'deposit' ? e.payload.amount : -e.payload.amount;
  }
  const target = sv.payload.target || 0;
  return { saved, target, pct: target > 0 ? Math.max(0, Math.min(100, Math.round(saved / target * 100))) : 0, reached: target > 0 && saved >= target };
}

/** Spent per category (expenses only) in a month, plus total. accountIds optional Set. */
export function monthSpend(txns, monthKey, accountIds) {
  const byCat = new Map(); let total = 0;
  for (const t of txns) {
    if (t.deleted || t.payload.kind !== 'expense' || t.payload.date.slice(0, 7) !== monthKey) continue;
    if (accountIds && !accountIds.has(t.payload.accountId)) continue;
    byCat.set(t.payload.categoryId, (byCat.get(t.payload.categoryId) || 0) + t.payload.amount);
    total += t.payload.amount;
  }
  return { byCat, total };
}

export function budgetRows(budgets, spend, monthKey) {
  const rows = [];
  for (const b of budgets) {
    if (b.deleted || b.payload.month !== monthKey) continue;
    const spent = b.payload.categoryId ? (spend.byCat.get(b.payload.categoryId) || 0) : spend.total;
    const amount = b.payload.amount;
    rows.push({ b, spent, amount, remaining: amount - spent, pct: amount > 0 ? Math.round(spent / amount * 100) : 0, over: spent > amount });
  }
  return rows.sort((a, b) => (a.b.payload.categoryId ? 1 : 0) - (b.b.payload.categoryId ? 1 : 0));
}

/** Occurrence dates for a recurring rule from its start up to `today` (inclusive), capped. */
export function occurrences(rule, today, cap = 400) {
  const out = []; const { startDate, endDate, freq } = rule;
  if (!startDate) return out;
  const startDay = parseYmd(startDate).getDate();
  for (let i = 0; out.length < cap; i++) {
    let d;
    if (freq === 'daily') d = addDays(startDate, i);
    else if (freq === 'weekly') d = addDays(startDate, i * 7);
    else if (freq === 'monthly' || freq === 'yearly') {
      const k = addMonths(startDate.slice(0, 7), freq === 'yearly' ? i * 12 : i);
      const [y, m] = k.split('-').map(Number);
      const last = new Date(y, m, 0).getDate(); // clamp: the 31st becomes the 30th/28th in short months
      d = `${k}-${pad(Math.min(startDay, last))}`;
    } else return out;
    if (d > today || (endDate && d > endDate)) break;
    out.push(d);
  }
  return out;
}

/** Deterministic id: two devices generating the same occurrence produce the SAME record id (no duplicates). */
export const recurringId = (ruleId, date) => `rec_${ruleId}_${date}`;
