# Income & Expense — PWA (Build 1, early working build)

Offline-first income/expense manager. Plain HTML + CSS + JavaScript, no build step, no framework.
Application ID for a future Play Store wrapper: `com.nextgenprime.incomeexpense`.

## What works in Build 1
Implemented **and tested** (Node unit tests + real headless-Chromium tests, see `tests/`):
- Income/expense records: add, edit, delete (trash + undo), validation, duplicate-tap protection
- Today / month / all summaries, balance, categories (add/edit/hide), search, category filter, privacy mode
- Bengali (default) / English, default currency selection (BDT ৳ default)
- IndexedDB storage, every record **AES-256-GCM encrypted** on the device; PIN lock (4–8 digits, PBKDF2) with auto-lock and attempt delay
- Fully offline: app reloads with no network, records added offline persist
- Automatic sync engine: pending queue, retry, no duplicates, two-device conflict handling, soft deletes, history kept (tested against a simulated cloud)
- Backup file export (optional password) and additive restore; conflicts kept for review
- Trash with restore; "Needs review" screen to resolve conflicting versions
- Installable PWA (manifest, service worker, shortcuts: Add expense / Add income)

Implemented but **NOT tested** (needs your Firebase project / a real phone): Firebase Auth (Google + email), the Firestore adapter (`js/cloud.js`), Firebase Storage receipt upload, receipt photo capture.

**Not built yet** (coming in following builds): account management & transfers/wallet screen, dues, tasks, budget, savings, notes, recurring entries, PDF reports, themes, biometric unlock, in-app reminders. The tab bar only shows screens that exist.

## Run locally
```
cd income-expense-pwa
python3 -m http.server 8080      # or any static server
```
Open http://localhost:8080 (service worker and encryption need https or localhost).

## Install on Android
Deploy to HTTPS (below), open the URL in Chrome on the phone → ⋮ menu → **Install app** (or use the Install row in the app's Menu).

## Firebase setup (all under YOUR account)
1. https://console.firebase.google.com → Add project (free Spark plan is enough for everything except receipt images in the cloud).
2. Build → Authentication → Get started → enable **Email/Password** and **Google**.
3. Build → Firestore Database → Create (production mode, pick a region near you).
4. Project settings → Your apps → Web (`</>`) → copy the config into `js/config.js`.
5. Authentication → Settings → Authorized domains: add the domain you host on.
6. Deploy rules + hosting: `npm i -g firebase-tools && firebase login && firebase use --add && firebase deploy --only firestore:rules,hosting`
7. Receipts in the cloud (optional): Firebase **Storage requires the paid Blaze plan**. Nothing in this app enables it. If you choose to upgrade yourself, set a budget alert, run `firebase deploy --only storage`, then switch on "Store receipt images in the cloud" in Menu → Cloud sync. Until then receipts stay encrypted on the phone only.

## Honest limits
- Sync runs while the app is open and when it is reopened. Browsers do not allow a closed PWA to sync reliably; Background Sync is not used.
- Local encryption stops casual access to the stored data. A 4-digit PIN can be brute-forced by someone who copies the phone's browser storage; use 6–8 digits. With no PIN the key sits on the device.
- The cloud copy relies on Firebase's encryption at rest and your security rules (not end-to-end encrypted).
- Firestore rules in `firebase/` have not been run against the Firebase emulator here; test them in your project.
