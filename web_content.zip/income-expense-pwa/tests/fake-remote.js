// Fake Firestore for tests. Uses the real decidePush rule. `net` can be switched off to simulate offline.
import { decidePush, same } from '../js/sync-core.js';
export function createFakeCloud() {
  const docs = new Map(), versions = [];
  let tick = 0;
  return {
    docs, versions,
    client(uid = 'u1', net = { up: true }) {
      const need = () => { if (!net.up) { const e = new Error('offline'); e.code = 'unavailable'; throw e; } };
      return {
        net, uid: () => uid,
        async push(rec) {
          need();
          const server = docs.get(rec.id);
          const d = decidePush(server, rec);
          if (d === 'conflict') return { conflict: true, server: structuredClone(server) };
          if (d === 'already') return { ok: true, rev: server.rev };
          const doc = { ...structuredClone(rec), rev: rec.rev + 1, srv: ++tick };
          docs.set(rec.id, doc); versions.push(structuredClone(doc));
          return { ok: true, rev: doc.rev };
        },
        async pull(cursor) {
          need();
          const records = [...docs.values()].filter(d => d.srv >= cursor).map(d => structuredClone(d));
          return { records, cursor: Math.max(cursor, ...records.map(r => r.srv), 0), more: false };
        },
        canUploadFiles: () => false,
      };
    },
  };
}
