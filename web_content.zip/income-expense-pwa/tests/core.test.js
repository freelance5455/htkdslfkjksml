import assert from 'node:assert/strict';
import { memoryBackend } from '../js/db.js';
import { createStore } from '../js/store.js';
import { createSync } from '../js/sync.js';
import { createFakeCloud } from './fake-remote.js';
import { accountBalance, summarize, dueStatus, savingStatus, monthSpend, budgetRows, occurrences, recurringId } from '../js/calc.js';
import { parseAmount, money } from '../js/util.js';
import { passwordEncrypt, passwordDecrypt } from '../js/crypto.js';

let pass = 0, fail = 0;
const test = async (name, fn) => { try { await fn(); pass++; console.log('  ok  ', name); } catch (e) { fail++; console.log('  FAIL', name, '\n      ', e.stack.split('\n').slice(0, 3).join('\n       ')); } };
const mk = async () => { const s = createStore(memoryBackend()); await s.init(); return s; };
const mkSync = (store, cloud, net, uid = 'u1') => createSync({ store, remote: cloud.client(uid, net), online: () => net.up });

console.log('money & parsing');
await test('parseAmount handles Bengali digits, commas, decimals', () => {
  assert.equal(parseAmount('১,২৩৪.৫০'), 123450); assert.equal(parseAmount('0.1'), 10); assert.equal(parseAmount('10.999'), NaN);
  assert.equal(parseAmount(''), NaN); assert.equal(parseAmount('abc'), NaN); assert.equal(parseAmount('19.99'), 1999);
});
await test('money formats BDT, Bengali digits, privacy', () => {
  assert.equal(money(123456, { lang: 'en' }), '৳1,234.56'); assert.equal(money(-5000, { lang: 'bn' }), '−৳৫০'); assert.equal(money(5, { privacy: true }), '৳••••');
});

console.log('calculations');
const R = (id, payload, extra = {}) => ({ id, deleted: false, payload, ...extra });
await test('account balance: opening + income - expense + transfers + due payments, deleted ignored', () => {
  const a = R('a', { openingBalance: 100000 }), b = R('b', { openingBalance: 0 });
  const txns = [R('1', { accountId: 'a', kind: 'income', amount: 50000 }), R('2', { accountId: 'a', kind: 'expense', amount: 20000 }), R('3', { accountId: 'a', kind: 'expense', amount: 999 }, { deleted: true })];
  const transfers = [R('t', { fromId: 'a', toId: 'b', amount: 30000 })];
  const dues = [R('d1', { kind: 'receivable', total: 10000 }), R('d2', { kind: 'payable', total: 7000 })];
  const duePayments = [R('p1', { dueId: 'd1', amount: 4000, accountId: 'a' }), R('p2', { dueId: 'd2', amount: 2500, accountId: 'a' })];
  const all = { txns, transfers, duePayments, dues };
  assert.equal(accountBalance(a, all), 100000 + 50000 - 20000 - 30000 + 4000 - 2500);
  assert.equal(accountBalance(b, all), 30000);
  assert.equal(accountBalance(a, all) + accountBalance(b, all), 100000 + 50000 - 20000 + 4000 - 2500); // transfers never change the total
});
await test('transfer between currencies uses toAmount', () => {
  const b = R('b', { openingBalance: 0 });
  assert.equal(accountBalance(b, { transfers: [R('t', { fromId: 'a', toId: 'b', amount: 10000, toAmount: 900 })] }), 900);
});
await test('summaries, dues, savings, budgets', () => {
  const t = [R('1', { kind: 'income', amount: 1000 }), R('2', { kind: 'expense', amount: 400 }), R('3', { kind: 'expense', amount: 50 }, { deleted: true })];
  assert.deepEqual(summarize(t), { income: 1000, expense: 400, balance: 600 });
  const d = R('d', { total: 1000 }), pay = [R('p1', { dueId: 'd', amount: 300 }), R('p2', { dueId: 'd', amount: 200 }, { deleted: true }), R('p3', { dueId: 'x', amount: 999 })];
  assert.deepEqual(dueStatus(d, pay), { paid: 300, total: 1000, remaining: 700, over: 0, settled: false });
  assert.equal(dueStatus(d, [R('p', { dueId: 'd', amount: 1200 })]).over, 200);
  const sv = R('s', { target: 1000 }), ent = [R('e1', { savingId: 's', kind: 'deposit', amount: 800 }), R('e2', { savingId: 's', kind: 'withdraw', amount: 300 })];
  assert.deepEqual(savingStatus(sv, ent), { saved: 500, target: 1000, pct: 50, reached: false });
  const tx = [R('1', { kind: 'expense', amount: 300, categoryId: 'c1', date: '2026-11-03', accountId: 'a' }), R('2', { kind: 'expense', amount: 200, categoryId: 'c2', date: '2026-11-04', accountId: 'a' }), R('3', { kind: 'expense', amount: 999, categoryId: 'c1', date: '2026-10-04', accountId: 'a' })];
  const sp = monthSpend(tx, '2026-11');
  const rows = budgetRows([R('b1', { month: '2026-11', categoryId: null, amount: 400 }), R('b2', { month: '2026-11', categoryId: 'c1', amount: 250 })], sp, '2026-11');
  assert.equal(rows[0].spent, 500); assert.equal(rows[0].over, true); assert.equal(rows[1].spent, 300); assert.equal(rows[1].remaining, -50);
});
await test('recurring occurrences: monthly clamps to month end; ids are deterministic', () => {
  assert.deepEqual(occurrences({ freq: 'monthly', startDate: '2026-01-31' }, '2026-04-30'), ['2026-01-31', '2026-02-28', '2026-03-31', '2026-04-30']);
  assert.equal(occurrences({ freq: 'daily', startDate: '2026-11-01' }, '2026-11-07').length, 7);
  assert.equal(occurrences({ freq: 'weekly', startDate: '2026-11-01', endDate: '2026-11-10' }, '2026-12-01').length, 2);
  assert.equal(recurringId('r1', '2026-11-01'), recurringId('r1', '2026-11-01'));
});

console.log('store & encryption');
await test('save/edit/delete/restore and history kept', async () => {
  const s = await mk(); const r = await s.save('txn', { amount: 100 });
  await s.patch(r.id, p => ({ ...p, amount: 200 })); await s.remove(r.id);
  assert.equal(s.list('txn').length, 0); assert.equal(s.list('txn', { deleted: true }).length, 1);
  await s.restore(r.id); assert.equal(s.get(r.id).payload.amount, 200);
  const h = await s.history(r.id); assert.ok(h.length >= 3); assert.ok(h.some(v => v.payload.amount === 100));
});
await test('data on disk is encrypted and survives restart; PIN set/verify/lock/unlock', async () => {
  const be = memoryBackend(); const s = createStore(be); await s.init();
  await s.save('txn', { amount: 12345, note: 'SECRETNOTE' });
  const raw = JSON.stringify(await be.getAll('records'), (k, v) => v instanceof Uint8Array ? Array.from(v) : v instanceof ArrayBuffer ? Array.from(new Uint8Array(v)) : v);
  assert.ok(!raw.includes('SECRETNOTE') && !raw.includes('12345'));
  await s.setPin('4821'); s.lock(); assert.equal(s.list('txn').length, 0);
  assert.equal(await s.unlockPin('0000'), false); assert.equal(await s.unlockPin('4821'), true); assert.equal(s.list('txn')[0].payload.note, 'SECRETNOTE');
  const s2 = createStore(be); assert.equal((await s2.init()).locked, true); assert.equal(await s2.unlockPin('4821'), true); assert.equal(s2.list('txn').length, 1);
  assert.equal(await s2.changePin('4821', '999999'), true); s2.lock(); assert.equal(await s2.unlockPin('4821'), false); assert.equal(await s2.unlockPin('999999'), true);
  assert.equal(await s2.removePin('000000'), false); assert.equal(await s2.removePin('999999'), true);
  const s3 = createStore(be); assert.equal((await s3.init()).locked, false); assert.equal(s3.list('txn').length, 1);
});
await test('backup export/import: additive, conflicting ids kept as conflicts, nothing deleted', async () => {
  const a = await mk(); const r = await a.save('txn', { amount: 1 }); await a.save('note', { title: 'n' });
  const data = await a.exportAll();
  const b = await mk(); const res = await b.importAll(JSON.parse(JSON.stringify(data)));
  assert.equal(res.added, 2); assert.equal(b.list('txn').length, 1);
  await b.patch(r.id, p => ({ ...p, amount: 2 }));
  const res2 = await b.importAll(data); assert.equal(res2.conflicted, 1); assert.equal(b.get(r.id).payload.amount, 2); assert.equal(b.conflictList().length, 1);
  await b.resolveConflict(r.id, 0, true); assert.equal(b.get(r.id).payload.amount, 1); assert.equal(b.conflictList().length, 0);
  await assert.rejects(() => b.importAll({ nope: 1 }));
});
await test('password-protected backup text round trip', async () => {
  const t = await passwordEncrypt('hello ৳', 'pw'); assert.equal(await passwordDecrypt(t, 'pw'), 'hello ৳'); await assert.rejects(() => passwordDecrypt(t, 'bad'));
});

console.log('sync: offline, two devices, conflicts');
await test('offline edits are kept and upload automatically when the network returns', async () => {
  const cloud = createFakeCloud(), net = { up: false }; const s = await mk(); const sy = mkSync(s, cloud, net);
  const r = await s.save('txn', { amount: 500 }); await sy.run();
  assert.equal(sy.state.status, 'offline'); assert.equal(cloud.docs.size, 0); assert.equal(s.pending().length, 1);
  net.up = true; await sy.run(); assert.equal(sy.state.status, 'synced'); assert.equal(cloud.docs.get(r.id).rev, 1); assert.equal(s.pending().length, 0);
});
await test('network drops mid-sync: nothing lost, retry creates no duplicates', async () => {
  const cloud = createFakeCloud(), net = { up: true }; const s = await mk(); const sy = mkSync(s, cloud, net);
  const a = await s.save('txn', { amount: 1 }); const b = await s.save('txn', { amount: 2 });
  const c = cloud.client('u1', net), origPush = c.push; let n = 0;
  const sy2 = createSync({ store: s, remote: { ...c, push: async rec => { if (++n === 2) { net.up = false; } return origPush(rec); } }, online: () => net.up });
  await sy2.run(); net.up = true; await sy.run();
  assert.equal(cloud.docs.size, 2); assert.equal(s.pending().length, 0); assert.equal(cloud.docs.get(a.id).rev, 1);
});
await test('lost reply: push applied in cloud but device never heard -> detected as already applied', async () => {
  const cloud = createFakeCloud(), net = { up: true }; const s = await mk(); const r = await s.save('txn', { amount: 9 });
  const c = cloud.client('u1', net); await c.push({ id: r.id, type: 'txn', rev: 0, deleted: false, payload: r.payload, updatedAt: r.updatedAt, deviceId: r.deviceId });
  await mkSync(s, cloud, net).run(); assert.equal(cloud.docs.get(r.id).rev, 1); assert.equal(s.pending().length, 0); assert.equal(s.conflictList().length, 0);
});
await test('two devices add different records offline -> both end up with both', async () => {
  const cloud = createFakeCloud(), n1 = { up: true }, n2 = { up: true }; const A = await mk(), B = await mk(); const sa = mkSync(A, cloud, n1), sb = mkSync(B, cloud, n2);
  await A.save('txn', { amount: 100 }); await B.save('txn', { amount: 200 }); await sa.run(); await sb.run(); await sa.run();
  assert.equal(A.list('txn').length, 2); assert.equal(B.list('txn').length, 2);
});
await test('append-only payments from two devices merge; remaining balance is correct', async () => {
  const cloud = createFakeCloud(), n1 = { up: true }, n2 = { up: true }; const A = await mk(), B = await mk(); const sa = mkSync(A, cloud, n1), sb = mkSync(B, cloud, n2);
  const due = await A.save('due', { kind: 'receivable', total: 10000 }); await sa.run(); await sb.run();
  await A.save('duePayment', { dueId: due.id, amount: 3000 }); await B.save('duePayment', { dueId: due.id, amount: 2000 });
  await sa.run(); await sb.run(); await sa.run();
  for (const S of [A, B]) assert.equal(dueStatus(S.get(due.id), S.list('duePayment')).remaining, 5000);
});
await test('same record edited on both devices -> cloud wins as current, other version KEPT as conflict, resolvable', async () => {
  const cloud = createFakeCloud(), n1 = { up: true }, n2 = { up: true }; const A = await mk(), B = await mk(); const sa = mkSync(A, cloud, n1), sb = mkSync(B, cloud, n2);
  const r = await A.save('txn', { amount: 100 }); await sa.run(); await sb.run();
  n2.up = false; await A.patch(r.id, p => ({ ...p, amount: 111 })); await B.patch(r.id, p => ({ ...p, amount: 222 }));
  await sa.run(); n2.up = true; await sb.run(); await sa.run();
  assert.equal(B.get(r.id).payload.amount, 111); const cs = B.conflictList(); assert.equal(cs.length, 1); assert.equal(cs[0].others[0].payload.amount, 222);
  assert.equal(B.pending().length, 0);
  await B.resolveConflict(r.id, 0, true); await sb.run(); await sa.run(); assert.equal(A.get(r.id).payload.amount, 222); assert.equal(cloud.docs.get(r.id).rev, 3);
  assert.ok(cloud.versions.filter(v => v.id === r.id).some(v => v.payload.amount === 111), 'cloud keeps every revision');
});
await test('delete on one device vs edit on another -> edit wins, record not lost', async () => {
  const cloud = createFakeCloud(), n1 = { up: true }, n2 = { up: true }; const A = await mk(), B = await mk(); const sa = mkSync(A, cloud, n1), sb = mkSync(B, cloud, n2);
  const r = await A.save('txn', { amount: 100 }); await sa.run(); await sb.run();
  n2.up = false; await A.remove(r.id); await B.patch(r.id, p => ({ ...p, amount: 150 }));
  await sa.run(); n2.up = true; await sb.run(); await sa.run();
  assert.equal(B.get(r.id).deleted, false); assert.equal(B.get(r.id).payload.amount, 150); assert.equal(A.get(r.id).deleted, false); assert.equal(A.get(r.id).payload.amount, 150);
});
await test('edit here vs delete elsewhere (other order) -> revived with the edit', async () => {
  const cloud = createFakeCloud(), n1 = { up: true }, n2 = { up: true }; const A = await mk(), B = await mk(); const sa = mkSync(A, cloud, n1), sb = mkSync(B, cloud, n2);
  const r = await A.save('txn', { amount: 100 }); await sa.run(); await sb.run();
  n1.up = false; await A.remove(r.id); await B.patch(r.id, p => ({ ...p, amount: 150 })); await sb.run(); // B (edit) synced first
  n1.up = true; await sa.run(); await sb.run();
  assert.equal(A.get(r.id).deleted, false); assert.equal(A.get(r.id).payload.amount, 150);
});
await test('delete/restore syncs as a tombstone, never a hard delete', async () => {
  const cloud = createFakeCloud(), n = { up: true }; const A = await mk(), B = await mk(); const sa = mkSync(A, cloud, n), sb = mkSync(B, cloud, n);
  const r = await A.save('txn', { amount: 5 }); await sa.run(); await sb.run(); await A.remove(r.id); await sa.run(); await sb.run();
  assert.equal(B.list('txn').length, 0); assert.equal(B.list('txn', { deleted: true }).length, 1); assert.ok(cloud.docs.has(r.id));
  await B.restore(r.id); await sb.run(); await sa.run(); assert.equal(A.list('txn').length, 1);
});
await test('default seed data created on two devices does not create conflicts', async () => {
  const cloud = createFakeCloud(), n = { up: true }; const A = await mk(), B = await mk();
  await A.save('category', { name: 'Food', seed: true }, 'cat_food'); await B.save('category', { name: 'খাবার', seed: true }, 'cat_food');
  const sa = mkSync(A, cloud, n), sb = mkSync(B, cloud, n); await sa.run(); await sb.run(); await sa.run();
  assert.equal(B.conflictList().length, 0); assert.equal(B.list('category').length, 1);
});
await test('edit while a push is in flight stays pending (no lost edit)', async () => {
  const cloud = createFakeCloud(), n = { up: true }; const s = await mk(); const r = await s.save('txn', { amount: 1 });
  const c = cloud.client('u1', n); let once = false; const slow = { ...c, push: async rec => { const out = await c.push(rec); if (!once) { once = true; await s.patch(r.id, p => ({ ...p, amount: 2 })); } return out; } };
  await createSync({ store: s, remote: slow, online: () => true }).run();
  // the edit made during the push is not marked synced, so the same run sends it as a second revision
  assert.equal(s.get(r.id).payload.amount, 2); assert.equal(cloud.docs.get(r.id).payload.amount, 2); assert.equal(cloud.docs.get(r.id).rev, 2); assert.equal(s.pending().length, 0);
  assert.ok(cloud.versions.some(v => v.id === r.id && v.payload.amount === 1), 'first revision kept in cloud history');
});

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
