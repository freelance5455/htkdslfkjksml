import sys, json, time, subprocess, os, re
from playwright.sync_api import sync_playwright, expect
PORT = 8765
srv = subprocess.Popen([sys.executable, '-m', 'http.server', str(PORT), '--bind', '127.0.0.1'], cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(0.8)
URL = f'http://127.0.0.1:{PORT}/index.html'
passed = failed = 0
def check(name, cond, extra=''):
    global passed, failed
    if cond: passed += 1; print('  ok  ', name)
    else: failed += 1; print('  FAIL', name, extra)

FAKE_CLOUD = """
(() => {
  const srv = JSON.parse(localStorage.getItem('__srv') || '{}'); let tick = Date.now();
  const save = () => localStorage.setItem('__srv', JSON.stringify(srv));
  window.__testCloud = { available: true, init: async () => {}, uid: () => 'u1', email: () => 't@x.com', onAuth: cb => { setTimeout(() => cb({ uid: 'u1' }), 50); return () => {}; },
    setStorageEnabled() {}, canUploadFiles: () => false, signOut: async () => {},
    async push(r) { const s = srv[r.id];
      if (s && !(s.rev === r.rev) && !(s.rev === r.rev + 1 && JSON.stringify(s.payload) === JSON.stringify(r.payload) && !!s.deleted === !!r.deleted)) return { conflict: true, server: s };
      if (s && s.rev === r.rev + 1) return { ok: true, rev: s.rev };
      srv[r.id] = { ...r, rev: r.rev + 1, srv: ++tick }; save(); return { ok: true, rev: r.rev + 1 }; },
    async pull(c) { const recs = Object.values(srv).filter(d => d.srv >= c); return { records: recs, cursor: recs.reduce((m, d) => Math.max(m, d.srv), c), more: false }; } };
})();
"""

try:
  with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={'width': 390, 'height': 800}, locale='bn-BD', accept_downloads=True)
    ctx.add_init_script(FAKE_CLOUD)
    page = ctx.new_page(); errors = []
    page.on('pageerror', lambda e: errors.append(str(e))); page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    page.goto(URL); page.wait_for_selector('.summary')
    check('app boots and shows Home (Bengali default)', 'আয়' in page.inner_text('.summary') and 'অবশিষ্ট' in page.inner_text('.summary'))
    page.screenshot(path='/tmp/s1_home.png')

    # add expense
    page.click('.fab'); page.wait_for_selector('.sheet form')
    page.fill('[name=amount]', '২৫০.৫০'); page.fill('[name=note]', 'চাল ডাল')
    page.select_option('[name=categoryId]', 'cat_food'); page.click('.sheet button[type=submit]')
    page.wait_for_selector('.item.tx'); txt = page.inner_text('.summary')
    check('expense saved and total shows ৳২৫০.৫০', '২৫০.৫০' in txt, txt)
    # add income
    page.click('.fab'); page.wait_for_selector('.sheet form'); page.click('.seg .inc span'); page.fill('[name=amount]', '1000'); page.click('.sheet button[type=submit]')
    page.wait_for_function("document.querySelectorAll('.item.tx').length==2")
    txt = page.inner_text('.summary')
    check('income + balance calculated (১,০০০ / ৭৪৯.৫০)', '১,০০০' in txt and '৭৪৯.৫০' in txt, txt)
    page.screenshot(path='/tmp/s2_list.png')

    # validation + duplicate prevention
    page.click('.fab'); page.wait_for_selector('.sheet form'); page.click('.sheet button[type=submit]')
    check('empty amount rejected', page.inner_text('.sheet .err') != '' and page.locator('.item.tx').count() == 2)
    page.fill('[name=amount]', '12abc'); page.click('.sheet button[type=submit]')
    check('invalid amount rejected', page.locator('.item.tx').count() == 2)
    page.fill('[name=amount]', '5'); page.dblclick('.sheet button[type=submit]'); page.wait_for_timeout(500)
    check('double-tap creates only ONE record', page.locator('.item.tx').count() == 3)

    # edit + delete + undo
    page.click('.item.tx >> nth=0'); page.wait_for_selector('.sheet form'); page.fill('[name=amount]', '7'); page.click('.sheet button[type=submit]'); page.wait_for_timeout(300)
    check('edit works', '৭' in page.inner_text('#txlist'))
    page.click('.item.tx >> nth=0'); page.wait_for_selector('[data-del]'); page.click('[data-del]'); page.wait_for_timeout(300)
    check('delete removes from list', page.locator('.item.tx').count() == 2)
    page.click('.toast .link'); page.wait_for_timeout(300)
    check('undo restores', page.locator('.item.tx').count() == 3)

    # category add
    page.click('[data-act=cat-manage]'); page.wait_for_selector('[data-newcat]'); page.click('.sheet [data-newcat]'); page.fill('.sheet >> nth=1 >> [name=name]', 'ঈদ'); page.click('.sheet >> nth=1 >> button[type=submit]'); page.wait_for_timeout(300)
    check('new category created', 'ঈদ' in page.inner_text('#sheets')); page.keyboard.press('Escape'); page.click('#sheets .sheet >> [data-sheet-close]') if page.locator('#sheets .sheet').count() else None
    page.wait_for_timeout(300)

    # sync (fake cloud): pending drains, server received records
    page.wait_for_function("window.__ie && window.__ie.store.pending().length===0", timeout=8000)
    n = page.evaluate("Object.keys(JSON.parse(localStorage.getItem('__srv')||'{}')).length")
    check('auto-sync pushed all records to cloud with no button', n >= 10, n)
    check('sync status is synced', page.evaluate("window.__ie.S.syncInfo.status") == 'synced')

    # English + menu
    page.click('[data-act=tab][data-t=menu]'); page.wait_for_selector('.menu'); page.click('label:has-text("English")'); page.wait_for_timeout(400)
    check('language switches to English', 'Cloud sync' in page.inner_text('.menu'))
    page.screenshot(path='/tmp/s3_menu.png')

    # PIN
    page.click('[data-act=go-security]'); page.click('[data-act=pin-set]'); page.fill('[name=p1]', '4821'); page.fill('[name=p2]', '4821'); page.click('.sheet button[type=submit]'); page.wait_for_timeout(1500)
    check('PIN set', page.evaluate("window.__ie.store.hasPin()"))
    page.reload(); page.wait_for_selector('#pinform')
    check('locked on reload; data not visible', page.locator('.summary').count() == 0)
    page.fill('#pin', '0000'); page.click('#pinform button'); page.wait_for_timeout(1200)
    check('wrong PIN rejected', page.locator('#pinform').count() == 1 and 'Wrong PIN' in page.inner_text('#lock'))
    page.fill('#pin', '4821'); page.click('#pinform button'); page.wait_for_selector('.bar', timeout=8000); page.evaluate("location.hash='#/home'"); page.wait_for_selector('.summary')
    check('correct PIN unlocks, data intact', page.locator('.item.tx').count() == 3)
    raw = page.evaluate("""async () => { const db = await new Promise(r => { const q = indexedDB.open('income-expense'); q.onsuccess = () => r(q.result); });
      const rows = await new Promise(r => { const q = db.transaction('records').objectStore('records').getAll(); q.onsuccess = () => r(q.result); }); return JSON.stringify(rows, (k, v) => v instanceof Uint8Array ? [...v] : v instanceof ArrayBuffer ? [...new Uint8Array(v)] : v); }""")
    check('IndexedDB holds only ciphertext (no amounts/notes in clear)', 'চাল ডাল' not in raw and 'enc' in raw)
    page.screenshot(path='/tmp/s4_after_unlock.png')

    # offline: service worker caches the app; add data with no network; reload offline
    page.wait_for_function("navigator.serviceWorker.controller !== null || true"); page.wait_for_timeout(1500)
    ctx.set_offline(True)
    page.click('.fab'); page.wait_for_selector('.sheet form'); page.fill('[name=amount]', '33'); page.fill('[name=note]', 'offline-note'); page.click('.sheet button[type=submit]'); page.wait_for_timeout(500)
    check('can add a record while offline', 'offline-note' in page.inner_text('#txlist'))
    page.reload(); page.wait_for_selector('#pinform', timeout=8000); page.fill('#pin', '4821'); page.click('#pinform button'); page.wait_for_selector('.bar', timeout=8000); page.evaluate("location.hash='#/home'"); page.wait_for_selector('.summary')
    check('app reloads OFFLINE and offline record persisted', 'offline-note' in page.inner_text('#txlist'))
    check('record is still pending (not lost) while offline', page.evaluate("window.__ie.store.pending().length") >= 1)
    ctx.set_offline(False); page.evaluate("window.dispatchEvent(new Event('online'))")
    page.wait_for_function("window.__ie.store.pending().length===0", timeout=10000)
    check('automatic sync after network returns', True)

    # backup export + wipe + restore
    page.click('[data-act=tab][data-t=menu]'); page.click('[data-act=go-backup]'); page.click('[data-act=backup-export]'); page.wait_for_selector('.sheet form')
    with page.expect_download() as dl: page.click('.sheet button[type=submit]')
    path = dl.value.path(); data = json.load(open(path))
    check('backup file contains all records', data['format'] == 'income-expense-backup' and len([r for r in data['records'] if r['type'] == 'txn']) == 4, len(data['records']))
    page.evaluate("window.__ie.store.save('txn', {kind:'expense',amount:1,accountId:'acc_personal',categoryId:null,date:'2026-01-01',time:'10:00',note:'x',attachmentId:null}, 'zzz')")
    page.screenshot(path='/tmp/s5_backup.png')
    check('no JS errors', not [e for e in errors if 'favicon' not in e and 'gstatic' not in e and 'ERR_' not in e], errors)
    b.close()
finally:
  srv.terminate()
print(f'\n{passed} passed, {failed} failed'); sys.exit(1 if failed else 0)
