FT GESTIÓN — PAQUETE ANDROID (PWA)

Este paquete está preparado como aplicación web instalable (PWA).
1. Subí esta carpeta a un hosting con HTTPS.
2. Abrí la dirección desde Chrome en Android.
3. Elegí “Instalar aplicación” o “Agregar a pantalla de inicio”.
4. Quedará el ícono FT y abrirá en modo aplicación.

IMPORTANTE:
- No es un APK nativo; es una PWA instalable.
- Los datos de FT Gestión se guardan localmente en el dispositivo mediante almacenamiento del navegador.
- Para sincronizar datos entre varios teléfonos habría que agregar una base de datos en la nube.
