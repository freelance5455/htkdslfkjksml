package com.example.taxinvoice;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final int REQ_CREATE_PDF = 7001;
    private WebView web;
    private boolean pageReady = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            s.setSafeBrowsingEnabled(false);
        }
        s.setBuiltInZoomControls(false);
        web.setBackgroundColor(Color.WHITE);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                view.postDelayed(() -> view.measure(
                        android.view.View.MeasureSpec.makeMeasureSpec(dp(595), android.view.View.MeasureSpec.EXACTLY),
                        android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED)), 200);
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocusFromTouch();
        web.addJavascriptInterface(new AndroidPrintBridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private PrintAttributes a4Attributes() {
        return new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(new PrintAttributes.Resolution("invoice", "Invoice", 300, 300))
                .setMinMargins(new PrintAttributes.Margins(0,0,0,0))
                .build();
    }

    private void startPrint() {
        web.requestFocusFromTouch();
        if (!pageReady) { toast("Invoice load ho raha hai, thoda ruk kar dobara dabayein."); return; }
        try {
            PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
            pm.print("Tax Invoice A4", new InvoicePrintAdapter(), a4Attributes());
        } catch (Exception e) { toast("Print start nahi hua: " + e.getMessage()); }
    }

    private void choosePdfFile() {
        web.requestFocusFromTouch();
        if (!pageReady) { toast("Invoice load ho raha hai, thoda ruk kar dobara dabayein."); return; }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_TITLE, "Tax_Invoice_A4.pdf");
        startActivityForResult(i, REQ_CREATE_PDF);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CREATE_PDF && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(data.getData(), "w")) {
                if (pfd == null) throw new IOException("File open failed");
                writePdf(pfd);
                toast("A4 PDF save ho gaya.");
            } catch (Exception e) { toast("PDF save nahi hua: " + e.getMessage()); }
        }
    }

    private PdfDocument buildPdf() {
        final int W = 595, H = 842;
        PdfDocument doc = new PdfDocument();
        int contentW = W;
        web.measure(android.view.View.MeasureSpec.makeMeasureSpec(contentW, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED));
        int contentH = Math.max(H, web.getMeasuredHeight());
        web.layout(0,0,contentW,contentH);
        float scale = 1f;
        int pageCount = Math.max(1, (int)Math.ceil(contentH / (double)H));
        for (int p=0; p<pageCount; p++) {
            PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(W,H,p+1).create());
            Canvas c = page.getCanvas();
            c.drawColor(Color.WHITE);
            c.save();
            c.clipRect(0,0,W,H);
            c.translate(0, -p*H);
            web.draw(c);
            c.restore();
            doc.finishPage(page);
        }
        return doc;
    }

    private void writePdf(ParcelFileDescriptor pfd) throws IOException {
        PdfDocument doc = buildPdf();
        try (FileOutputStream out = new FileOutputStream(pfd.getFileDescriptor())) {
            doc.writeTo(out);
        } finally { doc.close(); }
    }

    private class InvoicePrintAdapter extends PrintDocumentAdapter {
        @Override public void onLayout(PrintAttributes oldAttrs, PrintAttributes newAttrs, CancellationSignal cancellationSignal,
                                       LayoutResultCallback callback, android.os.Bundle extras) {
            if (cancellationSignal != null && cancellationSignal.isCanceled()) { callback.onLayoutCancelled(); return; }
            int h = Math.max(842, web.getMeasuredHeight());
            int pages = Math.max(1, (int)Math.ceil(h / 842.0));
            callback.onLayoutFinished(new PrintDocumentInfo.Builder("Tax_Invoice_A4.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(pages).build(), true);
        }
        @Override public void onWrite(PageRange[] pages, ParcelFileDescriptor destination, CancellationSignal cancellationSignal,
                                      WriteResultCallback callback) {
            if (cancellationSignal != null && cancellationSignal.isCanceled()) { callback.onWriteCancelled(); return; }
            try {
                writePdf(destination);
                callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (Exception e) { callback.onWriteFailed(e.getMessage()); }
            finally { try { destination.close(); } catch (Exception ignored) {} }
        }
    }

    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }

    private class AndroidPrintBridge {
        @JavascriptInterface public void printInvoice() {
            handler.post(() -> {
                try { startPrint(); } catch (Exception e) { toast("Print error: " + e.getMessage()); }
            });
        }
        @JavascriptInterface public void savePdf() {
            handler.post(() -> {
                try { choosePdfFile(); } catch (Exception e) { toast("PDF error: " + e.getMessage()); }
            });
        }
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
