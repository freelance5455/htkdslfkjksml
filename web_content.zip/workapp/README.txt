Tax Invoice - Maharajganj (A4 Print/PDF fixed V4)

Fixed:
- Print A4 button uses Android native Print dialog when running in the Android app.
- Save A4 PDF button opens Android's Save/Create Document picker.
- Browser fallback uses the system print dialog so Chrome can choose Save as PDF.
- Buttons are explicit type=button and use JS event listeners for reliable touch/click handling.
- Added button busy state so the tap is visibly acknowledged.
- A4 portrait print CSS retained.
- Existing invoice fields and calculations retained.

Build the Android project with Android Studio/Gradle and install the generated APK.
