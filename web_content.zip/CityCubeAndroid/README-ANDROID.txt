پروژه Android Studio برای بازی شهر مکعبی.
فایل HTML فعلی داخل app/src/main/assets/city_cube_game.html است.
پروژه در حالت Landscape اجرا می‌شود و WebView، JavaScript و اینترنت را فعال می‌کند.
HTML فعلی از Three.js خارجی استفاده می‌کند، بنابراین برای اجرای آن اینترنت لازم است.
پروژه را در Android Studio باز کنید و Build > Generate App Bundles or APKs را انتخاب کنید.
برای حساب توسعه‌دهنده و انتشار، اگر زیر ۱۸ سال هستید از والد/سرپرست کمک بگیرید.
