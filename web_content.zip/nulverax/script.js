/* NULVÉRAX — motor do jogo. Não contém falas: edite roteiro.js. */
const $ = id => document.getElementById(id);
const el = { jogo:$('jogo'), img:$('imagem'), caixa:$('caixa'), falante:$('falante'),
  texto:$('texto'), seta:$('seta'), escolhas:$('escolhas'), fim:$('fim') };

let fila = [], passoAtual = null, cena = null, digitando = false, timer = null, travado = false;
const sons = {};

/* ---------- Áudio (arquivo ausente é ignorado) ---------- */
function som(cmd){
  if(!cmd) return;
  const id = cmd.toca || cmd.loop || cmd.para, cfg = SONS[id];
  if(!cfg) return;
  if(cmd.para){ sons[id] && sons[id].pause(); return; }
  try{
    const a = sons[id] || (sons[id] = new Audio(cfg.arquivo));
    a.loop = !!cmd.loop; a.volume = cfg.vol ?? 1; a.currentTime = 0;
    a.play().catch(()=>{});
  }catch(e){}
}

/* ---------- Efeitos visuais ---------- */
function fx(nome){
  if(!nome) return;
  const cls = nome === 'corte' ? 'fade' : nome;
  el.jogo.classList.remove(cls); void el.jogo.offsetWidth; el.jogo.classList.add(cls);
  setTimeout(()=>el.jogo.classList.remove(cls), 1200);
}

/* ---------- Imagem com fallback ---------- */
function mostrarImagem(c){
  const lista = [c.img, ...(c.alt||[])];
  el.img.classList.remove('preto');
  const tentar = i => {
    if(i >= lista.length){ el.img.classList.add('preto'); return; }
    el.img.onerror = () => tentar(i+1);
    el.img.src = lista[i];
  };
  tentar(0);
  fx('troca');
}

/* ---------- Cenas ---------- */
function irPara(id){
  cena = CENAS[id];
  el.escolhas.hidden = true;
  mostrarImagem(cena);
  som(cena.inicio); fx(cena.fx);
  fila = [...cena.passos];
  proximo();
}

function proximo(){
  if(travado) return;
  if(!fila.length) return fimDaCena();
  passoAtual = fila.shift();
  som(passoAtual.som); fx(passoAtual.fx);
  const pens = passoAtual.q === 'PENSAMENTO';
  el.falante.textContent = pens ? 'pensamento' : passoAtual.q;
  el.falante.className = pens ? 'pensamento' : '';
  el.texto.className = passoAtual.q === '' ? 'sistema' : '';
  digitar(passoAtual.t);
}

function digitar(t){
  clearInterval(timer); digitando = true; el.seta.classList.add('off'); el.texto.textContent = '';
  let i = 0;
  timer = setInterval(()=>{
    el.texto.textContent = t.slice(0, ++i);
    if(i >= t.length) concluir();
  }, 22);
}
function concluir(){ clearInterval(timer); digitando = false; el.texto.textContent = passoAtual.t; el.seta.classList.remove('off'); }

function fimDaCena(){
  if(cena.escolhas) return mostrarEscolhas(cena.escolhas);
  if(cena.proxima) return irPara(cena.proxima);
  encerrar(cena.fim);
}

function mostrarEscolhas(lista){
  travado = true; el.seta.classList.add('off'); el.escolhas.innerHTML = '';
  lista.forEach(op=>{
    const b = document.createElement('button'); b.textContent = op.rotulo;
    b.onclick = () => { travado = false; el.escolhas.hidden = true; fila = [...op.passos];
      cena = { ...cena, escolhas:null, proxima:op.vai }; proximo(); };
    el.escolhas.appendChild(b);
  });
  el.escolhas.hidden = false;
}

function encerrar(msg){
  travado = true; el.jogo.classList.add('fade');
  setTimeout(()=>{ Object.values(sons).forEach(a=>a.pause()); el.fim.textContent = msg || 'FIM'; el.fim.hidden = false; }, 700);
}

/* ---------- Entrada ---------- */
el.caixa.addEventListener('click', ()=> digitando ? concluir() : proximo());
document.addEventListener('keydown', e=>{
  if(['Enter',' '].includes(e.key) && !$('jogo').hidden && el.escolhas.hidden){ e.preventDefault(); digitando ? concluir() : proximo(); }
});
$('btnIniciar').onclick = () => { $('inicio').hidden = true; el.jogo.hidden = false; irPara(CENA_INICIAL); };
