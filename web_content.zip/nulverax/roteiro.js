/* =====================================================================
   NULVÉRAX — ROTEIRO (edite falas, imagens e sons AQUI; não mexa no script.js)
   ---------------------------------------------------------------------
   IMAGENS: pasta assets/img/. "img" é a imagem principal; "alt" são
   alternativas usadas se a principal ainda não existir (ex.: trocar pela
   versão com a mão assim que você adicionar o arquivo).
   Se nenhuma existir, a tela fica preta (útil p/ cenas ainda sem asset).
   SONS: pasta assets/audio/. Arquivo ausente = silêncio (sem erro).
   PASSOS ({ q, t, som, ... }):
     q   = quem fala ("" = narração/texto do jogo; "PENSAMENTO" = itálico)
     t   = texto
     som = { toca:"id" } | { loop:"id" } | { para:"id" }
     fx  = "tremor" | "corte"
===================================================================== */

const IMG = "assets/img/";
const SOM = "assets/audio/";

const SONS = {
  chiado:   { arquivo: SOM + "chiado.mp3",     vol: 0.5 },
  tragada:  { arquivo: SOM + "tragada.mp3",    vol: 0.8 },
  fumaca:   { arquivo: SOM + "fumaca.mp3",     vol: 0.8 },
  porta:    { arquivo: SOM + "porta_bate.mp3", vol: 1.0 },
  ruido:    { arquivo: SOM + "ruido.mp3",      vol: 0.7 }
};

const CENA_INICIAL = "estacao";

const CENAS = {

  /* CENA 1 */
  estacao: {
    img: IMG + "estacao_mao.png", alt: [IMG + "estacao.png"],
    inicio: { loop: "chiado" },
    passos: [
      { q:"PENSAMENTO", t:"Porra… que dia do caralho." },
      { q:"PENSAMENTO", t:"Fazia tempo que eu não passava por esta estação." },
      { q:"PENSAMENTO", t:"Dizem que esse lugar é estranho. Que já teve gente que entrou num trem aqui e nunca mais voltou." },
      { q:"PENSAMENTO", t:"Tem até umas histórias ridículas sobre pessoas que teriam viajado para outro mundo." },
      { q:"PENSAMENTO", t:"É impressionante como as pessoas conseguem acreditar em qualquer merda." },
      { q:"PENSAMENTO", t:"Eu nunca entendi essa necessidade de transformar tudo em alguma coisa sobrenatural." },
      { q:"PENSAMENTO", t:"Meu trabalho já é cansativo o suficiente. A última coisa de que preciso é ficar ouvindo histórias de fantasma." },
      { q:"", t:"Você segura o cigarro. O chiado da estação continua.", som:{ toca:"tragada" } },
      { q:"PENSAMENTO", t:"Vou fumar um pouco e aproveitar o silêncio antes de ir embora.", som:{ toca:"fumaca" } },
      { q:"PENSAMENTO", t:"Enfim… já está na hora de entrar nesse trem." }
    ],
    proxima: "plataforma"
  },

  /* CENA 2 — precisa do asset figuras_porta.png (sem rosto, amontoadas na porta) */
  plataforma: {
    img: IMG + "figuras_porta.png", alt: [IMG + "estacao_mao.png", IMG + "estacao.png"],
    passos: [
      { q:"", t:"Você se aproxima da entrada do trem." },
      { q:"PROTAGONISTA", t:"Espera aí…" },
      { q:"PROTAGONISTA", t:"Que porra é aquela?" },
      { q:"", t:"Várias figuras amontoadas perto da porta do vagão." },
      { q:"PROTAGONISTA", t:"Caralho… que merda é essa?" },
      { q:"PROTAGONISTA", t:"Que tipo de gente fica parada desse jeito?" },
      { q:"", t:"Você tenta enxergar melhor. As figuras parecem não ter rosto." },
      { q:"PROTAGONISTA", t:"Ah, não. Que porra é essa, velho?" }
    ],
    proxima: "garota"
  },

  /* CENA 3 */
  garota: {
    img: IMG + "garota_estacao.png", alt: [IMG + "estacao.png"],
    fx: "tremor",
    passos: [
      { q:"GAROTA", t:"Ei! Você! Graças a Deus, encontrei alguém!" },
      { q:"GAROTA", t:"Você precisa sair daqui!" },
      { q:"PROTAGONISTA", t:"Calma aí. Que porra aconteceu?" },
      { q:"GAROTA", t:"Eu vim correndo da estação dois!" },
      { q:"GAROTA", t:"A estação inteira está cheia dessas coisas!" },
      { q:"GAROTA", t:"Elas não têm rosto! Eu não sei o que são!" },
      { q:"GAROTA", t:"Eu tentei fugir, mas elas estão por toda parte!" },
      { q:"PROTAGONISTA", t:"Sem rosto? Você está falando sério?" },
      { q:"GAROTA", t:"Você acha que eu estaria correndo desse jeito se estivesse brincando?!" },
      { q:"GAROTA", t:"Escuta, a gente precisa sair daqui. Agora!" },
      { q:"", t:"Ela olha para o vagão e fica ainda mais apavorada." },
      { q:"GAROTA", t:"Não entra nesse trem!" },
      { q:"GAROTA", t:"Por favor… não entra nesse vagão!" }
    ],
    proxima: "escolha"
  },

  /* CENA 4 — ESCOLHA */
  escolha: {
    img: IMG + "trem_mao.png", alt: [IMG + "trem_portas.png"],
    passos: [
      { q:"", t:"A garota insiste para que você fuja com ela." },
      { q:"", t:"Mas você não acredita em histórias sobrenaturais." },
      { q:"", t:"O que vai fazer?" }
    ],
    escolhas: [
      { rotulo:"Entrar no vagão",  vai:"entrar", passos:[
        { q:"PENSAMENTO", t:"Deve ser alguma brincadeira idiota de Halloween." },
        { q:"PENSAMENTO", t:"Fantasia, gente querendo assustar os outros… sei lá." },
        { q:"PENSAMENTO", t:"Não vou perder meu trem por causa disso." } ] },
      { rotulo:"Seguir a garota", vai:"rota_garota", passos:[
        { q:"PROTAGONISTA", t:"Espera. Você disse que veio correndo da outra estação?" },
        { q:"PROTAGONISTA", t:"Tá bom. Vamos sair daqui primeiro." },
        { q:"PENSAMENTO", t:"Seja lá o que estiver acontecendo, não quero descobrir ficando parado aqui." } ] }
    ]
  },

  /* CENA 5 */
  entrar: {
    img: IMG + "trem_portas.png", alt: [],
    passos: [
      { q:"PROTAGONISTA", t:"Vamos acabar logo com isso." },
      { q:"", t:"Você se aproxima da porta, ainda segurando o cigarro. Assim que entra, as portas se fecham violentamente.", som:{ toca:"porta" }, fx:"tremor" },
      { q:"PROTAGONISTA", t:"Ei! Ei! Abre essa porra!" },
      { q:"", t:"Você tenta abrir a porta." },
      { q:"PROTAGONISTA", t:"Que merda é você?!" },
      { q:"PROTAGONISTA", t:"Abre essa porra, caralho!" },
      { q:"", t:"O chiado da estação desaparece lentamente. O vagão fica completamente escuro.", som:{ para:"chiado" } }
    ],
    proxima: "voz"
  },

  /* CENA 6 */
  voz: {
    img: IMG + "porta_vagao.png", alt: [], /* ausente = tela preta */
    passos: [
      { q:"VOZ DESCONHECIDA", t:"Você entrou por vontade própria." },
      { q:"", t:"…" },
      { q:"PROTAGONISTA", t:"…Que porra?" },
      { q:"VOZ DESCONHECIDA", t:"Agora não há mais volta." },
      { q:"", t:"Um ruído pesado vem do fundo do vagão. Você vira lentamente a cabeça.", som:{ loop:"ruido" } }
    ],
    proxima: "demonio"
  },

  /* CENA 7 — imagem do demônio será adicionada pelo desenvolvedor: assets/img/demonio.png */
  demonio: {
    img: IMG + "demonio.png", alt: [],
    passos: [
      { q:"PROTAGONISTA", t:"…Ah, vai se foder." },
      { q:"", t:"Você fica imóvel, ainda com o cigarro na mão." }
    ],
    fim: "FIM DA SEQUÊNCIA."
  },

  /* Rota da garota: a ser desenvolvida */
  rota_garota: {
    img: IMG + "estacao.png", alt: [],
    passos: [{ q:"", t:"[A rota da garota será desenvolvida posteriormente.]" }],
    fim: "FIM DA SEQUÊNCIA."
  }
};
