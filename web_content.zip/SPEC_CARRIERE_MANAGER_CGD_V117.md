# Spécification directrice — Championnat Galactique de Dames (CGD)

## Vision générale
Jeu mobile de gestion sportive de dames inspiré de Football Manager Mobile. Le joueur incarne un manager qui dirige un club sur une carrière multi-saisons sans limite prédéfinie. Il peut préparer, jouer ou simuler les rencontres de son équipe, mais aussi gérer les finances, les damistes, le staff, les relations, les installations, les compétitions et la réputation.

## 1. Carrière et identité du manager
- Modes : Club ; Club & International ; Sans emploi avec candidatures aux postes vacants.
- Profil : prénom, nom, galaxie de jeu, sexe, réputation initiale.
- Réputation : Inconnu, Locale, Continentale, Mondiale. Elle doit peser sur la confiance du conseil et l'éligibilité aux offres des clubs.
- La carrière progresse saison après saison, avec un historique durable.
- La galaxie de jeu détermine le contexte des divisions, clubs et structures accessibles, sans fabriquer de données historiques non vérifiées.

## 2. Temps et boucle de jeu
- Temps journalier et bouton global unique « CONTINUER ».
- Arrêt à une action prioritaire : réponse obligatoire, match du club, offre ou décision contractuelle.
- Libellés contextuels : « RÉPONSE REQUISE », « ALLER AU MATCH », « CONTINUER ».
- Les autres clubs et rencontres sont simulés automatiquement ; le joueur garde la maîtrise de son match et peut le jouer ou le simuler.
- Tirages, communications aux clubs et calendrier sont générés par les moteurs, sans approbation manuelle systématique.

## 3. Messagerie
- Boîte de réception : conseil, adjoint, damistes, supporters, presse, agents, sponsors et partenaires.
- Chaque message présente son contexte, son niveau d'urgence et des réponses ayant des conséquences explicites.
- Effets possibles : moral, confiance du conseil, réputation, harmonie du vestiaire, relations commerciales.
- Certains messages sont bloquants tant qu'une réponse n'a pas été donnée.

## 4. Club, finances, installations et staff
- Santé financière : Pauvre, Normal, Riche ; budgets distincts de transferts et salaires.
- Installations : entraînement, centre de jeunes, arène, capacité et affluence moyenne.
- Staff : manager, adjoint, entraîneurs, recruteurs, kiné, avec profils, compétences et responsabilités.
- Délégation paramétrable : préparation des matchs, prêts, conseils et suivi des jeunes.
- Identité éditable : maillot, écusson et drapeau. Les éditeurs et motifs déjà livrés sont conservés.

## 5. Arènes
### Arènes spéciales — 9
1. Terrestre : règles classiques.
2. Néon : ambiance néon et chronomètre spécial de 2 minutes selon le catalogue historique.
3. Cristalline : 4 cristaux bleus ; arrivée sur cristal et promotion selon le moteur existant.
4. Gravitationnelle : dames limitées à 3 déplacements hors prise.
5. Volcanique : 4 cases de lave rouge sombre avec effets définis par le moteur d'arène.
6. Océanique : les pions capturent vers l'avant uniquement.
7. Temporelle : 40 tours maximum par camp.
8. Dimensionnelle : promotion anticipée.
9. Galactique Suprême : 2 cases de lave et 2 cristaux.
- Aperçu de damier 10×10 ; cases de lave en rouge sombre et cristaux en bleu.
### Arènes de clubs — 60
- Grille de 60 tuiles visuelles, sans modifier les règles de jeu.
- Arène du club dirigé mise en évidence en doré ; capacité, affluence moyenne et niveau des installations affichés.
- Actions en bas : Annuler et Confirmer.

## 6. Conseil d'administration
- Confiance sur six domaines : Matchs, Transferts, Harmonie, Supporters, Finances et Jeunes.
- Objectifs de saison et suivi des attentes.
- Demandes : budgets, installations, agrandissement d'arène, délai de reconstruction, sponsor et démission.
- Une confiance durablement faible expose au licenciement ; les seuils et conséquences devront être paramétrés et testés.

## 7. Effectif des damistes
- Chaque club possède exactement deux damistes, hommes ou femmes.
- Fiche : niveau, calcul, tactique, endurance, sang-froid, finale, forme, moral, contrat et valeur.
- Contrats : salaire, prime, durée, statut, négociation et contre-proposition ; signature seulement après accord des deux parties.
- Transferts : achats, échanges, agents, liste de transfert et prêts, sans dépasser deux damistes par club.
- Réserve et centre de jeunes : génération contrôlée de nouveaux damistes et choix d'une politique de développement.

## 8. Tactique et match
- Pré-match : choix d'un titulaire parmi les deux damistes, style Attaque / Équilibré / Défense et consignes.
- Match : damier, couleurs des équipes, chronomètre global et temps par tour, pause et changement de style.
- Règles de dames internationales 10×10 : prise obligatoire, prises multiples, dames volantes et prise maximale.
- Après-match : résumé, notes, réactions du conseil et de la presse.
- Les règles et le moteur de simulation déjà validés sont la source de vérité ; ne pas créer un second moteur contradictoire.

## 9. Compétitions et calendrier
- Championnats par divisions avec promotions et relégations ; Coupe Galactique, Coupe Fédéral, Coupe des Clubs, Champions League, Intergalactique des Clubs, Coupe Intergalactique des sélections/galaxies et Coupe Lunaire.
- La Dame d'Or est un classement individuel et une récompense annuelle, pas une coupe de club.
- Tirages automatiques, courriers aux clubs et inscription dans le calendrier central.
- Jours de compétition autorisés dans le principe : mardi, mercredi, jeudi et samedi, sous réserve des fenêtres officielles déjà validées, des journées de repos et de l'absence de chevauchement.
- Conserver les autorités FGD / AGD et les formats propres à chacune des huit compétitions existantes.

## 10. Classements, palmarès et histoire
- Hall of Fame des managers, rang, club, titres et réputation ; armoire à trophées, historique, succès et récits de carrière.
- Cérémonie annuelle dédiée, un prix après l'autre, avec écusson et maillot du lauréat.
### Récompenses individuelles
- Dame d'Or ; meilleur jeune ; meilleur damiste de chaque division ; manager de l'année.
### Récompenses collectives
- Club d'Or toutes divisions confondues ; champion de chaque division ; meilleure équipe de la saison avec un damiste par division ; meilleure attaque ; meilleure défense ; meilleure série d'invincibilité ; révélation de l'année (meilleur club promu) ; meilleure galaxie ; meilleure sélection de la Coupe Intergalactique ; fair-play (temps dépassé et forfaits les moins nombreux).
- Attribution automatique uniquement à partir des résultats homologués et de statistiques traçables.
- Chaque récompense est inscrite au palmarès du lauréat et du club concerné, influence la réputation et la confiance, et produit un message de félicitations.

## 11. Sauvegarde, options et navigation
- Sauvegarde automatique et manuelle ; plusieurs carrières chargeables ; réglage IA : Débutant, Amateur, Moyen, Supérieur, Professionnel ; quitter.
- Rail d'icônes à gauche : Messagerie, Accueil, Club, Arène de jeu, Damistes, Compétitions, Recherche, Réglages.
- Menu contextuel et un seul écran principal à la fois.
- Interface paysage prioritaire sur mobile, avec repli portrait accessible.

## Ordre de construction
La spécification est le contrat directeur du produit, mais ses 11 ensembles ne sont pas tous déclarés livrés par le socle 3.4. Les fonctionnalités seront intégrées par étapes testées, en commençant par la boucle quotidienne, puis le conseil et les finances, le staff/installations, les jeunes/recrutement, les arènes et enfin les palmarès/cérémonies.
