# BOSS Power Audio Web App

This project turns the supplied BOSS Premium Mic extension into a small web dashboard with a real WhatsApp Web QR session backend.

## What it does
- Single WhatsApp Web session using `whatsapp-web.js` + LocalAuth.
- QR code is shown in the dashboard for WhatsApp → Linked devices.
- Session persists in `.wwebjs_auth`.
- Browser microphone preview with gain, compressor, presence EQ and limiter controls.
- Original supplied extension is kept under `extension/` for supported Chromium Web use.

## Important limitation
WhatsApp does not expose a public API that lets a normal website capture and replace the internal audio of every WhatsApp call. Therefore this project does **not** falsely claim guaranteed audio processing for normal, group, or call-link calls. The browser audio panel processes a microphone stream when the browser exposes it; the supplied extension can be loaded separately for WhatsApp Web where its hook works.

## Run
1. Install Node.js 20+.
2. Run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000`.
5. Scan the QR with WhatsApp → Linked devices.

For Railway/Render/etc., use `npm start` as the start command and provide persistent storage if you want the WhatsApp auth session to survive redeploys.
