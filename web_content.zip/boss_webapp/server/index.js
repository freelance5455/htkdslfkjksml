const express = require('express');
const path = require('path');
const QRCode = require('qrcode');
const { Client, LocalAuth } = require('whatsapp-web.js');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const client = new Client({
  authStrategy: new LocalAuth({ dataPath: path.join(__dirname, '..', '.wwebjs_auth') }),
  puppeteer: {
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
  }
});

let state = { status: 'starting', qr: null, ready: false, number: null, name: null, error: null };

client.on('qr', async qr => {
  try { state.qr = await QRCode.toDataURL(qr, { width: 280, margin: 1 }); } catch (e) { state.error = e.message; }
  state.status = 'qr'; state.ready = false; state.error = null;
});
client.on('authenticated', () => { state.status = 'authenticated'; state.qr = null; });
client.on('ready', () => {
  const info = client.info;
  state = { ...state, status: 'ready', ready: true, qr: null, error: null,
    number: info?.wid?.user || null, name: info?.pushname || null };
});
client.on('auth_failure', msg => { state.status = 'auth_failure'; state.ready = false; state.error = String(msg); });
client.on('disconnected', reason => { state.status = 'disconnected'; state.ready = false; state.error = String(reason); });

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('/api/status', (_req, res) => res.json(state));
app.post('/api/logout', async (_req, res) => {
  try { await client.logout(); state = { status: 'logged_out', qr: null, ready: false, number: null, name: null, error: null }; res.json({ ok: true }); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});
app.get('/health', (_req, res) => res.json({ ok: true, whatsapp: state.status }));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.listen(PORT, HOST, () => console.log(`BOSS Power Audio listening on ${HOST}:${PORT}`));
client.initialize().catch(err => { state.status = 'error'; state.error = err.message; console.error(err); });
