class FreeFireMacro {
    constructor() {
        this.isRunning = false;
        this.clickSpeed = 150;
        this.clickInterval = 500;
        this.overlayOpacity = 70;
        this.autoHeadshot = true;
        this.smoothMovement = false;
        this.antiDetection = true;
        this.macros = [];
        this.permissions = new Set();
        this.notificationsEnabled = false;
        
        this.initElements();
        this.bindEvents();
        this.checkPermissions();
    }

    initElements() {
        this.elements = {
            btnToggle: document.getElementById('btnToggle'),
            btnPermissions: document.getElementById('btnPermissions'),
            btnNotify: document.getElementById('btnNotify'),
            clickSpeed: document.getElementById('clickSpeed'),
            clickInterval: document.getElementById('clickInterval'),
            overlayOpacity: document.getElementById('overlayOpacity'),
            autoHeadshot: document.getElementById('autoHeadshot'),
            smoothMovement: document.getElementById('smoothMovement'),
            antiDetection: document.getElementById('antiDetection'),
            speedValue: document.getElementById('speedValue'),
            intervalValue: document.getElementById('intervalValue'),
            opacityValue: document.getElementById('opacityValue'),
            statusText: document.getElementById('statusText'),
            overlay: document.getElementById('overlay'),
            logContainer: document.getElementById('logContainer'),
            macroProgress: document.getElementById('macroProgress')
        };
    }

    bindEvents() {
        // Botões principais
        this.elements.btnToggle.addEventListener('click', () => this.toggleMacro());
        this.elements.btnPermissions.addEventListener('click', () => this.requestPermissions());
        this.elements.btnNotify.addEventListener('click', () => this.enableNotifications());

        // Sliders de configuração
        this.elements.clickSpeed.addEventListener('input', (e) => {
            this.clickSpeed = parseInt(e.target.value);
            this.elements.speedValue.textContent = `${this.clickSpeed}ms`;
        });

        this.elements.clickInterval.addEventListener('input', (e) => {
            this.clickInterval = parseInt(e.target.value);
            this.elements.intervalValue.textContent = `${this.clickInterval}ms`;
        });

        this.elements.overlayOpacity.addEventListener('input', (e) => {
            this.overlayOpacity = parseInt(e.target.value);
            this.elements.opacityValue.textContent = `${this.overlayOpacity}%`;
            this.updateOverlayOpacity();
        });

        // Checkboxes
        this.elements.autoHeadshot.addEventListener('change', (e) => {
            this.autoHeadshot = e.target.checked;
        });

        this.elements.smoothMovement.addEventListener('change', (e) => {
            this.smoothMovement = e.target.checked;
        });

        this.elements.antiDetection.addEventListener('change', (e) => {
            this.antiDetection = e.target.checked;
        });
    }

    async toggleMacro() {
        if (!this.hasRequiredPermissions()) {
            this.log('Permissões necessárias! Conceda as permissões primeiro.', 'warning');
            return;
        }

        if (this.isRunning) {
            this.stopMacro();
        } else {
            await this.startMacro();
        }
    }

    async startMacro() {
        try {
            this.isRunning = true;
            this.updateUI();
            this.showOverlay(true);
            this.log('Macro iniciado com sucesso!', 'success');
            
            // Simula execução do macro
            this.executeMacros();
            
        } catch (error) {
            this.log(`Erro ao iniciar: ${error.message}`, 'error');
            this.stopMacro();
        }
    }

    stopMacro() {
        this.isRunning = false;
        this.macros.forEach(macro => clearTimeout(macro.id));
        this.macros = [];
        this.updateUI();
        this.showOverlay(false);
        this.log('Macro parado pelo usuário', 'info');
    }

    executeMacros() {
        const macroFunctions = [
            this.createClickMacro(),
            this.createAutoHeadshotMacro(),
            this.createMovementMacro()
        ];

        macroFunctions.forEach(fn => {
            const macroId = setInterval(() => {
                if (this.isRunning && this.antiDetection) {
                    fn.call(this);
                }
            }, this.calculateRandomDelay());
            
            this.macros.push({ id: macroId, function: fn });
        });
    }

    createClickMacro() {
        return () => {
            // Simula clique na tela
            const clickEvent = new MouseEvent('click', {
                bubbles: true,
                cancelable: true,
                view: window
            });
            document.body.dispatchEvent(clickEvent);
        };
    }

    createAutoHeadshotMacro() {
        return () => {
            if (this.autoHeadshot) {
                this.log('Auto headshot ativado', 'info');
                // Lógica específica para headshot
            }
        };
    }

    createMovementMacro() {
        return () => {
            if (this.smoothMovement) {
                this.log('Movimento suave ativo', 'info');
                // Lógica específica para movimento
            }
        };
    }

    calculateRandomDelay() {
        const baseDelay = this.clickInterval;
        const variance = Math.floor(Math.random() * 100) - 50; // Variação aleatória
        return baseDelay + variance;
    }

    async requestPermissions() {
        try {
            this.log('Solicitando permissões...', 'info');
            
            // Simula concessão de permissões
            const permissions = ['read_files', 'write_files', 'access_storage', 'modify_freefire'];
            
            for (const perm of permissions) {
                await this.grantPermission(perm);
            }
            
            this.updatePermissionStatus();
            this.log('Todas as permissões concedidas!', 'success');
            
        } catch (error) {
            this.log(`Erro ao conceder permissões: ${error.message}`, 'error');
        }
    }

    async grantPermission(permission) {
        return new Promise((resolve) => {
            setTimeout(() => {
                this.permissions.add(permission);
                resolve();
            }, 500);
        });
    }

    async enableNotifications() {
        try {
            if ('Notification' in window) {
                const permission = await Notification.requestPermission();
                this.notificationsEnabled = permission === 'granted';
                
                if (this.notificationsEnabled) {
                    new Notification('Free Fire Macro Pro', {
                        body: 'Notificações ativadas com sucesso!',
                        icon: '🎯'
                    });
                    this.log('Notificações ativadas!', 'success');
                } else {
                    this.log('Permissão de notificação negada', 'warning');
                }
            } else {
                this.log('Navegador não suporta notificações', 'error');
            }
        } catch (error) {
            this.log(`Erro ao ativar notificações: ${error.message}`, 'error');
        }
    }

    checkPermissions() {
        this.updatePermissionStatus();
    }

    hasRequiredPermissions() {
        const required = ['read_files', 'write_files', 'access_storage'];
        return required.every(perm => this.permissions.has(perm));
    }

    updateUI() {
        const statusClass = this.isRunning ? 'active' : 'off';
        const statusText = this.isRunning ? 'Ativo' : 'Desativado';
        
        this.elements.statusText.className = `status ${statusClass}`;
        this.elements.statusText.textContent = statusText;
        
        this.elements.btnToggle.innerHTML = this.isRunning 
            ? '<span class="icon">⏹️</span> Parar Macro' 
            : '<span class="icon">▶️</span> Iniciar Macro';
    }

    updatePermissionStatus() {
        const status = this.hasRequiredPermissions() ? 'active' : 'pending';
        const text = this.hasRequiredPermissions() ? 'Concedidas' : 'Pendentes';
        
        document.getElementById('permStatus').className = `status ${status}`;
        document.getElementById('permStatus').textContent = text;
    }

    showOverlay(show) {
        if (show) {
            this.elements.overlay.classList.remove('hidden');
            this.updateOverlayOpacity();
        } else {
            this.elements.overlay.classList.add('hidden');
        }
    }

    updateOverlayOpacity() {
        this.elements.overlay.style.opacity = this.overlayOpacity / 100;
    }

    log(message, type = 'info') {
        const logEntry = document.createElement('div');
        logEntry.className = `log-entry ${type}`;
        logEntry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        
        this.elements.logContainer.appendChild(logEntry);
        this.elements.logContainer.scrollTop = this.elements.logContainer.scrollHeight;
        
        // Limita número de logs
        if (this.elements.logContainer.children.length > 50) {
            this.elements.logContainer.removeChild(this.elements.logContainer.firstChild);
        }
    }
}

// Inicializa quando a página carregar
document.addEventListener('DOMContentLoaded', () => {
    new FreeFireMacro();
});
