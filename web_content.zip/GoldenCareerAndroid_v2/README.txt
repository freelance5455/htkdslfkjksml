GOLDEN CAREER ANDROID – VERSION 2.0

NOUVEAUTÉS
- Création du profil : nom, poste et nationalité.
- Progression de 16 à 40 ans.
- Entraînement et matchs avec statistiques.
- Championnat, coupe nationale et Ligue des champions (simulations).
- Convocation en sélection nationale.
- Marché des transferts et négociation d'offres.
- Récompenses de fin de saison et course au Ballon d'Or.
- Narrateur vocal français + sous-titres.
- Sauvegarde locale automatique.

COMPILATION
1. Décompresser l'archive.
2. Ouvrir le dossier dans Android Studio.
3. Attendre la synchronisation Gradle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

IMPORTANT
Ceci est le projet source Android, pas un APK déjà compilé.
La voix utilise la synthèse vocale disponible sur l'appareil.
Les résultats sportifs et transferts sont simulés localement, sans connexion à des bases de données officielles.
