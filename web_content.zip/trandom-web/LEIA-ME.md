# TRANDOM — versão web para APKForge / PWA Builder

Tudo está em **um único arquivo: `index.html`** (HTML + CSS + JS, sem bibliotecas, sem fontes externas, sem rede). É o arquivo para enviar ao APKForge. `manifest.webmanifest`, `sw.js` e `icons/` são extras para quem quiser empacotar como PWA (PWA Builder); o app funciona sem eles.

## Antes de empacotar
Edite o bloco `CONFIG` no começo do `<script>` de `index.html`:
- `BUY_ME_A_COFFEE_URL`, `PRIVACY_POLICY_URL`, `CONTACT_EMAIL`, `STORE_URL`: enquanto forem `REPLACE_WITH...`, os botões mostram "link ainda não disponível" (a linha de contato e a de avaliação ficam ocultas). Nada abre link inválido.
- Se o APKForge pedir ID de pacote, use o definitivo (ex.: `com.tfcorp.trandom`). Ele é permanente depois de publicar.

## O que tem (igual à versão Android, exceto o que está listado abaixo)
Roleta com roda desenhada (LEDs, pinos, ponteiro que bate em cada pino, desaceleração real, segmento vencedor em destaque), Números, Moeda 3D com espessura que gira no ar e quica, Dados 3D reais (poliedros D4/D6/D8/D10/D12/D20 desenhados em canvas, lançamento com giro, quique e sombra; 3 vs 3), fundo animado (ajuste "Fundo animado"), transições de página em cascata, Bola mágica (com respostas próprias), Letras, Cartas, Equipes · favoritos · histórico (200 itens) · listas salvas · copiar e compartilhar · som/vibração/histórico por ferramenta · pt-BR e en-US (detecta no 1º uso, troca em Ajustes, salva) · tema escuro padrão, claro e AMOLED · sem cadastro, sem rede. Dados ficam em `localStorage`.

## Diferenças em relação à versão Android
- Sem "agitar para lançar".
- Os sons são tons sintetizados (Web Audio), não os arquivos originais. Desligados por padrão.
- Compartilhar usa `navigator.share` quando o WebView permite; senão copia o texto.
- Vibração usa `navigator.vibrate`; depende do WebView/empacotador.

## O que foi e o que NÃO foi testado
Testado no Chromium de computador (Playwright), 90 verificações passaram: detecção de idioma (pt-BR, pt-PT, en-US, es-ES, ja-JP), todas as 8 ferramentas com entradas válidas e inválidas, favoritos, histórico, listas, copiar, configurações por ferramenta, troca de idioma e tema com persistência após recarregar, nenhuma requisição de rede, funcionamento offline, ausência de rolagem horizontal em 4 tamanhos de tela e nenhum erro de JavaScript.

**Não testado:** o APKForge em si (não encontrei documentação dele e não sei os requisitos exatos), um WebView Android real, o toque em aparelho, compartilhar/vibrar/copiar dentro do APK, abrir links externos pelo APK (`window.open` pode precisar de permissão no empacotador) e o service worker (só roda em http/https; em `file://` ele é ignorado).

## Licença
Baseado no Randomix (minar, MIT). O aviso está em `LICENSE.md` e na tela Ajustes › Licença.


## Animações (esta versão)
- Tudo é desenhado em canvas/CSS, sem bibliotecas e sem rede. `prefers-reduced-motion` reduz as animações ao mínimo.
- O resultado é sorteado primeiro (`crypto.getRandomValues`) e a animação termina exatamente nele.
- Testado: 95 verificações automáticas em Chromium desktop (resultado, histórico, ajustes, offline, sem rede, sem erros de JS) e capturas de tela de cada dado, da roleta e da moeda.
- NÃO testado: desempenho em celulares reais/WebView do APKForge, som e vibração em aparelho real. Se ficar pesado em aparelhos fracos, desligue "Fundo animado".
- Dados: o número sorteado aparece num selo sobre cada dado (o maior brilha, o menor apaga), então não é preciso contar pontos nem girar a cabeça para ler a face.
- Bola mágica (esfera com líquido que gira e resposta que sobe na janela), cartas distribuídas e viradas, números e letras girando e travando da esquerda para a direita, equipes surgindo em sequência.

## Versão 1.1.0 (otimização)
- Roleta: a roda vem primeiro e as opções ficam abaixo; atalhos "Sim/Não", "Pedra, papel, tesoura" e "1 a 6" quando a lista está vazia.
- Sons por ferramenta (clique de dado, tinido de moeda, acorde da roleta, sino da bola mágica) e vibração diferente no fim do sorteio. Só tocam se Som/Vibração estiverem ligados.
- Cor de destaque (ciano, violeta, verde, âmbar, rosa), funciona nos temas escuro, claro e AMOLED.
- "Chacoalhar para jogar" (desligado por padrão; em iOS pede permissão ao ligar). NÃO testado em aparelho real.
- Início mostra os últimos resultados; histórico agrupado por dia, com ícone da ferramenta.
- Acessibilidade: resultados anunciados para leitores de tela, foco visível, alvos de toque maiores.
- Cache offline atualizado para `trandom-v2`.

## 1.1.1
Auditoria e correções: veja `RELATORIO_AUDITORIA.md`. Testes em `tests/` (precisam de Python + Playwright; ajuste o caminho do index.html no topo de cada arquivo).
