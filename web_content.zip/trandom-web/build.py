# Builds index.html from src/template.html, injecting the magic ball answers from the Android strings
import re,json,sys
res='/home/claude/trandom/app/src/main/res/'
def parse(p):
    s=open(res+p,encoding='utf-8').read();return {m.group(1):m.group(2).replace("\\'","'").replace('\\"','"') for m in re.finditer(r'<string name="([^"]+)"[^>]*>(.*?)</string>',s,re.S)}
out={}
for lang,p in [('en','values/strings.xml'),('pt','values-pt-rBR/strings.xml')]:
    d=parse(p);out[lang]={'normal':[d[f'magic_answer_{i}'] for i in range(1,31)],'rude':[d[f'magic_answer_rude_{i}'] for i in range(1,7)]}
t=open('/home/claude/trandom-web/src/template.html',encoding='utf-8').read().replace('/*MAGIC*/{}',json.dumps(out,ensure_ascii=False))
open('/home/claude/trandom-web/index.html','w',encoding='utf-8').write(t);print('built',len(t))
