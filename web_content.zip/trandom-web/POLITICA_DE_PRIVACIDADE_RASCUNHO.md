# Política de Privacidade — TRANDOM (RASCUNHO)

> Rascunho técnico baseado no comportamento real do app. Não é aconselhamento jurídico: revise, preencha os campos entre [colchetes] e publique numa URL pública antes de enviar à Google Play.

**Última atualização:** [data]
**Desenvolvedora:** TFcorp — contato: [e-mail de contato]

## O que o TRANDOM faz com os seus dados
O TRANDOM funciona totalmente no seu aparelho. O app **não tem cadastro, não tem login e não declara a permissão de internet**. A TFcorp **não coleta, não recebe e não compartilha** dados pessoais por meio do app.

## Dados guardados no aparelho
Ficam apenas no armazenamento local do app: preferências (idioma, tema, vibração, som), favoritos, listas salvas por você, histórico de resultados e opções digitadas na roleta. Você pode apagar o histórico dentro do app; ao desinstalar o app, os dados locais são removidos. Esses dados podem ser incluídos no backup automático do Android da sua conta Google, conforme as configurações do seu aparelho.

## Permissões
- **Vibração**: feedback ao tocar nos botões.
Nenhuma outra permissão é solicitada.

## Links externos
O botão de apoio voluntário e a política de privacidade abrem o navegador do aparelho em sites de terceiros (por exemplo, Buy Me a Coffee), que têm suas próprias políticas. O app não envia dados seus a esses sites.

## Crianças
O app não coleta dados de ninguém, incluindo crianças.

## Alterações
Mudanças nesta política serão publicadas nesta página com nova data.

## Contato
[e-mail de contato]
