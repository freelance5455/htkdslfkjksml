# TRANDOM web 1.1.1 — Relatório de auditoria

Escopo: a versão web (index.html, sw.js, manifest). O projeto Android continua NÃO compilado e não foi tocado.
Backup da versão anterior (1.1.0): pasta `trandom-web-backup-v1.1.0` (fora deste ZIP, na área de trabalho da sessão); o ZIP da 1.1.0 já entregue também serve de recuperação.

## A. Diagnóstico
Estado inicial: app funcional (95 verificações aprovadas), mas com falhas de robustez em dados e entradas extremas.
Pontos bons: sem rede, sem dependências, sorteio com `crypto.getRandomValues` e rejeição de viés, sem `eval`, `innerHTML` só com ícones fixos do próprio código.

## B. Bugs encontrados e corrigidos (todos reproduzidos por teste ANTES da correção)
| # | Bug | Gravidade | Causa-raiz | Correção | Validação |
|---|-----|-----------|-----------|----------|-----------|
| 1 | Intervalo grande (ex.: 0 a 9.000.000.000) na Roleta ou em Números congelava a aba | Crítica | `rnd(n)` com n > 2^32: `lim` virava 0 e o laço de rejeição nunca terminava | `rnd` passou a aceitar até 2^53 (53 bits, com rejeição); limites validados como inteiros seguros | B1, B1b; qui-quadrado e faixa em 120 mil sorteios |
| 2 | Dados salvos corrompidos/antigos (ex.: `fav:null`) deixavam o app em branco, e o erro persistia a cada abertura | Crítica | `load()` só preenchia chaves ausentes, sem checar tipos | `sanitize()` valida tipo e faixa de tudo; JSON ilegível é copiado para `trandom_v1_unreadable` antes de ser sobrescrito | B2 |
| 3 | "2.5" virava 2 e "1e1" virava 1 em silêncio | Média | `parseInt` aceita lixo depois do número | `toInt` estrito (só inteiros); valor inválido mostra o erro de faixa | B3, B12 |
| 4 | Falha ao gravar (armazenamento cheio/bloqueado) era engolida sem aviso | Média | `catch` vazio | Aviso único por sessão; o app segue funcionando | B4, B4b |
| 5 | Seta "Voltar" empilhava histórico: o botão Voltar do sistema reabria a ferramenta | Média | `go("home")` em vez de voltar | `goBack()` usa `history.back()` quando veio de dentro do app | B10 |
| 6 | Mudar o intervalo durante o giro trocava os setores da roda e o destaque do vencedor sumia ou errava | Média | `sync()` redesenhava a roda em pleno giro | Sincronização ignorada durante o giro; destaque exposto em `data-win` para teste | B11 |
| 7 | "Remover último escolhido" apagava a opção no mesmo instante em que o vencedor aparecia | Baixa | remoção imediata + redesenho | Vencedor fica aceso 1,8 s antes de sair da lista | teste manual de código; sem teste automatizado dedicado |
| 8 | Coringa usava emoji (contra a diretriz do projeto) | Baixa | texto `🃏` | Texto "Coringa/Joker" | B9 |
| 9 | Teclado numérico do iOS não tem sinal de menos (intervalos negativos impossíveis) | Média | `inputmode="numeric"` em Mín/Máx | removido só nesses campos | NÃO testado em iPhone (ver H) |
| 10 | Zoom de página bloqueado (`user-scalable=no`) | Média (acessibilidade) | meta viewport | removido; `touch-action: manipulation` evita o atraso do toque duplo | revisão de código |

## C. Melhorias estruturais
- `sw.js`: estratégia "cache primeiro + atualiza em segundo plano" (antes, versão nova exigia trocar o nome do cache à mão). Cache `trandom-v3`.
- Um único `AudioContext` (havia dois).
- Removido CSS morto (`.big`, `.coin`, `.spin`, `.flip`, `.shake`).
- Texto do histórico limitado a 1500 caracteres.

## D. Performance (medido)
Fundo animado: removido `filter: blur(24px)` de uma tela cheia (o canvas já é 1/3 da resolução e os gradientes já são suaves; visual equivalente na captura) e limitado a 30 quadros/s, pausado com a aba oculta.
Trabalho da thread principal com a tela inicial parada, Chromium headless, 5 s por amostra, duas rodadas:
antes 47,4 e 40,4 ms/s; depois 23,1 e 23,1 ms/s (cerca de metade).
Limite da medição: headless usa renderização por software; o ganho de GPU em celular real não foi medido.

## E. Segurança
- Adicionada Content-Security-Policy: sem conexões de rede (`connect-src 'none'`), sem formulários, sem objetos, sem `base`. `script-src` mantém `'unsafe-inline'` porque o app é um arquivo único. Isso limita o estrago de uma eventual injeção, mas não a elimina.
- Verificado: nenhum uso de `eval`/`document.write`; `innerHTML` recebe apenas ícones fixos; textos de usuário entram como texto.
- Dados ficam só no `localStorage` do aparelho, sem criptografia (não há dado sensível).
- Não é uma auditoria de segurança completa; não afirmo que o app é "seguro".

## F. Interface e experiência
Mensagem clara quando o armazenamento falha; Voltar coerente; zoom liberado; coringa em texto. Sem redesenho.

## G. Testes
Executados e aprovados (Chromium desktop, Playwright):
- `tests/test_funcional.py`: 95 verificações (idiomas, todas as ferramentas, listas, histórico, ajustes, offline, sem requisições de rede, sem erros de JS).
- `tests/test_bugs_extremos.py`: 14 verificações dos bugs acima, 14 aprovadas (antes das correções: 5 aprovadas, 9 reprovadas).
- Estatística do `rnd`: qui-quadrado 4,5 (6 faces) e 5,6 (7 valores), abaixo do limite 20,5/22,5; 20 mil sorteios em faixa de 2^40 e 20 mil em 2^53, todos válidos.
- Layout sem rolagem horizontal em 320 px.
Não executados: celular real, WebView do APKForge, Safari/iOS/Firefox, leitor de tela, som/vibração/chacoalhar em aparelho, Service Worker via https (testes rodam em `file://`, onde ele não registra), projeto Android (não compila neste ambiente).

## H. Pendências
- Testar em aparelho real e no APKForge (a CSP é a mudança com maior risco de interagir com o empacotador, se ele injetar scripts na página; se algo quebrar, remova a linha `Content-Security-Policy` do `<head>`).
- Dados do usuário (listas, favoritos) só existem no aparelho: não há exportar/importar. Seria o próximo item útil, mas muda o produto, então não implementei sem sua autorização.
- Preencher links reais (apoio, política de privacidade) em `CONFIG`; ícone final.

## I. Resultado final
A versão 1.1.1 corrige uma falha crítica de congelamento e uma de quebra por dados corrompidos, e está mais robusta para entradas extremas. Está pronta para teste em aparelho real, não para publicação sem esse teste.
