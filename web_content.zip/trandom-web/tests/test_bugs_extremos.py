import sys, json, asyncio
from playwright.async_api import async_playwright
URL=sys.argv[1] if len(sys.argv)>1 else "file:///home/claude/trandom-web/index.html"
res=[]
def rec(name,ok,info=""): res.append((name,ok,info)); print(("PASS " if ok else "FAIL ")+name+(" -> "+str(info) if info and not ok else ""),flush=True)
async def page(br,pre=None,w=390,locale="en-US"):
    ctx=await br.new_context(locale=locale,viewport={"width":w,"height":780},permissions=["clipboard-read","clipboard-write"])
    p=await ctx.new_page();errs=[];p.on("pageerror",lambda e:errs.append(str(e)));p.on("console",lambda m:errs.append(m.text) if m.type=="error" else None)
    if pre: await p.add_init_script(pre)
    await p.goto(URL);await p.wait_for_timeout(300);return ctx,p,errs
async def alive(p,ms=3000):
    try: return (await asyncio.wait_for(p.evaluate("1+1"),ms/1000))==2
    except Exception: return False
async def main():
    async with async_playwright() as pw:
        br=await pw.chromium.launch()
        async def freeze_test(name,hash_,setup,click):
            br2=await pw.chromium.launch();ctx=await br2.new_context(locale="en-US",viewport={"width":390,"height":780});p=await ctx.new_page();p.set_default_timeout(4000)
            await p.goto(URL);await p.evaluate(f"location.hash='{hash_}'")
            try:
                await setup(p);await p.click(click,no_wait_after=True,timeout=4000)
            except Exception: pass
            await p.wait_for_timeout(1200);ok=await alive(p);rec(name,ok,"page frozen (infinite loop in rnd)")
            try: await asyncio.wait_for(br2.close(),4)
            except Exception: pass
        async def s1(p):
            await p.wait_for_selector("text=Range");await p.click("button:has-text('Range')");await p.fill("#rmin","0");await p.fill("#rmax","9000000000")
        async def s2(p):
            await p.wait_for_selector("#nmin");await p.fill("#nmin","0");await p.fill("#nmax","9000000000");await p.fill("#nqty","3")
        await freeze_test("B1 roulette range 0..9e9 keeps page responsive","#/tool/roulette",s1,"button:has-text('Spin the roulette!')")
        await freeze_test("B1b numbers range 0..9e9 keeps page responsive","#/tool/numbers",s2,"button:has-text('Draw')")
        # B2 corrupted / old storage
        bad='localStorage.setItem("trandom_v1",JSON.stringify({lang:"pt",fav:null,hist:"x",lists:[{}],ts:null,inp:{dice:{sides:7,count:99},roulette:{opts:"abc",min:null}},accent:"zzz",theme:"neon"}))'
        ctx,p,e=await page(br,bad)
        ok=True;why=""
        for r in ["home","history","lists","settings"]+["tool/"+k for k in["roulette","numbers","coin","dice","magic","letters","cards","teams"]]:
            await p.evaluate(f"location.hash='#/{r}'");await p.wait_for_timeout(150)
            if not (await p.inner_text("main")).strip(): ok=False;why=r;break
        rec("B2 corrupted storage: all pages still render",ok and not e,(why,e[:2]));await ctx.close()
        # B3 non-integer input
        ctx,p,e=await page(br)
        await p.evaluate("location.hash='#/tool/numbers'");await p.wait_for_selector("#nmin")
        await p.fill("#nmin","1");await p.fill("#nmax","2.5");await p.fill("#nqty","1");await p.click("button:has-text('Draw')");await p.wait_for_timeout(300)
        t=await p.inner_text("#toast");rec("B3 decimal limit rejected (not silently truncated)","range" in t.lower() or "integer" in t.lower() or "whole" in t.lower(),t);await ctx.close()
        # B4 storage blocked: app works and the user is told
        pre='Storage.prototype.setItem=function(){throw new DOMException("full","QuotaExceededError")}'
        ctx,p,e=await page(br,pre)
        await p.evaluate("location.hash='#/tool/coin'");await p.click("button:has-text('Flip the coin!')");await p.wait_for_timeout(2600)
        t=await p.inner_text("#toast");rec("B4 failed save is reported once",("save" in t.lower() or "storage" in t.lower()),t);rec("B4b app still works without storage",(await p.inner_text(".res")) in("Heads!","Tails!"));await ctx.close()
        # B5 double tap on spin writes one history entry
        ctx,p,e=await page(br)
        await p.evaluate("location.hash='#/tool/coin'");b=p.locator("button:has-text('Flip the coin!')");await b.dblclick();await p.wait_for_timeout(2800)
        n=await p.evaluate("JSON.parse(localStorage.getItem('trandom_v1')).hist.length");rec("B5 double tap = one result",n==1,n);await ctx.close()
        # B6 leaving a tool mid-animation then coming back: no errors
        ctx,p,e=await page(br)
        for k,btn in [("dice","Throw the dice!"),("coin","Flip the coin!"),("magic","Shake it!")]:
            await p.evaluate(f"location.hash='#/tool/{k}'");await p.click(f"button:has-text('{btn}')");await p.wait_for_timeout(200)
            await p.evaluate("location.hash='#/home'");await p.wait_for_timeout(200);await p.evaluate(f"location.hash='#/tool/{k}'");await p.wait_for_timeout(2800)
        rec("B6 navigate away mid-animation: no JS errors",not e,e[:2]);await ctx.close()
        # B7 layout at 320px
        ctx,p,e=await page(br,w=320);bad=[]
        for r in ["home","history","lists","settings"]+["tool/"+k for k in["roulette","numbers","coin","dice","magic","letters","cards","teams"]]:
            await p.evaluate(f"location.hash='#/{r}'");await p.wait_for_timeout(250)
            if await p.evaluate("document.documentElement.scrollWidth>document.documentElement.clientWidth+1"): bad.append(r)
        rec("B7 no horizontal overflow at 320px",not bad,bad);await ctx.close()
        # B8 invalid route
        ctx,p,e=await page(br);await p.evaluate("location.hash='#/tool/nope'");await p.wait_for_timeout(200);rec("B8 invalid route shows home",(await p.inner_text("h1"))=="Tools");await ctx.close()
        # B9 joker is not an emoji
        ctx,p,e=await page(br)
        await p.evaluate("location.hash='#/tool/cards'");await p.wait_for_selector("#kqty")
        await p.click("text=Include 2 jokers");await p.fill("#kqty","54");await p.click("button:has-text('Draw cards')");await p.wait_for_timeout(300)
        rec("B9 no emoji in card results","🃏" not in await p.inner_text(".res"));await ctx.close()
        # B10 back button
        ctx,p,e=await page(br)
        await p.click(".grid .tool >> nth=0");await p.wait_for_timeout(300);await p.click(".back");await p.wait_for_timeout(300)
        await p.go_back();await p.wait_for_timeout(300);h1=await p.evaluate("(document.querySelector('h1')||{}).textContent||''")
        rec("B10 back arrow then system Back does not reopen the tool",h1!="Roulette",h1);await ctx.close()
        # B11 mid-spin edit keeps wheel and result consistent
        ctx,p,e=await page(br)
        await p.evaluate("location.hash='#/tool/roulette'");await p.click("button:has-text('Range')");await p.fill("#rmin","1");await p.fill("#rmax","8")
        await p.click("button:has-text('Spin the roulette!')");await p.wait_for_timeout(800);await p.fill("#rmax","5");await p.wait_for_timeout(6500)
        r=await p.inner_text("#res");win=await p.evaluate("document.querySelector('.stage canvas').dataset.win");rec("B11 wheel highlights the drawn value after mid-spin edit",win==r,(win,r));await ctx.close()
        # B12 numbers: exponent notation
        ctx,p,e=await page(br)
        await p.evaluate("location.hash='#/tool/numbers'");await p.wait_for_selector("#nmin")
        await p.fill("#nmin","1");await p.fill("#nmax","1e1");await p.fill("#nqty","1");await p.click("button:has-text('Draw')");await p.wait_for_timeout(1900)
        r=await p.inner_text(".res");t=await p.inner_text("#toast")
        rec("B12 '1e1' is read as 10 or rejected, never as 1",(r.strip()!="1" or "range" in t.lower()) ,(r,t));await ctx.close()
        await br.close()
    f=[r for r in res if not r[1]];print(f"\nPASSED {len(res)-len(f)} / FAILED {len(f)}")
asyncio.run(main())
