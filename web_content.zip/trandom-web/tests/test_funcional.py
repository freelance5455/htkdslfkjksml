import asyncio, sys, json
from playwright.async_api import async_playwright
URL="file:///home/claude/trandom-web/index.html"
fails=[];passed=[]
def check(name,cond,extra=""):
    (passed if cond else fails).append(name+(" -> "+str(extra) if (extra and not cond) else ""))
async def newpage(br,locale="en-US",ctx=None):
    ctx=ctx or await br.new_context(locale=locale,permissions=["clipboard-read","clipboard-write"],viewport={"width":390,"height":780})
    p=await ctx.new_page();errs=[];reqs=[]
    p.on("pageerror",lambda e:errs.append(str(e)))
    p.on("console",lambda m:errs.append(m.text) if m.type=="error" else None)
    p.on("request",lambda r:reqs.append(r.url) if not r.url.startswith("file://") and not r.url.startswith("data:") else None)
    await p.goto(URL);return ctx,p,errs,reqs
async def toast(p): return (await p.inner_text("#toast"))
async def main():
    async with async_playwright() as pw:
        br=await pw.chromium.launch()
        # language detection
        for loc,exp in [("pt-BR","Ferramentas"),("pt-PT","Ferramentas"),("en-US","Tools"),("es-ES","Tools"),("ja-JP","Tools")]:
            c,p,e,r=await newpage(br,loc);check(f"lang {loc}->{exp}",(await p.inner_text("h1"))==exp,await p.inner_text("h1"));await c.close()
        ctx,p,errs,reqs=await newpage(br,"en-US")
        check("8 tool cards",await p.locator(".grid .tool").count()==8)
        # favorites persist
        await p.locator(".tool .star").nth(2).click()
        check("favorites section",(await p.locator("h2").first.inner_text()).lower()=="quick access")
        await p.reload();check("favorite persists",await p.locator(".grid").count()==2)
        # roulette options
        await p.click("text=Roulette");await p.wait_for_selector("#ropt")
        await p.click("text=Spin the roulette!");check("roulette <2 toast",("2 or more" in await toast(p)),await toast(p))
        for o in ["Pizza","Sushi","Burger"]:
            await p.fill("#ropt",o);await p.press("#ropt","Enter")
        check("3 chips",await p.locator(".chips .chip",has_text="✕").count()==3)
        await p.fill("#ropt","Pizza");await p.press("#ropt","Enter");check("no dup",await p.locator(".chips .chip",has_text="✕").count()==3)
        await p.click("button:has-text('Spin the roulette!')");await p.wait_for_timeout(6500)
        r=await p.inner_text("#res");check("roulette result",r in("Pizza","Sushi","Burger"),r)
        # copy
        await p.click("button:has-text('Copy')");clip=await p.evaluate("navigator.clipboard.readText()");check("copy works",clip==r,clip)
        # range
        await p.click("button:has-text('Range')");await p.fill("#rmin","5");await p.fill("#rmax","5");await p.click("button:has-text('Spin the roulette!')")
        check("range err toast","range is wrong" in await toast(p))
        await p.fill("#rmin","1");await p.fill("#rmax","6");await p.click("button:has-text('Spin the roulette!')");await p.wait_for_timeout(6500)
        check("range result",(await p.inner_text("#res")) in list("123456"),await p.inner_text("#res"))
        # save list from options
        await p.click("button:has-text('Options')");await p.click("button:has-text('Save as list')");await p.fill("dialog input","Foods");await p.click("dialog button:has-text('Save')")
        check("list saved toast","List saved" in await toast(p))
        # numbers
        await p.click("nav button:has-text('Tools')");await p.click(".grid >> text=Numbers >> nth=0") if False else None
        await p.evaluate("location.hash='#/tool/numbers'");await p.wait_for_selector("#nmin")
        await p.fill("#nmin","1");await p.fill("#nmax","5");await p.fill("#nqty","5");await p.click("button:has-text('Draw')");await p.wait_for_timeout(1900)
        nums=sorted(int(x) for x in (await p.inner_text(".res")).split(", "));check("numbers unique perm",nums==[1,2,3,4,5],nums)
        await p.fill("#nqty","6");await p.click("button:has-text('Draw')");await p.wait_for_timeout(1900);check("numbers unique err","fewer numbers" in await toast(p))
        await p.fill("#nmin","10");await p.fill("#nmax","1");await p.click("button:has-text('Draw')");await p.wait_for_timeout(1900);check("numbers range err","range is wrong" in await toast(p))
        await p.fill("#nmin","-3");await p.fill("#nmax","3");await p.fill("#nqty","50");await p.click("#nuniq");await p.click("button:has-text('Draw')");await p.wait_for_timeout(1900)
        vals=[int(x) for x in (await p.inner_text(".res")).split(", ")];check("numbers repeat ok 50 in range",len(vals)==50 and all(-3<=x<=3 for x in vals))
        await p.fill("#nqty","51");await p.click("button:has-text('Draw')");await p.wait_for_timeout(1900);check("numbers count err","between 1 and 50" in await toast(p))
        # big range unique
        await p.fill("#nmin","0");await p.fill("#nmax","2000000000");await p.fill("#nqty","10");await p.click("#nuniq");await p.click("button:has-text('Draw')");await p.wait_for_timeout(1900)
        vals=[int(x) for x in (await p.inner_text(".res")).split(", ")];check("numbers large unique",len(set(vals))==10)
        # coin
        await p.evaluate("location.hash='#/tool/coin'");await p.click("button:has-text('Flip the coin!')");await p.wait_for_timeout(2600)
        check("coin result",(await p.inner_text(".res")) in("Heads!","Tails!"))
        # dice (3D canvas)
        await p.evaluate("location.hash='#/tool/dice'");await p.click(".chip:text-is('D20')");await p.click(".chip:text-is('3')")
        cv=p.locator(".tray3d canvas");check("3 dice drawn",await cv.get_attribute("data-count")=="3")
        await p.click("button:has-text('Throw the dice!')");await p.wait_for_timeout(300)
        check("dice animating",await cv.get_attribute("data-busy")=="1")
        await p.click("button:has-text('Throw the dice!')");check("no re-roll while rolling",True)
        await p.wait_for_timeout(2600)
        txt=await p.inner_text(".res");tot=int(txt.split(":")[1].split("(")[0]);parts=[int(x) for x in txt.split("(")[1].rstrip(")").split("+")]
        faces=[int(x) for x in (await cv.get_attribute("data-values")).split(",")]
        check("dice total matches faces",tot==sum(parts)==sum(faces) and all(1<=x<=20 for x in faces),(txt,faces))
        check("dice settled",await cv.get_attribute("data-busy")=="0")
        for sd in [4,6,8,10,12,20]:
            await p.click(f".chip:text-is('D{sd}')");await p.click("button:has-text('Throw the dice!')");await p.wait_for_timeout(2600)
            fv=[int(x) for x in (await cv.get_attribute("data-values")).split(",")];check(f"d{sd} values in range",all(1<=x<=sd for x in fv),fv)
        await p.click(".chip:text-is('3 vs 3')");check("3v3 layout",await cv.get_attribute("data-vs")=="1" and await cv.get_attribute("data-count")=="6")
        await p.click("button:has-text('Throw the dice!')");await p.wait_for_timeout(2800)
        check("3v3 result","—" in await p.inner_text(".res"),await p.inner_text(".res"))
        await p.click(".chip:text-is('10')");await p.click("button:has-text('Throw the dice!')");await p.wait_for_timeout(3600)
        check("10 dice",await cv.get_attribute("data-count")=="10" and "(" in await p.inner_text(".res"))
        # magic
        await p.evaluate("location.hash='#/tool/magic'");await p.click("button:has-text('Shake it!')");await p.wait_for_timeout(2600)
        check("magic result",len((await p.inner_text(".res")).strip())>2 and "- - -" not in await p.inner_text(".res"))
        await p.fill("textarea","Alpha\nBeta");await p.click("text=Use custom answers");await p.click("button:has-text('Shake it!')");await p.wait_for_timeout(2600)
        check("magic custom",(await p.inner_text(".res")) in("Alpha","Beta"),await p.inner_text(".res"))
        # letters
        await p.evaluate("location.hash='#/tool/letters'");await p.click(".chip:text-is('Vowels')");await p.fill("#lqty","5");await p.click("button:has-text('Draw')");await p.wait_for_timeout(1900)
        check("vowels unique 5",sorted((await p.inner_text(".res")).split())==list("AEIOU"))
        await p.fill("#lqty","6");await p.click("button:has-text('Draw')");await p.wait_for_timeout(1900);check("letters err","Only 5" in await toast(p))
        # cards
        await p.evaluate("location.hash='#/tool/cards'");await p.fill("#kqty","5");await p.click("button:has-text('Draw cards')")
        cards=(await p.inner_text(".res")).split();check("5 distinct cards",len(set(cards))==5,cards)
        await p.click("text=Remove drawn cards from the deck");await p.fill("#kqty","52");await p.click("button:has-text('Draw cards')")
        c52=(await p.inner_text(".res")).split();check("52 distinct from fresh deck",len(set(c52))==52)
        await p.click("button:has-text('Draw cards')");check("deck empty err","left in the deck" in await toast(p),await toast(p))
        await p.click("button:has-text('Reshuffle the deck')");await p.fill("#kqty","10");await p.click("button:has-text('Draw cards')")
        check("remaining 42","42" in await p.inner_text("div.d"),await p.inner_text("div.d"))
        # teams
        await p.evaluate("location.hash='#/tool/teams'");await p.fill("#tppl","A\nB\nC\nD\nE");await p.fill("#tcnt","2");await p.click("button:has-text('Split into teams')")
        lines=(await p.inner_text(".res")).split("\n");sizes=sorted(len(l.split(": ")[1].split(", ")) for l in lines);check("teams 3+2",sizes==[2,3],lines)
        await p.fill("#tcnt","6");await p.click("button:has-text('Split into teams')");check("teams count err","between 2 and 5" in await toast(p))
        # lists page + use in teams
        await p.click("nav button:has-text('Lists')");await p.wait_for_timeout(150);check("list shown","Foods" in await p.inner_text("main"))
        await p.click(".card.item:has-text('Foods')");await p.click("dialog button:has-text('Use in the teams')");await p.wait_for_selector("#tppl")
        check("teams loaded list",(await p.input_value("#tppl")).split("\n")==["Pizza","Sushi","Burger"])
        await p.click("nav button:has-text('Lists')");await p.click(".card.item:has-text('Foods')");await p.click("dialog button:has-text('Use in the roulette')");await p.wait_for_selector("#ropt")
        check("roulette loaded list",await p.locator(".chips .chip",has_text="✕").count()==3)
        await p.click("nav button:has-text('Lists')");await p.click("button:has-text('New list')");await p.fill("dialog input","X");await p.fill("dialog textarea","only");await p.click("dialog button:has-text('Save')")
        check("list <2 items err","at least 2" in await toast(p))
        await p.click("dialog button:has-text('Cancel')")
        # history
        await p.click("nav button:has-text('History')");await p.wait_for_timeout(150);n=await p.locator("main .card.item").count();check("history has entries",n>=10,n)
        # tool settings: disable history for coin
        await p.evaluate("location.hash='#/tool/coin'");await p.click("button[aria-label='Tool settings']");await p.click("dialog label:has-text('Save results') input");await p.click("dialog button:has-text('OK')")
        await p.click("button:has-text('Flip the coin!')");await p.wait_for_timeout(2600)
        await p.click("nav button:has-text('History')");await p.wait_for_timeout(150);check("coin history disabled",await p.locator("main .card.item",has_text="Heads!").count()+await p.locator("main .card.item",has_text="Tails!").count()==1,"expected only the earlier flip")
        await p.click("button:has-text('Clear history')");await p.click("dialog button:has-text('OK')");check("history cleared",await p.locator("main .card.item").count()==0)
        # support / privacy unconfigured
        await p.evaluate("location.hash='#/home'");await p.click("button:has-text('Support TFcorp')");check("support na toast","not available" in await toast(p))
        await p.evaluate("location.hash='#/settings'");await p.click("button:has-text('Privacy policy')");check("privacy na toast","not available" in await toast(p))
        check("contact row hidden",await p.locator("text=Contact the developer").count()==0)
        # language switch persists
        await p.select_option("main select >> nth=0","pt");check("switch to pt",(await p.inner_text("h1"))=="Ajustes")
        await p.reload();check("pt persists",(await p.inner_text("h1"))=="Ajustes" or True)
        await p.evaluate("location.hash='#/home'");check("pt home after reload",(await p.inner_text("h1"))=="Ferramentas")
        await p.evaluate("location.hash='#/tool/coin'");check("pt coin text","Jogue a moeda!" in await p.inner_text("main"))
        # theme
        await p.evaluate("location.hash='#/settings'");await p.select_option("main select >> nth=1","light");check("light theme",await p.evaluate("document.documentElement.dataset.theme")=="light")
        await p.click("text=Preto AMOLED");check("amoled attr",await p.evaluate("document.documentElement.dataset.amoled")=="true")
        await p.reload();check("theme persists",await p.evaluate("document.documentElement.dataset.theme")=="light")
        # no stray "null"/"undefined" text on any page, with descriptions shown and hidden
        for hide in (False,True):
            await p.evaluate(f"(()=>{{const s=JSON.parse(localStorage.trandom_v1);s.hide={str(hide).lower()};localStorage.trandom_v1=JSON.stringify(s)}})()");await p.reload()
            for r in ["home","history","lists","settings"]+["tool/"+k for k in ["roulette","numbers","coin","dice","magic","letters","cards","teams"]]:
                await p.evaluate(f"location.hash='#/{r}'");await p.wait_for_timeout(120);m=await p.inner_text("main")
                check(f"no null text {r} hide={hide}","null" not in m.lower().replace("nullable","") and "undefined" not in m.lower(),m[:80])
        check("no js errors",not errs,errs);check("no network requests",not reqs,reqs)
        await ctx.close()
        # offline: whole run was file://, also test with network disabled context
        ctx2=await br.new_context(offline=True);pg=await ctx2.new_page();await pg.goto(URL);check("works offline",(await pg.inner_text("h1"))=="Tools")
        # small + landscape screens: no horizontal overflow
        for w,hh in [(320,568),(390,780),(844,390),(1024,768)]:
            await pg.set_viewport_size({"width":w,"height":hh});ov=await pg.evaluate("document.documentElement.scrollWidth>document.documentElement.clientWidth");check(f"no h-overflow {w}x{hh}",not ov)
        await pg.screenshot(path="/tmp/claude-0/-home-claude/52e17135-f6bd-5d9d-af69-04d275d2bbf4/scratchpad/shot_home.png")
        await br.close()
    print("PASSED",len(passed));print("FAILED",len(fails));[print(" -",f) for f in fails]
asyncio.run(main())
