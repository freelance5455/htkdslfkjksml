Vetho Calculate's
A lightweight mobile-friendly calculator.
Main file: index.html
Open index.html in a browser to test.
Import the project ZIP into a compatible HTML-to-APK builder.
