// =====================================================================
// FORM STUDIO — app.js
// =====================================================================

// ---------- MOBILE SIDEBAR ----------
function getSidebarOverlay() {
    let overlay = document.querySelector(".sidebar-overlay");

    if (!overlay) {
        overlay = document.createElement("div");
        overlay.className = "sidebar-overlay";
        overlay.addEventListener("click", closeSidebar);
        document.body.appendChild(overlay);
    }

    return overlay;
}

function openSidebar() {
    const sidebar = document.getElementById("sidebar");
    if (!sidebar) return;

    sidebar.classList.add("open");
    getSidebarOverlay().classList.add("show");
}

function closeSidebar() {
    const sidebar = document.getElementById("sidebar");
    if (sidebar) sidebar.classList.remove("open");

    const overlay = document.querySelector(".sidebar-overlay");
    if (overlay) overlay.classList.remove("show");
}

function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    if (!sidebar) return;

    if (sidebar.classList.contains("open")) {
        closeSidebar();
    } else {
        openSidebar();
    }
}

// মেনুতে ক্লিক করলে বা Esc চাপলে মোবাইলে সাইডবার বন্ধ হবে
document.addEventListener("click", function (event) {
    if (event.target.closest("#sidebar .menu-link")) {
        closeSidebar();
    }
});

document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") closeSidebar();
});

// স্ক্রিন বড় হলে ওভারলে বন্ধ করে দেওয়া
window.addEventListener("resize", function () {
    if (window.innerWidth > 900) closeSidebar();
});


// ---------- PRINT / SAVE PDF ----------
function printForm() {
    window.print();
}


// ---------- CLEAR ALL INPUTS ----------
function clearForm() {

    const confirmed = confirm("আপনি কি সকল তথ্য মুছে ফেলতে চান?");

    if (!confirmed) return;

    document.querySelectorAll("#printArea input").forEach(input => {

        if (input.type === "checkbox" || input.type === "radio") {
            input.checked = false;
        } else {
            input.value = "";
        }

        // প্রিন্টে যেন পুরনো মান না থাকে
        input.setAttribute("value", "");

    });

    document.querySelectorAll("#printArea textarea").forEach(input => {
        input.value = "";
        input.textContent = "";
    });

    document.querySelectorAll("#printArea select").forEach(input => {
        input.selectedIndex = 0;
    });

}


// ---------- HELP ----------
function showInstructions() {

    alert(
        "FORM STUDIO HELP\n\n" +
        "1. Sidebar থেকে ফর্ম নির্বাচন করুন।\n" +
        "2. ফর্মের ঘরে তথ্য লিখুন।\n" +
        "3. Print বাটনে ক্লিক করুন।\n" +
        "4. Destination থেকে Save as PDF নির্বাচন করুন।\n" +
        "5. নতুন ফর্ম যোগ করতে forms ফোল্ডারে HTML ফাইল তৈরি করুন।"
    );

}


// ---------- LIVE INPUT PREVIEW ----------
document.addEventListener("input", function (event) {

    if (event.target.closest("#printArea")) {

        const input = event.target;

        input.setAttribute("value", input.value);

        if (input.tagName === "TEXTAREA") {
            input.textContent = input.value;
        }

    }

});


// ---------- DIGIT INPUT AUTO MOVE ----------
document.addEventListener("input", function (event) {

    if (!event.target.classList.contains("digit-input")) return;

    event.target.value = event.target.value.replace(/[^0-9]/g, "").slice(0, 1);

    if (event.target.value && event.target.nextElementSibling) {
        event.target.nextElementSibling.focus();
    }

});


// ---------- BACKSPACE MOVE ----------
document.addEventListener("keydown", function (event) {

    if (
        event.key === "Backspace" &&
        event.target.classList.contains("digit-input") &&
        !event.target.value &&
        event.target.previousElementSibling
    ) {
        event.target.previousElementSibling.focus();
    }

});
