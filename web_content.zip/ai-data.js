/* JOSTECH — BASE DE CONNAISSANCES COMPLÈTE (10 DISCIPLINES) */
const AI_KNOWLEDGE = [
  {
    keys: ["ordinateur", "informatique", "von neumann", "processeur", "cpu", "ram", "ual", "alu", "bus", "fetch", "harvard"],
    title: "Ordinateur & Architecture de Von Neumann",
    ans: "L'informatique est la science du traitement automatique de l'information. Selon le modèle de Von Neumann (1945), un ordinateur réunit 4 organes : UAL (calculs), Unité de Contrôle (orchestration Fetch-Decode-Execute), RAM (programmes + données) et Entrées/Sorties, reliés par les bus de données, d'adresses et de contrôle."
  },
  {
    keys: ["binaire", "octet", "bit", "hexadecimal", "numeration", "complement", "ascii", "utf8", "codage"],
    title: "Systèmes de numération & Codage",
    ans: "Le binaire (base 2 : 0 et 1) reflète l'état des transistors. 1 octet = 8 bits (256 valeurs). Pour passer du binaire à l'hexadécimal (base 16), regroupez par 4 bits (ex: 1010 = A, 1111 = F). Pour un négatif en Complément à 2 : inversez tous les bits puis ajoutez 1."
  },
  {
    keys: ["boole", "booleen", "porte", "logique", "nand", "xor", "morgan", "verite"],
    title: "Algèbre de Boole & Portes logiques",
    ans: "L'algèbre de Boole manipule Vrai (1) et Faux (0). La porte NAND est universelle. Les lois de De Morgan disent : NON(A ET B) = (NON A) OU (NON B), et NON(A OU B) = (NON A) ET (NON B). Le XOR vaut 1 uniquement si A et B diffèrent."
  },
  {
    keys: ["cache", "sram", "dram", "localite", "pipeline", "amat", "memoire"],
    title: "Hiérarchie Mémoire & Caches CPU",
    ans: "La RAM (DRAM, ~80 ns) est lente face au CPU (~0,3 ns). Les caches L1/L2/L3 en SRAM (1 à 15 ns) chargent des lignes de 64 octets en exploitant la localité temporelle (variable réutilisée) et spatiale (cases voisines d'un tableau)."
  },
  {
    keys: ["algorithme", "algorithmique", "variable", "boucle", "python", "modulo", "fonction", "return", "recursivite", "recursif"],
    title: "Algorithmique, Python & Fonctions",
    ans: "Un algorithme est une suite finie et non ambiguë d'instructions. Attention : '=' affecte et '==' compare. Utilisez 'return' (et non print) pour renvoyer une valeur depuis une fonction. En récursivité, prévoyez toujours un cas de base et une convergence."
  },
  {
    keys: ["pointeur", "pointeurs", "malloc", "free", "pile", "stack", "heap", "adresse", "segmentation"],
    title: "Pointeurs & Mémoire en Langage C",
    ans: "En C, un pointeur stocke une adresse RAM (&x = adresse de x ; *p = contenu pointé). Les variables locales vivent sur la Pile (automatique), tandis que malloc() alloue sur le Tas (libération obligatoire avec free() pour éviter les fuites mémoire)."
  },
  {
    keys: ["poo", "objet", "classe", "heritage", "encapsulation", "polymorphisme", "complexite", "bigo", "dichotomique"],
    title: "POO & Complexité Big-O",
    ans: "Les 4 piliers de la POO : Abstraction, Encapsulation (protection des données), Héritage et Polymorphisme. En analyse Big-O : O(1) constant, O(log n) très rapide (~20 étapes sur 1 million d'éléments), O(n) linéaire, O(n²) à éviter."
  },
  {
    keys: ["html", "html5", "css", "css3", "semantique", "padding", "margin", "flexbox", "grid", "responsive"],
    title: "HTML5 & CSS3 Responsive",
    ans: "HTML5 structure le sens (<header>, <nav>, <main>, <article>). En CSS : content → padding (marge interne) → border → margin (marge externe). Utilisez 'box-sizing: border-box' pour éviter les débordements, et Flexbox/Grid pour le Mobile-First."
  },
  {
    keys: ["javascript", "dom", "xss", "fetch", "async", "await", "json", "localstorage", "evenement"],
    title: "JavaScript, DOM & Sécurité XSS",
    ans: "Le DOM est l'arbre HTML en mémoire. Utilisez async/await avec fetch() et try/catch pour ne pas figer l'écran. Contre la faille XSS, n'utilisez jamais innerHTML avec une saisie utilisateur : utilisez textContent !"
  },
  {
    keys: ["rest", "api", "http", "https", "jwt", "pwa", "cors", "stateless"],
    title: "API REST, JWT & PWA",
    ans: "En REST : GET lit (200), POST crée (201), PUT modifie, DELETE supprime (204). 401 = non connecté ; 403 = interdit. Le jeton JWT est signé côté serveur, et une PWA combine manifest.json + Service Worker."
  },
  {
    keys: ["sql", "mysql", "postgresql", "base", "donnees", "bdd", "relationnel", "select", "table", "cybersecurite", "cryptographie", "chiffrement", "reseau", "reseaux", "osi", "tcp", "robotique", "arduino", "intelligence", "machine", "learning"],
    title: "Bases de données, Réseaux, Cybersécurité, IA & Robotique",
    ans: "SQL (SELECT, INSERT, WHERE) interroge les bases relationnelles. Les réseaux reposent sur les modèles OSI (7 couches) et TCP/IP. La cybersécurité protège par cryptographie et contrôle des vulnérabilités. L'IA apprend par Machine/Deep Learning, et la Robotique pilote capteurs et actionneurs via microcontrôleurs (Arduino)."
  }
];