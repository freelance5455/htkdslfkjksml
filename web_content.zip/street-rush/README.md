# Street Rush
3-lane endless runner. Plain HTML/CSS/JS, no libraries, no external images.
Open index.html in a browser.

Controls: Left/Right (A/D) lane, Up/W/Space jump, Down/S slide. Touch: swipe.
Jump over orange barriers, slide under teal bars, dodge cars, collect coins.

Features: home screen, 5 unlockable skins, 5 worlds (portal every 25 s),
procedurally drawn buildings/trees/cars, blinking headlights, sun rays,
lagging camera with roll, vibration on coin pickup (Android), high score and coins saved in localStorage.

Tweak: WORLD_SECS, SKINS, WORLDS, CARS at the top of game.js.
