'use strict';
// Street Rush - original 3-lane endless runner (canvas pseudo-3D). No libraries, no external images.
const $ = id => document.getElementById(id);
const cv = $('game'), ctx = cv.getContext('2d');
const pcv = $('prev'), pctx = pcv.getContext('2d');
let W, H, K, DPR, HY, GY;
function resize(){
  DPR = Math.min(window.devicePixelRatio || 1, 1.5);          // cap resolution for speed
  W = innerWidth; H = innerHeight;
  cv.width = W * DPR; cv.height = H * DPR;
  K = Math.min(W * .3, H * .3);                                 // pixels per world unit at depth 0
  HY = H * (W > H ? .22 : .3);                                  // horizon
  GY = H * .88;                                                 // ground line at player depth
}
addEventListener('resize', resize); resize();

/* ---------- helpers ---------- */
const hex = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
const rgb = (c, f = 1) => `rgb(${Math.min(255, c[0] * f) | 0},${Math.min(255, c[1] * f) | 0},${Math.min(255, c[2] * f) | 0})`;
const rgba = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
const hsh = (a, b, c) => ((a * 374761393 + b * 668265263 + c * 1274126177) >>> 0) % 100;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

let PX, PY, PS, camX = 0;
function pj(x, z, y){ const t = 1 / (1 + z * .12); PS = t; PX = W / 2 + (x - camX) * K * t; PY = HY + (GY - HY) * t - y * K * t; }
const pts = [];
function P(x, z, y){ pj(x, z, y); pts.push(PX, PY); }
function poly(col){
  ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
  ctx.closePath(); ctx.fill(); pts.length = 0;
}
function addQuad(path){
  path.moveTo(pts[0], pts[1]); path.lineTo(pts[2], pts[3]); path.lineTo(pts[4], pts[5]); path.lineTo(pts[6], pts[7]);
  path.closePath(); pts.length = 0;
}
const topVisible = h => (GY - HY) - h * K > 0;
const fogA = z => z > 34 ? Math.max(0, 1 - (z - 34) / 32) : 1;

/* ---------- save data ---------- */
let SAVE = { best: 0, wallet: 0, skin: 0, owned: [0], vib: true, snd: true };
try { Object.assign(SAVE, JSON.parse(localStorage.getItem('streetrush') || '{}')); } catch (e) {}
function save(){ try { localStorage.setItem('streetrush', JSON.stringify(SAVE)); } catch (e) {} }
function vib(ms){ if (SAVE.vib && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) {} } }
let AC;
function beep(f, d, type, v){
  if (!SAVE.snd) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime;
    o.type = type || 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(v || .05, t); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + d);
  } catch (e) {}
}

/* ---------- worlds ---------- */
const WORLDS = [
  { name: 'Sunny City', style: 'city', top: '#3d9bff', mid: '#8fd0ff', bot: '#dff2ff', ground: '#8d9096', side: '#b9bcc2', road: '#3a3d44', line: '#f2f2f2',
    sun: 1, night: 0, snow: 0, sunC: '#fff2b0', sunX: .72, sunY: .45, sunR: .07, acc: '#4aa8ff',
    b: ['#c9b8a0', '#9fb3c8', '#d6c3b0', '#a8a8b8', '#b8c4a8'], win: ['#d8efff', '#6f8fae'], hmin: 3, hr: 5 },
  { name: 'Desert Sunset', style: 'desert', top: '#5a2a6e', mid: '#ff8a4a', bot: '#ffd08a', ground: '#d9a35f', side: '#e6bd82', road: '#5b4a3c', line: '#ffe9c0',
    sun: 1, night: 0, snow: 0, sunC: '#ffb060', sunX: .3, sunY: .85, sunR: .12, acc: '#ff8a4a',
    b: ['#d9a066', '#c88a55', '#e0b07a', '#b97a4a'], win: ['#ffcf7a', '#7a4a28'], hmin: 1.6, hr: 2 },
  { name: 'Neon Night', style: 'neon', top: '#06021f', mid: '#25104f', bot: '#5b1a7a', ground: '#0d0b22', side: '#1d1a3a', road: '#17172c', line: '#35e0ff',
    sun: .5, night: 1, snow: 0, sunC: '#dfe9ff', sunX: .25, sunY: .4, sunR: .05, acc: '#ff4fd8',
    b: ['#1b1740', '#241a52', '#12163a'], win: ['#ff4fd8', '#35e0ff'], neon: ['#ff4fd8', '#35e0ff', '#ffe14a'], hmin: 4, hr: 6 },
  { name: 'Snow Valley', style: 'snow', top: '#7e9bc4', mid: '#c2d6ee', bot: '#eef5fc', ground: '#f4f8fc', side: '#dfe8f2', road: '#59606c', line: '#ffffff',
    sun: .6, night: 0, snow: 1, sunC: '#fff8e0', sunX: .65, sunY: .5, sunR: .06, acc: '#9fd3ff',
    b: ['#8a6f5a', '#a5846b', '#7b8aa0', '#9b7b62'], win: ['#ffe9a6', '#46556b'], hmin: 2.4, hr: 3 },
  { name: 'Green Forest', style: 'forest', top: '#4fb4ff', mid: '#a9e0ff', bot: '#e4f7d8', ground: '#3d8c48', side: '#6fae5b', road: '#4a4a4a', line: '#f4f4f4',
    sun: 1, night: 0, snow: 0, sunC: '#fff0a8', sunX: .78, sunY: .4, sunR: .07, acc: '#5be37d',
    tree: ['#2f8f46', '#3aa655', '#277a3d'], hmin: 2.2, hr: 2.2 }
];
WORLDS.forEach(w => { w.bRgb = (w.b || []).map(hex); w.tRgb = (w.tree || []).map(hex); w.accRgb = hex(w.acc); });
const ENV_COLORS = ['top', 'mid', 'bot', 'ground', 'side', 'road', 'line', 'sunC'];
const ENV_NUMS = ['sun', 'night', 'snow', 'sunX', 'sunY', 'sunR'];
function makeEnv(w){ const e = {}; ENV_COLORS.forEach(k => e[k] = hex(w[k])); ENV_NUMS.forEach(k => e[k] = w[k]); return e; }
function lerpEnv(a, b, t){
  const e = {};
  ENV_COLORS.forEach(k => e[k] = a[k].map((v, i) => v + (b[k][i] - v) * t));
  ENV_NUMS.forEach(k => e[k] = a[k] + (b[k] - a[k]) * t);
  return e;
}

/* ---------- skins ---------- */
const SKINS = [
  { name: 'Blaze',  cost: 0,   shirt: '#ff6b35', pants: '#2d3a8c', shoe: '#ffffff', hair: '#2b1b12', skin: '#e8b48a', pack: '#ffd23f', hat: null },
  { name: 'Frost',  cost: 60,  shirt: '#4cc9f0', pants: '#22304f', shoe: '#e9f7ff', hair: '#d9d9d9', skin: '#f3cfb0', pack: '#ffffff', hat: 'beanie', hatC: '#1e88e5' },
  { name: 'Jade',   cost: 150, shirt: '#2ec4b6', pants: '#12372a', shoe: '#ffd23f', hair: '#3b2414', skin: '#c68b5e', pack: '#ff6b35', hat: 'cap', hatC: '#ffd23f' },
  { name: 'Shadow', cost: 300, shirt: '#2a2a33', pants: '#15151b', shoe: '#e63946', hair: '#000000', skin: '#8d5a3b', pack: '#e63946', hat: 'hood', hatC: '#1d1d25' },
  { name: 'Gold',   cost: 600, shirt: '#ffd23f', pants: '#8a5a00', shoe: '#fff6c9', hair: '#5a3a00', skin: '#e8b48a', pack: '#ffffff', hat: 'crown', hatC: '#ffcf33' }
];

/* ---------- character drawing (feet at 0,0; 1.8 units tall) ---------- */
function rr(c, x, y, w, h, r){ c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
function limb(c, x1, y1, x2, y2, w, col){ c.strokeStyle = col; c.lineWidth = w; c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke(); }
function drawChar(c, sk, x, y, u, ph, pose, lean){
  c.save(); c.translate(x, y); c.scale(u, u); c.lineCap = 'round';
  const run = pose === 'run', jump = pose === 'jump';
  if (pose === 'slide') c.scale(1, .55);
  c.rotate(lean * .3);
  c.translate(0, run ? -Math.abs(Math.cos(ph)) * .06 : 0);
  for (const sg of [-1, 1]){                                    // legs
    const lift = run ? Math.max(0, Math.sin(ph + (sg > 0 ? 0 : Math.PI))) * .3 : (jump ? (sg > 0 ? .45 : .2) : 0);
    limb(c, sg * .11, -.9, sg * .13, -.5 - lift * .6, .17, sk.pants);
    limb(c, sg * .13, -.5 - lift * .6, sg * .13, -lift - .05, .15, sk.pants);
    c.fillStyle = sk.shoe; c.beginPath(); c.ellipse(sg * .13, -lift - .03, .12, .07, 0, 0, 7); c.fill();
  }
  c.fillStyle = sk.shirt; rr(c, -.27, -1.45, .54, .62, .12); c.fill();   // torso
  c.fillStyle = 'rgba(0,0,0,.14)'; rr(c, -.27, -1.02, .54, .19, .08); c.fill();
  c.fillStyle = sk.pack; rr(c, -.18, -1.38, .36, .42, .08); c.fill();    // backpack
  c.fillStyle = 'rgba(0,0,0,.2)'; rr(c, -.13, -1.2, .26, .1, .03); c.fill();
  for (const sg of [-1, 1]){                                    // arms
    let hx = sg * .38, hy;
    if (jump){ hx = sg * .44; hy = -1.75; }
    else hy = -.85 - (run ? Math.sin(ph + (sg > 0 ? Math.PI : 0)) * .22 : 0);
    limb(c, sg * .3, -1.38, hx, hy, .13, sk.shirt);
    c.fillStyle = sk.skin; c.beginPath(); c.arc(hx, hy, .065, 0, 7); c.fill();
  }
  c.fillStyle = sk.skin; c.fillRect(-.06, -1.5, .12, .1);              // neck
  c.beginPath(); c.arc(0, -1.65, .21, 0, 7); c.fill();                  // head
  c.beginPath(); c.arc(-.21, -1.62, .04, 0, 7); c.arc(.21, -1.62, .04, 0, 7); c.fill();
  c.fillStyle = sk.hair; c.beginPath(); c.arc(0, -1.66, .215, 0, 7); c.fill();
  if (sk.hat === 'cap'){ c.fillStyle = sk.hatC; c.beginPath(); c.arc(0, -1.68, .23, Math.PI, 0); c.fill(); rr(c, -.08, -1.64, .16, .05, .02); c.fill(); }
  else if (sk.hat === 'beanie'){ c.fillStyle = sk.hatC; c.beginPath(); c.arc(0, -1.68, .24, Math.PI, 0); c.fill(); c.fillStyle = 'rgba(0,0,0,.2)'; rr(c, -.24, -1.7, .48, .07, .03); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.arc(0, -1.93, .06, 0, 7); c.fill(); }
  else if (sk.hat === 'hood'){ c.fillStyle = sk.hatC; c.beginPath(); c.arc(0, -1.64, .26, 0, 7); c.fill(); c.fillStyle = 'rgba(255,255,255,.15)'; rr(c, -.04, -1.9, .08, .22, .03); c.fill(); }
  else if (sk.hat === 'crown'){ c.fillStyle = sk.hatC; c.beginPath(); c.moveTo(-.2, -1.8); c.lineTo(-.2, -1.97); c.lineTo(-.1, -1.88); c.lineTo(0, -2.0); c.lineTo(.1, -1.88); c.lineTo(.2, -1.97); c.lineTo(.2, -1.8); c.closePath(); c.fill(); }
  c.restore();
}

/* ---------- game state ---------- */
const ZMAX = 62, WORLD_SECS = 25;
let mode = 'home', time = 0, dist = 0, speed = 9, coins = 0, score = 0, shake = 0, crashT = 0, newBest = false;
let player = { lane: 1, x: 0, y: 0, vy: 0, slide: 0, ph: 0 };
let objs = [], blds = [], parts = [], lights = [], portal = null;
let spawnZ = 25, bz = [-2, -2], spawnWorld = 0, worldIdx = 0, worldTimer = 0;
let env = makeEnv(WORLDS[0]), envFrom = null, envTo = null, envT = 1, tilt = 0;
let SX = 0, SY = 0, SR = 10;
const stars = Array.from({ length: 50 }, () => [Math.random(), Math.random() * .9, Math.random() * 1.6 + .4]);
const flakes = Array.from({ length: 70 }, () => ({ x: Math.random(), y: Math.random(), v: 40 + Math.random() * 50, r: 1 + Math.random() * 2, s: Math.random() * 6 }));
const CARS = [
  { len: 2.6, hb: .7, hc: 1.3, cs: .7, ce: 2.0, van: 0 },
  { len: 2.8, hb: .8, hc: 1.5, cs: .5, ce: 2.5, van: 0 },
  { len: 4.0, hb: .8, hc: 2.05, van: 1 }
];
const CCOL = [[200, 40, 50], [40, 90, 200], [235, 235, 235], [170, 175, 185], [245, 200, 30], [35, 35, 40], [40, 160, 90], [230, 120, 30]];

function initWorld(i){
  worldIdx = spawnWorld = i; env = makeEnv(WORLDS[i]); envFrom = null; envT = 1;
  blds = []; objs = []; portal = null; bz = [-2, -2]; worldTimer = 0; spawnZ = 25;
  spawnBuildings();
}
function startTransition(i){
  envFrom = env; envTo = makeEnv(WORLDS[i]); envT = 0; worldIdx = i;
  const b = $('banner'); b.textContent = WORLDS[i].name; b.classList.remove('show'); void b.offsetWidth; b.classList.add('show');
}
function spawnBuildings(){
  for (let s = 0; s < 2; s++){
    const side = s ? 1 : -1;
    while (bz[s] < ZMAX + 12){
      const wi = (portal && bz[s] >= portal.z) ? portal.next : spawnWorld, w = WORLDS[wi];
      if (w.style === 'forest'){
        blds.push({ k: 't', side, z: bz[s], len: 0, h: 1.8 + Math.random() * 2, x: 2.3 + Math.random() * 2.5, wi, c: Math.random() * 3 | 0 });
        bz[s] += 1.8 + Math.random() * 2.5;
      } else {
        const len = 4 + Math.random() * 4;
        blds.push({ k: 'b', side, z: bz[s], len, h: w.hmin + Math.random() * w.hr, w: 2.6, wi, c: Math.random() * w.b.length | 0, seed: Math.random() * 1000 | 0 });
        bz[s] += len + .4 + Math.random() * 1.2;
      }
    }
  }
}
function addCar(lane){
  const T = CARS[Math.random() * CARS.length | 0];
  objs.push({ t: 'car', lane, z: spawnZ, len: T.len, T, c: CCOL[Math.random() * CCOL.length | 0], v: Math.random() * 4, seed: Math.random() });
}
function spawnObstacles(){
  while (spawnZ < ZMAX + 12){
    const r = Math.random(), lane = Math.random() * 3 | 0;
    if (r < .45){ addCar(lane); if (Math.random() < .3) addCar((lane + 1 + (Math.random() * 2 | 0)) % 3); }
    else if (r < .6) objs.push({ t: 'barrier', lane, z: spawnZ, len: .5 });
    else if (r < .72) objs.push({ t: 'bar', lane, z: spawnZ, len: .4 });
    else for (let i = 0; i < 6; i++) objs.push({ t: 'coin', lane, z: spawnZ + i * 1.4, len: .5 });
    spawnZ += 9 + Math.random() * 6;
  }
}

/* ---------- input ---------- */
const playing = () => mode === 'play';
function move(d){ if (playing()) player.lane = clamp(player.lane + d, 0, 2); }
function jump(){ if (playing() && player.y === 0){ player.vy = 9; } }
function slide(){ if (playing()){ player.slide = .7; if (player.y > 0) player.vy = -16; } }
addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  if (k === 'arrowleft' || k === 'a') move(-1);
  else if (k === 'arrowright' || k === 'd') move(1);
  else if (k === 'arrowup' || k === 'w' || k === ' ') jump();
  else if (k === 'arrowdown' || k === 's') slide();
});
let tx = 0, ty = 0;
addEventListener('touchstart', e => { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
addEventListener('touchend', e => {
  const dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty;
  if (Math.abs(dx) > Math.abs(dy)){ if (Math.abs(dx) > 25) move(dx > 0 ? 1 : -1); }
  else if (Math.abs(dy) > 25) dy < 0 ? jump() : slide();
}, { passive: true });

/* ---------- UI ---------- */
let view = SAVE.skin;
function refreshHome(){
  $('hBest').textContent = SAVE.best; $('hCoins').textContent = SAVE.wallet;
  $('skinName').textContent = SKINS[view].name;
  const own = SAVE.owned.includes(view), b = $('skinBtn');
  if (own){ b.textContent = SAVE.skin === view ? 'Equipped' : 'Equip'; b.disabled = SAVE.skin === view; }
  else { b.textContent = 'Unlock for ' + SKINS[view].cost + ' coins'; b.disabled = SAVE.wallet < SKINS[view].cost; }
  $('optVib').checked = SAVE.vib; $('optSnd').checked = SAVE.snd;
}
$('prevSkin').onclick = () => { view = (view + SKINS.length - 1) % SKINS.length; refreshHome(); };
$('nextSkin').onclick = () => { view = (view + 1) % SKINS.length; refreshHome(); };
$('skinBtn').onclick = () => {
  if (!SAVE.owned.includes(view)){ if (SAVE.wallet < SKINS[view].cost) return; SAVE.wallet -= SKINS[view].cost; SAVE.owned.push(view); }
  SAVE.skin = view; save(); refreshHome();
};
$('optVib').onchange = e => { SAVE.vib = e.target.checked; save(); if (SAVE.vib) vib(30); };
$('optSnd').onchange = e => { SAVE.snd = e.target.checked; save(); };
$('play').onclick = $('again').onclick = startGame;
$('homeBtn').onclick = goHome;

function startGame(){
  try { AC = AC || new (window.AudioContext || window.webkitAudioContext)(); AC.resume(); } catch (e) {}
  $('home').classList.add('hidden'); $('over').classList.add('hidden'); $('hud').classList.remove('hidden');
  initWorld(0); player = { lane: 1, x: 0, y: 0, vy: 0, slide: 0, ph: 0 };
  speed = 14; dist = 0; coins = 0; score = 0; parts = []; mode = 'play'; camX = 0;
  $('hbest').textContent = 'Best ' + SAVE.best;
}
function goHome(){
  $('over').classList.add('hidden'); $('hud').classList.add('hidden'); $('home').classList.remove('hidden');
  mode = 'home'; initWorld(0); view = SAVE.skin; refreshHome();
}
function die(){
  mode = 'crash'; crashT = .8; shake = .5;
  vib(250); beep(90, .4, 'sawtooth', .1);
  newBest = score > SAVE.best; if (newBest) SAVE.best = score;
  SAVE.wallet += coins; save();
}
function showOver(){
  $('hud').classList.add('hidden');
  $('overTitle').textContent = newBest ? 'New best!' : 'Crashed';
  $('overScore').textContent = score;
  $('overBest').textContent = 'Best ' + SAVE.best;
  $('overCoins').textContent = '+' + coins + ' coins  (wallet ' + SAVE.wallet + ')';
  $('over').classList.remove('hidden');
}
function getCoin(){
  coins++; vib(12); beep(880, .07, 'square', .035); setTimeout(() => beep(1320, .09, 'square', .035), 55);
  pj(player.x, 0, .9);
  for (let i = 0; i < 10; i++) parts.push({ x: PX, y: PY, vx: (Math.random() - .5) * 260, vy: -Math.random() * 280 - 40, l: .5 });
}

/* ---------- update ---------- */
function update(dt){
  time += dt;
  for (const p of parts){ p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 700 * dt; p.l -= dt; }
  parts = parts.filter(p => p.l > 0);
  if (shake > 0) shake = Math.max(0, shake - dt);
  if (mode === 'crash'){ crashT -= dt; if (crashT <= 0){ mode = 'over'; showOver(); } return; }
  if (mode === 'over') return;

  const play = mode === 'play';
  speed = play ? Math.min(34, speed + dt * .35) : 9;
  const v = speed * dt; dist += v;
  for (const o of objs) o.z -= (speed + (o.v || 0)) * dt;
  for (const b of blds) b.z -= v;
  spawnZ -= v; bz[0] -= v; bz[1] -= v;

  // portals / world changes
  worldTimer += dt;
  if (!portal && worldTimer > (play ? WORLD_SECS : 9)){
    const nx = (spawnWorld + 1) % WORLDS.length;
    portal = { t: 'portal', z: Math.max(bz[0], bz[1], spawnZ) + 3, len: .4, next: nx };
    objs.push(portal);
  }
  if (portal && portal.z < 0){ spawnWorld = portal.next; startTransition(portal.next); portal = null; worldTimer = 0; }
  if (envFrom){ envT += dt / 2; if (envT >= 1){ env = envTo; envFrom = null; } else { const s = envT * envT * (3 - 2 * envT); env = lerpEnv(envFrom, envTo, s); } }

  // camera follows the runner with a lag and a little roll
  const camT = player.x * .55;
  camX += (camT - camX) * Math.min(1, dt * 2.2);
  tilt += ((camX - camT) * .05 - tilt) * Math.min(1, dt * 5);

  if (play){
    player.x += (player.lane - 1 - player.x) * Math.min(1, dt * 13);
    if (player.y > 0 || player.vy > 0){ player.vy -= 24 * dt; player.y += player.vy * dt; if (player.y <= 0){ player.y = 0; player.vy = 0; } }
    if (player.slide > 0) player.slide -= dt;
    player.ph += dt * (8 + speed * .25);
    spawnObstacles();
    for (const o of objs){
      if (o.dead || o.t === 'portal') continue;
      const dx = Math.abs(o.lane - 1 - player.x);
      if (o.t === 'coin'){ if (dx < .5 && o.z < .8 && o.z > -.4){ o.dead = true; getCoin(); } continue; }
      if (o.z > .5 || o.z + o.len < -.3) continue;
      if (o.t === 'car' && dx < .62) return die();
      if (o.t === 'barrier' && dx < .5 && player.y < .65) return die();
      if (o.t === 'bar' && dx < .5 && player.slide <= 0 && player.y < 1.25) return die();
    }
    score = Math.floor(dist) + coins * 10;
    $('score').textContent = score; $('coins').textContent = coins;
  }
  spawnBuildings();
  objs = objs.filter(o => !o.dead && o.z + o.len > -3);
  blds = blds.filter(b => b.z + b.len > -3);
  for (const f of flakes){ f.y += f.v * dt / H; f.x += Math.sin(time + f.s) * .0004; if (f.y > 1){ f.y = 0; f.x = Math.random(); } }
}

/* ---------- drawing ---------- */
function box(x, z0, z1, hw, y0, y1, col, front){
  z0 = Math.max(z0, -1.3); if (z1 < z0 + .05) return;
  const rel = x - camX;
  if (Math.abs(rel) > hw){ const sx = x + (rel > 0 ? -hw : hw); P(sx, z0, y0); P(sx, z1, y0); P(sx, z1, y1); P(sx, z0, y1); poly(rgb(col, .72)); }
  if (topVisible(y1)){ P(x - hw, z0, y1); P(x + hw, z0, y1); P(x + hw, z1, y1); P(x - hw, z1, y1); poly(rgb(col, 1.15)); }
  P(x - hw, z0, y0); P(x + hw, z0, y0); P(x + hw, z0, y1); P(x - hw, z0, y1); poly(rgb(col, front || 1));
}

function drawBuilding(b){
  const w = WORLDS[b.wi], zz1 = b.z + b.len; if (zz1 < -1.4) return;
  const z0 = Math.max(b.z, -1.4), xi = b.side * 2.05, xo = b.side * (2.05 + b.w), c = w.bRgb[b.c], h = b.h;
  P(xi, z0, 0); P(xi, zz1, 0); P(xi, zz1, h); P(xi, z0, h); poly(rgb(c, .78));
  if (b.z > -1.3){ P(xi, b.z, 0); P(xo, b.z, 0); P(xo, b.z, h); P(xi, b.z, h); poly(rgb(c, .95)); }
  if (topVisible(h)){ P(xi, z0, h); P(xi, zz1, h); P(xo, zz1, h); P(xo, z0, h); poly(w.style === 'snow' ? '#f6faff' : rgb(c, 1.15)); }
  else if (w.style === 'snow'){ P(xi, z0, h); P(xi, zz1, h); P(xi, zz1, h - .35); P(xi, z0, h - .35); poly('#f4f9ff'); }
  if (b.z < 38){                                                        // windows (3 batched paths)
    const cols = Math.max(2, Math.round(b.len / 1.1)), rows = Math.max(1, Math.floor(h / .95)), rh = h / rows;
    const pA = new Path2D(), pB = new Path2D(), pD = new Path2D(), la = w.night ? 30 : 22, lb = w.night ? 60 : 45;
    for (let i = 0; i < cols; i++){
      const za = b.z + b.len * (i + .2) / cols, zc = b.z + b.len * (i + .8) / cols; if (za < -1.3) continue;
      for (let j = 0; j < rows; j++){
        const ya = (j + .28) * rh, yb = (j + .72) * rh, r = hsh(b.seed, i, j);
        P(xi, za, ya); P(xi, zc, ya); P(xi, zc, yb); P(xi, za, yb); addQuad(r < la ? pA : r < lb ? pB : pD);
      }
    }
    if (b.z > -1.2 && b.z < 22){
      for (let i = 0; i < 3; i++){
        const xa = b.side * (2.05 + b.w * (i + .2) / 3), xb = b.side * (2.05 + b.w * (i + .8) / 3);
        for (let j = 0; j < rows; j++){
          const ya = (j + .28) * rh, yb = (j + .72) * rh, r = hsh(b.seed + 7, i, j);
          P(xa, b.z, ya); P(xb, b.z, ya); P(xb, b.z, yb); P(xa, b.z, yb); addQuad(r < la ? pA : r < lb ? pB : pD);
        }
      }
    }
    ctx.fillStyle = rgb(c, .5); ctx.fill(pD); ctx.fillStyle = w.win[0]; ctx.fill(pA); ctx.fillStyle = w.win[1]; ctx.fill(pB);
  }
  if (w.style === 'neon'){
    ctx.strokeStyle = w.neon[b.c % 3]; ctx.lineWidth = 2; ctx.beginPath();
    pj(xi, z0, h); ctx.moveTo(PX, PY); pj(xi, zz1, h); ctx.lineTo(PX, PY);
    if (b.z > -1.3){ pj(xi, b.z, 0); ctx.moveTo(PX, PY); pj(xi, b.z, h); ctx.lineTo(PX, PY); }
    ctx.stroke();
  }
}
function drawTree(b){
  if (b.z < -1.3) return;
  const tc = WORLDS[b.wi].tRgb[b.c]; pj(b.side * b.x, b.z, 0);
  const bx = PX, by = PY, s = K * PS;
  ctx.fillStyle = '#5b3a22'; ctx.fillRect(bx - .1 * s, by - b.h * .4 * s, .2 * s, b.h * .4 * s);
  for (let i = 0; i < 3; i++){
    const y0 = by - (b.h * .25 + i * b.h * .22) * s, wd = (1 - i * .22) * .85 * s, hh = b.h * .36 * s;
    ctx.fillStyle = rgb(tc, .75 + i * .13); ctx.beginPath(); ctx.moveTo(bx - wd, y0); ctx.lineTo(bx + wd, y0); ctx.lineTo(bx, y0 - hh); ctx.fill();
  }
}

function drawCar(o){
  const T = o.T, c = o.c, x0 = o.lane - 1, hw = .42, hb = T.hb, hc = T.hc;
  const zb = o.z + T.len, z0 = Math.max(o.z, -1.3); if (zb < -1.3) return;
  P(x0 - hw - .12, z0, 0); P(x0 + hw + .12, z0, 0); P(x0 + hw + .12, zb, 0); P(x0 - hw - .12, zb, 0); poly('rgba(0,0,0,.28)');
  const rel = x0 - camX, side = Math.abs(rel) > hw ? (rel > 0 ? -1 : 1) : 0, sx = x0 + side * hw;
  if (side){ P(sx, z0, .12); P(sx, zb, .12); P(sx, zb, hb); P(sx, z0, hb); poly(rgb(c, .72)); }
  if (T.van){
    if (side){
      P(sx, z0, hb); P(sx, zb, hb); P(sx, zb, hc); P(sx, z0, hc); poly(rgb(c, .8));
      P(sx, z0 + .2, hb + .3); P(sx, z0 + 1.2, hb + .3); P(sx, z0 + 1.2, hc - .25); P(sx, z0 + .2, hc - .25); poly('#1d2c3d');
    }
    if (topVisible(hc)){ P(x0 - hw, z0, hc); P(x0 + hw, z0, hc); P(x0 + hw, zb, hc); P(x0 - hw, zb, hc); poly(rgb(c, 1.2)); }
  } else {
    P(x0 - hw, z0, hb); P(x0 + hw, z0, hb); P(x0 + hw, zb, hb); P(x0 - hw, zb, hb); poly(rgb(c, 1.1));
    const hw2 = .33, cz0 = Math.max(o.z + T.cs, -1.3), cz1 = Math.max(o.z + T.ce, cz0 + .6);
    if (side){ const s2 = x0 + side * hw2; P(s2, cz0, hb); P(s2, cz1, hb); P(s2, cz1 - .35, hc); P(s2, cz0 + .45, hc); poly('#243649'); }
    P(x0 - hw2, cz0, hb); P(x0 + hw2, cz0, hb); P(x0 + hw2, cz0 + .45, hc); P(x0 - hw2, cz0 + .45, hc); poly('#263a52');
    P(x0 - .25, cz0 + .02, hb + .03); P(x0 - .08, cz0 + .02, hb + .03); P(x0 + .02, cz0 + .4, hc - .02); P(x0 - .15, cz0 + .4, hc - .02); poly('rgba(255,255,255,.18)');
    if (topVisible(hc)){ P(x0 - hw2, cz0 + .45, hc); P(x0 + hw2, cz0 + .45, hc); P(x0 + hw2, cz1 - .35, hc); P(x0 - hw2, cz1 - .35, hc); poly(rgb(c, 1.25)); }
  }
  if (o.z > -1.2){                                                      // front: grille, lights, plate, tyres
    const top = T.van ? hc : hb;
    pj(x0, o.z, 0); const bx = PX, by = PY, s = K * PS;
    pj(x0 - hw, o.z, .12); const lx = PX, ly = PY; pj(x0 + hw, o.z, top); const rx = PX, ry = PY;
    const g = ctx.createLinearGradient(0, ry, 0, ly); g.addColorStop(0, rgb(c, 1.18)); g.addColorStop(1, rgb(c, .68));
    ctx.fillStyle = g; ctx.fillRect(lx, ry, rx - lx, ly - ry);
    if (T.van){ ctx.fillStyle = '#1d2c3d'; ctx.fillRect(bx - .36 * s, by - (hc - .2) * s, .72 * s, (hc - hb - .35) * s); ctx.fillStyle = 'rgba(255,255,255,.14)'; ctx.fillRect(bx - .3 * s, by - (hc - .2) * s, .14 * s, (hc - hb - .35) * s); }
    ctx.fillStyle = '#0d0d0f'; ctx.fillRect(bx - .44 * s, by - .2 * s, .1 * s, .2 * s); ctx.fillRect(bx + .34 * s, by - .2 * s, .1 * s, .2 * s);
    ctx.fillStyle = '#2b2e35'; ctx.fillRect(bx - .44 * s, by - .26 * s, .88 * s, .15 * s);
    ctx.fillStyle = '#f3f3f3'; ctx.fillRect(bx - .13 * s, by - .42 * s, .26 * s, .11 * s);
    ctx.fillStyle = '#14171c'; ctx.fillRect(bx - .2 * s, by - .57 * s, .4 * s, .12 * s);
    ctx.fillStyle = '#9aa0a8'; for (let i = 1; i < 4; i++) ctx.fillRect(bx - .2 * s, by - (.57 - i * .03) * s, .4 * s, .006 * s * 10);
    const on = o.z < 35 ? ((time * 3.2 + o.seed * 4) % 1) < .5 : env.night > .5;   // headlights blink as the car nears
    for (const sg of [-1, 1]){
      ctx.fillStyle = on ? '#fff6c8' : '#8d97a1'; ctx.beginPath(); ctx.ellipse(bx + sg * .3 * s, by - .5 * s, .1 * s, .06 * s, 0, 0, 7); ctx.fill();
      if (on) lights.push({ x: bx + sg * .3 * s, y: by - .5 * s, s, a: ctx.globalAlpha });
    }
  }
}
function drawCoin(o){
  pj(o.lane - 1, Math.max(o.z, -1.3), .75); const r = .2 * K * PS, w = Math.abs(Math.cos(time * 4 + o.z)) * r + r * .12;
  ctx.fillStyle = '#c28f00'; ctx.beginPath(); ctx.ellipse(PX, PY, w + r * .1, r * 1.1, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.ellipse(PX, PY, w, r, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#ffe98a'; ctx.beginPath(); ctx.ellipse(PX, PY, w * .55, r * .6, 0, 0, 7); ctx.fill();
}
function drawBarrier(o){
  const x = o.lane - 1; box(x, o.z, o.z + .4, .42, 0, .6, [255, 159, 28], 1);
  if (o.z > -1.2){ for (let i = -1; i <= 1; i++){ P(x + i * .26 - .06, o.z, .15); P(x + i * .26 + .06, o.z, .15); P(x + i * .26 + .06, o.z, .5); P(x + i * .26 - .06, o.z, .5); poly('#fff'); } }
}
function drawBar(o){
  const x = o.lane - 1;
  box(x - .38, o.z, o.z + .3, .04, 0, .9, [90, 90, 100]); box(x + .38, o.z, o.z + .3, .04, 0, .9, [90, 90, 100]);
  box(x, o.z, o.z + .3, .44, .9, 1.25, [46, 196, 182], 1);
}
function drawPortal(o){
  const col = WORLDS[o.next].accRgb, z = o.z;
  ctx.globalCompositeOperation = 'lighter'; P(-1.55, z, 0); P(1.55, z, 0); P(1.55, z, 2.8); P(-1.55, z, 2.8); poly(rgba(col, .2)); ctx.globalCompositeOperation = 'source-over';
  box(-1.65, z, z + .3, .12, 0, 3.1, col, 1.2); box(1.65, z, z + .3, .12, 0, 3.1, col, 1.2); box(0, z, z + .3, 1.77, 2.8, 3.1, col, 1.2);
}
function drawObj(o){
  ctx.globalAlpha = fogA(o.z);
  if (o.t === 'car') drawCar(o); else if (o.t === 'coin') drawCoin(o); else if (o.t === 'barrier') drawBarrier(o); else if (o.t === 'bar') drawBar(o); else drawPortal(o);
  ctx.globalAlpha = 1;
}

function draw(){
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0); lights.length = 0; ctx.globalAlpha = 1;
  if (shake > 0) ctx.translate((Math.random() - .5) * shake * 14, (Math.random() - .5) * shake * 14);
  ctx.translate(W / 2, H / 2); ctx.rotate(tilt); ctx.translate(-W / 2, -H / 2);
  const e = env;
  // sky
  const sg = ctx.createLinearGradient(0, 0, 0, HY);
  sg.addColorStop(0, rgb(e.top)); sg.addColorStop(.55, rgb(e.mid)); sg.addColorStop(1, rgb(e.bot));
  ctx.fillStyle = sg; ctx.fillRect(-80, -80, W + 160, HY + 80);
  if (e.night > .05){ ctx.fillStyle = '#fff'; ctx.globalAlpha = e.night * .9; for (const s of stars) ctx.fillRect(s[0] * W, s[1] * HY, s[2], s[2]); ctx.globalAlpha = 1; }
  // sun (or moon) disc + glow
  SX = W * e.sunX - camX * K * .05; SY = HY * e.sunY; SR = e.sunR * Math.min(W, H) * 1.6;
  ctx.globalCompositeOperation = 'lighter';
  const sgl = ctx.createRadialGradient(SX, SY, 0, SX, SY, SR * 5); sgl.addColorStop(0, rgba(e.sunC, .55 * e.sun)); sgl.addColorStop(1, rgba(e.sunC, 0));
  ctx.fillStyle = sgl; ctx.fillRect(SX - SR * 5, SY - SR * 5, SR * 10, SR * 10);
  ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = rgba(e.sunC, .95); ctx.beginPath(); ctx.arc(SX, SY, SR, 0, 7); ctx.fill();
  // ground, sidewalks, road
  const gg = ctx.createLinearGradient(0, HY, 0, H); gg.addColorStop(0, rgb(e.bot)); gg.addColorStop(.3, rgb(e.ground));
  ctx.fillStyle = gg; ctx.fillRect(-80, HY, W + 160, H - HY + 80);
  P(-2.1, ZMAX + 12, 0); P(2.1, ZMAX + 12, 0); P(2.1, -1.5, 0); P(-2.1, -1.5, 0); poly(rgb(e.side));
  P(-1.5, ZMAX + 12, 0); P(1.5, ZMAX + 12, 0); P(1.5, -1.5, 0); P(-1.5, -1.5, 0); poly(rgb(e.road));
  const lp = new Path2D(), off = dist % 4;
  for (let z = -off; z < ZMAX; z += 4){
    const a = Math.max(z, -1.4), b = z + 1.8; if (b < -1.4) continue;
    for (const x of [-.5, .5]){ P(x - .04, a, 0); P(x + .04, a, 0); P(x + .04, b, 0); P(x - .04, b, 0); addQuad(lp); }
  }
  for (const x of [-1.46, 1.46]){ P(x - .04, -1.4, 0); P(x + .04, -1.4, 0); P(x + .04, ZMAX + 12, 0); P(x - .04, ZMAX + 12, 0); addQuad(lp); }
  ctx.fillStyle = rgb(e.line); ctx.globalAlpha = .85; ctx.fill(lp); ctx.globalAlpha = 1;
  // scenery then traffic, far to near
  blds.sort((a, b) => b.z - a.z); objs.sort((a, b) => b.z - a.z);
  for (const b of blds){ if (b.z > ZMAX + 2) continue; ctx.globalAlpha = fogA(b.z); if (b.k === 'b') drawBuilding(b); else drawTree(b); }
  ctx.globalAlpha = 1;
  for (const o of objs) if (o.z >= .3 && o.z < ZMAX + 4) drawObj(o);
  const fg = ctx.createLinearGradient(0, HY - 4, 0, HY + (GY - HY) * .22); fg.addColorStop(0, rgba(e.bot, 1)); fg.addColorStop(1, rgba(e.bot, 0));
  ctx.fillStyle = fg; ctx.fillRect(-80, HY - 4, W + 160, (GY - HY) * .22 + 4);
  // runner
  if (mode !== 'home'){
    pj(player.x, 0, 0); const gx = PX, gy = PY;
    ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(gx, gy, .3 * K * (1 - Math.min(player.y, 1.5) * .15), .08 * K, 0, 0, 7); ctx.fill();
    pj(player.x, 0, player.y);
    const pose = player.y > .05 ? 'jump' : player.slide > 0 ? 'slide' : 'run';
    drawChar(ctx, SKINS[SAVE.skin], PX, PY, .72 * K, mode === 'play' ? player.ph : 0, pose, clamp((player.lane - 1 - player.x) * .6, -.5, .5));
  }
  for (const o of objs) if (o.z < .3 && o.z + o.len > -2) drawObj(o);
  // sparkles
  ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = '#ffd23f';
  for (const p of parts){ ctx.globalAlpha = p.l * 2; ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, 7); ctx.fill(); }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  // night tint, then light sources on top
  if (e.night > .02){ ctx.fillStyle = `rgba(5,0,35,${.3 * e.night})`; ctx.fillRect(-80, -80, W + 160, H + 160); }
  ctx.globalCompositeOperation = 'lighter';
  for (const L of lights){
    ctx.globalAlpha = L.a;
    const g = ctx.createRadialGradient(L.x, L.y, 0, L.x, L.y, L.s * .9); g.addColorStop(0, 'rgba(255,240,180,.9)'); g.addColorStop(1, 'rgba(255,240,180,0)');
    ctx.fillStyle = g; ctx.fillRect(L.x - L.s, L.y - L.s, L.s * 2, L.s * 2);
    ctx.fillStyle = 'rgba(255,235,170,.1)'; ctx.beginPath(); ctx.moveTo(L.x, L.y); ctx.lineTo(L.x - .5 * L.s, L.y + 2.2 * L.s); ctx.lineTo(L.x + .5 * L.s, L.y + 2.2 * L.s); ctx.fill();
  }
  ctx.globalAlpha = 1;
  // sunlight: soft warm wash, rays and lens flares
  const sun = e.sun * (1 - e.night);
  if (sun > .05){
    const wash = ctx.createRadialGradient(SX, SY, 0, SX, SY, Math.max(W, H) * 1.1); wash.addColorStop(0, rgba(e.sunC, .2 * sun)); wash.addColorStop(1, rgba(e.sunC, 0));
    ctx.fillStyle = wash; ctx.fillRect(-80, -80, W + 160, H + 160);
    ctx.fillStyle = rgba(e.sunC, .06 * sun); const L = Math.max(W, H) * 1.6;
    for (let i = 0; i < 8; i++){ const a = time * .05 + i * .8 + .3; ctx.beginPath(); ctx.moveTo(SX, SY); ctx.lineTo(SX + Math.cos(a) * L, SY + Math.sin(a) * L); ctx.lineTo(SX + Math.cos(a + .07) * L, SY + Math.sin(a + .07) * L); ctx.fill(); }
    for (const f of [.5, .8, 1.15]){ ctx.fillStyle = rgba(e.sunC, .07 * sun); ctx.beginPath(); ctx.arc(SX + (W / 2 - SX) * f, SY + (H / 2 - SY) * f, SR * (.5 + f * .4), 0, 7); ctx.fill(); }
  }
  ctx.globalCompositeOperation = 'source-over';
  if (e.snow > .02){ ctx.fillStyle = '#fff'; ctx.globalAlpha = e.snow * .85; for (const f of flakes){ ctx.beginPath(); ctx.arc(f.x * W, f.y * H, f.r, 0, 7); ctx.fill(); } ctx.globalAlpha = 1; }
}

function drawPreview(){
  pctx.clearRect(0, 0, pcv.width, pcv.height);
  pctx.fillStyle = 'rgba(255,255,255,.08)'; pctx.beginPath(); pctx.ellipse(pcv.width / 2, pcv.height - 22, 60, 12, 0, 0, 7); pctx.fill();
  drawChar(pctx, SKINS[view], pcv.width / 2, pcv.height - 24, 120, time * 11, 'run', 0);
}

let last = performance.now();
function loop(now){
  const dt = Math.min(.05, (now - last) / 1000); last = now;
  update(dt); draw();
  if (mode === 'home') drawPreview();
  requestAnimationFrame(loop);
}
document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });
initWorld(0); refreshHome();
requestAnimationFrame(loop);
