"""Optional HTTPS-hosted feed generator. Requires YOUTUBE_API_KEY and channel IDs.
Run periodically on a server; publish feed.json over HTTPS. No fake LIVE alerts.
"""
import os,json,urllib.request,urllib.parse,datetime,hashlib,pathlib
ROOT=pathlib.Path(__file__).parent
CHANNELS=json.loads(os.getenv('TEACHER_CHANNELS','{}')) # {"Maths - Gagan Pratap":"UC...", ...}
RRB_URLS=json.loads(os.getenv('RRB_NOTICE_URLS','[]')) # official notices pages only
KEY=os.getenv('YOUTUBE_API_KEY','')
state_file=ROOT/'seen_state.json'
state=json.loads(state_file.read_text()) if state_file.exists() else {'rrb':{},'live':[]}
alerts=[]
def fetch(url):
 req=urllib.request.Request(url,headers={'User-Agent':'MyGroupDStudy/26.2'})
 with urllib.request.urlopen(req,timeout=15) as r:return r.read(1500000)
if KEY:
 for teacher,channel in CHANNELS.items():
  if not channel.startswith('UC'):continue
  q=urllib.parse.urlencode({'part':'snippet','channelId':channel,'eventType':'live','type':'video','maxResults':10,'key':KEY})
  try:
   data=json.loads(fetch('https://www.googleapis.com/youtube/v3/search?'+q))
   for item in data.get('items',[]):
    sn=item.get('snippet',{});vid=item.get('id',{}).get('videoId','')
    if not vid or sn.get('liveBroadcastContent')!='live' or sn.get('channelId')!=channel:continue
    if vid not in state['live']:alerts.append({'id':'live-'+vid,'type':'live','title':teacher+' — '+sn.get('title','LIVE Class'),'url':'https://www.youtube.com/watch?v='+vid})
    state['live'].append(vid)
  except Exception as e:print('YouTube check failed:',teacher,str(e))
state['live']=state['live'][-500:]
# A changed official notice page is NOT proof of a new vacancy; never alert from raw page changes.
# Curated verified notices can be added to verified_vacancies.json by an operator.
notices=ROOT/'verified_vacancies.json'
if notices.exists():
 for item in json.loads(notices.read_text()):
  if not all(item.get(k) for k in ('id','title','url')):continue
  if not item['url'].startswith('https://'):continue
  if item['id'] not in state['rrb']:
   alerts.append({'id':'vacancy-'+item['id'],'type':'vacancy','title':item['title'],'url':item['url']})
   state['rrb'][item['id']]=True
questions=ROOT/'new_questions.json';current=ROOT/'current_affairs.json'
feed={'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'alerts':alerts,'questions':json.loads(questions.read_text()) if questions.exists() else [],'current_affairs':json.loads(current.read_text()) if current.exists() else []}
(ROOT/'feed.json').write_text(json.dumps(feed,ensure_ascii=False,indent=2))
state_file.write_text(json.dumps(state,indent=2))
print('Generated',len(alerts),'new alerts')
