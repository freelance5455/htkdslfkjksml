यह वैकल्पिक ऑनलाइन डेटा सेवा है। सिर्फ APK से वास्तविक नए LIVE और वैकेंसी का पता नहीं चल सकता।
1. YouTube Data API key YOUTUBE_API_KEY और सत्यापित चारों चैनल ID TEACHER_CHANNELS JSON में सेट करें।
2. feed_server.py को ऑनलाइन सर्वर पर नियमित चलाएँ और feed.json को HTTPS पर उपलब्ध कराएँ।
3. आधिकारिक RRB नोटिस की पुष्टि करके verified_vacancies.json में id,title,url जोड़ें। पेज में बदलाव अपने-आप नई भर्ती नहीं माना जाता।
4. नए प्रश्न new_questions.json और खबरें current_affairs.json में प्रकाशित करें। गलत या बिना स्रोत वाली खबर न डालें।
5. ऐप के Updates सेक्शन में HTTPS feed.json का URL सेव करें। Android बैकग्राउंड जाँच लगभग 15 मिनट या उससे अधिक विलंब से होती है।
6. बिना API key, verified channels, hosting और news/questions source के ऑटो अपडेट काम नहीं करेंगे।
7. Android 13+ में notification permission जरूरी है; फोन की battery restrictions के कारण समय पर notification की गारंटी नहीं।
