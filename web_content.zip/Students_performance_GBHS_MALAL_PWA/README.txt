Students performance GBHS MALAL

This package contains the web app prototype with the supplied GBHS MALAL monogram embedded.
It is not an Android APK yet.

To test: open index.html in Chrome. For a home-screen installation, the app needs to be hosted over HTTPS and configured as a PWA. Android APK compilation requires an Android build environment (Android Studio/SDK or a trusted build service).

Important: records are stored locally in the browser on the device. Back up records regularly. Do not treat this prototype as a secure cloud database.
