// Service worker: sve se kešira pri instalaciji, pa aplikacija radi bez mreže.
// Pri svakoj izmeni fajlova povećaj VERSION da bi se korisnicima ponudilo osvežavanje.
const VERSION = 'v27.1.1';
const CACHE = 'finance-hub-' + VERSION;
const ASSETS = [
  './', './index.html', './manifest.webmanifest', './css/styles.css',
  './js/main.js', './js/util.js', './js/db.js', './js/store.js', './js/calc.js', './js/migrate.js', './js/charts.js', './js/sheet.js',
  './js/views/common.js', './js/views/overview.js', './js/views/transactions.js', './js/views/add.js', './js/views/plans.js', './js/views/more.js', './js/views/dashboard.js',
  './icons/icon-192.png', './icons/icon-512.png', './icons/maskable-512.png', './icons/apple-touch-icon.png',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith('finance-hub-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (e) => { if (e.data === 'skipWaiting') self.skipWaiting(); });

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then((hit) => hit || fetch(req).catch(() => (req.mode === 'navigate' ? caches.match('./index.html') : Response.error())))
  );
});
