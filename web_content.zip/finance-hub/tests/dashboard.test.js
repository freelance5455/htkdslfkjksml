const { chromium } = require('playwright');
const URL = 'http://localhost:8765/index.html';
let fails = 0;
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  page.on('console', (m) => m.type() === 'error' && errs.push(m.text()));
  await page.goto(URL); await page.waitForSelector('.hero');
  // probni profil sa podacima + limit
  await page.click('.nav [data-nav=more]'); await page.click('[data-action=add-demo]');
  await page.waitForTimeout(300);
  await page.click('.nav [data-nav=plans]'); await page.click('[data-action=edit-catbudgets]');
  await page.fill('.sheet-form [name=c0]', '8000'); await page.click('.sheet-form button[type=submit]');
  await page.waitForTimeout(300);

  await page.click('#dashBtn');
  await page.waitForSelector('[data-screen=dashboard] .chart-box svg');
  ok((await page.$$('[data-screen=dashboard] .chart-box svg')).length === 6, '6 charts rendered in portrait');
  await page.screenshot({ path: 'dash-portrait.png', fullPage: true });

  // dodir na grafikon otvara prikaz preko celog ekrana
  await page.click('[data-screen=dashboard] .chart-card >> nth=1');
  await page.waitForSelector('#fs:not([hidden]) svg');
  ok(await page.isVisible('#fs'), 'tap opens fullscreen viewer');
  ok((await page.textContent('#fsTitle')).includes('Potrošnja po kategoriji'), 'viewer opened on tapped chart');
  const box = await page.$eval('#fs .fs-page .chart-box', (e) => [e.clientWidth, e.clientHeight]);
  ok(box[0] > 300 && box[1] > 300, 'chart fills viewer: ' + box);
  await page.$eval('#fs .fs-page:nth-child(2) [data-tip]', (e) => e.dispatchEvent(new MouseEvent('click', { bubbles: true })));
  ok((await page.textContent('#fsReadout')).includes('%'), 'tap on slice shows readout');
  await page.click('[data-action=close-chart]');
  ok(await page.isHidden('#fs'), 'close works');

  // rotacija u landscape na dashboardu otvara sam
  await page.setViewportSize({ width: 844, height: 390 });
  await page.waitForSelector('#fs:not([hidden]) svg', { timeout: 3000 });
  ok(true, 'rotating to landscape auto-opens fullscreen dashboard');
  await page.waitForTimeout(400);
  const lb = await page.$eval('#fs .fs-page .chart-box', (e) => [e.clientWidth, e.clientHeight]);
  ok(lb[0] > 700 && lb[1] > 200, 'chart resized for landscape: ' + lb);
  await page.screenshot({ path: 'dash-landscape.png' });
  // sledeći grafikon swipe-om (scroll)
  await page.evaluate(() => { const p = document.querySelector('#fsPager'); p.scrollTo({ left: p.clientWidth * 2 }); });
  await page.waitForTimeout(400);
  ok((await page.textContent('#fsTitle')).includes('Saldo'), 'swipe to 3rd chart (Saldo)');
  await page.screenshot({ path: 'dash-landscape2.png' });
  // nazad u portrait zatvara automatski prikaz
  await page.setViewportSize({ width: 390, height: 800 });
  await page.waitForTimeout(400);
  ok(await page.isHidden('#fs'), 'back to portrait closes auto viewer');
  console.log(errs.length ? 'ERRORS ' + errs.join('|') : 'no errors'); ok(!errs.length, 'no errors');
  await browser.close(); process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('CRASH', e.message); process.exit(2); });
