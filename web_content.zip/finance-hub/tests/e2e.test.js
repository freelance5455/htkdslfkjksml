const { chromium } = require('playwright');
const fs = require('fs');
const URL = 'http://localhost:8765/index.html';
let fails = 0;
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, acceptDownloads: true });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
  await page.goto(URL);
  await page.waitForSelector('[data-screen=overview] .hero');
  ok(true, 'overview renders');
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.waitForFunction(() => navigator.serviceWorker.controller || true);
  await page.reload(); await page.waitForSelector('.hero');

  // dodaj trošak
  await page.click('.nav [data-nav=add]');
  await page.fill('#addForm [name=amount]', '2500');
  await page.fill('#addForm [name=title]', 'Namirnice');
  await page.click('#addForm button[type=submit]');
  await page.waitForSelector('.toast.show');
  ok((await page.textContent('#toast')).includes('sačuvana'), 'transaction saved toast');
  // dodaj EUR prihod
  await page.click('#addForm [data-type=income]');
  await page.fill('#addForm [name=amount]', '100');
  await page.selectOption('#addForm [name=currency]', 'EUR');
  await page.fill('#addForm [name=title]', 'Honorar');
  await page.click('#addForm button[type=submit]');
  await page.click('.nav [data-nav=overview]');
  const bal = await page.textContent('.hero .big');
  console.log('balance', bal);
  ok(/9\.220/.test(bal), 'balance = 100 EUR*117.2 - 2500 = 9.220');

  // perzistencija posle reload
  await page.reload(); await page.waitForSelector('.hero');
  ok(/9\.220/.test(await page.textContent('.hero .big')), 'persisted after reload (IndexedDB)');

  // offline
  await ctx.setOffline(true);
  await page.reload(); await page.waitForSelector('.hero');
  ok(/9\.220/.test(await page.textContent('.hero .big')), 'loads + data present OFFLINE');
  ok(!(await page.isHidden('#offline')), 'offline badge visible');
  await ctx.setOffline(false);

  // izmena i brisanje
  await page.click('.nav [data-nav=transactions]');
  await page.click('[data-screen=transactions] [data-action=edit-tx] >> nth=0');
  await page.fill('.sheet-form [name=title]', 'Honorar izmenjen');
  await page.click('.sheet-form button[type=submit]');
  await page.waitForSelector('text=Honorar izmenjen');
  ok(true, 'edit transaction');
  await page.click('[data-screen=transactions] [data-action=del-tx] >> nth=0');
  await page.click('.sheet-form button[type=submit]');
  await page.waitForTimeout(300);
  ok(!(await page.content()).includes('Honorar izmenjen'), 'delete transaction');

  // planovi: prenos, račun
  await page.click('.nav [data-nav=plans]');
  await page.click('[data-action=transfer]');
  await page.fill('.sheet-form [name=amount]', '500');
  await page.click('.sheet-form button[type=submit]');
  await page.waitForTimeout(300);
  ok((await page.textContent('[data-screen=plans]')).includes('Prenos'), 'transfer dialog works') ;
  await page.click('[data-action=add-bill]');
  await page.fill('.sheet-form [name=name]', 'Internet');
  await page.fill('.sheet-form [name=amount]', '2900');
  await page.click('.sheet-form button[type=submit]');
  await page.click('[data-action=pay-bill]');
  await page.click('.sheet-form button[type=submit]');
  await page.waitForSelector('text=Plaćeno ovog meseca');
  ok(true, 'bill paid creates expense');

  // backup
  await page.click('.nav [data-nav=more]');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('[data-action=backup]')]);
  const p = await dl.path(); const bk = JSON.parse(fs.readFileSync(p, 'utf8'));
  ok(bk.data.transactions.length === 3, 'backup has 3 tx (expense, transfer, bill): ' + bk.data.transactions.length);

  // restore V26-style backup with transfer legs
  const legacy = { app: 'Finance Hub', version: 16, data: { transactions: [
    { id: 'a', type: 'income', title: 'Plata', amount: 100000, currency: 'RSD', category: 'Plata', date: '2026-10-05', accountId: 'bank' },
    { id: 'tr_x_out', type: 'transfer_out', transferId: 'tr_x', title: 'Prenos na Štednja', amount: 11720, currency: 'RSD', category: 'Ostalo', date: '2026-10-06', accountId: 'bank' },
    { id: 'tr_x_in', type: 'transfer_in', transferId: 'tr_x', title: 'Prenos sa Tekući račun', amount: 11720, currency: 'RSD', category: 'Ostalo', date: '2026-10-06', accountId: 'savings' } ],
    goal: { name: 'Auto', target: 500000, saved: 1000 }, budget: 60000, rate: 117.2, assets: [], debts: [], bills: [], categoryBudgets: { Hrana: 20000 } } };
  fs.writeFileSync('legacy.json', JSON.stringify(legacy));
  await page.setInputFiles('#restoreFile', 'legacy.json');
  await page.click('.sheet-form button[type=submit]');
  await page.waitForSelector('text=Kopija je vraćena');
  await page.click('.nav [data-nav=plans]');
  const plans = await page.textContent('[data-screen=plans]');
  ok(/100 EUR/.test(plans) || /Štednja[\s\S]*100 EUR/.test(plans), 'legacy transfer merged: savings = 100 EUR');
  ok(plans.includes('Auto'), 'legacy goal imported');

  // Interna kopija postoji
  await page.click('.nav [data-nav=more]');
  await page.click('[data-action=snapshots]'); await page.waitForSelector('#sheet.open');
  ok((await page.textContent('#sheet')).includes('transakcija'), 'daily snapshot exists');
  await page.keyboard.press('Escape');

  // storage persisted info
  await page.waitForTimeout(300);
  const more = await page.textContent('[data-screen=more]');
  ok(more.includes('IndexedDB'), 'storage backend IndexedDB shown');

  await page.screenshot({ path: 'shot-more.png' });
  await page.click('.nav [data-nav=overview]'); await page.screenshot({ path: 'shot-overview.png' });

  // Uvoz iz stare aplikacije (localStorage) u novom kontekstu
  const ctx2 = await browser.newContext({ viewport: { width: 390, height: 800 } });
  await ctx2.addInitScript(() => {
    if (!localStorage.getItem('financeHubPersonal_v1') && !sessionStorage.getItem('seeded')) {
      sessionStorage.setItem('seeded', '1');
      localStorage.setItem('financeHubPersonal_v1', JSON.stringify({ transactions: [{ id: 'z', type: 'expense', title: 'Stari trošak', amount: 700, currency: 'RSD', category: 'Hrana', date: '2026-10-01' }], goal: { name: 'Fond', target: 100000, saved: 0 }, budget: 50000, rate: 117.2, assets: [], debts: [], bills: [], categoryBudgets: {} }));
    }
  });
  const p2 = await ctx2.newPage(); p2.on('pageerror', (e) => errs.push('p2 ' + e.message));
  await p2.goto(URL); await p2.waitForSelector('.hero');
  ok(/700/.test(await p2.textContent('.hero .big')), 'legacy localStorage auto-imported');

  console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no console/page errors');
  ok(errs.length === 0, 'no errors');
  await browser.close();
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
