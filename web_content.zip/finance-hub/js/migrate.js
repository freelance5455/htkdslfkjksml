// Normalizacija podataka: nova verzija (v2) i uvoz iz stare "Finance Hub Dark" (V11–V26) kopija i localStorage-a.
import { uid, isDate, round2, today } from './util.js';

export const DEFAULT_ACCOUNTS = () => [
  { id: 'cash', name: 'Gotovina', currency: 'RSD' },
  { id: 'bank', name: 'Tekući račun', currency: 'RSD' },
  { id: 'savings', name: 'Štednja', currency: 'EUR' },
];

export const blankState = () => ({
  v: 2,
  rate: 117.2,
  budget: 50000,
  categoryBudgets: {},
  goal: { name: 'Fond za sigurnost', target: 100000, saved: 0 },
  accounts: DEFAULT_ACCOUNTS(),
  transactions: [],
  assets: [],
  debts: [],
  bills: [],
  lastBackup: null,
});

const num = (v, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);
const cur = (c) => (c === 'EUR' ? 'EUR' : 'RSD');

// Prihvata i staro (V16–V26) i novo stanje; vraća ispravno v2 stanje ili baca grešku.
export function normalize(input) {
  const d = input && input.data && typeof input.data === 'object' ? input.data : input;
  if (!d || !Array.isArray(d.transactions)) throw new Error('Datoteka nije ispravna Finance Hub kopija.');
  const base = blankState();
  const rate = num(d.rate, 0) > 0 ? num(d.rate) : base.rate;

  const accounts = Array.isArray(d.accounts) && d.accounts.length
    ? d.accounts.filter((a) => a && a.id && a.name).map((a) => ({ id: String(a.id), name: String(a.name), currency: cur(a.currency) }))
    : base.accounts;
  const accIds = new Set(accounts.map((a) => a.id));
  const accById = Object.fromEntries(accounts.map((a) => [a.id, a]));
  const defaultAcc = accounts[0]?.id || 'cash';

  const txs = [];
  const legs = {}; // stari prenosi: dve zasebne transakcije povezane sa transferId
  for (const t of d.transactions) {
    if (!t || !isDate(t.date)) continue;
    const amount = round2(num(t.amount));
    if (amount <= 0) continue;
    const common = {
      id: String(t.id || uid()),
      amount,
      currency: cur(t.currency),
      rate: num(t.rate, 0) > 0 ? num(t.rate) : rate,
      title: String(t.title || '').slice(0, 70) || 'Bez naziva',
      category: String(t.category || 'Ostalo'),
      date: t.date,
      note: String(t.note || '').slice(0, 100),
      accountId: accIds.has(t.accountId) ? t.accountId : defaultAcc,
    };
    if (t.billId) common.billId = String(t.billId);
    if (t.type === 'income' || t.type === 'expense') txs.push({ ...common, type: t.type });
    else if (t.type === 'transfer' && accIds.has(t.toAccountId)) txs.push({ ...common, type: 'transfer', toAccountId: t.toAccountId, toAmount: round2(num(t.toAmount, amount)) });
    else if ((t.type === 'transfer_in' || t.type === 'transfer_out') && t.transferId) {
      (legs[t.transferId] ||= {})[t.type] = common;
    }
  }
  for (const [tid, l] of Object.entries(legs)) {
    if (!l.transfer_out || !l.transfer_in) continue; // nepotpun prenos se preskače
    const from = accById[l.transfer_out.accountId], to = accById[l.transfer_in.accountId];
    // U staroj verziji oba "kraka" imaju isti iznos u RSD; novi model čuva iznos u valuti računa.
    const r = l.transfer_out.rate;
    const conv = (amt, c) => (c === 'EUR' ? amt / r : amt);
    const rsd = l.transfer_out.currency === 'EUR' ? l.transfer_out.amount * r : l.transfer_out.amount;
    txs.push({
      ...l.transfer_out, id: tid, type: 'transfer', currency: from.currency, amount: round2(conv(rsd, from.currency)),
      toAccountId: to.id, toAmount: round2(conv(rsd, to.currency)), title: l.transfer_out.title.replace(/^Prenos na /, 'Prenos → '),
    });
  }

  const wealth = (arr) => (Array.isArray(arr) ? arr : [])
    .filter((x) => x && num(x.amount) > 0)
    .map((x) => ({ id: String(x.id || uid()), name: String(x.name || 'Stavka').slice(0, 60), amount: num(x.amount), currency: cur(x.currency) }));

  const goal = d.goal && typeof d.goal === 'object'
    ? { name: String(d.goal.name || base.goal.name), target: Math.max(1, num(d.goal.target, base.goal.target)), saved: Math.max(0, num(d.goal.saved)) }
    : base.goal;

  const cb = {};
  if (d.categoryBudgets && typeof d.categoryBudgets === 'object')
    for (const [k, v] of Object.entries(d.categoryBudgets)) if (num(v) > 0) cb[k] = num(v);

  return {
    v: 2,
    rate,
    budget: num(d.budget, 0) > 0 ? num(d.budget) : base.budget,
    categoryBudgets: cb,
    goal,
    accounts,
    transactions: txs,
    assets: wealth(d.assets),
    debts: wealth(d.debts),
    bills: (Array.isArray(d.bills) ? d.bills : [])
      .filter((b) => b && b.name && num(b.amount) > 0)
      .map((b) => ({ id: String(b.id || uid()), name: String(b.name).slice(0, 70), amount: num(b.amount), currency: cur(b.currency), day: Math.min(28, Math.max(1, Math.round(num(b.day, 1)))), category: String(b.category || 'Računi') })),
    lastBackup: typeof d.lastBackup === 'string' ? d.lastBackup : null,
  };
}

// Čita podatke stare aplikacije iz localStorage-a (radi samo ako je ista adresa/porekla kao stara datoteka).
export function readLegacyLocalStorage() {
  const found = [];
  try {
    const tryKey = (key, name) => {
      const raw = localStorage.getItem(key);
      if (!raw) return;
      try {
        const st = normalize(JSON.parse(raw));
        if (st.transactions.length || st.bills.length || st.assets.length || st.debts.length) found.push({ name, state: st });
      } catch {}
    };
    tryKey('financeHubPersonal_v1', 'Kuća / lično (uvezeno)');
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      const m = /^financeHubProfileData_real_(.+)$/.exec(k || '');
      if (m) tryKey(k, `Profil ${m[1]} (uvezeno)`);
    }
  } catch {}
  return found;
}

// Probni podaci za isprobavanje aplikacije.
export function demoState() {
  const s = blankState();
  const d = new Date();
  const day = (back) => { const x = new Date(d.getFullYear(), d.getMonth(), Math.max(1, d.getDate() - back)); return x.toISOString().slice(0, 10); };
  const mk = (type, title, amount, currency, category, back, accountId) => ({ id: uid(), type, title, amount, currency, rate: s.rate, category, date: day(back), note: 'Probni unos', accountId });
  s.transactions = [
    mk('income', 'Plata', 95000, 'RSD', 'Plata', 5, 'bank'),
    mk('expense', 'Namirnice', 4250, 'RSD', 'Hrana', 2, 'cash'),
    mk('expense', 'Struja', 38, 'EUR', 'Računi', 1, 'savings'),
    mk('expense', 'Gorivo', 6200, 'RSD', 'Prevoz', 0, 'cash'),
  ];
  s.bills = [{ id: uid(), name: 'Internet', amount: 2900, currency: 'RSD', day: Math.min(28, new Date().getDate() + 3), category: 'Računi' }];
  return s;
}
