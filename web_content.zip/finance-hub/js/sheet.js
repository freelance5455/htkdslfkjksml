// Modalni listovi (zamena za prompt()/confirm()) i registar akcija za delegirane događaje.
import { $, esc } from './util.js';

export const actions = {}; // data-action -> funkcija(element, event)

let current = null;
let clearTimer = null;

export function closeSheet(result) {
  if (!current) return;
  const { root, resolve, prevFocus } = current;
  current = null;
  root.classList.remove('open');
  document.body.classList.remove('noscroll');
  clearTimeout(clearTimer);
  clearTimer = setTimeout(() => { if (!current) root.innerHTML = ''; }, 200);
  prevFocus?.focus?.();
  resolve?.(result);
}

// Otvara list sa formom. onSubmit(form) može vratiti false/Promise<false> da ostane otvoren.
export function openSheet({ title, html, submitLabel = 'Sačuvaj', danger = false, onSubmit, onOpen }) {
  const root = $('#sheet');
  clearTimeout(clearTimer);
  return new Promise((resolve) => {
    current = { root, resolve, prevFocus: document.activeElement };
    root.innerHTML = `<div class="sheet-card" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="sheet-head"><h2>${esc(title)}</h2><button type="button" class="btn ghost" data-sheet-close>Zatvori</button></div>
      <form class="sheet-form" novalidate>${html}
        <div class="actions">${onSubmit ? `<button class="btn ${danger ? 'danger-solid' : ''}" type="submit">${esc(submitLabel)}</button>` : ''}
        <button class="btn ghost" type="button" data-sheet-close>Otkaži</button></div>
      </form></div>`;
    root.classList.add('open');
    document.body.classList.add('noscroll');
    const form = $('form', root);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      const r = await onSubmit?.(form);
      if (r !== false) closeSheet(true);
    });
    onOpen?.(form);
    $('input,select,button.btn', form)?.focus();
  });
}

export async function confirmSheet(message, okLabel = 'Potvrdi', danger = true) {
  const r = await openSheet({ title: 'Potvrda', html: `<p class="muted">${esc(message)}</p>`, submitLabel: okLabel, danger, onSubmit: () => true });
  return r === true;
}

document.addEventListener('click', (e) => {
  if (e.target.closest('[data-sheet-close]') || e.target.id === 'sheet') closeSheet(false);
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSheet(false); });
