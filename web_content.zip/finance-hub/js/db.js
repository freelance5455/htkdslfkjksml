// Lokalno skladište: IndexedDB (primarno), uz rezervni localStorage ako IndexedDB nije dostupan.
// Sve ostaje na uređaju — nema mrežnih poziva.
const DB_NAME = 'finance-hub';
const DB_VERSION = 1;
const STORES = ['kv', 'data', 'snapshots']; // kv: podešavanja, data: stanje po profilu, snapshots: dnevne kopije

let dbPromise = null;
let useFallback = false;

function open() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve) => {
    if (!('indexedDB' in window)) {
      useFallback = true;
      return resolve(null);
    }
    let req;
    try {
      req = indexedDB.open(DB_NAME, DB_VERSION);
    } catch {
      useFallback = true;
      return resolve(null);
    }
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const s of STORES) if (!db.objectStoreNames.contains(s)) db.createObjectStore(s, { keyPath: 'key' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => {
      useFallback = true;
      resolve(null);
    };
    req.onblocked = () => {
      useFallback = true;
      resolve(null);
    };
  });
  return dbPromise;
}

const lsKey = (store, key) => `fh2:${store}:${key}`;

function run(store, mode, fn) {
  return open().then(
    (db) =>
      new Promise((resolve, reject) => {
        const tx = db.transaction(store, mode);
        let result;
        tx.oncomplete = () => resolve(result);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error || new Error('Transakcija prekinuta'));
        const r = fn(tx.objectStore(store));
        if (r) r.onsuccess = () => (result = r.result);
      })
  );
}

export async function init() {
  await open();
  return { backend: useFallback ? 'localStorage' : 'IndexedDB' };
}

export async function get(store, key) {
  await open();
  if (useFallback) {
    const raw = localStorage.getItem(lsKey(store, key));
    return raw ? JSON.parse(raw) : undefined;
  }
  return run(store, 'readonly', (s) => s.get(key));
}

export async function put(store, record) {
  await open();
  if (useFallback) {
    localStorage.setItem(lsKey(store, record.key), JSON.stringify(record));
    return;
  }
  return run(store, 'readwrite', (s) => s.put(record));
}

export async function del(store, key) {
  await open();
  if (useFallback) {
    localStorage.removeItem(lsKey(store, key));
    return;
  }
  return run(store, 'readwrite', (s) => s.delete(key));
}

export async function all(store) {
  await open();
  if (useFallback) {
    const prefix = `fh2:${store}:`;
    const out = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k.startsWith(prefix)) out.push(JSON.parse(localStorage.getItem(k)));
    }
    return out;
  }
  return run(store, 'readonly', (s) => s.getAll());
}

// Kv pomoćnici
export const getKv = async (key, fallback = null) => (await get('kv', key))?.value ?? fallback;
export const setKv = (key, value) => put('kv', { key, value });

// Traži od pregledača da ne briše podatke kad ponestane prostora.
export async function requestPersistence() {
  try {
    if (navigator.storage?.persist) {
      if (await navigator.storage.persisted()) return true;
      return await navigator.storage.persist();
    }
  } catch {}
  return false;
}

export async function storageInfo() {
  const info = { backend: useFallback ? 'localStorage' : 'IndexedDB', persisted: false, usage: null, quota: null };
  try {
    if (navigator.storage?.persisted) info.persisted = await navigator.storage.persisted();
    if (navigator.storage?.estimate) {
      const e = await navigator.storage.estimate();
      info.usage = e.usage ?? null;
      info.quota = e.quota ?? null;
    }
  } catch {}
  return info;
}
