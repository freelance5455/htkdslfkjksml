import { $, $$, toast, monthKey, today } from './util.js';
import * as store from './store.js';
import { actions } from './sheet.js';
import { upcomingBills } from './calc.js';
import { requestPersistence } from './db.js';
import * as overview from './views/overview.js';
import * as transactions from './views/transactions.js';
import * as add from './views/add.js';
import * as plans from './views/plans.js';
import * as more from './views/more.js';
import * as dash from './views/dashboard.js';

const SCREENS = { overview, dashboard: dash, transactions, add, plans, more };
const TITLES = { overview: 'Pregled', dashboard: 'Dashboard', transactions: 'Transakcije', add: 'Nova transakcija', plans: 'Planovi', more: 'Izveštaji i podaci' };
let screen = 'overview';
// Telefon okrenut vodoravno (nizak ekran) — ne važi za široke desktop prozore.
const landscape = window.matchMedia('(orientation: landscape) and (max-height: 520px)');

function renderCurrent() {
  const el = $(`[data-screen="${screen}"]`);
  if (screen !== 'add') SCREENS[screen].render(el);
  renderHeader();
}

function renderHeader() {
  const p = store.profiles.find((x) => x.id === store.activeId);
  $('#profileName').textContent = p ? p.name : '';
  $('#screenTitle').textContent = TITLES[screen];
}

export function show(name) {
  if (!SCREENS[name]) name = 'overview';
  screen = name;
  $$('[data-screen]').forEach((s) => (s.hidden = s.dataset.screen !== name));
  $$('.nav button').forEach((b) => { const on = b.dataset.nav === name; b.classList.toggle('active', on); b.setAttribute('aria-current', on ? 'page' : 'false'); });
  $('#dashBtn').classList.toggle('active', name === 'dashboard');
  if (name === 'add') add.render($('[data-screen="add"]'));
  if (name === 'more') more.refreshStorageInfo().then(() => screen === 'more' && renderCurrent());
  renderCurrent();
  window.scrollTo(0, 0);
  if (name === 'dashboard' && landscape.matches) dash.openViewer(0, { auto: true });
  if (location.hash !== '#' + name) history.replaceState(null, '', '#' + name);
}

document.addEventListener('click', (e) => {
  const nav = e.target.closest('[data-nav]');
  if (nav) return show(nav.dataset.nav);
  const a = e.target.closest('[data-action]');
  if (!a) return;
  const act = a.dataset.action;
  if (act === 'edit-tx') return add.editTx(a.dataset.id);
  if (act === 'del-tx') return add.deleteTx(a.dataset.id);
  if (act === 'tx-month') { transactions.shiftTxMonth(Number(a.dataset.d)); return renderCurrent(); }
  actions[act]?.(a, e);
});
document.addEventListener('fh:rerender', renderCurrent);
store.subscribe(() => { if (screen === 'add') renderHeader(); else renderCurrent(); });
landscape.addEventListener('change', () => {
  if (landscape.matches && screen === 'dashboard' && !dash.isViewerOpen()) dash.openViewer(0, { auto: true });
  else if (!landscape.matches && dash.isViewerAuto()) dash.closeViewer(); // povratak u uspravan položaj vraća običan prikaz
});
window.addEventListener('hashchange', () => show(location.hash.slice(1)));

function reminders() {
  const due = upcomingBills(store.state, 3);
  if (!due.length || !('Notification' in window) || Notification.permission !== 'granted') return;
  const stamp = today() + due.map((b) => b.id + b.days).join(',');
  if (sessionStorage.getItem('fh:rem') === stamp) return;
  try {
    sessionStorage.setItem('fh:rem', stamp);
    new Notification('Finance Hub — podsetnik', { body: due.slice(0, 3).map((b) => `${b.name} ${b.days < 0 ? 'kasni' : b.days === 0 ? 'dospeva danas' : 'uskoro dospeva'}`).join(' · ') });
  } catch {}
}

function registerSW() {
  if (!('serviceWorker' in navigator) || !location.protocol.startsWith('http')) return;
  const hadController = !!navigator.serviceWorker.controller;
  navigator.serviceWorker.register('./sw.js').then((reg) => {
    reg.addEventListener('updatefound', () => {
      const w = reg.installing;
      w?.addEventListener('statechange', () => {
        if (w.state === 'installed' && navigator.serviceWorker.controller) {
          const b = $('#update');
          b.hidden = false;
          b.onclick = () => w.postMessage('skipWaiting');
        }
      });
    });
  }).catch(() => {});
  let reloaded = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => { if (hadController && !reloaded) { reloaded = true; location.reload(); } });
}

async function boot() {
  try {
    const info = await store.init();
    if (info.imported) toast(`Uvezeno ${info.imported} transakcija iz stare aplikacije.`, 5000);
    if (info.backend === 'localStorage') toast('IndexedDB nije dostupan — koristi se rezervno skladište.', 5000);
  } catch (e) {
    console.error(e);
    $('#boot').textContent = 'Skladište na uređaju nije dostupno. Proveri da li je privatni režim isključen.';
    return;
  }
  $('#boot').hidden = true;
  await requestPersistence();
  show(location.hash.slice(1) || 'overview');
  reminders();
  registerSW();
  window.addEventListener('online', () => $('#offline').hidden = true);
  window.addEventListener('offline', () => $('#offline').hidden = false);
  $('#offline').hidden = navigator.onLine;
}
boot();
