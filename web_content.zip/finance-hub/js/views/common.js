import { esc, fmt, prettyDate } from '../util.js';
import { state, ICONS } from '../store.js';
import { toRSD } from '../calc.js';

export const icon = (c) => ICONS[c] || '•';
export const accName = (id) => state.accounts.find((a) => a.id === id)?.name || '—';
export const pctClass = (p) => (p >= 100 ? 'over' : p >= 80 ? 'warn' : '');

export function txRow(t, { actions = true } = {}) {
  const isT = t.type === 'transfer', inc = t.type === 'income';
  const sign = isT ? '' : inc ? '+' : '−';
  const cls = isT ? '' : inc ? 'pos' : 'neg';
  const acc = isT ? `${accName(t.accountId)} → ${accName(t.toAccountId)}` : accName(t.accountId);
  const conv = t.currency === 'EUR' && !isT ? ` · ≈ ${fmt(toRSD(t, state))}` : '';
  return `<div class="tx" data-id="${esc(t.id)}">
    <div class="tx-ico">${isT ? '⇄' : inc ? '↗' : icon(t.category)}</div>
    <div class="tx-main"><div class="tx-title">${esc(t.title)}</div>
      <div class="sub">${esc(t.category)} · ${prettyDate(t.date)} · ${esc(acc)}${t.note ? ' · ' + esc(t.note) : ''}</div></div>
    <div class="tx-side"><div class="tx-amt ${cls}">${sign}${fmt(t.amount, t.currency)}</div><div class="sub">${conv.slice(3)}</div>
      ${actions ? `<div class="tx-btns"><button class="link" data-action="edit-tx" data-id="${esc(t.id)}">Izmeni</button><button class="link neg" data-action="del-tx" data-id="${esc(t.id)}">Obriši</button></div>` : ''}</div></div>`;
}

export const empty = (msg) => `<div class="empty">${esc(msg)}</div>`;
