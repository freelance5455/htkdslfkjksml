import { esc, fmt, monthKey, toast, today, round2, prettyDate } from '../util.js';
import * as store from '../store.js';
import { state } from '../store.js';
import { inMonth, flows, toRSD, wealthRSD, paidBillIds, billDue, forecast, accountBalance } from '../calc.js';
import { icon, empty, pctClass } from './common.js';
import { openSheet, confirmSheet, actions } from '../sheet.js';
import { monthLabel } from '../util.js';

const SPEND = store.CATEGORIES.expense;
const num = (v) => Number(String(v).replace(',', '.'));

export function render(el) {
  const key = monthKey();
  const txs = inMonth(state, key);
  const { expense } = flows(txs, state);
  const spent = {};
  txs.filter((t) => t.type === 'expense').forEach((t) => (spent[t.category] = (spent[t.category] || 0) + toRSD(t, state)));
  const budget = Math.max(1, state.budget), bp = Math.round((expense / budget) * 100);
  const cb = SPEND.filter((c) => state.categoryBudgets[c] > 0);
  const gp = Math.min(100, Math.round((state.goal.saved / Math.max(1, state.goal.target)) * 100));
  const paid = paidBillIds(state, key);
  const at = state.assets.reduce((s, x) => s + wealthRSD(x, state), 0), dt = state.debts.reduce((s, x) => s + wealthRSD(x, state), 0);
  const fc = forecast(state);
  const wealthRow = (x, k) => `<div class="row"><span><b>${esc(x.name)}</b><br><span class="sub">${fmt(x.amount, x.currency)}${x.currency === 'EUR' ? ' · ≈ ' + fmt(wealthRSD(x, state)) : ''}</span></span><button class="link neg" data-action="del-wealth" data-kind="${k}" data-id="${x.id}">Obriši</button></div>`;

  el.innerHTML = `
  <section class="card"><h3>Mesečni budžet</h3>
    <div class="row"><b>${fmt(expense)} potrošeno</b><span>${bp}%</span></div>
    <div class="track"><span class="${pctClass(bp)}" style="width:${Math.min(100, bp)}%"></span></div>
    <div class="sub">${expense <= budget ? 'Preostalo ' + fmt(budget - expense) : 'Preko budžeta za ' + fmt(expense - budget)} (limit ${fmt(budget)})</div>
    <div class="actions"><button class="btn ghost" data-action="edit-budget">Podesi budžet</button></div></section>

  <section class="card"><h3>Limiti po kategorijama</h3>
    ${cb.length ? cb.map((c) => { const lim = state.categoryBudgets[c], u = spent[c] || 0, p = Math.round((u / lim) * 100); return `<div class="catrow"><div class="row"><b>${icon(c)} ${esc(c)}</b><b class="${u > lim ? 'neg' : ''}">${fmt(u)} / ${fmt(lim)}</b></div><div class="track"><span class="${pctClass(p)}" style="width:${Math.min(100, p)}%"></span></div><div class="sub">${u > lim ? 'Prekoračeno za ' + fmt(u - lim) : p >= 80 ? 'Pažnja: iskorišćeno ' + p + '%' : 'Preostalo ' + fmt(lim - u)}</div></div>`; }).join('') : empty('Još nema limita po kategorijama.')}
    <div class="actions"><button class="btn ghost" data-action="edit-catbudgets">Podesi limite</button></div></section>

  <section class="card"><h3>Štedni cilj</h3>
    <div class="row"><b>${esc(state.goal.name)}</b><span>${gp}%</span></div><div class="track"><span style="width:${gp}%"></span></div>
    <div class="sub">${fmt(state.goal.saved)} od ${fmt(state.goal.target)}</div>
    <div class="actions"><button class="btn" data-action="goal-deposit">+ Uplata</button><button class="btn ghost" data-action="edit-goal">Izmeni cilj</button></div></section>

  <section class="card"><div class="row"><h3>Redovni računi</h3><button class="btn ghost" data-action="add-bill">+ Dodaj</button></div>
    <div class="sub">„Plaćeno" pravi trošak za današnji datum. Samo unos računa ne menja saldo.</div>
    ${state.bills.length ? state.bills.slice().sort((a, b) => a.day - b.day).map((b) => { const p = paid.has(b.id), due = billDue(b), late = !p && due < today(); return `<div class="bill"><div><b>${esc(b.name)}</b><div class="sub">${fmt(b.amount, b.currency)} · dan ${b.day} · ${esc(b.category)}</div><span class="pill ${late ? 'late' : ''}">${p ? 'Plaćeno ovog meseca' : late ? 'Rok je prošao' : 'Dospeva ' + prettyDate(due)}</span></div><div class="bill-btns">${p ? '<button class="btn ghost" disabled>Plaćeno ✓</button>' : `<button class="btn" data-action="pay-bill" data-id="${b.id}">Plaćeno</button>`}<button class="link neg" data-action="del-bill" data-id="${b.id}">Obriši</button></div></div>`; }).join('') : empty('Još nema redovnih računa.')}</section>

  <section class="card"><div class="row"><h3>Računi i novčanici</h3><button class="btn ghost" data-action="add-account">+ Račun</button></div>
    ${state.accounts.map((a) => `<div class="row"><span><b>${esc(a.name)}</b> <span class="sub">${a.currency}</span></span><span><b>${fmt(accountBalance(state, a), a.currency)}</b> ${['cash', 'bank', 'savings'].includes(a.id) ? '' : `<button class="link neg" data-action="del-account" data-id="${a.id}">Obriši</button>`}</span></div>`).join('')}
    <div class="actions"><button class="btn ghost" data-action="transfer">⇄ Prenesi između računa</button></div>
    <div class="sub">Prenos ne menja ukupno stanje, samo raspodelu novca.</div></section>

  <section class="card"><div class="row"><h3>Imovina i dugovanja</h3><button class="btn ghost" data-action="add-wealth">+ Stavka</button></div>
    <div class="stats"><div class="stat"><div class="label">IMOVINA</div><div class="v pos">${fmt(at)}</div></div><div class="stat"><div class="label">DUGOVI</div><div class="v neg">${fmt(dt)}</div></div>
    <div class="stat full"><div class="label">NETO IMOVINA</div><div class="v ${at - dt >= 0 ? 'pos' : 'neg'}">${fmt(at - dt)}</div></div></div>
    <h4>Moja imovina</h4>${state.assets.length ? state.assets.map((x) => wealthRow(x, 'asset')).join('') : empty('Nema unosa.')}
    <h4>Moja dugovanja</h4>${state.debts.length ? state.debts.map((x) => wealthRow(x, 'debt')).join('') : empty('Nema unosa.')}
    <div class="sub">Vrednosti sam procenjuješ; ovo nije bankarska evidencija.</div></section>

  <section class="card"><h3>Prognoza za 3 meseca</h3>
    ${fc.points.map((p) => `<div class="row"><b>${esc(monthLabel(p.key))}</b><b class="${p.balance < 0 ? 'neg' : 'pos'}">${fmt(p.balance)}</b></div>`).join('')}
    <div class="notice">${fc.knownMonths ? `Prosečan neto tok: ${fmt(fc.avg)} mesečno (na osnovu ${fc.knownMonths} od poslednja 3 meseca sa podacima). Procena, ne garancija.` : 'Nema dovoljno istorije za smislenu prognozu.'}</div></section>`;
}

const field = (label, inner, cls = '') => `<div class="field ${cls}"><label>${label}</label>${inner}</div>`;
const saved = (ok, msg) => (ok ? (toast(msg), true) : (toast('Čuvanje nije uspelo.'), false));

registerActions();
function registerActions() {
  actions['edit-budget'] = () => openSheet({ title: 'Mesečni budžet', html: field('Limit u RSD', `<input name="v" type="number" min="1" step="100" required value="${state.budget}">`),
    onSubmit: async (f) => { const v = num(f.v.value); if (!(v > 0)) return false; return saved(await store.setBudget(v), 'Budžet je sačuvan.'); } });

  actions['edit-catbudgets'] = () => openSheet({ title: 'Limiti po kategorijama', html: `<p class="sub">Mesečni limiti u RSD. 0 isključuje limit.</p><div class="formgrid">${SPEND.map((c, i) => field(`${icon(c)} ${esc(c)}`, `<input name="c${i}" type="number" min="0" step="100" value="${state.categoryBudgets[c] || 0}">`)).join('')}</div>`,
    onSubmit: async (f) => { const cb = {}; for (let i = 0; i < SPEND.length; i++) { const v = num(f['c' + i].value); if (!(v >= 0)) return false; if (v > 0) cb[SPEND[i]] = v; } return saved(await store.setCategoryBudgets(cb), 'Limiti su sačuvani.'); } });

  actions['edit-goal'] = () => openSheet({ title: 'Štedni cilj', html: `<div class="formgrid">${field('Naziv', `<input name="name" maxlength="50" required value="${esc(state.goal.name)}">`, 'full')}${field('Cilj (RSD)', `<input name="target" type="number" min="1" step="100" required value="${state.goal.target}">`)}${field('Ušteđeno (RSD)', `<input name="saved" type="number" min="0" step="100" required value="${state.goal.saved}">`)}</div>`,
    onSubmit: async (f) => { const target = num(f.target.value), sv = num(f.saved.value); if (!f.name.value.trim() || !(target > 0) || !(sv >= 0)) return false; return saved(await store.setGoal({ name: f.name.value.trim(), target, saved: sv }), 'Cilj je sačuvan.'); } });

  actions['goal-deposit'] = () => openSheet({ title: 'Uplata na cilj', html: field('Iznos (RSD, negativan za podizanje)', `<input name="v" type="number" step="100" required>`),
    onSubmit: async (f) => { const v = num(f.v.value); if (!Number.isFinite(v) || v === 0) return false; return saved(await store.goalDeposit(v), 'Cilj je ažuriran.'); } });

  actions['add-bill'] = () => openSheet({ title: 'Redovni račun', html: `<div class="formgrid">${field('Naziv', `<input name="name" maxlength="70" required placeholder="Struja, internet, kirija">`, 'full')}${field('Iznos', `<input name="amount" type="number" min="0.01" step="0.01" required>`)}${field('Valuta', `<select name="cur"><option>RSD</option><option>EUR</option></select>`)}${field('Dan dospeća (1–28)', `<input name="day" type="number" min="1" max="28" value="15" required>`)}${field('Kategorija', `<select name="cat">${['Računi', 'Stanovanje', 'Prevoz', 'Zdravlje', 'Ostalo'].map((c) => `<option>${c}</option>`).join('')}</select>`)}</div>`,
    onSubmit: async (f) => { const amount = num(f.amount.value), day = Math.round(num(f.day.value)); if (!f.name.value.trim() || !(amount > 0) || day < 1 || day > 28) { toast('Proveri naziv, iznos i dan (1–28).'); return false; } return saved(await store.addBill({ name: f.name.value.trim(), amount, currency: f.cur.value, day, category: f.cat.value }), 'Račun je sačuvan.'); } });

  actions['pay-bill'] = (el) => {
    const b = state.bills.find((x) => x.id === el.dataset.id); if (!b) return;
    return openSheet({ title: `Plaćeno: ${b.name}`, submitLabel: 'Evidentiraj plaćanje', html: `<p class="sub">${fmt(b.amount, b.currency)} će biti upisano kao trošak.</p>${field('Sa računa', `<select name="acc">${state.accounts.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join('')}</select>`)}`,
      onSubmit: async (f) => saved(await store.payBill(b.id, f.acc.value), 'Plaćanje je dodato u transakcije.') });
  };
  actions['del-bill'] = async (el) => { if (await confirmSheet('Obrisati redovni račun? Već evidentirana plaćanja ostaju.', 'Obriši')) { await store.deleteBill(el.dataset.id); toast('Račun je obrisan.'); } };

  actions['add-account'] = () => openSheet({ title: 'Novi račun', html: `<div class="formgrid">${field('Naziv', `<input name="name" maxlength="40" required>`, 'full')}${field('Valuta', `<select name="cur"><option>RSD</option><option>EUR</option></select>`)}</div>`,
    onSubmit: async (f) => f.name.value.trim() ? saved(await store.addAccount(f.name.value.trim(), f.cur.value), 'Račun je dodat.') : false });
  actions['del-account'] = async (el) => {
    if (state.transactions.some((t) => t.accountId === el.dataset.id || t.toAccountId === el.dataset.id)) { toast('Račun ima transakcije — prvo ih prebaci ili obriši.'); return; }
    if (await confirmSheet('Obrisati ovaj račun?', 'Obriši')) { await store.deleteAccount(el.dataset.id); toast('Račun je obrisan.'); }
  };
  actions['transfer'] = () => {
    if (state.accounts.length < 2) { toast('Potrebna su najmanje dva računa.'); return; }
    const opts = (i) => state.accounts.map((a, k) => `<option value="${a.id}" ${k === i ? 'selected' : ''}>${esc(a.name)} (${a.currency})</option>`).join('');
    return openSheet({ title: 'Prenos između računa', html: `<div class="formgrid">${field('Sa računa', `<select name="from">${opts(0)}</select>`)}${field('Na račun', `<select name="to">${opts(1)}</select>`)}${field('Iznos (u valuti izvornog računa)', `<input name="amount" type="number" min="0.01" step="0.01" required>`)}${field('Datum', `<input name="date" type="date" value="${today()}" required>`)}</div><div class="preview" data-p></div>`,
      onOpen: (f) => { const u = () => { const a = state.accounts.find((x) => x.id === f.from.value), b = state.accounts.find((x) => x.id === f.to.value), v = num(f.amount.value); f.querySelector('[data-p]').textContent = a && b && v > 0 ? (a.id === b.id ? 'Izaberi dva različita računa.' : `Stiže: ${fmt(round2(a.currency === b.currency ? v : a.currency === 'EUR' ? v * state.rate : v / state.rate), b.currency)}`) : ''; }; f.addEventListener('input', u); },
      onSubmit: async (f) => { const v = num(f.amount.value); if (f.from.value === f.to.value || !(v > 0)) { toast('Izaberi dva različita računa i iznos veći od nule.'); return false; } return saved(await store.addTransfer({ fromId: f.from.value, toId: f.to.value, amount: v, date: f.date.value || today() }), 'Prenos je evidentiran.'); } });
  };

  actions['add-wealth'] = () => openSheet({ title: 'Imovina ili dug', html: `<div class="formgrid">${field('Vrsta', `<select name="kind"><option value="asset">Imovina</option><option value="debt">Dugovanje</option></select>`)}${field('Valuta', `<select name="cur"><option>RSD</option><option>EUR</option></select>`)}${field('Naziv', `<input name="name" maxlength="60" required placeholder="Štednja, auto, kredit">`, 'full')}${field('Vrednost', `<input name="amount" type="number" min="0.01" step="0.01" required>`, 'full')}</div>`,
    onSubmit: async (f) => { const amount = num(f.amount.value); if (!f.name.value.trim() || !(amount > 0)) return false; return saved(await store.addWealth(f.kind.value, { name: f.name.value.trim(), amount, currency: f.cur.value }), 'Stavka je sačuvana.'); } });
  actions['del-wealth'] = async (el) => { if (await confirmSheet('Obrisati ovu stavku?', 'Obriši')) { await store.deleteWealth(el.dataset.kind, el.dataset.id); toast('Stavka je obrisana.'); } };
}
