import { $, esc, fmt, monthKey, monthLabel, toast, download, today, shiftMonth } from '../util.js';
import * as store from '../store.js';
import { state } from '../store.js';
import { flows, inMonth, expenseByCategory, trend, toRSD } from '../calc.js';
import * as db from '../db.js';
import { actions, openSheet, confirmSheet } from '../sheet.js';
import { demoState, normalize } from '../migrate.js';
import { icon, empty } from './common.js';
import { trendChart } from './overview.js';

let reportMonth = monthKey();
let storageInfo = null;
const mb = (b) => (b == null ? '—' : b > 1e6 ? (b / 1e6).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1e3)) + ' KB');

export async function refreshStorageInfo() { storageInfo = await db.storageInfo(); }

export function render(el) {
  const txs = inMonth(state, reportMonth);
  const { income, expense, net } = flows(txs, state);
  const cats = expenseByCategory(txs, state);
  const si = storageInfo;
  const lb = state.lastBackup ? new Date(state.lastBackup) : null;
  const days = lb ? Math.floor((Date.now() - lb) / 86400000) : null;

  el.innerHTML = `
  <section class="card"><h3>Mesečni izveštaj</h3>
    <div class="monthbar"><button class="btn ghost" data-action="rep-month" data-d="-1" aria-label="Prethodni mesec">‹</button><div class="monthlabel">${esc(monthLabel(reportMonth))}</div><button class="btn ghost" data-action="rep-month" data-d="1" aria-label="Sledeći mesec">›</button></div>
    <div class="stats three"><div class="stat"><div class="label">PRIHODI</div><div class="v pos">${fmt(income)}</div></div><div class="stat"><div class="label">TROŠKOVI</div><div class="v neg">${fmt(expense)}</div></div><div class="stat"><div class="label">NETO</div><div class="v ${net >= 0 ? 'pos' : 'neg'}">${fmt(net)}</div></div></div>
    <h4>Trend (6 meseci do izabranog)</h4>${trendChart(trend(state, 6, reportMonth))}
    <h4>Troškovi po kategoriji</h4>
    ${cats.length ? cats.map(([c, v]) => `<div class="catrow"><div class="row"><span>${icon(c)} ${esc(c)}</span><b>${fmt(v)}</b></div><div class="track"><span style="width:${Math.max(2, (v / Math.max(expense, 1)) * 100)}%"></span></div></div>`).join('') : empty('Nema podataka za izabrani mesec.')}
    <div class="actions"><button class="btn ghost" data-action="export-month">Izvezi mesec (CSV)</button><button class="btn ghost" data-action="export-all-csv">Izvezi sve (CSV)</button></div></section>

  <section class="card"><h3>Kurs EUR/RSD</h3>
    <div class="sub">Kurs se ručno podešava i ne ažurira se sam (aplikacija radi bez interneta). Svaka transakcija pamti kurs iz trenutka unosa, pa promena kursa ne menja stare unose.</div>
    <div class="actions"><button class="btn ghost" data-action="edit-rate">1 EUR = ${fmt(state.rate)} — promeni</button></div></section>

  <section class="card"><h3>Podaci na ovom uređaju</h3>
    <div class="row"><span>Skladište</span><b>${si ? esc(si.backend) : '…'}</b></div>
    <div class="row"><span>Zaštićeno od automatskog brisanja</span><b class="${si?.persisted ? 'pos' : ''}">${si ? (si.persisted ? 'Da' : 'Ne (zatraženo)') : '…'}</b></div>
    <div class="row"><span>Zauzeto</span><b>${si ? mb(si.usage) : '…'}</b></div>
    <div class="row"><span>Poslednja kopija</span><b class="${days == null || days > 30 ? 'neg' : ''}">${lb ? lb.toLocaleDateString('sr-Latn-RS') + ` (pre ${days} d)` : 'Nikad'}</b></div>
    <div class="sub">Podaci su samo u memoriji ovog pregledača. Brisanje podataka sajta, deinstalacija ili reset telefona ih briše — zato povremeno sačuvaj JSON kopiju. Aplikacija automatski čuva i 14 dnevnih internih kopija.</div>
    <div class="actions"><button class="btn" data-action="backup">Preuzmi kopiju (JSON)</button><button class="btn ghost" data-action="share-backup">Podeli…</button><button class="btn ghost" data-action="restore">Vrati iz kopije</button><button class="btn ghost" data-action="snapshots">Interne kopije</button></div>
    <input id="restoreFile" type="file" accept=".json,application/json" hidden></section>

  <section class="card"><h3>Profili</h3>
    ${store.profiles.map((p) => `<div class="row"><span>${p.id === store.activeId ? '● ' : '○ '}<b>${esc(p.name)}</b></span><span>${p.id === store.activeId ? '<span class="sub">aktivan</span>' : `<button class="link" data-action="switch-profile" data-id="${p.id}">Prebaci</button>`} <button class="link" data-action="rename-profile" data-id="${p.id}">Preimenuj</button>${store.profiles.length > 1 ? ` <button class="link neg" data-action="del-profile" data-id="${p.id}">Obriši</button>` : ''}</span></div>`).join('')}
    <div class="actions"><button class="btn ghost" data-action="add-profile">+ Novi profil</button><button class="btn ghost" data-action="add-demo">Probni profil</button></div></section>

  <section class="card"><h3>Obaveštenja</h3>
    <div class="sub" id="notifStatus">${!('Notification' in window) ? 'Ovaj pregledač ne podržava obaveštenja. Rokove vidiš u aplikaciji.' : Notification.permission === 'granted' ? 'Dozvoljena. Podsetnik za račune se prikazuje kada otvoriš aplikaciju.' : Notification.permission === 'denied' ? 'Blokirana u pregledaču.' : 'Nisu uključena.'}</div>
    <div class="actions"><button class="btn ghost" data-action="enable-notif">Uključi obaveštenja</button></div></section>

  <section class="card"><h3>O aplikaciji</h3><div class="sub">Finance Hub 27 · radi potpuno offline, bez servera i bez naloga. Podaci nikad ne napuštaju uređaj. Nije bankarska aplikacija niti poreski savet.</div>
    <div class="actions"><button class="btn danger-solid" data-action="clear-all">Obriši sve podatke profila</button></div></section>`;
}

const csvCell = (v) => '"' + String(v).replace(/"/g, '""') + '"';
function csv(rows) { return '﻿' + rows.map((r) => r.map(csvCell).join(';')).join('\r\n'); }
const typeLabel = { income: 'Prihod', expense: 'Trošak', transfer: 'Prenos' };
const txRows = (list) => [['Datum', 'Vrsta', 'Naziv', 'Kategorija', 'Iznos', 'Valuta', 'Kurs', 'Protivvrednost RSD', 'Račun', 'Napomena'],
  ...list.slice().sort((a, b) => a.date.localeCompare(b.date)).map((t) => [t.date, typeLabel[t.type], t.title, t.category, t.amount, t.currency, t.rate, t.type === 'transfer' ? '' : Math.round(toRSD(t, state) * 100) / 100, state.accounts.find((a) => a.id === t.accountId)?.name || '', t.note || ''])];

async function doBackup(share) {
  const payload = JSON.stringify(store.exportPayload(), null, 2);
  const name = `finance-hub-kopija-${today()}.json`;
  if (share && navigator.canShare) {
    const file = new File([payload], name, { type: 'application/json' });
    if (navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file], title: 'Finance Hub kopija' }); await store.markBackup(); return; } catch (e) { if (e.name === 'AbortError') return; } }
  }
  download(name, payload, 'application/json');
  await store.markBackup();
  toast('Kopija je preuzeta.');
}

actions['rep-month'] = (el) => { reportMonth = shiftMonth(reportMonth, Number(el.dataset.d)); store.state && document.dispatchEvent(new Event('fh:rerender')); };
actions['export-month'] = () => { const l = inMonth(state, reportMonth); if (!l.length) return toast('Nema transakcija za izabrani mesec.'); download(`finance-hub-${reportMonth}.csv`, csv(txRows(l)), 'text/csv;charset=utf-8'); };
actions['export-all-csv'] = () => { if (!state.transactions.length) return toast('Nema transakcija.'); download(`finance-hub-sve-${today()}.csv`, csv(txRows(state.transactions)), 'text/csv;charset=utf-8'); };
actions['backup'] = () => doBackup(false);
actions['share-backup'] = () => doBackup(true);
actions['restore'] = () => $('#restoreFile').click();
document.addEventListener('change', async (e) => {
  if (e.target.id !== 'restoreFile') return;
  const inp = e.target, f = inp.files[0];
  inp.value = '';
  if (!f) return;
  let raw;
  try { raw = JSON.parse(await f.text()); } catch { return toast('Datoteka nije ispravna Finance Hub kopija.'); }
  try { normalize(raw); } catch (err) { return toast(err.message); }
  if (!(await confirmSheet('Vratiti ovu kopiju? Trenutni podaci profila biće zamenjeni (interna kopija se čuva).', 'Vrati', false))) return;
  toast((await store.replaceState(raw)) ? 'Kopija je vraćena.' : 'Vraćanje nije uspelo.');
});
actions['snapshots'] = async () => {
  const list = await store.listSnapshots();
  await openSheet({ title: 'Interne dnevne kopije', html: list.length ? list.map((s) => `<div class="row"><span><b>${esc(s.date)}</b> <span class="sub">${s.state.transactions.length} transakcija</span></span><button type="button" class="link" data-snap="${esc(s.key)}">Vrati</button></div>`).join('') : '<p class="sub">Još nema internih kopija. Prva se pravi pre prve izmene svakog dana.</p>',
    onOpen: (form) => form.addEventListener('click', async (e) => { const b = e.target.closest('[data-snap]'); if (!b) return; const s = list.find((x) => x.key === b.dataset.snap); if (s && (await store.replaceState(s.state))) { toast('Vraćeno stanje od ' + s.date); document.querySelector('[data-sheet-close]').click(); } }) });
};
actions['edit-rate'] = () => openSheet({ title: 'Kurs EUR/RSD', html: `<div class="field"><label>1 EUR = koliko RSD?</label><input name="rate" type="number" min="1" step="0.01" required value="${state.rate}"></div><label class="check"><input type="checkbox" name="all"> Primeni i na sve postojeće unose u EUR</label>`,
  onSubmit: async (f) => { const r = Number(f.rate.value); if (!(r > 0)) return false; if (!(await store.setRate(r, f.all.checked))) { toast('Čuvanje nije uspelo.'); return false; } toast('Kurs je sačuvan.'); } });
actions['switch-profile'] = async (el) => { await store.switchProfile(el.dataset.id); toast('Profil promenjen.'); };
actions['rename-profile'] = (el) => { const p = store.profiles.find((x) => x.id === el.dataset.id); return openSheet({ title: 'Preimenuj profil', html: `<div class="field"><label>Naziv</label><input name="n" maxlength="40" required value="${esc(p.name)}"></div>`, onSubmit: async (f) => { await store.renameProfile(p.id, f.n.value.trim() || p.name); } }); };
actions['add-profile'] = () => openSheet({ title: 'Novi profil', html: `<div class="field"><label>Naziv</label><input name="n" maxlength="40" required placeholder="npr. Firma, Porodica"></div>`, onSubmit: async (f) => { if (!f.n.value.trim()) return false; await store.addProfile(f.n.value.trim()); toast('Profil je napravljen.'); } });
actions['add-demo'] = async () => { await store.addProfile('Probni profil', demoState()); toast('Probni profil je napravljen.'); };
actions['del-profile'] = async (el) => { if (await confirmSheet('Obrisati ovaj profil i sve njegove podatke?', 'Obriši')) { await store.deleteProfile(el.dataset.id); toast('Profil je obrisan.'); } };
actions['clear-all'] = async () => { if (await confirmSheet('Obrisati SVE podatke aktivnog profila? Ovo se ne može poništiti (osim iz interne kopije).', 'Obriši sve')) { await store.clearAll(); toast('Podaci su obrisani.'); } };
actions['enable-notif'] = async () => { if (!('Notification' in window)) return toast('Pregledač ne podržava obaveštenja.'); try { await Notification.requestPermission(); } catch {} document.dispatchEvent(new Event('fh:rerender')); };
