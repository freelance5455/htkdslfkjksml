import { $, esc, prettyDate, monthLabel, shiftMonth, monthKey, fmt } from '../util.js';
import { state } from '../store.js';
import { toRSD } from '../calc.js';
import { txRow, empty, accName } from './common.js';

let filter = 'all', query = '', month = 'all';

export const setTxFilter = (f) => { filter = f; };

export function render(el) {
  if (!$('#txList', el)) {
    el.innerHTML = `
    <div class="field"><label for="txSearch">Pretraga</label><input id="txSearch" type="search" placeholder="Naziv, kategorija, napomena…" autocomplete="off"></div>
    <div class="chips" id="txFilters">
      ${[['all', 'Sve'], ['income', 'Prihodi'], ['expense', 'Troškovi'], ['transfer', 'Prenosi'], ['EUR', 'EUR'], ['RSD', 'RSD']].map(([k, l]) => `<button class="chip" data-filter="${k}">${l}</button>`).join('')}
    </div>
    <div class="monthbar"><button class="btn ghost" data-action="tx-month" data-d="-1" aria-label="Prethodni mesec">‹</button>
      <button class="btn ghost" id="txMonthLabel" data-action="tx-month" data-d="0"></button>
      <button class="btn ghost" data-action="tx-month" data-d="1" aria-label="Sledeći mesec">›</button></div>
    <div id="txSummary" class="sub"></div>
    <section class="card" id="txList"></section>`;
    $('#txSearch', el).addEventListener('input', (e) => { query = e.target.value; render(el); });
    $('#txFilters', el).addEventListener('click', (e) => {
      const b = e.target.closest('[data-filter]');
      if (b) { filter = b.dataset.filter; render(el); }
    });
  }
  $('#txFilters', el).querySelectorAll('.chip').forEach((b) => b.classList.toggle('active', b.dataset.filter === filter));
  $('#txMonthLabel', el).textContent = month === 'all' ? 'Svi meseci' : monthLabel(month);

  const q = query.trim().toLocaleLowerCase('sr-Latn-RS');
  const list = state.transactions
    .filter((t) => (month === 'all' || t.date.slice(0, 7) === month)
      && (filter === 'all' || t.type === filter || t.currency === filter)
      && (!q || [t.title, t.category, t.note, t.date, accName(t.accountId)].some((v) => String(v || '').toLocaleLowerCase('sr-Latn-RS').includes(q))))
    .sort((a, b) => (b.date + b.id).localeCompare(a.date + a.id));

  const inc = list.filter((t) => t.type === 'income').reduce((s, t) => s + toRSD(t, state), 0);
  const exp = list.filter((t) => t.type === 'expense').reduce((s, t) => s + toRSD(t, state), 0);
  $('#txSummary', el).textContent = `${list.length} stavki · prihodi ${fmt(inc)} · troškovi ${fmt(exp)}`;

  let lastDate = '';
  $('#txList', el).innerHTML = list.length
    ? list.slice(0, 300).map((t) => {
        const head = t.date !== lastDate ? `<div class="daysep">${esc(prettyDate(t.date))}</div>` : '';
        lastDate = t.date;
        return head + txRow(t);
      }).join('') + (list.length > 300 ? empty('Prikazano prvih 300. Suzi pretragu ili izaberi mesec.') : '')
    : empty('Nema transakcija za izabrane filtere.');
}

export function shiftTxMonth(d) {
  if (d === 0) month = month === 'all' ? monthKey() : 'all';
  else month = shiftMonth(month === 'all' ? monthKey() : month, d);
}
