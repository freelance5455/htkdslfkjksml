import { $, $$, esc, fmt, fmtSigned, monthKey, monthLabel, shiftMonth, pad } from '../util.js';
import { state } from '../store.js';
import { flows, inMonth, expenseByCategory, trend, accountBalance, toRSD } from '../calc.js';
import { actions } from '../sheet.js';
import * as charts from '../charts.js';

let range = 6; // meseci za trend grafikone
let observers = [];
let viewer = null; // { auto, usedApi, idx }

const mlabel = (k) => monthLabel(k, { month: 'short' });

// Definicije grafikona: id, naslov, opis, funkcija koja pravi SVG za zadatu veličinu
function defs() {
  const key = monthKey();
  return [
    { id: 'flow', title: 'Prihodi i troškovi', sub: `Poslednjih ${range} meseci · linija = neto`, draw: (w, h) => charts.incomeExpense({ w, h, data: trend(state, range).map((m) => ({ ...m, label: mlabel(m.key) })) }) },
    { id: 'cats', title: 'Potrošnja po kategoriji', sub: monthLabel(key), draw: (w, h) => {
      const list = expenseByCategory(inMonth(state, key), state);
      const top = list.slice(0, 6).map(([label, value]) => ({ label, value }));
      const rest = list.slice(6).reduce((s, [, v]) => s + v, 0);
      if (rest > 0) top.push({ label: 'Ostale kategorije', value: rest });
      return charts.donut({ w, h, items: top });
    } },
    { id: 'balance', title: 'Saldo kroz vreme', sub: `Stanje na kraju meseca · ${range} meseci`, draw: (w, h) => {
      const months = Array.from({ length: range }, (_, i) => shiftMonth(key, i - range + 1));
      const real = state.transactions.filter((t) => t.type !== 'transfer');
      const values = months.map((m) => { const end = m + '-31'; return Math.round(flows(real.filter((t) => t.date <= end), state).net); });
      return charts.lineArea({ w, h, labels: months.map(mlabel), series: [{ name: 'Saldo', color: charts.COLORS.line, values, area: true }], every: w < 380 && range > 6 ? 2 : 1 });
    } },
    { id: 'month', title: 'Potrošnja kroz mesec', sub: 'Kumulativno u odnosu na budžet', draw: (w, h) => {
      const now = new Date(), days = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate(), today = now.getDate();
      const perDay = Array(days).fill(0);
      inMonth(state, key).filter((t) => t.type === 'expense').forEach((t) => { perDay[Number(t.date.slice(8, 10)) - 1] += toRSD(t, state); });
      let acc = 0;
      const values = perDay.slice(0, today).map((v) => Math.round((acc += v)));
      const labels = Array.from({ length: today }, (_, i) => String(i + 1));
      return charts.lineArea({ w, h, labels, series: [{ name: 'Potrošeno', color: charts.COLORS.exp, values, area: true }], refs: [{ value: state.budget, color: charts.COLORS.amber, label: 'Budžet ' + fmt(state.budget) }], every: Math.ceil(today / (w < 380 ? 6 : 12)) });
    } },
    { id: 'limits', title: 'Limiti po kategorijama', sub: 'Potrošeno / mesečni limit', draw: (w, h) => {
      const spent = Object.fromEntries(expenseByCategory(inMonth(state, key), state));
      const items = Object.entries(state.categoryBudgets).map(([label, limit]) => ({ label, limit, value: Math.round(spent[label] || 0) })).sort((a, b) => b.value / b.limit - a.value / a.limit).slice(0, 7);
      return items.length ? charts.hbars({ w, h, items }) : charts.hbars({ w, h, items: [] }).replace('Nema podataka', 'Postavi limite u Planovi → Limiti');
    } },
    { id: 'accounts', title: 'Stanje po računima', sub: 'U RSD protivvrednosti', draw: (w, h) =>
      charts.hbars({ w, h, items: state.accounts.map((a) => { const b = accountBalance(state, a); return { label: a.name, value: Math.round(a.currency === 'EUR' ? b * state.rate : b) }; }) }) },
  ];
}

function kpis() {
  const key = monthKey(), { income, expense, net } = flows(inMonth(state, key), state);
  const last = trend(state, 6).filter((m) => m.expense > 0);
  const avg = last.length ? last.reduce((s, m) => s + m.expense, 0) / last.length : 0;
  const rate = income > 0 ? Math.round((net / income) * 100) : null;
  return [
    ['Neto ovog meseca', fmtSigned(Math.round(net)), net >= 0 ? 'pos' : 'neg'],
    ['Štedna stopa', rate == null ? '—' : rate + '%', rate != null && rate < 0 ? 'neg' : 'pos'],
    ['Prosečni mesečni trošak', fmt(Math.round(avg)), ''],
    ['Troškovi ovog meseca', fmt(Math.round(expense)), 'neg'],
  ];
}

// Crta grafikon u kutiju i prati promenu njene veličine (rotacija, resize)
function mount(box, def) {
  const draw = () => {
    const w = Math.floor(box.clientWidth), h = Math.floor(box.clientHeight);
    if (w < 40 || h < 40) return;
    box.innerHTML = def.draw(w, h);
  };
  draw();
  const ro = new ResizeObserver(draw);
  ro.observe(box);
  observers.push(ro);
}
const cleanup = () => { observers.forEach((o) => o.disconnect()); observers = []; };

export function render(el) {
  cleanup();
  const list = defs();
  el.innerHTML = `
    <div class="kpis">${kpis().map(([l, v, c]) => `<div class="stat"><div class="label">${esc(l)}</div><div class="v ${c}">${esc(v)}</div></div>`).join('')}</div>
    <div class="dash-bar"><div class="chips">${[3, 6, 12].map((n) => `<button class="chip ${n === range ? 'active' : ''}" data-action="dash-range" data-n="${n}">${n} mes.</button>`).join('')}</div>
      <button class="btn ghost" data-action="open-chart" data-i="0">⛶ Preko celog ekrana</button></div>
    <div class="sub">Dodirni grafikon ili okreni telefon vodoravno za prikaz preko celog ekrana.</div>
    <div class="dash-grid">${list.map((d, i) => `<section class="card chart-card" data-action="open-chart" data-i="${i}" role="button" tabindex="0" aria-label="${esc(d.title)} — otvori preko celog ekrana">
      <div class="row"><h3>${esc(d.title)}</h3><span class="sub">${esc(d.sub)}</span></div><div class="chart-box" data-chart="${d.id}"></div></section>`).join('')}</div>`;
  $$('.chart-box', el).forEach((box, i) => mount(box, list[i]));
}

/* ---------- Prikaz preko celog ekrana ---------- */
export function isViewerOpen() { return !!viewer; }
export function isViewerAuto() { return !!viewer?.auto; }

export async function openViewer(idx = 0, { auto = false } = {}) {
  if (viewer) return;
  const list = defs();
  const root = $('#fs');
  viewer = { auto, usedApi: false, idx };
  root.hidden = false;
  document.body.classList.add('noscroll');
  root.innerHTML = `
    <div class="fs-bar"><div class="fs-title"><b id="fsTitle"></b> <span class="sub" id="fsSub"></span></div>
      <div class="chips">${[3, 6, 12].map((n) => `<button class="chip ${n === range ? 'active' : ''}" data-action="dash-range" data-n="${n}">${n}m</button>`).join('')}</div>
      <button class="btn ghost" data-action="close-chart" aria-label="Zatvori">✕</button></div>
    <div class="fs-readout" id="fsReadout">Dodirni stubić ili tačku za detalje</div>
    <div class="fs-pager" id="fsPager">${list.map((d) => `<div class="fs-page"><div class="chart-box" data-chart="${d.id}"></div></div>`).join('')}</div>
    <div class="fs-dots" id="fsDots">${list.map((_, i) => `<i data-i="${i}"></i>`).join('')}</div>`;
  const pager = $('#fsPager');
  cleanup();
  $$('.chart-box', root).forEach((box, i) => mount(box, list[i]));
  const setIdx = (i) => {
    viewer.idx = i;
    $('#fsTitle').textContent = list[i].title;
    $('#fsSub').textContent = list[i].sub;
    $$('#fsDots i').forEach((d, k) => d.classList.toggle('on', k === i));
    $('#fsReadout').textContent = 'Dodirni stubić ili tačku za detalje';
  };
  pager.scrollTo({ left: idx * pager.clientWidth });
  setIdx(idx);
  pager.addEventListener('scroll', () => { const i = Math.round(pager.scrollLeft / pager.clientWidth); if (i !== viewer?.idx) setIdx(i); }, { passive: true });
  root.onclick = (e) => { const t = e.target.closest('[data-tip]'); if (t) $('#fsReadout').textContent = t.dataset.tip; };
  $('#fsDots').onclick = (e) => { const d = e.target.closest('i'); if (d) pager.scrollTo({ left: Number(d.dataset.i) * pager.clientWidth, behavior: 'smooth' }); };

  // Pravi fullscreen (Android/desktop) + zaključavanje vodoravnog položaja kad je moguće. Na iOS-u pokriva ceo prozor.
  if (!auto) {
    try {
      if (root.requestFullscreen) { await root.requestFullscreen({ navigationUI: 'hide' }); viewer.usedApi = true; }
    } catch {}
    try { await screen.orientation?.lock?.('landscape'); } catch {}
  }
}

export function closeViewer() {
  if (!viewer) return;
  const v = viewer;
  viewer = null;
  cleanup();
  const root = $('#fs');
  root.hidden = true;
  root.innerHTML = '';
  document.body.classList.remove('noscroll');
  try { if (document.fullscreenElement) document.exitFullscreen(); } catch {}
  try { screen.orientation?.unlock?.(); } catch {}
  document.dispatchEvent(new CustomEvent('fh:viewer-closed', { detail: v }));
}

// Ponovo iscrtaj (npr. promena perioda) bez zatvaranja
export function refreshViewer() {
  if (!viewer) return;
  const { auto, idx } = viewer;
  const usedApi = viewer.usedApi;
  viewer = null; cleanup();
  openViewerKeep(idx, auto, usedApi);
}
async function openViewerKeep(idx, auto, usedApi) {
  await openViewer(idx, { auto: true }); // bez ponovnog fullscreen zahteva
  viewer.auto = auto; viewer.usedApi = usedApi;
}

actions['dash-range'] = (el) => { range = Number(el.dataset.n); if (viewer) refreshViewer(); document.dispatchEvent(new Event('fh:rerender')); };
actions['open-chart'] = (el) => openViewer(Number(el.dataset.i) || 0);
actions['close-chart'] = () => closeViewer();

// Izlazak iz pravog fullscreen-a sistemskim gestom zatvara i prikaz
document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement && viewer?.usedApi) closeViewer(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && viewer) closeViewer(); });
