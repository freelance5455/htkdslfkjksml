import { $, esc, today, toast, isDate, fmt, round2 } from '../util.js';
import * as store from '../store.js';
import { CATEGORIES } from '../store.js';
import { convert } from '../calc.js';
import { icon } from './common.js';
import { openSheet, confirmSheet } from '../sheet.js';

const catOptions = (type, selected) => {
  const list = CATEGORIES[type === 'income' ? 'income' : 'expense'].slice();
  if (selected && !list.includes(selected)) list.push(selected);
  return list.map((c) => `<option ${c === selected ? 'selected' : ''}>${esc(c)}</option>`).join('');
};
const accOptions = (sel) => store.state.accounts.map((a) => `<option value="${esc(a.id)}" ${a.id === sel ? 'selected' : ''}>${esc(a.name)} (${a.currency})</option>`).join('');

// Zajednička polja za unos i izmenu
export function txFields(t = {}) {
  const type = t.type || 'expense';
  return `
  <div class="seg" role="group" aria-label="Vrsta"><button type="button" class="${type === 'expense' ? 'active' : ''}" data-type="expense">− Trošak</button><button type="button" class="${type === 'income' ? 'active' : ''}" data-type="income">＋ Prihod</button></div>
  <input type="hidden" name="type" value="${type}">
  <div class="formgrid">
    <div class="field"><label>Iznos</label><input name="amount" type="number" inputmode="decimal" min="0.01" step="0.01" required placeholder="0,00" value="${t.amount ?? ''}"></div>
    <div class="field"><label>Valuta</label><select name="currency"><option ${t.currency !== 'EUR' ? 'selected' : ''}>RSD</option><option ${t.currency === 'EUR' ? 'selected' : ''}>EUR</option></select></div>
    <div class="field full"><label>Naziv</label><input name="title" maxlength="70" required placeholder="npr. Namirnice ili plata" value="${esc(t.title || '')}"></div>
    <div class="field"><label>Kategorija</label><select name="category">${catOptions(type, t.category)}</select></div>
    <div class="field"><label>Račun</label><select name="accountId">${accOptions(t.accountId)}</select></div>
    <div class="field"><label>Datum</label><input name="date" type="date" required value="${t.date || today()}"></div>
    <div class="field"><label>Napomena</label><input name="note" maxlength="100" placeholder="Opciono" value="${esc(t.note || '')}"></div>
  </div>
  <div class="preview" data-preview></div>`;
}

export function wireTxForm(form) {
  const upd = () => {
    const amt = Number(form.amount.value), rate = Number(form.dataset.rate) || store.state.rate;
    const p = form.querySelector('[data-preview]');
    if (!(amt > 0)) { p.textContent = 'Unesi iznos da vidiš protivvrednost.'; return; }
    p.textContent = form.currency.value === 'EUR' ? `${fmt(amt, 'EUR')} ≈ ${fmt(amt * rate)} (kurs ${fmt(rate)})` : `${fmt(amt)} ≈ ${fmt(amt / rate, 'EUR')}`;
  };
  form.addEventListener('input', upd);
  form.addEventListener('click', (e) => {
    const b = e.target.closest('[data-type]');
    if (!b) return;
    form.type.value = b.dataset.type;
    form.querySelectorAll('.seg button').forEach((x) => x.classList.toggle('active', x === b));
    form.category.innerHTML = catOptions(b.dataset.type);
  });
  upd();
}

function readTx(form) {
  const v = Object.fromEntries(new FormData(form));
  const amount = round2(v.amount);
  if (!(amount > 0)) { toast('Unesi iznos veći od nule.'); return null; }
  if (!v.title.trim()) { toast('Unesi naziv.'); return null; }
  if (!isDate(v.date)) { toast('Datum nije ispravan.'); return null; }
  return { type: v.type, amount, currency: v.currency, title: v.title.trim(), category: v.category, accountId: v.accountId, date: v.date, note: v.note.trim() };
}

export function render(el) {
  el.innerHTML = `<section class="card"><form id="addForm" novalidate>${txFields()}
    <div class="quickcats">${CATEGORIES.expense.slice(0, 5).map((c) => `<button type="button" class="chip" data-qcat="${c}">${icon(c)} ${c}</button>`).join('')}</div>
    <div class="actions"><button class="btn" type="submit">+ Sačuvaj transakciju</button><button class="btn ghost" type="reset">Očisti</button></div>
  </form></section>`;
  const form = $('#addForm', el);
  wireTxForm(form);
  form.addEventListener('click', (e) => {
    const q = e.target.closest('[data-qcat]');
    if (q) { form.type.value = 'expense'; form.querySelectorAll('.seg button').forEach((x) => x.classList.toggle('active', x.dataset.type === 'expense')); form.category.innerHTML = catOptions('expense', q.dataset.qcat); form.title.focus(); }
  });
  form.addEventListener('reset', () => setTimeout(() => { form.date.value = today(); form.category.innerHTML = catOptions('expense'); form.querySelectorAll('.seg button').forEach((x) => x.classList.toggle('active', x.dataset.type === 'expense')); form.type.value = 'expense'; form.dispatchEvent(new Event('input')); }));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const t = readTx(form);
    if (!t) return;
    const ok = await store.addTx(t);
    if (!ok) { toast('Čuvanje nije uspelo — pregledač nije dozvolio upis.'); return; }
    toast('Transakcija je sačuvana na uređaju.');
    form.reset();
  });
}

export async function editTx(id) {
  const t = store.state.transactions.find((x) => x.id === id);
  if (!t) return;
  if (t.type === 'transfer') { toast('Prenos se ne menja — obriši ga i unesi ponovo.'); return; }
  await openSheet({
    title: 'Izmena transakcije',
    html: txFields(t),
    onOpen: (form) => { form.dataset.rate = t.rate; wireTxForm(form); },
    onSubmit: async (form) => {
      const patch = readTx(form);
      if (!patch) return false;
      const ok = await store.updateTx(id, patch);
      if (!ok) { toast('Čuvanje nije uspelo.'); return false; }
      toast('Izmena je sačuvana.');
    },
  });
}

export async function deleteTx(id) {
  const t = store.state.transactions.find((x) => x.id === id);
  if (!t || !(await confirmSheet(`Obrisati „${t.title}"?`, 'Obriši'))) return;
  await store.deleteTx(id);
  toast('Transakcija je obrisana.');
}
