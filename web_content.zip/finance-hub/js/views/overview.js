import { esc, fmt, fmtSigned, monthKey, monthLabel } from '../util.js';
import { state } from '../store.js';
import { flows, inMonth, totalBalance, expenseByCategory, trend, upcomingBills, accountBalance } from '../calc.js';
import { txRow, icon, empty, pctClass } from './common.js';

export function trendChart(data) {
  const max = Math.max(1, ...data.flatMap((m) => [m.income, m.expense]));
  return `<div class="trend" role="img" aria-label="Prihodi i troškovi po mesecima">${data.map((m) => `
    <div class="trend-col"><div class="trend-bars">
      <i class="bar inc" title="Prihodi: ${esc(fmt(m.income))}" style="height:${Math.max(2, (m.income / max) * 90)}px"></i>
      <i class="bar exp" title="Troškovi: ${esc(fmt(m.expense))}" style="height:${Math.max(2, (m.expense / max) * 90)}px"></i></div>
      <div class="trend-label">${esc(monthLabel(m.key, { month: 'short' }))}</div></div>`).join('')}</div>
    <div class="legend"><span><i class="dot inc"></i>Prihodi</span><span><i class="dot exp"></i>Troškovi</span></div>`;
}

export function render(el) {
  const key = monthKey();
  const txs = inMonth(state, key);
  const { income, expense, net } = flows(txs, state);
  const balance = totalBalance(state);
  const budget = Math.max(1, state.budget);
  const bp = Math.round((expense / budget) * 100);
  const cats = expenseByCategory(txs, state).slice(0, 4);
  const due = upcomingBills(state, 7);
  const recent = state.transactions.slice().sort((a, b) => (b.date + b.id).localeCompare(a.date + a.id)).slice(0, 5);
  const gp = state.goal.target > 0 ? Math.min(100, Math.round((state.goal.saved / state.goal.target) * 100)) : 0;

  el.innerHTML = `
  <section class="hero card">
    <div class="label">UKUPNI SALDO TRANSAKCIJA</div>
    <div class="big ${balance < 0 ? 'neg' : ''}">${fmt(balance)}</div>
    <div class="sub">≈ ${fmt(balance / state.rate, 'EUR')} · kurs 1 EUR = ${fmt(state.rate)}</div>
    <div class="stats">
      <div class="stat"><div class="label">Prihodi · ${esc(monthLabel(key, { month: 'long' }))}</div><div class="v pos">${fmt(income)}</div></div>
      <div class="stat"><div class="label">Troškovi</div><div class="v neg">${fmt(expense)}</div></div>
      <div class="stat full"><div class="label">Rezultat meseca</div><div class="v ${net >= 0 ? 'pos' : 'neg'}">${fmtSigned(net)}</div></div>
    </div>
  </section>

  ${due.length ? `<section class="card alert"><h3>Rokovi u narednih 7 dana</h3>${due.map((b) => `
    <div class="row"><span><b>${esc(b.name)}</b><br><span class="sub">${b.due} · ${fmt(b.amount, b.currency)}</span></span>
    <b class="${b.days < 0 ? 'neg' : ''}">${b.days < 0 ? 'Kasni ' + -b.days + ' d' : b.days === 0 ? 'Danas' : 'Za ' + b.days + ' d'}</b></div>`).join('')}
    <button class="btn ghost" data-nav="plans">Otvori obaveze</button></section>` : ''}

  <div class="grid2">
    <section class="card"><h3>Mesečni budžet</h3>
      <div class="row"><b>${fmt(expense)}</b><span>${bp}%</span></div>
      <div class="track"><span class="${pctClass(bp)}" style="width:${Math.min(100, bp)}%"></span></div>
      <div class="sub">${expense <= budget ? 'Preostalo ' + fmt(budget - expense) : 'Preko budžeta za ' + fmt(expense - budget)} od ${fmt(budget)}</div></section>
    <section class="card"><h3>Štedni cilj</h3>
      <div class="row"><b>${esc(state.goal.name)}</b><span>${gp}%</span></div>
      <div class="track"><span style="width:${gp}%"></span></div>
      <div class="sub">${fmt(state.goal.saved)} od ${fmt(state.goal.target)}</div></section>
  </div>

  <section class="card"><h3>Potrošnja po kategoriji</h3>
    ${cats.length ? cats.map(([c, v]) => `<div class="catrow"><div class="row"><span>${icon(c)} ${esc(c)}</span><b>${fmt(v)}</b></div><div class="track"><span style="width:${Math.max(2, (v / Math.max(expense, 1)) * 100)}%"></span></div></div>`).join('') : empty('Dodaj troškove da vidiš raspodelu.')}</section>

  <section class="card"><h3>Trend poslednjih 6 meseci</h3>${trendChart(trend(state, 6))}</section>

  <section class="card"><h3>Računi</h3>${state.accounts.map((a) => `<div class="row"><span>${esc(a.name)} <span class="sub">${a.currency}</span></span><b>${fmt(accountBalance(state, a), a.currency)}</b></div>`).join('')}</section>

  <section class="card"><div class="row"><h3>Poslednje transakcije</h3><button class="link" data-nav="transactions">Sve</button></div>
    ${recent.length ? recent.map((t) => txRow(t)).join('') : empty('Još nema unosa. Dodaj prvu transakciju.')}</section>`;
}
