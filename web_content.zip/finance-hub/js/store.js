// Stanje aplikacije, profili i svi upisi. Svaka izmena ide kroz commit(): primeni → upiši u IndexedDB → javi UI-ju.
import * as db from './db.js';
import { blankState, normalize, readLegacyLocalStorage } from './migrate.js';
import { uid, today, round2, clone } from './util.js';
import { convert } from './calc.js';

export const CATEGORIES = {
  expense: ['Hrana', 'Stanovanje', 'Prevoz', 'Računi', 'Zdravlje', 'Zabava', 'Štednja', 'Ostalo'],
  income: ['Plata', 'Honorar', 'Štednja', 'Ostalo'],
};
export const ICONS = { Hrana: '🛒', Stanovanje: '🏠', Prevoz: '🚌', Računi: '🧾', Zdravlje: '✚', Zabava: '🎟️', Plata: '💼', Honorar: '🪙', Štednja: '🐷', Ostalo: '•' };

export let state = blankState();
export let profiles = []; // [{id, name}]
export let activeId = null;

const listeners = new Set();
export const subscribe = (fn) => (listeners.add(fn), () => listeners.delete(fn));
const emit = () => listeners.forEach((f) => f());

let snapDay = null;

async function persistProfiles() {
  await db.setKv('profiles', profiles);
  await db.setKv('active', activeId);
}

async function loadProfileData(id) {
  const rec = await db.get('data', id);
  try { state = rec ? normalize(rec.state) : blankState(); } catch { state = blankState(); }
  snapDay = await db.getKv('snapDay:' + id, null);
}

export async function init() {
  const info = await db.init();
  profiles = await db.getKv('profiles', null);
  activeId = await db.getKv('active', null);
  let imported = 0;

  if (!profiles || !profiles.length) {
    // Prvo pokretanje: pokušaj da preuzmeš podatke stare aplikacije iz localStorage-a (ista adresa).
    const legacy = readLegacyLocalStorage();
    profiles = [];
    if (legacy.length) {
      for (const l of legacy) {
        const id = uid();
        profiles.push({ id, name: l.name });
        await db.put('data', { key: id, state: l.state });
        imported += l.state.transactions.length;
      }
    } else {
      const id = uid();
      profiles.push({ id, name: 'Kuća / lično' });
      await db.put('data', { key: id, state: blankState() });
    }
    activeId = profiles[0].id;
    await persistProfiles();
  }
  if (!profiles.some((p) => p.id === activeId)) activeId = profiles[0].id;
  await loadProfileData(activeId);
  return { ...info, imported };
}

// Dnevna interna kopija stanja PRE izmene. Pravi se kad stanje ima podatke (jednom dnevno), ili uvek pre uvoza/brisanja (force).
async function snapshotIfNeeded(force = false) {
  const t = today();
  const hasData = state.transactions.length || state.bills.length || state.assets.length || state.debts.length;
  if (!hasData || (!force && snapDay === t)) return;
  try {
    await db.put('snapshots', { key: `${activeId}:${t}`, profileId: activeId, date: t, ts: Date.now(), state: clone(state) });
    snapDay = t;
    await db.setKv('snapDay:' + activeId, t);
    const mine = (await db.all('snapshots')).filter((s) => s.profileId === activeId).sort((a, b) => b.date.localeCompare(a.date));
    for (const old of mine.slice(14)) await db.del('snapshots', old.key);
  } catch {}
}

// Primeni izmenu i trajno je upiši. Vraća true samo ako je upis stvarno uspeo (inače vraća staro stanje).
export async function commit(mutator) {
  await snapshotIfNeeded();
  const before = clone(state);
  try {
    mutator(state);
    await db.put('data', { key: activeId, state, savedAt: Date.now() });
    emit();
    db.requestPersistence();
    return true;
  } catch (e) {
    state = before;
    emit();
    console.error(e);
    return false;
  }
}

/* ---------- Transakcije ---------- */
export const addTx = (t) => commit((s) => {
  s.transactions.push({ id: uid(), rate: s.rate, note: '', ...t, amount: round2(t.amount) });
});

export const updateTx = (id, patch) => commit((s) => {
  const i = s.transactions.findIndex((t) => t.id === id);
  if (i < 0) return;
  s.transactions[i] = { ...s.transactions[i], ...patch, amount: round2(patch.amount ?? s.transactions[i].amount) };
});

export const deleteTx = (id) => commit((s) => { s.transactions = s.transactions.filter((t) => t.id !== id); });

export const addTransfer = ({ fromId, toId, amount, date, note }) => commit((s) => {
  const from = s.accounts.find((a) => a.id === fromId), to = s.accounts.find((a) => a.id === toId);
  if (!from || !to || from.id === to.id) throw new Error('Neispravni računi');
  s.transactions.push({
    id: uid(), type: 'transfer', title: `Prenos: ${from.name} → ${to.name}`, category: 'Prenos', note: note || '',
    amount: round2(amount), currency: from.currency, rate: s.rate, date, accountId: from.id, toAccountId: to.id,
    toAmount: round2(convert(amount, from.currency, to.currency, s.rate)),
  });
});

/* ---------- Računi ---------- */
export const addAccount = (name, currency) => commit((s) => { s.accounts.push({ id: 'acc_' + uid(), name, currency }); });
export const deleteAccount = (id) => commit((s) => { s.accounts = s.accounts.filter((a) => a.id !== id); });

/* ---------- Podešavanja ---------- */
export const setRate = (rate, applyToAll) => commit((s) => {
  s.rate = rate;
  if (applyToAll) s.transactions.forEach((t) => { t.rate = rate; });
});
export const setBudget = (v) => commit((s) => { s.budget = v; });
export const setCategoryBudgets = (cb) => commit((s) => { s.categoryBudgets = cb; });
export const setGoal = (goal) => commit((s) => { s.goal = goal; });
export const goalDeposit = (amount) => commit((s) => { s.goal.saved = Math.max(0, round2(s.goal.saved + amount)); });

export const addWealth = (kind, item) => commit((s) => { s[kind === 'asset' ? 'assets' : 'debts'].push({ id: uid(), ...item }); });
export const deleteWealth = (kind, id) => commit((s) => { const k = kind === 'asset' ? 'assets' : 'debts'; s[k] = s[k].filter((x) => x.id !== id); });

export const addBill = (b) => commit((s) => { s.bills.push({ id: uid(), ...b }); });
export const deleteBill = (id) => commit((s) => { s.bills = s.bills.filter((b) => b.id !== id); });
export const payBill = (id, accountId) => commit((s) => {
  const b = s.bills.find((x) => x.id === id);
  if (!b) return;
  s.transactions.push({ id: uid(), billId: id, type: 'expense', title: b.name, amount: b.amount, currency: b.currency, rate: s.rate, category: b.category, date: today(), note: 'Redovni račun — plaćeno', accountId });
});

/* ---------- Kopije i uvoz ---------- */
export function exportPayload() {
  return { app: 'Finance Hub', version: 2, exportedAt: new Date().toISOString(), profile: profiles.find((p) => p.id === activeId)?.name, data: state };
}
export const markBackup = () => commit((s) => { s.lastBackup = new Date().toISOString(); });

export async function replaceState(raw) {
  const next = normalize(raw); // baca grešku ako nije ispravno
  await snapshotIfNeeded(true);
  return commit((s) => { Object.keys(s).forEach((k) => delete s[k]); Object.assign(s, next); });
}

export const clearAll = async () => (await snapshotIfNeeded(true), commit((s) => { const keep = s.rate; Object.keys(s).forEach((k) => delete s[k]); Object.assign(s, blankState(), { rate: keep }); }));

export const listSnapshots = async () => (await db.all('snapshots')).filter((x) => x.profileId === activeId).sort((a, b) => b.date.localeCompare(a.date));

/* ---------- Profili ---------- */
export async function switchProfile(id) {
  if (!profiles.some((p) => p.id === id)) return;
  activeId = id;
  await db.setKv('active', id);
  await loadProfileData(id);
  emit();
}
export async function addProfile(name, initial = blankState()) {
  const id = uid();
  profiles.push({ id, name });
  await db.put('data', { key: id, state: initial });
  await persistProfiles();
  await switchProfile(id);
}
export async function renameProfile(id, name) {
  const p = profiles.find((x) => x.id === id);
  if (p) { p.name = name; await persistProfiles(); emit(); }
}
export async function deleteProfile(id) {
  if (profiles.length < 2) return false;
  profiles = profiles.filter((p) => p.id !== id);
  await db.del('data', id);
  for (const s of await db.all('snapshots')) if (s.profileId === id) await db.del('snapshots', s.key);
  await persistProfiles();
  if (activeId === id) await switchProfile(profiles[0].id); else emit();
  return true;
}
