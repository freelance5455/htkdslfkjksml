// Čisti proračuni nad stanjem (bez DOM-a i bez upisa).
import { monthKey, shiftMonth, dateKey } from './util.js';

export const rateOf = (t, state) => Number(t.rate) > 0 ? Number(t.rate) : Number(state.rate) || 117.2;

export function convert(amount, from, to, rate) {
  if (from === to) return amount;
  return from === 'EUR' ? amount * rate : amount / rate; // EUR→RSD ili RSD→EUR
}

// Vrednost stavke u RSD. Transakcije koriste kurs iz trenutka unosa (t.rate).
export const toRSD = (t, state) => (t.currency === 'EUR' ? Number(t.amount) * rateOf(t, state) : Number(t.amount));
// Imovina i dugovi uvek koriste trenutni kurs.
export const wealthRSD = (x, state) => (x.currency === 'EUR' ? Number(x.amount) * state.rate : Number(x.amount));

export const flows = (txs, state) => {
  let income = 0, expense = 0;
  for (const t of txs) {
    if (t.type === 'income') income += toRSD(t, state);
    else if (t.type === 'expense') expense += toRSD(t, state);
  }
  return { income, expense, net: income - expense };
};

export const inMonth = (state, key) => state.transactions.filter((t) => t.date.slice(0, 7) === key);

export const totalBalance = (state) => flows(state.transactions, state).net;

export function accountBalance(state, acc) {
  let sum = 0;
  for (const t of state.transactions) {
    const rate = rateOf(t, state);
    if (t.type === 'transfer') {
      if (t.accountId === acc.id) sum -= convert(t.amount, t.currency, acc.currency, rate);
      if (t.toAccountId === acc.id) sum += Number(t.toAmount);
    } else if (t.accountId === acc.id) {
      const v = convert(Number(t.amount), t.currency, acc.currency, rate);
      sum += t.type === 'income' ? v : -v;
    }
  }
  return sum;
}

export function expenseByCategory(txs, state) {
  const out = {};
  for (const t of txs) if (t.type === 'expense') out[t.category] = (out[t.category] || 0) + toRSD(t, state);
  return Object.entries(out).sort((a, b) => b[1] - a[1]);
}

export function trend(state, months = 6, endKey = monthKey()) {
  const out = [];
  for (let i = months - 1; i >= 0; i--) {
    const key = shiftMonth(endKey, -i);
    out.push({ key, ...flows(inMonth(state, key), state) });
  }
  return out;
}

export const paidBillIds = (state, key = monthKey()) =>
  new Set(state.transactions.filter((t) => t.billId && t.date.slice(0, 7) === key).map((t) => t.billId));

export function billDue(bill, now = new Date()) {
  const day = Math.min(28, Math.max(1, Number(bill.day) || 1));
  return dateKey(new Date(now.getFullYear(), now.getMonth(), day));
}

export function upcomingBills(state, withinDays = 7, now = new Date()) {
  const paid = paidBillIds(state, monthKey(now));
  const t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return state.bills
    .filter((b) => !paid.has(b.id))
    .map((b) => {
      const due = billDue(b, now);
      const days = Math.round((new Date(due + 'T00:00:00') - t0) / 86400000);
      return { ...b, due, days };
    })
    .filter((b) => b.days <= withinDays)
    .sort((a, b) => a.days - b.days);
}

// Prognoza: prosečan neto tok poslednja 3 meseca u kojima ima podataka.
export function forecast(state, now = new Date()) {
  const cur = monthKey(now);
  const last3 = [2, 1, 0].map((i) => shiftMonth(cur, -i));
  const known = last3.map((k) => inMonth(state, k).filter((t) => t.type !== 'transfer')).filter((l) => l.length);
  const avg = known.length ? known.reduce((s, l) => s + flows(l, state).net, 0) / known.length : 0;
  const base = totalBalance(state);
  return { avg, knownMonths: known.length, points: [1, 2, 3].map((i) => ({ key: shiftMonth(cur, i), balance: base + avg * i })) };
}
