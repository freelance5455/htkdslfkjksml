// SVG grafikoni bez biblioteka (rade offline). Svaka funkcija prima {w,h} u pikselima i vraća SVG string.
import { esc, fmt } from './util.js';

export const COLORS = { inc: '#35d6b0', exp: '#ff7585', line: '#7aa2ff', grid: '#263744', txt: '#91a0b1', amber: '#f5b942', ink: '#edf4f8' };
export const PALETTE = ['#35d6b0', '#7aa2ff', '#f5b942', '#ff7585', '#b48cff', '#4fd1e8', '#8da0b3'];

const short = (n) => { const a = Math.abs(n), s = n < 0 ? '−' : ''; return a >= 1e6 ? s + +(a / 1e6).toFixed(1) + 'M' : a >= 1e3 ? s + Math.round(a / 1e3) + 'k' : s + Math.round(a); };
const niceMax = (v) => { if (v <= 0) return 1; const p = 10 ** Math.floor(Math.log10(v)); for (const m of [1, 2, 2.5, 5, 10]) if (v <= m * p) return m * p; return 10 * p; };
const svg = (w, h, body, label) => `<svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" role="img" aria-label="${esc(label)}" font-family="system-ui,sans-serif">${body}</svg>`;
const none = (w, h, msg = 'Nema podataka') => svg(w, h, `<text x="${w / 2}" y="${h / 2}" fill="${COLORS.txt}" font-size="13" text-anchor="middle">${esc(msg)}</text>`, msg);

// Zajednički okvir: Y osa sa mrežom
function frame(w, h, lo, hi, left = 40) {
  const pad = { l: left, r: 10, t: 12, b: 26 };
  const iw = w - pad.l - pad.r, ih = h - pad.t - pad.b;
  const y = (v) => pad.t + ih - ((v - lo) / (hi - lo || 1)) * ih;
  let grid = '';
  for (let i = 0; i <= 4; i++) {
    const v = lo + ((hi - lo) * i) / 4, yy = y(v);
    grid += `<line x1="${pad.l}" x2="${w - pad.r}" y1="${yy}" y2="${yy}" stroke="${COLORS.grid}" stroke-width="1"/><text x="${pad.l - 6}" y="${yy + 4}" fill="${COLORS.txt}" font-size="10.5" text-anchor="end">${short(v)}</text>`;
  }
  return { pad, iw, ih, y, grid };
}
const xLabels = (labels, f, w, every = 1) => labels.map((l, i) => (i % every ? '' : `<text x="${f.pad.l + (f.iw / labels.length) * (i + 0.5)}" y="${w}" fill="${COLORS.txt}" font-size="10.5" text-anchor="middle">${esc(l)}</text>`)).join('');

// Grupisani stubići: prihodi i troškovi po mesecima, uz liniju neto rezultata.
export function incomeExpense({ w, h, data }) {
  if (!data.some((d) => d.income || d.expense)) return none(w, h);
  const hi = niceMax(Math.max(...data.flatMap((d) => [d.income, d.expense])));
  const lo = Math.min(0, ...data.map((d) => d.net));
  const loN = lo < 0 ? -niceMax(-lo) : 0;
  const f = frame(w, h, loN, hi);
  const slot = f.iw / data.length, bw = Math.min(26, slot * 0.34);
  let out = f.grid;
  data.forEach((d, i) => {
    const cx = f.pad.l + slot * (i + 0.5), y0 = f.y(0);
    out += `<rect data-tip="${esc(d.label)} · prihodi ${esc(fmt(d.income))}" x="${cx - bw - 1}" y="${f.y(d.income)}" width="${bw}" height="${Math.max(1, y0 - f.y(d.income))}" rx="3" fill="${COLORS.inc}"/>`;
    out += `<rect data-tip="${esc(d.label)} · troškovi ${esc(fmt(d.expense))}" x="${cx + 1}" y="${f.y(d.expense)}" width="${bw}" height="${Math.max(1, y0 - f.y(d.expense))}" rx="3" fill="${COLORS.exp}"/>`;
  });
  const pts = data.map((d, i) => [f.pad.l + slot * (i + 0.5), f.y(d.net)]);
  out += `<polyline fill="none" stroke="${COLORS.amber}" stroke-width="2" points="${pts.map((p) => p.join(',')).join(' ')}"/>`;
  out += pts.map((p, i) => `<circle data-tip="${esc(data[i].label)} · neto ${esc(fmt(data[i].net))}" cx="${p[0]}" cy="${p[1]}" r="4" fill="${COLORS.amber}"/>`).join('');
  out += xLabels(data.map((d) => d.label), f, h - 8, slot < 34 ? 2 : 1);
  return svg(w, h, out, 'Prihodi, troškovi i neto rezultat po mesecima');
}

// Linija / površina (npr. saldo kroz vreme, kumulativna potrošnja)
export function lineArea({ w, h, labels, series, refs = [], every = 1 }) {
  const all = series.flatMap((s) => s.values).concat(refs.map((r) => r.value));
  if (!all.some((v) => v)) return none(w, h);
  const hiRaw = Math.max(...all, 0), loRaw = Math.min(...all, 0);
  const hi = niceMax(hiRaw), lo = loRaw < 0 ? -niceMax(-loRaw) : 0;
  const f = frame(w, h, lo, hi);
  const n = labels.length, x = (i) => f.pad.l + (n === 1 ? f.iw / 2 : (f.iw * i) / (n - 1));
  let out = f.grid;
  for (const r of refs) out += `<line x1="${f.pad.l}" x2="${w - f.pad.r}" y1="${f.y(r.value)}" y2="${f.y(r.value)}" stroke="${r.color}" stroke-dasharray="5 4" stroke-width="1.5"/><text x="${w - f.pad.r - 2}" y="${f.y(r.value) - 5}" fill="${r.color}" font-size="10.5" text-anchor="end">${esc(r.label)}</text>`;
  for (const s of series) {
    const pts = s.values.map((v, i) => [x(i), f.y(v)]);
    if (s.area) out += `<polygon fill="${s.color}" opacity=".16" points="${x(0)},${f.y(0)} ${pts.map((p) => p.join(',')).join(' ')} ${x(n - 1)},${f.y(0)}"/>`;
    out += `<polyline fill="none" stroke="${s.color}" stroke-width="2.5" stroke-linejoin="round" points="${pts.map((p) => p.join(',')).join(' ')}"/>`;
    if (n <= 40) out += pts.map((p, i) => `<circle data-tip="${esc(labels[i])} · ${esc(s.name)} ${esc(fmt(s.values[i]))}" cx="${p[0]}" cy="${p[1]}" r="${n > 20 ? 2.5 : 4}" fill="${s.color}"/>`).join('');
  }
  out += labels.map((l, i) => (i % every ? '' : `<text x="${x(i)}" y="${h - 8}" fill="${COLORS.txt}" font-size="10.5" text-anchor="middle">${esc(l)}</text>`)).join('');
  return svg(w, h, out, 'Linijski grafikon');
}

// Krofna sa legendom
export function donut({ w, h, items }) {
  const total = items.reduce((s, i) => s + i.value, 0);
  if (!total) return none(w, h, 'Nema troškova u ovom mesecu');
  const wide = w >= h * 1.25;
  const legendH = wide ? 0 : Math.min(items.length, 7) * 19 + 4;
  const size = wide ? Math.min(h - 16, w * 0.5) : Math.max(80, Math.min(w - 20, h - legendH - 12));
  const cx = wide ? size / 2 + 12 : w / 2, cy = (wide ? h : h - legendH) / 2, R = size / 2, r = R * 0.62;
  let a0 = -Math.PI / 2, out = '';
  items.forEach((it, i) => {
    const frac = it.value / total, a1 = a0 + frac * 2 * Math.PI, large = frac > 0.5 ? 1 : 0, col = PALETTE[i % PALETTE.length];
    if (frac >= 0.9999) out += `<circle data-tip="${esc(it.label)} · ${esc(fmt(it.value))} (100%)" cx="${cx}" cy="${cy}" r="${(R + r) / 2}" fill="none" stroke="${col}" stroke-width="${R - r}"/>`;
    else {
      const p = (a, rad) => `${cx + rad * Math.cos(a)},${cy + rad * Math.sin(a)}`;
      out += `<path data-tip="${esc(it.label)} · ${esc(fmt(it.value))} (${Math.round(frac * 100)}%)" d="M${p(a0, R)} A${R},${R} 0 ${large} 1 ${p(a1, R)} L${p(a1, r)} A${r},${r} 0 ${large} 0 ${p(a0, r)} Z" fill="${col}" stroke="#111b25" stroke-width="2"/>`;
    }
    a0 = a1;
  });
  out += `<text x="${cx}" y="${cy - 2}" fill="${COLORS.txt}" font-size="11" text-anchor="middle">Ukupno</text><text x="${cx}" y="${cy + 16}" fill="${COLORS.ink}" font-size="${size > 150 ? 17 : 14}" font-weight="700" text-anchor="middle">${short(total)}</text>`;
  const lx = wide ? size + 34 : 14, ly = wide ? Math.max(14, (h - items.length * 24) / 2) : h - legendH + 8, step = wide ? 24 : 19;
  items.forEach((it, i) => {
    const y = ly + i * step;
    out += `<rect x="${lx}" y="${y}" width="10" height="10" rx="3" fill="${PALETTE[i % PALETTE.length]}"/><text x="${lx + 16}" y="${y + 9}" fill="${COLORS.ink}" font-size="12">${esc(it.label)}</text><text x="${w - 12}" y="${y + 9}" fill="${COLORS.txt}" font-size="12" text-anchor="end">${Math.round((it.value / total) * 100)}% · ${short(it.value)}</text>`;
  });
  return svg(w, h, out, 'Raspodela troškova po kategorijama');
}

// Horizontalni stubići; opciono sa limitom (potrošeno / limit)
export function hbars({ w, h, items }) {
  if (!items.length) return none(w, h, 'Nema podataka');
  const labW = Math.min(110, w * 0.3), valW = 86, top = 6, rowH = Math.min(38, (h - top - 6) / items.length);
  const max = Math.max(...items.map((i) => Math.max(i.value, i.limit || 0)), 1);
  const bw = w - labW - valW - 12;
  let out = '';
  items.forEach((it, i) => {
    const y = top + i * rowH, bh = Math.min(16, rowH * 0.5), by = y + (rowH - bh) / 2;
    const over = it.limit && it.value > it.limit, col = it.value < 0 ? COLORS.exp : over ? COLORS.exp : it.limit && it.value / it.limit >= 0.8 ? COLORS.amber : COLORS.inc;
    out += `<text x="${labW - 8}" y="${by + bh - 3}" fill="${COLORS.ink}" font-size="12" text-anchor="end">${esc(it.label.length > 14 ? it.label.slice(0, 13) + '…' : it.label)}</text>`;
    out += `<rect x="${labW}" y="${by}" width="${bw}" height="${bh}" rx="4" fill="#1d2b38"/>`;
    out += `<rect data-tip="${esc(it.label)} · ${esc(fmt(it.value))}${it.limit ? ' od ' + esc(fmt(it.limit)) : ''}" x="${labW}" y="${by}" width="${Math.max(2, (Math.abs(it.value) / max) * bw)}" height="${bh}" rx="4" fill="${col}"/>`;
    if (it.limit) out += `<line x1="${labW + (it.limit / max) * bw}" x2="${labW + (it.limit / max) * bw}" y1="${by - 3}" y2="${by + bh + 3}" stroke="${COLORS.ink}" stroke-width="2"/>`;
    out += `<text x="${w - 6}" y="${by + bh - 3}" fill="${over ? COLORS.exp : COLORS.txt}" font-size="12" text-anchor="end">${short(it.value)}${it.limit ? ' / ' + short(it.limit) : ''}</text>`;
  });
  return svg(w, h, out, 'Stubići po stavkama');
}
