# Finance Hub 27 — offline PWA

Lične finansije koje rade **potpuno offline**. Nema servera, naloga ni mreže: svi podaci se čuvaju u memoriji telefona (IndexedDB u pregledaču) i nikad ne napuštaju uređaj.

## Pokretanje
Aplikacija je statična (HTML/CSS/ES moduli, bez build koraka). Service worker i instalacija na telefon zahtevaju `https://` ili `localhost`.

Lokalno (Python 3.12):
```
python3.12 -m http.server 8080
# otvori http://localhost:8080
```
Na telefonu: postavi fascikla na bilo koji besplatni statički hosting (GitHub Pages, Netlify, Cloudflare Pages) samo jednom. Otvori adresu, pa „Dodaj na početni ekran". Posle prvog učitavanja radi bez interneta.

## Struktura
- `index.html`, `manifest.webmanifest`, `sw.js` — ljuska, PWA, keš svih fajlova (povećaj `VERSION` u `sw.js` pri svakoj izmeni)
- `js/db.js` — IndexedDB (rezervno localStorage), zahtev za trajno skladište, informacije o prostoru
- `js/store.js` — stanje, profili, svi upisi (`commit` upisuje pa tek onda javlja uspeh), dnevne interne kopije (14 dana)
- `js/calc.js` — čisti proračuni (saldo, računi, trend, prognoza)
- `js/migrate.js` — normalizacija podataka i uvoz iz stare „Finance Hub Dark" V11–V26
- `js/views/*` — ekrani: Pregled, Transakcije, Dodaj, Planovi, Više
- `tests/e2e.test.js` — Playwright test (unos, trajnost, offline, backup/restore, uvoz)

## Dashboard (v27.1)
Dugme „Dashboard" u zaglavlju: 6 SVG grafikona (prihodi/troškovi, kategorije, saldo, potrošnja kroz mesec vs budžet, limiti, računi), period 3/6/12 meseci. Dodir na grafikon otvara prikaz preko celog ekrana (Fullscreen API + zaključavanje vodoravnog položaja gde je podržano; na iOS-u pokriva ceo prozor). Okretanje telefona vodoravno dok si na Dashboardu automatski otvara prikaz (prelistavanje prstom), a povratak u uspravan položaj ga zatvara. Manifest ima `orientation: any` da bi rotacija radila u instaliranoj aplikaciji.

## Šta je novo u odnosu na V26
- IndexedDB umesto localStorage + traženje trajnog skladišta (manji rizik da pregledač obriše podatke)
- Svaka transakcija pamti kurs iz trenutka unosa; promena kursa ne menja istoriju (opciono primeni na sve)
- Nema `prompt()`/`confirm()` — svi unosi su dijalozi prilagođeni telefonu
- Prenos između računa je jedna stavka u valuti računa (EUR↔RSD konverzija)
- Ekrani sa donjom navigacijom, kategorije posebno za prihode i troškove
- Automatske dnevne interne kopije + JSON izvoz/uvoz + CSV; podsetnik kad kopija nije pravljena
- Pouzdan offline: ceo kod keširan pri instalaciji, ponuda za osvežavanje kad izađe nova verzija

## Prelazak sa stare aplikacije
1. U staroj aplikaciji: „Preuzmi kompletnu kopiju" (JSON).
2. U novoj: Više → „Vrati iz kopije". Stari format (V16–V26) se prepoznaje, uključujući stare prenose.
(Ako se nova aplikacija otvori sa iste adrese kao stara, podaci iz localStorage-a se uvoze sami.)

## Važno
Podaci su vezani za jedan pregledač na jednom uređaju. Brisanje podataka sajta ili deinstalacija ih briše — povremeno sačuvaj JSON kopiju (Više → Preuzmi/Podeli).
