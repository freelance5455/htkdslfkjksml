Waseer Agricultural Farm Android project

This project wraps the offline HTML app in an Android WebView. It includes the app icon and enables JavaScript and DOM storage for the app's functionality.

Build an APK:
1. Install Android Studio on a computer.
2. Open this WaseerAndroid folder as a project.
3. Allow Gradle sync and install any SDK components Android Studio requests.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK under app/build/outputs/apk/debug/app-debug.apk.
6. Transfer that APK to your Android phone and install it. Android may ask you to allow installing apps from that source.

No APK was compiled in this environment because the Android SDK/Gradle build tools are not installed here.
