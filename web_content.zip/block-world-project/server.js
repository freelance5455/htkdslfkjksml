const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.use(express.static(path.join(__dirname, 'public')));
const rooms = new Map();
function getRoom(code) {
  if (!rooms.has(code)) rooms.set(code, { players: {}, blocks: [], dragonHP: 1000 });
  return rooms.get(code);
}
io.on('connection', socket => {
  socket.on('joinRoom', ({ code, name }) => {
    code = String(code || '').trim().toUpperCase().slice(0, 12);
    if (!/^[A-Z0-9]{4,12}$/.test(code)) return socket.emit('roomError', 'Room code must be 4–12 letters or numbers.');
    const room = getRoom(code);
    if (Object.keys(room.players).length >= 2 && !room.players[socket.id]) return socket.emit('roomError', 'This room already has two players.');
    socket.join(code); socket.data.room = code;
    room.players[socket.id] = { id: socket.id, name: String(name || 'Player').slice(0, 16), x: Object.keys(room.players).length ? 4 : 0, y: 2, z: 0, yaw: 0, health: 100 };
    socket.emit('roomJoined', { code, selfId: socket.id, players: Object.values(room.players), blocks: room.blocks, dragonHP: room.dragonHP });
    socket.to(code).emit('playerJoined', room.players[socket.id]);
    io.to(code).emit('playerList', Object.values(room.players));
  });
  socket.on('move', pos => { const code = socket.data.room; if (!code || !rooms.has(code)) return; const room=rooms.get(code); const p=room.players[socket.id]; if(!p) return; for(const k of ['x','y','z','yaw']) if(Number.isFinite(pos?.[k])) p[k]=Math.max(-500,Math.min(500,pos[k])); socket.to(code).emit('playerMoved', p); });
  socket.on('placeBlock', b => { const code=socket.data.room; if(!code||!rooms.has(code)) return; if(!b||!Number.isInteger(b.x)||!Number.isInteger(b.y)||!Number.isInteger(b.z)||!['grass','dirt','stone','wood','brick','obsidian'].includes(b.type)) return; const room=rooms.get(code); if(room.blocks.length>=5000) return; const block={x:b.x,y:b.y,z:b.z,type:b.type}; room.blocks.push(block); io.to(code).emit('blockPlaced',block); });
  socket.on('breakBlock', b => { const code=socket.data.room; if(!code||!rooms.has(code)) return; const room=rooms.get(code); const i=room.blocks.findIndex(q=>q.x===b.x&&q.y===b.y&&q.z===b.z); if(i>=0){room.blocks.splice(i,1);io.to(code).emit('blockBroken',b);} });
  socket.on('dragonHit', damage => { const code=socket.data.room; if(!code||!rooms.has(code)) return; const room=rooms.get(code); room.dragonHP=Math.max(0,room.dragonHP-Math.max(1,Math.min(50,Number(damage)||5))); io.to(code).emit('dragonHP',room.dragonHP); });
  socket.on('disconnect',()=>{const code=socket.data.room;if(!code||!rooms.has(code))return;const room=rooms.get(code);delete room.players[socket.id];io.to(code).emit('playerLeft',socket.id);io.to(code).emit('playerList',Object.values(room.players));if(!Object.keys(room.players).length)rooms.delete(code);});
});
const port = process.env.PORT || 3000;
server.listen(port, '0.0.0.0', () => console.log(`Block World running on http://localhost:${port}`));
