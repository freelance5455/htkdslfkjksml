Rust Mobile 3D — v10 Landscape

1. Extract the ZIP archive.
2. Open index.html in a modern mobile browser with WebGL support and internet access.
3. Tap “ГРАТИ 🎮” to request fullscreen and landscape orientation.
4. If the browser does not support orientation locking, rotate the phone manually and enable auto-rotate.

Note: orientation lock depends on browser/device support. JavaScript syntax checked; not runtime-tested on a physical phone.
