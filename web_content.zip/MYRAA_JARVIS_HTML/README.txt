MYRAA JARVIS HTML APP

Open index.html in a modern browser or upload the ZIP to a compatible HTML-to-APK builder.

Included:
- Login screen
- User-provided Gemini API key after login
- Online Gemini chat with offline fallback
- Voice input/output where browser supports it
- Animated female-style assistant avatar states
- Friend-like proactive/bored mode
- Settings
- Admin dashboard UI prototype
- Mobile responsive premium theme

Important: This is a web/HTML implementation. True Android background services, protected system settings, secure production authentication, and full device controls require native Android permissions/backend integration. Do not treat client-side API-key storage or admin authentication as production security.
