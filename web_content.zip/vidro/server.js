'use strict';
// Vidro: backend proxy para a YouTube Data API v3 + Return YouTube Dislike. Zero dependências (Node >= 18).
if (typeof fetch !== 'function') { console.error('Precisa do Node 18 ou mais novo. Versão atual: ' + process.version); process.exit(1); }
const http = require('http'), fs = require('fs'), path = require('path');

try { // .env simples
  for (const l of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n')) {
    const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
  }
} catch {}

const PORT = +process.env.PORT || 3000;
const KEY = process.env.YT_API_KEY || '';
const REGION = /^[A-Z]{2}$/.test(process.env.REGION || '') ? process.env.REGION : 'BR';
const YT = process.env.YT_BASE || 'https://www.googleapis.com/youtube/v3';
const RYD = process.env.RYD_BASE || 'https://returnyoutubedislikeapi.com';
const PUB = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

const cache = new Map();
async function getJSON(url, ttl = 300000) {
  const hit = cache.get(url);
  if (hit && hit.exp > Date.now()) return hit.v;
  let r;
  try { r = await fetch(url, { signal: AbortSignal.timeout(8000) }); }
  catch (err) { const e = new Error('Servidor sem acesso à internet ou ao YouTube (' + ((err.cause && (err.cause.code || (err.cause.errors && err.cause.errors[0] && err.cause.errors[0].code) || err.cause.message)) || err.message) + ')'); e.status = 502; throw e; }
  const body = await r.json().catch(() => ({}));
  if (!r.ok) {
    const e = new Error(r.status === 403 ? 'Cota diária da API esgotada ou acesso negado' : (body.error && body.error.message) || 'Falha no YouTube (' + r.status + ')');
    e.status = r.status === 403 ? 429 : 502;
    e.reason = body.error && body.error.errors && body.error.errors[0] && body.error.errors[0].reason;
    throw e;
  }
  cache.set(url, { v: body, exp: Date.now() + ttl });
  if (cache.size > 500) cache.delete(cache.keys().next().value);
  return body;
}
function yt(endpoint, params, ttl) {
  if (!KEY) { const e = new Error('YT_API_KEY não configurada. Copie .env.example para .env e preencha.'); e.status = 500; throw e; }
  return getJSON(`${YT}/${endpoint}?` + new URLSearchParams({ ...params, key: KEY }), ttl);
}

const secs = iso => { const m = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(iso || ''); return m ? (+m[1] || 0) * 3600 + (+m[2] || 0) * 60 + (+m[3] || 0) : 0; };
const num = x => (x === undefined ? null : +x);
const shape = v => {
  const s = v.snippet || {}, t = s.thumbnails || {}, st = v.statistics || {};
  return {
    id: v.id, title: s.title, channel: s.channelTitle, channelId: s.channelId, published: s.publishedAt,
    thumb: (t.medium || t.high || t.default || {}).url, live: s.liveBroadcastContent === 'live',
    dur: secs(v.contentDetails && v.contentDetails.duration), views: num(st.viewCount), likes: num(st.likeCount),
    comments: num(st.commentCount), description: s.description || ''
  };
};
const videosById = ids => yt('videos', { part: 'snippet,statistics,contentDetails', id: ids.join(',') });

const FILTERS = {
  all: {}, shorts: { videoDuration: 'short' }, live: { eventType: 'live' }, recent: { order: 'date' }
};

const routes = {
  async trending(q) {
    const d = await yt('videos', { part: 'snippet,statistics,contentDetails', chart: 'mostPopular', regionCode: REGION, maxResults: '24' });
    return { items: (d.items || []).map(shape) };
  },
  async search(q) {
    const text = (q.get('q') || '').trim().slice(0, 120);
    if (!text) return { items: [] };
    const f = FILTERS[q.get('f')] ? q.get('f') : 'all';
    const params = { part: 'snippet', type: 'video', maxResults: '24', regionCode: REGION, q: f === 'shorts' ? text + ' #shorts' : text, ...FILTERS[f] };
    const d = await yt('search', params);
    const ids = (d.items || []).map(i => i.id && i.id.videoId).filter(Boolean);
    if (!ids.length) return { items: [] };
    return { items: ((await videosById(ids)).items || []).map(shape) };
  },
  async video(q, id) {
    const d = await videosById([id]);
    if (!d.items || !d.items[0]) { const e = new Error('Vídeo não encontrado'); e.status = 404; throw e; }
    const dislikes = await getJSON(`${RYD}/votes?videoId=${id}`, 600000).then(r => ({ likes: r.likes, dislikes: r.dislikes })).catch(() => null);
    return { video: shape(d.items[0]), votes: dislikes };
  },
  async comments(q, id) {
    try {
      const d = await yt('commentThreads', { part: 'snippet', videoId: id, maxResults: '30', order: q.get('o') === 'time' ? 'time' : 'relevance', textFormat: 'plainText' });
      return { items: (d.items || []).map(i => { const c = i.snippet.topLevelComment.snippet; return { author: c.authorDisplayName, avatar: c.authorProfileImageUrl, text: c.textDisplay, likes: c.likeCount, published: c.publishedAt, replies: i.snippet.totalReplyCount }; }) };
    } catch (e) {
      if (e.reason === 'commentsDisabled') return { items: [], disabled: true };
      throw e;
    }
  }
};

const hits = new Map(); // limite simples por IP: 120 req/min
setInterval(() => hits.clear(), 60000).unref();
const send = (res, code, body, type = 'application/json; charset=utf-8') => {
  res.writeHead(code, { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
};

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x');
    if (req.method !== 'GET') return send(res, 405, { error: 'Método não permitido' });
    if (u.pathname.startsWith('/api/')) {
      const ip = req.socket.remoteAddress; const n = (hits.get(ip) || 0) + 1; hits.set(ip, n);
      if (n > 120) return send(res, 429, { error: 'Muitas requisições. Aguarde um minuto.' });
      const [, , name, id] = u.pathname.split('/');
      if (!routes[name]) return send(res, 404, { error: 'Rota inexistente' });
      if ((name === 'video' || name === 'comments') && !/^[\w-]{11}$/.test(id || '')) return send(res, 400, { error: 'ID de vídeo inválido' });
      res.setHeader('Cache-Control', 'public, max-age=60');
      return send(res, 200, await routes[name](u.searchParams, id));
    }
    let file = path.normalize(path.join(PUB, u.pathname === '/' ? 'index.html' : decodeURIComponent(u.pathname)));
    if (!file.startsWith(PUB + path.sep)) return send(res, 403, 'Proibido', 'text/plain');
    fs.readFile(file, (err, data) => err ? send(res, 404, 'Não encontrado', 'text/plain') : send(res, 200, data, MIME[path.extname(file)] || 'application/octet-stream'));
  } catch (e) {
    send(res, e.status || 500, { error: e.message });
  }
});
server.listen(PORT, () => console.log(`Vidro rodando em http://localhost:${PORT}` + (KEY ? '' : '  (falta YT_API_KEY)')));
