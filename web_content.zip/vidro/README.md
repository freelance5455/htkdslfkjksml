# Vidro

Cliente web de YouTube com visual de vidro (inspirado no MeeTube) e backend proxy em Node.
Sem dependências: precisa só de Node 18+.

## Rodar
1. Crie uma chave da YouTube Data API v3 no Google Cloud Console.
2. `cp .env.example .env` e preencha `YT_API_KEY`.
3. `node server.js` e abra http://localhost:3000

## O que tem
- Em alta, busca com filtros (Tudo, Shorts, Ao vivo, Recentes), Shorts, página do vídeo com comentários e vídeos relacionados.
- Dislikes via Return YouTube Dislike.
- Backend: esconde a chave, cache em memória (5 min), limite de 120 req/min por IP.

## Limites
- Cota padrão da API: 10.000 unidades/dia; cada busca custa 100 (cerca de 100 buscas/dia).
- O player é o embed oficial (youtube-nocookie), então anúncios do YouTube podem aparecer.
- Uso pessoal. Para publicar, siga os Termos de Serviço dos serviços de API do YouTube.
