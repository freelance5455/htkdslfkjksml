Paşabahçe Maaşım - Android Studio projesi

Bu ZIP, Android uygulamasının kaynak projesidir; derlenmiş APK değildir.
APK oluşturmak için:
1. Android Studio'yu bilgisayara kurun.
2. ZIP'i çıkarın ve Android Studio'da PasabahceMaasim klasörünü açın.
3. Gradle senkronizasyonunun bitmesini bekleyin.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. APK, app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.

Uygulama hesaplamaları internetsiz çalışır. Maaş katsayıları kullanıcı tarafından sağlanan formüllere göre tahminidir.
