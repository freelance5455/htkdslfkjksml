/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : WEB-1-1-2 */
registerLessonDetail(3, 1, "web-1-1-2", {
  title: "Leçon 2 : CSS3 : Cascade, Spécificité, Box Model et Flexbox",
  duration: "45 min (Manuel universitaire complet)",
  objectives: [
    "Comprendre l'algorithme de la Cascade CSS et calculer la spécificité d'un sélecteur.",
    "Maîtriser les 4 couches du Modèle de Boîte (Box Model) et l'intérêt vital de border-box.",
    "Construire des barres de navigation et cartes alignées avec Flexbox et CSS Grid.",
    "Concevoir une interface Mobile-First fluide grâce aux unités relatives (rem, %) et Media Queries."
  ],
  prerequisites: ["Leçon 1 — HTML5 Sémantique."],
  sections: [
    {
      type: "theory",
      title: "1. Que signifie « Feuilles de style en Cascade » (CSS) ?",
      text: "Le terme Cascade désigne la règle qui tranche lorsqu'un même élément HTML est ciblé par plusieurs règles CSS contradictoires (par exemple : une règle dit couleur bleue et une autre dit couleur rouge). Le navigateur applique trois critères par ordre d'importance :\n1) L'origine et !important (à éviter autant que possible).\n2) La Spécificité du sélecteur : plus un sélecteur est précis, plus il gagne.\n3) L'ordre d'apparition : à spécificité égale, la dernière règle écrite tout en bas du fichier CSS l'emporte."
    },
    {
      type: "table",
      title: "2. Barème universitaire de Spécificité CSS",
      headers: ["Sélecteur", "Score (A, B, C)", "Exemple et priorité"],
      rows: [
        ["Style en ligne (HTML)", "Priorité absolue (1,0,0,0)", "<p style='color:red'> (à éviter)"],
        ["Identifiant (#id)", "(1, 0, 0)", "#titre-principal (très spécifique)"],
        ["Classe (.cls), pseudo-classe", "(0, 1, 0)", ".btn-primary, :hover (recommandé)"],
        ["Balise HTML (tag)", "(0, 0, 1)", "p, h2, article (faible priorité)"]
      ]
    },
    {
      type: "definition",
      term: "Le Box Model (Modèle de Boîte) et box-sizing",
      text: "En CSS, chaque balise HTML est dessinée comme un rectangle à 4 couches concentriques :\n• Content : le texte ou l'image au centre.\n• Padding : marge intérieure entre le contenu et la bordure (prend la couleur de fond).\n• Border : la bordure visible autour du padding.\n• Margin : marge extérieure transparente repoussant les autres boîtes voisines.\n\nPar défaut (content-box), width: 100% ne mesure QUE le contenu : ajouter un padding fait déborder la boîte hors de l'écran ! Avec « * { box-sizing: border-box; } », le padding et la bordure restent inclus à l'intérieur de la largeur fixée."
    },
    {
      type: "theory",
      title: "3. Flexbox, CSS Grid et Approche Mobile-First",
      text: "Autrefois, centrer un bloc verticalement était un casse-tête. Aujourd'hui, CSS offre deux moteurs puissants :\n• Flexbox (display: flex) gère une dimension (une ligne OU une colonne). Idéal pour les barres de navigation et boutons : justify-content aligne sur l'axe principal, align-items centre sur l'axe perpendiculaire, et gap gère l'espacement sans bricoler des margins.\n• CSS Grid (display: grid) gère deux dimensions (lignes ET colonnes simultanément), parfait pour les grilles de cartes.\n\nAvec l'approche Mobile-First (comme dans JOSTECH), on écrit d'abord le style simple sur 1 colonne pour smartphone, puis on enrichit pour tablette/PC via « @media (min-width: 768px) { ... } »."
    },
    {
      type: "code",
      lang: "CSS3 — Mise en page Mobile-First complète",
      code: [
        "* { box-sizing: border-box; margin: 0; padding: 0; }",
        "",
        "/* Barre supérieure avec Flexbox */",
        ".topbar {",
        "  display: flex;",
        "  justify-content: space-between; /* Écarte gauche et droite */",
        "  align-items: center;            /* Centre verticalement */",
        "  padding: 12px 16px;",
        "  gap: 12px;",
        "}",
        "",
        "/* Grille Mobile-First : 1 colonne sur téléphone */",
        ".grille { display: grid; grid-template-columns: 1fr; gap: 14px; }",
        "",
        "/* Adaptation tablette et ordinateur */",
        "@media (min-width: 700px) {",
        "  .grille { grid-template-columns: repeat(2, 1fr); }",
        "}"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Pièges fréquents à éviter en CSS3",
      text: "1) Abuser de !important : cela casse la cascade naturelle et rend le design impossible à maintenir.\n2) Utiliser uniquement des pixels fixes (px) pour les textes : préférez l'unité relative rem (1rem = taille racine), qui respecte les réglages d'accessibilité de l'utilisateur.\n3) Fusion des marges (Margin Collapse) : deux marges verticales qui se touchent (margin-bottom: 20px suivi de margin-top: 15px) ne s'additionnent pas (35px), la plus grande gagne (20px) !"
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Duel de spécificité CSS",
      question: "Un paragraphe <p id='intro' class='texte-clair'> reçoit ces trois règles dans cet ordre :\n1) #intro { color: blue; }\n2) .texte-clair { color: silver; }\n3) p { color: white; }\nDe quelle couleur s'affichera le texte et pourquoi ?",
      solution: "En bleu ! Même si « p » est écrit tout en bas, #intro a une spécificité (1,0,0) largement supérieure à .texte-clair (0,1,0) et à p (0,0,1)."
    },
    {
      title: "Exercice 2 — Calcul Box Model",
      question: "Une boîte a width: 200px, padding: 20px (de chaque côté), border: 5px.\nQuelle est sa largeur totale réelle à l'écran en mode content-box (défaut) vs en mode border-box ?",
      solution: "• En content-box : 200 + 20 + 20 + 5 + 5 = 250 px !\n• En border-box : exactement 200 px (le contenu interne se réduit automatiquement à 150 px)."
    },
    {
      title: "Exercice 3 — Centrage parfait avec Flexbox",
      question: "Écrivez les 4 propriétés CSS sur un conteneur .centre de hauteur 100vh pour centrer parfaitement un logo à la fois horizontalement et verticalement.",
      solution: ".centre {\n  height: 100vh;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}"
    }
  ],
  summary: "CSS3 stylise le Web selon la Cascade et la Spécificité. Le trio box-sizing: border-box, Flexbox/Grid et Media Queries Mobile-First garantit des interfaces modernes parfaitement adaptées aux smartphones comme aux ordinateurs.",
  references: [
    "MDN Web Docs — Cascade CSS, Box Model, Flexbox et CSS Grid.",
    "W3C — CSS Box Model & Flexible Box Layout Specifications."
  ]
});