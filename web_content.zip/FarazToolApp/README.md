# Faraz Tool Android App

1. Android Studio (Koala ya naya) me **Open** karke is FarazToolApp folder ko kholo.
2. Gradle sync hone do (internet chahiye).
3. Phone USB se jodo (USB debugging ON) ya emulator chalao, phir **Run**.
4. APK banane ke liye: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Play Store ke liye: Build > Generate Signed Bundle / APK > Android App Bundle.

Tools ka code app/src/main/assets/index.html me hai. Isko badalna ho to wahi file edit karo.
PDF tools ko internet chahiye (pdf-lib CDN se aata hai). Baaki tools offline chalte hain.
