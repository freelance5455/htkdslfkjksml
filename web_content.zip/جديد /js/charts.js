/* الشارت: الرسم، الطبقات، التحليل المرئي، ولوحة الاستراتيجية وتفاصيل العملة */
let chart, ser, volS, zz, cur = {}, dpr = devicePixelRatio || 1;

$('#tfs').innerHTML = Object.keys(TFS).map(k => `<button class="chip" data-t="${k}">${k}</button>`).join('');
$('#tfs').onclick = e => { const t = e.target.dataset.t; if (t) { S.tf = t; loadChart(true); } };

$('#ovs').innerHTML = Object.entries(OVL).map(([k, v]) => `<button class="chip" data-o="${k}">${v}</button>`).join('');
$('#ovs').onclick = e => { const o = e.target.dataset.o; if (o) { S.ovl[o] = S.ovl[o] ? 0 : 1; loadChart(false); } };

function initChart() {
  const box = $('#box');
  chart = LightweightCharts.createChart(box, {
    autoSize: true, rightPriceScale:{ borderVisible:false },
    timeScale:{ timeVisible:true, borderVisible:false, rightOffset:8 }, crosshair:{ mode:0 }
  });
  ser = chart.addCandlestickSeries({ upColor:'#00D6A0', downColor:'#FF5268', borderVisible:false, wickUpColor:'#00D6A0', wickDownColor:'#FF5268' });
  volS = chart.addHistogramSeries({ priceFormat:{ type:'volume' }, priceScaleId:'' });
  volS.priceScale().applyOptions({ scaleMargins:{ top:.82, bottom:0 } });
  zz = chart.addLineSeries({ color:'#3987FF', lineWidth:2, lastValueVisible:false, priceLineVisible:false });
  chart.timeScale().subscribeVisibleLogicalRangeChange(draw);
  new ResizeObserver(() => requestAnimationFrame(draw)).observe(box);
  applyTheme();
}
function openChart() { if (!chart) initChart(); loadChart(true); }

function markers() {
  const c = cur.c, A = cur.an;
  if (!c || !A) return;
  const m = [];
  if (S.ovl.bos) (A.ev || []).forEach(e => m.push({
    time:c[e.j].time, position:e.up ? 'belowBar' : 'aboveBar',
    color:e.up ? '#00D6A0' : '#FF5268', shape:e.up ? 'arrowUp' : 'arrowDown', text:e.k
  }));
  if (S.ovl.sig) HIST.list.forEach(s => {
    if (s.i < 0 || s.i >= c.length) return;
    const b = s.side === 'BUY';
    m.push({
      time:c[s.i].time, position:b ? 'belowBar' : 'aboveBar',
      color:b ? '#3987FF' : '#F5B83D', shape:b ? 'arrowUp' : 'arrowDown',
      text:(b ? 'BUY ' : 'SELL ') + s.score + ({ tp:' ✓', sl:' ✗' }[s.result] || '')
    });
  });
  m.sort((a, b) => a.time - b.time);
  ser.setMarkers(m);
}

function loadChart(fit) {
  const c = Data.klines(S.sym, S.tf);
  cur.c = c; cur.an = analyze(c);
  const A = cur.an;

  document.querySelectorAll('#tfs .chip').forEach(b => b.classList.toggle('on', b.dataset.t === S.tf));
  document.querySelectorAll('#ovs .chip').forEach(b => b.classList.toggle('on', !!S.ovl[b.dataset.o]));

  ser.setData(c);
  volS.setData(c.map(x => ({ time:x.time, value:x.vol, color:x.close >= x.open ? 'rgba(0,214,160,.35)' : 'rgba(255,82,104,.35)' })));
  zz.setData(S.ovl.zz ? A.z.map(q => ({ time:c[q.i].time, value:q.p })) : []);
  if (fit) chart.timeScale().setVisibleLogicalRange({ from:c.length - 110, to:c.length + 8 });

  ensureHist();
  markers();

  cur.sg = buildSignal(S.sym, analyze(Data.klines(S.sym, '4H')), analyze(Data.klines(S.sym, '1H')), A);
  const T = Data.t(S.sym); if (T) T.sig = cur.sg;

  head(); strat(cur.sg); details(cur.sg); draw();
}

function head() {
  const T = Data.t(S.sym); if (!T) return;
  $('#cs').textContent = S.sym;
  $('#cp').textContent = fmt(T.price);
  $('#cc').textContent = (T.chg >= 0 ? '+' : '') + T.chg.toFixed(2) + '%';
  $('#cc').className = 'num ' + (T.chg >= 0 ? 'up' : 'down');
  details(cur.sg);
}

let lastDet = 0;
function details(sg) {
  const el = $('#det'); if (!el) return;
  if (Date.now() - lastDet < 1500) return;
  lastDet = Date.now();
  const A = cur.an;
  if (!A || !A.z) { el.innerHTML = ''; return; }
  const p = A.price, s = sg || cur.sg;
  const tr = k => `<span class="${TRD[k][1]}">${TRD[k][2]} ${TRD[k][0]}</span>`;
  const near = arr => arr && arr.length
    ? arr.reduce((a, b) => Math.abs((b.top + b.bot) / 2 - p) < Math.abs((a.top + a.bot) / 2 - p) ? b : a)
    : null;
  const ob = near((A.ob || []).filter(z => p >= z.bot && p <= z.top * 1.02));
  const fg = near((A.fvg || []).filter(z => p >= z.bot && p <= z.top * 1.02));
  const sup = (A.sr || []).filter(x => x.t === 'L' && x.p < p).sort((a, b) => b.p - a.p)[0];
  const res = (A.sr || []).filter(x => x.t === 'H' && x.p > p).sort((a, b) => a.p - b.p)[0];
  const fib = A.fib;

  el.innerHTML = `<h3>تفاصيل العملة — <span dir="ltr">${S.sym}</span></h3><div class="det">
    <div>
      <div class="kv"><span>السعر المباشر</span><b class="num">${fmt(p)}</b></div>
      <div class="kv"><span>اتجاه 4H</span>${tr(s ? s.t4 : 'side')}</div>
      <div class="kv"><span>اتجاه 1H</span>${tr(s ? s.t1 : 'side')}</div>
      <div class="kv"><span>اتجاه 15M</span>${tr(A.trend)}</div>
    </div>
    <div>
      <div class="kv"><span>آخر قمة</span><span class="num">${A.lastH ? fmt(A.lastH.p) : '—'}</span></div>
      <div class="kv"><span>آخر قاع</span><span class="num">${A.lastL ? fmt(A.lastL.p) : '—'}</span></div>
      <div class="kv"><span>دعم</span><span class="num up">${sup ? fmt(sup.p) : '—'}</span></div>
      <div class="kv"><span>مقاومة</span><span class="num down">${res ? fmt(res.p) : '—'}</span></div>
    </div>
    <div>
      <div class="kv"><span>فيبوناتشي 0%</span><span class="num">${fib ? fmt(fibPrice(fib, 0)) : '—'}</span></div>
      <div class="kv"><span>فيبوناتشي 50%</span><span class="num">${fib ? fmt(fibPrice(fib, .5)) : '—'}</span></div>
      <div class="kv"><span>فيبوناتشي 61.8%</span><span class="num">${fib ? fmt(fibPrice(fib, .618)) : '—'}</span></div>
      <div class="kv"><span>فيبوناتشي 100%</span><span class="num">${fib ? fmt(fibPrice(fib, 1)) : '—'}</span></div>
    </div>
    <div>
      <div class="kv"><span>أقرب Order Block</span><span class="num">${ob ? (ob.s === 'bull' ? 'Bullish ' : 'Bearish ') + fmt(ob.bot) + '–' + fmt(ob.top) : '—'}</span></div>
      <div class="kv"><span>أقرب FVG</span><span class="num">${fg ? (fg.s === 'bull' ? 'Bullish ' : 'Bearish ') + fmt(fg.bot) + '–' + fmt(fg.top) : '—'}</span></div>
      <div class="kv"><span>قوة الإشارة</span><b>${s ? s.score : 0}/100</b></div>
      <div class="kv"><span>آخر إشارة</span>${s && s.entry
        ? `<span class="num">${s.side === 'BUY' ? 'شراء' : 'بيع'} @ ${fmt(s.entry)}</span>`
        : '<span style="color:var(--tx2)">—</span>'}</div>
    </div>
  </div>`;
}

function strat(sg) {
  const s = sg || cur.sg;
  const el = $('#strat');
  if (!s) {
    el.innerHTML = '<h3>FIBONACCI SMC SCALPING</h3><p style="color:var(--tx2)">لا يتوفر تحليل لهذه العملة بعد.</p>';
    return;
  }
  const st = STAT[s.status] || STAT.none;
  const tr = k => `<span class="${TRD[k][1]}">${TRD[k][2]} ${TRD[k][0]}</span>`;
  const col = s.score >= S.minScore ? 'var(--up)' : 'var(--blue)';
  el.innerHTML = `<h3>FIBONACCI SMC SCALPING</h3>
  <div class="kv"><span>اتجاه 4H</span>${tr(s.t4)}</div>
  <div class="kv"><span>تأكيد 1H</span>${tr(s.t1)}</div>
  <div class="kv"><span>إطار الدخول 15M</span>${tr(s.t15)}</div>
  <div class="kv"><span>الحالة</span><span class="tag ${st[1]}">${st[0]}${s.side ? ' · ' + (s.side === 'BUY' ? 'شراء' : 'بيع') : ''}</span></div>
  <div class="sc"><b>${s.score || 0}</b><span class="tr"><i style="width:${s.score || 0}%;background:${col}"></i></span><small style="color:var(--tx2)">/100</small></div>
  ${s.entry ? `<div class="kv"><span>الدخول</span><span class="num">${fmt(s.entry)}</span></div>
  <div class="kv"><span>وقف الخسارة</span><span class="num down">${fmt(s.sl)}</span></div>
  <div class="kv"><span>الهدف (1:${s.rr || S.rr})</span><span class="num up">${fmt(s.tp)}</span></div>` : ''}
  <ul class="r" style="margin-top:10px">${s.reasons.length ? s.reasons.map(r => '<li>✓ ' + r + '</li>').join('')
    : `<li>${s.side ? 'لم يصل السعر إلى منطقة دخول بعد.' : 'اتجاها 4H و1H غير متوافقين، فلا تصدر صفقة.'}</li>`}</ul>
  ${s.status === 'signal' ? '<button class="btn" style="width:100%;margin-top:10px" id="tk">تسجيل الصفقة</button>' : ''}`;
  const b = $('#tk');
  if (b) b.onclick = () => { take({ sym:s.sym || S.sym, side:s.side, entry:s.entry, sl:s.sl, tp:s.tp, tf:s.tf || S.tf, score:s.score }); go('log'); };
}

$('#rng').onchange = e => {
  const c = cur.c; if (!c) return;
  const v = e.target.value;
  chart.timeScale().setVisibleLogicalRange({ from:v === 'all' ? 0 : c.length - +v, to:c.length + 8 });
};
$('#dg').onclick = () => {
  const a = $('#d1').value, b = $('#d2').value;
  if (!a || !b || !cur.c) return;
  const c = cur.c, f = new Date(a) / 1e3, t = new Date(b) / 1e3 + 86399;
  if (f >= t || t < c[0].time || f > c[c.length - 1].time) {
    alert('الفترة خارج البيانات المتاحة لهذا الإطار الزمني. اختر تاريخاً أحدث أو إطاراً أكبر.');
    return;
  }
  chart.timeScale().setVisibleRange({ from:Math.max(f, c[0].time), to:Math.min(t, c[c.length - 1].time) });
};

function draw() {
  const cv = $('#cv'), box = $('#box');
  if (!box || !cur.an || !chart) return;
  const w = box.clientWidth, h = box.clientHeight;
  cv.width = w * dpr; cv.height = h * dpr;
  const x = cv.getContext('2d');
  x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, h);
  x.font = '10px Tajawal,sans-serif';

  const A = cur.an, c = cur.c, ts = chart.timeScale();
  const X = i => ts.timeToCoordinate(c[Math.max(0, Math.min(i, c.length - 1))].time);
  const Y = p => ser.priceToCoordinate(p);
  const G = '#00D6A0', R = '#FF5268', B = '#3987FF', Y2 = '#F5B83D';

  const zone = (i, top, bot, col, lab) => {
    const a = X(i), y1 = Y(top), y2 = Y(bot);
    if (a == null || y1 == null || y2 == null) return;
    const x0 = Math.max(a, 0);
    x.fillStyle = col + '2E'; x.fillRect(x0, Math.min(y1, y2), w - x0, Math.max(1, Math.abs(y2 - y1)));
    x.strokeStyle = col + '99'; x.strokeRect(x0, Math.min(y1, y2), w - x0, Math.max(1, Math.abs(y2 - y1)));
    x.fillStyle = col; x.fillText(lab, x0 + 4, Math.min(y1, y2) + 10);
  };
  const line = (i0, i1, p, col, lab, dash) => {
    const a = i0 == null ? 0 : X(i0), b = i1 == null ? w : X(i1), y = Y(p);
    if (a == null || b == null || y == null) return;
    x.strokeStyle = col; x.setLineDash(dash ? [5, 4] : []);
    x.beginPath(); x.moveTo(Math.max(a, 0), y); x.lineTo(Math.min(b, w), y); x.stroke(); x.setLineDash([]);
    if (lab) { x.fillStyle = col; x.fillText(lab, Math.max(a, 0) + 4, y - 3); }
  };

  if (S.ovl.sd) (A.sd || []).forEach(z => zone(z.i, z.top, z.bot, z.s === 'bull' ? G : R, z.s === 'bull' ? 'Demand' : 'Supply'));
  if (S.ovl.ob) (A.ob || []).forEach(z => zone(z.i, z.top, z.bot, z.s === 'bull' ? G : R, z.s === 'bull' ? 'Bullish OB' : 'Bearish OB'));
  if (S.ovl.fvg) (A.fvg || []).forEach(z => zone(z.i, z.top, z.bot, z.s === 'bull' ? B : Y2, 'FVG'));
  if (S.ovl.fib && A.fib) A.fib.lv.forEach(l => line(A.fib.i0, null, l.p, [.5, .618].includes(l.v) ? Y2 : '#94A3B8', (l.v * 100).toFixed(1) + '%  ' + fmt(l.p), l.v !== .5 && l.v !== .618));
  if (S.ovl.sr) (A.sr || []).forEach(s => line(s.i, null, s.p, s.t === 'H' ? R : G, s.t === 'H' ? 'Resistance' : 'Support', true));
  if (S.ovl.bos) (A.ev || []).forEach(e => line(e.i, e.j, e.p, e.up ? G : R, e.k, false));

  /* الإشارات التاريخية: الدخول / الوقف / الهدف */
  if (S.ovl.sig) HIST.list.slice(-6).forEach(s => {
    const a = X(s.i), b = X(s.j == null ? c.length - 1 : s.j);
    if (a == null || b == null) return;
    const xe = Math.max(a, 0), xe2 = Math.min(Math.max(b, a), w);
    const seg = (p, col, lab) => {
      const y = Y(p); if (y == null) return;
      x.strokeStyle = col; x.setLineDash([3, 3]);
      x.beginPath(); x.moveTo(xe, y); x.lineTo(xe2, y); x.stroke(); x.setLineDash([]);
      if (lab) { x.fillStyle = col; x.fillText(lab, xe + 3, y - 2); }
    };
    seg(s.entry, '#3987FF', (s.side === 'BUY' ? 'BUY ' : 'SELL ') + s.score);
    seg(s.sl, R, 'SL');
    seg(s.tp, G, 'TP');
  });
}