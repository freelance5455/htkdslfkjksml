import * as THREE from 'three';

// Ship stats: speed (u/s base), handling (lateral u/s), solar (drain multiplier, lower = better)
export const SHIPS = [
  {
    id: 'nova', name: 'NOVA DART', tag: 'Balanced solar interceptor', cost: 0,
    speed: 80, handling: 34, solar: 1.0, jumps: 2, jumpPower: 19, dashCd: 1.4,
    hull: 0xeef1f5, dark: 0x2a2f3a, accent: 0xff7a1a, glow: 0xffa040,
    perk: 'Starts with 2 jump charges. Reliable all-rounder.',
  },
  {
    id: 'spectre', name: 'SPECTRE', tag: 'Stealth flying wing', cost: 0,
    speed: 84, handling: 44, solar: 1.08, jumps: 1, jumpPower: 19, dashCd: 0.6,
    hull: 0x1a1d26, dark: 0x0b0d12, accent: 0x34f5ff, glow: 0x5cf8ff,
    perk: 'Phase-dash recharges in 0.6s. Razor handling.',
  },
  {
    id: 'helios', name: 'HELIOS ARRAY', tag: 'Solar collector cruiser', cost: 450,
    speed: 78, handling: 32, solar: 0.68, jumps: 1, jumpPower: 19, dashCd: 1.4, sunBonus: 1.5,
    hull: 0xf4efe4, dark: 0x6b5a3a, accent: 0xffc23a, glow: 0xffd56a,
    perk: 'Solar drain -32%. Sun cells restore 50% more.',
  },
  {
    id: 'vortex', name: 'VORTEX TWIN', tag: 'Twin-hull heavy jumper', cost: 800,
    speed: 88, handling: 36, solar: 1.0, jumps: 4, jumpPower: 23, dashCd: 1.2,
    hull: 0x2b0f14, dark: 0x120608, accent: 0xff3344, glow: 0xff5a4a,
    perk: 'Launches with 4 jumps. Jumps fly 20% higher.',
  },
  {
    id: 'phantom', name: 'PHANTOM X', tag: 'Forward-swept phase fighter', cost: 1300,
    speed: 94, handling: 42, solar: 1.02, jumps: 2, jumpPower: 20, dashCd: 1.0, phaseStart: 6, phaseMult: 1.6,
    hull: 0x21142e, dark: 0x0e0816, accent: 0xc06bff, glow: 0xd890ff,
    perk: 'Launches phased for 6s. Phase cores last 60% longer.',
  },
  {
    id: 'omega', name: 'OMEGA ZERO', tag: 'Experimental singularity drive', cost: 2200,
    speed: 104, handling: 48, solar: 0.85, jumps: 3, jumpPower: 21, dashCd: 0.8, magnetBase: 7, overMult: 1.6,
    hull: 0xf2f6f8, dark: 0x101418, accent: 0x5bff9a, glow: 0x8affb8,
    perk: 'Permanent flux magnet. Overdrive lasts 60% longer.',
  },
  {
    id: 'titan', name: 'TITAN AEGIS', tag: 'Armoured fortress gunship', cost: 4000,
    speed: 90, handling: 38, solar: 0.9, jumps: 3, jumpPower: 21, dashCd: 1.1, shieldStart: 20, shieldHits: 2,
    hull: 0x8a96a8, dark: 0x1c222c, accent: 0x4db8ff, glow: 0x7fd0ff,
    perk: 'Launches with a 20s shield. Every shield absorbs 2 hits.',
  },
  {
    id: 'seraph', name: 'SERAPH', tag: 'Six-winged celestial glider', cost: 6500,
    speed: 98, handling: 50, solar: 0.55, jumps: 3, jumpPower: 22, dashCd: 0.7, nearBonus: 3, sunBonus: 1.4,
    hull: 0xfff6e8, dark: 0xb89a5a, accent: 0xffd56a, glow: 0xfff0b0,
    perk: 'Solar drain -45%. Near misses restore 3x energy. Halo of light wings.',
  },
  {
    id: 'leviathan', name: 'LEVIATHAN', tag: 'Living manta-ray dreadnought', cost: 9500,
    speed: 102, handling: 46, solar: 0.75, jumps: 4, jumpPower: 22, dashCd: 0.8, freeNova: 1, magnetBase: 4,
    hull: 0x123a4a, dark: 0x061820, accent: 0x2affd5, glow: 0x7affea,
    perk: 'Starts every run with a free Solar Nova. Wings that breathe.',
  },
  {
    id: 'eclipse', name: 'ECLIPSE', tag: 'Black-hole singularity core', cost: 15000,
    speed: 110, handling: 54, solar: 0.7, jumps: 5, jumpPower: 22, dashCd: 0.6, shadowImmune: true, magnetBase: 9, overMult: 1.8,
    hull: 0x0c0c12, dark: 0x050507, accent: 0xff6a2a, glow: 0xffa060,
    perk: 'Immune to shadow drain. Wide permanent magnet. Overdrive lasts 80% longer.',
  },
  {
    id: 'astra', name: 'ASTRA PRIME', tag: 'Crystalline god-machine', cost: 25000,
    speed: 116, handling: 58, solar: 0.6, jumps: 6, jumpPower: 23, dashCd: 0.5, dashSmash: true, shadowImmune: true, magnetBase: 10, freeRebirth: 1, phaseMult: 2,
    hull: 0xe8f4ff, dark: 0x3a2a6a, accent: 0xff4fd8, glow: 0xffa0f0,
    perk: 'Dashes smash buildings. Shadow-immune. One free Phoenix Rebirth per run.',
  },
];

function mirror(half) {
  // half: from nose (x=0) to tail centre (x=0), x >= 0
  const back = half.slice(1, -1).reverse().map(([x, y]) => [-x, y]);
  return [...half, ...back];
}

function planform(pts, thick, mat, bevel = 0.05) {
  const s = new THREE.Shape();
  s.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) s.lineTo(pts[i][0], pts[i][1]);
  s.closePath();
  const g = new THREE.ExtrudeGeometry(s, {
    depth: thick, bevelEnabled: true, bevelThickness: thick * 0.35, bevelSize: bevel, bevelSegments: 1, curveSegments: 4,
  });
  g.rotateX(Math.PI / 2);
  g.translate(0, thick / 2, 0);
  g.computeVertexNormals();
  const m = new THREE.Mesh(g, mat);
  m.castShadow = true;
  return m;
}

function fuselage(profile, mat, sx = 1, sy = 0.65) {
  // profile: [[radius, z], ...] nose -> tail
  const pts = profile.map(([r, z]) => new THREE.Vector2(Math.max(r, 0.001), z));
  const g = new THREE.LatheGeometry(pts, 14);
  g.rotateX(Math.PI / 2);
  // after rotateX(+90): lathe y -> -z ... flip so nose is -z
  g.scale(sx, sy, 1);
  g.computeVertexNormals();
  const m = new THREE.Mesh(g, mat);
  m.castShadow = true;
  return m;
}

function engine(group, mats, x, y, z, r, len) {
  const cg = new THREE.CylinderGeometry(r * 0.85, r, len, 14, 1, true);
  cg.rotateX(Math.PI / 2);
  const shell = new THREE.Mesh(cg, mats.dark);
  shell.position.set(x, y, z);
  shell.castShadow = true;
  group.add(shell);
  const cap = new THREE.Mesh(new THREE.CircleGeometry(r * 0.78, 16), mats.glow);
  cap.position.set(x, y, z + len / 2 - 0.02);
  group.add(cap);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(r * 0.92, r * 0.1, 6, 18), mats.accent);
  ring.position.set(x, y, z + len / 2);
  group.add(ring);
  const fg = new THREE.ConeGeometry(r * 0.7, 2.6, 12, 1, true);
  fg.rotateX(Math.PI / 2);
  fg.translate(0, 0, 1.3);
  const flame = new THREE.Mesh(fg, mats.flame);
  flame.position.set(x, y, z + len / 2);
  group.add(flame);
  const core = new THREE.Mesh(fg.clone().scale(0.45, 0.45, 0.6), mats.flameCore);
  core.position.copy(flame.position);
  group.add(core);
  group.userData.flames.push(flame, core);
  group.userData.engines.push(new THREE.Vector3(x, y, z + len / 2 + 0.2));
}

function light(group, mats, x, y, z, s = 0.09) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(s, 8, 6), mats.accentHot);
  m.position.set(x, y, z);
  group.add(m);
}

function strip(group, mat, x, y, z, w, h, d, ry = 0) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  m.rotation.y = ry;
  group.add(m);
  return m;
}

let solarTex = null;
function getSolarTex() {
  if (solarTex) return solarTex;
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const x = c.getContext('2d');
  x.fillStyle = '#000';
  x.fillRect(0, 0, 128, 128);
  x.strokeStyle = '#fff';
  x.lineWidth = 2;
  for (let i = 0; i <= 128; i += 16) {
    x.beginPath(); x.moveTo(i, 0); x.lineTo(i, 128); x.stroke();
    x.beginPath(); x.moveTo(0, i); x.lineTo(128, i); x.stroke();
  }
  solarTex = new THREE.CanvasTexture(c);
  solarTex.colorSpace = THREE.SRGBColorSpace;
  return solarTex;
}

function makeMats(def) {
  const hull = new THREE.MeshStandardMaterial({ color: def.hull, metalness: 0.75, roughness: 0.28, envMapIntensity: 1.2 });
  const dark = new THREE.MeshStandardMaterial({ color: def.dark, metalness: 0.85, roughness: 0.35, envMapIntensity: 1.0 });
  const accent = new THREE.MeshStandardMaterial({ color: def.accent, emissive: def.accent, emissiveIntensity: 1.1, metalness: 0.3, roughness: 0.4 });
  const accentHot = new THREE.MeshBasicMaterial({ color: new THREE.Color(def.glow).multiplyScalar(2.2) });
  const glass = new THREE.MeshStandardMaterial({ color: 0x050a12, emissive: def.accent, emissiveIntensity: 0.25, metalness: 1, roughness: 0.05, envMapIntensity: 2 });
  const glow = new THREE.MeshBasicMaterial({ color: new THREE.Color(def.glow).multiplyScalar(2.2) });
  const flame = new THREE.MeshBasicMaterial({ color: new THREE.Color(def.glow).multiplyScalar(1.4), transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
  const flameCore = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xffffff).multiplyScalar(1.5), transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });
  const solar = new THREE.MeshStandardMaterial({ color: 0x1a1406, emissive: def.glow, emissiveMap: getSolarTex(), emissiveIntensity: 1.8, metalness: 0.9, roughness: 0.2 });
  return { hull, dark, accent, accentHot, glass, glow, flame, flameCore, solar };
}

export function buildShip(def) {
  const g = new THREE.Group();
  g.userData = { engines: [], flames: [], tips: [], spinners: [], wavers: [], mats: null };
  const M = makeMats(def);
  g.userData.mats = M;

  if (def.id === 'nova') {
    g.add(planform(mirror([[0, -3.0], [0.45, -1.6], [2.5, 1.0], [2.6, 1.5], [0.7, 1.2], [0, 1.4]]), 0.12, M.hull));
    g.add(fuselage([[0, -3.6], [0.35, -2.6], [0.55, -1.2], [0.6, 0.4], [0.5, 1.6], [0.35, 1.9]], M.hull));
    const can = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.glass);
    can.scale.set(0.32, 0.26, 0.95); can.position.set(0, 0.32, -1.3); g.add(can);
    // canards
    g.add(planform(mirror([[0, -2.6], [1.0, -1.9], [1.0, -1.7], [0, -1.9]]), 0.06, M.dark));
    // tail fins
    for (const s of [-1, 1]) {
      const f2 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.9, 0.9), M.dark);
      f2.position.set(s * 0.9, 0.45, 1.15); f2.rotation.z = s * -0.35; f2.rotation.x = 0.4; g.add(f2);
      strip(g, M.accent, s * 1.55, 0.08, 0.1, 0.06, 0.05, 2.2, s * -0.85);
      light(g, M, s * 2.55, 0.08, 1.4);
      g.userData.tips.push(new THREE.Vector3(s * 2.55, 0.08, 1.45));
      engine(g, M, s * 0.48, 0.0, 1.3, 0.28, 1.0);
    }
    strip(g, M.accent, 0, 0.42, -0.2, 0.08, 0.04, 2.6);
  }

  if (def.id === 'spectre') {
    g.add(planform(mirror([[0, -2.4], [3.6, 0.9], [3.2, 1.35], [1.9, 0.7], [1.0, 1.4], [0.4, 0.9], [0, 1.2]]), 0.16, M.hull, 0.03));
    const hump = fuselage([[0, -2.0], [0.5, -1.0], [0.75, 0.2], [0.55, 1.0], [0.2, 1.2]], M.dark, 1.2, 0.45);
    hump.position.y = 0.05; g.add(hump);
    const can = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.glass);
    can.scale.set(0.38, 0.18, 0.8); can.position.set(0, 0.28, -0.9); g.add(can);
    for (const s of [-1, 1]) {
      strip(g, M.accent, s * 1.8, 0.11, -0.75, 0.05, 0.04, 4.3, s * -0.93);
      strip(g, M.accent, s * 2.6, 0.11, 1.05, 0.05, 0.04, 1.4, s * 1.1);
      light(g, M, s * 3.55, 0.1, 0.95, 0.07);
      g.userData.tips.push(new THREE.Vector3(s * 3.5, 0.1, 1.1));
      engine(g, M, s * 0.55, 0.1, 0.7, 0.22, 0.8);
    }
  }

  if (def.id === 'helios') {
    g.add(fuselage([[0, -3.4], [0.4, -2.4], [0.62, -0.8], [0.66, 0.8], [0.55, 1.8], [0.38, 2.1]], M.hull, 1, 0.8));
    const can = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.glass);
    can.scale.set(0.34, 0.3, 1.0); can.position.set(0, 0.38, -1.4); g.add(can);
    for (const s of [-1, 1]) {
      const arm = strip(g, M.dark, s * 1.0, 0, 0.2, 1.4, 0.12, 0.5);
      const panel = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.08, 1.8), M.solar);
      panel.position.set(s * 2.6, 0.0, 0.25); panel.rotation.z = s * 0.12; g.add(panel);
      const frame = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.1, 0.1), M.hull);
      frame.position.set(s * 2.6, 0.02, -0.65); frame.rotation.z = s * 0.12; g.add(frame);
      const frame2 = frame.clone(); frame2.position.z = 1.15; g.add(frame2);
      light(g, M, s * 3.65, 0.15, 0.25, 0.1);
      g.userData.tips.push(new THREE.Vector3(s * 3.6, 0.15, 1.2));
      engine(g, M, s * 0.55, -0.15, 1.6, 0.25, 0.9);
      void arm;
    }
    const halo = new THREE.Mesh(new THREE.TorusGeometry(1.15, 0.07, 8, 40), M.accent);
    halo.position.set(0, 0.05, 1.05); g.add(halo);
    g.userData.spinners.push({ obj: halo, axis: 'z', speed: 1.8 });
    const halo2 = new THREE.Mesh(new THREE.TorusGeometry(1.4, 0.03, 6, 40), M.accentHot);
    halo2.position.set(0, 0.05, 1.05); g.add(halo2);
    g.userData.spinners.push({ obj: halo2, axis: 'z', speed: -1.1 });
    engine(g, M, 0, 0.1, 1.95, 0.3, 0.6);
  }

  if (def.id === 'vortex') {
    for (const s of [-1, 1]) {
      const pod = fuselage([[0, -3.4], [0.32, -2.6], [0.5, -1.0], [0.52, 1.0], [0.42, 2.0]], M.hull, 1, 0.8);
      pod.position.x = s * 1.25; g.add(pod);
      strip(g, M.accent, s * 1.25, 0.38, -0.6, 0.1, 0.04, 3.4);
      const fin = new THREE.Mesh(new THREE.BoxGeometry(0.07, 1.1, 1.1), M.dark);
      fin.position.set(s * 1.25, 0.7, 1.3); fin.rotation.x = 0.5; fin.rotation.z = s * -0.2; g.add(fin);
      light(g, M, s * 1.33, 1.2, 1.7, 0.08);
      engine(g, M, s * 1.25, 0.12, 2.05, 0.3, 0.7);
      engine(g, M, s * 1.25, -0.28, 2.0, 0.2, 0.6);
      // outer wing
      g.add(planform([[s * 1.4, -0.4], [s * 3.3, 0.3], [s * 3.3, 0.8], [s * 1.4, 1.2]].map(p => p), 0.08, M.dark));
      light(g, M, s * 3.3, 0.06, 0.55, 0.09);
      g.userData.tips.push(new THREE.Vector3(s * 3.3, 0.06, 0.9));
    }
    // central forward-swept bridge wing
    g.add(planform([[-1.3, -0.4], [1.3, -0.4], [1.3, 0.6], [0, 0.2], [-1.3, 0.6]], 0.1, M.dark));
    const cock = fuselage([[0, -2.6], [0.3, -1.8], [0.42, -0.6], [0.3, 0.4]], M.hull, 1, 0.7);
    cock.position.y = 0.15; g.add(cock);
    const can = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.glass);
    can.scale.set(0.25, 0.2, 0.7); can.position.set(0, 0.42, -1.3); g.add(can);
  }

  if (def.id === 'phantom') {
    g.add(planform(mirror([[0, -3.4], [0.5, -2.2], [0.7, 0.0], [2.9, -1.4], [3.2, -1.0], [1.0, 1.3], [0.4, 1.8], [0, 1.6]]), 0.1, M.hull, 0.04));
    g.add(fuselage([[0, -4.0], [0.3, -3.0], [0.55, -1.4], [0.62, 0.4], [0.45, 1.8]], M.dark, 1, 0.7));
    const can = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.glass);
    can.scale.set(0.3, 0.25, 1.0); can.position.set(0, 0.35, -1.7); g.add(can);
    for (const s of [-1, 1]) {
      strip(g, M.accent, s * 1.85, 0.08, -0.7, 0.06, 0.04, 2.6, s * 0.99);
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.06, 1.0, 0.7), M.accent);
      blade.position.set(s * 3.1, 0.35, -1.15); blade.rotation.x = -0.3; g.add(blade);
      light(g, M, s * 3.1, 0.9, -1.3, 0.08);
      g.userData.tips.push(new THREE.Vector3(s * 3.1, 0.1, -0.9));
      const vf = new THREE.Mesh(new THREE.BoxGeometry(0.06, 1.0, 1.0), M.dark);
      vf.position.set(s * 0.5, 0.55, 1.2); vf.rotation.z = s * -0.5; vf.rotation.x = 0.45; g.add(vf);
    }
    engine(g, M, 0, 0, 1.9, 0.38, 0.8);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.05, 6, 30), M.accentHot);
    ring.position.set(0, 0, 2.55); g.add(ring);
    g.userData.spinners.push({ obj: ring, axis: 'z', speed: 4 });
  }

  if (def.id === 'omega') {
    g.add(planform(mirror([[0, -4.4], [0.6, -2.8], [3.4, 1.2], [3.0, 1.7], [1.6, 1.2], [1.2, 1.9], [0, 1.5]]), 0.14, M.hull, 0.05));
    g.add(fuselage([[0, -4.8], [0.28, -3.8], [0.6, -1.8], [0.75, 0.4], [0.6, 1.8]], M.dark, 1.1, 0.7));
    const can = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.glass);
    can.scale.set(0.32, 0.28, 1.2); can.position.set(0, 0.38, -2.1); g.add(can);
    for (const s of [-1, 1]) {
      strip(g, M.accent, s * 1.95, 0.12, -0.8, 0.06, 0.05, 4.6, s * -0.9);
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.06, 1.5, 1.4), M.dark);
      blade.position.set(s * 1.4, 0.75, 1.0); blade.rotation.x = 0.55; blade.rotation.z = s * -0.15; g.add(blade);
      strip(g, M.accent, s * 1.42, 1.3, 1.35, 0.08, 0.06, 0.9).rotation.x = 0.55;
      light(g, M, s * 3.35, 0.14, 1.3, 0.1);
      g.userData.tips.push(new THREE.Vector3(s * 3.3, 0.12, 1.5));
      engine(g, M, s * 0.9, 0.0, 1.75, 0.3, 0.8);
      // floating shards
      const shard = new THREE.Mesh(new THREE.OctahedronGeometry(0.35, 0), M.accent);
      shard.scale.set(0.5, 0.5, 2.2);
      const pivot = new THREE.Group(); pivot.position.set(s * 3.9, 0.3, 0.4);
      pivot.add(shard); g.add(pivot);
      g.userData.spinners.push({ obj: shard, axis: 'z', speed: s * 3 });
    }
    engine(g, M, 0, 0.12, 2.1, 0.4, 0.8);
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.28, 0), M.accentHot);
    core.position.set(0, 0.62, -0.4); g.add(core);
    g.userData.spinners.push({ obj: core, axis: 'y', speed: 3 });
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.6, 0.05, 6, 48), M.accentHot);
    ring.position.set(0, 0.1, 0.6); ring.rotation.x = Math.PI / 2; g.add(ring);
    g.userData.spinners.push({ obj: ring, axis: 'z', speed: 1.4 });
  }


  if (def.id === 'titan') {
    // heavy armoured body with slab plates and quad engines
    g.add(fuselage([[0, -3.8], [0.5, -3.0], [0.9, -1.4], [1.05, 0.6], [0.95, 1.9], [0.7, 2.3]], M.hull, 1.25, 0.7));
    const can = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.glass);
    can.scale.set(0.42, 0.3, 1.0); can.position.set(0, 0.55, -1.6); g.add(can);
    g.add(planform(mirror([[0, -1.6], [1.2, -1.2], [3.4, 0.6], [3.4, 1.4], [1.2, 1.6], [0, 1.8]]), 0.22, M.dark, 0.06));
    for (const s of [-1, 1]) {
      const plate = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.18, 2.2), M.hull);
      plate.position.set(s * 2.0, 0.22, 0.4); plate.rotation.z = s * 0.08; g.add(plate);
      strip(g, M.accent, s * 2.0, 0.33, 0.4, 1.0, 0.04, 0.08);
      strip(g, M.accent, s * 2.0, 0.33, -0.2, 1.0, 0.04, 0.08);
      const pod = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 2.4), M.dark);
      pod.position.set(s * 3.35, 0.1, 0.6); g.add(pod);
      const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4, 8).rotateX(Math.PI / 2), M.accent);
      barrel.position.set(s * 3.35, 0.1, -1.2); g.add(barrel);
      light(g, M, s * 3.35, 0.1, -1.95, 0.1);
      g.userData.tips.push(new THREE.Vector3(s * 3.4, 0.1, 1.8));
      engine(g, M, s * 0.6, 0.15, 2.3, 0.32, 0.9);
      engine(g, M, s * 1.5, 0.0, 2.0, 0.26, 0.8);
      const fin = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.2, 1.2), M.dark);
      fin.position.set(s * 1.1, 0.8, 1.5); fin.rotation.x = 0.45; fin.rotation.z = s * -0.3; g.add(fin);
    }
    const shieldRing = new THREE.Mesh(new THREE.TorusGeometry(1.0, 0.05, 6, 40), M.accentHot);
    shieldRing.position.set(0, 0.95, 0.3); shieldRing.rotation.x = Math.PI / 2; g.add(shieldRing);
    g.userData.spinners.push({ obj: shieldRing, axis: 'z', speed: 2.5 });
  }

  if (def.id === 'seraph') {
    g.add(fuselage([[0, -3.6], [0.3, -2.8], [0.5, -1.2], [0.55, 0.6], [0.35, 1.8], [0.15, 2.2]], M.hull, 1, 0.75));
    const can = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.glass);
    can.scale.set(0.28, 0.24, 0.9); can.position.set(0, 0.3, -1.5); g.add(can);
    // three pairs of feather-blade wings fanned out
    const wingDefs = [[-0.6, 0.35, 4.2, -0.35], [0.4, 0.15, 3.6, -0.05], [1.3, -0.05, 2.6, 0.3]];
    for (const s of [-1, 1]) {
      wingDefs.forEach(([z, y, span, sweep], wi) => {
        const pivot = new THREE.Group(); pivot.position.set(s * 0.4, y, z);
        const w = planform([[0, -0.25], [span, -0.55 + sweep], [span + 0.2, -0.35 + sweep], [0, 0.35]].map(([x, zz]) => [s * x, zz]), 0.05, wi === 1 ? M.solar : M.hull, 0.02);
        pivot.add(w);
        const edge = new THREE.Mesh(new THREE.BoxGeometry(span, 0.04, 0.05), M.accentHot);
        edge.position.set(s * span / 2, 0.06, -0.35 + sweep / 2); edge.rotation.y = s * -Math.atan2(sweep - 0.3, span); pivot.add(edge);
        g.add(pivot);
        g.userData.wavers.push({ obj: pivot, axis: 'z', amp: 0.08 + wi * 0.03, speed: 2.2, phase: wi * 0.7, base: s * (0.12 - wi * 0.12), sign: s });
        if (wi === 0) g.userData.tips.push(new THREE.Vector3(s * (span + 0.4), y, z - 0.5));
      });
      engine(g, M, s * 0.38, -0.05, 1.9, 0.2, 0.7);
    }
    const halo = new THREE.Mesh(new THREE.TorusGeometry(1.3, 0.06, 8, 48), M.accentHot);
    halo.position.set(0, 1.1, 0.6); halo.rotation.x = Math.PI / 2 - 0.25; g.add(halo);
    g.userData.spinners.push({ obj: halo, axis: 'z', speed: 1.2 });
    const orb = new THREE.Mesh(new THREE.IcosahedronGeometry(0.22, 1), M.glow);
    orb.position.set(0, 1.1, 0.6); g.add(orb);
  }

  if (def.id === 'leviathan') {
    // broad manta body, wings undulate
    const body = fuselage([[0, -3.2], [0.7, -2.4], [1.1, -0.8], [1.0, 1.0], [0.5, 2.6], [0.1, 4.2]], M.hull, 1.4, 0.45);
    g.add(body);
    const can = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.glass);
    can.scale.set(0.5, 0.2, 0.9); can.position.set(0, 0.32, -1.7); g.add(can);
    for (const s of [-1, 1]) {
      const pivot = new THREE.Group(); pivot.position.set(s * 0.9, 0, 0);
      const wing = planform([[0, -2.0], [2.2, -0.6], [4.2, 0.6], [4.0, 1.0], [2.0, 1.2], [0, 1.6]].map(([x, z]) => [s * x, z]), 0.1, M.hull, 0.04);
      pivot.add(wing);
      for (let k = 0; k < 4; k++) {
        const st = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.03, 2.2 - k * 0.3), M.accent);
        st.position.set(s * (0.8 + k * 0.85), 0.1, 0.2 + k * 0.2); st.rotation.y = s * -0.5; pivot.add(st);
      }
      const tip = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), M.accentHot);
      tip.position.set(s * 4.1, 0.05, 0.8); pivot.add(tip);
      g.add(pivot);
      g.userData.wavers.push({ obj: pivot, axis: 'z', amp: 0.16, speed: 2.6, phase: 0, base: 0, sign: s });
      g.userData.tips.push(new THREE.Vector3(s * 4.6, 0.1, 0.9));
      engine(g, M, s * 0.55, -0.05, 1.8, 0.26, 0.7);
      // cephalic fins at front
      const cf = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 1.0), M.dark);
      cf.position.set(s * 0.7, 0.05, -3.2); cf.rotation.y = s * 0.3; g.add(cf);
    }
    // glowing dorsal spine
    for (let k = 0; k < 6; k++) {
      const sp = new THREE.Mesh(new THREE.OctahedronGeometry(0.12, 0), M.accentHot);
      sp.position.set(0, 0.42 - k * 0.04, -0.6 + k * 0.6); g.add(sp);
    }
    // tail
    const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.12, 3.0, 6).rotateX(Math.PI / 2), M.dark);
    tail.position.set(0, 0, 5.2); g.add(tail);
    g.userData.wavers.push({ obj: tail, axis: 'y', amp: 0.25, speed: 3, phase: 1, base: 0, sign: 1 });
  }

  if (def.id === 'eclipse') {
    // dark hull wrapped around a black-hole core with accretion disk
    g.add(planform(mirror([[0, -4.2], [0.8, -2.0], [3.6, 0.4], [3.6, 1.0], [1.4, 0.9], [0.9, 2.0], [0, 1.6]]), 0.14, M.hull, 0.05));
    g.add(fuselage([[0, -4.6], [0.35, -3.6], [0.6, -1.8], [0.7, 0.2], [0.5, 1.6]], M.dark, 1.1, 0.7));
    const can = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.glass);
    can.scale.set(0.3, 0.26, 1.0); can.position.set(0, 0.36, -2.2); g.add(can);
    const core = new THREE.Mesh(new THREE.SphereGeometry(0.5, 24, 16), new THREE.MeshBasicMaterial({ color: 0x000000 }));
    core.position.set(0, 0.6, 0.4); g.add(core);
    const disk = new THREE.Mesh(new THREE.RingGeometry(0.6, 1.5, 48, 1), M.flame);
    disk.position.copy(core.position); disk.rotation.x = -Math.PI / 2 + 0.35; g.add(disk);
    g.userData.spinners.push({ obj: disk, axis: 'z', speed: 3 });
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.56, 0.035, 8, 48), M.accentHot);
    rim.position.copy(core.position); rim.rotation.x = Math.PI / 2 + 0.35; g.add(rim);
    const lens = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.02, 6, 48), M.glow);
    lens.position.copy(core.position); g.add(lens);
    g.userData.spinners.push({ obj: lens, axis: 'y', speed: 1.5 });
    for (const s of [-1, 1]) {
      strip(g, M.accent, s * 2.0, 0.12, -0.6, 0.06, 0.05, 4.4, s * -0.95);
      light(g, M, s * 3.6, 0.12, 0.7, 0.1);
      g.userData.tips.push(new THREE.Vector3(s * 3.6, 0.12, 1.0));
      engine(g, M, s * 1.0, 0.0, 1.8, 0.3, 0.8);
      for (let k = 0; k < 3; k++) {
        const shard = new THREE.Mesh(new THREE.TetrahedronGeometry(0.2, 0), M.accent);
        const pv = new THREE.Group(); pv.position.copy(core.position); pv.rotation.y = k * 2.1 + (s > 0 ? 1 : 0);
        shard.position.set(1.9 + k * 0.15, 0, 0); pv.add(shard); g.add(pv);
        g.userData.spinners.push({ obj: pv, axis: 'y', speed: s * (1.6 + k * 0.4) });
      }
    }
  }

  if (def.id === 'astra') {
    // crystalline god-machine with triple rotating halos
    const crystalMat = new THREE.MeshStandardMaterial({ color: 0xdff0ff, metalness: 0.2, roughness: 0.05, emissive: def.accent, emissiveIntensity: 0.35, transparent: true, opacity: 0.85, envMapIntensity: 2.5 });
    M.crystal = crystalMat; crystalMat.userData.keep = true;
    const body = new THREE.Mesh(new THREE.OctahedronGeometry(1, 0), crystalMat);
    body.scale.set(0.7, 0.45, 3.4); body.position.set(0, 0.1, -0.6); body.castShadow = true; g.add(body);
    const inner = new THREE.Mesh(new THREE.OctahedronGeometry(0.4, 0), M.glow);
    inner.scale.set(0.5, 0.5, 2.0); inner.position.set(0, 0.1, -0.6); g.add(inner);
    for (const s of [-1, 1]) {
      for (let k = 0; k < 3; k++) {
        const blade = new THREE.Mesh(new THREE.OctahedronGeometry(1, 0), crystalMat);
        blade.scale.set(1.8 - k * 0.35, 0.06, 0.45);
        const pv = new THREE.Group(); pv.position.set(s * (1.6 + k * 0.4), 0.05 + k * 0.25, -0.8 + k * 0.9);
        blade.rotation.y = s * (-0.35 - k * 0.15);
        pv.add(blade); g.add(pv);
        g.userData.wavers.push({ obj: pv, axis: 'z', amp: 0.06, speed: 1.6, phase: k, base: s * k * 0.15, sign: s });
      }
      const orb = new THREE.Mesh(new THREE.IcosahedronGeometry(0.16, 1), M.accentHot);
      orb.position.set(s * 3.3, 0.1, -1.0); g.add(orb);
      g.userData.tips.push(new THREE.Vector3(s * 3.4, 0.1, -0.8));
      engine(g, M, s * 0.45, 0, 1.6, 0.22, 0.7);
    }
    engine(g, M, 0, 0.25, 1.9, 0.3, 0.7);
    for (let k = 0; k < 3; k++) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(1.4 + k * 0.35, 0.04, 6, 64), k === 1 ? M.accentHot : M.glow);
      ring.position.set(0, 0.2, 0.9);
      const pv = new THREE.Group(); pv.position.copy(ring.position); ring.position.set(0, 0, 0);
      pv.rotation.set(k * 0.9, k * 0.5, 0); pv.add(ring); g.add(pv);
      g.userData.spinners.push({ obj: pv, axis: k === 1 ? 'x' : 'y', speed: 0.9 + k * 0.5 });
    }
  }

  // collect material list for phase transparency
  const mats = new Set();
  g.traverse(o => { if (o.isMesh && o.material && !o.material.blending) mats.add(o.material); });
  g.traverse(o => { if (o.isMesh) mats.add(o.material); });
  g.userData.allMats = [...mats].filter(m => m.blending !== THREE.AdditiveBlending && !m.userData.keep);
  return g;
}

export function animateShip(g, t, dt) {
  for (const s of g.userData.spinners) s.obj.rotation[s.axis] += s.speed * dt;
  for (const w of g.userData.wavers) w.obj.rotation[w.axis] = w.base + Math.sin(t * w.speed + w.phase) * w.amp * w.sign;
}

export function disposeShip(g) {
  g.traverse(o => {
    if (o.isMesh) { o.geometry.dispose(); }
  });
  for (const m of Object.values(g.userData.mats || {})) m.dispose();
}
