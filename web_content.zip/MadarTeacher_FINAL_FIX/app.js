const SURAH_DATA = [["الفاتحة", 7], ["البقرة", 286], ["آل عمران", 200], ["النساء", 176], ["المائدة", 120], ["الأنعام", 165], ["الأعراف", 206], ["الأنفال", 75], ["التوبة", 129], ["يونس", 109], ["هود", 123], ["يوسف", 111], ["الرعد", 43], ["إبراهيم", 52], ["الحجر", 99], ["النحل", 128], ["الإسراء", 111], ["الكهف", 110], ["مريم", 98], ["طه", 135], ["الأنبياء", 112], ["الحج", 78], ["المؤمنون", 118], ["النور", 64], ["الفرقان", 77], ["الشعراء", 227], ["النمل", 93], ["القصص", 88], ["العنكبوت", 69], ["الروم", 60], ["لقمان", 34], ["السجدة", 30], ["الأحزاب", 73], ["سبأ", 54], ["فاطر", 45], ["يس", 83], ["الصافات", 182], ["ص", 88], ["الزمر", 75], ["غافر", 85], ["فصلت", 54], ["الشورى", 53], ["الزخرف", 89], ["الدخان", 59], ["الجاثية", 37], ["الأحقاف", 35], ["محمد", 38], ["الفتح", 29], ["الحجرات", 18], ["ق", 45], ["الذاريات", 60], ["الطور", 49], ["النجم", 62], ["القمر", 55], ["الرحمن", 78], ["الواقعة", 96], ["الحديد", 29], ["المجادلة", 22], ["الحشر", 24], ["الممتحنة", 13], ["الصف", 14], ["الجمعة", 11], ["المنافقون", 11], ["التغابن", 18], ["الطلاق", 12], ["التحريم", 12], ["الملك", 30], ["القلم", 52], ["الحاقة", 52], ["المعارج", 44], ["نوح", 28], ["الجن", 28], ["المزمل", 20], ["المدثر", 56], ["القيامة", 40], ["الإنسان", 31], ["المرسلات", 50], ["النبأ", 40], ["النازعات", 46], ["عبس", 42], ["التكوير", 29], ["الانفطار", 19], ["المطففين", 36], ["الانشقاق", 25], ["البروج", 22], ["الطارق", 17], ["الأعلى", 19], ["الغاشية", 26], ["الفجر", 30], ["البلد", 20], ["الشمس", 15], ["الليل", 21], ["الضحى", 11], ["الشرح", 8], ["التين", 8], ["العلق", 19], ["القدر", 5], ["البينة", 8], ["الزلزلة", 8], ["العاديات", 11], ["القارعة", 11], ["التكاثر", 8], ["العصر", 3], ["الهمزة", 9], ["الفيل", 5], ["قريش", 4], ["الماعون", 7], ["الكوثر", 3], ["الكافرون", 6], ["النصر", 3], ["المسد", 5], ["الإخلاص", 4], ["الفلق", 5], ["الناس", 6]];
let user=null, circles=[], students=[], activeCircle=null, activeStudent=null, lessonType='new';
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
function screen(id){ document.querySelectorAll('.screen').forEach(x=>x.classList.add('hidden')); const el=$(id); if(el) el.classList.remove('hidden'); window.scrollTo({top:0,behavior:'smooth'}); }
function goHome(){screen('home');}
function openCircles(){screen('circles');loadCircles();}
function openCircleView(){if(!activeCircle)return openCircles();screen('circle');loadStudents();}
function openStudentView(){if(!activeStudent)return openCircleView();screen('student');loadHistory();}

async function login(){
  const email=$('email').value.trim(), password=$('password').value;
  if(!email||!password){$('loginMsg').textContent='اكتب البريد الإلكتروني وكلمة المرور.';return;}
  const btn=$('loginBtn'); btn.disabled=true; $('loginMsg').textContent='جاري الدخول...';
  try{
    const r=await sb.auth.signInWithPassword({email,password});
    if(r.error){$('loginMsg').textContent='بيانات الدخول غير صحيحة أو حدث خطأ: '+r.error.message;return;}
    user=r.data?.user||null;
    await checkRole();
  }catch(e){
    console.error(e);
    $('loginMsg').textContent='تعذر تسجيل الدخول. تأكد من الإنترنت ثم حاول مرة أخرى.';
  }finally{btn.disabled=false;}
}
async function checkRole(){
  const r=await sb.from('profiles').select('role').eq('id',user.id).single();
  if(r.error || !r.data || r.data.role!=='teacher'){await sb.auth.signOut();$('loginMsg').textContent='هذا الحساب ليس حساب محفظ.';return;}
  $('login').classList.add('hidden');$('app').classList.remove('hidden');await loadCircles();goHome();
}
async function loadCircles(){
  const r=await sb.from('circles').select('*').eq('teacher_id',user.id).order('created_at',{ascending:true});
  if(r.error){showError(r.error.message);return;}
  circles=r.data||[];$('circleCount').textContent=circles.length+' حلقة';
  $('circleList').innerHTML=circles.map(c=>`<button class="cardRow" onclick="chooseCircle('${c.id}')"><span class="rowIcon">📚</span><span class="rowText"><b>${esc(c.name)}</b><small>فتح الحلقة والطلاب</small></span><span class="arrow">‹</span></button>`).join('')||empty('لا توجد حلقات بعد. أضف أول حلقة من الأعلى.');
}
async function addCircle(){
  const name=$('circleName').value.trim();if(!name){$('circleMsg').textContent='اكتب اسم الحلقة أولاً.';return;}
  $('addCircle').disabled=true;$('circleMsg').textContent='جاري الإضافة...';
  const r=await sb.from('circles').insert({teacher_id:user.id,name});$('addCircle').disabled=false;
  if(r.error){$('circleMsg').textContent=r.error.message;return;}
  $('circleName').value='';$('circleMsg').textContent='تمت إضافة الحلقة.';await loadCircles();
}
async function chooseCircle(id){activeCircle=circles.find(c=>c.id===id)||null;if(!activeCircle)return; $('circleTitle').textContent=activeCircle.name;screen('circle');await loadStudents();}
async function loadStudents(){
  const r=await sb.from('students').select('*').eq('circle_id',activeCircle.id).eq('active',true).order('name');
  if(r.error){showError(r.error.message);return;} students=r.data||[];
  $('studentList').innerHTML=students.map(s=>`<button class="cardRow" onclick="chooseStudent('${s.id}')"><span class="avatar">${esc(s.name).slice(0,1)}</span><span class="rowText"><b>${esc(s.name)}</b><small>فتح ملف الطالب</small></span><span class="arrow">‹</span></button>`).join('')||empty('لا يوجد طلاب في هذه الحلقة.');
}
async function addStudent(){
  const name=$('studentName').value.trim();if(!name){$('studentMsg').textContent='اكتب اسم الطالب أولاً.';return;}
  $('addStudent').disabled=true;$('studentMsg').textContent='جاري الإضافة...';
  const r=await sb.from('students').insert({circle_id:activeCircle.id,name});$('addStudent').disabled=false;
  if(r.error){$('studentMsg').textContent=r.error.message;return;}
  $('studentName').value='';$('studentMsg').textContent='تمت إضافة الطالب.';await loadStudents();
}
function chooseStudent(id){activeStudent=students.find(s=>s.id===id)||null;if(!activeStudent)return;$('studentTitle').textContent=activeStudent.name;screen('student');loadHistory();}
async function loadHistory(){
  let r=await sb.from('recitations').select('*').eq('student_id',activeStudent.id).order('created_at',{ascending:false}).limit(50);
  if(r.error) r=await sb.from('recitations').select('*').eq('student_id',activeStudent.id).limit(50);
  $('history').innerHTML=(r.data||[]).map(x=>{
    const fa=x.from_ayah ?? x.from_verse ?? x.start_ayah ?? x.start_verse ?? x.ayah_from ?? x.from;
    const ta=x.to_ayah ?? x.to_verse ?? x.end_ayah ?? x.end_verse ?? x.ayah_to ?? x.to;
    return `<div class="history"><b>${x.type==='new'?'📖 حفظ جديد':'🔄 مراجعة'}</b><span>${esc(SURAH_DATA[(x.surah_number||1)-1]?.[0]||x.surah||'سورة')} — الآيات ${fa??'—'}–${ta??'—'}</span><small>${esc(x.created_at ? new Date(x.created_at).toLocaleDateString('ar-EG') : (x.date||''))}</small></div>`;
  }).join('')||empty('لا يوجد سجل لهذا الطالب.');
}
function openLesson(t){lessonType=t;$('lessonTitle').textContent=t==='new'?'حفظ جديد':'مراجعة';$('lessonMsg').textContent='';$('surah').value='0';updateAyahLimit();screen('lesson');}
function updateAyahLimit(){const m=SURAH_DATA[+$('surah').value][1];$('fromAyah').max=m;$('toAyah').max=m;$('surahHint').textContent='عدد آيات السورة: '+m;}
async function saveLesson(){
  const i=+$('surah').value,from=+$('fromAyah').value,to=+$('toAyah').value,max=SURAH_DATA[i][1];
  if(!from||!to||from<1||to<from||to>max){$('lessonMsg').textContent='راجع نطاق الآيات. الحد الأقصى لهذه السورة '+max+'.';return;}
  $('saveLesson').disabled=true;$('lessonMsg').textContent='جاري الحفظ...';
  const base={circle_id:activeCircle.id,student_id:activeStudent.id,type:lessonType,surah_number:i+1};
  const candidates=[{...base,from_ayah:from,to_ayah:to},{...base,from_verse:from,to_verse:to},{...base,start_ayah:from,end_ayah:to},{...base,start_verse:from,end_verse:to},{...base,ayah_from:from,ayah_to:to},{...base,from:from,to:to}];
  let r=null;
  for(const payload of candidates){ const attempt=await sb.from('recitations').insert(payload); if(!attempt.error){r=attempt;break;} r=attempt; }
  $('saveLesson').disabled=false;
  if(r.error){$('lessonMsg').textContent=r.error.message;return;}
  $('lessonMsg').textContent='تم تسجيل '+(lessonType==='new'?'الحفظ الجديد':'المراجعة')+' بنجاح.';$('fromAyah').value='';$('toAyah').value='';setTimeout(openStudentView,500);
}
async function renderReportCircles(){
  $('reportCircle').innerHTML=circles.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');
  if(circles.length) await renderAttendance(); else $('attendanceList').innerHTML=empty('أضف حلقة أولاً.');
}
async function renderAttendance(){
  const cid=$('reportCircle').value;if(!cid){$('attendanceList').innerHTML=empty('اختر الحلقة.');return;}
  const r=await sb.from('students').select('*').eq('circle_id',cid).eq('active',true).order('name');
  if(r.error){$('attendanceList').innerHTML=empty(r.error.message);return;}
  $('attendanceList').innerHTML=(r.data||[]).map(s=>`<label class="attendance"><input type="checkbox" data-student="${s.id}"><span>${esc(s.name)}</span><em>حاضر</em></label>`).join('')||empty('لا يوجد طلاب في هذه الحلقة.');
}
async function sendReport(){
  const cid=$('reportCircle').value,date=$('reportDate').value,hours=Number($('reportHours').value||0),notes=$('reportNotes').value.trim();
  const msg=$('reportMsg'); if(!cid||!date){msg.textContent='اختر الحلقة والتاريخ.';return;}
  $('sendReport').disabled=true;msg.textContent='جاري إرسال التقرير...';
  const checked=[...document.querySelectorAll('#attendanceList input[data-student]:checked')].map(x=>x.dataset.student);
  for(const student_id of checked){
    const a=await sb.from('attendance').insert({circle_id:cid,student_id,date,status:'present'});
    if(a.error && !String(a.error.message).toLowerCase().includes('duplicate')){msg.textContent=a.error.message;$('sendReport').disabled=false;return;}
  }
  const rep=await sb.from('daily_reports').insert({teacher_id:user.id,circle_id:cid,date,hours,notes});
  $('sendReport').disabled=false;
  if(rep.error){msg.textContent=rep.error.message;return;}
  msg.className='ok';msg.textContent='تم إرسال التقرير للمدير بنجاح.';
}
function empty(t){return `<div class="empty">${esc(t)}</div>`;}
function showError(t){alert(t);}

SURAH_DATA.forEach((s,i)=>$('surah').insertAdjacentHTML('beforeend',`<option value="${i}">${i+1} — ${s[0]}</option>`));
$('surah').onchange=updateAyahLimit;
$('loginBtn').onclick=login;$('logout').onclick=async()=>{await sb.auth.signOut();location.reload()};
$('addCircle').onclick=addCircle;$('addStudent').onclick=addStudent;$('saveLesson').onclick=saveLesson;$('sendReport').onclick=sendReport;$('reportCircle').onchange=renderAttendance;
async function init(){
  try {
    const { data, error } = await sb.auth.getSession();
    if (error) throw error;
    user = data?.session?.user || null;
    if (user) {
      await checkRole();
    } else {
      $('login').classList.remove('hidden');
      $('app').classList.add('hidden');
    }
  } catch (e) {
    console.error(e);
    $('loginMsg').textContent='تعذر الاتصال بالخادم. تأكد من الإنترنت ثم حاول مرة أخرى.';
  }
}

sb.auth.onAuthStateChange((event, session) => {
  if (event === 'SIGNED_OUT') {
    user = null;
    $('app').classList.add('hidden');
    $('login').classList.remove('hidden');
  }
});


function openReport(){
  screen('report');
  $('reportDate').value=new Date().toISOString().slice(0,10);
  renderAllCircleReports();
}
async function renderAllCircleReports(){
  const box=$('allCircleReports');
  if(!circles.length){box.innerHTML='<p class="muted">لا توجد حلقات.</p>';return}
  const parts=[];
  for(const c of circles){
    const r=await sb.from('students').select('*').eq('circle_id',c.id).eq('active',true).order('name');
    const list=r.data||[];
    parts.push(`<div class="report-card" data-circle="${c.id}">
      <h3>📚 ${esc(c.name)}</h3>
      <label>ساعات الحلقة</label>
      <input class="circle-hours" type="number" min="0" step="0.5" placeholder="مثال: 2">
      <div class="attendance-box">
        <b>الحضور:</b>
        ${list.length?list.map(s=>`<div class="att"><input type="checkbox" class="circle-att" data-student="${s.id}"><span>${esc(s.name)}</span></div>`).join(''):'<p class="muted">لا يوجد طلاب.</p>'}
      </div>
    </div>`);
  }
  box.innerHTML=parts.join('');
}
$('sendReport').onclick=async()=>{
  const msg=$('reportMsg');
  const date=$('reportDate').value;
  if(!date){msg.textContent='اختر التاريخ';return}
  msg.textContent='جاري إرسال تقرير جميع الحلقات...';
  const cards=[...document.querySelectorAll('.report-card')];
  for(const card of cards){
    const cid=card.dataset.circle;
    const hours=Number(card.querySelector('.circle-hours').value||0);
    const checked=[...card.querySelectorAll('.circle-att:checked')].map(x=>x.dataset.student);
    if(checked.length){
      const a=await sb.from('attendance').upsert(
        checked.map(student_id=>({circle_id:cid,student_id,date,status:'present'})),
        {onConflict:'student_id,date'}
      );
      if(a.error){msg.textContent=a.error.message;return}
    }
    const rep=await sb.from('daily_reports').insert({
      teacher_id:user.id,circle_id:cid,date,hours,
      notes:$('reportNotes').value.trim()
    });
    if(rep.error){msg.textContent=rep.error.message;return}
  }
  msg.textContent='تم إرسال تقرير جميع الحلقات للمدير بنجاح.';
  msg.className='ok';
};

// Start the app and restore an existing Supabase session.
init();
