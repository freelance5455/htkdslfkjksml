# ANONYMOUX STUDIO 2.5.0 — Full Repair & Verification Report

**Source archive:** `ANONYMOUX_STUDIO_2.4.9_TOOLS_TUTORIALS_REBUILD.zip`  
**Release archive:** `ANONYMOUX_STUDIO_2.5.0_FULLY_REPAIRED.zip`  
**Audit date:** 2026-11-12  
**Scope:** source inspection, targeted repair, static validation, existing regression suite, additive migration verification.

## 1. Executive summary

The supplied archive contains an existing PHP application with a database-backed Tools & Tutorials centre, resource administration, Voice Studio, Fish Audio integration, agent workspace, payments, credit ledger, media storage, and other generation workspaces. The repair retained that implementation rather than replacing it with a new application.

Two confirmed defects were corrected:

1. The public `tools-tutorials.php` route required `app/tools-tutorials.php`, but that application bootstrap file was absent from the archive. The resulting `require_once` would fail before the public catalogue could render. The missing bootstrap has been added and connects the existing resource service and authentication layer.
2. Voice TTS accepted requests without a caller-provided idempotency key and generated a fresh random key server-side. Repeated requests could consequently be charged as separate generations. The Voice Studio now sends and persists a request key across reload/network retries. The backend requires the key and uses unique per-user charge and refund key tables so concurrent duplicate attempts cannot create duplicate debits or refunds.

The source has **no PHP syntax errors in the checked PHP files**, no missing literal PHP include targets in the static include scan, and all included Python regression checks pass. A live PHP database/provider acceptance test could not be completed in this environment because the PHP runtime has PDO but no PDO database drivers, no `pdo_sqlite`, and no cURL extension. Fish Audio, payment, and other external-provider success is therefore not claimed.

## 2. Defects identified and repaired

| Finding | Severity | Repair |
|---|---|---|
| `app/tools-tutorials.php` missing while root route requires it | Critical route failure | Added a shared bootstrap requiring the existing `resources.php` and `auth.php` service layers. |
| Voice TTS accepted missing idempotency key and substituted a random key | High billing/retry risk | TTS now requires a valid `Idempotency-Key` header. |
| Voice charge deduplication relied only on a ledger lookup, which was not a database-enforced unique claim under concurrent MySQL requests | High billing race risk | Added `voice_request_keys` with `(user_id, request_key)` primary key and claim insertion inside the charge transaction. |
| Refund deduplication relied only on a prior refund-ledger lookup, which could race under concurrent refund attempts | High billing race risk | Added `voice_refunds` with `(user_id, request_key)` primary key and claim insertion inside the refund transaction. |
| Voice Studio did not persist a stable idempotency key through a lost response/reload | High retry risk | Frontend persists a pending key in `sessionStorage`, sends it on TTS requests, clears it after a definitive successful or non-duplicate error response, and retains it after an uncertain transport failure or duplicate response. |

### Existing functionality verified by source inspection

- Public resource catalogue uses `resources_catalog_page()` and database-backed tool/tutorial records.
- Resource category/search/pagination state is passed through the public route.
- Tutorial detail pages use the tutorial service and database steps/media/relations.
- Resource management actions are routed through `resource_admin_handle_post()`, which requires administrator authorization and CSRF validation.
- Resource URL validation accepts complete HTTPS destinations and rejects userinfo credentials and non-HTTPS schemes.
- Resource media is stored under private storage and served through an authenticated media endpoint with publication/role checks, basename validation, MIME allowlisting, and symlink checks.
- Voice audio history lookup is scoped to the authenticated user; audio delivery checks the owner ID and a constrained generated filename.
- Provider credentials are read server-side; the frontend calls application endpoints rather than receiving the Fish Audio key.
- Existing agent/provider billing code includes usage-ID reconciliation and opt-in USD-to-credit conversion checks covered by the supplied regression script.

## 3. Files created

- `app/tools-tutorials.php` — missing Tools & Tutorials route bootstrap.
- `migrations/005_voice_idempotency_sqlite.sql` — additive SQLite idempotency schema.
- `migrations/005_voice_idempotency_mysql.sql` — additive MySQL idempotency schema.
- `tests/voice_idempotency_migration_check.py` — repeatability and uniqueness test for the new migration.
- `FULL_REPAIR_REPORT.md` — this report.

## 4. Files modified

- `app/bootstrap.php` — idempotently creates voice charge/refund request-key tables for SQLite and MySQL at application schema initialization.
- `app/voice.php` — claims unique request keys within charge/refund transactions and treats duplicate-key collisions as duplicate requests rather than charging/refunding again.
- `api/voice/tts.php` — requires a valid idempotency key and uses it as the ledger reference.
- `assets/voice-studio.js` — persists and sends the pending idempotency key, retaining it when a network failure leaves the outcome uncertain.
- `voice-studio.php` — updates the Voice Studio JavaScript cache version.
- `migrations/README.md` — documents migration 005 and its non-destructive behavior.
- `tests/resource_admin_regression_check.py` — checks the newly restored bootstrap dependency.
- `tests/voice_flow_repair_check.py` — checks TTS idempotency key enforcement, charge/refund key tables, and client retry persistence.

No user data, production database, provider keys, or payment credentials were included in or modified by this repair process.

## 5. Database changes and preservation

Two new additive tables are introduced for both database engines:

- `voice_request_keys(user_id, request_key, created_at)` — unique primary key on `(user_id, request_key)`.
- `voice_refunds(user_id, request_key, created_at)` — unique primary key on `(user_id, request_key)`.

The application creates these tables using `CREATE TABLE IF NOT EXISTS`. Matching manual migration files are included for deployments that manage schema changes separately. The migrations are repeatable and do not drop tables, delete records, rewrite wallet balances, or alter existing credit history.

No migration was run against a production database. Existing user accounts, admin accounts, payment orders, wallets, credit transactions, generated audio, uploaded media, and workspace history remain untouched by the archive repair.

## 6. Security improvements and checks

- Required TTS idempotency keys prevent a new random charge reference from being silently generated for each client retry.
- Database uniqueness protects both debit and refund claims under concurrent requests.
- Duplicate key collisions return the existing duplicate-request error path; they do not trigger another debit or refund.
- Existing CSRF enforcement remains in place for the TTS POST endpoint.
- Existing server-side user authentication and per-user audio ownership checks remain in place.
- Existing admin resource handler retains `auth_require_admin()` and CSRF validation.
- Existing prepared statements, URL scheme validation, media MIME checks, basename validation, and storage symlink checks were retained.
- No live penetration test, authenticated browser test, or production-host configuration test was possible in this runtime.

## 7. Tests executed

| Test | Result | Notes |
|---|---|---|
| PHP syntax validation | PASS | 80 PHP files checked with `php -l`; no syntax errors reported. |
| JavaScript syntax validation | PASS | 12 JavaScript files checked with `node --check`. |
| Literal PHP include scan | PASS | No missing literal include/require targets found after repair. |
| `tests/branding_voice_integration_check.py` | PASS | Branding assets, responsive admin rules, shared voice listing wiring, and DB-backed resource route references. |
| `tests/resource_admin_regression_check.py` | PASS | Resource query/filter/pagination references, admin operations, category safety, media and history checks, and bootstrap dependency. |
| `tests/resource_migration_check.py` | PASS | Existing SQLite resource migration repeatability, tables, indexes, and representative foreign-key behavior using Python SQLite. |
| `tests/voice_flow_repair_check.py` | PASS | Existing Fish Audio/agent wiring checks plus new charge/refund idempotency checks. |
| `tests/voice_idempotency_migration_check.py` | PASS | New SQLite migration repeatability and uniqueness for charge/refund keys using Python SQLite. |
| `php tests/smoke.php` | SKIP | PHP runtime has no PDO SQLite driver or other PDO database driver. Script correctly reported the missing runtime dependency. |

### Runtime capabilities detected

- PHP CLI: 8.4.24.
- PDO extension: present.
- PDO database drivers: unavailable in this runtime.
- `pdo_sqlite`: unavailable.
- PHP cURL extension: unavailable.
- Node.js: v22.16.0.

Python SQLite tests validate the SQL migration behavior, but they are not a substitute for executing the PHP PDO persistence layer. No live Fish Audio request or payment-provider transaction was made.

## 8. Tests not executed / remaining limitations

The following acceptance tests require a configured target host and external credentials and are **not certified as passed**:

- PHP PDO SQLite/MySQL runtime persistence smoke test.
- Live Fish Audio voice catalogue, preview, synthesis, audio response, provider error, and refund tests.
- Live concurrent HTTP TTS requests against the configured database/provider.
- Actual browser registration/login/logout and session persistence.
- Live admin create/edit/delete/upload/publish/bulk/category operations against a configured production-like database.
- Live payment checkout/webhook and reconciliation tests.
- Live Decart image/video/realtime generation and unrelated workspace end-to-end tests.
- Mobile visual checks on physical Android/iOS devices and desktop browser matrix.
- Production hosting checks for HTTPS, file permissions, rewrite rules, PHP extensions, database connectivity, and storage access.

The supplied code and tests were statically audited and the available checks were executed. The presence of an integration implementation does not prove that a provider key, provider account, model entitlement, network route, payment merchant configuration, or production server is currently valid.

## 9. Deployment instructions

1. Back up the existing database and the entire `storage/` directory before deployment.
2. Preserve the existing `config.local.php` and server environment variables. Do not replace them with the example template.
3. Upload the contents of the release archive over the existing application, preserving user uploads and private storage. Do not delete the live database or `storage/` directory.
4. Confirm PHP 8.x, PDO with the selected SQLite or MySQL driver, cURL, OpenSSL, Fileinfo, and writable private storage are enabled.
5. For SQLite/MySQL, the application bootstrap creates the two new idempotency tables with `CREATE TABLE IF NOT EXISTS`. If your deployment uses manually managed migrations, run only the matching `005_voice_idempotency_*.sql` file against the configured database.
6. Sign in as an ordinary user and verify Tools & Tutorials, tutorial details, Voice Studio, and audio history. Sign in as an administrator separately to verify resource management.
7. Configure Fish Audio credentials only through the existing server-side encrypted admin configuration or server environment. Never put provider keys in JavaScript or a public config file.
8. Perform a short live voice generation and verify the debit, generated history row, playback/download, and refund behavior with a controlled test account before opening the feature to customers.
9. Run `php tests/smoke.php` on the actual host after confirming the configured PDO driver is enabled. Run the included Python checks in a suitable deployment/CI environment.

## 10. Release assessment

**Source-level repair:** completed for the confirmed missing Tools & Tutorials bootstrap and Voice Studio idempotency defects.  
**Available automated checks:** passed, except the PHP database smoke test which was skipped due to unavailable PDO drivers.  
**Production/live integration certification:** not completed; it requires the target hosting environment, database driver, Fish Audio credentials, and any payment/provider credentials.

This release is a targeted repair of the supplied 2.4.9 source, not a claim that all third-party services or production-host settings have been live-verified. No known P0 defect was observed in the executed source-level checks; production deployment should remain gated on the live acceptance tests listed above.
