Chess Master updated HTML game. Open index.html in a browser with internet access. This is not an APK.
