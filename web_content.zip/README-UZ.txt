TANYA: OSMON JANGI — yangilangan loyiha

O'zgarishlar:
- Tanya obrazi: sariq uzun soch, qizil bantlar, ofitser kepkasi, oltin tugmalar va plash.
- Jamoa askarlari: harbiy yashil kiyim, belbog' va T.N.Y. nishoni.
- O'yin xaritasidagi uylar oldiga T.N.Y. yozuvi qo'shildi.
- Asl nusxa index.original.html nomi bilan saqlangan.

Ishga tushirish:
1. ZIPni oching.
2. index.html faylini brauzerda oching (internet kerak, Three.js CDN'dan olinadi).
3. Telefon uchun landshaft holatida ochish qulay.

Eslatma: bu web o'yin; APK fayl emas. Android APK uchun Android Studio/Gradle build muhiti kerak.
