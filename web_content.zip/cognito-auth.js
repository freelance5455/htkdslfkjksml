/**
 * Maa Annapurna Tiffin Service - AWS Cognito Authentication Engine
 * Pure Native Browser Implementation (No external Node bundles or build tools needed)
 * 
 * Features:
 *  - Sign Up (Registration with Email, Mobile & Business Name)
 *  - Confirm Sign Up (OTP Email Verification)
 *  - Resend OTP Code
 *  - Sign In (USER_PASSWORD_AUTH with persistent tokens)
 *  - Keep User Logged In (Token refresh & session validation)
 *  - Forgot Password & Reset Password with OTP
 *  - Sign Out (Token clearance & state cleanup)
 *  - Automatic Seamless Fallback: Live AWS Cognito + Developer Sandbox Mode
 */

const CognitoAuth = (function () {
  const TOKEN_KEYS = {
    ID_TOKEN: 'cognito_id_token',
    ACCESS_TOKEN: 'cognito_access_token',
    REFRESH_TOKEN: 'cognito_refresh_token',
    USER_ID: 'cognito_user_id', // Partition key (Cognito sub)
    USER_EMAIL: 'cognito_user_email',
    USER_NAME: 'cognito_user_name',
    USER_PHONE: 'cognito_user_phone',
    EXPIRES_AT: 'cognito_token_expires_at',
    AUTH_PROVIDER: 'cognito_auth_provider' // 'aws' or 'sandbox'
  };

  // In-memory mock store for sandbox testing prior to AWS deployment
  const SANDBOX_USERS_KEY = 'cognito_sandbox_registered_users';

  function getCognitoEndpoint() {
    return `https://cognito-idp.${AWS_CONFIG.region}.amazonaws.com/`;
  }

  // Helper to make signed JSON requests to AWS Cognito IDP
  async function callCognitoAPI(target, payload) {
    const endpoint = getCognitoEndpoint();
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-amz-json-1.1',
        'X-Amz-Target': `AWSCognitoIdentityProviderService.${target}`
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      const errorMsg = data.message || data.__type || response.statusText || 'AWS Cognito Request Failed';
      const err = new Error(errorMsg);
      err.code = data.__type ? data.__type.split('#').pop() : 'CognitoError';
      err.raw = data;
      throw err;
    }

    return data;
  }

  // Parse JWT token payload without external libraries
  function parseJwt(token) {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(
        atob(base64)
          .split('')
          .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      return JSON.parse(jsonPayload);
    } catch (e) {
      return null;
    }
  }

  // Sandbox helper storage
  function getSandboxUsers() {
    try {
      const str = localStorage.getItem(SANDBOX_USERS_KEY);
      return str ? JSON.parse(str) : [];
    } catch {
      return [];
    }
  }

  function saveSandboxUsers(users) {
    try {
      localStorage.setItem(SANDBOX_USERS_KEY, JSON.stringify(users));
    } catch (e) {
      console.error(e);
    }
  }

  return {
    // Check if live AWS or sandbox mode is active
    isLiveAws: function () {
      return Boolean(AWS_CONFIG.userPoolId && AWS_CONFIG.clientId);
    },

    // ------------------------------------------------------------------------
    // SIGN UP (Create Account)
    // ------------------------------------------------------------------------
    signUp: async function ({ email, password, phone, name }) {
      const cleanEmail = email.trim().toLowerCase();
      const cleanPhone = phone.trim().startsWith('+') ? phone.trim() : '+91' + phone.trim().replace(/\D/g, '').slice(-10);
      const cleanName = name.trim();

      if (this.isLiveAws()) {
        const payload = {
          ClientId: AWS_CONFIG.clientId,
          Username: cleanEmail,
          Password: password,
          UserAttributes: [
            { Name: 'email', Value: cleanEmail },
            { Name: 'name', Value: cleanName },
            { Name: 'phone_number', Value: cleanPhone }
          ]
        };

        const result = await callCognitoAPI('SignUp', payload);
        return {
          userSub: result.UserSub,
          userConfirmed: result.UserConfirmed,
          deliveryMedium: result.CodeDeliveryDetails?.DeliveryMedium || 'EMAIL',
          destination: result.CodeDeliveryDetails?.Destination || cleanEmail,
          mode: 'aws'
        };
      } else {
        // Developer Sandbox Simulation
        await new Promise((r) => setTimeout(r, 600)); // simulate network latency
        const users = getSandboxUsers();
        const existing = users.find((u) => u.email === cleanEmail);
        if (existing && existing.confirmed) {
          const err = new Error('UsernameExistsException: An account with the given email already exists.');
          err.code = 'UsernameExistsException';
          throw err;
        }

        const mockSub = 'cognito-sub-' + Math.random().toString(36).substring(2, 10) + '-user';
        const updatedUsers = users.filter((u) => u.email !== cleanEmail);
        updatedUsers.push({
          sub: mockSub,
          email: cleanEmail,
          password: password,
          phone: cleanPhone,
          name: cleanName,
          confirmed: false,
          otp: '123456'
        });
        saveSandboxUsers(updatedUsers);

        return {
          userSub: mockSub,
          userConfirmed: false,
          deliveryMedium: 'EMAIL',
          destination: cleanEmail,
          mode: 'sandbox',
          sandboxDemoCode: '123456'
        };
      }
    },

    // ------------------------------------------------------------------------
    // CONFIRM SIGN UP (Verify OTP Code)
    // ------------------------------------------------------------------------
    confirmSignUp: async function (email, code) {
      const cleanEmail = email.trim().toLowerCase();
      const cleanCode = code.trim();

      if (this.isLiveAws()) {
        const payload = {
          ClientId: AWS_CONFIG.clientId,
          Username: cleanEmail,
          ConfirmationCode: cleanCode
        };
        await callCognitoAPI('ConfirmSignUp', payload);
        return { success: true, mode: 'aws' };
      } else {
        // Sandbox verification
        await new Promise((r) => setTimeout(r, 400));
        const users = getSandboxUsers();
        const user = users.find((u) => u.email === cleanEmail);
        if (!user) {
          throw new Error('UserNotFoundException: User does not exist.');
        }
        // Accept the test code 123456 or any 6-digit code for fast testing
        if (cleanCode.length !== 6) {
          throw new Error('CodeMismatchException: Invalid verification code format (must be 6 digits).');
        }
        user.confirmed = true;
        saveSandboxUsers(users);
        return { success: true, mode: 'sandbox' };
      }
    },

    // ------------------------------------------------------------------------
    // RESEND CONFIRMATION CODE
    // ------------------------------------------------------------------------
    resendConfirmationCode: async function (email) {
      const cleanEmail = email.trim().toLowerCase();

      if (this.isLiveAws()) {
        const payload = {
          ClientId: AWS_CONFIG.clientId,
          Username: cleanEmail
        };
        return await callCognitoAPI('ResendConfirmationCode', payload);
      } else {
        await new Promise((r) => setTimeout(r, 400));
        return {
          CodeDeliveryDetails: {
            DeliveryMedium: 'EMAIL',
            Destination: cleanEmail
          },
          sandboxDemoCode: '123456'
        };
      }
    },

    // ------------------------------------------------------------------------
    // SIGN IN (USER_PASSWORD_AUTH)
    // ------------------------------------------------------------------------
    signIn: async function (email, password) {
      const cleanEmail = email.trim().toLowerCase();

      if (this.isLiveAws()) {
        const payload = {
          AuthFlow: 'USER_PASSWORD_AUTH',
          ClientId: AWS_CONFIG.clientId,
          AuthParameters: {
            USERNAME: cleanEmail,
            PASSWORD: password
          }
        };

        const result = await callCognitoAPI('InitiateAuth', payload);
        const authResult = result.AuthenticationResult;

        if (!authResult) {
          throw new Error('Authentication challenge required: ' + (result.ChallengeName || 'Unknown challenge'));
        }

        const idToken = authResult.IdToken;
        const accessToken = authResult.AccessToken;
        const refreshToken = authResult.RefreshToken;
        const expiresIn = authResult.ExpiresIn || 3600;

        // Decode ID token to get user sub and attributes
        const claims = parseJwt(idToken) || {};
        const userId = claims.sub || claims['cognito:username'] || cleanEmail;
        const userName = claims.name || claims['custom:name'] || 'Maa Annapurna Admin';
        const userPhone = claims.phone_number || '';

        const expiresAt = Date.now() + expiresIn * 1000;

        // Store tokens securely in localStorage (strictly auth tokens only!)
        localStorage.setItem(TOKEN_KEYS.ID_TOKEN, idToken);
        localStorage.setItem(TOKEN_KEYS.ACCESS_TOKEN, accessToken);
        if (refreshToken) localStorage.setItem(TOKEN_KEYS.REFRESH_TOKEN, refreshToken);
        localStorage.setItem(TOKEN_KEYS.USER_ID, userId);
        localStorage.setItem(TOKEN_KEYS.USER_EMAIL, cleanEmail);
        localStorage.setItem(TOKEN_KEYS.USER_NAME, userName);
        localStorage.setItem(TOKEN_KEYS.USER_PHONE, userPhone);
        localStorage.setItem(TOKEN_KEYS.EXPIRES_AT, String(expiresAt));
        localStorage.setItem(TOKEN_KEYS.AUTH_PROVIDER, 'aws');

        return {
          userId,
          email: cleanEmail,
          name: userName,
          phone: userPhone,
          idToken,
          mode: 'aws'
        };
      } else {
        // Sandbox Simulation
        await new Promise((r) => setTimeout(r, 500));
        const users = getSandboxUsers();
        let user = users.find((u) => u.email === cleanEmail);

        // Allow default demo login for Maa Annapurna Tiffin Service
        if (!user && (cleanEmail === 'annapurna.tiffin@gmail.com' || cleanEmail === 'admin@annapurna.com')) {
          user = {
            sub: 'cognito-sub-annapurna-9311155593',
            email: cleanEmail,
            name: 'Maa Annapurna Tiffin Service',
            phone: '+919311155593',
            confirmed: true
          };
          users.push(user);
          saveSandboxUsers(users);
        }

        if (!user) {
          throw new Error('UserNotFoundException: User does not exist. Please Sign Up first.');
        }

        if (user.password && user.password !== password) {
          throw new Error('NotAuthorizedException: Incorrect username or password.');
        }

        const mockIdToken = 'sandbox_id_token_' + btoa(JSON.stringify({ sub: user.sub, email: user.email }));
        const mockAccessToken = 'sandbox_access_token_' + Date.now();
        const mockRefreshToken = 'sandbox_refresh_token_' + Date.now();
        const expiresAt = Date.now() + 86400 * 1000 * 7; // 7 days

        localStorage.setItem(TOKEN_KEYS.ID_TOKEN, mockIdToken);
        localStorage.setItem(TOKEN_KEYS.ACCESS_TOKEN, mockAccessToken);
        localStorage.setItem(TOKEN_KEYS.REFRESH_TOKEN, mockRefreshToken);
        localStorage.setItem(TOKEN_KEYS.USER_ID, user.sub);
        localStorage.setItem(TOKEN_KEYS.USER_EMAIL, user.email);
        localStorage.setItem(TOKEN_KEYS.USER_NAME, user.name || 'Maa Annapurna Admin');
        localStorage.setItem(TOKEN_KEYS.USER_PHONE, user.phone || '+91 9311155593');
        localStorage.setItem(TOKEN_KEYS.EXPIRES_AT, String(expiresAt));
        localStorage.setItem(TOKEN_KEYS.AUTH_PROVIDER, 'sandbox');

        return {
          userId: user.sub,
          email: user.email,
          name: user.name,
          phone: user.phone,
          idToken: mockIdToken,
          mode: 'sandbox'
        };
      }
    },

    // ------------------------------------------------------------------------
    // FORGOT PASSWORD (Initiate Reset)
    // ------------------------------------------------------------------------
    forgotPassword: async function (email) {
      const cleanEmail = email.trim().toLowerCase();

      if (this.isLiveAws()) {
        const payload = {
          ClientId: AWS_CONFIG.clientId,
          Username: cleanEmail
        };
        return await callCognitoAPI('ForgotPassword', payload);
      } else {
        await new Promise((r) => setTimeout(r, 400));
        return {
          CodeDeliveryDetails: {
            DeliveryMedium: 'EMAIL',
            Destination: cleanEmail
          },
          sandboxDemoCode: '123456'
        };
      }
    },

    // ------------------------------------------------------------------------
    // CONFIRM FORGOT PASSWORD (Submit New Password)
    // ------------------------------------------------------------------------
    confirmForgotPassword: async function (email, code, newPassword) {
      const cleanEmail = email.trim().toLowerCase();
      const cleanCode = code.trim();

      if (this.isLiveAws()) {
        const payload = {
          ClientId: AWS_CONFIG.clientId,
          Username: cleanEmail,
          ConfirmationCode: cleanCode,
          Password: newPassword
        };
        return await callCognitoAPI('ConfirmForgotPassword', payload);
      } else {
        await new Promise((r) => setTimeout(r, 500));
        const users = getSandboxUsers();
        const user = users.find((u) => u.email === cleanEmail);
        if (user) {
          user.password = newPassword;
          saveSandboxUsers(users);
        }
        return { success: true, mode: 'sandbox' };
      }
    },

    // ------------------------------------------------------------------------
    // KEEP USER LOGGED IN / CHECK SESSION
    // ------------------------------------------------------------------------
    checkSession: async function () {
      const idToken = localStorage.getItem(TOKEN_KEYS.ID_TOKEN);
      const userId = localStorage.getItem(TOKEN_KEYS.USER_ID);
      const email = localStorage.getItem(TOKEN_KEYS.USER_EMAIL);
      const expiresAt = Number(localStorage.getItem(TOKEN_KEYS.EXPIRES_AT) || 0);
      const authProvider = localStorage.getItem(TOKEN_KEYS.AUTH_PROVIDER) || 'sandbox';

      if (!idToken || !userId) {
        return { isAuthenticated: false };
      }

      // If token is expired or expiring in next 60 seconds
      if (Date.now() > expiresAt - 60000) {
        const refreshToken = localStorage.getItem(TOKEN_KEYS.REFRESH_TOKEN);
        if (refreshToken && this.isLiveAws()) {
          try {
            const refreshPayload = {
              AuthFlow: 'REFRESH_TOKEN_AUTH',
              ClientId: AWS_CONFIG.clientId,
              AuthParameters: {
                REFRESH_TOKEN: refreshToken
              }
            };
            const result = await callCognitoAPI('InitiateAuth', refreshPayload);
            const authResult = result.AuthenticationResult;
            if (authResult?.IdToken) {
              const newIdToken = authResult.IdToken;
              const newAccessToken = authResult.AccessToken;
              const expiresIn = authResult.ExpiresIn || 3600;
              localStorage.setItem(TOKEN_KEYS.ID_TOKEN, newIdToken);
              if (newAccessToken) localStorage.setItem(TOKEN_KEYS.ACCESS_TOKEN, newAccessToken);
              localStorage.setItem(TOKEN_KEYS.EXPIRES_AT, String(Date.now() + expiresIn * 1000));
            }
          } catch (e) {
            console.warn('Cognito token refresh failed:', e);
            this.signOut();
            return { isAuthenticated: false };
          }
        } else if (authProvider === 'sandbox') {
          // Prolong sandbox session
          localStorage.setItem(TOKEN_KEYS.EXPIRES_AT, String(Date.now() + 86400 * 1000 * 7));
        } else {
          this.signOut();
          return { isAuthenticated: false };
        }
      }

      return {
        isAuthenticated: true,
        user: {
          id: userId,
          email: email || 'annapurna.tiffin@gmail.com',
          name: localStorage.getItem(TOKEN_KEYS.USER_NAME) || 'Maa Annapurna Admin',
          phone: localStorage.getItem(TOKEN_KEYS.USER_PHONE) || '+91 9311155593',
          mode: authProvider
        }
      };
    },

    // ------------------------------------------------------------------------
    // SIGN OUT (Logout)
    // ------------------------------------------------------------------------
    signOut: function () {
      // Clear ONLY auth tokens from localStorage
      Object.values(TOKEN_KEYS).forEach((k) => localStorage.removeItem(k));
    },

    // ------------------------------------------------------------------------
    // GETTERS
    // ------------------------------------------------------------------------
    getCurrentUserId: function () {
      return localStorage.getItem(TOKEN_KEYS.USER_ID) || null;
    },

    getCurrentUserEmail: function () {
      return localStorage.getItem(TOKEN_KEYS.USER_EMAIL) || null;
    },

    getCurrentUserName: function () {
      return localStorage.getItem(TOKEN_KEYS.USER_NAME) || 'Maa Annapurna Admin';
    },

    getIdToken: function () {
      return localStorage.getItem(TOKEN_KEYS.ID_TOKEN) || null;
    },

    isAuthenticated: function () {
      return Boolean(localStorage.getItem(TOKEN_KEYS.USER_ID));
    }
  };
})();
