package com.jarvis.ultimate;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    // Change MODEL if you want a different one (e.g. a stronger model).
    private static final String MODEL = "claude-haiku-5-5";
    private static final String SYSTEM =
        "You are Jarvis V5, a sharp, calm and loyal AI assistant with a dry sense of humor. "
      + "The user talks to you by voice and chat, so keep replies short (1 to 3 sentences) unless they ask for detail. "
      + "Use plain text only: no markdown, no bullet symbols, no emojis, because your words are read aloud. "
      + "Reply in the language the user speaks. If asked which model or company is behind you, say you are an AI assistant and don't have those details.";

    private static final int REQ_MIC = 11;
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false, pendingListen = false;
    private SpeechRecognizer sr;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        web.setBackgroundColor(0xFF000000);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Jarvis");
        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.getDefault());
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.US);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { emit("ttsstart", ""); }
                    @Override public void onDone(String id) { emit("ttsdone", ""); }
                    @Override public void onError(String id) { emit("ttsdone", ""); }
                });
                ttsReady = true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    private void emit(final String ev, final String data) {
        web.post(() -> web.evaluateJavascript("window.onNative&&window.onNative(" + JSONObject.quote(ev) + "," + JSONObject.quote(data == null ? "" : data) + ")", null));
    }

    private SharedPreferences prefs() { return getSharedPreferences("jarvis", Context.MODE_PRIVATE); }

    private void startListen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { emit("error", "Speech recognition is not available. Install or enable the Google app."); emit("idle", ""); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListen = true; requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); return;
        }
        if (tts != null) tts.stop();
        if (sr != null) sr.destroy();
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { emit("listening", ""); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float v) {}
            public void onBufferReceived(byte[] bf) {}
            public void onEndOfSpeech() { emit("idle", ""); }
            public void onError(int c) {
                emit("idle", "");
                if (c == SpeechRecognizer.ERROR_NO_MATCH || c == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) emit("error", "Nothing heard. Tap the mic and try again.");
                else if (c == SpeechRecognizer.ERROR_NETWORK || c == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) emit("error", "Speech recognition needs an internet connection on this device.");
                else if (c == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) emit("error", "Microphone permission denied. Enable it in Android settings.");
                else emit("error", "Speech error code " + c);
            }
            public void onResults(Bundle r) {
                ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (l != null && !l.isEmpty()) emit("heard", l.get(0));
            }
            public void onPartialResults(Bundle r) {
                ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (l != null && !l.isEmpty()) emit("partial", l.get(0));
            }
            public void onEvent(int t, Bundle p) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        sr.startListening(i);
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] g) {
        if (rc == REQ_MIC) {
            boolean ok = g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED;
            if (ok && pendingListen) startListen();
            else if (!ok) { emit("error", "Microphone permission denied. Enable it in Android settings."); emit("idle", ""); }
            pendingListen = false;
        }
    }

    private void askAi(String historyJson) {
        try {
            String key = prefs().getString("key", "");
            if (key.isEmpty()) { emit("aierr", "NOKEY"); return; }
            JSONObject body = new JSONObject();
            body.put("model", MODEL);
            body.put("max_tokens", 400);
            body.put("system", SYSTEM);
            body.put("messages", new JSONArray(historyJson));
            HttpURLConnection c = (HttpURLConnection) new URL("https://api.anthropic.com/v1/messages").openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(45000);
            c.setRequestProperty("x-api-key", key);
            c.setRequestProperty("anthropic-version", "2023-06-01");
            c.setRequestProperty("content-type", "application/json");
            c.setDoOutput(true);
            c.getOutputStream().write(body.toString().getBytes("UTF-8"));
            int code = c.getResponseCode();
            InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int n;
            while (is != null && (n = is.read(buf)) > 0) bo.write(buf, 0, n);
            String resp = bo.toString("UTF-8");
            if (code >= 400) {
                String msg = "Request failed";
                try { msg = new JSONObject(resp).getJSONObject("error").getString("message"); } catch (Exception ignored) {}
                emit("aierr", code + ": " + msg);
                return;
            }
            JSONArray content = new JSONObject(resp).getJSONArray("content");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < content.length(); i++) {
                JSONObject blk = content.getJSONObject(i);
                if ("text".equals(blk.optString("type"))) sb.append(blk.optString("text"));
            }
            emit("reply", sb.toString().trim());
        } catch (Exception e) {
            emit("aierr", "Network error. Check your internet connection.");
        }
    }

    @Override public void onBackPressed() { moveTaskToBack(true); }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (sr != null) sr.destroy();
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface public void speak(String t) { if (ttsReady) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j"); else emit("ttsdone", ""); }
        @JavascriptInterface public void stopSpeak() { if (tts != null) tts.stop(); }
        @JavascriptInterface public void listen() { runOnUiThread(MainActivity.this::startListen); }
        @JavascriptInterface public void stopListen() { runOnUiThread(() -> { if (sr != null) sr.stopListening(); }); }
        @JavascriptInterface public boolean hasKey() { return !prefs().getString("key", "").isEmpty(); }
        @JavascriptInterface public void setKey(String k) { prefs().edit().putString("key", k == null ? "" : k.trim()).apply(); }
        @JavascriptInterface public void ask(final String historyJson) { new Thread(() -> askAi(historyJson)).start(); }
    }
}
