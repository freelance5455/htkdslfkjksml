(function(){
"use strict";
var J=window.Jarvis||null;
var $=function(s){return document.querySelector(s)};
var store={get:function(k,d){try{var v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},set:function(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
var cfg=Object.assign({tts:true,sfx:true,music:true,mvol:35,rain:true,lite:false},store.get("cfg",{}));
var hist=[],busy=false,listening=false,speaking=false,talk=false,misses=0,hasKey=J?J.hasKey():false;

/* ---------- SFX (synthesized with Web Audio, no files needed) ---------- */
var AC=null;
function ac(){if(!AC){try{AC=new (window.AudioContext||window.webkitAudioContext)()}catch(e){}}if(AC&&AC.state==="suspended")AC.resume();return AC}
function tone(f,d,type,vol,delay,f2){if(!cfg.sfx)return;var a=ac();if(!a)return;var t=a.currentTime+(delay||0),o=a.createOscillator(),g=a.createGain();
  o.type=type||"sine";o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+d);
  g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(vol||.1,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+d);
  o.connect(g);g.connect(a.destination);o.start(t);o.stop(t+d+.03)}
var SFX={
  click:function(){tone(1400,.04,"square",.04)},
  boot:function(){tone(120,.7,"sawtooth",.07,0,900);tone(1600,.05,"square",.05,.75);tone(1600,.05,"square",.05,.85)},
  ready:function(){tone(700,.12,"triangle",.1);tone(1050,.12,"triangle",.1,.12);tone(1400,.22,"triangle",.1,.24)},
  micOn:function(){tone(500,.14,"sine",.12,0,1000)},
  micOff:function(){tone(1000,.14,"sine",.1,0,450)},
  send:function(){tone(900,.06,"square",.05)},
  reply:function(){tone(800,.07,"triangle",.07);tone(1200,.09,"triangle",.07,.07)},
  type:function(){tone(1800+(Math.random()*700|0),.018,"square",.025)},
  err:function(){tone(180,.28,"sawtooth",.08,0,110)}
};
document.addEventListener("touchstart",ac,{once:true});
var music=null;
try{music=new Audio("sounds/music.mp3");music.loop=true}catch(e){}
function applyMusic(){if(!music)return;music.volume=(cfg.mvol==null?35:cfg.mvol)/100*(speaking?.35:1);if(cfg.music&&!listening&&!document.hidden){var p=music.play();if(p&&p.catch)p.catch(function(){})}else music.pause()}
document.addEventListener("touchstart",applyMusic,{once:true});
document.addEventListener("visibilitychange",applyMusic);

/* ---------- GLOBE (canvas, offline, no textures) ---------- */
var CITIES=[[40.7,-74],[51.5,-.1],[35.7,139.7],[-33.9,151.2],[28.6,77.2],[-23.5,-46.6],[30,31],[55.7,37.6],[1.3,103.8],[-1.3,36.8]];
var LAND=[
[[-168,66],[-140,70],[-95,72],[-80,68],[-62,58],[-55,50],[-67,44],[-76,35],[-81,25],[-97,26],[-105,22],[-117,32],[-124,40],[-125,49],[-140,60]],
[[-105,22],[-97,18],[-88,15],[-83,9],[-77,8],[-85,14],[-92,17]],
[[-73,78],[-20,82],[-20,70],[-44,60],[-55,68]],
[[-78,8],[-60,10],[-50,0],[-35,-6],[-40,-22],[-58,-38],[-66,-55],[-75,-50],[-72,-30],[-81,-5]],
[[-10,36],[-9,43],[-2,48],[5,52],[10,57],[20,70],[40,68],[70,73],[100,77],[140,72],[170,68],[160,60],[142,52],[130,42],[122,38],[122,30],[110,20],[106,10],[100,5],[98,16],[90,22],[80,15],[77,8],[72,20],[58,25],[50,30],[43,13],[35,30],[27,36],[22,37],[12,44],[3,43]],
[[-17,21],[-6,36],[10,37],[32,31],[43,12],[51,12],[40,-5],[40,-16],[33,-26],[20,-35],[12,-18],[9,4],[-8,4],[-17,14]],
[[114,-22],[130,-12],[142,-11],[153,-26],[146,-39],[135,-34],[115,-34]],
[[-5,50],[2,52],[-3,58],[-6,56]],
[[130,32],[141,36],[145,44],[140,41]],
[[95,5],[105,-6],[120,-8],[140,-8],[132,-1],[110,0]]
];
function inPoly(x,y,p){var c=false;for(var i=0,j=p.length-1;i<p.length;j=i++){var xi=p[i][0],yi=p[i][1],xj=p[j][0],yj=p[j][1];if(((yi>y)!==(yj>y))&&(x<(xj-xi)*(y-yi)/(yj-yi)+xi))c=!c}return c}
var PTS=(function(){var out=[];for(var la=-84;la<=84;la+=3){var step=3/Math.max(Math.cos(la*Math.PI/180),.25);for(var lo=-180;lo<180;lo+=step){var land=la<-72;if(!land)for(var k=0;k<LAND.length;k++){if(inPoly(lo,la,LAND[k])){land=true;break}}
if(land){var f=la*Math.PI/180,l=lo*Math.PI/180;out.push([Math.cos(f)*Math.sin(l),Math.sin(f),Math.cos(f)*Math.cos(l)])}}}return out})();

function makeGlobe(cv){
  var ctx=cv.getContext("2d"),w=0,h=0,dpr=1;
  function size(){dpr=cfg.lite?1:Math.min(window.devicePixelRatio||1,2);var r=cv.getBoundingClientRect();w=r.width||cv.width;h=r.height||cv.height;cv.width=w*dpr;cv.height=h*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
  size();
  var TILT=.4,ct=Math.cos(TILT),st=Math.sin(TILT);
  function P(x,y,z,a){var ca=Math.cos(a),sa=Math.sin(a);var x1=x*ca+z*sa,z1=-x*sa+z*ca;return [x1,y*ct-z1*st,y*st+z1*ct]}
  return {size:size,draw:function(a){
    var R=(Math.min(w,h)/2-6)*.86,cx=w/2,cy=h/2,i,k,p,q;
    ctx.clearRect(0,0,w,h);
    var g=ctx.createRadialGradient(cx,cy,R*.9,cx,cy,R*1.18);g.addColorStop(0,"rgba(0,255,102,.35)");g.addColorStop(1,"rgba(0,255,102,0)");
    ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,R*1.18,0,6.2832);ctx.fill();
    g=ctx.createRadialGradient(cx-R*.3,cy-R*.3,R*.1,cx,cy,R);g.addColorStop(0,"#052a12");g.addColorStop(1,"#000a04");
    ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,R,0,6.2832);ctx.fill();
    ctx.strokeStyle="rgba(0,255,102,.9)";ctx.lineWidth=1.5;ctx.stroke();
    ctx.strokeStyle="rgba(0,255,102,.2)";ctx.lineWidth=.6;ctx.beginPath();
    for(var lo=-180;lo<180;lo+=30){var pen=false;for(var la=-90;la<=90;la+=6){var f=la*.01745,l=lo*.01745;q=P(Math.cos(f)*Math.sin(l),Math.sin(f),Math.cos(f)*Math.cos(l),a);
      if(q[2]>0){var X=cx+q[0]*R,Y=cy-q[1]*R;pen?ctx.lineTo(X,Y):ctx.moveTo(X,Y);pen=true}else pen=false}}
    for(var la2=-60;la2<=60;la2+=30){var pen2=false;for(var lo2=-180;lo2<=180;lo2+=6){var f2=la2*.01745,l2=lo2*.01745;q=P(Math.cos(f2)*Math.sin(l2),Math.sin(f2),Math.cos(f2)*Math.cos(l2),a);
      if(q[2]>0){var X2=cx+q[0]*R,Y2=cy-q[1]*R;pen2?ctx.lineTo(X2,Y2):ctx.moveTo(X2,Y2);pen2=true}else pen2=false}}
    ctx.stroke();
    var s=R>60?2.2:1.6;ctx.fillStyle="#00ff66";ctx.beginPath();
    for(i=0;i<PTS.length;i++){p=PTS[i];q=P(p[0],p[1],p[2],a);if(q[2]>.05)ctx.rect(cx+q[0]*R-s/2,cy-q[1]*R-s/2,s,s)}
    ctx.fill();
    for(i=0;i<CITIES.length;i++){var cf=CITIES[i][0]*.01745,cl=CITIES[i][1]*.01745;q=P(Math.cos(cf)*Math.sin(cl),Math.sin(cf),Math.cos(cf)*Math.cos(cl),a);
      if(q[2]>.15){var px=cx+q[0]*R,py=cy-q[1]*R,ph=(a*.5+i*.37)%1;ctx.fillStyle="#d8ffe6";ctx.fillRect(px-1.5,py-1.5,3,3);ctx.strokeStyle="rgba(0,255,102,"+(1-ph).toFixed(2)+")";ctx.lineWidth=1;ctx.beginPath();ctx.arc(px,py,ph*11,0,6.2832);ctx.stroke()}}
    ctx.save();ctx.translate(cx,cy);ctx.rotate(-.45);ctx.strokeStyle="rgba(0,255,102,.5)";ctx.lineWidth=1;ctx.setLineDash([4,5]);ctx.beginPath();ctx.ellipse(0,0,R*1.12,R*.3,0,0,6.2832);ctx.stroke();ctx.setLineDash([]);
    var th=a*2.2;ctx.fillStyle="#d8ffe6";ctx.beginPath();ctx.arc(Math.cos(th)*R*1.12,Math.sin(th)*R*.3,3,0,6.2832);ctx.fill();ctx.restore();
    var sc=(a*3)%(R*2.4)-R*1.2;ctx.strokeStyle="rgba(0,255,102,.25)";ctx.lineWidth=1;ctx.beginPath();
    var yy=cy+sc,dx=Math.sqrt(Math.max(R*R-sc*sc,0));if(dx>0){ctx.moveTo(cx-dx,yy);ctx.lineTo(cx+dx,yy);ctx.stroke()}
  }};
}

/* ---------- code rain ---------- */
var rain=$("#rain"),rctx=rain.getContext("2d"),cols=[],FS=14,CH="01ABCDEF<>/{}[]#$%&*+=ｱｲｳｴｵｶｷｸｹｺ";
function rainSize(){rain.width=innerWidth;rain.height=innerHeight;cols=[];for(var i=0;i<Math.ceil(innerWidth/FS);i++)cols.push(Math.random()*innerHeight/FS|0)}
function rainStep(){rctx.fillStyle="rgba(0,0,0,.1)";rctx.fillRect(0,0,rain.width,rain.height);rctx.font=FS+"px monospace";
  for(var i=0;i<cols.length;i++){var y=cols[i]*FS,x=i*FS;rctx.fillStyle="#00ff66";rctx.fillText(CH.charAt(Math.random()*CH.length|0),x,y-FS);rctx.fillStyle="#d8ffe6";rctx.fillText(CH.charAt(Math.random()*CH.length|0),x,y);if(y>rain.height&&Math.random()>.975)cols[i]=0;cols[i]++}}

/* ---------- main loop ---------- */
var gMain,gBoot,rot=0,last=0,lastRain=0,booting=true;
function loop(t){
  requestAnimationFrame(loop);
  if(document.hidden)return;
  var gap=cfg.lite?50:33;
  if(t-last<gap)return;last=t;rot+=cfg.lite?.03:.02;
  if(booting&&gBoot)gBoot.draw(rot);else if(gMain)gMain.draw(rot);
  if(cfg.rain&&t-lastRain>(cfg.lite?160:70)){lastRain=t;rainStep()}
}

/* ---------- UI ---------- */
function add(cls,text){var c=$("#chat"),d=document.createElement("div");d.className="msg "+cls;c.appendChild(d);
  if(cls==="jv"&&!cfg.lite&&text.length>1){var n=0;(function t(){n=Math.min(text.length,n+2);d.textContent=text.slice(0,n);SFX.type();$("#v-chat").scrollTop=1e6;if(n<text.length)setTimeout(t,22)})()}else d.textContent=text;
  $("#v-chat").scrollTop=1e6;while(c.children.length>60)c.removeChild(c.firstChild)}
function setView(v){document.querySelectorAll(".view").forEach(function(e){e.classList.toggle("on",e.id==="v-"+v)});
  document.querySelectorAll("nav button").forEach(function(b){b.classList.toggle("on",b.dataset.v===v)})}
function status(){$("#sNet").textContent=navigator.onLine?"ONLINE":"OFFLINE";
  $("#sAi").textContent=busy?"THINKING":(hasKey?"READY":"NO KEY");
  $("#sMic").textContent=listening?"LISTEN":"IDLE";
  $("#sTts").textContent=speaking?"SPEAKING":(cfg.tts?"ON":"OFF");
  $("#mic").classList.toggle("live",listening);$("#talk").classList.toggle("on",talk);
  $("#keyNote").textContent=hasKey?"API key saved on this phone.":"No API key saved yet."}
function clock(){var d=new Date();$("#clock").textContent=("0"+d.getHours()).slice(-2)+":"+("0"+d.getMinutes()).slice(-2);status()}

/* ---------- chat with the AI ---------- */
function send(raw){
  var t=(raw||"").trim();if(!t||busy)return;
  add("you",t);
  if(!J){add("err","Native bridge missing. Install the APK on your phone. This will not work in a browser.");return}
  if(!hasKey){add("err","Paste your API key in SETUP first.");setView("set");return}
  hist.push({role:"user",content:t});busy=true;status();
  var h=hist.slice(-16);while(h.length&&h[0].role!=="user")h.shift();
  J.stopSpeak();J.ask(JSON.stringify(h));
}
function maybeListen(){if(talk&&J&&!busy&&!listening)setTimeout(function(){if(talk&&!busy&&!listening&&!speaking)J.listen()},350)}

window.onNative=function(ev,d){
  if(ev==="heard"){misses=0;$("#in").value="";send(d)}
  else if(ev==="partial"){$("#in").value=d}
  else if(ev==="listening"){listening=true;applyMusic();SFX.micOn();status()}
  else if(ev==="idle"){if(listening)SFX.micOff();listening=false;applyMusic();status()}
  else if(ev==="ttsstart"){speaking=true;applyMusic();status()}
  else if(ev==="ttsdone"){speaking=false;applyMusic();status();maybeListen()}
  else if(ev==="reply"){busy=false;hist.push({role:"assistant",content:d||"..."});add("jv",d||"...");status();if(cfg.tts&&d)J.speak(d);else maybeListen()}
  else if(ev==="aierr"){busy=false;hist.pop();SFX.err();
    if(d==="NOKEY"){hasKey=false;add("err","No API key saved. Open SETUP.");setView("set")}
    else add("err",(/^401/.test(d)?"The API key was rejected. Check it in SETUP. ":"")+d);
    talk=false;status()}
  else if(ev==="error"){
    if(talk&&/Nothing heard/.test(d)&&++misses<3){maybeListen();return}
    SFX.err();add("err",d);talk=false;status()}
};

/* ---------- wiring ---------- */
$("#send").onclick=function(){SFX.send();var v=$("#in").value;$("#in").value="";send(v)};
$("#in").addEventListener("keydown",function(e){if(e.key==="Enter")$("#send").click()});
$("#in").addEventListener("input",function(){SFX.type()});
$("#mic").onclick=function(){if(!J){add("err","The microphone works only inside the Android app.");return}if(listening)J.stopListen();else if(!busy)J.listen()};
$("#talk").onclick=function(){if(!J){add("err","Talk mode works only inside the Android app.");return}talk=!talk;misses=0;status();if(talk&&!busy&&!listening)J.listen();else if(!talk)J.stopListen()};
$("#stop").onclick=function(){talk=false;if(J){J.stopSpeak();J.stopListen()}status()};
document.querySelectorAll("nav button").forEach(function(b){b.onclick=function(){setView(b.dataset.v)}});
$("#saveKey").onclick=function(){var k=$("#key").value.trim();if(!k||!J)return;J.setKey(k);$("#key").value="";hasKey=true;status();add("jv","Key saved. I am ready.");setView("chat")};
$("#delKey").onclick=function(){if(J)J.setKey("");hasKey=false;status()};
$("#bTest").onclick=function(){if(J)J.speak("Jarvis V5 voice check. All systems online.");else add("err","Voice works only inside the Android app.")};
$("#bClr").onclick=function(){hist=[];$("#chat").innerHTML="";setView("chat")};
[["#cTts","tts"],["#cSfx","sfx"],["#cMus","music"],["#cRain","rain"],["#cLite","lite"]].forEach(function(p){var e=$(p[0]);e.checked=!!cfg[p[1]];e.onchange=function(){cfg[p[1]]=e.checked;store.set("cfg",cfg);
  if(p[1]==="rain"&&!e.checked)rctx.clearRect(0,0,rain.width,rain.height);
  if(p[1]==="lite"){document.body.classList.toggle("lite",cfg.lite);gMain.size();gBoot.size()}
  if(p[1]==="music")applyMusic();status()}});
$("#vMus").value=cfg.mvol;$("#vMus").oninput=function(){cfg.mvol=+this.value;store.set("cfg",cfg);applyMusic()};
addEventListener("resize",function(){rainSize();gMain.size()});
addEventListener("online",status);addEventListener("offline",status);

/* ---------- boot ---------- */
document.body.classList.toggle("lite",cfg.lite);SFX.boot();
gBoot=makeGlobe($("#bootGlobe"));gMain=makeGlobe($("#globe"));rainSize();requestAnimationFrame(loop);
var lines=["> kernel ............ OK","> display ........... OK","> bridge ............ "+(J?"OK":"NOT FOUND"),"> speech engine ..... "+(J?"CHECKED":"N/A"),"> AI core ........... "+(hasKey?"KEY OK":"NO KEY"),"> JARVIS V5 ready"];
var bi=0,bt=$("#bootText"),iv=setInterval(function(){if(bi<lines.length){bt.textContent+=lines[bi++]+"\n"}else clearInterval(iv)},170);
setTimeout(function(){$("#boot").classList.add("off");booting=false;SFX.ready();applyMusic();gMain.size();clock();setInterval(clock,5000);
  add("jv",!J?"Bridge missing. Install the APK on your phone.":hasKey?"Jarvis V5 online. Tap MIC and talk, or type.":"Welcome. Open SETUP and paste your API key so I can think.");
  if(!hasKey&&J)setView("set");
  setTimeout(function(){$("#boot").style.display="none"},600)},1500);
})();
