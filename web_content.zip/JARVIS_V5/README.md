# JARVIS V5 (com.jarvis.ultimate)
Talking AI only: chat by text or voice. Native Android (Java) + WebView UI. No libraries.

## Build the APK
1. Android Studio: File > Open > this folder, wait for Gradle sync (internet needed).
2. Build > Build APK(s). APK: `app/build/outputs/apk/debug/app-debug.apk`
3. Copy to the phone and install. It updates the old Jarvis app (same package).
   (Command line: `gradle wrapper --gradle-version 8.2` then `./gradlew assembleDebug`.)

## First run (required)
The AI needs your own Anthropic API key (console.anthropic.com, API usage is billed to you).
Open SETUP, paste the key, SAVE. It is stored only in the app's private storage and sent only to api.anthropic.com.
The model is set by `MODEL` at the top of `MainActivity.java`.

## Use
- Type, or tap MIC and speak. TALK MODE listens again after each spoken reply (stops after 3 silent tries).
- Speech-to-text uses Google speech service (internet). Text-to-speech uses the phone voice.
- Music: `app/src/main/assets/sounds/music.mp3` (replace file to change). SFX and typing sounds are synthesized.
- Opening index.html in a browser does NOT work: the mic, voice and AI need the Android app.
