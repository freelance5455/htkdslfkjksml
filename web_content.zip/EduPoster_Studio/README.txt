EduPoster Studio
=================

A blue-themed educational HTML poster creator.

HOW TO USE
1. Extract the ZIP file.
2. Open index.html in a modern browser (Chrome recommended).
3. Click poster elements to select them. Double-click editable text to edit it.
4. Use the left tools to add titles, text, sections, icons, links, notices, checklists, and dividers.
5. Use Preview to test hyperlinks.
6. Save stores drafts in this browser's local storage.
7. Download HTML exports a standalone poster that can be opened and shared in a browser.

NOTES
- This is a local browser-based starter app; it does not require a server.
- Saved drafts are stored on the device/browser where you created them.
- Website links require an internet connection when you open them.
- Imported HTML is cleaned before its content is inserted, but always review imported material before sharing.
