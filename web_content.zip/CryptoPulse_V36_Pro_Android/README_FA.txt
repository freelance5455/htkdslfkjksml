CryptoPulse V36 Pro — Android APK Ready

این پوشه پروژه Android Studio/AndroidIDE است.
1) پوشه را در AndroidIDE یا Android Studio باز کنید.
2) Gradle Sync را اجرا کنید.
3) از Build > Build APK(s) نسخه debug را بسازید.
4) APK خروجی معمولاً در app/build/outputs/apk/debug/app-debug.apk قرار می‌گیرد.

برنامه فعلاً Paper/Demo است و معامله واقعی ندارد. داده بازار از API عمومی Binance خوانده می‌شود؛ در صورت قطع اینترنت، مقادیر نمایشی/ذخیره‌شده استفاده می‌شوند.
