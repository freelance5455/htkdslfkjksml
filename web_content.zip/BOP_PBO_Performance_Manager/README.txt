BOP PBO PERFORMANCE MANAGER — ANDROID PROJECT (v1.0)

This is the first offline-first prototype based on the screenshots and requirements:
- Deposit and withdrawal entries with dates and customer references
- Monthly, quarterly and annual targets (default Rs. 50 lakh / Rs. 1.5 crore / Rs. 6 crore)
- Customer/prospect pipeline, potential amount and follow-up date
- Business visit log
- Dashboard, monthly chart and Friday review summary
- CSV exports and JSON backup/restore
- Data stored locally in the app's WebView storage

IMPORTANT:
This deliverable is the Android Studio source project, not a compiled APK. The build environment used for this session does not contain the Android SDK / Gradle build tools, so an APK could not be compiled here.

To build the APK:
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location (usually app/build/outputs/apk/debug/app-debug.apk).

Before using real customer data, confirm your employer's data-security rules. This prototype stores information locally on the device and is not an official Bank of Punjab system. Avoid entering confidential customer details unless authorized.
