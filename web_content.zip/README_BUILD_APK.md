# CHROMA RUSH - Android APK & Standalone App Guide

This package contains the complete source code, assets, audio engine, level generators, and Capacitor configuration for **Chroma Rush**.

---

## Option 1: Instant 1-Click Install on Android (No Tools Needed)

Chroma Rush is fully Progressive Web App (PWA) compliant with offline caching and standalone display.

1. Open the game in Chrome on your Android device:
   ```
   https://ais-dev-yfhum2nl4jps5eidj66g62-254341582394.asia-northeast1.run.app
   ```
2. Tap the **"Install on Android / APK"** button on the Title Screen, or tap Chrome's three-dot menu `⋮` and select **"Add to Home Screen"** or **"Install app"**.
3. Chroma Rush will install directly to your app drawer and home screen as a standalone full-screen native-like Android application with custom icon and offline play.

---

## Option 2: Build Native `.apk` Using Capacitor & Android Studio

To compile a native `.apk` file:

### Prerequisites
- Node.js (v18+)
- Android Studio with Android SDK installed

### Steps:

1. **Extract this zip file and enter directory:**
   ```bash
   cd chroma-rush
   npm install
   ```

2. **Add Capacitor Android platform & build web bundle:**
   ```bash
   npm install @capacitor/core @capacitor/android @capacitor/cli
   npm run build
   npx cap add android
   npx cap sync
   ```

3. **Build the APK:**
   - **Via CLI:**
     ```bash
     cd android
     ./gradlew assembleDebug
     ```
     Your compiled APK will be located at:
     `android/app/build/outputs/apk/debug/app-debug.apk`

   - **Via Android Studio GUI:**
     ```bash
     npx cap open android
     ```
     Then in Android Studio click:
     **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

---

## Option 3: Free Online Cloud APK Builder (No Android Studio Needed)

You can build the APK in 2 minutes for free without installing Android Studio:

1. Push this project to GitHub.
2. Link the repository to **PWABuilder** (https://www.pwabuilder.com) or **Appflow** / **GitHub Actions**:
   - Enter your URL or upload the zip.
   - PWABuilder generates an Android `.apk` and signed `.aab` (ready for Google Play Store) with one click!
