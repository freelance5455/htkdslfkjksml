# MoonChess Reader — Complete Android Project (ZIP to APK Guide)

This archive contains **100% of everything required** to compile **MoonChess Reader** into a native offline Android `.apk`:
- `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `gradle/libs.versions.toml`, `gradle/wrapper/gradle-wrapper.properties`
- `debug.keystore` & `debug.keystore.base64` (pre-configured debug signing key)
- `app/build.gradle.kts`, `app/proguard-rules.pro`, `app/google-services.json`
- `app/src/main/AndroidManifest.xml`
- Complete Kotlin + Jetpack Compose source code (`chess/`, `scanner/`, `pdf/`, `data/`, `firebase/`, `ui/`)
- Bundled offline fonts (`inter.ttf`, `merriweather.ttf`, `jetbrains_mono.ttf`), custom adaptive launcher icons (`mipmap-*`), and unit/Robolectric tests
- `.github/workflows/build-apk.yml` (1-click cloud APK builder if you only have a phone and no PC)

---

## Option A: Convert to APK Using Only Your Phone (Free via GitHub Actions)
If you do not have Android Studio on a computer:
1. Unzip `MoonChess-Reader-Android-Project.zip` on your phone.
2. Create a new repository on [github.com](https://github.com/new) and upload all extracted files/folders (including `.github/workflows/build-apk.yml`).
3. Open the **Actions** tab in your GitHub repository — the **Build MoonChess Android APK** workflow will run automatically.
4. Once green (~2 minutes), tap the completed run and download **`MoonChess-Reader-APK`** (`app-debug.apk`), then tap to install on your phone!

---

## Option B: Convert to APK in Android Studio (Windows / macOS / Linux)
1. Unzip `MoonChess-Reader-Android-Project.zip` into a folder.
2. Open **Android Studio** (Ladybug / Meerkat or newer) → **Open** → select the unzipped folder.
3. Wait for Gradle Sync to finish.
4. In the top menu, click **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
5. Your installable APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

---

## Option C: Convert to APK via Command Line
 With JDK 17+ and Android SDK (`ANDROID_HOME`) installed:
```bash
gradle :app:assembleDebug
```
Output APK: `app/build/outputs/apk/debug/app-debug.apk`
