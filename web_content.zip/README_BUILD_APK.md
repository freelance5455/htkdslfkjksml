# ATC Tower Simulator — Full Offline Android APK Project

This archive contains a complete, ready-to-compile Android Studio / Gradle project wrapping the offline Air Traffic Control simulator (`app/src/main/assets/www/index.html`) inside a fullscreen landscape Android WebView app with **zero internet permissions** and **zero external network calls**.

## What Is Included
- `app/src/main/assets/www/index.html` — Complete self-contained simulator (all 34 airports + custom airports, animated high-DPI radar, male VHF radio voice synthesis + VHF DSP filter chain, Go-Around patterns, Auto-ATC & Manual mode, real device clock, departure turnaround & strip filters).
- `app/src/main/java/com/atc/simulator/MainActivity.java` — Immersive sticky fullscreen `sensorLandscape` WebView host with **native offline `AndroidTts` bridge** (`TextToSpeech.synthesizeToFile` -> WebAudio 340Hz-2.8kHz VHF radio filter + compression + squelch tail, plus direct TTS fallback), hardware-accelerated canvas, and local storage enabled.
- `app/src/main/AndroidManifest.xml` — Zero network permissions (100% offline).
- `build.gradle`, `settings.gradle`, `app/build.gradle`, `gradle.properties`, adaptive radar icons.
- `.github/workflows/build-apk.yml` — Optional one-click cloud APK builder via GitHub Actions.

## Option 1: Build APK with Android Studio (Recommended)
1. Extract `atc-simulator-offline-apk.zip`.
2. Open **Android Studio** -> **Open** -> select the extracted folder.
3. Wait for Gradle Sync to finish.
4. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
5. Your installable APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`
   *(Or use **Build -> Generate Signed Bundle / APK** for a release APK.)*

## Option 2: Build APK via Command Line (Gradle + Android SDK)
Inside the extracted folder:
```bash
gradle assembleDebug
```

## Option 3: Build APK Online Without Installing Android Studio
1. Upload the extracted files to a GitHub repository.
2. Open the **Actions** tab -> select **Build Offline Android APK** -> click **Run workflow**.
3. Download the compiled `ATC-Tower-Simulator-Offline-APK` `.apk` artifact.

## Offline Male Radio Voices Inside the APK
Android `WebView` disables browser `window.speechSynthesis` by default, so this project bridges Java `android.speech.tts.TextToSpeech` (`AndroidTts`) directly into the HTML5 simulator:
- Uses your Android device's built-in offline English male TTS voices (`Speech Services by Google` / Samsung TTS) dynamically so every callsign, altitude, heading, custom airport, and MAYDAY is spoken offline.
- Synthesizes each transmission to a local temporary WAV and routes it through JavaScript's real-time WebAudio VHF radio DSP (`340Hz–2820Hz` bandpass, `1480Hz` handset speaker peak, soft radio limiter, PTT clicks, carrier hum, crackle, and squelch tail).
- All cockpit sound effects (alarms, jet/prop engines, ambience, radar pings) are synthesized 100% offline via WebAudio — no `.mp3` files or internet connection required.
