let books = [
    {
        image: "PopeLeoXIV.jpg",
        title: "Pope",
        description: "Discover the exciting world of James Bond.",
        price: "RM 25"
    },
    {
        image: "PopeLeo.jpg",
        title: "Harry Potter",
        description: "Enjoy the magical world of Harry Potter.",
        price: "RM 30"
    },
    {
        image: "PopeJohnPaul.webp",
        title: "Pope John Paul",
        description: "Learn more about Pope John Paul.",
        price: "RM 35"
    },
    {
        image: "PopeBenedict.webp",
        title: "Pope Benedict",
        description: "Learn more about Pope Benedict.",
        price: "RM 40"
    }
];

let currentBook = 0;

function showBook() {

    document.getElementById("bookImage").src =
        books[currentBook].image;

    document.getElementById("bookTitle").innerHTML =
        books[currentBook].title;

    document.getElementById("bookDescription").innerHTML =
        books[currentBook].description;

    document.getElementById("bookPrice").innerHTML =
        books[currentBook].price;
}

function nextBook() {

    currentBook = currentBook + 1;

    if (currentBook >= books.length) {
        currentBook = 0;
    }

    showBook();
}

function previousBook() {

    currentBook = currentBook - 1;

    if (currentBook < 0) {
        currentBook = books.length - 1;
    }

    showBook();
}

setInterval(nextBook, 3000);