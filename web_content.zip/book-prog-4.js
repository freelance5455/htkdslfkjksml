/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : PROG-3-1-1 */
registerLessonDetail(2, 3, "prog-3-1-1", {
  title: "Leçon 1 : POO Avancée et Analyse de Complexité Big-O",
  duration: "50 min (Manuel universitaire complet)",
  objectives: [
    "Comprendre pourquoi le paradigme objet résout la complexité des grands projets logiciels.",
    "Maîtriser les 4 piliers de la POO : Abstraction, Encapsulation, Héritage et Polymorphisme.",
    "Calculer rigoureusement la complexité temporelle et spatiale d'un algorithme en notation Grand O.",
    "Identifier et éliminer les boucles cachées de complexité O(n²)."
  ],
  prerequisites: ["Niveaux 1 et 2 de Programmation (fonctions et structures de données)."],
  sections: [
    {
      type: "theory",
      title: "1. De la programmation procédurale au Paradigme Objet",
      text: "Dans les années 1970-1980, la taille des logiciels explose (la « crise du logiciel »). Dans une approche purement procédurale, les données d'un côté et des centaines de fonctions de l'autre deviennent trop couplées : modifier une structure de données casse des dizaines de fonctions ailleurs.\n\nLa Programmation Orientée Objet (POO) réunit dans une même capsule — l'Objet — ses données propres (attributs) et les comportements autorisés sur ces données (méthodes). Une Classe est le plan abstrait (le moule), tandis que chaque Objet créé en RAM est une Instance concrète."
    },
    {
      type: "definition",
      term: "Les 4 Piliers de la POO",
      text: "1) Abstraction : exposer uniquement les actions essentielles d'un objet tout en masquant sa mécanique interne complexe.\n2) Encapsulation : protéger les attributs sensibles (ex: une note sur 20) contre des modifications illégales directes, en imposant le passage par des méthodes de contrôle (validation 0 ≤ note ≤ 20).\n3) Héritage : factoriser le code commun dans une classe mère (Membre) pour créer des classes filles spécialisées (Etudiant, Enseignant).\n4) Polymorphisme : capacité d'une même méthode (ex: afficher_statut()) à exécuter un comportement différent selon la classe réelle de l'objet."
    },
    {
      type: "code",
      lang: "Python — POO complète : Encapsulation, Héritage et Polymorphisme",
      code: [
        "class Membre:",
        "    def __init__(self, nom):",
        "        self.nom = nom",
        "    def role(self):",
        "        return 'Membre JOSTECH'",
        "",
        "class Etudiant(Membre):",
        "    def __init__(self, nom, moyenne):",
        "        super().__init__(nom)",
        "        self._moyenne = 0.0",
        "        self.definir_moyenne(moyenne) # Validation encapsulée",
        "",
        "    def definir_moyenne(self, val):",
        "        if 0 <= val <= 20:",
        "            self._moyenne = val",
        "",
        "    def role(self): # Redéfinition polymorphique",
        "        return f'Étudiant ({self._moyenne}/20)'",
        "",
        "class Enseignant(Membre):",
        "    def role(self):",
        "        return 'Enseignant-Chercheur'",
        "",
        "# Polymorphisme en action :",
        "equipe = [Etudiant('Amina', 17.5), Enseignant('Prof. Mivumbi')]",
        "for m in equipe:",
        "    print(m.nom, '→', m.role())"
      ].join("\n")
    },
    {
      type: "theory",
      title: "2. Analyse Asymptotique : pourquoi la notation Big-O ?",
      text: "Mesurer un algorithme avec un chronomètre en secondes n'a aucune valeur scientifique universelle : un code mal conçu paraîtra rapide sur un processeur récent et catastrophique sur un téléphone d'entrée de gamme.\n\nL'analyse asymptotique mesure comment croît le nombre d'opérations élémentaires T(n) lorsque la taille des données d'entrée n devient très grande (dans le pire cas). On note O(...) en conservant uniquement le terme mathématique dominant et en supprimant les constantes multiplicatives : ainsi, T(n) = 4n² + 25n + 100 s'écrit simplement O(n²)."
    },
    {
      type: "table",
      title: "3. Échelle universelle des complexités Big-O",
      headers: ["Notation", "Nom", "Opérations pour n = 1 000 000", "Algorithme typique"],
      rows: [
        ["O(1)", "Constante", "1", "Accès à tab[i] ou recherche dans un dictionnaire (Hash)"],
        ["O(log n)", "Logarithmique", "~20", "Recherche dichotomique dans un tableau trié"],
        ["O(n)", "Linéaire", "1 000 000", "Parcours simple d'une liste (min, max, somme)"],
        ["O(n log n)", "Quasi-linéaire", "~20 000 000", "Tris rapides efficaces (MergeSort, Timsort)"],
        ["O(n²)", "Quadratique", "1 000 000 000 000", "Double boucle imbriquée (tri à bulles)"],
        ["O(2^n)", "Exponentielle", "Impossible (siècles)", "Force brute sur tous les sous-ensembles"]
      ]
    },
    {
      type: "warning",
      title: "Pièges fréquents en architecture et complexité",
      text: "1) Complexité O(n²) cachée en Python/JS : écrire « for x in liste_A: if x in liste_B: » est en réalité O(n × m) car « x in liste_B » parcourt toute la liste B à chaque tour ! Remplacer liste_B par un ensemble (set) ramène la recherche à O(1) et tout l'algorithme à O(n).\n2) Complexité spatiale : un algorithme rapide en temps peut consommer trop de mémoire RAM O(n). Sur smartphone à mémoire limitée, il faut toujours arbitrer le compromis Temps / Espace.\n3) Abus d'héritage : n'utilisez l'héritage que pour une vraie relation « est un » (un Étudiant EST UN Membre). Sinon, préférez la composition (« a un »)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Déterminer la complexité Big-O de fragments de code",
      question: "Donnez la complexité temporelle Big-O (dans le pire cas) de chacun des 3 algorithmes suivants sur une liste de taille n :\nA) Lire le 1er et le dernier élément : x = tab[0] + tab[n-1]\nB) Deux boucles l'une APRÈS l'autre (non imbriquées) de taille n chacune.\nC) Deux boucles imbriquées où i va de 0 à n-1 et j va de i+1 à n-1.",
      solution: "A) O(1) : temps constant indépendant de n.\nB) O(n) + O(n) = O(2n) = O(n) (on supprime la constante 2).\nC) Le nombre total de tours vaut (n-1) + (n-2) + ... + 1 = n(n-1)/2 = (n² - n)/2 → le terme dominant est n², donc complexité O(n²) !"
    },
    {
      title: "Exercice 2 — Passage à l'échelle JOSTECH",
      question: "La plateforme compte 1 024 000 étudiants triés par matricule.\n1) Combien d'opérations exige la recherche dichotomique O(log₂ n) au maximum ?\n2) Si un algorithme O(n²) met 1 milliseconde pour n = 1 000, combien de temps mettra-t-il approximativement pour n = 100 000 (100× plus de données) ?",
      solution: "1) 2^20 = 1 048 576, donc environ 20 comparaisons seulement !\n2) Lorsque n est multiplié par 100, un algorithme quadratique O(n²) met 100² = 10 000 fois plus de temps : 1 ms × 10 000 = 10 secondes !"
    },
    {
      title: "Exercice 3 — Refactoring d'un piège O(n²)",
      question: "Pour trouver les étudiants inscrits à la fois en Python (liste A) et en C (liste B) de 50 000 noms chacune, pourquoi transformer B en ensemble (set_B = set(B)) accélère-t-il radicalement le programme ?",
      solution: "Avec une liste, tester « nom in B » prend O(n), donc la boucle sur A coûte 50 000 × 50 000 = 2,5 milliards d'opérations (O(n²)). Avec un set (table de hachage), tester « nom in set_B » prend O(1) en moyenne, ramenant le coût total à ~50 000 opérations (O(n)) !"
    }
  ],
  summary: "La POO organise des logiciels évolutifs grâce à l'abstraction, l'encapsulation, l'héritage et le polymorphisme. Couplée à l'analyse Big-O (temps et espace), elle permet aux ingénieurs de bâtir des applications fiables qui restent fluides même face à des millions d'utilisateurs.",
  references: [
    "Meyer, B. — Conception et programmation orientées objet, Eyrolles.",
    "Cormen, T. et al. — Introduction to Algorithms (MIT Press).",
    "Gamma, E. et al. — Design Patterns: Elements of Reusable Object-Oriented Software."
  ]
});