/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : IG-3-1-1 */
registerLessonDetail(1, 3, "ig-3-1-1", {
  title: "Leçon 1 : Hiérarchie Mémoire, Caches (L1-L3) et Pipeline CPU",
  duration: "50 min (Manuel universitaire complet)",
  objectives: [
    "Analyser le phénomène du « Memory Wall » (écart de vitesse entre processeur et RAM).",
    "Distinguer physiquement SRAM (Caches) et DRAM (Mémoire centrale).",
    "Exploiter la localité temporelle et spatiale ainsi que les lignes de cache (64 octets).",
    "Calculer le Temps Moyen d'Accès Mémoire (AMAT) et comprendre le Pipeline d'instructions."
  ],
  prerequisites: ["Niveaux 1 et 2 d'Informatique générale (Von Neumann, Bus et Registres)."],
  sections: [
    {
      type: "theory",
      title: "1. Le Mur de la Mémoire (The Memory Wall)",
      text: "Depuis les années 1980, la vitesse de calcul des processeurs a progressé bien plus rapidement que la vitesse d'accès aux barrettes de mémoire RAM. Aujourd'hui, un cœur de processeur cadencé à 3 GHz réalise un cycle d'horloge en 0,33 nanoseconde. Pendant ce temps, aller chercher une donnée dans la mémoire RAM (DRAM) prend environ 70 à 100 nanosecondes.\n\nFaites le calcul : 80 ns ÷ 0,33 ns ≈ 240 cycles ! Sans mécanisme intermédiaire, un processeur ultra-rapide passerait plus de 95 % de son temps totalement bloqué à attendre la RAM. Pour résoudre ce conflit entre vitesse (très chère) et grande capacité (peu coûteuse), les architectes utilisent une pyramide de mémoires : la Hiérarchie Mémoire."
    },
    {
      type: "table",
      title: "2. Pyramide hiérarchique et technologies physiques",
      headers: ["Niveau", "Technologie", "Capacité typique", "Latence"],
      rows: [
        ["Registres CPU", "Bascules internes", "Quelques centaines d'octets", "0,3 ns (1 cycle)"],
        ["Cache L1 (L1i / L1d)", "SRAM (6 transistors/bit)", "32 à 64 Ko par cœur", "~1 ns (3-4 cycles)"],
        ["Cache L2", "SRAM rapide", "256 Ko à 2 Mo par cœur", "~4 ns (12 cycles)"],
        ["Cache L3", "SRAM partagé", "8 Mo à 64 Mo (tous cœurs)", "~15 ns (40 cycles)"],
        ["Mémoire RAM", "DRAM (1 transistor + condensateur)", "4 Go à 64 Go", "~80 ns (240 cycles)"],
        ["Stockage SSD NVMe", "NAND Flash", "256 Go à 4 To", "~50 000 ns"]
      ]
    },
    {
      type: "theory",
      title: "3. Pourquoi ne pas tout fabriquer en mémoire Cache SRAM ?",
      text: "La mémoire SRAM (Static RAM) est extrêmement rapide car chaque bit est maintenu par 6 transistors tant que le courant est allumé, sans besoin de rechargement. Mais cela prend énormément de place sur le silicium, coûte très cher et chauffe beaucoup.\n\nÀ l'inverse, la mémoire DRAM (Dynamic RAM) de vos barrettes ou smartphones n'utilise qu'un minuscule transistor et un condensateur par bit : c'est très dense et bon marché (on peut mettre 16 Go dans un téléphone), mais le condensateur se décharge tout seul en quelques millisecondes ! Il faut donc sans cesse le rafraîchir, ce qui la rend beaucoup plus lente que la SRAM."
    },
    {
      type: "definition",
      term: "Cache Hit, Cache Miss, Ligne de Cache et Principe de Localité",
      text: "• Cache Hit (Succès) : la donnée demandée par le CPU est déjà présente dans le cache → accès quasi immédiat.\n• Cache Miss (Défaut) : absente du cache → le contrôleur doit aller la chercher en RAM, ce qui bloque le calcul.\n• Ligne de Cache (Cache Line) : le CPU ne transfère jamais 1 seul octet depuis la RAM ; il ramène d'un coup tout un bloc voisin de 64 octets.\n\nLes caches fonctionnent grâce à deux lois statistiques des programmes :\n1) Localité temporelle : une donnée accédée maintenant sera probablement réutilisée bientôt (ex. une variable de boucle).\n2) Localité spatiale : si l'on lit l'adresse M, on lira très probablement M+1, M+2 juste après (ex. parcours d'un tableau). Charger 64 octets d'un coup anticipe donc les lectures suivantes !"
    },
    {
      type: "code",
      lang: "Étude de cas : Impact massif sur un programme C (Matrice 2D)",
      code: [
        "Soit une grande matrice M[10000][10000] stockée ligne par ligne en RAM :",
        "",
        "// VERSION A (RAPIDE — exploite la localité spatiale) :",
        "for (int i = 0; i < 10000; i++)",
        "    for (int j = 0; j < 10000; j++)",
        "        somme += M[i][j]; // Cases voisines en RAM → Cache Hits !",
        "",
        "// VERSION B (LENTE — 5x à 15x plus lente à travail égal !) :",
        "for (int j = 0; j < 10000; j++)",
        "    for (int i = 0; i < 10000; i++)",
        "        somme += M[i][j]; // Saute de 40 000 octets à chaque pas → Cache Miss !"
      ].join("\n")
    },
    {
      type: "theory",
      title: "4. Le Pipeline d'instructions : la chaîne de montage du CPU",
      text: "Pour accélérer encore davantage le traitement, un processeur moderne n'attend pas qu'une instruction termine complètement ses 4 étapes (Fetch → Decode → Execute → Writeback) avant de commencer la suivante. Comme une chaîne de montage automobile, pendant que l'instruction 1 est à l'étape Execute, l'instruction 2 est déjà en Decode et l'instruction 3 est en Fetch !\n\nC'est le Pipelining. Il permet d'atteindre un débit proche d'une instruction terminée à chaque cycle d'horloge (IPC ≥ 1), voire plus sur les processeurs « superscalaires ». Seul point faible : lors d'un branchement conditionnel (if/else), si le CPU devine mal la branche prise (Branch Misprediction), il doit vider tout le pipeline et recommencer."
    },
    {
      type: "warning",
      title: "Pièges fréquents à éviter en ingénierie logicielle",
      text: "1) Croire que l'analyse Big-O suffit : une liste chaînée et un tableau se parcourent tous deux en O(n), mais le tableau contigu est souvent 10× plus rapide en pratique grâce aux lignes de cache.\n2) Politiques d'écriture : quand le CPU modifie une donnée en cache, deux stratégies existent : Write-Through (écrit tout de suite en cache ET en RAM, sûr mais lent) ou Write-Back (écrit en cache d'abord, puis en RAM plus tard quand la ligne est évincée — très rapide mais complexe en multi-cœur)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Temps Moyen d'Accès Mémoire (AMAT)",
      question: "Un processeur possède un cache L1 (latence = 1 ns, taux de succès = 92 %) et une RAM (latence = 80 ns). Calculez le Temps Moyen d'Accès Mémoire (AMAT) en utilisant la formule : AMAT = Temps_L1 + (Taux_Miss_L1 × Pénalité_RAM).",
      solution: "Taux de succès = 92 %, donc Taux_Miss_L1 = 1 - 0,92 = 0,08 (8 %).\nAMAT = 1 ns + (0,08 × 80 ns) = 1 + 6,4 = 7,4 ns.\nSans cache, chaque accès prendrait 80 ns : le L1 divise la latence effective par près de 11 !"
    },
    {
      title: "Exercice 2 — AMAT à deux niveaux de cache (L1 + L2)",
      question: "On ajoute un cache L2 entre le L1 et la RAM. Latence L1 = 1 ns (miss 10 %). Si miss L1, on cherche en L2 (latence = 5 ns, miss local de 20 % qui va en RAM à 80 ns). Calculez le nouvel AMAT.",
      solution: "Pénalité moyenne d'un miss L1 = Temps_L2 + (Taux_Miss_L2 × Temps_RAM) = 5 + (0,20 × 80) = 5 + 16 = 21 ns.\nAMAT total = 1 + (0,10 × 21) = 1 + 2,1 = 3,1 ns !"
    },
    {
      title: "Exercice 3 — Dimensionnement d'une ligne de cache",
      question: "Un tableau d'entiers (4 octets par entier) est parcouru séquentiellement. Sachant qu'une ligne de cache mesure 64 octets et que le tableau commence pile au début d'une ligne, combien d'entiers consécutifs sont ramenés d'un seul coup lors du tout premier Cache Miss ?",
      solution: "64 octets ÷ 4 octets/entier = 16 entiers ! L'accès à tab[0] provoque 1 Cache Miss, puis les 15 accès suivants (tab[1] à tab[15]) seront automatiquement 15 Cache Hits ultra-rapides."
    }
  ],
  summary: "La hiérarchie mémoire (Registres, L1/L2/L3 en SRAM, RAM en DRAM) contourne le mur de la mémoire grâce aux principes de localité temporelle et spatiale (lignes de cache de 64 octets). Couplée au Pipeline d'instructions, elle explique pourquoi les processeurs modernes atteignent de telles performances réelles.",
  references: [
    "Hennessy, J. & Patterson, D. — Computer Architecture: A Quantitative Approach (6th Ed.).",
    "Drepper, U. (2007) — What Every Programmer Should Know About Memory.",
    "Tanenbaum, A. S. — Architecture de l'ordinateur, Pearson."
  ]
});