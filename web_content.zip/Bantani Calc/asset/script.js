const passiveData = [
    { label: "- No Splitter -", value: null, loss: 0 },
    { label: "1 : 2", value: "1:2", loss: 3.7 },
    { label: "1 : 4", value: "1:4", loss: 7.2 },
    { label: "1 : 8", value: "1:8", loss: 10.5 },
    { label: "1 : 16", value: "1:16", loss: 13.8 },
    { label: "1 : 32", value: "1:32", loss: 17.0 },
    { label: "1 : 64", value: "1:64", loss: 20.5 }
];

const ratioData = [
    { label: "- No Ratio -", value: null, r1: 0, r2: 0 },
    { label: "1 : 99", value: "1:99", r1: 1, r2: 99 },
    { label: "2 : 98", value: "2:98", r1: 2, r2: 98 },
    { label: "3 : 97", value: "3:97", r1: 3, r2: 97 },
    { label: "4 : 96", value: "4:96", r1: 4, r2: 96 },
    { label: "5 : 95", value: "5:95", r1: 5, r2: 95 },
    { label: "6 : 94", value: "6:94", r1: 6, r2: 94 },
    { label: "7 : 93", value: "7:93", r1: 7, r2: 93 },
    { label: "8 : 92", value: "8:92", r1: 8, r2: 92 },
    { label: "9 : 91", value: "9:91", r1: 9, r2: 91 },
    { label: "10 : 90", value: "10:90", r1: 10, r2: 90 },
    { label: "12 : 88", value: "12:88", r1: 12, r2: 88 },
    { label: "15 : 85", value: "15:85", r1: 15, r2: 85 },
    { label: "18 : 82", value: "18:82", r1: 18, r2: 82 },
    { label: "20 : 80", value: "20:80", r1: 20, r2: 80 },
    { label: "22 : 78", value: "22:78", r1: 22, r2: 78 },
    { label: "25 : 75", value: "25:75", r1: 25, r2: 75 },
    { label: "28 : 72", value: "28:72", r1: 28, r2: 72 },
    { label: "30 : 70", value: "30:70", r1: 30, r2: 70 },
    { label: "35 : 65", value: "35:65", r1: 35, r2: 65 },
    { label: "40 : 60", value: "40:60", r1: 40, r2: 60 },
    { label: "45 : 55", value: "45:55", r1: 45, r2: 55 },
    { label: "50 : 50", value: "50:50", r1: 50, r2: 50 }
];

let currentPassive = passiveData[0];
let currentRatio = ratioData[0];
let currentSearchPassive = passiveData[0];
let activeCalcMode = 1; // 1 = Standar, 2 = Cari Rasio
let canvasThemeMode = 'dark'; // 'dark' atau 'light' untuk canvas

let calculationHistoryMode1 = JSON.parse(localStorage.getItem('bantani_calc_history_m1')) || [];
let calculationHistoryMode2 = JSON.parse(localStorage.getItem('bantani_calc_history_m2')) || [];
let siteTreeList = JSON.parse(localStorage.getItem('bantani_site_tree')) || [];

let activeCanvasSiteId = null;
let canvasScale = 1.0;
let canvasPanX = 100;
let canvasPanY = 100;
let currentCanvasMode = 'pan'; // 'pan' | 'connect'
let isPanning = false;
let startPanX = 0;
let startPanY = 0;
let connectingSource = null; 
let currentMouseX = 0;
let currentMouseY = 0;

function init() {
    const pList = document.getElementById('passiveList');
    if (pList) {
        pList.innerHTML = passiveData.map((item, index) => `
            <li class="modal-item ${index === 0 ? 'selected' : ''}" onclick="selectPassive(${index})">
                <span>${item.label}</span>
                ${item.loss ? `<small style="color:var(--text-secondary)">~${item.loss} dB</small>` : ''}
            </li>
        `).join('');
    }

    const rList = document.getElementById('ratioList');
    if (rList) {
        rList.innerHTML = ratioData.map((item, index) => `
            <li class="modal-item ${index === 0 ? 'selected' : ''}" onclick="selectRatio(${index})">
                <span>${item.label}</span>
            </li>
        `).join('');
    }

    const sPList = document.getElementById('searchPassiveList');
    if (sPList) {
        sPList.innerHTML = passiveData.map((item, index) => `
            <li class="modal-item ${index === 0 ? 'selected' : ''}" onclick="selectSearchPassive(${index})">
                <span>${item.label}</span>
                ${item.loss ? `<small style="color:var(--text-secondary)">~${item.loss} dB</small>` : ''}
            </li>
        `).join('');
    }

    setThemeMode('dark');
    switchCalcMode(1);
    renderSiteTree();
    initCanvasEvents();
}

function switchCalcMode(mode) {
    activeCalcMode = mode;
    const m1Container = document.getElementById('calcMode1Container');
    const m2Container = document.getElementById('calcMode2Container');
    const b1 = document.getElementById('btnCalcMode1');
    const b2 = document.getElementById('btnCalcMode2');

    if (mode === 1) {
        m1Container.style.display = 'block';
        m2Container.style.display = 'none';
        b1.classList.add('active');
        b2.classList.remove('active');
    } else {
        m1Container.style.display = 'none';
        m2Container.style.display = 'block';
        b1.classList.remove('active');
        b2.classList.add('active');
    }
}

function selectSearchPassive(index) {
    currentSearchPassive = passiveData[index];
    document.getElementById('selectedSearchPassive').innerText = currentSearchPassive.label;
    closeModal('searchPassiveModal');
}

function calculateBestRatio() {
    const powerIn = parseFloat(document.getElementById('searchPowerInput').value) || 0;
    const plcLoss = currentSearchPassive.loss || 0;
    const targetOut = parseFloat(document.getElementById('searchTargetOutput').value) || 0;

    const powerAfterPlc = powerIn - plcLoss;

    let allCombinations = [];

    ratioData.forEach(item => {
        if (!item.value) return;
        let r1 = item.r1;
        let r2 = item.r2;

        let loss1 = -10 * Math.log10(r1 / 100);
        let loss2 = -10 * Math.log10(r2 / 100);

        let out1 = powerAfterPlc - loss1;
        let out2 = powerAfterPlc - loss2;

        let smallPct = Math.min(r1, r2);
        let largePct = Math.max(r1, r2);
        let smallVal = (r1 === smallPct) ? out1 : out2;
        let largeVal = (r1 === largePct) ? out1 : out2;

        allCombinations.push({
            ratioLabel: item.label,
            smallPct: smallPct,
            largePct: largePct,
            smallVal: smallVal,
            largeVal: largeVal,
            diff: Math.abs(out1 - targetOut) + Math.abs(out2 - targetOut)
        });
    });

    allCombinations.sort((a, b) => a.diff - b.diff);
    let top3 = allCombinations.slice(0, 3);

    const resultContainer = document.getElementById('searchResultContainer');
    resultContainer.style.display = 'block';

    if (top3.length === 0) {
        resultContainer.innerHTML = `<div class="result-card"><span class="result-label">Tidak ada rasio yang cocok.</span></div>`;
        return;
    }

    let html = `<div style="font-weight:700; font-size:0.85rem; margin-bottom:10px; color:var(--accent-color);"><i class="fa-solid fa-star"></i> 3 Rekomendasi Rasio Terbaik:</div>`;

    top3.forEach((rec, idx) => {
        let borderColor = idx === 0 ? '#22c55e' : (idx === 1 ? '#3b82f6' : '#eab308');
        
        // Tombol menggunakan angka persenan (contoh: Copy 45%, Input 45%)
        html += `
            <div class="result-card" style="border-left-color: ${borderColor}; flex-direction:column; align-items:flex-start; gap:8px;">
                <div style="display:flex; justify-content:space-between; width:100%; align-items:center;">
                    <span class="result-label">Rekomendasi #${idx + 1}</span>
                </div>
                <div style="font-size: 0.95rem; font-weight: 700; color: var(--text-color);">
                    Rasio ${rec.ratioLabel} (${rec.smallPct}% : ${rec.largePct}%)
                </div>
                <div style="font-size: 0.85rem; color: var(--accent-color); font-weight: 600;">
                    Hasil: (${rec.smallVal.toFixed(2)} dBm : ${rec.largeVal.toFixed(2)} dBm)
                </div>
                <div style="display:flex; gap:6px; flex-wrap:wrap; width:100%; margin-top:4px;">
                    <button class="action-btn" onclick="copyResult('${rec.smallVal.toFixed(2)}')" style="flex:1;"><i class="fa-solid fa-copy"></i> Copy ${rec.smallPct}%</button>
                    <button class="action-btn" onclick="useAsRedamanInput('${rec.smallVal.toFixed(2)}')" style="flex:1;"><i class="fa-solid fa-arrow-up"></i> Input ${rec.smallPct}%</button>
                    <button class="action-btn" onclick="copyResult('${rec.largeVal.toFixed(2)}')" style="flex:1;"><i class="fa-solid fa-copy"></i> Copy ${rec.largePct}%</button>
                    <button class="action-btn" onclick="useAsRedamanInput('${rec.largeVal.toFixed(2)}')" style="flex:1;"><i class="fa-solid fa-arrow-up"></i> Input ${rec.largePct}%</button>
                </div>
            </div>
        `;
    });

    resultContainer.innerHTML = html;

    // Simpan Histori Mode 2 lengkap dengan label persentase pada tombol di histori
    const now = new Date();
    const jam = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const tanggal = now.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
    
    const historyItem = {
        dateTime: `${jam}, ${tanggal}`,
        powerIn: powerIn,
        target: targetOut,
        splitter: currentSearchPassive.label,
        summary: `Rasio ${top3[0].ratioLabel} | ${top3[0].smallPct}%: ${top3[0].smallVal.toFixed(2)} dBm | ${top3[0].largePct}%: ${top3[0].largeVal.toFixed(2)} dBm`,
        smallPct: top3[0].smallPct,
        largePct: top3[0].largePct,
        smallVal: top3[0].smallVal.toFixed(2),
        largeVal: top3[0].largeVal.toFixed(2)
    };
    calculationHistoryMode2.unshift(historyItem);
    if (calculationHistoryMode2.length > 20) calculationHistoryMode2.pop();
    localStorage.setItem('bantani_calc_history_m2', JSON.stringify(calculationHistoryMode2));
}

function useAsRedamanInput(val) {
    document.getElementById('searchPowerInput').value = val;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetSearchForm() {
    document.getElementById('searchPowerInput').value = '0.00';
    document.getElementById('searchTargetOutput').value = '0.00';
    selectSearchPassive(0);
    document.getElementById('searchResultContainer').style.display = 'none';
}

function setThemeMode(mode) {
    document.querySelectorAll('.theme-btn').forEach(btn => btn.classList.remove('active'));

    let activeTheme = mode;
    const logoImg = document.getElementById('brandLogoImg');

    if (mode === 'dark') {
        document.getElementById('btn-theme-dark').classList.add('active');
    } else {
        document.getElementById('btn-theme-light').classList.add('active');
    }

    document.documentElement.setAttribute('data-theme', activeTheme);

    if (logoImg) {
        if (activeTheme === 'light') {
            logoImg.src = 'img/bantani-logo2.png';
        } else {
            logoImg.src = 'img/bantani-logo.png';
        }
    }
}

function switchTab(tabName, evt) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.nav-tab').forEach(el => el.classList.remove('active'));

    document.getElementById('tab-' + tabName).classList.add('active');
    if (evt && evt.currentTarget) {
        evt.currentTarget.classList.add('active');
    }

    if (tabName === 'site') {
        renderSiteTree();
    }
}

function openModal(id) {
    document.getElementById(id).classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

function openHistoryModal() {
    const titleEl = document.getElementById('historyModalTitle');
    if (activeCalcMode === 1) {
        titleEl.innerHTML = `<i class="fa-solid fa-clock-rotate-left"></i> Histori Kalkulator Mode 1 (Standar)`;
        renderHistoryListMode1();
    } else {
        titleEl.innerHTML = `<i class="fa-solid fa-clock-rotate-left"></i> Histori Kalkulator Mode 2 (Cari Rasio)`;
        renderHistoryListMode2();
    }
    openModal('historyModal');
}

function openSiteModal(siteId = null) {
    const editInput = document.getElementById('editSiteId');
    const nameInput = document.getElementById('siteName');
    const titleEl = document.getElementById('siteModalTitle');

    if (siteId) {
        const site = siteTreeList.find(s => s.id === siteId);
        if (site) {
            editInput.value = site.id;
            nameInput.value = site.name;
            titleEl.innerHTML = `<i class="fa-solid fa-pen"></i> Edit Nama Wilayah Site`;
        }
    } else {
        editInput.value = '';
        nameInput.value = '';
        titleEl.innerHTML = `<i class="fa-solid fa-network-wired"></i> Buat Wilayah / Site Baru`;
    }
    openModal('siteModal');
}

function saveSiteMaster() {
    const editId = document.getElementById('editSiteId').value;
    const name = document.getElementById('siteName').value.trim() || 'Wilayah Baru';

    if (editId) {
        const site = siteTreeList.find(s => s.id === editId);
        if (site) site.name = name;
    } else {
        const newSite = {
            id: 'site_' + Date.now(),
            name: name,
            nodes: [],
            connections: []
        };
        siteTreeList.unshift(newSite);
    }

    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    closeModal('siteModal');
    renderSiteTree();
}

function deleteTreeNode(siteId, nodeId) {
    const site = siteTreeList.find(s => s.id === siteId);
    if (!site) return;

    if (site.id === nodeId) {
        if (confirm('Hapus seluruh wilayah site ini?')) {
            siteTreeList = siteTreeList.filter(s => s.id !== siteId);
        }
    } else {
        site.nodes = site.nodes.filter(node => node.id !== nodeId);
        site.connections = site.connections.filter(c => c.fromNode !== nodeId && c.toNode !== nodeId);
    }

    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    renderSiteTree();
}

function openMasterOpenModal() {
    document.getElementById('masterOpenInputText').value = '';
    openModal('masterOpenModal');
}

async function pasteJsonToOpenInput() {
    try {
        const text = await navigator.clipboard.readText();
        document.getElementById('masterOpenInputText').value = text;
    } catch (err) {
        alert('Gagal membaca clipboard. Pastikan browser diizinkan atau paste manual.');
    }
}

function importSiteFromJson() {
    const rawText = document.getElementById('masterOpenInputText').value.trim();
    if (!rawText) {
        alert('Coding JSON site masih kosong!');
        return;
    }

    try {
        const parsedSite = JSON.parse(rawText);
        if (!parsedSite.id || !parsedSite.name || !Array.isArray(parsedSite.nodes)) {
            throw new Error('Format coding site JSON tidak valid.');
        }

        const existingIdx = siteTreeList.findIndex(s => s.id === parsedSite.id);
        if (existingIdx >= 0) {
            siteTreeList[existingIdx] = parsedSite;
        } else {
            siteTreeList.unshift(parsedSite);
        }

        localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
        closeModal('masterOpenModal');
        renderSiteTree();
        alert('Berhasil memuat / mengimpor site baru!');
    } catch (e) {
        alert('Gagal memuat JSON: Format coding salah atau tidak valid.');
    }
}

function saveSiteData(siteId) {
    const site = siteTreeList.find(s => s.id === siteId);
    if (!site) return;
    document.getElementById('saveModalTitle').innerHTML = `<i class="fa-solid fa-code"></i> Coding Site: ${site.name}`;
    document.getElementById('jsonSavePreviewContent').innerText = JSON.stringify(site, null, 2);
    openModal('saveSiteModal');
}

function copySaveJsonData() {
    const content = document.getElementById('jsonSavePreviewContent').innerText;
    navigator.clipboard.writeText(content).then(() => {
        alert('Berhasil menyalin coding site ke clipboard!');
    }).catch(err => {
        console.error('Gagal menyalin:', err);
    });
}

function shareSiteToWhatsApp(siteId) {
    const site = siteTreeList.find(s => s.id === siteId);
    if (!site) return;

    let fileJsonString = JSON.stringify(site, null, 2);
    const encodedUri = encodeURIComponent(fileJsonString);
    window.open(`https://wa.me/?text=${encodedUri}`, '_blank');
}

function renderSiteTree() {
    const container = document.getElementById('siteListContainer');
    if (!container) return;

    if (siteTreeList.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-secondary); padding: 30px;">Belum ada daftar komponen site. Klik 'Tambah Site' atau 'Open' untuk mulai.</p>`;
        return;
    }

    container.innerHTML = siteTreeList.map(site => `
        <div class="site-tree-card">
            <div class="site-tree-header">
                <span class="site-tree-title"><i class="fa-solid fa-map-pin"></i> ${site.name}</span>
                <div class="result-actions">
                    <button class="action-btn" onclick="openSiteModal('${site.id}')" title="Edit Site"><i class="fa-solid fa-pen"></i> Edit</button>
                    <button class="action-btn" onclick="openFullCanvas('${site.id}')" title="Buka Full Canvas Diagram"><i class="fa-solid fa-pen-ruler"></i> + Komponen</button>
                    <button class="action-btn delete-all-btn" onclick="deleteTreeNode('${site.id}', '${site.id}')" title="Hapus Wilayah"><i class="fa-solid fa-trash"></i> Hapus</button>
                </div>
            </div>
            <div class="site-actions-row">
                <button class="action-btn" onclick="saveSiteData('${site.id}')" title="Lihat & Simpan Coding JSON Site" style="flex:1;"><i class="fa-solid fa-code" style="color:var(--accent-color);"></i> Save</button>
                <button class="action-btn" onclick="shareSiteToWhatsApp('${site.id}')" title="Kirim Coding ke WhatsApp" style="flex:1;"><i class="fa-brands fa-whatsapp" style="color:#25d366;"></i> Share WA</button>
            </div>
            <div class="tree-nodes-container">
                ${site.nodes.length > 0 ? renderNodesSummary(site.nodes) : '<small style="color:var(--text-secondary)">Belum ada komponen di canvas.</small>'}
            </div>
        </div>
    `).join('');
}

function renderNodesSummary(nodes) {
    return nodes.map(node => `
        <div class="tree-node-item">
            <div class="tree-node-content">
                <div class="tree-node-info">
                    <span class="tree-node-badge">${node.type}</span>
                    <strong>${node.name}</strong> 
                </div>
            </div>
            <div class="node-io-details">
                <i class="fa-solid fa-network-wired" style="color:var(--accent-color);"></i> Parameter: ${getNodeDetailSummary(node)}
            </div>
        </div>
    `).join('');
}

function getNodeDetailSummary(node) {
    if (node.type === 'OLT') return `Out: ${node.value || 0} dBm`;
    if (node.type === 'PLC') return `Rasio ${node.value || '1:8'} | In: ${node.inputVal || 0} | Out: ${node.outputVal || 0}`;
    if (node.type === 'FBT') {
        let parts = (node.value || '50:50').split(':');
        return `Rasio ${node.value || '50:50'} | In: ${node.inputVal || 0} | Out ${parts[0]}%: ${node.out1Val || 0} | Out ${parts[1]}%: ${node.out2Val || 0}`;
    }
    return '';
}

function selectPassive(index) {
    currentPassive = passiveData[index];
    document.getElementById('selectedPassive').innerText = currentPassive.label;
    closeModal('passiveModal');
}

function selectRatio(index) {
    currentRatio = ratioData[index];
    document.getElementById('selectedRatio').innerText = currentRatio.label;
    closeModal('ratioModal');
}

function calculate() {
    const laserInput = parseFloat(document.getElementById('laserInput').value) || 0;
    const additionalLoss = parseFloat(document.getElementById('additionalLoss').value) || 0;
    const plcLoss = currentPassive.loss || 0;
    
    let totalLoss = plcLoss + additionalLoss;
    let finalPower = laserInput - totalLoss;

    let resultsContainer = document.getElementById('resultsContainer');
    resultsContainer.style.display = 'block';

    let html = '';

    if (currentPassive.value) {
        html += `
            <div class="result-card" style="border-left-color: #22c55e;">
                <div class="result-info">
                    <span class="result-label">Passive Splitter (${currentPassive.label}) Output</span>
                    <span class="result-sublabel">Loss ~${plcLoss} dB</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span class="result-value" style="color:#22c55e;">${finalPower.toFixed(2)} dBm</span>
                    <button class="action-btn" onclick="copyResult('${finalPower.toFixed(2)}')"><i class="fa-solid fa-copy"></i></button>
                    <button class="action-btn" onclick="useAsInput('${finalPower.toFixed(2)}')"><i class="fa-solid fa-arrow-up"></i></button>
                </div>
            </div>
        `;
    }

    if (currentRatio.value) {
        let r1 = currentRatio.r1;
        let r2 = currentRatio.r2;
        let ratioLoss1 = -10 * Math.log10(r1 / 100);
        let ratioLoss2 = -10 * Math.log10(r2 / 100);
        let finalPowerRatio1 = finalPower - ratioLoss1;
        let finalPowerRatio2 = finalPower - ratioLoss2;

        html += `
            <div class="result-card" style="border-left-color: #eab308;">
                <div class="result-info">
                    <span class="result-label">Ratio Out ${r1}%</span>
                    <span class="result-sublabel">Loss ~${ratioLoss1.toFixed(2)} dB</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span class="result-value" style="color:#eab308;">${finalPowerRatio1.toFixed(2)} dBm</span>
                    <button class="action-btn" onclick="copyResult('${finalPowerRatio1.toFixed(2)}')"><i class="fa-solid fa-copy"></i></button>
                    <button class="action-btn" onclick="useAsInput('${finalPowerRatio1.toFixed(2)}')"><i class="fa-solid fa-arrow-up"></i></button>
                </div>
            </div>
            <div class="result-card" style="border-left-color: #ec4899;">
                <div class="result-info">
                    <span class="result-label">Ratio Out ${r2}%</span>
                    <span class="result-sublabel">Loss ~${ratioLoss2.toFixed(2)} dB</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span class="result-value" style="color:#ec4899;">${finalPowerRatio2.toFixed(2)} dBm</span>
                    <button class="action-btn" onclick="copyResult('${finalPowerRatio2.toFixed(2)}')"><i class="fa-solid fa-copy"></i></button>
                    <button class="action-btn" onclick="useAsInput('${finalPowerRatio2.toFixed(2)}')"><i class="fa-solid fa-arrow-up"></i></button>
                </div>
            </div>
        `;
    }

    if (!currentPassive.value && !currentRatio.value) {
        html = `
            <div class="result-card" style="border-left-color: #3b82f6;">
                <div class="result-info">
                    <span class="result-label">Direct Output Power</span>
                    <span class="result-sublabel">Loss: ${totalLoss.toFixed(2)} dB</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span class="result-value" style="color:#3b82f6;">${finalPower.toFixed(2)} dBm</span>
                    <button class="action-btn" onclick="copyResult('${finalPower.toFixed(2)}')"><i class="fa-solid fa-copy"></i></button>
                    <button class="action-btn" onclick="useAsInput('${finalPower.toFixed(2)}')"><i class="fa-solid fa-arrow-up"></i></button>
                </div>
            </div>
        `;
    }

    resultsContainer.innerHTML = html;

    const now = new Date();
    const jam = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const tanggal = now.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
    
    const historyItem = {
        dateTime: `${jam}, ${tanggal}`,
        laser: laserInput,
        loss: totalLoss.toFixed(2),
        output: finalPower.toFixed(2),
        splitter: currentPassive.label
    };
    calculationHistoryMode1.unshift(historyItem);
    if (calculationHistoryMode1.length > 20) calculationHistoryMode1.pop();
    localStorage.setItem('bantani_calc_history_m1', JSON.stringify(calculationHistoryMode1));
}

function renderHistoryListMode1() {
    const container = document.getElementById('historyListContainer');
    if (!container) return;

    if (calculationHistoryMode1.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-secondary); padding: 20px;">Belum ada riwayat kalkulasi Mode 1.</p>`;
        return;
    }

    container.innerHTML = calculationHistoryMode1.map((item) => `
        <div class="history-item">
            <div class="history-item-header">
                <span><i class="fa-solid fa-clock"></i> ${item.dateTime}</span>
                <button class="action-btn" onclick="useAsInputFromHistory('${item.output}')" style="padding: 2px 6px; font-size:0.7rem;"><i class="fa-solid fa-arrow-up"></i> Gunakan Power</button>
            </div>
            <div class="history-item-body">
                <span>Laser: <strong>${item.laser} dBm</strong> | Splitter: <strong>${item.splitter}</strong></span>
                <span style="color:var(--accent-color);">Total Loss: ${item.loss} dB | Output: <strong>${item.output} dBm</strong></span>
            </div>
        </div>
    `).join('');
}

function renderHistoryListMode2() {
    const container = document.getElementById('historyListContainer');
    if (!container) return;

    if (calculationHistoryMode2.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-secondary); padding: 20px;">Belum ada riwayat kalkulasi Mode 2.</p>`;
        return;
    }

    container.innerHTML = calculationHistoryMode2.map((item) => `
        <div class="history-item">
            <div class="history-item-header">
                <span><i class="fa-solid fa-clock"></i> ${item.dateTime}</span>
                <div style="display:flex; gap:4px;">
                    <button class="action-btn" onclick="useAsRedamanInput('${item.smallVal}')" style="padding: 2px 6px; font-size:0.65rem;"><i class="fa-solid fa-arrow-up"></i> Input ${item.smallPct}%</button>
                    <button class="action-btn" onclick="useAsRedamanInput('${item.largeVal}')" style="padding: 2px 6px; font-size:0.65rem;"><i class="fa-solid fa-arrow-up"></i> Input ${item.largePct}%</button>
                </div>
            </div>
            <div class="history-item-body">
                <span>Redaman: <strong>${item.powerIn} dBm</strong> | Target: <strong>${item.target} dBm</strong></span>
                <span style="color:var(--accent-color); font-weight:600;">${item.summary}</span>
            </div>
        </div>
    `).join('');
}

function useAsInputFromHistory(val) {
    document.getElementById('laserInput').value = val;
    closeModal('historyModal');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function clearHistory() {
    if (activeCalcMode === 1) {
        calculationHistoryMode1 = [];
        localStorage.removeItem('bantani_calc_history_m1');
        renderHistoryListMode1();
    } else {
        calculationHistoryMode2 = [];
        localStorage.removeItem('bantani_calc_history_m2');
        renderHistoryListMode2();
    }
}

function openFullCanvas(siteId) {
    activeCanvasSiteId = siteId;
    canvasScale = 1.0;
    canvasPanX = 100;
    canvasPanY = 100;
    setCanvasMode('pan');
    openModal('fullCanvasModal');
    setTimeout(() => {
        resizeCanvas();
        redrawInteractiveCanvas();
    }, 100);
}

function resizeCanvas() {
    const canvas = document.getElementById('interactiveCanvas');
    const container = document.getElementById('canvasWorkspace');
    if (!canvas || !container) return;
    canvas.width = container.clientWidth * 2;
    canvas.height = container.clientHeight * 2;
}

function setCanvasMode(mode) {
    currentCanvasMode = mode;
    document.querySelectorAll('.canvas-toolbar .mode-btn').forEach(btn => {
        if (!btn.id.includes('Canvas')) btn.classList.remove('active');
    });
    
    if (mode === 'pan') {
        document.getElementById('modePanBtn').classList.add('active');
        document.getElementById('canvasInstructionText').innerHTML = `<i class="fa-solid fa-circle-info"></i> <strong>Mode Pan Aktif</strong>: Klik & seret area kosong untuk menggeser canvas.`;
        document.getElementById('canvasWorkspace').style.cursor = 'grab';
    } else if (mode === 'connect') {
        document.getElementById('modeConnectBtn').classList.add('active');
        document.getElementById('canvasInstructionText').innerHTML = `<i class="fa-solid fa-circle-info"></i> <strong>Mode Tarik Garis Aktif</strong>: Klik port output (hijau) dan seret ke port input (biru).`;
        document.getElementById('canvasWorkspace').style.cursor = 'crosshair';
    }
    connectingSource = null;
    redrawInteractiveCanvas();
}

function setCanvasTheme(theme) {
    canvasThemeMode = theme;
    document.getElementById('btnCanvasDark').classList.remove('active');
    document.getElementById('btnCanvasLight').classList.remove('active');

    if (theme === 'dark') {
        document.getElementById('btnCanvasDark').classList.add('active');
    } else {
        document.getElementById('btnCanvasLight').classList.add('active');
    }
    redrawInteractiveCanvas();
}

/* Fitur Save PNG High Resolution (30 Megapixel) dengan Judul Nama Site di Tengah Atas */
function saveCanvasAsHighResPNG() {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;

    const exportWidth = 7200;
    const exportHeight = 4150;

    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = exportWidth;
    tempCanvas.height = exportHeight;
    const ctx = tempCanvas.getContext('2d');

    if (canvasThemeMode === 'light') {
        ctx.fillStyle = '#ffffff';
    } else {
        ctx.fillStyle = '#050507';
    }
    ctx.fillRect(0, 0, exportWidth, exportHeight);

    ctx.fillStyle = canvasThemeMode === 'light' ? '#0f172a' : '#22c55e';
    ctx.font = 'bold 72px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`SITE: ${site.name.toUpperCase()}`, exportWidth / 2, 120);

    ctx.save();
    ctx.scale(3.0, 3.0);
    ctx.translate(200, 250);

    if (site.connections) {
        site.connections.forEach(conn => {
            let fromNode = site.nodes.find(n => n.id === conn.fromNode);
            let toNode = site.nodes.find(n => n.id === conn.toNode);
            if (fromNode && toNode) {
                let fPos = getNodePortPos(fromNode, 'out', conn.fromPort);
                let tPos = getNodePortPos(toNode, 'in', 0);

                ctx.strokeStyle = canvasThemeMode === 'light' ? '#16a34a' : '#22c55e';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.moveTo(fPos.x, fPos.y);
                ctx.bezierCurveTo(fPos.x + 80, fPos.y, tPos.x - 80, tPos.y, tPos.x, tPos.y);
                ctx.stroke();
            }
        });
    }

    site.nodes.forEach(node => {
        if (node.type === 'OLT') {
            node.h = 100;
        } else if (node.type === 'PLC') {
            let count = getOutputPortsCount(node);
            node.h = Math.max(260, count * 32 + 100);
        } else if (node.type === 'FBT') {
            node.h = 180;
        }

        ctx.fillStyle = canvasThemeMode === 'light' ? '#f8fafc' : '#18181b';
        ctx.strokeStyle = canvasThemeMode === 'light' ? '#cbd5e1' : '#27272a';
        ctx.lineWidth = 2;
        ctx.fillRect(node.x, node.y, node.w, node.h);
        ctx.strokeRect(node.x, node.y, node.w, node.h);

        ctx.fillStyle = canvasThemeMode === 'light' ? '#16a34a' : '#22c55e';
        ctx.font = 'bold 14px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(node.type + ' : ' + node.name, node.x + 16, node.y + 28);

        // Jika OLT, tidak ada port input & tombol ambil input. Hanya ada port output.
        if (node.type !== 'OLT') {
            let inPos = getNodePortPos(node, 'in', 0);
            ctx.fillStyle = '#3b82f6';
            ctx.beginPath();
            ctx.arc(inPos.x, inPos.y, 9, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2;
            ctx.stroke();

            ctx.fillStyle = '#3b82f6';
            ctx.font = 'bold 12px sans-serif';
            ctx.fillText(`In: ${node.inputVal || 0} dBm`, inPos.x + 16, inPos.y + 5);
        }

        let outPorts = getOutputPortsCount(node);
        for (let i = 0; i < outPorts; i++) {
            let oPos = getNodePortPos(node, 'out', i);
            ctx.fillStyle = canvasThemeMode === 'light' ? '#16a34a' : '#22c55e';
            ctx.beginPath();
            ctx.arc(oPos.x, oPos.y, 9, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.stroke();

            let outLabelText = `Out${i+1}`;
            let outValText = '0 dBm';

            if (node.type === 'OLT') {
                outValText = `${node.value || 0} dBm`;
            } else if (node.type === 'FBT') {
                let parts = (node.value || '50:50').split(':');
                let pct = (i === 0) ? parts[0] : parts[1];
                outLabelText = `Out ${pct}%`;
                outValText = (i === 0 ? `${node.out1Val || 0}` : `${node.out2Val || 0}`) + ' dBm';
            } else if (node.type === 'PLC') {
                outLabelText = `Out${i+1}`;
                outValText = `${node.outputVal || 0} dBm`;
            }
            
            ctx.fillStyle = canvasThemeMode === 'light' ? '#16a34a' : '#22c55e';
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(`${outLabelText}: ${outValText}`, oPos.x - 16, oPos.y + 5);
            ctx.textAlign = 'left';
        }
    });

    ctx.restore();

    const link = document.createElement('a');
    link.download = `${site.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_network_30mp.png`;
    link.href = tempCanvas.toDataURL('image/png', 1.0);
    link.click();
}

function fetchNodeInputFromConnection(nodeId) {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site || !site.connections) return;

    let conn = site.connections.find(c => c.toNode === nodeId);
    if (!conn) {
        alert('Komponen ini belum terhubung dengan garis ke perangkat sebelumnya!');
        return;
    }

    let sourceNode = site.nodes.find(n => n.id === conn.fromNode);
    let targetNode = site.nodes.find(n => n.id === nodeId);
    if (!sourceNode || !targetNode) return;

    let sourceVal = 0;
    if (sourceNode.type === 'OLT') {
        sourceVal = parseFloat(sourceNode.value) || 0;
    } else if (sourceNode.type === 'PLC') {
        sourceVal = parseFloat(sourceNode.outputVal) || 0;
    } else if (sourceNode.type === 'FBT') {
        sourceVal = (conn.fromPort === 0) ? (parseFloat(sourceNode.out1Val) || 0) : (parseFloat(sourceNode.out2Val) || 0);
    }

    targetNode.inputVal = sourceVal;
    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    redrawInteractiveCanvas();
    renderSiteTree();
}

function calculateNodeOutputs(nodeId) {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;
    let node = site.nodes.find(n => n.id === nodeId);
    if (!node) return;

    if (node.type === 'PLC') {
        let inputPower = parseFloat(node.inputVal) || 0;
        let plcLossMap = { '1:2': 3.7, '1:4': 7.2, '1:8': 10.5, '1:16': 13.8, '1:32': 17.0, '1:64': 20.5 };
        let loss = plcLossMap[node.value || '1:8'] || 10.5;
        node.outputVal = (inputPower - loss).toFixed(2);
    } else if (node.type === 'FBT') {
        let inputPower = parseFloat(node.inputVal) || 0;
        let rParts = (node.value || '50:50').split(':');
        let r1 = parseInt(rParts[0]) || 50;
        let r2 = parseInt(rParts[1]) || 50;
        let loss1 = -10 * Math.log10(r1 / 100);
        let loss2 = -10 * Math.log10(r2 / 100);
        node.out1Val = (inputPower - loss1).toFixed(2);
        node.out2Val = (inputPower - loss2).toFixed(2);
    }

    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    redrawInteractiveCanvas();
    renderSiteTree();
}

function deleteNodeDirect(nodeId) {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;
    if (confirm('Hapus komponen ini dari canvas?')) {
        site.nodes = site.nodes.filter(n => n.id !== nodeId);
        site.connections = site.connections.filter(c => c.fromNode !== nodeId && c.toNode !== nodeId);
        localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
        redrawInteractiveCanvas();
        renderSiteTree();
    }
}

function addCanvasNode(type) {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;

    let defaultName = type === 'OLT' ? 'OLT Core 1' : type === 'PLC' ? 'PLC Splitter 1:8' : 'FBT Ratio 50:50';
    let defaultWidth = 360;
    let defaultHeight = 160;
    if (type === 'OLT') defaultHeight = 100;
    if (type === 'PLC') defaultHeight = 280;

    let newNode = {
        id: 'node_' + Date.now(),
        type: type,
        name: defaultName,
        x: (-canvasPanX + 250 + (site.nodes.length * 35)) / canvasScale,
        y: (-canvasPanY + 200) / canvasScale,
        w: defaultWidth,
        h: defaultHeight,
        value: type === 'OLT' ? '0' : type === 'PLC' ? '1:8' : '50:50',
        inputVal: 0,
        outputVal: 0,
        out1Val: 0,
        out2Val: 0
    };

    site.nodes.push(newNode);
    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    redrawInteractiveCanvas();
}

function clearCanvasNodes() {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;
    if (confirm('Reset dan hapus seluruh node & koneksi di canvas ini?')) {
        site.nodes = [];
        site.connections = [];
        localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
        redrawInteractiveCanvas();
    }
}

function zoomCanvas(delta) {
    canvasScale = Math.max(0.4, Math.min(2.5, canvasScale + delta));
    redrawInteractiveCanvas();
}

let canvasButtons = [];

function redrawInteractiveCanvas() {
    const canvas = document.getElementById('interactiveCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    canvasButtons = [];

    ctx.fillStyle = (canvasThemeMode === 'light') ? '#f8fafc' : '#050507';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    ctx.scale(canvasScale, canvasScale);
    ctx.translate(canvasPanX, canvasPanY);

    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) {
        ctx.restore();
        return;
    }

    if (site.connections) {
        site.connections.forEach(conn => {
            let fromNode = site.nodes.find(n => n.id === conn.fromNode);
            let toNode = site.nodes.find(n => n.id === conn.toNode);
            if (fromNode && toNode) {
                let fPos = getNodePortPos(fromNode, 'out', conn.fromPort);
                let tPos = getNodePortPos(toNode, 'in', 0);

                ctx.strokeStyle = canvasThemeMode === 'light' ? '#16a34a' : '#22c55e';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.moveTo(fPos.x, fPos.y);
                ctx.bezierCurveTo(fPos.x + 80, fPos.y, tPos.x - 80, tPos.y, tPos.x, tPos.y);
                ctx.stroke();
            }
        });
    }

    if (connectingSource) {
        let fNode = site.nodes.find(n => n.id === connectingSource.nodeId);
        if (fNode) {
            let fPos = getNodePortPos(fNode, 'out', connectingSource.portIndex);
            let targetX = (currentMouseX - canvasPanX) / canvasScale;
            let targetY = (currentMouseY - canvasPanY) / canvasScale;

            ctx.strokeStyle = '#ef4444';
            ctx.lineWidth = 3;
            ctx.setLineDash([5, 5]);
            ctx.beginPath();
            ctx.moveTo(fPos.x, fPos.y);
            ctx.lineTo(targetX, targetY);
            ctx.stroke();
            ctx.setLineDash([]);
        }
    }

    site.nodes.forEach(node => {
        if (node.type === 'OLT') {
            node.h = 100;
        } else if (node.type === 'PLC') {
            let count = getOutputPortsCount(node);
            node.h = Math.max(260, count * 32 + 100);
        } else if (node.type === 'FBT') {
            node.h = 180;
        }

        ctx.fillStyle = canvasThemeMode === 'light' ? '#ffffff' : '#18181b';
        ctx.strokeStyle = canvasThemeMode === 'light' ? '#cbd5e1' : '#27272a';
        ctx.lineWidth = 2;
        ctx.fillRect(node.x, node.y, node.w, node.h);
        ctx.strokeRect(node.x, node.y, node.w, node.h);

        ctx.fillStyle = canvasThemeMode === 'light' ? '#16a34a' : '#22c55e';
        ctx.font = 'bold 14px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(node.type + ' : ' + node.name, node.x + 16, node.y + 28);

        let delBtnX = node.x + node.w - 76;
        let editBtnX = node.x + node.w - 132;
        let actionBtnY = node.y + 12;

        ctx.fillStyle = '#ef4444';
        ctx.fillRect(delBtnX, actionBtnY, 62, 28);
        ctx.strokeStyle = '#dc2626';
        ctx.strokeRect(delBtnX, actionBtnY, 62, 28);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText('🗑 Hapus', delBtnX + 8, actionBtnY + 18);
        canvasButtons.push({ x: delBtnX, y: actionBtnY, w: 62, h: 28, action: 'deleteNode', nodeId: node.id });

        ctx.fillStyle = canvasThemeMode === 'light' ? '#e2e8f0' : '#27272a';
        ctx.fillRect(editBtnX, actionBtnY, 50, 28);
        ctx.strokeStyle = canvasThemeMode === 'light' ? '#cbd5e1' : '#3f3f46';
        ctx.strokeRect(editBtnX, actionBtnY, 50, 28);
        ctx.fillStyle = canvasThemeMode === 'light' ? '#0f172a' : '#f8fafc';
        ctx.font = 'bold 11px sans-serif';
        ctx.fillText('✎ Edit', editBtnX + 8, actionBtnY + 18);
        canvasButtons.push({ x: editBtnX, y: actionBtnY, w: 50, h: 28, action: 'editNode', nodeId: node.id });

        // Khusus OLT tidak ada input port & tombol ambil input
        if (node.type !== 'OLT') {
            let inPos = getNodePortPos(node, 'in', 0);
            ctx.fillStyle = '#3b82f6';
            ctx.beginPath();
            ctx.arc(inPos.x, inPos.y, 9, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2;
            ctx.stroke();

            ctx.fillStyle = '#3b82f6';
            ctx.font = 'bold 12px sans-serif';
            ctx.fillText(`In: ${node.inputVal || 0} dBm`, inPos.x + 16, inPos.y + 5);

            let btnW = 95, btnH = 26;
            let btnX = inPos.x + 115;
            let btnY = inPos.y - 13;
            ctx.fillStyle = '#2563eb';
            ctx.fillRect(btnX, btnY, btnW, btnH);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 11px sans-serif';
            ctx.fillText('Ambil Input', btnX + 14, btnY + 17);

            canvasButtons.push({ x: btnX, y: btnY, w: btnW, h: btnH, action: 'fetchInput', nodeId: node.id });

            let calcBtnW = 105, calcBtnH = 26;
            let calcBtnX = btnX;
            let calcBtnY = btnY + 32;
            ctx.fillStyle = '#16a34a';
            ctx.fillRect(calcBtnX, calcBtnY, calcBtnW, calcBtnH);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 11px sans-serif';
            ctx.fillText('Hitung Output', calcBtnX + 13, calcBtnY + 17);

            canvasButtons.push({ x: calcBtnX, y: calcBtnY, w: calcBtnW, h: calcBtnH, action: 'calcAllOutputs', nodeId: node.id });
        }

        let outPorts = getOutputPortsCount(node);
        for (let i = 0; i < outPorts; i++) {
            let oPos = getNodePortPos(node, 'out', i);
            ctx.fillStyle = canvasThemeMode === 'light' ? '#16a34a' : '#22c55e';
            ctx.beginPath();
            ctx.arc(oPos.x, oPos.y, 9, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.stroke();

            let outLabelText = `Out${i+1}`;
            let outValText = '0 dBm';

            if (node.type === 'OLT') {
                outValText = `${node.value || 0} dBm`;
            } else if (node.type === 'FBT') {
                let parts = (node.value || '50:50').split(':');
                let pct = (i === 0) ? parts[0] : parts[1];
                outLabelText = `Out ${pct}%`;
                outValText = (i === 0 ? `${node.out1Val || 0}` : `${node.out2Val || 0}`) + ' dBm';
            } else if (node.type === 'PLC') {
                outLabelText = `Out${i+1}`;
                outValText = `${node.outputVal || 0} dBm`;
            }
            
            ctx.fillStyle = canvasThemeMode === 'light' ? '#16a34a' : '#22c55e';
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(`${outLabelText}: ${outValText}`, oPos.x - 16, oPos.y + 5);
            ctx.textAlign = 'left';
        }
    });

    ctx.restore();
}

function getNodePortPos(node, type, index) {
    if (type === 'in') {
        return { x: node.x, y: node.y + node.h / 2 };
    } else {
        let count = getOutputPortsCount(node);
        let topPadding = node.type === 'OLT' ? 45 : 65;
        let bottomPadding = 30;
        let availableHeight = node.h - (topPadding + bottomPadding);
        let spacing = count > 1 ? availableHeight / (count - 1) : 0;
        return { x: node.x + node.w, y: node.y + topPadding + (count > 1 ? spacing * index : availableHeight / 2) };
    }
}

function getOutputPortsCount(node) {
    if (node.type === 'OLT') return 1;
    if (node.type === 'FBT') return 2;
    if (node.type === 'PLC') {
        let p = parseInt((node.value || '1:8').split(':')[1]) || 8;
        return Math.min(p, 32);
    }
    return 1;
}

let draggedNode = null;
let dragOffsetX = 0;
let dragOffsetY = 0;
let initialPinchDistance = null;

function initCanvasEvents() {
    const container = document.getElementById('canvasWorkspace');
    const canvas = document.getElementById('interactiveCanvas');
    if (!canvas || !container) return;

    canvas.addEventListener('wheel', (e) => {
        e.preventDefault();
        let delta = e.deltaY < 0 ? 0.1 : -0.1;
        zoomCanvas(delta);
    }, { passive: false });

    canvas.addEventListener('touchstart', (e) => {
        if (e.touches.length === 2) {
            initialPinchDistance = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY
            );
        }
    });

    canvas.addEventListener('touchmove', (e) => {
        if (e.touches.length === 2 && initialPinchDistance) {
            e.preventDefault();
            let currentDistance = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY
            );
            let diff = currentDistance - initialPinchDistance;
            if (Math.abs(diff) > 10) {
                zoomCanvas(diff > 0 ? 0.05 : -0.05);
                initialPinchDistance = currentDistance;
            }
        }
    });

    canvas.addEventListener('touchend', () => {
        initialPinchDistance = null;
    });

    canvas.addEventListener('mousedown', (e) => {
        const rect = canvas.getBoundingClientRect();
        const mouseX = (e.clientX - rect.left) * (canvas.width / rect.width) / canvasScale - canvasPanX / canvasScale;
        const mouseY = (e.clientY - rect.top) * (canvas.height / rect.height) / canvasScale - canvasPanY / canvasScale;

        const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
        if (!site) return;

        for (let btn of canvasButtons) {
            if (mouseX >= btn.x && mouseX <= btn.x + btn.w && mouseY >= btn.y && mouseY <= btn.y + btn.h) {
                if (btn.action === 'fetchInput') {
                    fetchNodeInputFromConnection(btn.nodeId);
                } else if (btn.action === 'calcAllOutputs') {
                    calculateNodeOutputs(btn.nodeId);
                } else if (btn.action === 'editNode') {
                    openEditNodeModal(btn.nodeId);
                } else if (btn.action === 'deleteNode') {
                    deleteNodeDirect(btn.nodeId);
                }
                return;
            }
        }

        if (currentCanvasMode === 'connect') {
            for (let node of site.nodes) {
                let count = getOutputPortsCount(node);
                for (let i = 0; i < count; i++) {
                    let pos = getNodePortPos(node, 'out', i);
                    let dist = Math.hypot(mouseX - pos.x, mouseY - pos.y);
                    if (dist < 22) {
                        connectingSource = { nodeId: node.id, portIndex: i };
                        return;
                    }
                }
            }
            return;
        }

        if (currentCanvasMode === 'pan') {
            for (let i = site.nodes.length - 1; i >= 0; i--) {
                let n = site.nodes[i];
                if (mouseX >= n.x && mouseX <= n.x + n.w && mouseY >= n.y && mouseY <= n.y + n.h) {
                    draggedNode = n;
                    dragOffsetX = mouseX - n.x;
                    dragOffsetY = mouseY - n.y;
                    return;
                }
            }

            isPanning = true;
            startPanX = e.clientX;
            startPanY = e.clientY;
        }
    });

    canvas.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        currentMouseX = e.clientX - rect.left;
        currentMouseY = e.clientY - rect.top;

        if (currentCanvasMode === 'connect' && connectingSource) {
            redrawInteractiveCanvas();
        } else if (draggedNode && currentCanvasMode === 'pan') {
            const mouseX = (e.clientX - rect.left) * (canvas.width / rect.width) / canvasScale - canvasPanX / canvasScale;
            const mouseY = (e.clientY - rect.top) * (canvas.height / rect.height) / canvasScale - canvasPanY / canvasScale;
            draggedNode.x = mouseX - dragOffsetX;
            draggedNode.y = mouseY - dragOffsetY;
            redrawInteractiveCanvas();
        } else if (isPanning && currentCanvasMode === 'pan') {
            canvasPanX += (e.clientX - startPanX) * 0.8;
            canvasPanY += (e.clientY - startPanY) * 0.8;
            startPanX = e.clientX;
            startPanY = e.clientY;
            redrawInteractiveCanvas();
        }
    });

    canvas.addEventListener('mouseup', (e) => {
        if (currentCanvasMode === 'connect' && connectingSource) {
            const rect = canvas.getBoundingClientRect();
            const mouseX = (e.clientX - rect.left) * (canvas.width / rect.width) / canvasScale - canvasPanX / canvasScale;
            const mouseY = (e.clientY - rect.top) * (canvas.height / rect.height) / canvasScale - canvasPanY / canvasScale;

            const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
            if (site) {
                for (let node of site.nodes) {
                    let pos = getNodePortPos(node, 'in', 0);
                    let dist = Math.hypot(mouseX - pos.x, mouseY - pos.y);
                    if (dist < 25) {
                        if (!site.connections) site.connections = [];
                        site.connections = site.connections.filter(c => c.toNode !== node.id);
                        site.connections.push({
                            fromNode: connectingSource.nodeId,
                            fromPort: connectingSource.portIndex,
                            toNode: node.id,
                            toPort: 0
                        });
                        break;
                    }
                }
            }
            connectingSource = null;
            localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
            redrawInteractiveCanvas();
        }

        if (draggedNode) {
            draggedNode = null;
            localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
        }
        isPanning = false;
    });
}

function openEditNodeModal(nodeId) {
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;
    const node = site.nodes.find(n => n.id === nodeId);
    if (!node) return;

    document.getElementById('editNodeCanvasId').value = node.id;
    document.getElementById('editNodeNameLabel').value = node.name;
    document.getElementById('editNodeTitle').innerHTML = `<i class="fa-solid fa-pen"></i> Edit ${node.type} - ${node.name}`;

    document.getElementById('editGroupOlt').style.display = 'none';
    document.getElementById('editGroupPlc').style.display = 'none';
    document.getElementById('editGroupFbt').style.display = 'none';

    if (node.type === 'OLT') {
        document.getElementById('editGroupOlt').style.display = 'block';
        document.getElementById('editOltValue').value = node.value || 0;
    } else if (node.type === 'PLC') {
        document.getElementById('editGroupPlc').style.display = 'block';
        document.getElementById('editPlcRatioType').value = node.value || '1:8';
        document.getElementById('editPlcInputVal').value = node.inputVal || 0;
        document.getElementById('editPlcOutputVal').value = node.outputVal || 0;
    } else if (node.type === 'FBT') {
        document.getElementById('editGroupFbt').style.display = 'block';
        document.getElementById('editFbtRatioType').value = node.value || '50:50';
        document.getElementById('editFbtInputVal').value = node.inputVal || 0;
        document.getElementById('editFbtOut1Val').value = node.out1Val || 0;
        document.getElementById('editFbtOut2Val').value = node.out2Val || 0;
    }

    openModal('editNodeModal');
}

function saveEditedCanvasNode() {
    const nodeId = document.getElementById('editNodeCanvasId').value;
    const site = siteTreeList.find(s => s.id === activeCanvasSiteId);
    if (!site) return;
    const node = site.nodes.find(n => n.id === nodeId);
    if (!node) return;

    node.name = document.getElementById('editNodeNameLabel').value.trim() || node.type;

    if (node.type === 'OLT') {
        node.value = parseFloat(document.getElementById('editOltValue').value) || 0;
    } else if (node.type === 'PLC') {
        node.value = document.getElementById('editPlcRatioType').value;
        node.inputVal = parseFloat(document.getElementById('editPlcInputVal').value) || 0;
        node.outputVal = parseFloat(document.getElementById('editPlcOutputVal').value) || 0;
    } else if (node.type === 'FBT') {
        node.value = document.getElementById('editFbtRatioType').value;
        node.inputVal = parseFloat(document.getElementById('editFbtInputVal').value) || 0;
        node.out1Val = parseFloat(document.getElementById('editFbtOut1Val').value) || 0;
        node.out2Val = parseFloat(document.getElementById('editFbtOut2Val').value) || 0;
    }

    localStorage.setItem('bantani_site_tree', JSON.stringify(siteTreeList));
    closeModal('editNodeModal');
    redrawInteractiveCanvas();
    renderSiteTree();
}

function deleteCanvasNodePrompt() {
    deleteNodeDirect(document.getElementById('editNodeCanvasId').value);
    closeModal('editNodeModal');
}

function useAsInput(val) {
    document.getElementById('laserInput').value = val;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function copyResult(val) {
    navigator.clipboard.writeText(val).then(() => {
        alert('Berhasil menyalin: ' + val + ' dBm');
    }).catch(err => {
        console.error('Gagal menyalin text: ', err);
    });
}

function resetForm() {
    document.getElementById('laserInput').value = '0.00';
    document.getElementById('additionalLoss').value = '0.00';
    selectPassive(0);
    selectRatio(0);
    document.getElementById('resultsContainer').style.display = 'none';
}

init();