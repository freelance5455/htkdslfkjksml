const arena = document.getElementById("arena");
const scoreEl = document.getElementById("score");
const timeEl = document.getElementById("time");
const bestEl = document.getElementById("best");
const comboText = document.getElementById("comboText");
const startOverlay = document.getElementById("startOverlay");
const endOverlay = document.getElementById("endOverlay");
const startBtn = document.getElementById("startBtn");
const restartBtn = document.getElementById("restartBtn");
const finalScoreEl = document.getElementById("finalScore");
const finalComboEl = document.getElementById("finalCombo");
const finalRankEl = document.getElementById("finalRank");
const soundToggle = document.getElementById("soundToggle");
const diffBtns = document.querySelectorAll(".diff-btn");

// Ball Skin Selector Elements
const openSkinsBtn = document.getElementById("openSkinsBtn");
const changeBallBtn = document.getElementById("changeBallBtn");
const selectedBallCard = document.getElementById("selectedBallCard");
const endSkinsBtn = document.getElementById("endSkinsBtn");
const skinsModal = document.getElementById("skinsModal");
const closeSkinsBtn = document.getElementById("closeSkinsBtn");
const applySkinBtn = document.getElementById("applySkinBtn");
const skinTabs = document.getElementById("skinTabs");
const skinsContainer = document.getElementById("skinsContainer");
const selectedBallPreview = document.getElementById("selectedBallPreview");
const selectedBallName = document.getElementById("selectedBallName");

// Ball Sections & Skins Library
const BALL_SECTIONS = [
  {
    id: "neon",
    title: "⚡ Neon Glow Balls",
    balls: [
      {
        id: "cyan_pulse",
        name: "Cyan Pulse",
        bg: "radial-gradient(circle at 30% 30%, #8cfbff, #00b8d4)",
        glow: "0 0 20px rgba(0, 229, 255, 0.85)",
        border: "2px solid #b2fbff",
        textColor: "#08121a",
        floatColor: "#00e5ff",
        emoji: ""
      },
      {
        id: "cyber_pink",
        name: "Cyber Pink",
        bg: "radial-gradient(circle at 30% 30%, #ff99e6, #ff007f)",
        glow: "0 0 20px rgba(255, 0, 127, 0.85)",
        border: "2px solid #ffb3ec",
        textColor: "#fff",
        floatColor: "#ff4da6",
        emoji: ""
      },
      {
        id: "toxic_green",
        name: "Toxic Lime",
        bg: "radial-gradient(circle at 30% 30%, #c8ff70, #22c55e)",
        glow: "0 0 20px rgba(34, 197, 94, 0.85)",
        border: "2px solid #d9ffb3",
        textColor: "#061b0c",
        floatColor: "#4ade80",
        emoji: ""
      },
      {
        id: "crimson_laser",
        name: "Crimson Red",
        bg: "radial-gradient(circle at 30% 30%, #ff8a8a, #e50914)",
        glow: "0 0 20px rgba(229, 9, 20, 0.88)",
        border: "2px solid #ffb3b3",
        textColor: "#fff",
        floatColor: "#ff4d5a",
        emoji: ""
      },
      {
        id: "solar_orange",
        name: "Solar Flare",
        bg: "radial-gradient(circle at 30% 30%, #ffd280, #ff6b00)",
        glow: "0 0 20px rgba(255, 107, 0, 0.88)",
        border: "2px solid #ffe0a3",
        textColor: "#1f0c00",
        floatColor: "#ff9233",
        emoji: ""
      },
      {
        id: "electric_violet",
        name: "Neon Violet",
        bg: "radial-gradient(circle at 30% 30%, #d8b4fe, #7c3aed)",
        glow: "0 0 20px rgba(124, 58, 237, 0.9)",
        border: "2px solid #e9d5ff",
        textColor: "#fff",
        floatColor: "#c084fc",
        emoji: ""
      }
    ]
  },
  {
    id: "energy",
    title: "🔥 Elemental & Energy Orbs",
    balls: [
      {
        id: "inferno_orb",
        name: "Inferno Fire",
        bg: "radial-gradient(circle at 35% 35%, #fff099, #ff5e00 55%, #990000 100%)",
        glow: "0 0 24px rgba(255, 94, 0, 0.95)",
        border: "2px solid #ffd166",
        textColor: "#fff",
        floatColor: "#ff7b29",
        emoji: "🔥"
      },
      {
        id: "thunder_orb",
        name: "Thunder Bolt",
        bg: "radial-gradient(circle at 30% 30%, #fff9c4, #facc15 55%, #b45309 100%)",
        glow: "0 0 24px rgba(250, 204, 21, 0.95)",
        border: "2px solid #fef08a",
        textColor: "#1c1917",
        floatColor: "#fde047",
        emoji: "⚡"
      },
      {
        id: "frost_crystal",
        name: "Frost Ice",
        bg: "radial-gradient(circle at 30% 30%, #ffffff, #7dd3fc 55%, #0284c7 100%)",
        glow: "0 0 22px rgba(125, 211, 252, 0.95)",
        border: "2px solid #e0f2fe",
        textColor: "#082f49",
        floatColor: "#7dd3fc",
        emoji: "❄️"
      },
      {
        id: "galaxy_void",
        name: "Galaxy Void",
        bg: "radial-gradient(circle at 30% 30%, #a855f7, #312e81 60%, #09071a 100%)",
        glow: "0 0 24px rgba(168, 85, 247, 0.95)",
        border: "2px solid #c084fc",
        textColor: "#fff",
        floatColor: "#c084fc",
        emoji: "🌌"
      },
      {
        id: "prism_rainbow",
        name: "Rainbow Prism",
        bg: "conic-gradient(from 0deg, #ff3d5a, #ffbe0b, #00f5d4, #3a86ff, #8338ec, #ff3d5a)",
        glow: "0 0 22px rgba(255, 255, 255, 0.75)",
        border: "2px solid #ffffff",
        textColor: "#fff",
        floatColor: "#ffffff",
        emoji: "✨"
      },
      {
        id: "diamond_core",
        name: "Diamond Core",
        bg: "radial-gradient(circle at 30% 30%, #ffffff, #67e8f9 55%, #0e7490 100%)",
        glow: "0 0 22px rgba(103, 232, 249, 0.95)",
        border: "2px solid #cffafe",
        textColor: "#083344",
        floatColor: "#67e8f9",
        emoji: "💎"
      }
    ]
  },
  {
    id: "aura",
    title: "🌀 Power Aura Spheres",
    balls: [
      {
        id: "blue_rasen",
        name: "Wind Spiral",
        bg: "radial-gradient(circle at center, #ffffff 10%, #38bdf8 45%, #1d4ed8 100%)",
        glow: "0 0 26px rgba(56, 189, 248, 0.95)",
        border: "2px solid #bae6fd",
        textColor: "#082f49",
        floatColor: "#38bdf8",
        emoji: "🌀"
      },
      {
        id: "cursed_purple",
        name: "Hollow Purple",
        bg: "radial-gradient(circle at center, #f5d0fe 10%, #9333ea 55%, #3b0764 100%)",
        glow: "0 0 28px rgba(192, 38, 211, 0.95)",
        border: "2px solid #f0abfc",
        textColor: "#fff",
        floatColor: "#e879f9",
        emoji: "🟣"
      },
      {
        id: "shadow_monarch",
        name: "Shadow Core",
        bg: "radial-gradient(circle at center, #60a5fa 12%, #1e1b4b 60%, #020617 100%)",
        glow: "0 0 26px rgba(59, 130, 246, 0.95)",
        border: "2px solid #60a5fa",
        textColor: "#fff",
        floatColor: "#60a5fa",
        emoji: "👁️"
      },
      {
        id: "dragon_soul",
        name: "Dragon Sphere",
        bg: "radial-gradient(circle at 30% 30%, #fef08a, #f97316 60%, #c2410c 100%)",
        glow: "0 0 24px rgba(249, 115, 22, 0.95)",
        border: "2px solid #fed7aa",
        textColor: "#fff",
        floatColor: "#fb923c",
        emoji: "🐉"
      },
      {
        id: "blood_moon",
        name: "Blood Moon",
        bg: "radial-gradient(circle at 35% 35%, #fca5a5, #b91c1c 58%, #450a0a 100%)",
        glow: "0 0 25px rgba(220, 38, 38, 0.95)",
        border: "2px solid #f87171",
        textColor: "#fff",
        floatColor: "#f87171",
        emoji: "🔴"
      },
      {
        id: "emerald_force",
        name: "Emerald Aura",
        bg: "radial-gradient(circle at center, #d1fae5 12%, #10b981 55%, #064e3b 100%)",
        glow: "0 0 24px rgba(16, 185, 129, 0.95)",
        border: "2px solid #6ee7b7",
        textColor: "#022c22",
        floatColor: "#34d399",
        emoji: "❇️"
      }
    ]
  },
  {
    id: "sports",
    title: "⚽ Sports & Gaming Balls",
    balls: [
      {
        id: "football",
        name: "Football",
        bg: "radial-gradient(circle at 30% 30%, #ffffff, #cbd5e1)",
        glow: "0 0 18px rgba(255, 255, 255, 0.7)",
        border: "2px solid #f8fafc",
        textColor: "#000",
        floatColor: "#ffffff",
        emoji: "⚽"
      },
      {
        id: "basketball",
        name: "Basketball",
        bg: "radial-gradient(circle at 30% 30%, #fdba74, #ea580c)",
        glow: "0 0 18px rgba(234, 88, 12, 0.8)",
        border: "2px solid #fed7aa",
        textColor: "#fff",
        floatColor: "#fb923c",
        emoji: "🏀"
      },
      {
        id: "bullseye",
        name: "Aim Target",
        bg: "radial-gradient(circle at 30% 30%, #fecaca, #dc2626)",
        glow: "0 0 20px rgba(220, 38, 38, 0.85)",
        border: "2px solid #fca5a5",
        textColor: "#fff",
        floatColor: "#f87171",
        emoji: "🎯"
      },
      {
        id: "skull_pro",
        name: "Pro Skull",
        bg: "radial-gradient(circle at 30% 30%, #475569, #0f172a)",
        glow: "0 0 20px rgba(148, 163, 184, 0.8)",
        border: "2px solid #94a3b8",
        textColor: "#fff",
        floatColor: "#e2e8f0",
        emoji: "💀"
      },
      {
        id: "alien_orb",
        name: "Arcade Alien",
        bg: "radial-gradient(circle at 30% 30%, #a78bfa, #4c1d95)",
        glow: "0 0 20px rgba(139, 92, 246, 0.85)",
        border: "2px solid #c4b5fd",
        textColor: "#fff",
        floatColor: "#a78bfa",
        emoji: "👾"
      },
      {
        id: "bomb_ball",
        name: "Nitro Bomb",
        bg: "radial-gradient(circle at 30% 30%, #52525b, #18181b)",
        glow: "0 0 20px rgba(255, 107, 43, 0.85)",
        border: "2px solid #ff6b2b",
        textColor: "#fff",
        floatColor: "#ff6b2b",
        emoji: "💣"
      }
    ]
  }
];

const ALL_BALLS = BALL_SECTIONS.flatMap((s) => s.balls);

let score = 0;
let timeLeft = 30;
let combo = 0;
let maxCombo = 0;
let bestScore = 0;
let timerId = null;
let spawnTimeout = null;
let running = false;
let soundOn = true;
let difficulty = "normal";
let activeTab = "all";
let selectedBallId = "cyan_pulse";
let audioCtx = null;

try {
  bestScore = parseInt(localStorage.getItem("neon_reflex_best") || "0", 10);
  if (isNaN(bestScore)) bestScore = 0;
  const savedBall = localStorage.getItem("neon_reflex_ball_skin");
  if (savedBall && ALL_BALLS.some((b) => b.id === savedBall)) {
    selectedBallId = savedBall;
  }
} catch (e) {
  bestScore = 0;
}
bestEl.textContent = bestScore;

function getSelectedBall() {
  return ALL_BALLS.find((b) => b.id === selectedBallId) || ALL_BALLS[0];
}

function applyBallStyle(el, ball, labelText = "+1") {
  el.style.background = ball.bg;
  el.style.boxShadow = ball.glow;
  el.style.border = ball.border;
  el.style.color = ball.textColor;
  if (ball.emoji) {
    el.innerHTML = `<span class="ball-emoji">${ball.emoji}</span>`;
  } else {
    el.textContent = labelText;
  }
}

function updateSelectedBallPreview() {
  const ball = getSelectedBall();
  selectedBallName.textContent = ball.name;
  applyBallStyle(selectedBallPreview, ball, "+1");
}

function renderSkinSections() {
  skinsContainer.innerHTML = "";
  const sectionsToShow = activeTab === "all"
    ? BALL_SECTIONS
    : BALL_SECTIONS.filter((s) => s.id === activeTab);

  sectionsToShow.forEach((section) => {
    const secEl = document.createElement("div");

    const titleEl = document.createElement("div");
    titleEl.className = "skin-section-title";
    titleEl.innerHTML = `<span>${section.title}</span><span>${section.balls.length}</span>`;
    secEl.appendChild(titleEl);

    const gridEl = document.createElement("div");
    gridEl.className = "skin-grid";

    section.balls.forEach((ball) => {
      const card = document.createElement("div");
      card.className = `skin-card ${ball.id === selectedBallId ? "selected" : ""}`;

      const orb = document.createElement("div");
      orb.className = "skin-orb";
      applyBallStyle(orb, ball, "+1");

      const name = document.createElement("div");
      name.className = "skin-name";
      name.textContent = ball.name;

      card.appendChild(orb);
      card.appendChild(name);

      card.addEventListener("click", () => {
        selectedBallId = ball.id;
        try {
          localStorage.setItem("neon_reflex_ball_skin", selectedBallId);
        } catch (e) {}
        playBeep(620, 0.06);
        updateSelectedBallPreview();
        renderSkinSections();
      });

      gridEl.appendChild(card);
    });

    secEl.appendChild(gridEl);
    skinsContainer.appendChild(secEl);
  });
}

function openSkinsModal() {
  if (running) {
    // Pause/stop active round cleanly so user can switch balls
    running = false;
    clearInterval(timerId);
    clearTimeout(spawnTimeout);
    clearTargets();
    startOverlay.classList.remove("hidden");
  }
  renderSkinSections();
  skinsModal.classList.remove("hidden");
}

function closeSkinsModal() {
  skinsModal.classList.add("hidden");
}

openSkinsBtn.addEventListener("click", openSkinsModal);
changeBallBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  openSkinsModal();
});
selectedBallCard.addEventListener("click", openSkinsModal);
endSkinsBtn.addEventListener("click", openSkinsModal);
closeSkinsBtn.addEventListener("click", closeSkinsModal);
applySkinBtn.addEventListener("click", closeSkinsModal);
skinsModal.addEventListener("click", (e) => {
  if (e.target === skinsModal) closeSkinsModal();
});

skinTabs.addEventListener("click", (e) => {
  const btn = e.target.closest(".tab-btn");
  if (!btn) return;
  skinTabs.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  activeTab = btn.dataset.tab;
  renderSkinSections();
});

function playBeep(freq, duration) {
  if (!soundOn) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    if (!audioCtx) audioCtx = new AudioContextClass();
    if (audioCtx.state === "suspended") audioCtx.resume();

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
    gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);

    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch (e) {}
}

soundToggle.addEventListener("click", () => {
  soundOn = !soundOn;
  soundToggle.textContent = soundOn ? "🔊" : "🔇";
});

diffBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    diffBtns.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    difficulty = btn.dataset.speed;
  });
});

function clearTargets() {
  arena.querySelectorAll(".target, .float-score").forEach((el) => el.remove());
}

function showFloatText(x, y, text, color) {
  const el = document.createElement("div");
  el.className = "float-score";
  el.textContent = text;
  el.style.left = `${x}px`;
  el.style.top = `${y}px`;
  el.style.color = color;
  arena.appendChild(el);
  setTimeout(() => el.remove(), 550);
}

function spawnTarget() {
  if (!running) return;
  clearTargets();

  const rect = arena.getBoundingClientRect();
  const isGold = Math.random() < 0.22;
  const ball = getSelectedBall();

  let size = 64;
  if (difficulty === "pro") size = isGold ? 48 : 54;
  else if (difficulty === "insane") size = isGold ? 44 : 48;
  else size = isGold ? 56 : 64;

  const maxX = Math.max(10, rect.width - size - 16);
  const maxY = Math.max(10, rect.height - size - 16);
  const x = Math.floor(Math.random() * maxX) + 8;
  const y = Math.floor(Math.random() * maxY) + 8;

  const target = document.createElement("div");
  target.className = `target ${isGold ? "gold-bonus" : ""}`;
  target.style.width = `${size}px`;
  target.style.height = `${size}px`;
  target.style.left = `${x}px`;
  target.style.top = `${y}px`;

  if (isGold) {
    target.style.background = "radial-gradient(circle at 30% 30%, #fff3b0, #ffae00)";
    target.style.color = "#0b0d14";
    if (ball.emoji) {
      target.innerHTML = `<span class="ball-emoji">${ball.emoji}</span><span class="bonus-tag">+3</span>`;
    } else {
      target.textContent = "+3";
    }
  } else {
    applyBallStyle(target, ball, "+1");
  }

  const hitHandler = (e) => {
    e.stopPropagation();
    if (!running) return;

    const points = isGold ? 3 : 1;
    score += points;
    combo += 1;
    if (combo > maxCombo) maxCombo = combo;

    scoreEl.textContent = score;
    comboText.textContent = combo >= 3 ? `🔥 ${combo}x Combo Streak!` : "Nice hit!";

    playBeep(isGold ? 760 : 540, 0.08);
    try {
      if (navigator.vibrate) navigator.vibrate(15);
    } catch (err) {}

    showFloatText(x + size / 4, y, `+${points}`, isGold ? "#ffd166" : ball.floatColor);
    clearTimeout(spawnTimeout);
    spawnTarget();
  };

  target.addEventListener("pointerdown", hitHandler);
  arena.appendChild(target);

  let stayTime = 1400;
  if (difficulty === "pro") stayTime = 950;
  else if (difficulty === "insane") stayTime = 720;

  spawnTimeout = setTimeout(() => {
    if (!running) return;
    combo = 0;
    comboText.textContent = "Missed! Combo reset.";
    spawnTarget();
  }, stayTime);
}

arena.addEventListener("pointerdown", (e) => {
  if (!running) return;
  if (e.target === arena) {
    combo = 0;
    comboText.textContent = "Miss tap! Ball par tap karo.";
    playBeep(200, 0.07);
  }
});

function endGame() {
  running = false;
  clearInterval(timerId);
  clearTimeout(spawnTimeout);
  clearTargets();

  if (score > bestScore) {
    bestScore = score;
    bestEl.textContent = bestScore;
    try {
      localStorage.setItem("neon_reflex_best", String(bestScore));
    } catch (e) {}
  }

  finalScoreEl.textContent = score;
  finalComboEl.textContent = `${maxCombo}x`;

  if (score >= 50) finalRankEl.textContent = "God-Tier Reflex! ⚡";
  else if (score >= 28) finalRankEl.textContent = "Pro Gamer Speed! 🔥";
  else finalRankEl.textContent = "Good Warmup! 💪";

  endOverlay.classList.remove("hidden");
  playBeep(330, 0.22);
}

function startGame() {
  score = 0;
  timeLeft = 30;
  combo = 0;
  maxCombo = 0;
  running = true;

  scoreEl.textContent = "0";
  timeEl.textContent = "30s";
  comboText.textContent = "Go! Balls tap karo!";
  startOverlay.classList.add("hidden");
  endOverlay.classList.add("hidden");

  spawnTarget();

  clearInterval(timerId);
  timerId = setInterval(() => {
    timeLeft -= 1;
    timeEl.textContent = `${timeLeft}s`;
    if (timeLeft <= 0) {
      endGame();
    }
  }, 1000);
}

startBtn.addEventListener("click", startGame);
restartBtn.addEventListener("click", startGame);

// Init UI
updateSelectedBallPreview();
