STUDYGO ANDROID 1.0 — PROGETTO SORGENTE

Questa cartella è un progetto Android nativo con una WebView che apre la UI offline inclusa.
Funzioni: chat con risposte predefinite, quiz, flashcard, planner locale, tema chiaro/scuro.
Non è ancora una AI generativa e non richiede login o connessione.

PER CREARE UN APK:
1. Aprire questa cartella con Android Studio su un computer.
2. Attendere la sincronizzazione Gradle (richiede Internet per dipendenze).
3. Selezionare Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Il file risultante si trova in app/build/outputs/apk/debug/app-debug.apk.

ANTEPRIMA SU TELEFONO:
Aprire app/src/main/assets/index.html con un browser o un visualizzatore HTML locale.

NOTA: Questo ZIP contiene il codice sorgente, NON un APK già compilato.
