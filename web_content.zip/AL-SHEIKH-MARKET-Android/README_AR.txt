AL-SHEIKH MARKET - مشروع Android Studio

طريقة البناء:
1) فك ضغط الملف.
2) افتح Android Studio ثم Open واختر مجلد AL-SHEIKH-MARKET-Android.
3) انتظر Gradle Sync. يلزم اتصال إنترنت أول مرة لتنزيل Android Gradle Plugin والمكتبات.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد APK من خيار Locate بعد انتهاء البناء.

الكاميرا:
- أضفنا صلاحية CAMERA وماسح باركود أصلياً عبر ZXing.
- لإظهار زر المسح في واجهة HTML، اربط زرّاً بالدالة:
  AndroidScanner.scanBarcode()
- عند نجاح المسح تستقبل الصفحة الرقم عبر:
  window.onNativeBarcodeScanned = function(code) { ... }

ملاحظة مهمة:
ملف HTML المرفق هو نسخة المرحلة الأولى. هذا المشروع يغلّفه داخل تطبيق Android ويحفظ LocalStorage داخل WebView.
بعض الميزات المذكورة في المواصفات الكبيرة لم تنفذ بعد في HTML، ولا يعني تحويله إلى APK أنها أصبحت موجودة.
Gradle يحتاج إنترنت أول مرة لجلب المكتبات. بعد اكتمال البناء يمكن تشغيل التطبيق دون إنترنت.
