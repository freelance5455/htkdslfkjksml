
const $ = id => document.getElementById(id);

const KEY = "pembukuan_keuangan_v1";

function muatData() {
  try {
    const data = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

let dataTransaksi = muatData();

const kategori = {
  masuk: [
    "Penjualan",
    "Gaji",
    "Bonus",
    "Usaha",
    "Piutang Diterima",
    "Lainnya"
  ],
  keluar: [
    "Makanan",
    "Transportasi",
    "Belanja",
    "Tagihan",
    "Modal Usaha",
    "Cicilan",
    "Kesehatan",
    "Lainnya"
  ]
};

function rupiah(n) {
  return Number(n).toLocaleString("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  });
}

function aman(teks) {
  return String(teks ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

function tanggalLokal() {
  const d = new Date();
  return [
    d.getFullYear(),
    String(d.getMonth() + 1).padStart(2, "0"),
    String(d.getDate()).padStart(2, "0")
  ].join("-");
}

function simpanData() {
  try {
    localStorage.setItem(KEY, JSON.stringify(dataTransaksi));
    return true;
  } catch (e) {
    alert("Data gagal disimpan. Periksa ruang penyimpanan browser.");
    return false;
  }
}

function isiKategori() {
  const jenis = $("jenis").value;
  $("kategori").innerHTML = kategori[jenis]
    .map(k => `<option value="${aman(k)}">${aman(k)}</option>`)
    .join("");
}

$("jenis").addEventListener("change", isiKategori);

$("formTransaksi").addEventListener("submit", e => {
  e.preventDefault();

  const nominal = Number($("nominal").value);

  if (!Number.isSafeInteger(nominal) || nominal <= 0) {
    alert("Masukkan nominal rupiah yang valid.");
    return;
  }

  const item = {
    id: Date.now().toString() +
      Math.random().toString(36).slice(2, 7),
    jenis: $("jenis").value,
    tanggal: $("tanggal").value,
    kategori: $("kategori").value,
    nominal,
    keterangan: $("keterangan").value.trim()
  };

  if (!item.tanggal) {
    alert("Silakan pilih tanggal transaksi.");
    return;
  }

  dataTransaksi.push(item);

  if (!simpanData()) {
    dataTransaksi.pop();
    return;
  }

  $("formTransaksi").reset();
  $("tanggal").value = tanggalLokal();
  isiKategori();
  tampilkan();

  alert("Transaksi berhasil disimpan.");
});

function dataPeriode() {
  const bulan = $("filterBulan").value;

  return dataTransaksi.filter(t =>
    !bulan || t.tanggal.startsWith(bulan)
  );
}

function hitung() {
  const daftar = dataPeriode();

  const masuk = daftar
    .filter(t => t.jenis === "masuk")
    .reduce((sum, t) => sum + t.nominal, 0);

  const keluar = daftar
    .filter(t => t.jenis === "keluar")
    .reduce((sum, t) => sum + t.nominal, 0);

  $("totalMasuk").textContent = rupiah(masuk);
  $("totalKeluar").textContent = rupiah(keluar);
  $("saldo").textContent = rupiah(masuk - keluar);
  $("jumlahData").textContent = daftar.length + " transaksi";
}

function tampilkanRiwayat() {
  const cari = $("cari").value.trim().toLowerCase();

  const daftar = dataPeriode()
    .filter(t =>
      (t.kategori + " " + t.keterangan).toLowerCase()
        .includes(cari)
    )
    .sort((a, b) =>
      b.tanggal.localeCompare(a.tanggal) ||
      b.id.localeCompare(a.id)
    );

  $("riwayat").innerHTML = daftar.length
    ? daftar.map(t => `
      <div class="transaksi">
        <h3>${aman(t.kategori)}</h3>
        <p>
          Tanggal: ${aman(t.tanggal)}<br>
          Keterangan: ${aman(t.keterangan || "-")}
        </p>
        <p class="${t.jenis === "masuk"
          ? "nominal-masuk" : "nominal-keluar"}">
          ${t.jenis === "masuk" ? "+" : "−"}${rupiah(t.nominal)}
        </p>
        <div class="aksi">
          <button type="button" class="hapus"
            data-hapus="${aman(t.id)}">
            Hapus Transaksi
          </button>
        </div>
      </div>
    `).join("")
    : '<p class="kosong">Tidak ada transaksi pada pilihan ini.</p>';
}

$("riwayat").addEventListener("click", e => {
  const tombol = e.target.closest("[data-hapus]");
  if (!tombol) return;

  const id = tombol.dataset.hapus;
  const item = dataTransaksi.find(t => t.id === id);

  if (!item) return;

  if (confirm(
    "Hapus transaksi " + item.kategori +
    " senilai " + rupiah(item.nominal) + "?"
  )) {
    const lama = dataTransaksi;
    dataTransaksi = dataTransaksi.filter(t => t.id !== id);

    if (!simpanData()) {
      dataTransaksi = lama;
      return;
    }

    tampilkan();
  }
});

function tampilkan() {
  hitung();
  tampilkanRiwayat();
}

$("filterBulan").addEventListener("change", tampilkan);
$("cari").addEventListener("input", tampilkanRiwayat);

$("semuaBulan").addEventListener("click", () => {
  $("filterBulan").value = "";
  tampilkan();
});

$("btnCetak").addEventListener("click", () => {
  window.print();
});

// Ekspor seluruh transaksi ke CSV
$("btnEkspor").addEventListener("click", () => {
  if (!dataTransaksi.length) {
    alert("Belum ada transaksi untuk diekspor.");
    return;
  }

  const kolom = [
    "Tanggal", "Jenis", "Kategori", "Nominal", "Keterangan"
  ];

  const baris = dataTransaksi.map(t => [
    t.tanggal,
    t.jenis === "masuk" ? "Pemasukan" : "Pengeluaran",
    t.kategori,
    t.nominal,
    t.keterangan
  ]);

  function csv(nilai) {
    let s = String(nilai ?? "");

    // Mencegah spreadsheet menjalankan teks sebagai formula.
    if (/^[\s]*[=+\-@\t\r]/.test(s)) {
      s = "'" + s;
    }

    return '"' + s.replace(/"/g, '""') + '"';
  }

  const isi = "\uFEFF" +
    [kolom, ...baris]
      .map(row => row.map(csv).join(";"))
      .join("\r\n");

  const blob = new Blob([isi], {
    type: "text/csv;charset=utf-8;"
  });

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");

  a.href = url;
  a.download = "pembukuan-" + tanggalLokal() + ".csv";
  document.body.appendChild(a);
  a.click();
  a.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

// Inisialisasi
$("tanggal").value = tanggalLokal();
$("filterBulan").value = tanggalLokal().slice(0, 7);
isiKategori();
tampilkan();
