const $ = id => document.getElementById(id);

const KEY = "pembukuan_keuangan_v2";

function muatData() {
  try {
    const data = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

let dataTransaksi = muatData();
let modeGrafik = "harian"; // 'harian', 'bulanan', 'tahunan'
let chartInstance = null;

const kategori = {
  masuk: ["Penjualan", "Gaji", "Bonus", "Usaha", "Piutang Diterima", "Lainnya"],
  keluar: ["Makanan", "Transportasi", "Belanja", "Tagihan", "Modal Usaha", "Cicilan", "Kesehatan", "Lainnya"]
};

function rupiah(n) {
  return Number(n).toLocaleString("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  });
}

function aman(teks) {
  return String(teks ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

function tanggalLokal() {
  const d = new Date();
  return [
    d.getFullYear(),
    String(d.getMonth() + 1).padStart(2, "0"),
    String(d.getDate()).padStart(2, "0")
  ].join("-");
}

function simpanData() {
  try {
    localStorage.setItem(KEY, JSON.stringify(dataTransaksi));
    return true;
  } catch (e) {
    alert("Data gagal disimpan. Periksa ruang penyimpanan browser.");
    return false;
  }
}

function isiKategori() {
  const jenis = $("jenis").value;
  $("kategori").innerHTML = kategori[jenis]
    .map(k => `<option value="${aman(k)}">${aman(k)}</option>`)
    .join("");
}

$("jenis").addEventListener("change", isiKategori);

// --- PERBAIKAN TAB NAVIGASI ---
function aktifkanTab(tabAktif) {
  const isDashboard = tabAktif === "dashboard";
  
  // Sembunyikan / Tampilkan View
  $("viewDashboard").style.display = isDashboard ? "block" : "none";
  $("viewRiwayat").style.display = isDashboard ? "none" : "block";

  // Style Tombol Dashboard
  $("tabDashboard").style.backgroundColor = isDashboard ? "#ffffff" : "transparent";
  $("tabDashboard").style.color = isDashboard ? "#047857" : "#475569";
  $("tabDashboard").style.boxShadow = isDashboard ? "0 1px 3px rgba(0,0,0,0.1)" : "none";

  // Style Tombol Riwayat
  $("tabRiwayat").style.backgroundColor = isDashboard ? "transparent" : "#ffffff";
  $("tabRiwayat").style.color = isDashboard ? "#475569" : "#047857";
  $("tabRiwayat").style.boxShadow = isDashboard ? "none" : "0 1px 3px rgba(0,0,0,0.1)";

  if (isDashboard && chartInstance) {
    setTimeout(() => chartInstance.resize(), 50);
  }
}

$("tabDashboard").addEventListener("click", () => aktifkanTab("dashboard"));
$("tabRiwayat").addEventListener("click", () => aktifkanTab("riwayat"));

// Event Submit Form Transaksi
$("formTransaksi").addEventListener("submit", e => {
  e.preventDefault();
  const nominal = Number($("nominal").value);

  if (!Number.isSafeInteger(nominal) || nominal <= 0) {
    alert("Masukkan nominal rupiah yang valid.");
    return;
  }

  const item = {
    id: Date.now().toString() + Math.random().toString(36).slice(2, 7),
    jenis: $("jenis").value,
    tanggal: $("tanggal").value,
    kategori: $("kategori").value,
    nominal,
    keterangan: $("keterangan").value.trim()
  };

  if (!item.tanggal) {
    alert("Silakan pilih tanggal transaksi.");
    return;
  }

  dataTransaksi.push(item);

  if (!simpanData()) {
    dataTransaksi.pop();
    return;
  }

  $("formTransaksi").reset();
  $("tanggal").value = tanggalLokal();
  isiKategori();
  tampilkan();

  alert("Transaksi berhasil disimpan.");
});

function dataPeriode() {
  const bulan = $("filterBulan").value;
  return dataTransaksi.filter(t => !bulan || t.tanggal.startsWith(bulan));
}

function hitung() {
  const daftar = dataPeriode();
  const masuk = daftar.filter(t => t.jenis === "masuk").reduce((sum, t) => sum + t.nominal, 0);
  const keluar = daftar.filter(t => t.jenis === "keluar").reduce((sum, t) => sum + t.nominal, 0);

  $("totalMasuk").textContent = rupiah(masuk);
  $("totalKeluar").textContent = rupiah(keluar);
  $("saldo").textContent = rupiah(masuk - keluar);
  $("jumlahData").textContent = `${daftar.length} transaksi tercatat`;
}

function tampilkanRiwayat() {
  const cari = $("cari").value.trim().toLowerCase();
  const daftar = dataPeriode()
    .filter(t => (t.kategori + " " + t.keterangan).toLowerCase().includes(cari))
    .sort((a, b) => b.tanggal.localeCompare(a.tanggal) || b.id.localeCompare(a.id));

  $("riwayat").innerHTML = daftar.length
    ? daftar.map(t => `
      <div class="py-3.5 border-b border-slate-100 flex justify-between items-center gap-3">
        <div class="space-y-1 min-w-0">
          <div class="flex items-center gap-2">
            <span class="inline-block px-2 py-0.5 text-[10px] font-bold uppercase rounded-md ${t.jenis === 'masuk' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}">${t.jenis}</span>
            <h3 class="text-sm font-bold text-slate-800 truncate">${aman(t.kategori)}</h3>
          </div>
          <p class="text-xs text-slate-500">${aman(t.tanggal)} &bull; ${aman(t.keterangan || "Tanpa keterangan")}</p>
        </div>
        <div class="text-right flex-shrink-0">
          <p class="text-sm font-extrabold ${t.jenis === "masuk" ? "text-emerald-600" : "text-rose-600"}">
            ${t.jenis === "masuk" ? "+" : "−"}${rupiah(t.nominal)}
          </p>
          <button type="button" data-hapus="${aman(t.id)}" class="btn-hapus-item text-xs text-slate-400 hover:text-rose-600 transition mt-1 font-medium">
            <i class="fa-regular fa-trash-can mr-1"></i>Hapus
          </button>
        </div>
      </div>
    `).join("")
    : '<p class="text-center text-slate-400 text-sm py-6">Tidak ada transaksi pada periode ini.</p>';
}

$("riwayat").addEventListener("click", e => {
  const tombol = e.target.closest("[data-hapus]");
  if (!tombol) return;

  const id = tombol.dataset.hapus;
  const item = dataTransaksi.find(t => t.id === id);
  if (!item) return;

  if (confirm(`Hapus transaksi ${item.kategori} senilai ${rupiah(item.nominal)}?`)) {
    const lama = dataTransaksi;
    dataTransaksi = dataTransaksi.filter(t => t.id !== id);

    if (!simpanData()) {
      dataTransaksi = lama;
      return;
    }
    tampilkan();
  }
});

// FUNGSI RENDER GRAFIK CHART.JS
function renderGrafik() {
  const ctx = $("grafikKeuangan").getContext("2d");
  const periodeBulan = $("filterBulan").value;
  
  let labels = [];
  let dataMasuk = [];
  let dataKeluar = [];

  if (modeGrafik === "harian") {
    $("labelInfoGrafik").textContent = `Grafik Harian Periode: ${periodeBulan || 'Semua Waktu'}`;
    
    let tahun = new Date().getFullYear();
    let bulan = new Date().getMonth() + 1;
    if (periodeBulan) {
      const parts = periodeBulan.split("-");
      tahun = parseInt(parts[0]);
      bulan = parseInt(parts[1]);
    }
    const jumlahHari = new Date(tahun, bulan, 0).getDate();

    labels = Array.from({ length: jumlahHari }, (_, i) => String(i + 1));
    dataMasuk = new Array(jumlahHari).fill(0);
    dataKeluar = new Array(jumlahHari).fill(0);

    dataTransaksi.forEach(t => {
      if (!periodeBulan || t.tanggal.startsWith(periodeBulan)) {
        const tglParts = t.tanggal.split("-");
        const hari = parseInt(tglParts[2], 10);
        if (hari >= 1 && hari <= jumlahHari) {
          if (t.jenis === "masuk") dataMasuk[hari - 1] += t.nominal;
          if (t.jenis === "keluar") dataKeluar[hari - 1] += t.nominal;
        }
      }
    });

  } else if (modeGrafik === "bulanan") {
    $("labelInfoGrafik").textContent = "Grafik Bulanan Tahun Berjalan";
    labels = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
    dataMasuk = new Array(12).fill(0);
    dataKeluar = new Array(12).fill(0);

    const tahunAktif = periodeBulan ? periodeBulan.split("-")[0] : String(new Date().getFullYear());

    dataTransaksi.forEach(t => {
      if (t.tanggal.startsWith(tahunAktif)) {
        const bulanIndex = parseInt(t.tanggal.split("-")[1], 10) - 1;
        if (bulanIndex >= 0 && bulanIndex < 12) {
          if (t.jenis === "masuk") dataMasuk[bulanIndex] += t.nominal;
          if (t.jenis === "keluar") dataKeluar[bulanIndex] += t.nominal;
        }
      }
    });

  } else if (modeGrafik === "tahunan") {
    $("labelInfoGrafik").textContent = "Grafik Perbandingan Tahunan";
    const tahunSet = new Set(dataTransaksi.map(t => t.tanggal.slice(0, 4)));
    tahunSet.add(String(new Date().getFullYear()));
    labels = Array.from(tahunSet).sort();

    dataMasuk = new Array(labels.length).fill(0);
    dataKeluar = new Array(labels.length).fill(0);

    dataTransaksi.forEach(t => {
      const thn = t.tanggal.slice(0, 4);
      const idx = labels.indexOf(thn);
      if (idx !== -1) {
        if (t.jenis === "masuk") dataMasuk[idx] += t.nominal;
        if (t.jenis === "keluar") dataKeluar[idx] += t.nominal;
      }
    });
  }

  if (chartInstance) {
    chartInstance.destroy();
  }

  chartInstance = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [
        {
          label: "Pemasukan",
          data: dataMasuk,
          backgroundColor: "#10b981",
          borderRadius: 6
        },
        {
          label: "Pengeluaran",
          data: dataKeluar,
          backgroundColor: "#f43f5e",
          borderRadius: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: "bottom",
          labels: { font: { size: 11, family: "system-ui" }, boxWidth: 12 }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { font: { size: 10 } },
          grid: { color: "#f1f5f9" }
        },
        x: {
          ticks: { font: { size: 10 } },
          grid: { display: false }
        }
      }
    }
  });
}

// Tombol Mode Grafik
$("btnModeHarian").addEventListener("click", () => {
  modeGrafik = "harian";
  renderGrafik();
});

$("btnModeBulanan").addEventListener("click", () => {
  modeGrafik = "bulanan";
  renderGrafik();
});

$("btnModeTahunan").addEventListener("click", () => {
  modeGrafik = "tahunan";
  renderGrafik();
});

function tampilkan() {
  hitung();
  tampilkanRiwayat();
  renderGrafik();
}

$("filterBulan").addEventListener("change", tampilkan);
$("cari").addEventListener("input", tampilkanRiwayat);

$("semuaBulan").addEventListener("click", () => {
  $("filterBulan").value = "";
  tampilkan();
});

$("btnCetak").addEventListener("click", () => {
  window.print();
});

// Ekspor ke CSV
$("btnEkspor").addEventListener("click", () => {
  if (!dataTransaksi.length) {
    alert("Belum ada transaksi untuk diekspor.");
    return;
  }

  const kolom = ["Tanggal", "Jenis", "Kategori", "Nominal", "Keterangan"];
  const baris = dataTransaksi.map(t => [
    t.tanggal,
    t.jenis === "masuk" ? "Pemasukan" : "Pengeluaran",
    t.kategori,
    t.nominal,
    t.keterangan
  ]);

  function csv(nilai) {
    let s = String(nilai ?? "");
    if (/^[\s]*[=+\-@\t\r]/.test(s)) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  }

  const isi = "\uFEFF" + [kolom, ...baris].map(row => row.map(csv).join(";")).join("\r\n");
  const blob = new Blob([isi], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");

  a.href = url;
  a.download = "pembukuan-keuangan-" + tanggalLokal() + ".csv";
  document.body.appendChild(a);
  a.click();
  a.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

// Inisialisasi Awal
$("tanggal").value = tanggalLokal();
$("filterBulan").value = tanggalLokal().slice(0, 7);
isiKategori();
aktifkanTab("dashboard");
tampilkan();
