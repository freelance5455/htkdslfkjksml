OFFLINE AI PHOTO ENHANCE — HTML ZIP FOR APK WRAPPERS

MAIN FILE: index.html

CONTENTS
- index.html
- style.css
- app.js
- manifest.webmanifest
- models/README.txt

HOW TO USE
1. Extract this ZIP on your Android phone.
2. Import the extracted folder into an HTML-to-APK / WebView app builder.
3. Set the start page to index.html.
4. Enable local/offline asset loading and image file selection.
5. Build/export the APK in that builder.

IMPORTANT
This ZIP is an HTML project package, not an already compiled APK.
The current enhancement uses offline browser image-processing algorithms
(brightness, contrast, color and sharpening). It does not include trained AI
model weights or genuine neural-network face restoration / super-resolution.
A true offline AI APK requires adding a compatible model and an inference
runtime (for example ONNX Runtime Mobile or WebAssembly), then testing it
on the target Android device.
