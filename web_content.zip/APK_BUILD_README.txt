APK-READY STITCH WEB APP

Entry file:
index.html

Use an online HTML/WebView-to-APK builder:
1. Upload this ZIP.
2. Set Start/Index page to index.html.
3. Enable Internet access.
4. Build APK.

The app is configured for manual number entry: it does not preload a number.
The real lookup requires an authorized API endpoint and correct authentication.
Do not put secret API keys inside index.html.
