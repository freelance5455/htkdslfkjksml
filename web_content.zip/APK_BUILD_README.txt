MILITARY 30 v3 — APK READY PACKAGE

This ZIP is intended for a cloud HTML-to-APK builder.

App name: Military 30
Suggested package name: com.military30.app
Orientation: Portrait
Display: Fullscreen / standalone
Offline: Yes
Internet permission: Not required for the workout itself
Website entry point: index.html

Upload this ZIP with index.html at the root of the ZIP.
Use the included icons/icon-192.png or icons/icon-512.png as the app icon if the builder asks for one.

NOTE:
This is a web-app package prepared for an APK wrapper. The APK compilation/signing still has to be performed by an Android build service.
