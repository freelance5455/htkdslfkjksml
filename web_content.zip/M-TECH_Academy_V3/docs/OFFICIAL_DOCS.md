# مراجع رسمية مقترحة

- Python Tutorial: https://docs.python.org/3/tutorial/
- Python Standard Library: https://docs.python.org/3/library/
- Python Packaging: https://packaging.python.org/
- Requests documentation: https://requests.readthedocs.io/
- Flask documentation: https://flask.palletsprojects.com/
- FastAPI documentation: https://fastapi.tiangolo.com/
- SQLite documentation: https://sqlite.org/docs.html
- Pyodide documentation: https://pyodide.org/en/stable/usage/quickstart.html
- OWASP Top 10: https://owasp.org/www-project-top-ten/
- OWASP Cheat Sheet Series: https://cheatsheetseries.owasp.org/
- OpenAI Python API docs: https://developers.openai.com/api/reference/python/

تحقق من إصدارات المكتبات وتوافقها قبل التثبيت؛ قد تتغير المتطلبات بمرور الوقت.
