"""HTTP client example. Install requests first: python -m pip install requests"""
try:
    import requests
except ImportError:
    raise SystemExit("Install requests with: python -m pip install requests")

url = "https://jsonplaceholder.typicode.com/todos/1"  # public demo API
try:
    response = requests.get(url, timeout=10)
    response.raise_for_status()
    data = response.json()
    print("Title:", data.get("title", "(no title)"))
except requests.RequestException as exc:
    print("Network request failed:", exc)
