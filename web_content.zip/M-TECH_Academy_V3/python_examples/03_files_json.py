"""Read/write a small JSON file in the current project folder."""
import json
from pathlib import Path

path = Path("mtech_demo.json")
data = {"brand": "M-TECH", "topics": ["Python", "APIs", "secure coding"]}
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
loaded = json.loads(path.read_text(encoding="utf-8"))
print(loaded["brand"], loaded["topics"])
