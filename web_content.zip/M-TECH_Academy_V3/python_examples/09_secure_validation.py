"""Example of explicit input validation and safe error handling."""
import re

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,30}$")

def validate_username(value: str) -> str:
    value = value.strip()
    if not USERNAME_RE.fullmatch(value):
        raise ValueError("Use 3-30 letters, digits, underscore, dot, or hyphen.")
    return value

for candidate in ["mtech_dev", "hi", "contains spaces"]:
    try:
        print("Accepted:", validate_username(candidate))
    except ValueError as exc:
        print("Rejected:", exc)
