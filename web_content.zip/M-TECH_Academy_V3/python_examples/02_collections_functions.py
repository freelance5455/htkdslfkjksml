"""Collections, functions, and safe validation."""
def average(numbers: list[float]) -> float:
    if not numbers:
        raise ValueError("numbers must not be empty")
    return sum(numbers) / len(numbers)

scores = [90, 84, 77, 95]
unique_scores = set(scores)
print("average:", average(scores))
print("unique count:", len(unique_scores))
