"""Local demo API. Install Flask and run only for local learning."""
try:
    from flask import Flask, jsonify
except ImportError:
    raise SystemExit("Install Flask with: python -m pip install flask")

app = Flask(__name__)

@app.get("/api/status")
def status():
    return jsonify({"brand": "M-TECH", "status": "online"})

if __name__ == "__main__":
    # Local testing only; do not expose the development server publicly.
    app.run(host="127.0.0.1", port=5001, debug=False)
