"""Async programming demo for I/O-style waiting."""
import asyncio

async def pretend_io(name: str, delay: float) -> str:
    await asyncio.sleep(delay)
    return f"Finished {name}"

async def main() -> None:
    results = await asyncio.gather(pretend_io("A", 1), pretend_io("B", 1))
    print(results)

if __name__ == "__main__":
    asyncio.run(main())
