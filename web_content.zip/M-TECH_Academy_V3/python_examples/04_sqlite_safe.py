"""SQLite parameterized query: safe pattern for user-supplied values."""
import sqlite3

with sqlite3.connect(":memory:") as connection:
    connection.execute("CREATE TABLE notes(id INTEGER PRIMARY KEY, title TEXT NOT NULL)")
    title_from_user = "First note"
    connection.execute("INSERT INTO notes(title) VALUES (?)", (title_from_user,))
    rows = connection.execute("SELECT id, title FROM notes WHERE title = ?", (title_from_user,)).fetchall()
    print(rows)
