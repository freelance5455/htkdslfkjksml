"""Read-only inventory of files in a folder you choose. No deletion or modification."""
from pathlib import Path

def inventory(folder_text: str) -> None:
    folder = Path(folder_text).expanduser()
    if not folder.is_dir():
        raise ValueError("Path does not point to a directory")
    for entry in sorted(folder.iterdir(), key=lambda item: item.name.lower()):
        try:
            if entry.is_file():
                print(f"{entry.name}	{entry.stat().st_size} bytes")
            elif entry.is_dir():
                print(f"{entry.name}/	[folder]")
        except OSError as exc:
            print(f"Skipped {entry.name}: {exc}")

if __name__ == "__main__":
    chosen = input("Folder path (read-only): ").strip()
    inventory(chosen)
