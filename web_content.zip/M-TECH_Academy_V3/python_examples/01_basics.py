"""Basics: variables, input conversion, and branches."""
def main() -> None:
    name = input("Your name: ").strip() or "Coder"
    raw_score = input("Score (0-100): ").strip()
    try:
        score = int(raw_score)
    except ValueError:
        print("Please enter a whole number.")
        return
    if not 0 <= score <= 100:
        print("Score must be between 0 and 100.")
    elif score >= 50:
        print(f"Well done, {name}!")
    else:
        print(f"Keep practicing, {name}.")

if __name__ == "__main__":
    main()
