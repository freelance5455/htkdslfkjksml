"""A tiny module and unit test, runnable with: python 07_unit_tests.py"""
import unittest

def discount(price: float, rate: float) -> float:
    if price < 0 or not 0 <= rate <= 1:
        raise ValueError("invalid price or rate")
    return price * (1 - rate)

class DiscountTests(unittest.TestCase):
    def test_discount(self):
        self.assertAlmostEqual(discount(100, 0.2), 80)
    def test_bad_rate(self):
        with self.assertRaises(ValueError):
            discount(100, 1.2)

if __name__ == "__main__":
    unittest.main()
