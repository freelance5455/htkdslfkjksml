"""M-TECH educational API scaffold: accounts, progress sync, and optional AI chat.
For local/private learning only; perform a security review before public deployment.
"""
from __future__ import annotations
import json
import os
import re
import sqlite3
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import jwt
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from openai import OpenAI
from pydantic import BaseModel, Field
from pwdlib import PasswordHash

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent
DB_FILE = Path(os.getenv("MTECH_DB_PATH", str(BASE_DIR / "mtech_users.sqlite3")))
if not DB_FILE.is_absolute():
    DB_FILE = BASE_DIR / DB_FILE
SECRET_KEY = os.getenv("MTECH_SECRET_KEY", "")
JWT_ALGORITHM = "HS256"
TOKEN_HOURS = 24
password_hasher = PasswordHash.recommended()
bearer = HTTPBearer(auto_error=False)

app = FastAPI(title="M-TECH Academy API", version="3.0.0", docs_url="/api/docs")
origins = [x.strip() for x in os.getenv("MTECH_CORS_ORIGINS", "http://127.0.0.1:5500,http://localhost:5500").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=["GET", "POST", "PUT", "OPTIONS"], allow_headers=["Authorization", "Content-Type"])

# Simple process-local rate guard for the educational chat endpoint; not a replacement for production rate limiting.
chat_hits: dict[str, deque[float]] = defaultdict(deque)
CHAT_LIMIT = 8
CHAT_WINDOW_SECONDS = 60


def get_db() -> sqlite3.Connection:
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_FILE, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with get_db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            progress_json TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL
        )""")


init_db()


class CredentialsIn(BaseModel):
    username: str = Field(min_length=3, max_length=30, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=10, max_length=128)


class ProgressIn(BaseModel):
    progress: dict[str, Any] = Field(default_factory=dict)


class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=2000)


def create_token(username: str) -> str:
    if len(SECRET_KEY) < 32 or SECRET_KEY == "REPLACE_WITH_LONG_RANDOM_SECRET":
        raise HTTPException(status_code=503, detail="اضبط MTECH_SECRET_KEY في ملف .env أولًا")
    payload = {"sub": username, "exp": datetime.now(timezone.utc) + timedelta(hours=TOKEN_HOURS), "iat": datetime.now(timezone.utc)}
    return jwt.encode(payload, SECRET_KEY, algorithm=JWT_ALGORITHM)


def get_current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)) -> sqlite3.Row:
    if not credentials:
        raise HTTPException(status_code=401, detail="سجّل الدخول أولًا")
    if len(SECRET_KEY) < 32:
        raise HTTPException(status_code=503, detail="إعداد السر غير مكتمل")
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[JWT_ALGORITHM])
        username = payload.get("sub")
        if not username:
            raise ValueError("missing subject")
    except (jwt.InvalidTokenError, ValueError):
        raise HTTPException(status_code=401, detail="جلسة غير صالحة؛ سجّل الدخول مجددًا")
    with get_db() as conn:
        row = conn.execute("SELECT id, username, progress_json FROM users WHERE username = ?", (username,)).fetchone()
    if not row:
        raise HTTPException(status_code=401, detail="الحساب غير موجود")
    return row


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "online", "service": "M-TECH Academy API", "version": "3.0.0"}


@app.post("/api/register", status_code=201)
def register(body: CredentialsIn) -> dict[str, str]:
    username = body.username.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,30}", username):
        raise HTTPException(status_code=422, detail="استخدم 3–30 حرفًا إنجليزيًا أو رقمًا أو . _ -")
    hashed = password_hasher.hash(body.password)
    try:
        with get_db() as conn:
            conn.execute("INSERT INTO users(username, password_hash, progress_json, created_at) VALUES(?, ?, '{}', ?)", (username, hashed, datetime.now(timezone.utc).isoformat()))
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="اسم المستخدم مستخدم بالفعل")
    return {"username": username, "access_token": create_token(username), "token_type": "bearer"}


@app.post("/api/login")
def login(body: CredentialsIn) -> dict[str, str]:
    with get_db() as conn:
        row = conn.execute("SELECT username, password_hash FROM users WHERE username = ? COLLATE NOCASE", (body.username.strip(),)).fetchone()
    if not row or not password_hasher.verify(body.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="اسم المستخدم أو كلمة المرور غير صحيحة")
    return {"username": row["username"], "access_token": create_token(row["username"]), "token_type": "bearer"}


@app.get("/api/me")
def me(user: sqlite3.Row = Depends(get_current_user)) -> dict[str, str]:
    return {"username": user["username"]}


@app.get("/api/progress")
def get_progress(user: sqlite3.Row = Depends(get_current_user)) -> dict[str, Any]:
    try:
        data = json.loads(user["progress_json"] or "{}")
    except json.JSONDecodeError:
        data = {}
    return {"username": user["username"], "progress": data}


@app.put("/api/progress")
def put_progress(body: ProgressIn, user: sqlite3.Row = Depends(get_current_user)) -> dict[str, Any]:
    # Store only a small bounded state object, not uploaded files or secrets.
    if len(body.progress) > 1000:
        raise HTTPException(status_code=413, detail="عدد كبير جدًا من عناصر التقدم")
    safe = {str(k)[:100]: bool(v) for k, v in body.progress.items() if isinstance(k, str)}
    encoded = json.dumps(safe, ensure_ascii=False)
    if len(encoded) > 100_000:
        raise HTTPException(status_code=413, detail="بيانات التقدم أكبر من المسموح")
    with get_db() as conn:
        conn.execute("UPDATE users SET progress_json = ? WHERE id = ?", (encoded, user["id"]))
    return {"saved": True, "progress": safe}


@app.post("/api/chat")
def chat(body: ChatIn, request: Request, user: sqlite3.Row = Depends(get_current_user)) -> dict[str, str]:
    # In-memory guard only; use a trusted reverse proxy / robust limiter before public deployment.
    key = request.client.host if request.client else "unknown"
    now = time.monotonic()
    hits = chat_hits[key]
    while hits and now - hits[0] > CHAT_WINDOW_SECONDS:
        hits.popleft()
    if len(hits) >= CHAT_LIMIT:
        raise HTTPException(status_code=429, detail="طلبات كثيرة؛ جرّب بعد دقيقة")
    hits.append(now)
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise HTTPException(status_code=503, detail="شات AI غير مفعّل. اضبط OPENAI_API_KEY على الخادم")
    try:
        client = OpenAI(api_key=api_key)
        response = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-5.5"),
            instructions=(
                "You are M-TECH's friendly Arabic Egyptian coding tutor. Explain Python step by step to a beginner. "
                "For cybersecurity, stick to defensive concepts, safe labs, authorized testing, and remediation; "
                "do not provide instructions for stealing credentials, bypassing account security, malware, or attacking real targets. "
                "Never ask the user to paste passwords, API keys, or Telegram bot tokens."
            ),
            input=body.message,
            max_output_tokens=900,
        )
        answer = getattr(response, "output_text", "") or "لم يصل نص في الرد."
        return {"reply": answer}
    except HTTPException:
        raise
    except Exception as exc:
        # Avoid leaking internals or secrets to the browser.
        print(f"AI backend error: {type(exc).__name__}")
        raise HTTPException(status_code=502, detail="تعذر الحصول على رد من خدمة AI؛ راجع إعدادات الخادم.")
