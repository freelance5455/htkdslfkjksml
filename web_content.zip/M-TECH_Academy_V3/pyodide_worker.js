// M-TECH Python runner worker. Requires internet on first use.
importScripts("https://cdn.jsdelivr.net/pyodide/v314.0.7/full/pyodide.js");
let pyodide;
self.onmessage = async (event) => {
  const data = event.data;
  try {
    if (data.type === "init") {
      pyodide = await loadPyodide({ indexURL: "https://cdn.jsdelivr.net/pyodide/v314.0.7/full/" });
      self.postMessage({ type: "ready", version: pyodide.runPython("import sys; sys.version.split()[0]") });
      return;
    }
    if (data.type === "run") {
      const stdout = [];
      const stderr = [];
      pyodide.setStdout({ batched: (s) => stdout.push(s) });
      pyodide.setStderr({ batched: (s) => stderr.push(s) });
      await pyodide.loadPackagesFromImports(data.code);
      pyodide.runPython(data.code);
      self.postMessage({ type: "done", stdout: stdout.join("\n"), stderr: stderr.join("\n") });
    }
  } catch (error) {
    self.postMessage({ type: "error", error: String(error), stdout: "", stderr: "" });
  }
};
