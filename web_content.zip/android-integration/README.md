# Android bridge for “Use template”

The website now calls `AndroidGZ.openAveeTemplateBase64(...)` when that native JavaScript bridge exists. In a plain browser, it falls back to downloading the file and explains how to open it manually.

## Integration needed for direct opening
1. Build the HTML inside an Android WebView APK.
2. Add AndroidX Core (`androidx.core:core`) to the Android project.
3. Add `AlJoulaniGZAndroidBridge.kt` to your Android app and replace `package your.app.package` with your app's package.
4. In the WebView setup, register the bridge: `webView.addJavascriptInterface(AlJoulaniGZAndroidBridge(this), "AndroidGZ")`.
5. Add the provider snippet from `AndroidManifest-snippet.xml` inside `<application>` and copy `file_paths.xml` to `res/xml/file_paths.xml`.
6. Test on a phone with Avee Player installed. Android/Avee may still show a chooser or reject direct import depending on file association. If that happens, the fallback is to open the downloaded `.viz` file from the Files/Downloads app and choose Avee Player.

Security: only use this bridge with trusted first-party UI. A JavaScript bridge exposes native functionality to the page loaded in the WebView; do not enable it for arbitrary websites. The current ZIP is still a prototype: user uploads are local to the current session and not shared online.
