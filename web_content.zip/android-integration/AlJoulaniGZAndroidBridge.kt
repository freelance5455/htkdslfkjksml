// Example native bridge for an Android WebView wrapper.
// Package name in Avee Player's Google Play listing: com.daaw.avee
// Add this class to your Android app and expose it with:
// webView.addJavascriptInterface(AlJoulaniGZAndroidBridge(this), "AndroidGZ")

package your.app.package

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.util.Base64
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class AlJoulaniGZAndroidBridge(private val activity: Activity) {
    @JavascriptInterface
    fun openAveeTemplateBase64(base64: String, requestedName: String) {
        activity.runOnUiThread {
            try {
                // Keep the demo's limit modest because JavaScript bridges copy the data in memory.
                if (base64.length > 14_000_000) {
                    Toast.makeText(activity, "Template is too large for direct opening", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                val cleanName = requestedName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val fileName = if (cleanName.endsWith(".viz", true)) cleanName else "$cleanName.viz"
                val folder = File(activity.cacheDir, "viz_templates").apply { mkdirs() }
                val file = File(folder, fileName)
                file.writeBytes(Base64.decode(base64, Base64.DEFAULT))
                val uri: Uri = FileProvider.getUriForFile(
                    activity,
                    "${activity.packageName}.fileprovider",
                    file
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/octet-stream")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    setPackage("com.daaw.avee")
                }
                try {
                    activity.startActivity(intent)
                } catch (_: ActivityNotFoundException) {
                    // If Avee is missing or does not advertise this file type, offer Android's app chooser.
                    val chooser = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/octet-stream")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    activity.startActivity(Intent.createChooser(chooser, "Open template with"))
                }
            } catch (e: Exception) {
                Toast.makeText(activity, "Could not open template. Download it and open it from Files.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
