const input = document.getElementById("fileInput");
const list = document.getElementById("fileList");
const empty = document.getElementById("emptyState");
const count = document.getElementById("fileCount");
const counter = document.getElementById("counter");
const storageText = document.getElementById("storageText");
const progress = document.getElementById("progressBar");
const dialog = document.getElementById("aboutDialog");
let selectedFiles = [];

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 ** 3) return `${(bytes / (1024 ** 2)).toFixed(1)} MB`;
  return `${(bytes / (1024 ** 3)).toFixed(2)} GB`;
}
function iconFor(name) {
  const ext = name.split(".").pop().toLowerCase();
  if (["apk","aab"].includes(ext)) return "▣";
  if (["zip","rar","7z"].includes(ext)) return "▧";
  if (["jpg","jpeg","png","webp","gif"].includes(ext)) return "▨";
  if (["pdf","doc","docx","txt"].includes(ext)) return "▤";
  return "◇";
}
function render() {
  list.innerHTML = "";
  empty.hidden = selectedFiles.length > 0;
  count.textContent = selectedFiles.length;
  counter.textContent = `${selectedFiles.length} ${selectedFiles.length === 1 ? "item" : "itens"}`;
  const total = selectedFiles.reduce((sum, file) => sum + file.size, 0);
  storageText.textContent = selectedFiles.length
    ? `${formatSize(total)} selecionados nesta sessão. Nada foi enviado.`
    : "Nenhum arquivo selecionado nesta sessão.";
  progress.style.width = `${Math.min(100, total / (100 * 1024 * 1024) * 100)}%`;
  selectedFiles.forEach(file => {
    const row = document.createElement("article");
    row.className = "file-item";
    const ico = document.createElement("div");
    ico.className = "file-icon";
    ico.textContent = iconFor(file.name);
    const meta = document.createElement("div");
    meta.className = "file-meta";
    const name = document.createElement("strong");
    name.textContent = file.name;
    const size = document.createElement("small");
    size.textContent = formatSize(file.size);
    meta.append(name, size);
    row.append(ico, meta);
    list.append(row);
  });
}
document.getElementById("chooseBtn").addEventListener("click", () => input.click());
input.addEventListener("change", event => {
  selectedFiles = [...selectedFiles, ...Array.from(event.target.files)];
  render();
  input.value = "";
});
function showAbout() { if (typeof dialog.showModal === "function") dialog.showModal(); else alert("VitorioFiles - versão inicial de demonstração."); }
document.getElementById("aboutBtn").addEventListener("click", showAbout);
document.getElementById("infoNav").addEventListener("click", event => { event.preventDefault(); showAbout(); });
document.getElementById("closeDialog").addEventListener("click", () => dialog.close());
document.getElementById("filesNav").addEventListener("click", event => {
  event.preventDefault();
  document.querySelector(".section-title").scrollIntoView({behavior:"smooth"});
});
render();
