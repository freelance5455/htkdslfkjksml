# VitorioFiles

Aplicativo inicial Android baseado em HTML/CSS/JavaScript + Capacitor.

## O que esta versão faz
- Interface móvel VitorioFiles.
- Seleciona arquivos do dispositivo.
- Mostra nome e tamanho dos arquivos selecionados.
- Identifica visualmente extensões comuns.
- Não envia arquivos para nenhum servidor.

## Requisitos para gerar o APK
- Node.js LTS
- Android Studio
- Android SDK
- Java JDK compatível com a versão do Android Gradle Plugin instalada pelo Capacitor

## Preparar o projeto
No terminal, dentro desta pasta:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio, aguarde a sincronização do Gradle. Depois use:
**Build > Build Bundle(s) / APK(s) > Build APK(s)**.

O APK de teste será gerado dentro da pasta `android/app/build/outputs/apk/`.

## Observações importantes
- Este ZIP contém o projeto-fonte, não um APK já compilado.
- A seleção de arquivos é apenas local e temporária nesta versão.
- Para publicar arquivos e criar links compartilháveis, será necessário integrar um backend e armazenamento em nuvem, com autenticação, regras de acesso, limites de tamanho e análise de arquivos.
- Não coloque chaves privadas, senhas ou credenciais administrativas no código do aplicativo.
