// Médiathèque : Documents\GESTION COLLEGE\Fichiers\<prof>\<catégorie>
const { ipcMain, app, shell, session } = require('electron');
const fs = require('fs'), path = require('path');
module.exports = function () {
  const root = path.join(app.getPath('documents'), 'GESTION COLLEGE');
  const safe = s => String(s || 'Divers').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').trim().slice(0, 60) || 'Divers';
  const dir = (p, c) => path.join(root, 'Fichiers', safe(p), safe(c));
  fs.mkdirSync(path.join(root, 'Fichiers'), { recursive: true });
  session.defaultSession.setPreloads([path.join(__dirname, 'fichiers-preload.js')]);
  ipcMain.handle('gcf:save', (e, prof, cat, name, buf) => {
    const d = dir(prof, cat); fs.mkdirSync(d, { recursive: true });
    let f = safe(name), p = path.join(d, f);
    if (fs.existsSync(p)) { const x = path.extname(f); f = path.basename(f, x) + '_' + Date.now() + x; p = path.join(d, f); }
    fs.writeFileSync(p, Buffer.from(buf)); return p;
  });
  ipcMain.handle('gcf:list', (e, prof, cat) => {
    const d = dir(prof, cat);
    try { return fs.readdirSync(d).map(n => ({ n, p: path.join(d, n), k: Math.ceil(fs.statSync(path.join(d, n)).size / 1024) })); } catch (x) { return []; }
  });
  ipcMain.handle('gcf:open', (e, p) => { if (path.resolve(p).startsWith(root)) return shell.openPath(p); });
  ipcMain.handle('gcf:folder', (e, prof) => { const d = path.join(root, 'Fichiers', safe(prof)); fs.mkdirSync(d, { recursive: true }); return shell.openPath(d); });
};
