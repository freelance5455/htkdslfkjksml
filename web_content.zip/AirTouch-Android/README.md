# AirTouch (Android) – hands-free control of ANY app

Front camera → MediaPipe Hand Landmarker → pointer dot drawn over all apps → pinch gestures
become real taps / swipes / Back / Home / Recents through an AccessibilityService.

## Build
1. Open this folder in **Android Studio** (Koala or newer) and press Run, or on a build server: `gradle assembleDebug`
   (the Gradle wrapper jar is not included – Android Studio creates it; or run `gradle wrapper --gradle-version 8.7`).
2. First build needs internet: it downloads `hand_landmarker.task` into `app/src/main/assets/`
   (https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task).
   You can also put the file there yourself.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

## First run on the phone
1. Open AirTouch → **Allow camera & notifications**.
2. **Open Accessibility settings** → AirTouch → ON.
   Android 13+ (sideloaded APK): if greyed out → Settings → Apps → AirTouch → ⋮ → *Allow restricted settings*.
3. **Start AirTouch**, then go to any app and show your hand to the front camera.

## Gestures
| Gesture | Action |
|---|---|
| Move palm | Dot moves |
| Thumb + index pinch | Tap |
| Two quick pinches | Double tap (the 1st pinch also taps) |
| Pinch, hold, move, release | Swipe / scroll |
| Thumb + middle | Back |
| Thumb + ring | Home |
| Thumb + little finger | Recents |

## How it stays alive in the background
`HandTrackingService` is a foreground service of type `camera` (permanent notification, Stop button).
Start it from the app screen (Android only allows starting camera services while the app is visible).

## Known limits
* Camera is used continuously → battery drain and the green camera indicator are expected.
* Many phones stop camera use when the screen is locked/off. Set battery to "Unrestricted" for AirTouch.
* Some apps (banking, DRM video, password screens) block or ignore accessibility input.
* Accessibility apps need Play Store policy approval to publish; for personal use sideload the APK.
* Tune *Hand reach*, *Smoothness* and *Pinch sensitivity* in the app. Good light on the hand helps a lot.

## HTML version (`web/` folder)
`web/index.html` is the browser/PWA version of AirTouch (same gestures, works only inside its own page).
Run it with `cd web && python -m http.server 8000` (camera needs HTTPS or localhost) or upload `web/` to any HTTPS host.
The Android app in `app/` is the one that works in the background and over other apps.
