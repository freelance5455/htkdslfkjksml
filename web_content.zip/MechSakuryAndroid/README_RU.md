# Меч сакуры — Android-проект

Это Android Studio project, который запускает оригинальную HTML-игру в полноэкранном WebView.
Дизайн и механики HTML-игры сохранены; исходная страница лежит в `app/src/main/assets/index.html`.

## Как получить APK
1. Установите Android Studio на компьютер.
2. Распакуйте архив и откройте папку `MechSakuryAndroid` через **Open** в Android Studio.
3. Дождитесь Gradle Sync. При первом запуске Android Studio может скачать Android SDK и Gradle-плагины.
4. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK будет в `app/build/outputs/apk/debug/app-debug.apk`.

## Важно
- Для онлайн-мультиплеера и загрузки веб-шрифтов требуется интернет.
- Приложение открывает игру локально, но PeerJS загружается с CDN и использует сетевое соединение.
- Это исходный проект, а не уже собранный APK: для сборки нужен Android SDK/Android Studio.
