plugins {
    id("com.android.application")
}

android {
    namespace = "ru.daven.mechsakury"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.daven.mechsakury"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
