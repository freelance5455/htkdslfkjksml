const $ = id => document.getElementById(id);
let balance = Number(localStorage.getItem("bw_balance") ?? 1000);
let transactions = JSON.parse(localStorage.getItem("bw_transactions") || "[]");
const money = n => "₱ " + Number(n).toLocaleString("en-PH",{minimumFractionDigits:2,maximumFractionDigits:2});
function persist(){localStorage.setItem("bw_balance",String(balance));localStorage.setItem("bw_transactions",JSON.stringify(transactions));}
function render(){
 $("balance").textContent=money(balance);
 const root=$("transactions");root.innerHTML="";
 $("empty").style.display=transactions.length?"none":"block";
 transactions.forEach(t=>{
  const row=document.createElement("div");row.className="tx";
  const icon=document.createElement("div");icon.className="tx-icon";icon.textContent=({"Cash in":"＋","Send":"↗","Pay":"▦","Buy load":"▤","Receive":"↓"})[t.type]||"•";
  const main=document.createElement("div");main.className="tx-main";
  const title=document.createElement("div");title.className="tx-title";title.textContent=t.description;
  const date=document.createElement("div");date.className="tx-date";date.textContent=t.type+" · "+t.date;
  main.append(title,date);
  const amount=document.createElement("div");amount.className="tx-amount "+(["Cash in","Receive"].includes(t.type)?"in":"out");amount.textContent=(["Cash in","Receive"].includes(t.type)?"+":"−")+money(t.amount);
  const del=document.createElement("button");del.className="delete";del.textContent="×";del.setAttribute("aria-label","Delete transaction");del.onclick=()=>{transactions=transactions.filter(x=>x.id!==t.id);persist();render();};
  row.append(icon,main,amount,del);root.append(row);
 });
}
function openTx(type){$("type").value=type;$("description").value="";$("amount").value="";$("modal").showModal();}
document.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>openTx(b.dataset.action)));
$("transactionForm").addEventListener("submit",e=>{
 if(e.submitter && e.submitter.value==="cancel")return;
 e.preventDefault();
 const type=$("type").value,description=$("description").value.trim(),amount=Number($("amount").value);
 if(!description||!Number.isFinite(amount)||amount<=0)return;
 const incoming=["Cash in","Receive"].includes(type);
 balance=Math.max(0,balance+(incoming?amount:-amount));
 transactions.unshift({id:Date.now()+Math.random(),type,description,amount,date:new Date().toLocaleString("en-PH",{dateStyle:"medium",timeStyle:"short"})});
 transactions=transactions.slice(0,100);persist();render();$("modal").close();
});
$("editBalance").onclick=()=>{$("newBalance").value=balance;$("balanceModal").showModal();};
$("balanceForm").addEventListener("submit",e=>{
 if(e.submitter && e.submitter.value==="cancel")return;
 e.preventDefault();const n=Number($("newBalance").value);if(Number.isFinite(n)&&n>=0){balance=n;persist();render();$("balanceModal").close();}
});
$("clearAll").onclick=()=>{if(confirm("Clear all demo transactions?")){transactions=[];persist();render();}};
render();
