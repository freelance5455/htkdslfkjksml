/* Arabic support for TriviaBlaze: language toggle, RTL, UI translation, Arabic questions */
let LANG = 'en';
try { if (localStorage.getItem('lang') === 'ar') LANG = 'ar'; } catch (e) {}
function toggleLang() {
  try { localStorage.setItem('lang', LANG === 'ar' ? 'en' : 'ar'); } catch (e) {}
  location.reload();
}

const AR_CATS = [
  { id: 'g', name: 'ثقافة عامة' }, { id: 'i', name: 'إسلاميات' }, { id: 's', name: 'علوم' },
  { id: 'geo', name: 'جغرافيا' }, { id: 'h', name: 'تاريخ' }, { id: 'sp', name: 'رياضة' }
];

// [question, correct, wrong1, wrong2, wrong3]
const AR_BANK = {
  g: [
    ['كم عدد حروف اللغة العربية؟', '28', '26', '29', '30'],
    ['ما هو أسرع حيوان بري؟', 'الفهد', 'الأسد', 'الحصان', 'الغزال'],
    ['ما هي عملة اليابان؟', 'الين', 'الوون', 'اليوان', 'الروبية'],
    ['كم عدد ألوان قوس قزح؟', '7', '5', '6', '8'],
    ['ما هو أكبر محيط في العالم؟', 'المحيط الهادئ', 'المحيط الأطلسي', 'المحيط الهندي', 'المحيط المتجمد الشمالي'],
    ['من العالم المشهور بتطوير المصباح الكهربائي العملي؟', 'توماس إديسون', 'نيكولا تسلا', 'غراهام بيل', 'ألبرت أينشتاين']
  ],
  i: [
    ['كم عدد أركان الإسلام؟', '5', '4', '6', '7'],
    ['ما هي أطول سورة في القرآن الكريم؟', 'البقرة', 'آل عمران', 'النساء', 'المائدة'],
    ['كم عدد سور القرآن الكريم؟', '114', '110', '112', '120'],
    ['في أي شهر يصوم المسلمون؟', 'رمضان', 'شعبان', 'شوال', 'محرم'],
    ['ما اسم أول مسجد بُني في الإسلام؟', 'مسجد قباء', 'المسجد النبوي', 'المسجد الحرام', 'المسجد الأقصى'],
    ['كم عدد الصلوات المفروضة في اليوم؟', '5', '3', '4', '6']
  ],
  s: [
    ['ما هو أكبر كوكب في المجموعة الشمسية؟', 'المشتري', 'زحل', 'الأرض', 'نبتون'],
    ['ما الرمز الكيميائي للماء؟', 'H2O', 'CO2', 'O2', 'NaCl'],
    ['كم عدد عظام جسم الإنسان البالغ؟', '206', '186', '256', '300'],
    ['ما الغاز الذي نتنفسه ونحتاجه للحياة؟', 'الأكسجين', 'النيتروجين', 'ثاني أكسيد الكربون', 'الهيدروجين'],
    ['أي كوكب يُعرف بالكوكب الأحمر؟', 'المريخ', 'الزهرة', 'عطارد', 'المشتري'],
    ['ما هو أقرب نجم إلى الأرض؟', 'الشمس', 'القمر', 'المريخ', 'الزهرة']
  ],
  geo: [
    ['ما هي عاصمة اليمن؟', 'صنعاء', 'عدن', 'تعز', 'الحديدة'],
    ['ما هي أكبر قارة من حيث المساحة؟', 'آسيا', 'أفريقيا', 'أوروبا', 'أمريكا الشمالية'],
    ['ما هي عاصمة مصر؟', 'القاهرة', 'الإسكندرية', 'الجيزة', 'أسوان'],
    ['ما هي أكبر دولة عربية من حيث المساحة؟', 'الجزائر', 'السعودية', 'السودان', 'ليبيا'],
    ['ما هي عاصمة السعودية؟', 'الرياض', 'جدة', 'مكة المكرمة', 'الدمام'],
    ['ما اسم أعلى جبل في العالم؟', 'إيفرست', 'كليمنجارو', 'مون بلان', 'ألب']
  ],
  h: [
    ['من هو أول الخلفاء الراشدين؟', 'أبو بكر الصديق', 'عمر بن الخطاب', 'عثمان بن عفان', 'علي بن أبي طالب'],
    ['إلى أي مدينة هاجر النبي ﷺ؟', 'المدينة المنورة', 'الطائف', 'دمشق', 'القدس'],
    ['من هو القائد الذي قاد فتح الأندلس؟', 'طارق بن زياد', 'خالد بن الوليد', 'صلاح الدين', 'عقبة بن نافع'],
    ['من هو القائد الذي حرّر القدس من الصليبيين؟', 'صلاح الدين الأيوبي', 'محمد الفاتح', 'عمر المختار', 'قطز'],
    ['من فتح القسطنطينية عام 1453م؟', 'محمد الفاتح', 'سليمان القانوني', 'صلاح الدين', 'هارون الرشيد'],
    ['ما هي عاصمة الدولة العباسية؟', 'بغداد', 'دمشق', 'القاهرة', 'قرطبة']
  ],
  sp: [
    ['كم عدد لاعبي فريق كرة القدم داخل الملعب؟', '11', '10', '9', '12'],
    ['كل كم سنة تقام بطولة كأس العالم لكرة القدم؟', '4', '2', '3', '5'],
    ['أي دولة فازت بكأس العالم 2022؟', 'الأرجنتين', 'فرنسا', 'البرازيل', 'كرواتيا'],
    ['كم مدة مباراة كرة القدم في الوقت الأصلي؟', '90 دقيقة', '80 دقيقة', '100 دقيقة', '120 دقيقة'],
    ['أي رياضة تُلعب بالريشة والمضرب؟', 'الريشة الطائرة', 'التنس', 'الإسكواش', 'كرة الطاولة'],
    ['كم عدد حلقات شعار الألعاب الأولمبية؟', '5', '4', '6', '7']
  ]
};

// Returns data in the same shape as the Open Trivia DB so the rest of the app is unchanged
async function getQuestionsData(url) {
  if (LANG !== 'ar') { const r = await fetch(url); return r.json(); }
  const pool = [];
  AR_CATS.forEach(c => {
    if (cfg.cat === 'any' || cfg.cat === c.id) AR_BANK[c.id].forEach(x => pool.push({ c: c.name, x }));
  });
  pool.sort(() => Math.random() - 0.5);
  return {
    results: pool.slice(0, cfg.num).map(({ c, x }) => ({
      question: x[0], correct_answer: x[1], incorrect_answers: x.slice(2), category: c
    }))
  };
}

const AR_UI = {
  'How much do you really know?': 'كم تعرف فعلاً؟', 'Category': 'التصنيف', 'Difficulty': 'الصعوبة',
  'Questions': 'الأسئلة', 'Time Limit': 'وقت السؤال', 'Any': 'الكل', 'Any Category': 'كل التصنيفات',
  'Easy': 'سهل', 'Medium': 'متوسط', 'Hard': 'صعب', 'Off': 'بدون', 'Single Player': 'لعب فردي', 'Welcome,': 'أهلاً،', 'Player': 'أيها اللاعب', 'Best Score': 'أفضل نتيجة', 'Correct': 'صحيحة', 'Wrong': 'خاطئة', 'Play Again': 'العب مجدداً',
  'Multiplayer': 'لعب جماعي', 'Loading…': 'جارٍ التحميل…', 'Score:': 'النقاط:',
  'Next Question →': 'السؤال التالي ←', 'See Results': 'عرض النتيجة', '⌂ Home': '⌂ الرئيسية',
  'Host': 'إنشاء غرفة', 'Join': 'انضمام', 'Back': 'رجوع', 'Enter your display name': 'اكتب اسمك',
  'Continue': 'متابعة', 'Signing in…': 'جارٍ الدخول…', 'Creating…': 'جارٍ الإنشاء…',
  'Joining…': 'جارٍ الانضمام…', 'Room Code': 'رمز الغرفة', 'Leave': 'خروج',
  'Waiting for players to join…': 'بانتظار انضمام اللاعبين…', 'Start Game': 'ابدأ اللعبة',
  'Enter Room Code': 'اكتب رمز الغرفة', 'Waiting for host to start…': 'بانتظار أن يبدأ المضيف…',
  'Waiting for others…': 'بانتظار البقية…', 'Final Results': 'النتائج النهائية',
  'Room Closed': 'تم إغلاق الغرفة', 'Back to Home': 'العودة للرئيسية', 'Done': 'تم', 'You': 'أنت',
  'The host has left the game. The room is no longer available.': 'غادر المضيف اللعبة ولم تعد الغرفة متاحة.',
  '⏱ Time Out': '⏱ انتهى الوقت', '✓ Correct': '✓ صحيحة', '✗ Wrong': '✗ خاطئة',
  'Outstanding': 'ممتاز جداً', 'Great job': 'أحسنت', 'Not bad': 'ليس سيئاً', 'Better luck next time': 'حظ أوفر المرة القادمة',
  'Please enter a name.': 'اكتب اسمك من فضلك.', 'Enter a 6-character room code.': 'اكتب رمز الغرفة (6 خانات).',
  'Room not found. Check the code and try again.': 'الغرفة غير موجودة، تأكد من الرمز.',
  'This game has already started or ended.': 'اللعبة بدأت أو انتهت.',
  'This game has already started or is full.': 'اللعبة بدأت أو الغرفة ممتلئة.',
  'This room is full (6 players max).': 'الغرفة ممتلئة (6 لاعبين كحد أقصى).',
  'Could not authenticate. Check your connection and try again.': 'تعذّر الدخول، تأكد من الإنترنت.'
};
const AR_RX = [
  [/^Question (\d+) of (\d+)$/, 'السؤال $1 من $2'], [/^(\d+) Questions$/, '$1 سؤال'],
  [/^(\d+) seconds$/, '$1 ثانية'], [/^(\d+)% correct$/, '$1% صحيحة'], [/^Q(\d+):$/, 'س$1:']
];

function arText(v) {
  const t = v.trim();
  if (!t) return v;
  let r = AR_UI[t];
  if (!r) for (const [re, rep] of AR_RX) if (re.test(t)) { r = t.replace(re, rep); break; }
  if (!r) { r = t.replace('Correct:', 'الصحيح:').replace('Your answer:', 'إجابتك:'); if (r === t) return v; }
  return v.replace(t, r);
}
function arWalk(n) {
  if (n.nodeType === 3) { const nv = arText(n.nodeValue); if (nv !== n.nodeValue) n.nodeValue = nv; }
  else if (n.nodeType === 1 && n.tagName !== 'SCRIPT' && n.tagName !== 'STYLE') n.childNodes.forEach(arWalk);
}

document.addEventListener('DOMContentLoaded', () => {
  const b = document.createElement('button');
  b.className = 'lang-btn';
  b.textContent = LANG === 'ar' ? 'English' : 'عربي';
  b.onclick = toggleLang;
  document.body.appendChild(b);
  if (LANG !== 'ar') return;
  document.documentElement.lang = 'ar';
  document.documentElement.dir = 'rtl';
  document.title = 'اختبار المعلومات';
  const nm = document.getElementById('mp-name-input');
  if (nm) nm.placeholder = 'اسمك…';
  arWalk(document.body);
  new MutationObserver(ms => ms.forEach(m => {
    if (m.type === 'characterData') arWalk(m.target); else m.addedNodes.forEach(arWalk);
  })).observe(document.body, { childList: true, subtree: true, characterData: true });
});
