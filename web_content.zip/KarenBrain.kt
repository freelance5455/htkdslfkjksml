package com.karen.assistant

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Şimdilik kural tabanlı (internetsiz). Sonra parse() yerine
 * bir yapay zeka API'si koyarsın; execute() aynı JSON'u çalıştırır.
 */
class KarenBrain(private val ctx: Context, private val speak: (String) -> Unit) {

    private val tr = Locale.forLanguageTag("tr-TR")

    fun handle(raw: String) {
        val json = parse(raw.lowercase(tr).trim())
        execute(JSONObject(json))
    }

    // Konuşmayı JSON komutuna çevirir
    private fun parse(t: String): String = when {
        "saat" in t ->
            """{"action":"tell_time"}"""
        "fener" in t || "el feneri" in t ->
            """{"action":"torch","state":"${if ("kapat" in t || "söndür" in t) "off" else "on"}"}"""
        t.endsWith(" aç") || t.endsWith(" başlat") || t.endsWith(" çalıştır") -> {
            val target = t.removeSuffix(" aç").removeSuffix(" başlat").removeSuffix(" çalıştır").trim()
            """{"action":"open_app","target":"$target"}"""
        }
        "merhaba" in t || "selam" in t ->
            """{"action":"say","text":"Merhaba Peter. Emrindeyim."}"""
        else ->
            """{"action":"say","text":"Bunu henüz öğrenmedim Peter."}"""
    }

    private fun execute(cmd: JSONObject) {
        when (cmd.getString("action")) {
            "tell_time" -> speak("Saat " + SimpleDateFormat("HH:mm", tr).format(Date()))
            "torch" -> setTorch(cmd.getString("state") == "on")
            "open_app" -> openApp(cmd.getString("target"))
            "say" -> speak(cmd.getString("text"))
        }
    }

    private fun setTorch(on: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList[0], on)
            speak(if (on) "Fener açık." else "Fener kapalı.")
        } catch (e: Exception) {
            speak("Fenere erişemedim.")
        }
    }

    private fun openApp(name: String) {
        val pm = ctx.packageManager
        val apps = pm.getInstalledApplications(0).filter { pm.getLaunchIntentForPackage(it.packageName) != null }
        fun label(i: android.content.pm.ApplicationInfo) = pm.getApplicationLabel(i).toString().lowercase(tr)

        val match = apps.firstOrNull { label(it) == name } ?: apps.firstOrNull { name in label(it) }
        val intent: Intent? = match?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            speak("${label(match)} açılıyor.")
        } else {
            speak("$name diye bir uygulama bulamadım.")
        }
    }
}
