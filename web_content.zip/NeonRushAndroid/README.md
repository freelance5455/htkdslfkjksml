# NEON RUSH — Android

Projet Android prêt à ouvrir dans Android Studio.

## Inclus
- Jeu HTML local intégré dans WebView, sans Internet.
- Écran de chargement natif NEON RUSH.
- Plein écran immersif portrait.
- Bouton QUITTER connecté à Android.
- Vibrations sur tir, dégâts, pouvoirs et destruction d'ennemis.
- Icône Android adaptive + icône legacy.
- Musique synthwave et effets sonores du jeu conservés.

## Compiler l'APK
1. Ouvrir le dossier `NeonRushAndroid` dans Android Studio.
2. Laisser Gradle synchroniser le projet.
3. Build > Build APK(s).
4. L'APK de debug sera dans `app/build/outputs/apk/debug/`.
