package com.neonrush.app;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView web;
    private FrameLayout root;
    private View splash;
    private long pageReadyAt = 0;

    private void immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        immersive();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5, 6, 13));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReadyAt = System.currentTimeMillis();
                new Handler().postDelayed(() -> hideSplash(), 650);
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.setBackgroundColor(Color.rgb(7, 9, 20));
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        showSplash();
        web.loadUrl("file:///android_asset/index.html");
    }

    private void showSplash() {
        FrameLayout box = new FrameLayout(this);
        box.setBackgroundColor(Color.rgb(5, 6, 13));

        ImageView icon = new ImageView(this);
        icon.setImageResource(com.neonrush.app.R.mipmap.ic_launcher);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(170), dp(170));
        ip.gravity = Gravity.CENTER;
        ip.bottomMargin = dp(75);
        box.addView(icon, ip);

        TextView title = new TextView(this);
        title.setText("NEON RUSH");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, dp(55));
        tp.gravity = Gravity.CENTER;
        tp.topMargin = dp(120);
        box.addView(title, tp);

        TextView loading = new TextView(this);
        loading.setText("CHARGEMENT…");
        loading.setTextColor(Color.rgb(96, 234, 255));
        loading.setTextSize(12);
        loading.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, dp(40));
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        lp.bottomMargin = dp(50);
        box.addView(loading, lp);

        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(42), dp(42));
        pp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        pp.bottomMargin = dp(85);
        box.addView(progress, pp);

        splash = box;
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
    }

    private void hideSplash() {
        if (splash != null) {
            root.removeView(splash);
            splash = null;
        }
        immersive();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    public class AndroidBridge {
        @JavascriptInterface public void quit() {
            runOnUiThread(() -> finishAndRemoveTask());
        }
        @JavascriptInterface public void vibrate(int ms) {
            if (ms < 1) return;
            Vibrator vibrator;
            if (Build.VERSION.SDK_INT >= 31) {
                VibratorManager vm = (VibratorManager)getSystemService(VIBRATOR_MANAGER_SERVICE);
                vibrator = vm.getDefaultVibrator();
            } else {
                vibrator = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            }
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(Math.min(ms, 1000), VibrationEffect.DEFAULT_AMPLITUDE));
                else vibrator.vibrate(ms);
            }
        }
    }

    @Override protected void onResume() { super.onResume(); immersive(); if (web != null) web.onResume(); }
    @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }
    @Override public void onBackPressed() { finishAndRemoveTask(); }
}
