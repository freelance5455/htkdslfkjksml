# Pequeños Grandes Aprendices — proyecto Android preparado

**Versión del proyecto:** 0.8.0  
**Estado honesto:** proyecto web + configuración de Capacitor y automatización para solicitar un APK de prueba. No incluye un APK compilado y probado en este paquete.

## La forma más práctica desde tu celular (sin pagar un servicio de compilación)

Este ZIP incluye `.github/workflows/android-apk.yml`. Al subir el proyecto a un repositorio de GitHub, GitHub Actions puede instalar las herramientas y compilar un **APK de prueba (debug)** en sus servidores. En un repositorio público, el uso estándar de GitHub Actions suele tener cuota gratuita, sujeto a las condiciones y límites vigentes de GitHub.

1. Descarga y descomprime el ZIP en el teléfono.
2. En el navegador del celular, crea/inicia sesión en GitHub y crea un repositorio nuevo. Para este primer ensayo, puede ser público para simplificar el uso de minutos gratuitos; no incluyas claves ni datos personales.
3. Sube el contenido de la carpeta del proyecto al repositorio (incluida la carpeta oculta `.github/workflows`; si la interfaz móvil no permite cargar carpetas/archivos ocultos, habrá que usar la vista web de escritorio o cargar el archivo de flujo por separado).
4. Abre la pestaña **Actions**, habilita los flujos si GitHub lo pide y ejecuta **Crear APK de prueba Android** con **Run workflow**, o haz un cambio en la rama principal.
5. Cuando termine en verde, abre esa ejecución y descarga el artefacto `pequenos-grandes-aprendices-apk-debug`. Descomprime el artefacto y toca `app-debug.apk` para probarlo en tu Android. El teléfono podría pedirte autorización para instalar desde esa fuente; instala solo el archivo generado por tu propio repositorio.

La primera compilación puede fallar por incompatibilidades o cambios de dependencias. Si pasa, comparte el texto del error (nunca contraseñas o claves) y se corrige. El flujo también revisa la sintaxis JavaScript antes de compilar.

## Si trabajas en una computadora en el futuro

Requisitos de Capacitor 8: Node.js 22+, Android Studio 2025.2.1 o posterior y Android SDK instalado. Desde esta carpeta:

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

## Importante: APK de prueba no es publicación

- El APK `debug` sirve para probar; **no es el AAB firmado de producción para Google Play**.
- No subas contraseñas, llaves de firma ni datos personales al repositorio.
- Antes de publicar hay que probar en un Android real, revisar el guardado del progreso y los flujos, corregir accesibilidad y botón Atrás, y verificar las políticas vigentes de Google Play.
- La política de privacidad incluida es un borrador, no debe publicarse sin completar con las prácticas reales de la app y alojarla en una URL accesible.
- La zona para adultos de la demo es una barrera de interfaz básica, no seguridad fuerte.
- La aplicación no lleva anuncios ni compras activas en esta versión.

Documentación: https://capacitorjs.com/docs/getting-started/environment-setup y https://docs.github.com/actions
