# Estado y límites de esta versión

- Incluye la aplicación web existente y configuración inicial de Capacitor 8.
- Incluye un flujo de GitHub Actions para generar un APK debug al subir el proyecto a GitHub.
- El archivo APK no está incluido: requiere ejecutar el flujo en GitHub Actions o compilar en un entorno Android.
- No se ha podido probar la app dentro de un emulador/dispositivo Android en este entorno.
- No es una versión de producción ni un AAB firmado para Play Store.
- No incluye SDK de anuncios ni compras integradas.
- El borrador de privacidad debe verificarse contra el comportamiento real antes de publicar.
