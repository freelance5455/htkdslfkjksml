# Plan de pruebas antes de publicar

## Funciones principales
- [ ] Navegar a cada sección y regresar al inicio.
- [ ] Probar abecedario completo (incluida Ñ) y audio con/sin voces instaladas.
- [ ] Probar números, conteo, formas, desafío, memoria y sus respuestas.
- [ ] Dibujar con dedo, cambiar colores, borrar, limpiar y guardar.
- [ ] Practicar trazos y cambiar letras; redimensionar pantalla.
- [ ] Abrir cada lámina para colorear, pintar partes, deshacer y reiniciar.
- [ ] Probar español, inglés y portugués.
- [ ] Guardar/cargar perfil y progreso; borrar progreso y confirmar que se elimina.
- [ ] Probar exportación de resumen y descargas dentro de Android WebView.

## Android y estabilidad
- [ ] Probar al menos en un Android de gama baja y otro más reciente.
- [ ] Revisar pantalla pequeña, orientación vertical, zoom del sistema y teclado.
- [ ] Revisar botón Atrás de Android desde cada pantalla.
- [ ] Cerrar y volver a abrir: verificar persistencia y ausencia de datos inesperados.
- [ ] Verificar modo avión y primer inicio sin conexión.
- [ ] Verificar que no se soliciten permisos innecesarios.
- [ ] Comprobar accesibilidad: foco, etiquetas, contraste y objetivos táctiles.
- [ ] Registrar fallos con pasos reproducibles; no marcar como aprobado sin probarlo.

## Privacidad y público infantil
- [ ] Decidir edades objetivo reales y completar la sección Público objetivo y contenido.
- [ ] Revisar todas las librerías/SDK incluidos y sus políticas para niños.
- [ ] Publicar una política de privacidad coherente con el comportamiento real.
- [ ] Completar Seguridad de datos y clasificación de contenido con información verdadera.
- [ ] No incluir anuncios hasta verificar SDK, formatos, consentimiento y requisitos de Families.
- [ ] Confirmar que el acceso de adultos no se presenta como seguridad fuerte.

## Publicación
- [ ] Confirmar package ID definitivo y nombre de desarrollador.
- [ ] Generar AAB firmado en entorno Android compatible.
- [ ] Probar AAB por canal interno antes de producción.
- [ ] Cumplir requisitos de pruebas de la cuenta y requisitos vigentes de Play Console.
- [ ] Preparar icono, capturas reales, descripción y ficha de tienda.
