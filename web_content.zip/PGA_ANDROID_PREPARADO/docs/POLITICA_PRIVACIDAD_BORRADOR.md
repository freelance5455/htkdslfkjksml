# Borrador de política de privacidad — NO publicar sin completar

**Estado: borrador pendiente de revisión.** Esta plantilla no es asesoramiento legal ni una política final.

Última actualización: [COMPLETAR FECHA]
Responsable: [COMPLETAR NOMBRE/ENTIDAD Y CONTACTO]
Contacto de privacidad: [COMPLETAR CORREO]

## Qué hace la app
Pequeños Grandes Aprendices ofrece actividades educativas de letras, números, dibujo, trazos, memoria y vocabulario.

## Datos
La versión de prueba está diseñada para no requerir cuenta ni conexión a un servidor propio. Puede guardar progreso localmente en el almacenamiento de la aplicación/navegador. Debe verificarse el comportamiento exacto en la versión Android final.

## Datos de menores
No introduzcas nombres completos, direcciones, fotos ni otros datos personales de menores en la demo. Antes de publicar, el responsable debe verificar el almacenamiento, las bibliotecas y cualquier servicio de terceros para describir fielmente todos los datos tratados.

## Terceros y publicidad
La demo entregada no incorpora un SDK publicitario. Si se agregan anuncios, analítica, enlaces externos u otros SDK, esta política debe actualizarse para describir los proveedores, los datos, las finalidades, los controles parentales y los mecanismos exigidos por la ley y Google Play Families.

## Conservación y eliminación
El progreso puede permanecer guardado localmente hasta que se borre desde la aplicación o se eliminen sus datos del dispositivo. Esta conducta debe confirmarse en la versión Android.

## Cambios y contacto
[COMPLETAR procedimiento de cambios y contacto del responsable].

**No publicar este borrador tal cual:** completar todos los campos, comprobar el comportamiento real de la app y obtener revisión legal apropiada para los mercados donde se distribuirá.
