# Build the RND Miner APK
Android Studio (Koala or newer): File > Open this folder > wait for Gradle sync > Build > Build APK(s).
Output: app/build/outputs/apk/debug/app-debug.apk   Install: `adb install app-debug.apk`
CLI: JDK 17, Android SDK 34 (ANDROID_HOME set), Gradle 8.7: run `gradle wrapper` once, then `./gradlew assembleDebug`.
The app is app/src/main/assets/index.html (unchanged), served at https://appassets.androidplatform.net/assets/index.html
