#!/bin/bash
cd "$(dirname "$0")"
export ANDROID_SDK_ROOT=/root/Android/Sdk
export ANDROID_HOME=/root/Android/Sdk
export PATH=$PATH:$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools
./gradlew assembleRelease
echo "APK gerado em: app/build/outputs/apk/release/app-release.apk"
