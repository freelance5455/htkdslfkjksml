# Futebol 3D - App Android

Este é o seu jogo Futebol 3D como app Android.

## Arquivos dentro
- `app/src/main/assets/index.html` — seu jogo completo
- `app/src/main/assets/three.min.js` — biblioteca Three.js (será baixada da internet ao instalar, ou carregue offline)
- `app/src/main/java/.../MainActivity.java` — abre o jogo em tela cheia

## Gerar o APK

### Opção 1: Android Studio (recomendado)
1. Baixe o **Android Studio** em https://developer.android.com/studio
2. Abra esta pasta em **File > Open**
3. Espere sincronizar o Gradle (primeira vez é lento)
4. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**
5. O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk` (teste) ou `app/build/outputs/apk/release/app-release.apk` (publicação)

### Opção 2: Linha de comando (Linux/Mac)
```bash
./gradlew assembleDebug    # para testar
./gradlew assembleRelease  # para publicar
```

## Instalar no celular

### Debug APK (testar rapidinho)
```bash
./gradlew installDebug
```

### Release APK (publicar na Play Store)
Você precisa assinar com sua chave:
```bash
./gradlew bundleRelease
```
O arquivo `.aab` fica em `app/build/outputs/bundle/release/app-release.aab` e é o que você envia para a Google Play.

## Funcionamento no app
✓ Partida contra robôs
✓ Cofre com itens
✓ Evento Diamante (Royale)
✓ Configurar HUD
✓ Perfil e ID
✗ Salas online (requer conexão ao servidor Claude)
✗ Buscar amigos por ID (requer servidor Claude)
✗ Enviar diamantes (requer servidor Claude)

Tudo é salvo localmente no aparelho.

## Modificar o jogo
Se quiser editar o jogo depois, mude o arquivo `app/src/main/assets/index.html` e rebuild.

## Dúvidas sobre Play Store?
- Você precisa de uma **conta Google Play Developer** (paga, ~$25 usd uma vez)
- Adicione fotos da loja, descrição, política de privacidade, etc no console
- Versões de teste podem ser feitas com ABD ou TestFlight antes de publicar
