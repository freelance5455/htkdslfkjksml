KART F2 — V1
Projeto leve de jogo 2D de corrida, offline.

Inclui: menu, garagem, veículos, moedas, pista aberta, corrida, duas faixas,
trânsito aleatório, colisão sem capotamento, troca de faixa, aceleração,
freio, marchas, ligar/desligar motor, clima (sol/tarde/noite/amanhecer/neve),
física visual de inclinação e velocímetro.

A V1 usa áudio de motor sintetizado localmente para continuar leve e offline.
A capa é uma imagem 512x512 separada em assets/kart_f2_cover_512.png.

Controles de toque: ⬆ ⬇ ◀ ▶ 🔑. No teclado: setas, A/D, espaço, E e 1–6.
