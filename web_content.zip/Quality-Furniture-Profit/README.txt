QUALITY FURNITURE PROFIT  -  App package
=========================================

What is inside
  index.html            the app
  manifest.webmanifest  app name, colours and icons
  sw.js                 lets the app work offline
  icons/                app icons

HOW TO GET IT ON YOUR PHONE OR COMPUTER AS AN APP
An app like this must be opened from a web address (https). Follow these steps once.

1) Put the folder online (free, about 2 minutes)
   - Go to https://app.netlify.com/drop
   - Drag this whole folder (not the zip) onto the page.
   - Netlify gives you a link such as https://your-name.netlify.app
     (GitHub Pages or Vercel work the same way.)

2) Install it
   - Android (Chrome): open the link, tap "Install app" on the page
     (or the menu with three dots, then "Install app").
   - iPhone (Safari): open the link, tap Share, then "Add to Home Screen".
   - Windows / Mac (Chrome or Edge): open the link and click the install icon
     in the address bar, or the "Install app" button on the page.
   The app then opens in its own window with the name "Quality Furniture Profit".

3) Want a real .apk (Android) or .exe / .msix (Windows) file?
   - Go to https://www.pwabuilder.com, paste your Netlify link and follow the steps.

TO TRY IT ON YOUR OWN COMPUTER FIRST
   - Open a terminal in this folder and run:   python -m http.server 8000
   - Open  http://localhost:8000  in Chrome.

GOOD TO KNOW
   - Sales are saved inside the browser/app on each device. Phone and computer do not share data.
   - Export to Excel regularly as a backup. The first time you use Export, the device needs internet
     (it loads the Excel tool once and remembers it).
   - After you change any file, change VERSION in sw.js (for example qf-profit-v2)
     so devices pick up the new version.
