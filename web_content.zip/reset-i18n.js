export const resetUi = {
  nl: { resetMenu: 'App Resetten', resetTitle: 'App resetten?', resetWarning: 'Weet je zeker dat je alle gegevens wilt wissen? Dit kan niet ongedaan worden gemaakt.', resetConfirm: 'Ja, wis alles', resetCancel: 'Nee, annuleren' },
  en: { resetMenu: 'Reset App', resetTitle: 'Reset the app?', resetWarning: 'Are you sure you want to erase all data? This cannot be undone.', resetConfirm: 'Yes, erase everything', resetCancel: 'No, cancel' },
  de: { resetMenu: 'App zurücksetzen', resetTitle: 'App zurücksetzen?', resetWarning: 'Möchtest du wirklich alle Daten löschen? Dieser Vorgang kann nicht rückgängig gemacht werden.', resetConfirm: 'Ja, alles löschen', resetCancel: 'Nein, abbrechen' },
  es: { resetMenu: 'Restablecer App', resetTitle: '¿Restablecer la aplicación?', resetWarning: '¿Seguro que quieres borrar todos los datos? Esta acción no se puede deshacer.', resetConfirm: 'Sí, borrar todo', resetCancel: 'No, cancelar' },
  fr: { resetMenu: "Réinitialiser l'App", resetTitle: 'Réinitialiser l’application ?', resetWarning: 'Voulez-vous vraiment effacer toutes les données ? Cette action est irréversible.', resetConfirm: 'Oui, tout effacer', resetCancel: 'Non, annuler' },
  fy: { resetMenu: 'App Resetsje', resetTitle: 'App opnij ynstelle?', resetWarning: 'Bist wis datst alle gegevens wiskje wolst? Dit kinst net ûngedien meitsje.', resetConfirm: 'Ja, alles wiskje', resetCancel: 'Nee, annulearje' }
};
