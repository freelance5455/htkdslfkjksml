const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetInit = `  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);

  // Resilient profile initialization with fallback safety
  const [profile, setProfile] = useState(() => {
    try {
      return offlineCache?.getProfile?.() || { email: 'juhnkrix.musika@gmail.com', name: 'Prophetic Believer' };
    } catch {
      return { email: 'juhnkrix.musika@gmail.com', name: 'Prophetic Believer' };
    }
  });`;

const replacementInit = `  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [engineInitError, setEngineInitError] = useState<string | null>(null);

  useEffect(() => {
    // Robust Initialization Service wrapper with 'graceful-fallback' state
    const initializeEngines = async () => {
      try {
        if (typeof audioEngine?.init === 'function') {
          await audioEngine.init();
        }
        if (typeof offlineCache?.init === 'function') {
          await offlineCache.init();
        }
      } catch (err) {
        console.warn('One or more engines failed to initialize. Running in graceful-fallback mode.', err);
        setEngineInitError('Audio or Cache Engine loaded in graceful fallback mode.');
      }
    };
    
    initializeEngines();
  }, []);

  // Resilient profile initialization with fallback safety
  const [profile, setProfile] = useState(() => {
    try {
      return offlineCache?.getProfile?.() || { email: 'juhnkrix.musika@gmail.com', name: 'Prophetic Believer' };
    } catch {
      return { email: 'juhnkrix.musika@gmail.com', name: 'Prophetic Believer' };
    }
  });`;

if (code.includes(targetInit)) {
  code = code.replace(targetInit, replacementInit);
}

fs.writeFileSync('src/App.tsx', code);
console.log("App initialized with engines");
