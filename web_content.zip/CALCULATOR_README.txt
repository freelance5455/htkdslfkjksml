TST QUANTITY CALCULATOR — MUBASHIR AMJED
========================================

AREA UNIT OPTION ADDED
The Measurement section now has an "Area result unit" selector:
- Square Feet (sq.ft)
- Square Yard (sq.yd)

The calculated area, each added section, and grand total display in the selected
area unit. The equivalent area is also shown in the measurement result.
Switching the selector updates the display; it does not change the real area,
CFT, aggregate quantities, or bitumen quantities.

CONVERSION
1 square yard = 9 square feet.
Square yards = square feet / 9.
Square feet = square yards × 9.

IMPORTANT CALCULATION RULES
- The app stores/calculates area internally in square feet for consistent formulas.
- Bitumen rates are kg/sq.ft, so bitumen quantity is calculated using the true
  square-foot area even if the display is set to square yards.
- CFT and aggregate quantities are independent of the display-area unit.
- Thickness selector: Feet (ft) or Inches (in). 0.083 ft is approximately
  1 inch; alternatively choose Inches and enter 1.
- Volume = area (sq.ft) × thickness (feet).
- Aggregate split defaults: 55%, 28%, 17%.
- Bitumen defaults: 1st coat 0.13, 2nd coat 0.08, 3rd coat 0.05 kg/sq.ft.
  Third coat is inferred from notebook total 0.26 minus 0.13 minus 0.08;
  confirm this rate against approved BOQ / project specification.

CSV EXPORT
CSV includes both Area sqft and Area sqyd columns, regardless of display setting.

ANDROID USE
Extract the ZIP and open index.html in Chrome. Works offline in browser.
Calculations run locally; no cloud/server. This is a browser calculator, not APK.
