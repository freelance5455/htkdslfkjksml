مشروع تطبيق عطيه جروب للكاشير

مهم: هذا مشروع Android Studio وليس ملف APK جاهزًا للتثبيت.

لإنشاء APK:
1) افتح Android Studio على كمبيوتر.
2) اختر Open وافتح مجلد AtiyaGroupCashier بعد فك الضغط.
3) انتظر اكتمال Gradle Sync وتنزيل مكونات Android المطلوبة.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) سيظهر APK داخل app/build/outputs/apk/debug/ ويمكن نقله للموبايل للتثبيت.

التطبيق يفتح ملف HTML المرفق محليًا داخل WebView، مع تفعيل JavaScript وDOM storage.
قبل إدخال بيانات حقيقية، اختبر البيع والحفظ والتقارير وصدّر نسخة احتياطية. هذا المشروع لم يُبنَ أو يُختبر على جهاز Android في هذه البيئة.
