MaxCall Android Studio project

This is an Android WebView wrapper for the supplied MaxCall HTML demo.
To build: open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Important: This wraps the visual HTML demo only. It is NOT a completed real-time video calling app. Real camera preview, call signaling, and connecting another person require additional Android/WebRTC implementation and a signaling server.
