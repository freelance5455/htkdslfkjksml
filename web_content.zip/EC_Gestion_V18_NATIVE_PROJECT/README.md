# EC Gestion V18 — PDF natif Android

Base: `EC_Gestion_V17_PDF_STYLE.html`.

## PDF natif
Le pont Java expose à la page WebView:
- `AndroidAPI.isNativePdfAvailable()`
- `AndroidAPI.generateNativePdf(html, filename)`

Le HTML est rendu dans un WebView dédié puis exporté avec Android `PrintDocumentAdapter` en A4 portrait. Le PDF est enregistré dans Téléchargements (MediaStore sur Android 10+, dossier Downloads sur versions antérieures).

## Firebase
Le fichier HTML V17 est copié tel quel dans `app/src/main/assets/index.html`. Aucun code Firebase n'est remplacé par le pont PDF.

## Compilation
Ouvrir ce dossier dans Android Studio récent et compiler l'application. Le projet utilise Android Gradle Plugin 8.6.1, compileSdk 35, minSdk 23.
