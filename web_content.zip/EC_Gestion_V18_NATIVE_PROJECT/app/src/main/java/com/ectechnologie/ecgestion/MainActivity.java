package com.ectechnologie.ecgestion;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean pdfBusy = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidAPI");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface public boolean isNativePdfAvailable() { return true; }

        @JavascriptInterface public void generateNativePdf(final String html, final String filename) {
            if (pdfBusy) {
                notifyJs(false, "Une génération PDF est déjà en cours.");
                return;
            }
            if (html == null || html.trim().isEmpty()) {
                notifyJs(false, "Le document PDF est vide.");
                return;
            }
            pdfBusy = true;
            mainHandler.post(() -> renderAndWritePdf(html, sanitizeFilename(filename)));
        }
    }

    private String sanitizeFilename(String name) {
        String n = name == null ? "EC-Gestion-Document.pdf" : name.trim();
        if (!n.toLowerCase(Locale.ROOT).endsWith(".pdf")) n += ".pdf";
        n = n.replaceAll("[^A-Za-z0-9._-]+", "_");
        if (n.length() < 5) n = "EC-Gestion-Document.pdf";
        return n;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void renderAndWritePdf(final String html, final String filename) {
        final WebView pdfWebView = new WebView(this);
        pdfWebView.setBackgroundColor(Color.WHITE);
        pdfWebView.getSettings().setJavaScriptEnabled(true);
        pdfWebView.getSettings().setDomStorageEnabled(true);
        pdfWebView.getSettings().setAllowFileAccess(true);
        pdfWebView.getSettings().setAllowContentAccess(true);
        pdfWebView.setWebChromeClient(new WebChromeClient());

        final String printHtml = html;
        pdfWebView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                // Images in V17 are normally data: URLs. Still wait for every image/font before printing.
                mainHandler.postDelayed(() -> waitForResourcesAndPrint(pdfWebView, filename), 350);
            }
        });
        pdfWebView.loadDataWithBaseURL("file:///android_asset/", printHtml, "text/html", "UTF-8", null);
    }

    private String wrapForPrint(String body) {
        String styles = "";
        String content = body == null ? "" : body;
        return "<!doctype html><html><head><meta charset='utf-8'>" +
                "<meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<style>" +
                "@page{size:A4 portrait;margin:0}" +
                "html,body{margin:0!important;padding:0!important;background:#fff!important}" +
                "body{width:210mm;min-height:297mm;overflow:visible!important}" +
                ".doc-paper{box-sizing:border-box;width:210mm;min-height:297mm;margin:0!important;box-shadow:none!important;overflow:visible!important}" +
                "img{max-width:100%;}" +
                "</style></head><body>" + styles + content + "</body></html>";
    }

    private void waitForResourcesAndPrint(final WebView pdfWebView, final String filename) {
        String js = "(async()=>{try{" +
                "const imgs=[...document.images];await Promise.all(imgs.map(i=>i.complete?Promise.resolve():new Promise(r=>{i.onload=i.onerror=r;setTimeout(r,6000)})));" +
                "if(document.fonts&&document.fonts.ready)await document.fonts.ready;" +
                "await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return 'READY';" +
                "}catch(e){return 'ERR:'+e}})()";
        pdfWebView.evaluateJavascript(js, value -> mainHandler.postDelayed(() -> printWebView(pdfWebView, filename), 150));
    }

    private void printWebView(final WebView pdfWebView, final String filename) {
        final File temp = new File(getCacheDir(), "ec_pdf_" + System.currentTimeMillis() + ".pdf");
        final PrintDocumentAdapter adapter;
        if (Build.VERSION.SDK_INT >= 21) {
            adapter = pdfWebView.createPrintDocumentAdapter("EC-Gestion");
        } else {
            finishPdf(false, "Version Android trop ancienne pour l'export PDF natif.", pdfWebView, temp);
            return;
        }

        final PrintAttributes attributes = new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(new PrintAttributes.Resolution("ec_pdf", "EC PDF", 300, 300))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build();

        adapter.onLayout(null, attributes, new CancellationSignal(), new PrintDocumentAdapter.LayoutResultCallback() {
            @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                writePdf(adapter, attributes, temp, filename, pdfWebView);
            }
            @Override public void onLayoutFailed(CharSequence error) {
                finishPdf(false, "Mise en page PDF impossible : " + error, pdfWebView, temp);
            }
            @Override public void onLayoutCancelled() {
                finishPdf(false, "Génération PDF annulée.", pdfWebView, temp);
            }
        }, null);
    }

    private void writePdf(final PrintDocumentAdapter adapter, final PrintAttributes attributes,
                          final File temp, final String filename, final WebView pdfWebView) {
        try {
            ParcelFileDescriptor pfd = ParcelFileDescriptor.open(temp,
                    ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_TRUNCATE);
            adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, pfd, new CancellationSignal(),
                    new PrintDocumentAdapter.WriteResultCallback() {
                        @Override public void onWriteFinished(PageRange[] pages) {
                            try { pfd.close(); } catch (Exception ignored) {}
                            if (!temp.exists() || temp.length() < 1024) {
                                finishPdf(false, "Le fichier PDF généré est vide ou incomplet.", pdfWebView, temp);
                                return;
                            }
                            try {
                                if (!hasPdfSignature(temp)) {
                                    finishPdf(false, "Signature PDF invalide.", pdfWebView, temp);
                                    return;
                                }
                                String result = saveToDownloads(temp, filename);
                                finishPdf(true, result, pdfWebView, temp);
                            } catch (Exception e) {
                                finishPdf(false, "Enregistrement du PDF impossible : " + e.getMessage(), pdfWebView, temp);
                            }
                        }
                        @Override public void onWriteFailed(CharSequence error) {
                            try { pfd.close(); } catch (Exception ignored) {}
                            finishPdf(false, "Écriture PDF impossible : " + error, pdfWebView, temp);
                        }
                        @Override public void onWriteCancelled() {
                            try { pfd.close(); } catch (Exception ignored) {}
                            finishPdf(false, "Écriture PDF annulée.", pdfWebView, temp);
                        }
                    });
        } catch (Exception e) {
            finishPdf(false, "Ouverture du fichier PDF impossible : " + e.getMessage(), pdfWebView, temp);
        }
    }

    private boolean hasPdfSignature(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[5];
            return in.read(b) == 5 && "%PDF-".equals(new String(b, StandardCharsets.US_ASCII));
        }
    }

    private String saveToDownloads(File source, String filename) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("MediaStore n'a pas créé le fichier.");
            try (InputStream in = new FileInputStream(source); OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) throw new IOException("Flux de sortie indisponible.");
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            } catch (Exception e) {
                resolver.delete(uri, null, null);
                throw e;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Downloads.IS_PENDING, 0);
            resolver.update(uri, done, null, null);
            return "PDF enregistré dans Téléchargements : " + filename;
        }

        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!downloads.exists() && !downloads.mkdirs()) throw new IOException("Impossible de créer Téléchargements.");
        File dest = new File(downloads, filename);
        try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        }
        return "PDF enregistré dans Téléchargements : " + dest.getAbsolutePath();
    }

    private void finishPdf(boolean ok, String message, WebView pdfWebView, File temp) {
        pdfBusy = false;
        try { if (temp != null && temp.exists()) temp.delete(); } catch (Exception ignored) {}
        mainHandler.post(() -> {
            try { pdfWebView.stopLoading(); pdfWebView.destroy(); } catch (Exception ignored) {}
            notifyJs(ok, message);
        });
    }

    private void notifyJs(boolean ok, String message) {
        final String safe;
        try { safe = JSONObject.quote(message == null ? "" : message); }
        catch (Exception e) { return; }
        if (webView == null) return;
        webView.post(() -> webView.evaluateJavascript(
                "window.__nativePdfDone && window.__nativePdfDone(" + (ok ? "true" : "false") + "," + safe + ");", null));
    }

    @Override protected void onDestroy() {
        pdfBusy = false;
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
