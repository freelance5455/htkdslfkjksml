# Dreams Star Heaven para Android

Proyecto Android que muestra el juego web `index.html` en un WebView de pantalla completa y orientación vertical. Incluye los recursos gráficos originales proporcionados.

## Generar APK sin instalar Android Studio

1. Sube el contenido de esta carpeta a un repositorio de GitHub (no subas solo el ZIP).
2. Abre la pestaña **Actions** del repositorio.
3. Selecciona **Build Android APK** y pulsa **Run workflow**.
4. Cuando termine correctamente, descarga el artefacto **DreamsStarHeaven-debug-apk**.
5. Extrae el ZIP descargado para obtener `app-debug.apk`.

El flujo de GitHub Actions compila con Java 17, Gradle 8.7 y Android SDK 35. El APK debug no está firmado para publicación en Google Play.

Las pantallas de compra/recarga que simule el HTML no quedan conectadas a Google Play Billing por esta compilación.
