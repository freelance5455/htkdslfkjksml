MIÉRCOLES 3.1 — OPCIÓN 2 DIRECTA (CLAVE PRECONFIGURADA)

La aplicación está configurada para llamar directamente a la API de Groq usando la clave que proporcionó el propietario. No solicita introducirla en Ajustes ni en el primer mensaje.

IMPORTANTE — SEGURIDAD: esta es una modalidad directa. Una clave incluida en JavaScript, HTML, un ZIP o un APK NO puede mantenerse secreta: una persona con acceso al archivo o a la aplicación puede extraerla y utilizarla. La clave también quedó expuesta al compartirse en una conversación. Recomendación: revocarla en Groq y crear otra; para distribuir la aplicación a otras personas, usar un servidor backend con la clave guardada como secreto.

La app guarda el historial localmente en el almacenamiento del navegador/perfil de la aplicación. No envía el historial de chats a otros usuarios mediante un servicio de sincronización. Distintos dispositivos/perfiles tienen almacenamientos separados; quien use el mismo dispositivo y perfil podría ver los datos locales.

La conexión directa depende de que el navegador/WebView permita solicitudes CORS a api.groq.com y de que el modelo esté disponible para la cuenta. El archivo ha sido revisado estáticamente; no se ha podido verificar una respuesta real con Groq desde el dispositivo del usuario.
