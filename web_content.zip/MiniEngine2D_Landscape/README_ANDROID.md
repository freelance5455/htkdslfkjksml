# Mini Engine 2D — Android (Landscape) + .VarPaEngine

Proyecto Android con WebView + motor 2D y **sistema de mods estilo Psych Engine**.

## Orientación
- `sensorLandscape` (horizontal, ambas direcciones)
- Pantalla completa inmersiva

## Sistema de mods (.VarPaEngine)

```
.VarPaEngine/
└── mods/
    ├── Images/
    │   └── characters/
    │       └── ejemplo.png          ← spritesheet / imagen
    └── characters/
        └── ejemplo.json             ← definición del personaje
```

### Dentro de la APK (assets)
Los mismos archivos se copian a:
- `app/src/main/assets/www/.VarPaEngine/mods/...`
- `app/src/main/assets/www/mods/...`

### En el editor (app)
Pestaña **"Importar images"**:
1. **Importar imágenes (PNG/JPG)** → carga los sprites al juego
2. **Importar JSON de personaje** → carga la definición (como PsychEngine)
3. Luego puedes asignar la imagen a cualquier objeto (Jugador o Sprite) desde el inspector
4. Botón **＋ Sprite (imagen)** crea un objeto pensado para usar texturas

### Formato JSON de personaje (simplificado)
```json
{
  "name": "ejemplo",
  "image": "Images/characters/ejemplo.png",
  "frameWidth": 64,
  "frameHeight": 64,
  "scale": 1.0,
  "animations": {
    "idle": { "frames": [0,1,2,3], "fps": 12, "loop": true },
    "walk": { "frames": [4,5,6,7], "fps": 10, "loop": true }
  },
  "offset": { "x": 0, "y": 0 }
}
```

## Cómo abrir
1. Android Studio → Open → carpeta `MiniEngine2D_Landscape`
2. Ejecutar en dispositivo o emulador

## Notas
- minSdk 23 · targetSdk 35
- Las imágenes importadas en runtime se guardan en memoria (dataURL)
- Para empaquetar sprites definitivos, colócalos en assets antes de compilar
