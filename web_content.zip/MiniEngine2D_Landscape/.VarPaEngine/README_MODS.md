# .VarPaEngine — Sistema de Mods (estilo Psych Engine)

Estructura de carpetas:

```
.VarPaEngine/
└── mods/
    ├── Images/
    │   └── characters/
    │       └── ejemplo.png          ← spritesheet del personaje
    └── characters/
        └── ejemplo.json             ← definición del personaje
```

## Cómo agregar un personaje

1. Coloca el PNG del spritesheet en:
   `mods/Images/characters/NOMBRE.png`

2. Crea el JSON en:
   `mods/characters/NOMBRE.json`

### Formato del JSON (simplificado de Psych Engine)

```json
{
  "name": "mi_personaje",
  "image": "Images/characters/mi_personaje.png",
  "frameWidth": 64,
  "frameHeight": 64,
  "scale": 1.0,
  "animations": {
    "idle": {
      "frames": [0, 1, 2, 3],
      "fps": 12,
      "loop": true
    },
    "walk": {
      "frames": [4, 5, 6, 7],
      "fps": 10,
      "loop": true
    }
  },
  "offset": { "x": 0, "y": 0 }
}
```

## Dentro de la app

- Botón **Importar imágenes**: carga PNGs/JPGs desde el dispositivo y los usa como sprites.
- Los archivos que pongas en `assets/www/mods/` se empaquetan con la APK.
- Para mods externos en el teléfono se puede ampliar más adelante con Storage Access Framework.

## Rutas que el motor busca

| Tipo            | Ruta                                      |
|-----------------|-------------------------------------------|
| Imágenes        | `mods/Images/characters/*.png`            |
| Definiciones    | `mods/characters/*.json`                  |
| (futuro XML)    | `mods/characters/*.xml`                   |
