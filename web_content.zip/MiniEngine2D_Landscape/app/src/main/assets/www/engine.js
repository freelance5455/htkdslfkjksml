/* Mini 2D Engine + .VarPaEngine mods (estilo PsychEngine) */
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

let project = {
  width: 1200,
  height: 650,
  gravity: 1500,
  speed: 280,
  objects: [
    { id: "player", type: "player", x: 120, y: 300, w: 42, h: 52, color: "#55a7ff", name: "Jugador" },
    { id: "ground", type: "block", x: 0, y: 570, w: 1200, h: 80, color: "#55d66b", name: "Suelo" },
    { id: "block1", type: "block", x: 380, y: 470, w: 180, h: 35, color: "#d29b58", name: "Plataforma" },
    { id: "coin1", type: "coin", x: 700, y: 400, w: 28, h: 28, color: "#ffd34d", name: "Moneda" },
    { id: "text1", type: "text", x: 80, y: 100, w: 300, h: 40, color: "#ffffff", text: "Mi primer nivel", fontSize: 32, name: "Texto" }
  ]
};

let selected = "player";
let playing = false;
let keys = {};
let drag = null;
let last = 0;
let state = { vy: 0, onGround: false };

/* ====== SISTEMA DE MODS (.VarPaEngine) ====== */
const assetImages = {};   // name → HTMLImageElement
const characters = {};    // name → character definition JSON

const $ = id => document.getElementById(id);
const obj = id => project.objects.find(o => o.id === id);
const imageListEl = () => $("imageList");
const charListEl = () => $("charList");

function resize() {
  canvas.width = canvas.clientWidth * devicePixelRatio;
  canvas.height = canvas.clientHeight * devicePixelRatio;
  ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
}
addEventListener("resize", resize);
resize();

function uid(t) {
  return t + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
}

function add(type) {
  const o = {
    id: uid(type),
    type,
    x: 160 + project.objects.length * 20,
    y: 180,
    w: type === "player" ? 42 : type === "coin" ? 28 : type === "text" ? 300 : type === "sprite" ? 64 : 120,
    h: type === "player" ? 52 : type === "coin" ? 28 : type === "text" ? 40 : type === "sprite" ? 64 : 40,
    color: type === "player" ? "#55a7ff" : type === "coin" ? "#ffd34d" : type === "text" ? "#fff" : "#d29b58",
    name: type === "player" ? "Jugador" : type === "coin" ? "Moneda" : type === "text" ? "Texto" : type === "sprite" ? "Sprite" : "Bloque"
  };
  if (type === "text") { o.text = "Texto nuevo"; o.fontSize = 28; }
  if (type === "sprite") o.image = null;
  project.objects.push(o);
  selected = o.id;
  refresh();
}

$("addPlayer").onclick = () => add("player");
$("addBlock").onclick = () => add("block");
$("addCoin").onclick = () => add("coin");
$("addText").onclick = () => add("text");
if ($("addSprite")) $("addSprite").onclick = () => add("sprite");

$("deleteObject").onclick = () => {
  project.objects = project.objects.filter(o => o.id !== selected);
  selected = project.objects[0]?.id;
  refresh();
};

function refresh() {
  const s = $("objectSelect");
  s.innerHTML = "";
  project.objects.forEach(o => {
    const p = document.createElement("option");
    p.value = o.id;
    p.textContent = o.name || o.id;
    s.appendChild(p);
  });
  s.value = selected || "";
  renderInspector();
  updateModLists();
  draw();
}

$("objectSelect").onchange = e => {
  selected = e.target.value;
  renderInspector();
  draw();
};

function renderInspector() {
  const o = obj(selected);
  const box = $("inspector");
  box.innerHTML = "";
  if (!o) return;

  let extra = "";
  if (o.type === "text") {
    extra = `<label>Texto<input id="iText" value="${o.text || ""}"></label>
             <label>Tamaño<input id="iFont" type="number" value="${o.fontSize || 28}"></label>`;
  }
  if (o.type === "sprite" || o.type === "player") {
    const imgOptions = Object.keys(assetImages).map(n =>
      `<option value="${n}" ${o.image === n ? "selected" : ""}>${n}</option>`
    ).join("");
    extra += `<label>Imagen (mods)
      <select id="iImage">
        <option value="">— ninguna —</option>
        ${imgOptions}
      </select>
    </label>`;
  }

  box.innerHTML = `
    <label>Nombre<input id="iName" value="${o.name || ""}"></label>
    <div class="row">
      <label>X<input id="iX" type="number" value="${o.x}"></label>
      <label>Y<input id="iY" type="number" value="${o.y}"></label>
    </div>
    <div class="row">
      <label>Ancho<input id="iW" type="number" value="${o.w}"></label>
      <label>Alto<input id="iH" type="number" value="${o.h}"></label>
    </div>
    <label>Color<input id="iColor" type="color" value="${o.color || "#ffffff"}"></label>
    ${extra}`;

  const map = { iName: "name", iX: "x", iY: "y", iW: "w", iH: "h", iColor: "color", iText: "text", iFont: "fontSize" };
  Object.keys(map).forEach(id => {
    const el = $(id);
    if (el) el.oninput = () => {
      const k = map[id];
      o[k] = el.type === "number" ? +el.value : el.value;
      draw();
    };
  });

  if ($("iImage")) {
    $("iImage").onchange = e => {
      o.image = e.target.value || null;
      if (o.image && assetImages[o.image]) {
        const img = assetImages[o.image];
        if (img.naturalWidth) { o.w = img.naturalWidth; o.h = img.naturalHeight; }
      }
      draw();
    };
  }
}

function overlap(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

function update(dt) {
  const p = obj("player") || project.objects.find(o => o.type === "player");
  if (!p) return;
  const l = keys.ArrowLeft || keys.a;
  const r = keys.ArrowRight || keys.d;
  const j = keys.ArrowUp || keys.w || keys[" "];
  p.x = Math.max(0, Math.min(project.width - p.w, p.x));
  p.x += (r - l) * project.speed * dt;
  state.vy += project.gravity * dt;
  p.y += state.vy * dt;
  state.onGround = false;
  for (const o of project.objects.filter(o => o.type === "block")) {
    if (overlap(p, o) && state.vy >= 0 && p.y + p.h - state.vy * dt <= o.y) {
      p.y = o.y - p.h;
      state.vy = 0;
      state.onGround = true;
    }
  }
  if (j && state.onGround) { state.vy = -620; state.onGround = false; }
  if (p.y > project.height + 100) { p.x = 120; p.y = 300; state.vy = 0; }
}

function draw() {
  const s = Math.min(canvas.clientWidth / project.width, canvas.clientHeight / project.height);
  const ox = (canvas.clientWidth - project.width * s) / 2;
  const oy = (canvas.clientHeight - project.height * s) / 2;
  ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
  ctx.save();
  ctx.translate(ox, oy);
  ctx.scale(s, s);
  ctx.fillStyle = "#151922";
  ctx.fillRect(0, 0, project.width, project.height);

  for (const o of project.objects) {
    if (o.type === "text") {
      ctx.fillStyle = o.color;
      ctx.font = `${o.fontSize || 28}px sans-serif`;
      ctx.fillText(o.text || "", o.x, o.y + (o.fontSize || 28));
      continue;
    }
    if (o.image && assetImages[o.image]) {
      try { ctx.drawImage(assetImages[o.image], o.x, o.y, o.w, o.h); }
      catch (e) { ctx.fillStyle = o.color || "#888"; ctx.fillRect(o.x, o.y, o.w, o.h); }
    } else if (o.type === "coin") {
      ctx.fillStyle = o.color;
      ctx.beginPath();
      ctx.arc(o.x + o.w / 2, o.y + o.h / 2, o.w / 2, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = o.color;
      ctx.fillRect(o.x, o.y, o.w, o.h);
    }
    if (!playing && o.id === selected) {
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 2;
      ctx.strokeRect(o.x - 3, o.y - 3, o.w + 6, o.h + 6);
    }
  }
  ctx.restore();
}

function loop(t) {
  const dt = Math.min(0.033, (t - last) / 1000 || 0);
  last = t;
  if (playing) update(dt);
  draw();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

addEventListener("keydown", e => {
  keys[e.key] = true;
  if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(e.key)) e.preventDefault();
});
addEventListener("keyup", e => keys[e.key] = false);

function pos(e) {
  const r = canvas.getBoundingClientRect();
  const s = Math.min(r.width / project.width, r.height / project.height);
  const ox = (r.width - project.width * s) / 2;
  const oy = (r.height - project.height * s) / 2;
  return { x: (e.clientX - r.left - ox) / s, y: (e.clientY - r.top - oy) / s };
}

canvas.onpointerdown = e => {
  if (playing) return;
  const p = pos(e);
  const hit = [...project.objects].reverse().find(o =>
    p.x >= o.x && p.x <= o.x + o.w && p.y >= o.y && p.y <= o.y + o.h
  );
  if (hit) {
    selected = hit.id;
    drag = { dx: p.x - hit.x, dy: p.y - hit.y };
    canvas.setPointerCapture(e.pointerId);
    refresh();
  }
};
canvas.onpointermove = e => {
  if (!drag || playing) return;
  const p = pos(e);
  const o = obj(selected);
  if (o) { o.x = p.x - drag.dx; o.y = p.y - drag.dy; renderInspector(); draw(); }
};
canvas.onpointerup = () => drag = null;

$("play").onclick = () => { playing = true; $("mode").textContent = "JUEGO"; };
$("stop").onclick = () => { playing = false; $("mode").textContent = "EDITOR"; refresh(); };
$("applySettings").onclick = () => {
  project.width = +$("worldW").value;
  project.height = +$("worldH").value;
  project.gravity = +$("gravity").value;
  project.speed = +$("speed").value;
  refresh();
};
$("export").onclick = () => {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(project, null, 2)], { type: "application/json" }));
  a.download = "mi_nivel.json";
  a.click();
};
$("import").onclick = () => $("fileInput").click();
$("fileInput").onchange = e => {
  const r = new FileReader();
  r.onload = () => { project = JSON.parse(r.result); selected = project.objects[0]?.id; refresh(); };
  r.readAsText(e.target.files[0]);
};

/* ====== IMPORTAR IMÁGENES ====== */
function updateModLists() {
  const il = imageListEl();
  const cl = charListEl();
  if (!il || !cl) return;

  il.innerHTML = "";
  const names = Object.keys(assetImages);
  if (names.length === 0) {
    il.innerHTML = '<div class="empty">Ninguna imagen cargada aún</div>';
  } else {
    names.forEach(n => {
      const div = document.createElement("div");
      div.className = "file-item";
      div.innerHTML = `<span>🖼 ${n}</span><button class="tiny" data-img="${n}">Usar</button>`;
      div.querySelector("button").onclick = () => {
        const o = obj(selected);
        if (o) {
          o.image = n;
          const img = assetImages[n];
          if (img && img.naturalWidth) { o.w = img.naturalWidth; o.h = img.naturalHeight; }
          renderInspector();
          draw();
        }
      };
      il.appendChild(div);
    });
  }

  cl.innerHTML = "";
  const cnames = Object.keys(characters);
  if (cnames.length === 0) {
    cl.innerHTML = '<div class="empty">Ningún personaje JSON cargado</div>';
  } else {
    cnames.forEach(n => {
      const div = document.createElement("div");
      div.className = "file-item";
      const c = characters[n];
      div.innerHTML = `<span>📄 ${n}</span><button class="tiny">Crear sprite</button>`;
      div.querySelector("button").onclick = () => {
        const o = {
          id: uid("sprite"), type: "sprite", x: 200, y: 200,
          w: c.frameWidth || 64, h: c.frameHeight || 64,
          color: "#ffffff", name: c.name || n, image: null, character: n
        };
        if (c.image) {
          const base = c.image.split("/").pop().replace(/\.(png|jpg|jpeg|webp)$/i, "");
          if (assetImages[base]) o.image = base;
          else if (assetImages[c.image]) o.image = c.image;
        }
        project.objects.push(o);
        selected = o.id;
        refresh();
      };
      cl.appendChild(div);
    });
  }
}

function loadImageFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = ev => {
      const img = new Image();
      img.onload = () => {
        const name = file.name.replace(/\.(png|jpg|jpeg|webp)$/i, "");
        assetImages[name] = img;
        assetImages[file.name] = img;
        resolve(name);
      };
      img.onerror = reject;
      img.src = ev.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function loadJsonFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target.result);
        const name = data.name || file.name.replace(/\.json$/i, "");
        characters[name] = data;
        if (data.image) {
          data.imageName = data.image.split("/").pop().replace(/\.(png|jpg|jpeg|webp)$/i, "");
        }
        resolve(name);
      } catch (err) { reject(err); }
    };
    reader.onerror = reject;
    reader.readAsText(file);
  });
}

if ($("btnImportImages")) $("btnImportImages").onclick = () => $("imgFileInput").click();
if ($("imgFileInput")) {
  $("imgFileInput").onchange = async e => {
    for (const f of [...e.target.files]) {
      try { await loadImageFile(f); } catch (err) { console.warn("Error imagen", f.name, err); }
    }
    updateModLists();
    refresh();
    e.target.value = "";
  };
}

if ($("btnImportJson")) $("btnImportJson").onclick = () => $("jsonFileInput").click();
if ($("jsonFileInput")) {
  $("jsonFileInput").onchange = async e => {
    for (const f of [...e.target.files]) {
      try { await loadJsonFile(f); } catch (err) { console.warn("Error JSON", f.name, err); }
    }
    updateModLists();
    e.target.value = "";
  };
}

document.querySelectorAll(".tab").forEach(b => {
  b.onclick = () => {
    document.querySelectorAll(".tab").forEach(x => x.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(x => x.classList.remove("active"));
    b.classList.add("active");
    $(b.dataset.tab).classList.add("active");
  };
});

async function tryLoadPackagedExample() {
  for (const path of ["mods/characters/ejemplo.json", ".VarPaEngine/mods/characters/ejemplo.json"]) {
    try {
      const res = await fetch(path);
      if (res.ok) {
        const data = await res.json();
        characters[data.name || "ejemplo"] = data;
        updateModLists();
      }
    } catch (_) {}
  }
}
tryLoadPackagedExample();
refresh();
