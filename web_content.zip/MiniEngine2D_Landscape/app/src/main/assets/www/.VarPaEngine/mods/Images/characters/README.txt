Coloca aquí tus PNG de personajes (ej: ejemplo.png)
