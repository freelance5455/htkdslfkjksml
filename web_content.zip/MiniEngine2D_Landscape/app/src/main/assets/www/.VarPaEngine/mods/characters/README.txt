Coloca aquí tus JSON de personajes (ej: ejemplo.json)
