package com.shadowgametae.miniengine2d;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;
    private static final String ROOT_NAME = ".VarPaEngine";
    private File modsRoot; // /storage/emulated/0/.VarPaEngine

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        requestStorageAccess();
        ensureVarPaFolders();

        web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            settings.setAllowFileAccessFromFileURLs(true);
            settings.setAllowUniversalAccessFromFileURLs(true);
        }
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        // Puente JS ↔ Android (estilo PsychEngine mods)
        web.addJavascriptInterface(new VarPaBridge(), "VarPa");

        web.loadUrl("file:///android_asset/www/index.html");
        setContentView(web);
    }

    private void requestStorageAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                    Toast.makeText(this, "Concede acceso a todos los archivos para usar mods en .VarPaEngine", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    startActivity(intent);
                }
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                }, 1001);
            }
        }
    }

    private void ensureVarPaFolders() {
        try {
            File external = Environment.getExternalStorageDirectory();
            modsRoot = new File(external, ROOT_NAME);
            if (!modsRoot.exists()) modsRoot.mkdirs();

            // Estructura tipo PsychEngine
            String[] dirs = {
                    "mods",
                    "mods/Images",
                    "mods/Images/characters",
                    "mods/characters"
            };
            for (String d : dirs) {
                File f = new File(modsRoot, d);
                if (!f.exists()) f.mkdirs();
            }

            // Archivo de ayuda
            File readme = new File(modsRoot, "LEEME.txt");
            if (!readme.exists()) {
                String text =
                        "=== VarPaEngine / Mini Engine 2D ===\n\n" +
                        "Estructura de mods (estilo PsychEngine):\n\n" +
                        "  .VarPaEngine/\n" +
                        "  └── mods/\n" +
                        "      ├── Images/\n" +
                        "      │   └── characters/\n" +
                        "      │       └── ejemplo.png      ← imágenes de personajes\n" +
                        "      └── characters/\n" +
                        "          └── ejemplo.json         ← definición del personaje\n\n" +
                        "También se aceptan .xml en mods/characters/\n\n" +
                        "Coloca aquí tus archivos y luego pulsa «Importar images» en la app.\n";
                FileOutputStream fos = new FileOutputStream(readme);
                fos.write(text.getBytes(StandardCharsets.UTF_8));
                fos.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Fallback a carpeta de la app
            modsRoot = new File(getExternalFilesDir(null), ROOT_NAME);
            modsRoot.mkdirs();
            new File(modsRoot, "mods/Images/characters").mkdirs();
            new File(modsRoot, "mods/characters").mkdirs();
        }
    }

    /** Puente expuesto a JavaScript como window.VarPa */
    public class VarPaBridge {

        @JavascriptInterface
        public String getModsPath() {
            return modsRoot != null ? modsRoot.getAbsolutePath() : "";
        }

        @JavascriptInterface
        public String listImages() {
            List<String> names = new ArrayList<>();
            try {
                File dir = new File(modsRoot, "mods/Images/characters");
                if (dir.exists()) {
                    File[] files = dir.listFiles();
                    if (files != null) {
                        for (File f : files) {
                            String n = f.getName().toLowerCase();
                            if (f.isFile() && (n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp"))) {
                                names.add(f.getName());
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}
            return String.join("|", names);
        }

        @JavascriptInterface
        public String listCharacterDefs() {
            List<String> names = new ArrayList<>();
            try {
                File dir = new File(modsRoot, "mods/characters");
                if (dir.exists()) {
                    File[] files = dir.listFiles();
                    if (files != null) {
                        for (File f : files) {
                            String n = f.getName().toLowerCase();
                            if (f.isFile() && (n.endsWith(".json") || n.endsWith(".xml"))) {
                                names.add(f.getName());
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}
            return String.join("|", names);
        }

        @JavascriptInterface
        public String loadImageBase64(String fileName) {
            try {
                File f = new File(modsRoot, "mods/Images/characters/" + fileName);
                if (!f.exists() || !f.isFile()) return "";
                byte[] data = readAllBytes(f);
                String mime = "image/png";
                String lower = fileName.toLowerCase();
                if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) mime = "image/jpeg";
                else if (lower.endsWith(".webp")) mime = "image/webp";
                String b64 = Base64.encodeToString(data, Base64.NO_WRAP);
                return "data:" + mime + ";base64," + b64;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public String loadText(String relativePath) {
            try {
                File f = new File(modsRoot, relativePath);
                if (!f.exists()) return "";
                byte[] data = readAllBytes(f);
                return new String(data, StandardCharsets.UTF_8);
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean fileExists(String relativePath) {
            try {
                return new File(modsRoot, relativePath).exists();
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void openModsFolder() {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse(modsRoot.getAbsolutePath());
                intent.setDataAndType(uri, "resource/folder");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(Intent.createChooser(intent, "Abrir carpeta .VarPaEngine"));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Carpeta: " + (modsRoot != null ? modsRoot.getAbsolutePath() : "?"),
                        Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public String ensureFolders() {
            ensureVarPaFolders();
            return modsRoot != null ? modsRoot.getAbsolutePath() : "";
        }
    }

    private byte[] readAllBytes(File f) throws Exception {
        InputStream is = new FileInputStream(f);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
        is.close();
        return bos.toByteArray();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            );
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
