# ANTRO EDU UNM 26
**Tagline:** Teman Belajar Pendidikan Antropologi

Aplikasi web responsif/PWA untuk belajar antropologi. Dapat dipasang di Android melalui browser yang mendukung PWA.

## Cara menjalankan
1. Ekstrak ZIP.
2. Buka folder `antro_edu_unm26`.
3. Untuk uji cepat, buka `index.html` di browser. Beberapa fitur PWA/offline membutuhkan hosting melalui HTTPS atau localhost.
4. Untuk pemasangan di Android: unggah folder ini ke hosting statis HTTPS (mis. GitHub Pages/Netlify), buka alamatnya di Chrome Android, lalu pilih **Install app / Tambahkan ke layar utama**.

## Fitur
- Beranda, pencarian lokal, materi 25 tema.
- Struktur modul: pengertian, latar belakang, konsep, teori/tokoh, contoh, analisis, kesimpulan, referensi awal.
- Katalog artikel jurnal dengan tautan penerbit asli.
- Antropologi Indonesia, kamus istilah, latihan dengan nilai otomatis, panduan tugas.
- Favorit, riwayat materi, nilai latihan disimpan di `localStorage` browser.
- Manifest, ikon, dan service worker untuk PWA.

## Catatan akademik penting
- Materi adalah pengantar ringkas yang perlu diperdalam menggunakan modul dosen, buku, dan sumber primer.
- Katalog jurnal hanya memuat rekaman yang memiliki halaman artikel/penerbit yang dapat ditelusuri. Ringkasan merupakan parafrasa informasi abstrak/metadata yang tampil pada laman penerbit. Untuk rincian metode, halaman, dan sitasi final, buka naskah asli.
- Jangan mengutip metadata yang belum dibaca. Periksa kembali nama penulis, volume, nomor, halaman, DOI, dan gaya sitasi pada PDF/artikel asli.
- Aplikasi ini tidak mengirim data profil, favorit, atau nilai ke server. Data hanya berada di browser/perangkat yang digunakan.
- Belum terhubung ke akun UNM, LMS, atau basis data kampus; tidak ada sinkronisasi antargawai.

## Referensi artikel terverifikasi yang ditanamkan
1. Wahyuddin dkk. (2023), “Nama, Makna dan Identitas Komunitas Adat Kajang di Sulawesi Selatan”, *Jurnal Ilmu Budaya*, 11(1). https://doi.org/10.34050/jib.v11i1.26220
2. Basir (2021), “Understanding sensitive cultural through daily conversation in urban society in Makassar”, *ETNOSIA*, 6(2), 295–306. https://doi.org/10.31947/etnosia.v6i2.19338
3. Nonci dkk. (2023), “The dialectic of globalization and social transformation of Silariang in Makassar, Indonesia”, *ETNOSIA*, 8(1), 127–144. https://doi.org/10.31947/etnosia.v8i1.26149
4. Syaiful (2017), “Kekerasan Kolektif di Perkotaan: Konstruksi dan Representasi Maskulinitas dalam Budaya Masyarakat Makassar”, *ETNOSIA*, 2(1), 95–115. https://doi.org/10.31947/etnosia.v2i1.2957
5. Kasmini & Mursalim (2023), “Perilaku Komunikasi Suku Bajo dalam Berinteraksi dengan Suku Bugis di Dusun Bajoe Kabupaten Bone”, *KAREBA*, 12(1). https://doi.org/10.31947/kareba.v12i1.28011

## Teknologi
HTML, CSS, JavaScript murni; tanpa framework/build step.
