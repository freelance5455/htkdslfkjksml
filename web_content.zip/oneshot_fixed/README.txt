One Shot MCQ - fixed Android build

1) Extract this ZIP on your Android phone.
2) Open one_shot_mcq_quiz.html in your HTML-to-APK app and build a new APK.
3) Open the app: it stays silent on the home screen. Sound starts only after tapping Quiz, with timer beeps and a result chime.
4) Video export renders a 1080x1920 portrait quiz with timer/result audio, similar to a screen recording. It tries to convert the recording to MP4 using FFmpeg.wasm (internet connection and enough RAM/storage required). If MP4 conversion is not supported in the WebView, it automatically saves the recorded video as WebM instead; WebM is a video file but is not MP4.

Important: Some HTML-to-APK wrappers block downloads, MediaRecorder, canvas capture, or WebAssembly. If the export button cannot save any file in that wrapper, use a WebView wrapper that allows MediaRecorder/canvas capture and downloads. This file has not been tested on the user's exact phone.
