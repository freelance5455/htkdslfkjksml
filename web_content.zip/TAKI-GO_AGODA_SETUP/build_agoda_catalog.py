#!/usr/bin/env python3
# Build a compact Agoda hotel catalog for every country present in the CSV.
# Streams rows to per-country JSON files to avoid keeping millions of hotels in RAM.
import argparse, csv, json, os, sys, re

csv.field_size_limit(min(sys.maxsize, 2**31 - 1))
KEEP = ["hotel_id", "hotel_name", "hotel_translated_name", "brand_name", "chain_name",
        "addressline1", "addressline2", "zipcode", "city", "state", "country", "countryisocode",
        "star_rating", "latitude", "longitude", "url", "checkin", "checkout",
        "photo1", "photo2", "photo3", "photo4", "photo5",
        "overview", "rates_from", "rates_currency", "number_of_reviews", "rating_average"]

def main():
    ap = argparse.ArgumentParser(description="Build a per-country hotel catalog from a large Agoda CSV.")
    ap.add_argument("csv_path")
    ap.add_argument("--countries", nargs="+", default=None,
                    help="Optional ISO country codes to include; default = every code found in CSV")
    ap.add_argument("--out", default="agoda_catalog")
    ap.add_argument("--max-overview", type=int, default=600,
                    help="Maximum description length; 0 = no description, -1 = full description")
    a = ap.parse_args()
    wanted = {c.upper() for c in a.countries} if a.countries else None
    os.makedirs(a.out, exist_ok=True)
    handles, counts, names = {}, {}, {}
    total = 0
    try:
        with open(a.csv_path, newline="", encoding="utf-8-sig", errors="replace") as f:
            for row in csv.DictReader(f):
                total += 1
                code = (row.get("countryisocode") or "").strip().upper()
                if not re.fullmatch(r"[A-Z]{2}", code) or (wanted is not None and code not in wanted):
                    continue
                if code not in handles:
                    path = os.path.join(a.out, f"agoda_{code}.json")
                    handles[code] = open(path, "w", encoding="utf-8")
                    handles[code].write("[")
                    counts[code] = 0
                h = {k: (row.get(k) or "").strip() for k in KEEP}
                ov = h.get("overview", "")
                if a.max_overview == 0:
                    h["overview"] = ""
                elif a.max_overview > 0 and len(ov) > a.max_overview:
                    cut = ov[:a.max_overview]
                    h["overview"] = cut[:cut.rfind(" ")] + "…" if " " in cut else cut
                h = {k: v for k, v in h.items() if v}
                if counts[code]:
                    handles[code].write(",")
                json.dump(h, handles[code], ensure_ascii=False, separators=(",", ":"))
                counts[code] += 1
                country_name = (row.get("country") or "").strip()
                if country_name and (code not in names or len(country_name) > len(names[code])):
                    names[code] = country_name
                if total % 500000 == 0:
                    print(f"... {total:,} rows scanned", file=sys.stderr)
    finally:
        for f in handles.values():
            f.write("]")
            f.close()

    countries = [{"code": c, "name": names.get(c, c), "count": counts[c]}
                 for c in sorted(counts, key=lambda x: names.get(x, x).casefold())]
    manifest = {"countries": countries, "total_hotels": sum(counts.values())}
    with open(os.path.join(a.out, "index.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, separators=(",", ":"))
    print(f"تمت قراءة {total:,} سطر.")
    print(f"الدول: {len(countries)} | الفنادق: {manifest['total_hotels']:,}")
    print(f"ملف قائمة الدول: {os.path.join(a.out, 'index.json')}")

if __name__ == "__main__":
    main()
