// Add this route inside your existing Cloudflare Worker fetch handler, before the 404 fallback.
// Required Worker secrets/vars: SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.
// Never put SUPABASE_SERVICE_ROLE_KEY in the HTML or expose it to the browser.

async function handleAgodaCatalog(request, env) {
  const url = new URL(request.url);
  const body = {
    p_city: url.searchParams.get("city") || null,
    p_country: url.searchParams.get("country") || null,
    p_hotel_name: url.searchParams.get("hotelName") || null,
    p_limit: Math.min(50, Math.max(1, Number(url.searchParams.get("limit") || 12)))
  };
  if (!env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) {
    return Response.json({ error: "Agoda catalogue database is not configured" }, { status: 503 });
  }
  const response = await fetch(`${env.SUPABASE_URL.replace(/\/$/, "")}/rest/v1/rpc/search_agoda_hotels`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: env.SUPABASE_SERVICE_ROLE_KEY,
      Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`
    },
    body: JSON.stringify(body)
  });
  const text = await response.text();
  return new Response(text, {
    status: response.status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Cache-Control": "public, max-age=60"
    }
  });
}

// In the Worker fetch handler, route it like this:
// if (url.pathname === "/api/hotels/catalog" && request.method === "GET") return handleAgodaCatalog(request, env);
// if (url.pathname === "/api/hotels/catalog" && request.method === "OPTIONS") return new Response(null, { headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET, OPTIONS", "Access-Control-Allow-Headers": "Content-Type, Authorization" } });
