-- Run in Supabase SQL Editor before importing the Agoda CSV.
create table if not exists public.agoda_hotels (
  hotel_id text, chain_id text, chain_name text, brand_id text, brand_name text,
  hotel_name text, hotel_formerly_name text, hotel_translated_name text,
  addressline1 text, addressline2 text, zipcode text, city text, state text,
  country text, countryisocode text, star_rating text, longitude text, latitude text,
  url text, checkin text, checkout text, numberrooms text, numberfloors text,
  yearopened text, yearrenovated text, photo1 text, photo2 text, photo3 text,
  photo4 text, photo5 text, overview text, rates_from text, continent_id text,
  continent_name text, city_id text, country_id text, number_of_reviews text,
  rating_average text, rates_currency text
);
create index if not exists agoda_hotels_city_idx on public.agoda_hotels (lower(city));
create index if not exists agoda_hotels_country_idx on public.agoda_hotels (lower(country));
create index if not exists agoda_hotels_name_idx on public.agoda_hotels (lower(hotel_name));

-- API-safe search function. It returns catalogue details, not live availability/prices.
create or replace function public.search_agoda_hotels(
  p_city text default null,
  p_country text default null,
  p_hotel_name text default null,
  p_limit integer default 12
)
returns setof public.agoda_hotels
language sql stable security invoker
set search_path = public
as $$
  select h.*
  from public.agoda_hotels h
  where (nullif(trim(p_city), '') is null or h.city ilike '%' || trim(p_city) || '%')
    and (nullif(trim(p_country), '') is null or h.country ilike '%' || trim(p_country) || '%'
         or h.countryisocode ilike '%' || trim(p_country) || '%')
    and (nullif(trim(p_hotel_name), '') is null or h.hotel_name ilike '%' || trim(p_hotel_name) || '%'
         or h.hotel_translated_name ilike '%' || trim(p_hotel_name) || '%')
  order by
    case when nullif(trim(p_hotel_name), '') is not null and h.hotel_name ilike trim(p_hotel_name) then 0 else 1 end,
    case when h.photo1 is not null and h.photo1 <> '' then 0 else 1 end,
    h.hotel_name
  limit greatest(1, least(coalesce(p_limit, 12), 50));
$$;

-- Keep the table private. The Cloudflare Worker should call the function using a server-side secret.
alter table public.agoda_hotels enable row level security;
revoke all on public.agoda_hotels from anon, authenticated;
revoke all on function public.search_agoda_hotels(text,text,text,integer) from public, anon, authenticated;
-- Worker uses service_role key server-side; never place that key in index.html.
grant execute on function public.search_agoda_hotels(text,text,text,integer) to service_role;
