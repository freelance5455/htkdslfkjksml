let equipamentos = [];
let manutencoes = [];
let lubrificacoes = [];

const CHAVES = {
    equipamentos: "lubriagro_equipamentos",
    manutencoes: "lubriagro_manutencoes",
    lubrificacoes: "lubriagro_lubrificacoes",
    login: "lubriagro_login"
};


const GABARITOS_EQUIPAMENTOS = [
 {tipo:"Trator agrícola", nome:"Trator agrícola", pontos:["Motor", "Transmissão", "Sistema hidráulico", "Eixos e articulações"]},
 {tipo:"Colhedora de cana", nome:"Colhedora de cana-de-açúcar", pontos:["Motor", "Sistema hidráulico", "Cortador de base", "Picador", "Rolamentos e articulações"]},
 {tipo:"Colheitadeira de grãos", nome:"Colheitadeira de grãos", pontos:["Motor", "Transmissão", "Plataforma", "Mancais e rolamentos"]},
 {tipo:"Caminhão", nome:"Caminhão agrícola", pontos:["Motor", "Transmissão", "Diferencial", "Cardã", "Pontos de chassis"]},
 {tipo:"Trator de esteira", nome:"Trator de esteira", pontos:["Motor", "Comando final", "Rolos e rodas-guia", "Articulação"]},
 {tipo:"Motoniveladora", nome:"Motoniveladora", pontos:["Motor", "Círculo e lâmina", "Articulação central", "Eixos"]},
 {tipo:"Pá-carregadeira", nome:"Pá-carregadeira", pontos:["Motor", "Braços e pinos", "Eixos", "Sistema hidráulico"]},
 {tipo:"Escavadeira", nome:"Escavadeira hidráulica", pontos:["Motor", "Coroa de giro", "Pinos e buchas", "Material rodante"]},
 {tipo:"Retroescavadeira", nome:"Retroescavadeira", pontos:["Motor", "Pinos e buchas", "Eixos", "Sistema hidráulico"]},
 {tipo:"Pulverizador", nome:"Pulverizador agrícola", pontos:["Motor", "Bomba", "Cardã", "Articulações da barra"]},
 {tipo:"Plantadeira / semeadora", nome:"Plantadeira / semeadora", pontos:["Transmissão", "Mancais", "Articulações", "Dosadores conforme manual"]},
 {tipo:"Distribuidor de fertilizantes", nome:"Distribuidor de fertilizantes", pontos:["Caixa de transmissão", "Mancais", "Cardã", "Esteira ou discos"]},
 {tipo:"Grade / arado", nome:"Grade / arado", pontos:["Mancais", "Cubos", "Articulações", "Pinos"]},
 {tipo:"Carreta agrícola", nome:"Carreta agrícola", pontos:["Cubos de roda", "Pontos de articulação", "Sistema de basculamento"]},
 {tipo:"Transbordo de cana", nome:"Transbordo de cana", pontos:["Cubos", "Pinos e buchas", "Articulações", "Sistema hidráulico"]},
 {tipo:"Roçadeira", nome:"Roçadeira agrícola", pontos:["Caixa de transmissão", "Cardã", "Mancais"]},
 {tipo:"Enfardadeira", nome:"Enfardadeira", pontos:["Caixa de transmissão", "Correntes", "Mancais", "Articulações"]},
 {tipo:"Veículo de apoio", nome:"Veículo de apoio", pontos:["Motor", "Transmissão", "Diferencial", "Pontos do chassi"]},
 {tipo:"Outro", nome:"Outro equipamento agrícola", pontos:["Conforme manual do fabricante"]}
];



// Planos iniciais de referência por tipo de equipamento. Não são dados de manual específico.
const PLANOS_SUGERIDOS = {
 "Trator agrícola": [
  {tipo:"Manutenção preventiva",intervalo:500,unidade:"h",tarefas:"Inspeção geral, correias, mangueiras, arrefecimento, vazamentos e itens de segurança"},
  {tipo:"Lubrificação",intervalo:100,unidade:"h",tarefas:"Lubrificar pontos indicados no manual, pinos e articulações quando aplicável"},
  {tipo:"Óleo e filtro do motor",intervalo:250,unidade:"h",tarefas:"Conferir especificação e programar troca de óleo/filtro somente após confirmar o manual"},
  {tipo:"Filtro de combustível e ar",intervalo:null,unidade:"manual",tarefas:"Inspecionar e substituir conforme indicador, combustível, poeira e manual do modelo"}
 ],
 "Colhedora de cana": [
  {tipo:"Inspeção preventiva",intervalo:50,unidade:"h",tarefas:"Inspecionar corte de base, picador, elevador, correntes, proteções, mangueiras e vazamentos"},
  {tipo:"Lubrificação",intervalo:10,unidade:"h",tarefas:"Conferir pontos de graxa e lubrificar conforme tabela do fabricante"},
  {tipo:"Óleo e filtros do motor/hidráulico",intervalo:null,unidade:"manual",tarefas:"Usar fluidos e intervalos separados conforme manual e sistema"}
 ],
 "Colheitadeira de grãos": [
  {tipo:"Inspeção preventiva",intervalo:50,unidade:"h",tarefas:"Inspecionar correias, correntes, plataforma, proteções e vazamentos"},
  {tipo:"Lubrificação",intervalo:10,unidade:"h",tarefas:"Lubrificar mancais e pontos indicados no manual"},
  {tipo:"Óleo e filtros",intervalo:null,unidade:"manual",tarefas:"Confirmar tipo de óleo e intervalo no manual do modelo"}
 ],
 "Caminhão": [
  {tipo:"Inspeção preventiva",intervalo:10000,unidade:"km",tarefas:"Inspecionar freios, pneus, luzes, correias, vazamentos e itens de segurança"},
  {tipo:"Óleo e filtro do motor",intervalo:null,unidade:"manual/km",tarefas:"Programar por manual, tipo de motor, óleo, uso severo e quilometragem"},
  {tipo:"Filtros de combustível e ar",intervalo:null,unidade:"manual/km",tarefas:"Verificar e trocar conforme manual e condições de operação"}
 ],
 "Retroescavadeira": [
  {tipo:"Inspeção preventiva",intervalo:250,unidade:"h",tarefas:"Inspecionar sistema hidráulico, pinos, buchas, pneus/material rodante, freios e vazamentos"},
  {tipo:"Lubrificação",intervalo:10,unidade:"h",tarefas:"Lubrificar pinos e articulações conforme tabela do fabricante"},
  {tipo:"Óleo e filtros",intervalo:null,unidade:"manual",tarefas:"Confirmar intervalos separados para motor, hidráulico e transmissão no manual"}
 ],
 "Trator de esteira": [{tipo:"Inspeção preventiva",intervalo:250,unidade:"h",tarefas:"Inspecionar material rodante, lâmina, comandos, mangueiras e vazamentos"},{tipo:"Lubrificação",intervalo:null,unidade:"manual",tarefas:"Aplicar os pontos e intervalos do manual"},{tipo:"Óleo e filtros",intervalo:null,unidade:"manual",tarefas:"Confirmar intervalos no manual do modelo"}],
 "Pulverizador": [{tipo:"Inspeção preventiva",intervalo:50,unidade:"h",tarefas:"Inspecionar bomba, bicos, mangueiras, filtros, barra e vazamentos"},{tipo:"Lubrificação",intervalo:null,unidade:"manual",tarefas:"Lubrificar articulações e cardã quando aplicável, conforme manual"},{tipo:"Óleo e filtros",intervalo:null,unidade:"manual",tarefas:"Conferir bomba/motor e especificações no manual"}]
};
function planoParaTipo(tipo) {
 const plano = PLANOS_SUGERIDOS[tipo];
 if (plano) return plano.map(x=>({...x}));
 return [{tipo:"Inspeção preventiva",intervalo:null,unidade:"manual",tarefas:"Definir lista e periodicidade com base no manual do fabricante"},{tipo:"Lubrificação",intervalo:null,unidade:"manual",tarefas:"Identificar pontos de lubrificação e intervalos no manual"},{tipo:"Óleo e filtros",intervalo:null,unidade:"manual",tarefas:"Confirmar tipo de fluido, filtros e periodicidade no manual exato"}];
}
function preencherPlanoSugerido() {
 const tipo=valor("tipoEquipamento"); const painel=document.getElementById("planoSugerido"); const lista=document.getElementById("listaPlanoSugerido");
 if(!tipo){painel.classList.add("escondido");return;}
 const plano=planoParaTipo(tipo); painel.classList.remove("escondido");
 lista.innerHTML=plano.map((r,i)=>`<div class="linha-plano"><strong>${esc(r.tipo)}</strong><span>${r.intervalo ? `A cada ${fmtNum(r.intervalo)} ${esc(r.unidade)}` : 'Intervalo: confirmar no manual'}</span><small>${esc(r.tarefas)}</small></div>`).join("");
}

const EXEMPLOS_EQUIPAMENTOS = [
 {nome:"Trator agrícola — exemplo 01",tipo:"Trator agrícola",marca:"Marca demonstrativa",modelo:"Modelo demonstrativo",ano:"2022",identificacao:"DEMO-TR-01",horimetro:1250,routines:[
  {tipo:"Manutenção preventiva",intervalo:500,unidade:"h",tarefas:"Inspeção geral, correias, mangueiras, arrefecimento e vazamentos",nota:"Exemplo de intervalo; confirmar no manual exato."},
  {tipo:"Lubrificação",intervalo:100,unidade:"h",tarefas:"Lubrificar pinos, articulações e pontos indicados pelo fabricante",nota:"Os pontos e intervalos variam conforme o modelo."},
  {tipo:"Óleo e filtros",intervalo:250,unidade:"h",tarefas:"Verificar/trocar óleo do motor e filtro conforme especificação",nota:"250 h é apenas ilustrativo, não uma recomendação universal."}]},
 {nome:"Trator agrícola — exemplo 02",tipo:"Trator agrícola",marca:"Marca demonstrativa",modelo:"Modelo demonstrativo",ano:"2021",identificacao:"DEMO-TR-02",horimetro:860,routines:[
  {tipo:"Manutenção preventiva",intervalo:500,unidade:"h",tarefas:"Inspeção de motor, transmissão, sistema hidráulico e segurança",nota:"Exemplo; seguir manual do fabricante."},
  {tipo:"Lubrificação",intervalo:100,unidade:"h",tarefas:"Lubrificar pontos de articulação e engates",nota:"Confirmar os pontos e periodicidade no manual."},
  {tipo:"Óleo e filtros",intervalo:250,unidade:"h",tarefas:"Conferir nível, especificação do óleo e filtro compatível",nota:"Intervalo ilustrativo; verificar manual."}]},
 {nome:"Colhedora de cana — exemplo",tipo:"Colhedora de cana",marca:"Marca demonstrativa",modelo:"Modelo demonstrativo",ano:"2023",identificacao:"DEMO-CC-01",horimetro:2100,routines:[
  {tipo:"Manutenção preventiva",intervalo:250,unidade:"h",tarefas:"Inspecionar sistemas hidráulico, corte de base, picador e proteções",nota:"Exemplo; confirmar no manual do modelo."},
  {tipo:"Lubrificação",intervalo:50,unidade:"h",tarefas:"Lubrificar rolamentos, pinos e articulações indicados",nota:"Pontos e intervalos dependem do equipamento."},
  {tipo:"Óleo e filtros",intervalo:250,unidade:"h",tarefas:"Verificar/trocar óleo e filtros conforme plano do fabricante",nota:"Intervalo ilustrativo, não universal."}]},
 {nome:"Caminhão agrícola — exemplo",tipo:"Caminhão",marca:"Marca demonstrativa",modelo:"Modelo demonstrativo",ano:"2020",identificacao:"DEMO-CAM-01",horimetro:98500,routines:[
  {tipo:"Manutenção preventiva",intervalo:10000,unidade:"km",tarefas:"Inspecionar freios, pneus, luzes, correias e vazamentos",nota:"Exemplo em km; consultar plano do fabricante."},
  {tipo:"Óleo e filtros",intervalo:10000,unidade:"km",tarefas:"Trocar óleo e filtros conforme especificação do motor",nota:"Intervalo ilustrativo; confirmar por modelo e uso."},
  {tipo:"Lubrificação",intervalo:5000,unidade:"km",tarefas:"Lubrificar pontos de chassi quando aplicável",nota:"Seguir o plano específico do veículo."}]},
 {nome:"Retroescavadeira — exemplo",tipo:"Retroescavadeira",marca:"Marca demonstrativa",modelo:"Modelo demonstrativo",ano:"2022",identificacao:"DEMO-LA-01",horimetro:640,routines:[
  {tipo:"Manutenção preventiva",intervalo:500,unidade:"h",tarefas:"Inspecionar motor, sistema hidráulico, pinos, buchas e material rodante",nota:"Exemplo; confirmar no manual."},
  {tipo:"Lubrificação",intervalo:50,unidade:"h",tarefas:"Lubrificar pinos, buchas e articulações da lança e caçamba",nota:"Confirmar pontos e intervalos do modelo."},
  {tipo:"Óleo e filtros",intervalo:250,unidade:"h",tarefas:"Verificar/trocar óleo e filtros conforme especificação",nota:"Intervalo apenas ilustrativo."}]}
];
function alternarExemplos(){
 const painel=document.getElementById("painelExemplos"); const botao=document.getElementById("botaoVerExemplos");
 if(!painel) return; const abrir=painel.classList.contains("escondido"); painel.classList.toggle("escondido",!abrir); botao.textContent=abrir?"Ocultar exemplos":"Mostrar exemplos";
 if(abrir) renderExemplosEquipamentos();
}
function renderExemplosEquipamentos(){
 const box=document.getElementById("listaExemplosEquipamentos"); if(!box)return;
 box.innerHTML=EXEMPLOS_EQUIPAMENTOS.map(e=>`<article class="item-card exemplo-card"><div class="item-topo"><div class="item-icone">${e.tipo.includes("Trator")?"🚜":e.tipo.includes("Colhedora")?"🌾":e.tipo.includes("Caminhão")?"🚛":"🚧"}</div><div class="item-info"><h3>${esc(e.nome)}</h3><p>${esc(e.tipo)} • ${esc(e.marca)} • ${esc(e.modelo)}</p><p>Identificação: <strong>${esc(e.identificacao)}</strong> • Horímetro demonstrativo: ${fmtNum(e.horimetro)} ${e.tipo==="Caminhão"?"km":"h"}</p><div class="rotinas-exemplo"><strong>Plano de manutenção ilustrativo:</strong><ol>${e.routines.map(r=>`<li><strong>${esc(r.tipo)} — a cada ${fmtNum(r.intervalo)} ${esc(r.unidade)}</strong><small>${esc(r.tarefas)}</small><small>${esc(r.nota)}</small></li>`).join("")}</ol></div></div></div></article>`).join("");
}
function adicionarEquipamentosExemplo(){
 const jaAdicionados=equipamentos.some(e=>String(e.identificacao||"").startsWith("DEMO-"));
 if(jaAdicionados){mostrarMensagem("Exemplos já adicionados","Os exemplos de demonstração já estão na lista. Seus registros existentes foram preservados.");return;}
 if(!confirm("Adicionar 5 equipamentos de demonstração ao cadastro? Isso não apaga seus dados existentes. Os intervalos do plano ficam disponíveis para consulta nesta área de exemplos."))return;
 EXEMPLOS_EQUIPAMENTOS.forEach((ex,idx)=>{
  const id="demo-"+(Date.now()+idx);
  equipamentos.push({id,nome:ex.nome,tipo:ex.tipo,marca:ex.marca,modelo:ex.modelo,ano:ex.ano,identificacao:ex.identificacao,horimetro:ex.horimetro,criadoEm:new Date().toISOString(),demonstracao:true});

 });
 salvarDados();atualizarTudo();renderExemplosEquipamentos();mostrarMensagem("Exemplos adicionados","Foram incluídos 5 equipamentos demonstrativos, sem inventar registros de manutenção passada. Seus dados anteriores foram mantidos.");
}

function configurarGabaritos() {
 const sel = document.getElementById("gabaritoEquipamento");
 if (!sel) return;
 sel.innerHTML = '<option value="">Cadastro personalizado</option>' + GABARITOS_EQUIPAMENTOS.map((g,i)=>`<option value="${i}">${esc(g.tipo)}</option>`).join("");
}
function aplicarGabaritoEquipamento() {
 const sel = document.getElementById("gabaritoEquipamento");
 const g = GABARITOS_EQUIPAMENTOS[Number(sel.value)];
 if (!g) return;
 const nome = document.getElementById("nomeEquipamento");
 const tipo = document.getElementById("tipoEquipamento");
 if (!nome.value.trim()) nome.value = g.nome;
 tipo.value = g.tipo;
 mostrarMensagem("Gabarito aplicado", "Confira marca e modelo. O plano de lubrificação deve ser confirmado no manual exato do equipamento.");
}

function renderRelatorioEquipamentos() {
 const tbody = document.getElementById("corpoRelatorioEquipamentos");
 if (!tbody) return;
 const linhas = equipamentos.map(e => {
   const ls = lubrificacoes.filter(x=>x.equipamentoId===e.id).sort((a,b)=>(b.data||"").localeCompare(a.data||""));
   const ms = manutencoes.filter(x=>x.equipamentoId===e.id).sort((a,b)=>(b.data||"").localeCompare(a.data||""));
   const lub = ls[0]; const man = ms[0];
   const statusLub = lub ? "Registrada" : "EM FALTA";
   const statusMan = man ? "Registrada" : "EM FALTA";
   const plano = e.intervaloLubrificacaoHoras || e.intervaloLubrificacaoDias ? "Configurado no cadastro" : "Não configurado — consultar manual";
   return `<tr><td>${esc(e.nome||e.tipo||"Equipamento")}</td><td>${esc(e.identificacao||"—")}</td><td>${lub?dataBR(lub.data):"—"}</td><td class="${lub?'status-ok':'status-falta'}">${statusLub}</td><td>${man?dataBR(man.data):"—"}</td><td class="${man?'status-ok':'status-falta'}">${statusMan}</td><td>${plano}</td></tr>`;
 }).join("");
 tbody.innerHTML = linhas || '<tr><td colspan="7">Nenhum equipamento cadastrado. Use Equipamentos para cadastrar ou escolher um gabarito.</td></tr>';
 const okLub=equipamentos.filter(e=>lubrificacoes.some(x=>x.equipamentoId===e.id)).length;
 const okMan=equipamentos.filter(e=>manutencoes.some(x=>x.equipamentoId===e.id)).length;
 const resumo=document.getElementById("resumoStatusEquipamentos");
 if(resumo) resumo.innerHTML=`<span>Equipamentos: <b>${equipamentos.length}</b></span><span>Com lubrificação registrada: <b>${okLub}</b></span><span>Sem lubrificação: <b>${equipamentos.length-okLub}</b></span><span>Com manutenção registrada: <b>${okMan}</b></span><span>Sem manutenção: <b>${equipamentos.length-okMan}</b></span>`;
}
function exportarRelatorioCSV() {
 const linhas=[["Equipamento","Tipo","Marca","Modelo","Identificação","Última lubrificação","Status lubrificação","Última manutenção","Status manutenção","Plano do fabricante"]];
 equipamentos.forEach(e=>{
  const ls=lubrificacoes.filter(x=>x.equipamentoId===e.id).sort((a,b)=>(b.data||"").localeCompare(a.data||""));
  const ms=manutencoes.filter(x=>x.equipamentoId===e.id).sort((a,b)=>(b.data||"").localeCompare(a.data||""));
  linhas.push([e.nome,e.tipo,e.marca,e.modelo,e.identificacao,ls[0]?.data||"",ls.length?"Registrada":"EM FALTA",ms[0]?.data||"",ms.length?"Registrada":"EM FALTA",(e.intervaloLubrificacaoHoras||e.intervaloLubrificacaoDias)?"Configurado no cadastro":"Não configurado — consultar manual"]);
 });
 const csv="\uFEFF"+linhas.map(r=>r.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(";")).join("\r\n");
 const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download="relatorio-equipamentos-lubriagro.csv"; a.click(); URL.revokeObjectURL(url);
}

document.addEventListener("DOMContentLoaded", () => {
    carregarDados();
    configurarGabaritos();
    configurarFormularios();
    verificarLogin();
    atualizarTudo();
    colocarDataAtual();
});

function carregarDados() {
    equipamentos = JSON.parse(localStorage.getItem(CHAVES.equipamentos) || "[]");
    manutencoes = JSON.parse(localStorage.getItem(CHAVES.manutencoes) || "[]");
    lubrificacoes = JSON.parse(localStorage.getItem(CHAVES.lubrificacoes) || "[]");
}

function salvarDados() {
    localStorage.setItem(CHAVES.equipamentos, JSON.stringify(equipamentos));
    localStorage.setItem(CHAVES.manutencoes, JSON.stringify(manutencoes));
    localStorage.setItem(CHAVES.lubrificacoes, JSON.stringify(lubrificacoes));
}

function verificarLogin() {
    const logado = localStorage.getItem(CHAVES.login) === "sim";
    document.getElementById("telaLogin").style.display = logado ? "none" : "flex";
    document.getElementById("app").classList.toggle("app-escondido", !logado);
}

document.getElementById("formLogin").addEventListener("submit", function(e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const senha = document.getElementById("loginSenha").value.trim();
    if (!email || senha.length < 3) {
        mostrarMensagem("Atenção", "Informe um e-mail e uma senha válida.");
        return;
    }
    localStorage.setItem(CHAVES.login, "sim");
    verificarLogin();
});

function entrarDemo() {
    localStorage.setItem(CHAVES.login, "sim");
    verificarLogin();
}

function sair() {
    localStorage.removeItem(CHAVES.login);
    document.getElementById("app").classList.add("app-escondido");
    document.getElementById("telaLogin").style.display = "flex";
}

function abrirTela(nome) {
    document.querySelectorAll(".tela").forEach(t => t.classList.remove("ativa"));
    const mapa = {
        inicio: "telaInicio",
        equipamentos: "telaEquipamentos",
        manutencoes: "telaManutencoes",
        lubrificacao: "telaLubrificacao",
        historico: "telaHistorico",
        alertas: "telaAlertas",
        relatorios: "telaRelatorios",
        rotina: "telaRotina",
        acompanhamento: "telaAcompanhamento"
    };
    const tela = document.getElementById(mapa[nome] || "telaInicio");
    tela.classList.add("ativa");
    atualizarTudo();
    window.scrollTo({top: 0, behavior: "smooth"});
}

function configurarFormularios() {
    document.getElementById("formEquipamento").addEventListener("submit", salvarEquipamento);
    document.getElementById("formManutencao").addEventListener("submit", salvarManutencao);
    document.getElementById("formLubrificacao").addEventListener("submit", salvarLubrificacao);
}

function abrirFormularioEquipamento() {
    document.getElementById("formEquipamento").classList.remove("escondido");
    document.getElementById("formEquipamento").scrollIntoView({behavior:"smooth"});
}

function abrirFormularioManutencao() {
    atualizarSelects();
    document.getElementById("formManutencao").classList.remove("escondido");
    document.getElementById("dataManutencao").value = hoje();
    document.getElementById("formManutencao").scrollIntoView({behavior:"smooth"});
}

function abrirFormularioLubrificacao() {
    atualizarSelects();
    document.getElementById("formLubrificacao").classList.remove("escondido");
    document.getElementById("dataLubrificacao").value = hoje();
    document.getElementById("formLubrificacao").scrollIntoView({behavior:"smooth"});
}

function fecharForm(id) {
    document.getElementById(id).classList.add("escondido");
    document.getElementById(id).reset();
}

function salvarEquipamento(e) {
    e.preventDefault();
    const id = document.getElementById("equipamentoId").value;
    const dados = {
        id: id || Date.now().toString(),
        nome: valor("nomeEquipamento"),
        tipo: valor("tipoEquipamento"),
        marca: valor("marcaEquipamento"),
        modelo: valor("modeloEquipamento"),
        ano: valor("anoEquipamento"),
        identificacao: valor("identificacaoEquipamento"),
        horimetro: numero("horimetroEquipamento"),
        quilometragem: numero("quilometragemEquipamento"),
        planoManutencao: document.getElementById("usarPlanoSugerido")?.checked ? (equipamentos.find(x=>x.id===id)?.planoManutencao || planoParaTipo(valor("tipoEquipamento"))) : (equipamentos.find(x=>x.id===id)?.planoManutencao || []),
        criadoEm: new Date().toISOString()
    };
    if (id) {
        const i = equipamentos.findIndex(x => x.id === id);
        if (i >= 0) equipamentos[i] = {...equipamentos[i], ...dados};
    } else {
        equipamentos.push(dados);
    }
    salvarDados();
    fecharForm("formEquipamento");
    atualizarTudo();
    mostrarMensagem("Equipamento salvo", "O equipamento foi cadastrado com sucesso.");
}

function editarEquipamento(id) {
    const e = equipamentos.find(x => x.id === id);
    if (!e) return;
    document.getElementById("equipamentoId").value = e.id;
    document.getElementById("nomeEquipamento").value = e.nome;
    document.getElementById("tipoEquipamento").value = e.tipo;
    document.getElementById("marcaEquipamento").value = e.marca;
    document.getElementById("modeloEquipamento").value = e.modelo;
    document.getElementById("anoEquipamento").value = e.ano;
    document.getElementById("identificacaoEquipamento").value = e.identificacao;
    document.getElementById("horimetroEquipamento").value = e.horimetro;
    document.getElementById("quilometragemEquipamento").value = e.quilometragem || "";
    document.getElementById("usarPlanoSugerido").checked = !!(e.planoManutencao && e.planoManutencao.length);
    preencherPlanoSugerido();
    document.getElementById("formEquipamento").classList.remove("escondido");
    window.scrollTo({top: 0, behavior:"smooth"});
}

function excluirEquipamento(id) {
    if (!confirm("Excluir este equipamento? O histórico dele também será removido.")) return;
    equipamentos = equipamentos.filter(x => x.id !== id);
    manutencoes = manutencoes.filter(x => x.equipamentoId !== id);
    lubrificacoes = lubrificacoes.filter(x => x.equipamentoId !== id);
    salvarDados();
    atualizarTudo();
}

function salvarManutencao(e) {
    e.preventDefault();
    const registro = {
        id: Date.now().toString(),
        equipamentoId: valor("manutencaoEquipamento"),
        tipo: valor("tipoManutencao"),
        data: valor("dataManutencao"),
        horimetro: numero("horimetroManutencao"),
        quilometragem: numero("quilometragemManutencao"),
        produto: valor("produtoManutencao"),
        quantidade: numero("quantidadeManutencao"),
        valor: numero("valorManutencao"),
        tecnicoNome: valor("tecnicoManutencao"),
        tecnicoMatricula: valor("matriculaManutencao"),
        observacao: valor("observacaoManutencao")
    };
    manutencoes.push(registro);
    atualizarHorimetro(registro.equipamentoId, registro.horimetro);
    salvarDados();
    fecharForm("formManutencao");
    atualizarTudo();
    mostrarMensagem("Manutenção registrada", "O serviço foi adicionado ao histórico do equipamento.");
}

function salvarLubrificacao(e) {
    e.preventDefault();
    lubrificacoes.push({
        id: Date.now().toString(),
        equipamentoId: valor("lubrificacaoEquipamento"),
        ponto: valor("pontoLubrificacao"),
        produto: valor("produtoLubrificacao"),
        horimetro: numero("horimetroLubrificacao"),
        data: valor("dataLubrificacao"),
        observacao: valor("observacaoLubrificacao")
    });
    salvarDados();
    fecharForm("formLubrificacao");
    atualizarTudo();
    mostrarMensagem("Lubrificação registrada", "O registro foi adicionado ao histórico.");
}

function atualizarHorimetro(id, h) {
    const e = equipamentos.find(x => x.id === id);
    if (e && h > Number(e.horimetro || 0)) e.horimetro = h;
}

function atualizarSelects() {
    const selects = ["manutencaoEquipamento", "lubrificacaoEquipamento", "rotinaEquipamento", "acompEquipamento"];
    selects.forEach(id => {
        const s = document.getElementById(id);
        const atual = s.value;
        const placeholder = id === "acompEquipamento" ? '<option value="">Todos os equipamentos</option>' : '<option value="">Selecione o equipamento</option>';
        s.innerHTML = placeholder +
            equipamentos.map(e => `<option value="${e.id}">${esc(e.nome)}${e.identificacao ? " — " + esc(e.identificacao) : ""}</option>`).join("");
        s.value = atual;
    });
}

function renderEquipamentos() {
    const box = document.getElementById("listaEquipamentos");
    if (!equipamentos.length) {
        box.innerHTML = vazio("🚜", "Nenhum equipamento cadastrado", "Cadastre a primeira máquina para começar.");
        return;
    }
    box.innerHTML = equipamentos.map(e => {
        const total = manutencoes.filter(m => m.equipamentoId === e.id).length;
        return `<article class="item-card">
            <div class="item-topo"><div class="item-icone">🚜</div><div class="item-info">
                <h3>${esc(e.nome)}</h3>
                <p>${esc(e.tipo)} ${e.marca ? "• " + esc(e.marca) : ""} ${e.modelo ? "• " + esc(e.modelo) : ""}</p>
                <p>⏱️ Horímetro: <strong>${fmtNum(e.horimetro)} h</strong></p>
                <p>📋 ${total} registro(s) de manutenção</p>
                ${e.planoManutencao?.length ? `<div class="plano-salvo"><strong>Plano de manutenção salvo</strong>${e.planoManutencao.map(r=>`<p>• ${esc(r.tipo)}: ${r.intervalo ? `a cada ${fmtNum(r.intervalo)} ${esc(r.unidade)}` : "confirmar no manual"}</p>`).join("")}<small>Referência inicial; confirmar no manual exato.</small></div>` : "<p>Plano não configurado. Edite o equipamento para carregar sugestões.</p>"}
            </div></div>
            <div class="item-acoes">
                <button class="botao-pequeno botao-editar" onclick="verHistoricoEquipamento('${e.id}')">📋 Histórico</button>
                <button class="botao-pequeno botao-editar" onclick="editarEquipamento('${e.id}')">✏️ Editar</button>
                <button class="botao-pequeno botao-excluir" onclick="excluirEquipamento('${e.id}')">Excluir</button>
            </div>
        </article>`;
    }).join("");
}

function renderManutencoes() {
    const box = document.getElementById("listaManutencoes");
    const lista = [...manutencoes].sort((a,b) => (b.data || "").localeCompare(a.data || ""));
    if (!lista.length) {
        box.innerHTML = vazio("🔧", "Nenhuma manutenção registrada", "Os serviços aparecerão aqui.");
        return;
    }
    box.innerHTML = lista.map(m => {
        const e = equipamento(m.equipamentoId);
        return `<article class="item-card">
            <div class="item-topo"><div class="item-icone">🔧</div><div class="item-info">
                <h3>${esc(e?.nome || "Equipamento removido")}</h3>
                <p><strong>${esc(m.tipo)}</strong></p>
                <p>📅 ${dataBR(m.data)} • ⏱️ ${fmtNum(m.horimetro)} h</p>
                <p>👷 Técnico: <strong>${esc(m.tecnicoNome || "Não informado")}</strong></p>
                <p>🪪 Matrícula: <strong>${esc(m.tecnicoMatricula || "Não informada")}</strong></p>
                ${m.produto ? `<p>🧰 ${esc(m.produto)} ${m.quantidade ? "• " + fmtNum(m.quantidade) : ""}</p>` : ""}
                <p class="valor">💰 ${moeda(m.valor)}</p>
                ${m.observacao ? `<p>${esc(m.observacao)}</p>` : ""}
            </div></div>
        </article>`;
    }).join("");
}

function renderLubrificacoes() {
    const box = document.getElementById("listaLubrificacoes");
    const lista = [...lubrificacoes].sort((a,b) => (b.data || "").localeCompare(a.data || ""));
    if (!lista.length) {
        box.innerHTML = vazio("🧴", "Nenhuma lubrificação registrada", "Registre os pontos lubrificados.");
        return;
    }
    box.innerHTML = lista.map(l => {
        const e = equipamento(l.equipamentoId);
        return `<article class="item-card"><div class="item-topo"><div class="item-icone">🧴</div><div class="item-info">
            <h3>${esc(e?.nome || "Equipamento removido")}</h3>
            <p>📍 ${esc(l.ponto)}</p><p>🧴 ${esc(l.produto || "Produto não informado")}</p>
            <p>📅 ${dataBR(l.data)} ${l.horimetro ? "• ⏱️ " + fmtNum(l.horimetro) + " h" : ""}</p>
            ${l.observacao ? `<p>${esc(l.observacao)}</p>` : ""}
        </div></div></article>`;
    }).join("");
}

function renderHistorico() {
    const filtro = document.getElementById("filtroHistorico");
    filtro.innerHTML = `<select onchange="renderHistorico()" id="historicoEquipamento"><option value="">Todos os equipamentos</option>${equipamentos.map(e => `<option value="${e.id}">${esc(e.nome)}</option>`).join("")}</select>`;
    const id = document.getElementById("historicoEquipamento").value;
    const eventos = [];
    manutencoes.forEach(m => { if (!id || m.equipamentoId === id) eventos.push({...m, categoria:"Manutenção"}); });
    lubrificacoes.forEach(l => { if (!id || l.equipamentoId === id) eventos.push({...l, categoria:"Lubrificação"}); });
    eventos.sort((a,b) => (b.data || "").localeCompare(a.data || ""));
    const box = document.getElementById("listaHistorico");
    if (!eventos.length) {
        box.innerHTML = vazio("📋", "Histórico vazio", "Selecione um equipamento ou registre um serviço.");
        return;
    }
    box.innerHTML = eventos.map(x => {
        const e = equipamento(x.equipamentoId);
        const titulo = x.categoria === "Manutenção" ? x.tipo : "Lubrificação — " + x.ponto;
        return `<article class="historico-item"><div class="linha-icone">${x.categoria === "Manutenção" ? "🔧" : "🧴"}</div><div><strong>${esc(titulo)}</strong><p>${esc(e?.nome || "Equipamento removido")}</p><small>📅 ${dataBR(x.data)} ${x.horimetro ? "• ⏱️ " + fmtNum(x.horimetro) + " h" : ""}</small>${x.valor ? `<small>💰 ${moeda(x.valor)}</small>` : ""}${x.categoria === "Manutenção" ? `<small>👷 Técnico: ${esc(x.tecnicoNome || "Não informado")} • 🪪 Matrícula: ${esc(x.tecnicoMatricula || "Não informada")}</small>` : ""}</div></article>`;
    }).join("");
}

function verHistoricoEquipamento(id) {
    abrirTela("historico");
    setTimeout(() => {
        const select = document.getElementById("historicoEquipamento");
        if (select) { select.value = id; renderHistorico(); }
    }, 50);
}

function renderAlertas() {
    const box = document.getElementById("listaAlertas");
    const alertas = [];
    equipamentos.forEach(e => {
        const intervalo = Number(e.intervaloLubrificacaoHoras || 0);
        const trocas = manutencoes.filter(m => m.equipamentoId === e.id && m.tipo === "Troca de óleo").sort((a,b) => Number(b.horimetro||0)-Number(a.horimetro||0));
        if (!intervalo) {
            alertas.push({e, texto:"Intervalo de lubrificação não configurado. Consulte o manual exato do fabricante.", classe:""});
            return;
        }
        const ultima = trocas[0];
        if (!ultima) { alertas.push({e, texto:"Não há troca de óleo registrada para calcular a próxima manutenção.", classe:"atrasado"}); return; }
        const restante = intervalo - (Number(e.horimetro || 0) - Number(ultima.horimetro || 0));
        if (restante <= 0) alertas.push({e, texto:`Manutenção por horímetro atrasada em ${Math.abs(restante).toFixed(0)} h.`, classe:"atrasado"});
        else if (restante <= Math.max(10, intervalo*0.1)) alertas.push({e, texto:`Manutenção próxima: faltam ${restante.toFixed(0)} h.`, classe:""});
    });
    if (!alertas.length) { box.innerHTML = vazio("✅", "Nenhum alerta calculado", "Configure os intervalos com base no manual específico de cada máquina."); return; }
    box.innerHTML = alertas.map(a => `<article class="alerta-card ${a.classe}"><div class="item-icone">⚠️</div><h3>${esc(a.e.nome)}</h3><p>${esc(a.texto)}</p><small>Horímetro atual: ${fmtNum(a.e.horimetro)} ${a.e.tipo === "Caminhão" ? "km" : "h"}</small></article>`).join("");
}

function renderRelatorios() {
    const tipos = {};
    manutencoes.forEach(m => tipos[m.tipo] = (tipos[m.tipo] || 0) + 1);
    const custos = {};
    manutencoes.forEach(m => {
        const e = equipamento(m.equipamentoId);
        const nome = e?.nome || "Outros";
        custos[nome] = (custos[nome] || 0) + Number(m.valor || 0);
    });
    renderGrafico("graficoTipos", tipos, "registros", false);
    renderGrafico("graficoCustos", custos, "R$", true);

    const total = manutencoes.reduce((s,m)=>s+Number(m.valor||0),0);
    const qtd = manutencoes.length;
    document.getElementById("resumoFinanceiro").innerHTML = `<div><span>Total gasto</span><strong>${moeda(total)}</strong></div><div><span>Manutenções</span><strong>${qtd}</strong></div><div><span>Custo médio</span><strong>${moeda(qtd ? total/qtd : 0)}</strong></div>`;
}

function renderGrafico(id, dados, unidade, dinheiro) {
    const box = document.getElementById(id);
    const entries = Object.entries(dados).sort((a,b)=>b[1]-a[1]);
    if (!entries.length) { box.innerHTML = `<div class="sem-grafico">Sem dados suficientes para gerar o gráfico.</div>`; return; }
    const max = Math.max(...entries.map(x=>x[1]), 1);
    box.innerHTML = entries.map(([nome,val]) => `<div class="barra-linha"><div class="barra-label"><span>${esc(nome)}</span><strong>${dinheiro ? moeda(val) : val + " " + unidade}</strong></div><div class="barra-fundo"><div class="barra" style="width:${Math.max(4,(val/max)*100)}%"></div></div></div>`).join("");
}

function renderRotinaDetalhe() {
 const box=document.getElementById("rotinaDetalhe"); if(!box)return;
 const id=document.getElementById("rotinaEquipamento")?.value;
 const e=equipamentos.find(x=>x.id===id);
 if(!e){box.innerHTML=vazio("🛢️","Selecione um equipamento","Os compartimentos, óleos e filtros aparecerão aqui.");return;}
 const plano=e.planoManutencao||planoParaTipo(e.tipo);
 const compartments=[
  {nome:"Motor",oleo:"Óleo de motor conforme especificação do fabricante",cap:"Confirmar capacidade no manual",filtro:"Filtro de óleo do motor; filtro de combustível; filtro de ar"},
  {nome:"Transmissão / caixa",oleo:"Fluido de transmissão especificado pelo fabricante",cap:"Confirmar capacidade no manual",filtro:"Filtros ou telas conforme o sistema e modelo"},
  {nome:"Sistema hidráulico",oleo:"Fluido hidráulico compatível com o equipamento",cap:"Confirmar capacidade no manual",filtro:"Filtro hidráulico de sucção/retorno conforme projeto"},
  {nome:"Eixos / diferencial / comandos finais",oleo:"Lubrificante de engrenagens conforme manual",cap:"Confirmar capacidade no manual",filtro:"Verificar se o conjunto utiliza filtro"}
 ];
 box.innerHTML=`<article class="item-card"><h3>${esc(e.nome)}</h3><p>${esc(e.marca||"")} ${esc(e.modelo||"")} • ${esc(e.tipo)}</p><p>Horímetro: <b>${fmtNum(e.horimetro)} h</b> • Quilometragem: <b>${e.quilometragem?fmtNum(e.quilometragem)+" km":"não informada"}</b></p></article>
 <div class="grafico-card"><h3>Compartimentos de óleo e filtros</h3><p class="relatorio-ajuda">São categorias para preencher a ficha. Tipo exato, viscosidade, capacidade em litros e código do filtro variam por marca/modelo e devem ser conferidos no manual.</p>${compartments.map(c=>`<div class="linha-plano"><strong>${c.nome}</strong><span>${c.oleo}</span><small>Capacidade: ${c.cap}<br>Filtros: ${c.filtro}</small></div>`).join("")}</div>
 <div class="grafico-card"><h3>Rotinas deste equipamento</h3>${plano.map(r=>`<div class="linha-plano"><strong>${esc(r.tipo)}</strong><span>${r.intervalo?`A cada ${fmtNum(r.intervalo)} ${esc(r.unidade)}`:"Intervalo a confirmar no manual"}</span><small>${esc(r.tarefas||"")}</small></div>`).join("")||"<p>Não há plano cadastrado.</p>"}<small>Plano inicial de referência; não substitui o manual específico.</small></div>`;
}
function renderAcompanhamento(){
 const box=document.getElementById("listaAcompanhamento"); if(!box)return;
 const id=document.getElementById("acompEquipamento")?.value;
 const lista=equipamentos.filter(e=>!id||e.id===id);
 if(!lista.length){box.innerHTML=vazio("⏱️","Nenhum equipamento cadastrado","Cadastre um equipamento para acompanhar as manutenções.");return;}
 box.innerHTML=lista.map(e=>{
  const regs=manutencoes.filter(m=>m.equipamentoId===e.id).sort((a,b)=>(b.data||"").localeCompare(a.data||""));
  const plano=e.planoManutencao||planoParaTipo(e.tipo);
  const rows=plano.map(r=>{
   if(!r.intervalo||!['h','km'].includes(r.unidade))return `<div class="linha-plano"><strong>${esc(r.tipo)}</strong><span>Próxima: confirmar no manual</span><small>${esc(r.tarefas||"")}</small></div>`;
   const match=regs.find(m=>{const t=(m.tipo+" "+(m.produto||"")).toLowerCase();const rt=(r.tipo||"").toLowerCase();return t.includes("troca")&&((rt.includes("óleo")&&t.includes("óleo"))||(rt.includes("filtro")&&t.includes("filtro"))||(rt.includes("lubr")&&t.includes("lubr"))||(rt.includes("preventiva")&&(t.includes("preventiva")||t.includes("revisão")))||(rt.includes("inspeção")&&t.includes("revisão")));});
   const unidade=r.unidade; const atual=unidade==="km"?Number(e.quilometragem||0):Number(e.horimetro||0); const ultimo=match?Number(unidade==="km"?(match.quilometragem||0):(match.horimetro||0)):0;
   const base=match?ultimo:0; const restante=Number(r.intervalo)-(atual-base); const status=!match?"Sem registro desta rotina":restante<=0?"ATRASADA":restante<=Math.max(10,Number(r.intervalo)*.1)?"PRÓXIMA":"Em dia";
   return `<div class="linha-plano"><strong>${esc(r.tipo)}</strong><span>${status} — ${restante>0?"faltam "+fmtNum(restante)+" "+unidade:status==="ATRASADA"?"ultrapassou "+fmtNum(Math.abs(restante))+" "+unidade:"registre a última realização"}</span><small>${match?`Última registrada em ${dataBR(match.data)} (${fmtNum(base)} ${unidade})`:`Registre a primeira realização para calcular a próxima.`}<br>${esc(r.tarefas||"")}</small></div>`;
  }).join("");
  return `<article class="item-card"><h3>🚜 ${esc(e.nome)}</h3><p>${esc(e.tipo)} • Horímetro: ${fmtNum(e.horimetro)} h • Km: ${e.quilometragem?fmtNum(e.quilometragem):"não informado"}</p><div class="grafico-card"><h3>Próximas rotinas</h3>${rows}</div><h3>Manutenções realizadas</h3>${regs.slice(0,8).map(m=>`<p>✓ ${esc(m.tipo)} — ${dataBR(m.data)} — ${fmtNum(m.horimetro)} h${m.quilometragem?" / "+fmtNum(m.quilometragem)+" km":""}</p>`).join("")||"<p>Nenhuma manutenção registrada ainda.</p>"}</article>`;
 }).join("");
}

function atualizarTudo() {
    document.getElementById("totalEquipamentos").textContent = equipamentos.length;
    document.getElementById("totalManutencoes").textContent = manutencoes.length;
    document.getElementById("totalAlertas").textContent = contarAlertas();
    renderEquipamentos();
    renderManutencoes();
    renderLubrificacoes();
    renderHistorico();
    renderAlertas();
    renderRelatorios();
    renderRelatorioEquipamentos();
    atualizarSelects();
    renderRotinaDetalhe();
    renderAcompanhamento();
}

function contarAlertas() {
    return equipamentos.filter(e => {
        const intervalo=Number(e.intervaloLubrificacaoHoras||0);
        if(!intervalo) return true;
        const trocas=manutencoes.filter(m=>m.equipamentoId===e.id&&m.tipo==="Troca de óleo").sort((a,b)=>Number(b.horimetro||0)-Number(a.horimetro||0));
        if(!trocas.length)return true;
        const restante=intervalo-(Number(e.horimetro||0)-Number(trocas[0].horimetro||0));
        return restante<=Math.max(10,intervalo*0.1);
    }).length;
}

function equipamento(id) { return equipamentos.find(e => e.id === id); }
function valor(id) { return document.getElementById(id).value.trim(); }
function numero(id) { return Number(document.getElementById(id).value || 0); }
function hoje() { return new Date().toISOString().slice(0,10); }
function colocarDataAtual() {
    ["dataManutencao","dataLubrificacao"].forEach(id => { const el=document.getElementById(id); if(el) el.value=hoje(); });
}
function dataBR(s) { if(!s) return "Data não informada"; const p=s.split("-"); return p.length===3 ? `${p[2]}/${p[1]}/${p[0]}` : s; }
function moeda(v) { return Number(v||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"}); }
function fmtNum(v) { return Number(v||0).toLocaleString("pt-BR",{maximumFractionDigits:1}); }
function esc(v) { return String(v ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
function vazio(icone,titulo,texto) { return `<div class="lista-vazia"><div class="vazio-icone">${icone}</div><strong>${titulo}</strong><p>${texto}</p></div>`; }
function mostrarMensagem(titulo,texto) {
    document.getElementById("mensagemTitulo").textContent = titulo;
    document.getElementById("mensagemTexto").textContent = texto;
    document.getElementById("mensagem").classList.add("visivel");
}
function fecharMensagem() { document.getElementById("mensagem").classList.remove("visivel"); }
