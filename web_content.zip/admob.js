import { Capacitor } from '@capacitor/core';
import { AdMob, AdmobConsentStatus } from '@capacitor-community/admob';

// Starfall Defense AdMob bridge.
// Keep test ads enabled while developing. Never click your own live ads.
const USE_TEST_ADS = true;
const APP_REWARDED_AD_UNIT_ID = 'ca-app-pub-3310594384950748/2721513516';
const TEST_REWARDED_AD_UNIT_ID = 'ca-app-pub-3940256099942544/5224354917';
const REWARDED_AD_UNIT_ID = USE_TEST_ADS ? TEST_REWARDED_AD_UNIT_ID : APP_REWARDED_AD_UNIT_ID;

let initialized = false;
let initializing = null;

async function initializeAdMob() {
  if (!Capacitor.isNativePlatform()) return false;
  if (initialized) return true;
  if (initializing) return initializing;
  initializing = (async () => {
    try {
      let consent = await AdMob.requestConsentInfo();
      if (consent.isConsentFormAvailable && consent.status === AdmobConsentStatus.REQUIRED) {
        consent = await AdMob.showConsentForm();
      }
      if (!consent.canRequestAds) return false;
      await AdMob.initialize();
      initialized = true;
      return true;
    } catch (error) {
      console.error('Starfall AdMob initialization failed:', error);
      return false;
    } finally {
      initializing = null;
    }
  })();
  return initializing;
}

// Existing game code calls this for both ship unlocks and revive.
// It returns true only when the SDK reports that a reward was earned.
window.starfallShowRewardedAd = async function () {
  const ready = await initializeAdMob();
  if (!ready) return false;
  try {
    await AdMob.prepareRewardVideoAd({ adId: REWARDED_AD_UNIT_ID, isTesting: USE_TEST_ADS });
    const reward = await AdMob.showRewardVideoAd();
    return !!reward;
  } catch (error) {
    console.warn('Starfall rewarded ad unavailable or not completed:', error);
    return false;
  }
};
