FrostFlow Ice Cream Distribution & Billing

Contents:
- index.html: standalone browser app.

How to run:
1. Extract the ZIP.
2. Open index.html in a modern browser (internet connection is needed for Tailwind styling CDN).
3. Inventory, shopkeepers, invoices, and settings are saved in this browser's localStorage.

Important:
- This is a browser-only demo. Data stays in the current browser/device and is not synced to other devices.
- GST rates and invoice treatment should be verified for your business and current Indian tax rules before issuing real tax invoices.
- Back up your browser data regularly; clearing browser storage can remove saved records.
