package com.hasan.followup

import android.content.Context
import android.os.Environment
import com.lowagie.text.Document
import com.lowagie.text.Paragraph
import com.lowagie.text.pdf.PdfWriter
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream

object ReportExporter {
 private fun dir(): File { val d=File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"تطبيق المتابعة"); d.mkdirs(); return d }
 fun pdf(c:Context, apps:List<Appointment>):File { val f=File(dir(),"تقرير_المواعيد.pdf"); val doc=Document(); PdfWriter.getInstance(doc,FileOutputStream(f)); doc.open(); doc.add(Paragraph("تقرير المواعيد - تطبيق المتابعة")); doc.add(Paragraph("إجمالي المواعيد: ${apps.size}")); apps.sortedBy{it.date+it.time}.forEachIndexed{idx,a->doc.add(Paragraph("${idx+1}. ${a.date} ${a.time} | ${a.title} | الحالة: ${a.status}${if(a.reason.isNotBlank())" | السبب: ${a.reason}" else ""}${if(a.notes.isNotBlank())" | ملاحظات: ${a.notes}" else ""}"))}; doc.close(); return f }
 fun xlsx(c:Context, apps:List<Appointment>):File { val f=File(dir(),"تقرير_المواعيد.xlsx"); val wb=XSSFWorkbook(); val s=wb.createSheet("المواعيد"); val h=s.createRow(0); listOf("التاريخ","الوقت","الموعد","الحالة","السبب","الملاحظات").forEachIndexed{i,v->h.createCell(i).setCellValue(v)}; apps.sortedBy{it.date+it.time}.forEachIndexed{r,a->val row=s.createRow(r+1);listOf(a.date,a.time,a.title,a.status,a.reason,a.notes).forEachIndexed{i,v->row.createCell(i).setCellValue(v)}};FileOutputStream(f).use{wb.write(it)};wb.close();return f }
}
