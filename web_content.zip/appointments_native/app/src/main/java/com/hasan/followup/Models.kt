package com.hasan.followup

data class Appointment(val id: Long, var title:String, var date:String, var time:String, var notes:String="", var reminders:MutableList<Reminder> = mutableListOf(), var status:String="لم يتم", var reason:String="")
data class Reminder(val id:Long, val dateTimeMillis:Long, val label:String="تنبيه")
