package com.hasan.followup
import android.content.*
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context, i:Intent){Alarms.rescheduleAll(c);Alarms.scheduleDaily(c)}}
