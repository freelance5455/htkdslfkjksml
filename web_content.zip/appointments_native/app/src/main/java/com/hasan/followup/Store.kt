package com.hasan.followup
import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
class Store(private val c:Context){ private val p=c.getSharedPreferences("data",0); private val g=Gson()
 fun all():MutableList<Appointment>{ val s=p.getString("apps","[]")!!; return g.fromJson(s,object:TypeToken<MutableList<Appointment>>(){}.type) }
 fun save(a:List<Appointment>){p.edit().putString("apps",g.toJson(a)).apply()}
}
