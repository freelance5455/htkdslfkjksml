plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.hasan.followup"; compileSdk = 35
    defaultConfig { applicationId = "com.hasan.followup"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.code.gson:gson:2.11.0")
    implementation("org.apache.poi:poi-ooxml:5.4.0")
    implementation("com.github.librepdf:openpdf:2.0.3")
}
