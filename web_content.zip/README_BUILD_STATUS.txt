DAYFLOW NATIVE ANDROID PROJECT - REPAIR NOTES

This archive contains Android/Kotlin source plus the DayFlow web assets. It is NOT a compiled APK and has NOT been built or tested on a physical Android device in this environment.

Repairs in this revision:
- Added AndroidX Core dependency used by NotificationCompat and ActivityCompat.
- Changed alarm notifications to NotificationCompat, compatible with the project's minSdk 23.
- Added a native bridge method to open Android's exact-alarm access screen on Android 12+.
- DayFlow requests exact-alarm access when the user enables reminders (Android 12+).
- After successful local login, DayFlow saves/synchronizes the current reminder schedule with Android.
- Notification Complete actions are queued natively and reconciled only after local login. The queue is cleared only when every queued completion is applied to a task in the active account.
- The alarm receiver schedules the next daily occurrence using the saved schedule; edits/deletions cancel previously registered task alarms.

Important limitations:
- This project still requires a compatible Android Gradle build environment. No Gradle wrapper JAR/scripts are included in this archive; the previous ZIP did not contain them, and a wrapper cannot be safely fabricated without the matching Gradle wrapper binary.
- Android 13+ notification permission must be granted. Android 12+ exact alarm access must be granted in Settings.
- OEM battery restrictions can delay alarms. Force-stopping the app prevents alarms until the app is launched again.
- Notification Complete is stored in native app storage while the WebView is closed, then copied into the local DayFlow account after the next successful login. It does not write WebView localStorage while the WebView is not running.
- Existing data in a separately installed APKForge WebView is not automatically migrated to this native app's WebView storage.

Build configuration:
- Android Gradle Plugin 8.7.3
- Kotlin Android plugin 2.0.21
- compileSdk 35, targetSdk 35, minSdk 23
- AndroidX Core KTX 1.15.0
