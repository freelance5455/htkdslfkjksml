
let player;
let obstacles = [];
let score = 0;
let gameOver = false;
let groundY;
let spawnTimer = 0;
let speed = 6;

function setup() {
  createCanvas(windowWidth, windowHeight);
  textFont("sans-serif");
  resetGame();
}

function resetGame() {
  groundY = height - 65;
  player = {
    x: 65,
    y: groundY - 55,
    w: 32,
    h: 55,
    vy: 0,
    gravity: 0.7,
    jump: -13,
    grounded: true
  };

  obstacles = [];
  score = 0;
  speed = 6;
  spawnTimer = 0;
  gameOver = false;
}

function draw() {
  background(110, 210, 250);

  // Sky decoration
  noStroke();
  fill(255, 255, 255, 210);
  ellipse(width * 0.7, 100, 90, 35);
  ellipse(width * 0.75, 95, 65, 45);
  ellipse(width * 0.25, 150, 80, 30);

  // Ground
  fill(40, 170, 75);
  rect(0, groundY, width, height - groundY);

  fill(130, 75, 170);
  rect(0, groundY + 12, width, height - groundY - 12);

  // Score
  fill(20);
  textSize(24);
  textAlign(LEFT, TOP);
  text("BUTNA GAME", 15, 15);
  text("Score: " + floor(score), 15, 48);

  if (!gameOver) {
    updatePlayer();
    updateObstacles();
    score += 0.1;
    speed = min(11, 6 + score / 150);
  }

  drawPlayer();

  for (let obs of obstacles) {
    drawEnemy(obs);
  }

  if (gameOver) {
    drawGameOver();
  } else if (score < 5) {
    fill(20);
    textSize(16);
    textAlign(CENTER, CENTER);
    text("TAP TO JUMP!", width / 2, height - 25);
  }
}

function updatePlayer() {
  player.vy += player.gravity;
  player.y += player.vy;

  if (player.y + player.h >= groundY) {
    player.y = groundY - player.h;
    player.vy = 0;
    player.grounded = true;
  }
}

function jumpPlayer() {
  if (gameOver) {
    resetGame();
    return;
  }

  if (player.grounded) {
    player.vy = player.jump;
    player.grounded = false;
  }
}

function drawPlayer() {
  push();
  translate(player.x, player.y);

  // Head
  fill(255, 205, 155);
  stroke(35, 75, 160);
  strokeWeight(3);
  ellipse(16, 9, 19, 19);

  // Body
  stroke(30, 90, 210);
  strokeWeight(6);
  line(16, 19, 16, 37);

  // Arms
  strokeWeight(4);
  line(16, 23, 5, 31);
  line(16, 23, 27, 29);

  // Legs
  line(16, 37, 6, 51);
  line(16, 37, 27, 50);

  pop();
}

function updateObstacles() {
  spawnTimer--;

  if (spawnTimer <= 0) {
    obstacles.push({
      x: width + 20,
      y: groundY - 48,
      w: 30,
      h: 48
    });

    spawnTimer = floor(random(65, 105));
  }

  for (let i = obstacles.length - 1; i >= 0; i--) {
    let obs = obstacles[i];
    obs.x -= speed;

    let hit =
      player.x + 23 > obs.x &&
      player.x + 9 < obs.x + obs.w &&
      player.y + player.h > obs.y &&
      player.y < obs.y + obs.h;

    if (hit) {
      gameOver = true;
    }

    if (obs.x + obs.w < 0) {
      obstacles.splice(i, 1);
    }
  }
}

function drawEnemy(obs) {
  push();
  translate(obs.x, obs.y);

  // Red enemy character
  stroke(190, 35, 35);
  strokeWeight(5);
  line(15, 15, 15, 32);
  line(15, 20, 4, 28);
  line(15, 20, 26, 28);
  line(15, 32, 5, 46);
  line(15, 32, 26, 46);

  fill(255, 180, 130);
  strokeWeight(2);
  ellipse(15, 8, 18, 18);

  pop();
}

function drawGameOver() {
  fill(0, 0, 0, 175);
  rect(0, 0, width, height);

  textAlign(CENTER, CENTER);
  fill(255, 80, 60);
  textSize(38);
  text("GAME OVER", width / 2, height / 2 - 55);

  fill(255);
  textSize(24);
  text("Score: " + floor(score), width / 2, height / 2);

  fill(40, 220, 110);
  rectMode(CENTER);
  rect(width / 2, height / 2 + 55, 220, 55, 18);
  rectMode(CORNER);

  fill(0);
  textSize(18);
  text("TAP TO RESTART", width / 2, height / 2 + 55);
}

function mousePressed() {
  jumpPlayer();
}

function touchStarted() {
  jumpPlayer();
  return false;
}

function keyPressed() {
  if (key === " " || keyCode === UP_ARROW) {
    jumpPlayer();
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  groundY = height - 65;

  if (player) {
    player.y = min(player.y, groundY - player.h);
  }
}
