
let player;
let obstacles = [];
let coins = [];

let score = 0;
let coinCount = 0;
let speed = 4;
let gameOver = false;

let groundY;
let spawnTimer = 0;
let coinTimer = 0;

// SOUND SYSTEM
let audioCtx = null;

function startAudio() {
  if (!audioCtx) {
    let AudioClass =
      window.AudioContext || window.webkitAudioContext;

    if (AudioClass) {
      audioCtx = new AudioClass();
    }
  }

  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume();
  }
}

function playTone(freq, duration, type, volume) {
  if (!audioCtx) return;

  let osc = audioCtx.createOscillator();
  let gain = audioCtx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

  gain.gain.setValueAtTime(volume, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(
    0.001,
    audioCtx.currentTime + duration
  );

  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.start();
  osc.stop(audioCtx.currentTime + duration);
}

function soundJump() {
  playTone(500, 0.15, "square", 0.035);
}

function soundCoin() {
  playTone(880, 0.12, "sine", 0.05);

  if (audioCtx) {
    setTimeout(() => {
      playTone(1175, 0.15, "sine", 0.04);
    }, 70);
  }
}

function soundGameOver() {
  playTone(220, 0.25, "sawtooth", 0.04);

  if (audioCtx) {
    setTimeout(() => {
      playTone(150, 0.4, "sawtooth", 0.04);
    }, 180);
  }
}

// SETUP
function setup() {
  createCanvas(350, 400);
  groundY = height - 60;
  resetGame();
}

// RESET GAME
function resetGame() {
  player = {
    x: 55,
    y: groundY - 50,
    w: 30,
    h: 50,
    vy: 0,
    jumping: false
  };

  obstacles = [];
  coins = [];

  score = 0;
  coinCount = 0;
  speed = 4;

  spawnTimer = 0;
  coinTimer = 0;
  gameOver = false;
}

// MAIN GAME
function draw() {
  background(135, 206, 235);

  // Sun
  noStroke();
  fill(255, 220, 40);
  circle(305, 50, 42);

  // Clouds
  fill(255);
  circle(65, 65, 25);
  circle(83, 58, 32);
  circle(103, 66, 25);

  // Ground
  fill(65, 185, 75);
  rect(0, groundY, width, 60);

  stroke(40, 140, 55);
  strokeWeight(2);
  line(0, groundY, width, groundY);
  noStroke();

  if (!gameOver) {
    score++;
    speed = min(8, 4 + score / 1500);

    // Player gravity
    player.vy += 0.7;
    player.y += player.vy;

    if (player.y >= groundY - player.h) {
      player.y = groundY - player.h;
      player.vy = 0;
      player.jumping = false;
    }

    // Create obstacles
    spawnTimer++;

    if (spawnTimer > 80) {
      obstacles.push({
        x: width + 10,
        w: 25,
        h: random(28, 42)
      });

      spawnTimer = 0;
    }

    // Move obstacles and check collision
    for (let o of obstacles) {
      o.x -= speed;

      if (
        player.x + player.w - 5 > o.x &&
        player.x + 5 < o.x + o.w &&
        player.y + player.h - 3 > groundY - o.h
      ) {
        gameOver = true;
        soundGameOver();
      }
    }

    obstacles = obstacles.filter(o => o.x + o.w > 0);

    // Create coins
    coinTimer++;

    if (coinTimer > 65) {
      coins.push({
        x: width + 10,
        y: groundY - random(65, 115),
        size: 20,
        collected: false
      });

      coinTimer = 0;
    }

    // Move and collect coins
    for (let c of coins) {
      c.x -= speed;

      let px = player.x + player.w / 2;
      let py = player.y + player.h / 2;

      if (
        !c.collected &&
        dist(px, py, c.x, c.y) < 23
      ) {
        c.collected = true;
        coinCount++;
        soundCoin();
      }
    }

    coins = coins.filter(c => c.x > -25 && !c.collected);
  }

  // Draw obstacles
  for (let o of obstacles) {
    fill(105, 65, 40);
    rect(o.x, groundY - o.h, o.w, o.h, 5);

    fill(155, 105, 65);
    rect(o.x + 4, groundY - o.h + 5, 5, o.h - 10, 2);
  }

  // Draw coins
  for (let c of coins) {
    fill(225, 150, 0);
    circle(c.x, c.y, c.size + 5);

    fill(255, 215, 0);
    circle(c.x, c.y, c.size);

    fill(255, 245, 150);
    ellipse(c.x - 3, c.y - 3, 5, 9);
  }

  // Draw player
  drawPlayer();

  // Score display
  fill(20, 45, 55);
  textAlign(LEFT);
  textSize(18);
  text("SCORE: " + floor(score / 5), 10, 25);
  text("COINS: " + coinCount, 10, 48);

  // Game Over screen
  if (gameOver) {
    fill(0, 0, 0, 175);
    rect(0, 0, width, height);

    fill(255);
    textAlign(CENTER);
    textSize(28);
    text("GAME OVER", width / 2, 165);

    textSize(18);
    text("Score: " + floor(score / 5), width / 2, 200);

    fill(255, 215, 0);
    text("Coins: " + coinCount, width / 2, 230);

    fill(255);
    textSize(16);
    text("Tap to restart", width / 2, 270);

    textAlign(LEFT);
  }
}

// PLAYER CHARACTER
function drawPlayer() {
  let x = player.x;
  let y = player.y;

  // Head
  noStroke();
  fill(255, 195, 145);
  circle(x + 15, y + 7, 21);

  // Hair
  fill(65, 40, 25);
  arc(x + 15, y + 5, 21, 14, PI, TWO_PI);

  // Body
  fill(25, 90, 220);
  rect(x + 5, y + 18, 20, 19, 5);

  // Arms
  stroke(255, 195, 145);
  strokeWeight(5);
  line(x + 5, y + 22, x - 1, y + 31);
  line(x + 25, y + 22, x + 31, y + 29);

  // Running legs
  stroke(35, 35, 50);
  strokeWeight(5);

  if (!player.jumping && !gameOver) {
    let step = sin(frameCount * 0.3) * 5;

    line(x + 10, y + 36, x + 8 + step, y + 49);
    line(x + 20, y + 36, x + 22 - step, y + 49);
  } else {
    line(x + 10, y + 36, x + 5, y + 45);
    line(x + 20, y + 36, x + 25, y + 45);
  }

  noStroke();
}

// JUMP AND RESTART
function jump() {
  startAudio();

  if (gameOver) {
    resetGame();
    return;
  }

  if (!player.jumping) {
    player.vy = -13;
    player.jumping = true;
    soundJump();
  }
}

function mousePressed() {
  jump();
}

function touchStarted() {
  jump();
  return false;
}
