
let player, traffic = [];
let score = 0, speed = 5, best = 0;
let state = "menu";
let roadOffset = 0, spawnTimer = 0;
let roadW, roadL, roadR, carW, carH;
let leftHeld = false, rightHeld = false;
let soundOn = true;
let audioCtx = null, engineOsc = null, engineGain = null;
let lastTime = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(1);
  textFont("Arial");
  textAlign(CENTER, CENTER);
  setupSize();
  resetGame();
}

function setupSize() {
  roadW = width * 0.94;
  roadL = (width - roadW) / 2;
  roadR = roadL + roadW;
  carW = min(width * 0.22, 100);
  carH = carW * 1.55;
}

function resetGame() {
  player = { x: width / 2, y: height * 0.73, w: carW, h: carH };
  traffic = [];
  score = 0;
  speed = 5;
  roadOffset = 0;
  spawnTimer = 0;
  lastTime = millis();
}

function startSound() {
  if (!soundOn) return;
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      engineOsc = audioCtx.createOscillator();
      engineGain = audioCtx.createGain();
      engineOsc.type = "sawtooth";
      engineOsc.frequency.value = 90;
      engineGain.gain.value = 0;
      engineOsc.connect(engineGain);
      engineGain.connect(audioCtx.destination);
      engineOsc.start();
    }
    if (audioCtx.state === "suspended") audioCtx.resume();
    engineGain.gain.setTargetAtTime(0.025, audioCtx.currentTime, 0.08);
  } catch (e) {}
}

function playTone(freq, duration, volume = 0.12, type = "square") {
  if (!soundOn) return;
  try {
    if (!audioCtx) startSound();
    if (!audioCtx) return;
    let osc = audioCtx.createOscillator();
    let gain = audioCtx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(volume, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch (e) {}
}

function draw() {
  let now = millis();
  let dt = min((now - lastTime) / 16.67, 2);
  lastTime = now;

  background("#24843c");
  drawRoad();

  if (state === "playing") updateGame(dt);

  for (let t of traffic) drawCar(t.x, t.y, t.w, t.h, t.color, false);
  drawCar(player.x, player.y, player.w, player.h, "#08e5a2", true);
  drawHUD();

  if (state === "menu") drawMenu();
  if (state === "over") drawOver();
  if (state === "playing") drawControls();

  if (audioCtx && engineOsc && engineGain && soundOn) {
    engineOsc.frequency.setTargetAtTime(75 + speed * 20, audioCtx.currentTime, 0.1);
  }
}

function drawRoad() {
  noStroke();
  fill("#277d39");
  rect(0, 0, width, height);

  fill("#35383e");
  rect(width / 2, 0, roadW, height);

  // Large road edges
  for (let y = -70; y < height + 70; y += 70) {
    let yy = (y + roadOffset * 1.5) % (height + 70);
    fill(floor(y / 70) % 2 ? "#ffffff" : "#ff3939");
    rect(roadL + 5, yy, 10, 55);
    rect(roadR - 5, yy, 10, 55);
  }

  // Road center markings
  fill("#f5eab8");
  for (let y = -100; y < height + 100; y += 110) {
    let yy = (y + roadOffset) % (height + 110);
    rect(width / 2, yy, 8, 58);
  }

  if (state === "playing") roadOffset += speed * 1.5;
  else roadOffset += 1;
}

function updateGame(dt) {
  speed = min(5 + score / 350, 10);
  score += dt * 0.2 * speed;

  if (leftHeld) player.x -= 7 * dt;
  if (rightHeld) player.x += 7 * dt;

  player.x = constrain(player.x, roadL + carW * 0.65, roadR - carW * 0.65);

  spawnTimer += dt;
  if (spawnTimer > max(34, 76 - score / 25)) {
    spawnTimer = 0;
    spawnTraffic();
  }

  for (let i = traffic.length - 1; i >= 0; i--) {
    let t = traffic[i];
    t.y += (speed + t.extra) * dt;

    if (abs(player.x - t.x) < (player.w + t.w) * 0.39 &&
        abs(player.y - t.y) < (player.h + t.h) * 0.38) {
      state = "over";
      best = max(best, floor(score));
      leftHeld = rightHeld = false;
      if (engineGain && audioCtx) {
        engineGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.04);
      }
      playTone(90, 0.65, 0.2, "sawtooth");
      return;
    }

    if (t.y > height + t.h) {
      traffic.splice(i, 1);
      score += 10;
    }
  }
}

function spawnTraffic() {
  let lanes = [
    roadL + roadW * 0.25,
    roadL + roadW * 0.50,
    roadL + roadW * 0.75
  ];
  let lane = random(lanes);
  let tries = 0;

  while (tries < 6 && traffic.some(t => abs(t.x - lane) < carW * 0.9 && t.y < carH * 3)) {
    lane = random(lanes);
    tries++;
  }

  traffic.push({
    x: lane, y: -carH,
    w: carW * random(0.9, 1.08),
    h: carH,
    color: random(["#ffbd31", "#ee4c55", "#4aa7ff", "#eeeeee", "#b47cff"]),
    extra: random(0.3, 2)
  });
}

function drawCar(x, y, w, h, c, isPlayer) {
  push();
  translate(x, y);
  rectMode(CENTER);
  noStroke();

  // Wheels
  fill("#111318");
  rect(-w * 0.45, -h * 0.28, w * 0.20, h * 0.24, 4);
  rect(w * 0.45, -h * 0.28, w * 0.20, h * 0.24, 4);
  rect(-w * 0.45, h * 0.28, w * 0.20, h * 0.24, 4);
  rect(w * 0.45, h * 0.28, w * 0.20, h * 0.24, 4);

  // Body
  fill(c);
  rect(0, 0, w * 0.86, h * 0.97, 12);

  // Windshield
  fill("#8bd7ef");
  rect(0, -h * 0.17, w * 0.64, h * 0.25, 7);

  fill("#263b50");
  rect(0, h * 0.13, w * 0.60, h * 0.15, 5);

  // Racing stripe
  if (isPlayer) {
    fill("#ffffff");
    rect(0, h * 0.05, w * 0.10, h * 0.50, 3);
  }

  // Headlights
  fill("#fff4ad");
  rect(-w * 0.27, -h * 0.42, w * 0.20, h * 0.06, 3);
  rect(w * 0.27, -h * 0.42, w * 0.20, h * 0.06, 3);

  // Rear lights
  fill("#ff2929");
  rect(-w * 0.27, h * 0.42, w * 0.20, h * 0.07, 3);
  rect(w * 0.27, h * 0.42, w * 0.20, h * 0.07, 3);
  pop();
}

function drawHUD() {
  noStroke();
  fill(0, 0, 0, 175);
  rect(width / 2, 35, min(width - 20, 370), 60, 16);

  fill("#ffffff");
  textStyle(BOLD);
  textSize(min(width * 0.045, 20));
  text("SCORE: " + floor(score) + "     SPEED: " + floor(speed * 20), width / 2, 35);
  textStyle(NORMAL);

  // Sound button
  fill(0, 0, 0, 180);
  circle(width - 32, 105, 48);
  fill("#ffffff");
  textSize(23);
  text(soundOn ? "♫" : "×", width - 32, 105);
}

function drawMenu() {
  shade();
  fill("#ffffff");
  textStyle(BOLD);
  textSize(min(width * 0.105, 46));
  text("CAR RACING", width / 2, height * 0.28);

  textSize(19);
  text("DODGE THE TRAFFIC!", width / 2, height * 0.36);
  drawButton(width / 2, height * 0.49, min(width * 0.75, 320), 76, "#00c994", "START GAME");

  textStyle(NORMAL);
  textSize(17);
  text("Tap LEFT or RIGHT to drive", width / 2, height * 0.59);
}

function drawOver() {
  shade();
  fill("#ff5656");
  textStyle(BOLD);
  textSize(min(width * 0.10, 43));
  text("GAME OVER", width / 2, height * 0.31);

  fill("#ffffff");
  textSize(25);
  text("Score: " + floor(score), width / 2, height * 0.40);
  textSize(20);
  text("Best: " + best, width / 2, height * 0.45);

  drawButton(width / 2, height * 0.55, min(width * 0.75, 320), 72, "#00c994", "RESTART");
}

function shade() {
  noStroke();
  fill(0, 0, 0, 185);
  rect(width / 2, height / 2, width, height);
}

function drawButton(x, y, w, h, c, label) {
  rectMode(CENTER);
  noStroke();
  fill(0, 0, 0, 90);
  rect(x, y + 5, w, h, 18);
  fill(c);
  rect(x, y, w, h, 18);
  fill("#ffffff");
  textStyle(BOLD);
  textSize(22);
  text(label, x, y);
  textStyle(NORMAL);
}

function drawControls() {
  let y = height - 75;
  let bw = min(width * 0.34, 150);
  let bh = 65;

  noStroke();
  fill(0, 0, 0, 150);
  rect(width * 0.23, y, bw, bh, 18);
  rect(width * 0.77, y, bw, bh, 18);

  fill("#ffffff");
  textStyle(BOLD);
  textSize(38);
  text("◀", width * 0.23, y);
  text("▶", width * 0.77, y);
  textStyle(NORMAL);
}

function handlePress(x, y) {
  // Sound button
  if (dist(x, y, width - 32, 105) < 29) {
    soundOn = !soundOn;
    if (soundOn) startSound();
    else if (audioCtx && engineGain) {
      engineGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.05);
    }
    return;
  }

  if (state === "menu") {
    startSound();
    if (audioCtx && soundOn) playTone(600, 0.12);
    state = "playing";
    resetGame();
    return;
  }

  if (state === "over") {
    startSound();
    if (audioCtx && soundOn) playTone(650, 0.12);
    state = "playing";
    resetGame();
    return;
  }

  if (state === "playing") {
    if (x < width / 2) leftHeld = true;
    else rightHeld = true;
  }
}

function mousePressed() {
  handlePress(mouseX, mouseY);
  return false;
}

function mouseReleased() {
  leftHeld = rightHeld = false;
  return false;
}

function touchStarted() {
  if (touches.length) handlePress(touches[0].x, touches[0].y);
  return false;
}

function touchMoved() {
  if (state === "playing" && touches.length) {
    if (touches[0].y > height - 150) {
      leftHeld = touches[0].x < width / 2;
      rightHeld = touches[0].x >= width / 2;
    }
  }
  return false;
}

function touchEnded() {
  leftHeld = rightHeld = false;
  return false;
}

function keyPressed() {
  if (keyCode === LEFT_ARROW || key === "a") leftHeld = true;
  if (keyCode === RIGHT_ARROW || key === "d") rightHeld = true;
  if (key === " " && state !== "playing") {
    startSound();
    state = "playing";
    resetGame();
  }
  return false;
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || key === "a") leftHeld = false;
  if (keyCode === RIGHT_ARROW || key === "d") rightHeld = false;
  return false;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  setupSize();
  if (player) {
    player.w = carW;
    player.h = carH;
    player.y = height * 0.73;
    player.x = constrain(player.x, roadL + carW * 0.65, roadR - carW * 0.65);
  }
}
