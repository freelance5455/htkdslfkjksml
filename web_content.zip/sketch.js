let audio;
let tracks = [];
let currentTrack = -1;
let fileInput;

let volumeLevel = 0.8;
let isSeeking = false;

function setup() {
  createCanvas(windowWidth, windowHeight);
  textFont("Arial");
  audio = new Audio();
  audio.volume = volumeLevel;
  audio.preload = "metadata";

  fileInput = createFileInput(addMusic);
  fileInput.attribute("accept", "audio/*");
  fileInput.attribute("multiple", "");
  fileInput.style("display", "block");
  fileInput.style("width", "100%");
  fileInput.style("max-width", "300px");
  fileInput.style("font-size", "15px");
  fileInput.style("color", "white");
  fileInput.style("background", "#292044");
  fileInput.style("padding", "12px");
  fileInput.style("border-radius", "14px");
  fileInput.style("border", "1px solid #6650a8");

  audio.addEventListener("ended", nextTrack);
}

function draw() {
  background(9, 11, 25);

  let w = min(width - 28, 480);
  let x = (width - w) / 2;
  let top = max(15, (height - 720) / 2);

  // Header
  noStroke();
  fill(255);
  textAlign(LEFT, CENTER);
  textStyle(BOLD);
  textSize(25);
  text("♫ MY MUSIC", x, top + 20);

  fill(160, 135, 255);
  textSize(12);
  textStyle(NORMAL);
  text("AUDIO PLAYER", x + w - 105, top + 20);

  // Album art
  let artY = top + 55;
  let artH = min(210, height * 0.25);

  noStroke();
  for (let i = 0; i < artH; i++) {
    let amount = i / artH;
    fill(
      lerp(70, 20, amount),
      lerp(45, 25, amount),
      lerp(160, 75, amount)
    );
    rect(x, artY + i, w, 1);
  }

  // Animated music bars
  let playing = audio && !audio.paused;
  let barCount = 35;
  let gap = w / barCount;

  for (let i = 0; i < barCount; i++) {
    let bh = playing
      ? random(15, max(20, artH * 0.55))
      : 10 + 5 * sin(frameCount * 0.04 + i);

    fill(190, 165, 255, 180);
    rect(
      x + i * gap + 2,
      artY + artH / 2 - bh / 2,
      max(2, gap - 4),
      bh,
      4
    );
  }

  // Center music symbol
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(45);
  text("♫", width / 2, artY + artH / 2);

  // Current track
  let infoY = artY + artH + 35;

  fill(155, 145, 190);
  textSize(12);
  text("NOW PLAYING", x, infoY);

  fill(255);
  textStyle(BOLD);
  textSize(20);

  let name = currentTrack >= 0
    ? tracks[currentTrack].name
    : "ሙዚቃ ምረጥ";

  textAlign(LEFT, TOP);
  text(
    name.length > 32 ? name.substring(0, 29) + "..." : name,
    x, infoY + 20, w, 48
  );

  fill(160, 160, 185);
  textStyle(NORMAL);
  textSize(13);
  text(
    currentTrack >= 0
      ? "My Music • Track " + (currentTrack + 1)
      : "ከስልክህ ሙዚቃ ጨምር",
    x, infoY + 52
  );

  // Progress bar
  let progressY = infoY + 100;
  let barW = w;

  noStroke();
  fill(42, 40, 65);
  rect(x, progressY, barW, 7, 5);

  let duration = audio.duration || 0;
  let current = audio.currentTime || 0;
  let progress = duration > 0 ? current / duration : 0;

  fill(165, 135, 255);
  rect(x, progressY, barW * progress, 7, 5);

  fill(185, 180, 205);
  textSize(12);
  textAlign(LEFT, TOP);
  text(formatTime(current), x, progressY + 13);
  textAlign(RIGHT, TOP);
  text(formatTime(duration), x + w, progressY + 13);

  // Playback controls
  let controlsY = progressY + 65;
  let center = width / 2;

  drawButton(center - 88, controlsY, "⏮", 30, false);
  drawButton(center, controlsY, audio.paused ? "▶" : "Ⅱ", 34, true);
  drawButton(center + 88, controlsY, "⏭", 30, false);

  // Volume section
  let volumeY = controlsY + 65;

  fill(255);
  textAlign(LEFT, CENTER);
  textSize(15);
  text("🔊  Volume", x, volumeY);

  fill(40, 38, 62);
  rect(x + 95, volumeY - 4, w - 95, 8, 5);

  fill(165, 135, 255);
  rect(x + 95, volumeY - 4, (w - 95) * volumeLevel, 8, 5);

  // Playlist
  let listY = volumeY + 38;

  fill(255);
  textSize(17);
  textStyle(BOLD);
  textAlign(LEFT, CENTER);
  text("የሙዚቃ ዝርዝር", x, listY);

  fill(155, 150, 180);
  textSize(12);
  textStyle(NORMAL);
  textAlign(RIGHT, CENTER);
  text(tracks.length + " songs", x + w, listY);

  let rowY = listY + 25;
  let availableRows = floor(
    max(0, height - rowY - 20) / 48
  );
  let visibleRows = min(tracks.length, availableRows, 5);

  for (let i = 0; i < visibleRows; i++) {
    let index = i;
    let yy = rowY + i * 48;

    fill(index === currentTrack ? color(42, 33, 75) : color(20, 22, 42));
    rect(x, yy, w, 42, 10);

    fill(185, 165, 255);
    textAlign(LEFT, CENTER);
    textSize(18);
    text("♫", x + 12, yy + 21);

    fill(255);
    textSize(13);
    text(
      tracks[index].name.length > 27
        ? tracks[index].name.substring(0, 24) + "..."
        : tracks[index].name,
      x + 40, yy + 21
    );

    fill(170, 160, 200);
    textAlign(RIGHT, CENTER);
    text(index === currentTrack && playing ? "Ⅱ" : "▶", x + w - 14, yy + 21);
  }

  if (tracks.length === 0) {
    fill(145, 140, 175);
    textAlign(CENTER, CENTER);
    textSize(13);
    text("ሙዚቃ ለመጨመር ከላይ ያለውን የፋይል ቁልፍ ተጠቀም።",
      width / 2, rowY + 30, w - 10, 50);
  }

  // Keep file picker near bottom of the screen
  let pickerY = min(
    height - 58,
    max(rowY + visibleRows * 48 + 8, artY + artH + 340)
  );

  fileInput.position(x, pickerY);
  fileInput.size(w, 42);
}

function drawButton(cx, cy, label, size, primary) {
  noStroke();

  if (primary) {
    fill(165, 135, 255);
    circle(cx, cy, 58);
    fill(20, 15, 40);
  } else {
    fill(220);
  }

  textAlign(CENTER, CENTER);
  textSize(size);
  text(label, cx, cy);
}

function addMusic(file) {
  if (!file || !file.name || !file.type.startsWith("audio/")) {
    return;
  }

  tracks.push({
    name: file.name,
    data: file.data
  });

  if (currentTrack === -1) {
    loadTrack(0, false);
  }
}

function loadTrack(index, autoplay = true) {
  if (index < 0 || index >= tracks.length) return;

  currentTrack = index;
  audio.src = tracks[index].data;
  audio.load();

  if (autoplay) {
    audio.play().catch(() => {});
  }
}

function nextTrack() {
  if (!tracks.length) return;
  loadTrack((currentTrack + 1) % tracks.length);
}

function previousTrack() {
  if (!tracks.length) return;

  if (audio.currentTime > 3) {
    audio.currentTime = 0;
  } else {
    loadTrack(
      (currentTrack - 1 + tracks.length) % tracks.length
    );
  }
}

function formatTime(seconds) {
  if (!Number.isFinite(seconds)) return "0:00";
  let m = floor(seconds / 60);
  let s = floor(seconds % 60);
  return m + ":" + String(s).padStart(2, "0");
}

function mousePressed() {
  let w = min(width - 28, 480);
  let x = (width - w) / 2;
  let top = max(15, (height - 720) / 2);
  let artY = top + 55;
  let artH = min(210, height * 0.25);
  let infoY = artY + artH + 35;
  let progressY = infoY + 100;
  let controlsY = progressY + 65;
  let volumeY = controlsY + 65;
  let center = width / 2;

  // Seek
  if (
    mouseY >= progressY - 12 &&
    mouseY <= progressY + 25 &&
    mouseX >= x &&
    mouseX <= x + w
  ) {
    if (audio.duration) {
      audio.currentTime =
        constrain((mouseX - x) / w, 0, 1) * audio.duration;
    }
    return false;
  }

  // Previous
  if (dist(mouseX, mouseY, center - 88, controlsY) < 30) {
    previousTrack();
    return false;
  }

  // Play / Pause
  if (dist(mouseX, mouseY, center, controlsY) < 34) {
    if (currentTrack < 0) {
      if (tracks.length) loadTrack(0);
    } else if (audio.paused) {
      audio.play().catch(() => {});
    } else {
      audio.pause();
    }
    return false;
  }

  // Next
  if (dist(mouseX, mouseY, center + 88, controlsY) < 30) {
    nextTrack();
    return false;
  }

  // Volume
  if (
    mouseY >= volumeY - 18 &&
    mouseY <= volumeY + 18 &&
    mouseX >= x + 95 &&
    mouseX <= x + w
  ) {
    volumeLevel = constrain((mouseX - x - 95) / (w - 95), 0, 1);
    audio.volume = volumeLevel;
    return false;
  }

  // Playlist
  let listY = volumeY + 38;
  let rowY = listY + 25;

  if (mouseY >= rowY && mouseX >= x && mouseX <= x + w) {
    let index = floor((mouseY - rowY) / 48);
    if (index >= 0 && index < tracks.length && index < 5) {
      loadTrack(index);
      return false;
    }
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
