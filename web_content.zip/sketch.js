
let player, obstacles, coins;
let groundY, score = 0, gameOver = false;
let speed = 5;
let audioCtx;
let lastObstacle = 0;
let lastCoin = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  groundY = height * 0.82;
  player = {
    x: width * 0.18,
    y: groundY - 42,
    w: 32,
    h: 42,
    vy: 0,
    jumping: false
  };
  obstacles = [];
  coins = [];
  textFont("sans-serif");
}

function draw() {
  background(135, 206, 235);

  // ሰማይና ደመና
  noStroke();
  fill(255, 255, 255, 210);
  ellipse(width * 0.22, height * 0.15, 75, 28);
  ellipse(width * 0.27, height * 0.14, 55, 35);
  ellipse(width * 0.72, height * 0.22, 90, 30);

  // መሬት
  fill(70, 180, 75);
  rect(0, groundY, width, height - groundY);
  fill(100, 65, 35);
  rect(0, groundY + 12, width, height - groundY);

  if (!gameOver) {
    score++;
    speed = min(8, 5 + score / 3000);

    // መሰናክሎች
    if (frameCount - lastObstacle > 95) {
      obstacles.push({
        x: width + 20,
        w: random(24, 35),
        h: random(30, 48)
      });
      lastObstacle = frameCount;
    }

    for (let o of obstacles) {
      o.x -= speed;
      fill(210, 65, 45);
      rect(o.x, groundY - o.h, o.w, o.h, 5);

      // የመሰናክል ግጭት
      if (
        player.x + player.w - 5 > o.x &&
        player.x + 5 < o.x + o.w &&
        player.y + player.h > groundY - o.h
      ) {
        gameOver = true;
        playSound(100, 0.35);
      }
    }

    obstacles = obstacles.filter(o => o.x + o.w > 0);

    // ሳንቲሞች
    if (frameCount - lastCoin > 65) {
      coins.push({
        x: width + 15,
        y: groundY - random(65, 100),
        r: 10
      });
      lastCoin = frameCount;
    }

    for (let c of coins) {
      c.x -= speed;
      fill(255, 205, 0);
      stroke(230, 140, 0);
      strokeWeight(2);
      ellipse(c.x, c.y, c.r * 2);
      noStroke();

      if (
        dist(
          player.x + player.w / 2,
          player.y + player.h / 2,
          c.x, c.y
        ) < 28
      ) {
        c.collected = true;
        score += 100;
        playSound(750, 0.08);
      }
    }

    coins = coins.filter(c => c.x > -20 && !c.collected);

    // ተጫዋቹ
    player.vy += 0.7;
    player.y += player.vy;

    if (player.y + player.h >= groundY) {
      player.y = groundY - player.h;
      player.vy = 0;
      player.jumping = false;
    }
  }

  // ተጫዋቹን አሳይ
  noStroke();
  fill(35, 75, 220);
  rect(player.x, player.y, player.w, player.h, 8);

  fill(255);
  ellipse(player.x + 22, player.y + 10, 9, 9);
  fill(0);
  ellipse(player.x + 24, player.y + 10, 4, 4);

  fill(255);
  textSize(22);
  textAlign(LEFT, TOP);
  text("Score: " + floor(score), 15, 15);

  if (gameOver) {
    fill(0, 0, 0, 160);
    rect(0, 0, width, height);

    fill(255);
    textAlign(CENTER, CENTER);
    textSize(34);
    text("GAME OVER", width / 2, height / 2 - 40);

    textSize(20);
    text("Score: " + floor(score), width / 2, height / 2);

    fill(255, 205, 0);
    rect(width / 2 - 85, height / 2 + 35, 170, 48, 12);

    fill(30);
    textSize(19);
    text("TAP TO RESTART", width / 2, height / 2 + 59);
  }
}

// ዝላይን ያነሰ አድርግ
function jump() {
  if (!player.jumping && !gameOver) {
    player.vy = -height * 0.015;
    player.jumping = true;
    playSound(350, 0.08);
  }
}

function mousePressed() {
  handleAction();
  return false;
}

function touchStarted() {
  handleAction();
  return false;
}

function handleAction() {
  if (gameOver) {
    score = 0;
    speed = 5;
    obstacles = [];
    coins = [];
    gameOver = false;
    player.y = groundY - player.h;
    player.vy = 0;
    player.jumping = false;
    lastObstacle = frameCount;
    lastCoin = frameCount;
  } else {
    jump();
  }
}

// የጨዋታ ድምፅ
function playSound(freq, duration) {
  try {
    if (!audioCtx) {
      audioCtx = new (
        window.AudioContext || window.webkitAudioContext
      )();
    }

    if (audioCtx.state === "suspended") {
      audioCtx.resume();
    }

    let osc = audioCtx.createOscillator();
    let gain = audioCtx.createGain();

    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(
      0.001,
      audioCtx.currentTime + duration
    );

    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch (e) {}
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  groundY = height * 0.82;

  if (!player.jumping) {
    player.y = groundY - player.h;
  }
}
