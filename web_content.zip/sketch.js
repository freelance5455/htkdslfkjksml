let player, obstacles = [], coins = [];
let score = 0, started = false, gameOver = false;
let groundY, speed = 6, audio;
let lastObstacle = 0, lastCoin = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  textFont("sans-serif");
  resetGame();
  started = false;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  groundY = height - max(65, height * 0.13);
  player.x = width * 0.17;
  if (player.y + player.h > groundY) {
    player.y = groundY - player.h;
    player.vy = 0;
  }
}

function resetGame() {
  groundY = height - max(65, height * 0.13);
  player = {
    x: width * 0.17,
    y: groundY - 78,
    w: 38,
    h: 78,
    vy: 0
  };
  obstacles = [];
  coins = [];
  score = 0;
  speed = 6;
  lastObstacle = frameCount;
  lastCoin = frameCount;
  gameOver = false;
}

function draw() {
  background(100, 195, 255);

  // ሰማይና ደመና
  noStroke();
  fill(255, 232, 100);
  circle(width * 0.82, height * 0.13, 55);

  fill(255, 255, 255, 220);
  ellipse(width * 0.25, height * 0.15, 90, 30);
  ellipse(width * 0.30, height * 0.14, 65, 35);
  ellipse(width * 0.58, height * 0.22, 100, 30);

  // መሬት
  fill(62, 175, 75);
  rect(0, groundY, width, height - groundY);
  fill(40, 130, 52);
  rect(0, groundY, width, 8);

  // የመሬት መንቀሳቀስ
  fill(230, 220, 150);
  for (let i = 0; i < 12; i++) {
    let x = ((i * 100 - frameCount * speed) % (width + 100) + width + 100) % (width + 100);
    rect(x, groundY + 25, 35, 5, 3);
  }

  // ትልቅ ርዕስና ነጥብ
  fill(15, 35, 75);
  textAlign(LEFT);
  textSize(constrain(width * 0.055, 22, 36));
  text("BUTNA RUN", 18, 42);
  textSize(constrain(width * 0.045, 19, 30));
  text("SCORE: " + score, 18, 78);

  if (!started) {
    drawPerson();
    fill(10, 30, 65);
    textAlign(CENTER);
    textSize(constrain(width * 0.065, 24, 38));
    text("BUTNA RUN", width / 2, height * 0.34);
    textSize(constrain(width * 0.04, 17, 25));
    text("TAP TO START", width / 2, height * 0.43);
    text("Tap to jump!", width / 2, height * 0.49);
    return;
  }

  if (gameOver) {
    drawPerson();
    fill(0, 0, 0, 165);
    rect(0, 0, width, height);

    textAlign(CENTER);
    fill(255, 80, 70);
    textSize(constrain(width * 0.09, 32, 55));
    text("GAME OVER!", width / 2, height * 0.38);

    fill(255);
    textSize(27);
    text("SCORE: " + score, width / 2, height * 0.46);

    fill(255, 200, 35);
    rect(width / 2 - 105, height * 0.53, 210, 62, 15);
    fill(25);
    textSize(25);
    text("RESTART", width / 2, height * 0.53 + 39);
    return;
  }

  // የመዝለል ስርዓት
  player.vy += 0.8;
  player.y += player.vy;

  if (player.y + player.h >= groundY) {
    player.y = groundY - player.h;
    player.vy = 0;
  }

  // እንቅፋቶች
  if (millis() - lastObstacle > max(550, 1250 - score * 2)) {
    obstacles.push({
      x: width + 20,
      w: 34,
      h: random(35, 52)
    });
    lastObstacle = millis();
  }

  for (let o of obstacles) {
    o.x -= speed;

    fill(145, 70, 40);
    rect(o.x, groundY - o.h, o.w, o.h, 7);
    fill(190, 105, 60);
    triangle(o.x, groundY - o.h, o.x + 16, groundY - o.h - 15,
             o.x + 30, groundY - o.h);

    // ግጭት
    let px = player.x + 8;
    let py = player.y + 5;
    if (px + player.w - 12 > o.x &&
        px < o.x + o.w &&
        py + player.h - 8 > groundY - o.h) {
      gameOver = true;
      playTone(120, 0.35);
    }
  }
  obstacles = obstacles.filter(o => o.x + o.w > 0);

  // ሳንቲሞች
  if (millis() - lastCoin > 900) {
    coins.push({
      x: width + 20,
      y: groundY - random(100, 175),
      r: 15,
      taken: false
    });
    lastCoin = millis();
  }

  for (let c of coins) {
    c.x -= speed;
    fill(255, 198, 0);
    stroke(190, 125, 0);
    strokeWeight(2);
    circle(c.x, c.y, c.r * 2);
    noStroke();
    fill(125, 75, 0);
    textAlign(CENTER);
    textSize(17);
    text("$", c.x, c.y + 6);

    if (!c.taken &&
        dist(player.x + player.w / 2,
              player.y + player.h / 2,
              c.x, c.y) < 34) {
      c.taken = true;
      score += 10;
      playTone(850, 0.12);
    }
  }
  coins = coins.filter(c => c.x > 0 && !c.taken);

  speed = 6 + floor(score / 100) * 0.4;
  drawPerson();
}

// የሰው ተጫዋች አካልና የሩጫ እንቅስቃሴ
function drawPerson() {
  let x = player.x;
  let y = player.y;
  let running = started && !gameOver &&
                y + player.h >= groundY - 1;
  let swing = running ? sin(frameCount * 0.45) * 12 : 0;

  push();
  rectMode(CORNER);
  strokeCap(ROUND);
  strokeJoin(ROUND);

  // ጫማና እግሮች
  stroke(30, 45, 90);
  strokeWeight(8);
  line(x + 18, y + 53, x + 16 + swing, y + 69);
  line(x + 22, y + 53, x + 24 - swing, y + 69);

  // ሰማያዊ ሱሪ
  noStroke();
  fill(35, 75, 185);
  rect(x + 9, y + 42, 22, 18, 5);

  // ጫማዎች
  stroke(25);
  strokeWeight(6);
  line(x + 16 + swing, y + 69, x + 8 + swing, y + 72);
  line(x + 24 - swing, y + 69, x + 32 - swing, y + 72);

  // እጆች
  stroke(120, 65, 38);
  strokeWeight(7);
  line(x + 10, y + 27, x + 3 + swing, y + 43);
  line(x + 29, y + 27, x + 36 - swing, y + 40);

  // ሰውነትና ቲሸርት
  noStroke();
  fill(235, 55, 55);
  rect(x + 7, y + 20, 27, 27, 7);

  // አንገት
  fill(120, 65, 38);
  rect(x + 17, y + 15, 9, 10, 3);

  // ጭንቅላት
  fill(150, 88, 53);
  circle(x + 21, y + 11, 25);

  // ፀጉር
  fill(35, 25, 20);
  arc(x + 21, y + 9, 25, 23, PI, TWO_PI);

  // ዓይን
  fill(255);
  circle(x + 27, y + 11, 5);
  fill(20);
  circle(x + 28, y + 11, 2.5);

  // ፈገግታ
  noFill();
  stroke(65, 25, 20);
  strokeWeight(1.5);
  arc(x + 25, y + 16, 8, 5, 0, PI);

  pop();
}

function jump() {
  if (!started) {
    started = true;
    playTone(500, 0.1);
    return;
  }
  if (gameOver) return;

  if (player.y + player.h >= groundY - 1) {
    player.vy = -15;
    playTone(550, 0.1);
  }
}

function mousePressed() {
  if (gameOver &&
      mouseX > width / 2 - 110 &&
      mouseX < width / 2 + 110 &&
      mouseY > height * 0.53 &&
      mouseY < height * 0.53 + 70) {
    resetGame();
    return;
  }
  jump();
}

function touchStarted() {
  if (gameOver) {
    if (mouseX > width / 2 - 110 &&
        mouseX < width / 2 + 110 &&
        mouseY > height * 0.53 &&
        mouseY < height * 0.53 + 70) {
      resetGame();
    }
  } else {
    jump();
  }
  return false;
}

function keyPressed() {
  if (key === " " || keyCode === UP_ARROW) {
    jump();
    return false;
  }
}

function playTone(freq, duration) {
  try {
    if (!audio) {
      audio = new (window.AudioContext ||
                   window.webkitAudioContext)();
    }
    if (audio.state === "suspended") audio.resume();

    let osc = audio.createOscillator();
    let gain = audio.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.12, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(
      0.001, audio.currentTime + duration
    );
    osc.connect(gain);
    gain.connect(audio.destination);
    osc.start();
    osc.stop(audio.currentTime + duration);
  } catch (e) {}
}
