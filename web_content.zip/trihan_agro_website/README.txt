# Trihan Agro Website

## Files
- index.html
- style.css
- script.js
- assets/trihan-agro-logo.png

## Run
Open `index.html` in any modern browser.

## Replace the logo
Replace:
`assets/trihan-agro-logo.png`

Keep the same filename, or change the `<img src>` paths in `index.html`.

## Replace farm photos
The website was originally built with placeholder image URLs, but this updated package uses your uploaded local images instead.

Replace each image URL with your own local image, for example:
`assets/images/cattle-1.jpg`

Then put your photos inside:
`assets/images/`

## Important contact details to update
- Email: `info@trihanagro.com`
- Facebook: current link is a placeholder Facebook homepage
- Google Maps: update the search URL if you have the exact farm map link

The contact form is front-end only. It validates input and shows a success message, but it does not send email until connected to a backend or form service.


UPDATED WITH YOUR UPLOADED PHOTOS
- Logo: assets/trihan-agro-logo.png
- Cattle: assets/images/cattle-closeup.jpg, cattle-field.jpg
- Poultry: assets/images/poultry-house.jpg, poultry-farm.jpg
- Fish: assets/images/fish-pond-1.jpg, fish-pond-2.jpg
- All image URLs have been replaced with local files so the website can work without Unsplash images.
