from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os, threading, webbrowser
os.chdir(Path(__file__).resolve().parent)
PORT=8794
class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.split('?')[0]=='/__lumii_version':
            data=b'Lumii-Premium-9.5.1-Revisao-Geral'
            self.send_response(200)
            self.send_header('Content-Type','text/plain; charset=utf-8')
            self.send_header('Content-Length',str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        return super().do_GET()
    def end_headers(self):
        self.send_header('Cache-Control','no-cache, no-store, must-revalidate')
        self.send_header('X-Content-Type-Options','nosniff')
        super().end_headers()
try:
    server=ThreadingHTTPServer(('127.0.0.1',PORT),Handler)
except OSError as exc:
    print('Nao foi possivel abrir a porta 8794. Feche a versao anterior da Lumii. Detalhes:',exc)
    raise SystemExit(1)
threading.Timer(0.5, lambda: webbrowser.open('http://127.0.0.1:8794/index.html',new=2)).start()
print('Lumii 9.5.1 ativa em http://127.0.0.1:8794/index.html')
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
