(()=>{
'use strict';
const PLANS='lumii-meses-planejados-v86', REAL='lumii-aportes-reais-v902';
const $=id=>document.getElementById(id);
const money=v=>Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const fmtMonth=s=>{if(!/^20\d\d-(0[1-9]|1[0-2])$/.test(s))return s;const [y,m]=s.split('-').map(Number);return new Intl.DateTimeFormat('pt-BR',{month:'long',year:'numeric',timeZone:'UTC'}).format(new Date(Date.UTC(y,m-1,1)))};
const el=(tag,cls,txt)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(txt!==undefined)n.textContent=txt;return n};
const get=(key)=>{try{const a=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(a)?a:[]}catch{return []}};
const plans=()=>get(PLANS).filter(p=>p&&typeof p.id==='string'&&Array.isArray(p.rows));
const records=()=>get(REAL).filter(a=>a&&typeof a.id==='string'&&typeof a.planId==='string'&&Number.isFinite(a.amount)&&a.amount>0&&/^\d{4}-\d\d-\d\d$/.test(a.date));
const total=p=>p.rows.reduce((s,r)=>s+(Number.isFinite(Number(r.amount))&&Number(r.amount)>=0?Number(r.amount):0),0);
function saveRecord(a){const prev=records(),next=[...prev,a];localStorage.setItem(REAL,JSON.stringify(next));if(!records().some(x=>x.id===a.id))throw Error('A gravação não foi confirmada.');}
function removeRecord(id){const next=records().filter(x=>x.id!==id);localStorage.setItem(REAL,JSON.stringify(next));if(records().some(x=>x.id===id))throw Error('A exclusão não foi confirmada.');}
function render(){const all=plans(),allReal=records();for(const [rootId,compact] of [['v901Home',true],['v901Goals',false]]){
 const root=$(rootId);if(!root)continue;root.replaceChildren();
 const head=el('div','v901-head');head.append(el('h3','',compact?'🎯 Meus planejamentos e progresso':'🌿 Planejamentos e aportes reais'),el('span','v901-chip','Lumii Premium · v9.0.2'));root.append(head);
 if(!all.length){root.append(el('p','v901-note','Nenhum planejamento encontrado nesta instalação. Salve um plano na aba Importar ou importe um backup de planejamentos. Suas metas cadastradas continuam separadas.'));continue;}
 const sumGoal=all.reduce((s,p)=>s+total(p),0),sumSaved=allReal.filter(a=>all.some(p=>p.id===a.planId)).reduce((s,a)=>s+a.amount,0);
 const overview=el('div','v902-overview');for(const [label,value] of [['Total planejado',sumGoal],['Aportes registrados',sumSaved],['Falta para os objetivos',Math.max(0,sumGoal-sumSaved)]]){const b=el('div','v902-stat');b.append(el('small','',label),el('strong','',money(value)));overview.append(b)}root.append(overview);
 const grid=el('div','v901-grid');
 for(const p of all){const goal=total(p),r=allReal.filter(x=>x.planId===p.id),saved=r.reduce((s,a)=>s+a.amount,0),pct=goal>0?Math.min(100,saved/goal*100):0;
 const card=el('article','v901-card v902-card');card.append(el('h4','',p.name||'Planejamento'));
 const stats=el('div','v902-statline');stats.append(el('span','',`Planejado: ${money(goal)}`),el('strong','',`Guardado: ${money(saved)}`));card.append(stats);
 const meter=el('div','v901-meter');const bar=el('div');bar.style.width=pct.toFixed(2)+'%';meter.append(bar);card.append(meter);
 card.append(el('p','v901-months',`${pct.toFixed(1).replace('.',',')}% concluído · Falta ${money(Math.max(0,goal-saved))}`));
 const rows=p.rows.filter(x=>/^20\d\d-(0[1-9]|1[0-2])$/.test(x.month));if(rows.length)card.append(el('p','v901-months',`${rows.length} aporte(s) previstos · ${fmtMonth(rows[0].month)} até ${fmtMonth(rows[rows.length-1].month)}`));
 if(!compact){const details=el('details');details.append(el('summary','','Ver planejamento mensal'));for(const x of rows)details.append(el('p','v901-months',`${fmtMonth(x.month)} — ${money(x.amount)}`));card.append(details);
 const form=el('form','v902-form');const label=el('strong','','Registrar dinheiro realmente guardado');form.append(label);
 const inputs=el('div','v902-inputs');const date=el('input');date.type='date';date.required=true;date.value=new Date().toLocaleDateString('en-CA');date.setAttribute('aria-label','Data do aporte');const amount=el('input');amount.type='number';amount.step='0.01';amount.min='0.01';amount.max='100000000';amount.required=true;amount.placeholder='Valor guardado (R$)';amount.setAttribute('aria-label','Valor realmente guardado');const btn=el('button','primary','Registrar aporte');btn.type='submit';inputs.append(date,amount,btn);form.append(inputs);
 const msg=el('p','v902-msg');msg.setAttribute('role','status');form.append(msg);
 form.onsubmit=e=>{e.preventDefault();const val=Number(amount.value);if(!Number.isFinite(val)||val<=0||val>100000000||!/^\d{4}-\d\d-\d\d$/.test(date.value)){msg.textContent='Informe uma data e um valor válido.';return;}if(!confirm(`Registrar ${money(val)} como dinheiro realmente guardado em ${date.value}?`))return;
 try{saveRecord({id:'aporte-'+Date.now()+'-'+Math.random().toString(36).slice(2),planId:p.id,date:date.value,amount:Math.round(val*100)/100});render()}catch(err){msg.textContent='Não foi possível salvar: '+err.message}};card.append(form);
 const history=el('details');history.append(el('summary','',`Histórico de aportes reais (${r.length})`));if(!r.length)history.append(el('p','v901-note','Nenhum aporte real registrado.'));for(const a of r.slice().sort((x,y)=>y.date.localeCompare(x.date))){const line=el('div','v902-history');line.append(el('span','',`${a.date.split('-').reverse().join('/')} — ${money(a.amount)}`));const del=el('button','','Excluir');del.type='button';del.onclick=()=>{if(!confirm(`Excluir o aporte de ${money(a.amount)}?`))return;try{removeRecord(a.id);render()}catch(err){alert('Erro ao excluir: '+err.message)}};line.append(del);history.append(line)}card.append(history);
 }grid.append(card)}root.append(grid);
 root.append(el('p','v901-note','Os aportes reais são registrados separadamente do planejamento e não são lançamentos bancários. Os dados ficam neste navegador; exporte backups regularmente.'));
 }}
render();document.querySelectorAll('.tabs button').forEach(b=>b.addEventListener('click',()=>setTimeout(render,0)));
window.addEventListener('storage',e=>{if([PLANS,REAL].includes(e.key))render()});
$('simpleShow86')?.addEventListener('click',()=>setTimeout(render,0));
document.addEventListener('click',e=>{if(e.target?.textContent?.includes('Salvar somente meses e valores'))setTimeout(render,250)});
window.lumiiRefreshPlans902=render;
})();
