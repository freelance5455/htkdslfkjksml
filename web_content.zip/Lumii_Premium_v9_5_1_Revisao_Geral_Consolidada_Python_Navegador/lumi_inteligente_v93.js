(()=>{'use strict';
const card=document.getElementById('lumiCard');if(!card||document.getElementById('l93Panel'))return;
const panel=document.createElement('section');panel.id='l93Panel';panel.className='l93-panel';panel.setAttribute('aria-label','Análise financeira local da Lumi');
const title=document.createElement('h3');title.textContent='✨ Lumi Inteligente';
const info=document.createElement('p');info.className='l93-muted';info.textContent='Orientações calculadas neste dispositivo, sem enviar seus dados a uma IA ou servidor. Não são recomendações bancárias.';
const btn=document.createElement('button');btn.type='button';btn.className='l93-refresh';btn.textContent='Analisar meus registros';
const result=document.createElement('div');result.id='l93Insights';result.setAttribute('aria-live','polite');
const stamp=document.createElement('small');stamp.className='l93-muted';stamp.textContent='Os dados só são lidos quando você solicita a análise.';
panel.append(title,info,btn,result,stamp);
const bottom=card.querySelector('.lumi-card-bottom');if(bottom)card.insertBefore(panel,bottom);else card.append(panel);
const fmt=n=>Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const read=(k,f)=>{try{const x=JSON.parse(localStorage.getItem(k)||'null');return x===null?f:x}catch{return f}};
const num=n=>typeof n==='number'&&Number.isFinite(n)?n:0;
const text=(tag,s,cls)=>{const n=document.createElement(tag);n.textContent=s;if(cls)n.className=cls;return n};
const today=new Date();
function analyze(){
 const data=read('dval-premium-v1',{});const mov=Array.isArray(data.mov)?data.mov:[];const div=Array.isArray(data.div)?data.div:[];const metas=Array.isArray(data.metas)?data.metas:[];
 const plans=read('lumii-meses-planejados-v86',[]);const aportes=read('lumii-aportes-reais-v902',[]);
 const ym=new Date().getFullYear()+'-'+String(new Date().getMonth()+1).padStart(2,'0');
 const month=mov.filter(m=>m&&typeof m.data==='string'&&m.data.slice(0,7)===ym);
 const income=month.filter(m=>m.tipo==='receita').reduce((s,m)=>s+num(m.valor),0);
 const expense=month.filter(m=>m.tipo==='despesa').reduce((s,m)=>s+num(m.valor),0);
 const tips=[];
 if(!mov.length&&!div.length&&!metas.length&&!(Array.isArray(plans)&&plans.length))tips.push(['Primeiro passo','Ainda não encontrei registros financeiros nesta instalação. Cadastre uma receita ou despesa em Lançamentos.']);
 if(month.length){tips.push(['Resumo do mês',`Entradas registradas: ${fmt(income)}. Saídas: ${fmt(expense)}. Diferença: ${fmt(income-expense)}. Este valor não é necessariamente o saldo da sua conta.`]);if(income>0&&expense>income)tips.push(['Atenção ao orçamento',`As despesas registradas superam as receitas em ${fmt(expense-income)} neste mês. Confira se os lançamentos estão completos antes de assumir novos compromissos.`]);else if(income>expense)tips.push(['Espaço no orçamento',`A diferença positiva registrada é ${fmt(income-expense)}. Confira contas ainda não lançadas antes de decidir quanto reservar.`]);}
 else if(mov.length)tips.push(['Lançamentos do mês','Você tem registros anteriores, mas ainda não há lançamentos datados neste mês. Confira as datas e registre o movimento atual.']);
 if(div.length){const total=div.reduce((s,d)=>s+Math.max(0,num(d.saldo)),0);tips.push(['Dívidas cadastradas',`${div.length} dívida(s), somando ${fmt(total)} nos saldos informados. Isso não representa cotação de quitação atualizada.`]);
 const nowIso=new Date().getFullYear()+'-'+String(new Date().getMonth()+1).padStart(2,'0')+'-'+String(new Date().getDate()).padStart(2,'0');
 const next=div.filter(d=>typeof d.vencimento==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d.vencimento)&&d.vencimento>=nowIso).sort((a,b)=>a.vencimento.localeCompare(b.vencimento))[0];
 if(next)tips.push(['Próximo vencimento',`${next.nome||'Dívida'}: ${next.vencimento.split('-').reverse().join('/')} (${fmt(next.parcela)} informados por parcela). Confirme a data e o pagamento com o credor.`]);}
 if(metas.length){const pending=metas.filter(g=>num(g.alvo)>num(g.atual));if(pending.length){const g=pending[0];tips.push(['Meta em andamento',`${g.nome||'Sua meta'}: ${fmt(num(g.atual))} de ${fmt(num(g.alvo))}. Faltam ${fmt(Math.max(0,num(g.alvo)-num(g.atual)))} conforme os dados cadastrados.`]);}else tips.push(['Metas cadastradas','As metas cadastradas mostram os valores desejados alcançados. Confirme se os registros refletem o dinheiro efetivamente reservado.']);}
 if(Array.isArray(plans)&&plans.length){const valid=plans.filter(p=>p&&Array.isArray(p.rows));if(valid.length){const ids=new Set(valid.map(p=>p.id));const target=valid.reduce((s,p)=>s+p.rows.reduce((a,r)=>a+Math.max(0,num(r.amount)),0),0);const saved=Array.isArray(aportes)?aportes.filter(a=>a&&ids.has(a.planId)).reduce((s,a)=>s+Math.max(0,num(a.amount)),0):0;tips.push(['Planejamentos importados',`${valid.length} planejamento(s). Previsto: ${fmt(target)}; aportes registrados: ${fmt(saved)}. Valores planejados não são dinheiro guardado.`]);}}
 if(!tips.length)tips.push(['Organize aos poucos','Preencha suas movimentações, dívidas e metas para receber orientações baseadas nos registros.']);
 result.replaceChildren();for(const [heading,body] of tips){const item=text('div','','l93-insight');item.append(text('strong',heading),text('p',body));result.append(item)}
 stamp.textContent='Análise local atualizada agora. Informações educativas; confira os dados e valores oficiais.';
}
btn.addEventListener('click',analyze);
const toggle=document.getElementById('lumiToggle');if(toggle)toggle.addEventListener('click',()=>{if(!card.hidden&&result.childElementCount===0)stamp.textContent='Clique em “Analisar meus registros” para ver as orientações.'});
})();