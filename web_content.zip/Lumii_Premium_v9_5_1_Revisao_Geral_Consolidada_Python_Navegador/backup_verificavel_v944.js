(function(){
'use strict';
function init(){
 if(document.getElementById('lumii-backup-v944'))return;
 const wrap=document.createElement('div');wrap.id='lumii-backup-v944';
 wrap.style.cssText='position:fixed;right:14px;bottom:14px;z-index:2147482000;font-family:Arial,sans-serif;max-width:280px';
 const toggle=document.createElement('button');toggle.type='button';toggle.textContent='🛡️ Conferir backup';toggle.setAttribute('aria-expanded','false');
 toggle.style.cssText='background:#175a47;color:white;border:1px solid #d9c58a;border-radius:18px;padding:9px 14px;cursor:pointer;box-shadow:0 2px 9px #0002';
 const panel=document.createElement('div');panel.hidden=true;panel.style.cssText='margin-top:6px;background:#fffdf5;color:#193c2f;border:1px solid #d7d7c6;border-radius:12px;padding:12px;box-shadow:0 3px 14px #0002;font-size:13px';
 const title=document.createElement('strong');title.textContent='Cópia de segurança';
 const desc=document.createElement('p');desc.textContent='Exporte uma cópia dos dados locais da Lumii. Nenhum dado é enviado à internet.';
 const status=document.createElement('p');status.setAttribute('role','status');status.style.cssText='font-size:12px;overflow-wrap:anywhere';
 const exportBtn=document.createElement('button');exportBtn.type='button';exportBtn.textContent='Baixar backup completo';
 const verifyBtn=document.createElement('button');verifyBtn.type='button';verifyBtn.textContent='Conferir arquivo JSON';
 const file=document.createElement('input');file.type='file';file.accept='.json,application/json';file.hidden=true;
 for(const b of [exportBtn,verifyBtn])b.style.cssText='display:block;margin:8px 0;padding:8px;border:1px solid #277359;border-radius:8px;background:#edf7f0;color:#174f3e;cursor:pointer;width:100%';
 toggle.onclick=()=>{panel.hidden=!panel.hidden;toggle.setAttribute('aria-expanded',String(!panel.hidden));if(!panel.hidden){let n=0;try{for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(/lumii|dval|premium|meses|cronograma/i.test(k))n++}status.textContent=n+' conjunto(s) de dados financeiros identificado(s) neste navegador.'}catch(e){status.textContent='Não foi possível ler o armazenamento: '+e.message}}};
 exportBtn.onclick=()=>{try{
  const data={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(/lumii|dval|premium|meses|cronograma/i.test(k))data[k]=localStorage.getItem(k)}
  if(!Object.keys(data).length){status.textContent='Nenhum dado da Lumii encontrado neste navegador. Confira se você abriu a versão correta.';return}
  const obj={format:'lumii-local-backup-v1',createdAt:new Date().toISOString(),origin:location.origin,items:data};
  const blob=new Blob([JSON.stringify(obj,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='lumii-backup-'+new Date().toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);
  status.textContent='Backup gerado com '+Object.keys(data).length+' conjunto(s). Guarde o arquivo em local seguro.';
 }catch(e){status.textContent='Falha ao gerar backup: '+e.message}};
 verifyBtn.onclick=()=>file.click();
 file.onchange=async()=>{const f=file.files&&file.files[0];if(!f)return;try{if(f.size>20*1024*1024)throw Error('Arquivo maior que 20 MB.');const obj=JSON.parse(await f.text());const checked=window.LumiiBackupFormatos951.validate(obj);status.textContent='Arquivo reconhecido: '+checked.count+' conjunto(s), criado em '+(obj.createdAt||'data não informada')+'. Esta conferência NÃO importa nem altera dados.'}catch(e){status.textContent='Não foi possível validar: '+e.message}file.value=''};
 panel.append(title,desc,exportBtn,verifyBtn,file,status);wrap.append(toggle,panel);document.body.appendChild(wrap);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
