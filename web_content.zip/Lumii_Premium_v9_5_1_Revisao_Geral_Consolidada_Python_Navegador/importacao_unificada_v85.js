(()=>{'use strict';
const $=id=>document.getElementById(id);
const debt=$('impDebtChoice'), expense=$('impExpenseChoice'), image=$('impImageChoice');
const debtArea=$('impDebtArea'),expenseArea=$('impExpenseArea'),imageArea=$('impImageArea');
const slot=$('lumii85ImageSlot'),plan=$('imgPlanImport');
if(!image||!slot||!plan)return;
slot.appendChild(plan);
// Only one active mode; all routes (Python shortcut, normal browser, Edge PWA) use this same HTML.
function choose(mode){
 const isImage=mode==='image',isDebt=mode==='debt',isExpense=mode==='expense';
 imageArea.hidden=!isImage;debtArea.hidden=!isDebt;expenseArea.hidden=!isExpense;
 for(const [el,on] of [[debt,isDebt],[expense,isExpense],[image,isImage]]){
  el.classList.toggle('active',on);el.setAttribute('aria-pressed',String(on));
 }
 if(isImage)imageArea.scrollIntoView({block:'nearest',behavior:'smooth'});
}
// Existing old handlers fire first, then this one sets the correct final state.
debt.addEventListener('click',()=>choose('debt'));
expense.addEventListener('click',()=>choose('expense'));
image.addEventListener('click',()=>choose('image'));
const old=$('textoPremium');
const button=$('sendPlan841');
if(button)button.addEventListener('click',()=>{
 choose('image');
 const txt=$('planText84');if(old?.value.trim())txt.value=old.value;
 const analyze=$('planAnalyze84');if(txt.value.trim())analyze?.click();
},true);
const direct=$('planAnalyze84');
// If OCR has recognized text, show feedback even when the parser cannot identify amounts.
if(direct)direct.addEventListener('click',()=>{
 const text=$('planText84')?.value||'';
 if(!text.trim())return;
 setTimeout(()=>{
  const preview=$('planPreview84'),status=$('planStatus84');
  if(preview?.hidden){preview.hidden=false;preview.textContent='A análise não conseguiu interpretar este texto. Confira o texto extraído e tente novamente.';}
  if(status&&!status.textContent.trim())status.textContent='Revise os campos antes de salvar.';
 },50);
});
// Existing experimental image flow can still be used, but point users to the right tool.
const oldParent=old?.closest('.imp-more-inner');
if(oldParent){
 const go=document.createElement('button');go.type='button';go.className='primary';
 go.textContent='📸 Usar o novo leitor de planos (recomendado)';
 go.style.cssText='display:block;width:100%;margin:10px 0;background:#176b4c;color:white';
 go.addEventListener('click',()=>{
  choose('image');if(old.value.trim()){$('planText84').value=old.value;$('planAnalyze84')?.click();}
 });
 oldParent.prepend(go);
}
// Expose a clear version indicator so outdated installed PWA instances are obvious.
const label=document.createElement('span');label.className='lumii85-pill';label.textContent='NOVO · Leitor de planos v8.5';
const h=plan.querySelector('h3');h?.parentNode.insertBefore(label,h);
})();
