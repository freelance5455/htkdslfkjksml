(()=>{'use strict';
const $=id=>document.getElementById(id), KEY='dval-premium-v1', FIX='lumii-premium-fixed-v83', PAID='lumii-premium-fixed-paid-v83';
const money=n=>Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const read=(k,f)=>{try{return JSON.parse(localStorage.getItem(k))??f}catch{return f}};
const db=()=>{const d=read(KEY,{mov:[],div:[],metas:[]});return d&&typeof d==='object'?d:{mov:[],div:[],metas:[]}};
const fixed=()=>{const v=read(FIX,[]);return Array.isArray(v)?v:[]};
const paid=()=>{const v=read(PAID,{});return v&&typeof v==='object'&&!Array.isArray(v)?v:{}};
const save=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value));return true}catch{alert('Não foi possível salvar. Exporte um backup e confira o espaço disponível.');return false}};
const add=(parent,tag,txt,cls)=>{const e=document.createElement(tag);if(txt!==undefined)e.textContent=txt;if(cls)e.className=cls;parent.append(e);return e};
const dateYMD=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const monthYMD=(year,month,day)=>{const d=new Date(year,month-1,1),last=new Date(year,month,0).getDate();return dateYMD(new Date(year,month-1,Math.min(day,last)))};
const startMonth=new Date();const month0=`${startMonth.getFullYear()}-${String(startMonth.getMonth()+1).padStart(2,'0')}`;
function panel(id,title,subtitle){const e=document.createElement('div');e.className='v82-box v83-box';e.id=id;add(e,'h3',title);add(e,'p',subtitle);return e}
function field(root,label,type,id,opts={}){const wrap=add(root,'div',undefined,'v83-field');const l=add(wrap,'label',label);l.htmlFor=id;const input=add(wrap,'input');input.type=type;input.id=id;Object.assign(input,opts);return input}
function button(root,label,handler,cls=''){const b=add(root,'button',label,cls);b.type='button';b.addEventListener('click',handler);return b}
function note(root,message){root.replaceChildren();add(root,'p',message,'v83-note')}
function makeUI(){
 const home=$('inicio'),debts=$('dividas');if(!home||!debts)return;
 const anchor=$('v82Monthly');
 const dashboard=panel('v83Overview','🌿 Lumi observa seu mês','Orientações calculadas com seus lançamentos e vencimentos cadastrados; não são aconselhamento financeiro individual.');
 add(dashboard,'div',undefined,'v83-output').id='v83Advice';home.insertBefore(dashboard,anchor||home.firstChild);
 const report=panel('v83Reports','📊 Relatório de 6 meses','Compare receitas e despesas registradas. Contas previstas não são descontadas automaticamente.');
 const reportActions=add(report,'div',undefined,'v83-actions');button(reportActions,'Exportar relatório CSV',exportCSV);add(report,'div',undefined,'v83-output').id='v83Report';
 home.insertBefore(report,$('v82Safe')||null);
 const recurring=panel('v83Recurring','🔁 Contas fixas mensais','Cadastre uma vez; acompanhe as próximas ocorrências e marque como pagas. Marcar como paga NÃO cria um lançamento, evitando contagem dupla.');
 const grid=add(recurring,'div',undefined,'v83-grid');field(grid,'Descrição','text','v83FixedName',{maxLength:80,placeholder:'Ex.: internet'});field(grid,'Valor (R$)','number','v83FixedValue',{min:'0.01',step:'0.01'});field(grid,'Dia de vencimento (1 a 31)','number','v83FixedDay',{min:'1',max:'31',step:'1',value:'10'});field(grid,'Começa no mês','month','v83FixedStart',{value:month0});
 const actions=add(recurring,'div',undefined,'v83-actions');button(actions,'Adicionar conta fixa',addFixed,'v83-primary');
 const calendar=add(recurring,'div',undefined,'v83-calendar');const row=add(calendar,'div',undefined,'v83-actions');const lab=add(row,'label','Visualizar mês');lab.htmlFor='v83CalendarMonth';const mi=add(row,'input');mi.type='month';mi.id='v83CalendarMonth';mi.value=month0;mi.addEventListener('change',renderAll);add(calendar,'div',undefined,'v83-output').id='v83Calendar';
 add(recurring,'div',undefined,'v83-output').id='v83FixedList';home.insertBefore(recurring,$('v82Safe')||null);
 const simulator=panel('v83Simulator','🧮 Simulador de quitação','Planeje reservas mensais para alcançar o saldo de quitação informado hoje. Sem taxa contratual e tabela de amortização, não é possível prever o valor futuro exigido pelo banco.');
 const sg=add(simulator,'div',undefined,'v83-grid');const selectWrap=add(sg,'div',undefined,'v83-field');const label=add(selectWrap,'label','Empréstimo');label.htmlFor='v83Debt';const sel=add(selectWrap,'select');sel.id='v83Debt';
 field(sg,'Valor já guardado (R$)','number','v83Saved',{min:'0',step:'0.01',value:'0'});field(sg,'Reserva mensal (R$)','number','v83Monthly',{min:'0',step:'0.01',value:'200'});field(sg,'Extra em novembro (R$)','number','v83Nov',{min:'0',step:'0.01',value:'0'});field(sg,'Extra em dezembro (R$)','number','v83Dec',{min:'0',step:'0.01',value:'0'});field(sg,'Começar em','month','v83Begin',{value:month0});field(sg,'Simular até','month','v83End',{value:`${startMonth.getFullYear()+1}-${String(startMonth.getMonth()+1).padStart(2,'0')}`});
 const sa=add(simulator,'div',undefined,'v83-actions');button(sa,'Calcular plano de reserva',simulate,'v83-primary');add(simulator,'div',undefined,'v83-output').id='v83Simulation';
 debts.append(simulator);
 document.querySelectorAll('.tabs [data-tab]').forEach(b=>b.addEventListener('click',renderAll));
 window.addEventListener('storage',renderAll);
 const originalSet=Storage.prototype.setItem;let lock=false;Storage.prototype.setItem=function(k,v){const r=originalSet.call(this,k,v);if(this===localStorage&&!lock&&k===KEY){lock=true;try{renderAll()}finally{lock=false}}return r};
 renderAll();
}
function addFixed(){const name=$('v83FixedName').value.trim(),value=Number($('v83FixedValue').value),day=Number($('v83FixedDay').value),start=$('v83FixedStart').value;
 if(!name||!Number.isFinite(value)||value<=0||value>1e9||!Number.isInteger(day)||day<1||day>31||!/^[0-9]{4}-(0[1-9]|1[0-2])$/.test(start)){alert('Preencha nome, valor, dia e mês de início corretamente.');return}
 const arr=fixed();arr.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random(),name,value,day,start});if(save(FIX,arr)){$('v83FixedName').value='';$('v83FixedValue').value='';renderAll()}}
function eventsFor(month){const [y,m]=month.split('-').map(Number);const items=[];const state=paid();
 for(const f of fixed())if(f.start<=month){const date=monthYMD(y,m,f.day);items.push({id:f.id+'|'+month,name:f.name,value:f.value,date,type:'fixed',done:!!state[f.id+'|'+month]})}
 for(const d of (db().div||[]))if(d.vencimento&&/^\d{4}-\d{2}-\d{2}$/.test(d.vencimento)&&d.vencimento.slice(0,7)===month){items.push({id:d.id,name:d.nome,value:d.parcela||0,date:d.vencimento,type:'debt',done:false})}
 return items.sort((a,b)=>a.date.localeCompare(b.date))}
function renderCalendar(){const month=$('v83CalendarMonth').value,root=$('v83Calendar');root.replaceChildren();if(!/^\d{4}-\d{2}$/.test(month)){note(root,'Escolha um mês válido.');return}
 const events=eventsFor(month);if(!events.length){note(root,'Nenhum vencimento cadastrado para este mês.');return}
 const ul=add(root,'div',undefined,'v83-events');for(const e of events){const row=add(ul,'div',undefined,'v83-event');const detail=add(row,'div');add(detail,'strong',e.date.split('-').reverse().join('/')+' · '+e.name);add(detail,'small',(e.type==='fixed'?'Conta fixa':'Dívida (vencimento cadastrado)')+' · '+money(e.value));if(e.type==='fixed'){button(row,e.done?'✓ Pago':'Marcar pago',()=>{const st=paid();st[e.id]=!st[e.id];if(save(PAID,st))renderAll()},e.done?'v83-paid':'')}else add(row,'span','Previsto','v83-tag')}}
function renderFixed(){const root=$('v83FixedList');root.replaceChildren();const list=fixed();if(!list.length){note(root,'Você ainda não cadastrou contas fixas.');return}for(const f of list){const row=add(root,'div',undefined,'v83-event');const txt=add(row,'div');add(txt,'strong',f.name);add(txt,'small',money(f.value)+' · dia '+f.day+' · desde '+f.start);button(row,'Excluir',()=>{if(!confirm('Excluir esta conta fixa? O histórico de pagamentos dessa conta também será removido.'))return;const arr=fixed().filter(x=>x.id!==f.id);const states=paid();Object.keys(states).filter(k=>k.startsWith(f.id+'|')).forEach(k=>delete states[k]);if(save(FIX,arr)&&save(PAID,states))renderAll()},'v83-delete')}}
function monthlyData(){const all=(db().mov||[]),now=new Date();const rows=[];for(let i=5;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth()-i,1),month=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;let inc=0,exp=0;for(const x of all){if(String(x.data).slice(0,7)!==month)continue;const v=Number(x.valor);if(!Number.isFinite(v)||v<0)continue;if(x.tipo==='receita')inc+=v;else if(x.tipo==='despesa')exp+=v}rows.push({month,inc,exp,balance:inc-exp})}return rows}
function renderReport(){const root=$('v83Report');root.replaceChildren();const rows=monthlyData(),table=add(root,'table',undefined,'v83-table');const head=add(table,'thead');const tr=add(head,'tr');['Mês','Entradas','Saídas','Diferença'].forEach(h=>add(tr,'th',h));const body=add(table,'tbody');for(const r of rows){const row=add(body,'tr');[r.month,money(r.inc),money(r.exp),money(r.balance)].forEach(v=>add(row,'td',v))}}
function exportCSV(){const rows=monthlyData(),cells=[['Mês','Entradas (R$)','Saídas (R$)','Diferença (R$)'],...rows.map(x=>[x.month,x.inc.toFixed(2),x.exp.toFixed(2),x.balance.toFixed(2)])];const csv='\ufeff'+cells.map(r=>r.join(';')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='lumii-relatorio-6-meses.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function renderAdvice(){const root=$('v83Advice');root.replaceChildren();const rows=monthlyData(),thisMonth=rows.at(-1),data=db(),goals=data.metas||[];const suggestions=[];
 if(!data.mov?.length)suggestions.push('💚 Comece cadastrando uma receita ou despesa para receber orientações personalizadas.');
 else if(thisMonth.exp>thisMonth.inc)suggestions.push('⚠️ Neste mês, as despesas registradas superam as receitas em '+money(thisMonth.exp-thisMonth.inc)+'. Confira se os lançamentos estão completos.');
 else suggestions.push('🌱 Neste mês, a diferença entre entradas e saídas registradas é '+money(thisMonth.balance)+'. Esse valor não considera contas ainda não lançadas.');
 const month=$('v83CalendarMonth').value;const upcoming=eventsFor(month).filter(x=>!x.done);if(upcoming.length)suggestions.push('📅 Você tem '+upcoming.length+' vencimento(s) cadastrado(s) para '+month+'. Confira o calendário abaixo.');
 const almost=goals.filter(g=>g.alvo>0&&g.atual/g.alvo>=.8&&g.atual<g.alvo);if(almost.length)suggestions.push('🎯 '+almost.length+' meta(s) já alcançaram pelo menos 80% do objetivo.');
 for(const s of suggestions)add(root,'p',s,'v83-tip')}
function fillDebts(){const sel=$('v83Debt'),prev=sel.value;sel.replaceChildren();const option=document.createElement('option');option.value='';option.textContent='Selecione uma dívida';sel.append(option);for(const d of (db().div||[])){const o=document.createElement('option');o.value=d.id;o.textContent=d.nome+' · '+money(d.saldo);sel.append(o)}sel.value=prev}
function simulate(){const root=$('v83Simulation');root.replaceChildren();const debt=(db().div||[]).find(d=>d.id===$('v83Debt').value);if(!debt){note(root,'Selecione uma dívida cadastrada.');return}
 const vals=['v83Saved','v83Monthly','v83Nov','v83Dec'].map(id=>Number($(id).value||0));if(vals.some(v=>!Number.isFinite(v)||v<0||v>1e9)){note(root,'Confira os valores informados.');return}
 const [saved,monthly,nov,dec]=vals,start=$('v83Begin').value,end=$('v83End').value;
 if(!/^\d{4}-\d{2}$/.test(start)||!/^\d{4}-\d{2}$/.test(end)||start>end){note(root,'Confira o período de simulação.');return}
 const [sy,sm]=start.split('-').map(Number),[ey,em]=end.split('-').map(Number),n=(ey-sy)*12+em-sm+1;
 if(n>120||n<1){note(root,'Simule entre 1 e 120 meses.');return}
 const target=Number(debt.saldo),rows=[];let total=saved,hit=saved>=target?'Já atingiu o saldo atual':null;
 for(let i=0;i<n;i++){const d=new Date(sy,sm-1+i,1),m=d.getMonth()+1,y=d.getFullYear(),base=monthly,extra=m===11?nov:m===12?dec:0;total=Math.round((total+base+extra)*100)/100;const month=`${y}-${String(m).padStart(2,'0')}`;rows.push({month,base,extra,total});if(!hit&&total>=target)hit=month}
 add(root,'p','Saldo de quitação informado hoje: '+money(target)+' · Valor reservado ao final: '+money(total),'v83-summary');
 add(root,'p',hit?'Meta de reserva atingida: '+hit:'Ainda faltariam '+money(Math.max(0,target-total))+' para alcançar o saldo informado hoje.','v83-summary');
 add(root,'p','Atenção: esta é uma projeção do dinheiro reservado, NÃO do saldo futuro do empréstimo. Parcelas, juros e descontos podem alterar o valor real de quitação.','v83-warning');
 const table=add(root,'table',undefined,'v83-table'),thead=add(table,'thead'),tr=add(thead,'tr');['Mês','Reserva','Extra','Acumulado'].forEach(x=>add(tr,'th',x));const body=add(table,'tbody');for(const r of rows){const row=add(body,'tr');[r.month,money(r.base),money(r.extra),money(r.total)].forEach(x=>add(row,'td',x))}}
function renderAll(){if(!$('v83Calendar'))return;fillDebts();renderCalendar();renderFixed();renderReport();renderAdvice()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',makeUI);else makeUI();
})();
