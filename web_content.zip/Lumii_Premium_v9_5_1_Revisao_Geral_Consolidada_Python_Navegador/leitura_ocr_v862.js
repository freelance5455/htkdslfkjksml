(()=>{
'use strict';
const $=id=>document.getElementById(id);
const file=$('planImg84'),button=$('planRead84'),out=$('planText84'),status=$('planStatus84'),summary=$('simpleUseText86');
if(!file||!button||!out||!status)return;
let busy=false;
function say(t){status.textContent=t}
function loadOCR(){
 if(window.Tesseract?.createWorker)return Promise.resolve();
 return new Promise((resolve,reject)=>{
  const old=document.getElementById('lumii-ocr-v862');
  if(old){old.addEventListener('load',resolve,{once:true});old.addEventListener('error',()=>reject(Error('Não foi possível carregar o leitor. Verifique sua conexão.')),{once:true});return}
  const s=document.createElement('script');s.id='lumii-ocr-v862';
  s.src='https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
  s.onload=resolve;s.onerror=()=>{s.remove();reject(Error('Não foi possível carregar o leitor de imagens. Verifique a internet ou cole o texto manualmente.'))};
  document.head.append(s);
 });
}
button.addEventListener('click',async()=>{
 if(busy)return;
 const f=file.files?.[0];
 if(!f){say('⚠️ Primeiro selecione uma imagem PNG, JPG ou WebP.');return}
 if(!['image/png','image/jpeg','image/webp'].includes(f.type)||f.size>8_000_000){say('⚠️ Escolha PNG, JPG ou WebP com até 8 MB.');return}
 busy=true;button.disabled=true;button.textContent='Lendo imagem…';
 let worker=null;
 try{
  say('⏳ Carregando o leitor de imagens pela internet…');
  await loadOCR();
  if(!window.Tesseract?.createWorker)throw Error('O leitor não foi iniciado.');
  say('⏳ Reconhecendo texto em português. Imagens com muitas tabelas podem demorar…');
  worker=await window.Tesseract.createWorker('por',1,{
    logger:m=>{
     if(m.status==='recognizing text'&&Number.isFinite(m.progress))say('⏳ Lendo imagem: '+Math.round(m.progress*100)+'%');
    }
  });
  const result=await worker.recognize(f);
  const t=String(result?.data?.text||'').trim();
  if(!t)throw Error('Não encontrei texto legível. Tente uma imagem mais nítida ou cole o texto manualmente.');
  out.value=t;
  out.dispatchEvent(new Event('input',{bubbles:true}));
  say('✓ Texto lido! Agora revise a tabela de meses e valores abaixo.');
  if(summary){summary.click();say('✓ Texto lido. Conferindo a tabela da imagem…');}
  // A financial table often contains month, contribution and cumulative amount.
  // Read the month and contribution columns separately, to avoid confusing the latter.
  try{
   const img=await createImageBitmap(f);
   const w=img.width,h=img.height;
   // For a three-column table, first column is ~20% and the monthly contribution
   // is in the second column. Crop away the summary panels on the right.
   const crop=async(x0,x1)=>{
    const c=document.createElement('canvas');c.width=Math.round((x1-x0)*w*2);c.height=Math.round(h*0.66*2);
    const ctx=c.getContext('2d',{willReadFrequently:true});ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);
    ctx.drawImage(img,x0*w,h*0.18,(x1-x0)*w,h*0.66,0,0,c.width,c.height);
    const r=await worker.recognize(c);
    return String(r?.data?.text||'');
   };
   say('⏳ Separando a coluna dos meses e a coluna dos aportes…');
   const left=await crop(0.015,0.20);
   const middle=await crop(0.205,0.425);
   const monthNames=['janeiro','fevereiro','marco','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
   const norm=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
   const monthRe=/\b(janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s*[/\- ]\s*(20\d\d)\b/g;
   const ms=[...norm(left).matchAll(monthRe)].map(m=>({month:`${m[2]}-${String(monthNames.indexOf(m[1])+1).padStart(2,'0')}`,amount:null,source:'coluna da tabela'}));
   const vals=[...middle.matchAll(/(?:R\$\s*)?(\d{1,3}(?:\.\d{3})*,\d{2}|\d+,\d{2})/g)].map(m=>Number(m[1].replace(/\./g,'').replace(',','.')));
   if(ms.length>=2&&ms.length===vals.length&&new Set(ms.map(x=>x.month)).size===ms.length){
    ms.forEach((r,i)=>r.amount=vals[i]);
    window.lumiiApplyMonthRows?.(ms);
    say(`✓ ${ms.length} meses associados aos respectivos aportes. Confira e salve.`);
   }else{
    say(`⚠️ Meses identificados: ${ms.length}; valores da coluna: ${vals.length}. Mantive a revisão sem adivinhar valores. Você pode preencher manualmente.`);
   }
   img.close?.();
  }catch(err){say('✓ Texto lido. A separação automática de colunas não foi possível; revise os valores manualmente.');}

 }catch(e){say('❌ '+(e?.message||String(e))+' Você também pode colar o texto e clicar em “Resumir meses do texto lido”.')}
 finally{try{await worker?.terminate()}catch{}busy=false;button.disabled=false;button.textContent='Ler imagem do plano'}
});
})();