/* Núcleo de leitura somente-leitura: não altera os dados existentes. */
(function(){'use strict';
 const KEY='dval-premium-v1';
 function read(){try{const d=JSON.parse(localStorage.getItem(KEY)||'{}');return {mov:Array.isArray(d.mov)?d.mov:[],div:Array.isArray(d.div)?d.div:[],metas:Array.isArray(d.metas)?d.metas:[]}}catch{return {mov:[],div:[],metas:[]}}}
 function amount(v){const n=Number(v);return Number.isFinite(n)&&n>=0?n:0}
 function month(s){return typeof s==='string'&&/^\d{4}-(0[1-9]|1[0-2])(-|$)/.test(s)?s.slice(0,7):null}
 function summarize(mov,months){const result=months.map(ym=>({ym,receitas:0,despesas:0,quantidade:0}));const map=new Map(result.map(r=>[r.ym,r]));for(const m of mov){if(!m||!map.has(month(m.data)))continue;const r=map.get(month(m.data));if(m.tipo==='receita'){r.receitas+=amount(m.valor);r.quantidade++}else if(m.tipo==='despesa'){r.despesas+=amount(m.valor);r.quantidade++}}return result.map(r=>({...r,saldo:r.receitas-r.despesas}))}
 function categories(mov,ym){const totals=new Map();for(const m of mov){if(!m||m.tipo!=='despesa'||month(m.data)!==ym)continue;const name=String(m.categoria||'Sem categoria').trim()||'Sem categoria';totals.set(name,(totals.get(name)||0)+amount(m.valor))}return [...totals].sort((a,b)=>b[1]-a[1])}
 window.LumiiFinanceCore949=Object.freeze({read,amount,month,summarize,categories});
})();
