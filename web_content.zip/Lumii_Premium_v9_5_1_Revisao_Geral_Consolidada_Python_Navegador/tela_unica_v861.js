(()=>{'use strict';
const $=id=>document.getElementById(id);
const image=$('impImageArea'),slot=$('lumii85ImageSlot'),simple=$('simpleMonths86'),old=$('imgPlanImport');
if(!image||!slot||!simple||!old)return;
// The months-only tool must live on the IMAGE tab, not the hidden Excel/loan tab.
slot.insertBefore(simple,old);
const v=old.querySelector('small');if(v&&/v8\.4\.1/.test(v.textContent))v.remove();
const oldTag=old.querySelector('.lumii85-pill');if(oldTag)oldTag.textContent='LEITURA DE IMAGEM · v8.6.1';
const oldHead=old.querySelector('h3');if(oldHead)oldHead.textContent='📷 Primeiro, leia a imagem';
const text=$('planText84');if(text){text.placeholder='O texto reconhecido aparecerá aqui. Depois clique em “Resumir meses do texto lido”.';}
const analyze=$('planAnalyze84');if(analyze)analyze.hidden=true;
const ex=$('planExample84');if(ex)ex.hidden=true;
const preview=$('planPreview84');if(preview)preview.hidden=true;
const oldBtn=$('sendPlan841');if(oldBtn){oldBtn.textContent='📅 Revisar somente meses e valores';oldBtn.addEventListener('click',()=>{setTimeout(()=>{$('simpleUseText86')?.click();simple.scrollIntoView({block:'start',behavior:'smooth'})},80)})}
// Text can be manually pasted into the OCR area, then summarized with a single action.
const imgBtn=$('planRead84');if(imgBtn){imgBtn.addEventListener('click',()=>{
 const before=text?.value||'';let tries=0;
 const poll=setInterval(()=>{tries++;const now=text?.value||'';
 if(now.trim()&&now!==before){clearInterval(poll);$('simpleUseText86')?.click();$('simpleStatus86').textContent+=' · Revise os meses e valores antes de salvar.'}
 if(tries>=50)clearInterval(poll);
 },250);
 });}
const notice=document.createElement('p');notice.className='imp-status';notice.textContent='✓ Importação simplificada v8.6.1: a tabela de revisão antiga foi substituída pelo modo “somente meses e valores”.';simple.prepend(notice);
})();