(()=>{'use strict';
const $=id=>document.getElementById(id);
const isPlan=t=>/quita[cç][aã]o|parcelas restantes|aporte mensal|total guardado|banco do brasil|meta de quita/i.test(t||'');
const old=$('textoPremium'),newText=$('planText84'),debt=$('impDebtChoice'),analyze=$('planAnalyze84');
if(!old||!newText||!debt||!analyze)return;
function route(t){debt.click();newText.value=t;analyze.click();$('imgPlanImport').scrollIntoView({behavior:'smooth',block:'start'});}
// Users already reading OCR in the legacy panel can reuse the text directly.
const more=old.closest('.imp-more-inner');
if(more){const b=document.createElement('button');b.type='button';b.id='sendPlan841';b.textContent='📊 Interpretar como plano de quitação';b.style.cssText='background:#176547;color:white;font-weight:700;';b.addEventListener('click',()=>{if(!old.value.trim()){alert('Primeiro clique em Ler imagem ou cole o texto do planejamento.');return}route(old.value)});more.append(b);
const tip=document.createElement('p');tip.className='imp-help';tip.textContent='Esta área é para gastos individuais. Se a imagem for uma tabela de empréstimo, use “Interpretar como plano de quitação” após a leitura.';more.insertBefore(tip,more.firstChild);
}
// Catch plan OCR pasted into the old expense text analyzer and send to the correct interpreter.
const btn=$('interpretarTexto');if(btn)btn.addEventListener('click',e=>{if(isPlan(old.value)){e.stopImmediatePropagation();e.preventDefault();route(old.value)}},true);
// Prominent navigation so a user does not need to locate a hidden second importer.
const imp=$('impDebtArea');if(imp){const banner=document.createElement('p');banner.className='imp-status';banner.style.cssText='border:1px solid #98c9ad;background:#e7f5eb;font-weight:700;';banner.textContent='📷 Planejamento em imagem? Use o leitor logo abaixo. Para gastos simples, escolha Movimentações.';imp.prepend(banner)}
// Mark which version is actually loaded to make stale Python server sessions obvious.
const version=document.createElement('small');version.textContent='Leitor de planos v8.4.1';version.style.cssText='display:block;text-align:center;color:#688075;margin:8px';$('imgPlanImport')?.append(version);
})();
