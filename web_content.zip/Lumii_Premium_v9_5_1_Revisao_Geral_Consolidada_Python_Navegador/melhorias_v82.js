
(() => {
"use strict";
const by=id=>document.getElementById(id);
const dataKey='dval-premium-v1';
const backupKeys=[
'dval-premium-v1','dval-premium-cronogramas-v1',
'dval-premium-real-reserves-v1','dval-premium-aprender-v1'
];
const getKeys=()=>Object.keys(localStorage).filter(k=> k.startsWith('dval-premium') || k.startsWith('lumii-'));
const safeJSON=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key)||'null')??fallback}catch{return fallback}};
const money=n=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(n);
const validNumber=n=>typeof n==='number'&&Number.isFinite(n)&&n>=0;
const validData=d=>d&&typeof d==='object'&&!Array.isArray(d)&&
 ['mov','div','metas'].every(k=>Array.isArray(d[k])&&d[k].length<=100000)&&
 d.mov.every(x=>x&&typeof x==='object'&&typeof x.id==='string'&&typeof x.tipo==='string'&&typeof x.nome==='string'&&Number.isFinite(Number(x.valor))&&Number(x.valor)>=0)&&
 d.div.every(x=>x&&typeof x==='object'&&typeof x.id==='string'&&typeof x.nome==='string'&&Number.isFinite(Number(x.saldo))&&Number(x.saldo)>=0)&&
 d.metas.every(x=>x&&typeof x==='object'&&typeof x.id==='string'&&typeof x.nome==='string'&&Number.isFinite(Number(x.alvo))&&Number(x.alvo)>=0);
function download(filename,obj){
 const blob=new Blob([JSON.stringify(obj,null,2)],{type:'application/json'});
 const url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function snapshot(){
 const keys={};
 getKeys().forEach(k=>{keys[k]=localStorage.getItem(k)});
 return {format:'lumii-full-backup-v82',exportedAt:new Date().toISOString(),keys};
}
function renderMonth(){
 const month=by('v82Month').value,db=safeJSON(dataKey,{mov:[]});
 let income=0,expense=0,count=0;
 (Array.isArray(db.mov)?db.mov:[]).forEach(m=>{
   if(String(m.data||'').slice(0,7)!==month)return;
   const v=Number(m.valor);
   if(!Number.isFinite(v)||v<0)return;
   if(m.tipo==='receita')income+=v;
   else if(m.tipo==='despesa')expense+=v;
   count++;
 });
 by('v82Income').textContent=money(income);
 by('v82Expense').textContent=money(expense);
 by('v82Balance').textContent=money(income-expense);
 by('v82MonthlyInfo').textContent=count+' lançamento(s) neste mês.';
}
function renderDue(){
 const d=safeJSON(dataKey,{div:[]}),root=by('v82DueList');
 root.replaceChildren();
 const debts=(Array.isArray(d.div)?d.div:[]).filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x.vencimento||''))
 .sort((a,b)=>a.vencimento.localeCompare(b.vencimento)).slice(0,6);
 if(!debts.length){root.textContent='Nenhuma data de vencimento cadastrada. Adicione uma na aba Dívidas.';return}
 const list=document.createElement('ul');list.className='v82-warnings';
 for(const x of debts){
  const li=document.createElement('li');
  const [y,m,day]=x.vencimento.split('-');
  li.textContent=`${day}/${m}/${y} — ${x.nome}${Number(x.parcela)>0?' · parcela '+money(Number(x.parcela)):''}`;
  list.append(li);
 }root.append(list);
}
function check(){
 const d=safeJSON(dataKey,null),out=by('v82Report');out.replaceChildren();
 if(!validData(d)){out.textContent='Atenção: estrutura de dados incompleta ou inválida. Exporte um backup e não substitua os registros antes de conferir.';return}
 const warnings=[];
 const ids=new Set();
 for(const category of ['mov','div','metas']){
  for(const item of d[category]){
   const id=category+':'+item.id;
   if(ids.has(id))warnings.push('Identificador repetido em '+category+': '+item.id);
   ids.add(id);
  }
 }
 const signatures=new Map();
 for(const m of d.mov){
  const sig=[m.tipo,String(m.nome).trim().toLowerCase(),m.data,Number(m.valor).toFixed(2)].join('|');
  signatures.set(sig,(signatures.get(sig)||0)+1);
 }
 const potential=[...signatures.values()].filter(n=>n>1).reduce((s,n)=>s+n-1,0);
 if(potential)warnings.push(potential+' lançamento(s) possivelmente duplicado(s). Confira antes de excluir; pagamentos iguais podem ser legítimos.');
 const orphan=safeJSON('dval-premium-cronogramas-v1',{});
 if(orphan&&typeof orphan==='object'&&!Array.isArray(orphan)){
  const validIds=new Set(d.div.map(x=>x.id));
  const count=Object.keys(orphan).filter(id=>!validIds.has(id)).length;
  if(count)warnings.push(count+' cronograma(s) de dívidas não encontradas. Não foram apagados.');
 }
 const p=document.createElement('p');
 p.textContent=`Registros: ${d.mov.length} lançamentos, ${d.div.length} dívidas e ${d.metas.length} metas.`;
 out.append(p);
 if(!warnings.length){const ok=document.createElement('p');ok.textContent='✓ Nenhum problema simples detectado. Esta conferência não substitui uma auditoria financeira.';out.append(ok)}
 else {const ul=document.createElement('ul');ul.className='v82-warnings';warnings.forEach(w=>{const li=document.createElement('li');li.textContent=w;ul.append(li)});out.append(ul)}
}
function restore(file){
 if(!file)return;
 if(file.size>8_000_000){alert('Arquivo maior que 8 MB.');return}
 file.text().then(raw=>{
  const b=JSON.parse(raw);
  if(!b||b.format!=='lumii-full-backup-v82'||!b.keys||typeof b.keys!=='object'||Array.isArray(b.keys))throw Error('Este não é um backup completo da v8.2.');
  if(!Object.prototype.hasOwnProperty.call(b.keys,dataKey))throw Error('Backup sem registros financeiros.');
  const d=JSON.parse(b.keys[dataKey]);
  if(!validData(d))throw Error('Registros financeiros inválidos.');
  const entries=Object.entries(b.keys);
  if(entries.length>80||entries.some(([k,v])=>!(/^(dval-premium|lumii-)[a-zA-Z0-9_.-]+$/.test(k))||typeof v!=='string'||v.length>5_000_000))throw Error('Backup contém entradas não permitidas.');
  for(const [k,v] of entries){if(k!==dataKey&&k.includes('cronogramas')){const obj=JSON.parse(v);if(!obj||typeof obj!=='object'||Array.isArray(obj))throw Error('Cronogramas inválidos.')}}
  if(!confirm('Restaurar '+d.mov.length+' lançamentos, '+d.div.length+' dívidas e '+d.metas.length+' metas? Os dados atuais serão substituídos.'))return;
  const before=snapshot();
  download('lumii-ANTES-da-restauracao-'+new Date().toISOString().slice(0,10)+'.json',before);
  try{
   const previous=before.keys;
   for(const [k,v] of entries)localStorage.setItem(k,v);
   for(const k of Object.keys(previous)){if(!Object.prototype.hasOwnProperty.call(b.keys,k))localStorage.removeItem(k)}
  }catch(err){
   // rollback storage to the previous exact values if quota is exceeded
   for(const [k] of entries){if(!Object.prototype.hasOwnProperty.call(before.keys,k))try{localStorage.removeItem(k)}catch{}}
   for(const [k,v] of Object.entries(before.keys)){try{localStorage.setItem(k,v)}catch{}}
   throw Error('Não foi possível salvar tudo. A cópia anterior foi preservada para recuperação.');
  }
  alert('Backup restaurado. A página será atualizada.');
  location.reload();
 }).catch(e=>alert('Não foi possível restaurar: '+e.message));
}
const month=by('v82Month');if(!month)return;
const now=new Date();month.value=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
month.addEventListener('change',renderMonth);
by('v82Export').addEventListener('click',()=>{
 try{download('lumii-backup-completo-'+new Date().toISOString().slice(0,10)+'.json',snapshot());by('v82Status').textContent='Backup gerado. Guarde o arquivo em local privado.'}
 catch(e){by('v82Status').textContent='Falha ao criar backup: '+e.message}
});
by('v82Check').addEventListener('click',check);
by('v82Import').addEventListener('change',e=>{const f=e.target.files?.[0];restore(f);e.target.value=''});
renderMonth();renderDue();
window.addEventListener('storage',()=>{renderMonth();renderDue()});
// Refresh summaries after any save without modifying the app's original functions.
const oldSet=Storage.prototype.setItem;
let refreshing=false;
Storage.prototype.setItem=function(k,v){
 const result=oldSet.call(this,k,v);
 if(this===localStorage&&!refreshing&&k===dataKey){
  refreshing=true;
  try{renderMonth();renderDue()}finally{refreshing=false}
 }
 return result;
};
})();
