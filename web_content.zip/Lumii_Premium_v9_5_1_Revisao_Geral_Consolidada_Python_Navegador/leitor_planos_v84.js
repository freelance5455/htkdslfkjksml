(()=>{'use strict';
const $=id=>document.getElementById(id), fmt=n=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(n);
const status=s=>$('planStatus84').textContent=s;
const months=['janeiro','fevereiro','marco','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
const clean=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const parseBR=s=>{let v=String(s||'').replace(/[^\d.,]/g,'');if(!v)return NaN;if(v.includes(','))v=v.replace(/\./g,'').replace(',','.');else if(/^\d{1,3}(\.\d{3})+$/.test(v))v=v.replace(/\./g,'');return Number(v)};
const amounts=s=>[...String(s).matchAll(/(?:R\$\s*)?(\d{1,3}(?:\.\d{3})*,\d{2}|\d+,\d{2})/g)].map(m=>parseBR(m[1]));
const findMoney=(text,regex)=>{const m=text.match(regex);if(!m)return NaN;const n=amounts(m[0]);return n.length?n[0]:NaN};
function parse(text){const lines=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean),all=clean(text);
 let name=/banco\s+do\s+brasil/i.test(text)?'Banco do Brasil':(/meutudo/i.test(text)?'MEUTUDO':(/creditas/i.test(text)?'Creditas':'Empréstimo importado'));
 const saldo=findMoney(text,/(?:saldo\s+atual(?:\s+para\s+quita[cç][aã]o)?|saldo\s+para\s+quita[cç][aã]o)[\s\S]{0,110}/i);
 const parcela=findMoney(text,/(?:parcela\s+mensal|parcela\s+do\s+m[eê]s)[\s\S]{0,75}/i);
 const restantesMatch=text.match(/parcelas\s+restantes[^\n\d]{0,30}(\d{1,4})/i);const restantes=restantesMatch?Number(restantesMatch[1]):0;
 const estimated=findMoney(text,/(?:valor\s+estimado\s+para\s+quita[cç][aã]o\s+em\s+dezembro|quita[cç][aã]o\s+estimada\s+em\s+dezembro)[^\n]{0,100}/i);
 const rows=[];let year=null;const yr=(text.match(/(?:meta\s+de\s+quita[cç][aã]o|dezembro\s+de)\s*[^\n]{0,30}?(20\d\d)/i)||[])[1];if(yr)year=Number(yr);
 for(const line of lines){const normalized=clean(line);const mm=normalized.match(/\b(janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s*(?:\/|de\s+)?\s*(20\d{2})?\b/);if(!mm)continue;
  const idx=months.indexOf(mm[1]);const y=Number(mm[2]||year);if(idx<0||!y)continue;
  const vals=amounts(line);if(!vals.length)continue;
  // A table row includes: payoff estimate, mandatory installment, monthly contribution, extra, 13th, monthly total, accumulated, remaining.
  // Prefer the explicitly labelled total in simplified text; for a full table use the third-from-last monetary value.
  let amount=vals.length>=6?vals[vals.length-3]:vals.length===1?vals[0]:vals.length===2?vals[1]:NaN;
  if(!Number.isFinite(amount)||amount<0||amount>1e9)continue;
  const month=`${y}-${String(idx+1).padStart(2,'0')}`;
  if(!rows.some(r=>r.month===month))rows.push({month,amount});
 }
 rows.sort((a,b)=>a.month.localeCompare(b.month));
 return {name,saldo,parcela,restantes,estimated,rows:rows.slice(0,120)};
}
let current=null;
const field=(label,key,value,type='text')=>{const wrapper=document.createElement('div'),lab=document.createElement('label'),inp=document.createElement('input');lab.textContent=label;inp.type=type;inp.value=value;inp.dataset.field=key;if(type==='number'){inp.min='0';inp.step=key==='restantes'?'1':'0.01'}wrapper.append(lab,inp);return wrapper};
function preview(data){current=data;const root=$('planPreview84');root.replaceChildren();root.hidden=false;
 const h=document.createElement('h3');h.textContent='Confira o plano antes de salvar';root.append(h);
 const warning=document.createElement('p');warning.className='imp-help';warning.textContent='Os valores podem ter sido reconhecidos incorretamente. Preencha ou corrija todos os campos. O dinheiro informado é PLANEJADO, não guardado nem pago.';root.append(warning);
 const grid=document.createElement('div');grid.className='plan-grid';
 for(const [label,key,value,type] of [['Banco / dívida','name',data.name,'text'],['Saldo de quitação informado hoje (R$)','saldo',Number.isFinite(data.saldo)?data.saldo:'','number'],['Parcela mensal (R$)','parcela',Number.isFinite(data.parcela)?data.parcela:'','number'],['Parcelas restantes','restantes',data.restantes||'','number'],['Quitação futura estimada na imagem (R$) — apenas referência','estimated',Number.isFinite(data.estimated)?data.estimated:'','number']])grid.append(field(label,key,value,type));root.append(grid);
 const heading=document.createElement('h4');heading.textContent='Reservas mensais planejadas';root.append(heading);
 const table=document.createElement('div');table.id='planRows84';root.append(table);
 function draw(){table.replaceChildren();for(const [i,row] of data.rows.entries()){const r=document.createElement('div');r.className='plan-grid';const a=field('Mês','month',row.month,'month'),b=field('Aporte previsto (R$)','amount',row.amount,'number');a.querySelector('input').oninput=e=>row.month=e.target.value;b.querySelector('input').oninput=e=>row.amount=Number(e.target.value);const del=document.createElement('button');del.type='button';del.textContent='Excluir mês';del.onclick=()=>{data.rows.splice(i,1);draw()};r.append(a,b,del);table.append(r)}}draw();
 const add=document.createElement('button');add.type='button';add.textContent='+ Adicionar mês';add.onclick=()=>{data.rows.push({month:'2027-12',amount:0});draw()};root.append(add);
 const btn=document.createElement('button');btn.type='button';btn.className='primary';btn.textContent='Salvar dívida e cronograma';btn.style.marginLeft='10px';btn.onclick=save;root.append(btn);
 status(`Prévia pronta: ${data.rows.length} mês(es) identificados. Confira todos os campos antes de salvar.`);
}
function save(){const root=$('planPreview84'),get=k=>root.querySelector(`[data-field="${k}"]`)?.value||'';
 const name=get('name').trim().slice(0,80),saldo=Number(get('saldo')),parcela=Number(get('parcela')),restantes=Number(get('restantes'));
 if(!name||!get('saldo')||!Number.isFinite(saldo)||saldo<=0||saldo>1e9||!Number.isFinite(parcela)||parcela<0||!Number.isInteger(restantes)||restantes<0||restantes>1200){status('Confira banco, saldo, parcela e parcelas restantes.');return}
 const rows=current.rows.slice().sort((a,b)=>a.month.localeCompare(b.month));if(!rows.length||rows.length>120||rows.some(r=>!/^20\d\d-(0[1-9]|1[0-2])$/.test(r.month)||!Number.isFinite(r.amount)||r.amount<0||r.amount>1e9)||new Set(rows.map(r=>r.month)).size!==rows.length){status('Confira os meses: não podem estar repetidos e todos precisam de um aporte válido.');return}
 for(let i=1;i<rows.length;i++){const prev=Number(rows[i-1].month.slice(0,4))*12+Number(rows[i-1].month.slice(5)),next=Number(rows[i].month.slice(0,4))*12+Number(rows[i].month.slice(5));if(next-prev!==1){status('O cronograma precisa ter meses consecutivos. Adicione os meses faltantes.');return}}
 const dataKey='dval-premium-v1',planKey='dval-premium-cronogramas-v1';let db,plans;try{db=JSON.parse(localStorage.getItem(dataKey)||'{"mov":[],"div":[],"metas":[]}');plans=JSON.parse(localStorage.getItem(planKey)||'{}')}catch{status('Não foi possível ler seus dados. Faça backup antes de tentar novamente.');return}
 if(!db||!Array.isArray(db.div)||!Array.isArray(db.mov)||!Array.isArray(db.metas)||!plans||typeof plans!=='object'||Array.isArray(plans)){status('Os dados existentes não estão no formato esperado. Nada foi alterado.');return}
 const similar=db.div.find(d=>clean(d.nome)===clean(name)&&Math.abs(d.saldo-saldo)<0.01);if(similar){status('Já existe uma dívida com esse nome e saldo. Confira antes de duplicar.');return}
 if(!confirm(`Cadastrar ${name}, saldo ${fmt(saldo)}, e ${rows.length} meses de reservas PLANEJADAS? Não serão registrados pagamentos nem valores já guardados.`))return;
 const id=crypto?.randomUUID?.()||String(Date.now())+Math.random(),debt={id,nome:name,saldo,parcela,restantes};
 const monthIndex=m=>Number(m.slice(0,4))*12+Number(m.slice(5))-1;
 const plan={debtId:id,initial:0,rows:rows.map(r=>({month:monthIndex(r.month),base:Math.round(r.amount*100)/100,extra:0}))};
 const previousDb=localStorage.getItem(dataKey),previousPlans=localStorage.getItem(planKey);
 try{db.div.push(debt);plans[id]=plan;localStorage.setItem(dataKey,JSON.stringify(db));localStorage.setItem(planKey,JSON.stringify(plans))}catch(err){try{if(previousDb===null)localStorage.removeItem(dataKey);else localStorage.setItem(dataKey,previousDb);if(previousPlans===null)localStorage.removeItem(planKey);else localStorage.setItem(planKey,previousPlans)}catch{}status('Falha ao salvar. Os dados anteriores foram preservados quando possível.');return}
 status('Plano salvo! A dívida e os aportes PLANEJADOS foram cadastrados. Recarregando…');alert('Dívida e cronograma salvos. A previsão de quitação da imagem NÃO foi tratada como saldo confirmado.');location.reload();
}
$('planAnalyze84').onclick=()=>{const t=$('planText84').value;if(t.trim().length<15){status('Cole o texto do plano ou use Ler imagem.');return}preview(parse(t))};
$('planExample84').onclick=()=>{$('planText84').value='Banco do Brasil\nSaldo atual para quitação R$ 3.593,49\nParcela mensal R$ 167,28\nParcelas restantes 48\nSetembro/2027 R$ 820,00\nOutubro/2027 R$ 220,00\nNovembro/2027 R$ 1.320,00\nDezembro/2027 R$ 710,00';preview(parse($('planText84').value))};
$('planRead84').onclick=async()=>{const file=$('planImg84').files?.[0];if(!file){status('Selecione a imagem primeiro.');return}if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>8_000_000){status('Escolha uma imagem PNG, JPG ou WebP com até 8 MB.');return}
 const btn=$('planRead84');btn.disabled=true;status('Carregando leitor de imagens. Aguarde…');let worker;
 try{if(!window.Tesseract){const script=document.createElement('script');script.src='https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';await new Promise((resolve,reject)=>{script.onload=resolve;script.onerror=reject;document.head.append(script)})}
 worker=await Tesseract.createWorker('por');status('Reconhecendo o texto no seu navegador…');const result=await worker.recognize(file);$('planText84').value=result.data.text||'';preview(parse(result.data.text||''));if(!Number.isFinite(current.saldo)||!current.rows.length)status('Texto extraído, mas nem todos os valores foram identificados. Corrija o texto e a prévia manualmente.');
 }catch(err){status('O leitor automático não carregou ou não conseguiu ler a imagem. Você pode colar o texto manualmente e clicar em Analisar planejamento.')}finally{if(worker)try{await worker.terminate()}catch{}btn.disabled=false}
};
window.LumiiPlanImageParser={parse};
})();