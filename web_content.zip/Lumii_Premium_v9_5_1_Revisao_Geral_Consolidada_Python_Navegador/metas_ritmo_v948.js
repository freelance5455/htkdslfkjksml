(()=>{'use strict';
const P='lumii-meses-planejados-v86',R='lumii-aportes-reais-v902';
const read=k=>{try{const x=JSON.parse(localStorage.getItem(k)||'[]');return Array.isArray(x)?x:[]}catch{return []}};
const brl=n=>n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const dateOK=s=>/^\d{4}-\d{2}-\d{2}$/.test(s)&&!Number.isNaN(Date.parse(s+'T12:00:00'));
const monthOK=s=>/^20\d{2}-(0[1-9]|1[0-2])$/.test(s);
const create=(tag,cls,txt)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(txt!==undefined)e.textContent=txt;return e};
function render(){const host=document.getElementById('v948GoalInsights');if(!host)return;host.replaceChildren();
 const plans=read(P).filter(p=>p&&typeof p.id==='string'&&Array.isArray(p.rows));
 const real=read(R).filter(x=>x&&typeof x.planId==='string'&&dateOK(x.date)&&Number.isFinite(Number(x.amount))&&Number(x.amount)>0);
 host.append(create('h3','','📈 Ritmo das suas metas'));
 host.append(create('p','v948-note','Estimativas baseadas somente em aportes realmente registrados. Valores planejados não são considerados dinheiro guardado.'));
 if(!plans.length){host.append(create('p','v948-note','Importe um planejamento para acompanhar o ritmo de cada objetivo.'));return;}
 for(const p of plans){const rows=p.rows.filter(x=>x&&monthOK(x.month)&&Number.isFinite(Number(x.amount))&&Number(x.amount)>=0);
 const goal=rows.reduce((a,x)=>a+Number(x.amount),0), deposits=real.filter(x=>x.planId===p.id), saved=deposits.reduce((a,x)=>a+Number(x.amount),0),remaining=Math.max(0,goal-saved);
 const card=create('article','v948-card');card.append(create('h4','',String(p.name||'Planejamento')));
 const stats=create('p','v948-stat',`${brl(saved)} guardados de ${brl(goal)} planejados · Restam ${brl(remaining)}`);card.append(stats);
 if(goal===0){card.append(create('p','v948-note','Cadastre valores previstos para calcular o progresso.'));host.append(card);continue;}
 const bar=create('div','v948-track'),fill=create('div','v948-fill');fill.style.width=Math.min(100,saved/goal*100).toFixed(1)+'%';bar.append(fill);bar.setAttribute('role','progressbar');bar.setAttribute('aria-valuenow',String(Math.round(Math.min(100,saved/goal*100))));bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax','100');card.append(bar);
 if(remaining<=0){card.append(create('p','v948-good','🎉 Valor planejado alcançado pelos aportes registrados!'));host.append(card);continue;}
 const valid=deposits.filter(x=>Number(x.amount)>0);const monthTotals={};for(const d of valid){const k=d.date.slice(0,7);monthTotals[k]=(monthTotals[k]||0)+Number(d.amount)}
 const monthKeys=Object.keys(monthTotals).sort();
 if(!monthKeys.length){card.append(create('p','v948-note','Registre seu primeiro aporte real para começar a acompanhar o ritmo.'));host.append(card);continue;}
 const last3=monthKeys.slice(-3),avg=last3.reduce((s,k)=>s+monthTotals[k],0)/last3.length;
 if(!(avg>0)){card.append(create('p','v948-note','Ainda não há dados suficientes para estimar o ritmo.'));host.append(card);continue;}
 const months=Math.ceil(remaining/avg);
 card.append(create('p','v948-stat',`Média dos últimos ${last3.length} mês(es) com aportes: ${brl(avg)}/mês.`));
 card.append(create('p','v948-note',`Se mantiver essa média, faltariam aproximadamente ${months} mês(es) de aportes. Não é uma previsão garantida: meses sem depósitos não entram na média.`));
 const lastPlan=rows.map(x=>x.month).sort().at(-1);if(lastPlan){const [y,m]=lastPlan.split('-').map(Number);const today=new Date(),target=new Date(y,m,0);const diff=(y-today.getFullYear())*12+m-(today.getMonth()+1)+1;
 if(diff>0){card.append(create('p','v948-note',`Para cobrir o valor restante até ${m.toString().padStart(2,'0')}/${y}, seria necessário guardar cerca de ${brl(remaining/diff)} por mês, incluindo o mês atual.`));}}
 host.append(card);
 }
}
function init(){const goal=document.getElementById('v901Goals');if(!goal)return;let host=document.getElementById('v948GoalInsights');if(!host){host=create('section','v948-panel');host.id='v948GoalInsights';goal.insertAdjacentElement('afterend',host)}render();document.addEventListener('click',()=>setTimeout(()=>{if(!document.getElementById('metas')?.classList.contains('hidden'))render()},120));window.addEventListener('storage',e=>{if(e.key===P||e.key===R)render()});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();