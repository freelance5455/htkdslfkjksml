(()=>{
'use strict';
const $=id=>document.getElementById(id);
const text=$('planText84'), old=$('textoPremium'),status=$('simpleStatus86'),editor=$('simpleEditor86'),saved=$('simpleSaved86');
if(!text||!editor)return;
window.lumiiApplyMonthRows=(incoming)=>{rows=incoming.map(r=>({...r}));warnings=[];render();status.textContent=`✓ ${rows.length} meses e ${rows.filter(r=>r.amount!==null).length} valores associados pelas colunas da imagem. Confira antes de salvar.`;editor.scrollIntoView({block:'nearest',behavior:'smooth'});};
const KEY='lumii-meses-planejados-v86', months=['janeiro','fevereiro','marco','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const br=n=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(n);
const parseMoney=s=>{const v=String(s).replace(/[^\d,.-]/g,'');return Number(v.includes(',')?v.replace(/\./g,'').replace(',','.'):v)};
const matches=s=>[...String(s).matchAll(/(?:R\$\s*)?(\d{1,3}(?:\.\d{3})*,\d{2}|\d+,\d{2})/g)].map(x=>parseMoney(x[1])).filter(Number.isFinite);
let rows=[],warnings=[];
function extract(t){
 const lines=t.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 const yearMatch=norm(t).match(/\b(?:janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s*\/?\s*(20\d\d)/);
 const defaultYear=Number(yearMatch?.[1]||t.match(/\b20\d\d\b/)?.[0]||new Date().getFullYear());
 const found=new Map(),warn=[];
 const monthPattern=/\b(janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\b(?:\s*(?:\/|de|-)\s*(20\d\d))?/;
 const isBadContext=s=>/saldo|quitacao|parcela|juros|acumulad|total\s+geral|total\s+guardado|restante|divida|emprestimo/i.test(norm(s));
 const isAporte=s=>/aporte|guardar|guardado\s+no\s+mes|reservar|economizar|poupanca|separar|valor\s+mensal|valor\s+a\s+guardar/i.test(norm(s));
 const candidates=[];
 for(let i=0;i<lines.length;i++){
  const line=lines[i],m=norm(line).match(monthPattern);
  if(!m)continue;
  const idx=months.indexOf(m[1]),year=Number(m[2]||defaultYear);
  if(idx<0||year<2025||year>2100)continue;
  const month=`${year}-${String(idx+1).padStart(2,'0')}`;
  // Don't guess an amount when a table row has several columns.
  const after=line.slice(m.index+m[0].length);
  let values=matches(after);
  let source='mesma linha';
  // A simple two-column OCR may split the amount onto the next line.
  if(!values.length&&i+1<lines.length&&!monthPattern.test(norm(lines[i+1]))&&!isBadContext(lines[i+1])){
   const next=lines[i+1];
   if(/^(?:R\$\s*)?[\d.,\s]+$/.test(next)&&matches(next).length===1){
    values=matches(next);source='linha seguinte';
   }
  }
  const context=[lines[i-1]||'',line].join(' ');
  const bad=isBadContext(context)&&!isAporte(context);
  const score=(values.length===1?4:0)+(isAporte(context)?3:0)-(bad?4:0);
  candidates.push({month,amount:values.length===1&&!bad?values[0]:null,source,score,ambiguous:values.length>1||bad});
 }
 for(const c of candidates){
  const prior=found.get(c.month);
  if(!prior||c.score>prior.score)found.set(c.month,c);
  else if(prior.score===c.score&&prior.amount!==c.amount){
   found.set(c.month,{...prior,amount:null,ambiguous:true});
  }
 }
 const rows=[...found.values()].sort((a,b)=>a.month.localeCompare(b.month)).map(c=>{
  if(c.ambiguous||c.amount===null)warn.push(`${c.month}: valor não identificado com segurança. Confira manualmente.`);
  return {month:c.month,amount:c.amount,source:c.amount===null?'conferir':c.source};
 });
 return {rows,warnings:warn};
}
function el(tag,txt){const e=document.createElement(tag);if(txt!==undefined)e.textContent=txt;return e}
function render(){
 editor.hidden=false;editor.replaceChildren();
 editor.append(el('h4','Aportes por mês — revisão'));
 const note=el('p','Os valores do gráfico, saldo, parcelas e acumulado são ignorados. Preencha apenas o total que pretende separar em cada mês.');note.className='months86-note';editor.append(note);
 const list=el('div');editor.append(list);
 const total=el('div');total.className='months86-total';editor.append(total);
 function draw(){
 list.replaceChildren();
 rows.forEach((r,i)=>{
  const line=el('div');line.className='months86-row';
  const month=el('input');month.type='month';month.value=r.month;month.setAttribute('aria-label','Mês');month.onchange=()=>{r.month=month.value;update()};
  const value=el('input');value.type='number';value.min='0';value.step='0.01';value.placeholder='Aporte em R$';value.setAttribute('aria-label','Valor planejado');value.value=r.amount===null?'':String(r.amount);
  value.oninput=()=>{r.amount=value.value===''?null:Number(value.value);update()};
  const del=el('button','Remover');del.type='button';del.onclick=()=>{rows.splice(i,1);draw()};
  line.append(month,value,del);list.append(line);
  if(r.source==='conferir'){const msg=el('small','⚠️ Confira o valor deste mês');msg.style.color='#a66b20';msg.style.gridColumn='1/-1';line.append(msg);}

 });
 update();
 }
 function update(){const valid=rows.filter(r=>Number.isFinite(r.amount)&&r.amount>=0);total.textContent=`${valid.length} de ${rows.length} meses preenchidos · Total planejado: ${br(valid.reduce((a,r)=>a+r.amount,0))}`;}
 draw();
 const actions=el('div');actions.className='imp-actions';
 const add=el('button','+ Adicionar mês');add.type='button';add.onclick=()=>{rows.push({month:'2027-12',amount:null});draw()};
 const save=el('button','💚 Salvar somente meses e valores');save.type='button';save.className='primary';
 save.onclick=()=>{
  if(!rows.length||rows.some(r=>!/^20\d\d-(0[1-9]|1[0-2])$/.test(r.month)||r.amount===null||!Number.isFinite(r.amount)||r.amount<0)||new Set(rows.map(r=>r.month)).size!==rows.length){status.textContent='⚠️ Confira todos os meses e valores; não deixe campos vazios ou meses repetidos.';return}
  const name=prompt('Nome deste planejamento:','Plano de quitação - Banco do Brasil');
  if(name===null)return;
  if(!name.trim()){status.textContent='Informe um nome para identificar o planejamento.';return}
  let items;
  try{items=JSON.parse(localStorage.getItem(KEY)||'[]');if(!Array.isArray(items))throw Error('Lista inválida')}catch(e){status.textContent='Erro ao abrir planejamentos: '+e.message;return}
  const plan={id:'meses-'+Date.now()+'-'+Math.random().toString(36).slice(2),name:name.trim().slice(0,100),createdAt:new Date().toISOString(),rows:rows.map(r=>({month:r.month,amount:Math.round(r.amount*100)/100}))};
  if(!confirm(`Salvar ${plan.rows.length} meses de "${plan.name}"? Isso registra somente valores planejados, não pagamentos.`))return;
  try{
   localStorage.setItem(KEY,JSON.stringify([...items,plan]));
   const check=JSON.parse(localStorage.getItem(KEY)||'[]');
   if(!check.some(x=>x.id===plan.id))throw Error('A gravação não foi confirmada.');
   status.textContent=`✓ Salvo com sucesso: ${plan.name} (${plan.rows.length} meses).`;
   showSaved();
  }catch(e){status.textContent='❌ Falha ao salvar: '+e.message}
 };
 actions.append(add,save);editor.append(actions);
}
function showSaved(){
 saved.hidden=false;saved.replaceChildren();saved.append(el('h4','Meus planejamentos salvos'));
 let items;try{items=JSON.parse(localStorage.getItem(KEY)||'[]')}catch{items=[]}
 if(!Array.isArray(items)||!items.length){saved.append(el('p','Nenhum planejamento salvo ainda.'));return}
 for(const plan of items.slice().reverse()){
  const item=el('div');item.className='months86-saved';
  item.append(el('strong',plan.name||'Planejamento'));
  const total=(plan.rows||[]).reduce((sum,r)=>sum+Number(r.amount||0),0);
  item.append(el('p',`${(plan.rows||[]).length} meses · ${br(total)} planejados`));
  const view=el('button','Visualizar meses');view.type='button';view.onclick=()=>{rows=(plan.rows||[]).map(r=>({...r}));render();editor.scrollIntoView({block:'start',behavior:'smooth'});status.textContent='Visualização carregada. Para salvar alterações, será criado outro planejamento.'};
  const remove=el('button','Excluir');remove.type='button';remove.onclick=()=>{if(!confirm('Excluir este planejamento salvo?'))return;const next=items.filter(x=>x.id!==plan.id);localStorage.setItem(KEY,JSON.stringify(next));showSaved()};
  item.append(view,remove);saved.append(item);
 }
}
$('simpleUseText86').onclick=()=>{
 const t=text.value.trim()||old?.value.trim()||'';
 if(!t){status.textContent='Primeiro use “Ler imagem do plano” ou cole o texto na caixa acima.';return}
 const result=extract(t);rows=result.rows;warnings=result.warnings;
 if(!rows.length){
  status.textContent='Nenhum mês reconhecido. Adicione os meses manualmente na tabela.';
  rows=[{month:'2027-09',amount:null},{month:'2027-10',amount:null},{month:'2027-11',amount:null},{month:'2027-12',amount:null}];
 }else status.textContent=`${rows.length} mês(es) identificados; ${rows.filter(r=>r.amount!==null).length} valor(es) associados automaticamente. ${warnings.length?'Confira os campos sinalizados.':'Confira os valores antes de salvar.'}`;
 render();editor.scrollIntoView({block:'nearest',behavior:'smooth'});
};
$('simpleShow86').onclick=showSaved;
showSaved();
})();
