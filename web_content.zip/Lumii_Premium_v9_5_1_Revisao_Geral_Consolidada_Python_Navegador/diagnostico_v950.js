/* Lumii v9.5.0: auditoria local, sem modificar dados */
(function(){'use strict';
const prefix=/lumii|dval|premium|meses|cronograma/i;
function audit(store){
 const result={checked:0,issues:[],warnings:[],details:[]};
 for(let i=0;i<store.length;i++){
  const k=store.key(i);if(!prefix.test(k))continue;
  result.checked++;const raw=store.getItem(k);
  if(raw===null||raw===''){result.warnings.push(k+': vazio');continue}
  try{
   const value=JSON.parse(raw);
   if(value===null||typeof value!=='object')result.warnings.push(k+': conteúdo não estruturado');
   if(k==='dval-premium-v1'){
    if(!value||Array.isArray(value)||typeof value!=='object'){result.issues.push('Cadastro principal: formato inesperado');continue}
    for(const field of ['mov','div','metas']){
     if(value[field]!==undefined&&!Array.isArray(value[field]))result.issues.push('Cadastro principal: '+field+' não é lista');
    }
    if(Array.isArray(value.mov)){
     const bad=value.mov.filter(x=>!x||typeof x!=='object'||!Number.isFinite(Number(x.valor))||Number(x.valor)<0);
     if(bad.length)result.warnings.push(bad.length+' movimentação(ões) com valor ausente, inválido ou negativo');
     result.details.push(value.mov.length+' movimentação(ões) encontradas');
    }
   }
  }catch(e){
   // Algumas chaves históricas podem guardar texto simples; sinalizar sem presumir corrupção.
   result.warnings.push(k+': não está em formato JSON (pode ser configuração antiga)');
  }
 }
 if(!result.checked)result.warnings.push('Nenhum dado da Lumii encontrado nesta origem do navegador');
 return result;
}
function validateBackup(obj){return window.LumiiBackupFormatos951.validate(obj).count;}

function init(){
 if(document.getElementById('lumii-diagnostico-v950'))return;
 const box=document.createElement('details');box.id='lumii-diagnostico-v950';
 box.style.cssText='position:fixed;right:14px;bottom:68px;z-index:2147481900;max-width:min(340px,calc(100vw - 28px));background:#fffdf5;border:1px solid #d9c58a;border-radius:12px;padding:9px 12px;color:#174f3e;font:13px Arial,sans-serif;box-shadow:0 3px 12px #0002';
 const summary=document.createElement('summary');summary.textContent='🔎 Diagnóstico dos dados';summary.style.cssText='cursor:pointer;font-weight:bold';
 const desc=document.createElement('p');desc.textContent='Verificação local. Não altera nem recupera dados automaticamente.';
 const run=document.createElement('button');run.textContent='Verificar meus dados';run.type='button';
 const check=document.createElement('button');check.textContent='Conferir backup JSON';check.type='button';
 const file=document.createElement('input');file.type='file';file.accept='.json,application/json';file.hidden=true;
 const out=document.createElement('p');out.setAttribute('role','status');out.style.cssText='white-space:pre-line;overflow-wrap:anywhere;max-height:220px;overflow:auto';
 for(const b of [run,check])b.style.cssText='display:block;margin:7px 0;width:100%;border:1px solid #277359;background:#edf7f0;border-radius:8px;padding:8px;cursor:pointer;color:#174f3e';
 run.onclick=()=>{try{const a=audit(localStorage);out.textContent='Conjuntos verificados: '+a.checked+'\n'+(a.issues.length?'Problemas: '+a.issues.join('; '):'Nenhum erro estrutural crítico identificado.')+'\n'+(a.warnings.length?'Atenção: '+a.warnings.join('; '):'Sem alertas adicionais.')+'\n'+a.details.join('; ')}catch(e){out.textContent='Não foi possível conferir o armazenamento: '+e.message}};
 check.onclick=()=>file.click();
 file.onchange=async()=>{const f=file.files&&file.files[0];if(!f)return;try{
  if(f.size>20*1024*1024)throw Error('Limite de 20 MB');
  const obj=JSON.parse(await f.text());const n=validateBackup(obj);
  out.textContent='Backup reconhecido: '+n+' conjunto(s). Esta verificação não importa nem garante que todos os dados estejam corretos. Arquivo não foi alterado.';
 }catch(e){out.textContent='Backup não validado: '+e.message}finally{file.value=''}};
 box.append(summary,desc,run,check,file,out);document.body.appendChild(box);
}
window.LumiiDiagnostics950=Object.freeze({audit,validateBackup});
if(typeof document!=='undefined'){if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init()}
})();
