(()=>{
'use strict';
const KEY='lumii-meses-planejados-v86';
const money=v=>Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const monthLabel=s=>{const [y,m]=s.split('-').map(Number);return new Intl.DateTimeFormat('pt-BR',{month:'short',year:'numeric',timeZone:'UTC'}).format(new Date(Date.UTC(y,m-1,1)))};
const node=(tag,cls,txt)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(txt!==undefined)n.textContent=txt;return n};
function plans(){try{const data=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(data)?data.filter(p=>p&&typeof p.id==='string'&&Array.isArray(p.rows)):[]}catch{return []}}
function rows(p){return p.rows.filter(r=>r&&/^20\d\d-(0[1-9]|1[0-2])$/.test(r.month)&&Number.isFinite(Number(r.amount))&&Number(r.amount)>=0).sort((a,b)=>a.month.localeCompare(b.month))}
function heading(root,title,subtitle){const h=node('div','v901-head');h.append(node('h3','',title),node('span','v901-chip',subtitle));root.append(h)}
function render(){const data=plans();for(const [id,compact] of [['v901Home',true],['v901Goals',false]]){
 const root=document.getElementById(id);if(!root)continue;root.replaceChildren();heading(root,compact?'🎯 Seus planejamentos importados':'🌿 Planejamentos importados','Lumii Premium · v9.0.1');
 if(!data.length){root.append(node('p','v901-note','Ainda não há planejamentos importados. Use a aba Importar para ler uma imagem e salvar os meses e valores.'));continue}
 const grid=node('div','v901-grid');
 for(const p of data){const r=rows(p),total=Math.round(r.reduce((a,x)=>a+Number(x.amount),0)*100)/100;
 const card=node('article','v901-card');card.append(node('h4','',String(p.name||'Planejamento')));
 const sums=node('div','v901-sums');const amount=node('div');amount.append(node('small','','Total planejado'),node('br'),node('strong','',money(total)));sums.append(amount);card.append(sums);
 const meter=node('div','v901-meter');meter.append(node('div'));card.append(meter);
 card.append(node('small','','Guardado confirmado: não informado · Progresso real: não calculado'));
 if(r.length)card.append(node('p','v901-months',r.length+' aporte(s) previsto(s) · '+monthLabel(r[0].month)+' até '+monthLabel(r[r.length-1].month)));
 if(!compact){const details=node('details');const summary=node('summary','','Ver aportes por mês');details.append(summary);const table=node('div','');for(const item of r){const line=node('p','v901-months',monthLabel(item.month)+' — '+money(item.amount));table.append(line)}details.append(table);card.append(details)}
 grid.append(card)
 }
 root.append(grid);root.append(node('p','v901-note','Os valores acima são planos, não depósitos realizados. Os dados permanecem na área de Importar e não criam metas duplicadas. Na próxima etapa, você poderá registrar os aportes reais.'));
 }}
let last='';function refresh(){const raw=localStorage.getItem(KEY)||'[]';if(raw!==last){last=raw;render()}}
render();last=localStorage.getItem(KEY)||'[]';
document.querySelectorAll('.tabs button').forEach(b=>b.addEventListener('click',()=>setTimeout(render,0)));
window.addEventListener('storage',e=>{if(e.key===KEY)refresh()});
document.getElementById('simpleShow86')?.addEventListener('click',()=>setTimeout(render,0));
const originalSet=Storage.prototype.setItem;
// Don't modify the storage implementation. Re-render after save button clicks instead.
document.addEventListener('click',e=>{if(e.target?.textContent?.includes('Salvar somente meses e valores'))setTimeout(render,250)});
})();