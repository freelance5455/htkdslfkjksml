(()=>{
'use strict';
const KEY='lumii-meses-planejados-v86';
const $=id=>document.getElementById(id), status=$('plansStatus88');
const say=s=>{if(status)status.textContent=s};
const get=()=>{const x=JSON.parse(localStorage.getItem(KEY)||'[]');if(!Array.isArray(x))throw Error('Dados de planos inválidos');return x};
const valid=x=>x&&typeof x==='object'&&typeof x.id==='string'&&x.id.length<150&&typeof x.name==='string'&&x.name.length<=100&&Array.isArray(x.rows)&&x.rows.length>0&&x.rows.length<=240&&x.rows.every(r=>r&&/^20\d\d-(0[1-9]|1[0-2])$/.test(r.month)&&typeof r.amount==='number'&&Number.isFinite(r.amount)&&r.amount>=0&&r.amount<=1e9);
$('exportPlans88')?.addEventListener('click',()=>{
 try{
  const plans=get(),payload={format:'lumii-plans-v1',exportedAt:new Date().toISOString(),plans};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download='lumii-planejamentos-'+new Date().toISOString().slice(0,10)+'.json';
  document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);
  say('✓ Backup de '+plans.length+' planejamento(s) preparado para download.');
 }catch(e){say('❌ Não foi possível exportar: '+e.message)}
});
$('importPlans88')?.addEventListener('change',async e=>{
 const f=e.target.files?.[0];if(!f)return;
 try{
  if(f.size>2e6)throw Error('Arquivo acima de 2 MB');
  const payload=JSON.parse(await f.text());
  if(payload?.format!=='lumii-plans-v1'||!Array.isArray(payload.plans)||payload.plans.length>1000||!payload.plans.every(valid))throw Error('Este arquivo não é um backup válido de planejamentos Lumii');
  const current=get(),ids=new Set(current.map(x=>x.id)),incoming=payload.plans.filter(x=>!ids.has(x.id));
  if(!confirm('Importar '+incoming.length+' planejamento(s) novo(s)? Os existentes serão mantidos.'))return;
  localStorage.setItem(KEY,JSON.stringify([...current,...incoming]));
  if(get().length!==current.length+incoming.length)throw Error('Não foi possível verificar a gravação');
  say('✓ '+incoming.length+' planejamento(s) importado(s). Clique em “Ver meus planos salvos” para conferir.');
  $('simpleShow86')?.click();
 }catch(err){say('❌ '+err.message)}
 finally{e.target.value=''}
});
})();