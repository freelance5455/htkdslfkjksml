(()=>{'use strict';
const $=id=>document.getElementById(id);
const old=$('textoPremium'), newText=$('planText84'), analyze=$('planAnalyze84'), preview=$('planPreview84'), status=$('planStatus84');
if(!newText||!analyze||!preview||!status)return;
const words=['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
const clean=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const number=s=>{let v=String(s).replace(/[^\d.,]/g,'');if(v.includes(','))v=v.replace(/\./g,'').replace(',','.');return Number(v)};
const currency=s=>[...String(s).matchAll(/(?:R\$\s*)?(\d{1,3}(?:\.\d{3})*,\d{2}|\d+,\d{2})/g)].map(x=>number(x[1]));
const matchVal=(text,re)=>{const m=text.match(re);return m?number(m[1]):NaN};
function getData(text){
 const lines=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 const name=/banco\s+do\s+brasil/i.test(text)?'Banco do Brasil':/creditas/i.test(text)?'Creditas':/meutudo/i.test(text)?'MEUTUDO':'Empréstimo importado';
 const locate=(re)=>{for(let i=0;i<lines.length;i++){if(re.test(clean(lines[i]))){const candidates=[lines[i],lines[i+1]||''];for(const c of candidates){const amounts=currency(c);if(amounts.length)return amounts[0]}}}return NaN};
 const saldo=locate(/saldo\s+atual|saldo\s+para\s+quitacao/);
 const parcela=locate(/parcela\s+mensal|parcela\s+do\s+mes/);
 let restantes=0;for(let i=0;i<lines.length;i++){if(/parcelas\s+restantes/i.test(clean(lines[i]))){const n=(lines[i].match(/(?:restantes)\D*(\d{1,4})/i)||[])[1]||(lines[i+1]||'').match(/^\s*(\d{1,4})\s*$/)?.[1];if(n){restantes=Number(n);break}}}
 const years=[...text.matchAll(/20\d{2}/g)].map(x=>Number(x[0]));const year=years.find(y=>y>=2026&&y<=2099)||new Date().getFullYear();
 const rows=[];
 for(const line of lines){
  const l=clean(line);
  const m=l.match(/\b(janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s*(?:\/|de\s+)?\s*(20\d\d)?/);
  if(!m)continue;
  const idx=words.map(clean).indexOf(m[1]);if(idx<0)continue;
  const y=Number(m[2]||year);if(y<2026||y>2099)continue;
  const vals=currency(line);if(!vals.length)continue;
  // Full OCR tables are ambiguous. Use only a clear single amount; otherwise require manual review.
  const amount=vals.length===1?vals[0]:NaN;
  if(!Number.isFinite(amount)||amount<0)continue;
  const month=`${y}-${String(idx+1).padStart(2,'0')}`;
  if(!rows.some(r=>r.month===month))rows.push({month,amount});
 }
 rows.sort((a,b)=>a.month.localeCompare(b.month));
 return {name,saldo,parcela,restantes,rows};
}
function renderFallback(text,reason){const data=getData(text);
 if(!data.rows.length){
  const year=(text.match(/20\d{2}/)||[])[0]||String(new Date().getFullYear());
  const months=['09','10','11','12'];data.rows=months.map(m=>({month:year+'-'+m,amount:0}));
 }
 preview.hidden=false;preview.replaceChildren();
 const h=document.createElement('h3');h.textContent='Revisão do plano de quitação';preview.append(h);
 const info=document.createElement('p');info.textContent='A leitura automática não concluiu a análise. Confira ou corrija os campos abaixo; nenhum valor será salvo automaticamente.';preview.append(info);
 const form=document.createElement('div');form.className='plan-grid';
 function input(label,key,val,type='text'){const wrap=document.createElement('div'),l=document.createElement('label'),i=document.createElement('input');l.textContent=label;i.type=type;i.value=(typeof val==='number'&&!Number.isFinite(val))?'':val;i.dataset.v842=key;if(type==='number'){i.min='0';i.step=key==='restantes'?'1':'0.01'}wrap.append(l,i);form.append(wrap)}
 input('Banco / dívida','name',data.name);input('Saldo para quitação (R$)','saldo',data.saldo,'number');input('Parcela mensal (R$)','parcela',data.parcela,'number');input('Parcelas restantes','restantes',data.restantes,'number');preview.append(form);
 const h4=document.createElement('h4');h4.textContent='Aportes planejados por mês';preview.append(h4);
 const list=document.createElement('div');preview.append(list);
 function draw(){list.replaceChildren();data.rows.forEach((row,i)=>{const wrap=document.createElement('div');wrap.className='plan-grid';const m=document.createElement('input');m.type='month';m.value=row.month;m.setAttribute('aria-label','Mês');m.oninput=()=>row.month=m.value;const v=document.createElement('input');v.type='number';v.min='0';v.step='0.01';v.value=row.amount;v.setAttribute('aria-label','Aporte planejado');v.oninput=()=>row.amount=Number(v.value);const del=document.createElement('button');del.type='button';del.textContent='Remover mês';del.onclick=()=>{data.rows.splice(i,1);draw()};wrap.append(m,v,del);list.append(wrap)})}draw();
 const add=document.createElement('button');add.type='button';add.textContent='+ Adicionar mês';add.onclick=()=>{data.rows.push({month:'2027-12',amount:0});draw()};preview.append(add);
 const note=document.createElement('p');note.textContent='Aportes são valores planejados, não dinheiro já guardado. Confira os valores de quitação diretamente com o banco.';preview.append(note);
 const save=document.createElement('button');save.type='button';save.className='primary';save.textContent='Salvar plano revisado';preview.append(save);

 save.onclick=()=>{
 const val=k=>preview.querySelector(`[data-v842="${k}"]`)?.value||'';
 const name=val('name').trim().slice(0,80),saldo=Number(val('saldo')),parcela=Number(val('parcela')),restantes=Number(val('restantes'));
 if(!name||!val('saldo')||!Number.isFinite(saldo)||saldo<=0||!Number.isFinite(parcela)||parcela<0||!Number.isInteger(restantes)||restantes<0||restantes>1200){status.textContent='⚠️ Confira nome, saldo, parcela e parcelas restantes.';return}
 const rows=data.rows.slice().sort((a,b)=>a.month.localeCompare(b.month));
 if(!rows.length||rows.some(r=>!/^20\d\d-(0[1-9]|1[0-2])$/.test(r.month)||!Number.isFinite(r.amount)||r.amount<0)||new Set(rows.map(r=>r.month)).size!==rows.length){status.textContent='⚠️ Informe os aportes mensais corretos e confira os meses sem repetições.';return}
 const key='dval-premium-v1',pk='dval-premium-cronogramas-v1';
 let db,plans;
 try{db=JSON.parse(localStorage.getItem(key)||'{"mov":[],"div":[],"metas":[]}');plans=JSON.parse(localStorage.getItem(pk)||'{}');
 if(!Array.isArray(db.div)||!Array.isArray(db.mov)||!Array.isArray(db.metas)||!plans||typeof plans!=='object'||Array.isArray(plans))throw Error('Formato de dados inválido');
 }catch(e){status.textContent='⚠️ Não foi possível abrir seus registros: '+e.message;return}
 if(db.div.some(x=>clean(x.nome)===clean(name)&&Math.abs(Number(x.saldo)-saldo)<0.01)){
 status.textContent='⚠️ Essa dívida já está cadastrada. Veja a aba Dívidas antes de salvar novamente.';return}
 if(!confirm('Salvar '+name+' e '+rows.length+' meses PLANEJADOS? Não serão registrados pagamentos nem valores guardados.'))return;
 const id=globalThis.crypto?.randomUUID?.()||'plano-'+Date.now()+'-'+Math.random().toString(36).slice(2);
 const monthIndex=m=>Number(m.slice(0,4))*12+Number(m.slice(5))-1;
 const debt={id,nome:name,saldo,parcela,restantes};
 const plan={debtId:id,initial:0,rows:rows.map(r=>({month:monthIndex(r.month),base:Math.round(r.amount*100)/100,extra:0}))};
 const previousDb=localStorage.getItem(key),previousPlans=localStorage.getItem(pk);
 save.disabled=true;save.textContent='Salvando…';
 try{
 db.div.push(debt);plans[id]=plan;
 localStorage.setItem(key,JSON.stringify(db));
 localStorage.setItem(pk,JSON.stringify(plans));
 const checkDb=JSON.parse(localStorage.getItem(key)||'{}'),checkPlans=JSON.parse(localStorage.getItem(pk)||'{}');
 if(!checkDb.div?.some(x=>x.id===id)||!checkPlans[id]||checkPlans[id].rows.length!==rows.length)throw Error('O navegador não confirmou os dados gravados.');
 const success=document.createElement('div');success.className='lumii-save-success';
 success.innerHTML='<strong>✓ Planejamento salvo e conferido!</strong><p>A dívida e os aportes planejados foram registrados neste navegador.</p>';
 const link=document.createElement('button');link.type='button';link.className='primary';link.textContent='Ver dívida e cronograma';
 link.onclick=()=>{document.getElementById('impDebtChoice')?.click();document.querySelector('[data-tab="dividas"]')?.click();};
 success.append(link);preview.append(success);
 status.textContent='✓ Salvamento confirmado: '+name+' · '+rows.length+' mês(es).';
 save.textContent='Plano salvo';save.disabled=true;
 const refresh=document.createElement('button');refresh.type='button';refresh.textContent='Atualizar e visualizar em Dívidas';refresh.onclick=()=>location.reload();success.append(refresh);
 }catch(e){
 try{if(previousDb===null)localStorage.removeItem(key);else localStorage.setItem(key,previousDb);
 if(previousPlans===null)localStorage.removeItem(pk);else localStorage.setItem(pk,previousPlans)}catch{}
 status.textContent='❌ Não foi possível salvar: '+e.message+'. Seus registros anteriores foram preservados.';
 save.disabled=false;save.textContent='Tentar salvar novamente';
 }
 };

 status.textContent='Prévia de revisão aberta. '+data.rows.length+' mês(es) reconhecidos. '+(reason||'Confira os valores.');preview.scrollIntoView({behavior:'smooth',block:'nearest'});
}
function route(){const t=(old?.value||newText.value||'').trim();if(!t){status.textContent='Primeiro leia a imagem ou cole o texto.';return}const debt=$('impDebtChoice');debt?.click();newText.value=t;try{renderFallback(t)}catch(e){status.textContent='Erro na análise: '+e.message;preview.hidden=false;preview.textContent='Não foi possível montar a prévia. Tente colar o texto novamente.'}}
const original=$('sendPlan841');if(original){const newer=original.cloneNode(true);original.replaceWith(newer);newer.addEventListener('click',route)}
const oldAnalyze=$('interpretarTexto');if(oldAnalyze){oldAnalyze.addEventListener('click',e=>{if(/quita[cç][aã]o|parcelas restantes|banco do brasil|aporte mensal/i.test(old?.value||'')){e.preventDefault();e.stopImmediatePropagation();route()}},true)}
const planAnalyze=$('planAnalyze84');if(planAnalyze){const newer=planAnalyze.cloneNode(true);planAnalyze.replaceWith(newer);newer.addEventListener('click',()=>renderFallback(newText.value,'Análise concluída em modo de revisão.'))}
const quick=document.createElement('button');quick.type='button';quick.textContent='📊 Abrir revisão do plano agora';quick.style.cssText='background:#176547;color:white;margin:8px 0;padding:11px 15px;border-radius:10px;cursor:pointer';quick.addEventListener('click',route);old?.closest('.imp-more-inner')?.append(quick);
const hint=document.createElement('p');hint.textContent='Se a análise antiga não responder, clique em “Abrir revisão do plano agora”. A prévia será aberta mesmo quando a leitura do texto estiver incompleta.';hint.className='imp-help';old?.closest('.imp-more-inner')?.append(hint);
})();
