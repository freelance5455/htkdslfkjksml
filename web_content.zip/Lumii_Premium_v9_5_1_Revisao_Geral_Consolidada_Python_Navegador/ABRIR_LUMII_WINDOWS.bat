@echo off
cd /d "%~dp0"
echo Abrindo Lumii Premium 9.5.1 no navegador...
py -3 servidor_lumii.py
if errorlevel 1 python servidor_lumii.py
pause
