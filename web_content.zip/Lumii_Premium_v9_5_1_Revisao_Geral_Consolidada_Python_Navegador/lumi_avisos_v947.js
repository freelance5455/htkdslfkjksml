(()=>{'use strict';
const KEY='dval-premium-v1', el=document.getElementById('l93Panel');if(!el||document.getElementById('l947Extra'))return;
const box=document.createElement('div');box.id='l947Extra';box.className='l947-extra';
const title=document.createElement('h4');title.textContent='💚 Avisos da Lumi';
const desc=document.createElement('p');desc.textContent='Confira vencimentos, metas e categorias usando apenas seus registros locais. Datas previstas não confirmam pagamento.';
const btn=document.createElement('button');btn.type='button';btn.textContent='Atualizar avisos';btn.className='l93-refresh';
const result=document.createElement('div');result.setAttribute('aria-live','polite');
box.append(title,desc,btn,result);el.append(box);
const read=(k,f)=>{try{let v=JSON.parse(localStorage.getItem(k)||'null');return v===null?f:v}catch{return f}};
const amount=v=>{let n=Number(v);return Number.isFinite(n)?n:0};
const money=v=>v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const date=s=>{if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return null;let d=new Date(s+'T12:00:00');return Number.isNaN(+d)?null:d};
const today=()=>{let d=new Date();d.setHours(12,0,0,0);return d};
const label=(h,p)=>{let item=document.createElement('div');item.className='l93-insight';let a=document.createElement('strong');a.textContent=h;let b=document.createElement('p');b.textContent=p;item.append(a,b);result.append(item)};
function update(){result.replaceChildren();const data=read(KEY,{});let mov=Array.isArray(data.mov)?data.mov:[], debts=Array.isArray(data.div)?data.div:[],goals=Array.isArray(data.metas)?data.metas:[];let now=today(),soon=[],late=[];
for(const m of mov){if(!m||m.tipo!=='despesa'||m.pago===true||m.status==='pago')continue;let d=date(m.vencimento||m.data);if(!d)continue;let days=Math.round((d-now)/86400000);if(days>=0&&days<=7)soon.push({days,name:String(m.descricao||m.nome||'Despesa'),value:amount(m.valor)});else if(days<0&&days>=-30)late.push({days,name:String(m.descricao||m.nome||'Despesa')});}
for(const d0 of debts){if(!d0)continue;let d=date(d0.vencimento);if(!d)continue;let days=Math.round((d-now)/86400000);if(days>=0&&days<=7)soon.push({days,name:String(d0.nome||'Parcela'),value:amount(d0.parcela)});}
soon.sort((a,b)=>a.days-b.days);if(soon.length){label('Próximos 7 dias',`${soon.length} compromisso(s) com data informada: `+soon.slice(0,3).map(x=>`${x.name} (${x.days===0?'hoje':`em ${x.days} dia(s)`}${x.value>0?', '+money(x.value):''})`).join('; ')+'. Confira se já foram pagos.')}else label('Vencimentos','Não encontrei compromissos futuros datados para os próximos 7 dias nos registros reconhecidos.');
if(late.length)label('Datas anteriores',`${late.length} despesa(s) com data anterior nos últimos 30 dias e sem confirmação de pagamento reconhecida. Confira o status antes de considerar atraso.`);
let active=goals.filter(g=>g&&amount(g.alvo)>0&&amount(g.atual)>=0&&amount(g.atual)<amount(g.alvo));if(active.length){active.sort((a,b)=>(amount(b.atual)/amount(b.alvo))-(amount(a.atual)/amount(a.alvo)));let g=active[0],pct=Math.min(100,Math.round(100*amount(g.atual)/amount(g.alvo)));label('Meta mais próxima',`${g.nome||'Meta'}: ${pct}% registrado. Faltam ${money(Math.max(0,amount(g.alvo)-amount(g.atual)))} para o valor-alvo.`)}
let ym=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0');let expenses=mov.filter(m=>m&&m.tipo==='despesa'&&typeof m.data==='string'&&m.data.startsWith(ym));let groups={};for(let m of expenses){let c=String(m.categoria||'Sem categoria').trim()||'Sem categoria';groups[c]=(groups[c]||0)+Math.max(0,amount(m.valor))}let entries=Object.entries(groups).sort((a,b)=>b[1]-a[1]);if(entries.length){let total=entries.reduce((s,x)=>s+x[1],0),[cat,v]=entries[0];label('Categoria com maior gasto',`${cat}: ${money(v)} (${total?Math.round(v/total*100):0}% das despesas registradas neste mês). Isso depende da classificação e da completude dos lançamentos.`)}
if(!mov.length&&!debts.length&&!goals.length)label('Comece por aqui','Cadastre movimentações, dívidas ou metas para a Lumi mostrar avisos personalizados.');
}
btn.addEventListener('click',update);
})();