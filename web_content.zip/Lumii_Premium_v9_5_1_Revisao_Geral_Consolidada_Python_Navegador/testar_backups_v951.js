global.window={};
(function(){'use strict';
const RE=/^(?:dval-premium|lumii-)[a-zA-Z0-9_.-]+$/;
const MAIN='dval-premium-v1';
function validate(obj){
 if(!obj||typeof obj!=='object'||Array.isArray(obj))throw Error('Arquivo de backup inválido');
 const isFull=obj.format==='lumii-full-backup-v903';
 const isLocal=obj.format==='lumii-local-backup-v1';
 if(!isFull&&!isLocal)throw Error('Formato de backup não reconhecido');
 const data=isFull?obj.keys:obj.items;
 if(!data||typeof data!=='object'||Array.isArray(data))throw Error('Conjuntos ausentes');
 const entries=Object.entries(data);
 if(!entries.length||entries.length>100)throw Error('Quantidade de conjuntos inesperada');
 if(!Object.prototype.hasOwnProperty.call(data,MAIN))throw Error('Backup sem cadastro financeiro principal');
 for(const [key,value] of entries){
  if(!RE.test(key)||typeof value!=='string'||value.length>6000000)throw Error('Conjunto inválido: '+key);
  try{JSON.parse(value)}catch{throw Error('JSON inválido no conjunto '+key)}
 }
 const main=JSON.parse(data[MAIN]);
 if(!main||typeof main!=='object'||Array.isArray(main)||!['mov','div','metas'].every(k=>Array.isArray(main[k])&&main[k].length<=100000))throw Error('Cadastro financeiro inválido');
 for(const key of ['lumii-meses-planejados-v86','lumii-aportes-reais-v902'])if(Object.prototype.hasOwnProperty.call(data,key)&&!Array.isArray(JSON.parse(data[key])))throw Error('Formato inválido em '+key);
 return {keys:data,count:entries.length,format:obj.format};
}
window.LumiiBackupFormatos951=Object.freeze({validate});
})();

const v=window.LumiiBackupFormatos951.validate;const keys={'dval-premium-v1':JSON.stringify({mov:[],div:[],metas:[]})};for(const [format,field] of [['lumii-full-backup-v903','keys'],['lumii-local-backup-v1','items']]){if(v({format,[field]:keys}).count!==1)throw Error('failed valid')}let rejected=false;try{v({format:'lumii-local-backup-v1',items:{'evil': '{}'}})}catch(e){rejected=true}if(!rejected)throw Error('failed invalid');console.log('backup validation OK');