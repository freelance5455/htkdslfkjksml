SARKI BAKA GLOBAL VENTURES - PORTAL
=====================================

FILES
- index.html
- css/style.css
- js/app.js

DEMO ADMIN LOGIN
Username: admin
Password: admin123

FEATURES
- Customer registration
- Customer login
- Admin login
- Admin dashboard
- Customer management
- Service management
- Notifications
- Contact messages
- Admin settings
- Responsive mobile design
- Browser localStorage persistence

IMPORTANT
This package is an offline/front-end portal. Data is stored in the browser using localStorage.
For a production company portal, connect it to a real backend/database and use secure server-side authentication and password hashing.

HOW TO USE
1. Extract the ZIP.
2. Open index.html in a browser, or import the folder/project into an HTML-to-APK builder.
3. Use the demo admin account above.
