const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validProfile(uid, ts) {
  return {
    userId: uid,
    displayName: "Aarav Sharma",
    preferredStyle: "Luxury Minimalist",
    preferredOccasion: "Office",
    preferredColors: "Black, White, Charcoal",
    budgetMaxInr: 5000,
    preferredRetailers: "Myntra, AJIO, Amazon, Flipkart",
    membershipTier: "FREE",
    tryOnCountUsed: 1,
    recommendationsUsed: 2,
    photoConsentGranted: true,
    hasUploadedPhoto: true,
    createdAt: ts,
    updatedAt: ts,
  };
}

function validOutfit(uid, ts) {
  return {
    userId: uid,
    title: "Tailored Monochrome Structured Blazer Set",
    category: "Complete outfit combinations",
    occasion: "Office",
    brand: "MANGO MAN",
    color: "Obsidian Black",
    priceInr: 4599,
    imageUrl: "https://images.unsplash.com/photo-1507679799987-c73779587ccf",
    productUrl: "https://www.myntra.com/blazers",
    retailer: "Myntra",
    stylistNote: "Sharp peak lapels elongate the torso while monochrome contrast creates editorial authority.",
    matchingShoes: "Black Italian Leather Chelsea Boots",
    matchingAccessories: "Minimalist Silver Chronograph Watch",
    createdAt: ts,
    updatedAt: ts,
  };
}

test("Unauthenticated user cannot read or write user profiles", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
});

test("Authenticated owner can create and read their own profile", async () => {
  const aliceCtx = testEnv.authenticatedContext(ALICE_UID);
  const aliceDb = aliceCtx.firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validProfile(ALICE_UID, now))
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      heightCm: 175,
      weightKg: 70,
      preferredTopSize: "L",
      preferredBottomSize: "32",
      bodyFitPreference: "Tailored Fit",
      updatedAt: new Date(),
    })
  );
  // Out-of-bounds heightCm (> 250) should be rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      heightCm: 400,
      updatedAt: new Date(),
    })
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
});

test("Cross-user access to profile and saved_outfits is rejected", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection("users").doc(ALICE_UID).set(validProfile(ALICE_UID, now));
    await db
      .collection("users")
      .doc(ALICE_UID)
      .collection("saved_outfits")
      .doc("outfit_1")
      .set(validOutfit(ALICE_UID, now));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("saved_outfits")
      .doc("outfit_1")
      .get()
  );
});

test("Shadow field injection on profile create is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  const poisoned = {
    ...validProfile(ALICE_UID, now),
    isAdmin: true,
  };
  await assertFails(aliceDb.collection("users").doc(ALICE_UID).set(poisoned));
});

test("Owner can create, list, and delete saved outfits", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("saved_outfits")
      .doc("outfit_1")
      .set(validOutfit(ALICE_UID, now))
  );
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("saved_outfits")
      .where("userId", "==", ALICE_UID)
      .get()
  );
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("saved_outfits")
      .doc("outfit_1")
      .delete()
  );
});

function validWishlistItem(uid, ts) {
  return {
    userId: uid,
    productId: "prod_101",
    title: "Royal Silk Embroidered Bandhgala Jacket",
    brand: "MANYAVAR",
    category: "Ethnic wear",
    occasion: "Wedding",
    selectedColor: "Obsidian Black",
    selectedSize: "L",
    priceInr: 3999,
    originalPriceInr: 6999,
    imageUrl: "https://images.unsplash.com/photo-1507679799987-c73779587ccf",
    productUrl: "https://www.myntra.com/ethnic-wear",
    retailer: "Myntra",
    notes: "Saved for December wedding reception • Pair with ivory churidar.",
    createdAt: ts,
    updatedAt: ts,
  };
}

test("Owner can create, list, update, and delete wishlist_items per userId, and cross-user access is denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date();

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("wishlist_items")
      .doc("wish_prod_101")
      .set(validWishlistItem(ALICE_UID, now))
  );

  // List own wishlist items
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("wishlist_items")
      .where("userId", "==", ALICE_UID)
      .get()
  );

  // Update selectedSize and notes
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("wishlist_items")
      .doc("wish_prod_101")
      .update({
        selectedSize: "XL",
        selectedColor: "Emerald Green",
        notes: "Updated size to XL after AR try-on calibration.",
        updatedAt: new Date(),
      })
  );

  // Cross-user read and delete must be rejected
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("wishlist_items")
      .doc("wish_prod_101")
      .get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("wishlist_items")
      .doc("wish_prod_101")
      .delete()
  );

  // Owner delete succeeds
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("wishlist_items")
      .doc("wish_prod_101")
      .delete()
  );
});

