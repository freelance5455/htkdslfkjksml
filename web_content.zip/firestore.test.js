const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = "demo-no-project";
const ALICE_UID = "alice_cust_123";
const BOB_UID = "bob_cust_456";
const ADMIN_UID = "admin_bimal_789";
const ADMIN_EMAIL = "bhandaribimal778@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Public user can read active providers", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("providers").doc("prov_1").set({
      name: "Ram Sharma",
      category: "electrician",
      city: "Tulsipur",
      description: "Wiring and meter repair",
      phone: "9847123456",
      phonePublic: true,
      active: true,
      createdAt: new Date(),
    });
  });

  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertSucceeds(unauthDb.collection("providers").doc("prov_1").get());
});

test("Public user cannot read inactive providers", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("providers").doc("prov_inactive").set({
      name: "Inactive Plumber",
      category: "plumber",
      city: "Ghorahi",
      description: "Not active",
      phone: "9847000000",
      phonePublic: false,
      active: false,
      createdAt: new Date(),
    });
  });

  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("providers").doc("prov_inactive").get());
});

test("Non-admin cannot create or update providers", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("providers").doc("prov_new").set({
      name: "Hacker Tech",
      category: "electrician",
      city: "Tulsipur",
      description: "Malicious entry",
      phonePublic: true,
      active: true,
      createdAt: new Date(),
    })
  );
});

test("Admin can create a provider", async () => {
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, { email: ADMIN_EMAIL }).firestore();
  await assertSucceeds(
    adminDb.collection("providers").doc("prov_admin_1").set({
      name: "Hari Electrician",
      category: "electrician",
      city: "Tulsipur",
      description: "Expert home wiring",
      phone: "9857812345",
      phonePublic: true,
      active: true,
      createdAt: new Date(),
    })
  );
});

test("Customer can create a pending booking for themselves", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("bookings").doc("booking_alice_1").set({
      customerUid: ALICE_UID,
      customerName: "Alice Shrestha",
      customerPhone: "9841234567",
      providerId: "prov_1",
      providerName: "Ram Sharma",
      category: "electrician",
      city: "Tulsipur",
      address: "Line-mini chowk, Ward 5",
      description: "Switchboard sparking issue",
      preferredDate: "2026-10-25",
      preferredTime: "Morning",
      status: "pending",
      createdAt: new Date(),
    })
  );
});

test("Customer cannot create booking under someone else's UID", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("bookings").doc("booking_spoof").set({
      customerUid: BOB_UID, // Spoofed!
      customerName: "Bob Thapa",
      customerPhone: "9841999999",
      providerId: "prov_1",
      category: "electrician",
      city: "Tulsipur",
      address: "Ward 3",
      description: "Spoof booking",
      status: "pending",
      createdAt: new Date(),
    })
  );
});

test("Customer cannot read another customer's booking", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("bookings").doc("booking_alice_private").set({
      customerUid: ALICE_UID,
      customerName: "Alice Shrestha",
      customerPhone: "9841234567",
      providerId: "prov_1",
      category: "electrician",
      city: "Tulsipur",
      address: "Line-mini chowk",
      description: "Short circuit",
      status: "pending",
      createdAt: new Date(),
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("bookings").doc("booking_alice_private").get());
});

test("Customer can cancel their own pending booking", async () => {
  const createdAt = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("bookings").doc("booking_alice_cancel").set({
      customerUid: ALICE_UID,
      customerName: "Alice Shrestha",
      customerPhone: "9841234567",
      providerId: "prov_1",
      category: "electrician",
      city: "Tulsipur",
      address: "Line-mini chowk",
      description: "Short circuit",
      status: "pending",
      createdAt,
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("bookings").doc("booking_alice_cancel").update({
      status: "cancelled",
      updatedAt: new Date(),
    })
  );
});
