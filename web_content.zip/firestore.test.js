const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const CUSTOMER_UID = "customer_asha_01";
const PROVIDER_UID = "provider_simba_01";
const OTHER_UID = "stranger_99";
const ADMIN_UID = "admin_joshua_01";
const ADMIN_EMAIL = "joshuachota04@gmail.com";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

const pastTime = () => new Date(Date.now() - 2000);
const futureTime = () => new Date(Date.now() + 60000);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) await testEnv.cleanup();
});

beforeEach(async () => {
  if (testEnv) await testEnv.clearFirestore();
});

test("Unauthenticated users are denied across all collections", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("providers").get());
  await assertFails(unauth.collection("services").get());
  await assertFails(unauth.collection("orders").get());
  await assertFails(unauth.collection("users").doc(CUSTOMER_UID).get());
  await assertFails(unauth.collection("payments").get());
});

test("User PII isolation: owner can create/read/update own profile; other users cannot read; cannot self-assign admin", async () => {
  const customerDb = testEnv.authenticatedContext(CUSTOMER_UID, {
    email: "asha@example.tz",
    email_verified: true,
  }).firestore();
  const otherDb = testEnv.authenticatedContext(OTHER_UID, {
    email: "other@example.tz",
    email_verified: true,
  }).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();

  const ts = pastTime();
  await assertSucceeds(
    customerDb.collection("users").doc(CUSTOMER_UID).set({
      userId: CUSTOMER_UID,
      fullName: "Asha Juma",
      email: "asha@example.tz",
      phone: "0712345678",
      region: "Dar es Salaam",
      address: "Mikocheni B",
      preferredLanguage: "sw",
      activeRole: "customer",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(customerDb.collection("users").doc(CUSTOMER_UID).get());
  await assertFails(otherDb.collection("users").doc(CUSTOMER_UID).get());
  await assertFails(otherDb.collection("users").get());

  // Cannot inject admin activeRole or ghost field
  await assertFails(
    customerDb.collection("users").doc(CUSTOMER_UID).update({
      activeRole: "admin",
      updatedAt: pastTime(),
    })
  );
  await assertFails(
    customerDb.collection("users").doc(CUSTOMER_UID).update({
      isAdmin: true,
      updatedAt: pastTime(),
    })
  );

  // Admin can list users
  await assertSucceeds(adminDb.collection("users").get());
});

test("Email spoofing test: unverified admin email is rejected", async () => {
  const spoofedAdminDb = testEnv.authenticatedContext("spoof_uid", {
    email: ADMIN_EMAIL,
    email_verified: false,
  }).firestore();

  await assertFails(spoofedAdminDb.collection("users").get());
  await assertFails(spoofedAdminDb.collection("audit_logs").get());
});

test("Providers: registration enforces PENDING & unverified; only verified admin can grant verifiedBadge", async () => {
  const providerDb = testEnv.authenticatedContext(PROVIDER_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();

  const ts = pastTime();
  // Attempting to self-verify on create fails
  await assertFails(
    providerDb.collection("providers").doc("prov_1").set({
      ownerId: PROVIDER_UID,
      companyName: "Simba Guard Ltd",
      description: "Professional armed and unarmed security guards across Dar es Salaam.",
      categories: ["SECURITY_GUARDS"],
      locations: ["Dar es Salaam", "Arusha"],
      startingPriceTzs: 350000,
      businessRegNumber: "BRELA-99812",
      securityLicenseNumber: "PSRA-TZ-2026-01",
      contactPhone: "0788112233",
      galleryBase64: [],
      verificationStatus: "VERIFIED",
      verifiedBadge: true,
      featured: false,
      revenueModel: "COMMISSION",
      subscriptionStatus: "INACTIVE",
      ratingAvg: 0,
      ratingCount: 0,
      completedOrdersCount: 0,
      totalEarningsTzs: 0,
      commissionOwedTzs: 0,
      commissionCollectedTzs: 0,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Valid PENDING create succeeds
  await assertSucceeds(
    providerDb.collection("providers").doc("prov_1").set({
      ownerId: PROVIDER_UID,
      companyName: "Simba Guard Ltd",
      description: "Professional armed and unarmed security guards across Dar es Salaam.",
      categories: ["SECURITY_GUARDS"],
      locations: ["Dar es Salaam", "Arusha"],
      startingPriceTzs: 350000,
      businessRegNumber: "BRELA-99812",
      securityLicenseNumber: "PSRA-TZ-2026-01",
      contactPhone: "0788112233",
      galleryBase64: [],
      verificationStatus: "PENDING",
      verifiedBadge: false,
      featured: false,
      revenueModel: "COMMISSION",
      subscriptionStatus: "INACTIVE",
      ratingAvg: 0,
      ratingCount: 0,
      completedOrdersCount: 0,
      totalEarningsTzs: 0,
      commissionOwedTzs: 0,
      commissionCollectedTzs: 0,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Provider cannot self-grant verifiedBadge
  await assertFails(
    providerDb.collection("providers").doc("prov_1").update({
      verifiedBadge: true,
      verificationStatus: "VERIFIED",
      updatedAt: pastTime(),
    })
  );

  // Admin can verify provider
  await assertSucceeds(
    adminDb.collection("providers").doc("prov_1").update({
      verifiedBadge: true,
      verificationStatus: "VERIFIED",
      featured: true,
      updatedAt: pastTime(),
    })
  );
});

test("Orders lifecycle, chat messages, and query alignment", async () => {
  const customerDb = testEnv.authenticatedContext(CUSTOMER_UID).firestore();
  const providerDb = testEnv.authenticatedContext(PROVIDER_UID).firestore();
  const otherDb = testEnv.authenticatedContext(OTHER_UID).firestore();

  const ts = pastTime();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("providers").doc("prov_1").set({
      ownerId: PROVIDER_UID,
      companyName: "Simba Guard Ltd",
      description: "Professional security guards across Tanzania.",
      categories: ["SECURITY_GUARDS"],
      locations: ["Dar es Salaam"],
      startingPriceTzs: 350000,
      businessRegNumber: "BRELA-99812",
      securityLicenseNumber: "PSRA-01",
      contactPhone: "0788112233",
      galleryBase64: [],
      verificationStatus: "VERIFIED",
      verifiedBadge: true,
      featured: true,
      revenueModel: "COMMISSION",
      subscriptionStatus: "INACTIVE",
      ratingAvg: 4.8,
      ratingCount: 10,
      completedOrdersCount: 10,
      totalEarningsTzs: 3500000,
      commissionOwedTzs: 175000,
      commissionCollectedTzs: 175000,
      createdAt: ts,
      updatedAt: ts,
    });
  });

  // Customer submits request
  await assertSucceeds(
    customerDb.collection("orders").doc("ord_1").set({
      customerId: CUSTOMER_UID,
      customerName: "Asha Juma",
      customerPhone: "0712345678",
      providerId: "prov_1",
      providerOwnerId: PROVIDER_UID,
      providerName: "Simba Guard Ltd",
      serviceCategory: "SECURITY_GUARDS",
      serviceTitle: "24/7 Residential Guard",
      location: "Mikocheni, Dar es Salaam",
      requirementDescription: "Need 2 day/night guards for residential gate.",
      attachmentPreviews: [],
      quotedAmountTzs: 0,
      commissionModel: "COMMISSION",
      commissionRatePercent: 5,
      commissionAmountTzs: 0,
      paymentStatus: "UNPAID",
      status: "REQUESTED",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Scoped queries succeed; unfiltered list fails for non-admin
  await assertSucceeds(customerDb.collection("orders").where("customerId", "==", CUSTOMER_UID).get());
  await assertSucceeds(providerDb.collection("orders").where("providerOwnerId", "==", PROVIDER_UID).get());
  await assertFails(customerDb.collection("orders").get());
  await assertFails(otherDb.collection("orders").doc("ord_1").get());

  // Provider cannot mark SERVICE_DELIVERED before payment is VERIFIED
  await assertFails(
    providerDb.collection("orders").doc("ord_1").update({
      status: "SERVICE_DELIVERED",
      updatedAt: pastTime(),
    })
  );

  // Provider submits quotation
  await assertSucceeds(
    providerDb.collection("orders").doc("ord_1").update({
      status: "QUOTATION_SUBMITTED",
      quotedAmountTzs: 400000,
      quotationNotes: "Includes 2 uniformed guards and night patrol radio.",
      updatedAt: pastTime(),
    })
  );

  // Chat message with participantIds works for participants, blocked for stranger
  await assertSucceeds(
    customerDb.collection("orders").doc("ord_1").collection("messages").doc("msg_1").set({
      orderId: "ord_1",
      senderId: CUSTOMER_UID,
      senderName: "Asha Juma",
      participantIds: [CUSTOMER_UID, PROVIDER_UID],
      text: "Habari, mnaanza lini?",
      createdAt: pastTime(),
    })
  );
  await assertSucceeds(
    customerDb.collection("orders").doc("ord_1").collection("messages")
      .where("participantIds", "array-contains", CUSTOMER_UID).get()
  );
  await assertFails(
    otherDb.collection("orders").doc("ord_1").collection("messages").doc("msg_1").get()
  );
  await assertFails(
    otherDb.collection("orders").doc("ord_1").collection("messages").get()
  );
});

test("Payments: enforces admin number 0788016987 and blocks direct VERIFIED creation", async () => {
  const customerDb = testEnv.authenticatedContext(CUSTOMER_UID).firestore();
  const ts = pastTime();

  // Direct VERIFIED creation blocked
  await assertFails(
    customerDb.collection("payments").doc("pay_1").set({
      payerId: CUSTOMER_UID,
      payerName: "Asha Juma",
      payerPhone: "0788123456",
      recipientNumber: "0788016987",
      providerId: "prov_1",
      providerOwnerId: PROVIDER_UID,
      orderId: "ord_1",
      paymentType: "ORDER_PAYMENT",
      amountTzs: 400000,
      commissionTzs: 20000,
      providerNetTzs: 380000,
      transactionRef: "SJS-AM-1001",
      receiptNumber: "RCT-1001",
      status: "VERIFIED",
      mode: "SANDBOX",
      gatewayMessage: "Forged",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Wrong recipient number blocked
  await assertFails(
    customerDb.collection("payments").doc("pay_1").set({
      payerId: CUSTOMER_UID,
      payerName: "Asha Juma",
      payerPhone: "0788123456",
      recipientNumber: "0799999999",
      providerId: "prov_1",
      providerOwnerId: PROVIDER_UID,
      orderId: "ord_1",
      paymentType: "ORDER_PAYMENT",
      amountTzs: 400000,
      commissionTzs: 20000,
      providerNetTzs: 380000,
      transactionRef: "SJS-AM-1001",
      receiptNumber: "RCT-1001",
      status: "PENDING_CALLBACK",
      mode: "SANDBOX",
      gatewayMessage: "Awaiting Airtel Money callback",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Valid PENDING_CALLBACK creation succeeds
  await assertSucceeds(
    customerDb.collection("payments").doc("pay_1").set({
      payerId: CUSTOMER_UID,
      payerName: "Asha Juma",
      payerPhone: "0788123456",
      recipientNumber: "0788016987",
      providerId: "prov_1",
      providerOwnerId: PROVIDER_UID,
      orderId: "ord_1",
      paymentType: "ORDER_PAYMENT",
      amountTzs: 400000,
      commissionTzs: 20000,
      providerNetTzs: 380000,
      transactionRef: "SJS-AM-1001",
      receiptNumber: "RCT-1001",
      status: "PENDING_CALLBACK",
      mode: "SANDBOX",
      gatewayMessage: "SANDBOX: Initiated to 0788016987",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Reject future timestamp
  await assertFails(
    customerDb.collection("payments").doc("pay_future").set({
      payerId: CUSTOMER_UID,
      payerName: "Asha Juma",
      payerPhone: "0788123456",
      recipientNumber: "0788016987",
      providerId: "prov_1",
      providerOwnerId: PROVIDER_UID,
      orderId: "ord_1",
      paymentType: "ORDER_PAYMENT",
      amountTzs: 400000,
      commissionTzs: 20000,
      providerNetTzs: 380000,
      transactionRef: "SJS-AM-1002",
      receiptNumber: "RCT-1002",
      status: "PENDING_CALLBACK",
      mode: "SANDBOX",
      gatewayMessage: "SANDBOX",
      createdAt: futureTime(),
      updatedAt: futureTime(),
    })
  );
});
