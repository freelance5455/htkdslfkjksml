const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ADMIN_UID = "admin_mia_001";
const ADMIN_EMAIL = "mia85478667@gmail.com";
const ALICE_UID = "alice_123";
const ALICE_EMAIL = "alice@example.com";
const BOB_UID = "bob_456";
const BOB_EMAIL = "bob@example.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function tsNow() {
  return new Date(Date.now() - 1000);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function adminCtx(env) {
  return env.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  });
}

function userCtx(env, uid, email) {
  return env.authenticatedContext(uid, {
    email,
    email_verified: true,
  });
}

async function seedUser(uid, email, displayName, credits = 10, role = "user") {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection("users").doc(uid).set({
      uid,
      email,
      displayName,
      role,
      credits,
      createdAt: new Date(Date.now() - 5000),
      updatedAt: new Date(Date.now() - 5000),
    });
  });
}

test("Unauthenticated user: cannot read users or credit_transactions", async () => {
  await seedUser(ALICE_UID, ALICE_EMAIL, "Alice", 10, "user");
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").get());
  await assertFails(unauthDb.collection("credit_transactions").get());
});

test("Regular user: can create own initial account with 10 credits and user role", async () => {
  const aliceDb = userCtx(testEnv, ALICE_UID, ALICE_EMAIL).firestore();
  const now = tsNow();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: ALICE_EMAIL,
      displayName: "Alice",
      role: "user",
      credits: 10,
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Regular user: cannot self-assign admin role or mint extra credits on create", async () => {
  const aliceDb = userCtx(testEnv, ALICE_UID, ALICE_EMAIL).firestore();
  const now = tsNow();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: ALICE_EMAIL,
      displayName: "Alice",
      role: "admin",
      credits: 10,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: ALICE_EMAIL,
      displayName: "Alice",
      role: "user",
      credits: 500,
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Regular user: cannot increase own credits or add credits to another user", async () => {
  await seedUser(ALICE_UID, ALICE_EMAIL, "Alice", 10, "user");
  await seedUser(BOB_UID, BOB_EMAIL, "Bob", 10, "user");

  const aliceDb = userCtx(testEnv, ALICE_UID, ALICE_EMAIL).firestore();

  // Self credit increase blocked
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      credits: 1000,
      updatedAt: tsNow(),
    })
  );

  // Cross-user read & write blocked (PII isolation)
  await assertFails(aliceDb.collection("users").doc(BOB_UID).get());
  await assertFails(aliceDb.collection("users").get());
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).update({
      credits: 100,
      updatedAt: tsNow(),
    })
  );
});

test("Email spoofing: unverified email matching admin is rejected", async () => {
  await seedUser(BOB_UID, BOB_EMAIL, "Bob", 10, "user");
  const spoofDb = testEnv.authenticatedContext("spoof_999", {
    email: ADMIN_EMAIL,
    email_verified: false,
  }).firestore();

  await assertFails(spoofDb.collection("users").get());
  await assertFails(
    spoofDb.collection("users").doc(BOB_UID).update({
      credits: 999,
      updatedAt: tsNow(),
    })
  );
});

test("Shadow update test: ghost fields are rejected even for admin", async () => {
  await seedUser(BOB_UID, BOB_EMAIL, "Bob", 10, "user");
  const aDb = adminCtx(testEnv).firestore();

  await assertFails(
    aDb.collection("users").doc(BOB_UID).update({
      credits: 50,
      ghostFlag: true,
      updatedAt: tsNow(),
    })
  );
});

test("Admin: can list all accounts and add credits to own account and others + write audit log", async () => {
  await seedUser(ADMIN_UID, ADMIN_EMAIL, "Mia Admin", 10, "admin");
  await seedUser(BOB_UID, BOB_EMAIL, "Bob", 10, "user");

  const aDb = adminCtx(testEnv).firestore();

  // List all users
  await assertSucceeds(aDb.collection("users").get());

  // Add credits to own account
  await assertSucceeds(
    aDb.collection("users").doc(ADMIN_UID).update({
      credits: 110,
      updatedAt: tsNow(),
    })
  );
  await assertSucceeds(
    aDb.collection("credit_transactions").doc("tx_self_1").set({
      targetUid: ADMIN_UID,
      targetEmail: ADMIN_EMAIL,
      adminUid: ADMIN_UID,
      adminEmail: ADMIN_EMAIL,
      type: "admin_grant",
      amount: 100,
      balanceAfter: 110,
      reason: "Admin self top-up",
      createdAt: tsNow(),
    })
  );

  // Add credits to Bob's account
  await assertSucceeds(
    aDb.collection("users").doc(BOB_UID).update({
      credits: 60,
      updatedAt: tsNow(),
    })
  );
  await assertSucceeds(
    aDb.collection("credit_transactions").doc("tx_bob_1").set({
      targetUid: BOB_UID,
      targetEmail: BOB_EMAIL,
      adminUid: ADMIN_UID,
      adminEmail: ADMIN_EMAIL,
      type: "admin_grant",
      amount: 50,
      balanceAfter: 60,
      reason: "Bonus credits for Bob",
      createdAt: tsNow(),
    })
  );

  // Ledger is immutable
  await assertFails(
    aDb.collection("credit_transactions").doc("tx_bob_1").update({ amount: 999 })
  );
  await assertFails(aDb.collection("credit_transactions").doc("tx_bob_1").delete());
});

test("Regular user: can spend (decrement) own credits and query own transactions", async () => {
  await seedUser(ALICE_UID, ALICE_EMAIL, "Alice", 10, "user");
  const aliceDb = userCtx(testEnv, ALICE_UID, ALICE_EMAIL).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      credits: 9,
      updatedAt: tsNow(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("credit_transactions").doc("tx_usage_1").set({
      targetUid: ALICE_UID,
      targetEmail: ALICE_EMAIL,
      adminUid: ALICE_UID,
      adminEmail: ALICE_EMAIL,
      type: "ai_usage",
      amount: -1,
      balanceAfter: 9,
      reason: "AI Background Remover",
      createdAt: tsNow(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("credit_transactions").where("targetUid", "==", ALICE_UID).get()
  );
});
