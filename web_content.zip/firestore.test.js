const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_UID = "admin_modesty";
const ADMIN_EMAIL = "orjimodesty@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) await testEnv.cleanup();
});

beforeEach(async () => {
  if (testEnv) await testEnv.clearFirestore();
});

function pastDate(msOffset = 2000) {
  return new Date(Date.now() - msOffset);
}

function futureDate(msOffset = 3600000) {
  return new Date(Date.now() + msOffset);
}

test("Unauthenticated users cannot read or write any collection", async () => {
  const db = testEnv.unauthenticatedContext().firestore();
  await assertFails(db.collection("auctions").get());
  await assertFails(db.collection("users").doc(ALICE_UID).get());
  await assertFails(db.collection("wallets").doc(ALICE_UID).get());
});

test("User registration, bidder counter, PII isolation, and role escalation guard", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const now = pastDate();

  // Counter starts at 1002
  await assertSucceeds(
    aliceDb.collection("counters").doc("bidder_seq").set({
      nextNumber: 1002,
      updatedAt: now,
    })
  );

  // Reject jumping counter by +5
  await assertFails(
    bobDb.collection("counters").doc("bidder_seq").update({
      nextNumber: 1007,
      updatedAt: pastDate(1000),
    })
  );

  // Reject self-assigning ADMIN role
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      email: "alice@example.com",
      bidderNumber: "TA-1001",
      accountStatus: "ACTIVE",
      role: "ADMIN",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Valid user registration
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Adeyemi",
      email: "alice@example.com",
      phone: "+2348012345678",
      bidderNumber: "TA-1001",
      bankName: "GTBank",
      accountNumber: "0123456789",
      accountName: "Alice Adeyemi",
      accountStatus: "ACTIVE",
      role: "USER",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Cross-user PII read and list must fail
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").get());

  // User cannot mutate immutable bidderNumber or role
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      bidderNumber: "TA-9999",
      updatedAt: pastDate(500),
    })
  );

  // Valid profile update
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      bankName: "Zenith Bank",
      updatedAt: pastDate(500),
    })
  );
});

test("Auction creation, atomic live bidding, and seller self-bid guard", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = pastDate(5000);

  // Alice lists an auction
  await assertSucceeds(
    aliceDb.collection("auctions").doc("auc_1").set({
      sellerId: ALICE_UID,
      sellerName: "Alice Adeyemi",
      sellerBidderNumber: "TA-1001",
      title: "Vintage Chronograph Watch",
      description: "Mint condition mechanical watch with original box.",
      category: "Watches",
      imageItems: ["preset:chronograph"],
      startingBid: 100000,
      minIncrement: 5000,
      currentBid: 0,
      bidCount: 0,
      highestBidderId: "",
      highestBidderNumber: "",
      featured: false,
      featuredFeePaid: 0,
      commissionRate: 3,
      commissionAmount: 0,
      sellerPayout: 0,
      status: "ACTIVE",
      endsAt: futureDate(),
      createdAt: now,
      updatedAt: now,
    })
  );

  // Seller cannot bid on own auction
  await assertFails(
    aliceDb.collection("auctions").doc("auc_1").update({
      currentBid: 100000,
      bidCount: 1,
      highestBidderId: ALICE_UID,
      highestBidderNumber: "TA-1001",
      updatedAt: pastDate(1000),
    })
  );

  // Standalone bid without updating auction doc fails
  await assertFails(
    bobDb.collection("auctions").doc("auc_1").collection("bids").doc("bid_fake").set({
      auctionId: "auc_1",
      bidderId: BOB_UID,
      bidderNumber: "TA-1002",
      amount: 120000,
      createdAt: pastDate(1000),
    })
  );

  // Atomic batch bid by Bob succeeds
  const batch = bobDb.batch();
  batch.update(bobDb.collection("auctions").doc("auc_1"), {
    currentBid: 100000,
    bidCount: 1,
    highestBidderId: BOB_UID,
    highestBidderNumber: "TA-1002",
    updatedAt: pastDate(1000),
  });
  batch.set(bobDb.collection("auctions").doc("auc_1").collection("bids").doc("bid_1"), {
    auctionId: "auc_1",
    bidderId: BOB_UID,
    bidderNumber: "TA-1002",
    amount: 100000,
    createdAt: pastDate(1000),
  });
  await assertSucceeds(batch.commit());
});

test("Wallet deposit, 3% commission auction settlement, and withdrawal workflow", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, { email: ADMIN_EMAIL, email_verified: true }).firestore();
  const now = pastDate(10000);

  // Create wallets
  await assertSucceeds(
    aliceDb.collection("wallets").doc(ALICE_UID).set({
      userId: ALICE_UID,
      availableBalance: 0,
      pendingWithdrawal: 0,
      totalDeposited: 0,
      totalEarned: 0,
      totalCommissionPaid: 0,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    bobDb.collection("wallets").doc(BOB_UID).set({
      userId: BOB_UID,
      availableBalance: 0,
      pendingWithdrawal: 0,
      totalDeposited: 0,
      totalEarned: 0,
      totalCommissionPaid: 0,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob deposits ₦600,000
  await assertSucceeds(
    bobDb.collection("wallets").doc(BOB_UID).update({
      availableBalance: 600000,
      totalDeposited: 600000,
      updatedAt: pastDate(5000),
    })
  );

  // Seed active auction with Bob winning at ₦500,000
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("auctions").doc("auc_settle").set({
      sellerId: ALICE_UID,
      sellerName: "Alice Adeyemi",
      sellerBidderNumber: "TA-1001",
      title: "Emerald Bronze Vase",
      description: "Handcrafted sculpture",
      category: "Art",
      imageItems: ["preset:sculpture"],
      startingBid: 200000,
      minIncrement: 10000,
      currentBid: 500000,
      bidCount: 3,
      highestBidderId: BOB_UID,
      highestBidderNumber: "TA-1002",
      featured: false,
      featuredFeePaid: 0,
      commissionRate: 3,
      commissionAmount: 0,
      sellerPayout: 0,
      status: "ENDED",
      endsAt: pastDate(3000),
      createdAt: now,
      updatedAt: now,
    });
  });

  // Bob settles won auction: 3% of ₦500,000 = ₦15,000 commission, ₦485,000 seller payout
  const settleBatch = bobDb.batch();
  settleBatch.update(bobDb.collection("auctions").doc("auc_settle"), {
    status: "SETTLED",
    commissionAmount: 15000,
    sellerPayout: 485000,
    settledAt: pastDate(1000),
    updatedAt: pastDate(1000),
  });
  settleBatch.update(bobDb.collection("wallets").doc(BOB_UID), {
    availableBalance: 100000,
    lastSettledAuctionId: "auc_settle",
    updatedAt: pastDate(1000),
  });
  settleBatch.update(bobDb.collection("wallets").doc(ALICE_UID), {
    availableBalance: 485000,
    totalEarned: 485000,
    totalCommissionPaid: 15000,
    lastSettledAuctionId: "auc_settle",
    updatedAt: pastDate(1000),
  });
  settleBatch.set(bobDb.collection("wallet_transactions").doc("tx_buyer"), {
    userId: BOB_UID,
    counterpartyId: ALICE_UID,
    auctionId: "auc_settle",
    type: "AUCTION_PAYMENT",
    amount: 500000,
    feeAmount: 0,
    description: "Payment for Emerald Bronze Vase",
    status: "COMPLETED",
    referenceCode: "TA-PAY-001",
    createdAt: pastDate(1000),
  });
  settleBatch.set(bobDb.collection("wallet_transactions").doc("tx_seller"), {
    userId: ALICE_UID,
    counterpartyId: BOB_UID,
    auctionId: "auc_settle",
    type: "SELLER_PAYOUT",
    amount: 485000,
    feeAmount: 15000,
    description: "Payout for Emerald Bronze Vase (3% fee: ₦15,000)",
    status: "COMPLETED",
    referenceCode: "TA-SET-001",
    createdAt: pastDate(1000),
  });
  await assertSucceeds(settleBatch.commit());

  // Bob cannot read Alice's wallet transactions
  await assertFails(bobDb.collection("wallet_transactions").where("userId", "==", ALICE_UID).get());
  await assertSucceeds(aliceDb.collection("wallet_transactions").where("userId", "==", ALICE_UID).get());

  // Alice requests withdrawal of ₦200,000
  const wdBatch = aliceDb.batch();
  wdBatch.update(aliceDb.collection("wallets").doc(ALICE_UID), {
    availableBalance: 285000,
    pendingWithdrawal: 200000,
    updatedAt: pastDate(500),
  });
  wdBatch.set(aliceDb.collection("withdrawals").doc("wd_1"), {
    userId: ALICE_UID,
    userDisplayName: "Alice Adeyemi",
    bidderNumber: "TA-1001",
    amount: 200000,
    bankName: "GTBank",
    accountNumber: "0123456789",
    accountName: "Alice Adeyemi",
    status: "PENDING",
    createdAt: pastDate(500),
    updatedAt: pastDate(500),
  });
  await assertSucceeds(wdBatch.commit());

  // Non-admin cannot approve withdrawal
  await assertFails(
    aliceDb.collection("withdrawals").doc("wd_1").update({
      status: "APPROVED",
      updatedAt: pastDate(200),
    })
  );

  // Spoofed unverified admin email cannot approve
  const spoofAdminDb = testEnv.authenticatedContext("spoof", { email: ADMIN_EMAIL, email_verified: false }).firestore();
  await assertFails(
    spoofAdminDb.collection("withdrawals").doc("wd_1").update({
      status: "APPROVED",
      updatedAt: pastDate(200),
    })
  );

  // Verified bootstrapped admin approves withdrawal
  await assertSucceeds(
    adminDb.collection("withdrawals").doc("wd_1").update({
      status: "APPROVED",
      adminNote: "Disbursed via NIP",
      updatedAt: pastDate(200),
    })
  );
});

test("Business ads admin-only control and ad inquiries isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, { email: ADMIN_EMAIL, email_verified: true }).firestore();
  const now = pastDate(2000);

  // Non-admin cannot create business ad
  await assertFails(
    aliceDb.collection("business_ads").doc("ad_1").set({
      businessName: "Lagos Vault",
      tagline: "Insured armored logistics",
      ctaLabel: "Book Courier",
      category: "Logistics",
      negotiatedFee: 50000,
      status: "ACTIVE",
      createdBy: ALICE_UID,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Admin creates negotiated business ad
  await assertSucceeds(
    adminDb.collection("business_ads").doc("ad_1").set({
      businessName: "Lagos Vault",
      tagline: "Insured armored logistics for luxury lots",
      ctaLabel: "Book Courier",
      category: "Logistics",
      negotiatedFee: 75000,
      status: "ACTIVE",
      createdBy: ADMIN_UID,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice submits ad inquiry
  await assertSucceeds(
    aliceDb.collection("ad_inquiries").doc("inq_1").set({
      userId: ALICE_UID,
      businessName: "Eko Horology",
      proposedBudget: 40000,
      message: "Interested in banner slot for luxury watch fair.",
      status: "PENDING",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob cannot read Alice's ad inquiry
  await assertFails(bobDb.collection("ad_inquiries").doc("inq_1").get());
  await assertSucceeds(aliceDb.collection("ad_inquiries").where("userId", "==", ALICE_UID).get());
  await assertSucceeds(adminDb.collection("ad_inquiries").get());
});
