const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_UID = "admin_999";
const ADMIN_EMAIL = "tahidullaskar10@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

// --- SECURITY BOUNDS TESTS ---

test("Unauthenticated user: cannot read users", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").get());
});

test("Authenticated user: can create their own profile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      displayName: "Alice",
      email: "alice@example.com",
      coins: 50,
      gems: 5,
      dailyCoins: 0,
      weeklyCoins: 0,
      isBlocked: false,
    })
  );
});

test("Authenticated user: cannot create profile for another user", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).set({
      uid: BOB_UID,
      displayName: "Bob",
      email: "bob@example.com",
      coins: 50,
      gems: 5,
      dailyCoins: 0,
      weeklyCoins: 0,
      isBlocked: false,
    })
  );
});

test("Authenticated user: can submit withdrawal with PENDING status", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("withdrawals").doc("w_1").set({
      userId: ALICE_UID,
      userName: "Alice",
      userEmail: "alice@example.com",
      methodId: "upi_1",
      methodTitle: "UPI Transfer",
      accountDetail: "alice@upi",
      coinsDeducted: 100,
      cashAmount: "₹10",
      status: "PENDING",
    })
  );
});

test("Non-admin user: cannot create tasks", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("tasks").doc("task_1").set({
      title: "Play Video",
      description: "Watch a rewarded video",
      rewardCoins: 20,
      category: "VIDEO",
      actionUrl: "https://example.com",
      isEnabled: true,
    })
  );
});

test("Admin user: can create tasks", async () => {
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, { email: ADMIN_EMAIL }).firestore();
  await assertSucceeds(
    adminDb.collection("tasks").doc("task_1").set({
      title: "Play Video",
      description: "Watch a rewarded video",
      rewardCoins: 20,
      category: "VIDEO",
      actionUrl: "https://example.com",
      isEnabled: true,
    })
  );
});

test("Admin user: can update withdrawal status to APPROVED", async () => {
  // Seed withdrawal as Alice
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("withdrawals").doc("w_1").set({
      userId: ALICE_UID,
      userName: "Alice",
      userEmail: "alice@example.com",
      methodId: "upi_1",
      methodTitle: "UPI Transfer",
      accountDetail: "alice@upi",
      coinsDeducted: 100,
      cashAmount: "₹10",
      status: "PENDING",
    });
  });

  const adminDb = testEnv.authenticatedContext(ADMIN_UID, { email: ADMIN_EMAIL }).firestore();
  await assertSucceeds(
    adminDb.collection("withdrawals").doc("w_1").update({
      status: "APPROVED",
    })
  );
});
