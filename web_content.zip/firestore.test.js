const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_seeker";
const BOB_UID = "bob_employer";
const CHARLIE_UID = "charlie_other";
const ADMIN_UID = "admin_user";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

const pastTs = () => new Date(Date.now() - 5000);

function validJobPayload(employerId, overrides = {}) {
  return {
    employerId,
    companyName: "Bharat Logistics Pvt Ltd",
    companyVerified: false,
    title: "Warehouse Operations Associate",
    category: "Delivery & Logistics",
    jobType: "FULL_TIME",
    state: "Maharashtra",
    city: "Pune",
    pincode: "411001",
    isRemote: false,
    salaryMinInr: 18000,
    salaryMaxInr: 25000,
    salaryPeriod: "MONTH",
    experienceLevel: "FRESHER",
    description: "Manage inventory sorting and dispatch operations at Pune hub.",
    requirements: "Basic smartphone operation and local Hindi/Marathi.",
    minAge: 18,
    isHazardousOrRestricted: false,
    applicationFee: 0,
    moderationStatus: "PENDING",
    isActive: true,
    applicantCount: 0,
    createdAt: pastTs(),
    updatedAt: pastTs(),
    ...overrides,
  };
}

function validQuestPayload(employerId, overrides = {}) {
  return {
    employerId,
    posterName: "KiranaConnect India",
    title: "Storefront Photo & PIN Verification",
    category: "Field Audit",
    description: "Verify 5 neighborhood retail stores in Indiranagar and capture shelf availability.",
    deliverableSpec: "5 timestamped notes & PIN confirmation",
    payoutInr: 450,
    estimatedMinutes: 45,
    city: "Bengaluru",
    state: "Karnataka",
    isRemote: false,
    minAge: 18,
    isHazardousOrRestricted: false,
    applicationFee: 0,
    moderationStatus: "PENDING",
    questStatus: "OPEN",
    createdAt: pastTs(),
    updatedAt: pastTs(),
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await ctx.firestore().collection("admins").doc(ADMIN_UID).set({
        adminId: ADMIN_UID,
        email: "admin@joby.in",
        createdAt: pastTs(),
      });
    });
  }
});

test("Unauthenticated users cannot read users, jobs, or side_quests", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("users").get());
  await assertFails(unauth.collection("jobs").where("moderationStatus", "==", "APPROVED").get());
  await assertFails(unauth.collection("side_quests").where("moderationStatus", "==", "APPROVED").get());
  await assertFails(unauth.collection("applications").get());
});

test("User PII isolation and self-privilege escalation prevention", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Aarav Sharma",
      email: "aarav@example.com",
      role: "SEEKER",
      age: 22,
      accountStatus: "ACTIVE",
      companyVerified: false,
      subscriptionTier: "FREE",
      createdAt: pastTs(),
      updatedAt: pastTs(),
    })
  );

  // Bob cannot read Alice's private user document
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());

  // Alice cannot self-verify company or suspend herself
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      companyVerified: true,
      updatedAt: pastTs(),
    })
  );
});

test("Zero-fee mandate and moderation gate on Jobs", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();

  // Reject non-zero application fee
  await assertFails(
    bobDb.collection("jobs").doc("job_fee").set(validJobPayload(BOB_UID, { applicationFee: 199 }))
  );

  // Reject hazardous job with minAge < 18
  await assertFails(
    bobDb.collection("jobs").doc("job_hazard").set(
      validJobPayload(BOB_UID, { isHazardousOrRestricted: true, minAge: 16 })
    )
  );

  // Reject employer self-approving job
  await assertFails(
    bobDb.collection("jobs").doc("job_self_approve").set(
      validJobPayload(BOB_UID, { moderationStatus: "APPROVED" })
    )
  );

  // Valid PENDING job creation succeeds
  await assertSucceeds(
    bobDb.collection("jobs").doc("job_valid").set(validJobPayload(BOB_UID))
  );

  // Seeker cannot read unapproved PENDING job directly
  await assertFails(aliceDb.collection("jobs").doc("job_valid").get());

  // Admin approves job
  await assertSucceeds(
    adminDb.collection("jobs").doc("job_valid").update({
      moderationStatus: "APPROVED",
      updatedAt: pastTs(),
    })
  );

  // Seeker can query APPROVED jobs
  await assertSucceeds(
    aliceDb.collection("jobs").where("moderationStatus", "==", "APPROVED").get()
  );
});

test("Age verification enforced on Job Applications", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("jobs").doc("job_18plus").set(
      validJobPayload(BOB_UID, { moderationStatus: "APPROVED", minAge: 18 })
    );
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();

  // Under-18 applicant blocked by rules
  await assertFails(
    aliceDb.collection("applications").doc("app_minor").set({
      seekerId: ALICE_UID,
      seekerName: "Rohan Teen",
      seekerAge: 16,
      seekerCity: "Pune",
      seekerSkills: ["Delivery"],
      seekerBio: "Student",
      resumeLabel: "resume.pdf",
      jobId: "job_18plus",
      jobTitle: "Warehouse Operations Associate",
      companyName: "Bharat Logistics Pvt Ltd",
      employerId: BOB_UID,
      coverNote: "Interested",
      status: "APPLIED",
      createdAt: pastTs(),
      updatedAt: pastTs(),
    })
  );

  // Adult applicant succeeds
  await assertSucceeds(
    aliceDb.collection("applications").doc("app_adult").set({
      seekerId: ALICE_UID,
      seekerName: "Aarav Sharma",
      seekerAge: 22,
      seekerCity: "Pune",
      seekerSkills: ["Inventory"],
      seekerBio: "2 years warehouse experience",
      resumeLabel: "aarav_cv.pdf",
      jobId: "job_18plus",
      jobTitle: "Warehouse Operations Associate",
      companyName: "Bharat Logistics Pvt Ltd",
      employerId: BOB_UID,
      coverNote: "Ready to join immediately",
      status: "APPLIED",
      createdAt: pastTs(),
      updatedAt: pastTs(),
    })
  );
});

test("Side Quest full lifecycle and terminal state locking", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("side_quests").doc("sq_1").set(
      validQuestPayload(BOB_UID, { moderationStatus: "APPROVED" })
    );
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Seeker claims quest
  await assertSucceeds(
    aliceDb.collection("side_quests").doc("sq_1").update({
      questStatus: "ASSIGNED",
      assignedSeekerId: ALICE_UID,
      assignedSeekerName: "Aarav",
      updatedAt: pastTs(),
    })
  );

  // Seeker submits completion proof
  await assertSucceeds(
    aliceDb.collection("side_quests").doc("sq_1").update({
      questStatus: "COMPLETION_SUBMITTED",
      proofNote: "Completed all 5 store checks",
      updatedAt: pastTs(),
    })
  );

  // Employer verifies and marks PAID
  await assertSucceeds(
    bobDb.collection("side_quests").doc("sq_1").update({
      questStatus: "PAID",
      paymentReference: "UPI-REF-998877",
      updatedAt: pastTs(),
    })
  );

  // Terminal state: Employer cannot reopen a PAID quest
  await assertFails(
    bobDb.collection("side_quests").doc("sq_1").update({
      questStatus: "CANCELLED",
      updatedAt: pastTs(),
    })
  );
});

test("Conversation and Message participant isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("conversations").doc("conv_1").set({
      participantIds: [ALICE_UID, BOB_UID],
      seekerId: ALICE_UID,
      employerId: BOB_UID,
      seekerName: "Aarav",
      employerName: "Bharat Logistics",
      jobTitle: "Warehouse Operations Associate",
      lastMessage: "Hello",
      lastMessageAt: pastTs(),
      createdAt: pastTs(),
      updatedAt: pastTs(),
    })
  );

  await assertFails(charlieDb.collection("conversations").doc("conv_1").get());
  await assertFails(
    charlieDb.collection("conversations").doc("conv_1").collection("messages").doc("m1").set({
      participantIds: [ALICE_UID, BOB_UID],
      senderId: CHARLIE_UID,
      senderName: "Charlie",
      text: "Intruder",
      isRead: false,
      createdAt: pastTs(),
    })
  );
});

test("Subscription plans editable only by Admin", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();

  await assertFails(
    bobDb.collection("subscription_plans").doc("JOBY_PLUS").set({
      code: "JOBY_PLUS",
      name: "JOBY Plus",
      priceInr: 1,
      billingCycle: "MONTHLY",
      maxActiveJobs: 20,
      featuredBoosts: 5,
      verifiedBadge: true,
      isActive: true,
      updatedAt: pastTs(),
    })
  );

  await assertSucceeds(
    adminDb.collection("subscription_plans").doc("JOBY_PLUS").set({
      code: "JOBY_PLUS",
      name: "JOBY Plus",
      priceInr: 999,
      billingCycle: "MONTHLY",
      maxActiveJobs: 20,
      featuredBoosts: 5,
      verifiedBadge: true,
      isActive: true,
      updatedAt: pastTs(),
    })
  );
});
