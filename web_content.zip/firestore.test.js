const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-merkop-bcc80574-c602-4453-860e-d8b87204133b";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validTimestamp() {
  return new Date(Date.now() - 1000);
}

function validConversation(uid, overrides = {}) {
  const now = validTimestamp();
  return {
    userId: uid,
    title: "Merkop Sohbeti",
    mode: "general",
    lastMessagePreview: "Merhaba Merkop!",
    messageCount: 1,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validMessage(uid, convId, overrides = {}) {
  return {
    userId: uid,
    conversationId: convId,
    role: "user",
    text: "Merhaba Merkop, nasılsın?",
    hasImage: false,
    createdAt: validTimestamp(),
    ...overrides,
  };
}

test("Unauthenticated user cannot list or create conversations", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore(DATABASE_ID);
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("conversations").get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1").set(validConversation(ALICE_UID))
  );
});

test("Authenticated user can create, list, and update own conversation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const convRef = aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1");

  await assertSucceeds(convRef.set(validConversation(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("conversations").get());
  await assertSucceeds(
    convRef.update({
      title: "Yeni Başlık",
      updatedAt: validTimestamp(),
    })
  );
});

test("Cross-user isolation blocks Bob from reading or writing Alice's conversations", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1").set(validConversation(ALICE_UID))
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("conversations").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1").get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_2").set(validConversation(BOB_UID))
  );
});

test("Rejects shadow fields, invalid mode, and oversized IDs", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_bad").set({
      ...validConversation(ALICE_UID),
      isAdmin: true,
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_bad_mode").set(
      validConversation(ALICE_UID, { mode: "superuser" })
    )
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("bad id with spaces").set(
      validConversation(ALICE_UID)
    )
  );
});

test("Messages require valid parent conversation and are immutable after creation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const msgsCol = aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1").collection("messages");

  // Fails when parent conversation does not exist
  await assertFails(msgsCol.doc("msg_1").set(validMessage(ALICE_UID, "conv_1")));

  // Create parent conversation first
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1").set(validConversation(ALICE_UID))
  );

  // Succeeds once parent exists
  await assertSucceeds(msgsCol.doc("msg_1").set(validMessage(ALICE_UID, "conv_1")));
  await assertSucceeds(msgsCol.get());

  // Updates to messages are blocked
  await assertFails(msgsCol.doc("msg_1").update({ text: "edited" }));

  // Bob cannot read or write Alice's messages
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1").collection("messages").get()
  );
});
