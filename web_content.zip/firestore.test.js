const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validBookPayload(userId = ALICE_UID, overrides = {}) {
  const now = new Date();
  return {
    userId,
    title: "Kayıp Zamanın İzinde",
    subtitle: "Bir Kütüphane Gizemi",
    synopsis: "Eski bir İstanbul kütüphanesinde bulunan el yazmasının sırrı.",
    genre: "Roman",
    tone: "Edebi ve Derin",
    creationMethod: "ai",
    coverTheme: "crimson",
    chapterCount: 3,
    totalWordCount: 1250,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validChapterPayload(userId = ALICE_UID, bookId = "book_1", overrides = {}) {
  const now = new Date();
  return {
    userId,
    bookId,
    chapterNumber: 1,
    title: "1. Bölüm: Tozlu Raflar",
    summary: "Kütüphanenin gizli odasının keşfi.",
    content: "Yağmurlu bir kasım akşamıydı...",
    wordCount: 420,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

test("Unauthenticated user cannot read or create books", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("books").get()
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("books")
      .doc("book_1")
      .set(validBookPayload(ALICE_UID))
  );
});

test("Authenticated owner can create, read, update, and delete their own book", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bookRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("books")
    .doc("book_1");

  const payload = validBookPayload(ALICE_UID);
  await assertSucceeds(bookRef.set(payload));
  await assertSucceeds(bookRef.get());
  await assertSucceeds(
    bookRef.update({
      title: "Güncellenmiş Başlık",
      updatedAt: new Date(),
    })
  );
  await assertSucceeds(bookRef.delete());
});

test("Cross-user access is strictly rejected for books and chapters", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db
      .collection("users")
      .doc(ALICE_UID)
      .collection("books")
      .doc("book_1")
      .set(validBookPayload(ALICE_UID));
    await db
      .collection("users")
      .doc(ALICE_UID)
      .collection("books")
      .doc("book_1")
      .collection("chapters")
      .doc("ch_1")
      .set(validChapterPayload(ALICE_UID, "book_1"));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("books")
      .doc("book_1")
      .get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("books")
      .doc("book_1")
      .collection("chapters")
      .doc("ch_1")
      .get()
  );
});

test("Rejects shadow fields, invalid creationMethod enum, and immutable field tampering", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bookRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("books")
    .doc("book_1");

  // Ghost field rejected
  await assertFails(
    bookRef.set(validBookPayload(ALICE_UID, { isVerified: true }))
  );

  // Invalid creationMethod rejected
  await assertFails(
    bookRef.set(validBookPayload(ALICE_UID, { creationMethod: "invalid" }))
  );

  // Valid create then attempt to mutate creationMethod
  await assertSucceeds(bookRef.set(validBookPayload(ALICE_UID)));
  await assertFails(
    bookRef.update({
      creationMethod: "manual",
      updatedAt: new Date(),
    })
  );
});

test("Authenticated owner can create and list up to 240 chapters for their book", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bookRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("books")
    .doc("book_240");
  await assertSucceeds(
    bookRef.set(validBookPayload(ALICE_UID, { chapterCount: 240, totalWordCount: 95000 }))
  );

  const chapterRef = bookRef.collection("chapters").doc("ch_240");
  await assertSucceeds(
    chapterRef.set(validChapterPayload(ALICE_UID, "book_240", { chapterNumber: 240 }))
  );
  await assertSucceeds(
    bookRef
      .collection("chapters")
      .where("userId", "==", ALICE_UID)
      .where("bookId", "==", "book_240")
      .get()
  );
});

