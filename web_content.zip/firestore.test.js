const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const ts = () => new Date(Date.now() - 1000);

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";
const ADMIN_UID = "admin_uid_789";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validUserPayload(uid, username) {
  return {
    userId: uid,
    username,
    displayTag: "SparkPlayer",
    bio: "Ready for ARK",
    avatarPreset: "prism_cyan",
    profileTheme: "obsidian_glass",
    level: 1,
    xp: 0,
    points: 0,
    gamesPlayed: 0,
    challengesCompleted: 0,
    friendsCount: 0,
    groupsCount: 0,
    badges: ["Early Explorer"],
    isPrivateAccount: true,
    allowFriendRequests: "everyone",
    showOnlineStatus: true,
    optOutLeaderboard: false,
    isOnline: true,
    ageBracket: "teen_13_17",
    parentalConsentApproved: true,
    isRestricted: false,
    createdAt: ts(),
    updatedAt: ts(),
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or list users, groups, or gameRooms", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").get());
  await assertFails(unauthDb.collection("groups").get());
  await assertFails(unauthDb.collection("gameRooms").get());
});

test("Authenticated user can create own profile, search by username, and read leaderboard-eligible users", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID, "alice_ark"))
  );
  await assertSucceeds(
    bobDb.collection("users").where("username", "==", "alice_ark").get()
  );
  await assertSucceeds(
    aliceDb.collection("users").where("optOutLeaderboard", "==", false).get()
  );
});

test("Score manipulation attack (>250 points jump) and self-restriction bypass fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID, "alice_ark"))
  );
  // Attempt +10000 points exploit
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      points: 10000,
      xp: 10000,
      updatedAt: ts(),
    })
  );
  // Attempt ghost field injection
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isVerifiedAdmin: true,
      updatedAt: ts(),
    })
  );
});

test("PII private settings doc is strictly owner-only", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("settings").set({
      userId: ALICE_UID,
      email: "alice@example.com",
      quietHoursEnabled: false,
      updatedAt: ts(),
    })
  );

  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("private").doc("settings").get()
  );
});

test("Private group enforces membership isolation on get and list", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("groups").doc("grp_secret").set({
      ownerId: ALICE_UID,
      name: "Secret Squad",
      description: "Friends only",
      inviteCode: "ARK999",
      theme: "aurora",
      isPrivate: true,
      allowMediaDownloads: false,
      memberUids: [ALICE_UID],
      adminUids: [ALICE_UID],
      memberCount: 1,
      createdAt: ts(),
      updatedAt: ts(),
    })
  );

  await assertFails(bobDb.collection("groups").doc("grp_secret").get());
  await assertFails(bobDb.collection("groups").get());
  await assertSucceeds(
    aliceDb.collection("groups").where("memberUids", "array-contains", ALICE_UID).get()
  );
});

test("Challenge progress prevents duplicate point claims after completion", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const ref = aliceDb.collection("users").doc(ALICE_UID).collection("challengeProgress").doc("ch_1");
  await assertSucceeds(
    ref.set({
      userId: ALICE_UID,
      challengeId: "ch_1",
      status: "completed",
      reflectionNote: "Encouraged a friend",
      pointsAwarded: 50,
      createdAt: ts(),
      updatedAt: ts(),
    })
  );
  await assertFails(
    ref.update({
      pointsAwarded: 100,
      updatedAt: ts(),
    })
  );
});

test("Email spoofing test: unverified admin email is rejected on reports moderation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("reports").doc("rep_1").set({
      reporterId: ALICE_UID,
      targetType: "message",
      targetId: "msg_1",
      reason: "Spam",
      details: "Test report",
      status: "open",
      createdAt: ts(),
      updatedAt: ts(),
    })
  );

  const spoofedAdminDb = testEnv.authenticatedContext("spoof_uid", {
    email: "qyrotho@gmail.com",
    email_verified: false,
  }).firestore();
  await assertFails(
    spoofedAdminDb.collection("reports").doc("rep_1").update({
      status: "resolved",
      updatedAt: ts(),
    })
  );

  const realAdminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "qyrotho@gmail.com",
    email_verified: true,
  }).firestore();
  await assertSucceeds(
    realAdminDb.collection("reports").doc("rep_1").update({
      status: "resolved",
      reviewedBy: ADMIN_UID,
      updatedAt: ts(),
    })
  );
});

test("Social posts enforce visibility isolation, age/privacy eligibility, and counter integrity", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Alice starts with private-by-default teen profile -> public post rejected!
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID, "alice_feed"))
  );
  const publicPost = {
    authorId: ALICE_UID,
    authorUsername: "alice_feed",
    authorAvatar: "prism_cyan",
    postType: "text",
    category: "Friends",
    caption: "Hello ARK!",
    imageBase64List: [],
    visibility: "public",
    visibleToUids: [ALICE_UID],
    groupIds: [],
    commentsDisabled: false,
    likeCount: 0,
    reactionCounts: {},
    commentCount: 0,
    shareCount: 0,
    createdAt: ts(),
    updatedAt: ts(),
  };
  await assertFails(aliceDb.collection("posts").doc("p_pub_1").set(publicPost));

  // Friends-only post succeeds; Bob (not a friend yet) cannot read or list it
  const friendsPost = { ...publicPost, visibility: "friends" };
  await assertSucceeds(aliceDb.collection("posts").doc("p_fr_1").set(friendsPost));
  await assertFails(bobDb.collection("posts").doc("p_fr_1").get());
  await assertFails(bobDb.collection("posts").get());

  // Make Bob an adult public user and verify public post works + Explore list passes
  const bobPayload = {
    ...validUserPayload(BOB_UID, "bob_feed"),
    isPrivateAccount: false,
    ageBracket: "adult_18_plus",
  };
  await assertSucceeds(bobDb.collection("users").doc(BOB_UID).set(bobPayload));
  await assertSucceeds(
    bobDb.collection("posts").doc("p_bob_pub").set({
      ...publicPost,
      authorId: BOB_UID,
      authorUsername: "bob_feed",
      visibleToUids: [BOB_UID],
    })
  );
  await assertSucceeds(
    aliceDb.collection("posts").where("visibility", "==", "public").get()
  );

  // Alice can react once and increment likeCount by +1, NOT +50
  await assertSucceeds(
    aliceDb.collection("posts").doc("p_bob_pub").collection("reactions").doc(ALICE_UID).set({
      userId: ALICE_UID,
      username: "alice_feed",
      reaction: "fire",
      createdAt: ts(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("posts").doc("p_bob_pub").update({
      likeCount: 1,
      reactionCounts: { fire: 1 },
      updatedAt: ts(),
    })
  );
  await assertFails(
    aliceDb.collection("posts").doc("p_bob_pub").update({
      likeCount: 51,
      reactionCounts: { fire: 51 },
      updatedAt: ts(),
    })
  );
});

test("Comments enforce disabled-comments toggle and owner moderation, and Polls prevent vote tampering", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      ...validUserPayload(ALICE_UID, "alice_poll"),
      isPrivateAccount: false,
      ageBracket: "adult_18_plus",
    })
  );

  await assertSucceeds(
    aliceDb.collection("posts").doc("p_poll_1").set({
      authorId: ALICE_UID,
      authorUsername: "alice_poll",
      authorAvatar: "prism_cyan",
      postType: "poll",
      category: "Gaming",
      caption: "Next squad game?",
      imageBase64List: [],
      visibility: "public",
      visibleToUids: [ALICE_UID],
      groupIds: [],
      commentsDisabled: false,
      likeCount: 0,
      reactionCounts: {},
      commentCount: 0,
      shareCount: 0,
      pollQuestion: "Pick tonight's game",
      pollOptions: ["Mafia", "Quiz Battle"],
      pollVoteCounts: {},
      createdAt: ts(),
      updatedAt: ts(),
    })
  );

  // Bob votes once and cannot change vote
  await assertSucceeds(
    bobDb.collection("posts").doc("p_poll_1").collection("pollVotes").doc(BOB_UID).set({
      userId: BOB_UID,
      optionIndex: 1,
      createdAt: ts(),
    })
  );
  await assertFails(
    bobDb.collection("posts").doc("p_poll_1").collection("pollVotes").doc(BOB_UID).update({
      optionIndex: 0,
    })
  );

  // Bob comments, Alice (post owner) deletes Bob's comment & disables comments
  const commentRef = bobDb.collection("posts").doc("p_poll_1").collection("comments").doc("c_1");
  await assertSucceeds(
    commentRef.set({
      postId: "p_poll_1",
      authorId: BOB_UID,
      authorUsername: "bob",
      authorAvatar: "prism_cyan",
      text: "Quiz Battle FTW!",
      likeCount: 0,
      createdAt: ts(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("posts").doc("p_poll_1").collection("comments").doc("c_1").delete()
  );
  await assertSucceeds(
    aliceDb.collection("posts").doc("p_poll_1").update({
      commentsDisabled: true,
      updatedAt: ts(),
    })
  );
  await assertFails(
    bobDb.collection("posts").doc("p_poll_1").collection("comments").doc("c_2").set({
      postId: "p_poll_1",
      authorId: BOB_UID,
      authorUsername: "bob",
      authorAvatar: "prism_cyan",
      text: "Trying while locked",
      likeCount: 0,
      createdAt: ts(),
    })
  );
});

test("Stories expose viewers strictly to story owner, and bookmarks/drafts remain private", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  const expires = new Date(Date.now() + 24 * 60 * 60 * 1000);
  await assertSucceeds(
    aliceDb.collection("stories").doc("st_1").set({
      authorId: ALICE_UID,
      authorUsername: "alice_st",
      authorAvatar: "prism_cyan",
      mediaType: "image",
      imageBase64: "abc123",
      caption: "Late night study!",
      visibility: "friends",
      visibleToUids: [ALICE_UID, BOB_UID],
      viewerCount: 0,
      createdAt: ts(),
      expiresAt: expires,
    })
  );

  // Bob is in visibleToUids, so Bob can view the story & record his view
  await assertSucceeds(bobDb.collection("stories").doc("st_1").get());
  await assertSucceeds(
    bobDb.collection("stories").doc("st_1").collection("viewers").doc(BOB_UID).set({
      viewerUid: BOB_UID,
      viewerUsername: "bob",
      viewerAvatar: "cyber_violet",
      viewedAt: ts(),
    })
  );

  // ONLY Alice (story owner) can read viewers list; Bob cannot!
  await assertFails(
    bobDb.collection("stories").doc("st_1").collection("viewers").get()
  );
  await assertSucceeds(
    aliceDb.collection("stories").doc("st_1").collection("viewers").get()
  );

  // Owner-only bookmarks & drafts
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("bookmarks").doc("p_1").set({
      userId: ALICE_UID,
      postId: "p_1",
      savedAt: ts(),
    })
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("bookmarks").get()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("drafts").get()
  );
});

test("Friend requests allow send, cancel, reject/re-send, accept, and block enforcement", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID, "alice_fr"))
  );
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).set(validUserPayload(BOB_UID, "bob_fr"))
  );

  const reqId = `${ALICE_UID}_${BOB_UID}`;
  const aliceReqRef = aliceDb.collection("friendRequests").doc(reqId);
  const bobReqRef = bobDb.collection("friendRequests").doc(reqId);

  // Alice sends initial friend request + notification to Bob
  await assertSucceeds(
    aliceReqRef.set({
      fromUid: ALICE_UID,
      fromUsername: "alice_fr",
      fromAvatar: "prism_cyan",
      toUid: BOB_UID,
      toUsername: "bob_fr",
      status: "pending",
      createdAt: ts(),
      updatedAt: ts(),
    })
  );
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).get()
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(BOB_UID).collection("notifications").doc("n_fr_1").set({
      userId: BOB_UID,
      senderId: ALICE_UID,
      senderUsername: "alice_fr",
      type: "friend_request",
      title: "New Friend Request",
      body: "@alice_fr wants to connect on ARK!",
      isRead: false,
      createdAt: ts(),
    })
  );

  // Bob declines; Alice can re-send by updating status back to pending
  await assertSucceeds(bobReqRef.update({ status: "rejected", updatedAt: ts() }));
  await assertSucceeds(
    aliceReqRef.update({
      status: "pending",
      fromUsername: "alice_fr",
      fromAvatar: "prism_cyan",
      toUsername: "bob_fr",
      updatedAt: ts(),
    })
  );

  // Alice cancels; Alice can re-send again
  await assertSucceeds(aliceReqRef.update({ status: "cancelled", updatedAt: ts() }));
  await assertSucceeds(
    aliceReqRef.update({
      status: "pending",
      fromUsername: "alice_fr",
      fromAvatar: "prism_cyan",
      toUsername: "bob_fr",
      updatedAt: ts(),
    })
  );

  // Bob accepts and creates mutual friend edges
  await assertSucceeds(bobReqRef.update({ status: "accepted", updatedAt: ts() }));
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).collection("friends").doc(ALICE_UID).set({
      userId: BOB_UID,
      friendUid: ALICE_UID,
      friendUsername: "alice_fr",
      friendAvatar: "prism_cyan",
      friendLevel: 1,
      createdAt: ts(),
    })
  );
  await assertSucceeds(
    bobDb.collection("users").doc(ALICE_UID).collection("friends").doc(BOB_UID).set({
      userId: ALICE_UID,
      friendUid: BOB_UID,
      friendUsername: "bob_fr",
      friendAvatar: "prism_cyan",
      friendLevel: 1,
      createdAt: ts(),
    })
  );

  // Cannot re-send while already friends
  await assertFails(
    aliceReqRef.update({
      status: "pending",
      fromUsername: "alice_fr",
      fromAvatar: "prism_cyan",
      toUsername: "bob_fr",
      updatedAt: ts(),
    })
  );

  // If Bob blocks Alice, Alice cannot send or re-send requests or notifications to Bob
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).collection("friends").doc(ALICE_UID).delete()
  );
  await assertSucceeds(
    bobDb.collection("users").doc(ALICE_UID).collection("friends").doc(BOB_UID).delete()
  );
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).collection("blocked").doc(ALICE_UID).set({
      userId: BOB_UID,
      blockedUid: ALICE_UID,
      blockedUsername: "alice_fr",
      createdAt: ts(),
    })
  );
  await assertFails(
    aliceReqRef.update({
      status: "pending",
      fromUsername: "alice_fr",
      fromAvatar: "prism_cyan",
      toUsername: "bob_fr",
      updatedAt: ts(),
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("notifications").doc("n_fr_blocked").set({
      userId: BOB_UID,
      senderId: ALICE_UID,
      senderUsername: "alice_fr",
      type: "friend_request",
      title: "New Friend Request",
      body: "@alice_fr wants to connect on ARK!",
      isRead: false,
      createdAt: ts(),
    })
  );
});

test("Followers & Following: public instant follow, private followRequests accept/reject, and count tampering rejection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Alice is public, Bob is private
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      ...validUserPayload(ALICE_UID, "alice_pub"),
      isPrivateAccount: false,
      followersCount: 0,
      followingCount: 0,
    })
  );
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).set({
      ...validUserPayload(BOB_UID, "bob_priv"),
      isPrivateAccount: true,
      followersCount: 0,
      followingCount: 0,
    })
  );

  // Bob follows Alice (public) in an atomic batch updating edges and counts
  const followBatch = bobDb.batch();
  followBatch.set(bobDb.collection("users").doc(ALICE_UID).collection("followers").doc(BOB_UID), {
    userId: ALICE_UID,
    peerUid: BOB_UID,
    peerUsername: "bob_priv",
    peerFullName: "Bob",
    peerAvatar: "prism_cyan",
    createdAt: ts(),
  });
  followBatch.set(bobDb.collection("users").doc(BOB_UID).collection("following").doc(ALICE_UID), {
    userId: BOB_UID,
    peerUid: ALICE_UID,
    peerUsername: "alice_pub",
    peerFullName: "Alice",
    peerAvatar: "prism_cyan",
    createdAt: ts(),
  });
  followBatch.update(bobDb.collection("users").doc(ALICE_UID), { followersCount: 1, updatedAt: ts() });
  followBatch.update(bobDb.collection("users").doc(BOB_UID), { followingCount: 1, updatedAt: ts() });
  await assertSucceeds(followBatch.commit());

  // Bob CANNOT spoof Alice's followersCount without writing a follower edge
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({ followersCount: 99, updatedAt: ts() })
  );

  // Alice CANNOT directly write herself into private Bob's followers without Bob accepting
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("followers").doc(ALICE_UID).set({
      userId: BOB_UID,
      peerUid: ALICE_UID,
      peerUsername: "alice_pub",
      peerAvatar: "prism_cyan",
      createdAt: ts(),
    })
  );

  // Alice sends followRequest to private Bob; Bob accepts atomically
  const reqId = `${ALICE_UID}_${BOB_UID}`;
  await assertSucceeds(
    aliceDb.collection("followRequests").doc(reqId).set({
      fromUid: ALICE_UID,
      fromUsername: "alice_pub",
      fromFullName: "Alice",
      fromAvatar: "prism_cyan",
      toUid: BOB_UID,
      toUsername: "bob_priv",
      status: "pending",
      createdAt: ts(),
      updatedAt: ts(),
    })
  );

  const acceptBatch = bobDb.batch();
  acceptBatch.update(bobDb.collection("followRequests").doc(reqId), { status: "accepted", updatedAt: ts() });
  acceptBatch.set(bobDb.collection("users").doc(BOB_UID).collection("followers").doc(ALICE_UID), {
    userId: BOB_UID,
    peerUid: ALICE_UID,
    peerUsername: "alice_pub",
    peerAvatar: "prism_cyan",
    createdAt: ts(),
  });
  acceptBatch.set(bobDb.collection("users").doc(ALICE_UID).collection("following").doc(BOB_UID), {
    userId: ALICE_UID,
    peerUid: BOB_UID,
    peerUsername: "bob_priv",
    peerAvatar: "prism_cyan",
    createdAt: ts(),
  });
  acceptBatch.update(bobDb.collection("users").doc(BOB_UID), { followersCount: 1, updatedAt: ts() });
  acceptBatch.update(bobDb.collection("users").doc(ALICE_UID), { followingCount: 1, updatedAt: ts() });
  await assertSucceeds(acceptBatch.commit());
});

test("Posts only_me privacy, hashtag fields, tag approval, and own comment editing work securely", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      ...validUserPayload(ALICE_UID, "alice_tag"),
      isPrivateAccount: false,
      ageBracket: "adult_18_plus",
    })
  );
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).set(validUserPayload(BOB_UID, "bob_tag"))
  );

  // Alice creates only_me post -> Bob cannot read
  await assertSucceeds(
    aliceDb.collection("posts").doc("p_onlyme").set({
      authorId: ALICE_UID,
      authorUsername: "alice_tag",
      authorAvatar: "prism_cyan",
      postType: "text",
      category: "Friends",
      caption: "Private diary #notes",
      hashtags: ["notes"],
      imageBase64List: [],
      visibility: "only_me",
      visibleToUids: [ALICE_UID],
      groupIds: [],
      commentsDisabled: false,
      likeCount: 0,
      reactionCounts: {},
      commentCount: 0,
      shareCount: 0,
      createdAt: ts(),
      updatedAt: ts(),
    })
  );
  await assertFails(bobDb.collection("posts").doc("p_onlyme").get());

  // Alice creates public post tagging Bob as pending
  await assertSucceeds(
    aliceDb.collection("posts").doc("p_tagged").set({
      authorId: ALICE_UID,
      authorUsername: "alice_tag",
      authorAvatar: "prism_cyan",
      postType: "photo",
      category: "Photography",
      caption: "Sunset #arkvibes",
      hashtags: ["arkvibes"],
      locationLabel: "Mumbai, India",
      altTexts: ["Evening sky gradient"],
      taggedUids: [BOB_UID],
      approvedTagUids: [],
      pendingTagUids: [BOB_UID],
      imageBase64List: ["imgdata"],
      visibility: "public",
      visibleToUids: [ALICE_UID],
      groupIds: [],
      commentsDisabled: false,
      likeCount: 0,
      reactionCounts: {},
      commentCount: 0,
      shareCount: 0,
      createdAt: ts(),
      updatedAt: ts(),
    })
  );

  // Bob can approve his own tag, NOT edit caption
  await assertSucceeds(
    bobDb.collection("posts").doc("p_tagged").update({
      pendingTagUids: [],
      approvedTagUids: [BOB_UID],
      taggedUids: [BOB_UID],
      updatedAt: ts(),
    })
  );
  await assertFails(
    bobDb.collection("posts").doc("p_tagged").update({ caption: "Hacked", updatedAt: ts() })
  );

  // Bob can comment and edit his own comment, while Alice cannot edit Bob's comment text
  const commentRef = bobDb.collection("posts").doc("p_tagged").collection("comments").doc("c_edit");
  await assertSucceeds(
    commentRef.set({
      postId: "p_tagged",
      authorId: BOB_UID,
      authorUsername: "bob_tag",
      authorAvatar: "prism_cyan",
      text: "Great shot!",
      likeCount: 0,
      isEdited: false,
      createdAt: ts(),
    })
  );
  await assertSucceeds(commentRef.update({ text: "Amazing shot!", isEdited: true }));
  await assertFails(
    aliceDb.collection("posts").doc("p_tagged").collection("comments").doc("c_edit").update({ text: "Tampered", isEdited: true })
  );
});

test("Story hiddenFromUids, reactions, Highlights, and Direct Messages enforce participant privacy", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const thirdDb = testEnv.authenticatedContext("charlie_uid_999").firestore();

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID, "alice_dm")));
  await assertSucceeds(bobDb.collection("users").doc(BOB_UID).set(validUserPayload(BOB_UID, "bob_dm")));

  // Story hiddenFromUids blocks Bob from get
  const expires = new Date(Date.now() + 24 * 60 * 60 * 1000);
  await assertSucceeds(
    aliceDb.collection("stories").doc("st_hidden").set({
      authorId: ALICE_UID,
      authorUsername: "alice_dm",
      authorAvatar: "prism_cyan",
      mediaType: "image",
      imageBase64: "abc",
      caption: "Secret",
      visibility: "friends",
      visibleToUids: [ALICE_UID],
      hiddenFromUids: [BOB_UID],
      viewerCount: 0,
      reactionCounts: {},
      createdAt: ts(),
      expiresAt: expires,
    })
  );
  await assertFails(bobDb.collection("stories").doc("st_hidden").get());

  // Highlight owner can create & Bob in visibleToUids can read, Charlie cannot
  await assertSucceeds(
    aliceDb.collection("highlights").doc("hl_1").set({
      ownerId: ALICE_UID,
      title: "Memories",
      coverImageBase64: "abc",
      slides: [{ storyId: "st_1", mediaType: "image", imageBase64: "abc", caption: "Hi", addedAtMillis: 1000 }],
      visibility: "followers",
      visibleToUids: [ALICE_UID, BOB_UID],
      createdAt: ts(),
      updatedAt: ts(),
    })
  );
  await assertSucceeds(bobDb.collection("highlights").doc("hl_1").get());
  await assertFails(thirdDb.collection("highlights").doc("hl_1").get());

  // Direct Messages between Alice and Bob: Charlie cannot read or write
  const convId = `${ALICE_UID}_${BOB_UID}`;
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).set({
      participantUids: [ALICE_UID, BOB_UID],
      participantNames: { [ALICE_UID]: "alice_dm", [BOB_UID]: "bob_dm" },
      participantAvatars: { [ALICE_UID]: "prism_cyan", [BOB_UID]: "prism_cyan" },
      status: "request",
      requesterUid: ALICE_UID,
      lastMessageText: "",
      lastSenderUid: "",
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 0 },
      createdAt: ts(),
      updatedAt: ts(),
    })
  );
  await assertFails(thirdDb.collection("conversations").doc(convId).get());

  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("dm_1").set({
      conversationId: convId,
      participantUids: [ALICE_UID, BOB_UID],
      senderId: ALICE_UID,
      senderUsername: "alice_dm",
      text: "Hey Bob!",
      reactions: {},
      isDeleted: false,
      createdAt: ts(),
      updatedAt: ts(),
    })
  );
  await assertSucceeds(bobDb.collection("conversations").doc(convId).collection("messages").doc("dm_1").get());
  await assertFails(thirdDb.collection("conversations").doc(convId).collection("messages").doc("dm_1").get());
});

test("Video media chunk uploads succeed in same batch or follow-up batch for owner/participant and block attackers/oversize chunks", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext("charlie_vid_999").firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      ...validUserPayload(ALICE_UID, "alice_vid"),
      isPrivateAccount: false,
      ageBracket: "adult_18_plus",
    })
  );
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).set(validUserPayload(BOB_UID, "bob_vid"))
  );

  // 1. Video Post + chunk_0..1 in same WriteBatch succeeds
  const postRef = aliceDb.collection("posts").doc("p_vid_1");
  const postBatch = aliceDb.batch();
  postBatch.set(postRef, {
    authorId: ALICE_UID,
    authorUsername: "alice_vid",
    authorAvatar: "prism_cyan",
    postType: "video",
    category: "Creativity",
    caption: "Check out this clip!",
    imageBase64List: [],
    videoThumbnailBase64: "dGh1bWI=",
    videoDurationMs: 5000,
    videoChunkCount: 2,
    visibility: "public",
    visibleToUids: [ALICE_UID],
    groupIds: [],
    commentsDisabled: false,
    likeCount: 0,
    reactionCounts: {},
    commentCount: 0,
    shareCount: 0,
    createdAt: ts(),
    updatedAt: ts(),
  });
  postBatch.set(postRef.collection("media").doc("chunk_0"), {
    index: 0,
    dataBase64: "Y2h1bmsw",
    authorId: ALICE_UID,
    createdAt: ts(),
  });
  postBatch.set(postRef.collection("media").doc("chunk_1"), {
    index: 1,
    dataBase64: "Y2h1bmsx",
    authorId: ALICE_UID,
    createdAt: ts(),
  });
  await assertSucceeds(postBatch.commit());

  // Follow-up batch chunk (index <= 15) by author succeeds
  await assertSucceeds(
    postRef.collection("media").doc("chunk_9").set({
      index: 9,
      dataBase64: "Y2h1bms5",
      authorId: ALICE_UID,
      createdAt: ts(),
    })
  );

  // Non-author cannot inject media chunk into Alice's post
  await assertFails(
    bobDb.collection("posts").doc("p_vid_1").collection("media").doc("chunk_2").set({
      index: 2,
      dataBase64: "aGFjaw==",
      authorId: BOB_UID,
      createdAt: ts(),
    })
  );

  // Index > 15 or chunk > 700,000 chars rejected
  await assertFails(
    postRef.collection("media").doc("chunk_16").set({
      index: 16,
      dataBase64: "b3Zlcg==",
      authorId: ALICE_UID,
      createdAt: ts(),
    })
  );
  await assertFails(
    postRef.collection("media").doc("chunk_3").set({
      index: 3,
      dataBase64: "A".repeat(700001),
      authorId: ALICE_UID,
      createdAt: ts(),
    })
  );

  // 2. Video Story + chunk_0 in same WriteBatch succeeds
  const expires = new Date(Date.now() + 24 * 60 * 60 * 1000);
  const storyRef = aliceDb.collection("stories").doc("st_vid_1");
  const storyBatch = aliceDb.batch();
  storyBatch.set(storyRef, {
    authorId: ALICE_UID,
    authorUsername: "alice_vid",
    authorAvatar: "prism_cyan",
    mediaType: "video",
    imageBase64: "dGh1bWI=",
    videoDurationMs: 4200,
    videoChunkCount: 1,
    caption: "Video story!",
    visibility: "friends",
    visibleToUids: [ALICE_UID, BOB_UID],
    viewerCount: 0,
    createdAt: ts(),
    expiresAt: expires,
  });
  storyBatch.set(storyRef.collection("media").doc("chunk_0"), {
    index: 0,
    dataBase64: "c3RvcnljaHVuaw==",
    authorId: ALICE_UID,
    createdAt: ts(),
  });
  await assertSucceeds(storyBatch.commit());
  await assertSucceeds(bobDb.collection("stories").doc("st_vid_1").collection("media").get());
  await assertFails(charlieDb.collection("stories").doc("st_vid_1").collection("media").get());

  // 3. Direct Message video chunk succeeds for participant, fails for non-participant
  const convId = `${ALICE_UID}_${BOB_UID}`;
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).set({
      participantUids: [ALICE_UID, BOB_UID],
      participantNames: { [ALICE_UID]: "alice_vid", [BOB_UID]: "bob_vid" },
      participantAvatars: { [ALICE_UID]: "prism_cyan", [BOB_UID]: "prism_cyan" },
      status: "active",
      requesterUid: ALICE_UID,
      lastMessageText: "",
      lastSenderUid: "",
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 0 },
      createdAt: ts(),
      updatedAt: ts(),
    })
  );
  const dmRef = aliceDb.collection("conversations").doc(convId).collection("messages").doc("dm_vid_1");
  const dmBatch = aliceDb.batch();
  dmBatch.set(dmRef, {
    conversationId: convId,
    participantUids: [ALICE_UID, BOB_UID],
    senderId: ALICE_UID,
    senderUsername: "alice_vid",
    text: "",
    videoThumbnailBase64: "dGh1bWI=",
    videoDurationMs: 3000,
    videoChunkCount: 1,
    reactions: {},
    isDeleted: false,
    createdAt: ts(),
    updatedAt: ts(),
  });
  dmBatch.set(dmRef.collection("media").doc("chunk_0"), {
    index: 0,
    dataBase64: "ZG1jaHVuaw==",
    authorId: ALICE_UID,
    createdAt: ts(),
  });
  await assertSucceeds(dmBatch.commit());
  await assertSucceeds(bobDb.collection("conversations").doc(convId).collection("messages").doc("dm_vid_1").collection("media").get());
  await assertFails(
    charlieDb.collection("conversations").doc(convId).collection("messages").doc("dm_vid_1").collection("media").doc("chunk_1").set({
      index: 1,
      dataBase64: "aGFjaw==",
      authorId: "charlie_vid_999",
      createdAt: ts(),
    })
  );
});




