const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write user companion prefs or learned moves", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const past = new Date(Date.now() - 2000);

  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      backgroundId: "sakura_shrine",
      dressColor: "orig",
      jpMode: true,
      createdAt: past,
      updatedAt: past,
    })
  );
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("learnedMoves").get());
});

test("Authenticated owner can create and partially update companion prefs", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      backgroundId: "sakura_shrine",
      dressColor: "orig",
      jpMode: true,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      backgroundId: "starlight_studio",
      dressColor: "#ff7eb6",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject invalid background enum
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      backgroundId: "unknown_bg",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject immutable createdAt mutation
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject ghost field
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      backgroundId: "sakura_shrine",
      dressColor: "orig",
      jpMode: true,
      createdAt: created,
      updatedAt: created,
    })
  );
});

test("Authenticated owner can create, list, update, and delete learned moves", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("learnedMoves").doc("banzai").set({
      userId: ALICE_UID,
      name: "banzai",
      steps: ["left_arm=up, right_arm=up", "left_arm=down, right_arm=down"],
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("learnedMoves").get()
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("learnedMoves").doc("banzai").update({
      steps: ["left_arm=up, right_arm=up, body=jump"],
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject mismatched @DocumentId field inside payload
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("learnedMoves").doc("spin_cute").set({
      id: "spin_cute",
      userId: ALICE_UID,
      name: "spin_cute",
      steps: ["body=spin"],
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("learnedMoves").doc("banzai").delete()
  );
});

test("Cross-user access to another user's prefs and learned moves is denied", async () => {
  const past = new Date(Date.now() - 10000);
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      displayName: "Bob",
      backgroundId: "lavender_glow",
      dressColor: "orig",
      jpMode: false,
      createdAt: past,
      updatedAt: past,
    });
    await db.collection("users").doc(BOB_UID).collection("learnedMoves").doc("victory").set({
      userId: BOB_UID,
      name: "victory",
      steps: ["left_arm=up"],
      createdAt: past,
      updatedAt: past,
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("users").doc(BOB_UID).get());
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).update({ backgroundId: "sakura_shrine" })
  );
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("learnedMoves").get()
  );
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("learnedMoves").doc("victory").delete()
  );
});
