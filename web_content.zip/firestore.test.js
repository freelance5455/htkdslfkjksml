const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ADMIN_UID = "admin_uid_1";
const TEACHER1_UID = "teacher_c1_uid";
const TEACHER2_UID = "teacher_c2_uid";
const OUTSIDER_UID = "outsider_uid";
const SCHOOL_ID = "almustafa_hifz";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

async function seedSchoolWithAdmin() {
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "hafizhanzala106@gmail.com",
    email_verified: true,
  }).firestore();
  const now = new Date(Date.now() - 2000);
  const batch = adminDb.batch();
  batch.set(adminDb.collection("schools").doc(SCHOOL_ID), {
    ownerUid: ADMIN_UID,
    title: "ڈیلی رپورٹ کلاس حفظ القرآن",
    centre: "المصطفیٰ اسلامک سنٹر ڈی سی کالونی گوجرانوالہ",
    activeClassId: "c1",
    nextClassNum: 3,
    memberUids: [ADMIN_UID],
    createdAt: now,
    updatedAt: now,
  });
  batch.set(adminDb.collection("schools").doc(SCHOOL_ID).collection("admin_secrets").doc("admin"), {
    pin: "1234",
    updatedAt: now,
  });
  batch.set(adminDb.collection("schools").doc(SCHOOL_ID).collection("class_secrets").doc("c1"), {
    classId: "c1",
    pin: "1111",
    updatedAt: now,
  });
  batch.set(adminDb.collection("schools").doc(SCHOOL_ID).collection("class_secrets").doc("c2"), {
    classId: "c2",
    pin: "2222",
    updatedAt: now,
  });
  batch.set(adminDb.collection("schools").doc(SCHOOL_ID).collection("members").doc(ADMIN_UID), {
    userId: ADMIN_UID,
    email: "hafizhanzala106@gmail.com",
    displayName: "Admin",
    role: "admin",
    createdAt: now,
    updatedAt: now,
  });
  batch.set(adminDb.collection("schools").doc(SCHOOL_ID).collection("classes").doc("c1"), {
    name: "صدیق اکبر",
    sortOrder: 0,
    nextStudentId: 2,
    createdAt: now,
    updatedAt: now,
  });
  batch.set(adminDb.collection("schools").doc(SCHOOL_ID).collection("classes").doc("c2"), {
    name: "فاروق اعظم",
    sortOrder: 1,
    nextStudentId: 2,
    createdAt: now,
    updatedAt: now,
  });
  batch.set(
    adminDb.collection("schools").doc(SCHOOL_ID).collection("classes").doc("c1").collection("students").doc("s1"),
    {
      studentNum: 1,
      name: "صارم سہیل",
      sortOrder: 0,
      createdAt: now,
      updatedAt: now,
    }
  );
  await assertSucceeds(batch.commit());
}

test("Unauthenticated users cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("schools").doc(SCHOOL_ID).get());
  await assertFails(unauthDb.collection("user_profiles").doc(ADMIN_UID).get());
});

test("Bootstrapped admin batch-seeds school, secrets, classes, and students", async () => {
  await seedSchoolWithAdmin();
});

test("Class 1 teacher joins with valid PIN, reads/writes Class 1 only, blocked from Class 2 and secrets", async () => {
  await seedSchoolWithAdmin();
  const t1Db = testEnv.authenticatedContext(TEACHER1_UID, {
    email: "teacher1@example.com",
    email_verified: true,
  }).firestore();
  const now = new Date(Date.now() - 1000);

  // Wrong PIN must fail
  const badBatch = t1Db.batch();
  badBatch.set(t1Db.collection("schools").doc(SCHOOL_ID).collection("members").doc(TEACHER1_UID), {
    userId: TEACHER1_UID,
    email: "teacher1@example.com",
    displayName: "Teacher 1",
    role: "class",
    classId: "c1",
    accessPin: "9999",
    createdAt: now,
    updatedAt: now,
  });
  badBatch.update(t1Db.collection("schools").doc(SCHOOL_ID), {
    memberUids: [ADMIN_UID, TEACHER1_UID],
    updatedAt: now,
  });
  await assertFails(badBatch.commit());

  // Cannot self-promote to admin without admin PIN
  await assertFails(
    t1Db.collection("schools").doc(SCHOOL_ID).collection("members").doc(TEACHER1_UID).set({
      userId: TEACHER1_UID,
      email: "teacher1@example.com",
      displayName: "Teacher 1",
      role: "admin",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Valid Class 1 PIN batch join succeeds
  const goodBatch = t1Db.batch();
  goodBatch.set(t1Db.collection("schools").doc(SCHOOL_ID).collection("members").doc(TEACHER1_UID), {
    userId: TEACHER1_UID,
    email: "teacher1@example.com",
    displayName: "Teacher 1",
    role: "class",
    classId: "c1",
    accessPin: "1111",
    createdAt: now,
    updatedAt: now,
  });
  goodBatch.update(t1Db.collection("schools").doc(SCHOOL_ID), {
    memberUids: [ADMIN_UID, TEACHER1_UID],
    updatedAt: now,
  });
  await assertSucceeds(goodBatch.commit());

  // Teacher 1 can read Class 1 and students, and create/update Class 1 daily report
  await assertSucceeds(t1Db.collection("schools").doc(SCHOOL_ID).collection("classes").doc("c1").get());
  await assertSucceeds(
    t1Db.collection("schools").doc(SCHOOL_ID).collection("classes").doc("c1").collection("students").get()
  );
  await assertSucceeds(
    t1Db
      .collection("schools")
      .doc(SCHOOL_ID)
      .collection("classes")
      .doc("c1")
      .collection("daily_reports")
      .doc("2026-11-21")
      .set({
        date: "2026-11-21",
        classId: "c1",
        sotd: "1",
        rows: { "1": { a1: true, sp: "25", sl: "12" } },
        updatedByUid: TEACHER1_UID,
        createdAt: now,
        updatedAt: now,
      })
  );

  // Teacher 1 CANNOT read Class 2 or secrets or update school settings
  await assertFails(t1Db.collection("schools").doc(SCHOOL_ID).collection("classes").doc("c2").get());
  await assertFails(t1Db.collection("schools").doc(SCHOOL_ID).collection("class_secrets").doc("c1").get());
  await assertFails(t1Db.collection("schools").doc(SCHOOL_ID).collection("admin_secrets").doc("admin").get());
  await assertFails(t1Db.collection("schools").doc(SCHOOL_ID).update({ title: "Hacked", updatedAt: now }));
});

test("Email spoofing with email_verified: false is rejected", async () => {
  await seedSchoolWithAdmin();
  const spoofDb = testEnv.authenticatedContext(OUTSIDER_UID, {
    email: "hafizhanzala106@gmail.com",
    email_verified: false,
  }).firestore();
  await assertFails(spoofDb.collection("schools").doc(SCHOOL_ID).get());
});

test("User profile isolation and ghost field rejection", async () => {
  const db1 = testEnv.authenticatedContext(TEACHER1_UID).firestore();
  const db2 = testEnv.authenticatedContext(TEACHER2_UID).firestore();
  const now = new Date(Date.now() - 1000);

  await assertSucceeds(
    db1.collection("user_profiles").doc(TEACHER1_UID).set({
      userId: TEACHER1_UID,
      email: "t1@example.com",
      displayName: "T1",
      activeSchoolId: SCHOOL_ID,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(
    db1.collection("user_profiles").doc(TEACHER2_UID).set({
      userId: TEACHER2_UID,
      email: "t2@example.com",
      displayName: "T2",
      activeSchoolId: SCHOOL_ID,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(db2.collection("user_profiles").doc(TEACHER1_UID).get());
  await assertFails(
    db2.collection("user_profiles").doc(TEACHER2_UID).set({
      userId: TEACHER2_UID,
      email: "t2@example.com",
      displayName: "T2",
      activeSchoolId: SCHOOL_ID,
      ghostField: true,
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Class teacher can add, edit, and delete student profiles in their own class only", async () => {
  await seedSchoolWithAdmin();
  const t1Db = testEnv.authenticatedContext(TEACHER1_UID, {
    email: "teacher1@example.com",
    email_verified: true,
  }).firestore();
  const now = new Date(Date.now() - 1000);

  // Join Class 1 with PIN
  const joinBatch = t1Db.batch();
  joinBatch.set(t1Db.collection("schools").doc(SCHOOL_ID).collection("members").doc(TEACHER1_UID), {
    userId: TEACHER1_UID,
    email: "teacher1@example.com",
    displayName: "Teacher 1",
    role: "class",
    classId: "c1",
    accessPin: "1111",
    createdAt: now,
    updatedAt: now,
  });
  joinBatch.update(t1Db.collection("schools").doc(SCHOOL_ID), {
    memberUids: [ADMIN_UID, TEACHER1_UID],
    updatedAt: now,
  });
  await assertSucceeds(joinBatch.commit());

  // Add student profile to Class 1 (mirroring HifzRepository.addStudent batch)
  const c1Ref = t1Db.collection("schools").doc(SCHOOL_ID).collection("classes").doc("c1");
  const addBatch = t1Db.batch();
  addBatch.set(c1Ref.collection("students").doc("s2"), {
    studentNum: 2,
    name: "محمد طلحہ",
    fatherName: "حافظ عبداللہ",
    guardianPhone: "03001234567",
    currentPara: "12",
    notes: "ماشاءاللہ بہترین",
    sortOrder: 1,
    createdAt: now,
    updatedAt: now,
  });
  addBatch.update(c1Ref, {
    nextStudentId: 3,
    updatedAt: now,
  });
  await assertSucceeds(addBatch.commit());

  // Update student profile in Class 1
  await assertSucceeds(
    c1Ref.collection("students").doc("s2").update({
      name: "محمد طلحہ احمد",
      currentPara: "13",
      notes: "منزل مضبوط ہے",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject modifying immutable studentNum or ghost field
  await assertFails(
    c1Ref.collection("students").doc("s2").update({
      studentNum: 99,
      updatedAt: new Date(Date.now() - 400),
    })
  );
  await assertFails(
    c1Ref.collection("students").doc("s2").update({
      ghostField: "bad",
      updatedAt: new Date(Date.now() - 400),
    })
  );

  // Reject renaming own class metadata as teacher
  await assertFails(c1Ref.update({ name: "Renamed By Teacher", updatedAt: now }));

  // Reject adding/updating/deleting student in Class 2
  const c2Ref = t1Db.collection("schools").doc(SCHOOL_ID).collection("classes").doc("c2");
  await assertFails(
    c2Ref.collection("students").doc("s9").set({
      studentNum: 9,
      name: "Unauthorized Student",
      sortOrder: 1,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Delete student profile in Class 1 succeeds
  await assertSucceeds(c1Ref.collection("students").doc("s2").delete());
});

