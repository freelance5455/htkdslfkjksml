const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_nova_123";
const BOB_UID = "bob_nova_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validProductPayload(now = new Date(Date.now() - 5000)) {
  return {
    name: "প্রিমিয়াম স্মার্ট ওয়াচ",
    category: "ইলেকট্রনিক্স",
    price: 1250,
    oldPrice: 1590,
    emoji: "⌚",
    description: "দৈনন্দিন ব্যবহারের জন্য স্টাইলিশ স্মার্ট ওয়াচ।",
    featured: true,
    rating: 4.8,
    soldCount: 42,
    createdAt: now,
    updatedAt: now,
  };
}

function validOrderPayload(now = new Date(Date.now() - 5000)) {
  return {
    orderNumber: "NB10293847",
    customerName: "রহিম উদ্দিন",
    phone: "01712345678",
    address: "বাড়ি ১২, রোড ৫, ধানমন্ডি, ঢাকা",
    note: "সন্ধ্যায় ডেলিভারি দিবেন",
    deliveryZone: "ঢাকা সিটি",
    deliveryFee: 60,
    subtotal: 1250,
    total: 1310,
    status: "নতুন",
    paymentMethod: "Cash on Delivery",
    items: [
      {
        productId: "prod_1",
        name: "প্রিমিয়াম স্মার্ট ওয়াচ",
        price: 1250,
        qty: 1,
        emoji: "⌚",
      },
    ],
    createdAt: now,
    updatedAt: now,
  };
}

function validSettingsPayload(now = new Date(Date.now() - 5000)) {
  return {
    shopName: "NOVA BAZAR",
    phone: "01764458050",
    facebookUrl: "https://www.facebook.com/share/1EFrX218aV/",
    adminPin: "6708",
    dhakaDeliveryFee: 60,
    outsideDeliveryFee: 120,
    seeded: true,
    createdAt: now,
    updatedAt: now,
  };
}

test("Unauthenticated user: denied across all user-scoped collections", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection(`users/${ALICE_UID}/products`).get());
  await assertFails(unauth.collection(`users/${ALICE_UID}/orders`).get());
  await assertFails(unauth.collection(`users/${ALICE_UID}/cart`).get());
  await assertFails(unauth.collection(`users/${ALICE_UID}/wishlist`).get());
  await assertFails(unauth.doc(`users/${ALICE_UID}/settings/shop`).get());
  await assertFails(
    unauth.doc(`users/${ALICE_UID}/products/prod_1`).set(validProductPayload())
  );
});

test("Products: owner CRUD, optional imageBase64, and negative guards", async () => {
  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/products/prod_1`).set(validProductPayload(created))
  );

  // List subcollection succeeds for owner
  await assertSucceeds(alice.collection(`users/${ALICE_UID}/products`).get());

  // Partial update with optional imageBase64 succeeds while preserving createdAt
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/products/prod_1`).update({
      price: 1190,
      imageBase64: "data_base64_stub",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject @DocumentId 'id' leakage in create payload
  await assertFails(
    alice.doc(`users/${ALICE_UID}/products/prod_2`).set({
      ...validProductPayload(created),
      id: "prod_2",
    })
  );

  // Reject immutable createdAt modification
  await assertFails(
    alice.doc(`users/${ALICE_UID}/products/prod_1`).update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject tampered future timestamp
  await assertFails(
    alice.doc(`users/${ALICE_UID}/products/prod_3`).set(
      validProductPayload(new Date(Date.now() + 60000))
    )
  );

  // Owner delete succeeds
  await assertSucceeds(alice.doc(`users/${ALICE_UID}/products/prod_1`).delete());
});

test("Orders: owner create, status progression, and terminal state locking", async () => {
  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  // Reject creating order with non-initial status
  await assertFails(
    alice.doc(`users/${ALICE_UID}/orders/ord_bad`).set({
      ...validOrderPayload(created),
      status: "সম্পন্ন",
    })
  );

  // Create order with status 'নতুন'
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/orders/ord_1`).set(validOrderPayload(created))
  );

  // List orders succeeds
  await assertSucceeds(alice.collection(`users/${ALICE_UID}/orders`).get());

  // Advance status to 'কনফার্ম' then 'সম্পন্ন'
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/orders/ord_1`).update({
      status: "কনফার্ম",
      updatedAt: new Date(Date.now() - 3000),
    })
  );
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/orders/ord_1`).update({
      status: "সম্পন্ন",
      updatedAt: new Date(Date.now() - 2000),
    })
  );

  // Terminal state lock: cannot update after 'সম্পন্ন'
  await assertFails(
    alice.doc(`users/${ALICE_UID}/orders/ord_1`).update({
      status: "বাতিল",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Delete order is forbidden
  await assertFails(alice.doc(`users/${ALICE_UID}/orders/ord_1`).delete());
});

test("Cart, Wishlist & Settings: owner operations and validation bounds", async () => {
  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 5000);

  // Cart create/update/delete
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/cart/prod_1`).set({
      productId: "prod_1",
      qty: 2,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/cart/prod_1`).update({
      qty: 3,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(
    alice.doc(`users/${ALICE_UID}/cart/prod_1`).update({
      qty: 120,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertSucceeds(alice.doc(`users/${ALICE_UID}/cart/prod_1`).delete());

  // Wishlist create/delete (update forbidden)
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/wishlist/prod_1`).set({
      productId: "prod_1",
      createdAt: now,
    })
  );
  await assertFails(
    alice.doc(`users/${ALICE_UID}/wishlist/prod_1`).update({
      productId: "prod_2",
    })
  );
  await assertSucceeds(alice.doc(`users/${ALICE_UID}/wishlist/prod_1`).delete());

  // Settings create/update on 'shop' doc only
  await assertFails(
    alice.doc(`users/${ALICE_UID}/settings/other`).set(validSettingsPayload(now))
  );
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/settings/shop`).set(validSettingsPayload(now))
  );
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/settings/shop`).update({
      phone: "01812345678",
      adminPin: "9988",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // UserProfile create/update on 'info' doc only
  await assertFails(
    alice.doc(`users/${ALICE_UID}/profile/wrong`).set({
      fullName: "রহিম উদ্দিন",
      phone: "01712345678",
      defaultAddress: "ধানমন্ডি, ঢাকা",
      preferredZone: "ঢাকা সিটি",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/profile/info`).set({
      fullName: "রহিম উদ্দিন",
      phone: "01712345678",
      defaultAddress: "ধানমন্ডি, ঢাকা",
      preferredZone: "ঢাকা সিটি",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    alice.doc(`users/${ALICE_UID}/profile/info`).update({
      phone: "01812345678",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Cross-user isolation: Bob cannot read or write Alice's store data", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.doc(`users/${ALICE_UID}/products/prod_1`).set(validProductPayload());
    await db.doc(`users/${ALICE_UID}/orders/ord_1`).set(validOrderPayload());
    await db.doc(`users/${ALICE_UID}/settings/shop`).set(validSettingsPayload());
  });

  const bob = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bob.collection(`users/${ALICE_UID}/products`).get());
  await assertFails(bob.doc(`users/${ALICE_UID}/products/prod_1`).get());
  await assertFails(
    bob.doc(`users/${ALICE_UID}/products/prod_1`).update({
      price: 1,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(bob.doc(`users/${ALICE_UID}/orders/ord_1`).get());
  await assertFails(bob.doc(`users/${ALICE_UID}/settings/shop`).get());
  await assertFails(bob.doc(`users/${ALICE_UID}/profile/info`).get());
});
