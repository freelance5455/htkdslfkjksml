const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or create conversations", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const now = new Date(Date.now() - 1000);
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("conversations").get()
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1").set({
      userId: ALICE_UID,
      title: "Test Chat",
      lastMessagePreview: "Hello",
      messageCount: 1,
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Authenticated user can create, read, update, and list own conversations", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const convRef = aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1");
  const now = new Date(Date.now() - 1000);

  await assertSucceeds(
    convRef.set({
      userId: ALICE_UID,
      title: "Python Tutorial",
      lastMessagePreview: "Explain decorators",
      messageCount: 2,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(convRef.get());
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("conversations")
      .where("userId", "==", ALICE_UID)
      .get()
  );

  await assertSucceeds(
    convRef.update({
      title: "Advanced Python",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Cross-user isolation: Bob cannot read, list, or modify Alice's conversations or memories", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 1000);
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1").set({
      userId: ALICE_UID,
      title: "Private Chat",
      lastMessagePreview: "Secret",
      messageCount: 1,
      createdAt: now,
      updatedAt: now,
    })
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv_1").get()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("conversations").get()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem_1").set({
      userId: BOB_UID,
      fact: "Injected memory",
      category: "Hack",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Shadow update and invalid schema rejection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 1000);
  const msgRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("conversations")
    .doc("conv_1")
    .collection("messages")
    .doc("msg_1");

  // Rejects invalid role
  await assertFails(
    msgRef.set({
      userId: ALICE_UID,
      conversationId: "conv_1",
      role: "system_override",
      content: "Hello",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Accepts valid role
  await assertSucceeds(
    msgRef.set({
      userId: ALICE_UID,
      conversationId: "conv_1",
      role: "user",
      content: "Hello NOVA!",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Rejects shadow field on update
  await assertFails(
    msgRef.update({
      content: "Edited",
      isVerifiedAdmin: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );
});
