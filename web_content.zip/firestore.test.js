const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const nowTimestamp = () => new Date(Date.now() - 1000);

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write chats or memories", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("chats").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("memories").get());
});

test("Authenticated user can create and read own profile, chat, message, and memory", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const profileRef = aliceDb.collection("users").doc(ALICE_UID);
  await assertSucceeds(profileRef.set({
    userId: ALICE_UID,
    displayName: "Alice",
    preferredLanguage: "ru",
    modelMode: "balanced",
    ttsEnabled: true,
    ttsRate: 1.0,
    memoryEnabled: true,
    createdAt: nowTimestamp(),
    updatedAt: nowTimestamp(),
  }));

  const chatRef = profileRef.collection("chats").doc("chat_1");
  await assertSucceeds(chatRef.set({
    userId: ALICE_UID,
    title: "Test Chat",
    lastMessagePreview: "Hello",
    messageCount: 0,
    isPinned: false,
    createdAt: nowTimestamp(),
    updatedAt: nowTimestamp(),
  }));

  const msgRef = chatRef.collection("messages").doc("msg_1");
  await assertSucceeds(msgRef.set({
    userId: ALICE_UID,
    chatId: "chat_1",
    role: "user",
    text: "Hello FLAMI AI",
    hasImage: false,
    isError: false,
    createdAt: nowTimestamp(),
    updatedAt: nowTimestamp(),
  }));

  const memRef = profileRef.collection("memories").doc("mem_1");
  await assertSucceeds(memRef.set({
    userId: ALICE_UID,
    fact: "Prefers concise Kotlin code examples",
    category: "preference",
    isActive: true,
    createdAt: nowTimestamp(),
    updatedAt: nowTimestamp(),
  }));

  await assertSucceeds(profileRef.collection("chats").get());
  await assertSucceeds(chatRef.collection("messages").get());
  await assertSucceeds(profileRef.collection("memories").get());
});

test("Cross-user access is denied for profile, chats, messages, and memories", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection("users").doc(BOB_UID).collection("chats").doc("bob_chat").set({
      userId: BOB_UID,
      title: "Bob Private",
      lastMessagePreview: "Secret",
      messageCount: 1,
      isPinned: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    await db.collection("users").doc(BOB_UID).collection("memories").doc("bob_mem").set({
      userId: BOB_UID,
      fact: "Bob secret fact",
      category: "profile",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("chats").get());
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("chats").doc("bob_chat").get());
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("memories").get());
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("memories").doc("bob_mem").set({
    userId: ALICE_UID,
    fact: "Injected",
    category: "general",
    isActive: true,
    createdAt: nowTimestamp(),
    updatedAt: nowTimestamp(),
  }));
});

test("Shadow update with extra field or invalid enum is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const memRef = aliceDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem_shadow");
  await assertFails(memRef.set({
    userId: ALICE_UID,
    fact: "Valid fact",
    category: "general",
    isActive: true,
    isAdmin: true,
    createdAt: nowTimestamp(),
    updatedAt: nowTimestamp(),
  }));
  await assertFails(memRef.set({
    userId: ALICE_UID,
    fact: "Valid fact",
    category: "invalid_category",
    isActive: true,
    createdAt: nowTimestamp(),
    updatedAt: nowTimestamp(),
  }));
});

test("Orphaned message without parent chat is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const msgRef = aliceDb.collection("users").doc(ALICE_UID)
    .collection("chats").doc("nonexistent_chat")
    .collection("messages").doc("msg_orphan");
  await assertFails(msgRef.set({
    userId: ALICE_UID,
    chatId: "nonexistent_chat",
    role: "user",
    text: "Orphan",
    hasImage: false,
    isError: false,
    createdAt: nowTimestamp(),
    updatedAt: nowTimestamp(),
  }));
});
