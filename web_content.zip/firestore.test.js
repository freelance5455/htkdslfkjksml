const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write browser_tabs, bookmarks, or search_history", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("browser_tabs").get());
  await assertFails(unauthDb.collection("bookmarks").get());
  await assertFails(unauthDb.collection("search_history").get());
});

test("Authenticated user can create and query their own bookmark with matching userId filter", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb.collection("bookmarks").doc("bm_1").set({
      userId: ALICE_UID,
      title: "Kotlin Docs",
      url: "https://kotlinlang.org",
      category: "Araştırma",
      note: "Resmi dokümantasyon",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("bookmarks").where("userId", "==", ALICE_UID).get()
  );
});

test("Authenticated user cannot read or update another user's bookmark or tab", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("bookmarks").doc("bob_bm").set({
      userId: BOB_UID,
      title: "Bob Secret",
      url: "https://example.com",
      category: "Güvenli Kasa",
      note: "Private note",
      createdAt: now,
      updatedAt: now,
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("bookmarks").doc("bob_bm").get());
  await assertFails(
    aliceDb.collection("bookmarks").doc("bob_bm").update({
      title: "Hacked",
      updatedAt: new Date(),
    })
  );
});

test("Shadow update with ghost field is rejected on browser_tabs and search_history", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertFails(
    aliceDb.collection("browser_tabs").doc("tab_1").set({
      userId: ALICE_UID,
      title: "Ana Sayfa",
      url: "beyaz://index.html",
      lastQuery: "",
      isPinned: false,
      isAdmin: true,
      createdAt: now,
      updatedAt: now,
    })
  );
});
