const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function buildSchoolConfigPayload(uid, now) {
  return {
    userId: uid,
    country: "REPUBLIC OF RWANDA",
    schoolName: "WISDOM INSTRUCTION SCHOOL",
    poBox: "365@yahoo",
    tel: "0788799193",
    ministry: "MINISTRY OF EDUCATION",
    academicYear: "2026/2027",
    term: "1st Term",
    reportTitle: "REPORT CARD",
    teacherName: "Tr. Jean Bosco",
    showLogo: true,
    logoFileName: "",
    logoSizeDp: 82,
    logoCircular: true,
    signatureFileName: "",
    signatureSizeDp: 48,
    borderColorHex: "#1F2937",
    headerBgHex: "#F8FAFC",
    reportFont: "serif",
    positionFormat: "number_only",
    decimalPlaces: 1,
    conductMax: "",
    manualStudentCount: "",
    passMark: 50,
    autoApplyObservations: false,
    labels: {
      schoolPrefix: "School:",
      studentName: "Student Name:",
      subjects: "SUBJECTS",
      totalRow: "Total",
    },
    createdAt: now,
    updatedAt: now,
  };
}

test("Unauthenticated user: cannot read or write any school collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const now = new Date(Date.now() - 2000);

  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("classes").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("students").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("attendance").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("teacher_assignments").get());

  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("classes").doc("class_p4").set({
      userId: ALICE_UID,
      name: "P4",
      sortOrder: 0,
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Cross-user isolation: Bob cannot read or write Alice's school data", async () => {
  const now = new Date(Date.now() - 5000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("users").doc(ALICE_UID).collection("classes").doc("class_p4").set({
      userId: ALICE_UID,
      name: "P4",
      sortOrder: 0,
      createdAt: now,
      updatedAt: now,
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("classes").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("classes").doc("class_p4").get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("classes").doc("class_p4").update({
      name: "Hacked",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("classes").doc("class_p4").delete());
});

test("Owner CRUD & partial updates succeed across all 7 collections", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);
  const updated = new Date(Date.now() - 1000);
  const userRoot = aliceDb.collection("users").doc(ALICE_UID);

  // 1. SchoolConfig
  await assertSucceeds(userRoot.collection("school_configs").doc("default").set(buildSchoolConfigPayload(ALICE_UID, created)));
  await assertSucceeds(
    userRoot.collection("school_configs").doc("default").update({
      schoolName: "TRIZZIE INTERNATIONAL SCHOOL",
      term: "2nd Term",
      updatedAt: updated,
    })
  );

  // 2. Class
  await assertSucceeds(
    userRoot.collection("classes").doc("class_p4").set({
      userId: ALICE_UID,
      name: "P4",
      sortOrder: 0,
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(
    userRoot.collection("classes").doc("class_p4").update({
      name: "P4-A",
      updatedAt: updated,
    })
  );

  // 3. Subject
  await assertSucceeds(
    userRoot.collection("subjects").doc("sub_math").set({
      userId: ALICE_UID,
      classId: "class_p4",
      name: "MATHEMATICS",
      maxTest: 100,
      maxExam: 0,
      sortOrder: 0,
      createdAt: created,
      updatedAt: created,
    })
  );

  // 4. Student
  await assertSucceeds(
    userRoot.collection("students").doc("stu_1").set({
      userId: ALICE_UID,
      classId: "class_p4",
      name: "HIRWA AUDREY",
      studentIdNo: "WIS-P4-005",
      conduct: "35",
      latesCount: 0,
      absencesCount: 0,
      observation: "Good You can do better",
      testScores: { sub_math: 72 },
      examScores: {},
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(
    userRoot.collection("students").doc("stu_1").update({
      testScores: { sub_math: 85 },
      latesCount: 1,
      updatedAt: updated,
    })
  );

  // 5. AttendanceRecord
  await assertSucceeds(
    userRoot.collection("attendance").doc("class_p4_2026-11-23_stu_1").set({
      userId: ALICE_UID,
      classId: "class_p4",
      studentId: "stu_1",
      dateKey: "2026-11-23",
      status: "LATE",
      note: "Arrived 10m after assembly",
      createdAt: created,
      updatedAt: created,
    })
  );

  // 6. TeacherAssignment
  await assertSucceeds(
    userRoot.collection("teacher_assignments").doc("ta_1").set({
      userId: ALICE_UID,
      teacherName: "Tr. Jean Bosco",
      teacherEmail: "jbosco@trizzie.edu",
      teacherPhone: "0788001122",
      classId: "class_p4",
      className: "P4",
      subjectId: "sub_math",
      subjectName: "MATHEMATICS",
      roleType: "CLASS_TEACHER",
      weeklyHours: 8,
      scheduleNote: "Mon-Fri 08:00-09:30",
      createdAt: created,
      updatedAt: created,
    })
  );

  // 7. ObservationRule
  await assertSucceeds(
    userRoot.collection("observation_rules").doc("rule_1").set({
      userId: ALICE_UID,
      minPct: 85,
      commentText: "Excellent performance. Keep it up!",
      createdAt: created,
      updatedAt: created,
    })
  );

  // List queries succeed on owner's subcollections (including empty)
  await assertSucceeds(userRoot.collection("classes").get());
  await assertSucceeds(userRoot.collection("students").get());
  await assertSucceeds(userRoot.collection("attendance").get());
  await assertSucceeds(userRoot.collection("teacher_assignments").get());
});

test("Validation & immutability guards reject ghost fields, @DocumentId id injection, invalid enums, and future timestamps", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const userRoot = aliceDb.collection("users").doc(ALICE_UID);
  const created = new Date(Date.now() - 10000);

  // Reject ghost field & @DocumentId 'id' field on create
  await assertFails(
    userRoot.collection("classes").doc("class_bad").set({
      id: "class_bad",
      userId: ALICE_UID,
      name: "P4",
      sortOrder: 0,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject future timestamp
  await assertFails(
    userRoot.collection("classes").doc("class_future").set({
      userId: ALICE_UID,
      name: "P4",
      sortOrder: 0,
      createdAt: new Date(Date.now() + 60000),
      updatedAt: created,
    })
  );

  // Reject invalid attendance status
  await assertFails(
    userRoot.collection("attendance").doc("att_bad").set({
      userId: ALICE_UID,
      classId: "class_p4",
      studentId: "stu_1",
      dateKey: "2026-11-23",
      status: "SKIPPED",
      note: "",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject invalid teacher roleType
  await assertFails(
    userRoot.collection("teacher_assignments").doc("ta_bad").set({
      userId: ALICE_UID,
      teacherName: "Tr. Alice",
      teacherEmail: "",
      teacherPhone: "",
      classId: "class_p4",
      className: "P4",
      subjectId: "",
      subjectName: "",
      roleType: "SUPERADMIN",
      weeklyHours: 10,
      scheduleNote: "",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Create valid student then reject createdAt mutation on update
  await assertSucceeds(
    userRoot.collection("students").doc("stu_imm").set({
      userId: ALICE_UID,
      classId: "class_p4",
      name: "INEZA GRACE",
      studentIdNo: "",
      conduct: "37",
      latesCount: 0,
      absencesCount: 0,
      observation: "",
      testScores: {},
      examScores: {},
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertFails(
    userRoot.collection("students").doc("stu_imm").update({
      createdAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});
