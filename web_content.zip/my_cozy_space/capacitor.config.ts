import type { CapacitorConfig } from '@capacitor/cli'
const config: CapacitorConfig = {
  appId: 'com.mycozyspace.planner',
  appName: 'My Cozy Space',
  webDir: 'dist',
  bundledWebRuntime: false
}
export default config
