# My Cozy Space 🌷

A cottagecore life planner built with React, Vite, TypeScript and Capacitor.

## Included
- Responsive web planner and installable PWA shell
- Home dashboard, tasks, calendar, habits and goals
- Finance tracker with monthly budget, envelopes and money notes
- Notes, export/import JSON backup
- Local autosave using browser storage
- Capacitor configuration for Android packaging
- Optional Supabase client configuration placeholder

## Run the web app
1. Install Node.js 20 or newer.
2. In this folder run:
   ```bash
   npm install
   npm run dev
   ```
3. Open the local URL printed by Vite.

For a production web build:
```bash
npm run build
```
Deploy the generated `dist/` folder to a static host such as Netlify, Vercel or Cloudflare Pages.

## Create the Android project / APK
You need Android Studio and an Android SDK.
```bash
npm install
npx cap add android
npm run android:sync
npm run android:open
```
In Android Studio, build > Build Bundle(s) / APK(s) > Build APK(s).
The generated APK is an installable Android build. This source bundle does not contain a prebuilt APK.

## Storage
Planner changes autosave locally in the browser / app webview. Use Settings > Export backup to download a JSON backup, and Import backup to restore it.

## Cloud sync status
Cloud sync is **not live yet**. The Settings screen includes Supabase project URL and public anon key fields as a starting point, but account authentication, a user-scoped database table, row-level security and sync conflict handling still need to be implemented before cloud backup can safely be enabled. Do not put a Supabase service-role key in the app.

A suggested starting SQL schema for a future authenticated cloud backup:
```sql
create table public.planner_backups (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.planner_backups enable row level security;

create policy "Users can read their own planner backup"
on public.planner_backups for select
to authenticated using (auth.uid() = user_id);

create policy "Users can insert their own planner backup"
on public.planner_backups for insert
to authenticated with check (auth.uid() = user_id);

create policy "Users can update their own planner backup"
on public.planner_backups for update
to authenticated using (auth.uid() = user_id)
with check (auth.uid() = user_id);
```

## Notes
- Currency display currently uses PHP (Philippine peso).
- Sample dashboard content is included so the app doesn't open empty.
- The finance screen is accessible through the floating Finances shortcut.
- For a public launch, add a privacy policy, authentication, cloud sync implementation and app icons.
