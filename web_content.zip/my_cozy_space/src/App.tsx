import { useEffect, useMemo, useState } from 'react'
import { Home, CalendarDays, Sun, Compass, Settings, Check, Plus, Leaf, BookOpen, Heart, Wallet, Target, Sparkles, Flower2, ChevronLeft, ChevronRight, X, Cloud, Download, Trash2, Menu } from 'lucide-react'
import { createClient, SupabaseClient } from '@supabase/supabase-js'

type Task = { id: string; title: string; done: boolean; date: string }
type Habit = { id: string; title: string; done: boolean }
type Envelope = { id: string; name: string; budget: number; spent: number }
type Note = { id: string; text: string; createdAt: string }
type AppData = { tasks: Task[]; habits: Habit[]; envelopes: Envelope[]; notes: Note[]; goals: string[]; budget: number; transactions: {id:string; label:string; amount:number; kind:string; date:string}[] }
const KEY = 'my-cozy-space-data-v1'
const today = new Date()
const dateKey = (d: Date) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
const initial: AppData = {
  tasks: [
    { id:'t1', title:'Make a little plan for today', done:false, date:dateKey(today) },
    { id:'t2', title:'Drink a glass of water', done:false, date:dateKey(today) },
    { id:'t3', title:'Tidy one cozy corner', done:false, date:dateKey(today) }
  ],
  habits: [{id:'h1',title:'Morning water',done:false},{id:'h2',title:'Read 10 pages',done:false},{id:'h3',title:'Stretch gently',done:false}],
  envelopes: [{id:'e1',name:'Home & bills',budget:8000,spent:2500},{id:'e2',name:'Groceries',budget:5000,spent:1200},{id:'e3',name:'Little treats',budget:1500,spent:300}],
  notes: [{id:'n1',text:'Plan a slow weekend morning 🌷',createdAt:new Date().toISOString()}],
  goals: ['Create a peaceful morning routine','Save for something meaningful','Make more time for reading'],
  budget: 18000,
  transactions: []
}
const money = (n:number) => new Intl.NumberFormat('en-PH',{style:'currency',currency:'PHP',maximumFractionDigits:0}).format(n)
const uid = () => Math.random().toString(36).slice(2,10)

export default function App() {
  const [data,setData] = useState<AppData>(() => {
    try { return {...initial,...JSON.parse(localStorage.getItem(KEY) || '{}')} } catch { return initial }
  })
  const [page,setPage] = useState('Home')
  const [month,setMonth] = useState(new Date(today.getFullYear(),today.getMonth(),1))
  const [taskText,setTaskText] = useState('')
  const [noteText,setNoteText] = useState('')
  const [envelopeName,setEnvelopeName] = useState('')
  const [envelopeBudget,setEnvelopeBudget] = useState('')
  const [transactionLabel,setTransactionLabel] = useState('')
  const [transactionAmount,setTransactionAmount] = useState('')
  const [transactionKind,setTransactionKind] = useState('spent')
  const [budgetInput,setBudgetInput] = useState(String(data.budget))
  const [toast,setToast] = useState('')
  const [menuOpen,setMenuOpen] = useState(false)
  const [supabase,setSupabase] = useState<SupabaseClient|null>(null)
  const [cloudStatus,setCloudStatus] = useState('Cloud not connected')
  const [configUrl,setConfigUrl] = useState(import.meta.env.VITE_SUPABASE_URL || '')
  const [configKey,setConfigKey] = useState(import.meta.env.VITE_SUPABASE_ANON_KEY || '')

  useEffect(() => { localStorage.setItem(KEY,JSON.stringify(data)) },[data])
  useEffect(() => { if (!toast) return; const t=setTimeout(()=>setToast(''),2400); return ()=>clearTimeout(t) },[toast])
  useEffect(() => {
    if (configUrl && configKey) {
      try { setSupabase(createClient(configUrl,configKey)); setCloudStatus('Cloud ready — sign-in and database setup still required') } catch { setCloudStatus('Check your cloud settings') }
    }
  },[configUrl,configKey])

  const update = (patch:Partial<AppData>) => setData(prev=>({...prev,...patch}))
  const tasksToday = data.tasks.filter(t=>t.date===dateKey(today))
  const spent = data.envelopes.reduce((a,e)=>a+e.spent,0)
  const left = data.budget-spent
  const monthName = month.toLocaleDateString('en-US',{month:'long',year:'numeric'})
  const calendarDays = useMemo(()=>{
    const first = new Date(month.getFullYear(),month.getMonth(),1).getDay()
    const count = new Date(month.getFullYear(),month.getMonth()+1,0).getDate()
    return [...Array(first).fill(null),...Array.from({length:count},(_,i)=>i+1)]
  },[month])

  const addTask = () => {
    if (!taskText.trim()) return
    update({tasks:[...data.tasks,{id:uid(),title:taskText.trim(),done:false,date:dateKey(today)}]}); setTaskText('')
  }
  const toggleTask = (id:string) => update({tasks:data.tasks.map(t=>t.id===id?{...t,done:!t.done}:t)})
  const toggleHabit = (id:string) => update({habits:data.habits.map(h=>h.id===id?{...h,done:!h.done}:h)})
  const addEnvelope = () => {
    const amount=Number(envelopeBudget)
    if (!envelopeName.trim() || !Number.isFinite(amount) || amount<0) return
    update({envelopes:[...data.envelopes,{id:uid(),name:envelopeName.trim(),budget:amount,spent:0}]})
    setEnvelopeName('');setEnvelopeBudget('');setToast('Your new envelope is ready 🌱')
  }
  const addTransaction = () => {
    const amount=Number(transactionAmount)
    if (!transactionLabel.trim() || !Number.isFinite(amount) || amount<=0) return
    if (transactionKind==='spent') {
      const first=data.envelopes[0]
      if (first) update({envelopes:data.envelopes.map((e,i)=>i===0?{...e,spent:e.spent+amount}:e),transactions:[{id:uid(),label:transactionLabel,amount,kind:transactionKind,date:dateKey(today)},...data.transactions]})
      else update({transactions:[{id:uid(),label:transactionLabel,amount,kind:transactionKind,date:dateKey(today)},...data.transactions]})
    } else update({transactions:[{id:uid(),label:transactionLabel,amount,kind:transactionKind,date:dateKey(today)},...data.transactions]})
    setTransactionLabel('');setTransactionAmount('');setToast('Money note saved ✨')
  }
  const addNote = () => { if(!noteText.trim())return;update({notes:[{id:uid(),text:noteText.trim(),createdAt:new Date().toISOString()},...data.notes]});setNoteText('') }
  const exportData = () => {
    const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='my-cozy-space-backup.json';a.click();URL.revokeObjectURL(url);setToast('Backup downloaded 🌷')
  }
  const importData = (file?:File) => {
    if(!file)return
    const reader=new FileReader();reader.onload=()=>{try{const parsed=JSON.parse(String(reader.result));setData({...initial,...parsed});setToast('Your backup was restored')}catch{setToast('That backup could not be read')}};reader.readAsText(file)
  }
  const nav=[{name:'Home',icon:Home},{name:'Calendar',icon:CalendarDays},{name:'My Day',icon:Sun},{name:'Explore',icon:Compass},{name:'Settings',icon:Settings}]
  const go=(name:string)=>{setPage(name);setMenuOpen(false)}
  return <div className="app-shell">
    <aside className={`sidebar ${menuOpen?'open':''}`}>
      <div className="brand"><div className="brand-mark"><Flower2 size={25}/></div><div><strong>My Cozy Space</strong><small>a little progress, every day</small></div><button className="mobile-close" onClick={()=>setMenuOpen(false)}><X size={18}/></button></div>
      <div className="side-label">YOUR LITTLE WORLD</div>
      {nav.map(item=><button key={item.name} className={`nav-item ${page===item.name?'active':''}`} onClick={()=>go(item.name)}><item.icon size={18}/>{item.name}</button>)}
      <div className="side-bottom"><div className="plant-note"><span>🌿</span><p>Take things one gentle step at a time.</p></div><small>MY COZY SPACE · 2027</small></div>
    </aside>
    {menuOpen&&<div className="scrim" onClick={()=>setMenuOpen(false)}/>}
    <main className="main">
      <header className="topbar"><button className="menu-button" onClick={()=>setMenuOpen(true)}><Menu/></button><div className="breadcrumb">My little world <span>/</span> <b>{page}</b></div><div className="top-right"><span className="today-pill"><span className="dot"/> {today.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'})}</span><div className="avatar">🌷</div></div></header>
      <div className="content">
        {page==='Home'&&<><div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> A FRESH LITTLE START</div><h1>Good day, sunshine <span>☀️</span></h1><p className="subheading">A little progress, every single day.</p></div><div className="quote-card"><span>“</span><p>Little by little, a little becomes a lot.</p><small>— Tanzanian proverb</small></div></div>
          <div className="hero-scene"><div className="hero-copy"><span className="hero-tag">YOUR COZY CORNER</span><h2>Make room for<br/><em>what matters.</em></h2><p>Small steps count. Rest counts, too.</p><button className="soft-button" onClick={()=>go('My Day')}>Plan my day <span>→</span></button></div><div className="scene-art"><div className="sun-disc"/><div className="window-frame"><div className="window-sky"/><div className="window-cross v"/><div className="window-cross h"/></div><div className="shelf"><span>▰</span><span>▰</span><span>▰</span><span>▰</span></div><div className="cat">🐈</div><div className="plant plant-one">🌿</div><div className="plant plant-two">🪴</div></div></div>
          <div className="stats-grid"><Stat icon={<Check/>} label="Today's tasks" value={`${tasksToday.filter(t=>t.done).length}/${tasksToday.length}`} hint="one step at a time"/><Stat icon={<Leaf/>} label="Daily habits" value={`${data.habits.filter(h=>h.done).length}/${data.habits.length}`} hint="growing gently"/><Stat icon={<Target/>} label="Little goals" value={`${data.goals.length}`} hint="dreams in progress"/><Stat icon={<Wallet/>} label="Left to spend" value={money(left)} hint="this month's budget"/></div>
          <div className="dashboard-grid"><section className="panel"><PanelHead title="Today's little list" sub="Your day, one thing at a time" action="See my day" onAction={()=>go('My Day')}/><div className="task-list">{tasksToday.slice(0,4).map(t=><button key={t.id} className={`task-row ${t.done?'checked':''}`} onClick={()=>toggleTask(t.id)}><span className="check-circle">{t.done&&<Check size={13}/>}</span><span>{t.title}</span></button>)}{tasksToday.length===0&&<Empty text="Nothing on the list yet. Add a little task!"/>}</div><button className="text-action" onClick={()=>go('My Day')}>Open my day <span>→</span></button></section>
          <section className="panel"><PanelHead title="Tiny habits, big feelings" sub="A little care goes a long way" action="All habits" onAction={()=>go('Explore')}/><div className="habit-list">{data.habits.slice(0,4).map(h=><button key={h.id} className={`habit-row ${h.done?'checked':''}`} onClick={()=>toggleHabit(h.id)}><span className="habit-icon">{h.done?'🌱':'🌼'}</span><span>{h.title}</span><span className="habit-check">{h.done?'Done':'Check in'}</span></button>)}</div></section></div>
          <div className="dashboard-grid lower"><section className="panel"><PanelHead title="A note to self" sub="Leave a little thought here"/><textarea className="note-input" value={noteText} onChange={e=>setNoteText(e.target.value)} placeholder="Today, I want to remember..."/><button className="primary-button small" onClick={addNote}>Save note <Plus size={15}/></button>{data.notes.slice(0,2).map(n=><div className="saved-note" key={n.id}>{n.text}</div>)}</section><section className="panel countdown"><div className="countdown-flower">🌷</div><span className="eyebrow">A GENTLE REMINDER</span><h3>Your dreams are<br/>worth making time for.</h3><p>Keep showing up for the things you love.</p><button className="text-action" onClick={()=>go('Explore')}>Visit my goals →</button></section></div>
        </>}
        {page==='Calendar'&&<><PageTitle eyebrow="A LITTLE LOOK AHEAD" title="My calendar" sub="Make space for the days you want to remember."/><section className="panel calendar-panel"><div className="calendar-head"><button className="icon-button" onClick={()=>setMonth(new Date(month.getFullYear(),month.getMonth()-1,1))}><ChevronLeft/></button><h2>{monthName}</h2><button className="icon-button" onClick={()=>setMonth(new Date(month.getFullYear(),month.getMonth()+1,1))}><ChevronRight/></button></div><div className="calendar-grid">{['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d=><b key={d}>{d}</b>)}{calendarDays.map((d,i)=><div key={i} className={`calendar-day ${d===today.getDate()&&month.getMonth()===today.getMonth()&&month.getFullYear()===today.getFullYear()?'today':''} ${d?'':'blank'}`}>{d&&<><span>{d}</span>{data.tasks.some(t=>t.date===dateKey(new Date(month.getFullYear(),month.getMonth(),d)))&&<i/>}</>}</div>)}</div><p className="muted small-text">Little dots show days with tasks. Your calendar is saved on this device.</p></section><section className="panel"><PanelHead title="This month's tasks" sub="Things you've planned for this month"/>{data.tasks.filter(t=>t.date.startsWith(`${month.getFullYear()}-${String(month.getMonth()+1).padStart(2,'0')}`)).map(t=><div className="simple-row" key={t.id}><span>{t.done?'✓':'○'} {t.title}</span><small>{t.date}</small></div>)}</section></>}
        {page==='My Day'&&<><PageTitle eyebrow="TODAY, AT YOUR PACE" title="My day" sub="You don't have to do it all. Just begin somewhere."/><section className="panel"><PanelHead title="Today's little list" sub={`${tasksToday.filter(t=>t.done).length} of ${tasksToday.length} done`}/><div className="add-row"><input value={taskText} onChange={e=>setTaskText(e.target.value)} onKeyDown={e=>e.key==='Enter'&&addTask()} placeholder="Add a small task..."/><button className="primary-button" onClick={addTask}><Plus size={16}/> Add task</button></div>{tasksToday.map(t=><div className="task-row-wrap" key={t.id}><button className={`task-row ${t.done?'checked':''}`} onClick={()=>toggleTask(t.id)}><span className="check-circle">{t.done&&<Check size={13}/>}</span><span>{t.title}</span></button><button className="delete-button" onClick={()=>update({tasks:data.tasks.filter(x=>x.id!==t.id)})}><Trash2 size={15}/></button></div>)}</section><section className="panel"><PanelHead title="Daily habits" sub="Tiny promises to yourself"/>{data.habits.map(h=><button className={`habit-row ${h.done?'checked':''}`} key={h.id} onClick={()=>toggleHabit(h.id)}><span className="habit-icon">{h.done?'🌱':'🌼'}</span><span>{h.title}</span><span className="habit-check">{h.done?'Done':'Check in'}</span></button>)}</section></>}
        {page==='Explore'&&<><PageTitle eyebrow="GROW AT YOUR OWN PACE" title="Little things to explore" sub="A home for your plans, dreams and everyday rituals."/><div className="feature-grid"><Feature icon={<Target/>} title="My goals" desc="Keep your dreams somewhere you can see them."/><Feature icon={<Heart/>} title="Wellness" desc="Make gentle space for rest and self-care."/><Feature icon={<BookOpen/>} title="Journal & memories" desc="Save the little moments worth keeping."/><Feature icon={<Sparkles/>} title="Study space" desc="A quiet corner for learning and focus."/><Feature icon={<Flower2/>} title="Wishlist" desc="Collect the lovely things you're looking forward to."/><Feature icon={<Leaf/>} title="Habit garden" desc="Grow small routines, one day at a time."/><Feature icon={<Wallet/>} title="My finances" desc="Give every peso a cozy little place."/><Feature icon={<CalendarDays/>} title="Year in review" desc="Look back at how far your little steps took you." /></div><section className="panel"><PanelHead title="Your little goals" sub="Keep the things that matter close"/>{data.goals.map((g,i)=><div className="simple-row" key={i}><span>🌱 {g}</span><button className="delete-button" onClick={()=>update({goals:data.goals.filter((_,j)=>j!==i)})}><Trash2 size={14}/></button></div>)}<div className="add-row"><input id="goal-input" placeholder="A new little goal..."/><button className="primary-button" onClick={()=>{const el=document.getElementById('goal-input') as HTMLInputElement;if(el.value.trim()){update({goals:[...data.goals,el.value.trim()]});el.value=''}}}><Plus size={16}/> Add goal</button></div></section></>}
        {page==='Settings'&&<><PageTitle eyebrow="MAKE YOUR SPACE YOURS" title="Little settings" sub="Your cozy corner, just the way you like it."/><section className="panel"><PanelHead title="Your data, your choice" sub="Your planner automatically saves to this device."/><div className="setting-row"><div><b>Device storage</b><p>Autosaves as you make changes.</p></div><span className="status-good">● Active</span></div><div className="setting-row"><div><b>Cloud backup</b><p>{cloudStatus}</p></div><span className="status-soft"><Cloud size={14}/> Optional</span></div><div className="cloud-form"><label>Supabase project URL</label><input value={configUrl} onChange={e=>setConfigUrl(e.target.value)} placeholder="https://your-project.supabase.co"/><label>Supabase anon key</label><input value={configKey} onChange={e=>setConfigKey(e.target.value)} placeholder="Paste your public anon key" type="password"/><p className="muted small-text">Cloud sync is not active yet. A Supabase project, database table, and authenticated user are required before syncing. Never paste a service-role key here.</p></div><div className="button-row"><button className="primary-button" onClick={exportData}><Download size={16}/> Export backup</button><label className="secondary-button upload-button">Import backup<input type="file" accept="application/json" onChange={e=>importData(e.target.files?.[0])}/></label></div></section><section className="panel"><PanelHead title="A fresh start" sub="This clears planner data stored in this browser."/><button className="danger-button" onClick={()=>{if(confirm('Clear all your planner data on this device? Export a backup first if you need it.')){setData(initial);setToast('A fresh little start 🌱')}}}><Trash2 size={15}/> Clear local planner data</button></section><section className="panel"><PanelHead title="About My Cozy Space"/><p className="muted">A little progress, every single day. Made for gentle plans, growing dreams and cozy moments. 🌷</p><small className="muted">Version 1.0.0 · Cottagecore edition</small></section></>}
        {page==='Finances'&&<Finance data={data} update={update} budgetInput={budgetInput} setBudgetInput={setBudgetInput} transactionLabel={transactionLabel} setTransactionLabel={setTransactionLabel} transactionAmount={transactionAmount} setTransactionAmount={setTransactionAmount} transactionKind={transactionKind} setTransactionKind={setTransactionKind} addTransaction={addTransaction} envelopeName={envelopeName} setEnvelopeName={setEnvelopeName} envelopeBudget={envelopeBudget} setEnvelopeBudget={setEnvelopeBudget} addEnvelope={addEnvelope}/>}
      </div>
      <footer className="footer">Made with a little love <span>♥</span> and a lot of leaves</footer>
    </main>
    <nav className="mobile-nav">{nav.map(item=><button key={item.name} className={page===item.name?'active':''} onClick={()=>go(item.name)}><item.icon size={18}/><small>{item.name}</small></button>)}</nav>
    {toast&&<div className="toast">{toast}</div>}
    <button className="finance-fab" title="Open finances" onClick={()=>setPage('Finances')}><Wallet size={19}/><span>Finances</span></button>
  </div>
}

function Stat({icon,label,value,hint}:{icon:React.ReactNode,label:string,value:string,hint:string}){return <div className="stat-card"><div className="stat-icon">{icon}</div><div><small>{label}</small><strong>{value}</strong><span>{hint}</span></div></div>}
function PanelHead({title,sub,action,onAction}:{title:string,sub?:string,action?:string,onAction?:()=>void}){return <div className="panel-head"><div><h3>{title}</h3>{sub&&<p>{sub}</p>}</div>{action&&<button className="head-action" onClick={onAction}>{action} →</button>}</div>}
function Empty({text}:{text:string}){return <div className="empty">{text}</div>}
function PageTitle({eyebrow,title,sub}:{eyebrow:string,title:string,sub:string}){return <div className="page-title"><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{sub}</p></div>}
function Feature({icon,title,desc}:{icon:React.ReactNode,title:string,desc:string}){return <div className="feature-card"><div className="feature-icon">{icon}</div><h3>{title}</h3><p>{desc}</p></div>}
function Finance({data,update,budgetInput,setBudgetInput,transactionLabel,setTransactionLabel,transactionAmount,setTransactionAmount,transactionKind,setTransactionKind,addTransaction,envelopeName,setEnvelopeName,envelopeBudget,setEnvelopeBudget,addEnvelope}:any){
 const spent=data.envelopes.reduce((a:number,e:any)=>a+e.spent,0)
 return <><PageTitle eyebrow="MONEY, TUCKED INTO ENVELOPES" title="My finances" sub="A gentle way to keep an eye on your pesos."/><section className="panel"><PanelHead title="This month's little budget" sub="Cash envelope system · November 2026"/><div className="budget-edit"><label>My total budget for this month</label><div className="add-row"><input type="number" value={budgetInput} onChange={e=>setBudgetInput(e.target.value)}/><button className="primary-button" onClick={()=>update({budget:Number(budgetInput)||0})}>Save budget</button></div></div><div className="money-stats"><div><small>Budget</small><b>{money(data.budget)}</b></div><div><small>Spent</small><b>{money(spent)}</b></div><div><small>Left to spend</small><b>{money(data.budget-spent)}</b></div><div><small>In envelopes</small><b>{money(data.envelopes.reduce((a:number,e:any)=>a+e.budget,0))}</b></div></div></section><section className="panel"><PanelHead title="Split it into envelopes" sub="Give each peso a little purpose"/><div className="envelope-grid">{data.envelopes.map((e:any)=><div className="envelope" key={e.id}><span>✿</span><b>{e.name}</b><strong>{money(e.budget-e.spent)}</strong><small>left of {money(e.budget)}</small><div className="progress"><i style={{width:`${Math.min(100,e.budget?e.spent/e.budget*100:0)}%`}}/></div><button className="delete-button" onClick={()=>update({envelopes:data.envelopes.filter((x:any)=>x.id!==e.id)})}>Remove</button></div>)}</div><div className="form-grid"><div><label>Envelope name</label><input value={envelopeName} onChange={e=>setEnvelopeName(e.target.value)} placeholder="e.g. Transport"/></div><div><label>Monthly budget (₱)</label><input type="number" value={envelopeBudget} onChange={e=>setEnvelopeBudget(e.target.value)} placeholder="0"/></div><button className="primary-button" onClick={addEnvelope}><Plus size={16}/> Add envelope</button></div></section><section className="panel"><PanelHead title="Write down money" sub="A little note for every peso"/><div className="toggle-group">{['spent','got','saved'].map(k=><button key={k} className={transactionKind===k?'selected':''} onClick={()=>setTransactionKind(k)}>{k==='spent'?'I spent':k==='got'?'I got':'I saved'}</button>)}</div><div className="form-grid"><div><label>What for?</label><input value={transactionLabel} onChange={e=>setTransactionLabel(e.target.value)} placeholder="e.g. Weekly groceries"/></div><div><label>Amount (₱)</label><input type="number" value={transactionAmount} onChange={e=>setTransactionAmount(e.target.value)} placeholder="0"/></div><button className="primary-button" onClick={addTransaction}>Save money note</button></div></section><section className="panel"><PanelHead title="This month's list" sub="Your little money journal"/>{data.transactions.length===0?<Empty text="No receipts this month yet."/>:data.transactions.map((t:any)=><div className="simple-row" key={t.id}><span>{t.kind==='spent'?'↗':t.kind==='got'?'↙':'♡'} {t.label}</span><b>{t.kind==='spent'?'-':'+'}{money(t.amount)}</b></div>)}</section></>
}
