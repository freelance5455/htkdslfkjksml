SafeNex - Phone-only HTML-to-APK build

This folder is intentionally packaged as a normal web project so it can be uploaded to a ZIP-to-APK / HTML-to-APK builder.

IMPORTANT:
1. The main file MUST be named index.html and be at the top level of the ZIP. It is already prepared that way.
2. In the APK builder, enable the CAMERA permission. SafeNex's scanner uses camera video through the browser/WebView.
3. Enable INTERNET permission because SafeNex loads html5-qrcode, ZXing Browser, Tesseract.js and product data over HTTPS.
4. Use Portrait orientation if offered.
5. After installing the APK, open SafeNex and start the scanner. Android should request Camera permission. If it does not, check Android Settings > Apps > SafeNex > Permissions > Camera.

The scanner code was kept intact and an explicit getUserMedia camera request was added before the scanner starts, so builders that support WebView camera permission can surface the native camera permission prompt.
