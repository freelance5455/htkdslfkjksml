/* JOSTECH — COURS 09 : GÉNIE INFORMATIQUE ET LOGICIEL */
registerDisciplineLevels(9, {
  1: {
    label: "Niveau 1 — Fondamental",
    subtitle: "Cycle de vie logiciel (SDLC), Cycle en V / Cascade et Méthodes Agiles.",
    chapters: [{
      id: "gl-1-1", title: "Chapitre 1 : Méthodes de Développement",
      lessons: [{
        id: "gl-1-1-1", title: "Leçon 1 : Cycle en Cascade vs Méthodes Agiles (Scrum)", duration: "25 min",
        objectives: ["Connaître les étapes du cycle de vie logiciel.", "Comparer Cascade rigide et itérations Agiles (Scrum)."],
        prerequisites: ["Notions de programmation."],
        sections: [
          { type: "theory", title: "De la Cascade à l'Agilité", text: "Tout logiciel suit un cycle : Analyse des besoins → Conception → Développement → Tests → Déploiement → Maintenance. Le modèle en Cascade enchaîne ces étapes une seule fois (adapté si tout est figé d'avance). L'approche Agile (Scrum) livre par petites itérations courtes appelées Sprints (1 à 4 semaines), exactement comme nous avons construit JOSTECH phase par phase !" },
          { type: "table", title: "Rôles clés en Scrum", headers: ["Rôle / Artefact", "Responsabilité"], rows: [
            ["Product Owner", "Définit les priorités fonctionnelles (Product Backlog)."],
            ["Scrum Master", "Facilite la méthode et lève les blocages techniques."],
            ["Équipe Dev", "Conçoit, code et teste l'incrément à chaque Sprint."]
          ]}
        ],
        exercise: {
          question: "Pourquoi le modèle en Cascade est-il risqué pour une startup éducative dont les besoins utilisateurs évoluent chaque mois ?",
          solution: "Parce qu'en Cascade, le client ne voit le produit final qu'à la toute fin : si un besoin a changé en cours de route, tout modifier coûte extrêmement cher."
        },
        summary: "L'Agilité réduit les risques en livrant vite de petites versions fonctionnelles testées et améliorées en continu.",
        references: ["Manifeste Agile (2001).", "Sommerville, I. — Software Engineering."]
      }]
    }]
  },
  2: {
    label: "Niveau 2 — Intermédiaire",
    subtitle: "Architecture logicielle (MVC), modélisation UML et gestion de versions Git.",
    chapters: [{
      id: "gl-2-1", title: "Chapitre 2 : Architecture, UML et Git",
      lessons: [{
        id: "gl-2-1-1", title: "Leçon 1 : Architecture MVC, UML et Commandes Git", duration: "30 min",
        objectives: ["Séparer Modèle, Vue et Contrôleur (MVC).", "Maîtriser le flux de travail Git (add, commit, branch, merge)."],
        prerequisites: ["Niveau 1 — Génie logiciel."],
        sections: [
          { type: "definition", term: "Architecture MVC (Modèle - Vue - Contrôleur)", text: "• Modèle : gère les données et règles métier (ex: courses.js, quizzes.js).\n• Vue : s'occupe uniquement de l'affichage (ex: index.html, style.css).\n• Contrôleur : relie les actions utilisateur aux données (ex: app.js, quiz-engine.js)." },
          { type: "code", lang: "Git — Flux de travail collaboratif", code: "git status                  # Voir fichiers modifiés\ngit add .                   # Préparer les changements\ngit commit -m 'Ajout quiz'  # Enregistrer une version datée\ngit checkout -b feat-labo   # Créer une branche isolée" }
        ],
        exercise: {
          question: "Quel avantage procure la création d'une branche Git (feature branch) avant de développer une grosse fonctionnalité ?",
          solution: "Cela isole le code en chantier afin de ne jamais casser la branche principale stable (main) en production."
        },
        summary: "MVC garantit un code propre et modulaire, UML clarifie la conception et Git sécurise l'historique collaboratif.",
        references: ["Chacon, S. — Pro Git.", "Fowler, M. — UML Distilled."]
      }]
    }]
  },
  3: {
    label: "Niveau 3 — Avancé & Universitaire",
    subtitle: "Tests logiciels, qualité (CI/CD), dette technique et maintenance.",
    chapters: [{
      id: "gl-3-1", title: "Chapitre 3 : Qualité Logicielle & Tests",
      lessons: [{
        id: "gl-3-1-1", title: "Leçon 1 : Pyramide des Tests, CI/CD et Dette Technique", duration: "30 min",
        objectives: ["Distinguer tests unitaires, d'intégration et E2E.", "Maîtriser la dette technique et les 4 types de maintenance."],
        prerequisites: ["Niveau 2 — Architecture et Git."],
        sections: [
          { type: "table", title: "Pyramide des Tests Automatisés", headers: ["Niveau", "Cible", "Vitesse & Coût"], rows: [
            ["Tests Unitaires (Base)", "1 fonction isolée (ex: calcul note /20)", "Ultra rapides, nombreux, peu coûteux."],
            ["Tests d'Intégration", "Dialogue entre modules (API + Base)", "Vitesse moyenne."],
            ["Tests E2E (Sommet)", "Parcours complet utilisateur simulé", "Lents et coûteux, limités aux flux critiques."]
          ]},
          { type: "warning", title: "La Dette Technique", text: "Choisir une solution bâclée pour aller vite aujourd'hui crée une « dette » : chaque future modification deviendra de plus en plus lente et coûteuse en maintenance corrective, adaptative ou évolutive." }
        ],
        exercise: {
          question: "Un logiciel fonctionne bien, mais on le met à jour pour s'adapter à une nouvelle version d'Android. Quel type de maintenance est-ce (corrective, adaptative ou perfective) ?",
          solution: "Maintenance adaptative (adaptation à un nouvel environnement matériel ou logiciel)."
        },
        summary: "La qualité logicielle repose sur des tests automatisés (CI/CD), une documentation claire et le remboursement régulier de la dette technique.",
        references: ["Martin, R. C. — Clean Code & Clean Architecture."]
      }]
    }]
  }
});