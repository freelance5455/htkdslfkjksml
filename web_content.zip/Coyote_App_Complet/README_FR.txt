COYOTE — PROJET COMPLET

Le dossier coyote-web contient une version directement testable dans un navigateur.
Le dossier coyote-android contient un projet Android Studio WebView prêt à être ouvert.

Fonctions: chats, recherche, contacts, appels (démo), profil, thème clair/sombre,
stockage local et assistant IA local de démonstration.

Pour produire l'APK: ouvrir coyote-android dans Android Studio, laisser Gradle se synchroniser,
puis Build > Build APK(s). Le fichier APK sera généré par Android Studio.

La vraie IA en ligne et les vrais appels/messages entre téléphones nécessitent un serveur
et des services réseau; cette version ne prétend pas fournir cela hors connexion.
