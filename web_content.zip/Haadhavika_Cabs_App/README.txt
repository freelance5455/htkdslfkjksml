HAADHAVIKA CABS WALAJAPET — BOOKING & BILLING SOFTWARE V2

WHAT WORKS NOW
- Responsive browser app for mobile and computer.
- Unique sequential booking IDs (HC-00001, HC-00002, ...).
- Customer/trip history with search and edit.
- Car ID can be automatically generated sequentially (HC-CAR-001, HC-CAR-002...) or assigned manually; ID is saved per booking, shown in office history, customer bill, bill text share, and CSV export. Search history by Car ID for office analysis.
- Swift and WagonR, separate AC / Non AC tariff.
- Trip start/closing date/time, KM, waiting charge, toll/parking, night halt, discount.
- Automatic fare/total calculation.
- Customer bill view; Print / Save PDF via browser print dialog.
- Share bill text using device share sheet, or copy/paste into WhatsApp.
- CSV export and JSON backup/restore.

IMPORTANT STORAGE LIMITATION
This version saves data in the current browser on the current device. It does NOT yet sync between mobile and computer. Cloud sync requires a Firebase project and secure rules.

TARIFF DEFAULTS (editable in Settings)
Swift: Non AC ₹11/km, AC ₹12/km, fixed charge ₹95.
WagonR: Non AC ₹10/km, AC ₹11/km, fixed charge ₹75 (temporary Indica-style tariff because the provided tariff image does not list WagonR separately).
Trip fare = KM × rate + fixed charge.
Total = trip fare + waiting + toll/parking + night halt − discount.
Confirm whether the fixed charges should remain as these values.

HOW TO RUN
1. Unzip the package.
2. Open index.html in Chrome, Edge, or another modern browser.
3. For a home-screen shortcut on Android, host it on HTTPS first, then use browser menu > Add to Home screen.
4. To save a customer bill as PDF: select booking > Print / Save PDF > choose Save as PDF in the print dialog.
5. Export JSON backups regularly. Browser data may be lost if browser storage is cleared.

CLOUD SETUP NEXT STEP
To enable actual cloud sync:
1. Create a Firebase project at https://console.firebase.google.com/
2. Add a Web app and copy the Firebase config.
3. Enable Cloud Firestore.
4. Set up Firebase Authentication (recommended) and Firestore security rules that only allow authorized company users.
5. Integrate Firebase SDK and replace local save/load functions with authenticated Firestore reads/writes.
6. Host on HTTPS (e.g. Firebase Hosting). Use the same project on phone and computer.
Do not publish database credentials or leave Firestore open to the public. Firebase client config is not a secret, but database access must be protected with authentication and security rules.

WHATSAPP NOTE
The app can share bill text or produce a PDF for manual sharing. Fully automatic WhatsApp delivery requires WhatsApp Business Platform/API, customer opt-in, a configured business account, and backend integration. This package does not send automatic WhatsApp messages by itself.

WAITING HOURS UPDATE
- Enter Start Date & Time and Closing Date & Time.
- Enter Included / Free Hours for the trip (0 means all elapsed hours are chargeable as extra time).
- The app calculates extra waiting hours automatically, rounding any partial extra hour up to a whole hour.
- Enter Waiting Rate per Hour manually (default ₹60, editable each trip).
- Waiting Charge is automatically calculated and is read-only.
- If the closing time is blank, extra waiting hours remain 0 until a closing time is entered.


DRIVER PROFILE AND BILL SHARING UPDATE
- Driver Details page appears first. Add driver name, phone number, vehicle registration number and driver/company ID.
- Driver ID is automatically generated as DRV-0001, DRV-0002, etc.
- Assign a saved driver to a booking; their phone number fills automatically and can be edited in the booking.
- Customer bill includes assigned driver details.
- Separate Share to Customer and Share to Driver buttons prepare the bill text for the phone's share sheet or clipboard. Choose WhatsApp/contact manually.
- This app does not send messages automatically in the background. Automated WhatsApp delivery requires WhatsApp Business Platform/API and backend configuration.
- Driver profiles are currently stored in this browser. Include them in JSON backups. Cloud sync is not configured.


WAITING HOURS AUTO / MANUAL UPDATE
- Choose Automatic mode to calculate extra waiting hours from closing time minus start time and included/free hours. Partial extra hours round up to a whole hour.
- Choose Manual mode to type the extra waiting hours yourself.
- Waiting hourly rates are configurable in Tariff Settings by vehicle and AC type. Defaults are Swift ₹70/hour (AC and Non AC) and WagonR ₹60/hour (AC and Non AC), based on the previously discussed rates; please confirm/update these in Settings.
- You can override the waiting rate for an individual booking. Waiting charge and total bill recalculate automatically.
