MY SALARY WALLET — BLACK & GOLD HTML VERSION

FILES
- index.html: editable HTML source for the app
- README_HI.txt: this guide

FEATURES
- Monthly salary default ₹12,000
- Present / Absent attendance tracking
- Base salary, overtime amount, and night allowance calculated separately
- Default salary calculation: ₹12,000 / 30 = ₹400 per Present day
- Overtime rate default ₹50/hour; editable
- Night allowance default ₹0/day; editable
- Time In / Time Out fields
- Attendance history, CSV export, JSON backup/restore
- Black and gold design
- Records stored locally in the browser/device

HOW TO OPEN ON ANDROID
1. Extract the ZIP in your phone's file manager (e.g. ZArchiver).
2. Open index.html with Chrome or another browser.
3. Change salary settings if needed, then add attendance.
4. Use JSON Backup regularly. Clearing browser storage may delete records.

IMPORTANT
This is an HTML app, not an installed APK. Telegram integration is not connected yet and requires a secure backend/webhook. Never place the Telegram bot token in the HTML file. Payroll logic is a starter calculation; confirm it matches your employer's policy before relying on it.
