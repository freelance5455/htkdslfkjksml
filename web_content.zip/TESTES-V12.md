# Testes da versão v12

## Verificações executadas
- `node --check` nos três blocos de JavaScript extraídos de `index.html`.
- `node --check` no servidor Node.js.
- HTML sem IDs duplicados.
- `index.html`, `web/index.html` e `www/index.html` mantidos byte a byte idênticos.
- Manifestos nas três rotas com `orientation: landscape` e `display: fullscreen`.
- Configuração inicial de IA sem URL placeholder e segredo de API fora do frontend.
- Checagem estática de referências relativas dos arquivos usados pelo HTML.
- Diálogo local usa a mensagem digitada; diálogo remoto recebe a mensagem atual e histórico anterior sem duplicar o turno atual.
- Verificações estáticas para terreno em altura, colisões, movimento autônomo e espécies místicas.

## Limite
Não foi possível validar a compilação pelo aplicativo HTML to APK nem executar a experiência em um telefone físico neste ambiente. Este ZIP é o projeto web para conversão, não um APK já compilado. O motor 3D usa Three.js por CDN e precisa de internet para seu carregamento inicial.
