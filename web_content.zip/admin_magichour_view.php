<?php
$mhKeyPresent=mh_api_key()!=='';
$mhEnabled=mh_setting('enabled','0')==='1';
$mhPrice=max(1,(int)mh_setting('credit_price','30'));
$mhModes=implode(', ',mh_modes());$mhAccountCredits=mh_setting('account_credits','Not checked');$mhAccountTier=mh_setting('account_tier','Not checked');$mhLastTest=mh_setting('last_test_at','Never');
$mhJobs=0;$mhFailed=0;$mhSpent=0;
try{$mhJobs=(int)db()->query("SELECT COUNT(*) FROM platform_jobs WHERE model='magic-hour-lip-sync'")->fetchColumn();$mhFailed=(int)db()->query("SELECT COUNT(*) FROM platform_jobs WHERE model='magic-hour-lip-sync' AND status='failed'")->fetchColumn();$mhSpent=(int)db()->query("SELECT COALESCE(SUM(-amount),0) FROM credit_transactions WHERE reason='Magic Hour Lip Sync' AND amount<0")->fetchColumn();}catch(Throwable $ignored){}
?>
<section class="data-panel">
 <div class="data-panel-head"><h2>Magic Hour · Lip Sync</h2><span><?=$mhKeyPresent?'API key stored':'API key missing'?></span></div>
 <p class="muted-copy">Configure Magic Hour for the AI Lip Sync mode inside Video Edit Studio. The permanent key is encrypted with the platform's AES-256-GCM key and never displayed after saving.</p>
 <form method="post" class="admin-form">
  <input type="hidden" name="_csrf" value="<?=$e(csrf_token())?>">
  <input type="hidden" name="admin_action" value="save_magichour_settings">
  <label>Magic Hour API key <input type="password" name="magichour_api_key" autocomplete="new-password" placeholder="<?=$mhKeyPresent?'Stored key — leave blank to keep it':'Paste Magic Hour API key'?>"></label>
  <label>Enabled generation modes <input name="magichour_modes" maxlength="250" value="<?=$e($mhModes)?>" required><small>Comma-separated. The documentation currently demonstrates lite; add other names only after confirming they are enabled for your account.</small></label>
  <label>Anonymoux credits per generation <input type="number" name="magichour_credit_price" min="1" max="100000" value="<?=$mhPrice?>" required></label>
  <label class="admin-check"><input type="checkbox" name="magichour_enabled" value="1" <?=$mhEnabled?'checked':''?>> Enable Magic Hour Lip Sync for users</label>
  <button class="admin-button primary" type="submit">Save Magic Hour settings</button>
 </form>
 <form method="post" style="margin-top:12px">
  <input type="hidden" name="_csrf" value="<?=$e(csrf_token())?>">
  <input type="hidden" name="admin_action" value="test_magichour_connection">
  <button class="admin-button" type="submit" <?=$mhKeyPresent?'':'disabled'?>>Test API connection</button>
 </form>
</section>
<section class="admin-stat-grid" style="margin-top:16px">
 <article class="admin-stat"><span>LIP SYNC JOBS</span><strong><?=$mhJobs?></strong><small>Recorded provider jobs</small></article>
 <article class="admin-stat"><span>FAILED JOBS</span><strong><?=$mhFailed?></strong><small>Includes uncertain submissions</small></article>
 <article class="admin-stat"><span>USER CREDITS DEBITED</span><strong><?=number_format($mhSpent)?></strong><small>Before any refunds</small></article>
 <article class="admin-stat"><span>MAGIC HOUR API CREDITS</span><strong><?=htmlspecialchars($mhAccountCredits)?></strong><small><?=htmlspecialchars($mhAccountTier)?> tier · <?=htmlspecialchars($mhLastTest)?></small></article>
</section>
<section class="data-panel"><div class="data-panel-head"><h2>Integration safeguards</h2><span>Shared hosting</span></div>
 <ul class="muted-copy"><li>PHP receives and validates both files, then forwards them to Magic Hour's signed HTTPS upload URLs.</li><li>Provider job IDs and outputs are recorded in the shared Video Edit Studio history.</li><li>Failed provider jobs receive an idempotent Anonymoux credit refund.</li><li>Transport failures with an uncertain provider submission are held for administrator review instead of risking a duplicate charge.</li><li>Large uploads remain limited by PHP upload size, POST size, execution time and available storage.</li></ul>
</section>
