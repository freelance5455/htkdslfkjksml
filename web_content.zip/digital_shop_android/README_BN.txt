DIGITAL SHOP Android App - Source Project

এই ZIP ফাইলে Android Studio-তে খোলার উপযোগী অ্যাপের সোর্স প্রজেক্ট আছে। এটি ইতিমধ্যে কম্পাইল করা APK নয়।

APK বানানোর সহজ পদ্ধতি:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. এই ZIP ফাইল Extract করুন।
3. Android Studio > Open নির্বাচন করে digital_shop_android ফোল্ডারটি খুলুন।
4. Gradle sync সম্পূর্ণ হতে দিন (ইন্টারনেট লাগবে)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
6. সফল হলে app/build/outputs/apk/debug/app-debug.apk ফাইলটি পাবেন।
7. APK ফোনে পাঠিয়ে ইনস্টল করতে পারেন। ফোনে অজানা উৎস থেকে ইনস্টল করার অনুমতি চাইতে পারে।

অ্যাপের বৈশিষ্ট্য:
- DIGITAL SHOP নাম
- RC ও Driving Licence পরিষেবার অনুরোধ
- Bike ও Car Insurance কোটেশন অনুরোধ
- ফর্ম থেকে WhatsApp-এ বার্তা পাঠানো
- যোগাযোগ নম্বর: 9830525631

গুরুত্বপূর্ণ:
- এই প্রজেক্টে backend/database বা অ্যাডমিন প্যানেল নেই। ফর্মের তথ্য WhatsApp বার্তায় যায়; অ্যাপ নিজে কাস্টমার ডেটা সংরক্ষণ করে না।
- ইন্স্যুরেন্স পলিসি ইস্যু বা সরকারি RTO কাজের জন্য প্রয়োজনীয় অনুমোদন/অফিসিয়াল চ্যানেল আলাদাভাবে লাগবে।
- Play Store প্রকাশের জন্য আলাদা signing ও policy যাচাই দরকার।


আপডেট: DIGITAL SHOP এখন বাংলা, हिन्दी ও English ভাষা সমর্থন করে। RC Transfer, RC/DL Mobile Update (সরকারি যাচাইকরণ অনুযায়ী), Learner Licence, PUC, Challan, Fitness, Permit, Insurance Quote/Renewal সহ পরিষেবা তালিকা যুক্ত হয়েছে। এই প্রজেক্ট APK নয়; Android build environment-এ compile/sign করতে হবে।


আপডেট: অ্যাপের উপরে আপনার দেওয়া DIGITAL SHOP লোগো যোগ করা হয়েছে। পরিষেবার তালিকায় “Driving Licence Apply / ড্রাইভিং লাইসেন্স আবেদন” এবং “Learner Licence Apply / লার্নার লাইসেন্স আবেদন” রয়েছে।
