J CUP TEA SHOP — ANDROID APP PROJECT

This is the Android Studio project source for your J Cup Tea Shop sales app.
It contains the app interface and an Android WebView wrapper. It is not a compiled APK.

PRODUCTS AND PRICES INCLUDED
Tea ₹15; Coffee ₹20; Boost ₹20; Horlicks ₹20; Suku Tea ₹15; Badam ₹20;
Lemon Tea ₹15; Lemon Tea with Honey ₹20; Biscuits ₹5 and ₹10;
Cigarettes: Small ₹15, Wave ₹10, Indimint ₹15, Kings ₹25, Lights ₹25,
Connect ₹25, Flake ₹12, Wills ₹13; Chocolate ₹1; Muruku ₹5; Nipat ₹5.

FEATURES
- Plus/minus quantity counters
- Automatic daily sales total and expenses subtraction
- Save and reopen daily records on the phone
- Daily report that can be copied into WhatsApp or Notes
- Reset current counts without deleting saved history

HOW TO BUILD THE APK
1. Install Android Studio on a computer from the official Android developer website.
2. Extract this ZIP file.
3. In Android Studio choose Open, then select the extracted JCupTeaShop folder.
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When finished, choose Locate. The APK is normally in app/build/outputs/apk/debug/app-debug.apk.
7. Transfer that APK to your Android phone, tap it, and allow installation from that source if Android asks.

The current execution environment did not have the Android SDK/Gradle build tools installed, so a compiled APK could not be produced here. The project source is provided so it can be built with Android Studio.

UPDATED FEATURES (Oct 2026)
- Current counts and expenses auto-save on this phone and return after refresh. The report panel itself is hidden after refresh.
- Saved history and all-time saved sales remain until the user deletes app data or clears history.
- Backup Data downloads a JSON backup file; Restore Backup imports it and merges saved dates. Keep backup files in Downloads and/or another safe location.
- Added Water Bottle ₹10, ₹20, ₹30 and Juice Bottle ₹10.

Important: local storage is on this device, not cloud storage. Export backups regularly. Uninstalling/clearing app data may erase local records.
