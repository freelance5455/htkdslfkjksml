# PAMIR — Android build with native Gallery

## What is included
- `www/index.html` — your existing PAMIR app, unchanged except: the Home gallery icon now calls `openPamirDeviceGallery()`, and two files are linked (`pamir-gallery.css`, `pamir-gallery.js`).
- `www/pamir-gallery.js|css` — full-screen Gallery (All / Photos / Videos / Albums), lazy thumbnails, paging, permission screens, swipe viewer with pinch/double-tap zoom and video playback.
- `native/java/af/pamir/app/PamirGalleryPlugin.java` — Capacitor plugin using Android MediaStore (read-only).
- `native/java/af/pamir/app/MainActivity.java` — registers the plugin.
- `setup-android.sh` — creates the Android project, copies native files, adds manifest permissions.

Opened in a normal browser (not the Android app), the icon falls back to PAMIR's existing media picker / publisher.

## Permissions
- Android 13+: READ_MEDIA_IMAGES, READ_MEDIA_VIDEO
- Android 14+: READ_MEDIA_VISUAL_USER_SELECTED (partial access, with a "Manage" button to pick more)
- Android 12 and older: READ_EXTERNAL_STORAGE (maxSdkVersion 32)

Denied → "Allow access" button. Permanently denied → "Open settings". Returning to the app re-checks permission automatically. New photos/videos refresh the grid (MediaStore ContentObserver).

## Build
Requirements: Node 18+, JDK 17, Android Studio / Android SDK (API 34).

    bash setup-android.sh
    cd android && ./gradlew assembleDebug
    # APK: android/app/build/outputs/apk/debug/app-debug.apk

After editing anything in `www/`, run `npx cap sync android` again.

## Feed publishing
The Gallery only browses. It never uploads or posts. PAMIR's existing publishing flow (`openPamirGallery`) is untouched.

## Verification for v2
- Debug APK successfully compiled with JDK 17 and Android SDK 34.
- APK signature verified using Android apksigner.
- Native plugin is registered, and the media permissions are present in the packaged manifest.
- JavaScript regression checks cover viewer pagination, stale requests, permission retry and Android foreground refresh.
- This is a debug-signed test APK, not a store-release build.
- No Android device or emulator test was performed: real MediaStore queries, selected-photo access, swipe/zoom and playback must still be checked on a phone.
- The existing web preview is unchanged; install the APK to access native phone media.

The generated Android project is included. Run `bash setup-android.sh` before rebuilding after native changes; it copies the authoritative Java sources from `native/`. Run `node --test tests/gallery.test.cjs` for regression checks.
