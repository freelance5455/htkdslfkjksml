package af.pamir.app;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Size;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * PAMIR native gallery: reads real photos/videos from Android MediaStore.
 * Read-only: never modifies or deletes user media.
 */
@CapacitorPlugin(
    name = "PamirGallery",
    permissions = {
        @Permission(alias = "images", strings = { Manifest.permission.READ_MEDIA_IMAGES }),
        @Permission(alias = "video", strings = { Manifest.permission.READ_MEDIA_VIDEO }),
        @Permission(alias = "selected", strings = { "android.permission.READ_MEDIA_VISUAL_USER_SELECTED" }),
        @Permission(alias = "legacy", strings = { Manifest.permission.READ_EXTERNAL_STORAGE })
    }
)
public class PamirGalleryPlugin extends Plugin {

    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private ContentObserver observer;
    private boolean askedOnce = false;

    @Override
    public void load() {
        askedOnce = getContext().getSharedPreferences("pamir_gallery", 0).getBoolean("asked", false);
        Handler h = new Handler(Looper.getMainLooper());
        observer = new ContentObserver(h) {
            private long last = 0;
            @Override
            public void onChange(boolean selfChange) {
                long now = System.currentTimeMillis();
                if (now - last < 1500) return; // debounce bursts
                last = now;
                notifyListeners("mediaChanged", new JSObject());
            }
        };
        ContentResolver cr = getContext().getContentResolver();
        cr.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer);
        cr.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer);
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        JSObject o = new JSObject();
        o.put("status", status());
        notifyListeners("appResumed", o);
    }

    @Override
    protected void handleOnDestroy() {
        if (observer != null) getContext().getContentResolver().unregisterContentObserver(observer);
        io.shutdownNow();
        super.handleOnDestroy();
    }

    // ---------- permissions ----------

    private boolean has(String p) {
        return ContextCompat.checkSelfPermission(getContext(), p) == PackageManager.PERMISSION_GRANTED;
    }

    /** granted | limited | denied | denied_permanent | prompt */
    private String status() {
        int sdk = Build.VERSION.SDK_INT;
        boolean full;
        if (sdk >= 33) full = has(Manifest.permission.READ_MEDIA_IMAGES) && has(Manifest.permission.READ_MEDIA_VIDEO);
        else full = has(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (full) return "granted";
        if (sdk >= 33 && (has(Manifest.permission.READ_MEDIA_IMAGES) || has(Manifest.permission.READ_MEDIA_VIDEO))) return "limited";
        if (sdk >= 34 && has("android.permission.READ_MEDIA_VISUAL_USER_SELECTED")) return "limited";
        if (!askedOnce) return "prompt";
        String[] aliases = sdk >= 34 ? new String[] { "images", "video", "selected" }
            : sdk >= 33 ? new String[] { "images", "video" } : new String[] { "legacy" };
        for (String alias : aliases) {
            if (getPermissionState(alias) != PermissionState.DENIED) return "denied";
        }
        return "denied_permanent";
    }

    private JSObject statusObj() {
        JSObject o = new JSObject();
        o.put("status", status());
        o.put("sdk", Build.VERSION.SDK_INT);
        o.put("canManageSelected", Build.VERSION.SDK_INT >= 34);
        return o;
    }

    @PluginMethod
    public void getStatus(PluginCall call) { call.resolve(statusObj()); }

    @PluginMethod
    public void requestAccess(PluginCall call) {
        askedOnce = true;
        getContext().getSharedPreferences("pamir_gallery", 0).edit().putBoolean("asked", true).apply();
        int sdk = Build.VERSION.SDK_INT;
        String[] aliases;
        if (sdk >= 34) aliases = new String[] { "images", "video", "selected" };
        else if (sdk >= 33) aliases = new String[] { "images", "video" };
        else aliases = new String[] { "legacy" };
        requestPermissionForAliases(aliases, call, "onAccessResult");
    }

    @PermissionCallback
    private void onAccessResult(PluginCall call) { call.resolve(statusObj()); }

    @PluginMethod
    public void openSettings(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", getContext().getPackageName(), null));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    // ---------- queries ----------

    private Uri filesUri() {
        return Build.VERSION.SDK_INT >= 29
            ? MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
            : MediaStore.Files.getContentUri("external");
    }

    private String typeSelection(String type) {
        String img = MediaStore.Files.FileColumns.MEDIA_TYPE + "=" + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;
        String vid = MediaStore.Files.FileColumns.MEDIA_TYPE + "=" + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
        if ("photos".equals(type)) return "(" + img + ")";
        if ("videos".equals(type)) return "(" + vid + ")";
        return "(" + img + " OR " + vid + ")";
    }

    private Cursor query(String[] proj, String sel, String[] args, int limit, int offset) {
        ContentResolver cr = getContext().getContentResolver();
        String order = MediaStore.Files.FileColumns.DATE_ADDED + " DESC";
        if (Build.VERSION.SDK_INT >= 30) {
            Bundle b = new Bundle();
            b.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel);
            b.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            b.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, new String[] { MediaStore.Files.FileColumns.DATE_ADDED });
            b.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING);
            if (limit > 0) {
                b.putInt(ContentResolver.QUERY_ARG_LIMIT, limit);
                b.putInt(ContentResolver.QUERY_ARG_OFFSET, offset);
            }
            return cr.query(filesUri(), proj, b, null);
        }
        if (limit > 0) order += " LIMIT " + limit + " OFFSET " + offset;
        return cr.query(filesUri(), proj, sel, args, order);
    }

    @PluginMethod
    public void getMedia(PluginCall call) {
        final String type = call.getString("type", "all");
        final String album = call.getString("albumId", null);
        final int limit = Math.max(1, Math.min(call.getInt("limit", 60), 300));
        final int offset = Math.max(0, call.getInt("offset", 0));
        io.execute(() -> {
            try {
                String sel = typeSelection(type);
                String[] args = null;
                if (album != null && !album.isEmpty()) {
                    sel += " AND " + MediaStore.MediaColumns.BUCKET_ID + "=?";
                    args = new String[] { album };
                }
                String[] proj = {
                    MediaStore.Files.FileColumns._ID,
                    MediaStore.Files.FileColumns.MEDIA_TYPE,
                    MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.MIME_TYPE,
                    MediaStore.MediaColumns.DATE_ADDED,
                    MediaStore.MediaColumns.SIZE,
                    MediaStore.MediaColumns.WIDTH,
                    MediaStore.MediaColumns.HEIGHT,
                    MediaStore.Video.VideoColumns.DURATION
                };
                JSArray items = new JSArray();
                try (Cursor c = query(proj, sel, args, limit, offset)) {
                    if (c != null) while (c.moveToNext()) {
                        long id = c.getLong(0);
                        boolean video = c.getInt(1) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
                        Uri base = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                        JSObject o = new JSObject();
                        o.put("id", String.valueOf(id));
                        o.put("type", video ? "video" : "image");
                        o.put("name", c.getString(2));
                        o.put("mime", c.getString(3));
                        o.put("dateAdded", c.getLong(4) * 1000L);
                        o.put("size", c.getLong(5));
                        o.put("width", c.getInt(6));
                        o.put("height", c.getInt(7));
                        o.put("duration", video ? c.getLong(8) : 0);
                        o.put("uri", ContentUris.withAppendedId(base, id).toString());
                        items.put(o);
                    }
                }
                int total = 0;
                try (Cursor c = query(new String[] { MediaStore.Files.FileColumns._ID }, sel, args, 0, 0)) {
                    if (c != null) total = c.getCount();
                }
                JSObject r = new JSObject();
                r.put("items", items);
                r.put("total", total);
                r.put("offset", offset);
                r.put("status", status());
                call.resolve(r);
            } catch (SecurityException se) {
                call.reject("Permission denied", "PERMISSION_DENIED");
            } catch (Exception e) {
                call.reject(e.getMessage() == null ? "Media query failed" : e.getMessage(), "QUERY_FAILED");
            }
        });
    }

    @PluginMethod
    public void getAlbums(PluginCall call) {
        io.execute(() -> {
            try {
                String[] proj = {
                    MediaStore.Files.FileColumns._ID,
                    MediaStore.Files.FileColumns.MEDIA_TYPE,
                    MediaStore.MediaColumns.BUCKET_ID,
                    MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
                };
                Map<String, JSObject> map = new LinkedHashMap<>();
                Map<String, Integer> counts = new LinkedHashMap<>();
                try (Cursor c = query(proj, typeSelection("all"), null, 0, 0)) {
                    if (c != null) while (c.moveToNext()) {
                        String bid = c.getString(2);
                        if (bid == null) continue;
                        counts.put(bid, (counts.containsKey(bid) ? counts.get(bid) : 0) + 1);
                        if (!map.containsKey(bid)) { // first row = newest = cover
                            long id = c.getLong(0);
                            boolean video = c.getInt(1) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
                            JSObject a = new JSObject();
                            a.put("id", bid);
                            String n = c.getString(3);
                            a.put("name", n == null ? "Album" : n);
                            a.put("coverId", String.valueOf(id));
                            a.put("coverType", video ? "video" : "image");
                            map.put(bid, a);
                        }
                    }
                }
                JSArray arr = new JSArray();
                for (Map.Entry<String, JSObject> e : map.entrySet()) {
                    e.getValue().put("count", counts.get(e.getKey()));
                    arr.put(e.getValue());
                }
                JSObject r = new JSObject();
                r.put("albums", arr);
                call.resolve(r);
            } catch (SecurityException se) {
                call.reject("Permission denied", "PERMISSION_DENIED");
            } catch (Exception e) {
                call.reject(e.getMessage() == null ? "Album query failed" : e.getMessage(), "QUERY_FAILED");
            }
        });
    }

    /** Creates (or reuses) a small cached JPEG thumbnail; returns an absolute file path. */
    @PluginMethod
    public void getThumbnail(PluginCall call) {
        final String idStr = call.getString("id");
        final String type = call.getString("type", "image");
        final int size = Math.max(96, Math.min(call.getInt("size", 320), 640));
        if (idStr == null) { call.reject("id required"); return; }
        io.execute(() -> {
            try {
                String permission = "video".equals(type) ? Manifest.permission.READ_MEDIA_VIDEO : Manifest.permission.READ_MEDIA_IMAGES;
                if (Build.VERSION.SDK_INT >= 33 ? !(has(permission) || (Build.VERSION.SDK_INT >= 34 && has("android.permission.READ_MEDIA_VISUAL_USER_SELECTED")))
                    : !has(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    call.reject("Permission denied", "PERMISSION_DENIED"); return;
                }
                long id = Long.parseLong(idStr);
                File dir = new File(getContext().getCacheDir(), "pamir_thumbs");
                if (!dir.exists()) dir.mkdirs();
                File out = new File(dir, type + "_" + id + "_" + size + ".jpg");
                if (!out.exists() || out.length() == 0) {
                    boolean video = "video".equals(type);
                    Bitmap bmp;
                    ContentResolver cr = getContext().getContentResolver();
                    if (Build.VERSION.SDK_INT >= 29) {
                        Uri base = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                        bmp = cr.loadThumbnail(ContentUris.withAppendedId(base, id), new Size(size, size), null);
                    } else if (video) {
                        bmp = MediaStore.Video.Thumbnails.getThumbnail(cr, id, MediaStore.Video.Thumbnails.MINI_KIND, null);
                    } else {
                        bmp = MediaStore.Images.Thumbnails.getThumbnail(cr, id, MediaStore.Images.Thumbnails.MINI_KIND, null);
                    }
                    if (bmp == null) { call.reject("Thumbnail unavailable", "NOT_FOUND"); return; }
                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        bmp.compress(Bitmap.CompressFormat.JPEG, 82, fos);
                    }
                    bmp.recycle();
                }
                JSObject r = new JSObject();
                r.put("path", out.getAbsolutePath());
                call.resolve(r);
            } catch (SecurityException e) {
                call.reject("Permission denied", "PERMISSION_DENIED");
            } catch (Exception e) {
                call.reject("Media unavailable or deleted", "NOT_FOUND");
            }
        });
    }

    /** Android 14+: re-opens the system dialog so the user can pick more photos/videos. */
    @PluginMethod
    public void manageSelectedAccess(PluginCall call) {
        if (Build.VERSION.SDK_INT < 34) { call.resolve(statusObj()); return; }
        requestAccess(call);
    }
}
