#!/usr/bin/env bash
# Creates the Android project and installs the PAMIR native gallery plugin.
set -e
npm ci
[ -d android ] || npx cap add android
JAVA_DIR=android/app/src/main/java/af/pamir/app
mkdir -p "$JAVA_DIR"
cp native/java/af/pamir/app/*.java "$JAVA_DIR/"
MANIFEST=android/app/src/main/AndroidManifest.xml
if ! grep -q READ_MEDIA_IMAGES "$MANIFEST"; then
  python3 - "$MANIFEST" <<'PY'
import sys
p=sys.argv[1]; s=open(p).read()
perms='''    <!-- PAMIR Gallery: read-only access to device photos and videos -->
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_VISUAL_USER_SELECTED" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
'''
s=s.replace('</manifest>', perms+'</manifest>',1)
open(p,'w').write(s)
PY
fi
npx cap sync android
echo "Done. Build APK with: cd android && ./gradlew assembleDebug"
