/* PAMIR Device Gallery — real Android media via the native PamirGallery plugin.
   Browsing only: nothing here publishes to the PAMIR feed. */
(function () {
  'use strict';
  var Cap = window.Capacitor;
  var native = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform() && Cap.getPlatform() === 'android');
  var G = native ? (Cap.registerPlugin ? Cap.registerPlugin('PamirGallery') : (Cap.Plugins || {}).PamirGallery) : null;
  var PAGE = 60;

  var st = { tab: 'all', album: null, items: [], total: 0, loading: false, done: false, status: null, gen: 0 };
  var root, body, countEl, noteEl, titleEl, io, viewer, track;

  function src(pathOrUri) { return Cap.convertFileSrc(pathOrUri); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function dur(ms) { var s = Math.round(ms / 1000), m = Math.floor(s / 60); s = s % 60; return m + ':' + (s < 10 ? '0' : '') + s; }

  function build() {
    root = document.createElement('div');
    root.className = 'pgx';
    root.setAttribute('role', 'dialog');
    root.setAttribute('aria-modal', 'true');
    root.innerHTML =
      '<div class="pgx-bar"><button class="pgx-ic" data-a="back" aria-label="Back"><i class="fa-solid fa-arrow-right"></i></button>' +
      '<div class="pgx-title"><span data-t>Gallery</span><span class="pgx-count" data-c></span></div>' +
      '<button class="pgx-ic" data-a="refresh" aria-label="Refresh"><i class="fa-solid fa-rotate"></i></button></div>' +
      '<div class="pgx-tabs">' +
      '<button class="pgx-tab on" data-tab="all"><i class="fa-solid fa-images"></i> All</button>' +
      '<button class="pgx-tab" data-tab="photos"><i class="fa-solid fa-image"></i> Photos</button>' +
      '<button class="pgx-tab" data-tab="videos"><i class="fa-solid fa-video"></i> Videos</button>' +
      '<button class="pgx-tab" data-tab="albums"><i class="fa-solid fa-folder"></i> Albums</button></div>' +
      '<div data-n></div><div class="pgx-body" data-b></div>';
    document.body.appendChild(root);
    body = root.querySelector('[data-b]'); countEl = root.querySelector('[data-c]');
    noteEl = root.querySelector('[data-n]'); titleEl = root.querySelector('[data-t]');
    if (document.documentElement.dir !== 'rtl') root.querySelector('[data-a=back] i').className = 'fa-solid fa-arrow-left';

    root.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.dataset.a === 'back') { if (st.album) { st.album = null; setTab('albums'); } else close(); }
      else if (b.dataset.a === 'refresh') reload();
      else if (b.dataset.tab) { st.album = null; setTab(b.dataset.tab); }
      else if (b.dataset.album) { st.album = { id: b.dataset.album, name: b.dataset.name }; st.tab = 'all'; reload(); }
      else if (b.dataset.idx) openViewer(+b.dataset.idx);
      else if (b.dataset.act) act(b.dataset.act);
    });
    body.addEventListener('scroll', function () {
      if (body.scrollTop + body.clientHeight > body.scrollHeight - 600) loadMore();
    }, { passive: true });

    io = new IntersectionObserver(function (ents) {
      ents.forEach(function (en) { if (en.isIntersecting) { io.unobserve(en.target); thumb(en.target); } });
    }, { root: body, rootMargin: '400px' });

    if (G) {
      G.addListener('mediaChanged', function () { if (isOpen() && !(viewer && viewer.classList.contains('show'))) softRefresh(); });
      G.addListener('appResumed', function (r) {
        if (!isOpen()) return;
        closeViewer(); checkAndLoad(false);
      });
    }
    document.addEventListener('backbutton', function () { if (viewer && viewer.classList.contains('show')) closeViewer(); else if (isOpen()) close(); });
  }

  function isOpen() { return root && root.classList.contains('show'); }

  function setTab(t) {
    st.tab = t;
    root.querySelectorAll('.pgx-tab').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === t && !st.album); });
    reload();
  }

  function thumb(cell) {
    var id = cell.dataset.id, type = cell.dataset.type, gen = st.gen;
    G.getThumbnail({ id: id, type: type, size: 320 }).then(function (r) {
      if (gen !== st.gen || !cell.isConnected) return;
      var img = cell.querySelector('img');
      img.onload = function () { img.classList.add('ok'); };
      img.src = src(r.path);
    }).catch(function (e) {
      if (gen !== st.gen || !cell.isConnected) return;
      if (e && e.code === 'PERMISSION_DENIED') return checkAndLoad(false);
      cell.insertAdjacentHTML('beforeend', '<div class="pgx-gone"><i class="fa-solid fa-image-slash"></i></div>');
    });
  }

  function stateView(icon, title, text, buttons) {
    body.innerHTML = '<div class="pgx-state"><i class="fa-solid ' + icon + '"></i><h3>' + esc(title) + '</h3><p>' + esc(text) + '</p>' +
      (buttons || []).map(function (b) { return '<button class="pgx-btn ' + (b[2] || '') + '" data-act="' + b[0] + '">' + esc(b[1]) + '</button>'; }).join('') + '</div>';
    countEl.textContent = '';
  }

  function renderNote() {
    noteEl.innerHTML = st.status === 'limited'
      ? '<div class="pgx-note"><i class="fa-solid fa-circle-info"></i><span>PAMIR has access to only part of your media library.</span><button data-act="manage">Manage</button></div>'
      : '';
  }

  function act(a) {
    if (a === 'request') G.requestAccess().then(function (r) { st.status = r.status; afterStatus(); });
    else if (a === 'settings') G.openSettings();
    else if (a === 'manage') G.manageSelectedAccess().then(function (r) { st.status = r.status; afterStatus(); });
    else if (a === 'retry') checkAndLoad(false);
  }

  function checkAndLoad(prompt) {
    var gen = ++st.gen;
    io.disconnect();
    stateView('fa-spinner fa-spin', 'Loading…', '');
    G.getStatus().then(function (r) {
      if (gen !== st.gen || !isOpen()) return;
      st.status = r.status;
      if (prompt && r.status === 'prompt') {
        stateView('fa-photo-film', 'Allow access to your photos and videos',
          'PAMIR needs permission to show the photos and videos stored on this phone. Your media stays on your device and is never posted unless you choose to share it.',
          [['request', 'Allow access']]);
        renderNote();
        return;
      }
      afterStatus();
    }).catch(function () { stateView('fa-triangle-exclamation', 'Something went wrong', 'The gallery could not be opened.', [['retry', 'Try again']]); });
  }

  function afterStatus() {
    renderNote();
    var s = st.status;
    if (s === 'granted' || s === 'limited') return reload();
    if (s === 'denied_permanent')
      return stateView('fa-lock', 'Access is turned off', 'Gallery permission was denied. Open Android Settings → Permissions → Photos and videos and allow access, then return to PAMIR.', [['settings', 'Open settings']]);
    stateView('fa-lock', 'Permission needed', 'Without access to photos and videos, PAMIR cannot show your gallery.', [['request', 'Allow access']]);
  }

  function reload() {
    if (!(st.status === 'granted' || st.status === 'limited')) return afterStatus();
    io.disconnect();
    st.gen++; st.items = []; st.total = 0; st.done = false; st.loading = false;
    titleEl.textContent = st.album ? st.album.name : 'Gallery';
    body.scrollTop = 0;
    if (st.tab === 'albums' && !st.album) return loadAlbums();
    body.innerHTML = '<div class="pgx-grid" data-g></div><div class="pgx-more" data-m><i class="fa-solid fa-spinner fa-spin"></i></div>';
    loadMore();
  }

  function softRefresh() {
    // New media appears at the top; reload the current view keeping the user's place simple.
    var top = body.scrollTop; reload(); if (top < 50) body.scrollTop = 0;
  }

  function loadMore() {
    if (st.loading || st.done || st.tab === 'albums' && !st.album) return;
    var grid = body.querySelector('[data-g]'); if (!grid) return;
    st.loading = true;
    var gen = st.gen;
    G.getMedia({ type: st.tab, albumId: st.album ? st.album.id : undefined, offset: st.items.length, limit: PAGE }).then(function (r) {
      if (gen !== st.gen) return;
      st.loading = false; st.total = r.total;
      var start = st.items.length;
      st.items = st.items.concat(r.items);
      if (viewer && viewer.classList.contains('show')) appendSlides(start);
      if (r.items.length < PAGE || st.items.length >= r.total) st.done = true;
      countEl.textContent = '(' + r.total + ')';
      if (!st.items.length) {
        var w = st.tab === 'videos' ? 'videos' : st.tab === 'photos' ? 'photos' : 'photos or videos';
        return stateView('fa-images', 'No ' + w + ' yet', st.status === 'limited' ? 'You have not selected any ' + w + ' for PAMIR.' : 'There are no ' + w + ' on this device.', st.status === 'limited' ? [['manage', 'Select media']] : []);
      }
      var frag = document.createDocumentFragment();
      r.items.forEach(function (m, i) {
        var b = document.createElement('button');
        b.className = 'pgx-cell'; b.dataset.idx = start + i; b.dataset.id = m.id; b.dataset.type = m.type;
        b.setAttribute('aria-label', m.name || m.type);
        b.innerHTML = '<img alt="" decoding="async">' + (m.type === 'video' ? '<span class="pgx-dur"><i class="fa-solid fa-play"></i>' + dur(m.duration) + '</span>' : '');
        frag.appendChild(b); io.observe(b);
      });
      grid.appendChild(frag);
      var more = body.querySelector('[data-m]'); if (more && st.done) more.remove();
      if (!st.done && body.scrollHeight <= body.clientHeight + 600) loadMore();
    }).catch(function (e) {
      if (gen !== st.gen || !isOpen()) return;
      st.loading = false;
      if (e && e.code === 'PERMISSION_DENIED') return checkAndLoad(false);
      stateView('fa-triangle-exclamation', 'Could not load media', 'Please try again.', [['retry', 'Try again']]);
    });
  }

  function loadAlbums() {
    stateView('fa-spinner fa-spin', 'Loading albums…', '');
    var gen = st.gen;
    G.getAlbums().then(function (r) {
      if (gen !== st.gen) return;
      countEl.textContent = '(' + r.albums.length + ')';
      if (!r.albums.length) return stateView('fa-folder-open', 'No albums', 'No albums were found on this device.');
      body.innerHTML = '<div class="pgx-albums">' + r.albums.map(function (a) {
        return '<button class="pgx-album" data-album="' + esc(a.id) + '" data-name="' + esc(a.name) + '"><div class="pgx-cell" data-id="' + esc(a.coverId) + '" data-type="' + a.coverType + '"><img alt=""></div><b>' + esc(a.name) + '</b><span>' + a.count + '</span></button>';
      }).join('') + '</div>';
      body.querySelectorAll('.pgx-album .pgx-cell').forEach(function (c) { io.observe(c); });
    }).catch(function () { stateView('fa-triangle-exclamation', 'Could not load albums', '', [['retry', 'Try again']]); });
  }

  /* ---------------- viewer ---------------- */
  function buildViewer() {
    viewer = document.createElement('div');
    viewer.className = 'pgv';
    viewer.innerHTML = '<div class="pgv-bar"><button class="pgx-ic" data-v="back" aria-label="Back"><i class="fa-solid fa-arrow-' + (document.documentElement.dir === 'rtl' ? 'right' : 'left') + '"></i></button><div class="pgv-name" data-vn></div></div><div class="pgv-track" dir="ltr" data-vt></div>';
    document.body.appendChild(viewer);
    track = viewer.querySelector('[data-vt]');
    viewer.querySelector('[data-v=back]').onclick = closeViewer;
    var t; track.addEventListener('scroll', function () { clearTimeout(t); t = setTimeout(syncSlides, 80); }, { passive: true });
  }

  var cur = 0;
  function openViewer(i) {
    if (!viewer) buildViewer();
    track.innerHTML = '';
    appendSlides(0);
    viewer.classList.add('show');
    cur = i;
    requestAnimationFrame(function () { track.scrollLeft = i * track.clientWidth; syncSlides(); });
  }

  function appendSlides(start) {
    st.items.slice(start).forEach(function (_, i) { var s = document.createElement('div'); s.className = 'pgv-slide'; s.dataset.k = start + i; track.appendChild(s); });
  }

  function syncSlides() {
    var w = track.clientWidth || 1;
    cur = Math.round(track.scrollLeft / w);
    var m = st.items[cur];
    viewer.querySelector('[data-vn]').textContent = m ? m.name || '' : '';
    track.querySelectorAll('.pgv-slide').forEach(function (s) {
      var k = +s.dataset.k, near = Math.abs(k - cur) <= 1;
      if (!near) { if (s.firstChild) unload(s); return; }
      if (!s.firstChild) fill(s, st.items[k]);
      var v = s.querySelector('video'); if (v && k !== cur) v.pause();
    });
    if (cur >= st.items.length - 3 && !st.done) loadMore();
  }

  function unload(s) { var v = s.querySelector('video'); if (v) { v.pause(); v.removeAttribute('src'); v.load(); } s.innerHTML = ''; }

  function fill(s, m) {
    if (!m) return;
    if (m.type === 'video') {
      var v = document.createElement('video');
      v.controls = true; v.playsInline = true; v.preload = 'metadata'; v.src = src(m.uri);
      v.onerror = function () { s.innerHTML = '<div class="pgx-state"><i class="fa-solid fa-film"></i><p>This video is no longer available.</p></div>'; };
      s.appendChild(v);
    } else {
      var img = document.createElement('img');
      img.alt = m.name || ''; img.decoding = 'async'; img.src = src(m.uri);
      img.onerror = function () { s.innerHTML = '<div class="pgx-state"><i class="fa-solid fa-image"></i><p>This photo is no longer available.</p></div>'; };
      s.appendChild(img); zoomable(img);
    }
  }

  function zoomable(img) {
    var scale = 1, x = 0, y = 0, d0 = 0, s0 = 1, px = 0, py = 0, lastTap = 0;
    function apply() { img.style.transform = 'translate(' + x + 'px,' + y + 'px) scale(' + scale + ')'; track.style.overflowX = scale > 1 ? 'hidden' : 'auto'; }
    function dist(t) { return Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY); }
    img.addEventListener('touchstart', function (e) {
      if (e.touches.length === 2) { d0 = dist(e.touches); s0 = scale; }
      else if (e.touches.length === 1) {
        px = e.touches[0].clientX; py = e.touches[0].clientY;
        var now = Date.now(); if (now - lastTap < 280) { scale = scale > 1 ? 1 : 2.5; x = y = 0; apply(); } lastTap = now;
      }
    }, { passive: true });
    img.addEventListener('touchmove', function (e) {
      if (e.touches.length === 2) { e.preventDefault(); scale = Math.min(5, Math.max(1, s0 * dist(e.touches) / d0)); if (scale === 1) x = y = 0; apply(); }
      else if (e.touches.length === 1 && scale > 1) { e.preventDefault(); x += e.touches[0].clientX - px; y += e.touches[0].clientY - py; px = e.touches[0].clientX; py = e.touches[0].clientY; apply(); }
    }, { passive: false });
  }

  function closeViewer() {
    if (!viewer) return;
    track.querySelectorAll('.pgv-slide').forEach(unload);
    track.innerHTML = ''; track.style.overflowX = 'auto';
    viewer.classList.remove('show');
  }

  /* ---------------- open / close ---------------- */
  function open() {
    if (!native || !G) {
      // Not running inside the PAMIR Android app: keep the existing PAMIR media flow.
      if (typeof window.openPamirGallery === 'function') return window.openPamirGallery();
      return;
    }
    if (!root) build();
    root.classList.add('show');
    document.body.classList.add('feature-open');
    st.album = null; st.tab = 'all';
    root.querySelectorAll('.pgx-tab').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === 'all'); });
    checkAndLoad(true);
  }

  function close() {
    closeViewer();
    root.classList.remove('show');
    document.body.classList.remove('feature-open');
    st.gen++; io.disconnect(); body.innerHTML = ''; st.items = [];
  }

  window.openPamirDeviceGallery = open;
})();
