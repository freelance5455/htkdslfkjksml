const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
function harness() {
  const cells = [], listeners = {};
  let requests = 0;
  const plugin = {
    addListener(n, f) { listeners[n] = f; },
    getStatus() { requests++; return Promise.resolve({ status: 'granted' }); },
    getMedia() { return Promise.resolve({ items: [], total: 0 }); },
  };
  function element() {
    return { className: '', dataset: {}, innerHTML: '', textContent: '', clientWidth: 360,
      classList: { contains: () => true, add() {}, remove() {}, toggle() {} },
      querySelector: () => element(), querySelectorAll: () => [], addEventListener() {}, setAttribute() {},
      appendChild(n) { cells.push(n); }, insertAdjacentHTML() {} };
  }
  const track = element();
  const window = { Capacitor: { isNativePlatform: () => true, getPlatform: () => 'android', registerPlugin: () => plugin } };
  const context = { window, document: { createElement: element, body: { appendChild() {}, classList: element().classList }, documentElement: { dir: 'ltr' }, addEventListener() {} },
    IntersectionObserver: class { observe() {} unobserve() {} disconnect() {} }, setTimeout, clearTimeout, requestAnimationFrame: f => f() };
  let script = fs.readFileSync('www/pamir-gallery.js', 'utf8');
  script = script.replace('window.openPamirDeviceGallery = open;', `window.testGallery = { build, st, act, checkAndLoad, appendSlides, thumb, useTrack(t) { track = t; }, useViewer(v) { viewer = v; } }; window.openPamirDeviceGallery = open;`);
  vm.runInNewContext(script, context);
  const api = window.testGallery;
  api.build(); api.useTrack(track);
  return { api, cells, listeners, requests: () => requests, plugin, element };
}
test('viewer appends the next page after 60 loaded items', () => {
  const h = harness(); h.api.st.items = Array.from({ length: 120 }, (_, id) => ({ id }));
  h.api.appendSlides(60);
  assert.equal(h.cells.length, 60);
  assert.equal(h.cells[0].dataset.k, 60); assert.equal(h.cells[59].dataset.k, 119);
});
test('returning to foreground rechecks unchanged limited access', () => {
  const h = harness(); h.api.st.status = 'limited';
  h.listeners.appResumed({ status: 'limited' }); assert.equal(h.requests(), 1);
});
test('retry rechecks permission rather than reusing stale status', () => {
  const h = harness(); h.api.st.status = 'denied'; h.api.act('retry'); assert.equal(h.requests(), 1);
});
test('stale thumbnail completion does not display media after close or reload', async () => {
  const h = harness(); let resolve;
  h.plugin.getThumbnail = () => new Promise(r => { resolve = r; });
  let writes = 0;
  const cell = { dataset: { id: '1', type: 'image' }, isConnected: true, querySelector() { writes++; return {}; } };
  h.api.thumb(cell); h.api.st.gen++; resolve({ path: '/cache/1.jpg' });
  await Promise.resolve(); assert.equal(writes, 0);
});
