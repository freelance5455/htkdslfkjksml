# PAMIR — complete available source code

This single ZIP contains both deliveries, kept separate:

- `android-app/`: original PAMIR web app, native Android Gallery plugin, generated Android project, resources, Gradle wrapper, dependency lockfile, setup script and gallery tests.
- `web-preview/`: current TanStack browser preview source, UI components, tests, configuration and dependency lockfile. It displays the original PAMIR export in an isolated iframe.

## Android build
Install Node 18+, JDK 17 and Android SDK 34 / Android Studio.
From `android-app/` run:

```sh
bash setup-android.sh
cd android
./gradlew assembleDebug
```

The APK is generated at `android-app/android/app/build/outputs/apk/debug/app-debug.apk`.
The authoritative native plugin sources are under `android-app/native/`; the setup script copies them into the generated Android project.
Gallery tests: `node --test tests/gallery.test.cjs` from `android-app/`.

## Browser preview
From `web-preview/`:

```sh
bun install
bun run dev
```

The route tree is generated automatically by the tooling. Browser navigation and mobile/desktop rendering were checked. Native device media access is only available in the Android app, not the browser preview.

## Status and exclusions
This is all currently available application source, not a claim that every service is configured or every feature is complete. Products, authentication and feed require the original app service configuration. No hosted service credentials or database export are supplied.
The Android debug APK was built and signature-checked previously; it has not been tested on an Android phone or emulator.
Dependencies, generated build output, APK binaries, repository metadata and private workspace metadata are intentionally omitted. Install dependencies and build locally using the instructions above.
