<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the uploaded PAMIR Android delivery separate from the TanStack preview; its authoritative plugin sources live in the exported package and are copied into Android by its setup script, so rebuilding does not lose native changes.
- Display the original PAMIR web export in an isolated full-screen iframe for browser preview, preserving its styling, scripts, and service configuration without changing the Android delivery.
