import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PAMIR — Preview" },
      { name: "description", content: "Preview of the original PAMIR application." },
      { property: "og:title", content: "PAMIR — Preview" },
      { property: "og:description", content: "Preview of the original PAMIR application." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      title="PAMIR"
      src="/pamir/index.html"
      className="fixed inset-0 h-dvh w-full border-0 bg-background"
      allow="camera; microphone; fullscreen"
    />
  );
}
