
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile
} from "https://www.gstatic.com/firebasejs/13.2.0/firebase-auth.js";

import {
  doc,
  setDoc,
  getDoc,
  updateDoc,
  serverTimestamp,
  collection,
  getDocs,
  query,
  orderBy,
  limit
} from "https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js";

import { auth, db } from "./firebase.js";

// عناصر نافذة الحساب
const accountModal = document.getElementById("accountModal");
const accountForm = document.getElementById("accountForm");
const accountProfile = document.getElementById("accountProfile");

const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");

const nameField = document.getElementById("nameField");
const accountName = document.getElementById("accountName");
const accountEmail = document.getElementById("accountEmail");
const accountPassword = document.getElementById("accountPassword");

const accountError = document.getElementById("accountError");
const accountSubmit = document.getElementById("accountSubmit");

let accountMode = "login";
let currentUser = null;

function showMessage(message) {
  if (typeof window.showToast === "function") {
    window.showToast(message);
  }
}
// =================================
// AHMAD AI - FIREBASE WALLET
// =================================

async function loadUserWallet(user) {
  const walletRef = doc(db, "wallets", user.uid);

  let walletSnap = await getDoc(walletRef);

  // إنشاء محفظة جديدة عند عدم وجودها
  if (!walletSnap.exists()) {
    await setDoc(walletRef, {
      points: 0,
      balance: 0,
      createdAt: serverTimestamp()
    });

    walletSnap = await getDoc(walletRef);
  }

  const wallet = walletSnap.data();

  const pointsElement = document.getElementById("walletPoints");
  const moneyElement = document.getElementById("walletMoney");

  if (pointsElement) {
    pointsElement.textContent = Number(wallet.points || 0).toLocaleString("en-US");
  }

  if (moneyElement) {
    moneyElement.textContent = Number(wallet.balance || 0).toFixed(2);
  }
}

// عرض الأصفار عند عدم تسجيل الدخول
function resetWalletDisplay() {
  const pointsElement = document.getElementById("walletPoints");
  const moneyElement = document.getElementById("walletMoney");

  if (pointsElement) pointsElement.textContent = "0";
  if (moneyElement) moneyElement.textContent = "0.00";
}

// =================================
// قراءة سجل عمليات المحفظة
// =================================
let walletTransactionsData = [];
async function loadWalletHistory(user) {
  const historyBox = document.getElementById("walletHistory");
  const emptyBox = document.getElementById("walletEmpty");

  if (!historyBox || !emptyBox) return;

  let list = document.getElementById("walletTransactions");

  if (!list) {
    list = document.createElement("div");
    list.id = "walletTransactions";
    historyBox.appendChild(list);
  }

  list.replaceChildren();
  emptyBox.hidden = false;

  try {
    const transactionsRef = collection(
      db,
      "wallets",
      user.uid,
      "transactions"
    );

    const transactionsQuery = query(
      transactionsRef,
      orderBy("createdAt", "desc"),
      limit(20)
    );

    const snapshot = await getDocs(transactionsQuery);
walletTransactionsData = snapshot.docs.map(doc => doc.data());
    if (snapshot.empty) {
      return;
    }

    emptyBox.hidden = true;

    snapshot.forEach(documentSnapshot => {
      const transaction = documentSnapshot.data();

      const item = document.createElement("div");
      item.className = "wallet-transaction-item";
item.dataset.type = transaction.currency === "money"
  ? "money"
  : "points";

const statusValue = String(transaction.status || "").toLowerCase();

if (["completed", "success", "paid", "مكتملة", "مكتمل", "ناجحة"].includes(statusValue)) {
  item.dataset.status = "completed";
} else if (["pending", "review", "قيد المراجعة", "معلقة"].includes(statusValue)) {
  item.dataset.status = "pending";
} else if (["rejected", "failed", "مرفوضة", "مرفوض", "فاشلة"].includes(statusValue)) {
  item.dataset.status = "rejected";
} else {
  item.dataset.status = "unknown";
}
      const info = document.createElement("div");
      info.className = "wallet-transaction-info";

      const title = document.createElement("strong");
      title.textContent = transaction.description ||
        "عملية في المحفظة";

      const date = document.createElement("small");

      if (transaction.createdAt?.toDate) {
        date.textContent = transaction.createdAt
          .toDate()
          .toLocaleString("ar-SY");
      } else {
        date.textContent = "التاريخ غير متوفر";
      }

      const amount = document.createElement("strong");
      amount.className = "wallet-transaction-amount";

      const value = Number(transaction.amount || 0);
      const unit = transaction.currency === "money"
        ? "رصيد"
        : "نقطة";

      amount.textContent = `${value} ${unit}`;

const details = document.createElement("div");
details.className = "wallet-transaction-details";
details.hidden = true;

const description = document.createElement("p");
description.textContent = "الوصف: " +
  (transaction.description || "غير متوفر");

const transactionType = document.createElement("p");
transactionType.textContent = "النوع: " +
  (transaction.type || "غير محدد");

const status = document.createElement("p");
const detailStatusValue = String(transaction.status || "").toLowerCase();

if (["completed", "success", "paid", "مكتملة", "مكتمل", "ناجحة"].includes(statusValue)) {
  status.className = "wallet-status-success";
  status.textContent = "الحالة: مكتملة";
} else if (["pending", "review", "قيد المراجعة", "معلقة", "معلقة"].includes(statusValue)) {
  status.className = "wallet-status-pending";
  status.textContent = "الحالة: قيد المراجعة";
} else if (["rejected", "failed", "مرفوضة", "مرفوض", "فاشلة"].includes(statusValue)) {
  status.className = "wallet-status-rejected";
  status.textContent = "الحالة: مرفوضة";
} else {
  status.className = "wallet-status-unknown";
  status.textContent = "الحالة: " + (transaction.status || "غير مسجلة");
}details.append(description, transactionType, status);

item.append(info, amount, details);

item.style.cursor = "pointer";

item.addEventListener("click", () => {
  details.hidden = !details.hidden;
});

list.appendChild(item);
    });
applyWalletFilters();
  } catch (error) {
    console.error("Wallet history error:", error);
    emptyBox.hidden = false;
    emptyBox.querySelector("p").textContent =
      "تعذر تحميل سجل العمليات.";
  }
}
// زر إظهار وإخفاء سجل المحفظة
const walletHistoryBtn = document.getElementById("walletHistoryBtn");
const walletHistoryBox = document.getElementById("walletHistory");

if (walletHistoryBtn && walletHistoryBox) {
  walletHistoryBox.hidden = true;

  walletHistoryBtn.addEventListener("click", async () => {
    walletHistoryBox.hidden = !walletHistoryBox.hidden;

    if (!walletHistoryBox.hidden) {
      if (currentUser) {
        await loadWalletHistory(currentUser);
      } else {
        showMessage("سجّل الدخول أولاً لعرض سجل العمليات.");
      }
    }
  });
}
function applyWalletFilters() {
  const typeFilter = document.getElementById("walletTypeFilter");
  const statusFilter = document.getElementById("walletStatusFilter");
  const list = document.getElementById("walletTransactions");

  if (!typeFilter || !statusFilter || !list) return;

  list.querySelectorAll(".wallet-transaction-item").forEach(item => {
    const typeMatch =
      typeFilter.value === "all" || item.dataset.type === typeFilter.value;

    const statusMatch =
      statusFilter.value === "all" || item.dataset.status === statusFilter.value;

    item.hidden = !(typeMatch && statusMatch);
  });
}

document.getElementById("walletTypeFilter")
  ?.addEventListener("change", applyWalletFilters);

document.getElementById("walletStatusFilter")
  ?.addEventListener("change", applyWalletFilters);
function openAccountModal() {
  if (!window.accountBackActive) {
    history.pushState(
      { ahmadView: "account" },
      "",
      location.href
    );

    window.accountBackActive = true;
  }

  accountModal.classList.add("show");
  accountError.textContent = "";

  if (currentUser) {
    showAccountProfile(currentUser);
  } else {
    showAccountForm();
  }
}

function closeAccountModal(fromHistory = false) {
  if (!fromHistory && window.accountBackActive) {
    window.accountBackActive = false;
    history.back();
    return;
  }

  accountModal.classList.remove("show");
}

window.closeAccountModal = closeAccountModal;
// إتاحة الدالة لملف app.js
window.openAccountModal = openAccountModal;
document.querySelector(".user-avatar").addEventListener("click", openAccountModal);
document.getElementById("closeAccount")
  .addEventListener("click", closeAccountModal);

accountModal.addEventListener("click", event => {
  if (event.target === accountModal) {
    closeAccountModal();
  }
});

function setAccountMode(mode) {
  accountMode = mode;
  accountError.textContent = "";
  accountForm.reset();

  const isRegister = mode === "register";

  loginTab.classList.toggle("active", !isRegister);
  registerTab.classList.toggle("active", isRegister);

  nameField.hidden = !isRegister;
  accountName.required = isRegister;

  accountSubmit.textContent = isRegister
    ? "إنشاء حساب جديد"
    : "تسجيل الدخول";

  document.getElementById("accountHeading").textContent =
    isRegister ? "انضم إلى AHMAD AI" : "مرحباً بعودتك";

  document.getElementById("accountDescription").textContent =
    isRegister
      ? "أنشئ حسابك وابدأ استخدام المنصة."
      : "سجّل الدخول للوصول إلى حسابك.";
}

loginTab.addEventListener("click", () => {
  setAccountMode("login");
});

registerTab.addEventListener("click", () => {
  setAccountMode("register");
});

function showAccountForm() {
  accountForm.hidden = false;
  accountProfile.hidden = true;
  setAccountMode("login");
}

function showAccountProfile(user) {
  accountForm.hidden = true;
  accountProfile.hidden = false;

  const name = user.displayName || user.email.split("@")[0];

  document.getElementById("profileName").textContent = name;
  document.getElementById("profileEmail").textContent = user.email;

  const firstLetter = name.trim().charAt(0).toUpperCase() || "A";

  document.getElementById("profileAvatar").textContent = firstLetter;
  document.querySelector(".user-avatar").textContent = firstLetter;
    // معلومات الحساب
  document.getElementById("profileUID").textContent = user.uid;

  document.getElementById("profileEmailCopy").textContent =
    user.email || "—";

  const creationDate = user.metadata.creationTime
    ? new Date(user.metadata.creationTime).toLocaleDateString("ar-SY")
    : "غير متوفر";

  document.getElementById("profileCreatedAt").textContent =
    creationDate;
}

function getFirebaseError(error) {
  const errors = {
    "auth/email-already-in-use": "هذا البريد مسجل مسبقاً.",
    "auth/invalid-email": "البريد الإلكتروني غير صالح.",
    "auth/weak-password": "كلمة المرور ضعيفة. استخدم 6 أحرف على الأقل.",
    "auth/user-not-found": "لا يوجد حساب بهذا البريد.",
    "auth/wrong-password": "كلمة المرور غير صحيحة.",
    "auth/invalid-credential": "البريد الإلكتروني أو كلمة المرور غير صحيحة.",
    "auth/too-many-requests": "محاولات كثيرة. حاول لاحقاً.",
    "permission-denied": "لا توجد صلاحية لحفظ بيانات الحساب. تحقق من قواعد Firestore."
  };

  return errors[error.code] || error.message || "حدث خطأ، حاول مرة أخرى.";
}

// إنشاء الحساب وتسجيل الدخول
accountForm.addEventListener("submit", async event => {
  event.preventDefault();

  accountError.textContent = "";

  const name = accountName.value.trim();
  const email = accountEmail.value.trim().toLowerCase();
  const password = accountPassword.value;

  if (accountMode === "register" && name.length < 2) {
    accountError.textContent = "الاسم يجب أن يحتوي على حرفين على الأقل.";
    return;
  }

  accountSubmit.disabled = true;
  accountSubmit.textContent = "يرجى الانتظار...";

  try {
    if (accountMode === "register") {
      const result = await createUserWithEmailAndPassword(
        auth,
        email,
        password
      );

      await updateProfile(result.user, {
        displayName: name
      });

      await setDoc(doc(db, "users", result.user.uid), {
        name: name,
        email: email,
        createdAt: serverTimestamp()
      });

      showMessage("تم إنشاء حسابك بنجاح!");

    } else {
      await signInWithEmailAndPassword(auth, email, password);

      showMessage("تم تسجيل الدخول بنجاح.");
    }

  } catch (error) {
    accountError.textContent = getFirebaseError(error);

  } finally {
    accountSubmit.disabled = false;

    accountSubmit.textContent =
      accountMode === "register"
        ? "إنشاء حساب جديد"
        : "تسجيل الدخول";
  }
});

// مراقبة حالة تسجيل الدخول
onAuthStateChanged(auth, async user => {
  currentUser = user;

  if (user) {
    try {
      const profileRef = doc(db, "users", user.uid);
      const profileSnap = await getDoc(profileRef);
      accountPhotoData = profileSnap.exists()
  ? profileSnap.data().photoData || ""
  : "";

applyAccountPhoto(accountPhotoData);

      if (!profileSnap.exists()) {
        await setDoc(profileRef, {
          name: user.displayName || user.email.split("@")[0],
          email: user.email,
          createdAt: serverTimestamp()
        });
      }
      await loadUserWallet(user);
      await loadWalletHistory(user);

      if (accountModal.classList.contains("show")) {
        showAccountProfile(user);
      }

    } catch (error) {
      console.error("Profile error:", error);
    }

  } else {
    document.querySelector(".user-avatar").textContent = "A";
resetWalletDisplay();
    if (accountModal.classList.contains("show")) {
      showAccountForm();
    }
  }
});

// تسجيل الخروج
document.getElementById("logoutBtn")
  .addEventListener("click", async () => {
    try {
      await signOut(auth);
      showAccountForm();
      showMessage("تم تسجيل الخروج.");

    } catch (error) {
      accountError.textContent = getFirebaseError(error);
    }
  });



// =================================
// تعديل اسم الحساب
// =================================

const editNameBtn = document.getElementById("editNameBtn");
const editNameBox = document.getElementById("editNameBox");
const newProfileName = document.getElementById("newProfileName");
const saveNameBtn = document.getElementById("saveNameBtn");
const cancelNameBtn = document.getElementById("cancelNameBtn");
const editNameError = document.getElementById("editNameError");

editNameBtn.addEventListener("click", () => {
  newProfileName.value = currentUser?.displayName || "";
  editNameError.textContent = "";
  editNameBox.hidden = false;
});

cancelNameBtn.addEventListener("click", () => {
  editNameBox.hidden = true;
  editNameError.textContent = "";
});

saveNameBtn.addEventListener("click", async () => {
  if (!currentUser) return;

  const newName = newProfileName.value.trim();

  if (newName.length < 2) {
    editNameError.textContent = "الاسم يجب أن يحتوي على حرفين على الأقل.";
    return;
  }

  saveNameBtn.disabled = true;
  saveNameBtn.textContent = "جارٍ الحفظ...";

  try {
    await updateProfile(currentUser, {
      displayName: newName
    });

    await updateDoc(doc(db, "users", currentUser.uid), {
      name: newName
    });

    document.getElementById("profileName").textContent = newName;
    document.getElementById("profileAvatar").textContent =
      newName.charAt(0).toUpperCase();

    document.querySelector(".user-avatar").textContent =
      newName.charAt(0).toUpperCase();

    editNameBox.hidden = true;
    showMessage("تم تحديث اسم الحساب بنجاح.");

  } catch (error) {
    editNameError.textContent = getFirebaseError(error);
  } finally {
    saveNameBtn.disabled = false;
    saveNameBtn.textContent = "حفظ الاسم";
  }
});




// =================================
// صورة الحساب الشخصية
// =================================

let accountPhotoData = "";

const choosePhotoBtn = document.getElementById("choosePhotoBtn");
const profilePhotoInput = document.getElementById("profilePhotoInput");

function applyAccountPhoto(photo) {
  const avatars = [
    document.getElementById("profileAvatar"),
    document.querySelector(".user-avatar")
  ];

  avatars.forEach(avatar => {
    if (!avatar) return;

    if (photo) {
      avatar.textContent = "";
      avatar.style.backgroundImage = `url("${photo}")`;
      avatar.style.backgroundSize = "cover";
      avatar.style.backgroundPosition = "center";
    } else {
      avatar.style.backgroundImage = "";
      const name = currentUser?.displayName ||
                   currentUser?.email?.split("@")[0] || "A";
      avatar.textContent = name.trim().charAt(0).toUpperCase();
    }
  });
}

choosePhotoBtn.addEventListener("click", () => {
  profilePhotoInput.click();
});

profilePhotoInput.addEventListener("change", async () => {
  const file = profilePhotoInput.files[0];
  if (!file || !currentUser) return;

  if (!file.type.startsWith("image/")) {
    showMessage("الرجاء اختيار صورة صحيحة.");
    return;
  }

  choosePhotoBtn.disabled = true;
  choosePhotoBtn.textContent = "جارٍ تجهيز الصورة...";

  try {
    const imageUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        const img = new Image();

        img.onload = () => {
          const canvas = document.createElement("canvas");
          const maxSize = 256;

          const ratio = Math.min(
            maxSize / img.width,
            maxSize / img.height,
            1
          );

          canvas.width = Math.round(img.width * ratio);
          canvas.height = Math.round(img.height * ratio);

          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

          resolve(canvas.toDataURL("image/jpeg", 0.65));
        };

        img.onerror = reject;
        img.src = reader.result;
      };

      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

    await updateDoc(doc(db, "users", currentUser.uid), {
      photoData: imageUrl
    });

    accountPhotoData = imageUrl;
    applyAccountPhoto(imageUrl);

    showMessage("تم حفظ الصورة الشخصية بنجاح!");

  } catch (error) {
    console.error(error);
    showMessage("تعذر حفظ الصورة. حاول مرة أخرى.");
  } finally {
    choosePhotoBtn.disabled = false;
    choosePhotoBtn.textContent = "📷 تغيير الصورة الشخصية";
    profilePhotoInput.value = "";
  }
});



// =================================
// نسخ معلومات الحساب
// =================================

async function copyAccountText(value, message) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(value);
    } else {
      const textarea = document.createElement("textarea");
      textarea.value = value;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();

      const copied = document.execCommand("copy");
      textarea.remove();

      if (!copied) throw new Error("Copy failed");
    }

    showMessage(message);
  } catch (error) {
    showMessage("تعذر النسخ. حاول مرة أخرى.");
  }
}

document.getElementById("copyUIDBtn").addEventListener("click", () => {
  if (currentUser) {
    copyAccountText(currentUser.uid, "تم نسخ معرّف الحساب.");
  }
});

document.getElementById("copyEmailBtn").addEventListener("click", () => {
  if (currentUser?.email) {
    copyAccountText(currentUser.email, "تم نسخ البريد الإلكتروني.");
  }
});