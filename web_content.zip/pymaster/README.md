# PyMaster by Hashimi — v0.1 (core build)
Requires: Node 18+, Android Studio + SDK, JDK 17.
```
npm install
npx cap add android
npx cap sync android
npx cap open android      # Build > Build APK(s), or: cd android && ./gradlew assembleDebug
# APK: android/app/build/outputs/apk/debug/app-debug.apk
npm test                  # unit tests (scoring, levels, streak, backup validation)
```
Android 13+: add `<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>` to AndroidManifest.xml (the plugin prompts at runtime).
Change `appId` in capacitor.config.json before release.

## Implemented
- IndexedDB storage service (versioned, additive migrations, never clears on startup); settings, progress, rewards, quizzes, notes, bookmarks
- Idempotent atomic lesson XP (unique reward key + single transaction); XP = sum of reward records
- Light/Dark/System, 7 accent presets + custom picker, applied pre-paint, persisted
- English/Persian with RTL; lessons+quizzes translated
- 3 lessons with verified quizzes, 60% pass; notes; bookmarks; streak, level
- Daily local reminder (single fixed id, rescheduled only on settings change)
- JSON backup export/import with validation and confirmation; double-confirmed reset
## NOT implemented yet (honest list)
Levels 4-20 content, exam engine (timed/module/final), badges & daily challenges, projects, search, Python execution (needs Pyodide or Chaquopy bridge; UI states it cannot run code), editor, font-size/reduced-motion settings, icon/splash, Play Store assets.
## Not verified
No Android build or device test was run; only the Node unit tests were executed.
