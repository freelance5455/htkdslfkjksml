// Pure logic (no browser APIs) so it is unit-testable in Node.
export const XP={lesson:20};
export const PASS=0.6;
export const levelFor=xp=>Math.floor(Math.sqrt(xp/50))+1;
export function scoreQuiz(questions,answers){
  let correct=0;questions.forEach((q,i)=>{if(answers[i]===q.a)correct++});
  const total=questions.length,pct=total?correct/total:0;
  return{correct,total,pct,passed:total>0&&pct>=PASS};
}
const dayKey=d=>`${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;
export function streak(timestamps,now=new Date()){
  const days=new Set(timestamps.map(t=>dayKey(new Date(t))));
  let d=new Date(now);if(!days.has(dayKey(d)))d.setDate(d.getDate()-1);
  let n=0;while(days.has(dayKey(d))){n++;d.setDate(d.getDate()-1)}return n;
}
export function validateBackup(o){
  if(!o||o.app!=='pymaster'||typeof o.version!=='number'||o.version>1||typeof o.data!=='object'||!o.data)return'invalid';
  return null;
}
