// Storage service: the only module that touches IndexedDB. Never clears data on startup.
import{XP,validateBackup}from'./core.js';
const NAME='pymaster',VER=1,STORES=['kv','progress','rewards','quizzes','notes','bookmarks'];
let _db;
export function open(){
  if(_db)return Promise.resolve(_db);
  return new Promise((res,rej)=>{const r=indexedDB.open(NAME,VER);
    r.onupgradeneeded=()=>{const d=r.result; // migrations only ADD stores, never delete
      for(const s of STORES)if(!d.objectStoreNames.contains(s))d.createObjectStore(s,s==='quizzes'?{keyPath:'id',autoIncrement:true}:{keyPath:'key'})};
    r.onsuccess=()=>{_db=r.result;res(_db)};r.onerror=()=>rej(r.error)})}
const wrap=q=>new Promise((res,rej)=>{q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});
const done=tx=>new Promise((res,rej)=>{tx.oncomplete=res;tx.onerror=tx.onabort=()=>rej(tx.error)});
export const getAll=async s=>wrap((await open()).transaction(s).objectStore(s).getAll());
export const get=async(s,k)=>wrap((await open()).transaction(s).objectStore(s).get(k));
export const put=async(s,v)=>{const tx=(await open()).transaction(s,'readwrite');tx.objectStore(s).put(v);return done(tx)};
export const del=async(s,k)=>{const tx=(await open()).transaction(s,'readwrite');tx.objectStore(s).delete(k);return done(tx)};
export async function loadSettings(defaults){
  const s=await get('kv','settings');return{...defaults,...(s||{})}}
export const saveSettings=s=>put('kv',{...s,key:'settings'});
// Atomic + idempotent: reward and progress in one transaction; a second call awards 0.
export async function completeLesson(id){
  const tx=(await open()).transaction(['progress','rewards'],'readwrite');
  const rk='lesson:'+id,ex=await wrap(tx.objectStore('rewards').get(rk));let xp=0;
  if(!ex){xp=XP.lesson;const at=Date.now();
    tx.objectStore('rewards').put({key:rk,xp,at,type:'lesson'});tx.objectStore('progress').put({key:id,done:true,at})}
  await done(tx);return xp}
export async function exportAll(){
  const data={};for(const s of STORES)data[s]=await getAll(s);
  return JSON.stringify({app:'pymaster',version:1,exportedAt:Date.now(),data},null,1)}
export function checkBackup(text){let o;try{o=JSON.parse(text)}catch{return{err:'invalid'}}
  const err=validateBackup(o);return err?{err}:{o}}
export async function importAll(o){ // merges; never clears
  const tx=(await open()).transaction(STORES,'readwrite');
  for(const s of STORES)for(const v of o.data[s]||[])tx.objectStore(s).put(v);return done(tx)}
export async function resetAll(){ // only reachable via a double-confirmed button
  const tx=(await open()).transaction(STORES,'readwrite');for(const s of STORES)tx.objectStore(s).clear();return done(tx)}
