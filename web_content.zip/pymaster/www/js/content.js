// Bundled lessons. a = index of the verified correct option.
export const LESSONS=[
{id:'l1-print',lv:1,
 title:{en:'Your first program: print()',fa:'اولین برنامه: print()'},
 body:{en:['A program is a list of instructions. Python reads them top to bottom.','print() shows text on the screen. Comments start with # and are ignored by Python.'],
       fa:['برنامه فهرستی از دستورهاست. پایتون آن‌ها را از بالا به پایین می‌خواند.','تابع print() متن را روی صفحه نمایش می‌دهد. توضیحات با # شروع می‌شوند و پایتون آن‌ها را نادیده می‌گیرد.']},
 code:"# say hello\nprint('Hi')",out:'Hi',
 quiz:[{q:{en:"What does print('Hi') display?",fa:"دستور print('Hi') چه چیزی نمایش می‌دهد؟"},o:{en:['Hi','print',"'Hi'"],fa:['Hi','print',"'Hi'"]},a:0},
       {q:{en:'Python comments start with:',fa:'توضیحات پایتون با چه چیزی شروع می‌شوند؟'},o:{en:['//','#','--'],fa:['//','#','--']},a:1}]},
{id:'l2-vars',lv:2,
 title:{en:'Variables and types',fa:'متغیرها و انواع داده'},
 body:{en:['A variable is a name that refers to a value: x = 5.','Common types: int (3), float (3.0), str ("a"), bool (True). type() tells you the type.'],
       fa:['متغیر نامی است که به یک مقدار اشاره می‌کند: x = 5.','انواع رایج: int (۳)، float (۳.۰)، str (متن)، bool (True). تابع type() نوع را نشان می‌دهد.']},
 code:'x = 5\ny = x + 2\nprint(y)\nprint(type(3.0))',out:"7\n<class 'float'>",
 quiz:[{q:{en:'x = 5; y = x + 2; print(y) shows:',fa:'با x = 5 و y = x + 2 ، print(y) چه نشان می‌دهد؟'},o:{en:['5','7','x + 2'],fa:['5','7','x + 2']},a:1},
       {q:{en:'type(3.0) is:',fa:'نوع type(3.0) چیست؟'},o:{en:['int','float','str'],fa:['int','float','str']},a:1}]},
{id:'l3-if',lv:3,
 title:{en:'Decisions with if / elif / else',fa:'تصمیم‌گیری با if / elif / else'},
 body:{en:['if runs a block only when its condition is True. Indentation marks the block.','Use elif for extra conditions and else for everything left.'],
       fa:['if فقط وقتی شرط درست باشد بلوک را اجرا می‌کند. تورفتگی بلوک را مشخص می‌کند.','برای شرط‌های بیشتر از elif و برای بقیه حالت‌ها از else استفاده کنید.']},
 code:'x = 10\nif x > 5:\n    print("big")\nelse:\n    print("small")',out:'big',
 quiz:[{q:{en:'With x = 10 the code above prints:',fa:'با x = 10 کد بالا چه چاپ می‌کند؟'},o:{en:['big','small','nothing'],fa:['big','small','هیچ‌چیز']},a:0},
       {q:{en:'Keyword for a second condition:',fa:'کلمه کلیدی شرط دوم کدام است؟'},o:{en:['elif','elseif','else if'],fa:['elif','elseif','else if']},a:0}]}
];
