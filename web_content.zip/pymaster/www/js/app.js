import*as DB from'./db.js';import{LESSONS}from'./content.js';import{T}from'./i18n.js';
import{levelFor,scoreQuiz,streak}from'./core.js';
const DEF={lang:'en',mode:'system',accent:'#3776ab',remind:false,time:'20:00'};
const PRESETS=['#3776ab','#7c3aed','#10b981','#f97316','#14b8a6','#ec4899','#1e3a8a'];
let S=DEF,tab='home',cur=null,msg='',view=document.getElementById('view');
const t=k=>T[S.lang][k]||T.en[k]||k;
const L=o=>o[S.lang]||o.en;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function theme(){const d=document.documentElement;
  d.dataset.theme=S.mode==='system'?(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'):S.mode;
  d.dir=S.lang==='fa'?'rtl':'ltr';d.lang=S.lang;d.style.setProperty('--accent',S.accent);
  localStorage.setItem('pm_pre',JSON.stringify({mode:S.mode,lang:S.lang,accent:S.accent}))}
const save=()=>{theme();return DB.saveSettings(S)};
async function schedule(){const N=window.Capacitor?.Plugins?.LocalNotifications;
  if(!N)return S.remind?t('nNo'):t('nOff');
  await N.cancel({notifications:[{id:1}]}); // single fixed id => no duplicates
  if(!S.remind)return t('nOff');
  const p=await N.requestPermissions();if(p.display!=='granted')return t('nDen');
  const[h,m]=S.time.split(':').map(Number);
  await N.schedule({notifications:[{id:1,title:'PyMaster',body:t('remindBody'),schedule:{on:{hour:h,minute:m},allowWhileIdle:true}}]});
  return t('nOk')}
function nav(){const n=document.getElementById('nav');
  n.innerHTML=['home','learn','settings'].map(k=>`<button class="${tab===k?'on':''}" data-tab="${k}">${t(k)}</button>`).join('');
  n.querySelectorAll('button').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;cur=null;msg='';render()})}
async function render(){nav();
  if(cur)return lesson();
  if(tab==='home')return home();
  if(tab==='learn')return learn();
  return settings()}
async function home(){
  const prog=await DB.getAll('progress'),rw=await DB.getAll('rewards'),xp=rw.reduce((a,r)=>a+r.xp,0);
  const done=new Set(prog.map(p=>p.key)),next=LESSONS.find(l=>!done.has(l.id)),pct=Math.round(done.size/LESSONS.length*100);
  view.innerHTML=`<h1>${t('hi')}</h1><p class="mut">${t('by')}</p>
  <div class="card row"><div><b>${xp}</b> ${t('xp')}</div><div>${t('level')} <b>${levelFor(xp)}</b></div><div><b>${streak(rw.map(r=>r.at))}</b> ${t('streak')}</div></div>
  <div class="card"><div class="mut">${t('prog')}: ${done.size}/${LESSONS.length}</div><div class="bar"><i style="width:${pct}%"></i></div></div>
  ${next?`<div class="card"><h2>${done.size?t('cont'):t('start')}</h2><p>${esc(L(next.title))}</p><button id="go">${t('open')}</button></div>`:''}`;
  if(next)document.getElementById('go').onclick=()=>{cur=next.id;render()}}
async function learn(){
  const done=new Set((await DB.getAll('progress')).map(p=>p.key));
  view.innerHTML=`<h1>${t('learn')}</h1>`+LESSONS.map(l=>`<div class="card"><b>${l.lv}. ${esc(L(l.title))}</b>
   ${done.has(l.id)?`<span class="ok"> ✓ ${t('done')}</span>`:''}<div><button data-id="${l.id}">${t('open')}</button></div></div>`).join('');
  view.querySelectorAll('button').forEach(b=>b.onclick=()=>{cur=b.dataset.id;msg='';render()})}
async function lesson(){
  const l=LESSONS.find(x=>x.id===cur),bm=await DB.get('bookmarks',l.id),note=(await DB.get('notes',l.id))?.text||'';
  view.innerHTML=`<button class="alt" id="bk">← ${t('back')}</button><h1>${esc(L(l.title))}</h1>
  ${L(l.body).map(p=>`<p>${esc(p)}</p>`).join('')}<pre>${esc(l.code)}</pre><p class="mut">Output:</p><pre>${esc(l.out)}</pre>
  <p class="mut">${t('runtime')}</p>
  <button class="alt" id="bm">${bm?'★ '+t('bmd'):'☆ '+t('bm')}</button>
  <div class="card">${l.quiz.map((q,i)=>`<p><b>${esc(L(q.q))}</b></p>${L(q.o).map((o,j)=>`<label class="opt"><input type="radio" name="q${i}" value="${j}"> ${esc(o)}</label>`).join('')}`).join('')}
  <button id="sub">${t('submit')}</button><p id="res">${msg}</p></div>
  <div class="card"><label>${t('notes')}<br><textarea id="note" rows="3" style="width:100%">${esc(note)}</textarea></label><button id="sn">${t('save')}</button></div>`;
  document.getElementById('bk').onclick=()=>{cur=null;render()};
  document.getElementById('bm').onclick=async()=>{bm?await DB.del('bookmarks',l.id):await DB.put('bookmarks',{key:l.id,at:Date.now()});render()};
  document.getElementById('sn').onclick=()=>DB.put('notes',{key:l.id,text:document.getElementById('note').value,at:Date.now()});
  document.getElementById('sub').onclick=async()=>{
    const ans=l.quiz.map((_,i)=>{const c=view.querySelector(`input[name=q${i}]:checked`);return c?+c.value:-1});
    const r=scoreQuiz(l.quiz,ans);await DB.put('quizzes',{lesson:l.id,score:r.pct,at:Date.now()});
    let m=`${t('res')}: ${r.correct}/${r.total}. `;
    if(r.passed){const xp=await DB.completeLesson(l.id);m+=`<span class="ok">${t('pass')} ${xp?`+${xp} ${t('xp')}`:t('already')}</span>`}
    else m+=`<span class="bad">${t('fail')}</span>`;
    document.getElementById('res').innerHTML=m;msg=m}}
function settings(){
  view.innerHTML=`<h1>${t('settings')}</h1>
  <div class="card"><label>${t('lang')} <select id="lg"><option value="en">English</option><option value="fa">فارسی</option></select></label></div>
  <div class="card"><label>${t('mode')} <select id="md">${['light','dark','system'].map(m=>`<option value="${m}">${t(m)}</option>`).join('')}</select></label>
   <p>${t('accent')}</p><div class="row">${PRESETS.map(c=>`<button class="sw" data-c="${c}" style="background:${c}" aria-label="${c}"></button>`).join('')}<input type="color" id="cc" value="${S.accent}"></div></div>
  <div class="card"><label><input type="checkbox" id="rm" ${S.remind?'checked':''}> ${t('remind')}</label><br>
   <label>${t('time')} <input type="time" id="tm" value="${S.time}"></label><p id="nm" class="mut"></p></div>
  <div class="card"><h2>${t('backup')}</h2><div class="row"><button id="ex">${t('exp')}</button><label class="btn alt" style="border:1px solid var(--accent);color:var(--accent);background:none">${t('imp')}<input type="file" id="im" accept=".json" hidden></label></div><p id="bmsg"></p></div>
  <div class="card"><button id="rs" style="background:var(--bad)">${t('reset')}</button></div><p class="mut">${t('privacy')}</p>`;
  const $=id=>document.getElementById(id);$('lg').value=S.lang;$('md').value=S.mode;
  $('lg').onchange=async e=>{S.lang=e.target.value;await save();render()};
  $('md').onchange=async e=>{S.mode=e.target.value;await save()};
  view.querySelectorAll('.sw').forEach(b=>b.onclick=async()=>{S.accent=b.dataset.c;$('cc').value=S.accent;await save()});
  $('cc').oninput=async e=>{S.accent=e.target.value;await save()};
  const rem=async()=>{S.remind=$('rm').checked;S.time=$('tm').value||'20:00';await save();$('nm').textContent=await schedule()};
  $('rm').onchange=rem;$('tm').onchange=rem;
  $('ex').onclick=async()=>{const a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([await DB.exportAll()],{type:'application/json'}));a.download='pymaster-backup.json';a.click()};
  $('im').onchange=async e=>{const f=e.target.files[0];if(!f)return;const c=DB.checkBackup(await f.text());
    if(c.err){$('bmsg').textContent=t('badfile');return}
    const n=Object.entries(c.o.data).map(([k,v])=>`${k}: ${v.length}`).join(', ');
    if(confirm(n)){await DB.importAll(c.o);$('bmsg').textContent=t('imported')}};
  $('rs').onclick=async()=>{if(confirm(t('sure'))&&confirm(t('sure'))){await DB.resetAll();S={...DEF};await save();render()}}}
(async()=>{try{S=await DB.loadSettings(DEF)}catch(e){view.textContent='Storage error: '+e.message;return}
  theme();matchMedia('(prefers-color-scheme:dark)').onchange=()=>S.mode==='system'&&theme();render()})();
