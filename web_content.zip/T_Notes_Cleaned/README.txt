T NOTES — OFFLINE NOTES APP

Contents:
- index.html: the complete app in one file.

Features:
- Create, edit, search, pin, and delete notes
- Categories and note colors
- Light/dark appearance toggle
- Notes saved on the device using browser local storage
- No Bible, prayer, religious, promotional, or external-link content
- No external libraries or internet connection required for the app itself

To convert:
1. Upload index.html directly if your converter accepts HTML files, OR upload T_Notes_Notes_Only.zip.
2. Set the start page to index.html if asked.
3. Choose an app name such as T Notes.

Note: saved notes stay in that app/browser storage on that device. Clearing app data may erase them. Different converters have different requirements, and this source ZIP is not itself an APK.
