UNSER VORRAT – FUNKTIONSTEST VERSION

Diese ZIP muss in Netlify Drop als ZIP hochgeladen werden.
Wichtig: index.html liegt direkt im ZIP-Root.

Zusatz:
- Speichern-Button ist zusätzlich direkt unter der Produktsuche vorhanden.
- Produkt-Merken benötigt die SQL-Migration migration_produktdatenbank.sql.
- Inventar-Speichern selbst benötigt keine zusätzliche SQL-Migration, sofern das bestehende inventory_items-Schema bereits funktioniert.
