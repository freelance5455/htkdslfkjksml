UNSER VORRAT – GOTHIC MASTER + HAUSHALTS-ZENTRALE

Baut auf dem funktionierenden Gothic/FOTO-Master auf.

Enthalten:
- kleineres Start-/Übersichts-Dashboard Haushalts-Zentrale
- Vorratskompass
- Vorratsbestand bewerten / Bestandswert
- bald ablaufende Artikel
- Mindestbestand unterschritten
- Einkaufsliste + geschätzte Gesamtkosten
- Artikelpreise, Preisverlauf, Durchschnitt, günstigster Preis
- Warnung bei ungewöhnlich hohem Preis
- Preis vom gespeicherten EAN-Produkt übernehmbar
- einfache Rezeptvorschläge aus dem Bestand
- separate Vorsorge-Zentrale: Wasser, Lebensmittel, Hygiene, Licht, Energie, Erste Hilfe, Dokumente, Wärme, Haustiere, Notfallrucksack
- Vorsorge-Fortschritt und Vorratskompass-Anbindung

WICHTIG:
Einmal migration_haushaltszentrale_vorsorge_preise.sql im Supabase SQL Editor ausführen.
Die bisherigen Migrationen bleiben gültig.
index.html liegt direkt im ZIP-Root.
