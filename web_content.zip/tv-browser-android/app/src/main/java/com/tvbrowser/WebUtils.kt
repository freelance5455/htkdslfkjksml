package com.tvbrowser

object WebUtils {
    /**
     * Retire les marqueurs "; wv" et "Version/x.x" du user-agent de la WebView :
     * beaucoup de sites traitent alors l'app comme un vrai Chrome mobile.
     */
    fun chromeUserAgent(default: String): String =
        default.replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+\\s"), "")
}
