import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.rafiqmuslim.app",
  appName: "رفيق المسلم",
  webDir: "dist/public",
  bundledWebRuntime: false,
  server: { androidScheme: "https" },
};

export default config;
