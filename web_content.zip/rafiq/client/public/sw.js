const CACHE_VERSION = "rafiq-muslim-v2";
const SHELL = ["/", "/manifest.webmanifest", "/logo.png", "/logo-192.png", "/robots.txt", "/sitemap.xml"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_VERSION).then((cache) => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_VERSION).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET" || new URL(request.url).origin !== self.location.origin) return;
  const url = new URL(request.url);
  const isContentApi = url.pathname.startsWith("/api/content/");
  const isAsset = url.pathname.startsWith("/assets/") || /\.(png|svg|ico|webmanifest|css|js)$/.test(url.pathname);
  if (!isContentApi && !isAsset && request.mode !== "navigate") return;
  if (isContentApi) {
    event.respondWith(fetch(request).then((response) => { const copy = response.clone(); caches.open(CACHE_VERSION).then((cache) => cache.put(request, copy)); return response; }).catch(() => caches.match(request).then((cached) => cached || new Response(JSON.stringify({ error: "offline_content_unavailable" }), { status: 503, headers: { "Content-Type": "application/json" } }))));
    return;
  }
  if (isAsset) {
    event.respondWith(caches.match(request).then((cached) => cached || fetch(request).then((response) => { const copy = response.clone(); caches.open(CACHE_VERSION).then((cache) => cache.put(request, copy)); return response; })));
    return;
  }
  event.respondWith(fetch(request).catch(() => caches.match("/")));
});
