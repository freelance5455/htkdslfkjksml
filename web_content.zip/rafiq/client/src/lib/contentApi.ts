export type ApiSurah = { number: number; nameArabic: string; nameEnglish?: string; revelationType?: string; ayahCount: number };
export type ApiAyah = { ayahNumber: number; globalNumber: number; text: string };
export type ApiHadith = { id: number; hadithNumber: string; text: string; narrator: string | null; grade: string | null; collectionSlug: string; collectionName: string; categories: string | null };

async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`content_api_${response.status}`);
  return response.json() as Promise<T>;
}

export const contentApi = {
  surahs: () => getJson<{ surahs: ApiSurah[] }>("/api/content/quran/surahs"),
  surah: (number: number) => getJson<{ surah: ApiSurah & { id: number }; ayahs: ApiAyah[] }>(`/api/content/quran/surahs/${number}`),
  quranSearch: (query: string) => getJson<{ results: Array<ApiAyah & { surahNumber: number; nameArabic: string }> }>(`/api/content/quran/search?q=${encodeURIComponent(query)}`),
  hadith: (query = "", category = "") => getJson<{ results: ApiHadith[] }>(`/api/content/hadith?q=${encodeURIComponent(query)}&category=${encodeURIComponent(category)}&limit=50`),
  unifiedSearch: (query: string) => getJson<{ quran: Array<ApiAyah & { surahNumber: number; nameArabic: string }>; hadith: Array<Pick<ApiHadith, "id" | "hadithNumber" | "text" | "collectionName">>; supplications: Array<{ id: number; kind: string; title: string; text: string; categoryName: string | null }> }>(`/api/content/search?q=${encodeURIComponent(query)}`),
};
