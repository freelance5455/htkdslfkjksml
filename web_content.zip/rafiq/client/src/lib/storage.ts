const safeRead = <T>(key: string, fallback: T): T => {
  try {
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
};

const safeWrite = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Local persistence is an enhancement; the UI remains usable if storage is unavailable.
  }
};

const localDateKey = () => {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

export const storage = {
  getQuranProgress: () => safeRead("rafiq-quran-progress", { surahId: 1, ayahIndex: 0 }),
  setQuranProgress: (value: { surahId: number; ayahIndex: number }) => safeWrite("rafiq-quran-progress", value),
  getTasbeeh: () => safeRead("rafiq-tasbeeh", { count: 0, target: 33 }),
  setTasbeeh: (value: { count: number; target: number }) => safeWrite("rafiq-tasbeeh", value),
  getCompletedToday: () => safeRead<string[]>(`rafiq-wird-${localDateKey()}`, []),
  setCompletedToday: (value: string[]) => safeWrite(`rafiq-wird-${localDateKey()}`, value),
  getAdhkarProgress: () => safeRead<Record<string, number>>("rafiq-adhkar-progress", {}),
  setAdhkarProgress: (value: Record<string, number>) => safeWrite("rafiq-adhkar-progress", value),
};

export const normalizeArabic = (value: string) =>
  value
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[إأآا]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/ؤ/g, "و")
    .replace(/ئ/g, "ي")
    .replace(/ـ/g, "")
    .trim();
