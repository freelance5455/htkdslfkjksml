export type Source = {
  label: string;
  reference: string;
  url?: string;
};

export type ReligiousItem = {
  id: string;
  title: string;
  text: string;
  category: string;
  repetitions?: number;
  source: Source;
  note?: string;
  reviewStatus?: "منشور" | "مسودة للمراجعة";
};

export type LearningItem = {
  id: string;
  title: string;
  summary: string;
  sections: string[];
  source: Source;
  status: "منشور" | "مسودة للمراجعة";
};

export type LifeSituation = {
  id: string;
  title: string;
  description: string;
  icon: string;
  guidance: string;
  ayat: ReligiousItem[];
  duas: ReligiousItem[];
  actions: string[];
};

export type IslamicEvent = {
  id: string;
  title: string;
  season: string;
  summary: string;
  source: Source;
};

export const surahs = [
  { id: 1, name: "الفاتحة", ayahs: 7, revelation: "مكية" },
  { id: 2, name: "البقرة", ayahs: 286, revelation: "مدنية" },
  { id: 3, name: "آل عمران", ayahs: 200, revelation: "مدنية" },
  { id: 18, name: "الكهف", ayahs: 110, revelation: "مكية" },
  { id: 36, name: "يس", ayahs: 83, revelation: "مكية" },
  { id: 67, name: "الملك", ayahs: 30, revelation: "مكية" },
  { id: 112, name: "الإخلاص", ayahs: 4, revelation: "مكية" },
];

export const verifiedAyat: ReligiousItem[] = [
  {
    id: "ayah-94-5",
    title: "سورة الشرح — الآية 5",
    text: "فَإِنَّ مَعَ الْعُسْرِ يُسْرًا",
    category: "آية اليوم",
    source: { label: "القرآن الكريم", reference: "سورة الشرح، الآية 5" },
  },
  {
    id: "ayah-94-6",
    title: "سورة الشرح — الآية 6",
    text: "إِنَّ مَعَ الْعُسْرِ يُسْرًا",
    category: "آيات",
    source: { label: "القرآن الكريم", reference: "سورة الشرح، الآية 6" },
  },
  {
    id: "ayah-20-25",
    title: "سورة طه — الآية 25",
    text: "رَبِّ اشْرَحْ لِي صَدْرِي",
    category: "دعاء قرآني",
    source: { label: "القرآن الكريم", reference: "سورة طه، الآية 25" },
  },
  {
    id: "ayah-20-114",
    title: "سورة طه — الآية 114",
    text: "وَقُلْ رَبِّ زِدْنِي عِلْمًا",
    category: "دعاء قرآني",
    source: { label: "القرآن الكريم", reference: "سورة طه، الآية 114" },
  },
  {
    id: "ayah-2-201",
    title: "سورة البقرة — الآية 201",
    text: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
    category: "دعاء قرآني",
    source: { label: "القرآن الكريم", reference: "سورة البقرة، الآية 201" },
  },
  {
    id: "ayah-7-23",
    title: "سورة الأعراف — الآية 23",
    text: "رَبَّنَا ظَلَمْنَا أَنْفُسَنَا وَإِنْ لَمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ",
    category: "دعاء قرآني",
    source: { label: "القرآن الكريم", reference: "سورة الأعراف، الآية 23" },
  },
  {
    id: "ayah-23-118",
    title: "سورة المؤمنون — الآية 118",
    text: "وَقُلْ رَبِّ اغْفِرْ وَارْحَمْ وَأَنْتَ خَيْرُ الرَّاحِمِينَ",
    category: "دعاء قرآني",
    source: { label: "القرآن الكريم", reference: "سورة المؤمنون، الآية 118" },
  },
];

export const adhkar: ReligiousItem[] = [
  { id: "dhikr-morning-1", title: "التسبيح والتحميد", text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", category: "أذكار الصباح", repetitions: 100, source: { label: "السنة النبوية", reference: "صحيح البخاري، كتاب الدعوات؛ وصحيح مسلم" }, note: "تُحفظ المتابعة على جهازك فقط." },
  { id: "dhikr-evening-1", title: "التسبيح والتحميد مساءً", text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", category: "أذكار المساء", repetitions: 100, source: { label: "السنة النبوية", reference: "صحيح البخاري، كتاب الدعوات؛ وصحيح مسلم" } },
  { id: "dhikr-waking-1", title: "ذكر الاستيقاظ", text: "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ", category: "أذكار الاستيقاظ", repetitions: 1, source: { label: "السنة النبوية", reference: "صحيح البخاري، كتاب الدعوات" } },
  { id: "dhikr-after-prayer", title: "الاستغفار بعد الصلاة", text: "أَسْتَغْفِرُ اللَّهَ", category: "أذكار بعد الصلاة", repetitions: 3, source: { label: "السنة النبوية", reference: "صحيح مسلم، كتاب المساجد ومواضع الصلاة" } },
  { id: "dhikr-sleep", title: "ذكر مطلق قبل النوم", text: "سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَاللَّهُ أَكْبَرُ", category: "أذكار النوم", repetitions: 33, source: { label: "السنة النبوية", reference: "صحيح البخاري، كتاب الدعوات؛ وصحيح مسلم" } },
  { id: "dhikr-travel", title: "دعاء الركوب والسفر", text: "سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ", category: "أذكار السفر", repetitions: 1, source: { label: "القرآن الكريم", reference: "سورة الزخرف، الآيتان 13–14" } },
  { id: "dhikr-food", title: "حمد الله بعد الطعام", text: "الْحَمْدُ لِلَّهِ", category: "أذكار الطعام", repetitions: 1, source: { label: "حالة مراجعة", reference: "لا يُنشر النص التفصيلي قبل إكمال التوثيق" }, reviewStatus: "مسودة للمراجعة" },
];

export const adhkarCategories = ["أذكار الصباح", "أذكار المساء", "أذكار النوم", "أذكار الاستيقاظ", "أذكار الصلاة", "أذكار بعد الصلاة", "أذكار السفر", "أذكار دخول وخروج المنزل", "أذكار الطعام", "أذكار متنوعة"];

export const duas: ReligiousItem[] = [
  ...verifiedAyat.filter((item) => item.category === "دعاء قرآني").map((item) => ({ ...item, category: "أدعية القرآن" as const })),
  { id: "dua-parents", title: "للوالدين", text: "رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا", category: "دعاء للوالدين", repetitions: 1, source: { label: "القرآن الكريم", reference: "سورة الإسراء، الآية 24" } },
  { id: "dua-distress", title: "دعاء عند الهم", text: "رَبِّ اشْرَحْ لِي صَدْرِي", category: "دعاء تفريج الهم", repetitions: 1, source: { label: "القرآن الكريم", reference: "سورة طه، الآية 25" }, note: "هذا دعاء قرآني ثابت، ولا يُقدَّم هنا كصيغة حديث منسوب." },
  { id: "dua-sunnah-draft", title: "أدعية من السنة", text: "سيُضاف نص موثق بعد مراجعة المصدر.", category: "أدعية من السنة", source: { label: "حالة مراجعة", reference: "لا يُنشر قبل إكمال التوثيق" }, reviewStatus: "مسودة للمراجعة" },
  { id: "dua-sick-draft", title: "دعاء للمريض", text: "سيُضاف نص موثق بعد مراجعة المصدر.", category: "دعاء للمريض", source: { label: "حالة مراجعة", reference: "لا يُنشر قبل إكمال التوثيق" }, reviewStatus: "مسودة للمراجعة" },
  { id: "dua-deceased-draft", title: "دعاء للميت", text: "سيُضاف نص موثق بعد مراجعة المصدر.", category: "دعاء للميت", source: { label: "حالة مراجعة", reference: "لا يُنشر قبل إكمال التوثيق" }, reviewStatus: "مسودة للمراجعة" },
  { id: "dua-travel-draft", title: "دعاء السفر", text: "سيُضاف نص موثق بعد مراجعة المصدر.", category: "دعاء السفر", source: { label: "حالة مراجعة", reference: "لا يُنشر قبل إكمال التوثيق" }, reviewStatus: "مسودة للمراجعة" },
  { id: "dua-provision-draft", title: "دعاء الرزق", text: "سيُضاف نص موثق بعد مراجعة المصدر.", category: "دعاء الرزق", source: { label: "حالة مراجعة", reference: "لا يُنشر قبل إكمال التوثيق" }, reviewStatus: "مسودة للمراجعة" },
  { id: "dua-repentance-draft", title: "دعاء التوبة", text: "سيُضاف نص موثق بعد مراجعة المصدر.", category: "دعاء التوبة", source: { label: "حالة مراجعة", reference: "لا يُنشر قبل إكمال التوثيق" }, reviewStatus: "مسودة للمراجعة" },
  { id: "dua-marriage-draft", title: "أدعية الزواج", text: "سيُضاف نص موثق بعد مراجعة المصدر.", category: "أدعية الزواج", source: { label: "حالة مراجعة", reference: "لا يُنشر قبل إكمال التوثيق" }, reviewStatus: "مسودة للمراجعة" },
  { id: "dua-general-draft", title: "أدعية عامة", text: "سيُضاف نص موثق بعد مراجعة المصدر.", category: "أدعية عامة", source: { label: "حالة مراجعة", reference: "لا يُنشر قبل إكمال التوثيق" }, reviewStatus: "مسودة للمراجعة" },
];

export const duaCategories = ["أدعية القرآن", "أدعية من السنة", "دعاء للوالدين", "دعاء للمريض", "دعاء للميت", "دعاء السفر", "دعاء الرزق", "دعاء تفريج الهم", "دعاء التوبة", "أدعية الزواج", "أدعية عامة"];

export const hadith: ReligiousItem[] = [
  {
    id: "hadith-intentions",
    title: "الأعمال بالنيات",
    text: "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى",
    category: "النية والعمل",
    source: { label: "صحيح البخاري", reference: "كتاب بدء الوحي، حديث 1" },
  },
  {
    id: "hadith-quran-teach",
    title: "تعلم القرآن وتعليمه",
    text: "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ",
    category: "القرآن الكريم",
    source: { label: "صحيح البخاري", reference: "كتاب فضائل القرآن، حديث 5027" },
  },
  {
    id: "hadith-kindness",
    title: "الرحمة",
    text: "مَنْ لا يَرْحَمْ لا يُرْحَمْ",
    category: "الأخلاق",
    source: { label: "صحيح البخاري", reference: "كتاب الأدب" },
    note: "يُعرض رقم الحديث عند توفره في مصدر البيانات المعتمد.",
  },
];

export const lifeSituations: LifeSituation[] = [
  {
    id: "loss",
    title: "توفي شخص أحبه",
    description: "كلمات تثبّت القلب وتفتح باب الدعاء والعمل الصالح.",
    icon: "heart",
    guidance: "المواساة باب رحمة، والدعاء للميت من الأعمال التي ينتفع بها بإذن الله. هذا تذكير عام وليس فتوى تفصيلية.",
    ayat: [verifiedAyat[5]],
    duas: [duas.find((item) => item.id === "ayah-23-118") ?? duas[0]],
    actions: ["الدعاء للميت بإخلاص", "تعزية أهله بلطف", "صدقة جارية إن تيسرت"],
  },
  {
    id: "repentance",
    title: "أريد التوبة",
    description: "ابدأ بخطوة صادقة، واترك ما يبعدك، واطلب العون.",
    icon: "sparkles",
    guidance: "التوبة باب مفتوح، وتحتاج إلى صدق وندم وإقلاع وعزم. في التفاصيل الفقهية يُرجع إلى أهل العلم الموثوقين.",
    ayat: [verifiedAyat[4]],
    duas: [duas.find((item) => item.id === "ayah-7-23") ?? duas[0]],
    actions: ["استغفار صادق", "رد الحقوق إلى أهلها", "اختيار عادة صغيرة ثابتة"],
  },
  {
    id: "sadness",
    title: "أشعر بالهم والحزن",
    description: "ورد قصير يذكّرك باليسر، مع خطوة عملية هادئة.",
    icon: "sun",
    guidance: "الحزن إنساني، واللجوء إلى الله وطلب مساندة أهل الثقة من أسباب العون. إذا طال الحزن أو أثّر على حياتك فاطلب مساعدة مختص.",
    ayat: [verifiedAyat[0], verifiedAyat[1]],
    duas: [duas.find((item) => item.id === "ayah-20-25") ?? duas[0]],
    actions: ["صلاة ركعتين إن تيسر", "التحدث مع شخص موثوق", "التنفس والراحة وشرب الماء"],
  },
  {
    id: "prayer-start",
    title: "أريد أن أبدأ الصلاة",
    description: "خطة لطيفة لبداية متدرجة مع تعلم الأساسيات.",
    icon: "book",
    guidance: "تعلم صفة الصلاة من مصدر موثوق واسأل أهل العلم في بلدك عن التفاصيل التي تحتاجها، وابدأ بالثبات على ما تعلمته.",
    ayat: [verifiedAyat[3]],
    duas: [duas.find((item) => item.id === "ayah-20-114") ?? duas[0]],
    actions: ["تعلم الوضوء", "تثبيت وقت صلاة واحدة ثم الزيادة", "طلب صحبة صالحة مشجعة"],
  },
  {
    id: "travel",
    title: "سأذهب للسفر",
    description: "قائمة قصيرة للسفر وذكر موثق، مع تنبيه لمسائل الرخص.",
    icon: "plane",
    guidance: "لأحكام قصر الصلاة والجمع وغيرها من تفاصيل السفر خلاف وتفصيل، فاستشر مصدرًا فقهيًا موثوقًا لحالتك.",
    ayat: [adhkar[3]],
    duas: [duas.find((item) => item.id === "ayah-2-201") ?? duas[0]],
    actions: ["تجهيز احتياجات الصلاة", "حفظ أوقات الصلاة في الطريق", "الدعاء لأهل البيت"],
  },
  {
    id: "baby",
    title: "رزقني الله بمولود",
    description: "فرحة وشكر وعمل صالح مرتبط بالنعمة.",
    icon: "baby",
    guidance: "اشكر النعمة واطلب للمولود الصلاح، وارجع إلى أهل العلم في السنن والأحكام التي تحتاج تفصيلًا.",
    ayat: [verifiedAyat[4]],
    duas: [duas.find((item) => item.id === "ayah-2-201") ?? duas[0]],
    actions: ["حمد الله", "الدعاء للمولود", "صلة الرحم ومشاركة الفرح"],
  },
  {
    id: "marriage",
    title: "سأتزوج",
    description: "تذكير بالمسؤولية والرحمة وطلب البركة.",
    icon: "heart",
    guidance: "الزواج ميثاق ومسؤولية؛ تعلّم الحقوق والواجبات من مصادر موثوقة، وفي مسائل الخلاف اسأل مختصًا موثوقًا.",
    ayat: [verifiedAyat[4]],
    duas: [duas.find((item) => item.id === "ayah-2-201") ?? duas[0]],
    actions: ["التعلم عن حسن العشرة", "الدعاء بالبركة", "الاتفاق على عادات عبادة مشتركة"],
  },
  {
    id: "istikharah",
    title: "أريد صلاة الاستخارة",
    description: "صفحة تذكيرية لإحالتك إلى شرح موثق قبل التطبيق.",
    icon: "compass",
    guidance: "الاستخارة عبادة لها صفة ودعاء ثابتان في السنة؛ راجع مصدرًا حديثيًا/فقهيًا موثوقًا لقراءة النص الكامل وشرح الخطوات.",
    ayat: [verifiedAyat[2]],
    duas: [duas.find((item) => item.id === "ayah-20-25") ?? duas[0]],
    actions: ["تحديد الأمر بوضوح", "استشارة أهل الخبرة", "اتباع الشرح الموثوق"],
  },
  {
    id: "charity",
    title: "أريد فعل صدقة جارية",
    description: "أفكار عامة لعمل نافع، مع ضرورة التحقق من الجهة.",
    icon: "hand",
    guidance: "اختر عملًا نافعًا مستمرًا وتحقق من موثوقية الجهة والاحتياج الفعلي قبل التبرع.",
    ayat: [verifiedAyat[4]],
    duas: [duas.find((item) => item.id === "ayah-2-201") ?? duas[0]],
    actions: ["تعليم نافع", "المساهمة في ماء أو مصحف عبر جهة موثوقة", "رعاية محتاج بصورة تحفظ كرامته"],
  },
  {
    id: "how-to-pray",
    title: "أريد معرفة كيفية صلاة معينة",
    description: "خريطة تعلم تحيلك إلى صفة الصلاة من مصدر موثوق دون اختصار يخل بالتفاصيل.",
    icon: "book",
    guidance: "صفة الصلاة تختلف في بعض التفاصيل بين أهل العلم؛ استخدم مادة تعليمية موثوقة واسأل معلّمًا أو عالمًا عند الحاجة.",
    ayat: [verifiedAyat[3]],
    duas: [duas.find((item) => item.id === "ayah-20-25") ?? duas[0]],
    actions: ["تحديد الصلاة المقصودة", "قراءة شرح موثق", "التعلم عمليًا من معلّم موثوق"],
  },
  {
    id: "dua-for-someone",
    title: "أريد الدعاء لشخص",
    description: "تذكير بصيغ قرآنية ثابتة ومساحة لنية الدعاء لمن تحب.",
    icon: "hand",
    guidance: "ادعُ لمن تحب بخير، وابتعد عن نسبة صيغة للنبي ﷺ إلا بعد التحقق من مصدرها.",
    ayat: [verifiedAyat[4], verifiedAyat[6]],
    duas: [duas.find((item) => item.id === "ayah-2-201") ?? duas[0]],
    actions: ["تحديد نية الخير", "الدعاء بصدق", "تذكر الدعاء في أوقات الإجابة دون جزم بوقت خاص"],
  },
];

export const learning: LearningItem[] = [
  { id: "wudu", title: "الوضوء", summary: "دليل تعريفي مرتب يساعدك على فهم أبواب الوضوء والرجوع إلى شرح موثق.", sections: ["معنى الطهارة", "ترتيب التعلم", "تنبيهات حول اختلاف بعض التفاصيل"], source: { label: "مادة تعليمية", reference: "تُراجع من مصدر فقهي موثوق قبل النشر النهائي" }, status: "مسودة للمراجعة" },
  { id: "prayer", title: "الصلاة", summary: "مساحة مختصرة للتعلم والتدرج، لا تغني عن الشرح العملي من أهل العلم.", sections: ["الاستعداد للصلاة", "أركان ومواقيت تحتاج شرحًا موثقًا", "أسئلة شائعة"], source: { label: "مادة تعليمية", reference: "يُستكمل المرجع التفصيلي في لوحة الإدارة" }, status: "مسودة للمراجعة" },
  { id: "ghusl", title: "الغسل", summary: "تعريف بالموضوع مع إحالة صريحة للمصادر الفقهية عند اختلاف التفصيل.", sections: ["متى يحتاج المسلم إلى الغسل", "مصدر الخطوات", "الخلاف المعتبر"], source: { label: "مادة تعليمية", reference: "تحتاج إلى مراجعة علمية قبل النشر" }, status: "مسودة للمراجعة" },
  { id: "tayammum", title: "التيمم", summary: "موضوع تعليمي يوضح أن له شروطًا وأحكامًا تختلف باختلاف الحال.", sections: ["متى يُبحث التيمم", "أهمية سؤال أهل العلم", "مصادر التوسع"], source: { label: "مادة تعليمية", reference: "تحتاج إلى مراجعة علمية قبل النشر" }, status: "مسودة للمراجعة" },
  { id: "istikharah", title: "صلاة الاستخارة", summary: "تعرف على أصل العبادة ومكان الرجوع إلى الحديث والشرح الموثوق.", sections: ["الأصل الحديثي", "الخطوات من المصدر", "لا تُبنى القرارات على أحلام لازمة"], source: { label: "السنة النبوية", reference: "صحيح البخاري، كتاب الدعوات" }, status: "منشور" },
  { id: "traveler", title: "صلاة المسافر", summary: "إحاطة أولية بموضوع فيه تفاصيل ومسائل خلافية تستلزم سؤال أهل العلم.", sections: ["تعريف السفر", "القصر والجمع", "اختلاف المذاهب والتطبيق"], source: { label: "مادة تعليمية", reference: "تُراجع من مصدر فقهي موثوق قبل النشر النهائي" }, status: "مسودة للمراجعة" },
  { id: "fasting", title: "الصيام", summary: "مقدمة تربط العبادة بالتعلم من مصدر موثوق، دون إصدار أحكام خاصة بالحالات الفردية.", sections: ["فضل العبادة", "ما يحتاج إلى تعلم", "الحالات الخاصة"], source: { label: "القرآن الكريم", reference: "سورة البقرة، الآيات 183–187" }, status: "مسودة للمراجعة" },
  { id: "zakat", title: "الزكاة", summary: "مدخل للتعلم مع تنبيه إلى أن حساب الأنصبة يحتاج بيانات دقيقة واستشارة مختص.", sections: ["معنى الزكاة", "المال والأنصبة", "استشارة جهة موثوقة"], source: { label: "مادة تعليمية", reference: "تحتاج إلى مراجعة علمية قبل النشر" }, status: "مسودة للمراجعة" },
  { id: "hajj", title: "الحج والعمرة", summary: "خريطة تعلم أولية للمناسك مع إحالات للمصادر الرسمية والفقهية.", sections: ["الاستعداد", "المناسك", "الأسئلة الخاصة"], source: { label: "مادة تعليمية", reference: "تُستكمل بالمصادر الرسمية قبل النشر النهائي" }, status: "مسودة للمراجعة" },
];

export const events: IslamicEvent[] = [
  { id: "ramadan", title: "رمضان", season: "موسم الطاعات", summary: "شهر الصيام والقرآن والصدقة، مع برنامج واقعي يراعي الاستطاعة.", source: { label: "القرآن الكريم", reference: "سورة البقرة، الآيات 183–185" } },
  { id: "dhul-hijjah", title: "العشر الأوائل من ذي الحجة", season: "موسم الطاعات", summary: "أيام فاضلة للتكبير والذكر والعمل الصالح، ويُستكمل المحتوى من المصادر الموثوقة.", source: { label: "السنة النبوية", reference: "مصادر الحديث المعتمدة" } },
  { id: "arafah", title: "يوم عرفة", season: "ذي الحجة", summary: "يوم عظيم من أيام العام، مع إحالة إلى المصادر الموثوقة لأحكامه وفضائله.", source: { label: "السنة النبوية", reference: "مصادر الحديث المعتمدة" } },
  { id: "ashura", title: "عاشوراء", season: "المحرم", summary: "مناسبة تحتاج قراءة متوازنة للتاريخ والفضائل وما ثبت من السنة.", source: { label: "السنة النبوية", reference: "صحيح مسلم، كتاب الصيام" } },
  { id: "eid-al-fitr", title: "عيد الفطر", season: "شوال", summary: "فرحة شكر وصلة ورحمة، مع الرجوع للمصادر في أحكام زكاة الفطر وصلاة العيد.", source: { label: "مادة تعليمية", reference: "تُستكمل من مصادر فقهية موثوقة" } },
  { id: "eid-al-adha", title: "عيد الأضحى", season: "ذي الحجة", summary: "يوم عيد ونسك وصلة، مع إحالات واضحة للمصادر الموثوقة.", source: { label: "مادة تعليمية", reference: "تُستكمل من مصادر فقهية موثوقة" } },
];

export const allSearchable = [...verifiedAyat, ...adhkar, ...duas, ...hadith].filter((item, index, arr) => item.reviewStatus !== "مسودة للمراجعة" && arr.findIndex((candidate) => candidate.id === item.id) === index);

export const dailyWird = {
  ayah: verifiedAyat[0],
  dhikr: adhkar[0],
  hadith: hadith[0],
  action: "اقرأ صفحة من كتاب نافع، أو ساعد شخصًا بخطوة صغيرة اليوم.",
  actionSource: { label: "اقتراح عام", reference: "عمل صالح مفتوح؛ اختر ما يناسبك دون نسبة شرعية" },
};

export const prayerCities = [
  { name: "إب", country: "اليمن", latitude: 13.9667, longitude: 44.1833, offset: 0 },
  { name: "صنعاء", country: "اليمن", latitude: 15.3694, longitude: 44.191, offset: 0 },
  { name: "عدن", country: "اليمن", latitude: 12.7855, longitude: 45.0187, offset: 0 },
  { name: "مكة المكرمة", country: "السعودية", latitude: 21.3891, longitude: 39.8579, offset: 0 },
  { name: "المدينة المنورة", country: "السعودية", latitude: 24.5247, longitude: 39.5692, offset: 0 },
];
