import { useEffect, useState } from "react";
import { ArrowLeft, ShieldCheck, Star } from "lucide-react";
import { useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import Home, { SiteChrome } from "./pages/Home";
import "./index.css";

const pageTitles: Record<string, string> = {
  "/": "رفيق المسلم — رفيقك في عبادتك وحياتك اليومية",
  "/quran": "القرآن الكريم — رفيق المسلم",
  "/adhkar": "الأذكار — رفيق المسلم",
  "/duas": "الأدعية — رفيق المسلم",
  "/prayer-times": "مواقيت الصلاة — رفيق المسلم",
  "/qibla": "اتجاه القبلة — رفيق المسلم",
  "/tasbeeh": "عداد التسبيح — رفيق المسلم",
  "/hijri": "التاريخ الهجري — رفيق المسلم",
  "/life-situations": "مواقف الحياة — رفيق المسلم",
  "/hadith": "الأحاديث النبوية — رفيق المسلم",
  "/learning": "تعلم ديني — رفيق المسلم",
  "/events": "المناسبات الإسلامية — رفيق المسلم",
  "/search": "البحث — رفيق المسلم",
  "/about": "عن رفيق المسلم",
  "/admin": "لوحة التحكم — رفيق المسلم",
};

function SplashScreen({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const timer = window.setTimeout(() => {
      try { sessionStorage.setItem("rafiq-splash-seen", "1"); } catch { /* session storage is optional */ }
      onDone();
    }, 5000);
    return () => window.clearTimeout(timer);
  }, [onDone]);

  return (
    <div className="splash-screen" role="status" aria-label="جاري فتح رفيق المسلم">
      <div className="splash-pattern" aria-hidden="true" />
      <div className="splash-content">
        <div className="splash-symbol" aria-hidden="true"><span /><span /><Star size={18} /></div>
        <div className="splash-kicker"><ShieldCheck size={14} /> مساحة موثوقة وهادئة</div>
        <h1>رفيق المسلم</h1>
        <p className="splash-tagline">رفيقك في عبادتك وحياتك اليومية</p>
        <div className="splash-divider" />
        <div className="splash-credit"><span>إعداد</span><strong>أشرف أحمد الفراص</strong><small>اليمن — محافظة إب<br />مديرية بعدان — قرية ذي الضرب</small></div>
        <div className="splash-progress"><span /></div>
      </div>
      <div className="splash-bottom"><span>نفتح لك مساحة من السكينة</span><ArrowLeft size={15} /></div>
    </div>
  );
}

function AppContent() {
  const [location] = useLocation();
  useEffect(() => {
    document.documentElement.lang = "ar";
    document.documentElement.dir = "rtl";
    document.body.dir = "rtl";
    document.title = pageTitles[location] ?? "رفيق المسلم";
    const description = document.querySelector('meta[name="description"]');
    description?.setAttribute("content", "رفيق المسلم — أدوات يومية ومحتوى إسلامي واضح المصدر، يرافقك في عبادتك وحياتك اليومية.");
  }, [location]);
  return <SiteChrome><Home /></SiteChrome>;
}

function App() {
  const [showSplash, setShowSplash] = useState(() => {
    try { return sessionStorage.getItem("rafiq-splash-seen") !== "1"; } catch { return true; }
  });
  return <ErrorBoundary>{showSplash ? <SplashScreen onDone={() => setShowSplash(false)} /> : <AppContent />}</ErrorBoundary>;
}

export default App;
