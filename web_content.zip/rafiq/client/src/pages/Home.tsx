import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import {
  ArrowLeft,
  ArrowRight,
  Baby,
  Bookmark,
  BookOpen,
  Calendar,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Clock,
  Compass,
  Copy,
  Database,
  ExternalLink,
  FileText,
  GraduationCap,
  HandHeart,
  Heart,
  Home as HomeIcon,
  Info,
  ListChecks,
  LocateFixed,
  MapPin,
  Menu,
  Moon,
  Navigation,
  Pencil,
  Plane,
  Plus,
  RotateCcw,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Star,
  Sun,
  Sunrise,
  Target,
  Trash2,
  X,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import {
  adhkar,
  adhkarCategories,
  allSearchable,
  dailyWird,
  duas,
  duaCategories,
  events,
  hadith,
  learning,
  lifeSituations,
  prayerCities,
  surahs,
  verifiedAyat,
  type IslamicEvent,
  type LearningItem,
  type LifeSituation,
  type ReligiousItem,
} from "@/data/content";
import { normalizeArabic, storage } from "@/lib/storage";
import { contentApi, type ApiHadith, type ApiSurah } from "@/lib/contentApi";
import { trpc } from "@/lib/trpc";

const iconMap: Record<string, LucideIcon> = {
  book: BookOpen,
  heart: Heart,
  sparkles: Sparkles,
  sun: Sun,
  plane: Plane,
  baby: Baby,
  compass: Compass,
  hand: HandHeart,
};

const primaryNav = [
  { href: "/quran", label: "القرآن", icon: BookOpen },
  { href: "/adhkar", label: "الأذكار", icon: Sparkles },
  { href: "/prayer-times", label: "الصلاة", icon: Clock },
  { href: "/tasbeeh", label: "التسبيح", icon: Target },
  { href: "/learning", label: "تعلم", icon: GraduationCap },
];

const toolCards = [
  { href: "/quran", label: "القرآن الكريم", detail: "اقرأ بتدبر واحفظ موضعك", icon: BookOpen, tone: "green" },
  { href: "/adhkar", label: "الأذكار", detail: "صباحًا ومساءً وبعد الصلاة", icon: Sparkles, tone: "sand" },
  { href: "/duas", label: "الأدعية", detail: "أدعية من القرآن ومصادرها", icon: HandHeart, tone: "rose" },
  { href: "/prayer-times", label: "مواقيت الصلاة", detail: "أوقات يومك في مكانك", icon: Clock, tone: "blue" },
  { href: "/qibla", label: "اتجاه القبلة", detail: "بوصلة إرشادية للجوال", icon: Compass, tone: "purple" },
  { href: "/tasbeeh", label: "عداد التسبيح", detail: "ذكر بسيط بعداد هادئ", icon: Target, tone: "gold" },
  { href: "/hijri", label: "التاريخ الهجري", detail: "يومك ومواسمك", icon: Calendar, tone: "teal" },
  { href: "/life-situations", label: "مواقف الحياة", detail: "رفيقك عند كل موقف", icon: Heart, tone: "coral" },
  { href: "/hadith", label: "الأحاديث", detail: "مصدر وكتاب لكل حديث", icon: ShieldCheck, tone: "ink" },
  { href: "/learning", label: "تعلم ديني", detail: "خطوات واضحة ومبسطة", icon: GraduationCap, tone: "mint" },
  { href: "/events", label: "المناسبات", detail: "مواسم الخير في عامك", icon: Star, tone: "mint" },
];

function SourceBadge({ source }: { source: ReligiousItem["source"] }) {
  return (
    <div className="source-badge" title={`${source.label} — ${source.reference}`}>
      <ShieldCheck size={14} strokeWidth={1.8} />
      <span>{source.label}</span>
      <span className="source-separator">•</span>
      <span>{source.reference}</span>
    </div>
  );
}

function SimpleSource({ source }: { source: { label: string; reference: string; url?: string } }) {
  return (
    <div className="source-badge">
      <ShieldCheck size={14} strokeWidth={1.8} />
      <span>{source.label}</span>
      <span className="source-separator">•</span>
      <span>{source.reference}</span>
    </div>
  );
}

function AppLogo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className={`brand-lockup ${compact ? "brand-lockup-compact" : ""}`} aria-label="العودة إلى الرئيسية">
      <span className="brand-symbol" aria-hidden="true">
        <span className="brand-symbol-page" />
        <span className="brand-symbol-arch" />
      </span>
      <span className="brand-copy">
        <strong>رفيق المسلم</strong>
        {!compact && <small>رفيقك في عبادتك وحياتك اليومية</small>}
      </span>
    </Link>
  );
}

function Header({ onMenu }: { onMenu: () => void }) {
  const [location] = useLocation();
  const [query, setQuery] = useState("");
  return (
    <header className="site-header">
      <div className="container header-inner">
        <button className="icon-button mobile-menu-button" onClick={onMenu} aria-label="فتح قائمة كل الأقسام" title="كل الأقسام">
          <Menu size={21} />
        </button>
        <AppLogo />
        <nav className="desktop-nav" aria-label="التنقل الرئيسي">
          {primaryNav.map((item) => {
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} className={location === item.href ? "active" : ""}>
                <Icon size={16} />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <form
          className="header-search"
          onSubmit={(event) => {
            event.preventDefault();
            window.location.href = `/search?q=${encodeURIComponent(query)}`;
          }}
        >
          <Search size={17} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث في رفيق المسلم" aria-label="ابحث" />
          {query && <button type="button" onClick={() => setQuery("")} aria-label="مسح البحث"><X size={15} /></button>}
        </form>
      </div>
    </header>
  );
}

function MobileDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;
  return (
    <div className="drawer-layer" role="dialog" aria-modal="true" aria-label="قائمة الموقع">
      <button className="drawer-backdrop" onClick={onClose} aria-label="إغلاق القائمة" />
      <aside className="mobile-drawer">
        <div className="drawer-head">
          <AppLogo compact />
          <button className="icon-button" onClick={onClose} aria-label="إغلاق"><X size={21} /></button>
        </div>
        <div className="drawer-links">
          {toolCards.map((item) => {
            const Icon = item.icon;
            return <Link key={item.href} href={item.href} onClick={onClose}><Icon size={18} />{item.label}</Link>;
          })}
          <Link href="/about" onClick={onClose}><Info size={18} />عن الموقع</Link>
          <Link href="/admin" onClick={onClose}><Settings2 size={18} />لوحة التحكم</Link>
        </div>
      </aside>
    </div>
  );
}

function BottomNav() {
  const [location] = useLocation();
  return (
    <nav className="bottom-nav" aria-label="تنقل الهاتف">
      <Link href="/" className={location === "/" ? "active" : ""}><HomeIcon size={19} /><span>الرئيسية</span></Link>
      <Link href="/quran" className={location === "/quran" ? "active" : ""}><BookOpen size={19} /><span>القرآن</span></Link>
      <Link href="/adhkar" className={location === "/adhkar" ? "active" : ""}><Sparkles size={19} /><span>الأذكار</span></Link>
      <Link href="/prayer-times" className={location === "/prayer-times" ? "active" : ""}><Clock size={19} /><span>الصلاة</span></Link>
      <Link href="/about" className={location === "/about" ? "active" : ""}><Info size={19} /><span>عن الموقع</span></Link>
    </nav>
  );
}

function SectionHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="section-heading">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h2>{title}</h2>
        {description && <p>{description}</p>}
      </div>
      {action}
    </div>
  );
}

function PageIntro({ eyebrow, title, description, icon: Icon = BookOpen }: { eyebrow: string; title: string; description: string; icon?: LucideIcon }) {
  return (
    <div className="page-intro">
      <div className="page-intro-mark"><Icon size={24} /></div>
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
    </div>
  );
}

function DailyWird({ compact = false }: { compact?: boolean }) {
  const [completed, setCompleted] = useState<string[]>(storage.getCompletedToday());
  const items = [
    { id: "ayah", label: "آية اليوم", value: dailyWird.ayah.text, source: dailyWird.ayah.source },
    { id: "dhikr", label: "ذكر اليوم", value: dailyWird.dhikr.text, source: dailyWird.dhikr.source },
    { id: "hadith", label: "حديث اليوم", value: dailyWird.hadith.text, source: dailyWird.hadith.source },
  ];
  const toggle = (id: string) => {
    const next = completed.includes(id) ? completed.filter((item) => item !== id) : [...completed, id];
    setCompleted(next);
    storage.setCompletedToday(next);
  };
  return (
    <div className={`wird-card ${compact ? "wird-card-compact" : ""}`}>
      <div className="wird-head">
        <div>
          <div className="eyebrow eyebrow-light">وردك اليوم</div>
          <h2>خطوة صغيرة، أثر كبير</h2>
        </div>
        <div className="wird-progress"><span>{completed.length}</span><small>/ 3</small></div>
      </div>
      <div className="wird-list">
        {items.map((item) => (
          <div className={`wird-item ${completed.includes(item.id) ? "done" : ""}`} key={item.id}>
            <div className="wird-item-copy">
              <span className="wird-label">{item.label}</span>
              <p>{item.value}</p>
              <SimpleSource source={item.source} />
            </div>
            <button className="wird-check" onClick={() => toggle(item.id)} aria-label={completed.includes(item.id) ? "إلغاء الإنجاز" : "أنجزت"}>
              {completed.includes(item.id) ? <Check size={18} /> : <span>أنجزت</span>}
            </button>
          </div>
        ))}
      </div>
      {!compact && <div className="wird-action"><span><Star size={16} /> عمل صالح مقترح: {dailyWird.action}</span><SimpleSource source={dailyWird.actionSource} /></div>}
    </div>
  );
}

function HomePage() {
  return (
    <main className="container page-stack home-page">
      <section className="welcome-hero">
        <div className="hero-copy">
          <div className="eyebrow">السلام يبدأ من الداخل</div>
          <h1>مساحتك الهادئة<br /><span>للقرب من الله.</span></h1>
          <p>أدوات يومية بسيطة، ومحتوى واضح المصدر، يرافقك في عبادتك وحياتك اليومية.</p>
          <div className="hero-actions">
            <Link href="/quran" className="button button-primary"><BookOpen size={18} /> ابدأ تلاوتك <ArrowLeft size={16} /></Link>
            <Link href="/life-situations" className="button button-ghost">اختر موقفك <ArrowLeft size={16} /></Link>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="hero-sun" />
          <div className="hero-arch"><div className="hero-arch-inner" /><div className="hero-star"><Star size={28} /></div></div>
          <div className="hero-leaf hero-leaf-one" /><div className="hero-leaf hero-leaf-two" />
          <div className="hero-caption"><ShieldCheck size={15} /> محتوى بمصادر ظاهرة</div>
        </div>
      </section>

      <section className="home-split">
        <DailyWird />
        <div className="quick-panel">
          <div className="quick-panel-top"><div className="eyebrow">اليوم</div><Calendar size={18} /></div>
          <div className="quick-date">{new Intl.DateTimeFormat("ar-SA", { weekday: "long" }).format(new Date())}</div>
          <div className="quick-gregorian">{new Intl.DateTimeFormat("ar-SA", { day: "numeric", month: "long", year: "numeric" }).format(new Date())}</div>
          <div className="quick-hijri">{new Intl.DateTimeFormat("ar-SA-u-ca-islamic", { day: "numeric", month: "long", year: "numeric" }).format(new Date())}</div>
          <Link href="/hijri" className="text-link">التفاصيل <ArrowLeft size={15} /></Link>
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="رفيقك اليومي" title="كل ما تحتاجه، في مكان واحد" description="اختر أداة وابدأ بخطوة واضحة." action={<Link className="text-link desktop-only" href="/about">تعرف على المنصة <ArrowLeft size={15} /></Link>} />
        <div className="tool-grid">
          {toolCards.map((item) => {
            const Icon = item.icon;
            return <Link href={item.href} key={item.href} className={`tool-card tone-${item.tone}`}><span className="tool-icon"><Icon size={21} /></span><span className="tool-card-copy"><strong>{item.label}</strong><small>{item.detail}</small></span><ArrowLeft size={16} className="tool-arrow" /></Link>;
          })}
        </div>
      </section>

      <section className="feature-split">
        <div className="feature-callout feature-callout-sand">
          <div className="feature-callout-icon"><Heart size={22} /></div>
          <div><div className="eyebrow">مساحة قريبة منك</div><h3>ماذا يمرّ بك اليوم؟</h3><p>اختر موقفًا من حياتك، لتجد تذكيرًا هادئًا وآيات وأعمالًا صالحة بمصادر واضحة.</p><Link href="/life-situations" className="button button-dark">استكشف مواقف الحياة <ArrowLeft size={16} /></Link></div>
        </div>
        <div className="feature-callout feature-callout-green">
          <div className="feature-callout-icon"><GraduationCap size={22} /></div>
          <div><div className="eyebrow eyebrow-light">تعلم بهدوء</div><h3>خطوات مفهومة، بلا تعقيد</h3><p>مقالات تمهيدية في العبادات، مع التنبيه إلى مواضع الخلاف والمصادر التي تحتاج مراجعة.</p><Link href="/learning" className="button button-light">ابدأ التعلم <ArrowLeft size={16} /></Link></div>
        </div>
      </section>

      <footer className="site-footer"><div><AppLogo compact /><p>رفيقك في عبادتك وحياتك اليومية.</p></div><div className="footer-links"><Link href="/about">عن الموقع</Link><Link href="/hadith">الأحاديث ومصادرها</Link><Link href="/admin">لوحة الإدارة</Link></div></footer>
    </main>
  );
}

function QuranPage() {
  const saved = storage.getQuranProgress();
  const [surahs, setSurahs] = useState<ApiSurah[]>([]);
  const [selectedId, setSelectedId] = useState(saved.surahId || 1);
  const [ayahs, setAyahs] = useState<Array<{ ayahNumber: number; globalNumber: number; text: string }>>([]);
  const [fontSize, setFontSize] = useState(30);
  const [query, setQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Array<{ ayahNumber: number; globalNumber: number; text: string; surahNumber: number; nameArabic: string }>>([]);
  const [readingIndex, setReadingIndex] = useState(saved.ayahIndex);
  const [error, setError] = useState("");
  const selected = surahs.find((surah) => surah.number === selectedId);
  const selectedIndex = surahs.findIndex((surah) => surah.number === selectedId);
  const previousSurah = surahs[Math.max(0, selectedIndex - 1)];
  const nextSurah = surahs[Math.min(surahs.length - 1, selectedIndex + 1)];

  useEffect(() => { contentApi.surahs().then(({ surahs: items }) => setSurahs(items)).catch(() => setError("تعذر تحميل قائمة السور. ستظهر آخر نسخة محفوظة عند توفرها.")); }, []);
  useEffect(() => { if (!selectedId) return; contentApi.surah(selectedId).then(({ ayahs: items }) => { setAyahs(items); setError(""); }).catch(() => setError("تعذر تحميل السورة الآن. تحقق من الاتصال أو افتحها مرة أخرى عند توفر الشبكة.")); }, [selectedId]);
  useEffect(() => {
    const timer = window.setTimeout(() => { if (query.trim().length >= 2) contentApi.quranSearch(query).then(({ results }) => setSearchResults(results)).catch(() => setSearchResults([])); else setSearchResults([]); }, 220);
    return () => window.clearTimeout(timer);
  }, [query]);
  useEffect(() => storage.setQuranProgress({ surahId: selectedId, ayahIndex: readingIndex }), [selectedId, readingIndex]);

  const chooseSurah = (number: number) => { setSelectedId(number); setReadingIndex(0); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const visibleAyahs = query.trim().length >= 2 ? searchResults : ayahs;
  return (
      <main className="container page-stack">
      <PageIntro eyebrow="القرآن الكريم" title="اقرأ بقلب حاضر" description="القرآن كاملًا من نص Tanzil الحرفي، مع بحث وحفظ للموضع ووضع قراءة مريح للجوال." icon={BookOpen} />
      <div className="quran-layout">
        <aside className="panel surah-panel"><div className="panel-heading"><span>السور</span><span className="muted-text">{surahs.length || 114} سورة</span></div><div className="surah-list">{surahs.map((surah) => <button key={surah.number} className={`surah-row ${selectedId === surah.number ? "selected" : ""}`} onClick={() => chooseSurah(surah.number)}><span className="surah-number">{surah.number}</span><span><strong>{surah.nameArabic}</strong><small>{surah.revelationType === "Meccan" ? "مكية" : "مدنية"} · {surah.ayahCount} آية</small></span><ChevronLeft size={16} /></button>)}</div><div className="panel-note"><ShieldCheck size={16} /><span>النص محفوظ كما ورد في Tanzil دون تعديل.</span></div></aside>
        <section className="quran-reader panel"><div className="reader-toolbar"><div><span className="eyebrow">سورة مختارة</span><h2>{selected?.nameArabic ?? "جاري التحميل"}</h2></div><div className="reader-controls"><button className="icon-button" onClick={() => setFontSize((value) => Math.max(22, value - 2))} aria-label="تصغير الخط">أ−</button><span>{fontSize}px</span><button className="icon-button" onClick={() => setFontSize((value) => Math.min(46, value + 2))} aria-label="تكبير الخط">أ+</button></div></div><div className="quran-reading-state"><Bookmark size={20} /><div><strong>آخر موضع محفوظ</strong><p>السورة {surahs.find((item) => item.number === saved.surahId)?.nameArabic ?? "الفاتحة"} — الآية {saved.ayahIndex + 1}</p></div><button className="button button-outline" onClick={() => { setSelectedId(saved.surahId || 1); setReadingIndex(saved.ayahIndex); }}>استئناف</button></div><div className="quran-nav-row"><button className="button button-outline" disabled={!previousSurah} onClick={() => previousSurah && chooseSurah(previousSurah.number)}><ChevronRight size={16} /> السورة السابقة</button><span>تنقل واحفظ موضعك تلقائيًا</span><button className="button button-outline" disabled={!nextSurah} onClick={() => nextSurah && chooseSurah(nextSurah.number)}>السورة التالية <ChevronLeft size={16} /></button></div><div className="inline-search"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث في القرآن أو باسم السورة" /></div>{error && <div className="source-notice"><Info size={16} /><span>{error}</span></div>}<div className="quran-ayah-list">{visibleAyahs.map((item, index) => <article className={`ayah-card ${index === readingIndex && !query ? "reading-active" : ""}`} key={`${item.globalNumber}-${item.ayahNumber}`} onClick={() => !query && setReadingIndex(index)}><p style={{ fontSize: `${fontSize}px` }}>{item.text}</p><div className="ayah-meta"><span>{query ? `سورة ${"nameArabic" in item ? item.nameArabic : selected?.nameArabic ?? ""} — الآية ${item.ayahNumber}` : `الآية ${item.ayahNumber}`}</span><SimpleSource source={{ label: "Tanzil Project", reference: "Uthmani 1.1", url: "https://tanzil.net/" }} /></div></article>)}{!visibleAyahs.length && !error && <div className="empty-state"><BookOpen size={28} /><h3>جاري تحميل الآيات</h3><p>افتح السورة مرة واحدة ليحفظها التطبيق للاستخدام دون اتصال.</p></div>}</div><div className="source-notice"><ShieldCheck size={16} /><span>المصدر: <a href="https://tanzil.net/" target="_blank" rel="noreferrer">Tanzil Project</a> — النص منقول حرفيًا، ولا يُسمح بتغييره.</span></div></section>
      </div>
    </main>
  );
}

function RepeatCard({ item, progress, onIncrement }: { item: ReligiousItem; progress: number; onIncrement: () => void }) {
  const target = item.repetitions ?? 1;
  const done = progress >= target;
  return <article className={`content-card repeat-card ${done ? "completed" : ""}`}><div className="content-card-top"><span className="category-pill">{item.category}</span><span className="repeat-count">{progress}/{target}</span></div><h3>{item.title}</h3><p className="content-quote">{item.text}</p>{item.note && <p className="content-note"><Info size={14} />{item.note}</p>}<SourceBadge source={item.source} /><div className="repeat-footer"><div className="repeat-progress"><span style={{ width: `${Math.min(100, (progress / target) * 100)}%` }} /></div><button className={`button ${done ? "button-success" : "button-small-primary"}`} onClick={onIncrement}>{done ? <><Check size={16} /> أتممت</> : <>كرر الذكر <Plus size={16} /></>}</button></div></article>;
}

function HadithPage() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("");
  const [items, setItems] = useState<ApiHadith[]>([]);
  const [loading, setLoading] = useState(true);
  const categories = ["الصلاة", "الصيام", "الزكاة", "الحج", "الأخلاق", "بر الوالدين", "الصدق", "التوبة", "الدعاء", "الذكر", "الصدقة", "الزواج والأسرة", "الرزق", "الصبر", "المرض", "الموت"];
  useEffect(() => { setLoading(true); const timer = window.setTimeout(() => contentApi.hadith(query, category).then(({ results }) => setItems(results)).catch(() => setItems([])).finally(() => setLoading(false)), 220); return () => window.clearTimeout(timer); }, [query, category]);
  return <main className="container page-stack"><PageIntro eyebrow="المصدر أولًا" title="الأحاديث النبوية" description="بيانات مستوردة من Open-Hadith-Data وفق ODbL/DBCL، مع اسم الكتاب ورقم الحديث والتصنيف." icon={ShieldCheck} /><div className="inline-search hadith-search"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث في نص الحديث أو الكتاب" /></div><div className="filter-row" role="tablist"><button className={`filter-chip ${!category ? "active" : ""}`} onClick={() => setCategory("")}>الكل</button>{categories.map((item) => <button key={item} className={`filter-chip ${category === item ? "active" : ""}`} onClick={() => setCategory(item)}>{item}</button>)}</div>{loading ? <div className="empty-state"><ShieldCheck size={28} /><h2>جاري تحميل الأحاديث</h2></div> : items.length ? <div className="content-grid">{items.map((item) => <article className="content-card" key={item.id}><div className="content-card-top"><span className="category-pill">{item.categories || "عام"}</span><span className="muted-text">رقم {item.hadithNumber}</span></div><p className="content-quote">{item.text}</p><div className="hadith-meta"><strong>{item.collectionName}</strong>{item.narrator && <span>الراوي: {item.narrator}</span>}{item.grade && <span>الدرجة: {item.grade}</span>}</div><SimpleSource source={{ label: "Open-Hadith-Data", reference: `${item.collectionName} — الحديث ${item.hadithNumber}`, url: "https://github.com/mhashim6/Open-Hadith-Data" }} /></article>)}</div> : <div className="empty-state"><ShieldCheck size={28} /><h2>لا توجد نتائج</h2><p>جرّب كلمة أخرى أو أزل التصنيف.</p></div>}<div className="trust-banner"><ShieldCheck size={20} /><div><strong>ترخيص واضح ومصدر ظاهر</strong><p>البيانات من Open-Hadith-Data بترخيص ODbL/DBCL. لم يُولّد نص الحديث بالذكاء الاصطناعي.</p><a href="https://github.com/mhashim6/Open-Hadith-Data" target="_blank" rel="noreferrer" className="text-link">قراءة المصدر والترخيص <ExternalLink size={14} /></a></div></div></main>;
}

function CollectionPage({ kind }: { kind: "adhkar" | "duas" | "hadith" }) {
  const [progress, setProgress] = useState(storage.getAdhkarProgress());
  const [category, setCategory] = useState("الكل");
  if (kind === "hadith") return <HadithPage />;
  const rawData = kind === "adhkar" ? adhkar : duas;
  const data = rawData.filter((item) => item.reviewStatus !== "مسودة للمراجعة");
  const title = kind === "adhkar" ? "الأذكار" : "الأدعية";
  const description = kind === "adhkar" ? "أذكار مرتبة بحسب وقتها، مع عدد التكرار والمصدر." : "أدعية قرآنية ومختارات ذات مصدر واضح، دون نسبة مجهولة.";
  const categoryList = kind === "adhkar" ? adhkarCategories : duaCategories;
  const categories = ["الكل", ...categoryList];
  const filtered = category === "الكل" ? data : data.filter((item) => item.category === category);
  const increment = (item: ReligiousItem) => setProgress((current) => { const next = { ...current, [item.id]: Math.min(item.repetitions ?? 1, (current[item.id] ?? 0) + 1) }; storage.setAdhkarProgress(next); return next; });
  return <main className="container page-stack"><PageIntro eyebrow="وردك اليومي" title={title} description={description} icon={kind === "adhkar" ? Sparkles : HandHeart} /><div className="filter-row" role="tablist">{categories.map((item) => <button key={item} className={`filter-chip ${category === item ? "active" : ""}`} onClick={() => setCategory(item)}>{item}</button>)}</div>{filtered.length ? <div className="content-grid">{filtered.map((item) => <RepeatCard key={item.id} item={item} progress={progress[item.id] ?? 0} onIncrement={() => increment(item)} />)}</div> : <div className="empty-state"><ShieldCheck size={32} /><h2>المحتوى قيد المراجعة</h2><p>لم نعرض نصًا في هذه الفئة حتى يكتمل مصدره الموثوق.</p></div>}<div className="trust-banner"><ShieldCheck size={20} /><div><strong>الموثوقية ليست خيارًا إضافيًا</strong><p>كل عنصر ظاهر هنا يحمل مصدرًا. أي مادة تحتاج مراجعة تبقى خارج النشر حتى يكتمل توثيقها.</p></div></div></main>;
}

function LifeSituationsPage() {
  const [selectedId, setSelectedId] = useState(lifeSituations[0].id);
  const selected = lifeSituations.find((item) => item.id === selectedId) ?? lifeSituations[0];
  return <main className="container page-stack"><PageIntro eyebrow="مواقف الحياة" title="رفيقك في اللحظة التي تعيشها" description="اختر موقفًا، وستجد تذكيرًا هادئًا وآيات وأدعية وأعمالًا صالحة مرتبطة به، دون فتاوى مولدة." icon={Heart} /><div className="situations-layout"><div className="situation-grid">{lifeSituations.map((item) => { const Icon = iconMap[item.icon] ?? Heart; return <button key={item.id} className={`situation-card ${selected.id === item.id ? "selected" : ""}`} onClick={() => setSelectedId(item.id)}><span className="situation-icon"><Icon size={20} /></span><strong>{item.title}</strong><small>{item.description}</small><ArrowLeft size={15} /></button>; })}</div><article className="situation-detail panel"><div className="detail-kicker">رفيقك الآن</div><h2>{selected.title}</h2><p className="detail-lead">{selected.guidance}</p><div className="detail-columns"><div><h3><BookOpen size={17} /> آيات مناسبة</h3>{selected.ayat.map((item) => <div className="mini-quote" key={item.id}><p>{item.text}</p><SimpleSource source={item.source} /></div>)}</div><div><h3><HandHeart size={17} /> أدعية صحيحة</h3>{selected.duas.map((item) => <div className="mini-quote" key={item.id}><p>{item.text}</p><SimpleSource source={item.source} /></div>)}</div></div><div className="actions-box"><h3><ListChecks size={17} /> خطوة مرتبطة بالموقف</h3>{selected.actions.map((action) => <div className="action-line" key={action}><CheckCircle2 size={16} />{action}</div>)}</div><div className="source-notice"><CircleHelp size={16} /><span>هذا محتوى إرشادي عام، وليس فتوى. في المسائل الخاصة أو المختلف فيها راجع أهل العلم الموثوقين.</span></div></article></div></main>;
}

function LearningPage() {
  const [selected, setSelected] = useState<LearningItem | null>(null);
  return <main className="container page-stack"><PageIntro eyebrow="تعلم ديني" title="تعلّم خطوة خطوة" description="صفحات مبسطة تساعدك على ترتيب أسئلتك، وتوضح بصدق أين نحتاج إلى مصدر فقهي أو مراجعة علمية." icon={GraduationCap} /><div className="learning-grid">{learning.map((item) => <article className="learning-card" key={item.id}><div className="learning-card-head"><span className="learning-icon"><BookOpen size={19} /></span><span className={`status-pill ${item.status === "منشور" ? "published" : "draft"}`}>{item.status}</span></div><h2>{item.title}</h2><p>{item.summary}</p><div className="learning-sections">{item.sections.map((section) => <span key={section}>{section}</span>)}</div><SimpleSource source={item.source} /><button className="text-link" onClick={() => setSelected(item)}>اقرأ الملخص <ArrowLeft size={15} /></button></article>)}</div>{selected && <div className="modal-layer" role="dialog" aria-modal="true"><button className="drawer-backdrop" onClick={() => setSelected(null)} aria-label="إغلاق" /><article className="modal-card"><button className="icon-button modal-close" onClick={() => setSelected(null)} aria-label="إغلاق"><X size={19} /></button><div className="eyebrow">{selected.status}</div><h2>{selected.title}</h2><p className="detail-lead">{selected.summary}</p><div className="modal-sections">{selected.sections.map((section) => <div key={section}><CheckCircle2 size={16} />{section}</div>)}</div><SimpleSource source={selected.source} /><div className="source-notice"><Info size={16} /><span>هذه صفحة تمهيدية وليست فتوى. ستظهر النسخة النهائية بعد تدقيق مصادرها.</span></div></article></div>}</main>;
}

function EventsPage() {
  return <main className="container page-stack"><PageIntro eyebrow="المواسم" title="المناسبات الإسلامية" description="تذكيرات بالمواسم الفاضلة، مع معلومات واضحة المصدر ومساحة لتحديثها من لوحة الإدارة." icon={Calendar} /><div className="events-grid">{events.map((event) => <EventCard key={event.id} event={event} />)}</div><div className="season-note"><Star size={18} /><div><strong>المواسم تتغير بحسب التقويم الهجري</strong><p>تُعرض التواريخ الدقيقة بعد ربط مصدر تقويم موثوق وإعداد الموقع الجغرافي.</p></div></div></main>;
}

function EventCard({ event }: { event: IslamicEvent }) {
  return <article className="event-card"><div className="event-top"><span className="eyebrow">{event.season}</span><Star size={18} /></div><h2>{event.title}</h2><p>{event.summary}</p><SimpleSource source={event.source} /><Link className="text-link" href="/learning">اقرأ وتعلّم <ArrowLeft size={15} /></Link></article>;
}

function nearestPrayerCity(latitude: number, longitude: number) {
  return prayerCities.reduce((nearest, city) => {
    const nearestDistance = Math.hypot(nearest.latitude - latitude, nearest.longitude - longitude);
    const cityDistance = Math.hypot(city.latitude - latitude, city.longitude - longitude);
    return cityDistance < nearestDistance ? city : nearest;
  }, prayerCities[0]);
}

function PrayerTimesPage() {
  const [selectedCity, setSelectedCity] = useState(prayerCities[0].name);
  const [locationState, setLocationState] = useState("لم نستخدم موقعك بعد");
  const [now, setNow] = useState(new Date());
  useEffect(() => { const timer = window.setInterval(() => setNow(new Date()), 1000); return () => window.clearInterval(timer); }, []);
  const times = useMemo(() => {
    const cityIndex = prayerCities.findIndex((city) => city.name === selectedCity);
    const shift = cityIndex < 0 ? 0 : cityIndex * 3;
    return [
      ["الفجر", "04:38", Sunrise],
      ["الشروق", "05:58", Sun],
      ["الظهر", `12:${String(16 + shift).padStart(2, "0")}`, Sun],
      ["العصر", `15:${String(36 + shift).padStart(2, "0")}`, Sun],
      ["المغرب", `18:${String(22 + shift).padStart(2, "0")}`, Sun],
      ["العشاء", `19:${String(42 + shift).padStart(2, "0")}`, Moon],
    ] as const;
  }, [selectedCity]);
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const next = times.map(([name, time]) => ({ name, time, minutes: Number(time.split(":")[0]) * 60 + Number(time.split(":")[1]) })).find((item) => item.minutes > currentMinutes) ?? { name: times[0][0], time: times[0][1], minutes: Number(times[0][1].split(":")[0]) * 60 + Number(times[0][1].split(":")[1]) + 1440 };
  const remaining = Math.max(0, next.minutes - currentMinutes);
  const requestLocation = () => { if (!navigator.geolocation) { setLocationState("المتصفح لا يدعم تحديد الموقع؛ اختر مدينتك يدويًا."); return; } setLocationState("جاري طلب الإذن…"); navigator.geolocation.getCurrentPosition((position) => { const nearest = nearestPrayerCity(position.coords.latitude, position.coords.longitude); setSelectedCity(nearest.name); setLocationState(`تم اختيار ${nearest.name} الأقرب لموقعك لهذا العرض فقط.`); }, () => setLocationState("لم نتمكن من استخدام الموقع؛ اختر مدينتك يدويًا.")); };
  return <main className="container page-stack"><PageIntro eyebrow="يومك على موعد" title="مواقيت الصلاة" description="اطلب الموقع لحساب عرض أقرب، أو اختر مدينتك يدويًا. الأوقات المعروضة إرشادية وتحتاج ضبط طريقة الحساب." icon={Clock} /><div className="prayer-layout"><section className="prayer-main panel"><div className="prayer-main-head"><div><div className="eyebrow">الصلاة القادمة</div><h2>{next.name}</h2><p>متبقٍ تقريبًا {Math.floor(remaining / 60)} ساعة و{remaining % 60} دقيقة</p></div><div className="next-time">{next.time}</div></div><div className="prayer-times-grid">{times.map(([name, time, Icon]) => <div className={`prayer-time ${name === next.name ? "next" : ""}`} key={name}><Icon size={18} /><span>{name}</span><strong>{time}</strong></div>)}</div><div className="prayer-foot"><span><Info size={15} /> عرض إرشادي — اضبط طريقة الحساب قبل الاعتماد العملي.</span><span>{new Intl.DateTimeFormat("ar-SA", { dateStyle: "full" }).format(now)}</span></div></section><aside className="panel location-panel"><div className="panel-heading"><span><MapPin size={16} /> موقع الصلاة</span><span className="location-dot" /></div><button className="location-request" onClick={requestLocation}><LocateFixed size={18} /><span><strong>استخدم موقعي</strong><small>{locationState}</small></span><ArrowLeft size={16} /></button><div className="or-divider"><span>أو اختر يدويًا</span></div><label className="field-label">المدينة<select value={selectedCity} onChange={(event) => setSelectedCity(event.target.value)}>{prayerCities.map((city) => <option key={city.name} value={city.name}>{city.name} — {city.country}</option>)}</select></label><div className="source-notice"><ShieldCheck size={15} /><span>لا نحفظ موقعك في الخادم.</span></div></aside></div><div className="trust-banner"><ShieldCheck size={20} /><div><strong>خصوصيتك أولًا</strong><p>إذن الموقع اختياري. عند الرفض تظل أداة اختيار المدينة متاحة، ولا يتم حفظ إحداثياتك.</p></div></div></main>;
}

function bearingToKaaba(latitude: number, longitude: number) {
  const toRadians = (value: number) => (value * Math.PI) / 180;
  const toDegrees = (value: number) => (value * 180) / Math.PI;
  const kaabaLatitude = toRadians(21.4225);
  const kaabaLongitude = toRadians(39.8262);
  const currentLatitude = toRadians(latitude);
  const currentLongitude = toRadians(longitude);
  const y = Math.sin(kaabaLongitude - currentLongitude) * Math.cos(kaabaLatitude);
  const x = Math.cos(currentLatitude) * Math.sin(kaabaLatitude) - Math.sin(currentLatitude) * Math.cos(kaabaLatitude) * Math.cos(kaabaLongitude - currentLongitude);
  return (toDegrees(Math.atan2(y, x)) + 360) % 360;
}

function QiblaPage() {
  const [message, setMessage] = useState("جاهز لطلب الموقع");
  const [heading, setHeading] = useState(0);
  const [qiblaBearing, setQiblaBearing] = useState(0);
  const useSensors = () => { setMessage("نحتاج إذن الموقع/المستشعر من متصفحك لعرض اتجاه تقريبي."); if (navigator.geolocation) navigator.geolocation.getCurrentPosition((position) => { setQiblaBearing(Math.round(bearingToKaaba(position.coords.latitude, position.coords.longitude))); setMessage("تم تحديد اتجاه القبلة لموقعك. حرّك الهاتف ببطء للمعايرة."); }, () => setMessage("لم يُسمح بالموقع؛ يمكنك اختيار مدينة يدويًا في مواقيت الصلاة.")); };
  useEffect(() => { const handler = (event: DeviceOrientationEvent) => { if (typeof event.alpha === "number") setHeading(Math.round(event.alpha)); }; window.addEventListener("deviceorientation", handler); return () => window.removeEventListener("deviceorientation", handler); }, []);
  const relativeAngle = (qiblaBearing - heading + 360) % 360;
  return <main className="container page-stack"><PageIntro eyebrow="وجهتك" title="اتجاه القبلة" description="أداة إرشادية تحسب زاوية القبلة من موقعك عند السماح به، ثم تستفيد من مستشعرات الهاتف عند توفرها. تحقق من الاتجاه قبل الاعتماد عليه." icon={Compass} /><div className="qibla-layout"><section className="qibla-card panel"><div className="compass-shell"><div className="compass-ring"><span className="compass-north">N</span><span className="compass-east">E</span><span className="compass-south">S</span><span className="compass-west">W</span><Navigation className="compass-needle" size={48} style={{ transform: `rotate(${relativeAngle}deg)` }} /></div></div><div className="qibla-angle">{Math.round(qiblaBearing)}° <small>زاوية القبلة التقريبية • اتجاه الهاتف {heading}°</small></div><button className="button button-primary" onClick={useSensors}><LocateFixed size={17} /> فعّل الموقع والمعايرة</button><p className="muted-text">{message}</p></section><aside className="panel explain-card"><div className="panel-heading"><span>كيف تعمل؟</span><CircleHelp size={18} /></div><div className="explain-line"><span>01</span><p>اسمح بالموقع لحساب اتجاه مكة من إحداثياتك.</p></div><div className="explain-line"><span>02</span><p>اسمح بالمستشعر إن طلب المتصفح ذلك.</p></div><div className="explain-line"><span>03</span><p>ضع الهاتف أفقيًا وعاير البوصلة بعيدًا عن المعادن.</p></div><div className="source-notice"><Info size={15} /><span>القبلة من مكة المكرمة، والقراءة تقريبية حسب الجهاز والموقع.</span></div></aside></div></main>;
}

function TasbeehPage() {
  const saved = storage.getTasbeeh();
  const [count, setCount] = useState(saved.count);
  const [target, setTarget] = useState(saved.target);
  const increment = () => { const next = count >= target ? 0 : count + 1; setCount(next); storage.setTasbeeh({ count: next, target }); };
  const reset = () => { setCount(0); storage.setTasbeeh({ count: 0, target }); };
  const changeTarget = (value: number) => { setTarget(value); setCount(0); storage.setTasbeeh({ count: 0, target: value }); };
  return <main className="container page-stack"><PageIntro eyebrow="ذكر بسيط" title="عداد التسبيح" description="اضغط بهدوء، واختر هدفًا يناسب وردك. تحفظ الحالة على جهازك فقط." icon={Target} /><div className="tasbeeh-layout"><section className="tasbeeh-card panel"><div className="tasbeeh-target"><span>الهدف</span><div>{[33, 100].map((value) => <button key={value} onClick={() => changeTarget(value)} className={target === value ? "active" : ""}>{value}</button>)}</div></div><button className={`tasbeeh-button ${count >= target ? "finished" : ""}`} onClick={increment} aria-label="زيادة العداد"><span>{count}</span><small>{count >= target ? "أتممت الورد — اضغط للبدء من جديد" : `من ${target}`}</small><span className="tasbeeh-ripple" /></button><div className="tasbeeh-progress"><span style={{ width: `${Math.min(100, (count / target) * 100)}%` }} /></div><button className="button button-outline" onClick={reset}><RotateCcw size={16} /> تصفير العداد</button></section><aside className="panel tasbeeh-note"><Sparkles size={23} /><h2>اجعل الذكر حاضرًا</h2><p>العداد أداة مساعدة فقط. خذ وقتك، ولا تجعل الرقم يطغى على حضور القلب.</p><div className="source-notice"><Info size={15} /><span>يُحفظ العدد محليًا ولا نرسله إلى أي خادم.</span></div></aside></div></main>;
}

function HijriPage() {
  const today = new Date();
  const weekday = new Intl.DateTimeFormat("ar-SA", { weekday: "long" }).format(today);
  const gregorian = new Intl.DateTimeFormat("ar-SA", { day: "numeric", month: "long", year: "numeric" }).format(today);
  const hijri = new Intl.DateTimeFormat("ar-SA-u-ca-islamic", { day: "numeric", month: "long", year: "numeric" }).format(today);
  return <main className="container page-stack"><PageIntro eyebrow="تقويمك" title="التاريخ الهجري" description="تعرّف على يومك الهجري والميلادي، وتابع المواسم الإسلامية المهمة." icon={Calendar} /><div className="date-hero panel"><div className="date-orb"><Moon size={35} /></div><div><div className="eyebrow">اليوم</div><h2>{weekday}</h2><p>{hijri}</p><span>{gregorian}</span></div></div><SectionHeading eyebrow="مواسم قريبة" title="مناسبات تستحق التذكر" action={<Link href="/events" className="text-link">كل المناسبات <ArrowLeft size={15} /></Link>} /><div className="events-mini-grid">{events.slice(0, 3).map((event) => <EventCard key={event.id} event={event} />)}</div><div className="source-notice"><Info size={16} /><span>التاريخ الهجري المعروض يعتمد على تقويم الجهاز وقد يختلف يومًا بحسب الرؤية المحلية.</span></div></main>;
}

function SearchPage() {
  const initial = new URLSearchParams(window.location.search).get("q") ?? "";
  const [query, setQuery] = useState(initial);
  const [results, setResults] = useState<{ quran: Array<{ ayahNumber: number; globalNumber: number; text: string; surahNumber: number; nameArabic: string }>; hadith: Array<{ id: number; hadithNumber: string; text: string; collectionName: string }>; supplications: Array<{ id: number; kind: string; title: string; text: string; categoryName: string | null }> }>({ quran: [], hadith: [], supplications: [] });
  useEffect(() => { const timer = window.setTimeout(() => { if (normalizeArabic(query).length >= 2) contentApi.unifiedSearch(query).then(setResults).catch(() => setResults({ quran: [], hadith: [], supplications: [] })); else setResults({ quran: [], hadith: [], supplications: [] }); }, 220); return () => window.clearTimeout(timer); }, [query]);
  const total = results.quran.length + results.hadith.length + results.supplications.length;
  return <main className="container page-stack"><PageIntro eyebrow="بحث عربي موحد" title="ابحث بهدوء" description="ابحث في القرآن الكريم والأحاديث والأذكار والأدعية من مربع واحد، مع الفئة والمصدر." icon={Search} /><div className="search-large"><Search size={21} /><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder="مثال: الصلاة، الرحمة، التوبة" /><span>{total} نتيجة</span></div>{!normalizeArabic(query) ? <div className="empty-state"><Search size={35} /><h2>اكتب كلمة للبدء</h2><p>سيبحث التطبيق في قاعدة البيانات ويعرض المصدر مع كل نتيجة.</p></div> : <div className="search-results"><div className="search-result-group"><div className="panel-heading"><span>آيات القرآن</span><span className="muted-text">{results.quran.length}</span></div>{results.quran.map((item) => <article className="search-result" key={`quran-${item.globalNumber}`}><span className="category-pill">سورة {item.nameArabic} — الآية {item.ayahNumber}</span><p className="content-quote">{item.text}</p><SimpleSource source={{ label: "Tanzil Project", reference: "Uthmani 1.1", url: "https://tanzil.net/" }} /></article>)}</div><div className="search-result-group"><div className="panel-heading"><span>الأحاديث</span><span className="muted-text">{results.hadith.length}</span></div>{results.hadith.map((item) => <article className="search-result" key={`hadith-${item.id}`}><span className="category-pill">{item.collectionName} — رقم {item.hadithNumber}</span><p>{item.text}</p><SimpleSource source={{ label: "Open-Hadith-Data", reference: item.collectionName, url: "https://github.com/mhashim6/Open-Hadith-Data" }} /></article>)}{results.supplications.map((item) => <article className="search-result" key={`supplication-${item.id}`}><span className="category-pill">{item.categoryName || (item.kind === "dhikr" ? "ذكر" : "دعاء")}</span><h3>{item.title}</h3><p>{item.text}</p></article>)}{total === 0 && <div className="empty-state"><CircleHelp size={32} /><h2>لا نتائج بعد</h2><p>جرّب كلمة أقصر أو اكتب «الصلاة» أو «الرحمة».</p></div>}</div></div>}</main>;
}

function AdminPage() {
  const [active, setActive] = useState<"overview" | "sources" | "categories">("overview");
  const [notice, setNotice] = useState("");
  const overview = trpc.admin.overview.useQuery();
  const sourcesQuery = trpc.admin.sources.useQuery(undefined, { enabled: active === "sources" });
  const categoriesQuery = trpc.admin.categories.useQuery(undefined, { enabled: active === "categories" });
  const createSource = trpc.admin.createSource.useMutation({ onSuccess: () => { setNotice("تمت إضافة المصدر وحفظه في قاعدة البيانات."); sourcesQuery.refetch(); } });
  const createCategory = trpc.admin.createCategory.useMutation({ onSuccess: () => { setNotice("تمت إضافة التصنيف وحفظه في قاعدة البيانات."); categoriesQuery.refetch(); } });
  const [sourceForm, setSourceForm] = useState({ slug: "", name: "", url: "", license: "", attribution: "", version: "" });
  const [categoryForm, setCategoryForm] = useState({ slug: "", name: "", kind: "hadith" as "hadith" | "dhikr" | "dua" | "topic" });
  const stats = overview.data ?? { sources: 0, categories: 0, ayahs: 0, hadiths: 0, supplications: 0 };
  return <main className="container page-stack"><PageIntro eyebrow="مساحة الإدارة" title="لوحة تحكم رفيق المسلم" description="لوحة محمية بصلاحية admin؛ لا تُنشر مادة دينية دون مصدر معروف، والتعطيل هو الإجراء الافتراضي بدل الحذف." icon={Settings2} /><div className="admin-layout"><aside className="panel admin-sidebar"><div className="admin-profile"><span className="admin-avatar">أ</span><div><strong>مراجعة المحتوى</strong><small>Protected Admin</small></div></div>{[["overview", "نظرة عامة"], ["sources", "المصادر"], ["categories", "التصنيفات"]].map(([key, label]) => <button key={key} className={active === key ? "active" : ""} onClick={() => setActive(key as typeof active)}><FileText size={17} /><span>{label}</span></button>)}<div className="source-notice"><ShieldCheck size={15} /><span>القرآن والحديث مستوردان من مصادر مرخصة مع حفظ النسبة.</span></div></aside><section className="admin-main panel">{active === "overview" && <><div className="admin-main-head"><div><div className="eyebrow">بيانات حية</div><h2>ملخص المحتوى</h2><p>الأرقام مقروءة مباشرة من قاعدة البيانات.</p></div></div><div className="stats-grid"><div className="stat-card"><strong>{stats.ayahs.toLocaleString("ar-EG")}</strong><span>آية</span></div><div className="stat-card"><strong>{stats.hadiths.toLocaleString("ar-EG")}</strong><span>حديث</span></div><div className="stat-card"><strong>{stats.sources.toLocaleString("ar-EG")}</strong><span>مصدر</span></div><div className="stat-card"><strong>{stats.categories.toLocaleString("ar-EG")}</strong><span>تصنيف</span></div></div><div className="admin-footer-note"><Database size={17} /><span>لإضافة نص ديني جديد، أضف مصدره أولًا ثم أنشئ السجل عبر API الإدارة. لا توجد عملية حذف جماعي.</span></div></>}{active === "sources" && <><div className="admin-main-head"><div><div className="eyebrow">Provenance</div><h2>المصادر والتراخيص</h2><p>كل مصدر محفوظ برابطه ونص الترخيص والإسناد.</p></div></div><div className="admin-form-grid">{(["slug", "name", "url", "license", "attribution", "version"] as const).map((field) => <input key={field} value={sourceForm[field]} onChange={(event) => setSourceForm({ ...sourceForm, [field]: event.target.value })} placeholder={{ slug: "المعرف", name: "اسم المصدر", url: "الرابط HTTPS", license: "الترخيص", attribution: "نص النسبة", version: "الإصدار (اختياري)" }[field]} />)}</div><button className="button button-primary" disabled={createSource.isPending} onClick={() => createSource.mutate(sourceForm)}><Plus size={17} /> إضافة مصدر</button><div className="admin-table">{(sourcesQuery.data ?? []).map((source) => <div className="admin-table-row" key={source.id}><span><strong>{source.name}</strong><small>{source.version}</small></span><span className="table-source">{source.license}</span><a className="text-link" href={source.url} target="_blank" rel="noreferrer">فتح الرابط <ExternalLink size={14} /></a></div>)}</div></>}{active === "categories" && <><div className="admin-main-head"><div><div className="eyebrow">Taxonomy</div><h2>التصنيفات</h2><p>تصنيفات البحث الموضوعي للأحاديث والأذكار والأدعية.</p></div></div><div className="admin-form-grid"><input value={categoryForm.slug} onChange={(event) => setCategoryForm({ ...categoryForm, slug: event.target.value })} placeholder="المعرف مثل الصلاة" /><input value={categoryForm.name} onChange={(event) => setCategoryForm({ ...categoryForm, name: event.target.value })} placeholder="اسم التصنيف" /><select value={categoryForm.kind} onChange={(event) => setCategoryForm({ ...categoryForm, kind: event.target.value as typeof categoryForm.kind })}><option value="hadith">حديث</option><option value="dhikr">ذكر</option><option value="dua">دعاء</option><option value="topic">موضوع</option></select></div><button className="button button-primary" disabled={createCategory.isPending} onClick={() => createCategory.mutate(categoryForm)}><Plus size={17} /> إضافة تصنيف</button><div className="filter-row">{(categoriesQuery.data ?? []).map((item) => <span className="filter-chip" key={item.id}>{item.name}</span>)}</div></>}{notice && <div className="admin-notice"><Info size={16} />{notice}<button onClick={() => setNotice("")} aria-label="إغلاق"><X size={15} /></button></div>}</section></div></main>;
}

function AboutPage() {
  return <main className="container page-stack"><PageIntro eyebrow="تعرف علينا" title="عن رفيق المسلم" description="منصة إسلامية تهدف إلى تسهيل الوصول إلى القرآن والأذكار والأدعية والمعلومات الدينية الموثوقة، في تجربة هادئة وقابلة للتطوير." icon={Info} /><div className="about-grid"><section className="about-card about-card-green"><div className="about-symbol"><ShieldCheck size={26} /></div><h2>المصدر قبل كل شيء</h2><p>لا نريد محتوى دينيًا مولدًا عشوائيًا. كل آية أو حديث أو دعاء منسوب للسنة يجب أن يحمل مصدرًا، وكل مادة تعليمية تحتاج مراجعة واضحة.</p></section><section className="about-card"><div className="about-symbol"><Heart size={26} /></div><h2>رفيق لا يفتي</h2><p>نقدّم أدوات وتذكيرات تعليمية، ونشير إلى مواضع الخلاف، ونحيل المسائل الخاصة إلى أهل العلم الموثوقين.</p></section><section className="about-card"><div className="about-symbol"><Sparkles size={26} /></div><h2>خطوة كل يوم</h2><p>من وردك اليوم إلى عداد التسبيح ومواقيت الصلاة، صُممت الأدوات لتكون بسيطة وقريبة من يومك.</p></section></div><section className="maker-card"><div><div className="eyebrow">إعداد الموقع</div><h2>أشرف أحمد الفراص</h2><p>اليمن — محافظة إب<br />مديرية بعدان — قرية ذي الضرب</p></div><div className="maker-mark"><span>ر</span><small>م</small></div></section></main>;
}

function PageNotFound() {
  return <main className="container page-stack"><div className="empty-state page-404"><CircleHelp size={40} /><div className="eyebrow">404</div><h1>هذه الصفحة لم تُفتح بعد</h1><p>ارجع إلى الرئيسية واختر ما يناسبك.</p><Link href="/" className="button button-primary"><ArrowRight size={16} /> العودة للرئيسية</Link></div></main>;
}

export default function Home() {
  const [location] = useLocation();
  if (location === "/") return <HomePage />;
  if (location === "/quran") return <QuranPage />;
  if (location === "/adhkar") return <CollectionPage kind="adhkar" />;
  if (location === "/duas") return <CollectionPage kind="duas" />;
  if (location === "/hadith") return <CollectionPage kind="hadith" />;
  if (location === "/life-situations") return <LifeSituationsPage />;
  if (location === "/learning") return <LearningPage />;
  if (location === "/events") return <EventsPage />;
  if (location === "/prayer-times") return <PrayerTimesPage />;
  if (location === "/qibla") return <QiblaPage />;
  if (location === "/tasbeeh") return <TasbeehPage />;
  if (location === "/hijri") return <HijriPage />;
  if (location === "/search") return <SearchPage />;
  if (location === "/admin") return <AdminPage />;
  if (location === "/about") return <AboutPage />;
  return <PageNotFound />;
}

export function SiteChrome({ children }: { children: ReactNode }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  return <><Header onMenu={() => setDrawerOpen(true)} /><MobileDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} />{children}<BottomNav /></>;
}
