# Android وiOS لاحقًا

المشروع الآن PWA مملوكة للتطبيق، ويمكن تثبيتها من متصفح الهاتف. المسار المقترح للتطبيقين الأصليين هو **Capacitor** فوق `dist/public`، مع `appId` محفوظ في `capacitor.config.ts`.

## بعد اعتماد إخراج native

```bash
pnpm build
pnpm add @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios
npx cap add android
npx cap add ios
npx cap sync
```

بعدها تُفتح مشاريع Android Studio وXcode لإعداد signing، الأذونات (الموقع والبوصلة)، وسياسات المتاجر. لا تُضاف مجلدات `android/` أو `ios/` إلى هذه النسخة قبل اختيار بيئة البناء وتوقيع التطبيقات.

## البيانات دون اتصال

يخزن service worker واجهة التطبيق والأصول، ويحتفظ باستجابات `/api/content/*` التي فتحها المستخدم سابقًا. عند الاتصال، تُحدّث الاستجابات من الشبكة؛ عند انقطاعها، تُعرض آخر نسخة مخزنة. بيانات الحساب والإدارة لا تُخزّن في cache العام.
