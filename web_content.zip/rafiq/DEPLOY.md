# نشر رفيق المسلم

## 1) تشغيل الموقع كخدمة Node/Docker

المشروع يحتوي على `Dockerfile` ويستمع على المنفذ `3000`.

المتطلبات في بيئة الاستضافة:
- Node.js 22 أو Docker
- MySQL إذا كنت ستستخدم قاعدة البيانات والميزات الديناميكية
- متغيرات البيئة الموجودة في `.env.example`

أوامر البناء والتشغيل:

```bash
pnpm install --frozen-lockfile
pnpm build
NODE_ENV=production pnpm start
```

أو باستخدام Docker:

```bash
docker build -t rafiq-muslim .
docker run --env-file .env -p 3000:3000 rafiq-muslim
```

اختبار الصحة:
`GET /api/health` يجب أن يعيد `{\"status\":\"ok\"}`.

## 2) PWA

بعد نشر الموقع عبر HTTPS يمكن للمستخدم تثبيت «رفيق المسلم» من المتصفح.
الـ manifest وService Worker موجودان بالفعل.

## 3) Android / iOS

الواجهة مجهزة لـ Capacitor. بعد تثبيت حزم المنصات على جهاز التطوير:

```bash
pnpm add @capacitor/android @capacitor/ios
pnpm build
npx cap add android
npx cap add ios
npx cap sync
```

ثم افتح مشروع Android في Android Studio ومشروع iOS في Xcode لإعداد التوقيع والنشر في المتاجر.

## 4) الدومين وSEO

تم حذف رابط Manus التجريبي الثابت من HTML وsitemap. قبل النشر النهائي استخدم دومينك الحقيقي، مثل:

```bash
SITE_URL=https://your-domain.com
```

ثم حدّث `sitemap.xml` ليحتوي على روابط الدومين الحقيقي.

## 5) ملاحظات مهمة

- لا ترفع ملف `.env` إلى Git أو إلى ZIP عام.
- لا تضع مفاتيح API داخل ملفات `client/`.
- شاشة البداية تظهر لأول فتح في جلسة المتصفح لمدة 5 ثوانٍ كما تم إعدادها.
