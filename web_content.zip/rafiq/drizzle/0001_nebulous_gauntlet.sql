CREATE TABLE `categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(120) NOT NULL,
	`name` varchar(160) NOT NULL,
	`kind` enum('hadith','dhikr','dua','topic') NOT NULL,
	CONSTRAINT `categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `categories_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `hadith_categories` (
	`hadithId` int NOT NULL,
	`categoryId` int NOT NULL,
	CONSTRAINT `hadith_categories_hadithId_categoryId_pk` PRIMARY KEY(`hadithId`,`categoryId`)
);
--> statement-breakpoint
CREATE TABLE `hadith_collections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(120) NOT NULL,
	`name` varchar(255) NOT NULL,
	`sourceId` int NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 0,
	CONSTRAINT `hadith_collections_id` PRIMARY KEY(`id`),
	CONSTRAINT `hadith_collections_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `hadiths` (
	`id` int AUTO_INCREMENT NOT NULL,
	`collectionId` int NOT NULL,
	`hadithNumber` varchar(80) NOT NULL,
	`text` text NOT NULL,
	`narrator` text,
	`grade` varchar(160),
	`sourceId` int NOT NULL,
	`enabled` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `hadiths_id` PRIMARY KEY(`id`),
	CONSTRAINT `hadith_collection_number_unique` UNIQUE(`collectionId`,`hadithNumber`)
);
--> statement-breakpoint
CREATE TABLE `quran_ayahs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`surahId` int NOT NULL,
	`ayahNumber` int NOT NULL,
	`globalNumber` int NOT NULL,
	`text` text NOT NULL,
	`sourceId` int NOT NULL,
	`enabled` boolean NOT NULL DEFAULT true,
	CONSTRAINT `quran_ayahs_id` PRIMARY KEY(`id`),
	CONSTRAINT `quran_ayah_surah_number_unique` UNIQUE(`surahId`,`ayahNumber`)
);
--> statement-breakpoint
CREATE TABLE `quran_surahs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`number` int NOT NULL,
	`nameArabic` varchar(160) NOT NULL,
	`nameEnglish` varchar(160),
	`revelationType` varchar(40),
	`ayahCount` int NOT NULL,
	`sourceId` int NOT NULL,
	CONSTRAINT `quran_surahs_id` PRIMARY KEY(`id`),
	CONSTRAINT `quran_surahs_number_unique` UNIQUE(`number`)
);
--> statement-breakpoint
CREATE TABLE `sources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(120) NOT NULL,
	`name` varchar(255) NOT NULL,
	`url` varchar(500) NOT NULL,
	`license` varchar(255) NOT NULL,
	`attribution` text NOT NULL,
	`version` varchar(120),
	`verifiedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sources_id` PRIMARY KEY(`id`),
	CONSTRAINT `sources_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `supplications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kind` enum('dhikr','dua') NOT NULL,
	`title` varchar(255) NOT NULL,
	`text` text NOT NULL,
	`categoryId` int,
	`repetitions` int,
	`sourceId` int NOT NULL,
	`enabled` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `supplications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `hadith_categories` ADD CONSTRAINT `hadith_categories_hadithId_hadiths_id_fk` FOREIGN KEY (`hadithId`) REFERENCES `hadiths`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `hadith_categories` ADD CONSTRAINT `hadith_categories_categoryId_categories_id_fk` FOREIGN KEY (`categoryId`) REFERENCES `categories`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `hadith_collections` ADD CONSTRAINT `hadith_collections_sourceId_sources_id_fk` FOREIGN KEY (`sourceId`) REFERENCES `sources`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `hadiths` ADD CONSTRAINT `hadiths_collectionId_hadith_collections_id_fk` FOREIGN KEY (`collectionId`) REFERENCES `hadith_collections`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `hadiths` ADD CONSTRAINT `hadiths_sourceId_sources_id_fk` FOREIGN KEY (`sourceId`) REFERENCES `sources`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `quran_ayahs` ADD CONSTRAINT `quran_ayahs_surahId_quran_surahs_id_fk` FOREIGN KEY (`surahId`) REFERENCES `quran_surahs`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `quran_ayahs` ADD CONSTRAINT `quran_ayahs_sourceId_sources_id_fk` FOREIGN KEY (`sourceId`) REFERENCES `sources`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `quran_surahs` ADD CONSTRAINT `quran_surahs_sourceId_sources_id_fk` FOREIGN KEY (`sourceId`) REFERENCES `sources`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `supplications` ADD CONSTRAINT `supplications_categoryId_categories_id_fk` FOREIGN KEY (`categoryId`) REFERENCES `categories`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `supplications` ADD CONSTRAINT `supplications_sourceId_sources_id_fk` FOREIGN KEY (`sourceId`) REFERENCES `sources`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `hadith_collection_idx` ON `hadiths` (`collectionId`);--> statement-breakpoint
CREATE INDEX `hadith_enabled_idx` ON `hadiths` (`enabled`);--> statement-breakpoint
CREATE INDEX `quran_ayah_search_idx` ON `quran_ayahs` (`surahId`,`ayahNumber`);--> statement-breakpoint
CREATE INDEX `quran_surahs_source_idx` ON `quran_surahs` (`sourceId`);--> statement-breakpoint
CREATE INDEX `supplications_kind_idx` ON `supplications` (`kind`);--> statement-breakpoint
CREATE INDEX `supplications_enabled_idx` ON `supplications` (`enabled`);