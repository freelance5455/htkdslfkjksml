import { boolean, int, index, mysqlEnum, mysqlTable, primaryKey, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const sources = mysqlTable("sources", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  url: varchar("url", { length: 500 }).notNull(),
  license: varchar("license", { length: 255 }).notNull(),
  attribution: text("attribution").notNull(),
  version: varchar("version", { length: 120 }),
  verifiedAt: timestamp("verifiedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const quranSurahs = mysqlTable("quran_surahs", {
  id: int("id").autoincrement().primaryKey(),
  number: int("number").notNull().unique(),
  nameArabic: varchar("nameArabic", { length: 160 }).notNull(),
  nameEnglish: varchar("nameEnglish", { length: 160 }),
  revelationType: varchar("revelationType", { length: 40 }),
  ayahCount: int("ayahCount").notNull(),
  sourceId: int("sourceId").notNull().references(() => sources.id),
}, (table) => ({ sourceIndex: index("quran_surahs_source_idx").on(table.sourceId) }));

export const quranAyahs = mysqlTable("quran_ayahs", {
  id: int("id").autoincrement().primaryKey(),
  surahId: int("surahId").notNull().references(() => quranSurahs.id),
  ayahNumber: int("ayahNumber").notNull(),
  globalNumber: int("globalNumber").notNull(),
  text: text("text").notNull(),
  sourceId: int("sourceId").notNull().references(() => sources.id),
  enabled: boolean("enabled").default(true).notNull(),
}, (table) => ({
  surahAyahUnique: uniqueIndex("quran_ayah_surah_number_unique").on(table.surahId, table.ayahNumber),
  searchIndex: index("quran_ayah_search_idx").on(table.surahId, table.ayahNumber),
}));

export const hadithCollections = mysqlTable("hadith_collections", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  sourceId: int("sourceId").notNull().references(() => sources.id),
  sortOrder: int("sortOrder").default(0).notNull(),
});

export const hadiths = mysqlTable("hadiths", {
  id: int("id").autoincrement().primaryKey(),
  collectionId: int("collectionId").notNull().references(() => hadithCollections.id),
  hadithNumber: varchar("hadithNumber", { length: 80 }).notNull(),
  text: text("text").notNull(),
  narrator: text("narrator"),
  grade: varchar("grade", { length: 160 }),
  sourceId: int("sourceId").notNull().references(() => sources.id),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  collectionNumberUnique: uniqueIndex("hadith_collection_number_unique").on(table.collectionId, table.hadithNumber),
  collectionIndex: index("hadith_collection_idx").on(table.collectionId),
  enabledIndex: index("hadith_enabled_idx").on(table.enabled),
}));

export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  name: varchar("name", { length: 160 }).notNull(),
  kind: mysqlEnum("kind", ["hadith", "dhikr", "dua", "topic"]).notNull(),
});

export const hadithCategories = mysqlTable("hadith_categories", {
  hadithId: int("hadithId").notNull().references(() => hadiths.id),
  categoryId: int("categoryId").notNull().references(() => categories.id),
}, (table) => ({
  primary: primaryKey({ columns: [table.hadithId, table.categoryId] }),
}));

export const supplications = mysqlTable("supplications", {
  id: int("id").autoincrement().primaryKey(),
  kind: mysqlEnum("kind", ["dhikr", "dua"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  text: text("text").notNull(),
  categoryId: int("categoryId").references(() => categories.id),
  repetitions: int("repetitions"),
  sourceId: int("sourceId").notNull().references(() => sources.id),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({ kindIndex: index("supplications_kind_idx").on(table.kind), enabledIndex: index("supplications_enabled_idx").on(table.enabled) }));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Source = typeof sources.$inferSelect;
export type QuranSurah = typeof quranSurahs.$inferSelect;
export type QuranAyah = typeof quranAyahs.$inferSelect;
export type Hadith = typeof hadiths.$inferSelect;
