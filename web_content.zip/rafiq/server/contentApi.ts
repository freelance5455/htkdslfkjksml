import type { Express, Request, Response } from "express";
import mysql from "mysql2/promise";

let pool: mysql.Pool | null = null;
function getPool() {
  if (!pool && (process.env.DATABASE_URL || process.env.DRIZZLE_DATABASE_URL)) {
    pool = mysql.createPool(process.env.DATABASE_URL || process.env.DRIZZLE_DATABASE_URL!);
  }
  return pool;
}

const safeLimit = (value: unknown, fallback = 30) => Math.min(100, Math.max(1, Number(value) || fallback));
const searchPattern = (value: string) => `%${value.replace(/[\\%_]/g, "\\$&").trim()}%`;
const normalizeArabic = (value: string) => value.toLowerCase().replace(/[\u064B-\u065F\u0670]/g, "").replace(/[إأآٱا]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/ؤ/g, "و").replace(/ئ/g, "ي").replace(/لاه/g, "لوه").trim();
const normalizedSql = (column: string) => `REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REGEXP_REPLACE(${column}, '[ًٌٍَُِّْـٰ]', ''), 'إ', 'ا'), 'أ', 'ا'), 'آ', 'ا'), 'ٱ', 'ا'), 'ة', 'ه'), 'ى', 'ي'), 'لاه', 'لوه')`;
const sendDbUnavailable = (res: Response) => res.status(503).json({ error: "content_database_unavailable" });

export function registerContentApi(app: Express) {
  app.get("/api/content/sources", async (_req, res) => {
    const db = getPool();
    if (!db) return sendDbUnavailable(res);
    const [rows] = await db.query("SELECT id,slug,name,url,license,attribution,version FROM sources ORDER BY id");
    return res.json({ sources: rows });
  });

  app.get("/api/content/quran/surahs", async (_req, res) => {
    const db = getPool();
    if (!db) return sendDbUnavailable(res);
    const [rows] = await db.query("SELECT number,nameArabic,nameEnglish,revelationType,ayahCount FROM quran_surahs ORDER BY number");
    return res.json({ surahs: rows });
  });

  app.get("/api/content/quran/surahs/:number", async (req, res) => {
    const db = getPool();
    if (!db) return sendDbUnavailable(res);
    const number = Number(req.params.number);
    if (!Number.isInteger(number) || number < 1 || number > 114) return res.status(400).json({ error: "invalid_surah" });
    const [surahRows] = await db.query("SELECT id,number,nameArabic,nameEnglish,revelationType,ayahCount FROM quran_surahs WHERE number=? LIMIT 1", [number]);
    const surah = (surahRows as Array<Record<string, unknown>>)[0];
    if (!surah) return res.status(404).json({ error: "surah_not_found" });
    const [ayahs] = await db.query("SELECT ayahNumber,globalNumber,text FROM quran_ayahs WHERE surahId=? AND enabled=1 ORDER BY ayahNumber", [surah.id]);
    return res.json({ surah, ayahs });
  });

  app.get("/api/content/quran/search", async (req, res) => {
    const db = getPool();
    if (!db) return sendDbUnavailable(res);
    const query = String(req.query.q || "").trim();
    if (query.length < 2) return res.json({ results: [] });
    const pattern = searchPattern(normalizeArabic(query));
    const [rows] = await db.query(`SELECT a.ayahNumber,a.globalNumber,a.text,s.number AS surahNumber,s.nameArabic FROM quran_ayahs a JOIN quran_surahs s ON s.id=a.surahId WHERE a.enabled=1 AND (${normalizedSql("a.text")} LIKE ? OR ${normalizedSql("s.nameArabic")} LIKE ?) ORDER BY a.globalNumber LIMIT ?`, [pattern, pattern, safeLimit(req.query.limit, 50)]);
    return res.json({ results: rows });
  });

  app.get("/api/content/hadith", async (req, res) => {
    const db = getPool();
    if (!db) return sendDbUnavailable(res);
    const query = String(req.query.q || "").trim();
    const category = String(req.query.category || "").trim();
    const collection = String(req.query.collection || "").trim();
    const limit = safeLimit(req.query.limit, 30);
    const clauses = ["h.enabled=1"];
    const params: unknown[] = [];
    if (query.length >= 2) { const pattern = searchPattern(normalizeArabic(query)); clauses.push(`(${normalizedSql("h.text")} LIKE ? OR h.hadithNumber LIKE ? OR ${normalizedSql("hc.name")} LIKE ?)`); params.push(pattern, pattern, pattern); }
    if (category) { clauses.push("EXISTS (SELECT 1 FROM hadith_categories hx JOIN categories cx ON cx.id=hx.categoryId WHERE hx.hadithId=h.id AND (cx.slug=? OR cx.name LIKE ?))"); params.push(category, searchPattern(category)); }
    if (collection) { clauses.push("hc.slug=?"); params.push(collection); }
    params.push(limit);
    const [rows] = await db.query(`SELECT h.id,h.hadithNumber,h.text,h.narrator,h.grade,hc.slug AS collectionSlug,hc.name AS collectionName,GROUP_CONCAT(DISTINCT c.name ORDER BY c.name SEPARATOR ", ") AS categories FROM hadiths h JOIN hadith_collections hc ON hc.id=h.collectionId LEFT JOIN hadith_categories hcat ON hcat.hadithId=h.id LEFT JOIN categories c ON c.id=hcat.categoryId WHERE ${clauses.join(" AND ")} GROUP BY h.id,h.hadithNumber,h.text,h.narrator,h.grade,hc.slug,hc.name ORDER BY h.id LIMIT ?`, params);
    return res.json({ results: rows });
  });

  app.get("/api/content/search", async (req: Request, res: Response) => {
    const db = getPool();
    if (!db) return sendDbUnavailable(res);
    const query = String(req.query.q || "").trim();
    if (query.length < 2) return res.json({ quran: [], hadith: [], supplications: [] });
    const pattern = searchPattern(normalizeArabic(query));
    const limit = safeLimit(req.query.limit, 12);
    const [quran] = await db.query(`SELECT a.ayahNumber,a.globalNumber,a.text,s.number AS surahNumber,s.nameArabic FROM quran_ayahs a JOIN quran_surahs s ON s.id=a.surahId WHERE a.enabled=1 AND (${normalizedSql("a.text")} LIKE ? OR ${normalizedSql("s.nameArabic")} LIKE ?) ORDER BY a.globalNumber LIMIT ?`, [pattern, pattern, limit]);
    const [hadith] = await db.query(`SELECT h.id,h.hadithNumber,h.text,hc.name AS collectionName FROM hadiths h JOIN hadith_collections hc ON hc.id=h.collectionId WHERE h.enabled=1 AND ${normalizedSql("h.text")} LIKE ? ORDER BY h.id LIMIT ?`, [pattern, limit]);
    const [supplications] = await db.query("SELECT s.id,s.kind,s.title,s.text,c.name AS categoryName FROM supplications s LEFT JOIN categories c ON c.id=s.categoryId WHERE s.enabled=1 AND (s.text LIKE ? OR s.title LIKE ?) ORDER BY s.id LIMIT ?", [pattern, pattern, limit]);
    return res.json({ quran, hadith, supplications });
  });
}
