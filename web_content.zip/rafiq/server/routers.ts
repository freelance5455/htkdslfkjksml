import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { categories, hadiths, quranAyahs, sources, supplications } from "../drizzle/schema";
import { eq, sql } from "drizzle-orm";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  admin: router({
    overview: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return { sources: 0, categories: 0, ayahs: 0, hadiths: 0, supplications: 0 };
      const [sourceCount, categoryCount, ayahCount, hadithCount, supplicationCount] = await Promise.all([
        db.select({ count: sql<number>`count(*)` }).from(sources),
        db.select({ count: sql<number>`count(*)` }).from(categories),
        db.select({ count: sql<number>`count(*)` }).from(quranAyahs),
        db.select({ count: sql<number>`count(*)` }).from(hadiths),
        db.select({ count: sql<number>`count(*)` }).from(supplications),
      ]);
      return { sources: Number(sourceCount[0]?.count ?? 0), categories: Number(categoryCount[0]?.count ?? 0), ayahs: Number(ayahCount[0]?.count ?? 0), hadiths: Number(hadithCount[0]?.count ?? 0), supplications: Number(supplicationCount[0]?.count ?? 0) };
    }),
    sources: adminProcedure.query(async () => {
      const db = await getDb();
      return db ? db.select().from(sources).orderBy(sources.id) : [];
    }),
    createSource: adminProcedure.input(z.object({ slug: z.string().min(2).max(120), name: z.string().min(2), url: z.string().url(), license: z.string().min(2), attribution: z.string().min(2), version: z.string().max(120).optional() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database is not available");
      await db.insert(sources).values(input);
      return { success: true } as const;
    }),
    categories: adminProcedure.query(async () => {
      const db = await getDb();
      return db ? db.select().from(categories).orderBy(categories.kind, categories.name) : [];
    }),
    createCategory: adminProcedure.input(z.object({ slug: z.string().min(2).max(120), name: z.string().min(2), kind: z.enum(["hadith", "dhikr", "dua", "topic"]) })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database is not available");
      await db.insert(categories).values(input);
      return { success: true } as const;
    }),
    setHadithEnabled: adminProcedure.input(z.object({ id: z.number().int().positive(), enabled: z.boolean() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database is not available");
      await db.update(hadiths).set({ enabled: input.enabled }).where(eq(hadiths.id, input.id));
      return { success: true } as const;
    }),
    setQuranAyahEnabled: adminProcedure.input(z.object({ id: z.number().int().positive(), enabled: z.boolean() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database is not available");
      await db.update(quranAyahs).set({ enabled: input.enabled }).where(eq(quranAyahs.id, input.id));
      return { success: true } as const;
    }),
  }),
});

export type AppRouter = typeof appRouter;
