import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import mysql from "mysql2/promise";

const root = process.cwd();
const dataDir = path.join(root, "server/data");
const dbUrl = process.env.DATABASE_URL ?? process.env.DRIZZLE_DATABASE_URL;
if (!dbUrl) throw new Error("DATABASE_URL or DRIZZLE_DATABASE_URL is required");

const connection = await mysql.createConnection(dbUrl);
const q = (value: string) => value.replaceAll("\\", "\\\\").replaceAll("%", "\\%").replaceAll("_", "\\_");
const normalizeArabic = (value: string) => value.toLowerCase().replace(/[\u064B-\u065F\u0670]/g, "").replace(/[إأآا]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/ؤ/g, "و").replace(/ئ/g, "ي").trim();

async function sourceId(slug: string, values: { name: string; url: string; license: string; attribution: string; version: string }) {
  await connection.execute(
    "INSERT INTO `sources` (`slug`,`name`,`url`,`license`,`attribution`,`version`) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `name`=VALUES(`name`),`url`=VALUES(`url`),`license`=VALUES(`license`),`attribution`=VALUES(`attribution`),`version`=VALUES(`version`)",
    [slug, values.name, values.url, values.license, values.attribution, values.version],
  );
  const [rows] = await connection.execute("SELECT `id` FROM `sources` WHERE `slug`=? LIMIT 1", [slug]);
  return (rows as Array<{ id: number }>)[0].id;
}

async function insertBatch(sql: string, rows: unknown[][]) {
  for (let i = 0; i < rows.length; i += 200) {
    const batch = rows.slice(i, i + 200);
    await connection.query(sql, [batch]);
  }
}

const tanzilSource = await sourceId("tanzil-quran-uthmani", {
  name: "Tanzil Quran Text — Uthmani",
  url: "https://tanzil.net/",
  license: "Creative Commons Attribution 3.0 (verbatim; no modification)",
  attribution: "Tanzil Quran Text, Copyright (C) 2007–2026 Tanzil Project. The text is copied verbatim and must not be changed.",
  version: "Uthmani 1.1 export",
});
const hadithSource = await sourceId("open-hadith-data-six-books", {
  name: "Open-Hadith-Data — six books",
  url: "https://github.com/mhashim6/Open-Hadith-Data",
  license: "Open Database License (ODbL 1.0) + Database Contents License (DbCL 1.0)",
  attribution: "Open-Hadith-Data project; original data sources and collection names are preserved per repository documentation.",
  version: "repository snapshot used for this import",
});

const metadata = JSON.parse(fs.readFileSync(path.join(dataDir, "quran-surah-metadata.json"), "utf8")) as Array<{ number: number; name: string; englishName: string; numberOfAyahs: number; revelationType: string }>;
await insertBatch(
  "INSERT INTO `quran_surahs` (`number`,`nameArabic`,`nameEnglish`,`revelationType`,`ayahCount`,`sourceId`) VALUES ? ON DUPLICATE KEY UPDATE `nameArabic`=VALUES(`nameArabic`),`nameEnglish`=VALUES(`nameEnglish`),`revelationType`=VALUES(`revelationType`),`ayahCount`=VALUES(`ayahCount`),`sourceId`=VALUES(`sourceId`)",
  metadata.map((surah) => [surah.number, surah.name, surah.englishName, surah.revelationType, surah.numberOfAyahs, tanzilSource]),
);
const [surahRows] = await connection.execute("SELECT `id`,`number` FROM `quran_surahs`");
const surahIds = new Map((surahRows as Array<{ id: number; number: number }>).map((row) => [row.number, row.id]));
const quranRows: unknown[][] = [];
let globalNumber = 0;
for (const line of fs.readFileSync(path.join(dataDir, "quran-tanzil-uthmani.txt"), "utf8").split(/\r?\n/)) {
  if (!line || line.startsWith("#")) continue;
  const [surahNumber, ayahNumber, text] = line.split("|", 3);
  if (!surahNumber || !ayahNumber || !text) continue;
  globalNumber += 1;
  quranRows.push([surahIds.get(Number(surahNumber)), Number(ayahNumber), globalNumber, text, tanzilSource, true]);
}
await insertBatch(
  "INSERT INTO `quran_ayahs` (`surahId`,`ayahNumber`,`globalNumber`,`text`,`sourceId`,`enabled`) VALUES ? ON DUPLICATE KEY UPDATE `globalNumber`=VALUES(`globalNumber`),`text`=VALUES(`text`),`sourceId`=VALUES(`sourceId`),`enabled`=VALUES(`enabled`)",
  quranRows,
);

const categoryNames = ["الصلاة", "الصيام", "الزكاة", "الحج", "الأخلاق", "بر الوالدين", "الصدق", "التوبة", "الدعاء", "الذكر", "الصدقة", "الزواج والأسرة", "الرزق", "الصبر", "المرض", "الموت", "عام"];
const categoryIds = new Map<string, number>();
for (const name of categoryNames) {
  const slug = normalizeArabic(name).replaceAll(" ", "-");
  await connection.execute("INSERT INTO `categories` (`slug`,`name`,`kind`) VALUES (?,?,?) ON DUPLICATE KEY UPDATE `name`=VALUES(`name`),`kind`=VALUES(`kind`)", [slug, name, "hadith"]);
  const [rows] = await connection.execute("SELECT `id` FROM `categories` WHERE `slug`=? LIMIT 1", [slug]);
  categoryIds.set(name, (rows as Array<{ id: number }>)[0].id);
}

const collections = [
  ["sahih-al-bukhari", "صحيح البخاري", "sahih_al-bukhari_ahadith.utf8.csv", 1],
  ["sahih-muslim", "صحيح مسلم", "sahih_muslim_ahadith.utf8.csv", 2],
  ["sunan-abu-dawud", "سنن أبي داود", "sunan_abu-dawud_ahadith.utf8.csv", 3],
  ["sunan-al-nasai", "سنن النسائي", "sunan_al-nasai_ahadith.utf8.csv", 4],
  ["jami-al-tirmidhi", "جامع الترمذي", "sunan_al-tirmidhi_ahadith.utf8.csv", 5],
  ["sunan-ibn-maja", "سنن ابن ماجه", "sunan_ibn-maja_ahadith.utf8.csv", 6],
] as const;
const keywords: Array<[string, string[]]> = [
  ["الصلاة", ["صلاه", "صلاة", "الوضوء", "السجود", "المسجد"]], ["الصيام", ["صيام", "الصوم", "رمضان"]], ["الزكاة", ["زكاه", "الزكاة"]], ["الحج", ["الحج", "العمرة", "عرفه"]], ["الأخلاق", ["الخلق", "أخلاق", "الرحمه"]], ["بر الوالدين", ["والديه", "الوالدين", "امه", "ابيه"]], ["الصدق", ["صدق", "كذب"]], ["التوبة", ["توبه", "التوبة", "استغفر"]], ["الدعاء", ["دعاء", "ادعو", "سأل"]], ["الذكر", ["ذكر الله", "اذكر", "التسبيح"]], ["الصدقة", ["صدقه", "الصدقة", "المال"]], ["الزواج والأسرة", ["الزواج", "المرأة", "النساء", "الولد"]], ["الرزق", ["الرزق", "البيع", "التجارة"]], ["الصبر", ["الصبر", "صبرا"]], ["المرض", ["المريض", "المرض", "الشفاء"]], ["الموت", ["الموت", "الميت", "الجنازة"]],
];

function parseCsvLine(line: string) {
  const values: string[] = [];
  let value = "";
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (quoted && line[i + 1] === '"') { value += '"'; i += 1; }
      else quoted = !quoted;
    } else if (char === "," && !quoted) { values.push(value); value = ""; }
    else value += char;
  }
  values.push(value);
  return values;
}

for (const [slug, name, filename, sortOrder] of collections) {
  await connection.execute("INSERT INTO `hadith_collections` (`slug`,`name`,`sourceId`,`sortOrder`) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE `name`=VALUES(`name`),`sourceId`=VALUES(`sourceId`),`sortOrder`=VALUES(`sortOrder`)", [slug, name, hadithSource, sortOrder]);
  const [collectionRows] = await connection.execute("SELECT `id` FROM `hadith_collections` WHERE `slug`=? LIMIT 1", [slug]);
  const collectionId = (collectionRows as Array<{ id: number }>)[0].id;
  const rows = fs.readFileSync(path.join(dataDir, "hadith", filename), "utf8").split(/\r?\n/).filter(Boolean).map(parseCsvLine);
  const hadithBatch: unknown[][] = [];
  for (const [number, text] of rows) {
    if (!number || !text) continue;
    hadithBatch.push([collectionId, number, text.trim(), null, null, hadithSource, true]);
  }
  for (let i = 0; i < hadithBatch.length; i += 200) {
    const batch = hadithBatch.slice(i, i + 200);
    await connection.query("INSERT INTO `hadiths` (`collectionId`,`hadithNumber`,`text`,`narrator`,`grade`,`sourceId`,`enabled`) VALUES ? ON DUPLICATE KEY UPDATE `text`=VALUES(`text`),`sourceId`=VALUES(`sourceId`),`enabled`=VALUES(`enabled`)", [batch]);
  }
  const [inserted] = await connection.execute("SELECT `id`,`text` FROM `hadiths` WHERE `collectionId`=?", [collectionId]);
  await connection.execute("DELETE hcat FROM `hadith_categories` hcat JOIN `hadiths` h ON h.id=hcat.hadithId WHERE h.collectionId=?", [collectionId]);
  const categoryRows: unknown[][] = [];
  for (const hadith of inserted as Array<{ id: number; text: string }>) {
    const normalized = normalizeArabic(hadith.text);
    const matches = keywords.filter(([, terms]) => terms.some((term) => normalized.includes(normalizeArabic(term)))).map(([name]) => categoryIds.get(name)).filter((id): id is number => Boolean(id));
    const finalIds = matches.length ? matches : [categoryIds.get("عام")!];
    for (const categoryId of finalIds) categoryRows.push([hadith.id, categoryId]);
  }
  await insertBatch("INSERT IGNORE INTO `hadith_categories` (`hadithId`,`categoryId`) VALUES ?", categoryRows);
  console.log(`[seed] ${name}: ${hadithBatch.length} hadiths`);
}

await connection.end();
console.log(`[seed] Quran: ${quranRows.length} ayahs across ${metadata.length} surahs`);
