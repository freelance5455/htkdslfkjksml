# Raja International Travel KP Android App

Offline-first Android WebView app for ticket booking, PNR, ticket numbers, customer/mobile details, airline and route, buy/sale price, profit, received amount, balance due, search, add payment, share, CSV export and JSON backup/restore.

## Build APK using Android Studio
1. Install Android Studio on a computer and install Android SDK Platform 35 (or adjust compileSdk to an installed platform).
2. Extract this folder and choose **Open** in Android Studio, selecting the `KaleyaTravelAndroid` folder.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`. Transfer it to your Android phone and install it. If prompted, allow installing apps from that source.

This project source is supplied; an APK has not been compiled in this environment because Android SDK/Gradle are not installed here. Customer records are stored locally on the phone using WebView local storage. Use Backup JSON regularly; uninstalling or clearing app data can erase records. No airline live PNR verification is included.
