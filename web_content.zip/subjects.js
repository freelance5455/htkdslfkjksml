// বিষয় → পত্র → অধ্যায় → প্রশ্ন (আসল ভর্তি প্রশ্ন + অনুশীলনী)
(() => {
  const SUBJ = [
    { id: "phy", name: "পদার্থবিজ্ঞান", icon: "atom", color: "#1E4FD8", bg: "#DBEAFE", papers: ["phy1", "phy2"] },
    { id: "chem", name: "রসায়ন", icon: "flask-conical", color: "#DB2777", bg: "#FCE7F3", papers: ["chem1", "chem2"] },
    { id: "math", name: "উচ্চতর গণিত", icon: "sigma", color: "#7C3AED", bg: "#EDE9FE", papers: ["math1", "math2"] },
    { id: "bio", name: "জীববিজ্ঞান", icon: "leaf", color: "#16A34A", bg: "#DCFCE7", papers: ["bio1", "bio2"] }
  ];
  const PNAME = { phy1: "পদার্থবিজ্ঞান ১ম পত্র", phy2: "পদার্থবিজ্ঞান ২য় পত্র", chem1: "রসায়ন ১ম পত্র", chem2: "রসায়ন ২য় পত্র", math1: "উচ্চতর গণিত ১ম পত্র", math2: "উচ্চতর গণিত ২য় পত্র", bio1: "জীববিজ্ঞান ১ম পত্র (উদ্ভিদবিজ্ঞান)", bio2: "জীববিজ্ঞান ২য় পত্র (প্রাণিবিজ্ঞান)" };
  const BN = "০১২৩৪৫৬৭৮৯", bn = v => String(v).replace(/\d/g, d => BN[d]);
  const fromBn = s => String(s).replace(/[০-৯]/g, c => BN.indexOf(c));
  const normTag = t => { // "GST ২০২৩-২৪" → "GST'23-24"
    const m = fromBn(t).match(/^([A-Za-z]+)\s*'?\s*(?:20)?(\d{2})-(?:20)?(\d{2})/);
    return m ? `${m[1].toUpperCase()}'${m[2]}-${m[3]}` : t;
  };
  const PAPERS = {}, ALLQ = [];
  SUBJ.forEach(s => s.papers.forEach(pid => {
    const qb = (window.QB || {})[pid] || [], pyq = (window.PYQ || {})[pid] || [];
    const chapters = qb.map(([name, prac], ci) => {
      const src = `HSC ${PNAME[pid]} (NCTB পাঠ্যবই) — অধ্যায় ${bn(ci + 1)}: ${name}`;
      const qs = [];
      (pyq[ci] || []).forEach((r, k) => qs.push({ id: `${pid}-${ci}-p${k}`, q: r[0], o: r[1], a: r[2], t: r[3], img: r[4] || null, e: r[5] || "", src, kind: "pyq", pid, ci }));
      prac.forEach((r, k) => {
        const tg = r[4] ? [normTag(r[4])] : [];
        qs.push({ id: `${pid}-${ci}-x${k}`, q: r[0], o: r[1], a: r[2], t: tg, e: r[3] || "", src, kind: tg.length ? "pyq" : "prac", pid, ci });
      });
      qs.forEach(q => ALLQ.push(q));
      return { name, qs, pyq: qs.filter(q => q.kind === "pyq").length };
    });
    PAPERS[pid] = { id: pid, name: PNAME[pid], short: PNAME[pid].replace(/ \(.+\)/, ""), sub: s.id, chapters, total: chapters.reduce((a, c) => a + c.qs.length, 0) };
  }));
  SUBJ.forEach(s => s.total = s.papers.reduce((a, p) => a + PAPERS[p].total, 0));
  window.SUBJ = SUBJ; window.PAPERS = PAPERS; window.ALLQ = ALLQ;
})();
