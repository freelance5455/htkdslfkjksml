# V121 — VIEW VISITS TODAY

Added a dashboard button named **VIEW VISITS TODAY**. It opens a date-filtered activity list defaulting to the current date. The date can be changed to inspect earlier dates. Only active items with daily records that show visits, amounts given, cash pulls, Banked entries, MTN SENT entries, or recorded notes are listed. Each row shows the amounts and stored visit/change details for the selected date.

Implemented in the web and Android WebView app assets without a database schema change. The list uses the app’s existing `daily_progress` records, so it does not claim to show item-profile edits that the app does not currently audit by date.
