# Store listing copy (edit freely; check lengths in the consoles)

**App name:** Dagba Digital Academy  (≤30 chars)
**Subtitle (Apple, ≤30):** Learn skills that pay
**Short description (Google, ≤80):** Simplifying knowledge. Building excellence. Equipping for the real world.
**Promotional text (Apple, ≤170):** Learn school subjects, income skills and professional development on your phone, at your own pace, with certificates you can verify.
**Keywords (Apple, ≤100):** online courses,Nigeria,WAEC,JAMB,skills,certificate,learning,faith,tutorials,income

**Full description**
Dagba Digital Academy simplifies knowledge and equips you for the real world.

LEARN YOUR WAY
• Academic: Basic (secondary school level) and Advanced (university level) subjects
• Income Skills: practical courses you can turn into earnings
• Professional Development: build career-ready skills
• Faith & Spiritual Growth: lessons, readings and audio for your journey

BUILT FOR REAL LIFE
• Video and text lessons, quizzes and assignments
• Resume exactly where you stopped
• Saved content to keep reading when your network is weak
• Certificates you can share and anyone can verify
• Learning paths that guide you from start to finish
• Notifications for announcements, grades and updates

YOUR ACCOUNT, EVERYWHERE
Sign in with the same account you use on dagbadigitalacademy.com. Your courses and progress are always in sync.

Questions? Contact us from Profile > Support.

**Category:** Education    **Content rating:** answer questionnaires honestly (expected: everyone / 4+; user-generated discussions exist, so Apple's UGC rules apply: reporting/removal is provided by staff moderation)
**Support URL:** https://dagbadigitalacademy.com/contact     **Privacy policy URL:** https://dagbadigitalacademy.com/privacy-policy
**Terms:** https://dagbadigitalacademy.com/terms-and-conditions     **Account deletion URL (Google):** https://dagbadigitalacademy.com/delete-account
