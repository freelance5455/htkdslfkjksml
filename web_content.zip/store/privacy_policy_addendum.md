# Privacy policy: text to add on the website (Admin → Pages → Privacy Policy). Have a lawyer review it, especially for Nigerian data-protection law (NDPA 2023).

## The Dagba app
When you use our Android or iPhone app we collect the same account and learning information as on our website, plus: a device identifier used only to send you push notifications (delivered through Google's Firebase Cloud Messaging), your app version and device type (to keep the app working), and any photos or files you choose to attach to an assignment. We do not use advertising or cross-app tracking, and we do not collect your precise location or contacts.
Payments made in the app are processed by Apple or Google; we receive confirmation that you purchased an item, not your card details.
You can delete your account in the app (Profile → Delete account) or at https://dagbadigitalacademy.com/delete-account. Deletion removes your name, email, phone, profile, notifications and sign-in sessions. We keep payment, earnings and refund records for accounting and legal reasons, and certificates exactly as issued so that they remain verifiable.
