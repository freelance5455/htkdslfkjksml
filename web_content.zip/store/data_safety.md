# Data disclosures (fill the console forms from this; verify against your final build)

| Data | Collected | Why | Shared with third parties | Optional | Deletable |
|---|---|---|---|---|---|
| Name, email, phone (optional) | Yes | Account, support, certificates | No (processors: your hosting provider) | Phone optional | Yes (in-app deletion) |
| Password | Yes (stored hashed on the server) | Sign-in | No | No | Yes |
| Purchase history | Yes | Access control, receipts, accounting | Apple/Google process the payment | n/a | Kept for legal/accounting, unlinked from name/email on deletion |
| Learning activity (progress, quiz scores, submissions, discussion posts) | Yes | Core feature | No | No | Personal data removed with the account |
| Photos/files the user chooses to attach to assignments | Only when the user picks them | Assignment submission | No | Yes | Via support |
| Device push token, platform, app version | Yes | Notifications, compatibility | Firebase Cloud Messaging (Google) delivers pushes | Push permission optional | Removed on sign-out/deletion |
| Approximate location / contacts / advertising ID | **No** | | | | |
| Analytics/crash SDKs | **None included** (add them to this table if you add any) | | | | |
Data in transit: HTTPS only. Tokens stored in iOS Keychain / Android Keystore. Account deletion: in app (Profile → Delete account) and at the public URL above.
Apple "App Privacy" labels: Contact Info (name, email, phone), Identifiers (user ID), Purchases, User Content (submissions/posts), Usage Data (learning progress); all "linked to the user", **not** used for tracking. No ATT prompt is needed because nothing tracks across apps.
Children: the service is for general audiences. If you target under-13s, Google's Families policy and COPPA/NDPR obligations apply; get legal advice before declaring a child audience.
