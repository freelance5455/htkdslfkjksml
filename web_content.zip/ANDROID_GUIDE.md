# APK
1. WebIntoApp.com — upload project folder/ZIP, icon icon-512.png, Build APK
2. Or Netlify Drop + PWABuilder Android

Support: 01002577489 · 01207951221
