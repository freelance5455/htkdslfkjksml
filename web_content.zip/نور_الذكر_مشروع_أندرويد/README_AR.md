# مشروع تطبيق نور الذكر — Android APK

هذا المشروع يضم صفحة HTML التي أُرسلت في المحادثة، مُهيأة كبداية لتطبيق Android باستخدام Capacitor.

## المتطلبات
- كمبيوتر بنظام Windows أو macOS أو Linux
- Node.js (إصدار LTS)
- Android Studio مع Android SDK

## بناء APK

افتح الطرفية داخل مجلد المشروع ثم نفّذ:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

في Android Studio:
1. انتظر اكتمال مزامنة Gradle.
2. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. بعد انتهاء البناء، اضغط **locate** للوصول إلى ملف APK الناتج.

## ملاحظات مهمة
- `www/index.html` هو ملف HTML الذي تم رفعه. هذا ليس ZIP كاملًا من منصة التصميم ولا يحتوي بالضرورة على ملفات المصدر الأصلية.
- الصفحة تستخدم بعض الموارد الخارجية (مثل Tailwind CDN والخطوط وأيقونات Font Awesome)، لذلك قد تحتاج اتصال إنترنت لظهور هذه الموارد بالشكل الكامل.
- لم يتم إنشاء APK داخل هذه الحزمة؛ يلزم تنفيذ خطوات البناء أعلاه في بيئة Android مجهزة.
- إذا كان لديك مجلد المشروع الأصلي من Lovable/Bolt، فهو أفضل من ملف HTML المفرد للحفاظ على جميع الملفات والوظائف.
