BRIXNN.7 - Proyecto Android

Este proyecto contiene la página HTML dentro de una app Android (WebView).

CÓMO GENERAR EL APK:
1. Descarga e instala Android Studio desde https://developer.android.com/studio
2. Descomprime la carpeta BRIXNN7-Android.
3. En Android Studio, selecciona Open y abre la carpeta BRIXNN7-Android.
4. Espera a que Gradle termine la sincronización. Si solicita instalar Android SDK 35, acepta.
5. En el menú, selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Al terminar, Android Studio mostrará un enlace para localizar el APK.
7. Pasa el APK a tu celular e instálalo. Android puede pedir permiso para instalar apps de esa fuente.

Nombre de app: BRIXNN.7
Paquete: com.brixnn7.app
Versión: 1.0

NOTA: Este ZIP es el proyecto fuente, no un APK ya compilado. Necesitas Android Studio para compilarlo. Las sensibilidades son valores de prueba y no modifican automáticamente los ajustes del teléfono ni el juego.
