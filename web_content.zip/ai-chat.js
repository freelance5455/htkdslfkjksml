
import { auth, db } from "./firebase.js";
import { createAHMADAiChat } from "./ai.js";

import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/13.2.0/firebase-auth.js";

import {
  collection,
  doc,
  getDocs,
  addDoc,
  setDoc,
  deleteDoc,
  updateDoc, 
  query,
  orderBy,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js";

const chatForm = document.getElementById("aiChatForm");
const promptInput = document.getElementById("aiPrompt");
const messagesBox = document.getElementById("aiMessages");
const sendButton = document.getElementById("aiSendBtn");

const newChatButton = document.getElementById("newAIChat");
const conversationList = document.getElementById("aiConversationList");

let currentUser = null;
let currentConversationId = null;
let currentChat = createAHMADAiChat();
let isSending = false;

// مسار محادثات المستخدم
function conversationsRef() {
  return collection(
    db,
    "users",
    currentUser.uid,
    "conversations"
  );
}

// مسار رسائل محادثة معينة
function messagesRef(conversationId) {
  return collection(
    db,
    "users",
    currentUser.uid,
    "conversations",
    conversationId,
    "messages"
  );
}

let currentUtterance = null;
let currentSpeechButton = null;

function stopAISpeech() {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }

  if (currentSpeechButton) {
    currentSpeechButton.textContent = "🔊 استمع";
    currentSpeechButton.classList.remove("speaking");
  }

  currentUtterance = null;
  currentSpeechButton = null;
}

function speakAIMessage(text, button) {
  if (!("speechSynthesis" in window)) {
    alert("متصفحك لا يدعم القراءة الصوتية.");
    return;
  }

  if (currentSpeechButton === button) {
    stopAISpeech();
    return;
  }

  stopAISpeech();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "ar-SA";
  utterance.rate = 1;
  utterance.pitch = 1;

  currentUtterance = utterance;
  currentSpeechButton = button;

  button.textContent = "⏹ إيقاف";
  button.classList.add("speaking");

  utterance.onend = () => {
    if (currentUtterance === utterance) {
      stopAISpeech();
    }
  };

  utterance.onerror = () => {
    if (currentUtterance === utterance) {
      stopAISpeech();
    }
  };

  window.speechSynthesis.speak(utterance);
}

function addMessage(text, type) {
  const welcome = messagesBox.querySelector(".ai-welcome");
  if (welcome) welcome.remove();

  const message = document.createElement("div");
  message.className = "ai-message " + type;

  const messageText = document.createElement("span");
  messageText.textContent = text;

  message.appendChild(messageText);

  if (type === "bot" && text !== "أفكر في إجابتك...") {
    const speakButton = document.createElement("button");

    speakButton.type = "button";
    speakButton.className = "ai-speak-btn";
    speakButton.textContent = "🔊 استمع";

    speakButton.addEventListener("click", () => {
      speakAIMessage(text, speakButton);
    });

    message.appendChild(speakButton);
  }

  messagesBox.appendChild(message);
  messagesBox.scrollTop = messagesBox.scrollHeight;

  return message;
}


// مسح الرسائل من الواجهة
function clearMessages() {
  messagesBox.replaceChildren();
}

// تحميل قائمة المحادثات
async function loadConversationList() {
  if (!currentUser) return;

  conversationList.textContent = "جارٍ تحميل المحادثات...";

  try {
    const snapshot = await getDocs(conversationsRef());

    const conversations = snapshot.docs.map(item => ({
      id: item.id,
      ...item.data()
    }));

    conversations.sort((a, b) => {
      const timeA = a.updatedAt?.toMillis?.() || 0;
      const timeB = b.updatedAt?.toMillis?.() || 0;
      return timeB - timeA;
    });

    conversationList.replaceChildren();

    if (conversations.length === 0) {
      conversationList.textContent = "لا توجد محادثات سابقة";
      return;
    }

    conversations.forEach(conversation => {
      const row = document.createElement("div");
      row.className = "ai-conversation-row";

      // زر فتح المحادثة
      const openButton = document.createElement("button");
      openButton.className = "ai-conversation-item";

      if (conversation.id === currentConversationId) {
        openButton.classList.add("active");
      }

      openButton.textContent =
        conversation.title || "محادثة جديدة";

      openButton.addEventListener("click", () => {
        openConversation(conversation.id);
      });

      // زر إعادة التسمية
      const renameButton = document.createElement("button");
      renameButton.className = "ai-rename-conversation";
      renameButton.textContent = "تسمية";
      renameButton.title = "إعادة تسمية المحادثة";

      renameButton.addEventListener("click", () => {
        renameConversation(
          conversation.id,
          conversation.title || ""
        );
      });

      // زر حذف المحادثة
      const deleteButton = document.createElement("button");
      deleteButton.className = "ai-delete-conversation";
      deleteButton.textContent = "حذف";
      deleteButton.title = "حذف المحادثة";

      deleteButton.addEventListener("click", () => {
        deleteConversation(conversation.id);
      });

      row.append(openButton, renameButton, deleteButton);
      conversationList.appendChild(row);
    });

  } catch (error) {
    console.error("Conversation List Error:", error);
    conversationList.textContent = "تعذر تحميل المحادثات";
  }
}

// حذف المحادثة
async function deleteConversation(conversationId) {
  if (!currentUser || isSending) return;

  const confirmed = confirm(
    "هل أنت متأكد من حذف هذه المحادثة وجميع رسائلها؟ لا يمكن التراجع عن الحذف."
  );

  if (!confirmed) return;

  try {
    const messages = await getDocs(
      messagesRef(conversationId)
    );

    // حذف جميع الرسائل
    for (const message of messages.docs) {
      await deleteDoc(message.ref);
    }

    // حذف المحادثة نفسها
    await deleteDoc(
      doc(conversationsRef(), conversationId)
    );

    // إذا كانت المحادثة المفتوحة هي المحذوفة
    if (currentConversationId === conversationId) {
      newConversation();
    } else {
      await loadConversationList();
    }

  } catch (error) {
    console.error("Delete Conversation Error:", error);
    alert("تعذر حذف المحادثة: " + error.message);
  }
}


async function renameConversation(conversationId, oldTitle) {
  if (!currentUser || isSending) return;

  // إنشاء نافذة التسمية
  const overlay = document.createElement("div");
  overlay.className = "rename-overlay";

  const box = document.createElement("div");
  box.className = "rename-box";

  const title = document.createElement("h3");
  title.textContent = "إعادة تسمية المحادثة";

  const input = document.createElement("input");
  input.type = "text";
  input.value = oldTitle;
  input.maxLength = 60;
  input.placeholder = "اكتب الاسم الجديد";

  const actions = document.createElement("div");
  actions.className = "rename-actions";

  const cancel = document.createElement("button");
  cancel.textContent = "إلغاء";
  cancel.type = "button";

  const save = document.createElement("button");
  save.textContent = "حفظ";
  save.type = "button";

  actions.append(cancel, save);
  box.append(title, input, actions);
  overlay.appendChild(box);
  document.body.appendChild(overlay);

  input.focus();
  input.select();

  cancel.onclick = () => overlay.remove();

  overlay.addEventListener("click", event => {
    if (event.target === overlay) {
      overlay.remove();
    }
  });

  save.onclick = async () => {
    const newTitle = input.value.trim();

    if (!newTitle) {
      alert("اكتب اسم المحادثة أولاً.");
      return;
    }

    save.disabled = true;
    save.textContent = "جارٍ الحفظ...";

    try {
      await updateDoc(
        doc(conversationsRef(), conversationId),
        { title: newTitle }
      );

      overlay.remove();
      await loadConversationList();

    } catch (error) {
      console.error("Rename Error:", error);
      alert("تعذرت إعادة التسمية: " + error.message);

      save.disabled = false;
      save.textContent = "حفظ";
    }
  };
}



// فتح محادثة قديمة
async function openConversation(conversationId) {
  if (!currentUser || isSending) return;

  try {
    clearMessages();
    addMessage("جارٍ فتح المحادثة...", "bot");

    const q = query(
      messagesRef(conversationId),
      orderBy("createdAt", "asc")
    );

    const snapshot = await getDocs(q);

    const history = [];
    const savedMessages = [];

    snapshot.forEach(item => {
      const data = item.data();

      if (!data.text || !["user", "model"].includes(data.role)) {
        return;
      }

      savedMessages.push(data);

      history.push({
        role: data.role,
        parts: [{ text: data.text }]
      });
    });

    currentConversationId = conversationId;
    currentChat = createAHMADAiChat(history);

    clearMessages();

    savedMessages.forEach(message => {
      addMessage(
        message.text,
        message.role === "user" ? "user" : "bot"
      );
    });

    if (savedMessages.length === 0) {
      addMessage("هذه المحادثة فارغة.", "bot");
    }

    await loadConversationList();

  } catch (error) {
    console.error("Open Conversation Error:", error);
    clearMessages();
    addMessage("تعذر فتح المحادثة. حاول مجدداً.", "error");
  }
}

// إنشاء محادثة جديدة
function newConversation() {
  if (isSending) return;

  currentConversationId = null;
  currentChat = createAHMADAiChat();

  clearMessages();

  const welcome = document.createElement("div");
  welcome.className = "ai-welcome";

  const heading = document.createElement("h3");
  heading.textContent = "مرحباً بك في المساعد الذكي";

  const paragraph = document.createElement("p");
  paragraph.textContent = "ابدأ محادثة جديدة واسألني ما تريد.";

  welcome.append(heading, paragraph);
  messagesBox.appendChild(welcome);

  loadConversationList();
}

// إرسال السؤال وحفظه
chatForm.addEventListener("submit", async event => {
  event.preventDefault();

  if (isSending) return;

  if (!currentUser) {
    addMessage("يرجى تسجيل الدخول أولاً.", "error");
    return;
  }

  const prompt = promptInput.value.trim();
  if (!prompt) return;

  isSending = true;

  addMessage(prompt, "user");

  promptInput.value = "";
  sendButton.disabled = true;
  sendButton.textContent = "جارٍ التفكير...";

  const loading = addMessage("أفكر في إجابتك...", "bot");

  try {
    // إنشاء محادثة في أول سؤال
    if (!currentConversationId) {
      const conversation = doc(conversationsRef());

      currentConversationId = conversation.id;

      await setDoc(conversation, {
        title: prompt.slice(0, 60),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }

    // إرسال السؤال إلى Gemini
    const answer = await currentChat.send(prompt);

    // حفظ السؤال والجواب في Firebase
    const messages = messagesRef(currentConversationId);

    await addDoc(messages, {
      role: "user",
      text: prompt,
      createdAt: serverTimestamp()
    });

    await addDoc(messages, {
      role: "model",
      text: answer,
      createdAt: serverTimestamp()
    });

    loading.remove();

    addMessage(
      answer || "لم يصلني رد من المساعد.",
      "bot"
    );

    await setDoc(
      doc(conversationsRef(), currentConversationId),
      { updatedAt: serverTimestamp() },
      { merge: true }
    );

    await loadConversationList();

  } catch (error) {
    console.error("AHMAD AI Error:", error);

    loading.remove();

    addMessage(
      "حدث خطأ: " + (error.message || error),
      "error"
    );

  } finally {
    isSending = false;
    sendButton.disabled = false;
    sendButton.textContent = "إرسال";
    promptInput.focus();
  }
});

// زر محادثة جديدة
newChatButton.addEventListener("click", newConversation);

// متابعة حالة تسجيل الدخول
onAuthStateChanged(auth, user => {
  currentUser = user;

  if (user) {
    loadConversationList();
  } else {
    currentConversationId = null;
    clearMessages();
    addMessage("يرجى تسجيل الدخول لاستخدام المحادثات.", "error");
    conversationList.textContent = "سجّل الدخول لعرض محادثاتك";
  }
});
