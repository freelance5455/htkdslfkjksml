package com.suryakant.suryaphoto;

/*
 * सूर्या फोटो (Surya Photo)
 * Developer: SURYAKANT BHARTI
 *
 * यह ऐप assets/index.html को WebView में चलाता है और उसे ये सुविधाएँ देता है:
 *  - फोटो चुनना (गैलरी / कैमरा)
 *  - गैलरी में सेव करना (Pictures/SuryaPhoto) और PDF को Downloads/SuryaPhoto में
 *  - सीधे प्रिंट करना
 *  - Google ML Kit से AI बैकग्राउंड हटाना
 */

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.print.PrintHelper;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 101;
    private static final int REQ_STORAGE = 102;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                return openPicker();
            }
        });
        web.addJavascriptInterface(new Bridge(), "SuryaAndroid");
        web.loadUrl("file:///android_asset/index.html");
    }

    private boolean openPicker() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        Intent chooser = Intent.createChooser(pick, "फोटो चुनें");
        cameraUri = null;
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists()) dir.mkdirs();
            File img = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", img);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        } catch (Exception e) {
            cameraUri = null;
        }
        try {
            startActivityForResult(chooser, REQ_FILE);
            return true;
        } catch (Exception e) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = null;
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            } else if (cameraUri != null) {
                result = new Uri[]{cameraUri};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.suryaBack ? window.suryaBack() : 'exit'", value -> {
            if (value == null || value.contains("exit")) finish();
        });
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
    }

    private void sendJs(final String js) {
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private void saveBytes(byte[] bytes, String name, String mime) throws IOException {
        boolean isImage = mime != null && mime.startsWith("image/");
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    (isImage ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/SuryaPhoto");
            Uri collection = isImage ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            Uri uri = getContentResolver().insert(collection, v);
            if (uri == null) throw new IOException("insert failed");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new IOException("no stream");
                os.write(bytes);
            }
        } else {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE));
                throw new IOException("permission");
            }
            File base = Environment.getExternalStoragePublicDirectory(isImage ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS);
            File dir = new File(base, "SuryaPhoto");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, name);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(bytes);
            }
            MediaScannerConnection.scanFile(this, new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
        }
    }

    /** JavaScript से बुलाए जाने वाले फ़ंक्शन: window.SuryaAndroid.* */
    private class Bridge {

        @JavascriptInterface
        public boolean isApp() {
            return true;
        }

        @JavascriptInterface
        public void saveFile(String base64, String name, String mime) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                saveBytes(bytes, name, mime);
                boolean isImage = mime != null && mime.startsWith("image/");
                toast(isImage ? "गैलरी में सेव हो गई ✓ (Pictures/SuryaPhoto)" : "सेव हो गई ✓ (Download/SuryaPhoto)");
            } catch (IOException e) {
                if ("permission".equals(e.getMessage())) toast("अनुमति दें और फिर से सेव दबाएँ");
                else toast("सेव नहीं हो पाई");
            } catch (Exception e) {
                toast("सेव नहीं हो पाई");
            }
        }

        @JavascriptInterface
        public void printImage(String base64, String jobName, double paperWmm, double paperHmm) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                final Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                runOnUiThread(() -> {
                    try {
                        PrintHelper helper = new PrintHelper(MainActivity.this);
                        helper.setScaleMode(PrintHelper.SCALE_MODE_FIT);
                        helper.setOrientation(paperWmm > paperHmm ? PrintHelper.ORIENTATION_LANDSCAPE : PrintHelper.ORIENTATION_PORTRAIT);
                        helper.printBitmap(jobName, bmp);
                    } catch (Exception e) {
                        toast("प्रिंट नहीं हो पाया");
                    }
                });
            } catch (Exception e) {
                toast("प्रिंट नहीं हो पाया");
            }
        }

        @JavascriptInterface
        public void removeBg(String base64) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                SelfieSegmenterOptions options = new SelfieSegmenterOptions.Builder()
                        .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                        .build();
                final Segmenter segmenter = Segmentation.getClient(options);
                segmenter.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener((SegmentationMask mask) -> {
                            try {
                                int w = mask.getWidth(), h = mask.getHeight();
                                ByteBuffer buf = mask.getBuffer();
                                buf.rewind();
                                int[] px = new int[w * h];
                                for (int i = 0; i < w * h; i++) {
                                    float c = buf.getFloat();
                                    int g = Math.max(0, Math.min(255, Math.round(c * 255f)));
                                    px[i] = Color.argb(255, g, g, g);
                                }
                                Bitmap mb = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
                                ByteArrayOutputStream os = new ByteArrayOutputStream();
                                mb.compress(Bitmap.CompressFormat.PNG, 100, os);
                                String out = Base64.encodeToString(os.toByteArray(), Base64.NO_WRAP);
                                sendJs("window.suryaMaskDone && window.suryaMaskDone('data:image/png;base64," + out + "')");
                            } catch (Exception e) {
                                sendJs("window.suryaMaskDone && window.suryaMaskDone('')");
                            }
                            segmenter.close();
                        })
                        .addOnFailureListener(e -> {
                            sendJs("window.suryaMaskDone && window.suryaMaskDone('')");
                            segmenter.close();
                        });
            } catch (Exception e) {
                sendJs("window.suryaMaskDone && window.suryaMaskDone('')");
            }
        }
    }
}
