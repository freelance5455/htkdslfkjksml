# A P Radiology & Diagnostic Centre — Professional Mobile-First Website

Static website redesign for A P Radiology & Diagnostic Centre, Madhepura, Bihar.

## Included
- Mobile-first responsive design
- Home / Services / Technology / About / Appointment / Contact
- 64-slice CT feature section
- CT, ultrasound/Doppler, digital X-ray, OPG/CBCT, obstetric imaging cards
- Mobile bottom Call / Book / WhatsApp bar
- Appointment enquiry form
- Works as a normal website and can be loaded inside an Android WebView app

## Before publishing
Replace `+91XXXXXXXXXX` in `index.html` and `assets/app.js` with the centre's verified phone/WhatsApp number. Add the exact centre address, hours, Google Maps URL, email and real logo/photos.

## Hosting
Upload `index.html` and the `assets` folder to the website root on your hosting. Keep the relative paths unchanged.

## Android app
The same live URL can be used by the Android app project so website updates appear inside the app without rebuilding the app, provided the app is configured as a WebView/site wrapper.
