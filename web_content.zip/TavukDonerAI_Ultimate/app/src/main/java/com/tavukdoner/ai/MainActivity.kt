package com.tavukdoner.ai

import android.Manifest
import android.app.Activity
import android.app.AlarmClock
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("tdai", MODE_PRIVATE) }
    private external fun nativeLoadModel(path: String, contextSize: Int): Boolean
    private external fun nativeGenerate(prompt: String): String
    private external fun nativeRelease()
    companion object { init { System.loadLibrary("tavukllama") } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Native")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun chooseModel() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                }
                startActivityForResult(i, 51)
            }
        }
        @JavascriptInterface fun chatLocal(prompt: String) {
            worker.execute {
                val answer = try {
                    val model = File(filesDir, "model.gguf")
                    if (!model.exists()) "Önce Ayarlar bölümünden GGUF model dosyasını seç."
                    else nativeGenerate(prompt)
                } catch (e: Exception) { "Yerel model hatası: ${e.message}" }
                runOnUiThread { web.evaluateJavascript("window.receiveAI(${JSONObject.quote(answer)})", null) }
            }
        }
        @JavascriptInterface fun chatOnline(prompt: String) {
            worker.execute {
                val endpoint = prefs.getString("endpoint", "") ?: ""
                val key = prefs.getString("key", "") ?: ""
                val model = prefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini"
                val answer = try {
                    require(endpoint.startsWith("https://")) { "Güvenlik için HTTPS API adresi gerekli." }
                    require(key.isNotBlank()) { "API anahtarı ayarlanmamış." }
                    val c = URL(endpoint).openConnection() as HttpURLConnection
                    c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 90000
                    c.setRequestProperty("Content-Type", "application/json")
                    c.setRequestProperty("Authorization", "Bearer $key")
                    c.doOutput = true
                    val body = JSONObject().put("model", model)
                        .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", "Türkçe cevap veren, dürüst ve güvenli bir kişisel asistansın."))
                            .put(JSONObject().put("role", "user").put("content", prompt)))
                        .toString()
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
                    val raw = stream.bufferedReader().use { it.readText() }; c.disconnect()
                    JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)
                        ?.optJSONObject("message")?.optString("content") ?: "API cevabı okunamadı: $raw"
                } catch (e: Exception) { "Çevrim içi bağlantı hatası: ${e.message}" }
                runOnUiThread { web.evaluateJavascript("window.receiveAI(${JSONObject.quote(answer)})", null) }
            }
        }
        @JavascriptInterface fun saveOnline(endpoint: String, key: String, model: String) {
            prefs.edit().putString("endpoint", endpoint.trim()).putString("key", key.trim())
                .putString("model", model.trim()).apply()
        }
        @JavascriptInterface fun runAction(action: String, value: String) {
            runOnUiThread {
                try {
                    when (action) {
                        "torch" -> {
                            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.CAMERA), 41)
                                throw Exception("Kamera izni istendi; izin verdikten sonra tekrar dene.")
                            }
                            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
                            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                                ?: throw Exception("Flaş bulunamadı.")
                            cm.setTorchMode(id, value == "on")
                        }
                        "volume" -> {
                            val am = getSystemService(AUDIO_SERVICE) as AudioManager
                            val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, (if (value == "up") cur + 1 else cur - 1).coerceIn(0,max), 0)
                        }
                        "wifi" -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                        "bluetooth" -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                        "settings" -> startActivity(Intent(Settings.ACTION_SETTINGS))
                        "alarm" -> startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, (value.toIntOrNull() ?: 5).coerceIn(1,1440)*60).putExtra(AlarmClock.EXTRA_SKIP_UI, false))
                    }
                    web.evaluateJavascript("window.actionResult('İşlem tamamlandı veya ilgili Android ekranı açıldı.')", null)
                } catch (e: Exception) {
                    web.evaluateJavascript("window.actionResult(${JSONObject.quote(e.message ?: "İşlem yapılamadı")})", null)
                }
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 51 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            worker.execute {
                try {
                    contentResolver.openInputStream(uri).use { input ->
                        requireNotNull(input)
                        File(filesDir, "model.gguf").outputStream().use { output -> input.copyTo(output) }
                    }
                    val ok = nativeLoadModel(File(filesDir, "model.gguf").absolutePath, 2048)
                    runOnUiThread { web.evaluateJavascript("window.modelResult(${JSONObject.quote(if(ok) "Model yüklendi. Çevrim dışı sohbet hazır." else "Model yüklenemedi. GGUF dosyasını kontrol et.")})", null) }
                } catch (e: Exception) {
                    runOnUiThread { web.evaluateJavascript("window.modelResult(${JSONObject.quote("Model kopyalanamadı: ${e.message}")})", null) }
                }
            }
        }
    }
    override fun onDestroy() {
        worker.shutdown()
        try { nativeRelease() } catch (_: Exception) {}
        web.removeJavascriptInterface("Native"); web.destroy()
        super.onDestroy()
    }
}
