#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <android/log.h>
#include "llama.h"

static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;
static std::mutex g_mutex;

static std::string jstringToString(JNIEnv* env, jstring s) {
    const char* p = env->GetStringUTFChars(s, nullptr);
    std::string out = p ? p : "";
    if (p) env->ReleaseStringUTFChars(s, p);
    return out;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_tavukdoner_ai_MainActivity_nativeLoadModel(JNIEnv* env, jobject, jstring path, jint contextSize) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0; // Geniş uyumluluk: CPU modu
    std::string p = jstringToString(env, path);
    g_model = llama_model_load_from_file(p.c_str(), mp);
    if (!g_model) return JNI_FALSE;
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) contextSize;
    cp.n_batch = 256;
    cp.n_threads = 4;
    cp.n_threads_batch = 4;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { llama_model_free(g_model); g_model = nullptr; return JNI_FALSE; }
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_tavukdoner_ai_MainActivity_nativeGenerate(JNIEnv* env, jobject, jstring userText) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model || !g_ctx) return env->NewStringUTF("Önce bir GGUF model dosyası yüklemelisin.");
    const llama_vocab* vocab = llama_model_get_vocab(g_model);
    std::string user = jstringToString(env, userText);
    std::string prompt =
        "<|im_start|>system\nSen Tavuk Döner AI'sın. Türkçe, doğru, güvenli ve anlaşılır cevap ver. "
        "Bilmediğin şeyi uydurma. Android işlemi yapman istenirse yalnızca izinli araç öner; kendiliğinden işlem yaptığını iddia etme.<|im_end|>\n"
        "<|im_start|>user\n" + user + "<|im_end|>\n<|im_start|>assistant\n";
    std::vector<llama_token> tokens(prompt.size() + 128);
    int n = llama_tokenize(vocab, prompt.c_str(), (int)prompt.size(), tokens.data(),
                           (int)tokens.size(), true, true);
    if (n < 0) {
        tokens.resize((size_t)(-n));
        n = llama_tokenize(vocab, prompt.c_str(), (int)prompt.size(), tokens.data(),
                           (int)tokens.size(), true, true);
    }
    if (n <= 0) return env->NewStringUTF("İstek modele aktarılamadı.");
    tokens.resize(n);
    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_batch batch = llama_batch_init((int)tokens.size(), 0, 1);
    for (int i = 0; i < n; ++i) {
        batch.token[i] = tokens[i];
        batch.pos[i] = i;
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0;
        batch.logits[i] = (i == n - 1);
    }
    batch.n_tokens = n;
    if (llama_decode(g_ctx, batch) != 0) {
        llama_batch_free(batch);
        return env->NewStringUTF("Model ilk metni işlerken hata oluştu.");
    }
    llama_sampler* sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(1234));
    std::string output;
    const llama_token eos = llama_vocab_eos(vocab);
    const int maxNew = 450;
    for (int i = 0; i < maxNew; ++i) {
        llama_token tok = llama_sampler_sample(sampler, g_ctx, -1);
        if (tok == eos || llama_vocab_is_eog(vocab, tok)) break;
        char piece[512];
        int len = llama_token_to_piece(vocab, tok, piece, sizeof(piece), 0, true);
        if (len > 0) output.append(piece, len);
        batch.n_tokens = 1;
        batch.token[0] = tok;
        batch.pos[0] = n + i;
        batch.n_seq_id[0] = 1;
        batch.seq_id[0][0] = 0;
        batch.logits[0] = true;
        if (llama_decode(g_ctx, batch) != 0) break;
    }
    llama_sampler_free(sampler);
    llama_batch_free(batch);
    return env->NewStringUTF(output.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_tavukdoner_ai_MainActivity_nativeRelease(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    llama_backend_free();
}
