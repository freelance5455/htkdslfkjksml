# Tavuk Döner AI Ultimate — Pova 4 hedefli Android projesi

## Önemli: ZIP APK değildir
Bu dosya Android kaynak projesidir. Uzantısını `.apk` yapmak APK oluşturmaz. GitHub Actions, Android SDK/NDK ve CMake ile gerçek APK derlemeye çalışır.

## Telefonda APK oluşturma
1. ZIP'i indirip telefonda bir klasöre çıkart.
2. github.com üzerinden yeni bir repository aç.
3. ZIP içindeki dosyaları klasör yapısını koruyarak repository'ye yükle.
4. Repository > Actions > "Build Tavuk Doner AI APK" > Run workflow.
5. İşlem başarılı olunca Actions çalışmasının altındaki Artifacts bölümünden `TavukDonerAI-Ultimate-debug-apk` dosyasını indir.
6. İndirilen artifact ZIP'ini çıkart; `app-debug.apk` dosyasını kur.
7. GitHub Actions ilk derlemede llama.cpp kaynak kodunu ve Android derleme bileşenlerini internetten alır. Derleme uzun sürebilir.

## Yerel Qwen modeli
APK'nın içine model gömülü değildir; APK boyutu çok büyümesin diye model ayrı indirilir.
Öneri: Qwen2.5-1.5B-Instruct GGUF Q4_K_M (yaklaşık 1 GB).
Model sayfası: https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF
Model dosyası telefona indikten sonra uygulamada Ayarlar > GGUF dosyası seç bölümünden seçilir. Uygulama model dosyasını kendi özel alanına kopyalar. İlk yükleme zaman alabilir.
Başlangıç bağlamı 2048 token ve CPU modu olarak ayarlanmıştır. Pova 4'te gerçek hız; RAM boşluğu, sıcaklık, Android sürümü ve derleme optimizasyonuna bağlıdır. 1.5B model büyük çevrim içi modeller kadar güçlü değildir.

## Çevrim içi model
Ayarlar'a OpenAI uyumlu HTTPS `/v1/chat/completions` uç noktası, API anahtarı ve sağlayıcının model adını gir. Mesaj gönderirken her seferinde açık onay çıkar. API kullanımı ücretli olabilir; sağlayıcı gizlilik ve saklama koşullarını kontrol et. API anahtarını uygulamaya girmen seçtiğin servise güvenmen anlamına gelir.

## Gizlilik
- Yerel model: uygulama içinde yerel çıkarım; mesajı internet API'sine göndermez.
- Çevrim içi model: onay verdiğin metin seçtiğin API sağlayıcısına gider.
- Uygulama analitik/reklam SDK'sı içermez.
- API anahtarı Android uygulama özel SharedPreferences alanında tutulur; bu prototipte Android Keystore tabanlı şifreleme ve güvenli proxy yoktur. Hassas/kurumsal anahtar kullanma.
- Android sistem izinleri ve üretici kısıtları geçerlidir.

## Bu sürümdeki telefon araçları
Fener, medya sesi, Wi-Fi/Bluetooth ayar sayfaları, genel ayarlar ve sayaç ekranı. Her işlemden önce uygulama içi onay istenir. Wi-Fi/Bluetooth açma-kapama gibi bazı işlemleri Android üçüncü taraf uygulamalara kapatır; bu nedenle sistem ayar ekranı açılır.

## Teknik not
Bu proje llama.cpp Android NDK kütüphanesini CMake FetchContent ile derlemeye bağlar. llama.cpp API'si gelişmeye devam ettiği için GitHub `master` sürümünde API değişikliği derlemeyi bozabilir. Build başarısız olursa Actions hata günlüğü gerekir; burada APK'nın başarıyla derlendiğini iddia etmiyorum.
