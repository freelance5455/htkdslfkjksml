/* Shared, backward-compatible accounting helpers. Amounts are stored as positive values;
   side is immutable per transaction once saved: dr increases receivable/payable debit,
   cr decreases the net balance from the owner's perspective. */
export function entrySide(entry, entityType = entry?.workerId ? 'staff' : 'farmer') {
  if (entry?.side === 'dr' || entry?.side === 'cr') return entry.side;
  if (entityType === 'staff' || entry?.workerId) {
    if (['workerPayment', 'workerAdvance', 'cashPaid', 'staffDeductionDr'].includes(entry?.type)) return 'dr';
    if (['workerWage', 'attendance', 'staffDeductionCr'].includes(entry?.type)) return 'cr';
  }
  if (entry?.type === 'cash' || entry?.type === 'cashReceived') return 'cr';
  if (entry?.type === 'cashPaid') return 'dr';
  if (entry?.type === 'adjust') return entry?.legacySide === 'dr' ? 'dr' : 'cr';
  // Old app treated these farmer work entries as charges. Keep the old result until reviewed.
  if (['tractor', 'motor', 'motorBill', 'solar', 'wapda', 'spray', 'fertilizer', 'fieldWork'].includes(entry?.type)) return 'dr';
  if (String(entry?.type || '').startsWith('custom-')) {
    const configured = entry?.defaultSide;
    return configured === 'cr' ? 'cr' : 'dr';
  }
  return 'cr';
}

export function entryEffect(entry, entityType) {
  const amount = Math.abs(Number(entry?.amount || 0));
  return entrySide(entry, entityType) === 'dr'
    ? { debit: amount, credit: 0 }
    : { debit: 0, credit: amount };
}

export function signedOpening(opening, side = 'dr') {
  const amount = Math.abs(Number(opening || 0));
  return side === 'cr' ? -amount : amount;
}

export function calculateBalance(entries, openingBalance = 0, entityType) {
  let balance = typeof openingBalance === 'object' && openingBalance !== null
    ? signedOpening(openingBalance.amount, openingBalance.side)
    : Number(openingBalance || 0);
  const rows = [...(entries || [])].sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')) || String(a.id || '').localeCompare(String(b.id || '')));
  const result = rows.map(entry => {
    const effect = entryEffect(entry, entityType);
    balance += effect.debit - effect.credit;
    return { entry, ...effect, balance, side: entrySide(entry, entityType) };
  });
  return { rows: result, debit: result.reduce((n, row) => n + row.debit, 0), credit: result.reduce((n, row) => n + row.credit, 0), closingBalance: balance };
}

export function legacyEntriesNeedingReview(entries) {
  return (entries || []).filter(entry => !['dr', 'cr'].includes(entry.side));
}
