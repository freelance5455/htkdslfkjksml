Blind Connect - by MPN Studio

Files
- index.html      The whole app. Upload this file to Netlify (drag and drop it on your site's Deploys page).
- firestore.rules Security rules for Firebase. Paste into Firebase > Build > Firestore Database > Rules, then press Publish.

Firebase checklist
1. Authentication > Sign-in method > Email/Password: Enable, Save.
2. Firestore Database: create it (Production mode, Mumbai region).
3. Firestore Database > Rules: paste firestore.rules, press Publish.

Server switch
Near the top of index.html there is a line:  window.__USE_FIREBASE = true;
true  = online (Firebase).
false = works only on one device, no server needed.

Contact: WhatsApp / phone 9579107455, email manavnanavare185@gmail.com
