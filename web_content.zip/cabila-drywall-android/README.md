# Cabila Drywall · Faturação (Android)

Esta pasta é um projeto Android completo. Abre a aplicação de faturação num
WebView, por isso funciona offline depois de instalada.

## Gerar o APK (no computador)
1. Instale o Android Studio (developer.android.com/studio).
2. File > Open e escolha a pasta `cabila-drywall-android`. Aguarde a sincronização do Gradle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O ficheiro fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar no telemóvel
1. Copie o ficheiro `app-debug.apk` para o telemóvel.
2. Abra-o e autorize "Instalar apps desconhecidas" para o gestor de ficheiros.
3. Toque em Instalar.

Compatível com Android 7.0 ou superior.

## Publicar na Play Store
Use Build > Generate Signed Bundle / APK, crie uma keystore e guarde-a num lugar seguro.
Sem ela não é possível atualizar a app mais tarde.

## Alterar a aplicação
Edite `app/src/main/assets/index.html`, que é a própria aplicação, e gere novamente o APK.
