package pt.cabila.faturacao;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) toast("Erro ao abrir a aplicação: " + error.getDescription());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException e) {
                    toast("Não foi possível abrir a ligação.");
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.setBackgroundColor(0xFFF2F4F7);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private void toast(final String mensagem) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, mensagem, Toast.LENGTH_LONG).show());
    }

    /** Ponte chamada pela página HTML (window.AndroidBridge). */
    class Bridge {

        @JavascriptInterface
        public void guardarFicheiro(final String base64, final String nome) {
            runOnUiThread(() -> {
                try {
                    byte[] dados = Base64.decode(base64, Base64.DEFAULT);
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.Downloads.DISPLAY_NAME, nome);
                        v.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                            os.write(dados);
                        }
                    } else {
                        File pasta = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        pasta.mkdirs();
                        try (FileOutputStream fos = new FileOutputStream(new File(pasta, nome))) {
                            fos.write(dados);
                        }
                    }
                    toast("PDF guardado na pasta de Transferências: " + nome);
                } catch (Exception e) {
                    toast("Não foi possível guardar o PDF.");
                }
            });
        }

        @JavascriptInterface
        public void partilharWhatsApp(final String base64, final String nome, final String texto) {
            runOnUiThread(() -> {
                try {
                    byte[] dados = Base64.decode(base64, Base64.DEFAULT);
                    File pasta = new File(getCacheDir(), "faturas");
                    pasta.mkdirs();
                    File ficheiro = new File(pasta, nome);
                    try (FileOutputStream fos = new FileOutputStream(ficheiro)) {
                        fos.write(dados);
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", ficheiro);

                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("application/pdf");
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    i.putExtra(Intent.EXTRA_TEXT, texto);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    i.setPackage("com.whatsapp");
                    try {
                        startActivity(i);
                    } catch (ActivityNotFoundException e) {
                        i.setPackage(null);
                        startActivity(Intent.createChooser(i, "Partilhar fatura"));
                    }
                } catch (Exception e) {
                    toast("Não foi possível partilhar a fatura.");
                }
            });
        }
    }
}
