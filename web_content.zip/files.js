// Global DB Reference
let db;

// DOM Elements
const addFileBtn = document.getElementById("addFileBtn");
const filePicker = document.getElementById("filePicker");
const fileList = document.getElementById("fileList");
const backBtn = document.getElementById("backBtn");

// IndexedDB Open
const request = indexedDB.open("HiddenFilesDB", 1);

request.onupgradeneeded = function (e) {
    db = e.target.result;
    if (!db.objectStoreNames.contains("files")) {
        db.createObjectStore("files", { keyPath: "id", autoIncrement: true });
    }
};

request.onsuccess = function (e) {
    db = e.target.result;
    loadFiles();
};

request.onerror = function (e) {
    console.error("Database Error:", e.target.error);
};

// Add File Event
if (addFileBtn && filePicker) {
    addFileBtn.onclick = function () {
        filePicker.click();
    };

    filePicker.onchange = function () {
        const selectedFiles = filePicker.files;
        for (let i = 0; i < selectedFiles.length; i++) {
            saveFile(selectedFiles[i]);
        }
    };
}

// Back Button Event
if (backBtn) {
    backBtn.onclick = function () {
        window.location.href = "vault.html";
    };
}

// Save File
function saveFile(file) {
    const tx = db.transaction("files", "readwrite");
    const store = tx.objectStore("files");

    store.add({
        name: file.name,
        data: file
    });

    tx.oncomplete = function () {
        loadFiles();
    };
}

// Load Files
function loadFiles() {
    if (!fileList) return;
    fileList.innerHTML = "";

    const tx = db.transaction("files", "readonly");
    const store = tx.objectStore("files");

    store.openCursor().onsuccess = function (e) {
        const cursor = e.target.result;

        if (cursor) {
            const item = document.createElement("div");
            item.className = "fileItem";

            const fileData = cursor.value.data;
            const fileName = cursor.value.name;
            const fileId = cursor.value.id;

            item.innerHTML = `
                <span class="openFile">📄 ${fileName}</span>
                <div>
                    <button class="restoreBtn">⬇ Restore</button>
                    <button class="deleteBtn">🗑 Delete</button>
                </div>
            `;

            // Click Handlers
            item.querySelector(".openFile").onclick = function () {
                openFile(fileData);
            };

            item.querySelector(".restoreBtn").onclick = function () {
                downloadFile(fileData, fileName);
            };

            item.querySelector(".deleteBtn").onclick = function () {
                deleteFile(fileId);
            };

            fileList.appendChild(item);
            cursor.continue();
        }
    };
}

// Open File
function openFile(file) {
    const reader = new FileReader();
    reader.onload = function () {
        localStorage.setItem("openFile", reader.result);
        window.location.href = "viewer.html";
    };
    reader.readAsDataURL(file);
}

// Restore / Download File
function downloadFile(file, name) {
    const url = URL.URL.createObjectURL ? URL.createObjectURL(file) : window.URL.createObjectURL(file);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;

    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    setTimeout(() => {
        URL.revokeObjectURL(url);
    }, 1000);
}

// Delete File
function deleteFile(id) {
    const tx = db.transaction("files", "readwrite");
    tx.objectStore("files").delete(id);

    tx.oncomplete = function () {
        loadFiles();
    };
}