
const fileInput = document.getElementById("fileInput");
const filePreview = document.getElementById("filePreview");
const conversionFormat = document.getElementById("conversionFormat");
const convertFilesBtn = document.getElementById("convertFilesBtn");
const conversionStatus = document.getElementById("conversionStatus");
const convertedFiles = document.getElementById("convertedFiles");

let selectedFiles = [];
let outputURLs = [];

function clearOutput() {
  outputURLs.forEach(url => URL.revokeObjectURL(url));
  outputURLs = [];
  convertedFiles.replaceChildren();
}

function showSelectedFiles() {
  filePreview.replaceChildren();

  if (!selectedFiles.length) {
    filePreview.textContent = "لم تختر أي ملفات بعد.";
    return;
  }

  selectedFiles.forEach(file => {
    const item = document.createElement("div");
    item.className = "file-preview-item";
    item.textContent =
      file.name + " — " + (file.size / 1024).toFixed(1) + " KB";
    filePreview.appendChild(item);
  });
};

function updateConversionFormats() {
  const files = Array.from(fileInput.files || []);

  conversionFormat.replaceChildren();

  const addOption = (value, label) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = label;
    conversionFormat.appendChild(option);
  };

  if (!files.length) {
    addOption("", "اختر ملفاً أولاً");
    return;
  }

  const imageFiles = files.every(file =>
  ["image/png", "image/jpeg", "image/webp", "image/bmp"].includes(file.type) ||
  /\.(png|jpe?g|webp|bmp)$/i.test(file.name)
);

  const documentFiles = files.every(file =>
    file.type === "text/plain" ||
    /\.(txt|docx)$/i.test(file.name)
  );
  const pdfFiles = files.every(file =>
  file.type === "application/pdf" ||
  /\.pdf$/i.test(file.name)
);

  if (imageFiles) {
  addOption("image/png", "PNG");
  addOption("image/jpeg", "JPG");
  addOption("image/webp", "WebP");
  addOption("image/bmp", "BMP");
  addOption("pdf", "PDF");
  } else if (documentFiles) {
  addOption("pdf", "PDF");
} else if (pdfFiles) {
  addOption("text/plain", "TXT"); 
  } else {
    addOption("", "هذه الصيغة لم تُدعَم بعد");
  }
}

fileInput.addEventListener("change", () => {
  selectedFiles = Array.from(fileInput.files || []);

  clearOutput();
  showSelectedFiles();
  updateConversionFormats();

  conversionStatus.textContent = selectedFiles.length
    ? "تم اختيار " + selectedFiles.length + " ملف."
    : "";
});

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();

    image.onload = () => {
      URL.revokeObjectURL(url);
      resolve(image);
    };

    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("تعذرت قراءة الصورة: " + file.name));
    };

    image.src = url;
  });
}
function canvasToBMP(canvas) {
  const width = canvas.width;
  const height = canvas.height;
  const ctx = canvas.getContext("2d");
  const imageData = ctx.getImageData(0, 0, width, height);

  const rowSize = Math.ceil((width * 3) / 4) * 4;
  const pixelSize = rowSize * height;
  const buffer = new ArrayBuffer(54 + pixelSize);
  const view = new DataView(buffer);
  const pixels = new Uint8Array(buffer);

  view.setUint8(0, 0x42);
  view.setUint8(1, 0x4D);
  view.setUint32(2, buffer.byteLength, true);
  view.setUint32(10, 54, true);
  view.setUint32(14, 40, true);
  view.setInt32(18, width, true);
  view.setInt32(22, height, true);
  view.setUint16(26, 1, true);
  view.setUint16(28, 24, true);
  view.setUint32(34, pixelSize, true);

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const source = ((height - 1 - y) * width + x) * 4;
      const target = 54 + y * rowSize + x * 3;

      const alpha = imageData.data[source + 3] / 255;

      pixels[target] =
        imageData.data[source + 2] * alpha + 255 * (1 - alpha);
      pixels[target + 1] =
        imageData.data[source + 1] * alpha + 255 * (1 - alpha);
      pixels[target + 2] =
        imageData.data[source] * alpha + 255 * (1 - alpha);
    }
  }

  return new Blob([buffer], { type: "image/bmp" });
}
function imageToBlob(image, format) {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;

    const ctx = canvas.getContext("2d");

    if (format === "image/jpeg") {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    ctx.drawImage(image, 0, 0);

    if (format === "image/bmp") {
  resolve(canvasToBMP(canvas));
  return;
}

canvas.toBlob(blob => {
  if (blob) resolve(blob);
  else reject(new Error("فشل تحويل الصورة."));
}, format, 0.85);
  });
}

function addDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  outputURLs.push(url);

  const item = document.createElement("div");
  item.className = "converted-file-item";

  const name = document.createElement("span");
  name.textContent = filename;

  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.textContent = "تحميل الملف";

  item.append(name, link);
  convertedFiles.appendChild(item);
}

async function convertImages() {
  const format = conversionFormat.value;

  // تحويل PDF إلى TXT
  if (format === "text/plain") {
    if (!window.pdfjsLib) {
      throw new Error("مكتبة قراءة PDF لم تُحمّل.");
    }

    window.pdfjsLib.GlobalWorkerOptions.workerSrc =
      "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";

    for (let i = 0; i < selectedFiles.length; i++) {
      const file = selectedFiles[i];
      const data = await file.arrayBuffer();

      const document = await window.pdfjsLib.getDocument({
        data: new Uint8Array(data)
      }).promise;

      let extractedText = "";

      for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber++) {
        const page = await document.getPage(pageNumber);
        const content = await page.getTextContent();

        extractedText += content.items
          .map(item => item.str)
          .join(" ") + "\n\n";
      }

      const blob = new Blob(
        [extractedText],
        { type: "text/plain;charset=utf-8" }
      );

      const filename = file.name.replace(/\.pdf$/i, "") + ".txt";

      addDownload(blob, filename);

      conversionStatus.textContent =
        "تم استخراج النص من الملف " + (i + 1);
    }

    return;
  }

  if (format === "pdf") {
    if (!window.jspdf?.jsPDF) {
      throw new Error("تعذر تحميل مكتبة PDF. تحقق من الإنترنت.");
    }

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF("p", "mm", "a4");

    
for (let i = 0; i < selectedFiles.length; i++) {
  const file = selectedFiles[i];

  if (file.type === "text/plain" || /\.txt$/i.test(file.name)) {
    const text = await file.text();

    pdf.setFont("helvetica");
    pdf.setFontSize(11);

    const margin = 15;
    const lineHeight = 7;
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();

    const lines = pdf.splitTextToSize(
      text,
      pageWidth - margin * 2
    );

    let y = margin;

    lines.forEach(line => {
      if (y + lineHeight > pageHeight - margin) {
        pdf.addPage();
        y = margin;
      }

      pdf.text(line, margin, y);
      y += lineHeight;
    });

  } else if (file.name.toLowerCase().endsWith(".docx")) {
    if (!window.mammoth) {
      throw new Error("مكتبة Word لم تُحمّل.");
    }

    const arrayBuffer = await file.arrayBuffer();

    const result = await window.mammoth.extractRawText({
      arrayBuffer: arrayBuffer
    });

    const margin = 15;
    const lineHeight = 7;
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();

    pdf.setFontSize(11);

    const lines = pdf.splitTextToSize(
      result.value,
      pageWidth - margin * 2
    );

    let y = margin;

    lines.forEach(line => {
      if (y + lineHeight > pageHeight - margin) {
        pdf.addPage();
        y = margin;
      }

      pdf.text(line, margin, y);
      y += lineHeight;
    });

  } else {
    const image = await loadImage(file);
    if (i > 0) pdf.addPage();

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();

    const ratio = Math.min(
      pageWidth / image.naturalWidth,
      pageHeight / image.naturalHeight
    );

    const width = image.naturalWidth * ratio;
    const height = image.naturalHeight * ratio;

    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;

    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0);

    pdf.addImage(
      canvas.toDataURL("image/jpeg", 0.9),
      "JPEG",
      (pageWidth - width) / 2,
      (pageHeight - height) / 2,
      width,
      height
    );
  }

  conversionStatus.textContent =
    "جاري تجهيز الملف " + (i + 1) + " من " + selectedFiles.length;
}


    addDownload(pdf.output("blob"), "AHMAD-AI-Converted.pdf");
    return;
  }

  const extensions = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
  "image/bmp": "bmp"
};

  for (let i = 0; i < selectedFiles.length; i++) {
    const image = await loadImage(selectedFiles[i]);
    const blob = await imageToBlob(image, format);
    const originalName = selectedFiles[i].name.replace(/\.[^.]+$/, "");

    addDownload(blob, originalName + "." + extensions[format]);

    conversionStatus.textContent =
      "تم تحويل " + (i + 1) + " من " + selectedFiles.length;
  }
}

convertFilesBtn.addEventListener("click", async () => {
  if (!selectedFiles.length) {conversionStatus.textContent = "اختر ملفاً واحداً على الأقل أولاً.";    return;
  }

  clearOutput();
  convertFilesBtn.disabled = true;

  try {
    await convertImages();
    conversionStatus.textContent = "اكتمل التحويل بنجاح.";
  } catch (error) {
    console.error(error);
    conversionStatus.textContent = error.message || "حدث خطأ أثناء التحويل.";
  } finally {
    convertFilesBtn.disabled = false;
  }
});
