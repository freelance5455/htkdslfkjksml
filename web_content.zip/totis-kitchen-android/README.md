# مطبخ توتي - Toti's Kitchen
1. Create a new GitHub repo and upload ALL files from this folder (keep .github/workflows/build.yml).
2. Open the Actions tab -> "Build APK" -> Run workflow (it also runs on every push).
3. After ~5 min: open the repo's "Releases" page on your phone and tap app-debug.apk to install it
   (or download the "totis-kitchen-apk" artifact from the run).
