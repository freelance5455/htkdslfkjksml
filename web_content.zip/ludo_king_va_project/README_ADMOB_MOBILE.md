# LUDO KING VA — AdMob development integration

This update adds native Android AdMob calls through `@capacitor-community/admob`.
It uses Google's official TEST application/ad-unit IDs only. Browser preview will not show ads.

## Included ad placements
- Adaptive banner: home screen only; hidden while a match is active.
- Interstitial: after a match has ended, when the player chooses Back to Home.
- Rewarded video: optional button in Player Profile; 20 local free coins are added only when the SDK reports an earned reward.

## Build from this source
Requires a compatible Node.js/npm environment and Android Studio. This is source code, not a compiled APK.

1. Put the project folder into a build environment.
2. Run `npm install`.
3. Run `npm run build`.
4. Run `npx cap add android` (only once, if no `android/` Capacitor project exists).
5. Add the AdMob `<meta-data>` snippet from `android/AndroidManifest.admob-snippet.xml` inside `<application>` in `android/app/src/main/AndroidManifest.xml`.
6. Add the string from `android/strings.admob-snippet.xml` inside `<resources>` in `android/app/src/main/res/values/strings.xml`.
7. Run `npx cap sync android`.
8. Open the Android project in Android Studio and build a debug APK.

If using a Capacitor Android project that already exists, do not run `npx cap add android` again.

## Test IDs currently configured
- App ID: `ca-app-pub-3940256099942544~3347511713`
- Banner: `ca-app-pub-3940256099942544/6300978111`
- Interstitial: `ca-app-pub-3940256099942544/1033173712`
- Rewarded: `ca-app-pub-3940256099942544/5224354917`

These are test IDs. Do not expect revenue from test ads. Do not click test or live ads repeatedly. Before release, an adult account owner/guardian should handle the AdMob account and app registration, replace test IDs with the correct approved IDs, complete consent/privacy setup, and review the current Google Play and AdMob policies. Do not use production ads during development.

## Important limitations
- Real revenue is not enabled: test IDs do not pay.
- This is an integration-ready source scaffold; it has not been built or tested on a physical Android device in this workspace.
- Local game coins are not cash, cannot be bought or redeemed, and are not a financial reward.
- Online multiplayer, server verification, Firebase auth, and admin dashboard are separate backend work and are not activated by this AdMob update.

## Documentation
- Plugin: https://github.com/capacitor-community/admob
- Google test ads: https://developers.google.com/admob/android/test-ads
