# AdMob update
See `README_ADMOB_MOBILE.md` for the native test-ad integration and build steps.

# LUDO KING VA — BY VISHAL YADAV

## What is included
- `index.html`: playable offline HTML5 Ludo game (single-player vs a simple computer opponent and 2–4 player local pass-and-play).
- `assets/app-icon.svg`: editable vector app icon.
- `firebase/`: starter Firebase configuration, Firestore rules and Cloud Functions outline.
- `android/`: Capacitor packaging notes.

## Run the game
1. Extract the ZIP.
2. Open `index.html` in Chrome, or upload the file to a static host.
3. On Android Chrome, use **⋮ → Add to Home screen** for a browser-installed shortcut.

## Gameplay implemented
- Four token colours, four tokens per player, six required to leave base.
- Dice roll, legal move checks, extra turn on six/capture/finishing.
- Captures, safe squares, home lanes, exact finish, win detection.
- AI opponent, 2/3/4 player local pass-and-play.
- Local profile and basic match statistics saved in browser storage.

## Important scope notes
This is a working offline/local game project, not a deployed online service. Real-time rooms, secure server-authoritative dice, Firebase Authentication, live leaderboard, admin dashboard and production AdMob placements require project credentials, deployed backend code, testing and privacy/legal setup. They are not honestly represented as active in this offline build. The Firebase folder is a secure-starting-point scaffold, not a configured production backend.

## Firebase setup (online upgrade)
1. Create a Firebase project at https://console.firebase.google.com.
2. Register a Web app and copy its config into `firebase/firebase-config.example.js` (then rename to `firebase-config.js`).
3. Enable Authentication providers you intend to support (for example Anonymous or Google).
4. Create Firestore and deploy `firebase/firestore.rules` using Firebase CLI.
5. Deploy callable/HTTPS Cloud Functions from `firebase/functions/` after implementing and testing server-side room state, dice generation, turn validation and rate limits.
6. Never put service-account keys or Admin SDK credentials in browser code.
7. Add emulator tests and rules tests before opening online play to users.

## Android APK build (Capacitor)
Prerequisites: Node.js LTS, npm and Android Studio.
1. Create a folder and copy `index.html` into a `www/` folder.
2. In that folder run:
   `npm init -y`
   `npm install @capacitor/core @capacitor/cli`
   `npx cap init "LUDO KING VA" "com.vishalyadav.ludokingva" --web-dir=www`
   `npm install @capacitor/android`
   `npx cap add android`
3. Copy `assets/app-icon.svg` to a PNG icon set using an icon generator or Android Studio Image Asset Studio. Android launcher icons generally need PNG/WebP density variants; SVG itself is not a launcher icon.
4. Run `npx cap sync android` then `npx cap open android`.
5. In Android Studio choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. For release, create a signed APK/AAB, keep the signing key private, test on real devices and follow Google Play policies.

## AdMob
Use Google's official Mobile Ads SDK for a native Android app or a supported Capacitor plugin. Keep test ad unit IDs during development. Only replace with your own approved ad unit IDs after the app is reviewed. Do not show interstitials during a turn or in a way that interrupts active gameplay. Rewarded ads are optional; all game rewards in this project are free and no purchase/redeem flow is included.

## Before publishing
- Add a real privacy policy and terms page with contact details.
- Complete Firebase security rules and backend validation.
- Add crash/error reporting and accessibility testing.
- Verify gameplay rules and test multiplayer on multiple devices.
- Use test ads and comply with consent, child-safety and local privacy requirements.
