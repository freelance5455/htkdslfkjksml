import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  AdmobConsentStatus,
  BannerAdSize,
  BannerAdPosition
} from '@capacitor-community/admob';

/*
 * DEVELOPMENT ONLY: Google's official Android test ad unit IDs.
 * Replace only after the app is registered and approved in your AdMob account.
 * Never click your own live ads. Do not use test IDs in a published production app.
 */
const TEST_IDS = {
  appId: 'ca-app-pub-3940256099942544~3347511713',
  banner: 'ca-app-pub-3940256099942544/6300978111',
  interstitial: 'ca-app-pub-3940256099942544/1033173712',
  rewarded: 'ca-app-pub-3940256099942544/5224354917'
};

let ready = false;
let bannerVisible = false;
let interstitialPrepared = false;
let rewardedPrepared = false;
let starting = null;

const isNativeAndroid = () =>
  Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';

async function initialize() {
  if (!isNativeAndroid()) {
    console.info('[LudoAds] Native Android required; ads stay disabled in browser preview.');
    return false;
  }
  if (ready) return true;
  if (starting) return starting;

  starting = (async () => {
    try {
      // Consent is checked before initializing/requesting ads.
      let consent = await AdMob.requestConsentInfo();
      if (consent.isConsentFormAvailable && consent.status === AdmobConsentStatus.REQUIRED) {
        consent = await AdMob.showConsentForm();
      }
      if (!consent.canRequestAds) {
        console.info('[LudoAds] Consent not available; no ad request made.');
        return false;
      }

      await AdMob.initialize();
      ready = true;
      await prepareInterstitial();
      await prepareRewarded();
      return true;
    } catch (err) {
      console.warn('[LudoAds] Initialization failed; gameplay continues without ads.', err);
      return false;
    } finally {
      starting = null;
    }
  })();
  return starting;
}

async function showBanner() {
  if (!(await initialize())) return false;
  try {
    await AdMob.showBanner({
      adId: TEST_IDS.banner,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: true,
      npa: true
    });
    bannerVisible = true;
    return true;
  } catch (err) {
    console.warn('[LudoAds] Banner unavailable.', err);
    return false;
  }
}

async function hideBanner() {
  if (!ready || !bannerVisible) return;
  try {
    await AdMob.hideBanner();
    bannerVisible = false;
  } catch (err) {
    console.warn('[LudoAds] Could not hide banner.', err);
  }
}

async function prepareInterstitial() {
  if (!ready) return false;
  try {
    await AdMob.prepareInterstitial({ adId: TEST_IDS.interstitial, isTesting: true, npa: true });
    interstitialPrepared = true;
    return true;
  } catch (err) {
    interstitialPrepared = false;
    console.warn('[LudoAds] Interstitial not ready.', err);
    return false;
  }
}

async function showInterstitial() {
  if (!(await initialize())) return false;
  // Interstitials are only called from the match-complete -> home transition.
  try {
    if (!interstitialPrepared && !(await prepareInterstitial())) return false;
    await hideBanner();
    await AdMob.showInterstitial();
    interstitialPrepared = false;
    await prepareInterstitial();
    return true;
  } catch (err) {
    console.warn('[LudoAds] Interstitial skipped.', err);
    interstitialPrepared = false;
    prepareInterstitial();
    return false;
  }
}

async function prepareRewarded() {
  if (!ready) return false;
  try {
    await AdMob.prepareRewardVideoAd({
      adId: TEST_IDS.rewarded,
      isTesting: true,
      npa: true,
      amount: 20
    });
    rewardedPrepared = true;
    return true;
  } catch (err) {
    rewardedPrepared = false;
    console.warn('[LudoAds] Rewarded ad not ready.', err);
    return false;
  }
}

async function showRewarded() {
  if (!(await initialize())) {
    alert('Reward ads are available only in the installed Android app build.');
    return false;
  }
  try {
    if (!rewardedPrepared && !(await prepareRewarded())) {
      alert('Reward ad is not ready right now. Please try again later.');
      return false;
    }
    const reward = await AdMob.showRewardVideoAd();
    rewardedPrepared = false;
    // The SDK resolves this call only when a reward is earned.
    if (reward && Number(reward.amount) > 0) {
      const coins = Math.min(20, Number(reward.amount));
      const profile = JSON.parse(localStorage.getItem('ludoProfile') || '{"coins":100}');
      profile.coins = Number(profile.coins || 0) + coins;
      localStorage.setItem('ludoProfile', JSON.stringify(profile));
      const coinPill = document.getElementById('coinPill');
      if (coinPill) coinPill.textContent = '🪙 ' + profile.coins;
      alert('Congratulations! ' + coins + ' free coins added.');
    }
    await prepareRewarded();
    return true;
  } catch (err) {
    console.warn('[LudoAds] Reward was not earned or ad failed.', err);
    rewardedPrepared = false;
    prepareRewarded();
    alert('No reward was added. You can try again later.');
    return false;
  }
}

window.LudoAds = { initialize, showBanner, hideBanner, showInterstitial, showRewarded };

// Wait until the page is ready; banner only on the home screen.
window.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => showBanner().catch(() => {}), 700);
});
