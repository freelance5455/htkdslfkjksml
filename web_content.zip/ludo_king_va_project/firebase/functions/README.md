# Cloud Functions implementation checklist

Implement server-authoritative callable/HTTPS functions before enabling online play:
- createRoom / joinRoom / leaveRoom
- rollDice: generate dice only on server; validate authenticated player, room, turn and rate limit
- moveToken: validate legal move against server room state
- reconnectRoom: return authorized room snapshot
- reportMatchResult: calculate winner and leaderboard totals server-side
- admin endpoints: require Firebase custom claims such as `admin === true`

Use transactions for room state changes. Never trust client-submitted dice values, winner claims, coin totals or admin flags. Add App Check, per-user throttling, audit logs, emulator tests and abuse monitoring. This folder intentionally contains no fake client-side security or hard-coded admin password.
