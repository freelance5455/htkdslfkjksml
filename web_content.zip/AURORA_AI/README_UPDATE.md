# AURORA AI - Mise à jour du Module Manga

Cette mise à jour inclut le fichier HTML manquant pour la visionneuse de mangas interne.

### Installation
Dézippez ce fichier et remplacez les dossiers correspondants dans votre projet :
- `android/app/src/main/assets/web/index.html` (Nouveau fichier critique)
- `android/app/src/main/assets/web/manga_panel_placeholder.png` (Image d'exemple requise pour le chargement initial)
