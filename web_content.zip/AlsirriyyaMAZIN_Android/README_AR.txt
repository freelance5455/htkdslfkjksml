السِّرّيّة MAZIN — مشروع Android

مهم: هذه ملفات مشروع Android Studio وليست APK جاهزًا؛ بيئة الإنشاء الحالية لا تحتوي على Android SDK/Gradle لتجميع APK هنا.

طريقة استخراج APK:
1) افتح Android Studio على كمبيوتر.
2) اختر Open وافتح مجلد AlsirriyyaMAZIN.
3) وافق على تنزيل/مزامنة Gradle وAndroid SDK عند الطلب.
4) من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s).
5) ستجد الملف غالبًا في app/build/outputs/apk/debug/app-debug.apk.

باسورد دخول الواجهة: 7117
كلمة سر التشفير منفصلة، ويجب أن تكون متطابقة عند المرسل والمستقبل.
التطبيق لا يرسل الرسائل إلى خادم؛ انسخ الرسالة المشفرة وأرسلها بنفسك.
