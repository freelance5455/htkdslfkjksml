# نور - تشغيل وبناء تطبيق الأندرويد

## المتطلبات
- Node.js 18 أو أحدث
- Android Studio (مع Android SDK و JDK 17)

## الخطوات
1. انسخ هذا المجلد لجهازك وادخل إليه:
   ```
   cd nour-app
   npm install
   ```
2. أضف منصة الأندرويد (مرة واحدة فقط):
   ```
   npx cap add android
   ```
3. انسخ ملف الواجهة إلى المشروع وزامن:
   ```
   npx cap sync android
   ```
4. افتح المشروع في Android Studio:
   ```
   npx cap open android
   ```
5. لبناء ملف APK: من القائمة Build > Build Bundle(s) / APK(s) > Build APK(s).
   لنشر على Google Play استخدم Build > Generate Signed Bundle / APK.

## ملاحظات
- واجهة التطبيق في `www/index.html`. أي تعديل عليها ثم `npx cap sync android`.
- معرّف التطبيق في `capacitor.config.json` (`appId`). غيّره قبل النشر إلى نطاقك الخاص.
- الإشعارات المجدولة في الخلفية والويدجت تحتاج كود أندرويد أصلي إضافي (لم يُضف بعد).
- القرآن والصوت يحتاجان اتصال إنترنت، والمواقيت والتسبيح والأذكار تعمل بدونه.

## التنبيهات (مهم)
- ثبّت إضافة التنبيهات: `npm install @capacitor/local-notifications@6` ثم `npx cap sync android`.
- تأكد إن `AndroidManifest.xml` فيه صلاحيات: `POST_NOTIFICATIONS`، و`SCHEDULE_EXACT_ALARM` (مع أندرويد 14)، و`RECEIVE_BOOT_COMPLETED` (عشان تنعاد الجدولة بعد إعادة تشغيل الجوال). إذا الإضافة ما أضافتها تلقائياً، أضفها يدوياً.
- الويدجت: انسخ ملفات `widget-android` حسب الشرح في `widget-android/README-widget.md`.
