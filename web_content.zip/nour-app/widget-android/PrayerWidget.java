package com.nour.islamic;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.TimeZone;

/** ويدجت أوقات الصلاة: الصلاة القادمة + أوقات اليوم. */
public class PrayerWidget extends AppWidgetProvider {

    private static final String[] KEYS = {"fajr", "dhuhr", "asr", "maghrib", "isha"};
    private static final String[] NAMES = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) updateOne(ctx, mgr, id);
    }

    static void updateOne(Context ctx, AppWidgetManager mgr, int id) {
        // الموقع المحفوظ (عمّان افتراضياً). التطبيق يكتبه هنا عبر إضافة لاحقة.
        SharedPreferences p = ctx.getSharedPreferences("nour_widget", Context.MODE_PRIVATE);
        double lat = p.getFloat("lat", 31.9539f);
        double lng = p.getFloat("lng", 35.9106f);

        Calendar now = Calendar.getInstance();
        LinkedHashMap<String, Long> t = PrayerCalc.times(
                now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH),
                lat, lng, 18.0, 17.0, 0.0, 1.0);

        long nowMs = System.currentTimeMillis();
        String nextName = NAMES[0];
        long nextT = t.get("fajr") + 86400000L;
        for (int i = 0; i < KEYS.length; i++) {
            long v = t.get(KEYS[i]);
            if (v > nowMs) { nextName = NAMES[i]; nextT = v; break; }
        }

        SimpleDateFormat f = new SimpleDateFormat("HH:mm", Locale.US);
        f.setTimeZone(TimeZone.getDefault());

        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_prayer);
        v.setTextViewText(R.id.wNext, "الصلاة القادمة: " + nextName);
        v.setTextViewText(R.id.wTime, f.format(new Date(nextT)));

        int[] rows = {R.id.wFajr, R.id.wDhuhr, R.id.wAsr, R.id.wMaghrib, R.id.wIsha};
        for (int i = 0; i < rows.length; i++) {
            v.setTextViewText(rows[i], NAMES[i] + "\n" + f.format(new Date(t.get(KEYS[i]))));
        }

        // الضغط على الويدجت يفتح التطبيق
        Intent launch = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        if (launch != null) {
            PendingIntent pi = PendingIntent.getActivity(ctx, 0, launch, PendingIntent.FLAG_IMMUTABLE);
            v.setOnClickPendingIntent(R.id.wRoot, pi);
        }

        mgr.updateAppWidget(id, v);
    }
}
