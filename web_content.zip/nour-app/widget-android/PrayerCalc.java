package com.nour.islamic;

import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.TimeZone;

/**
 * حساب أوقات الصلاة للويدجت. نفس منطق صفحة الويب (بالتوقيت العالمي،
 * مع تكرار الحساب عند وقت كل حدث). الزوايا: الفجر والعشاء حسب الطريقة.
 */
public class PrayerCalc {
    private static final double R = Math.PI / 180.0;

    /** يرجع وقت كل صلاة بالميلي ثانية (UTC) لليوم المحلي المعطى. */
    public static LinkedHashMap<String, Long> times(int year, int month0, int day,
                                                   double lat, double lng,
                                                   double fajrAngle, double ishaAngle,
                                                   double elev, double asrFactor) {
        GregorianCalendar g = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        g.clear();
        g.set(year, month0, day);
        long base = g.getTimeInMillis();
        double d0 = base / 86400000.0 + 2440587.5 - 2451545.0;

        double sunAlt = -(0.833 + 0.0347 * Math.sqrt(Math.max(0, elev)));

        double transit = 12 - lng / 15.0;
        for (int i = 0; i < 4; i++) transit = 12 - lng / 15.0 - solar(d0 + transit / 24.0)[1];

        double tMaghrib = event(d0, lat, lng, sunAlt, +1);
        double tFajr = event(d0, lat, lng, -fajrAngle, -1);
        double tSunrise = event(d0, lat, lng, sunAlt, -1);
        double tIsha = event(d0, lat, lng, -ishaAngle, +1);
        double tAsr = asr(d0, lat, lng, asrFactor);

        LinkedHashMap<String, Long> out = new LinkedHashMap<>();
        out.put("fajr", toMs(base, tFajr));
        out.put("sunrise", toMs(base, tSunrise));
        out.put("dhuhr", toMs(base, transit));
        out.put("asr", toMs(base, tAsr));
        out.put("maghrib", toMs(base, tMaghrib));
        out.put("isha", toMs(base, tIsha));
        return out;
    }

    private static long toMs(long base, double hours) {
        long ms = base + Math.round(hours * 3600000.0);
        return Math.round(ms / 60000.0) * 60000L;
    }

    /** موقع الشمس: [ميل الشمس بالدرجات، معادلة الوقت بالساعات]. */
    private static double[] solar(double D) {
        double g = (357.529 + 0.98560028 * D) % 360;
        double q = (280.459 + 0.98564736 * D) % 360;
        double L = (q + 1.915 * Math.sin(g * R) + 0.020 * Math.sin(2 * g * R)) % 360;
        double e = 23.439 - 0.00000036 * D;
        double RA = (Math.atan2(Math.cos(e * R) * Math.sin(L * R), Math.cos(L * R)) / R + 360) % 360;
        double decl = Math.asin(Math.sin(e * R) * Math.sin(L * R)) / R;
        double diff = (((q - RA) + 540) % 360) - 180;
        return new double[]{decl, diff / 15.0};
    }

    private static double hourAngle(double alt, double decl, double lat) {
        double x = (Math.sin(alt * R) - Math.sin(lat * R) * Math.sin(decl * R))
                / (Math.cos(lat * R) * Math.cos(decl * R));
        x = Math.min(1, Math.max(-1, x));
        return Math.acos(x) / R / 15.0;
    }

    private static double event(double d0, double lat, double lng, double alt, int sign) {
        double t = 12 - lng / 15.0;
        for (int i = 0; i < 4; i++) {
            double[] s = solar(d0 + t / 24.0);
            t = (12 - lng / 15.0 - s[1]) + sign * hourAngle(alt, s[0], lat);
        }
        return t;
    }

    private static double asr(double d0, double lat, double lng, double factor) {
        double t = 12 - lng / 15.0;
        for (int i = 0; i < 4; i++) {
            double[] s = solar(d0 + t / 24.0);
            double alt = Math.atan(1.0 / (factor + Math.tan(Math.abs((lat - s[0]) * R)))) / R;
            t = (12 - lng / 15.0 - s[1]) + hourAngle(alt, s[0], lat);
        }
        return t;
    }
}
