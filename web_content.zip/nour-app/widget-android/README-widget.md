# ويدجت أوقات الصلاة (أندرويد)

## ما فيه
- `PrayerCalc.java`: حساب أوقات الصلاة (نفس منطق صفحة الويب).
- `PrayerWidget.java`: الويدجت نفسه. يعرض الصلاة القادمة وأوقات الصلوات الخمس.
- `res/layout/widget_prayer.xml`: شكل الويدجت.
- `res/xml/prayer_widget_info.xml`: إعدادات الويدجت (الحجم، التحديث).

## طريقة الإضافة (بعد `npx cap add android`)
1. انسخ الملفين `PrayerCalc.java` و`PrayerWidget.java` إلى:
   `android/app/src/main/java/com/nour/islamic/`
2. انسخ `res/layout/widget_prayer.xml` إلى `android/app/src/main/res/layout/`
3. انسخ `res/xml/prayer_widget_info.xml` إلى `android/app/src/main/res/xml/`
4. في `android/app/src/main/AndroidManifest.xml` داخل `<application>` أضف:
   ```xml
   <receiver android:name=".PrayerWidget" android:exported="false">
       <intent-filter>
           <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
       </intent-filter>
       <meta-data android:name="android.appwidget.provider"
           android:resource="@xml/prayer_widget_info" />
   </receiver>
   ```
5. نفّذ `npx cap sync android` ثم ابنِ التطبيق من Android Studio.
6. ثبّت التطبيق، واضغط مطولاً على الشاشة الرئيسية > Widgets > نور.

## ملاحظات مهمة
- الكود ما اتجرّب على جهاز حقيقي. لازم تبنيه وتشوفه، وممكن تحتاج تعديلات.
- الويدجت حالياً يستخدم موقع عمّان الافتراضي. تغيير الموقع يحتاج إضافة Capacitor تكتب الإحداثيات في `nour_widget` (lat/lng).
- أندرويد يحدّث الويدجت كل 30 دقيقة كحد أدنى، فالصلاة القادمة ممكن تتأخر تحديثها حتى 30 دقيقة. الحل الكامل يحتاج AlarmManager.
- الويدجت ما يشغّل الأذان بنفسه، يعرض الأوقات فقط. التنبيهات الصوتية بالخلفية تحتاج خدمة أندرويد منفصلة.
