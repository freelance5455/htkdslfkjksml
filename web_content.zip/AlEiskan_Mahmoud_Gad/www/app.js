const services = [
  {icon:"⌂", title:"شقق الإسكان الاجتماعي", desc:"تعرف على الشروط والمستندات وخطوات التقديم وفق الإعلانات الرسمية."},
  {icon:"▦", title:"أراضي بيت الوطن للمصريين بالخارج", desc:"معلومات إرشادية عن المشروع والطروحات والإجراءات المتاحة."},
  {icon:"◆", title:"شقق الإسكان الفاخر", desc:"استفسر عن المشروعات والوحدات والمعلومات المنشورة رسميًا."},
  {icon:"▤", title:"شقق الإسكان المتوسط", desc:"تعرف على تفاصيل المشروعات والشروط والمستندات المطلوبة."},
  {icon:"⌂", title:"مبادرة بيتك في مصر", desc:"معلومات عن المبادرة الموجهة للمصريين بالخارج ومشروعاتها."},
  {icon:"◎", title:"جميع الخدمات الإلكترونية", desc:"مساعدة في الوصول إلى الخدمات والبوابات الحكومية الرسمية."}
];
const primaryPhone = "201069235307";
const secondaryPhone = "201205759749";
const grid = document.getElementById("servicesGrid");
const makeWhatsApp = (phone, service) => `https://wa.me/${phone}?text=${encodeURIComponent("السلام عليكم، أريد الاستفسار عن خدمة: " + service + " من الإسكان مع محمود جاد.")}`;
grid.innerHTML = services.map((service, i) => `
  <article class="service-card">
    <span class="service-icon" aria-hidden="true">${service.icon}</span>
    <h3>${service.title}</h3>
    <p>${service.desc}</p>
    <a class="service-link" href="${makeWhatsApp(primaryPhone, service.title)}" target="_blank" rel="noopener">استفسر عبر واتساب ←</a>
  </article>`).join("");
document.getElementById("year").textContent = new Date().getFullYear();
const toggle = document.getElementById("menuToggle");
const nav = document.getElementById("mainNav");
toggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  toggle.setAttribute("aria-expanded", "false");
}));
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
