# V74 — Excel buttons native-input fix

Built from V73.

- **Choose File** is now the actual HTML file input exposed through a styled label. This removes the custom JavaScript bridge click path that could silently do nothing. Android WebView handles the file input through `onShowFileChooser`.
- **Download Excel template** uses `dpm-template://save`, intercepted by `MainActivity`, then opens Android `ACTION_CREATE_DOCUMENT` Save As.
- **Import Items** remains the existing preview-and-Supabase import flow and becomes enabled after the selected file is parsed.
- No Supabase SQL/schema/functions changed.
- Existing Banked delete function and Balance functionality retained.
