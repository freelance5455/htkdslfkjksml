/**
 * Kanha Shop - Web Bluetooth ESC/POS Direct Print Helper
 * Supports direct connection to mini thermal printers (58mm/80mm) via Web Bluetooth API.
 * Currency: Khmer Riel (៛ / KHR)
 */

class BluetoothPrinter {
  constructor() {
    this.device = null;
    this.server = null;
    this.characteristic = null;
    this.isConnected = false;
  }

  // Check if Web Bluetooth is supported in this browser
  isSupported() {
    return 'bluetooth' in navigator;
  }

  // Connect to Bluetooth thermal printer
  async connect() {
    if (!this.isSupported()) {
      throw new Error("Browser មិនគាំទ្រ Web Bluetooth ទេ។ សូមប្រើ Google Chrome!");
    }

    try {
      this.device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: [
          '000018f0-0000-1000-8000-00805f9b34fb',
          'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
          '49535343-fe7d-4ae5-8fa9-9fafd205e455',
          0x18f0,
          0xffe0,
          0xffe1
        ]
      });

      this.device.addEventListener('gattserverdisconnected', () => {
        this.isConnected = false;
        console.log('Bluetooth Printer disconnected');
      });

      const server = await this.device.gatt.connect();
      this.server = server;

      const services = await server.getPrimaryServices();
      for (const service of services) {
        const characteristics = await service.getCharacteristics();
        for (const char of characteristics) {
          if (char.properties.write || char.properties.writeWithoutResponse) {
            this.characteristic = char;
            this.isConnected = true;
            return this.device.name || "Bluetooth Printer";
          }
        }
      }

      throw new Error("រកមិនឃើញ Write Characteristic លើ Printer នេះទេ!");
    } catch (err) {
      this.isConnected = false;
      throw err;
    }
  }

  // Send raw bytes in chunks
  async sendData(dataArray) {
    if (!this.characteristic) {
      throw new Error("មិនទាន់បានភ្ជាប់ Bluetooth Printer ទេ!");
    }

    const chunkSize = 50;
    for (let i = 0; i < dataArray.length; i += chunkSize) {
      const chunk = dataArray.slice(i, i + chunkSize);
      await this.characteristic.writeValue(new Uint8Array(chunk));
      await new Promise(r => setTimeout(r, 20));
    }
  }

  encodeText(text) {
    const encoder = new TextEncoder();
    return Array.from(encoder.encode(text));
  }

  // Print text receipt via ESC/POS commands (Khmer Riel)
  async printEscPos(receiptData) {
    const ESC = 0x1B;
    const GS = 0x1D;

    let buffer = [
      ESC, 0x40, // Initialize printer
      ESC, 0x61, 0x01, // Align Center
      ESC, 0x21, 0x30, // Double height & width
      ...this.encodeText((receiptData.shopName || "Kanha Shop") + "\n"),
      ESC, 0x21, 0x00, // Normal text
      ...this.encodeText((receiptData.shopKhmerName ? receiptData.shopKhmerName + "\n" : "")),
      ...this.encodeText((receiptData.shopPhone ? "Tel: " + receiptData.shopPhone + "\n" : "")),
      ...this.encodeText((receiptData.shopAddress ? receiptData.shopAddress + "\n" : "")),
      ...this.encodeText("--------------------------------\n"),
      ESC, 0x61, 0x00, // Align Left
      ...this.encodeText(`Inv: ${receiptData.invNo}\n`),
      ...this.encodeText(`Date: ${receiptData.date}\n`),
      ...this.encodeText(`Cashier: ${receiptData.cashier}\n`),
      ...this.encodeText("--------------------------------\n"),
      ...this.encodeText("Item             Qty   Total(R)\n"),
      ...this.encodeText("--------------------------------\n")
    ];

    // Items
    for (const item of receiptData.items) {
      const name = item.name.substring(0, 14).padEnd(14, ' ');
      const qty = String(item.qty).padStart(5, ' ');
      const total = (Math.round(item.price * item.qty).toLocaleString() + 'r').padStart(11, ' ');
      buffer.push(...this.encodeText(`${name}${qty}${total}\n`));
    }

    buffer.push(
      ...this.encodeText("--------------------------------\n"),
      ESC, 0x61, 0x02, // Align Right
      ...this.encodeText(`Subtotal: ${receiptData.subtotal.toLocaleString()} KHR\n`),
      ...(receiptData.discount > 0 ? this.encodeText(`Discount: -${receiptData.discount.toLocaleString()} KHR\n`) : []),
      ESC, 0x21, 0x30, // Double size Bold
      ...this.encodeText(`TOTAL: ${receiptData.total.toLocaleString()} KHR\n`),
      ESC, 0x21, 0x00,
      ...this.encodeText(`Received: ${receiptData.received.toLocaleString()} KHR\n`),
      ...this.encodeText(`Change: ${receiptData.change.toLocaleString()} KHR\n`),
      ...this.encodeText("--------------------------------\n"),
      ESC, 0x61, 0x01, // Center
      ...this.encodeText((receiptData.footerMsg || "Thank You! សូមអរគុណ!") + "\n"),
      0x0A, 0x0A, 0x0A, 0x0A,
      GS, 0x56, 0x41, 0x10
    );

    await this.sendData(buffer);
  }
}

window.BluetoothPrinter = new BluetoothPrinter();
