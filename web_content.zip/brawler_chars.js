(function () {
  var PALETTES = [
    { body: "#ff6b6b", hat: "#ffd32a", accent: "#ffffff", aura: "rgba(255,107,107,0.35)" },
    { body: "#4ecdc4", hat: "#ff9f43", accent: "#ffffff", aura: "rgba(78,205,196,0.35)" },
    { body: "#a55eea", hat: "#2ed573", accent: "#ffffff", aura: "rgba(165,94,234,0.35)" },
    { body: "#ffa502", hat: "#3742fa", accent: "#ffffff", aura: "rgba(255,165,2,0.35)" },
    { body: "#1e90ff", hat: "#ff4757", accent: "#ffffff", aura: "rgba(30,144,255,0.35)" }
  ];

  var SKIN_OVERRIDES = {
    "Oltin Qirol": {
      body: "#ffd32a",
      hat: "#ff9f1a",
      accent: "#fff200",
      aura: "rgba(255, 211, 42, 0.45)",
      crown: true,
      sparkles: true
    },
    "Soya Ninja": {
      body: "#2f3542",
      hat: "#6c5ce7",
      accent: "#a29bfe",
      aura: "rgba(108, 92, 231, 0.45)",
      mask: true,
      shadowTrail: true
    },
    "Olmos Ritsar": {
      body: "#00d2d3",
      hat: "#00a8ff",
      accent: "#ffffff",
      aura: "rgba(0, 210, 211, 0.45)",
      visor: true,
      sparkles: true
    },
    "Olmos Ritsar (RP)": {
      body: "#0984e3",
      hat: "#00cec9",
      accent: "#ffeaa7",
      aura: "rgba(0, 206, 201, 0.55)",
      visor: true,
      sparkles: true
    },
    "Ajdaho Imperatori (RP)": {
      body: "#ff3838",
      hat: "#ff9f1a",
      accent: "#ffd32a",
      aura: "rgba(255, 71, 87, 0.55)",
      crown: true,
      sparkles: true,
      flamePulse: true
    }
  };

  var entityState = new WeakMap();
  var shockwaves = [];

  function getSelectedSkinName() {
    try {
      var keys = ["brawl_uz_progress_v2", "brawl_uz_progress_v1"];
      for (var i = 0; i < keys.length; i++) {
        var raw = localStorage.getItem(keys[i]);
        if (raw) {
          var parsed = JSON.parse(raw);
          if (parsed && parsed.selectedSkin) return parsed.selectedSkin;
        }
      }
    } catch (e) {}
    return "Klassik";
  }

  function findCharacterArrays() {
    var found = [];
    var names = ["players", "bots", "enemies", "fighters", "brawlers", "units"];
    for (var i = 0; i < names.length; i++) {
      var n = names[i];
      if (typeof window[n] !== "undefined" && Array.isArray(window[n])) {
        found.push({ arr: window[n], isMainPlayerList: n === "players" });
      }
    }
    if (typeof player !== "undefined" && player && typeof player === "object") {
      found.push({ arr: [player], isMainPlayerList: true, single: true });
    }
    return found;
  }

  function getState(ent) {
    var st = entityState.get(ent);
    if (!st) {
      st = {
        lastX: ent.x,
        lastY: ent.y,
        lastHp: typeof ent.hp === "number" ? ent.hp : null,
        moveIntensity: 0,
        recoil: 0,
        hitFlash: 0,
        trail: []
      };
      entityState.set(ent, st);
    }
    return st;
  }

  function updateEntityAnimState(ent) {
    var st = getState(ent);
    var dx = ent.x - st.lastX;
    var dy = ent.y - st.lastY;
    var dist = Math.hypot(dx, dy);

    st.lastX = ent.x;
    st.lastY = ent.y;

    var targetMove = Math.min(1.5, dist / 4.2);
    st.moveIntensity += (targetMove - st.moveIntensity) * 0.25;

    if (st.moveIntensity > 0.18 && Math.random() < 0.45) {
      st.trail.push({
        x: ent.x,
        y: ent.y + 10,
        r: 5 + Math.random() * 4,
        alpha: 0.45
      });
    }

    if (typeof ent.hp === "number") {
      if (st.lastHp !== null && ent.hp < st.lastHp) {
        st.hitFlash = 1.0;
        st.recoil = Math.max(st.recoil, 0.7);
        shockwaves.push({
          x: ent.x,
          y: ent.y,
          radius: 10,
          maxRadius: 34,
          alpha: 0.75,
          color: "#ff6b6b"
        });
      }
      st.lastHp = ent.hp;
    }

    // Agar otish tugmasi bosilgan yoki o'q otilayotgan bo'lsa
    if (
      (typeof keys !== "undefined" && (keys[" "] || keys["Space"] || keys["f"] || keys["F"])) ||
      (typeof window.isShooting !== "undefined" && window.isShooting) ||
      ent.shooting ||
      ent.isAttacking
    ) {
      if (st.recoil < 0.35) {
        st.recoil = 1.0;
        var ang = typeof ent.angle === "number" ? ent.angle : 0;
        shockwaves.push({
          x: ent.x + Math.cos(ang) * 20,
          y: ent.y + Math.sin(ang) * 20,
          radius: 5,
          maxRadius: 22,
          alpha: 0.65,
          color: "#ffd32a"
        });
      }
    }

    st.recoil = Math.max(0, st.recoil - 0.09);
    st.hitFlash = Math.max(0, st.hitFlash - 0.08);

    for (var i = st.trail.length - 1; i >= 0; i--) {
      st.trail[i].alpha -= 0.035;
      st.trail[i].r += 0.35;
      if (st.trail[i].alpha <= 0) st.trail.splice(i, 1);
    }

    return st;
  }

  function drawShockwaves(ctx) {
    for (var i = shockwaves.length - 1; i >= 0; i--) {
      var sw = shockwaves[i];
      sw.radius += (sw.maxRadius - sw.radius) * 0.25;
      sw.alpha -= 0.055;
      if (sw.alpha <= 0) {
        shockwaves.splice(i, 1);
        continue;
      }
      ctx.save();
      ctx.strokeStyle = sw.color;
      ctx.globalAlpha = Math.max(0, sw.alpha);
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  function drawBrawlerCharacter(ctx, ent, idx, isMain) {
    if (!ent || typeof ent.x !== "number" || typeof ent.y !== "number") return;
    if (ent.dead === true || ent.alive === false || (typeof ent.hp === "number" && ent.hp <= 0)) return;

    var st = updateEntityAnimState(ent);
    var r = typeof ent.radius === "number" ? ent.radius : (typeof ent.r === "number" ? ent.r : 20);
    var scale = Math.max(0.85, Math.min(1.35, r / 20));
    var t = Date.now() * 0.009 + idx * 1.3;

    var speedFactor = 0.6 + st.moveIntensity * 1.4;
    var bob = Math.sin(t * speedFactor) * (1.8 + st.moveIntensity * 2.2);
    var tilt = Math.sin(t * speedFactor) * (0.04 + st.moveIntensity * 0.06);

    var pal = PALETTES[idx % PALETTES.length];
    var skinName = isMain ? getSelectedSkinName() : "Klassik";
    var ov = isMain && SKIN_OVERRIDES[skinName] ? SKIN_OVERRIDES[skinName] : null;

    var bodyColor = st.hitFlash > 0.2 ? "#ffffff" : ((ov && ov.body) || ent.color || pal.body);
    var hatColor = st.hitFlash > 0.2 ? "#ff6b6b" : ((ov && ov.hat) || pal.hat);
    var accentColor = (ov && ov.accent) || pal.accent;
    var auraColor = (ov && ov.aura) || pal.aura;

    var angle = typeof ent.angle === "number" ? ent.angle : (typeof ent.aimAngle === "number" ? ent.aimAngle : 0);

    // Harakat izlari (trail)
    for (var tr = 0; tr < st.trail.length; tr++) {
      var item = st.trail[tr];
      ctx.save();
      ctx.globalAlpha = Math.max(0, item.alpha * 0.5);
      ctx.fillStyle = ov && ov.shadowTrail ? hatColor : "#ffffff";
      ctx.beginPath();
      ctx.arc(item.x, item.y, item.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    ctx.save();
    ctx.translate(ent.x, ent.y + bob);

    // Taglik soya va yugurish halqasi
    ctx.save();
    ctx.translate(0, r * 0.72 - bob * 0.4);
    ctx.fillStyle = "rgba(0, 0, 0, 0.28)";
    ctx.beginPath();
    ctx.ellipse(0, 0, r * 0.95, r * 0.36, 0, 0, Math.PI * 2);
    ctx.fill();

    if (isMain) {
      var pulse = 1 + Math.sin(t * 1.2) * (ov && ov.flamePulse ? 0.14 : 0.06);
      ctx.strokeStyle = "#ffd32a";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.ellipse(0, 0, 18 * pulse, 7.2 * pulse, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();

    // Personaj gavdasi va tebranish animatsiyasi
    ctx.scale(scale, scale);
    ctx.rotate(tilt);
    ctx.lineWidth = 3;
    ctx.strokeStyle = "#11131a";
    ctx.lineJoin = "round";

    // Skin aurasi (yuqori daraja / RP skinlar uchun)
    if (isMain && ov) {
      var auraRadius = 21 + Math.sin(t * 1.5) * 2.5;
      ctx.save();
      ctx.fillStyle = auraColor;
      ctx.beginPath();
      ctx.arc(0, 0, auraRadius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Qo'l / yelka tebranish animatsiyasi
    var armSwing = Math.sin(t * (1.5 + st.moveIntensity)) * (2.5 + st.moveIntensity * 4.5);
    ctx.fillStyle = bodyColor;
    ctx.beginPath();
    ctx.arc(-15, 2 + armSwing, 6.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(15, 2 - armSwing, 6.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Asosiy chibi-brawler tanasi
    ctx.fillStyle = bodyColor;
    ctx.beginPath();
    ctx.arc(0, 1, 16.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Toj / dubulg'a / kepka
    if (ov && ov.crown) {
      var crownBounce = Math.sin(t * 1.8) * 1.4;
      ctx.fillStyle = "#ffd32a";
      ctx.beginPath();
      ctx.moveTo(-11, -11 + crownBounce);
      ctx.lineTo(-13, -22 + crownBounce);
      ctx.lineTo(-5, -16 + crownBounce);
      ctx.lineTo(0, -25 + crownBounce);
      ctx.lineTo(5, -16 + crownBounce);
      ctx.lineTo(13, -22 + crownBounce);
      ctx.lineTo(11, -11 + crownBounce);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    } else {
      ctx.fillStyle = hatColor;
      ctx.beginPath();
      ctx.arc(0, -5, 14.5, Math.PI * 1.05, Math.PI * 1.95);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }

    // Ko'zlar va qarash animatsiyasi
    var lookX = Math.cos(angle) * 3.4;
    var lookY = Math.sin(angle) * 2.4;
    var blink = Math.sin(t * 0.45) > 0.97 ? 0.15 : 1.0;

    if (ov && ov.mask) {
      ctx.fillStyle = "#1e272e";
      ctx.fillRect(-13, -4, 26, 9);
      ctx.strokeRect(-13, -4, 26, 9);
    }

    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.ellipse(-5.5 + lookX * 0.6, 0.5 + lookY * 0.5, 4.4, 5.4 * blink, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.ellipse(5.5 + lookX * 0.6, 0.5 + lookY * 0.5, 4.4, 5.4 * blink, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    if (blink > 0.5) {
      ctx.fillStyle = "#11131a";
      ctx.beginPath();
      ctx.arc(-5.5 + lookX, 1 + lookY, 2.2, 0, Math.PI * 2);
      ctx.arc(5.5 + lookX, 1 + lookY, 2.2, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = accentColor;
      ctx.beginPath();
      ctx.arc(-6.4 + lookX, -0.4 + lookY, 1.1, 0, Math.PI * 2);
      ctx.arc(4.6 + lookX, -0.4 + lookY, 1.1, 0, Math.PI * 2);
      ctx.fill();
    }

    // Og'iz animatsiyasi
    ctx.strokeStyle = "#11131a";
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.arc(lookX * 0.5, 8.5 + lookY * 0.3, 4.2, 0.15 * Math.PI, 0.85 * Math.PI);
    ctx.stroke();

    // Qurol + recoil + muzzle flash animatsiyasi
    ctx.save();
    ctx.rotate(angle);
    var kick = st.recoil * 5;
    ctx.fillStyle = "#485460";
    ctx.strokeStyle = "#11131a";
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.roundRect(10 - kick, -3.5, 13, 7, 2.5);
    ctx.fill();
    ctx.stroke();

    if (st.recoil > 0.25) {
      ctx.fillStyle = "#fff200";
      ctx.beginPath();
      ctx.moveTo(24 - kick, 0);
      ctx.lineTo(33 - kick, -6);
      ctx.lineTo(30 - kick, 0);
      ctx.lineTo(33 - kick, 6);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    // Yaltiroq zarralar (sparkles animatsiyasi)
    if (isMain && ov && ov.sparkles) {
      for (var sp = 0; sp < 3; sp++) {
        var spAng = t * 1.6 + sp * ((Math.PI * 2) / 3);
        var sx = Math.cos(spAng) * 23;
        var sy = Math.sin(spAng) * 23;
        ctx.fillStyle = accentColor;
        ctx.beginPath();
        ctx.arc(sx, sy, 2.2 + Math.sin(t * 3 + sp) * 0.8, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    ctx.restore();
  }

  function renderBrawlersOverlay() {
    var canvas = document.querySelector("canvas");
    if (!canvas) return;
    var ctx = canvas.getContext("2d");
    if (!ctx) return;

    var groups = findCharacterArrays();
    for (var g = 0; g < groups.length; g++) {
      var info = groups[g];
      var arr = info.arr;
      for (var i = 0; i < arr.length; i++) {
        var isMain = info.isMainPlayerList && i === 0;
        drawBrawlerCharacter(ctx, arr[i], i + g * 3, isMain);
      }
    }

    drawShockwaves(ctx);
  }

  window.addEventListener("load", function () {
    setInterval(renderBrawlersOverlay, 33);
  });
})();
