package ir.mr.khorasani;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.Settings;import android.print.*;import android.webkit.*;import android.view.*;import java.io.*;import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE); web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setDefaultTextEncodingName("UTF-8"); web.addJavascriptInterface(new Bridge(this),"Android"); web.setWebViewClient(new WebViewClient()); web.loadUrl("file:///android_asset/index.html"); }
 @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
 public static class Bridge { final Activity a; Bridge(Activity x){a=x;}
  @JavascriptInterface public String deviceId(){return Settings.Secure.getString(a.getContentResolver(),Settings.Secure.ANDROID_ID);}
  @JavascriptInterface public void saveFile(String name,String content,String mime){try{ if(Build.VERSION.SDK_INT>=29){android.content.ContentValues v=new android.content.ContentValues();v.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,name);v.put(android.provider.MediaStore.Downloads.MIME_TYPE,mime);v.put(android.provider.MediaStore.Downloads.IS_PENDING,1);Uri u=a.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u!=null){try(OutputStream o=a.getContentResolver().openOutputStream(u)){o.write(content.getBytes(StandardCharsets.UTF_8));}v.clear();v.put(android.provider.MediaStore.Downloads.IS_PENDING,0);a.getContentResolver().update(u,v,null,null);}}
  }catch(Exception e){new AlertDialog.Builder(a).setMessage("ذخیره فایل انجام نشد: "+e.getMessage()).setPositiveButton("باشه",null).show();}}
  @JavascriptInterface public void share(String subject,String body){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,subject);i.putExtra(Intent.EXTRA_TEXT,body);a.startActivity(Intent.createChooser(i,"ارسال/ذخیره خروجی"));}
  @JavascriptInterface public void printHtml(String title,String html){WebView p=new WebView(a);p.getSettings().setJavaScriptEnabled(true);p.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);p.setWebViewClient(new WebViewClient(){public void onPageFinished(WebView v,String u){PrintManager pm=(PrintManager)a.getSystemService(Context.PRINT_SERVICE);pm.print(title,v.createPrintDocumentAdapter(title),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());}});}
 }
}
