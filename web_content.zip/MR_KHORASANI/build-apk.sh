#!/usr/bin/env bash
set -euo pipefail
gradle assembleDebug --no-daemon
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
