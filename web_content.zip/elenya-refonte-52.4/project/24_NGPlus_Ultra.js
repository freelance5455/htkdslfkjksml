// V52.5 — NG+ ULTRA COMPLETE — couche additive, idempotente, sans impact classique.
var _ngPlusUltraApplied=false;

function applyNgPlusUltra_(){
  if(_ngPlusUltraApplied||typeof NGPLUS_DB==='undefined')return;
  _ngPlusUltraApplied=true;
  const B=(typeof ELENYA_ART_V54_BASE!=='undefined'?ELENYA_ART_V54_BASE:'https://cdn.jsdelivr.net/gh/Sunstrader/elenya-3d-assets@main/game-v54/');
  const BG={autel:'autel-reveil',memoire:'royaume-souvenirs',bibli:'bibliotheque',obs:'observatoire',gal:'galeries-basalte',dome:'dome-magique',mans:'mansarde-auberge',trone:'trone-ebene',forge:'forge-sacree',serre:'serre',lac:'lac-glaciaire',foret:'foret-noire',camp:'campement-nuit',chambre:'chambre-automate',cour:'cour-duel',larmes:'larmes-kalthar',chaos:'fin-chaos',aube:'fin-aube'};
  const bg=k=>B+'backgrounds/'+BG[k]+'.webp';
  const ff=f=>({type:'SET_FLAG',target:f}),fg=(g,v)=>({type:'ADD_GAUGE',target:g,value:v});
  const branch=(parent,key,id,title,pic,text,learn,act,flag,gauge)=>{
    const p=NGPLUS_DB[parent];if(!p||NGPLUS_DB[id])return;
    const c=(p.choices||[]).find(x=>x.key===key);if(!c)return;
    const next=c.next;c.next=id;
    NGPLUS_DB[id]={sceneNumber:id,chapter:p.chapter,title,mood:p.mood||'exploration',image:bg(pic),text,choices:[
      {key:'COMPRENDRE',text:learn,next,effects:[ff(flag+'_compris'),fg(gauge,2)],importance:'major',journal:learn},
      {key:'AGIR',text:act,next,effects:[ff(flag+'_agi'),fg('volonte',2)],importance:'major',journal:act}
    ]};
  };

  // Acte I — les quatre premiers noeuds ne convergent plus immédiatement.
  const S=[
    ['NGP_01_SEUIL','MEMOIRE','NGP_U01_MEMOIRE','L’archive des vies mortes','memoire','Neuf versions d’Elenya se superposent autour de la stèle. Aucune ne veut être réduite à une erreur. Les fins deviennent enfin des preuves comparables, mais aussi des vies qui ont réellement été vécues.','Classer les fins par cause et conséquence.','Conserver aussi ce qu’elles ont ressenti.','ngpu_archive','memoire_kalthar'],
    ['NGP_01_SEUIL','REFUS','NGP_U01_REFUS','La chambre sans passé','chambre','Le givre efface les mots. Pendant quelques secondes, aucun souvenir ne revient. Tu comprends alors la différence entre oublier le passé et lui retirer le droit de commander le présent.','Garder une seule phrase : « Je peux contredire mes anciennes vies. »','Effacer jusqu’à ton nom sur la stèle.','ngpu_refus','volonte'],
    ['NGP_01_SEUIL','FEN','NGP_U01_FEN','Fen ne dormait jamais vraiment','camp','Fen te montre les réveils qu’il a traversés sans pouvoir parler : toi morte, reine, absente, parfois heureuse. Son silence n’était pas de l’ignorance ; c’était une limite qu’il ne savait pas franchir sans te voler ton choix.','Reconnaître Fen comme lui-même, pas comme Kalthar.','Exiger de voir le tout premier réveil.','ngpu_fen','memoire_kalthar'],
    ['NGP_01_SEUIL','COURONNE','NGP_U01_COURONNE','Le poids qui connaît ton front','trone','La couronne se referme exactement à la taille de ton crâne. Elle a mémorisé toutes tes versions. Tu peux l’étudier comme un mécanisme ou lui retirer immédiatement tout droit symbolique sur toi.','Lire les anciennes commandes inscrites dans le métal.','Poser la couronne au sol avant qu’elle redevienne une habitude.','ngpu_couronne','memoire_kalthar'],

    ['NGP_02_NEUF_ECHOS','KALTHAR','NGP_U02_KALTHAR','La première mort de Kalthar','larmes','Le souvenir interdit montre Kalthar hésitant et terrifié. La légende avait effacé sa peur pour rendre son sacrifice plus utile. Tu découvres un homme avant de retrouver un symbole.','Conserver sa peur dans la mémoire officielle.','Refuser que son sacrifice devienne une prophétie.','ngpu_kalthar','memoire_kalthar'],
    ['NGP_02_NEUF_ECHOS','AMOUR','NGP_U02_AMOUR','Les mains qui devenaient des chaînes','serre','Des gestes tendres, des promesses et des jalousies apparaissent ensemble. Rien n’est entièrement faux. Le piège commence au moment où « reste » devient « tu dois rester ».','Nommer les anciennes limites franchies.','Garder le beau sans garder la cage.','ngpu_amour','volonte'],
    ['NGP_02_NEUF_ECHOS','TRONE','NGP_U02_TRONE','Le mécanisme sous le velours','trone','Sous le symbole royal, le Trône révèle ses conduits de givre : il transforme une volonté individuelle en loi du monde. Le problème n’est pas seulement le souverain ; c’est l’architecture qui en exige un.','Dessiner le mécanisme pour le démonter.','Couper un premier conduit secondaire.','ngpu_trone','memoire_kalthar'],
    ['NGP_02_NEUF_ECHOS','SILENCE','NGP_U02_SOI','La trace sans nom','foret','Une empreinte presque effacée n’appartient ni à Kalthar, ni à Kaelen, ni à Alistair. Elle est à toi, avant la couronne. Pour une fois, la route n’a pas été préparée par quelqu’un d’autre.','Suivre la trace jusqu’à ton premier souvenir humain.','Marquer le chemin pour pouvoir y revenir librement.','ngpu_soi','volonte'],

    ['NGP_03_PALAIS_ECHO','PROMESSE','NGP_U03_ECOUTE','La confession entière','bibli','Kalthar parle sans réclamer ton pardon. Il savait que la Stase te survivrait, mais pas qu’elle apprendrait à transformer tes choix en ancres. Son erreur fut de croire qu’il pouvait décider seul du prix acceptable.','L’écouter jusqu’au bout sans le rassurer.','Arrêter toute justification du sacrifice.','ngpu_confession','memoire_kalthar'],
    ['NGP_03_PALAIS_ECHO','COLERE','NGP_U03_COLERE','La colère et le verre','cour','Ta colère fissure les vitres du palais-mémoire. Kalthar ne disparaît pas. Le monde n’a pas besoin que ta colère soit sage pour qu’elle soit vraie, mais elle ne doit pas devenir une nouvelle couronne.','Dire enfin ce que les siècles ont laissé sans témoin.','T’arrêter avant que la colère ne décide à ta place.','ngpu_colere','instabilite'],
    ['NGP_03_PALAIS_ECHO','PARDON','NGP_U03_PARDON','Le pardon peut attendre','serre','Tu refuses de fabriquer une réponse immédiate. « Je ne sais pas » devient une décision entière. Le pardon différé n’est ni une vengeance ni une promesse.','Garder la question ouverte.','Refuser que Kalthar attende une absolution comme récompense.','ngpu_pardon','volonte'],
    ['NGP_03_PALAIS_ECHO','DEPART','NGP_U03_VIVRE','Vivre avant de comprendre','village','Tu quittes le palais et trouves des gens qui mangent, rient et réparent un toit. Aucun d’eux ne parle du Trône. Tu avais oublié qu’un monde à sauver contient aussi des journées qui ne parlent pas de toi.','Observer cette vie sans la transformer en leçon.','Aider à réparer le toit avant de reprendre la quête.','ngpu_vivre','volonte'],

    ['NGP_04_FRESQUE_REPRISE','DETTE','NGP_U04_NOMS','Le nom effacé sous le cercle','bibli','Sous plusieurs couches de pigment apparaît une liste de signatures, pas un coupable unique. Chaque génération a ajouté sa correction au piège. Chercher un seul monstre simplifierait l’histoire jusqu’à la rendre dangereuse.','Conserver les signatures avec leur contexte.','Étudier le mécanisme avant de distribuer les fautes.','ngpu_noms','memoire_kalthar'],
    ['NGP_04_FRESQUE_REPRISE','GEL','NGP_U04_FRONTIERE','Une frontière qui laisse passer','lac','Tu testes le Gel sur un ruisseau de chaleur. Une prison parfaite arrête tout, y compris ce qui devrait vivre. Une frontière imparfaite exige de l’attention et des relais.','Conserver le modèle de frontière souple.','Prévoir une barrière dure uniquement pour l’urgence.','ngpu_frontiere','volonte'],
    ['NGP_04_FRESQUE_REPRISE','BRISER','NGP_U04_FRAGMENTS','Après avoir cassé le récit','gal','La fresque se brise mais la chaleur derrière elle reste. Détruire une histoire fausse ne répare pas automatiquement ce qu’elle cachait. Les fragments deviennent maintenant une responsabilité.','Les archiver comme preuve d’un récit officiel mensonger.','Empêcher qu’ils soient reconstruits comme nouvelle vérité unique.','ngpu_fragments','memoire_kalthar'],
    ['NGP_04_FRESQUE_REPRISE','FEN','NGP_U04_SECRET_FEN','Ce que Fen a gardé','camp','Fen révèle une instruction de Kalthar : « Si elle me cherche, donne-lui du temps avant de lui donner une réponse. » Son silence devait préserver ton droit au doute, même s’il t’a blessée.','Reconnaître l’intention sans effacer la blessure.','Décider que Fen n’aura plus à porter seul ce secret.','ngpu_secret_fen','memoire_kalthar'],

    // Acte II — les choix relationnels ont chacun une scène propre avant la convergence.
    ['NGP_07_KAELEN_ECHO','STAY','NGP_U07_RESTE','Marcher sans contrat','foret','Kaelen marche à côté de toi, jamais un demi-pas derrière. Il demande où vous allez au lieu de supposer. Ce détail minuscule prouve davantage que toutes les promesses des anciennes vies.','Choisir ensemble le prochain détour.','L’autoriser explicitement à te contredire.','ngpu_kaelen_reste','lien_O'],
    ['NGP_07_KAELEN_ECHO','KISS','NGP_U07_BAISER','Après le baiser, une porte','serre','Le baiser ne résout rien, et c’est précisément ce qui le rend différent. Kaelen ne réclame pas une définition pour demain. Vous restez devant une porte ouverte.','Nommer ce que ce moment ne promet pas.','Choisir le présent sans contrat.','ngpu_kaelen_baiser','lien_O'],
    ['NGP_07_KAELEN_ECHO','DISTANCE','NGP_U07_DISTANCE','Un départ sans punition','cour','Kaelen accepte la distance sans transformer ton refus en dette. Il te rend même une moitié de carte : « Tu pourrais en avoir besoin sans moi. »','Reconnaître que la distance est respectée.','Garder la carte sans rouvrir la relation.','ngpu_kaelen_distance','volonte'],
    ['NGP_07_KAELEN_ECHO','QUESTION','NGP_U07_SOURCE','Le contrat avant son nom','bibli','La lignée de Kaelen n’était pas la première. Sa famille a hérité d’une fonction conçue pour survivre aux individus. Cela n’efface pas ses choix ; cela explique la cage dans laquelle ils ont été préparés.','Séparer héritage et responsabilité.','Archiver son témoignage avec le contrat.','ngpu_kaelen_source','memoire_kalthar'],

    ['NGP_08_ALISTAIR_ECHO','STAY','NGP_U08_RESTE','La porte reste ouverte','dome','Alistair laisse réellement la porte ouverte malgré le froid. Il te demande si tu veux qu’il reste, et pour la première fois la question ne contient pas sa propre réponse.','Choisir sa présence pour cette nuit seulement.','Refuser de décider aujourd’hui pour demain.','ngpu_alistair_reste','lien_E'],
    ['NGP_08_ALISTAIR_ECHO','KISS','NGP_U08_BAISER','La lumière après le baiser','serre','La lumière monte puis retombe sans sceller quoi que ce soit. Alistair rit presque de soulagement : aucun signe divin ne vient valider ou condamner ce moment.','Accepter un moment sans validation magique.','Nommer les limites que la foi ne décidera plus.','ngpu_alistair_baiser','lien_E'],
    ['NGP_08_ALISTAIR_ECHO','DISTANCE','NGP_U08_DISTANCE','La clé au sol','cour','Vous laissez la clé entre vous. Personne ne la ramasse. Le symbole perd sa lumière et devient un simple objet. Alistair part sans chercher une nouvelle serrure à garder.','Désacraliser la clé définitivement.','Conserver son histoire sans conserver son autorité.','ngpu_alistair_distance','volonte'],
    ['NGP_08_ALISTAIR_ECHO','QUESTION','NGP_U08_SOURCE','Le sceau avant la foi','obs','Les premiers tracés du Sceau Leonhart sont techniques, pas religieux. La prière est venue après. La foi d’Alistair peut rester vraie sans que l’outil de sa lignée garde un droit sur toi.','Séparer la foi du mécanisme de confinement.','Copier les tracés pour les rendre publics.','ngpu_alistair_source','memoire_kalthar'],

    ['NGP_09_DEUX_ECHOS','TRUCE','NGP_U09_TRUCE','Trois personnes, trois distances','camp','Marcher à trois rend visibles désir, jalousie et peur. Vous décidez de parler des distances au lieu de les deviner. La trêve devient une pratique, pas une posture romantique.','Écrire des règles révisables par les trois.','Autoriser chacun à demander une pause sans justification.','ngpu_truce','volonte'],
    ['NGP_09_DEUX_ECHOS','O','NGP_U09_O','Choisir Kaelen sans vainqueur','mans','Kaelen prend ta main. Alistair reste une personne avec sa propre suite, pas un perdant cosmique. Tu refuses que l’amour reproduise la logique du duel qui nourrissait le cycle.','Dire clairement que ce choix ne condamne personne.','Garder la relation hors du mécanisme du Trône.','ngpu_choix_o','lien_O'],
    ['NGP_09_DEUX_ECHOS','E','NGP_U09_E','Choisir Alistair sans vainqueur','dome','Alistair prend ta main. Kaelen ne devient pas un obstacle à éliminer. Le choix amoureux cesse d’être une guerre de succession.','Dire clairement que ce choix ne condamne personne.','Garder la relation hors du mécanisme du Trône.','ngpu_choix_e','lien_E'],
    ['NGP_09_DEUX_ECHOS','NONE','NGP_U09_NONE','Ne distribuer aucune place','foret','Tu ne choisis aucun des deux. Ils doivent enfin décider ce qu’ils deviennent quand ton désir ne leur donne aucun rôle. Le silence est inconfortable mais libre.','Les laisser partir séparément.','Accepter qu’ils restent seulement comme alliés.','ngpu_choix_none','volonte'],

    // Acte III — Oraya, Lyra et Fen deviennent de vraies branches de conséquences.
    ['NGP_10_ORAYA','PARDON','NGP_U10_PARDON','Pardonner ne ferme pas le dossier','forge','Oraya reçoit ton pardon sans sourire. Tu lui demandes ensuite d’ouvrir les archives et de répondre devant les survivants. Le pardon retire la vengeance du centre ; il ne supprime pas la responsabilité.','Exiger une déposition publique.','La faire participer à la réparation des lieux du rituel.','ngpu_oraya_pardon','memoire_kalthar'],
    ['NGP_10_ORAYA','PUNIR','NGP_U10_JUSTICE','Une justice sans absolution','cour','Tu refuses le pardon. Oraya demande quelle forme doit prendre sa responsabilité pour ne pas devenir un nouveau sacrifice spectaculaire.','Confier le jugement aux survivants.','L’écarter de tout pouvoir magique.','ngpu_oraya_justice','volonte'],
    ['NGP_10_ORAYA','QUESTION','NGP_U10_CARTE','La carte du cycle','obs','Oraya trace une constellation : Stase, Trône, contrats, sceaux, mémoires, Brasier. Aucun point n’est seul responsable ; chacun renforce les autres.','Copier la carte pour la transmettre.','Identifier les liens à couper avant le Trône.','ngpu_carte','memoire_kalthar'],
    ['NGP_10_ORAYA','SILENCE','NGP_U10_SILENCE','La stèle entre vous','gal','Tu ne réponds pas. Oraya comprend que ton silence n’est ni pardon ni condamnation. Pour une fois, elle ne remplit pas le vide avec une justification.','Rester jusqu’à ce que le silence cesse d’être une arme.','Partir sans lui offrir une scène de rédemption.','ngpu_oraya_silence','volonte'],

    ['NGP_11_LYRA','LIBERER','NGP_U11_LIBRE','Le droit d’être inutile','serre','Lyra passe une journée entière sans chanter. Rien de catastrophique n’arrive. Posséder un don qui n’est pas immédiatement réquisitionné devient une victoire politique.','Protéger son droit au repos.','Laisser Lyra choisir elle-même si elle témoignera.','ngpu_lyra_libre','volonte'],
    ['NGP_11_LYRA','CHANT','NGP_U11_CHANT','Un chant qui n’ouvre rien','obs','Vous chantez faux. Lyra rit au milieu d’une note. Aucune porte ne s’ouvre, aucun pouvoir ne répond. Le chant est enfin seulement un chant.','Garder le souvenir sans le transformer en symbole.','Enregistrer la chanson comme trace d’une liberté ordinaire.','ngpu_lyra_chant','memoire_kalthar'],
    ['NGP_11_LYRA','POUVOIR','NGP_U11_POUVOIR','Un pouvoir sans service obligatoire','dome','Lyra fait vibrer un verre puis s’arrête. Elle aime encore son pouvoir. La liberté n’exige pas d’abandonner ce qu’on aime, seulement le droit des autres de le réclamer.','Affirmer son droit de garder son pouvoir.','Écrire avec elle les usages qu’elle refuse.','ngpu_lyra_pouvoir','volonte'],
    ['NGP_11_LYRA','SILENCE','NGP_U11_SILENCE','Le ciel ouvert','foret','Vous restez assises sans parler. Lyra déplace son manteau pour te faire une place. Aucun pacte ne naît du silence. Aucune dette non plus.','Accepter que la présence suffise.','Partir avant que le silence devienne une obligation.','ngpu_lyra_silence','volonte'],

    ['NGP_12_FEN','LETTING_GO','NGP_U12_DEUIL','Les funérailles de trois siècles','larmes','Tu offres enfin à Kalthar une mort qui ne sert plus de moteur. Pas de statue ni de prophétie : un nom, quelques témoins, et Fen qui reste Fen.','Prononcer son nom comme celui d’un mort, pas d’une promesse.','Conserver une page de son histoire sans appeler son retour.','ngpu_deuil','memoire_kalthar'],
    ['NGP_12_FEN','REFUSE','NGP_U12_REFUS','La main qui refuse de s’ouvrir','chambre','Le palais-mémoire recommence à se construire dès que tu refuses de lâcher Kalthar. Tu vois le danger mais la douleur reste réelle. Le jeu ne transforme pas ce choix en caricature du mal.','Reconnaître que cette douleur devient du pouvoir.','Laisser malgré tout une fissure dans le souvenir.','ngpu_refus_kalthar','possession'],
    ['NGP_12_FEN','SILENCE','NGP_U12_FEN','Fen, seulement Fen','camp','Tu cesses de chercher un roi dans les yeux du furet. Fen vole un morceau de tissu et s’endort dessus. La banalité du geste te brise presque plus que les apparitions de Kalthar.','Choisir de connaître Fen comme lui-même.','Garder Kalthar comme mémoire sans lui voler le corps de Fen.','ngpu_fen_soi','volonte'],

    // Acte IV — chaque réponse au Brasier et au Trône reçoit sa conséquence jouable.
    ['NGP_13_BRASIER','GEL','NGP_U13_GEL','Tester la ligne vivante','lac','Le Brasier frappe ta frontière. Elle plie au lieu de casser. Une frontière vivante exige des relais, du repos et la possibilité d’être remplacée.','Concevoir la frontière pour être tenue à plusieurs.','Garder seule la première garde, mais seulement temporairement.','ngpu_brasier_gel','volonte'],
    ['NGP_13_BRASIER','MORTEL','NGP_U13_MORTEL','Le froid quitte tes doigts','aube','Le givre se retire de tes veines. Un corps humain a des limites immédiates, mais le Brasier perd une partie de sa prise. Ta mort future ne sera plus automatiquement un événement cosmique.','Accepter pleinement la limite humaine.','Admettre que le pouvoir te manque déjà.','ngpu_mortelle','volonte'],
    ['NGP_13_BRASIER','LIBERTE','NGP_U13_MIROIRS','Les éclats de toutes les fins','chaos','Les miroirs explosent. Chaque éclat contient une fin réellement vécue. Les briser ne les rend pas fausses ; cela leur retire le droit de devenir ton futur obligatoire.','Ramasser quelques éclats pour l’histoire.','Laisser le reste fondre sans monument.','ngpu_miroirs','memoire_kalthar'],
    ['NGP_13_BRASIER','POSSESSION','NGP_U13_PRISON','La prison sous ta peau','chaos','Le Brasier entre en toi. Tu as sauvé les autres d’une menace immédiate mais recréé l’ancienne architecture : une personne porte seule le danger pour tous.','Dire immédiatement aux autres ce que tu as fait.','Concentrer d’abord toute ton énergie sur le confinement.','ngpu_brasier_prison','possession'],

    ['NGP_14_TRONE_BRIS','DESTROY','NGP_U14_DETRUIT','Le silence après le fracas','trone','Le Trône s’effondre. Rien ne le remplace automatiquement. Détruire une institution ne crée pas encore la manière de vivre après elle.','Proposer une assemblée provisoire de survivants.','Rendre les décisions aux communautés locales.','ngpu_trone_detruit','volonte'],
    ['NGP_14_TRONE_BRIS','TRANSFORM','NGP_U14_ARCHIVE','Un Trône qui ne peut plus ordonner','bibli','Les conduits sont neutralisés. Le Trône devient une archive : toutes les décisions imposées restent consultables, aucune n’est exécutable.','Ouvrir l’archive au public.','Créer plusieurs clés indépendantes pour éviter une nouvelle centralisation.','ngpu_trone_archive','memoire_kalthar'],
    ['NGP_14_TRONE_BRIS','KEEP','NGP_U14_GARDE','La promesse devant un siège intact','trone','Tu promets de ne jamais utiliser le Trône. Kaelen demande ce qui arrivera si tu as peur demain ; Alistair demande ce qui arrivera après ta mort. Une promesse individuelle n’est pas une architecture.','Sceller l’accès avec plusieurs volontés indépendantes.','Assumer le risque et garder l’accès pour toi.','ngpu_trone_garde','possession'],
    ['NGP_14_TRONE_BRIS','SACRIFICE','NGP_U14_SACRIFICE','Devenir le mécanisme','chambre','Le Trône accepte ton sacrifice avec une facilité obscène. Toutes les attentes se tournent vers toi. Tu reconnais la vieille solution : devenir indispensable pour que les autres n’aient pas à décider ensemble.','Reculer avant que le mécanisme se ferme.','Rester malgré la contradiction.','ngpu_trone_sacrifice','instabilite'],

    // Acte V — chaque fin a une scène de décision finale distincte avant sa cinématique.
    ['NGP_15_DERNIER_CHOIX','FRONTIERE','NGP_U15_FRONTIERE','Avant de devenir une ligne','lac','Avant de tracer la frontière, tu demandes qui prendra le relais lorsque tu faibliras. Plusieurs mains se lèvent. La responsabilité devient partageable.','Inscrire le principe de relais dans la frontière.','Porter la première garde seule, mais pas l’éternité.','ngpu_fin_frontiere','volonte'],
    ['NGP_15_DERNIER_CHOIX','CYCLE','NGP_U15_CYCLE','Avant de recommencer','autel','Tu sais exactement ce qui arrivera si tu refuses encore la mort de Kalthar. Le premier matin reviendra. Personne ne pourra appeler cela un accident.','Accepter consciemment le recommencement.','Promettre que ce sera la dernière boucle malgré le doute.','ngpu_fin_cycle','possession'],
    ['NGP_15_DERNIER_CHOIX','FINAL','NGP_U15_LIBRE','Une aube sans couronne','aube','La couronne est au sol. Le geste final consiste à partir sans la reprendre lorsque les autres demandent qui décidera demain. « Vous », réponds-tu. « Et parfois vous vous tromperez. »','Partir avant qu’on transforme ton départ en cérémonie.','Laisser la carte du cycle et les archives.','ngpu_fin_libre','volonte'],
    ['NGP_15_DERNIER_CHOIX','LOVE','NGP_U15_AMOUR','Une main qui peut se retirer','serre','Tu tends la main. Personne ne la prend immédiatement. Cette attente est essentielle : le geste n’a de sens que si l’autre peut choisir de ne pas répondre.','Refuser tout serment éternel.','Construire une vie commune avec des portes qui restent ouvrables.','ngpu_fin_amour','volonte'],
    ['NGP_15_DERNIER_CHOIX','THRONE','NGP_U15_DEUX','Trois personnes devant le même siège','trone','Vous revenez tous les trois devant le Trône. La vieille histoire voudrait un couple, un rival et un vainqueur. Vous refusez les trois rôles.','Détruire le mécanisme ensemble sans propriétaire final.','Conserver seulement un fragment inerte comme avertissement.','ngpu_fin_deux','memoire_kalthar'],
    ['NGP_15_DERNIER_CHOIX','VOID','NGP_U15_VIDE','La place que personne ne prend','trone','Le siège vide donne envie de le remplir « provisoirement ». C’est ainsi que les mécanismes reviennent. Tu recules d’un pas.','Laisser la salle ouverte et le siège vide.','Démonter le siège sans construire de symbole de remplacement.','ngpu_fin_vide','volonte']
  ];
  S.forEach(x=>branch(...x));

  // Secret 100 % : neuf fins classiques + forte mémoire.
  if(NGPLUS_DB.NGP_12_FEN&&!NGPLUS_DB.NGP_12_FEN.choices.some(c=>c.key==='NEUVIEME')){
    NGPLUS_DB.NGP_12_FEN.choices.push({key:'NEUVIEME',text:'Ouvrir la neuvième mémoire interdite.',next:'NGP_U12_NEUVIEME',effects:[fg('memoire_kalthar',2),ff('ngpu_neuvieme')],importance:'critical',condition:gs=>Array.isArray(gs.ngPlus&&gs.ngPlus.originEnds)&&gs.ngPlus.originEnds.length>=9&&gs.getGauge('memoire_kalthar')>=10});
    NGPLUS_DB.NGP_U12_NEUVIEME={sceneNumber:'NGP_U12_NEUVIEME',chapter:3,title:'La neuvième mémoire',mood:'intimate',image:bg('chambre'),sprite:'Kalthar',text:'La neuvième mémoire n’est pas une fin mais l’instant avant la première. Kalthar, Oraya et une Elenya encore humaine cherchent comment survivre au Brasier. La phrase qui fonde le cycle est simple : « Il faut que quelqu’un décide. »\n\nTu comprends que la prison est née de l’idée qu’une seule personne devait porter la réponse.',choices:[{key:'PARTAGER',text:'Graver cette vérité dans les archives publiques.',next:'NGP_13_BRASIER',effects:[fg('volonte',3),ff('ngplus_verite_partagee')],importance:'critical'},{key:'GARDER',text:'Garder la vérité jusqu’à ce que le cycle soit brisé.',next:'NGP_13_BRASIER',effects:[fg('memoire_kalthar',3),ff('ngplus_verite_gardee')],importance:'critical'}]};
  }

  // Échos dynamiques NG+ Ultra — conservent text/image fixes tout en réagissant aux mémoires et routes réelles.
  const attachUltraEcho = (id, fn) => {
    const s = NGPLUS_DB[id];
    if (!s || typeof s.getDynamicNarrative === 'function') return;
    const baseText = s.text || '';
    s.getDynamicNarrative = (gs) => {
      const out = fn(gs, baseText);
      return out ? String(out) : baseText;
    };
  };
  ['NGP_U01_MEMOIRE','NGP_U01_REFUS','NGP_U01_FEN','NGP_U01_COURONNE'].forEach(id => attachUltraEcho(id, (gs, base) => {
    const origins = Array.isArray(gs.ngPlus && gs.ngPlus.originEnds) ? gs.ngPlus.originEnds.length : 0;
    const last = gs.getLastClassicEnding ? gs.getLastClassicEnding() : null;
    let lead = '';
    if (origins >= 2) lead = `Déjà ${origins} fins gravées répondent sous ton souffle.\n\n`;
    else if (last) lead = "L’écho de ta dernière sortie revient contre ta tempe, encore intact.\n\n";
    return lead + base;
  }));
  ['NGP_U07_RESTE','NGP_U07_BAISER','NGP_U07_DISTANCE','NGP_U07_SOURCE'].forEach(id => attachUltraEcho(id, (gs, base) => {
    let tail = '';
    if (gs.hasFlag('ngplus_preuve_contrat')) tail = "\n\nLa copie du contrat plie contre ta hanche : tu tiens désormais l’arme contre la guilde, pas contre lui.";
    else if (gs.hasFlag('ngplus_contrat_rendu')) tail = "\n\nEn lui laissant le papier intact, tu as retiré à cette entrevue toute ressemblance avec une convocation.";
    return base + tail;
  }));
  ['NGP_U08_RESTE','NGP_U08_BAISER','NGP_U08_DISTANCE','NGP_U08_SOURCE'].forEach(id => attachUltraEcho(id, (gs, base) => {
    let tail = '';
    if (gs.hasFlag('ngplus_sceau_explique')) tail = "\n\nLes traits de la serrure héritée restent ouverts devant lui : aucune clause ne demeure cachée entre vous.";
    else if (gs.hasFlag('ngplus_ancrage_rompu')) tail = "\n\nTon nom ne figure plus dans le cercle du Sceau ; ce qu’il te dit ce soir ne vient plus de sa lignée.";
    return base + tail;
  }));
  ['NGP_U09_TRUCE','NGP_U09_O','NGP_U09_E','NGP_U09_NONE'].forEach(id => attachUltraEcho(id, (gs, base) => {
    let lead = '';
    if (gs.hasFlag('ngplus_marques_brisees')) lead = "Les deux marques ont été brûlées dès l’orée du cycle ; il ne reste devant toi que deux hommes sans mandat.\n\n";
    else if (gs.hasFlag('ngplus_deux_marques')) lead = "Les deux marques que tu as conservées pèsent encore, preuves silencieuses de ce que la boucle attendait de vous.\n\n";
    return lead + base;
  }));
  ['NGP_U13_GEL','NGP_U13_MORTEL','NGP_U13_MIROIRS','NGP_U13_PRISON'].forEach(id => attachUltraEcho(id, (gs, base) => {
    let lead = '';
    if (gs.hasFlag('ngplus_verite_partagee')) lead = "La vérité gravée dans les archives publiques empêche désormais le Brasier de prétendre qu’une seule souveraine doit répondre.\n\n";
    else if (gs.hasFlag('ngplus_verite_gardee')) lead = "La vérité de la neuvième mémoire reste scellée contre ton cœur, prête à peser au seuil du Trône.\n\n";
    return lead + base;
  }));
  attachUltraEcho('NGP_U14_GARDE', (gs) => {
    const hasO = !gs.hasFlag('ngplus_kaelen_distance') && !gs.hasFlag('ngplus_kaelen_amitie') && !gs.hasFlag('ngplus_libertes')
      && (gs.hasFlag('ngplus_route_O') || (gs.hasFlag('ngplus_route_both') && !gs.hasFlag('ngplus_choix_final_E')));
    const hasE = !gs.hasFlag('ngplus_alistair_distance') && !gs.hasFlag('ngplus_alistair_amitie') && !gs.hasFlag('ngplus_libertes')
      && (gs.hasFlag('ngplus_route_E') || (gs.hasFlag('ngplus_route_both') && !gs.hasFlag('ngplus_choix_final_O')));
    let line = "Tu promets de ne jamais utiliser le Trône. ";
    if (hasO && hasE) line += "Kaelen demande ce qui arrivera si tu as peur demain ; Alistair demande ce qui arrivera après ta mort. ";
    else if (hasO) line += "Kaelen demande à voix basse ce qui arrivera si tu as peur demain — puis qui veillera après ta mort. ";
    else if (hasE) line += "Alistair demande gravement ce qui arrivera si tu cèdes demain, et qui gardera la salle après ta mort. ";
    else line += "Dans le silence de la nef, ta propre voix te renvoie les deux questions : que fera la peur demain, et que restera-t-il après ta mort ? ";
    return line + "Une promesse individuelle n’est pas une architecture.";
  });
  ['NGP_U15_FRONTIERE','NGP_U15_CYCLE','NGP_U15_LIBRE','NGP_U15_AMOUR','NGP_U15_VIDE'].forEach(id => attachUltraEcho(id, (gs, base) => {
    let lead = '';
    if (gs.hasFlag('ngplus_trone_detruit')) lead = "Derrière toi, le bois noir gît en éclats irréparables.\n\n";
    else if (gs.hasFlag('ngplus_trone_memoire')) lead = "Désarmé, le Trône n’est plus qu’un registre silencieux.\n\n";
    else if (gs.hasFlag('ngplus_trone_garde')) lead = "Intact mais solitaire, le siège demeure une tentation dont tu portes encore le poids.\n\n";
    return lead + base;
  }));

  // Aucun fond noir en NG+ : remplacement des visuels principaux par des CDN connus et fallback par acte.
  const V={NGP_01_SEUIL:'autel',NGP_02_NEUF_ECHOS:'memoire',NGP_03_PALAIS_ECHO:'memoire',NGP_04_FRESQUE_REPRISE:'gal',NGP_05_CONFRERIE:'bibli',NGP_06_DEUX_PORTES:'dome',NGP_07_KAELEN_ECHO:'mans',NGP_08_ALISTAIR_ECHO:'dome',NGP_09_DEUX_ECHOS:'trone',NGP_10_ORAYA:'forge',NGP_11_LYRA:'obs',NGP_12_FEN:'larmes',NGP_13_BRASIER:'chaos',NGP_14_TRONE_BRIS:'trone',NGP_15_DERNIER_CHOIX:'aube',NG_FIN_LIBERATION:'aube',NG_FIN_AMOUR:'serre',NG_FIN_DEUX_MAINS:'trone',NG_FIN_VIDE:'trone',NG_FIN_CYCLE:'autel',NG_FIN_FRONTIERE:'chaos'};
  Object.keys(V).forEach(id=>{if(NGPLUS_DB[id])NGPLUS_DB[id].image=bg(V[id]);});
  Object.keys(NGPLUS_DB).forEach(id=>{const s=NGPLUS_DB[id];if(s&&!s.image){const c=Number(s.chapter||1);s.image=bg(c===1?'memoire':c===2?'dome':c===3?'obs':c===4?'chaos':'aube');}});
}

// L'ultra NG+ est appliquée après la refonte existante, y compris ses 5 branches déjà ajoutées.
(function(){
  if(typeof applyRefonte_!=='function'||applyRefonte_._ngpu)return;
  const base=applyRefonte_;
  applyRefonte_=function(){base();applyNgPlusUltra_();};
  applyRefonte_._ngpu=true;
})();