STREET RUSH: MOBILE — Prototype 0.1

এটি একটি playable mini open-world browser game prototype, official GTA game নয়।

চালানোর সহজ উপায়:
1. ZIP extract করো।
2. app/src/main/assets/index.html ফাইলটি Android ফোনের Chrome-এ খোলো।
   যদি ফাইল ম্যানেজার থেকে না খোলে, HTML viewer/local web server app ব্যবহার করতে পারো।
3. START GAME চাপো।
4. স্ক্রিনের বাম দিকের বোতাম দিয়ে হাঁটা/গাড়ি চালাও।
5. গাড়ির কাছে গিয়ে ENTER CAR চাপো। হলুদ মার্কারে পৌঁছালে মিশন complete হবে।

PC controls: WASD/arrow keys, Shift = sprint, E = enter/exit car.

এটি প্রথম ছোট prototype: শহরে হাঁটা/গাড়ি, cash pickups, mission marker ও touch controls আছে।
এতে এখনো real 3D, guns, police AI, save system বা installable APK নেই।
