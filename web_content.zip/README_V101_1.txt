CryptoPulse V101.1
- Mobile pull-to-refresh gesture
- Animated CP refresh indicator
- Refresh reconnects shared LBank live hub and reloads current page
- Chart two-finger gesture is excluded from pull-to-refresh
