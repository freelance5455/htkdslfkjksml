# TKIC TV – THE KING IS COMING
Android starter project and browser prototype.

## Included
- `prototype/index.html`: interactive responsive prototype you can open in a modern browser.
- `prototype/tkic-tv-logo.png`: the uploaded channel logo.
- `android/TKICTV/`: Android Studio project source that loads the same interface in an Android WebView.
- Royal blue, white and gold branding.
- Home, Live TV, Videos (search), and About screens.
- Demo video playback using a public sample clip. The sample is NOT a TKIC TV sermon or broadcast.
- Live TV button opens the official TKIC TV YouTube Live page (`https://www.youtube.com/@tkictv/live`) in the YouTube app/browser.

## Preview the prototype
Open `prototype/index.html` in a browser. Keep `tkic-tv-logo.png` beside it.

## Build the Android app
1. Install Android Studio on a computer.
2. Open the `android/TKICTV` folder as an existing project.
3. Allow Gradle sync and install any SDK platform it requests (compile SDK 35).
4. Run on an Android device or emulator.
5. To create a release APK: Android Studio > Build > Generate Signed Bundle / APK. Create and safely store a signing key.

This is starter source, not a signed APK. An APK must be built and signed using Android build tools.

## Connect YouTube Live
1. The Live TV button is configured to open `https://www.youtube.com/@tkictv/live` in the YouTube app/browser.
2. In YouTube Studio, schedule a live stream or start one when you are ready to broadcast. The app cannot create or start the broadcast for you.
3. Test the button on an Android phone. If YouTube has no active or scheduled stream, viewers may see the channel page or a no-live message.
4. The recorded-video cards still contain demo titles and a public sample clip. Replace these with your official recordings and links before release.
5. If you later want the live stream to play inside the app, use an approved YouTube embedded player integration or a supported HLS playback provider; a channel URL is not itself a direct `.m3u8` stream.

## Before publishing
- Replace all sample/placeholder content and add official channel links and contact information.
- Add a privacy policy and a support contact.
- Test on multiple Android screen sizes and with slow connections.
- Create store icon, screenshots, feature graphic, app description and content rating.
- Create a Google Play Console developer account, follow current Play requirements, and upload a signed Android App Bundle (AAB). Store registration and publishing may require fees and verification.
- Check accessibility, permissions, copyright/streaming rights, and current Google Play policies.

## Important
No real TKIC TV live feed is included or claimed. The live stream and official recorded content must be supplied by the channel owner.
