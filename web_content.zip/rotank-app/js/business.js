/* ========= الوحدات التجارية المخصصة ========= */

/* ---------- لوحة التحكم ---------- */
async function renderDashboard(container) {
  const sales = await Store.all("salesInvoices");
  const expenses = await Store.all("expenses");
  const revenues = await Store.all("revenues");
  const items = await Store.all("items");
  const stocks = await computeAllStocks();
  const today = todayISO();
  const month = today.slice(0, 7);
  const year = today.slice(0, 4);

  function sumBy(list, pred, currency) {
    return list.filter(pred).reduce((s, i) => s + (i.currency === currency ? Number(i.total || i.amount || 0) : 0), 0);
  }
  const salesToday = { YER: sumBy(sales, s => s.date.slice(0,10)===today, "YER"), SAR: sumBy(sales, s => s.date.slice(0,10)===today, "SAR") };
  const salesMonth = { YER: sumBy(sales, s => s.date.slice(0,7)===month, "YER"), SAR: sumBy(sales, s => s.date.slice(0,7)===month, "SAR") };
  const salesYear = { YER: sumBy(sales, s => s.date.slice(0,4)===year, "YER"), SAR: sumBy(sales, s => s.date.slice(0,4)===year, "SAR") };

  const debtYER = sales.filter(s=>s.currency==="YER").reduce((s,i)=>s+Number(i.remaining||0),0);
  const debtSAR = sales.filter(s=>s.currency==="SAR").reduce((s,i)=>s+Number(i.remaining||0),0);

  const tanksCount = items.filter(i=>i.type==="tank").reduce((s,i)=> s + (stocks[i.id]||0), 0);
  const lowStockItems = items.filter(i => (stocks[i.id]||0) <= Number(i.minStock||0));

  container.innerHTML = `
    <div class="section-title"><h2>🏠 لوحة التحكم</h2></div>
    <div class="grid">
      <div class="stat"><div class="label">مبيعات اليوم (ريال يمني)</div><div class="value">${fmt(salesToday.YER)}</div></div>
      <div class="stat blue"><div class="label">مبيعات اليوم (ريال سعودي)</div><div class="value">${fmt(salesToday.SAR)}</div></div>
      <div class="stat dark"><div class="label">مبيعات الشهر (ي.ر / س.ر)</div><div class="value">${fmt(salesMonth.YER)} / ${fmt(salesMonth.SAR)}</div></div>
      <div class="stat dark"><div class="label">مبيعات السنة (ي.ر / س.ر)</div><div class="value">${fmt(salesYear.YER)} / ${fmt(salesYear.SAR)}</div></div>
      <div class="stat red"><div class="label">الديون (ريال يمني)</div><div class="value">${fmt(debtYER)}</div></div>
      <div class="stat red"><div class="label">الديون (ريال سعودي)</div><div class="value">${fmt(debtSAR)}</div></div>
      <div class="stat"><div class="label">عدد الخزانات بالمخزون</div><div class="value">${fmt(tanksCount)}</div></div>
      <div class="stat blue"><div class="label">إجمالي المصروفات (سجلات)</div><div class="value">${expenses.length}</div></div>
    </div>
    <div class="card">
      <div class="section-title"><h2>⚠️ تنبيهات المخزون المنخفض</h2></div>
      <table><thead><tr><th>الصنف</th><th>الرصيد الحالي</th><th>الحد الأدنى</th></tr></thead>
      <tbody>
        ${lowStockItems.length===0 ? '<tr><td colspan="3">لا توجد تنبيهات حاليًا</td></tr>' :
          lowStockItems.map(i=>`<tr class="low"><td>${escapeHtml(itemLabel(i))}</td><td>${fmt(stocks[i.id]||0)}</td><td>${fmt(i.minStock||0)}</td></tr>`).join("")}
      </tbody></table>
    </div>`;
}

/* ---------- الخزانات ---------- */
async function renderTanks(container) {
  const items = (await Store.all("items")).filter(i => i.type === "tank");
  const stocks = await computeAllStocks();
  const suppliers = await Store.all("suppliers");

  function formHtml(row) {
    row = row || {};
    return `<div class="card" id="tankForm">
      <div class="section-title"><h2>${row.id ? "تعديل" : "إضافة"} خزان</h2></div>
      <div class="form-grid">
        <div><label>الحجم (لتر) *</label>
          <select data-f="size">${TANK_SIZES.map(s=>`<option value="${s}" ${row.size==s?"selected":""}>${s}</option>`).join("")}</select>
        </div>
        <div><label>عدد الطبقات * (إلزامي)</label>
          <select data-f="layers">${TANK_LAYERS.map(l=>`<option value="${l.value}" ${row.layers==l.value?"selected":""}>${l.label}</option>`).join("")}</select>
        </div>
        <div><label>سعر الشراء</label><input data-f="purchasePrice" type="number" value="${row.purchasePrice||0}"/></div>
        <div><label>سعر البيع</label><input data-f="salePrice" type="number" value="${row.salePrice||0}"/></div>
        <div><label>الحد الأدنى للمخزون</label><input data-f="minStock" type="number" value="${row.minStock||0}"/></div>
        <div><label>المورد</label>
          <select data-f="supplierId"><option value="">-</option>${suppliers.map(s=>`<option value="${s.id}" ${row.supplierId===s.id?"selected":""}>${escapeHtml(s.name)}</option>`).join("")}</select>
        </div>
        <div style="grid-column:1/-1"><label>ملاحظات</label><textarea data-f="notes" rows="2">${escapeHtml(row.notes||"")}</textarea></div>
      </div>
      <div class="actions">
        <button class="btn" id="tankSave">💾 حفظ الخزان</button>
        <button class="btn gray" id="tankCancel">إلغاء</button>
      </div>
    </div>`;
  }

  function supplyFormHtml(item) {
    return `<div class="card" id="supplyForm">
      <div class="section-title"><h2>📥 تسجيل توريد: ${escapeHtml(itemLabel(item))}</h2></div>
      <div class="form-grid">
        <div><label>الكمية المستلمة *</label><input id="supQty" type="number" required/></div>
        <div><label>تاريخ الاستلام</label><input id="supDate" type="date" value="${todayISO()}"/></div>
        <div><label>رقم فاتورة التوريد</label><input id="supInvoice" type="text"/></div>
        <div><label>سعر الشراء لهذه الدفعة</label><input id="supPrice" type="number" value="${item.purchasePrice||0}"/></div>
      </div>
      <div class="actions">
        <button class="btn" id="supSave">💾 حفظ التوريد</button>
        <button class="btn gray" id="supCancel">إلغاء</button>
      </div>
    </div>`;
  }

  function paint() {
    container.innerHTML = `
      <div class="section-title"><h2>🛢️ إدارة الخزانات (حسب الحجم والطبقات)</h2>
        <button class="btn" id="addTankBtn">+ إضافة خزان جديد</button>
      </div>
      <div id="tankFormArea"></div>
      <div class="card">
        <table><thead><tr>
          <th>الحجم</th><th>الطبقات</th><th>الرصيد الحالي</th><th>سعر الشراء</th><th>سعر البيع</th><th>الحد الأدنى</th><th>إجراءات</th>
        </tr></thead>
        <tbody>
          ${items.length===0?'<tr><td colspan="7">لا توجد خزانات مسجلة</td></tr>':
          items.map(it=>{
            const stock = stocks[it.id]||0;
            const low = stock <= Number(it.minStock||0);
            const layerTxt = {"1":"طبقة واحدة","2":"طبقتين","3":"ثلاث طبقات"}[String(it.layers)];
            return `<tr class="${low?'low':''}">
              <td>${it.size} لتر</td><td>${layerTxt}</td><td>${fmt(stock)}</td>
              <td>${fmt(it.purchasePrice)}</td><td>${fmt(it.salePrice)}</td><td>${fmt(it.minStock)}</td>
              <td>
                <button class="btn sm" data-supply="${it.id}">📥 توريد</button>
                <button class="btn sm blue" data-edit="${it.id}">تعديل</button>
                <button class="btn sm red" data-del="${it.id}">حذف</button>
              </td>
            </tr>`;
          }).join("")}
        </tbody></table>
      </div>`;

    byId("addTankBtn").onclick = () => { byId("tankFormArea").innerHTML = formHtml({}); bindTankForm({}); };
    container.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>{
      const row = items.find(i=>i.id===b.dataset.edit);
      byId("tankFormArea").innerHTML = formHtml(row); bindTankForm(row);
    });
    container.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{
      if(!confirmAction("حذف هذا الخزان من القائمة؟ (لن تُحذف الحركات السابقة)")) return;
      await Store.remove("items", b.dataset.del);
      toast("تم الحذف"); renderTanks(container);
    });
    container.querySelectorAll("[data-supply]").forEach(b=>b.onclick=()=>{
      const item = items.find(i=>i.id===b.dataset.supply);
      byId("tankFormArea").innerHTML = supplyFormHtml(item);
      byId("supCancel").onclick = ()=>{byId("tankFormArea").innerHTML="";};
      byId("supSave").onclick = async ()=>{
        const qty = Number(byId("supQty").value);
        if(!qty || qty<=0){toast("أدخل كمية صحيحة","error");return;}
        await addMovement({
          itemId:item.id, direction:"increase", qty,
          date:new Date(byId("supDate").value||todayISO()).toISOString(),
          refType:"purchase_supply", unitPrice:Number(byId("supPrice").value||0),
          notes:"فاتورة توريد: "+(byId("supInvoice").value||"")
        });
        await logAudit("توريد خزانات", `${itemLabel(item)} × ${qty}`);
        toast("تم تسجيل التوريد"); renderTanks(container);
      };
    });
  }

  function bindTankForm(row) {
    byId("tankCancel").onclick = ()=>{byId("tankFormArea").innerHTML="";};
    byId("tankSave").onclick = async ()=>{
      const size = Number(document.querySelector('#tankForm [data-f="size"]').value);
      const layers = document.querySelector('#tankForm [data-f="layers"]').value;
      if(!size || !layers){ toast("الحجم وعدد الطبقات إلزاميان","error"); return; }
      const data = {
        ...row, type:"tank", size, layers,
        purchasePrice:Number(document.querySelector('#tankForm [data-f="purchasePrice"]').value||0),
        salePrice:Number(document.querySelector('#tankForm [data-f="salePrice"]').value||0),
        minStock:Number(document.querySelector('#tankForm [data-f="minStock"]').value||0),
        supplierId:document.querySelector('#tankForm [data-f="supplierId"]').value,
        notes:document.querySelector('#tankForm [data-f="notes"]').value
      };
      await Store.put("items", data);
      await logAudit(row.id?"تعديل خزان":"إضافة خزان", itemLabel(data));
      toast("تم الحفظ"); renderTanks(container);
    };
  }
  paint();
}

/* ---------- المنتجات البلاستيكية ---------- */
async function renderPlastic(container) {
  const items = (await Store.all("items")).filter(i=>i.type==="plastic");
  const stocks = await computeAllStocks();
  const suppliers = await Store.all("suppliers");

  function formHtml(row){
    row = row||{};
    return `<div class="card" id="plForm">
      <div class="section-title"><h2>${row.id?"تعديل":"إضافة"} منتج بلاستيكي</h2></div>
      <div class="form-grid">
        <div><label>اسم المنتج *</label><input data-f="name" value="${escapeHtml(row.name||"")}"/></div>
        <div><label>التصنيف</label><input data-f="category" value="${escapeHtml(row.category||"")}"/></div>
        <div><label>سعر الشراء</label><input data-f="purchasePrice" type="number" value="${row.purchasePrice||0}"/></div>
        <div><label>سعر البيع</label><input data-f="salePrice" type="number" value="${row.salePrice||0}"/></div>
        <div><label>الحد الأدنى للمخزون</label><input data-f="minStock" type="number" value="${row.minStock||0}"/></div>
        <div><label>المورد</label><select data-f="supplierId"><option value="">-</option>${suppliers.map(s=>`<option value="${s.id}" ${row.supplierId===s.id?"selected":""}>${escapeHtml(s.name)}</option>`).join("")}</select></div>
        <div><label>الكمية الابتدائية (عند الإضافة فقط)</label><input data-f="initQty" type="number" value="0"/></div>
        <div style="grid-column:1/-1"><label>ملاحظات</label><textarea data-f="notes">${escapeHtml(row.notes||"")}</textarea></div>
      </div>
      <div class="actions"><button class="btn" id="plSave">💾 حفظ</button><button class="btn gray" id="plCancel">إلغاء</button></div>
    </div>`;
  }
  function paint(){
    container.innerHTML = `
      <div class="section-title"><h2>📦 المنتجات البلاستيكية</h2><button class="btn" id="addPlBtn">+ إضافة منتج</button></div>
      <div id="plFormArea"></div>
      <div class="card"><table><thead><tr><th>المنتج</th><th>التصنيف</th><th>الرصيد</th><th>الشراء</th><th>البيع</th><th>إجراءات</th></tr></thead>
      <tbody>${items.length===0?'<tr><td colspan="6">لا توجد منتجات</td></tr>':items.map(it=>{
        const stock=stocks[it.id]||0; const low = stock<=Number(it.minStock||0);
        return `<tr class="${low?'low':''}"><td>${escapeHtml(it.name)}</td><td>${escapeHtml(it.category||"")}</td><td>${fmt(stock)}</td><td>${fmt(it.purchasePrice)}</td><td>${fmt(it.salePrice)}</td>
        <td><button class="btn sm blue" data-edit="${it.id}">تعديل</button> <button class="btn sm red" data-del="${it.id}">حذف</button></td></tr>`;
      }).join("")}</tbody></table></div>`;
    byId("addPlBtn").onclick=()=>{byId("plFormArea").innerHTML=formHtml({});bind({});};
    container.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>{
      const row=items.find(i=>i.id===b.dataset.edit); byId("plFormArea").innerHTML=formHtml(row); bind(row);
    });
    container.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{
      if(!confirmAction("حذف هذا المنتج؟"))return;
      await Store.remove("items", b.dataset.del); toast("تم الحذف"); renderPlastic(container);
    });
  }
  function bind(row){
    byId("plCancel").onclick=()=>{byId("plFormArea").innerHTML="";};
    byId("plSave").onclick=async()=>{
      const name=document.querySelector('#plForm [data-f="name"]').value;
      if(!name){toast("اسم المنتج إلزامي","error");return;}
      const data={...row,type:"plastic",name,
        category:document.querySelector('#plForm [data-f="category"]').value,
        purchasePrice:Number(document.querySelector('#plForm [data-f="purchasePrice"]').value||0),
        salePrice:Number(document.querySelector('#plForm [data-f="salePrice"]').value||0),
        minStock:Number(document.querySelector('#plForm [data-f="minStock"]').value||0),
        supplierId:document.querySelector('#plForm [data-f="supplierId"]').value,
        notes:document.querySelector('#plForm [data-f="notes"]').value};
      const saved = await Store.put("items", data);
      const initQty = Number(document.querySelector('#plForm [data-f="initQty"]').value||0);
      if(!row.id && initQty>0){
        await addMovement({itemId:saved.id,direction:"increase",qty:initQty,refType:"initial",notes:"رصيد ابتدائي"});
      }
      await logAudit(row.id?"تعديل منتج":"إضافة منتج", name);
      toast("تم الحفظ"); renderPlastic(container);
    };
  }
  paint();
}
