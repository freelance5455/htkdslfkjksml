/* ========= المبيعات ========= */
async function renderSales(container) {
  const invoices = (await Store.all("salesInvoices")).sort((a,b)=>b.date.localeCompare(a.date));
  const customers = await Store.all("customers");
  const items = await Store.all("items");
  const settings = (await Store.all("settings"))[0] || {};
  let lines = [];

  function itemOptions() {
    return items.map(i=>`<option value="${i.id}">${escapeHtml(itemLabel(i))} (بيع:${fmt(i.salePrice)})</option>`).join("");
  }

  function formHtml(){
    return `<div class="card" id="saleForm">
      <div class="section-title"><h2>🧾 فاتورة بيع جديدة</h2></div>
      <div class="form-grid">
        <div><label>العميل *</label><select id="saleCustomer"><option value="">-- اختر عميل --</option>${customers.map(c=>`<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("")}</select></div>
        <div><label>العملة *</label><select id="saleCurrency"><option value="YER">ريال يمني</option><option value="SAR">ريال سعودي</option></select></div>
        <div><label>نوع البيع *</label><select id="saleType"><option value="cash">نقدي</option><option value="credit">آجل</option></select></div>
        <div><label>تاريخ الفاتورة</label><input id="saleDate" type="date" value="${todayISO()}"/></div>
      </div>
      <table class="invoice-lines" id="linesTable">
        <thead><tr><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الخصم</th><th>الإجمالي</th><th></th></tr></thead>
        <tbody id="linesBody"></tbody>
      </table>
      <button class="btn sm" id="addLineBtn">+ إضافة سطر</button>
      <div class="form-grid" style="margin-top:12px">
        <div><label>الإجمالي</label><input id="saleTotal" disabled/></div>
        <div><label>المدفوع</label><input id="salePaid" type="number" value="0"/></div>
        <div><label>المتبقي</label><input id="saleRemaining" disabled/></div>
      </div>
      <div class="actions">
        <button class="btn" id="saleSave">💾 حفظ وطباعة الفاتورة</button>
        <button class="btn gray" id="saleCancel">إلغاء</button>
      </div>
    </div>`;
  }

  function lineRow(idx){
    return `<tr data-idx="${idx}">
      <td><select class="lnItem">${itemOptions()}</select></td>
      <td><input class="lnQty" type="number" value="1" style="width:70px"/></td>
      <td><input class="lnPrice" type="number" value="0" style="width:90px"/></td>
      <td><input class="lnDiscount" type="number" value="0" style="width:70px"/></td>
      <td class="lnTotal">0</td>
      <td><button class="btn sm red" onclick="this.closest('tr').remove(); recalcSale();">×</button></td>
    </tr>`;
  }

  window.recalcSale = function(){
    let total = 0;
    document.querySelectorAll("#linesBody tr").forEach(tr=>{
      const qty = Number(tr.querySelector(".lnQty").value||0);
      const price = Number(tr.querySelector(".lnPrice").value||0);
      const disc = Number(tr.querySelector(".lnDiscount").value||0);
      const t = qty*price - disc;
      tr.querySelector(".lnTotal").textContent = fmt(t);
      total += t;
    });
    byId("saleTotal").value = fmt(total);
    const paid = Number(byId("salePaid").value||0);
    byId("saleRemaining").value = fmt(total - paid);
    return total;
  };

  function paint(){
    container.innerHTML = `
      <div class="section-title"><h2>🧾 المبيعات</h2><button class="btn" id="newSaleBtn">+ فاتورة بيع جديدة</button></div>
      <div id="saleFormArea"></div>
      <div class="card"><table><thead><tr><th>رقم الفاتورة</th><th>التاريخ</th><th>العميل</th><th>العملة</th><th>الإجمالي</th><th>المتبقي</th><th>إجراءات</th></tr></thead>
      <tbody>${invoices.length===0?'<tr><td colspan="7">لا توجد فواتير</td></tr>':invoices.map(inv=>{
        const cust = customers.find(c=>c.id===inv.customerId);
        return `<tr><td>${inv.invoiceNo}</td><td>${inv.date.slice(0,10)}</td><td>${escapeHtml(cust?cust.name:"-")}</td>
        <td>${currencyLabel(inv.currency)}</td><td>${fmt(inv.total)}</td><td>${fmt(inv.remaining)}</td>
        <td><button class="btn sm" onclick="printInvoice('${inv.id}')">🖨️ طباعة</button> <button class="btn sm red" data-del="${inv.id}">حذف</button></td></tr>`;
      }).join("")}</tbody></table></div>`;
    byId("newSaleBtn").onclick=()=>{
      lines=[]; byId("saleFormArea").innerHTML = formHtml();
      byId("linesBody").innerHTML = lineRow(0);
      byId("addLineBtn").onclick=()=>{ byId("linesBody").insertAdjacentHTML("beforeend", lineRow(Date.now())); bindLineEvents(); };
      bindLineEvents();
      byId("salePaid").oninput = recalcSale;
      byId("saleCancel").onclick=()=>{byId("saleFormArea").innerHTML="";};
      byId("saleSave").onclick = saveSale;
      recalcSale();
    };
    container.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{
      if(!confirmAction("حذف الفاتورة؟ سيتم عكس حركة المخزون المرتبطة."))return;
      const inv = invoices.find(i=>i.id===b.dataset.del);
      const moves = (await Store.all("movements")).filter(m=>m.refId===inv.id);
      for(const m of moves) await Store.remove("movements", m.id);
      await Store.remove("salesInvoices", inv.id);
      await logAudit("حذف فاتورة بيع", inv.invoiceNo);
      toast("تم حذف الفاتورة"); renderSales(container);
    });
  }

  function bindLineEvents(){
    document.querySelectorAll("#linesBody tr").forEach(tr=>{
      tr.querySelector(".lnItem").onchange = (e)=>{
        const item = items.find(i=>i.id===e.target.value);
        if(item) tr.querySelector(".lnPrice").value = item.salePrice||0;
        recalcSale();
      };
      ["lnQty","lnPrice","lnDiscount"].forEach(cls=>{
        tr.querySelector("."+cls).oninput = recalcSale;
      });
    });
    // trigger initial price fill
    document.querySelectorAll("#linesBody tr").forEach(tr=>{
      const item = items.find(i=>i.id===tr.querySelector(".lnItem").value);
      if(item) tr.querySelector(".lnPrice").value = item.salePrice||0;
    });
    recalcSale();
  }

  async function saveSale(){
    const customerId = byId("saleCustomer").value;
    const saleType = byId("saleType").value;
    if(!customerId){toast("اختيار العميل إلزامي","error");return;}
    const currency = byId("saleCurrency").value;
    const total = recalcSale();
    const paid = Number(byId("salePaid").value||0);
    const remaining = total - paid;
    const rows = [...document.querySelectorAll("#linesBody tr")].map(tr=>({
      itemId: tr.querySelector(".lnItem").value,
      qty: Number(tr.querySelector(".lnQty").value||0),
      price: Number(tr.querySelector(".lnPrice").value||0),
      discount: Number(tr.querySelector(".lnDiscount").value||0)
    })).filter(r=>r.qty>0);
    if(rows.length===0){toast("أضف سطرًا واحدًا على الأقل","error");return;}
    const invoiceNo = await nextInvoiceNo(settings.invoicePrefix);
    const invoice = {
      id: uid(), invoiceNo, date: new Date(byId("saleDate").value||todayISO()).toISOString(),
      customerId, currency, saleType, items: rows, total, paid, remaining
    };
    await Store.put("salesInvoices", invoice);
    for(const r of rows){
      await addMovement({itemId:r.itemId, direction:"decrease", qty:r.qty, refType:"sale", refId:invoice.id, unitPrice:r.price});
    }
    await logAudit("فاتورة بيع", invoiceNo);
    toast("تم حفظ الفاتورة");
    renderSales(container);
    setTimeout(()=>printInvoice(invoice.id), 300);
  }
  paint();
}

async function printInvoice(id){
  const inv = await Store.get("salesInvoices", id);
  const customers = await Store.all("customers");
  const items = await Store.all("items");
  const settings = (await Store.all("settings"))[0]||{};
  const cust = customers.find(c=>c.id===inv.customerId);
  const win = window.open("", "_blank");
  win.document.write(`
    <html dir="rtl"><head><meta charset="utf-8"><title>فاتورة ${inv.invoiceNo}</title>
    <style>body{font-family:Arial;padding:20px} table{width:100%;border-collapse:collapse} td,th{border:1px solid #333;padding:6px;text-align:right}
    h2{color:#0b3d24}</style></head><body>
    <h2>${escapeHtml(settings.shopName||"")} - ${escapeHtml(settings.agentName||"")} - ${escapeHtml(settings.branch||"")}</h2>
    <p>رقم الفاتورة: ${inv.invoiceNo} | التاريخ: ${inv.date.slice(0,10)} | العميل: ${escapeHtml(cust?cust.name:"-")}</p>
    <table><thead><tr><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الخصم</th><th>الإجمالي</th></tr></thead>
    <tbody>${inv.items.map(r=>{
      const it = items.find(i=>i.id===r.itemId);
      return `<tr><td>${escapeHtml(itemLabel(it))}</td><td>${r.qty}</td><td>${fmt(r.price)}</td><td>${fmt(r.discount)}</td><td>${fmt(r.qty*r.price-r.discount)}</td></tr>`;
    }).join("")}</tbody></table>
    <p>الإجمالي: ${fmt(inv.total)} ${currencyLabel(inv.currency)} | المدفوع: ${fmt(inv.paid)} | المتبقي: ${fmt(inv.remaining)}</p>
    <script>window.print()</script>
    </body></html>`);
}

/* ========= المشتريات النقدية ========= */
async function renderPurchases(container) {
  const purchases = (await Store.all("purchases")).sort((a,b)=>b.date.localeCompare(a.date));
  const suppliers = await Store.all("suppliers");
  const items = await Store.all("items");

  function formHtml(){
    return `<div class="card" id="purForm">
      <div class="section-title"><h2>🛒 تسجيل مشترى نقدي</h2></div>
      <div class="form-grid">
        <div><label>المورد *</label><select id="purSupplier"><option value="">-</option>${suppliers.map(s=>`<option value="${s.id}">${escapeHtml(s.name)}</option>`).join("")}</select></div>
        <div><label>الصنف *</label><select id="purItem"><option value="">-</option>${items.map(i=>`<option value="${i.id}">${escapeHtml(itemLabel(i))}</option>`).join("")}</select></div>
        <div><label>الكمية *</label><input id="purQty" type="number"/></div>
        <div><label>سعر الشراء *</label><input id="purPrice" type="number"/></div>
        <div><label>طريقة الدفع</label><select id="purPayMethod"><option value="نقدي">نقدي</option><option value="تحويل">تحويل</option></select></div>
        <div><label>رقم الفاتورة</label><input id="purInvoice"/></div>
        <div><label>التاريخ</label><input id="purDate" type="date" value="${todayISO()}"/></div>
      </div>
      <div class="actions"><button class="btn" id="purSave">💾 حفظ</button><button class="btn gray" id="purCancel">إلغاء</button></div>
    </div>`;
  }
  function paint(){
    container.innerHTML = `<div class="section-title"><h2>🛒 المشتريات النقدية</h2><button class="btn" id="newPurBtn">+ مشترى جديد</button></div>
    <div id="purFormArea"></div>
    <div class="card"><table><thead><tr><th>التاريخ</th><th>المورد</th><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th><th>رقم الفاتورة</th><th></th></tr></thead>
    <tbody>${purchases.length===0?'<tr><td colspan="8">لا توجد مشتريات</td></tr>':purchases.map(p=>{
      const s=suppliers.find(x=>x.id===p.supplierId); const it=items.find(x=>x.id===p.itemId);
      return `<tr><td>${p.date.slice(0,10)}</td><td>${escapeHtml(s?s.name:"-")}</td><td>${escapeHtml(itemLabel(it))}</td><td>${p.qty}</td><td>${fmt(p.price)}</td><td>${fmt(p.qty*p.price)}</td><td>${escapeHtml(p.invoiceNo||"")}</td>
      <td><button class="btn sm red" data-del="${p.id}">حذف</button></td></tr>`;
    }).join("")}</tbody></table></div>`;
    byId("newPurBtn").onclick=()=>{byId("purFormArea").innerHTML=formHtml();
      byId("purCancel").onclick=()=>{byId("purFormArea").innerHTML="";};
      byId("purSave").onclick=async()=>{
        const supplierId=byId("purSupplier").value, itemId=byId("purItem").value;
        const qty=Number(byId("purQty").value||0), price=Number(byId("purPrice").value||0);
        if(!supplierId||!itemId||!qty){toast("المورد والصنف والكمية إلزامية","error");return;}
        const p={id:uid(),date:new Date(byId("purDate").value||todayISO()).toISOString(),supplierId,itemId,qty,price,
          paymentMethod:byId("purPayMethod").value, invoiceNo:byId("purInvoice").value};
        await Store.put("purchases", p);
        await addMovement({itemId, direction:"increase", qty, refType:"purchase", refId:p.id, unitPrice:price});
        await logAudit("مشترى نقدي", itemLabel(items.find(i=>i.id===itemId)));
        toast("تم الحفظ"); renderPurchases(container);
      };
    };
    container.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{
      if(!confirmAction("حذف هذا المشترى؟"))return;
      const moves=(await Store.all("movements")).filter(m=>m.refId===b.dataset.del);
      for(const m of moves) await Store.remove("movements", m.id);
      await Store.remove("purchases", b.dataset.del);
      toast("تم الحذف"); renderPurchases(container);
    });
  }
  paint();
}

/* ========= المرتجعات ========= */
async function renderReturns(container) {
  const returns = (await Store.all("returns")).sort((a,b)=>b.date.localeCompare(a.date));
  const items = await Store.all("items");
  const sales = await Store.all("salesInvoices");
  const purchases = await Store.all("purchases");

  function formHtml(){
    return `<div class="card" id="retForm">
      <div class="section-title"><h2>🔄 تسجيل مرتجع</h2></div>
      <div class="form-grid">
        <div><label>نوع المرتجع *</label><select id="retType"><option value="sale">مرتجع مبيعات</option><option value="purchase">مرتجع مشتريات</option></select></div>
        <div><label>الصنف *</label><select id="retItem">${items.map(i=>`<option value="${i.id}">${escapeHtml(itemLabel(i))}</option>`).join("")}</select></div>
        <div><label>الكمية المرتجعة *</label><input id="retQty" type="number"/></div>
        <div><label>القيمة</label><input id="retValue" type="number"/></div>
        <div><label>الفاتورة الأصلية (اختياري)</label><input id="retOrigInvoice" placeholder="رقم الفاتورة"/></div>
        <div><label>التاريخ</label><input id="retDate" type="date" value="${todayISO()}"/></div>
      </div>
      <div class="actions"><button class="btn" id="retSave">💾 حفظ</button><button class="btn gray" id="retCancel">إلغاء</button></div>
    </div>`;
  }
  function paint(){
    container.innerHTML = `<div class="section-title"><h2>🔄 المرتجعات</h2><button class="btn" id="newRetBtn">+ مرتجع جديد</button></div>
    <div id="retFormArea"></div>
    <div class="card"><table><thead><tr><th>التاريخ</th><th>النوع</th><th>الصنف</th><th>الكمية</th><th>القيمة</th><th>الفاتورة الأصلية</th><th></th></tr></thead>
    <tbody>${returns.length===0?'<tr><td colspan="7">لا توجد مرتجعات</td></tr>':returns.map(r=>{
      const it=items.find(x=>x.id===r.itemId);
      return `<tr><td>${r.date.slice(0,10)}</td><td>${r.type==="sale"?"مبيعات":"مشتريات"}</td><td>${escapeHtml(itemLabel(it))}</td><td>${r.qty}</td><td>${fmt(r.value)}</td><td>${escapeHtml(r.origInvoice||"")}</td>
      <td><button class="btn sm red" data-del="${r.id}">حذف</button></td></tr>`;
    }).join("")}</tbody></table></div>`;
    byId("newRetBtn").onclick=()=>{byId("retFormArea").innerHTML=formHtml();
      byId("retCancel").onclick=()=>{byId("retFormArea").innerHTML="";};
      byId("retSave").onclick=async()=>{
        const type=byId("retType").value, itemId=byId("retItem").value, qty=Number(byId("retQty").value||0);
        if(!qty){toast("الكمية إلزامية","error");return;}
        const r={id:uid(), type, itemId, qty, value:Number(byId("retValue").value||0),
          origInvoice:byId("retOrigInvoice").value, date:new Date(byId("retDate").value||todayISO()).toISOString()};
        await Store.put("returns", r);
        // مرتجع مبيعات = يزيد المخزون (رجع للمحل) / مرتجع مشتريات = ينقص المخزون (رجع للمورد)
        await addMovement({itemId, direction: type==="sale"?"increase":"decrease", qty, refType:"return_"+type, refId:r.id});
        await logAudit("مرتجع", `${type==="sale"?"مبيعات":"مشتريات"}: ${itemLabel(items.find(i=>i.id===itemId))}`);
        toast("تم الحفظ"); renderReturns(container);
      };
    };
    container.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{
      if(!confirmAction("حذف هذا المرتجع؟"))return;
      const moves=(await Store.all("movements")).filter(m=>m.refId===b.dataset.del);
      for(const m of moves) await Store.remove("movements", m.id);
      await Store.remove("returns", b.dataset.del);
      toast("تم الحذف"); renderReturns(container);
    });
  }
  paint();
}
