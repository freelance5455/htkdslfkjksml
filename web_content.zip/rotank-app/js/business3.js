/* ========= العملاء والديون ========= */
async function renderCustomersDebts(container) {
  const customers = await Store.all("customers");
  const sales = await Store.all("salesInvoices");
  const payments = await Store.all("debtPayments");

  function ledgerFor(custId){
    const s = sales.filter(i=>i.customerId===custId);
    const p = payments.filter(i=>i.customerId===custId);
    const balYER = s.filter(i=>i.currency==="YER").reduce((a,i)=>a+Number(i.remaining||0),0) - p.filter(i=>i.currency==="YER").reduce((a,i)=>a+Number(i.amount||0),0);
    const balSAR = s.filter(i=>i.currency==="SAR").reduce((a,i)=>a+Number(i.remaining||0),0) - p.filter(i=>i.currency==="SAR").reduce((a,i)=>a+Number(i.amount||0),0);
    return {balYER, balSAR, sales:s, payments:p};
  }

  function custFormHtml(row){
    row = row||{};
    return `<div class="card" id="custForm"><div class="section-title"><h2>${row.id?"تعديل":"إضافة"} عميل</h2></div>
    <div class="form-grid">
      <div><label>الاسم *</label><input data-f="name" value="${escapeHtml(row.name||"")}"/></div>
      <div><label>الهاتف</label><input data-f="phone" value="${escapeHtml(row.phone||"")}"/></div>
      <div><label>العنوان</label><input data-f="address" value="${escapeHtml(row.address||"")}"/></div>
      <div style="grid-column:1/-1"><label>ملاحظات</label><textarea data-f="notes">${escapeHtml(row.notes||"")}</textarea></div>
    </div>
    <div class="actions"><button class="btn" id="custSave">💾 حفظ</button><button class="btn gray" id="custCancel">إلغاء</button></div></div>`;
  }

  function detailHtml(cust){
    const L = ledgerFor(cust.id);
    return `<div class="card">
      <div class="section-title"><h2>📄 كشف حساب: ${escapeHtml(cust.name)}</h2>
      <div><button class="btn sm" onclick="window.print()">🖨️ طباعة</button> <button class="btn sm gray" id="closeDetail">إغلاق</button></div></div>
      <p>الرصيد المتبقي: <b>${fmt(L.balYER)}</b> ريال يمني | <b>${fmt(L.balSAR)}</b> ريال سعودي</p>
      <h4>الفواتير</h4>
      <table><thead><tr><th>رقم الفاتورة</th><th>التاريخ</th><th>العملة</th><th>الإجمالي</th><th>المدفوع</th><th>المتبقي</th></tr></thead>
      <tbody>${L.sales.map(s=>`<tr><td>${s.invoiceNo}</td><td>${s.date.slice(0,10)}</td><td>${currencyLabel(s.currency)}</td><td>${fmt(s.total)}</td><td>${fmt(s.paid)}</td><td>${fmt(s.remaining)}</td></tr>`).join("")||'<tr><td colspan="6">لا توجد فواتير</td></tr>'}</tbody></table>
      <h4>سجل السداد</h4>
      <table><thead><tr><th>التاريخ</th><th>العملة</th><th>المبلغ</th><th>ملاحظات</th><th></th></tr></thead>
      <tbody>${L.payments.map(p=>`<tr><td>${p.date.slice(0,10)}</td><td>${currencyLabel(p.currency)}</td><td>${fmt(p.amount)}</td><td>${escapeHtml(p.notes||"")}</td><td><button class="btn sm red" data-delpay="${p.id}">حذف</button></td></tr>`).join("")||'<tr><td colspan="5">لا يوجد سداد</td></tr>'}</tbody></table>
      <div class="card">
        <div class="section-title"><h2>💰 تسجيل سداد جديد</h2></div>
        <div class="form-grid">
          <div><label>العملة</label><select id="payCurrency"><option value="YER">ريال يمني</option><option value="SAR">ريال سعودي</option></select></div>
          <div><label>المبلغ</label><input id="payAmount" type="number"/></div>
          <div><label>ملاحظات</label><input id="payNotes"/></div>
        </div>
        <button class="btn" id="paySave">💾 حفظ السداد</button>
      </div>
    </div>`;
  }

  function paint(){
    container.innerHTML = `<div class="section-title"><h2>👥 العملاء والديون</h2><button class="btn" id="addCustBtn">+ إضافة عميل</button></div>
    <div id="custFormArea"></div>
    <div class="card"><table><thead><tr><th>الاسم</th><th>الهاتف</th><th>الرصيد ي.ر</th><th>الرصيد س.ر</th><th>إجراءات</th></tr></thead>
    <tbody>${customers.length===0?'<tr><td colspan="5">لا يوجد عملاء</td></tr>':customers.map(c=>{
      const L=ledgerFor(c.id);
      return `<tr><td>${escapeHtml(c.name)}</td><td>${escapeHtml(c.phone||"")}</td><td>${fmt(L.balYER)}</td><td>${fmt(L.balSAR)}</td>
      <td><button class="btn sm" data-view="${c.id}">كشف حساب</button> <button class="btn sm blue" data-edit="${c.id}">تعديل</button> <button class="btn sm red" data-del="${c.id}">حذف</button></td></tr>`;
    }).join("")}</tbody></table></div>`;
    byId("addCustBtn").onclick=()=>{byId("custFormArea").innerHTML=custFormHtml({});bindCustForm({});};
    container.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>{
      const row=customers.find(c=>c.id===b.dataset.edit); byId("custFormArea").innerHTML=custFormHtml(row); bindCustForm(row);
    });
    container.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{
      if(!confirmAction("حذف هذا العميل؟"))return;
      await Store.remove("customers", b.dataset.del); toast("تم الحذف"); renderCustomersDebts(container);
    });
    container.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>{
      const cust=customers.find(c=>c.id===b.dataset.view);
      byId("custFormArea").innerHTML = detailHtml(cust);
      byId("closeDetail").onclick=()=>{byId("custFormArea").innerHTML="";};
      container.querySelectorAll("[data-delpay]").forEach(pb=>pb.onclick=async()=>{
        if(!confirmAction("حذف سجل السداد؟"))return;
        await Store.remove("debtPayments", pb.dataset.delpay);
        toast("تم الحذف"); renderCustomersDebts(container);
      });
      byId("paySave").onclick=async()=>{
        const amount=Number(byId("payAmount").value||0);
        if(!amount){toast("أدخل مبلغًا صحيحًا","error");return;}
        await Store.put("debtPayments",{id:uid(),customerId:cust.id,date:new Date().toISOString(),
          currency:byId("payCurrency").value, amount, notes:byId("payNotes").value});
        await logAudit("سداد دين", cust.name+" - "+amount);
        toast("تم تسجيل السداد"); renderCustomersDebts(container);
      };
    });
  }
  function bindCustForm(row){
    byId("custCancel").onclick=()=>{byId("custFormArea").innerHTML="";};
    byId("custSave").onclick=async()=>{
      const name=document.querySelector('#custForm [data-f="name"]').value;
      if(!name){toast("الاسم إلزامي","error");return;}
      const data={...row,name,
        phone:document.querySelector('#custForm [data-f="phone"]').value,
        address:document.querySelector('#custForm [data-f="address"]').value,
        notes:document.querySelector('#custForm [data-f="notes"]').value};
      await Store.put("customers", data);
      toast("تم الحفظ"); renderCustomersDebts(container);
    };
  }
  paint();
}

/* ========= المصروفات والإيرادات ========= */
const EXPENSE_CATS = ["إيجار","نقل","تحميل وتنزيل","وقود","رواتب","صيانة","مصروفات أخرى"];
const REVENUE_CATS = ["إيرادات أخرى"];

async function renderExpenses(container){
  await renderCrud(container, {
    store:"expenses", title:"مصروف", icon:"💵",
    fields:[
      {key:"category",label:"البند",type:"select",options:EXPENSE_CATS.map(c=>({value:c,label:c})),required:true},
      {key:"amount",label:"المبلغ",type:"number",required:true},
      {key:"currency",label:"العملة",type:"select",options:[{value:"YER",label:"ريال يمني"},{value:"SAR",label:"ريال سعودي"}],required:true},
      {key:"date",label:"التاريخ",type:"date",required:true},
      {key:"notes",label:"ملاحظات",type:"textarea"}
    ]
  });
}
async function renderRevenues(container){
  await renderCrud(container, {
    store:"revenues", title:"إيراد", icon:"💰",
    fields:[
      {key:"category",label:"البند",type:"text",required:true},
      {key:"amount",label:"المبلغ",type:"number",required:true},
      {key:"currency",label:"العملة",type:"select",options:[{value:"YER",label:"ريال يمني"},{value:"SAR",label:"ريال سعودي"}],required:true},
      {key:"date",label:"التاريخ",type:"date",required:true},
      {key:"notes",label:"ملاحظات",type:"textarea"}
    ]
  });
}

async function renderSuppliers(container){
  await renderCrud(container, {
    store:"suppliers", title:"مورد", icon:"🚚",
    fields:[
      {key:"name",label:"الاسم",type:"text",required:true},
      {key:"phone",label:"الهاتف",type:"text"},
      {key:"address",label:"العنوان",type:"text"},
      {key:"notes",label:"ملاحظات",type:"textarea"}
    ]
  });
}

async function renderNotes(container){
  await renderCrud(container, {
    store:"notes", title:"ملاحظة", icon:"📝",
    fields:[
      {key:"category",label:"النوع",type:"select",options:[
        {value:"مورد",label:"ملاحظة مورد"},{value:"عميل",label:"ملاحظة عميل"},
        {value:"خزان",label:"ملاحظة خزان"},{value:"مبيعات",label:"ملاحظة مبيعات"},{value:"عام",label:"ملاحظة عامة"}
      ],required:true},
      {key:"relatedTo",label:"مرتبطة بـ (اسم/رقم فاتورة اختياري)",type:"text"},
      {key:"date",label:"التاريخ",type:"date",required:true},
      {key:"text",label:"نص الملاحظة",type:"textarea",required:true}
    ]
  });
}

/* ========= المخزون ========= */
async function renderInventory(container) {
  const items = await Store.all("items");
  const stocks = await computeAllStocks();
  const movements = await Store.all("movements");

  function damageFormHtml(item){
    return `<div class="card" id="dmgForm"><div class="section-title"><h2>تسجيل تالف: ${escapeHtml(itemLabel(item))}</h2></div>
    <div class="form-grid"><div><label>الكمية التالفة</label><input id="dmgQty" type="number"/></div>
    <div><label>ملاحظات</label><input id="dmgNotes"/></div></div>
    <div class="actions"><button class="btn red" id="dmgSave">تسجيل التالف</button><button class="btn gray" id="dmgCancel">إلغاء</button></div></div>`;
  }

  function paint(){
    container.innerHTML = `<div class="section-title"><h2>📦 المخزون (محسوب تلقائيًا)</h2></div>
    <div id="invFormArea"></div>
    <div class="card"><table><thead><tr><th>الصنف</th><th>الوارد</th><th>المباع</th><th>المرتجع</th><th>التالف</th><th>الرصيد الحالي</th><th></th></tr></thead>
    <tbody>${items.map(it=>{
      const moves = movements.filter(m=>m.itemId===it.id);
      const inn = moves.filter(m=>m.refType==="purchase"||m.refType==="purchase_supply"||m.refType==="initial").reduce((s,m)=>s+m.qty,0);
      const sold = moves.filter(m=>m.refType==="sale").reduce((s,m)=>s+m.qty,0);
      const ret = moves.filter(m=>m.refType&&m.refType.startsWith("return")).reduce((s,m)=>s+(m.direction==="increase"?m.qty:-m.qty),0);
      const dmg = moves.filter(m=>m.refType==="damage").reduce((s,m)=>s+m.qty,0);
      const stock = stocks[it.id]||0; const low = stock<=Number(it.minStock||0);
      return `<tr class="${low?'low':''}"><td>${escapeHtml(itemLabel(it))}</td><td>${fmt(inn)}</td><td>${fmt(sold)}</td><td>${fmt(ret)}</td><td>${fmt(dmg)}</td><td><b>${fmt(stock)}</b></td>
      <td><button class="btn sm red" data-dmg="${it.id}">تسجيل تالف</button></td></tr>`;
    }).join("")}</tbody></table></div>`;
    container.querySelectorAll("[data-dmg]").forEach(b=>b.onclick=()=>{
      const item = items.find(i=>i.id===b.dataset.dmg);
      byId("invFormArea").innerHTML = damageFormHtml(item);
      byId("dmgCancel").onclick=()=>{byId("invFormArea").innerHTML="";};
      byId("dmgSave").onclick=async()=>{
        const qty=Number(byId("dmgQty").value||0);
        if(!qty){toast("أدخل كمية صحيحة","error");return;}
        await addMovement({itemId:item.id, direction:"decrease", qty, refType:"damage", notes:byId("dmgNotes").value});
        await logAudit("تسجيل تالف", itemLabel(item)+" × "+qty);
        toast("تم التسجيل"); renderInventory(container);
      };
    });
  }
  paint();
}

/* ========= التقارير ========= */
async function renderReports(container) {
  const sales = await Store.all("salesInvoices");
  const purchases = await Store.all("purchases");
  const expenses = await Store.all("expenses");
  const revenues = await Store.all("revenues");
  const items = await Store.all("items");
  const movements = await Store.all("movements");

  function sumByMonthCurrency(list, dateField="date"){
    const map={};
    list.forEach(r=>{
      const m = (r[dateField]||"").slice(0,7);
      const cur = r.currency||"YER";
      map[m]=map[m]||{YER:0,SAR:0};
      map[m][cur]+= Number(r.total||r.amount||(r.qty*r.price)||0);
    });
    return map;
  }
  const salesByMonth = sumByMonthCurrency(sales);
  const expByMonth = sumByMonthCurrency(expenses);

  const tankSalesCount = {};
  movements.filter(m=>m.refType==="sale").forEach(m=>{
    const it = items.find(i=>i.id===m.itemId);
    if(it && it.type==="tank"){
      const key = `${it.size} لتر - ${({"1":"طبقة واحدة","2":"طبقتين","3":"ثلاث طبقات"})[String(it.layers)]}`;
      tankSalesCount[key]=(tankSalesCount[key]||0)+m.qty;
    }
  });
  const topTanks = Object.entries(tankSalesCount).sort((a,b)=>b[1]-a[1]).slice(0,10);

  const debtYER = sales.filter(s=>s.currency==="YER").reduce((a,i)=>a+Number(i.remaining||0),0);
  const debtSAR = sales.filter(s=>s.currency==="SAR").reduce((a,i)=>a+Number(i.remaining||0),0);
  const totalPurchases = purchases.reduce((a,p)=>a+p.qty*p.price,0);
  const totalExpenses = expenses.reduce((a,e)=>a+Number(e.amount||0),0);
  const totalRevenues = revenues.reduce((a,e)=>a+Number(e.amount||0),0);
  const totalSalesYER = sales.filter(s=>s.currency==="YER").reduce((a,i)=>a+Number(i.total||0),0);
  const totalSalesSAR = sales.filter(s=>s.currency==="SAR").reduce((a,i)=>a+Number(i.total||0),0);

  container.innerHTML = `
    <div class="section-title"><h2>📊 التقارير والإحصائيات</h2></div>
    <div class="grid">
      <div class="stat"><div class="label">إجمالي المبيعات (ي.ر)</div><div class="value">${fmt(totalSalesYER)}</div></div>
      <div class="stat blue"><div class="label">إجمالي المبيعات (س.ر)</div><div class="value">${fmt(totalSalesSAR)}</div></div>
      <div class="stat dark"><div class="label">إجمالي المشتريات</div><div class="value">${fmt(totalPurchases)}</div></div>
      <div class="stat red"><div class="label">إجمالي الديون (ي.ر/س.ر)</div><div class="value">${fmt(debtYER)} / ${fmt(debtSAR)}</div></div>
      <div class="stat"><div class="label">إجمالي المصروفات</div><div class="value">${fmt(totalExpenses)}</div></div>
      <div class="stat blue"><div class="label">إجمالي الإيرادات الأخرى</div><div class="value">${fmt(totalRevenues)}</div></div>
    </div>
    <div class="card"><h3>مقارنة المبيعات الشهرية</h3>
    <table><thead><tr><th>الشهر</th><th>ريال يمني</th><th>ريال سعودي</th></tr></thead>
    <tbody>${Object.entries(salesByMonth).sort((a,b)=>b[0].localeCompare(a[0])).map(([m,v])=>`<tr><td>${m}</td><td>${fmt(v.YER)}</td><td>${fmt(v.SAR)}</td></tr>`).join("")||'<tr><td colspan="3">لا توجد بيانات</td></tr>'}</tbody></table></div>
    <div class="card"><h3>🏆 أكثر أحجام/طبقات الخزانات مبيعًا</h3>
    <table><thead><tr><th>الصنف</th><th>الكمية المباعة</th></tr></thead>
    <tbody>${topTanks.map(([k,v])=>`<tr><td>${escapeHtml(k)}</td><td>${fmt(v)}</td></tr>`).join("")||'<tr><td colspan="2">لا توجد بيانات</td></tr>'}</tbody></table></div>
  `;
}

/* ========= النسخ الاحتياطي ========= */
async function renderBackup(container) {
  container.innerHTML = `
    <div class="section-title"><h2>💾 النسخ الاحتياطي والاستعادة</h2></div>
    <div class="card">
      <p>يمكنك تنزيل نسخة احتياطية كاملة من قاعدة البيانات (ملف JSON) وحفظها في مكان تختاره، أو استعادة نسخة سابقة.</p>
      <div class="actions">
        <button class="btn" id="expBtn">⬇️ تنزيل نسخة احتياطية الآن</button>
        <button class="btn blue" id="archBtn">🗄️ أرشفة الشهر الحالي</button>
      </div>
      <div style="margin-top:16px">
        <label>استعادة من ملف نسخة احتياطية</label>
        <input type="file" id="importFile" accept="application/json"/>
        <button class="btn red" id="impBtn" style="margin-top:8px">⬆️ استعادة (سيتم استبدال البيانات الحالية)</button>
      </div>
    </div>`;
  byId("expBtn").onclick = async ()=>{
    const data = await exportBackup();
    const blob = new Blob([JSON.stringify(data)], {type:"application/json"});
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `rotank_backup_${new Date().toISOString().slice(0,19).replace(/[:T]/g,"-")}.json`;
    a.click();
    await logAudit("نسخة احتياطية","تم التنزيل");
    toast("تم إنشاء النسخة الاحتياطية");
  };
  byId("archBtn").onclick = async ()=>{
    await archiveMonthSnapshot();
    toast("تم أرشفة الشهر الحالي");
  };
  byId("impBtn").onclick = async ()=>{
    const file = byId("importFile").files[0];
    if(!file){toast("اختر ملف النسخة الاحتياطية","error");return;}
    if(!confirmAction("سيتم استبدال جميع البيانات الحالية بالنسخة المستوردة. متابعة؟"))return;
    const text = await file.text();
    try{
      const data = JSON.parse(text);
      await importBackup(data);
      toast("تمت الاستعادة بنجاح، سيتم إعادة تحميل النظام");
      setTimeout(()=>location.reload(), 1500);
    }catch(e){ toast("ملف غير صالح: "+e.message, "error"); }
  };
}

/* ========= الإعدادات ========= */
async function renderSettings(container) {
  const settings = (await Store.all("settings"))[0] || {id:"main"};
  const users = await Store.all("users");
  container.innerHTML = `
    <div class="section-title"><h2>⚙️ الإعدادات</h2></div>
    <div class="card">
      <div class="form-grid">
        <div><label>اسم المحل</label><input id="setShop" value="${escapeHtml(settings.shopName||"")}"/></div>
        <div><label>اسم الوكيل</label><input id="setAgent" value="${escapeHtml(settings.agentName||"")}"/></div>
        <div><label>الفرع</label><input id="setBranch" value="${escapeHtml(settings.branch||"")}"/></div>
        <div><label>رقم الهاتف</label><input id="setPhone" value="${escapeHtml(settings.phone||"")}"/></div>
        <div><label>العنوان</label><input id="setAddress" value="${escapeHtml(settings.address||"")}"/></div>
        <div><label>العملة الافتراضية</label><select id="setCurrency"><option value="YER" ${settings.currencyDefault==="YER"?"selected":""}>ريال يمني</option><option value="SAR" ${settings.currencyDefault==="SAR"?"selected":""}>ريال سعودي</option></select></div>
        <div><label>بادئة رقم الفاتورة</label><input id="setPrefix" value="${escapeHtml(settings.invoicePrefix||"LH")}"/></div>
      </div>
      <button class="btn" id="setSave">💾 حفظ الإعدادات</button>
    </div>
    <div class="card">
      <div class="section-title"><h2>👤 المستخدمون والصلاحيات</h2><button class="btn" id="addUserBtn">+ إضافة مستخدم</button></div>
      <div id="userFormArea"></div>
      <table><thead><tr><th>اسم المستخدم</th><th>الاسم الكامل</th><th>الصلاحية</th><th></th></tr></thead>
      <tbody>${users.map(u=>`<tr><td>${escapeHtml(u.username)}</td><td>${escapeHtml(u.fullName||"")}</td><td>${escapeHtml(u.role)}</td>
      <td>${u.username!=="admin"?`<button class="btn sm red" data-deluser="${u.id}">حذف</button>`:""}</td></tr>`).join("")}</tbody></table>
    </div>`;
  byId("setSave").onclick = async ()=>{
    await Store.put("settings", {
      ...settings, shopName:byId("setShop").value, agentName:byId("setAgent").value,
      branch:byId("setBranch").value, phone:byId("setPhone").value, address:byId("setAddress").value,
      currencyDefault:byId("setCurrency").value, invoicePrefix:byId("setPrefix").value
    });
    toast("تم حفظ الإعدادات");
  };
  byId("addUserBtn").onclick = ()=>{
    byId("userFormArea").innerHTML = `<div class="card"><div class="form-grid">
      <div><label>اسم المستخدم</label><input id="newUname"/></div>
      <div><label>الاسم الكامل</label><input id="newFullname"/></div>
      <div><label>كلمة المرور</label><input id="newUpass" type="password"/></div>
      <div><label>الصلاحية</label><select id="newUrole"><option value="محاسب">محاسب</option><option value="بائع">بائع</option><option value="مدير">مدير</option></select></div>
      </div><button class="btn" id="saveUserBtn">حفظ المستخدم</button></div>`;
    byId("saveUserBtn").onclick = async ()=>{
      const username=byId("newUname").value, pass=byId("newUpass").value;
      if(!username||!pass){toast("اسم المستخدم وكلمة المرور إلزاميان","error");return;}
      const hash = await simpleHash(pass);
      await Store.put("users",{id:uid(),username,passwordHash:hash,fullName:byId("newFullname").value,role:byId("newUrole").value});
      toast("تم إضافة المستخدم"); renderSettings(container);
    };
  };
  container.querySelectorAll("[data-deluser]").forEach(b=>b.onclick=async()=>{
    if(!confirmAction("حذف هذا المستخدم؟"))return;
    await Store.remove("users", b.dataset.deluser); renderSettings(container);
  });
}
