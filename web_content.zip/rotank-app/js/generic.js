/* ========= وحدة CRUD عامة (للعملاء / الموردين / الملاحظات ...) ========= */
// config: { store, title, icon, fields:[{key,label,type,options,required}], extraCols:[{label,render(row)}] }
async function renderCrud(container, config) {
  const rows = await Store.all(config.store);
  rows.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
  let editingId = null;

  function fieldInput(f, val) {
    val = val == null ? "" : val;
    if (f.type === "select") {
      return `<select data-f="${f.key}">${f.options.map(o =>
        `<option value="${escapeHtml(o.value)}" ${o.value === val ? "selected" : ""}>${escapeHtml(o.label)}</option>`
      ).join("")}</select>`;
    }
    if (f.type === "textarea") {
      return `<textarea data-f="${f.key}" rows="2">${escapeHtml(val)}</textarea>`;
    }
    return `<input data-f="${f.key}" type="${f.type || "text"}" value="${escapeHtml(val)}" ${f.required ? "required" : ""}/>`;
  }

  function formHtml(row) {
    row = row || {};
    return `<div class="card" id="crudForm">
      <div class="section-title"><h2>${row.id ? "تعديل" : "إضافة"} ${config.title}</h2></div>
      <div class="form-grid">
        ${config.fields.map(f => `<div><label>${f.label}${f.required ? " *" : ""}</label>${fieldInput(f, row[f.key])}</div>`).join("")}
      </div>
      <div class="actions">
        <button class="btn" id="crudSave">💾 حفظ</button>
        <button class="btn gray" id="crudCancel">إلغاء</button>
      </div>
    </div>`;
  }

  function tableHtml() {
    return `<div class="card">
      <table>
        <thead><tr>
          ${config.fields.map(f => `<th>${f.label}</th>`).join("")}
          ${(config.extraCols || []).map(c => `<th>${c.label}</th>`).join("")}
          <th>إجراءات</th>
        </tr></thead>
        <tbody>
          ${rows.length === 0 ? `<tr><td colspan="99">لا توجد سجلات</td></tr>` : rows.map(r => `
            <tr>
              ${config.fields.map(f => `<td>${escapeHtml(f.type === "select" ? (f.options.find(o=>o.value===r[f.key])||{}).label || r[f.key] : r[f.key])}</td>`).join("")}
              ${(config.extraCols || []).map(c => `<td>${c.render(r)}</td>`).join("")}
              <td>
                <button class="btn sm blue" data-edit="${r.id}">تعديل</button>
                <button class="btn sm red" data-del="${r.id}">حذف</button>
              </td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>`;
  }

  function paint() {
    container.innerHTML = `
      <div class="section-title"><h2>${config.icon || ""} ${config.title}</h2>
        <button class="btn" id="crudAddBtn">+ إضافة ${config.title}</button>
      </div>
      <div id="crudFormArea"></div>
      ${tableHtml()}
    `;
    byId("crudAddBtn").onclick = () => {
      byId("crudFormArea").innerHTML = formHtml({});
      bindForm({});
    };
    container.querySelectorAll("[data-edit]").forEach(btn => {
      btn.onclick = () => {
        const row = rows.find(r => r.id === btn.dataset.edit);
        byId("crudFormArea").innerHTML = formHtml(row);
        bindForm(row);
      };
    });
    container.querySelectorAll("[data-del]").forEach(btn => {
      btn.onclick = async () => {
        if (!confirmAction("هل تريد حذف هذا السجل؟")) return;
        await Store.remove(config.store, btn.dataset.del);
        await logAudit("حذف", `${config.title}: ${btn.dataset.del}`);
        toast("تم الحذف");
        run();
      };
    });
  }

  function bindForm(row) {
    byId("crudCancel").onclick = () => { byId("crudFormArea").innerHTML = ""; };
    byId("crudSave").onclick = async () => {
      const data = { ...row };
      let missing = false;
      config.fields.forEach(f => {
        const el = document.querySelector(`#crudForm [data-f="${f.key}"]`);
        const v = el.value;
        if (f.required && !v) missing = true;
        data[f.key] = f.type === "number" ? Number(v) : v;
      });
      if (missing) { toast("يرجى تعبئة الحقول المطلوبة (*)", "error"); return; }
      data.createdAt = data.createdAt || new Date().toISOString();
      await Store.put(config.store, data);
      await logAudit(row.id ? "تعديل" : "إضافة", config.title);
      toast("تم الحفظ");
      run();
    };
  }

  function run() { renderCrud(container, config); }
  paint();
}
