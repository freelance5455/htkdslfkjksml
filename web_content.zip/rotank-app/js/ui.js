/* ========= أدوات واجهة مساعدة ========= */
function escapeHtml(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}
function fmt(n) {
  n = Number(n || 0);
  return n.toLocaleString("ar", { maximumFractionDigits: 2 });
}
function currencyLabel(c) { return c === "SAR" ? "ريال سعودي" : "ريال يمني"; }
function todayISO() { return new Date().toISOString().slice(0, 10); }
function toast(msg, type = "ok") {
  const box = document.getElementById("toastBox");
  if (!box) return alert(msg);
  const d = document.createElement("div");
  d.className = "msg " + (type === "error" ? "error" : "ok");
  d.style.position = "fixed"; d.style.left = "20px"; d.style.bottom = "20px";
  d.style.zIndex = 999; d.style.minWidth = "220px"; d.style.boxShadow = "0 4px 16px rgba(0,0,0,.2)";
  d.textContent = msg;
  box.appendChild(d);
  setTimeout(() => d.remove(), 3500);
}
function byId(id) { return document.getElementById(id); }
function confirmAction(msg) { return window.confirm(msg); }
