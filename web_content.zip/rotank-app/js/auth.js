/* ========= المصادقة والصلاحيات ========= */
const Auth = { currentUser: null };

async function simpleHash(text) {
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}

async function ensureDefaultAdmin() {
  const users = await Store.all("users");
  if (users.length === 0) {
    const passHash = await simpleHash("1234");
    await Store.put("users", {
      id: uid(), username: "admin", passwordHash: passHash,
      role: "مدير", fullName: "المدير العام"
    });
  }
  const settings = await Store.all("settings");
  if (settings.length === 0) {
    await Store.put("settings", {
      id: "main",
      shopName: "خزانات روتوتانك",
      agentName: "الوكيل علي ريجل",
      branch: "فرع اللحوم",
      phone: "", address: "", logo: "",
      currencyDefault: "YER",
      invoicePrefix: "LH"
    });
  }
}

async function login(username, password) {
  const users = await Store.all("users");
  const user = users.find(u => u.username === username);
  if (!user) return { ok: false, error: "اسم المستخدم غير صحيح" };
  const hash = await simpleHash(password);
  if (hash !== user.passwordHash) return { ok: false, error: "كلمة المرور غير صحيحة" };
  Auth.currentUser = user;
  sessionStorage.setItem("rotank_uid", user.id);
  await logAudit("تسجيل دخول", user.username);
  return { ok: true, user };
}

async function restoreSession() {
  const id = sessionStorage.getItem("rotank_uid");
  if (!id) return null;
  const user = await Store.get("users", id);
  Auth.currentUser = user;
  return user;
}

function logout() {
  logAudit("تسجيل خروج", Auth.currentUser ? Auth.currentUser.username : "");
  Auth.currentUser = null;
  sessionStorage.removeItem("rotank_uid");
  location.reload();
}

function hasPermission(feature) {
  if (!Auth.currentUser) return false;
  const role = Auth.currentUser.role;
  if (role === "مدير") return true;
  if (role === "محاسب") {
    return !["settings", "users"].includes(feature);
  }
  if (role === "بائع") {
    return ["dashboard", "sales", "customers"].includes(feature);
  }
  return false;
}
