/* ========= التطبيق الرئيسي والتوجيه ========= */
const ROUTES = [
  { key: "dashboard", label: "الرئيسية", icon: "🏠", render: renderDashboard },
  { key: "customers", label: "العملاء", icon: "👥", render: renderCustomersDebts },
  { key: "tanks", label: "الخزانات", icon: "🛢️", render: renderTanks },
  { key: "plastic", label: "المنتجات البلاستيكية", icon: "📦", render: renderPlastic },
  { key: "suppliers", label: "الموردون", icon: "🚚", render: renderSuppliers },
  { key: "sales", label: "المبيعات", icon: "🧾", render: renderSales },
  { key: "purchases", label: "المشتريات", icon: "🛒", render: renderPurchases },
  { key: "returns", label: "المرتجعات", icon: "🔄", render: renderReturns },
  { key: "expenses", label: "المصروفات", icon: "💵", render: renderExpenses },
  { key: "revenues", label: "الإيرادات", icon: "💰", render: renderRevenues },
  { key: "inventory", label: "المخزون", icon: "📦", render: renderInventory },
  { key: "reports", label: "التقارير", icon: "📊", render: renderReports },
  { key: "notes", label: "ملاحظات الوكيل", icon: "📝", render: renderNotes },
  { key: "backup", label: "النسخ الاحتياطي", icon: "💾", render: renderBackup },
  { key: "settings", label: "الإعدادات", icon: "⚙️", render: renderSettings }
];

function renderShell() {
  document.body.innerHTML = `
    <div id="app">
      <div id="sidebar">
        <div class="brand">🛢️ خزانات روتوتانك<small>الوكيل علي ريجل | فرع اللحوم</small></div>
        <nav id="navList"></nav>
        <div class="userbox">
          <div>👤 ${escapeHtml(Auth.currentUser.fullName || Auth.currentUser.username)}</div>
          <div style="opacity:.75;font-size:12px">${escapeHtml(Auth.currentUser.role)}</div>
          <button id="logoutBtn">🚪 تسجيل خروج</button>
        </div>
      </div>
      <div id="main">
        <div id="topbar">
          <button id="menuToggle" class="btn gray" style="display:none">☰</button>
          <h1 id="pageTitle">🏠 الرئيسية</h1>
        </div>
        <div id="content"></div>
      </div>
    </div>
    <div id="toastBox"></div>
  `;
  const nav = byId("navList");
  ROUTES.forEach(r => {
    const a = document.createElement("a");
    a.textContent = `${r.icon} ${r.label}`;
    a.dataset.key = r.key;
    a.onclick = () => navigate(r.key);
    nav.appendChild(a);
  });
  byId("logoutBtn").onclick = logout;
  navigate("dashboard");
}

async function navigate(key) {
  const route = ROUTES.find(r => r.key === key) || ROUTES[0];
  document.querySelectorAll("#navList a").forEach(a => a.classList.toggle("active", a.dataset.key === key));
  byId("pageTitle").textContent = `${route.icon} ${route.label}`;
  const content = byId("content");
  content.innerHTML = `<p>جارِ التحميل...</p>`;
  try {
    await route.render(content);
  } catch (err) {
    content.innerHTML = `<div class="msg error">حدث خطأ في تحميل هذه الشاشة: ${escapeHtml(err.message)}<br/>يمكنك نسخ هذه الرسالة وإعادة صياغتها للمطور.</div>`;
    console.error(err);
  }
}

function renderLogin() {
  document.body.innerHTML = `
    <div class="login-wrap">
      <div class="login-box">
        <h2>🛢️ خزانات روتوتانك</h2>
        <p style="margin-top:-8px;color:#555">الوكيل علي ريجل - فرع اللحوم</p>
        <div id="loginMsg"></div>
        <label style="text-align:right">اسم المستخدم</label>
        <input id="loginUser" value="admin"/>
        <label style="text-align:right;margin-top:8px">كلمة المرور</label>
        <input id="loginPass" type="password" value="1234"/>
        <button class="btn" id="loginBtn">دخول</button>
        <p style="font-size:12px;color:#888;margin-top:10px">المستخدم الافتراضي: admin / 1234</p>
      </div>
    </div>
    <div id="toastBox"></div>
  `;
  byId("loginBtn").onclick = doLogin;
  byId("loginPass").addEventListener("keydown", e => { if (e.key === "Enter") doLogin(); });
}

async function doLogin() {
  const username = byId("loginUser").value.trim();
  const password = byId("loginPass").value;
  const res = await login(username, password);
  if (!res.ok) {
    byId("loginMsg").innerHTML = `<div class="msg error">${escapeHtml(res.error)}</div>`;
    return;
  }
  renderShell();
}

async function boot() {
  await openDB();
  await ensureDefaultAdmin();
  const user = await restoreSession();
  if (user) renderShell();
  else renderLogin();
}

window.addEventListener("DOMContentLoaded", boot);

// تسجيل Service Worker إن كان التطبيق مستضافًا عبر http/https
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  });
}
