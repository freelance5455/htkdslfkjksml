/* ========= طبقة قاعدة البيانات (IndexedDB) ========= */
const DB_NAME = "rotank_db";
const DB_VERSION = 1;
const STORES = [
  "users","settings","customers","suppliers","items","movements",
  "salesInvoices","purchases","returns","debtPayments","expenses",
  "revenues","notes","auditLog","archives"
];

let _db = null;

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      STORES.forEach((name) => {
        if (!db.objectStoreNames.contains(name)) {
          db.createObjectStore(name, { keyPath: "id" });
        }
      });
    };
    req.onsuccess = (e) => { _db = e.target.result; resolve(_db); };
    req.onerror = (e) => reject(e.target.error);
  });
}

function tx(storeName, mode = "readonly") {
  return _db.transaction(storeName, mode).objectStore(storeName);
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

const Store = {
  all(storeName) {
    return new Promise((resolve, reject) => {
      const store = tx(storeName);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = (e) => reject(e.target.error);
    });
  },
  get(storeName, id) {
    return new Promise((resolve, reject) => {
      const req = tx(storeName).get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = (e) => reject(e.target.error);
    });
  },
  put(storeName, obj) {
    if (!obj.id) obj.id = uid();
    return new Promise((resolve, reject) => {
      const req = tx(storeName, "readwrite").put(obj);
      req.onsuccess = () => resolve(obj);
      req.onerror = (e) => reject(e.target.error);
    });
  },
  remove(storeName, id) {
    return new Promise((resolve, reject) => {
      const req = tx(storeName, "readwrite").delete(id);
      req.onsuccess = () => resolve(true);
      req.onerror = (e) => reject(e.target.error);
    });
  },
  clearAll(storeName) {
    return new Promise((resolve, reject) => {
      const req = tx(storeName, "readwrite").clear();
      req.onsuccess = () => resolve(true);
      req.onerror = (e) => reject(e.target.error);
    });
  }
};

async function logAudit(action, details) {
  const user = Auth.currentUser ? Auth.currentUser.username : "غير معروف";
  await Store.put("auditLog", {
    id: uid(), date: new Date().toISOString(), user, action, details: details || ""
  });
}

/* ---------- منطق المخزون التلقائي ---------- */
// حركة: { itemId, direction: 'increase'|'decrease', qty, date, refType, refId, unitPrice, notes }
async function addMovement(m) {
  m.id = uid();
  m.date = m.date || new Date().toISOString();
  await Store.put("movements", m);
  return m;
}

async function computeStock(itemId) {
  const moves = (await Store.all("movements")).filter(m => m.itemId === itemId);
  let stock = 0;
  moves.forEach(m => {
    stock += (m.direction === "increase" ? 1 : -1) * Number(m.qty || 0);
  });
  return stock;
}

async function computeAllStocks() {
  const items = await Store.all("items");
  const moves = await Store.all("movements");
  const map = {};
  items.forEach(it => map[it.id] = 0);
  moves.forEach(m => {
    if (map[m.itemId] === undefined) map[m.itemId] = 0;
    map[m.itemId] += (m.direction === "increase" ? 1 : -1) * Number(m.qty || 0);
  });
  return map;
}

function itemLabel(item) {
  if (!item) return "-";
  if (item.type === "tank") {
    const layerTxt = { "1": "طبقة واحدة", "2": "طبقتين", "3": "ثلاث طبقات" }[String(item.layers)] || "";
    return `خزان ${item.size} لتر - ${layerTxt}`;
  }
  return item.name || "-";
}

async function nextInvoiceNo(prefix) {
  const all = await Store.all("salesInvoices");
  const now = new Date();
  const y = now.getFullYear(), mo = String(now.getMonth() + 1).padStart(2, "0");
  const countThisMonth = all.filter(inv => (inv.invoiceNo || "").includes(`${y}-${mo}`)).length + 1;
  return `${prefix || "LH"}-${y}-${mo}-${String(countThisMonth).padStart(4, "0")}`;
}

/* ---------- التصنيف الافتراضي للخزانات ---------- */
const TANK_SIZES = [100,250,500,750,1000,1500,2000,2500,3000,4000,5000,10000];
const TANK_LAYERS = [
  { value: "1", label: "طبقة واحدة" },
  { value: "2", label: "طبقتين" },
  { value: "3", label: "ثلاث طبقات" }
];

/* ---------- النسخ الاحتياطي ---------- */
async function exportBackup() {
  const data = {};
  for (const s of STORES) data[s] = await Store.all(s);
  data._meta = { exportedAt: new Date().toISOString(), version: DB_VERSION };
  return data;
}

async function importBackup(data) {
  for (const s of STORES) {
    if (Array.isArray(data[s])) {
      await Store.clearAll(s);
      for (const row of data[s]) await Store.put(s, row);
    }
  }
}

/* ---------- الأرشفة الشهرية ---------- */
async function archiveMonthSnapshot() {
  const now = new Date();
  const y = now.getFullYear(), mo = now.getMonth() + 1;
  const key = `${y}-${String(mo).padStart(2, "0")}`;
  const snapshot = {
    id: "arc_" + key,
    key,
    year: y, month: mo,
    createdAt: now.toISOString(),
    sales: await Store.all("salesInvoices"),
    purchases: await Store.all("purchases"),
    returns: await Store.all("returns"),
    expenses: await Store.all("expenses"),
    revenues: await Store.all("revenues"),
    movements: await Store.all("movements")
  };
  await Store.put("archives", snapshot);
  return snapshot;
}
