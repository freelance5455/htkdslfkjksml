const CACHE_NAME = "rotank-cache-v1";
const ASSETS = [
  "./", "./index.html", "./manifest.json",
  "./css/style.css",
  "./js/db.js", "./js/auth.js", "./js/ui.js", "./js/generic.js",
  "./js/business.js", "./js/business2.js", "./js/business3.js", "./js/app.js",
  "./icons/icon-192.png", "./icons/icon-512.png"
];
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(ASSETS)));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))));
});
self.addEventListener("fetch", (e) => {
  e.respondWith(
    caches.match(e.request).then(res => res || fetch(e.request).then(r => {
      return caches.open(CACHE_NAME).then(c => { c.put(e.request, r.clone()); return r; });
    }).catch(() => res))
  );
});
