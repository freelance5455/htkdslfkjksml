# Carreira de Craque v1.50.3

- Corrigido o uniforme titular do Fluminense dentro do jogo.
- A camisa agora usa listras verticais mais estreitas em grená e verde, com filetes brancos entre elas, aproximando o padrão da referência enviada.
- Ajustado o padrão nas prévias de camisa e no uniforme desenhado do atleta.
- Os uniformes visitante e terceiro do Fluminense não foram alterados.
