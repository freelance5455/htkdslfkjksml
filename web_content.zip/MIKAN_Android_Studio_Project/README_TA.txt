MIKAN Diagnostic Lab – Android Studio Project

இந்த project-இல் தற்போதைய HTML reporting software சேர்க்கப்பட்டுள்ளது.

APK உருவாக்க:
1. Android Studio நிறுவி திறக்கவும்.
2. File > Open மூலம் இந்த ZIP-ஐ extract செய்த folder-ஐ தேர்வு செய்யவும்.
3. Gradle sync முடிந்ததும் Build > Build Bundle(s) / APK(s) > Build APK(s) தேர்வு செய்யவும்.
4. APK பொதுவாக app/build/outputs/apk/debug/app-debug.apk இடத்தில் கிடைக்கும்.
5. உங்கள் Android மொபைலில் APK-ஐ நிறுவி சோதிக்கவும்.

குறிப்பு:
- இந்த project-க்கு Android Studio/Android SDK தேவை.
- இங்கு APK build அல்லது device test செய்யப்படவில்லை.
- Report PDF/print செயல்பாடு Android print dialog-ஐ அழைக்கும் வகையில் இணைக்கப்பட்டுள்ளது; உங்கள் சாதனத்தில் சோதித்து உறுதிப்படுத்தவும்.
- இந்த HTML app-இன் test data மற்றும் app data சாதனத்தின் WebView storage-ல் சேமிக்கப்படலாம். பயன்பாட்டை uninstall செய்வதற்கு முன் தேவையான data-வை export/backup செய்யவும்.
