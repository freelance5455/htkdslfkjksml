# StudyZone Firebase Hosting

This build is prepared for Firebase Hosting using project `study-zone-b53df`.

## Deploy

From the project root:

```bash
firebase login
firebase deploy --only hosting
```

Firebase will publish the default site at:

- https://study-zone-b53df.web.app
- https://study-zone-b53df.firebaseapp.com

After deployment, add the actual `web.app` hostname to Firebase Authentication > Settings > Authorized domains if it is not already listed, then test Google Sign-In.

Do not deploy the `backend/` directory as static hosting content. The current hosting config intentionally ignores it.
