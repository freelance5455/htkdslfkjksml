# StudyZone Architecture

## Student data
`users/{uid}` is the cloud source of truth for structured student state.

## Study hierarchy
Board → Class → Stream → Subject → Book → Chapter → Topic → Concept → Question → Attempt → Mastery.

The current v1 project preserves the existing catalogue/chapter metadata and establishes the cloud state boundary. A later data-engine phase should move mastery/question data into dedicated collections instead of deriving them from task completion.

## Gamification
- XP = learning/progress currency.
- Coins = reward-store currency.
- Level = every 1,000 XP.
- Rank = Bronze, Silver, Gold, Platinum, Diamond.
- Challenges grant both XP and coins.

## AI
Browser → `/api/ai/ask` → AI provider.

The browser must never contain the AI provider secret.
