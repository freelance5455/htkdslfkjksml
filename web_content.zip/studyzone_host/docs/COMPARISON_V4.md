# v2.2 → v3.0 → v4.0 comparison

## v2.2 Firebase-connected baseline
- 28 files, ~319 KB uncompressed.
- Existing single-page StudyZone app with Firebase Auth/Firestore/Storage.
- Tasks, XP/coins, challenges, progress, library/catalog, quiz, scanner/OCR/PDF, focus timer and AI question solver scaffolding.
- AI backend accepted requests without Firebase ID-token verification.

## v3.0 security/enhancement package
- 34 files, ~354 KB uncompressed.
- Added Firebase Admin ID-token verification to the AI endpoint.
- Tightened Firestore and Storage rules to per-user paths.
- Added progress enhancement, curriculum scaffolding and profile/preferences enhancement scripts.
- Added a basic AI Tutor interface and safer account logout/cloud-state handling.
- Still not a complete adaptive curriculum engine or complete dedicated tutor product.

## v4.0 full-platform layer
- Keeps the v3 architecture and adds a dedicated `platform-core.js` layer.
- Adaptive curriculum mastery and recommendations.
- Study planner and daily goal tracking.
- Dedicated AI Tutor screen with persistent chat history and tutor profile controls.
- Feedback Center.
- Data export/import and privacy tools.
- Production diagnostics.
- Safer same-origin AI API default plus configurable separate backend URL.

## Size note
The ZIP intentionally contains source code, configuration and documentation only. It does not contain `node_modules`, browser/CDN libraries, an Android APK, or a compiled bundle. Therefore a small ZIP is normal and is not evidence that the source project is incomplete by itself.
