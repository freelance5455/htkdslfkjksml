# StudyZone Master v2 — Test Matrix

## P0: must pass before calling browser build usable
- [ ] Fresh storage opens onboarding, not Home.
- [ ] Onboarding reaches Auth.
- [ ] Guest reaches Class/Board/Stream setup.
- [ ] Class 10/11/12 selection works.
- [ ] Board and stream selection change catalogue.
- [ ] Book registration persists after reload.
- [ ] Local PDF/image import persists in IndexedDB.
- [ ] Question Solver accepts typed text.
- [ ] Question Solver extracts PDF text.
- [ ] Question Solver OCRs an image when OCR CDN loads.
- [ ] Camera fallback opens device camera/gallery.
- [ ] Task completion changes task percentage and gives one reward only.
- [ ] Focus timer records study minutes and changes study percentage.
- [ ] Quiz attempts change question percentage.
- [ ] Daily challenge claim cannot be repeated.
- [ ] XP level/rank reflects actual XP.
- [ ] Settings System Check reflects available APIs.

## P1: requires services
- [ ] Firebase email signup.
- [ ] Firebase login.
- [ ] Password reset.
- [ ] Google login on authorized HTTPS domain.
- [ ] Firestore cloud restore/sync.
- [ ] Firebase Storage upload.
- [ ] AI backend health endpoint.
- [ ] AI Question Solver response.

## P2: Android wrapper
- [ ] Fresh install shows onboarding.
- [ ] Native camera permission.
- [ ] Native gallery/file picker.
- [ ] PDF open/extraction.
- [ ] Back navigation.
- [ ] Keyboard behavior.
- [ ] Network failure messaging.
- [ ] Auth/cloud restore after reinstall.
