# StudyZone 4.0 — Full Student Platform

This release builds on the Firebase-connected StudyZone 3.x project rather than replacing its architecture.

## Included
- Adaptive curriculum mastery tracking using the existing class/board/stream catalog.
- Chapter completion and mastery state stored inside the signed-in student's state.
- Study planner: daily minutes, preferred study time, weekly session target and reminder preference.
- Dedicated AI Tutor screen with tutor profile preferences, question history and Firebase ID-token authentication.
- Tutor preferences: language, explanation style, detail level, tone, hints-first and exam mode.
- Feedback Center with categories and ratings.
- Data & Privacy center with JSON export/import.
- Production diagnostics for Firebase, Auth, Firestore, Storage, IndexedDB, connectivity, cloud sync and AI backend configuration.
- Recommendations based on unfinished tasks and weakest curriculum topics.
- Existing tasks, XP, coins, challenges, progress, library, OCR/PDF, scanner, Firebase Auth/Firestore/Storage and official book links preserved.
- AI backend continues to verify Firebase ID tokens and keep provider credentials server-side.

## Not bundled
- `node_modules` and third-party dependencies are intentionally not included; run `npm install` in `backend/` before building the API.
- No copyrighted textbook pages are bundled.
