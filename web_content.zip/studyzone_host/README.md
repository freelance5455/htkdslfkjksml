# StudyZone v2.9

StudyZone is a student-focused web app for Classes 10–12 combining task planning, gamification, progress tracking, study curriculum, quizzes, AI tutoring and a legal book/source directory.

## v2.9
This release adds a durable Profile Preferences layer and structured feedback/review capture. Existing Firebase authentication and Firestore state sync are preserved.

### Important
- This is a source-code project, not a Firebase Console import file.
- Keep Firebase secrets/service-account files out of the client project.
- The AI Tutor still requires the configured backend and AI provider key server-side.
