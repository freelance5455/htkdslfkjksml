# StudyZone v2.9

## Profile, Preferences & Feedback
- Added canonical per-user study preferences in `state.profilePrefs`.
- Added daily study goal editor (10–600 minutes).
- Added study reminder preference and preferred time for future notification support.
- Added compact-card preference.
- Added structured in-app rating/review feedback with rating, text, timestamp and user UID.
- Preferences and feedback use the existing `save()` path so signed-in users can sync through the existing Firestore app-state mechanism.
- Preserved existing Firebase Authentication, Study Hub, AI Tutor, Books/Legal Sources, Task, XP/Coins and Progress features.
- No API secrets added to the frontend.


## UI / AI Tutor update — 2026-09-26
- Moved the existing AI Tutor into the centered bottom navigation orb.
- Added AI Tutor image/PDF question upload (20 MB inline-request limit).
- Added attachment preview/removal and multimodal Gemini requests.
- Increased AI Tutor response typography and kept each response in one readable message container.
- Added My Library book selection to Quiz and included user-added books in the quiz entry flow.
- Fixed Add Book file-first flow so uploading a file before saving metadata no longer creates a duplicate book.
- Centered and enlarged the StudyZone home heading.
