# Firebase setup for StudyZone v2.2

Configured project: `study-zone-b53df`

Enable these Firebase products in the Firebase Console:
1. Authentication -> Sign-in method -> Email/Password (enable).
2. Authentication -> Sign-in method -> Google (enable if Google login is wanted).
3. Firestore Database -> Create database.
4. Storage -> Get started.

Deploy the rules in `firebase/firestore.rules` and `firebase/storage.rules` after the products are enabled.

The browser app uses Firebase Authentication, Firestore and Storage. The web config is not a server secret. Never put an OpenAI/other AI secret in frontend files.
