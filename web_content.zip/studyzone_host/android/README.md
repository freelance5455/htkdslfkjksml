# Android packaging

Use a real Android wrapper/build pipeline (preferably Capacitor or a maintained WebView project) rather than an HTML-to-APK converter that strips permissions or blocks secure APIs.

Required capabilities:
- INTERNET
- CAMERA
- file/media picker access appropriate to the Android version
- WebView JavaScript and DOM storage
- HTTPS for hosted auth/API endpoints

Do not put AI API secrets in the APK.
