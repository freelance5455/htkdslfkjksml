# v3 Security / Production Hardening

- Added Firebase ID-token verification to `/api/ai/ask`.
- Added frontend Authorization bearer token for AI requests.
- Added Firebase Admin SDK dependency and server environment configuration.
- Hardened CORS configuration.
- Added explicit deny-by-default Firestore and Storage rules.
- Added security setup and verification documentation.
