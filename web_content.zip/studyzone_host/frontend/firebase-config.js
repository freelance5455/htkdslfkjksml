// StudyZone Firebase Web configuration.
// Firebase web API keys identify the web app; do not put server/AI secrets here.
window.STUDYZONE_FIREBASE_CONFIG = {
  apiKey: "AIzaSyC0sG50mxQ2L2No6x3ZhHXHlM9ZszcpGBU",
  authDomain: "study-zone-b53df.firebaseapp.com",
  projectId: "study-zone-b53df",
  storageBucket: "study-zone-b53df.firebasestorage.app",
  messagingSenderId: "1051735710263",
  appId: "1:1051735710263:web:7c8ae317fd6b1c0541bdb2",
  measurementId: "G-21WHHG4M3V"
};
