// Optional public configuration. Leave blank when the AI backend is served from the same origin.
// For a separate backend, set this to e.g. https://your-api.example.com/api
window.STUDYZONE_API_BASE='';
