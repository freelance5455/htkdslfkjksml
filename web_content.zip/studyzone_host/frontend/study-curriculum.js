/* StudyZone v2.6 — Curriculum & Study Hub
   Original learning scaffolding only. Does not bundle copyrighted textbook text.
*/
(function(){
'use strict';
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const curriculum={
  '10th':{
    'Mathematics':{
      'Real Numbers':`Real numbers include rational and irrational numbers. A key idea is that every real number can be placed on the number line. For calculations, identify the property or theorem being used before manipulating the expression.`,
      'Polynomials':`A polynomial is an algebraic expression made from variables with non-negative integer powers. Learn degree, zeros and the relationship between zeros and coefficients, then practise factorisation.`
    },
    'Science':{
      'Chemical Reactions and Equations':`A chemical reaction forms new substances. Learn to identify reactants and products, write a symbolic equation, and balance atoms on both sides.`
    }
  },
  '11th':{
    'Accountancy':{
      'Introduction to Accounting':`Accounting is a systematic process of identifying, recording, classifying and summarising financial transactions so useful information can be communicated.`,
      'Accounting Equation':`The basic relationship is Assets = Capital + Liabilities. Each transaction changes at least two elements while keeping the equation balanced.`
    },
    'Mathematics':{
      'Sets':`A set is a well-defined collection of objects. Focus on notation, subsets, union, intersection, difference and complements, then practise Venn-diagram questions.`
    }
  },
  '12th / Plus 2':{
    'Accountancy':{
      'Accounting for Partnership Firms — Fundamentals':`Partnership accounting begins with the agreement among partners. Focus on profit-sharing, interest on capital, drawings, salary/commission and the treatment of items when the agreement is silent.`,
      'Goodwill: Nature and Valuation':`Goodwill represents the value attached to a firm's reputation and expected future benefits. Common approaches include average profit, super profit and capitalisation methods.`
    },
    'Business Studies':{
      'Nature and Significance of Management':`Management coordinates people and resources to achieve organisational objectives. Learn its objectives, characteristics, functions and why coordination matters.`
    },
    'Economics':{
      'National Income and Related Aggregates':`National income measures economic activity using related aggregates such as GDP and GNP. Learn the definitions first, then practise the relationships and precautions in calculation.`
    }
  }
};
const quizBank={
 'Accounting Equation':[
  {q:'If assets are ₹80,000 and liabilities are ₹30,000, capital is:',o:['₹30,000','₹50,000','₹80,000','₹1,10,000'],a:1},
  {q:'The basic accounting equation is:',o:['Assets = Capital − Liabilities','Assets = Capital + Liabilities','Capital = Assets + Liabilities','Liabilities = Assets + Capital'],a:1},
  {q:'Owner introduces cash into the business. What happens?',o:['Assets increase and capital increases','Assets decrease and capital increases','Only liabilities increase','Only capital decreases'],a:0}
 ],
 'Goodwill: Nature and Valuation':[
  {q:'Goodwill primarily represents:',o:['Cash in hand','Reputation and expected future benefits','Outstanding expenses','Stock quantity'],a:1},
  {q:'Under the average profit method, goodwill is based mainly on:',o:['Average maintainable profit and agreed years’ purchase','Only total assets','Only liabilities','Cash balance'],a:0}
 ],
 'Sets':[
  {q:'The union of two sets contains:',o:['Only common elements','Elements in either set or both','Only elements of the first set','No elements'],a:1},
  {q:'A set with no elements is called:',o:['Universal set','Singleton set','Empty set','Finite set'],a:2}
 ],
 'Real Numbers':[
  {q:'Which is irrational?',o:['1/2','0.75','√2','4'],a:2},
  {q:'A rational number can be written as:',o:['p/q, q ≠ 0','p/q, q = 0','Only a whole number','Only a terminating decimal'],a:0}
 ]
};
function getClassKey(){let c=state.className||'10th';return c==='12th'?'12th / Plus 2':c}
function booksForClass(){
  try{return typeof getCatalog==='function'?getCatalog():[]}
  catch(e){return[]}
}
function subjects(){
 const books=booksForClass(); const out=[];
 books.forEach(b=>{const s=b.subject||b.name;if(s&&!out.includes(s))out.push(s)});
 Object.keys(curriculum[getClassKey()]||{}).forEach(s=>{if(!out.includes(s))out.push(s)});
 return out.length?out:['Mathematics','Science'];
}
function chaptersFor(subject){
 const books=booksForClass().filter(b=>(b.subject||b.name)===subject);
 let arr=[];
 books.forEach(b=>(b.chapters||[]).forEach(c=>{if(!arr.includes(c))arr.push(c)}));
 const extra=curriculum[getClassKey()]?.[subject]?Object.keys(curriculum[getClassKey()][subject]):[];
 extra.forEach(c=>{if(!arr.includes(c))arr.push(c)});
 return arr;
}
function lessonFor(subject,chapter){
 return curriculum[getClassKey()]?.[subject]?.[chapter] ||
 `Start with the definition and key terms of "${chapter}". Write the concept in your own words, learn one worked example, then test yourself without looking at your notes. Use the Quiz button below for active recall.`;
}
function render(){
 const host=$('studyHub');if(!host)return;
 const subject=host.dataset.subject||subjects()[0];
 const chapters=chaptersFor(subject);
 const chapter=host.dataset.chapter||chapters[0]||'';
 host.dataset.subject=subject;host.dataset.chapter=chapter;
 host.innerHTML=`
 <div class="card pad">
  <div class="section-head"><div><div class="section-title">📚 ${esc(getClassKey())} Study Hub</div><div class="sub">Learn concepts, practise recall and earn XP. Only original learning notes are shown here.</div></div><span class="badge">${esc(subject)}</span></div>
  <div class="field"><label>Subject</label><select class="select" id="studySubject">${subjects().map(s=>`<option ${s===subject?'selected':''}>${esc(s)}</option>`).join('')}</select></div>
  <div class="field" style="margin-top:10px"><label>Chapter / Topic</label><select class="select" id="studyChapter">${chapters.map(c=>`<option ${c===chapter?'selected':''}>${esc(c)}</option>`).join('')}</select></div>
 </div>
 <div class="card pad" style="margin-top:10px">
   <div class="section-head"><div><div class="section-title">💡 Quick Lesson</div><div class="sub">Read → recall → practise</div></div><span class="badge">ORIGINAL NOTE</span></div>
   <p style="line-height:1.65;margin:8px 0">${esc(lessonFor(subject,chapter))}</p>
   <div class="grid2" style="margin-top:12px">
     <button class="btn" id="studyStartQuiz">🧠 Start Quiz</button>
     <button class="btn ghost" id="studyMakeTask">➕ Add Revision Task</button>
   </div>
 </div>
 <div class="card pad" style="margin-top:10px">
   <div class="section-head"><div class="section-title">🎯 Study Method</div><span class="badge">3 STEPS</span></div>
   <div class="stack">
    <div><b>1. Understand</b><div class="sub">Explain the concept in your own words.</div></div>
    <div><b>2. Recall</b><div class="sub">Close your notes and reproduce the key idea.</div></div>
    <div><b>3. Apply</b><div class="sub">Solve a question or create your own example.</div></div>
   </div>
 </div>
 <div class="card pad" style="margin-top:10px">
   <div class="section-head"><div class="section-title">📖 Chapters</div><span class="badge">${chapters.length}</span></div>
   <div class="stack">${chapters.slice(0,80).map((c,i)=>`<button class="option study-chapter" data-chapter="${esc(c)}" style="text-align:left"><b>${i+1}. ${esc(c)}</b><span>${quizBank[c]?'Quiz available':'Study note + revision task'}</span></button>`).join('')}</div>
 </div>`;
 $('studySubject').onchange=e=>{host.dataset.subject=e.target.value;host.dataset.chapter='';render()};
 $('studyChapter').onchange=e=>{host.dataset.chapter=e.target.value;render()};
 $('studyStartQuiz').onclick=()=>startMiniQuiz(subject,chapter);
 $('studyMakeTask').onclick=()=>{ if(typeof openTaskModal==='function'){openTaskModal();setTimeout(()=>{const t=$('taskTitle');if(t)t.value=`Revise: ${chapter}`},80)} };
 host.querySelectorAll('.study-chapter').forEach(b=>b.onclick=()=>{host.dataset.chapter=b.dataset.chapter;render()});
}
function startMiniQuiz(subject,chapter){
 const questions=quizBank[chapter];
 if(!questions){toast('A chapter-specific quiz is not available yet. Use the main Quiz section for more practice.');return}
 let i=0,score=0;
 const modal=$('modal'),content=$('modalContent');if(!modal||!content)return;
 function paint(){
  const q=questions[i];
  content.innerHTML=`<div class="row"><div><div class="eyebrow">MINI QUIZ</div><h2>${i+1}/${questions.length}</h2></div><button class="close" onclick="closeModal()">✕</button></div>
  <div class="card pad" style="margin-top:12px"><h3 style="font-size:17px;line-height:1.45">${esc(q.q)}</h3><div class="stack" style="margin-top:12px">${q.o.map((x,j)=>`<button class="option mini-opt" data-i="${j}">${esc(x)}</button>`).join('')}</div></div>`;
  content.querySelectorAll('.mini-opt').forEach(b=>b.onclick=()=>{
   const choice=Number(b.dataset.i);const correct=choice===q.a;
   if(correct)score++;
   content.querySelectorAll('.mini-opt').forEach(x=>x.disabled=true);
   b.classList.add(correct?'selected':'wrong');
   setTimeout(()=>{i++;if(i<questions.length)paint();else finish()},550);
  });
 }
 function finish(){
  const xp=score*10;
  if(typeof window.MasterStudyZone?.awardXP==='function')window.MasterStudyZone.awardXP(xp,`study_quiz:${getClassKey()}:${subject}:${chapter}:${todayISO()}:${Date.now()}`);
  else {state.xpTotal=(state.xpTotal||0)+xp;state.coins=(state.coins||0)+Math.floor(score/2);save()}
  content.innerHTML=`<div style="text-align:center;padding:18px"><div style="font-size:48px">🎉</div><h2>Quiz complete</h2><p class="sub">Score: ${score}/${questions.length}</p><div class="badge">+${xp} XP</div><button class="btn full" style="margin-top:14px" onclick="closeModal();render()">Continue</button></div>`;
  if(typeof renderDashboardExtras==='function')renderDashboardExtras();
 }
 modal.classList.add('open');paint();
}
function install(){
 const home=$('home');if(!home||$('studyHub'))return;
 const section=document.createElement('section');section.id='study';section.className='screen';
 section.innerHTML=`<div class="hero"><div class="eyebrow">LEARN • PRACTISE • REMEMBER</div><h1>Study</h1><p class="sub">Your syllabus navigator with short original notes, revision tasks and active-recall quizzes.</p></div><div id="studyHub"></div>`;
 home.parentNode.insertBefore(section,home.nextSibling);
 const nav=$('nav');if(nav){
  const b=document.createElement('button');b.dataset.screen='study';b.innerHTML='<span>📚</span><small>Study</small>';
  const quiz=nav.querySelector('[data-screen="quiz"]'); if(quiz)nav.insertBefore(b,quiz); else nav.appendChild(b);
  b.onclick=()=>showScreen('study');
 }
}
function boot(){install();if($('study')){const obs=new MutationObserver(()=>{if($('study').classList.contains('active'))render()});obs.observe($('study'),{attributes:true,attributeFilter:['class']})}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(boot,800));else setTimeout(boot,800);
window.StudyZoneStudyV26={render,startMiniQuiz};
})();