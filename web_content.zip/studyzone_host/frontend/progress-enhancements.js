/* StudyZone v2.5 — Progress Dashboard enhancement
   Adds a truthful, student-friendly progress dashboard without changing the existing app architecture.
*/
(function(){
  'use strict';

  const $ = id => document.getElementById(id);
  const iso = d => {
    const x = new Date(d);
    const y=x.getFullYear(), m=String(x.getMonth()+1).padStart(2,'0'), day=String(x.getDate()).padStart(2,'0');
    return `${y}-${m}-${day}`;
  };
  const today = () => typeof window.todayISO === 'function' ? window.todayISO() : iso(new Date());

  function ensure(){
    window.state=window.state||{};
    state.tasks=Array.isArray(state.tasks)?state.tasks:[];
    state.studyMinutesByDate=state.studyMinutesByDate||{};
    state.quizStats=state.quizStats||{byDate:{}};
    state.quizStats.byDate=state.quizStats.byDate||{};
    state.challengeClaims=state.challengeClaims||{};
    state.gamification=state.gamification||{achievements:{}};
    state.gamification.achievements=state.gamification.achievements||{};
  }

  function dayData(date){
    ensure();
    const tasks=state.tasks.filter(t=>t.date===date || t.repeatDaily!==false);
    const done=tasks.filter(t=>t.doneDates?.[date]).length;
    const minutes=Number(state.studyMinutesByDate?.[date]||0);
    const quiz=state.quizStats.byDate?.[date]||{answered:0,correct:0};
    const challenges=Object.keys(state.challengeClaims||{}).filter(k=>k.endsWith('_'+date)).length;
    return {date,total:tasks.length,done,minutes,answered:Number(quiz.answered||0),correct:Number(quiz.correct||0),challenges};
  }

  function days(n=7){
    const out=[];
    const now=new Date();
    now.setHours(12,0,0,0);
    for(let i=n-1;i>=0;i--){
      const d=new Date(now); d.setDate(now.getDate()-i);
      out.push(dayData(iso(d)));
    }
    return out;
  }

  function pct(n,d){ return d ? Math.min(100,Math.round(n/d*100)) : 0; }

  function render(){
    ensure();
    const host=$('progressDetailV25');
    if(!host)return;
    const recent=days(7), td=recent[recent.length-1];
    const yesterday=recent[recent.length-2]||{minutes:0,done:0,total:0};
    const totalMinutes=Object.values(state.studyMinutesByDate||{}).reduce((a,v)=>a+Number(v||0),0);
    const totalDone=state.tasks.reduce((n,t)=>n+Object.keys(t.doneDates||{}).length,0);
    const xp=Number(state.xpTotal||0), coins=Number(state.coins||0);
    const level=Math.floor(xp/1000)+1, inLevel=xp%1000;
    const achievements=Object.values(state.gamification.achievements||{});
    const weekMinutes=recent.reduce((a,d)=>a+d.minutes,0);
    const weekTasks=recent.reduce((a,d)=>a+d.done,0);
    const weekQuiz=recent.reduce((a,d)=>a+d.correct,0);

    const deltaMin=td.minutes-yesterday.minutes;
    const deltaTask=td.done-yesterday.done;
    const sign=n=>n>0?`+${n}`:String(n);
    const labels=recent.map(d=>{
      const dt=new Date(d.date+'T12:00:00');
      return dt.toLocaleDateString(undefined,{weekday:'short'}).slice(0,3);
    });

    host.innerHTML=`
      <div class="card pad v25-card">
        <div class="section-head">
          <div><div class="section-title">📈 Your last 7 days</div><div class="sub">Based on actual tasks, study minutes and quiz activity.</div></div>
          <span class="badge">7 DAYS</span>
        </div>
        <div class="v25-bars">
          ${recent.map((d,i)=>`
            <div class="v25-day">
              <div class="v25-bar-wrap"><div class="v25-bar" style="height:${Math.max(5,Math.min(100,d.minutes/Math.max(1,Math.max(...recent.map(x=>x.minutes)))*100))}%"></div></div>
              <b>${d.minutes}m</b><small>${labels[i]}</small>
            </div>`).join('')}
        </div>
        <div class="grid2" style="margin-top:12px">
          <div class="v25-mini"><span>📚</span><b>${weekMinutes} min</b><small>Study this week</small></div>
          <div class="v25-mini"><span>✅</span><b>${weekTasks}</b><small>Tasks completed</small></div>
          <div class="v25-mini"><span>🧠</span><b>${weekQuiz}</b><small>Correct answers</small></div>
          <div class="v25-mini"><span>📊</span><b>${sign(deltaMin)} min</b><small>vs yesterday</small></div>
        </div>
      </div>

      <div class="card pad v25-card">
        <div class="section-head">
          <div><div class="section-title">⚡ Level progress</div><div class="sub">Keep earning XP to reach the next level.</div></div>
          <b>Level ${level}</b>
        </div>
        <div class="progressbar"><span style="width:${Math.round(inLevel/10)}%"></span></div>
        <div class="row" style="margin-top:8px"><span class="sub">${inLevel} / 1000 XP</span><span class="sub">${1000-inLevel} XP to next level</span></div>
        <div class="grid2" style="margin-top:12px">
          <div class="v25-mini"><span>⚡</span><b>${xp} XP</b><small>Total XP</small></div>
          <div class="v25-mini"><span>🪙</span><b>${coins}</b><small>Coins</small></div>
        </div>
      </div>

      <div class="card pad v25-card">
        <div class="section-head">
          <div><div class="section-title">🏆 Achievements</div><div class="sub">${achievements.length} unlocked</div></div>
          <span class="badge">${totalDone} tasks total</span>
        </div>
        <div class="v25-achievements">
          ${achievements.length ? achievements.map(a=>`<div class="v25-ach"><span>${a.icon||'🏆'}</span><div><b>${esc(a.name||'Achievement')}</b><small>${esc(a.desc||'Unlocked')}</small></div></div>`).join('') : `<div class="sub">No achievements yet. Complete a task, study for 100 minutes, or build a streak to unlock them.</div>`}
        </div>
      </div>
    `;
  }

  function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}

  function install(){
    const progress=$('progress');
    if(!progress || $('progressDetailV25'))return;
    const anchor=progress.querySelector('.card.pad');
    const host=document.createElement('div');
    host.id='progressDetailV25';
    host.style.marginTop='12px';
    if(anchor) anchor.after(host); else progress.appendChild(host);
    render();

    // Existing app code calls its own internal render functions. A light refresh keeps this
    // enhancement synchronized without replacing those functions or their data model.
    setInterval(()=>{ if(document.body.contains(host) && !$('modal')) render(); },3000);
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>setTimeout(install,450));
  else setTimeout(install,450);
  window.StudyZoneProgressV25={render};
})();
