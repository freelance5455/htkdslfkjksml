/* StudyZone Master v1 — production-oriented enhancement layer.
   Keeps the existing UI as a compatibility layer while adding:
   - Firestore cloud sync for structured student state
   - Storage-ready profile/book upload helpers
   - real AI search client via /api/ai/ask (no API key in browser)
   - persistent XP/rank economy
   - richer daily challenges
   - safer progress calculation
   - diagnostics panel
*/
(function(){
  'use strict';
  const NS='studyzone_master_v1';
  const RANKS=[
    {name:'Bronze',min:0,max:499,icon:'🥉'},
    {name:'Silver',min:500,max:1999,icon:'🥈'},
    {name:'Gold',min:2000,max:4999,icon:'🥇'},
    {name:'Platinum',min:5000,max:9999,icon:'💎'},
    {name:'Diamond',min:10000,max:Infinity,icon:'💠'}
  ];
  const LEVEL_STEP=1000;
  let syncTimer=null, syncing=false;

  function toastSafe(msg){ if(typeof window.toast==='function') window.toast(msg); else console.log(msg); }
  function uid(){ return 'z'+Date.now().toString(36)+Math.random().toString(36).slice(2,8); }
  function currentUser(){ return window.studyZoneAuth?.currentUser || null; }
  function firestore(){ return window.firebase?.firestore ? window.firebase.firestore() : null; }
  function storage(){ return window.firebase?.storage ? window.firebase.storage() : null; }

  function ensureMasterState(){
    window.state = window.state || {};
    state.xpTotal = Number.isFinite(state.xpTotal)?state.xpTotal:0;
    state.xpLedger = Array.isArray(state.xpLedger)?state.xpLedger:[];
    state.achievements = state.achievements && typeof state.achievements==='object' ? state.achievements : {};
    state.challengeClaims = state.challengeClaims || {};
    state.dailyChallengeSet = state.dailyChallengeSet || {};
    state.studySessions = Array.isArray(state.studySessions)?state.studySessions:[];
    state.masterVersion='v1';
  }

  function awardXP(amount, reason){
    ensureMasterState(); amount=Math.max(0,Math.floor(amount||0)); if(!amount)return;
    const now=Date.now();
    state.xpTotal += amount;
    state.xpLedger.push({id:uid(),amount,reason:String(reason||'study'),at:now});
    if(state.xpLedger.length>250) state.xpLedger=state.xpLedger.slice(-250);
    if(typeof window.save==='function') window.save();
    renderGamification();
  }

  function levelInfo(xp){
    xp=Math.max(0,Number(xp)||0);
    const level=Math.floor(xp/LEVEL_STEP)+1;
    const inLevel=xp%LEVEL_STEP;
    const pct=Math.min(100,Math.round(inLevel/LEVEL_STEP*100));
    return {level,inLevel,pct,next:LEVEL_STEP-inLevel};
  }
  function rankInfo(xp){
    return RANKS.find(r=>xp>=r.min && xp<=r.max) || RANKS[RANKS.length-1];
  }

  function renderGamification(){
    ensureMasterState();
    if(window.StudyZoneV2?.gamification) window.StudyZoneV2.gamification();
    const xp=state.xpTotal||0, li=levelInfo(xp), rank=rankInfo(xp);
    const next=RANKS.find(r=>r.min>xp) || null;
    const nodes={homeXP:`${xp} XP`,homeLevel:`Level ${li.level} • ${rank.name}`,progressXP:`${xp} XP`,progressLevel:`Level ${li.level} • ${rank.name}`};
    Object.entries(nodes).forEach(([id,v])=>{const e=document.getElementById(id);if(e)e.textContent=v});
    const hero=document.querySelector('#progress .progress-hero');
    if(hero){
      let box=document.getElementById('masterRankBox');
      if(!box){box=document.createElement('div');box.id='masterRankBox';box.className='card pad';hero.parentNode.insertBefore(box,hero.nextSibling)}
      const toNext=next?Math.max(0,next.min-xp):0;
      box.innerHTML=`<div class="section-head"><div class="section-title">${rank.icon} ${rank.name} Rank</div><span class="badge">LEVEL ${li.level}</span></div><div class="progressbar"><span style="width:${li.pct}%"></span></div><div class="sub" style="margin-top:8px">${li.inLevel} / ${LEVEL_STEP} XP in this level${next?` • ${toNext} XP to ${next.name}`:' • Top rank reached'}</div>`;
    }
  }

  function challengeForDate(){
    ensureMasterState();
    const d=(typeof window.todayISO==='function'?window.todayISO():new Date().toISOString().slice(0,10));
    const seed=d.split('-').reduce((a,n)=>a+Number(n),0);
    const pool=[
      {id:'focus20',icon:'🎯',title:'20-minute focus',desc:'Complete a study task with a 20+ minute duration.',xp:60,coins:15,check:c=>c.duration>=20},
      {id:'tasks2',icon:'📝',title:'Finish 2 tasks',desc:'Complete two study tasks today.',xp:70,coins:20,check:c=>c.done>=2},
      {id:'quiz5',icon:'🧠',title:'Get 5 quiz answers right',desc:'Answer five quiz questions correctly.',xp:50,coins:15,check:c=>c.correct>=5},
      {id:'book1',icon:'📚',title:'Open a study book',desc:'Open or study one registered book today.',xp:35,coins:10,check:c=>c.bookOpened},
      {id:'streak3',icon:'🔥',title:'Protect a 3-day streak',desc:'Reach or maintain a 3-day streak.',xp:80,coins:25,check:c=>c.streak>=3},
      {id:'concept1',icon:'💡',title:'Finish one concept',desc:'Complete one concept/topic task.',xp:45,coins:12,check:c=>c.concept}
    ];
    const chosen=[0,1,2].map((_,i)=>pool[(seed+i*2)%pool.length]);
    return {d,chosen};
  }

  function challengeContext(){
    const d=typeof window.todayISO==='function'?window.todayISO():new Date().toISOString().slice(0,10);
    const tasks=state.tasks||[];
    const done=tasks.filter(t=>t.doneDates?.[d]).length;
    const duration=tasks.filter(t=>t.doneDates?.[d]).reduce((sum,t)=>sum+(parseInt(t.duration)||0),0);
    const correct=state.quizCorrectToday||0;
    const bookOpened=!!state.lastBookOpenedDate && state.lastBookOpenedDate===d;
    const streak=typeof window.calcStreak==='function'?window.calcStreak():0;
    const concept=tasks.some(t=>t.doneDates?.[d] && /concept|chapter|revision|topic/i.test(t.title||''));
    return {done,duration,correct,bookOpened,streak,concept};
  }

  function renderEnhancedChallenges(){
    const el=document.getElementById('challengeList'); if(!el)return;
    const {d,chosen}=challengeForDate(), c=challengeContext();
    el.innerHTML=chosen.map(x=>{
      const key=`${x.id}_${d}`, claimed=!!state.challengeClaims[key], complete=!!x.check(c);
      return `<div class="card pad"><div class="row"><div style="font-size:25px">${x.icon}</div><div style="flex:1"><b>${x.title}</b><div class="sub">${x.desc}</div><span class="badge">+${x.xp} XP • +${x.coins} coins</span></div><button class="btn small" ${(!complete||claimed)?'disabled':''} onclick="MasterStudyZone.claimEnhancedChallenge('${x.id}')">${claimed?'Claimed':complete?'Claim':'Locked'}</button></div></div>`;
    }).join('');
  }

  function claimEnhancedChallenge(id){
    const {d,chosen}=challengeForDate(), x=chosen.find(v=>v.id===id); if(!x)return;
    const key=`${id}_${d}`; if(state.challengeClaims[key]||!x.check(challengeContext()))return;
    state.challengeClaims[key]=true; state.coins=(state.coins||0)+x.coins; awardXP(x.xp,`challenge:${id}`);
    if(typeof window.save==='function')window.save(); renderEnhancedChallenges(); if(typeof window.renderRewards==='function')window.renderRewards(); toastSafe(`+${x.xp} XP • +${x.coins} coins`);
  }

  async function askAI(question, opts={}){
    const q=String(question||'').trim(); if(!q)throw new Error('Please enter a question.');
    const payload={question:q,className:state.className||'',board:state.board||'',stream:state.stream||'',subject:opts.subject||'',chapter:opts.chapter||'',book:opts.book||'',books:(state.books||[]).slice(0,20).map(b=>({id:b.id,name:b.name,subject:b.subject,author:b.author,chapters:(b.chapters||[]).slice(0,50)}))};
    const user=currentUser();
    if(!user) throw new Error('Please sign in before using StudyZone AI.');
    const idToken=await user.getIdToken();
    const r=await fetch((window.STUDYZONE_API_BASE||'')+'/api/ai/ask',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${idToken}`},body:JSON.stringify(payload)});
    const data=await r.json().catch(()=>({})); if(!r.ok)throw new Error(data.error||`AI request failed (${r.status})`); return data;
  }

  function injectAISearch(){
    const screen=document.getElementById('search'); if(!screen||document.getElementById('masterAISearch'))return;
    const box=document.createElement('div'); box.id='masterAISearch'; box.className='card pad'; box.style.marginTop='12px';
    box.innerHTML=`<div class="section-head"><div><div class="section-title">🧠 Ask StudyZone AI</div><div class="sub">Ask about your class, subject, chapter or registered books.</div></div><span class="badge">REAL API</span></div><textarea id="masterAIQuestion" class="textarea" rows="4" placeholder="e.g. Explain partnership accounts in Class 12 Accountancy step by step."></textarea><div class="grid2" style="margin-top:8px"><button id="masterAskAI" class="btn">Ask AI →</button><button id="masterUseCameraAI" class="btn ghost">📷 Ask from Camera</button></div><div id="masterAIStatus" class="sub" style="margin-top:8px"></div><div id="masterAIAnswer" class="card pad" style="display:none;margin-top:10px"></div>`;
    const oldSearch=screen.querySelector('.search'); screen.insertBefore(box,oldSearch?oldSearch.nextSibling:screen.firstChild.nextSibling);
    document.getElementById('masterAskAI').onclick=async()=>{
      const status=document.getElementById('masterAIStatus'), ans=document.getElementById('masterAIAnswer'), btn=document.getElementById('masterAskAI');
      btn.disabled=true; status.textContent='Thinking…'; ans.style.display='none';
      try{const data=await askAI(document.getElementById('masterAIQuestion').value); ans.style.display='block'; ans.innerHTML=`<b>Answer</b><div style="white-space:pre-wrap;line-height:1.6;margin-top:8px">${escSafe(data.answer||'No answer returned.')}</div>`; status.textContent=''; awardXP(5,'ai_question');}
      catch(e){status.textContent=e.message||'AI unavailable. Start the backend and configure an AI provider.';}
      finally{btn.disabled=false;}
    };
    document.getElementById('masterUseCameraAI').onclick=()=>{ if(typeof window.openCamera==='function')window.openCamera(); toastSafe('Capture a question, then use the AI search box to ask it.'); };
  }
  function escSafe(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

  async function syncCloud(){
    ensureMasterState(); const u=currentUser(), db=firestore(); if(!u||!db||syncing)return;
    syncing=true;
    try{
      const safe=JSON.parse(JSON.stringify(state,(k,v)=>k==='_blobUrl'||k==='dataUrl'?undefined:v));
      // Keep uploaded binary out of Firestore; files belong in Firebase Storage.
      await db.collection('users').doc(u.uid).set({profile:{name:state.auth?.name||u.displayName||'Student',email:u.email||'',updatedAt:Date.now()},state:safe,updatedAt:Date.now(),masterVersion:'v1'},{merge:true});
    }catch(e){console.warn('Cloud sync failed',e)}finally{syncing=false}
  }
  async function restoreCloud(){
    ensureMasterState(); const u=currentUser(), db=firestore(); if(!u||!db)return false;
    try{
      const snap=await db.collection('users').doc(u.uid).get(); if(!snap.exists)return false;
      const cloud=snap.data()?.state; if(!cloud)return false;
      // Prefer existing local changes only when they are newer than a stored timestamp.
      const localAt=Number(localStorage.getItem(NS+'_updatedAt')||0), cloudAt=Number(snap.data()?.updatedAt||0);
      if(cloudAt>localAt){ window.state=Object.assign(window.state,cloud); if(typeof window.save==='function'&&window.save.__masterWrapped)window.save.__masterOriginal(); else localStorage.setItem('studyzone_final_v13',JSON.stringify(state)); }
      return true;
    }catch(e){console.warn('Cloud restore failed',e);return false}
  }

  function wrapSave(){
    if(typeof window.save!=='function'||window.save.__masterWrapped)return;
    const original=window.save;
    function wrapped(){ original(); localStorage.setItem(NS+'_updatedAt',String(Date.now())); clearTimeout(syncTimer); syncTimer=setTimeout(syncCloud,900); }
    wrapped.__masterWrapped=true; wrapped.__masterOriginal=original; window.save=wrapped;
  }
  function wrapTaskToggle(){
    if(typeof window.toggleTask!=='function'||window.toggleTask.__masterWrapped)return;
    const original=window.toggleTask;
    function wrapped(id){
      const before=state.tasks?.find(t=>t.id===id)?.doneDates?.[typeof window.selectedDay==='string'?window.selectedDay:(typeof window.todayISO==='function'?window.todayISO():'')];
      original(id);
      const after=state.tasks?.find(t=>t.id===id)?.doneDates?.[typeof window.selectedDay==='string'?window.selectedDay:(typeof window.todayISO==='function'?window.todayISO():'')];
      if(!before&&after)awardXP(25,'task_complete');
    }
    wrapped.__masterWrapped=true; window.toggleTask=wrapped;
  }
  function wrapQuizAnswer(){
    if(typeof window.answerQuiz!=='function'||window.answerQuiz.__masterWrapped)return;
    const original=window.answerQuiz;
    function wrapped(i){const before=state.quizCorrectToday||0; original(i); setTimeout(()=>{if((state.quizCorrectToday||0)>before)awardXP(5,'quiz_correct')},20)}
    wrapped.__masterWrapped=true; window.answerQuiz=wrapped;
  }

  function installDiagnostics(){
    const s=document.createElement('style'); s.textContent=`#masterRankBox .progressbar{height:9px;border-radius:99px;background:rgba(255,255,255,.08);overflow:hidden;margin-top:10px}#masterRankBox .progressbar span{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#9b6cff,#52d7ff)}#masterAIAnswer{border-color:rgba(155,108,255,.3);background:rgba(155,108,255,.06)}`;document.head.appendChild(s);
  }

  async function boot(){
    ensureMasterState(); wrapSave(); wrapTaskToggle(); wrapQuizAnswer(); installDiagnostics();
    setTimeout(()=>{injectAISearch();renderGamification();renderEnhancedChallenges();},250);
    if(window.studyZoneAuth){
      window.studyZoneAuth.onAuthStateChanged(async user=>{ if(user){await restoreCloud(); await syncCloud(); renderGamification();renderEnhancedChallenges();} });
    }
    // Re-render enhancements after navigation.
    document.addEventListener('click',e=>{const b=e.target.closest?.('[onclick*="showScreen(\'search\'"]');if(b)setTimeout(injectAISearch,50)});
  }

  window.MasterStudyZone={awardXP,levelInfo,rankInfo,askAI,syncCloud,restoreCloud,renderGamification,renderEnhancedChallenges,claimEnhancedChallenge};
  window.STUDYZONE_API_BASE=window.STUDYZONE_API_BASE||'';
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
