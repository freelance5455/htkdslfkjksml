/* StudyZone Master v2 runtime
   Purpose: turn the earlier scaffold into a testable, coherent browser build.
   - truthful progress metrics (no proxy percentages)
   - idempotent XP/coin rewards
   - question solver: text + image OCR + PDF text extraction -> backend AI
   - visible system diagnostics
   - optional Firebase Storage upload for signed-in users
   - study-session timer and real study minutes
*/
(function(){
'use strict';
const V2='studyzone_master_v2';
const original={};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const today=()=>typeof window.todayISO==='function'?window.todayISO():new Date().toISOString().slice(0,10);
function ensure(){
  window.state=window.state||{};
  state.masterVersion=V2;
  state.xpTotal=Number.isFinite(state.xpTotal)?state.xpTotal:0;
  state.xpLedger=Array.isArray(state.xpLedger)?state.xpLedger:[];
  state.quizStats=state.quizStats||{answered:0,correct:0,byDate:{}};
  state.studyMinutesByDate=state.studyMinutesByDate||{};
  state.challengeClaims=state.challengeClaims||{};
  state.books=(state.books||[]).map(b=>{b.progressPct=Number.isFinite(b.progressPct)?b.progressPct:0; return b});
}
function save(){try{window.save?.()}catch(e){localStorage.setItem('studyzone_final_v13',JSON.stringify(state))}}
function hasReward(key){ensure();return state.xpLedger.some(x=>x.key===key)}
function rewardOnce(key,xp,coins,reason){ensure();if(hasReward(key))return false;state.xpTotal+=Math.max(0,Math.floor(xp||0));state.coins=(state.coins||0)+Math.max(0,Math.floor(coins||0));state.xpLedger.push({id:'v2_'+Date.now().toString(36)+Math.random().toString(36).slice(2,7),key,amount:Math.floor(xp||0),coins:Math.floor(coins||0),reason,at:Date.now()});if(state.xpLedger.length>500)state.xpLedger=state.xpLedger.slice(-500);save();window.MasterStudyZone?.renderGamification?.();return true}
function stats(){
 ensure(); const d=today(), tasks=state.tasks||[];
 const planned=tasks.filter(t=>t.date===d || t.repeatDaily!==false).length;
 const completed=tasks.filter(t=>t.doneDates?.[d]).length;
 const taskPct=planned?Math.min(100,Math.round(completed/planned*100)):0;
 const goal=Math.max(1,parseInt(localStorage.getItem('studyzone_goal')||'60')||60);
 const mins=Math.max(0,Number(state.studyMinutesByDate[d]||0));
 const studyPct=Math.min(100,Math.round(mins/goal*100));
 const claimed=Object.keys(state.challengeClaims||{}).filter(k=>k.endsWith('_'+d)).length;
 const challengePct=Math.min(100,Math.round(claimed/3*100));
 const qs=state.quizStats.byDate?.[d]||{answered:0,correct:0};
 const aiQ=Number(state.aiQuestionsByDate?.[d]||0);
 const answered=Number(qs.answered||0)+aiQ;
 const correct=Number(qs.correct||0);
 const questionPct=answered?Math.min(100,Math.round((correct/answered)*100)):0;
 const overall=Math.round((taskPct+studyPct+challengePct+questionPct)/4);
 const streak=typeof window.calcStreak==='function'?window.calcStreak():0;
 return {taskPct,studyPct,challengePct,questionPct,overall,done:completed,total:planned,mins,goal,answered,correct,streak,xp:state.xpTotal||0,level:Math.floor((state.xpTotal||0)/1000)+1};
}
function renderStats(){
 const s=stats();
 const map={progressOverall:s.overall+'%',progressRing:s.overall+'%',pStudy:s.studyPct+'%',pTasks:s.taskPct+'%',pChallenges:s.challengePct+'%',pQuestions:s.questionPct+'%',progressStreak:s.streak+' days',progressXP:s.xp+' XP',progressLevel:'Level '+s.level,homeProgress:s.overall+'% overall',homeXP:s.xp+' XP',homeLevel:'Level '+s.level};
 Object.entries(map).forEach(([id,v])=>{const e=document.getElementById(id);if(e)e.textContent=v});
 const coach=document.getElementById('coachSummary');if(coach)coach.textContent=`${s.taskPct}% tasks • ${s.studyPct}% study goal • ${s.challengePct}% challenges • ${s.questionPct}% questions`;
}
// Replace the old proxy calculation so percentages describe actual activity.
window.calcStats=stats;
// Make task XP idempotent per task/day.
if(typeof window.toggleTask==='function' && !window.toggleTask.__v2){
 original.toggleTask=window.toggleTask;
 window.toggleTask=function(id){
   ensure();
   const d=window.selectedDay||today();
   const t=state.tasks.find(x=>x.id===id);
   if(!t)return;
   t.doneDates=t.doneDates||{};
   const before=!!t.doneDates[d];
   original.toggleTask(id);
   const after=!!t.doneDates[d];
   if(!before&&after){
     const awarded=rewardOnce(`task:${id}:${d}`,25,5,'task_complete');
     if(awarded) window.toast?.('✓ Task complete • +25 XP • +5 coins');
   }
   renderStats(); window.renderHome?.(); window.renderTasks?.();
 };
 window.toggleTask.__v2=true;
}

// Task data integrity: keep daily completion history instead of deleting/resetting tasks.
// A repeated task is shown for every day, while a dated task appears only on its assigned day.
function normalizeTasks(){
 ensure();
 state.tasks=(state.tasks||[]).map(t=>{
   t.id=t.id||('task_'+Date.now().toString(36)+Math.random().toString(36).slice(2,7));
   t.title=String(t.title||'').trim();
   t.subject=String(t.subject||'').trim();
   t.date=t.date||today();
   t.repeatDaily=t.repeatDaily!==false;
   t.doneDates=(t.doneDates&&typeof t.doneDates==='object')?t.doneDates:{};
   return t;
 }).filter(t=>t.title);
}

// Count real quiz attempts and award once per question/day.
if(typeof window.answerQuiz==='function' && !window.answerQuiz.__v2){
 original.answerQuiz=window.answerQuiz;
 window.answerQuiz=function(i){ensure();const d=today();const before=state.quizCorrectToday||0; original.answerQuiz(i);setTimeout(()=>{const after=state.quizCorrectToday||0;state.quizStats.byDate[d]=state.quizStats.byDate[d]||{answered:0,correct:0};state.quizStats.byDate[d].answered++;if(after>before){state.quizStats.byDate[d].correct++;rewardOnce(`quiz:${d}:${i}:${state.quizStats.byDate[d].answered}`,5,1,'quiz_correct')}save();renderStats()},30)};
 window.answerQuiz.__v2=true;
}
// Study timer
let timer=null,elapsed=0;
function injectStudyTimer(){
 const coach=document.getElementById('coach');if(!coach||document.getElementById('v2StudyTimer'))return;
 const box=document.createElement('div');box.id='v2StudyTimer';box.className='card pad';box.style.marginTop='12px';
 box.innerHTML=`<div class="section-head"><div><div class="section-title">⏱️ Focus session</div><div class="sub">Real study minutes count toward your daily goal.</div></div><span class="badge" id="v2TimerState">READY</span></div><div style="font-size:36px;font-weight:900;text-align:center;margin:12px 0" id="v2Timer">00:00</div><div class="grid2"><button class="btn" id="v2TimerStart">Start</button><button class="btn ghost" id="v2TimerStop" disabled>Stop & Save</button></div>`;
 coach.appendChild(box);
 const out=document.getElementById('v2Timer'),start=document.getElementById('v2TimerStart'),stop=document.getElementById('v2TimerStop'),st=document.getElementById('v2TimerState');
 function paint(){const m=Math.floor(elapsed/60),s=elapsed%60;out.textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')}
 start.onclick=()=>{if(timer)return;elapsed=0;paint();timer=setInterval(()=>{elapsed++;paint()},1000);start.disabled=true;stop.disabled=false;st.textContent='RUNNING'};
 stop.onclick=()=>{if(!timer)return;clearInterval(timer);timer=null;const mins=Math.max(1,Math.round(elapsed/60));const d=today();state.studyMinutesByDate[d]=(state.studyMinutesByDate[d]||0)+mins;rewardOnce(`session:${d}:${Date.now()}`,Math.min(30,mins),Math.min(10,Math.floor(mins/10)),'study_session');save();renderStats();start.disabled=false;stop.disabled=true;st.textContent=`+${mins} min saved`;elapsed=0;paint()};
}
// Question Solver: image OCR + PDF extraction + backend AI.
async function pdfText(file){
 if(!window.pdfjsLib)throw new Error('PDF engine is still loading. Try again in a few seconds.');
 const buf=await file.arrayBuffer();const pdf=await pdfjsLib.getDocument({data:buf}).promise;let text='';const pages=Math.min(pdf.numPages,10);
 for(let p=1;p<=pages;p++){const pg=await pdf.getPage(p);const tc=await pg.getTextContent();text+=tc.items.map(x=>x.str).join(' ')+'\n\n'}
 return text.trim();
}
async function imageText(file,status){
 if(!window.Tesseract)throw new Error('OCR engine is still loading. Try again in a few seconds.');
 status.textContent='Reading image…';const r=await Tesseract.recognize(file,'eng',{logger:m=>{if(m.status)status.textContent=`OCR: ${m.status} ${m.progress?Math.round(m.progress*100):0}%`}});return r.data.text.trim();
}
function injectQuestionLab(){
 const screen=document.getElementById('search');if(!screen||document.getElementById('v2QuestionLab'))return;
 const box=document.createElement('div');box.id='v2QuestionLab';box.className='card pad';box.style.marginTop='12px';
 box.innerHTML=`<div class="section-head"><div><div class="section-title">📸 Question Solver</div><div class="sub">Type a question, upload a photo/PDF, or capture a page. OCR/text extraction runs in your browser; the answer comes from your configured AI backend.</div></div><span class="badge">V2</span></div><textarea id="v2Question" class="textarea" rows="5" placeholder="Type or paste the question here…"></textarea><div class="grid2" style="margin-top:8px"><label class="btn ghost" style="text-align:center;cursor:pointer">📎 Photo/PDF<input id="v2File" type="file" accept="image/*,.pdf,.txt,.md,.csv" hidden></label><button class="btn ghost" id="v2Camera">📷 Camera</button></div><div id="v2Status" class="sub" style="margin-top:8px"></div><button class="btn full" id="v2Solve" style="margin-top:8px">Solve step by step →</button><div id="v2Answer" class="card pad" style="display:none;margin-top:10px"></div>`;
 screen.insertBefore(box,screen.firstChild);
 const q=document.getElementById('v2Question'),file=document.getElementById('v2File'),status=document.getElementById('v2Status'),ans=document.getElementById('v2Answer');
 file.onchange=async()=>{const f=file.files?.[0];if(!f)return;try{status.textContent='Processing…';let text='';if(f.type.startsWith('image/'))text=await imageText(f,status);else if(f.type==='application/pdf'||f.name.toLowerCase().endsWith('.pdf'))text=await pdfText(f);else text=await f.text();q.value=(q.value? q.value+'\n\n':'')+text.slice(0,20000);status.textContent=`Loaded ${f.name}`;}catch(e){status.textContent=e.message||'Could not read that file.'}file.value=''};
 document.getElementById('v2Camera').onclick=()=>{window.__v2QuestionCapture=true;window.openCamera?.();status.textContent='Capture the question, then tap Save scan.'};
 document.getElementById('v2Solve').onclick=async()=>{const question=q.value.trim();if(!question)return status.textContent='Enter or capture a question first.';const btn=document.getElementById('v2Solve');btn.disabled=true;status.textContent='Sending to AI…';ans.style.display='none';try{const data=await window.MasterStudyZone.askAI(question);ans.style.display='block';ans.innerHTML=`<b>Step-by-step answer</b><div style="white-space:pre-wrap;line-height:1.65;margin-top:8px">${esc(data.answer||'No answer returned.')}</div>`;state.aiQuestionsByDate=state.aiQuestionsByDate||{};state.aiQuestionsByDate[today()]=(state.aiQuestionsByDate[today()]||0)+1;rewardOnce(`ai:${today()}:${Date.now()}`,5,1,'ai_question');save();renderStats()}catch(e){status.textContent=e.message||'AI request failed. Check the backend configuration.'}finally{btn.disabled=false}};
}
// System diagnostics visible in Settings.
function injectDiagnostics(){
 const screen=document.getElementById('settings');if(!screen||document.getElementById('v2Diagnostics'))return;
 const box=document.createElement('div');box.id='v2Diagnostics';box.className='card pad';box.style.marginTop='12px';screen.appendChild(box);
 const rows=[];
 rows.push(['Frontend','OK','This build is running.']);
 rows.push(['IndexedDB','indexedDB' in window?'OK':'FAIL','Used for local book/file storage.']);
 rows.push(['Camera API',navigator.mediaDevices?.getUserMedia?'Available':'Fallback only','HTTPS is required for live camera preview.']);
 rows.push(['Firebase SDK',window.studyZoneAuth?'Loaded':'Not loaded','Auth is required for cloud account features.']);
 rows.push(['AI backend','Not tested yet','Use Question Solver to test /api/ai/ask.']);
 box.innerHTML=`<div class="section-head"><div><div class="section-title">🧪 System check</div><div class="sub">This reports what the current browser build can actually access.</div></div><span class="badge">V2</span></div>`+rows.map(r=>`<div class="setting"><div><b>${r[0]}</b><div class="sub">${r[2]}</div></div><span class="badge">${r[1]}</span></div>`).join('');
}
// Optional cloud upload wrapper for newly imported files.
async function uploadToStorage(file,book){try{const u=window.studyZoneAuth?.currentUser;if(!u||!window.firebase?.storage||!file||!book)return;const ref=firebase.storage().ref(`users/${u.uid}/books/${book.id}/${book.fileName||file.name}`);await ref.put(file);book.storagePath=ref.fullPath;book.cloudStored=true;save();}catch(e){console.warn('Storage upload skipped',e)}}
if(typeof window.handleBookFile==='function'&&!window.handleBookFile.__v2){original.handleBookFile=window.handleBookFile;window.handleBookFile=async function(file,existingId){await original.handleBookFile(file,existingId);const id=existingId||[...state.books].at(-1)?.id;const b=state.books.find(x=>x.id===id);await uploadToStorage(file,b)};window.handleBookFile.__v2=true}

// --- v2.4 Gamification layer ------------------------------------------------
function gamification(){
  ensure();
  const d=today(), tasks=state.tasks||[];
  const completedToday=tasks.filter(t=>t.doneDates?.[d]).length;
  const studyMinutes=Number(state.studyMinutesByDate?.[d]||0);
  const xp=Number(state.xpTotal||0);
  const coins=Number(state.coins||0);
  const streak=typeof window.calcStreak==='function'?Number(window.calcStreak()||0):0;

  state.gamification=state.gamification||{achievements:{}};
  state.gamification.achievements=state.gamification.achievements||{};

  const rules=[
    ['first_task','First Step','Complete your first task','🎯',completedToday>=1 || tasks.some(t=>Object.keys(t.doneDates||{}).length>0)],
    ['ten_tasks','Getting Serious','Complete 10 tasks','🔥',tasks.reduce((n,t)=>n+Object.keys(t.doneDates||{}).length,0)>=10],
    ['seven_streak','7-Day Streak','Maintain a 7-day study streak','🗓️',streak>=7],
    ['hundred_minutes','Focused','Study for 100 total minutes','⏱️',Object.values(state.studyMinutesByDate||{}).reduce((a,v)=>a+Number(v||0),0)>=100],
    ['thousand_xp','XP Hunter','Earn 1,000 XP','⭐',xp>=1000],
    ['five_thousand_xp','Study Legend','Earn 5,000 XP','🏆',xp>=5000]
  ];
  let changed=false;
  for(const [id,name,desc,icon,ok] of rules){
    if(ok&&!state.gamification.achievements[id]){
      state.gamification.achievements[id]={name,desc,icon,unlockedAt:Date.now()};
      state.coins=(Number(state.coins)||0)+20;
      changed=true;
      window.toast?.(`${icon} Achievement unlocked: ${name} • +20 coins`);
    }
  }

  // Expose one canonical summary for UI integrations.
  const level=Math.floor(xp/1000)+1;
  const levelXP=xp%1000;
  const summary={xp,coins,level,levelXP,levelPct:Math.min(100,Math.round(levelXP/1000*100)),streak,completedToday,studyMinutes,achievements:Object.values(state.gamification.achievements)};
  window.StudyZoneV2.gamification=summary;
  return summary;
}

function boot(){ensure();normalizeTasks();gamification();renderStats();setTimeout(()=>{injectQuestionLab();injectStudyTimer();injectDiagnostics();gamification();renderStats()},350);document.addEventListener('click',e=>{const b=e.target.closest?.('[onclick*="showScreen(\'search\'"]');if(b)setTimeout(injectQuestionLab,80)});}
window.StudyZoneV2={stats,rewardOnce,renderStats,gamification};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
