// Optional: copy to runtime-config.js for local development.
// Keep secrets out of this file.
window.STUDYZONE_API_BASE='http://localhost:8787';
