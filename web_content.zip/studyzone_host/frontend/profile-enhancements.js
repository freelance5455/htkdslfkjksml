/* StudyZone v2.9 — Profile, Preferences & Feedback
   Adds a durable profile-preferences layer without replacing existing auth/UI.
*/
(function(){
  'use strict';
  const KEY='studyzone_profile_prefs_v29';
  const get=()=>window.state||{};
  const uid=()=>get().auth?.uid||window.studyZoneAuth?.currentUser?.uid||'guest';
  function ensure(){
    const s=get();
    s.profilePrefs=Object.assign({dailyGoalMinutes:60,studyReminder:false,reminderTime:'19:00',compactMode:false},s.profilePrefs||{});
    if(!Number.isFinite(Number(s.profilePrefs.dailyGoalMinutes)))s.profilePrefs.dailyGoalMinutes=60;
    return s.profilePrefs;
  }
  function persist(){
    try{ window.save?.(); }catch(e){ localStorage.setItem(KEY,JSON.stringify(ensure())); }
  }
  function refresh(){
    const p=ensure();
    const goal=document.getElementById('studyGoalSummary'); if(goal)goal.textContent=`${p.dailyGoalMinutes} min/day`;
    const rem=document.getElementById('reminderSummary'); if(rem)rem.textContent=p.studyReminder?`On • ${p.reminderTime}`:'Off';
    const compact=document.getElementById('compactSummary'); if(compact)compact.textContent=p.compactMode?'On':'Off';
    const input=document.getElementById('profileDailyGoal'); if(input)input.value=p.dailyGoalMinutes;
  }
  window.openProfilePreferences=function(){
    const p=ensure();
    openModal(`<div class="row"><div><div class="eyebrow">PREFERENCES</div><h2>Study Plan</h2></div><button class="close" onclick="closeModal()">✕</button></div>
      <form id="v29PrefForm" class="stack" style="margin-top:12px">
      <div class="field"><label>Daily study goal (minutes)</label><input class="input" id="profileDailyGoal" name="goal" type="number" min="10" max="600" step="5" value="${p.dailyGoalMinutes}"></div>
      <div class="setting"><div><b>Study reminder</b><div class="sub">Keep a reminder preference for the future notification system.</div></div><input name="reminder" type="checkbox" ${p.studyReminder?'checked':''}></div>
      <div class="field"><label>Preferred reminder time</label><input class="input" name="time" type="time" value="${p.reminderTime}"></div>
      <div class="setting"><div><b>Compact cards</b><div class="sub">Use tighter spacing on supported dashboard cards.</div></div><input name="compact" type="checkbox" ${p.compactMode?'checked':''}></div>
      <button class="btn full">Save preferences →</button></form>`);
    document.getElementById('v29PrefForm').onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);p.dailyGoalMinutes=Math.max(10,Math.min(600,Number(f.get('goal'))||60));p.studyReminder=f.get('reminder')==='on';p.reminderTime=String(f.get('time')||'19:00');p.compactMode=f.get('compact')==='on';
      // Keep the legacy dashboard calculation compatible with the new canonical value.
      localStorage.setItem('studyzone_goal',String(p.dailyGoalMinutes));
      document.body.classList.toggle('v29-compact',p.compactMode);persist();refresh();closeModal();renderProfile?.();renderHome?.();toast('Study preferences saved');playSound?.('success');};
  };
  window.openFeedback=window.openFeedback||function(){};
  window.openV29Feedback=function(){
    openModal(`<div class="row"><div><div class="eyebrow">FEEDBACK</div><h2>Help improve StudyZone</h2></div><button class="close" onclick="closeModal()">✕</button></div>
      <form id="v29Feedback" class="stack" style="margin-top:12px">
      <div class="field"><label>Rating</label><select class="input" name="rating"><option value="5">5 — Excellent</option><option value="4">4 — Good</option><option value="3">3 — Okay</option><option value="2">2 — Needs work</option><option value="1">1 — Poor</option></select></div>
      <div class="field"><label>Feedback</label><textarea class="textarea" name="text" required maxlength="2000" placeholder="What should we improve?"></textarea></div>
      <button class="btn full">Save feedback →</button></form>`);
    document.getElementById('v29Feedback').onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);const s=get();s.feedback=Array.isArray(s.feedback)?s.feedback:[];s.feedback.push({id:'fb_'+Date.now().toString(36),type:'review',rating:Number(f.get('rating'))||5,text:String(f.get('text')||'').trim(),date:Date.now(),uid:uid()});persist();closeModal();toast('Thanks — feedback saved');playSound?.('success');};
  };
  function inject(){
    if(document.getElementById('v29-profile-tools'))return;
    const profile=document.getElementById('profile');
    if(profile){
      const wrap=document.createElement('div');wrap.id='v29-profile-tools';wrap.className='card pad stack';
      wrap.innerHTML=`<div class="setting"><div><b>Daily study goal</b><div class="sub" id="studyGoalSummary">60 min/day</div></div><button class="link" onclick="openProfilePreferences()">Edit</button></div>
      <div class="setting"><div><b>Study reminder</b><div class="sub" id="reminderSummary">Off</div></div></div>
      <div class="setting"><div><b>Compact cards</b><div class="sub" id="compactSummary">Off</div></div></div>
      <button class="btn ghost full" onclick="openV29Feedback()">⭐ Rate / review StudyZone</button>`;
      const buttons=profile.querySelector('.stack:last-of-type'); if(buttons)buttons.before(wrap); else profile.appendChild(wrap);
    }
    const style=document.createElement('style');style.textContent='.v29-compact .card{padding:12px}.v29-compact .task{padding:9px!important}.v29-compact .section{margin-bottom:8px!important}';document.head.appendChild(style);
    document.body.classList.toggle('v29-compact',!!ensure().compactMode);refresh();
  }
  document.addEventListener('DOMContentLoaded',inject);
  window.addEventListener('load',()=>{inject();refresh()});
  setTimeout(()=>{ensure();refresh()},500);
})();
