# StudyZone v3 — Security / Production Hardening

## What changed
- AI requests now require a Firebase Authentication ID token.
- Browser sends the signed-in user's ID token in `Authorization: Bearer ...`.
- Backend verifies the token with Firebase Admin SDK before calling the AI provider.
- CORS is deny-by-default when `CORS_ORIGIN` is configured.
- Firestore explicitly denies all collections other than a user's own `/users/{uid}` document.
- Storage explicitly denies paths outside `/users/{uid}/...`.

## Backend environment
Set these on the backend host; never put them in frontend files:

- `OPENAI_API_KEY`
- `OPENAI_MODEL`
- `CORS_ORIGIN`
- `FIREBASE_PROJECT_ID`
- `FIREBASE_CLIENT_EMAIL`
- `FIREBASE_PRIVATE_KEY`

For Firebase Admin credentials, use a service-account identity/secret mechanism supported by your deployment platform. Do not commit the service-account JSON or private key to Git or the ZIP.

## Important
The Firebase Web API key in `frontend/firebase-config.js` is not an AI secret. It identifies the web app. The Firebase Admin private key and OpenAI API key are server secrets.

## Verification checklist
1. Sign in.
2. Ask AI: it should work only with a valid Firebase session.
3. Sign out and call the AI endpoint: it should return 401.
4. Verify one user cannot read another user's `/users/{uid}` document.
5. Verify Storage paths outside the signed-in user's UID are denied.
6. Set `CORS_ORIGIN` to the exact production Firebase Hosting origin(s).
