import Fastify from 'fastify';
import cors from '@fastify/cors';
import rateLimit from '@fastify/rate-limit';
import OpenAI from 'openai';
import { z } from 'zod';
import { cert, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';

const app=Fastify({logger:true});
const allowedOrigins=process.env.CORS_ORIGIN?process.env.CORS_ORIGIN.split(',').map(x=>x.trim()).filter(Boolean):[];
await app.register(cors,{origin:(origin,cb)=>{
  if(!origin || allowedOrigins.length===0 || allowedOrigins.includes(origin)) return cb(null,true);
  return cb(new Error('Origin not allowed'),false);
}});
await app.register(rateLimit,{max:30,timeWindow:'1 minute'});

const AskSchema=z.object({
  question:z.string().min(2).max(8000),
  className:z.string().max(50).optional(),
  board:z.string().max(100).optional(),
  stream:z.string().max(100).optional(),
  subject:z.string().max(100).optional(),
  chapter:z.string().max(200).optional(),
  book:z.string().max(200).optional(),
  books:z.array(z.object({id:z.string(),name:z.string(),subject:z.string().optional(),author:z.string().optional(),chapters:z.array(z.string()).optional()})).max(20).optional()
});

function firebaseAuth(){
  if(!getApps().length){
    initializeApp(process.env.FIREBASE_PROJECT_ID ? {credential: cert({
      projectId:process.env.FIREBASE_PROJECT_ID,
      clientEmail:process.env.FIREBASE_CLIENT_EMAIL,
      privateKey:(process.env.FIREBASE_PRIVATE_KEY||'').replace(/\\n/g,'\n')
    })} : undefined);
  }
  return getAuth();
}

async function requireUser(req:any,reply:any){
  const header=String(req.headers.authorization||'');
  if(!header.startsWith('Bearer ')) return reply.code(401).send({error:'Authentication required.'});
  try{
    const token=header.slice(7).trim();
    if(!token) throw new Error('Missing token');
    const decoded=await firebaseAuth().verifyIdToken(token);
    req.user=decoded;
  }catch(err){
    req.log.warn({err},'Invalid Firebase ID token');
    return reply.code(401).send({error:'Invalid or expired authentication token.'});
  }
}

app.get('/health',async()=>({ok:true,service:'studyzone-backend',version:'v3',aiConfigured:!!process.env.OPENAI_API_KEY,authRequired:true}));

app.post('/api/ai/ask',{preHandler:requireUser},async(req:any,reply)=>{
  const parsed=AskSchema.safeParse(req.body);
  if(!parsed.success)return reply.code(400).send({error:'Invalid AI request.'});
  if(!process.env.OPENAI_API_KEY)return reply.code(503).send({error:'AI backend is not configured yet. Add OPENAI_API_KEY to backend environment.'});
  const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
  const x=parsed.data;
  const context=[
    `Class: ${x.className||'not specified'}`,
    `Board: ${x.board||'not specified'}`,
    `Stream: ${x.stream||'not specified'}`,
    `Subject: ${x.subject||'not specified'}`,
    `Chapter: ${x.chapter||'not specified'}`,
    `Book: ${x.book||'not specified'}`,
    `Registered books: ${(x.books||[]).map(b=>`${b.name} [${b.subject||''}] chapters: ${(b.chapters||[]).slice(0,20).join(', ')}`).join(' | ')}`
  ].join('\n');
  try{
    const response=await client.responses.create({model:process.env.OPENAI_MODEL||'gpt-5-mini',input:[
      {role:'system',content:[{type:'input_text',text:'You are StudyZone AI, a careful school study tutor. Explain at the student\'s level, prefer the student\'s class/subject/book context, show steps for numerical problems, clearly mark uncertainty, and do not invent textbook wording or page numbers. Keep answers structured and useful.'}]},
      {role:'user',content:[{type:'input_text',text:`STUDENT CONTEXT\n${context}\n\nQUESTION\n${x.question}`}]}
    ]});
    return {answer:response.output_text||'No answer returned.',model:process.env.OPENAI_MODEL||'gpt-5-mini',userId:req.user.uid};
  }catch(err){req.log.error(err);return reply.code(502).send({error:'AI provider request failed.'});}
});

const port=Number(process.env.PORT||8787);
await app.listen({port,host:'0.0.0.0'});
