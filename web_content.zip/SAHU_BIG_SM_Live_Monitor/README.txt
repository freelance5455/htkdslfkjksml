SAHU BIG SM Live Result Monitor Demo

Android Studio project source. Simulated random BIG/SMALL results only; no external game connection or prediction.

Build: Open this folder in Android Studio, sync Gradle, then Build > Build APK(s). Debug APK appears in app/build/outputs/apk/debug/.
