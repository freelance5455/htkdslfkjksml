# Jagdamba Fuel Station Android App

This Android Studio project packages the current v27 HTML management software inside a WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on the Android phone.

The HTML app is bundled at `app/src/main/assets/index.html` and does not require Chrome to run.
