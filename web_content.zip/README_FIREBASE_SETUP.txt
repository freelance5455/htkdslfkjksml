SHIKSHA — FINAL FIREBASE CONNECTION SETUP

Files:
1. Shiksha_Student_Firebase.html — student app; keeps demo locks and class/board isolation.
2. Shiksha_Admin_Firebase.html — separate admin uploader.
3. firebase-config.js — reference config file (the two HTML files currently contain a clearly marked config block too).
4. firestore.rules / storage.rules — use the rules from the previous Shiksha Firebase starter package.

Firebase setup:
1. Create a Firebase project.
2. Add a Web App and copy its config.
3. Enable Authentication -> Sign-in method -> Email/Password.
4. Create the admin account in Firebase Authentication.
5. Enable Firestore Database.
6. Enable Storage.
7. Create Firestore document: admins/{ADMIN_UID} with { role: "admin" }.
8. Publish the Firestore and Storage security rules from the starter package.
9. Put the same Firebase config into the marked firebaseConfig object in BOTH HTML files.
10. Host the HTML files (recommended) instead of opening them as file:// pages.

Student behavior:
- Class 11 and 12 stay locked with Demo Version popup.
- Class 9/10 ICSE and State Board stay locked.
- Only Class 9 CBSE and Class 10 CBSE proceed.
- Material -> category -> subject -> Firebase files.
- Every upload is rendered separately; repeated uploads are not collapsed.
- Queries filter class + board + category + subject.

Admin behavior:
- Firebase Authentication controls login.
- Upload asks category, subject, class and board.
- Files go to Firebase Storage.
- Metadata goes to Firestore.
- Delete removes the Firestore record and attempts to remove the Storage file.

Security note:
Do not publish a real admin password inside HTML. Firebase Authentication is used instead.
