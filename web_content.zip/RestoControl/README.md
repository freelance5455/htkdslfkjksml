# RESTO CONTROL — Your Restaurant. Your Business. Under Control.

Fully offline restaurant management app (HTML + CSS + vanilla JavaScript + IndexedDB + Service Worker + PWA).

## Files (all must stay in this structure)

```
index.html
style.css
manifest.json
sw.js
js/ethcal.js     Ethiopian <-> Gregorian conversion (exact, offline)
js/calc.js       Profit, salary, attendance, stock calculations
js/db.js         IndexedDB database (one database per restaurant)
js/app.js        The application screens and logic
icons/icon-192.png
icons/icon-512.png
```

## How to put it on a phone (one-time, needs internet ONCE)

A PWA can only be installed from an https address (a file on the phone is not enough).
Host the folder for free, open the link once, install, then it works in airplane mode.

1. Unzip the zip on the phone (Files app → tap the zip → Extract).
2. Upload the folder to a free host from the phone browser, e.g. Netlify Drop (app.netlify.com/drop), Cloudflare Pages, or GitHub Pages. Keep the folder structure.
3. Open your link in Chrome on the phone → menu (⋮) → **Install app** / **Add to Home screen**.
4. Open the app once while online so everything is cached, then try airplane mode.

For each new restaurant customer: open the same link on THEIR phone, install, and create their restaurant on first launch (name, owner account). Logo, phone, address, currency, language, calendar and theme color are in More → Settings. Data is stored only on that phone.

## When you change any file
Edit `VERSION` in `sw.js` (for example `resto-control-v3`) so phones download the update.

## What was tested (Chrome, 390px phone size, Africa/Addis_Ababa)
- Ethiopian calendar: new-year anchors, leap years, Pagume, and a day-by-day round trip over 200 years (`test-cal.js`).
- Calculations: profit, advances, unpaid salary, attendance totals, stock levels, CSV (`test-calc.js`).
- Real browser run: create restaurant, login, employee, attendance, salary advance, sale, expense, menu, order and payment, stock use and low-stock warning, report CSV export, backup download, reload persistence, offline reload, restore, wrong password rejected, employee account hides money screens.
- NOT tested on a real Android phone. Please test one full day with fake data before using it with a real customer.

## Important rules in the app
- Profit = Sales − Expenses − Salary actually paid. Unpaid salary is shown separately as a liability.
- Attendance never pays or reduces salary. Only recorded payments and advances change what is owed.
- Payroll months are always Ethiopian months (even if the display calendar is Gregorian).
- Dates are stored internally as Gregorian ISO dates (YYYY-MM-DD) and shown in the chosen calendar, so original values are preserved.
- "Today" always uses Africa/Addis_Ababa time, whatever the phone's time zone says.

## Security: honest limits
Passwords only block casual access inside the app. The data is a normal browser database on the phone; anyone with the unlocked phone or technical skill can reach it, and clearing the app/browser data deletes everything. Use a phone screen lock and download a backup file every week (More → Settings → Backup), then send it to another phone or email.
