const C=require('./js/ethcal.js');let f=0;
function eq(a,b,m){const ok=JSON.stringify(a)===JSON.stringify(b);if(!ok){f++;console.log('FAIL',m,JSON.stringify(a),'!=',JSON.stringify(b));}else console.log('ok',m);}
eq(C.isoToEth('2023-09-11'),{y:2015,m:13,d:6},'11 Sep 2023 = Pagume 6 2015 (leap)');
eq(C.isoToEth('2023-09-12'),{y:2016,m:1,d:1},'12 Sep 2023 = Meskerem 1 2016');
eq(C.isoToEth('2024-09-11'),{y:2017,m:1,d:1},'11 Sep 2024 = Meskerem 1 2017');
eq(C.isoToEth('2026-09-11'),{y:2019,m:1,d:1},'11 Sep 2026 = Meskerem 1 2019');
eq(C.isoToEth('2026-10-31'),{y:2019,m:2,d:21},'31 Oct 2026 = Tikimt 21 2019');
eq(C.isoToEth('2024-01-07'),{y:2016,m:4,d:28},'7 Jan 2024 = Tahsas 28 2016');
eq(C.isoToEth('2024-01-08'),{y:2016,m:4,d:29},'8 Jan 2024 = Tahsas 29 (Meskerem 1 + 118 days)');eq(C.isoToEth('2024-01-10'),{y:2016,m:5,d:1},'10 Jan 2024 = Tir 1');
eq(C.isoToEth('2000-01-01'),{y:1992,m:4,d:22},'1 Jan 2000 = Tahsas 22 1992');
eq(C.ethToIso(2016,1,1),'2023-09-12','eth->greg 2016-1-1');
eq(C.ethToIso(2015,13,6),'2023-09-11','eth->greg Pagume 6 2015');
eq(C.isEthValid(2015,13,6),true,'2015 Pagume 6 valid');
eq(C.isEthValid(2016,13,6),false,'2016 Pagume 6 invalid');
eq(C.weekday('2026-10-31'),6,'31 Oct 2026 is Saturday');
eq(C.todayIso(Date.UTC(2026,9,31,21,30)),'2026-11-01','Addis date after 21:00 UTC rolls over');
eq(C.addDays('2024-02-28',2),'2024-03-01','addDays leap');
// full round-trip 1900-2100 every day
let bad=0,s='1900-01-01';for(let i=0;i<73000;i++){const e=C.isoToEth(s);if(!C.isEthValid(e.y,e.m,e.d)||C.ethToIso(e.y,e.m,e.d)!==s){bad++;}s=C.addDays(s,1);}
eq(bad,0,'round trip 200 years, '+s);
console.log(f?'FAILURES '+f:'ALL PASSED');
