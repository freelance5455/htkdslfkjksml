/* RESTO CONTROL - main application. Vanilla JS, fully offline. */
(function () {
'use strict';
var Cal = EthCal, K = Calc, D = DB;
var $ = function (s) { return document.querySelector(s); };
var S = { lang: 'en', cal: 'eth', cur: 'ETB', color: '#16a34a', name: 'Restaurant', logo: '', phone: '', address: '', user: null, tab: 'home', sub: '', date: Cal.todayIso(), per: 'day', draft: { items: [], table: '' }, rp: { kind: 'financial' }, edit: null, empView: null };

/* ---------- translations (English text is the key) ---------- */
var AM = { 'Home':'ዋና','Orders':'ትዕዛዞች','Money':'ገንዘብ','Staff':'ሠራተኞች','More':'ተጨማሪ','Stock':'ክምችት','Sales':'ሽያጭ','Expenses':'ወጪዎች','Summary':'ማጠቃለያ','Income':'ገቢ','Profit':'ትርፍ','Today':'ዛሬ','Save':'አስቀምጥ','Cancel':'ሰርዝ','Delete':'ሰርዝ','Edit':'አስተካክል','Add':'ጨምር','Name':'ስም','Phone':'ስልክ','Address':'አድራሻ','Amount':'መጠን','Date':'ቀን','Note':'ማስታወሻ','Present':'ተገኝቷል','Absent':'ቀርቷል','Late':'ዘግይቷል','Half-day':'ግማሽ ቀን','Leave':'ፈቃድ','Employees':'ሠራተኞች','Attendance':'መገኘት','Salary':'ደመወዝ','Reports':'ሪፖርቶች','Settings':'ቅንብሮች','Login':'ግባ','Logout':'ውጣ','Username':'የተጠቃሚ ስም','Password':'የይለፍ ቃል','Cash':'ጥሬ ገንዘብ','Telebirr':'ቴሌብር','Other':'ሌላ','Pending':'በመጠባበቅ ላይ','Completed':'ተጠናቋል','Cancelled':'ተሰርዟል','Total':'ጠቅላላ','Inventory':'ክምችት','Language':'ቋንቋ','Calendar':'የቀን አቆጣጠር','Backup':'ምትኬ','Restore':'መልስ' };
function t(k) { return S.lang === 'am' && AM[k] ? AM[k] : k; }

/* ---------- helpers ---------- */
function esc(v) { return String(v === undefined || v === null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function money(n) { n = K.num(n); return n.toLocaleString('en-US', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 }) + ' ' + esc(S.cur); }
function fd(iso) { return Cal.fmt(iso, S.cal, S.lang); }
function names() { return S.lang === 'am' ? Cal.MONTHS_AM : Cal.MONTHS_EN; }
function toast(m) { var e = $('#toast'); e.textContent = m; e.className = 'show'; clearTimeout(toast.t); toast.t = setTimeout(function () { e.className = ''; }, 2300); }
function v(id) { var e = $('#' + id); return e ? e.value.trim() : ''; }
function today() { return Cal.todayIso(); }
var ICONS = { home: '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>', receipt: '<path d="M6 2h12v20l-3-2-3 2-3-2-3 2z"/><path d="M9 7h6M9 11h6M9 15h4"/>', wallet: '<rect x="2" y="6" width="20" height="14" rx="2"/><path d="M2 10h20M16 15h2"/>', users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 21c0-4 3-6 7-6s7 2 7 6"/><circle cx="17.5" cy="9" r="2.5"/><path d="M17 15c3 0 5 1.5 5 5"/>', menu: '<path d="M3 6h18M3 12h18M3 18h18"/>', box: '<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>' };
function ic(n) { return '<svg class="i" viewBox="0 0 24 24">' + ICONS[n] + '</svg>'; }

function dateField(id, iso, back) {
  iso = iso || S.date;
  if (S.cal === 'greg') return '<input type="date" id="' + id + '" value="' + iso + '">';
  var e = Cal.isoToEth(iso), d = '', m = '', y = '', i;
  for (i = 1; i <= 30; i++) d += '<option' + (i === e.d ? ' selected' : '') + '>' + i + '</option>';
  names().forEach(function (n, k) { m += '<option value="' + (k + 1) + '"' + (k + 1 === e.m ? ' selected' : '') + '>' + n + '</option>'; });
  for (i = e.y - (back || 6); i <= e.y + 2; i++) y += '<option' + (i === e.y ? ' selected' : '') + '>' + i + '</option>';
  return '<div class="dt" id="' + id + '"><select class="d">' + d + '</select><select class="m">' + m + '</select><select class="y">' + y + '</select></div>';
}
function readDate(id) {
  var el = $('#' + id);
  if (el.tagName === 'INPUT') return el.value || S.date;
  var y = +el.querySelector('.y').value, m = +el.querySelector('.m').value, d = +el.querySelector('.d').value;
  return Cal.ethToIso(y, m, Math.min(d, Cal.ethMonthDays(y, m)));
}
function datebar() {
  return '<div class="card" data-c="bar"><label style="margin-top:0">' + t('Date') + ' · <b>' + Cal.DAYS_EN[Cal.weekday(S.date)] + '</b></label>' + dateField('bar', S.date) + '<button class="btn sm ghost" data-a="today">' + t('Today') + '</button><button class="btn sm ghost" data-a="step" data-n="-1">◀</button><button class="btn sm ghost" data-a="step" data-n="1">▶</button></div>';
}
function range(per) {
  if (per === 'day') return [S.date, S.date];
  var e = Cal.isoToEth(S.date), g = Cal.parseIso(S.date);
  if (S.cal === 'greg') return per === 'month' ? K.gMonthRange(g.y, g.m) : K.gYearRange(g.y);
  return per === 'month' ? K.monthRange(e.y, e.m) : K.yearRange(e.y);
}
function periodLabel(per) {
  if (per === 'day') return fd(S.date);
  var e = Cal.isoToEth(S.date), g = Cal.parseIso(S.date);
  if (S.cal === 'greg') return per === 'month' ? Cal.G_MONTHS[g.m - 1] + ' ' + g.y : String(g.y);
  return per === 'month' ? names()[e.m - 1] + ' ' + e.y : String(e.y);
}
function perSeg() {
  return '<div class="seg">' + [['day', 'Daily'], ['month', 'Monthly'], ['year', 'Yearly']].map(function (p) { return '<button class="' + (S.per === p[0] ? 'on' : '') + '" data-a="per" data-v="' + p[0] + '">' + p[1] + '</button>'; }).join('') + '</div>';
}
function seg(items, cur, action) {
  return '<div class="seg">' + items.map(function (p) { return '<button class="' + (cur === p[0] ? 'on' : '') + '" data-a="' + action + '" data-v="' + p[0] + '">' + t(p[1]) + '</button>'; }).join('') + '</div>';
}
function payMonthSelect(id, key) {
  var cur = Math.floor(key / 100), cm = key % 100, o = '', y, m;
  for (y = cur - 1; y <= cur + 1; y++) for (m = 1; m <= 13; m++) { var k = y * 100 + m; o += '<option value="' + k + '"' + (k === key ? ' selected' : '') + '>' + names()[m - 1] + ' ' + y + '</option>'; }
  return '<select id="' + id + '">' + o + '</select>';
}
function keyLabel(k) { return names()[k % 100 - 1] + ' ' + Math.floor(k / 100); }
function download(name, text, mime) {
  var b = new Blob(['﻿' + text], { type: mime + ';charset=utf-8' }), a = document.createElement('a');
  a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800);
}
function log(action, detail) { return D.put('activity', { ts: new Date().toISOString(), user: S.user ? S.user.username : '-', action: action, detail: detail || '' }); }
async function hashPw(p, salt) {
  var s = salt + ':' + p;
  if (window.crypto && crypto.subtle) { var b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return Array.from(new Uint8Array(b)).map(function (x) { return x.toString(16).padStart(2, '0'); }).join(''); }
  var h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0; return 'x' + h;
}
function isOwner() { return S.user && S.user.role === 'owner'; }
function sortBy(arr, f, desc) { return arr.slice().sort(function (a, b) { return (f(a) < f(b) ? -1 : f(a) > f(b) ? 1 : 0) * (desc ? -1 : 1); }); }
function addrTime(ts) { return Cal.nowTime(Date.parse(ts)); }
function addrDate(ts) { return Cal.todayIso(Date.parse(ts)); }

/* ---------- settings / theme ---------- */
async function loadSettings() {
  S.name = await D.getSetting('name', 'Restaurant'); S.logo = await D.getSetting('logo', ''); S.phone = await D.getSetting('phone', ''); S.address = await D.getSetting('address', '');
  S.cur = await D.getSetting('cur', 'ETB'); S.lang = await D.getSetting('lang', 'en'); S.cal = await D.getSetting('cal', 'eth'); S.color = await D.getSetting('color', '#16a34a');
  document.documentElement.style.setProperty('--accent', S.color);
  document.title = S.name + ' · RESTO CONTROL';
}

/* ---------- boot / login ---------- */
async function boot() {
  var reg = D.registry();
  if (!reg.length) return setupScreen(true);
  var last = localStorage.getItem('resto_last'), id = reg.some(function (r) { return r.id === last; }) ? last : reg[0].id;
  await D.open(id); await loadSettings(); loginScreen();
}
function brand() { return '<img class="logo-big" src="' + (S.logo || 'icons/icon-192.png') + '" alt="">'; }
function setupScreen(first) {
  $('#app').innerHTML = '<div class="login">' + (first ? '<img class="logo-big" src="icons/icon-192.png" alt=""><h1>RESTO CONTROL</h1><p>Your Restaurant. Your Business. Under Control.</p>' : '<h2>New restaurant (separate data)</h2>') +
    '<div class="card"><label>Restaurant name</label><input id="s_name"><label>Owner full name</label><input id="s_owner"><label>Owner username</label><input id="s_user" autocapitalize="none"><label>Owner password (min 4 characters)</label><input id="s_pw" type="password">' +
    '<button class="btn" data-a="createRestaurant">Create restaurant</button>' + (first ? '' : '<button class="btn ghost" data-a="tab" data-v="more">Cancel</button>') + '</div>' +
    (first ? '<div class="note">Already have a backup file? Create the restaurant first with the same name, then use Settings → Restore.</div>' : '') + '</div>';
}
async function loginScreen() {
  var reg = D.registry(), opts = reg.map(function (r) { return '<option value="' + esc(r.id) + '"' + (r.id === D.id() ? ' selected' : '') + '>' + esc(r.name) + '</option>'; }).join('');
  $('#app').innerHTML = '<div class="login">' + brand() + '<h1>' + esc(S.name) + '</h1><p>RESTO CONTROL</p><div class="card">' +
    (reg.length > 1 ? '<label>Restaurant</label><select id="l_rest" data-c="rest">' + opts + '</select>' : '') +
    '<label>' + t('Username') + '</label><input id="l_user" autocapitalize="none" autocomplete="username"><label>' + t('Password') + '</label><input id="l_pw" type="password" autocomplete="current-password">' +
    '<button class="btn navy" data-a="login">' + t('Login') + '</button></div></div>';
}

/* ---------- main shell ---------- */
function tabs() {
  return isOwner() ? [['home', 'Home', 'home'], ['orders', 'Orders', 'receipt'], ['money', 'Money', 'wallet'], ['staff', 'Staff', 'users'], ['more', 'More', 'menu']]
    : [['home', 'Home', 'home'], ['orders', 'Orders', 'receipt'], ['stock', 'Stock', 'box'], ['more', 'More', 'menu']];
}
async function render() {
  var body = '';
  try { body = await screens[S.tab](); } catch (e) { console.error(e); body = '<div class="wrap"><div class="warnbox">Error: ' + esc(e.message) + '</div></div>'; }
  $('#app').innerHTML = '<div class="top"><img src="' + (S.logo || 'icons/icon-192.png') + '" alt=""><div><div class="t1">' + esc(S.name) + '</div><div class="t2">' + fd(today()) + ' · ' + Cal.nowTime() + '</div></div><div class="sp"></div><div class="t2">' + esc(S.user.name) + '</div></div>' +
    '<div class="wrap">' + body + '</div><div class="nav">' + tabs().map(function (x) { return '<button class="' + (S.tab === x[0] ? 'on' : '') + '" data-a="tab" data-v="' + x[0] + '">' + ic(x[2]) + t(x[1]) + '</button>'; }).join('') + '</div>';
}
async function loadAll() {
  var r = await Promise.all(['employees', 'attendance', 'salaryPayments', 'sales', 'expenses', 'inventory', 'stockMoves', 'orders', 'activity'].map(function (s) { return D.all(s); }));
  return { emps: r[0], att: r[1], pay: r[2], sales: r[3], exp: r[4], inv: r[5], moves: r[6], orders: r[7], act: r[8] };
}
function warnings(a) { return a.inv.filter(function (i) { return K.stockLevel(i, a.moves) <= K.num(i.minQty); }); }
function finBox(f, label, owed) {
  return '<div class="grid"><div class="stat in"><small>' + t('Income') + '</small><b>' + money(f.income) + '</b></div><div class="stat out"><small>' + t('Expenses') + '</small><b>' + money(f.totalExpenses) + '</b></div></div>' +
    '<div class="stat ' + (f.profit >= 0 ? 'in' : 'out') + '" style="margin-top:10px"><small>' + t('Profit') + ' · ' + esc(label) + '</small><b>' + money(f.profit) + '</b></div>' +
    '<div class="note"><b>How profit is calculated:</b> Income ' + money(f.income) + ' − Expenses ' + money(f.otherExpenses) + ' − Salary &amp; advances actually paid ' + money(f.salaryPaid) + ' = <b>' + money(f.profit) + '</b>. Unpaid salary is <u>not</u> counted as an expense; it is shown separately below as a liability.</div>' +
    (owed !== undefined ? '<div class="stat warn"><small>Outstanding salary (liability, not an expense)</small><b>' + money(owed) + '</b></div>' : '');
}

var screens = {};

/* ----- HOME ----- */
screens.home = async function () {
  var a = await loadAll(), day = S.date, w = warnings(a), orders = a.orders.filter(function (o) { return o.date === day; });
  var h = datebar();
  if (isOwner()) {
    var f = K.finance(a.sales, a.exp, a.pay, day, day), dayAtt = a.att.filter(function (x) { return x.date === day; }), active = a.emps.filter(function (e) { return e.status === 'active'; });
    var pres = dayAtt.filter(function (x) { return ['present', 'late', 'half'].indexOf(x.status) >= 0; }).length, abs = dayAtt.filter(function (x) { return x.status === 'absent'; }).length;
    var owed = K.unpaidSalary(a.emps, a.pay, today()).total;
    h += '<h2>Daily control · ' + fd(day) + '</h2><div class="grid"><div class="stat in"><small>Total sales</small><b>' + money(f.income) + '</b></div><div class="stat out"><small>Total expenses</small><b>' + money(f.totalExpenses) + '</b></div>' +
      '<div class="stat ' + (f.profit >= 0 ? 'in' : 'out') + '"><small>Estimated profit</small><b>' + money(f.profit) + '</b></div><div class="stat out"><small>Salary payments</small><b>' + money(f.salaryPaid) + '</b></div>' +
      '<div class="stat"><small>Employees present</small><b>' + pres + ' / ' + active.length + '</b></div><div class="stat ' + (abs ? 'out' : '') + '"><small>Employees absent</small><b>' + abs + '</b></div>' +
      '<div class="stat"><small>New orders</small><b>' + orders.length + '</b></div><div class="stat ' + (w.length ? 'warn' : '') + '"><small>Inventory warnings</small><b>' + w.length + '</b></div></div>' +
      '<div class="note">Profit = Sales − Expenses − Salary actually paid. <b>Outstanding salary (not counted): ' + money(owed) + '</b></div>';
  } else {
    h += '<h2>' + fd(day) + '</h2><div class="grid"><div class="stat"><small>Orders</small><b>' + orders.length + '</b></div><div class="stat ' + (w.length ? 'warn' : '') + '"><small>Inventory warnings</small><b>' + w.length + '</b></div></div>';
  }
  if (w.length) h += '<h3>Low stock</h3><div class="card">' + w.map(function (i) { return '<div class="row"><div class="l"><b>' + esc(i.name) + '</b></div><span class="tag r">' + K.stockLevel(i, a.moves) + ' ' + esc(i.unit || '') + '</span></div>'; }).join('') + '</div>';
  var acts = isOwner() ? sortBy(a.act.filter(function (x) { return addrDate(x.ts) === day; }), function (x) { return x.ts; }, true) : [];
  if (isOwner()) h += '<h3>What happened on this day</h3><div class="card">' + (acts.length ? acts.slice(0, 60).map(function (x) { return '<div class="row small"><div class="l"><b>' + esc(x.action) + '</b><span class="mut">' + esc(x.detail) + '</span></div><span class="mut">' + addrTime(x.ts) + '<br>' + esc(x.user) + '</span></div>'; }).join('') : '<span class="mut">No recorded activity.</span>') + '</div>';
  return h;
};

/* ----- ORDERS ----- */
screens.orders = async function () {
  var r = await Promise.all([D.all('orders'), D.all('menu'), D.all('tables')]), orders = r[0], menu = r[1], tables = r[2];
  var d = S.draft, tot = K.orderTotal(d.items);
  var h = seg([['new', 'New order'], ['list', 'Orders']], S.sub === 'list' ? 'list' : 'new', 'osub');
  if (S.sub !== 'list') {
    h += '<div class="card"><label style="margin-top:0">Table</label><select id="o_table"><option value="">Takeaway / no table</option>' + tables.map(function (x) { return '<option' + (d.table === x.name ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('') + '</select>';
    h += '<label>Add from menu</label>' + (menu.length ? menu.map(function (m) { return '<button class="chip" data-a="addItem" data-id="' + m.id + '">' + esc(m.name) + ' · ' + K.num(m.price) + '</button>'; }).join('') : '<div class="mut small">Menu is empty. Add items in More → Menu &amp; Tables, or add a custom item below.</div>');
    h += '<label>Custom item</label><div class="grid"><input id="c_name" placeholder="Name"><input id="c_price" type="number" inputmode="decimal" step="any" placeholder="Price"></div><button class="btn sm ghost" data-a="addCustom">+ Add custom item</button></div>';
    h += '<div class="card"><h3 style="margin-top:0">Order items</h3>' + (d.items.length ? d.items.map(function (i, k) { return '<div class="row"><div class="l"><b>' + esc(i.name) + '</b><span class="mut small">' + money(i.price) + ' × ' + i.qty + '</span></div><div><button class="btn sm ghost" data-a="qty" data-k="' + k + '" data-n="-1">−</button><button class="btn sm ghost" data-a="qty" data-k="' + k + '" data-n="1">+</button></div></div>'; }).join('') : '<span class="mut">No items yet.</span>') +
      '<div class="row"><b>' + t('Total') + '</b><b>' + money(tot) + '</b></div><button class="btn" data-a="saveOrder">Save order</button></div>';
  } else {
    var list = sortBy(orders.filter(function (o) { return o.date === S.date; }), function (o) { return o.time + o.id; }, true);
    h += datebar() + (list.length ? list.map(function (o) {
      var st = o.status === 'completed' ? 'g' : o.status === 'cancelled' ? 'r' : 'a';
      return '<div class="card"><div class="row" style="padding-top:0"><div class="l"><b>#' + o.id + ' · ' + esc(o.table || 'Takeaway') + '</b><span class="mut small">' + o.time + ' · ' + esc(o.by) + '</span></div><span class="tag ' + st + '">' + t(o.status[0].toUpperCase() + o.status.slice(1)) + '</span></div>' +
        o.items.map(function (i) { return '<div class="small">' + esc(i.name) + ' × ' + i.qty + ' = ' + money(i.price * i.qty) + '</div>'; }).join('') +
        '<div class="row"><b>' + t('Total') + '</b><b>' + money(o.total) + '</b></div><span class="tag ' + (o.paid ? 'g' : 'r') + '">' + (o.paid ? 'Paid · ' + t(o.method) : 'Unpaid') + '</span><div>' +
        (o.status !== 'cancelled' && !o.paid ? ['Cash', 'Telebirr', 'Other'].map(function (m) { return '<button class="btn sm" data-a="payOrder" data-id="' + o.id + '" data-m="' + m + '">Paid ' + t(m) + '</button>'; }).join('') : '') +
        (o.status === 'pending' ? '<button class="btn sm navy" data-a="completeOrder" data-id="' + o.id + '">Complete</button>' : '') +
        (o.status !== 'cancelled' && !o.paid ? '<button class="btn sm red" data-a="cancelOrder" data-id="' + o.id + '">Cancel</button>' : '') + '</div></div>';
    }).join('') : '<div class="card mut">No orders on this date.</div>');
  }
  return h;
};

/* ----- MONEY ----- */
screens.money = async function () {
  var a = await loadAll(), sub = S.sub || 'summary';
  var h = seg([['summary', 'Summary'], ['sales', 'Sales'], ['expenses', 'Expenses']], sub, 'sub');
  if (sub === 'summary') {
    var rg = range(S.per), f = K.finance(a.sales, a.exp, a.pay, rg[0], rg[1]), owed = K.unpaidSalary(a.emps, a.pay, today()).total;
    h += datebar() + perSeg() + finBox(f, periodLabel(S.per), owed);
    var byCat = {}; a.exp.forEach(function (e) { if (K.inRange(e.date, rg[0], rg[1])) byCat[e.category] = (byCat[e.category] || 0) + K.num(e.amount); });
    if (f.salaryPaid) byCat['Employee salaries'] = (byCat['Employee salaries'] || 0) + f.salaryPaid;
    h += '<h3>Expenses by category</h3><div class="card">' + (Object.keys(byCat).length ? Object.keys(byCat).map(function (c) { return '<div class="row"><span>' + esc(c) + '</span><b class="neg">' + money(byCat[c]) + '</b></div>'; }).join('') : '<span class="mut">None in this period.</span>') + '</div>';
  } else if (sub === 'sales') {
    var s = S.edit && S.edit.store === 'sales' ? S.edit.rec : null;
    h += '<div class="card"><h3 style="margin-top:0">' + (s ? 'Edit sale' : 'Record sale') + '</h3><label>' + t('Date') + '</label>' + dateField('f_date', s ? s.date : today()) + '<label>' + t('Amount') + '</label><input id="f_amt" type="number" inputmode="decimal" step="any" value="' + (s ? s.amount : '') + '">' +
      '<label>Category</label><select id="f_cat">' + ['Food', 'Drink', 'Other'].map(function (c) { return '<option' + (s && s.category === c ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select><label>Payment method</label><select id="f_m">' + ['Cash', 'Telebirr', 'Other'].map(function (c) { return '<option value="' + c + '"' + (s && s.method === c ? ' selected' : '') + '>' + t(c) + '</option>'; }).join('') + '</select>' +
      '<label>' + t('Note') + '</label><input id="f_note" value="' + esc(s ? s.note : '') + '"><button class="btn" data-a="saveSale">' + t('Save') + '</button>' + (s ? '<button class="btn ghost" data-a="cancelEdit">' + t('Cancel') + '</button>' : '') + '</div>';
    var rg2 = range('month'); h += datebar() + '<h3>Sales · ' + periodLabel('month') + '</h3><div class="card">' + (function () {
      var l = sortBy(a.sales.filter(function (x) { return K.inRange(x.date, rg2[0], rg2[1]); }), function (x) { return x.date + String(x.id).padStart(8, '0'); }, true);
      return l.length ? l.map(function (x) { return '<div class="row"><div class="l"><b class="pos">' + money(x.amount) + '</b><span class="mut small">' + fd(x.date) + ' · ' + esc(x.category) + ' · ' + t(x.method) + (x.orderId ? ' · order #' + x.orderId : '') + (x.note ? ' · ' + esc(x.note) : '') + '</span></div><div><button class="btn sm ghost" data-a="editRec" data-s="sales" data-id="' + x.id + '">' + t('Edit') + '</button><button class="btn sm red" data-a="delRec" data-s="sales" data-id="' + x.id + '">✕</button></div></div>'; }).join('') : '<span class="mut">No sales this month.</span>';
    })() + '</div>';
  } else {
    var e = S.edit && S.edit.store === 'expenses' ? S.edit.rec : null, cats = ['Food purchases', 'Electricity', 'Water', 'Rent', 'Transport', 'Maintenance', 'Other'];
    h += '<div class="note">Employee salaries are recorded in Staff → Salary and counted automatically.</div><div class="card"><h3 style="margin-top:0">' + (e ? 'Edit expense' : 'Record expense') + '</h3><label>' + t('Date') + '</label>' + dateField('f_date', e ? e.date : today()) + '<label>Category</label><select id="f_cat">' + cats.map(function (c) { return '<option' + (e && e.category === c ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select>' +
      '<label>' + t('Amount') + '</label><input id="f_amt" type="number" inputmode="decimal" step="any" value="' + (e ? e.amount : '') + '"><label>' + t('Note') + '</label><input id="f_note" value="' + esc(e ? e.note : '') + '"><button class="btn" data-a="saveExpense">' + t('Save') + '</button>' + (e ? '<button class="btn ghost" data-a="cancelEdit">' + t('Cancel') + '</button>' : '') + '</div>';
    var rg3 = range('month'); h += datebar() + '<h3>Expenses · ' + periodLabel('month') + '</h3><div class="card">' + (function () {
      var l = sortBy(a.exp.filter(function (x) { return K.inRange(x.date, rg3[0], rg3[1]); }), function (x) { return x.date + String(x.id).padStart(8, '0'); }, true);
      return l.length ? l.map(function (x) { return '<div class="row"><div class="l"><b class="neg">' + money(x.amount) + '</b><span class="mut small">' + fd(x.date) + ' · ' + esc(x.category) + (x.note ? ' · ' + esc(x.note) : '') + '</span></div><div><button class="btn sm ghost" data-a="editRec" data-s="expenses" data-id="' + x.id + '">' + t('Edit') + '</button><button class="btn sm red" data-a="delRec" data-s="expenses" data-id="' + x.id + '">✕</button></div></div>'; }).join('') : '<span class="mut">No expenses this month.</span>';
    })() + '</div>';
  }
  return h;
};

/* ----- STAFF ----- */
screens.staff = async function () {
  var a = await loadAll(), sub = S.sub || 'employees';
  var h = seg([['employees', 'Employees'], ['attendance', 'Attendance'], ['salary', 'Salary']], sub, 'sub');
  if (sub === 'employees') {
    var e = S.edit && S.edit.store === 'employees' ? S.edit.rec : null;
    h += '<div class="card"><h3 style="margin-top:0">' + (e ? 'Edit employee' : 'Register employee') + '</h3><label>Full name</label><input id="e_name" value="' + esc(e ? e.name : '') + '"><label>Phone number</label><input id="e_phone" type="tel" value="' + esc(e ? e.phone : '') + '"><label>Employee ID</label><input id="e_code" value="' + esc(e ? e.code : '') + '"><label>Job position</label><input id="e_pos" value="' + esc(e ? e.position : '') + '">' +
      '<label>Monthly salary (' + esc(S.cur) + ')</label><input id="e_sal" type="number" inputmode="decimal" step="any" value="' + (e ? e.salary : '') + '"><label>Starting date</label>' + dateField('e_start', e ? e.startDate : today(), 30) + '<label>Status</label><select id="e_status"><option value="active"' + (e && e.status === 'active' ? ' selected' : '') + '>Active</option><option value="inactive"' + (e && e.status === 'inactive' ? ' selected' : '') + '>Inactive</option></select>' +
      '<button class="btn" data-a="saveEmp">' + t('Save') + '</button>' + (e ? '<button class="btn ghost" data-a="cancelEdit">' + t('Cancel') + '</button>' : '') + '</div><h3>' + t('Employees') + ' (' + a.emps.length + ')</h3><div class="card">' +
      (a.emps.length ? a.emps.map(function (x) { return '<div class="row"><div class="l"><b>' + esc(x.name) + '</b><span class="mut small">' + esc(x.position) + ' · ' + esc(x.code) + ' · ' + money(x.salary) + ' · since ' + fd(x.startDate) + '</span></div><div><span class="tag ' + (x.status === 'active' ? 'g' : '') + '">' + x.status + '</span><br><button class="btn sm ghost" data-a="editRec" data-s="employees" data-id="' + x.id + '">' + t('Edit') + '</button></div></div>'; }).join('') : '<span class="mut">No employees yet.</span>') + '</div>';
  } else if (sub === 'attendance') {
    var act = a.emps.filter(function (x) { return x.status === 'active'; }), day = S.date;
    if (S.empView) {
      var em = a.emps.find(function (x) { return x.id === S.empView; }), rg = range(S.per), rows = sortBy(a.att.filter(function (x) { return x.empId === em.id && K.inRange(x.date, rg[0], rg[1]); }), function (x) { return x.date; }, true), tt = K.attendanceTotals(rows);
      h += '<button class="btn sm ghost" data-a="empBack">← Back</button><h2>' + esc(em.name) + ' · ' + periodLabel(S.per) + '</h2>' + datebar() + perSeg() + totalsBox(tt) + '<div class="card">' + (rows.length ? rows.map(function (x) { return '<div class="row"><span>' + fd(x.date) + '</span><span class="tag ' + attTag(x.status) + '">' + t(attLabel(x.status)) + '</span></div>'; }).join('') : '<span class="mut">No records.</span>') + '</div>';
    } else {
      var dr = a.att.filter(function (x) { return x.date === day; }), tt2 = K.attendanceTotals(dr), un = act.length - dr.length;
      h += datebar() + '<div class="grid"><div class="stat in"><small>Present / late / half</small><b>' + (tt2.present + tt2.late + tt2.half) + '</b></div><div class="stat out"><small>Absent</small><b>' + tt2.absent + '</b></div><div class="stat warn"><small>Late</small><b>' + tt2.late + '</b></div><div class="stat"><small>Not recorded</small><b>' + Math.max(0, un) + '</b></div></div><h3>Attendance · ' + fd(day) + '</h3><div class="card">' +
        (act.length ? act.map(function (x) {
          var rec = dr.find(function (r) { return r.empId === x.id; }), cur = rec ? rec.status : '';
          return '<div style="padding:8px 0;border-bottom:1px solid var(--line)"><div class="row" style="border:0;padding:0"><b>' + esc(x.name) + '</b><button class="btn sm ghost" data-a="empHist" data-id="' + x.id + '">History</button></div><div class="att">' + ['present', 'absent', 'late', 'half', 'leave'].map(function (s) { return '<button class="' + s + (cur === s ? ' on' : '') + '" data-a="mark" data-id="' + x.id + '" data-v="' + s + '">' + t(attLabel(s)) + '</button>'; }).join('') + '</div></div>';
        }).join('') : '<span class="mut">Register employees first.</span>') + '</div><div class="note">Tap a status again to change it. Attendance does <b>not</b> pay or reduce salary; salary is only affected by recorded payments.</div>';
      var rgm = range('month');
      h += '<h3>' + periodLabel('month') + ' totals</h3><div class="card tw"><table><tr><th>Name</th><th class="n">Work days</th><th class="n">Abs</th><th class="n">Late</th><th class="n">Leave</th></tr>' + act.map(function (x) { var q = K.attendanceTotals(a.att.filter(function (r) { return r.empId === x.id && K.inRange(r.date, rgm[0], rgm[1]); })); return '<tr><td>' + esc(x.name) + '</td><td class="n">' + q.workingDays + '</td><td class="n">' + q.absent + '</td><td class="n">' + q.late + '</td><td class="n">' + q.leave + '</td></tr>'; }).join('') + '</table></div>';
    }
  } else {
    var key = K.ethMonthKey(S.date), owed = K.unpaidSalary(a.emps, a.pay, today());
    h += datebar() + '<div class="stat warn"><small>Total unpaid salary (all months to date, active staff)</small><b>' + money(owed.total) + '</b></div><div class="note">Month shown: <b>' + keyLabel(key) + '</b> (payroll months are always Ethiopian months). Payments are recorded separately from attendance.</div>';
    a.emps.filter(function (x) { return x.status === 'active'; }).forEach(function (x) {
      var m = K.salaryForMonth(x, a.pay, key);
      h += '<div class="card"><div class="row" style="padding-top:0"><div class="l"><b>' + esc(x.name) + '</b><span class="mut small">' + esc(x.position) + '</span></div><span class="tag ' + (m.remaining ? 'a' : 'g') + '">' + (m.remaining ? 'Remaining ' + money(m.remaining) : 'Settled') + '</span></div>' +
        '<div class="small">Salary ' + money(m.due) + ' · Paid ' + money(m.paid) + ' · Advance ' + money(m.advance) + (m.overpaid ? ' · <span class="neg">Overpaid ' + money(m.overpaid) + '</span>' : '') + '</div><div class="small mut">All months unpaid: ' + money(owed.perEmployee[x.id] || 0) + '</div>' +
        '<button class="btn sm" data-a="payForm" data-id="' + x.id + '" data-t="salary">Pay salary</button><button class="btn sm navy" data-a="payForm" data-id="' + x.id + '" data-t="advance">Advance</button><button class="btn sm ghost" data-a="empHistPay" data-id="' + x.id + '">History</button></div>';
    });
    if (S.payForm) {
      var pe = a.emps.find(function (z) { return z.id === S.payForm.id; });
      h += '<div class="card" style="border:2px solid var(--accent)"><h3 style="margin-top:0">' + (S.payForm.type === 'advance' ? 'Advance payment' : 'Salary payment') + ' · ' + esc(pe.name) + '</h3><label>' + t('Amount') + '</label><input id="p_amt" type="number" inputmode="decimal" step="any"><label>Payment date</label>' + dateField('p_date', today()) + '<label>For month</label>' + payMonthSelect('p_month', key) + '<label>' + t('Note') + '</label><input id="p_note"><button class="btn" data-a="savePay">' + t('Save') + '</button><button class="btn ghost" data-a="cancelPay">' + t('Cancel') + '</button></div>';
    }
    if (S.payHist) {
      var he = a.emps.find(function (z) { return z.id === S.payHist; }), hp = sortBy(a.pay.filter(function (p) { return p.empId === he.id; }), function (p) { return p.date + String(p.id).padStart(8, '0'); }, true);
      h += '<h3>Payment history · ' + esc(he.name) + '</h3><div class="card">' + (hp.length ? hp.map(function (p) { return '<div class="row"><div class="l"><b>' + money(p.amount) + ' <span class="tag">' + p.type + '</span></b><span class="mut small">' + fd(p.date) + ' · for ' + keyLabel(p.forMonth) + (p.note ? ' · ' + esc(p.note) : '') + '</span></div><button class="btn sm red" data-a="delRec" data-s="salaryPayments" data-id="' + p.id + '">✕</button></div>'; }).join('') : '<span class="mut">No payments yet.</span>') + '</div>';
    }
  }
  return h;
};
function attLabel(s) { return { present: 'Present', absent: 'Absent', late: 'Late', half: 'Half-day', leave: 'Leave' }[s]; }
function attTag(s) { return { present: 'g', absent: 'r', late: 'a', half: 'a', leave: '' }[s]; }
function totalsBox(t2) { return '<div class="grid"><div class="stat in"><small>Total working days</small><b>' + t2.workingDays + '</b></div><div class="stat out"><small>Absent days</small><b>' + t2.absent + '</b></div><div class="stat warn"><small>Late days</small><b>' + t2.late + '</b></div><div class="stat"><small>Leave days</small><b>' + t2.leave + '</b></div></div>'; }

/* ----- STOCK ----- */
screens.stock = async function () {
  var a = await loadAll(), h = '';
  if (isOwner() || true) {
    var it = S.edit && S.edit.store === 'inventory' ? S.edit.rec : null;
    h += '<div class="card"><h3 style="margin-top:0">' + (it ? 'Edit item' : 'New stock item') + '</h3><label>Item name</label><input id="i_name" value="' + esc(it ? it.name : '') + '"><label>Type</label><select id="i_cat">' + ['Food ingredient', 'Drink', 'Other supply'].map(function (c) { return '<option' + (it && it.category === c ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select><div class="grid"><div><label>Unit (kg, L, pcs)</label><input id="i_unit" value="' + esc(it ? it.unit : '') + '"></div><div><label>Opening quantity</label><input id="i_open" type="number" inputmode="decimal" step="any" value="' + (it ? it.openingQty : 0) + '"></div><div><label>Purchase price / unit</label><input id="i_price" type="number" inputmode="decimal" step="any" value="' + (it ? it.price : '') + '"></div><div><label>Low-stock warning at</label><input id="i_min" type="number" inputmode="decimal" step="any" value="' + (it ? it.minQty : 0) + '"></div></div>' +
      '<button class="btn" data-a="saveItem">' + t('Save') + '</button>' + (it ? '<button class="btn ghost" data-a="cancelEdit">' + t('Cancel') + '</button>' : '') + '</div>';
  }
  if (S.move) {
    var mi = a.inv.find(function (z) { return z.id === S.move.id; });
    h += '<div class="card" style="border:2px solid var(--accent)"><h3 style="margin-top:0">' + { add: 'Add stock', use: 'Use stock', waste: 'Record wastage' }[S.move.type] + ' · ' + esc(mi.name) + '</h3><label>Quantity (' + esc(mi.unit || '') + ')</label><input id="m_qty" type="number" inputmode="decimal" step="any"><label>' + t('Date') + '</label>' + dateField('m_date', today()) +
      (S.move.type === 'add' && isOwner() ? '<label>Total cost paid (optional)</label><input id="m_cost" type="number" inputmode="decimal" step="any" value=""><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="m_exp" style="width:auto" checked> Also record as expense (Food purchases)</label>' : '') + '<label>' + t('Note') + '</label><input id="m_note"><button class="btn" data-a="saveMove">' + t('Save') + '</button><button class="btn ghost" data-a="cancelMove">' + t('Cancel') + '</button></div>';
  }
  h += '<h3>Stock (' + a.inv.length + ')</h3><div class="card">' + (a.inv.length ? sortBy(a.inv, function (x) { return x.name.toLowerCase(); }).map(function (x) {
    var q = K.stockLevel(x, a.moves), low = q <= K.num(x.minQty);
    return '<div style="padding:9px 0;border-bottom:1px solid var(--line)"><div class="row" style="border:0;padding:0"><div class="l"><b>' + esc(x.name) + '</b><span class="mut small">' + esc(x.category) + ' · ' + money(x.price) + '/' + esc(x.unit || 'unit') + '</span></div><span class="tag ' + (low ? 'r' : 'g') + '">' + q + ' ' + esc(x.unit || '') + (low ? ' · LOW' : '') + '</span></div><button class="btn sm" data-a="moveForm" data-id="' + x.id + '" data-t="add">+ Add</button><button class="btn sm navy" data-a="moveForm" data-id="' + x.id + '" data-t="use">Use</button><button class="btn sm red" data-a="moveForm" data-id="' + x.id + '" data-t="waste">Waste</button>' + (isOwner() ? '<button class="btn sm ghost" data-a="editRec" data-s="inventory" data-id="' + x.id + '">' + t('Edit') + '</button>' : '') + '</div>';
  }).join('') : '<span class="mut">No stock items yet.</span>') + '</div>';
  return h;
};

/* ----- REPORTS ----- */
function buildReport(a, kind, per) {
  var rg = range(per), lbl = periodLabel(per), title, head, rows = [], notes = [];
  function days(from, to) { var o = [], d = from; while (d <= to) { o.push(d); d = Cal.addDays(d, 1); } return o; }
  if (kind === 'financial') {
    title = 'Financial report · ' + lbl; head = [per === 'year' ? 'Period' : 'Date', 'Income', 'Expenses (other)', 'Salary paid', 'Total expenses', 'Net operating profit'];
    var parts = [];
    if (per === 'year') { var e = Cal.isoToEth(S.date), g = Cal.parseIso(S.date); for (var m = 1; m <= (S.cal === 'greg' ? 12 : 13); m++) parts.push(S.cal === 'greg' ? [Cal.G_MONTHS[m - 1], K.gMonthRange(g.y, m)] : [names()[m - 1] + ' ' + e.y, K.monthRange(e.y, m)]); }
    else parts = days(rg[0], rg[1]).map(function (d) { return [fd(d), [d, d]]; });
    parts.forEach(function (p) { var f = K.finance(a.sales, a.exp, a.pay, p[1][0], p[1][1]); if (f.income || f.totalExpenses) rows.push([p[0], f.income, f.otherExpenses, f.salaryPaid, f.totalExpenses, f.profit]); });
    var tf = K.finance(a.sales, a.exp, a.pay, rg[0], rg[1]); rows.push(['TOTAL', tf.income, tf.otherExpenses, tf.salaryPaid, tf.totalExpenses, tf.profit]);
    notes.push('Net operating profit = income - (expenses + salary actually paid). Outstanding salary: ' + K.unpaidSalary(a.emps, a.pay, today()).total + ' (liability, not counted).');
  } else if (kind === 'sales') {
    title = 'Sales report · ' + lbl; head = ['Date', 'Category', 'Method', 'Amount', 'Order', 'Note'];
    sortBy(a.sales.filter(function (x) { return K.inRange(x.date, rg[0], rg[1]); }), function (x) { return x.date; }).forEach(function (x) { rows.push([fd(x.date), x.category, x.method, x.amount, x.orderId || '', x.note || '']); });
    rows.push(['TOTAL', '', '', K.incomeIn(a.sales, rg[0], rg[1]), '', '']);
  } else if (kind === 'attendance') {
    title = 'Attendance report · ' + lbl; head = ['Employee', 'Working days', 'Present', 'Late', 'Half-day', 'Absent', 'Leave'];
    a.emps.forEach(function (x) { var q = K.attendanceTotals(a.att.filter(function (r) { return r.empId === x.id && K.inRange(r.date, rg[0], rg[1]); })); rows.push([x.name, q.workingDays, q.present, q.late, q.half, q.absent, q.leave]); });
  } else if (kind === 'salary') {
    title = 'Salary report · ' + lbl; head = ['Date', 'Employee', 'Type', 'For month', 'Amount', 'Note'];
    sortBy(a.pay.filter(function (p) { return K.inRange(p.date, rg[0], rg[1]); }), function (p) { return p.date; }).forEach(function (p) { var em = a.emps.find(function (x) { return x.id === p.empId; }); rows.push([fd(p.date), em ? em.name : '?', p.type, keyLabel(p.forMonth), p.amount, p.note || '']); });
    rows.push(['TOTAL PAID', '', '', '', K.salaryOut(a.pay, rg[0], rg[1]), '']);
    var ow = K.unpaidSalary(a.emps, a.pay, today()); a.emps.forEach(function (x) { if (ow.perEmployee[x.id]) rows.push(['UNPAID', x.name, '', 'all months to date', ow.perEmployee[x.id], '']); }); rows.push(['TOTAL UNPAID', '', '', '', ow.total, '']);
  } else if (kind === 'inventory') {
    title = 'Inventory report · ' + lbl; head = ['Item', 'Type', 'Unit', 'In stock', 'Added (period)', 'Used (period)', 'Wasted (period)', 'Low-stock at', 'Status'];
    a.inv.forEach(function (x) { function s(tp) { var t2 = 0; a.moves.forEach(function (m) { if (m.itemId === x.id && m.type === tp && K.inRange(m.date, rg[0], rg[1])) t2 += K.num(m.qty); }); return K.r2(t2); } var q = K.stockLevel(x, a.moves); rows.push([x.name, x.category, x.unit, q, s('add'), s('use'), s('waste'), x.minQty, q <= K.num(x.minQty) ? 'LOW' : 'OK']); });
  } else {
    title = 'Employee list'; head = ['Name', 'Employee ID', 'Position', 'Phone', 'Monthly salary', 'Start date', 'Status'];
    a.emps.forEach(function (x) { rows.push([x.name, x.code, x.position, x.phone, x.salary, fd(x.startDate), x.status]); });
  }
  return { title: title, head: head, rows: rows, notes: notes };
}
screens.reports = async function () {
  var a = await loadAll(), r = buildReport(a, S.rp.kind, S.per);
  var h = '<button class="btn sm ghost" data-a="tab" data-v="more">← More</button><h2>Reports</h2>' + seg([['financial', 'Financial'], ['sales', 'Sales'], ['attendance', 'Attendance'], ['salary', 'Salary'], ['inventory', 'Inventory'], ['employees', 'Employees']], S.rp.kind, 'rkind') + datebar() + (['employees', 'inventory'].indexOf(S.rp.kind) >= 0 && S.rp.kind === 'employees' ? '' : perSeg());
  h += '<div class="card"><b>' + esc(r.title) + '</b><div class="tw"><table><tr>' + r.head.map(function (x, i) { return '<th' + (i ? ' class="n"' : '') + '>' + esc(x) + '</th>'; }).join('') + '</tr>' + (r.rows.length ? r.rows.map(function (x) { return '<tr>' + x.map(function (c, i) { return '<td' + (i && typeof c === 'number' ? ' class="n"' : '') + '>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') : '<tr><td colspan="' + r.head.length + '" class="mut">No data.</td></tr>') + '</table></div>' + r.notes.map(function (n) { return '<div class="note">' + esc(n) + '</div>'; }).join('') + '</div>';
  h += '<button class="btn navy" data-a="exportCsv">Export CSV</button><button class="btn ghost" data-a="exportJson">Export JSON</button>';
  return h;
};

/* ----- MORE ----- */
screens.more = async function () {
  var h = '';
  if (!isOwner()) return '<h2>' + esc(S.user.name) + '</h2><div class="card"><p class="mut">Signed in as <b>' + esc(S.user.username) + '</b> (employee account).</p><label>' + t('Language') + '</label><select id="x_lang" data-c="lang"><option value="en"' + (S.lang === 'en' ? ' selected' : '') + '>English</option><option value="am"' + (S.lang === 'am' ? ' selected' : '') + '>አማርኛ</option></select><button class="btn red" data-a="logout">' + t('Logout') + '</button></div>';
  h += '<h2>More</h2>' + seg([['menu', 'Menu & Tables'], ['stock', 'Inventory'], ['reports', 'Reports'], ['settings', 'Settings']], '', 'moreGo');
  h += '<div class="card"><b>' + esc(S.name) + '</b><div class="mut small">' + esc(S.phone) + ' ' + esc(S.address) + '</div></div>';
  return h + await moreSub();
};
async function moreSub() {
  var sub = S.sub, h = '';
  if (sub === 'menu') {
    var r = await Promise.all([D.all('menu'), D.all('tables')]), menu = r[0], tables = r[1];
    h += '<h3>Menu</h3><div class="card"><div class="grid"><input id="mn_name" placeholder="Item name"><input id="mn_price" type="number" inputmode="decimal" step="any" placeholder="Price"></div><select id="mn_cat"><option>Food</option><option>Drink</option></select><button class="btn" data-a="addMenu">Add menu item</button>' + menu.map(function (m) { return '<div class="row"><div class="l"><b>' + esc(m.name) + '</b><span class="mut small">' + esc(m.cat) + '</span></div><b>' + money(m.price) + '</b><button class="btn sm red" data-a="delRec" data-s="menu" data-id="' + m.id + '">✕</button></div>'; }).join('') + '</div>' +
      '<h3>Tables</h3><div class="card"><input id="tb_name" placeholder="Table name, e.g. Table 1"><button class="btn" data-a="addTable">Add table</button>' + tables.map(function (m) { return '<div class="row"><b>' + esc(m.name) + '</b><button class="btn sm red" data-a="delRec" data-s="tables" data-id="' + m.id + '">✕</button></div>'; }).join('') + '</div>';
  } else if (sub === 'settings') {
    var users = await D.all('users'), act = sortBy(await D.all('activity'), function (x) { return x.ts; }, true).slice(0, 40);
    h += '<h3>Restaurant settings</h3><div class="card"><label>Restaurant name</label><input id="st_name" value="' + esc(S.name) + '"><label>Phone number</label><input id="st_phone" value="' + esc(S.phone) + '"><label>Address</label><input id="st_addr" value="' + esc(S.address) + '"><label>Currency</label><input id="st_cur" value="' + esc(S.cur) + '">' +
      '<label>' + t('Language') + '</label><select id="st_lang"><option value="en"' + (S.lang === 'en' ? ' selected' : '') + '>English</option><option value="am"' + (S.lang === 'am' ? ' selected' : '') + '>አማርኛ (Amharic)</option></select><label>' + t('Calendar') + '</label><select id="st_cal"><option value="eth"' + (S.cal === 'eth' ? ' selected' : '') + '>Ethiopian</option><option value="greg"' + (S.cal === 'greg' ? ' selected' : '') + '>Gregorian</option></select>' +
      '<label>Theme color</label><input id="st_color" type="color" value="' + S.color + '" style="height:50px"><label>Logo (picture)</label><input id="st_logo" type="file" accept="image/*"><button class="btn" data-a="saveSettings">' + t('Save') + '</button></div>';
    h += '<h3>User accounts</h3><div class="card">' + users.map(function (u) { return '<div class="row"><div class="l"><b>' + esc(u.name) + '</b><span class="mut small">' + esc(u.username) + ' · ' + u.role + (u.active === false ? ' · disabled' : '') + '</span></div>' + (u.role !== 'owner' ? '<button class="btn sm ghost" data-a="toggleUser" data-id="' + u.id + '">' + (u.active === false ? 'Enable' : 'Disable') + '</button><button class="btn sm ghost" data-a="resetPw" data-id="' + u.id + '">Reset PW</button>' : '<button class="btn sm ghost" data-a="resetPw" data-id="' + u.id + '">Change PW</button>') + '</div>'; }).join('') +
      '<h3>Add employee account</h3><input id="u_name" placeholder="Full name"><input id="u_user" placeholder="Username" autocapitalize="none" style="margin-top:6px"><input id="u_pw" type="password" placeholder="Password (min 4)" style="margin-top:6px"><button class="btn navy" data-a="addUser">Create account</button><div class="note">Employee accounts can take orders and manage stock. They cannot see money, salaries, reports or settings.</div></div>';
    h += '<h3>' + t('Backup') + ' &amp; ' + t('Restore') + '</h3><div class="card"><button class="btn navy" data-a="backup">Download backup file</button><label>Restore from backup file (replaces ALL data of this restaurant)</label><input id="rs_file" type="file" accept=".json,application/json"><button class="btn red" data-a="restore">' + t('Restore') + '</button></div>';
    h += '<h3>Restaurants on this phone</h3><div class="card">' + D.registry().map(function (r2) { return '<div class="row"><b>' + esc(r2.name) + '</b>' + (r2.id === D.id() ? '<span class="tag g">open</span>' : '<button class="btn sm ghost" data-a="switchRest" data-id="' + r2.id + '">Switch</button>') + '</div>'; }).join('') + '<button class="btn ghost" data-a="newRest">+ Add another restaurant</button><div class="note">Each restaurant has its own separate database and backup file.</div></div>';
    h += '<h3>Activity log (last 40)</h3><div class="card">' + act.map(function (x) { return '<div class="row small"><div class="l"><b>' + esc(x.action) + '</b><span class="mut">' + esc(x.detail) + '</span></div><span class="mut">' + fd(addrDate(x.ts)) + ' ' + addrTime(x.ts) + '<br>' + esc(x.user) + '</span></div>'; }).join('') + '</div>';
    h += '<div class="warnbox"><b>About security (honest limits):</b> Passwords stop casual access inside the app, but all data lives on this phone in the browser database. Someone with the phone unlocked, or technical skill, can read or delete it by other means, and clearing the browser/app data erases everything. Use a phone screen lock and download a backup file regularly (and keep it somewhere safe, e.g. send to another phone).</div><button class="btn red" data-a="logout">' + t('Logout') + '</button>';
  }
  return h;
}
screens.more2 = null;

/* ---------- actions ---------- */
var A = {};
A.tab = function (e) { S.tab = e.v; S.sub = (e.v === 'more' ? '' : ''); S.edit = null; S.empView = null; S.payForm = null; S.move = null; render(); };
A.sub = function (e) { S.sub = e.v; S.edit = null; S.empView = null; S.payForm = null; S.payHist = null; render(); };
A.osub = function (e) { S.sub = e.v; render(); };
A.per = function (e) { S.per = e.v; render(); };
A.today = function () { S.date = today(); render(); };
A.step = function (e) { S.date = Cal.addDays(S.date, +e.n); render(); };
A.moreGo = function (e) { if (e.v === 'stock') { S.tab = 'stock'; } else if (e.v === 'reports') { S.tab = 'reports'; } else S.sub = e.v; render(); };
A.rkind = function (e) { S.rp.kind = e.v; render(); };
A.cancelEdit = function () { S.edit = null; render(); };
A.editRec = async function (e) { S.edit = { store: e.s, rec: await D.get(e.s, +e.id) }; render(); scrollTo(0, 0); };
A.delRec = async function (e) {
  if (!confirm('Delete this record? This cannot be undone.')) return;
  var rec = await D.get(e.s, +e.id); await D.del(e.s, +e.id); await log('Deleted ' + e.s, JSON.stringify(rec).slice(0, 120)); toast('Deleted'); render();
};
A.logout = function () { S.user = null; loginScreen(); };
A.login = async function () {
  var u = v('l_user').toLowerCase(), pw = $('#l_pw').value, users = await D.all('users'), rec = users.find(function (x) { return x.username === u; });
  if (!rec || rec.active === false || (await hashPw(pw, rec.salt)) !== rec.hash) return toast('Wrong username or password');
  S.user = rec; S.tab = 'home'; S.sub = ''; S.date = today(); await log('Login', ''); render();
};
A.createRestaurant = async function () {
  var name = v('s_name'), owner = v('s_owner'), user = v('s_user').toLowerCase(), pw = $('#s_pw').value;
  if (!name || !owner || !user || pw.length < 4) return toast('Fill all fields (password min 4)');
  var id = 'r' + Date.now(), reg = D.registry(); reg.push({ id: id, name: name }); D.saveRegistry(reg); localStorage.setItem('resto_last', id);
  await D.open(id); var salt = String(Math.random()).slice(2);
  await D.put('users', { username: user, name: owner, role: 'owner', salt: salt, hash: await hashPw(pw, salt), active: true });
  await D.setSetting('name', name); await loadSettings(); S.user = null; toast('Restaurant created. Please log in.'); loginScreen();
};
A.addUser = async function () {
  var name = v('u_name'), user = v('u_user').toLowerCase(), pw = $('#u_pw').value, users = await D.all('users');
  if (!name || !user || pw.length < 4) return toast('Fill all fields (password min 4)');
  if (users.some(function (x) { return x.username === user; })) return toast('Username already exists');
  var salt = String(Math.random()).slice(2); await D.put('users', { username: user, name: name, role: 'staff', salt: salt, hash: await hashPw(pw, salt), active: true });
  await log('Created employee account', user); toast('Account created'); render();
};
A.toggleUser = async function (e) { var u = await D.get('users', +e.id); u.active = u.active === false; await D.put('users', u); await log((u.active ? 'Enabled' : 'Disabled') + ' account', u.username); render(); };
A.resetPw = async function (e) {
  var p = prompt('New password (min 4 characters):'); if (!p || p.length < 4) return;
  var u = await D.get('users', +e.id); u.salt = String(Math.random()).slice(2); u.hash = await hashPw(p, u.salt); await D.put('users', u); await log('Password changed', u.username); toast('Password changed');
};
A.switchRest = async function (e) { localStorage.setItem('resto_last', e.id); S.user = null; await D.open(e.id); await loadSettings(); loginScreen(); };
A.newRest = function () { setupScreen(false); };

/* money */
A.saveSale = async function () {
  var amt = K.num(v('f_amt')); if (amt <= 0) return toast('Enter an amount');
  var rec = { date: readDate('f_date'), amount: amt, category: v('f_cat'), method: v('f_m'), note: v('f_note'), status: 'paid', by: S.user.username };
  if (S.edit && S.edit.store === 'sales') { rec.id = S.edit.rec.id; rec.orderId = S.edit.rec.orderId; }
  await D.put('sales', rec); await log(S.edit ? 'Edited sale' : 'Recorded sale', money(amt) + ' ' + rec.category); S.edit = null; toast('Saved'); render();
};
A.saveExpense = async function () {
  var amt = K.num(v('f_amt')); if (amt <= 0) return toast('Enter an amount');
  var rec = { date: readDate('f_date'), amount: amt, category: v('f_cat'), note: v('f_note'), by: S.user.username };
  if (S.edit && S.edit.store === 'expenses') rec.id = S.edit.rec.id;
  await D.put('expenses', rec); await log(S.edit ? 'Edited expense' : 'Recorded expense', money(amt) + ' ' + rec.category); S.edit = null; toast('Saved'); render();
};

/* staff */
A.saveEmp = async function () {
  var name = v('e_name'); if (!name) return toast('Enter the full name');
  var rec = { name: name, phone: v('e_phone'), code: v('e_code'), position: v('e_pos'), salary: K.num(v('e_sal')), startDate: readDate('e_start'), status: v('e_status') };
  if (S.edit && S.edit.store === 'employees') rec.id = S.edit.rec.id;
  await D.put('employees', rec); await log(S.edit ? 'Edited employee' : 'Registered employee', name); S.edit = null; toast('Saved'); render();
};
A.mark = async function (e) {
  var rows = await D.all('attendance'), ex = rows.find(function (r) { return r.date === S.date && r.empId === +e.id; });
  var rec = ex || { date: S.date, empId: +e.id }; rec.status = e.v; rec.by = S.user.username; await D.put('attendance', rec);
  var em = await D.get('employees', +e.id); await log('Attendance', em.name + ': ' + e.v + ' (' + S.date + ')'); render();
};
A.empHist = function (e) { S.empView = +e.id; S.per = 'month'; render(); };
A.empBack = function () { S.empView = null; render(); };
A.payForm = function (e) { S.payForm = { id: +e.id, type: e.t }; render(); setTimeout(function () { var p = $('#p_amt'); if (p) p.scrollIntoView(); }, 50); };
A.cancelPay = function () { S.payForm = null; render(); };
A.empHistPay = function (e) { S.payHist = +e.id; render(); };
A.savePay = async function () {
  var amt = K.num(v('p_amt')); if (amt <= 0) return toast('Enter an amount');
  var em = await D.get('employees', S.payForm.id);
  await D.put('salaryPayments', { empId: em.id, type: S.payForm.type, amount: amt, date: readDate('p_date'), forMonth: +v('p_month'), note: v('p_note'), by: S.user.username });
  await log('Salary ' + S.payForm.type, em.name + ' ' + money(amt)); S.payForm = null; toast('Payment recorded'); render();
};

/* stock */
A.saveItem = async function () {
  var name = v('i_name'); if (!name) return toast('Enter the item name');
  var rec = { name: name, category: v('i_cat'), unit: v('i_unit'), openingQty: K.num(v('i_open')), price: K.num(v('i_price')), minQty: K.num(v('i_min')) };
  if (S.edit && S.edit.store === 'inventory') rec.id = S.edit.rec.id;
  await D.put('inventory', rec); await log(S.edit ? 'Edited stock item' : 'New stock item', name); S.edit = null; toast('Saved'); render();
};
A.moveForm = function (e) { S.move = { id: +e.id, type: e.t }; render(); };
A.cancelMove = function () { S.move = null; render(); };
A.saveMove = async function () {
  var q = K.num(v('m_qty')); if (q <= 0) return toast('Enter a quantity');
  var it = await D.get('inventory', S.move.id), date = readDate('m_date');
  if (S.move.type !== 'add') { var all = await D.all('stockMoves'); if (K.stockLevel(it, all) < q && !confirm('This is more than the stock on record. Continue?')) return; }
  await D.put('stockMoves', { itemId: it.id, type: S.move.type, qty: q, date: date, note: v('m_note'), by: S.user.username });
  var cost = $('#m_cost') ? K.num(v('m_cost')) : 0;
  if (S.move.type === 'add' && cost > 0 && $('#m_exp') && $('#m_exp').checked) await D.put('expenses', { date: date, category: 'Food purchases', amount: cost, note: 'Stock: ' + it.name, by: S.user.username });
  await log('Stock ' + S.move.type, it.name + ' ' + q); S.move = null; toast('Saved'); render();
};

/* orders */
A.addItem = async function (e) { var m = await D.get('menu', +e.id), x = S.draft.items.find(function (i) { return i.name === m.name && i.price === m.price; }); if (x) x.qty++; else S.draft.items.push({ name: m.name, price: K.num(m.price), qty: 1, cat: m.cat }); S.draft.table = $('#o_table').value; render(); };
A.addCustom = function () { var n = v('c_name'), p = K.num(v('c_price')); if (!n || p <= 0) return toast('Enter name and price'); S.draft.table = $('#o_table').value; S.draft.items.push({ name: n, price: p, qty: 1, cat: 'Food' }); render(); };
A.qty = function (e) { var i = S.draft.items[+e.k]; i.qty += +e.n; if (i.qty <= 0) S.draft.items.splice(+e.k, 1); S.draft.table = $('#o_table').value; render(); };
A.saveOrder = async function () {
  if (!S.draft.items.length) return toast('Add at least one item');
  var o = { date: today(), time: Cal.nowTime(), table: $('#o_table').value, items: S.draft.items, total: K.orderTotal(S.draft.items), status: 'pending', paid: false, method: '', by: S.user.username };
  var id = await D.put('orders', o); await log('New order', '#' + id + ' ' + money(o.total)); S.draft = { items: [], table: '' }; S.sub = 'list'; S.date = today(); toast('Order #' + id + ' saved'); render();
};
A.completeOrder = async function (e) { var o = await D.get('orders', +e.id); o.status = 'completed'; await D.put('orders', o); await log('Order completed', '#' + o.id); render(); };
A.cancelOrder = async function (e) { if (!confirm('Cancel this order?')) return; var o = await D.get('orders', +e.id); o.status = 'cancelled'; await D.put('orders', o); await log('Order cancelled', '#' + o.id); render(); };
A.payOrder = async function (e) {
  var o = await D.get('orders', +e.id); if (o.paid) return;
  o.paid = true; o.method = e.m; if (o.status === 'pending') o.status = 'completed'; await D.put('orders', o);
  var by = {}; o.items.forEach(function (i) { by[i.cat || 'Food'] = (by[i.cat || 'Food'] || 0) + i.price * i.qty; });
  for (var c in by) await D.put('sales', { date: today(), amount: K.r2(by[c]), category: c, method: e.m, orderId: o.id, note: 'Order #' + o.id, status: 'paid', by: S.user.username });
  await log('Order paid', '#' + o.id + ' ' + e.m + ' ' + money(o.total)); toast('Payment recorded'); render();
};
A.addMenu = async function () { var n = v('mn_name'), p = K.num(v('mn_price')); if (!n || p <= 0) return toast('Enter name and price'); await D.put('menu', { name: n, price: p, cat: v('mn_cat') }); render(); };
A.addTable = async function () { var n = v('tb_name'); if (!n) return; await D.put('tables', { name: n }); render(); };

/* settings / backup */
function resizeLogo(file) {
  return new Promise(function (res) { var r = new FileReader(); r.onload = function () { var im = new Image(); im.onload = function () { var c = document.createElement('canvas'), s = 160; c.width = c.height = s; var x = c.getContext('2d'), m = Math.min(im.width, im.height); x.drawImage(im, (im.width - m) / 2, (im.height - m) / 2, m, m, 0, 0, s, s); res(c.toDataURL('image/png')); }; im.src = r.result; }; r.readAsDataURL(file); });
}
A.saveSettings = async function () {
  var name = v('st_name') || 'Restaurant';
  await D.setSetting('name', name); await D.setSetting('phone', v('st_phone')); await D.setSetting('address', v('st_addr')); await D.setSetting('cur', v('st_cur') || 'ETB'); await D.setSetting('lang', v('st_lang')); await D.setSetting('cal', v('st_cal')); await D.setSetting('color', $('#st_color').value);
  var f = $('#st_logo').files[0]; if (f) await D.setSetting('logo', await resizeLogo(f));
  var reg = D.registry(); reg.forEach(function (r) { if (r.id === D.id()) r.name = name; }); D.saveRegistry(reg);
  await log('Settings changed', ''); await loadSettings(); toast('Settings saved'); render();
};
A.backup = async function () {
  var d = await D.exportAll(); download('RestoControl_' + S.name.replace(/\W+/g, '_') + '_' + today() + '.json', JSON.stringify(d), 'application/json'); await log('Backup downloaded', ''); toast('Backup downloaded');
};
A.restore = async function () {
  var f = $('#rs_file').files[0]; if (!f) return toast('Choose a backup file first');
  if (!confirm('This REPLACES all current data of this restaurant with the backup. Continue?')) return;
  try { var obj = JSON.parse(await f.text()); await D.importAll(obj); await log('Backup restored', f.name); await loadSettings(); toast('Restored'); render(); } catch (e) { toast(e.message || 'Invalid file'); }
};
A.exportCsv = async function () { var a = await loadAll(), r = buildReport(a, S.rp.kind, S.per); download('report_' + S.rp.kind + '_' + S.date + '.csv', K.toCsv([r.head].concat(r.rows)), 'text/csv'); };
A.exportJson = async function () { var a = await loadAll(), r = buildReport(a, S.rp.kind, S.per); download('report_' + S.rp.kind + '_' + S.date + '.json', JSON.stringify({ restaurant: S.name, title: r.title, headers: r.head, rows: r.rows, notes: r.notes, exportedAt: new Date().toISOString() }, null, 1), 'application/json'); };

/* ---------- events ---------- */
document.addEventListener('click', function (ev) {
  var el = ev.target.closest('[data-a]'); if (!el) return;
  var fn = A[el.dataset.a]; if (fn) Promise.resolve(fn(el.dataset)).catch(function (e) { console.error(e); toast('Error: ' + e.message); });
});
document.addEventListener('change', function (ev) {
  var el = ev.target.closest('[data-c]'); if (!el) return;
  if (el.dataset.c === 'bar') { S.date = readDate('bar'); render(); }
  else if (el.dataset.c === 'rest') { A.switchRest({ id: el.value }); }
  else if (el.dataset.c === 'lang') { S.lang = el.value; D.setSetting('lang', el.value).then(render); }
});
screens.settings = screens.more; // safety
screens.menu = screens.more;

window.RestoApp = { S: S, A: A, boot: boot, render: render, buildReport: buildReport, loadAll: loadAll };
if ('serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('sw.js').catch(function () {});
boot();
})();
