/* IndexedDB layer. One database PER restaurant (name: resto_<id>), so data is never mixed. */
(function (root) {
  var STORES = ['users','employees','attendance','salaryPayments','sales','expenses','inventory','stockMoves','orders','tables','menu','activity','settings'];
  var INDEXES = { attendance: [['date','date']], salaryPayments: [['date','date'],['empId','empId']], sales: [['date','date']], expenses: [['date','date']], stockMoves: [['date','date'],['itemId','itemId']], orders: [['date','date']], activity: [['ts','ts']] };
  var db = null, curId = null;

  function registry() { try { return JSON.parse(localStorage.getItem('resto_registry') || '[]'); } catch (e) { return []; } }
  function saveRegistry(r) { localStorage.setItem('resto_registry', JSON.stringify(r)); }
  function open(id) {
    return new Promise(function (res, rej) {
      if (db) { db.close(); db = null; }
      var rq = indexedDB.open('resto_' + id, 1);
      rq.onupgradeneeded = function () {
        var d = rq.result;
        STORES.forEach(function (s) {
          var st = d.createObjectStore(s, s === 'settings' ? { keyPath: 'key' } : { keyPath: 'id', autoIncrement: true });
          (INDEXES[s] || []).forEach(function (ix) { st.createIndex(ix[0], ix[1]); });
        });
      };
      rq.onsuccess = function () { db = rq.result; curId = id; res(db); };
      rq.onerror = function () { rej(rq.error); };
    });
  }
  function tx(store, mode, fn) {
    return new Promise(function (res, rej) {
      var t = db.transaction(store, mode), s = t.objectStore(store), out = fn(s);
      t.oncomplete = function () { res(out instanceof IDBRequest ? out.result : out); };
      t.onerror = t.onabort = function () { rej(t.error); };
    });
  }
  function all(store) { return tx(store, 'readonly', function (s) { return s.getAll(); }); }
  function get(store, id) { return tx(store, 'readonly', function (s) { return s.get(id); }); }
  function put(store, obj) { return tx(store, 'readwrite', function (s) { return s.put(obj); }); }
  function del(store, id) { return tx(store, 'readwrite', function (s) { return s.delete(id); }); }
  function clear(store) { return tx(store, 'readwrite', function (s) { return s.clear(); }); }
  function getSetting(k, dflt) { return get('settings', k).then(function (r) { return r ? r.value : dflt; }); }
  function setSetting(k, v) { return put('settings', { key: k, value: v }); }

  function exportAll() {
    var out = { app: 'RESTO CONTROL', version: 1, restaurantId: curId, exportedAt: new Date().toISOString(), data: {} };
    return Promise.all(STORES.map(function (s) { return all(s).then(function (r) { out.data[s] = r; }); })).then(function () { return out; });
  }
  function importAll(obj) {
    if (!obj || obj.app !== 'RESTO CONTROL' || !obj.data) return Promise.reject(new Error('Not a RESTO CONTROL backup file'));
    if (obj.restaurantId !== curId) return Promise.reject(new Error('This backup belongs to a different restaurant. Open that restaurant first.'));
    return STORES.reduce(function (p, s) {
      return p.then(function () { return clear(s); }).then(function () {
        return (obj.data[s] || []).reduce(function (q, row) { return q.then(function () { return put(s, row); }); }, Promise.resolve());
      });
    }, Promise.resolve());
  }
  function deleteRestaurantDb(id) {
    return new Promise(function (res) { if (db) { db.close(); db = null; } var r = indexedDB.deleteDatabase('resto_' + id); r.onsuccess = r.onerror = r.onblocked = function () { res(); }; });
  }
  root.DB = { registry: registry, saveRegistry: saveRegistry, open: open, all: all, get: get, put: put, del: del, clear: clear, getSetting: getSetting, setSetting: setSetting, exportAll: exportAll, importAll: importAll, deleteRestaurantDb: deleteRestaurantDb, id: function () { return curId; } };
})(self);
