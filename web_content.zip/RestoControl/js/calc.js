/* Pure business calculations (no DOM, no database) so they can be unit tested. */
(function (root) {
  var Cal = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./ethcal.js') : root.EthCal;
  function num(v) { v = parseFloat(v); return isFinite(v) ? v : 0; }
  function r2(v) { return Math.round(v * 100) / 100; }

  function monthRange(ey, em) { return [Cal.ethToIso(ey, em, 1), Cal.ethToIso(ey, em, Cal.ethMonthDays(ey, em))]; }
  function yearRange(ey) { return [Cal.ethToIso(ey, 1, 1), Cal.ethToIso(ey, 13, Cal.ethMonthDays(ey, 13))]; }
  function gMonthRange(y, m) { return [Cal.iso({ y: y, m: m, d: 1 }), Cal.iso({ y: y, m: m, d: Cal.gregMonthDays(y, m) })]; }
  function gYearRange(y) { return [y + '-01-01', y + '-12-31']; }
  function inRange(d, from, to) { return d >= from && d <= to; }
  function sum(rows, from, to, f) { var t = 0; rows.forEach(function (r) { if (inRange(r.date, from, to)) t += num(f ? f(r) : r.amount); }); return r2(t); }

  /* Sales count only when payment status is paid (or partially: amountPaid). Cancelled never counts. */
  function saleAmount(s) { return s.status === 'cancelled' ? 0 : num(s.amount); }
  function incomeIn(sales, from, to) { return sum(sales, from, to, saleAmount); }
  function salaryOut(pay, from, to) { return sum(pay, from, to, function (p) { return p.amount; }); }
  function expensesIn(exp, from, to) { return sum(exp, from, to); }

  /* Net Operating Profit = Income - (Paid Expenses + Salary & advance actually paid). Unpaid salary is NOT included. */
  function finance(sales, exp, pay, from, to) {
    var income = incomeIn(sales, from, to), otherExp = expensesIn(exp, from, to), sal = salaryOut(pay, from, to);
    var totalExp = r2(otherExp + sal);
    return { income: income, otherExpenses: otherExp, salaryPaid: sal, totalExpenses: totalExp, profit: r2(income - totalExp) };
  }

  function ethMonthKey(iso) { var e = Cal.isoToEth(iso); return e.y * 100 + e.m; }
  function nextKey(k) { var y = Math.floor(k / 100), m = k % 100; return m === 13 ? (y + 1) * 100 + 1 : k + 1; }

  /* Salary for one employee for one Ethiopian month key (yyyymm). Payments are the ONLY thing that reduce what is owed. */
  function salaryForMonth(emp, payments, key) {
    var paid = 0, adv = 0;
    payments.forEach(function (p) { if (p.empId === emp.id && p.forMonth === key) { if (p.type === 'advance') adv += num(p.amount); else paid += num(p.amount); } });
    var due = num(emp.salary), total = r2(paid + adv);
    return { due: due, paid: r2(paid), advance: r2(adv), remaining: r2(Math.max(0, due - total)), overpaid: r2(Math.max(0, total - due)) };
  }
  /* Unpaid salary from employee start month until current month (active employees only). */
  function unpaidSalary(emps, payments, todayIso) {
    var cur = ethMonthKey(todayIso), total = 0, per = {};
    emps.forEach(function (e) {
      if (e.status !== 'active') return;
      var k = ethMonthKey(e.startDate || todayIso), sub = 0;
      while (k <= cur) { sub += salaryForMonth(e, payments, k).remaining; k = nextKey(k); }
      per[e.id] = r2(sub); total += sub;
    });
    return { total: r2(total), perEmployee: per };
  }

  function attendanceTotals(rows) {
    var t = { present: 0, absent: 0, late: 0, half: 0, leave: 0, workingDays: 0 };
    rows.forEach(function (r) { if (t[r.status] !== undefined) t[r.status]++; });
    t.workingDays = t.present + t.late + t.half * 0.5; // counts days actually worked
    return t;
  }

  function orderTotal(items) { var t = 0; (items || []).forEach(function (i) { t += num(i.price) * num(i.qty); }); return r2(t); }

  /* Stock: movement types add (+), use (-), waste (-). */
  function stockLevel(item, moves) {
    var q = num(item.openingQty);
    moves.forEach(function (m) { if (m.itemId === item.id) q += (m.type === 'add' ? 1 : -1) * num(m.qty); });
    return r2(q);
  }
  function toCsv(rows) {
    function esc(v) { v = v === undefined || v === null ? '' : String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
    return rows.map(function (r) { return r.map(esc).join(','); }).join('\n');
  }
  var api = { num: num, r2: r2, monthRange: monthRange, yearRange: yearRange, gMonthRange: gMonthRange, gYearRange: gYearRange, inRange: inRange, sum: sum, incomeIn: incomeIn, salaryOut: salaryOut, expensesIn: expensesIn, finance: finance, ethMonthKey: ethMonthKey, nextKey: nextKey, salaryForMonth: salaryForMonth, unpaidSalary: unpaidSalary, attendanceTotals: attendanceTotals, orderTotal: orderTotal, stockLevel: stockLevel, toCsv: toCsv };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Calc = api;
})(typeof self !== 'undefined' ? self : this);
