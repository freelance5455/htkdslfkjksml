/* Ethiopian <-> Gregorian conversion (exact, integer Julian Day Number method). Offline, no libraries. */
(function (root) {
  var OFFSET = 1723856; // JDN epoch of Ethiopic calendar
  var MONTHS_EN = ['Meskerem','Tikimt','Hidar','Tahsas','Tir','Yekatit','Megabit','Miazia','Ginbot','Sene','Hamle','Nehase','Pagume'];
  var MONTHS_AM = ['መስከረም','ጥቅምት','ኅዳር','ታኅሣሥ','ጥር','የካቲት','መጋቢት','ሚያዝያ','ግንቦት','ሰኔ','ሐምሌ','ነሐሴ','ጳጉሜ'];
  var G_MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  var DAYS_EN = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  var DAYS_AM = ['እሑድ','ሰኞ','ማክሰኞ','ረቡዕ','ሐሙስ','አርብ','ቅዳሜ'];

  function div(a, b) { return Math.floor(a / b); }
  function mod(a, b) { return ((a % b) + b) % b; }

  function gregToJDN(y, m, d) {
    var a = div(14 - m, 12), yy = y + 4800 - a, mm = m + 12 * a - 3;
    return d + div(153 * mm + 2, 5) + 365 * yy + div(yy, 4) - div(yy, 100) + div(yy, 400) - 32045;
  }
  function jdnToGreg(jdn) {
    var a = jdn + 32044, b = div(4 * a + 3, 146097), c = a - div(146097 * b, 4);
    var d = div(4 * c + 3, 1461), e = c - div(1461 * d, 4), m = div(5 * e + 2, 153);
    return { y: 100 * b + d - 4800 + div(m, 10), m: m + 3 - 12 * div(m, 10), d: e - div(153 * m + 2, 5) + 1 };
  }
  function ethToJDN(y, m, d) {
    return OFFSET + 365 + 365 * (y - 1) + div(y, 4) + 30 * m + d - 31;
  }
  function jdnToEth(jdn) {
    var r = mod(jdn - OFFSET, 1461);
    var n = mod(r, 365) + 365 * div(r, 1460);
    var year = 4 * div(jdn - OFFSET, 1461) + div(r, 365) - div(r, 1460);
    return { y: year, m: div(n, 30) + 1, d: mod(n, 30) + 1 };
  }
  function isEthLeap(y) { return mod(y, 4) === 3; }
  function ethMonthDays(y, m) { return m < 13 ? 30 : (isEthLeap(y) ? 6 : 5); }
  function isEthValid(y, m, d) { return m >= 1 && m <= 13 && d >= 1 && d <= ethMonthDays(y, m); }
  function gregMonthDays(y, m) { return new Date(Date.UTC(y, m, 0)).getUTCDate(); }

  function pad(n, l) { n = String(n); while (n.length < (l || 2)) n = '0' + n; return n; }
  function iso(g) { return pad(g.y, 4) + '-' + pad(g.m) + '-' + pad(g.d); }
  function parseIso(s) { var p = s.split('-'); return { y: +p[0], m: +p[1], d: +p[2] }; }

  function ethToIso(y, m, d) { return iso(jdnToGreg(ethToJDN(y, m, d))); }
  function isoToEth(s) { var g = parseIso(s); return jdnToEth(gregToJDN(g.y, g.m, g.d)); }
  function weekday(s) { var g = parseIso(s); return mod(gregToJDN(g.y, g.m, g.d) + 1, 7); } // 0 = Sunday
  function addDays(s, n) { var g = parseIso(s); return iso(jdnToGreg(gregToJDN(g.y, g.m, g.d) + n)); }

  /* "Today" in Africa/Addis_Ababa, always (UTC+3, no DST). Independent of phone time zone. */
  function todayIso(now) {
    var t = new Date((now || Date.now()) + 3 * 3600 * 1000);
    return pad(t.getUTCFullYear(), 4) + '-' + pad(t.getUTCMonth() + 1) + '-' + pad(t.getUTCDate());
  }
  function nowTime(now) {
    var t = new Date((now || Date.now()) + 3 * 3600 * 1000);
    return pad(t.getUTCHours()) + ':' + pad(t.getUTCMinutes());
  }

  /* Format a stored ISO (Gregorian) date for display. mode: 'eth' | 'greg'; lang: 'en' | 'am' */
  function fmt(s, mode, lang) {
    if (!s) return '';
    if (mode === 'greg') { var g = parseIso(s); return g.d + ' ' + G_MONTHS[g.m - 1] + ' ' + g.y; }
    var e = isoToEth(s);
    return e.d + ' ' + (lang === 'am' ? MONTHS_AM : MONTHS_EN)[e.m - 1] + ' ' + e.y;
  }

  var api = {
    MONTHS_EN: MONTHS_EN, MONTHS_AM: MONTHS_AM, G_MONTHS: G_MONTHS, DAYS_EN: DAYS_EN, DAYS_AM: DAYS_AM,
    gregToJDN: gregToJDN, jdnToGreg: jdnToGreg, ethToJDN: ethToJDN, jdnToEth: jdnToEth,
    isEthLeap: isEthLeap, ethMonthDays: ethMonthDays, isEthValid: isEthValid, gregMonthDays: gregMonthDays,
    ethToIso: ethToIso, isoToEth: isoToEth, weekday: weekday, addDays: addDays,
    todayIso: todayIso, nowTime: nowTime, fmt: fmt, pad: pad, parseIso: parseIso, iso: iso
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.EthCal = api;
})(typeof self !== 'undefined' ? self : this);
