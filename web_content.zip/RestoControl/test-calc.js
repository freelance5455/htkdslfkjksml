const C=require('./js/calc.js'),E=require('./js/ethcal.js');let f=0;
function eq(a,b,m){const ok=JSON.stringify(a)===JSON.stringify(b);if(!ok){f++;console.log('FAIL',m,JSON.stringify(a),'!=',JSON.stringify(b));}else console.log('ok',m);}
// profit: unpaid salary NOT counted
const sales=[{date:'2026-10-31',amount:1000,status:'paid'},{date:'2026-10-31',amount:500,status:'cancelled'},{date:'2026-10-30',amount:200,status:'paid'}];
const exp=[{date:'2026-10-31',amount:300}];
const pay=[{date:'2026-10-31',amount:100,empId:1,type:'salary',forMonth:201902}];
eq(C.finance(sales,exp,pay,'2026-10-31','2026-10-31'),{income:1000,otherExpenses:300,salaryPaid:100,totalExpenses:400,profit:600},'daily profit, cancelled excluded');
eq(C.finance(sales,exp,[],'2026-10-30','2026-10-31').profit,900,'range profit no salary');
// salary: attendance irrelevant, only payments reduce
const emp={id:1,salary:3000,status:'active',startDate:'2026-09-11'};
eq(C.salaryForMonth(emp,[],201902),{due:3000,paid:0,advance:0,remaining:3000,overpaid:0},'nothing paid');
const p2=[{empId:1,type:'advance',amount:500,forMonth:201902},{empId:1,type:'salary',amount:1000,forMonth:201902}];
eq(C.salaryForMonth(emp,p2,201902),{due:3000,paid:1000,advance:500,remaining:1500,overpaid:0},'advance + partial');
eq(C.unpaidSalary([emp],[],'2026-10-31').total,6000,'2 months unpaid (Meskerem+Tikimt)');
eq(C.unpaidSalary([emp],p2,'2026-10-31').total,4500,'unpaid after payments');
eq(C.unpaidSalary([{...emp,status:'inactive'}],[],'2026-10-31').total,0,'inactive ignored');
eq(C.nextKey(201913),202001,'Pagume -> next year Meskerem');
eq(C.monthRange(2019,2),['2026-10-11','2026-11-09'],'Tikimt 2019 range');
eq(C.yearRange(2019),['2026-09-11','2027-09-11'],'Eth year 2019 range (leap, Pagume has 6 days)');
eq(C.attendanceTotals([{status:'present'},{status:'late'},{status:'half'},{status:'absent'},{status:'leave'}]),{present:1,absent:1,late:1,half:1,leave:1,workingDays:2.5},'attendance totals');
eq(C.orderTotal([{price:50,qty:2},{price:12.5,qty:3}]),137.5,'order total');
eq(C.stockLevel({id:1,openingQty:10},[{itemId:1,type:'add',qty:5},{itemId:1,type:'use',qty:3},{itemId:1,type:'waste',qty:1},{itemId:2,type:'add',qty:99}]),11,'stock level');
eq(C.toCsv([['a','b,c'],['x"y',1]]),'a,"b,c"\n"x""y",1','csv escaping');
console.log(f?'FAILURES '+f:'ALL PASSED');
