const SH={2:[2],3:[2,8],4:[2,8,8],5:[2,8,18,8],6:[2,8,18,18,8],7:[2,8,18,32,18,8]};
const CORE={2:'[He]',3:'[Ne]',4:'[Ar]',5:'[Kr]',6:'[Xe]',7:'[Rn]'};
const COL={am:'#ff6b6b',ae:'#ffa94d',tm:'#4dabf7',pt:'#38d9a9',ml:'#a9e34b',nm:'#ffd43b',ha:'#f783ac',ng:'#b197fc',ln:'#66d9e8',ac:'#e599f7',uk:'#868e96'};
function pos(z){ // [row, column, period]
  if(z==1)return[1,1,1]; if(z==2)return[1,18,1];
  if(z<5)return[2,z-2,2]; if(z<11)return[2,z+8,2];
  if(z<13)return[3,z-10,3]; if(z<19)return[3,z,3];
  if(z<37)return[4,z-18,4]; if(z<55)return[5,z-36,5];
  if(z<57)return[6,z-54,6]; if(z<71)return[9,z-53,6]; if(z<87)return[6,z-68,6];
  if(z<89)return[7,z-86,7]; if(z<103)return[10,z-85,7]; return[7,z-100,7];}
const E=RAW.split('\n').map((l,i)=>{const[s,n,m,c,f,mp,bp,y]=l.split('|');const z=i+1,[r,col,p]=pos(z);
  const sh=p>1?[...SH[p]]:[];f.split(' ').forEach(t=>{const g=/^(\d)[spdf](\d+)$/.exec(t);sh[g[1]-1]=(sh[g[1]-1]||0)+ +g[2]});
  return{z,s,n,m,c,cfg:(p>1?CORE[p]+' ':'')+f,mp:+mp||0,bp:+bp||0,y:+y,r,col,p,sh:sh.map(v=>v||0)}});
const $=id=>document.getElementById(id);let filter=null;
function state(e,T){if(!e.mp)return'unk';if(e.bp&&T>=e.bp)return'gas';return T>=e.mp?'liquid':'solid'}
const grid=$('grid');
E.forEach(e=>{const b=document.createElement('button');b.className='el';b.style.cssText=`--r:${e.r};--c:${e.col};--k:${COL[e.c]}`;
  b.innerHTML=`<i>${e.z}</i><small>${e.m.split('.')[0]}</small><b>${e.s}</b><span style="font-size:10px">${e.n}</span>`;
  b.title=`${e.n} (${CATS[e.c]})`;b.onclick=()=>show(e);e.el=b;grid.appendChild(b)});
const lg=$('legend');Object.keys(CATS).forEach(k=>{const b=document.createElement('button');b.style.setProperty('--c',COL[k]);b.textContent=CATS[k];
  b.onclick=()=>{filter=filter==k?null:k;[...lg.children].forEach(x=>x.classList.toggle('on',x===b&&filter));update()};lg.appendChild(b)});
function update(){const q=$('q').value.trim().toLowerCase(),T=+$('t').value;
  $('tv').textContent=`${T} K · ${Math.round(T-273.15)} °C`;
  E.forEach(e=>{const hit=(!q||e.n.toLowerCase().includes(q)||e.s.toLowerCase()==q||String(e.z)==q)&&(!filter||e.c==filter);
    e.el.className='el '+state(e,T)+(hit?'':' dim')})}
$('q').oninput=update;$('t').oninput=update;update();
const ph={solid:'Solid',liquid:'Liquid',gas:'Gas',unk:'Unknown'};
function show(e){const T=293,k=COL[e.c];let rings='';
  e.sh.forEach((n,i)=>{const R=22+i*(78/Math.max(e.sh.length,1));rings+=`<circle class="orb" cx="100" cy="100" r="${R}"/><g class="ring" style="animation-duration:${6+i*4}s">`+
    Array.from({length:n},(_,j)=>{const a=j/n*6.283;return`<circle class="dot" r="2.6" cx="${100+R*Math.cos(a)}" cy="${100+R*Math.sin(a)}"/>`}).join('')+'</g>'});
  const K=v=>v?`${v} K (${Math.round(v-273.15)} °C)`:'Not known';
  $('info').innerHTML=`<div class="d" style="--k:${k}"><div><div class="big"><span>${e.z}</span><b>${e.s}</b><span>${e.m}</span></div>
  <svg class="atom" viewBox="0 0 200 200"><circle class="nuc" cx="100" cy="100" r="11"/>${rings}</svg></div>
  <div><h2>${e.n}</h2><span class="tag">${CATS[e.c]}</span>
  <dl><dt>Atomic number</dt><dd>${e.z}</dd><dt>Atomic mass</dt><dd>${e.m} u</dd><dt>Period</dt><dd>${e.p}</dd>
  <dt>Group</dt><dd>${e.col>2&&e.r>8?'f-block':e.col}</dd><dt>Electrons per shell</dt><dd>${e.sh.join(', ')}</dd>
  <dt>Configuration</dt><dd>${e.cfg}</dd><dt>Melting point</dt><dd>${K(e.mp)}</dd><dt>Boiling point</dt><dd>${K(e.bp)}</dd>
  <dt>State at 20 °C</dt><dd>${ph[state(e,T)]}</dd><dt>Discovered</dt><dd>${e.y?e.y:'Known since ancient times'}</dd></dl>
  <p><a target="_blank" rel="noopener" href="https://en.wikipedia.org/wiki/${e.n}">Read more on Wikipedia</a></p></div></div>`;
  $('dlg').showModal()}
$('x').onclick=()=>$('dlg').close();$('dlg').onclick=ev=>{if(ev.target.id=='dlg')$('dlg').close()};
