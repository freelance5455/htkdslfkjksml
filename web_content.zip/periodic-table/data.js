// Sym|Name|Atomic mass|Category|Valence config (core noble gas added automatically)|Melting K|Boiling K|Year discovered (0 = ancient)
const RAW = `H|Hydrogen|1.008|nm|1s1|14|20|1766
He|Helium|4.0026|ng|1s2|1|4|1895
Li|Lithium|6.94|am|2s1|454|1603|1817
Be|Beryllium|9.0122|ae|2s2|1560|2742|1798
B|Boron|10.81|ml|2s2 2p1|2349|4200|1808
C|Carbon|12.011|nm|2s2 2p2|3800|4300|0
N|Nitrogen|14.007|nm|2s2 2p3|63|77|1772
O|Oxygen|15.999|nm|2s2 2p4|54|90|1774
F|Fluorine|18.998|ha|2s2 2p5|53|85|1886
Ne|Neon|20.180|ng|2s2 2p6|25|27|1898
Na|Sodium|22.990|am|3s1|371|1156|1807
Mg|Magnesium|24.305|ae|3s2|923|1363|1755
Al|Aluminium|26.982|pt|3s2 3p1|933|2792|1825
Si|Silicon|28.085|ml|3s2 3p2|1687|3538|1824
P|Phosphorus|30.974|nm|3s2 3p3|317|553|1669
S|Sulfur|32.06|nm|3s2 3p4|388|718|0
Cl|Chlorine|35.45|ha|3s2 3p5|172|239|1774
Ar|Argon|39.948|ng|3s2 3p6|84|87|1894
K|Potassium|39.098|am|4s1|337|1032|1807
Ca|Calcium|40.078|ae|4s2|1115|1757|1808
Sc|Scandium|44.956|tm|3d1 4s2|1814|3109|1879
Ti|Titanium|47.867|tm|3d2 4s2|1941|3560|1791
V|Vanadium|50.942|tm|3d3 4s2|2183|3680|1801
Cr|Chromium|51.996|tm|3d5 4s1|2180|2944|1797
Mn|Manganese|54.938|tm|3d5 4s2|1519|2334|1774
Fe|Iron|55.845|tm|3d6 4s2|1811|3134|0
Co|Cobalt|58.933|tm|3d7 4s2|1768|3200|1735
Ni|Nickel|58.693|tm|3d8 4s2|1728|3186|1751
Cu|Copper|63.546|tm|3d10 4s1|1358|2835|0
Zn|Zinc|65.38|tm|3d10 4s2|693|1180|1746
Ga|Gallium|69.723|pt|3d10 4s2 4p1|303|2477|1875
Ge|Germanium|72.630|ml|3d10 4s2 4p2|1211|3106|1886
As|Arsenic|74.922|ml|3d10 4s2 4p3|1090|887|0
Se|Selenium|78.971|nm|3d10 4s2 4p4|494|958|1817
Br|Bromine|79.904|ha|3d10 4s2 4p5|266|332|1826
Kr|Krypton|83.798|ng|3d10 4s2 4p6|116|120|1898
Rb|Rubidium|85.468|am|5s1|312|961|1861
Sr|Strontium|87.62|ae|5s2|1050|1655|1790
Y|Yttrium|88.906|tm|4d1 5s2|1799|3609|1794
Zr|Zirconium|91.224|tm|4d2 5s2|2128|4682|1789
Nb|Niobium|92.906|tm|4d4 5s1|2750|5017|1801
Mo|Molybdenum|95.95|tm|4d5 5s1|2896|4912|1778
Tc|Technetium|98|tm|4d5 5s2|2430|4538|1937
Ru|Ruthenium|101.07|tm|4d7 5s1|2607|4423|1844
Rh|Rhodium|102.91|tm|4d8 5s1|2237|3968|1803
Pd|Palladium|106.42|tm|4d10|1828|3236|1803
Ag|Silver|107.87|tm|4d10 5s1|1235|2435|0
Cd|Cadmium|112.41|tm|4d10 5s2|594|1040|1817
In|Indium|114.82|pt|4d10 5s2 5p1|430|2345|1863
Sn|Tin|118.71|pt|4d10 5s2 5p2|505|2875|0
Sb|Antimony|121.76|ml|4d10 5s2 5p3|904|1860|0
Te|Tellurium|127.60|ml|4d10 5s2 5p4|723|1261|1782
I|Iodine|126.90|ha|4d10 5s2 5p5|387|457|1811
Xe|Xenon|131.29|ng|4d10 5s2 5p6|161|165|1898
Cs|Caesium|132.91|am|6s1|302|944|1860
Ba|Barium|137.33|ae|6s2|1000|2118|1808
La|Lanthanum|138.91|ln|5d1 6s2|1193|3737|1839
Ce|Cerium|140.12|ln|4f1 5d1 6s2|1068|3716|1803
Pr|Praseodymium|140.91|ln|4f3 6s2|1208|3793|1885
Nd|Neodymium|144.24|ln|4f4 6s2|1297|3347|1885
Pm|Promethium|145|ln|4f5 6s2|1315|3273|1945
Sm|Samarium|150.36|ln|4f6 6s2|1345|2067|1879
Eu|Europium|151.96|ln|4f7 6s2|1099|1802|1901
Gd|Gadolinium|157.25|ln|4f7 5d1 6s2|1585|3546|1880
Tb|Terbium|158.93|ln|4f9 6s2|1629|3503|1843
Dy|Dysprosium|162.50|ln|4f10 6s2|1680|2840|1886
Ho|Holmium|164.93|ln|4f11 6s2|1734|2993|1878
Er|Erbium|167.26|ln|4f12 6s2|1802|3141|1843
Tm|Thulium|168.93|ln|4f13 6s2|1818|2223|1879
Yb|Ytterbium|173.05|ln|4f14 6s2|1097|1469|1878
Lu|Lutetium|174.97|ln|4f14 5d1 6s2|1925|3675|1907
Hf|Hafnium|178.49|tm|4f14 5d2 6s2|2506|4876|1923
Ta|Tantalum|180.95|tm|4f14 5d3 6s2|3290|5731|1802
W|Tungsten|183.84|tm|4f14 5d4 6s2|3695|5828|1783
Re|Rhenium|186.21|tm|4f14 5d5 6s2|3459|5869|1925
Os|Osmium|190.23|tm|4f14 5d6 6s2|3306|5285|1803
Ir|Iridium|192.22|tm|4f14 5d7 6s2|2719|4701|1803
Pt|Platinum|195.08|tm|4f14 5d9 6s1|2041|4098|1735
Au|Gold|196.97|tm|4f14 5d10 6s1|1337|3129|0
Hg|Mercury|200.59|tm|4f14 5d10 6s2|234|630|0
Tl|Thallium|204.38|pt|4f14 5d10 6s2 6p1|577|1746|1861
Pb|Lead|207.2|pt|4f14 5d10 6s2 6p2|601|2022|0
Bi|Bismuth|208.98|pt|4f14 5d10 6s2 6p3|544|1837|1753
Po|Polonium|209|pt|4f14 5d10 6s2 6p4|527|1235|1898
At|Astatine|210|ha|4f14 5d10 6s2 6p5|575|610|1940
Rn|Radon|222|ng|4f14 5d10 6s2 6p6|202|211|1900
Fr|Francium|223|am|7s1|300|950|1939
Ra|Radium|226|ae|7s2|973|2010|1898
Ac|Actinium|227|ac|6d1 7s2|1323|3471|1899
Th|Thorium|232.04|ac|6d2 7s2|2023|5061|1829
Pa|Protactinium|231.04|ac|5f2 6d1 7s2|1841|4300|1913
U|Uranium|238.03|ac|5f3 6d1 7s2|1405|4404|1789
Np|Neptunium|237|ac|5f4 6d1 7s2|917|4273|1940
Pu|Plutonium|244|ac|5f6 7s2|913|3501|1940
Am|Americium|243|ac|5f7 7s2|1449|2880|1944
Cm|Curium|247|ac|5f7 6d1 7s2|1613|3383|1944
Bk|Berkelium|247|ac|5f9 7s2|1259|2900|1949
Cf|Californium|251|ac|5f10 7s2|1173|1743|1950
Es|Einsteinium|252|ac|5f11 7s2|1133||1952
Fm|Fermium|257|ac|5f12 7s2|1800||1952
Md|Mendelevium|258|ac|5f13 7s2|1100||1955
No|Nobelium|259|ac|5f14 7s2|1100||1957
Lr|Lawrencium|266|ac|5f14 7s2 7p1|1900||1961
Rf|Rutherfordium|267|tm|5f14 6d2 7s2|||1964
Db|Dubnium|268|tm|5f14 6d3 7s2|||1967
Sg|Seaborgium|269|tm|5f14 6d4 7s2|||1974
Bh|Bohrium|270|tm|5f14 6d5 7s2|||1981
Hs|Hassium|277|tm|5f14 6d6 7s2|||1984
Mt|Meitnerium|278|uk|5f14 6d7 7s2|||1982
Ds|Darmstadtium|281|uk|5f14 6d8 7s2|||1994
Rg|Roentgenium|282|uk|5f14 6d9 7s2|||1994
Cn|Copernicium|285|tm|5f14 6d10 7s2|||1996
Nh|Nihonium|286|uk|5f14 6d10 7s2 7p1|||2004
Fl|Flerovium|289|uk|5f14 6d10 7s2 7p2|||1998
Mc|Moscovium|290|uk|5f14 6d10 7s2 7p3|||2003
Lv|Livermorium|293|uk|5f14 6d10 7s2 7p4|||2000
Ts|Tennessine|294|uk|5f14 6d10 7s2 7p5|||2010
Og|Oganesson|294|uk|5f14 6d10 7s2 7p6|||2002`;
const CATS = {am:'Alkali metal',ae:'Alkaline earth metal',tm:'Transition metal',pt:'Post-transition metal',ml:'Metalloid',nm:'Reactive nonmetal',ha:'Halogen',ng:'Noble gas',ln:'Lanthanide',ac:'Actinide',uk:'Unknown properties'};
