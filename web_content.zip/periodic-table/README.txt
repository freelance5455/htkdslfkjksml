Periodic Table
Open index.html in any browser. No install or internet needed (except the Wikipedia links).
Files: index.html (page), style.css (design), data.js (all 118 elements), script.js (logic).
Features: color-coded categories, search, category filter, temperature slider that shows solid/liquid/gas,
and a detail card with an animated atom model, electron shells, configuration, melting/boiling points and discovery year.
