APPRECIATE OS — ONE COMPLETE SOURCE PACKAGE
Release bundle: v1.48

This single ZIP contains the APPRECIATE application, APPRECIATE CLOUD control plane, optional APPRECIATE AI gateway/model runtime, EDGE node software, database definitions, deployment files, documentation and tests. Keep the extracted project together; do not split it into separate downloads.

START HERE
1. Read appreciate_work/START_HERE.txt.
2. Read appreciate_work/RELEASE_STATUS.md and appreciate_work/OWNERSHIP_AND_CONTROL.md.
3. The customer app and registration/login system are in appreciate_work/app/. The HTML-to-APK wrapper target is appreciate_work/app/public/index.html (after the app is deployed on HTTPS).
4. The APPRECIATE CLOUD owner portal/control plane is in appreciate_work/cloud-control/ and is orchestrated with the root docker-compose.yml.
5. The optional self-hosted AI gateway and Ollama model runtime are in appreciate_work/appreciate-ai/ and the root docker-compose.yml AI profile.
6. Deploy the stack on a continuously available host with Docker Engine/Compose, persistent storage, HTTPS/domain routing and a supported PostgreSQL setup. Configure secrets only in the host environment/.env; never put them in GitHub, this ZIP's public files, or the APK.

IMPORTANT STATUS
This is one consolidated SOURCE package, not a deployed public service and not a compiled APK. No live host, production database, public HTTPS endpoint, real AI inference or external payment/royalty/courier provider is claimed as activated by the archive. Some provider integrations require separate merchant/developer approvals, credentials and live tests. APPRECIATE AI is included as an optional self-hosted gateway + Ollama runtime, but its app UI/API integration and production deployment are not complete. See APPRECIATE_AI_BUILD_NOTES_V1_46.md and RELEASE_STATUS.md.

Do not use a local phone localhost address as the public app URL. The APK wrapper must point to the deployed HTTPS app URL.
