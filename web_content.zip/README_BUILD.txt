WORK TRACKING SHEET - APK PROJECT

This is an Android Studio WebView project.

BUILD:
1. Install Android Studio on Windows/Mac/Linux.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync.
4. Build > Build APK(s).
5. The debug APK will be generated under:
   app/build/outputs/apk/debug/app-debug.apk

IMPORTANT:
- The HTML is bundled inside the APK and works offline.
- Data is stored in WebView DOM storage/localStorage.
- Android Back is handled one WebView history step at a time.
- For a production release, create an app icon and sign the APK/AAB.

NOTE:
The source HTML was adapted for APK packaging and keeps the Work Tracking Sheet workflow.
