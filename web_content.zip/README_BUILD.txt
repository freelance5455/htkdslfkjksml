TDH PickleQue Android App
==========================

This project packages the existing TDH PickleQue HTML as a standalone Android app.
The app is fully offline: the HTML is bundled into the APK and runs in an Android WebView.
The TDH Pickleball Club circular logo is used as the launcher icon.

Build with Android Studio:
1. Open this folder in Android Studio.
2. Let Gradle sync/download the required Android Gradle Plugin and SDK components.
3. Select Build > Build APK(s).
4. The APK will be under app/build/outputs/apk/debug/ for the debug build.

Recommended environment:
- Android Studio Quail 4 (2026.1.4) or newer compatible Android Studio.
- JDK 17.
- Android SDK Platform 37 / Build Tools 36.0.0 or newer supported by the selected AGP.

The app does not request INTERNET permission and does not require WAMP, a server, or an internet connection.
TDH PickleQue data remains local to the installed app through browser LocalStorage.
