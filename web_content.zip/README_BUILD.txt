JUVENIL V43 - TESTE FAMILIAR
Alterações desta revisão:
- Jogos ao vivo agora podem abrir a mesma tela de mercados do jogo.
- Palpites virtuais (Juvecoins) podem ser registrados durante o jogo ao vivo.
- O sistema continua bloqueando apostas após a partida terminar.
- Placar ao vivo sincroniza os jogos da lista principal.
- Proteções contra aposta em partida encerrada com tela desatualizada.
- Ajustes de compatibilidade para Safari/iPhone no HTML (viewport/PWA metadata).

IMPORTANTE SOBRE IPHONE:
Este projeto continua sendo um aplicativo Android (APK/AAB). iPhone não instala APK/AAB.
O HTML foi deixado mais compatível com Safari/PWA, mas para abrir o JUVENIL como aplicativo no iPhone será necessário publicar esta interface como web/PWA ou criar um projeto iOS.
