HISAB BOOK ANDROID PROJECT

This is an Android Studio project wrapper around the Hisab Book web app.
To build an installable APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync and install required Android SDK platform 35/build tools if prompted.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK path, usually app/build/outputs/apk/debug/app-debug.apk.

Notes:
- This workspace does not include a prebuilt APK; compiling requires Android SDK/Gradle tooling.
- Data stays inside the app's WebView storage on this device. Export/restore backups inside the app.
- The app currently has no PIN lock, cloud sync, or server-side backup.
