CBSE 12 Dashboard v2
Open this folder in Android Studio.
Let Gradle sync, then choose Build > Build APK(s).
The APK will be generated under app/build/outputs/apk/.

This version fixes the previous invalid custom-tag rendering approach and renders
all dashboard sections through standard HTML/JavaScript. Progress and theme
settings are stored locally in the WebView. No internet permission is required.
