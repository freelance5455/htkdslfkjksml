# 토공토공 Android 앱 프로젝트

기존 토공토공 HTML을 Android WebView 앱으로 감싼 프로젝트입니다.

뒤로가기 동작:
- 메인 화면이 아니면 메인 화면으로 이동
- 메인 화면에서 뒤로가기를 누르면 Android 네이티브 종료 확인창 표시
- '종료' 선택 시 앱 종료

Android Studio에서 이 폴더를 열고 Gradle 동기화 후 APK를 빌드하세요.
