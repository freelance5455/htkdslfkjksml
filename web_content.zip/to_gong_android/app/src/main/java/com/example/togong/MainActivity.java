package com.example.togong;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean exitConfirmed = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        webView = new WebView(this);
        setContentView(webView);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void goMainThen() {
        webView.evaluateJavascript("(function(){var m=document.getElementById('screen-main'); return !!(m&&m.classList.contains('active'));})()", value -> {
            boolean isMain = "true".equals(value);
            if (isMain) showExitDialog();
            else webView.evaluateJavascript("if(typeof showScreen==='function'){showScreen('main');} void(0);", null);
        });
    }

    private void showExitDialog() {
        new AlertDialog.Builder(this)
            .setTitle("토공토공")
            .setMessage("앱을 종료하시겠습니까?")
            .setNegativeButton("취소", null)
            .setPositiveButton("종료", (d, w) -> { exitConfirmed = true; finish(); })
            .show();
    }

    @Override public void onBackPressed() {
        if (exitConfirmed) { super.onBackPressed(); return; }
        goMainThen();
    }
}
