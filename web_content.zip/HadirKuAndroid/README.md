# HadirKu — proyek Android

Aplikasi daftar hadir murid yang bekerja offline. Fitur saat ini:
- PIN lokal sederhana (bukan akun online)
- Data murid
- Absensi harian: Hadir, Izin, Sakit, Alpa
- Pilihan kelas dan tanggal
- Statistik absensi dan rekap per murid
- Simpan otomatis di perangkat
- Ekspor CSV dan cadangan JSON

## Membuat APK
1. Pasang Android Studio di komputer: https://developer.android.com/studio
2. Ekstrak folder `HadirKuAndroid`.
3. Android Studio → Open → pilih folder `HadirKuAndroid`.
4. Tunggu Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35.
5. Pilih Build → Build Bundle(s) / APK(s) → Build APK(s).
6. Klik tautan lokasi APK pada notifikasi Build, lalu salin `app-debug.apk` ke HP dan buka untuk memasang.
7. Jika Android memblokir pemasangan, izinkan instalasi dari sumber tersebut pada pengaturan Android.

## Catatan penting
- Aplikasi ini tidak membutuhkan internet untuk fitur inti.
- PIN hanya melindungi layar aplikasi secara sederhana; data belum dienkripsi dan bukan sistem autentikasi yang kuat.
- Data disimpan di WebView local storage pada perangkat. Menghapus data aplikasi dapat menghapus data absensi; ekspor cadangan JSON secara berkala.
- Pengingat notifikasi Android dan sinkronisasi akun online belum diimplementasikan pada versi awal ini.
- Uji coba pada perangkat nyata sebelum dipakai untuk data sekolah penting.
