MY FITNESS - Browser app prototype

Open index.html in a modern browser on your phone or computer.
Features:
- Weekly workout plans and exercise example photo thumbnails
- Done checkboxes and session progress
- Water tracker
- Food checklist
- Personal measurements
- Reminder preference controls

Notes:
- This is a web app prototype, not an Android APK.
- Exercise photos load from the internet; a connection is needed for them.
- The simple prototype does not guarantee scheduled reminders after the page/browser is closed.
- For an installable Android APK with reliable background notifications, the app must be packaged and tested in an Android project.
