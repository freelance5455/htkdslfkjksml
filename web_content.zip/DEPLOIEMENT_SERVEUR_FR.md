# SKYNET V2 — Préparation à l'installation sur serveur

Cette livraison conserve le prototype navigateur et lui ajoute un premier backend indépendant. Elle prépare l'intégration future, sans prétendre que le serveur est déjà hébergé ni que toutes les fonctions de sécurité sont certifiées.

## Ce qui est codé maintenant
- API REST documentée automatiquement par FastAPI.
- Stockage PostgreSQL conteneurisé.
- Création initiale d'un administrateur protégée par une clé de configuration.
- Authentification JWT à expiration et hachage Argon2.
- Cloisonnement organisationnel côté serveur pour les événements, approbations et journaux.
- Journalisation d'audit des opérations couvertes.
- Calcul SHA-256 des preuves fournies (le contenu brut n'est pas conservé par cet endpoint).
- Workflow de demande et de revue humaine des actions sensibles ; aucun ordre système n'est exécuté.

## Installation future
Le dossier `server/` contient Dockerfile, docker-compose.yml, `.env.example`, dépendances et application. Le serveur devra être configuré par un administrateur technique. Ne pas publier le port API directement sur Internet : utiliser un reverse proxy HTTPS, pare-feu et secrets forts.

## Ce qui n'est pas encore terminé
Le frontend n'appelle pas encore l'API. Les connecteurs de renseignement sur les menaces, le moteur de détection validé, l'IA, MFA, gestion de secrets, migrations de base, limitation de débit, révocation des sessions, sauvegardes automatisées chiffrées, supervision et audits indépendants restent à développer.

Le projet ne doit pas être présenté à un investisseur comme un produit cloud finalisé. Il peut être présenté comme un prototype enrichi d'un socle backend préparatoire et d'une feuille de route technique vérifiable.


## Mise à jour 0.3.0

Le conteneur API exécute maintenant `alembic upgrade head` avant de démarrer. Faites une sauvegarde PostgreSQL avant toute mise à jour. Les scripts sont dans `server/scripts/backup_postgres.sh` et `server/scripts/restore_postgres.sh`. La restauration remplace la base et doit être testée sur une copie.

Le limiteur de tentatives est local au processus ; pour plusieurs réplicas, il faudra le remplacer par un stockage partagé. La MFA, l'intégration frontend/API et l'audit indépendant restent à faire avant production.
