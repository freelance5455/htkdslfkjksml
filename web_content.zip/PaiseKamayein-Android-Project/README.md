# Paise Kamayein - Android APK Source Project
Generated automatically from: **/app.html**
Package Name: `com.paisekamayein.app`

---

## 🇮🇳 हिंदी में निर्देश: अपने फ़ोन के लिए APK कैसे बनाएं?

### तरीका 1: Android Studio (सबसे आसान और आधिकारिक तरीका)
1. इस पूरे ZIP फ़ोल्डर को अपने कंप्यूटर में Extract (Unzip) करें।
2. [Android Studio](https://developer.android.com/studio) खोलें।
3. **Open an Existing Project** पर क्लिक करें और इस अनज़िप किए गए फ़ोल्डर को चुनें।
4. Gradle Sync पूरा होने तक 1-2 मिनट इंतज़ार करें।
5. ऊपर मेनू में **Build > Build Bundle(s) / APK(s) > Build APK(s)** पर क्लिक करें।
6. 1 मिनट में आपका **app-debug.apk** बनकर तैयार हो जाएगा!
7. "locate" लिंक पर क्लिक करके एपीके फ़ाइल अपने मोबाइल में भेजें और इंस्टॉल करें!

### तरीका 2: बिना किसी सॉफ्टवेयर के फ्री में APK बनाएं (GitHub Actions)
1. GitHub.com पर एक नया Private या Public Repository बनाएं।
2. इस फ़ोल्डर की सभी फ़ाइलों को GitHub पर Upload (Push) करें।
3. GitHub पर **Actions** टैब में जाएं - अपने आप Android APK Build शुरू हो जाएगा!
4. 2-3 मिनट में Action पूरा होने पर Artifacts सेक्शन से **app-apk.zip** डाउनलोड करें।
5. उसमें आपकी रेडी-टू-इंस्टॉल `.apk` फ़ाइल मिल जाएगी!

---

## 🇬🇧 English Instructions: How to Build the APK?

### Method 1: Using Android Studio
1. Unzip this project directory.
2. Open **Android Studio** and click **Open**.
3. Select this folder and wait for Gradle sync to complete.
4. Go to **Build** menu > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
5. Once built, click **locate** in the popup notification to get your `app-debug.apk`.

### Method 2: Free Cloud APK via GitHub Actions (Zero Local Setup)
1. Create a repository on GitHub and push these files.
2. The included `.github/workflows/build-apk.yml` will automatically trigger on push.
3. Download the finished APK directly from the GitHub Actions Artifacts tab!
