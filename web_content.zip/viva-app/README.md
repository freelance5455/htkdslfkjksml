# VIVA — Idiomas para a vida real

Protótipo funcional de um aplicativo de aprendizagem de espanhol para falantes de português, com foco em situações cotidianas.

## Como executar

1. Extraia o arquivo ZIP.
2. Abra `index.html` em um navegador moderno (Chrome, Edge, Firefox ou Safari).
3. Para melhor compatibilidade com recursos de instalação/PWA, sirva a pasta por um servidor local, por exemplo com `python -m http.server 8000`, e abra `http://localhost:8000`.

## O que já funciona

- Dashboard com indicadores de estudo.
- Biblioteca com 15 categorias práticas e conteúdo inicial em cada uma.
- Lições com explicação, tradução e exemplo contextualizado.
- Áudio de pronúncia via síntese de voz do navegador (quando disponível).
- Salvar expressões e anotações no caderno.
- Revisão rápida, quiz, simulação de cafeteria e escrita livre.
- Progresso local e persistência com `localStorage`.
- Layout responsivo para celular e desktop.

## Limitações desta versão

Este é um protótipo front-end: não possui contas, sincronização em nuvem, IA conversacional real, correção automática de pronúncia, nem banco de dados remoto. O progresso fica salvo no navegador e dispositivo em que foi utilizado. O conteúdo é uma amostra inicial que pode ser ampliada.

## Estrutura

- `index.html` — estrutura das telas.
- `styles.css` — identidade visual e responsividade.
- `app.js` — navegação, lições, exercícios e persistência.
- `manifest.webmanifest` — metadados básicos para instalação como aplicativo web.
