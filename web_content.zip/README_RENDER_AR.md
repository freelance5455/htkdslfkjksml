# MUNTY STORE — Render

هذه النسخة مهيأة للنشر كـ Node.js Web Service على Render.

## إعداد Render
- Build: `npm install`
- Start: `npm start`
- Health: `/health`
- Persistent data: `/opt/render/project/src/data`

## Environment Variables
- `ADMIN_PASSWORD`: كلمة مرور لوحة الإدارة
- `OPENAI_API_KEY`: مفتاح OpenAI API
- `OPENAI_MODEL`: `gpt-5.6-luna`
- `DATA_DIR`: `/opt/render/project/src/data`

## الإدارة
بعد النشر استخدم:
`/a7m3d-control-9x7k.html`

لا تفتح الصفحة من `content://` أو من مدير الملفات. يجب فتحها من رابط Render.
