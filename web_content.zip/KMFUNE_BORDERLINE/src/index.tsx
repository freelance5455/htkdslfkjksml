import { Hono } from 'hono'

// KMFUNE STUDIOS — PROJECT BORDERLINE
// The game is a fully static Three.js client living in /public/game.
// Cloudflare Pages serves those files directly; this worker only redirects
// the site root to the game entry point.
const app = new Hono()

app.get('/', (c) => c.redirect('/game/', 302))
app.get('/game', (c) => c.redirect('/game/', 301))

export default app
