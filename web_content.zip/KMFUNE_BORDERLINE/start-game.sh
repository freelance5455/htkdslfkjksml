#!/usr/bin/env sh
# KMFUNE STUDIOS — PROJECT BORDERLINE launcher (macOS / Linux)
cd "$(dirname "$0")"
if command -v node >/dev/null 2>&1; then
  (sleep 1; (xdg-open http://localhost:8080 || open http://localhost:8080) >/dev/null 2>&1) &
  node serve.mjs
elif command -v python3 >/dev/null 2>&1; then
  echo "Node.js not found - using Python. Open http://localhost:8080"
  cd public/game && python3 -m http.server 8080
else
  echo "Please install Node.js (https://nodejs.org) or Python 3."
fi
