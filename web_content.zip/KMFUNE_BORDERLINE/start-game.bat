@echo off
REM KMFUNE STUDIOS - PROJECT BORDERLINE launcher (Windows)
cd /d "%~dp0"
where node >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:8080
  node serve.mjs
  goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:8080
  cd public\game
  python -m http.server 8080
  goto :eof
)
echo Please install Node.js from https://nodejs.org or Python 3.
pause
