// =====================================================================
// Static (Node, no browser) test: builds EVERY weapon with EVERY
// compatible attachment individually + a fully-kitted build, and checks
// sockets, parts, sights/ADS, NaN geometry, attachment parenting, stat
// effects and compatibility rules.   Run:  node --import ./tests/register.mjs tests/static.test.mjs
// =====================================================================
class Ctx { createImageData(w, h) { return { data: new Uint8ClampedArray(w * h * 4), width: w, height: h }; } getImageData(x, y, w, h) { return this.createImageData(w, h); } createLinearGradient() { return { addColorStop() {} }; } createRadialGradient() { return { addColorStop() {} }; } measureText() { return { width: 10 }; } }
const ctx = () => new Proxy(new Ctx(), { get: (t, k) => (k in t ? t[k] : () => {}), set: () => true });
globalThis.document = { createElement: () => ({ width: 1, height: 1, style: {}, getContext: ctx }), getElementById: () => null };
globalThis.window = globalThis; globalThis.localStorage = { getItem: () => null, setItem() {} };
const G = '../public/game/js/weapons/';
const THREE = await import('three');
const { ALL_WEAPONS, ALL_ORDER } = await import(G + 'registry.js');
const { WeaponConfiguration, effectiveDef, WeaponStatistics, disposeModel } = await import(G + 'gunsmith.js');
const { WeaponInstance } = await import(G + 'instance.js');
let fails = 0, builds = 0; const report = [];
const ok = (c, m) => { if (!c) { fails++; report.push(m); } };
for (const id of ALL_ORDER) {
  const def = ALL_WEAPONS[id];
  const combos = [{}];
  for (const [slot, list] of Object.entries(def.slots || {})) for (const a of list) combos.push({ [slot]: a });
  const full = {}; for (const [slot, list] of Object.entries(def.slots || {})) full[slot] = list[list.length - 1]; combos.push(full);
  for (const att of combos) {
    const tag = `${id} ${JSON.stringify(att)}`;
    try {
      const w = new WeaponInstance(def, new WeaponConfiguration(id, att)); builds++;
      const m = w.model;
      for (const k of ['muzzle', 'ejection', 'rightHand', 'leftHand', 'magWell']) ok(m.sockets[k], `${tag}: missing socket ${k}`);
      ok(m.parts.trigger, `${tag}: no trigger`);
      if (def.reload.type === 'mag') ok(m.parts.mag, `${tag}: no mag pivot`);
      ok(Number.isFinite(w.adsPos.y) && Number.isFinite(w.sightPitch), `${tag}: bad ADS`);
      ok(m.meta.rearSight || m.meta.reticle || m.meta.scopeEye, `${tag}: NO SIGHTS`);
      ok(w.def.magSize > 0 && w.def.ads.time > 0, `${tag}: bad effective def`);
      let nan = 0; m.root.traverse((o) => { if (o.isMesh) { const p = o.geometry.attributes.position.array; for (let i = 0; i < p.length; i += 31) if (!Number.isFinite(p[i])) { nan++; break; } } });
      ok(!nan, `${tag}: NaN geometry`);
      for (const [slot, a] of Object.entries(m.attachments || {})) ok(a.group.parent, `${tag}: orphan ${slot}`);
      // optic must sit ON the rail: its lowest point within 2 mm of the optic socket
      if (m.attachments?.optic) {
        m.root.updateMatrixWorld(true);
        const box = new THREE.Box3().setFromObject(m.attachments.optic.group);
        const sy = m.sockets.optic.getWorldPosition(new THREE.Vector3()).y;
        ok(Math.abs(box.min.y - sy) < 0.002, `${tag}: optic floating/sunk by ${(box.min.y - sy).toFixed(4)}`);
      }
      if (!Object.keys(att).length) console.log(id.padEnd(9), 'sight', String(m.meta.sightType).padEnd(6), 'adsPos', w.adsPos.toArray().map((v) => v.toFixed(3)).join(','));
      disposeModel(m);
    } catch (e) { fails++; report.push(`${tag}: THROW ${e.message} ${e.stack.split('\n')[1]}`); }
  }
}
// gameplay effect of attachments
const base = new WeaponConfiguration('fn2000', {}), kit = new WeaponConfiguration('fn2000', { muzzle: 'supp_long', underbarrel: 'vgrip', magazine: 'mag_ext' });
const a = effectiveDef(base), b = effectiveDef(kit);
ok(b.magSize === 45 && b.recoil.pitch < a.recoil.pitch && b.ads.time > a.ads.time && b.suppressed, 'attachment effects not applied');
console.log('FN2000 stock→kitted: mag', a.magSize, '→', b.magSize, '| pitch', a.recoil.pitch.toFixed(4), '→', b.recoil.pitch.toFixed(4), '| ADS', a.ads.time, '→', b.ads.time.toFixed(3), '| suppressed', b.suppressed);
console.log('display delta', JSON.stringify(WeaponStatistics.delta(base, kit)));
ok(new WeaponConfiguration('awm', { optic: null }).att.optic === 'scope8', 'AWM must keep an optic');
ok(!Object.keys(new WeaponConfiguration('sidearm', { optic: 'scope12', underbarrel: 'vgrip' }).att).length, 'incompatible attachments accepted');
console.log(`\nbuilds ${builds}, failures ${fails}`);
report.slice(0, 40).forEach((r) => console.log('FAIL', r));
process.exit(fails ? 1 : 0);
