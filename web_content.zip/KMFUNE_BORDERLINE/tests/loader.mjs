// Node ESM resolve hook: maps the browser importmap ("three", "three/addons/") to the vendored copy.
const ROOT = new URL('../public/game/lib/', import.meta.url).href;
export async function resolve(spec, ctx, next) {
  if (spec === 'three') return next(ROOT + 'three.module.js', ctx);
  if (spec.startsWith('three/addons/')) return next(ROOT + 'addons/' + spec.slice(13), ctx);
  return next(spec, ctx);
}
