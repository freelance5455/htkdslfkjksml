// =====================================================================
// Headless browser regression test (Playwright + SwiftShader).
//   1. serve:   PORT=8090 node serve.mjs
//   2. run:     node tests/browser.test.mjs [weaponIds] [shotDir]
// For each weapon: equip → hip shot → ADS shot (+state) → burst →
// tracer cleanup check → reload → ammo check. Then Auto Sprint and
// gunsmith install/persistence checks. Exit code 1 on any failure.
// Pointer lock is stubbed; inputs go through Input._down/_up (the same
// path real key/mouse events use).
// =====================================================================
import { chromium } from 'playwright';
const ids = (process.argv[2] || 'sidearm,fn2000,scar,qbz95,dynasty,vector,p90,vanguard,bigrig,kraken,m250,awm,barrett,m700,ranger').split(',');
const dir = process.argv[3] || '/tmp/shots/';
const fs = await import('node:fs'); fs.mkdirSync(dir, { recursive: true });
const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const p = await b.newPage({ viewport: { width: 800, height: 450 } });
const logs = []; let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } };
p.on('console', (m) => { if (['error', 'warning'].includes(m.type())) logs.push(`[${m.type()}] ${m.text().slice(0, 300)}`); });
p.on('pageerror', (e) => logs.push('[pageerror] ' + e.message + ' ' + (e.stack || '').split('\n').slice(1, 3).join(' | ')));
await p.addInitScript(() => {
  if (!sessionStorage.getItem('init')) {
    localStorage.clear();
    localStorage.setItem('kmfune.borderline.settings.v1', JSON.stringify({ graphics: { preset: 'low', resolutionScale: 0.6, shadowQuality: 0, aoQuality: 0, bloom: false, antialias: 'none' } }));
    sessionStorage.setItem('init', '1');
  }
});
await p.goto('http://localhost:8090/game/', { waitUntil: 'load' });
await p.waitForSelector('#loading-start:not(.hidden)', { timeout: 180000 });
await p.evaluate(() => { window.__game.input.requestLock = () => {}; });
await p.click('#loading-start');
await p.waitForTimeout(800);
const shot = (n) => p.screenshot({ path: dir + n + '.png', timeout: 180000 });
const ev = (fn, a) => p.evaluate(fn, a);

for (const id of ids) {
  await ev((id) => { const g = window.__game; g.weapons.setLoadout(id, id === 'sidearm' ? 'fn2000' : 'sidearm'); g.startSession(); g.input.locked = true; g.player.pitch = 0; g.player.yaw = 0; }, id);
  await p.waitForTimeout(1400);
  await shot(`${id}_1hip`);
  await ev(() => window.__game.input._down('Mouse2'));
  await p.waitForTimeout(2200);
  await shot(`${id}_2ads`);
  const s1 = await ev(() => { const g = window.__game, w = g.weapons; return { ads: w.adsBlend, fov: g.camera.fov, pip: w.scopeRendering, mag: w.current.mag, sight: w.current.model.meta.sightType }; });
  ok(s1.ads > 0.99, `${id}: ADS did not complete (${s1.ads})`);
  await ev(() => window.__game.input._down('Mouse0'));
  await p.waitForTimeout(650);
  await ev(() => window.__game.input._up('Mouse0'));
  await p.waitForTimeout(300);
  const s2 = await ev(() => window.__game.weapons.current.mag);
  ok(s2 < s1.mag, `${id}: did not fire`);
  await ev(() => window.__game.input._up('Mouse2'));
  await p.waitForTimeout(2000);
  const s3 = await ev(() => { const g = window.__game; return { tracers: g.fx.tracers.filter((t) => t.alive || t.mesh.visible).length, ads: g.weapons.adsBlend, vmFov: g.weapons.vmCamera.fov }; });
  ok(s3.tracers === 0, `${id}: ${s3.tracers} tracers still alive/visible 2 s after firing`);
  ok(s3.ads === 0 && Math.abs(s3.vmFov - 60) < 0.01, `${id}: ADS not restored on release (ads ${s3.ads}, vmFov ${s3.vmFov})`);
  await ev(() => window.__game.weapons.tryReload());
  await p.waitForTimeout(1100);
  await shot(`${id}_3reload`);
  await p.waitForTimeout(5200);
  const s4 = await ev(() => { const w = window.__game.weapons; return { mag: w.current.mag, size: w.current.def.magSize, state: w.state, total: w.current.mag + w.current.reserve }; });
  ok(s4.state === 'ready', `${id}: stuck in ${s4.state} after reload`);
  ok(s4.mag === s4.size || s4.state !== 'ready', `${id}: mag ${s4.mag}/${s4.size} after reload`);
  console.log(id.padEnd(9), JSON.stringify({ sight: s1.sight, fov: +s1.fov.toFixed(1), pip: s1.pip, fired: s1.mag - s2, reload: `${s4.mag}/${s4.size}` }));
  await ev(() => window.__game.endSession());
}

// ---- Auto Sprint ----
await ev(() => { const g = window.__game; g.weapons.setLoadout('fn2000', 'sidearm'); g.startSession(); g.input.locked = true; });
const autoRes = await ev(async () => {
  const g = window.__game, { settings } = await import('./js/core/settings.js');
  // wait for N *game frames* (wall-clock waits are unreliable under software GL)
  const wait = (ms) => new Promise((r) => { let n = Math.max(6, Math.round(ms / 60)); const f = () => (--n <= 0 ? r() : requestAnimationFrame(f)); requestAnimationFrame(f); });
  await wait(600);
  const fwd = settings.controls.bindings.forward;
  settings.set('controls', 'autoSprint', true);
  g.input._down(fwd); await wait(900);
  const a = g.player.sprinting;
  g.input._down('Mouse2'); await wait(500);
  const b = g.player.sprinting;
  g.input._up('Mouse2'); await wait(900);   // forward still held → must re-sprint only now
  const c = g.player.sprinting;
  g.input._up(fwd);
  settings.set('controls', 'autoSprint', false);
  g.input._down(fwd); await wait(800);
  const d = g.player.sprinting;
  g.input._up(fwd);
  const stored = JSON.parse(localStorage.getItem('kmfune.borderline.settings.v1')).controls.autoSprint;
  return { onFwd: a, whileAds: b, afterAdsRelease: c, offFwd: d, persisted: stored === false };
});
console.log('autoSprint', JSON.stringify(autoRes));
ok(autoRes.onFwd && !autoRes.whileAds && autoRes.afterAdsRelease && !autoRes.offFwd && autoRes.persisted, 'Auto Sprint behaviour');
await ev(() => window.__game.endSession());

// ---- Gunsmith ----
await ev(() => window.__game.menus.show('loadout-screen'));
await p.waitForTimeout(1500);
await shot('gs_1armory');
await p.click('#gs-btn-alt'); await p.waitForTimeout(400);
await ev(() => { const gs = window.__game.menus.gunsmith; gs.attSlot = 'muzzle'; gs.render(); });
const cards = await p.$$('.gs-card.att');
await cards[4].hover(); await p.waitForTimeout(1800);
await shot('gs_2hover_preview');
const deltaShown = await ev(() => document.querySelectorAll('#gs-stats em.up, #gs-stats em.down').length);
ok(deltaShown > 0, 'hover shows no stat deltas');
await cards[4].click(); await p.waitForTimeout(400);
await ev(() => { const gs = window.__game.menus.gunsmith; gs.attSlot = 'optic'; gs.render(); });
const c2 = await p.$$('.gs-card.att'); await c2[1].click(); await p.waitForTimeout(1800);
await shot('gs_3installed');
const saved = await ev(() => JSON.parse(localStorage.getItem('kmfune.borderline.gunsmith.v1')).builds.fn2000);
console.log('saved build', JSON.stringify(saved));
ok(saved && saved.muzzle && saved.optic === 'red_dot', 'gunsmith build not persisted');
const live = await ev(() => { const w = window.__game.weapons.slots[0]; return { id: w.def.id, optic: !!w.model.attachments.optic, muzzle: !!w.model.attachments.muzzle, supp: w.def.suppressed }; });
console.log('live weapon', JSON.stringify(live));
ok(live.optic && live.muzzle, 'equipped weapon did not receive attachments');
await ev(() => window.__game.menus.show('main-menu', false));
await p.waitForTimeout(1500);
await shot('menu');

const errs = logs.filter((l) => !l.includes('THREE.Clock'));
console.log(errs.slice(0, 20).join('\n') || 'console: clean');
ok(!errs.some((l) => l.startsWith('[error]') || l.startsWith('[pageerror]')), 'console errors');
console.log(fails ? `\n${fails} FAILURE(S)` : '\nALL BROWSER TESTS PASSED');
await b.close();
process.exit(fails ? 1 : 0);
