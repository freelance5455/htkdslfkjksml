# KMFUNE STUDIOS — PROJECT BORDERLINE

**Developed by KMFUNE STUDIOS.** A first-person shooter for the browser, built on three.js r186 (vendored). It has a cel-shaded test range with full movement, 15 weapons, and an armory and gunsmith screen modelled on the reference video *ECC: Redline – All Gun Customisation / Attachments*.

---

## 1. Running the game

The game is a static web app. It must be served over `http://`, because opening `file://` blocks ES modules.

| OS | Command |
|---|---|
| Windows | double-click **`start-game.bat`** |
| macOS / Linux | `./start-game.sh` |
| Any (Node ≥ 18) | `node serve.mjs` → open http://localhost:8080 (`PORT=xxxx` to change) |
| Python fallback | `cd public/game && python3 -m http.server 8080` |

- Click **CLICK TO START** to unlock audio, which browsers block until you interact with the page.
- **Requires:** a WebGL2 browser (current Chrome, Edge, Firefox or Safari).
- **Hosting:** the Hono worker in `src/` only redirects `/` → `/game/`. `npm run build && npm run deploy` publishes to Cloudflare Pages.

## 2. Controls (all rebindable in Settings → Controls)

| Action | Default | Action | Default |
|---|---|---|---|
| Move | W A S D | Fire | LMB |
| Sprint | L-Shift (hold/toggle) | Aim down sights | RMB (hold/toggle) |
| Crouch / slide | C (sprint + crouch = slide) | Reload | R |
| Jump | Space | Inspect | F |
| Primary / secondary / swap | 1 / 2 / Q, mouse wheel | Fire mode | B |
| Pause | Esc | Resupply (range) | T |
| Perf overlay | F3 | | |

**Auto Sprint** (Settings → Controls → *Auto Sprint*, saved):
- Holding forward sprints without pressing Sprint.
- Aiming cancels the sprint, and it stays cancelled until you release ADS.

**Armory / gunsmith keys:**

| Key | Action |
|---|---|
| Space | Equip / install |
| F | Gunsmith / inspect |
| B | Inspect |
| Z | Strip all attachments |
| R | Reset camera |
| 1 / 2 | Choose loadout slot |
| Drag / wheel | Rotate / zoom the weapon |

## 3. Reference analysis (ECC: Redline video, 8 min 47 s)

The whole video was sampled: 1 frame every 6 s as contact sheets, plus full-resolution frames at key moments. An automated pass checked the analysis.

### Interface (confirmed)
- **Screen:** a dark armory/studio scene with one centred, studio-lit weapon. Top-left: a red title tag and a red-highlighted category tab.
- **Attachment list:** a left column of cards, each with an icon and a Chinese name. Legible examples: 条纹后握把 *striped rear grip*, 斑点后握把 *spotted rear grip*, 颗粒后握把 *granular rear grip*.
- **Stats panel:** weapon name, level line, then six white bars with numbers: damage, range (m), recoil control, hip-fire accuracy, mobility, fire rate.
  - Hovered changes show as green `(+n)` or red `(−n)`, with a coloured segment on the bar.
  - Below the bars: fire rate (RPM), sight magnification, magazine, fire mode and muzzle velocity, then an icon grid of attachment slots, a description, and a *details* button.
- **Actions:** bottom-right *Install* / *Pre-install* (in the armory: *Equip* / *Modify*), with key hints.
  - Footer hints: Esc back, B inspect, Z remove all attachments, C calibrate, R upgrade.
- **Camera:** eases in to the part being modified (muzzle, stock, grip…).
- **Range and inspect:** a first-person inspect and a live-fire sequence (7:47–8:05).
- **Weapon selection screen (8:32):** category tabs 自动步枪 ARs, 冲锋枪 SMGs, 霰弹枪 shotguns, 轻机枪 LMGs, 射手步枪 marksman rifles, 狙击枪 snipers. A pistol sits in the secondary slot.

### Weapons
| Weapon | Status | Time | Implemented as |
|---|---|---|---|
| Vector | CONFIRMED (name legible) | 0:00–0:59 | `vector`: Super-V SMG; drum, long shroud, folding stock |
| P90 | CONFIRMED (stats legible: 25 dmg, 18 m, 909 RPM, 50 rds, 883 m/s) | 1:00–1:52 | `p90`: bullpup PDW with a translucent top magazine |
| AWM | CONFIRMED | 1:53–3:05 | `awm`: olive thumbhole chassis, fluted barrel |
| Barrett (巴雷特) | CONFIRMED | 3:06–3:51 | `barrett`: .50 anti-materiel rifle |
| M700 | CONFIRMED | 3:52–4:41 | `m700`: bolt action in a skeletal chassis |
| FN2000 | CONFIRMED | 4:42–5:58 | `fn2000`: bullpup shell with forward ejection |
| SCAR | CONFIRMED | 5:59–6:57 | `scar`: monolithic rail, folding stock |
| QBZ95 | CONFIRMED (white/gold/blue skin) | 6:58–8:05 | `qbz95`: carry-handle bullpup |
| M250 | CONFIRMED (loadout screen: 41 dmg, 41 m, 550 RPM, 75 rds) | 8:32 | `m250`: belt-fed LMG with an ammo pouch |
| Glock-pattern pistol | PARTIAL (name not legible) | 8:32 | `sidearm`: shown as "P-17 SIDEARM" (generic name) |
| Origin-12 shotgun, M4-type rifle | NOT IMPLEMENTED (seen only as thumbnails) | 8:2x | the shotgun category uses the original Big Rig / Kraken |

### Attachments
- **Slots seen:** optic, muzzle, barrel, underbarrel, laser, magazine, stock, rear grip.
- **Items visually identified (partial; most names were not legible):**
  - optics: tube red dot, RMR-type mini reflex, holographic, 2.0× and 3.0×/4× prism optics, 8×/12× rifle scopes
  - muzzle: round and box suppressors, compensator, brake
  - other: vertical/stubby/angled grips, side laser, extended and drum magazines, tactical/folding stocks, three textured rear grips
- **Names in this game:** generic descriptive names. The three rear grips use the translated legible names; their Chinese labels are kept in `attachments.js` (`ref`).

## 4. What is in the game

### Weapons (15, each modelled separately; no shared generic model)
| Category | Weapons |
|---|---|
| Handguns | P-17 Sidearm |
| Assault rifles | FN2000, SCAR, QBZ95, Dynasty* |
| SMGs | Vector, P90, Vanguard* |
| Shotguns | Big Rig*, Kraken* |
| LMG | M250 |
| Snipers | AWM, Barrett, M700, Ranger* |

\* Original KMFUNE weapons (Borderlands-style set). These have fixed sights and furniture, so they have no attachment slots.

**Model structure:**
- Every reference model has the named groups MainBody, BarrelAssembly, HandguardAssembly, StockAssembly, MagazineAssembly, SightMounts, MovingParts and AttachmentPoints (sockets).
- Static meshes are merged per material inside each group (few draw calls). Moving parts stay articulated: trigger, bolt or slide, charging handle, magazine, bolt handle, feed cover, flip-up sights.
- **Barrel, magazine, stock and grip variants are modelled** (real geometry differences, not scaling). Examples: Vector long shroud and drum, folded stock, P90 long barrel, AWM cheek riser and monopod.
- **Back-up iron sights fold flat** when an optic is mounted, so they don't block the optic's view.

### Attachments (31) and compatibility
- **Library:** `js/weapons/attachments.js`. Each entry has a slot, a mount type (`pic` rail, `thread` muzzle, `under` rail, `side` rail, or `model` variant), stat modifiers and a 3D builder.
- **Compatibility:** each weapon lists the attachments it accepts per slot. `AttachmentCompatibility.sanitize()` drops incompatible items.
- **Mounting:**
  - Optics sit on the rail socket; the static test checks the gap is under 2 mm.
  - Muzzle devices thread on at the crown, and the flash and tracer origin move to the device tip.
  - Grips hang from the bottom rail; lasers mount on the side rail.
- **Sniper optic rule:** AWM, Barrett and M700 have no iron sights (as in the reference), so they always keep an optic.

### Stats change gameplay
`effectiveDef(config)` turns attachment modifiers into the numbers the game actually uses:

| Stat | In-game effect |
|---|---|
| Damage | per-hit damage |
| Range | damage falloff distances |
| Accuracy | hip, move and ADS spread |
| Control | recoil pitch, yaw, kick and recovery |
| Mobility | movement speed and draw time |
| ADS time | aim-down-sights transition time |
| Magazine | capacity, reserve and reload time |

- **Suppressors:** quieter, low-passed shot, and flash removed.
- **Optics:** set the magnification and ADS FOV.
- **Display:** the gunsmith's numbers and live deltas come from the same calculation.

### Optics and ADS
- **ADS alignment:** computed from each model's real sight geometry (rear/front iron, reflex reticle, or scope eye point), including sight-line pitch.
- **Red dot / holographic:**
  - The optic housing physically sits on its rail with a transparent glass lens.
  - The reticle (dot, or ring-dot for holo) is drawn in the lens shader along the optic axis. It is parallax-free and visible only through the lens, never as a full-screen overlay.
- **Magnified scopes (2×–12×, Ranger 6×):**
  - The eyepiece shows a picture-in-picture render from a second camera along the scope's axis, so it moves with sway and recoil.
  - The view through it has a reticle (mil-dot or chevron), an eye-box shadow and a subtle edge vignette.
  - The rest of the screen stays visible; there is **no black full-screen mask**.
  - Mouse sensitivity scales with the zoom.
- **Ranger scope:** sits on a one-piece rail base, with ring bases resting on the rail and the optical axis parallel to the bore.

### Animation, audio, recoil
- **Reloads per weapon type:**
  - tactical and empty reloads
  - P90 top-load (magazine lifts up and back)
  - M250 belt (feed cover opens, pouch swap, belt hidden while out)
  - pistol (flush drop + slide release)
  - bolt-action empty reload (bolt cycle)
  - Kraken shell-by-shell (interruptible)
- **Firing:** bolt and pump cycles; recoil comes from per-weapon recoil data.
- **Inspection:** in game (F) and in the gunsmith (B: scripted orbit and close-up).
- **Weapon sounds:** separate sounds per class (SMG, PDW, pistol, carbine, battle rifle, LMG, magnum and the originals).
  - The new class sounds are made offline from the CC0 recordings, by pitch/EQ/trim processing in ffmpeg.
- **Rapid-fire voice management:**
  - per-weapon voice group cap, with the oldest voice faded out over 20 ms (no clicks)
  - 1.5 ms attack ramps
  - duplicate suppression
  - a single retriggered range-tail voice
  - no per-shot array allocations

### Bug-fix list (previous request)
1. **Vanguard is now an SMG:**
   - model: 9 mm curved stick magazine, aperture rear sight + hooded front post
   - full-auto 860 RPM, 32-round magazine, SMG recoil and sound
   - no pellets or shells
2. Kraken: a real rail-mounted reflex optic with a transparent lens and the dot inside the lens.
3. Ranger: scope rail and rings seated on the receiver; optical axis aligned with the barrel.
4. Sniper ADS: real magnification through the scope picture-in-picture, a circular scope view and vignette, and no full-screen black overlay.
5. Every weapon's ADS uses offsets derived from its own sights, and transforms are restored on exit (tested).
6. Auto Sprint setting added (see §2).
7. **Tracer bug:** the tail could never reach the impact point, so finished tracers hung in the air.
   - Fix: the tail now passes the impact point, every tracer has a hard lifetime cap, and the pool is recycled as a ring buffer and fully reset.
8. Rapid-fire audio: see above.

## 5. Project layout
```
public/game/
  index.html, css/game.css
  js/main.js                   bootstrap, loop, scope PiP pass
  js/core/                     settings (persisted), input, events, math
  js/render/                   toon materials, ink outline, renderer/post chain, textures
  js/world/                    sky, AABB physics, test range
  js/player/                   movement controller (Auto Sprint), arms
  js/weapons/
    definitions.js             original 5 weapon definitions
    registry.js                WeaponRegistry: reference weapons, categories, compatibility lists, provenance
    refkit.js                  shared part builders (grips, rails, flip-up irons, mags, barrels)
    refmodels.js / refmodels2.js   individual reference weapon models
    models.js, kit.js          original models + geometry kit
    attachments.js             AttachmentRegistry + attachment models
    gunsmith.js                Compatibility, Configuration, Statistics, effectiveDef, assembler, LoadoutManager
    optics.js                  reflex/holo lens shader, scope lens shader, ScopeView (PiP)
    instance.js                WeaponInstance (ADS alignment from sight geometry)
    controller.js, firing.js, animations.js   state machine, firing/recoil, reload/inspect animation
  js/ui/
    gunsmith.js                GunsmithUI (armory + gunsmith)
    preview.js                 WeaponPreviewController (studio lights, orbit, slot focus)
    menus.js, hud.js
  assets/audio, assets/fonts, lib/ (three.js r186 + addons)
tests/
  static.test.mjs              node: builds all weapon × attachment combinations
  browser.test.mjs             playwright: every weapon in game + Auto Sprint + gunsmith
serve.mjs, start-game.sh/.bat  zero-dependency local server / launchers
```

### Adding a weapon
1. Write a builder (see `refmodels.js`) that returns `{root, parts, sockets, rounds, meta}`.
   - It must provide `optic/muzzle/underbarrel/laser` sockets for its slots, plus iron-sight `meta` (or `opticRequired`).
2. Add a definition to `REF_WEAPONS` in `registry.js` with `cat`, `slots`, `base` stats, recoil, reload and sound, then add it to `ALL_ORDER`.
3. Run `node --import ./tests/register.mjs tests/static.test.mjs`.

### Adding an attachment
Add an entry to `ATTACHMENTS` (slot, mount, mods, `build()` returning `{group, meta}` with origin at the mount point), then list its id in the compatible weapons' `slots`.

### Adding a map
Write a builder like `world/testRange.js` returning `{spawn, update, onTargetHit}` that registers boxes with `PhysicsWorld`, then call it in `main.js`.

## 6. Tests
```
node --import ./tests/register.mjs tests/static.test.mjs        # no browser needed
PORT=8090 node serve.mjs &  node tests/browser.test.mjs          # needs: npm i playwright && npx playwright install chromium
```
- **Static test:** 200 weapon/attachment builds. It checks sockets, parts, sights/ADS, NaN geometry, attachment parenting, optic-on-rail contact, stat effects and compatibility rules.
- **Browser test:** for every weapon:
  - hip, ADS and reload screenshots
  - ADS completes and is restored on exit
  - firing consumes ammo
  - no tracer alive 2 s after firing
  - reload completes with a full magazine

  It also tests Auto Sprint behaviour and persistence, gunsmith hover deltas, install, persistence and live application to the equipped weapon, and a clean console.

## 7. Known limitations (honest status)
- **Models are procedural reconstructions** (extruded silhouettes, lathes, bevelled boxes), not scanned or sculpted AAA assets. Each is unique and functional, but less detailed than the reference.
  - To use real assets, load a GLB in a builder and return the same `{root, parts, sockets, meta}` contract; the gunsmith and gameplay code need no changes.
- **Not implemented:**
  - the shotgun and M4 seen only in the 8:32 thumbnails
  - weapon skins (外观), weapon levels/upgrades (成长) and saved presets (方案)
  - the *calibrate* function
- **Audio:** new weapon sounds are processed versions of the CC0 recordings, not unique recordings per weapon. Suppressed shots are low-passed rather than separately recorded.
- **First-person hands:** the support-hand pose per weapon is procedural IK and approximate on some bullpups.
- **Verification limits:**
  - Testing ran in headless software rendering (SwiftShader, about 8–10 fps), so frame-time figures are not representative of real GPUs.
  - Audio quality (clicks) was checked by code inspection and voice counting, not by listening.

## 8. Credits
- three.js r186 (MIT)
- Firearm recordings: "The Free Firearm Sound Library" (CC0)
- Kenney.nl sounds (CC0)
- Fonts: Bangers and Teko (OFL)
- All models are original procedural work by KMFUNE STUDIOS. The ECC: Redline video was used only as a visual reference; no assets were extracted.
