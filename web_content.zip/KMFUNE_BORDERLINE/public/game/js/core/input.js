// =====================================================================
// Input manager
//  - keyboard + mouse buttons are unified as "codes" (mouse = Mouse0..4)
//  - actions are resolved through the rebindable bindings in settings
//  - pointer-lock aware: gameplay input only when locked & enabled
// =====================================================================
import { settings, prettyKey } from './settings.js';
import { bus } from './events.js';

export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    this.keys = new Set();
    this.pressedThisFrame = new Set();
    this.releasedThisFrame = new Set();
    this.mouse = { dx: 0, dy: 0, wheel: 0 };
    this.locked = false;
    this.enabled = false;
    this.captureNext = null; // rebinding callback(code)

    window.addEventListener('keydown', (e) => this._onKeyDown(e));
    window.addEventListener('keyup', (e) => this._up(e.code));
    window.addEventListener('blur', () => this.releaseAll());
    document.addEventListener('mousedown', (e) => this._onMouseDown(e));
    document.addEventListener('mouseup', (e) => this._up('Mouse' + e.button));
    document.addEventListener('mousemove', (e) => this._onMouseMove(e));
    document.addEventListener('wheel', (e) => { if (this.locked && this.enabled) this.mouse.wheel += Math.sign(e.deltaY); }, { passive: true });
    document.addEventListener('contextmenu', (e) => e.preventDefault());
    document.addEventListener('pointerlockchange', () => {
      const was = this.locked;
      this.locked = document.pointerLockElement === this.canvas;
      if (!this.locked) this.releaseAll();
      if (was !== this.locked) bus.emit('input:lock', this.locked);
    });
    document.addEventListener('pointerlockerror', () => bus.emit('input:lockerror'));
  }

  requestLock() {
    if (this.locked) return;
    const fallback = () => {
      try { const p2 = this.canvas.requestPointerLock(); if (p2 && p2.catch) p2.catch(() => bus.emit('input:lockerror')); }
      catch { bus.emit('input:lockerror'); }
    };
    try {
      const p = this.canvas.requestPointerLock({ unadjustedMovement: true });
      if (p && p.catch) p.catch(fallback);
    } catch { fallback(); }
  }

  exitLock() { if (document.pointerLockElement) document.exitPointerLock(); }

  releaseAll() {
    for (const k of this.keys) this.releasedThisFrame.add(k);
    this.keys.clear();
  }

  _down(code, repeat) {
    if (!repeat) this.pressedThisFrame.add(code);
    this.keys.add(code);
  }
  _up(code) {
    if (this.keys.delete(code)) this.releasedThisFrame.add(code);
  }

  _onKeyDown(e) {
    if (this.captureNext) {
      e.preventDefault();
      const cb = this.captureNext; this.captureNext = null;
      cb(e.code);
      return;
    }
    if (e.code === 'Escape') { bus.emit('input:escape'); return; }
    if (e.code === settings.controls.bindings.perf) { e.preventDefault(); if (!e.repeat) bus.emit('input:perf'); return; }
    if (!this.enabled || !this.locked) return;
    if (['Space', 'Tab', 'AltLeft', 'AltRight', 'ControlLeft', 'KeyS', 'KeyW', 'KeyD', 'KeyF'].includes(e.code) || e.code.startsWith('F')) e.preventDefault();
    this._down(e.code, e.repeat);
  }

  _onMouseDown(e) {
    if (this.captureNext) {
      e.preventDefault();
      const cb = this.captureNext; this.captureNext = null;
      cb('Mouse' + e.button);
      return;
    }
    if (!this.locked || !this.enabled) return;
    this._down('Mouse' + e.button, false);
  }

  _onMouseMove(e) {
    if (!this.locked || !this.enabled) return;
    // Guard against rare huge spikes some browsers emit right after locking.
    const mx = Math.abs(e.movementX) > 500 ? 0 : e.movementX;
    const my = Math.abs(e.movementY) > 500 ? 0 : e.movementY;
    this.mouse.dx += mx; this.mouse.dy += my;
  }

  down(action) { return this.keys.has(settings.controls.bindings[action]); }
  pressed(action) { return this.pressedThisFrame.has(settings.controls.bindings[action]); }
  released(action) { return this.releasedThisFrame.has(settings.controls.bindings[action]); }

  consumeMouse() {
    const d = { dx: this.mouse.dx, dy: this.mouse.dy };
    this.mouse.dx = 0; this.mouse.dy = 0;
    return d;
  }
  consumeWheel() { const w = this.mouse.wheel; this.mouse.wheel = 0; return w; }

  endFrame() {
    this.pressedThisFrame.clear();
    this.releasedThisFrame.clear();
  }
}

export const codeLabel = prettyKey;
