// =====================================================================
// Settings store — defaults, graphics presets, persistence, change events
// =====================================================================

export const DEFAULT_BINDINGS = {
  forward: 'KeyW',
  back: 'KeyS',
  left: 'KeyA',
  right: 'KeyD',
  jump: 'Space',
  sprint: 'ShiftLeft',
  crouch: 'KeyC',
  reload: 'KeyR',
  fire: 'Mouse0',
  ads: 'Mouse2',
  primary: 'Digit1',
  secondary: 'Digit2',
  swap: 'KeyQ',
  inspect: 'KeyF',
  firemode: 'KeyB',
  perf: 'F3',
};

export const ACTION_LABELS = {
  forward: 'Move Forward', back: 'Move Back', left: 'Strafe Left', right: 'Strafe Right',
  jump: 'Jump / Slide-Jump Cancel', sprint: 'Sprint', crouch: 'Crouch / Slide', reload: 'Reload',
  fire: 'Fire', ads: 'Aim Down Sights', primary: 'Primary Weapon', secondary: 'Secondary Weapon',
  swap: 'Swap Weapon', inspect: 'Inspect Weapon', firemode: 'Toggle Fire Mode', perf: 'Performance Overlay',
};

// Graphics presets. Each key maps 1:1 to a graphics setting.
export const PRESETS = {
  low: {
    resolutionScale: 0.7, shadowQuality: 0, shadowDistance: 30, textureQuality: 0, aoQuality: 0,
    antialias: 'fxaa', bloom: false, bloomIntensity: 0.35, postProcessing: true, viewDistance: 350,
    effectsQuality: 0, outlines: true, hatching: false,
  },
  medium: {
    resolutionScale: 0.85, shadowQuality: 1, shadowDistance: 45, textureQuality: 1, aoQuality: 0,
    antialias: 'fxaa', bloom: true, bloomIntensity: 0.35, postProcessing: true, viewDistance: 600,
    effectsQuality: 1, outlines: true, hatching: true,
  },
  high: {
    resolutionScale: 1.0, shadowQuality: 2, shadowDistance: 60, textureQuality: 2, aoQuality: 1,
    antialias: 'smaa', bloom: true, bloomIntensity: 0.4, postProcessing: true, viewDistance: 900,
    effectsQuality: 2, outlines: true, hatching: true,
  },
  ultra: {
    resolutionScale: 1.25, shadowQuality: 3, shadowDistance: 80, textureQuality: 2, aoQuality: 2,
    antialias: 'smaa', bloom: true, bloomIntensity: 0.45, postProcessing: true, viewDistance: 1400,
    effectsQuality: 2, outlines: true, hatching: true,
  },
};

export const DEFAULTS = {
  graphics: {
    preset: 'high',
    ...PRESETS.high,
    toneMapping: 'aces',      // aces | agx | neutral | linear
    exposure: 0.82,
    fov: 80,
    showFps: false,
    maxPixelRatio: 2,
  },
  controls: {
    sensitivity: 1.0,
    adsMultiplier: 0.7,
    invertY: false,
    sprintMode: 'hold',   // hold | toggle
    autoSprint: false,    // hold forward to sprint automatically (ADS cancels)
    crouchMode: 'hold',   // hold | toggle
    adsMode: 'hold',      // hold | toggle
    bindings: { ...DEFAULT_BINDINGS },
  },
  audio: {
    master: 0.8,
    weapons: 0.85,
    footsteps: 0.7,
    environment: 0.5,
    interface: 0.6,
  },
  loadout: { primary: 'fn2000', secondary: 'sidearm' },
};

const STORAGE_KEY = 'kmfune.borderline.settings.v1';

function deepClone(o) { return JSON.parse(JSON.stringify(o)); }

function deepMerge(target, src) {
  if (!src || typeof src !== 'object') return target;
  for (const k of Object.keys(target)) {
    if (!(k in src)) continue;
    const tv = target[k], sv = src[k];
    if (tv && typeof tv === 'object' && !Array.isArray(tv)) deepMerge(tv, sv);
    else if (typeof sv === typeof tv) target[k] = sv;
  }
  return target;
}

class SettingsStore {
  constructor() {
    this.data = deepClone(DEFAULTS);
    this.listeners = new Set();
    this.storageOk = true;
    this.load();
  }

  load() {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) deepMerge(this.data, JSON.parse(raw));
    } catch (e) {
      this.storageOk = false; // private mode / disabled storage: continue with defaults
    }
    this.validateBindings();
  }

  save() {
    if (!this.storageOk) return;
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data)); }
    catch (e) { this.storageOk = false; }
  }

  get graphics() { return this.data.graphics; }
  get controls() { return this.data.controls; }
  get audio() { return this.data.audio; }
  get loadout() { return this.data.loadout; }

  set(section, key, value) {
    this.data[section][key] = value;
    if (section === 'graphics' && key in PRESETS.high) this.data.graphics.preset = 'custom';
    this.save();
    this.emit(section, key);
  }

  applyPreset(name) {
    if (!PRESETS[name]) return;
    Object.assign(this.data.graphics, PRESETS[name]);
    this.data.graphics.preset = name;
    this.save();
    this.emit('graphics', '*');
  }

  // Guarantees every action has a unique, non-empty binding.
  validateBindings() {
    const b = this.data.controls.bindings;
    const used = new Set();
    for (const action of Object.keys(DEFAULT_BINDINGS)) {
      if (!b[action] || used.has(b[action]) || b[action] === 'Escape') b[action] = DEFAULT_BINDINGS[action];
      if (used.has(b[action])) {
        // default collides with a user binding — find the owner and reset both
        for (const a of Object.keys(b)) if (a !== action && b[a] === b[action]) b[a] = DEFAULT_BINDINGS[a];
      }
      used.add(b[action]);
    }
  }

  // Rebind with swap semantics: if the code is used by another action, they exchange keys.
  rebind(action, code) {
    if (code === 'Escape') return false;
    const b = this.data.controls.bindings;
    const prev = b[action];
    for (const a of Object.keys(b)) {
      if (a !== action && b[a] === code) b[a] = prev;
    }
    b[action] = code;
    this.save();
    this.emit('controls', 'bindings');
    return true;
  }

  resetControls() {
    const c = DEFAULTS.controls;
    Object.assign(this.data.controls, deepClone(c));
    this.save();
    this.emit('controls', '*');
  }

  resetAll(section) {
    this.data[section] = deepClone(DEFAULTS[section]);
    this.save();
    this.emit(section, '*');
  }

  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  emit(section, key) { for (const fn of this.listeners) fn(section, key); }
}

export const settings = new SettingsStore();

export function prettyKey(code) {
  if (!code) return '—';
  if (code === 'Mouse0') return 'LMB';
  if (code === 'Mouse1') return 'MMB';
  if (code === 'Mouse2') return 'RMB';
  if (code === 'Mouse3') return 'MB4';
  if (code === 'Mouse4') return 'MB5';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code.startsWith('Numpad')) return 'Num' + code.slice(6);
  const map = { ShiftLeft: 'L-Shift', ShiftRight: 'R-Shift', ControlLeft: 'L-Ctrl', ControlRight: 'R-Ctrl', AltLeft: 'L-Alt', AltRight: 'R-Alt', Space: 'Space', CapsLock: 'Caps', Tab: 'Tab', Backquote: '`' };
  return map[code] || code;
}
