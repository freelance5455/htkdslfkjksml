// Small math helpers shared by gameplay & animation systems.
import * as THREE from 'three';

export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const smooth = (t) => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
export const smoother = (t) => { t = clamp(t, 0, 1); return t * t * t * (t * (t * 6 - 15) + 10); };
export const easeOutCubic = (t) => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
export const easeInCubic = (t) => Math.pow(clamp(t, 0, 1), 3);
export const easeOutBack = (t) => { t = clamp(t, 0, 1); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
/** frame-rate independent exponential approach */
export const damp = (a, b, lambda, dt) => lerp(a, b, 1 - Math.exp(-lambda * dt));
export const remap01 = (v, a, b) => clamp((v - a) / (b - a), 0, 1);
export const DEG = Math.PI / 180;

/** Critically-damped-ish 1D spring (semi-implicit Euler, sub-stepped). */
export class Spring {
  constructor(stiffness = 120, damping = 14, value = 0) {
    this.k = stiffness; this.d = damping; this.value = value; this.vel = 0; this.target = 0;
  }
  impulse(v) { this.vel += v; }
  update(dt) {
    const steps = Math.max(1, Math.ceil(dt / (1 / 240)));
    const h = dt / steps;
    for (let i = 0; i < steps; i++) {
      const a = (this.target - this.value) * this.k - this.vel * this.d;
      this.vel += a * h;
      this.value += this.vel * h;
    }
    return this.value;
  }
  reset(v = 0) { this.value = v; this.vel = 0; this.target = v; }
}

/** 3-component spring for vectors / euler offsets. */
export class Spring3 {
  constructor(k, d) { this.x = new Spring(k, d); this.y = new Spring(k, d); this.z = new Spring(k, d); }
  impulse(x, y, z) { this.x.impulse(x); this.y.impulse(y); this.z.impulse(z); }
  update(dt, out) { out.set(this.x.update(dt), this.y.update(dt), this.z.update(dt)); return out; }
  reset() { this.x.reset(); this.y.reset(); this.z.reset(); }
}

const _v = new THREE.Vector3();
/** Two-bone IK. Returns elbow position (writes into outElbow). */
export function solveTwoBone(shoulder, hand, l1, l2, pole, outElbow, outHand) {
  _v.subVectors(hand, shoulder);
  let d = _v.length();
  const maxReach = (l1 + l2) * 0.999;
  const minReach = Math.abs(l1 - l2) + 1e-3;
  outHand.copy(hand);
  if (d > maxReach) { _v.multiplyScalar(maxReach / d); outHand.copy(shoulder).add(_v); d = maxReach; }
  if (d < minReach) { d = minReach; }
  const dir = _v.clone().normalize();
  // cosine law
  const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
  // pole direction orthogonalised against dir
  const p = pole.clone().sub(shoulder);
  p.sub(dir.clone().multiplyScalar(p.dot(dir))).normalize();
  outElbow.copy(shoulder).addScaledVector(dir, a).addScaledVector(p, h);
  return outElbow;
}
