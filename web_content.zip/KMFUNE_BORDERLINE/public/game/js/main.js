// =====================================================================
// KMFUNE STUDIOS — PROJECT BORDERLINE
// Application bootstrap & game loop
// =====================================================================
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { settings } from './core/settings.js';
import { bus } from './core/events.js';
import { Input } from './core/input.js';
import { GameRenderer } from './render/renderer.js';
import { getShared } from './weapons/kit.js';
import { createSky, SUN_DIR } from './world/sky.js';
import { PhysicsWorld } from './world/physics.js';
import { buildTestRange } from './world/testRange.js';
import { PlayerController } from './player/controller.js';
import { ViewArms, ShadowBody } from './player/arms.js';
import { WeaponController } from './weapons/controller.js';
import { Effects } from './fx/effects.js';
import { audio } from './audio/audio.js';
import { HUD } from './ui/hud.js';
import { Menus } from './ui/menus.js';
import { ScopeView, LENS_LAYER } from './weapons/optics.js';

const $ = (id) => document.getElementById(id);
const loadFill = $('loading-fill'), loadText = $('loading-text');
const progress = (p, t) => { loadFill.style.width = Math.round(p * 100) + '%'; if (t) loadText.textContent = t; };
const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));

class Game {
  constructor() {
    this.inSession = false;
    this.paused = true;
    this.clock = new THREE.Timer();
    this.time = 0;
    this.perf = { frames: 0, acc: 0, fps: 0, ms: 0, show: settings.graphics.showFps };
    this.hurt = 0;
  }

  async init() {
    progress(0.05, 'Initialising renderer…');
    const canvas = $('game-canvas');
    this.gr = new GameRenderer(canvas);
    const renderer = this.gr.renderer;
    if (!renderer.getContext()) throw new Error('WebGL2 is not available in this browser.');
    this.input = new Input(canvas);
    await nextFrame();

    // ---------- scenes & cameras ----------
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(settings.graphics.fov, innerWidth / innerHeight, 0.05, settings.graphics.viewDistance);
    this.camera.layers.enable(0); // player shadow body lives on layer 1 (not rendered by camera)
    this.vmScene = new THREE.Scene();
    this.vmCamera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.01, 10);
    this.vmCamera.layers.enable(LENS_LAYER);   // reflex / scope lenses
    this.scopeView = new ScopeView();

    // environment light (IBL) for metals — generated once
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environment = envTex; this.scene.environmentIntensity = 0.25;
    this.vmScene.environment = envTex; this.vmScene.environmentIntensity = 0.7;

    // fog (warm, illustrated haze)
    this.scene.fog = new THREE.Fog(0xb9cfe0, 90, settings.graphics.viewDistance);

    // ---------- lighting ----------
    this.sun = new THREE.DirectionalLight(0xfff0d8, 2.35);
    this.sun.position.copy(SUN_DIR).multiplyScalar(80);
    this.sun.castShadow = true;
    this.sun.shadow.bias = -0.0004; this.sun.shadow.normalBias = 0.035;
    this.scene.add(this.sun, this.sun.target);
    this.hemi = new THREE.HemisphereLight(0xa9c8f0, 0x7a6448, 0.62);
    this.scene.add(this.hemi);
    // viewmodel lights: same sun direction in view space is updated per frame
    this.vmSun = new THREE.DirectionalLight(0xfff0d8, 2.6);
    this.vmHemi = new THREE.HemisphereLight(0xcfe2ff, 0x6b5a44, 1.1);
    this.vmScene.add(this.vmSun, this.vmSun.target, this.vmHemi);
    this.vmFlash = new THREE.PointLight(0xffa040, 0, 1.4, 2);
    this.vmScene.add(this.vmFlash);

    progress(0.15, 'Painting textures…');
    await nextFrame();
    const tq = settings.graphics.textureQuality;
    getShared(tq);

    // ---------- world ----------
    this.sky = createSky();
    this.scene.add(this.sky.group);
    this.physics = new PhysicsWorld();
    progress(0.3, 'Pouring concrete…');
    await nextFrame();
    this.map = buildTestRange({ scene: this.scene, physics: this.physics, quality: settings.graphics, sun: this.sun });

    // ---------- systems ----------
    this.fx = new Effects(this.scene, this.physics, settings.graphics);
    this.player = new PlayerController(this.physics, this.input, this.camera);
    this.player.spawn(this.map.spawn.position, this.map.spawn.yaw);
    this.body = new ShadowBody(this.scene);
    this.arms = new ViewArms(this.vmScene);
    progress(0.45, 'Machining weapons…');
    await nextFrame();
    this.weapons = new WeaponController({ vmScene: this.vmScene, vmCamera: this.vmCamera, worldCamera: this.camera, arms: this.arms, physics: this.physics, effects: this.fx, controller: this.player, map: this.map });
    this.applyLoadout();

    this.gr.setScenes(this.scene, this.camera, this.vmScene, this.vmCamera);
    this.applyGraphics();

    progress(0.6, 'Loading audio…');
    try { await audio.load((p) => progress(0.6 + p * 0.3, 'Loading audio…')); }
    catch (e) { console.warn('Audio unavailable', e); }

    // ---------- UI ----------
    this.hud = new HUD();
    this.menus = new Menus(this);

    // ---------- pre-compile shaders (avoid hitches on first shot) ----------
    progress(0.92, 'Compiling shaders…');
    await nextFrame();
    this.warmup();

    // ---------- events ----------
    window.addEventListener('resize', () => this.gr.resize());
    settings.on((sec, key) => { if (sec === 'graphics') this.applyGraphics(key); });
    bus.on('input:escape', () => this.onEscape());
    bus.on('input:perf', () => { settings.set('graphics', 'showFps', !settings.graphics.showFps); });
    bus.on('input:lock', (locked) => this.onLockChange(locked));
    bus.on('input:lockerror', () => { if (this.inSession && !this.menus.open) $('lock-overlay').classList.remove('hidden'); });
    bus.on('player:footstep', (e) => this.footstep(e));
    bus.on('player:land', (e) => { audio.play('land', { cat: 'footsteps', volume: 0.4 + e.intensity * 0.6 }); audio.play('foot', { cat: 'footsteps', volume: 0.5 + e.intensity * 0.4, rate: 0.8 }); });
    bus.on('player:jump', () => audio.play('cloth', { cat: 'footsteps', volume: 0.35, rate: 1.2 }));
    bus.on('player:slideStart', () => { this.slideVoice = audio.play('slide', { cat: 'footsteps', volume: 0.6 }); audio.play('whoosh', { cat: 'footsteps', volume: 0.3 }); });
    bus.on('player:slideEnd', () => { if (this.slideVoice) { try { this.slideVoice.gain.gain.setTargetAtTime(0, audio.ctx.currentTime, 0.05); } catch { /* */ } this.slideVoice = null; } });
    $('lock-overlay').addEventListener('click', () => this.input.requestLock());
    canvas.addEventListener('click', () => { if (this.inSession && !this.menus.open && !this.input.locked) this.input.requestLock(); });
    window.addEventListener('keydown', (e) => { if (e.code === 'KeyT' && this.inSession && !this.paused) this.weapons.refill(); });
    document.addEventListener('visibilitychange', () => { if (document.hidden && this.inSession && !this.paused) this.pause(); });

    progress(1, 'Ready.');
    // first user gesture: unlocks audio, then show menu
    const start = $('loading-start');
    start.classList.remove('hidden');
    $('loading-text').textContent = 'KMFUNE STUDIOS — PROJECT BORDERLINE';
    await new Promise((res) => start.addEventListener('click', res, { once: true }));
    await audio.resume();
    audio.startAmbient();
    audio.ui('ui_confirm');
    $('loading-screen').classList.remove('active');
    this.menus.show('main-menu', false);
    this.clock.connect?.(document); this.clock.reset?.();
    this.loop();
  }

  warmup() {
    // render every material once in both scenes, including FX meshes
    const r = this.gr.renderer;
    this.weapons.slots.forEach((s) => { if (s.model.root.parent !== this.weapons.recoilNode) this.weapons.recoilNode.add(s.model.root); });
    this.fx.addDecal(new THREE.Vector3(0, -5, 0), new THREE.Vector3(0, 1, 0)); // offscreen decal compile
    this.fx.impact(new THREE.Vector3(0, -5, 0), new THREE.Vector3(0, 1, 0), 'metal');
    try { r.compile(this.scene, this.camera); r.compile(this.vmScene, this.vmCamera); } catch (e) { console.warn(e); }
    this.gr.render(0.016, 0, 0);
    this.weapons.slots.forEach((s, i) => { if (i !== this.weapons.active) s.model.root.removeFromParent(); });
    this.fx.reset();
  }

  applyLoadout() {
    const l = settings.loadout;
    this.weapons.setLoadout(l.primary, l.secondary);
  }

  applyGraphics(key) {
    const g = settings.graphics;
    this.gr.applySettings();
    this.camera.far = g.viewDistance; this.camera.updateProjectionMatrix();
    this.scene.fog.far = g.viewDistance; this.scene.fog.near = Math.min(80, g.viewDistance * 0.15);
    const size = this.gr.shadowMapSize || 2048;
    this.sun.castShadow = g.shadowQuality > 0;
    if (this.sun.shadow.mapSize.x !== size) {
      this.sun.shadow.mapSize.set(size, size);
      if (this.sun.shadow.map) { this.sun.shadow.map.dispose(); this.sun.shadow.map = null; }
    }
    const d = g.shadowDistance;
    const sc = this.sun.shadow.camera;
    sc.left = -d; sc.right = d; sc.top = d; sc.bottom = -d; sc.near = 1; sc.far = 220; sc.updateProjectionMatrix();
    this.perf.show = g.showFps;
    $('perf-overlay').classList.toggle('hidden', !g.showFps);
    if (key === 'fov') this.camera.fov = g.fov;
  }

  // ---------------- session flow ----------------
  startSession() {
    if (!this.inSession) {
      this.player.spawn(this.map.spawn.position, this.map.spawn.yaw);
      this.fx.reset();
      this.weapons.refill();
    }
    this.inSession = true;
    this.resume();
  }
  resume() {
    this.menus.hideAll();
    this.hud.show(true);
    this.hud.setWeapon(this.weapons.hudState());
    this.paused = false;
    this.input.enabled = true;
    this.input.requestLock();
  }
  pause() {
    this.paused = true;
    this.input.enabled = false;
    this.input.releaseAll();
    this.input.exitLock();
    $('lock-overlay').classList.add('hidden');
    this.menus.show('pause-screen', false);
  }
  endSession() {
    this.inSession = false;
    this.paused = true;
    this.input.enabled = false;
    this.input.exitLock();
    this.hud.show(false);
    this.weapons.abortActions();
    this.menus.show('main-menu', false);
  }
  onEscape() {
    if (this.input.captureNext) return;
    if (!this.inSession) { if (this.menus.current && this.menus.current !== 'main-menu') this.menus.back(); return; }
    if (this.menus.open) { if (this.menus.current === 'pause-screen') this.resume(); else this.menus.back(); }
    else this.pause();
  }
  onLockChange(locked) {
    if (locked) { $('lock-overlay').classList.add('hidden'); return; }
    // lost pointer lock while playing (Esc pressed by browser, alt-tab…) → pause menu
    if (this.inSession && !this.paused) this.pause();
  }

  footstep(e) {
    const vol = { walk: 0.45, run: 0.6, sprint: 0.75, crouch: 0.22 }[e.kind] ?? 0.5;
    audio.play('foot', { cat: 'footsteps', volume: vol, rate: e.kind === 'crouch' ? 0.9 : e.kind === 'sprint' ? 1.08 : 1, rateJitter: 0.06, lowpass: e.kind === 'crouch' ? 2500 : undefined });
    if (e.kind === 'sprint' && Math.random() < 0.5) audio.play('cloth', { cat: 'footsteps', volume: 0.15 });
  }

  // ---------------- loop ----------------
  loop() {
    requestAnimationFrame(() => this.loop());
    this.clock.update(); const dt = Math.min(this.clock.getDelta(), 0.1);
    const t0 = performance.now();
    this.time += dt;
    const active = this.inSession && !this.paused && this.input.locked;

    if (this.inSession && !this.paused) {
      this.player.enabled = true;
      if (!active) this.input.consumeMouse();
      this.player.update(active ? dt : 0.0001);
      this.weapons.update(dt, this.input, active);
    } else if (!this.inSession) {
      // attract mode: slow camera orbit behind the menu
      const a = this.time * 0.05;
      this.camera.position.set(Math.sin(a) * 6 + 2, 1.8, 20 + Math.cos(a) * 3);
      this.camera.lookAt(0, 1.4, -10);
      this.camera.fov = settings.graphics.fov; this.camera.updateProjectionMatrix();
      this.weapons.update(dt, this.input, false);
    } else {
      this.weapons.update(dt, this.input, false);
    }
    this.vmScene.visible = this.inSession;

    this.map.update(dt);
    this.body.update(this.player, dt);
    this.fx.update(dt, this.camera);
    this.sky.uniforms.time.value = this.time;
    this.sky.group.position.copy(this.camera.position);

    // sun shadow follows the player (texel-snapped to avoid shimmering)
    const g = settings.graphics;
    const focus = this.camera.position;
    const texel = (g.shadowDistance * 2) / (this.sun.shadow.mapSize.x || 2048);
    const fx = Math.round(focus.x / texel) * texel, fz = Math.round(focus.z / texel) * texel;
    this.sun.target.position.set(fx, 0, fz);
    this.sun.position.set(fx, 0, fz).addScaledVector(SUN_DIR, 100);

    // viewmodel lighting mirrors world sun in camera space
    const camQinv = this.camera.quaternion.clone().invert();
    const sunView = SUN_DIR.clone().applyQuaternion(camQinv);
    this.vmSun.position.copy(sunView).multiplyScalar(5);
    this.vmSun.target.position.set(0, 0, 0);
    this.vmFlash.intensity = this.fx.flashLightT > 0 ? 0.6 : 0;
    this.vmFlash.position.set(0.1, -0.05, -0.6);

    // audio listener
    const fwd = new THREE.Vector3(); this.camera.getWorldDirection(fwd);
    const right = new THREE.Vector3().crossVectors(fwd, new THREE.Vector3(0, 1, 0)).normalize();
    audio.setListener(this.camera.position, right, fwd);

    // magnified-scope picture-in-picture (only while a scope is raised)
    const lens = this.inSession ? this.weapons.scopeLens : null;
    this.weapons.scopeRendering = !!lens;
    if (lens) {
      const H = this.gr.renderer.domElement.height;
      const size = Math.min(g.textureQuality >= 2 ? 1024 : 640, Math.max(256, Math.round(H * 0.72 / 64) * 64));
      this.vmScene.updateMatrixWorld();
      this.scopeView.render(this.gr.renderer, this.scene, this.camera, this.vmCamera, lens, this.weapons.current.model.meta.zoom || 4, size);
    }
    // The gunsmith studio covers the whole screen with its own backdrop →
    // skip the world/post pipeline entirely while it is open.
    if (this.menus.current === 'loadout-screen') { const r = this.gr.renderer; r.setRenderTarget(null); r.setClearColor(0x0b0c0e, 1); r.clear(); }
    else this.gr.render(dt, this.time, this.hurt);
    if (this.menus.previewActive) this.menus.renderPreview(this.gr.renderer, dt);
    if (this.inSession) this.hud.update(dt, { camera: this.camera, weapons: this.weapons, player: this.player, renderer: this.gr });

    this.input.endFrame();
    this.updatePerf(dt, performance.now() - t0);
  }

  updatePerf(dt, cpuMs) {
    const p = this.perf;
    p.frames++; p.acc += dt;
    if (p.acc >= 0.5) {
      p.fps = p.frames / p.acc; p.ms = (p.acc / p.frames) * 1000; p.frames = 0; p.acc = 0;
      if (p.show) {
        const info = this.gr.renderer.info;
        const db = this.gr.drawingBufferSize;
        $('perf-overlay').textContent =
          `FPS ${p.fps.toFixed(0)}   frame ${p.ms.toFixed(1)} ms   cpu ${cpuMs.toFixed(1)} ms\n` +
          `res ${db.x}×${db.y} (${Math.round(settings.graphics.resolutionScale * 100)}%)   preset ${settings.graphics.preset.toUpperCase()}\n` +
          `draw calls ${info.render.calls}   tris ${(info.render.triangles / 1000).toFixed(0)}k   geo ${info.memory.geometries}   tex ${info.memory.textures}\n` +
          `state ${this.player.state}   speed ${this.player.speed2D.toFixed(1)} m/s   weapon ${this.weapons.state}`;
      }
    }
  }
}

const game = new Game();
window.__game = game; // debugging / automated tests
game.init().catch((e) => {
  console.error(e);
  const el = $('loading-error');
  el.textContent = 'Failed to start: ' + (e && e.message ? e.message : e) + '\n\nThis game needs a WebGL2-capable browser and must be served over http:// (see README).';
  el.classList.remove('hidden');
});
