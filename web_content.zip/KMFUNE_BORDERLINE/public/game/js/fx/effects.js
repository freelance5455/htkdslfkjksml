// =====================================================================
// Effects: decals, particles, tracers, muzzle flashes, casings, magazines
// ---------------------------------------------------------------------
// Everything is POOLED and preallocated — firing never allocates GPU
// resources or compiles shaders mid-combat.
//
//  Decals ...... one InstancedMesh (ring buffer, 400 max) with a 4×2 atlas
//                (concrete / metal rows). Oriented to the surface normal,
//                pushed 2 mm off the surface + polygonOffset → no z-fight,
//                no floating. Parented to moving targets via per-decal
//                "attach" so holes stay on swinging plates / falling boards.
//  Particles ... single Points-like InstancedMesh of camera-facing quads
//                (dust puffs, debris chips, sparks) with CPU simulation.
//  Tracers ..... pooled stretched quads that fly along the shot ray.
//  Muzzle ...... per-weapon flash quads + 1 shared PointLight (pooled).
//  Casings ..... pooled physical props (gravity, floor bounce, spin, sleep,
//                fade after a lifetime) — rifle cases & shotgun hulls.
//  Magazines ... dropped mag props: gravity, collide with floor & boxes,
//                bounce with damping, settle, then fade out after 20 s
//                (max 6 alive).
// =====================================================================
import * as THREE from 'three';
import { decalAtlas, puffTexture, flashAtlas } from '../render/textures.js';
import { cartridgeGeo, shellGeos, getShared } from '../weapons/kit.js';
import { audio } from '../audio/audio.js';

const MAX_DECALS = 400;
const MAX_PARTICLES = 600;

export class Effects {
  constructor(scene, physics, quality) {
    this.scene = scene;
    this.physics = physics;
    this.quality = quality;
    this.time = 0;
    this._m4 = new THREE.Matrix4();
    this._q = new THREE.Quaternion();
    this._v = new THREE.Vector3();
    this._s = new THREE.Vector3();

    // ---------------- decals ----------------
    const atlas = decalAtlas();
    this.decalMat = new THREE.MeshStandardMaterial({
      map: atlas, transparent: true, depthWrite: false, roughness: 0.95, metalness: 0,
      polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4,
    });
    this.decalMat.onBeforeCompile = (sh) => {
      sh.vertexShader = sh.vertexShader
        .replace('#include <common>', '#include <common>\nattribute vec2 aTile;\nattribute float aFade;\nvarying float vFade;')
        .replace('#include <uv_vertex>', '#include <uv_vertex>\n#ifdef USE_MAP\nvMapUv = vec2( ( uv.x + aTile.x ) * 0.25, uv.y * 0.5 + 0.5 - aTile.y * 0.5 );\n#endif\nvFade = aFade;');
      sh.fragmentShader = sh.fragmentShader
        .replace('#include <common>', '#include <common>\nvarying float vFade;')
        .replace('#include <alphatest_fragment>', '#include <alphatest_fragment>\ndiffuseColor.a *= vFade;\nif ( diffuseColor.a < 0.02 ) discard;');
    };
    const dg = new THREE.PlaneGeometry(1, 1);
    this.decalTile = new THREE.InstancedBufferAttribute(new Float32Array(MAX_DECALS * 2), 2);
    this.decalFade = new THREE.InstancedBufferAttribute(new Float32Array(MAX_DECALS), 1);
    dg.setAttribute('aTile', this.decalTile);
    dg.setAttribute('aFade', this.decalFade);
    this.decals = new THREE.InstancedMesh(dg, this.decalMat, MAX_DECALS);
    this.decals.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.decals.count = 0;
    this.decals.frustumCulled = false;
    this.decals.renderOrder = 2;
    this.decals.receiveShadow = true;
    scene.add(this.decals);
    this.decalData = []; // {attach, local: Matrix4, world: Matrix4}
    this.decalHead = 0;

    // ---------------- particles ----------------
    const pg = new THREE.PlaneGeometry(1, 1);
    this.pColor = new THREE.InstancedBufferAttribute(new Float32Array(MAX_PARTICLES * 4), 4);
    pg.setAttribute('aColor', this.pColor);
    this.pMat = new THREE.MeshBasicMaterial({ map: puffTexture(), transparent: true, depthWrite: false, toneMapped: true });
    this.pMat.onBeforeCompile = (sh) => {
      sh.vertexShader = sh.vertexShader
        .replace('#include <common>', '#include <common>\nattribute vec4 aColor;\nvarying vec4 vCol;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvCol = aColor;');
      sh.fragmentShader = sh.fragmentShader
        .replace('#include <common>', '#include <common>\nvarying vec4 vCol;')
        .replace('#include <map_fragment>', '#include <map_fragment>\ndiffuseColor *= vCol;');
    };
    this.particles = new THREE.InstancedMesh(pg, this.pMat, MAX_PARTICLES);
    this.particles.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.particles.frustumCulled = false;
    this.particles.count = 0;
    this.particles.renderOrder = 5;
    scene.add(this.particles);
    this.pool = [];
    for (let i = 0; i < MAX_PARTICLES; i++) this.pool.push({ alive: false, pos: new THREE.Vector3(), vel: new THREE.Vector3(), life: 0, max: 1, size: 0.1, grow: 0, col: new THREE.Color(), alpha: 1, drag: 1, grav: 0, rot: 0, additive: false });
    // sparks (additive, separate mesh)
    this.sMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    const sg = new THREE.PlaneGeometry(1, 1);
    this.sparks = new THREE.InstancedMesh(sg, this.sMat, 200);
    this.sparks.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.sparks.frustumCulled = false; this.sparks.count = 0;
    scene.add(this.sparks);
    this.sparkPool = [];
    for (let i = 0; i < 200; i++) this.sparkPool.push({ alive: false, pos: new THREE.Vector3(), vel: new THREE.Vector3(), life: 0, max: 0.3 });

    // ---------------- tracers ----------------
    this.tracerMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(4, 3.2, 1.6), transparent: true, opacity: 0.9, depthWrite: false, blending: THREE.AdditiveBlending });
    const tg = new THREE.PlaneGeometry(1, 1); tg.translate(0, 0.5, 0); tg.rotateX(Math.PI / 2); // quad spans z = 0..1 (+Z = travel direction)
    this.tracers = []; this.tracerHead = 0;
    for (let i = 0; i < 40; i++) {
      const m = new THREE.Mesh(tg, this.tracerMat);
      m.visible = false; m.frustumCulled = false;
      const m2 = new THREE.Mesh(tg, this.tracerMat); m2.rotation.z = Math.PI / 2; m.add(m2); // cross quad
      scene.add(m);
      this.tracers.push({ mesh: m, from: new THREE.Vector3(), dir: new THREE.Vector3(), dist: 0, travelled: 0, speed: 0, len: 0, age: 0, maxAge: 0, alive: false });
    }

    // ---------------- muzzle light ----------------
    this.flashLight = new THREE.PointLight(0xffb060, 0, 7, 2);
    this.flashLight.castShadow = false;
    scene.add(this.flashLight);
    this.flashLightT = 0;
    this.flashTex = flashAtlas();

    // ---------------- casings ----------------
    const { M } = getShared();
    this.caseGeo = cartridgeGeo(0.039, 0.0056, 0.0); // case only (projectile fired)
    this.caseGeoBig = cartridgeGeo(0.06, 0.0068, 0.0);
    const sh = shellGeos(0.062, 0.0105);
    this.hullGeo = sh.hull; this.hullBrassGeo = sh.brass;
    this.brassMat = M.brass(); this.hullMat = M.shellRed();
    this.casings = [];
    for (let i = 0; i < 40; i++) {
      const g = new THREE.Group(); g.visible = false;
      const a = new THREE.Mesh(this.caseGeo, this.brassMat);
      const b = new THREE.Mesh(this.hullGeo, this.hullMat); const c = new THREE.Mesh(this.hullBrassGeo, this.brassMat);
      g.add(a, b, c); scene.add(g);
      this.casings.push({ g, a, b, c, kind: 'rifle', vel: new THREE.Vector3(), spin: new THREE.Vector3(), life: 0, sleeping: false, bounces: 0, alive: false, worldScale: 1 });
    }
    this.casingHead = 0;

    // ---------------- dropped magazines ----------------
    this.mags = [];
  }

  // ===================== Decals =====================
  addDecal(point, normal, kind = 'concrete', size = 0.09, attach = null) {
    const i = this.decalHead;
    this.decalHead = (this.decalHead + 1) % MAX_DECALS;
    if (this.decals.count < MAX_DECALS) this.decals.count++;
    const n = normal.clone().normalize();
    const pos = point.clone().addScaledVector(n, 0.002);
    // orientation: plane faces +Z → align to normal, random spin
    const q = this._q.setFromUnitVectors(new THREE.Vector3(0, 0, 1), n);
    const spin = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), Math.random() * Math.PI * 2);
    q.multiply(spin);
    const s = size * (0.8 + Math.random() * 0.4);
    const world = new THREE.Matrix4().compose(pos, q, new THREE.Vector3(s, s, s));
    let local = null;
    if (attach) {
      attach.updateWorldMatrix(true, false);
      local = new THREE.Matrix4().copy(attach.matrixWorld).invert().multiply(world);
    }
    this.decalData[i] = { attach, local, world, born: this.time };
    this.decals.setMatrixAt(i, world);
    this.decalTile.setXY(i, Math.floor(Math.random() * 4), kind === 'metal' ? 1 : 0);
    this.decalFade.setX(i, 1);
    this.decalTile.needsUpdate = true; this.decalFade.needsUpdate = true;
    this.decals.instanceMatrix.needsUpdate = true;
  }

  clearDecals() {
    this.decals.count = 0; this.decalHead = 0; this.decalData.length = 0;
  }

  // ===================== Particles =====================
  _spawnP(o) {
    for (const p of this.pool) {
      if (p.alive) continue;
      p.alive = true; p.pos.copy(o.pos); p.vel.copy(o.vel); p.life = 0; p.max = o.life; p.size = o.size; p.grow = o.grow ?? 0;
      p.col.set(o.color ?? 0xffffff); p.alpha = o.alpha ?? 1; p.drag = o.drag ?? 2; p.grav = o.grav ?? 0; p.rot = Math.random() * 6.28;
      return p;
    }
    return null;
  }
  _spark(pos, vel, life) {
    for (const s of this.sparkPool) { if (s.alive) continue; s.alive = true; s.pos.copy(pos); s.vel.copy(vel); s.life = 0; s.max = life; return; }
  }

  /** Material-specific impact burst */
  impact(point, normal, material, intensity = 1) {
    const eq = this.quality.effectsQuality;
    const mul = [0.4, 0.7, 1][eq] * intensity;
    const n = normal;
    const tangent = new THREE.Vector3();
    const rnd = () => new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5);
    if (material === 'concrete') {
      for (let i = 0; i < Math.ceil(5 * mul); i++) {
        const v = n.clone().multiplyScalar(0.6 + Math.random() * 1.4).add(rnd().multiplyScalar(0.9));
        this._spawnP({ pos: point, vel: v, life: 0.9 + Math.random() * 0.8, size: 0.12 + Math.random() * 0.1, grow: 0.5, color: 0xcfc3ab, alpha: 0.55, drag: 2.5, grav: -0.15 });
      }
      for (let i = 0; i < Math.ceil(7 * mul); i++) { // chips
        const v = n.clone().multiplyScalar(2 + Math.random() * 3).add(rnd().multiplyScalar(3));
        this._spawnP({ pos: point, vel: v, life: 0.5 + Math.random() * 0.4, size: 0.018 + Math.random() * 0.02, color: 0x6a5e4c, alpha: 1, drag: 0.4, grav: 9.8 });
      }
    } else if (material === 'metal') {
      for (let i = 0; i < Math.ceil(10 * mul); i++) {
        const v = n.clone().multiplyScalar(2 + Math.random() * 4).add(rnd().multiplyScalar(5));
        this._spark(point, v, 0.15 + Math.random() * 0.25);
      }
      this._spawnP({ pos: point, vel: n.clone().multiplyScalar(0.4), life: 0.5, size: 0.08, grow: 0.6, color: 0x9a948a, alpha: 0.4, drag: 3 });
      this.flashAt(point.clone().addScaledVector(n, 0.05), 0.5, 0xffd080);
    } else if (material === 'wood') {
      for (let i = 0; i < Math.ceil(6 * mul); i++) {
        const v = n.clone().multiplyScalar(1.5 + Math.random() * 2.5).add(rnd().multiplyScalar(2.2));
        this._spawnP({ pos: point, vel: v, life: 0.6 + Math.random() * 0.4, size: 0.02 + Math.random() * 0.02, color: 0xd6b27a, alpha: 1, drag: 0.6, grav: 9.8 });
      }
      this._spawnP({ pos: point, vel: n.clone().multiplyScalar(0.5), life: 0.7, size: 0.1, grow: 0.5, color: 0xe9dcc0, alpha: 0.45, drag: 3 });
    }
    void tangent;
  }

  /** Muzzle smoke wisp */
  muzzleSmoke(pos, dir, amount = 1) {
    const eq = this.quality.effectsQuality;
    for (let i = 0; i < Math.ceil(amount * [1, 2, 3][eq]); i++) {
      const v = dir.clone().multiplyScalar(0.5 + Math.random() * 0.8).add(new THREE.Vector3((Math.random() - 0.5) * 0.3, 0.25 + Math.random() * 0.3, (Math.random() - 0.5) * 0.3));
      this._spawnP({ pos, vel: v, life: 0.7 + Math.random() * 0.6, size: 0.05 + Math.random() * 0.04, grow: 0.35, color: 0xe8e2d6, alpha: 0.28, drag: 2.2, grav: -0.2 });
    }
  }

  flashAt(pos, intensity = 1, color = 0xffb060) {
    this.flashLight.position.copy(pos);
    this.flashLight.color.set(color);
    this.flashLight.intensity = 4 * intensity;
    this.flashLightT = 0.05;
  }

  // ===================== Tracers =====================
  _killTracer(t) { t.alive = false; t.mesh.visible = false; t.travelled = 0; t.age = 0; t.mesh.scale.set(1, 1, 1); }
  tracer(from, to, speed = 380, len = 3.2) {
    // ring-buffer allocation: if every tracer is alive, recycle the oldest
    let t = null;
    for (let i = 0; i < this.tracers.length; i++) { const x = this.tracers[(this.tracerHead + i) % this.tracers.length]; if (!x.alive) { t = x; break; } }
    if (!t) t = this.tracers[this.tracerHead];
    this.tracerHead = (this.tracers.indexOf(t) + 1) % this.tracers.length;
    t.alive = true; t.age = 0;
    t.from.copy(from);
    t.dir.subVectors(to, from);
    t.dist = t.dir.length();
    t.dir.normalize();
    t.travelled = 0; t.speed = speed; t.len = Math.min(len, t.dist);
    t.maxAge = (t.dist + t.len) / Math.max(1, speed) + 0.1;
    t.mesh.scale.set(0.014, 0.014, 0.01);
    t.mesh.visible = true;
    t.mesh.position.copy(from);
    t.mesh.lookAt(this._v.copy(from).add(t.dir)); // Object3D.lookAt aims +Z at the target
  }

  // ===================== Casings =====================
  ejectCasing(kind, pos, vel, quat) {
    const c = this.casings[this.casingHead];
    this.casingHead = (this.casingHead + 1) % this.casings.length;
    c.alive = true; c.kind = kind; c.sleeping = false; c.life = 0; c.bounces = 0;
    c.g.visible = true;
    c.a.visible = kind !== 'shell'; c.b.visible = c.c.visible = kind === 'shell';
    c.a.geometry = kind === 'rifleBig' ? this.caseGeoBig : this.caseGeo;
    c.g.position.copy(pos); c.g.quaternion.copy(quat); c.g.scale.setScalar(1);
    c.vel.copy(vel);
    c.spin.set((Math.random() - 0.5) * 30, (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 30);
  }

  // ===================== Magazines =====================
  dropMagazine(prop, worldMatrix, vel) {
    if (!prop) return;
    if (this.mags.length >= 6) { const old = this.mags.shift(); this.scene.remove(old.obj); }
    worldMatrix.decompose(prop.position, prop.quaternion, prop.scale);
    prop.scale.setScalar(1);
    prop.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.frustumCulled = true; } });
    this.scene.add(prop);
    // approximate collision radius from bounds
    const box = new THREE.Box3().setFromObject(prop);
    const size = box.getSize(new THREE.Vector3());
    this.mags.push({ obj: prop, vel: vel.clone(), spin: new THREE.Vector3((Math.random() - 0.5) * 6, (Math.random() - 0.5) * 4, (Math.random() - 0.5) * 6), half: Math.max(0.012, Math.min(size.x, size.y, size.z) * 0.5), life: 0, sleeping: false, bounces: 0, kind: 'mag' });
  }

  // ===================== Update =====================
  update(dt, camera) {
    this.time += dt;
    const g = 9.81;

    // decals that follow moving targets
    let decDirty = false;
    for (let i = 0; i < this.decals.count; i++) {
      const d = this.decalData[i];
      if (!d) continue;
      if (d.attach) {
        d.attach.updateWorldMatrix(true, false);
        d.world.multiplyMatrices(d.attach.matrixWorld, d.local);
        this.decals.setMatrixAt(i, d.world);
        decDirty = true;
      }
    }
    if (decDirty) this.decals.instanceMatrix.needsUpdate = true;

    // particles (camera facing quads)
    let n = 0;
    const camQ = camera.quaternion;
    for (const p of this.pool) {
      if (!p.alive) continue;
      p.life += dt;
      if (p.life >= p.max) { p.alive = false; continue; }
      p.vel.multiplyScalar(Math.exp(-p.drag * dt));
      p.vel.y -= p.grav * dt;
      p.pos.addScaledVector(p.vel, dt);
      if (p.pos.y < 0.005 && p.grav > 0) { p.pos.y = 0.005; p.vel.y *= -0.3; p.vel.x *= 0.5; p.vel.z *= 0.5; }
      const t = p.life / p.max;
      const s = p.size * (1 + p.grow * t * 4);
      this._q.copy(camQ).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), p.rot + t));
      this._m4.compose(p.pos, this._q, this._s.set(s, s, s));
      this.particles.setMatrixAt(n, this._m4);
      const a = p.alpha * (1 - t) * Math.min(1, t * 10 + 0.3);
      this.pColor.setXYZW(n, p.col.r, p.col.g, p.col.b, a);
      n++;
    }
    this.particles.count = n;
    if (n) { this.particles.instanceMatrix.needsUpdate = true; this.pColor.needsUpdate = true; }

    // sparks: stretched along velocity
    let sn = 0;
    for (const s of this.sparkPool) {
      if (!s.alive) continue;
      s.life += dt;
      if (s.life >= s.max) { s.alive = false; continue; }
      s.vel.y -= g * dt;
      s.pos.addScaledVector(s.vel, dt);
      const sp = s.vel.length();
      this._q.setFromUnitVectors(new THREE.Vector3(0, 1, 0), this._v.copy(s.vel).normalize());
      const k = 1 - s.life / s.max;
      this._m4.compose(s.pos, this._q, this._s.set(0.008 * k + 0.003, Math.min(0.12, sp * 0.012), 1));
      this.sparks.setMatrixAt(sn++, this._m4);
    }
    this.sparks.count = sn;
    if (sn) this.sparks.instanceMatrix.needsUpdate = true;
    this.sMat.color.setRGB(5, 3.2, 1.4);

    // tracers
    for (const t of this.tracers) {
      if (!t.alive) continue;
      // Bug fix: head used to be clamped to dist, so tail = dist - len could
      // never reach dist and finished tracers stayed suspended in the air.
      // Tail now keeps travelling until it passes the impact point; a hard
      // lifetime cap guarantees release back to the pool.
      t.travelled += t.speed * dt;
      t.age += dt;
      const head = Math.min(t.travelled, t.dist);
      const tail = Math.min(t.dist, Math.max(0, t.travelled - t.len));
      if (tail >= t.dist - 0.01 || t.age > t.maxAge) { this._killTracer(t); continue; }
      t.mesh.position.copy(t.from).addScaledVector(t.dir, tail);
      t.mesh.scale.set(0.014, 0.014, Math.max(0.01, head - tail));
    }

    // muzzle light decay
    if (this.flashLightT > 0) {
      this.flashLightT -= dt;
      if (this.flashLightT <= 0) this.flashLight.intensity = 0;
      else this.flashLight.intensity *= 0.6;
    }

    // casings
    for (const c of this.casings) {
      if (!c.alive) continue;
      c.life += dt;
      if (!c.sleeping) {
        c.vel.y -= g * dt;
        c.g.position.addScaledVector(c.vel, dt);
        const e = new THREE.Euler(c.spin.x * dt, c.spin.y * dt, c.spin.z * dt);
        c.g.quaternion.multiply(this._q.setFromEuler(e));
        const floorY = this._supportY(c.g.position, 0.01);
        if (c.g.position.y < floorY + 0.006) {
          c.g.position.y = floorY + 0.006;
          if (c.vel.y < -0.4) {
            c.bounces++;
            if (c.bounces <= 2) audio.play(c.kind === 'shell' ? 'shotgun_shell_drop' : 'casing', { cat: 'environment', at: c.g.position, volume: 0.35 / c.bounces, refDistance: 2 });
          }
          c.vel.y *= -0.32; c.vel.x *= 0.55; c.vel.z *= 0.55; c.spin.multiplyScalar(0.5);
          if (Math.abs(c.vel.y) < 0.3 && c.vel.lengthSq() < 0.05) {
            c.sleeping = true;
            // lie flat: align case axis with ground plane
            const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(c.g.quaternion); fwd.y = 0;
            if (fwd.lengthSq() < 1e-4) fwd.set(1, 0, 0);
            fwd.normalize();
            c.g.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, -1), fwd);
          }
        }
        this._collideBoxes(c.g.position, c.vel, 0.006);
      }
      if (c.life > 12) {
        const k = 1 - (c.life - 12) / 1;
        if (k <= 0) { c.alive = false; c.g.visible = false; } else c.g.scale.setScalar(k);
      }
    }

    // magazines
    for (let i = this.mags.length - 1; i >= 0; i--) {
      const m = this.mags[i];
      m.life += dt;
      if (!m.sleeping) {
        m.vel.y -= g * dt;
        m.obj.position.addScaledVector(m.vel, dt);
        m.obj.quaternion.multiply(this._q.setFromEuler(new THREE.Euler(m.spin.x * dt, m.spin.y * dt, m.spin.z * dt)));
        const floorY = this._supportY(m.obj.position, 0.05);
        if (m.obj.position.y < floorY + m.half) {
          m.obj.position.y = floorY + m.half;
          if (m.vel.y < -0.8) {
            m.bounces++;
            if (m.bounces <= 3) audio.play(m.bounces === 1 ? 'hit_plate' : 'metal_light', { cat: 'environment', at: m.obj.position, volume: 0.5 / m.bounces, rate: 1.3, refDistance: 3 });
          }
          m.vel.y *= -0.25; m.vel.x *= 0.5; m.vel.z *= 0.5; m.spin.multiplyScalar(0.4);
          if (Math.abs(m.vel.y) < 0.35 && m.vel.lengthSq() < 0.08) {
            m.sleeping = true;
            // settle onto its side (flattest orientation)
            const up = new THREE.Vector3(1, 0, 0).applyQuaternion(m.obj.quaternion);
            const target = new THREE.Quaternion().setFromUnitVectors(up, new THREE.Vector3(0, Math.sign(up.y) || 1, 0)).multiply(m.obj.quaternion);
            m.obj.quaternion.copy(target);
          }
        }
        this._collideBoxes(m.obj.position, m.vel, m.half);
      }
      if (m.life > 20) {
        const k = 1 - (m.life - 20) / 1.5;
        if (k <= 0) { this.scene.remove(m.obj); this.mags.splice(i, 1); } else m.obj.scale.setScalar(k);
      }
    }
  }

  _supportY(p, r) {
    let y = 0;
    for (const b of this.physics.boxes) {
      if (p.x > b.min.x - r && p.x < b.max.x + r && p.z > b.min.z - r && p.z < b.max.z + r && p.y >= b.max.y - 0.05 && b.max.y > y) y = b.max.y;
    }
    return y;
  }
  _collideBoxes(p, v, r) {
    for (const b of this.physics.boxes) {
      if (p.x > b.min.x - r && p.x < b.max.x + r && p.z > b.min.z - r && p.z < b.max.z + r && p.y > b.min.y && p.y < b.max.y - 0.05) {
        // push out along smallest penetration axis (x or z)
        const dx1 = p.x - (b.min.x - r), dx2 = (b.max.x + r) - p.x, dz1 = p.z - (b.min.z - r), dz2 = (b.max.z + r) - p.z;
        const m = Math.min(dx1, dx2, dz1, dz2);
        if (m === dx1) { p.x = b.min.x - r; v.x = -Math.abs(v.x) * 0.3; }
        else if (m === dx2) { p.x = b.max.x + r; v.x = Math.abs(v.x) * 0.3; }
        else if (m === dz1) { p.z = b.min.z - r; v.z = -Math.abs(v.z) * 0.3; }
        else { p.z = b.max.z + r; v.z = Math.abs(v.z) * 0.3; }
      }
    }
  }

  reset() {
    this.clearDecals();
    for (const p of this.pool) p.alive = false;
    for (const s of this.sparkPool) s.alive = false;
    for (const t of this.tracers) this._killTracer(t);
    this.tracerHead = 0;
    for (const c of this.casings) { c.alive = false; c.g.visible = false; }
    for (const m of this.mags) this.scene.remove(m.obj);
    this.mags.length = 0;
  }
}
