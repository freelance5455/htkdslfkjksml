// =====================================================================
// Procedural texture factory
// All surface textures are painted at load time on canvases so the game is
// fully self-contained (no external image downloads). Textures are generated
// as tileable maps using wrapped value-noise and are cached per quality level.
//
// Painted in an "illustrated" manner: hand-drawn cracks, stains, chips and
// ink speckles on top of a noise base — the comic look comes from the paint,
// the cel-shading comes from the material patch (see toon.js).
// =====================================================================
import * as THREE from 'three';

// ---------- deterministic RNG ----------
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- tileable value noise ----------
function makeNoise(size, cell, rnd) {
  const g = Math.max(1, Math.round(size / cell));
  const grid = new Float32Array(g * g);
  for (let i = 0; i < grid.length; i++) grid[i] = rnd();
  const out = new Float32Array(size * size);
  for (let y = 0; y < size; y++) {
    const fy = (y / size) * g, y0 = Math.floor(fy), ty = fy - y0;
    const sy = ty * ty * (3 - 2 * ty);
    const y0w = y0 % g, y1w = (y0 + 1) % g;
    for (let x = 0; x < size; x++) {
      const fx = (x / size) * g, x0 = Math.floor(fx), tx = fx - x0;
      const sx = tx * tx * (3 - 2 * tx);
      const x0w = x0 % g, x1w = (x0 + 1) % g;
      const a = grid[y0w * g + x0w], b = grid[y0w * g + x1w];
      const c = grid[y1w * g + x0w], d = grid[y1w * g + x1w];
      out[y * size + x] = (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sy;
    }
  }
  return out;
}

function fbm(size, baseCell, octaves, rnd, persistence = 0.5) {
  const out = new Float32Array(size * size);
  let amp = 1, total = 0, cell = baseCell;
  for (let o = 0; o < octaves; o++) {
    const n = makeNoise(size, Math.max(2, cell), rnd);
    for (let i = 0; i < out.length; i++) out[i] += n[i] * amp;
    total += amp; amp *= persistence; cell /= 2;
  }
  for (let i = 0; i < out.length; i++) out[i] /= total;
  return out;
}

function canvas(size) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  return c;
}

function toTexture(c, { srgb = true, repeat = 1, aniso = 8 } = {}) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat, repeat);
  t.anisotropy = aniso;
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.generateMipmaps = true;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.needsUpdate = true;
  return t;
}

// Draws a stroke wrapped across tile borders so that the texture tiles.
function wrapStroke(ctx, size, drawFn) {
  for (const ox of [-size, 0, size]) for (const oy of [-size, 0, size]) {
    ctx.save(); ctx.translate(ox, oy); drawFn(); ctx.restore();
  }
}

// Convert a height field to a tangent-space normal map
function heightToNormal(height, size, strength) {
  const c = canvas(size); const ctx = c.getContext('2d');
  const img = ctx.createImageData(size, size);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const l = height[y * size + ((x - 1 + size) % size)], r = height[y * size + ((x + 1) % size)];
    const u = height[((y - 1 + size) % size) * size + x], d = height[((y + 1) % size) * size + x];
    let nx = (l - r) * strength, ny = (u - d) * strength, nz = 1;
    const len = Math.hypot(nx, ny, nz); nx /= len; ny /= len; nz /= len;
    const i = (y * size + x) * 4;
    img.data[i] = (nx * 0.5 + 0.5) * 255; img.data[i + 1] = (ny * 0.5 + 0.5) * 255;
    img.data[i + 2] = (nz * 0.5 + 0.5) * 255; img.data[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

// ---------------------------------------------------------------------
// Concrete — aggregate, pores, stains, hairline cracks, expansion joints
// returns { map, normalMap, roughnessMap }
// ---------------------------------------------------------------------
export function concreteTextures(quality = 2, opts = {}) {
  const size = [256, 512, 1024][quality];
  const rnd = mulberry32(opts.seed ?? 1337);
  const base = opts.base ?? [176, 168, 152];
  const height = new Float32Array(size * size);

  const n1 = fbm(size, size / 4, 5, rnd, 0.55);
  const n2 = fbm(size, size / 16, 3, rnd, 0.5);
  const stain = fbm(size, size / 2, 3, rnd, 0.6);

  const c = canvas(size); const ctx = c.getContext('2d');
  const img = ctx.createImageData(size, size);
  for (let i = 0; i < size * size; i++) {
    const v = n1[i] * 0.6 + n2[i] * 0.4;
    // painterly posterisation of the large-scale variation
    const band = Math.round(v * 6) / 6;
    const tone = 0.82 + band * 0.22 + (n2[i] - 0.5) * 0.08;
    const st = Math.max(0, stain[i] - 0.58) * 1.6;
    const r = base[0] * tone - st * 50, g = base[1] * tone - st * 46, b = base[2] * tone - st * 36;
    img.data[i * 4] = r; img.data[i * 4 + 1] = g; img.data[i * 4 + 2] = b; img.data[i * 4 + 3] = 255;
    height[i] = v * 0.6;
  }
  ctx.putImageData(img, 0, 0);

  // Aggregate: small pebbles with a dark ink edge on one side
  const aggCount = Math.floor(size * size / 900);
  for (let i = 0; i < aggCount; i++) {
    const x = rnd() * size, y = rnd() * size, r = 0.6 + rnd() * (size / 380);
    const shade = 120 + rnd() * 90;
    wrapStroke(ctx, size, () => {
      ctx.fillStyle = `rgba(${shade},${shade - 6},${shade - 16},0.85)`;
      ctx.beginPath(); ctx.ellipse(x, y, r * 1.3, r, rnd() * 3, 0, Math.PI * 2); ctx.fill();
    });
    const px = Math.floor(x), py = Math.floor(y);
    if (px >= 0 && py >= 0 && px < size && py < size) height[py * size + px] += 0.25;
  }
  // Pores (dark pinholes)
  for (let i = 0; i < size * size / 500; i++) {
    const x = rnd() * size, y = rnd() * size;
    ctx.fillStyle = `rgba(40,34,28,${0.25 + rnd() * 0.4})`;
    ctx.fillRect(x, y, 1 + rnd() * 1.5, 1 + rnd());
    const px = Math.floor(x), py = Math.floor(y);
    height[py * size + px] -= 0.4;
  }
  // Hairline cracks: random walks with an ink line + light lip
  const cracks = opts.cracks ?? 7;
  for (let k = 0; k < cracks; k++) {
    let x = rnd() * size, y = rnd() * size, a = rnd() * Math.PI * 2;
    const pts = [[x, y]];
    const len = 20 + rnd() * 60;
    for (let s = 0; s < len; s++) {
      a += (rnd() - 0.5) * 0.7; x += Math.cos(a) * size / 160; y += Math.sin(a) * size / 160; pts.push([x, y]);
      if (rnd() < 0.05) { // branch
        let bx = x, by = y, ba = a + (rnd() > 0.5 ? 1 : -1) * (0.6 + rnd());
        const bp = [[bx, by]];
        for (let j = 0; j < 10 + rnd() * 14; j++) { ba += (rnd() - 0.5) * 0.6; bx += Math.cos(ba) * size / 180; by += Math.sin(ba) * size / 180; bp.push([bx, by]); }
        drawCrack(ctx, size, bp, 0.6);
      }
    }
    drawCrack(ctx, size, pts, 1);
  }
  // Hand-painted stain blotches
  for (let i = 0; i < 10; i++) {
    const x = rnd() * size, y = rnd() * size, r = size * (0.03 + rnd() * 0.08);
    wrapStroke(ctx, size, () => {
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, `rgba(70,58,40,${0.12 + rnd() * 0.12})`); g.addColorStop(1, 'rgba(70,58,40,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    });
  }
  // Expansion joint grid (optional, for floor slabs)
  if (opts.joints) {
    ctx.strokeStyle = 'rgba(38,30,22,0.9)'; ctx.lineWidth = Math.max(2, size / 220);
    ctx.beginPath(); ctx.moveTo(0, 1); ctx.lineTo(size, 1); ctx.moveTo(1, 0); ctx.lineTo(1, size); ctx.stroke();
    ctx.strokeStyle = 'rgba(230,220,200,0.35)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, 4); ctx.lineTo(size, 4); ctx.moveTo(4, 0); ctx.lineTo(4, size); ctx.stroke();
    for (let i = 0; i < size; i++) { height[i] -= 1; height[1 * size + i] -= 1; height[i * size] -= 1; height[i * size + 1] -= 1; }
  }

  // Roughness map
  const rc = canvas(size); const rctx = rc.getContext('2d');
  const rimg = rctx.createImageData(size, size);
  for (let i = 0; i < size * size; i++) {
    const v = 200 + (n2[i] - 0.5) * 60 - Math.max(0, stain[i] - 0.6) * 120;
    rimg.data[i * 4] = rimg.data[i * 4 + 1] = rimg.data[i * 4 + 2] = v; rimg.data[i * 4 + 3] = 255;
  }
  rctx.putImageData(rimg, 0, 0);

  const repeat = opts.repeat ?? 1;
  return {
    map: toTexture(c, { repeat }),
    normalMap: toTexture(heightToNormal(height, size, opts.normalStrength ?? 3.2), { srgb: false, repeat }),
    roughnessMap: toTexture(rc, { srgb: false, repeat }),
  };
}

function drawCrack(ctx, size, pts, w) {
  wrapStroke(ctx, size, () => {
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.strokeStyle = 'rgba(235,225,205,0.35)'; ctx.lineWidth = (2.2 * w * size) / 512;
    ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x + 1, y + 1) : ctx.moveTo(x + 1, y + 1))); ctx.stroke();
    ctx.strokeStyle = 'rgba(30,24,18,0.85)'; ctx.lineWidth = (1.3 * w * size) / 512;
    ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.stroke();
  });
}

// ---------------------------------------------------------------------
// Painted metal / polymer detail sheet (greyscale, multiplied by material
// colour). Scratches, edge-wear speckle, grime gradients.
// ---------------------------------------------------------------------
export function wearTextures(quality = 2, seed = 7) {
  const size = [256, 512, 512][quality];
  const rnd = mulberry32(seed);
  const n = fbm(size, size / 6, 4, rnd, 0.55);
  const c = canvas(size); const ctx = c.getContext('2d');
  const img = ctx.createImageData(size, size);
  const height = new Float32Array(size * size);
  for (let i = 0; i < size * size; i++) {
    const v = 0.86 + (n[i] - 0.5) * 0.22;
    img.data[i * 4] = img.data[i * 4 + 1] = img.data[i * 4 + 2] = Math.min(255, v * 255); img.data[i * 4 + 3] = 255;
    height[i] = n[i] * 0.2;
  }
  ctx.putImageData(img, 0, 0);
  // scratches: bright thin strokes with dark shadow
  for (let i = 0; i < size / 3; i++) {
    const x = rnd() * size, y = rnd() * size, a = rnd() * Math.PI, l = 4 + rnd() * size / 10;
    wrapStroke(ctx, size, () => {
      ctx.strokeStyle = `rgba(255,255,255,${0.25 + rnd() * 0.35})`; ctx.lineWidth = 0.7;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); ctx.stroke();
      ctx.strokeStyle = 'rgba(0,0,0,0.25)';
      ctx.beginPath(); ctx.moveTo(x + 0.8, y + 0.8); ctx.lineTo(x + 0.8 + Math.cos(a) * l, y + 0.8 + Math.sin(a) * l); ctx.stroke();
    });
  }
  // chips & grime dots
  for (let i = 0; i < size * 1.5; i++) {
    const x = rnd() * size, y = rnd() * size;
    const dark = rnd() > 0.5;
    ctx.fillStyle = dark ? `rgba(20,16,12,${0.15 + rnd() * 0.3})` : `rgba(255,250,240,${0.15 + rnd() * 0.25})`;
    ctx.beginPath(); ctx.arc(x, y, 0.4 + rnd() * 1.6, 0, Math.PI * 2); ctx.fill();
  }
  const rc = canvas(size); const rctx = rc.getContext('2d');
  rctx.drawImage(c, 0, 0);
  rctx.globalCompositeOperation = 'difference'; rctx.fillStyle = '#fff'; rctx.fillRect(0, 0, size, size); // invert: scratches shinier
  return {
    map: toTexture(c),
    roughnessMap: toTexture(rc, { srgb: false }),
    normalMap: toTexture(heightToNormal(height, size, 2.0), { srgb: false }),
  };
}

// Wood grain (Dynasty stock / Ranger furniture)
export function woodTexture(quality = 2, tint = [139, 90, 50], seed = 99) {
  const size = [256, 512, 512][quality];
  const rnd = mulberry32(seed);
  const n = fbm(size, size / 8, 4, rnd);
  const c = canvas(size); const ctx = c.getContext('2d');
  const img = ctx.createImageData(size, size);
  const height = new Float32Array(size * size);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const i = y * size + x;
    const ring = Math.sin((x / size) * Math.PI * 2 * 7 + n[i] * 9) * 0.5 + 0.5;
    const band = Math.round(ring * 3) / 3; // posterised grain bands
    const k = 0.72 + band * 0.25 + (n[i] - 0.5) * 0.12;
    img.data[i * 4] = tint[0] * k; img.data[i * 4 + 1] = tint[1] * k; img.data[i * 4 + 2] = tint[2] * k; img.data[i * 4 + 3] = 255;
    height[i] = ring * 0.4;
  }
  ctx.putImageData(img, 0, 0);
  ctx.strokeStyle = 'rgba(40,20,8,0.35)'; ctx.lineWidth = 1;
  for (let i = 0; i < 26; i++) {
    const x = rnd() * size;
    ctx.beginPath(); ctx.moveTo(x, 0);
    for (let y = 0; y <= size; y += 8) ctx.lineTo(x + Math.sin(y * 0.03 + i) * 4, y);
    ctx.stroke();
  }
  return { map: toTexture(c), normalMap: toTexture(heightToNormal(height, size, 1.5), { srgb: false }) };
}

// Stippled / knurled grip pattern
export function gripTexture(quality = 2) {
  const size = [128, 256, 256][quality];
  const c = canvas(size); const ctx = c.getContext('2d');
  ctx.fillStyle = '#8a8a8a'; ctx.fillRect(0, 0, size, size);
  const height = new Float32Array(size * size);
  const step = size / 16;
  for (let y = 0; y < size; y += step) for (let x = 0; x < size; x += step) {
    const ox = ((y / step) % 2) * step / 2;
    ctx.fillStyle = '#c4c4c4'; ctx.beginPath(); ctx.arc(x + ox, y, step * 0.32, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#4a4a4a'; ctx.beginPath(); ctx.arc(x + ox + 1, y + 1, step * 0.18, 0, Math.PI * 2); ctx.fill();
  }
  const d = ctx.getImageData(0, 0, size, size).data;
  for (let i = 0; i < size * size; i++) height[i] = d[i * 4] / 255;
  return { map: toTexture(c), normalMap: toTexture(heightToNormal(height, size, 4), { srgb: false }) };
}

// Fabric wrap (Ranger / Big Rig tape)
export function fabricTexture(quality = 2, tint = [226, 214, 186]) {
  const size = [128, 256, 256][quality];
  const rnd = mulberry32(4242);
  const c = canvas(size); const ctx = c.getContext('2d');
  ctx.fillStyle = `rgb(${tint})`; ctx.fillRect(0, 0, size, size);
  for (let y = 0; y < size; y += 3) {
    ctx.fillStyle = `rgba(0,0,0,${0.06 + rnd() * 0.08})`; ctx.fillRect(0, y, size, 1);
  }
  for (let x = 0; x < size; x += 3) {
    ctx.fillStyle = `rgba(255,255,255,${0.04 + rnd() * 0.06})`; ctx.fillRect(x, 0, 1, size);
  }
  for (let i = 0; i < 40; i++) {
    ctx.fillStyle = `rgba(90,70,40,${rnd() * 0.15})`;
    ctx.beginPath(); ctx.arc(rnd() * size, rnd() * size, rnd() * 10, 0, Math.PI * 2); ctx.fill();
  }
  return { map: toTexture(c) };
}

// Camo pattern for the Vanguard (olive / bone white blotches as in reference)
export function camoTexture(quality = 2, colors = ['#d8d3c4', '#5e6844', '#3f4630', '#a8a58f'], seed = 21) {
  const size = [256, 512, 512][quality];
  const rnd = mulberry32(seed);
  const n = fbm(size, size / 3, 4, rnd, 0.55);
  const n2 = fbm(size, size / 5, 3, rnd, 0.5);
  const c = canvas(size); const ctx = c.getContext('2d');
  const img = ctx.createImageData(size, size);
  const cols = colors.map((h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]);
  for (let i = 0; i < size * size; i++) {
    const v = n[i] + (n2[i] - 0.5) * 0.25;
    const k = v < 0.42 ? 0 : v < 0.52 ? 3 : v < 0.6 ? 1 : 2;
    const col = cols[k];
    img.data[i * 4] = col[0]; img.data[i * 4 + 1] = col[1]; img.data[i * 4 + 2] = col[2]; img.data[i * 4 + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return { map: toTexture(c) };
}

// Target face (concentric rings, numbers) — non-repeating
export function targetFaceTexture() {
  const size = 512;
  const c = canvas(size); const ctx = c.getContext('2d');
  ctx.fillStyle = '#efe2c0'; ctx.fillRect(0, 0, size, size);
  const rings = ['#efe2c0', '#20190f', '#efe2c0', '#20190f', '#e0342a', '#ffcc1a'];
  for (let i = 0; i < rings.length; i++) {
    const r = size * 0.48 * (1 - i / rings.length);
    ctx.fillStyle = rings[i]; ctx.beginPath(); ctx.arc(size / 2, size / 2, r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#15110d'; ctx.lineWidth = 4; ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(21,17,13,0.6)'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(size / 2, 10); ctx.lineTo(size / 2, size - 10); ctx.moveTo(10, size / 2); ctx.lineTo(size - 10, size / 2); ctx.stroke();
  ctx.font = 'bold 34px Bangers, Impact, sans-serif'; ctx.fillStyle = '#15110d';
  ctx.fillText('KMFUNE', 18, 44);
  const t = toTexture(c); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}

// Bullet hole decal atlas — 4 variants per material row (concrete, metal)
export function decalAtlas() {
  const size = 512, cell = 128;
  const c = canvas(size); const ctx = c.getContext('2d');
  const rnd = mulberry32(555);
  for (let row = 0; row < 2; row++) for (let v = 0; v < 4; v++) {
    const cx = v * cell + cell / 2, cy = row * cell + cell / 2;
    if (row === 0) { // concrete: chipped crater, dust halo, radial cracks, ink core
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, cell * 0.48);
      g.addColorStop(0, 'rgba(60,50,40,0.55)'); g.addColorStop(0.5, 'rgba(90,78,62,0.25)'); g.addColorStop(1, 'rgba(90,78,62,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, cell * 0.48, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(205,195,175,0.9)';
      ctx.beginPath();
      for (let a = 0; a < Math.PI * 2; a += 0.35) { const r = cell * (0.17 + rnd() * 0.09); ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); }
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(25,20,15,0.85)'; ctx.lineWidth = 1.6;
      for (let k = 0; k < 5 + rnd() * 4; k++) {
        let a = rnd() * Math.PI * 2, x = cx, y = cy; ctx.beginPath(); ctx.moveTo(x, y);
        for (let s = 0; s < 6; s++) { a += (rnd() - 0.5) * 0.6; x += Math.cos(a) * cell * 0.05; y += Math.sin(a) * cell * 0.05; ctx.lineTo(x, y); }
        ctx.stroke();
      }
      ctx.fillStyle = '#17120d'; ctx.beginPath(); ctx.arc(cx, cy, cell * 0.075, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#15110d'; ctx.lineWidth = 2.5;
      ctx.beginPath();
      for (let a = 0; a < Math.PI * 2; a += 0.35) { const r = cell * (0.17 + rnd() * 0.09); ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); }
      ctx.closePath(); ctx.stroke();
    } else { // metal: bright dent ring, scorched halo, dark puncture
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, cell * 0.42);
      g.addColorStop(0, 'rgba(30,25,20,0.7)'); g.addColorStop(0.6, 'rgba(40,30,20,0.25)'); g.addColorStop(1, 'rgba(40,30,20,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, cell * 0.42, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(235,235,230,0.95)'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(cx, cy, cell * 0.13, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = '#15110d'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(cx, cy, cell * 0.165, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#0f0c09'; ctx.beginPath(); ctx.arc(cx, cy, cell * 0.08, 0, Math.PI * 2); ctx.fill();
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return t;
}

// Soft round sprite used for dust / smoke particles
export function puffTexture() {
  const size = 128;
  const c = canvas(size); const ctx = c.getContext('2d');
  const rnd = mulberry32(77);
  for (let i = 0; i < 9; i++) {
    const x = size / 2 + (rnd() - 0.5) * size * 0.35, y = size / 2 + (rnd() - 0.5) * size * 0.35, r = size * (0.18 + rnd() * 0.16);
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, 'rgba(255,255,255,0.9)'); g.addColorStop(0.7, 'rgba(255,255,255,0.5)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

// Comic muzzle flash: star burst with ink outline, 4 variants in a 2x2 atlas
export function flashAtlas() {
  const size = 512, cell = 256;
  const c = canvas(size); const ctx = c.getContext('2d');
  const rnd = mulberry32(31337);
  for (let v = 0; v < 4; v++) {
    const cx = (v % 2) * cell + cell / 2, cy = Math.floor(v / 2) * cell + cell / 2;
    const spikes = 7 + Math.floor(rnd() * 4);
    const path = () => {
      ctx.beginPath();
      for (let i = 0; i <= spikes * 2; i++) {
        const a = (i / (spikes * 2)) * Math.PI * 2 + rnd() * 0.15;
        const r = i % 2 === 0 ? cell * (0.36 + rnd() * 0.12) : cell * (0.12 + rnd() * 0.06);
        ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      }
      ctx.closePath();
    };
    path(); ctx.fillStyle = 'rgba(255,150,40,1)'; ctx.fill(); ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(60,20,0,0.9)'; ctx.stroke();
    ctx.save(); ctx.translate(cx, cy); ctx.scale(0.62, 0.62); ctx.translate(-cx, -cy); path(); ctx.fillStyle = '#ffe36a'; ctx.fill(); ctx.restore();
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, cell * 0.16);
    g.addColorStop(0, '#ffffff'); g.addColorStop(1, 'rgba(255,255,220,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, cell * 0.16, 0, Math.PI * 2); ctx.fill();
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

// Side-on flash (cone along +X) for third-person views of the muzzle
export function flashSideTexture() {
  const w = 256, h = 128;
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  const rnd = mulberry32(8080);
  ctx.beginPath(); ctx.moveTo(0, h / 2);
  const n = 9;
  for (let i = 0; i <= n; i++) {
    const t = i / n; const a = -Math.PI / 2 + t * Math.PI;
    const r = (i % 2 === 0 ? 0.95 : 0.55) * (0.8 + rnd() * 0.2);
    ctx.lineTo(Math.cos(a) * w * r * 0.98 * (1 - Math.abs(Math.sin(a)) * 0.3), h / 2 + Math.sin(a) * h * 0.45 * r);
  }
  ctx.closePath();
  ctx.fillStyle = '#ff9a2a'; ctx.fill(); ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(60,20,0,0.9)'; ctx.stroke();
  const g = ctx.createLinearGradient(0, 0, w, 0); g.addColorStop(0, '#ffffff'); g.addColorStop(0.4, '#ffe36a'); g.addColorStop(1, 'rgba(255,200,80,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(w * 0.3, h / 2, w * 0.32, h * 0.18, 0, 0, Math.PI * 2); ctx.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

// Painted backdrop-mountain silhouette strip (transparent PNG-style)
export function mesaStripTexture() {
  const w = 2048, h = 256;
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  const rnd = mulberry32(2024);
  const layers = [
    { col: '#c9a37a', base: 0.55, amp: 0.3, ink: 'rgba(60,35,20,0.55)' },
    { col: '#a5754b', base: 0.72, amp: 0.22, ink: 'rgba(50,28,15,0.8)' },
  ];
  for (const L of layers) {
    ctx.beginPath(); ctx.moveTo(0, h);
    let y = h * L.base;
    const pts = [];
    for (let x = 0; x <= w; x += 16) {
      // mesa: flat tops with steep faces
      if (rnd() < 0.08) y = h * (L.base - rnd() * L.amp);
      if (rnd() < 0.06) y = h * L.base + rnd() * 10;
      pts.push([x, y + (rnd() - 0.5) * 4]);
    }
    pts[pts.length - 1][1] = pts[0][1];
    pts.forEach(([x, yy]) => ctx.lineTo(x, yy));
    ctx.lineTo(w, h); ctx.closePath();
    ctx.fillStyle = L.col; ctx.fill();
    ctx.strokeStyle = L.ink; ctx.lineWidth = 3; ctx.beginPath(); pts.forEach(([x, yy], i) => (i ? ctx.lineTo(x, yy) : ctx.moveTo(x, yy))); ctx.stroke();
    // hatching shading on faces
    ctx.strokeStyle = 'rgba(70,40,20,0.25)'; ctx.lineWidth = 1.5;
    for (let i = 0; i < 400; i++) {
      const x = rnd() * w; const yy = pts[Math.min(pts.length - 1, Math.floor(x / 16))][1];
      const yb = yy + 8 + rnd() * (h - yy) * 0.6;
      ctx.beginPath(); ctx.moveTo(x, yb); ctx.lineTo(x + 6, yb + 10); ctx.stroke();
    }
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = THREE.RepeatWrapping;
  return t;
}
