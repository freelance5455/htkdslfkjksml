// =====================================================================
// Stylised cel-shading material system
// ---------------------------------------------------------------------
// We keep three.js' physically-based MeshStandardMaterial (so metals,
// roughness maps, normal maps and IBL reflections stay correct) and patch
// the direct-light term:
//
//   * N·L is remapped through a smooth multi-band ramp → crisp light /
//     shadow regions (cel bands) instead of a continuous gradient.
//   * `uToonMix` blends between PBR and toon per material. Environment uses
//     ~1.0 (fully illustrated), weapons ~0.55 (detailed, readable metal).
//   * World-space, surface-anchored hatching is drawn in the shadow band.
//     It uses a dominant-axis planar projection so it sticks to geometry
//     (no "shower-door" swimming) and fades out with fwidth() to avoid moiré.
//
// All toon materials share a single global uniform block so graphics
// settings (hatching on/off, strength) update instantly with no recompiles.
// =====================================================================
import * as THREE from 'three';

export const toonGlobals = {
  uHatchStrength: { value: 0.55 },
  uHatchScale: { value: 7.0 },
  uBandSoftness: { value: 0.035 },
  uShadowTint: { value: new THREE.Color(0x5a6a9a) },   // cool shadow tint (comic)
  uShadowTintAmt: { value: 0.22 },
};

const PARS = /* glsl */`
uniform float uToonMix;
uniform float uHatchStrength;
uniform float uHatchScale;
uniform float uHatchAmount;
uniform float uBandSoftness;
uniform vec3  uShadowTint;
uniform float uShadowTintAmt;
varying vec3 vToonWorldPos;
varying vec3 vToonWorldNormal;
float gToonShade = 1.0;   // 1 = fully lit, 0 = in shadow (set by the direct light term)

float toonRamp( float x ) {
  float s = uBandSoftness;
  // three bands: deep shadow (0.0), half-tone (0.55), lit (1.0)
  float a = smoothstep( 0.04 - s, 0.04 + s, x );
  float b = smoothstep( 0.42 - s, 0.42 + s, x );
  return a * 0.55 + b * 0.45;
}

float hatchPattern( vec3 p, vec3 n, float density ) {
  vec3 an = abs( n );
  vec2 uv = an.y > max( an.x, an.z ) ? p.xz : ( an.x > an.z ? p.zy : p.xy );
  uv *= uHatchScale;
  float s1 = uv.x + uv.y;
  float f1 = abs( fract( s1 ) - 0.5 );
  float w1 = fwidth( s1 );
  float l1 = 1.0 - smoothstep( 0.12 - w1, 0.12 + w1, f1 );
  // cross-hatch for the deepest shadows
  float s2 = uv.x - uv.y;
  float f2 = abs( fract( s2 * 1.0 ) - 0.5 );
  float w2 = fwidth( s2 );
  float l2 = 1.0 - smoothstep( 0.1 - w2, 0.1 + w2, f2 );
  float fade = 1.0 - smoothstep( 0.25, 0.6, w1 );   // kill lines when they get sub-pixel
  return clamp( l1 * smoothstep( 0.0, 0.35, density ) + l2 * smoothstep( 0.55, 0.95, density ), 0.0, 1.0 ) * fade;
}
`;

// Patched copy of lights_fragment_begin: inside the directional-light loop we
// record the sun's banded N·L multiplied by the shadow-map attenuation, so the
// hatching/shadow tint follows both form shadows and cast shadows of the sun
// only (muzzle-flash point lights do not trigger hatching).
const TOON_LIGHTS_BEGIN = (() => {
  const src = THREE.ShaderChunk.lights_fragment_begin;
  // slice on whole lines (each marker sits inside a '#if ( ... )' line)
  const a = src.lastIndexOf('\n', src.indexOf('NUM_DIR_LIGHTS > 0 ) &&')) + 1;
  const b = src.lastIndexOf('\n', src.indexOf('NUM_RECT_AREA_LIGHTS > 0 ) &&')) + 1;
  if (a <= 0 || b <= 0) return src;
  let block = src.slice(a, b);
  // declared once before the (unrolled) loop → no redeclaration with N lights
  block = block.replace('getDirectionalLightInfo( directionalLight, directLight );',
    'getDirectionalLightInfo( directionalLight, directLight );\n\t\ttoonUnshadowed = directLight.color;');
  block = block.replace('RE_Direct( directLight,',
    `{ float lu = dot( toonUnshadowed, vec3( 0.2126, 0.7152, 0.0722 ) );
       float ls = dot( directLight.color, vec3( 0.2126, 0.7152, 0.0722 ) );
       float sh = lu > 0.0001 ? ls / lu : 1.0;
       gToonShade = min( gToonShade, toonRamp( saturate( dot( geometryNormal, directLight.direction ) ) ) * sh ); }
		RE_Direct( directLight,`);
  return src.slice(0, a) + 'vec3 toonUnshadowed = vec3( 1.0 );\n' + block + src.slice(b);
})();

// Physical BRDF with the banded diffuse/specular N·L term.
const TOON_PHYSICAL_PARS = THREE.ShaderChunk.lights_physical_pars_fragment.replace(
  /void RE_Direct_Physical\(([\s\S]*?)float dotNL = saturate\( dot\( geometryNormal, directLight\.direction \) \);/,
  (m, args) => `void RE_Direct_Physical(${args}float dotNLraw = saturate( dot( geometryNormal, directLight.direction ) );
\tfloat dotNL = mix( dotNLraw, toonRamp( dotNLraw ), uToonMix );`);

function patchShader(shader, material) {
  shader.uniforms.uToonMix = material.userData.uToonMix;
  shader.uniforms.uHatchAmount = material.userData.uHatchAmount;
  Object.assign(shader.uniforms, toonGlobals);

  shader.vertexShader = shader.vertexShader
    .replace('#include <common>', '#include <common>\nvarying vec3 vToonWorldPos;\nvarying vec3 vToonWorldNormal;')
    .replace('#include <fog_vertex>', `#include <fog_vertex>
      vec4 toonWP = vec4( transformed, 1.0 );
      #ifdef USE_INSTANCING
        toonWP = instanceMatrix * toonWP;
      #endif
      toonWP = modelMatrix * toonWP;
      vToonWorldPos = toonWP.xyz;
      vToonWorldNormal = normalize( mat3( modelMatrix ) * objectNormal );`);

  shader.fragmentShader = shader.fragmentShader
    .replace('#include <common>', '#include <common>\n' + PARS)
    .replace('#include <lights_physical_pars_fragment>', TOON_PHYSICAL_PARS)
    .replace('#include <lights_fragment_begin>', TOON_LIGHTS_BEGIN)
    .replace(
      '#include <opaque_fragment>',
      `{
         // hatching + cool shadow tint in the sun-shadow band
         float shade = 1.0 - gToonShade;
         float hatch = hatchPattern( vToonWorldPos, vToonWorldNormal, shade ) * uHatchStrength * uHatchAmount;
         outgoingLight = mix( outgoingLight, outgoingLight * uShadowTint * 1.6, shade * uShadowTintAmt * uToonMix );
         outgoingLight *= 1.0 - hatch * 0.55;
       }
       #include <opaque_fragment>`);
}

/**
 * Create a toon-patched MeshStandardMaterial.
 * @param {object} params    MeshStandardMaterial params
 * @param {object} toon      { mix: 0..1, hatch: 0..1 }
 */
export function toonMaterial(params = {}, toon = {}) {
  const m = new THREE.MeshStandardMaterial(params);
  m.userData.uToonMix = { value: toon.mix ?? 1.0 };
  m.userData.uHatchAmount = { value: toon.hatch ?? 1.0 };
  // the shadow-band term uses the direct light colour, which already contains
  // the shadow-map attenuation, so cast shadows also receive hatching.
  m.onBeforeCompile = (shader) => patchShader(shader, m);
  m.customProgramCacheKey = () => 'toon-v3';
  return m;
}

// Material presets for the environment and for weapons
export function envMat(params, hatch = 1.0) { return toonMaterial(params, { mix: 1.0, hatch }); }
export function gunMat(params) { return toonMaterial({ envMapIntensity: 0.9, ...params }, { mix: 0.55, hatch: 0.0 }); }

// Basic unlit ink material (used for small ink accents)
export const inkMaterial = new THREE.MeshBasicMaterial({ color: 0x15110d });
