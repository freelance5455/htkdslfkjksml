// =====================================================================
// Ink outline + comic grade pass
// ---------------------------------------------------------------------
// Screen-space edge detection on a depth + view-normal prepass.
//  * Depth edges use a *relative* threshold (|Δz| / z) so silhouette
//    thickness is stable at every distance and doesn't explode on thin
//    geometry or grazing floors.
//  * Normal edges detect creases (crease ink).
//  * Line width scales with distance (thicker near, thinner far) and fades
//    with fog distance so the horizon doesn't turn into a black smear.
//  * The first-person weapon layer is rendered into the same prepass with
//    its own depth range, and gets a slightly thinner, darker line so small
//    weapon details aren't swallowed (per-object tuning via the normal
//    buffer's alpha channel = "ink weight").
// Also applies the comic grade: slight saturation boost, warm highlights,
// cool shadows and a subtle paper grain.
// =====================================================================
import * as THREE from 'three';
import { LENS_LAYER } from '../weapons/optics.js';
import { Pass, FullScreenQuad } from 'three/addons/postprocessing/Pass.js';

const NormalInkShader = {
  vertexShader: /* glsl */`
    varying vec3 vN;
    #include <common>
    #include <morphtarget_pars_vertex>
    #include <skinning_pars_vertex>
    void main() {
      #include <beginnormal_vertex>
      #include <morphnormal_vertex>
      #include <skinbase_vertex>
      #include <skinnormal_vertex>
      #include <defaultnormal_vertex>
      vN = normalize( transformedNormal );
      #include <begin_vertex>
      #include <morphtarget_vertex>
      #include <skinning_vertex>
      #include <project_vertex>
    }`,
  fragmentShader: /* glsl */`
    uniform float uInk;
    varying vec3 vN;
    void main() {
      vec3 n = normalize( vN );
      if ( !gl_FrontFacing ) n = -n;
      gl_FragColor = vec4( n * 0.5 + 0.5, uInk );
    }`,
};

export class InkOutlinePass extends Pass {
  constructor(scene, camera, width, height) {
    super();
    this.scene = scene;
    this.camera = camera;
    this.extraLayers = []; // [{scene, camera}] rendered on top (viewmodel)
    this.enabled = true;
    this.outlinesEnabled = true;

    const rtOpts = { type: THREE.HalfFloatType, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter };
    this.normalTarget = new THREE.WebGLRenderTarget(width, height, rtOpts);
    this.normalTarget.depthTexture = new THREE.DepthTexture(width, height);
    this.normalTarget.depthTexture.type = THREE.UnsignedIntType;

    this.normalMaterial = new THREE.ShaderMaterial({
      uniforms: { uInk: { value: 1.0 } },
      vertexShader: NormalInkShader.vertexShader,
      fragmentShader: NormalInkShader.fragmentShader,
    });

    this.material = new THREE.ShaderMaterial({
      uniforms: {
        tDiffuse: { value: null },
        tNormal: { value: this.normalTarget.texture },
        tDepth: { value: this.normalTarget.depthTexture },
        resolution: { value: new THREE.Vector2(width, height) },
        cameraNear: { value: camera.near },
        cameraFar: { value: camera.far },
        inkColor: { value: new THREE.Color(0x15110d) },
        thickness: { value: 1.35 },
        depthThreshold: { value: 0.025 },
        normalThreshold: { value: 0.45 },
        fogFar: { value: 600.0 },
        outlines: { value: 1.0 },
        saturation: { value: 1.22 },
        warmth: { value: 0.05 },
        grain: { value: 0.025 },
        vignette: { value: 0.22 },
        time: { value: 0 },
        hurt: { value: 0 },
      },
      vertexShader: /* glsl */`
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 ); }`,
      fragmentShader: /* glsl */`
        #include <packing>
        uniform sampler2D tDiffuse, tNormal, tDepth;
        uniform vec2 resolution;
        uniform float cameraNear, cameraFar, thickness, depthThreshold, normalThreshold, fogFar, outlines;
        uniform float saturation, warmth, grain, vignette, time, hurt;
        uniform vec3 inkColor;
        varying vec2 vUv;

        float viewZ( vec2 uv ) {
          float d = texture2D( tDepth, uv ).x;
          return -perspectiveDepthToViewZ( d, cameraNear, cameraFar );
        }
        float hash( vec2 p ) { return fract( sin( dot( p, vec2( 12.9898, 78.233 ) ) ) * 43758.5453 ); }

        void main() {
          vec4 col = texture2D( tDiffuse, vUv );
          vec3 c = col.rgb;

          float ink = 0.0;
          if ( outlines > 0.5 ) {
            float z0 = viewZ( vUv );
            vec4 n0 = texture2D( tNormal, vUv );
            // thicker near, thinner far; viewmodel (alpha < 1) gets thin lines
            float w = thickness * mix( 1.0, 0.65, step( n0.a, 0.9 ) );
            w *= clamp( 2.2 - log( 1.0 + z0 ) * 0.35, 0.7, 1.6 );
            vec2 px = w / resolution;
            vec2 offs[4];
            offs[0] = vec2( px.x, 0.0 ); offs[1] = vec2( -px.x, 0.0 ); offs[2] = vec2( 0.0, px.y ); offs[3] = vec2( 0.0, -px.y );
            float dEdge = 0.0, nEdge = 0.0;
            for ( int i = 0; i < 4; i++ ) {
              vec2 uv = vUv + offs[i];
              float z = viewZ( uv );
              // relative depth difference; only the farther side draws (sharp silhouette)
              float dz = ( z - z0 ) / max( z0, 0.05 );
              dEdge = max( dEdge, smoothstep( depthThreshold, depthThreshold * 2.0, dz ) );
              vec4 n = texture2D( tNormal, uv );
              float nd = 1.0 - dot( n0.xyz * 2.0 - 1.0, n.xyz * 2.0 - 1.0 );
              nEdge = max( nEdge, smoothstep( normalThreshold, normalThreshold + 0.25, nd ) );
            }
            // sky has depth 1: don't draw ink inside the sky
            float sky = step( 0.99999, texture2D( tDepth, vUv ).x );
            float fade = 1.0 - smoothstep( fogFar * 0.25, fogFar * 0.75, z0 );
            ink = max( dEdge, nEdge * 0.85 ) * fade * ( 1.0 - sky );
          }
          c = mix( c, inkColor, clamp( ink, 0.0, 1.0 ) * 0.92 );

          // ---- comic grade (applied in linear HDR before tone mapping) ----
          float l = dot( c, vec3( 0.2126, 0.7152, 0.0722 ) );
          c = mix( vec3( l ), c, saturation );
          c *= mix( vec3( 0.97, 0.99, 1.05 ), vec3( 1.0 + warmth, 1.0 + warmth * 0.45, 1.0 - warmth * 0.6 ), smoothstep( 0.05, 0.6, l ) );
          // paper grain
          float g = hash( vUv * resolution + fract( time ) * 61.0 ) - 0.5;
          c *= 1.0 + g * grain;
          // vignette + damage vignette
          vec2 q = vUv - 0.5;
          float v = smoothstep( 0.85, 0.2, length( q * vec2( 1.0, 0.8 ) ) );
          c *= mix( 1.0 - vignette, 1.0, v );
          c = mix( c, c * vec3( 1.4, 0.4, 0.35 ), hurt * ( 1.0 - v ) );
          gl_FragColor = vec4( c, col.a );
        }`,
    });
    this.fsQuad = new FullScreenQuad(this.material);
    this._clearColor = new THREE.Color();
  }

  setSize(width, height) {
    this.normalTarget.setSize(width, height);
    this.material.uniforms.resolution.value.set(width, height);
  }

  render(renderer, writeBuffer, readBuffer) {
    const u = this.material.uniforms;
    u.tDiffuse.value = readBuffer.texture;
    u.cameraNear.value = this.camera.near;
    u.cameraFar.value = this.camera.far;
    u.outlines.value = this.outlinesEnabled ? 1 : 0;

    if (this.outlinesEnabled) {
      // ---- normal / depth prepass ----
      const oldOverride = this.scene.overrideMaterial;
      const oldBg = this.scene.background;
      renderer.getClearColor(this._clearColor);
      const oldAlpha = renderer.getClearAlpha();
      const oldAutoClear = renderer.autoClear;
      const oldShadow = renderer.shadowMap.autoUpdate;
      renderer.shadowMap.autoUpdate = false;
      renderer.setRenderTarget(this.normalTarget);
      renderer.setClearColor(0x8080ff, 1);
      renderer.clear();
      this.scene.overrideMaterial = this.normalMaterial;
      this.scene.background = null;
      this.normalMaterial.uniforms.uInk.value = 1.0;
      renderer.render(this.scene, this.camera);
      this.scene.overrideMaterial = oldOverride;
      this.scene.background = oldBg;
      // viewmodel layer: clear depth, mark with ink weight 0.5
      for (const layer of this.extraLayers) {
        if (!layer.visible) continue;
        renderer.autoClear = false;
        renderer.clearDepth();
        const o = layer.scene.overrideMaterial;
        layer.scene.overrideMaterial = this.normalMaterial;
        this.normalMaterial.uniforms.uInk.value = 0.5;
        layer.camera.layers.disable(LENS_LAYER);
        renderer.render(layer.scene, layer.camera);
        layer.camera.layers.enable(LENS_LAYER);
        layer.scene.overrideMaterial = o;
      }
      renderer.autoClear = oldAutoClear;
      renderer.shadowMap.autoUpdate = oldShadow;
      renderer.setClearColor(this._clearColor, oldAlpha);
    }

    if (this.renderToScreen) renderer.setRenderTarget(null);
    else { renderer.setRenderTarget(writeBuffer); if (this.clear) renderer.clear(); }
    this.fsQuad.render(renderer);
  }

  dispose() {
    this.normalTarget.dispose();
    this.normalMaterial.dispose();
    this.material.dispose();
    this.fsQuad.dispose();
  }
}
