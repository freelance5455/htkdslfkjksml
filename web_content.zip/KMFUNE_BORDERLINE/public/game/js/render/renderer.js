// =====================================================================
// Renderer + post-processing pipeline
// ---------------------------------------------------------------------
//  World RenderPass (HDR, half-float)
//    → GTAO (optional, world only — the viewmodel is not occluded by the world)
//    → Viewmodel RenderPass (depth cleared, rendered over the world)
//    → Ink outline + comic grade (depth/normal edge detection)
//    → UnrealBloom (HDR threshold > 1 so only emissive/flash content blooms)
//    → OutputPass (tone mapping + sRGB)
//    → FXAA / SMAA (on display-referred image)
//
//  "HDR" here means a genuine high-dynamic-range pipeline: lighting is
//  computed and stored in half-float buffers with values > 1.0 (sun,
//  muzzle flash), then compressed by a selectable filmic tone-mapping
//  operator. We do not claim HDR *display* output.
// =====================================================================
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { SMAAPass } from 'three/addons/postprocessing/SMAAPass.js';
import { FXAAPass } from 'three/addons/postprocessing/FXAAPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';
import { InkOutlinePass } from './outlinePass.js';
import { settings } from '../core/settings.js';
import { toonGlobals } from './toon.js';

const TONEMAPS = {
  aces: THREE.ACESFilmicToneMapping,
  agx: THREE.AgXToneMapping,
  neutral: THREE.NeutralToneMapping,
  linear: THREE.LinearToneMapping,
};

export class GameRenderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({
      canvas, antialias: false, powerPreference: 'high-performance', stencil: false, alpha: false,
    });
    const r = this.renderer;
    r.outputColorSpace = THREE.SRGBColorSpace;
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFSoftShadowMap;
    r.info.autoReset = false;

    this.scene = null; this.camera = null;
    this.vmScene = null; this.vmCamera = null;
    this.composer = null;
    this.width = 1; this.height = 1;
    this.applyingSettings = false;
  }

  setScenes(scene, camera, vmScene, vmCamera) {
    this.scene = scene; this.camera = camera;
    this.vmScene = vmScene; this.vmCamera = vmCamera;
    this.buildComposer();
    this.applySettings();
  }

  buildComposer() {
    const r = this.renderer;
    if (this.composer) { this.composer.dispose(); }
    const size = r.getDrawingBufferSize(new THREE.Vector2());
    const rt = new THREE.WebGLRenderTarget(Math.max(1, size.x), Math.max(1, size.y), { type: THREE.HalfFloatType });
    this.composer = new EffectComposer(r, rt);

    this.worldPass = new RenderPass(this.scene, this.camera);
    this.composer.addPass(this.worldPass);

    this.gtaoPass = new GTAOPass(this.scene, this.camera, size.x, size.y);
    this.gtaoPass.output = GTAOPass.OUTPUT.Default;
    this.gtaoPass.blendIntensity = 0.85;
    this.gtaoPass.updateGtaoMaterial({ radius: 0.6, distanceExponent: 1.5, thickness: 1.2, scale: 1.0, samples: 12 });
    this.gtaoPass.updatePdMaterial({ lumaPhi: 10, depthPhi: 2, normalPhi: 3, radius: 6, rings: 2, samples: 12 });
    this.composer.addPass(this.gtaoPass);

    this.vmPass = new RenderPass(this.vmScene, this.vmCamera);
    this.vmPass.clear = false;
    this.vmPass.clearDepth = true;
    this.composer.addPass(this.vmPass);

    this.inkPass = new InkOutlinePass(this.scene, this.camera, size.x, size.y);
    this.inkPass.extraLayers.push({ scene: this.vmScene, camera: this.vmCamera, visible: true });
    this.composer.addPass(this.inkPass);

    this.bloomPass = new UnrealBloomPass(new THREE.Vector2(size.x, size.y), 0.4, 0.45, 1.6);
    this.composer.addPass(this.bloomPass);

    this.outputPass = new OutputPass();
    this.composer.addPass(this.outputPass);

    this.fxaaPass = new FXAAPass();
    this.composer.addPass(this.fxaaPass);
    this.smaaPass = new SMAAPass();
    this.composer.addPass(this.smaaPass);
  }

  applySettings() {
    const g = settings.graphics;
    const r = this.renderer;
    r.toneMapping = TONEMAPS[g.toneMapping] ?? THREE.ACESFilmicToneMapping;
    r.toneMappingExposure = g.exposure;

    const shadowSizes = [0, 1024, 2048, 4096];
    const wantShadows = g.shadowQuality > 0;
    if (r.shadowMap.enabled !== wantShadows) {
      r.shadowMap.enabled = wantShadows;
      // shadow map toggling changes shader defines → force material refresh
      this.scene?.traverse((o) => { if (o.material) { (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => (m.needsUpdate = true)); } });
      this.vmScene?.traverse((o) => { if (o.material) { (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => (m.needsUpdate = true)); } });
    }
    r.shadowMap.type = g.shadowQuality >= 2 ? THREE.PCFSoftShadowMap : THREE.PCFShadowMap;
    this.shadowMapSize = shadowSizes[g.shadowQuality] || 1024;

    toonGlobals.uHatchStrength.value = g.hatching ? 0.55 : 0.0;

    if (this.composer) {
      const post = g.postProcessing;
      this.gtaoPass.enabled = post && g.aoQuality > 0;
      if (g.aoQuality > 0) this.gtaoPass.updateGtaoMaterial({ samples: g.aoQuality >= 2 ? 16 : 8 });
      this.inkPass.outlinesEnabled = !!g.outlines;
      this.inkPass.enabled = post;
      this.bloomPass.enabled = post && g.bloom;
      this.bloomPass.strength = g.bloomIntensity;
      this.fxaaPass.enabled = post && g.antialias === 'fxaa';
      this.smaaPass.enabled = post && g.antialias === 'smaa';
      this.inkPass.material.uniforms.fogFar.value = g.viewDistance;
    }
    this.resize();
  }

  get pixelRatio() {
    const g = settings.graphics;
    const dpr = Math.min(window.devicePixelRatio || 1, g.maxPixelRatio);
    return Math.max(0.35, dpr * g.resolutionScale);
  }

  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.width = w; this.height = h;
    const pr = this.pixelRatio;
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    if (this.composer) {
      this.composer.setPixelRatio(pr);
      this.composer.setSize(w, h);
    }
    for (const cam of [this.camera, this.vmCamera]) {
      if (!cam) continue;
      cam.aspect = w / h; cam.updateProjectionMatrix();
    }
  }

  render(dt, time, hurt = 0) {
    const r = this.renderer;
    r.info.reset();
    const g = settings.graphics;
    if (g.postProcessing && this.composer) {
      this.inkPass.material.uniforms.time.value = time;
      this.inkPass.material.uniforms.hurt.value = hurt;
      this.inkPass.extraLayers[0].visible = this.vmScene.visible;
      this.vmPass.enabled = this.vmScene.visible;
      this.composer.render(dt);
    } else {
      // direct path: tone mapping is applied by the renderer on screen output
      r.setRenderTarget(null);
      r.autoClear = true;
      r.render(this.scene, this.camera);
      if (this.vmScene.visible) {
        r.autoClear = false;
        r.clearDepth();
        r.render(this.vmScene, this.vmCamera);
        r.autoClear = true;
      }
    }
  }

  get drawingBufferSize() { return this.renderer.getDrawingBufferSize(new THREE.Vector2()); }
}
