// =====================================================================
// Map: OPEN CONCRETE TEST RANGE
// ---------------------------------------------------------------------
// Layout (metres, +Z = south / toward spawn, -Z = downrange / north):
//   * 240 x 240 m concrete apron made of 6 m poured slabs (expansion joints)
//   * Spawn pad at z=+20 with a weapon bench
//   * Downrange: target lanes at 10 / 25 / 50 / 100 m with paper targets
//     on stands and spring-loaded steel plates (ring when hit)
//   * Left: concrete wall gallery (impact testing walls, pillars, barriers)
//   * Right: open sprint/slide strip with jump boxes and a step ramp
//   * Perimeter: low jersey barriers, light towers, shipping containers,
//     water tower, painted mesas on the horizon (from sky.js)
// All static solids are registered as AABB colliders (physics.js).
// Maps implement: build(ctx) → { spawn, update(dt), dispose() }
// =====================================================================
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { envMat } from '../render/toon.js';
import { concreteTextures, wearTextures, targetFaceTexture, mulberry32 } from '../render/textures.js';

export const MAP_INFO = { id: 'test_range', name: 'Concrete Test Range', description: 'Open weapons test range.' };

// UV-box geometry with world-scaled UVs (so concrete texel density is constant)
function boxWorldUV(sx, sy, sz, texelPerMeter = 0.25) {
  const g = new THREE.BoxGeometry(sx, sy, sz);
  const uv = g.attributes.uv, pos = g.attributes.position, nrm = g.attributes.normal;
  for (let i = 0; i < uv.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const nx = Math.abs(nrm.getX(i)), ny = Math.abs(nrm.getY(i));
    let u, v;
    if (ny > 0.5) { u = x; v = z; } else if (nx > 0.5) { u = z; v = y; } else { u = x; v = y; }
    uv.setXY(i, u * texelPerMeter, v * texelPerMeter);
  }
  return g;
}

export function buildTestRange(ctx) {
  const { scene, physics, quality, sun } = ctx;
  const root = new THREE.Group();
  root.name = 'map_test_range';
  scene.add(root);
  const rnd = mulberry32(90210);
  const disposables = [];
  const track = (x) => { disposables.push(x); return x; };
  const tq = quality.textureQuality;

  // ---------------- materials ----------------
  const slabTex = concreteTextures(tq, { seed: 11, joints: true, cracks: 9, repeat: 1, base: [158, 148, 132] });
  const floorMat = track(envMat({ map: slabTex.map, normalMap: slabTex.normalMap, roughnessMap: slabTex.roughnessMap, roughness: 1, metalness: 0, normalScale: new THREE.Vector2(0.9, 0.9) }, 0.9));
  const wallTex = concreteTextures(tq, { seed: 23, cracks: 5, base: [178, 166, 146], normalStrength: 2.5 });
  const wallMat = track(envMat({ map: wallTex.map, normalMap: wallTex.normalMap, roughnessMap: wallTex.roughnessMap, roughness: 1, metalness: 0 }));
  const darkTex = concreteTextures(tq, { seed: 31, cracks: 4, base: [128, 118, 104] });
  const darkConcrete = track(envMat({ map: darkTex.map, normalMap: darkTex.normalMap, roughness: 1, metalness: 0 }));
  const wear = wearTextures(tq, 3);
  const steelMat = track(envMat({ color: 0x5b6066, map: wear.map, roughnessMap: wear.roughnessMap, normalMap: wear.normalMap, roughness: 0.55, metalness: 0.75 }, 0.7));
  const rustMat = track(envMat({ color: 0xa4552a, map: wear.map, roughness: 0.85, metalness: 0.3 }, 0.9));
  const yellowPaint = track(envMat({ color: 0xf2b21c, map: wear.map, roughness: 0.6, metalness: 0.1 }, 0.6));
  const redPaint = track(envMat({ color: 0xc83a26, map: wear.map, roughness: 0.6, metalness: 0.1 }, 0.7));
  const tealPaint = track(envMat({ color: 0x2f7f86, map: wear.map, roughness: 0.65, metalness: 0.2 }, 0.8));
  const woodMat = track(envMat({ color: 0x9a6a3c, roughness: 0.85, metalness: 0 }, 0.9));
  const plateMat = track(envMat({ color: 0xe8e1cf, map: wear.map, roughness: 0.4, metalness: 0.6 }, 0.6));
  const faceTex = targetFaceTexture();
  const faceMat = track(envMat({ map: faceTex, roughness: 0.9 }, 0.3));
  const lampMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(3.0, 2.6, 1.8) });

  // ---------------- floor: big slab with world UVs (6 m per tile) ----------------
  const FLOOR = 480;
  const floorGeo = new THREE.PlaneGeometry(FLOOR, FLOOR, 1, 1);
  floorGeo.rotateX(-Math.PI / 2);
  const fuv = floorGeo.attributes.uv;
  for (let i = 0; i < fuv.count; i++) fuv.setXY(i, (fuv.getX(i) - 0.5) * FLOOR / 6, (fuv.getY(i) - 0.5) * FLOOR / 6);
  const floor = new THREE.Mesh(floorGeo, floorMat);
  floor.receiveShadow = true;
  floor.name = 'floor';
  root.add(floor);

  // painted lane lines & range markings (decals as thin geometry, slightly above floor)
  const lineMat = track(new THREE.MeshStandardMaterial({ color: 0xf2c230, roughness: 0.8, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }));
  const whiteLine = track(new THREE.MeshStandardMaterial({ color: 0xf1ead8, roughness: 0.8, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }));
  const lineGeos = [], whiteGeos = [];
  for (let lane = -3; lane <= 3; lane++) {
    const g = new THREE.PlaneGeometry(0.18, 130); g.rotateX(-Math.PI / 2); g.translate(lane * 6 - 3, 0.003, -55);
    lineGeos.push(g);
  }
  for (const d of [0, 10, 25, 50, 100]) {
    const g = new THREE.PlaneGeometry(42, d === 0 ? 0.5 : 0.22); g.rotateX(-Math.PI / 2); g.translate(0, 0.003, 10 - d);
    (d === 0 ? lineGeos : whiteGeos).push(g);
  }
  // hazard chevrons around spawn pad
  for (let i = 0; i < 12; i++) {
    const g = new THREE.PlaneGeometry(0.7, 0.25); g.rotateX(-Math.PI / 2); g.rotateY(Math.PI / 4); g.translate(-8 + i * 1.4, 0.004, 13);
    lineGeos.push(g);
  }
  root.add(new THREE.Mesh(mergeGeometries(lineGeos), lineMat));
  root.add(new THREE.Mesh(mergeGeometries(whiteGeos), whiteLine));
  lineGeos.forEach((g) => g.dispose()); whiteGeos.forEach((g) => g.dispose());

  // distance number boards
  const boardCanvas = (txt) => {
    const c = document.createElement('canvas'); c.width = 256; c.height = 128;
    const x = c.getContext('2d');
    x.fillStyle = '#f2c230'; x.fillRect(0, 0, 256, 128);
    x.strokeStyle = '#15110d'; x.lineWidth = 10; x.strokeRect(5, 5, 246, 118);
    x.fillStyle = '#15110d'; x.font = 'bold 84px Bangers, Impact, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(txt, 128, 70);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
  };

  // ---------------- helpers ----------------
  const solid = (geo, mat, x, y, z, collide = true, material = 'concrete', cast = true) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    m.castShadow = cast; m.receiveShadow = true;
    root.add(m);
    if (collide) {
      geo.computeBoundingBox();
      const bb = geo.boundingBox;
      physics.addBox(bb.min.clone().add(m.position), bb.max.clone().add(m.position), material);
    }
    return m;
  };
  const cbox = (sx, sy, sz, x, y, z, mat = wallMat, material = 'concrete') => solid(boxWorldUV(sx, sy, sz), mat, x, y + sy / 2, z, true, material);

  // ---------------- spawn bench ----------------
  cbox(4.0, 0.9, 1.0, 6, 0, 16, darkConcrete);
  const benchTop = solid(new RoundedBoxGeometry(4.2, 0.08, 1.2, 2, 0.02), woodMat, 6, 0.94, 16, false);
  void benchTop;
  // ammo crates on bench (visual)
  for (let i = 0; i < 3; i++) {
    const crate = solid(new RoundedBoxGeometry(0.7, 0.4, 0.45, 2, 0.03), i === 1 ? redPaint : tealPaint, 4.6 + i * 1.2, 1.18, 16, false);
    crate.rotation.y = (rnd() - 0.5) * 0.3;
  }

  // ---------------- downrange lanes: target stands ----------------
  const targets = [];
  const standGeo = new THREE.CylinderGeometry(0.05, 0.05, 1.6, 8);
  const baseGeo = boxWorldUV(1.2, 0.3, 0.6);
  const boardGeo = new THREE.BoxGeometry(1.0, 1.4, 0.06);
  const faceGeo = new THREE.PlaneGeometry(0.95, 0.95);
  const distances = [10, 25, 50, 100];
  distances.forEach((d, di) => {
    const z = 10 - d;
    for (let lane = -2; lane <= 2; lane++) {
      if (d >= 50 && Math.abs(lane) === 2) continue;
      const x = lane * 6;
      // concrete base (collider)
      solid(baseGeo, darkConcrete, x, 0.15, z, true);
      // pivoting target group (falls back when "killed", pops up again)
      const pivot = new THREE.Group();
      pivot.position.set(x, 0.3, z);
      root.add(pivot);
      const pole1 = new THREE.Mesh(standGeo, steelMat); pole1.position.set(-0.42, 0.8, 0); pole1.castShadow = true; pivot.add(pole1);
      const pole2 = new THREE.Mesh(standGeo, steelMat); pole2.position.set(0.42, 0.8, 0); pole2.castShadow = true; pivot.add(pole2);
      const board = new THREE.Mesh(boardGeo, woodMat); board.position.set(0, 1.25, 0); board.castShadow = true; board.receiveShadow = true; pivot.add(board);
      const face = new THREE.Mesh(faceGeo, faceMat); face.position.set(0, 1.25, 0.032); pivot.add(face);
      const t = {
        object3D: pivot,
        box: new THREE.Box3(new THREE.Vector3(-0.5, 0.55, -0.04), new THREE.Vector3(0.5, 1.95, 0.04)),
        material: 'wood',
        enabled: true,
        kind: 'paper',
        maxHp: 150 + di * 50, hp: 150 + di * 50,
        state: 'up', timer: 0, angle: 0,
        distance: d,
        center: new THREE.Vector3(0, 1.25, 0),
        face,
      };
      physics.addTarget(t);
      targets.push(t);
    }
    // distance board
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.8), new THREE.MeshBasicMaterial({ map: track(boardCanvas(d + 'M')), toneMapped: true }));
    sign.position.set(-16.5, 1.6, z); sign.rotation.y = Math.PI / 6;
    root.add(sign);
    solid(new THREE.CylinderGeometry(0.06, 0.06, 1.3, 8), steelMat, -16.5, 0.65, z - 0.05, false);
  });

  // ---------------- steel plate rack (ringing plates) at 35 m ----------------
  const plates = [];
  const plateZ = -25;
  solid(boxWorldUV(9, 0.25, 0.8), darkConcrete, 24, 0.125, plateZ, true);
  const rackBar = solid(new THREE.BoxGeometry(9, 0.12, 0.12), rustMat, 24, 1.9, plateZ, false);
  void rackBar;
  for (const px of [-3.6, 3.6]) solid(new THREE.BoxGeometry(0.15, 1.9, 0.15), rustMat, 24 + px + (px < 0 ? -0.6 : 0.6), 0.95, plateZ, false);
  for (let i = 0; i < 5; i++) {
    const hinge = new THREE.Group();
    hinge.position.set(24 - 3.2 + i * 1.6, 1.84, plateZ);
    root.add(hinge);
    const chainL = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.3, 4), steelMat); chainL.position.set(-0.15, -0.15, 0); hinge.add(chainL);
    const chainR = chainL.clone(); chainR.position.x = 0.15; hinge.add(chainR);
    const isRound = i % 2 === 0;
    const pg = isRound ? new THREE.CylinderGeometry(0.4, 0.4, 0.03, 28) : new THREE.BoxGeometry(0.62, 0.8, 0.03);
    if (isRound) pg.rotateX(Math.PI / 2);
    const plate = new THREE.Mesh(pg, plateMat);
    plate.position.y = -0.3 - (isRound ? 0.4 : 0.4);
    plate.castShadow = true;
    hinge.add(plate);
    const t = {
      object3D: plate,
      box: isRound ? new THREE.Box3(new THREE.Vector3(-0.38, -0.38, -0.02), new THREE.Vector3(0.38, 0.38, 0.02)) : new THREE.Box3(new THREE.Vector3(-0.31, -0.4, -0.02), new THREE.Vector3(0.31, 0.4, 0.02)),
      material: 'metal', enabled: true, kind: 'plate', hinge, swing: 0, swingVel: 0,
      hp: Infinity, maxHp: Infinity, center: new THREE.Vector3(),
    };
    physics.addTarget(t);
    plates.push(t);
  }

  // ---------------- moving target on a rail at 40 m ----------------
  const railZ = -32;
  solid(boxWorldUV(30, 0.2, 0.5), steelMat, -2, 0.1, railZ, true, 'metal');
  const mover = new THREE.Group(); mover.position.set(-2, 0.2, railZ); root.add(mover);
  const cart = new THREE.Mesh(new RoundedBoxGeometry(1.0, 0.35, 0.6, 2, 0.05), yellowPaint); cart.position.y = 0.18; cart.castShadow = true; mover.add(cart);
  const silhouette = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.5, 0.05), redPaint); silhouette.position.y = 1.15; silhouette.castShadow = true; mover.add(silhouette);
  const head = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.05, 20), redPaint); head.rotation.x = Math.PI / 2; head.position.y = 2.12; mover.add(head);
  const moverTarget = {
    object3D: mover, box: new THREE.Box3(new THREE.Vector3(-0.42, 0.38, -0.04), new THREE.Vector3(0.42, 2.36, 0.04)),
    material: 'metal', enabled: true, kind: 'mover', hp: Infinity, maxHp: Infinity, center: new THREE.Vector3(0, 1.3, 0), headY: 1.9,
  };
  physics.addTarget(moverTarget);

  // ---------------- left: impact wall gallery ----------------
  // long wall with buttresses, and free-standing walls at varied angles (still AABB)
  cbox(1.0, 5.0, 60, -34, 0, -20);                         // long wall
  for (let i = 0; i < 6; i++) cbox(1.6, 5.4, 1.2, -33.2, 0, -46 + i * 10.5, darkConcrete); // buttresses
  cbox(8, 3.2, 0.6, -24, 0, -8);
  cbox(0.6, 3.2, 8, -20, 0, -22);
  cbox(10, 1.2, 0.8, -25, 0, -36, darkConcrete);           // half-height cover
  cbox(2.4, 2.4, 2.4, -22, 0, 2, wallMat);                 // cube
  // pillars
  for (let i = 0; i < 4; i++) {
    const p = solid(new THREE.CylinderGeometry(0.6, 0.7, 6, 18), wallMat, -28 + (i % 2) * 6, 3, -50 - Math.floor(i / 2) * 8, false);
    physics.addBoxCS(p.position.x, 3, p.position.z, 1.2, 6, 1.2, 'concrete');
  }
  // steel impact panel on the long wall
  const steelPanel = solid(new THREE.BoxGeometry(0.12, 2.6, 6), steelMat, -33.44, 1.6, -2, true, 'metal');
  void steelPanel;

  // jersey barriers (perimeter + scattered)
  const jersey = (() => {
    const shape = new THREE.Shape();
    shape.moveTo(-0.3, 0); shape.lineTo(0.3, 0); shape.lineTo(0.3, 0.08); shape.lineTo(0.15, 0.3); shape.lineTo(0.1, 0.81); shape.lineTo(-0.1, 0.81); shape.lineTo(-0.15, 0.3); shape.lineTo(-0.3, 0.08); shape.closePath();
    const g = new THREE.ExtrudeGeometry(shape, { depth: 3.0, bevelEnabled: true, bevelThickness: 0.02, bevelSize: 0.02, bevelSegments: 1 });
    g.translate(0, 0, -1.5);
    // world-scaled UVs
    const uv = g.attributes.uv, pos = g.attributes.position;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, pos.getZ(i) * 0.25 + pos.getX(i) * 0.25, pos.getY(i) * 0.25);
    return g;
  })();
  const jerseyPositions = [];
  for (let i = -6; i <= 6; i++) { jerseyPositions.push([i * 3.1, -118, 0]); jerseyPositions.push([i * 3.1 + 40, -118, 0]); jerseyPositions.push([i * 3.1 - 40, -118, 0]); }
  for (let i = -8; i <= 8; i++) { jerseyPositions.push([62, i * 3.1 - 30, Math.PI / 2]); }
  [[14, -6, 0], [17.2, -6, 0], [-10, -14, Math.PI / 2], [30, 6, 0.0], [33.2, 6, 0]].forEach((p) => jerseyPositions.push(p));
  const jerseyMesh = new THREE.InstancedMesh(jersey, wallMat, jerseyPositions.length);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), s1 = new THREE.Vector3(1, 1, 1);
  jerseyPositions.forEach(([x, z, ry], i) => {
    q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), ry);
    m4.compose(new THREE.Vector3(x, 0, z), q, s1);
    jerseyMesh.setMatrixAt(i, m4);
    const alongX = Math.abs(Math.sin(ry)) > 0.5;
    physics.addBoxCS(x, 0.4, z, alongX ? 3.0 : 0.6, 0.81, alongX ? 0.6 : 3.0, 'concrete');
  });
  jerseyMesh.castShadow = true; jerseyMesh.receiveShadow = true;
  root.add(jerseyMesh);

  // ---------------- right: movement strip ----------------
  cbox(3, 0.6, 3, 22, 0, 2, darkConcrete);         // jump box low
  cbox(3, 1.2, 3, 26, 0, -2, darkConcrete);        // jump box mid
  cbox(3, 1.8, 3, 30, 0, -6, darkConcrete);        // jump box high
  // stairs (step-up test)
  for (let i = 0; i < 6; i++) cbox(4, 0.25 * (i + 1), 0.6, 38, 0, 8 - i * 0.6, wallMat);
  cbox(4, 1.5, 6, 38, 0, 1.4, wallMat);            // platform at the top
  // low tunnel for crouch/slide testing (roof at 1.25 m)
  cbox(0.6, 1.25, 8, 44, 0, -14, wallMat);
  cbox(0.6, 1.25, 8, 47, 0, -14, wallMat);
  cbox(3.6, 0.4, 8, 45.5, 1.25, -14, darkConcrete);
  // painted slide lane
  {
    const g = new THREE.PlaneGeometry(4, 30); g.rotateX(-Math.PI / 2); g.translate(45.5, 0.004, -40);
    const slideLane = new THREE.Mesh(g, track(new THREE.MeshStandardMaterial({ color: 0x2f7f86, roughness: 0.7, transparent: true, opacity: 0.55, polygonOffset: true, polygonOffsetFactor: -2 })));
    root.add(slideLane);
  }

  // ---------------- perimeter dressing ----------------
  // shipping containers
  const containerGeo = (() => {
    const parts = [];
    const body = new THREE.BoxGeometry(12.2, 2.6, 2.44); parts.push(body);
    for (let i = 0; i < 22; i++) { const r = new THREE.BoxGeometry(0.12, 2.4, 2.5); r.translate(-5.8 + i * 0.55, 0, 0); parts.push(r); }
    return mergeGeometries(parts.map((p) => p.toNonIndexed()));
  })();
  [[-50, 1.3, -80, 0.2, rustMat], [-48, 3.9, -79, 0.35, tealPaint], [70, 1.3, -60, Math.PI / 2, redPaint], [70, 1.3, -46, Math.PI / 2, tealPaint], [-70, 1.3, 30, Math.PI / 2 + 0.1, yellowPaint]].forEach(([x, y, z, ry, mat]) => {
    const c = new THREE.Mesh(containerGeo, mat); c.position.set(x, y, z); c.rotation.y = ry; c.castShadow = true; c.receiveShadow = true; root.add(c);
    // conservative AABB of the rotated container
    const cos = Math.abs(Math.cos(ry)), sin = Math.abs(Math.sin(ry));
    physics.addBoxCS(x, y, z, 12.2 * cos + 2.44 * sin, 2.6, 12.2 * sin + 2.44 * cos, 'metal');
  });

  // light towers
  const towerParts = [];
  {
    const mast = new THREE.CylinderGeometry(0.18, 0.28, 14, 10); mast.translate(0, 7, 0); towerParts.push(mast);
    const bar = new THREE.BoxGeometry(3, 0.2, 0.2); bar.translate(0, 13.6, 0); towerParts.push(bar);
    const base = new THREE.BoxGeometry(1.4, 0.6, 1.4); base.translate(0, 0.3, 0); towerParts.push(base);
  }
  const towerGeo = mergeGeometries(towerParts.map((g) => g.toNonIndexed()));
  const lampGeo = new THREE.BoxGeometry(0.7, 0.5, 0.25);
  [[-40, 40], [40, 40], [-40, -100], [40, -100]].forEach(([x, z]) => {
    const t = new THREE.Mesh(towerGeo, steelMat); t.position.set(x, 0, z); t.castShadow = true; root.add(t);
    physics.addBoxCS(x, 0.3, z, 1.4, 0.6, 1.4, 'metal');
    physics.addBoxCS(x, 7, z, 0.5, 14, 0.5, 'metal');
    for (const lx of [-1.1, 0, 1.1]) { const l = new THREE.Mesh(lampGeo, lampMat); l.position.set(x + lx, 14.05, z); l.lookAt(0, 0, -20); root.add(l); }
  });

  // water tower landmark
  {
    const g = new THREE.Group(); g.position.set(-95, 0, -140); root.add(g);
    const tank = new THREE.Mesh(new THREE.CylinderGeometry(7, 7, 8, 24), rustMat); tank.position.y = 22; tank.castShadow = true; g.add(tank);
    const cap = new THREE.Mesh(new THREE.ConeGeometry(7.4, 3, 24), redPaint); cap.position.y = 27.5; g.add(cap);
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.45, 18, 8), steelMat);
      leg.position.set(Math.cos(a) * 5, 9, Math.sin(a) * 5); leg.castShadow = true; g.add(leg);
    }
    const band = new THREE.Mesh(new THREE.CylinderGeometry(7.05, 7.05, 1.2, 24, 1, true), yellowPaint); band.position.y = 22; g.add(band);
  }

  // range control booth behind spawn
  cbox(8, 3.2, 5, -6, 0, 30, wallMat);
  cbox(8.6, 0.3, 5.6, -6, 3.2, 30, darkConcrete);
  solid(new THREE.BoxGeometry(6, 1.2, 0.1), new THREE.MeshStandardMaterial({ color: 0x9fd4e6, roughness: 0.1, metalness: 0.2, emissive: 0x112233 }), -6, 2.0, 27.47, false);
  // warning sign
  {
    const c = document.createElement('canvas'); c.width = 512; c.height = 256;
    const x = c.getContext('2d');
    x.fillStyle = '#f2c230'; x.fillRect(0, 0, 512, 256);
    x.fillStyle = '#15110d'; for (let i = -4; i < 16; i++) { x.beginPath(); x.moveTo(i * 40, 0); x.lineTo(i * 40 + 20, 0); x.lineTo(i * 40 - 20, 40); x.lineTo(i * 40 - 40, 40); x.fill(); x.beginPath(); x.moveTo(i * 40, 216); x.lineTo(i * 40 + 20, 216); x.lineTo(i * 40 - 20, 256); x.lineTo(i * 40 - 40, 256); x.fill(); }
    x.font = '76px Bangers, Impact, sans-serif'; x.textAlign = 'center'; x.fillText('LIVE FIRE', 256, 120); x.font = '40px Bangers, Impact'; x.fillText('KMFUNE PROVING GROUNDS', 256, 180);
    const t = track(new THREE.CanvasTexture(c)); t.colorSpace = THREE.SRGBColorSpace;
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(4, 2), new THREE.MeshStandardMaterial({ map: t, roughness: 0.7 }));
    sign.position.set(-6, 2.4, 32.52); sign.rotation.y = Math.PI; root.add(sign);
    const sign2 = sign.clone(); sign2.position.set(-6, 2.4, 27.47); sign2.rotation.y = 0; root.add(sign2);
  }

  // scattered small debris (instanced rubble chunks) for ground detail
  {
    const g = new THREE.DodecahedronGeometry(0.12, 0);
    const n = quality.effectsQuality === 0 ? 120 : 400;
    const im = new THREE.InstancedMesh(g, darkConcrete, n);
    for (let i = 0; i < n; i++) {
      let x, z;
      do { x = (rnd() - 0.5) * 200; z = (rnd() - 0.5) * 200 - 30; } while (Math.abs(x) < 20 && z > -110 && z < 25);
      const s = 0.4 + rnd() * 1.6;
      m4.compose(new THREE.Vector3(x, 0.04 * s, z), q.setFromEuler(new THREE.Euler(rnd() * 3, rnd() * 3, rnd() * 3)), new THREE.Vector3(s, s * 0.6, s));
      im.setMatrixAt(i, m4);
    }
    im.receiveShadow = true;
    root.add(im);
  }

  // stylised tumbleweed-ish dry shrubs around the edges (cheap crossed planes)
  {
    const c = document.createElement('canvas'); c.width = 128; c.height = 128;
    const x = c.getContext('2d');
    x.strokeStyle = '#6e5a2c'; x.lineWidth = 3;
    for (let i = 0; i < 40; i++) { x.beginPath(); x.moveTo(64, 128); const a = -Math.PI / 2 + (rnd() - 0.5) * 2.2; const l = 40 + rnd() * 70; x.quadraticCurveTo(64 + Math.cos(a) * l * 0.5 + (rnd() - 0.5) * 30, 128 + Math.sin(a) * l * 0.5, 64 + Math.cos(a) * l, 128 + Math.sin(a) * l); x.stroke(); }
    x.strokeStyle = '#15110d'; x.lineWidth = 1; x.stroke();
    const t = track(new THREE.CanvasTexture(c)); t.colorSpace = THREE.SRGBColorSpace;
    const mat = track(new THREE.MeshStandardMaterial({ map: t, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 1 }));
    const g1 = new THREE.PlaneGeometry(1.4, 1.4); g1.translate(0, 0.7, 0);
    const g2 = g1.clone(); g2.rotateY(Math.PI / 2);
    const shrubGeo = mergeGeometries([g1, g2]);
    const n = 160;
    const im = new THREE.InstancedMesh(shrubGeo, mat, n);
    for (let i = 0; i < n; i++) {
      const a = rnd() * Math.PI * 2, r = 85 + rnd() * 120;
      const s = 0.6 + rnd() * 1.2;
      m4.compose(new THREE.Vector3(Math.cos(a) * r, 0, Math.sin(a) * r - 30), q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rnd() * 6), new THREE.Vector3(s, s, s));
      im.setMatrixAt(i, m4);
    }
    root.add(im);
  }

  // ---------------- runtime behaviour ----------------
  let time = 0;
  const tmpV = new THREE.Vector3();
  function update(dt) {
    time += dt;
    // paper targets: fall → wait → rise
    for (const t of targets) {
      if (t.state === 'falling') {
        t.angle = Math.min(Math.PI / 2 - 0.05, t.angle + dt * 6);
        if (t.angle >= Math.PI / 2 - 0.05) { t.state = 'down'; t.timer = 2.5; }
      } else if (t.state === 'down') {
        t.timer -= dt; if (t.timer <= 0) t.state = 'rising';
      } else if (t.state === 'rising') {
        t.angle = Math.max(0, t.angle - dt * 2.5);
        if (t.angle <= 0) { t.state = 'up'; t.hp = t.maxHp; t.enabled = true; }
      }
      t.object3D.rotation.x = -t.angle;
    }
    // swinging plates (damped spring)
    for (const p of plates) {
      p.swingVel += (-p.swing * 60 - p.swingVel * 3.2) * dt;
      p.swing += p.swingVel * dt;
      p.hinge.rotation.x = p.swing;
    }
    // mover: ping-pong along the rail
    mover.position.x = -2 + Math.sin(time * 0.45) * 13;
    void tmpV;
  }

  // Called by the weapon system when a target is hit
  function onTargetHit(target, hit, damage, dir) {
    if (target.kind === 'paper') {
      if (target.state !== 'up') return { killed: false };
      target.hp -= damage;
      if (target.hp <= 0) { target.state = 'falling'; target.enabled = false; return { killed: true }; }
      return { killed: false };
    }
    if (target.kind === 'plate') {
      target.swingVel += -Math.sign(dir.z || 1) * Math.min(14, damage * 0.12) * (dir.z < 0 ? 1 : -1);
      return { killed: false, ring: true };
    }
    if (target.kind === 'mover') return { killed: false, ring: true };
    return { killed: false };
  }

  const spawn = { position: new THREE.Vector3(0, 0, 18), yaw: 0 };

  // sun shadow camera bounds follow the player (see main), but provide defaults
  void sun;

  function dispose() {
    scene.remove(root);
    root.traverse((o) => {
      if (o.geometry) o.geometry.dispose();
    });
    for (const d of disposables) {
      if (d.dispose) d.dispose();
      if (d.map) d.map.dispose?.();
    }
    for (const t of [slabTex, wallTex, darkTex, wear]) Object.values(t).forEach((x) => x.dispose?.());
    faceTex.dispose();
  }

  return { root, spawn, update, dispose, onTargetHit, targets, plates, mover: moverTarget, info: MAP_INFO };
}
