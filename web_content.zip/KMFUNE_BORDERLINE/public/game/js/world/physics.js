// =====================================================================
// Lightweight collision world
// ---------------------------------------------------------------------
//  * Static solids are axis-aligned boxes (AABBs). The test range is
//    deliberately built from boxes so movement collision is exact, cheap
//    and robust (no tunnelling, no getting stuck on triangle seams).
//  * The player is a vertical capsule approximated as a cylinder for the
//    horizontal sweep plus exact vertical resolution (ground / ceiling).
//  * Shooting uses an analytic ray-vs-AABB slab test against colliders
//    plus registered "hit targets" (also AABBs in their local space, with
//    an optional transform for rotating targets). Each shot returns ONE
//    nearest hit → one impact event (no duplicate callbacks).
//  * Floor is the infinite plane y = 0.
// =====================================================================
import * as THREE from 'three';

export class PhysicsWorld {
  constructor() {
    this.boxes = [];       // { min: Vector3, max: Vector3, material, userData }
    this.targets = [];     // { object3D, box: Box3 (local), material, onHit(hit), enabled }
    this.groundY = 0;
    this._tmpBox = new THREE.Box3();
    this._inv = new THREE.Matrix4();
    this._ro = new THREE.Vector3();
    this._rd = new THREE.Vector3();
    this._n = new THREE.Vector3();
  }

  addBox(min, max, material = 'concrete', userData = null) {
    const b = { min: min.clone(), max: max.clone(), material, userData };
    this.boxes.push(b);
    return b;
  }

  /** Register a box from a center + size. */
  addBoxCS(cx, cy, cz, sx, sy, sz, material = 'concrete', userData = null) {
    return this.addBox(new THREE.Vector3(cx - sx / 2, cy - sy / 2, cz - sz / 2), new THREE.Vector3(cx + sx / 2, cy + sy / 2, cz + sz / 2), material, userData);
  }

  addTarget(t) { this.targets.push(t); return t; }

  // ------------------------------------------------------------------
  // Character movement: move a cylinder (radius r, from feetY to feetY+h)
  // by delta, resolving collisions. Returns flags.
  // ------------------------------------------------------------------
  moveCharacter(pos, delta, radius, height, stepHeight = 0.35) {
    const res = { grounded: false, hitCeiling: false, hitWall: false };

    // Sub-step to avoid tunnelling at high speed (slide, falls).
    const maxStep = radius * 0.5;
    const len = Math.max(Math.abs(delta.x), Math.abs(delta.z), Math.abs(delta.y));
    const steps = Math.max(1, Math.ceil(len / maxStep));
    const sx = delta.x / steps, sy = delta.y / steps, sz = delta.z / steps;

    for (let s = 0; s < steps; s++) {
      // ---- vertical ----
      pos.y += sy;
      if (pos.y <= this.groundY) { pos.y = this.groundY; if (sy <= 0) res.grounded = true; }
      for (const b of this.boxes) {
        if (!this._overlapXZ(pos, radius, b)) continue;
        const top = pos.y + height;
        if (pos.y < b.max.y && top > b.min.y) {
          if (sy <= 0 && pos.y >= b.max.y - Math.max(0.05, -sy + 0.05)) { pos.y = b.max.y; res.grounded = true; }
          else if (sy > 0 && top <= b.min.y + sy + 0.05) { pos.y = b.min.y - height; res.hitCeiling = true; }
        }
      }

      // ---- horizontal (X then Z, with automatic step-up) ----
      for (const axis of ['x', 'z']) {
        const d = axis === 'x' ? sx : sz;
        if (d === 0) continue;
        pos[axis] += d;
        for (const b of this.boxes) {
          if (!this._overlapXZ(pos, radius, b)) continue;
          if (pos.y >= b.max.y - 1e-4 || pos.y + height <= b.min.y) continue;
          // step up small ledges if grounded-ish
          const stepUp = b.max.y - pos.y;
          if (stepUp > 0 && stepUp <= stepHeight && this._spaceFree(pos, radius, height, b.max.y)) {
            pos.y = b.max.y; res.grounded = true; continue;
          }
          // push out along this axis using closest-point on box to circle centre
          this._pushOut(pos, radius, b, axis);
          res.hitWall = true;
        }
      }
    }
    // final ground probe (stay glued when walking off tiny ledges)
    if (!res.grounded) res.grounded = this.groundProbe(pos, radius, 0.03) !== null;
    return res;
  }

  _overlapXZ(pos, r, b) {
    const cx = Math.max(b.min.x, Math.min(pos.x, b.max.x));
    const cz = Math.max(b.min.z, Math.min(pos.z, b.max.z));
    const dx = pos.x - cx, dz = pos.z - cz;
    return dx * dx + dz * dz < r * r - 1e-6;
  }

  _pushOut(pos, r, b, axis) {
    const cx = Math.max(b.min.x, Math.min(pos.x, b.max.x));
    const cz = Math.max(b.min.z, Math.min(pos.z, b.max.z));
    let dx = pos.x - cx, dz = pos.z - cz;
    const dist = Math.hypot(dx, dz);
    if (dist > 1e-5) {
      const push = r - dist;
      pos.x += (dx / dist) * push; pos.z += (dz / dist) * push;
    } else {
      // centre inside box: push out along the moving axis to nearest face
      if (axis === 'x') {
        const l = pos.x - b.min.x, rr = b.max.x - pos.x;
        pos.x = l < rr ? b.min.x - r : b.max.x + r;
      } else {
        const l = pos.z - b.min.z, rr = b.max.z - pos.z;
        pos.z = l < rr ? b.min.z - r : b.max.z + r;
      }
    }
  }

  _spaceFree(pos, r, h, atY) {
    for (const b of this.boxes) {
      if (!this._overlapXZ(pos, r, b)) continue;
      if (atY < b.max.y - 1e-4 && atY + h > b.min.y) return false;
    }
    return true;
  }

  /** Can a cylinder of height h stand at pos without intersecting? (uncrouch test) */
  fits(pos, r, h) {
    for (const b of this.boxes) {
      if (!this._overlapXZ(pos, r, b)) continue;
      if (pos.y + 0.01 < b.max.y && pos.y + h > b.min.y) return false;
    }
    return true;
  }

  /** Highest support surface within `maxDist` below feet, or null */
  groundProbe(pos, r, maxDist) {
    if (pos.y - this.groundY <= maxDist) return this.groundY;
    let best = null;
    for (const b of this.boxes) {
      if (!this._overlapXZ(pos, r * 0.9, b)) continue;
      const gap = pos.y - b.max.y;
      if (gap >= -0.001 && gap <= maxDist && (best === null || b.max.y > best)) best = b.max.y;
    }
    return best;
  }

  // ------------------------------------------------------------------
  // Raycasting (hitscan)
  // ------------------------------------------------------------------
  static rayAABB(ro, rd, min, max, outNormal) {
    let tmin = -Infinity, tmax = Infinity, axisHit = -1, signHit = 0;
    for (let i = 0; i < 3; i++) {
      const o = i === 0 ? ro.x : i === 1 ? ro.y : ro.z;
      const d = i === 0 ? rd.x : i === 1 ? rd.y : rd.z;
      const mn = i === 0 ? min.x : i === 1 ? min.y : min.z;
      const mx = i === 0 ? max.x : i === 1 ? max.y : max.z;
      if (Math.abs(d) < 1e-9) { if (o < mn || o > mx) return -1; continue; }
      let t1 = (mn - o) / d, t2 = (mx - o) / d, s = -1;
      if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; s = 1; }
      if (t1 > tmin) { tmin = t1; axisHit = i; signHit = s; }
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return -1;
    }
    if (tmax < 0) return -1;
    if (tmin < 0) return -1; // origin inside box: ignore (prevents back-face holes)
    if (outNormal) {
      outNormal.set(0, 0, 0);
      if (axisHit === 0) outNormal.x = signHit; else if (axisHit === 1) outNormal.y = signHit; else outNormal.z = signHit;
    }
    return tmin;
  }

  /**
   * Nearest hit along a ray. Returns {point, normal, distance, material, target, box} or null.
   */
  raycast(origin, dir, maxDist = 1000) {
    let best = null;
    const n = this._n;

    // floor plane
    if (dir.y < -1e-6) {
      const t = (this.groundY - origin.y) / dir.y;
      if (t > 0 && t < maxDist) best = { distance: t, normal: new THREE.Vector3(0, 1, 0), material: 'concrete', target: null, box: null };
    }
    for (const b of this.boxes) {
      const t = PhysicsWorld.rayAABB(origin, dir, b.min, b.max, n);
      if (t >= 0 && t < maxDist && (!best || t < best.distance)) {
        best = { distance: t, normal: n.clone(), material: b.material, target: null, box: b };
      }
    }
    // targets: local-space AABBs transformed by their object's world matrix
    for (const tg of this.targets) {
      if (!tg.enabled) continue;
      tg.object3D.updateWorldMatrix(true, false);
      this._inv.copy(tg.object3D.matrixWorld).invert();
      const lo = this._ro.copy(origin).applyMatrix4(this._inv);
      const ld = this._rd.copy(dir).transformDirection(this._inv);
      // scale factor between local and world distance
      const scale = new THREE.Vector3().copy(dir).transformDirection(this._inv).length();
      const ldn = ld; // transformDirection already normalises
      const t = PhysicsWorld.rayAABB(lo, ldn, tg.box.min, tg.box.max, n);
      if (t < 0) continue;
      // convert local t to world distance
      const lp = lo.clone().addScaledVector(ldn, t);
      const wp = lp.applyMatrix4(tg.object3D.matrixWorld);
      const wd = wp.distanceTo(origin);
      if (wd < maxDist && (!best || wd < best.distance)) {
        const wn = n.clone().transformDirection(tg.object3D.matrixWorld);
        best = { distance: wd, normal: wn, material: tg.material, target: tg, box: null, localPoint: lo.clone().addScaledVector(ldn, t) };
      }
      void scale;
    }
    if (best) best.point = origin.clone().addScaledVector(dir, best.distance);
    return best;
  }
}
