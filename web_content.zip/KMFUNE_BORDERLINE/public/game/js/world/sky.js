// =====================================================================
// Stylised sky dome
// Analytic gradient + sun disc/halo + procedural painted cumulus clouds
// with posterised lighting and ink rims. Also a distant ring of painted
// mesas for a readable horizon. Rendered without depth write, follows camera.
// =====================================================================
import * as THREE from 'three';
import { mesaStripTexture } from '../render/textures.js';

export const SUN_DIR = new THREE.Vector3(-0.45, 0.62, -0.64).normalize();

export function createSky() {
  const group = new THREE.Group();
  group.name = 'sky';

  const uniforms = {
    sunDir: { value: SUN_DIR.clone() },
    zenith: { value: new THREE.Color(0x2a6fd6) },
    horizon: { value: new THREE.Color(0xbfe0f2) },
    ground: { value: new THREE.Color(0xc9b48e) },
    sunColor: { value: new THREE.Color(1.0, 0.93, 0.78) },
    time: { value: 0 },
    cloudCover: { value: 0.52 },
  };

  const mat = new THREE.ShaderMaterial({
    uniforms,
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    vertexShader: /* glsl */`
      varying vec3 vDir;
      void main() {
        vDir = normalize( position );
        vec4 p = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
        gl_Position = p.xyww;   // pin to far plane
      }`,
    fragmentShader: /* glsl */`
      uniform vec3 sunDir, zenith, horizon, ground, sunColor;
      uniform float time, cloudCover;
      varying vec3 vDir;

      float hash( vec2 p ) { p = fract( p * vec2( 123.34, 456.21 ) ); p += dot( p, p + 45.32 ); return fract( p.x * p.y ); }
      float noise( vec2 p ) {
        vec2 i = floor( p ), f = fract( p );
        vec2 u = f * f * ( 3.0 - 2.0 * f );
        return mix( mix( hash( i ), hash( i + vec2( 1, 0 ) ), u.x ), mix( hash( i + vec2( 0, 1 ) ), hash( i + vec2( 1, 1 ) ), u.x ), u.y );
      }
      float fbm( vec2 p ) {
        float v = 0.0, a = 0.5;
        for ( int i = 0; i < 5; i++ ) { v += a * noise( p ); p = p * 2.03 + vec2( 17.1, 9.2 ); a *= 0.5; }
        return v;
      }

      void main() {
        vec3 d = normalize( vDir );
        float h = d.y;
        // sky gradient (slightly banded for an illustrated look)
        float t = pow( clamp( h, 0.0, 1.0 ), 0.55 );
        t = floor( t * 14.0 ) / 14.0 * 0.35 + t * 0.65;
        vec3 col = mix( horizon, zenith, t );
        // ground below horizon (hidden by floor, but avoids a seam)
        col = mix( col, ground, smoothstep( 0.0, -0.06, h ) );

        // sun
        float sd = max( dot( d, sunDir ), 0.0 );
        col += sunColor * pow( sd, 9.0 ) * 0.35;
        col += sunColor * pow( sd, 90.0 ) * 0.9;
        float disc = smoothstep( 0.9993, 0.9996, sd );
        col = mix( col, vec3( 1.0, 0.98, 0.9 ) * 6.0, disc );

        // painted clouds on a virtual plane
        if ( h > 0.0 ) {
          vec2 uv = d.xz / ( h + 0.12 ) * 1.35;
          uv += vec2( time * 0.004, time * 0.0015 );
          float n = fbm( uv * 0.9 );
          float n2 = fbm( uv * 2.7 + 3.0 );
          float density = smoothstep( 1.0 - cloudCover, 1.0 - cloudCover + 0.18, n * 0.78 + n2 * 0.32 );
          // lighting: offset sample toward the sun, posterised into 3 tones
          vec2 toSun = normalize( sunDir.xz + 1e-4 ) * 0.09;
          float nl = fbm( ( uv + toSun ) * 0.9 ) * 0.78 + fbm( ( uv + toSun ) * 2.7 + 3.0 ) * 0.32;
          float lit = clamp( ( n * 0.78 + n2 * 0.32 ) - nl + 0.55, 0.0, 1.0 );
          lit = lit > 0.62 ? 1.0 : ( lit > 0.42 ? 0.78 : 0.58 );
          vec3 cloudLit = vec3( 1.0, 0.985, 0.95 ) * 1.25;
          vec3 cloudShadow = mix( vec3( 0.55, 0.62, 0.78 ), horizon, 0.25 );
          vec3 cc = mix( cloudShadow, cloudLit, lit );
          // ink rim on the cloud silhouette
          float edge = smoothstep( 0.0, 0.08, density ) - smoothstep( 0.08, 0.2, density );
          float fadeH = smoothstep( 0.015, 0.2, h );
          col = mix( col, cc, density * fadeH * 0.96 );
          col = mix( col, col * 0.62, edge * fadeH * 0.55 );
        }
        // horizon haze
        col = mix( col, horizon * 1.05, smoothstep( 0.18, 0.0, abs( h ) ) * 0.55 );
        gl_FragColor = vec4( col, 1.0 );
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  });
  // tone mapping/colour space are applied by the OutputPass in the composer;
  // the includes above only take effect when rendering directly to screen.
  mat.toneMapped = true;

  const dome = new THREE.Mesh(new THREE.SphereGeometry(4000, 48, 24), mat);
  dome.frustumCulled = false;
  dome.renderOrder = -10;
  group.add(dome);

  // distant mesa ring (painted silhouettes)
  const mesaTex = mesaStripTexture();
  mesaTex.repeat.set(3, 1);
  const mesaMat = new THREE.MeshBasicMaterial({ map: mesaTex, transparent: true, alphaTest: 0.5, fog: false, color: 0xe8dcc8, depthWrite: false, side: THREE.BackSide });
  const ring = new THREE.Mesh(new THREE.CylinderGeometry(2400, 2400, 360, 64, 1, true), mesaMat);
  ring.position.y = 130;
  ring.renderOrder = -9;
  ring.frustumCulled = false;
  group.add(ring);

  return { group, uniforms, dome, ring, mesaMat };
}
