// =====================================================================
// GunsmithUI — Armory (weapon selection) + Gunsmith (attachments)
// ---------------------------------------------------------------------
// Layout follows the reference (ECC: Redline, see README §Reference):
//   top-left   red-marked screen title + category tabs (red = active)
//   left       list cards (weapons, or attachments of the focused slot)
//   left-mid   stat panel: name, level line, six bars with green/red
//              live deltas while hovering, raw readouts (RPM, sight
//              magnification, magazine, fire mode, ADS time, reload),
//              attachment icon grid, description
//   bottom-rt  primary / secondary action buttons with key hints
//   bottom     slot bar (gunsmith) + key-hint footer
// The 3D preview is a studio-lit WeaponPreviewController; selecting a
// slot eases the camera to that mount point. Hovering an attachment
// previews it on the model AND in the stats before it's installed.
// States: 'select' (armory) → 'modify' (gunsmith) → slot → 'inspect'.
// =====================================================================
import { settings } from '../core/settings.js';
import { audio } from '../audio/audio.js';
import { CATEGORIES, WeaponRegistry, ALL_WEAPONS } from '../weapons/registry.js';
import { ATTACHMENTS, SLOT_ORDER, SLOT_LABELS } from '../weapons/attachments.js';
import { AttachmentCompatibility, WeaponStatistics, LoadoutManager, WeaponConfiguration } from '../weapons/gunsmith.js';
import { fireModeLabel } from '../weapons/definitions.js';
import { WeaponPreviewController } from './preview.js';

const $ = (id) => document.getElementById(id);
const STAT_ROWS = [['damage', 'DAMAGE'], ['range', 'RANGE'], ['control', 'RECOIL CONTROL'], ['accuracy', 'HIP-FIRE ACCURACY'], ['mobility', 'MOBILITY'], ['rof', 'FIRE RATE']];
const SLOT_ICON = { optic: '◎', muzzle: '▭', barrel: '═', underbarrel: '┴', laser: '✦', magazine: '▮', stock: '◢', grip: '◣' };

export class GunsmithUI {
  constructor(menus) {
    this.menus = menus;
    this.preview = new WeaponPreviewController();
    this.preview.bind($('gs-preview'));
    this.mode = 'select';
    this.slot = 'primary';                 // loadout slot being edited
    this.cat = 'ar';
    this.weaponId = 'fn2000';
    this.attSlot = null;                   // gunsmith slot being edited
    this.hoverCfg = null;
    this.inspectT = -1;
    this.pending = { ...settings.loadout };
    document.querySelectorAll('#gs-modetabs button').forEach((b) => b.addEventListener('click', () => { audio.ui('ui_switch'); this.setMode(b.dataset.gsMode); }));
    $('gs-btn-main').addEventListener('click', () => this.primaryAction());
    $('gs-btn-alt').addEventListener('click', () => this.altAction());
    window.addEventListener('keydown', (e) => this.onKey(e));
  }

  get active() { return this.menus.current === 'loadout-screen'; }

  open() {
    this.pending = { ...settings.loadout };
    this.weaponId = this.pending[this.slot];
    this.cat = WeaponRegistry.get(this.weaponId).cat;
    this.mode = 'select'; this.attSlot = null; this.hoverCfg = null;
    this.render();
  }

  // ---------------- state ----------------
  cfg() { return LoadoutManager.config(this.weaponId); }
  setMode(m) {
    this.mode = m; this.attSlot = null; this.hoverCfg = null;
    this.preview.focusSlot(null);
    this.render();
  }
  setWeapon(id) {
    if (this.weaponId === id) return;
    this.weaponId = id; this.hoverCfg = null; this.attSlot = null;
    this.preview.auto = true;
    this.render();
  }
  setSlot(slot) { // loadout slot primary/secondary
    this.slot = slot;
    this.weaponId = this.pending[slot];
    this.cat = WeaponRegistry.get(this.weaponId).cat;
    this.render();
  }

  primaryAction() {
    if (this.mode === 'select') {
      // EQUIP into the current loadout slot (swap if already in the other)
      const other = this.slot === 'primary' ? 'secondary' : 'primary';
      if (this.pending[other] === this.weaponId) this.pending[other] = this.pending[this.slot];
      this.pending[this.slot] = this.weaponId;
      settings.data.loadout.primary = this.pending.primary; settings.data.loadout.secondary = this.pending.secondary; settings.save();
      audio.ui('ui_confirm');
      this.flash(`${WeaponRegistry.get(this.weaponId).name} equipped as ${this.slot.toUpperCase()}`);
      this.menus.game.applyLoadout();
      this.render();
    } else if (this.attSlot && this.hoverAtt !== undefined) {
      this.install(this.attSlot, this.hoverAtt);
    }
  }
  altAction() {
    if (this.mode === 'select') this.setMode('modify');
    else this.startInspect();
  }

  install(slot, attId) {
    const cfg = this.cfg();
    if (!attId && AttachmentCompatibility.lockReason(cfg.def, slot)) { audio.ui('ui_back'); this.flash(AttachmentCompatibility.lockReason(cfg.def, slot)); return; }
    const next = cfg.with(slot, attId);
    LoadoutManager.store(next);
    audio.play('mag_seat', { cat: 'interface', volume: 0.5, rate: 1.3 });
    this.hoverCfg = null;
    this.flash(attId ? `${ATTACHMENTS[attId].name} installed` : `${SLOT_LABELS[slot]} cleared`);
    // live-apply to the in-game loadout if this weapon is equipped
    if (Object.values(settings.loadout).includes(this.weaponId)) this.menus.game.applyLoadout();
    this.render();
  }
  stripAll() {
    const cfg = this.cfg();
    let next = new WeaponConfiguration(cfg.weaponId, {});
    for (const s of SLOT_ORDER) if (!next.att[s]) next = next.with(s, null);
    LoadoutManager.store(next);
    if (Object.values(settings.loadout).includes(this.weaponId)) this.menus.game.applyLoadout();
    audio.ui('ui_back'); this.flash('All removable attachments removed');
    this.render();
  }
  startInspect() { this.inspectT = 0; this.preview.auto = false; this.preview.focusSlot(null); audio.cue('cloth'); }

  flash(msg) {
    const n = $('gs-note'); n.textContent = msg; n.classList.add('show');
    clearTimeout(this._noteT); this._noteT = setTimeout(() => n.classList.remove('show'), 2200);
  }

  onKey(e) {
    if (!this.active || this.menus.game.input.captureNext) return;
    if (e.code === 'Space') { e.preventDefault(); this.primaryAction(); }
    else if (e.code === 'KeyF') this.altAction();
    else if (e.code === 'KeyB') this.startInspect();
    else if (e.code === 'KeyZ' && this.mode === 'modify') this.stripAll();
    else if (e.code === 'KeyR') { this.preview.auto = true; this.preview.tPitch = 0.08; this.preview.focusSlot(this.attSlot); }
    else if (e.code === 'Digit1') this.setSlot('primary');
    else if (e.code === 'Digit2') this.setSlot('secondary');
  }

  // ---------------- rendering ----------------
  render() {
    const cfg = this.cfg(), def = cfg.def;
    $('gs-title-text').textContent = this.mode === 'select' ? (this.slot === 'primary' ? 'PRIMARY WEAPON' : 'SECONDARY WEAPON') : 'GUNSMITH';
    document.querySelectorAll('#gs-modetabs button').forEach((b) => b.classList.toggle('active', b.dataset.gsMode === this.mode));
    this.renderCats();
    this.renderList(cfg);
    this.renderStats(cfg, this.hoverCfg);
    this.renderSlotbar(cfg);
    this.renderLoadoutStrip();
    $('gs-weapon-name').innerHTML = `${def.name}<small>${def.category}</small>`;
    $('gs-btn-main').querySelector('span').textContent = this.mode === 'select' ? 'EQUIP' : 'INSTALL';
    $('gs-btn-alt').querySelector('span').textContent = this.mode === 'select' ? 'MODIFY' : 'INSPECT';
    $('gs-btn-main').disabled = this.mode === 'modify' && !this.attSlot;
    $('gs-btn-alt').disabled = this.mode === 'select' && !AttachmentCompatibility.slotsFor(def).length;
    this.preview.show(this.hoverCfg || cfg);
  }

  renderCats() {
    const el = $('gs-cats');
    el.innerHTML = '';
    el.style.display = this.mode === 'select' ? '' : 'none';
    for (const c of WeaponRegistry.categoriesInUse()) {
      const b = document.createElement('button');
      b.textContent = c.label; b.className = c.id === this.cat ? 'active' : '';
      b.addEventListener('click', () => { audio.ui('ui_switch'); this.cat = c.id; const ids = WeaponRegistry.byCategory(c.id); if (!ids.includes(this.weaponId)) this.setWeapon(ids[0]); else this.render(); });
      el.appendChild(b);
    }
  }

  renderList(cfg) {
    const list = $('gs-list');
    list.innerHTML = '';
    if (this.mode === 'select') {
      $('gs-left-head').textContent = CATEGORIES.find((c) => c.id === this.cat)?.label || 'WEAPONS';
      for (const id of WeaponRegistry.byCategory(this.cat)) {
        const d = ALL_WEAPONS[id];
        const card = document.createElement('button');
        card.className = 'gs-card' + (id === this.weaponId ? ' selected' : '');
        const eq = this.pending.primary === id ? 'PRIMARY' : this.pending.secondary === id ? 'SECONDARY' : '';
        card.innerHTML = `<span class="gs-card-name">${d.name}</span><span class="gs-card-sub">${d.category}</span>${eq ? `<span class="gs-tag">${eq}</span>` : ''}<span class="gs-card-ref ${d.ref.status.toLowerCase()}">${d.ref.status}</span>`;
        card.addEventListener('mouseenter', () => audio.ui('ui_hover'));
        card.addEventListener('click', () => { audio.ui('ui_select'); this.setWeapon(id); });
        card.addEventListener('dblclick', () => this.primaryAction());
        list.appendChild(card);
      }
      return;
    }
    // gunsmith: attachments of the selected slot (or prompt)
    if (!this.attSlot) {
      $('gs-left-head').textContent = 'SELECT A SLOT';
      const p = document.createElement('div'); p.className = 'gs-empty';
      p.textContent = AttachmentCompatibility.slotsFor(cfg.def).length ? 'Choose an attachment slot on the weapon (bottom bar). Hover an attachment to preview its effect before installing.' : 'This weapon has fixed furniture and sights — no attachment slots.';
      list.appendChild(p);
      return;
    }
    const slot = this.attSlot;
    $('gs-left-head').textContent = SLOT_LABELS[slot];
    const ids = [null, ...(cfg.def.slots[slot] || [])];
    for (const id of ids) {
      const a = id ? ATTACHMENTS[id] : null;
      const locked = !id && AttachmentCompatibility.lockReason(cfg.def, slot);
      const card = document.createElement('button');
      const installed = (cfg.att[slot] || null) === id;
      card.className = 'gs-card att' + (installed ? ' installed' : '') + (locked ? ' locked' : '');
      card.innerHTML = `<span class="gs-att-icon">${SLOT_ICON[slot]}</span><span class="gs-card-name">${a ? a.name : (slot === 'optic' && cfg.def.meta?.sightType !== 'none' ? 'Iron Sights' : 'Standard / None')}</span>${installed ? '<span class="gs-tag">INSTALLED</span>' : ''}`;
      card.addEventListener('mouseenter', () => {
        audio.ui('ui_hover');
        this.hoverAtt = id;
        this.hoverCfg = locked ? null : cfg.with(slot, id);
        this.renderStats(cfg, this.hoverCfg, a);
        this.preview.show(this.hoverCfg || cfg);
        this.preview.focusSlot(slot);
      });
      card.addEventListener('mouseleave', () => { this.hoverCfg = null; this.renderStats(cfg, null); this.preview.show(cfg); });
      card.addEventListener('click', () => this.install(slot, id));
      list.appendChild(card);
    }
  }

  renderSlotbar(cfg) {
    const bar = $('gs-slotbar');
    bar.innerHTML = '';
    bar.style.display = this.mode === 'modify' ? '' : 'none';
    if (this.mode !== 'modify') return;
    for (const slot of AttachmentCompatibility.slotsFor(cfg.def)) {
      const id = cfg.att[slot];
      const b = document.createElement('button');
      b.className = 'gs-slot' + (slot === this.attSlot ? ' active' : '') + (id ? ' filled' : '');
      b.innerHTML = `<i>${SLOT_ICON[slot]}</i><b>${SLOT_LABELS[slot]}</b><small>${id ? ATTACHMENTS[id].name : '—'}</small>`;
      b.addEventListener('mouseenter', () => audio.ui('ui_hover'));
      b.addEventListener('click', () => { audio.ui('ui_select'); this.attSlot = slot; this.hoverCfg = null; this.preview.focusSlot(slot); this.render(); });
      bar.appendChild(b);
    }
  }

  renderLoadoutStrip() {
    const L = this.pending;
    $('gs-loadout').innerHTML = ['primary', 'secondary'].map((s, i) => {
      const d = WeaponRegistry.get(L[s]);
      return `<button class="gs-ls ${this.slot === s ? 'active' : ''}" data-ls="${s}"><kbd>${i + 1}</kbd><b>${d.name}</b><small>${s.toUpperCase()}</small></button>`;
    }).join('');
    $('gs-loadout').querySelectorAll('[data-ls]').forEach((b) => b.addEventListener('click', () => { audio.ui('ui_select'); this.setSlot(b.dataset.ls); }));
  }

  renderStats(cfg, hover, att) {
    const S = WeaponStatistics.display(cfg);
    const H = hover ? WeaponStatistics.display(hover) : null;
    const def = cfg.def;
    const fmtS = (d) => (Math.abs(d) < 0.005 ? '' : `<em class="${d < 0 ? 'up' : 'down'}">(${d > 0 ? '+' : ''}${d.toFixed(2)}s)</em>`);
    const fmtD = (d, inv = false) => { if (!d) return ''; const good = inv ? d < 0 : d > 0; return `<em class="${good ? 'up' : 'down'}">(${d > 0 ? '+' : ''}${Math.round(d)})</em>`; };
    const bars = STAT_ROWS.map(([k, label]) => {
      const v = S[k], h = H ? H[k] : v, d = h - v;
      const lo = Math.min(v, h), hi = Math.max(v, h);
      return `<div class="gs-stat"><span>${label}</span><b>${Math.round(h)}${k === 'range' ? 'm' : ''} ${fmtD(d)}</b>
        <div class="gs-bar"><i style="width:${lo}%"></i>${d ? `<u class="${d > 0 ? 'up' : 'down'}" style="left:${lo}%;width:${hi - lo}%"></u>` : ''}</div></div>`;
    }).join('');
    const R = H || S;
    const raw = [
      ['FIRE RATE', `${R.rpm} RPM`],
      ['SIGHT', `${R.zoom}×`],
      ['MAGAZINE', `${R.magSize} ${fmtD(H ? H.magSize - S.magSize : 0)}`],
      ['FIRE MODE', def.fireModes.map(fireModeLabel).join(' / ')],
      ['ADS TIME', `${R.adsMs} ms ${fmtD(H ? H.adsMs - S.adsMs : 0, true)}`],
      ['RELOAD', R.reload ? `${R.reload.toFixed(2)} s ${H && S.reload ? fmtS(H.reload - S.reload) : ''}` : 'Shell-by-shell'],
    ].map(([k, v]) => `<div class="gs-raw"><span>${k}</span><b>${v}</b></div>`).join('');
    const icons = AttachmentCompatibility.slotsFor(def).map((s) => `<i class="${cfg.att[s] ? 'on' : ''}" title="${SLOT_LABELS[s]}${cfg.att[s] ? ': ' + ATTACHMENTS[cfg.att[s]].name : ''}">${SLOT_ICON[s]}</i>`).join('');
    const head = att !== undefined && this.mode === 'modify' && this.attSlot
      ? `<div class="gs-att-head"><h4>${att ? att.name : 'Standard'}</h4><p>${att ? att.desc : 'Remove the attachment from this slot.'}</p>${att ? modList(att) : ''}</div>` : '';
    $('gs-stats').innerHTML = `${head}
      <h3>${def.name}</h3><div class="gs-lv">${def.category.toUpperCase()} <span class="gs-ref ${def.ref.status.toLowerCase()}" title="${def.ref.note}">${def.ref.status}${def.ref.time ? ' · ' + def.ref.time : ''}</span></div>
      ${bars}
      <div class="gs-sep"></div>${raw}
      ${icons ? `<div class="gs-icons">${icons}</div>` : ''}
      <p class="gs-blurb">${def.blurb}</p>`;
  }

  // ---------------- per-frame ----------------
  renderFrame(renderer, dt) {
    const el = $('gs-preview');
    const rect = el.getBoundingClientRect();
    // inspection: scripted orbit around the weapon (both sides + close-up)
    if (this.inspectT >= 0) {
      this.inspectT += dt;
      const t = this.inspectT, P = this.preview;
      P.tYaw = -0.35 + Math.sin(t * 0.9) * 1.6; P.tPitch = 0.1 + Math.sin(t * 0.6) * 0.18;
      P.tDist = P.baseDist * (0.7 + 0.25 * Math.cos(t * 0.7));
      if (t > 7) { this.inspectT = -1; P.focusSlot(this.attSlot); }
    }
    this.preview.render(renderer, rect, dt, 0.14);
  }
}

function modList(a) {
  const names = { damage: 'Damage', range: 'Range', control: 'Recoil control', accuracy: 'Accuracy', mobility: 'Mobility', adsTime: 'ADS time', recoilMul: 'Recoil', hipMul: 'Hip spread', magMul: 'Magazine', reloadMul: 'Reload time', flashMul: 'Muzzle flash' };
  const items = Object.entries(a.mods).filter(([k, v]) => names[k] && v !== 0 && v !== 1).map(([k, v]) => {
    let txt, good;
    if (k === 'adsTime') { txt = `${v > 0 ? '+' : ''}${Math.round(v * 1000)} ms`; good = v < 0; }
    else if (k.endsWith('Mul')) { const p = Math.round((v - 1) * 100); txt = `${p > 0 ? '+' : ''}${p}%`; good = k === 'magMul' ? p > 0 : p < 0; }
    else { txt = `${v > 0 ? '+' : ''}${v}`; good = v > 0; }
    return `<li class="${good ? 'up' : 'down'}"><span>${names[k]}</span><b>${txt}</b></li>`;
  });
  if (a.mods.suppressed) items.push('<li class="up"><span>Sound</span><b>Suppressed</b></li>');
  return `<ul class="gs-mods">${items.join('')}</ul>`;
}
