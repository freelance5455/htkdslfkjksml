// =====================================================================
// HUD — crosshair, ammo, rounds strip, weapon slots, vitals, compass,
// hit markers, floating damage numbers (pooled DOM), prompts, scope.
// Reads weapon state through events + per-frame update (no polling of
// DOM layout → no forced reflow in the frame loop).
// =====================================================================
import * as THREE from 'three';
import { bus } from '../core/events.js';
import { fireModeLabel } from '../weapons/definitions.js';
import { settings, prettyKey } from '../core/settings.js';

const $ = (id) => document.getElementById(id);

export class HUD {
  constructor() {
    this.root = $('hud');
    this.ch = $('crosshair');
    this.chParts = { l: this.ch.querySelector('.ch-l'), r: this.ch.querySelector('.ch-r'), t: this.ch.querySelector('.ch-t'), b: this.ch.querySelector('.ch-b') };
    this.hit = $('hitmarker');
    this.scope = $('scope-overlay');
    this.mag = $('ammo-mag'); this.reserve = $('ammo-reserve');
    this.name = $('hud-weapon-name'); this.mode = $('hud-firemode'); this.slots = $('hud-slots'); this.rounds = $('hud-rounds');
    this.state = $('hud-state'); this.prompt = $('hud-prompt');
    this.dmgLayer = $('damage-layer');
    this.compass = $('compass-strip');
    this.hitT = 0;
    this.lastHud = null;
    this.dmgPool = [];
    for (let i = 0; i < 24; i++) {
      const d = document.createElement('div'); d.className = 'dmg-num'; d.style.display = 'none';
      this.dmgLayer.appendChild(d);
      this.dmgPool.push({ el: d, alive: false, pos: new THREE.Vector3(), t: 0, vx: 0 });
    }
    this.buildCompass();
    bus.on('weapon:changed', (s) => this.setWeapon(s));
    bus.on('weapon:fired', (s) => this.setAmmo(s));
    bus.on('weapon:ammo', (s) => this.setAmmo(s));
    bus.on('weapon:hit', (h) => this.onHit(h));
  }

  show(v) { this.root.classList.toggle('hidden', !v); }

  buildCompass() {
    const labels = { 0: 'N', 45: 'NE', 90: 'E', 135: 'SE', 180: 'S', 225: 'SW', 270: 'W', 315: 'NW' };
    let html = '';
    for (let rep = 0; rep < 3; rep++) for (let d = 0; d < 360; d += 15) {
      const l = labels[d];
      html += l ? `<span class="major">${l}</span>` : `<span>${d % 45 === 0 ? '' : '·'}</span>`;
    }
    this.compass.innerHTML = html;
  }

  setWeapon(s) {
    if (!s) return;
    this.name.textContent = s.name;
    this.mode.textContent = fireModeLabel(s.fireMode);
    this.slots.innerHTML = s.slots.map((x, i) => `<span class="hud-slot${x.active ? ' active' : ''}">${i + 1} · ${x.name}</span>`).join('');
    this.rounds.innerHTML = '<i></i>'.repeat(s.magSize);
    this.setAmmo(s);
  }

  setAmmo(s) {
    if (!s) return;
    this.lastHud = s;
    this.mag.textContent = s.mag;
    this.reserve.textContent = s.reserve;
    this.mag.classList.toggle('low', s.mag > 0 && s.mag <= Math.ceil(s.magSize * 0.25));
    this.mag.classList.toggle('empty', s.mag === 0);
    const kids = this.rounds.children;
    if (kids.length !== s.magSize) this.rounds.innerHTML = '<i></i>'.repeat(s.magSize);
    for (let i = 0; i < kids.length; i++) kids[i].classList.toggle('spent', i >= s.mag);
  }

  onHit({ point, damage, crit, killed }) {
    this.hitT = 0.18;
    this.hit.classList.toggle('crit', !!crit || killed);
    const d = this.dmgPool.find((x) => !x.alive) || this.dmgPool[0];
    d.alive = true; d.t = 0; d.pos.copy(point); d.vx = (Math.random() - 0.5) * 60;
    d.el.textContent = (crit ? 'CRIT! ' : '') + damage + (killed ? ' ✖' : '');
    d.el.className = 'dmg-num' + (crit || killed ? ' crit' : '');
    d.el.style.display = 'block';
  }

  update(dt, { camera, weapons, player, renderer }) {
    // crosshair: gap from the actual spread cone projected to pixels
    const s = weapons.current ? weapons.crosshairSpread : 0;
    const h = renderer.height;
    const px = Math.tan(s) / Math.tan((camera.fov * Math.PI) / 360) * (h / 2);
    const gap = 6 + px;
    const p = this.chParts;
    p.l.style.transform = `translate(${-gap - 10}px,0)`; p.r.style.transform = `translate(${gap}px,0)`;
    p.t.style.transform = `translate(0,${-gap - 10}px)`; p.b.style.transform = `translate(0,${gap}px)`;
    const ads = weapons.adsBlend;
    const hideCh = weapons.scoped || ads > 0.6 || weapons.sprintBlend > 0.5 || weapons.state === 'inspecting';
    this.ch.style.opacity = hideCh ? '0' : '1';
    this.scope.style.opacity = '0'; // legacy full-screen mask retired: scopes use in-lens PiP

    // hit marker
    this.hitT = Math.max(0, this.hitT - dt);
    this.hit.style.opacity = this.hitT > 0 ? String(Math.min(1, this.hitT * 8)) : '0';

    // damage numbers (projected each frame)
    const W = renderer.width, H = renderer.height;
    const v = new THREE.Vector3();
    for (const d of this.dmgPool) {
      if (!d.alive) continue;
      d.t += dt;
      if (d.t > 1.1) { d.alive = false; d.el.style.display = 'none'; continue; }
      v.copy(d.pos).project(camera);
      if (v.z > 1) { d.el.style.display = 'none'; continue; }
      d.el.style.display = 'block';
      const x = (v.x * 0.5 + 0.5) * W + d.vx * d.t, y = (-v.y * 0.5 + 0.5) * H - 70 * d.t + 120 * d.t * d.t - 20;
      const sc = d.t < 0.1 ? 0.6 + d.t * 6 : 1.2 - Math.min(0.3, (d.t - 0.1) * 0.4);
      d.el.style.transform = `translate(${x}px,${y}px) translate(-50%,-50%) scale(${sc.toFixed(3)}) rotate(-6deg)`;
      d.el.style.opacity = String(Math.min(1, (1.1 - d.t) * 3));
    }

    // compass
    let deg = ((-player.yaw * 180) / Math.PI) % 360; if (deg < 0) deg += 360;
    this.compass.style.transform = `translateX(${210 - (360 + deg) / 15 * 30 - 15}px)`;

    // state + prompts
    const st = { idle: 'STANDING', walk: 'WALKING', sprint: 'SPRINTING', crouch: 'CROUCHED', crouchwalk: 'CROUCH-WALK', slide: 'SLIDING', air: 'AIRBORNE' }[player.state] || '';
    if (this.state.textContent !== st) this.state.textContent = st;
    const hud = this.lastHud;
    let prompt = '';
    if (hud) {
      if (weapons.state === 'reloading') prompt = 'RELOADING…';
      else if (hud.mag === 0 && hud.reserve === 0) prompt = 'NO AMMO — PRESS [T] TO RESUPPLY';
      else if (hud.mag === 0) prompt = `[${prettyKey(settings.controls.bindings.reload)}] RELOAD`;
      else if (hud.mag <= Math.ceil(hud.magSize * 0.25)) prompt = `LOW AMMO — [${prettyKey(settings.controls.bindings.reload)}]`;
      else if (hud.needsCycle && !weapons.manual) prompt = 'CHAMBER: CLICK';
    }
    if (this.prompt.textContent !== prompt) this.prompt.textContent = prompt;
    this.prompt.classList.toggle('hidden', !prompt);
  }
}
