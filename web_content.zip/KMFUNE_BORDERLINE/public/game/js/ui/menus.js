// =====================================================================
// Menus: main / loadout (with live 3D preview) / settings / controls /
// credits / pause. Every button is wired to a real action.
// =====================================================================
import { settings, PRESETS, ACTION_LABELS, DEFAULT_BINDINGS, prettyKey, DEFAULTS } from '../core/settings.js';
import { WeaponRegistry } from '../weapons/registry.js';
import { LoadoutManager } from '../weapons/gunsmith.js';
import { GunsmithUI } from './gunsmith.js';
import { WeaponPreviewController } from './preview.js';
import { audio } from '../audio/audio.js';

const $ = (id) => document.getElementById(id);
const SCREENS = ['main-menu', 'loadout-screen', 'settings-screen', 'controls-screen', 'credits-screen', 'pause-screen'];

export class Menus {
  constructor(game) {
    this.game = game;
    this.stack = [];
    this.current = null;
    this.settingsTab = 'graphics';

    document.querySelectorAll('[data-action]').forEach((b) => {
      b.addEventListener('click', () => { audio.ui('ui_click'); this.action(b.dataset.action); });
      b.addEventListener('mouseenter', () => audio.ui('ui_hover'));
    });
    document.querySelectorAll('#settings-tabs .tab').forEach((t) => t.addEventListener('click', () => { audio.ui('ui_switch'); this.settingsTab = t.dataset.tab; this.renderSettings(); }));
    this.gunsmith = new GunsmithUI(this);
    this.menuPreview = new WeaponPreviewController();
    this.menuPreview.yaw = this.menuPreview.tYaw = -0.5;
  }

  // ---------------- navigation ----------------
  show(id, push = true) {
    if (push && this.current && this.current !== id) this.stack.push(this.current);
    for (const s of SCREENS) $(s).classList.toggle('active', s === id);
    this.current = id;
    if (id === 'loadout-screen') this.gunsmith.open();
    if (id === 'settings-screen') this.renderSettings();
    if (id === 'controls-screen') this.renderControls();
    if (id === 'main-menu') this.renderMainSummary();
    this.previewActive = id === 'loadout-screen' || id === 'main-menu';
  }
  hideAll() { for (const s of SCREENS) $(s).classList.remove('active'); this.current = null; this.stack = []; this.previewActive = false; }
  back() {
    const prev = this.stack.pop();
    if (prev) this.show(prev, false);
    else if (this.game.inSession) this.game.resume();
    else this.show('main-menu', false);
  }
  get open() { return !!this.current; }

  action(a) {
    switch (a) {
      case 'play': this.game.startSession(); break;
      case 'resume': this.game.resume(); break;
      case 'loadout': this.show('loadout-screen'); break;
      case 'settings': this.show('settings-screen'); break;
      case 'controls': this.show('controls-screen'); break;
      case 'credits': this.show('credits-screen'); break;
      case 'mainmenu': this.game.endSession(); break;
      case 'back': this.back(); break;
      case 'deploy': this.deploy(); break;
      case 'reset-tab': this.resetTab(); break;
    }
  }

  renderMainSummary() {
    const l = settings.loadout;
    const line = (i, id) => { const d = WeaponRegistry.get(id); const n = Object.values(LoadoutManager.config(id).att).filter(Boolean).length; return `<div class="ml-row"><kbd>${i}</kbd><b>${d.name}</b><small>${d.category}${n ? ' · ' + n + ' attachment' + (n > 1 ? 's' : '') : ''}</small></div>`; };
    $('menu-loadout-summary').innerHTML = `<h4>CURRENT LOADOUT</h4>${line(1, l.primary)}${line(2, l.secondary)}`;
    $('btn-resume-main').hidden = !this.game.inSession;
    this.menuPreview.show(LoadoutManager.config(l.primary));
    this.menuPreview.auto = true;
  }

  deploy() {
    const L = settings.loadout;
    if (!L.primary || !L.secondary || L.primary === L.secondary) return;
    audio.ui('ui_confirm');
    this.game.applyLoadout();
    this.game.startSession();
  }

  /** Per-frame 3D previews (main-menu showcase / gunsmith studio). */
  renderPreview(renderer, dt) {
    if (this.current === 'loadout-screen') this.gunsmith.renderFrame(renderer, dt);
    else if (this.current === 'main-menu') this.menuPreview.render(renderer, $('menu-preview').getBoundingClientRect(), dt, 0.12);
  }

  // ---------------- settings ----------------
  renderSettings() {
    document.querySelectorAll('#settings-tabs .tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === this.settingsTab));
    const body = $('settings-body');
    body.innerHTML = '';
    const g = settings.graphics, c = settings.controls, a = settings.audio;
    const section = (t) => { const d = document.createElement('div'); d.className = 'setting-section'; d.textContent = t; body.appendChild(d); };
    const row = (label, desc, control) => {
      const r = document.createElement('div'); r.className = 'setting-row';
      r.innerHTML = `<label>${label}<span class="desc">${desc || ''}</span></label>`;
      r.appendChild(control); body.appendChild(r); return r;
    };
    const select = (sec, key, opts, after) => {
      const s = document.createElement('select');
      for (const [v, l] of opts) { const o = document.createElement('option'); o.value = v; o.textContent = l; s.appendChild(o); }
      s.value = String(settings.data[sec][key]);
      s.addEventListener('change', () => {
        const raw = s.value; const cur = settings.data[sec][key];
        const val = typeof cur === 'number' ? Number(raw) : typeof cur === 'boolean' ? raw === 'true' : raw;
        settings.set(sec, key, val); audio.ui('ui_switch'); after?.();
      });
      return s;
    };
    const slider = (sec, key, min, max, step, fmt = (v) => v.toFixed(2)) => {
      const w = document.createElement('div'); w.style.display = 'flex'; w.style.alignItems = 'center'; w.style.gap = '8px';
      const i = document.createElement('input'); i.type = 'range'; i.min = min; i.max = max; i.step = step; i.value = settings.data[sec][key];
      const v = document.createElement('span'); v.className = 'val'; v.textContent = fmt(Number(i.value));
      i.addEventListener('input', () => { settings.set(sec, key, Number(i.value)); v.textContent = fmt(Number(i.value)); });
      w.append(i, v); return w;
    };
    const toggle = (sec, key, after) => {
      const i = document.createElement('input'); i.type = 'checkbox'; i.checked = !!settings.data[sec][key];
      i.addEventListener('change', () => { settings.set(sec, key, i.checked); audio.ui('ui_switch'); after?.(); });
      return i;
    };
    const rerender = () => this.renderSettings();

    if (this.settingsTab === 'graphics') {
      section('PRESET');
      const ps = document.createElement('select');
      for (const [v, l] of [['low', 'Low'], ['medium', 'Medium'], ['high', 'High'], ['ultra', 'Ultra'], ['custom', 'Custom']]) { const o = document.createElement('option'); o.value = v; o.textContent = l; ps.appendChild(o); }
      ps.value = g.preset;
      ps.addEventListener('change', () => { if (PRESETS[ps.value]) { settings.applyPreset(ps.value); audio.ui('ui_confirm'); rerender(); } });
      row('Graphics preset', 'Low disables bloom/AO/hatching, lowers resolution & shadows', ps);
      section('RENDERING');
      row('Resolution scale', 'Internal render resolution vs. display', slider('graphics', 'resolutionScale', 0.5, 1.5, 0.05, (v) => Math.round(v * 100) + '%'));
      row('Field of view', 'Horizontal-ish vertical FOV (degrees)', slider('graphics', 'fov', 65, 100, 1, (v) => String(v)));
      row('Anti-aliasing', 'Post AA on the final image', select('graphics', 'antialias', [['none', 'Off'], ['fxaa', 'FXAA'], ['smaa', 'SMAA']]));
      row('Post-processing', 'Off = direct render (no outlines/bloom/AO/grade)', toggle('graphics', 'postProcessing'));
      row('Ink outlines', 'Depth/normal edge ink lines', toggle('graphics', 'outlines'));
      row('Hatching', 'Comic hatching in shadow bands', toggle('graphics', 'hatching'));
      row('Tone mapping', 'HDR → display operator (scene is lit & stored in HDR)', select('graphics', 'toneMapping', [['aces', 'ACES Filmic'], ['agx', 'AgX'], ['neutral', 'Khronos Neutral'], ['linear', 'Linear (clipped)']]));
      row('Exposure', 'Tone-mapping exposure', slider('graphics', 'exposure', 0.5, 2, 0.05));
      section('LIGHTING & EFFECTS');
      row('Shadow quality', 'Shadow map resolution', select('graphics', 'shadowQuality', [[0, 'Off'], [1, 'Low (1024)'], [2, 'High (2048)'], [3, 'Ultra (4096)']]));
      row('Shadow distance', 'Sun shadow coverage radius (m)', slider('graphics', 'shadowDistance', 20, 120, 5, (v) => v + 'm'));
      row('Ambient occlusion', 'GTAO screen-space AO', select('graphics', 'aoQuality', [[0, 'Off'], [1, 'Medium'], [2, 'High']]));
      row('Bloom', 'Glow on HDR highlights (flash, lamps, sun)', toggle('graphics', 'bloom'));
      row('Bloom intensity', '', slider('graphics', 'bloomIntensity', 0, 1.2, 0.05));
      row('Texture quality', 'Procedural texture resolution (applies on restart)', select('graphics', 'textureQuality', [[0, 'Low'], [1, 'Medium'], [2, 'High']]));
      row('Effects quality', 'Particle density', select('graphics', 'effectsQuality', [[0, 'Low'], [1, 'Medium'], [2, 'High']]));
      row('View distance', 'Camera far plane & fog', slider('graphics', 'viewDistance', 200, 1600, 50, (v) => v + 'm'));
      row('Show FPS / perf overlay', 'Also toggled with F3', toggle('graphics', 'showFps'));
    } else if (this.settingsTab === 'controls') {
      section('MOUSE');
      row('Mouse sensitivity', '', slider('controls', 'sensitivity', 0.1, 4, 0.05));
      row('ADS sensitivity multiplier', 'Relative to hip; FOV-compensated', slider('controls', 'adsMultiplier', 0.2, 1.5, 0.05));
      row('Invert Y axis', '', toggle('controls', 'invertY'));
      section('BEHAVIOUR');
      row('Sprint', '', select('controls', 'sprintMode', [['hold', 'Hold'], ['toggle', 'Toggle']]));
      row('Auto Sprint', 'Holding forward sprints automatically. Aiming cancels sprint until ADS is released', select('controls', 'autoSprint', [['false', 'Off'], ['true', 'On']]));
      row('Crouch', '', select('controls', 'crouchMode', [['hold', 'Hold'], ['toggle', 'Toggle']]));
      row('Aim down sights', '', select('controls', 'adsMode', [['hold', 'Hold'], ['toggle', 'Toggle']]));
      section('KEY BINDINGS — click, then press a key or mouse button (Esc cancels)');
      for (const action of Object.keys(DEFAULT_BINDINGS)) {
        const b = document.createElement('button'); b.className = 'bind-btn';
        b.textContent = prettyKey(c.bindings[action]);
        b.addEventListener('click', () => {
          if (this.game.input.captureNext) return;
          b.classList.add('listening'); b.textContent = 'PRESS KEY…';
          this.game.input.captureNext = (code) => {
            b.classList.remove('listening');
            if (code !== 'Escape') { settings.rebind(action, code); audio.ui('ui_confirm'); }
            rerender();
          };
        });
        row(ACTION_LABELS[action], '', b);
      }
      const reset = document.createElement('button'); reset.className = 'bind-btn'; reset.textContent = 'RESET CONTROLS';
      reset.addEventListener('click', () => { settings.resetControls(); audio.ui('ui_back'); rerender(); });
      row('Restore default controls', 'Bindings, sensitivity & modes', reset);
    } else {
      section('VOLUME');
      const pct = (v) => Math.round(v * 100) + '%';
      row('Master', '', slider('audio', 'master', 0, 1, 0.01, pct));
      row('Weapons', 'Gunshots & handling', slider('audio', 'weapons', 0, 1, 0.01, pct));
      row('Footsteps', 'Movement', slider('audio', 'footsteps', 0, 1, 0.01, pct));
      row('Environment', 'Impacts, casings, wind', slider('audio', 'environment', 0, 1, 0.01, pct));
      row('Interface', 'Menus', slider('audio', 'interface', 0, 1, 0.01, pct));
      const test = document.createElement('button'); test.className = 'bind-btn'; test.textContent = 'PLAY TEST SHOT';
      test.addEventListener('click', () => audio.play('dynasty_shot', { cat: 'weapons', volume: 0.8 }));
      row('Test', 'Audio starts after the first click (browser policy)', test);
    }
    if (!settings.storageOk) { const n = document.createElement('div'); n.className = 'setting-section'; n.style.fontSize = '18px'; n.textContent = '⚠ Browser storage unavailable — settings will not persist after closing.'; body.appendChild(n); }
  }

  resetTab() {
    if (this.settingsTab === 'controls') settings.resetControls();
    else if (this.settingsTab === 'graphics') { settings.resetAll('graphics'); }
    else settings.resetAll('audio');
    audio.ui('ui_back');
    this.renderSettings();
  }

  renderControls() {
    const b = settings.controls.bindings;
    const rows = Object.keys(DEFAULT_BINDINGS).map((a) => [ACTION_LABELS[a], prettyKey(b[a])]);
    rows.push(['Mouse wheel', 'Switch weapon'], ['Esc', 'Pause / menu'], ['T', 'Resupply ammo (test range)'], ['Slide', 'Sprint + Crouch'], ['Slide cancel', 'Jump (hop) or Sprint (stand) during slide']);
    $('controls-body').innerHTML = rows.map(([l, k]) => `<div class="ctrl-row"><span>${l}</span><kbd>${k}</kbd></div>`).join('');
  }
}
void DEFAULTS;
