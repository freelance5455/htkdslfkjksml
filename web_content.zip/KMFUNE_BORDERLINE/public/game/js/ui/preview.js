// =====================================================================
// WeaponPreviewController — studio-lit 3D weapon showcase
// ---------------------------------------------------------------------
// Dark studio (as in the reference gunsmith): key / fill / rim lights,
// a soft floor shadow catcher and a subtle backdrop gradient. Orbit
// camera with damped yaw/pitch/zoom; focusSlot() eases the camera onto
// the attachment point being edited (reference behaviour: selecting a
// muzzle zooms to the muzzle, etc.). Drag = rotate, wheel = zoom.
// Rendered with scissor into a DOM rect (no extra canvas/context).
// Models are cached per configuration key and disposed on eviction.
// =====================================================================
import * as THREE from 'three';
import { assembleModel, disposeModel } from '../weapons/gunsmith.js';
import { LENS_LAYER } from '../weapons/optics.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

let ENV = null; // shared studio IBL (generated once)

const damp = (a, b, k, dt) => a + (b - a) * (1 - Math.exp(-k * dt));

/** Dark studio backdrop: soft radial light falloff + faint horizontal light bands (reference armory look). */
function studioBackdrop() {
  const c = document.createElement('canvas'); c.width = 512; c.height = 288;
  const g = c.getContext('2d');
  const rg = g.createRadialGradient(330, 150, 10, 300, 150, 360);
  rg.addColorStop(0, '#2b2d31'); rg.addColorStop(0.45, '#17181b'); rg.addColorStop(1, '#070708');
  g.fillStyle = rg; g.fillRect(0, 0, 512, 288);
  g.globalAlpha = 0.05; g.fillStyle = '#ffffff';
  for (const [y, h] of [[52, 3], [96, 2], [190, 2], [226, 4]]) g.fillRect(0, y, 512, h);
  g.globalAlpha = 0.06;
  for (let i = 0; i < 2600; i++) { g.fillStyle = Math.random() < 0.5 ? '#000' : '#fff'; g.fillRect(Math.random() * 512, Math.random() * 288, 1, 1); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export class WeaponPreviewController {
  constructor() {
    const s = this.scene = new THREE.Scene();
    s.background = studioBackdrop();
    this.cam = new THREE.PerspectiveCamera(26, 1, 0.02, 20);
    this.cam.layers.enable(LENS_LAYER);
    // studio lighting
    s.add(new THREE.HemisphereLight(0xc8d0dc, 0x15161a, 0.55));
    const key = new THREE.DirectionalLight(0xfff2e2, 3.2); key.position.set(1.6, 2.2, 2.0);
    key.castShadow = true; key.shadow.mapSize.set(1024, 1024); key.shadow.bias = -0.0005;
    Object.assign(key.shadow.camera, { left: -1, right: 1, top: 1, bottom: -1, near: 0.5, far: 6 });
    const fill = new THREE.DirectionalLight(0xbcd2ff, 0.9); fill.position.set(-2.2, 0.6, 1.4);
    const rim = new THREE.DirectionalLight(0xffffff, 2.6); rim.position.set(-0.6, 1.4, -2.6);
    const kick = new THREE.PointLight(0xff4a3a, 0.6, 3, 2); kick.position.set(1.4, -0.3, -1.2); // red accent like the reference UI
    s.add(key, key.target, fill, rim, kick);
    // floor shadow catcher
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(6, 6), new THREE.ShadowMaterial({ opacity: 0.35 }));
    floor.rotation.x = -Math.PI / 2; floor.position.y = -0.24; floor.receiveShadow = true;
    s.add(floor);
    this.pivot = new THREE.Group(); s.add(this.pivot);
    this.cache = new Map();       // key → { holder, model, center }
    this.current = null;
    this.yaw = -0.35; this.pitch = 0.08; this.dist = 1.9; this.auto = true;
    this.tYaw = this.yaw; this.tPitch = this.pitch; this.tDist = this.dist;
    this.focus = new THREE.Vector3(); this.tFocus = new THREE.Vector3();
    this.baseDist = 1.9;
  }

  /** Bind drag / wheel interaction to a DOM element. */
  bind(el) {
    let drag = null;
    el.addEventListener('pointerdown', (e) => { if (e.button !== 0) return; drag = { x: e.clientX, y: e.clientY, yaw: this.tYaw, pitch: this.tPitch }; this.auto = false; el.setPointerCapture(e.pointerId); });
    el.addEventListener('pointermove', (e) => { if (!drag) return; this.tYaw = drag.yaw + (e.clientX - drag.x) * 0.008; this.tPitch = Math.max(-0.9, Math.min(0.9, drag.pitch + (e.clientY - drag.y) * 0.005)); });
    el.addEventListener('pointerup', () => { drag = null; });
    el.addEventListener('wheel', (e) => { e.preventDefault(); this.tDist = Math.max(0.35, Math.min(3.2, this.tDist * (e.deltaY > 0 ? 1.1 : 0.9))); }, { passive: false });
  }

  /** Show a configuration (cached by key). */
  show(cfg) {
    const key = cfg.key();
    let entry = this.cache.get(key);
    if (!entry) {
      const model = assembleModel(cfg);
      const holder = new THREE.Group();
      const box = new THREE.Box3().setFromObject(model.root);
      const center = box.getCenter(new THREE.Vector3());
      const size = box.getSize(new THREE.Vector3());
      model.root.position.set(-center.x, -center.y, -center.z);
      model.root.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
      holder.add(model.root);
      entry = { holder, model, center, size, cfg };
      this.cache.set(key, entry);
      // evict old entries (bounded memory)
      if (this.cache.size > 10) {
        for (const [k, v] of this.cache) { if (v !== entry && v !== this.current) { disposeModel(v.model); this.cache.delete(k); break; } }
      }
    }
    if (this.current !== entry) {
      this.pivot.clear();
      this.pivot.add(entry.holder);
      const sameWeapon = this.current && this.current.cfg.weaponId === cfg.weaponId;
      this.current = entry;
      this.baseDist = Math.max(1.0, entry.size.z * 1.75 + 0.35);
      if (!sameWeapon) { this.tDist = this.baseDist; this.tFocus.set(0, 0, 0); }
    }
    return entry.model;
  }

  /** Ease the camera onto an attachment slot (null = whole weapon). */
  focusSlot(slot) {
    const e = this.current; if (!e) return;
    if (!slot) { this.tFocus.set(0, 0, 0); this.tDist = this.baseDist; return; }
    const S = e.model.sockets;
    const name = { optic: 'optic', muzzle: 'muzzleBase', underbarrel: 'underbarrel', laser: 'laser', magazine: 'magWell', stock: 'rightHand', grip: 'rightHand', barrel: 'muzzleBase' }[slot];
    const sock = S[name] || S[name === 'muzzleBase' ? 'muzzle' : name];
    if (!sock) return;
    e.model.root.updateMatrixWorld(true);
    const p = sock.getWorldPosition(new THREE.Vector3());
    this.pivot.worldToLocal(p);
    if (slot === 'stock') p.z += 0.22;
    if (slot === 'barrel') p.z += 0.12;
    if (slot === 'magazine') p.y -= 0.06;
    this.tFocus.copy(p);
    this.tDist = slot === 'barrel' ? 0.85 : 0.6;
    this.auto = false;
    // turn the side with the part toward the camera
    this.tYaw = slot === 'laser' ? -1.1 : -0.55;
    this.tPitch = slot === 'underbarrel' || slot === 'magazine' ? -0.18 : slot === 'optic' ? 0.22 : 0.08;
  }

  update(dt) {
    if (this.auto) this.tYaw += dt * 0.25;
    this.yaw = damp(this.yaw, this.tYaw, 7, dt); this.pitch = damp(this.pitch, this.tPitch, 7, dt);
    this.dist = damp(this.dist, this.tDist, 6, dt);
    this.focus.x = damp(this.focus.x, this.tFocus.x, 6, dt); this.focus.y = damp(this.focus.y, this.tFocus.y, 6, dt); this.focus.z = damp(this.focus.z, this.tFocus.z, 6, dt);
    // orbit around the focus point: the weapon rotates, the camera stays framed
    this.pivot.rotation.set(0, 0, 0);
    const c = this.cam;
    c.position.set(
      this.focus.x + Math.sin(this.yaw) * Math.cos(this.pitch) * this.dist,
      this.focus.y + Math.sin(this.pitch) * this.dist,
      this.focus.z + Math.cos(this.yaw) * Math.cos(this.pitch) * this.dist,
    );
    // weapon faces left like the reference (muzzle to screen-left): view from +X side
    const off = c.position.clone().sub(this.focus);
    off.applyAxisAngle(new THREE.Vector3(0, 1, 0), -Math.PI / 2);   // camera on the weapon's left (-X) → muzzle points screen-left
    c.position.copy(this.focus).add(off);
    c.lookAt(this.focus);
  }

  /** Render into a screen rect (CSS px). `shift` offsets the weapon horizontally (0..1 of width). */
  render(renderer, rect, dt, shift = 0) {
    if (!this.current || rect.width < 10 || rect.height < 10) return;
    if (!ENV) { const pm = new THREE.PMREMGenerator(renderer); ENV = pm.fromScene(new RoomEnvironment(), 0.04).texture; pm.dispose(); }
    if (this.scene.environment !== ENV) { this.scene.environment = ENV; this.scene.environmentIntensity = 0.85; }
    this.update(dt);
    const H = window.innerHeight;
    const r = renderer;
    // drawn straight to the canvas: the renderer applies tone mapping + sRGB itself
    const prevExp = r.toneMappingExposure, prevTM = r.toneMapping;
    r.toneMappingExposure = 1.15; r.toneMapping = THREE.ACESFilmicToneMapping;
    r.setRenderTarget(null);
    r.setScissorTest(true);
    r.setScissor(rect.left, H - rect.bottom, rect.width, rect.height);
    r.setViewport(rect.left, H - rect.bottom, rect.width, rect.height);
    this.cam.aspect = rect.width / rect.height;
    this.cam.setViewOffset(rect.width, rect.height, -shift * rect.width, 0, rect.width, rect.height);
    this.cam.updateProjectionMatrix();
    r.autoClear = false; r.clearDepth();
    r.render(this.scene, this.cam);
    r.setScissorTest(false);
    r.setViewport(0, 0, window.innerWidth, window.innerHeight);
    r.autoClear = true;
    r.toneMappingExposure = prevExp; r.toneMapping = prevTM;
  }
}
