// =====================================================================
// Player body — intentionally simplified "stickman" design
// ---------------------------------------------------------------------
// ViewArms:  first-person arms in viewmodel space. Capsule upper arm +
//            forearm with sleeve/glove materials, mitten hands without
//            individual fingers. Two-bone IK from fixed shoulders to hand
//            targets supplied by the weapon controller (grip sockets or
//            animated reload targets). Bone lengths are fixed → arms never
//            stretch; if a target is out of reach the hand stops at full
//            extension and the weapon controller keeps targets in reach.
// ShadowBody: full-body stickman in the world that is not visible to the
//            first-person camera (camera layer 1) but casts a shadow, with
//            legs that walk/crouch/slide/jump with the controller state.
// =====================================================================
import * as THREE from 'three';
import { getShared } from '../weapons/kit.js';
import { solveTwoBone, clamp } from '../core/math.js';

const UPPER = 0.36, FORE = 0.34;

const _up = new THREE.Vector3(0, 1, 0), _d = new THREE.Vector3();
function orientTube(mesh, a, b) {
  _d.subVectors(b, a);
  const len = _d.length();
  mesh.position.copy(a);
  if (len > 1e-5) mesh.quaternion.setFromUnitVectors(_up, _d.multiplyScalar(1 / len));
  mesh.scale.set(1, Math.max(1e-3, len), 1);
}

function mittenGeo() {
  // palm block + finger mitt + thumb blob, built along +Y (fingers) and
  // with the palm facing -Z. Simple, readable and finger-less.
  const parts = [];
  const palm = new THREE.CapsuleGeometry(0.026, 0.035, 4, 10); palm.scale(1.05, 1, 0.62); parts.push(palm);
  const mitt = new THREE.CapsuleGeometry(0.024, 0.03, 4, 10); mitt.scale(1.0, 1, 0.6); mitt.rotateX(-0.45); mitt.translate(0, 0.045, -0.012); parts.push(mitt);
  const thumb = new THREE.CapsuleGeometry(0.011, 0.028, 3, 8); thumb.rotateZ(0.9); thumb.translate(-0.03, 0.012, -0.012); parts.push(thumb);
  const cuff = new THREE.CylinderGeometry(0.031, 0.029, 0.03, 12); cuff.translate(0, -0.042, 0); parts.push(cuff);
  return parts;
}

export class ViewArms {
  constructor(scene) {
    const { M } = getShared();
    this.group = new THREE.Group();
    this.group.name = 'viewArms';
    scene.add(this.group);
    const sleeve = M.sleeve(), glove = M.glove(), pad = M.gloveWhite();
    // unit-length limb tubes (y 0..1 → scaled to bone length); joints are spheres,
    // so scaling the tube never distorts the rounded ends.
    const upGeo = new THREE.CylinderGeometry(0.04, 0.046, 1, 12, 1, true); upGeo.translate(0, 0.5, 0);
    const foreGeo = new THREE.CylinderGeometry(0.033, 0.04, 1, 12, 1, true); foreGeo.translate(0, 0.5, 0);
    const jointGeo = new THREE.SphereGeometry(0.046, 12, 8);
    const [palm, mitt, thumb, cuff] = mittenGeo();
    this.sides = {};
    for (const side of ['L', 'R']) {
      const upper = new THREE.Mesh(upGeo, sleeve);
      const fore = new THREE.Mesh(foreGeo, sleeve);
      const hand = new THREE.Group();
      hand.add(new THREE.Mesh(palm, glove), new THREE.Mesh(mitt, glove), new THREE.Mesh(thumb, glove), new THREE.Mesh(cuff, pad));
      // white armour plate on the back of the hand (as in reference gloves)
      const plate = new THREE.Mesh(new THREE.CapsuleGeometry(0.016, 0.02, 3, 8), pad);
      plate.scale.set(1, 1, 0.4); plate.position.set(0, 0.01, 0.017); hand.add(plate);
      const elbowPad = new THREE.Mesh(jointGeo, pad);
      elbowPad.scale.setScalar(0.95);
      this.group.add(upper, fore, hand, elbowPad);
      for (const m of [upper, fore, elbowPad]) m.frustumCulled = false;
      hand.traverse((o) => { if (o.isMesh) o.frustumCulled = false; });
      this.sides[side] = {
        upper, fore, hand, elbowPad,
        shoulder: new THREE.Vector3(side === 'R' ? 0.24 : -0.16, -0.34, -0.02),
        pole: new THREE.Vector3(side === 'R' ? 0.6 : -0.45, -0.9, 0.1),
        target: new THREE.Vector3(), targetQ: new THREE.Quaternion(),
        elbow: new THREE.Vector3(), handPos: new THREE.Vector3(),
        visible: true,
      };
    }
    this._a = new THREE.Vector3();
  }

  /** Set world-space (viewmodel space) hand target and orientation. */
  setTarget(side, pos, quat) { const s = this.sides[side]; s.target.copy(pos); s.targetQ.copy(quat); }
  setVisible(side, v) { this.sides[side].visible = v; }

  update() {
    for (const side of ['L', 'R']) {
      const s = this.sides[side];
      const vis = s.visible;
      s.upper.visible = s.fore.visible = s.hand.visible = s.elbowPad.visible = vis;
      if (!vis) continue;
      // wrist sits a little behind the hand centre along the hand's -Y
      const wrist = this._a.set(0, -0.055, 0).applyQuaternion(s.targetQ).add(s.target);
      solveTwoBone(s.shoulder, wrist, UPPER, FORE, s.pole, s.elbow, s.handPos);
      orientTube(s.upper, s.shoulder, s.elbow);
      orientTube(s.fore, s.elbow, s.handPos);
      s.elbowPad.position.copy(s.elbow);
      // hand: if the wrist was clamped (out of reach) shift the hand with it
      const shift = this._a.subVectors(s.handPos, wrist);
      s.hand.position.copy(s.target).add(shift);
      s.hand.quaternion.copy(s.targetQ);
    }
  }
}

// ---------------------------------------------------------------------
// Shadow-only stickman body (world space)
// ---------------------------------------------------------------------
export class ShadowBody {
  constructor(scene) {
    this.group = new THREE.Group();
    this.group.name = 'shadowBody';
    const mat = new THREE.MeshBasicMaterial({ color: 0x000000 });
    const limb = new THREE.CapsuleGeometry(0.07, 0.36, 4, 8);
    const mk = (geo) => { const m = new THREE.Mesh(geo, mat); m.castShadow = true; m.layers.set(1); this.group.add(m); return m; };
    this.torso = mk(new THREE.CapsuleGeometry(0.17, 0.42, 4, 10));
    this.head = mk(new THREE.SphereGeometry(0.13, 12, 8));
    this.thighL = mk(limb); this.thighR = mk(limb);
    this.shinL = mk(limb); this.shinR = mk(limb);
    this.armL = mk(limb); this.armR = mk(limb);
    this.gun = mk(new THREE.BoxGeometry(0.07, 0.12, 0.8));
    this.group.traverse((o) => o.layers.set(1));
    scene.add(this.group);
    this.phase = 0;
  }

  update(ctrl, dt) {
    const g = this.group;
    g.position.copy(ctrl.pos);
    g.rotation.y = ctrl.yaw;
    const crouch = ctrl.sliding ? 1 : ctrl.crouching ? 0.7 : 0;
    const speed = ctrl.speed2D;
    if (ctrl.grounded && !ctrl.sliding) this.phase += dt * speed * 2.1;
    const swing = Math.sin(this.phase) * clamp(speed / 6, 0, 1) * 0.7;
    const hip = 0.92 - crouch * 0.4;
    const air = ctrl.grounded ? 0 : 0.6;
    const legs = [[this.thighL, this.shinL, swing, -0.1], [this.thighR, this.shinR, -swing, 0.1]];
    for (const [th, sh, a, x] of legs) {
      const knee = new THREE.Vector3(x, hip - 0.42, 0);
      const angle = a - crouch * (ctrl.sliding ? -1.2 : 0.9) - air * 0.5;
      knee.set(x, hip - Math.cos(angle) * 0.42, -Math.sin(angle) * 0.42);
      const foot = new THREE.Vector3(x, Math.max(0.05, knee.y - 0.42 + crouch * 0.18), knee.z + Math.sin(Math.max(0, -angle)) * 0.2 + crouch * 0.25);
      if (ctrl.sliding) foot.set(x, 0.12, knee.z - 0.4);
      capsule(th, new THREE.Vector3(x, hip, 0), knee);
      capsule(sh, knee, foot);
    }
    const chest = new THREE.Vector3(0, hip + 0.38, ctrl.sliding ? 0.2 : 0);
    capsule(this.torso, new THREE.Vector3(0, hip + 0.05, 0), chest.clone().add(new THREE.Vector3(0, 0.25, 0)));
    this.head.position.set(0, chest.y + 0.42, chest.z);
    // arms holding the gun forward
    const gunPos = new THREE.Vector3(0.15, chest.y + 0.12, -0.35);
    capsule(this.armR, new THREE.Vector3(0.22, chest.y + 0.2, chest.z), gunPos.clone().add(new THREE.Vector3(0.02, 0, 0.15)));
    capsule(this.armL, new THREE.Vector3(-0.22, chest.y + 0.2, chest.z), gunPos.clone().add(new THREE.Vector3(-0.08, 0, -0.2)));
    this.gun.position.copy(gunPos);
    this.gun.rotation.set(ctrl.pitch * 0.8, 0, 0);
  }
}

function capsule(mesh, a, b) {
  const d = new THREE.Vector3().subVectors(b, a);
  const len = d.length();
  mesh.position.copy(a).addScaledVector(d, 0.5);
  if (len > 1e-4) mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.divideScalar(len));
  mesh.scale.set(1, Math.max(0.1, len / 0.5), 1);
}
