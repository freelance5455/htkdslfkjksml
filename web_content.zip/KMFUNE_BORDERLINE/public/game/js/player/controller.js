// =====================================================================
// First-person movement controller
// ---------------------------------------------------------------------
// Fixed-timestep simulation (120 Hz) with interpolated presentation.
// States: idle / walk / sprint / crouch / slide / air
//
//   Walk ............ WASD, smooth accel/decel (ground friction model)
//   Sprint .......... hold/toggle; forward-only (diagonal ok), breaks on
//                     backpedal, ADS, firing (weapon system tells us), crouch
//   Crouch .......... hold/toggle; camera lowers smoothly; capsule shrinks;
//                     uncrouch is blocked if there is no headroom
//   Jump ............ grounded only, coyote time 0.1 s, jump buffer 0.12 s
//   Slide ........... crouch while sprinting above SLIDE_MIN_SPEED → burst of
//                     momentum, low friction, speed-dependent duration;
//                     ends when speed drops, crouch released (hold mode),
//                     or a wall is hit.
//   Slide cancel .... (a) JUMP during slide → keeps momentum into a hop
//                     (b) SPRINT during slide → stand up into sprint
//                     Both restore states without teleporting/velocity reset.
// =====================================================================
import * as THREE from 'three';
import { settings } from '../core/settings.js';
import { clamp, damp, DEG } from '../core/math.js';
import { bus } from '../core/events.js';

export const MOVE = {
  WALK_SPEED: 4.6,
  SPRINT_SPEED: 7.4,
  CROUCH_SPEED: 2.4,
  ADS_SPEED_MUL: 0.62,
  GROUND_ACCEL: 62,
  GROUND_FRICTION: 9.5,
  AIR_ACCEL: 14,
  AIR_MAX: 7.6,
  GRAVITY: 22,
  JUMP_VELOCITY: 7.0,
  SLIDE_MIN_SPEED: 5.6,
  SLIDE_BOOST: 3.0,
  SLIDE_FRICTION: 1.6,
  SLIDE_END_SPEED: 3.2,
  SLIDE_MAX_TIME: 1.15,
  SLIDE_COOLDOWN: 0.45,
  STAND_HEIGHT: 1.8,
  CROUCH_HEIGHT: 1.15,
  SLIDE_HEIGHT: 0.95,
  EYE_STAND: 1.66,
  EYE_CROUCH: 1.05,
  EYE_SLIDE: 0.85,
  RADIUS: 0.36,
  COYOTE: 0.1,
  JUMP_BUFFER: 0.12,
};

const FIXED_DT = 1 / 120;

export class PlayerController {
  constructor(physics, input, camera) {
    this.physics = physics;
    this.input = input;
    this.camera = camera;

    this.pos = new THREE.Vector3();
    this.prevPos = new THREE.Vector3();
    this.vel = new THREE.Vector3();
    this.yaw = 0; this.pitch = 0;

    this.state = 'idle';
    this.grounded = true;
    this.crouching = false;
    this.sliding = false;
    this.sprinting = false;
    this.sprintToggled = false;
    this.adsInput = false; this.autoSprintLatch = false; this.adsZoom = 1;
    this.crouchToggled = false;
    this.height = MOVE.STAND_HEIGHT;
    this.eyeHeight = MOVE.EYE_STAND;
    this.eyeSmooth = MOVE.EYE_STAND;

    this.slideTimer = 0;
    this.slideCooldown = 0;
    this.slideDir = new THREE.Vector3();
    this.coyote = 0;
    this.jumpBuffer = 0;
    this.airTime = 0;
    this.lastLandSpeed = 0;
    this.accum = 0;

    // presentation
    this.bobPhase = 0;
    this.bobAmount = 0;
    this.stepDistance = 0;
    this.camTilt = 0;
    this.landKick = 0;        // camera dip on landing (spring)
    this.landKickVel = 0;
    this.recoilPitch = 0;     // applied by weapon system (view kick, recovers)
    this.recoilYaw = 0;
    this.speed2D = 0;
    this.moveInput = new THREE.Vector2();
    this.wishDir = new THREE.Vector3();
    this.adsBlend = 0;        // set by weapon system
    this.blockSprint = false; // set by weapon system (firing, reloading w/ some guns)
    this.enabled = true;
  }

  spawn(position, yaw = 0) {
    this.pos.copy(position); this.prevPos.copy(position);
    this.vel.set(0, 0, 0);
    this.yaw = yaw; this.pitch = 0;
    this.crouching = this.sliding = this.sprinting = false;
    this.sprintToggled = this.crouchToggled = false;
    this.height = MOVE.STAND_HEIGHT; this.eyeHeight = this.eyeSmooth = MOVE.EYE_STAND;
    this.state = 'idle';
    this.recoilPitch = this.recoilYaw = 0;
  }

  // ---------------- look ----------------
  applyLook() {
    const { dx, dy } = this.input.consumeMouse();
    const c = settings.controls;
    const fov = this.camera.fov;
    // ADS sensitivity: user multiplier, and FOV-proportional scaling so the
    // perceived speed stays consistent when zoomed.
    const zoomScale = Math.tan((fov * DEG) / 2) / Math.tan((settings.graphics.fov * DEG) / 2) / (this.adsZoom || 1);
    const adsMul = 1 + (c.adsMultiplier * zoomScale - 1) * this.adsBlend;
    const k = 0.0022 * c.sensitivity * adsMul;
    this.yaw -= dx * k;
    this.pitch -= dy * k * (c.invertY ? -1 : 1);
    this.pitch = clamp(this.pitch, -89 * DEG, 89 * DEG);
  }

  // ---------------- simulation ----------------
  update(dt) {
    if (!this.enabled) return;
    this.applyLook();
    this._readStateInputs();

    this.accum += Math.min(dt, 0.1);
    while (this.accum >= FIXED_DT) {
      this.prevPos.copy(this.pos);
      this._step(FIXED_DT);
      this.accum -= FIXED_DT;
    }
    this._present(dt);
  }

  _readStateInputs() {
    const inp = this.input, c = settings.controls;
    // movement intent
    const f = (inp.down('forward') ? 1 : 0) - (inp.down('back') ? 1 : 0);
    const s = (inp.down('right') ? 1 : 0) - (inp.down('left') ? 1 : 0);
    this.moveInput.set(s, f);
    if (this.moveInput.lengthSq() > 1) this.moveInput.normalize();

    // sprint (hold / toggle)
    if (c.sprintMode === 'toggle') { if (inp.pressed('sprint')) this.sprintToggled = !this.sprintToggled; }
    let sprintHeld = c.sprintMode === 'toggle' ? this.sprintToggled : inp.down('sprint');
    // Auto Sprint: holding forward sprints automatically. Aiming cancels it,
    // and it cannot re-engage until the ADS input has been released.
    if (c.autoSprint) {
      if (this.adsInput) this.autoSprintLatch = true;
      else if (this.autoSprintLatch && !this.adsInput) this.autoSprintLatch = false;
      if (inp.down('forward') && !inp.down('back') && !this.autoSprintLatch) sprintHeld = true;
    }

    // crouch (hold / toggle)
    const crouchPressed = inp.pressed('crouch');
    if (c.crouchMode === 'toggle' && crouchPressed && !this.sliding) this.crouchToggled = !this.crouchToggled;
    const crouchHeld = c.crouchMode === 'toggle' ? this.crouchToggled : inp.down('crouch');

    // jump buffer
    if (inp.pressed('jump')) this.jumpBuffer = MOVE.JUMP_BUFFER;

    // ---- slide entry: crouch pressed while sprinting fast on ground ----
    if (crouchPressed && this.grounded && !this.sliding && this.slideCooldown <= 0 && this.sprinting && this.speed2D >= MOVE.SLIDE_MIN_SPEED) {
      this._startSlide();
      if (c.crouchMode === 'toggle') this.crouchToggled = false; // slide shouldn't leave toggle stuck
      return;
    }

    // ---- slide cancel (b): sprint pressed → stand into sprint ----
    if (this.sliding && inp.pressed('sprint') && this._canStand()) {
      this._endSlide('sprint');
      this.sprinting = true;
      if (c.sprintMode === 'toggle') this.sprintToggled = true;
    }
    // hold-crouch released during slide → end slide (stand if possible)
    if (this.sliding && c.crouchMode === 'hold' && !inp.down('crouch') && this.slideTimer > 0.18) {
      this._endSlide(this._canStand() ? 'stand' : 'crouch');
    }

    if (!this.sliding) {
      const wantCrouch = crouchHeld;
      if (wantCrouch) this.crouching = true;
      else if (this.crouching && this._canStand()) this.crouching = false;

      // sprint conditions
      const forwardish = this.moveInput.y > 0.3;
      const canSprint = forwardish && !this.crouching && this.adsBlend < 0.5 && !this.blockSprint;
      this.sprinting = sprintHeld && canSprint && (this.grounded || this.sprinting);
      if (c.sprintMode === 'toggle' && !forwardish && this.moveInput.lengthSq() === 0) this.sprintToggled = false;
    }
  }

  _canStand() {
    return this.physics.fits(this.pos, MOVE.RADIUS * 0.95, MOVE.STAND_HEIGHT);
  }

  _startSlide() {
    this.sliding = true;
    this.sprinting = false;
    this.crouching = true;
    this.slideTimer = 0;
    // direction = current horizontal velocity direction (momentum-preserving)
    this.slideDir.set(this.vel.x, 0, this.vel.z).normalize();
    const boost = MOVE.SLIDE_BOOST * clamp((this.speed2D - MOVE.SLIDE_MIN_SPEED + 2) / 3, 0.5, 1);
    this.vel.x += this.slideDir.x * boost;
    this.vel.z += this.slideDir.z * boost;
    bus.emit('player:slideStart', { speed: this.speed2D + boost });
  }

  _endSlide(reason) {
    if (!this.sliding) return;
    this.sliding = false;
    this.slideCooldown = MOVE.SLIDE_COOLDOWN;
    if (reason === 'stand' || reason === 'sprint' || reason === 'jump') this.crouching = !this._canStand();
    else this.crouching = true;
    if (settings.controls.crouchMode === 'toggle' && this.crouching) this.crouchToggled = true;
    bus.emit('player:slideEnd', { reason });
  }

  _step(h) {
    const P = MOVE;
    this.slideCooldown = Math.max(0, this.slideCooldown - h);
    this.jumpBuffer = Math.max(0, this.jumpBuffer - h);
    this.coyote = this.grounded ? P.COYOTE : Math.max(0, this.coyote - h);

    // ---- wish direction in world space ----
    const sinY = Math.sin(this.yaw), cosY = Math.cos(this.yaw);
    // forward = (-sin, -cos) for yaw rotating around Y with -Z forward
    const fx = -sinY, fz = -cosY, rx = cosY, rz = -sinY;
    this.wishDir.set(fx * this.moveInput.y + rx * this.moveInput.x, 0, fz * this.moveInput.y + rz * this.moveInput.x);
    const wishLen = this.wishDir.length();
    if (wishLen > 1e-4) this.wishDir.multiplyScalar(1 / wishLen);

    let targetSpeed = this.crouching ? P.CROUCH_SPEED : this.sprinting ? P.SPRINT_SPEED : P.WALK_SPEED;
    targetSpeed *= 1 + (P.ADS_SPEED_MUL - 1) * this.adsBlend;
    targetSpeed *= this.weaponMobility || 1;   // weapon + attachment weight
    // backpedal slightly slower
    if (this.moveInput.y < 0) targetSpeed *= 0.85;

    // ---- jump (and slide-jump cancel) ----
    if (this.jumpBuffer > 0 && this.coyote > 0) {
      if (this.sliding) {
        this._endSlide('jump');
        bus.emit('player:slideCancel', { type: 'jump' });
      }
      if (!this.crouching || this._canStand()) {
        this.crouching = false;
        this.vel.y = P.JUMP_VELOCITY;
        this.grounded = false; this.coyote = 0; this.jumpBuffer = 0;
        bus.emit('player:jump');
      }
    }

    const hv = new THREE.Vector3(this.vel.x, 0, this.vel.z);
    if (this.sliding) {
      // low friction slide along slideDir with slight steering
      this.slideTimer += h;
      const sp = hv.length();
      const newSp = Math.max(0, sp - P.SLIDE_FRICTION * h * (1 + this.slideTimer * 1.6));
      // steering: up to ~25°/s toward wishDir
      if (wishLen > 0.1) {
        const steer = 0.45 * h;
        this.slideDir.lerp(this.wishDir, steer).normalize();
      }
      hv.copy(this.slideDir).multiplyScalar(newSp);
      if (newSp < P.SLIDE_END_SPEED || this.slideTimer > P.SLIDE_MAX_TIME * clamp(sp / 8, 0.6, 1.25) || !this.grounded) {
        this._endSlide(this._canStand() && settings.controls.crouchMode === 'hold' && !this.input.down('crouch') ? 'stand' : 'crouch');
      }
    } else if (this.grounded) {
      // ground: friction + acceleration toward target velocity
      const sp = hv.length();
      if (sp > 1e-4) {
        const drop = sp * P.GROUND_FRICTION * h * (wishLen > 0.1 ? 0.35 : 1);
        const ns = Math.max(0, sp - Math.max(drop, wishLen > 0.1 ? 0 : 0.6 * h * 10));
        hv.multiplyScalar(ns / sp);
      }
      if (wishLen > 0.1) {
        const cur = hv.dot(this.wishDir);
        const add = targetSpeed - cur;
        if (add > 0) hv.addScaledVector(this.wishDir, Math.min(P.GROUND_ACCEL * h, add));
        // clamp to target speed (prevents strafe-boost exploits on ground)
        const len = hv.length();
        if (len > targetSpeed && !this.sliding) hv.multiplyScalar(Math.max(targetSpeed, len - P.GROUND_FRICTION * 1.5 * h * len) / len);
      }
    } else {
      // air control
      if (wishLen > 0.1) {
        const cur = hv.dot(this.wishDir);
        const add = P.AIR_MAX * 0.6 - cur;
        if (add > 0) hv.addScaledVector(this.wishDir, Math.min(P.AIR_ACCEL * h, add));
      }
    }
    this.vel.x = hv.x; this.vel.z = hv.z;

    // gravity
    if (!this.grounded || this.vel.y > 0) this.vel.y -= P.GRAVITY * h;
    else this.vel.y = -2 * h; // small stick force

    // ---- capsule height (smooth, collision-checked) ----
    const wantH = this.sliding ? P.SLIDE_HEIGHT : this.crouching ? P.CROUCH_HEIGHT : P.STAND_HEIGHT;
    if (wantH > this.height) {
      const nh = Math.min(wantH, this.height + h * 6);
      if (this.physics.fits(this.pos, P.RADIUS * 0.95, nh)) this.height = nh;
    } else this.height = Math.max(wantH, this.height - h * 8);

    // ---- integrate & collide ----
    const wasGrounded = this.grounded;
    const fallSpeed = -this.vel.y;
    const delta = new THREE.Vector3(this.vel.x * h, this.vel.y * h, this.vel.z * h);
    const res = this.physics.moveCharacter(this.pos, delta, P.RADIUS, this.height, this.sliding || this.crouching ? 0.2 : 0.38);
    if (res.hitCeiling && this.vel.y > 0) this.vel.y = 0;
    if (res.hitWall && this.sliding) {
      // hitting a wall during a slide ends it (prevents sliding into walls forever)
      const sp = Math.hypot(this.vel.x, this.vel.z);
      if (sp < P.SLIDE_END_SPEED + 0.5) this._endSlide('crouch');
    }
    if (res.hitWall) {
      // remove velocity into walls: recompute from actual displacement
      const actual = new THREE.Vector3().subVectors(this.pos, this.prevPos);
      if (Math.abs(actual.x) < Math.abs(delta.x) * 0.5) this.vel.x = actual.x / h;
      if (Math.abs(actual.z) < Math.abs(delta.z) * 0.5) this.vel.z = actual.z / h;
    }
    this.grounded = res.grounded && this.vel.y <= 0.01;
    if (this.grounded) { if (this.vel.y < 0) this.vel.y = 0; }

    if (!wasGrounded && this.grounded) {
      this.lastLandSpeed = fallSpeed;
      if (this.airTime > 0.12) {
        const k = clamp(fallSpeed / 12, 0.15, 1);
        this.landKickVel -= k * 2.4;
        bus.emit('player:land', { speed: fallSpeed, intensity: k });
      }
      this.airTime = 0;
    }
    if (!this.grounded) this.airTime += h;

    // safety: never fall below floor
    if (this.pos.y < -0.01) { this.pos.y = 0; this.vel.y = 0; this.grounded = true; }

    this.speed2D = Math.hypot(this.vel.x, this.vel.z);

    // state label
    if (this.sliding) this.state = 'slide';
    else if (!this.grounded) this.state = 'air';
    else if (this.crouching) this.state = this.speed2D > 0.4 ? 'crouchwalk' : 'crouch';
    else if (this.sprinting && this.speed2D > 1) this.state = 'sprint';
    else if (this.speed2D > 0.4) this.state = 'walk';
    else this.state = 'idle';

    // footsteps by distance travelled
    if (this.grounded && !this.sliding && this.speed2D > 0.6) {
      this.stepDistance += this.speed2D * h;
      const stride = this.crouching ? 0.85 : this.sprinting ? 1.85 : 1.45;
      if (this.stepDistance >= stride) {
        this.stepDistance -= stride;
        bus.emit('player:footstep', { kind: this.crouching ? 'crouch' : this.sprinting ? 'sprint' : (this.speed2D > 3 ? 'run' : 'walk'), speed: this.speed2D });
      }
    } else if (!this.grounded) this.stepDistance = 0.9;
  }

  // ---------------- camera presentation ----------------
  _present(dt) {
    const alpha = this.accum / FIXED_DT;
    const ip = new THREE.Vector3().lerpVectors(this.prevPos, this.pos, alpha);

    const targetEye = this.sliding ? MOVE.EYE_SLIDE : this.crouching ? MOVE.EYE_CROUCH : MOVE.EYE_STAND;
    // eye must stay below capsule top
    const eyeCap = this.height - 0.12;
    this.eyeSmooth = damp(this.eyeSmooth, Math.min(targetEye, eyeCap), 12, dt);

    // land dip spring
    this.landKickVel += (-this.landKick * 140 - this.landKickVel * 16) * dt;
    this.landKick += this.landKickVel * dt;

    // head bob (scaled by speed, suppressed in ADS / air / slide)
    const moving = this.grounded && !this.sliding && this.speed2D > 0.3;
    const bobTarget = moving ? clamp(this.speed2D / MOVE.SPRINT_SPEED, 0, 1) * (1 - this.adsBlend * 0.85) : 0;
    this.bobAmount = damp(this.bobAmount, bobTarget, 8, dt);
    const freq = this.sprinting ? 2.15 : this.crouching ? 1.35 : 1.75;
    if (moving) this.bobPhase += dt * freq * Math.PI * 2 * clamp(this.speed2D / 4.5, 0.6, 1.4) * 0.5;
    const bobY = Math.abs(Math.sin(this.bobPhase)) * 0.045 * this.bobAmount;
    const bobX = Math.sin(this.bobPhase) * 0.022 * this.bobAmount;

    // strafe tilt + slide tilt
    const localVelX = this.vel.x * Math.cos(this.yaw) - this.vel.z * Math.sin(this.yaw);
    const tiltTarget = clamp(-localVelX / MOVE.SPRINT_SPEED, -1, 1) * 1.6 * DEG * (1 - this.adsBlend * 0.6) + (this.sliding ? 4.5 * DEG : 0);
    this.camTilt = damp(this.camTilt, tiltTarget, 8, dt);

    const cam = this.camera;
    cam.position.set(ip.x, ip.y + this.eyeSmooth + bobY + this.landKick * 0.08, ip.z);
    // lateral bob in view space
    cam.position.x += Math.cos(this.yaw) * bobX;
    cam.position.z += -Math.sin(this.yaw) * bobX;
    cam.rotation.order = 'YXZ';
    cam.rotation.set(this.pitch + this.recoilPitch + this.landKick * 0.02, this.yaw + this.recoilYaw, this.camTilt);
  }

  get forward() {
    const v = new THREE.Vector3();
    this.camera.getWorldDirection(v);
    return v;
  }
}
