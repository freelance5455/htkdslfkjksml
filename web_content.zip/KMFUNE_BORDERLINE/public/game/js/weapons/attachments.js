// =====================================================================
// AttachmentRegistry + attachment models
// ---------------------------------------------------------------------
// Each attachment: { id, name, slot, mount, desc, mods, build?, variant? }
//   slot     optic | muzzle | barrel | underbarrel | laser | magazine | stock | grip
//   mount    the socket/interface it needs:
//              'pic'     Picatinny top rail (optics)
//              'thread'  threaded muzzle   'under' bottom rail
//              'side'    side rail          'model' a modelled variant of
//                                           the weapon itself (barrel/mag/
//                                           stock/grip) → `variant` key
//   mods     stat modifiers. Additive points on 0–100 stats
//            (damage, range, control, accuracy, mobility, handling) or
//            multipliers (*Mul) on raw ballistic values.
//   build()  returns { group, meta } in attachment space: origin = the
//            mount interface point (rail top centre / muzzle crown), -Z
//            forward. Optics report meta.axisY (optical axis above the
//            rail), meta.lens, meta.kind ('reflex'|'holo'|'scope'),
//            meta.zoom, meta.eyeZ (rear lens z).
// Names: generic descriptive names. Chinese UI labels legible in the
// reference (e.g. 颗粒后握把 "granular rear grip") are mapped in
// REF_LABELS; nothing is presented as a verified in-game item name
// unless it was legible.
// =====================================================================
import * as THREE from 'three';
import { getShared, finalize, captureRest } from './kit.js';
import { rbox, zcyl, ycyl, xcyl, ztube, railGeo, screwGeo, put, profileGeo } from './refkit.js';
import { makeReflexLens, makeScopeLens } from './optics.js';

const G = () => { const g = new THREE.Group(); return g; };
function done(group, meta = {}) { captureRest(group); finalize(group); return { group, meta }; }
/** Picatinny clamp base standing on the rail top (y = 0). */
function clamp(g, M, len = 0.04, w = 0.03, h = 0.008, mat, z = 0, dir = 1) {
  const c = new THREE.Group(); c.position.z = z; if (dir < 0) c.rotation.z = Math.PI; g.add(c);   // rotate (not mirror) → winding preserved
  put(c, rbox(w, h, len, 0.002), mat || M.blackened(0x17181a), 0, h / 2, 0);
  put(c, rbox(w + 0.004, 0.005, len * 0.6, 0.0015), M.blackened(0x101112), 0, 0.0025, 0);
  put(c, xcyl(0.0035, w + 0.01, 10), M.steel(), 0, 0.004, len * 0.18);
  put(c, screwGeo(0.004, 0.003), M.steel(), w / 2 + 0.004, 0.004, len * 0.18);
}

// ---------------------------------------------------------------- optics
function buildRedDot() {
  const { M } = getShared(); const g = G();
  const body = M.gunmetal(0x232427), dark = M.blackened(0x121314);
  clamp(g, M, 0.036, 0.026, 0.009);
  const Y = 0.026;
  put(g, ztube(0.0175, 0.0145, 0.034, 28), body, 0, Y, 0);
  put(g, ztube(0.0185, 0.0145, 0.005, 28), dark, 0, Y, -0.016);
  put(g, rbox(0.012, 0.012, 0.024, 0.002), body, 0, 0.012, 0);
  put(g, xcyl(0.0055, 0.008, 14), M.steel(), 0.0205, Y, 0.004);
  put(g, ycyl(0.0055, 0.008, 14), body, 0, Y + 0.02, 0.002);
  const lens = makeReflexLens(new THREE.CircleGeometry(0.0145, 32), 'dot', 0xff2a18);
  lens.position.set(0, Y, -0.012); g.add(lens);
  return done(g, { kind: 'reflex', axisY: Y, lens, eyeZ: 0.017 });
}
function buildMiniDot() {
  const { M } = getShared(); const g = G();
  const body = M.gunmetal(0x2a2b2e);
  clamp(g, M, 0.03, 0.024, 0.006);
  // open-emitter mini reflex: angled window on a low base
  put(g, rbox(0.026, 0.008, 0.034, 0.003), body, 0, 0.01, 0);
  const win = new THREE.Shape(); win.moveTo(-0.013, 0); win.lineTo(0.013, 0); win.lineTo(0.011, 0.018); win.quadraticCurveTo(0, 0.022, -0.011, 0.018); win.closePath();
  const hole = new THREE.Path(); hole.moveTo(-0.0105, 0.002); hole.lineTo(0.0105, 0.002); hole.lineTo(0.009, 0.016); hole.quadraticCurveTo(0, 0.0195, -0.009, 0.016); hole.closePath(); win.holes.push(hole);
  const wg = new THREE.ExtrudeGeometry(win, { depth: 0.004, bevelEnabled: false }); wg.translate(0, 0, -0.002);
  put(g, wg, body, 0, 0.013, -0.012);
  const lg = new THREE.PlaneGeometry(0.02, 0.015);
  const lens = makeReflexLens(lg, 'dot', 0xff2a18);
  lens.position.set(0, 0.0215, -0.012); g.add(lens);
  put(g, rbox(0.006, 0.004, 0.006, 0.001), M.blackened(0x0c0c0d), 0, 0.0155, 0.01);   // emitter
  return done(g, { kind: 'reflex', axisY: 0.0215, lens, eyeZ: 0.016 });
}
function buildHolo() {
  const { M } = getShared(); const g = G();
  const body = M.polymer(0x1f2023), dark = M.blackened(0x121314);
  clamp(g, M, 0.08, 0.03, 0.008);
  put(g, rbox(0.034, 0.016, 0.085, 0.004), body, 0, 0.016, 0.005);            // battery housing / base
  // hood: rectangular frame with a real window
  const hood = new THREE.Shape(); hood.moveTo(-0.019, 0); hood.lineTo(0.019, 0); hood.lineTo(0.019, 0.034); hood.quadraticCurveTo(0, 0.04, -0.019, 0.034); hood.closePath();
  const win = new THREE.Path(); win.moveTo(-0.0155, 0.002); win.lineTo(0.0155, 0.002); win.lineTo(0.0155, 0.03); win.quadraticCurveTo(0, 0.035, -0.0155, 0.03); win.closePath(); hood.holes.push(win);
  const hg = new THREE.ExtrudeGeometry(hood, { depth: 0.05, bevelEnabled: true, bevelSize: 0.0012, bevelThickness: 0.0012, bevelSegments: 1 });
  hg.translate(0, 0, -0.025);
  put(g, hg, body, 0, 0.022, -0.01);
  for (const sx of [1, -1]) put(g, rbox(0.003, 0.03, 0.012, 0.001), dark, sx * 0.0175, 0.04, 0.02);
  put(g, xcyl(0.005, 0.01, 12), M.steel(), 0.021, 0.018, 0.03);
  const lens = makeReflexLens(new THREE.PlaneGeometry(0.031, 0.028), 'holo', 0xff2a18);
  const Y = 0.022 + 0.017;
  lens.position.set(0, Y, -0.03); g.add(lens);
  return done(g, { kind: 'holo', axisY: Y, lens, eyeZ: 0.015 });
}
function buildPrism(zoom, eyeRelief = 0.07) {
  const { M } = getShared(); const g = G();
  const body = M.gunmetal(0x26282b), dark = M.blackened(0x111213);
  clamp(g, M, 0.05, 0.03, 0.009);
  const Y = 0.036;
  put(g, rbox(0.03, 0.02, 0.05, 0.004), body, 0, 0.018, 0);
  put(g, zcyl(0.022, 0.016, 0.03, 24), body, 0, Y, -0.04);                    // objective bell
  put(g, rbox(0.036, 0.034, 0.05, 0.006), body, 0, Y, -0.005);                  // prism housing
  put(g, zcyl(0.016, 0.017, 0.022, 24), body, 0, Y, 0.03);                      // eyepiece
  put(g, ztube(0.0235, 0.019, 0.006, 24), dark, 0, Y, -0.057);
  put(g, ycyl(0.008, 0.01, 14), dark, 0, Y + 0.021, -0.005);                    // turret
  put(g, xcyl(0.008, 0.01, 14), dark, 0.021, Y, -0.005);
  const front = new THREE.CircleGeometry(0.019, 28); front.rotateY(Math.PI);
  put(g, front, M.glass(0x20343a), 0, Y, -0.054);
  const lens = makeScopeLens(0.0145, 'acog');
  lens.material.uniforms.uEyeRelief.value = eyeRelief;
  lens.position.set(0, Y, 0.0415); g.add(lens);
  return done(g, { kind: 'scope', axisY: Y, lens, zoom, eyeZ: 0.0415, eyeRelief });
}
function buildSniperScope(zoom) {
  const { M } = getShared(); const g = G();
  const body = M.gunmetal(0x1d1e21), dark = M.blackened(0x0f1011);
  const Y = 0.034;
  // two rings on clamps
  for (const z of [-0.045, 0.045]) {
    clamp(g, M, 0.022, 0.028, 0.008, null, z);
    put(g, rbox(0.024, Y - 0.017 - 0.008, 0.016, 0.003), dark, 0, 0.008 + (Y - 0.025) / 2, z);
    put(g, ztube(0.0195, 0.0152, 0.016, 24), dark, 0, Y, z);
  }
  put(g, zcyl(0.0152, 0.0152, 0.19, 28), body, 0, Y, 0);
  put(g, zcyl(0.028, 0.0152, 0.06, 28, true), body, 0, Y, -0.125);              // objective bell
  put(g, ztube(0.029, 0.025, 0.026, 28), body, 0, Y, -0.165);
  put(g, zcyl(0.0152, 0.02, 0.03, 24), body, 0, Y, 0.11);                        // eyepiece
  put(g, ztube(0.021, 0.0175, 0.03, 24), dark, 0, Y, 0.14);
  put(g, ycyl(0.011, 0.02, 18), dark, 0, Y + 0.022, -0.005);                     // elevation turret
  put(g, xcyl(0.011, 0.02, 18), dark, 0.022, Y, -0.005);                         // windage turret
  put(g, xcyl(0.009, 0.016, 16), dark, -0.02, Y, -0.005);                        // parallax
  put(g, rbox(0.012, 0.006, 0.02, 0.002), M.steel(), 0, Y + 0.011, 0.07);         // power ring lever
  const obj = new THREE.CircleGeometry(0.0255, 32); obj.rotateY(Math.PI);
  put(g, obj, M.glass(0x1a2f36), 0, Y, -0.17);
  const lens = makeScopeLens(0.0175, 'mildot');
  lens.material.uniforms.uEyeRelief.value = 0.085;
  lens.position.set(0, Y, 0.154); g.add(lens);
  return done(g, { kind: 'scope', axisY: Y, lens, zoom, eyeZ: 0.154, eyeRelief: 0.085 });
}

// ---------------------------------------------------------------- muzzle
function buildSuppressor(len, r, square = false) {
  const { M } = getShared(); const g = G();
  const can = M.gunmetal(0x2b2c2f), dark = M.blackened(0x111213);
  put(g, ztube(r * 0.62, r * 0.38, 0.016, 18), dark, 0, 0, -0.008);             // thread collar / mount
  if (square) {
    put(g, rbox(r * 2, r * 2, len, 0.006), can, 0, 0, -0.016 - len / 2);
    for (let i = 0; i < 4; i++) for (const sx of [1, -1]) put(g, rbox(0.0015, r * 1.2, 0.012, 0.001), dark, sx * r, 0, -0.03 - i * (len - 0.03) / 4);
  } else {
    put(g, zcyl(r, r, len, 28), can, 0, 0, -0.016 - len / 2);
    for (let i = 0; i < 3; i++) put(g, ztube(r * 1.012, r * 0.9, 0.004, 28), dark, 0, 0, -0.03 - i * (len - 0.04) / 3);
  }
  put(g, ztube(r * 0.98, 0.006, 0.004, 24), M.blackened(0x070708), 0, 0, -0.016 - len - 0.001);
  return done(g, { length: len + 0.016, suppressed: true });
}
function buildCompensator() {
  const { M } = getShared(); const g = G();
  const body = M.blackened(0x1a1b1d);
  put(g, zcyl(0.0125, 0.0125, 0.055, 18), body, 0, 0, -0.0275);
  for (let i = 0; i < 3; i++) {
    put(g, rbox(0.03, 0.006, 0.007, 0.001), M.blackened(0x060606), 0, 0.006, -0.015 - i * 0.012);  // top ports
    for (const sx of [1, -1]) put(g, rbox(0.006, 0.012, 0.007, 0.001), M.blackened(0x060606), sx * 0.011, 0, -0.015 - i * 0.012);
  }
  return done(g, { length: 0.055 });
}
function buildBrake() {
  const { M } = getShared(); const g = G();
  const body = M.steel(0x6e7277);
  put(g, rbox(0.04, 0.026, 0.06, 0.004), body, 0, 0, -0.03);
  for (let i = 0; i < 2; i++) for (const sx of [1, -1]) put(g, rbox(0.004, 0.02, 0.014, 0.001), M.blackened(0x060606), sx * 0.02, 0, -0.016 - i * 0.026);
  return done(g, { length: 0.06 });
}
function buildFlashHider() {
  const { M } = getShared(); const g = G();
  const body = M.blackened(0x161719);
  put(g, zcyl(0.011, 0.011, 0.012, 16), body, 0, 0, -0.006);
  for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2 + Math.PI / 4; put(g, rbox(0.006, 0.006, 0.034, 0.001), body, Math.cos(a) * 0.009, Math.sin(a) * 0.009, -0.029); }
  return done(g, { length: 0.046 });
}

// ---------------------------------------------------------- underbarrel / laser
function buildVertGrip(short = false) {
  const { M } = getShared(); const g = G();
  // grips hang below the bottom rail: origin = rail surface, body extends -Y
  clamp(g, M, 0.03, 0.026, 0.006, null, 0, -1);
  const L = short ? 0.05 : 0.085;
  put(g, ycyl(0.0135, L, 16, 0.0125), M.polymer(0x1d1e20), 0, -L / 2 - 0.006, 0);
  for (let i = 0; i < 4; i++) put(g, new THREE.TorusGeometry(0.0134, 0.0012, 6, 18), M.blackened(0x101112), 0, -0.02 - i * (L - 0.03) / 4, 0, Math.PI / 2, 0, 0);
  put(g, ycyl(0.015, 0.006, 16), M.blackened(0x121314), 0, -L - 0.008, 0);
  return done(g, { length: L });
}
function buildAngledGrip() {
  const { M } = getShared(); const g = G();
  put(g, profileGeo([[-0.03, 0.0], [0.05, 0.0], [0.045, -0.012], [0.0, -0.04], [-0.02, -0.04], [-0.03, -0.012]], 0.026, 0.004), M.polymer(0x1d1e20), 0, 0, 0);
  return done(g, {});
}
function buildLaser() {
  const { M } = getShared(); const g = G();
  const body = M.polymer(0x1c1d1f);
  put(g, rbox(0.03, 0.006, 0.03, 0.002), M.blackened(0x121314), 0, 0.003, 0);      // clamp (on rail, +Y = away from rail)
  put(g, rbox(0.03, 0.026, 0.06, 0.005), body, 0, 0.019, -0.008);
  put(g, zcyl(0.006, 0.006, 0.006, 14), M.steel(), -0.006, 0.019, -0.04);
  const em = new THREE.CircleGeometry(0.004, 12); em.rotateY(Math.PI);
  put(g, em, M.emissive(0x50ff60, 4), -0.006, 0.019, -0.0435);
  put(g, rbox(0.008, 0.006, 0.01, 0.001), M.paint(0xb3202a), 0.009, 0.033, 0.01);  // switch
  return done(g, { laser: true });
}

// ---------------------------------------------------------------- registry
const A = (id, name, slot, mount, desc, mods, extra = {}) => ({ id, name, slot, mount, desc, mods, ...extra });

export const ATTACHMENTS = {
  // optics
  red_dot:      A('red_dot', 'Tube Red Dot', 'optic', 'pic', '1× tube reflex. Clear sight picture, fast ADS.', { adsTime: -0.02, accuracy: 3 }, { build: buildRedDot }),
  mini_dot:     A('mini_dot', 'Mini Reflex', 'optic', 'pic', 'Open-emitter 1× reflex. Lightest optic.', { adsTime: -0.03, accuracy: 2 }, { build: buildMiniDot }),
  holo:         A('holo', 'Holographic Sight', 'optic', 'pic', '1× holographic ring-dot, large window.', { accuracy: 4, adsTime: 0.0 }, { build: buildHolo }),
  prism2:       A('prism2', '2.0× Combat Optic', 'optic', 'pic', '2× prism sight with chevron reticle.', { accuracy: 6, adsTime: 0.03, mobility: -2 }, { build: () => buildPrism(2, 0.07) }),
  acog4:        A('acog4', '4× Prism Scope', 'optic', 'pic', '4× fixed prism scope.', { accuracy: 9, range: 6, adsTime: 0.05, mobility: -3 }, { build: () => buildPrism(4, 0.07) }),
  scope8:       A('scope8', '8× Precision Scope', 'optic', 'pic', '8× variable rifle scope, mil-dot reticle.', { accuracy: 12, range: 10, adsTime: 0.08, mobility: -4 }, { build: () => buildSniperScope(8), sniper: true }),
  scope12:      A('scope12', '12× Long-Range Scope', 'optic', 'pic', '12× magnification for extreme range.', { accuracy: 14, range: 14, adsTime: 0.11, mobility: -6 }, { build: () => buildSniperScope(12), sniper: true }),
  // muzzle
  flash_hider:  A('flash_hider', 'Flash Hider', 'muzzle', 'thread', 'Reduces muzzle flash.', { control: 2, flashMul: 0.55 }, { build: buildFlashHider }),
  compensator:  A('compensator', 'Compensator', 'muzzle', 'thread', 'Ported device fighting muzzle climb.', { control: 7, hipMul: 1.05, recoilMul: 0.86 }, { build: buildCompensator }),
  brake:        A('brake', 'Muzzle Brake', 'muzzle', 'thread', 'Heavy brake for big calibres.', { control: 9, recoilMul: 0.8, mobility: -2 }, { build: buildBrake }),
  supp_short:   A('supp_short', 'Compact Suppressor', 'muzzle', 'thread', 'Short can. Quieter, no tracer flash.', { range: 3, mobility: -2, adsTime: 0.01, suppressed: true }, { build: () => buildSuppressor(0.1, 0.0175) }),
  supp_long:    A('supp_long', 'Long Suppressor', 'muzzle', 'thread', 'Full-length can. Quietest, adds velocity.', { range: 7, control: 3, mobility: -5, adsTime: 0.025, suppressed: true }, { build: () => buildSuppressor(0.17, 0.019) }),
  supp_square:  A('supp_square', 'Box Suppressor', 'muzzle', 'thread', 'Rectangular-section suppressor.', { range: 5, control: 2, mobility: -4, adsTime: 0.02, suppressed: true }, { build: () => buildSuppressor(0.13, 0.017, true) }),
  // underbarrel
  vgrip:        A('vgrip', 'Vertical Grip', 'underbarrel', 'under', 'Improves vertical recoil control.', { control: 8, mobility: -2, adsTime: 0.01, recoilMul: 0.9 }, { build: () => buildVertGrip(false) }),
  stubby:       A('stubby', 'Stubby Grip', 'underbarrel', 'under', 'Short grip, balanced handling.', { control: 4, accuracy: 3 }, { build: () => buildVertGrip(true) }),
  angled:       A('angled', 'Angled Grip', 'underbarrel', 'under', 'Improves ADS speed.', { adsTime: -0.03, control: 2 }, { build: buildAngledGrip }),
  // laser
  laser:        A('laser', 'Tactical Laser', 'laser', 'side', 'Green laser module: tighter hip-fire.', { accuracy: 6, hipMul: 0.75 }, { build: buildLaser }),
  // modelled variants of the weapon itself
  barrel_long:  A('barrel_long', 'Extended Barrel', 'barrel', 'model', 'Longer barrel: range & velocity, slower handling.', { range: 12, damage: 3, mobility: -5, adsTime: 0.03, control: 3 }, { variant: ['barrel', 'long'] }),
  barrel_short: A('barrel_short', 'Short Barrel', 'barrel', 'model', 'Short barrel: handling over range.', { range: -8, mobility: 6, adsTime: -0.03 }, { variant: ['barrel', 'short'] }),
  barrel_cqc:   A('barrel_cqc', 'CQC Barrel', 'barrel', 'model', '13" barrel for close quarters.', { range: -6, mobility: 5, adsTime: -0.025 }, { variant: ['barrel', 'cqc'] }),
  mag_ext:      A('mag_ext', 'Extended Magazine', 'magazine', 'model', 'Increased capacity, slower reload.', { magMul: 1.5, reloadMul: 1.1, mobility: -2 }, { variant: ['mag', 'ext'] }),
  mag_drum:     A('mag_drum', 'Drum Magazine', 'magazine', 'model', 'High-capacity drum. Heavy.', { magMul: 2.0, reloadMul: 1.3, mobility: -6, adsTime: 0.03 }, { variant: ['mag', 'drum'] }),
  stock_tac:    A('stock_tac', 'Tactical Stock', 'stock', 'model', 'Adjustable cheek riser: stability.', { control: 6, accuracy: 3, mobility: -2 }, { variant: ['stock', 'tac'] }),
  stock_fold:   A('stock_fold', 'Folded Stock', 'stock', 'model', 'Stock folded: mobility over control.', { control: -10, mobility: 8, adsTime: -0.04, hipMul: 0.9 }, { variant: ['stock', 'folded'] }),
  stock_comp:   A('stock_comp', 'Composite Stock', 'stock', 'model', 'Fixed composite butt.', { control: 4, mobility: -1 }, { variant: ['stock', 'composite'] }),
  stock_cheek:  A('stock_cheek', 'Cheek Riser', 'stock', 'model', 'Raised cheek weld.', { accuracy: 4, control: 2 }, { variant: ['stock', 'cheek'] }),
  stock_pad:    A('stock_pad', 'Thick Butt Pad', 'stock', 'model', 'Thicker recoil pad.', { control: 4 }, { variant: ['stock', 'pad'] }),
  stock_compact:A('stock_compact', 'Compact Stock', 'stock', 'model', 'Shortened stock.', { control: -3, mobility: 4, adsTime: -0.02 }, { variant: ['stock', 'compact'] }),
  grip_striped: A('grip_striped', 'Striped Rear Grip', 'grip', 'model', 'Ribbed texture: ADS speed.', { adsTime: -0.02, mobility: 2 }, { variant: ['grip', 'striped'], ref: '条纹后握把' }),
  grip_spotted: A('grip_spotted', 'Spotted Rear Grip', 'grip', 'model', 'Dot texture: recoil stability.', { control: 3, adsTime: 0.01 }, { variant: ['grip', 'spotted'], ref: '斑点后握把' }),
  grip_granular:A('grip_granular', 'Granular Rear Grip', 'grip', 'model', 'Granular texture: faster ADS & sprint-to-fire.', { adsTime: -0.03, mobility: 3, control: -2 }, { variant: ['grip', 'granular'], ref: '颗粒后握把' }),
};

export const SLOT_ORDER = ['optic', 'muzzle', 'barrel', 'underbarrel', 'laser', 'magazine', 'stock', 'grip'];
export const SLOT_LABELS = { optic: 'OPTIC', muzzle: 'MUZZLE', barrel: 'BARREL', underbarrel: 'UNDERBARREL', laser: 'LASER', magazine: 'MAGAZINE', stock: 'STOCK', grip: 'REAR GRIP' };
/** Reference UI labels legible in the video (Chinese) → slot. */
export const REF_LABELS = { 瞄具: 'optic', 枪口: 'muzzle', 枪管: 'barrel', 前握把: 'underbarrel', 弹匣: 'magazine', 枪托: 'stock', 后握把: 'grip', 镭射: 'laser' };

export const AttachmentRegistry = {
  get: (id) => ATTACHMENTS[id] || null,
  all: () => Object.values(ATTACHMENTS),
  forSlot: (slot) => Object.values(ATTACHMENTS).filter((a) => a.slot === slot),
  build(id) { const a = ATTACHMENTS[id]; return a && a.build ? a.build() : null; },
};
