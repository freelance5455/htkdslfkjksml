// =====================================================================
// Gunsmith core: AttachmentCompatibility, WeaponConfiguration,
// WeaponStatistics, WeaponAssembler, LoadoutManager.
// ---------------------------------------------------------------------
// * A configuration is { weaponId, att: { slot: attachmentId|null } }.
// * The assembler builds the weapon model (with modelled variants) and
//   mounts attachment models on the weapon's sockets. Optics replace the
//   iron-sight meta so ADS aligns to the optic's real optical axis.
// * effectiveDef() produces a per-configuration copy of the weapon
//   definition with the attachment modifiers applied to the values the
//   gameplay code actually uses (spread, recoil, ADS time, range/falloff,
//   magazine size, reload time, movement) → attachments change gameplay.
// * Display stats (0–100) are derived from the same modified values.
// =====================================================================
import * as THREE from 'three';
import { ATTACHMENTS, SLOT_ORDER } from './attachments.js';
import { WeaponRegistry, ALL_WEAPONS } from './registry.js';
import { BUILDERS } from './models.js';
import { captureRest } from './kit.js';

const clamp01 = (v) => Math.max(0, Math.min(100, v));

// ---------------- AttachmentCompatibility ----------------
export const AttachmentCompatibility = {
  slotsFor(def) { return SLOT_ORDER.filter((s) => def.slots && def.slots[s] && def.slots[s].length); },
  isCompatible(def, attId) {
    const a = ATTACHMENTS[attId];
    if (!a || !def.slots) return false;
    return (def.slots[a.slot] || []).includes(attId);
  },
  /** Validates a whole configuration, returning a cleaned copy. */
  sanitize(def, att = {}) {
    const out = {};
    for (const slot of SLOT_ORDER) {
      const id = att[slot];
      if (id && this.isCompatible(def, id)) out[slot] = id;
    }
    if (def.defaults) for (const [slot, id] of Object.entries(def.defaults)) if (!out[slot] && att[slot] !== null) out[slot] = id;
    // precision rifles with no iron sights must keep an optic
    if (!out.optic && def.slots?.optic && def.defaults?.optic) out.optic = def.defaults.optic;
    return out;
  },
  /** Reason a slot can't be emptied (or null). */
  lockReason(def, slot) {
    if (slot === 'optic' && def.defaults?.optic && !def.legacy) return 'This rifle has no iron sights — an optic is required.';
    return null;
  },
};

// ---------------- WeaponConfiguration ----------------
export class WeaponConfiguration {
  constructor(weaponId, att = {}) {
    this.weaponId = weaponId;
    this.def = WeaponRegistry.get(weaponId);
    this.att = AttachmentCompatibility.sanitize(this.def, att);
  }
  clone() { return new WeaponConfiguration(this.weaponId, { ...this.att }); }
  with(slot, attId) {
    const c = this.clone();
    if (attId) c.att[slot] = attId; else { delete c.att[slot]; c.att[slot] = null; }
    c.att = AttachmentCompatibility.sanitize(c.def, c.att);
    return c;
  }
  get attachments() { return Object.values(this.att).filter(Boolean).map((id) => ATTACHMENTS[id]); }
  /** Model-variant config passed to the builder. */
  variants() {
    const v = { folded: !!this.att.optic };
    for (const a of this.attachments) if (a.variant) v[a.variant[0]] = a.variant[1];
    return v;
  }
  key() { return this.weaponId + '|' + SLOT_ORDER.map((s) => this.att[s] || '-').join(','); }
  toJSON() { return { weaponId: this.weaponId, att: { ...this.att } }; }
}

// ---------------- WeaponStatistics ----------------
export const WeaponStatistics = {
  /** Sum attachment modifiers. */
  mods(cfg) {
    const m = { damage: 0, range: 0, control: 0, accuracy: 0, mobility: 0, adsTime: 0, recoilMul: 1, hipMul: 1, magMul: 1, reloadMul: 1, flashMul: 1, suppressed: false };
    for (const a of cfg.attachments) {
      for (const [k, v] of Object.entries(a.mods)) {
        if (k.endsWith('Mul')) m[k] *= v;
        else if (k === 'suppressed') m.suppressed = m.suppressed || v;
        else m[k] = (m[k] || 0) + v;
      }
    }
    return m;
  },
  /** Display stats (reference categories) for a configuration. */
  display(cfg) {
    const b = cfg.def.base, m = this.mods(cfg), e = effectiveDef(cfg);
    return {
      damage: clamp01(b.damage + m.damage), range: clamp01(b.range + m.range), control: clamp01(b.control + m.control),
      accuracy: clamp01(b.accuracy + m.accuracy), mobility: clamp01(b.mobility + m.mobility), rof: clamp01(b.rof),
      // raw readouts (like the reference's lower block)
      rpm: e.rpm, magSize: e.magSize, adsMs: Math.round(e.ads.time * 1000), reload: e.reload.tactical ? e.reload.tactical.time : null,
      fireMode: e.fireModes[0], zoom: e.zoom || 1, rangeM: e.falloff[0],
    };
  },
  /** Per-stat deltas between two configurations (for preview colouring). */
  delta(a, b) {
    const A = this.display(a), B = this.display(b), d = {};
    for (const k of ['damage', 'range', 'control', 'accuracy', 'mobility', 'rof', 'magSize', 'adsMs', 'reload', 'rpm']) d[k] = (B[k] ?? 0) - (A[k] ?? 0);
    return d;
  },
};

// ---------------- effective definition (gameplay) ----------------
const effCache = new Map();
export function effectiveDef(cfg) {
  const key = cfg.key();
  if (effCache.has(key)) return effCache.get(key);
  const d = cfg.def, m = WeaponStatistics.mods(cfg);
  const e = structuredCloneDef(d);
  e.config = cfg.toJSON();
  e.damage = Math.round(d.damage * (1 + m.damage / 100) * 10) / 10;
  const rangeK = 1 + m.range / 60;
  e.falloff = [d.falloff[0] * rangeK, d.falloff[1] * rangeK, d.falloff[2]];
  e.range = d.range * Math.max(1, rangeK);
  const accK = 1 - m.accuracy / 120;                       // + accuracy → tighter spread
  e.spread = d.spread * accK * m.hipMul;
  e.moveSpread = d.moveSpread * accK * m.hipMul;
  e.adsSpread = d.adsSpread * accK;
  const ctrlK = (1 - m.control / 100) * m.recoilMul;       // + control → less recoil
  e.recoil = { ...d.recoil, pitch: d.recoil.pitch * ctrlK, yaw: d.recoil.yaw * ctrlK, kickBack: d.recoil.kickBack * ctrlK, kickUp: d.recoil.kickUp * ctrlK, recover: d.recoil.recover * (1 + m.control / 200) };
  e.ads = { ...d.ads, time: Math.max(0.08, d.ads.time + m.adsTime) };
  e.mobilityMul = 1 + m.mobility / 200;                    // player movement multiplier
  e.equip = d.equip * (1 - m.mobility / 250); e.unequip = d.unequip * (1 - m.mobility / 250);
  if (d.reload.type === 'mag') {
    e.magSize = Math.round(d.magSize * m.magMul);
    e.reserve = Math.round(d.reserve * m.magMul);
    e.reload = { ...d.reload, tactical: { ...d.reload.tactical, time: d.reload.tactical.time * m.reloadMul }, empty: { ...d.reload.empty, time: d.reload.empty.time * m.reloadMul } };
  }
  e.suppressed = m.suppressed;
  e.flashMul = m.flashMul * (m.suppressed ? 0.15 : 1);
  if (m.suppressed) { e.shotVolume = d.shotVolume * 0.55; e.suppressedLowpass = 2400; }
  const optic = cfg.att.optic ? ATTACHMENTS[cfg.att.optic] : null;
  e.zoom = 1;
  if (optic) {
    const zoom = { prism2: 2, acog4: 4, scope8: 8, scope12: 12 }[optic.id] || 1;
    e.zoom = zoom;
    if (zoom > 1) e.ads = { ...e.ads, scope: true, fov: d.ads.scope ? d.ads.fov : 58, vmFov: zoom >= 8 ? 38 : 42 };
    else e.ads = { ...e.ads, scope: false, fov: Math.min(d.ads.scope ? 62 : d.ads.fov, 64), vmFov: 48 };
  }
  e.stats = { damage: (d.base.damage + m.damage) / 100, rof: d.base.rof / 100, range: (d.base.range + m.range) / 100, handling: (d.base.mobility + m.mobility) / 100 };
  effCache.set(key, e);
  return e;
}
function structuredCloneDef(d) {
  // functions (build) are shared; data is copied shallowly per level used
  const e = { ...d };
  e.recoil = { ...d.recoil }; e.ads = { ...d.ads }; e.hip = { ...d.hip }; e.sprint = { ...d.sprint };
  e.reload = { ...d.reload };
  return e;
}

// ---------------- WeaponAssembler (model + mounted attachments) ----------------
const _v = new THREE.Vector3();
export function assembleModel(cfg) {
  const def = cfg.def;
  const model = def.build ? def.build(cfg.variants()) : BUILDERS[def.builder]();
  const S = model.sockets, root = model.root;
  model.attachments = {};
  for (const slot of SLOT_ORDER) {
    const id = cfg.att[slot]; if (!id) continue;
    const a = ATTACHMENTS[id]; if (!a || !a.build) continue;          // model variants are already built in
    const sockName = (def.mountOverrides && def.mountOverrides[slot]) || { optic: 'optic', muzzle: 'muzzle', underbarrel: 'underbarrel', laser: 'laser' }[slot];
    const sock = S[sockName];
    if (!sock) { console.warn('[gunsmith] missing socket', sockName, def.id); continue; }
    const built = a.build();
    built.group.name = 'att_' + id;
    built.group.userData.part = true;
    // sockets are children of the AttachmentPoints group (static) → mount there
    sock.add(built.group);
    if (sockName === 'laser' && def.mountOverrides?.laser === 'underbarrel') built.group.rotation.z = Math.PI;
    model.attachments[slot] = { def: a, group: built.group, meta: built.meta };
  }
  // ---- optic → ADS meta (eye line through the optic's optical axis) ----
  const op = model.attachments.optic;
  if (op) {
    const sp = S.optic.position;
    const axisY = sp.y + op.meta.axisY, eyeZ = sp.z + op.meta.eyeZ;
    if (op.meta.kind === 'scope') {
      model.meta = { ...model.meta, rearSight: null, frontSight: null, reticle: null, scopeEye: new THREE.Vector3(0, axisY, eyeZ), eyeRelief: op.meta.eyeRelief, lens: op.meta.lens, zoom: op.meta.zoom, sightType: 'scope' };
    } else {
      model.meta = { ...model.meta, rearSight: null, frontSight: null, scopeEye: null, reticle: new THREE.Vector3(0, axisY, sp.z), lens: op.meta.lens, sightType: op.meta.kind };
    }
  }
  // muzzle socket moves to the end of the muzzle device (flash & tracer origin)
  const mz = model.attachments.muzzle;
  if (mz && mz.meta.length) {
    const tip = new THREE.Object3D(); tip.name = 'muzzleTip'; tip.position.set(0, 0, -mz.meta.length); S.muzzle.add(tip);
    model.sockets = { ...S, muzzle: tip, muzzleBase: S.muzzle };
  }
  model.meta.suppressed = !!(mz && mz.meta.suppressed);
  captureRest(root);
  root.traverse((o) => { if (o.isMesh) { o.frustumCulled = false; } });
  void _v;
  return model;
}

/** Frees GPU geometry for a model that will never be shown again (shared materials are kept). */
export function disposeModel(model) {
  if (!model) return;
  model.root.removeFromParent();
  model.root.traverse((o) => {
    if (!o.isMesh) return;
    o.geometry?.dispose();
    if (o.material && o.material.isShaderMaterial) o.material.dispose();   // per-lens materials
  });
}

// ---------------- LoadoutManager (persisted gunsmith builds) ----------------
const KEY = 'kmfune.borderline.gunsmith.v1';
export const LoadoutManager = {
  _data: null,
  load() {
    if (this._data) return this._data;
    let d = null;
    try { d = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch { d = null; }
    this._data = d && typeof d === 'object' ? d : { builds: {} };
    if (!this._data.builds) this._data.builds = {};
    return this._data;
  },
  save() { try { localStorage.setItem(KEY, JSON.stringify(this._data)); } catch { /* storage unavailable */ } },
  config(weaponId) {
    const d = this.load();
    return new WeaponConfiguration(weaponId, d.builds[weaponId] || {});
  },
  store(cfg) { const d = this.load(); d.builds[cfg.weaponId] = { ...cfg.att }; this.save(); },
  reset(weaponId) { const d = this.load(); delete d.builds[weaponId]; this.save(); },
};

export { ALL_WEAPONS };
