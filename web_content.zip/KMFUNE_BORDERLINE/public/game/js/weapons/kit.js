// =====================================================================
// Weapon construction kit
// ---------------------------------------------------------------------
// Weapon space (metres): origin = top of pistol grip / trigger area,
// -Z = muzzle direction, +Y = up, +X = weapon's right side.
//
// `profileGeo()` extrudes a side-view silhouette [[forward, up], ...] across
// the weapon's width with a bevel, so receivers, stocks, grips, magazines
// and handguards are custom silhouettes rather than plain boxes.
// `finalize()` merges static meshes per material inside each animated
// sub-group (pivot) → few draw calls, while moving parts stay articulated.
// =====================================================================
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { gunMat } from '../render/toon.js';
import { wearTextures, woodTexture, gripTexture, fabricTexture, camoTexture } from '../render/textures.js';

let SHARED = null;

export function getShared(quality = 2) {
  if (SHARED) return SHARED;
  const wear = wearTextures(quality, 17);
  for (const t of [wear.map, wear.roughnessMap, wear.normalMap]) t.repeat.set(3, 3);
  const wood = woodTexture(quality, [150, 92, 48], 5);
  const woodRed = woodTexture(quality, [122, 62, 38], 8);
  const grip = gripTexture(quality); grip.map.repeat.set(3, 3); grip.normalMap.repeat.set(3, 3);
  const fabric = fabricTexture(quality); fabric.map.repeat.set(2, 2);
  const camo = camoTexture(quality); camo.map.repeat.set(1.4, 1.4);
  const cache = new Map();
  const mat = (key, params) => {
    if (cache.has(key)) return cache.get(key);
    const m = gunMat(params); m.name = key; cache.set(key, m); return m;
  };
  const M = {
    gunmetal: (c = 0x3a3d41) => mat('gunmetal' + c, { color: c, map: wear.map, roughnessMap: wear.roughnessMap, normalMap: wear.normalMap, normalScale: new THREE.Vector2(0.4, 0.4), roughness: 0.55, metalness: 0.8 }),
    steel: (c = 0x8e9399) => mat('steel' + c, { color: c, map: wear.map, roughnessMap: wear.roughnessMap, roughness: 0.38, metalness: 0.95 }),
    blackened: (c = 0x1d1e20) => mat('black' + c, { color: c, map: wear.map, roughnessMap: wear.roughnessMap, roughness: 0.62, metalness: 0.6 }),
    paint: (c) => mat('paint' + c, { color: c, map: wear.map, roughnessMap: wear.roughnessMap, normalMap: wear.normalMap, normalScale: new THREE.Vector2(0.3, 0.3), roughness: 0.58, metalness: 0.15 }),
    polymer: (c) => mat('poly' + c, { color: c, map: wear.map, roughness: 0.75, metalness: 0.0 }),
    rubber: (c = 0x232426) => mat('rubber' + c, { color: c, map: grip.map, normalMap: grip.normalMap, roughness: 0.92, metalness: 0 }),
    wood: () => mat('wood', { map: wood.map, normalMap: wood.normalMap, normalScale: new THREE.Vector2(0.5, 0.5), roughness: 0.6, metalness: 0 }),
    woodRed: () => mat('woodRed', { map: woodRed.map, normalMap: woodRed.normalMap, normalScale: new THREE.Vector2(0.5, 0.5), roughness: 0.55, metalness: 0 }),
    brass: () => mat('brass', { color: 0xc8963c, roughness: 0.3, metalness: 1.0 }),
    copper: () => mat('copper', { color: 0xb5653a, map: wear.map, roughness: 0.4, metalness: 0.95 }),
    bronze: () => mat('bronze', { color: 0x9a6a36, map: wear.map, roughness: 0.42, metalness: 0.9 }),
    fabric: (c = 0xe2d6ba) => mat('fabric' + c, { color: c, map: fabric.map, roughness: 1.0, metalness: 0 }),
    camo: () => mat('camo', { map: camo.map, roughnessMap: wear.roughnessMap, roughness: 0.62, metalness: 0.1 }),
    glass: (c = 0x1c2b26) => mat('glass' + c, { color: c, roughness: 0.05, metalness: 0.9, envMapIntensity: 1.6 }),
    emissive: (c, i = 3) => {
      const key = 'emi' + c + i;
      if (cache.has(key)) return cache.get(key);
      const m = new THREE.MeshBasicMaterial({ color: new THREE.Color(c).multiplyScalar(i) });
      m.name = key; cache.set(key, m); return m;
    },
    shellRed: () => mat('shellRed', { color: 0xc8231c, roughness: 0.45, metalness: 0.05 }),
    glove: () => mat('glove', { color: 0x2c2e33, map: grip.map, roughness: 0.85, metalness: 0.05 }),
    gloveWhite: () => mat('gloveW', { color: 0xdedbd2, map: wear.map, roughness: 0.6, metalness: 0.1 }),
    sleeve: () => mat('sleeve', { color: 0x6b4a32, map: fabric.map, roughness: 1, metalness: 0 }),
  };
  SHARED = { M };
  return SHARED;
}

// ------------------------------------------------------------------ //
// Geometry helpers
// ------------------------------------------------------------------ //
export function boxUV(g, scale = 6) {
  if (!g.attributes.normal) g.computeVertexNormals();
  const pos = g.attributes.position, nrm = g.attributes.normal;
  let uv = g.attributes.uv;
  if (!uv || uv.count !== pos.count) { uv = new THREE.BufferAttribute(new Float32Array(pos.count * 2), 2); g.setAttribute('uv', uv); }
  for (let i = 0; i < pos.count; i++) {
    const ax = Math.abs(nrm.getX(i)), ay = Math.abs(nrm.getY(i)), az = Math.abs(nrm.getZ(i));
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    if (ax >= ay && ax >= az) uv.setXY(i, z * scale, y * scale);
    else if (ay >= az) uv.setXY(i, x * scale, z * scale);
    else uv.setXY(i, x * scale, y * scale);
  }
  uv.needsUpdate = true;
  return g;
}

function extrude(shape, width, bevel, curveSegments) {
  const depth = Math.max(0.0005, width - bevel * 2);
  const g = new THREE.ExtrudeGeometry(shape, {
    depth, bevelEnabled: bevel > 0, bevelThickness: bevel, bevelSize: bevel, bevelSegments: bevel > 0 ? 2 : 0, curveSegments,
  });
  g.translate(0, 0, -depth / 2);
  // shape (f, u) extruded along +Z (w). rotateY(+90°): x' = w, z' = -f
  // → forward maps to -Z without mirroring (winding & normals preserved).
  g.rotateY(Math.PI / 2);
  boxUV(g, 6);
  return g;
}

/** Side-profile extrusion. pts = [[forward, up], ...]; width across X. */
export function profileGeo(pts, width, bevel = 0.003, curveSegments = 4) {
  const shape = new THREE.Shape();
  pts.forEach(([f, u], i) => (i === 0 ? shape.moveTo(f, u) : shape.lineTo(f, u)));
  shape.closePath();
  return extrude(shape, width, bevel, curveSegments);
}
/** Same, from a THREE.Shape (curves / holes allowed; shape coords = forward, up). */
export function shapeGeo(shape, width, bevel = 0.003, curveSegments = 10) { return extrude(shape, width, bevel, curveSegments); }

export function rbox(w, h, d, r = 0.004, seg = 2) {
  const g = new RoundedBoxGeometry(w, h, d, seg, Math.max(0.0002, Math.min(r, w / 2 - 1e-4, h / 2 - 1e-4, d / 2 - 1e-4)));
  return boxUV(g, 6);
}
/** Cylinder along Z (radius rFront at -Z end). */
export function zcyl(rFront, rBack, len, seg = 20, open = false) {
  const g = new THREE.CylinderGeometry(rFront, rBack, len, seg, 1, open);
  g.rotateX(-Math.PI / 2);
  return g;
}
export function xcyl(r, len, seg = 16) { const g = new THREE.CylinderGeometry(r, r, len, seg); g.rotateZ(Math.PI / 2); return g; }
export function ycyl(r, len, seg = 16, r2) { return new THREE.CylinderGeometry(r, r2 ?? r, len, seg); }
/** Lathe along -Z: pts = [[forwardDistance, radius]] */
export function zlathe(pts, seg = 24) {
  const g = new THREE.LatheGeometry(pts.map(([z, r]) => new THREE.Vector2(Math.max(0, r), z)), seg);
  g.rotateX(-Math.PI / 2);
  return g;
}
/** Hollow tube along Z with real wall thickness. */
export function ztube(rOuter, rInner, len, seg = 24) {
  return zlathe([[-len / 2, rInner], [-len / 2, rOuter], [len / 2, rOuter], [len / 2, rInner], [-len / 2, rInner]], seg);
}
/** Picatinny-style rail centred at origin, along Z. */
export function railGeo(length, width = 0.022, height = 0.009) {
  const parts = [];
  const base = rbox(width, height * 0.55, length, 0.0015); base.translate(0, height * 0.275, 0); parts.push(base);
  const n = Math.max(2, Math.floor(length / 0.01));
  for (let i = 0; i < n; i++) {
    const t = rbox(width * 1.12, height * 0.5, 0.0055, 0.001, 1);
    t.translate(0, height * 0.75, -length / 2 + (i + 0.5) * (length / n));
    parts.push(t);
  }
  return merge(parts);
}
/** Screw head facing ±X. */
export function screwGeo(r = 0.0035, depth = 0.0018) { const g = new THREE.CylinderGeometry(r, r * 1.1, depth, 10); g.rotateZ(Math.PI / 2); return g; }
/** N thin boxes spaced along an axis. */
export function ribsGeo(n, size, step, axis = 'z') {
  const parts = [];
  for (let i = 0; i < n; i++) {
    const g = new THREE.BoxGeometry(size[0], size[1], size[2]);
    const o = (i - (n - 1) / 2) * step;
    g.translate(axis === 'x' ? o : 0, axis === 'y' ? o : 0, axis === 'z' ? o : 0);
    parts.push(g);
  }
  return merge(parts);
}
export function merge(geos) {
  const list = geos.map((g) => {
    const n = g.index ? g.toNonIndexed() : g;
    for (const k of Object.keys(n.attributes)) if (!['position', 'normal', 'uv'].includes(k)) n.deleteAttribute(k);
    if (!n.attributes.uv) boxUV(n);
    if (!n.attributes.normal) n.computeVertexNormals();
    return n;
  });
  return mergeGeometries(list, false);
}

// ------------------------------------------------------------------ //
// Assembly helpers
// ------------------------------------------------------------------ //
export function put(parent, geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, name) {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z); m.rotation.set(rx, ry, rz);
  if (name) m.name = name;
  parent.add(m);
  return m;
}
export function pivot(parent, name, x = 0, y = 0, z = 0) {
  const g = new THREE.Group();
  g.name = name; g.position.set(x, y, z); g.userData.part = true;
  g.userData.rest = { p: g.position.clone(), r: g.rotation.clone() };
  parent.add(g);
  return g;
}
export function socket(parent, name, x = 0, y = 0, z = 0) {
  const o = new THREE.Object3D();
  o.name = name; o.position.set(x, y, z); o.userData.socket = true;
  parent.add(o);
  return o;
}
/** Store the rest pose of every pivot (call after placement). */
export function captureRest(root) {
  root.traverse((o) => { if (o.userData.part) o.userData.rest = { p: o.position.clone(), r: o.rotation.clone() }; });
}

/** Merge static meshes per material inside each pivot group. */
export function finalize(root) {
  const groups = [root];
  root.traverse((o) => { if (o !== root && o.userData.part) groups.push(o); });
  root.updateMatrixWorld(true);
  for (const g of groups) {
    const byMat = new Map();
    const victims = [];
    const visit = (node) => {
      for (const child of node.children) {
        if (child.userData.part || child.userData.socket || child.userData.keep) continue;
        if (child.isMesh) victims.push(child);
        visit(child);
      }
    };
    visit(g);
    const inv = new THREE.Matrix4().copy(g.matrixWorld).invert();
    for (const m of victims) {
      const geo = m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone();
      for (const k of Object.keys(geo.attributes)) if (!['position', 'normal', 'uv'].includes(k)) geo.deleteAttribute(k);
      if (!geo.attributes.uv) boxUV(geo);
      geo.applyMatrix4(new THREE.Matrix4().multiplyMatrices(inv, m.matrixWorld));
      const key = m.material.uuid;
      if (!byMat.has(key)) byMat.set(key, { mat: m.material, geos: [] });
      byMat.get(key).geos.push(geo);
    }
    for (const m of victims) { m.parent.remove(m); m.geometry.dispose(); }
    for (const { mat, geos } of byMat.values()) {
      const merged = mergeGeometries(geos, false);
      geos.forEach((x) => x.dispose());
      if (!merged) continue;
      merged.computeBoundingSphere();
      const mesh = new THREE.Mesh(merged, mat);
      mesh.name = 'merged_' + (mat.name || 'm');
      g.add(mesh);
    }
  }
  root.traverse((o) => { if (o.isMesh) { o.castShadow = false; o.receiveShadow = false; o.frustumCulled = false; } });
  return root;
}

// ------------------------------------------------------------------ //
// Ammunition geometry
// ------------------------------------------------------------------ //
/** Rifle cartridge along -Z, base at z=0. */
export function cartridgeGeo(len = 0.056, r = 0.0055, tip = 0.38) {
  const caseLen = len * (1 - tip);
  return zlathe([
    [0, 0], [0, r * 0.9], [0.002, r * 0.9], [0.0028, r * 0.74], [0.0042, r], [caseLen * 0.8, r], [caseLen, r * 0.62],
    [caseLen + 0.001, r * 0.6], [caseLen + len * tip * 0.55, r * 0.5], [len, 0.0006], [len, 0],
  ], 12);
}
export function cartridgeCaseGeo(len, r, tip) {
  const caseLen = len * (1 - tip);
  return zlathe([[0, 0], [0, r * 0.9], [0.002, r * 0.9], [0.0028, r * 0.74], [0.0042, r], [caseLen * 0.8, r], [caseLen, r * 0.62], [caseLen, 0]], 12);
}
export function projectileGeo(len, r, tip) {
  const caseLen = len * (1 - tip);
  return zlathe([[caseLen, 0], [caseLen, r * 0.6], [caseLen + len * tip * 0.55, r * 0.5], [len, 0.0006], [len, 0]], 12);
}
/** Shotgun shell along -Z: brass head + hull. */
export function shellGeos(len = 0.065, r = 0.0105) {
  const brass = zlathe([[0, 0], [0, r * 1.08], [0.003, r * 1.08], [0.003, r * 1.0], [0.016, r * 1.0], [0.016, 0]], 16);
  const hull = zlathe([[0.016, 0], [0.016, r * 0.97], [len - 0.004, r * 0.97], [len, r * 0.72], [len, 0]], 16);
  return { brass, hull };
}
