// =====================================================================
// Reference weapons (ECC: Redline gunsmith footage) — individual models
// ---------------------------------------------------------------------
// Every builder is a separate, hand-laid procedural model with its own
// silhouette, proportions and functional parts. Builders take a config
//   { barrel, mag, stock, grip, folded }
// where barrel/mag/stock/grip select *modelled* variants (not scaling),
// and `folded` flips the back-up iron sights flat when an optic is fitted.
//
// Hierarchy (each a named group; static meshes merged per material inside):
//   MainBody / BarrelAssembly / HandguardAssembly / StockAssembly /
//   MagazineAssembly(mag pivot) / SightMounts / MovingParts(bolt, charge,
//   trigger, cover…) / AttachmentPoints(sockets: optic, muzzle,
//   underbarrel, laser, hands, ejection, magWell)
//
// Weapon space: origin = top of the pistol grip, -Z = muzzle, metres.
// Profiles are [[forward, up], …] (forward f → z = -f).
// =====================================================================
import * as THREE from 'three';
import { getShared, finalize, captureRest, socket, shellGeos } from './kit.js';
import {
  keep, smokeMat, pistolGrip, triggerGroup, topRail, sideRail, flipIrons, boxMag, drumMag, barrel, crown,
  profileGeo, shapeGeo, rbox, zcyl, ycyl, xcyl, ztube, railGeo, screwGeo, put, pivot, cartridgeGeo,
} from './refkit.js';

// ---------- small helpers ----------
function asm(root, name) {
  const g = new THREE.Group(); g.name = name; g.userData.part = true;
  g.userData.rest = { p: g.position.clone(), r: g.rotation.clone() };
  root.add(g); return g;
}
function groups(root) {
  return {
    body: asm(root, 'MainBody'), barrelA: asm(root, 'BarrelAssembly'), hg: asm(root, 'HandguardAssembly'),
    stock: asm(root, 'StockAssembly'), magA: asm(root, 'MagazineAssembly'), sights: asm(root, 'SightMounts'),
    moving: asm(root, 'MovingParts'), points: new THREE.Group(),
  };
}
function rrPath(f0, u0, f1, u1, r, PathT = THREE.Path) {
  const p = new PathT();
  p.moveTo(f0 + r, u0); p.lineTo(f1 - r, u0); p.quadraticCurveTo(f1, u0, f1, u0 + r);
  p.lineTo(f1, u1 - r); p.quadraticCurveTo(f1, u1, f1 - r, u1); p.lineTo(f0 + r, u1);
  p.quadraticCurveTo(f0, u1, f0, u1 - r); p.lineTo(f0, u0 + r); p.quadraticCurveTo(f0, u0, f0 + r, u0);
  return p;
}
function polyShape(pts, holes = []) {
  const s = new THREE.Shape();
  pts.forEach(([f, u], i) => (i === 0 ? s.moveTo(f, u) : s.lineTo(f, u)));
  s.closePath(); holes.forEach((h) => s.holes.push(h));
  return s;
}
/** Grip texture variants on an integral grip column (both sides). */
function gripDecor(g, M, variant, { f0, f1, u0, u1, x }) {
  if (!variant || variant === 'std') return;
  const dark = M.blackened(0x141518);
  for (const sx of [1, -1]) {
    if (variant === 'striped') {
      for (let u = u0 + 0.006; u < u1 - 0.004; u += 0.011) put(g, rbox(0.0016, 0.0032, f1 - f0 - 0.008, 0.0008), dark, sx * x, u, -(f0 + f1) / 2);
    } else {
      const big = variant === 'spotted';
      const geo = big ? new THREE.SphereGeometry(0.0026, 8, 6) : new THREE.IcosahedronGeometry(0.0013, 0);
      const step = big ? 0.009 : 0.0055;
      for (let u = u0 + 0.005; u < u1 - 0.003; u += step) for (let f = f0 + 0.005; f < f1 - 0.003; f += step) put(g, geo, M.rubber(0x2c2a27), sx * x, u, -f);
    }
  }
}
function finish(root, G, parts, s, rounds, meta) {
  root.add(G.points);
  G.points.userData.socket = true;
  captureRest(root);
  finalize(root);
  return { root, parts, sockets: s, rounds, meta };
}
function sock(G, defs) {
  const out = {};
  for (const [k, v] of Object.entries(defs)) {
    const parent = v[3] || G.points;
    out[k] = socket(parent, k, v[0], v[1], v[2]);
    if (v[4]) out[k].rotation.z = v[4];
  }
  return out;
}

// ====================================================================
// VECTOR — .45 SMG, Super-V receiver (KRISS Vector) — CONFIRMED (0:00-0:59)
// ====================================================================
export function buildVector(cfg = {}) {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'Vector';
  const G = groups(root);
  const poly = M.polymer(0x1c1d20), dark = M.blackened(0x141517), steel = M.steel(0x6c7076), alu = M.gunmetal(0x2a2c30);
  // upper receiver
  put(G.body, profileGeo([[-0.085, 0.03], [0.25, 0.03], [0.265, 0.045], [0.265, 0.074], [0.24, 0.082], [-0.07, 0.082], [-0.088, 0.068]], 0.048, 0.004), poly);
  // Super-V lower: drops ahead of the trigger guard into the angled magazine well
  put(G.body, profileGeo([[0.015, 0.035], [0.2, 0.035], [0.196, 0.0], [0.168, -0.072], [0.07, -0.072], [0.052, -0.026], [0.018, -0.006]], 0.05, 0.004), poly);
  put(G.body, rbox(0.03, 0.006, 0.09, 0.002), dark, 0, -0.07, -0.118);                 // magwell lip
  for (const sx of [1, -1]) {
    put(G.body, rbox(0.0012, 0.004, 0.27, 0.0005), dark, sx * 0.0245, 0.05, -0.09);   // panel seam
    put(G.body, rbox(0.0015, 0.05, 0.004, 0.0006), dark, sx * 0.0255, 0.0, -0.06, 0.45, 0, 0);
  }
  put(G.body, rbox(0.002, 0.016, 0.05, 0.001), M.blackened(0x080809), 0.0245, 0.06, -0.06);  // ejection port
  put(G.body, rbox(0.03, 0.045, 0.02, 0.004), alu, 0, 0.055, 0.092);                  // stock adapter
  put(G.body, rbox(0.006, 0.012, 0.016, 0.002), steel, 0.026, 0.022, 0.0);             // safety
  put(G.body, xcyl(0.004, 0.054, 10), steel, 0, 0.0, -0.065);                           // mag release
  // grip + trigger
  pistolGrip(G.body, poly, cfg.grip, { rake: 0.035, len: 0.105 });
  const trigger = triggerGroup(G.moving, M, { y: 0.0, len: 0.05, depth: 0.03 });
  // shroud / barrel variants
  const hgLen = { std: 0.115, long: 0.245, short: 0.04 }[cfg.barrel || 'std'];
  const hgEnd = 0.26 + hgLen;
  put(G.hg, profileGeo([[0.255, 0.028], [hgEnd, 0.03], [hgEnd, 0.078], [0.255, 0.08]], 0.042, 0.004), cfg.barrel === 'long' ? alu : poly);
  if (cfg.barrel === 'long') for (let i = 0; i < 6; i++) for (const sx of [1, -1]) put(G.hg, rbox(0.002, 0.008, 0.024, 0.002), M.blackened(0x09090a), sx * 0.0212, 0.054, -(0.285 + i * 0.035));
  const bottom = railGeo(Math.max(0.03, hgLen - 0.01), 0.02, 0.008); bottom.rotateX(Math.PI);
  put(G.hg, bottom, dark, 0, 0.028, -(0.26 + hgLen / 2));
  if (hgLen > 0.06) sideRail(G.hg, M, 0.05, 0.021, 0.055, -(0.26 + hgLen - 0.04), 1);
  const crownF = hgEnd + 0.03;
  barrel(G.barrelA, M, { y: 0.055, z0: -hgEnd + 0.01, len: crownF - hgEnd + 0.01, r: 0.0085 });
  crown(G.barrelA, M, { y: 0.055, z: -crownF, r: 0.0085 });
  // top rail over receiver + shroud
  const railLen = hgEnd - 0.03 + 0.065;
  const RT = topRail(G.sights, M, railLen, 0.082, 0.065 - railLen / 2);
  const irons = flipIrons(G.sights, M, { railTop: RT, rearZ: 0.04, frontZ: -(hgEnd - 0.04), height: 0.034, folded: cfg.folded });
  // charging handle (left)
  const charge = pivot(G.moving, 'charge', -0.026, 0.068, -0.17);
  put(charge, rbox(0.016, 0.01, 0.022, 0.003), dark, -0.006, 0, 0);
  // stock
  if (cfg.stock === 'tac') {
    put(G.stock, zcyl(0.015, 0.015, 0.2, 16), alu, 0, 0.056, 0.19);
    put(G.stock, profileGeo([[-0.18, 0.08], [-0.33, 0.085], [-0.345, 0.06], [-0.345, -0.055], [-0.31, -0.06], [-0.2, 0.03]], 0.038, 0.006), poly);
    put(G.stock, rbox(0.04, 0.13, 0.016, 0.006), M.rubber(), 0, 0.012, 0.352);
  } else {
    const st = pivot(G.stock, 'stockFold', -0.0, 0.055, 0.098);
    const sg = profileGeo([[-0.0, 0.02], [-0.235, 0.015], [-0.245, -0.005], [-0.245, -0.115], [-0.215, -0.12], [-0.195, -0.055], [-0.03, -0.015], [0.0, -0.015]], 0.03, 0.005);
    put(st, sg, poly);
    put(st, rbox(0.034, 0.125, 0.016, 0.006), M.rubber(), 0, -0.05, 0.252);
    put(st, ycyl(0.006, 0.04, 12), steel, 0.0, 0.0, 0.004);                              // hinge pin
    if (cfg.stock === 'folded') { st.position.x = -0.042; st.rotation.y = Math.PI * 0.995; }
  }
  // magazine
  let magOut;
  if (cfg.mag === 'drum') magOut = drumMag(G.magA, M, { y: -0.066, z: -0.116, r: 0.05, w: 0.056, tower: 0.04, d: 0.03 });
  else magOut = boxMag(G.magA, M, { y: -0.066, z: -0.116, len: cfg.mag === 'ext' ? 0.19 : 0.122, w: 0.022, d: 0.03, curve: 0.008, caliber: [0.032, 0.0058] });
  const s = sock(G, {
    muzzle: [0, 0.055, -crownF], ejection: [0.026, 0.06, -0.06], sight: [0, 0.12, -0.1],
    rightHand: [0, -0.045, 0.03], leftHand: [0, 0.012, -(0.26 + Math.max(0.05, hgLen * 0.55))], magWell: [0, -0.07, -0.116],
    optic: [0, RT, -0.085], underbarrel: [0, 0.02, -(0.26 + hgLen * 0.55)], laser: [0.028, 0.055, -(0.26 + hgLen - 0.04), null, Math.PI / 2],
  });
  return finish(root, G, { trigger, charge, mag: magOut.mag, rearSight: irons.rear, frontSight: irons.front }, s, magOut.rounds, {
    rearSight: new THREE.Vector3(0, irons.SL, 0.032), frontSight: new THREE.Vector3(0, irons.SL, -(hgEnd - 0.048)), sightType: 'iron',
    hasUnder: hgLen > 0.06,
  });
}

// ====================================================================
// P90 — 5.7 mm bullpup PDW, top-mounted translucent magazine — CONFIRMED
// ====================================================================
export function buildP90(cfg = {}) {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'P90';
  const G = groups(root);
  const black = M.polymer(0x1b1c1f), red = M.paint(0xb3202a), dark = M.blackened(0x121315), steel = M.steel();
  // body: thumbhole + trigger loop cut THROUGH the shell
  const body = polyShape([[-0.27, 0.06], [0.13, 0.06], [0.2, 0.03], [0.212, -0.01], [0.2, -0.07], [0.17, -0.1], [0.08, -0.105], [0.03, -0.112], [-0.06, -0.106], [-0.2, -0.106], [-0.255, -0.095], [-0.276, -0.04]],
    [rrPath(0.035, -0.082, 0.125, -0.026, 0.016), rrPath(-0.175, -0.084, -0.06, -0.03, 0.02)]);
  put(G.body, shapeGeo(body, 0.058, 0.005, 10), black);
  // red armour panels (1 mm proud of the shell → no z-fighting)
  put(G.body, profileGeo([[-0.2, 0.004], [0.12, 0.012], [0.165, 0.042], [-0.2, 0.044]], 0.0605, 0.002), red);
  put(G.body, profileGeo([[0.13, -0.035], [0.19, -0.03], [0.185, -0.07], [0.155, -0.088]], 0.0605, 0.002), red);
  for (const sx of [1, -1]) for (const [f, u] of [[-0.18, 0.02], [0.06, 0.03], [0.17, -0.06]]) put(G.body, screwGeo(0.0028, 0.002), steel, sx * 0.0305, u, -f);
  put(G.body, rbox(0.03, 0.006, 0.04, 0.002), dark, 0, -0.108, -0.01);                  // downward ejection chute
  gripDecor(G.body, M, cfg.grip, { f0: -0.055, f1: 0.03, u0: -0.1, u1: -0.035, x: 0.0292 });
  // front sight housing (optic rail sits on it)
  put(G.body, profileGeo([[0.075, 0.06], [0.2, 0.034], [0.208, 0.1], [0.1, 0.104], [0.078, 0.098]], 0.054, 0.004), black);
  put(G.body, profileGeo([[-0.215, 0.06], [-0.16, 0.06], [-0.16, 0.088], [-0.21, 0.09]], 0.05, 0.003), black); // rear latch
  const RT = topRail(G.sights, M, 0.11, 0.103, -0.15);
  const irons = flipIrons(G.sights, M, { railTop: RT, rearZ: -0.107, frontZ: -0.198, height: 0.027, folded: cfg.folded, frontMat: red });
  // magazine (smoke polymer, 50 rds lying across the bore)
  const mag = pivot(G.magA, 'mag', 0, 0.062, 0);
  put(mag, profileGeo([[-0.17, 0.0], [0.15, 0.0], [0.15, 0.027], [-0.165, 0.028]], 0.05, 0.003), smokeMat());
  put(mag, rbox(0.052, 0.006, 0.012, 0.002), dark, 0, 0.012, 0.168);
  const rounds = [];
  const rg = cartridgeGeo(0.046, 0.0031, 0.35);
  for (let i = 0; i < 12; i++) rounds.push(keep(put(mag, rg, M.brass(), 0.022, 0.014, -0.12 + i * 0.022, 0, Math.PI / 2, 0)));
  // barrel variants
  const crownF = cfg.barrel === 'long' ? 0.38 : 0.292;
  if (cfg.barrel === 'long') put(G.barrelA, zcyl(0.0145, 0.0155, 0.12, 18), dark, 0, 0.03, -0.27);
  barrel(G.barrelA, M, { y: 0.03, z0: -0.2, len: crownF - 0.2, r: 0.0078 });
  crown(G.barrelA, M, { y: 0.03, z: -crownF, r: 0.0078 });
  // under rail (front of trigger loop) + right side rail
  const br = railGeo(0.05, 0.02, 0.008); br.rotateX(Math.PI); put(G.hg, br, dark, 0, -0.098, -0.175);
  sideRail(G.hg, M, 0.05, 0.029, 0.018, -0.16, 1);
  // charging handles (both sides, front)
  const charge = pivot(G.moving, 'charge', -0.031, 0.036, -0.16);
  put(charge, rbox(0.008, 0.01, 0.018, 0.003), dark, -0.003, 0, 0);
  const trigger = pivot(G.moving, 'trigger', 0, -0.028, -0.05);
  put(trigger, profileGeo([[0, 0], [0.007, 0], [0.004, -0.02], [-0.002, -0.024]], 0.007, 0.0008), steel);
  // butt
  const padT = cfg.stock === 'pad' ? 0.03 : 0.012;
  put(G.stock, rbox(0.06, 0.15, padT, 0.005), M.rubber(), 0, -0.02, 0.272 + padT / 2);
  if (cfg.stock === 'pad') put(G.stock, rbox(0.05, 0.02, 0.05, 0.004), black, 0, 0.065, 0.255);
  const s = sock(G, {
    muzzle: [0, 0.03, -crownF], ejection: [0.03, -0.06, -0.01], sight: [0, 0.14, -0.15],
    rightHand: [0, -0.05, 0.0], leftHand: [0, -0.07, -0.178], magWell: [0, 0.062, 0],
    optic: [0, RT, -0.15], underbarrel: [0, -0.107, -0.175], laser: [0.036, 0.018, -0.16, null, Math.PI / 2],
  });
  return finish(root, G, { trigger, charge, mag, rearSight: irons.rear, frontSight: irons.front }, s, rounds, {
    rearSight: new THREE.Vector3(0, irons.SL, -0.115), frontSight: new THREE.Vector3(0, irons.SL, -0.19), sightType: 'iron', hasUnder: true,
  });
}

// ====================================================================
// FN2000 — 5.56 bullpup, smooth shell, enclosed trigger — CONFIRMED
// ====================================================================
export function buildFN2000(cfg = {}) {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'FN2000';
  const G = groups(root);
  const shell = M.polymer(0x232427), grey = M.polymer(0x3a3c40), dark = M.blackened(0x121315), steel = M.steel();
  const body = polyShape([[-0.34, 0.06], [0.28, 0.068], [0.36, 0.05], [0.372, 0.015], [0.362, -0.012], [0.135, -0.02], [0.125, -0.104], [0.105, -0.118], [-0.03, -0.118], [-0.044, -0.032], [-0.062, -0.04], [-0.14, -0.062], [-0.31, -0.066], [-0.347, -0.035]],
    [rrPath(0.012, -0.1, 0.11, -0.03, 0.013)]);
  put(G.body, shapeGeo(body, 0.06, 0.006, 12), shell);
  put(G.body, profileGeo([[-0.3, 0.035], [0.26, 0.044], [0.33, 0.035], [0.3, 0.05], [-0.3, 0.048]], 0.0615, 0.002), grey);  // upper shell band
  for (const sx of [1, -1]) {
    put(G.body, rbox(0.0012, 0.004, 0.5, 0.0005), dark, sx * 0.0302, 0.0, -0.02);
    put(G.body, screwGeo(0.003, 0.002), steel, sx * 0.031, 0.02, 0.2);
  }
  put(G.body, rbox(0.002, 0.014, 0.05, 0.001), M.blackened(0x070708), 0.03, 0.03, -0.06);   // forward ejection port
  gripDecor(G.body, M, cfg.grip, { f0: -0.04, f1: 0.008, u0: -0.112, u1: -0.035, x: 0.0302 });
  const trigger = pivot(G.moving, 'trigger', 0, -0.04, -0.04);
  put(trigger, profileGeo([[0, 0], [0.007, 0], [0.004, -0.02], [-0.002, -0.024]], 0.007, 0.0008), steel);
  // top rail & irons
  const RT = topRail(G.sights, M, 0.25, 0.068, -0.08);
  const irons = flipIrons(G.sights, M, { railTop: RT, rearZ: 0.03, frontZ: -0.19, height: 0.032, folded: cfg.folded });
  // barrel variants (protrudes from the nose)
  const crownF = { std: 0.42, long: 0.5, short: 0.385 }[cfg.barrel || 'std'];
  if (cfg.barrel === 'long') put(G.barrelA, zcyl(0.016, 0.017, 0.09, 18), grey, 0, 0.025, -0.41);
  barrel(G.barrelA, M, { y: 0.025, z0: -0.36, len: crownF - 0.36, r: 0.0085 });
  crown(G.barrelA, M, { y: 0.025, z: -crownF, r: 0.0085 });
  const br = railGeo(0.12, 0.02, 0.008); br.rotateX(Math.PI); put(G.hg, br, dark, 0, -0.017, -0.27);
  sideRail(G.hg, M, 0.06, 0.03, 0.025, -0.29, 1);
  const charge = pivot(G.moving, 'charge', -0.031, 0.04, -0.22);
  put(charge, rbox(0.01, 0.01, 0.02, 0.003), dark, -0.004, 0, 0);
  // stock variants
  put(G.stock, rbox(0.058, 0.12, 0.014, 0.005), M.rubber(), 0, -0.004, 0.348);
  if (cfg.stock === 'composite') {
    put(G.stock, profileGeo([[-0.33, 0.06], [-0.39, 0.065], [-0.4, -0.06], [-0.33, -0.065]], 0.056, 0.005), grey);
    put(G.stock, rbox(0.044, 0.016, 0.12, 0.004), shell, 0, 0.072, 0.29);
  }
  const magOut = boxMag(G.magA, M, { y: -0.05, z: 0.096, len: cfg.mag === 'ext' ? 0.235 : 0.165, d: 0.062, w: 0.024, curve: cfg.mag === 'ext' ? 0.05 : 0.035, caliber: [0.057, 0.0048] });
  const s = sock(G, {
    muzzle: [0, 0.025, -crownF], ejection: [0.03, 0.03, -0.06], sight: [0, 0.11, -0.08],
    rightHand: [0, -0.06, 0.012], leftHand: [0, -0.03, -0.25], magWell: [0, -0.05, 0.096],
    optic: [0, RT, -0.08], underbarrel: [0, -0.025, -0.27], laser: [0.037, 0.025, -0.29, null, Math.PI / 2],
  });
  return finish(root, G, { trigger, charge, mag: magOut.mag, rearSight: irons.rear, frontSight: irons.front }, s, magOut.rounds, {
    rearSight: new THREE.Vector3(0, irons.SL, 0.022), frontSight: new THREE.Vector3(0, irons.SL, -0.182), sightType: 'iron', hasUnder: true,
  });
}

// ====================================================================
// QBZ95 — 5.8 mm bullpup with carry handle (white/gold/blue skin) — CONFIRMED
// ====================================================================
export function buildQBZ95(cfg = {}) {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'QBZ95';
  const G = groups(root);
  const white = M.polymer(0xe2e0da), gold = M.brass(), blue = M.paint(0x2a5bd7), dark = M.blackened(0x17181a), steel = M.steel();
  put(G.body, profileGeo([[-0.385, 0.055], [0.12, 0.062], [0.34, 0.055], [0.36, 0.035], [0.36, 0.0], [0.14, -0.012], [0.13, -0.035], [0.112, -0.03], [0.02, -0.012], [-0.06, -0.03], [-0.14, -0.05], [-0.36, -0.06], [-0.39, -0.03]], 0.054, 0.005), white);
  for (const sx of [1, -1]) {
    put(G.body, rbox(0.0014, 0.006, 0.4, 0.0006), blue, sx * 0.0276, 0.044, 0.1);
    put(G.body, rbox(0.0014, 0.005, 0.2, 0.0006), gold, sx * 0.0276, 0.018, -0.25);
    put(G.body, rbox(0.0014, 0.03, 0.05, 0.002), dark, sx * 0.0276, 0.01, 0.2);        // cheek-weld panel
  }
  put(G.body, rbox(0.002, 0.014, 0.05, 0.001), M.blackened(0x070708), 0.0275, 0.03, 0.06);  // ejection port (right, rear)
  pistolGrip(G.body, M.polymer(0x2b2b2e), cfg.grip, { top: -0.008, len: 0.105, rake: 0.03 });
  const trigger = triggerGroup(G.moving, M, { y: -0.012, len: 0.1, depth: 0.034 });
  // carry handle (with real opening) + rail
  const handle = polyShape([[-0.03, 0.0], [0.21, 0.0], [0.21, 0.05], [-0.03, 0.05]], [rrPath(0.02, 0.008, 0.17, 0.034, 0.008)]);
  const hg = shapeGeo(handle, 0.022, 0.003, 8);
  put(G.sights, hg, white, 0, 0.06, 0);
  const RT = topRail(G.sights, M, 0.17, 0.11, -0.09, 0.021, 0.009, dark);
  const irons = flipIrons(G.sights, M, { railTop: RT, rearZ: 0.0, frontZ: -0.18, height: 0.03, folded: cfg.folded, frontMat: gold });
  const charge = pivot(G.moving, 'charge', 0, 0.068, -0.08);
  put(charge, rbox(0.012, 0.01, 0.02, 0.003), gold, 0, 0, 0);
  // barrel
  const crownF = cfg.barrel === 'long' ? 0.52 : 0.44;
  barrel(G.barrelA, M, { y: 0.022, z0: -0.355, len: crownF - 0.355, r: 0.0082, mat: M.steel(0x8b8e92) });
  put(G.barrelA, ztube(0.0115, 0.0085, 0.012, 16), gold, 0, 0.022, -0.362);
  crown(G.barrelA, M, { y: 0.022, z: -crownF, r: 0.0082 });
  const br = railGeo(0.12, 0.02, 0.008); br.rotateX(Math.PI); put(G.hg, br, dark, 0, -0.006, -0.26);
  sideRail(G.hg, M, 0.06, 0.027, 0.025, -0.3, 1);
  // stock variants
  put(G.stock, rbox(0.052, 0.112, 0.014, 0.005), M.rubber(0x2a2a2a), 0, -0.003, 0.392);
  if (cfg.stock === 'cheek') put(G.stock, profileGeo([[-0.18, 0.055], [-0.36, 0.055], [-0.36, 0.075], [-0.2, 0.072]], 0.04, 0.005), white);
  const magOut = boxMag(G.magA, M, { y: -0.046, z: 0.104, len: cfg.mag === 'ext' ? 0.23 : 0.16, d: 0.06, w: 0.023, curve: 0.034, caliber: [0.058, 0.0047], mat: M.polymer(0x2a2b2d) });
  const s = sock(G, {
    muzzle: [0, 0.022, -crownF], ejection: [0.028, 0.03, 0.06], sight: [0, 0.15, -0.09],
    rightHand: [0, -0.055, 0.02], leftHand: [0, -0.025, -0.24], magWell: [0, -0.046, 0.104],
    optic: [0, RT, -0.09], underbarrel: [0, -0.015, -0.26], laser: [0.034, 0.025, -0.3, null, Math.PI / 2],
  });
  return finish(root, G, { trigger, charge, mag: magOut.mag, rearSight: irons.rear, frontSight: irons.front }, s, magOut.rounds, {
    rearSight: new THREE.Vector3(0, irons.SL, -0.008), frontSight: new THREE.Vector3(0, irons.SL, -0.172), sightType: 'iron', hasUnder: true,
  });
}

// ====================================================================
// SCAR — 7.62 battle rifle, monolithic upper, folding stock — CONFIRMED
// ====================================================================
export function buildSCAR(cfg = {}) {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'SCAR';
  const G = groups(root);
  const upper = M.gunmetal(0x2a2b2e), lower = M.polymer(0x1e1f21), dark = M.blackened(0x121314), steel = M.steel();
  put(G.body, profileGeo([[-0.12, 0.025], [0.42, 0.028], [0.42, 0.072], [-0.12, 0.072]], 0.05, 0.004), upper);
  put(G.body, profileGeo([[-0.115, -0.004], [0.13, -0.004], [0.14, 0.026], [-0.115, 0.026]], 0.046, 0.004), lower);
  put(G.body, profileGeo([[0.035, -0.004], [0.13, -0.004], [0.126, -0.036], [0.04, -0.036]], 0.052, 0.004), lower);
  for (const sx of [1, -1]) {
    for (let i = 0; i < 4; i++) put(G.hg, rbox(0.002, 0.012, 0.03, 0.002), M.blackened(0x0a0a0b), sx * 0.0252, 0.045, -(0.2 + i * 0.05));
    put(G.body, screwGeo(0.003, 0.002), steel, sx * 0.0252, 0.012, 0.09);
  }
  put(G.body, rbox(0.002, 0.016, 0.06, 0.001), M.blackened(0x070708), 0.0252, 0.048, -0.02);  // ejection port
  pistolGrip(G.body, lower, cfg.grip, { top: -0.004, len: 0.11, rake: 0.036 });
  const trigger = triggerGroup(G.moving, M, { y: -0.004, len: 0.074 });
  const RT = topRail(G.sights, M, 0.53, 0.072, -0.15);
  const irons = flipIrons(G.sights, M, { railTop: RT, rearZ: 0.09, frontZ: -0.39, height: 0.034, folded: cfg.folded });
  const br = railGeo(0.2, 0.02, 0.008); br.rotateX(Math.PI); put(G.hg, br, dark, 0, 0.026, -0.3);
  sideRail(G.hg, M, 0.09, 0.025, 0.048, -0.36, 1);
  sideRail(G.hg, M, 0.09, -0.025, 0.048, -0.36, -1);
  const crownF = { std: 0.5, long: 0.6, cqc: 0.445 }[cfg.barrel || 'std'];
  put(G.barrelA, rbox(0.026, 0.026, 0.03, 0.004), dark, 0, 0.045, -0.43);          // gas block
  barrel(G.barrelA, M, { y: 0.045, z0: -0.42, len: crownF - 0.42, r: 0.0095 });
  crown(G.barrelA, M, { y: 0.045, z: -crownF, r: 0.0095 });
  const charge = pivot(G.moving, 'charge', -0.028, 0.055, -0.15);
  put(charge, rbox(0.03, 0.01, 0.012, 0.003), dark, -0.012, 0, 0);
  const bolt = pivot(G.moving, 'bolt', 0, 0.05, -0.02);
  put(bolt, rbox(0.006, 0.012, 0.05, 0.001), steel, 0.022, 0, 0);
  // stock variants
  const sh = cfg.stock === 'compact' ? 0.05 : 0;
  put(G.stock, rbox(0.04, 0.05, 0.03, 0.005), lower, 0, 0.045, 0.13);
  put(G.stock, profileGeo([[-0.14, 0.07], [-0.36 + sh, 0.068], [-0.4 + sh, 0.055], [-0.405 + sh, -0.06], [-0.37 + sh, -0.07], [-0.33 + sh, -0.005], [-0.16, 0.02], [-0.14, 0.02]], 0.044, 0.006), lower);
  put(G.stock, rbox(0.046, 0.13, 0.016, 0.006), M.rubber(), 0, -0.002, 0.41 - sh);
  if (cfg.stock === 'tac') {
    put(G.stock, profileGeo([[-0.2, 0.07], [-0.35, 0.068], [-0.35, 0.09], [-0.21, 0.088]], 0.036, 0.005), lower);
    for (const z of [0.22, 0.32]) put(G.stock, ycyl(0.0025, 0.022, 8), steel, 0, 0.078, z);
  } else put(G.stock, profileGeo([[-0.2, 0.07], [-0.35 + sh, 0.068], [-0.35 + sh, 0.08], [-0.21, 0.08]], 0.036, 0.005), lower);
  const magOut = boxMag(G.magA, M, { y: -0.03, z: -0.085, len: cfg.mag === 'ext' ? 0.185 : 0.13, d: 0.075, w: 0.026, curve: 0.01, caliber: [0.071, 0.006] });
  const s = sock(G, {
    muzzle: [0, 0.045, -crownF], ejection: [0.026, 0.05, -0.02], sight: [0, 0.115, -0.15],
    rightHand: [0, -0.05, 0.03], leftHand: [0, 0.012, -0.3], magWell: [0, -0.03, -0.085],
    optic: [0, RT, -0.06], underbarrel: [0, 0.018, -0.3], laser: [0.032, 0.048, -0.36, null, Math.PI / 2],
  });
  return finish(root, G, { trigger, charge, bolt, mag: magOut.mag, rearSight: irons.rear, frontSight: irons.front }, s, magOut.rounds, {
    rearSight: new THREE.Vector3(0, irons.SL, 0.082), frontSight: new THREE.Vector3(0, irons.SL, -0.382), sightType: 'iron', hasUnder: true,
  });
}
