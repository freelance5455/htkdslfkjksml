// =====================================================================
// Reference-weapon construction helpers (gunsmith weapons)
// ---------------------------------------------------------------------
// Shared, parameterised sub-assemblies used by the individually modelled
// reference weapons in refmodels.js. Each helper produces real geometry
// for one functional part (grip, trigger group, rail, flip-up irons,
// magazines); every weapon composes them with its own receiver, barrel,
// stock and silhouette, so no two weapons share a whole model.
//
// Mount conventions (weapon space, metres; -Z = muzzle, +Y = up):
//   sockets.optic       top-rail surface point where an optic's base sits
//   sockets.muzzle      barrel crown (muzzle devices thread on here)
//   sockets.underbarrel bottom-rail surface (grips hang from y = 0 down)
//   sockets.laser       right side-rail surface (+X outward)
// =====================================================================
import * as THREE from 'three';
import { profileGeo, shapeGeo, rbox, zcyl, ycyl, xcyl, ztube, railGeo, screwGeo, put, pivot, cartridgeGeo, getShared } from './kit.js';
import { gunMat } from '../render/toon.js';

export const keep = (m) => { m.userData.keep = true; return m; };

let SMOKE = null;
/** Translucent smoke polymer (P90 magazine). */
export function smokeMat() {
  if (!SMOKE) { SMOKE = gunMat({ color: 0x3a3226, roughness: 0.25, metalness: 0.0, transparent: true, opacity: 0.62 }); SMOKE.name = 'smokePoly'; SMOKE.depthWrite = false; }
  return SMOKE;
}

/**
 * Pistol grip below the origin. variant: 'std' (stippled), 'striped', 'granular'.
 * rake = rearward slope; len = grip length.
 */
export function pistolGrip(root, mat, variant = 'std', { len = 0.11, w = 0.032, rake = 0.035, top = 0.0, fwd = 0.012 } = {}) {
  const { M } = getShared();
  const pts = [[-0.032, top + 0.002], [fwd, top + 0.002], [fwd - 0.006, top - 0.04], [fwd - rake * 0.4 - 0.004, top - len], [-0.032 - rake - 0.004, top - len], [-0.034 - rake * 0.4, top - 0.05]];
  put(root, profileGeo(pts, w, 0.006), mat);
  const g = new THREE.Group(); root.add(g);
  if (variant === 'striped') {
    for (let i = 0; i < 6; i++) {
      const u = 0.022 + i * 0.014, f = fwd - 0.008 - (u / len) * rake * 0.5;
      put(g, rbox(w + 0.0016, 0.0035, 0.034, 0.0012), M.blackened(0x15161a), 0, top - u, -(f - 0.02), -0.25, 0, 0);
    }
  } else if (variant === 'granular') {
    const dot = new THREE.IcosahedronGeometry(0.0018, 0);
    for (let i = 0; i < 5; i++) for (let j = 0; j < 3; j++) for (const sx of [1, -1]) {
      put(g, dot, M.rubber(0x34302a), sx * (w / 2 + 0.0004), top - 0.025 - i * 0.016, 0.004 + j * 0.011 + i * 0.003);
    }
  }
  return g;
}

/** Trigger guard + articulated trigger. Returns the trigger pivot. */
export function triggerGroup(root, M, { y = 0.0, len = 0.075, depth = 0.032 } = {}) {
  const dark = M.blackened();
  put(root, profileGeo([[0.0, y], [len, y], [len + 0.002, y - 0.004], [0.004, y - depth], [0.0, y - depth + 0.004], [len - 0.008, y - 0.006], [0.0, y - 0.006]], 0.009, 0.0012), dark);
  const trigger = pivot(root, 'trigger', 0, y - 0.002, -0.03);
  put(trigger, profileGeo([[0, 0], [0.006, 0], [0.004, -0.018], [-0.002, -0.022]], 0.006, 0.0008), M.steel());
  return trigger;
}

/** Picatinny rail; returns rail-top height. */
export function topRail(root, M, len, y, z, w = 0.021, h = 0.009, mat) {
  put(root, railGeo(len, w, h), mat || M.blackened(0x18191b), 0, y, z);
  return y + h;
}
/** Side rail on +X / -X face (teeth face outward). */
export function sideRail(root, M, len, x, y, z, side = 1) {
  const g = railGeo(len, 0.016, 0.007);
  g.rotateZ(-side * Math.PI / 2);
  put(root, g, M.blackened(0x18191b), x, y, z);
  return x + side * 0.007;
}

/**
 * Flip-up iron sights standing on a rail. When `folded` (an optic is
 * mounted) both sights are rotated flat onto the rail like real BUIS —
 * they remain attached geometry, never just hidden.
 * Returns { SL, rear, front } with SL = sight-line height.
 */
export function flipIrons(root, M, { railTop, rearZ, frontZ, height = 0.034, folded = false, frontMat }) {
  const dark = M.blackened(0x17181a), steel = M.steel();
  const SL = railTop + height;
  // rear aperture
  put(root, rbox(0.022, 0.008, 0.024, 0.002), dark, 0, railTop + 0.004, rearZ);
  const rear = pivot(root, 'rearSight', 0, railTop + 0.008, rearZ + 0.008);
  for (const sx of [1, -1]) put(rear, rbox(0.004, height - 0.002, 0.006, 0.001), dark, sx * 0.009, (height - 0.008) / 2, -0.008);
  put(rear, new THREE.TorusGeometry(0.0055, 0.0018, 8, 18), dark, 0, height - 0.008, -0.008);
  put(rear, rbox(0.022, 0.004, 0.006, 0.001), dark, 0, 0.002, -0.008);
  // front post with protective ears
  put(root, rbox(0.022, 0.008, 0.024, 0.002), dark, 0, railTop + 0.004, frontZ);
  const front = pivot(root, 'frontSight', 0, railTop + 0.008, frontZ - 0.008);
  for (const sx of [1, -1]) put(front, rbox(0.003, height - 0.004, 0.006, 0.001), frontMat || dark, sx * 0.009, (height - 0.01) / 2, 0.008);
  put(front, ycyl(0.0012, height - 0.012, 6, 0.0018), steel, 0, (height - 0.012) / 2 + 0.0, 0.008);
  put(front, rbox(0.022, 0.004, 0.006, 0.001), dark, 0, 0.002, 0.008);
  if (folded) { rear.rotation.x = Math.PI / 2 * 0.98; front.rotation.x = -Math.PI / 2 * 0.98; }
  return { SL, rear, front };
}

/** Straight / slightly curved box magazine; returns { mag, rounds }. */
export function boxMag(root, M, { y, z, len = 0.15, w = 0.024, d = 0.06, curve = 0.02, mat, plateMat, caliber = [0.045, 0.0055], name = 'mag', rake = 0 } = {}) {
  const mag = pivot(root, name, 0, y, z);
  const s = new THREE.Shape();
  const h = d / 2;
  s.moveTo(-h, 0); s.lineTo(h, 0);
  s.quadraticCurveTo(h + curve * 0.3, -len * 0.5, h + curve - rake, -len);
  s.lineTo(-h + curve - rake, -len - 0.004);
  s.quadraticCurveTo(-h + curve * 0.25, -len * 0.5, -h, 0);
  s.closePath();
  put(mag, shapeGeo(s, w, 0.0025, 12), mat || M.gunmetal(0x2f3134));
  put(mag, rbox(w + 0.004, 0.012, d + 0.008, 0.003), plateMat || M.polymer(0x1f2022), 0, -len - 0.004, -(curve - rake), 0.12 * Math.sign(curve || 0.0001), 0, 0);
  for (const sx of [1, -1]) put(mag, rbox(0.0012, len * 0.7, 0.006, 0.0005), M.blackened(0x141416), sx * (w / 2 + 0.0003), -len * 0.45, -(curve * 0.35));
  const rounds = [];
  const cg = cartridgeGeo(caliber[0], caliber[1], 0.38);
  for (let i = 0; i < 2; i++) rounds.push(keep(put(mag, cg, M.brass(), i ? caliber[1] * 0.75 : -caliber[1] * 0.75, 0.003 - i * 0.003, d / 2 - 0.004)));
  return { mag, rounds };
}

/** Drum magazine: feed tower + twin/single drum. */
export function drumMag(root, M, { y, z, r = 0.055, w = 0.05, tower = 0.05, d = 0.034, mat, name = 'mag', caliber = [0.03, 0.0055] } = {}) {
  const mag = pivot(root, name, 0, y, z);
  const m = mat || M.polymer(0x1c1d1f);
  put(mag, rbox(0.024, tower, d, 0.003), M.gunmetal(0x2d2f32), 0, -tower / 2, 0);
  const drum = new THREE.CylinderGeometry(r, r, w, 36); drum.rotateZ(Math.PI / 2);
  put(mag, drum, m, 0, -tower - r * 0.8, -r * 0.15);
  const cap = new THREE.CylinderGeometry(r * 0.55, r * 0.6, w + 0.008, 24); cap.rotateZ(Math.PI / 2);
  put(mag, cap, M.blackened(0x141516), 0, -tower - r * 0.8, -r * 0.15);
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    put(mag, rbox(w + 0.003, 0.006, 0.012, 0.002), M.blackened(0x141516), 0, -tower - r * 0.8 + Math.sin(a) * r * 0.96, -r * 0.15 + Math.cos(a) * r * 0.96, a, 0, 0);
  }
  put(mag, xcyl(0.009, w + 0.016, 14), M.steel(), 0, -tower - r * 0.8, -r * 0.15); // winding key
  const rounds = [];
  const cg = cartridgeGeo(caliber[0], caliber[1], 0.38);
  for (let i = 0; i < 2; i++) rounds.push(keep(put(mag, cg, M.brass(), i ? 0.004 : -0.004, 0.003 - i * 0.003, d / 2 - 0.004)));
  return { mag, rounds };
}

/** Free-floating barrel + optional fluting; returns crown z. */
export function barrel(root, M, { y, z0, len, r = 0.009, r2, fluted = false, mat }) {
  put(root, zcyl(r, r2 ?? r * 1.1, len, 18), mat || M.steel(0x5c6066), 0, y, z0 - len / 2);
  if (fluted) for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; put(root, rbox(0.0025, 0.0025, len * 0.6, 0.0008), M.blackened(0x101112), Math.cos(a) * r * 0.98, y + Math.sin(a) * r * 0.98, z0 - len * 0.45); }
  return z0 - len;
}

/** Standard muzzle thread / crown so devices visibly thread on. */
export function crown(root, M, { y, z, r }) {
  put(root, ztube(r * 1.02, r * 0.45, 0.004, 16), M.steel(0x8e9399), 0, y, z + 0.002);
}

export function screws(root, M, list, r = 0.0028) { for (const [x, y, z] of list) put(root, screwGeo(r, 0.002), M.steel(), x, y, z); }

export { profileGeo, shapeGeo, rbox, zcyl, ycyl, xcyl, ztube, railGeo, screwGeo, put, pivot, cartridgeGeo };
