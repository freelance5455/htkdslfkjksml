// =====================================================================
// Reference weapons, part 2: precision rifles, LMG and handgun
// (see refmodels.js for conventions). Precision rifles have no iron
// sights in the reference → their optic slot is mandatory.
// =====================================================================
import * as THREE from 'three';
import { getShared, finalize, captureRest, socket } from './kit.js';
import {
  keep, pistolGrip, triggerGroup, topRail, sideRail, flipIrons, boxMag, barrel, crown,
  profileGeo, shapeGeo, rbox, zcyl, ycyl, xcyl, railGeo, screwGeo, put, pivot, cartridgeGeo,
} from './refkit.js';

function asm(root, name) {
  const g = new THREE.Group(); g.name = name; g.userData.part = true;
  g.userData.rest = { p: g.position.clone(), r: g.rotation.clone() };
  root.add(g); return g;
}
function groups(root) {
  return {
    body: asm(root, 'MainBody'), barrelA: asm(root, 'BarrelAssembly'), hg: asm(root, 'HandguardAssembly'),
    stock: asm(root, 'StockAssembly'), magA: asm(root, 'MagazineAssembly'), sights: asm(root, 'SightMounts'),
    moving: asm(root, 'MovingParts'), points: new THREE.Group(),
  };
}
function sock(G, defs) {
  const out = {};
  for (const [k, v] of Object.entries(defs)) { out[k] = socket(G.points, k, v[0], v[1], v[2]); if (v[3]) out[k].rotation.z = v[3]; }
  return out;
}
function finish(root, G, parts, s, rounds, meta) {
  root.add(G.points); G.points.userData.socket = true;
  captureRest(root); finalize(root);
  return { root, parts, sockets: s, rounds, meta };
}
/** Bolt with rotating handle; returns { bolt, handle }. */
function boltAssembly(parent, M, { y, z, r = 0.0095, len = 0.11, knob = 0.0085, knobMat, handleLen = 0.048 }) {
  const bolt = pivot(parent, 'bolt', 0, y, z);
  put(bolt, zcyl(r, r, len, 16), M.steel(0x9aa0a6), 0, 0, -len / 2 + 0.02);
  const handle = new THREE.Group(); handle.name = 'boltHandle'; bolt.add(handle);
  put(handle, rbox(handleLen, 0.007, 0.008, 0.002), M.steel(), handleLen / 2 + 0.004, 0, 0.012);
  put(handle, new THREE.SphereGeometry(knob, 14, 10), knobMat || M.blackened(0x141416), handleLen + 0.006, -0.004, 0.012);
  return { bolt, handle };
}

// ====================================================================
// AWM — .338 bolt-action, olive thumbhole chassis — CONFIRMED (1:53-3:05)
// ====================================================================
export function buildAWM(cfg = {}) {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'AWM';
  const G = groups(root);
  const olive = M.paint(0x5d5a3c), dark = M.blackened(0x161718), steel = M.steel(), grey = M.gunmetal(0x3b3d40);
  const th = new THREE.Path(); th.moveTo(-0.07, -0.005); th.lineTo(-0.15, -0.005); th.quadraticCurveTo(-0.17, -0.03, -0.15, -0.07); th.lineTo(-0.09, -0.07); th.quadraticCurveTo(-0.06, -0.04, -0.07, -0.005);
  const ch = new THREE.Shape();
  [[0.33, 0.02], [0.33, 0.055], [-0.02, 0.055], [-0.05, 0.06], [-0.47, 0.065], [-0.48, 0.035], [-0.48, -0.085], [-0.44, -0.09], [-0.3, -0.06], [-0.2, -0.1], [-0.05, -0.105], [-0.01, -0.02], [0.07, -0.016], [0.07, 0.0], [0.2, -0.002]].forEach(([f, u], i) => (i ? ch.lineTo(f, u) : ch.moveTo(f, u)));
  ch.closePath(); ch.holes.push(th);
  put(G.body, shapeGeo(ch, 0.058, 0.006, 8), olive);
  put(G.stock, rbox(0.06, 0.15, 0.024, 0.008), M.rubber(0x2a2a2a), 0, -0.012, 0.49);
  const cheekH = cfg.stock === 'tac' ? 0.02 : 0.008;
  put(G.stock, profileGeo([[-0.17, 0.065], [-0.38, 0.068], [-0.38, 0.08 + cheekH], [-0.19, 0.08 + cheekH]], 0.044, 0.005), olive);
  for (const z of [0.22, 0.34]) put(G.stock, ycyl(0.003, 0.02 + cheekH, 8), steel, 0, 0.068, z);
  if (cfg.stock === 'tac') put(G.stock, ycyl(0.012, 0.07, 14), dark, 0, -0.12, 0.43);
  put(G.body, zcyl(0.02, 0.02, 0.24, 22), grey, 0, 0.07, -0.08);
  put(G.body, rbox(0.002, 0.014, 0.07, 0.001), M.blackened(0x070708), 0.0205, 0.075, -0.07);
  const RT = topRail(G.sights, M, 0.26, 0.088, -0.08);
  for (const sx of [1, -1]) put(G.body, screwGeo(0.003, 0.002), steel, sx * 0.0295, 0.0, -0.17);
  const trigger = triggerGroup(G.moving, M, { y: -0.012, len: 0.07 });
  const crownF = cfg.barrel === 'long' ? 0.86 : 0.76;
  barrel(G.barrelA, M, { y: 0.07, z0: -0.33, len: crownF - 0.33, r: 0.0105, r2: 0.0135, fluted: true, mat: M.blackened(0x202124) });
  crown(G.barrelA, M, { y: 0.07, z: -crownF, r: 0.0105 });
  put(G.hg, rbox(0.03, 0.014, 0.03, 0.004), dark, 0, -0.005, -0.3);
  sideRail(G.hg, M, 0.06, 0.03, 0.035, -0.26, 1);
  const bb = railGeo(0.08, 0.02, 0.008); bb.rotateX(Math.PI); put(G.hg, bb, dark, 0, 0.02, -0.22);
  const { bolt, handle } = boltAssembly(G.moving, M, { y: 0.07, z: 0.0, knob: 0.0095, knobMat: M.blackened(0x0f1011), handleLen: 0.05 });
  const magOut = boxMag(G.magA, M, { y: -0.016, z: -0.075, len: cfg.mag === 'ext' ? 0.085 : 0.05, d: 0.09, w: 0.034, curve: 0.0, caliber: [0.093, 0.0072] });
  const s = sock(G, {
    muzzle: [0, 0.07, -crownF], ejection: [0.022, 0.075, -0.07], sight: [0, 0.13, 0.04],
    rightHand: [0, -0.05, 0.03], leftHand: [0, 0.0, -0.3], magWell: [0, -0.016, -0.075],
    optic: [0, RT, -0.07], underbarrel: [0, 0.012, -0.22], laser: [0.037, 0.035, -0.26, Math.PI / 2],
  });
  return finish(root, G, { trigger, bolt, boltHandle: handle, mag: magOut.mag }, s, magOut.rounds, { sightType: 'none', opticRequired: true, hasUnder: true });
}

// ====================================================================
// BARRETT — .50 BMG anti-materiel semi-auto (M82 silhouette) — CONFIRMED
// ====================================================================
export function buildBarrett(cfg = {}) {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'Barrett';
  const G = groups(root);
  const metal = M.gunmetal(0x3e4044), dark = M.blackened(0x141517), steel = M.steel();
  put(G.body, profileGeo([[-0.2, 0.03], [0.5, 0.034], [0.5, 0.09], [-0.17, 0.09], [-0.2, 0.075]], 0.052, 0.003), metal);
  for (let i = 0; i < 8; i++) for (const sx of [1, -1]) put(G.hg, rbox(0.002, 0.012, 0.032, 0.002), M.blackened(0x08090a), sx * 0.0262, 0.068, -(0.2 + i * 0.038));
  put(G.body, profileGeo([[-0.2, -0.004], [0.2, -0.004], [0.2, 0.032], [-0.2, 0.032]], 0.05, 0.003), metal);
  for (const sx of [1, -1]) for (const z of [-0.18, 0.0, 0.15]) put(G.body, screwGeo(0.004, 0.003), steel, sx * 0.026, 0.015, z);
  pistolGrip(G.body, M.rubber(0x252526), cfg.grip, { top: -0.004, len: 0.115, rake: 0.04, w: 0.036 });
  const trigger = triggerGroup(G.moving, M, { y: -0.004, len: 0.075 });
  const crownF = cfg.barrel === 'long' ? 1.0 : 0.88;
  barrel(G.barrelA, M, { y: 0.055, z0: -0.5, len: crownF - 0.5, r: 0.014, r2: 0.016, fluted: true });
  crown(G.barrelA, M, { y: 0.055, z: -crownF, r: 0.014 });
  put(G.body, xcyl(0.006, 0.07, 10), steel, 0, 0.1, -0.15);
  const RT = topRail(G.sights, M, 0.4, 0.09, -0.1);
  const bb = railGeo(0.1, 0.02, 0.008); bb.rotateX(Math.PI); put(G.hg, bb, dark, 0, 0.03, -0.4);
  sideRail(G.hg, M, 0.07, 0.026, 0.06, -0.42, 1);
  put(G.stock, profileGeo([[-0.2, 0.08], [-0.48, 0.07], [-0.5, 0.05], [-0.5, -0.07], [-0.46, -0.08], [-0.3, -0.03], [-0.2, -0.004]], 0.05, 0.005), metal);
  put(G.stock, rbox(0.054, 0.155, 0.03, 0.008), M.rubber(), 0, -0.006, 0.515);
  if (cfg.stock === 'tac') put(G.stock, profileGeo([[-0.25, 0.075], [-0.44, 0.07], [-0.44, 0.095], [-0.27, 0.095]], 0.04, 0.005), M.polymer(0x232426));
  const charge = pivot(G.moving, 'charge', 0.027, 0.06, -0.1);
  put(charge, rbox(0.03, 0.012, 0.016, 0.003), dark, 0.012, 0, 0);
  const magOut = boxMag(G.magA, M, { y: -0.004, z: -0.12, len: cfg.mag === 'ext' ? 0.14 : 0.095, d: 0.14, w: 0.042, curve: 0.0, caliber: [0.138, 0.0098] });
  const s = sock(G, {
    muzzle: [0, 0.055, -crownF], ejection: [0.027, 0.06, -0.05], sight: [0, 0.15, 0.0],
    rightHand: [0, -0.055, 0.035], leftHand: [0, 0.015, -0.4], magWell: [0, -0.004, -0.12],
    optic: [0, RT, -0.05], underbarrel: [0, 0.022, -0.4], laser: [0.033, 0.06, -0.42, Math.PI / 2],
  });
  return finish(root, G, { trigger, charge, mag: magOut.mag }, s, magOut.rounds, { sightType: 'none', opticRequired: true, hasUnder: true });
}

// ====================================================================
// M700 — .308 bolt-action in a skeletal tactical chassis — CONFIRMED
// ====================================================================
export function buildM700(cfg = {}) {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'M700';
  const G = groups(root);
  const chassis = M.gunmetal(0x2e3034), dark = M.blackened(0x141517), steel = M.steel(), grey = M.gunmetal(0x45484c);
  put(G.body, profileGeo([[-0.06, 0.03], [0.14, 0.03], [0.14, 0.058], [-0.06, 0.058]], 0.05, 0.004), chassis);
  put(G.hg, profileGeo([[0.14, 0.022], [0.46, 0.026], [0.46, 0.074], [0.14, 0.076]], 0.046, 0.004), chassis);
  for (let i = 0; i < 6; i++) for (const sx of [1, -1]) put(G.hg, rbox(0.002, 0.012, 0.03, 0.004), M.blackened(0x08090a), sx * 0.0232, 0.048, -(0.18 + i * 0.045));
  put(G.body, zcyl(0.019, 0.019, 0.22, 22), grey, 0, 0.07, -0.05);
  put(G.body, rbox(0.002, 0.014, 0.06, 0.001), M.blackened(0x070708), 0.0195, 0.074, -0.05);
  pistolGrip(G.body, M.rubber(0x26272a), cfg.grip, { top: 0.0, len: 0.105, rake: 0.03 });
  const trigger = triggerGroup(G.moving, M, { y: 0.0, len: 0.07 });
  put(G.body, profileGeo([[-0.04, 0.0], [0.13, 0.0], [0.13, -0.03], [0.04, -0.03]], 0.048, 0.004), chassis);
  const RT = topRail(G.sights, M, 0.5, 0.089, -0.15);
  const bb = railGeo(0.14, 0.02, 0.008); bb.rotateX(Math.PI); put(G.hg, bb, dark, 0, 0.022, -0.35);
  sideRail(G.hg, M, 0.07, 0.023, 0.05, -0.4, 1);
  const crownF = cfg.barrel === 'long' ? 0.82 : 0.72;
  barrel(G.barrelA, M, { y: 0.07, z0: -0.46, len: crownF - 0.46, r: 0.0105, r2: 0.0125, mat: M.blackened(0x26272a) });
  crown(G.barrelA, M, { y: 0.07, z: -crownF, r: 0.0105 });
  put(G.stock, rbox(0.03, 0.04, 0.03, 0.004), chassis, 0, 0.045, 0.075);
  const sk = new THREE.Shape();
  [[-0.08, 0.065], [-0.4, 0.07], [-0.42, 0.05], [-0.42, -0.07], [-0.39, -0.075], [-0.33, -0.02], [-0.1, 0.02], [-0.08, 0.025]].forEach(([f, u], i) => (i ? sk.lineTo(f, u) : sk.moveTo(f, u)));
  sk.closePath();
  const hole = new THREE.Path(); hole.moveTo(-0.15, 0.032); hole.lineTo(-0.33, 0.0); hole.lineTo(-0.37, -0.02); hole.lineTo(-0.36, 0.052); hole.lineTo(-0.14, 0.05); hole.closePath(); sk.holes.push(hole);
  put(G.stock, shapeGeo(sk, 0.03, 0.004, 6), chassis);
  put(G.stock, rbox(0.044, 0.14, 0.02, 0.007), M.rubber(), 0, -0.003, 0.43);
  const cheekH = cfg.stock === 'tac' ? 0.022 : 0.008;
  put(G.stock, profileGeo([[-0.18, 0.07], [-0.36, 0.072], [-0.36, 0.082 + cheekH], [-0.19, 0.082 + cheekH]], 0.036, 0.005), M.polymer(0x232426));
  const { bolt, handle } = boltAssembly(G.moving, M, { y: 0.07, z: 0.03, r: 0.009, knob: 0.0095, knobMat: M.blackened(0x101112), handleLen: 0.045 });
  const magOut = boxMag(G.magA, M, { y: -0.03, z: -0.06, len: cfg.mag === 'ext' ? 0.11 : 0.06, d: 0.075, w: 0.026, curve: 0.006, caliber: [0.071, 0.006] });
  const s = sock(G, {
    muzzle: [0, 0.07, -crownF], ejection: [0.021, 0.074, -0.05], sight: [0, 0.13, 0.04],
    rightHand: [0, -0.05, 0.03], leftHand: [0, 0.01, -0.33], magWell: [0, -0.03, -0.06],
    optic: [0, RT, -0.06], underbarrel: [0, 0.014, -0.35], laser: [0.03, 0.05, -0.4, Math.PI / 2],
  });
  return finish(root, G, { trigger, bolt, boltHandle: handle, mag: magOut.mag }, s, magOut.rounds, { sightType: 'none', opticRequired: true, hasUnder: true });
}

// ====================================================================
// M250 — 6.8 mm belt-fed LMG (tan, ammo pouch) — CONFIRMED name (8:32 loadout)
// ====================================================================
export function buildM250(cfg = {}) {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'M250';
  const G = groups(root);
  const tan = M.paint(0xb7a37c), tanD = M.paint(0x8f7d5b), dark = M.blackened(0x161718), steel = M.steel();
  put(G.body, profileGeo([[-0.14, 0.0], [0.33, 0.0], [0.33, 0.085], [0.0, 0.092], [-0.14, 0.09]], 0.064, 0.004), tan);
  const cover = pivot(G.moving, 'cover', 0, 0.092, 0.02);
  put(cover, profileGeo([[0.0, 0.0], [0.2, 0.0], [0.2, 0.016], [0.0, 0.02]], 0.062, 0.004), tanD);
  for (let i = 0; i < 9; i++) for (const sx of [1, -1]) put(G.hg, rbox(0.002, 0.012, 0.024, 0.003), M.blackened(0x0a0a0b), sx * 0.0322, 0.05, -(0.12 + i * 0.03));
  // belt: visible rounds hanging from the feed tray into the pouch (right side)
  const rounds = [];
  const rg = cartridgeGeo(0.06, 0.0052, 0.38);
  for (let i = 0; i < 6; i++) rounds.push(keep(put(G.body, rg, M.brass(), 0.0345, 0.072 - i * 0.012, -0.03 + i * 0.002)));
  put(G.body, rbox(0.004, 0.03, 0.07, 0.002), dark, 0.034, 0.08, -0.03);   // feed tray mouth
  pistolGrip(G.body, M.polymer(0x6f6450), cfg.grip, { top: 0.0, len: 0.11, rake: 0.035, w: 0.036 });
  const trigger = triggerGroup(G.moving, M, { y: 0.0, len: 0.08 });
  const RT = topRail(G.sights, M, 0.36, 0.112, -0.15, 0.021, 0.009, tanD);
  const irons = flipIrons(G.sights, M, { railTop: RT, rearZ: 0.0, frontZ: -0.31, height: 0.032, folded: cfg.folded });
  const crownF = cfg.barrel === 'long' ? 0.72 : 0.64;
  barrel(G.barrelA, M, { y: 0.045, z0: -0.33, len: crownF - 0.33, r: 0.011, mat: M.blackened(0x222326) });
  put(G.barrelA, ztubeSafe(0.016, 0.011, 0.016), dark, 0, 0.045, -0.42);
  put(G.barrelA, rbox(0.012, 0.05, 0.016, 0.004), dark, 0.0, 0.08, -0.42);   // barrel carry handle post
  crown(G.barrelA, M, { y: 0.045, z: -crownF, r: 0.011 });
  const bb = railGeo(0.15, 0.02, 0.008); bb.rotateX(Math.PI); put(G.hg, bb, dark, 0, 0.0, -0.24);
  sideRail(G.hg, M, 0.07, 0.032, 0.05, -0.27, 1);
  put(G.stock, profileGeo([[-0.14, 0.085], [-0.42, 0.08], [-0.44, 0.06], [-0.44, -0.06], [-0.4, -0.07], [-0.24, -0.01], [-0.14, 0.0]], 0.05, 0.006), tan);
  put(G.stock, rbox(0.052, 0.14, 0.018, 0.007), M.rubber(0x3b342a), 0, 0.006, 0.45);
  const charge = pivot(G.moving, 'charge', -0.034, 0.05, -0.15);
  put(charge, rbox(0.024, 0.012, 0.016, 0.003), dark, -0.01, 0, 0);
  const mag = pivot(G.magA, 'mag', 0.005, -0.004, -0.04);
  const big = cfg.mag === 'ext';
  put(mag, rbox(0.075, big ? 0.13 : 0.1, 0.1, 0.012), M.fabric(0xc8b998), 0, big ? -0.065 : -0.05, 0);
  put(mag, rbox(0.077, 0.03, 0.06, 0.006), M.fabric(0xb0a17f), 0, -0.02, 0.0);
  const s = sock(G, {
    muzzle: [0, 0.045, -crownF], ejection: [0.033, 0.05, -0.02], sight: [0, 0.15, -0.1],
    rightHand: [0, -0.05, 0.035], leftHand: [0, -0.01, -0.24], magWell: [0, -0.004, -0.04],
    optic: [0, RT, -0.06], underbarrel: [0, -0.008, -0.24], laser: [0.039, 0.05, -0.27, Math.PI / 2],
  });
  return finish(root, G, { trigger, charge, mag, cover, rearSight: irons.rear, frontSight: irons.front }, s, rounds, {
    rearSight: new THREE.Vector3(0, irons.SL, -0.008), frontSight: new THREE.Vector3(0, irons.SL, -0.302), sightType: 'iron', hasUnder: true, belt: true,
  });
}

// ====================================================================
// SIDEARM — polymer striker pistol (G17 pattern, secondary-slot pistol
// in the 8:32 loadout screen; on-screen name NOT legible)
// ====================================================================
export function buildSidearm(cfg = {}) {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'Sidearm';
  const G = groups(root);
  const frame = M.polymer(0x2a2b2f), slideM = M.gunmetal(0x3a3c40), dark = M.blackened(0x111214);
  put(G.body, profileGeo([[-0.04, 0.0], [0.13, 0.0], [0.135, 0.02], [-0.04, 0.022]], 0.03, 0.003), frame);
  put(G.body, profileGeo([[-0.032, 0.0], [0.006, 0.0], [-0.004, -0.04], [-0.02, -0.105], [-0.06, -0.103], [-0.055, -0.04], [-0.045, 0.0]], 0.031, 0.005), frame);
  const trigger = triggerGroup(G.moving, M, { y: 0.0, len: 0.05, depth: 0.028 });
  const br = railGeo(0.035, 0.018, 0.006); br.rotateX(Math.PI); put(G.hg, br, dark, 0, 0.0, -0.105);
  const slide = pivot(G.moving, 'slide', 0, 0.02, 0);
  put(slide, profileGeo([[-0.045, 0.0], [0.15, 0.0], [0.155, 0.03], [-0.045, 0.03]], 0.026, 0.003), slideM);
  for (let i = 0; i < 6; i++) for (const sx of [1, -1]) put(slide, rbox(0.0012, 0.022, 0.0025, 0.0004), dark, sx * 0.0131, 0.015, 0.035 - i * 0.005);
  put(slide, rbox(0.002, 0.01, 0.03, 0.001), M.blackened(0x070708), 0.013, 0.022, -0.04);
  // rear notch (two ears) + front post; sight line SL = 0.057
  for (const sx of [1, -1]) put(slide, rbox(0.006, 0.007, 0.008, 0.001), dark, sx * 0.0055, 0.0335, 0.036);
  put(slide, rbox(0.003, 0.007, 0.006, 0.001), dark, 0, 0.0335, -0.145);
  put(slide, ycyl(0.0011, 0.001, 6), M.emissive(0x9dff6a, 2), 0, 0.0372, -0.1415, Math.PI / 2, 0, 0);
  const SL = 0.057;
  const crownF = cfg.barrel === 'long' ? 0.2 : 0.158;
  barrel(G.barrelA, M, { y: 0.032, z0: -0.15, len: crownF - 0.15 + 0.003, r: 0.0055 });
  crown(G.barrelA, M, { y: 0.032, z: -crownF, r: 0.0055 });
  const magOut = boxMag(G.magA, M, { y: -0.004, z: 0.02, len: cfg.mag === 'ext' ? 0.15 : 0.1, d: 0.03, w: 0.022, curve: -0.016, caliber: [0.029, 0.0048], mat: M.polymer(0x1e1f22) });
  const s = sock(G, {
    muzzle: [0, 0.032, -crownF], ejection: [0.014, 0.042, -0.04], sight: [0, SL, -0.05],
    rightHand: [0, -0.045, 0.025], leftHand: [0, -0.05, 0.02], magWell: [0, -0.004, 0.02],
    optic: [0, 0.05, -0.03], underbarrel: [0, -0.006, -0.105], laser: [0, -0.006, -0.105],
  });
  return finish(root, G, { trigger, slide, mag: magOut.mag }, s, magOut.rounds, {
    rearSight: new THREE.Vector3(0, SL, 0.036), frontSight: new THREE.Vector3(0, SL, -0.145), sightType: 'iron', hasUnder: false, pistol: true,
  });
}

function ztubeSafe(ro, ri, len) {
  const g = new THREE.CylinderGeometry(ro, ro, len, 16, 1, true); g.rotateX(-Math.PI / 2); return g;
}
