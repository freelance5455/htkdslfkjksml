// =====================================================================
// Firing: hitscan, damage, impacts, recoil impulses, muzzle FX, casings,
// magazine drops. Mixed into WeaponController (see controller.js).
// One trigger event → one call to fire() → one ray per pellet → at most
// one impact per pellet. Damage is aggregated per target per shot.
// =====================================================================
import * as THREE from 'three';
import { V, E } from './instance.js';
import { cloneMagProp } from './models.js';
import { clamp, lerp, smooth } from '../core/math.js';
import { audio } from '../audio/audio.js';
import { bus } from '../core/events.js';

export const FiringMixin = {
  currentSpread() {
    const def = this.current.def, p = this.player, a = smooth(this.adsBlend);
    const moveSp = clamp(p.speed2D / 7.4, 0, 1);
    return lerp(def.spread + def.moveSpread * moveSp + (p.grounded ? 0 : 0.03), def.adsSpread, a) + this.bloomSpread();
  },
  bloomSpread() {
    const since = this.time - this.lastShotTime;
    return Math.max(0, 0.012 * Math.min(8, this.shotsFired) * Math.exp(-since * 5) * (1 - this.adsBlend * 0.7));
  },

  fire() {
    const w = this.current, def = w.def;
    w.mag--;
    this.fireCooldown = 60 / def.rpm;
    this.shotsFired++;
    this.lastShotTime = this.time;
    const manual = def.cycle === 'boltAction' || def.cycle === 'pump';
    w.chambered = w.mag > 0 && !manual;
    w.needsCycle = manual && w.mag > 0;

    // ---------- hitscan ----------
    const origin = this.camera.getWorldPosition(V());
    const fwd = V(); this.camera.getWorldDirection(fwd);
    const right = V().crossVectors(fwd, V(0, 1, 0)).normalize();
    const up = V().crossVectors(right, fwd).normalize();
    const spread = this.currentSpread();
    const muzzle = this.muzzleWorld();
    const hits = [];
    for (let i = 0; i < def.pellets; i++) {
      const r = spread * (def.pellets > 1 ? Math.sqrt(Math.random()) : (Math.random() + Math.random()) * 0.5);
      const th = Math.random() * Math.PI * 2;
      const dir = fwd.clone().addScaledVector(right, Math.cos(th) * r).addScaledVector(up, Math.sin(th) * r).normalize();
      const hit = this.physics.raycast(origin, dir, def.range);
      const end = hit ? hit.point : origin.clone().addScaledVector(dir, Math.min(def.range, 300));
      if (hit) hits.push({ hit, dir });
      if ((def.pellets === 1 || i % 3 === 0) && end.distanceTo(muzzle) > 2.5) {
        this.fx.tracer(muzzle.clone().addScaledVector(dir, 0.5), end, def.pellets > 1 ? 260 : 430, def.pellets > 1 ? 2.2 : 4.5);
      }
    }
    const perTarget = new Map();
    for (const { hit, dir } of hits) {
      const kind = hit.material === 'metal' ? 'metal' : 'concrete';
      this.fx.addDecal(hit.point, hit.normal, kind, def.pellets > 1 ? 0.05 : def.id === 'ranger' ? 0.1 : 0.075, hit.target ? hit.target.object3D : null);
      this.fx.impact(hit.point, hit.normal, hit.material, def.pellets > 1 ? 0.45 : 1);
      if (!hit.target) continue;
      const [f0, f1, minMul] = def.falloff;
      const d = hit.distance;
      let dmg = def.damage * (d <= f0 ? 1 : d >= f1 ? minMul : lerp(1, minMul, (d - f0) / (f1 - f0)));
      let crit = false;
      const lp = hit.localPoint;
      if (hit.target.kind === 'paper' && lp && Math.hypot(lp.x, lp.y - 1.25) < 0.12) { dmg *= 1.6; crit = true; }
      if (hit.target.kind === 'mover' && lp && lp.y > hit.target.headY) { dmg *= def.headMul || 1.8; crit = true; }
      const e = perTarget.get(hit.target) || { dmg: 0, crit: false, point: hit.point, dir };
      e.dmg += dmg; e.crit ||= crit; perTarget.set(hit.target, e);
    }
    hits.slice(0, 2).forEach(({ hit }) => {
      const name = hit.material === 'metal' ? (hit.target ? 'hit_bell' : 'hit_plate') : hit.material === 'wood' ? 'hit_soft' : 'hit_concrete';
      audio.play(name, { cat: 'environment', at: hit.point, volume: hit.material === 'metal' ? 0.8 : 0.6, refDistance: 6 });
    });
    for (const [target, e] of perTarget) {
      const res = this.map.onTargetHit(target, null, e.dmg, e.dir) || {};
      bus.emit('weapon:hit', { point: e.point, damage: Math.round(e.dmg), crit: e.crit, killed: !!res.killed });
    }

    // ---------- presentation ----------
    this.recoilKick();
    this.muzzleFlash(muzzle, fwd);
    const [p0, p1] = def.shotPitch;
    // Rapid-fire voice management: each weapon's gunshot is its own voice
    // group, capped so overlapping tails never pile up; the oldest voice is
    // faded (not cut). The environment tail is a single retriggered voice.
    const auto = def.rpm >= 400;
    audio.play(def.sound, { cat: 'weapons', volume: def.shotVolume, rate: lerp(p0, p1, Math.random()), rateJitter: 0, group: 'shot', maxGroup: auto ? 3 : 4, minInterval: 0.02, lowpass: def.suppressedLowpass });
    if (this.tailVoice) audio._kill(this.tailVoice);
    this.tailVoice = audio.play('shot_tail', { cat: 'environment', volume: auto ? 0.22 : 0.35, delay: 0.03, lowpass: 900, minInterval: 0 });
    if (w.mag === 0) audio.play('metal_light', { cat: 'weapons', volume: 0.3, rate: 1.6, delay: 0.06 });
    if (def.cycle === 'bolt' || def.cycle === 'charge' || def.cycle === 'slide') { this.autoCycleT = 0; this.ejectCase(); }
    else if (manual && w.mag > 0) this.startManualCycle(0.12);
    w.model.parts.trigger.rotation.x = 0.25;
    this.player.sprinting = false;
    w.updateRounds();
    bus.emit('weapon:fired', this.hudState());
  },

  recoilKick() {
    const r = this.current.def.recoil;
    const a = smooth(this.adsBlend);
    const mul = lerp(1, r.adsMul, a) * (this.player.crouching ? 0.85 : 1);
    this.rPosZ.impulse(r.kickBack * 30 * mul);
    this.rPosY.impulse(r.kickUp * 30 * mul * (1 - a * 0.6));
    this.rRotX.impulse(r.pitch * 40 * mul * (1 - a * 0.5));
    this.rRotZ.impulse((Math.random() - 0.5) * r.roll * 30 * mul);
    this.rRotY.impulse((Math.random() - 0.5) * r.yaw * 30 * mul);
    const pitchKick = r.pitch * mul * (0.85 + Math.random() * 0.3) * (1 + Math.min(this.shotsFired, 10) * 0.025);
    this.camKick.pitchVel += pitchKick * 18;
    this.camKick.yaw += (Math.random() * 2 - 1 + r.yawBias) * r.yaw * mul;
  },

  updateCameraRecoil(dt) {
    const r = this.current.def.recoil, ck = this.camKick;
    ck.pitch += ck.pitchVel * dt;
    ck.pitchVel *= Math.exp(-28 * dt);
    const recovering = this.time - this.lastShotTime > (60 / this.current.def.rpm) * 1.2;
    const rec = recovering ? r.recover : r.recover * 0.25;
    ck.pitch += (0 - ck.pitch) * (1 - Math.exp(-rec * dt));
    ck.yaw += (0 - ck.yaw) * (1 - Math.exp(-rec * 0.8 * dt));
    ck.pitch = Math.min(ck.pitch, 0.25);
    this.player.recoilPitch = ck.pitch;
    this.player.recoilYaw = ck.yaw;
  },

  /** Viewmodel-space point → world space (vm camera has a different FOV). */
  vmToWorld(vmPos) {
    const ndc = vmPos.clone().project(this.vmCamera);
    const depth = -vmPos.z;
    const camPos = this.camera.getWorldPosition(V());
    const dir = V(ndc.x, ndc.y, 0.5).unproject(this.camera).sub(camPos).normalize();
    const fwd = V(); this.camera.getWorldDirection(fwd);
    return camPos.addScaledVector(dir, depth / Math.max(0.05, dir.dot(fwd)));
  },
  muzzleWorld() {
    const s = this.current.model.sockets.muzzle;
    s.updateWorldMatrix(true, false);
    return this.vmToWorld(s.getWorldPosition(V()));
  },

  ejectCase() {
    const def = this.current.def;
    const ej = this.current.model.sockets.ejection;
    ej.updateWorldMatrix(true, false);
    const world = this.vmToWorld(ej.getWorldPosition(V()));
    const camQ = this.camera.getWorldQuaternion(new THREE.Quaternion());
    const vel = V(1.8 + Math.random() * 0.8, 1.6 + Math.random() * 0.8, 0.4 + Math.random() * 0.4).applyQuaternion(camQ);
    vel.x += this.player.vel.x; vel.z += this.player.vel.z;
    const q = camQ.clone().multiply(new THREE.Quaternion().setFromEuler(E(0, Math.PI / 2, 0)));
    this.fx.ejectCasing(def.caseEject === 'shell' ? 'shell' : def.caseEject, world, vel, q);
  },

  muzzleFlash(worldPos, fwd) {
    const def = this.current.def;
    const fm = def.flashMul ?? 1;
    if (fm > 0.3) this.fx.flashAt(worldPos.clone().addScaledVector(fwd, 0.15), (def.pellets > 1 ? 1.4 : 1.0) * fm);
    this.fx.muzzleSmoke(worldPos, fwd, def.pellets > 1 ? 2 : 1);
    if (!this.flash) this.buildFlash();
    const fs = this.flash;
    this.current.model.sockets.muzzle.add(fs.group);
    fs.t = 0.045;
    const v = Math.floor(Math.random() * 4);
    fs.front.material.map.offset.set((v % 2) * 0.5, Math.floor(v / 2) * 0.5);
    const scale = def.pellets > 1 ? 1.3 : def.id === 'ranger' ? 1.4 : 1.0;
    fs.group.scale.setScalar(scale * (def.flashMul ?? 1) * (0.85 + Math.random() * 0.3));
    fs.front.rotation.z = Math.random() * Math.PI;
    fs.group.visible = (def.flashMul ?? 1) > 0.2 && !(def.ads.scope && this.adsBlend > 0.9);
  },
  buildFlash() {
    const mk = () => { const t = this.fx.flashTex.clone(); t.repeat.set(0.5, 0.5); t.needsUpdate = true; return t; };
    const mat = new THREE.MeshBasicMaterial({ map: mk(), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, color: new THREE.Color(1.6, 1.3, 1.0) });
    const sideMat = mat.clone(); sideMat.map = mk();
    const group = new THREE.Group();
    const front = new THREE.Mesh(new THREE.PlaneGeometry(0.11, 0.11), mat); front.position.z = -0.03;
    const s1 = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 0.065), sideMat); s1.rotation.y = Math.PI / 2; s1.position.z = -0.08;
    const s2 = s1.clone(); s2.rotation.z = Math.PI / 2;
    group.add(front, s1, s2);
    group.traverse((o) => { o.frustumCulled = false; o.renderOrder = 10; });
    group.visible = false;
    this.flash = { group, front, t: 0 };
  },
  updateFlash(dt) {
    if (!this.flash || this.flash.t <= 0) return;
    this.flash.t -= dt;
    if (this.flash.t <= 0) this.flash.group.visible = false;
  },

  dropMagProp() {
    const w = this.current;
    const prop = cloneMagProp(w.model);
    if (!prop) return;
    const mag = w.model.parts.mag;
    mag.updateWorldMatrix(true, false);
    const worldPos = this.vmToWorld(mag.getWorldPosition(V()));
    const camQ = this.camera.getWorldQuaternion(new THREE.Quaternion());
    const q = camQ.clone().multiply(mag.getWorldQuaternion(new THREE.Quaternion()));
    const m = new THREE.Matrix4().compose(worldPos, q, V(1, 1, 1));
    const vel = V(0, -1.2, 0).applyQuaternion(camQ); vel.x += this.player.vel.x * 0.8; vel.z += this.player.vel.z * 0.8;
    // dropped mag is empty → hide its cartridges
    prop.traverse((o) => { if (o.material && o.material.name === 'brass') o.visible = false; });
    this.fx.dropMagazine(prop, m, vel);
  },
};
