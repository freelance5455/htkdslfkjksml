// =====================================================================
// Reference weapon models (procedural reconstructions)
// ---------------------------------------------------------------------
// Built from the supplied reference footage. Each builder returns:
//   { root, parts:{...pivots}, sockets:{ muzzle, ejection, magWell, leftHand,
//     rightHand, sight }, rounds:[mesh...], meta }
//
// Reference checklist (from frame study):
//  DYNASTY  (assault rifle, AK-pattern, "Empty" + "Tactical" reloads)
//    ✓ dark gunmetal receiver, ribbed dust cover, red pinstripe along side
//    ✓ tall front sight "horn" post on gas block, rear tangent sight
//    ✓ long barrel w/ slotted muzzle brake, gas tube above barrel
//    ✓ curved steel magazine (ribbed), magazine release paddle
//    ✓ right-side charging handle on bolt carrier (reciprocates)
//    ✓ white/steel skeletal stock with brown wood insert + brass rivets
//    ✓ pistol grip, trigger guard, safety lever
//  VANGUARD (SMG — reclassified per bug-fix spec: 9mm stick mag, aperture/hooded-post irons)
//    ✓ chunky bone-white / olive camo receiver, heavy top rail
//    ✓ orange loop (ring) sight on rail — signature feature
//    ✓ orange charging handle on top-left, rectangular box magazine
//    ✓ dark olive lower, textured grip, flat-faced muzzle shroud
//  RANGER   (bolt-action sniper, "Empty" + "Tactical" reloads)
//    ✓ olive/grey stock w/ orange knob/turret accents, wood lower stock
//    ✓ large scope, octagonal objective bell (dark), rings
//    ✓ bolt handle (rotates + slides), long fluted barrel, bipod legs
//    ✓ detachable box magazine; sling strap at front
//  BIG RIG  (heavy shotgun, "Empty Reload": swing open + shells)
//    ✓ dark grey slab-sided body, bright orange side panels
//    ✓ ring rear sight on raised mount; top carry/charging bar
//    ✓ fat muzzle can (suppressor-like) + rust-orange forward handle
//    ✓ square cut-outs / rivets on receiver sides, box magazine
//  KRAKEN   (top-loading pump shotgun, "Empty Reload": shell into top port)
//    ✓ charcoal/bronze heat-shielded barrel, orange glow indicators
//    ✓ top loading port, red shells with brass bases (visible rounds)
//    ✓ grooved pump handle, orange glowing reflex optic, purple accent light
// Hidden internals are not invented beyond what animations need.
// =====================================================================
import * as THREE from 'three';
import {
  getShared, profileGeo, shapeGeo, rbox, zcyl, xcyl, ycyl, zlathe, ztube, railGeo, screwGeo, ribsGeo,
  put, pivot, socket, finalize, captureRest, cartridgeGeo, cartridgeCaseGeo, projectileGeo, shellGeos, merge,
} from './kit.js';
import { makeReflexLens, makeScopeLens } from './optics.js';

const keep = (m) => { m.userData.keep = true; return m; };

// ---------- shared hand-off helpers ----------
function sockets(root, s) {
  const out = {};
  for (const [k, v] of Object.entries(s)) out[k] = socket(root, k, v[0], v[1], v[2]);
  return out;
}

// ====================================================================
// DYNASTY — AK-pattern assault rifle
// ====================================================================
export function buildDynasty() {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'Dynasty';
  const recv = M.gunmetal(0x34373b), dark = M.blackened(), steel = M.steel(), red = M.paint(0xa8231d);
  const white = M.gloveWhite(), wood = M.wood(), brass = M.brass();

  // --- lower receiver / trunnion body (stamped, with mag-well cut) ---
  put(root, profileGeo([[-0.06, 0.0], [0.2, 0.0], [0.205, 0.012], [0.2, 0.06], [-0.075, 0.062], [-0.09, 0.045], [-0.09, 0.012]], 0.046, 0.003), recv, 0, 0.0, 0);
  // red pinstripe both sides
  put(root, rbox(0.0012, 0.004, 0.27, 0.0005), red, 0.0235, 0.047, -0.065);
  put(root, rbox(0.0012, 0.004, 0.27, 0.0005), red, -0.0235, 0.047, -0.065);
  // stamped side dimple above magazine
  put(root, rbox(0.002, 0.014, 0.04, 0.003), dark, 0.0235, 0.025, -0.11);
  put(root, rbox(0.002, 0.014, 0.04, 0.003), dark, -0.0235, 0.025, -0.11);
  // rivets
  for (const z of [-0.04, -0.075, -0.15, -0.18]) for (const sx of [1, -1]) put(root, screwGeo(0.0028, 0.002), steel, sx * 0.0238, 0.012, z);
  // --- dust cover (ribbed, slightly domed) ---
  const coverShape = new THREE.Shape();
  coverShape.moveTo(-0.07, 0); coverShape.lineTo(0.205, 0); coverShape.lineTo(0.205, 0.014); coverShape.quadraticCurveTo(0.07, 0.026, -0.06, 0.024); coverShape.lineTo(-0.07, 0.018); coverShape.closePath();
  put(root, shapeGeo(coverShape, 0.044, 0.003), recv, 0, 0.062, 0);
  put(root, ribsGeo(4, [0.046, 0.003, 0.006], 0.022, 'z'), dark, 0, 0.083, 0.11);
  // rear tangent sight: base block + leaf with an OPEN U-notch.
  // Sight line height SL = 0.092 (notch top == front post tip).
  const SL = 0.092;
  put(root, rbox(0.03, 0.016, 0.03, 0.003), recv, 0, 0.066, -0.215);
  put(root, rbox(0.026, 0.006, 0.05, 0.0015), steel, 0, 0.077, -0.235);
  // notch leaf = two ears with a 5 mm gap; bar below the notch
  for (const sx of [1, -1]) put(root, rbox(0.009, SL - 0.074, 0.004, 0.0008), dark, sx * 0.007, (SL + 0.074) / 2, -0.212);
  put(root, rbox(0.024, 0.004, 0.004, 0.0008), dark, 0, 0.076, -0.212);
  // --- handguard (dark polymer, vent slots) ---
  put(root, profileGeo([[0.205, 0.008], [0.43, 0.012], [0.43, 0.058], [0.205, 0.062]], 0.05, 0.005), M.polymer(0x2b2723), 0, 0, 0);
  for (let i = 0; i < 4; i++) for (const sx of [1, -1]) put(root, rbox(0.002, 0.007, 0.03, 0.002), dark, sx * 0.0255, 0.035, -0.24 - i * 0.045);
  // upper gas tube cover
  put(root, zcyl(0.011, 0.012, 0.22, 16), recv, 0, 0.066, -0.32);
  // --- barrel ---
  put(root, zcyl(0.0085, 0.0095, 0.34, 18), steel, 0, 0.034, -0.55);
  // gas block + front sight post ("horn")
  put(root, rbox(0.028, 0.04, 0.03, 0.004), recv, 0, 0.05, -0.58);
  // front sight "horn": two side ears (open in the middle) + thin post.
  // Seen from the eye the ears flank the target; only the 2.4 mm post sits
  // under the aim point with its tip exactly on the sight line.
  put(root, rbox(0.022, 0.012, 0.016, 0.002), dark, 0, 0.076, -0.585);
  for (const sx of [1, -1]) put(root, profileGeo([[-0.008, 0], [0.008, 0], [0.006, SL - 0.07 + 0.01], [-0.006, SL - 0.07 + 0.01]], 0.003, 0.0006), dark, sx * 0.0095, 0.07, -0.585);
  put(root, ycyl(0.0012, SL - 0.081, 6, 0.0016), steel, 0, (SL + 0.081) / 2, -0.585); // post, tip at SL
  // muzzle brake (slotted)
  put(root, zcyl(0.012, 0.012, 0.055, 14), dark, 0, 0.034, -0.745);
  for (let i = 0; i < 3; i++) put(root, rbox(0.026, 0.004, 0.006, 0.001), steel, 0, 0.034, -0.73 - i * 0.012);
  // --- pistol grip + trigger guard + trigger ---
  put(root, profileGeo([[-0.03, 0.002], [0.012, 0.002], [0.004, -0.04], [-0.012, -0.11], [-0.048, -0.11], [-0.04, -0.06]], 0.034, 0.005), M.rubber(0x2a221d), 0, 0, 0);
  put(root, profileGeo([[0.0, 0.0], [0.07, 0.0], [0.072, -0.004], [0.004, -0.032], [0.0, -0.028], [0.06, -0.006], [0.0, -0.006]], 0.008, 0.001), dark, 0, 0, 0);
  const trigger = pivot(root, 'trigger', 0, -0.002, -0.03);
  put(trigger, profileGeo([[0, 0], [0.006, 0], [0.004, -0.018], [-0.002, -0.022]], 0.006, 0.0008), steel);
  // safety lever
  put(root, rbox(0.003, 0.012, 0.11, 0.0015), steel, 0.0245, 0.045, -0.03);
  // --- stock (white steel skeleton + wood cheek insert) ---
  put(root, profileGeo([[-0.075, 0.06], [-0.09, 0.06], [-0.36, 0.035], [-0.36, -0.07], [-0.33, -0.075], [-0.09, 0.0], [-0.075, 0.005]], 0.036, 0.006), white, 0, 0, 0);
  put(root, profileGeo([[-0.12, 0.042], [-0.32, 0.024], [-0.32, -0.04], [-0.14, 0.006]], 0.039, 0.004), wood, 0, 0, 0);
  put(root, rbox(0.044, 0.112, 0.018, 0.006), M.rubber(), 0, -0.018, 0.37); // butt pad
  for (const z of [0.16, 0.24, 0.3]) for (const sx of [1, -1]) put(root, screwGeo(0.003, 0.002), brass, sx * 0.0198, 0.01, z);
  // sling loop
  put(root, new THREE.TorusGeometry(0.009, 0.0018, 6, 12), steel, 0.02, 0.055, -0.4, 0, Math.PI / 2, 0);

  // --- bolt carrier & charging handle (right side, reciprocates) ---
  const bolt = pivot(root, 'bolt', 0, 0.05, 0);
  put(bolt, rbox(0.012, 0.016, 0.11, 0.002), steel, 0.018, 0, -0.06);
  put(bolt, rbox(0.03, 0.006, 0.008, 0.002), steel, 0.04, 0, -0.012);          // handle stem
  put(bolt, ycyl(0.006, 0.014, 10), dark, 0.057, 0, -0.012, 0, 0, Math.PI / 2); // knob
  // ejection port (dark recess)
  put(root, rbox(0.002, 0.016, 0.05, 0.001), M.blackened(0x0c0c0d), 0.0232, 0.055, -0.07);

  // --- magazine (curved steel w/ ribs) ---
  const mag = pivot(root, 'mag', 0, 0.002, -0.115);
  const magShape = new THREE.Shape();
  magShape.moveTo(-0.034, 0.0); magShape.lineTo(0.034, 0.0);
  magShape.quadraticCurveTo(0.044, -0.09, 0.085, -0.19);
  magShape.lineTo(0.034, -0.205);
  magShape.quadraticCurveTo(-0.004, -0.11, -0.034, 0.0);
  put(mag, shapeGeo(magShape, 0.028, 0.003, 14), M.gunmetal(0x45484c));
  put(mag, ribsGeo(1, [0.03, 0.006, 0.006], 0, 'z'), steel, 0, -0.06, -0.008); // feed lip ridge
  for (let i = 0; i < 3; i++) put(mag, rbox(0.0305, 0.008, 0.004, 0.001), dark, 0, -0.05 - i * 0.04, 0.0 - i * 0.017 - 0.012);
  put(mag, rbox(0.032, 0.008, 0.05, 0.002), dark, 0, -0.2, -0.06, 0.42, 0, 0); // base plate
  // visible top rounds (feed lips) — ammo-synced
  const rounds = [];
  const cgeo = cartridgeGeo(0.039, 0.0056, 0.36);
  for (let i = 0; i < 2; i++) {
    const r = keep(put(mag, cgeo, brass, (i % 2 ? 0.004 : -0.004), 0.002 - i * 0.002, 0.016 - i * 0.002));
    rounds.push(r);
  }
  // mag release paddle
  put(root, rbox(0.016, 0.004, 0.02, 0.001), steel, 0, -0.004, -0.073);

  const s = sockets(root, {
    muzzle: [0, 0.034, -0.775], ejection: [0.026, 0.055, -0.07], sight: [0, 0.088, -0.4],
    rightHand: [0, -0.04, 0.035], leftHand: [0, 0.01, -0.33], magWell: [0, 0.0, -0.115],
  });
  captureRest(root);
  finalize(root);
  return {
    root, parts: { trigger, bolt, mag }, sockets: s, rounds,
    meta: { rearSight: new THREE.Vector3(0, 0.092, -0.212), frontSight: new THREE.Vector3(0, 0.092, -0.585), sightType: 'iron' },
  };
}

// ====================================================================
// VANGUARD — submachine gun (bone/olive camo, orange hooded front sight)
// ====================================================================
export function buildVanguard() {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'Vanguard';
  const camo = M.camo(), olive = M.paint(0x4c5636), dark = M.blackened(0x202219), orange = M.paint(0xe2761c), steel = M.steel();

  // main chunky upper receiver (bone/camo), angular "shark" nose
  put(root, profileGeo([[-0.17, 0.0], [0.2, 0.0], [0.3, 0.012], [0.34, 0.04], [0.33, 0.085], [0.2, 0.1], [-0.12, 0.1], [-0.17, 0.075]], 0.068, 0.008), camo, 0, 0, 0);
  // lower olive housing (trigger group + magwell)
  put(root, profileGeo([[-0.17, 0.003], [0.13, 0.003], [0.13, -0.04], [-0.02, -0.045], [-0.17, -0.03]], 0.062, 0.006), olive, 0, 0, 0);
  // panel seams & bolts
  for (const sx of [1, -1]) {
    put(root, rbox(0.002, 0.003, 0.3, 0.001), dark, sx * 0.0345, 0.05, -0.05);
    for (const z of [0.12, -0.02, -0.16, -0.26]) put(root, screwGeo(0.004, 0.002), steel, sx * 0.0348, 0.07, z);
    put(root, rbox(0.003, 0.03, 0.06, 0.004), olive, sx * 0.0345, 0.04, -0.27); // side vent plate
    for (let i = 0; i < 3; i++) put(root, rbox(0.002, 0.004, 0.045, 0.001), dark, sx * 0.0362, 0.03 + i * 0.01, -0.27);
  }
  // heavy top rail (top surface y = 0.112)
  put(root, railGeo(0.34, 0.03, 0.012), dark, 0, 0.1, -0.03);
  // ---- SMG IRON SIGHTS on the rail. Sight line SL = 0.135 (parallel to bore) ----
  const SL = 0.135;
  // rear aperture: clamp block + ring (aperture centre exactly on SL)
  put(root, rbox(0.026, 0.01, 0.022, 0.002), dark, 0, 0.117, 0.07);
  for (const sx of [1, -1]) put(root, rbox(0.004, SL - 0.118, 0.008, 0.001), dark, sx * 0.009, (SL + 0.118) / 2 - 0.002, 0.07);
  put(root, new THREE.TorusGeometry(0.0062, 0.0019, 8, 20), dark, 0, SL, 0.07);
  // front post inside a protective hood ring (orange = Vanguard signature colour)
  put(root, rbox(0.024, 0.01, 0.02, 0.002), dark, 0, 0.117, -0.2);
  put(root, ycyl(0.0013, SL - 0.122, 6, 0.0018), steel, 0, (SL + 0.122) / 2, -0.2);         // post, tip at SL
  put(root, new THREE.TorusGeometry(0.0125, 0.0022, 8, 24), orange, 0, SL - 0.001, -0.2); // hood ring
  for (const sx of [1, -1]) put(root, rbox(0.003, 0.014, 0.006, 0.001), orange, sx * 0.011, 0.126, -0.2);
  // muzzle shroud (flat-faced, slotted)
  put(root, profileGeo([[0.33, 0.012], [0.42, 0.02], [0.42, 0.08], [0.33, 0.088]], 0.06, 0.006), olive, 0, 0, 0);
  put(root, zcyl(0.017, 0.017, 0.03, 18), dark, 0, 0.05, -0.43);
  put(root, ztube(0.017, 0.012, 0.012, 18), steel, 0, 0.05, -0.448);
  for (let i = 0; i < 3; i++) for (const sx of [1, -1]) put(root, rbox(0.002, 0.04, 0.01, 0.002), dark, sx * 0.0305, 0.05, -0.35 - i * 0.022);
  // grip (stippled) + guard + trigger
  put(root, profileGeo([[-0.05, -0.03], [-0.01, -0.03], [-0.02, -0.08], [-0.034, -0.14], [-0.08, -0.14], [-0.074, -0.09]], 0.036, 0.006), M.rubber(0x2a2b24), 0, 0, 0.0);
  put(root, profileGeo([[0.0, -0.03], [0.08, -0.03], [0.08, -0.062], [0.0, -0.065], [0.006, -0.058], [0.074, -0.056], [0.074, -0.036], [0.0, -0.036]], 0.01, 0.0015), dark, 0, 0, 0);
  const trigger = pivot(root, 'trigger', 0, -0.033, -0.035);
  put(trigger, profileGeo([[0, 0], [0.007, 0], [0.004, -0.02], [-0.002, -0.024]], 0.007, 0.0008), steel);
  // forward grip block under nose
  put(root, profileGeo([[0.2, -0.0], [0.3, 0.012], [0.29, -0.03], [0.21, -0.04]], 0.05, 0.006), olive, 0, 0, 0);
  // stock (bullpup rear, rubber pad)
  put(root, profileGeo([[-0.17, 0.075], [-0.3, 0.07], [-0.32, 0.05], [-0.32, -0.05], [-0.17, -0.03]], 0.06, 0.008), camo, 0, 0, 0);
  put(root, rbox(0.064, 0.13, 0.02, 0.008), M.rubber(), 0, 0.01, 0.325);

  // ORANGE CHARGING HANDLE on top-left (slides back on rail channel)
  const charge = pivot(root, 'charge', -0.036, 0.09, -0.1);
  put(charge, rbox(0.012, 0.014, 0.05, 0.003), orange, -0.004, 0, 0);
  put(charge, rbox(0.018, 0.02, 0.014, 0.004), orange, -0.012, 0.004, 0.018);
  put(root, rbox(0.004, 0.006, 0.16, 0.001), M.blackened(0x0c0c0d), -0.0345, 0.09, -0.07); // channel

  // magwell collar in front of the trigger guard
  put(root, rbox(0.034, 0.02, 0.046, 0.003), olive, 0, -0.046, -0.105);
  // 9mm stick magazine (slightly curved, steel body, polymer base) + visible top rounds
  const mag = pivot(root, 'mag', 0, -0.05, -0.105);
  const ms = new THREE.Shape();
  ms.moveTo(-0.017, 0.0); ms.lineTo(0.017, 0.0);
  ms.quadraticCurveTo(0.02, -0.09, 0.034, -0.175);
  ms.lineTo(0.0, -0.18);
  ms.quadraticCurveTo(-0.012, -0.09, -0.017, 0.0);
  put(mag, shapeGeo(ms, 0.024, 0.0025, 12), M.gunmetal(0x3b3e33));
  for (const sx of [1, -1]) put(mag, rbox(0.0015, 0.12, 0.006, 0.0007), dark, sx * 0.0122, -0.085, -0.006, -0.12, 0, 0); // stiffening ribs
  put(mag, rbox(0.028, 0.012, 0.04, 0.003), M.polymer(0x2a2c22), 0, -0.182, -0.017, 0.16, 0, 0);                 // base pad
  const rounds = [];
  const cg = cartridgeGeo(0.029, 0.0048, 0.4);
  for (let i = 0; i < 2; i++) rounds.push(keep(put(mag, cg, M.brass(), i ? 0.004 : -0.004, 0.003 - i * 0.003, 0.014)));

  const s = sockets(root, {
    muzzle: [0, 0.05, -0.455], ejection: [0.036, 0.06, -0.02], sight: [0, 0.145, -0.17],
    rightHand: [0, -0.06, 0.05], leftHand: [0, -0.02, -0.26], magWell: [0, -0.05, -0.105],
  });
  captureRest(root);
  finalize(root);
  return {
    root, parts: { trigger, charge, mag }, sockets: s, rounds,
    meta: { rearSight: new THREE.Vector3(0, 0.135, 0.07), frontSight: new THREE.Vector3(0, 0.135, -0.2), sightType: 'iron' },
  };
}

// ====================================================================
// RANGER — bolt-action sniper rifle with large scope
// ====================================================================
export function buildRanger() {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'Ranger';
  const olive = M.paint(0x6e6a55), grey = M.gunmetal(0x55575a), dark = M.blackened(), orange = M.paint(0xd8561e), steel = M.steel(), wood = M.woodRed();

  // receiver tube
  put(root, zcyl(0.02, 0.02, 0.22, 22), grey, 0, 0.04, -0.08);
  put(root, zlathe([[0, 0.02], [0.02, 0.016], [0.02, 0]], 20), grey, 0, 0.04, 0.03, 0, Math.PI, 0); // rear cap
  // stock: olive upper body with orange accents, wood lower/butt
  put(root, profileGeo([[0.18, 0.025], [-0.02, 0.025], [-0.05, 0.05], [-0.1, 0.05], [-0.42, 0.058], [-0.43, -0.07], [-0.2, -0.05], [-0.06, -0.012], [0.12, -0.015], [0.32, 0.0], [0.33, 0.025]], 0.05, 0.008), olive, 0, 0, 0);
  put(root, profileGeo([[-0.15, -0.035], [-0.42, -0.02], [-0.43, -0.075], [-0.2, -0.056]], 0.053, 0.006), wood, 0, 0, 0);
  put(root, rbox(0.054, 0.14, 0.024, 0.008), M.rubber(0x2b2420), 0, -0.006, 0.44);
  // cheek riser with orange adjustment knob (signature orange discs)
  put(root, profileGeo([[-0.14, 0.05], [-0.34, 0.06], [-0.34, 0.085], [-0.16, 0.078]], 0.04, 0.006), olive, 0, 0, 0);
  for (const sx of [1, -1]) {
    put(root, xcyl(0.016, 0.012, 20), orange, sx * 0.028, 0.0, -0.04);   // big orange disc on stock (side)
    put(root, xcyl(0.008, 0.016, 12), steel, sx * 0.03, 0.0, -0.04);
  }
  // pistol grip + guard + trigger
  put(root, profileGeo([[-0.04, -0.01], [0.0, -0.012], [-0.012, -0.06], [-0.03, -0.115], [-0.07, -0.11], [-0.06, -0.05]], 0.034, 0.006), wood, 0, 0, 0);
  put(root, profileGeo([[0.0, -0.014], [0.07, -0.016], [0.07, -0.048], [0.0, -0.05], [0.006, -0.044], [0.064, -0.042], [0.064, -0.022], [0.0, -0.02]], 0.008, 0.001), dark, 0, 0, 0);
  const trigger = pivot(root, 'trigger', 0, -0.017, -0.03);
  put(trigger, profileGeo([[0, 0], [0.006, 0], [0.004, -0.018], [-0.002, -0.022]], 0.006, 0.0008), steel);
  // barrel (fluted heavy profile) + muzzle brake
  put(root, zcyl(0.0105, 0.014, 0.52, 20), dark, 0, 0.04, -0.45);
  for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; put(root, rbox(0.003, 0.003, 0.3, 0.001), steel, Math.cos(a) * 0.0122, 0.04 + Math.sin(a) * 0.0122, -0.44); }
  put(root, zcyl(0.016, 0.016, 0.05, 16), grey, 0, 0.04, -0.735);
  put(root, ztube(0.016, 0.009, 0.006, 16), steel, 0, 0.04, -0.762);
  for (const sx of [1, -1]) put(root, rbox(0.004, 0.014, 0.028, 0.001), M.blackened(0x0c0c0d), sx * 0.015, 0.04, -0.735);
  // bipod (folded under forend)
  for (const sx of [1, -1]) {
    put(root, rbox(0.008, 0.008, 0.18, 0.002), dark, sx * 0.016, -0.022, -0.38, 0.06, 0, 0);
    put(root, rbox(0.012, 0.012, 0.02, 0.003), M.rubber(), sx * 0.016, -0.028, -0.47);
  }
  put(root, rbox(0.044, 0.016, 0.03, 0.004), grey, 0, -0.012, -0.29);
  // sling strap (front swivel)
  put(root, new THREE.TorusGeometry(0.01, 0.0022, 6, 12), steel, -0.028, 0.0, -0.3, 0, Math.PI / 2, 0);

  // --- SCOPE BASE: one-piece rail screwed to the receiver (receiver top y = 0.060) ---
  put(root, rbox(0.024, 0.008, 0.2, 0.002), grey, 0, 0.064, -0.08);           // base 0.060..0.068
  put(root, railGeo(0.2, 0.022, 0.009), dark, 0, 0.066, -0.08);               // rail top 0.075
  for (const z of [-0.15, -0.01]) put(root, ycyl(0.003, 0.004, 8), steel, 0, 0.07, z);
  // --- SCOPE: rings + tube + turrets + octagonal objective bell ---
  // optical axis y = 0.110, parallel to the bore (bore y = 0.040, both along -Z)
  const scope = new THREE.Group(); scope.name = 'OpticAssembly'; scope.position.set(0, 0.11, -0.08); root.add(scope);
  put(scope, zcyl(0.017, 0.017, 0.24, 24), grey, 0, 0, -0.01);
  put(scope, zlathe([[0.11, 0.017], [0.13, 0.022], [0.15, 0.022], [0.16, 0.019]], 24), grey, 0, 0, 0.12, 0, Math.PI, 0); // eyepiece
  // octagonal objective bell (8 sides)
  const bell = new THREE.CylinderGeometry(0.036, 0.02, 0.085, 8, 1, true); bell.rotateX(-Math.PI / 2); bell.rotateZ(Math.PI / 8);
  put(scope, bell, M.gunmetal(0x3d3b33), 0, 0, -0.17);
  const bellRim = new THREE.CylinderGeometry(0.038, 0.038, 0.012, 8); bellRim.rotateX(-Math.PI / 2); bellRim.rotateZ(Math.PI / 8);
  put(scope, bellRim, dark, 0, 0, -0.215);
  const objLens = new THREE.CircleGeometry(0.031, 24); objLens.rotateY(Math.PI);
  put(scope, objLens, M.glass(0x203028), 0, 0, -0.205);
  // ocular lens = picture-in-picture magnified view (see optics.js)
  const lens = makeScopeLens(0.019, 'mildot');
  lens.material.uniforms.uEyeRelief.value = 0.08;
  lens.position.set(0, 0, 0.158); scope.add(lens);
  // turrets (orange elevation cap like reference)
  put(scope, ycyl(0.011, 0.02, 16), orange, 0, 0.026, -0.03);
  put(scope, xcyl(0.011, 0.02, 16), orange, 0.026, 0, -0.03);
  put(scope, ycyl(0.014, 0.006, 16), dark, 0, 0.018, -0.03);
  // rings
  // rings: clamp around the tube (r 0.017) and seat on the rail (rail top = scope-local y -0.035)
  for (const z of [-0.09, 0.03]) {
    put(scope, ztube(0.021, 0.017, 0.018, 20), dark, 0, 0, z);
    put(scope, rbox(0.028, 0.022, 0.018, 0.003), dark, 0, -0.025, z);         // ring base: y -0.036..-0.014
    put(scope, rbox(0.03, 0.006, 0.022, 0.002), dark, 0, -0.033, z);          // rail clamp jaw
    put(scope, xcyl(0.0035, 0.034, 8), steel, 0, -0.031, z);                   // cross bolt
    for (const sx of [1, -1]) put(scope, screwGeo(0.0028, 0.002), steel, sx * 0.0215, 0.0, z); // cap screws
  }
  // --- bolt (handle rotates up then slides back) ---
  const bolt = pivot(root, 'bolt', 0, 0.04, -0.005);
  put(bolt, zcyl(0.0105, 0.0105, 0.12, 16), steel, 0, 0, -0.04);
  const handle = new THREE.Group(); handle.name = 'boltHandle'; bolt.add(handle);
  put(handle, rbox(0.05, 0.007, 0.008, 0.002), steel, 0.03, 0, 0.012);
  put(handle, new THREE.SphereGeometry(0.0085, 14, 10), orange, 0.055, -0.004, 0.012);  // orange bolt knob (ref)
  // ejection port
  put(root, rbox(0.002, 0.016, 0.06, 0.001), M.blackened(0x0c0c0d), 0.0205, 0.044, -0.08);
  // magazine (detachable box, flush) + visible top round
  const mag = pivot(root, 'mag', 0, -0.012, -0.07);
  put(mag, profileGeo([[-0.04, 0.0], [0.045, 0.0], [0.045, -0.055], [-0.04, -0.058]], 0.04, 0.004), M.polymer(0x2d2c27));
  put(mag, rbox(0.044, 0.008, 0.088, 0.003), orange, 0, -0.058, -0.002);
  const rounds = [];
  const rg = cartridgeGeo(0.072, 0.0068, 0.33);
  for (let i = 0; i < 2; i++) rounds.push(keep(put(mag, rg, M.brass(), i ? 0.005 : -0.005, 0.004 - i * 0.004, 0.034)));

  const s = sockets(root, {
    muzzle: [0, 0.04, -0.77], ejection: [0.022, 0.045, -0.08], sight: [0, 0.11, 0.08],
    rightHand: [0, -0.05, 0.03], leftHand: [0, -0.01, -0.3], magWell: [0, -0.012, -0.07],
  });
  captureRest(root);
  finalize(root);
  return {
    root, parts: { trigger, bolt, mag, boltHandle: handle }, sockets: s, rounds,
    meta: { scopeEye: new THREE.Vector3(0, 0.11, -0.08 + 0.158), scopeCenterY: 0.11, sightType: 'scope', lens, zoom: 6, eyeRelief: 0.08 },
  };
}

// ====================================================================
// BIG RIG — heavy box shotgun (grey + orange, ring sight, fat muzzle can)
// ====================================================================
export function buildBigRig() {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'Big Rig';
  const grey = M.gunmetal(0x4a4b4c), dark = M.blackened(0x222324), orange = M.paint(0xd9622a), steel = M.steel(), rust = M.copper();

  // slab body (tall, angular)
  put(root, profileGeo([[-0.18, -0.02], [0.24, -0.02], [0.3, 0.02], [0.3, 0.11], [0.04, 0.13], [-0.16, 0.12], [-0.2, 0.08]], 0.07, 0.006), grey, 0, 0, 0);
  // orange side panels (raised)
  for (const sx of [1, -1]) {
    put(root, profileGeo([[-0.12, 0.0], [0.2, 0.0], [0.24, 0.04], [0.2, 0.09], [-0.1, 0.1]], 0.006, 0.002), orange, sx * 0.037, 0, 0);
    // square cut-outs with bolt (as in reference)
    for (const [z, y] of [[-0.05, 0.05], [-0.15, 0.05]]) {
      put(root, rbox(0.004, 0.026, 0.026, 0.003), dark, sx * 0.0405, y, z);
      put(root, screwGeo(0.006, 0.003), steel, sx * 0.042, y, z);
    }
    put(root, rbox(0.003, 0.004, 0.32, 0.001), dark, sx * 0.0405, 0.103, -0.04);
  }
  // raised sight mount & RING REAR SIGHT
  put(root, profileGeo([[0.0, 0.0], [0.06, 0.0], [0.05, 0.05], [0.01, 0.05]], 0.02, 0.003), dark, 0, 0.125, -0.06);
  const ring = new THREE.TorusGeometry(0.016, 0.0045, 10, 22);
  put(root, ring, dark, 0, 0.192, -0.09);
  put(root, ycyl(0.004, 0.02, 8), dark, 0, 0.174, -0.09);
  // front sight post at front of top bar
  put(root, rbox(0.004, 0.026, 0.006, 0.001), dark, 0, 0.152, -0.38);
  // top carry / charging bar (slides back on reload)
  const charge = pivot(root, 'charge', 0, 0.135, -0.1);
  put(charge, rbox(0.016, 0.016, 0.34, 0.004), dark, 0, 0, -0.1);
  put(charge, rbox(0.02, 0.04, 0.014, 0.004), dark, 0, -0.016, -0.27);
  put(charge, rbox(0.02, 0.03, 0.014, 0.004), dark, 0, -0.012, 0.06);
  // front: barrel + fat can + rust handle
  put(root, zcyl(0.017, 0.017, 0.12, 18), dark, 0, 0.07, -0.36);
  put(root, zcyl(0.03, 0.03, 0.16, 22), M.gunmetal(0x3a3b3c), 0, 0.07, -0.5);
  for (let i = 0; i < 5; i++) put(root, ztube(0.0315, 0.029, 0.006, 22), dark, 0, 0.07, -0.44 - i * 0.025);
  put(root, ztube(0.03, 0.012, 0.008, 22), steel, 0, 0.07, -0.582);
  // forward vertical handle (rust/orange) — sticks out to the LEFT in the reference
  put(root, xcyl(0.011, 0.11, 14), rust, -0.08, 0.03, -0.27);
  put(root, xcyl(0.015, 0.01, 14), dark, -0.135, 0.03, -0.27);
  put(root, rbox(0.04, 0.03, 0.03, 0.004), dark, -0.035, 0.03, -0.27);
  // wrapped tape on front
  put(root, ztube(0.022, 0.017, 0.04, 16), M.fabric(0xd2c4a2), 0, 0.07, -0.33);
  // grip / guard / trigger
  put(root, profileGeo([[-0.04, -0.02], [0.0, -0.02], [-0.012, -0.07], [-0.03, -0.13], [-0.075, -0.125], [-0.065, -0.07]], 0.038, 0.006), M.rubber(0x2c2c2c), 0, 0, 0);
  put(root, profileGeo([[0.0, -0.02], [0.08, -0.02], [0.08, -0.054], [0.0, -0.056], [0.006, -0.05], [0.074, -0.048], [0.074, -0.026], [0.0, -0.026]], 0.01, 0.0015), dark, 0, 0, 0);
  const trigger = pivot(root, 'trigger', 0, -0.023, -0.035);
  put(trigger, profileGeo([[0, 0], [0.007, 0], [0.004, -0.02], [-0.002, -0.024]], 0.007, 0.0008), steel);
  // rear stock (skeletal block, orange accent)
  put(root, profileGeo([[-0.18, 0.08], [-0.42, 0.08], [-0.43, -0.07], [-0.38, -0.075], [-0.2, -0.02]], 0.06, 0.008), dark, 0, 0, 0);
  put(root, profileGeo([[-0.24, 0.06], [-0.36, 0.06], [-0.36, -0.03], [-0.26, 0.0]], 0.062, 0.004), orange, 0, 0, 0);
  put(root, rbox(0.064, 0.16, 0.02, 0.008), M.rubber(), 0, 0.0, 0.435);
  // box magazine (dark, side cut) + visible top shell
  const mag = pivot(root, 'mag', 0, -0.02, -0.17);
  put(mag, profileGeo([[-0.05, 0.0], [0.05, 0.0], [0.055, -0.12], [-0.045, -0.125]], 0.058, 0.005), M.blackened(0x2a2b2c));
  put(mag, rbox(0.062, 0.012, 0.106, 0.004), orange, 0, -0.128, -0.005);
  for (const sx of [1, -1]) put(mag, rbox(0.002, 0.08, 0.03, 0.002), M.blackened(0x111111), sx * 0.0292, -0.06, -0.01);
  const rounds = [];
  const sh = shellGeos(0.065, 0.011);
  const top = new THREE.Group(); top.position.set(0, 0.004, 0.034); mag.add(top);
  put(top, sh.hull, M.shellRed()); put(top, sh.brass, M.brass());
  top.userData.keep = true; rounds.push(top);

  const s = sockets(root, {
    muzzle: [0, 0.07, -0.59], ejection: [0.04, 0.08, -0.02], sight: [0, 0.192, -0.09],
    rightHand: [0, -0.05, 0.035], leftHand: [-0.135, 0.03, -0.27], magWell: [0, -0.02, -0.17],
  });
  captureRest(root);
  finalize(root);
  return {
    root, parts: { trigger, charge, mag }, sockets: s, rounds,
    meta: { rearSight: new THREE.Vector3(0, 0.192, -0.09), frontSight: new THREE.Vector3(0, 0.165, -0.38) },
  };
}

// ====================================================================
// KRAKEN — top-loading pump shotgun (bronze/charcoal, orange glow optic)
// ====================================================================
export function buildKraken() {
  const { M } = getShared();
  const root = new THREE.Group(); root.name = 'Kraken';
  const char = M.gunmetal(0x2e2f31), bronze = M.bronze(), dark = M.blackened(), steel = M.steel(), glowO = M.emissive(0xff8a1c, 4), glowP = M.emissive(0xa03cff, 3);

  // receiver (bronze lower, charcoal upper)
  put(root, profileGeo([[-0.1, -0.02], [0.17, -0.02], [0.19, 0.0], [0.19, 0.06], [-0.08, 0.065], [-0.12, 0.04]], 0.06, 0.006), bronze, 0, 0, 0);
  put(root, profileGeo([[-0.09, 0.06], [0.19, 0.055], [0.2, 0.09], [0.02, 0.105], [-0.07, 0.1]], 0.056, 0.006), char, 0, 0, 0);
  // top loading port (dark opening) + gate
  put(root, rbox(0.03, 0.004, 0.07, 0.002), M.blackened(0x080808), 0, 0.104, 0.01);
  const gate = pivot(root, 'gate', 0, 0.107, -0.025);
  put(gate, rbox(0.032, 0.004, 0.07, 0.002), char, 0, 0, 0.035);
  // orange glow indicators along the side (ref)
  for (const sx of [1, -1]) {
    put(root, ycyl(0.004, 0.003, 10), glowO, sx * 0.031, 0.04, -0.05, 0, 0, Math.PI / 2);
    put(root, rbox(0.002, 0.004, 0.12, 0.001), M.paint(0xb0581e), sx * 0.0305, 0.072, -0.02);
    for (const z of [0.1, -0.12]) put(root, screwGeo(0.0035, 0.002), steel, sx * 0.0308, 0.02, z);
  }
  // heat-shielded barrel (charcoal shroud with slots) + magazine tube
  put(root, zcyl(0.014, 0.014, 0.44, 18), steel, 0, 0.065, -0.4);
  put(root, profileGeo([[0.19, 0.05], [0.62, 0.055], [0.63, 0.088], [0.19, 0.092]], 0.04, 0.004), char, 0, 0, 0);
  for (let i = 0; i < 6; i++) put(root, rbox(0.042, 0.004, 0.022, 0.001), M.blackened(0x0b0b0b), 0, 0.09, -0.24 - i * 0.06);
  put(root, zcyl(0.013, 0.013, 0.36, 16), dark, 0, 0.025, -0.37);
  put(root, zcyl(0.017, 0.017, 0.03, 16), bronze, 0, 0.065, -0.635);
  put(root, ztube(0.017, 0.011, 0.01, 16), steel, 0, 0.065, -0.655);
  // GROOVED PUMP (slides along mag tube)
  const pump = pivot(root, 'pump', 0, 0.03, -0.34);
  put(pump, profileGeo([[-0.075, -0.02], [0.075, -0.02], [0.08, 0.008], [0.075, 0.028], [-0.075, 0.028], [-0.08, 0.008]], 0.056, 0.008), M.polymer(0x3a2c22));
  for (let i = 0; i < 7; i++) put(pump, rbox(0.058, 0.004, 0.006, 0.001), dark, 0, -0.022, -0.06 + i * 0.02);
  for (const sx of [1, -1]) for (let i = 0; i < 6; i++) put(pump, rbox(0.003, 0.034, 0.006, 0.001), dark, sx * 0.0285, 0.004, -0.05 + i * 0.02);
  // action bars (connect pump to bolt)
  for (const sx of [1, -1]) put(pump, rbox(0.003, 0.006, 0.22, 0.001), steel, sx * 0.022, 0.005, 0.15);
  // ---- REFLEX OPTIC (tube type) on a short rail ----
  // receiver top at the optic station ≈ y 0.100 → rail 0.100..0.109 → base 0.109..0.117
  put(root, railGeo(0.07, 0.024, 0.009), dark, 0, 0.1, -0.07);
  const optic = new THREE.Group(); optic.name = 'OpticAssembly'; optic.position.set(0, 0, -0.07); root.add(optic);
  put(optic, rbox(0.034, 0.008, 0.056, 0.002), char, 0, 0.113, 0);                       // clamp base (sits on rail)
  for (const sx of [1, -1]) put(optic, screwGeo(0.0035, 0.003), steel, sx * 0.0175, 0.113, 0.012);
  const OY = 0.138;                                                                     // optical axis height
  put(optic, ztube(0.0235, 0.0198, 0.05, 28), char, 0, OY, 0);                          // housing tube
  put(optic, ztube(0.0255, 0.0198, 0.006, 28), M.paint(0xd0601c), 0, OY, -0.024);       // orange front hood ring
  put(optic, rbox(0.016, 0.008, 0.04, 0.002), char, 0, 0.12, 0);                        // tube-to-base web
  put(optic, rbox(0.012, 0.008, 0.014, 0.002), char, 0, OY + 0.025, 0.01);              // LED emitter housing (top rear)
  put(optic, ycyl(0.0022, 0.002, 8), glowO, 0, OY + 0.0292, 0.01);                       // emitter glow
  put(optic, xcyl(0.006, 0.008, 14), steel, 0.027, OY, 0.008);                           // brightness knob
  // lens: real transparent glass; the red dot lives in the lens shader
  const lens = makeReflexLens(new THREE.CircleGeometry(0.0198, 32), 'dot', 0xff3018);
  lens.position.set(0, OY, -0.02); optic.add(lens);
  // grip, guard, trigger
  put(root, profileGeo([[-0.04, -0.02], [0.0, -0.02], [-0.012, -0.07], [-0.03, -0.125], [-0.072, -0.12], [-0.064, -0.065]], 0.036, 0.006), M.rubber(0x2a2420), 0, 0, 0);
  put(root, profileGeo([[0.0, -0.02], [0.075, -0.02], [0.075, -0.052], [0.0, -0.054], [0.006, -0.048], [0.069, -0.046], [0.069, -0.026], [0.0, -0.026]], 0.009, 0.0012), dark, 0, 0, 0);
  const trigger = pivot(root, 'trigger', 0, -0.023, -0.033);
  put(trigger, profileGeo([[0, 0], [0.007, 0], [0.004, -0.02], [-0.002, -0.024]], 0.007, 0.0008), steel);
  // stock with purple light (ref) + bronze plate
  put(root, profileGeo([[-0.12, 0.08], [-0.4, 0.06], [-0.41, -0.065], [-0.36, -0.07], [-0.13, -0.015]], 0.054, 0.007), char, 0, 0, 0);
  put(root, profileGeo([[-0.16, 0.05], [-0.34, 0.04], [-0.34, 0.0], [-0.18, 0.02]], 0.057, 0.003), bronze, 0, 0, 0);
  for (const sx of [1, -1]) put(root, rbox(0.002, 0.008, 0.05, 0.002), glowP, sx * 0.029, 0.02, 0.3);
  put(root, rbox(0.058, 0.14, 0.02, 0.008), M.rubber(), 0, -0.002, 0.41);
  // bolt (visible through port, cycles with pump)
  const bolt = pivot(root, 'bolt', 0, 0.08, 0.0);
  put(bolt, rbox(0.022, 0.018, 0.06, 0.002), steel, 0, 0, 0);
  // shells: internal tube is hidden; visible shell = the one in the loading port
  const rounds = [];
  const sh = shellGeos(0.066, 0.0108);
  const portShell = new THREE.Group(); portShell.position.set(0, 0.092, 0.035); root.add(portShell);
  put(portShell, sh.hull, M.shellRed()); put(portShell, sh.brass, M.brass());
  portShell.userData.keep = true; rounds.push(portShell);
  // side shell carrier (4 visible spare shells on the left side — reserve display)
  const carrier = new THREE.Group(); carrier.position.set(-0.034, 0.02, 0.06); root.add(carrier);
  carrier.userData.keep = true;
  put(carrier, rbox(0.006, 0.03, 0.1, 0.002), dark, 0.002, 0, 0);
  const sideShells = [];
  for (let i = 0; i < 4; i++) {
    const g = new THREE.Group(); g.position.set(-0.006, -0.022, -0.036 + i * 0.022); g.rotation.x = -Math.PI / 2; carrier.add(g);
    put(g, sh.hull, M.shellRed()); put(g, sh.brass, M.brass());
    g.scale.setScalar(0.62); sideShells.push(g);
  }

  const s = sockets(root, {
    muzzle: [0, 0.065, -0.66], ejection: [0.032, 0.08, -0.0], sight: [0, 0.133, -0.07],
    rightHand: [0, -0.05, 0.03], leftHand: [0, 0.0, -0.34], magWell: [0, 0.1, 0.0],
  });
  s.sight.position.set(0, 0.138, -0.09);
  captureRest(root);
  finalize(root);
  return {
    root, parts: { trigger, pump, gate, bolt }, sockets: s, rounds, sideShells,
    meta: { reticle: new THREE.Vector3(0, 0.138, -0.09), sightType: 'reflex', lens },
  };
}

export const BUILDERS = { dynasty: buildDynasty, vanguard: buildVanguard, ranger: buildRanger, bigrig: buildBigRig, kraken: buildKraken };

// Loose magazine prop for drop physics: clones the weapon's mag pivot meshes.
export function cloneMagProp(model) {
  const src = model.parts.mag;
  if (!src) return null;
  const g = new THREE.Group();
  src.traverse((o) => {
    if (!o.isMesh || o === src) return;
    const m = new THREE.Mesh(o.geometry, o.material);
    o.updateWorldMatrix(true, false);
    const rel = new THREE.Matrix4().copy(src.matrixWorld).invert().multiply(o.matrixWorld);
    rel.decompose(m.position, m.quaternion, m.scale);
    g.add(m);
  });
  return g;
}

// silence unused import warnings for helpers reserved for future models
void merge; void cartridgeCaseGeo; void projectileGeo;
