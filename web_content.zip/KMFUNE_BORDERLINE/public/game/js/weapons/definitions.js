// =====================================================================
// Weapon definitions (data-driven)
// ---------------------------------------------------------------------
// Each entry fully describes one weapon: model builder, ammo, fire mode,
// ballistics, recoil, viewmodel transforms, ADS alignment, animation
// timings and audio events. Adding a weapon = add a builder in models.js
// + an entry here. Reload types:
//   'mag'      → magazine swap (empty reload adds a charge/bolt action)
//   'shell'    → shells loaded one at a time (interruptible by firing)
// Reload event timings are normalised 0..1 across the clip duration.
// =====================================================================

export const WEAPONS = {
  dynasty: {
    id: 'dynasty', name: 'DYNASTY', category: 'Assault Rifle', builder: 'dynasty',
    blurb: 'AK-pattern rifle with a skeletal steel stock and wood cheek insert. Reliable full-auto workhorse.',
    magSize: 30, reserve: 210, fireModes: ['auto', 'semi'], rpm: 640,
    damage: 34, pellets: 1, spread: 0.0022, adsSpread: 0.0004, moveSpread: 0.012, range: 400, falloff: [60, 180, 0.6],
    recoil: { pitch: 0.0105, yaw: 0.0032, yawBias: 0.15, recover: 9, kickBack: 0.034, kickUp: 0.012, roll: 0.035, adsMul: 0.55 },
    cycle: 'bolt',     // reciprocating part per shot
    caseEject: 'rifle',
    hip: { pos: [0.165, -0.175, -0.36], rot: [0, 0, 0] },
    ads: { fov: 62, time: 0.2, eyeRelief: 0.27 },
    sprint: { pos: [0.06, -0.2, -0.32], rot: [-0.32, 0.72, 0.18] },
    reload: {
      type: 'mag',
      tactical: { time: 2.15, ammoAt: 0.58 },
      empty: { time: 2.85, ammoAt: 0.5 },
      sounds: {
        tactical: [[0.14, 'mag_out'], [0.5, 'mag_in'], [0.58, 'mag_seat'], [0.82, 'cloth']],
        empty: [[0.1, 'mag_out'], [0.38, 'mag_in'], [0.45, 'mag_seat'], [0.66, 'bolt_back'], [0.74, 'bolt_fwd'], [0.9, 'cloth']],
      },
    },
    equip: 0.45, unequip: 0.3, sound: 'dynasty_shot', shotVolume: 0.8, shotPitch: [0.97, 1.04],
    hands: { rightGrip: 'rightHand', leftGrip: 'leftHand' },
    stats: { damage: 0.45, rof: 0.75, range: 0.7, handling: 0.6 },
  },
  vanguard: {
    id: 'vanguard', name: 'VANGUARD', category: 'Submachine Gun', builder: 'vanguard',
    blurb: 'Compact 9mm SMG in bone/olive camo. Curved stick magazine, aperture rear + hooded orange front sight, top-left charging handle.',
    magSize: 32, reserve: 192, fireModes: ['auto', 'semi'], rpm: 860,
    damage: 21, pellets: 1, spread: 0.0042, adsSpread: 0.0011, moveSpread: 0.008, range: 160, falloff: [18, 55, 0.55],
    recoil: { pitch: 0.0062, yaw: 0.0042, yawBias: -0.1, recover: 11, kickBack: 0.022, kickUp: 0.008, roll: 0.03, adsMul: 0.6 },
    cycle: 'charge', caseEject: 'rifle',
    hip: { pos: [0.16, -0.18, -0.34], rot: [0, 0, 0] },
    ads: { fov: 66, time: 0.17 },
    sprint: { pos: [0.06, -0.21, -0.3], rot: [-0.3, 0.7, 0.2] },
    reload: {
      type: 'mag',
      tactical: { time: 1.85, ammoAt: 0.58 },
      empty: { time: 2.45, ammoAt: 0.5 },
      sounds: {
        tactical: [[0.14, 'mag_out'], [0.5, 'mag_in'], [0.58, 'mag_seat'], [0.84, 'cloth']],
        empty: [[0.1, 'mag_out'], [0.4, 'mag_in'], [0.5, 'mag_seat'], [0.66, 'bolt_back'], [0.75, 'bolt_fwd'], [0.9, 'cloth']],
      },
    },
    equip: 0.4, unequip: 0.28, sound: 'smg_shot', shotVolume: 0.72, shotPitch: [0.98, 1.04],
    hands: { rightGrip: 'rightHand', leftGrip: 'leftHand' },
    stats: { damage: 0.32, rof: 0.95, range: 0.35, handling: 0.85 },
  },
  ranger: {
    id: 'ranger', name: 'RANGER', category: 'Sniper Rifle', builder: 'ranger',
    blurb: 'Bolt-action precision rifle. Heavy fluted barrel, octagonal-bell scope with orange turrets, folding bipod.',
    magSize: 5, reserve: 30, fireModes: ['bolt'], rpm: 48,
    damage: 140, pellets: 1, spread: 0.03, adsSpread: 0.0, moveSpread: 0.03, range: 900, falloff: [200, 600, 0.8],
    headMul: 2.0,
    recoil: { pitch: 0.06, yaw: 0.01, yawBias: 0.1, recover: 5, kickBack: 0.09, kickUp: 0.03, roll: 0.05, adsMul: 0.6 },
    cycle: 'boltAction', boltTime: 0.95, caseEject: 'rifleBig',
    hip: { pos: [0.17, -0.185, -0.4], rot: [0, 0, 0] },
    ads: { fov: 58, time: 0.3, scope: true, vmFov: 38 },  // magnification comes from the scope (meta.zoom = 6x)
    sprint: { pos: [0.06, -0.22, -0.34], rot: [-0.3, 0.7, 0.18] },
    reload: {
      type: 'mag',
      tactical: { time: 2.4, ammoAt: 0.62 },
      empty: { time: 3.3, ammoAt: 0.55 },
      sounds: {
        tactical: [[0.16, 'mag_out'], [0.55, 'mag_in'], [0.62, 'mag_seat'], [0.86, 'cloth']],
        empty: [[0.06, 'bolt_up'], [0.12, 'bolt_back'], [0.22, 'mag_out'], [0.5, 'mag_in'], [0.56, 'mag_seat'], [0.72, 'bolt_fwd'], [0.78, 'bolt_down'], [0.92, 'cloth']],
      },
    },
    equip: 0.6, unequip: 0.35, sound: 'ranger_shot', shotVolume: 1.0, shotPitch: [0.98, 1.02],
    hands: { rightGrip: 'rightHand', leftGrip: 'leftHand' },
    stats: { damage: 1.0, rof: 0.1, range: 1.0, handling: 0.3 },
  },
  bigrig: {
    id: 'bigrig', name: 'BIG RIG', category: 'Heavy Shotgun', builder: 'bigrig',
    blurb: 'Brutal slab-sided box shotgun with orange armour panels, ring rear sight and a fat muzzle can.',
    magSize: 8, reserve: 40, fireModes: ['semi'], rpm: 160,
    damage: 15, pellets: 12, spread: 0.055, adsSpread: 0.04, moveSpread: 0.012, range: 55, falloff: [8, 30, 0.2],
    recoil: { pitch: 0.05, yaw: 0.012, yawBias: -0.2, recover: 6.5, kickBack: 0.09, kickUp: 0.035, roll: 0.07, adsMul: 0.75 },
    cycle: 'charge', caseEject: 'shell',
    hip: { pos: [0.17, -0.2, -0.4], rot: [0, 0, 0] },
    ads: { fov: 66, time: 0.25 },
    sprint: { pos: [0.06, -0.23, -0.34], rot: [-0.3, 0.68, 0.22] },
    reload: {
      type: 'mag',
      tactical: { time: 2.5, ammoAt: 0.6 },
      empty: { time: 3.2, ammoAt: 0.48 },
      sounds: {
        tactical: [[0.15, 'mag_out'], [0.52, 'mag_in'], [0.6, 'mag_seat'], [0.85, 'cloth']],
        empty: [[0.1, 'mag_out'], [0.38, 'mag_in'], [0.46, 'mag_seat'], [0.66, 'pump_back'], [0.76, 'pump_fwd'], [0.9, 'cloth']],
      },
    },
    equip: 0.6, unequip: 0.35, sound: 'bigrig_shot', shotVolume: 1.0, shotPitch: [0.92, 0.98],
    hands: { rightGrip: 'rightHand', leftGrip: 'leftHand' },
    stats: { damage: 0.95, rof: 0.3, range: 0.22, handling: 0.4 },
  },
  kraken: {
    id: 'kraken', name: 'KRAKEN', category: 'Pump Shotgun', builder: 'kraken',
    blurb: 'Top-loading pump gun. Bronze receiver, heat-shielded barrel, glowing orange reflex optic. Load shells one by one.',
    magSize: 7, reserve: 35, fireModes: ['pump'], rpm: 75,
    damage: 18, pellets: 9, spread: 0.04, adsSpread: 0.028, moveSpread: 0.01, range: 60, falloff: [10, 38, 0.25],
    recoil: { pitch: 0.055, yaw: 0.01, yawBias: 0.1, recover: 6, kickBack: 0.085, kickUp: 0.035, roll: 0.06, adsMul: 0.7 },
    cycle: 'pump', pumpTime: 0.62, caseEject: 'shell',
    hip: { pos: [0.17, -0.19, -0.38], rot: [0, 0, 0] },
    ads: { fov: 64, time: 0.22 },
    sprint: { pos: [0.06, -0.22, -0.32], rot: [-0.3, 0.7, 0.2] },
    reload: {
      type: 'shell',
      start: 0.45, perShell: 0.52, shellAt: 0.55, end: 0.5, emptyRack: 0.7,
      sounds: { shell: [[0.5, 'shell_in']], rack: [[0.2, 'pump_back'], [0.6, 'pump_fwd']] },
    },
    equip: 0.5, unequip: 0.32, sound: 'kraken_shot', shotVolume: 0.95, shotPitch: [0.96, 1.02],
    hands: { rightGrip: 'rightHand', leftGrip: 'leftHand' },
    stats: { damage: 0.9, rof: 0.2, range: 0.28, handling: 0.5 },
  },
};

export const WEAPON_ORDER = ['dynasty', 'vanguard', 'ranger', 'bigrig', 'kraken'];

export function fireModeLabel(m) {
  return { auto: 'FULL AUTO', semi: 'SEMI', bolt: 'BOLT ACTION', pump: 'PUMP ACTION', burst: 'BURST' }[m] || m.toUpperCase();
}
