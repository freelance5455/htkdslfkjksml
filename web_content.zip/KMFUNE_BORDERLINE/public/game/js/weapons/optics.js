// =====================================================================
// Optics: reflex / holographic lens materials and magnified-scope
// picture-in-picture rendering.
// ---------------------------------------------------------------------
//  Reflex & holo sights
//    The lens is a real, mostly transparent glass disc/window mounted in
//    the optic housing. The reticle is drawn *in the lens shader* at the
//    point where the eye's line of sight parallel to the optic axis meets
//    the lens → the dot is parallax-free (appears at infinity) and is only
//    visible *through* the lens. Nothing is drawn full-screen.
//  Magnified scopes
//    The ocular lens samples a render target produced by a second world
//    camera whose FOV is narrowed by the scope magnification and which is
//    aimed along the scope's optical axis (so sway & recoil move the
//    image correctly). Reticle, eye-box "scope shadow" and edge vignette
//    are drawn in the lens shader. The rest of the screen keeps showing
//    the un-magnified world and the weapon → no full-screen black mask.
// =====================================================================
import * as THREE from 'three';

const _eye = new THREE.Vector3();
const _inv = new THREE.Matrix4();
/** Transparent lenses live on this layer; the ink normal/depth prepass disables it. */
export const LENS_LAYER = 3;

const COMMON_VERT = /* glsl */`
  varying vec2 vLocal;
  #include <common>
  void main() {
    vLocal = position.xy;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

/** Keeps uEye (camera position in lens-local space) current; allocation-free. */
function trackEye(mesh) {
  mesh.onBeforeRender = (r, s, cam) => {
    _inv.copy(mesh.matrixWorld).invert();
    _eye.setFromMatrixPosition(cam.matrixWorld).applyMatrix4(_inv);
    mesh.material.uniforms.uEye.value.copy(_eye);
  };
}

/**
 * Reflex (red dot) or holographic lens.
 * @param {'dot'|'holo'} style
 * @param {number} radius lens half-size (local units, lens faces +Z)
 */
export function reflexLensMaterial(style = 'dot', color = 0xff2a1a, tint = 0x8fb6c8) {
  return new THREE.ShaderMaterial({
    name: 'reflexLens_' + style,
    transparent: true, depthWrite: false, side: THREE.FrontSide,
    uniforms: {
      uEye: { value: new THREE.Vector3(0, 0, 1) },
      uColor: { value: new THREE.Color(color).multiplyScalar(7.0) },
      uTint: { value: new THREE.Color(tint) },
      uHolo: { value: style === 'holo' ? 1 : 0 },
      uBright: { value: 1 },
    },
    vertexShader: COMMON_VERT,
    fragmentShader: /* glsl */`
      uniform vec3 uEye; uniform vec3 uColor; uniform vec3 uTint; uniform float uHolo; uniform float uBright;
      varying vec2 vLocal;
      void main() {
        float d = max(0.02, uEye.z);
        // reticle centre = eye projected along the optic axis (parallax-free)
        vec2 p = vLocal - uEye.xy;
        float ang = length(p) / d;                     // angular radius (rad) seen from the eye
        float px = fwidth(ang) * 1.2;
        float dot_ = 1.0 - smoothstep(0.0034 - px, 0.0034 + px, max(ang - px * 0.6, 0.0));  // ~2 px minimum so it never vanishes
        float ring = 0.0;
        if (uHolo > 0.5) {
          ring = 1.0 - smoothstep(0.0, px * 1.4, abs(ang - 0.0175) - 0.0008);
          // four ticks on the ring
          vec2 a = abs(p / d);
          float tick = step(min(a.x, a.y), 0.0007) * step(0.0175, max(a.x, a.y)) * step(max(a.x, a.y), 0.0215);
          ring = max(ring, tick);
        }
        float ret = max(dot_, ring * 0.9) * uBright;
        // glass: faint tint + coating sheen toward the rim
        float sheen = 0.06 + 0.08 * smoothstep(0.2, 1.0, length(vLocal) * 40.0);
        vec3 col = uTint * sheen + uColor * ret;
        float alpha = clamp(sheen * 1.4 + ret, 0.0, 1.0);
        gl_FragColor = vec4(col, alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  });
}

/** Ocular lens of a magnified scope (samples the PiP render target). */
export function scopeLensMaterial(radius, reticle = 'mildot') {
  return new THREE.ShaderMaterial({
    name: 'scopeLens',
    transparent: false, depthWrite: true,
    uniforms: {
      tScope: { value: null },
      uEye: { value: new THREE.Vector3(0, 0, 1) },
      uR: { value: radius },
      uAds: { value: 0 },
      uActive: { value: 0 },
      uEyeRelief: { value: 0.075 },
      uStyle: { value: reticle === 'acog' ? 1 : 0 },
    },
    vertexShader: COMMON_VERT,
    fragmentShader: /* glsl */`
      uniform sampler2D tScope; uniform vec3 uEye; uniform float uR; uniform float uAds; uniform float uActive;
      uniform float uEyeRelief; uniform float uStyle;
      varying vec2 vLocal;
      void main() {
        vec2 q = vLocal / uR;                     // -1..1 across the lens
        float r = length(q);
        // eye-box: lateral eye offset from the optical axis + distance error
        vec2 off = uEye.xy / uR;
        float dz = abs(uEye.z - uEyeRelief) / uEyeRelief;
        float box = 1.0 - smoothstep(0.55, 1.05, length(q - off * 1.6) + dz * 0.6);
        vec3 img = vec3(0.0);
        if (uActive > 0.5) img = texture2D(tScope, q * 0.5 + 0.5).rgb;
        // reticle (second focal plane, black)
        float w = fwidth(r) * 1.5;
        float line = 0.0;
        vec2 a = abs(q);
        if (uStyle < 0.5) {
          // duplex crosshair with mil dots
          float thin = step(a.x, 0.004) + step(a.y, 0.004);
          float thick = (step(a.x, 0.016) * step(0.45, a.y)) + (step(a.y, 0.016) * step(0.45, a.x));
          line = clamp(thin + thick, 0.0, 1.0);
          for (int i = 1; i <= 4; i++) {
            float k = float(i) * 0.09;
            line = max(line, 1.0 - smoothstep(0.009, 0.009 + w, length(vec2(a.x, abs(a.y - k)))) * step(a.x, 0.02));
            line = max(line, 1.0 - smoothstep(0.009, 0.009 + w, length(vec2(abs(a.x - k), a.y))) * step(a.y, 0.02));
          }
        } else {
          // ACOG-style chevron + stadia
          float chev = step(abs(a.x - (-q.y) * 0.9), 0.012) * step(q.y, 0.0) * step(-0.12, q.y);
          float post = step(a.x, 0.006) * step(q.y, -0.12);
          float hor = step(a.y, 0.004) * step(0.35, a.x);
          line = clamp(chev + post + hor, 0.0, 1.0);
        }
        vec3 col = img * box;
        col = mix(col, vec3(0.0), line * 0.92);
        // centre illumination dot (red) for low light
        float cd = 1.0 - smoothstep(0.012, 0.012 + w, r);
        col = mix(col, vec3(4.0, 0.25, 0.15), cd * (uStyle > 0.5 ? 1.0 : 0.85));
        // edge vignette inside the tube + glass tint when not looking through
        col *= 1.0 - smoothstep(0.78, 1.0, r) * 0.85;
        vec3 glass = vec3(0.03, 0.05, 0.06) + vec3(0.08, 0.12, 0.14) * pow(1.0 - r, 2.0);
        col = mix(glass, col, smoothstep(0.35, 0.9, uAds) * uActive);
        gl_FragColor = vec4(col, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  });
}

export function makeReflexLens(geo, style, color) {
  const m = new THREE.Mesh(geo, reflexLensMaterial(style, color));
  m.renderOrder = 20; m.frustumCulled = false;
  m.userData.keep = true; m.userData.noInk = true; m.userData.lens = style;
  m.layers.set(LENS_LAYER);
  trackEye(m);
  return m;
}
export function makeScopeLens(radius, reticle) {
  const geo = new THREE.CircleGeometry(radius, 40);
  const m = new THREE.Mesh(geo, scopeLensMaterial(radius, reticle));
  m.frustumCulled = false;
  m.userData.keep = true; m.userData.lens = 'scope';
  trackEye(m);
  return m;
}

// ---------------------------------------------------------------------
// Scope picture-in-picture renderer
// ---------------------------------------------------------------------
export class ScopeView {
  constructor() {
    this.size = 0;
    this.rt = null;
    this.cam = new THREE.PerspectiveCamera(10, 1, 0.05, 1200);
    this.cam.layers.set(0);
    this.active = false;
    this._q = new THREE.Quaternion();
    this._dir = new THREE.Vector3();
    this._fwd = new THREE.Vector3(0, 0, -1);
  }

  ensure(size) {
    if (this.size === size && this.rt) return;
    this.rt?.dispose();
    this.size = size;
    this.rt = new THREE.WebGLRenderTarget(size, size, { type: THREE.HalfFloatType, samples: 0 });
    this.rt.texture.generateMipmaps = false;
  }

  /**
   * @param lens  scope lens mesh (in the viewmodel scene)
   * @param zoom  magnification
   * @param worldCam  main camera; vmCam viewmodel camera
   */
  render(renderer, scene, worldCam, vmCam, lens, zoom, size) {
    this.ensure(size);
    // optical axis in viewmodel-camera space (lens faces +Z toward the eye)
    lens.updateWorldMatrix(true, false);
    this._dir.set(0, 0, -1).transformDirection(lens.matrixWorld);
    this._q.setFromUnitVectors(this._fwd, this._dir);
    const c = this.cam;
    c.position.copy(worldCam.position);
    c.quaternion.copy(worldCam.quaternion).multiply(this._q);
    // lens angular radius as seen from the ADS eye
    const R = lens.material.uniforms.uR.value, e = lens.material.uniforms.uEyeRelief.value;
    const tanTheta = R / e;
    const tanBeta = (tanTheta * Math.tan((worldCam.fov * Math.PI) / 360)) / (Math.tan((vmCam.fov * Math.PI) / 360) * zoom);
    c.fov = (Math.atan(tanBeta) * 360) / Math.PI;
    c.far = worldCam.far; c.near = 0.1;
    c.updateProjectionMatrix();
    c.updateMatrixWorld(true);
    const prevTarget = renderer.getRenderTarget();
    const prevAuto = renderer.shadowMap.autoUpdate;
    renderer.shadowMap.autoUpdate = false;   // reuse this frame's shadow maps
    renderer.setRenderTarget(this.rt);
    renderer.clear();
    renderer.render(scene, c);
    renderer.setRenderTarget(prevTarget);
    renderer.shadowMap.autoUpdate = prevAuto;
    lens.material.uniforms.tScope.value = this.rt.texture;
  }

  dispose() { this.rt?.dispose(); this.rt = null; this.size = 0; }
}
