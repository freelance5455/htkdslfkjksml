// =====================================================================
// Weapon controller — state machine, input, transform composition, hands
// ---------------------------------------------------------------------
// States:  equipping → ready ⇄ (auto/manual cycle) → reloading → ready
//          ready → unequipping → equipping(next) ;  ready → inspecting
//
// Transform layers (viewmodel space; camera at origin looking -Z):
//   rig        anchor  = lerp(hip, ADS(from sight geometry), ads) ⊕ sprint
//   animNode   equip / reload / inspect / manual-cycle pose
//   swayNode   breathing + look-lag + movement bob + strafe + jump/land
//   recoilNode recoil springs
// Each layer is independent and composed by the scene graph exactly once.
// =====================================================================
import * as THREE from 'three';
import { WeaponRegistry } from './registry.js';
import { LoadoutManager, disposeModel } from './gunsmith.js';
import { WeaponInstance, V, E } from './instance.js';
import { FiringMixin } from './firing.js';
import * as A from './animations.js';
import { Spring, clamp, damp, lerp, smooth } from '../core/math.js';
import { settings } from '../core/settings.js';
import { audio } from '../audio/audio.js';
import { bus } from '../core/events.js';

export class WeaponController {
  constructor({ vmScene, vmCamera, worldCamera, arms, physics, effects, controller, map }) {
    Object.assign(this, { vmScene, vmCamera, camera: worldCamera, arms, physics, fx: effects, player: controller, map });
    this.slots = [null, null];
    this.active = 0;
    this.current = null;
    this.state = 'none'; this.stateT = 0; this.pendingSlot = -1;

    this.rig = new THREE.Group(); this.animNode = new THREE.Group(); this.swayNode = new THREE.Group(); this.recoilNode = new THREE.Group();
    this.rig.add(this.animNode); this.animNode.add(this.swayNode); this.swayNode.add(this.recoilNode);
    vmScene.add(this.rig);

    this.scopeRendering = false;
    this.adsBlend = 0; this.adsHeld = false; this.adsToggled = false; this.sprintBlend = 0;
    this.fireCooldown = 0; this.triggerHeld = false; this.shotsFired = 0; this.lastShotTime = -10; this.time = 0;
    this.rPosZ = new Spring(220, 22); this.rPosY = new Spring(220, 22); this.rRotX = new Spring(180, 16); this.rRotZ = new Spring(160, 14); this.rRotY = new Spring(180, 18);
    this.camKick = { pitch: 0, yaw: 0, pitchVel: 0 };
    this.lookSway = V(); this.moveSwayX = 0; this.landOffset = new Spring(160, 13); this.jumpOffset = 0; this.lastLook = null;
    this.crosshairSpread = 0;

    this.reload = null;          // { kind, t, dur, events, ammoGiven, magDropped } or shell state
    this.autoCycleT = -1;        // semi/auto bolt reciprocation
    this.manual = null;          // { kind, t, delay, sounds }
    this.inspectT = -1;
    this.leftOverride = null;

    bus.on('player:land', ({ intensity }) => this.landOffset.impulse(-intensity * 2.2));
    bus.on('player:jump', () => this.landOffset.impulse(0.9));
  }

  // ---------------- loadout / switching ----------------
  /** Builds both weapons from their saved gunsmith configurations. Old models are disposed (no GPU leaks). */
  setLoadout(primaryId, secondaryId) {
    this.abortActions();
    for (const s of this.slots) if (s) disposeModel(s.model);
    if (this.handShell) { this.handShell.removeFromParent(); this.handShell = null; }
    this.current = null;
    const mk = (id) => { const d = WeaponRegistry.get(id) || WeaponRegistry.get('dynasty'); return new WeaponInstance(d, LoadoutManager.config(d.id)); };
    this.slots = [mk(primaryId), mk(secondaryId)];
    this.slots.forEach((s) => s.updateRounds());
    this.equip(0, true);
  }

  equip(slot, instant = false) {
    if (this.current) this.current.model.root.removeFromParent();
    this.abortActions();
    this.active = slot;
    this.current = this.slots[slot];
    this.recoilNode.add(this.current.model.root);
    this.current.resetParts();
    this.current.updateRounds();
    this.state = 'equipping'; this.stateT = instant ? this.current.def.equip : 0;
    this.adsBlend = 0;
    if (!instant) audio.cue('equip');
    bus.emit('weapon:changed', this.hudState());
  }

  switchTo(slot) {
    if (!this.slots[slot]) return;
    if (this.state === 'unequipping') { this.pendingSlot = slot === this.active ? -1 : slot; if (slot === this.active) { this.state = 'equipping'; this.stateT = this.current.def.equip * 0.4; } return; }
    if (slot === this.active) return;
    this.abortActions();
    this.pendingSlot = slot;
    this.state = 'unequipping'; this.stateT = 0;
    audio.cue('unequip');
  }

  /** Cancel reload/cycle/inspect safely. Ammo only moves at defined points, so nothing is lost or duplicated. */
  abortActions() {
    if (this.reload && this.current) {
      // a pump/bolt gun interrupted mid-cycle must still be cycled later
      this.current.resetParts();
      this.current.updateRounds();
    }
    if (this.manual && this.current) { this.current.resetParts(); }
    this.reload = null; this.manual = null; this.autoCycleT = -1; this.inspectT = -1; this.leftOverride = null;
    if (this.state === 'reloading' || this.state === 'inspecting') this.state = 'ready';
  }

  // ---------------- main update ----------------
  update(dt, input, active) {
    this.time += dt;
    const w = this.current; if (!w) return;
    const def = w.def, p = this.player;

    if (active) this.handleInput(input);
    else { this.triggerHeld = false; this.adsHeld = false; }

    this.fireCooldown = Math.max(0, this.fireCooldown - dt);
    this.stateT += dt;
    if (this.state === 'equipping' && this.stateT >= def.equip) this.state = 'ready';
    if (this.state === 'unequipping' && this.stateT >= def.unequip) {
      const s = this.pendingSlot >= 0 ? this.pendingSlot : 1 - this.active; this.pendingSlot = -1;
      this.equip(s);
    }
    if (this.state === 'reloading') (this.reload.kind === 'shell' ? this.updateShellReload(dt) : this.updateMagReload(dt));
    this.updateCycles(dt);
    if (this.state === 'inspecting') { this.inspectT += dt; if (this.inspectT > 3.2) { this.state = 'ready'; this.inspectT = -1; } }

    // ---- ADS / sprint blends ----
    const canAds = this.adsHeld && (this.state === 'ready' || this.state === 'equipping') && !p.sliding
      && !(p.sprinting && p.speed2D > 1) && !(def.ads.scope && this.manual);
    this.adsBlend = clamp(this.adsBlend + (canAds ? 1 : -1) * dt / def.ads.time, 0, 1);
    const a = smooth(this.adsBlend);
    p.adsBlend = a;
    p.blockSprint = this.adsHeld || (this.triggerHeld && w.canFire && this.state === 'ready');
    p.weaponMobility = def.mobilityMul || 1;
    p.adsInput = this.adsHeld;
    const wantSprint = p.sprinting && p.speed2D > 2 && this.state !== 'reloading' && !this.manual && this.state !== 'inspecting' ? 1 : 0;
    this.sprintBlend = damp(this.sprintBlend, wantSprint, 9, dt);

    // ---- FOV ----
    const baseFov = settings.graphics.fov;
    this.camera.fov = lerp(baseFov + this.sprintBlend * 4 + (p.sliding ? 6 : 0), def.ads.fov, a);
    this.camera.updateProjectionMatrix();
    this.vmCamera.fov = lerp(60, def.ads.vmFov ?? (def.ads.scope ? 40 : 50), a);
    this.vmCamera.updateProjectionMatrix();
    // optics: lens uniforms (reflex brightness, scope PiP activation)
    const lens = w.model.meta.lens;
    if (lens && lens.userData.lens === 'scope') {
      lens.material.uniforms.uAds.value = a;
      lens.material.uniforms.uActive.value = this.scopeRendering ? 1 : 0;
    }
    p.adsZoom = def.ads.scope ? lerp(1, w.model.meta.zoom || 1, a) : 1;

    this.composeTransforms(dt);
    this.updateCameraRecoil(dt);
    this.updateFlash(dt);
    this.updateHands();
    this.crosshairSpread = damp(this.crosshairSpread, this.currentSpread(), 14, dt);
  }

  handleInput(input) {
    const w = this.current, def = w.def, c = settings.controls, p = this.player;
    if (c.adsMode === 'toggle') { if (input.pressed('ads')) this.adsToggled = !this.adsToggled; this.adsHeld = this.adsToggled; }
    else this.adsHeld = input.down('ads');
    this.triggerHeld = input.down('fire');
    const firePressed = input.pressed('fire');

    if (input.pressed('primary')) this.switchTo(0);
    if (input.pressed('secondary')) this.switchTo(1);
    if (input.pressed('swap')) this.switchTo(1 - this.active);
    if (input.consumeWheel() !== 0) this.switchTo(this.pendingSlot >= 0 ? 1 - this.pendingSlot : 1 - this.active);

    if (input.pressed('firemode') && def.fireModes.length > 1 && this.state === 'ready') {
      w.fireMode = def.fireModes[(def.fireModes.indexOf(w.fireMode) + 1) % def.fireModes.length];
      audio.cue('firemode'); bus.emit('weapon:changed', this.hudState());
    }
    if (input.pressed('reload')) this.tryReload();
    if (input.pressed('inspect') && this.state === 'ready' && !this.manual && this.autoCycleT < 0) { this.state = 'inspecting'; this.inspectT = 0; }
    if (this.state === 'inspecting' && (firePressed || this.adsHeld || input.pressed('reload') || p.sprinting)) { this.state = 'ready'; this.inspectT = -1; }
    // shell reload can be interrupted by firing (finishes the current shell first)
    if (this.state === 'reloading' && this.reload.kind === 'shell' && firePressed && w.mag > 0) this.reload.interrupt = true;

    this.handleTrigger(firePressed);
  }

  handleTrigger(firePressed) {
    const w = this.current, def = w.def;
    if (this.state !== 'ready') return;
    const want = w.fireMode === 'auto' ? this.triggerHeld : firePressed;
    if (!this.triggerHeld && this.time - this.lastShotTime > 0.25) this.shotsFired = 0;
    if (!want || this.fireCooldown > 0 || this.manual) return;
    if (w.mag <= 0) {
      if (firePressed) { audio.cue('dry_fire'); this.fireCooldown = 0.25; if (w.reserve > 0) this.tryReload(); }
      return;
    }
    if (w.needsCycle) { if (firePressed) this.startManualCycle(0); return; }
    if (this.sprintBlend > 0.35) { this.player.sprinting = false; this.fireCooldown = 0.06; return; }
    void def;
    this.fire();
  }

  // ---------------- action cycling ----------------
  startManualCycle(delay) {
    this.manual = { kind: this.current.def.cycle, t: -delay, sounds: 0 };
  }

  updateCycles(dt) {
    const w = this.current, def = w.def, parts = w.model.parts;
    // fast reciprocation for semi/auto (bolt carrier / charging handle)
    if (this.autoCycleT >= 0) {
      this.autoCycleT += dt;
      const dur = Math.min(0.08, (60 / def.rpm) * 0.8);
      const t = this.autoCycleT / dur;
      const back = t < 0.4 ? t / 0.4 : Math.max(0, 1 - (t - 0.4) / 0.6);
      const part = parts.slide || parts.bolt || parts.charge;
      const travel = parts.slide ? 0.032 : def.id === 'dynasty' ? 0.055 : parts.bolt ? 0.04 : 0.02;
      if (part) part.position.z = part.userData.rest.p.z + back * travel;
      if (t >= 1) { this.autoCycleT = -1; if (part) part.position.z = part.userData.rest.p.z; }
    }
    const m = this.manual;
    if (!m || this.state !== 'ready') return;
    m.t += dt;
    if (m.t < 0) return;
    const dur = m.kind === 'pump' ? def.pumpTime : def.boltTime;
    const t = m.t / dur;
    if (m.kind === 'boltAction') {
      A.boltCycle(w, Math.min(1, t));
      if (m.sounds === 0 && t > 0.05) { audio.cue('bolt_up'); m.sounds++; }
      if (m.sounds === 1 && t > 0.3) { audio.cue('bolt_back'); this.ejectCase(); m.sounds++; }
      if (m.sounds === 2 && t > 0.6) { audio.cue('bolt_fwd'); m.sounds++; }
      if (m.sounds === 3 && t > 0.8) { audio.cue('bolt_down'); m.sounds++; }
    } else {
      A.pumpCycle(w, Math.min(1, t));
      if (m.sounds === 0 && t > 0.05) { audio.cue('pump_back'); m.sounds++; }
      if (m.sounds === 1 && t > 0.35) { this.ejectCase(); m.sounds++; }
      if (m.sounds === 2 && t > 0.5) { audio.cue('pump_fwd'); m.sounds++; }
    }
    if (t >= 1) {
      this.manual = null;
      if (w.mag > 0) { w.chambered = true; w.needsCycle = false; }
      w.resetParts();
      bus.emit('weapon:ammo', this.hudState());
    }
  }

  // ---------------- reload ----------------
  tryReload() {
    const w = this.current, def = w.def;
    if (this.state !== 'ready' && this.state !== 'inspecting') return false;
    if (w.mag >= def.magSize || w.reserve <= 0 || this.autoCycleT >= 0) return false;
    // a pending/active bolt or pump cycle is cancelled: the reload itself re-chambers
    if (this.manual) { this.manual = null; w.resetParts(); }
    this.state = 'reloading'; this.inspectT = -1; this.adsToggled = false;
    if (def.reload.type === 'mag') {
      const kind = w.mag === 0 ? 'empty' : 'tactical';
      this.reload = { kind, t: 0, dur: def.reload[kind].time, events: def.reload.sounds[kind].map(([t, n]) => ({ t, n, done: false })), ammoGiven: false, magDropped: false };
    } else {
      this.reload = { kind: 'shell', phase: 'start', t: 0, interrupt: false, emptyStart: w.mag === 0, loadedThisCycle: false, soundDone: false, rackSounds: 0 };
    }
    bus.emit('weapon:reload', { kind: this.reload.kind });
    return true;
  }

  updateMagReload(dt) {
    const w = this.current, def = w.def, r = this.reload;
    r.t += dt;
    const t = Math.min(1, r.t / r.dur);
    for (const e of r.events) if (!e.done && t >= e.t) { e.done = true; audio.cue(e.n); }
    if (!r.ammoGiven && t >= def.reload[r.kind].ammoAt) {
      // ammo moves exactly once, when the new magazine seats. The old mag's
      // remaining rounds go back to reserve → total ammo is conserved.
      r.ammoGiven = true;
      const total = w.reserve + w.mag;
      w.mag = Math.min(def.magSize, total);
      w.reserve = total - w.mag;
      w.updateRounds();
      bus.emit('weapon:ammo', this.hudState());
    }
    if (t >= 1) {
      this.state = 'ready'; this.reload = null; this.leftOverride = null;
      w.chambered = w.mag > 0; w.needsCycle = false;
      w.resetParts(); w.updateRounds();
      bus.emit('weapon:ammo', this.hudState());
    }
  }

  updateShellReload(dt) {
    const w = this.current, def = w.def, R = def.reload, sl = this.reload;
    sl.t += dt;
    if (sl.phase === 'start') {
      if (sl.t >= R.start) { sl.phase = 'load'; sl.t = 0; sl.loadedThisCycle = false; sl.soundDone = false; }
    } else if (sl.phase === 'load') {
      const u = sl.t / R.perShell;
      if (!sl.soundDone && u >= R.sounds.shell[0][0]) { sl.soundDone = true; audio.cue('shell_in'); }
      if (!sl.loadedThisCycle && u >= R.shellAt) {
        sl.loadedThisCycle = true;
        if (w.reserve > 0 && w.mag < def.magSize) { w.mag++; w.reserve--; w.updateRounds(); bus.emit('weapon:ammo', this.hudState()); }
      }
      if (u >= 1) {
        if (w.mag >= def.magSize || w.reserve <= 0 || sl.interrupt) { sl.phase = sl.emptyStart ? 'rack' : 'end'; sl.t = 0; }
        else { sl.t = 0; sl.loadedThisCycle = false; sl.soundDone = false; }
      }
    } else if (sl.phase === 'rack') {
      const u = sl.t / R.emptyRack;
      A.pumpCycle(w, Math.min(1, u));
      if (sl.rackSounds === 0 && u > R.sounds.rack[0][0]) { audio.cue('pump_back'); sl.rackSounds++; }
      if (sl.rackSounds === 1 && u > R.sounds.rack[1][0]) { audio.cue('pump_fwd'); sl.rackSounds++; }
      if (u >= 1) { sl.phase = 'end'; sl.t = 0; w.resetParts(); }
    } else if (sl.phase === 'end' && sl.t >= R.end) {
      this.state = 'ready'; this.reload = null; this.leftOverride = null;
      w.chambered = w.mag > 0; w.needsCycle = false;
      w.resetParts(); w.updateRounds();
      bus.emit('weapon:ammo', this.hudState());
    }
  }

  // ---------------- transforms ----------------
  composeTransforms(dt) {
    const w = this.current, def = w.def, p = this.player;
    const a = smooth(this.adsBlend), sp = this.sprintBlend;

    // anchor
    const anchor = V(...def.hip.pos).lerp(w.adsPos, a).lerp(V(...def.sprint.pos), sp * (1 - a));
    const rx = lerp(0, -w.sightPitch, a) + def.sprint.rot[0] * sp;
    let ry = def.sprint.rot[1] * sp, rz = def.sprint.rot[2] * sp;
    const crouchK = p.crouching && !p.sliding ? 1 - a : 0;
    anchor.y += crouchK * 0.012; rz += crouchK * 0.06;
    if (p.sliding) { rz += 0.22 * (1 - a); anchor.x -= 0.02; }
    this.rig.position.copy(anchor);
    this.rig.rotation.set(rx, ry, rz, 'YXZ');

    // animation layer
    const pos = this.animNode.position.set(0, 0, 0), rot = this.animNode.rotation.set(0, 0, 0, 'YXZ');
    this.leftOverride = null;
    if (this.state === 'equipping') A.equipPose(this.stateT, def.equip, pos, rot);
    else if (this.state === 'unequipping') A.unequipPose(this.stateT, def.unequip, pos, rot);
    else if (this.state === 'inspecting') A.inspectPose(this.inspectT, pos, rot);
    else if (this.state === 'reloading') {
      if (this.reload.kind === 'shell') this.leftOverride = A.shellReloadPose(w, this.reload, pos, rot).leftHand;
      else {
        const r = this.reload;
        const res = A.magReloadPose(w, r.kind, Math.min(1, r.t / r.dur), pos, rot);
        this.leftOverride = res.leftHand;
        if (res.phase === 'swap' && !r.magDropped) { r.magDropped = true; if (r.kind === 'empty') this.dropMagProp(); }
        // while the new mag travels in show its (future) full content; before that the real count
        if (r.magDropped && !r.ammoGiven) w.updateRounds(Math.min(def.magSize, w.reserve + w.mag));
      }
    }
    if (this.manual && this.manual.t >= 0 && this.state === 'ready') {
      const dur = this.manual.kind === 'pump' ? def.pumpTime : def.boltTime;
      A.cyclePose(this.manual.kind, Math.min(1, this.manual.t / dur), pos, rot);
    }

    // sway / bob
    const swayK = 1 - a * 0.88, t = this.time;
    const ll = this.lastLook || { yaw: p.yaw, pitch: p.pitch };
    const id = 1 / Math.max(dt, 1e-3);
    this.lastLook = { yaw: p.yaw, pitch: p.pitch };
    const lx = clamp((p.yaw - ll.yaw) * id * 0.006, -0.04, 0.04) * swayK, ly = clamp((p.pitch - ll.pitch) * id * 0.004, -0.03, 0.03) * swayK;
    this.lookSway.x += (lx - this.lookSway.x) * (1 - Math.exp(-10 * dt));
    this.lookSway.y += (ly - this.lookSway.y) * (1 - Math.exp(-10 * dt));
    const bob = p.bobAmount * (1 - a * 0.85) * (1 + sp * 0.8), ph = p.bobPhase;
    const localVx = p.vel.x * Math.cos(p.yaw) - p.vel.z * Math.sin(p.yaw);
    const strafe = clamp(localVx / 7, -1, 1);
    this.moveSwayX = damp(this.moveSwayX, -strafe * 0.012 * swayK, 6, dt);
    const landY = this.landOffset.update(dt) * 0.02;
    this.jumpOffset = damp(this.jumpOffset, p.grounded ? 0 : clamp(p.vel.y * 0.003, -0.02, 0.015), 8, dt);
    this.swayNode.position.set(
      Math.sin(t * 1.1) * 0.0018 * swayK + Math.sin(ph) * 0.011 * bob + this.moveSwayX - this.lookSway.x * 0.5,
      Math.sin(t * 2.2) * 0.0012 * swayK - Math.abs(Math.cos(ph)) * 0.009 * bob + landY + this.jumpOffset - this.lookSway.y * 0.4, 0);
    this.swayNode.rotation.set(-this.lookSway.y * 1.2 + landY * 2, -this.lookSway.x * 1.5, this.lookSway.x * 2 + strafe * 0.04 * swayK + Math.sin(ph) * 0.012 * bob, 'YXZ');

    // recoil
    this.recoilNode.position.set(0, this.rPosY.update(dt) * 0.01, this.rPosZ.update(dt) * 0.01);
    this.recoilNode.rotation.set(this.rRotX.update(dt) * 0.01, this.rRotY.update(dt) * 0.01, this.rRotZ.update(dt) * 0.01, 'YXZ');

    const trig = w.model.parts.trigger;
    trig.rotation.x = damp(trig.rotation.x, this.triggerHeld && this.state === 'ready' ? 0.12 : 0, 25, dt);
  }

  // ---------------- hands ----------------
  updateHands() {
    const w = this.current, sock = w.model.sockets, root = w.model.root;
    this.rig.updateWorldMatrix(true, true);
    const rootQ = root.getWorldQuaternion(new THREE.Quaternion());
    const toVM = (local, q) => ({ pos: local.clone().applyMatrix4(root.matrixWorld), quat: rootQ.clone().multiply(q) });
    const R = toVM(sock.rightHand.position.clone().add(V(0.004, 0, 0)), new THREE.Quaternion().setFromEuler(E(-1.75, 0, -0.25)));
    this.arms.setTarget('R', R.pos, R.quat);
    let L;
    if (this.leftOverride) L = toVM(this.leftOverride.pos, this.leftOverride.quat);
    else L = toVM(sock.leftHand.position.clone().add(w.def.id === 'bigrig' ? V(-0.01, -0.02, 0) : V(-0.008, -0.03, 0)), A.Q_GRIP);
    this.arms.setTarget('L', L.pos, L.quat);

    // shell held in the left hand during Kraken loading
    if (w.def.reload.type === 'shell') {
      if (!this.handShell) { this.handShell = w.model.rounds[0].clone(); this.handShell.visible = false; this.vmScene.add(this.handShell); }
      const show = !!(this.leftOverride && this.leftOverride.shell && w.reserve > 0);
      this.handShell.visible = show;
      if (show) {
        this.handShell.position.copy(L.pos).add(V(0, 0.035, -0.01).applyQuaternion(L.quat));
        this.handShell.quaternion.copy(rootQ);
      }
    } else if (this.handShell) this.handShell.visible = false;

    // The weapon & arms stay visible in scope ADS: the magnified image is
    // shown only inside the ocular lens (picture-in-picture), never as a
    // full-screen overlay.
    this.rig.visible = true;
    this.arms.group.visible = true;
    this.arms.update();
  }

  get scoped() { return !!(this.current && this.current.def.ads.scope && this.adsBlend > 0.92); }
  /** Scope picture-in-picture is needed whenever the scope is (partly) raised. */
  get scopeLens() {
    const w = this.current;
    if (!w || !w.def.ads.scope || this.adsBlend < 0.25 || !w.model.meta.lens) return null;
    return w.model.meta.lens;
  }
  get busy() { return this.state === 'reloading' || !!this.manual; }

  hudState() {
    const w = this.current; if (!w) return null;
    return {
      id: w.def.id, name: w.def.name, mag: w.mag, magSize: w.def.magSize, reserve: w.reserve, fireMode: w.fireMode,
      slots: this.slots.map((s, i) => ({ name: s.def.name, active: i === this.active })),
      reloading: this.state === 'reloading', needsCycle: w.needsCycle,
    };
  }

  refill() {
    for (const s of this.slots) { s.mag = s.def.magSize; s.reserve = s.def.reserve; s.chambered = true; s.needsCycle = false; s.updateRounds(); }
    bus.emit('weapon:ammo', this.hudState());
  }
}
Object.assign(WeaponController.prototype, FiringMixin);
