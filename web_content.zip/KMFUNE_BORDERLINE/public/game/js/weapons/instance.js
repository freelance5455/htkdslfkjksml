// =====================================================================
// WeaponInstance — authoritative per-weapon state (ammo, mode, model)
// plus small animation helpers shared by the controller modules.
// =====================================================================
import * as THREE from 'three';
import { BUILDERS } from './models.js';
import { assembleModel, effectiveDef } from './gunsmith.js';
import { smoother } from '../core/math.js';

export const V = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
export const E = (x = 0, y = 0, z = 0) => new THREE.Euler(x, y, z, 'YXZ');

/** Keyframes [[t, value|array]] sampled with smootherstep interpolation. */
export function sampleKeys(keys, t) {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    if (t <= keys[i][0]) {
      const [t0, a] = keys[i - 1], [t1, b] = keys[i];
      const u = smoother((t - t0) / Math.max(1e-6, t1 - t0));
      if (typeof a === 'number') return a + (b - a) * u;
      return a.map((x, k) => x + (b[k] - x) * u);
    }
  }
  return keys[keys.length - 1][1];
}

export class WeaponInstance {
  /** @param def weapon definition  @param cfg optional WeaponConfiguration (gunsmith) */
  constructor(def, cfg = null) {
    this.cfg = cfg;
    this.def = cfg ? effectiveDef(cfg) : def;
    def = this.def;
    this.model = cfg ? assembleModel(cfg) : BUILDERS[def.builder]();
    this.mag = def.magSize;
    this.reserve = def.reserve;
    this.chambered = true;
    this.needsCycle = false;     // bolt/pump must be worked before next shot
    this.fireMode = def.fireModes[0];

    // ---- ADS alignment derived from the model's real sight geometry ----
    const m = this.model.meta;
    let sightY, sightZ, eyeRelief;
    if (m.scopeEye) { sightY = m.scopeEye.y; sightZ = m.scopeEye.z; eyeRelief = -(m.eyeRelief ?? 0.08); }
    else if (m.reticle) { sightY = m.reticle.y; sightZ = m.reticle.z; eyeRelief = -0.2; }
    else if (m.rearSight) { sightY = m.rearSight.y; sightZ = m.rearSight.z; eyeRelief = -(def.ads.eyeRelief ?? 0.16); }  // per-weapon (pistols: arm's length)
    else { sightY = 0.1; sightZ = 0; eyeRelief = -0.2; }   // no sights at all (should not happen: sanitize forces an optic)
    // Sight line passes through the eye: weapon origin placed at (0, -sightY, eye - sightZ)
    this.adsPos = V(0, -sightY, eyeRelief - sightZ);
    // pitch so the rear→front sight line is exactly parallel to the view axis
    this.sightPitch = (m.rearSight && m.frontSight)
      ? Math.atan2(m.frontSight.y - m.rearSight.y, m.rearSight.z - m.frontSight.z)
      : 0;
  }

  get canFire() { return this.mag > 0 && this.chambered && !this.needsCycle; }

  /** Visible cartridges always mirror the real magazine count. */
  updateRounds(countOverride) {
    const n = countOverride ?? this.mag;
    const r = this.model.rounds;
    for (let i = 0; i < r.length; i++) r[i].visible = n > i;
    if (this.model.sideShells) {
      const k = Math.min(4, this.reserve);
      this.model.sideShells.forEach((s, i) => (s.visible = i < k));
    }
  }

  resetParts() {
    this.model.root.traverse((o) => {
      if (o.userData.part && o.userData.rest) { o.position.copy(o.userData.rest.p); o.rotation.copy(o.userData.rest.r); o.visible = true; }
    });
    if (this.model.parts.boltHandle) this.model.parts.boltHandle.rotation.set(0, 0, 0);
  }
}
