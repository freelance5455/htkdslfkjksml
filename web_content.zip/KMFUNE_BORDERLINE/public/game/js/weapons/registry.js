// =====================================================================
// WeaponRegistry — reference weapons (gunsmith) as WeaponDefinitions
// ---------------------------------------------------------------------
// Each definition uses the same schema as definitions.js (so the
// existing controller, firing, reload, recoil and audio code run them
// unchanged) plus gunsmith data:
//   slots   { slot: [compatible attachment ids] }  (AttachmentCompatibility)
//   base    0–100 display stats in the reference's categories
//           (damage, range, control, accuracy(hip), mobility, fire rate)
//   ref     reference provenance: status CONFIRMED / PARTIAL, timestamps
// =====================================================================
import { WEAPONS as LEGACY, WEAPON_ORDER as LEGACY_ORDER } from './definitions.js';
import { buildVector, buildP90, buildFN2000, buildQBZ95, buildSCAR } from './refmodels.js';
import { buildAWM, buildBarrett, buildM700, buildM250, buildSidearm } from './refmodels2.js';

export const CATEGORIES = [
  { id: 'handgun', label: 'HANDGUNS', ref: '手枪' },
  { id: 'ar', label: 'ASSAULT RIFLES', ref: '自动步枪' },
  { id: 'smg', label: 'SMGs', ref: '冲锋枪' },
  { id: 'shotgun', label: 'SHOTGUNS', ref: '霰弹枪' },
  { id: 'lmg', label: 'LMGs', ref: '轻机枪' },
  { id: 'marksman', label: 'MARKSMAN', ref: '射手步枪' },
  { id: 'sniper', label: 'SNIPERS', ref: '狙击枪' },
];

const OPT_1X = ['red_dot', 'mini_dot', 'holo'];
const OPT_MID = ['prism2', 'acog4'];
const OPT_SNIPER = ['acog4', 'scope8', 'scope12'];
const MUZ = ['flash_hider', 'compensator', 'supp_short', 'supp_long', 'supp_square'];
const UNDER = ['vgrip', 'stubby', 'angled'];
const GRIPS = ['grip_striped', 'grip_spotted', 'grip_granular'];

const mk = (o) => ({
  pellets: 1, moveSpread: 0.01, adsSpread: 0.0008, headMul: 1.8, hands: { rightGrip: 'rightHand', leftGrip: 'leftHand' },
  equip: 0.45, unequip: 0.3, shotPitch: [0.97, 1.03], shotVolume: 0.8, caseEject: 'rifle', ...o,
});
const magReload = (tac, emp, chargeName = 'bolt') => ({
  type: 'mag',
  tactical: { time: tac, ammoAt: 0.58 },
  empty: { time: emp, ammoAt: 0.5 },
  sounds: {
    tactical: [[0.14, 'mag_out'], [0.5, 'mag_in'], [0.58, 'mag_seat'], [0.84, 'cloth']],
    empty: [[0.1, 'mag_out'], [0.4, 'mag_in'], [0.5, 'mag_seat'], [0.66, chargeName + '_back'], [0.75, chargeName + '_fwd'], [0.9, 'cloth']],
  },
});
const boltReload = (tac, emp) => ({
  type: 'mag',
  tactical: { time: tac, ammoAt: 0.62 },
  empty: { time: emp, ammoAt: 0.55 },
  sounds: {
    tactical: [[0.16, 'mag_out'], [0.55, 'mag_in'], [0.62, 'mag_seat'], [0.86, 'cloth']],
    empty: [[0.06, 'bolt_up'], [0.12, 'bolt_back'], [0.22, 'mag_out'], [0.5, 'mag_in'], [0.56, 'mag_seat'], [0.72, 'bolt_fwd'], [0.78, 'bolt_down'], [0.92, 'cloth']],
  },
});

export const REF_WEAPONS = {
  vector: mk({
    id: 'vector', name: 'VECTOR', category: 'Submachine Gun', cat: 'smg', builder: 'vector', build: buildVector,
    blurb: '.45 ACP SMG with the Super-V recoil system: very high rate of fire, low muzzle climb.',
    magSize: 25, reserve: 175, fireModes: ['auto', 'semi'], rpm: 1100, damage: 24, spread: 0.0048, range: 140, falloff: [15, 45, 0.5],
    recoil: { pitch: 0.0052, yaw: 0.0036, yawBias: 0.05, recover: 12, kickBack: 0.02, kickUp: 0.006, roll: 0.025, adsMul: 0.6 },
    cycle: 'charge', hip: { pos: [0.16, -0.18, -0.34], rot: [0, 0, 0] }, ads: { fov: 66, time: 0.16 }, sprint: { pos: [0.06, -0.21, -0.3], rot: [-0.3, 0.7, 0.2] },
    reload: magReload(1.9, 2.5, 'bolt'), sound: 'smg_shot', shotPitch: [1.04, 1.1], shotVolume: 0.68,
    slots: { optic: [...OPT_1X, 'prism2'], muzzle: MUZ, barrel: ['barrel_long', 'barrel_short'], underbarrel: UNDER, laser: ['laser'], magazine: ['mag_ext', 'mag_drum'], stock: ['stock_tac', 'stock_fold'], grip: GRIPS },
    base: { damage: 24, range: 16, control: 42, accuracy: 44, mobility: 79, rof: 92 },
    ref: { status: 'CONFIRMED', time: '0:00–0:59', note: 'Name "Vector" legible; drum mag, long shroud, suppressor & folding stock shown.' },
  }),
  p90: mk({
    id: 'p90', name: 'P90', category: 'PDW', cat: 'smg', builder: 'p90', build: buildP90,
    blurb: '5.7×28 bullpup PDW. 50-round top-mounted magazine, ambidextrous downward ejection.',
    magSize: 50, reserve: 250, fireModes: ['auto', 'semi'], rpm: 909, damage: 25, spread: 0.0046, range: 160, falloff: [18, 55, 0.55],
    recoil: { pitch: 0.0056, yaw: 0.0034, yawBias: -0.05, recover: 11, kickBack: 0.02, kickUp: 0.007, roll: 0.025, adsMul: 0.6 },
    cycle: 'charge', hip: { pos: [0.15, -0.165, -0.33], rot: [0, 0, 0] }, ads: { fov: 66, time: 0.17 }, sprint: { pos: [0.06, -0.21, -0.3], rot: [-0.3, 0.7, 0.2] },
    reload: { ...magReload(2.6, 3.1, 'bolt'), topLoad: true }, sound: 'pdw_shot', shotVolume: 0.66,
    slots: { optic: OPT_1X, muzzle: MUZ, barrel: ['barrel_long'], underbarrel: UNDER, laser: ['laser'], stock: ['stock_pad'], grip: GRIPS },
    base: { damage: 25, range: 18, control: 29, accuracy: 40, mobility: 64, rof: 64 },
    ref: { status: 'CONFIRMED', time: '1:00–1:52', note: 'Stats legible at 1:40: damage 25, range 18 m, RPM 909, mag 50, muzzle velocity 883 m/s.' },
  }),
  fn2000: mk({
    id: 'fn2000', name: 'FN2000', category: 'Assault Rifle', cat: 'ar', builder: 'fn2000', build: buildFN2000,
    blurb: '5.56 bullpup rifle with a smooth one-piece shell and forward ejection.',
    magSize: 30, reserve: 210, fireModes: ['auto', 'semi'], rpm: 800, damage: 31, spread: 0.0026, range: 380, falloff: [45, 150, 0.6],
    recoil: { pitch: 0.0085, yaw: 0.0028, yawBias: 0.1, recover: 9.5, kickBack: 0.028, kickUp: 0.01, roll: 0.03, adsMul: 0.55 },
    cycle: 'charge', hip: { pos: [0.15, -0.17, -0.36], rot: [0, 0, 0] }, ads: { fov: 62, time: 0.21 }, sprint: { pos: [0.06, -0.21, -0.32], rot: [-0.32, 0.72, 0.18] },
    reload: magReload(2.4, 3.0, 'bolt'), sound: 'carbine_shot', shotVolume: 0.78,
    slots: { optic: [...OPT_1X, ...OPT_MID], muzzle: MUZ, barrel: ['barrel_long', 'barrel_short'], underbarrel: UNDER, laser: ['laser'], magazine: ['mag_ext'], stock: ['stock_comp'], grip: GRIPS },
    base: { damage: 31, range: 38, control: 48, accuracy: 46, mobility: 58, rof: 70 },
    ref: { status: 'CONFIRMED', time: '4:42–5:58', note: 'Name legible; red-dot, holo, 2.0× optic, vertical grip, extended mag, suppressor seen.' },
  }),
  scar: mk({
    id: 'scar', name: 'SCAR', category: 'Battle Rifle', cat: 'ar', builder: 'scar', build: buildSCAR,
    blurb: '7.62 battle rifle: monolithic top rail, side-folding stock, hard-hitting.',
    magSize: 20, reserve: 140, fireModes: ['auto', 'semi'], rpm: 600, damage: 41, spread: 0.0028, range: 450, falloff: [55, 180, 0.65],
    recoil: { pitch: 0.0125, yaw: 0.0038, yawBias: 0.12, recover: 8.5, kickBack: 0.036, kickUp: 0.013, roll: 0.035, adsMul: 0.55 },
    cycle: 'bolt', hip: { pos: [0.165, -0.175, -0.36], rot: [0, 0, 0] }, ads: { fov: 62, time: 0.23 }, sprint: { pos: [0.06, -0.2, -0.32], rot: [-0.32, 0.72, 0.18] },
    reload: magReload(2.3, 2.9, 'bolt'), sound: 'battle_shot', shotVolume: 0.86,
    slots: { optic: [...OPT_1X, ...OPT_MID], muzzle: MUZ, barrel: ['barrel_long', 'barrel_cqc'], underbarrel: UNDER, laser: ['laser'], magazine: ['mag_ext'], stock: ['stock_tac', 'stock_compact'], grip: GRIPS },
    base: { damage: 41, range: 44, control: 34, accuracy: 42, mobility: 56, rof: 52 },
    ref: { status: 'CONFIRMED', time: '5:59–6:57', note: 'Name legible; long suppressor, vertical grip, RMR-type red dot, tactical stock seen.' },
  }),
  qbz95: mk({
    id: 'qbz95', name: 'QBZ95', category: 'Assault Rifle', cat: 'ar', builder: 'qbz95', build: buildQBZ95,
    blurb: '5.8 mm bullpup with integral carry-handle rail. Shown in a white/gold/blue skin.',
    magSize: 30, reserve: 210, fireModes: ['auto', 'semi'], rpm: 680, damage: 33, spread: 0.0026, range: 400, falloff: [50, 160, 0.6],
    recoil: { pitch: 0.0092, yaw: 0.0032, yawBias: -0.08, recover: 9, kickBack: 0.03, kickUp: 0.011, roll: 0.03, adsMul: 0.55 },
    cycle: 'charge', hip: { pos: [0.155, -0.17, -0.36], rot: [0, 0, 0] }, ads: { fov: 62, time: 0.22 }, sprint: { pos: [0.06, -0.21, -0.32], rot: [-0.32, 0.72, 0.18] },
    reload: magReload(2.5, 3.1, 'bolt'), sound: 'dynasty_shot', shotPitch: [1.02, 1.07], shotVolume: 0.78,
    slots: { optic: [...OPT_1X, ...OPT_MID], muzzle: MUZ, barrel: ['barrel_long'], underbarrel: UNDER, laser: ['laser'], magazine: ['mag_ext'], stock: ['stock_cheek'], grip: GRIPS },
    base: { damage: 33, range: 40, control: 44, accuracy: 45, mobility: 60, rof: 60 },
    ref: { status: 'CONFIRMED', time: '6:58–8:05', note: 'Name legible; 3.0× optic, brake, vertical grip; first-person inspect & range firing at 7:47–8:05.' },
  }),
  m250: mk({
    id: 'm250', name: 'M250', category: 'Light Machine Gun', cat: 'lmg', builder: 'm250', build: buildM250,
    blurb: 'Belt-fed 6.8 mm LMG: big calibre, slow cyclic rate, 75-round pouch.',
    magSize: 75, reserve: 225, fireModes: ['auto'], rpm: 550, damage: 41, spread: 0.0042, moveSpread: 0.018, range: 450, falloff: [50, 170, 0.65],
    recoil: { pitch: 0.0105, yaw: 0.0046, yawBias: 0.15, recover: 8, kickBack: 0.034, kickUp: 0.012, roll: 0.03, adsMul: 0.6 },
    cycle: 'bolt', hip: { pos: [0.17, -0.19, -0.38], rot: [0, 0, 0] }, ads: { fov: 62, time: 0.3 }, sprint: { pos: [0.06, -0.22, -0.34], rot: [-0.3, 0.7, 0.2] },
    reload: { ...magReload(4.6, 5.2, 'bolt'), belt: true }, equip: 0.7, unequip: 0.4, sound: 'lmg_shot', shotVolume: 0.86,
    slots: { optic: [...OPT_1X, ...OPT_MID], muzzle: MUZ, barrel: ['barrel_long'], underbarrel: UNDER, laser: ['laser'], magazine: ['mag_ext'], grip: GRIPS },
    base: { damage: 41, range: 41, control: 22, accuracy: 56, mobility: 62, rof: 64 },
    ref: { status: 'CONFIRMED', time: '8:32', note: 'Loadout screen: M250, damage 41, range 41 m, RPM 550, mag 75, 800 m/s.' },
  }),
  awm: mk({
    id: 'awm', name: 'AWM', category: 'Sniper Rifle', cat: 'sniper', builder: 'awm', build: buildAWM,
    blurb: '.338 Lapua Magnum bolt-action. Thumbhole chassis, fluted barrel, one-shot potential.',
    magSize: 5, reserve: 30, fireModes: ['bolt'], rpm: 45, damage: 150, spread: 0.035, adsSpread: 0.0, moveSpread: 0.03, range: 1000, falloff: [250, 700, 0.8], headMul: 2.2,
    recoil: { pitch: 0.062, yaw: 0.01, yawBias: 0.1, recover: 5, kickBack: 0.09, kickUp: 0.03, roll: 0.05, adsMul: 0.6 },
    cycle: 'boltAction', boltTime: 1.0, caseEject: 'rifleBig', hip: { pos: [0.17, -0.19, -0.4], rot: [0, 0, 0] }, ads: { fov: 58, time: 0.32, scope: true, vmFov: 38 }, sprint: { pos: [0.06, -0.22, -0.34], rot: [-0.3, 0.7, 0.18] },
    reload: boltReload(2.6, 3.4), equip: 0.6, unequip: 0.35, sound: 'magnum_shot', shotVolume: 1.0,
    slots: { optic: OPT_SNIPER, muzzle: ['brake', 'supp_long', 'supp_square'], barrel: ['barrel_long'], underbarrel: ['vgrip'], laser: ['laser'], magazine: ['mag_ext'], stock: ['stock_tac'], grip: GRIPS },
    defaults: { optic: 'scope8' },
    base: { damage: 95, range: 92, control: 30, accuracy: 18, mobility: 40, rof: 8 },
    ref: { status: 'CONFIRMED', time: '1:53–3:05', note: 'Name legible; olive thumbhole stock, suppressor, 8×/12× scopes, tactical stock, laser.' },
  }),
  barrett: mk({
    id: 'barrett', name: 'BARRETT', category: 'Anti-Materiel Rifle', cat: 'sniper', builder: 'barrett', build: buildBarrett,
    blurb: '.50 BMG semi-automatic anti-materiel rifle with a signature double-chamber brake.',
    magSize: 10, reserve: 30, fireModes: ['semi'], rpm: 90, damage: 130, spread: 0.04, adsSpread: 0.0005, moveSpread: 0.035, range: 1200, falloff: [300, 800, 0.8], headMul: 2.0,
    recoil: { pitch: 0.07, yaw: 0.012, yawBias: 0.1, recover: 4.5, kickBack: 0.1, kickUp: 0.035, roll: 0.06, adsMul: 0.6 },
    cycle: 'bolt', caseEject: 'rifleBig', hip: { pos: [0.17, -0.2, -0.42], rot: [0, 0, 0] }, ads: { fov: 58, time: 0.38, scope: true, vmFov: 38 }, sprint: { pos: [0.06, -0.23, -0.36], rot: [-0.3, 0.68, 0.18] },
    reload: magReload(3.0, 3.8, 'bolt'), equip: 0.75, unequip: 0.4, sound: 'magnum_shot', shotPitch: [0.86, 0.9], shotVolume: 1.0,
    slots: { optic: OPT_SNIPER, muzzle: ['brake', 'supp_long'], barrel: ['barrel_long'], underbarrel: ['vgrip'], laser: ['laser'], magazine: ['mag_ext'], stock: ['stock_tac'], grip: GRIPS },
    defaults: { optic: 'scope8', muzzle: 'brake' },
    base: { damage: 88, range: 96, control: 20, accuracy: 15, mobility: 30, rof: 14 },
    ref: { status: 'CONFIRMED', time: '3:06–3:51', note: 'Name legible as 巴雷特 (Barrett); brake, heavy suppressor, scopes, tactical grip.' },
  }),
  m700: mk({
    id: 'm700', name: 'M700', category: 'Sniper Rifle', cat: 'sniper', builder: 'm700', build: buildM700,
    blurb: '.308 bolt-action in a skeletal tactical chassis with M-LOK forend.',
    magSize: 5, reserve: 35, fireModes: ['bolt'], rpm: 55, damage: 120, spread: 0.032, adsSpread: 0.0, moveSpread: 0.028, range: 900, falloff: [220, 600, 0.8], headMul: 2.0,
    recoil: { pitch: 0.052, yaw: 0.01, yawBias: 0.08, recover: 5.5, kickBack: 0.08, kickUp: 0.028, roll: 0.045, adsMul: 0.6 },
    cycle: 'boltAction', boltTime: 0.85, caseEject: 'rifleBig', hip: { pos: [0.17, -0.185, -0.4], rot: [0, 0, 0] }, ads: { fov: 58, time: 0.3, scope: true, vmFov: 38 }, sprint: { pos: [0.06, -0.22, -0.34], rot: [-0.3, 0.7, 0.18] },
    reload: boltReload(2.4, 3.2), equip: 0.55, unequip: 0.35, sound: 'ranger_shot', shotPitch: [1.02, 1.06], shotVolume: 0.95,
    slots: { optic: OPT_SNIPER, muzzle: ['brake', 'supp_long', 'supp_square', 'compensator'], barrel: ['barrel_long'], underbarrel: UNDER, laser: ['laser'], magazine: ['mag_ext'], stock: ['stock_tac'], grip: GRIPS },
    defaults: { optic: 'scope8' },
    base: { damage: 80, range: 85, control: 38, accuracy: 22, mobility: 48, rof: 10 },
    ref: { status: 'CONFIRMED', time: '3:52–4:41', note: 'Name legible; skeletal chassis, suppressors, scopes, tactical stock.' },
  }),
  sidearm: mk({
    id: 'sidearm', name: 'P-17 SIDEARM', category: 'Handgun', cat: 'handgun', builder: 'sidearm', build: buildSidearm,
    blurb: 'Polymer-frame 9 mm striker pistol (secondary-slot pistol visible in the loadout screen).',
    magSize: 17, reserve: 102, fireModes: ['semi'], rpm: 450, damage: 26, spread: 0.004, range: 90, falloff: [12, 40, 0.5],
    recoil: { pitch: 0.016, yaw: 0.005, yawBias: 0.1, recover: 12, kickBack: 0.03, kickUp: 0.02, roll: 0.06, adsMul: 0.6 },
    cycle: 'slide', hip: { pos: [0.13, -0.15, -0.36], rot: [0, 0, 0] }, ads: { fov: 68, time: 0.14, eyeRelief: 0.34 }, sprint: { pos: [0.08, -0.25, -0.3], rot: [-0.6, 0.3, 0.1] },
    reload: { ...magReload(1.5, 1.9, 'bolt'), pistol: true }, equip: 0.3, unequip: 0.22, sound: 'pistol_shot', shotVolume: 0.7,
    slots: { muzzle: ['supp_short', 'compensator'], barrel: ['barrel_long'], laser: ['laser'], magazine: ['mag_ext'] },
    mountOverrides: { laser: 'underbarrel' },
    base: { damage: 26, range: 14, control: 55, accuracy: 60, mobility: 92, rof: 40 },
    ref: { status: 'PARTIAL', time: '8:32 (secondary slot)', note: 'Glock-pattern pistol with tan/purple skin seen; name not legible → generic name.' },
  }),
};

// Legacy (original Borderlands-style) weapons stay available; give them
// gunsmith categories so they appear in the same menu.
const LEGACY_CAT = { dynasty: 'ar', vanguard: 'smg', ranger: 'sniper', bigrig: 'shotgun', kraken: 'shotgun' };
const LEGACY_BASE = {
  dynasty: { damage: 34, range: 40, control: 40, accuracy: 42, mobility: 60, rof: 58 },
  vanguard: { damage: 21, range: 18, control: 50, accuracy: 48, mobility: 80, rof: 85 },
  ranger: { damage: 90, range: 90, control: 32, accuracy: 20, mobility: 44, rof: 8 },
  bigrig: { damage: 85, range: 10, control: 30, accuracy: 30, mobility: 50, rof: 22 },
  kraken: { damage: 80, range: 12, control: 34, accuracy: 32, mobility: 54, rof: 12 },
};
for (const id of LEGACY_ORDER) {
  const d = LEGACY[id];
  d.cat = LEGACY_CAT[id];
  d.base = LEGACY_BASE[id];
  d.legacy = true;
  d.slots = d.slots || {};
  d.ref = { status: 'ORIGINAL', note: 'Original KMFUNE weapon (Borderlands-style reference set). Fixed sights.' };
}

export const ALL_WEAPONS = { ...REF_WEAPONS, ...LEGACY };
export const ALL_ORDER = ['sidearm', 'fn2000', 'scar', 'qbz95', 'dynasty', 'vector', 'p90', 'vanguard', 'bigrig', 'kraken', 'm250', 'awm', 'barrett', 'm700', 'ranger'];

export const WeaponRegistry = {
  get: (id) => ALL_WEAPONS[id] || null,
  byCategory: (cat) => ALL_ORDER.filter((id) => ALL_WEAPONS[id].cat === cat),
  categoriesInUse: () => CATEGORIES.filter((c) => ALL_ORDER.some((id) => ALL_WEAPONS[id].cat === c.id)),
};
