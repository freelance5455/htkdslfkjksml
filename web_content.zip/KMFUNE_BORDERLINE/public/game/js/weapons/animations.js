// =====================================================================
// Weapon animation layers (procedural keyframes)
// Pure functions: given controller state they return a pose for the
// animation node and drive the weapon's articulated parts. They also
// return a left-hand target (in weapon space) when the support hand
// leaves the handguard.
// =====================================================================
import * as THREE from 'three';
import { V, E, sampleKeys } from './instance.js';
import { clamp, lerp, smooth, easeOutBack } from '../core/math.js';

const qFromE = (x, y, z) => new THREE.Quaternion().setFromEuler(E(x, y, z));
const Q_GRIP = qFromE(-1.4, 0, 0.3);     // palm up under handguard
const Q_MAG = qFromE(-0.4, 0.2, 1.4);    // palm wrapping a magazine
const Q_CHARGE = qFromE(-0.2, 0, -1.6);  // palm down over the top / side

/** Equip (raise) */
export function equipPose(t, dur, pos, rot) {
  const u = easeOutBack(clamp(t / dur, 0, 1));
  pos.set(0, lerp(-0.28, 0, u), lerp(0.08, 0, u));
  rot.set(lerp(-0.9, 0, u), lerp(0.3, 0, u), lerp(0.4, 0, u));
}
/** Unequip (lower) */
export function unequipPose(t, dur, pos, rot) {
  const u = smooth(clamp(t / dur, 0, 1));
  pos.set(0, -0.3 * u, 0.06 * u);
  rot.set(-0.9 * u, 0.25 * u, 0.4 * u);
}
/** Inspect: lift, turn to show left side, roll back to show the right. */
export function inspectPose(t, pos, rot) {
  const u = t / 3.2;
  const k = sampleKeys([[0, 0], [0.12, 1], [0.88, 1], [1, 0]], u);
  const turn = sampleKeys([[0, 0], [0.15, 0], [0.45, 1], [0.6, 1], [0.85, -0.25], [1, 0]], u);
  pos.set(-0.12 * k, 0.05 * k, 0.05 * k);
  rot.set(0.15 * k, -0.6 * turn * k - 0.25 * k, 0.9 * turn * k);
}

/** Bolt-action cycle: lift → back (eject) → forward → down. Drives bolt + handle. */
export function boltCycle(w, t) {
  const p = w.model.parts;
  const lift = t < 0.2 ? t / 0.2 : t < 0.7 ? 1 : Math.max(0, 1 - (t - 0.7) / 0.15);
  const back = t < 0.2 ? 0 : t < 0.45 ? (t - 0.2) / 0.25 : t < 0.7 ? 1 - (t - 0.45) / 0.25 : 0;
  p.boltHandle.rotation.z = smooth(lift) * 1.25;
  p.bolt.position.z = p.bolt.userData.rest.p.z + smooth(back) * 0.085;
}
/** Pump cycle: back then forward. */
export function pumpCycle(w, t) {
  const p = w.model.parts;
  const back = t < 0.45 ? smooth(t / 0.45) : Math.max(0, 1 - smooth((t - 0.45) / 0.45));
  p.pump.position.z = p.pump.userData.rest.p.z + back * 0.09;
  if (p.bolt) p.bolt.position.z = p.bolt.userData.rest.p.z + back * 0.06;
  return back;
}
/** Cant pose while working a manual action. */
export function cyclePose(kind, t, pos, rot) {
  const k = sampleKeys([[0, 0], [0.2, 1], [0.8, 1], [1, 0]], t);
  if (kind === 'boltAction') { rot.z += 0.18 * k; rot.x += 0.04 * k; pos.y -= 0.015 * k; }
  else { rot.x -= 0.03 * k; pos.z += 0.01 * k; }
}

/** Key moments of a magazine reload clip, derived from its sound timeline. */
export function magTimeline(def, kind) {
  const s = def.reload.sounds[kind];
  const find = (...names) => s.find((x) => names.includes(x[1]))?.[0];
  const empty = kind === 'empty';
  const tOut = find('mag_out') ?? 0.12;
  const tIn = find('mag_in') ?? 0.45;
  const seat = def.reload[kind].ammoAt;
  const tCh = empty ? (find('bolt_back', 'pump_back') ?? 0.7) : 1;
  const tChF = empty ? (find('bolt_fwd', 'pump_fwd') ?? 0.78) : 1;
  return { empty, tOut, tIn, seat, tCh, tChF };
}

/**
 * Magazine reload choreography:
 *  tilt → hand to mag → release & pull out → (empty: drop) → retrieve new
 *  mag from pouch → align & insert → seat (slap) → [empty: charge] → ready.
 * Returns { leftHand:{pos,quat}, magOut:boolean(phase where old mag left) }
 */
export function magReloadPose(w, kind, t, pos, rot) {
  const def = w.def, parts = w.model.parts;
  const T = magTimeline(def, kind);
  const { empty, tOut, tIn, seat, tCh, tChF } = T;

  // ---- weapon body ----
  const tilt = sampleKeys([[0, 0], [0.1, 1], [seat + 0.05, 1], [empty ? tCh - 0.05 : 0.85, empty ? 0.6 : 1], [empty ? Math.min(0.97, tChF + 0.08) : 0.85, 0.6], [1, 0]], t);
  const charge = empty ? sampleKeys([[0, 0], [tCh - 0.08, 0], [tCh, 1], [tChF + 0.06, 1], [Math.min(1, tChF + 0.14), 0]], t) : 0;
  rot.set(0.32 * tilt + 0.1 * charge, -0.22 * tilt, 0.55 * tilt - 0.35 * charge);
  pos.set(-0.03 * tilt, 0.035 * tilt + 0.02 * charge, 0.02 * tilt);
  const slap = Math.exp(-Math.pow((t - seat) * 40, 2));
  pos.y += slap * 0.012; rot.x += slap * 0.06;

  // ---- magazine path (weapon space, relative to rest) ----
  const mag = parts.mag;
  const rest = mag.userData.rest.p;
  const mOff = V(); let mRot = 0, visible = true, phase = 'in';
  const outEnd = tOut + 0.12, inStart = tIn - 0.12;
  // per-weapon magazine extraction path (data-driven):
  //   default  – drops out of a bottom well        (out = down, tilts forward)
  //   topLoad  – P90: rear latch, lifts up & back  (out = up/back)
  //   belt     – LMG: pouch unhooks sideways/down; feed cover opens (see below)
  //   pistol   – flush grip mag drops straight down, quick
  const R = def.reload;
  const OUT = R.topLoad ? [0, 0.09, 0.07] : R.belt ? [0.05, -0.12, 0.0] : R.pistol ? [0, -0.13, 0.01] : [0, -0.16, -0.02];
  const OUTROT = R.topLoad ? -0.35 : R.belt ? 0.0 : R.pistol ? 0.05 : 0.25;
  const STASH = R.topLoad ? [-0.12, 0.1, 0.15] : [-0.12, -0.35, 0.05];
  if (t < tOut) phase = 'in';
  else if (t < outEnd) { const u = smooth((t - tOut) / 0.12); mOff.set(OUT[0] * u, OUT[1] * u, OUT[2] * u); mRot = OUTROT * u; phase = 'pulling'; }
  else if (t < inStart) {
    const u = smooth((t - outEnd) / Math.max(0.01, inStart - outEnd));
    mOff.set(lerp(STASH[0], OUT[0], u), lerp(STASH[1], OUT[1], u), lerp(STASH[2], OUT[2], u)); mRot = lerp(OUTROT * 2.4, OUTROT, u);
    visible = u > 0.08; phase = 'swap';
  } else if (t < seat) {
    const u = smooth((t - inStart) / Math.max(0.01, seat - inStart));
    mOff.set(lerp(OUT[0], 0, u), lerp(OUT[1], 0, u), lerp(OUT[2], 0, u)); mRot = lerp(OUTROT, 0, u); phase = 'inserting';
  }
  // belt-fed: feed-tray cover opens before the pouch comes off, closes after the belt is laid
  if (R.belt && parts.cover) {
    parts.cover.rotation.x = -1.15 * sampleKeys([[0, 0], [Math.max(0.01, tOut - 0.1), 1], [seat + 0.12, 1], [Math.min(0.99, seat + 0.2), 0]], t);
    for (const r of w.model.rounds) r.visible = t < tOut - 0.05 || t > seat + 0.05;
  }
  mag.position.copy(rest).add(mOff);
  mag.rotation.set(mRot, 0, 0);
  mag.visible = visible;

  // ---- charging handle / bolt (empty reload only) ----
  let chK = 0;
  const ch = parts.slide || parts.charge || parts.bolt;
  if (empty && ch) {
    const back = sampleKeys([[0, 0], [tCh - 0.02, 0], [tCh + 0.03, 1], [tChF - 0.01, 1], [tChF + 0.01, 0]], t);
    const dist = parts.slide ? 0.035 : def.id === 'dynasty' ? 0.07 : parts.boltHandle ? 0.085 : 0.06;
    ch.position.z = ch.userData.rest.p.z + back * dist;
    if (parts.boltHandle) parts.boltHandle.rotation.z = sampleKeys([[0, 0], [tCh - 0.1, 0], [tCh - 0.03, 1.25], [tChF + 0.02, 1.25], [tChF + 0.07, 0]], t);
    chK = sampleKeys([[0, 0], [seat + 0.08, 0], [tCh - 0.04, 1], [tChF + 0.02, 1], [Math.min(0.99, tChF + 0.12), 0]], t);
  }

  // ---- support hand target ----
  const grip = w.model.sockets.leftHand.position.clone();
  const magHand = rest.clone().add(mOff).add(R.topLoad ? V(-0.03, 0.03, 0) : V(-0.03, -0.06, 0));
  const pouch = V(-0.15, -0.35, 0.15);
  const kMag = sampleKeys([[0, 0], [Math.max(0.01, tOut - 0.08), 1], [outEnd, 1], [outEnd + 0.08, 0], [inStart - 0.02, 0], [inStart + 0.02, 1], [seat + 0.04, 1], [Math.min(0.99, seat + 0.12), 0]], t);
  const kPouch = sampleKeys([[0, 0], [outEnd, 0], [outEnd + 0.08, 1], [inStart - 0.02, 1], [inStart + 0.02, 0]], t);
  const lh = grip.clone().lerp(magHand, kMag).lerp(pouch, kPouch);
  if (chK > 0 && ch) {
    const off = parts.slide ? V(0.0, 0.03, 0.0) : def.id === 'dynasty' ? V(0.05, 0.03, 0.008) : parts.boltHandle ? V(0.06, 0.024, 0.02) : ch.position.x > 0.01 ? V(0.02, 0.02, 0.01) : V(-0.02, 0.05, 0.02);
    lh.lerp(ch.position.clone().add(off), chK);
  }
  const lq = Q_GRIP.clone().slerp(Q_MAG, Math.max(kMag, kPouch)).slerp(Q_CHARGE, chK);
  return { leftHand: { pos: lh, quat: lq }, phase, timeline: T };
}

/** Shell-by-shell loading pose (Kraken top-loader). */
export function shellReloadPose(w, sl, pos, rot) {
  const R = w.def.reload;
  let k = 1;
  if (sl.phase === 'start') k = smooth(sl.t / R.start);
  else if (sl.phase === 'end') k = 1 - smooth(sl.t / R.end);
  rot.set(0.55 * k, -0.25 * k, 0.75 * k);
  pos.set(-0.05 * k, 0.06 * k, 0.03 * k);
  const u = sl.phase === 'load' ? sl.t / R.perShell : 0;
  const reach = sl.phase === 'load' ? sampleKeys([[0, 0], [0.25, 0], [0.5, 1], [0.62, 1], [0.85, 0], [1, 0]], u) : 0;
  const fromPouch = sl.phase === 'load' ? sampleKeys([[0, 1], [0.25, 1], [0.45, 0], [0.85, 0], [1, 1]], u) : 0;
  const grip = w.model.sockets.leftHand.position.clone();
  const port = V(-0.02, 0.18 - reach * 0.035, 0.055);
  const pouch = V(-0.2, -0.32, 0.12);
  const lh = grip.clone().lerp(pouch, fromPouch * (1 - reach) * (sl.phase === 'load' ? 1 : 0)).lerp(port, reach);
  const push = sl.phase === 'load' ? Math.exp(-Math.pow((u - 0.55) * 12, 2)) : 0;
  pos.y -= push * 0.008;
  const lq = qFromE(-1.2 + reach * 1.6, 0, 0.3 + reach * 0.8);
  if (w.model.parts.gate) w.model.parts.gate.rotation.x = -0.9 * (sl.phase === 'load' ? 1 : k);
  return { leftHand: { pos: lh, quat: lq, shell: reach > 0.05 && !sl.loadedThisCycle } };
}

export { Q_GRIP };
