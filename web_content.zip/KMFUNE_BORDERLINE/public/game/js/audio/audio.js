// =====================================================================
// Audio engine (Web Audio API)
// ---------------------------------------------------------------------
//  * All clips are fetched & decoded ONCE at load (no decoding in combat).
//  * Category buses: weapons / footsteps / environment / interface → master
//    → gentle compressor (prevents clipping during rapid fire).
//  * Voice limiting per category + global cap. AudioBufferSourceNodes are
//    one-shot by design (cheap); we reuse the gain/panner graph per voice
//    slot and stop the oldest voice when a cap is hit.
//  * Spatial sounds use an equal-power stereo panner + inverse distance
//    attenuation + a low-pass for distance (cheap, no HRTF convolution).
//  * Starts suspended; resumed on the first user gesture (autoplay policy).
//  * A few handling sounds are synthesised into AudioBuffers ONCE at load
//    (cloth rustle, bolt metal, dry-fire click, slide whoosh) using shaped
//    noise + resonant filters rendered offline — layered with recorded clips.
// =====================================================================
import { settings } from '../core/settings.js';

const BASE = './assets/audio/';

const MANIFEST = {
  dynasty_shot: ['weapons/dynasty_shot.ogg'],
  vanguard_shot: ['weapons/vanguard_shot.ogg'],
  ranger_shot: ['weapons/ranger_shot.ogg'],
  bigrig_shot: ['weapons/bigrig_shot.ogg'],
  kraken_shot: ['weapons/kraken_shot.ogg'],
  pdw_shot: ['weapons/pdw_shot.ogg'],
  magnum_shot: ['weapons/magnum_shot.ogg'],
  carbine_shot: ['weapons/carbine_shot.ogg'],
  battle_shot: ['weapons/battle_shot.ogg'],
  lmg_shot: ['weapons/lmg_shot.ogg'],
  pistol_shot: ['weapons/pistol_shot.ogg'],
  smg_shot: ['weapons/smg_shot.ogg'],
  mag_in: ['weapons/mag_in.ogg'],
  mag_seat: ['weapons/mag_seat.ogg'],
  pump_back: ['weapons/pump_back.ogg'],
  pump_fwd: ['weapons/pump_fwd.ogg'],
  pump_mid: ['weapons/pump_mid.ogg'],
  metal_light: [0, 1, 2, 3, 4].map((i) => `mech/impactMetal_light_00${i}.ogg`),
  metal_med: [0, 1, 2].map((i) => `mech/impactMetal_medium_00${i}.ogg`),
  plate_light: [0, 1, 2, 3, 4].map((i) => `mech/impactPlate_light_00${i}.ogg`),
  tin: [0, 1, 2].map((i) => `mech/impactTin_medium_00${i}.ogg`),
  hit_concrete: [0, 1, 2, 3, 4].map((i) => `impact/impactMining_00${i}.ogg`),
  hit_generic: [0, 1, 2, 3, 4].map((i) => `impact/impactGeneric_light_00${i}.ogg`),
  hit_bell: [0, 1, 2].map((i) => `impact/impactBell_heavy_00${i}.ogg`),
  hit_plate: [0, 1, 2].map((i) => `impact/impactPlate_heavy_00${i}.ogg`),
  hit_soft: [0, 1, 2].map((i) => `impact/impactSoft_heavy_00${i}.ogg`),
  foot: [0, 1, 2, 3, 4].map((i) => `foot/footstep_concrete_00${i}.ogg`),
  ui_click: ['ui/click_001.ogg'],
  ui_hover: ['ui/tick_001.ogg'],
  ui_select: ['ui/select_002.ogg'],
  ui_confirm: ['ui/confirmation_001.ogg'],
  ui_back: ['ui/back_001.ogg'],
  ui_switch: ['ui/switch_002.ogg'],
};

const CAPS = { weapons: 14, footsteps: 4, environment: 16, interface: 4 };
const GLOBAL_CAP = 32;

export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.buffers = new Map();   // name → AudioBuffer[]
    this.voices = [];           // {src, cat, start}
    this.ready = false;
    this.lastVariant = new Map();
    this.lastPlay = new Map();
    this.listener = { pos: [0, 0, 0], right: [1, 0, 0], fwd: [0, 0, -1] };
  }

  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC({ latencyHint: 'interactive' });
    const c = this.ctx;
    this.comp = c.createDynamicsCompressor();
    this.comp.threshold.value = -10; this.comp.knee.value = 8; this.comp.ratio.value = 4;
    this.comp.attack.value = 0.002; this.comp.release.value = 0.12;
    this.master = c.createGain();
    this.master.connect(this.comp); this.comp.connect(c.destination);
    this.buses = {};
    for (const cat of ['weapons', 'footsteps', 'environment', 'interface']) {
      const g = c.createGain(); g.connect(this.master); this.buses[cat] = g;
    }
    // ambient wind bed
    this.ambient = null;
    this.applyVolumes();
    settings.on((section) => { if (section === 'audio') this.applyVolumes(); });
  }

  applyVolumes() {
    if (!this.ctx) return;
    const a = settings.audio, t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(a.master, t, 0.02);
    this.buses.weapons.gain.setTargetAtTime(a.weapons, t, 0.02);
    this.buses.footsteps.gain.setTargetAtTime(a.footsteps, t, 0.02);
    this.buses.environment.gain.setTargetAtTime(a.environment, t, 0.02);
    this.buses.interface.gain.setTargetAtTime(a.interface, t, 0.02);
  }

  async resume() {
    if (!this.ctx) this.init();
    if (this.ctx && this.ctx.state !== 'running') { try { await this.ctx.resume(); } catch { /* ignore */ } }
  }

  async load(onProgress) {
    this.init();
    if (!this.ctx) return;
    const entries = Object.entries(MANIFEST);
    const total = entries.reduce((s, [, v]) => s + v.length, 0);
    let done = 0;
    await Promise.all(entries.map(async ([name, files]) => {
      const bufs = await Promise.all(files.map(async (f) => {
        try {
          const res = await fetch(BASE + f);
          if (!res.ok) throw new Error(res.status + ' ' + f);
          const arr = await res.arrayBuffer();
          const buf = await this.ctx.decodeAudioData(arr);
          return buf;
        } catch (e) {
          console.warn('[audio] failed to load', f, e.message);
          return null;
        } finally {
          done++; onProgress?.(done / total);
        }
      }));
      this.buffers.set(name, bufs.filter(Boolean));
    }));
    this._synthesize();
    this.ready = true;
  }

  // ---------- offline-synthesised handling sounds (rendered once) ----------
  _noiseBuffer(dur, shape, filterFn) {
    const sr = this.ctx.sampleRate, n = Math.floor(sr * dur);
    const buf = this.ctx.createBuffer(1, n, sr);
    const d = buf.getChannelData(0);
    let b0 = 0, b1 = 0;
    for (let i = 0; i < n; i++) {
      const t = i / sr;
      const white = Math.random() * 2 - 1;
      b0 = 0.85 * b0 + 0.15 * white; // simple low-pass
      b1 = white - b0;               // high-pass residue
      d[i] = (filterFn ? filterFn(white, b0, b1, t) : white) * shape(t / dur, t);
    }
    return buf;
  }
  _synthesize() {
    const sr = this.ctx.sampleRate;
    // cloth rustle: band-limited noise with slow amplitude flutter
    this.buffers.set('cloth', [0, 1].map((v) => this._noiseBuffer(0.35, (u, t) => Math.sin(Math.PI * u) * (0.5 + 0.5 * Math.sin(t * (40 + v * 13))) * 0.35, (w, lo) => lo * 1.2)));
    // whoosh (slide / weapon swing)
    this.buffers.set('whoosh', [this._noiseBuffer(0.5, (u) => Math.pow(Math.sin(Math.PI * Math.min(1, u * 1.3)), 2) * 0.5, (w, lo) => lo)]);
    // metallic click (dry fire / bolt contact): damped resonant partials + click
    const metallic = (freqs, dur, decay, amp) => {
      const n = Math.floor(sr * dur); const buf = this.ctx.createBuffer(1, n, sr); const d = buf.getChannelData(0);
      for (let i = 0; i < n; i++) {
        const t = i / sr; let s = 0;
        freqs.forEach((f, k) => { s += Math.sin(2 * Math.PI * f * t + k) * Math.exp(-t * decay * (1 + k * 0.6)) / (k + 1); });
        s += (Math.random() * 2 - 1) * Math.exp(-t * 900) * 1.5;
        d[i] = s * amp;
      }
      return buf;
    };
    this.buffers.set('dry_fire', [metallic([3100, 4870, 7200], 0.12, 60, 0.5), metallic([2900, 5200, 6900], 0.12, 70, 0.5)]);
    this.buffers.set('bolt_tick', [metallic([1800, 3300, 5100], 0.18, 35, 0.45)]);
    this.buffers.set('shell_tick', [metallic([2200, 3900], 0.1, 55, 0.4), metallic([2500, 4300], 0.1, 50, 0.4)]);
    // shell casing tinkle on concrete
    this.buffers.set('casing', [0, 1, 2].map((v) => {
      const dur = 0.35, n = Math.floor(sr * dur); const buf = this.ctx.createBuffer(1, n, sr); const d = buf.getChannelData(0);
      const f = 4200 + v * 700, bounces = [0, 0.07 + v * 0.01, 0.15 + v * 0.02];
      for (let i = 0; i < n; i++) { const t = i / sr; let s = 0; bounces.forEach((b, k) => { if (t >= b) { const tt = t - b; s += Math.sin(2 * Math.PI * f * (1 + k * 0.03) * tt) * Math.exp(-tt * 45) * (0.6 / (k + 1)); } }); d[i] = s * 0.4; }
      return buf;
    }));
    this.buffers.set('shotgun_shell_drop', [0, 1].map((v) => {
      const dur = 0.3, n = Math.floor(sr * dur); const buf = this.ctx.createBuffer(1, n, sr); const d = buf.getChannelData(0);
      for (let i = 0; i < n; i++) { const t = i / sr; let s = 0; for (const [b, a] of [[0, 1], [0.09 + v * 0.02, 0.5]]) if (t >= b) { const tt = t - b; s += (Math.random() * 2 - 1) * Math.exp(-tt * 70) * a * 0.6 + Math.sin(2 * Math.PI * (900 + v * 120) * tt) * Math.exp(-tt * 40) * a * 0.3; } d[i] = s * 0.5; }
      return buf;
    }));
    // heavy landing thump
    this.buffers.set('land', [this._noiseBuffer(0.25, (u, t) => Math.exp(-t * 18) * 0.9, (w, lo) => lo * 1.6)]);
    // slide scrape (concrete) — loopable-ish noise bed
    this.buffers.set('slide', [this._noiseBuffer(1.2, (u) => Math.min(1, u * 8) * Math.pow(1 - u, 0.6) * 0.35, (w, lo, hi) => lo * 0.7 + hi * 0.25)]);
    // ambient wind (2 s, looped)
    {
      const dur = 6, n = Math.floor(sr * dur); const buf = this.ctx.createBuffer(2, n, sr);
      for (let ch = 0; ch < 2; ch++) {
        const d = buf.getChannelData(ch); let lo = 0, lo2 = 0;
        for (let i = 0; i < n; i++) {
          const t = i / sr; const w = Math.random() * 2 - 1;
          lo = 0.985 * lo + 0.015 * w; lo2 = 0.9 * lo2 + 0.1 * lo;
          const gust = 0.55 + 0.45 * Math.sin((t / dur) * Math.PI * 2 * 2 + ch) * Math.sin((t / dur) * Math.PI * 2 * 3 + 1.3);
          d[i] = lo2 * 6 * gust;
        }
        // crossfade the loop seam
        const fade = Math.floor(sr * 0.25);
        for (let i = 0; i < fade; i++) { const k = i / fade; d[i] = d[i] * k + d[n - fade + i] * (1 - k); }
      }
      this.buffers.set('wind', [buf]);
    }
    // synthesized tails for gunshots to add a distant open-range "slap" (short, no long reverb)
    this.buffers.set('shot_tail', [this._noiseBuffer(0.6, (u, t) => Math.exp(-t * 7) * 0.25, (w, lo) => lo)]);
  }

  startAmbient() {
    if (!this.ctx || this.ambient || !this.buffers.get('wind')?.length) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.buffers.get('wind')[0]; src.loop = true;
    const g = this.ctx.createGain(); g.gain.value = 0.35;
    src.connect(g); g.connect(this.buses.environment);
    src.start();
    this.ambient = { src, g };
  }
  stopAmbient() { if (this.ambient) { try { this.ambient.src.stop(); } catch { /* */ } this.ambient = null; } }

  setListener(pos, right, fwd) {
    this.listener.pos[0] = pos.x; this.listener.pos[1] = pos.y; this.listener.pos[2] = pos.z;
    this.listener.right[0] = right.x; this.listener.right[1] = right.y; this.listener.right[2] = right.z;
    this.listener.fwd[0] = fwd.x; this.listener.fwd[1] = fwd.y; this.listener.fwd[2] = fwd.z;
  }

  _pick(name) {
    const list = this.buffers.get(name);
    if (!list || !list.length) return null;
    if (list.length === 1) return list[0];
    let i = Math.floor(Math.random() * list.length);
    if (i === this.lastVariant.get(name)) i = (i + 1) % list.length; // avoid immediate repeats
    this.lastVariant.set(name, i);
    return list[i];
  }

  // ---- voice management (allocation-free, click-free) ----
  _compact(now) {
    const v = this.voices; let j = 0;
    for (let i = 0; i < v.length; i++) if (v[i].end > now) v[j++] = v[i];
    v.length = j;
  }
  _reap(cat, group, maxGroup) {
    const now = this.ctx.currentTime;
    this._compact(now);
    // per-group cap (e.g. one weapon's gunshot): steal the oldest of that group
    if (group) {
      let n = 0, oldest = null;
      for (const v of this.voices) if (v.group === group) { n++; if (!oldest) oldest = v; }
      if (n >= maxGroup && oldest) this._kill(oldest);
    }
    let inCat = 0, oldestCat = null;
    for (const v of this.voices) if (v.cat === cat) { inCat++; if (!oldestCat) oldestCat = v; }
    if (inCat >= (CAPS[cat] ?? 8) && oldestCat) this._kill(oldestCat);
    if (this.voices.length >= GLOBAL_CAP) this._kill(this.voices[0]);
  }
  /** Fade a voice out over ~20 ms before stopping it (an abrupt stop clicks). */
  _kill(v) {
    const t = this.ctx.currentTime;
    try {
      const g = v.gain.gain;
      g.cancelScheduledValues(t);
      g.setValueAtTime(g.value, t);
      g.linearRampToValueAtTime(0, t + 0.02);
      v.src.stop(t + 0.03);
    } catch { /* already stopped */ }
    v.end = 0;
    const i = this.voices.indexOf(v);
    if (i >= 0) this.voices.splice(i, 1);
  }

  /**
   * Play a clip.
   * opts: { cat, volume, rate, rateJitter, at (Vector3 world pos), delay, offset, duration, lowpass }
   */
  play(name, opts = {}) {
    if (!this.ctx || this.ctx.state !== 'running') return null;
    const buf = this._pick(name);
    if (!buf) return null;
    const cat = opts.cat || 'weapons';
    const c = this.ctx;
    // duplicate suppression: the same clip triggered twice within minInterval
    // (e.g. two code paths on one shot) plays once
    const minI = opts.minInterval ?? 0.012;
    const last = this.lastPlay.get(name) ?? -1;
    if (c.currentTime + (opts.delay ?? 0) - last < minI) return null;
    this.lastPlay.set(name, c.currentTime + (opts.delay ?? 0));
    this._reap(cat, opts.group, opts.maxGroup ?? 99);
    const src = c.createBufferSource();
    src.buffer = buf;
    const jitter = opts.rateJitter ?? 0.04;
    src.playbackRate.value = (opts.rate ?? 1) * (1 + (Math.random() * 2 - 1) * jitter);
    const gain = c.createGain();
    let vol = opts.volume ?? 1;
    let node = src;
    if (opts.at) {
      const L = this.listener;
      const dx = opts.at.x - L.pos[0], dy = opts.at.y - L.pos[1], dz = opts.at.z - L.pos[2];
      const dist = Math.max(0.5, Math.hypot(dx, dy, dz));
      const ref = opts.refDistance ?? 3;
      vol *= Math.min(1, ref / (ref + (dist - ref) * 1.0));
      const pan = c.createStereoPanner();
      const side = (dx * L.right[0] + dy * L.right[1] + dz * L.right[2]) / dist;
      pan.pan.value = Math.max(-1, Math.min(1, side * 0.85));
      // air absorption for far sounds
      if (dist > 15) {
        const lp = c.createBiquadFilter(); lp.type = 'lowpass';
        lp.frequency.value = Math.max(1200, 18000 - dist * 120);
        node.connect(lp); node = lp;
      }
      node.connect(pan); node = pan;
    }
    if (opts.lowpass) { const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = opts.lowpass; node.connect(lp); node = lp; }
    if (opts.highpass) { const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = opts.highpass; node.connect(hp); node = hp; }
    const when = c.currentTime + (opts.delay ?? 0);
    // 1.5 ms attack ramp → no DC-step click at the start of a clip
    gain.gain.setValueAtTime(0, when);
    gain.gain.linearRampToValueAtTime(vol, when + 0.0015);
    node.connect(gain); gain.connect(this.buses[cat]);
    const offset = opts.offset ?? 0;
    const dur = opts.duration ?? (buf.duration - offset);
    src.start(when, offset, dur);
    const v = { src, gain, cat, group: opts.group || null, end: when + dur / src.playbackRate.value + 0.05 };
    src.onended = () => { v.end = 0; };
    this.voices.push(v);
    return v;
  }

  ui(name) { this.play(name, { cat: 'interface', volume: 0.7, rateJitter: 0.02 }); }

  // Composite named weapon-handling cues → layered clips
  cue(name, at) {
    const o = { cat: 'weapons' };
    switch (name) {
      case 'mag_out': this.play('metal_light', { ...o, volume: 0.35, rate: 1.25 }); this.play('mag_seat', { ...o, volume: 0.5, rate: 0.8 }); break;
      case 'mag_in': this.play('mag_in', { ...o, volume: 0.85 }); break;
      case 'mag_seat': this.play('mag_seat', { ...o, volume: 0.9 }); this.play('metal_light', { ...o, volume: 0.25, rate: 1.5 }); break;
      case 'bolt_back': this.play('pump_back', { ...o, volume: 0.55, rate: 1.35 }); this.play('bolt_tick', { ...o, volume: 0.35 }); break;
      case 'bolt_fwd': this.play('pump_fwd', { ...o, volume: 0.6, rate: 1.4 }); this.play('bolt_tick', { ...o, volume: 0.45, rate: 0.9 }); break;
      case 'bolt_up': this.play('bolt_tick', { ...o, volume: 0.4, rate: 1.2 }); break;
      case 'bolt_down': this.play('bolt_tick', { ...o, volume: 0.45, rate: 0.85 }); this.play('metal_light', { ...o, volume: 0.2 }); break;
      case 'pump_back': this.play('pump_back', { ...o, volume: 0.85 }); break;
      case 'pump_fwd': this.play('pump_fwd', { ...o, volume: 0.9 }); break;
      case 'shell_in': this.play('pump_mid', { ...o, volume: 0.55, rate: 1.4 }); this.play('shell_tick', { ...o, volume: 0.4 }); break;
      case 'cloth': this.play('cloth', { ...o, volume: 0.4 }); break;
      case 'dry_fire': this.play('dry_fire', { ...o, volume: 0.6 }); break;
      case 'equip': this.play('cloth', { ...o, volume: 0.5 }); this.play('metal_light', { ...o, volume: 0.25, rate: 0.9, delay: 0.12 }); break;
      case 'unequip': this.play('whoosh', { ...o, volume: 0.25, rate: 1.4 }); break;
      case 'firemode': this.play('bolt_tick', { ...o, volume: 0.4, rate: 1.5 }); break;
      default: this.play(name, { ...o, at });
    }
  }
}

export const audio = new AudioEngine();
