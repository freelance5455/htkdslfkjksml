/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : IG-1-1-2 */
registerLessonDetail(1, 1, "ig-1-1-2", {
  title: "Leçon 2 : Systèmes de numération, Complément à 2 et Codage",
  duration: "50 min (Manuel complet)",
  objectives: [
    "Expliquer pourquoi le matériel informatique repose physiquement sur la base 2 (binaire).",
    "Maîtriser la forme polynomiale en base b et convertir rigoureusement entre bases 10, 2, 8 et 16.",
    "Distinguer correctement les unités décimales (Ko, Mo, Go) des unités binaires (Kio, Mio, Gio).",
    "Représenter les entiers négatifs en binaire grâce au Complément à 2.",
    "Comprendre le codage alphanumérique (ASCII, ISO-8859-1, UTF-8) et ses enjeux de compatibilité."
  ],
  prerequisites: ["Leçon 1 (Architecture mémoire), division euclidienne et puissances de 2."],
  sections: [
    {
      type: "theory",
      title: "1. Pourquoi l'ordinateur compte-t-il uniquement avec 0 et 1 ?",
      text: "À l'intérieur d'un microprocesseur moderne, des milliards de transistors microscopiques (gravés à quelques nanomètres) agissent comme des interrupteurs électroniques ultra-rapides. Tenter de distinguer dix niveaux de tension électrique différents (0V, 0,5V, 1V... jusqu'à 4,5V) pour représenter les chiffres 0 à 9 provoquerait d'énormes erreurs dès qu'un échauffement ou un parasite électromagnétique ferait légèrement varier la tension.\n\nEn choisissant uniquement deux états largement séparés — tension basse (symbole 0) et tension haute (symbole 1) — les ingénieurs rendent les circuits logiques pratiquement insensibles au bruit électrique. C'est le fondement physique du système binaire (base 2)."
    },
    {
      type: "definition",
      term: "Bit, Quartet, Octet et Capacité de codage",
      text: "• Bit (binary digit) : la plus petite unité d'information possible (0 ou 1).\n• Quartet (Nibble) : groupe de 4 bits (permet 2^4 = 16 combinaisons, exactement 1 chiffre hexadécimal).\n• Octet (Byte en anglais, noté o ou B) : groupe de 8 bits (2^8 = 256 combinaisons possibles, de 0 à 255).\n\nRègle universelle : avec n bits, on peut représenter exactement 2^n valeurs distinctes (de 0 à 2^n - 1 pour des entiers positifs)."
    },
    {
      type: "theory",
      title: "2. Principe mathématique de la numération positionnelle (Base b)",
      text: "Dans toute base b (où les chiffres vont de 0 à b - 1), la valeur d'un nombre s'obtient par sa décomposition polynomiale : chaque chiffre est multiplié par une puissance de la base b selon son rang (en commençant par le rang 0 tout à droite).\n\nExemple en base 10 : 472 = (4 × 10^2) + (7 × 10^1) + (2 × 10^0) = 400 + 70 + 2.\nEn base 2 (binaire), il n'existe que deux chiffres (0 et 1), et les puissances successives de droite à gauche valent : 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024.\nEn base 16 (hexadécimal), il faut 16 symboles : on utilise 0..9 puis les lettres A=10, B=11, C=12, D=13, E=14, F=15."
    },
    {
      type: "code",
      lang: "Méthodes complètes de conversion pas à pas",
      code: [
        "1) BINAIRE → DÉCIMAL : Convertir 11010110 (base 2)",
        "   Poids :  128   64   32   16    8    4    2    1",
        "   Bits  :    1    1    0    1    0    1    1    0",
        "   Somme : 128 + 64 + 0 + 16 + 0 + 4 + 2 + 0 = 214 (base 10)",
        "",
        "2) DÉCIMAL → BINAIRE (Divisions successives par 2) : Convertir 156",
        "   156 ÷ 2 = 78  reste 0  (bit de poids faible, tout à droite)",
        "    78 ÷ 2 = 39  reste 0",
        "    39 ÷ 2 = 19  reste 1",
        "    19 ÷ 2 =  9  reste 1",
        "     9 ÷ 2 =  4  reste 1",
        "     4 ÷ 2 =  2  reste 0",
        "     2 ÷ 2 =  1  reste 0",
        "     1 ÷ 2 =  0  reste 1  (bit de poids fort, tout à gauche)",
        "   Lecture de bas en haut : 10011100 (base 2)",
        "",
        "3) BINAIRE ↔ HEXADÉCIMAL (Règle d'or : paquets de 4 bits depuis la droite)",
        "   Pourquoi ? Parce que 16 = 2^4 !",
        "   Exemple : 1001 1100",
        "   - Paquet gauche : 1001 = 8 + 1 = 9",
        "   - Paquet droit  : 1100 = 8 + 4 = 12 = C",
        "   Résultat immédiat : 9C (base 16), noté souvent 0x9C en C/Python/JS !"
      ].join("\n")
    },
    {
      type: "theory",
      title: "3. Représenter les nombres négatifs : le Complément à 2",
      text: "Comment stocker -25 en mémoire alors qu'un ordinateur ne connaît ni le signe '+' ni le signe '-' ? Une première idée naïve consisterait à réserver le bit tout à gauche comme bit de signe (0 = positif, 1 = négatif). Mais cela crée deux zéros (+0 et -0) et complique les circuits d'addition.\n\nLes ordinateurs modernes utilisent tous le « Complément à 2 » sur n bits (ex. 8 bits, 32 bits). Avec cette méthode, le bit le plus à gauche porte un poids négatif (-128 sur 8 bits), et l'addition fonctionne directement avec les mêmes circuits électroniques pour les positifs et les négatifs !\n\nPour trouver l'opposé (-X) d'un entier X sur 8 bits :\n1) Écrire X sur 8 bits.\n2) Inverser tous les bits (Complément à 1 : les 0 deviennent 1, les 1 deviennent 0).\n3) Ajouter 1 en binaire.",
      bullets: [
        "Exemple : Coder -25 sur 8 bits.",
        "Étape 1 : +25 = 0001 1001",
        "Étape 2 (inversion) : 1110 0110",
        "Étape 3 (+ 1) : 1110 0111  →  (-128 + 64 + 32 + 4 + 2 + 1 = -25 !)",
        "Plage possible sur 8 bits signés : de -128 à +127 (soit 256 valeurs)."
      ]
    },
    {
      type: "table",
      title: "4. Unités de mesure et Codage des textes (ASCII vers UTF-8)",
      headers: ["Norme / Unité", "Valeur exacte / Taille", "Usage concret"],
      rows: [
        ["1 Ko vs 1 Kio", "1 Ko = 1000 o | 1 Kio = 1024 o", "Disques vendus en Go (10^9), mais OS mesurant souvent en Gio (2^30)."],
        ["ASCII (1963)", "7 bits (128 symboles : 0 à 127)", "Chiffres, lettres non accentuées ('A'=65, 'a'=97, Espace=32)."],
        ["ISO-8859-1 (Latin-1)", "8 bits (256 symboles)", "Ajoute é, è, ç, à mais incompatible hors Europe occidentale."],
        ["UTF-8 (Unicode)", "Variable : 1 à 4 octets", "Standard universel du Web : compatible ASCII sur 1 octet, gère toutes les langues et émojis."]
      ]
    },
    {
      type: "warning",
      title: "Pièges fréquents à éviter",
      text: "1) Attention à la casse entre « b » et « B » : 100 Mb/s (Mégabits/s) sur votre connexion 4G ou Wi-Fi équivaut à 100 ÷ 8 = 12,5 Mo/s (Mégaoctets/s) de téléchargement réel ! Un octet = 8 bits.\n2) En UTF-8, un fichier contenant uniquement des lettres anglaises pèse 1 octet par caractère, mais les lettres accentuées (é, è, à) pèsent 2 octets et les émojis 4 octets.\n3) En binaire sur 8 bits non signés, le maximum est 255 (1111 1111) : ajouter 1 provoque un dépassement de capacité (Overflow) ramenant le compteur à 0000 0000 !"
    },
    {
      type: "example",
      title: "Pourquoi les développeurs Web adorent l'hexadécimal pour les couleurs",
      text: "Dans le code CSS de JOSTECH, une couleur comme #12161F contient 3 octets écrits en hexadécimal : Rouge = 12 (soit 18/255), Vert = 16 (soit 22/255), Bleu = 1F (soit 31/255). Au lieu d'écrire 24 bits illisibles (000100100001011000011111), l'hexadécimal résume l'information en 6 caractères clairs !"
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Conversions multi-bases",
      question: "1) Convertissez le nombre décimal 197 en binaire sur 8 bits, puis en hexadécimal.\n2) Convertissez le nombre hexadécimal 3A (base 16) en binaire puis en décimal.",
      solution: "1) 197 = 128 + 64 + 4 + 1 = 1100 0101 (base 2).\n   Groupes de 4 bits : 1100 = 12 = C ; 0101 = 5 → C5 (base 16).\n2) 3A (16) : 3 = 0011 et A (10) = 1010 → 0011 1010 (base 2).\n   En décimal : (3 × 16) + 10 = 48 + 10 = 58 (base 10)."
    },
    {
      title: "Exercice 2 — Complément à 2 (Entiers signés)",
      question: "Codez l'entier négatif -42 en Complément à 2 sur 8 bits. Vérifiez ensuite votre résultat en additionnant binaire(+42) + binaire(-42).",
      solution: "+42 = 32 + 8 + 2 = 0010 1010.\nInversion (Complément à 1) : 1101 0101.\nAjouter 1 : 1101 0101 + 1 = 1101 0110.\nVérification : 0010 1010 + 1101 0110 = 1 0000 0000. En ignorant la retenue qui sort du 8e bit, on obtient bien 0000 0000 (zéro) !"
    },
    {
      title: "Exercice 3 — Débit réseau et capacité de stockage",
      question: "Vous téléchargez un cours vidéo optionnel de 90 Mo avec une connexion 4G affichant un débit de 24 Mb/s (Mégabits par seconde). Combien de secondes faudra-t-il au minimum ?",
      solution: "Attention à l'unité ! 24 Mb/s = 24 ÷ 8 = 3 Mo/s (Mégaoctets par seconde).\nTemps minimum = 90 Mo ÷ 3 Mo/s = 30 secondes."
    }
  ],
  summary: "Toute donnée informatique finit en suite de bits (0 et 1). L'hexadécimal offre aux informaticiens une lecture condensée du binaire (1 chiffre = 4 bits). Le Complément à 2 permet de manipuler les nombres négatifs sans changer les circuits d'addition, et UTF-8 assure l'encodage universel de tous les textes du monde.",
  references: [
    "Tanenbaum, A. S. — Architecture de l'ordinateur (Annexe A : Systèmes de numération).",
    "Delannoy, C. — Initiation à l'architecture et au codage binaire.",
    "Unicode Consortium — The Unicode Standard / UTF-8 Specification."
  ]
});