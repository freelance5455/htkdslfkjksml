
/* =====================================================================
   موتور بازی: تم‌ها، رندر بوم، دونده، منطق مرحله‌ها
   ===================================================================== */
const $ = id => document.getElementById(id);
const cv = $('scene'), ctx = cv.getContext('2d');
const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
let W = 0, H = 0, DPR = 1, groundY = 400;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, k) => a + (b - a) * k;
const hsh = (i, s = 0) => { const x = Math.sin(i * 127.1 + s * 311.7) * 43758.5453; return x - Math.floor(x); };
const TAU = Math.PI * 2;

/* ---------- تم‌ها (هر ۶۰ ثانیه خودکار عوض می‌شوند) ---------- */
const THEME_SECONDS = 60;
const THEMES = [
  { name: 'غروب نئونی', sky: ['#12053a', '#4a0f8c', '#c2287f', '#ff8a5b'], sun: { t: 'sun', x: .7, y: .62, r: .27, c1: '#ffe86b', c2: '#ff3d8a', stripes: true },
    layers: [{ k: 'mount', col: '#3b1a78', b: .86, a: .42, p: .05, s: 140 }, { k: 'mount', col: '#2a1058', b: .95, a: .30, p: .12, s: 90 }],
    ground: ['#1d0a40', '#0b0420'], line: '#ff4fd8', part: ['sparks', '#ff7be8'], ui: ['#ff4fd8', '#4ff0ff', 'rgba(20,6,52,.66)'] },
  { name: 'جنگل جادویی', sky: ['#06251f', '#0e5b4a', '#3aa57a', '#c9f0a8'], sun: { t: 'moon', x: .25, y: .38, r: .17, c1: '#f6ffe0', c2: '#cdeab2' },
    layers: [{ k: 'trees', col: '#0b3d33', b: .98, h: .5, p: .08, sp: 38 }, { k: 'trees', col: '#07281f', b: 1, h: .72, p: .2, sp: 54 }, { k: 'trees', col: '#041a14', b: 1.04, h: 1.0, p: .45, sp: 120 }],
    ground: ['#0c3a22', '#05160d'], line: '#9bff7a', part: ['fireflies', '#e8ff72'], ui: ['#7dff9b', '#fff27a', 'rgba(4,28,22,.68)'] },
  { name: 'فضای دور', sky: ['#02010a', '#0a0a3a', '#251a6b'], stars: true, sun: { t: 'planet', x: .74, y: .42, r: .28, c1: '#f4b36a', c2: '#8b3d2a' },
    layers: [{ k: 'mount', col: '#171046', b: .95, a: .22, p: .04, s: 160 }, { k: 'mount', col: '#0f0a30', b: 1, a: .18, p: .1, s: 100 }],
    ground: ['#1a0f4a', '#07041a'], line: '#7b8cff', part: ['warp', '#bcd0ff'], ui: ['#8b7bff', '#4ff0ff', 'rgba(6,4,30,.72)'] },
  { name: 'اقیانوس', sky: ['#0a3a6b', '#1b86c9', '#5ed3f3', '#d4f7ff'], sun: { t: 'sun', x: .3, y: .5, r: .2, c1: '#fff7c2', c2: '#ffd66b' },
    layers: [{ k: 'wave', col: '#1a73b8', b: .88, a: .05, p: .06, s: 120, sp: .8 }, { k: 'wave', col: '#0f5a96', b: .95, a: .06, p: .14, s: 90, sp: 1.2 }, { k: 'wave', col: '#0b4676', b: 1.02, a: .07, p: .3, s: 70, sp: 1.7 }],
    ground: ['#0a4a7a', '#04233f'], line: '#9ef6ff', part: ['bubbles', '#d4f7ff'], ui: ['#4ff0ff', '#ffe86b', 'rgba(4,28,60,.68)'] },
  { name: 'صحرای طلایی', sky: ['#3b1d5a', '#d6495e', '#ff9a4d', '#ffe08a'], sun: { t: 'sun', x: .6, y: .58, r: .3, c1: '#fff3b0', c2: '#ffb347' },
    layers: [{ k: 'dune', col: '#c25a4a', b: .88, a: .22, p: .05, s: 220 }, { k: 'dune', col: '#a8443d', b: .96, a: .22, p: .12, s: 170 }, { k: 'dune', col: '#7a2f35', b: 1.02, a: .2, p: .25, s: 130 }],
    cacti: '#173d2c', ground: ['#6a2a30', '#2c0f16'], line: '#ffd27a', part: ['dust', '#ffd9a0'], ui: ['#ffb347', '#ff5e8a', 'rgba(48,14,24,.68)'] },
  { name: 'شهر شبانه', sky: ['#030818', '#0b1a4a', '#2a2f82', '#6b4fa8'], stars: true, sun: { t: 'moon', x: .8, y: .36, r: .14, c1: '#fff8e0', c2: '#e6dcc0' },
    layers: [{ k: 'build', col: '#0d1640', b: 1, hm: .7, p: .06, step: 64 }, { k: 'build', col: '#101c52', b: 1, hm: .85, p: .15, step: 82, win: '#ffe27a' }, { k: 'build', col: '#070d2c', b: 1.02, hm: 1.0, p: .32, step: 120, win: '#7be8ff' }],
    ground: ['#0b1030', '#04061a'], line: '#4ff0ff', part: ['sparks', '#4ff0ff'], ui: ['#4ff0ff', '#ff4fd8', 'rgba(4,8,30,.72)'] },
  { name: 'سرزمین یخی', sky: ['#2a4a8a', '#6fa8e6', '#bfe3ff', '#f2fbff'], sun: { t: 'sun', x: .25, y: .46, r: .17, c1: '#ffffff', c2: '#e6f6ff' },
    layers: [{ k: 'mount', col: '#9cc4ec', b: .86, a: .4, p: .05, s: 150 }, { k: 'mount', col: '#7aa8d8', b: .95, a: .3, p: .12, s: 100 }, { k: 'mount', col: '#4f82b8', b: 1.02, a: .24, p: .25, s: 70 }],
    ground: ['#e9f6ff', '#a9cdef'], line: '#ffffff', part: ['snow', '#ffffff'], ui: ['#7fd4ff', '#ffffff', 'rgba(10,32,72,.7)'] }
];

/* ---------- حالت صحنه ---------- */
let themeIdx = 0, themeClock = 0, fade = 1, fadeT = 0;
let curS = null, prevS = null;
let worldX = 0, speed = 240, speedTarget = 240, time = 0;
const mode = { name: 'start' };
const targets = { start: { gy: .72, rx: .5 }, map: { gy: .3, rx: .18 }, play: { gy: .42, rx: .27 } };
const runner = { x: 0, s: 1, phase: 0, anim: null, dash: 0 };
const symbols = [], bursts = [];
const SYM = ['∈', '∪', '∩', '⊂', '∅', 'ℕ', 'ℤ', 'ℚ', '½', '∉', '⊆', '∞', '⅓', '%'];

function makeState(T) {
  const n = reduceMotion ? 24 : 60, parts = [];
  for (let i = 0; i < n; i++) parts.push({ x: Math.random(), y: Math.random(), v: .3 + Math.random() * .7, s: .5 + Math.random(), ph: Math.random() * TAU });
  const stars = []; if (T.stars) for (let i = 0; i < 90; i++) stars.push({ x: Math.random(), y: Math.random(), s: Math.random() * 1.6 + .4, ph: Math.random() * TAU });
  return { T, parts, stars };
}
function applyUI(T) {
  const r = document.documentElement.style;
  r.setProperty('--accent', T.ui[0]); r.setProperty('--accent2', T.ui[1]); r.setProperty('--glass', T.ui[2]);
  $('themeName').textContent = T.name;
}
function setTheme(i, announce) {
  prevS = curS; themeIdx = i % THEMES.length; curS = makeState(THEMES[themeIdx]);
  fade = prevS ? 0 : 1; fadeT = 0; themeClock = 0; applyUI(THEMES[themeIdx]);
  if (announce) { toast('🎨 تم جدید: ' + THEMES[themeIdx].name); sfx('theme'); }
}
let toastTimer;
function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('on'), 2400); }

function resize() {
  DPR = Math.min(window.devicePixelRatio || 1, 2); W = innerWidth; H = innerHeight;
  cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR); ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  runner.s = clamp(H / 760, .72, 1.3);
  if (!runner.x) { groundY = H * targets[mode.name].gy; runner.x = W * targets[mode.name].rx; }
  if (!symbols.length) for (let i = 0; i < (reduceMotion ? 6 : 14); i++) symbols.push({ x: Math.random(), y: Math.random() * .7, v: .2 + Math.random() * .5, sz: 22 + Math.random() * 30, ph: Math.random() * TAU, ch: SYM[i % SYM.length] });
}
addEventListener('resize', resize);

/* ---------- رسم لایه‌ها ---------- */
function drawMount(L, off) {
  const base = groundY * L.b, amp = groundY * L.a;
  ctx.fillStyle = L.col; ctx.beginPath(); ctx.moveTo(0, groundY + 2);
  for (let x = 0; x <= W + 8; x += 8) {
    const u = (x + off) / L.s;
    const n = Math.abs(Math.sin(u * 1.3 + 1)) * .6 + Math.abs(Math.sin(u * 2.9 + 2)) * .3 + Math.abs(Math.sin(u * .5)) * .5;
    ctx.lineTo(x, base - n * amp);
  }
  ctx.lineTo(W, groundY + 2); ctx.closePath(); ctx.fill();
}
function drawDune(L, off) {
  ctx.fillStyle = L.col; ctx.beginPath(); ctx.moveTo(0, groundY + 2);
  for (let x = 0; x <= W + 10; x += 10) { const u = (x + off) / L.s; const n = Math.sin(u) * .5 + Math.sin(u * 2.3 + 1.7) * .25 + .75; ctx.lineTo(x, groundY * L.b - n * groundY * L.a); }
  ctx.lineTo(W, groundY + 2); ctx.closePath(); ctx.fill();
}
function drawWave(L, off, tm) {
  ctx.fillStyle = L.col; ctx.beginPath(); ctx.moveTo(0, groundY + 2);
  for (let x = 0; x <= W + 10; x += 10) { const u = (x + off) / L.s; ctx.lineTo(x, groundY * L.b - (Math.sin(u + tm * L.sp) * .5 + .6) * groundY * L.a); }
  ctx.lineTo(W, groundY + 2); ctx.closePath(); ctx.fill();
}
function drawBuild(L, off) {
  const st = L.step, i0 = Math.floor(off / st) - 1, n = Math.ceil(W / st) + 3, by = groundY * L.b;
  for (let k = 0; k < n; k++) {
    const i = i0 + k, w = st * (.55 + hsh(i, 1) * .35), h = groundY * L.hm * (.35 + hsh(i, 2) * .6), x = i * st - off, y = by - h;
    ctx.fillStyle = L.col; ctx.fillRect(x, y, w, h + 2);
    if (L.win) {
      ctx.fillStyle = L.win; ctx.globalAlpha *= .8;
      for (let wy = y + 8, ry = 0; wy < by - 8; wy += 14, ry++) for (let wx = x + 6, cx = 0; wx < x + w - 8; wx += 12, cx++) if (hsh(i * 17 + cx, ry + 5) > .55) ctx.fillRect(wx, wy, 6, 7);
      ctx.globalAlpha /= .8;
    }
  }
}
function drawTrees(L, off) {
  const sp = L.sp, i0 = Math.floor(off / sp) - 1, n = Math.ceil(W / sp) + 3, by = groundY * L.b;
  ctx.fillStyle = L.col;
  for (let k = 0; k < n; k++) {
    const i = i0 + k, x = i * sp - off + hsh(i, 3) * sp * .4, h = groundY * L.h * (.6 + hsh(i, 4) * .55), w = h * .5;
    ctx.fillRect(x - 3, by - h * .26, 6, h * .26 + 2);
    for (let j = 0; j < 3; j++) {
      const ay = by - h * (1 - j * .22), bY = by - h * (.62 - j * .18), hw = w * (.5 + j * .18);
      ctx.beginPath(); ctx.moveTo(x, ay); ctx.lineTo(x - hw, bY); ctx.lineTo(x + hw, bY); ctx.closePath(); ctx.fill();
    }
  }
}
function drawCacti(col, off) {
  const sp = 420, i0 = Math.floor(off / sp) - 1, n = Math.ceil(W / sp) + 3, s = runner.s;
  ctx.fillStyle = col; ctx.strokeStyle = col; ctx.lineCap = 'round';
  for (let k = 0; k < n; k++) {
    const i = i0 + k; if (hsh(i, 9) < .35) continue;
    const x = i * sp - off + hsh(i, 8) * 160, h = (55 + hsh(i, 7) * 40) * s;
    ctx.lineWidth = 12 * s; ctx.beginPath(); ctx.moveTo(x, groundY + 4); ctx.lineTo(x, groundY - h); ctx.stroke();
    ctx.lineWidth = 8 * s; ctx.beginPath(); ctx.moveTo(x, groundY - h * .45); ctx.lineTo(x - 18 * s, groundY - h * .45); ctx.lineTo(x - 18 * s, groundY - h * .75); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x, groundY - h * .6); ctx.lineTo(x + 16 * s, groundY - h * .6); ctx.lineTo(x + 16 * s, groundY - h * .88); ctx.stroke();
  }
}
function drawCelestial(S) {
  const c = S.T.sun, x = W * c.x, y = groundY * c.y + Math.sin(time * .4) * 4, r = groundY * c.r;
  if (c.t === 'sun') {
    const g = ctx.createRadialGradient(x, y, r * .5, x, y, r * 2.6); g.addColorStop(0, c.c2 + 'aa'); g.addColorStop(1, c.c2 + '00');
    ctx.fillStyle = g; ctx.fillRect(x - r * 3, y - r * 3, r * 6, r * 6);
    const d = ctx.createLinearGradient(0, y - r, 0, y + r); d.addColorStop(0, c.c1); d.addColorStop(1, c.c2);
    ctx.fillStyle = d; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    if (c.stripes) {
      ctx.save(); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.clip(); ctx.fillStyle = S.T.sky[1];
      for (let i = 0; i < 6; i++) { const yy = y + r * (.05 + i * .17), hh = 2 + i * 1.8; ctx.fillRect(x - r, yy, r * 2, hh); }
      ctx.restore();
    }
  } else if (c.t === 'moon') {
    const g = ctx.createRadialGradient(x, y, r * .8, x, y, r * 2.2); g.addColorStop(0, 'rgba(255,255,230,.35)'); g.addColorStop(1, 'rgba(255,255,230,0)');
    ctx.fillStyle = g; ctx.fillRect(x - r * 3, y - r * 3, r * 6, r * 6);
    ctx.fillStyle = c.c1; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,.08)'; [[-.3, -.2, .22], [.25, .1, .16], [-.05, .4, .12]].forEach(q => { ctx.beginPath(); ctx.arc(x + q[0] * r, y + q[1] * r, q[2] * r, 0, TAU); ctx.fill(); });
  } else {
    const d = ctx.createRadialGradient(x - r * .35, y - r * .35, r * .1, x, y, r); d.addColorStop(0, c.c1); d.addColorStop(1, c.c2);
    ctx.save(); ctx.translate(x, y); ctx.rotate(-.35);
    ctx.strokeStyle = 'rgba(255,225,170,.55)'; ctx.lineWidth = r * .16; ctx.beginPath(); ctx.ellipse(0, 0, r * 1.7, r * .4, 0, Math.PI, TAU); ctx.stroke();
    ctx.fillStyle = d; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,225,170,.8)'; ctx.beginPath(); ctx.ellipse(0, 0, r * 1.7, r * .4, 0, 0, Math.PI); ctx.stroke();
    ctx.restore();
  }
}
function drawGround(T) {
  const g = ctx.createLinearGradient(0, groundY, 0, H); g.addColorStop(0, T.ground[0]); g.addColorStop(1, T.ground[1]);
  ctx.fillStyle = g; ctx.fillRect(0, groundY, W, H - groundY + 2);
  ctx.save(); ctx.strokeStyle = T.line; ctx.globalAlpha *= .22; ctx.lineWidth = 1.5;
  const sp = 90, sh = worldX % sp, vx = W * .5;
  for (let x = -sh - sp; x < W + sp * 3; x += sp) { ctx.beginPath(); ctx.moveTo(x, groundY); ctx.lineTo(vx + (x - vx) * 3.4, H); ctx.stroke(); }
  for (let k = 1; k <= 7; k++) { const y = groundY + (H - groundY) * Math.pow(k / 7, 1.8); ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
  ctx.restore();
  ctx.save(); ctx.strokeStyle = T.line; ctx.lineWidth = 3; ctx.shadowColor = T.line; ctx.shadowBlur = 14;
  ctx.beginPath(); ctx.moveTo(0, groundY); ctx.lineTo(W, groundY); ctx.stroke(); ctx.restore();
}
function drawParts(S, dt) {
  const [type, col] = S.T.part, ps = S.parts; ctx.fillStyle = col; ctx.strokeStyle = col;
  for (const p of ps) {
    if (type === 'snow') { p.y += dt * .08 * p.v * 3; p.x += Math.sin(time + p.ph) * dt * .02 - speed * dt / W * .15 * p.v; if (p.y > 1) p.y = -.02; if (p.x < -.02) p.x = 1.02; ctx.globalAlpha = .85; ctx.beginPath(); ctx.arc(p.x * W, p.y * H, 1.5 + p.s * 1.8, 0, TAU); ctx.fill(); }
    else if (type === 'bubbles') { p.y -= dt * .07 * p.v; p.x -= speed * dt / W * .1 * p.v; if (p.y < -.03) { p.y = 1.02; p.x = Math.random(); } if (p.x < -.02) p.x = 1.02; ctx.globalAlpha = .5; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(p.x * W + Math.sin(time * 2 + p.ph) * 6, p.y * H, 3 + p.s * 5, 0, TAU); ctx.stroke(); }
    else if (type === 'fireflies') { p.x += Math.sin(time * .7 + p.ph) * dt * .03 - speed * dt / W * .12 * p.v; p.y += Math.cos(time * .9 + p.ph) * dt * .02; if (p.x < -.02) p.x = 1.02; const px = p.x * W, py = (.15 + p.y * .75) * H, a = .35 + .65 * Math.abs(Math.sin(time * 2 + p.ph)); ctx.globalAlpha = a; const g = ctx.createRadialGradient(px, py, 0, px, py, 14 * p.s); g.addColorStop(0, col); g.addColorStop(1, 'rgba(232,255,114,0)'); ctx.fillStyle = g; ctx.fillRect(px - 16, py - 16, 32, 32); ctx.fillStyle = col; }
    else if (type === 'dust') { p.x -= speed * dt / W * .5 * p.v; if (p.x < -.05) { p.x = 1.05; p.y = Math.random(); } ctx.globalAlpha = .25 * p.v; ctx.beginPath(); ctx.ellipse(p.x * W, (.2 + p.y * .8) * H, 10 + p.s * 14, 1.5 + p.s, 0, 0, TAU); ctx.fill(); }
    else if (type === 'warp') { p.x -= speed * dt / W * (.4 + p.v) * 1.3; if (p.x < -.1) { p.x = 1.1; p.y = Math.random(); } ctx.globalAlpha = .35 * p.v; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(p.x * W, p.y * groundY * 1.1); ctx.lineTo(p.x * W + 30 + speed * .1 * p.v, p.y * groundY * 1.1); ctx.stroke(); }
    else { p.y -= dt * .05 * p.v; p.x -= speed * dt / W * .2 * p.v; if (p.y < -.03) { p.y = 1.02; p.x = Math.random(); } if (p.x < -.02) p.x = 1.02; ctx.globalAlpha = .55 * Math.abs(Math.sin(time * 2 + p.ph)); const z = 2 + p.s * 2.4; ctx.fillRect(p.x * W, p.y * H, z, z); }
  }
  ctx.globalAlpha = 1;
}
function drawTheme(S, alpha, dt) {
  const T = S.T; ctx.save(); ctx.globalAlpha = alpha;
  const g = ctx.createLinearGradient(0, 0, 0, groundY); T.sky.forEach((c, i) => g.addColorStop(i / (T.sky.length - 1), c));
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, groundY + 1);
  if (S.stars.length) { ctx.fillStyle = '#fff'; for (const s of S.stars) { ctx.globalAlpha = alpha * (.4 + .6 * Math.abs(Math.sin(time * 1.5 + s.ph))); const sx = ((s.x * W - worldX * .01) % W + W) % W; ctx.fillRect(sx, s.y * groundY * .95, s.s, s.s); } ctx.globalAlpha = alpha; }
  drawCelestial(S);
  for (const L of T.layers) {
    const off = worldX * L.p;
    if (L.k === 'mount') drawMount(L, off); else if (L.k === 'dune') drawDune(L, off); else if (L.k === 'wave') drawWave(L, off, time);
    else if (L.k === 'build') drawBuild(L, off); else if (L.k === 'trees') drawTrees(L, off);
  }
  drawGround(T);
  if (T.cacti) drawCacti(T.cacti, worldX);
  drawParts(S, dt);
  ctx.restore();
}
function drawSymbols(dt) {
  ctx.save(); ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (const s of symbols) {
    s.x -= (speed * .035 + 6 * s.v) * dt / W; if (s.x < -.06) { s.x = 1.06; s.y = Math.random() * .7; }
    const y = (s.y * groundY * 1.1) + Math.sin(time * .8 + s.ph) * 10;
    ctx.globalAlpha = .13 + .08 * Math.sin(time + s.ph); ctx.font = `800 ${s.sz}px Georgia,'Cambria Math',serif`;
    ctx.save(); ctx.translate(s.x * W, y); ctx.rotate(Math.sin(time * .5 + s.ph) * .3); ctx.fillText(s.ch, 0, 0); ctx.restore();
  }
  ctx.restore();
}

/* ---------- دونده ---------- */
function drawRunner() {
  const s = runner.s, x = runner.x, gy = groundY, a = runner.anim, T = THEMES[themeIdx], ph = runner.phase;
  let lift = 0, rot = 0, shake = 0, state = 'run';
  if (a) {
    const u = clamp(a.t / a.dur, 0, 1); state = a.type;
    if (a.type === 'jump') { lift = Math.sin(Math.PI * u) * 95 * s; rot = u * TAU; }
    else if (a.type === 'stumble') { rot = Math.sin(u * Math.PI) * .6; shake = Math.sin(u * 45) * (1 - u) * 4; lift = Math.sin(Math.PI * u) * 12 * s; }
    else if (a.type === 'cheer') { lift = Math.abs(Math.sin(u * Math.PI * 4)) * 46 * s; }
  }
  const suit = T.ui[1], accent = T.ui[0], skin = '#ffcfa6', pants = '#1d1f4d';
  /* سایه */
  ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(x, gy + 5, Math.max(10, 34 * s - lift * .22), 7 * s, 0, 0, TAU); ctx.fill();
  /* هاله هنگام دویدن سریع */
  if (runner.dash > 0 || state === 'jump') {
    const g = ctx.createRadialGradient(x, gy - 50 * s - lift, 5, x, gy - 50 * s - lift, 85 * s); g.addColorStop(0, suit + '88'); g.addColorStop(1, suit + '00');
    ctx.fillStyle = g; ctx.fillRect(x - 100 * s, gy - 150 * s - lift, 200 * s, 200 * s);
  }
  /* محاسبهٔ پاها */
  const hipY = -42 * s, U = 21 * s;
  const leg = p => { const th = Math.sin(p) * .95, sh = th - (1 + Math.cos(p)) * .55, kx = Math.sin(th) * U, ky = hipY + Math.cos(th) * U; return { kx, ky, fx: kx + Math.sin(sh) * U, fy: ky + Math.cos(sh) * U }; };
  const pA = state === 'cheer' ? 0 : ph, la = leg(pA), lb = leg(pA + Math.PI);
  const drop = state === 'stumble' ? 0 : -Math.max(la.fy, lb.fy);
  ctx.save(); ctx.translate(x + shake, gy - lift + drop);
  ctx.translate(0, -48 * s); ctx.rotate(rot); ctx.translate(0, 48 * s);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const limb = (x0, y0, x1, y1, x2, y2, w, col) => { ctx.strokeStyle = col; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); };
  const shoe = (l, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(l.fx + 4 * s, l.fy + 1 * s, 10 * s, 5.5 * s, 0, 0, TAU); ctx.fill(); ctx.fillStyle = accent; ctx.fillRect(l.fx - 5 * s, l.fy + 4 * s, 18 * s, 2.4 * s); };
  const lean = 7 * s, sx = lean, sy = hipY - 30 * s;
  const arm = (p, col) => { const ang = Math.sin(p) * 1.1, ex = sx + Math.sin(ang) * 15 * s, ey = sy + 3 * s + Math.cos(ang) * 15 * s, a2 = ang + .9 + Math.max(0, Math.sin(p)) * .4; const hx = ex + Math.sin(a2) * 14 * s, hy = ey + Math.cos(a2) * 14 * s; limb(sx, sy + 3 * s, ex, ey, hx, hy, 8 * s, col); ctx.fillStyle = skin; ctx.beginPath(); ctx.arc(hx, hy, 4.6 * s, 0, TAU); ctx.fill(); };
  const armP = state === 'cheer' ? -2.2 : ph + Math.PI;
  /* پشت */
  arm(armP + Math.PI, 'rgba(255,255,255,.55)');
  limb(0, hipY, lb.kx, lb.ky, lb.fx, lb.fy, 10 * s, '#12143a'); shoe(lb, '#e8e8f4');
  /* تنه */
  ctx.strokeStyle = suit; ctx.lineWidth = 25 * s; ctx.beginPath(); ctx.moveTo(0, hipY + 2 * s); ctx.lineTo(sx, sy); ctx.stroke();
  ctx.strokeStyle = accent; ctx.lineWidth = 4 * s; ctx.beginPath(); ctx.moveTo(-9 * s, hipY - 6 * s); ctx.lineTo(sx - 8 * s, sy + 10 * s); ctx.stroke();
  /* جلو */
  limb(0, hipY, la.kx, la.ky, la.fx, la.fy, 10.5 * s, pants); shoe(la, '#fff');
  /* روسری */
  ctx.strokeStyle = accent; ctx.lineWidth = 7 * s; ctx.beginPath(); ctx.moveTo(sx - 2 * s, sy - 3 * s);
  const wob = state === 'stumble' ? 0 : 1;
  for (let i = 1; i <= 7; i++) ctx.lineTo(sx - i * 9 * s, sy - 3 * s + Math.sin(time * 11 - i * .8) * 4 * s * wob * (i / 7) + i * 1.2 * s);
  ctx.stroke();
  /* سر */
  const hx = sx + 4 * s, hy = sy - 18 * s;
  ctx.fillStyle = skin; ctx.beginPath(); ctx.arc(hx, hy, 15 * s, 0, TAU); ctx.fill();
  ctx.fillStyle = '#2b1b3d'; ctx.beginPath(); ctx.arc(hx - 1 * s, hy - 2 * s, 15.5 * s, Math.PI * 1.05, Math.PI * 2.05); ctx.fill();
  ctx.beginPath(); ctx.moveTo(hx - 12 * s, hy - 6 * s); ctx.quadraticCurveTo(hx - 24 * s, hy - 2 * s + Math.sin(time * 9) * 3 * s, hx - 20 * s, hy + 8 * s); ctx.lineTo(hx - 10 * s, hy + 2 * s); ctx.fill();
  ctx.strokeStyle = accent; ctx.lineWidth = 4 * s; ctx.beginPath(); ctx.moveTo(hx - 14 * s, hy - 3 * s); ctx.lineTo(hx + 14 * s, hy - 5 * s); ctx.stroke();
  ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(hx + 6 * s, hy + 2 * s, 3.6 * s, 0, TAU); ctx.fill();
  ctx.fillStyle = '#1b1030'; ctx.beginPath(); ctx.arc(hx + 7.2 * s, hy + 2.2 * s, 1.9 * s, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#a04a3a'; ctx.lineWidth = 1.8 * s; ctx.beginPath();
  if (state === 'stumble') ctx.arc(hx + 6 * s, hy + 11 * s, 3.5 * s, Math.PI * 1.1, Math.PI * 1.9); else ctx.arc(hx + 5 * s, hy + 7 * s, 4.5 * s, .15, Math.PI * .8);
  ctx.stroke();
  arm(armP, suit);
  if (state === 'stumble') { ctx.fillStyle = '#ffd54a'; for (let i = 0; i < 3; i++) { const q = time * 6 + i * 2.1; ctx.save(); ctx.translate(hx + Math.cos(q) * 22 * s, hy - 20 * s + Math.sin(q) * 6 * s); ctx.rotate(q); star(0, 0, 5 * s); ctx.restore(); } }
  ctx.restore();
  /* خطوط سرعت */
  if (speed > 420) { ctx.save(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; for (let i = 0; i < 7; i++) { const yy = gy - (14 + i * 15) * s - lift * .5, len = 40 + hsh(i, Math.floor(time * 12)) * 60; ctx.globalAlpha = .4 * (1 - i / 8); ctx.beginPath(); ctx.moveTo(x - 38 * s, yy); ctx.lineTo(x - 38 * s - len, yy); ctx.stroke(); } ctx.restore(); }
}
function star(x, y, r) { ctx.beginPath(); for (let i = 0; i < 10; i++) { const rr = i % 2 ? r * .45 : r, a = -Math.PI / 2 + i * Math.PI / 5; ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } ctx.closePath(); ctx.fill(); }

/* ---------- ذرات جشن ---------- */
function burst(x, y, kind, n) {
  const T = THEMES[themeIdx], cols = ['#ffd54a', T.ui[0], T.ui[1], '#ffffff', '#3ee08f'];
  for (let i = 0; i < n; i++) bursts.push({ x, y, vx: (Math.random() - .5) * (kind === 'conf' ? 700 : 380), vy: -Math.random() * (kind === 'conf' ? 600 : 420) - 120, g: kind === 'conf' ? 520 : 900, life: 1.1 + Math.random() * .8, age: 0, kind, rot: Math.random() * TAU, vr: (Math.random() - .5) * 14, col: kind === 'coin' ? '#ffd54a' : cols[i % cols.length], sz: 4 + Math.random() * 6 });
}
function drawBursts(dt) {
  for (let i = bursts.length - 1; i >= 0; i--) {
    const b = bursts[i]; b.age += dt; if (b.age > b.life) { bursts.splice(i, 1); continue; }
    b.vy += b.g * dt; b.x += b.vx * dt; b.y += b.vy * dt; b.rot += b.vr * dt;
    ctx.save(); ctx.globalAlpha = clamp(1 - (b.age / b.life) ** 3, 0, 1); ctx.translate(b.x, b.y); ctx.rotate(b.rot); ctx.fillStyle = b.col;
    if (b.kind === 'coin') { ctx.scale(Math.abs(Math.cos(b.age * 9)) + .15, 1); ctx.beginPath(); ctx.arc(0, 0, b.sz + 3, 0, TAU); ctx.fill(); ctx.strokeStyle = '#b8860b'; ctx.lineWidth = 1.6; ctx.stroke(); }
    else if (b.kind === 'conf') ctx.fillRect(-b.sz / 2, -b.sz / 4, b.sz, b.sz / 2); else if (b.kind === 'star') star(0, 0, b.sz + 2); else { ctx.beginPath(); ctx.arc(0, 0, b.sz / 2, 0, TAU); ctx.fill(); }
    ctx.restore();
  }
}
function popText(txt, col) {
  const d = document.createElement('div'); d.className = 'pop'; d.textContent = txt; d.style.color = col || '#ffd54a';
  d.style.left = runner.x + 'px'; d.style.top = (groundY - 130 * runner.s) + 'px'; document.body.appendChild(d); setTimeout(() => d.remove(), 1200);
}

/* ---------- حلقهٔ اصلی ---------- */
let last = performance.now();
const RING = 59.7;
function frame(now) {
  const dt = Math.min((now - last) / 1000, .05); last = now; time += dt;
  themeClock += dt; if (themeClock >= THEME_SECONDS) setTheme(themeIdx + 1, true);
  if (fade < 1) { fadeT += dt; fade = clamp(fadeT / 1.6, 0, 1); if (fade >= 1) prevS = null; }
  const tg = targets[mode.name]; groundY = lerp(groundY, H * tg.gy, 1 - Math.pow(.001, dt)); runner.x = lerp(runner.x, W * tg.rx, 1 - Math.pow(.003, dt));
  if (runner.dash > 0) runner.dash -= dt;
  speed = lerp(speed, speedTarget, 1 - Math.pow(.02, dt)); if (runner.dash > 0) speedTarget = 760; else if (runner.anim && runner.anim.type === 'stumble') speedTarget = 70; else speedTarget = mode.name === 'start' ? 300 : 240;
  worldX += speed * dt; runner.phase += dt * (6 + speed / 40);
  if (runner.anim) { runner.anim.t += dt; if (runner.anim.t >= runner.anim.dur) runner.anim = null; }
  $('ringFg').style.strokeDashoffset = String(RING * (themeClock / THEME_SECONDS));
  ctx.clearRect(0, 0, W, H);
  if (prevS && fade < 1) { drawTheme(prevS, 1, dt); drawTheme(curS, fade, dt); } else drawTheme(curS, 1, dt);
  drawSymbols(dt); drawRunner(); drawBursts(dt);
  requestAnimationFrame(frame);
}

/* ---------- صدا ---------- */
let AC = null, soundOn = true;
function tone(f, d, type, v, delay, to) {
  const t0 = AC.currentTime + (delay || 0), o = AC.createOscillator(), g = AC.createGain();
  o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0); if (to) o.frequency.exponentialRampToValueAtTime(to, t0 + d);
  g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(v || .12, t0 + .015); g.gain.exponentialRampToValueAtTime(.0001, t0 + d);
  o.connect(g); g.connect(AC.destination); o.start(t0); o.stop(t0 + d + .05);
}
function sfx(k) {
  if (!soundOn) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume();
    if (k === 'ok') { tone(660, .12, 'triangle', .13); tone(990, .2, 'triangle', .13, .09); }
    else if (k === 'no') tone(220, .35, 'sawtooth', .1, 0, 90);
    else if (k === 'win') [523, 659, 784, 1047, 1318].forEach((f, i) => tone(f, .25, 'triangle', .13, i * .1));
    else if (k === 'lose') [392, 330, 262].forEach((f, i) => tone(f, .3, 'sine', .12, i * .16));
    else if (k === 'theme') tone(300, .5, 'sine', .08, 0, 900);
    else tone(520, .06, 'square', .05);
  } catch (e) { }
}

/* ---------- منطق بازی ---------- */
const save = { max: 1, score: 0 };
const attempts = {};
const S = { level: 1, q: [], i: 0, res: [], locked: false, streak: 0, cur: null };
const LETTERS = ['الف', 'ب', 'ج', 'د'];
const PRAISE = ['آفرین! 🎯', 'درسته! 🔥', 'عالی بود! ⭐', 'دمت گرم! 💪', 'همینه! 🚀', 'نابغه‌ای! 🧠'];
const stripTags = h => h.replace(/<[^>]+>/g, '');

async function loadSave() { try { if (window.storage) { const r = await window.storage.get('mojmoo-save', false); if (r && r.value) { const d = JSON.parse(r.value); save.max = clamp(d.max | 0, 1, 50); save.score = d.score | 0; } } } catch (e) { } }
async function writeSave() { try { if (window.storage) await window.storage.set('mojmoo-save', JSON.stringify(save), false); } catch (e) { } }

function show(name) {
  mode.name = name;
  ['start', 'map', 'play'].forEach(n => $(n).classList.toggle('on', n === name));
  $('hud').classList.toggle('on', name !== 'start');
}
function updateHUD() {
  $('lvlTxt').innerHTML = `<small>${stageOf(S.level).name}</small><b>مرحلهٔ ${fa(S.level)} از ${fa(50)}</b>`;
  $('score').textContent = fa(save.score);
  $('combo').textContent = S.streak >= 2 ? `🔥×${fa(S.streak)}` : '';
}
function renderMap() {
  let h = `<h2>نقشهٔ مرحله‌ها</h2><small style="opacity:.8">تا مرحلهٔ ${fa(save.max)} باز شده</small>`;
  for (const st of STAGES) {
    h += `<div class="stg"><b>${st.name}</b><small>مرحلهٔ ${fa(st.from)} تا ${fa(st.to)}</small></div><div class="grid">`;
    for (let L = st.from; L <= st.to; L++) {
      const cls = L < save.max ? 'done' : L === save.max ? 'cur' : 'lock', boss = L % 10 === 0 ? ' boss' : '';
      h += `<button class="node ${cls}${boss}" data-l="${L}" ${L > save.max ? 'disabled' : ''} aria-label="مرحلهٔ ${fa(L)}">${L % 10 === 0 && L > save.max ? '👑' : fa(L)}</button>`;
    }
    h += '</div>';
  }
  h += `<div style="margin-top:18px;text-align:center"><button class="btn ghost" id="mapBack" style="min-height:46px;font-size:1rem">بازگشت به صفحهٔ اول</button></div>`;
  $('mapPanel').innerHTML = h;
  $('mapPanel').querySelectorAll('.node:not(.lock)').forEach(b => b.onclick = () => { sfx('click'); startLevel(+b.dataset.l); });
  $('mapBack').onclick = () => { sfx('click'); show('start'); };
  const cur = $('mapPanel').querySelector('.node.cur'); if (cur) setTimeout(() => cur.scrollIntoView({ block: 'center', behavior: reduceMotion ? 'auto' : 'smooth' }), 60);
}
function openMap() { renderMap(); show('map'); updateHUD(); }
function startLevel(L) {
  S.level = L; S.i = 0; S.res = []; S.streak = 0; S.q = genLevel(L, attempts[L] || 0);
  $('result').classList.remove('on'); show('play'); updateHUD();
  const st = stageOf(L), boss = L % 10 === 0;
  $('introB').textContent = boss ? `👑 مرحلهٔ ${fa(L)}` : `مرحلهٔ ${fa(L)}`; $('introS').textContent = boss ? 'مرحلهٔ باس — ' + st.name : st.name;
  const el = $('intro'); el.classList.remove('show'); void el.offsetWidth; el.classList.add('show');
  $('stageName').textContent = st.name; renderQuestion();
}
function renderDots() {
  $('dots').innerHTML = [0, 1, 2, 3].map(i => `<i class="${S.res[i] === true ? 'ok' : S.res[i] === false ? 'no' : i === S.i ? 'cur' : ''}"></i>`).join('');
}
function renderQuestion() {
  const q = S.q[S.i]; S.cur = q; S.locked = false; renderDots();
  const card = $('card'); card.style.animation = 'none'; void card.offsetWidth; card.style.animation = '';
  $('qtext').innerHTML = q.q;
  const long = Math.max(...q.opts.map(o => stripTags(o).length)) > 24;
  const o = $('opts'); o.className = long ? 'one' : ''; o.classList.remove('opts-locked');
  o.innerHTML = q.opts.map((t, i) => `<button class="opt" data-i="${i}"><span class="k">${LETTERS[i]}</span><span>${t}</span></button>`).join('');
  o.querySelectorAll('.opt').forEach(b => b.onclick = () => choose(+b.dataset.i));
  const fb = $('fb'); fb.className = ''; fb.innerHTML = ''; card.scrollTop = 0;
}
function choose(i) {
  if (S.locked) return; S.locked = true;
  const q = S.cur, ok = i === q.ans, btns = [...$('opts').children];
  $('opts').classList.add('opts-locked');
  btns.forEach((b, k) => { if (k === q.ans) b.classList.add('ok'); else if (k === i) b.classList.add('no'); else b.classList.add('dim'); });
  S.res[S.i] = ok; renderDots();
  const fb = $('fb');
  if (ok) {
    S.streak++; const gain = 10 + Math.min(S.streak - 1, 5) * 3; save.score += gain; updateHUD();
    runner.anim = { type: 'jump', t: 0, dur: .75 }; runner.dash = 1; burst(runner.x, groundY - 70 * runner.s, 'coin', 14); burst(runner.x, groundY - 70 * runner.s, 'star', 6);
    popText('+' + fa(gain)); sfx('ok');
    fb.className = 'show'; fb.innerHTML = PRAISE[Math.floor(Math.random() * PRAISE.length)];
    setTimeout(next, 1150);
  } else {
    S.streak = 0; updateHUD(); runner.anim = { type: 'stumble', t: 0, dur: 1.1 }; sfx('no');
    if (!reduceMotion) { const c = $('card'); c.classList.remove('shake'); void c.offsetWidth; c.classList.add('shake'); }
    fb.className = 'show'; fb.innerHTML = `<b style="color:var(--gold)">پاسخ درست: </b>${q.opts[q.ans]}<br>${q.exp}<button class="nx" id="nx">ادامه</button>`;
    $('nx').onclick = next; $('nx').focus({ preventScroll: true }); $('card').scrollTop = $('card').scrollHeight;
  }
}
function next() {
  if (!S.locked) return; S.locked = false; $('fb').className = ''; $('fb').innerHTML = '';
  S.i++; if (S.i < 4) renderQuestion(); else finishLevel();
}
function finishLevel() {
  const good = S.res.filter(Boolean).length, win = good === 4, L = S.level, last = L === 50;
  renderDots();
  $('resDots').innerHTML = S.res.map(r => `<i class="${r ? 'ok' : 'no'}">${r ? '✓' : '✕'}</i>`).join('');
  const btns = $('resBtns');
  if (win) {
    const bonus = 50 + (L % 10 === 0 ? 100 : 0); save.score += bonus; if (L === save.max && !last) save.max = L + 1; writeSave(); updateHUD();
    attempts[L] = 0; runner.anim = { type: 'cheer', t: 0, dur: 2.4 }; runner.dash = 1.4; sfx('win');
    for (let k = 0; k < 6; k++) setTimeout(() => burst(Math.random() * W, H * .2, 'conf', 26), k * 220);
    $('resIcon').textContent = last ? '🏆' : L % 10 === 0 ? '👑' : '🎉';
    $('resTitle').textContent = last ? 'قهرمان مجموعه‌ها شدی!' : 'مرحله رو گرفتی!';
    $('resText').innerHTML = last ? `هر ۵۰ مرحله تموم شد!<br>امتیاز نهایی: <b>${fa(save.score)}</b> ⭐` : `هر ۴ سؤال درست بود! <b>+${fa(bonus)}</b> امتیاز جایزه گرفتی.`;
    btns.innerHTML = (last ? '' : `<button class="btn main" id="rNext">مرحلهٔ ${fa(L + 1)}</button>`) + `<button class="btn ghost" id="rMap">نقشهٔ مرحله‌ها</button>`;
    if (!last) $('rNext').onclick = () => { sfx('click'); startLevel(L + 1); };
  } else {
    attempts[L] = (attempts[L] || 0) + 1; runner.anim = { type: 'stumble', t: 0, dur: 1.1 }; sfx('lose');
    $('resIcon').textContent = '💪'; $('resTitle').textContent = `${fa(good)} از ${fa(4)} درست`;
    $('resText').innerHTML = 'برای رفتن به مرحلهٔ بعد باید هر ۴ سؤال رو درست جواب بدی.<br>این بار سؤال‌های تازه می‌گیری!';
    btns.innerHTML = `<button class="btn main" id="rRetry">دوباره امتحان کن</button><button class="btn ghost" id="rMap">نقشهٔ مرحله‌ها</button>`;
    $('rRetry').onclick = () => { sfx('click'); startLevel(L); };
  }
  $('rMap').onclick = () => { sfx('click'); $('result').classList.remove('on'); openMap(); };
  setTimeout(() => $('result').classList.add('on'), 650);
}

/* ---------- رویدادها ---------- */
$('btnStart').onclick = () => { sfx('click'); startLevel(save.max); };
$('btnOpenMap').onclick = () => { sfx('click'); openMap(); };
$('btnMap').onclick = () => { sfx('click'); $('result').classList.remove('on'); openMap(); };
$('btnSnd').onclick = () => { soundOn = !soundOn; $('btnSnd').textContent = soundOn ? '🔊' : '🔇'; if (soundOn) sfx('click'); };
$('themeChip').onclick = () => setTheme(themeIdx + 1, true);
addEventListener('keydown', e => {
  const map = { '1': 0, '2': 1, '3': 2, '4': 3, '۱': 0, '۲': 1, '۳': 2, '۴': 3 };
  if (mode.name === 'play' && !$('result').classList.contains('on')) {
    if (e.key in map && !S.locked) choose(map[e.key]);
    else if ((e.key === 'Enter' || e.key === ' ') && S.locked && $('nx')) { e.preventDefault(); next(); }
  }
});

/* ---------- شروع ---------- */
resize(); setTheme(0, false); mode.name = 'start'; groundY = H * targets.start.gy; runner.x = W * targets.start.rx;
loadSave().then(() => { if (save.max > 1) $('btnStart').textContent = `ادامه — مرحلهٔ ${fa(save.max)}`; updateHUD(); });
requestAnimationFrame(frame);
</script>
</body>
</html>
