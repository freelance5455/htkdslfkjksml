/* =====================================================================
   موتور تولید سوال — ۵۰ مرحله × ۴ سوال، بر اساس فصل «مجموعه‌ها و احتمال»
   ===================================================================== */
const FA = '۰۱۲۳۴۵۶۷۸۹';
const fa = x => String(x).replace(/-/g, '−').replace(/\d/g, d => FA[+d]);
const M = s => `<span class="ms">${s}</span>`;
const range = (a, b) => { const o = []; for (let i = a; i <= b; i++) o.push(i); return o; };
const srt = a => a.slice().sort((x, y) => x - y);
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const RI = (r, a, b) => a + Math.floor(r() * (b - a + 1));
const RP = (r, a) => a[Math.floor(r() * a.length)];
const RS = (r, a) => { const x = a.slice(); for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1));[x[i], x[j]] = [x[j], x[i]]; } return x; };
const RSm = (r, a, n) => RS(r, a).slice(0, n);
const gcd = (a, b) => b ? gcd(b, a % b) : a;
const isPrime = n => n > 1 && range(2, Math.floor(Math.sqrt(n))).every(d => n % d);
const divisors = n => range(1, n).filter(d => n % d === 0);

const body = a => a.map(fa).join('، ');
const setS = a => a.length ? `{${body(a)}}` : '∅';
const SH = a => M(setS(a));
const SHd = a => M(`{${body(a)}، ...}`);
const uni = (a, b) => srt([...new Set([...a, ...b])]);
const inter = (a, b) => srt(a.filter(x => b.includes(x)));
const diff = (a, b) => srt(a.filter(x => !b.includes(x)));

function frH(n, d) {
  if (n === 0) return M('۰');
  const g = gcd(n, d); n /= g; d /= g;
  return d === 1 ? M(fa(n)) : `<span class="fr"><i>${fa(n)}</i><i>${fa(d)}</i></span>`;
}
function probOpts(r, k, N) {
  const c = [k + 1, k - 1, k + 2, k - 2, N - k, k + 3, k - 3, k * 2, Math.floor(k / 2), 1, N, 0]
    .filter((v, i, a) => v >= 0 && v <= N && v !== k && a.indexOf(v) === i);
  return RS(r, c).slice(0, 3).map(v => frH(v, N));
}
const numW = (ans, c) => [...new Set(c.filter(v => v !== ans && v >= 0))].map(fa);

function build(r, q, correct, wrongs, exp) {
  const seen = new Set([correct]), w = [];
  for (const x of RS(r, wrongs)) { if (!seen.has(x)) { seen.add(x); w.push(x); if (w.length === 3) break; } }
  if (w.length < 3) throw new Error('few wrongs: ' + q);
  const opts = RS(r, [correct, ...w]);
  return { q, opts, ans: opts.indexOf(correct), exp: exp || '' };
}

/* ---------- نمودار ون ---------- */
function vennSVG(oa, both, ob) {
  const place = (cx, cy, arr, twoCols) => {
    const n = arr.length, cols = twoCols && n > 3 ? 2 : 1, rows = Math.ceil(n / cols);
    return arr.map((v, j) => {
      const col = j % cols, row = Math.floor(j / cols);
      const x = cx + (cols === 2 ? (col ? 15 : -15) : 0);
      const y = cy - (rows - 1) * 10 + row * 20 + 5;
      return `<text x="${x}" y="${y}" text-anchor="middle">${fa(v)}</text>`;
    }).join('');
  };
  return `<div class="venn"><svg viewBox="0 0 300 150" role="img" aria-label="نمودار ون">
    <circle cx="112" cy="78" r="62" fill="rgba(79,240,255,.16)" stroke="#4ff0ff" stroke-width="2.5"/>
    <circle cx="188" cy="78" r="62" fill="rgba(255,106,213,.16)" stroke="#ff6ad5" stroke-width="2.5"/>
    <text x="52" y="22" fill="#4ff0ff" font-weight="800" font-size="17">A</text>
    <text x="248" y="22" fill="#ff6ad5" font-weight="800" font-size="17">B</text>
    <g fill="#fff" font-size="15" font-weight="700">${place(86, 78, oa, true)}${place(150, 78, both, false)}${place(214, 78, ob, true)}</g>
  </svg></div>`;
}

function makeAB(r, t) {
  const hi = 14 + Math.floor(t * 10), k1 = t > .6 ? 4 : 3;
  const pool = RS(r, range(1, hi));
  const nb = RI(r, 2, k1), na = RI(r, 2, k1), nB = RI(r, 2, k1);
  const both = srt(pool.slice(0, nb)), oa = srt(pool.slice(nb, nb + na)), ob = srt(pool.slice(nb + na, nb + na + nB));
  return { both, oa, ob, A: srt([...both, ...oa]), B: srt([...both, ...ob]) };
}
const opCands = S => ({ u: uni(S.A, S.B), i: inter(S.A, S.B), ab: diff(S.A, S.B), ba: diff(S.B, S.A), sd: uni(diff(S.A, S.B), diff(S.B, S.A)), a: S.A, b: S.B });
const OPN = { u: 'A ∪ B', i: 'A ∩ B', ab: 'A − B', ba: 'B − A' };
const OPE = {
  u: 'اجتماع یعنی همهٔ عضوهایی که حداقل در یکی از دو مجموعه‌اند (بدون تکرار).',
  i: 'اشتراک یعنی عضوهای مشترک هر دو مجموعه.',
  ab: 'A − B یعنی عضوهای A که در B نیستند.',
  ba: 'B − A یعنی عضوهای B که در A نیستند.'
};
const ABhtml = S => `<div class="sets">${M('A = ' + setS(S.A))}<br>${M('B = ' + setS(S.B))}</div>`;

const G = {};

/* ================= مرحلهٔ آشنایی ================= */
G.member = (r, t) => {
  const A = srt(RSm(r, range(1, 12 + Math.floor(t * 8)), RI(r, 4, 5)));
  const out = range(1, 20).filter(x => !A.includes(x));
  const a = RP(r, A), [b1, b2] = RSm(r, out, 2);
  return build(r, `اگر ${M('A = ' + setS(A))} باشد، کدام عبارت درست است؟`,
    M(`${fa(a)} ∈ A`), [M(`${fa(b1)} ∈ A`), M(`${fa(b2)} ∈ A`), M(`${fa(a)} ∉ A`)],
    `${fa(a)} یکی از اعضای A است؛ پس ${M(fa(a) + ' ∈ A')}.`);
};
G.count = (r, t) => {
  const n = RI(r, 3, 5 + (t > .5 ? 1 : 0));
  const base = RSm(r, range(1, 9), n), extra = RSm(r, base, RI(r, 1, 3));
  const list = RS(r, [...base, ...extra]);
  return build(r, `مجموعهٔ ${M('A = ' + setS(list))} چند عضو دارد؟`, fa(n),
    numW(n, [list.length, n + 1, n - 1, list.length + 1, n + 2]),
    `تکرار عضو، مجموعهٔ جدیدی نمی‌سازد؛ عضوهای متمایز: ${M(setS(srt(base)))} ⇒ ${fa(n)} عضو.`);
};
G.primeDiv = (r, t) => {
  const NL = [12, 18, 20, 24, 28, 30, 36, 40, 42, 45, 48, 50, 60, 66, 70, 72, 84, 90, 105];
  const n = RP(r, NL.slice(0, 6 + Math.floor(t * 40)));
  const D = divisors(n), P = D.filter(isPrime), C = D.filter(d => !isPrime(d) && d > 1);
  const wr = [SH(srt([...P, RP(r, C)])), SH([1, ...P]), P.length > 1 ? SH(P.slice(0, -1)) : SH(srt([...P, n])), SH(D)];
  return build(r, `مجموعهٔ شمارنده‌های اول عدد ${fa(n)} کدام است؟`, SH(P), wr,
    `شمارنده‌های ${fa(n)}: ${M(setS(D))}؛ فقط اول‌ها: ${SH(P)}.`);
};
G.divCount = (r, t) => {
  const NL = [12, 18, 20, 24, 28, 30, 36, 40, 45, 48, 50, 60, 72, 100];
  const n = RP(r, NL.slice(0, 5 + Math.floor(t * 40)));
  const D = divisors(n), k = D.length;
  return build(r, `عدد ${fa(n)} چند شمارندهٔ طبیعی دارد؟`, fa(k), numW(k, [k + 1, k - 1, k + 2, k - 2, D.filter(isPrime).length]),
    `شمارنده‌ها: ${M(setS(D))} ⇒ ${fa(k)} عدد.`);
};
const OKSET = [
  'عددهای طبیعی زوج کوچک‌تر از ۱۰', 'شمارنده‌های اول عدد ۳۰', 'عددهای اول کوچک‌تر از ۲۰', `عددهای صحیح بین ${M('−۳')} و ۲`,
  'مضرب‌های طبیعی عدد ۴ که کوچک‌تر از ۲۰ باشند', 'عددهای طبیعی یک‌رقمی', 'حروف کلمهٔ «ریاضی»', 'عددهای طبیعی بین ۱۰ و ۱۴',
  `جواب‌های معادلهٔ ${M('۳x = ۱۲')}`, 'شمارنده‌های طبیعی عدد ۱۲'];
const BADSET = ['چهار شاعر ایرانی', 'پنج عدد بزرگ', 'سه شهر ایران', 'چهار میوهٔ خوشمزه', 'عددهای نزدیک به ۱۰۰',
  '۵ عدد طبیعی که بین ۱ و ۲۰ قرار داشته باشند', 'چند ورزشکار معروف', 'چند عدد کوچک', 'غذاهای خوشمزهٔ ایرانی', 'سه عدد طبیعی زوج'];
G.isSet = (r) => {
  if (r() < .45) {
    return build(r, 'کدام عبارت یک مجموعه را <b>مشخص نمی‌کند</b>؟', RP(r, BADSET), RSm(r, OKSET, 3),
      'مجموعه باید کاملاً معین و بدون تکرار باشد؛ در این عبارت معلوم نیست دقیقاً چه چیزهایی عضو هستند.');
  }
  return build(r, 'کدام عبارت یک مجموعه را <b>مشخص می‌کند</b>؟', RP(r, OKSET), RSm(r, BADSET, 3),
    'عضوهای این عبارت کاملاً معین‌اند؛ بقیه به سلیقه یا برداشت بستگی دارند.');
};
G.emptyQ = (r) => {
  const k = RI(r, 2, 20);
  return build(r, 'کدام عبارت، <b>مجموعهٔ تهی</b> را مشخص می‌کند؟',
    `عددهای طبیعی بین ${fa(k)} و ${fa(k + 1)}`,
    [`عددهای طبیعی بین ${fa(k)} و ${fa(k + 2)}`, 'عددهای اول و زوج', `عددهای صحیح بین ${M('−۱')} و ۱`, 'عددهای طبیعی یک‌رقمی که مضرب ۳ و اول باشند'],
    `بین ${fa(k)} و ${fa(k + 1)} هیچ عدد طبیعی نیست. ولی «اول و زوج» = ${M('{۲}')} و «صحیح بین ${M('−۱')} و ۱» = ${M('{۰}')} است.`);
};
G.emptyTrick = (r) => {
  const items = [['{∅}', 1, '∅ خودش یک عضو است.'], ['{ }', 0, 'در این مجموعه عضوی نیست.'], ['{۰}', 1, 'عدد صفر یک عضو است.'],
    ['{∅، ۰}', 2, 'دو عضو دارد: ∅ و ۰.'], ['{∅، {∅}}', 2, 'دو عضو دارد: ∅ و {∅}.']];
  const [txt, n, e] = RP(r, items);
  return build(r, `مجموعهٔ ${M(txt)} چند عضو دارد؟`, fa(n), numW(n, [0, 1, 2, 3]), e);
};

/* ================= برابری و نمایش ================= */
G.equal = (r) => {
  const A = srt(RSm(r, range(1, 12), RI(r, 3, 4)));
  const out = range(1, 15).filter(x => !A.includes(x));
  const sh = a => M(setS(RS(r, a)));
  const correct = sh([...A, RP(r, A)]);
  const rep = RP(r, A);
  const wr = [sh([...A.filter(x => x !== rep), RP(r, out)]), sh(A.filter(x => x !== rep)), sh([...A, RP(r, out)]), sh([...A.slice(0, -1), RP(r, out)])];
  return build(r, `کدام مجموعه با ${M('A = ' + setS(A))} برابر است؟`, correct, wr,
    'ترتیب نوشتن و تکرار عضوها مهم نیست؛ دو مجموعه وقتی برابرند که عضوهایشان دقیقاً یکی باشد.');
};
G.equalFind = (r) => {
  const P = RSm(r, range(1, 12), 3), x = P[1];
  const left = RS(r, [P[0], 'x', P[2]]);
  return build(r, `اگر ${M(setS(left) + ' = ' + setS(RS(r, P)))} باشد، x چند است؟`, fa(x),
    numW(x, [P[0], P[2], x + 1, x - 1, x + 2]).concat([fa(x + 3)]),
    `دو مجموعه برابرند؛ عضو باقی‌مانده ${fa(x)} است.`);
};
G.builder = (r) => {
  const a = RI(r, 1, 8), b = a + RI(r, 3, 5), incl = r() < .5;
  const el = incl ? range(a, b) : range(a + 1, b - 1);
  const cond = incl ? `${fa(a)} ≤ x ≤ ${fa(b)}` : `${fa(a)} < x < ${fa(b)}`;
  const wr = incl ? [range(a + 1, b - 1), range(a, b - 1), range(a + 1, b)] : [range(a, b), range(a, b - 1), range(a + 1, b)];
  return build(r, `مجموعهٔ ${M('{x ∈ ℕ | ' + cond + '}')} را با عضوهایش بنویسید.`, SH(el), wr.map(SH),
    `${incl ? 'علامت ≤ یعنی دو سر هم شامل می‌شوند.' : 'علامت < یعنی دو سر شامل نمی‌شوند.'} پاسخ: ${SH(el)}.`);
};
const lin = (p, q) => `${fa(p)}k${q > 0 ? ' + ' + fa(q) : q < 0 ? ' − ' + fa(-q) : ''}`;
G.rule = (r) => {
  const p = RI(r, 2, 6), q = RI(r, -1, 4);
  const L = (s, step, off) => range(0, 3).map(i => step * (s + i) + off);
  const correct = L(1, p, q);
  const wr = [L(0, p, q), L(1, p, q + 1), L(1, p + 1, q), L(1, p, q - 1), L(2, p, q)];
  return build(r, `اولین عضوهای مجموعهٔ ${M('{' + lin(p, q) + ' | k ∈ ℕ}')} کدام است؟`, SHd(correct), wr.map(SHd),
    `به‌جای k عددهای ${M('۱، ۲، ۳، ...')} را قرار می‌دهیم (ℕ از ۱ شروع می‌شود): ${SHd(correct)}.`);
};
const NS_T = ['N ⊆ W', 'W ⊆ Z', 'Z ⊆ Q', 'N ⊆ Q', '0 ∈ W', '0 ∉ N', '-3 ∈ Z', '-3 ∉ W', '1/2 ∈ Q', '1/2 ∉ Z', '7 ∈ N', '0٫5 ∈ Q'];
const NS_F = ['W ⊆ N', 'Z ⊆ W', 'Q ⊆ Z', '0 ∈ N', '-3 ∈ W', '1/2 ∈ Z', '-2 ∈ N', '0٫5 ∈ Z', 'Z ⊆ N', '1/3 ∈ W'];
const nsFix = s => M(fa(s).replace(/N/g, 'ℕ').replace(/Z/g, 'ℤ').replace(/Q/g, 'ℚ'));
G.numSets = (r) => {
  if (r() < .5) {
    return build(r, 'کدام عبارت <b>درست</b> است؟', nsFix(RP(r, NS_T)), RSm(r, NS_F, 3).map(nsFix),
      'ℕ ⊆ W ⊆ ℤ ⊆ ℚ؛ هر عدد طبیعی حسابی است، هر حسابی صحیح و هر صحیح گویاست.');
  }
  return build(r, 'کدام عبارت <b>نادرست</b> است؟', nsFix(RP(r, NS_F)), RSm(r, NS_T, 3).map(nsFix),
    'ℕ ⊆ W ⊆ ℤ ⊆ ℚ؛ برعکس این رابطه‌ها برقرار نیست.');
};
G.setWhich = (r) => {
  const k = RI(r, 1, 9), v = RI(r, 0, 2);
  if (v === 0) return build(r, `کدام عدد عضو ${M('ℤ')} است، ولی عضو ${M('W')} نیست؟`, M(fa(-k)), [M(fa(0)), M(fa(k)), M('۱/۲'), M(fa(k + 1))], 'عددهای صحیح منفی در W نیستند.');
  if (v === 1) return build(r, `کدام عدد عضو ${M('W')} است، ولی عضو ${M('ℕ')} نیست؟`, M('۰'), [M(fa(k)), M(fa(-k)), M('۱/۲'), M(fa(k + 2))], 'تنها عدد حسابی غیرطبیعی، صفر است.');
  const d = RP(r, [2, 3, 4, 5, 7]);
  return build(r, `کدام عدد عضو ${M('ℚ')} است، ولی عضو ${M('ℤ')} نیست؟`, M(`${fa(1)}/${fa(d)}`), [M(fa(-k)), M('۰'), M(fa(k)), M(fa(k + 3))], 'کسر ساده‌نشدنی با مخرج بزرگ‌تر از ۱ گویاست ولی صحیح نیست.');
};
G.multMember = (r) => {
  const p = RI(r, 4, 9), q = RI(r, 0, 3), m = RI(r, 2, 9), x = p * m + q;
  return build(r, `کدام عدد عضو مجموعهٔ ${M('{' + lin(p, q) + ' | k ∈ ℕ}')} است؟`, M(fa(x)),
    [x + 1, x + 2, x - 1, x + 3].map(v => M(fa(v))),
    `برای k = ${fa(m)} داریم ${M(fa(p) + '×' + fa(m) + (q ? ' + ' + fa(q) : '') + ' = ' + fa(x))}.`);
};
G.consec = (r) => {
  if (r() < .5) {
    const m = RI(r, 3, 14);
    return build(r, `مجموعهٔ ${M('A')} شامل سه عدد طبیعی متوالی است که مجموعشان ${fa(3 * m)} است. ${M('A')} کدام است؟`,
      SH([m - 1, m, m + 1]), [SH([m, m + 1, m + 2]), SH([m - 2, m - 1, m]), SH([m - 2, m, m + 2]), SH([m - 1, m, m + 2])],
      `عدد وسط = مجموع ÷ ۳ = ${fa(m)}؛ پس ${SH([m - 1, m, m + 1])}.`);
  }
  const m = 2 * RI(r, 2, 8);
  return build(r, `سه عدد زوج متوالی داریم که میانگینشان ${fa(m)} است. این مجموعه کدام است؟`,
    SH([m - 2, m, m + 2]), [SH([m - 1, m, m + 1]), SH([m, m + 2, m + 4]), SH([m - 4, m - 2, m]), SH([m - 2, m, m + 1])],
    `در سه عدد متوالی، میانگین همان عدد وسط است؛ پس ${SH([m - 2, m, m + 2])}.`);
};
G.intCount = (r) => {
  const lo = -RI(r, 1, 7), hi = RI(r, 1, 8), li = r() < .7, hiI = r() < .4;
  const el = range(lo, hi).filter(x => (li ? x >= lo : x > lo) && (hiI ? x <= hi : x < hi)), n = el.length;
  const cond = `${fa(lo)} ${li ? '≤' : '<'} x ${hiI ? '≤' : '<'} ${fa(hi)}`;
  return build(r, `مجموعهٔ ${M('A = {x ∈ ℤ | ' + cond + '}')} چند عضو دارد؟`, fa(n),
    numW(n, [n + 1, n - 1, hi - lo, hi + Math.abs(lo), n + 2]),
    `عضوها: ${SH(el)} ⇒ ${fa(n)} عضو (صفر را فراموش نکن!).`);
};

/* ================= زیرمجموعه ================= */
G.subPick = (r) => {
  const A = srt(RSm(r, range(1, 9), 4)), out = range(1, 12).filter(x => !A.includes(x));
  const S = srt(RSm(r, A, RI(r, 2, 3)));
  const bad = () => srt([...RSm(r, A, 1), RP(r, out)]);
  return build(r, `کدام مجموعه زیرمجموعهٔ ${M('A = ' + setS(A))} است؟`, SH(S), [SH(bad()), SH(srt([A[0], A[1], RP(r, out)])), SH(srt([RP(r, out), RP(r, A)])), SH(srt([...A, RP(r, out)]))],
    'زیرمجموعه یعنی همهٔ عضوهایش در A باشند؛ در بقیهٔ گزینه‌ها عضوی هست که در A نیست.');
};
G.subStmt = (r) => {
  const U = RSm(r, range(1, 9), 6), A = srt(U.slice(0, 4)), y = U[4];
  const S = srt(RSm(r, A, 2)), x = RP(r, A), So = srt([RP(r, A), y]);
  const T = [[`${setS(S)} ⊆ A`, 'همهٔ عضوهای این مجموعه در A هستند.'], ['∅ ⊆ A', 'مجموعهٔ تهی زیرمجموعهٔ هر مجموعه‌ای است.'], ['A ⊆ A', 'هر مجموعه زیرمجموعهٔ خودش است.'],
    [`${fa(x)} ∈ A`, `${fa(x)} یکی از اعضای A است.`], [`${setS(So)} ⊈ A`, `${fa(y)} در A نیست.`], [`${fa(y)} ∉ A`, `${fa(y)} عضو A نیست.`]];
  const F = [[`${setS(So)} ⊆ A`, `${fa(y)} در A نیست؛ پس زیرمجموعه نیست.`], [`${fa(y)} ∈ A`, `${fa(y)} عضو A نیست.`],
    [`${setS([x])} ∈ A`, `${fa(x)} عضو A است، نه ${M(setS([x]))}؛ درست آن ${M(setS([x]) + ' ⊆ A')} است.`],
    [`A ⊆ ${setS(S)}`, 'A چهار عضو دارد و این مجموعه فقط دو عضو.'], [`${fa(x)} ⊆ A`, 'برای عضو از ∈ استفاده می‌کنیم، نه ⊆.'], [`${setS(S)} ∈ A`, 'یک مجموعه، عضو A نیست؛ زیرمجموعهٔ A است.']];
  const head = `${M('A = ' + setS(A))}<br>`;
  if (r() < .5) { const c = RP(r, T); return build(r, head + 'کدام عبارت <b>درست</b> است؟', M(c[0]), RSm(r, F, 3).map(f => M(f[0])), c[1]); }
  const c = RP(r, F); return build(r, head + 'کدام عبارت <b>نادرست</b> است؟', M(c[0]), RSm(r, T, 3).map(f => M(f[0])), c[1]);
};
G.subCount = (r, t) => {
  const n = Math.min(6, RI(r, 2, 3 + Math.floor(t * 4))), ls = 'abcdef'.slice(0, n).split(''), v = 2 ** n;
  return build(r, `مجموعهٔ ${M('A = {' + ls.join('، ') + '}')} چند زیرمجموعه دارد؟`, fa(v), numW(v, [2 * n, n * n, v - 1, v * 2, v / 2, n + 1]),
    `هر مجموعهٔ ${fa(n)} عضوی ${M('۲^' + fa(n) + ' = ' + fa(v))} زیرمجموعه دارد (با ∅ و خودش).`);
};
G.subCount2 = (r) => {
  const n = RI(r, 3, 6), ls = 'abcdef'.slice(0, n).split('');
  const A = M('A = {' + ls.join('، ') + '}');
  if (r() < .5) { const v = 2 ** n - 1; return build(r, `${A}<br>چند زیرمجموعهٔ <b>غیرتهی</b> دارد؟`, fa(v), numW(v, [v + 1, 2 * n, n * n, v - 1, 2 ** (n - 1)]), `کل زیرمجموعه‌ها ${fa(2 ** n)} است؛ بدون ∅: ${fa(v)}.`); }
  const v = n * (n - 1) / 2; return build(r, `${A}<br>چند زیرمجموعهٔ <b>دو عضوی</b> دارد؟`, fa(v), numW(v, [n, 2 * n, v + 1, v - 1, n * n]), `هر زوج متفاوت از ${fa(n)} عضو یک زیرمجموعهٔ دو عضوی است: ${fa(v)} حالت.`);
};
G.subChain = (r) => {
  const b = [
    [`اگر ${M('A ⊆ B')} و ${M('B ⊆ C')} باشد، کدام عبارت همواره درست است؟`, M('A ⊆ C'), [M('C ⊆ A'), M('B ⊆ A'), M('A = C')], 'زیرمجموعه بودن «انتقالی» است: A در B و B در C، پس A در C.'],
    [`اگر ${M('A ⊆ B')} و ${M('B ⊆ A')} باشد، چه نتیجه‌ای می‌گیریم؟`, M('A = B'), [M('A ∩ B = ∅'), M('A − B ≠ ∅'), M('n(A) < n(B)')], 'هر عضو A در B و هر عضو B در A است؛ پس برابرند.'],
    [`اگر ${M('n(A) = ۵')} و ${M('A ⊆ B')} باشد، تعداد اعضای B …`, 'حداقل ۵ است', ['دقیقاً ۵ است', 'حداکثر ۵ است', 'کمتر از ۵ است'], 'همهٔ ۵ عضو A در B هستند؛ B می‌تواند عضو بیشتری هم داشته باشد.'],
    ['مجموعهٔ تهی زیرمجموعهٔ کدام مجموعه است؟', 'هر مجموعه‌ای', ['فقط مجموعه‌های غیرتهی', 'فقط خودش', 'هیچ مجموعه‌ای'], 'مجموعهٔ تهی عضوی ندارد که در A نباشد؛ پس زیرمجموعهٔ هر مجموعه‌ای است.']];
  const c = RP(r, b); return build(r, c[0], c[1], c[2], c[3]);
};
G.oddTrap = (r) => {
  const D = srt(RSm(r, [-6, -4, -2, 2, 4, 6, 8, 10, 12], 4));
  return build(r, `${M('D = ' + setS(D))}<br>کدام زیرمجموعهٔ D فقط عددهای <b>فرد</b> دارد؟`, M('∅'),
    [SH([D[0]]), SH([D[0], D[1]]), SH([D[1], D[2]]), SH(D)], 'در D عدد فردی نیست؛ تنها زیرمجموعه‌ای که «همهٔ اعضایش فرد» است، مجموعهٔ تهی است.');
};

/* ================= اجتماع، اشتراک، تفاضل ================= */
const setOpQ = (r, t, op, venn) => {
  const S = makeAB(r, t), c = opCands(S);
  const stem = venn ? `${vennSVG(S.oa, S.both, S.ob)}<div>با توجه به نمودار، ${M(OPN[op])} کدام است؟</div>` : `${ABhtml(S)}<div>${M(OPN[op])} کدام است؟</div>`;
  return build(r, stem, SH(c[op]), Object.keys(c).filter(k => k !== op).map(k => SH(c[k])), `${OPE[op]} ⇒ ${SH(c[op])}`);
};
G.union = (r, t) => setOpQ(r, t, 'u'); G.inters = (r, t) => setOpQ(r, t, 'i');
G.diffAB = (r, t) => setOpQ(r, t, 'ab'); G.diffBA = (r, t) => setOpQ(r, t, 'ba');
G.vennRead = (r, t) => setOpQ(r, t, RP(r, ['u', 'i', 'ab', 'ba']), true);
G.vennCount = (r, t) => {
  const S = makeAB(r, t), c = opCands(S);
  const o = RP(r, [['n(A ∪ B)', c.u.length], ['n(A ∩ B)', c.i.length], ['n(A − B)', c.ab.length], ['n(B − A)', c.ba.length]]);
  return build(r, `${vennSVG(S.oa, S.both, S.ob)}<div>با توجه به نمودار، ${M(o[0])} چند است؟</div>`, fa(o[1]),
    numW(o[1], [S.A.length, S.B.length, S.A.length + S.B.length, c.u.length, c.i.length, o[1] + 1, o[1] - 1]),
    'عضوهای ناحیهٔ مورد نظر را بشمار؛ عضوهای مشترک را فقط یک بار حساب کن.');
};
const EXPR = [
  ['(A − B) ∪ (A ∩ B)', (A, B, C) => A], ['(A ∪ B) − C', (A, B, C) => diff(uni(A, B), C)], ['(A − C) ∪ (B − C)', (A, B, C) => uni(diff(A, C), diff(B, C))],
  ['(A ∩ B) − C', (A, B, C) => diff(inter(A, B), C)], ['(A − B) ∪ (B − A)', (A, B, C) => uni(diff(A, B), diff(B, A))],
  ['A ∩ (B ∪ C)', (A, B, C) => inter(A, uni(B, C))], ['(A ∪ C) − B', (A, B, C) => diff(uni(A, C), B)], ['A − (B ∪ C)', (A, B, C) => diff(A, uni(B, C))],
  ['(A ∩ B) ∪ C', (A, B, C) => uni(inter(A, B), C)]];
G.expr = (r) => {
  const U = range(1, 12), A = srt(RSm(r, U, RI(r, 4, 6))), B = srt(RSm(r, U, RI(r, 4, 6))), C = srt(RSm(r, U, RI(r, 4, 6)));
  const e = RP(r, EXPR), val = e[1](A, B, C);
  const wr = EXPR.filter(x => x !== e).map(x => SH(x[1](A, B, C)));
  const tog = x => val.includes(x) ? val.filter(v => v !== x) : srt([...val, x]);
  wr.push(SH(tog(RP(r, U))), SH(tog(RP(r, U))));
  return build(r, `<div class="sets">${M('A = ' + setS(A))}<br>${M('B = ' + setS(B))}<br>${M('C = ' + setS(C))}</div><div>${M(e[0])} کدام است؟</div>`, SH(val), wr,
    `ابتدا پرانتز را حساب کن، بعد عمل بعدی را: ${M(e[0])} = ${SH(val)}.`);
};
G.counts = (r, t) => {
  const c = RI(r, 2, 6 + Math.floor(t * 6)), oa = RI(r, 3, 9 + Math.floor(t * 6)), ob = RI(r, 3, 9 + Math.floor(t * 6));
  const a = oa + c, b = ob + c, u = oa + ob + c, ty = RI(r, 0, 5);
  const N = (s, v) => M(s + ' = ' + fa(v));
  if (ty === 0) return build(r, `${N('n(A)', a)}، ${N('n(B)', b)} و ${N('n(A ∩ B)', c)}. ${M('n(A ∪ B)')} چند است؟`, fa(u), numW(u, [a + b, a + b + c, u + 1, u - 1, a + b - c - 1]), `${M('n(A∪B) = n(A) + n(B) − n(A∩B)')} = ${fa(a)} + ${fa(b)} − ${fa(c)} = ${fa(u)}`);
  if (ty === 1) return build(r, `${N('n(A)', a)}، ${N('n(B)', b)} و ${N('n(A ∪ B)', u)}. ${M('n(A ∩ B)')} چند است؟`, fa(c), numW(c, [a + b + u, u - a, a + b, c + 1, c - 1, b - c]), `${fa(a)} + ${fa(b)} − ${fa(u)} = ${fa(c)}`);
  if (ty === 2) return build(r, `${N('n(A)', a)} و ${N('n(A ∩ B)', c)}. ${M('n(A − B)')} چند است؟`, fa(oa), numW(oa, [a + c, a, c, oa + 1, oa - 1]), `${M('n(A−B) = n(A) − n(A∩B)')} = ${fa(a)} − ${fa(c)} = ${fa(oa)}`);
  if (ty === 3) {
    const w = RP(r, [['فقط والیبال', oa, [a, a + c, u, oa + 1]], ['فقط فوتبال', ob, [b, b + c, u, ob + 1]], ['حداقل در یکی از دو تیم', u, [a + b, a + b + c, u + 1, u - 1]]]);
    return build(r, `در یک کلاس ${fa(a)} نفر والیبال، ${fa(b)} نفر فوتبال و ${fa(c)} نفر هر دو ورزش را بازی می‌کنند. چند نفر ${w[0]} بازی می‌کنند؟`, fa(w[1]), numW(w[1], w[2]), 'کسانی که هر دو را بازی می‌کنند، در هر دو شمارش شده‌اند؛ باید یک بار کم شوند.');
  }
  if (ty === 4) return build(r, `کلاسی ${fa(u)} دانش‌آموز دارد و همه حداقل در یکی از دو تیم والیبال یا فوتبال‌اند. ${fa(a)} نفر والیبال و ${fa(b)} نفر فوتبال بازی می‌کنند. چند نفر در هر دو تیم‌اند؟`, fa(c), numW(c, [a + b + u, a + b, c + 1, c - 1, u - a]), `${fa(a)} + ${fa(b)} − ${fa(u)} = ${fa(c)}`);
  return build(r, `${N('n(A)', a)} و ${N('n(B)', b)} و ${M('A ∩ B = ∅')}. ${M('n(A ∪ B)')} چند است؟`, fa(a + b), numW(a + b, [a + b - 1, a + b + 1, Math.abs(a - b), a * b]), 'وقتی اشتراک تهی است، چیزی دو بار شمرده نمی‌شود؛ تعداد‌ها را جمع می‌کنیم.');
};
const FACT_T = ['A ∩ B ⊆ A', 'A ⊆ A ∪ B', 'A − B ⊆ A', 'A ∩ B ⊆ A ∪ B', '(A − B) ∪ (A ∩ B) = A', 'A ∪ ∅ = A', 'A ∩ ∅ = ∅', 'B ⊆ A ∪ B'];
const FACT_F = ['A ⊆ A ∩ B', 'A ∪ B ⊆ A', 'A − B = B − A', 'B ⊆ A − B', 'A ∩ ∅ = A', 'A ∪ ∅ = ∅', 'A − B = A ∩ B', 'A ∩ B = A ∪ B'];
G.facts = (r) => {
  if (r() < .5) return build(r, 'کدام عبارت برای هر دو مجموعهٔ A و B <b>همواره درست</b> است؟', M(RP(r, FACT_T)), RSm(r, FACT_F, 3).map(M), 'اشتراک «کوچک‌تر» و اجتماع «بزرگ‌تر» از هر دو مجموعه است؛ بقیه فقط گاهی برقرارند.');
  return build(r, 'کدام عبارت برای دو مجموعهٔ دلخواه A و B <b>همواره درست نیست</b>؟', M(RP(r, FACT_F)), RSm(r, FACT_T, 3).map(M), 'این رابطه فقط برای بعضی مجموعه‌ها برقرار است، نه همه.');
};

/* ================= احتمال ================= */
const DICE_EV = [
  [0, 'زوج', x => x % 2 === 0], [0, 'فرد', x => x % 2 === 1], [0, 'اول', isPrime], [0, 'مضرب ۳', x => x % 3 === 0], [0, 'بزرگ‌تر از ۴', x => x > 4],
  [0, 'کوچک‌تر از ۳', x => x < 3], [0, 'بزرگ‌تر از ۶', x => x > 6], [0, 'کوچک‌تر از ۷', x => x < 7],
  [1, 'زوج و اول', x => x % 2 === 0 && isPrime(x)], [1, 'فرد و اول', x => x % 2 === 1 && isPrime(x)], [1, 'زوج و بزرگ‌تر از ۲', x => x % 2 === 0 && x > 2],
  [1, 'اول یا زوج', x => isPrime(x) || x % 2 === 0], [1, 'مضرب ۳ یا زوج', x => x % 3 === 0 || x % 2 === 0], [1, 'فرد و بزرگ‌تر از ۲', x => x % 2 === 1 && x > 2],
  [1, 'شمارندهٔ ۶', x => 6 % x === 0], [1, 'اول و بزرگ‌تر از ۳', x => isPrime(x) && x > 3]];
G.dice = (r, t) => {
  const ev = RP(r, DICE_EV.filter(e => e[0] <= (t < .35 ? 0 : 1))), S = range(1, 6), A = S.filter(ev[2]), k = A.length;
  return build(r, `تاسی را می‌اندازیم. احتمال اینکه عدد رو شده <b>${ev[1]}</b> باشد چقدر است؟`, frH(k, 6), probOpts(r, k, 6),
    `${M('S = ' + setS(S))}، ${M('A = ' + setS(A))} ⇒ ${M('n(A) = ' + fa(k))}، ${M('n(S) = ۶')} ⇒ ${M('P(A) = ' + fa(k) + '/۶')}`);
};
G.diceSet = (r) => {
  const ev = RP(r, DICE_EV), S = range(1, 6), A = S.filter(ev[2]);
  const tog = (arr, x) => arr.includes(x) ? arr.filter(v => v !== x) : srt([...arr, x]);
  const comp = diff(S, A);
  const wr = [SH(comp), SH(tog(A, RP(r, S))), SH(tog(A, RP(r, S))), SH(tog(tog(A, RP(r, S)), RP(r, S))), SH(tog(A, 1)), SH(tog(A, 6))];
  return build(r, `در پرتاب یک تاس، پیشامد «عدد رو شده <b>${ev[1]}</b> باشد» با کدام مجموعه نشان داده می‌شود؟`, SH(A), wr,
    'پیشامد، زیرمجموعه‌ای از S = {۱، ۲، ۳، ۴، ۵، ۶} است که شرط را برآورده می‌کند.');
};
const cardEvs = (r, t) => {
  const k = RI(r, 3, 9), l = [[0, `کمتر از ${fa(k)}`, x => x < k], [0, `بیشتر از ${fa(k)}`, x => x > k], [0, 'زوج', x => x % 2 === 0], [0, 'فرد', x => x % 2 === 1],
    [1, 'اول', isPrime], [1, 'مضرب ۳', x => x % 3 === 0], [1, 'مضرب ۵', x => x % 5 === 0], [1, 'بزرگ‌تر از ۱۰', x => x > 10], [1, 'کوچک‌تر از ۱۱', x => x < 11],
    [1, 'زوج و مضرب ۳', x => x % 2 === 0 && x % 3 === 0], [1, 'اول یا زوج', x => isPrime(x) || x % 2 === 0], [1, 'فرد و بزرگ‌تر از ۴', x => x % 2 === 1 && x > 4]];
  return RP(r, l.filter(e => e[0] <= (t < .3 ? 0 : 1)));
};
G.cards = (r, t) => {
  const ev = cardEvs(r, t), S = range(1, 10), A = S.filter(ev[2]), k = A.length;
  return build(r, `۱۰ کارت یکسان با شمارهٔ ۱ تا ۱۰ در جعبه‌ای است. یک کارت تصادفی بیرون می‌آوریم. احتمال اینکه عدد روی کارت <b>${ev[1]}</b> باشد چقدر است؟`,
    frH(k, 10), probOpts(r, k, 10), `${M('A = ' + setS(A))} ⇒ ${M('P(A) = ' + fa(k) + '/۱۰')}`);
};
G.family = (r, t) => {
  const n = t < .5 ? RI(r, 2, 3) : 3, N = 1 << n, st = range(0, N - 1);
  const cnt = s => range(0, n - 1).reduce((a, i) => a + ((s >> i) & 1), 0);
  const evs = [['دقیقاً یک دختر داشته باشد', s => cnt(s) === 1], ['دقیقاً دو دختر داشته باشد', s => cnt(s) === 2], ['حداقل یک دختر داشته باشد', s => cnt(s) >= 1],
    ['همهٔ فرزندانش پسر باشند', s => cnt(s) === 0], ['همهٔ فرزندانش دختر باشند', s => cnt(s) === n], ['حداکثر یک دختر داشته باشد', s => cnt(s) <= 1], ['فرزند اولش دختر باشد', s => s & 1]];
  const e = RP(r, evs), k = st.filter(e[1]).length;
  return build(r, `خانواده‌ای ${fa(n)} فرزند دارد و احتمال دختر یا پسر بودن هر فرزند برابر است. احتمال اینکه این خانواده ${e[0]} چقدر است؟`, frH(k, N), probOpts(r, k, N),
    `همهٔ حالت‌های ممکن ${M('n(S) = ۲^' + fa(n) + ' = ' + fa(N))} است و حالت‌های مطلوب ${fa(k)} تاست.`);
};
G.marbles = (r, t) => {
  const c = [RI(r, 3, 6 + Math.floor(t * 3)), RI(r, 3, 6 + Math.floor(t * 3)), RI(r, 3, 6 + Math.floor(t * 3))], nm = ['قرمز', 'آبی', 'سبز'], N = c[0] + c[1] + c[2];
  const i = RI(r, 0, 2), j = (i + RI(r, 1, 2)) % 3, v = RI(r, 0, 2);
  let k, txt;
  if (v === 0) { k = c[i]; txt = `${nm[i]} باشد`; } else if (v === 1) { k = N - c[i]; txt = `${nm[i]} نباشد`; } else { k = c[i] + c[j]; txt = `${nm[i]} یا ${nm[j]} باشد`; }
  return build(r, `در جعبه‌ای ${fa(c[0])} مهرهٔ قرمز، ${fa(c[1])} مهرهٔ آبی و ${fa(c[2])} مهرهٔ سبز هست. یک مهره را تصادفی بیرون می‌آوریم. احتمال اینکه این مهره <b>${txt}</b> چقدر است؟`,
    frH(k, N), probOpts(r, k, N), `${M('n(S) = ' + fa(N))} و حالت‌های مطلوب ${fa(k)} تا ⇒ ${M('P = ' + fa(k) + '/' + fa(N))}`);
};
const TWO = [[0, 'مجموع دو عدد ۷ باشد', (a, b) => a + b === 7], [0, 'دو عدد رو شده یکسان باشند', (a, b) => a === b], [0, 'مجموع دو عدد از ۱۰ بیشتر باشد', (a, b) => a + b > 10],
  [0, 'هر دو عدد زوج باشند', (a, b) => a % 2 === 0 && b % 2 === 0], [0, 'مجموع دو عدد ۱۲ باشد', (a, b) => a + b === 12], [0, 'مجموع دو عدد کمتر از ۵ باشد', (a, b) => a + b < 5],
  [1, 'حداقل یکی از دو عدد ۶ باشد', (a, b) => a === 6 || b === 6], [1, 'مجموع دو عدد فرد باشد', (a, b) => (a + b) % 2 === 1], [1, 'مجموع دو عدد مضرب ۳ باشد', (a, b) => (a + b) % 3 === 0],
  [1, 'حاصل‌ضرب دو عدد ۶ باشد', (a, b) => a * b === 6], [1, 'هر دو عدد اول باشند', (a, b) => isPrime(a) && isPrime(b)], [1, 'عدد اول بزرگ‌تر یا مساوی عدد دوم باشد', (a, b) => a >= b]];
G.twoDice = (r, t) => {
  const e = RP(r, TWO.filter(x => x[0] <= (t < .6 ? 0 : 1))); let k = 0;
  for (let a = 1; a <= 6; a++) for (let b = 1; b <= 6; b++) if (e[2](a, b)) k++;
  return build(r, `دو تاس را با هم می‌اندازیم. احتمال اینکه <b>${e[1]}</b> چقدر است؟`, frH(k, 36), probOpts(r, k, 36),
    `${M('n(S) = ۶×۶ = ۳۶')}؛ حالت‌های مطلوب را بشمار: ${fa(k)} حالت ⇒ ${M('P = ' + fa(k) + '/۳۶')}`);
};
G.complement = (r) => {
  const b = RI(r, 5, 12), a = RI(r, 1, b - 1), k = b - a;
  return build(r, `اگر ${M('P(A) = ' + fa(a) + '/' + fa(b))} باشد، احتمال <b>رخ ندادن</b> پیشامد A چقدر است؟`, frH(k, b), probOpts(r, k, b),
    `${M('P(A′) = ۱ − P(A)')} = ${fa(b)}/${fa(b)} − ${fa(a)}/${fa(b)} = ${fa(k)}/${fa(b)}`);
};
G.probFacts = (r) => {
  const v = RI(r, 0, 2);
  if (v === 0) {
    const ok = ['۰', '۱', '۲/۵', '۳/۴', '۱/۸', '۷/۱۰', '۰٫۹'], bad = ['۵/۴', '−۰٫۲', '۱٫۵', '۳/۲', '−۱/۳', '۲', '۱۰/۷', '۱۱/۱۰'];
    return build(r, 'کدام عدد می‌تواند احتمال رخ دادن یک پیشامد باشد؟', M(RP(r, ok)), RSm(r, bad, 3).map(M), 'احتمال همیشه بین ۰ و ۱ است (می‌تواند خود ۰ یا ۱ هم باشد).');
  }
  if (v === 1) return build(r, 'احتمال رخ دادن یک پیشامد <b>غیرممکن</b> چند است؟', M('۰'), [M('۱'), M('۱/۲'), M('−۱'), M('۱۰۰')], 'پیشامد غیرممکن = مجموعهٔ تهی ⇒ n(∅) = ۰ ⇒ احتمال صفر.');
  return build(r, 'احتمال رخ دادن یک پیشامد <b>حتمی</b> چند است؟', M('۱'), [M('۰'), M('۱/۲'), M('۲'), M('۱۰')], 'پیشامد حتمی همان S است ⇒ n(S)/n(S) = ۱.');
};
const EQL = [['زوج', [2, 4, 6]], ['فرد', [1, 3, 5]], ['اول', [2, 3, 5]], ['کمتر از ۳', [1, 2]], ['بزرگ‌تر از ۴', [5, 6]], ['مضرب ۳', [3, 6]], ['عدد ۶', [6]], ['کمتر از ۵', [1, 2, 3, 4]], ['مضرب ۴', [4]], ['بزرگ‌تر از ۲', [3, 4, 5, 6]]];
G.equalLikely = (r) => {
  const pairsOk = [], pairsBad = [];
  for (let i = 0; i < EQL.length; i++) for (let j = i + 1; j < EQL.length; j++) (EQL[i][1].length === EQL[j][1].length ? pairsOk : pairsBad).push([EQL[i], EQL[j]]);
  const f = p => `«${p[0][0]}» و «${p[1][0]}»`;
  return build(r, 'در پرتاب یک تاس، کدام دو پیشامد <b>همشانس</b> هستند (احتمالشان برابر است)؟', f(RP(r, pairsOk)), RSm(r, pairsBad, 3).map(f),
    'دو پیشامد وقتی همشانس‌اند که تعداد اعضای مجموعه‌شان برابر باشد.');
};
G.probFromCounts = (r) => {
  if (r() < .6) {
    const a = RP(r, [8, 10, 12, 15, 20, 24, 30]), b = RI(r, 1, a - 1);
    return build(r, `${M('n(S) = ' + fa(a))} و ${M('n(A) = ' + fa(b))} است. ${M('P(A)')} چقدر است؟`, frH(b, a), probOpts(r, b, a), `${M('P(A) = n(A)/n(S) = ' + fa(b) + '/' + fa(a))}`);
  }
  const q = RP(r, [4, 5, 6, 8, 10]), p = RI(r, 1, q - 1), m = RI(r, 2, 6), ns = q * m, na = p * m;
  const g = gcd(p, q), pp = p / g, qq = q / g, na2 = pp * (ns / qq);
  return build(r, `${M('n(S) = ' + fa(ns))} و ${M('P(A) = ' + fa(pp) + '/' + fa(qq))} است. ${M('n(A)')} چند است؟`, fa(na2), numW(na2, [na2 + 1, na2 - 1, ns - na2, pp, qq, na2 + 2]),
    `${M('n(A) = P(A) × n(S)')} = ${fa(pp)}/${fa(qq)} × ${fa(ns)} = ${fa(na2)}`);
};
G.addMarbles = (r) => {
  const rd = RI(r, 2, 6), bl = rd + RI(r, 2, 6), d = bl - rd;
  return build(r, `در جعبه‌ای ${fa(rd)} مهرهٔ قرمز و ${fa(bl)} مهرهٔ آبی هست. چند مهرهٔ <b>قرمز</b> دیگر اضافه کنیم تا احتمال بیرون آمدن مهرهٔ قرمز ${M('۱/۲')} شود؟`, fa(d),
    numW(d, [d + 1, d - 1, bl, rd, bl + rd, d + 2]), `احتمال ۱/۲ یعنی تعداد قرمزها با آبی‌ها برابر شود: ${fa(rd)} + ${fa(d)} = ${fa(bl)}.`);
};

/* ================= مرحله‌ها ================= */
const STAGES = [
  { from: 1, to: 6, name: 'آشنایی با مجموعه', pool: ['member', 'count', 'primeDiv', 'divCount', 'isSet', 'emptyQ', 'emptyTrick', 'equal'] },
  { from: 7, to: 13, name: 'برابری و نمایش مجموعه‌ها', pool: ['equal', 'equalFind', 'builder', 'rule', 'numSets', 'setWhich', 'multMember', 'consec', 'intCount', 'count'] },
  { from: 14, to: 20, name: 'زیرمجموعه', pool: ['subPick', 'subStmt', 'subCount', 'subCount2', 'subChain', 'oddTrap', 'numSets', 'emptyQ', 'subStmt'] },
  { from: 21, to: 31, name: 'اجتماع، اشتراک و تفاضل', pool: ['union', 'inters', 'diffAB', 'diffBA', 'vennRead', 'vennCount', 'expr', 'counts', 'facts', 'vennRead'] },
  { from: 32, to: 42, name: 'احتمال', pool: ['dice', 'diceSet', 'cards', 'family', 'marbles', 'twoDice', 'complement', 'probFacts', 'equalLikely', 'probFromCounts', 'addMarbles'] },
  { from: 43, to: 50, name: 'فینال: همه‌چیز با هم', pool: ['expr', 'counts', 'subCount2', 'vennCount', 'twoDice', 'marbles', 'family', 'addMarbles', 'builder', 'rule', 'intCount', 'subStmt', 'dice', 'cards', 'vennRead', 'diceSet'] }
];
const stageOf = L => STAGES.find(s => L >= s.from && L <= s.to);
function genOne(key, L, i, attempt, t) {
  let last;
  for (let tries = 0; tries < 40; tries++) {
    try { return G[key](mulberry32(L * 7919 + i * 104729 + attempt * 1299709 + tries * 31337 + 13), t); } catch (e) { last = e; }
  }
  throw last;
}
function genLevel(L, attempt) {
  const st = stageOf(L), t = (L - 1) / 49, local = L - st.from, n = st.pool.length;
  const step = [3, 5, 7, 4].find(s => gcd(s, n) === 1);
  return range(0, 3).map(i => genOne(st.pool[(local * step + i) % n], L, i, attempt, t));
}
