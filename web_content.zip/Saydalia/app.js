import {all,put,remove,getMeta,setMeta,replaceAll} from './db.js';
import {money,dateKey,movementTotals,pharmacyBreakdown,itemTotal,validateBackup,monthRange} from './core.js';

const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const main=$('#main'), modalRoot=$('#modalRoot');
const today=dateKey(new Date());
let state={page:'day',pharmacies:[],movements:[],primaryId:null,selectedMonth:new Date().getMonth()+1,selectedYear:new Date().getFullYear(),dayShift:'Morning',dayManager:'',detailId:null,monthPharmacy:null};
const uid=()=>crypto.randomUUID();
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dateLabel=d=>new Intl.DateTimeFormat('ar-EG',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(new Date(`${d}T12:00:00`));
const activePharmacies=()=>state.pharmacies.filter(p=>p.active);
const primary=()=>state.pharmacies.find(p=>p.id===state.primaryId);
const pharmacyName=id=>state.pharmacies.find(p=>p.id===id)?.name||'صيدلية غير معروفة';
const shiftLabel=s=>({Morning:'صباحي',Afternoon:'مسائي',Night:'ليلي'}[s]||s);
const typeLabel=t=>t==='in'?'وارد إلينا':'صادر منا';
const typeClass=t=>t==='in'?'incoming':'outgoing';
const sortMovements=rows=>[...rows].sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt-a.createdAt);
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2600)}
async function refresh(){state.pharmacies=await all('pharmacies');state.movements=await all('movements');state.primaryId=await getMeta('primaryId')||state.primaryId;render()}
async function init(){
  await refresh();
  if(!state.pharmacies.length){showSetup();return}
  if(!primary()){state.primaryId=state.pharmacies.find(p=>p.isPrimary)?.id||state.pharmacies[0]?.id}
  render();
  if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
}
function showSetup(){
  modalRoot.innerHTML=`<div class="overlay"><section class="modal setup-modal"><div class="setup-icon">✚</div><h2>مرحبًا بك في صيدلية</h2><p class="muted">لنبدأ بإعداد فروع المجموعة. يمكنك إضافة فروع أخرى لاحقًا.</p><form id="setupForm">
  <label>اسم الصيدلية الأساسية<input name="primary" required maxlength="80" placeholder="مثال: صيدلية النور"></label>
  <label>أسماء الصيدليات الأخرى <span class="muted">(اختياري — اسم في كل سطر)</span><textarea name="others" rows="3" placeholder="صيدلية الفرع الثاني&#10;صيدلية الفرع الثالث"></textarea></label>
  <button class="btn primary full">بدء الاستخدام</button></form></section></div>`;
  $('#setupForm').onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.currentTarget),name=fd.get('primary').trim();if(!name)return;
    const p={id:uid(),name,active:true,isPrimary:true,createdAt:Date.now()};const others=String(fd.get('others')||'').split('\n').map(x=>x.trim()).filter(Boolean).map(n=>({id:uid(),name:n,active:true,isPrimary:false,createdAt:Date.now()}));
    await put('pharmacies',p);for(const x of others)await put('pharmacies',x);await setMeta('primaryId',p.id);modalRoot.innerHTML='';await refresh();toast('تم إعداد المجموعة بنجاح');};
}
function setPage(page){state.page=page;state.monthPharmacy=null;render();window.scrollTo({top:0,behavior:'smooth'})}
function render(){
  $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===state.page));
  if(state.page==='day')renderDay();else if(state.page==='month')renderMonth();else if(state.page==='year')renderYear();else if(state.page==='settings')renderSettings();else if(state.page==='details')renderDetails();
}
function pageHeader(title,sub=''){return `<div class="page-heading"><div><h1>${title}</h1>${sub?`<p>${sub}</p>`:''}</div></div>`}
function renderDay(){
  const rows=sortMovements(state.movements.filter(m=>m.date===today));
  const totals=movementTotals(rows);
  main.innerHTML=`${pageHeader('اليوم',dateLabel(today))}
  <section class="hero-card"><div><span class="eyebrow">الصيدلية الأساسية</span><h2>${esc(primary()?.name||'—')}</h2><p>${dateLabel(today)}</p></div><div class="hero-plus">✚</div></section>
  <section class="shift-card"><div class="section-title"><h3>بيانات الشيفت</h3><span class="soft-pill">تُحفظ مع كل حركة</span></div>
    <div class="form-grid"><label>الشيفت<select id="dayShift"><option value="Morning">Morning</option><option value="Afternoon">Afternoon</option><option value="Night">Night</option></select></label>
    <label>مسؤول الشيفت<input id="dayManager" placeholder="اكتب اسم المسؤول" value="${esc(state.dayManager)}"></label></div></section>
  <div class="section-title"><h3>ملخص اليوم</h3><span class="muted">${rows.length} حركة</span></div>
  <div class="stats-grid"><div class="stat-card"><span>الوارد</span><strong class="green">${money(totals.incoming)}</strong></div><div class="stat-card"><span>الصادر</span><strong class="orange">${money(totals.outgoing)}</strong></div></div>
  <button class="btn primary add-button" id="addMovement">＋ إضافة حركة</button>
  <div class="section-title list-title"><h3>حركات اليوم</h3></div>
  <div class="movement-list">${rows.length?rows.map(movementCard).join(''):`<div class="empty-state"><div>▤</div><strong>لا توجد حركات مسجلة اليوم</strong><p>ابدأ بإضافة أول حركة بين الفروع.</p></div>`}</div>`;
  $('#dayShift').value=state.dayShift;$('#dayShift').onchange=e=>state.dayShift=e.target.value;
  $('#dayManager').oninput=e=>state.dayManager=e.target.value;
  $('#addMovement').onclick=()=>openMovementForm();
  bindCards();
}
function movementCard(m){
 return `<article class="movement-card" data-open="${m.id}"><div class="movement-top"><span class="type-chip ${typeClass(m.type)}">${typeLabel(m.type)}</span><span class="movement-time">${shiftLabel(m.shift)} · ${esc(m.manager||'—')}</span></div>
 <div class="movement-middle"><div><strong>${esc(pharmacyName(m.pharmacyId))}</strong><small>رقم الحركة: ${esc(m.code)}</small></div><strong class="amount">${money(m.amount)}</strong></div>
 <div class="movement-bottom"><span>${m.items.length?`<span class="dot"></span>${m.items.length} أصناف`:'بدون تفاصيل أدوية'}</span><span>التفاصيل ←</span></div></article>`;
}
function bindCards(){$$('[data-open]').forEach(el=>el.onclick=()=>{state.detailId=el.dataset.open;state.page='details';render()})}
function openMovementForm(m=null){
 const editing=!!m,options=activePharmacies().filter(p=>p.id!==state.primaryId);
 modalRoot.innerHTML=`<div class="overlay"><section class="modal"><div class="modal-head"><div><h2>${editing?'تعديل الحركة':'إضافة حركة جديدة'}</h2><p>الحقول الأساسية لتسجيل حركة بين فرعين</p></div><button class="close" data-close>×</button></div>
 <form id="movementForm"><div class="segmented"><label><input type="radio" name="type" value="in" ${!m||m.type==='in'?'checked':''}><span>وارد إلينا</span></label><label><input type="radio" name="type" value="out" ${m?.type==='out'?'checked':''}><span>صادر منا</span></label></div>
 <label>الصيدلية الأخرى<select name="pharmacyId" required>${options.map(p=>`<option value="${p.id}" ${m?.pharmacyId===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}</select></label>
 <div class="form-grid"><label>التاريخ<input type="date" name="date" value="${m?.date||today}" required></label><label>الشيفت<select name="shift"><option value="Morning">Morning</option><option value="Afternoon">Afternoon</option><option value="Night">Night</option></select></label></div>
 <label>مسؤول الشيفت<input name="manager" value="${esc(m?.manager||state.dayManager)}" placeholder="اسم المسؤول"></label>
 <label>إجمالي قيمة الحركة (جنيه)<input name="amount" type="number" min="0" step="0.01" value="${m?.amount??''}" required placeholder="0.00"></label>
 <label>ملاحظات <span class="muted">(اختياري)</span><textarea name="notes" rows="2">${esc(m?.notes||'')}</textarea></label>
 <div class="form-actions"><button type="button" class="btn light" data-close>إلغاء</button><button class="btn primary">${editing?'حفظ التعديلات':'حفظ الحركة'}</button></div></form></section></div>`;
 const form=$('#movementForm');form.elements.shift.value=m?.shift||state.dayShift;
 $$('[data-close]').forEach(b=>b.onclick=()=>modalRoot.innerHTML='');
 form.onsubmit=async e=>{e.preventDefault();const fd=new FormData(form),amount=Number(fd.get('amount'));if(!Number.isFinite(amount)||amount<0){toast('أدخل قيمة صحيحة');return}
  const movement={...(m||{}),id:m?.id||uid(),code:m?.code||`SY-${Date.now().toString().slice(-8)}`,type:fd.get('type'),pharmacyId:fd.get('pharmacyId'),date:fd.get('date'),shift:fd.get('shift'),manager:String(fd.get('manager')).trim(),amount,notes:String(fd.get('notes')).trim(),items:m?.items||[],createdAt:m?.createdAt||Date.now(),updatedAt:Date.now()};
  await put('movements',movement);modalRoot.innerHTML='';await refresh();toast('تم حفظ الحركة');};
}
function renderDetails(){
 const m=state.movements.find(x=>x.id===state.detailId);if(!m){setPage('day');return}
 const items=m.items||[],calculated=itemTotal(items),diff=calculated-Number(m.amount);
 main.innerHTML=`<button class="back-link" id="backDay">← العودة</button>${pageHeader('تفاصيل الحركة',`رقم الحركة ${m.code}`)}
 <section class="detail-summary"><div class="movement-top"><span class="type-chip ${typeClass(m.type)}">${typeLabel(m.type)}</span><span class="soft-pill">${dateLabel(m.date)}</span></div><h2>${esc(pharmacyName(m.pharmacyId))}</h2><div class="detail-amount">${money(m.amount)}</div><div class="detail-meta"><span>${shiftLabel(m.shift)}</span><span>المسؤول: ${esc(m.manager||'—')}</span></div>${m.notes?`<p class="notes">${esc(m.notes)}</p>`:''}</section>
 <div class="section-title"><div><h3>تفاصيل الأدوية</h3><p>إضافة الأصناف اختيارية تمامًا</p></div><button class="btn small primary" id="addItem">＋ صنف</button></div>
 <div class="items-list">${items.length?items.map((it,i)=>`<div class="item-card"><div><strong>${esc(it.name)}</strong><small>${it.quantity} × ${money(it.unitPrice)}</small></div><strong>${money(Number(it.quantity)*Number(it.unitPrice))}</strong><button class="tiny-icon" data-edit-item="${i}" aria-label="تعديل الصنف">✎</button><button class="tiny-icon danger" data-delete-item="${i}" aria-label="حذف الصنف">×</button></div>`).join(''):`<div class="empty-inline">لم تتم إضافة أصناف لهذه الحركة.</div>`}</div>
 <section class="reconcile-card"><div><span>إجمالي تفاصيل الأصناف</span><strong>${money(calculated)}</strong></div><div><span>قيمة الحركة المعتمدة</span><strong>${money(m.amount)}</strong></div><div class="reconcile-result ${Math.abs(diff)<0.005?'ok':'warn'}">${Math.abs(diff)<0.005?'✓ الإجماليان متطابقان':`⚠ الفرق ${money(Math.abs(diff))} ${diff>0?'زيادة في الأصناف':'نقص في الأصناف'}`}</div></section>
 <div class="detail-actions"><button class="btn light" id="editMovement">تعديل الحركة</button><button class="btn danger-outline" id="deleteMovement">حذف الحركة</button></div>`;
 $('#backDay').onclick=()=>setPage('day');$('#addItem').onclick=()=>openItemForm(m);
 $$('[data-edit-item]').forEach(b=>b.onclick=()=>openItemForm(m,Number(b.dataset.editItem)));
 $$('[data-delete-item]').forEach(b=>b.onclick=async()=>{if(!confirm('هل تريد حذف هذا الصنف؟'))return;m.items.splice(Number(b.dataset.deleteItem),1);await put('movements',m);await refresh();state.page='details';state.detailId=m.id;render()});
 $('#editMovement').onclick=()=>openMovementForm(m);
 $('#deleteMovement').onclick=async()=>{if(confirm('هل أنت متأكد من حذف الحركة نهائيًا؟ سيتم تحديث التقارير.')){await remove('movements',m.id);state.page='day';await refresh();toast('تم حذف الحركة')}};
}
function openItemForm(m,index=null){
 const old=index===null?null:m.items[index];
 modalRoot.innerHTML=`<div class="overlay"><section class="modal"><div class="modal-head"><div><h2>${old?'تعديل صنف':'إضافة صنف دواء'}</h2><p>يُحسب إجمالي الصنف تلقائيًا</p></div><button class="close" data-close>×</button></div>
 <form id="itemForm"><label>اسم الدواء<input name="name" required value="${esc(old?.name||'')}" placeholder="اسم الصنف"></label><div class="form-grid"><label>الكمية<input name="quantity" type="number" min="0.001" step="any" required value="${old?.quantity??''}"></label><label>سعر الوحدة (جنيه)<input name="unitPrice" type="number" min="0" step="0.01" required value="${old?.unitPrice??''}"></label></div><div class="live-total">إجمالي الصنف <strong id="liveItemTotal">${money((old?.quantity||0)*(old?.unitPrice||0))}</strong></div><div class="form-actions"><button type="button" class="btn light" data-close>إلغاء</button><button class="btn primary">حفظ الصنف</button></div></form></section></div>`;
 const f=$('#itemForm'),update=()=>$('#liveItemTotal').textContent=money(Number(f.elements.quantity.value)*Number(f.elements.unitPrice.value));
 f.elements.quantity.oninput=update;f.elements.unitPrice.oninput=update;
 $$('[data-close]').forEach(b=>b.onclick=()=>modalRoot.innerHTML='');
 f.onsubmit=async e=>{e.preventDefault();const item={name:f.elements.name.value.trim(),quantity:Number(f.elements.quantity.value),unitPrice:Number(f.elements.unitPrice.value)};if(!item.name||item.quantity<=0||item.unitPrice<0){toast('راجع بيانات الصنف');return}
 if(index===null)m.items.push(item);else m.items[index]=item; m.updatedAt=Date.now();await put('movements',m);modalRoot.innerHTML='';await refresh();state.page='details';state.detailId=m.id;render();toast('تم حفظ الصنف');};
}
function renderMonth(){
 const [start,end]=monthRange(state.selectedYear,state.selectedMonth),rows=state.movements.filter(m=>m.date>=start&&m.date<=end),t=movementTotals(rows),breakdown=pharmacyBreakdown(rows,state.pharmacies);
 main.innerHTML=`${pageHeader('التقرير الشهري','الوارد والصادر يُعرضان بشكل مستقل دون مقاصة')}
 <section class="period-picker"><label>الشهر<select id="monthSelect">${Array.from({length:12},(_,i)=>`<option value="${i+1}">${new Intl.DateTimeFormat('ar-EG',{month:'long'}).format(new Date(2025,i,1))}</option>`).join('')}</select></label><label>السنة<select id="monthYear">${yearOptions(state.selectedYear)}</select></label></section>
 <div class="stats-grid report-stats"><div class="stat-card"><span>إجمالي الوارد</span><strong class="green">${money(t.incoming)}</strong><small>${t.incomingCount} حركة واردة</small></div><div class="stat-card"><span>إجمالي الصادر</span><strong class="orange">${money(t.outgoing)}</strong><small>${t.outgoingCount} حركة صادرة</small></div></div>
 <div class="section-title"><h3>كشف الصيدليات</h3><span class="muted">${breakdown.length} صيدلية نشطة بالحركات</span></div>
 <div class="pharmacy-list">${breakdown.length?breakdown.map(x=>`<button class="pharmacy-card" data-pharmacy="${x.pharmacy.id}"><div class="pharmacy-avatar">✚</div><div class="pharmacy-info"><strong>${esc(x.pharmacy.name)}</strong><small>وارد ${x.incomingCount} · صادر ${x.outgoingCount} · ${x.count} حركة</small></div><div class="pharmacy-values"><b class="green">${money(x.incoming)}</b><b class="orange">${money(x.outgoing)}</b></div><span class="chevron">‹</span></button>`).join(''):`<div class="empty-state"><div>▤</div><strong>لا توجد حركات في هذا الشهر</strong></div>`}</div>
 <div class="export-row"><button class="btn light" id="monthCsv">تصدير CSV</button><button class="btn light" id="monthExcel">تصدير Excel</button></div>`;
 $('#monthSelect').value=state.selectedMonth;$('#monthYear').value=state.selectedYear;
 $('#monthSelect').onchange=e=>{state.selectedMonth=Number(e.target.value);renderMonth()};
 $('#monthYear').onchange=e=>{state.selectedYear=Number(e.target.value);renderMonth()};
 $$('[data-pharmacy]').forEach(b=>b.onclick=()=>{state.monthPharmacy=b.dataset.pharmacy;renderPharmacyMonth(start,end)});
 $('#monthCsv').onclick=()=>exportReport(rows,`تقرير-${state.selectedYear}-${String(state.selectedMonth).padStart(2,'0')}.csv`,'csv');
 $('#monthExcel').onclick=()=>exportReport(rows,`تقرير-${state.selectedYear}-${String(state.selectedMonth).padStart(2,'0')}.xls`,'xls');
}
function renderPharmacyMonth(start,end){
 const p=state.pharmacies.find(x=>x.id===state.monthPharmacy);if(!p){state.monthPharmacy=null;renderMonth();return}
 const rows=sortMovements(state.movements.filter(m=>m.pharmacyId===p.id&&m.date>=start&&m.date<=end));
 main.innerHTML=`<button class="back-link" id="backMonth">← كشف كل الصيدليات</button>${pageHeader(p.name,'حركات الصيدلية خلال الشهر المحدد')}
 <div class="movement-list">${rows.length?rows.map(movementCard).join(''):`<div class="empty-state">لا توجد حركات</div>`}</div>`;
 $('#backMonth').onclick=()=>{state.monthPharmacy=null;renderMonth()};bindCards();
}
function yearOptions(selected){const now=new Date().getFullYear();return Array.from({length:9},(_,i)=>now-5+i).map(y=>`<option value="${y}" ${y===selected?'selected':''}>${y}</option>`).join('')}
function renderYear(){
 const y=state.selectedYear,rows=state.movements.filter(m=>m.date.startsWith(`${y}-`)),t=movementTotals(rows),breakdown=pharmacyBreakdown(rows,state.pharmacies);
 const months=Array.from({length:12},(_,i)=>{const n=i+1,[a,b]=monthRange(y,n),r=rows.filter(m=>m.date>=a&&m.date<=b),x=movementTotals(r);return {n,...x}});
 main.innerHTML=`${pageHeader('التقرير السنوي','ملخص الحركات المسجلة خلال السنة')}
 <section class="period-picker single"><label>السنة<select id="yearSelect">${yearOptions(y)}</select></label></section>
 <div class="stats-grid report-stats"><div class="stat-card"><span>إجمالي الوارد السنوي</span><strong class="green">${money(t.incoming)}</strong><small>${t.incomingCount} حركة واردة</small></div><div class="stat-card"><span>إجمالي الصادر السنوي</span><strong class="orange">${money(t.outgoing)}</strong><small>${t.outgoingCount} حركة صادرة</small></div></div>
 <div class="stats-grid compact-stats"><div class="stat-card"><span>إجمالي الحركات</span><strong>${t.count}</strong></div><div class="stat-card"><span>عدد الصيدليات</span><strong>${breakdown.length}</strong></div></div>
 <div class="section-title"><h3>التقرير الشهري</h3><span class="muted">اضغط على شهر لعرض تفاصيله</span></div>
 <div class="months-grid">${months.map(m=>`<button class="month-card" data-month="${m.n}"><strong>${new Intl.DateTimeFormat('ar-EG',{month:'long'}).format(new Date(y,m.n-1,1))}</strong><span>${m.count} حركة</span><div><small class="green">وارد ${money(m.incoming)}</small><small class="orange">صادر ${money(m.outgoing)}</small></div></button>`).join('')}</div>
 <div class="section-title"><h3>كشف الصيدليات السنوي</h3></div>
 <div class="pharmacy-list">${breakdown.length?breakdown.map(x=>`<div class="pharmacy-card static"><div class="pharmacy-avatar">✚</div><div class="pharmacy-info"><strong>${esc(x.pharmacy.name)}</strong><small>${x.incomingCount} وارد · ${x.outgoingCount} صادر</small></div><div class="pharmacy-values"><b class="green">${money(x.incoming)}</b><b class="orange">${money(x.outgoing)}</b></div></div>`).join(''):`<div class="empty-inline">لا توجد حركات خلال هذه السنة.</div>`}</div>
 <div class="export-row"><button class="btn light" id="yearCsv">تصدير CSV</button><button class="btn light" id="yearExcel">تصدير Excel</button></div>`;
 $('#yearSelect').onchange=e=>{state.selectedYear=Number(e.target.value);renderYear()};
 $$('[data-month]').forEach(b=>b.onclick=()=>{state.selectedMonth=Number(b.dataset.month);setPage('month')});
 $('#yearCsv').onclick=()=>exportReport(rows,`تقرير-سنوي-${y}.csv`,'csv');$('#yearExcel').onclick=()=>exportReport(rows,`تقرير-سنوي-${y}.xls`,'xls');
}
function renderSettings(){
 main.innerHTML=`${pageHeader('الإعدادات','إدارة الفروع والبيانات')}
 <section class="settings-section"><div class="section-title"><h3>الصيدليات التابعة للمجموعة</h3><button class="btn small primary" id="addPharmacy">＋ إضافة</button></div>
 <div class="pharmacy-list">${state.pharmacies.map(p=>`<div class="settings-pharmacy"><div class="pharmacy-avatar">✚</div><div class="pharmacy-info"><strong>${esc(p.name)} ${p.isPrimary?'<span class="soft-pill">أساسية</span>':''}</strong><small>${p.active?'نشطة':'متوقفة عن الحركات الجديدة'}</small></div><button class="tiny-icon" data-rename="${p.id}" title="تعديل الاسم">✎</button>${!p.isPrimary?`<button class="tiny-icon ${p.active?'danger':''}" data-toggle="${p.id}" title="${p.active?'إيقاف':'تفعيل'}">${p.active?'Ⅱ':'▶'}</button>`:''}</div>`).join('')}</div></section>
 <section class="settings-section"><div class="section-title"><h3>النسخ الاحتياطي</h3></div><p class="muted">احفظ نسخة كاملة من الفروع والحركات والأصناف، أو استعد نسخة سابقة.</p><div class="backup-actions"><button class="btn primary" id="exportBackup">⇩ تصدير نسخة احتياطية</button><label class="btn light file-button">⇧ استيراد نسخة احتياطية<input type="file" id="importBackup" accept=".json,application/json" hidden></label></div></section>
 <section class="settings-section"><div class="section-title"><h3>بيانات التقارير</h3></div><p class="muted">يمكن تصدير تقارير الشهر أو السنة بصيغة CSV أو Excel من صفحات التقارير.</p><div class="storage-note">✓ تُحفظ البيانات محليًا على هذا الجهاز باستخدام IndexedDB، ولا تُرسل إلى خادم خارجي.</div></section>`;
 $('#addPharmacy').onclick=()=>pharmacyForm();
 $$('[data-rename]').forEach(b=>b.onclick=()=>pharmacyForm(state.pharmacies.find(p=>p.id===b.dataset.rename)));
 $$('[data-toggle]').forEach(b=>b.onclick=async()=>{const p=state.pharmacies.find(x=>x.id===b.dataset.toggle);p.active=!p.active;await put('pharmacies',p);await refresh();toast(p.active?'تم تفعيل الصيدلية':'تم إيقاف الصيدلية مع الاحتفاظ بسجلاتها')});
 $('#exportBackup').onclick=exportBackup;$('#importBackup').onchange=e=>importBackup(e.target.files[0]);
}
function pharmacyForm(p=null){
 modalRoot.innerHTML=`<div class="overlay"><section class="modal"><div class="modal-head"><h2>${p?'تعديل اسم الصيدلية':'إضافة صيدلية'}</h2><button class="close" data-close>×</button></div><form id="pharmacyForm"><label>اسم الصيدلية<input name="name" required maxlength="80" value="${esc(p?.name||'')}" placeholder="اسم الفرع"></label><div class="form-actions"><button type="button" class="btn light" data-close>إلغاء</button><button class="btn primary">حفظ</button></div></form></section></div>`;
 $$('[data-close]').forEach(b=>b.onclick=()=>modalRoot.innerHTML='');
 $('#pharmacyForm').onsubmit=async e=>{e.preventDefault();const name=new FormData(e.currentTarget).get('name').trim();if(!name)return;await put('pharmacies',{...(p||{}),id:p?.id||uid(),name,active:p?.active??true,isPrimary:p?.isPrimary??false,createdAt:p?.createdAt||Date.now()});modalRoot.innerHTML='';await refresh();toast('تم حفظ بيانات الصيدلية')};
}
function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function csvCell(v){return `"${String(v??'').replace(/"/g,'""')}"`}
function exportReport(rows,filename,format){
 const data=[['رقم الحركة','التاريخ','النوع','الصيدلية','الشيفت','المسؤول','قيمة الحركة بالجنيه','عدد الأصناف','ملاحظات'],...rows.map(m=>[m.code,m.date,typeLabel(m.type),pharmacyName(m.pharmacyId),shiftLabel(m.shift),m.manager,m.amount,m.items.length,m.notes])];
 if(format==='csv'){download(new Blob(['\ufeff'+data.map(r=>r.map(csvCell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}),filename)}
 else {const html=`<html><head><meta charset="utf-8"></head><body><table dir="rtl" border="1">${data.map((r,i)=>`<tr>${r.map(c=>`<${i?'td':'th'}>${esc(c)}</${i?'td':'th'}>`).join('')}</tr>`).join('')}</table></body></html>`;download(new Blob([html],{type:'application/vnd.ms-excel;charset=utf-8'}),filename)}
 toast('تم تجهيز التقرير للتصدير');
}
async function exportBackup(){
 const data={schema:'saydalia-backup-v1',app:'صيدلية',exportedAt:new Date().toISOString(),pharmacies:state.pharmacies,movements:state.movements};
 download(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),`Saydalia-backup-${today}.json`);toast('تم تصدير النسخة الاحتياطية');
}
async function importBackup(file){
 if(!file)return;
 try{const data=JSON.parse(await file.text());validateBackup(data);if(!confirm(`سيتم استبدال جميع البيانات الحالية بـ ${data.pharmacies.length} صيدلية و${data.movements.length} حركة. هل تريد المتابعة؟`))return;
  await replaceAll(data.pharmacies,data.movements,{primaryId:data.pharmacies.find(p=>p.isPrimary)?.id||data.pharmacies[0]?.id});await refresh();toast('تمت استعادة النسخة الاحتياطية بنجاح');
 }catch(e){alert(e.message||'تعذر قراءة النسخة الاحتياطية.');}
}
$('#backupQuick').onclick=()=>{setPage('settings');setTimeout(exportBackup,0)};
$$('.nav-item').forEach(b=>b.onclick=()=>setPage(b.dataset.page));
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();state.installPrompt=e});
init().catch(e=>{console.error(e);main.innerHTML='<div class="empty-state">حدث خطأ في فتح قاعدة البيانات. افتح التطبيق من خلال خادم محلي أو HTTPS.</div>'});
