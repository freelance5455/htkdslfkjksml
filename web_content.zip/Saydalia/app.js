const $=s=>document.querySelector(s),esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const p2=n=>String(n).padStart(2,'0'),money=n=>(+n).toLocaleString('ar-EG',{maximumFractionDigits:2})+' ج.م',num=n=>(+n).toLocaleString('ar-EG');
const todayStr=()=>{const d=new Date();return d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate())};
const MN=['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const SH={Morning:'Morning — صباحي',Afternoon:'Afternoon — مسائي',Night:'Night — ليلي'};
const DB=(()=>{let db;const q=(s,m,f)=>new Promise((res,rej)=>{const r=f(db.transaction(s,m).objectStore(s));r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
 return{open:()=>new Promise((res,rej)=>{const r=indexedDB.open('saydalia',1);r.onupgradeneeded=()=>{const d=r.result;d.createObjectStore('settings',{keyPath:'k'});d.createObjectStore('pharmacies',{keyPath:'id',autoIncrement:true});d.createObjectStore('moves',{keyPath:'id',autoIncrement:true})};r.onsuccess=()=>{db=r.result;res()};r.onerror=()=>rej(r.error)}),
 all:s=>q(s,'readonly',o=>o.getAll()),get:(s,k)=>q(s,'readonly',o=>o.get(k)),put:(s,v)=>q(s,'readwrite',o=>o.put(v)),del:(s,k)=>q(s,'readwrite',o=>o.delete(k)),
 restore:d=>new Promise((res,rej)=>{const t=db.transaction(['settings','pharmacies','moves'],'readwrite');['pharmacies','moves'].forEach(s=>{t.objectStore(s).clear();d[s].forEach(v=>t.objectStore(s).put(v))});t.objectStore('settings').put({k:'main',name:d.settings.name,shift:d.settings.shift||'Morning',manager:d.settings.manager||''});t.oncomplete=res;t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error)})}})();
let S={st:null,ph:[],moves:[]},cur=null,lastHash='#/day';
const phName=id=>(S.ph.find(p=>p.id===id)||{name:'(غير معروفة)'}).name;
async function load(){S.st=(await DB.get('settings','main'))||null;S.ph=await DB.all('pharmacies');S.moves=await DB.all('moves')}
const app=h=>{$('#app').innerHTML=h;window.scrollTo(0,0)};
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('on');setTimeout(()=>e.classList.remove('on'),1800)}
function dl(name,blob){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000)}
const head=(t,sub,left)=>`<header class="top"><div><h1>${t}</h1>${sub?'<small>'+sub+'</small>':''}</div><span class="hr">${left||''}<button type="button" class="th" onclick="toggleTheme()" aria-label="تبديل الوضع">🌓</button></span></header>`;
const card=m=>`<a class="card mv ${m.type}" href="#/move/${m.id}"><div class="r"><b>${m.type==='in'?'⬇️ وارد':'⬆️ صادر'} · ${esc(phName(m.pid))}</b><b>${money(m.amount)}</b></div><div class="s">#${m.id} · ${m.date}${m.time?' '+m.time:''} · ${m.shift}${m.manager?' · '+esc(m.manager):''}${(m.items||[]).length?' · '+num(m.items.length)+' صنف':''}</div></a>`;
const tot=s=>`<div class="tot"><div class="card"><span>إجمالي الوارد (أخذنا)</span><b>${money(s.inTotal)}</b><span>${num(s.inCount)} حركة</span></div><div class="card"><span>إجمالي الصادر (أعطينا)</span><b>${money(s.outTotal)}</b><span>${num(s.outCount)} حركة</span></div></div>`;
function route(){const h=location.hash.slice(2).split('/'),v=h[0]||'day';$('#nav').hidden=!(S.st&&S.st.name);
 if(!S.st||!S.st.name)return viewSetup();
 if(v!=='move')lastHash=location.hash||'#/day';
 document.querySelectorAll('#nav a').forEach(a=>a.classList.toggle('on',a.dataset.v===v));
 ({day:viewDay,month:viewMonth,year:viewYear,move:viewMove,plan:viewPlan,settings:viewSettings}[v]||viewDay)(h.slice(1))}
function viewSetup(){app(head('مرحبًا بك في صيدلية','الإعداد الأولي')+`<div class="pad"><label>اسم الصيدلية الأساسية<input id="mn" placeholder="مثال: صيدلية الشفاء"></label><label>أسماء الصيدليات الأخرى في المجموعة (اسم في كل سطر)<textarea id="pl" rows="5"></textarea></label><button class="primary" id="go">ابدأ الاستخدام</button></div>`);
 $('#go').onclick=async()=>{const n=$('#mn').value.trim();if(!n)return alert('اكتب اسم الصيدلية الأساسية');
  await DB.put('settings',{k:'main',name:n,shift:'Morning',manager:''});
  const seen=new Set();for(const l of $('#pl').value.split('\n').map(x=>x.trim()).filter(Boolean)){if(!seen.has(l)){seen.add(l);await DB.put('pharmacies',{name:l,active:true})}}
  await load();location.hash='#/day';route()}}
function viewDay(){const t=todayStr(),[y,m,d]=t.split('-'),ms=S.moves.filter(x=>x.date===t).sort((a,b)=>b.id-a.id);
 app(head(esc(S.st.name),new Date(+y,m-1,+d).toLocaleDateString('ar-EG',{weekday:'long',day:'numeric',month:'long',year:'numeric'}),'<a class="ic" href="#/settings">⚙️</a>')+
 `<div class="pad"><label>الشيفت<select id="sh">${Object.keys(SH).map(k=>`<option value="${k}" ${S.st.shift===k?'selected':''}>${SH[k]}</option>`).join('')}</select></label><label>مسؤول الشيفت<input id="mg" value="${esc(S.st.manager)}" placeholder="اكتب الاسم"></label>${tot(L.stats(ms))}<h2>حركات اليوم</h2>${ms.length?ms.map(card).join(''):'<div class="empty">لا توجد حركات اليوم. اضغط «إضافة حركة».</div>'}</div><a class="fab" href="#/move/new">➕ إضافة حركة</a>`);
 const sv=async()=>{S.st={...S.st,shift:$('#sh').value,manager:$('#mg').value.trim()};await DB.put('settings',S.st)};$('#sh').onchange=sv;$('#mg').onchange=sv}
function viewMove(a){const id=a[0];
 if(id==='new'){const act=S.ph.filter(p=>p.active);if(!act.length){alert('أضف صيدلية أخرى أولًا من الإعدادات');location.hash='#/settings';return}
  cur={type:'in',pid:act[0].id,date:todayStr(),shift:S.st.shift,manager:S.st.manager,amount:'',notes:'',items:[],mode:'brief',time:''}}
 else{const m=S.moves.find(x=>x.id==id);if(!m){location.hash='#/day';return}cur=JSON.parse(JSON.stringify(m));cur.items=cur.items||[];cur.mode=cur.mode||(cur.items.length?'detailed':'brief');cur.time=cur.time||''}
 renderMove()}
const itemRow=(it,i)=>`<div class="item"><input class="iname" placeholder="اسم الدواء" value="${esc(it.name)}"><div class="g"><input class="iqty" type="number" inputmode="decimal" step="any" min="0" placeholder="الكمية" value="${esc(it.qty)}"><input class="iprice" type="number" inputmode="decimal" step="any" min="0" placeholder="سعر الوحدة" value="${esc(it.price)}"><output>${money(L.lineTotal(it))}</output><button type="button" class="x" data-rm="${i}">حذف الصنف ✕</button></div></div>`;
function renderMove(){const opts=S.ph.filter(p=>p.active||p.id===cur.pid),det=cur.mode==='detailed';
 app(head(cur.id?'تفاصيل الحركة #'+cur.id:'إضافة حركة','',`<a class="ic" href="${lastHash}">↩️</a>`)+`<form id="f" class="pad" onsubmit="return false">
<div class="seg"><button type="button" data-type="in" class="${cur.type==='in'?'on':''}">⬇️ وارد إلينا</button><button type="button" data-type="out" class="${cur.type==='out'?'on':''}">⬆️ صادر منا</button></div>
<label>الصيدلية الأخرى<select id="pid">${opts.map(p=>`<option value="${p.id}" ${p.id===cur.pid?'selected':''}>${esc(p.name)}${p.active?'':' (متوقفة)'}</option>`).join('')}</select></label>
<label>التاريخ<input type="date" id="date" value="${cur.date}"></label>
<div class="two"><label>الشيفت<select id="shift">${Object.keys(SH).map(k=>`<option value="${k}" ${cur.shift===k?'selected':''}>${SH[k]}</option>`).join('')}</select></label><label>الوقت (اختياري)<input type="time" id="time" value="${esc(cur.time)}"></label></div>
<label>مسؤول الشيفت<input id="manager" value="${esc(cur.manager)}"></label>
<h2>طريقة التسجيل</h2><div class="seg"><button type="button" data-mode="brief" class="${det?'':'on'}">⚡ مختصر</button><button type="button" data-mode="detailed" class="${det?'on':''}">📋 تفصيلي</button></div>
${det?`<h2>الأدوية</h2><div id="items">${cur.items.map(itemRow).join('')}</div><button type="button" id="add">➕ إضافة صنف</button><div id="cmp" class="card"></div>`:`<label>إجمالي قيمة الحركة (جنيه) — اكتب السعر فقط<input id="amount" type="number" inputmode="decimal" step="any" min="0" value="${esc(cur.amount)}"></label>`}
<label>ملاحظات (اختياري)<textarea id="notes" rows="2">${esc(cur.notes)}</textarea></label>
<button class="primary" id="save">💾 حفظ الحركة</button>${cur.id?'<button type="button" class="danger" id="del">🗑️ حذف الحركة</button>':''}</form>`);
 const f=$('#f');updCmp();f.oninput=()=>{readForm();updCmp()};
 f.onclick=e=>{const b=e.target.closest('button');if(!b)return;
  if(b.dataset.type){readForm();cur.type=b.dataset.type;renderMove()}
  else if(b.dataset.mode){readForm();if(b.dataset.mode==='detailed'&&!cur.items.length)cur.items.push({name:'',qty:'',price:''});if(b.dataset.mode==='brief'&&!(+cur.amount)){const t=L.itemsTotal(cur.items);if(t)cur.amount=t}cur.mode=b.dataset.mode;renderMove()}
  else if(b.id==='add'){readForm();cur.items.push({name:'',qty:'',price:''});renderMove()}
  else if(b.dataset.rm!==undefined){readForm();cur.items.splice(+b.dataset.rm,1);renderMove()}
  else if(b.id==='save')save();else if(b.id==='del')del()}}
function readForm(){cur.pid=+$('#pid').value;cur.date=$('#date').value;cur.shift=$('#shift').value;cur.time=$('#time').value;cur.manager=$('#manager').value;cur.notes=$('#notes').value;
 if(cur.mode==='detailed')cur.items=[...document.querySelectorAll('.item')].map(e=>({name:e.querySelector('.iname').value,qty:e.querySelector('.iqty').value,price:e.querySelector('.iprice').value}));else cur.amount=$('#amount').value}
function updCmp(){if(cur.mode!=='detailed')return;document.querySelectorAll('.item').forEach((e,i)=>e.querySelector('output').textContent=money(L.lineTotal(cur.items[i])));
 const its=cur.items.filter(i=>i.name.trim());$('#cmp').textContent='🧮 إجمالي الحركة (يُحسب تلقائيًا): '+money(L.itemsTotal(its))+' — '+num(its.length)+' صنف'}
async function save(){readForm();const det=cur.mode==='detailed',items=det?cur.items.filter(i=>i.name.trim()).map(i=>({name:i.name.trim(),qty:+i.qty||0,price:+i.price||0})):[];
 if(!cur.pid)return alert('اختر الصيدلية الأخرى');if(!cur.date)return alert('اختر التاريخ');
 if(det&&!items.length)return alert('أضف صنفًا واحدًا على الأقل، أو اختر «مختصر»');
 const amt=det?L.itemsTotal(items):parseFloat(cur.amount);if(!(amt>0))return alert('أدخل قيمة صحيحة للحركة (أكبر من صفر)');
 const m={type:cur.type,pid:cur.pid,date:cur.date,time:cur.time||'',shift:cur.shift,manager:cur.manager.trim(),mode:cur.mode,amount:L.r2(amt),notes:cur.notes.trim(),items};if(cur.id)m.id=cur.id;
 await DB.put('moves',m);await load();toast('تم الحفظ');location.hash=lastHash;route()}
async function del(){if(!confirm('حذف هذه الحركة وكل أصنافها نهائيًا؟'))return;await DB.del('moves',cur.id);await load();toast('تم الحذف');location.hash=lastHash;route()}
function viewPlan(a){const ym=a[0]||todayStr().slice(0,7),pid=a[1],all=L.inMonth(S.moves,ym),y=+ym.slice(0,4),mo=+ym.slice(5)-1,nd=new Date(y,mo+1,0).getDate(),
 wd=d=>new Date(y,mo,d).toLocaleDateString('ar-EG',{weekday:'long'}),ms=pid?all.filter(m=>m.pid==pid):all,s=L.stats(ms),t=todayStr();
 const day=d=>{const ds=ms.filter(m=>+m.date.slice(8)===d).sort((p,q)=>(p.time||'').localeCompare(q.time||'')||p.id-q.id),z=L.stats(ds);
  if(!ds.length)return pid?'':`<div class="card off"><div class="r"><b>${num(d)} ${MN[mo]}</b><span>${wd(d)}</span></div></div>`;
  return `<details class="card ${ym+'-'+p2(d)===t?'today':''}"><summary><div class="r"><b>${num(d)} ${MN[mo]} — ${wd(d)}</b><span>${num(z.count)} حركة</span></div><div class="s">⬆️ صادر منا: ${num(z.outCount)} حركة · ${money(z.outTotal)}</div><div class="s">⬇️ وارد إلينا: ${num(z.inCount)} حركة · ${money(z.inTotal)}</div></summary>${ds.map(m=>card(m)).join('')}</details>`};
 const days=Array.from({length:nd},(_,i)=>day(i+1)).join('');
 const top=`<label>الشهر<input type="month" id="pp" value="${ym}"></label>`+(pid?`<label>الصيدلية<select id="pps">${S.ph.map(p=>`<option value="${p.id}" ${p.id==pid?'selected':''}>${esc(p.name)}${p.active?'':' (متوقفة)'}</option>`).join('')}</select></label>`:'');
 const phs=pid?'':`<h2>تخطيط كل صيدلية</h2>${S.ph.map(p=>{const z=L.stats(all.filter(m=>m.pid===p.id));return `<a class="card" href="#/plan/${ym}/${p.id}"><div class="r"><b>${esc(p.name)}</b><span>${num(z.count)} حركة</span></div><div class="s">⬆️ صادر منا: ${num(z.outCount)} · ${money(z.outTotal)}  |  ⬇️ وارد إلينا: ${num(z.inCount)} · ${money(z.inTotal)}</div></a>`}).join('')||'<div class="empty">أضف صيدليات من الإعدادات</div>'}`;
 app(head(pid?'تخطيط: '+esc(phName(+pid)):'تخطيط الشهر',MN[mo]+' '+y,pid?`<a class="ic" href="#/plan/${ym}">↩️</a>`:'<a class="ic" href="#/settings">⚙️</a>')+`<div class="pad">${top}${tot(s)}<div class="card"><div class="r"><span>عدد الحركات الإجمالي</span><b>${num(s.count)}</b></div></div>${phs}<h2>${pid?'الأيام التي بها حركات':'تفاصيل الأيام'}</h2>${days||'<div class="empty">لا توجد حركات لهذه الصيدلية في هذا الشهر</div>'}</div>`);
 $('#pp').onchange=e=>{if(e.target.value)location.hash='#/plan/'+e.target.value+(pid?'/'+pid:'')};
 if(pid)$('#pps').onchange=e=>location.hash='#/plan/'+ym+'/'+e.target.value}
window.toggleTheme=()=>{const n=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=n;try{localStorage.setItem('theme',n)}catch(e){}};
const expBtns=(s,k)=>`<div class="row"><button onclick="exp('xlsx','${s}','${k}')">📗 تصدير Excel</button><button onclick="exp('csv','${s}','${k}')">📄 تصدير CSV</button></div>`;
function viewMonth(a){const ym=a[0]||todayStr().slice(0,7),pid=a[1],ms=L.inMonth(S.moves,ym);
 if(pid){const pm=ms.filter(m=>m.pid==pid).sort((x,y)=>y.date.localeCompare(x.date)||y.id-x.id);
  return app(head(esc(phName(+pid)),ym,`<a class="ic" href="#/month/${ym}">↩️</a>`)+`<div class="pad">${tot(L.stats(pm))}${pm.length?pm.map(m=>card(m)+((m.items||[]).length?`<ul class="its">${m.items.map(i=>`<li>${esc(i.name)} — ${num(i.qty)} × ${money(i.price)} = ${money(L.lineTotal(i))}</li>`).join('')}</ul>`:'')).join(''):'<div class="empty">لا توجد حركات</div>'}</div>`)}
 const bp=L.byPharmacy(ms).sort((x,y)=>phName(x.pid).localeCompare(phName(y.pid),'ar'));
 app(head('الشهر',MN[+ym.slice(5)-1]+' '+ym.slice(0,4),'<a class="ic" href="#/settings">⚙️</a>')+`<div class="pad"><label>اختر الشهر<input type="month" id="mp" value="${ym}"></label>${tot(L.stats(ms))}<h2>كشف الصيدليات</h2>${bp.length?bp.map(p=>`<a class="card" href="#/month/${ym}/${p.pid}"><b>${esc(phName(p.pid))}</b><div class="s">أخذنا منها: ${money(p.inTotal)} (${num(p.inCount)} حركة)</div><div class="s">أعطيناها: ${money(p.outTotal)} (${num(p.outCount)} حركة)</div></a>`).join(''):'<div class="empty">لا توجد حركات في هذا الشهر</div>'}${expBtns('m',ym)}</div>`);
 $('#mp').onchange=e=>{if(e.target.value)location.hash='#/month/'+e.target.value}}
function viewYear(a){const y=a[0]||todayStr().slice(0,4),ms=L.inYear(S.moves,y),s=L.stats(ms),bp=L.byPharmacy(ms).sort((x,z)=>phName(x.pid).localeCompare(phName(z.pid),'ar'));
 app(head('السنة',y,'<a class="ic" href="#/settings">⚙️</a>')+`<div class="pad"><label>السنة<input type="number" id="yp" value="${y}" min="2000" max="2100"></label>${tot(s)}<div class="card"><div class="r"><span>عدد الحركات الإجمالي</span><b>${num(s.count)}</b></div></div>
<h2>كشف الصيدليات</h2>${bp.length?bp.map(p=>`<div class="card"><b>${esc(phName(p.pid))}</b><div class="s">وارد: ${money(p.inTotal)} · صادر: ${money(p.outTotal)}</div><div class="s">عدد الحركات: ${num(p.count)} (وارد ${num(p.inCount)} / صادر ${num(p.outCount)})</div></div>`).join(''):'<div class="empty">لا توجد حركات</div>'}
<h2>التقرير الشهري</h2>${L.monthly(S.moves,y).map(m=>`<a class="card" href="#/month/${m.ym}"><div class="r"><b>${MN[+m.ym.slice(5)-1]}</b><span>${num(m.count)} حركة</span></div><div class="s">وارد: ${money(m.inTotal)} · صادر: ${money(m.outTotal)}</div></a>`).join('')}${expBtns('y',y)}</div>`);
 $('#yp').onchange=e=>{if(/^\d{4}$/.test(e.target.value))location.hash='#/year/'+e.target.value}}
function reportRows(title,ms,y){const s=L.stats(ms),R=[[title],['إجمالي الوارد',s.inTotal],['إجمالي الصادر',s.outTotal],['عدد الحركات الواردة',s.inCount],['عدد الحركات الصادرة',s.outCount],['إجمالي عدد الحركات',s.count],[]];
 if(y){R.push(['الشهر','وارد','صادر','عدد الوارد','عدد الصادر']);L.monthly(S.moves,y).forEach(m=>R.push([MN[+m.ym.slice(5)-1],m.inTotal,m.outTotal,m.inCount,m.outCount]));R.push([])}
 R.push(['الصيدلية','إجمالي الوارد','إجمالي الصادر','عدد الوارد','عدد الصادر']);L.byPharmacy(ms).forEach(p=>R.push([phName(p.pid),p.inTotal,p.outTotal,p.inCount,p.outCount]));R.push([],['رقم','التاريخ','الوقت','النوع','الصيدلية','الشيفت','المسؤول','قيمة الحركة','ملاحظات','الأصناف']);
 ms.slice().sort((a,b)=>a.date.localeCompare(b.date)||a.id-b.id).forEach(m=>R.push([m.id,m.date,m.time||'',m.type==='in'?'وارد':'صادر',phName(m.pid),m.shift,m.manager,m.amount,m.notes,(m.items||[]).map(i=>i.name+' × '+i.qty+' @ '+i.price).join(' | ')]));return R}
window.exp=(kind,sc,key)=>{const ms=sc==='m'?L.inMonth(S.moves,key):L.inYear(S.moves,key),rows=reportRows((sc==='m'?'تقرير شهر ':'تقرير سنة ')+key,ms,sc==='y'?key:null),n='saydalia-'+key;
 kind==='xlsx'?dl(n+'.xlsx',new Blob([X.xlsx(rows)],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})):dl(n+'.csv',new Blob(['\ufeff'+X.csv(rows)],{type:'text/csv;charset=utf-8'}))};
function viewSettings(){app(head('الإعدادات','','<a class="ic" href="#/day">↩️</a>')+`<div class="pad"><label>اسم الصيدلية الأساسية<input id="mname" value="${esc(S.st.name)}"></label><h2>الصيدليات الأخرى</h2>
${S.ph.map(p=>`<div class="row" style="margin-bottom:8px"><input data-pid="${p.id}" value="${esc(p.name)}" style="margin:0"><label><input type="checkbox" data-act="${p.id}" ${p.active?'checked':''}> نشطة</label></div>`).join('')||'<div class="empty">لا توجد صيدليات بعد</div>'}
<button class="primary" id="ss">💾 حفظ التعديلات</button><label>إضافة صيدلية جديدة<input id="newph"></label><button id="addph">➕ إضافة</button>
<p class="s">الصيدلية المتوقفة لا تظهر في الحركات الجديدة، وتبقى سجلاتها القديمة في التقارير.</p>
<h2>النسخ الاحتياطي</h2><button id="bk">⬇️ تصدير نسخة احتياطية كاملة</button><label>استيراد نسخة احتياطية<input type="file" id="rs" accept=".json,application/json"></label></div>`);
 $('#ss').onclick=async()=>{const name=$('#mname').value.trim();if(!name)return alert('اكتب اسم الصيدلية الأساسية');S.st={...S.st,name};await DB.put('settings',S.st);
  for(const r of document.querySelectorAll('[data-pid]')){const id=+r.dataset.pid,p=S.ph.find(x=>x.id===id),nm=r.value.trim(),ac=document.querySelector('[data-act="'+id+'"]').checked;if(nm&&(nm!==p.name||ac!==p.active))await DB.put('pharmacies',{...p,name:nm,active:ac})}
  await load();toast('تم الحفظ');route()};
 $('#addph').onclick=async()=>{const v=$('#newph').value.trim();if(!v)return;if(S.ph.some(p=>p.name===v))return alert('هذا الاسم موجود بالفعل');await DB.put('pharmacies',{name:v,active:true});await load();toast('تمت الإضافة');route()};
 $('#bk').onclick=()=>dl('saydalia-backup-'+todayStr()+'.json',new Blob([JSON.stringify({app:'saydalia',version:1,exportedAt:new Date().toISOString(),settings:{name:S.st.name,shift:S.st.shift,manager:S.st.manager},pharmacies:S.ph,moves:S.moves})],{type:'application/json'}));
 $('#rs').onchange=async e=>{const fl=e.target.files[0];if(!fl)return;let d;try{d=JSON.parse(await fl.text())}catch(x){e.target.value='';return alert('الملف ليس JSON صالحًا')}
  const er=L.validateBackup(d);if(er){e.target.value='';return alert('النسخة الاحتياطية غير صالحة: '+er)}
  if(!confirm('سيتم استبدال كل البيانات الحالية بالنسخة ('+d.pharmacies.length+' صيدلية، '+d.moves.length+' حركة). هل أنت متأكد؟')){e.target.value='';return}
  await DB.restore(d);await load();toast('تمت الاستعادة');location.hash='#/day';route()}}
(async()=>{try{await DB.open()}catch(e){document.body.textContent='تعذر فتح قاعدة البيانات في هذا المتصفح (وضع التصفح الخاص؟)';return}
 navigator.storage&&navigator.storage.persist&&navigator.storage.persist();await load();addEventListener('hashchange',route);route();
 if('serviceWorker'in navigator&&location.protocol!=='file:')navigator.serviceWorker.register('sw.js').catch(()=>{})})();
