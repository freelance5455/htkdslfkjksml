const DB_NAME='SaydaliaDB', DB_VERSION=1;
let dbPromise;
export function db() {
  if(dbPromise) return dbPromise;
  dbPromise=new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{
      const d=req.result;
      if(!d.objectStoreNames.contains('pharmacies')) d.createObjectStore('pharmacies',{keyPath:'id'});
      if(!d.objectStoreNames.contains('movements')) {
        const s=d.createObjectStore('movements',{keyPath:'id'});
        s.createIndex('date','date'); s.createIndex('pharmacyId','pharmacyId');
      }
      if(!d.objectStoreNames.contains('meta')) d.createObjectStore('meta',{keyPath:'key'});
    };
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
  return dbPromise;
}
export async function all(store) {
  const d=await db(); return new Promise((resolve,reject)=>{
    const r=d.transaction(store,'readonly').objectStore(store).getAll();
    r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error);
  });
}
export async function get(store,key) {
  const d=await db(); return new Promise((resolve,reject)=>{
    const r=d.transaction(store,'readonly').objectStore(store).get(key);
    r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error);
  });
}
export async function put(store,value) {
  const d=await db(); return new Promise((resolve,reject)=>{
    const tx=d.transaction(store,'readwrite'); tx.objectStore(store).put(value);
    tx.oncomplete=()=>resolve(value); tx.onerror=()=>reject(tx.error);
  });
}
export async function remove(store,key) {
  const d=await db(); return new Promise((resolve,reject)=>{
    const tx=d.transaction(store,'readwrite'); tx.objectStore(store).delete(key);
    tx.oncomplete=resolve; tx.onerror=()=>reject(tx.error);
  });
}
export async function replaceAll(pharmacies,movements,meta={}) {
  const d=await db();
  return new Promise((resolve,reject)=>{
    const tx=d.transaction(['pharmacies','movements','meta'],'readwrite');
    for(const name of ['pharmacies','movements','meta']) tx.objectStore(name).clear();
    pharmacies.forEach(x=>tx.objectStore('pharmacies').put(x));
    movements.forEach(x=>tx.objectStore('movements').put(x));
    Object.entries(meta).forEach(([key,value])=>tx.objectStore('meta').put({key,value}));
    tx.oncomplete=resolve; tx.onerror=()=>reject(tx.error);
  });
}
export async function getMeta(key) { return (await get('meta',key))?.value; }
export async function setMeta(key,value) { return put('meta',{key,value}); }