(function(g){
const sum=a=>a.reduce((s,x)=>s+x,0),r2=n=>Math.round((+n+Number.EPSILON)*100)/100;
const lineTotal=i=>r2((+i.qty||0)*(+i.price||0));
const itemsTotal=items=>r2(sum((items||[]).map(lineTotal)));
function stats(ms){const i=ms.filter(m=>m.type==='in'),o=ms.filter(m=>m.type==='out');
 return{inTotal:r2(sum(i.map(m=>+m.amount))),outTotal:r2(sum(o.map(m=>+m.amount))),inCount:i.length,outCount:o.length,count:ms.length}}
function byPharmacy(ms){const k={};ms.forEach(m=>(k[m.pid]=k[m.pid]||[]).push(m));return Object.keys(k).map(p=>({pid:+p,...stats(k[p])}))}
const inMonth=(ms,ym)=>ms.filter(m=>m.date.slice(0,7)===ym);
const inYear=(ms,y)=>ms.filter(m=>m.date.slice(0,4)===String(y));
const monthly=(ms,y)=>Array.from({length:12},(_,i)=>{const ym=y+'-'+String(i+1).padStart(2,'0');return{ym,...stats(inMonth(ms,ym))}});
function validateBackup(d){
 if(!d||typeof d!=='object'||d.app!=='saydalia')return 'الملف ليس نسخة من تطبيق صيدلية';
 if(d.version!==1)return 'إصدار النسخة غير مدعوم';
 if(!d.settings||typeof d.settings.name!=='string'||!d.settings.name.trim())return 'إعدادات ناقصة';
 if(!Array.isArray(d.pharmacies)||!Array.isArray(d.moves))return 'بنية البيانات ناقصة';
 const ids=new Set(),mids=new Set();
 for(const p of d.pharmacies){if(!Number.isInteger(p.id)||typeof p.name!=='string'||!p.name.trim()||ids.has(p.id))return 'بيانات صيدلية غير صحيحة';ids.add(p.id)}
 for(const m of d.moves){
  if(!Number.isInteger(m.id)||mids.has(m.id))return 'رقم حركة مكرر أو غير صحيح';mids.add(m.id);
  if(m.type!=='in'&&m.type!=='out')return 'نوع حركة غير صحيح (#'+m.id+')';
  if(!ids.has(m.pid))return 'حركة #'+m.id+' مرتبطة بصيدلية غير موجودة';
  if(typeof m.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(m.date))return 'تاريخ غير صحيح (#'+m.id+')';
  if(!Number.isFinite(m.amount)||m.amount<0)return 'قيمة غير صحيحة (#'+m.id+')';
  if(m.time!==undefined&&typeof m.time!=='string')return 'وقت غير صحيح (#'+m.id+')';
  if(m.items!==undefined&&!Array.isArray(m.items))return 'أصناف غير صحيحة (#'+m.id+')';
  for(const i of m.items||[])if(typeof i.name!=='string'||!Number.isFinite(i.qty)||!Number.isFinite(i.price))return 'صنف غير صحيح في الحركة #'+m.id}
 return null}
g.L={r2,lineTotal,itemsTotal,stats,byPharmacy,inMonth,inYear,monthly,validateBackup};
if(typeof module!=='undefined')module.exports=g.L;
})(typeof window!=='undefined'?window:globalThis);
