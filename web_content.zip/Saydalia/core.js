export const money = n => new Intl.NumberFormat('ar-EG',{style:'currency',currency:'EGP',maximumFractionDigits:2}).format(Number(n)||0);
export const dateKey = d => {
  const x = new Date(d);
  return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`;
};
export const sum = xs => xs.reduce((a,b)=>a+(Number(b)||0),0);
export function movementTotals(movements, predicate=()=>true) {
  const rows = movements.filter(predicate);
  return {
    incoming: sum(rows.filter(x=>x.type==='in').map(x=>x.amount)),
    outgoing: sum(rows.filter(x=>x.type==='out').map(x=>x.amount)),
    incomingCount: rows.filter(x=>x.type==='in').length,
    outgoingCount: rows.filter(x=>x.type==='out').length,
    count: rows.length
  };
}
export function pharmacyBreakdown(movements, pharmacies, predicate=()=>true) {
  return pharmacies.map(p=>{
    const rows=movements.filter(m=>m.pharmacyId===p.id && predicate(m));
    return {pharmacy:p, incoming:sum(rows.filter(m=>m.type==='in').map(m=>m.amount)),
      outgoing:sum(rows.filter(m=>m.type==='out').map(m=>m.amount)),
      incomingCount:rows.filter(m=>m.type==='in').length,
      outgoingCount:rows.filter(m=>m.type==='out').length,count:rows.length};
  }).filter(x=>x.count>0);
}
export function itemTotal(items) {
  return sum(items.map(i=>(Number(i.quantity)||0)*(Number(i.unitPrice)||0)));
}
export function validateBackup(data) {
  if(!data || data.schema!=='saydalia-backup-v1' || !Array.isArray(data.pharmacies) || !Array.isArray(data.movements))
    throw new Error('ملف النسخة الاحتياطية غير صالح أو غير مدعوم.');
  const ids=new Set(data.pharmacies.map(p=>p.id));
  for(const m of data.movements) {
    if(!m.id || !ids.has(m.pharmacyId) || !['in','out'].includes(m.type) || !Number.isFinite(Number(m.amount)) || Number(m.amount)<0)
      throw new Error('تحتوي النسخة الاحتياطية على حركة غير مكتملة أو غير صحيحة.');
    if(!Array.isArray(m.items)) throw new Error('بنية تفاصيل الأدوية غير صحيحة.');
  }
  return true;
}
export function monthRange(year,month) {
  const start=`${year}-${String(month).padStart(2,'0')}-01`;
  const end=new Date(Number(year),Number(month),0).getDate();
  return [start,`${year}-${String(month).padStart(2,'0')}-${String(end).padStart(2,'0')}`];
}