import test from 'node:test';
import assert from 'node:assert/strict';
import {movementTotals,pharmacyBreakdown,itemTotal,validateBackup,monthRange} from '../core.js';
const pharmacies=[{id:'p1',name:'الأولى'},{id:'p2',name:'الثانية'}];
const movements=[
{id:'1',pharmacyId:'p1',type:'in',date:'2026-11-02',amount:5000,items:[]},
{id:'2',pharmacyId:'p1',type:'out',date:'2026-11-02',amount:3000,items:[]},
{id:'3',pharmacyId:'p2',type:'in',date:'2026-10-10',amount:1000,items:[]}
];
test('الوارد والصادر مستقلان ولا توجد مقاصة',()=>assert.deepEqual(movementTotals(movements),{incoming:6000,outgoing:3000,incomingCount:2,outgoingCount:1,count:3}));
test('كشف الفرع يحافظ على الوارد والصادر',()=>{const x=pharmacyBreakdown(movements,pharmacies)[0];assert.equal(x.incoming,5000);assert.equal(x.outgoing,3000)});
test('تجميع الشهر لا يضم حركات شهر آخر',()=>{const [a,b]=monthRange(2026,11);assert.deepEqual(movementTotals(movements,m=>m.date>=a&&m.date<=b).incoming,5000)});
test('إجمالي الأصناف كمية في سعر الوحدة',()=>assert.equal(itemTotal([{quantity:2,unitPrice:100},{quantity:3,unitPrice:50}]),350));
test('النسخة الاحتياطية الصحيحة تقبل',()=>assert.equal(validateBackup({schema:'saydalia-backup-v1',pharmacies,movements}),true));
test('النسخة الاحتياطية ذات حركة بلا فرع ترفض',()=>assert.throws(()=>validateBackup({schema:'saydalia-backup-v1',pharmacies,movements:[{id:'x',pharmacyId:'missing',type:'in',amount:2,items:[]}]})));
