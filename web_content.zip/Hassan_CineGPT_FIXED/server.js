const http = require('http');
const fs = require('fs');
const path = require('path');

const TOKEN = process.env.REPLICATE_API_TOKEN;
const PORT = Number(process.env.PORT || 3000);
const MODEL = 'prunaai/p-video';
const ROOT = __dirname;

function send(res, status, body, type='application/json') {
  const data = typeof body === 'string' ? body : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': type + (type.startsWith('text/') ? ';charset=utf-8' : ''),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
  });
  res.end(data);
}

function readJson(req, max = 4 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (Buffer.byteLength(data) > max) {
        req.destroy();
        reject(new Error('حجم الطلب كبير جدًا. صغّر الصورة إلى أقل من 1MB.'));
      }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); }
      catch { reject(new Error('بيانات الطلب غير صحيحة.')); }
    });
    req.on('error', reject);
  });
}

async function replicate(endpoint, options={}) {
  if (!TOKEN) throw new Error('الخادم غير مضبوط: أضف REPLICATE_API_TOKEN.');
  const response = await fetch('https://api.replicate.com/v1' + endpoint, {
    ...options,
    headers: {
      'Authorization': 'Bearer ' + TOKEN,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  const text = await response.text();
  let json;
  try { json = JSON.parse(text); } catch { json = { detail: text }; }
  if (!response.ok) throw new Error(json.detail || json.error || ('Replicate HTTP ' + response.status));
  return json;
}

async function waitForPrediction(id) {
  for (let i = 0; i < 180; i++) {
    const p = await replicate('/predictions/' + encodeURIComponent(id));
    if (p.status === 'succeeded') return p;
    if (p.status === 'failed' || p.status === 'canceled') {
      throw new Error(p.error || ('التوليد انتهى بحالة: ' + p.status));
    }
    await new Promise(r => setTimeout(r, 2000));
  }
  throw new Error('التوليد أخذ وقتًا أطول من المتوقع. جرّب مرة أخرى.');
}

function outputUrl(output) {
  if (typeof output === 'string') return output;
  if (output && typeof output.url === 'string') return output.url;
  if (output && Array.isArray(output) && typeof output[0] === 'string') return output[0];
  return null;
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, '');

  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    return send(res, 200, fs.readFileSync(path.join(ROOT, 'index.html')), 'text/html');
  }
  if (req.method === 'GET' && req.url === '/logo.png') {
    const file = fs.readFileSync(path.join(ROOT, 'logo.png'));
    res.writeHead(200, {'Content-Type':'image/png','Access-Control-Allow-Origin':'*'});
    return res.end(file);
  }
  if (req.method === 'GET' && req.url === '/health') {
    return send(res, 200, {ok:true, token_configured:Boolean(TOKEN), model:MODEL});
  }
  if (req.method === 'POST' && req.url === '/api/generate') {
    try {
      const b = await readJson(req);
      const prompt = String(b.prompt || '').trim();
      const image = b.image ? String(b.image) : '';
      if (!prompt && !image) return send(res, 400, {error:'اكتب وصفًا أو اختر صورة.'});
      if (image && !image.startsWith('data:image/')) return send(res, 400, {error:'الصورة يجب أن تكون صورة مرفوعة من التطبيق.'});
      if (image && image.length > 1_500_000) return send(res, 400, {error:'الصورة كبيرة. اختر صورة أصغر.'});

      const duration = Math.min(20, Math.max(1, Number(b.duration || 5)));
      const resolution = b.resolution === '1080p' ? '1080p' : '720p';
      const input = {
        prompt,
        duration,
        resolution,
        fps: 24,
        save_audio: true,
        aspect_ratio: '16:9',
        prompt_upsampling: true,
        disable_safety_filter: false
      };
      if (image) input.image = image;

      let p = await replicate('/models/prunaai/p-video/predictions', {
        method:'POST',
        headers:{'Prefer':'wait=60'},
        body:JSON.stringify({input})
      });
      if (p.status !== 'succeeded') p = await waitForPrediction(p.id);
      const url = outputUrl(p.output);
      if (!url) throw new Error('المحرك لم يرجع رابط فيديو.');
      return send(res, 200, {ok:true, video_url:url, prediction_id:p.id});
    } catch (e) {
      return send(res, 500, {ok:false, error:e.message || 'حدث خطأ غير معروف.'});
    }
  }
  send(res, 404, 'Not found', 'text/plain');
});

server.listen(PORT, () => console.log(`Hassan CineGPT server: http://localhost:${PORT}`));
