Hassan CineGPT AI PRO - FIXED

المشكلة التي كان يظهر بسببها Failed to fetch:
كان ملف HTML مفتوحًا بدون خادم /api/generate. التطبيق يحتاج Backend لأن مفتاح Replicate لا يجب وضعه داخل HTML.

الطريقة 1 - Node.js:
1) ثبّت Node.js 18 أو أحدث على جهاز/سيرفر.
2) ضع الملفات معًا.
3) اضبط متغير البيئة REPLICATE_API_TOKEN بمفتاح Replicate.
4) شغّل: npm start
5) افتح http://localhost:3000
6) إذا كنت تستخدم HTML-to-APK، استخدم index.html وضع رابط الخادم في خانة "رابط خادم التوليد".

الطريقة 2 - Cloudflare Worker:
1) أنشئ Worker جديد.
2) انسخ worker.js.
3) أضف Secret باسم REPLICATE_API_TOKEN.
4) انسخ رابط Worker وضعه في خانة "رابط خادم التوليد" داخل التطبيق.

ملاحظات:
- توليد الفيديو عبر Replicate ليس مجانيًا بلا حدود؛ يلزم رصيد/حساب حسب الخدمة.
- الصور الكبيرة يتم تصغيرها في التطبيق، ويفضل أن تكون أقل من 1MB.
- لا تضع مفتاح Replicate داخل index.html أو APK.
