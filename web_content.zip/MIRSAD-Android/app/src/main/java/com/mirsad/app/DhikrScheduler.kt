package com.mirsad.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject

object DhikrScheduler {
    private const val PREF = "mirsad_dhikr_native"
    fun saveAndSchedule(context: Context, cfg: JSONObject) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("config", cfg.toString()).apply()
        schedule(context)
    }
    fun config(context: Context): JSONObject = try {
        JSONObject(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("config", "{}") ?: "{}")
    } catch (_: Exception) { JSONObject() }
    fun schedule(context: Context) {
        val c = config(context)
        val enabled = c.optBoolean("enabled", false) && c.optBoolean("androidNotifications", true)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context)
        am.cancel(pi)
        if (!enabled) return
        val interval = (c.optInt("interval", 60).coerceIn(30, 120) * 60_000L)
        val next = System.currentTimeMillis() + interval
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
        else am.set(AlarmManager.RTC_WAKEUP, next, pi)
    }
    fun pending(context: Context): PendingIntent {
        val i = Intent(context, DhikrAlarmReceiver::class.java)
        return PendingIntent.getBroadcast(context, 451, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
