package com.mirsad.study

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return Result.success()
        val lessonId = inputData.getString(KEY_LESSON_ID) ?: return Result.failure()
        val cycle = inputData.getString(KEY_CYCLE) ?: return Result.failure()
        val title = inputData.getString(KEY_TITLE) ?: "درس"
        val subject = inputData.getString(KEY_SUBJECT) ?: ""
        val prefs = applicationContext.getSharedPreferences("mirsad_reminders", Context.MODE_PRIVATE)
        val firedKey = "fired:$lessonId:$cycle"
        if (prefs.getBoolean(firedKey, false)) return Result.success()
        prefs.edit().putBoolean(firedKey, true).apply()
        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("lessonId", lessonId)
        }
        val pending = PendingIntent.getActivity(
            applicationContext, (lessonId + cycle).hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("مِرْصاد: حان وقت المراجعة")
            .setContentText("وصل «$title»${if (subject.isNotBlank()) " · $subject" else ""} إلى 40% أو أقل.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("حان وقت مراجعة درس «$title» في مادة «$subject». وصلت نسبة الاحتفاظ إلى 40% أو أقل. افتح مِرْصاد وسجّل المراجعة لبدء دورة جديدة."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        NotificationManagerCompat.from(applicationContext).notify((lessonId + cycle).hashCode(), notification)
        return Result.success()
    }

    companion object {
        const val CHANNEL_ID = "mirsad_review_reminders"
        const val WORK_TAG = "mirsad-reminder"
        const val KEY_LESSON_ID = "lesson_id"
        const val KEY_CYCLE = "cycle"
        const val KEY_TITLE = "title"
        const val KEY_SUBJECT = "subject"
    }
}
