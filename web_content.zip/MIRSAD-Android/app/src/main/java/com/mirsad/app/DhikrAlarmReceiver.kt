package com.mirsad.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class DhikrAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val c = DhikrScheduler.config(context)
        if (!c.optBoolean("enabled", false) || !c.optBoolean("androidNotifications", true)) return
        val now = Calendar.getInstance()
        if (c.optBoolean("quiet", false)) {
            val start = c.optInt("quietStart", 22); val end = c.optInt("quietEnd", 7)
            val h = now.get(Calendar.HOUR_OF_DAY)
            val quietNow = if (start < end) h in start until end else (h >= start || h < end)
            if (quietNow) { DhikrScheduler.schedule(context); return }
        }
        val startHour = c.optInt("startHour", 8); val endHour = c.optInt("endHour", 22)
        val hour = now.get(Calendar.HOUR_OF_DAY)
        val inRange = if (startHour <= endHour) hour in startHour..endHour else (hour >= startHour || hour <= endHour)
        if (!inRange) { DhikrScheduler.schedule(context); return }

        val dhikrs = arrayOf(
            "أستغفر الله العظيم", "الحمد لله", "سبحان الله", "الله أكبر", "لا إله إلا الله",
            "سبحان الله وبحمده، سبحان الله العظيم", "لا حول ولا قوة إلا بالله", "أستغفر الله وأتوب إليه",
            "اللهم صل وسلم على نبينا محمد", "حسبي الله ونعم الوكيل", "لا إله إلا أنت سبحانك إني كنت من الظالمين",
            "رضيت بالله رباً، وبالإسلام ديناً، وبمحمد ﷺ نبياً", "سبحان الله والحمد لله ولا إله إلا الله والله أكبر",
            "اللهم أعني على ذكرك وشكرك وحسن عبادتك", "رب اغفر لي وتب علي إنك أنت التواب الرحيم"
        )
        val prefs = context.getSharedPreferences("mirsad_dhikr_native", Context.MODE_PRIVATE)
        val last = prefs.getString("lastDhikr", "") ?: ""
        val choices = dhikrs.filter { it != last }
        val chosen = choices[Random.nextInt(choices.size)]
        val entryId = "native-${System.currentTimeMillis()}"
        var log = try { org.json.JSONArray(prefs.getString("history", "[]") ?: "[]") } catch (_: Exception) { org.json.JSONArray() }
        log.put(JSONObject().put("id", entryId).put("text", chosen).put("at", System.currentTimeMillis()).put("done", false))
        if (log.length() > 500) { val trimmed = org.json.JSONArray(); for (i in log.length() - 500 until log.length()) trimmed.put(log.get(i)); log = trimmed }
        prefs.edit().putString("lastDhikr", chosen).putString("history", log.toString()).apply()

        val fg = MainActivity.active?.get()
        if (fg != null && c.optBoolean("inApp", true)) {
            fg.showDhikrInApp(chosen)
        } else {
            createChannel(context)
            val open = PendingIntent.getActivity(context, 12, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notification = NotificationCompat.Builder(context, "mirsad_dhikr")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("تذكير لطيف")
                .setContentText(chosen)
                .setStyle(NotificationCompat.BigTextStyle().bigText("$chosen\n\nألا بذكر الله تطمئن القلوب"))
                .setContentIntent(open).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setVibrate(if (c.optBoolean("vibration", false)) longArrayOf(0, 180) else null)
                .build()
            try { NotificationManagerCompat.from(context).notify(452, notification) } catch (_: SecurityException) {}
        }
        DhikrScheduler.schedule(context)
    }
    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel("mirsad_dhikr", "الذكر العفوي", NotificationManager.IMPORTANCE_DEFAULT)
            c.description = "تذكيرات الذكر العفوي من مِرْصاد"
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) { DhikrScheduler.schedule(context) }
}
