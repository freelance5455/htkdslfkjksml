package com.mirsad.study

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.app.Activity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val requestCodeNotifications = 7401

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(MirsadBridge(this), "MirsadNative")
        setContentView(webView)
        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ReminderWorker.CHANNEL_ID,
                "تذكيرات مِرْصاد",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "تنبيهات مراجعة الدروس عند وصول الاحتفاظ إلى 40%" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    inner class MirsadBridge(private val context: Context) {
        @JavascriptInterface fun requestNotificationPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                    webView.evaluateJavascript("window.mirsadNativePermissionResult(true)", null)
                } else {
                    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestCodeNotifications)
                }
            }
        }

        @JavascriptInterface fun syncReminders(json: String) {
            try {
                val items = JSONArray(json)
                val wm = WorkManager.getInstance(context)
                wm.cancelAllWorkByTag(ReminderWorker.WORK_TAG)
                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val id = item.getString("id")
                    val cycle = item.getString("cycle")
                    val title = item.getString("title")
                    val subject = item.getString("subject")
                    val dueAt = item.getLong("dueAt")
                    val firedKey = "fired:$id:$cycle"
                    if (context.getSharedPreferences("mirsad_reminders", Context.MODE_PRIVATE).getBoolean(firedKey, false)) continue
                    val delay = (dueAt - System.currentTimeMillis()).coerceAtLeast(0L)
                    val data = Data.Builder()
                        .putString(ReminderWorker.KEY_LESSON_ID, id)
                        .putString(ReminderWorker.KEY_CYCLE, cycle)
                        .putString(ReminderWorker.KEY_TITLE, title)
                        .putString(ReminderWorker.KEY_SUBJECT, subject)
                        .build()
                    val request = OneTimeWorkRequestBuilder<ReminderWorker>()
                        .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                        .setInputData(data)
                        .addTag(ReminderWorker.WORK_TAG)
                        .build()
                    wm.enqueueUniqueWork("mirsad-$id-$cycle", androidx.work.ExistingWorkPolicy.REPLACE, request)
                }
            } catch (_: Exception) { }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestCodeNotifications) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            webView.evaluateJavascript("window.mirsadNativePermissionResult($granted)", null)
        }
    }
}
