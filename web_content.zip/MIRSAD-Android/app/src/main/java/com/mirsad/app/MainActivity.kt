package com.mirsad.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.lang.ref.WeakReference

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(NativeBridge(this), "MirsadNative")
        setContentView(web)
        active = WeakReference(this)
        web.loadUrl("file:///android_asset/index.html")
        DhikrScheduler.schedule(this)
    }
    override fun onResume() { super.onResume(); active = WeakReference(this) }
    override fun onPause() { if (active?.get() === this) active = null; super.onPause() }
    override fun onDestroy() { if (::web.isInitialized) web.destroy(); super.onDestroy() }

    fun showDhikrInApp(text: String) {
        runOnUiThread {
            val safe = JSONObject.quote(text)
            web.evaluateJavascript("window.dispatchEvent(new CustomEvent('mirsad-dhikr',{detail:{text:$safe}}));", null)
        }
    }
    fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 701)
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 701) web.evaluateJavascript("window.mirsadNativePermissionResult(${grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED});", null)
    }
    companion object { @Volatile var active: WeakReference<MainActivity>? = null }
}

class NativeBridge(private val activity: MainActivity) {
    @JavascriptInterface fun requestNotificationPermission() = activity.runOnUiThread { activity.askNotificationPermission() }
    @JavascriptInterface fun configureDhikr(json: String) {
        try { DhikrScheduler.saveAndSchedule(activity, JSONObject(json)) } catch (_: Exception) {}
    }
    @JavascriptInterface fun requestNotifications() = activity.runOnUiThread { activity.askNotificationPermission() }
    @JavascriptInterface fun getDhikrHistory(): String = activity.getSharedPreferences("mirsad_dhikr_native", Context.MODE_PRIVATE).getString("history", "[]") ?: "[]"
}
