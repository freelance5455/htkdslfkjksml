FONT THEME. — HTML APK-builder package

You were right: this package is HTML-first. There is NO Android Studio project in this ZIP.

FILES
- index.html: complete responsive app UI
- assets/: place optional images/fonts here
- README.txt: packaging and Android bridge notes

HOW TO PACKAGE
1. Extract this ZIP.
2. Give index.html and the assets folder to your HTML-to-APK / WebView APK builder.
3. Set the app name to: Font theme.
4. Set index.html as the start page.
5. Build the APK using your preferred method.

CURRENT HTML FEATURES
- Minimal white interface
- App grid and search
- 12 font style options
- Change displayed app name in the launcher preview
- Select GIF/PNG/JPG/WebP and preview it
- Save customization in browser localStorage
- Sample app mode for testing the UI

IMPORTANT: installed app discovery and actual launching
A plain HTML page cannot access Android's installed-app list or launch arbitrary installed packages. This is an Android security restriction, not an HTML bug. To make the APK act as a real home-screen launcher, the APK builder/runtime must expose a native JavaScript bridge.

This page checks for:
  window.FontThemeAndroid.getInstalledApps()

Expected return value: JSON string or JS array, e.g.
[
  {"id":"com.example.app","name":"Example","iconUrl":"content://..."}
]

For actual app launching, your APK builder should also expose:
  window.FontThemeAndroid.launchApp(packageName)

For launcher registration, the APK wrapper must declare itself as a HOME app in its Android manifest. The HTML page alone cannot register as the system home screen.

To apply each saved custom name/icon/font to a home-screen tile, the wrapper should return package names and icon content URIs, and implement the native launcher bridge. The HTML page is the frontend; the APK wrapper provides Android-only permissions and actions.

GIF note
The browser preview can animate GIF files. The actual launcher must render animated images in its native app grid; a static Android shortcut icon generally cannot animate.

Font note
The font selector styles labels inside Font theme. It cannot change the font inside WhatsApp/Instagram or system-wide Android settings.

No remote libraries, analytics, or network calls are used.
