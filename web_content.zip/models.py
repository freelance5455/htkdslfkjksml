from app import db
from flask_login import UserMixin
from datetime import datetime

class School(db.Model):
    __tablename__ = 'schools'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    code = db.Column(db.String(50), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)  # Auto-generated: firstname@cbe.co.ke
    password_hash = db.Column(db.String(255), nullable=False)
    # Feature 12 & 13: Strict Staff Roles
    role = db.Column(db.Enum('Principal', 'Deputy Principal', 'Senior Teacher', 'Class Teacher', 'Subject Teacher', 'Subordinate Staff', name='staff_roles'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Learner(db.Model):
    __tablename__ = 'learners'
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    admission_number = db.Column(db.String(50), unique=True, nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    # Feature 2 & 7: PP1 to Grade 12 scope
    grade_level = db.Column(db.Enum('PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12', name='grade_levels'), nullable=False)
    stream = db.Column(db.String(20), nullable=False)  # e.g. North, South, East, West
    class_teacher_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True) # Feature 4
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Mark(db.Model):
    __tablename__ = 'marks'
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    learner_id = db.Column(db.Integer, db.ForeignKey('learners.id'), nullable=False)
    subject = db.Column(db.String(100), nullable=False)
    term = db.Column(db.Enum('Term 1', 'Term 2', 'Term 3', name='terms'), nullable=False)
    exam_type = db.Column(db.Enum('Opener', 'Mid-Term', 'End-Term', 'CAT', name='exam_types'), nullable=False)
    calendar_year = db.Column(db.Integer, nullable=False, default=2026)
    score = db.Column(db.Float, nullable=False)
    stream_rank = db.Column(db.Integer, nullable=True) # Feature 15
    overall_rank = db.Column(db.Integer, nullable=True) # Feature 15

class StaffAttendance(db.Model):
    __tablename__ = 'staff_attendance'
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    clock_in = db.Column(db.Time, nullable=True)
    clock_out = db.Column(db.Time, nullable=True)

class LessonPlan(db.Model):
    __tablename__ = 'lesson_plans'
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    teacher_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    term = db.Column(db.Enum('Term 1', 'Term 2', 'Term 3', name='terms'), nullable=False)
    calendar_year = db.Column(db.Integer, nullable=False, default=2026)
    file_path = db.Column(db.String(255), nullable=False)
    status = db.Column(db.Enum('Pending Review', 'Approved', 'Revision Requested', name='plan_status'), default='Pending Review')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Attendance(db.Model):
    __tablename__ = 'attendances'
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    learner_id = db.Column(db.Integer, db.ForeignKey('learners.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    status = db.Column(db.Enum('Present', 'Absent', 'Excused', name='attendance_status'), nullable=False)
    countersigned_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True) # Feature 14 approval
