GUEST FIRST — ANDROID STUDIO PROJECT

This project wraps the Guest First Hospitality Training web app in an Android WebView.
It is a source project, NOT a prebuilt APK. The APK must be built with Android Studio and the Android SDK.

BUILD AN APK (computer required):
1. Install Android Studio on a Windows, Mac, or Linux computer from the official Android developer site.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted Guest_First_Android_Project folder.
4. Allow Gradle sync and install any SDK components Android Studio requests.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When finished, choose Locate. The debug APK is normally app/build/outputs/apk/debug/app-debug.apk.
7. Transfer that APK to your Android phone and open it to install. You may need to allow installation from that file manager.

NOTES:
- App label: Guest First.
- Application ID: com.guestfirst.hospitality
- Questions added by a user are stored locally on that device. There is no team sync or shared database yet.
- Before workplace rollout, have management review all SOP, menu, allergen, and brand content.
- For distribution outside a small test, create a signed release APK in Android Studio and follow your organization's IT/security policy.
