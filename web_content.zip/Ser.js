/* =====================================
   SER - SISTEMA EMPRESARIAL
===================================== */

let dados = JSON.parse(localStorage.getItem("SER_DADOS")) || null;

let paginaAtual = "inicio";


/* =====================================
   INICIALIZAÇÃO
===================================== */

document.addEventListener("DOMContentLoaded", () => {

    if (dados) {
        document.getElementById("primeiroAcesso").classList.add("hidden");
        document.getElementById("login").classList.remove("hidden");
    }

});


/* =====================================
   SALVAR
===================================== */

function salvar() {
    localStorage.setItem("SER_DADOS", JSON.stringify(dados));
}


/* =====================================
   PRIMEIRO ADMINISTRADOR
===================================== */

function criarAdministrador() {

    const empresa = document.getElementById("empresaInicial").value.trim();
    const nome = document.getElementById("nomeAdmin").value.trim();
    const usuario = document.getElementById("usuarioAdmin").value.trim();
    const senha = document.getElementById("senhaAdmin").value;

    if (!empresa || !nome || !usuario || !senha) {
        alert("Preencha todos os campos.");
        return;
    }

    if (senha.length < 4) {
        alert("A senha precisa ter pelo menos 4 caracteres.");
        return;
    }

    dados = {

        empresa: empresa,

        administrador: {
            nome: nome,
            usuario: usuario,
            senha: senha,
            cargo: "Administrador"
        },

        pessoas: [
            {
                id: Date.now(),
                nome: nome,
                usuario: usuario,
                cargo: "Administrador"
            }
        ],

        cargos: [
            {
                id: Date.now(),
                nome: "Administrador",
                descricao: "Acesso total ao sistema."
            }
        ],

        projetos: []

    };

    salvar();

    document.getElementById("primeiroAcesso").classList.add("hidden");
    document.getElementById("login").classList.remove("hidden");

    alert("Sistema criado com sucesso! Agora faça login.");
}


/* =====================================
   LOGIN
===================================== */

function entrar() {

    const usuario = document.getElementById("loginUsuario").value.trim();
    const senha = document.getElementById("loginSenha").value;

    const erro = document.getElementById("erroLogin");

    if (
        usuario === dados.administrador.usuario &&
        senha === dados.administrador.senha
    ) {

        sessionStorage.setItem("SER_LOGADO", "true");

        abrirSistema();

    } else {

        erro.textContent = "Usuário ou senha incorretos.";

    }

}


/* =====================================
   ABRIR SISTEMA
===================================== */

function abrirSistema() {

    document.getElementById("auth").classList.add("hidden");
    document.getElementById("sistema").classList.remove("hidden");

    atualizarInterface();

}


/* =====================================
   INTERFACE
===================================== */

function atualizarInterface() {

    const nome = dados.administrador.nome;

    document.getElementById("nomeEmpresaTopo").textContent =
        dados.empresa;

    document.getElementById("nomeUsuarioTopo").textContent =
        nome;

    document.getElementById("saudacaoNome").textContent =
        nome;

    document.getElementById("configNome").textContent =
        nome;

    document.getElementById("configUsuario").textContent =
        "@" + dados.administrador.usuario;

    document.getElementById("configEmpresa").textContent =
        dados.empresa;

    const inicial =
        nome.charAt(0).toUpperCase();

    document.getElementById("avatarTopo").textContent = inicial;
    document.getElementById("avatarConfig").textContent = inicial;

    document.getElementById("numeroProjetos").textContent =
        dados.projetos.length;

    document.getElementById("numeroPessoas").textContent =
        dados.pessoas.length;

    document.getElementById("numeroCargos").textContent =
        dados.cargos.length;

    renderizarProjetos();
    renderizarCargos();

}


/* =====================================
   NAVEGAÇÃO
===================================== */

function abrirPagina(pagina) {

    const paginas = [
        "inicio",
        "projetos",
        "cargos",
        "conta"
    ];

    paginas.forEach(nome => {

        const elemento =
            document.getElementById("pagina" +
                nome.charAt(0).toUpperCase() +
                nome.slice(1));

        if (elemento) {
            elemento.classList.add("hidden");
        }

    });

    const alvo =
        document.getElementById(
            "pagina" +
            pagina.charAt(0).toUpperCase() +
            pagina.slice(1)
        );

    if (alvo) {
        alvo.classList.remove("hidden");
    }

    document.querySelectorAll(".nav-btn")
        .forEach(btn => btn.classList.remove("ativo"));

    const nav =
        document.getElementById("nav" +
            pagina.charAt(0).toUpperCase() +
            pagina.slice(1));

    if (nav) {
        nav.classList.add("ativo");
    }

    paginaAtual = pagina;

}


/* =====================================
   PROJETOS
===================================== */

function novoProjeto() {

    const modal = document.getElementById("modal");
    const conteudo = document.getElementById("conteudoModal");

    conteudo.innerHTML = `

        <h2>Novo projeto</h2>

        <input id="novoProjetoNome"
               placeholder="Nome do projeto">

        <input id="novoProjetoDescricao"
               placeholder="Descrição">

        <button class="confirmar"
                onclick="salvarProjeto()">
            CRIAR PROJETO
        </button>

    `;

    modal.classList.remove("hidden");

}


function salvarProjeto() {

    const nome =
        document.getElementById("novoProjetoNome")
        .value.trim();

    const descricao =
        document.getElementById("novoProjetoDescricao")
        .value.trim();

    if (!nome) {
        alert("Digite o nome do projeto.");
        return;
    }

    dados.projetos.push({

        id: Date.now(),

        nome: nome,

        descricao:
            descricao || "Sem descrição.",

        status: "Em andamento",

        criadoEm:
            new Date().toLocaleDateString("pt-BR")

    });

    salvar();

    fecharModal();

    atualizarInterface();

    abrirPagina("projetos");

}


/* =====================================
   LISTAR PROJETOS
===================================== */

function renderizarProjetos() {

    const lista =
        document.getElementById("listaProjetos");

    const inicio =
        document.getElementById("listaProjetosInicio");

    if (dados.projetos.length === 0) {

        lista.innerHTML = `
            <div class="lista-vazia">
                Nenhum projeto criado.
            </div>
        `;

        inicio.innerHTML =
            "Nenhum projeto criado ainda.";

        return;

    }

    lista.innerHTML = dados.projetos.map(projeto => `

        <div class="item">

            <div class="item-topo">

                <h3>${escapar(projeto.nome)}</h3>

                <span class="status">
                    ${escapar(projeto.status)}
                </span>

            </div>

            <p>
                ${escapar(projeto.descricao)}
            </p>

            <p>
                Criado em ${projeto.criadoEm}
            </p>

        </div>

    `).join("");


    inicio.innerHTML = dados.projetos
        .slice(-3)
        .reverse()
        .map(projeto => `

            <div class="item">

                <div class="item-topo">

                    <h3>${escapar(projeto.nome)}</h3>

                    <span class="status">
                        ${escapar(projeto.status)}
                    </span>

                </div>

                <p>${escapar(projeto.descricao)}</p>

            </div>

        `).join("");

}


/* =====================================
   CARGOS
===================================== */

function novoCargo() {

    const modal = document.getElementById("modal");
    const conteudo = document.getElementById("conteudoModal");

    conteudo.innerHTML = `

        <h2>Novo cargo</h2>

        <input id="novoCargoNome"
               placeholder="Nome do cargo">

        <input id="novoCargoDescricao"
               placeholder="Descrição / permissões">

        <button class="confirmar"
                onclick="salvarCargo()">
            CRIAR CARGO
        </button>

    `;

    modal.classList.remove("hidden");

}


function salvarCargo() {

    const nome =
        document.getElementById("novoCargoNome")
        .value.trim();

    const descricao =
        document.getElementById("novoCargoDescricao")
        .value.trim();

    if (!nome) {
        alert("Digite o nome do cargo.");
        return;
    }

    dados.cargos.push({

        id: Date.now(),

        nome: nome,

        descricao:
            descricao || "Sem descrição."

    });

    salvar();

    fecharModal();

    atualizarInterface();

    abrirPagina("cargos");

}


/* =====================================
   LISTAR CARGOS
===================================== */

function renderizarCargos() {

    const lista =
        document.getElementById("listaCargos");

    lista.innerHTML = dados.cargos.map(cargo => `

        <div class="item">

            <div class="item-topo">

                <h3>${escapar(cargo.nome)}</h3>

                <span class="status">
                    ${contarPessoasCargo(cargo.nome)}
                    pessoa(s)
                </span>

            </div>

            <p>
                ${escapar(cargo.descricao)}
            </p>

        </div>

    `).join("");

}


function contarPessoasCargo(cargo) {

    return dados.pessoas.filter(
        pessoa => pessoa.cargo === cargo
    ).length;

}


/* =====================================
   MODAL
===================================== */

function fecharModal() {

    document.getElementById("modal")
        .classList.add("hidden");

}


/* =====================================
   SAIR
===================================== */

function sair() {

    sessionStorage.removeItem("SER_LOGADO");

    document.getElementById("sistema")
        .classList.add("hidden");

    document.getElementById("auth")
        .classList.remove("hidden");

    document.getElementById("loginSenha").value = "";

}


/* =====================================
   SEGURANÇA BÁSICA DE TEXTO
===================================== */

function escapar(texto) {

    return String(texto)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}

