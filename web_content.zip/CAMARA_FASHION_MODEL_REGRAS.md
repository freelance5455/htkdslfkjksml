# Câmara se Fashion Model — regras do aplicativo

## Acesso
- O aplicativo funciona somente com internet.
- O utilizador deve autenticar-se com Google antes de acessar concursos e votação.
- Utilizadores comuns não podem criar concursos, participantes ou imagens.

## Administrador
Somente o dono/admin autorizado pode:
- criar, editar, abrir e encerrar concursos;
- definir nome, código, datas, capa e imagens;
- cadastrar participantes e definir nome/código/número/foto;
- definir o preço de 1 voto em Meticais (MT);
- configurar o método/destino de pagamento;
- acompanhar votos, pagamentos e valores arrecadados.

## Votação
- O utilizador escolhe um concurso e participante.
- O sistema calcula o total: quantidade de votos × preço por voto.
- O voto só é contabilizado depois da confirmação do pagamento pelo provedor de pagamento.
- Toda transação deve possuir um identificador e ficar registada.
- O sistema deve impedir votos fictícios ou alterações diretas no total de votos.

## Segurança
- As credenciais do administrador nunca ficam expostas no cliente.
- Operações administrativas e confirmação de pagamentos devem ocorrer no backend.
- Não guardar palavras-passe Google no aplicativo; usar OAuth/Firebase Auth ou serviço equivalente.
- O destino real dos pagamentos deve ser configurado no backend/provedor, não apenas em texto na interface.

## Marca
Nome do aplicativo: Câmara se Fashion Model


## Regra de dados iniciais
- NÃO existe participante padrão, incluindo Yasmin/Yasmine.
- O aplicativo deve iniciar sem nomes, fotos ou concursos de exemplo.
- O administrador é quem cadastra todos os concursos, imagens, participantes, nomes e códigos.
- Nenhum nome de participante deve ficar fixo no código.
- O conteúdo exibido aos utilizadores vem dos dados publicados pelo administrador.

## Internet
- O aplicativo é somente online.
- Sem conexão com a internet, concursos, imagens, login, pagamentos e votação não funcionam.
