# Aldeia do Reino v9 — notas

- Pacote browser-first, sem necessidade de compilar o projeto Capacitor.
- `index.html` na raiz para conversores que usam a página inicial da raiz.
- `web/index.html` para conversores que carregam `https://appassets.androidplatform.net/web/index.html`.
- `www/index.html` incluído como terceira convenção comum.
- Mundo procedural em setores; oito raças/personas; identidade, objetivos, valores e segredos por personagem; memória local; diálogo contextual; interação social; recrutamento e domesticação em função de força, intelecto, felicidade/vínculo, medo e agressividade.
- Os diálogos individuais são dirigidos por regras locais e memória, com opção de servidor remoto configurável. Não há um modelo de IA generativa completo embutido.
- Correção do limite entre setores e desativação da tentativa de service worker no host appassets para evitar cache antigo nessa rota.
- O modo 3D ainda requer que o CDN Three.js seja acessível; o modo de compatibilidade 2D continua disponível caso falhe.
