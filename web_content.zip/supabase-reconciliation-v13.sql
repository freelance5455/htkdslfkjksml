-- WONDER SHIFT V13 — RÉCONCILIATION DE LA BASE SUPABASE EXISTANTE
-- À exécuter APRÈS les actions/migrations déjà réalisées dans le projet.
-- Ce script ne recrée pas les tables et ne demande aucune clé secrète.
-- Il remet seulement à niveau les colonnes/fonctions/policies nécessaires au paquet V13.

create extension if not exists pgcrypto;

-- 1) Colonnes attendues par l'application actuelle.
alter table public.profiles add column if not exists name text;
alter table public.profiles add column if not exists full_name text;
alter table public.profiles add column if not exists role text;
alter table public.profiles add column if not exists active boolean;
alter table public.profiles add column if not exists is_active boolean;
alter table public.profiles add column if not exists photo_url text;
alter table public.profiles add column if not exists created_at timestamptz;
alter table public.profiles add column if not exists updated_at timestamptz;
update public.profiles
set full_name=coalesce(nullif(full_name,''),nullif(name,''),'Utilisateur')
where full_name is null or full_name='';
update public.profiles
set name=coalesce(nullif(name,''),full_name,'Utilisateur')
where name is null or name='';
update public.profiles set role=coalesce(role,'Agent') where role is null;
update public.profiles set active=coalesce(active,true) where active is null;
update public.profiles set is_active=coalesce(is_active,active,true) where is_active is null;
update public.profiles set created_at=coalesce(created_at,now()) where created_at is null;
update public.profiles set updated_at=coalesce(updated_at,created_at,now()) where updated_at is null;

alter table public.operations add column if not exists agent_id uuid references auth.users(id);
alter table public.operations add column if not exists updated_at timestamptz default now();
alter table public.operations add column if not exists deleted boolean default false;
update public.operations set updated_at=coalesce(updated_at,created_at,date,now()) where updated_at is null;
update public.operations set deleted=coalesce(deleted,false) where deleted is null;

alter table public.operation_change_requests add column if not exists updated_at timestamptz default now();
alter table public.services add column if not exists updated_at timestamptz default now();
alter table public.tasks add column if not exists updated_at timestamptz default now();
alter table public.stock_items add column if not exists updated_at timestamptz default now();
alter table public.cash_sessions add column if not exists updated_at timestamptz default now();
alter table public.cash_movements add column if not exists operation_id text references public.operations(id) on delete set null;
alter table public.cash_handovers add column if not exists updated_at timestamptz default now();
alter table public.weekly_closures add column if not exists updated_at timestamptz default now();
alter table public.audit_logs add column if not exists device_id text;

-- 2) Fonctions de rôle : utilisées par toutes les policies RLS.
create or replace function public.current_user_role()
returns text language sql stable security definer
set search_path=public,pg_catalog
as $$
  select role from public.profiles
  where id=auth.uid() and coalesce(is_active,active,true)=true
  limit 1;
$$;
grant execute on function public.current_user_role() to authenticated;

grant execute on function public.bootstrap_available() to anon,authenticated;

-- 3) Supprime les anciennes policies des tables concernées afin qu'une policy historique
--    ne puisse pas contredire la règle V13.
do $$
declare p record;
begin
  for p in
    select schemaname, tablename, policyname
    from pg_policies
    where schemaname='public'
      and tablename in (
        'profiles','operations','operation_change_requests','services','tasks',
        'stock_items','stock_movements','cash_sessions','cash_movements',
        'cash_handovers','weekly_closures','notifications','audit_logs',
        'sync_devices','sync_conflicts','report_exports'
      )
  loop
    execute format('drop policy if exists %I on %I.%I',p.policyname,p.schemaname,p.tablename);
  end loop;
end $$;

alter table public.profiles enable row level security;
alter table public.operations enable row level security;
alter table public.operation_change_requests enable row level security;
alter table public.services enable row level security;
alter table public.tasks enable row level security;
alter table public.stock_items enable row level security;
alter table public.stock_movements enable row level security;
alter table public.cash_sessions enable row level security;
alter table public.cash_movements enable row level security;
alter table public.cash_handovers enable row level security;
alter table public.weekly_closures enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;
alter table public.sync_devices enable row level security;
alter table public.sync_conflicts enable row level security;
alter table public.report_exports enable row level security;

-- 4) Policies finales correspondant aux trois rôles du projet.
create policy profiles_select_authenticated on public.profiles
for select to authenticated using (true);
create policy profiles_insert_developer on public.profiles
for insert to authenticated with check (public.current_user_role()='Développeur');
create policy profiles_update_developer on public.profiles
for update to authenticated
using (public.current_user_role()='Développeur')
with check (public.current_user_role()='Développeur');

create policy operations_select_authenticated on public.operations
for select to authenticated
using (public.current_user_role() in ('Agent','Superviseur','Développeur'));
create policy operations_insert_authenticated on public.operations
for insert to authenticated
with check (
  public.current_user_role() in ('Agent','Superviseur','Développeur')
  and (public.current_user_role() in ('Superviseur','Développeur') or agent_id=auth.uid())
);
create policy operations_update_management on public.operations
for update to authenticated
using (public.current_user_role() in ('Superviseur','Développeur'))
with check (public.current_user_role() in ('Superviseur','Développeur'));

create policy ocr_select on public.operation_change_requests
for select to authenticated
using (requested_by=auth.uid() or public.current_user_role() in ('Superviseur','Développeur'));
create policy ocr_insert on public.operation_change_requests
for insert to authenticated
with check (requested_by=auth.uid() and public.current_user_role() in ('Agent','Superviseur','Développeur'));
create policy ocr_update on public.operation_change_requests
for update to authenticated
using (public.current_user_role() in ('Superviseur','Développeur'))
with check (public.current_user_role() in ('Superviseur','Développeur'));

create policy services_read_all on public.services for select to authenticated using (true);
create policy services_write_management on public.services for all to authenticated
using (public.current_user_role() in ('Superviseur','Développeur'))
with check (public.current_user_role() in ('Superviseur','Développeur'));
create policy tasks_read_all on public.tasks for select to authenticated using (true);
create policy tasks_write_management on public.tasks for all to authenticated
using (public.current_user_role() in ('Superviseur','Développeur'))
with check (public.current_user_role() in ('Superviseur','Développeur'));

create policy stock_read_all on public.stock_items for select to authenticated using (true);
create policy stock_write_dev on public.stock_items for all to authenticated
using (public.current_user_role()='Développeur')
with check (public.current_user_role()='Développeur');
create policy stock_mov_read_all on public.stock_movements for select to authenticated using (true);
create policy stock_mov_insert_mgmt on public.stock_movements for insert to authenticated
with check (public.current_user_role() in ('Superviseur','Développeur'));

create policy cash_sessions_select on public.cash_sessions for select to authenticated
using (public.current_user_role() in ('Agent','Superviseur','Développeur'));
create policy cash_sessions_write on public.cash_sessions for all to authenticated
using (public.current_user_role() in ('Superviseur','Développeur'))
with check (public.current_user_role() in ('Superviseur','Développeur'));
create policy cash_movements_select on public.cash_movements for select to authenticated
using (public.current_user_role() in ('Agent','Superviseur','Développeur'));
create policy cash_movements_insert on public.cash_movements for insert to authenticated
with check (
  public.current_user_role() in ('Superviseur','Développeur')
  or (public.current_user_role()='Agent' and agent_id=auth.uid())
);

create policy handovers_select on public.cash_handovers for select to authenticated
using (public.current_user_role() in ('Agent','Superviseur','Développeur'));
create policy handovers_insert on public.cash_handovers for insert to authenticated
with check (handed_over_by=auth.uid() and public.current_user_role() in ('Agent','Superviseur','Développeur'));
create policy handovers_update_management on public.cash_handovers for update to authenticated
using (public.current_user_role() in ('Superviseur','Développeur'))
with check (public.current_user_role() in ('Superviseur','Développeur'));

create policy weekly_closures_select on public.weekly_closures for select to authenticated
using (public.current_user_role() in ('Agent','Superviseur','Développeur'));
create policy weekly_closures_insert on public.weekly_closures for insert to authenticated
with check (prepared_by=auth.uid() and public.current_user_role() in ('Agent','Superviseur','Développeur'));
create policy weekly_closures_update on public.weekly_closures for update to authenticated
using (public.current_user_role() in ('Superviseur','Développeur'))
with check (public.current_user_role() in ('Superviseur','Développeur'));

create policy notifications_select on public.notifications for select to authenticated
using (user_id=auth.uid() or public.current_user_role() in ('Superviseur','Développeur'));
create policy notifications_insert on public.notifications for insert to authenticated
with check (public.current_user_role() in ('Superviseur','Développeur') and (user_id is null or user_id=auth.uid()));

create policy audit_insert_auth on public.audit_logs for insert to authenticated
with check (user_id=auth.uid());
create policy audit_read_developer on public.audit_logs for select to authenticated
using (public.current_user_role()='Développeur');

create policy sync_devices_select on public.sync_devices for select to authenticated
using (user_id=auth.uid() or public.current_user_role() in ('Superviseur','Développeur'));
create policy sync_devices_insert on public.sync_devices for insert to authenticated
with check (user_id=auth.uid());
create policy sync_devices_update on public.sync_devices for update to authenticated
using (user_id=auth.uid() or public.current_user_role()='Développeur')
with check (user_id=auth.uid() or public.current_user_role()='Développeur');

create policy sync_conflicts_insert on public.sync_conflicts for insert to authenticated
with check (user_id=auth.uid());
create policy sync_conflicts_read_management on public.sync_conflicts for select to authenticated
using (public.current_user_role() in ('Superviseur','Développeur'));

create policy report_exports_select_management on public.report_exports for select to authenticated
using (public.current_user_role() in ('Superviseur','Développeur'));
create policy report_exports_insert_authenticated on public.report_exports for insert to authenticated
with check (generated_by=auth.uid() and public.current_user_role() in ('Agent','Superviseur','Développeur'));

-- 5) Audit automatique conservé sur les opérations et remises.
create or replace function public.audit_operation_change()
returns trigger language plpgsql security definer set search_path=public,pg_catalog
as $$
begin
  insert into public.audit_logs(id,user_id,action,metadata,created_at)
  values ('AUD-'||replace(gen_random_uuid()::text,'-',''),auth.uid(),
          case when TG_OP='INSERT' then 'operation.created' when TG_OP='UPDATE' then 'operation.updated' else 'operation.deleted' end,
          jsonb_build_object('operation_id',coalesce(new.id,old.id),'operation_type',coalesce(new.type,old.type)),now());
  return coalesce(new,old);
end;
$$;
drop trigger if exists trg_audit_operations on public.operations;
create trigger trg_audit_operations after insert or update or delete on public.operations
for each row execute function public.audit_operation_change();

create or replace function public.audit_handover_change()
returns trigger language plpgsql security definer set search_path=public,pg_catalog
as $$
begin
  insert into public.audit_logs(id,user_id,action,metadata,created_at)
  values ('AUD-'||replace(gen_random_uuid()::text,'-',''),auth.uid(),
          case when TG_OP='INSERT' then 'cash.handover.created' when TG_OP='UPDATE' then 'cash.handover.updated' else 'cash.handover.deleted' end,
          jsonb_build_object('handover_id',coalesce(new.id,old.id)),now());
  return coalesce(new,old);
end;
$$;
drop trigger if exists trg_audit_handovers on public.cash_handovers;
create trigger trg_audit_handovers after insert or update or delete on public.cash_handovers
for each row execute function public.audit_handover_change();

-- 6) Index utiles pour le sync/rapports.
create index if not exists operations_updated_at_idx on public.operations(updated_at);
create index if not exists operations_agent_date_idx on public.operations(agent_id,date);
create index if not exists ocr_operation_id_idx on public.operation_change_requests(operation_id);
create index if not exists cash_movements_operation_idx on public.cash_movements(operation_id);
create index if not exists cash_handovers_week_idx on public.cash_handovers(week_start,week_end);
create index if not exists audit_logs_created_idx on public.audit_logs(created_at);
create index if not exists sync_devices_user_idx on public.sync_devices(user_id);
create index if not exists weekly_closures_week_idx on public.weekly_closures(week_start,week_end);

-- Fin V13. Ne contient aucune clé service_role.
