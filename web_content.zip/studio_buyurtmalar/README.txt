GOLD STAR VIDEO STUDIO — BUYURTMALAR

Bu hozircha offline ishlaydigan PWA prototipi (APK emas).

Sinash:
1. ZIP ichidagi fayllarni hostingga (HTTPS) joylang yoki lokal web-server orqali oching.
2. Android Chrome'da manzilni oching.
3. Brauzer menyusidan “Add to Home screen / Bosh ekranga qo‘shish”ni tanlang.

Imkoniyatlar:
- Sana, vaqt, mijoz ismi, telefon, manzil, xizmat turi, izoh.
- Buyurtma qo‘shish, tahrirlash, o‘chirish.
- Qidirish va kelgusi/o‘tgan buyurtmalar filtri.
- Jami, shu oy va 7 kun ichidagi buyurtmalar hisoblagichi.
- JSON zaxira nusxasini olish va tiklash.
- Service worker orqali offline ishga tushish (birinchi marta internet/HTTPS orqali ochilgandan keyin).

Muhim: ma’lumotlar aynan shu brauzer/telefonda localStorage'da saqlanadi. Ilova ma’lumotlarini tozalashdan oldin zaxira nusxa oling.

APK yig‘ish uchun Android SDK va Gradle build muhiti kerak. Bu ish muhitida ular mavjud emas, shu sababli ushbu ZIP'dan APK tayyor deb da'vo qilinmaydi.
