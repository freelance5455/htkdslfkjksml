import React, { useState } from 'react';
import { View, Text, Pressable, ActivityIndicator } from 'react-native';
import OfflineAIModelManager from './OfflineAIModelManager';

// Example manual mode selector.
// Keep your existing Gemini code in the Online branch of your chat handler.
export function AIModelModeSelector({ mode, onChange }) {
  return (
    <View style={{ flexDirection: 'row', gap: 10 }}>
      <Pressable onPress={() => onChange('online')}
        style={{ padding: 12, borderRadius: 10, backgroundColor: mode === 'online' ? '#2563eb' : '#e5e7eb' }}>
        <Text style={{ color: mode === 'online' ? '#fff' : '#111' }}>Online AI</Text>
      </Pressable>
      <Pressable onPress={() => onChange('offline')}
        style={{ padding: 12, borderRadius: 10, backgroundColor: mode === 'offline' ? '#2563eb' : '#e5e7eb' }}>
        <Text style={{ color: mode === 'offline' ? '#fff' : '#111' }}>Offline AI</Text>
      </Pressable>
    </View>
  );
}

// Example download control to place in your Settings / Offline Model screen.
export function OfflineModelDownloadButton() {
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  const download = async () => {
    setBusy(true);
    setMessage('');
    try {
      await OfflineAIModelManager.downloadModel(setProgress);
      setMessage('Model downloaded. You can now select Offline AI.');
    } catch (error) {
      setMessage(error?.message || 'Download failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ gap: 8 }}>
      <Pressable disabled={busy} onPress={download}
        style={{ padding: 14, borderRadius: 10, backgroundColor: '#2563eb', opacity: busy ? 0.6 : 1 }}>
        <Text style={{ color: '#fff', textAlign: 'center' }}>
          {busy ? 'Downloading model…' : 'Download offline model'}
        </Text>
      </Pressable>
      {busy ? <Text>{progress.toFixed(1)}%</Text> : null}
      {busy ? <ActivityIndicator /> : null}
      {!!message && <Text>{message}</Text>}
    </View>
  );
}

// Example send handler inside your chat screen:
// const [mode, setMode] = useState('online');
// async function sendMessage(text) {
//   if (mode === 'offline') {
//     const answer = await OfflineAIModelManager.generate(text, token => {
//       // Append token to the currently streaming assistant message.
//     });
//     return answer;
//   }
//   // Call your existing Gemini API implementation here.
// }
