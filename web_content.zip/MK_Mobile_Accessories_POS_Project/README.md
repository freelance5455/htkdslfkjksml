# MK Mobile Accessories POS

Android WebView project containing an offline-first HTML POS.

## Included
- Product and stock management with brand and barcode text fields
- Billing, discount, paid/due, receipts, sales/profit overview
- Customer credit and repayments
- Urdu, English, Pashto language selector
- JSON backup/restore, CSV sales export, reset all
- WhatsApp share link, SMS composer link, system print dialog

## Build
Open this folder in Android Studio with SDK Platform 35 and JDK 17, sync Gradle, then use **Build > Build APK(s)**. See `BUILD_INSTRUCTIONS_UR.txt`.

## Limits
This ZIP is source code, not a prebuilt APK. Some translation strings may remain in English/Urdu. Direct Bluetooth thermal printing and automatic SMS sending are not implemented. Test backup/restore and local storage on the target device before using real business records.
