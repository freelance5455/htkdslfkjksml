# Life Guide — Capacitor (real Android app) setup

Do this on your HP laptop. You need **Node.js LTS** and **Android Studio** (as for Nurul Hidayah).
Stop after each step and check the result before continuing.

## ⚠️ Before anything — protect your data
A Capacitor app is a *different app* from your current converter-made APK, so its data starts empty.
1. In the OLD app: Settings → **Share backup** (or Export / Copy backup text). Save the file somewhere safe.
2. Install the new app, then Settings → **Import (replace all)** (or paste the text) to restore.
3. Only uninstall the old app after you have confirmed everything restored.

## 1. Install dependencies
```
cd life-guide        (the unzipped project folder)
npm install
```

## 2. Choose the app ID (once — never change it later)
`capacitor.config.json` uses `com.ahcreative.lifeguide`. Keep it. Changing it later makes Android treat it as a different app.

## 3. Add Android and copy the web app
```
npx cap add android
npm run sync
```

## 4. Allow notifications (Android 13+ and exact alarms)
Open `android/app/src/main/AndroidManifest.xml` and, inside `<manifest>` (above `<application>`), add:
```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
<uses-permission android:name="android.permission.USE_EXACT_ALARM" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
```
Then in Life Guide → Settings → Reminders, tap **Allow notifications**.

## 5. Icon and name
App name comes from `capacitor.config.json` ("Life Guide"). To replace the icon, use Android Studio:
right-click `res` → New → Image Asset → pick `icons/icon-512.png`.

## 6. Build the APK
```
npm run open
```
In Android Studio: **Build → Build Bundle(s)/APK(s) → Build APK(s)**. Install the debug APK on your phone to test.
For a release APK use **Build → Generate Signed Bundle / APK** and keep your keystore file safe (back it up!).

## 7. Updating later
After any change to the web files: `npm run sync`, then build again. Always increase the version, and install over the old app (same app ID, same signing key) so data is kept. Back up first anyway.

## Optional
- **Fingerprint unlock**: `npm i @aparajita/capacitor-biometric-auth` then `npx cap sync`. Life Guide shows "Use fingerprint" on the lock screen automatically when the plugin exists.
- **Blank screen in recent apps**: the web layer already covers the screen when you switch away; the strongest version is Android's FLAG_SECURE (`@capacitor-community/privacy-screen`).
