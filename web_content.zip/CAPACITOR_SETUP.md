# AllJi — Capacitor setup

This project has been prepared for Capacitor packaging.

## Next steps
1. Install dependencies:
   npm install
2. Build the web app:
   npm run build
3. Add Android:
   npx cap add android
4. Sync:
   npx cap sync android
5. Open in Android Studio:
   npx cap open android

For iOS, on a Mac with Xcode:
1. npx cap add ios
2. npx cap sync ios
3. npx cap open ios

Note: The Android/iOS native folders are intentionally not pre-generated here because they require the platform toolchains. This ZIP contains the Capacitor configuration needed to generate them.
