# V9K Family Android App — v1.0.0

Basic Android WebView app for the V9K Family Free Fire Tournament Nepal interface.

## Included
- Existing `index.html` bundled inside the APK
- V9K Family app name and launcher icon
- Portrait mobile layout
- JavaScript, DOM storage and WebView database support
- Image/file chooser support
- Internet permission for Supabase and online features
- Version 1.0.0

## Important
The current environment does not contain the Android SDK/Gradle build tools, so this project has not been compiled into an APK here.

To build: open this folder in Android Studio and choose **Build > Build APK(s)**.

Live Khalti/backend functions still require the corresponding server/backend deployment. They can be added in a later app version without changing the basic APK structure.
