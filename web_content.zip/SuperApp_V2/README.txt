SUPER APP V2 — STARTER PROTOTYPE
=================================

Files
- index.html: mobile-friendly Hindi/English prototype
- README.txt: this guide
- ROADMAP.txt: practical next steps toward a real Android/Play Store app

How to preview on an Android phone
1. Download and extract this ZIP.
2. Open index.html in a mobile browser or use a simple HTML preview/editor app.
3. Try the bottom tabs: Home, Videos, Upload, Chat, Calls, Games, Profile.
4. Use the Hindi / EN button to switch languages.

Important limitations
This is a clickable front-end prototype, NOT a finished Android APK or Play Store release.
- Upload only selects a local video; it does not upload it to a server.
- Chat messages are local demo messages, not sent to another person.
- Call buttons show a demo notice; no real audio/video call is placed.
- The tap game is a local mini-game; it is not multiplayer.
- Profile name is stored locally in the browser.
- No real login, database, cloud video storage, moderation, reporting, or privacy backend is connected.

Before public release
A real app needs a backend/authentication, video storage and streaming, user-to-user chat, WebRTC or a calling provider, game implementation, abuse reporting/blocking, privacy policy, Data Safety answers, and testing. Do not advertise demo buttons as live features.
