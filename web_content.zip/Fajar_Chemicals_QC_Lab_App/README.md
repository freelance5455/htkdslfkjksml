# Fajar Chemicals QC Laboratory - Report Generator

Open `index.html`. Menu: Dashboard, Reports, Live Preview, Print & Download, Account Settings.

* **Reports**: all template fields editable, tick Raw Material / Batch Analysis / External, test table with add/reorder rows, optional extra columns and extra header fields, FIT/UNFIT verdict, calendar date pickers, 500g/1000g sample sizes.
* **PDF**: "Generate PDF" opens the sheet; choose Save as PDF.
* **Dashboard**: totals, company vs external, per-month chart, date-ordered table, filters, backup/restore.
* **Monthly report**: pick a month, export Excel (.xls), Word (.doc) or PDF.
* **Email storage**: dashboard > "Email & sync". Enter your email and a sync endpoint (e.g. a free Formspree form, or a Google Apps Script web app that emails the posted JSON). With data on, unsent reports (marked with an amber dot) are posted automatically; offline reports queue until you reconnect. A browser cannot send email silently without such an endpoint.

* **Share**: when online, a Share button (report page, Live Preview, report list) opens WhatsApp or email with the report summary ready to send. Account Settings > WhatsApp: add your number, and optionally a gateway URL for automatic sending.

## Developer notes
* `src/ts/` TypeScript -> `js/xml.js` (XML import/export, Excel XML). `src/scss/theme.scss` -> `css/theme.css`. `src/less/print.less` -> `css/print.css`. `tailwind.config.js` + `src/input.css` are ready for `npm run build:tw` (not linked yet).
* Run `npm install` then `npm run build` to regenerate the compiled files.
