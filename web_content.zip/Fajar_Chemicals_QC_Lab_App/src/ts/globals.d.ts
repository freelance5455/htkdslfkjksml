interface TestRow { t: string; s: string; r: string; m: string; k: string; x: string[]; }
interface QcReport {
  id: string; no: string; type: 'raw' | 'batch' | 'external'; m: Record<string, string>;
  xf: string; xc: string[]; rows: TestRow[]; verdict: 'FIT' | 'UNFIT'; overall: string;
  sig: Record<string, string>; created: number; updated?: number; synced?: boolean; draft?: boolean;
}
declare const DB: { all(): QcReport[]; save(a: QcReport[]): void; get(id: string): QcReport | undefined };
declare const CAT: Record<string, string>;
declare const MN: (mon: string) => string;
declare function toast(t: string, err?: number): void;
declare function dl(name: string, mime: string, html: string): void;
declare function today(): string;
declare function fd(v: string | undefined): string;
declare function monthList(mon: string): QcReport[];
declare function exportMonth(mon: string, kind: string): void;
declare function render(): void;
