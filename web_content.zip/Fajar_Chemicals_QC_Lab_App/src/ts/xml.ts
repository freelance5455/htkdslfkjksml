/* Fajar QC - XML import/export and real Excel XML (SpreadsheetML). Compiled by tsc to js/xml.js */
(() => {
  const ESC: Record<string, string> = { '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' };
  const X = (s: unknown): string => String(s == null ? '' : s).replace(/[<>&"']/g, c => ESC[c]);

  function reportsToXml(list: QcReport[]): string {
    const body = list.map(r =>
      `<Report id="${X(r.id)}" no="${X(r.no)}" type="${r.type}" verdict="${r.verdict}" created="${r.created}">` +
      Object.keys(r.m).map(k => `<Field name="${X(k)}">${X(r.m[k])}</Field>`).join('') +
      `<ExtraFields>${X(r.xf)}</ExtraFields><ExtraColumns>${r.xc.map(c => `<Column>${X(c)}</Column>`).join('')}</ExtraColumns><Tests>` +
      r.rows.map(w => `<Test><Name>${X(w.t)}</Name><Specification>${X(w.s)}</Specification><Result>${X(w.r)}</Result><Method>${X(w.m)}</Method><Remarks>${X(w.k)}</Remarks>${Array.from(w.x || [], v => `<Extra>${X(v)}</Extra>`).join('')}</Test>`).join('') +
      `</Tests><OverallRemarks>${X(r.overall)}</OverallRemarks><Signatures prepared="${X(r.sig.preparedBy)}" reviewed="${X(r.sig.reviewedBy)}" approved="${X(r.sig.approvedBy)}"/></Report>`
    ).join('\n');
    return `<?xml version="1.0" encoding="UTF-8"?>\n<FajarQcReports version="1" exported="${new Date().toISOString()}">\n${body}\n</FajarQcReports>`;
  }

  function xmlToReports(text: string): QcReport[] {
    const doc = new DOMParser().parseFromString(text, 'application/xml');
    if (doc.querySelector('parsererror') || doc.documentElement.nodeName !== 'FajarQcReports') throw new Error('Not a Fajar QC XML file');
    const t = (e: Element, n: string): string => { const c = e.getElementsByTagName(n)[0]; return c ? c.textContent || '' : ''; };
    return Array.from(doc.getElementsByTagName('Report')).map((e): QcReport => {
      const m: Record<string, string> = {};
      Array.from(e.getElementsByTagName('Field')).forEach(f => { m[f.getAttribute('name') || ''] = f.textContent || ''; });
      const sg = e.getElementsByTagName('Signatures')[0];
      const a = (n: string): string => (sg && sg.getAttribute(n)) || '';
      return {
        id: e.getAttribute('id') || '', no: e.getAttribute('no') || '',
        type: (e.getAttribute('type') || 'batch') as QcReport['type'],
        verdict: e.getAttribute('verdict') === 'UNFIT' ? 'UNFIT' : 'FIT',
        created: Number(e.getAttribute('created')) || Date.now(), m,
        xf: t(e, 'ExtraFields'), xc: Array.from(e.getElementsByTagName('Column'), c => c.textContent || ''),
        rows: Array.from(e.getElementsByTagName('Test'), (w): TestRow => ({
          t: t(w, 'Name'), s: t(w, 'Specification'), r: t(w, 'Result'), m: t(w, 'Method'), k: t(w, 'Remarks'),
          x: Array.from(w.getElementsByTagName('Extra'), x => x.textContent || '')
        })),
        overall: t(e, 'OverallRemarks'), sig: { preparedBy: a('prepared'), reviewedBy: a('reviewed'), approvedBy: a('approved') }, synced: false
      };
    });
  }

  function monthToSpreadsheetML(list: QcReport[], mon: string): string {
    const cell = (v: unknown, s?: string): string => `<Cell${s ? ` ss:StyleID="${s}"` : ''}><Data ss:Type="String">${X(v)}</Data></Cell>`;
    const row = (cells: unknown[], s?: string): string => `<Row>${cells.map(c => cell(c, s)).join('')}</Row>`;
    const head = ['QcReport No.', 'Test Date', 'Category', 'Source', 'Product', 'Batch', 'Test', 'Specification', 'Result', 'Method', 'Remarks', 'Verdict'];
    const data = list.flatMap(r => r.rows.filter(w => w.t).map(w =>
      row([r.no, fd(r.m.dateOfTest), CAT[r.type], r.m.source || 'N.A', r.m.productName || 'N.A', r.m.batchNo || 'N.A', w.t, w.s, w.r, w.m, w.k, r.verdict])));
    const n = (k: QcReport['type']): number => list.filter(r => r.type === k).length;
    const fit = list.filter(r => r.verdict === 'FIT').length;
    const sum = [['Month', MN(mon)], ['Total reports', String(list.length)], ['Raw material', String(n('raw'))], ['Batch analysis', String(n('batch'))], ['External', String(n('external'))], ['Fit', String(fit)], ['Unfit', String(list.length - fit)]].map(p => row(p)).join('');
    return `<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?>` +
      `<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">` +
      `<Styles><Style ss:ID="h"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#1F8A3B" ss:Pattern="Solid"/></Style></Styles>` +
      `<Worksheet ss:Name="Summary"><Table><Column ss:Width="120"/><Column ss:Width="120"/>${sum}</Table></Worksheet>` +
      `<Worksheet ss:Name="Reports"><Table>${head.map(() => '<Column ss:Width="95"/>').join('')}${row(head, 'h')}${data.join('')}</Table></Worksheet></Workbook>`;
  }

  const baseExport = exportMonth;
  (window as any).exportMonth = (mon: string, kind: string): void => {
    if (kind !== 'xls') { baseExport(mon, kind); return; }
    if (!mon) { toast('Choose a month first', 1); return; }
    const l = monthList(mon);
    if (!l.length) { toast('No reports in ' + MN(mon), 1); return; }
    dl(`Fajar_QC_${mon}.xls`, 'application/vnd.ms-excel', monthToSpreadsheetML(l, mon));
  };

  const pane = document.getElementById('v-print');
  if (pane) {
    pane.insertAdjacentHTML('beforeend', `<section class="card" style="margin-top:18px"><div class="card-head"><h2>XML data</h2></div><div class="card-body"><div class="fmt"><div class="tile"><b>Export XML</b><small>All reports as structured XML</small><button class="btn small" id="xmlOut">Download</button></div><div class="tile"><b>Import XML</b><small>Merge a Fajar QC XML file</small><button class="btn small" id="xmlIn">Choose file</button><input type="file" id="xmlFile" accept=".xml,text/xml" hidden></div><div class="tile"><b>Excel report</b><small>Monthly sheet is real Excel XML</small><span class="tag">SpreadsheetML</span></div></div></div></section>`);
    const file = document.getElementById('xmlFile') as HTMLInputElement;
    (document.getElementById('xmlOut') as HTMLButtonElement).onclick = () => {
      const a = DB.all();
      if (!a.length) { toast('No reports yet', 1); return; }
      dl(`Fajar_QC_reports_${today()}.xml`, 'application/xml', reportsToXml(a));
    };
    (document.getElementById('xmlIn') as HTMLButtonElement).onclick = () => file.click();
    file.onchange = async () => {
      const f = file.files && file.files[0];
      if (!f) return;
      try {
        const incoming = xmlToReports(await f.text()), all = DB.all();
        let added = 0;
        incoming.forEach(r => { if (r.id && !all.some(x => x.id === r.id)) { all.push(r); added++; } });
        DB.save(all); render(); toast(`Imported ${added} new report(s)`);
      } catch (e) { toast('Invalid XML file', 1); }
      file.value = '';
    };
  }
})();
