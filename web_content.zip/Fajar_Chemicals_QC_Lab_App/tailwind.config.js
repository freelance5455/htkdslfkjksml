/** Tailwind source config (build: npm run build:tw -> css/tailwind.css). Not linked into the pages yet. */
module.exports = { content: ['./*.html', './js/**/*.js'], theme: { extend: { colors: { brand: { DEFAULT: '#6d3be0', dark: '#4b24b8', soft: '#ede7fd' }, fajar: '#1f8a3b' }, fontFamily: { ui: ['system-ui', 'Segoe UI', 'Roboto', 'Arial', 'sans-serif'] } } }, plugins: [] };
