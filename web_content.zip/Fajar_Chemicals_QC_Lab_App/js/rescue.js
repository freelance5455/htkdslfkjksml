/* Real PDF files (pdf-lib, offline) + delivery that works without print dialogs, popups or file pickers */
(()=>{const {PDFDocument,StandardFonts,rgb}=PDFLib,K=rgb(0,0,0),WV=/; wv\)/.test(navigator.userAgent);
const T=s=>String(s==null?'':s).replace(/[\u2018\u2019]/g,"'").replace(/[\u201c\u201d]/g,'"').replace(/[\u2013\u2014]/g,'-').replace(/[^\x20-\x7E\xA0-\xFF]/g,'?');
const fit=(s,f,w,z)=>{while(z>5&&f.widthOfTextAtSize(s,z)>w-4)z-=.5;return z};
const wrap=(s,f,w,z)=>{const o=[];let c='';T(s).split(' ').forEach(x=>{const n=c?c+' '+x:x;if(f.widthOfTextAtSize(n,z)>w&&c){o.push(c);c=x}else c=n});o.push(c);return o};
async function build(list,monthly){const doc=await PDFDocument.create(),F=await doc.embedFont(StandardFonts.Helvetica),B=await doc.embedFont(StandardFonts.HelveticaBold),logo=await doc.embedPng(Uint8Array.from(atob(LOGO.split(',')[1]),c=>c.charCodeAt(0)));
 const mk=p=>{const Y=t=>842-t;return{box:(x,t,w,h,bw)=>p.drawRectangle({x,y:Y(t+h),width:w,height:h,borderColor:K,borderWidth:bw||.8}),line:(a,t,b,u,bw,c)=>p.drawLine({start:{x:a,y:Y(t)},end:{x:b,y:Y(u)},thickness:bw||.8,color:c||K}),
  txt(s,x,t,w,z,f,al){s=T(s);z=fit(s,f,w,z);const tw=f.widthOfTextAtSize(s,z);p.drawText(s,{x:al=='l'?x+2:al=='r'?x+w-tw-2:x+(w-tw)/2,y:Y(t)-z,size:z,font:f})}}};
 const L=28,W=539;
 if(monthly){const mon=list[0].m.dateOfTest.slice(0,7);let p=doc.addPage([595,842]),g=mk(p),t=40;p.drawImage(logo,{x:L,y:842-t-26,width:logo.width*26/logo.height,height:26});t+=40;
  g.txt('FAJAR CHEMICALS QUALITY CONTROL LABORATORY',L,t,W,14,B,'l');t+=24;g.txt('Monthly Test Report - '+MN(mon),L,t,W,12,B,'l');t+=22;
  const c=k=>list.filter(r=>r.type===k).length,f=list.filter(r=>r.verdict==='FIT').length;g.txt(`Total ${list.length}   Raw material ${c('raw')}   Batch ${c('batch')}   External ${c('external')}   Fit ${f}   Unfit ${list.length-f}`,L,t,W,9.5,F,'l');t+=22;
  list.forEach(r=>{if(t>800){p=doc.addPage([595,842]);g=mk(p);t=40}g.line(L,t-2,L+W,t-2,.3);g.txt(`${r.no}   ${fd(r.m.dateOfTest)}   ${CAT[r.type]}   ${r.m.productName||'N.A'}   ${r.verdict}`,L,t+1,W,9,F,'l');t+=16})}
 list.forEach(r=>{const p=doc.addPage([595,842]),g=mk(p),m=r.m,xc=r.xc||[],v=k=>DATEK.includes(k)?fd(m[k]):(m[k]||'N.A');
  g.txt('Report No: '+r.no,L,14,W,8,F,'r');g.box(L,30,W,78,2.5);g.txt('FAJAR CHEMICALS QUALITY CONTROL LABORATORY',L,40,W,15,B);g.line(L,60,L+W,60,1,rgb(.16,.43,.71));
  p.drawImage(logo,{x:L+8,y:842-92,width:logo.width*24/logo.height,height:24});g.txt('ADDRESS: HAVELI ROADCHOURAST MIAN KHAN TEH DEPALPUR DIST OKARA',L,94,W,8.5,F);
  g.box(L,108,W,20,2.5);g.txt('FERTILIZER TEST REPORTS',L,113,W,11,B);
  [['raw','RAWMATERIAL',L],['batch','BATCHANALYSIS',205],['external','EXTERNAL',420]].forEach(([k,l,x])=>{g.txt(l,x,148,200,8.5,B,'l');const bx=x+B.widthOfTextAtSize(l,8.5)+10;g.box(bx,140,38,22,1.5);if(r.type===k){g.line(bx+9,152,bx+15,158,1.8);g.line(bx+15,158,bx+29,144,1.8)}});
  const rows=PAIRS.map(q=>[q[0],v(q[1]),q[2],q[3]?v(q[3]):'']),xf=(r.xf||'').split('\n').map(l=>l.split(':')).filter(a=>a[0].trim()).map(a=>[a[0].trim(),a.slice(1).join(':').trim()||'N.A']);
  for(let i=0;i<xf.length;i+=2)rows.push([xf[i][0],xf[i][1],(xf[i+1]||[''])[0],(xf[i+1]||['',''])[1]]);
  let t=172;const cw=W/4;rows.forEach(q=>{q.forEach((s,i)=>{g.box(L+i*cw,t,cw,20);g.txt(s,L+i*cw,t+5.5,cw,9,i%2&&s!=='N.A'&&s!==''?B:F)});t+=20});
  const n=xc.length,ws=[24,20,18,22,16].map(w=>w*(100-12*n)/100).concat(xc.map(()=>12)).map(w=>W*w/100),row=(cells,h,z,f)=>{let x=L;cells.forEach((s,i)=>{g.box(x,t,ws[i],h);g.txt(s,x,t+(h-z)/2,ws[i],z,f);x+=ws[i]});t+=h};
  row(['Tests','Specification','Results','Methods','Remarks',...xc],20,9.5,B);r.rows.filter(w=>w.t||w.s||w.r||w.m||w.k).forEach(w=>row([w.t,w.s,w.r,w.m,w.k,...xc.map((c,j)=>(w.x||[])[j]||'')],28,10.5,F));
  t+=18;const rm=' THE PRODUCT '+(r.verdict==='FIT'?'COMPLIES WITH':'DOES NOT COMPLY WITH')+' THE STANDARD LIMITS, FOUND';g.txt('REMARKS:',L,t,70,10,B,'l');g.line(L+2,t+11,L+52,t+11,.8);g.txt(rm,L+52,t,420,9,F,'l');g.txt('['+r.verdict+']',L+52+F.widthOfTextAtSize(T(rm),9)+4,t-2,70,14,B,'l');
  t+=34;g.txt('OVERALL REMARKS:',L,t,160,10,B,'l');g.line(L+2,t+11,L+100,t+11,.8);t+=20;
  (r.overall||'').split('\n').filter(s=>s.trim()).forEach((s,i)=>{wrap(s,F,W-24,7.5).forEach((ln,j)=>{if(!j)g.txt((i+1)+'.',L,t,20,7.5,F,'l');g.txt(ln,L+18,t,W-20,7.5,F,'l');t+=10.5});t+=4});
  t=Math.max(t+36,730);[['preparedBy','PREPARED BY'],['reviewedBy','REVIEWED BY'],['approvedBy','APPROVED BY']].forEach(([k,l],i)=>{const x=L+i*(W/3)+10,w=W/3-20;g.txt((r.sig||{})[k]||'',x,t-14,w,9,F);g.line(x,t,x+w,t,.8);g.txt(l,x,t+3,w,8,B)})});
 return doc.save()}
const copy=async s=>{try{await navigator.clipboard.writeText(s);return 1}catch(e){const a=document.createElement('textarea');a.value=s;document.body.appendChild(a);a.select();let ok=0;try{ok=document.execCommand('copy')}catch(x){}a.remove();return ok}};
const box=h=>{let d=$('#rsDlg');if(!d){document.body.insertAdjacentHTML('beforeend','<dialog id="rsDlg" style="border:0;border-radius:18px;padding:22px;width:min(400px,92vw);box-shadow:0 12px 40px rgba(0,0,0,.35)"></dialog>');d=$('#rsDlg')}d.innerHTML=h;d.showModal();const c=$('#rsC');if(c)c.onclick=()=>d.close();return d};
const ext=u=>{if(WV&&!/^https?:/.test(u)){const f=document.createElement('iframe');f.style.display='none';f.src=u;document.body.appendChild(f);setTimeout(()=>f.remove(),1500)}else if(!window.open(u,'_blank'))location.href=u;toast('Opening\u2026 if nothing opens, use Copy message',0)};
async function deliver(bytes,name,text){const blob=new Blob([bytes],{type:'application/pdf'}),file=new File([blob],name,{type:'application/pdf'});
 if(navigator.canShare&&navigator.canShare({files:[file]})){try{await navigator.share({files:[file],title:name,text});return}catch(e){if(e.name==='AbortError')return}}
 const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();
 box(`<h2 style="margin:0 0 4px;font-size:18px">PDF ready</h2><p class="hint" style="margin:0 0 12px">${esc(name)}</p><div style="display:grid;gap:10px"><a class="btn primary" style="justify-content:center" href="${u}" download="${esc(name)}" target="_blank">Open / save PDF</a><button class="btn" id="rsK">Copy report text</button><button class="btn" id="rsC">Close</button></div><p class="hint" style="margin-top:10px">If nothing was saved, this app&rsquo;s browser blocks downloads. Open the app in Chrome, or copy the text and paste it into WhatsApp or email.</p>`);
 $('#rsK').onclick=async()=>toast(await copy(text)?'Copied':'Copy failed',0)}
const pdfOut=async(list,monthly)=>{if(!list.length)return toast('Nothing to export',1);try{toast('Preparing PDF\u2026');const nm=monthly?`Fajar_QC_${list[0].m.dateOfTest.slice(0,7)}.pdf`:list.length==1?list[0].no+'.pdf':'Fajar_QC_reports.pdf';await deliver(await build(list,monthly),nm,list.map(msgOf).join('\n\n'))}catch(e){toast('PDF failed: '+e.message,1)}};
window.openPrint=(list,auto,html)=>pdfOut(list,!!html);
window.shareDlg=r=>{if(!r)return toast('Nothing to share yet',1);if(!navigator.onLine)return toast('Connect to the internet to share',1);const c=Cfg.get(),n=(c.wa||'').replace(/\D/g,''),m=msgOf(r);
 box(`<h2 style="margin:0 0 4px;font-size:18px">Share ${esc(r.no)}</h2><p class="hint" style="margin:0 0 14px">${esc(r.m.productName||'N.A')} \u00b7 ${r.verdict}${n?' \u00b7 to +'+n:''}</p><div style="display:grid;gap:10px"><button class="btn primary" id="s1" style="background:#1fa855;justify-content:center">Send on WhatsApp</button><button class="btn" id="s2">Send by Email</button><button class="btn" id="s3">Share / save PDF</button><button class="btn" id="s4">Copy message</button><button class="btn" id="rsC">Close</button></div><p class="hint" style="margin-top:10px">If WhatsApp or Mail does not open from this app, tap Copy message and paste it, or open the app in Chrome.</p>`);
 $('#s1').onclick=()=>ext('https://wa.me/'+n+'?text='+encodeURIComponent(m));$('#s2').onclick=()=>ext('mailto:'+(c.email||'')+'?subject='+encodeURIComponent('Fajar QC Report '+r.no)+'&body='+encodeURIComponent(m));
 $('#s3').onclick=()=>{$('#rsDlg').close();pdfOut([r])};$('#s4').onclick=async()=>toast(await copy(m)?'Message copied':'Copy failed',0)};
if($('#v-account')){const sw=['#6d3be0','#1f8a3b','#2563a8','#b8860b','#c2410c','#0f766e'];
 $('#a_photo').closest('.fld').insertAdjacentHTML('beforeend','<small class="hint">If Choose File does nothing in your app, pick a colour instead:</small><div style="display:flex;gap:10px;margin-top:6px">'+sw.map(c=>`<button class="av" data-c="${c}" style="background:${c};width:34px;height:34px;cursor:pointer;border:2px solid #fff;box-shadow:0 0 0 1px #0003"></button>`).join('')+'</div>');
 $$('[data-c]').forEach(b=>b.onclick=()=>{Prof.set({...Prof.get(),color:b.dataset.c,photo:''});location.reload()});
 $('#v-print').insertAdjacentHTML('beforeend','<section class="card" style="margin-top:18px"><div class="card-head"><h2>Copy &amp; paste backup</h2></div><div class="card-body"><p class="hint" style="margin:0 0 10px">For apps that cannot save or pick files.</p><div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn small" id="bkCopy">Copy backup</button></div><textarea id="bkBox" rows="3" placeholder="Paste a copied backup here" style="width:100%;margin-top:10px"></textarea><button class="btn small" id="bkIn" style="margin-top:8px">Import pasted backup</button></div></section>');
 $('#bkCopy').onclick=async()=>toast(await copy(JSON.stringify(DB.all()))?'Backup copied':'Copy failed',0);
 $('#bkIn').onclick=()=>{try{const n=JSON.parse($('#bkBox').value),a=DB.all();n.forEach(r=>{if(!a.find(x=>x.id===r.id))a.push(r)});DB.save(a);render();toast('Imported '+n.length+' reports')}catch(e){toast('Not a valid backup',1)}}}
})();
