let F='all';const COL={raw:'#1f8a3b',batch:'#2563a8',external:'#b8860b'},dt=r=>r.m.dateOfTest||new Date(r.created).toISOString().slice(0,10);
$('#mon').value=today().slice(0,7);
function list(){const q=$('#q').value.toLowerCase(),f=$('#from').value,t=$('#to').value;
 const a=DB.all().filter(r=>(F=='all'||(F=='company'?r.type!='external':r.type==F))&&(!q||[r.no,r.m.productName,r.m.batchNo,r.m.source,r.m.sampleId,r.m.sampleBy].join(' ').toLowerCase().includes(q))&&(!f||dt(r)>=f)&&(!t||dt(r)<=t)).sort((x,y)=>(dt(x)+x.no).localeCompare(dt(y)+y.no));return $('#sort').value=='desc'?a.reverse():a}
function cv(id){const c=$(id),p=c.parentNode,d=devicePixelRatio||1,w=p.clientWidth,h=Math.max(p.clientHeight,220);c.width=w*d;c.height=h*d;c.style.width=w+'px';c.style.height=h+'px';const x=c.getContext('2d');x.scale(d,d);x.font='12px Segoe UI,Arial';return[x,w,h]}
function charts(a){if($('#chartMonthly').parentNode.clientWidth<40||$('#chartCategory').parentNode.clientWidth<40)return;let[x,w,h]=cv('#chartMonthly'),m={};a.forEach(r=>{const k=dt(r).slice(0,7);m[k]=(m[k]||0)+1});const ks=Object.keys(m).sort().slice(-12),mx=Math.max(1,...ks.map(k=>m[k])),bw=w/Math.max(ks.length,6);
 x.textAlign='center';ks.forEach((k,i)=>{const bh=(h-44)*m[k]/mx,bx=i*bw+bw*.18;x.fillStyle='#1f8a3b';x.fillRect(bx,h-24-bh,bw*.64,bh);x.fillStyle='#12211a';x.fillText(m[k],bx+bw*.32,h-28-bh);x.fillStyle='#5f6f66';x.fillText(new Date(k+'-01').toLocaleString('en',{month:'short'})+" '"+k.slice(2,4),bx+bw*.32,h-8)});
 [x,w,h]=cv('#chartCategory');const t=a.length,cx=w/2,cy=h/2,R=Math.min(w,h)/2-10;let s=-Math.PI/2;
 if(!t){x.fillStyle='#dde5df';x.beginPath();x.arc(cx,cy,R,0,7);x.arc(cx,cy,R*.6,0,7,true);x.fill()}
 Object.keys(CAT).forEach(k=>{const n=a.filter(r=>r.type===k).length,e=s+2*Math.PI*n/(t||1);if(n){x.fillStyle=COL[k];x.beginPath();x.arc(cx,cy,R,s,e);x.arc(cx,cy,R*.6,e,s,true);x.fill()}s=e});
 x.fillStyle='#12211a';x.textAlign='center';x.font='700 24px Segoe UI,Arial';x.fillText(t,cx,cy+8)}
function render(){const all=DB.all(),a=list(),c=k=>all.filter(r=>r.type===k).length,fit=all.filter(r=>r.verdict==='FIT').length;
 $('#kpiTotal').textContent=all.length;$('#kpiCompany').textContent=c('raw')+c('batch');$('#kpiCompanySub').textContent=c('raw')+' raw material \u00b7 '+c('batch')+' batch';$('#kpiExternal').textContent=c('external');$('#kpiFit').textContent=fit;$('#kpiUnfit').textContent=all.length-fit;$('#kpiLast').textContent=all.length?fd(all.map(dt).sort().pop()):'\u2014';
 const ch=[['all','All',all.length],['company','Company',c('raw')+c('batch')],['raw','Raw Material',c('raw')],['batch','Batch Analysis',c('batch')],['external','External / Outdoor',c('external')]];
 $('#chips').innerHTML=ch.map(x=>`<button class="chip${F==x[0]?' active':''}" data-f="${x[0]}">${x[1]} <span class="n">${x[2]}</span></button>`).join('');
 $('#legend').innerHTML=Object.keys(CAT).map(k=>`<div class="item"><span class="dot" style="background:${COL[k]}"></span>${CAT[k]}<span class="val">${c(k)}</span></div>`).join('');
 $('#rowCount').textContent=a.length+' report'+(a.length==1?'':'s');
 $('#rows').innerHTML=a.length?a.map(r=>`<tr><td class="mono">${esc(r.no)}${r.draft?' <em class="dft">draft</em>':r.synced?'':' <span title="Waiting to sync" style="color:#b8860b">\u25cf</span>'}</td><td>${fd(dt(r))}</td><td><b>${esc(r.m.productName||'N.A')}</b><br><small>${esc(r.m.batchNo||'')}</small></td><td><span class="badge ${r.type}">${CAT[r.type]}</span></td><td>${esc(r.m.source||'N.A')}</td><td>${esc(r.m.sampleBy||'N.A')}</td><td><span class="badge ${r.verdict.toLowerCase()}">${r.verdict}</span></td><td>${fd(new Date(r.created).toISOString().slice(0,10))}</td><td class="actions"><a class="btn small" href="report.html?id=${r.id}">Open</a> <button class="btn small" data-p="${r.id}">PDF</button> <button class="btn small onl" data-s="${r.id}">Share</button> <button class="btn small danger" data-d="${r.id}">Delete</button></td></tr>`).join(''):'<tr><td colspan="9"><div class="empty"><strong>No reports yet</strong>Click \u201c+ New Report\u201d or \u201cAdd sample data\u201d.</div></td></tr>';
 charts(all);status()}
function status(){const p=Sync.pending(),c=Cfg.get();$('#syncSt').textContent=(navigator.onLine?'Online':'Offline')+' \u00b7 '+(p?p+' pending':'all synced')+(c.email?' \u00b7 '+c.email:' \u00b7 no email linked')}
window.onSynced=render;addEventListener('online',status);addEventListener('offline',status);addEventListener('resize',()=>charts(DB.all()));
document.addEventListener('click',e=>{const t=e.target.closest('button');if(!t)return;
 if(t.dataset.f){F=t.dataset.f;render()}if(t.dataset.x)exportMonth($('#mon').value,t.dataset.x);
 if(t.dataset.p)openPrint([DB.get(t.dataset.p)],true);
 if(t.dataset.d&&confirm('Delete this report?')){DB.del(t.dataset.d);render()}});
['q','from','to','sort'].forEach(i=>$('#'+i).addEventListener('input',render));
$('#btnClear').onclick=()=>{$('#q').value=$('#from').value=$('#to').value='';F='all';render()};
$('#btnExportAll').onclick=()=>dl('Fajar_QC_backup_'+today()+'.json','application/json',JSON.stringify(DB.all()));
$('#btnImport').onclick=()=>$('#importFile').click();
$('#importFile').onchange=async e=>{try{const n=JSON.parse(await e.target.files[0].text()),a=DB.all();n.forEach(r=>{if(!a.find(x=>x.id===r.id))a.push(r)});DB.save(a);toast('Restored '+n.length+' reports');render()}catch(x){toast('Invalid backup file',1)}};
$('#btnSeed').onclick=()=>{const mk=(t,n,s,d,i,p,sp,rs,v,b)=>{const r=blank();r.type=t;Object.assign(r.m,{productName:n,source:s,activeIngredient:i,activePercentage:p,dateOfTest:d,sampleReceivedOn:d,resultReportedOn:d,sampleBy:'Ali Raza',sampleReceivedBy:'Ali Raza',sampleSize:'500g',batchNo:b||'N.A',analysisTime:'1:00PM',temperature:'33',humidity:'40'});r.rows=[{t:'Appearance',s:'Granules',r:'Ok',m:'VISUAL',k:'Ok',x:[]},{t:n.split(' ')[0]+' ('+i+')',s:sp,r:rs,m:'Flame Photometer',k:v=='FIT'?'Ok':'Fail',x:[]}];r.verdict=v;DB.put(r)};
 mk('external','Potash (40%)','Umar Farooq','2026-10-06','K2O','40%','40%(+-5)','39.87%','FIT');mk('batch','Potash (50%)','Plant Store','2026-09-18','K2O','50%','50%(+-5)','43.10%','UNFIT','B-0918');mk('raw','Urea (46%)','Warehouse','2026-08-25','N','46%','46%(+-1)','46.2%','FIT','U-0825');render()};
render();
