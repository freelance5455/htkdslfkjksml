const qid=new URLSearchParams(location.search).get('id');let R=(qid&&DB.get(qid))||blank();
const sty=document.createElement('style');sty.textContent=DOC_CSS.replace(/body\{[^}]*\}/,'').replace(/@page\{[^}]*\}/,'');document.head.appendChild(sty);
document.body.insertAdjacentHTML('beforeend','<datalist id="dl_size"><option>500g<option>1000g<option>250g<option>1kg</datalist><datalist id="dl_state"><option>Granules<option>Powder<option>Liquid<option>Crystals</datalist>');
$('#m_sampleSize').setAttribute('list','dl_size');$('#m_physicalState').setAttribute('list','dl_state');
$$('details.section')[1].insertAdjacentHTML('afterend','<details class="section" open><summary>Extra columns &amp; fields <span class="badge draft" style="margin-left:6px">optional</span></summary><div class="inner"><label class="fld"><span>Extra test-table columns (comma separated)</span><input type="text" id="xc_in" placeholder="e.g. Limit, Unit"></label><label class="fld" style="margin-top:10px"><span>Extra header fields (one per line &mdash; Label: value)</span><textarea id="xf_in" rows="3" placeholder="Lot Size: 25 tons"></textarea></label></div></details>');
function draw(){if(!$('#toggleLive').checked)return;const h=$('#docHolder');h.innerHTML=sheetHTML(R);h.firstChild.style.zoom=Math.min(1,($('#previewScroll').clientWidth-16)/740)}
function drawRows(){const xc=R.xc;$('#testRows').closest('table').querySelector('thead').innerHTML='<tr><th></th><th>Tests</th><th>Specification</th><th>Results</th><th>Methods</th><th>Remarks</th>'+xc.map(c=>`<th>${esc(c)}</th>`).join('')+'<th></th></tr>';
 $('#testRows').innerHTML=R.rows.map((w,i)=>`<tr><td class="handle"><button class="btn small icon" data-a="up" data-i="${i}">\u2191</button><button class="btn small icon" data-a="dn" data-i="${i}">\u2193</button></td>`+['t','s','r','m','k'].map(k=>`<td><input data-i="${i}" data-k="${k}" value="${esc(w[k])}"></td>`).join('')+xc.map((c,j)=>`<td><input data-i="${i}" data-x="${j}" value="${esc((w.x||[])[j])}"></td>`).join('')+`<td><button class="btn small icon danger" data-a="del" data-i="${i}">\u2715</button></td></tr>`).join('')}
function fill(){$$('[id^=m_]').forEach(e=>e.value=R.m[e.id.slice(2)]||'');$$('[id^=s_]').forEach(e=>e.value=R.sig[e.id.slice(2)]||'');$$('[name=reportType]').forEach(e=>e.checked=e.value===R.type);
 $('#r_verdict').value=R.verdict;$('#r_overall').value=R.overall;$('#xc_in').value=R.xc.join(', ');$('#xf_in').value=R.xf||'';$('#docId').textContent=R.no;drawRows();draw()}
$$('[id^=m_]').forEach(e=>e.addEventListener('input',()=>{R.m[e.id.slice(2)]=e.value;draw()}));
$$('[id^=s_]').forEach(e=>e.addEventListener('input',()=>{R.sig[e.id.slice(2)]=e.value;draw()}));
$$('[name=reportType]').forEach(e=>e.onchange=()=>{R.type=e.value;draw()});
$('#r_verdict').onchange=e=>{R.verdict=e.target.value;draw()};
$('#r_overall').oninput=e=>{R.overall=e.target.value;draw()};
$('#btnResetRemarks').onclick=()=>{R.overall=OVERALL.join('\n');$('#r_overall').value=R.overall;draw()};
$('#xc_in').oninput=e=>{R.xc=e.target.value.split(',').map(s=>s.trim()).filter(Boolean);drawRows();draw()};
$('#xf_in').oninput=e=>{R.xf=e.target.value;draw()};
$('#toggleLive').onchange=()=>{$('#docHolder').innerHTML='';draw()};
$('#testRows').addEventListener('input',e=>{const t=e.target,w=R.rows[t.dataset.i];if(!w)return;if(t.dataset.k)w[t.dataset.k]=t.value;else{w.x=w.x||[];w.x[t.dataset.x]=t.value}draw()});
$('#testRows').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const i=+b.dataset.i,a=b.dataset.a,x=R.rows;if(a=='del')x.splice(i,1);else{const j=a=='up'?i-1:i+1;if(j<0||j>=x.length)return;[x[i],x[j]]=[x[j],x[i]]}drawRows();draw()});
$('#btnAddRow').onclick=()=>{R.rows.push({t:'',s:'',r:'',m:'',k:'',x:[]});drawRows();draw()};
const save=()=>{DB.put(R);history.replaceState(0,'','report.html?id='+R.id);toast('Report '+R.no+' saved')};
$('#btnSave').onclick=save;
$('#btnPrint').onclick=()=>{DB.put(R);openPrint([R],true)};
$('#btnPdf').onclick=()=>openPrint([R],false);
$('#btnNew').onclick=()=>{R=blank();history.replaceState(0,'','report.html');fill()};
$('#btnDuplicate').onclick=()=>{const c=JSON.parse(JSON.stringify(R));R=Object.assign(blank(),{m:c.m,xc:c.xc,xf:c.xf,rows:c.rows,type:c.type,verdict:c.verdict,overall:c.overall,sig:c.sig});DB.put(R);history.replaceState(0,'','report.html?id='+R.id);fill();toast('Duplicated as '+R.no)};
$('#btnDelete').onclick=()=>{if(confirm('Delete report '+R.no+'?')){DB.del(R.id);location.href='index.html'}};
addEventListener('resize',draw);fill();
