(()=>{const K='fc_view',L={auto:'Auto',mobile:'Mobile',desktop:'Desktop'},get=()=>localStorage.getItem(K)||'auto',mv=document.querySelector('meta[name=viewport]');
 const apply=()=>{const v=get();document.body.classList.toggle('vm-m',v==='mobile'&&screen.width>=700);document.body.classList.toggle('vm-d',v==='desktop');
  if(mv)mv.content=v==='desktop'?'width=1280':'width=device-width, initial-scale=1, viewport-fit=cover';
  const b=$('#vmBtn');if(b)b.textContent=L[v]+' view';const s=$('#a_view');if(s)s.value=v};
 const set=v=>{localStorage.setItem(K,v);apply();toast('View: '+L[v])};
 $('.sh-top .av').parentNode.insertAdjacentHTML('beforebegin','<button class="vm" id="vmBtn" title="Switch between Auto, Mobile and Desktop view"></button>');
 $('#vmBtn').onclick=()=>set({auto:'mobile',mobile:'desktop',desktop:'auto'}[get()]);
 const t=$('#a_theme');if(t)t.closest('.fld').insertAdjacentHTML('afterend','<label class="fld"><span>Display view</span><select id="a_view"><option value="auto">Auto (fits your screen)</option><option value="mobile">Mobile view</option><option value="desktop">Desktop view</option></select></label>'),$('#a_view').onchange=e=>set(e.target.value);
 addEventListener('resize',apply);apply()})();
