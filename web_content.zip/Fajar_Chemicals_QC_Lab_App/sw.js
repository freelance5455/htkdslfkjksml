const C='fajar-qc-v6',F=['./','index.html','report.html','css/styles.css','css/shell.css','css/polish.css','js/extras.js','js/share.js','js/viewmode.js','js/xml.js','css/theme.css','css/print.css','js/shell.js','js/views.js','js/data.js','js/doc-css.js','js/render.js','js/report.js','js/dashboard.js','img/logo.png','manifest.json'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(F))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))});
