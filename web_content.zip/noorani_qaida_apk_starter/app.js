const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const copy = {
  en: {
    subtitle:"Learn gently, step by step", heroKicker:"LEARN • LISTEN • PRACTICE",
    heroText:"Build your Arabic reading skills one small lesson at a time.", start:"Start learning",
    progressLabel:"YOUR PROGRESS", progressTitle:"Your learning journey", ofLessons:"/ 3 lessons",
    lessonsEyebrow:"LEARNING PATH", lessonsTitle:"Start with the basics", practiceEyebrow:"CHECK YOURSELF",
    practiceTitle:"Practice time", practicePrompt:"Which letter is shown below?", next:"Next question ↻",
    azkarEyebrow:"DAILY REMEMBRANCE", azkarTitle:"Azkar & duas", bathroomTitle:"Entering the bathroom",
    bathroomMeaning:"O Allah, I seek refuge in You from male and female evil beings.",
    leavingTitle:"Leaving the bathroom", leavingMeaning:"I ask You for forgiveness.",
    tashahhudTitle:"Tashahhud", tashahhudMeaning:"A beginning excerpt from the Tashahhud recitation.",
    listenDua:"Listen", religiousNote:"Learning note: the Tashahhud shown here is only an excerpt. Confirm complete prayer texts and teaching with a trusted teacher.",
    prayerEyebrow:"WORSHIP GUIDE", prayerTitle:"How to pray", prayerNote:"This is a brief overview, not a complete fiqh lesson. Details can vary by school; learn the full method from a qualified teacher.",
    navHome:"Home",navLessons:"Lessons",navAzkar:"Azkar",navGuide:"Guide",
    lessonNames:["Arabic letters","Short vowels","Letter practice"],
    lessonDescs:["Meet the Arabic letters and their shapes.","Begin learning the short vowel marks.","Review letters with a guided practice."],
    listen:"🔊 Listen", practice:"Practice", completed:"Completed ✓", correct:"Correct! Well done.", wrong:"Not quite. Try again and listen carefully.", unsupported:"Speech recognition is not available in this browser. You can still complete the quiz.",
    speechPrompt:"Say the shown letter after pressing the microphone button. Feedback is a practice aid, not a perfect pronunciation judgement.",
    speechButton:"🎙 Speak", speechUnavailable:"Microphone speech recognition is not supported here. Try Chrome on a compatible device.",
    completedToast:"Lesson marked complete.", offlineNote:"Offline: saved app files and progress work offline. Speech voices may require a downloaded device voice."
  },
  am: {
    subtitle:"በቀስታ እና በደረጃ ተማር", heroKicker:"ተማር • አዳምጥ • ተለማመድ",
    heroText:"የአረብኛ ንባብን በትንንሽ ትምህርቶች በደረጃ ተማር።", start:"ትምህርት ጀምር",
    progressLabel:"የእርስዎ እድገት", progressTitle:"የትምህርት ጉዞዎ", ofLessons:"/ 3 ትምህርቶች",
    lessonsEyebrow:"የትምህርት መንገድ", lessonsTitle:"ከመሠረቱ ጀምር", practiceEyebrow:"ራስህን ፈትሽ",
    practiceTitle:"የልምምድ ጊዜ", practicePrompt:"ከታች የታየው ፊደል የትኛው ነው?", next:"ቀጣይ ጥያቄ ↻",
    azkarEyebrow:"የዕለት ዚክር", azkarTitle:"ዚክር እና ዱዓ", bathroomTitle:"ወደ መጸዳጃ ሲገቡ",
    bathroomMeaning:"አላህ ሆይ፣ ከወንድና ከሴት ክፉ ፍጥረታት በአንተ እጠበቃለሁ።",
    leavingTitle:"ከመጸዳጃ ሲወጡ", leavingMeaning:"ምሕረትህን እለምናለሁ።",
    tashahhudTitle:"ተሸሁድ", tashahhudMeaning:"ይህ ከተሸሁድ የመጀመሪያ ክፍል ብቻ ነው።",
    listenDua:"አዳምጥ", religiousNote:"ማስታወሻ፦ እዚህ ያለው ተሸሁድ ከፊል ብቻ ነው። ሙሉ ንባቡን ከታመነ አስተማሪ ያረጋግጡ።",
    prayerEyebrow:"የአምልኮ መመሪያ", prayerTitle:"እንዴት መስገድ እንደሚቻል", prayerNote:"ይህ አጭር ማጠቃለያ ነው፤ ሙሉ የፊቅህ ትምህርት አይደለም። ሙሉውን ከብቁ አስተማሪ ይማሩ።",
    navHome:"መነሻ",navLessons:"ትምህርት",navAzkar:"ዚክር",navGuide:"መመሪያ",
    lessonNames:["የአረብኛ ፊደላት","አጭር አናባቢዎች","የፊደል ልምምድ"],
    lessonDescs:["የአረብኛ ፊደላትን እና ቅርጻቸውን ተማር።","የአጭር አናባቢ ምልክቶችን ጀምር።","በመመሪያ ልምምድ ፊደላትን ድገም።"],
    listen:"🔊 አዳምጥ",practice:"ተለማመድ",completed:"ተጠናቋል ✓",correct:"ትክክል! በርታ።",wrong:"ገና አልተሳካም። እንደገና ሞክር።",
    unsupported:"የንግግር መለየት በዚህ አሳሽ አይደገፍም፤ ግን ጥያቄዎቹን መስራት ትችላለህ።",
    speechPrompt:"የሚታየውን ፊደል ከማይክሮፎን በኋላ ተናገር። ግብረመልሱ የልምምድ እገዛ ነው እንጂ ፍጹም የድምፅ ፍርድ አይደለም።",
    speechButton:"🎙 ተናገር",speechUnavailable:"የማይክሮፎን ንግግር በዚህ አይደገፍም። ተስማሚ መሣሪያ ላይ Chrome ይሞክሩ።",
    completedToast:"ትምህርቱ እንደተጠናቀቀ ተመዝግቧል።", offlineNote:"ከመስመር ውጭ፦ የተቀመጡ ፋይሎችና እድገት ይሰራሉ። የድምፅ አማራጭ በመሣሪያው ላይ ሊወርድ ይችላል።"
  },
  ar: {
    subtitle:"تعلّم بهدوء، خطوةً خطوة", heroKicker:"تعلّم • استمع • تدرّب",
    heroText:"طوّر مهارات قراءة العربية درسًا صغيرًا بعد درس.", start:"ابدأ التعلّم",
    progressLabel:"تقدّمك", progressTitle:"رحلتك التعليمية", ofLessons:"/ 3 دروس",
    lessonsEyebrow:"مسار التعلّم", lessonsTitle:"ابدأ بالأساسيات", practiceEyebrow:"اختبر نفسك",
    practiceTitle:"وقت التدريب", practicePrompt:"ما الحرف الظاهر أدناه؟", next:"السؤال التالي ↻",
    azkarEyebrow:"الأذكار اليومية", azkarTitle:"الأذكار والأدعية", bathroomTitle:"دعاء دخول الخلاء",
    bathroomMeaning:"اللهم إني أعوذ بك من الخبث والخبائث.",
    leavingTitle:"دعاء الخروج من الخلاء", leavingMeaning:"أطلب مغفرتك.",
    tashahhudTitle:"التشهد", tashahhudMeaning:"هذا مقتطف من بداية التشهد.",
    listenDua:"استمع", religiousNote:"تنبيه تعليمي: المعروض هنا مقتطف من التشهد فقط. راجع النص الكامل وطريقة الصلاة مع معلّم موثوق.",
    prayerEyebrow:"دليل العبادة", prayerTitle:"كيفية الصلاة", prayerNote:"هذا ملخص موجز وليس درس فقه كاملًا. قد تختلف بعض التفاصيل؛ تعلّم الطريقة الكاملة من معلّم مؤهل.",
    navHome:"الرئيسية",navLessons:"الدروس",navAzkar:"الأذكار",navGuide:"الدليل",
    lessonNames:["الحروف العربية","الحركات القصيرة","تدريب الحروف"],
    lessonDescs:["تعرّف إلى الحروف العربية وأشكالها.","ابدأ بتعلّم علامات الحركات القصيرة.","راجع الحروف من خلال تدريب موجّه."],
    listen:"🔊 استمع",practice:"تدرّب",completed:"اكتمل ✓",correct:"صحيح! أحسنت.",wrong:"ليس تمامًا. حاول مجددًا واستمع جيدًا.",
    unsupported:"التعرّف على الكلام غير متاح في هذا المتصفح، لكن يمكنك إكمال الاختبار.",
    speechPrompt:"انطق الحرف الظاهر بعد الضغط على زر الميكروفون. هذه الميزة للتدريب وليست حكمًا دقيقًا على النطق.",
    speechButton:"🎙 تكلّم",speechUnavailable:"التعرّف على الكلام غير مدعوم هنا. جرّب Chrome على جهاز متوافق.",
    completedToast:"تم تسجيل إكمال الدرس.",offlineNote:"دون إنترنت: تعمل ملفات التطبيق والتقدّم المحفوظ دون اتصال. قد تحتاج الأصوات إلى تنزيلها على الجهاز."
  }
};

const lessons = [
  {id:1, glyph:"ا ب ت ث", titleKey:0, icon:"ا", speech:"ا ب ت ث", note:"ا ب ت ث"},
  {id:2, glyph:"بَ بِ بُ", titleKey:1, icon:"َ", speech:"بَ بِ بُ", note:"بَ بِ بُ"},
  {id:3, glyph:"ب ت ث ن ي", titleKey:2, icon:"ب", speech:"ب ت ث ن ي", note:"ب ت ث ن ي"}
];
const questions = [
  {letter:"ب",options:["ت","ب","ث"],answer:"ب"},
  {letter:"ت",options:["ث","ن","ت"],answer:"ت"},
  {letter:"ث",options:["ب","ث","ت"],answer:"ث"},
  {letter:"ا",options:["ا","ب","ن"],answer:"ا"},
  {letter:"ن",options:["ي","ن","ت"],answer:"ن"}
];
let questionIndex = 0;
let completed = new Set(JSON.parse(localStorage.getItem("nooraniCompleted") || "[]"));
let currentLang = localStorage.getItem("nooraniLanguage") || "en";
const t = (key) => (copy[currentLang] && copy[currentLang][key]) || copy.en[key] || key;

function speak(text, lang = "ar") {
  if (!("speechSynthesis" in window)) { showToast("Text-to-speech is not available on this device."); return; }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = lang === "ar" ? "ar-SA" : lang === "am" ? "am-ET" : "en-US";
  utterance.rate = 0.78;
  const voices = window.speechSynthesis.getVoices();
  const match = voices.find(v => v.lang.toLowerCase().startsWith(lang));
  if (match) utterance.voice = match;
  window.speechSynthesis.speak(utterance);
}
function showToast(message) {
  const toast = $("#toast"); toast.textContent = message; toast.classList.add("show");
  clearTimeout(showToast.timer); showToast.timer = setTimeout(() => toast.classList.remove("show"), 2600);
}
function renderLessons() {
  $("#lessonGrid").innerHTML = lessons.map(lesson => `
    <article class="lesson-card">
      <div class="lesson-top"><div class="lesson-icon">${lesson.icon}</div><span class="lesson-number">LESSON ${lesson.id.toString().padStart(2,"0")}</span></div>
      <h3>${t("lessonNames")[lesson.titleKey]}</h3>
      <p>${t("lessonDescs")[lesson.titleKey]}</p>
      <div class="lesson-arabic" dir="rtl">${lesson.glyph}</div>
      <div class="lesson-actions">
        <button class="secondary" data-lesson-listen="${lesson.id}">${t("listen")}</button>
        <button class="primary" data-complete="${lesson.id}">${completed.has(lesson.id) ? t("completed") : t("practice")}</button>
      </div>
    </article>`).join("");
  $$("[data-lesson-listen]").forEach(button => button.addEventListener("click", () => {
    const lesson = lessons.find(item => item.id === Number(button.dataset.lessonListen)); speak(lesson.speech);
  }));
  $$("[data-complete]").forEach(button => button.addEventListener("click", () => {
    const id = Number(button.dataset.complete);
    completed.add(id); localStorage.setItem("nooraniCompleted", JSON.stringify([...completed]));
    renderLessons(); updateProgress(); showToast(t("completedToast"));
  }));
}
function updateProgress() {
  $("#progressCount").textContent = completed.size;
  $("#progressBar").style.width = `${completed.size / lessons.length * 100}%`;
}
function renderQuestion() {
  const q = questions[questionIndex % questions.length];
  $("#quizLetter").textContent = q.letter;
  $("#quizOptions").innerHTML = q.options.map(option => `<button type="button" data-answer="${option}">${option}</button>`).join("");
  $("#quizFeedback").textContent = "";
  $$("[data-answer]").forEach(button => button.addEventListener("click", () => {
    const right = button.dataset.answer === q.answer;
    $("#quizFeedback").textContent = right ? t("correct") : t("wrong");
    $("#quizFeedback").style.color = right ? "#13745a" : "#a54b3c";
    if (right && "vibrate" in navigator) navigator.vibrate(35);
  }));
}
function applyLanguage() {
  const strings = copy[currentLang] || copy.en;
  document.documentElement.lang = currentLang;
  document.documentElement.dir = currentLang === "ar" ? "rtl" : "ltr";
  $("#language").value = currentLang;
  const ids = ["subtitle","heroKicker","heroText","progressLabel","progressTitle","ofLessons","lessonsEyebrow","lessonsTitle","practiceEyebrow","practiceTitle","practicePrompt","azkarEyebrow","azkarTitle","bathroomTitle","bathroomMeaning","leavingTitle","leavingMeaning","tashahhudTitle","tashahhudMeaning","listenDua","religiousNote","prayerEyebrow","prayerTitle","prayerNote","navHome","navLessons","navAzkar","navGuide"];
  ids.forEach(id => { const el = document.getElementById(id); if (el && strings[id]) el.textContent = strings[id]; });
  $("#startLearning").firstChild.textContent = strings.start + " ";
  $("#nextQuestion").textContent = strings.next || copy.en.next;
  $$(".listenWord").forEach(el => el.textContent = strings.listenDua || "Listen");
  renderLessons(); renderQuestion(); updateProgress(); renderPrayerSteps();
}
function renderPrayerSteps() {
  const data = currentLang === "am" ? [
    ["ኒያ (ዓላማ)","የምትሰግደውን ሶላት በልብህ አስብ።"],
    ["ዝግጅት","ውዱእ አድርግ እና ወደ ቂብላ ቁም።"],
    ["ጀምር","“አላሁ አክበር” በማለት ጀምር።"],
    ["ንባብና መጨረሻ","የተማርከውን ንባብ አንብብ እና ሶላቱን በሰላም ጨርስ።"]
  ] : currentLang === "ar" ? [
    ["النية","اعرف في قلبك الصلاة التي ستؤديها."],["الاستعداد","توضأ واستقبل القبلة."],
    ["البدء","ابدأ بتكبيرة الإحرام: الله أكبر."],["القراءة والختام","اقرأ ما تعلمته وأتمّ الصلاة بالتسليم."]
  ] : [
    ["Make intention","Know which prayer you are about to perform."],["Prepare","Perform wudu and face the Qiblah."],
    ["Begin","Say “Allahu Akbar” and follow the prayer positions you have learned."],["Recite and complete","Recite the required passages and complete the prayer with the ending salams."]
  ];
  $("#prayerSteps").innerHTML = data.map(([title,desc]) => `<li><strong>${title}</strong><span>${desc}</span></li>`).join("");
}
$("#language").addEventListener("change", event => {
  currentLang = event.target.value; localStorage.setItem("nooraniLanguage", currentLang); applyLanguage();
});
$("#startLearning").addEventListener("click", () => $("#lessonsSection").scrollIntoView({behavior:"smooth"}));
$("#listenTitle").addEventListener("click", () => speak("القاعدة النورانية"));
$("#nextQuestion").addEventListener("click", () => { questionIndex++; renderQuestion(); });
$$("[data-speak]").forEach(button => button.addEventListener("click", () => speak(button.dataset.speak)));
$$(".nav-item").forEach(button => button.addEventListener("click", () => {
  $$(".nav-item").forEach(item => item.classList.remove("active")); button.classList.add("active");
  if (button.dataset.target === "top") window.scrollTo({top:0,behavior:"smooth"});
  else document.getElementById(button.dataset.target).scrollIntoView({behavior:"smooth"});
}));

// Speech recognition is optional and browser-dependent. It is not a reliable tajweed/makhraj judge.
function addSpeechPracticeButton() {
  const panel = $(".practice-panel");
  const button = document.createElement("button");
  button.className = "secondary"; button.id = "speechPractice"; button.textContent = t("speechButton");
  button.style.marginTop = "10px";
  panel.appendChild(button);
  button.addEventListener("click", () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { showToast(t("speechUnavailable")); return; }
    const recognition = new SpeechRecognition();
    recognition.lang = "ar-SA"; recognition.interimResults = false; recognition.maxAlternatives = 3;
    showToast(t("speechPrompt"));
    recognition.onresult = event => {
      const heard = event.results[0][0].transcript || "";
      const target = $("#quizLetter").textContent;
      const normalized = heard.replace(/[ًٌٍَُِّْـ\s]/g,"");
      const targetNorm = target.replace(/[ًٌٍَُِّْـ\s]/g,"");
      const likely = normalized.includes(targetNorm) || targetNorm.includes(normalized);
      $("#quizFeedback").textContent = likely ? `${t("correct")} (${heard})` : `${t("wrong")} (${heard})`;
      $("#quizFeedback").style.color = likely ? "#13745a" : "#a54b3c";
    };
    recognition.onerror = () => showToast(t("speechUnavailable"));
    recognition.start();
  });
}
const speechHint = document.createElement("p");
speechHint.className = "note"; speechHint.id = "speechHint"; speechHint.textContent = t("speechPrompt");
$(".practice-panel").appendChild(speechHint);
addSpeechPracticeButton();
applyLanguage();
