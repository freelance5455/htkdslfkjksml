# القاعدة النورانية — Android APK starter

This is a starter project made with HTML, CSS, and JavaScript. It includes:
- Responsive home page inspired by the hand-drawn sketch
- English, Amharic, and Arabic interface labels
- Sample Arabic-letter lessons and a multiple-choice practice quiz
- Browser/device text-to-speech where available
- Optional browser speech recognition where supported
- Sample Azkar cards and a short prayer overview
- Local progress and language preference saved with `localStorage`

## Important limits
- The 3 lesson cards are placeholders/sample lessons, not the complete authorized Noorani Qaida curriculum. Add lessons from pages/audio you have permission to use.
- Speech recognition only gives rough practice feedback; it cannot accurately certify Arabic articulation or Tajweed.
- Device text-to-speech voices vary and may need internet or a downloaded Arabic voice.
- For full offline operation, bundle permitted audio files locally and add a service worker/PWA or package local assets in an Android WebView.
- Verify all religious texts and complete prayer instructions with a trusted qualified teacher before publishing.

## Preview on Windows
1. Extract the ZIP to a folder.
2. Double-click `index.html` to open it in Chrome or Edge.
3. For microphone recognition, browser support and secure-origin restrictions may apply; use Chrome on a compatible device. The APK WebView may require extra native permission/configuration.

## Package as an Android APK (Capacitor route)
This route uses HTML/CSS/JS for the app interface, plus Node.js and Android build tools to package it.
1. Install Node.js LTS from https://nodejs.org/
2. Install Android Studio from https://developer.android.com/studio and complete its Android SDK setup.
3. Open Command Prompt in a NEW project folder and run:
   ```bat
   npm create @capacitor/app@latest
   ```
   Follow prompts. Use an app name such as `Noorani Qaida`, app ID like `com.example.nooranqaida`, and web directory `www`.
4. Copy `index.html`, `style.css`, and `app.js` into the project's `www` folder (replace starter files if needed).
5. In that project folder run:
   ```bat
   npm install
   npm install @capacitor/android
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
6. In Android Studio, wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio shows the APK output location. Install the APK on your own phone for testing.

## Offline-first next steps
- Keep all CSS and JS local (already done).
- Do not rely on Google Fonts for offline appearance; the CSS has fallback fonts. For fully offline fonts, remove the `@import` line or bundle licensed font files locally.
- Place licensed audio under `www/audio/` and reference those files locally.
- Add a service worker if serving as a PWA. A packaged WebView with local files can work offline without a service worker.
- If microphone recognition is essential, configure Android microphone permission and test on-device. Some recognition providers require internet.
