# CryptoPulse — Stage 1163
## Sepolia Network Layer

- Added a native-only Sepolia network boundary.
- Ethereum Sepolia is fixed at Chain ID 11155111 (`0xAA36A7`).
- RPC configuration is intentionally empty by default and contains no API key/secret.
- Only read-only `eth_chainId` / `net_version` are allowed by the boundary.
- No signing, private-key access, transaction broadcast, or mainnet fallback exists.
- WebView receives only sanitized network state; the RPC URL itself is never exposed.
- Live RPC reachability is not claimed when no endpoint is configured or when the environment cannot reach the network.
