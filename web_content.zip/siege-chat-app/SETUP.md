# Siege Chat – Einrichtung (© 2026 Veyron Studio)

## 1. Supabase (einmalig, im Dashboard)
1. Authentication → Sign In / Providers → Email: **"Confirm email" ausschalten**.
2. Dort die **Mindestlänge fürs Passwort auf 8** stellen (Menü kann je nach Version anders heißen).
3. Authentication → Users → Add user: `de1v01@siege.invalid` + dein NEUES Dev-Passwort, "Auto Confirm User" an. Das zuerst machen, bevor die App öffentlich ist.

## 2. Programme (kostenlos)
Node.js (LTS), Android Studio.

## 3. App testen (im Browser, bevor du eine APK baust)
    npm install
    npm run dev
Öffne die Adresse in ZWEI verschiedenen Browser-Profilen (oder normal + privat), registriere je ein Konto, füge die ID des anderen hinzu und schreibt euch.

## 4. APK bauen
    npm run build
    npx cap add android
    npx cap sync
    npx cap open android
In Android Studio: Build → Build Bundle(s)/APK(s) → Build APK(s). Die Test-APK kannst du aufs Handy kopieren und installieren.

## Bekannte Einschränkungen
- Verschlüsselung gilt pro Gerät: Wer sich auf einem neuen Gerät anmeldet, ersetzt seinen Schlüssel. Nachrichten, die für den alten Schlüssel verschlüsselt wurden, sind dort unlesbar (🔒). Ein Konto sollte nur auf einem Gerät gleichzeitig genutzt werden.
- Keine Forward Secrecy (kein Signal-Protokoll). Der Server sieht, wer wann mit wem schreibt.
- Wörter-Limit: Der Server kann Wörter nicht zählen, er rechnet nach angegebenen Wörtern, mindestens nach Paketgröße (Betrüger kommen auf etwa das 4-Fache).
- Nachrichten kommen per Abfrage alle 4 Sekunden, nicht per Echtzeit-Push. Push-Meldungen (Firebase) sind noch nicht eingebaut.
- Nicht gegen einen echten Server im Browser getestet. Bitte Schritt 3 gründlich durchspielen.
