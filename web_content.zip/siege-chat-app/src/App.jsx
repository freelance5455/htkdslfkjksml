/*
 * Siege Chat — © 2026 Veyron Studio. All rights reserved.
 * Siege Chat, the Siege Chat logo and the Veyron Studio name and logo are proprietary to Veyron Studio.
 * Copying, redistributing or modifying this software or its logos without written permission is prohibited.
 */
import React, { useState, useEffect, useRef, useCallback } from "react";
import { createClient } from "@supabase/supabase-js";
import sodium from "libsodium-wrappers";
import {
  Send,
  Paperclip,
  Smile,
  Settings as SettingsIcon,
  User as UserIcon,
  ChevronLeft,
  Check,
  Trash2,
  X,
  Copy,
  UserPlus,
  Shield,
  RefreshCw,
} from "lucide-react";

const ALLOWED_EMOJIS = ["❤️", "😎", "🤝", "🫂", "👍", "😭", "💀", "🙂", "😀", "😏"];
const MAX_USERS = 4000; // Registrierungen auf der ganzen App
const STD_MAX_WORDS = 12000;
const STD_MAX_PHOTOS = 24;
const PHOTO_COOLDOWN_MS = 24 * 60 * 60 * 1000;
const MESSAGE_TTL_MS = 2 * 60 * 60 * 1000;
const SUPPORT_ID = "SUPPORT";
const DEV_ID = "DE1V01"; // reserviert: wird nie vergeben, Login nur mit Dev-Passwort
const ID_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // 32^6 ≈ 1,07 Mrd. mögliche IDs
const DEFAULT_QUOTA = { wordsUsed: 0, photosUsed: 0, photoLimitHitAt: null, lastActionAt: 0 };
const COOLDOWN_POINTS = [
  [0, 0],
  [10, 5],
  [15, 10],
  [20, 20],
  [30, 35],
  [35, 40],
];

const COL = {
  bg: "#0B0F1C",
  panel: "#10162A",
  panel2: "#171E36",
  field: "#0A0E19",
  border: "#232C48",
  fieldBorder: "#303B5E",
  text: "#EEF1F8",
  muted: "#9AA4BF",
  faint: "#667191",
  accent: "#F5630E",
  danger: "#FF5D6C",
  blueTick: "#3FA9E8",
};

// ---------- i18n (DE / EN) ----------
const LANG_CODES = ["en", "de", "fr", "es"];
function detectLang() {
  const l = ((typeof navigator !== "undefined" && navigator.language) || "en").slice(0, 2).toLowerCase();
  return LANG_CODES.includes(l) ? l : "en";
}
let LANG = detectLang();
const I18N = {
  de: {
    users: "NUTZER", lock: "SPERRE", noLimits: "keine Limits", noContacts: "Noch keine Kontakte — ID in den Settings eingeben.",
    settings: "Einstellungen", username: "Benutzername", usernameLabel: "BENUTZERNAME", idHint: "Das ist deine ID. Gib sie nur Leuten, denen du vertraust ;)",
    copied: "Kopiert.", enterId: "ID EINES NUTZERS EINGEBEN", display: "ANZEIGE", darkmode: "Darkmode", darkOnly: "Nur Darkmode verfügbar.",
    delChat: "Chat löschen?", save: "Speichern", whichChat: "Welchen Chat löschen?", cancel: "Abbrechen",
    delChatConfirm: "Diesen Chat löschen? Alle Nachrichten werden dauerhaft gelöscht.", del: "Löschen",
    words: "WÖRTER", photos: "FOTOS", unlimitedPhotos: "unbegrenzte Fotos", noLock: "keine Sperre", blocked: "BLOCKIERT",
    empty: "— keine Übertragungen —", placeholder: "Nachricht senden!", photosBack: "Fotos wieder verfügbar in",
    photoToast: "Foto-Limit erreicht. Bitte warte 24 Stunden ;)", delMsg: "Nachricht löschen?",
    lockedFor: (v) => `Chat gesperrt für ${v}.`, wordLimit: (v) => `Wortlimit erreicht (${v}/${v}).`,
    photoFail: "Foto konnte nicht verarbeitet werden.", syncFail: "Sync fehlgeschlagen — nach unten ziehen.",
    sendFail: "Senden fehlgeschlagen.", delFail: "Löschen fehlgeschlagen.", ownIdErr: "Das ist deine eigene ID.", notFound: "Nutzer nicht gefunden.",
    connected: (v) => `Verbunden mit ${v}.`, connErrTitle: "VERBINDUNGSFEHLER", retry: "Erneut versuchen",
    chooseName: "Benutzername wählen", password: "Passwort", password2: "Passwort wiederholen", register: "Konto erstellen",
    haveAccount: "Schon ein Account? Melde Dich an!", noAccount: "Neu hier? Konto erstellen", loginTitle: "Anmelden", loginBtn: "Anmelden",
    idPlaceholder: "ID (SC-XXXXXX)", pwRules: "8–16 Zeichen, mindestens 3 Ziffern", logout: "Abmelden", language: "SPRACHE",
    nameEmpty: "Benutzername darf nicht leer sein.", pwLen: "Passwort muss 8–16 Zeichen lang sein.", pwDigits: "Passwort braucht mindestens 3 Ziffern.",
    pwMismatch: "Die Passwörter stimmen nicht überein.", full: `Siege Chat ist voll (${MAX_USERS}/${MAX_USERS}).`,
    notConfirmed: "Registrierung konnte nicht bestätigt werden (gleichzeitige Änderung). Bitte nochmal versuchen.",
    profileFail: "Lokales Profil konnte nicht gespeichert werden.", idNotFound: "Diese ID existiert nicht.",
    noPw: "Dieser Account hat noch kein Passwort (alter Account).", wrongPw: "Falsches Passwort.",
    noStorage: "Speicher nicht verfügbar: window.storage existiert hier nicht (App läuft nicht in der Claude-Umgebung?).",
    timeout: "Zeitüberschreitung beim Speicher (6 s). Verbindung prüfen.", storageErr: (v) => `Speicherfehler: ${v}`,
    storageChecking: "Speicher wird geprüft…", storageOk: "Speicher: OK", storageBad: (v) => `Speicher: ${v}`,
  },
  en: {
    users: "USERS", lock: "LOCK", noLimits: "no limits", noContacts: "No contacts yet — enter an ID in settings.",
    settings: "Settings", username: "Username", usernameLabel: "USERNAME", idHint: "This is your ID. Only share it with people you trust ;)",
    copied: "Copied.", enterId: "ENTER USER ID", display: "DISPLAY", darkmode: "Dark mode", darkOnly: "Dark mode only.",
    delChat: "Delete a chat?", save: "Save", whichChat: "Which chat to delete?", cancel: "Cancel",
    delChatConfirm: "Delete this chat? All messages will be permanently deleted.", del: "Delete",
    words: "WORDS", photos: "PHOTOS", unlimitedPhotos: "unlimited photos", noLock: "no lock", blocked: "BLOCKED",
    empty: "— no transmissions —", placeholder: "Send message!", photosBack: "Photos available again in",
    photoToast: "You've reached your photo limit. Please wait 24 hours ;)", delMsg: "Delete message?",
    lockedFor: (v) => `Chat locked for ${v}.`, wordLimit: (v) => `Word limit reached (${v}/${v}).`,
    photoFail: "Couldn't process photo.", syncFail: "Couldn't sync — pull down to try again.",
    sendFail: "Failed to send.", delFail: "Failed to delete.", ownIdErr: "That's your own ID.", notFound: "User not found.",
    connected: (v) => `Connected with ${v}.`, connErrTitle: "CONNECTION ERROR", retry: "Try again",
    chooseName: "Choose a username", password: "Password", password2: "Repeat password", register: "Create account",
    haveAccount: "Already have an account? Log in!", noAccount: "New here? Create account", loginTitle: "Log in", loginBtn: "Log in",
    idPlaceholder: "ID (SC-XXXXXX)", pwRules: "8–16 characters, at least 3 digits", logout: "Log out", language: "LANGUAGE",
    nameEmpty: "Username can't be empty.", pwLen: "Password must be 8–16 characters.", pwDigits: "Password needs at least 3 digits.",
    pwMismatch: "Passwords don't match.", full: `Siege Chat is full (${MAX_USERS}/${MAX_USERS}).`,
    notConfirmed: "Registration could not be confirmed (concurrent change). Please try again.",
    profileFail: "Local profile could not be saved.", idNotFound: "This ID doesn't exist.",
    noPw: "This account has no password yet (old account).", wrongPw: "Wrong password.",
    noStorage: "Storage unavailable: window.storage doesn't exist here (not running in the Claude environment?).",
    timeout: "Storage timed out (6 s). Check your connection.", storageErr: (v) => `Storage error: ${v}`,
    storageChecking: "Checking storage…", storageOk: "Storage: OK", storageBad: (v) => `Storage: ${v}`,
  },
};
Object.assign(I18N.de, {
  splashLoading: "Wird geladen…", splashSlow: "Langsame Verbindung — das dauert etwas länger…", speedFast: "Schnelle Verbindung",
  speedOk: "Normale Verbindung", speedSlow: "Langsame Verbindung", offline: "Du bist offline.", copyright: "© 2026 Veyron Studio. Alle Rechte vorbehalten.",
});
Object.assign(I18N.en, {
  splashLoading: "Loading…", splashSlow: "Slow connection — this is taking a bit longer…", speedFast: "Fast connection",
  speedOk: "Normal connection", speedSlow: "Slow connection", offline: "You are offline.", copyright: "© 2026 Veyron Studio. All rights reserved.",
});
I18N.fr = {
  users: "UTILISATEURS", lock: "VERROU", noLimits: "aucune limite", noContacts: "Aucun contact — saisis un ID dans les réglages.",
  settings: "Réglages", username: "Nom d’utilisateur", usernameLabel: "NOM D’UTILISATEUR", idHint: "Voici ton ID. Ne le partage qu’avec des personnes de confiance ;)",
  copied: "Copié.", enterId: "SAISIR L’ID D’UN UTILISATEUR", display: "AFFICHAGE", darkmode: "Mode sombre", darkOnly: "Mode sombre uniquement.",
  delChat: "Supprimer un chat ?", save: "Enregistrer", whichChat: "Quel chat supprimer ?", cancel: "Annuler",
  delChatConfirm: "Supprimer ce chat ? Tous les messages seront définitivement supprimés.", del: "Supprimer",
  words: "MOTS", photos: "PHOTOS", unlimitedPhotos: "photos illimitées", noLock: "aucun verrou", blocked: "BLOQUÉ",
  empty: "— aucune transmission —", placeholder: "Envoyer un message !", photosBack: "Photos de nouveau disponibles dans",
  photoToast: "Limite de photos atteinte. Patiente 24 heures ;)", delMsg: "Supprimer le message ?",
  lockedFor: (v) => `Chat verrouillé pendant ${v}.`, wordLimit: (v) => `Limite de mots atteinte (${v}/${v}).`,
  photoFail: "Impossible de traiter la photo.", syncFail: "Synchronisation impossible — tire vers le bas pour réessayer.",
  sendFail: "Échec de l’envoi.", delFail: "Échec de la suppression.", ownIdErr: "C’est ton propre ID.", notFound: "Utilisateur introuvable.",
  connected: (v) => `Connecté avec ${v}.`, connErrTitle: "ERREUR DE CONNEXION", retry: "Réessayer",
  chooseName: "Choisis un nom d’utilisateur", password: "Mot de passe", password2: "Répéter le mot de passe", register: "Créer un compte",
  haveAccount: "Déjà un compte ? Connecte-toi !", noAccount: "Nouveau ? Créer un compte", loginTitle: "Connexion", loginBtn: "Se connecter",
  idPlaceholder: "ID (SC-XXXXXX)", pwRules: "8–16 caractères, au moins 3 chiffres", logout: "Se déconnecter", language: "LANGUE",
  nameEmpty: "Le nom d’utilisateur ne peut pas être vide.", pwLen: "Le mot de passe doit contenir 8 à 16 caractères.",
  pwDigits: "Le mot de passe doit contenir au moins 3 chiffres.", pwMismatch: "Les mots de passe ne correspondent pas.",
  full: `Siege Chat est complet (${MAX_USERS}/${MAX_USERS}).`,
  notConfirmed: "L’inscription n’a pas pu être confirmée (modification simultanée). Réessaie.",
  profileFail: "Le profil local n’a pas pu être enregistré.", idNotFound: "Cet ID n’existe pas.",
  noPw: "Ce compte n’a pas encore de mot de passe (ancien compte).", wrongPw: "Mot de passe incorrect.",
  noStorage: "Stockage indisponible : window.storage n’existe pas ici (l’app ne tourne pas dans l’environnement Claude ?).",
  timeout: "Délai de stockage dépassé (6 s). Vérifie ta connexion.", storageErr: (v) => `Erreur de stockage : ${v}`,
  storageChecking: "Vérification du stockage…", storageOk: "Stockage : OK", storageBad: (v) => `Stockage : ${v}`,
  splashLoading: "Chargement…", splashSlow: "Connexion lente — cela prend un peu plus de temps…", speedFast: "Connexion rapide",
  speedOk: "Connexion normale", speedSlow: "Connexion lente", offline: "Tu es hors ligne.", copyright: "© 2026 Veyron Studio. Tous droits réservés.",
};
I18N.es = {
  users: "USUARIOS", lock: "BLOQUEO", noLimits: "sin límites", noContacts: "Aún no hay contactos — introduce un ID en los ajustes.",
  settings: "Ajustes", username: "Nombre de usuario", usernameLabel: "NOMBRE DE USUARIO", idHint: "Este es tu ID. Compártelo solo con gente de confianza ;)",
  copied: "Copiado.", enterId: "INTRODUCE EL ID DE UN USUARIO", display: "PANTALLA", darkmode: "Modo oscuro", darkOnly: "Solo modo oscuro.",
  delChat: "¿Eliminar un chat?", save: "Guardar", whichChat: "¿Qué chat eliminar?", cancel: "Cancelar",
  delChatConfirm: "¿Eliminar este chat? Todos los mensajes se borrarán de forma permanente.", del: "Eliminar",
  words: "PALABRAS", photos: "FOTOS", unlimitedPhotos: "fotos ilimitadas", noLock: "sin bloqueo", blocked: "BLOQUEADO",
  empty: "— sin transmisiones —", placeholder: "¡Enviar mensaje!", photosBack: "Fotos disponibles de nuevo en",
  photoToast: "Has alcanzado el límite de fotos. Espera 24 horas ;)", delMsg: "¿Eliminar mensaje?",
  lockedFor: (v) => `Chat bloqueado durante ${v}.`, wordLimit: (v) => `Límite de palabras alcanzado (${v}/${v}).`,
  photoFail: "No se pudo procesar la foto.", syncFail: "No se pudo sincronizar — desliza hacia abajo para reintentar.",
  sendFail: "Error al enviar.", delFail: "Error al eliminar.", ownIdErr: "Ese es tu propio ID.", notFound: "Usuario no encontrado.",
  connected: (v) => `Conectado con ${v}.`, connErrTitle: "ERROR DE CONEXIÓN", retry: "Reintentar",
  chooseName: "Elige un nombre de usuario", password: "Contraseña", password2: "Repetir contraseña", register: "Crear cuenta",
  haveAccount: "¿Ya tienes cuenta? ¡Inicia sesión!", noAccount: "¿Eres nuevo? Crear cuenta", loginTitle: "Iniciar sesión", loginBtn: "Iniciar sesión",
  idPlaceholder: "ID (SC-XXXXXX)", pwRules: "8–16 caracteres, al menos 3 dígitos", logout: "Cerrar sesión", language: "IDIOMA",
  nameEmpty: "El nombre de usuario no puede estar vacío.", pwLen: "La contraseña debe tener entre 8 y 16 caracteres.",
  pwDigits: "La contraseña necesita al menos 3 dígitos.", pwMismatch: "Las contraseñas no coinciden.",
  full: `Siege Chat está lleno (${MAX_USERS}/${MAX_USERS}).`,
  notConfirmed: "No se pudo confirmar el registro (cambio simultáneo). Inténtalo de nuevo.",
  profileFail: "No se pudo guardar el perfil local.", idNotFound: "Este ID no existe.",
  noPw: "Esta cuenta aún no tiene contraseña (cuenta antigua).", wrongPw: "Contraseña incorrecta.",
  noStorage: "Almacenamiento no disponible: window.storage no existe aquí (¿la app no se ejecuta en el entorno de Claude?).",
  timeout: "Tiempo de espera del almacenamiento agotado (6 s). Revisa tu conexión.", storageErr: (v) => `Error de almacenamiento: ${v}`,
  storageChecking: "Comprobando almacenamiento…", storageOk: "Almacenamiento: OK", storageBad: (v) => `Almacenamiento: ${v}`,
  splashLoading: "Cargando…", splashSlow: "Conexión lenta — esto tardará un poco más…", speedFast: "Conexión rápida",
  speedOk: "Conexión normal", speedSlow: "Conexión lenta", offline: "Estás sin conexión.", copyright: "© 2026 Veyron Studio. Todos los derechos reservados.",
};
const I18N_EXTRA = {
  de: { yourId: "Deine ID", support: "Support", supportInbox: "Support-Anfragen", supportNoLimits: "SUPPORT · keine Limits", supportEmpty: "Keine Anfragen.", confirmOff: "Registrierung nicht möglich: In Supabase muss „Confirm email“ ausgeschaltet sein." },
  en: { yourId: "Your ID", support: "Support", supportInbox: "Support requests", supportNoLimits: "SUPPORT · no limits", supportEmpty: "No requests.", confirmOff: "Sign-up not possible: \"Confirm email\" must be turned off in Supabase." },
  fr: { yourId: "Ton ID", support: "Support", supportInbox: "Demandes de support", supportNoLimits: "SUPPORT · sans limites", supportEmpty: "Aucune demande.", confirmOff: "Inscription impossible : « Confirm email » doit être désactivé dans Supabase." },
  es: { yourId: "Tu ID", support: "Soporte", supportInbox: "Solicitudes de soporte", supportNoLimits: "SOPORTE · sin límites", supportEmpty: "Sin solicitudes.", confirmOff: "Registro imposible: «Confirm email» debe estar desactivado en Supabase." },
};
function t(key, v) {
  const x = (I18N[LANG] && I18N[LANG][key]) ?? (I18N_EXTRA[LANG] && I18N_EXTRA[LANG][key]) ?? I18N.en[key] ?? I18N_EXTRA.en[key] ?? I18N.de[key] ?? key;
  return typeof x === "function" ? x(v) : x;
}
// Ladegeschwindigkeit einordnen (ms → Kategorie)
function loadQuality(ms) {
  return ms < 1500 ? "speedFast" : ms < 4000 ? "speedOk" : "speedSlow";
}
const LOCALES = { de: "de-DE", en: "en-GB", fr: "fr-FR", es: "es-ES" };

function getCooldownMinutes(userCount) {
  if (userCount <= 0) return 0;
  if (userCount >= MAX_USERS) return 40;
  for (let i = 0; i < COOLDOWN_POINTS.length - 1; i++) {
    const [x1, y1] = COOLDOWN_POINTS[i];
    const [x2, y2] = COOLDOWN_POINTS[i + 1];
    if (userCount >= x1 && userCount <= x2) {
      const t = (userCount - x1) / (x2 - x1);
      return y1 + t * (y2 - y1);
    }
  }
  return 40;
}

// Kosten in Wörtern; jedes erlaubte Emoji zählt nur 0,5
function messageCost(text) {
  let emojiCount = 0;
  let rest = text;
  for (const e of ALLOWED_EMOJIS) {
    const parts = rest.split(e);
    emojiCount += parts.length - 1;
    rest = parts.join(" ");
  }
  const words = rest.split(/\s+/).filter(Boolean).length;
  return words + 0.5 * emojiCount;
}

function fmtClock(ts) {
  return new Date(ts).toLocaleTimeString(LOCALES[LANG] || "en-GB", { hour: "2-digit", minute: "2-digit" });
}

function fmtCountdown(ms) {
  const totalSec = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function generateId() {
  let out = "SC-";
  for (let i = 0; i < 6; i++) out += ID_CHARS[Math.floor(Math.random() * ID_CHARS.length)];
  return out;
}

function chatKeyFor(a, b) {
  return [a, b].sort().join("__");
}
// Support-Chats: ein Thread pro Nutzer, der Dev sieht alle
function threadKey(me, chat) {
  if (chat.isSupport) return `SUPPORT__${me.id === DEV_ID ? chat.id : me.id}`;
  return chatKeyFor(me.id, chat.id);
}

async function compressImage(file, maxW = 480, quality = 0.6) {
  const dataUrl = await new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
  const img = await new Promise((res, rej) => {
    const i = new window.Image();
    i.onload = () => res(i);
    i.onerror = rej;
    i.src = dataUrl;
  });
  const scale = Math.min(1, maxW / img.width);
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  canvas.getContext("2d").drawImage(img, 0, 0, w, h);
  return canvas.toDataURL("image/jpeg", quality);
}

// ---------- backend: Supabase + Ende-zu-Ende-Verschlüsselung ----------
const SUPABASE_URL = "https://ikiagzukoixojkiydmfe.supabase.co";
const SUPABASE_KEY = "sb_publishable_U66nTphUHDSvygJ86JzcJQ_MfopG_c7"; // öffentlicher Schlüssel, darf im Client stehen
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

function withTimeout(promise, ms = 8000) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error("Request timed out")), ms)),
  ]);
}
class ServerError extends Error {}
function describeError(e) {
  if (e && e.key) return t(e.key);
  const msg = (e && (e.message || e.error_description)) || String(e);
  if (msg.includes("timed out")) return t("timeout");
  if (msg === "not_found") return t("notFound");
  if (msg === "own_id") return t("ownIdErr");
  if (msg === "invalid_username") return t("nameEmpty");
  return t("storageErr", msg);
}
async function db(builder) {
  const { data, error } = await withTimeout(builder);
  if (error) throw new ServerError(error.message);
  return data;
}
async function rpc(name, args) {
  return db(supabase.rpc(name, args));
}
function lsGet(k) {
  try {
    return localStorage.getItem(k);
  } catch (e) {
    return null;
  }
}
function lsSet(k, v) {
  try {
    localStorage.setItem(k, v);
  } catch (e) {
    // ignorieren
  }
}
// Echter Verbindungstest gegen den Server (statt nur "sieht gut aus")
async function runStorageCheck() {
  try {
    await rpc("registered_count");
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: describeError(e) };
  }
}
async function registeredCount() {
  return Number(await rpc("registered_count"));
}

// --- Verschlüsselung (libsodium crypto_box: X25519 + XSalsa20-Poly1305). Privater Schlüssel bleibt auf dem Gerät.
let sodiumReady = null;
function ensureSodium() {
  if (!sodiumReady) sodiumReady = sodium.ready.then(() => sodium);
  return sodiumReady;
}
const toB64 = (u8) => sodium.to_base64(u8, sodium.base64_variants.ORIGINAL);
const fromB64 = (s) => sodium.from_base64(s, sodium.base64_variants.ORIGINAL);
let MYKEYS = null;
const PK_CACHE = new Map();
async function activateKeys(me) {
  await ensureSodium();
  const stored = lsGet(`siege:sk:${me.id}`);
  let privateKey;
  if (stored) privateKey = fromB64(stored);
  else {
    privateKey = sodium.crypto_box_keypair().privateKey;
    lsSet(`siege:sk:${me.id}`, toB64(privateKey));
  }
  const publicKey = sodium.crypto_scalarmult_base(privateKey);
  await rpc("set_public_key", { p_key: toB64(publicKey) });
  MYKEYS = { id: me.id, privateKey };
}
async function publicKeyOf(id) {
  const hit = PK_CACHE.get(id);
  if (hit && Date.now() - hit.at < 60000) return hit.key;
  let b64;
  if (id === "SUPPORT") b64 = await rpc("get_support_public_key");
  else {
    const rows = await db(supabase.from("profiles").select("public_key").eq("id", id));
    b64 = rows && rows[0] && rows[0].public_key;
  }
  if (!b64) throw new ServerError("no_public_key");
  const key = fromB64(b64);
  PK_CACHE.set(id, { key, at: Date.now() });
  return key;
}
async function encryptFor(otherId, plaintext) {
  await ensureSodium();
  const pk = await publicKeyOf(otherId);
  const nonce = sodium.randombytes_buf(sodium.crypto_box_NONCEBYTES);
  const cipher = sodium.crypto_box_easy(plaintext, nonce, pk, MYKEYS.privateKey);
  return { cipher: toB64(cipher), nonce: toB64(nonce) };
}
async function decryptFrom(otherId, cipherB64, nonceB64) {
  try {
    await ensureSodium();
    const pk = await publicKeyOf(otherId);
    return sodium.to_string(sodium.crypto_box_open_easy(fromB64(cipherB64), fromB64(nonceB64), pk, MYKEYS.privateKey));
  } catch (e) {
    return null; // z. B. Nachricht an einen alten Schlüssel (anderes Gerät)
  }
}
function peerId(row, me) {
  if (row.is_support) return me.id === DEV_ID ? row.support_user : "SUPPORT";
  return row.sender_id === me.id ? row.recipient_id : row.sender_id;
}
async function mapMessage(row, me) {
  const text = await decryptFrom(peerId(row, me), row.ciphertext, row.nonce);
  const fromMe = row.sender_id === me.id || (row.sender_id === "SUPPORT" && me.id === DEV_ID);
  const ok = text !== null;
  return {
    id: row.id,
    user: fromMe ? me.id : row.sender_id,
    type: ok && row.kind === "photo" ? "photo" : "text",
    text: ok ? text : "🔒",
    ts: Date.parse(row.created_at),
    seen: !!row.seen_at,
  };
}
async function loadChat(key, me) {
  const rows = await db(supabase.from("messages").select("*").eq("thread_key", key).order("created_at", { ascending: true }).limit(300));
  const messages = [];
  for (const r of rows || []) messages.push(await mapMessage(r, me));
  const qrows = await db(supabase.from("chat_quota").select("*").eq("thread_key", key).eq("user_id", me.id));
  const q = qrows && qrows[0];
  const quotas = {
    [me.id]: q
      ? {
          wordsUsed: Number(q.words_used),
          photosUsed: q.photos_used,
          photoLimitHitAt: q.photo_limit_hit_at ? Date.parse(q.photo_limit_hit_at) : null,
          lastActionAt: q.last_action_at ? Date.parse(q.last_action_at) : 0,
        }
      : { ...DEFAULT_QUOTA },
  };
  return { messages, quotas };
}
// Limits (Wörter, Fotos, Sperre) prüft der Server in send_message()
async function sendMessage(me, chat, kind, text, words) {
  const support = !!chat.isSupport;
  const dev = me.id === DEV_ID;
  const other = support ? (dev ? chat.id : "SUPPORT") : chat.id;
  const { cipher, nonce } = await encryptFor(other, text);
  return rpc("send_message", { p_recipient: support ? (dev ? chat.id : "") : chat.id, p_support: support, p_kind: kind, p_cipher: cipher, p_nonce: nonce, p_words: words });
}
async function namesFor(ids) {
  if (!ids.length) return {};
  const rows = await db(supabase.from("profiles").select("id, username").in("id", ids));
  return Object.fromEntries((rows || []).map((r) => [r.id, r.username]));
}
async function loadContactList() {
  const rows = await db(supabase.from("contacts").select("contact_id"));
  const ids = (rows || []).map((r) => r.contact_id);
  const names = await namesFor(ids);
  return ids.map((id) => ({ id, name: names[id] || "?" }));
}
async function loadSupportInbox() {
  const rows = await db(supabase.from("messages").select("support_user").eq("is_support", true).limit(1000));
  const ids = [...new Set((rows || []).map((r) => r.support_user).filter(Boolean))];
  const names = await namesFor(ids);
  return ids.map((id) => ({ id, name: names[id] || "?" }));
}

// ---------- auth ----------
const PW_MIN = 8;
const PW_MAX = 16;
const PW_MIN_DIGITS = 3;
class AuthError extends Error {
  constructor(key) {
    super(key);
    this.key = key;
  }
}
function validatePassword(pw) {
  if (pw.length < PW_MIN || pw.length > PW_MAX) return "pwLen";
  if ((pw.match(/\d/g) || []).length < PW_MIN_DIGITS) return "pwDigits";
  return null;
}
const emailFor = (id) => `${id.toLowerCase()}@siege.invalid`;
async function profileOfSession() {
  const { data } = await withTimeout(supabase.auth.getSession());
  const uid = data && data.session && data.session.user.id;
  if (!uid) return null;
  const rows = await db(supabase.from("profiles").select("id, username").eq("user_id", uid));
  return rows && rows[0] ? { id: rows[0].id, name: rows[0].username } : null;
}
async function loadMe() {
  const me = await profileOfSession();
  if (me) await activateKeys(me);
  return me;
}
async function registerAccount(name, pw, pw2) {
  const trimmed = name.trim();
  if (!trimmed) throw new AuthError("nameEmpty");
  const bad = validatePassword(pw);
  if (bad) throw new AuthError(bad);
  if (pw !== pw2) throw new AuthError("pwMismatch");
  let last = null;
  for (let attempt = 0; attempt < 5; attempt++) {
    const id = generateId();
    const { data, error } = await withTimeout(supabase.auth.signUp({ email: emailFor(id), password: pw, options: { data: { username: trimmed } } }));
    if (error) {
      last = error;
      if (/already|registered|exists/i.test(error.message)) continue; // ID zufällig vergeben -> neue ID
      if ((await registeredCount().catch(() => 0)) >= MAX_USERS) throw new AuthError("full");
      throw error;
    }
    if (!data.session) throw new AuthError("confirmOff");
    const prof = await profileOfSession();
    if (!prof || prof.id !== id) throw new AuthError("notConfirmed"); // echte Prüfung: Profil muss serverseitig existieren
    await activateKeys(prof);
    return { me: prof, directorySize: await registeredCount() };
  }
  throw last || new AuthError("notConfirmed");
}
async function loginAccount(idRaw, pw) {
  const id = idRaw.trim().toUpperCase();
  if (!id) throw new AuthError("idNotFound");
  const { error } = await withTimeout(supabase.auth.signInWithPassword({ email: emailFor(id), password: pw }));
  if (error) {
    if (/invalid login/i.test(error.message)) throw new AuthError("wrongPw");
    throw error;
  }
  const me = await profileOfSession();
  if (!me) throw new AuthError("profileFail");
  await activateKeys(me);
  return { me, directorySize: await registeredCount() };
}
async function logoutAccount() {
  await withTimeout(supabase.auth.signOut());
  MYKEYS = null;
}
// ---------- /auth ----------

function Logo({ size = 36 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" aria-label="Siege Chat" draggable="false" onContextMenu={(e) => e.preventDefault()} style={{ flexShrink: 0, userSelect: "none", WebkitUserDrag: "none" }}>
      <desc>© Veyron Studio</desc>
      <rect x="0.5" y="0.5" width="99" height="99" rx="22" fill="#101626" stroke="#232C48" />
      <rect x="25.3" y="18.9" width="26.6" height="20.8" rx="3.4" fill="#F5630E" />
      <rect x="51.6" y="39.6" width="26.6" height="20.8" rx="3.4" fill="#F5630E" />
      <rect x="25.3" y="60.3" width="26.6" height="20.8" rx="3.4" fill="#F5630E" />
    </svg>
  );
}

function FontImport() {
  return (
    <style>{`@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Space+Grotesk:wght@400;500;700&display=swap');
    @keyframes slideUp { from { transform: translateY(120%); } to { transform: translateY(0); } }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes popIn { from { opacity: 0; transform: scale(.94) translateY(6px); } to { opacity: 1; transform: scale(1) translateY(0); } }
    .toast-slide { animation: slideUp 0.3s cubic-bezier(.2,.8,.2,1); }
    .screen-in { animation: fadeIn 0.35s cubic-bezier(.2,.8,.2,1); }
    .msg-in { animation: popIn 0.25s cubic-bezier(.2,.8,.2,1); }
    button { transition: transform .15s ease, opacity .2s ease, filter .2s ease, background-color .2s ease; }
    button:hover:not(:disabled) { filter: brightness(1.08); }
    button:active:not(:disabled) { transform: scale(.97); }
    input { transition: border-color .2s ease, box-shadow .2s ease; }
    input:focus { border-color: ${COL.accent} !important; box-shadow: 0 0 0 3px rgba(245,99,14,.18); }
    @keyframes spUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes spDraw { to { stroke-dashoffset: 0; } }
    @keyframes spLine { from { transform: scaleX(0); } to { transform: scaleX(1); } }
    @keyframes spBar { 0% { transform: translateX(-100%); } 100% { transform: translateX(250%); } }
    @keyframes menuPop { from { opacity: 0; transform: translateY(-6px) scale(.97); } to { opacity: 1; transform: none; } }
    .sp-item { opacity: 0; animation: spUp .8s cubic-bezier(.2,.8,.2,1) forwards; }
    .sp-hex { stroke-dasharray: 1; stroke-dashoffset: 1; animation: spDraw 1.2s cubic-bezier(.4,0,.2,1) .2s forwards; }
    .sp-line { transform: scaleX(0); animation: spLine .9s cubic-bezier(.4,0,.2,1) forwards; }
    .sp-bar { animation: spBar 1.4s ease-in-out infinite; }
    .menu-pop { animation: menuPop .18s ease-out; }
    @media (prefers-reduced-motion: reduce) {
      .sp-item, .sp-hex, .sp-line, .sp-bar, .screen-in, .msg-in, .menu-pop, .toast-slide { animation: none !important; opacity: 1 !important; transform: none !important; stroke-dashoffset: 0 !important; }
    }
    * { scrollbar-width: thin; scrollbar-color: ${COL.border} transparent; }`}</style>
  );
}

const LANGS = [["en", "English"], ["de", "Deutsch"], ["fr", "Français"], ["es", "Español"]];

// Zahnrad im kleinen Viereck = Spracheinstellungen (+ kurzer Hinweis)
function LangPicker({ lang, setLang, hint, onHintDone }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        onClick={() => { setOpen((o) => !o); if (onHintDone) onHintDone(); }}
        aria-label={t("language")}
        className="flex items-center justify-center rounded-lg"
        style={{ width: 34, height: 34, background: COL.panel2, border: `1px solid ${COL.border}`, color: COL.accent }}
      >
        <SettingsIcon size={18} />
      </button>
      {hint && !open && (
        <div onClick={onHintDone} className="menu-pop absolute right-0 z-40" style={{ top: "calc(100% + 12px)", width: 210 }}>
          <div style={{ position: "absolute", top: -5, right: 12, width: 10, height: 10, background: COL.accent, transform: "rotate(45deg)", borderRadius: 2 }} />
          <div className="relative rounded-xl px-3 py-2 text-xs" style={{ background: COL.accent, color: COL.bg, fontWeight: 600, lineHeight: 1.35 }}>
            Struggling to Understand?<br />Change to your Language.
          </div>
        </div>
      )}
      {open && (
        <>
          <div className="fixed inset-0" style={{ zIndex: 40 }} onClick={() => setOpen(false)} />
          <div className="menu-pop absolute right-0 rounded-xl overflow-hidden" style={{ zIndex: 50, top: "calc(100% + 8px)", minWidth: 180, background: COL.panel, border: `1px solid ${COL.border}`, boxShadow: "0 12px 32px rgba(0,0,0,.45)" }}>
            <div className="px-4 pt-3 pb-1 text-xs" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{t("language")}</div>
            {LANGS.map(([code, label]) => (
              <button key={code} onClick={() => { setLang(code); setOpen(false); }} className="w-full flex items-center justify-between px-4 py-3 text-sm text-left" style={{ color: lang === code ? COL.accent : COL.text }}>
                <span>{label}</span>
                {lang === code && <Check size={16} />}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

const fieldStyle = { background: COL.field, border: `1px solid ${COL.fieldBorder}`, color: COL.text, fontFamily: "'JetBrains Mono', monospace" };

function AuthShell({ lang, setLang, hint, onHintDone, title, children, bottomText, onBottom }) {
  return (
    <div className="screen-in min-h-screen w-full flex flex-col" style={{ background: `radial-gradient(120% 60% at 50% 0%, #161E3A 0%, ${COL.bg} 60%)`, fontFamily: "'Space Grotesk', sans-serif" }}>
      <FontImport />
      <div className="flex items-center justify-between px-6 pt-6">
        <div className="flex items-center gap-3">
          <Logo size={40} />
          <span className="text-xs tracking-widest" style={{ color: COL.muted, fontFamily: "'JetBrains Mono', monospace" }}>SIEGE CHAT 1.0.0</span>
        </div>
        <LangPicker lang={lang} setLang={setLang} hint={hint} onHintDone={onHintDone} />
      </div>
      <div className="flex-1 flex items-center justify-center px-6">
        <div className="w-full max-w-sm">
          <h1 className="text-3xl mb-6" style={{ color: COL.text, fontWeight: 700 }}>{title}</h1>
          {children}
        </div>
      </div>
      <div className="text-center text-xs pb-3" style={{ color: COL.faint }}>{t("copyright")}</div>
      <button onClick={onBottom} className="w-full py-4 text-sm" style={{ background: COL.panel, color: COL.accent, borderTop: `1px solid ${COL.border}`, fontWeight: 500 }}>
        {bottomText}
      </button>
    </div>
  );
}

function usePullToRefresh(scrollRef, onRefresh) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startY = useRef(null);
  const dragging = useRef(false);

  const getY = (e) => (e.touches && e.touches[0] ? e.touches[0].clientY : e.clientY);

  const start = (e) => {
    if (refreshing) return;
    if (scrollRef.current && scrollRef.current.scrollTop <= 0) {
      startY.current = getY(e);
      dragging.current = true;
    }
  };
  const move = (e) => {
    if (!dragging.current || startY.current === null) return;
    const dy = getY(e) - startY.current;
    if (dy > 0) {
      setPull(Math.min(dy * 0.5, 70));
    } else {
      dragging.current = false;
      startY.current = null;
      setPull(0);
    }
  };
  const end = async () => {
    const trigger = dragging.current && pull > 45;
    dragging.current = false;
    startY.current = null;
    setPull(0);
    if (trigger) {
      setRefreshing(true);
      try {
        await onRefresh();
      } finally {
        setRefreshing(false);
      }
    }
  };

  return {
    pull,
    refreshing,
    handlers: {
      onTouchStart: start,
      onTouchMove: move,
      onTouchEnd: end,
      onMouseDown: start,
      onMouseMove: (e) => dragging.current && move(e),
      onMouseUp: end,
      onMouseLeave: () => dragging.current && end(),
    },
  };
}

function PullIndicator({ pull, refreshing }) {
  return (
    <div
      style={{
        height: refreshing ? 32 : pull,
        overflow: "hidden",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        transition: pull === 0 && !refreshing ? "height 0.2s ease" : "none",
      }}
    >
      {(pull > 8 || refreshing) && (
        <RefreshCw size={16} style={{ color: COL.accent }} className={refreshing ? "animate-spin" : ""} />
      )}
    </div>
  );
}

function SiegeChatApp({ onBoot, hint, onHintDone }) {
  const [phase, setPhase] = useState("loading");
  const [me, setMe] = useState(null);
  const [nameDraft, setNameDraft] = useState("");
  const [nameError, setNameError] = useState("");
  const [directorySize, setDirectorySize] = useState(0);
  const [contacts, setContacts] = useState([]); // [{id,name}]
  const [activeChat, setActiveChat] = useState(null); // {id,name,isOwner}
  const [chatData, setChatData] = useState({ messages: [], quotas: {} });
  const [pending, setPending] = useState([]);
  const [input, setInput] = useState("");
  const [showEmoji, setShowEmoji] = useState(false);
  const [sendError, setSendError] = useState("");
  const [photoToast, setPhotoToast] = useState(false);
  const [now, setNow] = useState(Date.now());
  const [confirmDeleteMsg, setConfirmDeleteMsg] = useState(null);
  const [deleteChatId, setDeleteChatId] = useState(null);
  const [pickingChatToDelete, setPickingChatToDelete] = useState(false);
  const [addIdDraft, setAddIdDraft] = useState("");
  const [addIdMsg, setAddIdMsg] = useState("");
  const [copyFlash, setCopyFlash] = useState(false);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [listSyncError, setListSyncError] = useState("");
  const [threadSyncError, setThreadSyncError] = useState("");
  const [initError, setInitError] = useState("");
  const [initTick, setInitTick] = useState(0);
  const [storageStatus, setStorageStatus] = useState(null); // {ok, reason} | null
  const [lang, setLang] = useState(() => LANG);
  const [pwDraft, setPwDraft] = useState("");
  const [pw2Draft, setPw2Draft] = useState("");
  const [loginId, setLoginId] = useState("");
  LANG = lang;
  useEffect(() => {
    if (onBoot) onBoot({ phase, error: initError, lang });
  }, [phase, initError, lang, onBoot]);
  const changeLang = (l) => {
    setLang(l);
    lsSet("msngr:lang", l);
  };

  const fileInputRef = useRef(null);
  const scrollRef = useRef(null);
  const chatListScrollRef = useRef(null);
  const pollRef = useRef(null);
  const tickRef = useRef(null);
  const pressTimer = useRef(null);
  const listFetchBusy = useRef(false);
  const threadFetchBusy = useRef(false);
  const sendingRef = useRef(false);

  const isOwner = activeChat?.isSupport; // Support: keine Limits
  const isDev = me?.id === DEV_ID;
  const [supportList, setSupportList] = useState([]);
  const [supportErr, setSupportErr] = useState("");
  const leaveThread = () => setPhase(activeChat?.isSupport ? (isDev ? "supportInbox" : "settings") : "chatlist");
  const openSupport = () => (isDev ? setPhase("supportInbox") : openChat(SUPPORT_ID, t("support"), true));
  const refreshSupportInbox = useCallback(async () => {
    try {
      setSupportList(await loadSupportInbox());
      setSupportErr("");
    } catch (e) {
      setSupportErr(describeError(e));
    }
  }, []);
  useEffect(() => {
    if (phase !== "supportInbox") return;
    refreshSupportInbox();
    const iv = setInterval(refreshSupportInbox, 6000);
    return () => clearInterval(iv);
  }, [phase, refreshSupportInbox]);
  const maxWords = isOwner ? Infinity : STD_MAX_WORDS;
  const maxPhotos = isOwner ? Infinity : STD_MAX_PHOTOS;
  const cooldownMin = isOwner ? 0 : getCooldownMinutes(directorySize);
  const cooldownMs = cooldownMin * 60 * 1000;
  const myQuota = (me && chatData.quotas[me.id]) || DEFAULT_QUOTA;
  const remainingCooldown = activeChat ? Math.max(0, myQuota.lastActionAt + cooldownMs - now) : 0;
  const canSend = cooldownMs === 0 || remainingCooldown <= 0;
  const photoLocked = !isOwner && myQuota.photosUsed >= STD_MAX_PHOTOS;
  const photoRemainingMs = myQuota.photoLimitHitAt ? Math.max(0, myQuota.photoLimitHitAt + PHOTO_COOLDOWN_MS - now) : 0;
  const photoLockActive = photoLocked && photoRemainingMs > 0;

  // ---------- init ----------
  useEffect(() => {
    (async () => {
      try {
        const lv = lsGet("msngr:lang");
        if (lv && LANG_CODES.includes(lv)) setLang(lv);
        const stored = await loadMe();
        if (!stored) {
          setPhase("onboarding");
          return;
        }
        setMe(stored);
        setDirectorySize(await registeredCount());
        setContacts(await loadContactList());
        setPhase("chatlist");
      } catch (e) {
        setInitError(describeError(e));
        setPhase("error");
      }
    })();
  }, [initTick]);

  // Speicher-Selbsttest, sobald der Onboarding-Screen sichtbar ist
  useEffect(() => {
    if (phase !== "onboarding") return;
    let cancelled = false;
    setStorageStatus(null);
    runStorageCheck().then((res) => {
      if (!cancelled) setStorageStatus(res);
    });
    return () => {
      cancelled = true;
    };
  }, [phase]);

  const refreshChatList = useCallback(async (opts = {}) => {
    if (!me || listFetchBusy.current) return;
    listFetchBusy.current = true;
    try {
      setDirectorySize(await registeredCount());
      setContacts(await loadContactList());
      setListSyncError("");
    } catch (e) {
      if (!opts.silent) setListSyncError(t("syncFail"));
    } finally {
      listFetchBusy.current = false;
    }
  }, [me]);

  useEffect(() => {
    if (phase !== "chatlist" || !me) return;
    refreshChatList({ silent: true });
    const iv = setInterval(() => refreshChatList({ silent: true }), 6000);
    return () => clearInterval(iv);
  }, [phase, me, refreshChatList]);

  const refreshChat = useCallback(async (key, myId, opts = {}) => {
    if (threadFetchBusy.current) return;
    threadFetchBusy.current = true;
    try {
      const c = await loadChat(key, { id: myId });
      if (c.messages.some((m) => m.user !== myId && !m.seen)) {
        try {
          await rpc("mark_seen", { p_thread: key });
          c.messages.forEach((m) => {
            if (m.user !== myId) m.seen = true;
          });
        } catch (e) {
          // Lesebestätigung ist nur Hintergrund — Nachrichten trotzdem anzeigen
        }
      }
      setChatData(c);
      setThreadSyncError("");
    } catch (e) {
      if (!opts.silent) setThreadSyncError(t("syncFail"));
    } finally {
      threadFetchBusy.current = false;
    }
  }, []);

  useEffect(() => {
    if (phase !== "thread" || !activeChat || !me) return;
    const key = threadKey(me, activeChat);
    setThreadSyncError("");
    refreshChat(key, me.id, { silent: true });
    pollRef.current = setInterval(() => refreshChat(key, me.id, { silent: true }), 4000);
    tickRef.current = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      clearInterval(pollRef.current);
      clearInterval(tickRef.current);
    };
  }, [phase, activeChat, me, refreshChat]);

  const chatlistPull = usePullToRefresh(chatListScrollRef, () => refreshChatList({ silent: false }));
  const threadPull = usePullToRefresh(
    scrollRef,
    useCallback(async () => {
      if (!activeChat || !me) return;
      await refreshChat(threadKey(me, activeChat), me.id, { silent: false });
    }, [activeChat, me, refreshChat])
  );

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [chatData.messages, pending]);

  // photo cooldown auto-reset
  useEffect(() => {
    if (!activeChat || isOwner) return;
    if (myQuota.photoLimitHitAt && photoRemainingMs <= 0 && myQuota.photosUsed > 0) {
      (async () => {
        // Server setzt das Foto-Kontingent beim nächsten Senden zurück; hier nur die Anzeige
        setChatData((c) => ({ ...c, quotas: { ...c.quotas, [me.id]: { ...(c.quotas[me.id] || DEFAULT_QUOTA), photosUsed: 0, photoLimitHitAt: null } } }));
      })();
    }
  }, [photoRemainingMs, myQuota, activeChat, isOwner, me]);

  // ---------- actions ----------
  const finishAuth = async (res) => {
    const c = await loadContactList();
    setMe(res.me);
    setDirectorySize(res.directorySize);
    setContacts(c);
    setNameDraft("");
    setPwDraft("");
    setPw2Draft("");
    setLoginId("");
    setNameError("");
    setPhase("chatlist");
  };

  const handleRegister = async () => {
    if (loading) return;
    setLoading(true);
    setNameError("");
    try {
      await finishAuth(await registerAccount(nameDraft, pwDraft, pw2Draft));
    } catch (e) {
      setNameError(describeError(e));
      if (!(e && e.key)) runStorageCheck().then(setStorageStatus);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async () => {
    if (loading) return;
    setLoading(true);
    setNameError("");
    try {
      await finishAuth(await loginAccount(loginId, pwDraft));
    } catch (e) {
      setNameError(describeError(e));
      if (!(e && e.key)) runStorageCheck().then(setStorageStatus);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logoutAccount();
    } catch (e) {
      setNameError(describeError(e));
      return;
    }
    setMe(null);
    setActiveChat(null);
    setContacts([]);
    setPwDraft("");
    setNameError("");
    setPhase("login");
  };

  const renameUser = async () => {
    const trimmed = nameDraft.trim();
    if (!trimmed || !me) {
      setPhase("settings");
      return;
    }
    setLoading(true);
    try {
      await rpc("rename_user", { p_name: trimmed });
      const newMe = { ...me, name: trimmed };
      setMe(newMe);
      setPhase("settings");
    } catch (e) {
      setNameError(describeError(e));
    } finally {
      setLoading(false);
    }
  };

  const addContactById = async () => {
    const targetId = addIdDraft.trim().toUpperCase();
    setAddIdMsg("");
    if (!targetId) return;
    if (targetId === me.id) {
      setAddIdMsg(t("ownIdErr"));
      return;
    }
    setLoading(true);
    try {
      const nm = await rpc("add_contact", { p_target: targetId });
      setAddIdMsg(`✓ ${t("connected", nm)}`);
      setAddIdDraft("");
      setContacts((prev) => {
        if (prev.some((c) => c.id === targetId)) return prev;
        return [...prev, { id: targetId, name: nm }];
      });
    } catch (e) {
      setAddIdMsg(describeError(e));
    } finally {
      setLoading(false);
    }
  };

  const openChat = async (id, name, owner) => {
    setActiveChat({ id, name, isSupport: owner });
    setPending([]);
    setSendError("");
    setInput("");
    setPhase("thread");
  };

  const doSend = async (localMsg, kind, words) => {
    if (sendingRef.current) return;
    sendingRef.current = true;
    setSending(true);
    setSendError("");
    setPending((p) => [...p, localMsg]);
    const key = threadKey(me, activeChat);
    try {
      await sendMessage(me, activeChat, kind, localMsg.text, words); // Limits prüft der Server
      setChatData(await loadChat(key, me));
    } catch (e) {
      const msg = (e && e.message) || "";
      if (msg.startsWith("cooldown:")) setSendError(t("lockedFor", fmtCountdown(Number(msg.split(":")[1]) * 1000)));
      else if (msg.startsWith("photo_locked:")) setPhotoToast(true);
      else if (msg === "word_limit") setSendError(t("wordLimit", maxWords));
      else setSendError(`${t("sendFail")} ${describeError(e)}`);
    } finally {
      setPending((p) => p.filter((m) => m.id !== localMsg.id));
      sendingRef.current = false;
      setSending(false);
    }
  };

  const handleSendText = () => {
    const text = input.trim();
    if (!text || !canSend) return;
    const localMsg = { id: `${Date.now()}-${Math.random()}`, user: me.id, type: "text", text, ts: Date.now() };
    setInput("");
    doSend(localMsg, ALLOWED_EMOJIS.includes(text) ? "emoji" : "text", messageCost(text));
  };

  const handlePickPhoto = async (file) => {
    if (!file || !canSend || photoLockActive) return;
    try {
      const dataUrl = await compressImage(file);
      const localMsg = { id: `${Date.now()}-${Math.random()}`, user: me.id, type: "photo", text: dataUrl, ts: Date.now() };
      doSend(localMsg, "photo", 0);
    } catch (e) {
      setSendError(t("photoFail"));
    }
  };

  const deleteMessage = async (id) => {
    setConfirmDeleteMsg(null);
    try {
      await db(supabase.from("messages").delete().eq("id", id));
      setChatData(await loadChat(threadKey(me, activeChat), me));
    } catch (e) {
      setSendError(`${t("delFail")} ${describeError(e)}`);
    }
  };

  const deleteChatMessages = async (id) => {
    try {
      await db(supabase.from("messages").delete().eq("thread_key", chatKeyFor(me.id, id)));
      if (activeChat?.id === id) setChatData((c) => ({ ...c, messages: [] }));
    } catch (e) {
      // Chat bleibt unverändert, wenn das Löschen fehlschlug
    } finally {
      setDeleteChatId(null);
      setPickingChatToDelete(false);
    }
  };

  const copyId = () => {
    navigator.clipboard?.writeText(me.id).catch(() => {});
    setCopyFlash(true);
    setTimeout(() => setCopyFlash(false), 1200);
  };

  const startPress = (m, e) => {
    if (e) e.stopPropagation();
    if (m.user !== me.id) return;
    pressTimer.current = setTimeout(() => setConfirmDeleteMsg(m.id), 500);
  };
  const cancelPress = () => clearTimeout(pressTimer.current);

  // ---------- render: loading ----------
  if (phase === "loading") return <div className="min-h-screen" style={{ background: COL.bg }} />;

  // ---------- render: error ----------
  if (phase === "error") {
    return (
      <div className="screen-in min-h-screen w-full flex items-center justify-center p-6" style={{ background: COL.bg, fontFamily: "'Space Grotesk', sans-serif" }}>
        <FontImport />
        <div className="w-full max-w-sm">
          <div className="text-xs tracking-widest mb-2" style={{ color: COL.danger, fontFamily: "'JetBrains Mono', monospace" }}>{t("connErrTitle")}</div>
          <div className="text-sm mb-4" style={{ color: COL.text }}>{initError}</div>
          <button onClick={() => { setInitError(""); setPhase("loading"); setInitTick((t) => t + 1); }} className="w-full py-3 rounded-xl font-medium" style={{ background: COL.accent, color: COL.bg }}>
            {t("retry")}
          </button>
        </div>
      </div>
    );
  }

  // ---------- render: onboarding (Registrierung) ----------
  if (phase === "onboarding") {
    return (
      <AuthShell hint={hint} onHintDone={onHintDone} lang={lang} setLang={changeLang} title={t("chooseName")} bottomText={t("haveAccount")} onBottom={() => { setNameError(""); setPhase("login"); }}>
        <input value={nameDraft} onChange={(e) => setNameDraft(e.target.value)} maxLength={20} placeholder={t("chooseName")} className="w-full px-4 py-3 mb-3 outline-none rounded-xl" style={fieldStyle} />
        <input type="password" value={pwDraft} onChange={(e) => setPwDraft(e.target.value)} maxLength={PW_MAX} placeholder={t("password")} className="w-full px-4 py-3 mb-3 outline-none rounded-xl" style={fieldStyle} />
        <input type="password" value={pw2Draft} onChange={(e) => setPw2Draft(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleRegister()} maxLength={PW_MAX} placeholder={t("password2")} className="w-full px-4 py-3 mb-2 outline-none rounded-xl" style={fieldStyle} />
        <div className="text-xs mb-3" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{t("pwRules")}</div>
        {nameError && <div className="text-sm mb-3" style={{ color: COL.danger }}>{nameError}</div>}
        <div className="text-xs mb-4" style={{ fontFamily: "'JetBrains Mono', monospace", color: storageStatus ? (storageStatus.ok ? COL.accent : COL.danger) : COL.faint }}>
          {storageStatus === null ? t("storageChecking") : storageStatus.ok ? t("storageOk") : t("storageBad", storageStatus.reason)}
        </div>
        <button onClick={handleRegister} disabled={loading} className="w-full py-3 rounded-xl font-medium tracking-wide disabled:opacity-50" style={{ background: COL.accent, color: COL.bg }}>
          {t("register")}
        </button>
      </AuthShell>
    );
  }

  // ---------- render: login ----------
  if (phase === "login") {
    return (
      <AuthShell hint={hint} onHintDone={onHintDone} lang={lang} setLang={changeLang} title={t("loginTitle")} bottomText={t("noAccount")} onBottom={() => { setNameError(""); setPwDraft(""); setPhase("onboarding"); }}>
        <input value={loginId} onChange={(e) => setLoginId(e.target.value)} placeholder={t("idPlaceholder")} autoCapitalize="characters" className="w-full px-4 py-3 mb-3 outline-none rounded-xl" style={fieldStyle} />
        <input type="password" value={pwDraft} onChange={(e) => setPwDraft(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleLogin()} maxLength={PW_MAX} placeholder={t("password")} className="w-full px-4 py-3 mb-3 outline-none rounded-xl" style={fieldStyle} />
        {nameError && <div className="text-sm mb-3" style={{ color: COL.danger }}>{nameError}</div>}
        <button onClick={handleLogin} disabled={loading} className="w-full py-3 rounded-xl font-medium tracking-wide disabled:opacity-50" style={{ background: COL.accent, color: COL.bg }}>
          {t("loginBtn")}
        </button>
      </AuthShell>
    );
  }

  // ---------- render: settings ----------
  if (phase === "settings" || phase === "editName") {
    return (
      <div className="screen-in min-h-screen w-full" style={{ background: COL.bg, fontFamily: "'Space Grotesk', sans-serif" }}>
        <FontImport />
        <div className="flex items-center gap-3 px-4 py-4 border-b" style={{ borderColor: COL.border, background: COL.panel }}>
          <button onClick={() => setPhase(phase === "editName" ? "settings" : "chatlist")} style={{ color: COL.text }}>
            <ChevronLeft size={22} />
          </button>
          <span style={{ color: COL.text, fontWeight: 700 }}>{phase === "editName" ? t("username") : t("settings")}</span>
        </div>

        {phase === "settings" && (
          <div className="p-4 space-y-3">
            <button onClick={() => { setNameDraft(me.name); setPhase("editName"); }} className="w-full text-left p-4 rounded-xl flex items-center justify-between" style={{ background: COL.panel2 }}>
              <div>
                <div className="text-xs mb-1" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{t("usernameLabel")}</div>
                <div style={{ color: COL.text }}>{me.name}</div>
              </div>
              <ChevronLeft size={16} style={{ transform: "rotate(180deg)", color: COL.faint }} />
            </button>

            <div className="p-4 rounded-xl" style={{ background: COL.panel2 }}>
              <div className="text-xs mb-2" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{t("yourId")}</div>
              <div className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl mb-2" style={{ background: COL.field, border: `1px solid ${COL.fieldBorder}` }}>
                <span style={{ color: COL.accent, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "1px" }}>{isDev ? "De1V01" : me.id}</span>
                <button onClick={copyId} style={{ color: COL.muted }}>
                  <Copy size={16} />
                </button>
              </div>
              {copyFlash && <div className="text-xs mb-2" style={{ color: COL.accent }}>{t("copied")}</div>}
              <div className="text-xs" style={{ color: COL.faint }}>{t("idHint")}</div>
            </div>

            <div className="p-4 rounded-xl" style={{ background: COL.panel2 }}>
              <div className="text-xs mb-2" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{t("enterId")}</div>
              <div className="flex gap-2">
                <input
                  value={addIdDraft}
                  onChange={(e) => setAddIdDraft(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && addContactById()}
                  placeholder="SC-XXXXXX"
                  className="flex-1 px-3 py-2 rounded-xl outline-none text-sm"
                  style={{ background: COL.field, border: `1px solid ${COL.fieldBorder}`, color: COL.text, fontFamily: "'JetBrains Mono', monospace" }}
                />
                <button onClick={addContactById} disabled={loading} className="px-3 rounded-xl flex items-center justify-center disabled:opacity-50" style={{ background: COL.accent, color: COL.bg }}>
                  <UserPlus size={18} />
                </button>
              </div>
              {addIdMsg && <div className="text-xs mt-2" style={{ color: addIdMsg.startsWith("✓") ? COL.accent : COL.danger }}>{addIdMsg}</div>}
            </div>

            <div className="p-4 rounded-xl" style={{ background: COL.panel2 }}>
              <div className="text-xs mb-1" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{t("display")}</div>
              <div style={{ color: COL.text }}>{t("darkmode")}</div>
              <div className="text-xs mt-1" style={{ color: COL.faint }}>{t("darkOnly")}</div>
            </div>

            <div className="p-4 rounded-xl flex items-center justify-between" style={{ background: COL.panel2 }}>
              <div className="text-xs" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{t("language")}</div>
              <LangPicker lang={lang} setLang={changeLang} />
            </div>

            <button onClick={openSupport} className="w-full text-left p-4 rounded-xl flex items-center justify-between" style={{ background: COL.panel2, color: COL.text }}>
              <span>{isDev ? t("supportInbox") : t("support")}</span>
              <ChevronLeft size={16} style={{ transform: "rotate(180deg)", color: COL.faint }} />
            </button>

            <button onClick={handleLogout} className="w-full text-left p-4 rounded-xl" style={{ background: COL.panel2, color: COL.text }}>
              {t("logout")}
            </button>

            <button onClick={() => setPickingChatToDelete(true)} className="w-full text-left p-4 rounded-xl flex items-center gap-2" style={{ background: COL.panel2, color: COL.danger }}>
              <Trash2 size={16} />
              {t("delChat")}
            </button>

            <div className="text-xs text-center pt-4" style={{ color: COL.faint }}>{t("copyright")}</div>
          </div>
        )}

        {phase === "editName" && (
          <div className="p-4">
            <input
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && renameUser()}
              maxLength={20}
              placeholder={t("chooseName")}
              className="w-full px-3 py-3 mb-3 outline-none rounded-xl"
              style={{ background: COL.field, border: `1px solid ${COL.fieldBorder}`, color: COL.text, fontFamily: "'JetBrains Mono', monospace" }}
            />
            {nameError && <div className="text-sm mb-3" style={{ color: COL.danger }}>{nameError}</div>}
            <button onClick={renameUser} disabled={loading} className="w-full py-3 rounded-xl font-medium disabled:opacity-50" style={{ background: COL.accent, color: COL.bg }}>
              {t("save")}
            </button>
          </div>
        )}

        {pickingChatToDelete && (
          <div className="fixed inset-0 flex items-end justify-center p-4 z-50" style={{ background: "rgba(0,0,0,0.5)" }}>
            <div className="w-full max-w-sm rounded-xl p-4" style={{ background: COL.panel }}>
              <div style={{ color: COL.text }} className="mb-3">{t("whichChat")}</div>
              <div className="space-y-2 mb-3">
                {contacts.map((c) => (
                  <button key={c.id} onClick={() => setDeleteChatId(c.id)} className="w-full text-left px-3 py-2 rounded-xl" style={{ background: COL.panel2, color: COL.text }}>{c.name}</button>
                ))}
              </div>
              <button onClick={() => setPickingChatToDelete(false)} className="w-full py-2.5 rounded-xl" style={{ background: COL.panel2, color: COL.muted }}>{t("cancel")}</button>
            </div>
          </div>
        )}

        {deleteChatId && (
          <div className="fixed inset-0 flex items-end justify-center p-4 z-50" style={{ background: "rgba(0,0,0,0.5)" }}>
            <div className="w-full max-w-sm rounded-xl p-4" style={{ background: COL.panel }}>
              <div style={{ color: COL.text }} className="mb-4">{t("delChatConfirm")}</div>
              <div className="flex gap-2">
                <button onClick={() => setDeleteChatId(null)} className="flex-1 py-2.5 rounded-xl" style={{ background: COL.panel2, color: COL.muted }}>{t("cancel")}</button>
                <button onClick={() => deleteChatMessages(deleteChatId)} className="flex-1 py-2.5 rounded-xl" style={{ background: COL.danger, color: "#fff" }}>{t("del")}</button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ---------- render: support inbox (nur Dev) ----------
  if (phase === "supportInbox") {
    return (
      <div className="screen-in min-h-screen w-full" style={{ background: COL.bg, fontFamily: "'Space Grotesk', sans-serif" }}>
        <FontImport />
        <div className="flex items-center gap-3 px-4 py-4 border-b" style={{ borderColor: COL.border, background: COL.panel }}>
          <button onClick={() => setPhase("settings")} style={{ color: COL.text }}><ChevronLeft size={22} /></button>
          <span style={{ color: COL.text, fontWeight: 700 }}>{t("supportInbox")}</span>
        </div>
        {supportErr && <div className="px-4 py-2 text-xs" style={{ color: COL.danger }}>{supportErr}</div>}
        <div className="p-2">
          {supportList.map((c) => (
            <button key={c.id} onClick={() => openChat(c.id, c.name, true)} className="w-full flex items-center gap-3 p-3 rounded-xl mb-1" style={{ background: COL.panel2 }}>
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: COL.panel, border: `1px solid ${COL.border}` }}>
                <span style={{ color: COL.muted, fontFamily: "'JetBrains Mono', monospace" }}>{(c.name[0] || "?").toUpperCase()}</span>
              </div>
              <div className="text-left">
                <div style={{ color: COL.text, fontWeight: 600 }}>{c.name}</div>
                <div className="text-xs" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{c.id}</div>
              </div>
            </button>
          ))}
          {supportList.length === 0 && !supportErr && (
            <div className="text-xs text-center mt-8" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{t("supportEmpty")}</div>
          )}
        </div>
      </div>
    );
  }

  // ---------- render: chat list ----------
  if (phase === "chatlist") {
    const segments = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    return (
      <div className="screen-in min-h-screen w-full flex flex-col" style={{ background: COL.bg, fontFamily: "'Space Grotesk', sans-serif" }}>
        <FontImport />
        <div className="border-b px-5 py-4" style={{ borderColor: COL.border, background: COL.panel }}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3" style={{ color: COL.accent }}>
              <Logo size={34} />
              <span className="text-xs tracking-widest" style={{ fontFamily: "'JetBrains Mono', monospace" }}>SIEGE CHAT 1.0.0</span>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setPhase("settings")} aria-label={t("settings")} className="flex items-center justify-center rounded-lg" style={{ width: 34, height: 34, color: COL.muted }}>
                <UserIcon size={18} />
              </button>
              <LangPicker lang={lang} setLang={changeLang} hint={hint} onHintDone={onHintDone} />
            </div>
          </div>
          <div className="flex items-center gap-1 mb-2">
            {segments.map((s) => (
              <div key={s} className="h-1.5 flex-1 rounded-xl" style={{ background: directorySize > ((s - 1) * MAX_USERS) / segments.length ? COL.accent : COL.border }} />
            ))}
          </div>
          <div className="text-xs" style={{ fontFamily: "'JetBrains Mono', monospace", color: COL.muted }}>
            {t("users")} {directorySize}/{MAX_USERS} · {t("lock")} {getCooldownMinutes(directorySize).toFixed(0)} MIN
          </div>
        </div>

        {listSyncError && (
          <div className="px-4 py-1.5 text-xs" style={{ color: COL.danger }}>{listSyncError}</div>
        )}

        <div ref={chatListScrollRef} {...chatlistPull.handlers} className="flex-1 overflow-y-auto p-2">
          <PullIndicator pull={chatlistPull.pull} refreshing={chatlistPull.refreshing} />
          {contacts.map((c) => (
            <button key={c.id} onClick={() => openChat(c.id, c.name, false)} className="w-full flex items-center gap-3 p-3 rounded-xl mb-1" style={{ background: COL.panel2 }}>
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: COL.panel, border: `1px solid ${COL.border}` }}>
                <span style={{ color: COL.muted, fontFamily: "'JetBrains Mono', monospace" }}>{c.name[0]?.toUpperCase()}</span>
              </div>
              <div className="text-left">
                <div style={{ color: COL.text, fontWeight: 600 }}>{c.name}</div>
                <div className="text-xs" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{c.id}</div>
              </div>
            </button>
          ))}

          {contacts.length === 0 && (
            <div className="text-xs text-center mt-8" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>
              {t("noContacts")}
            </div>
          )}
        </div>
      </div>
    );
  }

  // ---------- render: thread ----------
  const allMessages = [...chatData.messages, ...pending.map((p) => ({ ...p, pending: true }))].sort((a, b) => a.ts - b.ts);

  return (
    <div className="screen-in min-h-screen w-full flex flex-col" style={{ background: COL.bg, fontFamily: "'Space Grotesk', sans-serif" }}>
      <FontImport />

      <div className="border-b px-4 py-3" style={{ borderColor: COL.border, background: COL.panel }}>
        <div className="flex items-center gap-3 mb-2">
          <button onClick={leaveThread} style={{ color: COL.text }}>
            <ChevronLeft size={22} />
          </button>
          <span style={{ color: COL.text, fontWeight: 700 }}>{activeChat.name}</span>
        </div>
        {isOwner ? (
          <div className="text-xs" style={{ fontFamily: "'JetBrains Mono', monospace", color: COL.faint }}>
            {t("supportNoLimits")}
          </div>
        ) : (
          <div className="flex items-center justify-between text-xs" style={{ fontFamily: "'JetBrains Mono', monospace", color: COL.faint }}>
            <span>{t("words")} {Math.floor(STD_MAX_WORDS - myQuota.wordsUsed)}/{STD_MAX_WORDS}</span>
            <span>{t("photos")} {STD_MAX_PHOTOS - myQuota.photosUsed}/{STD_MAX_PHOTOS}</span>
            <span>{t("lock")} {cooldownMin.toFixed(0)} MIN</span>
          </div>
        )}
        {!isOwner && remainingCooldown > 0 && (
          <div className="text-xs mt-1" style={{ color: COL.danger, fontFamily: "'JetBrains Mono', monospace" }}>{t("blocked")} {fmtCountdown(remainingCooldown)}</div>
        )}
      </div>

      <div ref={scrollRef} {...threadPull.handlers} className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        <PullIndicator pull={threadPull.pull} refreshing={threadPull.refreshing} />
        {threadSyncError && (
          <div className="text-xs text-center" style={{ color: COL.danger }}>{threadSyncError}</div>
        )}
        {allMessages.length === 0 && (
          <div className="text-xs text-center mt-10" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{t("empty")}</div>
        )}
        {allMessages.map((m) => {
          const mine = m.user === me.id;
          return (
            <div key={m.id} className={`msg-in flex ${mine ? "justify-end" : "justify-start"}`}>
              <div
                className="max-w-[75%] select-none"
                onMouseDown={(e) => startPress(m, e)}
                onMouseUp={cancelPress}
                onMouseLeave={cancelPress}
                onTouchStart={(e) => startPress(m, e)}
                onTouchEnd={cancelPress}
              >
                {m.type === "text" ? (
                  <div className="px-3 py-2 rounded-2xl text-sm" style={{ background: mine ? COL.accent : COL.panel2, color: mine ? COL.bg : COL.text }}>
                    {m.text}
                  </div>
                ) : (
                  <img src={m.text} alt="Foto" className="rounded-xl max-w-full" style={{ border: `1px solid ${COL.border}` }} />
                )}
                <div className={`flex items-center gap-1 mt-0.5 ${mine ? "justify-end" : "justify-start"}`}>
                  <span className="text-xs" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>{fmtClock(m.ts)}</span>
                  {mine && !m.pending && <Check size={13} style={{ color: m.seen ? COL.blueTick : COL.faint }} />}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {sendError && <div className="px-4 pb-1 text-xs" style={{ color: COL.danger }}>{sendError}</div>}

      {showEmoji && (
        <div className="flex gap-1.5 px-4 py-2 flex-wrap border-t" style={{ borderColor: COL.border, background: COL.panel }}>
          {ALLOWED_EMOJIS.map((e) => (
            <button key={e} onClick={() => setInput((v) => v + e)} className="text-lg px-1.5 py-0.5 rounded-xl" style={{ background: COL.panel2 }}>{e}</button>
          ))}
        </div>
      )}

      <div className="px-3 py-3" style={{ background: COL.panel }}>
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 px-3 py-2 rounded-full" style={{ background: COL.field, border: `1px solid ${COL.fieldBorder}` }}>
            <button onClick={() => setShowEmoji((v) => !v)} style={{ color: COL.muted }}>
              <Smile size={20} />
            </button>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendText()}
              disabled={!canSend}
              placeholder={t("placeholder")}
              className="flex-1 bg-transparent outline-none text-sm disabled:opacity-50"
              style={{ color: COL.text }}
            />
            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => handlePickPhoto(e.target.files?.[0])} />
            <button
              onClick={() => (photoLockActive ? setPhotoToast(true) : fileInputRef.current?.click())}
              disabled={!canSend || sending}
              style={{ color: photoLockActive ? COL.danger : COL.muted, opacity: canSend ? 1 : 0.4 }}
            >
              <Paperclip size={20} />
            </button>
          </div>
          <button onClick={handleSendText} disabled={!canSend || sending || !input.trim()} className="p-3 rounded-full disabled:opacity-40 flex items-center justify-center" style={{ background: COL.accent, color: COL.bg }}>
            <Send size={18} />
          </button>
        </div>
        {photoLockActive && (
          <div className="text-xs mt-1 text-center" style={{ color: COL.faint, fontFamily: "'JetBrains Mono', monospace" }}>
            {t("photosBack")} {fmtCountdown(photoRemainingMs)}
          </div>
        )}
      </div>

      {photoToast && (
        <div className="fixed bottom-4 left-4 right-4 flex justify-center z-50">
          <div className="toast-slide w-full max-w-sm rounded-xl px-4 py-3 flex items-center justify-between gap-2" style={{ background: COL.panel2, border: `1px solid ${COL.border}` }}>
            <span className="text-sm" style={{ color: COL.text }}>{t("photoToast")}</span>
            <button onClick={() => setPhotoToast(false)} style={{ color: COL.faint }}><X size={16} /></button>
          </div>
        </div>
      )}

      {confirmDeleteMsg && (
        <div className="fixed inset-0 flex items-end justify-center p-4 z-50" style={{ background: "rgba(0,0,0,0.5)" }}>
          <div className="w-full max-w-sm rounded-xl p-4" style={{ background: COL.panel }}>
            <div style={{ color: COL.text }} className="mb-4">{t("delMsg")}</div>
            <div className="flex gap-2">
              <button onClick={() => setConfirmDeleteMsg(null)} className="flex-1 py-2.5 rounded-xl" style={{ background: COL.panel2, color: COL.muted }}>{t("cancel")}</button>
              <button onClick={() => deleteMessage(confirmDeleteMsg)} className="flex-1 py-2.5 rounded-xl" style={{ background: COL.danger, color: "#fff" }}>{t("del")}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- Splash: "Made by Veyron Studio" + Lade-Erkennung ----------
const MIN_SPLASH_MS = 2800;
function Splash({ boot, attempt, onRetry, onGone }) {
  const t0 = useRef(performance.now());
  const [elapsed, setElapsed] = useState(0);
  const [loadMs, setLoadMs] = useState(null);
  const [leaving, setLeaving] = useState(false);
  const [gone, setGone] = useState(false);
  LANG = boot.lang || LANG;
  const failed = boot.phase === "error";
  const ready = boot.phase !== "loading" && !failed;

  useEffect(() => {
    t0.current = performance.now();
    setElapsed(0);
    setLoadMs(null);
    setLeaving(false);
    setGone(false);
  }, [attempt]);

  useEffect(() => {
    if (leaving) return;
    const iv = setInterval(() => setElapsed(performance.now() - t0.current), 200);
    return () => clearInterval(iv);
  }, [leaving, attempt]);

  // gemessene echte Ladezeit, sobald die App bereit ist
  useEffect(() => {
    if (ready && loadMs === null) setLoadMs(Math.round(performance.now() - t0.current));
  }, [ready, loadMs]);

  // erst ausblenden, wenn App + Schriften geladen sind und die Animation durch ist
  useEffect(() => {
    if (loadMs === null) return;
    let cancelled = false;
    const fonts = typeof document !== "undefined" && document.fonts && document.fonts.ready
      ? Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 2500))])
      : Promise.resolve();
    fonts.then(() => {
      const wait = Math.max(0, MIN_SPLASH_MS - (performance.now() - t0.current));
      setTimeout(() => { if (!cancelled) setLeaving(true); }, wait);
    });
    return () => { cancelled = true; };
  }, [loadMs]);

  useEffect(() => {
    if (!leaving) return;
    const to = setTimeout(() => { setGone(true); if (onGone) onGone(); }, 700);
    return () => clearTimeout(to);
  }, [leaving]);

  if (gone) return null;
  const offline = typeof navigator !== "undefined" && navigator.onLine === false;
  const mono = { fontFamily: "'JetBrains Mono', monospace" };
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center px-8" style={{ zIndex: 100, background: "#000", fontFamily: "'Space Grotesk', sans-serif", opacity: leaving ? 0 : 1, transition: "opacity .7s ease", pointerEvents: leaving ? "none" : "auto" }}>
      <FontImport />
      <div className="w-full max-w-sm flex flex-col items-center text-center">
        <svg width="64" height="64" viewBox="0 0 100 100" fill="none" draggable="false" onContextMenu={(e) => e.preventDefault()} style={{ userSelect: "none" }}>
          <desc>© Veyron Studio</desc>
          <path className="sp-hex" pathLength="1" d="M50 8 L86 29 L86 71 L50 92 L14 71 L14 29 Z" stroke="#fff" strokeWidth="7" strokeLinejoin="round" />
        </svg>
        <div className="sp-item mt-8" style={{ animationDelay: ".9s", color: "#fff", fontSize: 34, fontWeight: 700, letterSpacing: ".02em" }}>VEYRON STUDIO</div>
        <div className="sp-item mt-4" style={{ animationDelay: "1.2s", color: "#8A8A8A", fontSize: 15 }}>Software · Development · Innovation</div>
        <div className="sp-line mt-8 w-full" style={{ animationDelay: "1.5s", height: 1, background: "#2A2A2A" }} />
        <div className="sp-item mt-8" style={{ animationDelay: "1.8s", color: "#fff", fontSize: 20 }}>Siege Chat</div>
        <div className="sp-item mt-3" style={{ animationDelay: "2.1s", color: "#8A8A8A", fontSize: 15 }}>Made by Veyron Studio</div>
      </div>

      <div className="absolute left-0 right-0 bottom-8 px-8 text-center text-xs" style={{ ...mono, color: "#6E6E6E" }}>
        {failed ? (
          <div className="mx-auto max-w-sm">
            <div style={{ color: COL.danger, marginBottom: 6 }}>{t("connErrTitle")}</div>
            <div style={{ marginBottom: 6 }}>{boot.error}</div>
            {offline && <div style={{ marginBottom: 6 }}>{t("offline")}</div>}
            <button onClick={onRetry} className="px-5 py-2 rounded-xl" style={{ background: COL.accent, color: "#000", fontWeight: 700 }}>{t("retry")}</button>
          </div>
        ) : loadMs !== null ? (
          <div>{t(loadQuality(loadMs))} · {(loadMs / 1000).toFixed(1)} s</div>
        ) : (
          <div className="mx-auto max-w-sm">
            <div style={{ marginBottom: 8 }}>{offline ? t("offline") : elapsed > 4000 ? t("splashSlow") : t("splashLoading")}</div>
            <div className="mx-auto overflow-hidden" style={{ width: 120, height: 2, background: "#1E1E1E", borderRadius: 2 }}>
              <div className="sp-bar" style={{ width: "40%", height: 2, background: COL.accent }} />
            </div>
            {elapsed > 12000 && (
              <button onClick={onRetry} className="mt-4 px-5 py-2 rounded-xl" style={{ background: "#1E1E1E", color: "#fff" }}>{t("retry")}</button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default function SiegeChat() {
  const [boot, setBoot] = useState({ phase: "loading", error: "", lang: LANG });
  const [attempt, setAttempt] = useState(0);
  const [hint, setHint] = useState(false);
  const hintTimer = useRef(null);
  const dismissHint = useCallback(() => {
    clearTimeout(hintTimer.current);
    setHint(false);
  }, []);
  // Hinweis erscheint, sobald der Splash weg ist, und verschwindet nach 1 Minute
  const showHint = useCallback(() => {
    setHint(true);
    clearTimeout(hintTimer.current);
    hintTimer.current = setTimeout(() => setHint(false), 60000);
  }, []);
  useEffect(() => () => clearTimeout(hintTimer.current), []);
  return (
    <>
      <SiegeChatApp key={attempt} onBoot={setBoot} hint={hint} onHintDone={dismissHint} />
      <Splash
        boot={boot}
        attempt={attempt}
        onGone={showHint}
        onRetry={() => {
          setBoot({ phase: "loading", error: "", lang: LANG });
          setAttempt((a) => a + 1);
        }}
      />
    </>
  );
}
