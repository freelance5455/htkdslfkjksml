# Smart 10.6 — Native Android Build

This is the **native Android Smart app**, not the browser/ZIP-to-APK web wrapper.

## What is connected
- Native Smart chat UI
- Voice button and foreground Smart Voice service
- Accessibility-based phone controls
- Open apps and websites/search
- Home / Back / Recent / notifications / quick settings
- Calls and SMS composer
- Camera, screenshot and timer/alarm actions
- Floating Smart button foundation
- Notification listener foundation
- Smart Pro/billing foundation
- GitHub Actions APK build

## Important
Android permissions and Accessibility access must be enabled by the user. Android also restricts background microphone behavior on some devices.

The general AI chat backend is intentionally **not embedded with an API secret**. To enable full AI chat, deploy the backend in `backend/` and put its HTTPS URL into `SmartAiClient.kt` as `BASE_URL`.

## Build
Push this project to GitHub and run **Actions → Build Smart APK → Run workflow**. The generated `smart-v10.6-debug-apk` artifact contains the installable APK.
