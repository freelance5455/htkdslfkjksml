# AI Farming – Android build
1. Deploy `server/server.js` (any host with Node 18+, set ANTHROPIC_API_KEY) and put its HTTPS URL in `www/index.html` → `const AI_ENDPOINT="https://YOUR-SERVER/"`.
2. `npm install`
3. `npx cap add android`
4. `npm run assets`   (generates icons/splash from /assets)
5. `npm run sync` then `npm run open` (Android Studio) → Build > Build APK(s) / Generate Signed Bundle for Play Store.
4b. In android/app/src/main/AndroidManifest.xml make sure these exist:
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.CAMERA"/>
PWA: host the `www` folder over HTTPS and use "Install app" / "Add to Home screen" in Chrome.
