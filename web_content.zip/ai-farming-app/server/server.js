// Tiny proxy that keeps your Anthropic API key off the phone. Run: ANTHROPIC_API_KEY=sk-... node server/server.js  (Node 18+)
const http=require("http");const KEY=process.env.ANTHROPIC_API_KEY;
http.createServer(async(req,res)=>{
 res.setHeader("Access-Control-Allow-Origin","*");res.setHeader("Access-Control-Allow-Headers","Content-Type");
 if(req.method==="OPTIONS"){res.writeHead(204);return res.end()}
 if(req.method!=="POST"){res.writeHead(404);return res.end()}
 let b="";for await(const c of req)b+=c;
 try{const {system,messages,image}=JSON.parse(b);const msgs=messages.map(m=>({role:m.role,content:m.content}));
  if(image){const l=msgs[msgs.length-1];l.content=[{type:"image",source:{type:"base64",media_type:"image/jpeg",data:image}},{type:"text",text:l.content}]}
  const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"content-type":"application/json","x-api-key":KEY,"anthropic-version":"2023-06-01"},body:JSON.stringify({model:"claude-sonnet-5-5",max_tokens:1200,system,messages:msgs})});
  const j=await r.json();res.writeHead(200,{"Content-Type":"application/json"});res.end(JSON.stringify({text:(j.content||[]).map(x=>x.text||"").join("")||JSON.stringify(j)}))}
 catch(e){res.writeHead(500);res.end(JSON.stringify({text:String(e)}))}
}).listen(process.env.PORT||8787,()=>console.log("AI proxy on :"+(process.env.PORT||8787)));
