// AI Farming proxy — keeps your Anthropic API key off the phone.
// Run:  ANTHROPIC_API_KEY=sk-ant-... node server/server.js      (Node 18+, no dependencies)
// Optional env: APP_TOKEN (shared secret the app sends), MODEL, PORT, ALLOW_ORIGIN, RATE_LIMIT (requests / 10 min / IP)
const http = require("http");
const KEY = process.env.ANTHROPIC_API_KEY, TOKEN = process.env.APP_TOKEN || "";
const MODEL = process.env.MODEL || "claude-sonnet-5-5", ORIGIN = process.env.ALLOW_ORIGIN || "*";
const LIMIT = +process.env.RATE_LIMIT || 40, MAX_BODY = 8 * 1024 * 1024;
if (!KEY) { console.error("Set ANTHROPIC_API_KEY first."); process.exit(1); }

const hits = new Map(); // ip -> [timestamps]
function limited(ip) {
  const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 6e5);
  a.push(now); hits.set(ip, a); return a.length > LIMIT;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (!v.some(t => now - t < 6e5)) hits.delete(k); }, 6e5).unref();

const send = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json" }); res.end(JSON.stringify(obj)); };

http.createServer(async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", ORIGIN);
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }
  if (req.method === "GET" && req.url.startsWith("/health")) return send(res, 200, { ok: true, model: MODEL });
  if (req.method !== "POST") return send(res, 404, { text: "Not found" });
  if (TOKEN && req.headers.authorization !== "Bearer " + TOKEN) return send(res, 401, { text: "Unauthorized: wrong access token" });
  const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").split(",")[0].trim();
  if (limited(ip)) return send(res, 429, { text: "Too many requests, please wait a few minutes." });

  let body = "", size = 0;
  for await (const c of req) { size += c.length; if (size > MAX_BODY) return send(res, 413, { text: "Image too large" }); body += c; }
  try {
    const { system, messages, image, max_tokens } = JSON.parse(body);
    if (!Array.isArray(messages) || !messages.length) return send(res, 400, { text: "messages required" });
    const msgs = messages.map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content) }));
    if (image) {
      const last = msgs[msgs.length - 1];
      last.content = [{ type: "image", source: { type: "base64", media_type: "image/jpeg", data: image } }, { type: "text", text: last.content }];
    }
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 80000);
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", signal: ctl.signal,
      headers: { "content-type": "application/json", "x-api-key": KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: MODEL, max_tokens: Math.min(+max_tokens || 1200, 2500), system, messages: msgs })
    });
    clearTimeout(to);
    const j = await r.json();
    if (!r.ok) return send(res, 502, { text: j.error?.message || "Upstream error " + r.status });
    send(res, 200, { text: (j.content || []).map(x => x.text || "").join("") });
  } catch (e) { send(res, 500, { text: e.name === "AbortError" ? "AI timed out" : String(e.message || e) }); }
}).listen(process.env.PORT || 8787, () => console.log("AI Farming proxy on :" + (process.env.PORT || 8787) + " model=" + MODEL + (TOKEN ? " (token required)" : " (open — set APP_TOKEN!)")));
