// Offline mode: every feature works with NO AI server. Used automatically when no AI is configured.
Object.assign(L.ar,{off_t1:"تشخيص مشكلة النبات",off_d1:"اختر الأعراض التي تراها على النبات ثم اضغط تشخيص. (يمكنك أيضاً التقاط صورة لتقارن بها.)",off_go:"🔍 تشخيص من الأعراض",sy_t:"ماذا ترى على النبات؟",nosel:"اختر عرضاً واحداً على الأقل.",nomatch:"لا يوجد تطابق واضح. جرّب أعراضاً أخرى أو افتح مكتبة الأمراض.",match:"نسبة التطابق",off_help:"لم أجد إجابة محددة. جرّب اسم نبات (مثل: طماطم) أو كلمة مثل: ري، تربة، آفات، سماد، تخزين، أو اسم مرض.",off_topics:"مواضيع متاحة:",off_more:"📚 المزيد في «مكتبة الأمراض» و«مشاكل الزراعة وحلولها»."});
Object.assign(L.en,{off_t1:"Plant problem diagnosis",off_d1:"Tick the symptoms you see on the plant, then press Diagnose. (You can also take a photo to compare.)",off_go:"🔍 Diagnose from symptoms",sy_t:"What do you see on the plant?",nosel:"Select at least one symptom.",nomatch:"No clear match. Try other symptoms or open the disease library.",match:"Match",off_help:"I couldn’t find a specific answer. Try a plant name (e.g. tomato) or a word like: irrigation, soil, pests, fertiliser, storage, or a disease name.",off_topics:"Available topics:",off_more:"📚 More in the Disease library and Farming problems & solutions."});
Object.assign(L.de,{off_t1:"Diagnose von Pflanzenproblemen",off_d1:"Wähle die Symptome, die du an der Pflanze siehst, und tippe auf Diagnose. (Du kannst auch ein Foto zum Vergleich aufnehmen.)",off_go:"🔍 Diagnose aus Symptomen",sy_t:"Was siehst du an der Pflanze?",nosel:"Wähle mindestens ein Symptom.",nomatch:"Keine eindeutige Übereinstimmung. Probiere andere Symptome oder öffne die Krankheitsbibliothek.",match:"Übereinstimmung",off_help:"Ich habe keine konkrete Antwort gefunden. Versuche einen Pflanzennamen (z. B. Tomate) oder ein Wort wie: Bewässerung, Boden, Schädlinge, Dünger, Lagerung oder einen Krankheitsnamen.",off_topics:"Verfügbare Themen:",off_more:"📚 Mehr in der Krankheitsbibliothek und unter Probleme der Landwirtschaft & Lösungen."});
Object.assign(L.fr,{off_t1:"Diagnostic des problèmes de plantes",off_d1:"Cochez les symptômes observés sur la plante puis appuyez sur Diagnostiquer. (Vous pouvez aussi prendre une photo pour comparer.)",off_go:"🔍 Diagnostiquer selon les symptômes",sy_t:"Que voyez-vous sur la plante ?",nosel:"Sélectionnez au moins un symptôme.",nomatch:"Aucune correspondance claire. Essayez d’autres symptômes ou ouvrez la bibliothèque des maladies.",match:"Correspondance",off_help:"Je n’ai pas trouvé de réponse précise. Essayez un nom de plante (ex. tomate) ou un mot comme : irrigation, sol, ravageurs, engrais, conservation, ou un nom de maladie.",off_topics:"Sujets disponibles :",off_more:"📚 Plus dans la bibliothèque des maladies et Problèmes agricoles et solutions."});

const offlineOn=()=>!endpoint()&&!window.claude;
const nz=s=>String(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f\u064B-\u065F]/g,"").replace(/[أإآ]/g,"ا").replace(/ى/g,"ي").replace(/ة/g,"ه").replace(/ß/g,"ss");
const toks=s=>nz(s).split(/[^a-z0-9\u0600-\u06ff]+/).filter(Boolean).map(w=>w.replace(/^(وال|بال|لل|ال|و)(?=.{2,})/,""));
const kwHit=(txt,tk,kw)=>{const e=kw[0]=="=",k=nz(e?kw.slice(1):kw);return e||k.length<=3?tk.includes(k):txt.includes(k)};
const score=(txt,tk,kws)=>kws.reduce((n,k)=>n+(kwHit(txt,tk,k)?1:0),0);

// keywords per SOL index (see solutions.js order)
const SK=[
"water,irrigat,drought,drip,ري,مياه,ماء,جفاف,تنقيط,wasser,bewasser,durre,trocken,tropf,=eau,irrig,arros,secheresse,goutte",
"soil,erosion,compost,تربه,تعريه,boden,kompost,humus,=sol,terre",
"salin,salt,ملوح,ملح,salz,=sel",
"climate,weather,frost,heat,flood,مناخ,طقس,صقيع,=حر,فيضان,klima,wetter,hitze,climat,meteo,=gel,canicule",
"pest,insect,thrip,آفات,آفه,حشر,schadling,insekt,ravageur,nuisible",
"disease,fungal,bacteri,virus,مرض,امراض,فطر,krankheit,pilz,maladie,champignon",
"weed,حشائش,حشيش,unkraut,adventice,mauvaise herbe",
"fertil,nutrient,manure,npk,analys,سماد,اسمده,تسميد,خصوبه,تحليل,dunger,dungung,nahrstoff,engrais,azote",
"seed,germinat,بذور,بذره,تقاوي,انبات,=saat,samen,keimung,semence,graine",
"harvest,storage,store,spoil,حصاد,تخزين,حفظ,فاقد,ernte,lager,verderb,recolte,stockage,conserv,perte",
"market,price,sell,تسويق,سعر,اسعار,بيع,markt,preis,verkauf,=prix,vente,commerci",
"cost,profit,income,تكلف,ربح,دخل,kosten,gewinn,einkommen,=cout,benefice,rentab",
"pesticide,spray,herbicide,residue,مبيد,رش,pestizid,spritz,traitement",
"labour,labor,worker,machin,tractor,عمال,عماله,ميكن,جرار,arbeit,maschine,main-d,mecanis,ouvrier",
"=bee,pollinat,biodivers,نحل,تلقيح,تنوع,biene,bestaub,artenvielfalt,abeille,pollinis",
"loan,credit,finance,extension,training,قرض,تمويل,ارشاد,تدريب,kredit,beratung,schulung,financement,vulgarisation,formation"
].map(s=>s.split(","));
const DK={pm:"powdery,mildew,دقيقي,mehltau,oidium,بياض",dm:"downy,mildew,زغبي,mehltau,mildiou,بياض",lb:"blight,late blight,لفحه,متاخره,krautfaule,braunfaule,mildiou",eb:"early blight,blight,مبكره,durrfleck,alternar",ap:"aphid,=المن,blattlaus,puceron",sm:"mite,spider,عنكبوت,spinnmilbe,milbe,acarien,araignee",wf:"whitefly,white fly,ذباب,weisse fliege,aleurode,mouche blanche",ru:"rust,=صدا,=rost,rouille",rr:"root rot,damping,=عفن,wurzelfaule,umfall,pourriture,fonte",nd:"nitrogen,نيتروجين,ازوت,stickstoff,azote,اصفرار,yellow,gelb,jaunis",fe:"iron,chlorosis,حديد,eisen,chlorose,=fer,اصفرار",tu:"tuta,leafminer,leaf miner,حفار,miniermotte,mineuse",rw:"weevil,palm,سوسه,نخيل,palmrussler,charancon,palmier"};
Object.keys(DK).forEach(k=>DK[k]=DK[k].split(","));

// plants -> related diseases
const PD=[[/tomato/,["lb","eb","tu","wf","rr","nd"]],[/potato/,["lb","eb","ap","nd"]],[/cucumber|melon|squash|zucchini|pumpkin/,["pm","dm","sm","wf","rr"]],[/wheat|barley|oat|rye/,["ru","ap","nd"]],[/palm/,["rw","nd","fe"]],[/rose|bean/,["ru","pm","ap","sm"]]];
const PC={veg:["pm","ap","wf","rr","nd"],fruit:["pm","ap","sm","fe"],tree:["ap","fe","rr","nd"],grain:["ru","ap","nd"],legume:["ru","ap","rr"],herb:["pm","ap","rr"],ind:["ap","wf","nd"],flower:["pm","ap","sm","ru"],house:["sm","rr","fe","ap"]};

const kOf=()=>["ar","de","fr"].includes(lg)?lg:"en";
const disById=id=>DIS.find(d=>d.id==id);
const plantMatch=(txt)=>{let best=-1,len=0;P.forEach((p,i)=>Object.values(p.n).forEach(v=>{const n=nz(v);if(n.length<3||n.length<=len)return;
 const hit=/[a-z]/.test(n)?new RegExp("(^|[^a-z])"+n.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+"(s|es|n|en)?($|[^a-z])").test(txt):txt.includes(n);if(hit){best=i;len=n.length}}));return best};
const firstSent=s=>String(s).split(/[;.؛]/)[0];
const solBlock=(r,k)=>`**${r[0]} ${r[1][k]}**\n${r[2][k]}\n`+r[3][k].map(x=>"- "+x).join("\n");
const disBlock=(d,k)=>`**${d.i} ${d.n[k]}**\n**${t("sym")}:** ${d.s[k]}\n**${t("org")}:** ${d.t[k]}\n**${t("prev")}:** ${d.p[k]}`;
function plantGuide(i,k,onlyProblems){
 const p=P[i],f=F[p.n.en]||{},T=L[lg],key=p.n.en.toLowerCase();
 const ids=(PD.find(x=>x[0].test(key))||[0,PC[p.c]||PC.veg])[1],ds=ids.map(disById).filter(Boolean);
 if(onlyProblems)return `**🌿 ${p.n[lg]}** — ${t("probs")}\n\n`+ds.map(d=>disBlock(d,k)).join("\n\n");
 const [a,b]=(f.m||"1-12").split("-").map(Number),sow=a==b?monthName(a):monthName(a)+" → "+monthName(b);
 let o=`**🌿 ${p.n[lg]}** (${T.cat[p.c]}${p.n.en!=p.n[lg]?" · "+p.n.en:""})\n`;
 if(f.t)o+=`- ${t("f_days")}: ${f.d?f.d+" "+t("days"):t("perennial")}\n- ${t("f_temp")}: ${f.t}°C\n- ${t("f_water")}: ${t("w"+f.w)}\n- ${t("f_sun")}: ${t("s"+f.s)}\n- ${t("f_ph")}: ${f.ph}\n- ${t("f_sow")}: ${sow}\n`;
 o+=`\n**${t("careT")}**\n${T.care[p.c]}\n`;
 if(ds.length)o+=`\n**${t("probs")}**\n`+ds.map(d=>`- ${d.i} ${d.n[k]} — ${firstSent(d.t[k])}`).join("\n");
 return o+`\n\n${t("sowNote")}`}

// Chat engine (replaces the AI when none is configured)
async function offlineAI(msgs,on){
 const k=kOf(),raw=String((msgs[msgs.length-1]||{}).content||""),txt=nz(raw),tk=toks(raw);
 const pi=plantMatch(txt);
 if(pi>=0){const prob=/disease|problem|pest|مرض|امراض|مشاكل|افات|krankheit|probleme|schadling|maladie|ravageur/.test(txt);return plantGuide(pi,k,prob)}
 const dm=Object.keys(DK).map(id=>[id,score(txt,tk,DK[id])]).filter(x=>x[1]>0).sort((a,b)=>b[1]-a[1]).slice(0,2);
 const sm=SK.map((kw,i)=>[i,score(txt,tk,kw)]).filter(x=>x[1]>0).sort((a,b)=>b[1]-a[1]).slice(0,2);
 const out=[...dm.map(x=>disBlock(disById(x[0]),k)),...sm.map(x=>solBlock(SOL[x[0]],k))].slice(0,3);
 if(out.length)return out.join("\n\n")+"\n\n"+t("off_more");
 return t("off_help")+"\n\n**"+t("off_topics")+"**\n"+SOL.slice(0,8).map(r=>"- "+r[0]+" "+r[1][k]).join("\n")}

// Symptom-based diagnosis (replaces photo AI)
const SY=[
["yellow_old",{ar:"اصفرار موحّد يبدأ بالأوراق القديمة وبطء النمو",en:"Older leaves turn evenly pale yellow; slow, stunted growth",de:"Ältere Blätter vergilben gleichmäßig; langsames, gestauchtes Wachstum",fr:"Les vieilles feuilles jaunissent uniformément ; croissance lente"},{nd:3}],
["yellow_young",{ar:"الأوراق الحديثة صفراء والعروق خضراء",en:"Young leaves yellow while veins stay green",de:"Junge Blätter gelb, Adern bleiben grün",fr:"Jeunes feuilles jaunes, nervures vertes"},{fe:3}],
["white_powder",{ar:"بقع بيضاء مسحوقية على الأوراق والسيقان",en:"White powdery patches on leaves and stems",de:"Weiße, mehlartige Flecken auf Blättern und Stängeln",fr:"Taches blanches poudreuses sur feuilles et tiges"},{pm:3}],
["angular_fuzz",{ar:"بقع صفراء زاوية وزغب رمادي بنفسجي أسفل الورقة",en:"Yellow angular patches with grey-purple fuzz underneath",de:"Gelbe eckige Flecken mit grau-violettem Flaum unterseits",fr:"Taches jaunes anguleuses avec duvet gris-violet dessous"},{dm:3}],
["dark_blotch",{ar:"بقع داكنة مائية كبيرة وعفن أبيض وتعفن الثمار",en:"Large dark water-soaked blotches, white mould, fruit rot",de:"Große dunkle wasserdurchtränkte Flecken, weißer Schimmel, Fruchtfäule",fr:"Grandes taches sombres huileuses, moisissure blanche, fruits pourris"},{lb:3}],
["ring_spots",{ar:"بقع بنية بحلقات متداخلة على الأوراق القديمة",en:"Brown spots with concentric rings on older leaves",de:"Braune Flecken mit konzentrischen Ringen auf älteren Blättern",fr:"Taches brunes à anneaux concentriques sur vieilles feuilles"},{eb:3}],
["insects",{ar:"حشرات صغيرة خضراء أو سوداء متجمعة على القمم وندوة عسلية",en:"Clusters of tiny green or black insects on shoots; sticky honeydew",de:"Gruppen winziger grüner oder schwarzer Insekten an Trieben; klebriger Honigtau",fr:"Colonies de minuscules insectes verts ou noirs sur les pousses ; miellat"},{ap:3,wf:1}],
["webbing",{ar:"خيوط عنكبوتية وتنقيط أصفر دقيق في الطقس الحار الجاف",en:"Fine webbing and yellow stippling in hot, dry weather",de:"Feine Gespinste und gelbe Sprenkelung bei heiß-trockenem Wetter",fr:"Fines toiles et ponctuation jaune par temps chaud et sec"},{sm:3}],
["white_fly",{ar:"حشرات بيضاء صغيرة تطير عند هز النبات",en:"Tiny white insects fly up when the plant is shaken",de:"Winzige weiße Insekten fliegen beim Schütteln auf",fr:"De minuscules insectes blancs s’envolent quand on secoue la plante"},{wf:3,ap:1}],
["sooty",{ar:"التفاف أو اصفرار الأوراق مع ندوة عسلية وعفن أسود",en:"Curling or yellowing leaves with honeydew and black sooty mould",de:"Eingerollte oder vergilbende Blätter mit Honigtau und Rußtau",fr:"Feuilles enroulées ou jaunies avec miellat et fumagine"},{wf:2,ap:2}],
["pustules",{ar:"بثرات برتقالية مسحوقية أسفل الأوراق",en:"Orange powdery pustules under the leaves",de:"Orangefarbene pulvrige Pusteln auf den Blattunterseiten",fr:"Pustules orange poudreuses sous les feuilles"},{ru:3}],
["root_wilt",{ar:"ذبول رغم رطوبة التربة أو انهيار البادرات وجذور بنية رخوة",en:"Wilting despite wet soil, collapsed seedlings, brown mushy roots",de:"Welke trotz nasser Erde, umgekippte Keimlinge, braune matschige Wurzeln",fr:"Flétrissement malgré sol humide, semis effondrés, racines brunes et molles"},{rr:3}],
["mines",{ar:"أنفاق متعرجة في الأوراق وثمار مثقوبة بفضلات سوداء",en:"Winding tunnels in leaves; holes in fruit with black droppings",de:"Gewundene Gänge in Blättern; Löcher in Früchten mit schwarzem Kot",fr:"Galeries sinueuses dans les feuilles ; fruits perforés avec déjections noires"},{tu:3}],
["palm",{ar:"سائل بني وألياف ممضوغة في جذع النخلة وانهيار السعف المركزي",en:"Brown ooze and chewed fibre on a palm trunk; central fronds collapse",de:"Brauner Saft und zerkaute Fasern am Palmenstamm; mittlere Wedel knicken ein",fr:"Écoulement brun et fibres mâchées sur un palmier ; palmes centrales qui s’effondrent"},{rw:3}]];

function offUI(){
 if(!offlineOn()){$("sy").innerHTML="";return}
 const on=[...document.querySelectorAll("#sy input:checked")].map(i=>i.dataset.s),k=kOf();
 $("t1").textContent=t("off_t1");$("d1").textContent=t("off_d1");$("go").textContent=t("off_go");
 $("sy").innerHTML=`<h4 style="margin:12px 0 4px;color:var(--g)">${t("sy_t")}</h4>`+SY.map(s=>`<label class="sy"><input type="checkbox" data-s="${s[0]}"${on.includes(s[0])?" checked":""}><span>${esc(s[1][k])}</span></label>`).join("")}

function offlineScan(){
 const r=$("res"),k=kOf(),sel=[...document.querySelectorAll("#sy input:checked")].map(i=>i.dataset.s);$("acts").innerHTML="";r.style.display="block";
 if(!sel.length){r.textContent=t("nosel");return}
 const sc={};SY.filter(s=>sel.includes(s[0])).forEach(s=>Object.entries(s[2]).forEach(([id,w])=>sc[id]=(sc[id]||0)+w));
 const top=Object.entries(sc).sort((a,b)=>b[1]-a[1]).slice(0,3);
 if(!top.length){r.textContent=t("nomatch");return}
 r.innerHTML=top.map(([id,v])=>{const d=disById(id),pc=Math.min(100,Math.round(v/(3*sel.length)*100));
  return `<div class="iss"><div class="it"><b>${d.i} ${esc(d.n[k])}</b><span class="ty">${esc(tt("ty_",d.ty))}</span></div><div class="bar"><i style="width:${pc}%"></i></div><small>${t("match")}: ${pc}%</small><h4>${t("sym")}</h4><p>${esc(d.s[k])}</p><h4>${t("org")}</h4><p>${esc(d.t[k])}</p><h4>${t("prev")}</h4><p>${esc(d.p[k])}</p></div>`}).join("")+`<p>${t("off_more")}</p>`;
 const b=document.createElement("button"),d0=disById(top[0][0]);b.textContent="💬 "+t("followup");b.onclick=()=>{show(2);$("q").value=d0.n[k]+" — ";$("q").focus()};$("acts").appendChild(b)}
