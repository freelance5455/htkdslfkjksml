// AI Farming v2 — app logic. Data/i18n live in data.js.
const AI_ENDPOINT=""; // optional default server URL; users can also set it in Settings (no rebuild needed)
const $=i=>document.getElementById(i);
const ld=(k,d)=>{try{const v=localStorage.getItem("af_"+k);return v==null?d:JSON.parse(v)}catch(e){return d}};
const sv=(k,v)=>{try{localStorage.setItem("af_"+k,JSON.stringify(v))}catch(e){}};
let lg=ld("lg",null)||(["ar","de","fr"].includes((navigator.language||"").slice(0,2))?navigator.language.slice(0,2):"en");
let tab=0,cat="all",img=null,busy=false,lastScan=null;
let hist=ld("hist",[]),farm=ld("farm",[]),scans=ld("scans",[]),cfg=ld("cfg",{}),wx=ld("wx",null);
const t=k=>L[lg][k]??(X[k]?X[k][lg=="ar"?1:0]:k);
const tt=(p,v)=>X[p+v]?t(p+v):v;
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const fmt=s=>esc(s).replace(/\*\*(.+?)\*\*/g,"<b>$1</b>").replace(/^#{1,4}\s*(.+)$/gm,"<b>$1</b>").replace(/^[-*]\s+/gm,"• ").replace(/\n/g,"<br>");
const arr=x=>Array.isArray(x)?x:x?[x]:[];
const sum=a=>a.reduce((x,y)=>x+(+y||0),0);
const dl=lg=>["ar","de","fr"].includes(lg)?lg:"en";
const plantName=p=>p.n[lg];
const monthName=m=>new Date(2000,m-1,1).toLocaleString(lg,{month:"short"});
const toURL=b=>new Promise(r=>{const f=new FileReader();f.onload=()=>r(f.result);f.readAsDataURL(b)});

/* ---------- AI ---------- */
const ctxLine=()=>{const a=[];if(cfg.place)a.push("User location: "+cfg.place);if(wx)a.push(`Current weather ${wx.t}°C, humidity ${wx.h}%`);if(farm.length)a.push("User is growing: "+[...new Set(farm.map(f=>P[f.i].n.en))].join(", "));return a.join(". ")};
const SYS=()=>`You are AI Farming, an expert agronomist and plant pathologist assistant inside a mobile app. Always reply in ${L[lg].n}. Be practical and concise, give quantities and timings when useful, prefer organic/low-risk solutions first, state uncertainty honestly, and when you list chemical products remind the user to follow the label and local regulations and wear protection. Only answer farming, gardening and plant topics. ${ctxLine()}`;
const endpoint=()=>(cfg.url||AI_ENDPOINT||"").trim().replace(/\/+$/,"");
async function ai(msgs,blob,on,opt={}){
 const s=window.claude&&await claude.use("sample");
 if(s){const o={onText:r=>on&&on(r.text),cache:false};if(blob&&(await s.limits()).images)o.images=[blob];
  const m=msgs.map((x,i)=>i?x:{role:x.role,content:(opt.system||SYS())+"\n\n"+x.content});return (await s(m,o)).text}
 const u=endpoint();if(!u)return offlineAI(msgs,on);
 const b64=blob?(await toURL(blob)).split(",")[1]:null,ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),90000);
 try{
  const r=await fetch(u+"/",{method:"POST",signal:ctl.signal,headers:{"Content-Type":"application/json",...(cfg.token?{Authorization:"Bearer "+cfg.token}:{})},body:JSON.stringify({system:opt.system||SYS(),messages:msgs,image:b64,max_tokens:opt.max||1200})});
  const j=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(j.text||"HTTP "+r.status);
  on&&on(j.text);return j.text;
 }finally{clearTimeout(to)}
}
const errText=e=>e.message=="noai"?t("noai"):t("err")+(e.message&&e.name!="AbortError"?"\n("+e.message.slice(0,120)+")":"");
function shrink(f,m=1024,q=.85){return new Promise(r=>{const i=new Image();i.onload=()=>{const k=Math.min(1,m/Math.max(i.width,i.height)),c=document.createElement("canvas");c.width=i.width*k;c.height=i.height*k;c.getContext("2d").drawImage(i,0,0,c.width,c.height);c.toBlob(r,"image/jpeg",q)};i.src=URL.createObjectURL(f)})}

/* ---------- Chat ---------- */
function addMsg(cls,s){const d=document.createElement("div");d.className="m "+cls;d.innerHTML=fmt(s);$("msgs").appendChild(d);d.scrollIntoView({block:"end"});return d}
async function ask(text){if(busy||!text.trim())return;busy=true;show(2);addMsg("u",text);hist.push({role:"user",content:text});const d=addMsg("a",t("wait"));
 try{const r=await ai(hist.slice(-8),null,x=>d.innerHTML=fmt(x));hist.push({role:"assistant",content:r});d.innerHTML=fmt(r)}catch(e){d.textContent=errText(e);hist.pop()}
 hist=hist.slice(-40);sv("hist",hist);busy=false}
function drawChat(){$("msgs").innerHTML="";hist.forEach(m=>addMsg(m.role=="user"?"u":"a",m.content))}

/* ---------- Scan (plant ID + diagnosis) ---------- */
const HC={healthy:"#2e9e5b",mild:"#d9a400",moderate:"#e6751a",severe:"#d23a3a"};
const scanPrompt=()=>`You are a plant pathologist. Analyse the photo: identify the plant, judge its health, and list every visible problem (disease, pest, nutrient deficiency, environmental stress, weed). Reply with ONLY one JSON object, no markdown, in this exact shape:
{"is_plant":true,"plant":{"name":"common name","scientific":"Latin name"},"health":"healthy|mild|moderate|severe","confidence":0-100,"issues":[{"name":"","type":"fungal|bacterial|viral|pest|nutrient|environmental|weed|other","symptoms":"what is visible and what else to check","cause":"","organic":["step"],"chemical":["active ingredient class, follow label"],"prevention":["step"],"urgency":"now|week|monitor"}],"care":"one or two sentences of general care for this plant","note":""}
If healthy, use an empty issues list. If the image is not a plant or too unclear, set is_plant false and explain in note. Write every text value in ${L[lg].n}; keep JSON keys and the enum values in English.`;
function pj(s){const m=String(s).match(/\{[\s\S]*\}/);if(!m)return null;try{return JSON.parse(m[0])}catch(e){return null}}
const lst=(h,a)=>a.length?`<h4>${h}</h4><ul>${a.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`:"";
function scanHTML(r){
 if(r.is_plant===false)return `<b>${t("notplant")}</b><br>${esc(r.note||"")}`;
 const h=HC[r.health]?r.health:"mild",c=Math.max(0,Math.min(100,Math.round(+r.confidence||0)));
 let o=`<div class="rh"><div><b class="pn">${esc(r.plant?.name||"?")}</b><div class="sci">${esc(r.plant?.scientific||"")}</div></div><span class="bd" style="background:${HC[h]}">${t(h)}</span></div><div class="bar"><i style="width:${c}%"></i></div><small>${t("conf")}: ${c}%</small>`;
 arr(r.issues).forEach(s=>{o+=`<div class="iss"><div class="it"><b>${esc(s.name)}</b><span><span class="ty">${esc(tt("ty_",s.type))}</span> ${s.urgency&&X["u_"+s.urgency]?`<span class="ur">${t("u_"+s.urgency)}</span>`:""}</span></div>
  ${s.symptoms?`<h4>${t("sym")}</h4><p>${esc(s.symptoms)}</p>`:""}${s.cause?`<h4>${t("cause")}</h4><p>${esc(s.cause)}</p>`:""}${lst(t("org"),arr(s.organic))}${lst(t("chem"),arr(s.chemical))}${lst(t("prev"),arr(s.prevention))}</div>`});
 if(r.care)o+=`<h4 style="color:var(--g);margin:12px 0 2px">${t("careT")}</h4><p style="color:var(--ink)">${esc(r.care)}</p>`;
 if(r.note)o+=`<p>${esc(r.note)}</p>`;return o}
const findPlant=nm=>{nm=String(nm||"").toLowerCase().trim();return nm?P.findIndex(p=>Object.values(p.n).some(v=>v.toLowerCase()==nm)):-1};
function scanActs(r,srcImg){const a=$("acts");a.innerHTML="";if(!r||r.is_plant===false)return;
 const pi=findPlant(r.plant?.name),sumTxt=`${r.plant?.name||""}: ${arr(r.issues).map(i=>i.name).join(", ")||t("healthy")}`;
 const add=(l,f)=>{const b=document.createElement("button");b.textContent=l;b.onclick=f;a.appendChild(b)};
 if(pi>=0)add("📖 "+t("openguide"),()=>{show(3);openPlant(pi)});
 add("💬 "+t("followup"),()=>{show(2);$("q").value=sumTxt+" — ";$("q").focus()});
 add("📤 "+t("share"),async()=>{const txt=`AI Farming — ${sumTxt}\n`+arr(r.issues).map(i=>`• ${i.name}: ${arr(i.organic).join("; ")}`).join("\n");try{navigator.share?await navigator.share({text:txt}):await navigator.clipboard.writeText(txt)}catch(e){}})}
async function runScan(){if(offlineOn())return offlineScan();const r=$("res");r.style.display="block";if(!img){r.textContent=t("nopic");return}if(busy)return;busy=true;r.textContent=t("wait");$("acts").innerHTML="";
 try{const raw=await ai([{role:"user",content:scanPrompt()}],img,null,{max:1800}),j=pj(raw);
  if(j){r.innerHTML=scanHTML(j);scanActs(j);lastScan=j;
   if(j.is_plant!==false){const th=await toURL(await shrink(img,160,.6));scans.unshift({id:Date.now(),th,r:j});scans=scans.slice(0,25);try{sv("scans",scans)}catch(e){}}}
  else r.innerHTML=fmt(raw)}catch(e){r.textContent=errText(e)}busy=false}
async function pick(f){if(!f)return;img=await shrink(f);$("prev").src=URL.createObjectURL(img);$("prev").style.display="block";$("res").style.display="none";$("acts").innerHTML=""}

/* ---------- Plants guide ---------- */
const mon=()=>{let m=new Date().getMonth()+1;if(cfg.lat<0)m=(m+5)%12+1;return m};
const inSow=p=>{const f=F[p.n.en];if(!f||p.c=="house")return false;const[a,b]=f.m.split("-").map(Number),m=mon();return a<=b?m>=a&&m<=b:m>=a||m<=b};
function drawPlants(){const T=L[lg],q=$("srch").value.toLowerCase();
 $("chips").innerHTML=["all","now",...Object.keys(T.cat)].map(k=>`<button class="chip ${k==cat?"on":""}" data-c="${k}">${k=="all"?T.all:k=="now"?"🗓️ "+t("sownow"):T.cat[k]}</button>`).join("");
 $("plist").innerHTML=P.map((p,i)=>[p,i]).filter(([p])=>(cat=="all"||(cat=="now"?inSow(p):p.c==cat))&&Object.values(p.n).some(v=>v.toLowerCase().includes(q))).map(([p,i])=>`<button class="pl" data-i="${i}"><span>${esc(plantName(p))}</span><small>${T.cat[p.c]}</small></button>`).join("")}
function openPlant(i){const p=P[i],T=L[lg],f=F[p.n.en]||{},e=$("pd");e.style.display="block";
 const [a,b]=(f.m||"1-12").split("-").map(Number),rows=[["f_days",f.d?f.d+" "+t("days"):t("perennial")],["f_temp",f.t+"°C"],["f_water",t("w"+f.w)],["f_sun",t("s"+f.s)],["f_ph",f.ph],["f_sow",a==b?monthName(a):monthName(a)+" → "+monthName(b)]];
 const today=new Date().toISOString().slice(0,10);
 e.innerHTML=`<h2>${esc(plantName(p))}</h2><p>${T.cat[p.c]}${p.n.en!=plantName(p)?" · "+esc(p.n.en):""}</p><div class="facts">${rows.map(r=>`<div><small>${t(r[0])}</small>${esc(r[1])}</div>`).join("")}</div><p style="font-size:11px">${t("sowNote")}</p><p style="color:var(--ink)">${T.care[p.c]}</p>
 <div class="sec2"><button id="pg">${T.guide}</button><button id="pp" class="ghost">${t("probs")}</button><div class="row2"><input type="date" id="pdt" value="${today}"><button id="pa" style="flex:none">${t("addfarm")}</button></div></div>`;
 $("pg").onclick=()=>ask({ar:`أعطني دليل زراعة كامل لنبات ${p.n.ar}: الموسم والتربة والري والتسميد وأهم الآفات والأمراض والحصاد.`,en:`Give me a complete growing guide for ${p.n.en}: season, soil, watering, fertilising, main pests and diseases, harvest.`,de:`Gib mir einen vollständigen Anbauleitfaden für ${p.n.de}: Saison, Boden, Gießen, Düngung, wichtigste Schädlinge und Krankheiten, Ernte.`,fr:`Donne-moi un guide de culture complet pour ${p.n.fr} : saison, sol, arrosage, fertilisation, principaux ravageurs et maladies, récolte.`}[lg]);
 $("pp").onclick=()=>ask({ar:`ما أهم الأمراض والآفات التي تصيب ${p.n.ar}؟ لكل مشكلة: الأعراض وطريقة العلاج العضوي ثم الكيميائي والوقاية.`,en:`What are the most important diseases and pests of ${p.n.en}? For each: symptoms, organic then chemical treatment, and prevention.`,de:`Welche Krankheiten und Schädlinge sind bei ${p.n.de} am wichtigsten? Je Problem: Symptome, biologische dann chemische Behandlung, Vorbeugung.`,fr:`Quelles sont les principales maladies et ravageurs de ${p.n.fr} ? Pour chacun : symptômes, traitement biologique puis chimique, prévention.`}[lg]);
 $("pa").onclick=()=>addPlanting(i,$("pdt").value||today);e.scrollIntoView({behavior:"smooth"})}

/* ---------- My farm ---------- */
const harvestAt=f=>{const d=F[P[f.i].n.en].d;return d?new Date(new Date(f.date).getTime()+d*864e5):null};
async function notify(id,title,body,at){try{const N=window.Capacitor?.Plugins?.LocalNotifications;if(!N||at<Date.now())return;await N.requestPermissions();await N.schedule({notifications:[{id,title,body,schedule:{at}}]})}catch(e){}}
function addPlanting(i,date){const f={id:Date.now()%2e9,i,date};farm.push(f);sv("farm",farm);const h=harvestAt(f);if(h){h.setHours(8,0,0,0);notify(f.id,"🌾 AI Farming",P[i].n[lg]+" — "+t("harvest"),h)}
 drawFarm();drawUp();show(4)}
function upRows(){return farm.map(f=>({f,h:harvestAt(f)})).filter(x=>x.h).sort((a,b)=>a.h-b.h)}
const upHTML=rows=>rows.map(({f,h})=>{const dd=Math.ceil((h-Date.now())/864e5);return `<div class="card" style="margin-top:8px"><b>${esc(plantName(P[f.i]))}</b> <small style="color:var(--mut)">${t("harvest")}: ${h.toLocaleDateString(lg)} (${dd>0?dd+" "+t("days"):"✓"})</small></div>`}).join("");
function drawUp(){const r=upRows().slice(0,3);$("up").innerHTML=r.length?`<h2>${t("upcoming")}</h2>${upHTML(r)}<div style="height:12px"></div>`:""}
function drawFarm(){$("mp").textContent=t("myplants");$("hh").textContent=t("hist");
 $("farm").innerHTML=farm.length?farm.map(f=>{const p=P[f.i],h=harvestAt(f),tot=F[p.n.en].d*864e5,pc=h?Math.max(0,Math.min(100,(Date.now()-new Date(f.date))/tot*100)):0;
  return `<div class="card" style="margin-top:8px"><div class="row2"><b>${esc(plantName(p))}</b><button class="x" data-rm="${f.id}">${t("remove")}</button></div><small style="color:var(--mut)">${t("planted")}: ${new Date(f.date).toLocaleDateString(lg)}${h?" · "+t("harvest")+": "+h.toLocaleDateString(lg):" · "+t("perennial")}</small>${h?`<div class="pr"><i style="width:${pc}%"></i></div>`:""}
  <div class="acts"><button data-ask="${f.i}">💬 ${t("followup")}</button></div></div>`}).join(""):`<p>${t("empty")}</p>`;
 $("hl").innerHTML=scans.length?scans.map(s=>`<button class="hi" data-sc="${s.id}"><img src="${s.th}" alt=""><span>${esc(s.r.plant?.name||"?")}<small>${t(HC[s.r.health]?s.r.health:"mild")} · ${arr(s.r.issues).map(i=>esc(i.name)).join(", ")||"—"}</small></span></button>`).join(""):`<p>${t("empty")}</p>`}

/* ---------- Weather & climate alerts (Open-Meteo, no key) ---------- */
async function fetchWx(){if(cfg.lat==null)return drawWx();
 try{const u=`https://api.open-meteo.com/v1/forecast?latitude=${cfg.lat}&longitude=${cfg.lon}&current=temperature_2m,relative_humidity_2m&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,et0_fao_evapotranspiration,wind_speed_10m_max&timezone=auto&forecast_days=7`;
  const j=await (await fetch(u)).json(),d=j.daily;wx={t:Math.round(j.current.temperature_2m),h:j.current.relative_humidity_2m,max:d.temperature_2m_max,min:d.temperature_2m_min,rain:d.precipitation_sum,et:d.et0_fao_evapotranspiration,wind:d.wind_speed_10m_max,at:Date.now()};sv("wx",wx)}catch(e){}
 drawWx();calc()}
function alerts(){const a=[],w=wx;if(!w)return a;
 if(Math.min(...w.min)<=2)a.push("al_frost");if(Math.max(...w.max)>=36)a.push("al_heat");if(Math.max(...w.wind)>=40)a.push("al_wind");if(Math.max(...w.rain)>=25)a.push("al_rain");
 if(sum(w.rain)<5&&sum(w.et)>20)a.push("al_dry");if(w.h>=85&&w.t>=15&&w.t<=28)a.push("al_fungal");return a}
function drawWx(){const e=$("wx");
 if(!wx){e.innerHTML=`<b>🌦️ ${t("wxT")}</b><p>${t("setloc")}</p><button id="wset" style="width:100%">${t("useloc").replace("📍 ","📍 ")}</button>`;$("wset").onclick=()=>show(7);return}
 const al=alerts();e.innerHTML=`<div class="top"><div><b>🌦️ ${t("wxT")}</b><br><small>${esc(cfg.place||"")}</small></div><div class="big">${wx.t}°</div></div>
 <small>💧 ${wx.h}% · ↑${Math.round(wx.max[0])}° ↓${Math.round(wx.min[0])}° · ${t("rain7")}: ${Math.round(sum(wx.rain))} mm · ${t("et7")}: ${Math.round(sum(wx.et))} mm</small>
 ${(al.length?al:["al_ok"]).map(k=>`<div class="al ${k=="al_ok"?"":"w"}">${t(k)}</div>`).join("")}`}

/* ---------- Calculators ---------- */
function calc(){const A=+$("ia").value||0,kc=KC[$("ic").value]||1,ef=[.9,.75,.55][+$("im").value||0],et=+$("ie").value||0,rain=wx?sum(wx.rain)/7:0;
 const need=Math.max(0,et*kc-rain*.8)*A/ef;$("r1").textContent=`${Math.round(need).toLocaleString(lg)} ${t("u_ld")} · ${(need*7/1000).toFixed(1)} ${t("u_m3")}`;
 const pct=+$("fp").value||0;$("r2").textContent=pct>0?`${((+$("fr").value||0)*(+$("fa").value||0)/1e4/(pct/100)).toFixed(2)} ${t("u_kg")}`:"—";
 const cell=(+$("sr").value||0)*(+$("sp").value||0)/1e4;$("r3").textContent=cell>0?`${Math.floor((+$("sa").value||0)/cell).toLocaleString(lg)} ${t("u_pl")}`:"—"}
function drawCalc(){const T=L[lg];$("ct").textContent=t("calcT");$("c1").textContent=t("c_irr");$("c2").textContent=t("c_fert");$("c3").textContent=t("c_seed");
 ["c_area","c_crop","c_meth","c_et","c_area","c_rate","c_pct","c_area","c_row","c_pl"].forEach((k,i)=>$("l"+(i+1)).textContent=t(k));
 const cv=$("ic").value||"veg";$("ic").innerHTML=Object.keys(KC).map(k=>`<option value="${k}">${T.cat[k]}</option>`).join("");$("ic").value=cv;
 const mv=$("im").value||"0";$("im").innerHTML=[0,1,2].map(i=>`<option value="${i}">${t("m"+(i+1))}</option>`).join("");$("im").value=mv;
 if(wx&&!$("ie").dataset.u)$("ie").value=(sum(wx.et)/7).toFixed(1);$("cn").textContent=t("calcNote");calc()}

/* ---------- Disease library (offline) ---------- */
function drawDis(){const q=$("ds").value.toLowerCase(),k=dl(lg);$("dt").textContent="📚 "+t("dis_t");$("dn").textContent="📶 "+t("dis_off");$("ds").placeholder=t("dis_s");$("w6").textContent=L[lg].warn;
 $("dl").innerHTML=DIS.filter(d=>!q||Object.values(d.n).some(v=>v.toLowerCase().includes(q))).map(d=>`<details><summary>${d.i} ${esc(d.n[k])} <span class="ty">${esc(tt("ty_",d.ty))}</span></summary><h4>${t("sym")}</h4><p>${esc(d.s[k])}</p><h4>${t("org")}</h4><p>${esc(d.t[k])}</p><h4>${t("prev")}</h4><p>${esc(d.p[k])}</p><div class="acts"><button data-dq="${d.id}">💬 ${t("followup")}</button></div></details>`).join("")}

/* ---------- Settings ---------- */
function drawSet(){$("st").textContent="⚙️ "+t("set_t");$("k1").textContent=t("url");$("k2").textContent=t("token");$("su").value=cfg.url||"";$("sk").value=cfg.token||"";$("ss").textContent=t("save");$("stt").textContent=t("test");
 $("cq").placeholder=t("city");$("cb").textContent="🔍";$("gl").textContent=t("useloc");$("clr").textContent=t("clear");$("pl").textContent=cfg.place?"📍 "+cfg.place:""}
const setLoc=(la,lo,pl)=>{cfg={...cfg,lat:la,lon:lo,place:pl};sv("cfg",cfg);$("pl").textContent="📍 "+pl;$("cr").innerHTML="";fetchWx()};

/* ---------- Navigation & rendering ---------- */
function show(n){tab=n;document.querySelectorAll("section").forEach((s,i)=>s.classList.toggle("on",i==n));[...$("nav").children].forEach((b,i)=>b.classList.toggle("on",i==n));
 if(n==4){drawFarm()}if(n==5)drawCalc();if(n==6)drawDis();if(n==7)drawSet();if(n==8)drawSol();scrollTo(0,0)}
function draw(){const T=L[lg];document.documentElement.lang=lg;document.documentElement.dir=T.dir;$("lg").value=lg;$("tag").textContent=T.tag;
 const tl=[...T.tools,t("tl_calc"),t("tl_dis"),t("tl_sow"),t("tl_set")],ic=[...ICON,"🧮","📚","🗓️","⚙️"];
 $("tools").innerHTML=tl.map((x,i)=>`<button class="tile" data-t="${i}"><span>${ic[i]}</span>${x}</button>`).join("")+`<button class="tile sol" data-t="12"><span>🧩</span>${t("tl_sol")}</button>`;
 $("nav").innerHTML=[...T.tab,t("farm")].map((x,i)=>`<button data-n="${i}"><i>${["🏠","📷","🤖","🌱","🚜"][i]}</i>${x}</button>`).join("");
 $("h1").textContent=H[lg][0];$("h2").textContent=H[lg][1];$("hb1").textContent=T.shot;$("hb2").textContent="🤖 "+T.tab[2];$("t1").textContent=T.t1;$("d1").textContent=T.d1;$("shot").textContent=T.shot;$("gal").textContent=t("gal");$("go").textContent=T.go;
 $("q").placeholder=T.ph;$("send").textContent=T.send;$("srch").placeholder=T.srch;$("w1").textContent=$("w2").textContent=T.warn;$("nc").textContent=t("newchat");$("pd").style.display="none";
 document.querySelectorAll("[data-bk]").forEach(b=>b.textContent=t("back"));
 const bn=$("banner"),off=!endpoint()&&!window.claude;bn.style.display="none";bn.textContent=t("ai_off");
 drawPlants();drawWx();drawUp();drawChat();offUI();show(tab)}

/* ---------- Events ---------- */
$("lg").onchange=e=>{lg=e.target.value;sv("lg",lg);draw()};
$("nav").onclick=e=>{const b=e.target.closest("button");if(b)show(+b.dataset.n)};
document.body.addEventListener("click",e=>{if(e.target.closest("[data-bk]"))show(0)});
$("banner").onclick=()=>show(7);
$("tools").onclick=e=>{const b=e.target.closest("button");if(!b)return;const i=+b.dataset.t;
 if(i<8){if(offlineOn())ask(L[lg].tools[i]);else{show(2);$("q").value=L[lg].tools[i]+": ";$("q").focus()}}else if(i==8)show(5);else if(i==9)show(6);else if(i==10){cat="now";show(3);drawPlants()}else if(i==12)show(8);else show(7)};
$("chips").onclick=e=>{const b=e.target.closest("button");if(b){cat=b.dataset.c;drawPlants()}};
$("plist").onclick=e=>{const b=e.target.closest("button");if(b)openPlant(+b.dataset.i)};
$("srch").oninput=drawPlants;
$("send").onclick=()=>{const v=$("q").value;$("q").value="";ask(v)};$("q").onkeydown=e=>{if(e.key=="Enter")$("send").click()};
$("nc").onclick=()=>{hist=[];sv("hist",hist);drawChat()};
$("shot").onclick=()=>$("file").click();$("gal").onclick=()=>$("file2").click();$("hb1").onclick=()=>{show(1);$("file").click()};$("hb2").onclick=()=>show(2);
$("file").onchange=e=>{pick(e.target.files[0]);e.target.value=""};$("file2").onchange=e=>{pick(e.target.files[0]);e.target.value=""};
$("go").onclick=runScan;
$("farm").onclick=e=>{const r=e.target.closest("[data-rm]"),a=e.target.closest("[data-ask]");
 if(r){farm=farm.filter(f=>f.id!=r.dataset.rm);sv("farm",farm);try{window.Capacitor?.Plugins?.LocalNotifications?.cancel({notifications:[{id:+r.dataset.rm}]})}catch(x){}drawFarm();drawUp()}
 if(a){const p=P[+a.dataset.ask];show(2);$("q").value=p.n[lg]+" — ";$("q").focus()}};
$("hl").onclick=e=>{const b=e.target.closest("[data-sc]");if(!b)return;const s=scans.find(x=>x.id==b.dataset.sc);if(!s)return;show(1);$("prev").src=s.th;$("prev").style.display="block";$("res").style.display="block";$("res").innerHTML=scanHTML(s.r);scanActs(s.r)};
document.querySelectorAll("#s5 input,#s5 select").forEach(el=>el.addEventListener("input",()=>{if(el.id=="ie")el.dataset.u=1;calc()}));
$("ds").oninput=drawDis;
$("sq").oninput=drawSol;
$("sol").onclick=e=>{const b=e.target.closest("[data-sq]");if(!b)return;const r=SOL[+b.dataset.sq],k=["ar","de","fr"].includes(lg)?lg:"en";show(2);$("q").value=r[1][k]+" — ";$("q").focus()};
$("dl").onclick=e=>{const b=e.target.closest("[data-dq]");if(!b)return;const d=DIS.find(x=>x.id==b.dataset.dq);show(2);$("q").value=d.n[dl(lg)]+" — ";$("q").focus()};
$("ss").onclick=()=>{cfg={...cfg,url:$("su").value.trim(),token:$("sk").value.trim()};sv("cfg",cfg);$("sr1").textContent=t("saved");draw();show(7)};
$("stt").onclick=async()=>{const u=($("su").value.trim()||endpoint()).replace(/\/+$/,"");$("sr1").textContent=t("wait");
 try{const r=await fetch(u+"/health");const j=await r.json();$("sr1").textContent=r.ok&&j.ok?t("okc")+(j.model?" · "+j.model:""):t("failc")}catch(e){$("sr1").textContent=t("failc")}};
$("cb").onclick=async()=>{const q=$("cq").value.trim();if(!q)return;
 try{const j=await(await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=5&language=${lg}`)).json();
  $("cr").innerHTML=(j.results||[]).map(r=>`<button class="pl" data-la="${r.latitude}" data-lo="${r.longitude}" data-pl="${esc([r.name,r.admin1,r.country].filter(Boolean).join(", "))}"><span>${esc(r.name)}</span><small>${esc([r.admin1,r.country].filter(Boolean).join(", "))}</small></button>`).join("")||`<p>${t("empty")}</p>`}catch(e){$("cr").innerHTML=`<p>${t("failc")}</p>`}};
$("cq").onkeydown=e=>{if(e.key=="Enter")$("cb").click()};
$("cr").onclick=e=>{const b=e.target.closest("[data-la]");if(b)setLoc(+b.dataset.la,+b.dataset.lo,b.dataset.pl)};
$("gl").onclick=()=>navigator.geolocation?.getCurrentPosition(p=>setLoc(+p.coords.latitude.toFixed(3),+p.coords.longitude.toFixed(3),`${p.coords.latitude.toFixed(2)}, ${p.coords.longitude.toFixed(2)}`),()=>{$("pl").textContent=t("failc")},{timeout:15000});
$("clr").onclick=()=>{if(confirm(t("confirm"))){try{Object.keys(localStorage).filter(k=>k.startsWith("af_")).forEach(k=>localStorage.removeItem(k))}catch(e){}location.reload()}};
if("serviceWorker"in navigator&&location.protocol.startsWith("http"))navigator.serviceWorker.register("sw.js").catch(()=>{});
draw();fetchWx();setTimeout(()=>$("splash")?.remove(),1100);
