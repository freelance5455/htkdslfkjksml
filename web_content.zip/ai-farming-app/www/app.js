// Agrinova v2 — app logic. Data/i18n live in data.js.
const AI_ENDPOINT=""; // optional default server URL; users can also set it in Settings (no rebuild needed)
const $=i=>document.getElementById(i);
const ld=(k,d)=>{try{const v=localStorage.getItem("af_"+k);return v==null?d:JSON.parse(v)}catch(e){return d}};
const sv=(k,v)=>{try{localStorage.setItem("af_"+k,JSON.stringify(v))}catch(e){}};
let lg=ld("lg",null)||(["ar","de","fr"].includes((navigator.language||"").slice(0,2))?navigator.language.slice(0,2):"en");
let tab=0,cat="all",img=null,busy=false,lastScan=null;
let hist=ld("hist",[]),farm=ld("farm",[]),scans=ld("scans",[]),cfg=ld("cfg",{}),wx=ld("wx",null);
const t=k=>L[lg][k]??(X[k]?X[k][lg=="ar"?1:0]:k);
const tt=(p,v)=>X[p+v]?t(p+v):v;
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const fmt=s=>esc(s).replace(/\*\*(.+?)\*\*/g,"<b>$1</b>").replace(/^#{1,4}\s*(.+)$/gm,"<b>$1</b>").replace(/^[-*]\s+/gm,"• ").replace(/\n/g,"<br>");
const arr=x=>Array.isArray(x)?x:x?[x]:[];
const sum=a=>a.reduce((x,y)=>x+(+y||0),0);
const dl=lg=>["ar","de","fr"].includes(lg)?lg:"en";
const plantName=p=>p.n[lg];
const monthName=m=>new Date(2000,m-1,1).toLocaleString(lg,{month:"short"});
const toURL=b=>new Promise(r=>{const f=new FileReader();f.onload=()=>r(f.result);f.readAsDataURL(b)});

/* ---------- AI ---------- */
const ctxLine=()=>{const a=[];if(cfg.place)a.push("User location: "+cfg.place);if(wx)a.push(`Current weather ${wx.t}°C, humidity ${wx.h}%`);if(farm.length)a.push("User is growing: "+[...new Set(farm.map(f=>P[f.i].n.en))].join(", "));return a.join(". ")};
const SYS=()=>`You are Agrinova, an expert agronomist and plant pathologist assistant inside a mobile app. Always reply in ${L[lg].n}. Be practical and concise, give quantities and timings when useful, prefer organic/low-risk solutions first, state uncertainty honestly, and when you list chemical products remind the user to follow the label and local regulations and wear protection. Only answer farming, gardening and plant topics. ${ctxLine()}`;
const endpoint=()=>(cfg.url||AI_ENDPOINT||"").trim().replace(/\/+$/,"");
async function ai(msgs,blob,on,opt={}){
 const s=window.claude&&await claude.use("sample");
 if(s){const o={onText:r=>on&&on(r.text),cache:false};if(blob&&(await s.limits()).images)o.images=[blob];
  const m=msgs.map((x,i)=>i?x:{role:x.role,content:(opt.system||SYS())+"\n\n"+x.content});return (await s(m,o)).text}
 const u=endpoint();if(!u)return offlineAI(msgs,on);
 const b64=blob?(await toURL(blob)).split(",")[1]:null,ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),90000);
 try{
  const r=await fetch(u+"/",{method:"POST",signal:ctl.signal,headers:{"Content-Type":"application/json",...(cfg.token?{Authorization:"Bearer "+cfg.token}:{})},body:JSON.stringify({system:opt.system||SYS(),messages:msgs,image:b64,max_tokens:opt.max||1200})});
  const j=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(j.text||"HTTP "+r.status);
  on&&on(j.text);return j.text;
 }finally{clearTimeout(to)}
}
const errText=e=>e.message=="noai"?t("noai"):t("err")+(e.message&&e.name!="AbortError"?"\n("+e.message.slice(0,120)+")":"");
function shrink(f,m=1024,q=.85){return new Promise(r=>{const i=new Image();i.onload=()=>{const k=Math.min(1,m/Math.max(i.width,i.height)),c=document.createElement("canvas");c.width=i.width*k;c.height=i.height*k;c.getContext("2d").drawImage(i,0,0,c.width,c.height);c.toBlob(r,"image/jpeg",q)};i.src=URL.createObjectURL(f)})}

/* ---------- Chat ---------- */
function addMsg(cls,s){const d=document.createElement("div");d.className="m "+cls;d.innerHTML=fmt(s);$("msgs").appendChild(d);d.scrollIntoView({block:"end"});return d}
async function ask(text){if(busy||!text.trim())return;busy=true;show(2);addMsg("u",text);hist.push({role:"user",content:text});const d=addMsg("a",t("wait"));
 try{const r=await ai(hist.slice(-8),null,x=>d.innerHTML=fmt(x));hist.push({role:"assistant",content:r});d.innerHTML=fmt(r)}catch(e){d.textContent=errText(e);hist.pop()}
 hist=hist.slice(-40);sv("hist",hist);busy=false}
function drawChat(){$("msgs").innerHTML="";hist.forEach(m=>addMsg(m.role=="user"?"u":"a",m.content))}

/* ---------- Scan (plant ID + diagnosis) ---------- */
const HC={healthy:"#2e9e5b",mild:"#d9a400",moderate:"#e6751a",severe:"#d23a3a"};
const scanPrompt=()=>`You are a plant pathologist. Analyse the photo: identify the plant, judge its health, and list every visible problem (disease, pest, nutrient deficiency, environmental stress, weed). Reply with ONLY one JSON object, no markdown, in this exact shape:
{"is_plant":true,"plant":{"name":"common name","scientific":"Latin name"},"health":"healthy|mild|moderate|severe","confidence":0-100,"issues":[{"name":"","type":"fungal|bacterial|viral|pest|nutrient|environmental|weed|other","symptoms":"what is visible and what else to check","cause":"","organic":["step"],"chemical":["active ingredient class, follow label"],"prevention":["step"],"urgency":"now|week|monitor"}],"care":"one or two sentences of general care for this plant","note":""}
If healthy, use an empty issues list. If the image is not a plant or too unclear, set is_plant false and explain in note. Write every text value in ${L[lg].n}; keep JSON keys and the enum values in English.`;
function pj(s){const m=String(s).match(/\{[\s\S]*\}/);if(!m)return null;try{return JSON.parse(m[0])}catch(e){return null}}
const lst=(h,a)=>a.length?`<h4>${h}</h4><ul>${a.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`:"";
function scanHTML(r){
 if(r.is_plant===false)return `<b>${t("notplant")}</b><br>${esc(r.note||"")}`;
 const h=HC[r.health]?r.health:"mild",c=Math.max(0,Math.min(100,Math.round(+r.confidence||0)));
 let o=`<div class="rh"><div><b class="pn">${esc(r.plant?.name||"?")}</b><div class="sci">${esc(r.plant?.scientific||"")}</div></div><span class="bd" style="background:${HC[h]}">${t(h)}</span></div><div class="bar"><i style="width:${c}%"></i></div><small>${t("conf")}: ${c}%</small>`;
 arr(r.issues).forEach(s=>{o+=`<div class="iss"><div class="it"><b>${esc(s.name)}</b><span><span class="ty">${esc(tt("ty_",s.type))}</span> ${s.urgency&&X["u_"+s.urgency]?`<span class="ur">${t("u_"+s.urgency)}</span>`:""}</span></div>
  ${s.symptoms?`<h4>${t("sym")}</h4><p>${esc(s.symptoms)}</p>`:""}${s.cause?`<h4>${t("cause")}</h4><p>${esc(s.cause)}</p>`:""}${lst(t("org"),arr(s.organic))}${lst(t("chem"),arr(s.chemical))}${lst(t("prev"),arr(s.prevention))}</div>`});
 if(r.care)o+=`<h4 style="color:var(--g);margin:12px 0 2px">${t("careT")}</h4><p style="color:var(--ink)">${esc(r.care)}</p>`;
 if(r.note)o+=`<p>${esc(r.note)}</p>`;return o}
const findPlant=nm=>{nm=String(nm||"").toLowerCase().trim();return nm?P.findIndex(p=>Object.values(p.n).some(v=>v.toLowerCase()==nm)):-1};
function scanActs(r,srcImg){const a=$("acts");a.innerHTML="";if(!r||r.is_plant===false)return;
 const pi=findPlant(r.plant?.name),sumTxt=`${r.plant?.name||""}: ${arr(r.issues).map(i=>i.name).join(", ")||t("healthy")}`;
 const add=(l,f)=>{const b=document.createElement("button");b.textContent=l;b.onclick=f;a.appendChild(b)};
 if(pi>=0)add("📖 "+t("openguide"),()=>{show(3);openPlant(pi)});
 add("💬 "+t("followup"),()=>{show(2);$("q").value=sumTxt+" — ";$("q").focus()});
 add("📤 "+t("share"),async()=>{const txt=`Agrinova — ${sumTxt}\n`+arr(r.issues).map(i=>`• ${i.name}: ${arr(i.organic).join("; ")}`).join("\n");try{navigator.share?await navigator.share({text:txt}):await navigator.clipboard.writeText(txt)}catch(e){}})}
async function runScan(){const r=$("res");r.style.display="block";if(!img){if(offlineOn())return offlineScan();r.textContent=t("nopic");return}if(offlineOn()){const picked=[...document.querySelectorAll("#sy input:checked")].length>0;if(picked){offlineScan();const n=document.createElement("p");n.className="warn";n.textContent=lg=="ar"?"ملاحظة: النتيجة مبنية على الأعراض التي اخترتها، وليست قراءة آلية للصورة. لتشخيص الصورة مباشرة اربط خادم AI من الإعدادات.":"Note: this result uses your selected symptoms, not automatic image recognition. Connect an AI server for image diagnosis.";r.appendChild(n);}else{r.textContent=lg=="ar"?"الصورة جاهزة، لكن التعرف التلقائي عليها يحتاج خادم ذكاء اصطناعي. اختر الأعراض الظاهرة للحصول على فرز أولي دون إنترنت، أو اربط الخادم لتشخيص الصورة.":"Photo ready. Automatic image recognition requires an AI server. Select visible symptoms for offline symptom-based screening, or connect the server for image diagnosis.";}return}if(busy)return;busy=true;r.textContent=t("wait");$("acts").innerHTML="";
 try{const raw=await ai([{role:"user",content:scanPrompt()}],img,null,{max:1800}),j=pj(raw);
  if(j){r.innerHTML=scanHTML(j);scanActs(j);lastScan=j;
   if(j.is_plant!==false){const th=await toURL(await shrink(img,160,.6));scans.unshift({id:Date.now(),th,r:j});scans=scans.slice(0,25);try{sv("scans",scans)}catch(e){}}}
  else r.innerHTML=fmt(raw)}catch(e){r.textContent=errText(e)}busy=false}
async function pick(f){if(!f)return;try{stopCamera();if(!f.type||!f.type.startsWith("image/"))throw new Error("not-image");img=await shrink(f);if(!img)throw new Error("image-read");$("prev").src=URL.createObjectURL(img);$("prev").style.display="block";$("res").style.display="none";$("acts").innerHTML="";$("camStatus").textContent=lg=="ar"?"تم تحميل الصورة بنجاح.":"Image loaded successfully.";}catch(e){$("camStatus").textContent=lg=="ar"?"لم نتمكن من قراءة الصورة. جرّب صورة أخرى.":"Could not read this image. Try another photo.";}}

/* ---------- Plants guide ---------- */
const mon=()=>{let m=new Date().getMonth()+1;if(cfg.lat<0)m=(m+5)%12+1;return m};
const inSow=p=>{const f=F[p.n.en];if(!f||p.c=="house")return false;const[a,b]=f.m.split("-").map(Number),m=mon();return a<=b?m>=a&&m<=b:m>=a||m<=b};
function drawPlants(){const T=L[lg],q=$("srch").value.toLowerCase();
 $("chips").innerHTML=["all","now",...Object.keys(T.cat)].map(k=>`<button class="chip ${k==cat?"on":""}" data-c="${k}">${k=="all"?T.all:k=="now"?"🗓️ "+t("sownow"):T.cat[k]}</button>`).join("");
 $("plist").innerHTML=P.map((p,i)=>[p,i]).filter(([p])=>(cat=="all"||(cat=="now"?inSow(p):p.c==cat))&&Object.values(p.n).some(v=>v.toLowerCase().includes(q))).map(([p,i])=>`<button class="pl" data-i="${i}"><span>${esc(plantName(p))}</span><small>${T.cat[p.c]}</small></button>`).join("")}
function openPlant(i){const p=P[i],T=L[lg],f=F[p.n.en]||{},e=$("pd");e.style.display="block";
 const [a,b]=(f.m||"1-12").split("-").map(Number),rows=[["f_days",f.d?f.d+" "+t("days"):t("perennial")],["f_temp",f.t+"°C"],["f_water",t("w"+f.w)],["f_sun",t("s"+f.s)],["f_ph",f.ph],["f_sow",a==b?monthName(a):monthName(a)+" → "+monthName(b)]];
 const today=new Date().toISOString().slice(0,10);
 e.innerHTML=`<h2>${esc(plantName(p))}</h2><p>${T.cat[p.c]}${p.n.en!=plantName(p)?" · "+esc(p.n.en):""}</p><div class="facts">${rows.map(r=>`<div><small>${t(r[0])}</small>${esc(r[1])}</div>`).join("")}</div><p style="font-size:11px">${t("sowNote")}</p><p style="color:var(--ink)">${T.care[p.c]}</p>
 <div class="sec2"><button id="pg">${T.guide}</button><button id="pp" class="ghost">${t("probs")}</button><div class="row2"><input type="date" id="pdt" value="${today}"><button id="pa" style="flex:none">${t("addfarm")}</button></div></div>`;
 $("pg").onclick=()=>ask({ar:`أعطني دليل زراعة كامل لنبات ${p.n.ar}: الموسم والتربة والري والتسميد وأهم الآفات والأمراض والحصاد.`,en:`Give me a complete growing guide for ${p.n.en}: season, soil, watering, fertilising, main pests and diseases, harvest.`,de:`Gib mir einen vollständigen Anbauleitfaden für ${p.n.de}: Saison, Boden, Gießen, Düngung, wichtigste Schädlinge und Krankheiten, Ernte.`,fr:`Donne-moi un guide de culture complet pour ${p.n.fr} : saison, sol, arrosage, fertilisation, principaux ravageurs et maladies, récolte.`}[lg]);
 $("pp").onclick=()=>ask({ar:`ما أهم الأمراض والآفات التي تصيب ${p.n.ar}؟ لكل مشكلة: الأعراض وطريقة العلاج العضوي ثم الكيميائي والوقاية.`,en:`What are the most important diseases and pests of ${p.n.en}? For each: symptoms, organic then chemical treatment, and prevention.`,de:`Welche Krankheiten und Schädlinge sind bei ${p.n.de} am wichtigsten? Je Problem: Symptome, biologische dann chemische Behandlung, Vorbeugung.`,fr:`Quelles sont les principales maladies et ravageurs de ${p.n.fr} ? Pour chacun : symptômes, traitement biologique puis chimique, prévention.`}[lg]);
 $("pa").onclick=()=>addPlanting(i,$("pdt").value||today);e.scrollIntoView({behavior:"smooth"})}

/* ---------- My farm ---------- */
const harvestAt=f=>{const d=F[P[f.i].n.en].d;return d?new Date(new Date(f.date).getTime()+d*864e5):null};
async function notify(id,title,body,at){try{const N=window.Capacitor?.Plugins?.LocalNotifications;if(!N||at<Date.now())return;await N.requestPermissions();await N.schedule({notifications:[{id,title,body,schedule:{at}}]})}catch(e){}}
function addPlanting(i,date){const f={id:Date.now()%2e9,i,date};farm.push(f);sv("farm",farm);const h=harvestAt(f);if(h){h.setHours(8,0,0,0);notify(f.id,"🌾 Agrinova",P[i].n[lg]+" — "+t("harvest"),h)}
 drawFarm();drawUp();show(4)}
function upRows(){return farm.map(f=>({f,h:harvestAt(f)})).filter(x=>x.h).sort((a,b)=>a.h-b.h)}
const upHTML=rows=>rows.map(({f,h})=>{const dd=Math.ceil((h-Date.now())/864e5);return `<div class="card" style="margin-top:8px"><b>${esc(plantName(P[f.i]))}</b> <small style="color:var(--mut)">${t("harvest")}: ${h.toLocaleDateString(lg)} (${dd>0?dd+" "+t("days"):"✓"})</small></div>`}).join("");
function drawUp(){const r=upRows().slice(0,3);$("up").innerHTML=r.length?`<h2>${t("upcoming")}</h2>${upHTML(r)}<div style="height:12px"></div>`:""}
function drawFarm(){$("mp").textContent=t("myplants");$("hh").textContent=t("hist");
 $("farm").innerHTML=farm.length?farm.map(f=>{const p=P[f.i],h=harvestAt(f),tot=F[p.n.en].d*864e5,pc=h?Math.max(0,Math.min(100,(Date.now()-new Date(f.date))/tot*100)):0;
  return `<div class="card" style="margin-top:8px"><div class="row2"><b>${esc(plantName(p))}</b><button class="x" data-rm="${f.id}">${t("remove")}</button></div><small style="color:var(--mut)">${t("planted")}: ${new Date(f.date).toLocaleDateString(lg)}${h?" · "+t("harvest")+": "+h.toLocaleDateString(lg):" · "+t("perennial")}</small>${h?`<div class="pr"><i style="width:${pc}%"></i></div>`:""}
  <div class="acts"><button data-ask="${f.i}">💬 ${t("followup")}</button></div></div>`}).join(""):`<p>${t("empty")}</p>`;
 $("hl").innerHTML=scans.length?scans.map(s=>`<button class="hi" data-sc="${s.id}"><img src="${s.th}" alt=""><span>${esc(s.r.plant?.name||"?")}<small>${t(HC[s.r.health]?s.r.health:"mild")} · ${arr(s.r.issues).map(i=>esc(i.name)).join(", ")||"—"}</small></span></button>`).join(""):`<p>${t("empty")}</p>`}

/* ---------- Weather & climate alerts (Open-Meteo, no key) ---------- */
async function fetchWx(){if(cfg.lat==null)return drawWx();
 try{const u=`https://api.open-meteo.com/v1/forecast?latitude=${cfg.lat}&longitude=${cfg.lon}&current=temperature_2m,relative_humidity_2m&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,et0_fao_evapotranspiration,wind_speed_10m_max&timezone=auto&forecast_days=7`;
  const j=await (await fetch(u)).json(),d=j.daily;wx={t:Math.round(j.current.temperature_2m),h:j.current.relative_humidity_2m,max:d.temperature_2m_max,min:d.temperature_2m_min,rain:d.precipitation_sum,et:d.et0_fao_evapotranspiration,wind:d.wind_speed_10m_max,at:Date.now()};sv("wx",wx)}catch(e){}
 drawWx();calc()}
function alerts(){const a=[],w=wx;if(!w)return a;
 if(Math.min(...w.min)<=2)a.push("al_frost");if(Math.max(...w.max)>=36)a.push("al_heat");if(Math.max(...w.wind)>=40)a.push("al_wind");if(Math.max(...w.rain)>=25)a.push("al_rain");
 if(sum(w.rain)<5&&sum(w.et)>20)a.push("al_dry");if(w.h>=85&&w.t>=15&&w.t<=28)a.push("al_fungal");return a}
function drawWx(){const e=$("wx");
 if(!wx){e.innerHTML=`<b>🌦️ ${t("wxT")}</b><p>${t("setloc")}</p><button id="wset" style="width:100%">${t("useloc").replace("📍 ","📍 ")}</button>`;$("wset").onclick=()=>show(7);return}
 const al=alerts();e.innerHTML=`<div class="top"><div><b>🌦️ ${t("wxT")}</b><br><small>${esc(cfg.place||"")}</small></div><div class="big">${wx.t}°</div></div>
 <small>💧 ${wx.h}% · ↑${Math.round(wx.max[0])}° ↓${Math.round(wx.min[0])}° · ${t("rain7")}: ${Math.round(sum(wx.rain))} mm · ${t("et7")}: ${Math.round(sum(wx.et))} mm</small>
 ${(al.length?al:["al_ok"]).map(k=>`<div class="al ${k=="al_ok"?"":"w"}">${t(k)}</div>`).join("")}`}

/* ---------- Calculators ---------- */
function calc(){const A=+$("ia").value||0,kc=KC[$("ic").value]||1,ef=[.9,.75,.55][+$("im").value||0],et=+$("ie").value||0,rain=wx?sum(wx.rain)/7:0;
 const need=Math.max(0,et*kc-rain*.8)*A/ef;$("r1").textContent=`${Math.round(need).toLocaleString(lg)} ${t("u_ld")} · ${(need*7/1000).toFixed(1)} ${t("u_m3")}`;
 const pct=+$("fp").value||0;$("r2").textContent=pct>0?`${((+$("fr").value||0)*(+$("fa").value||0)/1e4/(pct/100)).toFixed(2)} ${t("u_kg")}`:"—";
 const cell=(+$("sr").value||0)*(+$("sp").value||0)/1e4;$("r3").textContent=cell>0?`${Math.floor((+$("sa").value||0)/cell).toLocaleString(lg)} ${t("u_pl")}`:"—"}
function drawCalc(){const T=L[lg];$("ct").textContent=t("calcT");$("c1").textContent=t("c_irr");$("c2").textContent=t("c_fert");$("c3").textContent=t("c_seed");
 ["c_area","c_crop","c_meth","c_et","c_area","c_rate","c_pct","c_area","c_row","c_pl"].forEach((k,i)=>$("l"+(i+1)).textContent=t(k));
 const cv=$("ic").value||"veg";$("ic").innerHTML=Object.keys(KC).map(k=>`<option value="${k}">${T.cat[k]}</option>`).join("");$("ic").value=cv;
 const mv=$("im").value||"0";$("im").innerHTML=[0,1,2].map(i=>`<option value="${i}">${t("m"+(i+1))}</option>`).join("");$("im").value=mv;
 if(wx&&!$("ie").dataset.u)$("ie").value=(sum(wx.et)/7).toFixed(1);$("cn").textContent=t("calcNote");calc()}

/* ---------- Disease library (offline) ---------- */
function drawDis(){const q=$("ds").value.toLowerCase(),k=dl(lg);$("dt").textContent="📚 "+t("dis_t");$("dn").textContent="📶 "+t("dis_off");$("ds").placeholder=t("dis_s");$("w6").textContent=L[lg].warn;
 $("dl").innerHTML=DIS.filter(d=>!q||Object.values(d.n).some(v=>v.toLowerCase().includes(q))).map(d=>`<details><summary>${d.i} ${esc(d.n[k])} <span class="ty">${esc(tt("ty_",d.ty))}</span></summary><h4>${t("sym")}</h4><p>${esc(d.s[k])}</p><h4>${t("org")}</h4><p>${esc(d.t[k])}</p><h4>${t("prev")}</h4><p>${esc(d.p[k])}</p><div class="acts"><button data-dq="${d.id}">💬 ${t("followup")}</button></div></details>`).join("")}

/* ---------- Settings ---------- */
function drawSet(){$("st").textContent="⚙️ "+t("set_t");$("k1").textContent=t("url");$("k2").textContent=t("token");$("su").value=cfg.url||"";$("sk").value=cfg.token||"";$("ss").textContent=t("save");$("stt").textContent=t("test");
 $("cq").placeholder=t("city");$("cb").textContent="🔍";$("gl").textContent=t("useloc");$("clr").textContent=t("clear");$("pl").textContent=cfg.place?"📍 "+cfg.place:""}
const setLoc=(la,lo,pl)=>{cfg={...cfg,lat:la,lon:lo,place:pl};sv("cfg",cfg);$("pl").textContent="📍 "+pl;$("cr").innerHTML="";fetchWx()};

/* ---------- Advanced features: each tool has its own dedicated card ---------- */
const EXTRA_FEATURES=[
 {id:11,icon:"🌿",n:{ar:"التعرّف على النباتات",en:"AI Plant Identification",de:"KI-Pflanzenerkennung",fr:"Identification des plantes par IA"},d:{ar:"تعرّف على اسم النبات والمحصول من صورة، مع الاسم العلمي ومعلومات أساسية.",en:"Identify a plant or crop from a photo, with its scientific name and basic information.",de:"Pflanzen und Nutzpflanzen anhand eines Fotos mit wissenschaftlichem Namen erkennen.",fr:"Identifier une plante ou une culture à partir d’une photo et obtenir son nom scientifique."},q:"Identify the plant in a photo and provide its common and scientific names, distinguishing features and basic growing needs."},
 {id:12,icon:"🐛",n:{ar:"كاشف الآفات والحشرات",en:"AI Pest Detector",de:"KI-Schädlingsdetektor",fr:"Détecteur de ravageurs par IA"},d:{ar:"تحليل صورة الحشرة أو أثرها على النبات، وشرح الاحتمالات وطرق المكافحة الآمنة.",en:"Analyse an insect or its damage on a plant and explain likely causes and safer control options.",de:"Insekten oder Fraßspuren analysieren und mögliche Ursachen sowie sichere Maßnahmen erklären.",fr:"Analyser un insecte ou ses dégâts et proposer des moyens de lutte adaptés."},q:"Help identify the pest from the photo, explain visible evidence, confidence and integrated pest-management steps. Do not recommend pesticide use without confirming the pest."},
 {id:13,icon:"🧪",n:{ar:"مستشار الأسمدة الذكي",en:"Smart Fertilizer Advisor",de:"Intelligente Düngeberatung",fr:"Conseiller intelligent en fertilisation"},d:{ar:"تقدير احتياجات النبات الغذائية بالاعتماد على المحصول والأعراض ونتائج تحليل التربة.",en:"Estimate crop nutrient needs using crop type, symptoms and soil-test results.",de:"Nährstoffbedarf anhand von Kultur, Symptomen und Bodenanalyse einschätzen.",fr:"Estimer les besoins nutritifs selon la culture, les symptômes et l’analyse du sol."},q:"Act as a fertilizer advisor. Ask for missing crop, growth stage, soil test and area details; explain nutrient diagnosis and safe, locally verified recommendations."},
 {id:14,icon:"🛰️",n:{ar:"مراقبة المزرعة بالأقمار الصناعية",en:"Satellite Farm Monitoring",de:"Satellitenüberwachung von Feldern",fr:"Suivi agricole par satellite"},d:{ar:"شرح كيفية متابعة الغطاء النباتي وتغيرات الحقول بصور الأقمار الصناعية عند توفر مصدر بيانات.",en:"Monitor vegetation and field changes using satellite imagery when a data provider is connected.",de:"Vegetation und Feldveränderungen mit Satellitenbildern überwachen, sofern Daten verfügbar sind.",fr:"Suivre la végétation et les changements des parcelles lorsque des données satellite sont disponibles."},q:"Explain how to monitor my field with satellite imagery. Ask for location and field size, describe suitable indices such as NDVI, and clearly state that live satellite data requires a connected provider."},
 {id:15,icon:"🗓️",n:{ar:"تقويم الزراعة الذكي",en:"Smart Farming Calendar",de:"Intelligenter Anbaukalender",fr:"Calendrier agricole intelligent"},d:{ar:"إنشاء جدول لمواعيد الزراعة والري والتسميد والمتابعة والحصاد حسب منطقتك.",en:"Build a schedule for planting, irrigation, fertilizing, monitoring and harvesting for your location.",de:"Zeitplan für Aussaat, Bewässerung, Düngung, Kontrolle und Ernte erstellen.",fr:"Créer un calendrier de semis, d’irrigation, de fertilisation, de suivi et de récolte."},q:"Create a practical crop calendar for my location. Ask for crop, variety, planting date and region; give dated tasks and explain local-climate uncertainty."},
 {id:16,icon:"🔄",n:{ar:"مخطط تدوير المحاصيل",en:"Crop Rotation Planner",de:"Fruchtfolgeplaner",fr:"Planificateur de rotation des cultures"},d:{ar:"اقتراح تسلسل محاصيل يساعد على تنويع الزراعة وتقليل استنزاف التربة وتراكم بعض الآفات.",en:"Suggest crop sequences to diversify production and reduce soil depletion and pest carryover.",de:"Fruchtfolgen zur Diversifizierung und zur Verringerung von Bodenerschöpfung und Schädlingsdruck planen.",fr:"Proposer des rotations pour diversifier les cultures et limiter l’épuisement du sol et certains ravageurs."},q:"Design a crop rotation plan. Ask what was grown previously, soil type, irrigation and region; explain the reason for each crop sequence."},
 {id:17,icon:"🍎",n:{ar:"فاحص جودة المحاصيل",en:"AI Crop Quality Scanner",de:"KI-Erntequalitätsprüfung",fr:"Analyse IA de la qualité des récoltes"},d:{ar:"فحص العيوب الظاهرة في الثمار والمنتجات من الصور، دون ادعاء كشف التلف الداخلي غير المرئي.",en:"Inspect visible defects in produce photos without claiming to detect hidden internal damage.",de:"Sichtbare Mängel auf Produktfotos prüfen, ohne unsichtbare innere Schäden zu behaupten.",fr:"Examiner les défauts visibles sur les photos sans prétendre détecter les dommages internes."},q:"Inspect the visible quality of this crop or fruit photo. Describe visible defects, limitations, and handling or sorting suggestions; do not infer hidden contamination."},
 {id:18,icon:"💹",n:{ar:"أسعار المحاصيل العالمية",en:"Global Crop Prices",de:"Globale Agrarpreise",fr:"Prix agricoles mondiaux"},d:{ar:"مقارنة أسعار المحاصيل في الأسواق عند ربط التطبيق بمصادر أسعار موثوقة ومحدثة.",en:"Compare crop prices when reliable, up-to-date market data sources are connected.",de:"Agrarpreise vergleichen, sofern zuverlässige aktuelle Marktdaten angebunden sind.",fr:"Comparer les prix agricoles lorsque des sources de marché fiables et à jour sont connectées."},q:"Help me compare market prices for my crop. Ask for crop, grade, quantity, market and date; distinguish estimates from verified live prices."},
 {id:19,icon:"⛈️",n:{ar:"إنذار المخاطر الزراعية",en:"Agricultural Disaster Alerts",de:"Warnungen vor Agrarrisiken",fr:"Alertes sur les risques agricoles"},d:{ar:"تجميع إرشادات الاستعداد لمخاطر الصقيع والحرارة والجفاف والفيضانات والرياح.",en:"Prepare for frost, heat, drought, flooding and wind risks using local forecasts.",de:"Auf Frost, Hitze, Dürre, Überschwemmungen und Wind anhand lokaler Vorhersagen vorbereiten.",fr:"Se préparer au gel, à la chaleur, à la sécheresse, aux inondations et au vent selon les prévisions locales."},q:"Create an agricultural risk-preparedness checklist for my crop and region, covering heat, frost, drought, heavy rain and wind. Do not claim a live warning unless current forecast data is available."},
 {id:20,icon:"🚜",n:{ar:"إدارة المعدات الزراعية",en:"Farm Equipment Manager",de:"Landmaschinenverwaltung",fr:"Gestion du matériel agricole"},d:{ar:"تنظيم المعدات وساعات التشغيل ومواعيد الصيانة والفحص الدوري.",en:"Organize equipment, operating hours, maintenance dates and routine inspections.",de:"Maschinen, Betriebsstunden, Wartungstermine und regelmäßige Prüfungen verwalten.",fr:"Organiser le matériel, les heures d’utilisation, l’entretien et les inspections."},q:"Build an equipment maintenance log and schedule. Ask what equipment I own, usage hours and last service date."},
 {id:21,icon:"♻️",n:{ar:"مؤشر الزراعة المستدامة",en:"Eco Farming Score",de:"Nachhaltigkeitsbewertung",fr:"Indice d’agriculture durable"},d:{ar:"تقييم ممارسات توفير المياه والطاقة وتقليل الفاقد وتحسين صحة التربة.",en:"Review water and energy efficiency, waste reduction and soil-health practices.",de:"Wasser- und Energieeffizienz, Abfallvermeidung und Bodengesundheit bewerten.",fr:"Évaluer l’efficacité de l’eau et de l’énergie, la réduction des pertes et la santé des sols."},q:"Assess my farm's sustainability practices. Ask about water, energy, soil, inputs and waste; provide a transparent score with reasons and improvement steps."},
 {id:22,icon:"🎙️",n:{ar:"المساعد الزراعي الصوتي",en:"Agrinova Voice Assistant",de:"Sprachassistent für Landwirtschaft",fr:"Assistant agricole vocal"},d:{ar:"التحدث مع المستشار الزراعي بالصوت؛ يتطلب دعم تحويل الصوت إلى نص في الجهاز أو إضافة خدمة صوتية.",en:"Talk to the farming assistant using speech-to-text supported by the device or a connected voice service.",de:"Mit dem Assistenten sprechen, sofern Geräte-Spracherkennung oder ein Sprachdienst verfügbar ist.",fr:"Parler à l’assistant grâce à la reconnaissance vocale de l’appareil ou à un service vocal connecté."},q:"Help me use a voice-first farming workflow. Explain how to ask a farming question clearly and provide a concise spoken-style answer."}
];
function drawFeatures(){const title={ar:"ميزات Agrinova المتقدمة",en:"Agrinova Advanced Features",de:"Erweiterte AI-Farming-Funktionen",fr:"Fonctionnalités avancées Agrinova"};const intro={ar:"كل ميزة في بطاقة مستقلة. بعض الوظائف تحتاج اتصالًا بمصادر بيانات أو خدمات خارجية قبل أن تقدم نتائج مباشرة.",en:"Each feature has its own card. Some features require connected data providers or external services for live results.",de:"Jede Funktion hat eine eigene Karte. Einige benötigen Datenanbieter oder externe Dienste für Live-Ergebnisse.",fr:"Chaque fonction possède sa propre carte. Certaines nécessitent des fournisseurs de données ou des services externes."};
 $("featureTitle").textContent="🌍 "+title[lg];$("featureIntro").textContent=intro[lg];
 $("featureGrid").innerHTML=EXTRA_FEATURES.map(f=>`<article class="feature-card"><div class="fhead"><span class="ficon">${f.icon}</span><h3>${esc(f.n[lg])}</h3></div><p>${esc(f.d[lg])}</p><button data-feature="${f.id}">${lg=="ar"?"افتح الميزة":lg=="de"?"Funktion öffnen":lg=="fr"?"Ouvrir la fonction":"Open feature"}</button></article>`).join("");
}
let activeFeature=null,featureBlob=null;
function openFeature(id){const f=EXTRA_FEATURES.find(x=>x.id===id);if(!f)return;activeFeature=f;featureBlob=null;
 show(11);$("featureWorkIcon").textContent=f.icon;$("featureWorkTitle").textContent=f.n[lg];$("featureWorkDesc").textContent=f.d[lg];
 $("featureInput").value="";$("featureImage").value="";$("featureOutput").innerHTML="";$("featureStatus").textContent="";
 $("featureInput").placeholder=lg=="ar"?"اكتب تفاصيل المحصول أو المشكلة أو البيانات المتاحة...":"Enter crop, problem, location or available measurements...";
 $("featureRun").textContent=lg=="ar"?"حلّل البيانات":"Run analysis";
 $("featureInputLabel").textContent=lg=="ar"?"بيانات المزرعة / السؤال":"Farm details / question";
 $("featureImageLabel").textContent=lg=="ar"?"أرفق صورة (اختياري للميزات البصرية)":"Attach a photo (optional for visual tools)";
 $("featureDisclaimer").textContent=lg=="ar"?"النتائج تعتمد على البيانات المدخلة. الأسعار والأقمار الصناعية والتحذيرات المباشرة لا تُعرض كبيانات حية إلا عند ربط مصدر موثوق.":"Results depend on the information supplied. Live prices, satellite imagery and alerts require verified data providers.";
}
async function runFeature(){if(!activeFeature||busy)return;const details=$("featureInput").value.trim();if(!details&&!featureBlob){$("featureStatus").textContent=lg=="ar"?"اكتب بيانات أو أرفق صورة أولاً.":"Enter details or attach a photo first.";return;}
 if(offlineOn()){ $("featureOutput").textContent=lg=="ar"?"هذه الميزة تحتاج اتصالاً بخادم الذكاء الاصطناعي لتنفيذ التحليل المخصص. يمكنك إضافة رابط الخادم من الإعدادات. لن نعرض نتيجة تخمينية على أنها تحليل حقيقي.":"This feature needs a connected AI server for its tailored analysis. Add the server URL in Settings. No guessed result will be presented as a real analysis.";return; }
 busy=true;$("featureRun").disabled=true;$("featureStatus").textContent=t("wait");$("featureOutput").textContent="";
 const prompt=`Feature: ${activeFeature.n.en}. Task: ${activeFeature.q}\nUser-provided details: ${details||"No text supplied; analyse the attached image if present."}\nRespond in ${L[lg].n}. Structure the response with: findings, evidence/assumptions, recommended next steps, missing information, and confidence/limitations. Never invent live market, satellite or weather data. If the image is unclear, say so. For pesticide/fertilizer advice, avoid unsupported exact doses and require local label/lab data.`;
 try{const answer=await ai([{role:"user",content:prompt}],featureBlob,x=>$("featureOutput").innerHTML=fmt(x),{max:1800});$("featureOutput").innerHTML=fmt(answer||"");$("featureStatus").textContent=lg=="ar"?"اكتمل التحليل.":"Analysis complete.";}
 catch(e){$("featureOutput").textContent=errText(e);$("featureStatus").textContent=lg=="ar"?"تعذر إكمال التحليل.":"Analysis failed.";}
 finally{busy=false;$("featureRun").disabled=false;}
}

/* ---------- Soil analytics: local calculations + saved history ---------- */
let soilHistory=ld("soilHistory",[]),lastSoil=null;
function soilVal(id){const v=$(id).value.trim();return v===""?null:Number(v)}
function soilAnalyze(){
 const d={date:new Date().toISOString(),crop:$('soilCrop').value.trim(),area:soilVal('soilArea'),ph:soilVal('soilPh'),ec:soilVal('soilEc'),n:soilVal('soilN'),p:soilVal('soilP'),k:soilVal('soilK'),moist:soilVal('soilMoist')};
 const issues=[],notes=[];
 if(d.ph!==null){if(d.ph<5.5)issues.push('التربة حمضية؛ راجع احتياجها للجير الزراعي بناءً على تحليل المعمل.');else if(d.ph>7.8)issues.push('التربة قلوية؛ قد يقل تيسر بعض العناصر الصغرى. افحص مياه الري والعناصر قبل المعالجة.');else notes.push('درجة pH ضمن نطاق شائع لكثير من المحاصيل، لكن النطاق الأمثل يختلف حسب المحصول.');}
 if(d.ec!==null){if(d.ec>=4)issues.push('الملوحة مرتفعة وقد تسبب إجهاداً ملحياً لمحاصيل حساسة؛ يلزم تفسير EC حسب طريقة استخلاص العينة.');else if(d.ec>=2)issues.push('توجد ملوحة تستحق المتابعة، وتختلف خطورتها باختلاف المحصول وطريقة القياس.');else notes.push('قراءة EC المدخلة منخفضة نسبياً وفق حدود استرشادية عامة؛ تحقق من وحدة وطريقة القياس.');}
 [['N',d.n],['P',d.p],['K',d.k]].forEach(([k,v])=>{if(v!==null)notes.push(`${k}: ${v} mg/kg — لا يمكن تصنيفه بدقة دون معرفة طريقة التحليل ونوع التربة والمحصول ومرحلة النمو.`)});
 if(d.moist!==null){if(d.moist<20)issues.push('رطوبة التربة المدخلة منخفضة؛ افحص عمق الجذور ونوع حساس الرطوبة قبل قرار الري.');else if(d.moist>85)issues.push('رطوبة التربة مرتفعة؛ تحقق من الصرف واحتمال تشبع منطقة الجذور.');else notes.push('رطوبة التربة ضمن المجال الوسطي للحساسات الشائعة، لكن عتبة الري تعتمد على نوع التربة والمحصول.');}
 if(!issues.length)issues.push('لم تظهر إشارة تحذير واضحة من القيم المدخلة، وهذا لا يعني أن التربة خالية من المشكلات.');
 lastSoil={...d,issues,notes};
 $('soilResult').innerHTML=`<h3>نتيجة التحليل — ${esc(d.crop||'المزرعة')}</h3><p><b>تاريخ التحليل:</b> ${new Date(d.date).toLocaleDateString(lg)}</p><h4>ملاحظات تحتاج متابعة</h4><ul>${issues.map(x=>`<li>${esc(x)}</li>`).join('')}</ul><h4>قراءات وملاحظات</h4><ul>${notes.map(x=>`<li>${esc(x)}</li>`).join('')}</ul><p class="warn">هذه قراءة فرز أولي وليست تشخيصاً مخبرياً أو جرعة سماد. لا تحسب جرعات NPK من التركيز وحده؛ يلزم تقرير المعمل، المحصول، مرحلة النمو، ومواصفات السماد.</p><button id="soilAskAI" class="ghost">اطلب تفسيراً زراعياً مفصلاً</button>`;
 $('soilAskAI').onclick=()=>{show(2);$('q').value='فسّر نتائج تحليل التربة التالية للمحصول '+(d.crop||'غير محدد')+' والمساحة '+(d.area??'غير محددة')+' فدان. القيم: pH='+d.ph+', EC='+d.ec+', N='+d.n+', P='+d.p+', K='+d.k+', رطوبة='+d.moist+'%. اذكر ما يمكن استنتاجه وما لا يمكن الجزم به، واطلب المعلومات الناقصة قبل تحديد جرعات.';$('q').focus()};
 return lastSoil;
}
function saveSoil(){if(!lastSoil)soilAnalyze();if(!lastSoil)return;soilHistory.unshift({...lastSoil});soilHistory=soilHistory.slice(0,30);sv('soilHistory',soilHistory);drawSoilHistory();$('soilResult').insertAdjacentHTML('beforeend','<p class="res">تم حفظ التحليل على هذا الجهاز.</p>');lastSoil=null}
function drawSoilHistory(){const e=$('soilHistory');if(!e)return;e.innerHTML=soilHistory.length?soilHistory.map((x,i)=>`<details><summary>${esc(x.crop||'مزرعة')} — ${new Date(x.date).toLocaleDateString(lg)}</summary><p>pH: ${x.ph??'—'} | EC: ${x.ec??'—'} | N: ${x.n??'—'} | P: ${x.p??'—'} | K: ${x.k??'—'}</p><button data-soil-open="${i}" class="ghost">عرض التحليل</button></details>`).join(''):'<p>لا توجد تحاليل محفوظة بعد.</p>'}

/* ---------- Navigation & rendering ---------- */
function show(n){if(n!==1)stopCamera();tab=n;document.querySelectorAll("section").forEach((s,i)=>s.classList.toggle("on",i==n));[...$("nav").children].forEach((b,i)=>b.classList.toggle("on",i==n));
 if(n==4){drawFarm()}if(n==5)drawCalc();if(n==6)drawDis();if(n==7)drawSet();if(n==8)drawSol();if(n==9)drawFeatures();if(n==10)drawSoilHistory();scrollTo(0,0)}
function draw(){const T=L[lg];document.documentElement.lang=lg;document.documentElement.dir=T.dir;$("lg").value=lg;$("tag").textContent=T.tag;
 const tl=[...T.tools,t("tl_calc"),t("tl_dis"),t("tl_sow"),t("tl_set")],ic=[...ICON,"🧮","📚","🗓️","⚙️"];
 $("tools").innerHTML=tl.map((x,i)=>`<button class="tile" data-t="${i}"><span>${ic[i]}</span>${x}</button>`).join("")+`<button class="tile sol" data-t="12"><span>🧩</span>${t("tl_sol")}</button><button class="tile sol" data-t="13"><span>🚀</span>${lg=="ar"?"الميزات المتقدمة":lg=="de"?"Erweiterte Funktionen":lg=="fr"?"Fonctions avancées":"Advanced Features"}</button>`;
 $("nav").innerHTML=[...T.tab,t("farm")].map((x,i)=>`<button data-n="${i}"><i>${["🏠","📷","🤖","🌱","🚜"][i]}</i>${x}</button>`).join("");
 $("h1").textContent=H[lg][0];$("h2").textContent=H[lg][1];$("hb1").textContent=T.shot;$("hb2").textContent="🤖 "+T.tab[2];$("t1").textContent=T.t1;$("d1").textContent=T.d1;$("shot").textContent=T.shot;$("gal").textContent=t("gal");$("go").textContent=T.go;
 $("q").placeholder=T.ph;$("send").textContent=T.send;$("srch").placeholder=T.srch;$("w1").textContent=$("w2").textContent=T.warn;$("nc").textContent=t("newchat");$("pd").style.display="none";
 document.querySelectorAll("[data-bk]").forEach(b=>b.textContent=t("back"));
 const bn=$("banner"),off=!endpoint()&&!window.claude;bn.style.display="none";bn.textContent=t("ai_off");
 drawPlants();drawWx();drawUp();drawChat();offUI();show(tab)}

/* ---------- Reliable in-app camera ---------- */
let cameraStream=null;
function stopCamera(){if(cameraStream){cameraStream.getTracks().forEach(track=>track.stop());cameraStream=null;}const v=$("camVideo");if(v)v.srcObject=null;const box=$("camBox");if(box)box.hidden=true;}
async function startCamera(){
 const status=$("camStatus");status.textContent=lg=="ar"?"جارٍ طلب إذن الكاميرا…":lg=="de"?"Kameraberechtigung wird angefordert…":lg=="fr"?"Autorisation de la caméra…":"Requesting camera permission…";
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){status.textContent=lg=="ar"?"الكاميرا المباشرة غير مدعومة هنا؛ سيتم فتح كاميرا الهاتف بالطريقة البديلة.":"Live camera is unavailable; opening the phone camera picker.";$("file").click();return;}
 try{stopCamera();cameraStream=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:"environment"},width:{ideal:1280},height:{ideal:960}}});const v=$("camVideo");v.srcObject=cameraStream;$("camBox").hidden=false;await v.play();status.textContent=lg=="ar"?"الكاميرا جاهزة. وجّهها نحو النبات ثم التقط الصورة.":lg=="de"?"Kamera bereit. Richten Sie sie auf die Pflanze und nehmen Sie ein Foto auf.":lg=="fr"?"Caméra prête. Cadrez la plante puis prenez la photo.":"Camera ready. Point it at the plant and capture a photo.";}
 catch(err){stopCamera();const msg=err&&err.name==="NotAllowedError"?(lg=="ar"?"تم رفض إذن الكاميرا. اسمح للتطبيق باستخدام الكاميرا من إعدادات الهاتف ثم حاول مجددًا.":"Camera permission was denied. Allow camera access in phone settings and try again."):(lg=="ar"?"تعذر تشغيل الكاميرا: ":"Could not start camera: ")+(err&&err.message?err.message:"");status.textContent=msg;try{$("file").click()}catch(e){}}
}
async function captureCamera(){const v=$("camVideo");if(!v.videoWidth){$("camStatus").textContent=lg=="ar"?"انتظر حتى تظهر صورة الكاميرا.":"Wait for the camera preview.";return;}const c=document.createElement("canvas");c.width=v.videoWidth;c.height=v.videoHeight;c.getContext("2d").drawImage(v,0,0,c.width,c.height);const blob=await new Promise(resolve=>c.toBlob(resolve,"image/jpeg",.9));if(!blob){$("camStatus").textContent=lg=="ar"?"فشل التقاط الصورة.":"Could not capture image.";return;}stopCamera();await pick(new File([blob],"plant-photo.jpg",{type:"image/jpeg"}));$("camStatus").textContent=lg=="ar"?"تم التقاط الصورة. اضغط تشخيص النبات.":"Photo captured. Tap Diagnose.";}

/* ---------- Events ---------- */
$("lg").onchange=e=>{lg=e.target.value;sv("lg",lg);draw()};
$("nav").onclick=e=>{const b=e.target.closest("button");if(b)show(+b.dataset.n)};
document.body.addEventListener("click",e=>{if(e.target.closest("[data-bk]"))show(0)});
$("banner").onclick=()=>show(7);
$("tools").onclick=e=>{const b=e.target.closest("button");if(!b)return;const i=+b.dataset.t;
 if(i<8){if(offlineOn())ask(L[lg].tools[i]);else{show(2);$("q").value=L[lg].tools[i]+": ";$("q").focus()}}else if(i==8)show(5);else if(i==9)show(6);else if(i==10){cat="now";show(3);drawPlants()}else if(i==12)show(8);else if(i==13)show(9);else if(i==14)show(10);else show(7)};
$("featureGrid").onclick=e=>{const b=e.target.closest("[data-feature]");if(b)openFeature(+b.dataset.feature)};
$("chips").onclick=e=>{const b=e.target.closest("button");if(b){cat=b.dataset.c;drawPlants()}};
$("plist").onclick=e=>{const b=e.target.closest("button");if(b)openPlant(+b.dataset.i)};
$("srch").oninput=drawPlants;
$("send").onclick=()=>{const v=$("q").value;$("q").value="";ask(v)};$("q").onkeydown=e=>{if(e.key=="Enter")$("send").click()};
$("nc").onclick=()=>{hist=[];sv("hist",hist);drawChat()};
$("shot").onclick=()=>{$("camStatus").textContent=lg=="ar"?"افتح كاميرا الهاتف والتقط صورة للنبات.":"Use your phone camera to take a plant photo.";$("file").click()};$("capture").onclick=captureCamera;$("closeCam").onclick=stopCamera;$("gal").onclick=()=>$("file2").click();$("hb1").onclick=()=>{show(1);$("file").click()};$("hb2").onclick=()=>show(2);
$("file").onchange=e=>{pick(e.target.files[0]);e.target.value=""};$("file2").onchange=e=>{pick(e.target.files[0]);e.target.value=""};
$("go").onclick=runScan;
$("featureImage").onchange=async e=>{const f=e.target.files&&e.target.files[0];featureBlob=null;if(!f)return;try{if(!f.type.startsWith("image/"))throw new Error("not-image");featureBlob=await shrink(f,1200,.86);$("featureStatus").textContent=lg=="ar"?"تم إرفاق الصورة.":"Image attached.";}catch(err){$("featureStatus").textContent=lg=="ar"?"تعذرت قراءة الصورة.":"Could not read image.";}};
$("featureRun").onclick=runFeature;
$("farm").onclick=e=>{const r=e.target.closest("[data-rm]"),a=e.target.closest("[data-ask]");
 if(r){farm=farm.filter(f=>f.id!=r.dataset.rm);sv("farm",farm);try{window.Capacitor?.Plugins?.LocalNotifications?.cancel({notifications:[{id:+r.dataset.rm}]})}catch(x){}drawFarm();drawUp()}
 if(a){const p=P[+a.dataset.ask];show(2);$("q").value=p.n[lg]+" — ";$("q").focus()}};
$("hl").onclick=e=>{const b=e.target.closest("[data-sc]");if(!b)return;const s=scans.find(x=>x.id==b.dataset.sc);if(!s)return;show(1);$("prev").src=s.th;$("prev").style.display="block";$("res").style.display="block";$("res").innerHTML=scanHTML(s.r);scanActs(s.r)};
document.querySelectorAll("#s5 input,#s5 select").forEach(el=>el.addEventListener("input",()=>{if(el.id=="ie")el.dataset.u=1;calc()}));
$("soilAnalyze").onclick=soilAnalyze;$("soilSave").onclick=saveSoil;$("soilHistory").onclick=e=>{const b=e.target.closest("[data-soil-open]");if(!b)return;const x=soilHistory[+b.dataset.soilOpen];if(!x)return;$ ("soilCrop").value=x.crop||"";["Area","Ph","Ec","N","P","K","Moist"].forEach(k=>{const key=k.toLowerCase();$("soil"+k).value=x[key]??""});lastSoil=x;$ ("soilResult").innerHTML=`<h3>تحليل محفوظ</h3><ul>${x.issues.map(v=>`<li>${esc(v)}</li>`).join("")}</ul>`};
$("ds").oninput=drawDis;
$("sq").oninput=drawSol;
$("sol").onclick=e=>{const b=e.target.closest("[data-sq]");if(!b)return;const r=SOL[+b.dataset.sq],k=["ar","de","fr"].includes(lg)?lg:"en";show(2);$("q").value=r[1][k]+" — ";$("q").focus()};
$("dl").onclick=e=>{const b=e.target.closest("[data-dq]");if(!b)return;const d=DIS.find(x=>x.id==b.dataset.dq);show(2);$("q").value=d.n[dl(lg)]+" — ";$("q").focus()};
$("ss").onclick=()=>{cfg={...cfg,url:$("su").value.trim(),token:$("sk").value.trim()};sv("cfg",cfg);$("sr1").textContent=t("saved");draw();show(7)};
$("stt").onclick=async()=>{const u=($("su").value.trim()||endpoint()).replace(/\/+$/,"");$("sr1").textContent=t("wait");
 try{const r=await fetch(u+"/health");const j=await r.json();$("sr1").textContent=r.ok&&j.ok?t("okc")+(j.model?" · "+j.model:""):t("failc")}catch(e){$("sr1").textContent=t("failc")}};
$("cb").onclick=async()=>{const q=$("cq").value.trim();if(!q)return;
 try{const j=await(await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=5&language=${lg}`)).json();
  $("cr").innerHTML=(j.results||[]).map(r=>`<button class="pl" data-la="${r.latitude}" data-lo="${r.longitude}" data-pl="${esc([r.name,r.admin1,r.country].filter(Boolean).join(", "))}"><span>${esc(r.name)}</span><small>${esc([r.admin1,r.country].filter(Boolean).join(", "))}</small></button>`).join("")||`<p>${t("empty")}</p>`}catch(e){$("cr").innerHTML=`<p>${t("failc")}</p>`}};
$("cq").onkeydown=e=>{if(e.key=="Enter")$("cb").click()};
$("cr").onclick=e=>{const b=e.target.closest("[data-la]");if(b)setLoc(+b.dataset.la,+b.dataset.lo,b.dataset.pl)};
$("gl").onclick=()=>navigator.geolocation?.getCurrentPosition(p=>setLoc(+p.coords.latitude.toFixed(3),+p.coords.longitude.toFixed(3),`${p.coords.latitude.toFixed(2)}, ${p.coords.longitude.toFixed(2)}`),()=>{$("pl").textContent=t("failc")},{timeout:15000});
$("clr").onclick=()=>{if(confirm(t("confirm"))){try{Object.keys(localStorage).filter(k=>k.startsWith("af_")).forEach(k=>localStorage.removeItem(k))}catch(e){}location.reload()}};
if("serviceWorker"in navigator&&location.protocol.startsWith("http"))navigator.serviceWorker.register("sw.js").catch(()=>{});
draw();fetchWx();setTimeout(()=>$("splash")?.remove(),1100);
