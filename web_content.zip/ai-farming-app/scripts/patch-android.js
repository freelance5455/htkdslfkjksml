// Adds the permissions AI Farming needs to the generated Android project. Safe to run more than once.
const fs = require("fs"), p = "android/app/src/main/AndroidManifest.xml";
if (!fs.existsSync(p)) { console.error("Run `npx cap add android` first."); process.exit(1); }
let x = fs.readFileSync(p, "utf8");
const lines = [
  '<uses-permission android:name="android.permission.INTERNET" />',
  '<uses-permission android:name="android.permission.CAMERA" />',
  '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
  '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
  '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  '<uses-feature android:name="android.hardware.camera" android:required="false" />'
];
const add = lines.filter(l => !x.includes(l.match(/android:name="([^"]+)"/)[1]));
if (add.length) { x = x.replace("</manifest>", "    " + add.join("\n    ") + "\n</manifest>"); fs.writeFileSync(p, x); }
console.log(add.length ? "Added " + add.length + " manifest entries." : "Manifest already up to date.");
