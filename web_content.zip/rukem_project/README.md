# RUKEM RT 01 - Android Build Project

HTML sumber RUKEM RT 01 ditanam di `app/src/main/assets/index.html`.

## Build
1. Buka folder ini di Android Studio.
2. Tunggu Gradle Sync.
3. Pilih **Build > Build APK(s)**.
4. APK debug ada di `app/build/outputs/apk/debug/app-debug.apk`.

Project ini mempertahankan koneksi internet untuk fitur cloud/Firebase yang digunakan HTML, tetapi UI utama dan aset HTML berada di dalam APK sehingga aplikasi dapat dibuka tanpa hosting.
