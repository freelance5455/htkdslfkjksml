"""Global AI: локальный запуск для проверки на компьютере.

Запуск:  python main.py
Откроется http://localhost:8000 (на localhost камера работает без HTTPS).
Для APK этот файл не нужен: приложение целиком лежит в index.html.
"""
import http.server
import os
import socketserver
import webbrowser

PORT = 8000
os.chdir(os.path.dirname(os.path.abspath(__file__)))

with socketserver.TCPServer(("", PORT), http.server.SimpleHTTPRequestHandler) as srv:
    print(f"Global AI: http://localhost:{PORT}  (Ctrl+C чтобы остановить)")
    webbrowser.open(f"http://localhost:{PORT}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
