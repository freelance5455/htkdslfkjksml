# Global AI

Папка: `index.html` (всё приложение), `KAK_RABOTAET.txt` (подробно, как работает и что локально), `main.py` (проверка на ПК), `README.md`.

## Проверка на компьютере
`python main.py`

## Сборка APK (Capacitor)
```
npm init -y
npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Global AI" com.synth.globalai --web-dir=www
mkdir www && cp index.html www/
npx cap add android
```
В `android/app/src/main/AndroidManifest.xml` добавь перед `<application>`:
```
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.CAMERA"/>
<uses-feature android:name="android.hardware.camera" android:required="false"/>
```
Затем `npx cap sync` и `npx cap open android`, дальше Build > Build APK в Android Studio.

## Быстрый способ без программирования
Загрузи `index.html` (или zip с ним) в конструктор вроде WebIntoApp или Median и включи разрешения «Камера» и «Интернет».

## Что внутри
- Имя: Global AI. На просьбу рассказать о себе подробно отвечает: «Я Global AI от компании Synth. Первая версия была создана 6 ноября 2026 года.»
- Фото с камеры (живая камера или системная), из галереи (до 4 штук), вставка из буфера.
- Ссылки: страницы читаются и учитываются в ответе, ссылки на картинки анализируются как фото.
- Распознавание: описание, чтение текста, объекты, задачи на фото.
- Потоковый ответ, кнопка «Стоп», Markdown, копирование, библиотеки и чаты, редактор кода, запуск кода.
- Чат и распознавание требуют интернета.
