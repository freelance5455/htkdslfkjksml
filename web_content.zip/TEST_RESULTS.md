# ANONYMOUX STUDIO 2.3.2 — Test Results

Run date: 2026-11-11 (build environment)

| Test | Result | Evidence / note |
|---|---|---|
| PHP syntax | **PASS** | `php -l` across all 49 PHP files; no syntax errors. |
| JavaScript syntax | **PASS** | `node --check` across all 8 files under `assets/`. |
| SQLite resource migration | **PASS** | `python tests/resource_migration_check.py`; applies migration twice, verifies nine tables, notification uniqueness, FK cascade and `SET NULL`. |
| Destructive migration scan | **PASS** | Test asserts migration contains no `DROP TABLE` or `DELETE FROM`. |
| PHP persistence smoke | **SKIP / NOT AVAILABLE** | `php tests/smoke.php` detects no `pdo_sqlite`; no `pdo_mysql` driver or configured test DSN is present. |
| Decart live integration | **NOT TESTED** | No live provider credentials or cURL extension available in build runtime. |
| Fish Audio live integration | **NOT TESTED** | No live provider credentials or cURL extension available in build runtime. |
| Admin resource CRUD against DB | **NOT TESTED** | Requires PHP PDO database driver and authenticated admin account. Source checks and PHP lint passed. |
| Per-user isolation / cross-account media tests | **NOT TESTED** | Requires two deployed user sessions and a live DB. Auth/owner checks are present in source. |
| File upload attack testing | **STATIC REVIEW ONLY** | MIME/signature/dimension validation, generated names, size limits, symlink/basename guards and private storage reviewed; no live multipart test executed. |
| Mobile / browser responsiveness | **NOT TESTED ON DEVICE** | Responsive CSS/HTML updated; physical Android/iOS and real browser layout acceptance must be completed after deployment. |
| Shared-hosting behavior | **NOT TESTED** | `.htaccess`, PHP upload limits, SQLite permissions, cURL availability, WAF and execution timeout depend on deployed host. |

## Runtime capability note

Build container reports PHP 8.4.24 and PDO core, but does not include `pdo_sqlite`, `pdo_mysql` or `curl`. The Python standard-library SQLite engine was used only to execute and validate the standalone SQLite migration; this is not a substitute for the application's PHP/PDO smoke test.

## Re-run commands

```bash
find . -type f -name '*.php' -print0 | xargs -0 -n1 php -l
find assets -type f -name '*.js' -print0 | xargs -0 -n1 node --check
python tests/resource_migration_check.py
php tests/smoke.php
```

The last command will skip until a PDO SQLite driver or a reachable MySQL PDO DSN is configured. After deployment, also run the administrator CRUD, ownership, uploads, storage quota, mobile layout and Decart/Fish Audio acceptance checks in `DEPLOYMENT_GUIDE.md`.
