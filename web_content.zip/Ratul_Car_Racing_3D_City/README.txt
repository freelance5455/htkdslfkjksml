RATUL CAR RACING 3D - CITY EDITION
Version 1.0 prototype

Files:
- index.html: the playable 3D browser game.

How to play:
1. Open index.html in a modern browser with internet access.
2. Wait for the Three.js engine to load.
3. Tap START RACING.
4. Use left/right buttons to steer; hold NITRO to boost.

Notes:
- This is a browser-playable prototype, not an APK.
- It loads Three.js from jsDelivr, so internet is required.
- Android APK packaging is a separate next step.
