# GlassOS — iPhone-inspired Android UI demo

This is an Android Studio project for a fullscreen, touch-driven iPhone-style interface. It is a simulation app, not an iOS replacement or a system launcher.

## Features
- Dynamic Island-style expandable pill
- Swipe between home pages and bottom home indicator
- Liquid-glass styling and changeable gradient wallpapers
- Settings for glass appearance, accent color, and tap sounds
- Functional local calculator and persistent notes
- Demo Music, Photos, Weather, Clock, Phone, Messages, Browser, Files, and Control Center screens
- Local time/date and subtle generated UI tap sounds

## Honest limitations
- Music uses short generated demo tones, not a streaming catalog.
- Weather is sample data; browser is intentionally offline.
- Phone/messages do not place calls or send SMS.
- Camera and private files are not accessed.
- This app cannot replace Android's system UI or provide genuine iOS system features.

## Build APK
The current workspace did not have the Android SDK or Gradle installed, so an APK could not be compiled here. To build it:
1. Install Android Studio on a computer.
2. Open this `GlassOS` folder as a project.
3. Let Android Studio install the required Android SDK / Gradle components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated debug APK on your Android phone.

Minimum Android version: Android 8.0 (API 26).
