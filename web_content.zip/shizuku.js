// Shizuku API integration
if (typeof Shizuku !== 'undefined') {
  Shizuku.checkSelfPermission();
  Shizuku.newProcess(["pm","disable","com.garena.game.kgvn.anticheat"], null, null);
}