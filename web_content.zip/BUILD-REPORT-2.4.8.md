# ANONYMOUX STUDIO 2.4.8 — Voice generation flow repair

Source: `ANONYMOUX_STUDIO_2.4.7_VOICE_AGENT_RESOURCES_REBUILD.zip`

## Repairs

1. **Fish Audio voice catalogue:** accepts the provider's documented `svc` model type (while retaining compatibility with legacy `tts` records) and honors provider `has_more` pagination metadata. The previous `type === tts` filter discarded the documented public voice models.
2. **Agent voice flags:** creation now persists `expressive: false` as an explicit Boolean instead of dropping it from the JSON configuration.
3. **Voice continuity:** selected Voice Studio voice is persisted in the existing account-scoped `workspace_preferences` store and loaded from the server. Local browser storage remains a fallback. Agent sessions also pass the saved agent voice through Fish Audio's supported session `overrides.voice_id` field.
4. **SDK reproducibility:** browser Agent SDK import pinned to `@fishaudio/agent-client@0.3.0`.
5. **Usage reconciliation:** on session end, the backend retrieves Fish Audio session details, reads completed LLM usage cost records, and stores each provider `message_generation_id` once in the existing `agent_usage` table. Deterministic credit-ledger references prevent duplicate wallet debits. A retry endpoint and UI control allow post-call usage to be reconciled after Fish Audio completes processing.
6. **Billing safety:** `ANONYMOUX_AGENT_CREDITS_PER_USD` defaults to `0`. At zero, USD LLM usage is measured and stored but does not debit ANON credits. A positive conversion rate enables charging completed, provider-reported LLM usage. Insufficient balances are marked `unpaid`; incomplete usage is not charged.

## Scope and preserved systems

- No database schema migration; existing `workspace_preferences`, `agent_sessions`, `agent_usage`, and `credit_transactions` tables are reused.
- Existing Fish Audio API key vault, TTS endpoint, payment logic, credit wallet, agent ownership, and CSRF/authentication guards remain in place.
- No provider credentials are exposed to browser code.

## Known billing boundary

Fish Audio's session detail schema exposes LLM usage costs in USD. This implementation reconciles those returned LLM costs only. It does not invent separate ASR/TTS/audio transport charges where the current session response does not expose those costs. Configure the credit/USD conversion only after setting and testing the platform's commercial rate policy.

## Verification

- PHP syntax: 78 PHP files passed.
- JavaScript syntax: 12 asset scripts passed.
- Voice-flow repair static checks: 12 passed.
- Branding/voice integration regression checks: passed.
- Resources/admin regression checks: passed.
- Resource migration repeatability check: passed.
- PHP persistence smoke test: skipped because this build runtime does not have `pdo_sqlite`; run against the target site's MySQL/SQLite PDO driver.
- Live Fish Audio calls, provider usage settlement, microphone/WebRTC browser playback, and real production database writes were not possible without the deployment's API key, PHP cURL, and database runtime.
