VXOS 1.0 ALPHA — ANDROID PROJESİ
================================

Bu proje, VDX ekosistemi için Android üzerinde çalışan bir arayüz prototipidir.
Gerçek bir Android işletim sistemi değildir; Android çekirdeğini, donanım
performansını veya cihazın sistem ayarlarını değiştirmez.

GEREKSİNİMLER
-------------
- Android Studio (Koala veya daha yeni sürüm önerilir)
- JDK 17
- Android SDK Platform 35
- Gradle 8.9 (Android Gradle Plugin 8.7.3 ile)
- İnternet yalnızca ilk Gradle bağımlılıklarının indirilmesi/senkronizasyonu için gerekir.
  Uygulamanın temel arayüzü kurulduktan sonra çevrimdışı açılır.

ANDROID STUDIO'DA AÇMA
---------------------
1. ZIP dosyasını bir klasöre çıkarın.
2. Android Studio > Open seçeneğine basın.
3. Çıkardığınız VXOS_1.0_ALPHA klasörünü seçin.
4. Android Studio'nun Gradle senkronizasyonunu tamamlamasını bekleyin.
5. Bir Android cihaz veya emülatör seçip Run düğmesine basın.

APK DERLEME
-----------
Android Studio:
1. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
2. Derleme tamamlanınca çıkan bildirimde Locate seçeneğine basın.
3. APK genellikle app/build/outputs/apk/debug/app-debug.apk konumundadır.

Komut satırı (Gradle kuruluysa):
    gradle assembleDebug

Paket kimliği: com.vdx.vxos
Namespace: com.vdx.vxos
Minimum SDK: 23
Compile SDK: 35
Hedef SDK: 35
Sürüm: 1.0-alpha

ÇALIŞAN ÖZELLİKLER
------------------
- Koyu/açık tema tercihi
- Eco / Normal / Hyperboost arayüz profili (yalnızca arayüz tercihi)
- Ana ekran ve modül navigasyonu
- VDX_BASE alt sayfaları
- Modül etkinleştirme tercihleri
- Yerel not ekleme ve silme
- JSON yedek dışa aktarma ve geri yükleme (Android belge seçici)
- Cihazın yerel saat/tarih gösterimi
- Çevrimdışı temel arayüz
- Türkçe kullanıcı arayüzü

BİLİNEN EKSİKLİKLER / SINIRLAR
------------------------------
- Vexa AI ve VDX Bilge için henüz gerçek AI/arama servisi bağlanmamıştır.
- VDX Watch için Bluetooth/saat eşleştirme işlevi henüz eklenmemiştir.
- VDX CLOUD henüz uzak sunucu veya senkronizasyon içermez.
- Automation motoru, gerçek zamanlı otomasyon çalıştırmaz.
- Analytics yalnızca yerel uygulama verilerinden basit sayılar gösterir.
- App Workshop APK derlemez; UI Designer temel tema seçimiyle sınırlıdır.
- System Core, Android çekirdeği değildir ve sistem seviyesinde yetki kullanmaz.
- Android'in bildirim paneli, hızlı ayarları ve uygulama çekmecesi değiştirilmez.
- Uygulama şu an tek Activity + WebView tabanlıdır.
- Gradle Wrapper dosyaları ZIP'e eklenmemiştir. Android Studio kurulumunuzun
  Gradle dağıtımını kullanabilir veya projede Gradle Wrapper oluşturabilirsiniz.

GİZLİLİK VE İZİNLER
-------------------
Manifestte internet, konum, kamera, mikrofon, Bluetooth veya depolama izni
istenmez. JSON dosyaları Android'in sistem belge seçicisi üzerinden kullanıcı
seçimiyle okunur/yazılır. Notlar ve ayarlar WebView localStorage alanındadır.

MİMARİ
------
- MainActivity.kt: Android Activity, WebView ve JSON dosya köprüsü
- assets/index.html: uygulama iskeleti
- assets/style.css: responsive koyu/açık tema
- assets/app.js: navigasyon, modüller, yerel kayıt ve yedekleme
