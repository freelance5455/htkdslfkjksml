package com.vdx.vxos

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val createBackupRequest = 4101
    private val openBackupRequest = 4102
    private var pendingBackup = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 13, 31)
        window.navigationBarColor = android.graphics.Color.rgb(7, 13, 31)
        window.decorView.systemUiVisibility = 0

        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(7, 13, 31))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(VxBridge(), "VXOS")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class VxBridge {
        @JavascriptInterface
        fun exportBackup(json: String) {
            runOnUiThread {
                pendingBackup = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "VXOS_backup.json")
                }
                startActivityForResult(intent, createBackupRequest)
            }
        }

        @JavascriptInterface
        fun importBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, openBackupRequest)
            }
        }

        @JavascriptInterface
        fun notifyUser(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message.take(180), Toast.LENGTH_SHORT).show() }
        }
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            createBackupRequest -> {
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingBackup) }
                Toast.makeText(this, "Yedek dosyası kaydedildi.", Toast.LENGTH_SHORT).show()
            }
            openBackupRequest -> {
                val content = contentResolver.openInputStream(uri)?.use { stream ->
                    BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
                } ?: return
                webView.evaluateJavascript("window.applyImportedBackup(${org.json.JSONObject.quote(content)});", null)
            }
        }
    }

    override fun onBackPressed() {
        webView.evaluateJavascript("window.vxBack();", null)
    }
}
