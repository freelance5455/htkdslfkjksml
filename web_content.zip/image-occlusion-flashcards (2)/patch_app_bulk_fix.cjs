const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
  "onBulkCreate={bulkCreateCards}",
  "onStartBulkEdit={(cards) => {\n          setBulkEditQueue(cards);\n          setView('bulk-edit');\n        }}\n          onBulkCreate={bulkCreateCards}"
);

fs.writeFileSync('src/App.tsx', code);
console.log('App.tsx bulk edit prop patched');
