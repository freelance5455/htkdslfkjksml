const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const oldButtons = `              <button
                type="button"
                onClick={() => {
                  setShowAutoBulkSummary(false);
                  onCancel();
                }}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/20 transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>✨ ঠিক আছে (সেভ সম্পন্ন)</span>
              </button>`;

const newButtons = `              <button
                type="button"
                onClick={handleSaveAllAutoBulkCards}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/20 transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>💾 সরাসরি সেভ করুন</span>
              </button>`;

code = code.replace(oldButtons, newButtons);

const reviewBtnOld = `<span>🔍 কার্ডগুলো রিভিউ ও এডিট করুন</span>`;
const reviewBtnNew = `<span>👀 কার্ডগুলো প্রিভিউ ও এডিট করুন</span>`;

code = code.replace(reviewBtnOld, reviewBtnNew);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed buttons');
