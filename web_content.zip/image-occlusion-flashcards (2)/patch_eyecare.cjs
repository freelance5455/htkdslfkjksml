const fs = require('fs');

function patchComponent(filePath) {
  let code = fs.readFileSync(filePath, 'utf8');

  // Add Moon import if not present
  if (!code.includes('Moon,')) {
    code = code.replace('import { Home', 'import { Moon, Home');
  }

  // Add eyeCare state
  if (!code.includes('eyeCare')) {
    code = code.replace(
      "const [alertMsg, setAlertMsg] = useState('');",
      "const [alertMsg, setAlertMsg] = useState('');\n  const [eyeCare, setEyeCare] = useState(false);"
    );
    // In QuizMode, alertMsg might not exist, check activeItemId
    code = code.replace(
      "const [activeItemId, setActiveItemId] = useState<string | null>(null);",
      "const [activeItemId, setActiveItemId] = useState<string | null>(null);\n  const [eyeCare, setEyeCare] = useState(false);"
    );
  }

  // Add EyeCare button in zoom controls
  const zoomControlsMatch = code.match(/<button onClick=\{\(\) => resetTransform\(\)\}.*?<\/button>/);
  if (zoomControlsMatch && !code.includes('setEyeCare(!eyeCare)')) {
    const btnHtml = `\\n                  <button onClick={() => setEyeCare(!eyeCare)} className={\`p-2 rounded \${eyeCare ? 'bg-indigo-500/50 text-indigo-200' : 'text-white hover:bg-slate-700'}\`} title="Eye-Care Mode"><Moon className="w-5 h-5" /></button>`;
    code = code.replace(zoomControlsMatch[0], zoomControlsMatch[0] + btnHtml);
  }

  // Apply filter to image
  const imgMatch = code.match(/<img src=\{card.image\}.*?className=".*?".*?\/>/);
  if (imgMatch && !code.includes('filter: eyeCare')) {
    const newImg = imgMatch[0].replace('/>', ` style={{ filter: eyeCare ? 'brightness(0.75) sepia(0.3) contrast(1.1)' : 'none', transition: 'filter 0.3s' }} />`);
    code = code.replace(imgMatch[0], newImg);
  }

  fs.writeFileSync(filePath, code);
  console.log(filePath + " updated successfully");
}

patchComponent('src/components/StudyCard.tsx');
patchComponent('src/components/QuizMode.tsx');
