const fs = require('fs');
let code = fs.readFileSync('src/components/StudyCard.tsx', 'utf8');

// Add showNotes state
code = code.replace(
  "const [alertMsg, setAlertMsg] = useState('');",
  "const [alertMsg, setAlertMsg] = useState('');\n  const [showNotes, setShowNotes] = useState(false);"
);

// Reset showNotes on next card
code = code.replace(
  "setRevealedPins(new Set());",
  "setRevealedPins(new Set());\n      setShowNotes(false);"
);

// Replace notes display
const notesBlockOld = `{card.notes && (
          <div className="mt-4 w-full max-w-2xl bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-slate-200">
            <h3 className="font-bold text-sm mb-1 text-slate-400">নোট/ছন্দ:</h3>
            <p className="whitespace-pre-wrap">{card.notes}</p>
          </div>
        )}`;

const notesBlockNew = `{card.notes && (
          <div className="mt-4 w-full max-w-2xl bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-slate-200 transition-all">
            <button 
              onClick={() => setShowNotes(!showNotes)}
              className="flex items-center justify-between w-full font-bold text-sm text-slate-400 hover:text-slate-200 transition-colors"
            >
              <span>নোট/ছন্দ</span>
              <span>{showNotes ? '▲' : '▼'}</span>
            </button>
            {showNotes && (
              <p className="whitespace-pre-wrap mt-3 pt-3 border-t border-slate-700 text-sm">{card.notes}</p>
            )}
          </div>
        )}`;

code = code.replace(notesBlockOld, notesBlockNew);

fs.writeFileSync('src/components/StudyCard.tsx', code);
console.log("StudyCard updated successfully");
