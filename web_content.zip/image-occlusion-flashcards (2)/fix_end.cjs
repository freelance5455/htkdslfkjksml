const fs = require('fs');
let lines = fs.readFileSync('src/components/CreateCard.tsx', 'utf8').split('\n');

// Replace lines 2927 to 2929 (which are index 2927, 2928, 2929)
// Note: 2928 is `          </div>`, 2929 is `        )}`, 2930 is `      </div>`.
// Wait, 0-based indexing:
// line 2928 is lines[2927].
lines[2927] = '            )}'; // replaces `          </div>`
lines[2928] = '          </div>'; // replaces `        )}`
lines[2929] = '        )}'; // replaces `      </div>`

fs.writeFileSync('src/components/CreateCard.tsx', lines.join('\n'));
