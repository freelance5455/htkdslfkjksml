const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const target = `  const handleReviewAutoBulkCards = () => {
    if (autoBulkCompletedCards.length === 0) return;
    const batchItems = autoBulkCompletedCards.map(c => ({
      id: \`batch-\${c.id}\`,
      image: c.image,
      title: c.title,
      rectangles: c.rectangles || [],
      pins: c.pins || [],
      notes: c.notes || '',
      tags: c.tags || [],
      isAiProcessed: true
    }));
    setImageBatch(batchItems);
    setActiveBatchIndex(0);
    setShowAutoBulkSummary(false);
  };`;

code = code.replace(target, '');
fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Removed duplicate');
