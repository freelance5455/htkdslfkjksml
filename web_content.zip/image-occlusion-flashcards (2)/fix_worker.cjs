const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetBulk = `  const bulkCreateCards = async (newCards: Card[]) => {
    try {
      const { update, get } = await import('idb-keyval');
      const now = Date.now();
      const stamped = newCards.map(c => ({ ...c, createdAt: c.createdAt || now, updatedAt: now }));
      
      await update('flashcards', (val: any) => {
        const existing = (val as Card[]) || [];
        return [...existing, ...stamped];
      });
      
      const latest = (await get('flashcards')) || [];
      setCards(latest);
      syncService.notifyLocalChange();
    } catch (e) {
      console.error('Failed to bulk save cards:', e);
    }
  };`;

const replacementBulk = `  const bulkCreateCards = async (newCards: Card[]) => {
    try {
      const { update, get } = await import('idb-keyval');
      const now = Date.now();
      const stamped = newCards.map(c => ({ ...c, createdAt: c.createdAt || now, updatedAt: now }));
      
      // Batch large arrays into smaller chunks for IDB to avoid transaction blocking
      const CHUNK_SIZE = 10;
      let existingCards = (await get('flashcards')) || [];
      
      for (let i = 0; i < stamped.length; i += CHUNK_SIZE) {
         const chunk = stamped.slice(i, i + CHUNK_SIZE);
         await update('flashcards', (val: any) => {
            const current = (val as Card[]) || [];
            return [...current, ...chunk];
         });
      }
      
      const latest = (await get('flashcards')) || [];
      setCards(latest);
      syncService.notifyLocalChange();
    } catch (e) {
      console.error('Failed to bulk save cards:', e);
    }
  };`;

code = code.replace(targetBulk, replacementBulk);
fs.writeFileSync('src/App.tsx', code);
