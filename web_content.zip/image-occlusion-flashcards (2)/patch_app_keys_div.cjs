const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
  "{view === 'create' && (\n        <CreateCard\n          key={editingCardId || 'new'}",
  "{view === 'create' && (\n        <div key={editingCardId || 'new'} className=\"h-full\">\n        <CreateCard"
);
code = code.replace(
  "          onCancel={handleCancelEdit}\n        />\n      )}",
  "          onCancel={handleCancelEdit}\n        />\n        </div>\n      )}"
);

code = code.replace(
  "{view === 'bulk-edit' && bulkEditQueue.length > 0 && (\n        <CreateCard\n          key={bulkEditQueue[0].id}",
  "{view === 'bulk-edit' && bulkEditQueue.length > 0 && (\n        <div key={bulkEditQueue[0].id} className=\"h-full\">\n        <CreateCard"
);

code = code.replace(
  "          onCancel={() => {\n            setBulkEditQueue([]);\n            setView('dashboard');\n          }}\n        />\n      )}",
  "          onCancel={() => {\n            setBulkEditQueue([]);\n            setView('dashboard');\n          }}\n        />\n        </div>\n      )}"
);

fs.writeFileSync('src/App.tsx', code);
console.log('App.tsx wrapped with keys in div');
