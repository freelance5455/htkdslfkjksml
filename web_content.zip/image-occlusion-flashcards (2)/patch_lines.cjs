const fs = require('fs');
let lines = fs.readFileSync('src/components/CreateCard.tsx', 'utf8').split('\n');

lines.splice(2926, 6, 
  '          </div>',
  '        )}',
  '      </main>'
);

fs.writeFileSync('src/components/CreateCard.tsx', lines.join('\n'));
