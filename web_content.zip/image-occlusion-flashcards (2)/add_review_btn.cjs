const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const reviewFunction = `  const handleReviewAutoBulkCards = () => {
    if (autoBulkCompletedCards.length === 0) return;
    const batchItems = autoBulkCompletedCards.map(c => ({
      id: \`batch-\${c.id}\`,
      image: c.image,
      title: c.title,
      rectangles: c.rectangles || [],
      pins: c.pins || [],
      notes: c.notes || '',
      tags: c.tags || [],
      isAiProcessed: true
    }));
    setImageBatch(batchItems);
    setActiveBatchIndex(0);
    setShowAutoBulkSummary(false);
  };

  // 3rd Option: Full Auto Bulk Processing Handler`;

code = code.replace('  // 3rd Option: Full Auto Bulk Processing Handler', reviewFunction);

const reviewBtn = `            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={handleReviewAutoBulkCards}
                className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm border border-slate-700 transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Eye className="w-4 h-4" />
                <span>🔍 কার্ডগুলো রিভিউ ও এডিট করুন</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowAutoBulkSummary(false);
                  onCancel();
                }}`;

code = code.replace(`            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-slate-800">
              
              <button
                type="button"
                onClick={() => {
                  setShowAutoBulkSummary(false);
                  onCancel();
                }}`, reviewBtn);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Added review logic');
