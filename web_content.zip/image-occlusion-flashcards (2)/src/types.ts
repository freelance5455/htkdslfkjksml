export type SyncStatus = 'Saved on phone' | 'Syncing' | 'Backed up';

export interface Folder {
  id: number;
  parentId?: number;
  name: string;
  createdAt: number;
  updatedAt?: number;
}

export interface Rectangle {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  xPercent?: number;
  yPercent?: number;
  widthPercent?: number;
  heightPercent?: number;
  label?: string;
  badgePosition?: 'auto' | 'left' | 'inside' | 'right' | 'top' | 'hidden';
  badgeDistance?: 'normal' | 'far' | 'margin';
}

export interface Pin {
  id: number;
  x: number;
  y: number;
  xPercent?: number;
  yPercent?: number;
  label: string;
  badgePosition?: 'auto' | 'left' | 'inside' | 'right' | 'top' | 'hidden';
  badgeDistance?: 'normal' | 'far' | 'margin';
}

export interface Card {
  id: number;
  folderId?: number;
  title: string;
  image: string;
  rectangles: Rectangle[];
  pins?: Pin[];
  notes?: string;
  tags?: string[];
  badgePosition?: 'auto' | 'left' | 'inside' | 'right' | 'hidden';
  showBadges?: boolean;
  badgeDistance?: 'normal' | 'far' | 'margin';
  interval?: number;
  repetition?: number;
  easeFactor?: number;
  nextReview?: number;
  lastReviewed?: number;
  lapses?: number;
  favorite?: boolean;
  createdAt?: number;
  updatedAt?: number;
}
