import { registerSW } from 'virtual:pwa-register';
import { appUpdateService } from './lib/appUpdate';
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import ErrorBoundary from './components/ErrorBoundary';
import './index.css';

if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  const updateSW = registerSW({
    immediate: true,
    onNeedRefresh() {
      // User is prompted via the in-app banner instead of an abrupt page reload
      appUpdateService.setHasUpdate(true);
    },
    onOfflineReady() {
      console.log('App is ready for offline use.');
    },
    onRegisteredSW(_swUrl, r) {
      if (r) {
        // Safe check after initial load is stabilized
        setTimeout(() => {
          r.update().catch(() => {});
        }, 8000);
      }
    }
  });

  appUpdateService.registerSWUpdateHandler(() => {
    try {
      updateSW(true);
    } catch (e) {
      window.location.reload();
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
