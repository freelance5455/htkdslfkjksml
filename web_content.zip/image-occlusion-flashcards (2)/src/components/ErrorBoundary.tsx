import React, { ReactNode } from 'react';
import { AlertTriangle, RotateCcw, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends (React.Component as any) {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: any) {
    console.error('Uncaught error caught by ErrorBoundary:', error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    if (this.props.onReset) {
      this.props.onReset();
    }
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6 text-center select-none">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mb-4 text-amber-400">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold mb-2 text-white">সাময়িক ত্রুটি দেখা দিয়েছে</h2>
          <p className="text-sm text-slate-300 max-w-sm mb-6">
            আপনার সমস্ত কার্ড ও ডাটা ডিভাইসে সম্পূর্ণ সুরক্ষিত আছে। নিচের বাটনে চাপ দিয়ে আবার চেষ্টা করুন।
          </p>
          <div className="flex flex-col sm:flex-row gap-3 w-full max-w-xs">
            <button
              onClick={this.handleReset}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-semibold rounded-xl shadow-lg transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              পুনরায় চেষ্টা করুন
            </button>
            <button
              onClick={() => {
                try {
                  sessionStorage.removeItem('io_active_view');
                  sessionStorage.removeItem('io_active_folder');
                } catch (e) {}
                window.location.reload();
              }}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 font-semibold rounded-xl border border-slate-700 transition-all cursor-pointer"
            >
              <Home className="w-4 h-4" />
              হোম স্ক্রিনে যান
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
