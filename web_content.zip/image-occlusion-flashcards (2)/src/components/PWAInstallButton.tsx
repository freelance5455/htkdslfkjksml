import React from 'react';
import { Smartphone } from 'lucide-react';

interface PWAInstallButtonProps {
  className?: string;
  onClick?: () => void;
}

export default function PWAInstallButton({ className = '', onClick }: PWAInstallButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-bold transition-all active:scale-95 shadow-xs cursor-pointer bg-gradient-to-r from-blue-500 to-indigo-600 text-white hover:from-blue-600 hover:to-indigo-700 border border-white/20 animate-pulse ${className}`}
      title="ফোনে আলাদা অ্যাপ (APK) ইনস্টল করুন"
    >
      <Smartphone className="w-3.5 h-3.5 text-blue-100" />
      <span>অ্যাপ ইনস্টল</span>
    </button>
  );
}
