import React, { useRef, useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import {
  Settings as SettingsIcon,
  X,
  Download,
  Upload,
  FileJson,
  CheckCircle2,
  Moon,
  Sun,
  ShieldCheck,
  HardDrive,
  Folder as FolderIcon,
  Layers,
  Sparkles,
  Info,
  HelpCircle,
  Volume2,
  VolumeX,
  Smartphone,
  Repeat,
  RefreshCw,
  Cloud,
  Globe,
  LogOut,
  User as UserIcon,
  History,
  Copy,
  ClipboardPaste,
  AlertTriangle,
  Check,
  Eye,
  Sliders,
  SunMedium
} from 'lucide-react';
import { User } from 'firebase/auth';
import { auth, googleSignIn, logout } from '../lib/firebase';
import { syncService } from '../lib/firestoreSync';
import { appUpdateService } from '../lib/appUpdate';
import { saveOrShareJSON, copyTextToClipboard } from '../lib/fileSaveUtils';
import FileExportModal from './FileExportModal';
import { openSyncModal, openDeepRecoveryModal } from './SyncButton';
import { Card, Folder } from '../types';
import { 
  getSpeechSettings, 
  updateSpeechSettings, 
  speakWithRepetition, 
  triggerHaptic, 
  SpeechSettings, 
  stopSpeech 
} from '../lib/speechUtils';
import { usePWAInstall } from '../lib/usePWAInstall';
import PWAInstallModal from './PWAInstallModal';
import { 
  getNotchSetting, 
  setNotchSetting, 
  NotchSetting,
  getBottomNavSetting,
  setBottomNavSetting,
  BottomNavSetting
} from '../lib/notchUtils';
import {
  getEyeComfortSettings,
  saveEyeComfortSettings,
  toggleEyeComfort,
  subscribeEyeComfort,
  EyeComfortSettings,
  EyeComfortTone,
  isEyeComfortActive
} from '../lib/eyeComfortUtils';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  cards: Card[];
  folders: Folder[];
  darkMode?: boolean;
  toggleDarkMode?: () => void;
  onImport?: (data: { cards: Card[]; folders: Folder[] } | Card[]) => void;
  setAlertMsg?: (msg: string) => void;
  onOpenSync?: () => void;
  onOpenHelp?: () => void;
}

export default function SettingsModal({
  isOpen,
  onClose,
  cards,
  folders,
  darkMode,
  toggleDarkMode,
  onImport,
  setAlertMsg,
  onOpenSync,
  onOpenHelp
}: SettingsModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportPayload, setExportPayload] = useState<{ filename: string; data: any } | null>(null);
  const [isCopyingDirect, setIsCopyingDirect] = useState(false);
  const [copiedDirectSuccess, setCopiedDirectSuccess] = useState(false);
  const [showPasteRestoreModal, setShowPasteRestoreModal] = useState(false);
  const [pastedJson, setPastedJson] = useState('');
  const [speechSettings, setSpeechSettings] = useState<SpeechSettings>(() => getSpeechSettings());
  const [showPwaInstallModal, setShowPwaInstallModal] = useState(false);
  const [notchMode, setNotchMode] = useState<NotchSetting>(() => getNotchSetting());
  const [bottomNavMode, setBottomNavMode] = useState<BottomNavSetting>(() => getBottomNavSetting());
  const { isInstalled, isInstallable, storageInfo, refreshStorage } = usePWAInstall();

  const [currentUser, setCurrentUser] = useState<User | null>(() => auth.currentUser);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [isRefreshingUpdate, setIsRefreshingUpdate] = useState(false);

  useEffect(() => {
    const unsub = auth.onAuthStateChanged((u) => setCurrentUser(u));
    return () => unsub();
  }, []);

  const handleGoogleLogin = async () => {
    try {
      setIsSigningIn(true);
      const res = await googleSignIn();
      if (res?.user) {
        setCurrentUser(res.user);
        if (setAlertMsg) setAlertMsg(`${res.user.displayName || 'ব্যবহারকারী'} হিসেবে লগইন সম্পন্ন! ক্লাউড অটো-সিঙ্ক সক্রিয়।`);
        try {
          const syncRes = await syncService.syncNow();
          if (syncRes && (syncRes.cards.length > 0 || syncRes.folders.length > 0)) {
            onImport?.(syncRes);
          }
        } catch (e) {
          console.warn('Initial sync warning:', e);
        }
      }
    } catch (err: any) {
      if (err?.code !== 'auth/popup-closed-by-user') {
        if (setAlertMsg) setAlertMsg('গুগল লগইন ব্যর্থ হয়েছে। ইন্টারনেট সংযোগ পরীক্ষা করুন।');
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleGoogleLogout = async () => {
    try {
      await logout();
      setCurrentUser(null);
      if (setAlertMsg) setAlertMsg('লগআউট সম্পন্ন হয়েছে। আপনার সমস্ত ডাটা ডিভাইসে সুরক্ষিত আছে।');
    } catch (e) {
      console.warn('Logout error:', e);
    }
  };

  const handleTriggerAppUpdate = async () => {
    try {
      setIsRefreshingUpdate(true);
      triggerHaptic('success');
      if (setAlertMsg) setAlertMsg('নতুন আপডেট লোড ও ক্যাশ পরিষ্কার করা হচ্ছে...');
      await appUpdateService.applyUpdateAndReload();
    } catch (e) {
      console.warn(e);
      window.location.reload();
    } finally {
      setIsRefreshingUpdate(false);
    }
  };

  useEffect(() => {
    setSpeechSettings(getSpeechSettings());
    if (isOpen) {
      refreshStorage();
    }
  }, [isOpen]);

  const [eyeComfort, setEyeComfort] = useState<EyeComfortSettings>(() => getEyeComfortSettings());
  const [isEyeComfortOn, setIsEyeComfortOn] = useState<boolean>(() => isEyeComfortActive());

  useEffect(() => {
    const unsub = subscribeEyeComfort((s, active) => {
      setEyeComfort(s);
      setIsEyeComfortOn(active);
    });
    return () => unsub();
  }, []);

  if (!isOpen || typeof document === 'undefined') return null;

  const totalMasks = cards.reduce((acc, c) => acc + (c.rectangles?.length || 0), 0);

  // Universal Backup Export Handler (Opens modal with Copy, Share, Download, Drive options)
  const handleExportJSON = () => {
    const now = new Date();
    const dateString = now.toISOString().slice(0, 10);
    const timeString = `${String(now.getHours()).padStart(2, '0')}-${String(now.getMinutes()).padStart(2, '0')}`;
    const filename = `flashcards_backup_${dateString}_${timeString}.json`;

    const backupPayload = {
      app: 'Image Occlusion Flashcards',
      version: '2.0',
      exportedAt: now.toISOString(),
      exportedAtFormatted: now.toLocaleString('bn-BD', {
        dateStyle: 'medium',
        timeStyle: 'short'
      }),
      stats: {
        totalCards: cards.length,
        totalFolders: folders.length,
        totalMasks: totalMasks
      },
      folders: folders,
      cards: cards
    };

    setExportPayload({ filename, data: backupPayload });
    setShowExportModal(true);
  };

  // Direct 1-click clipboard copy (100% permission-free, never blocked by APK)
  const handleDirectCopyBackup = async () => {
    try {
      setIsCopyingDirect(true);
      const now = new Date();
      const backupPayload = {
        app: 'Image Occlusion Flashcards',
        version: '2.0',
        exportedAt: now.toISOString(),
        stats: {
          totalCards: cards.length,
          totalFolders: folders.length,
          totalMasks: totalMasks
        },
        folders: folders,
        cards: cards
      };
      const ok = await copyTextToClipboard(JSON.stringify(backupPayload, null, 2));
      if (ok) {
        setCopiedDirectSuccess(true);
        if (setAlertMsg) {
          setAlertMsg(`সম্পূর্ণ ব্যাকআপ (${cards.length}টি কার্ড ও ${folders.length}টি ফোল্ডার) ক্লিপবোর্ডে কপি হয়েছে! নোটপ্যাডে পেস্ট করে রাখুন।`);
        }
        setTimeout(() => setCopiedDirectSuccess(false), 4500);
      } else {
        if (setAlertMsg) setAlertMsg('ক্লিপবোর্ডে কপি করা সম্ভব হয়নি।');
      }
    } catch (e) {
      if (setAlertMsg) setAlertMsg('কপি করতে সমস্যা হয়েছে।');
    } finally {
      setIsCopyingDirect(false);
    }
  };

  // Paste & Restore Handler (100% permission-free restore)
  const handleRestoreFromPastedText = () => {
    if (!pastedJson.trim()) {
      if (setAlertMsg) setAlertMsg('দয়া করে ব্যাকআপ টেক্সট পেস্ট করুন।');
      return;
    }
    try {
      const parsed = JSON.parse(pastedJson.trim());
      if (onImport) {
        onImport(parsed);
        if (setAlertMsg) {
          setAlertMsg('সফলভাবে টেক্সট ব্যাকআপ থেকে ডাটা রিস্টোর করা হয়েছে!');
        }
        setShowPasteRestoreModal(false);
        setPastedJson('');
        onClose();
      }
    } catch (err) {
      if (setAlertMsg) {
        setAlertMsg('পেস্ট করা টেক্সটটি সঠিক JSON ব্যাকআপ নয়। সম্পূর্ণ ব্যাকআপ কপি পেস্ট করুন।');
      }
    }
  };

  // Manual Backup Import Handler
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (onImport) {
          onImport(parsed);
          if (setAlertMsg) {
            setAlertMsg('সফলভাবে JSON ব্যাকআপ ফাইল থেকে ডাটা রিস্টোর করা হয়েছে!');
          }
          onClose();
        }
      } catch (err) {
        console.error('Failed to parse imported JSON file:', err);
        if (setAlertMsg) {
          setAlertMsg('ভুল ফাইল ফরম্যাট! অনুগ্রহ করে একটি সঠিক .json ব্যাকআপ ফাইল নির্বাচন করুন।');
        }
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const modalContent = (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-800 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200/80 dark:border-slate-700/80 relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Hidden file input for manual restore */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleImportJSON}
          accept="application/json,.json,text/plain,text/*,*/*"
          className="hidden"
        />

        {/* Modal Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full transition-colors cursor-pointer"
          title="বন্ধ করুন"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 mb-5 pb-4 border-b border-slate-100 dark:border-slate-700/80">
          <div className="w-11 h-11 rounded-2xl bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center shadow-xs border border-blue-100 dark:border-blue-800/40">
            <SettingsIcon className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
              অ্যাপ সেটিংস ও ব্যাকআপ
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              ম্যানুয়াল ব্যাকআপ, থিম এবং ডাটা ব্যবস্থাপনা
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Google Account & Cloud Auto-Sync Primary Section */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-blue-50/90 via-indigo-50/70 to-sky-50/40 dark:from-slate-900 dark:via-blue-950/40 dark:to-indigo-950/30 border border-blue-200/90 dark:border-blue-800/60 shadow-xs space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                  <Cloud className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    গুগল অ্যাকাউন্ট ও ক্লাউড অটো-সিঙ্ক
                    {currentUser ? (
                      <span className="text-[10px] bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 font-bold px-2 py-0.5 rounded-full">
                        কানেক্টেড
                      </span>
                    ) : (
                      <span className="text-[10px] bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300 font-bold px-2 py-0.5 rounded-full">
                        লগইন প্রয়োজন
                      </span>
                    )}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    ফোন পরিবর্তন বা নতুন অ্যাপে সমস্ত কার্ড স্বয়ংক্রিয়ভাবে ফিরে আসবে
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    openSyncModal('drive');
                  }}
                  className="px-2.5 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border border-blue-200 dark:border-blue-800/60 active:scale-95 text-blue-700 dark:text-blue-300 rounded-xl text-xs font-bold shadow-2xs transition-all cursor-pointer"
                  title="গুগল ড্রাইভ ব্যাকআপ ও রিস্টোর"
                >
                  ড্রাইভ অপশন
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    openSyncModal('cloud');
                  }}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
                  title="ক্লাউড অটো-সিঙ্ক ও সেটিংস"
                >
                  সিঙ্ক অপশন
                </button>
              </div>
            </div>

            {currentUser ? (
              <div className="p-3 rounded-xl bg-white/80 dark:bg-slate-800/80 border border-blue-100 dark:border-blue-900/40 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  {currentUser.photoURL ? (
                    <img src={currentUser.photoURL} alt="" className="w-8 h-8 rounded-full ring-2 ring-emerald-500 shrink-0 object-cover" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-xs shrink-0">
                      {(currentUser.displayName || currentUser.email || 'U')[0].toUpperCase()}
                    </div>
                  )}
                  <div className="min-w-0 text-xs">
                    <div className="font-bold text-slate-800 dark:text-white truncate">
                      {currentUser.displayName || 'গুগল ব্যবহারকারী'}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {currentUser.email}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleGoogleLogout}
                  className="text-xs font-bold text-red-500 hover:text-red-600 px-2 py-1 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors shrink-0 flex items-center gap-1"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>লগআউট</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  অন্য যেকোনো অ্যাপের মতো আপনার গুগল অ্যাকাউন্ট দিয়ে লগইন করে রাখুন। আপনার সমস্ত ফ্ল্যাশ কার্ড ও ফোল্ডার স্বয়ংক্রিয়ভাবে ক্লাউডে সেভ থাকবে। নতুন ফোনে অ্যাপ নিলেও শুধু লগইন করলেই সবকিছু নিমেষেই ফিরে আসবে।
                </p>
                <button
                  type="button"
                  onClick={handleGoogleLogin}
                  disabled={isSigningIn}
                  className="w-full flex items-center justify-center gap-2 bg-white hover:bg-slate-50 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white py-2.5 px-3 rounded-xl font-bold text-xs shadow-xs border border-slate-200 dark:border-slate-700 transition-all cursor-pointer active:scale-98 disabled:opacity-50"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.15z"/>
                    <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.28v3.15C3.27 21.36 7.35 24 12 24z"/>
                    <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.28C.46 8.2.0 10.04.0 12c0 1.96.46 3.8 1.28 5.42l4-3.15z"/>
                    <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.27 2.64 1.28 6.58l4 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
                  </svg>
                  <span>{isSigningIn ? 'লগইন হচ্ছে...' : 'Google দিয়ে সাইন-ইন করুন (স্বয়ংক্রিয় ব্যাকআপ)'}</span>
                </button>
              </div>
            )}
          </div>

          {/* AppsGeyser & APK Live Automatic Updates Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-teal-50/90 via-emerald-50/60 to-blue-50/40 dark:from-slate-900 dark:via-teal-950/40 dark:to-slate-800 border border-teal-200/90 dark:border-teal-800/60 shadow-xs space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  AppsGeyser ও APK লাইভ অটোমেটিক আপডেট
                  <span className="text-[10px] bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-300 font-bold px-2 py-0.5 rounded-full">
                    স্বয়ংক্রিয়
                  </span>
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  ক্লাউডের সাথে সরাসরি যুক্ত • নতুন কোড ও ফিচার অটোমেটিক লোড হয়
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              AppsGeyser দিয়ে তৈরি করা APK সরাসরি আমাদের লাইভ ওয়েবসাইটের সাথে যুক্ত। যখনই কোনো নতুন ফিচার বা আপডেট দেওয়া হয়, আপনার অ্যাপে তা স্বয়ংক্রিয়ভাবে লোড হয়ে যাবে। যদি কখনো পরিবর্তন দেখতে দেরি হয়, নিচের বাটনে একবার ট্যাপ করলেই ক্যাশ পরিষ্কার করে নতুন লাইভ ভার্সন লোড হবে।
            </p>

            <button
              type="button"
              onClick={handleTriggerAppUpdate}
              disabled={isRefreshingUpdate}
              className="w-full py-2.5 px-3 bg-teal-600 hover:bg-teal-700 active:scale-98 text-white font-bold rounded-xl text-xs transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshingUpdate ? 'animate-spin' : ''}`} />
              <span>{isRefreshingUpdate ? 'নতুন সংস্করণ লোড হচ্ছে...' : '🔄 নতুন আপডেট চেক করুন ও রিফ্রেশ করুন'}</span>
            </button>
          </div>

          {/* APK & Isolated Phone Storage Section */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-indigo-50/90 via-blue-50/60 to-purple-50/40 dark:from-indigo-950/40 dark:via-slate-800/70 dark:to-blue-950/30 border border-indigo-200/90 dark:border-indigo-800/60 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    আলাদা অ্যাপ (APK) ও ফোন স্টোরেজ
                    {isInstalled && (
                      <span className="text-[10px] bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 font-bold px-2 py-0.5 rounded-full">
                        সক্রিয়
                      </span>
                    )}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    ক্রোমের সাথে সম্পর্কহীন • সম্পূর্ণ ফোনের ভেতরে সংরক্ষিত
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowPwaInstallModal(true)}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer shrink-0"
              >
                {isInstalled ? 'স্টোরেজ দেখুন' : 'অ্যাপ ইনস্টল করুন'}
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-3">
              {isInstalled
                ? 'অ্যাপটি বর্তমানে একটি পূর্ণাঙ্গ স্বতন্ত্র অ্যাপ (WebAPK) হিসেবে ফোনের অভ্যন্তরে নিজস্ব জায়গায় সংরক্ষিত। ক্রোম ব্রাউজার ডিলিট বা ক্যাশ ক্লিয়ার করলেও ভেতরের ছবি ও ডাটা অক্ষত থাকবে।'
                : 'এটি সাধারণ কোনো ব্রাউজার শর্টকাট নয়। ইনস্টল করলে অ্যান্ড্রয়েড এর নিজস্ব WebAPK প্রযুক্তি ব্যবহার করে ফোনে সম্পূর্ণ আলাদা অ্যাপ হিসেবে স্থাপন করবে এবং নিজস্ব মেমোরি ব্যবহার করবে।'}
            </p>

            {/* Storage Info Details */}
            <div className="p-3 rounded-xl bg-white/70 dark:bg-slate-900/60 border border-indigo-100 dark:border-indigo-900/40 text-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-indigo-500" /> ফোনের নিজস্ব মেমোরি ব্যবহার:
                </span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">
                  {storageInfo?.usageMB || '0.0'} MB
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" /> অটো-ডিলিট সুরক্ষা (Persistence):
                </span>
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                  {storageInfo?.isPersisted ? 'সুরক্ষিত (Permanent)' : 'স্বয়ংক্রিয় লক সক্রিয়'}
                </span>
              </div>
            </div>

            {/* Mobile Status Bar / Notch Gap Control */}
            <div className="pt-3 border-t border-indigo-100/60 dark:border-indigo-900/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-indigo-500" />
                  স্ট্যাটাস বার / ওয়াইফাই সেফ স্পেস (APK & Notch)
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold">
                  {notchMode === 'auto' ? 'স্মার্ট অটো' : notchMode}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
                অ্যাপে ওপরের ওয়াইফাই, চার্জিং বা ক্যামেরা নচ আইকন বাটনের ওপর চলে আসলে ফাঁকা জায়গা বাড়ান:
              </p>
              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {[
                  { id: 'auto', label: 'অটো (৩৬px)' },
                  { id: 'standard', label: 'স্ট্যান্ডার্ড' },
                  { id: 'tall', label: 'বেশি (৪৮px)' },
                  { id: 'none', label: 'বন্ধ (০px)' }
                ].map(item => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setNotchSetting(item.id as NotchSetting);
                      setNotchMode(item.id as NotchSetting);
                      if (setAlertMsg) setAlertMsg(`স্ট্যাটাস বার স্পেস সেট করা হয়েছে: ${item.label}`);
                    }}
                    className={`py-1.5 px-1 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                      notchMode === item.id
                        ? 'bg-blue-600 text-white border-blue-500 shadow-xs'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {/* Bottom Nav / Back-Home button clearance */}
              <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    নিচের নেভিগেশন বার স্পেস (ব্যাক/হোম বাটন)
                  </span>
                  <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full">
                    {bottomNavMode}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight mb-2">
                  ফোনের ব্যাক ও হোম বাটন যাতে স্টাডি মোডের বাটনের সাথে সংঘর্ষ না করে, সেজন্য স্পেস নিয়ন্ত্রণ করুন:
                </p>
                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { id: 'auto', label: 'স্বয়ংক্রিয় (৫৮px)' },
                    { id: 'tall', label: 'বেশি (৭৬px)' },
                    { id: 'extra', label: 'সর্বোচ্চ (৯২px)' },
                    { id: 'compact', label: 'ছোট (৩৬px)' }
                  ].map(item => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setBottomNavSetting(item.id as BottomNavSetting);
                        setBottomNavMode(item.id as BottomNavSetting);
                        if (setAlertMsg) setAlertMsg(`নিচের নেভিগেশন স্পেস: ${item.label}`);
                      }}
                      className={`py-1.5 px-1 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                        bottomNavMode === item.id
                          ? 'bg-emerald-600 text-white border-emerald-500 shadow-xs'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Main Requested Feature: Manual Backup & Export Section */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-blue-50/90 via-indigo-50/40 to-slate-50 dark:from-blue-950/40 dark:via-slate-800/60 dark:to-indigo-950/30 border border-blue-200/90 dark:border-blue-800/60 shadow-xs relative overflow-hidden">
            <div className="flex items-center gap-2.5 mb-2">
              <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                <FileJson className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                  ম্যানুয়াল ব্যাকআপ এক্সপোর্ট (JSON)
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  অফলাইনে নিজের কাছে সম্পূর্ণ ডাটা সংরক্ষণ করুন
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-3">
              আপনার তৈরি করা সকল ফ্ল্যাশকার্ড (ইমেজ, মাস্ক ও প্রগ্রেস) এবং ফোল্ডারের বর্তমান অবস্থা একটি একক <span className="font-mono font-semibold text-blue-600 dark:text-blue-400 bg-blue-100/60 dark:bg-blue-900/40 px-1.5 py-0.5 rounded text-[11px]">.json</span> ফাইল আকারে ডাউনলোড করে পেনড্রাইভ, গুগল ড্রাইভ বা ডিভাইসে সংরক্ষণ করতে পারেন।
            </p>

            {/* Current State Snapshot Badges */}
            <div className="flex items-center gap-2 flex-wrap mb-4">
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-2xs">
                <FolderIcon className="w-3.5 h-3.5 text-amber-500" />
                {folders.length} টি ফোল্ডার
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-2xs">
                <Layers className="w-3.5 h-3.5 text-blue-500" />
                {cards.length} টি কার্ড
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-2xs">
                <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                {totalMasks} টি মাস্ক
              </span>
            </div>

            {/* Direct Copy Success Confirmation */}
            {copiedDirectSuccess && (
              <div className="mb-3 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/80 text-emerald-800 dark:text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in">
                <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 stroke-[2.5]" />
                <span className="font-semibold">সম্পূর্ণ ব্যাকআপ ক্লিপবোর্ডে কপি হয়েছে! নোটপ্যাডে পেস্ট করে রাখুন।</span>
              </div>
            )}

            {/* Files and Media / Storage Zero-Permission Notice */}
            <div className="mb-3 p-3 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 dark:from-emerald-950/50 dark:via-teal-950/40 dark:to-emerald-950/50 border border-emerald-300 dark:border-emerald-800/80 text-[11px] text-emerald-950 dark:text-emerald-100 leading-relaxed flex items-start gap-2 shadow-2xs">
              <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Files and media পারমিশন ছাড়াই শতভাগ কার্যকর:</strong> আপনার ফোনের অ্যাপ সেটিংসে 'Files and media' পারমিশন অপশন নেই (শুধুমাত্র ক্যামেরা আছে)? কোনো চিন্তা নেই! <strong>"ক্লিপবোর্ডে কপি"</strong> এবং <strong>"টেক্সট পেস্ট করে রিস্টোর"</strong> ব্যবহারের মাধ্যমে কোনো প্রকার ফোন পারমিশন ছাড়াই সমস্ত ব্যাকআপ নিরাপদে সেভ ও ফিরিয়ে আনা যাবে।
              </span>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <button
                  type="button"
                  onClick={handleExportJSON}
                  className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 active:scale-[0.98] text-white px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm shadow-md shadow-blue-500/25 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4 stroke-[2.5]" />
                  <span>ব্যাকআপ এক্সপোর্ট ও সেভ</span>
                </button>

                <button
                  type="button"
                  onClick={handleDirectCopyBackup}
                  disabled={isCopyingDirect}
                  className="flex items-center justify-center gap-1.5 bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 dark:hover:bg-blue-900/50 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 px-3.5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer active:scale-98 shrink-0"
                  title="কোনো পারমিশন ছাড়া সরাসরি ক্লিপবোর্ডে কপি করুন"
                >
                  <Copy className="w-4 h-4" />
                  <span>{copiedDirectSuccess ? 'কপি হয়েছে' : 'ক্লিপবোর্ডে কপি'}</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 active:scale-[0.98] text-slate-700 dark:text-slate-200 px-3 py-2 rounded-xl font-semibold text-xs border border-slate-200 dark:border-slate-700 shadow-2xs transition-all cursor-pointer"
                  title="পূর্ববর্তী ব্যাকআপ ফাইল রিস্টোর করুন"
                >
                  <Upload className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                  <span>ফাইল থেকে রিস্টোর</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowPasteRestoreModal(true)}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 active:scale-[0.98] text-slate-700 dark:text-slate-200 px-3 py-2 rounded-xl font-semibold text-xs border border-slate-200 dark:border-slate-700 shadow-2xs transition-all cursor-pointer"
                  title="কপি করা ব্যাকআপ টেক্সট পেস্ট করে রিস্টোর করুন"
                >
                  <ClipboardPaste className="w-3.5 h-3.5 text-amber-500" />
                  <span>টেক্সট পেস্ট করে রিস্টোর</span>
                </button>
              </div>
            </div>

            {/* Google Drive Deep Recovery Button in Settings */}
            <div className="pt-2.5 mt-2.5 border-t border-blue-100 dark:border-slate-700/60 flex flex-col sm:flex-row gap-2">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  openDeepRecoveryModal();
                }}
                className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-purple-50 to-indigo-50 hover:from-purple-100 hover:to-indigo-100 dark:from-purple-950/40 dark:to-indigo-950/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800/60 px-3.5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer active:scale-98 shadow-2xs"
                title="নতুন ডিভাইসে ভুলবশত ০টি কার্ড ব্যাকআপ হয়ে থাকলে আগের সব কার্ড উদ্ধার করুন"
              >
                <History className="w-4 h-4 text-purple-600 dark:text-purple-400 shrink-0" />
                <span>🔍 গুগল ড্রাইভ ডিপ রিকভারি (হারানো কার্ড উদ্ধার)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  openSyncModal('drive');
                }}
                className="flex items-center justify-center gap-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 px-3 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer active:scale-98 shadow-2xs shrink-0"
              >
                <HardDrive className="w-4 h-4 text-amber-500 shrink-0" />
                <span>ড্রাইভ ব্যাকআপ</span>
              </button>
            </div>
          </div>

          {/* Section 2: Appearance & Theme Settings */}
          <div className="space-y-3">
            {toggleDarkMode && (
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-700/30 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-slate-700 text-amber-600 dark:text-amber-300 flex items-center justify-center">
                    {darkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                      ডিসপ্লে থিম
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {darkMode ? 'ডার্ক মোড সক্রিয় আছে' : 'লাইট মোড সক্রিয় আছে'}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={toggleDarkMode}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    darkMode ? 'bg-blue-600' : 'bg-slate-300'
                  }`}
                  role="switch"
                  aria-checked={darkMode}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      darkMode ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            )}

            {/* Eye Comfort Shield / Night Light System Settings */}
            <div className={`p-4 rounded-2xl border transition-all duration-300 ${
              isEyeComfortOn 
                ? 'bg-amber-500/10 dark:bg-amber-500/15 border-amber-400/60 dark:border-amber-500/40 shadow-xs' 
                : 'bg-slate-50 dark:bg-slate-700/30 border-slate-200/80 dark:border-slate-700/60'
            }`}>
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                    isEyeComfortOn
                      ? 'bg-amber-500 text-white shadow-sm ring-2 ring-amber-300 dark:ring-amber-500/50'
                      : 'bg-amber-100 dark:bg-slate-700 text-amber-700 dark:text-amber-300'
                  }`}>
                    <Eye className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                        চোখের সুরক্ষা আলো (Eye Comfort Shield)
                      </h4>
                      {isEyeComfortOn && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500 text-slate-950 font-extrabold uppercase tracking-wider">
                          অন
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      স্ক্রিনের ক্ষতিকর নীল আলো কমিয়ে উষ্ণ ও আরামদায়ক আলো দেয়
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const next = toggleEyeComfort();
                    setIsEyeComfortOn(next);
                    if (setAlertMsg) {
                      setAlertMsg(next ? 'চোখের সুরক্ষা আলো সক্রিয় হয়েছে (Eye Comfort ON) 🛡️' : 'চোখের সুরক্ষা আলো বন্ধ করা হয়েছে');
                    }
                  }}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    isEyeComfortOn ? 'bg-amber-500' : 'bg-slate-300 dark:bg-slate-600'
                  }`}
                  role="switch"
                  aria-checked={isEyeComfortOn}
                  title="চোখের সুরক্ষা আলো চালু বা বন্ধ করুন"
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      isEyeComfortOn ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Advanced Controls when Enabled */}
              {isEyeComfortOn && (
                <div className="mt-4 pt-3.5 border-t border-amber-300/40 dark:border-amber-500/30 space-y-4 animate-in fade-in duration-200">
                  {/* Intensity / Warmth Slider */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-slate-700 dark:text-slate-200 flex items-center gap-1">
                        <Sliders className="w-3.5 h-3.5 text-amber-500" />
                        <span>আলোর উষ্ণতা (Warmth): {eyeComfort.intensity}%</span>
                      </span>
                      <span className="text-amber-600 dark:text-amber-400 font-bold">
                        {eyeComfort.intensity <= 20 ? 'হালকা ওয়ার্ম' : eyeComfort.intensity <= 40 ? 'সুপারিশকৃত ব্যালেন্সড' : 'গভীর নাইট শিল্ড'}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={12}
                      max={60}
                      step={2}
                      value={eyeComfort.intensity}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        saveEyeComfortSettings({ intensity: val });
                      }}
                      className="w-full accent-amber-500 h-2 bg-slate-200 dark:bg-slate-600 rounded-lg cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-400 font-medium">
                      <span>মৃদু (১২%)</span>
                      <span>ব্যালেন্সড (৩০%)</span>
                      <span>গভীর (৬০%)</span>
                    </div>
                  </div>

                  {/* Warm Light Tone Mode */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-200 block">
                      আলোর রঙ ও ধরন (Color Tone):
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => saveEyeComfortSettings({ tone: 'amber' })}
                        className={`p-2 rounded-xl text-left border text-xs font-medium transition-all cursor-pointer ${
                          eyeComfort.tone === 'amber'
                            ? 'bg-amber-100 dark:bg-amber-950/60 border-amber-500 text-amber-900 dark:text-amber-200 font-bold ring-1 ring-amber-400'
                            : 'bg-white/60 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-amber-50/50'
                        }`}
                      >
                        <div className="flex items-center gap-1 mb-0.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block shadow-xs" />
                          <span className="truncate">অ্যাম্বার গোল্ড</span>
                        </div>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400">ব্লু-লাইট শিল্ড</p>
                      </button>

                      <button
                        type="button"
                        onClick={() => saveEyeComfortSettings({ tone: 'sepia' })}
                        className={`p-2 rounded-xl text-left border text-xs font-medium transition-all cursor-pointer ${
                          eyeComfort.tone === 'sepia'
                            ? 'bg-amber-100 dark:bg-amber-950/60 border-amber-500 text-amber-900 dark:text-amber-200 font-bold ring-1 ring-amber-400'
                            : 'bg-white/60 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-amber-50/50'
                        }`}
                      >
                        <div className="flex items-center gap-1 mb-0.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-[#e3be7f] inline-block shadow-xs" />
                          <span className="truncate">রিডিং পেপার</span>
                        </div>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400">বইয়ের মতো সেপিয়া</p>
                      </button>

                      <button
                        type="button"
                        onClick={() => saveEyeComfortSettings({ tone: 'candle' })}
                        className={`p-2 rounded-xl text-left border text-xs font-medium transition-all cursor-pointer ${
                          eyeComfort.tone === 'candle'
                            ? 'bg-amber-100 dark:bg-amber-950/60 border-amber-500 text-amber-900 dark:text-amber-200 font-bold ring-1 ring-amber-400'
                            : 'bg-white/60 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-amber-50/50'
                        }`}
                      >
                        <div className="flex items-center gap-1 mb-0.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-[#f97316] inline-block shadow-xs" />
                          <span className="truncate">সফট ক্যান্ডেল</span>
                        </div>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400">রাতের মোমবাতি</p>
                      </button>
                    </div>
                  </div>

                  {/* Auto Night Schedule */}
                  <label className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-white/70 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 cursor-pointer">
                    <div className="flex items-center gap-2">
                      <Moon className="w-4 h-4 text-indigo-500" />
                      <div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-100">
                          স্বয়ংক্রিয় নাইট শিডিউল (Auto Night)
                        </p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400">
                          প্রতিদিন সন্ধ্যা ৭টা থেকে সকাল ৭টা পর্যন্ত নিজে নিজেই সক্রিয় থাকবে
                        </p>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={eyeComfort.autoNight}
                      onChange={(e) => saveEyeComfortSettings({ autoNight: e.target.checked })}
                      className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 accent-amber-500"
                    />
                  </label>
                </div>
              )}
            </div>
          </div>

          {/* Section: Speech Repetition & Pronunciation Engine */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-700/30 border border-slate-200/80 dark:border-slate-700/60 space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-300 flex items-center justify-center">
                  <Repeat className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                    <span>উচ্চারণ ও স্পিচ রিপিটেশন</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 font-bold">উন্নত</span>
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    প্রতিটি বৈজ্ঞানিক পরিভাষা কতবার পুনরাবৃত্তি হবে নির্ধারণ করুন
                  </p>
                </div>
              </div>
            </div>

            {/* Repetition Count Selector */}
            <div className="pt-2 border-t border-slate-200/70 dark:border-slate-700/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                রিপিটেশন সংখ্যা:
              </span>
              <div className="flex items-center gap-1.5 bg-white dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                {[
                  { count: 1, label: '১ বার (1x)' },
                  { count: 2, label: '২ বার (2x - প্রস্তাবিত)' },
                  { count: 3, label: '৩ বার (3x - মুখস্থ)' }
                ].map(r => (
                  <button
                    key={r.count}
                    type="button"
                    onClick={() => {
                      triggerHaptic('light');
                      const next = updateSpeechSettings({ repeatCount: r.count });
                      setSpeechSettings(next);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      speechSettings.repeatCount === r.count
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Auto-Pronounce on Reveal Toggle */}
            <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-200/70 dark:border-slate-700/60">
              <div>
                <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  আড়াল খুললেই স্বয়ংক্রিয় উচ্চারণ
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  মাস্ক বা পিনে চাপ দিলে তৎক্ষণাৎ সঠিক উচ্চারণ শুনুন
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  triggerHaptic('light');
                  const nextVal = !speechSettings.autoPronounceOnReveal;
                  const next = updateSpeechSettings({ autoPronounceOnReveal: nextVal });
                  setSpeechSettings(next);
                }}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  speechSettings.autoPronounceOnReveal ? 'bg-purple-600' : 'bg-slate-300 dark:bg-slate-600'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    speechSettings.autoPronounceOnReveal ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Tactile Haptic Vibration Toggle */}
            <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-200/70 dark:border-slate-700/60">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-slate-400" />
                <div>
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    APK স্পর্শ ভাইব্রেশন (Haptic Feedback)
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    বাটন ক্লিক ও কার্ড ফ্লিপে স্মুথ টাচ ভাইব্রেশন
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  const nextVal = !speechSettings.hapticFeedback;
                  const next = updateSpeechSettings({ hapticFeedback: nextVal });
                  setSpeechSettings(next);
                  if (nextVal) triggerHaptic('success');
                }}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  speechSettings.hapticFeedback ? 'bg-emerald-600' : 'bg-slate-300 dark:bg-slate-600'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    speechSettings.hapticFeedback ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Test Pronunciation Button */}
            <div className="pt-2 flex items-center justify-end">
              <button
                type="button"
                onClick={() => {
                  triggerHaptic('medium');
                  speakWithRepetition('মাইটোকনড্রিয়া - Mitochondria', { count: speechSettings.repeatCount });
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-purple-100 hover:bg-purple-200 dark:bg-purple-900/40 dark:hover:bg-purple-900/70 text-purple-700 dark:text-purple-300 transition-colors cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>রিপিটেশন টেস্ট শুনুন ({speechSettings.repeatCount}x)</span>
              </button>
            </div>
          </div>

          {/* Section 3: Cloud & Google Drive Backup Shortcut */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-700/30 border border-slate-200/80 dark:border-slate-700/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <HardDrive className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                  ক্লাউড ও গুগল ড্রাইভ ব্যাকআপ
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  অটো-সিঙ্ক ও স্থায়ী ড্রাইভ স্টোরেজ পরিচালনা করুন
                </p>
              </div>
            </div>

            {onOpenSync && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenSync();
                }}
                className="w-full sm:w-auto px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl font-semibold text-xs transition-all shadow-xs cursor-pointer text-center"
              >
                ড্রাইভ সিঙ্ক অপশন
              </button>
            )}
          </div>

          {/* Section 4: Image Occlusion Tutorial & Help */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-700/30 border border-slate-200/80 dark:border-slate-700/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <HelpCircle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                  ইমেজ অক্লুশন নির্দেশিকা
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  নতুনদের জন্য সহজ ভিজ্যুয়াল টিউটোরিয়াল ও ডেমো
                </p>
              </div>
            </div>

            {onOpenHelp && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenHelp();
                }}
                className="w-full sm:w-auto px-3.5 py-2 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded-xl font-semibold text-xs transition-all shadow-xs cursor-pointer text-center"
              >
                টিউটোরিয়াল দেখুন
              </button>
            )}
          </div>

          {/* Section 4: Data Security Reassurance Notice */}
          <div className="p-3.5 rounded-2xl bg-slate-100/70 dark:bg-slate-700/40 text-slate-600 dark:text-slate-300 text-xs flex items-start gap-2.5">
            <Info className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
            <p className="leading-relaxed text-[11px]">
              আপনার সম্পূর্ণ ডাটা আপনার ব্রাউজারের নিরাপদ IndexedDB-তে সংরক্ষিত থাকে। নতুন ফোন পরিবর্তন বা ব্রাউজার হিস্ট্রি মুছে ফেলার আগে নিয়মিত ম্যানুয়াল JSON ব্যাকআপ ডাউনলোড করে রাখা সুপারিশ করা হয়।
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            অফলাইন ও লোকাল স্টোরেজ নিরাপদ
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-lg font-semibold transition-colors cursor-pointer"
          >
            সম্পন্ন
          </button>
        </div>
      </div>

      <PWAInstallModal
        isOpen={showPwaInstallModal}
        onClose={() => setShowPwaInstallModal(false)}
      />

      {/* Universal File Export Modal (Provides Copy, Share, Download, Drive options with APK guidance) */}
      {exportPayload && (
        <FileExportModal
          isOpen={showExportModal}
          onClose={() => {
            setShowExportModal(false);
            setExportPayload(null);
          }}
          data={exportPayload.data}
          filename={exportPayload.filename}
          title="মেমোরি কার্ড ব্যাকআপ ও ফাইল সেভ"
          onOpenGoogleDrive={() => {
            setShowExportModal(false);
            onClose();
            openSyncModal('drive');
          }}
          onSuccess={(msg) => {
            if (setAlertMsg) setAlertMsg(msg);
          }}
        />
      )}

      {/* Paste & Restore Modal */}
      {showPasteRestoreModal && (
        <div
          className="fixed inset-0 bg-black/80 z-[100001] flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setShowPasteRestoreModal(false)}
        >
          <div
            className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                  <ClipboardPaste className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                    ব্যাকআপ টেক্সট পেস্ট করে রিস্টোর
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    কোনো ফাইল আপলোড ছাড়া সরাসরি কোড দিয়ে উদ্ধার
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowPasteRestoreModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              পূর্বে কপি করে রাখা সম্পূর্ণ JSON ব্যাকআপ টেক্সট নিচের বক্সে পেস্ট করুন। এটি আপনার ডিভাইসের সমস্ত কার্ড ও ফোল্ডার তৎক্ষণাৎ রিস্টোর করবে।
            </p>

            <textarea
              value={pastedJson}
              onChange={(e) => setPastedJson(e.target.value)}
              placeholder='এখানে ব্যাকআপ JSON কোড পেস্ট করুন...'
              rows={7}
              className="w-full p-3 text-xs font-mono rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-amber-500/30"
            />

            <div className="flex items-center gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setShowPasteRestoreModal(false)}
                className="flex-1 py-2.5 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={handleRestoreFromPastedText}
                disabled={!pastedJson.trim()}
                className="flex-1 py-2.5 text-xs font-bold rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white transition-all shadow-sm cursor-pointer"
              >
                রিস্টোর করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  return createPortal(modalContent, document.body);
}
