import React, { useState, useEffect } from 'react';
import {
  Download,
  Copy,
  Check,
  Share2,
  X,
  AlertTriangle,
  HardDrive,
  FileText,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Loader2
} from 'lucide-react';
import { copyTextToClipboard, triggerDirectDownload, triggerServerDownload, isAndroidWebView } from '../lib/fileSaveUtils';

export interface FileExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: any;
  filename: string;
  title: string;
  subtitle?: string;
  onOpenGoogleDrive?: () => void;
  onSuccess?: (msg: string) => void;
}

export default function FileExportModal({
  isOpen,
  onClose,
  data,
  filename,
  title,
  subtitle,
  onOpenGoogleDrive,
  onSuccess
}: FileExportModalProps) {
  const [copied, setCopied] = useState(false);
  const [downloadTriggered, setDownloadTriggered] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const [showRawText, setShowRawText] = useState(false);

  const jsonContent = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
  const dataSizeKb = Math.max(1, Math.round(jsonContent.length / 1024));
  const isWebView = isAndroidWebView();

  // Auto-copy to clipboard on mount for immediate 100% zero-permission safety
  useEffect(() => {
    if (isOpen) {
      copyTextToClipboard(jsonContent).then((ok) => {
        if (ok) {
          setCopied(true);
        }
      });
    }
  }, [isOpen, jsonContent]);

  if (!isOpen) return null;

  const handleCopy = async () => {
    const success = await copyTextToClipboard(jsonContent);
    if (success) {
      setCopied(true);
      onSuccess?.('সম্পূর্ণ ব্যাকআপ ডাটা ক্লিপবোর্ডে কপি হয়েছে!');
      setTimeout(() => setCopied(false), 5000);
    }
  };

  const handleShare = async () => {
    setIsSharing(true);
    try {
      if (typeof navigator !== 'undefined' && navigator.canShare && typeof File !== 'undefined') {
        const file = new File([jsonContent], filename, { type: 'application/json' });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: title,
            text: `${title} - Image Occlusion Flashcards`
          });
          onSuccess?.('সফলভাবে শেয়ার করা হয়েছে!');
          return;
        }
      }

      // Fallback share with text or clipboard
      if (typeof navigator !== 'undefined' && navigator.share) {
        await navigator.share({
          title: title,
          text: jsonContent.length < 40000 ? jsonContent : `${title} ব্যাকআপ ফাইল (${filename})`
        });
        onSuccess?.('সফলভাবে শেয়ার করা হয়েছে!');
      } else {
        await handleCopy();
      }
    } catch (err: any) {
      if (err?.name !== 'AbortError') {
        // If share fails, fallback to copy
        await handleCopy();
      }
    } finally {
      setIsSharing(false);
    }
  };

  const handleDownload = async () => {
    // 1. Always safeguard clipboard first so user never loses their data
    await handleCopy();
    setIsDownloading(true);

    try {
      // 2. Use server-side HTTPS download so Android DownloadManager receives a valid HTTPS URL (NOT blob:)
      // Android DownloadManager fails with "Download failed" when given blob: URLs.
      const serverOk = await triggerServerDownload(filename, jsonContent, 'application/json');
      if (serverOk) {
        setDownloadTriggered(true);
        setTimeout(() => setDownloadTriggered(false), 8000);
        onSuccess?.('ডাউনলোড রিকোয়েস্ট সফল! নোটিফিকেশন বার বা ডাউনলোড ফোল্ডার দেখুন।');
        return;
      }
    } catch (e) {
      console.warn('Server download attempt failed, falling back:', e);
    } finally {
      setIsDownloading(false);
    }

    // 3. Fallback direct download
    const ok = triggerDirectDownload(filename, jsonContent, 'application/json');
    if (ok) {
      setDownloadTriggered(true);
      setTimeout(() => setDownloadTriggered(false), 6000);
      onSuccess?.('ফাইল ডাউনলোড শুরু হয়েছে!');
    }
  };

  return (
    <div
      className="fixed inset-0 z-[100000] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200/90 dark:border-slate-800 relative max-h-[92vh] overflow-y-auto text-slate-800 dark:text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors cursor-pointer"
          title="বন্ধ করুন"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 mb-4 pb-3.5 border-b border-slate-100 dark:border-slate-800">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20 shrink-0">
            <Download className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div className="min-w-0 pr-6">
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white truncate">
              {title}
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 truncate">
              <span className="font-mono">{filename}</span>
              <span>•</span>
              <span>~{dataSizeKb} KB</span>
            </div>
          </div>
        </div>

        {/* Zero-Permission Built-in Guarantee Banner */}
        <div className="mb-4 p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 dark:from-emerald-950/50 dark:via-teal-950/40 dark:to-emerald-950/50 border border-emerald-300 dark:border-emerald-800/80 text-emerald-950 dark:text-emerald-100 text-xs space-y-1.5 shadow-2xs">
          <div className="flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-300">
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>কোনো "Files and media" পারমিশন প্রয়োজন নেই</span>
            <span className="text-[10px] bg-emerald-200/70 dark:bg-emerald-800/70 text-emerald-900 dark:text-emerald-200 px-2 py-0.2 rounded-full font-bold ml-auto">
              বিল্ট-ইন ফিক্স
            </span>
          </div>
          <p className="text-[11px] sm:text-xs text-emerald-900/90 dark:text-emerald-200/90 leading-relaxed">
            আপনার ফোনের অ্যাপ সেটিংসে <strong>"Files and media"</strong> পারমিশন অপশন নেই (শুধুমাত্র ক্যামেরা আছে)? কোনো সমস্যা নেই! ব্যাকআপ এবং রিস্টোরের যাবতীয় কাজ <strong>কোনো প্রকার স্টোরেজ অনুমতি ছাড়াই</strong> অ্যাপের অভ্যন্তরে সরাসরি সম্পন্ন করার ব্যবস্থা করা হয়েছে।
          </p>
        </div>

        {/* Copy Feedback Alert */}
        {copied && (
          <div className="mb-4 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-900 dark:text-emerald-200 text-xs flex items-start gap-2.5 animate-in fade-in duration-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold flex items-center gap-1.5">
                <span>সম্পূর্ণ ব্যাকআপ কোড স্বয়ংক্রিয়ভাবে কপি হয়েছে!</span>
                <span className="text-[10px] bg-emerald-600 text-white px-1.5 py-0.2 rounded font-mono font-normal">১০০% প্রস্তুত</span>
              </div>
              <div className="text-[11px] text-emerald-800/90 dark:text-emerald-300/90 mt-0.5">
                আপনার ফোনের Google Keep Notes, Notepad অথবা যেকোনো নোট অ্যাপে পেস্ট করে রাখুন। পরবর্তীতে <strong>"টেক্সট পেস্ট করে রিস্টোর"</strong> দিয়ে যেকোনো সময় ফিরিয়ে আনতে পারবেন।
              </div>
            </div>
          </div>
        )}

        {/* Download Trigger Alert */}
        {downloadTriggered && (
          <div className="mb-4 p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-200 text-xs flex items-start gap-2.5 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold">
                {isWebView ? 'ব্যাকআপ ডাটা ক্লিপবোর্ডে সংরক্ষিত হয়েছে!' : 'ফাইল ডাউনলোড অনুরোধ পাঠানো হয়েছে!'}
              </div>
              <div className="text-[11px] text-blue-800/90 dark:text-blue-300/90 mt-0.5">
                {isWebView
                  ? 'এই APK-তে স্টোরেজ পারমিশনের কোনো ঝামেলা ছাড়াই ডাটা ক্লিপবোর্ডে কপি রয়েছে। সরাসরি পেস্ট করে সংরক্ষণ করুন।'
                  : 'ডাউনলোড ফোল্ডারে .json ফাইলটি সেভ হবে।'}
              </div>
            </div>
          </div>
        )}

        {/* Action Options */}
        <div className="space-y-2.5 mb-4">
          {/* Option 1: Copy Backup Code (Recommended & 100% Reliable without permissions) */}
          <div
            onClick={handleCopy}
            className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer group ${
              copied
                ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30'
                : 'border-blue-500 bg-blue-50/60 dark:bg-blue-950/40 hover:bg-blue-100/60 dark:hover:bg-blue-900/50 shadow-sm'
            }`}
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    copied
                      ? 'bg-emerald-500 text-white'
                      : 'bg-blue-600 text-white group-hover:scale-105 transition-transform'
                  }`}
                >
                  {copied ? <Check className="w-5 h-5 stroke-[2.5]" /> : <Copy className="w-5 h-5" />}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-sm text-slate-900 dark:text-white">
                      ১. ক্লিপবোর্ডে ব্যাকআপ কপি করুন
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-600 text-white">
                      কোনো পারমিশন লাগে না • ১০০% সফল
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
                    এক ক্লিকেই কপি হয়ে যাবে, ফোনের নোটপ্যাড বা কিপ নোটসে পেস্ট করে রাখুন
                  </p>
                </div>
              </div>

              <button
                type="button"
                className={`px-3 py-1.5 rounded-xl font-bold text-xs shrink-0 transition-colors ${
                  copied
                    ? 'bg-emerald-600 text-white'
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
              >
                {copied ? 'কপি হয়েছে!' : 'কপি করুন'}
              </button>
            </div>
          </div>

          {/* Option 2: Share via Web Share API */}
          <div
            onClick={handleShare}
            className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-purple-400 dark:hover:border-purple-600 bg-slate-50/70 dark:bg-slate-800/60 hover:bg-purple-50/50 dark:hover:bg-purple-950/30 transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                  <Share2 className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">
                    ২. অন্য অ্যাপে শেয়ার করুন (Share)
                  </span>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    গুগল ড্রাইভ, হোয়াটসঅ্যাপ বা জিমেইলে সরাসরি ফাইল বা টেক্সট পাঠান
                  </p>
                </div>
              </div>
              <button
                type="button"
                disabled={isSharing}
                className="px-3 py-1.5 rounded-xl font-bold text-xs bg-purple-600 hover:bg-purple-700 text-white shrink-0 cursor-pointer"
              >
                শেয়ার করুন
              </button>
            </div>
          </div>

          {/* Option 3: Direct File Download via Server HTTPS */}
          <div
            onClick={handleDownload}
            className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-600 bg-slate-50/70 dark:bg-slate-800/60 hover:bg-blue-50/40 dark:hover:bg-blue-950/30 transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                  {isDownloading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">
                    ৩. ফাইল ডাউনলোড (HTTPS Download)
                  </span>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    সার্ভার থেকে সরাসরি .json ফাইল আপনার ডিভাইসে ডাউনলোড করুন
                  </p>
                </div>
              </div>
              <button
                type="button"
                disabled={isDownloading}
                className="px-3 py-1.5 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-700 text-white shrink-0 cursor-pointer flex items-center gap-1.5"
              >
                {isDownloading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{isDownloading ? 'প্রসেস হচ্ছে...' : 'ডাউনলোড'}</span>
              </button>
            </div>
          </div>

          {/* Android / APK Download Safeguard Tip */}
          <div className="p-3 rounded-2xl bg-amber-50/80 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-900/60 text-[11px] text-amber-900 dark:text-amber-200 leading-relaxed flex items-start gap-2">
            <span className="text-sm">💡</span>
            <div>
              <strong>ফোনে "Download failed" নোটিফিকেশন আসলে কি করবেন?</strong>
              <div className="mt-0.5 text-amber-800/90 dark:text-amber-300/90">
                AppsGeyser বা APK অ্যাপে স্টোরেজ পারমিশন না থাকলে সিস্টেম "download failed" দেখাতে পারে। কোনো সমস্যা নেই! ওপরের <strong>"১. ক্লিপবোর্ডে ব্যাকআপ কপি করুন"</strong> বাটনে চাপ দিন (ডাটা ইতোমধ্যে আপনার ক্লিপবোর্ডে সংরক্ষিত) অথবা <strong>"২. শেয়ার করুন"</strong> দিয়ে গুগল ড্রাইভে সেভ করে রাখুন।
              </div>
            </div>
          </div>

          {/* Option 4: Google Drive Cloud Backup (If callback provided) */}
          {onOpenGoogleDrive && (
            <div
              onClick={() => {
                onClose();
                onOpenGoogleDrive();
              }}
              className="p-3.5 rounded-2xl border border-amber-200 dark:border-amber-900/60 hover:border-amber-400 dark:hover:border-amber-600 bg-amber-50/40 dark:bg-amber-950/20 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900/50 text-amber-600 dark:text-amber-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <HardDrive className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <span className="font-bold text-sm text-slate-900 dark:text-white">
                      ৪. গুগল ড্রাইভে ক্লাউড ব্যাকআপ
                    </span>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      লোকাল মেমোরি ছাড়াই সরাসরি আপনার গুগল একাউন্টে ক্লাউডে সেভ করুন
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  className="px-3 py-1.5 rounded-xl font-bold text-xs bg-amber-600 hover:bg-amber-700 text-white shrink-0 cursor-pointer"
                >
                  ড্রাইভ খুলুন
                </button>
              </div>
            </div>
          )}
        </div>

        {/* View Raw JSON Text Expander */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setShowRawText(!showRawText)}
            className="w-full flex items-center justify-between py-2 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer font-medium"
          >
            <span className="flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5" />
              <span>ব্যাকআপ কোড সরাসরি দেখুন ও কপি করুন</span>
            </span>
            {showRawText ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showRawText && (
            <div className="mt-2 space-y-2 animate-in fade-in">
              <div className="relative">
                <textarea
                  readOnly
                  value={jsonContent}
                  rows={6}
                  className="w-full p-2.5 text-[11px] font-mono rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 focus:outline-hidden"
                  onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                />
              </div>
              <button
                type="button"
                onClick={handleCopy}
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>সম্পূর্ণ কোড কপি করুন</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
