import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Save, Image as ImageIcon, Camera, Undo2, Loader2, Move, Eraser, Check, 
  Eye, EyeOff, Sparkles, Hand, PenTool, RotateCw, FlipHorizontal, FlipVertical, 
  Crop as CropIcon, MapPin, MousePointer, Square, HelpCircle, Layers, Maximize2, 
  Minimize2, ChevronDown, ChevronUp, Trash2, ListOrdered, Sun, Edit3, Volume2, 
  ArrowUp, ArrowDown, Split, Images, FileImage, Sliders, CheckSquare, Plus,
  Zap, CheckCircle2, Hash, ClipboardPaste
} from 'lucide-react';
import ReactCrop, { type Crop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import { Card, Rectangle, Pin } from '../types';
import { TagInput } from './TagComponents';
import OcclusionHelpModal from './OcclusionHelpModal';
import ImageEnhanceModal from './ImageEnhanceModal';
import { computeCollisionFreeSideBadges } from '../lib/badgeLayout';

export interface ImageBatchItem {
  id: string;
  image: string;
  title: string;
  rectangles: Rectangle[];
  pins: Pin[];
  notes: string;
  tags: string[];
  isAiProcessed?: boolean;
}

interface CreateCardProps {
  folderId: number | null;
  editingCard?: Card;
  existingTags?: string[];
  onSave: (card: Card) => void;
  onCancel: () => void;
  onSkip?: () => void;
  isBulkEdit?: boolean;
  bulkRemaining?: number;
  onBulkCreate?: (cards: Card[]) => void;
}

export default function CreateCard({ folderId, editingCard, existingTags, onSave, onCancel, onSkip, isBulkEdit, bulkRemaining, onBulkCreate }: CreateCardProps) {
  const [title, setTitle] = useState(editingCard?.title || '');
  const [notes, setNotes] = useState(editingCard?.notes || '');
  const [tags, setTags] = useState<string[]>(editingCard?.tags || []);
  const [image, setImage] = useState<string | null>(editingCard?.image || null);
  const [lastProcessedImage, setLastProcessedImage] = useState<string | null>(editingCard?.image || null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [rectangles, setRectangles] = useState<Rectangle[]>(editingCard?.rectangles || []);
  const [pins, setPins] = useState<Pin[]>(editingCard?.pins || []);
  const [cardBadgePosition, setCardBadgePosition] = useState<'auto' | 'left' | 'inside' | 'right'>(editingCard?.badgePosition || 'auto');
  const [showBadges, setShowBadges] = useState<boolean>(editingCard?.showBadges !== undefined ? editingCard.showBadges : false); // Initially off for new cards
  const [cardBadgeDistance, setCardBadgeDistance] = useState<'normal' | 'far' | 'margin'>(editingCard?.badgeDistance || 'far');
  const [toolMode, setToolMode] = useState<'mask' | 'pin'>('mask');
  const [pinPrompt, setPinPrompt] = useState<{x: number, y: number, label: string} | null>(null);
  const [isGeneratingNotes, setIsGeneratingNotes] = useState(false);
  const [isAutoFilling, setIsAutoFilling] = useState(false);
    
  // Multi-Image Batch state
  const [imageBatch, setImageBatch] = useState<ImageBatchItem[]>([]);
  const [activeBatchIndex, setActiveBatchIndex] = useState<number>(0);
  const [isBatchProcessingAi, setIsBatchProcessingAi] = useState(false);

  // 3rd Option: Full Auto Bulk Processing Engine state
  const [isAutoBulkActive, setIsAutoBulkActive] = useState(false);
  const [autoBulkProgress, setAutoBulkProgress] = useState<{ current: number; total: number; title: string; step: string }>({
    current: 0,
    total: 0,
    title: '',
    step: ''
  });
  const [autoBulkCompletedCards, setAutoBulkCompletedCards] = useState<Card[]>([]);
  const [showAutoBulkSummary, setShowAutoBulkSummary] = useState(false);

  // Mask Edit & Layer Selection state
  const [selectedRectId, setSelectedRectId] = useState<number | null>(null);
  const [hoveredRectId, setHoveredRectId] = useState<number | null>(null);
  const [editingRectModal, setEditingRectModal] = useState<Rectangle | null>(null);
  const [overlappedPicker, setOverlappedPicker] = useState<{ x: number; y: number; rects: Rectangle[] } | null>(null);
  const [showLayersManager, setShowLayersManager] = useState(true);

  const safeParseJson = async (res: Response) => {
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch (e) {
      console.error('Invalid JSON response:', text.substring(0, 100));
      throw new Error('এআই দিয়ে টেক্সট শনাক্ত করতে সমস্যা হয়েছে। সার্ভার থেকে ভুল রেসপন্স এসেছে।');
    }
  };

  const handleAutoFillMetadata = async () => {
    if (!image) {
      setAlertMsg('AI অটো-ফিল করতে প্রথমে একটি ছবি সিলেক্ট করুন।');
      return;
    }
    setIsAutoFilling(true);
    try {
      const res = await fetch('/api/suggest-card-metadata', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: image })
      });
      const data = await res.json();
      if (data.title) {
        setTitle(data.title);
      }
      // Note: User explicitly requested tags should NOT be auto-filled by AI
      if (data.summary && !notes) {
        setNotes(`📌 ${data.summary}`);
      }
      setAlertMsg(`AI দ্বারা কার্ডের শিরোনাম ("${data.title || ''}") সফলভাবে সনাক্ত করা হয়েছে!`);
      setTimeout(() => setAlertMsg(''), 3000);
    } catch (err) {
      setAlertMsg('AI অটো-ফিলে সমস্যা হয়েছে।');
    } finally {
      setIsAutoFilling(false);
    }
  };

  const handleGenerateAiNotes = async () => {
    if (!image) {
      setAlertMsg('AI নোট তৈরি করতে প্রথমে একটি ছবি সিলেক্ট করুন।');
      return;
    }
    setIsGeneratingNotes(true);
    try {
      const res = await fetch('/api/generate-card-notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: image,
          title: title.trim() || 'Untitled'
        })
      });
      const data = await res.json();
      if (data.notes) {
        setNotes(prev => prev ? `${prev}\n\n${data.notes}` : data.notes);
        setAlertMsg('AI দ্বারা তৈরি স্মার্ট স্টাডি নোট যোগ করা হয়েছে!');
        setTimeout(() => setAlertMsg(''), 2500);
      } else {
        setAlertMsg(data.error || 'নোট তৈরি করা যায়নি।');
      }
    } catch (err) {
      setAlertMsg('সার্ভারে যোগাযোগ করতে ব্যর্থ হয়েছে।');
    } finally {
      setIsGeneratingNotes(false);
    }
  };
  const [alertMsg, setAlertMsg] = useState('');
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [showHintBanner, setShowHintBanner] = useState(true);

  // First-time user onboarding check for Image Occlusion
  useEffect(() => {
    try {
      const seen = localStorage.getItem('seen_occlusion_guide');
      if (!seen) {
        setShowHelpModal(true);
      }
    } catch (e) {
      // ignore localStorage restriction
    }
  }, []);
  
  // Crop states
  const [isCropModal, setIsCropModal] = useState(false);
  const [isEnhanceModal, setIsEnhanceModal] = useState(false);
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<any>();
  const cropImageRef = useRef<HTMLImageElement>(null);
  
  // Eraser states
  const [isErasingModal, setIsErasingModal] = useState(false);
  const [eraserSize, setEraserSize] = useState(20);
  const [brushColor, setBrushColor] = useState('#FFFFFF');
  const eraserCanvasRef = useRef<HTMLCanvasElement>(null);
  const [isEraserDrawing, setIsEraserDrawing] = useState(false);
  const [lastPos, setLastPos] = useState({ x: 0, y: 0 });

  // Preview state
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [isScrollMode, setIsScrollMode] = useState(false);
  const [showMaskControls, setShowMaskControls] = useState(false);
  
  const [isDrawing, setIsDrawing] = useState(false);
  const [isDragging, setIsDragging] = useState<number | null>(null);
  const [isDraggingPin, setIsDraggingPin] = useState<number | null>(null);
  const [isResizing, setIsResizing] = useState<number | null>(null);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });
  const [currentRect, setCurrentRect] = useState<Rectangle | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [pinDragOffset, setPinDragOffset] = useState({ x: 0, y: 0 });
  
  const imageRef = useRef<HTMLImageElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const processImageFiles = async (rawFiles: File[]) => {
    const validFiles = rawFiles.filter(f => f.type.match('image.*'));
    if (validFiles.length === 0) {
      if (rawFiles.length > 0) {
        setAlertMsg('দয়া করে শুধুমাত্র সাধারণ ছবি (JPG, PNG) আপলোড করুন।');
      }
      return;
    }

    setIsProcessing(true);

    let memoryFiles: File[] = [];
    try {
      memoryFiles = await Promise.all(validFiles.map(async f => {
        const buffer = await f.arrayBuffer();
        return new File([buffer], f.name, { type: f.type });
      }));
    } catch (err) {
      console.error('Failed to read files into memory:', err);
      setAlertMsg('ফাইল পড়তে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
      setIsProcessing(false);
      return;
    }

    try {
      const { compressImage } = await import('../lib/imageUtils');
      
      if (memoryFiles.length === 1 && imageBatch.length === 0) {
        // Standard single-file upload
        const file = memoryFiles[0];
        const compressedBase64 = await compressImage(file, 1600, 0.85, true);
        setImage(compressedBase64);
        if (!title.trim()) {
          const autoName = file.name.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');
          if (autoName && autoName.length > 1) {
            setTitle(autoName);
          }
        }
        setAlertMsg('ছবি আপলোড সম্পন্ন! স্পষ্টতার জন্য ব্রাইটনেস ও কনট্রাস্ট অপ্টিমাইজ করা হয়েছে।');
        setTimeout(() => setAlertMsg(''), 2500);
      } else {
        // Multi-file batch upload (or adding more images to existing batch)
        setAlertMsg(`${memoryFiles.length} টি ছবি প্রসেস ও অপ্টিমাইজ করা হচ্ছে...`);
        const newBatchItems: ImageBatchItem[] = [];
        
        for (let i = 0; i < memoryFiles.length; i++) {
          const file = memoryFiles[i];
          const autoName = file.name.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');
          let base64 = '';
          try {
            base64 = await compressImage(file, 1600, 0.85, true);
          } catch (err) {
            base64 = await new Promise<string>((resolve) => {
              const reader = new FileReader();
              reader.onload = () => resolve((reader.result as string) || '');
              reader.readAsDataURL(file);
            });
          }

          if (base64) {
            newBatchItems.push({
              id: `${Date.now()}-${i}-${Math.random().toString(36).substr(2, 6)}`,
              image: base64,
              title: autoName || `কার্ড ${imageBatch.length + i + 1}`,
              rectangles: [],
              pins: [],
              notes: '',
              tags: [...tags]
            });
          }
        }

        if (newBatchItems.length > 0) {
          // If this was an existing single image, convert it into batch item 0 first
          let combinedBatch = [...imageBatch];
          if (combinedBatch.length === 0 && image) {
            combinedBatch.push({
              id: `init-${Date.now()}`,
              image,
              title: title.trim() || 'কার্ড ১',
              rectangles: [...rectangles],
              pins: [...pins],
              notes: notes.trim(),
              tags: [...tags]
            });
          }

          combinedBatch = [...combinedBatch, ...newBatchItems];
          setImageBatch(combinedBatch);

          // If no active image, set the first item
          if (!image) {
            setActiveBatchIndex(0);
            setImage(newBatchItems[0].image);
            setTitle(newBatchItems[0].title);
            setRectangles([]);
            setPins([]);
          }

          setAlertMsg(`সাফল্যের সাথে ${newBatchItems.length} টি ছবি যুক্ত হয়েছে! উপরের স্ট্রিপ থেকে একে একে এডিট বা একসাথে AI চালাতে পারেন।`);
          setTimeout(() => setAlertMsg(''), 4000);
        }
      }
    } catch (err) {
      console.error(err);
      setAlertMsg('ছবি প্রসেস করতে ত্রুটি হয়েছে।');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawFiles: File[] = Array.from(e.target.files || []);
    await processImageFiles(rawFiles);
    e.target.value = '';
  };

  const handlePasteImageFromClipboard = async () => {
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.read) {
        const clipboardItems = await navigator.clipboard.read();
        for (const item of clipboardItems) {
          const imageType = item.types.find(type => type.startsWith('image/'));
          if (imageType) {
            const blob = await item.getType(imageType);
            const file = new File([blob], `clipboard_image_${Date.now()}.png`, { type: imageType });
            await processImageFiles([file]);
            return;
          }
        }
      }
      setAlertMsg('ক্লিপবোর্ডে কোনো ছবি পাওয়া যায়নি। প্রথমে কোনো ছবি কপি বা স্ক্রিনশট নিন, তারপর এখানে পেস্ট করুন।');
    } catch (e) {
      setAlertMsg('ক্লিপবোর্ড থেকে সরাসরি ছবি পড়ার অনুমতি মেলেনি। যেকোনো ছবি কপি করার পর স্ক্রিনে দীর্ঘক্ষণ চাপ দিয়ে পেস্ট করতে পারেন।');
    }
  };

  // Listen for global paste events (Ctrl+V / Paste)
  useEffect(() => {
    const handlePaste = async (e: ClipboardEvent) => {
      // Don't intercept paste in text inputs or textareas
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }
      const items = e.clipboardData?.items;
      if (!items) return;
      const imageFiles: File[] = [];
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) imageFiles.push(file);
        }
      }
      if (imageFiles.length > 0) {
        e.preventDefault();
        await processImageFiles(imageFiles);
      }
    };
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [imageBatch, title, image]);



  // 3rd Option: Full Auto Bulk Processing Handler (Auto Name, Notes, Masks, and Quality)
  const handleAutoBulkUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawFiles: File[] = Array.from(e.target.files || []);
    const validFiles = rawFiles.filter(f => f.type.match('image.*'));
    if (validFiles.length === 0) {
      if (rawFiles.length > 0) {
        setAlertMsg('দয়া করে শুধুমাত্র সাধারণ ছবি (JPG, PNG) আপলোড করুন।');
      }
      return;
    }

    setIsAutoBulkActive(true);
    
    // Request Wake Lock to prevent screen sleep during processing
    let wakeLock: any = null;
    try {
      if ('wakeLock' in navigator) {
        wakeLock = await (navigator as any).wakeLock.request('screen');
      }
    } catch (err) {
      console.log('WakeLock not supported or denied');
    }

    // Eagerly read all files into memory
    let memoryFiles: File[] = [];
    try {
      memoryFiles = await Promise.all(validFiles.map(async f => {
        const buffer = await f.arrayBuffer();
        return new File([buffer], f.name, { type: f.type });
      }));
    } catch (err) {
      console.error('Failed to read files into memory:', err);
      setAlertMsg('ফাইল পড়তে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
      setIsAutoBulkActive(false);
      e.target.value = '';
      if (wakeLock) { wakeLock.release().catch(()=>{}); }
      return;
    }
    setAutoBulkProgress({
      current: 0,
      total: memoryFiles.length,
      title: 'শুরু হচ্ছে...',
      step: 'ফাইল প্রস্তুতি ও হাই-কোয়ালিটি অপটিমাইজেশন...'
    });
    
    let successCount = 0;
    const processedCards: Card[] = [];

    try {
      const { compressImage } = await import('../lib/imageUtils');

      for (let i = 0; i < memoryFiles.length; i++) {
        const file = memoryFiles[i];
        const defaultTitle = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');

        setAutoBulkProgress({
          current: i + 1,
          total: memoryFiles.length,
          title: defaultTitle,
          step: 'ছবি ফিল্টারিং, কন্ট্রাস্ট ও রেজ্যুলুশন বাড়ানো হচ্ছে...'
        });

        // Step 1: Quality optimization and sharpness enhancement
        const enhancedBase64 = await compressImage(file, 1600, 0.85, true);

        setAutoBulkProgress({
          current: i + 1,
          total: memoryFiles.length,
          title: defaultTitle,
          step: 'AI দ্বারা অটো নাম, একাডেমিক স্টাডি নোট ও মাস্ক তৈরি হচ্ছে...'
        });

        // Step 2: Single-call AI processing for Title, Notes, and Occlusion Masks
        let cardTitle = defaultTitle;
        let cardNotes = '';
        let detectedMasks: Rectangle[] = [];

        try {
          const response = await fetch('/api/auto-process-diagram', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ imageBase64: enhancedBase64 })
          });

          if (response.ok) {
            const result = await response.json();
            if (result.title && result.title.trim()) {
              cardTitle = result.title.trim();
            }
            if (result.notes && result.notes.trim()) {
              cardNotes = result.notes.trim();
            }
            if (Array.isArray(result.boxes) && result.boxes.length > 0) {
              detectedMasks = result.boxes.map((b: any, bIdx: number) => {
                const w = b.xmax - b.xmin;
                const h = b.ymax - b.ymin;
                // Dynamically calculate 4-6 pixel equivalent padding based on height for Bengali matra/kar-chinhas
                const isBengali = /[\u0980-\u09FF]/.test(b.text || '');
                // Heavily increase padding for Bengali to ensure all ascenders (matra, ref) and descenders (kar-chinh) are fully masked.
                // It dynamically scales with the height but guarantees a larger absolute minimum padding.
                const padX = Math.min(12, Math.max(8, w * 0.08));
                const padY = isBengali ? Math.min(18, Math.max(12, h * 0.25)) : Math.min(10, Math.max(6, h * 0.10));
                const clampedXmin = Math.max(0, b.xmin - padX);
                const clampedYmin = Math.max(0, b.ymin - padY);
                const clampedXmax = Math.min(1000, b.xmax + padX);
                const clampedYmax = Math.min(1000, b.ymax + padY);

                return {
                  id: Date.now() + i * 10000 + bIdx,
                  x: 0,
                  y: 0,
                  width: 0,
                  height: 0,
                  xPercent: (clampedXmin / 1000) * 100,
                  yPercent: (clampedYmin / 1000) * 100,
                  widthPercent: ((clampedXmax - clampedXmin) / 1000) * 100,
                  heightPercent: ((clampedYmax - clampedYmin) / 1000) * 100,
                  label: b.text || '',
                  badgePosition: 'auto'
                };
              });
            }
          }
        } catch (aiErr) {
          console.warn('Auto AI processing error for card', i, aiErr);
        }

        const now = Date.now() + i;
        const newCard: Card = {
          id: now,
          title: cardTitle,
          notes: cardNotes,
          image: enhancedBase64,
          rectangles: detectedMasks,
          pins: [],
          tags: tags.length > 0 ? [...tags] : [],
          folderId: folderId || undefined,
          createdAt: now,
          updatedAt: now,
          badgePosition: 'auto',
          badgeDistance: 'far'
        };

        // Wait for user to review before committing to IDB
        successCount++;
        
        // Push lightweight version to memory for summary (empty image to save RAM)
        processedCards.push(newCard);
        
        // Yield to main thread to prevent UI freezing
        await new Promise(r => setTimeout(r, 100));
      }

      setAutoBulkCompletedCards(processedCards);
      setShowAutoBulkSummary(true);
      
      if (onBulkCreate) {
         onBulkCreate([]);
      }
      
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate([20, 40, 20]); } catch (_) {}
      }
      
    } catch (err) {
      console.error('Auto bulk processing error:', err);
      setAlertMsg('বাল্ক প্রসেসিংয়ে সমস্যা হয়েছে।');
    } finally {
      setIsAutoBulkActive(false);
      e.target.value = '';
      if (wakeLock) { wakeLock.release().catch(()=>{}); }
    }
  };

  const handleSaveAllAutoBulkCards = () => {
    if (autoBulkCompletedCards.length > 0) {
      if (onBulkCreate) {
        onBulkCreate(autoBulkCompletedCards);
      } else {
        autoBulkCompletedCards.forEach(c => onSave(c));
      }
      setShowAutoBulkSummary(false);
      onCancel();
    }
  };

  const handleReviewAutoBulkCards = () => {
    if (autoBulkCompletedCards.length === 0) return;
    const batchItems: ImageBatchItem[] = autoBulkCompletedCards.map(c => ({
      id: `batch-${c.id}`,
      image: c.image,
      title: c.title,
      rectangles: c.rectangles || [],
      pins: c.pins || [],
      notes: c.notes || '',
      tags: c.tags || [],
      isAiProcessed: true
    }));

    setImageBatch(batchItems);
    setActiveBatchIndex(0);
    setImage(batchItems[0].image);
    setRectangles(batchItems[0].rectangles);
    setPins(batchItems[0].pins);
    setTitle(batchItems[0].title);
    setNotes(batchItems[0].notes);
    setTags(batchItems[0].tags);
    setShowAutoBulkSummary(false);
    setAlertMsg(`${autoBulkCompletedCards.length}টি কার্ড স্বয়ংক্রিয়ভাবে লোড হয়েছে! ট্রে থেকে একে একে দেখতে বা সেভ করতে পারেন।`);
    setTimeout(() => setAlertMsg(''), 4000);
  };

  // Computes collision-free side badges and clean leader lines placed strictly in empty space (Netter Atlas Style)
  const computedSideBadges = useMemo(() => {
    if (!showBadges || cardBadgePosition === 'inside' || cardBadgePosition === 'hidden') return [];
    return computeCollisionFreeSideBadges(rectangles, cardBadgePosition);
  }, [rectangles, cardBadgePosition, showBadges]);

  // Switch between batch images while preserving edits
  const switchBatchItem = (targetIdx: number) => {
    if (targetIdx < 0 || targetIdx >= imageBatch.length || targetIdx === activeBatchIndex) return;
    
    // Save current active item into batch
    const updatedBatch = [...imageBatch];
    if (updatedBatch[activeBatchIndex]) {
      updatedBatch[activeBatchIndex] = {
        ...updatedBatch[activeBatchIndex],
        title: title.trim(),
        notes: notes.trim(),
        tags: [...tags],
        image: image || updatedBatch[activeBatchIndex].image,
        rectangles: [...rectangles],
        pins: [...pins]
      };
    }

    // Load target item into active view
    const targetItem = updatedBatch[targetIdx];
    setActiveBatchIndex(targetIdx);
    setImage(targetItem.image);
    setTitle(targetItem.title);
    setNotes(targetItem.notes || '');
    setTags(targetItem.tags || []);
    setRectangles(targetItem.rectangles || []);
    setPins(targetItem.pins || []);
    setImageBatch(updatedBatch);
    setSelectedRectId(null);
    setOverlappedPicker(null);
  };

  // Run AI text & occlusion mask detection on all uploaded batch items
  const handleBatchAiDetectAll = async () => {
    if (imageBatch.length === 0) return;
    setIsBatchProcessingAi(true);
    setAlertMsg(`AI দিয়ে মোট ${imageBatch.length} টি ছবিতে স্বয়ংক্রিয় মাস্ক তৈরি শুরু হচ্ছে...`);

    // First save current card state into batch
    const batchCopy = imageBatch.map((item, idx) => {
      if (idx === activeBatchIndex) {
        return {
          ...item,
          title: title.trim(),
          notes: notes.trim(),
          tags: [...tags],
          image: image || item.image,
          rectangles: [...rectangles],
          pins: [...pins]
        };
      }
      return item;
    });

    let successCount = 0;
    // Process concurrently in chunks of 3 to avoid rate limits
    const chunkSize = 3;
    let completedCount = 0;

    for (let i = 0; i < batchCopy.length; i += chunkSize) {
      const chunk = batchCopy.slice(i, i + chunkSize);
      await Promise.all(chunk.map(async (item, chunkIdx) => {
        const actualIdx = i + chunkIdx;
        if (item.rectangles.length > 0 && item.isAiProcessed) {
          completedCount++;
          setAlertMsg(`AI প্রসেসিং চলছে: ছবি ${completedCount}/${batchCopy.length}...`);
          return;
        }

        try {
          const optimized = await prepareImageForAI(item.image);
          const res = await fetch('/api/detect-text', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              imageBase64: optimized,
              mode: 'labels'
            })
          });

          if (res.ok) {
            const data = await res.json();
            const boxes = data.boxes || [];
            if (boxes.length > 0) {
              const newRects: Rectangle[] = boxes.map((b: any, bIdx: number) => {
                const w = b.xmax - b.xmin;
                const h = b.ymax - b.ymin;
                // Dynamically calculate 4-6 pixel equivalent padding based on height for Bengali matra/kar-chinhas
                const isBengali = /[\u0980-\u09FF]/.test(b.text || '');
                // Heavily increase padding for Bengali to ensure all ascenders (matra, ref) and descenders (kar-chinh) are fully masked.
                // It dynamically scales with the height but guarantees a larger absolute minimum padding.
                const padX = Math.min(12, Math.max(8, w * 0.08));
                const padY = isBengali ? Math.min(18, Math.max(12, h * 0.25)) : Math.min(10, Math.max(6, h * 0.10));
                const xmin = Math.max(0, b.xmin - padX);
                const xmax = Math.min(1000, b.xmax + padX);
                const ymin = Math.max(0, b.ymin - padY);
                const ymax = Math.min(1000, b.ymax + padY);

                const xPercent = (xmin / 1000) * 100;
                const yPercent = (ymin / 1000) * 100;
                const widthPercent = ((xmax - xmin) / 1000) * 100;
                const heightPercent = ((ymax - ymin) / 1000) * 100;
                return {
                  id: Date.now() + actualIdx * 1000 + bIdx,
                  x: 0, y: 0, width: 0, height: 0,
                  xPercent, yPercent, widthPercent, heightPercent,
                  label: b.text || '',
                  badgePosition: (b.xmin + b.xmax) / 2 >= 500 ? 'right' : 'left'
                };
              });
              
              // To avoid mutating state directly, we create a new object
              batchCopy[actualIdx] = {
                ...batchCopy[actualIdx],
                rectangles: newRects,
                isAiProcessed: true
              };
              successCount++;
            }
          }
        } catch (err) {
          console.error(`Error processing batch item ${actualIdx}:`, err);
        } finally {
          completedCount++;
          setAlertMsg(`AI প্রসেসিং চলছে: ছবি ${completedCount}/${batchCopy.length}...`);
        }
      }));
    }

    setImageBatch(batchCopy);
    if (batchCopy[activeBatchIndex]) {
      setRectangles(batchCopy[activeBatchIndex].rectangles);
    }
    setIsBatchProcessingAi(false);
    setAlertMsg(`AI ডিটেকশন সম্পন্ন! ${successCount} টি কার্ডে নিখুঁত মাস্ক তৈরি হয়েছে।`);
    setTimeout(() => setAlertMsg(''), 3000);
  };

  // Save all cards in batch at once
  const handleSaveAllBatch = () => {
    const updatedBatch = [...imageBatch];
    if (updatedBatch[activeBatchIndex]) {
      updatedBatch[activeBatchIndex] = {
        ...updatedBatch[activeBatchIndex],
        title: title.trim(),
        notes: notes.trim(),
        tags: [...tags],
        image: image || updatedBatch[activeBatchIndex].image,
        rectangles: [...rectangles],
        pins: [...pins]
      };
    }

    const validCards: Card[] = updatedBatch
      .filter(item => item.image && item.title.trim())
      .map((item, idx) => ({
        id: item.id.startsWith('batch-') 
             ? parseInt(item.id.replace('batch-', ''), 10) 
             : Date.now() + idx + Math.floor(Math.random() * 1000),
        folderId: folderId || undefined,
        title: item.title.trim(),
        notes: item.notes?.trim() || '',
        tags: item.tags || [],
        image: item.image,
        rectangles: item.rectangles,
        pins: item.pins,
        badgePosition: cardBadgePosition || 'auto',
        badgeDistance: cardBadgeDistance || 'far',
        showBadges: showBadges,
        createdAt: Date.now() + idx,
        updatedAt: Date.now() + idx
      }));

    if (validCards.length === 0) {
      setAlertMsg('সংরক্ষণ করার মতো কোনো বৈধ কার্ড পাওয়া যায়নি। ছবি ও শিরোনাম দিন।');
      return;
    }

    if (onBulkCreate) {
      onBulkCreate(validCards);
      setAlertMsg(`${validCards.length} টি কার্ড সফলভাবে তৈরি ও সংরক্ষণ করা হয়েছে!`);
      setTimeout(() => onCancel(), 600);
    } else {
      validCards.forEach(c => onSave(c));
      onCancel();
    }
  };

  const handleRotateImage = () => {
    if (!image) return;
    setIsProcessing(true);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.height;
      canvas.height = img.width;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((90 * Math.PI) / 180);
        ctx.drawImage(img, -img.width / 2, -img.height / 2);
        const isPng = image.startsWith('data:image/png');
        setImage(canvas.toDataURL(isPng ? 'image/png' : 'image/jpeg', 0.95));
        setRectangles([]); // Reset rectangles as coordinates change
      }
      setIsProcessing(false);
    };
    img.onerror = () => {
      setAlertMsg('ছবি রোটেট করতে সমস্যা হয়েছে!');
      setIsProcessing(false);
    };
    img.src = image;
  };

  const handleFlipImage = (axis: 'horizontal' | 'vertical') => {
    if (!image) return;
    setIsProcessing(true);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.translate(canvas.width / 2, canvas.height / 2);
        if (axis === 'horizontal') {
          ctx.scale(-1, 1);
        } else {
          ctx.scale(1, -1);
        }
        ctx.drawImage(img, -img.width / 2, -img.height / 2);
        const isPng = image.startsWith('data:image/png');
        setImage(canvas.toDataURL(isPng ? 'image/png' : 'image/jpeg', 0.95));
        setRectangles([]); // Reset rectangles as coordinates change
      }
      setIsProcessing(false);
    };
    img.onerror = () => {
      setAlertMsg('ছবি ফ্লিপ করতে সমস্যা হয়েছে!');
      setIsProcessing(false);
    };
    img.src = image;
  };

  const getCoordinates = (e: React.MouseEvent | React.TouchEvent | MouseEvent | TouchEvent) => {
    if (!wrapperRef.current) return { x: 0, y: 0 };
    const rect = wrapperRef.current.getBoundingClientRect();
    let clientX, clientY;
    
    if ('touches' in e && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('clientX' in e) {
      clientX = (e as MouseEvent).clientX;
      clientY = (e as MouseEvent).clientY;
    } else {
      return { x: 0, y: 0 };
    }
    
    return {
      x: clientX - rect.left,
      y: clientY - rect.top
    };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    // Only start drawing if we are not dragging or resizing a rectangle
    if (isDragging !== null || isResizing !== null) return;
    
    e.preventDefault();
    const coords = getCoordinates(e);

    if (toolMode === 'pin') {
      setPinPrompt({ x: coords.x, y: coords.y, label: '' });
      return;
    }

    setStartPos(coords);
    setIsDrawing(true);
    setCurrentRect({
      id: Date.now(),
      x: coords.x,
      y: coords.y,
      width: 0,
      height: 0
    });
  };

  const startDragging = (e: React.MouseEvent | React.TouchEvent, rectId: number) => {
    e.stopPropagation();
    e.preventDefault();
    const coords = getCoordinates(e);
    const rect = rectangles.find(r => r.id === rectId);
    if (!rect) return;
    
    const clientW = wrapperRef.current?.clientWidth || 1;
    const clientH = wrapperRef.current?.clientHeight || 1;
    const curX = rect.xPercent !== undefined ? (rect.xPercent / 100) * clientW : rect.x;
    const curY = rect.yPercent !== undefined ? (rect.yPercent / 100) * clientH : rect.y;

    setIsDragging(rectId);
    setDragOffset({
      x: coords.x - curX,
      y: coords.y - curY
    });
  };

  const startDraggingPin = (e: React.MouseEvent | React.TouchEvent, pinId: number) => {
    e.stopPropagation();
    e.preventDefault();
    const coords = getCoordinates(e);
    const clientW = wrapperRef.current?.clientWidth || 1;
    const clientH = wrapperRef.current?.clientHeight || 1;
    const pin = pins.find(p => p.id === pinId);
    if (!pin) return;
    
    const curX = pin.xPercent !== undefined ? (pin.xPercent / 100) * clientW : pin.x;
    const curY = pin.yPercent !== undefined ? (pin.yPercent / 100) * clientH : pin.y;

    setIsDraggingPin(pinId);
    setPinDragOffset({
      x: coords.x - curX,
      y: coords.y - curY
    });
  };

  const startResizing = (e: React.MouseEvent | React.TouchEvent, rectId: number) => {
    e.stopPropagation();
    e.preventDefault();
    setIsResizing(rectId);
  };

  const handlePointerMove = (e: MouseEvent | TouchEvent) => {
    if (isDrawing) {
      if (e.cancelable) e.preventDefault();
      const coords = getCoordinates(e);
      
      const x = Math.min(startPos.x, coords.x);
      const y = Math.min(startPos.y, coords.y);
      const width = Math.abs(coords.x - startPos.x);
      const height = Math.abs(coords.y - startPos.y);
      
      setCurrentRect(prev => prev ? { ...prev, x, y, width, height } : null);
    } else if (isDragging !== null) {
      if (e.cancelable) e.preventDefault();
      const coords = getCoordinates(e);
      const clientW = wrapperRef.current?.clientWidth || 1;
      const clientH = wrapperRef.current?.clientHeight || 1;
      
      setRectangles(prev => prev.map(rect => {
        if (rect.id === isDragging) {
          const newX = coords.x - dragOffset.x;
          const newY = coords.y - dragOffset.y;
          return {
            ...rect,
            x: newX,
            y: newY,
            xPercent: Math.max(0, Math.min(100, (newX / clientW) * 100)),
            yPercent: Math.max(0, Math.min(100, (newY / clientH) * 100))
          };
        }
        return rect;
      }));
    } else if (isDraggingPin !== null) {
      if (e.cancelable) e.preventDefault();
      const coords = getCoordinates(e);
      const clientW = wrapperRef.current?.clientWidth || 1;
      const clientH = wrapperRef.current?.clientHeight || 1;
      const newX = coords.x - pinDragOffset.x;
      const newY = coords.y - pinDragOffset.y;
      
      setPins(prev => prev.map(pin => {
        if (pin.id === isDraggingPin) {
          return {
            ...pin,
            x: newX,
            y: newY,
            xPercent: Math.max(0, Math.min(100, (newX / clientW) * 100)),
            yPercent: Math.max(0, Math.min(100, (newY / clientH) * 100))
          };
        }
        return pin;
      }));
    } else if (isResizing !== null) {
      if (e.cancelable) e.preventDefault();
      const coords = getCoordinates(e);
      const clientW = wrapperRef.current?.clientWidth || 1;
      const clientH = wrapperRef.current?.clientHeight || 1;
      
      setRectangles(prev => prev.map(rect => {
        if (rect.id === isResizing) {
          const curX = rect.xPercent !== undefined ? (rect.xPercent / 100) * clientW : rect.x;
          const curY = rect.yPercent !== undefined ? (rect.yPercent / 100) * clientH : rect.y;
          const newWidth = Math.max(10, coords.x - curX);
          const newHeight = Math.max(10, coords.y - curY);
          return {
            ...rect,
            width: newWidth,
            height: newHeight,
            widthPercent: (newWidth / clientW) * 100,
            heightPercent: (newHeight / clientH) * 100
          };
        }
        return rect;
      }));
    }
  };

  const handlePointerUp = () => {
    const clientW = wrapperRef.current?.clientWidth || 1;
    const clientH = wrapperRef.current?.clientHeight || 1;

    if (isDrawing) {
      setIsDrawing(false);
      if (currentRect && currentRect.width > 10 && currentRect.height > 10) {
        const newRect: Rectangle = {
          ...currentRect,
          xPercent: (currentRect.x / clientW) * 100,
          yPercent: (currentRect.y / clientH) * 100,
          widthPercent: (currentRect.width / clientW) * 100,
          heightPercent: (currentRect.height / clientH) * 100
        };
        setRectangles(prev => [...prev, newRect]);
      }
      setCurrentRect(null);
    }
    
    if (isDragging !== null) {
      setRectangles(prev => prev.map(r => r.id === isDragging ? {
        ...r,
        xPercent: (r.x / clientW) * 100,
        yPercent: (r.y / clientH) * 100,
        widthPercent: (r.width / clientW) * 100,
        heightPercent: (r.height / clientH) * 100
      } : r));
      setIsDragging(null);
    }

    if (isDraggingPin !== null) {
      setIsDraggingPin(null);
    }

    if (isResizing !== null) {
      setRectangles(prev => prev.map(r => r.id === isResizing ? {
        ...r,
        xPercent: (r.x / clientW) * 100,
        yPercent: (r.y / clientH) * 100,
        widthPercent: (r.width / clientW) * 100,
        heightPercent: (r.height / clientH) * 100
      } : r));
      setIsResizing(null);
    }
  };

  useEffect(() => {
    const handleMouseUp = () => handlePointerUp();
    const handleTouchEnd = () => handlePointerUp();
    
    if (isDrawing || isDragging !== null || isDraggingPin !== null || isResizing !== null) {
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('touchend', handleTouchEnd);
      window.addEventListener('mousemove', handlePointerMove, { passive: false });
      window.addEventListener('touchmove', handlePointerMove, { passive: false });
    }
    
    return () => {
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('touchmove', handlePointerMove);
    };
  }, [isDrawing, isDragging, isDraggingPin, isResizing, currentRect, startPos, dragOffset, pinDragOffset]);

  const handleSave = () => {
    if (!title.trim()) return setAlertMsg('অনুগ্রহ করে কার্ডের একটি নাম দিন।');
    if (!image) return setAlertMsg('অনুগ্রহ করে একটি ছবি আপলোড করুন।');
    if (rectangles.length === 0 && pins.length === 0) return setAlertMsg('অন্তত একটি মাস্ক বা পিন তৈরি করুন।');

    const clientW = wrapperRef.current?.clientWidth || imageRef.current?.clientWidth || 1;
    const clientH = wrapperRef.current?.clientHeight || imageRef.current?.clientHeight || 1;

    const normalizedRectangles = rectangles.map(r => ({
      ...r,
      xPercent: r.xPercent !== undefined ? r.xPercent : (r.x / clientW) * 100,
      yPercent: r.yPercent !== undefined ? r.yPercent : (r.y / clientH) * 100,
      widthPercent: r.widthPercent !== undefined ? r.widthPercent : (r.width / clientW) * 100,
      heightPercent: r.heightPercent !== undefined ? r.heightPercent : (r.height / clientH) * 100,
    }));

    const normalizedPins = pins.map(p => ({
      ...p,
      xPercent: p.xPercent !== undefined ? p.xPercent : (p.x / clientW) * 100,
      yPercent: p.yPercent !== undefined ? p.yPercent : (p.y / clientH) * 100,
    }));

    onSave({
      id: editingCard?.id || Date.now(),
      folderId: folderId || undefined,
      title: title.trim(),
      notes: notes.trim(),
      tags: tags.map(t => t.trim()).filter(Boolean),
      image,
      rectangles: normalizedRectangles,
      pins: normalizedPins,
      badgePosition: cardBadgePosition || 'auto',
      badgeDistance: cardBadgeDistance || 'far',
      showBadges: showBadges,
      createdAt: editingCard?.createdAt || Date.now(),
      favorite: editingCard?.favorite ?? false,
      interval: editingCard?.interval,
      repetition: editingCard?.repetition,
      easeFactor: editingCard?.easeFactor,
      nextReview: editingCard?.nextReview,
      lastReviewed: editingCard?.lastReviewed,
      lapses: editingCard?.lapses
    });
  };

  const prepareImageForAI = (dataUrl: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        // Optimized 800px dimension provides lightning fast upload & inference
        const maxDim = 1600;
        let width = img.naturalWidth || img.width;
        let height = img.naturalHeight || img.height;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(dataUrl);
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        // Subtle micro-contrast boost enhances faint diacritics and text edges for AI OCR
        ctx.filter = 'contrast(1.08) brightness(1.02)';
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", 0.85));
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });
  };

  const handleAutoDetect = async () => {
    if (!image) {
      setAlertMsg('অনুগ্রহ করে প্রথমে একটি ছবি নির্বাচন বা আপলোড করুন।');
      return;
    }
    setIsProcessing(true);
    setAlertMsg('AI দিয়ে উচ্চ-নিখুঁত স্ক্যান ও টেক্সট ডিটেকশন শুরু হয়েছে...');
    try {
      const optimizedImage = await prepareImageForAI(image);
      const res = await fetch('/api/detect-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          imageBase64: optimizedImage,
          mode: 'labels'
        })
      });

      if (!res.ok) {
        const text = await res.text();
        let errMsg = 'AI প্রসেস করতে ব্যর্থ হয়েছে।';
        try {
          const errJson = JSON.parse(text);
          if (errJson.error) errMsg = errJson.error;
        } catch(e) {}
        throw new Error(errMsg);
      }

      const data = await res.json();
      const boxes = data.boxes || [];

      if (boxes && boxes.length > 0 && imageRef.current) {
        const clientW = imageRef.current.clientWidth;
        const clientH = imageRef.current.clientHeight;

        // 1. Sort detected items top-to-bottom, left-to-right
        const sortedBoxes = [...boxes].sort((a: any, b: any) => {
          if (Math.abs(a.ymin - b.ymin) > 25) return a.ymin - b.ymin;
          return a.xmin - b.xmin;
        });

        // 2. Intelligent Typographic Margins (in 0-1000 normalized coordinate space)
        // Bengali diacritics (কার, মাত্রা, রেফ, ফলা) and English ascenders/descenders
        // need dedicated margin so letters never peek out from under the occlusion box.
        const paddedBoxes = sortedBoxes.map((box: any) => {
          const xmin = box.xmin;
          const ymin = box.ymin;
          const xmax = box.xmax;
          const ymax = box.ymax;

          const wNorm = xmax - xmin;
          const hNorm = ymax - ymin;

          return {
            xmin,
            ymin,
            xmax,
            ymax,
            text: box.text || '',
            labelType: box.labelType || 'label'
          };
        });

        // 3. Smart Non-Maximum Suppression / Overlap Merging
        const mergedBoxes: typeof paddedBoxes = [];
        for (const box of paddedBoxes) {
          let merged = false;
          for (let i = 0; i < mergedBoxes.length; i++) {
            const existing = mergedBoxes[i];
            const interXmin = Math.max(box.xmin, existing.xmin);
            const interYmin = Math.max(box.ymin, existing.ymin);
            const interXmax = Math.min(box.xmax, existing.xmax);
            const interYmax = Math.min(box.ymax, existing.ymax);

            if (interXmax > interXmin && interYmax > interYmin) {
              const interArea = (interXmax - interXmin) * (interYmax - interYmin);
              const boxArea = (box.xmax - box.xmin) * (box.ymax - box.ymin);
              const existArea = (existing.xmax - existing.xmin) * (existing.ymax - existing.ymin);
              const minArea = Math.min(boxArea, existArea);
              const unionArea = boxArea + existArea - interArea;
              const iou = unionArea > 0 ? interArea / unionArea : 0;
              const overlapRatio = minArea > 0 ? interArea / minArea : 0;

              // Merge if overlap ratio is > 30% or IoU > 0.20 to completely prevent overlapping double-masks
              if (iou > 0.20 || overlapRatio > 0.30) {
                let combinedText = existing.text || '';
                if (box.text) {
                  if (!combinedText) {
                    combinedText = box.text;
                  } else if (!combinedText.includes(box.text) && !box.text.includes(combinedText)) {
                    combinedText = `${combinedText} ${box.text}`.trim();
                  } else if (box.text.length > combinedText.length) {
                    combinedText = box.text;
                  }
                }

                mergedBoxes[i] = {
                  xmin: Math.min(box.xmin, existing.xmin),
                  ymin: Math.min(box.ymin, existing.ymin),
                  xmax: Math.max(box.xmax, existing.xmax),
                  ymax: Math.max(box.ymax, existing.ymax),
                  text: combinedText,
                  labelType: existing.labelType || box.labelType
                };
                merged = true;
                break;
              }
            }
          }
          if (!merged) {
            mergedBoxes.push(box);
          }
        }

                // 4. Map to Rectangles with smart badge placement away from the central diagram
        const newRects: Rectangle[] = mergedBoxes.map((box, idx) => {
          // Add smart proportional padding based on the word's own size
          const w = box.xmax - box.xmin;
          const h = box.ymax - box.ymin;
          const isBengali = /[\u0980-\u09FF]/.test(box.text || '');
          const padX = Math.min(12, Math.max(8, w * 0.08));
          const padY = isBengali ? Math.min(18, Math.max(12, h * 0.25)) : Math.min(10, Math.max(6, h * 0.10));
          const xmin = Math.max(0, box.xmin - padX);
          const xmax = Math.min(1000, box.xmax + padX);
          const ymin = Math.max(0, box.ymin - padY);
          const ymax = Math.min(1000, box.ymax + padY);

          const xPercent = (xmin / 1000) * 100;
          const yPercent = (ymin / 1000) * 100;
          const widthPercent = ((xmax - xmin) / 1000) * 100;
          const heightPercent = ((ymax - ymin) / 1000) * 100;
          
          const x = Math.round((xmin / 1000) * clientW);
          const y = Math.round((ymin / 1000) * clientH);
          const width = Math.max(14, Math.round(((xmax - xmin) / 1000) * clientW));
          const height = Math.max(12, Math.round(((ymax - ymin) / 1000) * clientH));

          // Smart placement away from the diagram drawing:
          // In diagrams/illustrations, the core diagram is usually in the center.
          // Items in the left half (xmin < 500) get badges on the outer left ('left').
          // Items in the right half (xmin >= 500) get badges on the outer right ('right').
          const centerNormX = (box.xmin + box.xmax) / 2;
          const smartPos: 'left' | 'right' = centerNormX >= 500 ? 'right' : 'left';

          return {
            id: Date.now() + idx + Math.random(),
            x,
            y,
            width,
            height,
            xPercent,
            yPercent,
            widthPercent,
            heightPercent,
            label: box.text,
            badgePosition: smartPos,
            badgeDistance: 'far'
          };
        });

        setCardBadgePosition('auto');
        setCardBadgeDistance('far');
        setRectangles(prev => [...prev, ...newRects]);
        setAlertMsg(`AI স্ক্যান সম্পন্ন: ${newRects.length} টি লেবেল শনাক্ত হয়েছে! চিত্র পরিষ্কার দেখার সুবিধার্থে নম্বর ব্যাজগুলো (#১, #২...) চিত্র থেকে দূরে পাশে বসানো হয়েছে।`);
        setTimeout(() => setAlertMsg(''), 4500);
      } else {
        setAlertMsg('ছবিতে কোনো স্পষ্ট লেখা বা লেবেল পাওয়া যায়নি। আপনি ম্যানুয়ালি ড্র করে মাস্ক আঁকতে পারেন।');
      }
    } catch (e: any) {
      console.error('AI Mask Detection Error:', e);
      setAlertMsg(e?.message || 'AI মাস্ক তৈরি করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
    } finally {
      setIsProcessing(false);
    }
  };

  // Fine-tuning mask controls
  const adjustAllMaskPadding = (deltaPx: number) => {
    if (rectangles.length === 0) return;
    const clientW = wrapperRef.current?.clientWidth || 1;
    const clientH = wrapperRef.current?.clientHeight || 1;
    setRectangles(prev => prev.map(rect => {
      const newW = Math.max(8, rect.width + deltaPx * 2);
      const newH = Math.max(8, rect.height + deltaPx * 2);
      const newX = Math.max(0, rect.x - deltaPx);
      const newY = Math.max(0, rect.y - deltaPx);
      return {
        ...rect,
        x: newX,
        y: newY,
        width: newW,
        height: newH,
        xPercent: (newX / clientW) * 100,
        yPercent: (newY / clientH) * 100,
        widthPercent: (newW / clientW) * 100,
        heightPercent: (newH / clientH) * 100
      };
    }));
    setAlertMsg(deltaPx > 0 ? 'মাস্কের আকার বড় করা হয়েছে (+2px)।' : 'মাস্কের আকার টাইট করা হয়েছে (-2px)।');
    setTimeout(() => setAlertMsg(''), 1500);
  };

  // Helper to get normalized pixel bounding box for any rectangle
  const getRectBox = (r: Rectangle, clientW: number, clientH: number) => {
    const x = r.xPercent !== undefined ? (r.xPercent / 100) * clientW : r.x;
    const y = r.yPercent !== undefined ? (r.yPercent / 100) * clientH : r.y;
    const width = r.widthPercent !== undefined ? (r.widthPercent / 100) * clientW : r.width;
    const height = r.heightPercent !== undefined ? (r.heightPercent / 100) * clientH : r.height;
    return { x, y, width, height, x2: x + width, y2: y + height };
  };

  // Check if any two rectangles in a set overlap
  const checkHasOverlaps = (rects: Rectangle[]): { count: number; pairs: [number, number][] } => {
    if (rects.length < 2) return { count: 0, pairs: [] };
    const clientW = wrapperRef.current?.clientWidth || 1000;
    const clientH = wrapperRef.current?.clientHeight || 1000;
    const pairs: [number, number][] = [];

    for (let i = 0; i < rects.length; i++) {
      const boxA = getRectBox(rects[i], clientW, clientH);
      for (let j = i + 1; j < rects.length; j++) {
        const boxB = getRectBox(rects[j], clientW, clientH);
        const interX = Math.max(boxA.x, boxB.x);
        const interY = Math.max(boxA.y, boxB.y);
        const interX2 = Math.min(boxA.x2, boxB.x2);
        const interY2 = Math.min(boxA.y2, boxB.y2);

        if (interX2 > interX && interY2 > interY) {
          const interArea = (interX2 - interX) * (interY2 - interY);
          const minArea = Math.min(boxA.width * boxA.height, boxB.width * boxB.height);
          if (minArea > 0 && (interArea / minArea) > 0.08) {
            pairs.push([rects[i].id, rects[j].id]);
          }
        }
      }
    }
    return { count: pairs.length, pairs };
  };

  const mergeOverlappingMasks = () => {
    if (rectangles.length < 2) {
      setAlertMsg('মার্জ করার জন্য অন্তত ২টি মাস্ক প্রয়োজন।');
      setTimeout(() => setAlertMsg(''), 2000);
      return;
    }
    const clientW = wrapperRef.current?.clientWidth || 1000;
    const clientH = wrapperRef.current?.clientHeight || 1000;
    
    let pool = [...rectangles];
    const merged: Rectangle[] = [];

    while (pool.length > 0) {
      let current = pool.shift()!;
      let hasMerge = true;
      while (hasMerge) {
        hasMerge = false;
        const curBox = getRectBox(current, clientW, clientH);

        for (let i = 0; i < pool.length; i++) {
          const other = pool[i];
          const otherBox = getRectBox(other, clientW, clientH);

          const interX = Math.max(curBox.x, otherBox.x);
          const interY = Math.max(curBox.y, otherBox.y);
          const interX2 = Math.min(curBox.x2, otherBox.x2);
          const interY2 = Math.min(curBox.y2, otherBox.y2);

          if (interX2 > interX && interY2 > interY) {
            const interArea = (interX2 - interX) * (interY2 - interY);
            const minArea = Math.min(curBox.width * curBox.height, otherBox.width * otherBox.height);
            const overlapRatio = minArea > 0 ? interArea / minArea : 0;

            if (overlapRatio > 0.08) {
              const minX = Math.min(curBox.x, otherBox.x);
              const minY = Math.min(curBox.y, otherBox.y);
              const maxX = Math.max(curBox.x2, otherBox.x2);
              const maxY = Math.max(curBox.y2, otherBox.y2);

              let combinedLabel = current.label || '';
              if (other.label) {
                if (!combinedLabel) {
                  combinedLabel = other.label;
                } else if (!combinedLabel.includes(other.label) && !other.label.includes(combinedLabel)) {
                  combinedLabel = `${combinedLabel} ${other.label}`;
                } else if (other.label.length > combinedLabel.length) {
                  combinedLabel = other.label;
                }
              }

              current = {
                id: current.id,
                x: minX,
                y: minY,
                width: maxX - minX,
                height: maxY - minY,
                xPercent: (minX / clientW) * 100,
                yPercent: (minY / clientH) * 100,
                widthPercent: ((maxX - minX) / clientW) * 100,
                heightPercent: ((maxY - minY) / clientH) * 100,
                label: combinedLabel.trim() || undefined,
                badgePosition: current.badgePosition || other.badgePosition || 'auto'
              };
              pool.splice(i, 1);
              hasMerge = true;
              break;
            }
          }
        }
      }
      merged.push(current);
    }

    const diff = rectangles.length - merged.length;
    setRectangles(merged);
    setOverlappedPicker(null);
    setAlertMsg(diff > 0 
      ? `সাফল্য! ${diff} টি ওভারল্যাপিং আড়াল একত্র করে পরিষ্কার বক্সে রূপান্তর করা হয়েছে!` 
      : 'কোনো ওভারল্যাপিং আড়াল পাওয়া যায়নি, সবগুলো মাস্ক আলাদা।'
    );
    setTimeout(() => setAlertMsg(''), 3000);
  };

  // Bring a mask layer to top
  const bringRectToFront = (rectId: number) => {
    setRectangles(prev => {
      const idx = prev.findIndex(r => r.id === rectId);
      if (idx === -1 || idx === prev.length - 1) return prev;
      const target = prev[idx];
      const rest = prev.filter(r => r.id !== rectId);
      return [...rest, target];
    });
    setSelectedRectId(rectId);
    setAlertMsg('আড়ালটি সর্বোপরে (Bring to Front) আনা হয়েছে!');
    setTimeout(() => setAlertMsg(''), 1500);
  };

  // Send a mask layer to back
  const sendRectToBack = (rectId: number) => {
    setRectangles(prev => {
      const idx = prev.findIndex(r => r.id === rectId);
      if (idx === -1 || idx === 0) return prev;
      const target = prev[idx];
      const rest = prev.filter(r => r.id !== rectId);
      return [target, ...rest];
    });
    setSelectedRectId(rectId);
    setAlertMsg('আড়ালটি নিচে (Send to Back) পাঠানো হয়েছে!');
    setTimeout(() => setAlertMsg(''), 1500);
  };

  // TTS audio check for mask label
  const speakText = (text?: string) => {
    if (!text || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const isBengali = /[\u0980-\u09FF]/.test(text);
    utterance.lang = isBengali ? 'bn-BD' : 'en-US';
    utterance.rate = 0.95;
    window.speechSynthesis.speak(utterance);
  };

  // Save changes from Edit Mask Modal
  const handleSaveEditedRect = (updated: Rectangle) => {
    setRectangles(prev => prev.map(r => r.id === updated.id ? updated : r));
    setEditingRectModal(null);
    setSelectedRectId(updated.id);
    setAlertMsg('আড়ালের তথ্য সফলভাবে আপডেট হয়েছে!');
    setTimeout(() => setAlertMsg(''), 2000);
  };

  // Delete a mask
  const handleDeleteRect = (rectId: number) => {
    setRectangles(prev => prev.filter(r => r.id !== rectId));
    if (selectedRectId === rectId) setSelectedRectId(null);
    if (editingRectModal?.id === rectId) setEditingRectModal(null);
    setAlertMsg('আড়ালটি মুছে ফেলা হয়েছে।');
    setTimeout(() => setAlertMsg(''), 1500);
  };

  const convertMasksToPins = () => {
    if (rectangles.length === 0) return;
    const clientW = wrapperRef.current?.clientWidth || 1;
    const clientH = wrapperRef.current?.clientHeight || 1;

    const newPins: Pin[] = rectangles.map((r, idx) => ({
      id: Date.now() + idx,
      x: Math.round(r.x + r.width / 2),
      y: Math.round(r.y + r.height / 2),
      xPercent: (r.xPercent !== undefined && r.widthPercent !== undefined)
        ? r.xPercent + r.widthPercent / 2
        : ((r.x + r.width / 2) / clientW) * 100,
      yPercent: (r.yPercent !== undefined && r.heightPercent !== undefined)
        ? r.yPercent + r.heightPercent / 2
        : ((r.y + r.height / 2) / clientH) * 100,
      label: r.label || `লেবেল ${idx + 1}`
    }));

    setPins(prev => [...prev, ...newPins]);
    setRectangles([]);
    setToolMode('pin');
    setAlertMsg(`${newPins.length} টি মাস্ককে ইন্টারঅ্যাক্টিভ পিনে রূপান্তর করা হয়েছে!`);
    setTimeout(() => setAlertMsg(''), 2500);
  };

  const clearAllMasks = () => {
    if (rectangles.length === 0) return;
    if (window.confirm('আপনি কি সব মাস্ক মুছে ফেলতে চান?')) {
      setRectangles([]);
      setAlertMsg('সকল মাস্ক মুছে ফেলা হয়েছে।');
      setTimeout(() => setAlertMsg(''), 1500);
    }
  };



  const getEraserCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!eraserCanvasRef.current) return { x: 0, y: 0 };
    const rect = eraserCanvasRef.current.getBoundingClientRect();
    let clientX, clientY;
    if ('touches' in e && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('clientX' in e) {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    } else {
      return { x: 0, y: 0 };
    }
    const scaleX = eraserCanvasRef.current.width / rect.width;
    const scaleY = eraserCanvasRef.current.height / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const startEraser = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    setIsEraserDrawing(true);
    const coords = getEraserCoordinates(e);
    setLastPos(coords);
    drawEraserDot(coords.x, coords.y);
  };

  const drawEraserDot = (x: number, y: number) => {
    if (!eraserCanvasRef.current) return;
    const ctx = eraserCanvasRef.current.getContext('2d');
    if (!ctx) return;
    ctx.beginPath();
    ctx.fillStyle = brushColor;
    ctx.arc(x, y, eraserSize / 2, 0, Math.PI * 2);
    ctx.fill();
  };

  const drawEraser = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isEraserDrawing || !eraserCanvasRef.current) return;
    e.preventDefault();
    const ctx = eraserCanvasRef.current.getContext('2d');
    if (!ctx) return;
    const coords = getEraserCoordinates(e);
    
    ctx.beginPath();
    ctx.strokeStyle = brushColor;
    ctx.lineWidth = eraserSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.moveTo(lastPos.x, lastPos.y);
    ctx.lineTo(coords.x, coords.y);
    ctx.stroke();
    
    setLastPos(coords);
  };

  const saveCrop = () => {
    const imageEl = cropImageRef.current;
    if (!completedCrop || !completedCrop.width || !completedCrop.height) {
      setAlertMsg('ক্রপ করার জন্য ছবির নির্দিষ্ট অংশের ওপর আঙুল বা মাউস দিয়ে সিলেক্ট করুন।');
      return;
    }

    if (!imageEl || !imageEl.naturalWidth || !imageEl.naturalHeight) {
      setIsCropModal(false);
      return;
    }

    const displayedWidth = imageEl.width || imageEl.clientWidth || imageEl.getBoundingClientRect().width;
    const displayedHeight = imageEl.height || imageEl.clientHeight || imageEl.getBoundingClientRect().height;

    if (!displayedWidth || !displayedHeight) {
      setIsCropModal(false);
      return;
    }

    let naturalX = 0;
    let naturalY = 0;
    let naturalWidth = 0;
    let naturalHeight = 0;

    if (completedCrop.unit === '%') {
      naturalX = (completedCrop.x / 100) * imageEl.naturalWidth;
      naturalY = (completedCrop.y / 100) * imageEl.naturalHeight;
      naturalWidth = (completedCrop.width / 100) * imageEl.naturalWidth;
      naturalHeight = (completedCrop.height / 100) * imageEl.naturalHeight;
    } else {
      const scaleX = imageEl.naturalWidth / displayedWidth;
      const scaleY = imageEl.naturalHeight / displayedHeight;
      naturalX = completedCrop.x * scaleX;
      naturalY = completedCrop.y * scaleY;
      naturalWidth = completedCrop.width * scaleX;
      naturalHeight = completedCrop.height * scaleY;
    }

    // Ensure within natural image bounds
    naturalX = Math.max(0, Math.min(imageEl.naturalWidth - 1, naturalX));
    naturalY = Math.max(0, Math.min(imageEl.naturalHeight - 1, naturalY));
    naturalWidth = Math.max(1, Math.min(imageEl.naturalWidth - naturalX, naturalWidth));
    naturalHeight = Math.max(1, Math.min(imageEl.naturalHeight - naturalY, naturalHeight));

    const targetWidth = Math.round(naturalWidth);
    const targetHeight = Math.round(naturalHeight);

    if (targetWidth > 0 && targetHeight > 0) {
      const canvas = document.createElement('canvas');
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(
          imageEl,
          naturalX,
          naturalY,
          naturalWidth,
          naturalHeight,
          0,
          0,
          targetWidth,
          targetHeight
        );
        const isPng = image.startsWith('data:image/png');
        const outputDataUrl = canvas.toDataURL(isPng ? 'image/png' : 'image/jpeg', 0.95);
        setImage(outputDataUrl);
        setRectangles([]); // Reset rectangles as coordinates change
        setPins([]); // Reset pins as coordinates change
        setCrop(undefined);
        setCompletedCrop(null);
        setAlertMsg('ছবি সম্পূর্ণ হাই রেজোলিউশন ও স্পষ্টতায় ক্রপ করা হয়েছে!');
        setTimeout(() => setAlertMsg(''), 2500);
      }
    }
    setIsCropModal(false);
  };

  const stopEraser = () => {
    setIsEraserDrawing(false);
  };

  const saveEraser = () => {
    if (eraserCanvasRef.current) {
      const isPng = image.startsWith('data:image/png');
      setImage(eraserCanvasRef.current.toDataURL(isPng ? 'image/png' : 'image/jpeg', 0.95));
    }
    setIsErasingModal(false);
  };

  const initEraserCanvas = () => {
    if (image && eraserCanvasRef.current) {
      const img = new Image();
      img.onload = () => {
        if (eraserCanvasRef.current) {
          eraserCanvasRef.current.width = img.width;
          eraserCanvasRef.current.height = img.height;
          const ctx = eraserCanvasRef.current.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0);
          }
        }
      };
      img.src = image;
    }
  };

  useEffect(() => {
    if (isErasingModal) {
      setTimeout(initEraserCanvas, 50);
    }
  }, [isErasingModal]);

  return (
    <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-900">
      {/* Alert Modal */}
      {alertMsg && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4">{alertMsg}</h3>
            <button onClick={() => setAlertMsg('')} className="w-full bg-blue-600 text-white py-2 rounded-lg font-medium">ঠিক আছে</button>
          </div>
        </div>
      )}

      {/* Crop Modal */}
      {isCropModal && image && (
        <div className="fixed inset-0 bg-black z-50 flex flex-col">
          <header className="safe-top-header bg-gray-900 border-b border-gray-800 px-4 pb-3 flex items-center justify-between shadow-sm shrink-0">
            <button onClick={() => setIsCropModal(false)} className="p-2 text-gray-400 hover:text-white rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <h2 className="font-bold text-white text-lg flex items-center gap-2">
              <CropIcon className="w-5 h-5" /> ক্রপ করুন
            </h2>
            <button
              onClick={saveCrop}
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 active:scale-95 transition-transform"
            >
              <Check className="w-5 h-5" /> ওকে
            </button>
          </header>
          <div className="bg-gray-800/90 text-gray-300 text-xs py-2 px-4 text-center border-b border-gray-700/60 shrink-0">
            ছবির যে অংশটুকু রাখতে চান, আঙুল বা মাউস দিয়ে সেটুকু সিলেক্ট করুন (অরিজিনাল হাই-রেজোলিউশন বজায় থাকবে)
          </div>
          <div className="flex-1 relative bg-gray-900 overflow-hidden flex items-center justify-center p-4">
            <ReactCrop
              crop={crop}
              onChange={(c) => setCrop(c)}
              onComplete={(c) => setCompletedCrop(c)}
              className="max-h-full"
            >
              <img
                ref={cropImageRef}
                src={image}
                alt="Crop preview"
                className="max-w-full max-h-[80vh] object-contain"
              />
            </ReactCrop>
          </div>
        </div>
      )}

      {/* Eraser Modal */}
      {isErasingModal && image && (
        <div className="fixed inset-0 bg-black z-50 flex flex-col">
          <header className="safe-top-header bg-gray-900 border-b border-gray-800 px-4 pb-3 flex items-center justify-between shadow-sm shrink-0">
            <button onClick={() => setIsErasingModal(false)} className="p-2 text-gray-400 hover:text-white rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <h2 className="font-bold text-white text-lg flex items-center gap-2">
              <Eraser className="w-5 h-5" /> মার্কআপ/ইরেজার
            </h2>
            <button
              onClick={saveEraser}
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 active:scale-95 transition-transform"
            >
              <Check className="w-5 h-5" /> ওকে
            </button>
          </header>
          <div className="flex-1 relative bg-gray-900 overflow-hidden flex items-center justify-center p-4">
            <div className="relative inline-block max-w-full max-h-full">
              <canvas
                ref={eraserCanvasRef}
                className="max-w-full max-h-full cursor-crosshair touch-none bg-white dark:bg-slate-800"
                onMouseDown={startEraser}
                onMouseMove={drawEraser}
                onMouseUp={stopEraser}
                onMouseLeave={stopEraser}
                onTouchStart={startEraser}
                onTouchMove={drawEraser}
                onTouchEnd={stopEraser}
                onTouchCancel={stopEraser}
              />
            </div>
          </div>
          <div className="bg-gray-900 p-6 flex flex-col gap-6 shrink-0 border-t border-gray-800">
            <div className="flex flex-col gap-2">
              <label className="text-white text-sm font-medium">রঙ (Color)</label>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {['#FFFFFF', '#000000', '#EF4444', '#22C55E', '#3B82F6', '#EAB308', '#D946EF', '#06B6D4'].map(c => (
                  <button
                    key={c}
                    onClick={() => setBrushColor(c)}
                    className={`w-8 h-8 shrink-0 rounded-full border-2 ${brushColor === c ? 'border-blue-400 scale-110' : 'border-gray-600'} transition-all`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-white text-sm font-medium flex justify-between">
                <span>ব্রাশের সাইজ (Brush Size)</span>
                <span>{eraserSize}px</span>
              </label>
              <input
                type="range"
                value={eraserSize}
                min={2}
                max={100}
                step={2}
                onChange={(e) => setEraserSize(Number(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      <header className="safe-top-header bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border-b border-slate-200/50 dark:border-slate-800/50 px-4 pb-3 flex items-center justify-between shadow-sm shrink-0 sticky top-0 z-40">
        <button onClick={onCancel} className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-full transition-colors" title="বাতিল">
          <X className="w-6 h-6" />
        </button>
        <h2 className="font-bold text-gray-800 dark:text-gray-100 text-lg truncate flex-1 text-center px-2">
          {isBulkEdit ? `এডিট করুন (${bulkRemaining} টি বাকি)` : (editingCard ? 'কার্ড এডিট করুন' : 'নতুন কার্ড')}
        </h2>
        
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            type="button"
            onClick={() => setShowHelpModal(true)}
            className="flex items-center gap-1 p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 rounded-lg transition-colors font-medium text-xs sm:text-sm active:scale-95 cursor-pointer"
            title="ইমেজ অক্লুশন কীভাবে কাজ করে? (টিউটোরিয়াল ও ডেমো)"
          >
            <HelpCircle className="w-5 h-5" />
            <span className="hidden xs:inline font-semibold">সাহায্য</span>
          </button>
          {isBulkEdit && onSkip && (
            <button
              onClick={onSkip}
              className="flex items-center gap-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 px-4 py-2 rounded-lg font-medium active:scale-95 transition-transform"
            >
              স্কিপ (Skip)
            </button>
          )}
          <button
            onClick={handleSave}
            className="flex items-center gap-2 bg-green-500 text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-green-600 shadow-md hover:shadow-lg active:scale-95 transition-all"
          >
            <Save className="w-5 h-5 hidden sm:block" /> <span className="hidden sm:inline">{isBulkEdit ? 'সেভ ও পরবর্তী' : 'সেভ'}</span><span className="sm:hidden">{isBulkEdit ? 'সেভ ও পরবর্তী' : 'সেভ'}</span>
          </button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4 max-w-3xl w-full mx-auto flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="কার্ডের বিষয় বা নাম..."
            className="flex-1 p-3.5 sm:p-4 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-base sm:text-lg text-gray-900 dark:text-white"
          />
          {image && (
            <button
              type="button"
              onClick={handleAutoFillMetadata}
              disabled={isAutoFilling}
              className="shrink-0 flex items-center gap-1.5 px-3.5 py-3 sm:py-3.5 rounded-xl text-xs sm:text-sm font-bold bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-md active:scale-95 transition-all cursor-pointer disabled:opacity-50"
              title="AI দিয়ে ছবির বিষয়বস্তু স্ক্যান করে কার্ডের নাম ও ট্যাগ স্বয়ংক্রিয়ভাবে পূরণ করুন"
            >
              {isAutoFilling ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="hidden sm:inline">AI খুঁজছে...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-100" />
                  <span className="font-semibold">AI অটো-ফিল</span>
                </>
              )}
            </button>
          )}
        </div>
        
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-600 dark:text-gray-300">নোট বা স্মৃতিছন্দ (Study Notes)</span>
            {image && (
              <button
                type="button"
                onClick={handleGenerateAiNotes}
                disabled={isGeneratingNotes}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-xs transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
                title="AI দিয়ে স্বয়ংক্রিয়ভাবে সারসংক্ষেপ ও স্মৃতিছন্দ তৈরি করুন"
              >
                {isGeneratingNotes ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>AI নোট লিখছে...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>✨ AI স্মার্ট নোট তৈরি</span>
                  </>
                )}
              </button>
            )}
          </div>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="নোট বা ছন্দ (ঐচ্ছিক)... উপরে 'AI স্মার্ট নোট তৈরি' বোতাম চেপে স্বয়ংক্রিয়ভাবে নোট তৈরি করতে পারেন"
            className="w-full p-4 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-[90px]"
          />
        </div>

        <TagInput
          tags={tags}
          onChange={setTags}
          existingTags={existingTags}
        />

        {!image && (
          <div className="flex flex-col gap-3.5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Option 1: Normal Gallery */}
              <label className="flex flex-col items-center justify-center bg-white dark:bg-slate-800 border-2 border-dashed border-blue-300 dark:border-blue-700/60 rounded-2xl p-5 sm:p-6 cursor-pointer hover:bg-blue-50/50 dark:hover:bg-slate-800/80 transition-all shadow-xs group">
                <div className="flex flex-col items-center text-center">
                  {isProcessing ? (
                    <Loader2 className="w-9 h-9 text-blue-500 mb-2.5 animate-spin" />
                  ) : (
                    <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform shadow-xs">
                      <Images className="w-6 h-6" />
                    </div>
                  )}
                  <span className="text-gray-900 dark:text-white font-bold text-sm sm:text-base mb-0.5">
                    ১. গ্যালারি / এক বা একাধিক ছবি
                  </span>
                  <span className="text-xs text-gray-500 dark:text-gray-400 font-normal">
                    ছবি সিলেক্ট করে নিজে মাস্ক ও নোট কাস্টমাইজ করুন
                  </span>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={handleImageUpload}
                  disabled={isProcessing || isAutoBulkActive}
                />
              </label>

              {/* Option 2: Direct Camera */}
              <label className="flex flex-col items-center justify-center bg-white dark:bg-slate-800 border-2 border-dashed border-emerald-300 dark:border-emerald-700/60 rounded-2xl p-5 sm:p-6 cursor-pointer hover:bg-emerald-50/50 dark:hover:bg-slate-800/80 transition-all shadow-xs group">
                <div className="flex flex-col items-center text-center">
                  {isProcessing ? (
                    <Loader2 className="w-9 h-9 text-emerald-500 mb-2.5 animate-spin" />
                  ) : (
                    <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform shadow-xs">
                      <Camera className="w-6 h-6" />
                    </div>
                  )}
                  <span className="text-gray-900 dark:text-white font-bold text-sm sm:text-base mb-0.5">
                    ২. ক্যামেরা দিয়ে ছবি তুলুন
                  </span>
                  <span className="text-xs text-gray-500 dark:text-gray-400 font-normal">
                    সরাসরি বই বা খাতা থেকে ছবি তুলুন
                  </span>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={handleImageUpload}
                  disabled={isProcessing || isAutoBulkActive}
                />
              </label>
            </div>

            {/* Option 3: Full Automatic Bulk Engine */}
            <label className="relative overflow-hidden flex flex-col sm:flex-row items-center justify-between bg-gradient-to-r from-amber-500/10 via-indigo-500/10 to-amber-500/10 dark:from-amber-950/40 dark:via-indigo-950/40 dark:to-amber-950/40 border-2 border-dashed border-amber-400/80 dark:border-amber-400/60 rounded-2xl p-5 sm:p-6 cursor-pointer hover:border-amber-500 hover:bg-amber-50/50 dark:hover:bg-slate-800/90 transition-all shadow-md group">
              <div className="flex items-center gap-4 text-left w-full sm:w-auto mb-3 sm:mb-0">
                <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center shrink-0 shadow-md group-hover:scale-105 transition-transform">
                  <Zap className="w-6 h-6 fill-slate-950" />
                </div>
                <div className="flex flex-col">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-gray-950 dark:text-white font-extrabold text-base sm:text-lg">
                      ৩. সম্পূর্ণ অটোমেটিক বাল্ক মোড
                    </span>
                    <span className="bg-amber-400 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider shadow-xs">
                      ✨ ফুল অটো
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 font-medium leading-relaxed">
                    একসাথে অনেকগুলো ছবি দিন — AI স্বয়ংক্রিয়ভাবে প্রতিটির নাম, স্টাডি নোট, মাস্ক এবং কোয়ালিটি অপটিমাইজ করে দেবে।
                  </p>
                </div>
              </div>

              <div className="shrink-0 w-full sm:w-auto">
                <div className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold text-sm shadow-md flex items-center justify-center gap-2 group-hover:shadow-lg transition-all">
                  <Sparkles className="w-4 h-4" />
                  <span>অনেকগুলো ছবি দিন</span>
                </div>
              </div>

              <input
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleAutoBulkUpload}
                disabled={isProcessing || isAutoBulkActive}
              />
            </label>

            {/* Option 4: Zero-Permission Clipboard Paste Option */}
            <div
              onClick={handlePasteImageFromClipboard}
              className="flex items-center justify-between p-3.5 sm:p-4 rounded-2xl border-2 border-dashed border-indigo-300 dark:border-indigo-700/60 bg-indigo-50/50 dark:bg-indigo-950/30 hover:bg-indigo-100/50 dark:hover:bg-indigo-900/40 transition-all cursor-pointer group shadow-2xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                  <ClipboardPaste className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-900 dark:text-white font-bold text-sm sm:text-base">
                      ৪. ক্লিপবোর্ড থেকে ছবি পেস্ট করুন
                    </span>
                    <span className="text-[10px] bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 font-bold px-2 py-0.5 rounded-full">
                      পারমিশনমুক্ত
                    </span>
                  </div>
                  <span className="text-xs text-gray-500 dark:text-gray-400 font-normal">
                    কপি করা স্ক্রিনশট বা ছবি সরাসরি পেস্ট করুন (বা কীবোর্ডে Ctrl+V)
                  </span>
                </div>
              </div>
              <button
                type="button"
                className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shrink-0 cursor-pointer shadow-xs"
              >
                ছবি পেস্ট করুন
              </button>
            </div>
          </div>
        )}

        {/* Multi-Image Batch Tray & Quick Controls */}
        {imageBatch.length > 1 && (
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-3.5 text-white border border-indigo-500/30 shadow-xl flex flex-col gap-2.5 animate-in fade-in">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Images className="w-5 h-5 text-indigo-400" />
                <span className="font-bold text-sm text-indigo-100">
                  বাল্ক ইমেজ কিউ (ছবি {activeBatchIndex + 1} / {imageBatch.length})
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleBatchAiDetectAll}
                  disabled={isBatchProcessingAi}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-md active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
                  title="সবগুলো ছবিতে স্বয়ংক্রিয়ভাবে AI মাস্ক বসান"
                >
                  {isBatchProcessingAi ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>AI তৈরি করছে...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 text-slate-900" />
                      <span>সবগুলোতে AI চালান</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleSaveAllBatch}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs shadow-md active:scale-95 transition-all cursor-pointer"
                  title="সবগুলো ছবি দিয়ে এক ক্লিকে কার্ড তৈরি সম্পন্ন করুন"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>সব সেভ করুন ({imageBatch.length}টি)</span>
                </button>
              </div>
            </div>

            {/* Horizontal Thumbnail Strip */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 scrollbar-thin">
              {imageBatch.map((item, idx) => {
                const isActive = idx === activeBatchIndex;
                const rectCount = isActive ? rectangles.length : item.rectangles.length;
                return (
                  <div
                    key={item.id}
                    onClick={() => switchBatchItem(idx)}
                    className={`relative shrink-0 w-20 h-16 rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                      isActive
                        ? 'border-amber-400 ring-2 ring-amber-400/60 scale-105 shadow-lg'
                        : 'border-white/20 opacity-70 hover:opacity-100 hover:border-white/50'
                    }`}
                  >
                    <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent flex flex-col justify-between p-1">
                      <span className="text-[10px] font-mono font-bold bg-black/70 text-white px-1 rounded w-fit">
                        #{idx + 1}
                      </span>
                      <span className="text-[9px] text-amber-300 font-semibold truncate">
                        {rectCount > 0 ? `${rectCount} মাস্ক` : 'খালি'}
                      </span>
                    </div>
                  </div>
                );
              })}

              {/* Add more images button */}
              <label className="shrink-0 w-20 h-16 rounded-xl border-2 border-dashed border-white/40 hover:border-white flex flex-col items-center justify-center cursor-pointer transition-colors bg-white/5 hover:bg-white/10">
                <Plus className="w-5 h-5 text-white/80" />
                <span className="text-[10px] text-white/80 font-bold mt-0.5">+ ছবি যোগ</span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={handleImageUpload}
                  disabled={isProcessing}
                />
              </label>
            </div>
          </div>
        )}

        {image && (
          <div className="flex flex-col gap-2">
            {/* Quick Tutorial Tip Banner for First-Time Users */}
            {showHintBanner && (
              <div className="flex items-center justify-between gap-2 p-2.5 px-3.5 rounded-xl bg-blue-50/95 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800/60 text-xs text-blue-950 dark:text-blue-200 shadow-2xs animate-in fade-in">
                <div className="flex items-center gap-2 min-w-0">
                  <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                  <span className="truncate">
                    <strong>টিউটোরিয়াল:</strong> ছবির যে লেখাটি ঢাকতে চান, আঙুল বা মাউস টেনে সেটির ওপর বক্স আঁকুন।
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => setShowHelpModal(true)}
                    className="text-[11px] font-bold text-blue-700 dark:text-blue-300 underline underline-offset-2 hover:text-blue-800 cursor-pointer"
                  >
                    গাইড দেখুন
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowHintBanner(false)}
                    className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 rounded cursor-pointer"
                    title="টিপস বন্ধ করুন"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-sm text-gray-500 dark:text-gray-400 px-1">
              <span className="text-xs max-w-[200px] sm:max-w-none leading-tight">
                {isScrollMode ? 'নিচে যেতে ছবিটি ধরে টানুন' : 'আঁকতে আঙুল টানুন। নিচে যেতে "প্যান" এ যান'}
              </span>
              <div className="flex gap-2 sm:gap-3 md:gap-4 ml-auto flex-wrap justify-start sm:justify-end w-full sm:w-auto bg-white/50 dark:bg-slate-800/50 p-2 sm:p-1 rounded-2xl sm:rounded-none">
                <button
                  onClick={() => setIsEnhanceModal(true)}
                  disabled={isProcessing || isPreviewMode}
                  title="ছবির ব্রাইটনেস ও কনট্রাস্ট অ্যাডজাস্ট করুন (কালো বা অস্পষ্ট অংশ পরিষ্কার করতে)"
                  className="text-amber-600 dark:text-amber-400 font-semibold active:scale-95 flex items-center gap-1.5 disabled:opacity-50 transition-all hover:bg-amber-50 dark:hover:bg-amber-950/30 py-1.5 px-2.5 rounded-xl cursor-pointer"
                >
                  <Sun className="w-4 h-4" /> উজ্জ্বলতা
                </button>
                <button
                  onClick={() => setIsCropModal(true)}
                  disabled={isProcessing || isPreviewMode}
                  title="ছবির অপ্রয়োজনীয় অংশ ছেঁটে ফেলুন (Crop)"
                  className="text-indigo-600 font-semibold active:scale-95 flex items-center gap-1.5 disabled:opacity-50 transition-all hover:bg-indigo-50 dark:hover:bg-indigo-950/30 py-1.5 px-2.5 rounded-xl"
                >
                  <CropIcon className="w-4 h-4" /> ক্রপ
                </button>
                <button
                  onClick={() => handleFlipImage('horizontal')}
                  disabled={isProcessing || isPreviewMode}
                  title="ছবিকে আড়াআড়ি উল্টান (Flip Horizontal)"
                  className="text-teal-600 font-semibold active:scale-95 flex items-center gap-1.5 disabled:opacity-50 transition-all hover:bg-teal-50 dark:hover:bg-teal-950/30 py-1.5 px-2 rounded-xl"
                >
                  <FlipHorizontal className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleFlipImage('vertical')}
                  disabled={isProcessing || isPreviewMode}
                  title="ছবিকে লম্বালম্বি উল্টান (Flip Vertical)"
                  className="text-teal-600 font-medium active:scale-95 flex items-center gap-1 disabled:opacity-50 transition-colors hover:text-teal-700"
                >
                  <FlipVertical className="w-4 h-4" />
                </button>
                <button
                  onClick={handleRotateImage}
                  disabled={isProcessing || isPreviewMode}
                  title="ছবি ৯০ ডিগ্রি ঘোরান (Rotate)"
                  className="text-orange-600 font-semibold active:scale-95 flex items-center gap-1.5 disabled:opacity-50 transition-all hover:bg-orange-50 dark:hover:bg-orange-950/30 py-1.5 px-2.5 rounded-xl"
                >
                  <RotateCw className="w-4 h-4" /> রোটেট
                </button>
                <button
                  onClick={() => setIsErasingModal(true)}
                  disabled={isProcessing || isPreviewMode}
                  title="ব্রাশ দিয়ে দাগ মুছুন বা সাদা রং করুন (Markup)"
                  className="text-pink-600 font-semibold active:scale-95 flex items-center gap-1.5 disabled:opacity-50 transition-all hover:bg-pink-50 dark:hover:bg-pink-950/30 py-1.5 px-2.5 rounded-xl"
                >
                  <Eraser className="w-4 h-4" /> মার্কআপ
                </button>
                <button
                  onClick={() => { setToolMode('mask'); setIsScrollMode(false); }}
                  title="মাস্ক টুল: ছবিতে আঙুল বা মাউস ড্র্যাগ করে বক্স আঁকুন"
                  className={`font-semibold active:scale-95 flex items-center gap-1.5 transition-all py-1.5 px-2.5 rounded-xl ${toolMode === 'mask' && !isScrollMode ? 'text-blue-700 bg-blue-100 dark:bg-blue-900/40 dark:text-blue-300 shadow-sm' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700'}`}
                >
                  <Square className="w-4 h-4" /> মাস্ক
                </button>
                <button
                  onClick={() => { setToolMode('pin'); setIsScrollMode(false); }}
                  title="পিন টুল: নির্দিষ্ট বিন্দুতে ক্লিক করে পিন ও ক্লু বসান"
                  className={`font-semibold active:scale-95 flex items-center gap-1.5 transition-all py-1.5 px-2.5 rounded-xl ${toolMode === 'pin' && !isScrollMode ? 'text-red-700 bg-red-100 dark:bg-red-900/40 dark:text-red-300 shadow-sm' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700'}`}
                >
                  <MapPin className="w-4 h-4" /> পিন
                </button>
                <button
                  type="button"
                  onClick={() => setIsScrollMode(!isScrollMode)}
                  disabled={isPreviewMode}
                  title={isScrollMode ? 'আঁকা মোডে ফিরুন' : 'ছবি উপরে-নিচে স্ক্রোল বা নাড়াচাড়া করতে প্যান মোড চালু করুন'}
                  className={`font-semibold active:scale-95 flex items-center gap-1.5 disabled:opacity-50 transition-all py-1.5 px-2.5 rounded-xl ${isScrollMode ? 'text-amber-700 bg-amber-100 dark:bg-amber-900/40 dark:text-amber-300 shadow-sm' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700'}`}
                >
                  {isScrollMode ? <><PenTool className="w-4 h-4" /> আঁকুন</> : <><Hand className="w-4 h-4" /> প্যান</>}
                </button>
                
                <button
                  onClick={handleAutoDetect}
                  disabled={isProcessing || isPreviewMode}
                  title="AI দিয়ে ছবির লেখা শনাক্ত করে নিখুঁত মাস্ক তৈরি করুন"
                  className="text-purple-700 dark:text-purple-300 font-semibold active:scale-95 flex items-center gap-1.5 disabled:opacity-50 transition-all hover:bg-purple-100 dark:hover:bg-purple-900/60 bg-purple-50 dark:bg-purple-950/40 px-3 py-1.5 rounded-xl border border-purple-200 dark:border-purple-800/60 text-sm shadow-sm"
                >
                  {isProcessing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-purple-600" />}
                  <span>AI মাস্ক</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsPreviewMode(!isPreviewMode)}
                  title={isPreviewMode ? 'এডিট মোডে ফিরুন' : 'প্রিভিউ দেখুন'}
                  className={`font-semibold active:scale-95 flex items-center gap-1.5 transition-all py-1.5 px-2.5 rounded-xl ${isPreviewMode ? 'text-indigo-700 bg-indigo-100 dark:bg-indigo-900/40 dark:text-indigo-300 shadow-sm' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700'}`}
                >
                  {isPreviewMode ? <><Edit3 className="w-4 h-4" /> এডিট</> : <><Eye className="w-4 h-4" /> প্রিভিউ</>}
                </button>

                <button
                  type="button"
                  onClick={() => setShowBadges(!showBadges)}
                  title={showBadges ? 'নম্বর ব্যাজ (#১,#২...) ও দাগ গায়েব করুন' : 'নম্বর ব্যাজ ও দাগ চালু করুন'}
                  className={`font-medium active:scale-95 flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs transition-all ${showBadges ? 'bg-emerald-100 dark:bg-emerald-900/40 border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-400' : 'bg-white dark:bg-slate-700 border-slate-200 dark:border-slate-600 text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-600'}`}
                >
                  {showBadges ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  <span className="hidden sm:inline">{showBadges ? 'ব্যাজ অন' : 'ব্যাজ অফ'}</span>
                </button>
              </div>
            </div>

            {/* Precision Mask Fine-Tuning Bar */}
            {rectangles.length > 0 && !isPreviewMode && (
              <div className="flex items-center justify-between gap-2 p-2 px-3.5 rounded-2xl bg-white/70 dark:bg-slate-800/70 backdrop-blur-md border border-slate-200/60 dark:border-slate-700/60 shadow-sm text-xs flex-wrap">
                <div className="flex items-center gap-1.5 font-semibold text-slate-700 dark:text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                  <span>{rectangles.length} টি মাস্ক</span>
                  <span className="text-[11px] text-slate-400 font-normal hidden sm:inline">(নিখুঁত করার টুল)</span>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap ml-auto">
                  <button
                    type="button"
                    onClick={() => setShowMaskControls(!showMaskControls)}
                    title={showMaskControls ? 'মাস্কের এডিট ও ডিলিট বাটন লুকান' : 'সব মাস্কের এডিট ও ডিলিট বাটন দেখান'}
                    className={`flex items-center gap-1 px-2 py-1 rounded-md border active:scale-95 transition-all font-medium ${
                      showMaskControls 
                        ? 'bg-amber-100 dark:bg-amber-900/40 border-amber-300 dark:border-amber-700 text-amber-700 dark:text-amber-400'
                        : 'bg-white dark:bg-slate-700 border-slate-200 dark:border-slate-600 hover:bg-slate-50 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <Sliders className="w-3 h-3" />
                    <span>{showMaskControls ? 'বাটন হাইড' : 'বাটন শো'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => adjustAllMaskPadding(-2)}
                    title="সব মাস্ক ২ পিক্সেল টাইট করুন"
                    className="flex items-center gap-1 px-2 py-1 rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:bg-slate-50 active:scale-95 text-slate-700 dark:text-slate-200 transition-all font-medium"
                  >
                    <Minimize2 className="w-3 h-3 text-slate-500" />
                    <span>টাইট (-2px)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => adjustAllMaskPadding(2)}
                    title="সব মাস্ক ২ পিক্সেল বড় করুন যাতে সব অক্ষর ও কারচিহ্ন ঢাকা পড়ে"
                    className="flex items-center gap-1 px-2 py-1 rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:bg-slate-50 active:scale-95 text-slate-700 dark:text-slate-200 transition-all font-medium"
                  >
                    <Maximize2 className="w-3 h-3 text-slate-500" />
                    <span>বড় (+2px)</span>
                  </button>
                  <button
                    type="button"
                    onClick={mergeOverlappingMasks}
                    title="ওভারল্যাপ হওয়া মাস্ক একত্র করে একটি পরিষ্কার বক্সে পরিণত করুন"
                    className="flex items-center gap-1 px-2 py-1 rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:bg-slate-50 active:scale-95 text-indigo-600 dark:text-indigo-400 transition-all font-medium"
                  >
                    <Layers className="w-3 h-3" />
                    <span>মার্জ</span>
                  </button>
                  <button
                    type="button"
                    onClick={convertMasksToPins}
                    title="শনাক্তকৃত সব মাস্ককে পয়েন্টার পিনে রূপান্তর করুন"
                    className="flex items-center gap-1 px-2 py-1 rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:bg-slate-50 active:scale-95 text-red-600 dark:text-red-400 transition-all font-medium"
                  >
                    <MapPin className="w-3 h-3" />
                    <span>পিনে রূপান্তর</span>
                  </button>
                  <button
                    type="button"
                    onClick={clearAllMasks}
                    title="সব মাস্ক মুছে ফেলুন"
                    className="flex items-center gap-1 px-1.5 py-1 rounded-md text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 active:scale-95 transition-all"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
            
            <div className="flex justify-center bg-gray-200 rounded-xl overflow-hidden shadow-inner border border-gray-300">
              <div
                ref={wrapperRef}
                className={`relative inline-block select-none max-w-full ${isPreviewMode ? 'cursor-default' : (isScrollMode ? 'cursor-grab active:cursor-grabbing' : 'touch-none cursor-crosshair')}`}
                onMouseDown={(isPreviewMode || isScrollMode) ? undefined : startDrawing}
                onTouchStart={(isPreviewMode || isScrollMode) ? undefined : startDrawing}
                onClick={(e) => {
                  if (isPreviewMode || isScrollMode) return;
                  const rectBox = wrapperRef.current?.getBoundingClientRect();
                  if (!rectBox) return;
                  const clickX = e.clientX - rectBox.left;
                  const clickY = e.clientY - rectBox.top;
                  const clientW = wrapperRef.current?.clientWidth || 1000;
                  const clientH = wrapperRef.current?.clientHeight || 1000;

                  const hits = rectangles.filter(r => {
                    const box = getRectBox(r, clientW, clientH);
                    return clickX >= box.x && clickX <= box.x2 && clickY >= box.y && clickY <= box.y2;
                  });

                  if (hits.length > 1) {
                    setOverlappedPicker({ x: clickX, y: clickY, rects: hits });
                  } else if (hits.length === 1) {
                    setSelectedRectId(hits[0].id);
                    setOverlappedPicker(null);
                  } else {
                    setSelectedRectId(null);
                    setOverlappedPicker(null);
                  }
                }}
              >
                <img
                  ref={imageRef}
                  src={image}
                  alt="Preview"
                  className="max-w-full h-auto block pointer-events-none"
                  draggable={false}
                />

                {/* Floating Overlap Layer Picker Chip */}
                {overlappedPicker && (
                  <div
                    className="absolute z-50 bg-slate-900/95 text-white border border-amber-400/80 rounded-xl p-2 shadow-2xl backdrop-blur-md flex items-center gap-2 -translate-x-1/2"
                    style={{ left: overlappedPicker.x, top: Math.max(10, overlappedPicker.y - 50) }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="text-[11px] font-bold text-amber-300 flex items-center gap-1 shrink-0">
                      <Layers className="w-3.5 h-3.5" /> লেয়ার চয়ন:
                    </div>
                    <div className="flex items-center gap-1.5 overflow-x-auto max-w-[240px]">
                      {overlappedPicker.rects.map((r) => {
                        const idx = rectangles.findIndex(item => item.id === r.id);
                        return (
                          <button
                            key={r.id}
                            type="button"
                            onClick={() => {
                              bringRectToFront(r.id);
                              setSelectedRectId(r.id);
                              setOverlappedPicker(null);
                            }}
                            className={`px-2 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                              selectedRectId === r.id
                                ? 'bg-amber-500 text-slate-950 font-bold'
                                : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                            }`}
                          >
                            <span>#{idx + 1}</span>
                            {r.label && <span className="max-w-[70px] truncate">{r.label}</span>}
                          </button>
                        );
                      })}
                    </div>
                    <button
                      type="button"
                      onClick={() => setOverlappedPicker(null)}
                      className="text-slate-400 hover:text-white p-0.5 rounded-full"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
                
                {rectangles.map((rect, idx) => {
                  const pos = rect.badgePosition || cardBadgePosition || 'auto';
                  const xNorm = rect.xPercent !== undefined ? rect.xPercent : (rect.x / (wrapperRef.current?.clientWidth || 1000)) * 100;
                  const actualPos = pos === 'auto' ? (xNorm >= 50 ? 'right' : 'left') : pos;
                  const isLeft = actualPos === 'left';
                  const isRight = actualPos === 'right';
                  const isInside = actualPos === 'inside';
                  const isNearLeftEdge = (rect.xPercent !== undefined && rect.xPercent < 6);
                  const isNearRightEdge = (rect.xPercent !== undefined && (rect.xPercent + (rect.widthPercent || 0)) > 94);
                  const isSelected = selectedRectId === rect.id;

                  return (
                    <motion.div
                      key={rect.id}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ type: 'spring', stiffness: 260, damping: 20 }}
                      className={`absolute flex items-center justify-center transition-all ${
                        isPreviewMode 
                          ? 'bg-blue-600 border-none' 
                          : `border-2 ${isSelected ? 'border-amber-400 ring-2 ring-amber-400 ring-offset-1 z-30 shadow-lg' : 'border-blue-600'} bg-blue-500/40 cursor-move ${isDragging === rect.id ? 'opacity-70 border-dashed' : 'hover:bg-blue-500/60'}`
                      }`}
                      style={{
                        left: rect.xPercent !== undefined ? `${rect.xPercent}%` : `${rect.x}px`,
                        top: rect.yPercent !== undefined ? `${rect.yPercent}%` : `${rect.y}px`,
                        width: rect.widthPercent !== undefined ? `${rect.widthPercent}%` : `${rect.width}px`,
                        height: rect.heightPercent !== undefined ? `${rect.heightPercent}%` : `${rect.height}px`
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedRectId(rect.id);
                      }}
                      onDoubleClick={(e) => {
                        e.stopPropagation();
                        setEditingRectModal(rect);
                      }}
                      onMouseDown={(isPreviewMode || isScrollMode) ? undefined : (e) => startDragging(e, rect.id)}
                      onTouchStart={(isPreviewMode || isScrollMode) ? undefined : (e) => startDragging(e, rect.id)}
                    >
                      {/* Inside Badge (when user explicitly selects inside mode) */}
                      {showBadges && cardBadgePosition === 'inside' && rect.badgePosition !== 'hidden' && (
                        <span className="absolute pointer-events-none z-20 font-mono font-bold text-[10px] px-1.5 py-0.5 rounded shadow-md border whitespace-nowrap bg-slate-950/90 text-amber-300 border-amber-400/80 flex items-center justify-center top-1 left-1" title={`আইটেম #${idx + 1}`}>
                          #{idx + 1}
                        </span>
                      )}

                      {!isPreviewMode && !isScrollMode && (showMaskControls || selectedRectId === rect.id || hoveredRectId === rect.id) && (
                        <>
                          <Move className="w-4 h-4 text-white opacity-50 pointer-events-none" />
                          
                          {/* Detected Label Badge */}
                          {rect.label && (
                            <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 bg-blue-900/90 text-white font-medium text-[9px] px-1.5 py-0.5 rounded shadow whitespace-nowrap pointer-events-none z-10 max-w-[120px] truncate border border-blue-700">
                              {rect.label}
                            </span>
                          )}

                          {/* Edit Button Handle (Left Corner) */}
                          <button
                            type="button"
                            title="আড়াল সম্পাদনা ও টেক্সট পরিবর্তন (Edit Mask)"
                            className="absolute -top-3.5 -left-3.5 w-7 h-7 sm:w-8 sm:h-8 bg-blue-600 hover:bg-blue-700 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-white dark:border-slate-800 z-20 transition-transform active:scale-90 cursor-pointer"
                            onMouseDown={(e) => {
                              e.stopPropagation();
                              e.preventDefault();
                              setEditingRectModal(rect);
                            }}
                            onTouchStart={(e) => {
                              e.stopPropagation();
                              e.preventDefault();
                              setEditingRectModal(rect);
                            }}
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          {/* Delete Handle (Right Corner) */}
                          <button
                            type="button"
                            title="মাস্ক মুছে ফেলুন"
                            className="absolute -top-3.5 -right-3.5 w-7 h-7 sm:w-8 sm:h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-white dark:border-slate-800 z-10 transition-transform active:scale-90 cursor-pointer"
                            onMouseDown={(e) => {
                              e.stopPropagation();
                              e.preventDefault();
                              setRectangles(prev => prev.filter(r => r.id !== rect.id));
                            }}
                            onTouchStart={(e) => {
                              e.stopPropagation();
                              e.preventDefault();
                              setRectangles(prev => prev.filter(r => r.id !== rect.id));
                            }}
                          >
                            <X className="w-4 h-4" />
                          </button>

                          {/* Resize Handle */}
                          <div
                            className="absolute bottom-0 right-0 w-4 h-4 bg-blue-600 cursor-se-resize rounded-tl-sm"
                            style={{ transform: 'translate(50%, 50%)' }}
                            onMouseDown={(e) => startResizing(e, rect.id)}
                            onTouchStart={(e) => startResizing(e, rect.id)}
                          />
                        </>
                      )}
                    </motion.div>
                  );
                })}
                
                {currentRect && (
                  <div
                    className="absolute border-2 border-blue-600 border-dashed bg-blue-400/50 pointer-events-none"
                    style={{
                      left: currentRect.x,
                      top: currentRect.y,
                      width: currentRect.width,
                      height: currentRect.height
                    }}
                  />
                )}

                {pins.map((pin, pIdx) => {
                  const pinNumber = rectangles.length + pIdx + 1;

                  return (
                    <motion.div
                      key={pin.id}
                      initial={{ opacity: 0, scale: 0.8, y: -24, x: "-50%" }}
                      animate={{ opacity: 1, scale: 1, y: -24, x: "-50%" }}
                      transition={{ type: 'spring', stiffness: 260, damping: 20 }}
                      className={`absolute z-10 flex flex-col items-center justify-center ${
                        (!isPreviewMode && !isScrollMode) ? 'cursor-move' : ''
                      } ${isDraggingPin === pin.id ? 'scale-110 opacity-80' : ''}`}
                      style={{
                        left: pin.xPercent !== undefined ? `${pin.xPercent}%` : `${pin.x}px`,
                        top: pin.yPercent !== undefined ? `${pin.yPercent}%` : `${pin.y}px`
                      }}
                      onMouseDown={(isPreviewMode || isScrollMode) ? undefined : (e) => startDraggingPin(e, pin.id)}
                      onTouchStart={(isPreviewMode || isScrollMode) ? undefined : (e) => startDraggingPin(e, pin.id)}
                    >
                      {!isPreviewMode && (
                        <button
                          onClick={(e) => { e.stopPropagation(); setPins(prev => prev.filter(p => p.id !== pin.id)); }}
                          className="absolute -top-3 -right-3 w-5 h-5 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-md z-20"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                      {/* Compact clean numbered pin bubble */}
                      <div className="bg-red-500 w-6 h-6 rounded-full border-2 border-white shadow-md relative z-10 flex items-center justify-center text-[10px] font-mono font-black text-white">
                        {pinNumber}
                      </div>
                      <div className="mt-1 bg-white text-gray-900 font-bold px-2 py-0.5 rounded shadow text-xs whitespace-nowrap border border-gray-200">
                        {pin.label}
                      </div>
                    </motion.div>
                  );
                })}

                {pinPrompt && (
                  <div 
                    className="absolute z-50 bg-white p-3 rounded-lg shadow-xl border border-gray-200 -translate-x-1/2 -translate-y-[100%]"
                    style={{ left: pinPrompt.x, top: pinPrompt.y - 10 }}
                    onClick={e => e.stopPropagation()}
                    onMouseDown={e => e.stopPropagation()}
                    onTouchStart={e => e.stopPropagation()}
                  >
                    <input
                      autoFocus
                      type="text"
                      placeholder="অংশের নাম লিখুন..."
                      className="border border-gray-300 rounded px-2 py-1 text-sm mb-2 w-40 focus:outline-none focus:border-blue-500 text-gray-900"
                      value={pinPrompt.label}
                      onChange={e => setPinPrompt({ ...pinPrompt, label: e.target.value })}
                      onKeyDown={e => {
                        if (e.key === 'Enter' && pinPrompt.label.trim()) {
                          const clientW = wrapperRef.current?.clientWidth || 1;
                          const clientH = wrapperRef.current?.clientHeight || 1;
                          setPins(prev => [...prev, {
                            id: Date.now(),
                            x: pinPrompt.x,
                            y: pinPrompt.y,
                            xPercent: (pinPrompt.x / clientW) * 100,
                            yPercent: (pinPrompt.y / clientH) * 100,
                            label: pinPrompt.label.trim()
                          }]);
                          setPinPrompt(null);
                        }
                      }}
                    />
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setPinPrompt(null)}
                        className="flex-1 text-xs bg-gray-100 py-1 rounded hover:bg-gray-200 text-gray-700"
                      >
                        বাতিল
                      </button>
                      <button 
                        onClick={() => {
                          if (pinPrompt.label.trim()) {
                            const clientW = wrapperRef.current?.clientWidth || 1;
                            const clientH = wrapperRef.current?.clientHeight || 1;
                            setPins(prev => [...prev, {
                              id: Date.now(),
                              x: pinPrompt.x,
                              y: pinPrompt.y,
                              xPercent: (pinPrompt.x / clientW) * 100,
                              yPercent: (pinPrompt.y / clientH) * 100,
                              label: pinPrompt.label.trim()
                            }]);
                            setPinPrompt(null);
                          }
                        }}
                        className="flex-1 text-xs bg-blue-600 text-white py-1 rounded hover:bg-blue-700 font-medium"
                      >
                        যোগ করুন
                      </button>
                    </div>
                  </div>
                )}

                {/* Edge-pinned Badges and Leader Lines (#1, #2...) */}
                {showBadges && cardBadgePosition !== 'inside' && cardBadgePosition !== 'hidden' && (
                  <>
                    <svg className="absolute inset-0 w-full h-full pointer-events-none z-20 overflow-visible">
                      {computedSideBadges.map(b => (
                        <g key={`leader-create-${b.id}`}>
                          <line
                            x1={`${b.anchorX}%`}
                            y1={`${b.anchorY}%`}
                            x2={`${b.targetX}%`}
                            y2={`${b.targetY}%`}
                            stroke="rgba(0,0,0,0.6)"
                            strokeWidth="2.5"
                          />
                          <line
                            x1={`${b.anchorX}%`}
                            y1={`${b.anchorY}%`}
                            x2={`${b.targetX}%`}
                            y2={`${b.targetY}%`}
                            stroke={hoveredRectId === b.id || selectedRectId === b.id ? "#fbbf24" : "rgba(251, 191, 36, 0.75)"}
                            strokeWidth={hoveredRectId === b.id || selectedRectId === b.id ? "2" : "1.2"}
                            strokeDasharray={hoveredRectId === b.id || selectedRectId === b.id ? "none" : "3 3"}
                          />
                          <circle
                            cx={`${b.targetX}%`}
                            cy={`${b.targetY}%`}
                            r={hoveredRectId === b.id || selectedRectId === b.id ? 4 : 2.5}
                            fill="#fbbf24"
                            stroke="#0f172a"
                            strokeWidth="1"
                          />
                        </g>
                      ))}
                    </svg>

                    {computedSideBadges.map(b => (
                      <button
                        key={`badge-create-${b.id}`}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedRectId(b.id);
                        }}
                        onDoubleClick={(e) => {
                          e.stopPropagation();
                          const targetRect = rectangles.find(r => r.id === b.id);
                          if (targetRect) setEditingRectModal(targetRect);
                        }}
                        onMouseEnter={() => setHoveredRectId(b.id)}
                        onMouseLeave={() => setHoveredRectId(null)}
                        className={`absolute z-30 font-mono font-black text-[10px] sm:text-[11px] px-1.5 py-0.5 rounded shadow-lg border flex items-center justify-center cursor-pointer transition-all active:scale-95 ${
                          selectedRectId === b.id || hoveredRectId === b.id
                            ? 'bg-amber-400 text-slate-950 border-amber-300 ring-2 ring-amber-300/80 scale-110 shadow-[0_0_12px_rgba(251,191,36,0.8)]'
                            : 'bg-slate-950/90 text-amber-300 border-amber-400/80 hover:bg-slate-900'
                        }`}
                        style={{
                          left: `${b.displayX}%`,
                          top: `${b.displayY}%`,
                          transform: 'translateY(-50%)'
                        }}
                        title={`মাস্ক #${b.idx + 1}: ${b.label || 'চিহ্নিত অংশ'} (ক্লিক করে সিলেক্ট করুন)`}
                      >
                        #{b.idx + 1}
                      </button>
                    ))}
                  </>
                )}
              </div>
            </div>

            {/* Item List & Badge Placement Management */}
            {(rectangles.length > 0 || pins.length > 0) && (
              <div className="mt-6 bg-slate-900 border border-slate-700/80 rounded-2xl p-5 shadow-xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-amber-500/10 rounded-lg text-amber-400 border border-amber-500/20">
                      <ListOrdered className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-white font-bold text-base flex items-center gap-2">
                          নম্বর, লেয়ার ও লেবেল নিয়ন্ত্রণ
                          <span className="bg-slate-800 text-amber-300 font-mono text-xs px-2 py-0.5 rounded-full border border-slate-700">
                            মোট {rectangles.length + pins.length} টি
                          </span>
                        </h3>
                        {(() => {
                          const overlapInfo = checkHasOverlaps(rectangles);
                          if (overlapInfo.count > 0) {
                            return (
                              <button
                                type="button"
                                onClick={mergeOverlappingMasks}
                                className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold shadow-md active:scale-95 transition-all cursor-pointer animate-pulse"
                                title="ওভারল্যাপ করা মাস্কগুলো এক ক্লিকে মার্জ করে পরিষ্কার বক্সে রূপান্তর করুন"
                              >
                                <Split className="w-3.5 h-3.5" />
                                <span>⚠️ {overlapInfo.count}টি ওভারল্যাপ! মার্জ করুন</span>
                              </button>
                            );
                          }
                          return null;
                        })()}
                      </div>
                      <p className="text-xs text-slate-400">
                        চিত্র যাতে পরিষ্কার ও বাধারহিত দেখা যায়, তাই ডিফল্টভাবে নম্বর ব্যাজগুলো (#১, #২...) চিত্র থেকে দূরে পাশে বসানো হয়। প্রতিটি মাস্ক এডিট ও লেয়ার পরিবর্তন করতে পারবেন।
                      </p>
                    </div>
                  </div>

                  {/* Bulk Badge Position Switcher & Master Toggle */}
                  <div className="flex flex-wrap items-center gap-2 bg-slate-800/80 p-1.5 rounded-xl border border-slate-700 text-xs">
                    {/* Master ON/OFF Toggle */}
                    <button
                      type="button"
                      onClick={() => setShowBadges(!showBadges)}
                      className={`px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all shadow-sm ${
                        showBadges 
                          ? 'bg-emerald-600 text-white hover:bg-emerald-500 ring-1 ring-emerald-400' 
                          : 'bg-rose-950/90 text-rose-300 border border-rose-800 hover:bg-rose-900'
                      }`}
                      title="সকল নম্বর ব্যাজ (#১,#২...) ও লিডার লাইন দাগ অন বা সম্পূর্ণ গায়েব করুন"
                    >
                      {showBadges ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                      <span>{showBadges ? 'ব্যাজ ও দাগ: অন' : 'ব্যাজ ও দাগ: অফ (গায়েব)'}</span>
                    </button>

                    <div className="h-4 w-px bg-slate-700 mx-0.5" />

                    <span className="text-slate-400 pl-1 font-medium">পজিশন:</span>
                    <button
                      type="button"
                      onClick={() => {
                        setCardBadgePosition('auto');
                        setRectangles(prev => prev.map(r => ({ ...r, badgePosition: 'auto', badgeDistance: 'far' })));
                        setPins(prev => prev.map(p => ({ ...p, badgePosition: 'auto', badgeDistance: 'far' })));
                      }}
                      className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                        cardBadgePosition === 'auto' ? 'bg-amber-500 text-slate-950 shadow-md ring-1 ring-amber-300' : 'text-slate-300 hover:bg-slate-700'
                      }`}
                      title="স্বয়ংক্রিয়ভাবে অঙ্গ বা চিত্রের বাইরে পর্যাপ্ত দূরত্বে ব্যাজ বসাবে যাতে ছবি দেখে সহজে শনাক্ত ও মনে রাখা যায়"
                    >
                      স্মার্ট (চিত্র থেকে দূরে)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCardBadgePosition('left');
                        setRectangles(prev => prev.map(r => ({ ...r, badgePosition: 'left', badgeDistance: 'far' })));
                        setPins(prev => prev.map(p => ({ ...p, badgePosition: 'left', badgeDistance: 'far' })));
                      }}
                      className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                        cardBadgePosition === 'left' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-300 hover:bg-slate-700'
                      }`}
                      title="চিত্রের বাম পাশে দূরে ব্যাজ রাখুন"
                    >
                      বাম পাশে (দূরে)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCardBadgePosition('right');
                        setRectangles(prev => prev.map(r => ({ ...r, badgePosition: 'right', badgeDistance: 'far' })));
                        setPins(prev => prev.map(p => ({ ...p, badgePosition: 'right', badgeDistance: 'far' })));
                      }}
                      className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                        cardBadgePosition === 'right' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-300 hover:bg-slate-700'
                      }`}
                      title="চিত্রের ডান পাশে দূরে ব্যাজ রাখুন"
                    >
                      ডান পাশে (দূরে)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCardBadgePosition('inside');
                        setRectangles(prev => prev.map(r => ({ ...r, badgePosition: 'inside' })));
                        setPins(prev => prev.map(p => ({ ...p, badgePosition: 'inside' })));
                      }}
                      className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                        cardBadgePosition === 'inside' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-300 hover:bg-slate-700'
                      }`}
                      title="মাস্কের ভেতরে কোণায় ব্যাজ রাখুন"
                    >
                      ভেতরে
                    </button>
                  </div>
                </div>

                {/* Items Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-80 overflow-y-auto pr-1">
                  {rectangles.map((rect, idx) => {
                    const pos = rect.badgePosition || cardBadgePosition || 'auto';
                    return (
                      <div
                        key={rect.id}
                        className="flex items-center justify-between gap-2 p-3 bg-slate-800/60 rounded-xl border border-slate-700/70 hover:border-slate-600 transition-colors"
                      >
                        <div className="flex items-center gap-2.5 flex-1 min-w-0">
                          <span className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 font-mono font-bold text-xs flex items-center justify-center border border-amber-500/40 shrink-0">
                            #{idx + 1}
                          </span>
                          <input
                            type="text"
                            value={rect.label || ''}
                            placeholder={`মাস্ক #${idx + 1} এর নাম...`}
                            onChange={(e) => {
                              const val = e.target.value;
                              setRectangles(prev => prev.map(r => r.id === rect.id ? { ...r, label: val } : r));
                            }}
                            className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 flex-1 min-w-0"
                          />
                        </div>

                        {/* Individual Badge Position selector & Edit Controls */}
                        <div className="flex items-center gap-1 shrink-0">
                          {rect.label && (
                            <button
                              type="button"
                              onClick={() => speakText(rect.label)}
                              className="p-1 rounded text-slate-400 hover:text-blue-400 hover:bg-slate-700"
                              title="উচ্চারণ শুনুন"
                            >
                              <Volume2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Edit Mask Button */}
                          <button
                            type="button"
                            onClick={() => setEditingRectModal(rect)}
                            className="px-2 py-1 rounded bg-blue-600/40 hover:bg-blue-600 text-blue-200 hover:text-white text-[11px] font-semibold flex items-center gap-1 transition-colors"
                            title="আড়াল সম্পাদনা (Edit Mask)"
                          >
                            <Edit3 className="w-3 h-3" />
                            <span>এডিট</span>
                          </button>

                          {/* Specific mask badge & line ON/OFF toggle (e.g. hide #5 or #6 specifically) */}
                          <button
                            type="button"
                            onClick={() => {
                              const isHidden = pos === 'hidden';
                              const next = isHidden ? (cardBadgePosition || 'auto') : 'hidden';
                              setRectangles(prev => prev.map(r => r.id === rect.id ? { ...r, badgePosition: next, badgeDistance: 'far' } : r));
                            }}
                            className={`px-2 py-1 rounded border text-[11px] font-semibold flex items-center gap-1 transition-all ${
                              pos === 'hidden'
                                ? 'bg-rose-950/80 border-rose-800 text-rose-300 hover:bg-rose-900 shadow-xs'
                                : 'bg-slate-700/80 border-slate-600 text-slate-300 hover:bg-slate-600 hover:text-white'
                            }`}
                            title={pos === 'hidden' ? `মাস্ক #${idx + 1} এর ব্যাজ ও দাগ গায়েব করা আছে (ক্লিক করে অন করুন)` : `মাস্ক #${idx + 1} এর ব্যাজ ও দাগ চালু আছে (ক্লিক করে গায়েব করুন)`}
                          >
                            {pos === 'hidden' ? <EyeOff className="w-3.5 h-3.5 text-rose-400" /> : <Eye className="w-3.5 h-3.5 text-emerald-400" />}
                            <span>{pos === 'hidden' ? 'গায়েব' : 'অন'}</span>
                          </button>

                          {pos !== 'hidden' && (
                            <button
                              type="button"
                              onClick={() => {
                                const next = pos === 'auto' ? 'left' : (pos === 'left' ? 'right' : (pos === 'right' ? 'inside' : 'auto'));
                                setRectangles(prev => prev.map(r => r.id === rect.id ? { ...r, badgePosition: next, badgeDistance: 'far' } : r));
                              }}
                              className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-slate-300 text-[11px] font-mono font-semibold"
                              title="ব্যাজ অবস্থান পরিবর্তন করুন (স্মার্ট দূরে / বাম / ডান / ভেতর)"
                            >
                              {pos === 'auto' ? 'স্মার্ট' : (pos === 'left' ? 'বাম' : (pos === 'inside' ? 'ভেতর' : 'ডান'))}
                            </button>
                          )}

                          {/* Reorder Up */}
                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={() => {
                              if (idx === 0) return;
                              setRectangles(prev => {
                                const copy = [...prev];
                                const temp = copy[idx - 1];
                                copy[idx - 1] = copy[idx];
                                copy[idx] = temp;
                                return copy;
                              });
                            }}
                            className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-30 hover:bg-slate-700"
                            title="উপরে নিন (নম্বর কমান)"
                          >
                            <ChevronUp className="w-3.5 h-3.5" />
                          </button>

                          {/* Reorder Down */}
                          <button
                            type="button"
                            disabled={idx === rectangles.length - 1}
                            onClick={() => {
                              if (idx === rectangles.length - 1) return;
                              setRectangles(prev => {
                                const copy = [...prev];
                                const temp = copy[idx + 1];
                                copy[idx + 1] = copy[idx];
                                copy[idx] = temp;
                                return copy;
                              });
                            }}
                            className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-30 hover:bg-slate-700"
                            title="নিচে নিন (নম্বর বাড়ান)"
                          >
                            <ChevronDown className="w-3.5 h-3.5" />
                          </button>

                          {/* Layer Bring to Front */}
                          <button
                            type="button"
                            onClick={() => bringRectToFront(rect.id)}
                            className="p-1 rounded text-slate-400 hover:text-amber-400 hover:bg-slate-700"
                            title="লেয়ার সর্বউপরে আনুন (Bring to Front)"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>

                          {/* Layer Send to Back */}
                          <button
                            type="button"
                            onClick={() => sendRectToBack(rect.id)}
                            className="p-1 rounded text-slate-400 hover:text-orange-400 hover:bg-slate-700"
                            title="লেয়ার নিচে পাঠান (Send to Back)"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete */}
                          <button
                            type="button"
                            onClick={() => setRectangles(prev => prev.filter(r => r.id !== rect.id))}
                            className="p-1 rounded text-red-400 hover:text-red-300 hover:bg-red-500/20"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}

                  {pins.map((pin, pIdx) => {
                    const pinNumber = rectangles.length + pIdx + 1;
                    const pos = pin.badgePosition || cardBadgePosition || 'left';
                    return (
                      <div
                        key={pin.id}
                        className="flex items-center justify-between gap-2 p-3 bg-slate-800/60 rounded-xl border border-slate-700/70 hover:border-slate-600 transition-colors"
                      >
                        <div className="flex items-center gap-2.5 flex-1 min-w-0">
                          <span className="w-7 h-7 rounded-lg bg-red-500/20 text-red-400 font-mono font-bold text-xs flex items-center justify-center border border-red-500/40 shrink-0">
                            #{pinNumber}
                          </span>
                          <input
                            type="text"
                            value={pin.label}
                            placeholder={`পিন #${pinNumber} এর নাম...`}
                            onChange={(e) => {
                              const val = e.target.value;
                              setPins(prev => prev.map(p => p.id === pin.id ? { ...p, label: val } : p));
                            }}
                            className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-400 flex-1 min-w-0"
                          />
                        </div>

                        {/* Individual Badge Position selector */}
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              const next = pos === 'auto' ? 'left' : (pos === 'left' ? 'right' : (pos === 'right' ? 'inside' : 'auto'));
                              setPins(prev => prev.map(p => p.id === pin.id ? { ...p, badgePosition: next, badgeDistance: 'far' } : p));
                            }}
                            className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-slate-300 text-[11px] font-mono font-semibold"
                            title="ব্যাজ অবস্থান পরিবর্তন করুন (স্মার্ট দূরে / বাম / ডান / ভেতর)"
                          >
                            {pos === 'auto' ? 'স্মার্ট' : (pos === 'left' ? 'বাম' : (pos === 'inside' ? 'ভেতর' : 'ডান'))}
                          </button>

                          {/* Delete Pin */}
                          <button
                            type="button"
                            onClick={() => setPins(prev => prev.filter(p => p.id !== pin.id))}
                            className="p-1 rounded text-red-400 hover:text-red-300 hover:bg-red-500/20"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
    </main>
      {/* Mask Edit Modal */}
      {editingRectModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-in fade-in">
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-5 max-w-md w-full shadow-2xl border border-gray-200 dark:border-slate-700 flex flex-col gap-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b pb-3 dark:border-slate-700">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <h3 className="font-bold text-gray-900 dark:text-white text-base">
                  আড়াল সম্পাদনা (মাস্ক #{rectangles.findIndex(r => r.id === editingRectModal.id) + 1})
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingRectModal(null)}
                className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex flex-col gap-3">
              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300 mb-1 flex items-center justify-between">
                  <span>মাস্ক লেবেল / নাম (উত্তর)</span>
                  {editingRectModal.label && (
                    <button
                      type="button"
                      onClick={() => speakText(editingRectModal.label)}
                      className="text-xs text-blue-600 dark:text-blue-400 flex items-center gap-1 font-semibold hover:underline"
                    >
                      <Volume2 className="w-3.5 h-3.5" /> উচ্চারণ শুনুন
                    </button>
                  )}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={editingRectModal.label || ''}
                    onChange={(e) => setEditingRectModal({ ...editingRectModal, label: e.target.value })}
                    placeholder="যেমন: কোষপ্রাচীর, মাইটোকন্ড্রিয়া, কান্ড..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                    autoFocus
                  />
                  {editingRectModal.label && (
                    <button
                      type="button"
                      onClick={() => setEditingRectModal({ ...editingRectModal, label: '' })}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-1"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5 block">
                  ব্যাজ ও দাগের অবস্থান (Badge & Line Position)
                </label>
                <div className="grid grid-cols-5 gap-1.5">
                  {[
                    { key: 'auto', label: 'স্বয়ংক্রিয়' },
                    { key: 'left', label: 'বামে' },
                    { key: 'right', label: 'ডানে' },
                    { key: 'inside', label: 'ভেতরে' },
                    { key: 'hidden', label: 'গায়েব (অফ)' }
                  ].map(item => (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => setEditingRectModal({ ...editingRectModal, badgePosition: item.key as any })}
                      className={`py-1.5 px-1 rounded-lg text-xs font-bold transition-all text-center ${
                        (editingRectModal.badgePosition || 'auto') === item.key
                          ? (item.key === 'hidden' ? 'bg-rose-600 text-white shadow-xs' : 'bg-blue-600 text-white shadow-xs')
                          : 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5 block">
                  লেয়ারের ক্রম (Layer Order)
                </label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => bringRectToFront(editingRectModal.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-gray-300 dark:border-slate-600 hover:bg-gray-100 dark:hover:bg-slate-700 text-xs font-semibold text-gray-800 dark:text-gray-200 transition-colors"
                  >
                    <ArrowUp className="w-4 h-4 text-blue-500" />
                    <span>উপরে আনুন (Bring to Front)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => sendRectToBack(editingRectModal.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-gray-300 dark:border-slate-600 hover:bg-gray-100 dark:hover:bg-slate-700 text-xs font-semibold text-gray-800 dark:text-gray-200 transition-colors"
                  >
                    <ArrowDown className="w-4 h-4 text-orange-500" />
                    <span>নিচে পাঠান (Send to Back)</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5 block">
                  আকার ও পজিশন সূক্ষ্ম সমন্বয় (Fine Tune)
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center justify-between p-2 rounded-xl bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700">
                    <span className="font-medium text-gray-600 dark:text-gray-400">প্রস্থ (Width)</span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          const clientW = wrapperRef.current?.clientWidth || 1000;
                          const curW = editingRectModal.widthPercent !== undefined ? (editingRectModal.widthPercent / 100) * clientW : editingRectModal.width;
                          const newW = Math.max(10, curW - 5);
                          setEditingRectModal({
                            ...editingRectModal,
                            width: newW,
                            widthPercent: (newW / clientW) * 100
                          });
                        }}
                        className="w-6 h-6 rounded-md bg-gray-200 dark:bg-slate-700 font-bold flex items-center justify-center hover:bg-gray-300"
                      >
                        -
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const clientW = wrapperRef.current?.clientWidth || 1000;
                          const curW = editingRectModal.widthPercent !== undefined ? (editingRectModal.widthPercent / 100) * clientW : editingRectModal.width;
                          const newW = curW + 5;
                          setEditingRectModal({
                            ...editingRectModal,
                            width: newW,
                            widthPercent: (newW / clientW) * 100
                          });
                        }}
                        className="w-6 h-6 rounded-md bg-gray-200 dark:bg-slate-700 font-bold flex items-center justify-center hover:bg-gray-300"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-2 rounded-xl bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700">
                    <span className="font-medium text-gray-600 dark:text-gray-400">উচ্চতা (Height)</span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          const clientH = wrapperRef.current?.clientHeight || 1000;
                          const curH = editingRectModal.heightPercent !== undefined ? (editingRectModal.heightPercent / 100) * clientH : editingRectModal.height;
                          const newH = Math.max(10, curH - 5);
                          setEditingRectModal({
                            ...editingRectModal,
                            height: newH,
                            heightPercent: (newH / clientH) * 100
                          });
                        }}
                        className="w-6 h-6 rounded-md bg-gray-200 dark:bg-slate-700 font-bold flex items-center justify-center hover:bg-gray-300"
                      >
                        -
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const clientH = wrapperRef.current?.clientHeight || 1000;
                          const curH = editingRectModal.heightPercent !== undefined ? (editingRectModal.heightPercent / 100) * clientH : editingRectModal.height;
                          const newH = curH + 5;
                          setEditingRectModal({
                            ...editingRectModal,
                            height: newH,
                            heightPercent: (newH / clientH) * 100
                          });
                        }}
                        className="w-6 h-6 rounded-md bg-gray-200 dark:bg-slate-700 font-bold flex items-center justify-center hover:bg-gray-300"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t dark:border-slate-700">
              <button
                type="button"
                onClick={() => handleDeleteRect(editingRectModal.id)}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 text-xs font-bold transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>মুছে ফেলুন</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEditingRectModal(null)}
                  className="px-4 py-2 rounded-xl border border-gray-300 dark:border-slate-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 text-xs font-bold transition-colors"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveEditedRect(editingRectModal)}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md transition-all active:scale-95 cursor-pointer"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <OcclusionHelpModal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
      />

      {image && (
        <ImageEnhanceModal
          isOpen={isEnhanceModal}
          imageSrc={image}
          onApply={(enhanced) => {
            setImage(enhanced);
            setAlertMsg('ছবির ব্রাইটনেস ও কনট্রাস্ট সফলভাবে আপডেট করা হয়েছে!');
            setTimeout(() => setAlertMsg(''), 2500);
          }}
          onClose={() => setIsEnhanceModal(false)}
        />
      )}

      {/* 3rd Option: Auto Bulk Processing In-Progress Modal */}
      {isAutoBulkActive && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl flex flex-col gap-5 text-white">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/30 text-amber-400 flex items-center justify-center shrink-0 animate-pulse">
                <Zap className="w-6 h-6 fill-amber-400" />
              </div>
              <div>
                <span className="text-[11px] font-black uppercase tracking-wider text-amber-400">
                  ৩য় অপশন • ফুল অটোমেশন
                </span>
                <h3 className="text-xl font-black text-white">
                  সম্পূর্ণ অটোমেটিক বাল্ক ইঞ্জিন চলছে...
                </h3>
              </div>
            </div>

            {/* Progress Bar & Counter */}
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-slate-300 truncate max-w-[280px]">
                  📸 {autoBulkProgress.title || 'ছবি প্রসেস হচ্ছে...'}
                </span>
                <span className="text-amber-400 font-mono">
                  {autoBulkProgress.current} / {autoBulkProgress.total} ({Math.round((autoBulkProgress.current / Math.max(1, autoBulkProgress.total)) * 100)}%)
                </span>
              </div>
              <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <div 
                  className="h-full bg-gradient-to-r from-amber-500 to-amber-400 transition-all duration-300 rounded-full shadow-[0_0_12px_rgba(251,191,36,0.6)]"
                  style={{ width: `${(autoBulkProgress.current / Math.max(1, autoBulkProgress.total)) * 100}%` }}
                />
              </div>
              <p className="text-xs text-amber-300/90 font-medium flex items-center gap-2 mt-1">
                <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
                <span>{autoBulkProgress.step}</span>
              </p>
            </div>

            {/* Automated Steps Features */}
            <div className="grid grid-cols-2 gap-2.5 pt-2 border-t border-slate-800 text-[11px] text-slate-300">
              <div className="flex items-center gap-2 bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/60">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>কোয়ালিটি ও কনট্রাস্ট অপটিমাইজেশন</span>
              </div>
              <div className="flex items-center gap-2 bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/60">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>অটো বিষয় ও শিরোনাম</span>
              </div>
              <div className="flex items-center gap-2 bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/60">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>একাডেমিক স্টাডি নোট</span>
              </div>
              <div className="flex items-center gap-2 bg-slate-800/60 p-2.5 rounded-xl border border-slate-700/60">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>নিখুঁত মাস্ক ও এজ-ব্যাজ (#1, #2)</span>
              </div>
            </div>

            <div className="text-center pt-1">
              <span className="text-[11px] text-slate-400">
                দয়া করে অপেক্ষা করুন, সবগুলো কার্ড একসাথেই প্রস্তুত হয়ে যাবে।
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 3rd Option: Auto Bulk Completed Summary Modal */}
      {showAutoBulkSummary && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-xl w-full shadow-2xl flex flex-col gap-5 text-white max-h-[90vh]">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-white">
                    🎉 {autoBulkCompletedCards.length}টি স্টাডি কার্ড স্বয়ংক্রিয়ভাবে প্রস্তুত!
                  </h3>
                  <p className="text-xs text-slate-400">
                    প্রতিটি ছবির নাম, নোট, মাস্ক এবং কোয়ালিটি স্বয়ংক্রিয়ভাবে তৈরি হয়েছে।
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAutoBulkSummary(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* List of processed cards */}
            <div className="flex flex-col gap-2.5 overflow-y-auto max-h-[320px] pr-1.5 custom-scrollbar">
              {autoBulkCompletedCards.map((card, cIdx) => (
                <div
                  key={card.id}
                  className="flex items-center justify-between gap-3 p-3 bg-slate-800/70 border border-slate-700/80 rounded-2xl"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-12 h-12 rounded-xl bg-slate-700 border border-slate-600 shrink-0 flex items-center justify-center text-slate-400">
                      <ImageIcon className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-bold text-sm text-white truncate">
                        {card.title}
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                        <span className="text-amber-400 font-semibold">
                          🎯 {card.rectangles?.length || 0}টি মাস্ক
                        </span>
                        {card.notes && <span>• 📝 নোট যুক্ত</span>}
                        <span>• ✨ হাই-কোয়ালিটি</span>
                      </div>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-500 px-2">
                    #{cIdx + 1}
                  </span>
                </div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={handleReviewAutoBulkCards}
                className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm border border-slate-700 transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Eye className="w-4 h-4" />
                <span>👀 কার্ডগুলো প্রিভিউ ও এডিট করুন</span>
              </button>
              <button
                type="button"
                onClick={handleSaveAllAutoBulkCards}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/20 transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>💾 সরাসরি সেভ করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
