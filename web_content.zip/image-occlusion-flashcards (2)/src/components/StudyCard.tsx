import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  Moon, Home, ArrowRight, CheckCircle, Eye, EyeOff, Edit3, ZoomIn, ZoomOut, 
  Maximize, Maximize2, Minimize2, Sparkles, Volume2, VolumeX, Square, Keyboard, 
  MousePointer, Layers, Check, X, HelpCircle, RotateCcw, ListChecks, CheckCheck, 
  RefreshCw, ChevronLeft, ChevronRight, Tag, Settings, SlidersHorizontal, FileText, BookOpen,
  PenTool, Download, Trophy, Award, Zap, Heart, AlertCircle, HelpCircle as HelpIcon, Star, Repeat, Hash,
  Move, Smartphone, RotateCw, FlipHorizontal, GripHorizontal, ChevronUp, ChevronDown
} from 'lucide-react';
import { Card, Rectangle, Pin } from '../types';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';
import { TagBadge } from './TagComponents';
import AiTutorModal from './AiTutorModal';
import ScratchpadOverlay from './ScratchpadOverlay';
import SessionSummaryModal from './SessionSummaryModal';
import { 
  speakText, 
  speakWithRepetition,
  stopSpeech, 
  toggleSpeech, 
  isMuted, 
  toggleMute, 
  subscribeMuteState, 
  subscribeSpeechState, 
  playSoundEffect,
  triggerHaptic,
  getSpeechSettings,
  updateSpeechSettings,
  SpeechSettings
} from '../lib/speechUtils';
import { incrementDailyStudyCount } from '../lib/goalUtils';
import { calculateSrs, getEstimatedIntervals, formatIntervalBengali, SrsRating } from '../lib/srsUtils';
import { computeCollisionFreeSideBadges } from '../lib/badgeLayout';
import { saveOrShareJSON } from '../lib/fileSaveUtils';
import FileExportModal from './FileExportModal';
import { openSyncModal } from './SyncButton';
import { 
  getNotchSetting, 
  setNotchSetting, 
  NotchSetting,
  getBottomNavSetting,
  setBottomNavSetting,
  BottomNavSetting
} from '../lib/notchUtils';
import {
  toggleEyeComfort,
  subscribeEyeComfort,
  isEyeComfortActive
} from '../lib/eyeComfortUtils';

interface StudyCardProps {
  cards: Card[];
  initialIndex: number;
  onEdit: (id: number) => void;
  onUpdateCard?: (id: number, updates: Partial<Card>) => void;
  onClose: () => void;
}

export default function StudyCard({ cards, initialIndex, onEdit, onUpdateCard, onClose }: StudyCardProps) {
  const [activeCardsList, setActiveCardsList] = useState<Card[]>(cards);
  const [localNotch, setLocalNotch] = useState<NotchSetting>(() => getNotchSetting());
  const [localBottomNav, setLocalBottomNav] = useState<BottomNavSetting>(() => getBottomNavSetting());
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [revealed, setRevealed] = useState<Set<number>>(new Set());
  const [revealedPins, setRevealedPins] = useState<Set<number>>(new Set());
  const [alertMsg, setAlertMsg] = useState('');
  const [eyeCare, setEyeCare] = useState<boolean>(() => isEyeComfortActive());

  useEffect(() => {
    const unsub = subscribeEyeComfort((_, active) => setEyeCare(active));
    return () => unsub();
  }, []);
  const [showNotes, setShowNotes] = useState(false);
  const [showAiTutor, setShowAiTutor] = useState(false);
  const [showOptionsDrawer, setShowOptionsDrawer] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isNotesSpeaking, setIsNotesSpeaking] = useState(false);
  const [isCurrentlySpeaking, setIsCurrentlySpeaking] = useState(false);
  const [repetitionProgress, setRepetitionProgress] = useState<{ current: number; total: number; text: string } | null>(null);
  const [speechSettings, setSpeechSettings] = useState<SpeechSettings>(() => getSpeechSettings());
  const [isGloballyMuted, setIsGloballyMuted] = useState(isMuted());

  // Smart Study Modes:
  // studyMode: 'click' (reveal on click) | 'type' (typing test) | 'mcq' (multiple choice quiz)
  const [studyMode, setStudyMode] = useState<'click' | 'type' | 'mcq'>('click');
  // occlusionMode: 'hide-all' (Anki Hide All) | 'hide-one' (Anki Hide One)
  const [occlusionMode, setOcclusionMode] = useState<'hide-all' | 'hide-one'>('hide-all');
  const [activeItemIndex, setActiveItemIndex] = useState<number>(0);
  const [badgePosition, setBadgePosition] = useState<'auto' | 'left' | 'inside' | 'right' | 'hidden'>(
    activeCardsList[currentIndex]?.badgePosition || 'auto'
  );
  const [showBadges, setShowBadges] = useState<boolean>(
    activeCardsList[currentIndex]?.showBadges !== undefined 
      ? activeCardsList[currentIndex].showBadges! 
      : false // Default to false (hidden)
  );

  // Fullscreen & Diagram View Optimization states
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showContextLabels, setShowContextLabels] = useState(true);
  // Flip Card to Original Clean Image (Flashcard flip showing unmasked raw diagram)
  const [isFlippedToOriginal, setIsFlippedToOriginal] = useState(false);
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const [canvasDimensions, setCanvasDimensions] = useState<{ width: number; height: number }>({ width: 0, height: 0 });
  const [imgNaturalSize, setImgNaturalSize] = useState<{ width: number; height: number }>({ width: 800, height: 600 });

  // On-Canvas Scratchpad / Pen tool
  const [isPenActive, setIsPenActive] = useState(false);

  // Spaced Repetition (SRS) & Session Analytics
  const sessionStartTimeRef = useRef<number>(Date.now());
  const [sessionDuration, setSessionDuration] = useState(0);
  const [againCardIds, setAgainCardIds] = useState<number[]>([]);
  const [totalRevealedCount, setTotalRevealedCount] = useState(0);
  const [showSessionSummary, setShowSessionSummary] = useState(false);
  const [srsToast, setSrsToast] = useState<{ message: string; rating: SrsRating } | null>(null);

  // MCQ Mode states
  const [selectedMcqOptionId, setSelectedMcqOptionId] = useState<string | null>(null);
  const [mcqFeedback, setMcqFeedback] = useState<{ isCorrect: boolean; correctAnswer: string } | null>(null);

  // Mobile Touch Gestures
  const touchStartPos = useRef<{ x: number; y: number; time: number } | null>(null);
  const [hoveredRectId, setHoveredRectId] = useState<number | null>(null);

  // Type-in answer state
  const [typedAnswer, setTypedAnswer] = useState('');
  const [itemAnswers, setItemAnswers] = useState<Record<number, string>>({});
  const [typeFeedback, setTypeFeedback] = useState<{
    isCorrect: boolean;
    correctAnswer: string;
    message?: string;
    matchedCount?: number;
  } | null>(null);
  const [typeViewMode, setTypeViewMode] = useState<'single' | 'list'>('single');
  const [isToolbarCollapsed, setIsToolbarCollapsed] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('study_toolbar_collapsed');
      if (saved !== null) return saved === 'true';
    }
    return false;
  });
  const [dockKey, setDockKey] = useState(0);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportPayload, setExportPayload] = useState<{ filename: string; data: any; title: string } | null>(null);

  const handleToggleCollapse = (collapsed: boolean) => {
    setIsToolbarCollapsed(collapsed);
    try {
      localStorage.setItem('study_toolbar_collapsed', String(collapsed));
    } catch (e) {}
  };
  const inputRef = useRef<HTMLInputElement>(null);

  const card = activeCardsList[currentIndex];

  const getItemLabel = (type: 'rect' | 'pin', item: Rectangle | Pin, idx: number): string => {
    if (type === 'pin') {
      return (item as Pin).label?.trim() || `পিন ${idx + 1}`;
    }
    const rect = item as Rectangle;
    if (rect.label?.trim()) return rect.label.trim();
    if ((card?.rectangles?.length || 0) === 1 && card?.title) return card.title;
    return `মাস্ক ${idx + 1}`;
  };

  const allItems: { type: 'rect' | 'pin'; item: Rectangle | Pin; id: number; label: string; itemNumber: number }[] = [
    ...(card?.rectangles || []).map((r, idx) => ({
      type: 'rect' as const,
      item: r,
      id: r.id,
      label: getItemLabel('rect', r, idx),
      itemNumber: idx + 1
    })),
    ...(card?.pins || []).map((p, idx) => ({
      type: 'pin' as const,
      item: p,
      id: p.id,
      label: getItemLabel('pin', p, (card?.rectangles?.length || 0) + idx),
      itemNumber: (card?.rectangles?.length || 0) + idx + 1
    }))
  ];

  const activeItem = allItems[activeItemIndex];

  // Computed visibility for badges:
  // Hidden by user preference in click mode, but ALWAYS visible in MCQ/Type modes (as they are required for the quiz).
  const effectiveShowBadges = studyMode === 'click' ? showBadges : true;

  // Computes collision-free side badges and clean leader lines placed strictly in empty space (Netter Atlas Style)
  const computedSideBadges = useMemo(() => {
    if (!effectiveShowBadges || badgePosition === 'hidden' || badgePosition === 'inside' || !card?.rectangles || card.rectangles.length === 0) return [];
    return computeCollisionFreeSideBadges(card.rectangles, badgePosition, {
      activeRectId: allItems[activeItemIndex]?.id,
      occlusionMode,
      studyMode,
      revealedIds: revealed
    });
  }, [card?.rectangles, badgePosition, effectiveShowBadges, occlusionMode, allItems, activeItemIndex, studyMode, revealed]);

  // Dynamic Spaced Repetition estimated intervals for current card
  const srsIntervals = useMemo(() => {
    return getEstimatedIntervals(card?.interval, card?.repetition, card?.easeFactor, card?.lapses);
  }, [card?.interval, card?.repetition, card?.easeFactor, card?.lapses]);

  // Multiple Choice (MCQ) Option Generator: 1 correct + 3 clever distractors
  const mcqOptions = useMemo(() => {
    if (!activeItem || !activeItem.label) return [];
    const correctText = activeItem.label.trim();

    // 1. Gather other labels on the same card
    const otherLabels = allItems
      .filter(i => i.id !== activeItem.id && i.label && i.label.trim() !== correctText)
      .map(i => i.label.trim());

    // 2. Gather labels from other cards in the session
    if (otherLabels.length < 3) {
      cards.forEach(c => {
        c.rectangles?.forEach(r => {
          if (r.label && r.label.trim() && r.label.trim() !== correctText && !otherLabels.includes(r.label.trim())) {
            otherLabels.push(r.label.trim());
          }
        });
        c.pins?.forEach(p => {
          if (p.label && p.label.trim() && p.label.trim() !== correctText && !otherLabels.includes(p.label.trim())) {
            otherLabels.push(p.label.trim());
          }
        });
      });
    }

    // 3. Fallback bank for medical/academic terminology
    const fallbackBank = [
      'Aorta (মহাধমনী)', 'Superior Vena Cava', 'Left Atrium (বাম অলিন্দ)', 
      'Right Ventricle (ডান নিলয়)', 'Femur (উর্বস্থি)', 'Humerus (প্রগণ্ডাস্থি)', 
      'Cerebrum (গুরুমস্তিষ্ক)', 'Cerebellum (লঘুমস্তিষ্ক)', 'Medulla Oblongata',
      'Renal Cortex (বৃক্কীয় কর্টেক্স)', 'Nephron (নেফ্রন)', 'Pulmonary Artery'
    ];
    for (const term of fallbackBank) {
      if (otherLabels.length >= 3) break;
      if (term !== correctText && !otherLabels.includes(term)) {
        otherLabels.push(term);
      }
    }

    // Pick 3 distractors
    const chosenDistractors = [...otherLabels]
      .sort(() => 0.5 - Math.random())
      .slice(0, 3);

    const raw = [
      { id: 'opt-correct', text: correctText, isCorrect: true },
      ...chosenDistractors.map((text, idx) => ({ id: `opt-distractor-${idx}`, text, isCorrect: false }))
    ];

    // Seeded shuffle for stable layout while on this item
    return raw.sort(() => 0.5 - Math.random());
  }, [activeItem?.id, activeItem?.label, card?.id, cards]);

  // Handle selecting an option in MCQ mode
  const handleSelectMcqOption = (option: { id: string; text: string; isCorrect: boolean }) => {
    if (selectedMcqOptionId !== null || !activeItem) return;
    setSelectedMcqOptionId(option.id);

    if (option.isCorrect) {
      playSoundEffect('correct');
      setMcqFeedback({ isCorrect: true, correctAnswer: option.text });
      if (activeItem.type === 'pin') {
        setRevealedPins(prev => new Set(prev).add(activeItem.id));
      } else {
        setRevealed(prev => new Set(prev).add(activeItem.id));
      }
      setTotalRevealedCount(prev => prev + 1);
    } else {
      playSoundEffect('incorrect');
      setMcqFeedback({ isCorrect: false, correctAnswer: activeItem.label });
      if (!againCardIds.includes(card.id)) {
        setAgainCardIds(prev => [...prev, card.id]);
      }
      if (activeItem.type === 'pin') {
        setRevealedPins(prev => new Set(prev).add(activeItem.id));
      } else {
        setRevealed(prev => new Set(prev).add(activeItem.id));
      }
      setTotalRevealedCount(prev => prev + 1);
    }
  };

  // Handle Spaced Repetition (SRS) rating (Again, Hard, Good, Easy)
  const handleSrsRate = (rating: SrsRating) => {
    if (!card) return;
    const result = calculateSrs(
      rating,
      card.interval || 0,
      card.repetition || 0,
      card.easeFactor || 2.5,
      card.lapses || 0
    );

    if (rating === 'again') {
      triggerHaptic('warning');
      playSoundEffect('incorrect');
      if (!againCardIds.includes(card.id)) {
        setAgainCardIds(prev => [...prev, card.id]);
      }
      setSrsToast({
        message: `আবার চিহ্নিত! পরবর্তী রিভিশন: ${formatIntervalBengali(result.interval)}`,
        rating: 'again'
      });
    } else {
      triggerHaptic('success');
      playSoundEffect('correct');
      setSrsToast({
        message: `সফল! পরবর্তী রিভিশন: ${formatIntervalBengali(result.interval)}`,
        rating
      });
    }

    onUpdateCard?.(card.id, {
      interval: result.interval,
      repetition: result.repetition,
      easeFactor: result.easeFactor,
      nextReview: result.nextReview,
      lastReviewed: result.lastReviewed,
      lapses: result.lapses,
    });

    setTimeout(() => setSrsToast(null), 2000);

    // If in hide-one mode: go to next item or next card
    if (occlusionMode === 'hide-one') {
      if (activeItemIndex < allItems.length - 1) {
        setActiveItemIndex(prev => prev + 1);
        setSelectedMcqOptionId(null);
        setMcqFeedback(null);
      } else {
        handleNext();
      }
    } else {
      handleNext();
    }
  };

  // Mobile Touch Gestures for Swiping
  const handleTouchStart = (e: React.TouchEvent) => {
    if (isPenActive) return;
    const touch = e.touches[0];
    touchStartPos.current = {
      x: touch.clientX,
      y: touch.clientY,
      time: Date.now()
    };
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (isPenActive || !touchStartPos.current) return;
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - touchStartPos.current.x;
    const deltaY = touch.clientY - touchStartPos.current.y;
    const elapsed = Date.now() - touchStartPos.current.time;

    // Detect horizontal swipe
    if (Math.abs(deltaX) > 50 && Math.abs(deltaX) > Math.abs(deltaY) * 1.3 && elapsed < 600) {
      if (deltaX < 0) {
        // Swiped Left -> Next
        if (occlusionMode === 'hide-one' && activeItemIndex < allItems.length - 1) {
          setActiveItemIndex(prev => prev + 1);
          setSelectedMcqOptionId(null);
          setMcqFeedback(null);
        } else {
          handleNext();
        }
      } else {
        // Swiped Right -> Previous
        if (occlusionMode === 'hide-one' && activeItemIndex > 0) {
          setActiveItemIndex(prev => prev - 1);
          setSelectedMcqOptionId(null);
          setMcqFeedback(null);
        } else if (currentIndex > 0) {
          setCurrentIndex(prev => prev - 1);
          setSelectedMcqOptionId(null);
          setMcqFeedback(null);
        }
      }
    }
    touchStartPos.current = null;
  };

  // Track canvas dimensions with ResizeObserver so image fits with mathematical precision
  useEffect(() => {
    if (!canvasContainerRef.current) return;
    const updateSize = () => {
      if (canvasContainerRef.current) {
        setCanvasDimensions({
          width: canvasContainerRef.current.clientWidth,
          height: canvasContainerRef.current.clientHeight,
        });
      }
    };
    updateSize();
    const observer = new ResizeObserver(updateSize);
    observer.observe(canvasContainerRef.current);
    return () => observer.disconnect();
  }, [isFullscreen, studyMode, occlusionMode, showNotes]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger shortcuts when user is typing in an input box
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return;
      }

      // Exit fullscreen on Escape
      if (e.key === 'Escape' && isFullscreen) {
        setIsFullscreen(false);
        return;
      }

      // Edit Card on 'e'
      if (e.key.toLowerCase() === 'e' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        onEdit(card.id);
        return;
      }

      // Flip card to Original Clean Image on 'o' (or Space/Enter if already flipped)
      if (e.key.toLowerCase() === 'o' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        toggleFlipOriginal();
        return;
      }

      // If currently on original clean image, pressing Space flips back to study mode
      if (isFlippedToOriginal && (e.key === ' ' || e.key === 'Enter')) {
        e.preventDefault();
        toggleFlipOriginal();
        return;
      }

      // Toggle fullscreen on 'f'
      if (e.key.toLowerCase() === 'f' && !e.ctrlKey && !e.metaKey) {
        setIsFullscreen(prev => !prev);
        return;
      }

      // Toggle Marker Pen on 'p'
      if (e.key.toLowerCase() === 'p' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setIsPenActive(prev => !prev);
        return;
      }

      // Toggle Badges & Leader Lines on 'b' or 'h'
      if ((e.key.toLowerCase() === 'b' || e.key.toLowerCase() === 'h') && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        if (studyMode === 'click') {
          setShowBadges(prev => {
            const next = !prev;
            if (onUpdateCard && card) {
              onUpdateCard(card.id, { showBadges: next });
            }
            return next;
          });
        }
        return;
      }

      // Spaced Repetition Rating Shortcuts: 1, 2, 3, 4
      if (e.key === '1') {
        e.preventDefault();
        handleSrsRate('again');
        return;
      }
      if (e.key === '2') {
        e.preventDefault();
        handleSrsRate('hard');
        return;
      }
      if (e.key === '3') {
        e.preventDefault();
        handleSrsRate('good');
        return;
      }
      if (e.key === '4') {
        e.preventDefault();
        handleSrsRate('easy');
        return;
      }

      if (studyMode === 'mcq') {
        // MCQ selection via keys A, B, C, D
        const key = e.key.toLowerCase();
        const mapKeys: Record<string, number> = { a: 0, b: 1, c: 2, d: 3 };
        if (mapKeys[key] !== undefined && mcqOptions[mapKeys[key]]) {
          e.preventDefault();
          handleSelectMcqOption(mcqOptions[mapKeys[key]]);
          return;
        }
      }

      if (occlusionMode === 'hide-one') {
        const curItem = allItems[activeItemIndex];
        const isDone = curItem ? (curItem.type === 'pin' ? revealedPins.has(curItem.id) : revealed.has(curItem.id)) : false;

        if (e.key === ' ' || e.key === 'Enter') {
          e.preventDefault();
          if (!curItem) return;

          if (!isDone) {
            // Reveal current item
            if (curItem.type === 'pin') {
              setRevealedPins(prev => new Set(prev).add(curItem.id));
            } else {
              setRevealed(prev => new Set(prev).add(curItem.id));
            }
            setTotalRevealedCount(prev => prev + 1);
            if (curItem.label && !isGloballyMuted) {
              speakText(curItem.label);
            }
          } else {
            // Advance to next item
            if (activeItemIndex < allItems.length - 1) {
              setActiveItemIndex(prev => prev + 1);
              setSelectedMcqOptionId(null);
              setMcqFeedback(null);
            } else {
              handleNext();
            }
          }
        } else if (e.key === 'ArrowRight') {
          e.preventDefault();
          if (activeItemIndex < allItems.length - 1) {
            setActiveItemIndex(prev => prev + 1);
            setSelectedMcqOptionId(null);
            setMcqFeedback(null);
          } else {
            handleNext();
          }
        } else if (e.key === 'ArrowLeft') {
          e.preventDefault();
          if (activeItemIndex > 0) {
            setActiveItemIndex(prev => prev - 1);
            setSelectedMcqOptionId(null);
            setMcqFeedback(null);
          }
        } else if (e.key.toLowerCase() === 'r') {
          if (curItem?.label) {
            speakText(curItem.label);
          } else {
            handlePronounce();
          }
        }
      } else {
        if (e.key === 'ArrowRight') {
          handleNext();
        } else if (e.key === ' ') {
          e.preventDefault();
          toggleRevealAll();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  // Subscribe to audio mute and speaking states
  useEffect(() => {
    const unsubMute = subscribeMuteState(muted => setIsGloballyMuted(muted));
    const unsubSpeech = subscribeSpeechState((speaking, progress) => {
      setIsCurrentlySpeaking(speaking);
      setRepetitionProgress(progress || null);
      if (!speaking) {
        setIsSpeaking(false);
        setIsNotesSpeaking(false);
      }
    });
    return () => {
      unsubMute();
      unsubSpeech();
      stopSpeech();
    };
  }, []);

  // Reset states and stop any lingering audio when switching cards
  useEffect(() => {
    stopSpeech();
    setIsSpeaking(false);
    setIsNotesSpeaking(false);
    setRepetitionProgress(null);
    setRevealed(new Set());
    setRevealedPins(new Set());
    setActiveItemIndex(0);
    setTypedAnswer('');
    setItemAnswers({});
    setTypeFeedback(null);
    setShowNotes(false);
    setIsFlippedToOriginal(false);
    setBadgePosition(card?.badgePosition || 'auto');
    setShowBadges(card?.showBadges !== undefined ? card.showBadges : false); // Default to false
  }, [currentIndex, card?.badgePosition, card?.showBadges]);

  const toggleFlipOriginal = () => {
    setIsFlippedToOriginal(prev => {
      const next = !prev;
      triggerHaptic('light');
      return next;
    });
  };

  const handleStopAllAudio = () => {
    stopSpeech();
    setIsSpeaking(false);
    setIsNotesSpeaking(false);
    setRepetitionProgress(null);
  };

  const handleToggleMute = () => {
    const nextMuted = toggleMute();
    setIsGloballyMuted(nextMuted);
    if (nextMuted) {
      handleStopAllAudio();
    }
  };

  const toggleMask = (rectId: number) => {
    triggerHaptic('light');
    setRevealed(prev => {
      const next = new Set(prev);
      if (next.has(rectId)) {
        next.delete(rectId);
      } else {
        next.add(rectId);
        const rect = card?.rectangles?.find(r => r.id === rectId);
        if (rect?.label && !isGloballyMuted) {
          const settings = getSpeechSettings();
          if (settings.autoPronounceOnReveal) {
            speakWithRepetition(rect.label, { count: settings.repeatCount });
          }
        }
      }
      return next;
    });
  };

  const togglePin = (pin: Pin) => {
    triggerHaptic('light');
    setRevealedPins(prev => {
      const next = new Set(prev);
      if (next.has(pin.id)) {
        next.delete(pin.id);
      } else {
        next.add(pin.id);
        if (pin.label && !isGloballyMuted) {
          const settings = getSpeechSettings();
          if (settings.autoPronounceOnReveal) {
            speakWithRepetition(pin.label, { count: settings.repeatCount });
          } else {
            speakText(pin.label);
          }
        }
      }
      return next;
    });
  };

  const toggleRevealAll = () => {
    const totalItems = (card?.rectangles?.length || 0) + (card?.pins?.length || 0);
    if (revealed.size + revealedPins.size === totalItems) {
      setRevealed(new Set());
      setRevealedPins(new Set());
      setShowNotes(false);
    } else {
      setRevealed(new Set(card?.rectangles?.map(r => r.id) || []));
      setRevealedPins(new Set(card?.pins?.map(p => p.id) || []));
    }
  };

  const handleNext = () => {
    handleStopAllAudio();
    incrementDailyStudyCount(1);
    if (currentIndex < activeCardsList.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedMcqOptionId(null);
      setMcqFeedback(null);
    } else {
      const duration = Math.max(1, Math.round((Date.now() - sessionStartTimeRef.current) / 1000));
      setSessionDuration(duration);
      playSoundEffect('complete');
      setShowSessionSummary(true);
    }
  };

  const handlePrev = () => {
    handleStopAllAudio();
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setSelectedMcqOptionId(null);
      setMcqFeedback(null);
    }
  };

  const handleReviewWeakSpots = (weakCards: Card[]) => {
    setShowSessionSummary(false);
    setActiveCardsList(weakCards);
    setCurrentIndex(0);
    setRevealed(new Set());
    setRevealedPins(new Set());
    setActiveItemIndex(0);
    setAgainCardIds([]);
    setSelectedMcqOptionId(null);
    setMcqFeedback(null);
    sessionStartTimeRef.current = Date.now();
  };

  const handleRestartAll = () => {
    setShowSessionSummary(false);
    setActiveCardsList(cards);
    setCurrentIndex(0);
    setRevealed(new Set());
    setRevealedPins(new Set());
    setActiveItemIndex(0);
    setAgainCardIds([]);
    setSelectedMcqOptionId(null);
    setMcqFeedback(null);
    sessionStartTimeRef.current = Date.now();
  };

  const handleExportCurrentDeck = () => {
    const exportData = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      cardsCount: activeCardsList.length,
      cards: activeCardsList
    };
    const filename = `medical_deck_backup_${activeCardsList.length}_cards_${new Date().toISOString().slice(0, 10)}.json`;
    setExportPayload({
      filename,
      data: exportData,
      title: 'মেমোরি কার্ড ডেক ব্যাকআপ'
    });
    setShowExportModal(true);
  };

  const handlePronounce = () => {
    if (!card) return;
    if (isSpeaking || isCurrentlySpeaking) {
      handleStopAllAudio();
      return;
    }
    setIsSpeaking(true);
    speakText(card.title, () => setIsSpeaking(false));
  };

  const handleToggleNotesSpeech = () => {
    if (isNotesSpeaking) {
      handleStopAllAudio();
    } else {
      setIsNotesSpeaking(true);
      speakText(card.notes || '', () => setIsNotesSpeaking(false));
    }
  };

  // Clean string for linguistic comparison
  const cleanText = (str: string): string => {
    return (str || '')
      .toLowerCase()
      .replace(/[\u200B-\u200D\uFEFF]/g, '')
      .replace(/[.,/#!$%^&*;:{}=\-_`~()?"'<>।–—\\+[\]]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  };

  // Levenshtein distance for fuzzy matching
  const levenshtein = (a: string, b: string): number => {
    const matrix: number[][] = [];
    for (let i = 0; i <= b.length; i++) matrix[i] = [i];
    for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= b.length; i++) {
      for (let j = 1; j <= a.length; j++) {
        if (b.charAt(i - 1) === a.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }
    return matrix[b.length][a.length];
  };

  // Smart single match function
  const checkSingleMatch = (inputCandidate: string, targetLabel: string): boolean => {
    const cIn = cleanText(inputCandidate);
    const cTarget = cleanText(targetLabel);
    if (!cIn || !cTarget) return false;
    if (cIn === cTarget) return true;

    // Check target alternative names, e.g. "Left Ventricle / বাম নিলয়" or "Femur (থাই বোন)"
    const targetTokens = targetLabel
      .split(/[/,;()।|]|(?:\s+or\s+)|\s+বা\s+|\s+এবং\s+/i)
      .map(t => cleanText(t))
      .filter(t => t.length > 0);

    for (const token of targetTokens) {
      if (token === cIn) return true;
      if (cIn.includes(token) && token.length >= 3) return true;
      if (token.includes(cIn) && cIn.length >= token.length * 0.7) return true;

      if (cIn.length >= 4 && token.length >= 4) {
        const dist = levenshtein(cIn, token);
        if (dist <= 1) return true;
        if (cIn.length >= 7 && dist <= 2) return true;
      }
    }

    // Direct substring checks
    if (cIn.includes(cTarget) && cTarget.length >= 3) return true;
    if (cTarget.includes(cIn) && cIn.length >= cTarget.length * 0.7) return true;

    return false;
  };

  // Handle checking answers - supports single or multiple answers in one go
  const handleCheckTypedAnswer = (e?: React.FormEvent, overrideItemId?: number) => {
    if (e) e.preventDefault();

    const targetItemIndex = overrideItemId !== undefined
      ? allItems.findIndex(i => i.id === overrideItemId)
      : activeItemIndex;

    const activeItem = allItems[targetItemIndex] || allItems[activeItemIndex];
    if (!activeItem) return;

    const answerToCheck = (overrideItemId !== undefined
      ? itemAnswers[overrideItemId]
      : typedAnswer) || '';

    if (!answerToCheck.trim()) return;

    const rawInput = answerToCheck.trim();
    // Split input into chunks if user entered multiple answers (separated by comma, semicolon, newline, "এবং", "ও", "and", "+")
    const inputChunks = rawInput
      .split(/[,;\n\t|+]|(?:\s+এবং\s+)|\s+and\s+|\s+ও\s+/i)
      .map(s => s.replace(/^\s*[\d১-৯]+[.)-]\s*/, '').trim())
      .filter(Boolean);

    if (inputChunks.length === 0) inputChunks.push(rawInput);

    // 1. Check if active item matches
    let activeMatched = false;
    for (const chunk of inputChunks) {
      if (checkSingleMatch(chunk, activeItem.label)) {
        activeMatched = true;
        break;
      }
    }
    if (!activeMatched && checkSingleMatch(rawInput, activeItem.label)) {
      activeMatched = true;
    }

    // 2. Multi-Item Bonus: Check if input chunks match OTHER unrevealed items on this card!
    const otherMatchedItems: typeof allItems = [];
    for (let i = 0; i < allItems.length; i++) {
      if (i === targetItemIndex) continue;
      const other = allItems[i];
      const isAlreadyDone = (other.type === 'pin' ? revealedPins.has(other.id) : revealed.has(other.id));
      if (isAlreadyDone) continue;

      for (const chunk of inputChunks) {
        if (checkSingleMatch(chunk, other.label)) {
          otherMatchedItems.push(other);
          break;
        }
      }
    }

    if (activeMatched) {
      // Active item is correct!
      if (activeItem.type === 'pin') {
        setRevealedPins(prev => new Set(prev).add(activeItem.id));
      } else {
        setRevealed(prev => new Set(prev).add(activeItem.id));
      }

      // Also reveal any other matched items (if user typed answers for multiple items at once)
      if (otherMatchedItems.length > 0) {
        otherMatchedItems.forEach(m => {
          if (m.type === 'pin') {
            setRevealedPins(prev => new Set(prev).add(m.id));
          } else {
            setRevealed(prev => new Set(prev).add(m.id));
          }
        });
      }

      const allSolvedNames = [activeItem.label, ...otherMatchedItems.map(m => m.label)];
      const msg = otherMatchedItems.length > 0
        ? `অসাধারণ! আপনি ${allSolvedNames.length} টি আইটেম একসাথে সঠিক লিখেছেন: "${allSolvedNames.join('", "')}"!`
        : `অসাধারণ! #${activeItem.itemNumber} নম্বর উত্তরটি সঠিক হয়েছে!`;

      setTypeFeedback({
        isCorrect: true,
        correctAnswer: activeItem.label,
        message: msg,
        matchedCount: 1 + otherMatchedItems.length
      });

      playSoundEffect('correct');
      if (!isGloballyMuted) {
        speakText(activeItem.label);
      }

      // Save answer
      setItemAnswers(prev => ({ ...prev, [activeItem.id]: rawInput }));

      // Find next unrevealed item
      const nextUnrevealedIdx = allItems.findIndex((item, idx) => {
        if (idx === targetItemIndex) return false;
        if (otherMatchedItems.some(m => m.id === item.id)) return false;
        const isDone = item.type === 'pin' ? revealedPins.has(item.id) : revealed.has(item.id);
        return !isDone;
      });

      if (nextUnrevealedIdx !== -1) {
        // Automatically smoothly advance after 1.2 seconds if not manually clicked
        setTimeout(() => {
          setActiveItemIndex(nextUnrevealedIdx);
          setTypedAnswer(itemAnswers[allItems[nextUnrevealedIdx]?.id] || '');
          setTypeFeedback(null);
          inputRef.current?.focus();
        }, 1300);
      }
    } else if (otherMatchedItems.length > 0) {
      // User typed an answer that belongs to another item on this card!
      otherMatchedItems.forEach(m => {
        if (m.type === 'pin') {
          setRevealedPins(prev => new Set(prev).add(m.id));
        } else {
          setRevealed(prev => new Set(prev).add(m.id));
        }
      });

      playSoundEffect('correct');
      const matchedNames = otherMatchedItems.map(m => `#${m.itemNumber} (${m.label})`).join(', ');
      setTypeFeedback({
        isCorrect: true,
        correctAnswer: activeItem.label,
        message: `দারুণ! আপনি ${matchedNames} সঠিক লিখেছেন! এখন বর্তমান আইটেম #${activeItem.itemNumber} এর নাম লিখুন।`,
        matchedCount: otherMatchedItems.length
      });
      if (!isGloballyMuted) {
        speakText(otherMatchedItems[0].label);
      }
    } else {
      // Incorrect
      playSoundEffect('incorrect');
      setTypeFeedback({
        isCorrect: false,
        correctAnswer: activeItem.label,
        message: `ভুল হয়েছে! সঠিক উত্তর: "${activeItem.label}"`
      });
    }
  };

  // Switch to an item by index
  const selectActiveItem = (idx: number) => {
    if (idx < 0 || idx >= allItems.length) return;
    const item = allItems[idx];
    setActiveItemIndex(idx);
    setTypedAnswer(itemAnswers[item.id] || '');
    setTypeFeedback(null);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  // Reveal active item
  const handleRevealCurrentItem = () => {
    const activeItem = allItems[activeItemIndex];
    if (!activeItem) return;
    if (activeItem.type === 'pin') {
      setRevealedPins(prev => new Set(prev).add(activeItem.id));
    } else {
      setRevealed(prev => new Set(prev).add(activeItem.id));
    }
    setTypeFeedback({
      isCorrect: false,
      correctAnswer: activeItem.label,
      message: `প্রকাশ করা হলো: "${activeItem.label}"`
    });
    speakText(activeItem.label);
  };

  // Handle canvas item click
  const handleItemClick = (type: 'rect' | 'pin', id: number, itemObj: Rectangle | Pin) => {
    if (studyMode === 'type') {
      // In Type Mode: Select this item for active recall typing!
      const idx = allItems.findIndex(i => i.id === id);
      if (idx !== -1) {
        selectActiveItem(idx);
      }
    } else if (occlusionMode === 'hide-one') {
      // In Hide-One Mode (একটি আড়াল - প্রেক্ষাপট)
      const idx = allItems.findIndex(i => i.id === id);
      if (idx !== -1) {
        if (idx !== activeItemIndex) {
          // Clicking a different item switches the hidden target to that item
          setActiveItemIndex(idx);
        } else {
          // Clicking the current hidden item reveals/hides it
          if (type === 'rect') toggleMask(id);
          else togglePin(itemObj as Pin);
        }
      }
    } else {
      // In Click Mode (সব আড়াল): toggle reveal
      if (type === 'rect') toggleMask(id);
      else togglePin(itemObj as Pin);
    }
  };

  const nextActiveItem = () => {
    const nextIdx = (activeItemIndex + 1) % (allItems.length || 1);
    selectActiveItem(nextIdx);
  };

  if (!card) return null;

  const isLast = currentIndex === cards.length - 1;
  const totalItems = (card.rectangles?.length || 0) + (card.pins?.length || 0);
  const allRevealed = (revealed.size + revealedPins.size) === totalItems;

  return (
    <div className="flex flex-col h-full bg-slate-900 select-none">
      {/* Non-blocking Toast Feedback (No popup modal or interrupting buttons) */}
      {alertMsg && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 pointer-events-none animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="bg-slate-900/95 border border-slate-700/90 text-white px-4 py-2 rounded-full shadow-2xl backdrop-blur-md flex items-center gap-2 text-xs font-semibold">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{alertMsg}</span>
          </div>
        </div>
      )}

      {/* AI Tutor Modal */}
      <AiTutorModal
        card={card}
        isOpen={showAiTutor}
        onClose={() => setShowAiTutor(false)}
      />

      {/* Speech Repetition Floating Active Indicator */}
      {isCurrentlySpeaking && repetitionProgress && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-40 bg-slate-900/95 backdrop-blur-md border border-purple-500/60 shadow-2xl rounded-full px-4 py-2 flex items-center gap-2.5 text-xs text-white animate-in fade-in slide-in-from-top-2 duration-200">
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-purple-500"></span>
          </span>
          <span className="font-semibold text-purple-300 whitespace-nowrap">
            উচ্চারণ অনুশীলন: {repetitionProgress.current}/{repetitionProgress.total}
          </span>
          <span className="text-slate-300 font-medium truncate max-w-[120px] sm:max-w-xs">
            "{repetitionProgress.text}"
          </span>
          <button
            type="button"
            onClick={handleStopAllAudio}
            className="p-1 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="শব্দ বন্ধ করুন"
          >
            <Square className="w-3 h-3 fill-current" />
          </button>
        </div>
      )}

      {/* Sleek Master Header with safe-top-header for mobile status bar / notch clearing */}
      {/* Sleek, Unscattered Master Header */}
      <header className="safe-top-header bg-slate-900/95 backdrop-blur-md text-white px-3 sm:px-4 pb-2.5 pt-1.5 flex items-center justify-between gap-2 shadow-md shrink-0 border-b border-slate-800 z-20">
        {/* Left: Home, Card Counter, Favorite & Card Title */}
        <div className="flex items-center gap-2 min-w-0">
          <button
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white rounded-xl hover:bg-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer text-xs sm:text-sm font-semibold shrink-0"
            title="ড্যাশবোর্ডে ফিরে যান"
          >
            <Home className="w-4 h-4" /> <span className="hidden sm:inline">ড্যাশবোর্ড</span>
          </button>
          
          <div className="flex items-center gap-1.5 bg-slate-950/80 border border-slate-800 px-2 py-0.5 rounded-lg shrink-0">
            <span className="text-xs font-mono font-bold text-slate-300">#{currentIndex + 1}/{cards.length}</span>
            <button 
              onClick={() => {
                if (onUpdateCard) {
                  const newFav = !card.favorite;
                  onUpdateCard(card.id, { favorite: newFav });
                  setAlertMsg(newFav ? 'কার্ডটি প্রিয় তালিকায় যুক্ত করা হয়েছে ⭐' : 'প্রিয় তালিকা থেকে সরানো হয়েছে');
                  setTimeout(() => setAlertMsg(''), 2000);
                }
              }}
              className="text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
              title={card.favorite ? 'প্রিয় থেকে সরান' : 'প্রিয় কার্ড চিহ্নিত করুন'}
            >
              <Star className={`w-3.5 h-3.5 ${card.favorite ? 'fill-amber-400 text-amber-400' : ''}`} />
            </button>
          </div>

          <h2 className="text-xs sm:text-sm font-bold text-slate-200 truncate max-w-[130px] sm:max-w-xs md:max-w-sm" title={card.title}>
            {card.title}
          </h2>
        </div>

        {/* Right Tools: Edit, AI Tutor, Options Drawer & Next Card */}
        <div className="flex items-center gap-1.5 shrink-0">
          {isCurrentlySpeaking && (
            <button
              onClick={handleStopAllAudio}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-md animate-pulse cursor-pointer"
              title="শব্দ এখনই থামান"
            >
              <Square className="w-3 h-3 fill-current" />
              <span className="hidden xs:inline">থামান</span>
            </button>
          )}

          {/* Edit Button */}
          <button 
            onClick={() => onEdit(card.id)}
            className="flex items-center gap-1 px-2.5 py-1 bg-indigo-600/25 hover:bg-indigo-600/40 border border-indigo-500/40 text-indigo-200 hover:text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95"
            title="এই কার্ডটি এডিট করুন (E)"
          >
            <Edit3 className="w-3.5 h-3.5 text-indigo-300" />
            <span className="hidden xs:inline">এডিট</span>
          </button>

          {/* AI Tutor Button */}
          <button
            onClick={() => setShowAiTutor(true)}
            className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-purple-900/30 border border-purple-500/40 hover:bg-purple-800/40 text-purple-200 hover:text-white transition-colors cursor-pointer"
            title="AI টিউটর দিয়ে ছবিটি সহজ বাংলায় বুঝুন"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>AI টিউটর</span>
          </button>

          {/* Eye Comfort Shield Toggle Button */}
          <button
            type="button"
            onClick={() => {
              const next = toggleEyeComfort();
              setEyeCare(next);
              setAlertMsg(next ? 'চোখের সুরক্ষা আলো সক্রিয় 🛡️' : 'চোখের সুরক্ষা আলো বন্ধ');
            }}
            className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              eyeCare
                ? 'bg-amber-400 text-slate-950 font-bold border-amber-300 shadow-sm'
                : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border-slate-700 hover:text-white'
            }`}
            title={eyeCare ? "চোখের সুরক্ষা আলো সক্রিয় আছে (Eye Comfort ON)" : "চোখের সুরক্ষা আলো চালু করুন (Eye Comfort Shield)"}
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">আই-শিল্ড</span>
          </button>

          {/* Master "অপশন" Button */}
          <button
            type="button"
            onClick={() => setShowOptionsDrawer(true)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showOptionsDrawer
                ? 'bg-amber-400 text-slate-950 border-amber-300'
                : 'bg-slate-800 hover:bg-slate-750 text-amber-300 border-amber-500/40 hover:border-amber-400'
            }`}
            title="স্টাডি অপশন, নোট ও সেটিংস"
          >
            <Settings className="w-3.5 h-3.5 text-amber-400" />
            <span>অপশন</span>
            {card.notes && (
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" title="স্টাডি নোট উপলব্ধ" />
            )}
          </button>

          {/* Next Card Quick Button */}
          <button
            type="button"
            onClick={handleNext}
            className={`flex items-center gap-1 text-white px-2.5 py-1 rounded-lg text-xs font-bold shadow-md cursor-pointer transition-transform active:scale-95 ${
              isLast ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-blue-600 hover:bg-blue-500'
            }`}
            title="পরবর্তী কার্ডে যান"
          >
            <span className="hidden xs:inline">{isLast ? 'সমাপ্ত' : 'পরবর্তী'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Main Study Arena - Dedicated to Maximizing the Image */}
      <main className="flex-1 w-full h-full min-h-0 relative flex flex-col items-center justify-center overflow-hidden bg-slate-950 p-1 sm:p-2">
        {/* Interactive Diagram Canvas Container */}
        <div 
          ref={canvasContainerRef}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          className={
            isFullscreen 
              ? "fixed inset-0 z-50 bg-slate-950/98 p-2 sm:p-3 flex flex-col justify-between" 
              : "flex-1 w-full h-full min-h-0 relative flex items-center justify-center overflow-hidden bg-slate-950/70 rounded-2xl border border-slate-700/80 shadow-inner"
          }
        >
          <TransformWrapper initialScale={1} minScale={0.5} maxScale={4} centerOnInit>
            {({ zoomIn, zoomOut, resetTransform }) => (
              <>
                <TransformComponent 
                  wrapperStyle={{ width: '100%', height: '100%', overflow: 'hidden' }}
                  contentStyle={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                >
                  <motion.div 
                    key={isFlippedToOriginal ? 'original-clean-view' : 'occlusion-study-view'}
                    initial={{ rotateY: isFlippedToOriginal ? 90 : -90, opacity: 0.8 }}
                    animate={{ rotateY: 0, opacity: 1 }}
                    transition={{ duration: 0.35, ease: "easeOut" }}
                    style={{ transformStyle: 'preserve-3d' }}
                    onClick={() => {
                      if (!isPenActive) {
                        toggleFlipOriginal();
                      }
                    }}
                    className="relative inline-block bg-white rounded-lg shadow-2xl m-auto select-none cursor-pointer"
                  >
                    <img
                      src={card.image}
                      alt={card.title}
                      onLoad={(e) => setImgNaturalSize({
                        width: e.currentTarget.naturalWidth || 800,
                        height: e.currentTarget.naturalHeight || 600
                      })}
                      className="block rounded-lg select-none mx-auto"
                      draggable={false}
                      style={{
                        maxHeight: isFullscreen 
                          ? 'calc(100vh - 120px)' 
                          : `${canvasDimensions.height > 140 ? canvasDimensions.height - 96 : 800}px`,
                        maxWidth: isFullscreen 
                          ? 'calc(100vw - 24px)' 
                          : `${canvasDimensions.width > 60 ? canvasDimensions.width - 16 : 1200}px`,
                        width: 'auto',
                        height: 'auto',
                        objectFit: 'contain',
                        filter: eyeCare ? 'brightness(0.85) sepia(0.18) contrast(1.05)' : 'none',
                        transition: 'filter 0.3s'
                      }}
                    />

                    {isFlippedToOriginal ? (
                      /* Clean Original Image: 100% pure and unobstructed. No badges, no text, no options over the image. Tapping on the image directly flips back! */
                      <div
                        className="absolute inset-0 rounded-lg pointer-events-auto"
                        title="ছবিতে ট্যাপ করে স্টাডি মোডে ফিরুন"
                      />
                    ) : (
                      <>
                        {/* Canvas Scratchpad Overlay for Anatomical Annotations */}
                        <ScratchpadOverlay
                          isActive={isPenActive}
                          onToggleActive={setIsPenActive}
                          width={imgNaturalSize.width}
                          height={imgNaturalSize.height}
                        />
                    
                    {/* Occlusion Rectangles */}
                    {card.rectangles?.map((rect, idx) => {
                      const isRevealed = revealed.has(rect.id);
                      const isTargetInHideOne = occlusionMode === 'hide-one' && allItems[activeItemIndex]?.id === rect.id;
                      const isTargetInTypeMode = studyMode === 'type' && allItems[activeItemIndex]?.id === rect.id;

                      let boxStyle = 'bg-blue-600 border-blue-800 text-white shadow-md';
                      if (studyMode === 'type') {
                        if (isRevealed) {
                          boxStyle = 'bg-emerald-600/30 border-emerald-400 text-emerald-200 shadow-[0_0_15px_rgba(16,185,129,0.5)]';
                        } else if (isTargetInTypeMode) {
                          boxStyle = 'bg-indigo-600/70 border-amber-400 ring-4 ring-amber-400/80 shadow-[0_0_20px_rgba(251,191,36,0.8)] text-white animate-pulse';
                        } else {
                          boxStyle = 'bg-slate-800/85 border-slate-600 text-slate-300 hover:border-slate-400';
                        }
                      } else if (occlusionMode === 'hide-one') {
                        if (isTargetInHideOne) {
                          if (isRevealed) {
                            boxStyle = 'bg-emerald-500/20 border-2 border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.4)] rounded-lg cursor-pointer flex items-center justify-center';
                          } else {
                            boxStyle = 'bg-amber-500 hover:bg-amber-400 text-slate-950 border-2 border-amber-200 ring-4 ring-amber-400/60 shadow-xl rounded-lg cursor-pointer transform hover:scale-[1.01] active:scale-95 transition-all flex items-center justify-center';
                          }
                        } else {
                          // All other items: if showContextLabels is true, show subtle golden accent; otherwise clean transparent
                          boxStyle = showContextLabels
                            ? 'bg-amber-400/5 border border-amber-400/25 hover:border-amber-400/70 hover:bg-amber-400/10 rounded-lg cursor-pointer transition-colors'
                            : 'bg-transparent border border-transparent hover:border-amber-400/40 hover:bg-amber-400/5 rounded-lg cursor-pointer transition-colors';
                        }
                      } else {
                        if (isRevealed) {
                          boxStyle = 'bg-transparent border-green-500/90 shadow-[0_0_15px_rgba(34,197,94,0.4)]';
                        }
                      }

                      return (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ type: 'spring', stiffness: 260, damping: 20, delay: idx * 0.02 }}
                          key={rect.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleItemClick('rect', rect.id, rect);
                          }}
                          className={`absolute border-2 cursor-pointer transition-all duration-200 flex items-center justify-center font-bold text-xl select-none ${boxStyle}`}
                          style={{
                            left: rect.xPercent !== undefined ? `${rect.xPercent}%` : `${rect.x}px`,
                            top: rect.yPercent !== undefined ? `${rect.yPercent}%` : `${rect.y}px`,
                            width: rect.widthPercent !== undefined ? `${rect.widthPercent}%` : `${rect.width}px`,
                            height: rect.heightPercent !== undefined ? `${rect.heightPercent}%` : `${rect.height}px`
                          }}
                        >
                          {/* Inside Badge (when explicitly selected) */}
                          {effectiveShowBadges && badgePosition === 'inside' && rect.badgePosition !== 'hidden' && (
                            <span className="absolute pointer-events-none z-30 font-mono font-black text-[11px] px-1.5 py-0.5 rounded-md shadow-lg border flex items-center justify-center whitespace-nowrap top-1 left-1 bg-slate-950/95 text-amber-300 border-amber-400/80">
                              #{idx + 1}
                            </span>
                          )}

                          {/* Active prompt beacon in type mode */}
                          {isTargetInTypeMode && !isRevealed && (
                            <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-amber-400 text-slate-900 font-extrabold text-[11px] px-2.5 py-0.5 rounded-full shadow-lg whitespace-nowrap z-30 pointer-events-none flex items-center gap-1 animate-bounce">
                              <span>🎯 #{idx + 1} লিখুন</span>
                            </div>
                          )}

                          {studyMode === 'type' ? (
                            isRevealed ? (
                              <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-emerald-950/95 text-emerald-200 font-bold text-[11px] px-2.5 py-0.5 rounded-md shadow-lg border border-emerald-500/60 whitespace-nowrap z-20 pointer-events-none flex items-center gap-1 animate-in fade-in">
                                <span>✅ #{idx + 1}: {rect.label || card.title}</span>
                              </div>
                            ) : '?'
                          ) : occlusionMode === 'hide-one' ? (
                            isTargetInHideOne ? (
                              isRevealed ? (
                                rect.label ? (
                                  <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-950/95 text-emerald-300 font-bold text-xs px-2.5 py-1 rounded-lg shadow-xl border border-emerald-500 whitespace-nowrap z-30 pointer-events-auto flex items-center gap-1.5 animate-in fade-in zoom-in-95">
                                    <span>✅ #{idx + 1}: {rect.label}</span>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        speakText(rect.label);
                                      }}
                                      className="hover:text-white cursor-pointer ml-0.5"
                                      title="উচ্চারণ শুনুন"
                                    >
                                      <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                                    </button>
                                  </div>
                                ) : null
                              ) : (
                                <span className="text-xl text-slate-950 font-black select-none">?</span>
                              )
                            ) : (
                              showContextLabels && rect.label ? (
                                <div className="hidden group-hover:flex absolute -top-7 left-1/2 -translate-x-1/2 bg-slate-950/95 text-amber-300 border border-amber-500/60 px-2 py-0.5 rounded-md text-[11px] font-semibold shadow-lg whitespace-nowrap pointer-events-none z-30 animate-in fade-in">
                                  <span>{rect.label}</span>
                                </div>
                              ) : null
                            )
                          ) : (
                            !isRevealed ? '?' : (
                              rect.label ? (
                                <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-slate-900/90 text-white font-bold text-[11px] px-2 py-0.5 rounded-md shadow-lg border border-slate-700 whitespace-nowrap z-20 pointer-events-none flex items-center gap-1 animate-in fade-in zoom-in-95">
                                  <span>{rect.label}</span>
                                </div>
                              ) : null
                            )
                          )}
                        </motion.div>
                      );
                    })}
                    
                    {/* Occlusion Pins */}
                    {card.pins?.map((pin, idx) => {
                      const pinNumber = (card.rectangles?.length || 0) + idx + 1;
                      const isRevealed = revealedPins.has(pin.id);
                      const isTargetInHideOne = occlusionMode === 'hide-one' && allItems[activeItemIndex]?.id === pin.id;
                      const isTargetInTypeMode = studyMode === 'type' && allItems[activeItemIndex]?.id === pin.id;

                      let pinDotStyle = isRevealed ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white animate-pulse';
                      if (studyMode === 'type') {
                        if (isRevealed) {
                          pinDotStyle = 'bg-emerald-500 ring-2 ring-emerald-300 text-white';
                        } else if (isTargetInTypeMode) {
                          pinDotStyle = 'bg-amber-400 ring-4 ring-amber-300 text-slate-900 font-black animate-bounce scale-125';
                        } else {
                          pinDotStyle = 'bg-slate-700 ring-2 ring-slate-500 text-slate-300 hover:ring-amber-300';
                        }
                      } else if (occlusionMode === 'hide-one') {
                        if (isTargetInHideOne) {
                          pinDotStyle = isRevealed
                            ? 'bg-emerald-500 ring-4 ring-emerald-300 text-white shadow-lg'
                            : 'bg-amber-400 ring-4 ring-amber-300 text-slate-950 font-black scale-125 shadow-xl animate-pulse';
                        } else {
                          pinDotStyle = isRevealed
                            ? 'bg-emerald-600/70 text-white'
                            : 'bg-slate-700/80 text-slate-300 ring-1 ring-white/30 hover:ring-amber-400 hover:scale-110';
                        }
                      }

                      return (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8, y: -24, x: "-50%" }}
                          animate={{ opacity: 1, scale: 1, y: -24, x: "-50%" }}
                          transition={{ type: 'spring', stiffness: 260, damping: 20, delay: idx * 0.02 }}
                          key={pin.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleItemClick('pin', pin.id, pin);
                          }}
                          className="absolute z-10 flex flex-col items-center justify-center cursor-pointer"
                          style={{
                            left: pin.xPercent !== undefined ? `${pin.xPercent}%` : `${pin.x}px`,
                            top: pin.yPercent !== undefined ? `${pin.yPercent}%` : `${pin.y}px`
                          }}
                        >
                          {/* Active prompt beacon in type mode */}
                          {studyMode === 'type' && isTargetInTypeMode && !isRevealed && (
                            <div className="absolute -top-7 bg-amber-400 text-slate-900 font-extrabold text-[11px] px-2 py-0.5 rounded-full shadow-lg whitespace-nowrap z-30 pointer-events-none flex items-center gap-1 animate-bounce">
                              <span>🎯 #{pinNumber} লিখুন</span>
                            </div>
                          )}

                          {/* Active prompt beacon in hide-one mode */}
                          {studyMode !== 'type' && occlusionMode === 'hide-one' && isTargetInHideOne && !isRevealed && (
                            <div className="absolute -top-7 bg-amber-400 text-slate-900 font-extrabold text-[11px] px-2 py-0.5 rounded-full shadow-lg whitespace-nowrap z-30 pointer-events-none flex items-center gap-1 animate-bounce">
                              <span>🎯 #{pinNumber} আড়াল (ক্লিক করুন)</span>
                            </div>
                          )}

                          {/* Pin Number Badge beacon if active target in type mode */}
                          {isTargetInTypeMode && !isRevealed && (
                            <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-amber-400 text-slate-900 font-extrabold text-[11px] px-2 py-0.5 rounded-full shadow-lg whitespace-nowrap z-30 pointer-events-none flex items-center gap-1 animate-bounce">
                              <span>🎯 #{pinNumber} লিখুন</span>
                            </div>
                          )}

                          {/* Pin Bubble */}
                          <div className={`w-6 h-6 rounded-full border-2 border-white shadow-md relative z-10 transition-all flex items-center justify-center text-[10px] font-mono font-bold ${pinDotStyle} ${
                            (isTargetInTypeMode || isTargetInHideOne) ? 'ring-4 ring-amber-300 scale-110' : ''
                          }`}>
                            {pinNumber}
                          </div>

                          {/* Label popup if revealed or in hide-one mode with showContextLabels */}
                          {(isRevealed || (occlusionMode === 'hide-one' && showContextLabels && !isTargetInHideOne && pin.label)) && (
                            <div className="mt-1 bg-slate-950/90 text-slate-100 font-bold px-2.5 py-0.5 rounded-md shadow-lg text-xs whitespace-nowrap border border-slate-700 animate-in fade-in zoom-in-90 duration-200 flex items-center gap-1">
                              <span>#{pinNumber}: {pin.label}</span>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  speakText(pin.label);
                                }}
                                className="p-0.5 hover:text-indigo-400 cursor-pointer"
                                title="উচ্চারণ শুনুন"
                              >
                                <Volume2 className="w-3 h-3 text-slate-400" />
                              </button>
                            </div>
                          )}
                        </motion.div>
                      );
                    })}

                    {/* Edge-pinned Badges & Leader Lines (clings to outer sides, far away from text) */}
                    {effectiveShowBadges && badgePosition !== 'inside' && badgePosition !== 'hidden' && (
                      <>
                        <svg className="absolute inset-0 w-full h-full pointer-events-none z-20 overflow-visible">
                          {computedSideBadges.map(b => {
                            // In hide-one mode, only render leader line if it's the active target or if revealed
                            if (occlusionMode === 'hide-one' && !b.isTargetInHideOne && !b.isRevealed) {
                              return null;
                            }

                            const isHighlight = b.isTargetInHideOne || b.isTargetInTypeMode || hoveredRectId === b.id;
                            const strokeColor = isHighlight
                              ? "#fbbf24"
                              : b.isRevealed
                              ? "rgba(16, 185, 129, 0.75)"
                              : "rgba(251, 191, 36, 0.75)";

                            return (
                              <g key={`study-leader-${b.id}`}>
                                <line
                                  x1={`${b.anchorX}%`}
                                  y1={`${b.anchorY}%`}
                                  x2={`${b.targetX}%`}
                                  y2={`${b.targetY}%`}
                                  stroke="rgba(0,0,0,0.6)"
                                  strokeWidth={isHighlight ? "3.5" : "2"}
                                />
                                <line
                                  x1={`${b.anchorX}%`}
                                  y1={`${b.anchorY}%`}
                                  x2={`${b.targetX}%`}
                                  y2={`${b.targetY}%`}
                                  stroke={strokeColor}
                                  strokeWidth={isHighlight ? "2.5" : "1.2"}
                                  strokeDasharray={isHighlight ? "none" : "3 3"}
                                />
                                <circle
                                  cx={`${b.targetX}%`}
                                  cy={`${b.targetY}%`}
                                  r={isHighlight ? 4.5 : 2.5}
                                  fill={isHighlight ? "#fbbf24" : b.isRevealed ? "#10b981" : "#f59e0b"}
                                  stroke="#0f172a"
                                  strokeWidth="1"
                                />
                              </g>
                            );
                          })}
                        </svg>

                        {/* Pinned directly along the outer edge borders */}
                        {computedSideBadges.map(b => {
                          // In hide-one mode, only show active target badge unless revealed
                          if (occlusionMode === 'hide-one' && !b.isTargetInHideOne && !b.isRevealed) {
                            return null;
                          }

                          let badgeStyle = '';
                          if (b.isTargetInTypeMode || b.isTargetInHideOne) {
                            badgeStyle = 'bg-amber-400 text-slate-950 border-amber-300 ring-4 ring-amber-300/80 scale-115 animate-bounce shadow-[0_0_15px_rgba(251,191,36,0.9)]';
                          } else if (b.isRevealed) {
                            badgeStyle = 'bg-emerald-950/95 text-emerald-300 border-emerald-500/80 shadow-emerald-950/60 hover:bg-emerald-900';
                          } else {
                            badgeStyle = 'bg-slate-950/95 text-amber-300 border-amber-400/80 shadow-slate-950/80 hover:bg-slate-900';
                          }

                          return (
                            <button
                              key={`study-side-badge-${b.id}`}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleItemClick('rect', b.id, b.rect);
                              }}
                              onMouseEnter={() => setHoveredRectId(b.id)}
                              onMouseLeave={() => setHoveredRectId(null)}
                              className={`absolute z-30 font-mono font-black text-[10px] sm:text-[11px] px-1.5 py-0.5 rounded-md shadow-xl border flex items-center justify-center cursor-pointer transition-all active:scale-90 ${badgeStyle}`}
                              style={{
                                left: `${b.displayX}%`,
                                top: `${b.displayY}%`,
                                transform: 'translateY(-50%)'
                              }}
                              title={`আইটেম #${b.idx + 1}: ${b.label || 'চিহ্নিত অংশ'} (ক্লিক করে উত্তর দেখুন)`}
                            >
                              #{b.idx + 1}
                            </button>
                          );
                        })}
                      </>
                    )}
                      </>
                    )}
                  </motion.div>
                </TransformComponent>
                {/* Master Grounded Control Console - Draggable & Collapsible ("আমার ইচ্ছামতো ছোট করে নড়াচড়া করানো") */}
                {isToolbarCollapsed ? (
                  /* Compact Draggable Mini Floating Pill (ছবি পুরোপুরি দেখার জন্য মিনিমাইজড ভিউ) */
                  <motion.div
                    key={`mini-dock-${dockKey}`}
                    drag
                    dragMomentum={false}
                    dragElastic={0.1}
                    dragConstraints={canvasContainerRef}
                    className="absolute safe-bottom-dock left-0 right-0 mx-auto w-fit z-30 pointer-events-auto"
                  >
                    <div className="bg-slate-900/95 border border-slate-700/90 backdrop-blur-xl rounded-full shadow-2xl px-2.5 py-1.5 flex items-center gap-1.5 sm:gap-2 ring-1 ring-white/10 select-none">
                      {/* Drag Grip Handle */}
                      <div 
                        className="p-1 text-slate-400 hover:text-white cursor-grab active:cursor-grabbing touch-none rounded-lg"
                        title="টেনে যেকোনো জায়গায় সরান"
                      >
                        <Move className="w-3.5 h-3.5" />
                      </div>

                      {/* Mode & Progress Indicator */}
                      <span className="text-[11px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/25 shrink-0 flex items-center gap-1">
                        <span>{studyMode === 'click' ? '👆' : studyMode === 'mcq' ? '⚡' : '⌨️'}</span>
                        <span>{revealed.size + revealedPins.size}/{totalItems}</span>
                      </span>

                      {/* Quick Flip to Original Button */}
                      <button
                        type="button"
                        onClick={toggleFlipOriginal}
                        className={`p-1.5 rounded-full border text-xs font-bold transition-all cursor-pointer ${
                          isFlippedToOriginal
                            ? 'bg-emerald-500 text-slate-950 border-emerald-300 ring-2 ring-emerald-400/50'
                            : 'bg-slate-800 text-emerald-300 border-emerald-600/50 hover:bg-slate-700 hover:text-white'
                        }`}
                        title="কার্ড উল্টে আসল স্বাভাবিক চিত্রটি দেখুন"
                      >
                        <RotateCw className={`w-3.5 h-3.5 transition-transform duration-500 ${isFlippedToOriginal ? 'rotate-180' : ''}`} />
                      </button>

                      {/* Quick Reveal / Hide All in Click mode */}
                      {studyMode === 'click' && (
                        <button
                          type="button"
                          onClick={toggleRevealAll}
                          className="text-[11px] font-bold text-sky-300 hover:text-white px-2 py-1 rounded-lg bg-sky-600/20 border border-sky-500/40 hover:bg-sky-600/30 transition-colors cursor-pointer shrink-0"
                          title={allRevealed ? 'সব লুকান' : 'সব উন্মুক্ত'}
                        >
                          {allRevealed ? 'লুকান' : 'উন্মুক্ত'}
                        </button>
                      )}

                      {/* Quick Next Button */}
                      <button
                        type="button"
                        onClick={handleNext}
                        className={`p-1.5 rounded-full text-xs font-bold text-white transition-all cursor-pointer ${
                          isLast ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-blue-600 hover:bg-blue-500'
                        }`}
                        title={isLast ? 'সমাপ্ত' : 'পরবর্তী কার্ড'}
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>

                      {/* Expand Full Menu Button */}
                      <button
                        type="button"
                        onClick={() => handleToggleCollapse(false)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md cursor-pointer transition-all active:scale-95 shrink-0"
                        title="সব অপশন বড় করে দেখুন"
                      >
                        <ChevronUp className="w-3.5 h-3.5" />
                        <span>অপশন</span>
                      </button>
                    </div>
                  </motion.div>
                ) : (
                  /* Master Grounded Control Console - Draggable & Collapsible */
                  <motion.div
                    key={`full-dock-${dockKey}`}
                    drag
                    dragMomentum={false}
                    dragElastic={0.1}
                    dragConstraints={canvasContainerRef}
                    className="absolute safe-bottom-dock left-0 right-0 mx-auto w-[96vw] max-w-xl z-30 pointer-events-auto"
                  >
                    <div className="bg-slate-900/95 border border-slate-700/80 backdrop-blur-xl rounded-2xl shadow-2xl p-2 sm:p-2.5 flex flex-col gap-1.5 ring-1 ring-white/10">
                      
                      {/* Drag & Header Bar: Drag Handle + Reset Position + Minimize Button */}
                      <div className="flex items-center justify-between pb-1 border-b border-slate-800/80 text-xs">
                        <div 
                          className="flex items-center gap-1.5 text-slate-400 hover:text-slate-200 cursor-grab active:cursor-grabbing touch-none select-none px-1 py-0.5"
                          title="টেনে যেকোনো জায়গায় সরান"
                        >
                          <GripHorizontal className="w-4 h-4 text-amber-400 shrink-0" />
                          <span className="text-[11px] font-medium text-slate-300">ইচ্ছামতো টেনে যেকোনো জায়গায় রাখুন</span>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => setDockKey(k => k + 1)}
                            className="text-[10px] text-slate-400 hover:text-white px-2 py-0.5 rounded bg-slate-800/80 hover:bg-slate-750 border border-slate-700/60 cursor-pointer transition-colors"
                            title="কনসোলটি আবার আগের মাঝের জায়গায় নিয়ে আসুন"
                          >
                            মাঝে আনুন
                          </button>

                          {/* Minimize Button - অপশন ছোট করুন */}
                          <button
                            type="button"
                            onClick={() => handleToggleCollapse(true)}
                            className="flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 hover:text-amber-200 border border-amber-500/40 text-xs font-bold transition-all cursor-pointer active:scale-95"
                            title="অপশন ছোট করে মিনিমাইজ করুন যাতে ছবি পরিষ্কার দেখা যায়"
                          >
                            <ChevronDown className="w-3.5 h-3.5" />
                            <span>ছোট করুন</span>
                          </button>
                        </div>
                      </div>

                      {/* Tier 1: Segmented Study Mode Pill + Integrated Tools Bar */}
                    <div className="flex items-center justify-between gap-1.5 flex-wrap sm:flex-nowrap">
                      {/* Segmented Mode Selector */}
                      <div className="flex items-center bg-slate-950/90 p-0.5 rounded-xl border border-slate-800 shrink-0">
                        <button
                          type="button"
                          onClick={() => setStudyMode('click')}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                            studyMode === 'click' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
                          }`}
                          title="ক্লিক মোড"
                        >
                          👆 ক্লিক
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setStudyMode('mcq');
                            setOcclusionMode('hide-one');
                          }}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                            studyMode === 'mcq' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
                          }`}
                          title="MCQ কুইজ মোড"
                        >
                          <Zap className="w-3 h-3" />
                          <span>MCQ</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setStudyMode('type')}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                            studyMode === 'type' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
                          }`}
                          title="টাইপ পরীক্ষা মোড"
                        >
                          <Keyboard className="w-3 h-3" />
                          <span>টাইপ</span>
                        </button>
                      </div>

                      {/* Integrated Tools Row: Flip to Clean Original, Pen, Zoom Controls, Fullscreen */}
                      <div className="flex items-center gap-1 shrink-0 ml-auto">
                        {/* Flip Card to Original Clean Image */}
                        <button
                          type="button"
                          onClick={toggleFlipOriginal}
                          className={`px-2.5 py-1 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 ${
                            isFlippedToOriginal
                              ? 'bg-emerald-500 text-slate-950 border-emerald-300 ring-2 ring-emerald-400/50 shadow-sm'
                              : 'bg-slate-800 text-emerald-300 border-emerald-600/50 hover:bg-slate-750 hover:text-white'
                          }`}
                          title="কার্ড উল্টে মূল স্বাভাবিক চিত্রটি দেখুন (শর্টকাট: O)"
                        >
                          <RotateCw className={`w-3.5 h-3.5 transition-transform duration-500 ${isFlippedToOriginal ? 'rotate-180' : ''}`} />
                          <span>{isFlippedToOriginal ? 'স্টাডি' : 'আসল ছবি'}</span>
                        </button>

                        {/* Pen Toggle */}
                        <button
                          type="button"
                          onClick={() => setIsPenActive(!isPenActive)}
                          className={`p-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                            isPenActive 
                              ? 'bg-amber-400 text-slate-950 border-amber-300 ring-2 ring-amber-400/50 shadow-sm' 
                              : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
                          }`}
                          title="অন-ক্যানভাস মার্কার / কলম (P)"
                        >
                          <PenTool className="w-3.5 h-3.5" />
                        </button>

                        {/* Zoom Controls */}
                        <div className="flex items-center bg-slate-950/80 p-0.5 rounded-xl border border-slate-800">
                          <button
                            type="button"
                            onClick={() => zoomIn()}
                            className="p-1 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer"
                            title="জুম ইন"
                          >
                            <ZoomIn className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => zoomOut()}
                            className="p-1 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer"
                            title="জুম আউট"
                          >
                            <ZoomOut className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => resetTransform()}
                            className="p-1 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer"
                            title="ফিট টু স্ক্রিন (রিসেট)"
                          >
                            <Maximize className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Fullscreen */}
                        <button
                          type="button"
                          onClick={() => setIsFullscreen(!isFullscreen)}
                          className={`p-1.5 rounded-xl border transition-colors cursor-pointer ${
                            isFullscreen ? 'bg-amber-500 text-slate-950 font-bold border-amber-400' : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
                          }`}
                          title={isFullscreen ? "ফুলস্ক্রিন বন্ধ করুন (Esc)" : "ফুলস্ক্রিন ভিউ (F)"}
                        >
                          {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    {/* Tier 2: Active Mode Interactions (Dedicated console area) */}
                    {studyMode === 'mcq' && activeItem ? (
                      <div className="pt-1.5 border-t border-slate-800/90 flex flex-col gap-1.5">
                        {/* MCQ Header: Question Number, Prompt & Navigation */}
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-black text-xs px-2 py-0.5 rounded-lg bg-amber-400 text-slate-950 shadow-sm">
                              #{activeItemIndex + 1}/{allItems.length}
                            </span>
                            <span className="text-slate-300 text-xs font-medium">সঠিক উত্তর নির্বাচন করুন:</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              disabled={activeItemIndex === 0}
                              onClick={() => {
                                selectActiveItem(Math.max(0, activeItemIndex - 1));
                                setSelectedMcqOptionId(null);
                                setMcqFeedback(null);
                              }}
                              className="p-1 rounded-lg text-slate-300 hover:text-white bg-slate-800 disabled:opacity-30 cursor-pointer"
                              title="পূর্ববর্তী আইটেম"
                            >
                              <ChevronLeft className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              disabled={activeItemIndex === allItems.length - 1}
                              onClick={() => {
                                selectActiveItem(Math.min(allItems.length - 1, activeItemIndex + 1));
                                setSelectedMcqOptionId(null);
                                setMcqFeedback(null);
                              }}
                              className="p-1 rounded-lg text-slate-300 hover:text-white bg-slate-800 disabled:opacity-30 cursor-pointer"
                              title="পরবর্তী আইটেম"
                            >
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                            {/* Next Card Quick Button in MCQ */}
                            <button
                              type="button"
                              onClick={handleNext}
                              className={`ml-1 px-2.5 py-0.5 rounded-lg text-xs font-bold text-white shadow-xs cursor-pointer whitespace-nowrap transition-transform active:scale-95 ${
                                isLast ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-blue-600 hover:bg-blue-500'
                              }`}
                            >
                              {isLast ? 'সমাপ্ত' : 'পরবর্তী ➔'}
                            </button>
                          </div>
                        </div>

                        {/* 4 MCQ Option Choices in 2x2 Grid - Fits perfectly without scrolling */}
                        <div className="grid grid-cols-2 gap-1.5">
                          {mcqOptions.map((opt, i) => {
                            const bengaliLetters = ['ক', 'খ', 'গ', 'ঘ'];
                            const isSelected = selectedMcqOptionId === opt.id;
                            const isAnswered = selectedMcqOptionId !== null;

                            let btnStyle = 'bg-slate-800/90 hover:bg-slate-750 text-slate-200 border-slate-700 hover:border-amber-400';
                            if (isAnswered) {
                              if (opt.isCorrect) {
                                btnStyle = 'bg-emerald-600 text-white border-emerald-400 font-bold shadow-md';
                              } else if (isSelected) {
                                btnStyle = 'bg-rose-600 text-white border-rose-400 font-bold shadow-md';
                              } else {
                                btnStyle = 'bg-slate-800/50 text-slate-500 border-slate-800 opacity-60';
                              }
                            }

                            return (
                              <button
                                key={opt.id}
                                type="button"
                                disabled={isAnswered}
                                onClick={() => handleSelectMcqOption(opt)}
                                className={`px-2.5 py-1.5 rounded-xl text-xs border transition-all flex items-center gap-2 cursor-pointer active:scale-95 text-left ${btnStyle}`}
                              >
                                <span className="w-4 h-4 rounded-full bg-slate-950/60 flex items-center justify-center text-[10px] font-bold shrink-0">
                                  {bengaliLetters[i] || i + 1}
                                </span>
                                <span className="truncate">{opt.text}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ) : occlusionMode === 'hide-one' && activeItem && studyMode === 'click' ? (
                      /* Hide-one interactive console */
                      <div className="pt-1.5 border-t border-slate-800/90 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="font-mono font-black text-xs px-2 py-0.5 rounded-lg bg-amber-400 text-slate-950 shrink-0 shadow-sm">
                            #{activeItemIndex + 1}
                          </span>
                          {(activeItem.type === 'pin' ? revealedPins.has(activeItem.id) : revealed.has(activeItem.id)) ? (
                            <span className="text-emerald-400 font-bold text-xs truncate">
                              {activeItem.label || 'নামহীন'}
                            </span>
                          ) : (
                            <span className="text-slate-300 text-xs truncate">
                              #{activeItemIndex + 1} শনাক্ত করুন
                            </span>
                          )}
                          {activeItem.label && (activeItem.type === 'pin' ? revealedPins.has(activeItem.id) : revealed.has(activeItem.id)) && (
                            <button
                              type="button"
                              onClick={() => speakText(activeItem.label)}
                              className="p-1 text-emerald-400 hover:text-white cursor-pointer shrink-0"
                              title="উচ্চারণ শুনুন"
                            >
                              <Volume2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {!(activeItem.type === 'pin' ? revealedPins.has(activeItem.id) : revealed.has(activeItem.id)) ? (
                            <button
                              type="button"
                              onClick={() => {
                                if (activeItem.type === 'pin') togglePin(activeItem.item as Pin);
                                else toggleMask(activeItem.id);
                              }}
                              className="px-3 py-1 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer shadow-md transition-all active:scale-95"
                            >
                              উত্তর দেখুন
                            </button>
                          ) : (
                            <div className="flex items-center gap-1 bg-slate-950/80 p-0.5 rounded-xl border border-slate-800">
                              <button type="button" onClick={() => handleSrsRate('again')} className="px-2 py-0.5 rounded text-[11px] font-bold bg-rose-950/80 text-rose-300 border border-rose-800/80 cursor-pointer">আবার</button>
                              <button type="button" onClick={() => handleSrsRate('hard')} className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-950/80 text-amber-300 border border-amber-800/80 cursor-pointer">কঠিন</button>
                              <button type="button" onClick={() => handleSrsRate('good')} className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-800/80 cursor-pointer">ভালো</button>
                              <button type="button" onClick={() => handleSrsRate('easy')} className="px-2 py-0.5 rounded text-[11px] font-bold bg-blue-950/80 text-blue-300 border border-blue-800/80 cursor-pointer">সহজ</button>
                            </div>
                          )}

                          <button
                            type="button"
                            disabled={activeItemIndex === 0}
                            onClick={() => selectActiveItem(Math.max(0, activeItemIndex - 1))}
                            className="p-1 rounded-lg text-slate-300 hover:text-white bg-slate-800 disabled:opacity-30 cursor-pointer"
                            title="পূর্ববর্তী"
                          >
                            <ChevronLeft className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={activeItemIndex === allItems.length - 1}
                            onClick={() => selectActiveItem(Math.min(allItems.length - 1, activeItemIndex + 1))}
                            className="p-1 rounded-lg text-slate-300 hover:text-white bg-slate-800 disabled:opacity-30 cursor-pointer"
                            title="পরবর্তী"
                          >
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ) : studyMode === 'click' ? (
                      /* Click Mode Standard View */
                      <div className="pt-1.5 border-t border-slate-800/90 flex items-center justify-between gap-2 flex-wrap sm:flex-nowrap">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-slate-300 bg-slate-950/70 px-2 py-1 rounded-lg border border-slate-800">
                            আইটেম: <strong className="text-amber-400 font-mono">{revealed.size + revealedPins.size}</strong>/{totalItems}
                          </span>
                          
                          <button
                            type="button"
                            onClick={toggleRevealAll}
                            className="text-xs font-bold text-sky-300 hover:text-white px-2.5 py-1 rounded-lg bg-sky-600/20 border border-sky-500/40 hover:bg-sky-600/30 transition-colors cursor-pointer"
                          >
                            {allRevealed ? 'সব লুকান' : 'সব উন্মুক্ত'}
                          </button>

                          {/* Badge toggle */}
                          <button
                            type="button"
                            onClick={() => {
                              setShowBadges(prev => {
                                const next = !prev;
                                if (onUpdateCard && card) {
                                  onUpdateCard(card.id, { showBadges: next });
                                }
                                return next;
                              });
                            }}
                            className={`p-1 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                              showBadges
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                                : 'bg-rose-950/80 text-rose-300 border-rose-800'
                            }`}
                            title={showBadges ? 'নম্বর ব্যাজ (#১,#২...) ও দাগ গায়েব করুন' : 'নম্বর ব্যাজ ও দাগ চালু করুন'}
                          >
                            {showBadges ? <Hash className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                          </button>
                        </div>

                        {/* Rating or Next Card */}
                        {allRevealed ? (
                          <div className="flex items-center gap-1 bg-slate-950/80 p-0.5 rounded-xl border border-slate-800 shrink-0">
                            <button type="button" onClick={() => handleSrsRate('again')} className="px-2 py-0.5 rounded text-[11px] font-bold bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800/80 cursor-pointer">আবার</button>
                            <button type="button" onClick={() => handleSrsRate('hard')} className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-950/80 hover:bg-amber-900 text-amber-300 border border-amber-800/80 cursor-pointer">কঠিন</button>
                            <button type="button" onClick={() => handleSrsRate('good')} className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-800/80 cursor-pointer">ভালো</button>
                            <button type="button" onClick={() => handleSrsRate('easy')} className="px-2 py-0.5 rounded text-[11px] font-bold bg-blue-950/80 hover:bg-blue-900 text-blue-300 border border-blue-800/80 cursor-pointer">সহজ</button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={handleNext}
                            className={`px-3 py-1 rounded-xl text-xs font-bold text-white shadow-md flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer ml-auto shrink-0 ${
                              isLast ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-blue-600 hover:bg-blue-500'
                            }`}
                          >
                            <span>{isLast ? 'সমাপ্ত' : 'পরবর্তী কার্ড'}</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    ) : null}
                  </div>
                </motion.div>
              )}
              </>
            )}
          </TransformWrapper>
        </div>

        {/* Type-in Active Recall Console */}
        {studyMode === 'type' && (
          <div className="w-full max-w-2xl mt-3 p-3.5 bg-slate-800/95 border border-indigo-500/40 rounded-2xl shadow-xl shrink-0">
            {/* Upper Items Navigation Bar */}
            <div className="flex flex-col gap-2 pb-2.5 border-b border-slate-700/70 mb-3">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-indigo-300 font-semibold">
                  <Keyboard className="w-3.5 h-3.5 text-indigo-400" />
                  <span>টাইপ মোড আইটেমসমূহ (মোট {allItems.length} টি)</span>
                  <span className="bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded-full text-[11px] border border-indigo-700/50">
                    {revealed.size + revealedPins.size}/{allItems.length} সম্পন্ন
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {/* View Mode Toggle: Single vs List */}
                  <div className="flex items-center bg-slate-900 p-0.5 rounded-lg border border-slate-700 text-[11px]">
                    <button
                      type="button"
                      onClick={() => setTypeViewMode('single')}
                      className={`px-2 py-0.5 rounded font-medium transition-all cursor-pointer ${
                        typeViewMode === 'single' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                      title="একক আইটেমে ফোকাস করুন"
                    >
                      একক 🎯
                    </button>
                    <button
                      type="button"
                      onClick={() => setTypeViewMode('list')}
                      className={`px-2 py-0.5 rounded font-medium transition-all cursor-pointer ${
                        typeViewMode === 'list' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                      title="সবগুলোর তালিকা এক সাথে দেখুন ও লিখুন"
                    >
                      তালিকা 📋
                    </button>
                  </div>

                  {/* Quick Reveal All */}
                  <button
                    type="button"
                    onClick={toggleRevealAll}
                    className="text-[11px] px-2 py-1 rounded-lg bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center gap-1 cursor-pointer transition-all"
                    title="সবগুলোর নাম এক ক্লিকে প্রকাশ করুন"
                  >
                    <Eye className="w-3 h-3 text-amber-400" />
                    <span className="hidden sm:inline">সব উত্তর দেখুন</span>
                  </button>
                </div>
              </div>

              {/* Horizontal Pill Selectors for All Items */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
                {allItems.map((item, idx) => {
                  const isDone = item.type === 'pin' ? revealedPins.has(item.id) : revealed.has(item.id);
                  const isActive = activeItemIndex === idx;

                  return (
                    <button
                      key={`item-pill-${item.type}-${item.id}`}
                      type="button"
                      onClick={() => selectActiveItem(idx)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer shrink-0 border ${
                        isDone
                          ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/60'
                          : isActive
                          ? 'bg-indigo-600 border-amber-400 text-white ring-2 ring-amber-400/50 shadow-md scale-105'
                          : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white hover:border-slate-500'
                      }`}
                      title={isDone ? `সম্পন্ন: ${item.label}` : `আইটেম #${item.itemNumber} নির্বাচন করুন`}
                    >
                      <span>#{item.itemNumber}</span>
                      {isDone ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="max-w-[120px] truncate">{item.label}</span>
                        </>
                      ) : isActive ? (
                        <span className="text-amber-200">✍️ টাইপ করুন</span>
                      ) : (
                        <span>{item.type === 'pin' ? '📌' : '🔍'}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Single Item Mode View */}
            {typeViewMode === 'single' ? (
              <form onSubmit={handleCheckTypedAnswer} className="flex flex-col gap-2.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 text-indigo-200 font-bold">
                    <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.5 rounded">
                      আইটেম #{activeItem?.itemNumber}
                    </span>
                    <span>
                      {activeItem?.type === 'pin' ? 'চিহ্নিত পিনটির নাম লিখুন:' : 'লুকানো মাস্ক অংশের নাম লিখুন:'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleRevealCurrentItem}
                      className="text-slate-400 hover:text-amber-300 text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                      title="এই আইটেমটির উত্তর প্রকাশ করুন"
                    >
                      <HelpCircle className="w-3 h-3" /> উত্তর দেখুন
                    </button>
                    {allItems.length > 1 && (
                      <button
                        type="button"
                        onClick={nextActiveItem}
                        className="text-slate-400 hover:text-white text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <RotateCcw className="w-3 h-3" /> পরবর্তী ({activeItemIndex + 1}/{allItems.length})
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <input
                    ref={inputRef}
                    type="text"
                    value={typedAnswer}
                    onChange={(e) => setTypedAnswer(e.target.value)}
                    placeholder={`আইটেম #${activeItem?.itemNumber} এর নাম টাইপ করুন (অথবা একসাথে একাধিক)...`}
                    className="flex-1 bg-slate-900 border border-slate-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 outline-none"
                    autoFocus
                  />
                  <button
                    type="submit"
                    disabled={!typedAnswer.trim()}
                    className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-xl transition-all active:scale-95 cursor-pointer shadow-md flex items-center gap-1.5 shrink-0"
                  >
                    <span>যাচাই করুন</span>
                    <CheckCheck className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-[11px] text-slate-400 leading-tight">
                  💡 <strong className="text-slate-300">সহজ সুবিধা:</strong> আপনি চাইলে একাধিক নামও একসাথে কমা দিয়ে লিখতে পারেন (যেমন: <em>"নাম ১, নাম ২"</em>) অথবা ওপরের যেকোনো নম্বরে বা ডায়ագրামে ক্লিক করে আলাদাভাবে টাইপ করতে পারেন।
                </p>

                {typeFeedback && (
                  <div className={`p-3 rounded-xl text-xs flex flex-wrap items-center justify-between gap-2 animate-in fade-in slide-in-from-top-1 ${
                    typeFeedback.isCorrect
                      ? 'bg-emerald-950/90 border border-emerald-500/60 text-emerald-200'
                      : 'bg-rose-950/90 border border-rose-500/60 text-rose-200'
                  }`}>
                    <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                      {typeFeedback.isCorrect ? (
                        <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <X className="w-4 h-4 text-rose-400 shrink-0" />
                      )}
                      <span className="font-medium">
                        {typeFeedback.message || (typeFeedback.isCorrect ? 'অসাধারণ! উত্তরটি সঠিক হয়েছে।' : `ভুল হয়েছে! সঠিক উত্তর: "${typeFeedback.correctAnswer}"`)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {typeFeedback.correctAnswer && (
                        <button
                          type="button"
                          onClick={() => speakText(typeFeedback.correctAnswer)}
                          className="p-1.5 rounded-lg bg-black/30 hover:bg-black/50 text-white cursor-pointer transition-colors flex items-center gap-1"
                          title="উচ্চারণ শুনুন"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span className="text-[11px]">শুনুন</span>
                        </button>
                      )}
                      {allItems.length > 1 && (
                        <button
                          type="button"
                          onClick={nextActiveItem}
                          className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] cursor-pointer transition-all active:scale-95 shadow"
                        >
                          পরবর্তী আইটেম ➔
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </form>
            ) : (
              /* All Items List Mode View */
              <div className="flex flex-col gap-2 max-h-60 overflow-y-auto pr-1">
                {allItems.map((item, idx) => {
                  const isDone = item.type === 'pin' ? revealedPins.has(item.id) : revealed.has(item.id);
                  const isCurActive = activeItemIndex === idx;

                  return (
                    <div
                      key={`list-row-${item.id}`}
                      className={`p-2 rounded-xl border transition-all flex items-center justify-between gap-2 text-xs ${
                        isDone
                          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                          : isCurActive
                          ? 'bg-indigo-950/50 border-indigo-500 text-white ring-1 ring-indigo-400/50'
                          : 'bg-slate-900/60 border-slate-700/70 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-[90px]">
                        <span className="font-mono font-bold text-amber-300 bg-slate-800 px-1.5 py-0.5 rounded text-[11px]">
                          #{item.itemNumber}
                        </span>
                        <span>{item.type === 'pin' ? '📌 পিন' : '🔍 মাস্ক'}</span>
                      </div>

                      {isDone ? (
                        <div className="flex items-center justify-between flex-1 pl-2">
                          <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            {item.label}
                          </span>
                          <button
                            type="button"
                            onClick={() => speakText(item.label)}
                            className="p-1 text-slate-400 hover:text-white cursor-pointer"
                            title="উচ্চারণ শুনুন"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 flex-1">
                          <input
                            type="text"
                            value={itemAnswers[item.id] || ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              setItemAnswers(prev => ({ ...prev, [item.id]: val }));
                            }}
                            onFocus={() => setActiveItemIndex(idx)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                handleCheckTypedAnswer(e, item.id);
                              }
                            }}
                            placeholder="নাম টাইপ করুন..."
                            className="flex-1 bg-slate-950 border border-slate-700 focus:border-indigo-400 rounded-lg px-2 py-1 text-xs text-white outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleCheckTypedAnswer(undefined, item.id)}
                            disabled={!itemAnswers[item.id]?.trim()}
                            className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold px-2.5 py-1 rounded-lg text-[11px] cursor-pointer shrink-0"
                          >
                            যাচাই
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              selectActiveItem(idx);
                              handleRevealCurrentItem();
                            }}
                            className="text-slate-400 hover:text-amber-300 p-1 cursor-pointer"
                            title="উত্তর দেখুন"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}



      </main>

      {/* Options & Settings Slide-Over Drawer */}
      {showOptionsDrawer && (
        <div className="fixed inset-0 z-50 flex justify-end animate-in fade-in duration-150">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity cursor-pointer" 
            onClick={() => setShowOptionsDrawer(false)} 
          />
          
          {/* Drawer Panel */}
          <div className="relative w-full sm:w-[440px] bg-slate-900 border-l border-slate-700/80 shadow-2xl h-full flex flex-col z-10 animate-in slide-in-from-right duration-200">
            {/* Drawer Header */}
            <div className="p-3.5 sm:p-4 bg-slate-850 border-b border-slate-700/80 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2 text-white font-bold text-sm sm:text-base">
                <Settings className="w-4 h-4 text-amber-400" />
                <span>স্টাডি অপশন ও সেটিংস</span>
              </div>
              <button
                type="button"
                onClick={() => setShowOptionsDrawer(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer transition-colors"
                title="বন্ধ করুন (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Drawer Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs sm:text-sm text-slate-300">
              {/* Clean Original View Quick Toggle */}
              <div className="bg-emerald-950/40 rounded-xl p-3.5 border border-emerald-600/50 space-y-2.5 shadow-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-bold text-emerald-300 text-xs sm:text-sm">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>আসল ছবি দর্শন (ক্লিন ভিউ)</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      toggleFlipOriginal();
                      setShowOptionsDrawer(false);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5 shadow-xs active:scale-95 ${
                      isFlippedToOriginal
                        ? 'bg-emerald-500 text-slate-950 border-emerald-300'
                        : 'bg-emerald-900/60 hover:bg-emerald-800 text-emerald-200 border-emerald-500/60'
                    }`}
                  >
                    <RotateCw className={`w-3.5 h-3.5 ${isFlippedToOriginal ? 'rotate-180' : ''}`} />
                    <span>{isFlippedToOriginal ? 'স্টাডিতে ফিরুন' : 'আসল ছবি দেখুন'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-emerald-200/80 leading-relaxed">
                  কোনো দাগ, পিন বা মাস্ক ছাড়া মূল পরিষ্কার চিত্রটি এক ক্লিকে উল্টে দেখুন। স্টাডি ও আসল ছবির মাঝে দ্রুত অদলবদল করা যায়। (কিবোর্ড শর্টকাট: <kbd className="px-1.5 py-0.5 bg-slate-900 border border-emerald-700/60 rounded text-emerald-300 font-mono text-[10px]">O</kbd>)
                </p>
              </div>

              {/* Section 1: Occlusion Mode & Study Mode */}
              <div className="bg-slate-800/80 rounded-xl p-3.5 border border-slate-700 space-y-3">
                <div className="flex items-center gap-2 font-bold text-white text-xs sm:text-sm border-b border-slate-700/60 pb-2">
                  <SlidersHorizontal className="w-4 h-4 text-amber-400" />
                  <span>আড়াল ও পড়ার মোড</span>
                </div>

                {/* Hide One vs Hide All */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-semibold text-slate-400">আড়াল পদ্ধতি (Anki IO Style):</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setOcclusionMode('hide-one');
                        if (studyMode === 'type') setStudyMode('click');
                      }}
                      className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                        occlusionMode === 'hide-one'
                          ? 'bg-amber-500/20 border-amber-400 text-amber-200 font-bold shadow-sm'
                          : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white hover:border-slate-600'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <Eye className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-xs font-bold">একটি আড়াল</span>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight">
                        শুধুমাত্র টার্গেট অংশ আড়াল, বাকি প্রেক্ষাপট দৃশ্যমান
                      </p>
                    </button>

                    <button
                      type="button"
                      onClick={() => setOcclusionMode('hide-all')}
                      className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                        occlusionMode === 'hide-all'
                          ? 'bg-blue-600/30 border-blue-400 text-blue-200 font-bold shadow-sm'
                          : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white hover:border-slate-600'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <Layers className="w-3.5 h-3.5 text-blue-400" />
                        <span className="text-xs font-bold">সব আড়াল</span>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight">
                        সবগুলো মাস্ক একসাথে আড়াল থাকবে
                      </p>
                    </button>
                  </div>
                </div>

                {/* Context Labels Toggle (in Hide One) */}
                {occlusionMode === 'hide-one' && (
                  <div className="flex items-center justify-between pt-1 border-t border-slate-700/60">
                    <div className="flex flex-col">
                      <span className="text-xs font-semibold text-slate-300">প্রেক্ষাপট লেবেল</span>
                      <span className="text-[10px] text-slate-400">অন্যান্য অংশের নাম চিত্রে দেখা যাবে কিনা</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowContextLabels(!showContextLabels)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                        showContextLabels
                          ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-xs'
                          : 'bg-slate-900 text-slate-400 border-slate-700'
                      }`}
                    >
                      {showContextLabels ? 'অন (দৃশ্যমান)' : 'অফ (লুকানো)'}
                    </button>
                  </div>
                )}

                {/* Click vs Type Mode */}
                <div className="space-y-1.5 pt-1 border-t border-slate-700/60">
                  <span className="text-[11px] font-semibold text-slate-400">পড়ার ধরন:</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setStudyMode('click')}
                      className={`p-2 rounded-xl text-center border transition-all cursor-pointer flex items-center justify-center gap-1.5 text-xs font-semibold ${
                        studyMode === 'click'
                          ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                          : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      <MousePointer className="w-3.5 h-3.5" />
                      <span>ক্লিক মোড</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setStudyMode('type')}
                      className={`p-2 rounded-xl text-center border transition-all cursor-pointer flex items-center justify-center gap-1.5 text-xs font-semibold ${
                        studyMode === 'type'
                          ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm'
                          : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      <Keyboard className="w-3.5 h-3.5" />
                      <span>টাইপ মোড</span>
                    </button>
                  </div>
                </div>

                {/* Badge & Leader Line Visibility & Position */}
                {studyMode === 'click' && (
                  <div className="space-y-2 pt-1 border-t border-slate-700/60">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-semibold text-slate-300">ব্যাজ ও লিডার লাইন দাগ (B):</span>
                      <button
                        type="button"
                        onClick={() => {
                          setShowBadges(prev => {
                            const next = !prev;
                            if (onUpdateCard && card) {
                              onUpdateCard(card.id, { showBadges: next });
                            }
                            return next;
                          });
                        }}
                        className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5 ${
                          showBadges
                            ? 'bg-emerald-600 text-white border-emerald-500 shadow-xs'
                            : 'bg-rose-950/80 text-rose-300 border-rose-800'
                        }`}
                      >
                        {showBadges ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        <span>{showBadges ? 'অন (দৃশ্যমান)' : 'অফ (দাগ ও ব্যাজ গায়েব)'}</span>
                      </button>
                    </div>

                    {showBadges && (
                      <div className="space-y-1">
                        <span className="text-[10px] text-slate-400">অবস্থান পরিবর্তন:</span>
                        <div className="grid grid-cols-4 gap-1.5">
                          {[
                            { id: 'auto', label: 'স্মার্ট' },
                            { id: 'left', label: 'বাম পাশে' },
                            { id: 'right', label: 'ডান পাশে' },
                            { id: 'inside', label: 'ভেতরে' }
                          ].map(bp => (
                            <button
                              key={bp.id}
                              type="button"
                              onClick={() => setBadgePosition(bp.id as any)}
                              className={`py-1.5 px-1 rounded-lg text-xs font-bold border transition-all text-center cursor-pointer ${
                                badgePosition === bp.id
                                  ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-xs'
                                  : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white'
                              }`}
                            >
                              {bp.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Status Bar / Notch Gap for Mobile APK */}
              <div className="bg-slate-800/80 rounded-xl p-3.5 border border-slate-700 space-y-2">
                <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                  <div className="flex items-center gap-2 font-bold text-white text-xs sm:text-sm">
                    <Smartphone className="w-4 h-4 text-sky-400" />
                    <span>উপরের স্ট্যাটাস বার সেফ স্পেস</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-950 text-sky-300 border border-sky-800 font-semibold">
                    APK / Notch
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-tight">
                  ফোনের ওয়াইফাই, ব্যাটারি বা নচ আইকন বাটনের ওপর যাতে না আসে, সেজন্য নিচের সাইজ নির্বাচন করুন:
                </p>
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {[
                    { id: 'auto', label: 'অটো (৩৬px)' },
                    { id: 'standard', label: 'স্ট্যান্ডার্ড' },
                    { id: 'tall', label: 'বেশি (৪৮px)' },
                    { id: 'none', label: 'বন্ধ (০px)' }
                  ].map(item => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setNotchSetting(item.id as NotchSetting);
                        setLocalNotch(item.id as NotchSetting);
                        setAlertMsg(`স্ট্যাটাস বার স্পেস: ${item.label}`);
                        setTimeout(() => setAlertMsg(''), 2000);
                      }}
                      className={`py-1.5 px-1 rounded-lg text-[11px] font-bold border transition-all text-center cursor-pointer ${
                        localNotch === item.id
                          ? 'bg-sky-500 text-slate-950 border-sky-300 shadow-xs'
                          : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Section: Bottom Navigation Bar Space (Back/Home Button Clearance) */}
              <div className="bg-slate-800/80 rounded-xl p-3.5 border border-slate-700 space-y-2.5">
                <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                  <div className="flex items-center gap-2 font-bold text-white text-xs sm:text-sm">
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    <span>নিচের নেভিগেশন বার স্পেস (ব্যাক/হোম বাটন)</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-900/60 text-emerald-300 font-semibold">
                    {localBottomNav}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-tight">
                  ফোনের পেছনের ব্যাক বাটন বা হোম বাটন যাতে স্টাডি বাটনের সাথে ওভারল্যাপ না করে, সেজন্য স্পেস বা ব্যবধান বাড়ান বা কমান:
                </p>
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {[
                    { id: 'auto', label: 'স্বয়ংক্রিয় (৫৮px)' },
                    { id: 'tall', label: 'বেশি (৭৬px)' },
                    { id: 'extra', label: 'সর্বোচ্চ (৯২px)' },
                    { id: 'compact', label: 'ছোট (৩৬px)' },
                  ].map(item => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setBottomNavSetting(item.id as BottomNavSetting);
                        setLocalBottomNav(item.id as BottomNavSetting);
                        setAlertMsg(`নিচের স্পেস: ${item.label}`);
                        setTimeout(() => setAlertMsg(''), 2000);
                      }}
                      className={`py-1.5 px-1 rounded-lg text-[11px] font-bold border transition-all text-center cursor-pointer ${
                        localBottomNav === item.id
                          ? 'bg-emerald-500 text-slate-950 border-emerald-300 shadow-xs'
                          : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Section 2: Study Notes & Mnemonics */}
              <div className="bg-slate-800/80 rounded-xl p-3.5 border border-slate-700 space-y-2.5">
                <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                  <div className="flex items-center gap-2 font-bold text-white text-xs sm:text-sm">
                    <FileText className="w-4 h-4 text-emerald-400" />
                    <span>স্মার্ট স্টাডি নোট ও ছন্দ</span>
                  </div>
                  {card.notes && (
                    <button
                      type="button"
                      onClick={handleToggleNotesSpeech}
                      className={`px-2 py-0.5 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-all ${
                        isNotesSpeaking
                          ? 'bg-rose-600 text-white animate-pulse'
                          : 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/50'
                      }`}
                    >
                      {isNotesSpeaking ? <Square className="w-3 h-3 fill-current" /> : <Volume2 className="w-3 h-3" />}
                      <span>{isNotesSpeaking ? 'থামান' : 'শুনুন'}</span>
                    </button>
                  )}
                </div>

                {card.notes ? (
                  <div className="whitespace-pre-wrap text-xs sm:text-sm text-slate-200 bg-slate-900/80 p-3 rounded-xl border border-slate-700/60 leading-relaxed max-h-48 overflow-y-auto">
                    {card.notes}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 italic">
                    এই কার্ডে কোনো স্টাডি নোট বা ছন্দ যুক্ত করা হয়নি।
                  </p>
                )}
              </div>

              {/* Section: Speech Repetition & Sound */}
              <div className="bg-slate-800/80 rounded-xl p-3.5 border border-slate-700 space-y-2.5">
                <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                  <div className="flex items-center gap-2 font-bold text-white text-xs sm:text-sm">
                    <Repeat className="w-4 h-4 text-purple-400" />
                    <span>স্পিচ রিপিটেশন ও সাউন্ড</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-900/60 text-purple-300 font-semibold">
                    {speechSettings.repeatCount}x পুনরাবৃত্তি
                  </span>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-300">প্রতি উচ্চারণে পুনরাবৃত্তি:</span>
                    <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-lg border border-slate-700">
                      {[1, 2, 3].map(cnt => (
                        <button
                          key={cnt}
                          type="button"
                          onClick={() => {
                            triggerHaptic('light');
                            const next = updateSpeechSettings({ repeatCount: cnt });
                            setSpeechSettings(next);
                          }}
                          className={`px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                            speechSettings.repeatCount === cnt
                              ? 'bg-purple-600 text-white shadow-xs'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {cnt}x
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1.5 border-t border-slate-700/50">
                    <span className="text-xs text-slate-300">আড়াল খুললে অটো উচ্চারণ:</span>
                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        const nextVal = !speechSettings.autoPronounceOnReveal;
                        const next = updateSpeechSettings({ autoPronounceOnReveal: nextVal });
                        setSpeechSettings(next);
                      }}
                      className={`px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                        speechSettings.autoPronounceOnReveal
                          ? 'bg-purple-600 text-white'
                          : 'bg-slate-700 text-slate-400'
                      }`}
                    >
                      {speechSettings.autoPronounceOnReveal ? 'চালু' : 'বন্ধ'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Section 3: All Items List Navigator */}
              <div className="bg-slate-800/80 rounded-xl p-3.5 border border-slate-700 space-y-2.5">
                <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                  <div className="flex items-center gap-2 font-bold text-white text-xs sm:text-sm">
                    <ListChecks className="w-4 h-4 text-blue-400" />
                    <span>সকল আইটেম ({allItems.length} টি)</span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    {revealed.size + revealedPins.size}/{allItems.length} উন্মুক্ত
                  </span>
                </div>

                <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                  {allItems.map((item, idx) => {
                    const isDone = item.type === 'pin' ? revealedPins.has(item.id) : revealed.has(item.id);
                    const isActive = activeItemIndex === idx;

                    return (
                      <button
                        key={`drawer-item-${item.type}-${item.id}`}
                        type="button"
                        onClick={() => {
                          selectActiveItem(idx);
                          setShowOptionsDrawer(false);
                        }}
                        className={`w-full p-2 rounded-xl text-left border flex items-center justify-between gap-2 transition-all cursor-pointer ${
                          isActive
                            ? 'bg-amber-500/20 border-amber-400 text-amber-200 font-semibold'
                            : isDone
                            ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                            : 'bg-slate-900/70 border-slate-700/80 text-slate-300 hover:border-slate-500 hover:text-white'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span className={`font-mono font-bold text-xs px-1.5 py-0.5 rounded ${
                            isActive ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-400'
                          }`}>
                            #{idx + 1}
                          </span>
                          <span className="text-xs truncate font-medium">
                            {item.label || (item.type === 'pin' ? 'পিন' : 'মাস্ক')}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {isDone ? (
                            <span className="text-[10px] text-emerald-400 flex items-center gap-0.5">
                              <Check className="w-3 h-3" /> দেখা হয়েছে
                            </span>
                          ) : (
                            <span className="text-[10px] text-slate-500">বাকি আছে</span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Section 4: Extra Tools & Help */}
              <div className="bg-slate-800/80 rounded-xl p-3.5 border border-slate-700 space-y-2.5">
                <span className="text-xs font-bold text-white block border-b border-slate-700/60 pb-1.5">
                  অন্যান্য সুবিধা ও শর্টকাট
                </span>
                
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAiTutor(true);
                      setShowOptionsDrawer(false);
                    }}
                    className="p-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>AI টিউটর</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onEdit(card.id);
                      setShowOptionsDrawer(false);
                    }}
                    className="p-2.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer border border-slate-600"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                    <span>কার্ড এডিট</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleExportCurrentDeck}
                  className="w-full p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer border border-slate-600 transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-blue-400" />
                  <span>ডেক ডাউনলোড ও ব্যাকআপ (JSON)</span>
                </button>

                <div className="bg-slate-900/80 rounded-xl p-2.5 border border-slate-700/60 text-[11px] text-slate-400 space-y-1">
                  <div className="font-semibold text-slate-300">কিবোর্ড শর্টকাট:</div>
                  <div className="flex justify-between">
                    <span>উত্তর দেখা / পরবর্তী:</span>
                    <kbd className="px-1 py-0.2 bg-slate-950 rounded text-amber-300 font-mono">Space</kbd>
                  </div>
                  <div className="flex justify-between">
                    <span>পূর্ববর্তী / পরবর্তী আইটেম:</span>
                    <kbd className="px-1 py-0.2 bg-slate-950 rounded text-amber-300 font-mono">← / →</kbd>
                  </div>
                  <div className="flex justify-between">
                    <span>SRS রেটিং (আবার-সহজ):</span>
                    <kbd className="px-1 py-0.2 bg-slate-950 rounded text-amber-300 font-mono">1, 2, 3, 4</kbd>
                  </div>
                  <div className="flex justify-between">
                    <span>মার্কার কলম টগল:</span>
                    <kbd className="px-1 py-0.2 bg-slate-950 rounded text-amber-300 font-mono">P</kbd>
                  </div>
                  <div className="flex justify-between">
                    <span>ফুলস্ক্রিন টগল:</span>
                    <kbd className="px-1 py-0.2 bg-slate-950 rounded text-amber-300 font-mono">F</kbd>
                  </div>
                  <div className="flex justify-between">
                    <span>ড্রয়ার বন্ধ:</span>
                    <kbd className="px-1 py-0.2 bg-slate-950 rounded text-amber-300 font-mono">Esc</kbd>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating SRS Toast Notification */}
      {srsToast && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 text-white border border-slate-700/90 px-4 py-2 rounded-2xl shadow-2xl backdrop-blur-md flex items-center gap-2 text-xs sm:text-sm animate-in fade-in slide-in-from-top-3">
          <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${
            srsToast.rating === 'again' ? 'bg-rose-500 ring-2 ring-rose-300/40' :
            srsToast.rating === 'hard' ? 'bg-amber-500 ring-2 ring-amber-300/40' :
            srsToast.rating === 'good' ? 'bg-emerald-400 ring-2 ring-emerald-300/40' : 'bg-blue-400 ring-2 ring-blue-300/40'
          }`} />
          <span className="font-semibold text-slate-100">{srsToast.message}</span>
        </div>
      )}

      {/* Session Summary Analytics Modal */}
      {showSessionSummary && (
        <SessionSummaryModal
          cards={activeCardsList}
          againCardIds={againCardIds}
          revealedCount={totalRevealedCount}
          totalMaskCount={activeCardsList.reduce((acc, c) => acc + (c.rectangles?.length || 0) + (c.pins?.length || 0), 0)}
          durationSeconds={sessionDuration}
          onRestartAll={handleRestartAll}
          onReviewWeakSpots={handleReviewWeakSpots}
          onFinish={onClose}
        />
      )}

      {/* Universal File Export Modal (With Copy, Share, Download, Drive options and APK guidance) */}
      {exportPayload && (
        <FileExportModal
          isOpen={showExportModal}
          onClose={() => {
            setShowExportModal(false);
            setExportPayload(null);
          }}
          data={exportPayload.data}
          filename={exportPayload.filename}
          title={exportPayload.title}
          onOpenGoogleDrive={() => {
            setShowExportModal(false);
            openSyncModal('drive');
          }}
          onSuccess={(msg) => setAlertMsg(msg)}
        />
      )}
    </div>
  );
}
