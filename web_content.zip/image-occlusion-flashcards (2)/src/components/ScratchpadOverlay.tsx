import React, { useRef, useEffect, useState, useCallback } from 'react';
import { PenTool, RotateCcw, Trash2, X, Check } from 'lucide-react';

interface ScratchpadOverlayProps {
  isActive: boolean;
  onToggleActive: (active: boolean) => void;
  width: number;
  height: number;
}

interface Stroke {
  color: string;
  size: number;
  points: { x: number; y: number }[];
}

export default function ScratchpadOverlay({
  isActive,
  onToggleActive,
  width,
  height,
}: ScratchpadOverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentColor, setCurrentColor] = useState('#facc15'); // Neon yellow
  const [currentSize, setCurrentSize] = useState(4);
  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const currentStrokeRef = useRef<Stroke | null>(null);

  // Redraw all strokes whenever strokes or canvas size changes
  const redraw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const renderStroke = (stroke: Stroke | null | undefined) => {
      if (!stroke || !stroke.points || !Array.isArray(stroke.points) || stroke.points.length < 2) return;
      ctx.strokeStyle = stroke.color || '#facc15';
      ctx.lineWidth = stroke.size || 4;
      ctx.beginPath();
      ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
      for (let i = 1; i < stroke.points.length; i++) {
        if (stroke.points[i]) {
          ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
        }
      }
      ctx.stroke();
    };

    strokes.forEach(s => {
      if (s) renderStroke(s);
    });
    if (currentStrokeRef.current) {
      renderStroke(currentStrokeRef.current);
    }
  }, [strokes]);

  useEffect(() => {
    redraw();
  }, [redraw, width, height]);

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isActive) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;

    canvas.setPointerCapture(e.pointerId);
    setIsDrawing(true);
    currentStrokeRef.current = {
      color: currentColor,
      size: currentSize,
      points: [{ x, y }]
    };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !currentStrokeRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;

    if (currentStrokeRef.current && Array.isArray(currentStrokeRef.current.points)) {
      currentStrokeRef.current.points.push({ x, y });
      redraw();
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    setIsDrawing(false);
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch (_) {}

    const finishedStroke = currentStrokeRef.current;
    currentStrokeRef.current = null;

    if (finishedStroke && Array.isArray(finishedStroke.points) && finishedStroke.points.length > 1) {
      setStrokes(prev => [...prev.filter((s): s is Stroke => Boolean(s && s.points)), finishedStroke]);
    }
    redraw();
  };

  const clearStrokes = () => {
    setStrokes([]);
    currentStrokeRef.current = null;
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  const undoLast = () => {
    setStrokes(prev => prev.slice(0, -1));
  };

  const colors = [
    { id: '#facc15', label: 'হলুদ' },
    { id: '#06b6d4', label: 'সায়ান' },
    { id: '#f43f5e', label: 'লাল' },
    { id: '#ffffff', label: 'সাদা' },
  ];

  return (
    <>
      <canvas
        ref={canvasRef}
        width={width || 800}
        height={height || 600}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className={`absolute inset-0 w-full h-full z-20 touch-none ${
          isActive ? 'cursor-crosshair pointer-events-auto' : 'pointer-events-none'
        }`}
      />

      {/* Floating Pen Toolbar when active */}
      {isActive && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-40 bg-slate-900/95 border border-amber-500/50 px-3.5 py-2 rounded-2xl shadow-2xl backdrop-blur-md flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-1 text-amber-300 text-xs font-bold shrink-0">
            <PenTool className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">মার্কার মোড</span>
          </div>

          <div className="h-4 w-px bg-slate-700" />

          {/* Color palette */}
          <div className="flex items-center gap-1.5">
            {colors.map(c => (
              <button
                key={c.id}
                type="button"
                onClick={() => setCurrentColor(c.id)}
                className={`w-5 h-5 rounded-full border-2 transition-transform cursor-pointer ${
                  currentColor === c.id ? 'scale-125 border-white shadow-md' : 'border-transparent opacity-70 hover:opacity-100'
                }`}
                style={{ backgroundColor: c.id }}
                title={c.label}
              />
            ))}
          </div>

          <div className="h-4 w-px bg-slate-700" />

          {/* Size picker */}
          <div className="flex items-center gap-1">
            {[2, 4, 8].map(sz => (
              <button
                key={sz}
                type="button"
                onClick={() => setCurrentSize(sz)}
                className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-all ${
                  currentSize === sz
                    ? 'bg-amber-400 text-slate-950 font-black'
                    : 'text-slate-400 hover:text-white bg-slate-800'
                }`}
              >
                {sz === 2 ? 'চিকন' : sz === 4 ? 'মাঝারি' : 'মোটা'}
              </button>
            ))}
          </div>

          <div className="h-4 w-px bg-slate-700" />

          {/* Actions */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={undoLast}
              disabled={strokes.length === 0}
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 disabled:opacity-30 cursor-pointer"
              title="এক ধাপ পূর্বাবস্থায় (Undo)"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={clearStrokes}
              disabled={strokes.length === 0}
              className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 disabled:opacity-30 cursor-pointer"
              title="সব আঁকা মুছুন (Clear All)"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => onToggleActive(false)}
              className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 cursor-pointer border border-slate-700"
            >
              <Check className="w-3 h-3 text-emerald-400" />
              <span>সম্পন্ন</span>
            </button>
          </div>
        </div>
      )}
    </>
  );
}
