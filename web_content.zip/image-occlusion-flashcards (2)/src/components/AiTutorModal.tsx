import React, { useState, useEffect } from 'react';
import { X, Sparkles, Send, Loader2, Volume2, Square, Bot, HelpCircle, BookOpen, CheckCircle2, XCircle, Award, RotateCcw } from 'lucide-react';
import { Card } from '../types';
import { speakText, stopSpeech, playSoundEffect } from '../lib/speechUtils';

interface AiTutorModalProps {
  card: Card;
  isOpen: boolean;
  onClose: () => void;
}

interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export default function AiTutorModal({ card, isOpen, onClose }: AiTutorModalProps) {
  const [activeTab, setActiveTab] = useState<'explain' | 'quiz'>('explain');
  const [explanation, setExplanation] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [userQuestion, setUserQuestion] = useState<string>('');
  const [history, setHistory] = useState<{ sender: 'ai' | 'user'; text: string }[]>([]);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // AI Quiz states
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [quizLoading, setQuizLoading] = useState(false);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  useEffect(() => {
    if (isOpen && !explanation && !loading) {
      loadInitialExplanation();
    }
  }, [isOpen]);

  // Clean up audio on unmount or close
  useEffect(() => {
    return () => {
      stopSpeech();
    };
  }, []);

  const handleClose = () => {
    stopSpeech();
    setIsSpeaking(false);
    onClose();
  };

  const loadInitialExplanation = async (customPrompt?: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/explain-concept', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: card.image,
          title: card.title,
          notes: card.notes || '',
          question: customPrompt || 'এই ডায়াগ্রাম বা বিষয়টি সহজ ভাষায় এবং পরীক্ষার উপযোগী পয়েন্ট আকারে বুঝিয়ে দাও।'
        })
      });

      const data = await res.json();
      if (data.explanation) {
        setExplanation(data.explanation);
        if (customPrompt) {
          setHistory(prev => [
            ...prev,
            { sender: 'user', text: customPrompt },
            { sender: 'ai', text: data.explanation }
          ]);
        }
      } else {
        setExplanation(data.error || 'ব্যাখ্যা পাওয়া যায়নি।');
      }
    } catch (e: any) {
      setExplanation('AI টিউটরের সাথে সংযোগ স্থাপন করা সম্ভব হয়নি। দয়া করে আবার চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  const loadQuiz = async () => {
    setQuizLoading(true);
    setSelectedAnswers({});
    setQuizSubmitted(false);
    try {
      const labels = [
        ...(card.rectangles || []).map(r => r.label).filter(Boolean),
        ...(card.pins || []).map(p => p.label).filter(Boolean)
      ];

      const res = await fetch('/api/generate-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: card.image,
          title: card.title,
          notes: card.notes || '',
          labels
        })
      });

      const data = await res.json();
      if (Array.isArray(data.questions) && data.questions.length > 0) {
        setQuizQuestions(data.questions);
      }
    } catch (e) {
      console.error('Quiz fetch failed:', e);
    } finally {
      setQuizLoading(false);
    }
  };

  const handleAskQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userQuestion.trim() || loading) return;
    const q = userQuestion.trim();
    setUserQuestion('');
    loadInitialExplanation(q);
  };

  const handleToggleSpeak = (text: string) => {
    if (isSpeaking) {
      stopSpeech();
      setIsSpeaking(false);
    } else {
      setIsSpeaking(true);
      speakText(text, () => setIsSpeaking(false));
    }
  };

  const handleSelectQuizOption = (qIdx: number, optIdx: number) => {
    if (quizSubmitted) return;
    setSelectedAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
  };

  const handleSubmitQuiz = () => {
    setQuizSubmitted(true);
    let correctCount = 0;
    quizQuestions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        correctCount++;
      }
    });
    if (correctCount === quizQuestions.length) {
      playSoundEffect('complete');
    } else if (correctCount > 0) {
      playSoundEffect('correct');
    } else {
      playSoundEffect('incorrect');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 text-slate-100 rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="px-5 py-3.5 bg-gradient-to-r from-indigo-900/80 via-blue-900/70 to-slate-900 border-b border-indigo-500/30 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-300 flex items-center justify-center border border-indigo-400/30 shadow-xs">
              <Sparkles className="w-4 h-4 text-indigo-300" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white flex items-center gap-1.5">
                AI স্টাডি টিউটর
                <span className="text-[10px] uppercase tracking-wider bg-indigo-500/30 text-indigo-200 px-1.5 py-0.5 rounded font-mono font-bold">Premium</span>
              </h3>
              <p className="text-xs text-indigo-200/80 truncate max-w-[240px] sm:max-w-xs">{card.title}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {isSpeaking && (
              <button
                onClick={() => {
                  stopSpeech();
                  setIsSpeaking(false);
                }}
                className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-600 hover:bg-rose-500 text-white animate-pulse cursor-pointer shadow-xs"
                title="শব্দ এখনই থামান"
              >
                <Square className="w-3 h-3 fill-current" />
                <span>থামান</span>
              </button>
            )}
            <button
              onClick={handleClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center bg-slate-800/80 px-4 pt-2 border-b border-slate-700 text-xs font-semibold gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('explain')}
            className={`pb-2 px-3 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'explain'
                ? 'border-indigo-400 text-indigo-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            <span>বিষয় ব্যাখ্যা ও ডাউট</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('quiz');
              if (quizQuestions.length === 0 && !quizLoading) {
                loadQuiz();
              }
            }}
            className={`pb-2 px-3 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'quiz'
                ? 'border-indigo-400 text-indigo-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>AI প্র্যাকটিস কুইজ (MCQ)</span>
          </button>
        </div>

        {/* Content Body */}
        {activeTab === 'explain' ? (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm leading-relaxed">
            {/* Main Card Image Snapshot (Mini) */}
            <div className="flex items-center gap-3 p-2.5 bg-slate-800/80 rounded-xl border border-slate-700/80">
              <img src={card.image} alt={card.title} className="w-14 h-14 object-cover rounded-lg shrink-0 border border-slate-600 shadow-xs" />
              <div className="min-w-0 flex-1">
                <div className="font-semibold text-xs sm:text-sm text-slate-200 truncate">{card.title}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  {card.rectangles?.length || 0} টি মাস্ক • {card.pins?.length || 0} টি পিন
                </div>
              </div>
              {explanation && !loading && (
                <button
                  onClick={() => handleToggleSpeak(explanation)}
                  className={`p-2 rounded-lg transition-colors flex items-center gap-1 text-xs shrink-0 cursor-pointer ${
                    isSpeaking
                      ? 'bg-rose-600/30 text-rose-300 border border-rose-500/40 animate-pulse'
                      : 'bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300'
                  }`}
                  title={isSpeaking ? 'ভয়েস বন্ধ করুন' : 'ভয়েসে শুনুন'}
                >
                  {isSpeaking ? <Square className="w-4 h-4 fill-current text-rose-400" /> : <Volume2 className="w-4 h-4 text-indigo-200" />}
                  <span className="hidden sm:inline">{isSpeaking ? 'থামান' : 'শুনুন'}</span>
                </button>
              )}
            </div>

            {/* AI Explanation Text */}
            {loading && !explanation ? (
              <div className="flex flex-col items-center justify-center py-10 gap-3 text-slate-400">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-400" />
                <p className="text-xs font-medium">AI ছবিটি গভীরভাবে বিশ্লেষণ করে ব্যাখ্যা তৈরি করছে...</p>
              </div>
            ) : (
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60 space-y-3">
                <div className="flex items-center gap-2 text-indigo-400 text-xs font-semibold">
                  <Bot className="w-4 h-4" /> টিউটরের ব্যাখ্যা:
                </div>
                <div className="text-slate-200 text-xs sm:text-sm whitespace-pre-wrap leading-relaxed">
                  {explanation}
                </div>
              </div>
            )}

            {/* Follow-up Q&A conversation history */}
            {history.length > 0 && (
              <div className="space-y-3 pt-2">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5" /> ডাউট ক্লিয়ারিং আলাপ
                </div>
                {history.map((msg, i) => (
                  <div
                    key={i}
                    className={`p-3 rounded-xl text-xs sm:text-sm ${
                      msg.sender === 'user'
                        ? 'bg-blue-600/20 text-blue-200 border border-blue-500/30 ml-6'
                        : 'bg-slate-800/90 text-slate-200 border border-slate-700 mr-6'
                    }`}
                  >
                    <div className="text-[10px] font-bold opacity-60 mb-1">
                      {msg.sender === 'user' ? 'আপনার প্রশ্ন:' : 'টিউটরের উত্তর:'}
                    </div>
                    <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Quick preset question prompts */}
            <div className="pt-2">
              <div className="text-[11px] font-medium text-slate-400 mb-2 flex items-center gap-1">
                <HelpCircle className="w-3.5 h-3.5" /> দ্রুত জানতে চান?
              </div>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'সহজে মনে রাখার কোনো ছন্দ বা নেমোনিক ট্রিক দাও',
                  'পরীক্ষায় এখান থেকে কী কী প্রশ্ন আসতে পারে?',
                  'সবচেয়ে গুরুত্বপূর্ণ অংশটির কাজ কী?'
                ].map((suggestion, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => loadInitialExplanation(suggestion)}
                    disabled={loading}
                    className="text-xs px-2.5 py-1 rounded-full bg-slate-800 hover:bg-indigo-900/40 text-slate-300 hover:text-indigo-200 border border-slate-700/80 transition-all active:scale-95 disabled:opacity-50 text-left cursor-pointer"
                  >
                    💡 {suggestion}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* Quiz Tab */
          <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm leading-relaxed">
            {quizLoading ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3 text-slate-400">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-400" />
                <p className="text-xs font-medium">AI ডায়াগ্রাম বিশ্লেষণ করে ৩টি কুইজ তৈরি করছে...</p>
              </div>
            ) : quizQuestions.length === 0 ? (
              <div className="text-center py-10 space-y-3">
                <p className="text-xs text-slate-400">কোনো কুইজ লোড হয়নি। নতুন করে কুইজ তৈরি করুন।</p>
                <button
                  onClick={loadQuiz}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl cursor-pointer"
                >
                  কুইজ জেনারেট করুন
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-400 pb-1 border-b border-slate-800">
                  <span>৩টি প্রশ্নের উত্তর দিয়ে প্রস্তুতি যাচাই করুন</span>
                  <button
                    onClick={loadQuiz}
                    className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300 cursor-pointer text-[11px]"
                  >
                    <RotateCcw className="w-3 h-3" /> নতুন প্রশ্ন তৈরি করুন
                  </button>
                </div>

                {quizQuestions.map((q, qIdx) => {
                  const userChoice = selectedAnswers[qIdx];
                  const isAnswered = userChoice !== undefined;
                  const isCorrect = userChoice === q.correctIndex;

                  return (
                    <div key={qIdx} className="bg-slate-800/70 p-3.5 rounded-xl border border-slate-700 space-y-2.5">
                      <div className="font-semibold text-xs sm:text-sm text-slate-100 flex items-start gap-2">
                        <span className="bg-indigo-600/40 text-indigo-300 text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 mt-0.5">
                          #{qIdx + 1}
                        </span>
                        <span>{q.question}</span>
                      </div>

                      <div className="grid grid-cols-1 gap-1.5">
                        {q.options.map((opt, optIdx) => {
                          let optStyle = 'bg-slate-900/60 border-slate-700 hover:bg-slate-700/50 text-slate-300';
                          if (quizSubmitted) {
                            if (optIdx === q.correctIndex) {
                              optStyle = 'bg-emerald-900/40 border-emerald-500 text-emerald-200 font-semibold';
                            } else if (userChoice === optIdx) {
                              optStyle = 'bg-rose-900/40 border-rose-500 text-rose-200';
                            }
                          } else if (userChoice === optIdx) {
                            optStyle = 'bg-indigo-600/30 border-indigo-500 text-indigo-200 font-semibold';
                          }

                          return (
                            <button
                              key={optIdx}
                              onClick={() => handleSelectQuizOption(qIdx, optIdx)}
                              disabled={quizSubmitted}
                              className={`w-full text-left p-2.5 rounded-lg border text-xs transition-all flex items-center justify-between cursor-pointer ${optStyle}`}
                            >
                              <span>{opt}</span>
                              {quizSubmitted && optIdx === q.correctIndex && (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 ml-2" />
                              )}
                              {quizSubmitted && userChoice === optIdx && optIdx !== q.correctIndex && (
                                <XCircle className="w-4 h-4 text-rose-400 shrink-0 ml-2" />
                              )}
                            </button>
                          );
                        })}
                      </div>

                      {quizSubmitted && (
                        <div className="text-[11px] p-2 bg-slate-900/80 rounded-lg border border-slate-700 text-slate-300 leading-relaxed">
                          💡 <span className="font-semibold text-indigo-300">ব্যাখ্যা:</span> {q.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}

                {!quizSubmitted ? (
                  <button
                    onClick={handleSubmitQuiz}
                    disabled={Object.keys(selectedAnswers).length < quizQuestions.length}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-xl transition-all cursor-pointer shadow-md"
                  >
                    উত্তর সাবমিট করুন ({Object.keys(selectedAnswers).length}/{quizQuestions.length})
                  </button>
                ) : (
                  <div className="p-3 bg-indigo-950/40 border border-indigo-500/40 rounded-xl flex items-center justify-between text-xs text-indigo-200">
                    <div>
                      স্কোর:{' '}
                      <span className="font-bold text-white text-sm">
                        {quizQuestions.filter((q, idx) => selectedAnswers[idx] === q.correctIndex).length} / {quizQuestions.length}
                      </span>
                    </div>
                    <button
                      onClick={loadQuiz}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold cursor-pointer"
                    >
                      পুনরায় কুইজ দিন
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Question Input Footer (only for explain tab) */}
        {activeTab === 'explain' && (
          <form onSubmit={handleAskQuestion} className="p-3 bg-slate-800/90 border-t border-slate-700/80 flex items-center gap-2 shrink-0">
            <input
              type="text"
              value={userQuestion}
              onChange={(e) => setUserQuestion(e.target.value)}
              placeholder="টিউটরকে যেকোনো প্রশ্ন করুন (যেমন: এই অঙ্গের প্রধান কাজ কী?)..."
              disabled={loading}
              className="flex-1 bg-slate-900/80 border border-slate-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-200 placeholder-slate-500 outline-none transition-all disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={!userQuestion.trim() || loading}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white p-2.5 rounded-xl transition-all active:scale-95 shrink-0 flex items-center justify-center cursor-pointer"
              title="প্রশ্ন পাঠান"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </button>
          </form>
        )}

      </div>
    </div>
  );
}
