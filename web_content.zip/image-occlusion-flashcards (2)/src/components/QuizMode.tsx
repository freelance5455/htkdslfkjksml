import React, { useState, useEffect } from 'react';
import { Moon, Home, ArrowRight, CheckCircle, Eye, EyeOff, XCircle, ZoomIn, ZoomOut, Maximize, AlertCircle, Sparkles, Volume2 } from 'lucide-react';
import { Card, Rectangle, Pin } from '../types';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';
import { TagBadge } from './TagComponents';
import AiTutorModal from './AiTutorModal';
import { speakText } from '../lib/speechUtils';
import { incrementDailyStudyCount } from '../lib/goalUtils';
import { calculateSrs, SrsRating } from '../lib/srsUtils';
import {
  toggleEyeComfort,
  subscribeEyeComfort,
  isEyeComfortActive
} from '../lib/eyeComfortUtils';

interface QuizModeProps {
  cards: Card[];
  onUpdateCard: (id: number, updates: Partial<Card>) => void;
  onClose: () => void;
}

type ItemStatus = 'hidden' | 'revealed' | 'correct' | 'incorrect';

export default function QuizMode({ cards, onUpdateCard, onClose }: QuizModeProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemStates, setItemStates] = useState<Record<string, ItemStatus>>({});
  const [activeItemId, setActiveItemId] = useState<string | null>(null);
  const [eyeCare, setEyeCare] = useState<boolean>(() => isEyeComfortActive());

  useEffect(() => {
    const unsub = subscribeEyeComfort((_, active) => setEyeCare(active));
    return () => unsub();
  }, []);
  const [showNotes, setShowNotes] = useState(false);
  const [showAiTutor, setShowAiTutor] = useState(false);
  
  const [quizFinished, setQuizFinished] = useState(false);
  const [sessionStats, setSessionStats] = useState({ cardsStudied: 0 });

  const card = cards[currentIndex];

  useEffect(() => {
    if (!card) return;
    const initialStates: Record<string, ItemStatus> = {};
    card.rectangles?.forEach(r => initialStates[`rect-${r.id}`] = 'hidden');
    card.pins?.forEach(p => initialStates[`pin-${p.id}`] = 'hidden');
    
    if (!card.rectangles?.length && !card.pins?.length) {
       initialStates['card-only'] = 'revealed';
    }

    setItemStates(initialStates);
    setActiveItemId(null);
    setShowNotes(false);
  }, [card, currentIndex]);

  const toggleItem = (type: 'rect' | 'pin', id: number) => {
    const key = `${type}-${id}`;
    if (itemStates[key] === 'hidden') {
      setItemStates(prev => ({ ...prev, [key]: 'revealed' }));
      setActiveItemId(key);
    } else {
      setActiveItemId(key);
    }
  };

  const gradeActiveItem = (isCorrect: boolean) => {
    if (!activeItemId) return;
    setItemStates(prev => ({ ...prev, [activeItemId]: isCorrect ? 'correct' : 'incorrect' }));
    setActiveItemId(null);
  };

  const handleNextCard = () => {
    if (!card) return;

    let correctCount = 0;
    let totalItems = 0;
    
    Object.values(itemStates).forEach(status => {
      if (status === 'correct' || status === 'incorrect') totalItems++;
      if (status === 'correct') correctCount++;
    });

    let srsRating: SrsRating = 'good';
    if (totalItems === 0) {
      srsRating = 'good';
    } else {
      const percent = correctCount / totalItems;
      if (percent === 1) srsRating = 'easy';
      else if (percent >= 0.75) srsRating = 'good';
      else if (percent >= 0.5) srsRating = 'hard';
      else srsRating = 'again';
    }

    const srsResult = calculateSrs(
      srsRating,
      card.interval || 0,
      card.repetition || 0,
      card.easeFactor || 2.5,
      card.lapses || 0
    );

    onUpdateCard(card.id, {
      interval: srsResult.interval,
      repetition: srsResult.repetition,
      easeFactor: srsResult.easeFactor,
      nextReview: srsResult.nextReview,
      lastReviewed: srsResult.lastReviewed,
      lapses: srsResult.lapses,
    });
    setSessionStats(prev => ({ cardsStudied: prev.cardsStudied + 1 }));
    incrementDailyStudyCount(1);

    if (currentIndex < cards.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setQuizFinished(true);
    }
  };

  if (quizFinished) {
    return (
      <div className="flex flex-col h-full bg-slate-900 text-white items-center justify-center p-6">
        <div className="bg-slate-800 p-8 rounded-2xl shadow-2xl max-w-sm w-full border border-slate-700">
          <div className="flex justify-center mb-6">
            <CheckCircle className="w-20 h-20 text-green-500 animate-bounce" />
          </div>
          <h2 className="text-3xl font-bold text-center mb-2">অসাধারণ!</h2>
          <p className="text-slate-400 text-center mb-8">আজকের মতো আপনার রিভিশন সফলভাবে সম্পন্ন হয়েছে।</p>
          
          <div className="bg-slate-900 rounded-lg p-6 mb-6 text-center">
            <div className="text-4xl font-bold text-blue-500">{sessionStats.cardsStudied}</div>
            <div className="text-sm text-slate-400 uppercase tracking-wider mt-2">কার্ড রিভিশন দেওয়া হয়েছে</div>
          </div>
          
          <button 
            onClick={onClose}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold transition-colors shadow-lg active:scale-95"
          >
            ড্যাশবোর্ডে ফিরে যান
          </button>
        </div>
      </div>
    );
  }

  if (!card) return null;

  const totalItemsCount = (card.rectangles?.length || 0) + (card.pins?.length || 0);
  const gradedItemsCount = Object.values(itemStates).filter(s => s === 'correct' || s === 'incorrect').length;
  const isCardCompleted = totalItemsCount === 0 || gradedItemsCount === totalItemsCount;

  return (
    <div className="flex flex-col h-full bg-slate-900">
      {/* AI Tutor Modal */}
      <AiTutorModal
        card={card}
        isOpen={showAiTutor}
        onClose={() => setShowAiTutor(false)}
      />

      <header className="safe-top-header bg-slate-800 text-white px-4 pb-4 flex items-center justify-between shadow-md shrink-0 border-b border-slate-700">
        <button onClick={onClose} className="p-2 text-slate-300 hover:text-white rounded-full flex gap-2 items-center transition-colors">
          <Home className="w-5 h-5" /> <span className="text-sm hidden sm:inline">ড্যাশবোর্ড</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="text-sm font-medium text-slate-400">কুইজ {currentIndex + 1} / {cards.length}</div>
          <button
            onClick={() => setShowAiTutor(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-xs active:scale-95 transition-all cursor-pointer"
            title="AI টিউটরের সাহায্য নিন"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden sm:inline">AI টিউটর</span>
          </button>
        </div>

        <div className="flex gap-2 text-sm font-bold">
          <span className="text-green-500">
            {Object.values(itemStates).filter(s => s === 'correct').length}
          </span>
          <span className="text-slate-500">/</span>
          <span className="text-slate-300">{totalItemsCount}</span>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-4 overflow-hidden relative">
        <div className="flex flex-col items-center gap-1.5 mb-3 shrink-0">
          <h2 className="text-2xl font-bold text-white text-center">{card.title}</h2>
          {card.tags && card.tags.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap justify-center">
              {card.tags.map((t, idx) => (
                <TagBadge key={`${t}-${idx}`} tag={t} size="sm" />
              ))}
            </div>
          )}
        </div>
        
        <div className="flex-1 w-full relative flex items-center justify-center overflow-hidden bg-slate-800/50 rounded-xl border border-slate-700 shadow-inner">
          <TransformWrapper initialScale={1} minScale={0.5} maxScale={4} centerOnInit>
            {({ zoomIn, zoomOut, resetTransform }) => (
              <>
                <div className="absolute top-4 right-4 z-10 flex flex-col gap-2 bg-slate-800 p-2 rounded-lg shadow-lg border border-slate-600">
                  <button onClick={() => zoomIn()} className="p-2 text-white hover:bg-slate-700 rounded"><ZoomIn className="w-5 h-5" /></button>
                  <button onClick={() => zoomOut()} className="p-2 text-white hover:bg-slate-700 rounded"><ZoomOut className="w-5 h-5" /></button>
                  <button onClick={() => resetTransform()} className="p-2 text-white hover:bg-slate-700 rounded"><Maximize className="w-5 h-5" /></button>
                  <button 
                    onClick={() => {
                      const next = toggleEyeComfort();
                      setEyeCare(next);
                    }} 
                    className={`p-2 rounded transition-all active:scale-95 ${
                      eyeCare ? 'bg-amber-400 text-slate-950 font-bold shadow-md' : 'text-white hover:bg-slate-700'
                    }`} 
                    title={eyeCare ? "চোখের সুরক্ষা আলো সক্রিয় আছে (Eye Comfort ON)" : "চোখের সুরক্ষা আলো চালু করুন (Eye Comfort Shield)"}
                  >
                    <Eye className="w-5 h-5" />
                  </button>
                </div>
                <TransformComponent wrapperStyle={{ width: '100%', height: '100%' }}>
                  <div className="relative inline-block bg-white rounded shadow-2xl m-auto">
                    <img src={card.image} alt={card.title} className="max-w-full h-auto block rounded" draggable={false}  style={{ filter: eyeCare ? 'brightness(0.75) sepia(0.3) contrast(1.1)' : 'none', transition: 'filter 0.3s' }} />
                    
                    {card.rectangles?.map(rect => {
                      const key = `rect-${rect.id}`;
                      const status = itemStates[key] || 'hidden';
                      const isActive = activeItemId === key;
                      
                      let bgClass = 'bg-blue-600 border-blue-800 text-white flex items-center justify-center font-bold text-2xl shadow-md';
                      if (status === 'revealed') bgClass = 'bg-transparent border-blue-400 shadow-[0_0_15px_rgba(96,165,250,0.5)]';
                      if (status === 'correct') bgClass = 'bg-transparent border-green-500/80 shadow-[0_0_15px_rgba(34,197,94,0.3)]';
                      if (status === 'incorrect') bgClass = 'bg-transparent border-red-500/80 shadow-[0_0_15px_rgba(239,68,68,0.3)]';
                      
                      return (
                        <div
                          key={rect.id}
                          onClick={() => toggleItem('rect', rect.id)}
                          className={`absolute border-4 cursor-pointer transition-all duration-300 ${bgClass} ${isActive ? 'ring-4 ring-blue-300 ring-offset-2 ring-offset-slate-800' : ''}`}
                          style={{
                            left: rect.xPercent !== undefined ? `${rect.xPercent}%` : `${rect.x}px`,
                            top: rect.yPercent !== undefined ? `${rect.yPercent}%` : `${rect.y}px`,
                            width: rect.widthPercent !== undefined ? `${rect.widthPercent}%` : `${rect.width}px`,
                            height: rect.heightPercent !== undefined ? `${rect.heightPercent}%` : `${rect.height}px`
                          }}
                        >
                          {status === 'hidden' ? '?' : (
                            rect.label ? (
                              <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-slate-900/90 text-white font-bold text-[11px] px-2 py-0.5 rounded-md shadow-lg border border-slate-700 whitespace-nowrap z-20 pointer-events-none flex items-center gap-1 animate-in fade-in zoom-in-95">
                                <span>{rect.label}</span>
                              </div>
                            ) : null
                          )}
                        </div>
                      );
                    })}

                    {card.pins?.map(pin => {
                      const key = `pin-${pin.id}`;
                      const status = itemStates[key] || 'hidden';
                      const isActive = activeItemId === key;

                      let dotClass = 'bg-blue-600 animate-pulse';
                      if (status === 'revealed') dotClass = 'bg-blue-400';
                      if (status === 'correct') dotClass = 'bg-green-500';
                      if (status === 'incorrect') dotClass = 'bg-red-500';

                      return (
                        <div
                          key={pin.id}
                          onClick={() => toggleItem('pin', pin.id)}
                          className={`absolute z-10 flex flex-col items-center justify-center cursor-pointer -translate-x-1/2 -translate-y-[24px] ${isActive ? 'scale-110' : ''}`}
                          style={{
                            left: pin.xPercent !== undefined ? `${pin.xPercent}%` : `${pin.x}px`,
                            top: pin.yPercent !== undefined ? `${pin.yPercent}%` : `${pin.y}px`
                          }}
                        >
                          <div className={`w-6 h-6 rounded-full border-2 border-white shadow-md relative z-10 transition-colors ${dotClass}`}></div>
                          {status !== 'hidden' && (
                            <div className={`mt-1 font-bold px-3 py-1 rounded-md shadow-lg text-sm whitespace-nowrap border animate-in fade-in zoom-in duration-200 ${
                              status === 'correct' ? 'bg-green-50 text-green-900 border-green-200' :
                              status === 'incorrect' ? 'bg-red-50 text-red-900 border-red-200' :
                              'bg-white text-gray-900 border-gray-200'
                            }`}>
                              {pin.label}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </TransformComponent>
              </>
            )}
          </TransformWrapper>
        </div>

        {card.notes && (
          <div className="mt-4 w-full max-w-md bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-slate-200 shrink-0 shadow-lg text-left transition-all">
            <button 
              onClick={() => setShowNotes(!showNotes)}
              className="flex items-center justify-between w-full font-bold text-sm text-slate-400 hover:text-slate-200 transition-colors"
            >
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4" /> 
                <span>নোট/ছন্দ</span>
              </div>
              <span>{showNotes ? '▲ লুকান' : '▼ দেখুন'}</span>
            </button>
            {showNotes && (
              <p className="whitespace-pre-wrap mt-3 pt-3 border-t border-slate-700 text-sm animate-in fade-in slide-in-from-top-2">{card.notes}</p>
            )}
          </div>
        )}

      </main>

      <footer className="p-4 bg-slate-800 flex flex-col gap-4 shrink-0 border-t border-slate-700 min-h-[100px] justify-center relative">
        {activeItemId ? (
          <div className="flex flex-col gap-2 w-full max-w-md mx-auto animate-in slide-in-from-bottom-4 duration-200">
            <div className="text-center text-slate-300 font-medium mb-1">এই অংশটি কি আপনার মনে ছিল?</div>
            <div className="flex gap-4">
              <button
                onClick={() => gradeActiveItem(false)}
                className="flex-1 flex items-center justify-center gap-2 bg-slate-700 hover:bg-red-900/50 text-red-400 hover:text-red-300 border border-red-900/30 hover:border-red-500/50 px-4 py-3 rounded-xl font-bold shadow-lg transition-all active:scale-95"
              >
                <XCircle className="w-5 h-5" /> ভুলে গেছি
              </button>
              <button
                onClick={() => gradeActiveItem(true)}
                className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-3 rounded-xl font-bold shadow-lg transition-all active:scale-95"
              >
                <CheckCircle className="w-5 h-5" /> মনে ছিল
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={handleNextCard}
            className={`w-full max-w-md mx-auto flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-bold shadow-lg transition-all active:scale-95 ${
              isCardCompleted 
                ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
            }`}
          >
            {isCardCompleted ? 'পরবর্তী কার্ডে যান' : 'স্কিপ করে এগিয়ে যান'}
          </button>
        )}
      </footer>
    </div>
  );
}
