import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { Tag, Plus, X, Check, Hash } from 'lucide-react';
import { getTagColorClass, cleanTag, PRESET_TAGS, TagCount } from '../lib/tagUtils';

interface TagBadgeProps {
  tag: string;
  count?: number;
  isActive?: boolean;
  onClick?: () => void;
  onRemove?: () => void;
  size?: 'sm' | 'md';
  className?: string;
}

export const TagBadge: React.FC<TagBadgeProps> = ({
  tag,
  count,
  isActive = false,
  onClick,
  onRemove,
  size = 'md',
  className = ''
}) => {
  const colorClass = getTagColorClass(tag);
  const isSm = size === 'sm';

  return (
    <span
      onClick={onClick}
      className={`inline-flex items-center gap-1 font-medium rounded-full border transition-all select-none ${
        isSm ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs'
      } ${colorClass} ${
        onClick ? 'cursor-pointer hover:shadow-xs active:scale-95' : ''
      } ${
        isActive ? 'ring-2 ring-blue-500 ring-offset-1 dark:ring-offset-slate-900 font-bold shadow-xs' : ''
      } ${className}`}
    >
      <span className="opacity-70 text-[10px]">#</span>
      <span className="truncate max-w-[130px]">{cleanTag(tag)}</span>
      {typeof count === 'number' && (
        <span className="ml-0.5 px-1.5 py-0.2 rounded-full bg-black/10 dark:bg-white/15 text-[10px] font-bold">
          {count}
        </span>
      )}
      {onRemove && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="ml-0.5 p-0.5 hover:bg-black/15 dark:hover:bg-white/20 rounded-full transition-colors cursor-pointer"
          title="ট্যাগ মুছুন"
        >
          <X className="w-3 h-3" />
        </button>
      )}
    </span>
  );
};

interface TagFilterBarProps {
  tags: TagCount[];
  activeTag: string | null;
  onSelectTag: (tag: string | null) => void;
  totalCardsCount?: number;
}

export const TagFilterBar: React.FC<TagFilterBarProps> = ({
  tags,
  activeTag,
  onSelectTag,
  totalCardsCount
}) => {
  if (tags.length === 0) return null;

  return (
    <div className="w-full flex items-center gap-1.5 overflow-x-auto pb-1.5 pt-0.5 scrollbar-thin no-scrollbar">
      <div className="flex items-center gap-1 shrink-0 text-xs font-semibold text-gray-500 dark:text-gray-400 pl-0.5 pr-1">
        <Tag className="w-3.5 h-3.5 text-blue-500" />
        <span className="hidden sm:inline">ট্যাগ:</span>
      </div>

      {/* 'All' button */}
      <button
        type="button"
        onClick={() => onSelectTag(null)}
        className={`shrink-0 inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-full border transition-all cursor-pointer select-none ${
          activeTag === null
            ? 'bg-blue-600 border-blue-600 text-white font-bold shadow-xs'
            : 'bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700'
        }`}
      >
        <span>সব</span>
        {typeof totalCardsCount === 'number' && (
          <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
            activeTag === null ? 'bg-white/20 text-white' : 'bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-300'
          }`}>
            {totalCardsCount}
          </span>
        )}
      </button>

      {/* Individual tags */}
      {tags.map((item) => {
        const isCurrent = activeTag?.toLowerCase() === item.name.toLowerCase();
        return (
          <TagBadge
            key={item.name}
            tag={item.name}
            count={item.count}
            isActive={isCurrent}
            onClick={() => onSelectTag(isCurrent ? null : item.name)}
            size="md"
            className="shrink-0"
          />
        );
      })}

      {/* Clear filter indicator if filtered */}
      {activeTag && (
        <button
          type="button"
          onClick={() => onSelectTag(null)}
          className="shrink-0 text-xs text-blue-600 dark:text-blue-400 hover:underline px-1 py-0.5 font-medium flex items-center gap-1 cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
          <span>রিসেট</span>
        </button>
      )}
    </div>
  );
};

interface TagInputProps {
  tags: string[];
  onChange: (newTags: string[]) => void;
  existingTags?: string[];
}

export const TagInput: React.FC<TagInputProps> = ({
  tags,
  onChange,
  existingTags = []
}) => {
  const [inputValue, setInputValue] = useState('');

  const addTag = (text: string) => {
    const cleaned = cleanTag(text);
    if (!cleaned) return;
    const exists = tags.some(t => t.toLowerCase() === cleaned.toLowerCase());
    if (!exists) {
      onChange([...tags, cleaned]);
    }
    setInputValue('');
  };

  const removeTag = (indexToRemove: number) => {
    onChange(tags.filter((_, i) => i !== indexToRemove));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addTag(inputValue);
    } else if (e.key === 'Backspace' && !inputValue && tags.length > 0) {
      removeTag(tags.length - 1);
    }
  };

  // Build list of suggested tags: preset + any existing from cards, excluding currently selected
  const suggestedCandidates = Array.from(new Set([...PRESET_TAGS, ...existingTags]));
  const suggestions = suggestedCandidates.filter(
    s => !tags.some(t => t.toLowerCase() === s.toLowerCase())
  ).slice(0, 8);

  return (
    <div className="flex flex-col gap-2 p-3 bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 shadow-xs">
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
          <Tag className="w-3.5 h-3.5 text-blue-500" />
          <span>ট্যাগ বা লেবেল (Tags / Labels)</span>
        </label>
        <span className="text-[11px] text-gray-400 dark:text-gray-500">
          কমা (,) বা Enter চাপুন
        </span>
      </div>

      {/* Selected tags chip container */}
      <div className="flex flex-wrap items-center gap-1.5 min-h-[34px] p-1.5 bg-gray-50 dark:bg-slate-900/60 rounded-lg border border-gray-200 dark:border-slate-700">
        {tags.map((tag, idx) => (
          <TagBadge
            key={`${tag}-${idx}`}
            tag={tag}
            onRemove={() => removeTag(idx)}
            size="sm"
          />
        ))}

        <div className="flex-1 min-w-[140px] flex items-center gap-1">
          <Hash className="w-3.5 h-3.5 text-gray-400 shrink-0 ml-1" />
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={tags.length === 0 ? "ট্যাগ লিখুন ও Enter চাপুন (যেমন: Biology, HSC)..." : "আরেকটি ট্যাগ লিখে Enter চাপুন..."}
            className="w-full text-xs sm:text-sm bg-transparent border-none focus:outline-none text-gray-800 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500"
          />
          {inputValue.trim() && (
            <button
              type="button"
              onClick={() => addTag(inputValue)}
              title="ট্যাগ হিসেবে যোগ করুন"
              className="px-2 py-1 text-xs bg-blue-600 text-white rounded-md hover:bg-blue-700 shrink-0 font-semibold flex items-center gap-0.5"
            >
              <Plus className="w-3.5 h-3.5" /> যোগ
            </button>
          )}
        </div>
      </div>

      {/* Suggested quick pills */}
      {suggestions.length > 0 && (
        <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
          <span className="text-[11px] text-gray-400 dark:text-gray-500 shrink-0">সাজেস্টেড:</span>
          {suggestions.map((sug) => (
            <button
              key={sug}
              type="button"
              onClick={() => addTag(sug)}
              className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] rounded-full bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 hover:bg-blue-50 hover:text-blue-600 dark:hover:bg-slate-600 transition-colors border border-transparent hover:border-blue-200"
            >
              <Plus className="w-2.5 h-2.5 opacity-60" />
              <span>{sug}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

interface BulkTagModalProps {
  isOpen: boolean;
  selectedCount: number;
  existingTags: string[];
  onApply: (tag: string) => void;
  onClose: () => void;
}

export const BulkTagModal: React.FC<BulkTagModalProps> = ({
  isOpen,
  selectedCount,
  existingTags,
  onApply,
  onClose
}) => {
  const [tagInput, setTagInput] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleaned = cleanTag(tagInput);
    if (!cleaned) return;
    onApply(cleaned);
    setTagInput('');
    onClose();
  };

  const suggestions = Array.from(new Set([...PRESET_TAGS, ...existingTags])).slice(0, 10);

  if (typeof document === 'undefined') return null;

  const modalNode = (
    <div className="fixed inset-0 bg-black/75 z-[9999] backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white dark:bg-slate-800 rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-gray-100 dark:border-slate-700 animate-in fade-in zoom-in-95 duration-150" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-slate-700">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Tag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900 dark:text-gray-100 text-sm">ট্যাগ যোগ করুন</h3>
              <p className="text-[11px] text-gray-500 dark:text-gray-400">{selectedCount} টি কার্ডে ট্যাগ যুক্ত হবে</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 flex flex-col gap-3">
          <div>
            <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
              ট্যাগের নাম
            </label>
            <div className="relative">
              <Hash className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                placeholder="যেমন: Biology, History, Hard..."
                autoFocus
                className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
              />
            </div>
          </div>

          {suggestions.length > 0 && (
            <div>
              <span className="text-[11px] text-gray-500 dark:text-gray-400 font-medium">দ্রুত পছন্দ করুন:</span>
              <div className="flex flex-wrap gap-1.5 mt-1.5 max-h-24 overflow-y-auto">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      onApply(s);
                      onClose();
                    }}
                    className="px-2 py-0.5 text-xs rounded-full bg-gray-100 dark:bg-slate-700 hover:bg-blue-100 hover:text-blue-600 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200 transition-colors"
                  >
                    #{s}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="flex items-center gap-2 mt-2 pt-2 border-t border-gray-100 dark:border-slate-700">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 rounded-xl text-xs font-semibold text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={!tagInput.trim()}
              className="flex-1 py-2 rounded-xl text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 transition-colors shadow-xs"
            >
              যুক্ত করুন
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  return createPortal(modalNode, document.body);
};
