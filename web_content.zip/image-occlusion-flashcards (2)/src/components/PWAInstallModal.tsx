import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Smartphone, Download, CheckCircle2, ShieldCheck, HardDrive, Info, X, ExternalLink, RefreshCw } from 'lucide-react';
import { usePWAInstall } from '../lib/usePWAInstall';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function PWAInstallModal({ isOpen, onClose }: PWAInstallModalProps) {
  const { isInstallable, isInstalled, isIOS, install, storageInfo, refreshStorage } = usePWAInstall();
  const [installing, setInstalling] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  // Lock background scrolling while modal is open
  useEffect(() => {
    if (isOpen && typeof document !== 'undefined') {
      const origOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = origOverflow;
      };
    }
  }, [isOpen]);

  if (!isOpen || typeof document === 'undefined') return null;

  const handleInstallClick = async () => {
    setInstalling(true);
    try {
      const success = await install();
      if (success) {
        onClose();
      }
    } finally {
      setInstalling(false);
    }
  };

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  const modalNode = (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(15, 23, 42, 0.96)', // Solid deep slate (completely blocks background and prevents MIUI transparency bug)
        zIndex: 999999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
      }}
      onClick={onClose}
    >
      <div
        style={{
          position: 'relative',
          zIndex: 1000000,
          maxHeight: 'calc(100vh - 2.5rem)',
          width: '100%',
          maxWidth: '28rem',
        }}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with App Icon */}
        <div className="flex items-center gap-3.5 mb-5">
          <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 p-2.5 shadow-md flex items-center justify-center text-white shrink-0">
            <Smartphone className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-slate-900 dark:text-white leading-tight">
              {isInstalled ? 'আলাদা অ্যাপ (APK) মোড সক্রিয়' : 'ফোনে আলাদা অ্যাপ (APK) ইনস্টল'}
            </h3>
            <p className="text-xs text-blue-600 dark:text-blue-400 font-semibold mt-0.5">
              ক্রোমের সাথে সম্পর্কহীন • সম্পূর্ণ ফোনের নিজস্ব জায়গায় সেভ
            </p>
          </div>
        </div>

        {/* Main Status / Content */}
        {isInstalled ? (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div className="text-xs text-slate-700 dark:text-slate-300 space-y-1">
                <p className="font-bold text-emerald-800 dark:text-emerald-300 text-sm">
                  অ্যাপটি আপনার ফোনে ইনস্টল করা আছে!
                </p>
                <p>
                  এটি এখন আপনার ফোনের App Drawer এবং Settings &gt; Apps এ নিজস্ব জায়গা নিয়ে চলছে। ক্রোম ব্রাউজার বন্ধ বা হিস্টোরি মুছে ফেললেও আপনার কার্ডগুলো মুছে যাবে না।
                </p>
              </div>
            </div>

            {/* Storage details */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-200">
                  <HardDrive className="w-4 h-4 text-blue-500" />
                  <span>ফোনের নিজস্ব মেমোরি স্ট্যাটাস:</span>
                </div>
                <button
                  onClick={() => refreshStorage()}
                  className="text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" /> রিফ্রেশ
                </button>
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-400 space-y-1">
                <div className="flex justify-between">
                  <span>ব্যবহৃত মেমোরি:</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">
                    {storageInfo?.usageMB || '0.0'} MB
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>পার্মানেন্ট লক (Auto-delete সুরক্ষা):</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> সক্রিয়
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-sm shadow-md transition-colors"
            >
              ঠিক আছে
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Features Highlight */}
            <div className="space-y-2.5 text-xs text-slate-700 dark:text-slate-300">
              <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 dark:text-white">ক্রোম থেকে সম্পূর্ণ মুক্ত (WebAPK):</strong>
                  <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                    সাধারণ শর্টকাটের মতো কোনো ব্রাউজার বার থাকবে না। ফোনের হোমস্ক্রিন ও অ্যাপ লিস্টে নিজস্ব অ্যাপের মতো বসবে।
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <HardDrive className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 dark:text-white">ফোনের নিজস্ব স্টোরেজে সেভ:</strong>
                  <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                    ক্রোম ব্রাউজার ডিলিট বা ক্যাশ ক্লিয়ার হলেও আপনার তৈরি করা কার্ড ও ছবিগুলো ফোনের ভেতর নিরাপদ থাকবে।
                  </p>
                </div>
              </div>
            </div>

            {/* Install Action */}
            {isInstallable ? (
              <button
                onClick={handleInstallClick}
                disabled={installing}
                className="w-full py-3 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                {installing ? 'ইনস্টল হচ্ছে...' : 'এখনই ফোনে ইনস্টল করুন (Install APK)'}
              </button>
            ) : isIOS ? (
              <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-xs text-amber-900 dark:text-amber-300">
                <p className="font-bold mb-1">iPhone / iPad এ ইনস্টল করতে:</p>
                <ol className="list-decimal pl-4 space-y-1">
                  <li>Safari ব্রাউজারের নিচে <strong>Share (শেয়ার)</strong> বাটনে চাপ দিন।</li>
                  <li>নিচে স্ক্রোল করে <strong>"Add to Home Screen"</strong> এ ক্লিক করুন।</li>
                </ol>
              </div>
            ) : (
              <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 text-xs text-slate-700 dark:text-slate-300 space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-blue-900 dark:text-blue-300">
                  <Info className="w-4 h-4 text-blue-600" />
                  <span>অ্যান্ড্রয়েড ফোনে এক ক্লিকে ইনস্টল করার নিয়ম:</span>
                </div>
                <ol className="list-decimal pl-4 space-y-1.5 text-slate-600 dark:text-slate-400">
                  <li>
                    ফোনে Chrome ব্রাউজারে এই লিংকটি ওপেন করুন।
                  </li>
                  <li>
                    উপরে ডানদিকের <strong>তিনটি ডট (⋮)</strong> মেনুতে ক্লিক করুন।
                  </li>
                  <li>
                    সেখান থেকে <strong>"Install app" (অ্যাপ ইনস্টল করুন)</strong> অপশনটিতে ট্যাপ করুন (এটি কোনো শর্টকাট নয়, আসল WebAPK অ্যাপ তৈরি করবে)।
                  </li>
                </ol>

                <div className="pt-2">
                  <button
                    onClick={handleCopyUrl}
                    className="w-full py-2 px-3 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    {copySuccess ? '✓ লিংক কপি হয়েছে!' : 'অ্যাপের লিংক কপি করুন'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );

  return createPortal(modalNode, document.body);
}
