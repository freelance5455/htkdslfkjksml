import React, { useState, useEffect } from 'react';
import { Sparkles, Layers, ShieldCheck, Zap, HardDrive, CheckCircle2 } from 'lucide-react';

interface AppLaunchScreenProps {
  onFinish?: () => void;
  minDuration?: number;
}

export default function AppLaunchScreen({ onFinish, minDuration = 550 }: AppLaunchScreenProps) {
  const [progress, setProgress] = useState(25);
  const [statusText, setStatusText] = useState('স্মার্ট রিভিশন ইঞ্জিন লোড হচ্ছে...');
  const [isFadingOut, setIsFadingOut] = useState(false);

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setProgress(65);
      setStatusText('লোকাল অফলাইন ডাটাবেজ প্রস্তুত...');
    }, 150);

    const timer2 = setTimeout(() => {
      setProgress(95);
      setStatusText('ক্লাউড অটো-সিঙ্ক ও স্টোরেজ সক্রিয়...');
    }, 320);

    const timer3 = setTimeout(() => {
      setProgress(100);
      setStatusText('আপনার মেমোরি কার্ড প্রস্তুত!');
      setTimeout(() => {
        setIsFadingOut(true);
        setTimeout(() => {
          onFinish?.();
        }, 220);
      }, 120);
    }, minDuration);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [minDuration, onFinish]);

  return (
    <div
      className={`fixed inset-0 z-[200] flex flex-col items-center justify-center p-6 bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-white transition-opacity duration-300 ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Subtle Background Glows */}
      <div className="absolute w-72 h-72 rounded-full bg-blue-500/15 blur-3xl -top-10 -left-10 pointer-events-none" />
      <div className="absolute w-72 h-72 rounded-full bg-indigo-500/15 blur-3xl -bottom-10 -right-10 pointer-events-none" />

      <div className="relative flex flex-col items-center max-w-sm w-full text-center">
        {/* Animated Brand Icon */}
        <div className="relative mb-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-500 p-0.5 shadow-2xl shadow-blue-500/30 flex items-center justify-center animate-pulse">
            <div className="w-full h-full bg-slate-900/90 rounded-2xl flex items-center justify-center backdrop-blur-sm">
              <Layers className="w-10 h-10 text-blue-400" />
            </div>
          </div>
          <div className="absolute -top-1 -right-1 p-1 bg-amber-400 rounded-full shadow-lg text-slate-950">
            <Sparkles className="w-3.5 h-3.5 fill-current" />
          </div>
        </div>

        {/* Brand Name & Tagline */}
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight bg-gradient-to-r from-white via-blue-100 to-blue-300 bg-clip-text text-transparent mb-2">
          মেমোরি কার্ড স্টুডিও
        </h1>
        <p className="text-sm text-blue-200/80 mb-6 font-medium">
          অফলাইন-ফার্স্ট স্মার্ট স্পেসড রিপিটিশন ও ড্রাইভ ব্যাকআপ
        </p>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800/80 rounded-full h-1.5 p-0.5 overflow-hidden mb-3 border border-slate-700/60 shadow-inner">
          <div
            className="bg-gradient-to-r from-blue-500 via-indigo-400 to-teal-400 h-full rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Status text */}
        <p className="text-xs text-blue-300/90 font-medium tracking-wide flex items-center gap-1.5 min-h-[1.25rem]">
          <span>{statusText}</span>
        </p>

        {/* Feature Pills at Bottom */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-8 text-[11px] text-blue-200/70">
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800/60 border border-slate-700/50">
            <Zap className="w-3 h-3 text-amber-400" /> ১০০% অফলাইন
          </span>
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800/60 border border-slate-700/50">
            <HardDrive className="w-3 h-3 text-emerald-400" /> ড্রাইভ ব্যাকআপ
          </span>
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800/60 border border-slate-700/50">
            <ShieldCheck className="w-3 h-3 text-blue-400" /> সুরক্ষিত ডাটা
          </span>
        </div>
      </div>
    </div>
  );
}
