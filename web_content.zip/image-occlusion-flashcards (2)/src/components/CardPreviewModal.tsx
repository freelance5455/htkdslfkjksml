import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Star, Eye, EyeOff, BookOpen, Edit3, Tag, Calendar, Award, Sparkles, HelpCircle, ArrowRight } from 'lucide-react';
import { Card } from '../types';
import { getCardSrsBadge } from '../lib/srsUtils';
import { triggerHaptic, speakWithRepetition, getSpeechSettings } from '../lib/speechUtils';

interface CardPreviewModalProps {
  card: Card | null;
  isOpen?: boolean;
  folderName?: string;
  onClose: () => void;
  onToggleFavorite?: (cardId: number) => void;
  onStartStudy?: (card: Card) => void;
  onEdit?: (cardId: number) => void;
}

export default function CardPreviewModal({
  card,
  isOpen = true,
  folderName,
  onClose,
  onToggleFavorite,
  onStartStudy,
  onEdit,
}: CardPreviewModalProps) {
  const [showMasks, setShowMasks] = useState(true);
  const [revealedIds, setRevealedIds] = useState<number[]>([]);

  if (!isOpen || !card || typeof document === 'undefined') return null;

  const isFav = Boolean(card.favorite);
  const srsBadge = getCardSrsBadge(card);

  const toggleReveal = (id: number) => {
    triggerHaptic('light');
    setRevealedIds(prev => {
      const isCurrentlyRevealed = prev.includes(id);
      if (!isCurrentlyRevealed) {
        const rect = card.rectangles?.find(r => r.id === id);
        if (rect?.label) {
          const settings = getSpeechSettings();
          speakWithRepetition(rect.label, { count: settings.repeatCount });
        }
        return [...prev, id];
      } else {
        return prev.filter(i => i !== id);
      }
    });
  };

  const handleToggleFav = () => {
    if (onToggleFavorite) {
      onToggleFavorite(card.id);
    }
  };

  const modalNode = (
    <div className="fixed inset-0 z-[9999] bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-4xl flex flex-col max-h-[96vh] shadow-2xl overflow-hidden">
        {/* Top Header */}
        <header className="px-4 py-3 sm:px-6 sm:py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0 bg-white/95 dark:bg-slate-900/95">
          <div className="flex items-center gap-3 min-w-0">
            {/* Favorite Toggle Button */}
            <button
              onClick={handleToggleFav}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all active:scale-90 cursor-pointer shadow-xs border ${
                isFav
                  ? 'bg-amber-100 dark:bg-amber-950/70 text-amber-600 dark:text-amber-400 border-amber-300 dark:border-amber-700 ring-2 ring-amber-400/30'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:text-amber-500 hover:border-amber-200'
              }`}
              title={isFav ? 'প্রিয় তালিকা থেকে সরান' : 'প্রিয় কার্ড হিসেবে চিহ্নিত করুন'}
            >
              <Star className={`w-4 h-4 ${isFav ? 'fill-amber-400 text-amber-500' : ''}`} />
              <span>{isFav ? 'প্রিয় কার্ড (Favorite)' : 'ফেভারিট করুন'}</span>
            </button>

            <h2 className="font-bold text-slate-800 dark:text-slate-100 text-sm sm:text-base truncate">
              {card.title}
            </h2>
            {folderName && (
              <span className="hidden md:inline-flex items-center text-[11px] font-medium px-2 py-0.5 rounded-full bg-blue-50 dark:bg-slate-800 text-blue-600 dark:text-blue-300 border border-blue-200/60 dark:border-slate-700">
                {folderName}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Mask Toggle */}
            <button
              onClick={() => {
                setShowMasks(!showMasks);
                setRevealedIds([]);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 transition-all"
              title="সব মাস্ক হাইড বা শো করুন"
            >
              {showMasks ? <EyeOff className="w-4 h-4 text-blue-500" /> : <Eye className="w-4 h-4 text-slate-400" />}
              <span className="hidden sm:inline">{showMasks ? 'উত্তর দেখুন' : 'মাস্ক ঢাকুন'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 flex flex-col items-center gap-4 bg-slate-50/50 dark:bg-slate-950/50">
          {/* Card Image Display with Occlusion Overlay */}
          <div className="relative inline-block max-w-full rounded-2xl overflow-hidden shadow-md border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            <img
              src={card.image}
              alt={card.title}
              className="max-h-[55vh] w-auto max-w-full block select-none"
              draggable={false}
            />

            {/* Occlusion Rectangles */}
            {showMasks &&
              card.rectangles?.map((rect, idx) => {
                const isRevealed = revealedIds.includes(rect.id);

                return (
                  <div
                    key={rect.id}
                    onClick={() => toggleReveal(rect.id)}
                    className={`absolute flex items-center justify-center transition-all duration-200 cursor-pointer select-none ${
                      isRevealed
                        ? 'bg-transparent border-2 border-dashed border-blue-400/80 shadow-xs'
                        : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md border border-blue-400/50'
                    }`}
                    style={{
                      left: rect.xPercent !== undefined ? `${rect.xPercent}%` : `${rect.x}px`,
                      top: rect.yPercent !== undefined ? `${rect.yPercent}%` : `${rect.y}px`,
                      width: rect.widthPercent !== undefined ? `${rect.widthPercent}%` : `${rect.width}px`,
                      height: rect.heightPercent !== undefined ? `${rect.heightPercent}%` : `${rect.height}px`,
                    }}
                    title={isRevealed ? 'ক্লিক করে আবার ঢাকুন' : 'ক্লিক করে দেখুন'}
                  >
                    {!isRevealed ? (
                      <span className="font-bold text-xs tracking-wider px-1 text-white select-none">
                        ?
                      </span>
                    ) : rect.label ? (
                      <span className="bg-slate-900/90 text-amber-300 font-semibold text-[10px] px-1.5 py-0.5 rounded shadow whitespace-nowrap">
                        {rect.label}
                      </span>
                    ) : null}
                  </div>
                );
              })}

            {/* Pins */}
            {showMasks &&
              card.pins?.map((pin, idx) => (
                <div
                  key={pin.id}
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none"
                  style={{
                    left: pin.xPercent !== undefined ? `${pin.xPercent}%` : `${pin.x}px`,
                    top: pin.yPercent !== undefined ? `${pin.yPercent}%` : `${pin.y}px`,
                  }}
                >
                  <div className="w-5 h-5 rounded-full bg-red-500 text-white font-bold text-[10px] flex items-center justify-center border-2 border-white shadow-md">
                    {idx + 1}
                  </div>
                </div>
              ))}
          </div>

          <p className="text-[11px] text-slate-400 text-center">
            💡 টিপস: যেকোনো নীল বক্সে ক্লিক করলে সেটির উত্তর সাময়িকভাবে দেখা যাবে
          </p>

          {/* Metadata Card: Tags, SRS Status & Notes */}
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            {/* SRS Info Bar */}
            <div className="flex items-center justify-between flex-wrap gap-2 text-xs pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <span className={`px-2.5 py-1 rounded-full font-bold text-[11px] border ${srsBadge.badgeClass}`}>
                  {srsBadge.text}
                </span>
                <span className="text-slate-500">
                  ইন্টারভ্যাল: <strong>{card.interval || 0} দিন</strong>
                </span>
              </div>
              <div className="flex items-center gap-3 text-slate-500 text-[11px]">
                <span>রিপিট: {card.repetition || 0} বার</span>
                <span>সহজতা: {((card.easeFactor || 2.5) * 100).toFixed(0)}%</span>
              </div>
            </div>

            {/* Tags */}
            {card.tags && card.tags.length > 0 && (
              <div className="flex items-center gap-1.5 flex-wrap">
                <Tag className="w-3.5 h-3.5 text-slate-400" />
                {card.tags.map((t) => (
                  <span
                    key={t}
                    className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono text-xs"
                  >
                    #{t}
                  </span>
                ))}
              </div>
            )}

            {/* Study Notes */}
            {card.notes && (
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">
                <span className="font-bold block text-slate-500 dark:text-slate-400 text-[11px] mb-1">
                  নোট / ব্যাখ্যা:
                </span>
                {card.notes}
              </div>
            )}
          </div>
        </div>

        {/* Action Footer */}
        <footer className="px-4 py-3 sm:px-6 sm:py-3.5 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 shrink-0">
          <button
            onClick={handleToggleFav}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all active:scale-95 ${
              isFav
                ? 'text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Star className={`w-4 h-4 ${isFav ? 'fill-amber-400 text-amber-500' : ''}`} />
            <span>{isFav ? 'ফেভারিট করা আছে' : 'ফেভারিটে যোগ করুন'}</span>
          </button>

          <div className="flex items-center gap-2">
            {onEdit && (
              <button
                onClick={() => {
                  onClose();
                  onEdit(card.id);
                }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 active:scale-95 transition-all"
              >
                <Edit3 className="w-4 h-4" />
                <span>এডিট</span>
              </button>
            )}

            {onStartStudy && (
              <button
                onClick={() => {
                  onClose();
                  onStartStudy(card);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-sm shadow-blue-500/20 active:scale-95 transition-all cursor-pointer"
              >
                <BookOpen className="w-4 h-4 stroke-[2.5]" />
                <span>স্টাডি শুরু</span>
              </button>
            )}
          </div>
        </footer>
      </div>
    </div>
  );

  return createPortal(modalNode, document.body);
}
