import React, { useState, useEffect } from 'react';
import { X, Check, Sun, Contrast, RotateCcw, Sparkles, Moon, BookOpen, Sliders, Eye } from 'lucide-react';
import { enhanceImage, analyzeImageTone, loadImage } from '../lib/imageEnhance';

interface ImageEnhanceModalProps {
  isOpen: boolean;
  imageSrc: string;
  onApply: (enhancedImage: string) => void;
  onClose: () => void;
}

export default function ImageEnhanceModal({
  isOpen,
  imageSrc,
  onApply,
  onClose,
}: ImageEnhanceModalProps) {
  const [brightness, setBrightness] = useState(18);
  const [contrast, setContrast] = useState(24);
  const [invert, setInvert] = useState(false);
  const [autoLevels, setAutoLevels] = useState(true);
  const [previewSrc, setPreviewSrc] = useState<string>(imageSrc);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showOriginal, setShowOriginal] = useState(false);
  const [detectedDark, setDetectedDark] = useState(false);

  // Analyze tone on initial load
  useEffect(() => {
    if (!isOpen || !imageSrc) return;
    let isCancelled = false;

    loadImage(imageSrc)
      .then((img) => {
        if (isCancelled) return;
        const tone = analyzeImageTone(img);
        setDetectedDark(tone.isDarkInverted);
        if (tone.isDarkInverted) {
          setInvert(true);
          setBrightness(20);
          setContrast(28);
        } else {
          setInvert(false);
          setBrightness(18);
          setContrast(24);
        }
      })
      .catch(() => {});

    return () => {
      isCancelled = true;
    };
  }, [isOpen, imageSrc]);

  // Debounced live preview generation
  useEffect(() => {
    if (!isOpen || !imageSrc) return;

    let timer = setTimeout(async () => {
      setIsProcessing(true);
      try {
        const result = await enhanceImage(imageSrc, {
          brightness,
          contrast,
          invert,
          autoLevels,
          maxWidth: 1280, // responsive preview speed
        });
        setPreviewSrc(result);
      } catch (e) {
        console.error('Enhance preview error', e);
      } finally {
        setIsProcessing(false);
      }
    }, 150);

    return () => clearTimeout(timer);
  }, [brightness, contrast, invert, autoLevels, imageSrc, isOpen]);

  if (!isOpen) return null;

  const handleApply = async () => {
    setIsProcessing(true);
    try {
      // Generate full-resolution output
      const finalImage = await enhanceImage(imageSrc, {
        brightness,
        contrast,
        invert,
        autoLevels,
        maxWidth: 2048,
      });
      onApply(finalImage);
      onClose();
    } catch (e) {
      console.error(e);
      onClose();
    } finally {
      setIsProcessing(false);
    }
  };

  const applyPreset = (preset: 'auto' | 'bright' | 'scan' | 'invert' | 'reset') => {
    switch (preset) {
      case 'auto':
        setBrightness(18);
        setContrast(25);
        setInvert(false);
        setAutoLevels(true);
        break;
      case 'bright':
        setBrightness(35);
        setContrast(20);
        setInvert(false);
        setAutoLevels(true);
        break;
      case 'scan':
        setBrightness(15);
        setContrast(42);
        setInvert(false);
        setAutoLevels(true);
        break;
      case 'invert':
        setInvert(!invert);
        break;
      case 'reset':
        setBrightness(0);
        setContrast(0);
        setInvert(false);
        setAutoLevels(false);
        break;
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-2 sm:p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-3xl flex flex-col max-h-[95vh] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-4 py-3 sm:px-6 sm:py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/50 text-amber-600 flex items-center justify-center">
              <Sun className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800 dark:text-slate-100 text-sm sm:text-base">
                ছবির ব্রাইটনেস ও কনট্রাস্ট অ্যাডজাস্টমেন্ট
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                কালো বা অস্পষ্ট অংশগুলো পরিষ্কার করে পড়ার ও মাস্ক আঁকার উপযোগী করুন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notice for detected dark reader screenshots */}
        {detectedDark && (
          <div className="bg-amber-50 dark:bg-amber-950/50 border-b border-amber-200 dark:border-amber-800/60 px-4 py-2 text-xs text-amber-800 dark:text-amber-200 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Moon className="w-3.5 h-3.5 shrink-0" />
              ডার্ক/নাইট মোড স্ক্রিনশট শনাক্ত হয়েছে! স্বয়ংক্রিয়ভাবে সাদা ব্যাকগ্রাউন্ডে কনভার্ট করা হয়েছে।
            </span>
            <button
              onClick={() => setInvert(!invert)}
              className="font-bold underline text-amber-900 dark:text-amber-100 hover:opacity-80"
            >
              {invert ? 'মূল ডার্কে ফিরুন' : 'সাদা পেজে রূপান্তর করুন'}
            </button>
          </div>
        )}

        {/* Main Image Preview Stage */}
        <div className="relative flex-1 min-h-[220px] max-h-[46vh] bg-slate-100 dark:bg-slate-950 flex items-center justify-center p-3 overflow-hidden select-none">
          <img
            src={showOriginal ? imageSrc : previewSrc}
            alt="Enhancement Preview"
            className="max-h-full max-w-full object-contain rounded-lg shadow-sm"
          />

          {/* Compare Button */}
          <button
            onMouseDown={() => setShowOriginal(true)}
            onMouseUp={() => setShowOriginal(false)}
            onMouseLeave={() => setShowOriginal(false)}
            onTouchStart={() => setShowOriginal(true)}
            onTouchEnd={() => setShowOriginal(false)}
            className="absolute bottom-3 right-3 bg-black/70 hover:bg-black/85 text-white text-xs px-3 py-1.5 rounded-full font-medium flex items-center gap-1.5 backdrop-blur-xs active:scale-95 transition-all shadow-md cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{showOriginal ? 'আসল ছবি' : 'ধরে রাখুন: আসল ছবি দেখুন'}</span>
          </button>

          {isProcessing && (
            <div className="absolute top-3 left-3 bg-black/60 text-white text-[11px] px-2.5 py-1 rounded-md backdrop-blur-xs flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              <span>প্রসেসিং...</span>
            </div>
          )}
        </div>

        {/* Controls & Sliders */}
        <div className="p-4 sm:p-5 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 space-y-4">
          {/* Quick Presets */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 shrink-0 mr-1">
              প্রিসেট:
            </span>
            <button
              onClick={() => applyPreset('auto')}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-100 active:scale-95 transition-all"
            >
              <Sparkles className="w-3 h-3" />
              অটো ক্লিয়ার
            </button>
            <button
              onClick={() => applyPreset('scan')}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 active:scale-95 transition-all"
            >
              <BookOpen className="w-3 h-3" />
              বই স্ক্যান
            </button>
            <button
              onClick={() => applyPreset('bright')}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 active:scale-95 transition-all"
            >
              <Sun className="w-3 h-3" />
              উজ্জ্বল
            </button>
            <button
              onClick={() => applyPreset('invert')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border transition-all active:scale-95 ${
                invert
                  ? 'bg-purple-600 text-white border-purple-600'
                  : 'bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800 hover:bg-purple-100'
              }`}
            >
              <Moon className="w-3 h-3" />
              নাইট মোড ফিক্স
            </button>
            <button
              onClick={() => applyPreset('reset')}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 active:scale-95 transition-all"
            >
              <RotateCcw className="w-3 h-3" />
              রিসেট
            </button>
          </div>

          {/* Sliders */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            {/* Brightness Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1">
                  <Sun className="w-3.5 h-3.5 text-amber-500" /> উজ্জ্বলতা (Brightness)
                </span>
                <span className="font-mono text-slate-500">{brightness > 0 ? `+${brightness}` : brightness}%</span>
              </div>
              <input
                type="range"
                min="-30"
                max="70"
                value={brightness}
                onChange={(e) => setBrightness(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
            </div>

            {/* Contrast Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1">
                  <Contrast className="w-3.5 h-3.5 text-indigo-500" /> কনট্রাস্ট (Contrast)
                </span>
                <span className="font-mono text-slate-500">{contrast > 0 ? `+${contrast}` : contrast}%</span>
              </div>
              <input
                type="range"
                min="-20"
                max="80"
                value={contrast}
                onChange={(e) => setContrast(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-4 py-3 sm:px-6 sm:py-3.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-600 dark:text-slate-300">
            <input
              type="checkbox"
              checked={autoLevels}
              onChange={(e) => setAutoLevels(e.target.checked)}
              className="w-4 h-4 rounded text-blue-600 rounded border-slate-300 focus:ring-blue-500"
            />
            <span>স্বয়ংক্রিয় ব্যাকগ্রাউন্ড হোয়াইটনিং</span>
          </label>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl active:scale-95 transition-all"
            >
              বাতিল
            </button>
            <button
              onClick={handleApply}
              disabled={isProcessing}
              className="flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-bold bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl shadow-sm active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
            >
              <Check className="w-4 h-4 stroke-[2.5]" />
              <span>প্রয়োগ করুন</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
