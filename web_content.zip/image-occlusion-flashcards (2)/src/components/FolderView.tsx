import React, { useState, useRef, useEffect } from 'react';
import { BookOpen, Upload, Trash2, Plus, Search, Shuffle, Edit3, ArrowLeft, Folder as FolderIcon, MoreVertical, CheckSquare, X, Tag, Settings as SettingsIcon, HelpCircle, Trophy, Star, FileText, Sun, Moon, Eye } from 'lucide-react';
import { Card, Folder } from '../types';
import SyncButton from './SyncButton';
import SettingsModal from './SettingsModal';
import OcclusionHelpModal from './OcclusionHelpModal';
import CardPreviewModal from './CardPreviewModal';
import { getAllTags, cleanTag } from '../lib/tagUtils';
import { TagBadge, TagFilterBar, BulkTagModal } from './TagComponents';
import { getCardSrsBadge, sortCardsForOptimalReview, isCardDue } from '../lib/srsUtils';
import {
  toggleEyeComfort,
  subscribeEyeComfort,
  isEyeComfortActive
} from '../lib/eyeComfortUtils';

interface FolderViewProps {
  folder: Folder;
  cards: Card[];
  folders: Folder[];
  allFolders: Folder[];
  allCards?: Card[];
  darkMode?: boolean;
  toggleDarkMode?: () => void;
  onAddFolder: (name: string) => void;
  onDeleteFolder: (id: number) => void;
  onOpenFolder: (id: number) => void;
  onBack: () => void;
  onDelete: (id: number) => void;
  onDeleteMultiple?: (ids: number[], itemType?: 'card'|'folder') => void;
  onMoveMultiple?: (ids: number[], targetFolderId: number | null, itemType?: 'card'|'folder') => void;
  onRename: (id: number, title: string) => void;
  onEdit: (id: number) => void;
  onStartStudy: (index: number, shuffled?: boolean, studyCards?: Card[]) => void;
  onStartQuiz: (studyCards?: Card[]) => void;
  onCreateNew: () => void;
  onMoveItem?: (itemId: number, targetFolderId: number | null, itemType: 'card' | 'folder') => void;
  onBulkCreate?: (cards: Card[]) => void;
  onStartBulkEdit?: (cards: Card[]) => void;
  onImport?: (data: { cards: Card[]; folders: Folder[] }) => void;
  onSyncDataLoaded?: (data: { cards: Card[]; folders: Folder[] }) => void;
  onAddTagToCards?: (cardIds: number[], tag: string) => void;
  onToggleFavorite?: (cardId: number) => void;
}

export default function FolderView({ folder, cards, folders, allFolders, allCards, darkMode, toggleDarkMode, onAddFolder, onDeleteFolder, onOpenFolder, onBack, onDelete, onDeleteMultiple, onMoveMultiple, onRename, onEdit, onStartStudy, onStartQuiz, onCreateNew, onMoveItem, onBulkCreate, onStartBulkEdit, onImport, onSyncDataLoaded, onAddTagToCards, onToggleFavorite }: FolderViewProps) {
  const [search, setSearch] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [showBulkTagModal, setShowBulkTagModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [previewCard, setPreviewCard] = useState<Card | null>(null);
  const bulkFileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ current: number; total: number } | null>(null);
  const [bulkPendingCards, setBulkPendingCards] = useState<Card[]>([]);
  const [alertMsg, setAlertMsg] = useState('');
  const [isEyeComfort, setIsEyeComfort] = useState<boolean>(() => isEyeComfortActive());

  useEffect(() => {
    const unsub = subscribeEyeComfort((_, active) => setIsEyeComfort(active));
    return () => unsub();
  }, []);
  
  const handleBulkUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;
    setIsUploading(true);
    setUploadProgress({ current: 0, total: files.length });
    const newCards: Card[] = [];
    let failedCount = 0;
    const { compressImage } = await import('../lib/imageUtils');
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setUploadProgress({ current: i + 1, total: files.length });
      
      const isImg = file.type.startsWith('image/') || 
                    /\.(jpe?g|png|webp|bmp|gif|heic|heif)$/i.test(file.name) ||
                    file.type === '';
      if (!isImg) {
        continue;
      }
      try {
         const compressedBase64 = await compressImage(file, 2048, 0.85);
         newCards.push({
            id: Date.now() + Math.floor(Math.random() * 1000000) + i,
            title: file.name.replace(/\.[^/.]+$/, "") || `কার্ড ${newCards.length + 1}`,
            image: compressedBase64,
            rectangles: [],
            pins: [],
            createdAt: Date.now(),
            folderId: folder.id
         });
      } catch (err) { 
        console.error("Error compressing", err);
        failedCount++;
      }
    }
    
    setUploadProgress(null);
    setIsUploading(false);
    if (bulkFileInputRef.current) bulkFileInputRef.current.value = '';

    if (newCards.length > 0) {
      setBulkPendingCards(newCards);
      if (failedCount > 0) {
        setAlertMsg(`${failedCount} টি ছবি প্রসেস করা যায়নি, বাকি ${newCards.length} টি ছবি প্রস্তুত।`);
      }
    } else if (failedCount > 0) {
      setAlertMsg(`${failedCount} টি ছবি প্রসেস করতে সমস্যা হয়েছে, অন্য ছবি দিয়ে চেষ্টা করুন।`);
    }
  };

  
  // Modal states
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);
  const [deleteType, setDeleteType] = useState<'card'|'folder'>('card');
  const [moveItemData, setMoveItemData] = useState<{id: number, type: 'card'|'folder'} | null>(null);
  const [renameData, setRenameData] = useState<{id: number, title: string} | null>(null);
  const [renameInput, setRenameInput] = useState('');

  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [selectedFolders, setSelectedFolders] = useState<number[]>([]);
  const [isSelectionMode, setIsSelectionMode] = useState(false);

  const [showMenu, setShowMenu] = useState(false);
  const pressTimer = useRef<NodeJS.Timeout | null>(null);

  const startPress = (id: number, type: 'card'|'folder') => {
    if (isSelectionMode) return;
    pressTimer.current = setTimeout(() => {
      setIsSelectionMode(true);
      if (type === 'card') toggleSelectCard(id);
      else toggleSelectFolder(id);
    }, 500);
  };

  const cancelPress = () => {
    if (pressTimer.current) {
      clearTimeout(pressTimer.current);
      pressTimer.current = null;
    }
  };

  const selectAll = () => {
    setSelectedCards(filteredCards.map(c => c.id));
    setSelectedFolders(filteredFolders.map(f => f.id));
    setShowMenu(false);
  };


  const toggleSelectCard = (id: number) => {
    setSelectedCards(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };
  
  const toggleSelectFolder = (id: number) => {
    setSelectedFolders(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const cancelSelection = () => {
    setSelectedCards([]);
    setSelectedFolders([]);
    setIsSelectionMode(false);
  };

  const [showFolderModal, setShowFolderModal] = useState(false);
  const [folderName, setFolderName] = useState('');
  const [dragOverFolderId, setDragOverFolderId] = useState<number | null>(null);

  const isSearching = search.trim().length > 0;
  const searchLower = search.toLowerCase().trim();
  const folderAvailableTags = getAllTags(cards);
  const hasTagFilter = Boolean(selectedTag);

  const filteredCards = cards.filter(c => {
    if (selectedTag) {
      const matchTag = Array.isArray(c.tags) && c.tags.some(t => cleanTag(t).toLowerCase() === selectedTag.toLowerCase());
      if (!matchTag) return false;
    }
    if (isSearching) {
      const matchTitle = c.title.toLowerCase().includes(searchLower);
      const matchTag = Array.isArray(c.tags) && c.tags.some(t => t.toLowerCase().includes(searchLower));
      if (!matchTitle && !matchTag) return false;
    }
    return true;
  });

  const filteredFolders = hasTagFilter
    ? []
    : isSearching
      ? folders.filter(f => f.name.toLowerCase().includes(searchLower))
      : folders;

  const handleRenameClick = (card: Card) => {
    setRenameData({ id: card.id, title: card.title });
    setRenameInput(card.title);
  };

  const confirmRename = () => {
    if (renameData && renameInput.trim() !== '') {
      onRename(renameData.id, renameInput.trim());
    }
    setRenameData(null);
  };

  const handleCreateFolder = () => {
    if (folderName.trim()) {
      onAddFolder(folderName.trim());
      setShowFolderModal(false);
      setFolderName('');
    }
  };

  const handleDragStart = (e: React.DragEvent, id: number, type: 'folder' | 'card') => {
    e.dataTransfer.setData('itemId', id.toString());
    e.dataTransfer.setData('itemType', type);
  };

  const handleDragOver = (e: React.DragEvent, folderId: number) => {
    e.preventDefault();
    setDragOverFolderId(folderId);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOverFolderId(null);
  };

  const handleDrop = (e: React.DragEvent, targetFolderId: number) => {
    e.preventDefault();
    setDragOverFolderId(null);
    const itemId = parseInt(e.dataTransfer.getData('itemId'));
    const itemType = e.dataTransfer.getData('itemType') as 'folder' | 'card';
    if (!itemId || !itemType) return;
    
    if (onMoveItem) {
      onMoveItem(itemId, targetFolderId, itemType);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto pb-24">
      {/* Delete Confirm Modal */}
      {deleteConfirmId !== null && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-2">নিশ্চিত করুন</h3>
            <p className="text-gray-600 mb-6">আপনি কি নিশ্চিত যে {deleteConfirmId === -1 ? `নির্বাচিত ${selectedFolders.length} টি ফোল্ডার এবং ${selectedCards.length} টি কার্ড` : `এই ${deleteType === 'folder' ? 'ফোল্ডার এবং এর সব কার্ড' : 'কার্ডটি'}`} ডিলিট করতে চান?</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirmId(null)} className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-2 rounded-lg font-medium hover:bg-gray-200 dark:hover:bg-slate-600 transition-colors">না, বাতিল</button>
              <button onClick={() => { 
                if (deleteConfirmId === -1 && onDeleteMultiple) {
                  if (selectedFolders.length > 0) onDeleteMultiple(selectedFolders, 'folder');
                  if (selectedCards.length > 0) onDeleteMultiple(selectedCards, 'card');
                  cancelSelection();
                } else {
                  if (deleteType === 'folder') onDeleteFolder(deleteConfirmId);
                  else onDelete(deleteConfirmId);
                } 
                setDeleteConfirmId(null); 
              }} className="flex-1 bg-red-500 text-white py-2 rounded-lg font-medium">হ্যাঁ, ডিলিট</button>
            </div>
          </div>
        </div>
      )}

      {/* Move Modal */}
      {moveItemData !== null && onMoveItem && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-gray-100">কোথায় মুভ করবেন?</h3>
            <div className="flex flex-col gap-2 max-h-60 overflow-y-auto mb-4">
              <button
                onClick={() => {
                  if (moveItemData.id === -1 && onMoveMultiple) {
                    if (selectedFolders.length > 0) onMoveMultiple(selectedFolders, null, 'folder');
                    if (selectedCards.length > 0) onMoveMultiple(selectedCards, null, 'card');
                    cancelSelection();
                  } else if (onMoveItem) {
                    onMoveItem(moveItemData.id, null, moveItemData.type);
                  }
                  setMoveItemData(null);
                }}
                className="p-3 text-left bg-gray-50 hover:bg-gray-100 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-lg flex items-center gap-3 transition-colors"
              >
                <FolderIcon className="w-5 h-5 text-gray-400" />
                <span className="font-medium text-gray-800 dark:text-gray-200">মূল পাতা (Root)</span>
              </button>
              {allFolders.filter(f => f.id !== (moveItemData.type === 'folder' ? moveItemData.id : -1) && f.id !== folder.id).map(f => (
                <button
                  key={f.id}
                  onClick={() => {
                    if (moveItemData.id === -1 && onMoveMultiple) {
                      if (selectedFolders.length > 0) onMoveMultiple(selectedFolders, f.id, 'folder');
                      if (selectedCards.length > 0) onMoveMultiple(selectedCards, f.id, 'card');
                      cancelSelection();
                    } else if (onMoveItem) {
                      onMoveItem(moveItemData.id, f.id, moveItemData.type);
                    }
                    setMoveItemData(null);
                  }}
                  className="p-3 text-left bg-gray-50 hover:bg-gray-100 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-lg flex items-center gap-3 transition-colors"
                >
                  <FolderIcon className="w-5 h-5 text-amber-500" />
                  <span className="font-medium text-gray-800 dark:text-gray-200">{f.name}</span>
                </button>
              ))}
            </div>
            <button onClick={() => setMoveItemData(null)} className="w-full bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-2 rounded-lg font-medium">বাতিল</button>
          </div>
        </div>
      )}

      {/* Rename Modal */}
      {renameData && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100">কার্ডের নাম পরিবর্তন</h3>
            <input 
              type="text" 
              value={renameInput}
              onChange={(e) => setRenameInput(e.target.value)}
              className="w-full border border-gray-300 dark:border-slate-600 rounded-lg p-3 mb-6 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-gray-100"
              autoFocus
            />
            <div className="flex gap-3">
              <button onClick={() => setRenameData(null)} className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-2 rounded-lg font-medium hover:bg-gray-200 dark:hover:bg-slate-600 transition-colors">বাতিল</button>
              <button onClick={confirmRename} className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-medium">সেভ করুন</button>
            </div>
          </div>
        </div>
      )}

            {/* Upload Progress Modal */}
      {uploadProgress && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-2xl text-center">
            <div className="animate-spin text-3xl mb-3">⏳</div>
            <h3 className="text-lg font-bold dark:text-white mb-2">ছবি প্রসেস হচ্ছে...</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
              {uploadProgress.current} / {uploadProgress.total} টি ছবি তৈরি হচ্ছে
            </p>
            <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-3 overflow-hidden">
              <div 
                className="bg-green-500 h-full transition-all duration-300"
                style={{ width: `${Math.round((uploadProgress.current / uploadProgress.total) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Bulk Upload Confirmation Modal */}
      {bulkPendingCards.length > 0 && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-gray-100">সফলভাবে প্রসেস হয়েছে</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">আপনি {bulkPendingCards.length} টি ছবি নির্বাচন করেছেন। এখন কি করবেন?</p>
            <div className="flex flex-col gap-3">
              <button 
                onClick={() => {
                   if (onBulkCreate) onBulkCreate(bulkPendingCards);
                   setAlertMsg(`${bulkPendingCards.length} টি কার্ড এই ফোল্ডারে সেভ হয়েছে!`);
                   setBulkPendingCards([]);
                }} 
                className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-medium shadow-sm transition-colors"
              >
                সরাসরি সেভ করুন (পরে মাস্ক করবেন)
              </button>
              <button 
                onClick={() => {
                   if (onStartBulkEdit) onStartBulkEdit(bulkPendingCards);
                   setBulkPendingCards([]);
                }} 
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-medium shadow-sm transition-colors"
              >
                এখনি মাস্ক তৈরি করুন (একটার পর একটা)
              </button>
              <button 
                onClick={() => setBulkPendingCards([])} 
                className="w-full bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200 py-3 rounded-lg font-medium transition-colors mt-2"
              >
                বাতিল করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Global Alert */}
      {alertMsg && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-6 py-3 rounded-xl shadow-lg z-50 flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
          <span>{alertMsg}</span>
          <button onClick={() => setAlertMsg('')} className="p-1 hover:bg-blue-700 rounded-full"><X className="w-4 h-4" /></button>
        </div>
      )}
      
      <input 
        type="file" 
        ref={bulkFileInputRef} 
        onChange={handleBulkUpload} 
        accept="image/*,.heic,.heif,.jpg,.jpeg,.png,.webp,.bmp" 
        multiple 
        className="hidden" 
      />

      {/* Create Folder Modal */}
      {showFolderModal && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100">নতুন ফোল্ডার</h3>
            <input 
              type="text" 
              value={folderName}
              onChange={(e) => setFolderName(e.target.value)}
              placeholder="ফোল্ডারের নাম..."
              className="w-full border border-gray-300 dark:border-slate-600 rounded-lg p-3 mb-6 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-gray-100"
              autoFocus
            />
            <div className="flex gap-3">
              <button onClick={() => setShowFolderModal(false)} className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-2 rounded-lg font-medium hover:bg-gray-200 dark:hover:bg-slate-600 transition-colors">বাতিল</button>
              <button onClick={handleCreateFolder} className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-medium">তৈরি করুন</button>
            </div>
          </div>
        </div>
      )}

      {isSelectionMode ? (
        <header className="safe-top-header bg-blue-600 dark:bg-blue-800 text-white px-4 pb-4 shadow-md rounded-b-2xl mb-6 shrink-0 flex items-center justify-between relative z-20">
          <div className="flex items-center gap-3">
            <button onClick={cancelSelection} className="p-2 hover:bg-blue-700 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <span className="text-xl font-bold">{selectedCards.length + selectedFolders.length} সিলেক্টেড</span>
          </div>
          <div className="relative flex items-center gap-2">
            {selectedCards.length > 0 && (
              <button
                onClick={() => setShowBulkTagModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-semibold transition-colors"
                title="সিলেক্ট করা কার্ডগুলোতে ট্যাগ দিন"
              >
                <Tag className="w-4 h-4" />
                <span className="hidden sm:inline">ট্যাগ দিন</span>
              </button>
            )}
            <SyncButton cards={allCards} folders={allFolders} onDataLoaded={onSyncDataLoaded || onImport} setAlert={setAlertMsg} />
            <button onClick={() => setShowMenu(!showMenu)} className="p-2 hover:bg-blue-700 rounded-full transition-colors">
              <MoreVertical className="w-6 h-6" />
            </button>
            {showMenu && (
              <div className="absolute right-0 mt-2 top-full w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl py-2 text-gray-800 dark:text-gray-200 z-50 border border-gray-100 dark:border-slate-700">
                <button onClick={selectAll} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left font-medium">
                  <CheckSquare className="w-5 h-5" /> সব সিলেক্ট করুন
                </button>
                {selectedCards.length > 0 && (
                  <button onClick={() => {
                    setShowMenu(false);
                    setShowBulkTagModal(true);
                  }} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left font-medium text-blue-600 dark:text-blue-400">
                    <Tag className="w-5 h-5" /> ট্যাগ যোগ করুন
                  </button>
                )}
                <button onClick={() => {
                  setShowMenu(false);
                  if (selectedCards.length > 0 || selectedFolders.length > 0) setMoveItemData({ id: -1, type: 'card' });
                }} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left font-medium">
                  <FolderIcon className="w-5 h-5" /> মুভ করুন
                </button>
                <button onClick={() => {
                  setShowMenu(false);
                  if (selectedCards.length > 0 || selectedFolders.length > 0) {
                    setDeleteType('card');
                    setDeleteConfirmId(-1);
                  }
                }} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-red-50 dark:hover:bg-red-900/30 text-red-500 transition-colors text-left font-medium">
                  <Trash2 className="w-5 h-5" /> ডিলিট করুন
                </button>
              </div>
            )}
          </div>
        </header>
      ) : (
        <header className="safe-top-header bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 dark:from-slate-900 dark:via-blue-950 dark:to-indigo-950 text-white px-4 pb-5 sm:px-6 sm:pb-6 shadow-xl rounded-b-3xl mb-4 shrink-0 flex items-center justify-between gap-2 relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-44 h-44 bg-blue-400/15 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center gap-2.5 min-w-0 relative z-10">
            <button onClick={onBack} className="p-2 hover:bg-white/10 dark:hover:bg-slate-800/80 active:scale-90 rounded-full transition-all shrink-0" title="ফিরে যান">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div className="min-w-0">
              <h1 className="text-lg sm:text-xl font-extrabold truncate max-w-[160px] xs:max-w-[220px] sm:max-w-md">{folder.name}</h1>
              <p className="text-blue-100 dark:text-blue-200 text-xs mt-0.5 font-medium">{folders.length} সাবফোল্ডার, {cards.length} কার্ড</p>
            </div>
          </div>
          <div className="flex items-center gap-1 sm:gap-2 shrink-0 relative z-10">
            <SyncButton cards={allCards} folders={allFolders} onDataLoaded={onSyncDataLoaded || onImport} setAlert={setAlertMsg} />
            {toggleDarkMode && (
              <button 
                onClick={toggleDarkMode} 
                title="ডার্ক মোড টগল করুন" 
                className="p-2 hover:bg-white/10 dark:hover:bg-slate-800/80 active:scale-90 rounded-full transition-all text-sm font-medium"
              >
                {darkMode ? <Sun className="w-5 h-5 text-amber-300" /> : <Moon className="w-5 h-5 text-blue-100" />}
              </button>
            )}
            <button 
              onClick={() => {
                const next = toggleEyeComfort();
                setIsEyeComfort(next);
                setAlertMsg(next ? 'চোখের সুরক্ষা আলো সক্রিয় হয়েছে (Eye Comfort ON) 🛡️' : 'চোখের সুরক্ষা আলো বন্ধ করা হয়েছে');
              }} 
              title={isEyeComfort ? "চোখের সুরক্ষা আলো সক্রিয় আছে (Eye Comfort ON) - বন্ধ করতে ক্লিক করুন" : "চোখের সুরক্ষা আলো চালু করুন (Eye Comfort Shield / Night Light)"} 
              className={`p-2 rounded-full transition-all active:scale-90 flex items-center gap-1 cursor-pointer ${
                isEyeComfort
                  ? 'bg-amber-400 text-slate-900 shadow-md ring-2 ring-amber-300'
                  : 'hover:bg-white/10 dark:hover:bg-slate-800/80 text-blue-100 hover:text-white'
              }`}
            >
              <Eye className="w-5 h-5" />
            </button>
            <button
              onClick={() => setShowHelpModal(true)}
              title="ইমেজ অক্লুশন নির্দেশিকা ও ডেমো (Help Guide)"
              className="p-2 hover:bg-white/10 dark:hover:bg-slate-800/80 active:scale-90 rounded-full transition-all text-sm font-medium"
            >
              <HelpCircle className="w-5 h-5 text-blue-100 hover:text-white" />
            </button>
            <button
              onClick={() => setShowSettingsModal(true)}
              title="অ্যাপ সেটিংস ও ব্যাকআপ (Settings)"
              className="p-2 hover:bg-white/10 dark:hover:bg-slate-800/80 active:scale-90 rounded-full transition-all text-sm font-medium"
            >
              <SettingsIcon className="w-5 h-5" />
            </button>
          </div>
        </header>
      )}

      <main className="flex-1 max-w-3xl w-full mx-auto px-4 pt-1 pb-32 flex flex-col gap-4">
        
        {(cards.length > 0 || folders.length > 0) && (
          <div className="flex flex-col gap-2 mb-2">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500 w-5 h-5 pointer-events-none" />
                <input 
                  type="text" 
                  placeholder={`${folder.name}-এ কার্ডের শিরোনাম দিয়ে খুঁজুন... (Filter by title)`}
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-11 pr-10 py-3 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm transition-all text-sm sm:text-base"
                />
                {search && (
                  <button
                    onClick={() => setSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-full transition-colors cursor-pointer"
                    title="সার্চ মুছুন"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              {filteredCards.length > 0 && (
                <div className="flex gap-2">
                  <button 
                    onClick={() => onStartStudy(0, true, (isSearching || hasTagFilter) ? filteredCards : undefined)}
                    className="flex items-center justify-center gap-2 bg-purple-100 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 hover:bg-purple-200 dark:hover:bg-purple-900/50 px-4 py-3 rounded-xl font-semibold transition-colors whitespace-nowrap"
                  >
                    <Shuffle className="w-5 h-5" /> শাফেল
                  </button>
                  <button 
                    onClick={() => onStartQuiz((isSearching || hasTagFilter) ? filteredCards : undefined)}
                    className="flex items-center justify-center gap-2 bg-indigo-100 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-200 dark:hover:bg-indigo-900/50 px-4 py-3 rounded-xl font-semibold transition-colors whitespace-nowrap"
                  >
                    <BookOpen className="w-5 h-5" /> কুইজ
                  </button>
                </div>
              )}
            </div>

            <TagFilterBar
              tags={folderAvailableTags}
              activeTag={selectedTag}
              onSelectTag={setSelectedTag}
              totalCardsCount={cards.length}
            />

            {selectedTag && (
              <div className="flex items-center justify-between px-3 py-2 bg-blue-50 dark:bg-slate-800/80 rounded-xl border border-blue-200 dark:border-slate-700 text-xs text-blue-900 dark:text-blue-200 shadow-xs">
                <div className="flex items-center gap-2">
                  <Tag className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0" />
                  <span>
                    ট্যাগ <strong>#{selectedTag}</strong> অনুযায়ী এই ফোল্ডারে <strong>{filteredCards.length}</strong> টি কার্ড পাওয়া গেছে
                  </span>
                </div>
                <button
                  onClick={() => setSelectedTag(null)}
                  className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-semibold cursor-pointer shrink-0"
                >
                  সব দেখুন
                </button>
              </div>
            )}

            {isSearching && (
              <div className="flex items-center justify-between px-1 text-xs text-gray-600 dark:text-gray-400">
                <span>
                  <strong>"{search}"</strong> এর জন্য <strong>{filteredCards.length}</strong> টি কার্ড {filteredFolders.length > 0 ? `ও ${filteredFolders.length} টি ফোল্ডার` : ''} পাওয়া গেছে
                </span>
                <button
                  onClick={() => setSearch('')}
                  className="text-blue-600 dark:text-blue-400 hover:underline font-medium cursor-pointer"
                >
                  সার্চ ক্লিয়ার করুন
                </button>
              </div>
            )}
          </div>
        )}

        {cards.length === 0 && folders.length === 0 ? (
          <div className="flex flex-col items-center justify-center flex-1 text-gray-400 opacity-70 mt-10">
            <BookOpen className="w-16 h-16 mb-4" />
            <p className="text-lg">ফোল্ডারে কিছু নেই!</p>
            <p className="text-sm text-center">নতুন তৈরি করতে নিচের বাটনে ক্লিক করুন।</p>
          </div>
        ) : filteredCards.length === 0 && filteredFolders.length === 0 ? (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            <Search className="w-12 h-12 mx-auto mb-3 opacity-30 text-gray-400" />
            <p className="text-base font-semibold text-gray-700 dark:text-gray-200">
              "{search}" শিরোনামের কোনো কার্ড বা ফোল্ডার পাওয়া যায়নি!
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              বানান সঠিক আছে কিনা দেখুন অথবা অন্য কোনো শব্দ দিয়ে অনুসন্ধান করুন।
            </p>
            <button
              onClick={() => setSearch('')}
              className="mt-4 px-4 py-2 text-xs font-semibold bg-blue-50 dark:bg-slate-800 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-100 dark:hover:bg-slate-700 transition-colors cursor-pointer"
            >
              সব কার্ড দেখুন
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Folders */}
            {filteredFolders.map((subfolder) => {
              const count = allFolders.filter(c => c.parentId === subfolder.id).length;
              const isDragOver = dragOverFolderId === subfolder.id;
              return (
                <div 
                  key={subfolder.id} 
                  onClick={() => { if(isSelectionMode) toggleSelectFolder(subfolder.id); else onOpenFolder(subfolder.id); }} 
                  onPointerDown={(e) => {
                     if (e.button !== 0) return;
                     startPress(subfolder.id, 'folder');
                  }}
                  onPointerUp={cancelPress}
                  onPointerLeave={cancelPress}
                  onPointerCancel={cancelPress}
                  onContextMenu={(e) => {
                     // e.preventDefault();
                  }}
                  className={`bg-white dark:bg-slate-800 p-3.5 sm:p-4 rounded-2xl shadow-xs hover:shadow-md border flex items-center justify-between cursor-pointer active:scale-[0.99] transition-all duration-150 group ${isSelectionMode && selectedFolders.includes(subfolder.id) ? 'border-blue-500 bg-blue-50/60 dark:bg-blue-950/40 ring-2 ring-blue-400' : isDragOver ? 'border-blue-500 ring-2 ring-blue-200' : 'border-slate-100 dark:border-slate-700/80'}`}
                  draggable={!isSelectionMode}
                  onDragStart={(e) => handleDragStart(e, subfolder.id, 'folder')}
                  onDragOver={(e) => handleDragOver(e, subfolder.id)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, subfolder.id)}
                >
                  <div className="flex items-center gap-3.5 overflow-hidden w-full pr-2">
                    {isSelectionMode && (
                      <input type="checkbox" checked={selectedFolders.includes(subfolder.id)} onChange={() => toggleSelectFolder(subfolder.id)} className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500" onClick={e => e.stopPropagation()} />
                    )}

                    <div className="w-12 h-12 bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center flex-shrink-0 shadow-xs border border-amber-200/50 dark:border-amber-700/30">
                      <FolderIcon className="w-6 h-6" fill="currentColor" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-800 dark:text-gray-100 line-clamp-2 break-words text-sm sm:text-base">{subfolder.name}</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">সাবফোল্ডার</p>
                    </div>
                  </div>
                  <div className="relative shrink-0 flex items-center">
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveDropdown(activeDropdown === `folder-${subfolder.id}` ? null : `folder-${subfolder.id}`); }}
                      className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center bg-gray-50 dark:bg-slate-700/70 text-gray-600 dark:text-gray-300 rounded-xl hover:bg-gray-100 dark:hover:bg-slate-600 active:scale-95 transition-all"
                    >
                      <MoreVertical className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    {activeDropdown === `folder-${subfolder.id}` && (
                      <div className="absolute right-0 top-12 w-40 bg-white dark:bg-slate-800 rounded-xl shadow-xl py-2 text-gray-800 dark:text-gray-200 z-50 border border-gray-100 dark:border-slate-700">
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setMoveItemData({ id: subfolder.id, type: 'folder' }); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <FolderIcon className="w-4 h-4" /> মুভ করুন
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setDeleteType('folder'); setDeleteConfirmId(subfolder.id); }} className="w-full px-4 py-2 text-left text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 flex items-center gap-2 font-medium">
                           <Trash2 className="w-4 h-4" /> ডিলিট করুন
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Cards */}
            {filteredCards.map((card) => {
              const originalIndex = cards.findIndex(c => c.id === card.id);
              const studyIndex = (isSearching || hasTagFilter) ? filteredCards.findIndex(c => c.id === card.id) : originalIndex;
              return (
                <div 
                  key={card.id} 
                  onClick={() => { if(isSelectionMode) toggleSelectCard(card.id); }}
                  onPointerDown={(e) => {
                     if (e.button !== 0) return;
                     startPress(card.id, 'card');
                  }}
                  onPointerUp={cancelPress}
                  onPointerLeave={cancelPress}
                  onPointerCancel={cancelPress}
                  onContextMenu={(e) => {
                     // e.preventDefault();
                  }}
                  className={`bg-white dark:bg-slate-800 p-3.5 sm:p-4 rounded-2xl shadow-xs hover:shadow-md border flex items-center justify-between group cursor-pointer active:scale-[0.99] transition-all duration-150 ${isSelectionMode && selectedCards.includes(card.id) ? 'border-blue-500 bg-blue-50/60 dark:bg-blue-950/40 ring-2 ring-blue-400' : 'border-slate-100 dark:border-slate-700/80'}`}
                  draggable={!isSelectionMode}
                  onDragStart={(e) => handleDragStart(e, card.id, 'card')}
                >
                  <div className="flex items-center gap-3.5 overflow-hidden w-full pr-2">
                    {isSelectionMode && (
                      <input type="checkbox" checked={selectedCards.includes(card.id)} onChange={() => toggleSelectCard(card.id)} className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500" onClick={e => e.stopPropagation()} />
                    )}

                    <div 
                      onClick={(e) => {
                        e.stopPropagation();
                        setPreviewCard(card);
                      }}
                      className="w-16 h-16 sm:w-18 sm:h-18 bg-slate-100 dark:bg-slate-700 rounded-xl overflow-hidden flex-shrink-0 border border-slate-200/80 dark:border-slate-700 shadow-xs relative cursor-pointer group/thumb hover:border-blue-400 dark:hover:border-blue-500 transition-colors"
                      title="কার্ড প্রিভিউ দেখতে ক্লিক করুন"
                    >
                      <img src={card.image} alt={card.title} className="w-full h-full object-cover group-hover/thumb:scale-105 transition-transform" />
                      {card.favorite && (
                        <div className="absolute top-1 right-1 bg-amber-500 text-slate-950 p-0.5 rounded-full shadow-xs" title="প্রিয় কার্ড">
                          <Star className="w-2.5 h-2.5 fill-slate-950" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0 pointer-events-auto">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-gray-800 dark:text-gray-100 line-clamp-2 break-words text-sm sm:text-base">{card.title}</h3>
                      </div>
                      <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                        <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700/70 text-slate-600 dark:text-slate-300 border border-slate-200/60 dark:border-slate-600/50">
                          {(card.rectangles?.length || 0) + (card.pins?.length || 0)} টি আইটেম
                        </span>
                        {(() => {
                          const srsBadge = getCardSrsBadge(card);
                          return (
                            <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full border flex items-center gap-1 ${srsBadge.badgeClass}`} title={`ইন্টারভ্যাল: ${card.interval || 0} দিন | রিপিটেশন: ${card.repetition || 0} | ইজি ফ্যাক্টর: ${card.easeFactor || 2.5}`}>
                              {srsBadge.type === 'mastered' && <Trophy className="w-3 h-3 text-emerald-500" />}
                              {srsBadge.text}
                            </span>
                          );
                        })()}
                        {card.tags && card.tags.length > 0 && (
                          <div className="flex items-center gap-1 flex-wrap">
                            {card.tags.map((t, idx) => (
                              <TagBadge
                                key={`${t}-${idx}`}
                                tag={t}
                                size="sm"
                                onClick={() => setSelectedTag(cleanTag(t))}
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="relative shrink-0 flex items-center gap-1">
                    {/* Quick Star Favorite Toggle */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (onToggleFavorite) onToggleFavorite(card.id);
                      }}
                      className={`w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl transition-all cursor-pointer active:scale-90 ${
                        card.favorite
                          ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-500 hover:bg-amber-100 dark:hover:bg-amber-900/50'
                          : 'bg-gray-50 dark:bg-slate-700/70 text-gray-400 dark:text-gray-500 hover:text-amber-500 hover:bg-gray-100 dark:hover:bg-slate-600'
                      }`}
                      title={card.favorite ? 'প্রিয় তালিকা থেকে সরান' : 'প্রিয় কার্ড হিসেবে চিহ্নিত করুন'}
                    >
                      <Star className={`w-4 h-4 sm:w-5 sm:h-5 ${card.favorite ? 'fill-amber-400 text-amber-500' : ''}`} />
                    </button>
                    {/* Direct Edit Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onEdit(card.id);
                      }}
                      className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 rounded-xl hover:bg-indigo-100 dark:hover:bg-indigo-900/60 active:scale-95 transition-all shadow-2xs border border-indigo-100 dark:border-indigo-800/40"
                      title="কার্ড এডিট করুন"
                    >
                      <Edit3 className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); onStartStudy(studyIndex !== -1 ? studyIndex : 0, false, (isSearching || hasTagFilter) ? filteredCards : undefined); }}
                      className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-800/40 active:scale-95 transition-all shadow-xs"
                      title="স্টাডি করুন"
                    >
                      <BookOpen className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveDropdown(activeDropdown === `card-${card.id}` ? null : `card-${card.id}`); }}
                      className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center bg-gray-50 dark:bg-slate-700/70 text-gray-600 dark:text-gray-300 rounded-xl hover:bg-gray-100 dark:hover:bg-slate-600 active:scale-95 transition-all"
                    >
                      <MoreVertical className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    {activeDropdown === `card-${card.id}` && (
                      <div className="absolute right-0 top-12 w-44 bg-white dark:bg-slate-800 rounded-xl shadow-xl py-2 text-gray-800 dark:text-gray-200 z-50 border border-gray-100 dark:border-slate-700">
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setPreviewCard(card); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <FileText className="w-4 h-4 text-blue-500" /> প্রিভিউ দেখুন
                        </button>
                        <button onClick={(e) => {
                          e.stopPropagation();
                          setActiveDropdown(null);
                          if (onToggleFavorite) onToggleFavorite(card.id);
                        }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <Star className={`w-4 h-4 ${card.favorite ? 'fill-amber-400 text-amber-500' : 'text-gray-400'}`} />
                           {card.favorite ? 'প্রিয় থেকে সরান' : 'প্রিয় চিহ্নিত করুন'}
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); onEdit(card.id); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <Edit3 className="w-4 h-4" /> এডিট করুন
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setMoveItemData({ id: card.id, type: 'card' }); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <FolderIcon className="w-4 h-4" /> মুভ করুন
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setDeleteType('card'); setDeleteConfirmId(card.id); }} className="w-full px-4 py-2 text-left text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 flex items-center gap-2 font-medium">
                           <Trash2 className="w-4 h-4" /> ডিলিট করুন
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Modern Android / iOS Floating Action Dock */}
      <div className="fixed bottom-0 left-0 right-0 p-3 sm:p-4 pointer-events-none flex justify-center z-40 safe-bottom">
        <div className="pointer-events-auto bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg px-3 py-2 sm:px-4 sm:py-2.5 rounded-full shadow-2xl border border-slate-200/80 dark:border-slate-700/80 flex items-center gap-1.5 sm:gap-2.5 transition-all">
          <button
            onClick={() => setShowFolderModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-amber-950/40 hover:text-amber-600 dark:hover:text-amber-400 rounded-full font-semibold text-xs sm:text-sm active:scale-95 transition-all"
            title="নতুন সাবফোল্ডার"
          >
            <div className="w-7 h-7 rounded-full bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <FolderIcon className="w-4 h-4" />
            </div>
            <span className="hidden xs:inline">সাবফোল্ডার</span>
          </button>

          <button
            onClick={() => bulkFileInputRef.current?.click()}
            disabled={isUploading}
            title="একসাথে একাধিক ছবি দিয়ে কার্ড বানান"
            className="flex items-center gap-1.5 px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-600 dark:hover:text-emerald-400 rounded-full font-semibold text-xs sm:text-sm active:scale-95 transition-all disabled:opacity-50"
          >
            <div className="w-7 h-7 rounded-full bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              {isUploading ? <span className="animate-spin text-xs">⏳</span> : <Upload className="w-4 h-4" />}
            </div>
            <span className="hidden xs:inline">বাল্ক</span>
          </button>

          <div className="h-6 w-px bg-slate-200 dark:bg-slate-700 mx-0.5" />

          <button
            onClick={onCreateNew}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-4 py-2 sm:px-5 sm:py-2.5 rounded-full font-bold text-xs sm:text-sm shadow-md shadow-blue-500/25 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
            <span>নতুন কার্ড</span>
          </button>
        </div>
      </div>

      <BulkTagModal
        isOpen={showBulkTagModal}
        selectedCount={selectedCards.length}
        existingTags={folderAvailableTags.map(t => t.name)}
        onApply={(tag) => {
          if (onAddTagToCards) {
            onAddTagToCards(selectedCards, tag);
            setAlertMsg(`${selectedCards.length} টি কার্ডে #${tag} ট্যাগ যুক্ত করা হয়েছে!`);
            cancelSelection();
          }
        }}
        onClose={() => setShowBulkTagModal(false)}
      />

      <SettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        cards={allCards || cards}
        folders={allFolders || folders}
        darkMode={darkMode}
        toggleDarkMode={toggleDarkMode}
        onImport={onImport}
        setAlertMsg={setAlertMsg}
        onOpenHelp={() => setShowHelpModal(true)}
      />

      <OcclusionHelpModal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
      />

      {previewCard && (
        <CardPreviewModal
          card={cards.find(c => c.id === previewCard.id) || previewCard}
          folderName={folder.name}
          onClose={() => setPreviewCard(null)}
          onEdit={() => {
            const id = previewCard.id;
            setPreviewCard(null);
            onEdit(id);
          }}
          onStartStudy={() => {
            const c = previewCard;
            setPreviewCard(null);
            const idx = cards.findIndex(item => item.id === c.id);
            onStartStudy(idx !== -1 ? idx : 0, false, [c]);
          }}
          onToggleFavorite={onToggleFavorite ? () => onToggleFavorite(previewCard.id) : undefined}
        />
      )}
    </div>
  );
}
