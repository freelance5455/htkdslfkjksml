import React, { useState, useEffect } from 'react';
import { Eye, Clock } from 'lucide-react';

export default function EyeCareTimer() {
  // 20 minutes = 20 * 60 seconds = 1200 seconds
  const WORK_TIME = 1200; 
  // 20 seconds break
  const BREAK_TIME = 20;

  const [workTimeLeft, setWorkTimeLeft] = useState(WORK_TIME);
  const [isBreakActive, setIsBreakActive] = useState(false);
  const [breakTimeLeft, setBreakTimeLeft] = useState(BREAK_TIME);

  useEffect(() => {
    const interval = setInterval(() => {
      if (isBreakActive) {
        setBreakTimeLeft(prev => {
          if (prev <= 1) {
            setIsBreakActive(false);
            setWorkTimeLeft(WORK_TIME); // Reset work timer
            return BREAK_TIME;
          }
          return prev - 1;
        });
      } else {
        setWorkTimeLeft(prev => {
          if (prev <= 1) {
            setIsBreakActive(true);
            setBreakTimeLeft(BREAK_TIME);
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isBreakActive]);

  const handleSkip = () => {
    setIsBreakActive(false);
    setWorkTimeLeft(WORK_TIME);
    setBreakTimeLeft(BREAK_TIME);
  };

  if (!isBreakActive) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-slate-900/90 backdrop-blur-sm p-4 animate-in fade-in duration-500">
      <div className="bg-white dark:bg-slate-800 p-8 rounded-2xl shadow-2xl max-w-md w-full text-center border border-slate-700">
        <div className="flex justify-center mb-6">
          <div className="relative">
            <Eye className="w-16 h-16 text-blue-500 animate-pulse" />
            <Clock className="w-6 h-6 text-indigo-500 absolute -bottom-2 -right-2 bg-white dark:bg-slate-800 rounded-full" />
          </div>
        </div>
        
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">চোখের বিশ্রাম! (20-20-20)</h2>
        
        <p className="text-slate-600 dark:text-slate-300 mb-6 text-lg leading-relaxed">
          স্ক্রিন থেকে চোখ সরিয়ে কমপক্ষে <strong>২০ ফুট</strong> দূরের কোনো বস্তুর দিকে <strong>২০ সেকেন্ড</strong> তাকিয়ে থাকুন। এটি আপনার চোখের স্ট্রেইন কমাবে।
        </p>
        
        <div className="text-6xl font-bold text-blue-600 dark:text-blue-400 mb-8 font-mono">
          {breakTimeLeft}s
        </div>
        
        <button 
          onClick={handleSkip}
          className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 text-sm font-medium transition-colors"
        >
          স্কিপ করুন
        </button>
      </div>
    </div>
  );
}
