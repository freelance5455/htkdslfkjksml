import React, { useState, useRef, useEffect } from 'react';
import { BookOpen, Trash2, Plus, Search, Shuffle, Download, Upload, Edit3, X, Folder as FolderIcon, Moon, Sun, MoreVertical, CheckSquare, Layers, Sparkles, ShieldCheck, Tag, Settings as SettingsIcon, HelpCircle, Flame, Target, Trophy, Award, FileText, Star, ClipboardPaste, Check, Eye } from 'lucide-react';
import { Card, Folder } from '../types';
import SyncButton from './SyncButton';
import SettingsModal from './SettingsModal';
import OcclusionHelpModal from './OcclusionHelpModal';
import CardPreviewModal from './CardPreviewModal';
import PWAInstallButton from './PWAInstallButton';
import PWAInstallModal from './PWAInstallModal';
import { getAllTags, cleanTag } from '../lib/tagUtils';
import { saveOrShareJSON } from '../lib/fileSaveUtils';
import { TagBadge, TagFilterBar, BulkTagModal } from './TagComponents';
import FileExportModal from './FileExportModal';
import { openSyncModal } from './SyncButton';
import { getDailyGoalStats, setDailyGoalTarget, DailyGoalData } from '../lib/goalUtils';
import { triggerHaptic } from '../lib/speechUtils';
import {
  getCardSrsBadge,
  sortCardsForOptimalReview,
  getSrsOverview,
  isCardDue,
  isCardNew,
  isCardMastered,
  isCardLearning
} from '../lib/srsUtils';
import {
  toggleEyeComfort,
  subscribeEyeComfort,
  isEyeComfortActive
} from '../lib/eyeComfortUtils';

interface DashboardProps {
  cards: Card[];
  folders: Folder[];
  darkMode?: boolean;
  toggleDarkMode?: () => void;
  onAddFolder: (name: string) => void;
  onDeleteFolder: (id: number) => void;
  onOpenFolder: (id: number) => void;
  onDelete: (id: number) => void;
  onDeleteMultiple?: (ids: number[], itemType?: 'card'|'folder') => void;
  onMoveMultiple?: (ids: number[], targetFolderId: number | null, itemType?: 'card'|'folder') => void;
  onRename: (id: number, title: string) => void;
  onEdit: (id: number) => void;
  onImport: (data: any) => void;
  onSyncDataLoaded?: (data: { cards: Card[]; folders: Folder[] }) => void;
  onRecoverLegacy: () => void;
  onAddTagToCards?: (cardIds: number[], tag: string) => void;
  onToggleFavorite?: (cardId: number) => void;
  onMoveItem: (itemId: number, targetFolderId: number | null, itemType: 'card' | 'folder') => void;
  onStartStudy: (index: number, shuffled?: boolean, studyCards?: Card[]) => void;
  onStartQuiz: (studyCards?: Card[]) => void;
  onCreateNew: () => void;
  onBulkCreate?: (cards: Card[]) => void;
  onStartBulkEdit?: (cards: Card[]) => void;
}

export default function Dashboard({ cards, folders, darkMode, toggleDarkMode, onAddFolder, onDeleteFolder, onOpenFolder, onDelete, onDeleteMultiple, onMoveMultiple, onRename, onEdit, onImport, onSyncDataLoaded, onRecoverLegacy, onAddTagToCards, onToggleFavorite, onMoveItem, onStartStudy, onStartQuiz, onCreateNew, onBulkCreate, onStartBulkEdit }: DashboardProps) {
  const [search, setSearch] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [srsFilter, setSrsFilter] = useState<'all' | 'due' | 'new' | 'learning' | 'mastered' | 'favorite'>('all');
  const [showBulkTagModal, setShowBulkTagModal] = useState(false);
  const [previewCard, setPreviewCard] = useState<Card | null>(null);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bulkFileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  // Modal states
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);
  const [deleteType, setDeleteType] = useState<'card'|'folder'>('card');
  const [bulkPendingCards, setBulkPendingCards] = useState<Card[]>([]);
  const [moveItemData, setMoveItemData] = useState<{id: number, type: 'card'|'folder'} | null>(null);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [renameData, setRenameData] = useState<{id: number, title: string} | null>(null);
  const [renameInput, setRenameInput] = useState('');
  const [alertMsg, setAlertMsg] = useState('');
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showFileExportModal, setShowFileExportModal] = useState(false);
  const [fileExportPayload, setFileExportPayload] = useState<{ filename: string; data: any; title: string } | null>(null);
  const [showRestoreModal, setShowRestoreModal] = useState(false);
  const [pastedRestoreJson, setPastedRestoreJson] = useState('');
  const [isPastingFromClipboard, setIsPastingFromClipboard] = useState(false);
  const [showPwaInstallModal, setShowPwaInstallModal] = useState(false);
  const [isEyeComfort, setIsEyeComfort] = useState<boolean>(() => isEyeComfortActive());

  useEffect(() => {
    const unsub = subscribeEyeComfort((_, active) => setIsEyeComfort(active));
    return () => unsub();
  }, []);

  const handlePasteFromClipboard = async () => {
    try {
      setIsPastingFromClipboard(true);
      if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text && text.trim()) {
          setPastedRestoreJson(text.trim());
          setAlertMsg('ক্লিপবোর্ড থেকে ডাটা পেস্ট হয়েছে! এবার "রিস্টোর সম্পন্ন করুন" বাটনে চাপ দিন।');
          return;
        }
      }
      setAlertMsg('ক্লিপবোর্ডে সরাসরি অ্যাক্সেস পাওয়া যায়নি। নিচের বক্সে দীর্ঘক্ষণ চেপে ধরে Paste করুন।');
    } catch (e) {
      setAlertMsg('নিচের টেক্সটবক্সে আঙুল দিয়ে চেপে ধরে "Paste" করুন।');
    } finally {
      setIsPastingFromClipboard(false);
    }
  };

  const handleConfirmPasteRestore = () => {
    if (!pastedRestoreJson.trim()) {
      setAlertMsg('অনুগ্রহ করে ব্যাকআপ কোড পেস্ট করুন!');
      return;
    }
    try {
      const parsed = JSON.parse(pastedRestoreJson.trim());
      onImport(parsed);
      setShowRestoreModal(false);
      setPastedRestoreJson('');
      setAlertMsg('সফলভাবে সমস্ত ফ্ল্যাশকার্ড ও ফোল্ডার রিস্টোর সম্পন্ন হয়েছে!');
    } catch (err) {
      setAlertMsg('ভুল ফরম্যাট! অনুগ্রহ করে সঠিক সম্পূর্ণ JSON ব্যাকআপ কোড পেস্ট করুন।');
    }
  };
  const [goalStats, setGoalStats] = useState<DailyGoalData>(() => getDailyGoalStats());
  const [targetGoalInput, setTargetGoalInput] = useState<number>(() => getDailyGoalStats().target);

  useEffect(() => {
    setGoalStats(getDailyGoalStats());
    const handleFocus = () => setGoalStats(getDailyGoalStats());
    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, [cards]);

  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [selectedFolders, setSelectedFolders] = useState<number[]>([]);
  const [isSelectionMode, setIsSelectionMode] = useState(false);

  const [showMenu, setShowMenu] = useState(false);
  const pressTimer = useRef<NodeJS.Timeout | null>(null);

  const startPress = (id: number, type: 'card'|'folder') => {
    if (isSelectionMode) return;
    pressTimer.current = setTimeout(() => {
      setIsSelectionMode(true);
      if (type === 'card') toggleSelectCard(id);
      else toggleSelectFolder(id);
    }, 500);
  };

  const cancelPress = () => {
    if (pressTimer.current) {
      clearTimeout(pressTimer.current);
      pressTimer.current = null;
    }
  };

  const selectAll = () => {
    setSelectedCards(filteredCards.map(c => c.id));
    setSelectedFolders(filteredFolders.map(f => f.id));
    setShowMenu(false);
  };


  const toggleSelectCard = (id: number) => {
    setSelectedCards(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };
  
  const toggleSelectFolder = (id: number) => {
    setSelectedFolders(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const cancelSelection = () => {
    setSelectedCards([]);
    setSelectedFolders([]);
    setIsSelectionMode(false);
  };

  
  const [showFolderModal, setShowFolderModal] = useState(false);
  const [folderName, setFolderName] = useState('');
  const [uploadProgress, setUploadProgress] = useState<{ current: number; total: number } | null>(null);

  const allAvailableTags = getAllTags(cards);
  const hasTagFilter = Boolean(selectedTag);
  const hasSrsFilter = srsFilter !== 'all';

  const srsStats = React.useMemo(() => getSrsOverview(cards), [cards]);
  const dueCards = React.useMemo(() => cards.filter(isCardDue), [cards]);
  const favoriteCount = React.useMemo(() => cards.filter(c => Boolean(c.favorite)).length, [cards]);

  const isSearching = search.trim().length > 0;
  const searchLower = search.toLowerCase().trim();

  const unassignedCards = cards.filter(c => !c.folderId);
  const rootFolders = folders.filter(f => !f.parentId);

  // When searching, tag-filtering, or SRS-filtering, filter cards across all folders so users can find what they need
  const rawFilteredCards = cards.filter(c => {
    if (selectedTag) {
      const matchTag = Array.isArray(c.tags) && c.tags.some(t => cleanTag(t).toLowerCase() === selectedTag.toLowerCase());
      if (!matchTag) return false;
    } else if (!hasSrsFilter && !isSearching) {
      if (c.folderId) return false;
    }

    if (srsFilter === 'due' && !isCardDue(c)) return false;
    if (srsFilter === 'new' && !isCardNew(c)) return false;
    if (srsFilter === 'learning' && !isCardLearning(c)) return false;
    if (srsFilter === 'mastered' && !isCardMastered(c)) return false;
    if (srsFilter === 'favorite' && !c.favorite) return false;

    if (isSearching) {
      const matchTitle = c.title.toLowerCase().includes(searchLower);
      const matchTag = Array.isArray(c.tags) && c.tags.some(t => t.toLowerCase().includes(searchLower));
      if (!matchTitle && !matchTag) return false;
    }

    return true;
  });

  // If viewing due cards, automatically sort by optimal SuperMemo-2 queue
  const filteredCards = React.useMemo(() => {
    if (srsFilter === 'due') {
      return sortCardsForOptimalReview(rawFilteredCards);
    }
    return rawFilteredCards;
  }, [rawFilteredCards, srsFilter]);

  const filteredFolders = (hasTagFilter || hasSrsFilter)
    ? []
    : isSearching
      ? rootFolders.filter(f => f.name.toLowerCase().includes(searchLower))
      : rootFolders;

  const handleBulkUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;
    setIsUploading(true);
    setUploadProgress({ current: 0, total: files.length });
    const newCards: Card[] = [];
    let failedCount = 0;
    const { compressImage } = await import('../lib/imageUtils');
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setUploadProgress({ current: i + 1, total: files.length });
      
      const isImg = file.type.startsWith('image/') || 
                    /\.(jpe?g|png|webp|bmp|gif|heic|heif)$/i.test(file.name) ||
                    file.type === '';
      if (!isImg) {
        continue;
      }
      try {
         const compressedBase64 = await compressImage(file, 2048, 0.85);
         newCards.push({
            id: Date.now() + Math.floor(Math.random() * 1000000) + i,
            title: file.name.replace(/\.[^/.]+$/, "") || `কার্ড ${newCards.length + 1}`,
            image: compressedBase64,
            rectangles: [],
            pins: [],
            createdAt: Date.now()
         });
      } catch (err) { 
        console.error("Error compressing", err);
        failedCount++;
      }
    }
    
    setUploadProgress(null);
    setIsUploading(false);
    if (bulkFileInputRef.current) bulkFileInputRef.current.value = '';

    if (newCards.length > 0) {
      setBulkPendingCards(newCards);
      if (failedCount > 0) {
        setAlertMsg(`${failedCount} টি ছবি প্রসেস করা যায়নি, বাকি ${newCards.length} টি ছবি প্রস্তুত।`);
      }
    } else if (failedCount > 0) {
      setAlertMsg(`${failedCount} টি ছবি প্রসেস করতে সমস্যা হয়েছে, অন্য ছবি দিয়ে চেষ্টা করুন।`);
    }
  };

  const handleExport = () => {
    try {
      const now = new Date();
      const dateString = now.toISOString().slice(0, 10);
      const timeString = `${String(now.getHours()).padStart(2, '0')}-${String(now.getMinutes()).padStart(2, '0')}`;
      const backupPayload = {
        app: 'Image Occlusion Flashcards',
        version: '2.0',
        exportedAt: now.toISOString(),
        exportedAtFormatted: now.toLocaleString('bn-BD'),
        totalCards: cards.length,
        totalFolders: folders.length,
        cards,
        folders
      };

      const filename = `flashcards_backup_${dateString}_${timeString}.json`;
      setShowExportModal(false);
      setFileExportPayload({
        filename,
        data: backupPayload,
        title: 'মেমোরি কার্ড সম্পূর্ণ ব্যাকআপ'
      });
      setShowFileExportModal(true);
    } catch (e) {
      setAlertMsg('ফাইল প্রস্তুত করতে সমস্যা হয়েছে।');
    }
  };

  const handleExportAnki = () => {
    try {
      if (cards.length === 0) {
        setAlertMsg('এক্সপোর্ট করার মতো কোনো কার্ড নেই!');
        return;
      }
      let tsvContent = "#separator:tab\n#html:true\n#tags column:3\n";
      cards.forEach(c => {
        const front = `<strong>${(c.title || 'Untitled').replace(/\t/g, ' ')}</strong><br><img src="${c.image}">`;
        const back = c.notes ? c.notes.replace(/\n/g, '<br>').replace(/\t/g, ' ') : `আইটেম: ${(c.rectangles?.length || 0)} টি মাস্ক, ${(c.pins?.length || 0)} টি পিন`;
        const tagStr = (c.tags || []).join(' ');
        tsvContent += `${front}\t${back}\t${tagStr}\n`;
      });

      const filename = `anki_deck_${new Date().toISOString().slice(0, 10)}.txt`;
      setShowExportModal(false);
      setFileExportPayload({
        filename,
        data: tsvContent,
        title: 'Anki ডেক ব্যাকআপ ফাইল'
      });
      setShowFileExportModal(true);
    } catch (e) {
      setAlertMsg('Anki ফাইল প্রস্তুত করতে সমস্যা হয়েছে।');
    }
  };

  const handleSaveGoalTarget = () => {
    if (targetGoalInput > 0) {
      const updated = setDailyGoalTarget(targetGoalInput);
      setGoalStats(updated);
      setShowGoalModal(false);
      setAlertMsg(`প্রতিদিনের পড়ার টার্গেট ${targetGoalInput} টি কার্ড সেট করা হয়েছে!`);
      setTimeout(() => setAlertMsg(''), 2500);
    }
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportFile(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const confirmImport = () => {
    if (!importFile) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target?.result as string);
        onImport(imported);
        setAlertMsg('সফলভাবে ডাটা ইম্পোর্ট করা হয়েছে!');
      } catch (err) {
        setAlertMsg('ভুল ফাইল ফরম্যাট!');
      }
      setImportFile(null);
    };
    reader.readAsText(importFile);
  };

  const handleRenameClick = (card: Card) => {
    setRenameData({ id: card.id, title: card.title });
    setRenameInput(card.title);
  };

  const confirmRename = () => {
    if (renameData && renameInput.trim() !== '') {
      onRename(renameData.id, renameInput.trim());
    }
    setRenameData(null);
  };

  const handleCreateFolder = () => {
    if (folderName.trim()) {
      onAddFolder(folderName.trim());
      setShowFolderModal(false);
      setFolderName('');
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto pb-24">
      {/* Hidden file inputs placed at root level */}
      <input type="file" ref={fileInputRef} onChange={handleImport} accept="application/json,.json,text/plain,text/*,*/*" className="hidden" />
      <input 
        type="file" 
        ref={bulkFileInputRef} 
        onChange={handleBulkUpload} 
        accept="image/*,.heic,.heif,.jpg,.jpeg,.png,.webp,.bmp" 
        multiple 
        className="hidden" 
      />

      {/* Upload Progress Modal */}
      {uploadProgress && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-2xl text-center">
            <div className="animate-spin text-3xl mb-3">⏳</div>
            <h3 className="text-lg font-bold dark:text-white mb-2">ছবি প্রসেস হচ্ছে...</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
              {uploadProgress.current} / {uploadProgress.total} টি ছবি তৈরি হচ্ছে
            </p>
            <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-3 overflow-hidden">
              <div 
                className="bg-green-500 h-full transition-all duration-300"
                style={{ width: `${Math.round((uploadProgress.current / uploadProgress.total) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Alert Modal */}
      {alertMsg && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100">{alertMsg}</h3>
            <button onClick={() => setAlertMsg('')} className="w-full bg-blue-600 text-white py-2 rounded-lg font-medium">ঠিক আছে</button>
          </div>
        </div>
      )}

      {/* Bulk Upload Choice Modal */}
      {bulkPendingCards.length > 0 && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-xl font-bold mb-4 dark:text-white text-center">অনেকগুলো ছবি সিলেক্ট করেছেন</h3>
            <p className="text-slate-600 dark:text-slate-300 mb-6 text-center">
              আপনি কি ছবিগুলো একবারে সরাসরি সেভ করতে চান, নাকি একে একে এডিট করে (নাম, মাস্ক দিয়ে) সেভ করতে চান?
            </p>
            <div className="flex flex-col gap-3">
              <button
                onClick={() => {
                  if (onStartBulkEdit) onStartBulkEdit(bulkPendingCards);
                  setBulkPendingCards([]);
                }}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold transition-colors"
              >
                একে একে এডিট করুন (প্রস্তাবিত)
              </button>
              <button
                onClick={() => {
                  if (onBulkCreate) onBulkCreate(bulkPendingCards);
                  setAlertMsg(`${bulkPendingCards.length} টি কার্ড সফলভাবে তৈরি হয়েছে!`);
                  setBulkPendingCards([]);
                }}
                className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold transition-colors"
              >
                সব একসাথে সেভ করুন
              </button>
              <button
                onClick={() => setBulkPendingCards([])}
                className="w-full py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-white rounded-lg font-bold transition-colors mt-2"
              >
                বাতিল করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm Modal */}
      {deleteConfirmId !== null && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-2">নিশ্চিত করুন</h3>
            <p className="text-gray-600 mb-6">আপনি কি নিশ্চিত যে {deleteConfirmId === -1 ? `নির্বাচিত ${selectedFolders.length} টি ফোল্ডার এবং ${selectedCards.length} টি কার্ড` : `এই ${deleteType === 'folder' ? 'ফোল্ডার এবং এর সব কার্ড' : 'কার্ডটি'}`} ডিলিট করতে চান?</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirmId(null)} className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-2 rounded-lg font-medium">না, বাতিল</button>
              <button onClick={() => { 
                if (deleteConfirmId === -1 && onDeleteMultiple) {
                  if (selectedFolders.length > 0) onDeleteMultiple(selectedFolders, 'folder');
                  if (selectedCards.length > 0) onDeleteMultiple(selectedCards, 'card');
                  cancelSelection();
                } else {
                  if (deleteType === 'folder') onDeleteFolder(deleteConfirmId);
                  else onDelete(deleteConfirmId);
                } 
                setDeleteConfirmId(null); 
              }} className="flex-1 bg-red-500 text-white py-2 rounded-lg font-medium">হ্যাঁ, ডিলিট</button>
            </div>
          </div>
        </div>
      )}

      {/* Move Modal */}
      {moveItemData !== null && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100">কোথায় মুভ করবেন?</h3>
            <div className="flex flex-col gap-2 max-h-60 overflow-y-auto mb-4">
              <button
                onClick={() => {
                  if (moveItemData.id === -1 && onMoveMultiple) {
                    if (selectedFolders.length > 0) onMoveMultiple(selectedFolders, null, 'folder');
                    if (selectedCards.length > 0) onMoveMultiple(selectedCards, null, 'card');
                    cancelSelection();
                  } else {
                    onMoveItem(moveItemData.id, null, moveItemData.type);
                  }
                  setMoveItemData(null);
                }}
                className="p-3 text-left bg-gray-50 hover:bg-gray-100 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-lg flex items-center gap-3 transition-colors"
              >
                <FolderIcon className="w-5 h-5 text-gray-400" />
                <span className="font-medium text-gray-800 dark:text-gray-200">মূল পাতা (Root)</span>
              </button>
              {folders.filter(f => f.id !== (moveItemData.type === 'folder' ? moveItemData.id : -1)).map(folder => (
                <button
                  key={folder.id}
                  onClick={() => {
                    if (moveItemData.id === -1 && onMoveMultiple) {
                      if (selectedFolders.length > 0) onMoveMultiple(selectedFolders, folder.id, 'folder');
                      if (selectedCards.length > 0) onMoveMultiple(selectedCards, folder.id, 'card');
                      cancelSelection();
                    } else {
                      onMoveItem(moveItemData.id, folder.id, moveItemData.type);
                    }
                    setMoveItemData(null);
                  }}
                  className="p-3 text-left bg-gray-50 hover:bg-gray-100 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-lg flex items-center gap-3 transition-colors"
                >
                  <FolderIcon className="w-5 h-5 text-amber-500" />
                  <span className="font-medium text-gray-800 dark:text-gray-200">{folder.name}</span>
                </button>
              ))}
            </div>
            <button onClick={() => setMoveItemData(null)} className="w-full bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-2 rounded-lg font-medium">বাতিল</button>
          </div>
        </div>
      )}

      {/* Import Confirm Modal */}
      {importFile && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-2">নিশ্চিত করুন</h3>
            <p className="text-gray-600 mb-6">ইম্পোর্ট করলে বর্তমান সব কার্ড মুছে যাবে এবং ব্যাকআপ থেকে নতুন কার্ড যুক্ত হবে। আপনি কি নিশ্চিত?</p>
            <div className="flex gap-3">
              <button onClick={() => setImportFile(null)} className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-2 rounded-lg font-medium">বাতিল</button>
              <button onClick={confirmImport} className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-medium">হ্যাঁ, ইম্পোর্ট</button>
            </div>
          </div>
        </div>
      )}

      {/* Rename Modal */}
      {renameData && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100">কার্ডের নাম পরিবর্তন</h3>
            <input 
              type="text" 
              value={renameInput}
              onChange={(e) => setRenameInput(e.target.value)}
              className="w-full border border-gray-300 dark:border-slate-600 rounded-lg p-3 mb-6 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-gray-100"
              autoFocus
            />
            <div className="flex gap-3">
              <button onClick={() => setRenameData(null)} className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-2 rounded-lg font-medium">বাতিল</button>
              <button onClick={confirmRename} className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-medium">সেভ করুন</button>
            </div>
          </div>
        </div>
      )}

      {/* Create Folder Modal */}
      {showFolderModal && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[9999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100">নতুন ফোল্ডার</h3>
            <input 
              type="text" 
              value={folderName}
              onChange={(e) => setFolderName(e.target.value)}
              placeholder="ফোল্ডারের নাম..."
              className="w-full border border-gray-300 dark:border-slate-600 rounded-lg p-3 mb-6 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-gray-100"
              autoFocus
            />
            <div className="flex gap-3">
              <button onClick={() => setShowFolderModal(false)} className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-2 rounded-lg font-medium">বাতিল</button>
              <button onClick={handleCreateFolder} className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-medium">তৈরি করুন</button>
            </div>
          </div>
        </div>
      )}

      {isSelectionMode ? (
        <header className="safe-top-header bg-blue-600 dark:bg-blue-800 text-white px-4 pb-4 shadow-md rounded-b-2xl mb-6 shrink-0 flex items-center justify-between relative z-20">
          <div className="flex items-center gap-3">
            <button onClick={cancelSelection} className="p-2 hover:bg-blue-700 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <span className="text-xl font-bold">{selectedCards.length + selectedFolders.length} সিলেক্টেড</span>
          </div>
          <div className="relative flex items-center gap-2">
            {selectedCards.length > 0 && (
              <button
                onClick={() => setShowBulkTagModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-semibold transition-colors"
                title="সিলেক্ট করা কার্ডগুলোতে ট্যাগ দিন"
              >
                <Tag className="w-4 h-4" />
                <span className="hidden sm:inline">ট্যাগ দিন</span>
              </button>
            )}
            <SyncButton cards={cards} folders={folders} onDataLoaded={onSyncDataLoaded || onImport} setAlert={setAlertMsg} />
            <button onClick={() => setShowMenu(!showMenu)} className="p-2 hover:bg-blue-700 rounded-full transition-colors">
              <MoreVertical className="w-6 h-6" />
            </button>
            {showMenu && (
              <div className="absolute right-0 mt-2 top-full w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl py-2 text-gray-800 dark:text-gray-200 z-50 border border-gray-100 dark:border-slate-700">
                <button onClick={selectAll} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left font-medium">
                  <CheckSquare className="w-5 h-5" /> সব সিলেক্ট করুন
                </button>
                {selectedCards.length > 0 && (
                  <button onClick={() => {
                    setShowMenu(false);
                    setShowBulkTagModal(true);
                  }} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left font-medium text-blue-600 dark:text-blue-400">
                    <Tag className="w-5 h-5" /> ট্যাগ যোগ করুন
                  </button>
                )}
                <button onClick={() => {
                  setShowMenu(false);
                  if (selectedCards.length > 0 || selectedFolders.length > 0) setMoveItemData({ id: -1, type: 'card' });
                }} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left font-medium">
                  <FolderIcon className="w-5 h-5" /> মুভ করুন
                </button>
                <button onClick={() => {
                  setShowMenu(false);
                  if (selectedCards.length > 0 || selectedFolders.length > 0) {
                    setDeleteType('card');
                    setDeleteConfirmId(-1);
                  }
                }} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-red-50 dark:hover:bg-red-900/30 text-red-500 transition-colors text-left font-medium">
                  <Trash2 className="w-5 h-5" /> ডিলিট করুন
                </button>
              </div>
            )}
          </div>
        </header>
      ) : (
        <header className="safe-top-header bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 dark:from-slate-900 dark:via-blue-950 dark:to-indigo-950 text-white px-4 pb-5 sm:px-6 sm:pb-6 shadow-xl rounded-b-3xl mb-4 shrink-0 border-b border-blue-500/20 relative overflow-hidden">
          {/* Subtle Ambient Light Glows */}
          <div className="absolute -top-10 -right-10 w-44 h-44 bg-blue-400/15 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-44 h-44 bg-indigo-400/15 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center justify-between gap-2 mb-3 relative z-10">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-white/15 dark:bg-blue-500/20 flex items-center justify-center backdrop-blur-md border border-white/20 shadow-xs">
                <Layers className="w-5 h-5 text-blue-100" />
              </div>
              <button onClick={onRecoverLegacy} title="হারানো ডাটা খুঁজুন (Recovery)" className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-500 hover:bg-amber-600 active:scale-95 text-white rounded-full transition-all text-xs font-bold shadow-xs shrink-0">
                রিকভারি
              </button>
              <PWAInstallButton onClick={() => setShowPwaInstallModal(true)} />
            </div>
            
            <div className="flex items-center gap-1 sm:gap-2 shrink-0">
              <SyncButton cards={cards} folders={folders} onDataLoaded={onSyncDataLoaded || onImport} setAlert={setAlertMsg} />
              {toggleDarkMode && (
                <button onClick={toggleDarkMode} title="ডার্ক মোড টগল করুন" className="p-2 hover:bg-white/10 dark:hover:bg-slate-800/80 active:scale-90 rounded-full transition-all">
                  {darkMode ? <Sun className="w-5 h-5 text-amber-300" /> : <Moon className="w-5 h-5" />}
                </button>
              )}
              <button 
                onClick={() => {
                  triggerHaptic('light');
                  const next = toggleEyeComfort();
                  setIsEyeComfort(next);
                  setAlertMsg(next ? 'চোখের সুরক্ষা আলো সক্রিয় হয়েছে (Eye Comfort ON) 🛡️' : 'চোখের সুরক্ষা আলো বন্ধ করা হয়েছে');
                }} 
                title={isEyeComfort ? "চোখের সুরক্ষা আলো সক্রিয় আছে (Eye Comfort ON) - বন্ধ করতে ক্লিক করুন" : "চোখের সুরক্ষা আলো চালু করুন (Eye Comfort Shield / Night Light)"} 
                className={`p-2 rounded-full transition-all active:scale-90 flex items-center gap-1 cursor-pointer ${
                  isEyeComfort
                    ? 'bg-amber-400 text-slate-900 shadow-md ring-2 ring-amber-300'
                    : 'hover:bg-white/10 dark:hover:bg-slate-800/80 text-blue-100 hover:text-white'
                }`}
              >
                <Eye className="w-5 h-5" />
                <span className="hidden lg:inline text-xs font-bold">আই-শিল্ড</span>
              </button>
              <button 
                onClick={() => setShowHelpModal(true)} 
                title="ইমেজ অক্লুশন নির্দেশিকা ও ডেমো (Help Guide)" 
                className="flex items-center gap-1 p-2 hover:bg-white/10 dark:hover:bg-slate-800/80 active:scale-90 rounded-full transition-all text-sm font-medium"
              >
                <HelpCircle className="w-5 h-5 text-blue-100 hover:text-white" />
                <span className="hidden sm:inline text-xs font-medium">সাহায্য</span>
              </button>
              <button 
                onClick={() => setShowSettingsModal(true)} 
                title="অ্যাপ সেটিংস ও ব্যাকআপ (Settings)" 
                className="flex items-center gap-1 p-2 hover:bg-white/10 dark:hover:bg-slate-800/80 active:scale-90 rounded-full transition-all text-sm font-medium"
              >
                <SettingsIcon className="w-5 h-5" />
                <span className="hidden sm:inline text-xs font-medium">সেটিংস</span>
              </button>
              <button onClick={() => setShowExportModal(true)} title="ফাইল ব্যাকআপ ও Anki এক্সপোর্ট" className="flex items-center gap-1 p-2 hover:bg-white/10 dark:hover:bg-slate-800/80 active:scale-90 rounded-full transition-all text-sm font-medium cursor-pointer">
                <Download className="w-5 h-5" />
                <span className="hidden sm:inline text-xs font-medium">ব্যাকআপ</span>
              </button>
              <button onClick={() => setShowRestoreModal(true)} title="ডাটা রিস্টোর (টেক্সট পেস্ট বা ফাইল)" className="flex items-center gap-1 p-2 hover:bg-white/10 dark:hover:bg-slate-800/80 active:scale-90 rounded-full transition-all text-sm font-medium cursor-pointer">
                <Upload className="w-5 h-5" />
                <span className="hidden sm:inline text-xs font-medium">রিস্টোর</span>
              </button>
            </div>
          </div>
          
          <div className="text-center pt-1 pb-1 relative z-10">
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight bg-gradient-to-r from-white via-blue-50 to-blue-200 bg-clip-text text-transparent">
              মেমোরি কার্ড স্টুডিও
            </h1>
            <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 mt-2 text-xs text-blue-100 font-medium">
              <span className="px-2.5 py-0.5 rounded-full bg-white/15 dark:bg-white/10 border border-white/15 backdrop-blur-xs">
                📁 {rootFolders.length} টি ফোল্ডার
              </span>
              <span className="text-blue-300">•</span>
              <span className="px-2.5 py-0.5 rounded-full bg-white/15 dark:bg-white/10 border border-white/15 backdrop-blur-xs">
                🗂️ {cards.length} টি কার্ড
              </span>
              <span className="hidden sm:inline text-blue-300">•</span>
              <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-200 border border-emerald-400/30">
                <ShieldCheck className="w-3.5 h-3.5" /> ড্রাইভ ও ক্লাউড নিরাপদ
              </span>
            </div>
          </div>
        </header>
      )}

      {/* Review Stats & Daily Goal Widgets */}
      <div className="max-w-3xl w-full mx-auto px-4 mb-3 shrink-0">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Due Cards Review Widget (SuperMemo-2) */}
          <div className="relative overflow-hidden bg-gradient-to-br from-blue-600/10 via-indigo-600/5 to-purple-600/10 dark:from-blue-950/60 dark:via-slate-800/80 dark:to-indigo-950/60 p-3.5 sm:p-4 rounded-2xl border border-blue-200/70 dark:border-blue-800/40 shadow-xs backdrop-blur-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-blue-500/30 shrink-0">
                <BookOpen className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100">SuperMemo-2 রিভিশন</h2>
                  {srsStats.dueCount > 0 ? (
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800 animate-pulse">
                      {srsStats.dueCount} বাকি
                    </span>
                  ) : (
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                      সব সম্পন্ন
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  {srsStats.dueCount > 0
                    ? `${srsStats.dueCount} টি কার্ডের সময় হয়েছে (${srsStats.masteredCount} টি সম্পূর্ণ আয়ত্তে)`
                    : `আজকে সব রিভিশন শেষ! (${srsStats.masteredCount} টি সম্পূর্ণ আয়ত্তে)`}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
              <button 
                onClick={() => {
                  const due = sortCardsForOptimalReview(cards.filter(c => isCardDue(c)));
                  if (due.length > 0) {
                    onStartStudy(0, false, due); 
                  } else {
                    setAlertMsg('আজকে নতুন কোনো রিভিশন বাকি নেই!');
                  }
                }}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-3 sm:px-3.5 py-2 rounded-xl font-bold text-xs shadow-md shadow-blue-500/25 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                title="SuperMemo-2 অপটিমাল অর্ডারে স্টাডি শুরু করুন"
              >
                পড়ুন ({srsStats.dueCount})
              </button>
              <button 
                onClick={() => {
                  const due = sortCardsForOptimalReview(cards.filter(c => isCardDue(c)));
                  if (due.length > 0) {
                    onStartQuiz(due);
                  } else {
                    setAlertMsg('আজকে নতুন কোনো রিভিশন বাকি নেই!');
                  }
                }}
                className="bg-indigo-100 dark:bg-indigo-950/60 hover:bg-indigo-200 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 px-3 py-2 rounded-xl font-bold text-xs active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                title="কুইজ দিয়ে মেধা যাচাই করুন"
              >
                কুইজ
              </button>
            </div>
          </div>

          {/* Daily Goal & Streak Habit Widget */}
          <div 
            onClick={() => setShowGoalModal(true)}
            className="relative overflow-hidden bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-rose-500/10 dark:from-amber-950/60 dark:via-slate-800/80 dark:to-orange-950/60 p-4 rounded-2xl border border-amber-200/70 dark:border-amber-800/40 shadow-xs backdrop-blur-xs flex items-center justify-between gap-3 cursor-pointer hover:border-amber-400/60 transition-all group"
            title="ডেইলি পড়ার টার্গেট ও স্ট্রিক পরিবর্তন করতে ক্লিক করুন"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-md shadow-orange-500/30 shrink-0 group-hover:scale-105 transition-transform">
                <Flame className="w-6 h-6 text-amber-100" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1">
                    <span>{goalStats.streak} দিন স্ট্রিক!</span>
                  </h2>
                  {goalStats.todayCount >= goalStats.target && (
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300">
                      সম্পন্ন 🎉
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex-1 bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, Math.round((goalStats.todayCount / Math.max(1, goalStats.target)) * 100))}%` }}
                    />
                  </div>
                  <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 shrink-0">
                    {goalStats.todayCount}/{goalStats.target}
                  </span>
                </div>
              </div>
            </div>
            <div className="shrink-0 text-slate-400 group-hover:text-amber-500 transition-colors p-1">
              <Target className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      <main className="flex-1 max-w-3xl w-full mx-auto px-4 pt-1 pb-32 flex flex-col gap-4">
        
        {(rootFolders.length > 0 || cards.length > 0) && (
          <div className="flex flex-col gap-2 mb-2">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500 w-5 h-5 pointer-events-none" />
                <input 
                  type="text" 
                  placeholder="কার্ডের শিরোনাম দিয়ে খুঁজুন... (Filter by title)" 
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-11 pr-10 py-3 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm transition-all text-sm sm:text-base"
                />
                {search && (
                  <button
                    onClick={() => setSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-full transition-colors cursor-pointer"
                    title="সার্চ মুছুন"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              {filteredCards.length > 0 && (
                <div className="flex gap-2">
                  <button 
                    onClick={() => onStartStudy(0, true, (isSearching || hasTagFilter) ? filteredCards : undefined)}
                    className="flex items-center justify-center gap-2 bg-purple-100 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 hover:bg-purple-200 dark:hover:bg-purple-900/50 px-4 py-3 rounded-xl font-semibold transition-colors whitespace-nowrap"
                  >
                    <Shuffle className="w-5 h-5" /> শাফেল
                  </button>
                  <button 
                    onClick={() => onStartQuiz((isSearching || hasTagFilter) ? filteredCards : undefined)}
                    className="flex items-center justify-center gap-2 bg-indigo-100 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-200 dark:hover:bg-indigo-900/50 px-4 py-3 rounded-xl font-semibold transition-colors whitespace-nowrap"
                  >
                    <BookOpen className="w-5 h-5" /> কুইজ
                  </button>
                </div>
              )}
            </div>

            <TagFilterBar
              tags={allAvailableTags}
              activeTag={selectedTag}
              onSelectTag={setSelectedTag}
              totalCardsCount={cards.length}
            />

            {/* SRS Status Filter Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-none text-xs">
              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 shrink-0 mr-0.5">
                SRS স্ট্যাটাস:
              </span>
              <button
                type="button"
                onClick={() => setSrsFilter('all')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer shrink-0 ${
                  srsFilter === 'all'
                    ? 'bg-blue-600 text-white shadow-xs font-bold'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                সব ({cards.length})
              </button>
              <button
                type="button"
                onClick={() => setSrsFilter('due')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
                  srsFilter === 'due'
                    ? 'bg-rose-600 text-white shadow-xs font-bold'
                    : 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/50 border border-rose-200/60 dark:border-rose-800/40'
                }`}
              >
                <span>রিভিউ বাকি</span>
                <span className="px-1.5 py-0.2 rounded-full bg-white/20 text-[10px]">
                  {srsStats.dueCount}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setSrsFilter('new')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
                  srsFilter === 'new'
                    ? 'bg-sky-600 text-white shadow-xs font-bold'
                    : 'bg-sky-50 dark:bg-sky-950/50 text-sky-700 dark:text-sky-300 hover:bg-sky-100 dark:hover:bg-sky-900/50 border border-sky-200/60 dark:border-sky-800/40'
                }`}
              >
                <span>নতুন</span>
                <span className="px-1.5 py-0.2 rounded-full bg-white/20 text-[10px]">
                  {srsStats.newCount}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setSrsFilter('learning')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
                  srsFilter === 'learning'
                    ? 'bg-amber-600 text-white shadow-xs font-bold'
                    : 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900/50 border border-amber-200/60 dark:border-amber-800/40'
                }`}
              >
                <span>লার্নিং</span>
                <span className="px-1.5 py-0.2 rounded-full bg-white/20 text-[10px]">
                  {srsStats.learningCount}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setSrsFilter('mastered')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
                  srsFilter === 'mastered'
                    ? 'bg-emerald-600 text-white shadow-xs font-bold'
                    : 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 border border-emerald-200/60 dark:border-emerald-800/40'
                }`}
              >
                <span>আয়ত্তে</span>
                <span className="px-1.5 py-0.2 rounded-full bg-white/20 text-[10px]">
                  {srsStats.masteredCount}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setSrsFilter('favorite')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer shrink-0 flex items-center gap-1.5 ${
                  srsFilter === 'favorite'
                    ? 'bg-amber-500 text-slate-950 shadow-xs font-bold'
                    : 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900/50 border border-amber-200/60 dark:border-amber-800/40'
                }`}
              >
                <Star className={`w-3.5 h-3.5 ${srsFilter === 'favorite' ? 'fill-slate-950 text-slate-950' : 'fill-amber-400 text-amber-500'}`} />
                <span>প্রিয়</span>
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${srsFilter === 'favorite' ? 'bg-black/20 text-slate-950' : 'bg-amber-200/60 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200'}`}>
                  {favoriteCount}
                </span>
              </button>
            </div>

            {srsFilter !== 'all' && (
              <div className="flex items-center justify-between px-3 py-2 bg-blue-50 dark:bg-slate-800/80 rounded-xl border border-blue-200 dark:border-slate-700 text-xs text-blue-900 dark:text-blue-200 shadow-xs">
                <div className="flex items-center gap-2">
                  {srsFilter === 'favorite' ? (
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-400 shrink-0" />
                  ) : (
                    <BookOpen className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0" />
                  )}
                  <span>
                    {srsFilter === 'favorite' ? (
                      <>প্রিয় ফিল্টার: <strong>{filteredCards.length}</strong> টি স্টার দেওয়া প্রিয় কার্ড দেখানো হচ্ছে</>
                    ) : (
                      <>SRS ফিল্টার: <strong>{srsFilter === 'due' ? 'রিভিউ বাকি' : srsFilter === 'new' ? 'নতুন কার্ড' : srsFilter === 'learning' ? 'লার্নিং ফেজ' : 'আয়ত্তে কার্ড'}</strong> অনুযায়ী <strong>{filteredCards.length}</strong> টি কার্ড সাজানো হয়েছে</>
                    )}
                  </span>
                </div>
                <button
                  onClick={() => setSrsFilter('all')}
                  className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-semibold cursor-pointer shrink-0"
                >
                  সব দেখুন
                </button>
              </div>
            )}

            {selectedTag && (
              <div className="flex items-center justify-between px-3 py-2 bg-blue-50 dark:bg-slate-800/80 rounded-xl border border-blue-200 dark:border-slate-700 text-xs text-blue-900 dark:text-blue-200 shadow-xs">
                <div className="flex items-center gap-2">
                  <Tag className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0" />
                  <span>
                    ট্যাগ <strong>#{selectedTag}</strong> অনুযায়ী <strong>{filteredCards.length}</strong> টি কার্ড পাওয়া গেছে (সব ফোল্ডার জুড়ে)
                  </span>
                </div>
                <button
                  onClick={() => setSelectedTag(null)}
                  className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-semibold cursor-pointer shrink-0"
                >
                  সব দেখুন
                </button>
              </div>
            )}

            {isSearching && (
              <div className="flex items-center justify-between px-1 text-xs text-gray-600 dark:text-gray-400">
                <span>
                  <strong>"{search}"</strong> এর জন্য <strong>{filteredCards.length}</strong> টি কার্ড {filteredFolders.length > 0 ? `ও ${filteredFolders.length} টি ফোল্ডার` : ''} পাওয়া গেছে
                </span>
                <button
                  onClick={() => setSearch('')}
                  className="text-blue-600 dark:text-blue-400 hover:underline font-medium cursor-pointer"
                >
                  সার্চ ক্লিয়ার করুন
                </button>
              </div>
            )}
          </div>
        )}

        {rootFolders.length === 0 && cards.length === 0 ? (
          <div className="flex flex-col items-center justify-center flex-1 text-gray-400 opacity-70 mt-10">
            <BookOpen className="w-16 h-16 mb-4" />
            <p className="text-lg">কোনো ফোল্ডার বা কার্ড নেই!</p>
            <p className="text-sm text-center">নতুন তৈরি করতে নিচের বাটনে ক্লিক করুন।</p>
          </div>
        ) : filteredCards.length === 0 && filteredFolders.length === 0 ? (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            <Search className="w-12 h-12 mx-auto mb-3 opacity-30 text-gray-400" />
            <p className="text-base font-semibold text-gray-700 dark:text-gray-200">
              "{search}" শিরোনামের কোনো কার্ড বা ফোল্ডার পাওয়া যায়নি!
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              বানান সঠিক আছে কিনা দেখুন অথবা অন্য কোনো শব্দ দিয়ে অনুসন্ধান করুন।
            </p>
            <button
              onClick={() => setSearch('')}
              className="mt-4 px-4 py-2 text-xs font-semibold bg-blue-50 dark:bg-slate-800 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-100 dark:hover:bg-slate-700 transition-colors cursor-pointer"
            >
              সব কার্ড দেখুন
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Folders */}
            {filteredFolders.map((folder) => {
              const count = cards.filter(c => c.folderId === folder.id).length;
              return (
                <div key={folder.id} 
                  onClick={() => { if(isSelectionMode) toggleSelectFolder(folder.id); else onOpenFolder(folder.id); }} 
                  onPointerDown={(e) => {
                     // Don't trigger long press if it's right click or not main button
                     if (e.button !== 0) return;
                     startPress(folder.id, 'folder');
                  }}
                  onPointerUp={cancelPress}
                  onPointerLeave={cancelPress}
                  onPointerCancel={cancelPress}
                  onContextMenu={(e) => { 
                     // Prevent native context menu from triggering default browser behavior if we want custom long press
                     // e.preventDefault(); 
                  }}
                  className={`bg-white dark:bg-slate-800 p-3.5 sm:p-4 rounded-2xl shadow-xs hover:shadow-md border flex items-center justify-between cursor-pointer active:scale-[0.99] transition-all duration-150 group ${isSelectionMode && selectedFolders.includes(folder.id) ? 'border-blue-500 bg-blue-50/60 dark:bg-blue-950/40 ring-2 ring-blue-400' : 'border-slate-100 dark:border-slate-700/80'}`}>
                  <div className="flex items-center gap-3.5 overflow-hidden w-full pr-2">
                    {isSelectionMode && (
                      <input type="checkbox" checked={selectedFolders.includes(folder.id)} onChange={() => toggleSelectFolder(folder.id)} className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500" onClick={e => e.stopPropagation()} />
                    )}
                    <div className="w-12 h-12 bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center flex-shrink-0 shadow-xs border border-amber-200/50 dark:border-amber-700/30">
                      <FolderIcon className="w-6 h-6" fill="currentColor" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-800 dark:text-gray-100 line-clamp-2 break-words text-sm sm:text-base">{folder.name}</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{count} টি কার্ড</p>
                    </div>
                  </div>
                  <div className="relative shrink-0 flex items-center">
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveDropdown(activeDropdown === `folder-${folder.id}` ? null : `folder-${folder.id}`); }}
                      className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center bg-gray-50 dark:bg-slate-700/70 text-gray-600 dark:text-gray-300 rounded-xl hover:bg-gray-100 dark:hover:bg-slate-600 active:scale-95 transition-all"
                    >
                      <MoreVertical className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    {activeDropdown === `folder-${folder.id}` && (
                      <div className="absolute right-0 top-12 w-40 bg-white dark:bg-slate-800 rounded-xl shadow-xl py-2 text-gray-800 dark:text-gray-200 z-50 border border-gray-100 dark:border-slate-700">
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setMoveItemData({ id: folder.id, type: 'folder' }); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <FolderIcon className="w-4 h-4" /> মুভ করুন
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setDeleteType('folder'); setDeleteConfirmId(folder.id); }} className="w-full px-4 py-2 text-left text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 flex items-center gap-2 font-medium">
                           <Trash2 className="w-4 h-4" /> ডিলিট করুন
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Cards */}
            {filteredCards.map((card) => {
              const originalIndex = unassignedCards.findIndex(c => c.id === card.id);
              const studyIndex = (isSearching || hasTagFilter) ? filteredCards.findIndex(c => c.id === card.id) : originalIndex;
              return (
                <div key={card.id} 
                  onClick={() => { if(isSelectionMode) toggleSelectCard(card.id); }}
                  onPointerDown={(e) => {
                     if (e.button !== 0) return;
                     startPress(card.id, 'card');
                  }}
                  onPointerUp={cancelPress}
                  onPointerLeave={cancelPress}
                  onPointerCancel={cancelPress}
                  className={`bg-white dark:bg-slate-800 p-3.5 sm:p-4 rounded-2xl shadow-xs hover:shadow-md border flex items-center justify-between group cursor-pointer active:scale-[0.99] transition-all duration-150 ${isSelectionMode && selectedCards.includes(card.id) ? 'border-blue-500 bg-blue-50/60 dark:bg-blue-950/40 ring-2 ring-blue-400' : 'border-slate-100 dark:border-slate-700/80'}`}>
                  <div className="flex items-center gap-3.5 overflow-hidden w-full pr-2">
                    {isSelectionMode && (
                      <input type="checkbox" checked={selectedCards.includes(card.id)} onChange={() => toggleSelectCard(card.id)} className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500" onClick={e => e.stopPropagation()} />
                    )}
                    <div 
                      onClick={(e) => {
                        e.stopPropagation();
                        setPreviewCard(card);
                      }}
                      className="w-16 h-16 sm:w-18 sm:h-18 bg-slate-100 dark:bg-slate-700 rounded-xl overflow-hidden flex-shrink-0 border border-slate-200/80 dark:border-slate-700 shadow-xs relative cursor-pointer group/thumb hover:border-blue-400 dark:hover:border-blue-500 transition-colors"
                      title="কার্ড প্রিভিউ ও ফেভারিট দেখতে ক্লিক করুন"
                    >
                      <img src={card.image} alt={card.title} className="w-full h-full object-cover group-hover/thumb:scale-105 transition-transform" />
                      {card.favorite && (
                        <div className="absolute top-1 right-1 bg-amber-500 text-slate-950 p-0.5 rounded-full shadow-xs" title="প্রিয় কার্ড">
                          <Star className="w-2.5 h-2.5 fill-slate-950" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-gray-800 dark:text-gray-100 line-clamp-2 break-words text-sm sm:text-base">{card.title}</h3>
                      </div>
                      <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                        <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700/70 text-slate-600 dark:text-slate-300 border border-slate-200/60 dark:border-slate-600/50">
                          {(card.rectangles?.length || 0) + (card.pins?.length || 0)} টি আইটেম
                        </span>
                        {(() => {
                          const srsBadge = getCardSrsBadge(card);
                          return (
                            <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full border flex items-center gap-1 ${srsBadge.badgeClass}`} title={`ইন্টারভ্যাল: ${card.interval || 0} দিন | রিপিটেশন: ${card.repetition || 0} | ইজি ফ্যাক্টর: ${card.easeFactor || 2.5}`}>
                              {srsBadge.type === 'mastered' && <Trophy className="w-3 h-3 text-emerald-500" />}
                              {srsBadge.text}
                            </span>
                          );
                        })()}
                        {card.folderId && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenFolder(card.folderId!);
                            }}
                            className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-blue-50 dark:bg-slate-700 text-blue-600 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-slate-600 transition-colors cursor-pointer"
                            title="ফোল্ডারে যান"
                          >
                            <FolderIcon className="w-3 h-3" />
                            {folders.find(f => f.id === card.folderId)?.name || 'ফোল্ডার'}
                          </button>
                        )}
                        {card.tags && card.tags.length > 0 && (
                          <div className="flex items-center gap-1 flex-wrap">
                            {card.tags.map((t, idx) => (
                              <TagBadge
                                key={`${t}-${idx}`}
                                tag={t}
                                size="sm"
                                onClick={() => setSelectedTag(cleanTag(t))}
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="relative shrink-0 flex items-center gap-1">
                    {/* Star Favorite Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (onToggleFavorite) onToggleFavorite(card.id);
                      }}
                      className={`w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl transition-all cursor-pointer active:scale-90 ${
                        card.favorite
                          ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-500 hover:bg-amber-100 dark:hover:bg-amber-900/50'
                          : 'bg-gray-50 dark:bg-slate-700/70 text-gray-400 dark:text-gray-500 hover:text-amber-500 hover:bg-gray-100 dark:hover:bg-slate-600'
                      }`}
                      title={card.favorite ? 'প্রিয় তালিকা থেকে সরান' : 'প্রিয় কার্ড হিসেবে চিহ্নিত করুন'}
                    >
                      <Star className={`w-4 h-4 sm:w-5 sm:h-5 ${card.favorite ? 'fill-amber-400 text-amber-500' : ''}`} />
                    </button>
                    {/* Direct Edit Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onEdit(card.id);
                      }}
                      className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 rounded-xl hover:bg-indigo-100 dark:hover:bg-indigo-900/60 active:scale-95 transition-all shadow-2xs border border-indigo-100 dark:border-indigo-800/40"
                      title="কার্ড এডিট করুন"
                    >
                      <Edit3 className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); onStartStudy(studyIndex !== -1 ? studyIndex : 0, false, (isSearching || hasTagFilter) ? filteredCards : undefined); }}
                      className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-800/40 active:scale-95 transition-all shadow-xs"
                      title="স্টাডি করুন"
                    >
                      <BookOpen className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveDropdown(activeDropdown === `card-${card.id}` ? null : `card-${card.id}`); }}
                      className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center bg-gray-50 dark:bg-slate-700/70 text-gray-600 dark:text-gray-300 rounded-xl hover:bg-gray-100 dark:hover:bg-slate-600 active:scale-95 transition-all"
                    >
                      <MoreVertical className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    {activeDropdown === `card-${card.id}` && (
                      <div className="absolute right-0 top-12 w-44 bg-white dark:bg-slate-800 rounded-xl shadow-xl py-2 text-gray-800 dark:text-gray-200 z-50 border border-gray-100 dark:border-slate-700">
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setPreviewCard(card); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <FileText className="w-4 h-4 text-blue-500" /> প্রিভিউ দেখুন
                        </button>
                        <button onClick={(e) => {
                          e.stopPropagation();
                          setActiveDropdown(null);
                          if (onToggleFavorite) onToggleFavorite(card.id);
                        }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <Star className={`w-4 h-4 ${card.favorite ? 'fill-amber-400 text-amber-500' : 'text-gray-400'}`} />
                           {card.favorite ? 'প্রিয় থেকে সরান' : 'প্রিয় চিহ্নিত করুন'}
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); onEdit(card.id); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <Edit3 className="w-4 h-4" /> এডিট করুন
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setMoveItemData({ id: card.id, type: 'card' }); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <FolderIcon className="w-4 h-4" /> মুভ করুন
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setDeleteType('card'); setDeleteConfirmId(card.id); }} className="w-full px-4 py-2 text-left text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 flex items-center gap-2 font-medium">
                           <Trash2 className="w-4 h-4" /> ডিলিট করুন
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Modern Android / iOS Floating Action Dock */}
      <div className="fixed bottom-0 left-0 right-0 p-3 sm:p-4 pointer-events-none flex justify-center z-40 safe-bottom">
        <div className="pointer-events-auto bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg px-3 py-2 sm:px-4 sm:py-2.5 rounded-full shadow-2xl border border-slate-200/80 dark:border-slate-700/80 flex items-center gap-1.5 sm:gap-2.5 transition-all">
          <button
            onClick={() => setShowFolderModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-amber-950/40 hover:text-amber-600 dark:hover:text-amber-400 rounded-full font-semibold text-xs sm:text-sm active:scale-95 transition-all"
            title="নতুন ফোল্ডার"
          >
            <div className="w-7 h-7 rounded-full bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <FolderIcon className="w-4 h-4" />
            </div>
            <span className="hidden xs:inline">ফোল্ডার</span>
          </button>

          <button
            onClick={() => bulkFileInputRef.current?.click()}
            disabled={isUploading}
            title="একসাথে একাধিক ছবি দিয়ে কার্ড বানান"
            className="flex items-center gap-1.5 px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-600 dark:hover:text-emerald-400 rounded-full font-semibold text-xs sm:text-sm active:scale-95 transition-all disabled:opacity-50"
          >
            <div className="w-7 h-7 rounded-full bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              {isUploading ? <span className="animate-spin text-xs">⏳</span> : <Upload className="w-4 h-4" />}
            </div>
            <span className="hidden xs:inline">বাল্ক</span>
          </button>

          <div className="h-6 w-px bg-slate-200 dark:bg-slate-700 mx-0.5" />

          <button
            onClick={onCreateNew}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-4 py-2 sm:px-5 sm:py-2.5 rounded-full font-bold text-xs sm:text-sm shadow-md shadow-blue-500/25 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
            <span>নতুন কার্ড</span>
          </button>
        </div>
      </div>

      <BulkTagModal
        isOpen={showBulkTagModal}
        selectedCount={selectedCards.length}
        existingTags={allAvailableTags.map(t => t.name)}
        onApply={(tag) => {
          if (onAddTagToCards) {
            onAddTagToCards(selectedCards, tag);
            setAlertMsg(`${selectedCards.length} টি কার্ডে #${tag} ট্যাগ যুক্ত করা হয়েছে!`);
            cancelSelection();
          }
        }}
        onClose={() => setShowBulkTagModal(false)}
      />

      <SettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        cards={cards}
        folders={folders}
        darkMode={darkMode}
        toggleDarkMode={toggleDarkMode}
        onImport={onImport}
        setAlertMsg={setAlertMsg}
        onOpenHelp={() => setShowHelpModal(true)}
      />

      <OcclusionHelpModal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
      />

      <PWAInstallModal
        isOpen={showPwaInstallModal}
        onClose={() => setShowPwaInstallModal(false)}
      />

      {/* Universal File Export Modal (With Copy, Share, Download, Drive options and APK guidance) */}
      {fileExportPayload && (
        <FileExportModal
          isOpen={showFileExportModal}
          onClose={() => {
            setShowFileExportModal(false);
            setFileExportPayload(null);
          }}
          data={fileExportPayload.data}
          filename={fileExportPayload.filename}
          title={fileExportPayload.title}
          onOpenGoogleDrive={() => {
            setShowFileExportModal(false);
            openSyncModal('drive');
          }}
          onSuccess={(msg) => setAlertMsg(msg)}
        />
      )}

      {/* Universal In-App Restore Modal (Zero Permissions: Paste from clipboard or pick file) */}
      {showRestoreModal && (
        <div 
          className="fixed inset-0 z-[100000] flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200"
          onClick={() => setShowRestoreModal(false)}
        >
          <div 
            className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200/90 dark:border-slate-800 relative max-h-[92vh] overflow-y-auto text-slate-800 dark:text-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              type="button"
              onClick={() => setShowRestoreModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3.5 mb-4 pb-3.5 border-b border-slate-100 dark:border-slate-800">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-md shadow-orange-500/20 shrink-0">
                <Upload className="w-5 h-5 stroke-[2.5]" />
              </div>
              <div className="min-w-0 pr-6">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white truncate">
                  ডাটা ও ফ্ল্যাশকার্ড রিস্টোর (Restore)
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                  পূর্বে সেভ বা কপি করা ব্যাকআপ থেকে সবকিছু ফিরিয়ে আনুন
                </p>
              </div>
            </div>

            {/* Zero-Permission In-App Safeguard Banner */}
            <div className="mb-4 p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 dark:from-emerald-950/50 dark:via-teal-950/40 dark:to-emerald-950/50 border border-emerald-300 dark:border-emerald-800/80 text-emerald-950 dark:text-emerald-100 text-xs space-y-1.5 shadow-2xs">
              <div className="flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-300">
                <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>কোনো ফাইল বা স্টোরেজ পারমিশন লাগে না</span>
                <span className="text-[10px] bg-emerald-200/70 dark:bg-emerald-800/70 text-emerald-900 dark:text-emerald-200 px-2 py-0.2 rounded-full font-bold ml-auto">
                  ১০০% নিরাপদ
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-emerald-900/90 dark:text-emerald-200/90 leading-relaxed">
                আপনার ফোনের অ্যাপ সেটিংসে <strong>"Files and media"</strong> পারমিশন না থাকলে (বা শুধু ক্যামেরা দেখালে) কোনো চিন্তা নেই! নিচের বক্সে পূর্বে কপি করা ব্যাকআপ কোড পেস্ট করে দিলেই কোনো পারমিশন ছাড়াই আপনার সমস্ত ফ্ল্যাশকার্ড ও ফোল্ডার রিস্টোর হয়ে যাবে।
              </p>
            </div>

            {/* Paste Button & Textarea */}
            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <ClipboardPaste className="w-4 h-4 text-amber-500" />
                  <span>ব্যাকআপ কোড পেস্ট করুন:</span>
                </label>
                <button
                  type="button"
                  onClick={handlePasteFromClipboard}
                  disabled={isPastingFromClipboard}
                  className="px-3 py-1.5 bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 dark:hover:bg-blue-900/50 text-blue-600 dark:text-blue-300 border border-blue-200 dark:border-blue-800 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
                >
                  <ClipboardPaste className="w-3.5 h-3.5" />
                  <span>ক্লিপবোর্ড থেকে আনুন</span>
                </button>
              </div>

              <textarea
                value={pastedRestoreJson}
                onChange={(e) => setPastedRestoreJson(e.target.value)}
                placeholder="এখানে আপনার ব্যাকআপ JSON কোড পেস্ট করুন..."
                rows={6}
                className="w-full p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs font-mono focus:ring-2 focus:ring-amber-500 focus:outline-hidden resize-none"
              />

              <button
                type="button"
                onClick={handleConfirmPasteRestore}
                disabled={!pastedRestoreJson.trim()}
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 active:scale-98 disabled:opacity-50 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md shadow-orange-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4 stroke-[2.5]" />
                <span>রিস্টোর সম্পন্ন করুন</span>
              </button>
            </div>

            {/* Alternative: Pick from file manager */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-center">
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2">
                অথবা আপনার ডিভাইসে যদি .json ফাইল সেভ করা থাকে:
              </p>
              <button
                type="button"
                onClick={() => {
                  setShowRestoreModal(false);
                  fileInputRef.current?.click();
                }}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5 text-slate-500" />
                <span>ডিভাইসের ফাইল ম্যানেজার থেকে বেছে নিন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Daily Goal & Habit Modal */}
      {showGoalModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-[9999] p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-800 rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-gray-100 dark:border-slate-700 text-slate-800 dark:text-slate-100">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
                  <Target className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-base">ডেইলি পড়ার টার্গেট</h3>
              </div>
              <button 
                onClick={() => setShowGoalModal(false)}
                className="p-1.5 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200/60 dark:border-amber-800/30 flex items-center gap-3 mb-4">
              <Flame className="w-8 h-8 text-amber-500 shrink-0" />
              <div>
                <div className="font-bold text-sm text-amber-900 dark:text-amber-200">
                  {goalStats.streak} দিনের ধারাবাহিক স্ট্রিক! 🔥
                </div>
                <div className="text-xs text-amber-700 dark:text-amber-400">
                  আজকে {goalStats.todayCount} টি কার্ড রিভিশন দেওয়া হয়েছে।
                </div>
              </div>
            </div>

            <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">
              প্রতিদিন কতটি কার্ড পড়ার লক্ষ্য রাখতে চান?
            </label>

            {/* Quick target selector buttons */}
            <div className="grid grid-cols-4 gap-2 mb-3">
              {[5, 10, 15, 20, 25, 30, 40, 50].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setTargetGoalInput(num)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    targetGoalInput === num
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-600'
                  }`}
                >
                  {num} টি
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 mb-5">
              <input
                type="number"
                min="1"
                max="200"
                value={targetGoalInput}
                onChange={(e) => setTargetGoalInput(Math.max(1, parseInt(e.target.value) || 1))}
                className="flex-1 px-3 py-2 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl text-center font-bold text-lg outline-none focus:border-amber-500"
              />
              <span className="text-xs font-semibold text-gray-500">কার্ড / প্রতিদিন</span>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowGoalModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 text-xs font-bold text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={handleSaveGoalTarget}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-md shadow-amber-500/20 active:scale-95 transition-all"
              >
                সেভ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Export Options Modal (Full JSON vs Anki) */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-[9999] p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-800 rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-gray-100 dark:border-slate-700 text-slate-800 dark:text-slate-100">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                  <Download className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-base">ফাইল ব্যাকআপ ও এক্সপোর্ট</h3>
              </div>
              <button 
                onClick={() => setShowExportModal(false)}
                className="p-1.5 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
              আপনার ফ্ল্যাশকার্ডগুলো কোন ফরম্যাটে সেভ বা এক্সপোর্ট করতে চান?
            </p>

            <div className="flex flex-col gap-3 mb-5">
              {/* Option 1: Full JSON Backup */}
              <div 
                onClick={() => {
                  setShowExportModal(false);
                  handleExport();
                }}
                className="p-3.5 rounded-xl border border-gray-200 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-500 bg-gray-50/70 dark:bg-slate-900/60 hover:bg-blue-50/50 dark:hover:bg-blue-950/30 transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300 flex items-center justify-center shrink-0">
                    <Download className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-sm text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400">
                      সম্পূর্ণ JSON ব্যাকআপ
                    </div>
                    <div className="text-[11px] text-gray-500 dark:text-gray-400">
                      সব ছবি, ফোল্ডার ও পিন সহ ১০০% ডাটা সুরক্ষিত রাখতে
                    </div>
                  </div>
                </div>
              </div>

              {/* Option 2: Anki Deck Export */}
              <div 
                onClick={handleExportAnki}
                className="p-3.5 rounded-xl border border-gray-200 dark:border-slate-700 hover:border-purple-500 dark:hover:border-purple-500 bg-gray-50/70 dark:bg-slate-900/60 hover:bg-purple-50/50 dark:hover:bg-purple-950/30 transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-300 flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-sm text-slate-900 dark:text-slate-100 group-hover:text-purple-600 dark:group-hover:text-purple-400">
                      Anki ডেক এক্সপোর্ট (.txt)
                    </div>
                    <div className="text-[11px] text-gray-500 dark:text-gray-400">
                      Anki বা AnkiDroid এ সরাসরি Import করে পড়ার জন্য
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowExportModal(false)}
              className="w-full py-2.5 rounded-xl border border-gray-200 dark:border-slate-700 text-xs font-bold text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>
      )}

      {previewCard && (
        <CardPreviewModal
          card={cards.find(c => c.id === previewCard.id) || previewCard}
          folderName={folders.find(f => f.id === previewCard.folderId)?.name}
          onClose={() => setPreviewCard(null)}
          onEdit={() => {
            const id = previewCard.id;
            setPreviewCard(null);
            onEdit(id);
          }}
          onStartStudy={() => {
            const c = previewCard;
            setPreviewCard(null);
            const idx = cards.findIndex(item => item.id === c.id);
            onStartStudy(idx !== -1 ? idx : 0, false, [c]);
          }}
          onToggleFavorite={onToggleFavorite ? () => onToggleFavorite(previewCard.id) : undefined}
        />
      )}

      {/* Native Mobile Bottom Navigation Bar (APK Look & Feel) */}
      <nav className={`md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 border-t border-slate-200/80 dark:border-slate-800 shadow-[0_-4px_24px_rgba(0,0,0,0.12)] px-2 py-1.5 safe-bottom items-center justify-around ${
        showPwaInstallModal || showSettingsModal || showHelpModal || showExportModal || showGoalModal || previewCard ? 'hidden' : 'flex'
      }`}>
        {/* Tab 1: Dashboard / All */}
        <button
          type="button"
          onClick={() => {
            triggerHaptic('light');
            setSrsFilter('all');
            setSelectedTag(null);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all cursor-pointer ${
            srsFilter === 'all'
              ? 'text-blue-600 dark:text-blue-400 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Layers className="w-5 h-5" />
          <span className="text-[10px] mt-0.5 font-medium">সব কার্ড</span>
        </button>

        {/* Tab 2: Study / Due */}
        <button
          type="button"
          onClick={() => {
            triggerHaptic('medium');
            const targetCards = dueCards.length > 0 ? dueCards : cards;
            if (targetCards.length > 0) {
              onStartStudy(0, false, targetCards);
            }
          }}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all relative cursor-pointer ${
            dueCards.length > 0
              ? 'text-amber-600 dark:text-amber-400 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          {dueCards.length > 0 && (
            <span className="absolute top-0 right-1 px-1.5 py-0.2 rounded-full bg-amber-500 text-white text-[9px] font-bold ring-2 ring-white dark:ring-slate-900 animate-pulse">
              {dueCards.length}
            </span>
          )}
          <BookOpen className="w-5 h-5" />
          <span className="text-[10px] mt-0.5 font-medium">পড়া শুরু</span>
        </button>

        {/* Tab 3: Center Elevated Button: Create New AI Card */}
        <div className="-mt-6">
          <button
            type="button"
            onClick={() => {
              triggerHaptic('success');
              onCreateNew();
            }}
            className="w-13 h-13 rounded-full bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white flex items-center justify-center shadow-lg shadow-indigo-500/40 active:scale-90 transition-all cursor-pointer border-3 border-white dark:border-slate-900"
            title="নতুন AI ফ্ল্যাশকার্ড তৈরি করুন"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>

        {/* Tab 4: Starred / Favorites */}
        <button
          type="button"
          onClick={() => {
            triggerHaptic('light');
            setSrsFilter(srsFilter === 'favorite' ? 'all' : 'favorite');
          }}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all cursor-pointer ${
            srsFilter === 'favorite'
              ? 'text-amber-500 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Star className={`w-5 h-5 ${srsFilter === 'favorite' ? 'fill-amber-500 text-amber-500' : ''}`} />
          <span className="text-[10px] mt-0.5 font-medium">প্রিয় ({cards.filter(c => c.favorite).length})</span>
        </button>

        {/* Tab 5: Settings */}
        <button
          type="button"
          onClick={() => {
            triggerHaptic('light');
            setShowSettingsModal(true);
          }}
          className="flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-all cursor-pointer"
        >
          <SettingsIcon className="w-5 h-5" />
          <span className="text-[10px] mt-0.5 font-medium">সেটিংস</span>
        </button>
      </nav>
    </div>
  );
}
