import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import {
  HelpCircle,
  X,
  Square,
  Eye,
  EyeOff,
  Sparkles,
  MousePointer,
  CheckCircle2,
  Layers,
  ArrowRight,
  Hand,
  MapPin,
  Crop as CropIcon,
  RotateCw,
  BookOpen
} from 'lucide-react';

interface OcclusionHelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'guide' | 'interactive' | 'shortcuts';
}

export default function OcclusionHelpModal({
  isOpen,
  onClose,
  defaultTab = 'interactive'
}: OcclusionHelpModalProps) {
  const [activeTab, setActiveTab] = useState<'interactive' | 'steps' | 'tips'>(defaultTab === 'guide' ? 'steps' : 'interactive');
  
  // Interactive Simulator States
  const [demoMasks, setDemoMasks] = useState<{ [key: string]: boolean }>({
    mask1: false, // false = hidden (masked), true = revealed
    mask2: false,
    mask3: true
  });

  const toggleDemoMask = (key: string) => {
    setDemoMasks(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleGotIt = () => {
    try {
      localStorage.setItem('seen_occlusion_guide', 'true');
    } catch (e) {
      // ignore storage error
    }
    onClose();
  };

  if (!isOpen || typeof document === 'undefined') return null;

  const modalNode = (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-800 rounded-3xl max-w-lg w-full p-4 sm:p-6 shadow-2xl border border-slate-200 dark:border-slate-700 relative max-h-[92vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-3.5 right-3.5 p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full transition-colors cursor-pointer z-10"
          title="বন্ধ করুন"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100 dark:border-slate-700/80 shrink-0">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 border border-blue-100 dark:border-blue-800/40 shadow-2xs">
            <HelpCircle className="w-6 h-6" />
          </div>
          <div className="min-w-0 pr-6">
            <div className="flex items-center gap-1.5">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white truncate">
                ইমেজ অক্লুশন নির্দেশিকা
              </h2>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 shrink-0">
                টিউটোরিয়াল
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
              ছবির নির্দিষ্ট অংশ ঢেকে পড়ার বৈজ্ঞানিক পদ্ধতি (Active Recall)
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex p-1 bg-slate-100 dark:bg-slate-900/60 rounded-xl my-3 text-xs font-semibold shrink-0 gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('interactive')}
            className={`flex-1 py-1.5 px-2 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'interactive'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-500" />
            <span>ডেমো পরীক্ষা</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('steps')}
            className={`flex-1 py-1.5 px-2 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'steps'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-indigo-500" />
            <span>৩টি সহজ ধাপ</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('tips')}
            className={`flex-1 py-1.5 px-2 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'tips'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Hand className="w-3.5 h-3.5 text-amber-500" />
            <span>জরুরি টিপস</span>
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-3.5 text-slate-700 dark:text-slate-300">
          
          {/* TAB 1: INTERACTIVE DEMO SIMULATOR */}
          {activeTab === 'interactive' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-2xl border border-blue-200 dark:border-blue-900/60 text-xs">
                <p className="text-slate-800 dark:text-slate-200 font-medium leading-relaxed">
                  <span className="font-bold text-blue-600 dark:text-blue-400">ইমেজ অক্লুশন কী?</span> বইয়ের পাতা, ডায়াগ্রাম, চার্ট বা মানচিত্রের লেবেলগুলোর ওপর রঙিন বক্স (মাস্ক) দিয়ে ঢেকে দেওয়া হয়। নিচে একটি নমুনা কার্ড আছে—মাস্কে ট্যাপ করে দেখুন:
                </p>
              </div>

              {/* Interactive Mini Card Canvas */}
              <div className="relative rounded-2xl overflow-hidden border border-slate-300 dark:border-slate-700 bg-slate-900 p-4 select-none shadow-inner min-h-[220px] flex flex-col justify-between">
                {/* Visual Diagram Representation */}
                <div className="flex items-center justify-between text-slate-400 text-[11px] pb-2 border-b border-slate-800">
                  <span className="flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5 text-blue-400" />
                    নমুনা চিত্র: উদ্ভিদ কোষ (Plant Cell)
                  </span>
                  <span className="text-[10px] text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-full font-mono">
                    ক্লিক করে উত্তর দেখুন
                  </span>
                </div>

                {/* Simulated Diagram Area with Occlusion Boxes */}
                <div className="relative my-4 p-3 bg-slate-800/80 rounded-xl border border-slate-700/60 flex flex-col gap-3">
                  
                  {/* Item 1 */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-300">১. কোষের শক্তিঘর কোনটি?</span>
                    <div
                      onClick={() => toggleDemoMask('mask1')}
                      className={`relative px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all active:scale-95 shadow-xs flex items-center justify-center min-w-[120px] ${
                        demoMasks.mask1
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/60'
                          : 'bg-blue-600 hover:bg-blue-500 text-white animate-pulse'
                      }`}
                    >
                      {demoMasks.mask1 ? (
                        <span className="flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> মাইটোকন্ড্রিয়া
                        </span>
                      ) : (
                        <span className="flex items-center gap-1">
                          <EyeOff className="w-3.5 h-3.5 opacity-75" /> ? মাস্ক ১ (ট্যাপ করুন)
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Item 2 */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-300">২. সালোকসংশ্লেষণকারী অঙ্গাণু:</span>
                    <div
                      onClick={() => toggleDemoMask('mask2')}
                      className={`relative px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all active:scale-95 shadow-xs flex items-center justify-center min-w-[120px] ${
                        demoMasks.mask2
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/60'
                          : 'bg-indigo-600 hover:bg-indigo-500 text-white animate-pulse'
                      }`}
                    >
                      {demoMasks.mask2 ? (
                        <span className="flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> ক্লোরোপ্লাস্ট
                        </span>
                      ) : (
                        <span className="flex items-center gap-1">
                          <EyeOff className="w-3.5 h-3.5 opacity-75" /> ? মাস্ক ২ (ট্যাপ করুন)
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Item 3 */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-300">৩. কোষের নিয়ন্ত্রণ কেন্দ্র:</span>
                    <div
                      onClick={() => toggleDemoMask('mask3')}
                      className={`relative px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all active:scale-95 shadow-xs flex items-center justify-center min-w-[120px] ${
                        demoMasks.mask3
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/60'
                          : 'bg-purple-600 hover:bg-purple-500 text-white'
                      }`}
                    >
                      {demoMasks.mask3 ? (
                        <span className="flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> নিউক্লিয়াস
                        </span>
                      ) : (
                        <span className="flex items-center gap-1">
                          <EyeOff className="w-3.5 h-3.5 opacity-75" /> ? মাস্ক ৩
                        </span>
                      )}
                    </div>
                  </div>

                </div>

                <div className="text-[11px] text-center text-slate-400 flex items-center justify-center gap-1">
                  <MousePointer className="w-3.5 h-3.5 text-blue-400" />
                  পড়ার সময় এভাবে উত্তর ভেবে মাস্কে ট্যাপ করলেই সঠিক উত্তর প্রকাশ পায়!
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: 3 STEP GUIDE */}
          {activeTab === 'steps' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              
              {/* Step 1 */}
              <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-700/40 border border-slate-200/80 dark:border-slate-700">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white font-black text-sm flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                  ১
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    ছবি আপলোড বা ছবি তুলুন
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    বইয়ের যেকোনো পৃষ্ঠা, ডায়াগ্রাম, চার্ট বা মেডিকেল নোটের ছবি তুলুন। প্রয়োজন হলে <span className="font-semibold text-indigo-600 dark:text-indigo-400">ক্রপ</span> বা <span className="font-semibold text-teal-600 dark:text-teal-400">রোটেট</span> টুল দিয়ে ছবিটি সোজা করে নিন।
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-700/40 border border-slate-200/80 dark:border-slate-700">
                <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white font-black text-sm flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                  ২
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    মাস্ক আঁকুন (Draw Masks)
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    ছবির যে শব্দ বা লেবেলগুলো আপনি মুখস্থ রাখতে চান, আঙুল দিয়ে সেটির ওপর আয়তাকার বক্স টানুন। চাইলে <span className="font-semibold text-purple-600 dark:text-purple-400">অটো-ডিটেক্ট</span> বাটনে ক্লিক করে AI দিয়ে এক ক্লিকে সব লেখা স্বয়ংক্রিয়ভাবে শনাক্ত করতে পারেন।
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-700/40 border border-slate-200/80 dark:border-slate-700">
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white font-black text-sm flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                  ৩
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    অনুশীলন ও সেলফ-টেস্টিং
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    কার্ড সেভ করার পর <strong>স্টাডি বা কুইজ মোড</strong> চালু করুন। মাস্কগুলো লুকানো থাকবে। উত্তর মনে করার চেষ্টা করে মাস্কে স্পর্শ করে নিজের মেমোরি ঝালিয়ে নিন।
                  </p>
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: PRO TIPS & SHORTCUTS */}
          {activeTab === 'tips' && (
            <div className="space-y-2.5 animate-in fade-in duration-200">
              
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/90 dark:border-amber-900/50 flex items-start gap-2.5">
                <Hand className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <strong className="text-slate-900 dark:text-white">প্যান বনাম আঁকা মোড:</strong>
                  <p className="text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
                    বড় ছবি হলে স্ক্রিন উপরে-নিচে সরাতে <strong>"প্যান"</strong> টুলে যান। আর নতুন বক্স আঁকতে <strong>"আঁকুন / মাস্ক"</strong> টুলে থাকুন।
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200/90 dark:border-blue-900/50 flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <strong className="text-slate-900 dark:text-white">পিন টুল (Pin Mode):</strong>
                  <p className="text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
                    বড় বক্সের বদলে ছোট পয়েন্টে ক্লু বসাতে "পিন" টুল ব্যবহার করে নির্দিষ্ট স্থানে ট্যাপ করুন।
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200/90 dark:border-purple-900/50 flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <strong className="text-slate-900 dark:text-white">অটো-ডিটেক্ট (OCR):</strong>
                  <p className="text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
                    ছবিতে প্রচুর লেখা থাকলে এক ক্লিকেই সব টেক্সট বক্স শনাক্ত করতে পারেন।
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/90 dark:border-emerald-900/50 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <strong className="text-slate-900 dark:text-white">প্রিভিউ মোড:</strong>
                  <p className="text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
                    কার্ড সেভ করার আগে চোখ (Eye) আইকনে ক্লিক করে স্টাডি মোডের অভিজ্ঞতা এখনই টেস্ট করে নিতে পারেন।
                  </p>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={() => {
              if (activeTab === 'interactive') setActiveTab('steps');
              else if (activeTab === 'steps') setActiveTab('tips');
              else setActiveTab('interactive');
            }}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>পরবর্তী অংশ</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={handleGotIt}
            className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 active:scale-95 text-white rounded-xl font-bold text-xs sm:text-sm shadow-md shadow-blue-500/25 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <span>বুঝতে পেরেছি</span>
            <CheckCircle2 className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );

  return createPortal(modalNode, document.body);
}
