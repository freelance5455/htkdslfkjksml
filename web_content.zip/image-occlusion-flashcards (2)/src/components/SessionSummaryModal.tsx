import React from 'react';
import { Trophy, CheckCircle, RotateCcw, Home, Sparkles, Award, ArrowRight, Flame, BarChart3, AlertCircle } from 'lucide-react';
import { Card } from '../types';

interface SessionSummaryModalProps {
  cards: Card[];
  againCardIds: number[];
  revealedCount: number;
  totalMaskCount: number;
  durationSeconds: number;
  onReviewWeakSpots: (weakCards: Card[]) => void;
  onRestartAll: () => void;
  onFinish: () => void;
}

export default function SessionSummaryModal({
  cards,
  againCardIds,
  revealedCount,
  totalMaskCount,
  durationSeconds,
  onReviewWeakSpots,
  onRestartAll,
  onFinish,
}: SessionSummaryModalProps) {
  const weakCards = cards.filter(c => againCardIds.includes(c.id));
  const accuracyPercent = Math.min(
    100,
    totalMaskCount > 0
      ? Math.round(((totalMaskCount - againCardIds.length) / totalMaskCount) * 100)
      : 100
  );

  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    if (mins === 0) return `${s} সেকেন্ড`;
    return `${mins} মিনিট ${s} সেকেন্ড`;
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col">
        {/* Header with celebration banner */}
        <div className="relative p-6 sm:p-8 text-center bg-gradient-to-b from-indigo-950/60 to-slate-900 border-b border-slate-800">
          <div className="inline-flex p-4 rounded-3xl bg-amber-500/10 border border-amber-500/30 text-amber-400 mb-3 shadow-inner shadow-amber-500/20 animate-bounce">
            <Trophy className="w-10 h-10" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            দারুণ পড়াশোনা! সেশন সম্পন্ন 🎉
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            আপনি সফলভাবে এই স্টাডি সেশনের সব কন্টেন্ট অনুশীলন করেছেন
          </p>
        </div>

        {/* Stats Bento Grid */}
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/60">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">মোট কার্ড</span>
              <span className="text-xl sm:text-2xl font-black text-blue-400 font-mono">
                {cards.length}
              </span>
            </div>

            <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/60">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">শনাক্ত মাস্ক</span>
              <span className="text-xl sm:text-2xl font-black text-emerald-400 font-mono">
                {revealedCount}
              </span>
            </div>

            <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/60">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">মোট সময়</span>
              <span className="text-sm sm:text-base font-bold text-amber-300 font-mono mt-1 block">
                {formatDuration(durationSeconds)}
              </span>
            </div>
          </div>

          {/* Weak spots notification */}
          {weakCards.length > 0 ? (
            <div className="p-3.5 bg-rose-950/40 border border-rose-500/30 rounded-2xl flex items-center justify-between gap-3 text-xs sm:text-sm text-rose-200">
              <div className="flex items-center gap-2.5">
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                <div>
                  <span className="font-bold block">
                    {weakCards.length} টি কার্ড আবার ঝালাই করা দরকার
                  </span>
                  <span className="text-[11px] text-rose-300/80">
                    এগুলোতে 'আবার (Again)' চিহ্নিত করা হয়েছিল
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onReviewWeakSpots(weakCards)}
                className="px-3 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs cursor-pointer shadow-md transition-all active:scale-95 shrink-0"
              >
                এখনই রিভিশন
              </button>
            </div>
          ) : (
            <div className="p-3.5 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl flex items-center gap-2.5 text-xs sm:text-sm text-emerald-200">
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>
                সবগুলো আইটেম খুব চমৎকারভাবে মনে রাখতে পেরেছেন! কোনো দুর্বল অংশ পাওয়া যায়নি।
              </span>
            </div>
          )}

          {/* Motivational Tip */}
          <div className="p-3 bg-slate-800/50 rounded-xl text-[11px] text-slate-400 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              স্পেসড রিপিটিশন নিয়ম অনুযায়ী কাল বা পরবর্তী নির্ধারিত দিনে স্বয়ংক্রিয়ভাবে আবার মনে করিয়ে দেওয়া হবে।
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-6 bg-slate-850 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={onRestartAll}
            className="w-full sm:w-auto px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 border border-slate-700 cursor-pointer transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>সেশন পুনরায় শুরু</span>
          </button>

          <button
            type="button"
            onClick={onFinish}
            className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 cursor-pointer transition-all active:scale-95"
          >
            <Home className="w-4 h-4" />
            <span>ড্যাশবোর্ডে সমাপ্ত করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
}
