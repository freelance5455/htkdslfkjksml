import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { User } from 'firebase/auth';
import {
  Cloud,
  CheckCircle2,
  RefreshCw,
  LogOut,
  X,
  Loader2,
  ShieldCheck,
  Smartphone,
  WifiOff,
  User as UserIcon,
  HardDrive,
  Download,
  Upload,
  Globe,
  Sparkles,
  Copy,
  ClipboardPaste,
  FileText,
  History,
  AlertCircle,
  Search
} from 'lucide-react';
import { get, set } from 'idb-keyval';
import { googleSignIn, logout, initAuth, isDriveTokenValid } from '../lib/firebase';
import { syncService } from '../lib/firestoreSync';
import { 
  syncToDrive, 
  loadFromDrive, 
  getLastDriveBackupTime, 
  getDriveRevisionsList, 
  restoreSpecificRevision, 
  DriveRevisionItem 
} from '../lib/drive';
import { appUpdateService } from '../lib/appUpdate';
import { saveOrShareJSON, copyTextToClipboard } from '../lib/fileSaveUtils';
import FileExportModal from './FileExportModal';
import { Card, Folder, SyncStatus } from '../types';

interface SyncButtonProps {
  cards?: Card[];
  folders?: Folder[];
  onDataLoaded?: (data: { cards: Card[]; folders: Folder[] }) => void;
  setAlert?: (msg: string) => void;
  className?: string;
}

export function SyncStatusIndicator(props: SyncButtonProps) {
  return <SyncButton {...props} />;
}

export const openSyncModal = (tab: 'cloud' | 'update' | 'drive' | 'file' = 'cloud') => {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('open-sync-modal', { detail: { tab } }));
  }
};

export const openDeepRecoveryModal = () => {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('open-deep-recovery-modal'));
  }
};

export default function SyncButton({ cards, folders, onDataLoaded, setAlert, className }: SyncButtonProps) {
  const [user, setUser] = useState<User | null>(null);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(syncService.getStatus());
  const [lastSyncedAt, setLastSyncedAt] = useState<number | null>(syncService.getLastSyncedAt());
  const [lastDriveBackup, setLastDriveBackup] = useState<number | null>(getLastDriveBackupTime());
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);
  
  const [isActionPending, setIsActionPending] = useState(false);
  const [isDriveBackingUp, setIsDriveBackingUp] = useState(false);
  const [isDriveRestoring, setIsDriveRestoring] = useState(false);
  const [isDriveConnected, setIsDriveConnected] = useState<boolean>(isDriveTokenValid());
  const [isCheckingAppUpdate, setIsCheckingAppUpdate] = useState(false);
  
  const [isInitializing, setIsInitializing] = useState(true);
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'cloud' | 'update' | 'drive' | 'file'>('cloud');
  
  const [showPasteModal, setShowPasteModal] = useState(false);
  const [pastedJson, setPastedJson] = useState('');
  const [isExportingFile, setIsExportingFile] = useState(false);
  const [isCopyingBackup, setIsCopyingBackup] = useState(false);
  const [showFileExportModal, setShowFileExportModal] = useState(false);
  const [fileExportPayload, setFileExportPayload] = useState<{ filename: string; data: any; title: string } | null>(null);

  const [showRevisionsModal, setShowRevisionsModal] = useState(false);
  const [revisionsList, setRevisionsList] = useState<DriveRevisionItem[]>([]);
  const [isLoadingRevisions, setIsLoadingRevisions] = useState(false);
  const [restoringRevisionId, setRestoringRevisionId] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isFirstMount = useRef(true);

  // Prevent background scroll when modal is open
  useEffect(() => {
    if (showSyncModal) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow;
      };
    }
  }, [showSyncModal]);

  // 1. Subscribe to SyncService status updates
  useEffect(() => {
    const unsubSync = syncService.subscribe((status, lastSynced) => {
      setSyncStatus(status);
      if (lastSynced) setLastSyncedAt(lastSynced);
    });

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const handleOpenModalEvent = (e: Event) => {
      const custom = e as CustomEvent<{ tab?: 'cloud' | 'update' | 'drive' | 'file' }>;
      if (custom.detail?.tab) {
        setActiveTab(custom.detail.tab);
      }
      setShowSyncModal(true);
    };

    const handleOpenDeepRecoveryEvent = () => {
      setActiveTab('drive');
      setShowSyncModal(true);
      handleOpenDeepRecovery();
    };

    window.addEventListener('open-sync-modal', handleOpenModalEvent);
    window.addEventListener('open-deep-recovery-modal', handleOpenDeepRecoveryEvent);

    setLastDriveBackup(getLastDriveBackupTime());

    return () => {
      unsubSync();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('open-sync-modal', handleOpenModalEvent);
      window.removeEventListener('open-deep-recovery-modal', handleOpenDeepRecoveryEvent);
    };
  }, []);

  // 2. Initialize Firebase Auth and handle initial auto-restore
  useEffect(() => {
    const unsubscribe = initAuth(
      async (u) => {
        setUser(u);
        setIsInitializing(false);

        // If user logged in and first time or app reload, perform auto-sync & auto-restore
        if (u && isFirstMount.current) {
          isFirstMount.current = false;
          try {
            const res = await syncService.syncNow();
            if (res) {
              if (res.cards.length > 0 || res.folders.length > 0) {
                onDataLoaded?.({ cards: res.cards, folders: res.folders });
              }
              if (res.restoredFromCloud) {
                setAlert?.(`ক্লাউড থেকে আপনার সমস্ত কার্ড (${res.cards.length}টি) ও ফোল্ডার উদ্ধার করা হয়েছে!`);
              }
            }
          } catch (e) {
            console.warn('Initial auto-sync notice:', e);
          }
        }
      },
      () => {
        setUser(null);
        setIsInitializing(false);
      }
    );

    return () => unsubscribe();
  }, [onDataLoaded, setAlert]);

  // Helper to ensure full cards and folders data
  const getFullData = async (): Promise<{ cards: Card[]; folders: Folder[] }> => {
    let currentCards = cards;
    let currentFolders = folders;
    if (!currentCards || currentCards.length === 0) {
      currentCards = (await get<Card[]>('flashcards')) || [];
    }
    if (!currentFolders || currentFolders.length === 0) {
      currentFolders = (await get<Folder[]>('folders')) || [];
    }
    return { cards: currentCards, folders: currentFolders };
  };

  // Google Sign-In with Firestore auto-sync & auto-restore
  const handleLogin = async () => {
    try {
      setIsActionPending(true);
      const result = await googleSignIn();
      if (result?.user) {
        setUser(result.user);
        setIsDriveConnected(true);

        // Fetch cloud data and restore immediately
        try {
          const syncResult = await syncService.syncNow();
          if (syncResult) {
            if (syncResult.cards.length > 0 || syncResult.folders.length > 0) {
              onDataLoaded?.({ cards: syncResult.cards, folders: syncResult.folders });
            }
            setAlert?.(`${result.user.displayName || 'ব্যবহারকারী'} হিসেবে গুগল লগইন সফল! ক্লাউড থেকে সব ডাটা রিস্টোর ও স্বয়ংক্রিয় সিঙ্ক সক্রিয় হয়েছে।`);
          } else {
            setAlert?.(`${result.user.displayName || 'ব্যবহারকারী'} হিসেবে লগইন সম্পন্ন! অটোমেটিক ক্লাউড ব্যাকআপ সক্রিয়।`);
          }
        } catch (syncErr) {
          console.warn('Initial Firestore sync notice:', syncErr);
          setAlert?.(`${result.user.displayName || 'ব্যবহারকারী'} হিসেবে লগইন সম্পন্ন। আপনার ডাটা ডিভাইসে নিরাপদ রয়েছে।`);
        }
      }
    } catch (err: any) {
      if (
        err?.code === 'auth/popup-closed-by-user' ||
        err?.code === 'auth/cancelled-popup-request' ||
        err?.message?.includes('popup-closed-by-user')
      ) {
        // User closed or dismissed popup
      } else if (err?.code === 'auth/popup-blocked' || err?.message === 'POPUP_BLOCKED') {
        setAlert?.('ব্রাউজারের পপ-আপ ব্লক করা আছে। দয়া করে ব্রাউজার সেটিংস থেকে Pop-ups অনুমোদন (Allow) করুন।');
      } else {
        console.error('Login error:', err);
        setAlert?.('লগইন করতে সমস্যা হয়েছে। ইন্টারনেট সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।');
      }
    } finally {
      setIsActionPending(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setUser(null);
      setIsDriveConnected(false);
      setShowSyncModal(false);
      setAlert?.('লগআউট সফল হয়েছে। আপনার সমস্ত ডাটা ডিভাইসের মেমরিতে নিরাপদ রয়েছে।');
    } catch (e) {
      console.error('Logout error', e);
    }
  };

  // Manual Firestore Sync
  const handleManualSync = async () => {
    if (!user) {
      handleLogin();
      return;
    }
    if (!isOnline) {
      setAlert?.('আপনি অফলাইনে আছেন। ইন্টারনেট সংযোগ পাওয়া মাত্রই ডাটা সিঙ্ক হবে।');
      return;
    }

    try {
      setIsActionPending(true);
      const res = await syncService.syncNow();
      if (res) {
        onDataLoaded?.({ cards: res.cards, folders: res.folders });
        if (res.restoredFromCloud) {
          setAlert?.(`ক্লাউড থেকে সফলভাবে ${res.cards.length}টি কার্ড ও ${res.folders.length}টি ফোল্ডার রিস্টোর হয়েছে!`);
        } else {
          setAlert?.(`ক্লাউডে আপনার সমস্ত ডাটা (${res.cards.length}টি কার্ড) সফলভাবে আপডেট ও ব্যাকআপ হয়েছে!`);
        }
      } else {
        setAlert?.('ক্লাউড ডাটা যাচাই সম্পন্ন হয়েছে। সবকিছু আপ-টু-ডেট আছে।');
      }
    } catch (err: any) {
      console.warn('Manual sync warning:', err);
      setAlert?.('সিঙ্ক সম্পন্ন হতে পারেনি, তবে আপনার সকল ডাটা ডিভাইসে সম্পূর্ণ নিরাপদ রয়েছে।');
    } finally {
      setIsActionPending(false);
    }
  };

  const handleResetSync = () => {
    syncService.forceReset();
    setIsActionPending(false);
    setAlert?.('সিঙ্ক থামানো হয়েছে। আপনার সকল কার্ড ও ফোল্ডার ফোনে সুরক্ষিত রয়েছে।');
  };

  // AppsGeyser & Web App Automatic Update Trigger
  const handleCheckAppUpdate = async () => {
    try {
      setIsCheckingAppUpdate(true);
      setAlert?.('নতুন আপডেটের জন্য ক্লাউড সার্ভার চেক করা হচ্ছে...');
      const hasNewUpdate = await appUpdateService.checkForUpdate();
      if (hasNewUpdate) {
        setAlert?.('নতুন আপডেট পাওয়া গেছে! অ্যাপ রিফ্রেশ করে নতুন সংস্করণ লোড করা হচ্ছে...');
        setTimeout(() => {
          appUpdateService.applyUpdateAndReload();
        }, 800);
      } else {
        // Force refresh cache and reload to guarantee fresh content
        setTimeout(() => {
          appUpdateService.applyUpdateAndReload();
        }, 500);
      }
    } catch (e) {
      console.warn('Update check failed:', e);
      window.location.reload();
    } finally {
      setIsCheckingAppUpdate(false);
    }
  };

  // Google Drive Backup
  const handleDriveBackup = async () => {
    if (!isOnline) {
      setAlert?.('ইন্টারনেট সংযোগ নেই। ড্রাইভ ব্যাকআপের জন্য ইন্টারনেট সংযোগ প্রয়োজন।');
      return;
    }

    try {
      setIsDriveBackingUp(true);

      if (!isDriveTokenValid()) {
        const authRes = await googleSignIn();
        if (!authRes || !authRes.accessToken) {
          setIsDriveConnected(false);
          setIsDriveBackingUp(false);
          setAlert?.('গুগল ড্রাইভ পারমিশন পাওয়া যায়নি।');
          return;
        }
        setIsDriveConnected(true);
      }

      const { cards: allCards, folders: allFolders } = await getFullData();
      const result = await syncToDrive(allCards, allFolders);

      if (result && result.backedUpAt) {
        setLastDriveBackup(result.backedUpAt);
        setAlert?.(`গুগল ড্রাইভে সফলভাবে সম্পূর্ণ ব্যাকআপ (${allCards.length}টি কার্ড) সংরক্ষিত হয়েছে!`);
      } else {
        setAlert?.('ড্রাইভ ব্যাকআপ সম্পন্ন হয়েছে।');
      }
    } catch (err: any) {
      console.error('Drive backup failed:', err);
      setAlert?.(err?.message || 'গুগল ড্রাইভ ব্যাকআপে সমস্যা হয়েছে।');
    } finally {
      setIsDriveBackingUp(false);
    }
  };

  const handleDriveRestore = async () => {
    if (!isOnline) {
      setAlert?.('ইন্টারনেট সংযোগ নেই। ড্রাইভ থেকে ডাটা নামানোর জন্য ইন্টারনেট প্রয়োজন।');
      return;
    }

    try {
      setIsDriveRestoring(true);

      if (!isDriveTokenValid()) {
        const authRes = await googleSignIn();
        if (!authRes || !authRes.accessToken) {
          setIsDriveConnected(false);
          setIsDriveRestoring(false);
          setAlert?.('গুগল ড্রাইভ পারমিশন পাওয়া যায়নি।');
          return;
        }
        setIsDriveConnected(true);
      }

      const result = await loadFromDrive();

      if (result && Array.isArray(result.cards) && result.cards.length > 0) {
        await set('flashcards', result.cards);
        await set('folders', result.folders);
        onDataLoaded?.({ cards: result.cards, folders: result.folders });
        if (result.recoveredFromRevision) {
          setAlert?.(`🎉 দারুণ খবর! গুগল ড্রাইভের ব্যাকআপ ইতিহাস (পূর্ববর্তী সংস্করণ) থেকে আপনার হারিয়ে যাওয়া ${result.cards.length}টি কার্ড ও ${result.folders.length}টি ফোল্ডার সফলভাবে উদ্ধার করা হয়েছে!`);
        } else {
          setAlert?.(`গুগল ড্রাইভ থেকে ${result.cards.length}টি কার্ড ও ${result.folders.length}টি ফোল্ডার রিস্টোর সম্পন্ন হয়েছে!`);
        }
        setShowSyncModal(false);
      } else {
        setAlert?.('গুগল ড্রাইভে বর্তমান ফাইলে ০টি কার্ড পাওয়া গেছে। অনুগ্রহ করে নিচে "🔍 ড্রাইভ ডিপ রিকভারি ও ভার্সন ইতিহাস" বাটনে চাপ দিয়ে আগের সব ব্যাকআপ থেকে কার্ড উদ্ধার করুন।');
      }
    } catch (err: any) {
      console.error('Drive restore failed:', err);
      setAlert?.(`গুগল ড্রাইভ থেকে ফাইল উদ্ধার করতে সমস্যা হয়েছে: ${err?.message || 'অজানা ত্রুটি'}`);
    } finally {
      setIsDriveRestoring(false);
    }
  };

  // Deep Recovery: Fetch all versions from Google Drive
  const handleOpenDeepRecovery = async () => {
    if (!isOnline) {
      setAlert?.('ইন্টারনেট সংযোগ নেই। ড্রাইভ হিস্ট্রি দেখার জন্য ইন্টারনেট প্রয়োজন।');
      return;
    }
    try {
      setIsLoadingRevisions(true);
      setShowRevisionsModal(true);

      if (!isDriveTokenValid()) {
        const authRes = await googleSignIn();
        if (!authRes || !authRes.accessToken) {
          setShowRevisionsModal(false);
          setAlert?.('গুগল ড্রাইভ পারমিশন পাওয়া যায়নি।');
          return;
        }
        setIsDriveConnected(true);
      }

      const list = await getDriveRevisionsList();
      setRevisionsList(list);
    } catch (err: any) {
      console.error('Failed to load drive revisions:', err);
      setAlert?.(`ড্রাইভ ভার্সন হিস্ট্রি লোড করতে সমস্যা হয়েছে: ${err?.message || 'অজানা ত্রুটি'}`);
    } finally {
      setIsLoadingRevisions(false);
    }
  };

  const handleRestoreRevision = async (revId: string, fileId?: string) => {
    try {
      setRestoringRevisionId(revId);
      const res = await restoreSpecificRevision(revId, fileId);
      if (res && Array.isArray(res.cards) && res.cards.length > 0) {
        await set('flashcards', res.cards);
        await set('folders', res.folders);
        onDataLoaded?.({ cards: res.cards, folders: res.folders });
        setAlert?.(`🎉 সফলভাবে ড্রাইভ ইতিহাস থেকে ${res.cards.length}টি কার্ড ও ${res.folders.length}টি ফোল্ডার উদ্ধার হয়েছে!`);
        setShowRevisionsModal(false);
        setShowSyncModal(false);
      } else {
        setAlert?.('এই ভার্সনে কোনো কার্ড ডাটা পাওয়া যায়নি। অন্য কোনো ভার্সন চেষ্টা করুন।');
      }
    } catch (err: any) {
      console.error('Failed to restore revision:', err);
      setAlert?.(`রিস্টোর ব্যর্থ হয়েছে: ${err?.message || 'অজানা ত্রুটি'}`);
    } finally {
      setRestoringRevisionId(null);
    }
  };

  // Local Offline File Export (Opens universal export modal with Copy, Share, Download, and Drive options)
  const handleExportFile = async () => {
    try {
      setIsExportingFile(true);
      const { cards: allCards, folders: allFolders } = await getFullData();
      const now = new Date();
      const dateString = now.toISOString().slice(0, 10);
      const timeString = `${String(now.getHours()).padStart(2, '0')}-${String(now.getMinutes()).padStart(2, '0')}`;
      const exportData = {
        app: 'Image Occlusion Flashcards',
        version: '2.0',
        exportedAt: now.toISOString(),
        exportedAtFormatted: now.toLocaleString('bn-BD'),
        stats: {
          totalCards: allCards.length,
          totalFolders: allFolders.length
        },
        cards: allCards,
        folders: allFolders
      };

      const filename = `flashcards_backup_${dateString}_${timeString}.json`;
      setFileExportPayload({
        filename,
        data: exportData,
        title: 'মেমোরি কার্ড ব্যাকআপ ফাইল'
      });
      setShowFileExportModal(true);
    } catch (e) {
      console.error('Export error:', e);
      setAlert?.('ফাইল এক্সপোর্ট করতে সমস্যা হয়েছে।');
    } finally {
      setIsExportingFile(false);
    }
  };

  // Direct Clipboard Copy Backup (100% reliable on all phones and WebViews)
  const handleCopyBackup = async () => {
    try {
      setIsCopyingBackup(true);
      const { cards: allCards, folders: allFolders } = await getFullData();
      const exportData = {
        app: 'Image Occlusion Flashcards',
        version: '2.0',
        exportedAt: new Date().toISOString(),
        stats: {
          totalCards: allCards.length,
          totalFolders: allFolders.length
        },
        cards: allCards,
        folders: allFolders
      };
      const ok = await copyTextToClipboard(JSON.stringify(exportData, null, 2));
      if (ok) {
        setAlert?.(`সম্পূর্ণ ব্যাকআপ (${allCards.length}টি কার্ড ও ${allFolders.length}টি ফোল্ডার) ক্লিপবোর্ডে কপি করা হয়েছে! নোটপ্যাড বা ফাইলে পেস্ট করে রাখতে পারেন।`);
      } else {
        setAlert?.('ক্লিপবোর্ডে কপি করা সম্ভব হয়নি।');
      }
    } catch (e) {
      setAlert?.('কপি করতে সমস্যা হয়েছে।');
    } finally {
      setIsCopyingBackup(false);
    }
  };

  // Restore from Pasted JSON text
  const handleRestoreFromText = async () => {
    if (!pastedJson.trim()) {
      setAlert?.('দয়া করে ব্যাকআপ টেক্সট পেস্ট করুন।');
      return;
    }
    try {
      const parsed = JSON.parse(pastedJson.trim());
      if (Array.isArray(parsed.cards)) {
        await set('flashcards', parsed.cards);
        await set('folders', parsed.folders || []);
        onDataLoaded?.({ cards: parsed.cards, folders: parsed.folders || [] });
        setAlert?.(`সফলভাবে ${parsed.cards.length}টি কার্ড ও ${(parsed.folders || []).length}টি ফোল্ডার উদ্ধার হয়েছে!`);
        setShowPasteModal(false);
        setPastedJson('');
        setShowSyncModal(false);
      } else if (Array.isArray(parsed)) {
        await set('flashcards', parsed);
        onDataLoaded?.({ cards: parsed, folders: [] });
        setAlert?.(`সফলভাবে ${parsed.length}টি কার্ড উদ্ধার করা হয়েছে!`);
        setShowPasteModal(false);
        setPastedJson('');
        setShowSyncModal(false);
      } else {
        setAlert?.('ভুল ব্যাকআপ ফরম্যাট! সঠিক JSON ব্যাকআপ পেস্ট করুন।');
      }
    } catch (err) {
      setAlert?.('পেস্ট করা টেক্সটটি সঠিক JSON নয়। সম্পূর্ণ ব্যাকআপ কপি পেস্ট করুন।');
    }
  };

  // Local Offline File Import
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed.cards)) {
          await set('flashcards', parsed.cards);
          await set('folders', parsed.folders || []);
          onDataLoaded?.({ cards: parsed.cards, folders: parsed.folders || [] });
          setAlert?.('ফাইল থেকে সকল কার্ড ও ফোল্ডার সফলভাবে উদ্ধার করা হয়েছে!');
          setShowSyncModal(false);
        } else if (Array.isArray(parsed)) {
          await set('flashcards', parsed);
          onDataLoaded?.({ cards: parsed, folders: [] });
          setAlert?.('ফাইল থেকে ফ্ল্যাশকার্ড উদ্ধার করা হয়েছে!');
          setShowSyncModal(false);
        } else {
          setAlert?.('ভুল ফরম্যাট! সঠিক JSON ব্যাকআপ ফাইল নির্বাচন করুন।');
        }
      } catch (err) {
        setAlert?.('ফাইলটি পড়া সম্ভব হয়নি।');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const formatTime = (ts: number | null) => {
    if (!ts) return 'এখনো হয়নি';
    const date = new Date(ts);
    return date.toLocaleDateString('bn-BD', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const isCurrentlySyncing = syncStatus === 'Syncing' || isActionPending;

  if (isInitializing) {
    return (
      <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-semibold bg-white/20 text-white/90 ${className || ''}`}>
        <Loader2 className="w-3.5 h-3.5 animate-spin" />
        <span className="whitespace-nowrap font-medium text-[11px]">অ্যাকাউন্ট...</span>
      </div>
    );
  }

  // Google "G" SVG icon
  const GoogleGIcon = () => (
    <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
      <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.15z"/>
      <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.28v3.15C3.27 21.36 7.35 24 12 24z"/>
      <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.28C.46 8.2.0 10.04.0 12c0 1.96.46 3.8 1.28 5.42l4-3.15z"/>
      <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.27 2.64 1.28 6.58l4 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
    </svg>
  );

  return (
    <div className={`relative inline-flex items-center ${className || ''}`}>
      {/* 
        Header Trigger Button:
        When NOT logged in: Prominent Google Account button
        When LOGGED IN: User Profile Avatar + Name + Green Active Badge
      */}
      {!user ? (
        <button
          type="button"
          onClick={() => setShowSyncModal(true)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-1.5 rounded-full text-xs font-bold transition-all shadow-sm cursor-pointer select-none bg-white text-slate-800 hover:bg-blue-50 border border-slate-200 dark:bg-slate-800 dark:text-slate-100 dark:border-slate-700 active:scale-95 shrink-0"
          title="গুগল অ্যাকাউন্ট দিয়ে লগইন করুন (স্বয়ংক্রিয় ব্যাকআপ ও রিস্টোর)"
        >
          <GoogleGIcon />
          <span className="whitespace-nowrap font-bold text-xs">গুগল অ্যাকাউন্ট</span>
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse shrink-0" title="লগইন করা নেই" />
        </button>
      ) : (
        <button
          type="button"
          onClick={() => setShowSyncModal(true)}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-1.5 rounded-full text-xs font-bold transition-all shadow-sm cursor-pointer select-none border active:scale-95 shrink-0 ${
            isCurrentlySyncing
              ? 'bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-200 border-blue-300 dark:border-blue-700'
              : 'bg-emerald-50 dark:bg-emerald-950/70 text-emerald-900 dark:text-emerald-100 border-emerald-300 dark:border-emerald-700 hover:bg-emerald-100 dark:hover:bg-emerald-900/80'
          }`}
          title={`${user.displayName || user.email} হিসেবে লগইন আছেন (অটো ক্লাউড সিঙ্ক সক্রিয়)`}
        >
          {user.photoURL ? (
            <img
              src={user.photoURL}
              alt=""
              className="w-4 h-4 rounded-full ring-1 ring-emerald-500 shrink-0 object-cover"
            />
          ) : (
            <div className="w-4 h-4 rounded-full bg-emerald-600 text-white text-[10px] flex items-center justify-center font-bold shrink-0">
              {(user.displayName || user.email || 'U')[0].toUpperCase()}
            </div>
          )}

          <span className="whitespace-nowrap max-w-[65px] sm:max-w-[100px] truncate text-xs">
            {user.displayName ? user.displayName.split(' ')[0] : 'অ্যাকাউন্ট'}
          </span>

          {isCurrentlySyncing ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600 dark:text-blue-300 shrink-0" />
          ) : (
            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0 shadow-xs" title="অটোমেটিক ক্লাউড ব্যাকআপ সক্রিয়" />
          )}

          {!isOnline && (
            <span title="অফলাইন" className="text-red-500 shrink-0">
              <WifiOff className="w-3 h-3" />
            </span>
          )}
        </button>
      )}

      {/* Sync & Backup Management Modal */}
      {showSyncModal && typeof document !== 'undefined' && createPortal(
        <div 
          className="fixed inset-0 bg-black/75 z-[99999] flex items-center justify-center p-3 sm:p-4 backdrop-blur-sm animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowSyncModal(false);
          }}
        >
          <div 
            className="bg-white dark:bg-slate-800 rounded-3xl max-w-lg w-full p-5 sm:p-6 pb-12 shadow-2xl border border-gray-100 dark:border-slate-700 relative animate-in fade-in zoom-in-95 max-h-[82vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowSyncModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3.5 mb-4 pb-3 border-b border-gray-100 dark:border-slate-700">
              <div className="p-3 bg-blue-50 dark:bg-blue-900/40 rounded-2xl text-blue-600 dark:text-blue-400 shrink-0 border border-blue-100 dark:border-blue-800/40">
                <Cloud className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  গুগল অ্যাকাউন্ট ও অটো-সিঙ্ক
                  <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
                </h2>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  স্বয়ংক্রিয় ক্লাউড ব্যাকআপ, ডিভাইস রিস্টোর এবং অ্যাপ আপডেট
                </p>
              </div>
            </div>

            {/* Status Tabs Navigation */}
            <div className="grid grid-cols-4 gap-1 p-1 bg-gray-100 dark:bg-slate-900/80 rounded-2xl mb-4 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveTab('cloud')}
                className={`py-2 px-1 text-center rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'cloud'
                    ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                }`}
              >
                <Cloud className="w-3.5 h-3.5" />
                <span className="truncate">অ্যাকাউন্ট</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('update')}
                className={`py-2 px-1 text-center rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'update'
                    ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                <span className="truncate">অটো-আপডেট</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('drive')}
                className={`py-2 px-1 text-center rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'drive'
                    ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                }`}
              >
                <HardDrive className="w-3.5 h-3.5" />
                <span className="truncate">গুগল ড্রাইভ</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('file')}
                className={`py-2 px-1 text-center rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'file'
                    ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                }`}
              >
                <Download className="w-3.5 h-3.5" />
                <span className="truncate">অফলাইন ফাইল</span>
              </button>
            </div>

            {/* TAB 1: Google Account & Cloud Auto-Sync */}
            {activeTab === 'cloud' && (
              <div className="space-y-4 animate-in fade-in duration-200">
                {/* When NOT logged in: Prompt Google Sign-In */}
                {!user ? (
                  <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-blue-50 via-indigo-50/60 to-purple-50/40 dark:from-slate-900 dark:via-blue-950/40 dark:to-indigo-950/30 border border-blue-200/80 dark:border-blue-900/50 space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center">
                        <GoogleGIcon />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                          গুগল দিয়ে অ্যাকাউন্ট কানেক্ট করুন
                        </h3>
                        <p className="text-[11px] text-gray-500 dark:text-gray-400">
                          সর্বদা স্বয়ংক্রিয় ক্লাউড ব্যাকআপ ও রিস্টোর
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2 text-xs text-gray-600 dark:text-gray-300 bg-white/70 dark:bg-slate-800/70 p-3 rounded-xl border border-blue-100 dark:border-blue-900/30">
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        <span><strong>স্বয়ংক্রিয় ক্লাউড ব্যাকআপ:</strong> আপনি যে কার্ড তৈরি করবেন তা সর্বদা অটোমেটিক ক্লাউডে সেভ থাকবে।</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        <span><strong>অন্য ফোনে সবকিছু ফিরে আসা:</strong> ফোন পরিবর্তন করলে বা অ্যাপ পুনরায় ইনস্টল করলে শুধু গুগল দিয়ে লগইন করলেই সব কার্ড ও ফোল্ডার ফিরে আসবে।</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        <span><strong>ডাটা হারাবে না:</strong> মেমোরি ক্লিয়ার হলেও আপনার পড়া ও প্রগ্রেস সুরক্ষিত থাকবে।</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleLogin}
                      disabled={isActionPending}
                      className="w-full flex items-center justify-center gap-2.5 bg-white hover:bg-gray-50 text-gray-800 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-white py-3 px-4 rounded-xl font-bold text-xs transition-all shadow-md border border-gray-200 dark:border-slate-600 disabled:opacity-50 cursor-pointer active:scale-98"
                    >
                      <GoogleGIcon />
                      <span>{isActionPending ? 'লগইন প্রসেস হচ্ছে...' : 'Google দিয়ে সাইন-ইন করুন'}</span>
                    </button>
                  </div>
                ) : (
                  /* When Logged in: Account Profile Card */
                  <div className="space-y-3">
                    <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/30 border border-emerald-200 dark:border-emerald-800/50 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        {user.photoURL ? (
                          <img
                            src={user.photoURL}
                            alt=""
                            className="w-12 h-12 rounded-full ring-2 ring-emerald-500 shrink-0 object-cover"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center text-lg font-bold shrink-0">
                            {(user.displayName || user.email || 'U')[0].toUpperCase()}
                          </div>
                        )}
                        <div className="min-w-0">
                          <h3 className="text-sm font-bold text-gray-900 dark:text-white truncate">
                            {user.displayName || 'গুগল ব্যবহারকারী'}
                          </h3>
                          <p className="text-[11px] text-gray-500 dark:text-gray-400 truncate">
                            {user.email}
                          </p>
                          <div className="flex items-center gap-1.5 mt-1 text-[11px] text-emerald-700 dark:text-emerald-300 font-bold">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            <span>অটোমেটিক ক্লাউড সিঙ্ক সক্রিয়</span>
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={handleLogout}
                        className="px-2.5 py-1.5 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/50 rounded-xl text-xs font-bold transition-colors shrink-0 flex items-center gap-1"
                        title="লগআউট"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">লগআউট</span>
                      </button>
                    </div>

                    {/* Active Sync watchdog banner */}
                    {isCurrentlySyncing && (
                      <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 p-3 rounded-2xl text-xs text-blue-900 dark:text-blue-200">
                        <div className="flex items-center gap-2 font-semibold">
                          <Loader2 className="w-4 h-4 animate-spin text-blue-600 dark:text-blue-400 shrink-0" />
                          <span>ক্লাউড ফায়ারস্টোরে সিঙ্ক ও ব্যাকআপ চলছে...</span>
                        </div>
                        <button
                          type="button"
                          onClick={handleResetSync}
                          className="mt-2 px-2.5 py-1 bg-red-100 hover:bg-red-200 text-red-700 dark:bg-red-950/60 dark:hover:bg-red-900/80 dark:text-red-300 rounded-lg text-xs font-semibold transition-colors"
                        >
                          সিঙ্ক থামাতে চাপ দিন
                        </button>
                      </div>
                    )}

                    {/* Cloud Sync Stats */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-3 rounded-xl bg-gray-50 dark:bg-slate-900/60 border border-gray-200/70 dark:border-slate-700">
                        <span className="text-gray-500 dark:text-gray-400 text-[11px] block mb-0.5">ক্লাউডে ব্যাকআপ স্ট্যাটাস:</span>
                        <span className="font-bold flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                          <CheckCircle2 className="w-3.5 h-3.5" /> সর্বদা সক্রিয় (Auto)
                        </span>
                      </div>

                      <div className="p-3 rounded-xl bg-gray-50 dark:bg-slate-900/60 border border-gray-200/70 dark:border-slate-700">
                        <span className="text-gray-500 dark:text-gray-400 text-[11px] block mb-0.5">সর্বশেষ ক্লাউড সিঙ্ক:</span>
                        <span className="font-bold text-gray-800 dark:text-gray-200">
                          {formatTime(lastSyncedAt)}
                        </span>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-blue-50/70 dark:bg-slate-900/50 border border-blue-100 dark:border-blue-900/30 text-xs text-blue-950 dark:text-blue-200 space-y-1">
                      <div className="font-bold flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                        <span>সর্বদা অটোমেটিক আপডেট কীভাবে হয়?</span>
                      </div>
                      <p className="text-[11px] text-gray-600 dark:text-gray-300 leading-relaxed">
                        আপনি যখনই নতুন কোনো কার্ড যোগ করবেন, ফোল্ডার বানাবেন বা কুইজ দিয়ে কার্ড রিভিশন করবেন, অ্যাপ স্বয়ংক্রিয়ভাবে ৩ সেকেন্ডের মধ্যে ব্যাকগ্রাউন্ডে গুগল ক্লাউডে ডাটা আপডেট করে নেয়।
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={handleManualSync}
                      disabled={isCurrentlySyncing || !isOnline}
                      className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-bold text-xs transition-colors shadow-sm disabled:opacity-50 cursor-pointer active:scale-98"
                    >
                      {isCurrentlySyncing ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                      <span>এখনই ক্লাউড সিঙ্ক ও রিস্টোর নিশ্চিত করুন</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: AppsGeyser / APK Automatic Live Updates */}
            {activeTab === 'update' && (
              <div className="space-y-4 animate-in fade-in duration-200">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-50/80 via-blue-50/60 to-purple-50/40 dark:from-slate-900 dark:via-indigo-950/40 dark:to-blue-950/30 border border-indigo-200/80 dark:border-indigo-900/50 space-y-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                      <Globe className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                        AppsGeyser ও APK লাইভ অটো-আপডেট
                      </h3>
                      <p className="text-[11px] text-gray-500 dark:text-gray-400">
                        সরাসরি ক্লাউড লিংক কানেকশন • স্বয়ংক্রিয় নতুন কোড লোড
                      </p>
                    </div>
                  </div>

                  <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                    AppsGeyser দিয়ে আপনি যে APK তৈরি করেছেন, সেটি সরাসরি ক্লাউডের এই লাইভ সংস্করণের সাথে যুক্ত। নতুন কোনো ফিচার আসলে বা পরিবর্তন হলে অ্যাপ ওপেন করলেই স্বয়ংক্রিয়ভাবে তা লোড হয়ে যাবে।
                  </p>

                  <div className="p-3 rounded-xl bg-white/80 dark:bg-slate-900/70 border border-indigo-100 dark:border-indigo-900/40 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600 dark:text-gray-400 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> বর্তমান স্ট্যাটাস:
                      </span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        লাইভ ক্লাউড আপডেট সক্রিয়
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-gray-600 dark:text-gray-400 flex items-center gap-1.5">
                        <Smartphone className="w-3.5 h-3.5 text-indigo-500" /> ক্যাশ সুরক্ষামূলক রিফ্রেশ:
                      </span>
                      <span className="font-bold text-gray-800 dark:text-gray-200">
                        স্বয়ংক্রিয় (Auto Check)
                      </span>
                    </div>
                  </div>

                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={handleCheckAppUpdate}
                      disabled={isCheckingAppUpdate}
                      className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white py-3 rounded-xl font-bold text-xs transition-all shadow-md disabled:opacity-50 cursor-pointer"
                    >
                      {isCheckingAppUpdate ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>নতুন আপডেট চেক করা হচ্ছে...</span>
                        </>
                      ) : (
                        <>
                          <RefreshCw className="w-4 h-4" />
                          <span>🔄 নতুন আপডেট চেক করুন ও রিফ্রেশ করুন</span>
                        </>
                      )}
                    </button>
                    <p className="text-[11px] text-gray-500 dark:text-gray-400 text-center mt-2">
                      টিপ: কোনো নতুন পরিবর্তন না দেখা গেলে এই বাটনে চাপ দিন, সাথে সাথে ক্যাশ ক্লিয়ার হয়ে নতুন সংস্করণ লোড হবে।
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: Google Drive Backup */}
            {activeTab === 'drive' && (
              <div className="space-y-4 animate-in fade-in duration-200">
                <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 rounded-2xl text-xs text-amber-900 dark:text-amber-200 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <HardDrive className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>ব্যক্তিগত গুগল ড্রাইভে সম্পূর্ণ ব্যাকআপ ফাইল</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-amber-800 dark:text-amber-300">
                    ফায়ারস্টোর ক্লাউড সিঙ্কের পাশাপাশি আপনি চাইলে নিজের গুগল ড্রাইভে একটি ব্যাকআপ ফাইল আকারেও সকল কার্ড ও ছবি সংরক্ষণ করতে পারেন।
                  </p>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-slate-700">
                    <span className="text-gray-500 dark:text-gray-400">সর্বশেষ গুগল ড্রাইভ ব্যাকআপ:</span>
                    <span className="font-medium text-gray-700 dark:text-gray-300">
                      {formatTime(lastDriveBackup)}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleDriveBackup}
                    disabled={isDriveBackingUp || !isOnline}
                    className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white py-2.5 px-3 rounded-xl font-bold text-xs transition-colors shadow-xs disabled:opacity-50 cursor-pointer"
                  >
                    {isDriveBackingUp ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                    <span>ড্রাইভে সেভ করুন</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDriveRestore}
                    disabled={isDriveRestoring || !isOnline}
                    className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white py-2.5 px-3 rounded-xl font-bold text-xs transition-colors shadow-xs disabled:opacity-50 cursor-pointer"
                  >
                    {isDriveRestoring ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                    <span>ড্রাইভ থেকে রিস্টোর</span>
                  </button>
                </div>

                {/* Deep Recovery for lost/overwritten cards */}
                <div className="mt-3 p-3.5 rounded-2xl bg-gradient-to-br from-purple-50/90 via-indigo-50/60 to-blue-50/40 dark:from-slate-900 dark:via-purple-950/40 dark:to-slate-800 border border-purple-200/90 dark:border-purple-800/60 text-xs space-y-2.5">
                  <div className="flex items-center gap-2">
                    <History className="w-4 h-4 text-purple-600 dark:text-purple-400 shrink-0" />
                    <span className="font-bold text-slate-900 dark:text-white">
                      ভুল ব্যাকআপ উদ্ধার ও ড্রাইভ ভার্সন ইতিহাস (Deep Recovery)
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                    নতুন ফোনে লগইন করার পর ভুলবশত ০টি কার্ড ব্যাকআপ দিয়ে ফেলেছেন যার কারণে রিস্টোর করতে গেলে ০টি কার্ড দেখাচ্ছে? চিন্তা নেই! গুগল ড্রাইভের ব্যাকআপ ইতিহাস থেকে পুরনো সব তারিখের সংরক্ষিত সংস্করণ খুঁজে বের করে আগের সব কার্ড উদ্ধার করা সম্ভব।
                  </p>
                  <button
                    type="button"
                    onClick={handleOpenDeepRecovery}
                    disabled={isLoadingRevisions || !isOnline}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 active:scale-98 text-white py-2.5 px-3 rounded-xl font-bold text-xs transition-all shadow-xs disabled:opacity-50 cursor-pointer"
                  >
                    {isLoadingRevisions ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>ড্রাইভের সব সংস্করণ স্ক্যান করা হচ্ছে...</span>
                      </>
                    ) : (
                      <>
                        <Search className="w-4 h-4" />
                        <span>🔍 ড্রাইভ ডিপ রিকভারি ও ভার্সন ইতিহাস খুলুন</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* TAB 4: Offline File Backup (JSON Export/Import) */}
            {activeTab === 'file' && (
              <div className="space-y-3.5 text-xs animate-in fade-in duration-200">
                <p className="text-gray-600 dark:text-gray-300 text-xs leading-relaxed">
                  ইন্টারনেট ছাড়াও একটি একক <span className="font-mono bg-gray-100 dark:bg-slate-700 px-1 py-0.5 rounded font-bold">.json</span> ফাইল আকারে সমস্ত কার্ড ও ফোল্ডার ডাউনলোড বা কপি করে মেমোরি কার্ড বা অন্য অ্যাপে সংরক্ষণ করতে পারেন।
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  {/* Option 1: File Download / Native Phone Save */}
                  <button
                    type="button"
                    onClick={handleExportFile}
                    disabled={isExportingFile}
                    className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white py-3 px-3 rounded-xl font-bold transition-all shadow-sm cursor-pointer disabled:opacity-50"
                  >
                    {isExportingFile ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                    <span>ফাইল ডাউনলোড বা সেভ</span>
                  </button>

                  {/* Option 2: Copy Backup to Clipboard */}
                  <button
                    type="button"
                    onClick={handleCopyBackup}
                    disabled={isCopyingBackup}
                    className="flex items-center justify-center gap-2 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-200 border border-indigo-200 dark:border-indigo-800 py-3 px-3 rounded-xl font-bold transition-all shadow-xs cursor-pointer active:scale-98"
                  >
                    {isCopyingBackup ? <Loader2 className="w-4 h-4 animate-spin" /> : <Copy className="w-4 h-4" />}
                    <span>ব্যাকআপ কোড কপি করুন</span>
                  </button>

                  {/* Option 3: Restore from File */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white py-3 px-3 rounded-xl font-bold transition-all shadow-sm cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>ফাইল থেকে রিস্টোর</span>
                  </button>

                  {/* Option 4: Paste & Restore */}
                  <button
                    type="button"
                    onClick={() => setShowPasteModal(true)}
                    className="flex items-center justify-center gap-2 bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 text-gray-800 dark:text-gray-100 border border-gray-200 dark:border-slate-600 py-3 px-3 rounded-xl font-bold transition-all cursor-pointer active:scale-98"
                  >
                    <ClipboardPaste className="w-4 h-4 text-amber-500" />
                    <span>পেস্ট করে রিস্টোর</span>
                  </button>
                </div>

                <div className="p-3 bg-amber-50/70 dark:bg-amber-950/30 rounded-xl border border-amber-200/60 dark:border-amber-900/40 text-[11px] text-amber-900 dark:text-amber-200 leading-relaxed">
                  💡 <strong>APK ব্যবহারকারীদের জন্য টিপ:</strong> ফোনে ফাইল ডাউনলোডে <em>"Don't permission granted"</em> এরর আসলে চিন্তা নেই! <strong>"ব্যাকআপ কোড কপি করুন"</strong> বাটনে চাপ দিন (কোনো স্টোরেজ পারমিশন লাগে না) এবং আপনার নোটপ্যাড বা কিপ নোটসে পেস্ট করে রাখুন।
                </div>

                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImportFile}
                  accept="application/json,.json,text/plain,text/*,*/*"
                  className="hidden"
                />
              </div>
            )}

            {/* Paste & Restore Modal */}
            {showPasteModal && (
              <div 
                className="fixed inset-0 bg-black/80 z-[100000] flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-150"
                onClick={() => setShowPasteModal(false)}
              >
                <div 
                  className="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full p-5 shadow-2xl border border-gray-200 dark:border-slate-700 space-y-3"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                      <ClipboardPaste className="w-4 h-4 text-amber-500" />
                      ব্যাকআপ কোড পেস্ট করে রিস্টোর
                    </h3>
                    <button
                      type="button"
                      onClick={() => setShowPasteModal(false)}
                      className="p-1 rounded-full text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    পূর্বে কপি করা ব্যাকআপ JSON কোডটি নিচের বক্সে পেস্ট করুন:
                  </p>

                  <textarea
                    value={pastedJson}
                    onChange={(e) => setPastedJson(e.target.value)}
                    placeholder='{"cards": [...], "folders": [...]}'
                    rows={6}
                    className="w-full p-2.5 text-xs font-mono rounded-xl bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 text-gray-900 dark:text-gray-100 focus:outline-hidden focus:ring-2 focus:ring-blue-500 select-text"
                  />

                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowPasteModal(false)}
                      className="flex-1 py-2 rounded-xl text-xs font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      বাতিল
                    </button>
                    <button
                      type="button"
                      onClick={handleRestoreFromText}
                      disabled={!pastedJson.trim()}
                      className="flex-1 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white transition-colors disabled:opacity-50 shadow-xs"
                    >
                      রিস্টোর সম্পন্ন করুন
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Footer User Info */}
            {user && (
              <div className="mt-5 pt-3 border-t border-gray-100 dark:border-slate-700 flex justify-between items-center text-xs">
                <span className="text-[11px] text-gray-400 truncate max-w-[200px]">
                  {user.email}
                </span>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="text-xs font-bold text-red-500 hover:text-red-600 flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  লগআউট
                </button>
              </div>
            )}
          </div>
        </div>,
        document.body
      )}

      {/* Google Drive Deep Recovery & Revisions History Modal */}
      {showRevisionsModal && typeof document !== 'undefined' && createPortal(
        <div
          className="fixed inset-0 bg-black/80 z-[100000] flex items-center justify-center p-3 sm:p-4 backdrop-blur-md animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowRevisionsModal(false);
          }}
        >
          <div
            className="bg-white dark:bg-slate-800 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-gray-100 dark:border-slate-700 relative animate-in fade-in zoom-in-95 max-h-[85vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-slate-700 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-300 flex items-center justify-center shadow-xs">
                  <History className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-gray-900 dark:text-white">
                    গুগল ড্রাইভ সংস্করণ ইতিহাস
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    পূর্ববর্তী সব ব্যাকআপ থেকে হারিয়ে যাওয়া কার্ড উদ্ধার
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowRevisionsModal(false)}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Explanatory Banner */}
            <div className="my-3 p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-xs text-amber-900 dark:text-amber-200 shrink-0 space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>নতুন ডিভাইসে ভুল ব্যাকআপ হলে যেভাবে কার্ড উদ্ধার করবেন:</span>
              </div>
              <p className="text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed">
                নিচে আপনার গুগল ড্রাইভের সমস্ত ঐতিহাসিক ব্যাকআপ তারিখ এবং কার্ডের সংখ্যাসহ দেখানো হয়েছে। যে সংস্করণে আপনার সব কার্ড ছিল, সেটির ডানের <strong>"উদ্ধার করুন"</strong> বাটনে ট্যাপ করলেই সেগুলো ফিরিয়ে আনা হবে।
              </p>
            </div>

            {/* Revisions List / Loading / Empty */}
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 min-h-[160px]">
              {isLoadingRevisions ? (
                <div className="py-12 text-center space-y-3">
                  <Loader2 className="w-8 h-8 animate-spin text-purple-600 mx-auto" />
                  <p className="text-xs text-gray-600 dark:text-gray-300 font-medium">
                    গুগল ড্রাইভের ফাইল ও সংস্করণ ইতিহাস স্ক্যান করা হচ্ছে...
                  </p>
                </div>
              ) : revisionsList.length === 0 ? (
                <div className="py-12 text-center space-y-2 text-gray-500 dark:text-gray-400">
                  <HardDrive className="w-10 h-10 mx-auto text-gray-400 opacity-50" />
                  <p className="text-xs font-medium">
                    গুগল ড্রাইভে কোনো পূর্ববর্তী ব্যাকআপ সংস্করণ পাওয়া যায়নি।
                  </p>
                </div>
              ) : (
                revisionsList.map((rev) => {
                  const isCurrentRestoring = restoringRevisionId === rev.id;
                  const formattedDate = new Date(rev.modifiedTime).toLocaleString('bn-BD', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  });

                  return (
                    <div
                      key={`${rev.fileId}-${rev.id}`}
                      className={`p-3 rounded-2xl border transition-all text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                        rev.isHealthy
                          ? 'bg-white dark:bg-slate-900 border-purple-200/80 dark:border-purple-900/40 shadow-xs hover:border-purple-400'
                          : 'bg-gray-50 dark:bg-slate-900/40 border-gray-200 dark:border-slate-800 opacity-60'
                      }`}
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-gray-900 dark:text-white">
                            {formattedDate}
                          </span>
                          {rev.isCurrentActive && (
                            <span className="text-[10px] bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300 font-bold px-2 py-0.5 rounded-full">
                              বর্তমান ফাইল
                            </span>
                          )}
                        </div>

                        <div className="text-[11px] text-gray-500 dark:text-gray-400 truncate">
                          {rev.sourceLabel || 'গুগল ড্রাইভ সংস্করণ'} • {(rev.size / 1024).toFixed(1)} KB
                        </div>

                        <div className="flex items-center gap-2 pt-0.5">
                          {rev.cardsCount !== undefined && (
                            <span
                              className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                                rev.cardsCount > 0
                                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                                  : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                              }`}
                            >
                              {rev.cardsCount > 0
                                ? `🗂️ ${rev.cardsCount} টি কার্ড`
                                : '⚠️ ০ টি কার্ড (খালি ব্যাকআপ)'}
                            </span>
                          )}

                          {rev.foldersCount !== undefined && rev.foldersCount > 0 && (
                            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                              📁 {rev.foldersCount} টি ফোল্ডার
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="shrink-0 flex items-center justify-end">
                        {rev.isHealthy ? (
                          <button
                            type="button"
                            onClick={() => handleRestoreRevision(rev.id, rev.fileId)}
                            disabled={!!restoringRevisionId}
                            className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all cursor-pointer disabled:opacity-50"
                          >
                            {isCurrentRestoring ? (
                              <>
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                <span>উদ্ধার হচ্ছে...</span>
                              </>
                            ) : (
                              <>
                                <Download className="w-3.5 h-3.5" />
                                <span>এই সংস্করণ উদ্ধার করুন</span>
                              </>
                            )}
                          </button>
                        ) : (
                          <span className="text-[11px] text-gray-400 dark:text-gray-500 italic">
                            কোনো কার্ড নেই
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Modal Footer */}
            <div className="pt-3 mt-3 border-t border-gray-100 dark:border-slate-700 flex items-center justify-between shrink-0">
              <button
                type="button"
                onClick={handleOpenDeepRecovery}
                disabled={isLoadingRevisions}
                className="text-xs text-purple-600 dark:text-purple-400 font-bold hover:underline flex items-center gap-1 cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingRevisions ? 'animate-spin' : ''}`} />
                <span>পুনরায় রিফ্রেশ করুন</span>
              </button>

              <button
                type="button"
                onClick={() => setShowRevisionsModal(false)}
                className="px-4 py-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200 font-bold text-xs transition-colors cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Universal File Export Modal (With Copy, Share, Download, Drive options and APK guidance) */}
      {fileExportPayload && (
        <FileExportModal
          isOpen={showFileExportModal}
          onClose={() => {
            setShowFileExportModal(false);
            setFileExportPayload(null);
          }}
          data={fileExportPayload.data}
          filename={fileExportPayload.filename}
          title={fileExportPayload.title}
          onOpenGoogleDrive={() => {
            setShowFileExportModal(false);
            setActiveTab('drive');
          }}
          onSuccess={(msg) => setAlert?.(msg)}
        />
      )}
    </div>
  );
}
