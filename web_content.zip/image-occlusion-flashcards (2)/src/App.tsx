/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { get, set } from 'idb-keyval';
import Dashboard from './components/Dashboard';
import CreateCard from './components/CreateCard';
import StudyCard from './components/StudyCard';
import FolderView from './components/FolderView';
import QuizMode from './components/QuizMode';
import EyeCareTimer from './components/EyeCareTimer';
import AppLaunchScreen from './components/AppLaunchScreen';
import { Card, Folder } from './types';
import { syncService } from './lib/firestoreSync';
import { appUpdateService } from './lib/appUpdate';
import { getAllTags } from './lib/tagUtils';
import { requestPhonePersistence } from './lib/storageUtils';
import { initSystemSafeAreaSettings } from './lib/notchUtils';
import { initEyeComfort } from './lib/eyeComfortUtils';

export default function App() {
  // Session-restored navigation state prevents resetting to Home on Android app sleep/resume
  const [view, setView] = useState<'dashboard' | 'create' | 'study' | 'folder' | 'quiz' | 'bulk-edit'>(() => {
    try {
      const saved = sessionStorage.getItem('io_active_view');
      if (saved && ['dashboard', 'create', 'study', 'folder', 'quiz', 'bulk-edit'].includes(saved)) {
        return saved as any;
      }
    } catch (e) {}
    return 'dashboard';
  });

  const [cards, setCards] = useState<Card[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  
  const [studyCards, setStudyCards] = useState<Card[]>([]);
  const [studyIndex, setStudyIndex] = useState(0);
  const [bulkEditQueue, setBulkEditQueue] = useState<Card[]>([]);
  
  const [editingCardId, setEditingCardId] = useState<number | null>(() => {
    try {
      const savedCard = sessionStorage.getItem('io_editing_card');
      return savedCard ? Number(savedCard) : null;
    } catch (e) {}
    return null;
  });
  
  const [currentFolderId, setCurrentFolderId] = useState<number | null>(() => {
    try {
      const savedFolder = sessionStorage.getItem('io_active_folder');
      return savedFolder ? Number(savedFolder) : null;
    } catch (e) {}
    return null;
  });

  const [globalAlert, setGlobalAlert] = useState('');
  const [loading, setLoading] = useState(true);
  
  // Only show full launch screen on very first app opening in the session
  const [isLaunching, setIsLaunching] = useState(() => {
    try {
      return sessionStorage.getItem('io_has_launched') !== 'true';
    } catch (e) {}
    return true;
  });

  const [darkMode, setDarkMode] = useState(false);
  const [hasAppUpdate, setHasAppUpdate] = useState(false);
  const [backToast, setBackToast] = useState<string | null>(null);

  // References for reliable event listener access without closure staleness
  const viewRef = useRef(view);
  const currentFolderIdRef = useRef(currentFolderId);
  const foldersRef = useRef(folders);
  const lastBackPressTime = useRef<number>(0);

  useEffect(() => {
    viewRef.current = view;
    try {
      sessionStorage.setItem('io_active_view', view);
    } catch (e) {}
  }, [view]);

  useEffect(() => {
    currentFolderIdRef.current = currentFolderId;
    try {
      if (currentFolderId !== null) {
        sessionStorage.setItem('io_active_folder', String(currentFolderId));
      } else {
        sessionStorage.removeItem('io_active_folder');
      }
    } catch (e) {}
  }, [currentFolderId]);

  useEffect(() => {
    foldersRef.current = folders;
  }, [folders]);

  useEffect(() => {
    try {
      if (editingCardId !== null) {
        sessionStorage.setItem('io_editing_card', String(editingCardId));
      } else {
        sessionStorage.removeItem('io_editing_card');
      }
    } catch (e) {}
  }, [editingCardId]);

  // Navigate helper that pushes History state for Android back button/gesture
  const navigateTo = (
    nextView: 'dashboard' | 'create' | 'study' | 'folder' | 'quiz' | 'bulk-edit',
    folderId: number | null = null,
    cardId: number | null = null,
    replace = false
  ) => {
    setView(nextView);
    setCurrentFolderId(folderId);
    setEditingCardId(cardId);

    try {
      const stateObj = {
        view: nextView,
        folderId,
        cardId,
        timestamp: Date.now()
      };
      if (replace) {
        window.history.replaceState(stateObj, '');
      } else {
        window.history.pushState(stateObj, '');
      }
    } catch (e) {}
  };

  // Android System Back Button & History popstate integration
  useEffect(() => {
    try {
      if (!window.history.state || !window.history.state.view) {
        window.history.replaceState({
          view: viewRef.current,
          folderId: currentFolderIdRef.current,
          timestamp: Date.now()
        }, '');
      }
    } catch (e) {}

    const handlePopState = (event: PopStateEvent) => {
      const state = event.state;
      const curView = viewRef.current;
      const curFolderId = currentFolderIdRef.current;
      const allFolders = foldersRef.current;

      if (state && state.view) {
        setView(state.view);
        setCurrentFolderId(state.folderId ?? null);
        setEditingCardId(state.cardId ?? null);
        return;
      }

      // If user navigated back without state payload:
      if (curView === 'create' || curView === 'bulk-edit') {
        const targetView = curFolderId ? 'folder' : 'dashboard';
        setView(targetView);
        setEditingCardId(null);
        try {
          window.history.pushState({ view: targetView, folderId: curFolderId }, '');
        } catch (e) {}
      } else if (curView === 'study' || curView === 'quiz') {
        const targetView = curFolderId ? 'folder' : 'dashboard';
        setView(targetView);
        try {
          window.history.pushState({ view: targetView, folderId: curFolderId }, '');
        } catch (e) {}
      } else if (curView === 'folder' && curFolderId !== null) {
        const curFolder = allFolders.find(f => f.id === curFolderId);
        if (curFolder && curFolder.parentId) {
          setCurrentFolderId(curFolder.parentId);
          try {
            window.history.pushState({ view: 'folder', folderId: curFolder.parentId }, '');
          } catch (e) {}
        } else {
          setCurrentFolderId(null);
          setView('dashboard');
          try {
            window.history.pushState({ view: 'dashboard', folderId: null }, '');
          } catch (e) {}
        }
      } else if (curView === 'dashboard') {
        // Standard Android double-back to exit behavior
        const now = Date.now();
        if (now - lastBackPressTime.current < 2500) {
          // Allow natural exit / close
          setBackToast(null);
        } else {
          lastBackPressTime.current = now;
          setBackToast('অ্যাপ বন্ধ করতে আবার ব্যাক চাপুন');
          setTimeout(() => {
            setBackToast(null);
          }, 2400);
          try {
            window.history.pushState({ view: 'dashboard', folderId: null }, '');
          } catch (e) {}
        }
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  // Subscribe to service worker / update notifications
  useEffect(() => {
    const unsubUpdate = appUpdateService.subscribe((updateReady) => {
      setHasAppUpdate(updateReady);
    });
    return () => unsubUpdate();
  }, []);

  // System and IndexedDB initialization
  useEffect(() => {
    initSystemSafeAreaSettings();
    const cleanupEyeComfort = initEyeComfort();
    const isDark = localStorage.getItem('darkMode') === 'true';
    if (isDark) {
      document.documentElement.classList.add('dark');
      setDarkMode(true);
    }
    
    const loadData = async () => {
      try {
        let loadedCards = await get<Card[]>('flashcards') || [];
        let loadedFolders = await get<Folder[]>('folders') || [];

        // Migration from localStorage if idb is empty
        if (loadedCards.length === 0) {
          const saved = localStorage.getItem('occlusionCards');
          if (saved) {
            loadedCards = JSON.parse(saved);
            await set('flashcards', loadedCards);
          }
        }
        
        setCards(loadedCards);
        setFolders(loadedFolders);

        // Lock storage in phone OS to avoid deletion by Chrome/system cache clear
        requestPhonePersistence();
      } catch (e) {
        console.error('Failed to load data from IndexedDB', e);
      } finally {
        setLoading(false);
      }
    };

    loadData();

    return () => {
      cleanupEyeComfort();
    };
  }, []);

  // Restore study session if restored into study/quiz view after app suspend
  useEffect(() => {
    if (cards.length > 0 && studyCards.length === 0 && (view === 'study' || view === 'quiz')) {
      const target = currentFolderId ? cards.filter(c => c.folderId === currentFolderId) : cards.filter(c => !c.folderId);
      if (target.length > 0) {
        setStudyCards(target);
      } else if (cards.length > 0) {
        setStudyCards(cards);
      }
    }
  }, [cards, currentFolderId, view, studyCards.length]);

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('darkMode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('darkMode', 'false');
    }
  };

  const saveCards = async (newCards: Card[]) => {
    try {
      const now = Date.now();
      const stampedCards = newCards.map(c => ({
        ...c,
        updatedAt: c.updatedAt || now
      }));
      await set('flashcards', stampedCards);
      setCards(stampedCards);
      syncService.notifyLocalChange();
    } catch (e) {
      setGlobalAlert('স্টোরেজ এরর! নতুন ডাটা সেভ করা যাচ্ছে না।');
    }
  };

  const saveFolders = async (newFolders: Folder[]) => {
    try {
      const now = Date.now();
      const stampedFolders = newFolders.map(f => ({
        ...f,
        updatedAt: f.updatedAt || now
      }));
      await set('folders', stampedFolders);
      setFolders(stampedFolders);
      syncService.notifyLocalChange();
    } catch (e) {
      setGlobalAlert('স্টোরেজ এরর!');
    }
  };

  const addFolder = (name: string, parentId?: number) => {
    const now = Date.now();
    const newFolder: Folder = { id: now, name, parentId, createdAt: now, updatedAt: now };
    saveFolders([newFolder, ...folders]);
  };

  const deleteFolder = (id: number) => {
    syncService.trackDeletion('folder', id);
    const cardsInFolder = cards.filter(c => c.folderId === id);
    cardsInFolder.forEach(c => syncService.trackDeletion('card', c.id));
    saveFolders(folders.filter(f => f.id !== id));
    saveCards(cards.filter(c => c.folderId !== id));
  };

  const moveItem = (itemId: number, targetFolderId: number | null, itemType: 'card' | 'folder') => {
    const now = Date.now();
    if (itemType === 'card') {
      saveCards(cards.map(c => c.id === itemId ? { ...c, folderId: targetFolderId || undefined, updatedAt: now } : c));
    } else {
      saveFolders(folders.map(f => f.id === itemId ? { ...f, parentId: targetFolderId || undefined, updatedAt: now } : f));
    }
  };

  const saveCardAction = (card: Card) => {
    const now = Date.now();
    if (editingCardId) {
      saveCards(cards.map(c => c.id === editingCardId ? { ...card, id: editingCardId, createdAt: c.createdAt || now, updatedAt: now } : c));
    } else {
      saveCards([{ ...card, createdAt: now, updatedAt: now }, ...cards]);
    }
    setEditingCardId(null);
    navigateTo(currentFolderId ? 'folder' : 'dashboard', currentFolderId, null);
  };

  const bulkCreateCards = async (newCards: Card[]) => {
    try {
      const { update, get } = await import('idb-keyval');
      
      if (newCards && newCards.length > 0) {
        const now = Date.now();
        const stamped = newCards.map(c => ({ ...c, createdAt: c.createdAt || now, updatedAt: now }));
        
        // Batch large arrays into smaller chunks for IDB to avoid transaction blocking
        const CHUNK_SIZE = 10;
        
        for (let i = 0; i < stamped.length; i += CHUNK_SIZE) {
           const chunk = stamped.slice(i, i + CHUNK_SIZE);
           await update('flashcards', (val: any) => {
              const current = (val as Card[]) || [];
              // Perform upsert based on card ID to prevent duplicates when reviewing
              const currentMap = new Map(current.map(c => [c.id, c]));
              for (const c of chunk) {
                 currentMap.set(c.id, c);
              }
              return Array.from(currentMap.values());
           });
        }
      }
      
      const latest = (await get('flashcards')) || [];
      setCards(latest);
      syncService.notifyLocalChange();
    } catch (e) {
      console.error('Failed to bulk save cards:', e);
    }
  };

  const deleteMultipleCards = (ids: number[], itemType: 'card'|'folder' = 'card') => {
    if (itemType === 'card') {
      ids.forEach(id => syncService.trackDeletion('card', id));
      saveCards(cards.filter(c => !ids.includes(c.id)));
    } else {
      ids.forEach(id => {
        syncService.trackDeletion('folder', id);
        const cardsInFolder = cards.filter(c => c.folderId === id);
        cardsInFolder.forEach(c => syncService.trackDeletion('card', c.id));
      });
      saveFolders(folders.filter(f => !ids.includes(f.id)));
      saveCards(cards.filter(c => !c.folderId || !ids.includes(c.folderId)));
    }
  };

  const moveMultipleCards = (ids: number[], targetFolderId: number | null, itemType: 'card'|'folder' = 'card') => {
    const now = Date.now();
    if (itemType === 'card') {
      saveCards(cards.map(c => ids.includes(c.id) ? { ...c, folderId: targetFolderId || undefined, updatedAt: now } : c));
    } else {
      saveFolders(folders.map(f => ids.includes(f.id) ? { ...f, parentId: targetFolderId || undefined, updatedAt: now } : f));
    }
  };

  const deleteCard = (id: number) => {
    syncService.trackDeletion('card', id);
    saveCards(cards.filter(c => c.id !== id));
  };

  const updateCard = (id: number, updates: Partial<Card>) => {
    saveCards(cards.map(c => c.id === id ? { ...c, ...updates, updatedAt: Date.now() } : c));
  };

  const toggleFavorite = (cardId: number) => {
    const card = cards.find(c => c.id === cardId);
    if (!card) return;
    const nextFav = !card.favorite;
    updateCard(cardId, { favorite: nextFav });
  };

  const renameCard = (id: number, newTitle: string) => {
    saveCards(cards.map(c => c.id === id ? { ...c, title: newTitle, updatedAt: Date.now() } : c));
  };

  const addTagToCards = (cardIds: number[], tag: string) => {
    const cleaned = tag.trim().replace(/^#+/, '').trim();
    if (!cleaned) return;
    const now = Date.now();
    saveCards(cards.map(c => {
      if (!cardIds.includes(c.id)) return c;
      const currentTags = Array.isArray(c.tags) ? c.tags : [];
      if (currentTags.some(t => t.trim().replace(/^#+/, '').toLowerCase() === cleaned.toLowerCase())) {
        return c;
      }
      return {
        ...c,
        tags: [...currentTags, cleaned],
        updatedAt: now
      };
    }));
  };

  const recoverLegacyData = async () => {
    try {
      const saved = localStorage.getItem('occlusionCards');
      if (saved) {
        const legacyCards = JSON.parse(saved);
        if (legacyCards && legacyCards.length > 0) {
          await importData(legacyCards);
          setGlobalAlert('রিকভারি সফল! ' + legacyCards.length + ' টি পুরোনো কার্ড উদ্ধার করা সম্ভব হয়েছে।');
          return;
        }
      }
      setGlobalAlert('দুঃখিত, আপনার ডিভাইসে কোনো পুরোনো ডাটার ব্যাকআপ পাওয়া যায়নি।');
    } catch(e) {
      setGlobalAlert('রিকভারি করার সময় একটি সমস্যা হয়েছে।');
    }
  };

  const importData = async (data: any) => {
    if (data.cards && data.folders) {
      const mergedFolders = [...folders];
      data.folders.forEach((newFolder: Folder) => {
        const idx = mergedFolders.findIndex(f => f.id === newFolder.id);
        if (idx >= 0) {
          mergedFolders[idx] = newFolder;
        } else {
          mergedFolders.push(newFolder);
        }
      });
      await saveFolders(mergedFolders);

      const mergedCards = [...cards];
      data.cards.forEach((newCard: Card) => {
        const idx = mergedCards.findIndex(c => c.id === newCard.id);
        if (idx >= 0) {
          mergedCards[idx] = newCard;
        } else {
          mergedCards.push(newCard);
        }
      });
      await saveCards(mergedCards);
      setGlobalAlert('ডাটা সফলভাবে ইমপোর্ট করা হয়েছে!');
    } else if (Array.isArray(data)) {
      const mergedCards = [...cards];
      data.forEach((newCard: Card) => {
        const idx = mergedCards.findIndex(c => c.id === newCard.id);
        if (idx >= 0) {
          mergedCards[idx] = newCard;
        } else {
          mergedCards.push(newCard);
        }
      });
      await saveCards(mergedCards);
      setGlobalAlert('ডাটা সফলভাবে ইমপোর্ট করা হয়েছে!');
    } else {
      setGlobalAlert('ভুল ফাইল ফরম্যাট!');
    }
  };

  // Called when cloud sync restores or syncs data without recursive saveCards/saveFolders loop
  const handleSyncDataLoaded = (data: { cards: Card[]; folders: Folder[] }) => {
    setCards(data.cards);
    setFolders(data.folders);
  };

  const startStudy = (cardsToStudy: Card[], index: number = 0, shuffled: boolean = false) => {
    if (cardsToStudy.length === 0) return;
    if (shuffled) {
      const shuffledList = [...cardsToStudy].sort(() => Math.random() - 0.5);
      setStudyCards(shuffledList);
      setStudyIndex(0);
    } else {
      setStudyCards(cardsToStudy);
      setStudyIndex(index);
    }
    navigateTo('study', currentFolderId);
  };

  const startQuiz = (cardsToStudy: Card[]) => {
    if (cardsToStudy.length === 0) return;
    const shuffledList = [...cardsToStudy].sort(() => Math.random() - 0.5);
    setStudyCards(shuffledList);
    navigateTo('quiz', currentFolderId);
  };

  const handleEditCard = (id: number) => {
    const card = cards.find(c => c.id === id);
    const targetFolder = card?.folderId !== undefined ? card.folderId : (currentFolderId || null);
    navigateTo('create', targetFolder, id);
  };

  const handleCancelEdit = () => {
    setEditingCardId(null);
    navigateTo(currentFolderId ? 'folder' : 'dashboard', currentFolderId, null);
  };

  const handleFinishLaunch = () => {
    setIsLaunching(false);
    try {
      sessionStorage.setItem('io_has_launched', 'true');
    } catch (e) {}
  };

  if (loading || isLaunching) {
    return <AppLaunchScreen minDuration={isLaunching ? 400 : 0} onFinish={handleFinishLaunch} />;
  }

  return (
    <div className="bg-gray-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 h-screen overflow-hidden flex flex-col font-sans transition-colors animate-in fade-in duration-300">
      {globalAlert && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-[99999] p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4 dark:text-white">{globalAlert}</h3>
            <button onClick={() => setGlobalAlert('')} className="w-full bg-blue-600 text-white py-2 rounded-lg font-medium cursor-pointer">ঠিক আছে</button>
          </div>
        </div>
      )}

      {/* Android Back Button Toast */}
      {backToast && (
        <div className="fixed bottom-14 left-1/2 -translate-x-1/2 z-[99999] bg-slate-900/95 text-white text-xs font-semibold px-4 py-2.5 rounded-full shadow-2xl border border-slate-700 pointer-events-none animate-in fade-in zoom-in-95 duration-200">
          {backToast}
        </div>
      )}

      {hasAppUpdate && (
        <div className="fixed top-2 left-1/2 -translate-x-1/2 z-[99998] max-w-md w-[92%] bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-600 text-white px-3.5 py-2.5 rounded-2xl shadow-2xl flex items-center justify-between gap-2 border border-white/30 animate-in slide-in-from-top-3 duration-300">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-300 animate-ping shrink-0" />
            <span className="text-xs font-bold truncate">মেমোরি কার্ডের নতুন আপডেট এসেছে!</span>
          </div>
          <button
            onClick={() => appUpdateService.applyUpdateAndReload()}
            className="px-3 py-1 bg-white text-blue-700 hover:bg-blue-50 active:scale-95 rounded-xl text-xs font-bold shrink-0 shadow-xs transition-all cursor-pointer"
          >
            এখনই রিলোড
          </button>
        </div>
      )}

      {view === 'dashboard' && (
        <Dashboard
          cards={cards}
          folders={folders}
          darkMode={darkMode}
          toggleDarkMode={toggleDarkMode}
          onAddFolder={addFolder}
          onDeleteFolder={deleteFolder}
          onOpenFolder={(id) => navigateTo('folder', id)}
          onMoveItem={moveItem}
          onDelete={deleteCard}
          onDeleteMultiple={deleteMultipleCards}
          onMoveMultiple={moveMultipleCards}
          onRename={renameCard}
          onEdit={handleEditCard}
          onImport={importData}
          onSyncDataLoaded={handleSyncDataLoaded}
          onRecoverLegacy={recoverLegacyData}
          onAddTagToCards={addTagToCards}
          onToggleFavorite={toggleFavorite}
          onStartStudy={(index, shuffled, studyCards) => startStudy(studyCards || cards.filter(c => !c.folderId), index, shuffled)}
          onStartQuiz={(studyCards) => startQuiz(studyCards || cards.filter(c => !c.folderId))}
          onCreateNew={() => navigateTo('create', null, null)}
          onStartBulkEdit={(cards) => {
            setBulkEditQueue(cards);
            navigateTo('bulk-edit', currentFolderId);
          }}
          onBulkCreate={bulkCreateCards}
        />
      )}
      
      {view === 'folder' && currentFolderId !== null && (
        <FolderView 
          folder={folders.find(f => f.id === currentFolderId)!}
          cards={cards.filter(c => c.folderId === currentFolderId)}
          folders={folders.filter(f => f.parentId === currentFolderId)}
          allFolders={folders}
          onAddFolder={(name) => addFolder(name, currentFolderId)}
          onDeleteFolder={deleteFolder}
          onOpenFolder={(id) => navigateTo('folder', id)}
          onMoveItem={moveItem}
          onBack={() => {
            const current = folders.find(f => f.id === currentFolderId);
            if (current && current.parentId) {
              navigateTo('folder', current.parentId);
            } else {
              navigateTo('dashboard', null);
            }
          }}
          onDelete={deleteCard}
          onDeleteMultiple={deleteMultipleCards}
          onMoveMultiple={moveMultipleCards}
          onRename={renameCard}
          onEdit={handleEditCard}
          onStartStudy={(index, shuffled, studyCards) => startStudy(studyCards || cards.filter(c => c.folderId === currentFolderId), index, shuffled)}
          onStartQuiz={(studyCards) => startQuiz(studyCards || cards.filter(c => c.folderId === currentFolderId))}
          onCreateNew={() => navigateTo('create', currentFolderId, null)}
          onStartBulkEdit={(bulkCards) => {
            setBulkEditQueue(bulkCards);
            navigateTo('bulk-edit', currentFolderId);
          }}
          onBulkCreate={bulkCreateCards}
          allCards={cards}
          darkMode={darkMode}
          toggleDarkMode={toggleDarkMode}
          onImport={importData}
          onSyncDataLoaded={handleSyncDataLoaded}
          onAddTagToCards={addTagToCards}
          onToggleFavorite={toggleFavorite}
        />
      )}

      {view === 'create' && (
        <div key={editingCardId || 'new'} className="h-full">
          <CreateCard
            folderId={currentFolderId}
            editingCard={editingCardId ? cards.find(c => c.id === editingCardId) : undefined}
            existingTags={getAllTags(cards).map(t => t.name)}
            onSave={saveCardAction}
            onCancel={handleCancelEdit}
            onBulkCreate={bulkCreateCards}
          />
        </div>
      )}
      
      {view === 'study' && (
        <StudyCard
          cards={studyCards}
          initialIndex={studyIndex}
          onEdit={handleEditCard}
          onUpdateCard={updateCard}
          onClose={() => navigateTo(currentFolderId ? 'folder' : 'dashboard', currentFolderId)}
        />
      )}

      {view === 'quiz' && (
        <QuizMode
          cards={studyCards}
          onUpdateCard={updateCard}
          onClose={() => navigateTo(currentFolderId ? 'folder' : 'dashboard', currentFolderId)}
        />
      )}

      {view === 'bulk-edit' && bulkEditQueue.length > 0 && (
        <div key={bulkEditQueue[0].id} className="h-full">
          <CreateCard
            folderId={bulkEditQueue[0].folderId ?? currentFolderId}
            editingCard={bulkEditQueue[0]}
            existingTags={getAllTags(cards).map(t => t.name)}
            isBulkEdit={true}
            bulkRemaining={bulkEditQueue.length}
            onSave={(updatedCard) => {
              const newCards = [updatedCard, ...cards];
              saveCards(newCards);
              
              const nextQueue = bulkEditQueue.slice(1);
              if (nextQueue.length > 0) {
                setBulkEditQueue(nextQueue);
              } else {
                navigateTo(currentFolderId ? 'folder' : 'dashboard', currentFolderId);
              }
            }}
            onSkip={() => {
              const nextQueue = bulkEditQueue.slice(1);
              if (nextQueue.length > 0) {
                setBulkEditQueue(nextQueue);
              } else {
                navigateTo(currentFolderId ? 'folder' : 'dashboard', currentFolderId);
              }
            }}
            onCancel={() => {
              setBulkEditQueue([]);
              navigateTo(currentFolderId ? 'folder' : 'dashboard', currentFolderId);
            }}
          />
        </div>
      )}

      {(view === 'study' || view === 'quiz') && <EyeCareTimer />}
    </div>
  );
}
