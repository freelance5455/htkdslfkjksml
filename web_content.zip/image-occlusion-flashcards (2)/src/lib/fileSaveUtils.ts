/**
 * Universal file save, share, and export utilities for Web, PWA, and Android WebView (AppsGeyser / TWA / APK).
 * Solves Android WebView storage permission restrictions ("Don't permission granted" / "Download failed")
 * by providing:
 *  1. Web Share API (native Android system sheet allowing "Save to device", Google Drive, Keep, etc. with 0 permissions)
 *  2. Server-side HTTPS download (so Android DownloadManager receives a valid HTTPS URL, never a failing blob: URL)
 *  3. Automatic & 1-click clipboard backup safeguards (100% permission-free guarantee)
 */

export interface SaveFileResult {
  success: boolean;
  method: 'shared' | 'downloaded' | 'copied' | 'cancelled' | 'error';
  message: string;
}

/**
 * Detects if the current device is Android.
 */
export function isAndroidDevice(): boolean {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
  return /Android/i.test(navigator.userAgent || '');
}

/**
 * Detects if the current environment is an Android WebView / APK wrapper (e.g. AppsGeyser com.wFlashcard).
 */
export function isAndroidWebView(): boolean {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent || '';
  const isAndroid = /Android/i.test(ua);
  if (!isAndroid) return false;

  // AppsGeyser package name in UA or standard WebView indicators
  const isWv = /wv|Version\/[0-9.]+|com\.wFlashcard|Crosswalk/i.test(ua);
  const isStandalone = (window.navigator as any).standalone === true ||
    (typeof window.matchMedia === 'function' && window.matchMedia('(display-mode: standalone)').matches);
  const isChromeWithoutRuntime = Boolean((window as any).chrome && !(window as any).chrome?.runtime);

  // In Android wrappers, either explicit webview flag or standalone display
  return isWv || isStandalone || isAndroid;
}

/**
 * Copies text safely to clipboard on any device or WebView (works with 0 permissions).
 */
export async function copyTextToClipboard(text: string): Promise<boolean> {
  try {
    if (typeof navigator !== 'undefined' && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (err) {
    console.warn('navigator.clipboard failed, attempting fallback textarea copy:', err);
  }

  // Reliable textarea execCommand fallback for restricted WebViews
  try {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.setAttribute('readonly', '');
    textArea.style.position = 'fixed';
    textArea.style.top = '0';
    textArea.style.left = '-999999px';
    textArea.style.opacity = '0';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    // For iOS and mobile devices
    textArea.setSelectionRange(0, text.length);
    const successful = document.execCommand('copy');
    document.body.removeChild(textArea);
    return successful;
  } catch (e) {
    console.warn('Fallback clipboard copy failed:', e);
    return false;
  }
}

/**
 * Executes a server-side HTTPS file download.
 * Android DownloadManager CANNOT download blob: or data: URIs and fails with "download failed".
 * By registering the download on the server, DownloadManager receives a standard https:// URL.
 */
export async function triggerServerDownload(
  filename: string,
  content: string,
  mimeType = 'application/json'
): Promise<boolean> {
  try {
    const res = await fetch('/api/prepare-download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename, content, mimeType })
    });

    if (!res.ok) {
      throw new Error(`Server download prepare returned status ${res.status}`);
    }

    const data = await res.json();
    if (data?.downloadUrl) {
      // In Android WebViews and browsers, assigning window.location to a Content-Disposition HTTPS endpoint
      // triggers Android DownloadManager or browser download cleanly without blob URI failure.
      window.location.href = data.downloadUrl;
      return true;
    }
    return false;
  } catch (err) {
    console.warn('Server download route failed, trying fallback direct download:', err);
    return triggerDirectDownload(filename, content, mimeType);
  }
}

/**
 * Executes a direct browser file download via Blob URL (ideal for desktop browsers).
 */
export function triggerDirectDownload(filename: string, content: string, mimeType = 'application/json'): boolean {
  try {
    const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      try {
        if (link.parentNode) {
          link.parentNode.removeChild(link);
        }
        URL.revokeObjectURL(url);
      } catch (e) {
        // Ignored
      }
    }, 120000);

    return true;
  } catch (err) {
    console.warn('Direct blob download failed, trying data URI:', err);
    try {
      const dataUri = `data:${mimeType};charset=utf-8,` + encodeURIComponent(content);
      const link = document.createElement('a');
      link.href = dataUri;
      link.download = filename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (link.parentNode) link.parentNode.removeChild(link);
      }, 1000);
      return true;
    } catch (e) {
      console.error('Data URI download failed:', e);
      return false;
    }
  }
}

/**
 * Universal save or share JSON with built-in safeguards for Android APK "Download failed" errors.
 */
export async function saveOrShareJSON(
  filename: string,
  data: any,
  title = 'মেমোরি কার্ড ব্যাকআপ ফাইল'
): Promise<SaveFileResult> {
  const jsonContent = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
  const isAndroid = isAndroidDevice();

  // 1. Preemptively safeguard by copying to clipboard
  // This guarantees that the user NEVER loses their backup even if the system has blocked downloads
  let clipboardCopied = false;
  try {
    clipboardCopied = await copyTextToClipboard(jsonContent);
  } catch (e) {
    // Ignored
  }

  // 2. Web Share API (Primary recommended choice on Android/mobile)
  // Opens native Android share sheet with options: "Save to device" / "Files by Google" / "Google Drive" / "Keep"
  // Completely bypasses app storage permissions!
  if (typeof navigator !== 'undefined' && navigator.canShare && typeof File !== 'undefined') {
    try {
      const file = new File([jsonContent], filename, { type: 'application/json' });
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: title,
          text: `${title} - Image Occlusion Flashcards`
        });
        return {
          success: true,
          method: 'shared',
          message: 'ব্যাকআপ ফাইল সফলভাবে শেয়ার/সংরক্ষণ করা হয়েছে!'
        };
      }
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        return {
          success: false,
          method: 'cancelled',
          message: 'সংরক্ষণ বাতিল করা হয়েছে।'
        };
      }
      console.warn('Web Share with files failed, attempting fallback:', err);
    }
  }

  // 3. For Android devices, trigger server HTTPS download to prevent "Download failed" blob error
  if (isAndroid) {
    try {
      const serverDownloadTriggered = await triggerServerDownload(filename, jsonContent, 'application/json');
      if (serverDownloadTriggered) {
        return {
          success: true,
          method: 'downloaded',
          message: 'ফাইল ডাউনলোড শুরু হয়েছে! (ব্যাকআপ কোড ক্লিপবোর্ডেও সুরক্ষিত রাখা হয়েছে)'
        };
      }
    } catch (e) {
      console.warn('Android server download attempt failed:', e);
    }

    // If server download was blocked by wrapper, clipboard copy is already done
    return {
      success: true,
      method: 'copied',
      message: 'সম্পূর্ণ ব্যাকআপ আপনার ক্লিপবোর্ডে কপি হয়েছে! কোনো স্টোরেজ পারমিশন ছাড়াই এটি সুরক্ষিত। আপনার ফোনের নোটপ্যাড বা কিপ নোটসে পেস্ট করে রাখুন।'
    };
  }

  // 4. Standard Desktop Web Browser Download
  const downloadTriggered = triggerDirectDownload(filename, jsonContent, 'application/json');

  if (downloadTriggered) {
    return {
      success: true,
      method: 'downloaded',
      message: 'ফাইল ডাউনলোড শুরু হয়েছে!'
    };
  }

  // 5. Fallback: Copy to clipboard if download was blocked
  if (!clipboardCopied) {
    const ok = await copyTextToClipboard(jsonContent);
    if (ok) {
      return {
        success: true,
        method: 'copied',
        message: 'ডাউনলোড সমর্থিত না হওয়ায় সম্পূর্ণ ব্যাকআপ ক্লিপবোর্ডে কপি করা হয়েছে! নোটপ্যাডে পেস্ট করে রাখুন।'
      };
    }
  }

  return {
    success: false,
    method: 'error',
    message: 'ফাইলটি ডাউনলোড বা সংরক্ষণ করা যায়নি।'
  };
}
