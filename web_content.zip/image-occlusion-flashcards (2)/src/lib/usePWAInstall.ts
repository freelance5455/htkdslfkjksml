import { useEffect, useState } from 'react';
import { requestPhonePersistence, checkStorageStatus, StorageInfo } from './storageUtils';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [storageInfo, setStorageInfo] = useState<StorageInfo | null>(null);

  useEffect(() => {
    // Detect standalone mode (already installed as WebAPK / standalone app / APK)
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      window.matchMedia('(display-mode: fullscreen)').matches ||
      window.matchMedia('(display-mode: minimal-ui)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true ||
      document.referrer.includes('android-app://') ||
      /wv|android.*version\/[0-9\.]+|com\.wflashcard|wflashcard/i.test(userAgent) ||
      (window as unknown as { Android?: unknown }).Android !== undefined ||
      window.location.protocol === 'file:' ||
      (typeof localStorage !== 'undefined' && localStorage.getItem('is_apk_mode') === 'true');

    setIsInstalled(isStandalone);

    // Detect iOS devices
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIOSDevice);

    // Request persistent phone storage immediately
    requestPhonePersistence().then(() => {
      checkStorageStatus().then(setStorageInfo);
    });

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
      requestPhonePersistence().then(() => {
        checkStorageStatus().then(setStorageInfo);
      });
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const install = async (): Promise<boolean> => {
    if (!deferredPrompt) return false;
    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
        await requestPhonePersistence();
        const info = await checkStorageStatus();
        setStorageInfo(info);
        return true;
      }
    } catch (err) {
      console.warn('Install prompt error:', err);
    }
    return false;
  };

  const refreshStorage = async () => {
    await requestPhonePersistence();
    const info = await checkStorageStatus();
    setStorageInfo(info);
    return info;
  };

  return {
    isInstallable: !!deferredPrompt,
    isInstalled,
    isIOS,
    install,
    storageInfo,
    refreshStorage,
  };
}
