import heic2any from 'heic2any';
import { enhanceImage, analyzeImageTone } from './imageEnhance';

export const compressImage = async (
  file: File,
  maxWidth = 2048,
  quality = 0.88,
  autoEnhance = true
): Promise<string> => {
  let fileToProcess: File | Blob = file;

  // Convert HEIC/HEIF to JPEG first
  if (
    file.type === 'image/heic' ||
    file.type === 'image/heif' ||
    file.name.toLowerCase().endsWith('.heic') ||
    file.name.toLowerCase().endsWith('.heif')
  ) {
    try {
      const convertedBlob = await heic2any({
        blob: file,
        toType: 'image/jpeg',
        quality: quality,
      });
      const blob = Array.isArray(convertedBlob) ? convertedBlob[0] : convertedBlob;
      fileToProcess = new File([blob], file.name.replace(/\.heic|\.heif/i, '.jpg'), { type: 'image/jpeg' });
    } catch (e) {
      console.warn('HEIC conversion failed, using original file', e);
    }
  }

  // Fast Canvas resize with high smoothing for maximum clarity and speed
  try {
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          resolve(reader.result);
        } else {
          reject(new Error('Failed to read file as string'));
        }
      };
      reader.onerror = () => reject(reader.error || new Error('FileReader error'));
      reader.readAsDataURL(fileToProcess);
    });

    return await new Promise<string>((resolve, reject) => {
      const img = new Image();
      img.onload = async () => {
        let width = img.naturalWidth || img.width || 800;
        let height = img.naturalHeight || img.height || 600;

        if (width > maxWidth || height > maxWidth) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxWidth) / height);
            height = maxWidth;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(dataUrl);
          return;
        }

        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);

        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        const initialDataUrl = canvas.toDataURL('image/jpeg', quality);

        if (autoEnhance) {
          try {
            const tone = analyzeImageTone(img);
            const isNightMode = tone.isDarkInverted;
            const enhanced = await enhanceImage(img, {
              brightness: isNightMode ? 20 : 16,
              contrast: isNightMode ? 28 : 22,
              invert: isNightMode,
              autoLevels: true,
              maxWidth,
            });
            resolve(enhanced);
            return;
          } catch (enhErr) {
            console.warn('Auto-enhancement non-fatal fallback:', enhErr);
          }
        }

        resolve(initialDataUrl);
      };
      img.onerror = () => reject(new Error('Failed to load image for compression'));
      img.src = dataUrl;
    });
  } catch (error) {
    console.error('Image processing error:', error);
    // Ultimate fallback if canvas or image loading completely fails
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error('Final FileReader fallback failed'));
      reader.readAsDataURL(fileToProcess);
    });
  }
};

