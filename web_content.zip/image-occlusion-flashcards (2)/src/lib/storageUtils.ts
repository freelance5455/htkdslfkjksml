/**
 * Storage persistence and quota utilities for Android WebAPK & PWA
 */

export interface StorageInfo {
  isPersisted: boolean;
  usageBytes: number;
  quotaBytes: number;
  usageMB: string;
  quotaMB: string;
  percentUsed: number;
  supported: boolean;
}

export async function requestPhonePersistence(): Promise<boolean> {
  if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
    try {
      const isPersisted = await navigator.storage.persist();
      console.log('Persistent phone storage status:', isPersisted);
      return isPersisted;
    } catch (err) {
      console.warn('Storage persist request failed:', err);
      return false;
    }
  }
  return false;
}

export async function checkStorageStatus(): Promise<StorageInfo> {
  const defaultInfo: StorageInfo = {
    isPersisted: false,
    usageBytes: 0,
    quotaBytes: 0,
    usageMB: '0.0',
    quotaMB: '0.0',
    percentUsed: 0,
    supported: false,
  };

  if (typeof navigator === 'undefined' || !navigator.storage) {
    return defaultInfo;
  }

  defaultInfo.supported = true;

  try {
    if (navigator.storage.persisted) {
      defaultInfo.isPersisted = await navigator.storage.persisted();
    }

    if (navigator.storage.estimate) {
      const estimate = await navigator.storage.estimate();
      const usage = estimate.usage || 0;
      const quota = estimate.quota || 0;

      defaultInfo.usageBytes = usage;
      defaultInfo.quotaBytes = quota;
      defaultInfo.usageMB = (usage / (1024 * 1024)).toFixed(1);
      defaultInfo.quotaMB = (quota / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
      defaultInfo.percentUsed = quota > 0 ? Math.min(100, Math.round((usage / quota) * 100)) : 0;
    }
  } catch (e) {
    console.warn('Error checking storage estimate:', e);
  }

  return defaultInfo;
}
