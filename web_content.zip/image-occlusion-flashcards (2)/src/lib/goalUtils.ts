/**
 * Smart Daily Goal and Streak Tracker
 */

export interface DailyGoalData {
  target: number;
  todayCount: number;
  streak: number;
  lastStudiedDate: string;
}

const STORAGE_KEY = 'occlusion_daily_habit_stats';

const getTodayDateString = (): string => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const getYesterdayDateString = (): string => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const getDailyGoalStats = (): DailyGoalData => {
  const today = getTodayDateString();
  const defaultData: DailyGoalData = {
    target: 15,
    todayCount: 0,
    streak: 0,
    lastStudiedDate: ''
  };

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultData;
    const parsed = JSON.parse(raw);

    // If last studied date is today, return current count
    if (parsed.lastStudiedDate === today) {
      return {
        target: parsed.target || 15,
        todayCount: parsed.todayCount || 0,
        streak: parsed.streak || 1,
        lastStudiedDate: today
      };
    }

    // If last studied date is yesterday, streak continues! Today starts at 0
    if (parsed.lastStudiedDate === getYesterdayDateString()) {
      return {
        target: parsed.target || 15,
        todayCount: 0,
        streak: parsed.streak || 1,
        lastStudiedDate: parsed.lastStudiedDate
      };
    }

    // Missed more than 1 day, streak reset
    return {
      target: parsed.target || 15,
      todayCount: 0,
      streak: 0,
      lastStudiedDate: parsed.lastStudiedDate || ''
    };
  } catch {
    return defaultData;
  }
};

export const incrementDailyStudyCount = (count = 1): DailyGoalData => {
  const today = getTodayDateString();
  const yesterday = getYesterdayDateString();
  const current = getDailyGoalStats();

  let newStreak = current.streak;
  if (current.lastStudiedDate === today) {
    // Already studied today
    newStreak = Math.max(1, current.streak);
  } else if (current.lastStudiedDate === yesterday) {
    // Continued consecutive streak
    newStreak = (current.streak || 0) + 1;
  } else {
    // Fresh start
    newStreak = 1;
  }

  const updated: DailyGoalData = {
    target: current.target,
    todayCount: current.todayCount + count,
    streak: newStreak,
    lastStudiedDate: today
  };

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to save habit stats', e);
  }

  return updated;
};

export const setDailyGoalTarget = (newTarget: number): DailyGoalData => {
  const current = getDailyGoalStats();
  const updated = { ...current, target: Math.max(5, newTarget) };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch {}
  return updated;
};
