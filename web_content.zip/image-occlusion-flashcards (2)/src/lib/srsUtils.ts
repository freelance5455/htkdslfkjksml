import { Card } from '../types';

export type SrsRating = 'again' | 'hard' | 'good' | 'easy';

export type SrsState = 'new' | 'learning' | 'review' | 'mastered';

export interface SrsResult {
  interval: number; // in days
  repetition: number;
  easeFactor: number;
  nextReview: number; // timestamp in ms
  lastReviewed: number;
  lapses: number;
  state: SrsState;
}

/**
 * SuperMemo-2 (SM-2) algorithm implementation
 * 
 * Standard SM-2 mathematical formula:
 * EF' = EF + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))
 * where q in [0..5], and EF' >= 1.3
 * 
 * Interval progression:
 * I(1) = 1 day
 * I(2) = 6 days
 * I(n) = I(n-1) * EF
 */
export function calculateSrs(
  rating: SrsRating,
  currentInterval = 0,
  currentRepetition = 0,
  currentEaseFactor = 2.5,
  currentLapses = 0
): SrsResult {
  let interval = currentInterval;
  let repetition = currentRepetition;
  let easeFactor = currentEaseFactor || 2.5;
  let lapses = currentLapses || 0;
  const now = Date.now();

  // Map 4-button rating to SuperMemo quality grade q in [0..5]
  // Again: q = 1 (complete recall blackout)
  // Hard:  q = 3 (correct response with difficulty)
  // Good:  q = 4 (correct response after hesitation - optimal)
  // Easy:  q = 5 (instantaneous, effortless recall)
  const qualityMap: Record<SrsRating, number> = {
    again: 1,
    hard: 3,
    good: 4,
    easy: 5,
  };

  const q = qualityMap[rating];

  if (rating === 'again') {
    // Recall failure: reset consecutive repetition count and increment lapse
    repetition = 0;
    lapses += 1;
    interval = 1; // Re-test tomorrow (1-day learning interval)

    // In SM-2 with Anki dampening, drop EF by 0.20 to avoid catastrophic ease drop while reflecting difficulty
    easeFactor = Math.max(1.3, easeFactor - 0.20);
  } else if (rating === 'hard') {
    // Recall with difficulty: small penalty to EF
    // SM-2 formula for q=3: EF + (0.1 - 2 * (0.08 + 0.04)) = EF - 0.14
    easeFactor = Math.max(1.3, easeFactor + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)));

    if (repetition === 0) {
      interval = 1;
    } else if (repetition === 1) {
      interval = 3; // shorter interval for hard recall
    } else {
      // Advance interval with conservative factor (1.2x)
      interval = Math.max(interval + 1, Math.round((interval || 1) * 1.2));
    }
    repetition += 1;
  } else if (rating === 'good') {
    // Normal optimal recall:
    // SM-2 formula for q=4: EF + (0.1 - 1 * 0.10) = EF (unchanged)
    easeFactor = Math.max(1.3, easeFactor + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)));

    if (repetition === 0) {
      interval = 1; // Day 1
    } else if (repetition === 1) {
      interval = 6; // Day 6 (classic SM-2 step 2)
    } else {
      interval = Math.max(interval + 1, Math.round((interval || 1) * easeFactor));
    }
    repetition += 1;
  } else if (rating === 'easy') {
    // Effortless recall: reward EF bonus (+0.10) and interval bonus
    // SM-2 formula for q=5: EF + (0.1 - 0) = EF + 0.10
    easeFactor = Math.round((easeFactor + 0.10) * 100) / 100;

    if (repetition === 0) {
      interval = 4; // Easy start skips to 4 days
    } else if (repetition === 1) {
      interval = 10; // Easy step 2
    } else {
      // Standard 1.3x easy bonus on top of easeFactor
      interval = Math.max(interval + 2, Math.round((interval || 1) * easeFactor * 1.3));
    }
    repetition += 1;
  }

  // Ensure easeFactor is bounded between 1.3 and 3.5
  easeFactor = Math.min(3.5, Math.max(1.3, Math.round(easeFactor * 100) / 100));

  const nextReview = now + interval * 24 * 60 * 60 * 1000;

  // Determine SRS State
  let state: SrsState = 'review';
  if (repetition === 0) {
    state = 'learning';
  } else if (repetition >= 3 || interval >= 21) {
    state = 'mastered';
  }

  return {
    interval,
    repetition,
    easeFactor,
    nextReview,
    lastReviewed: now,
    lapses,
    state,
  };
}

/**
 * Check if a card is currently due for review
 */
export function isCardDue(card: Card, now = Date.now()): boolean {
  if (!card.nextReview) return true; // New cards are due for initial study
  return card.nextReview <= now;
}

/**
 * Check if an already reviewed card is overdue/due
 */
export function isReviewedCardDue(card: Card, now = Date.now()): boolean {
  return Boolean(card.nextReview && card.nextReview <= now);
}

/**
 * Check if a card is completely new (never studied)
 */
export function isCardNew(card: Card): boolean {
  return (!card.lastReviewed && (!card.repetition || card.repetition === 0) && (!card.interval || card.interval === 0));
}

/**
 * Check if a card is mastered (3+ consecutive repetitions or 21+ days interval)
 */
export function isCardMastered(card: Card): boolean {
  return Boolean((card.repetition && card.repetition >= 3) || (card.interval && card.interval >= 21));
}

/**
 * Check if a card is currently in learning/re-learning phase
 */
export function isCardLearning(card: Card): boolean {
  return Boolean(!isCardNew(card) && (card.repetition === 0 || (card.interval && card.interval <= 3)));
}

/**
 * Sort cards into an optimal SuperMemo-2 study queue:
 * 1. Overdue cards first (oldest review debt first)
 * 2. Due cards for today
 * 3. Lapsed / active learning cards
 * 4. Brand new unstudied cards
 * 5. Future cards (sorted by nextReview ascending)
 */
export function sortCardsForOptimalReview(cards: Card[], now = Date.now()): Card[] {
  return [...cards].sort((a, b) => {
    const aDue = isCardDue(a, now);
    const bDue = isCardDue(b, now);

    // If both are due, prioritize already reviewed cards that are most overdue
    if (aDue && bDue) {
      const aTime = a.nextReview || 0;
      const bTime = b.nextReview || 0;
      // Overdue first (smaller timestamp = older/more overdue)
      if (aTime !== bTime) return aTime - bTime;
      // Then prioritize lapsed cards
      return (b.lapses || 0) - (a.lapses || 0);
    }

    // Due cards come before non-due cards
    if (aDue && !bDue) return -1;
    if (!aDue && bDue) return 1;

    // Both are in the future: sort by nextReview ascending
    return (a.nextReview || Infinity) - (b.nextReview || Infinity);
  });
}

/**
 * Get comprehensive SRS statistics for a collection of cards
 */
export function getSrsOverview(cards: Card[], now = Date.now()) {
  let dueCount = 0;
  let newCount = 0;
  let learningCount = 0;
  let reviewCount = 0;
  let masteredCount = 0;

  cards.forEach(card => {
    if (isCardNew(card)) {
      newCount++;
      dueCount++; // New cards count as due for initial study
    } else if (card.nextReview && card.nextReview <= now) {
      dueCount++;
      if (card.repetition === 0) learningCount++;
      else if (isCardMastered(card)) masteredCount++;
      else reviewCount++;
    } else if (isCardMastered(card)) {
      masteredCount++;
    } else if (isCardLearning(card)) {
      learningCount++;
    } else {
      reviewCount++;
    }
  });

  return {
    total: cards.length,
    dueCount,
    newCount,
    learningCount,
    reviewCount,
    masteredCount,
  };
}

/**
 * Format interval into localized Bengali text
 */
export function formatIntervalBengali(days: number): string {
  if (days <= 0) return '< ১ দিন';
  if (days === 1) return '১ দিন';
  if (days < 30) return `${days} দিন`;
  const months = Math.round(days / 30);
  if (months < 12) return `${months} মাস`;
  const years = (days / 365).toFixed(1);
  return `${years} বছর`;
}

/**
 * Format next review date into friendly Bengali text
 */
export function formatNextReviewBengali(nextReview?: number, now = Date.now()): string {
  if (!nextReview) return 'নতুন কার্ড';
  
  const diffMs = nextReview - now;
  if (diffMs <= 0) return 'আজকে বাকি';

  const diffDays = Math.round(diffMs / (24 * 60 * 60 * 1000));
  if (diffDays <= 0) return 'আজকে পরে';
  if (diffDays === 1) return 'আগামীকাল';
  if (diffDays < 30) return `${diffDays} দিন পর`;
  const diffMonths = Math.round(diffDays / 30);
  if (diffMonths < 12) return `${diffMonths} মাস পর`;
  return `${(diffDays / 365).toFixed(1)} বছর পর`;
}

/**
 * Generate preview interval text for Again, Hard, Good, Easy buttons
 */
export function getEstimatedIntervals(
  currentInterval = 0,
  currentRepetition = 0,
  currentEaseFactor = 2.5,
  currentLapses = 0
): Record<SrsRating, { days: number; text: string }> {
  const again = calculateSrs('again', currentInterval, currentRepetition, currentEaseFactor, currentLapses);
  const hard = calculateSrs('hard', currentInterval, currentRepetition, currentEaseFactor, currentLapses);
  const good = calculateSrs('good', currentInterval, currentRepetition, currentEaseFactor, currentLapses);
  const easy = calculateSrs('easy', currentInterval, currentRepetition, currentEaseFactor, currentLapses);

  return {
    again: { days: again.interval, text: formatIntervalBengali(again.interval) },
    hard: { days: hard.interval, text: formatIntervalBengali(hard.interval) },
    good: { days: good.interval, text: formatIntervalBengali(good.interval) },
    easy: { days: easy.interval, text: formatIntervalBengali(easy.interval) },
  };
}

/**
 * Get visual badge and status info for a card
 */
export function getCardSrsBadge(card: Card, now = Date.now()): {
  text: string;
  badgeClass: string;
  isDue: boolean;
  type: 'due' | 'new' | 'learning' | 'mastered' | 'review';
} {
  if (isCardNew(card)) {
    return {
      text: 'নতুন কার্ড',
      badgeClass: 'bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border-sky-200/70 dark:border-sky-800/50',
      isDue: true,
      type: 'new',
    };
  }

  if (card.nextReview && card.nextReview <= now) {
    const overdueDays = Math.floor((now - card.nextReview) / (24 * 60 * 60 * 1000));
    return {
      text: overdueDays > 1 ? `রিভিউ বাকি (${overdueDays} দিন)` : 'আজকে রিভিউ বাকি',
      badgeClass: 'bg-rose-50 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 border-rose-300 dark:border-rose-800 animate-pulse font-bold',
      isDue: true,
      type: 'due',
    };
  }

  if (isCardMastered(card)) {
    return {
      text: `আয়ত্তে (${card.repetition || 0}x • ${card.easeFactor || 2.5} EF)`,
      badgeClass: 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200/70 dark:border-emerald-800/50 font-semibold',
      isDue: false,
      type: 'mastered',
    };
  }

  if (isCardLearning(card)) {
    return {
      text: `লার্নিং (${formatNextReviewBengali(card.nextReview, now)})`,
      badgeClass: 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200/70 dark:border-amber-800/50',
      isDue: false,
      type: 'learning',
    };
  }

  return {
    text: `পরবর্তী: ${formatNextReviewBengali(card.nextReview, now)}`,
    badgeClass: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700',
    isDue: false,
    type: 'review',
  };
}

export function getSrsStageLabel(card: Card): string {
  const badge = getCardSrsBadge(card);
  return badge.text;
}

