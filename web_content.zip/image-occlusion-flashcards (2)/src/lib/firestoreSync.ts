import { collection, doc, setDoc, getDocs, deleteDoc } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { get, set } from 'idb-keyval';
import { Card, Folder, SyncStatus } from '../types';

type SyncListener = (status: SyncStatus, lastSynced?: number | null) => void;

function withTimeout<T>(promise: Promise<T>, ms: number, errorMsg: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(errorMsg));
    }, ms);

    promise.then(
      res => {
        clearTimeout(timer);
        resolve(res);
      },
      err => {
        clearTimeout(timer);
        reject(err);
      }
    );
  });
}

class FirestoreSyncService {
  private syncStatus: SyncStatus = 'Saved on phone';
  private lastSyncedAt: number | null = null;
  private listeners: Set<SyncListener> = new Set();
  private isSyncing = false;
  private syncTimer: NodeJS.Timeout | null = null;
  private watchdogTimer: NodeJS.Timeout | null = null;

  constructor() {
    // Listen for online events to automatically sync when internet returns
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => {
        console.log('Internet connection restored. Triggering auto-sync...');
        this.syncNow().catch(() => {});
      });

      window.addEventListener('offline', () => {
        this.setStatus('Saved on phone');
      });

      // Load last synced timestamp from local cache
      get<number>('last_synced_timestamp')
        .then(ts => {
          if (ts) {
            this.lastSyncedAt = ts;
            this.notifyListeners();
          }
        })
        .catch(() => {});
    }
  }

  public subscribe(listener: SyncListener): () => void {
    this.listeners.add(listener);
    listener(this.syncStatus, this.lastSyncedAt);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public getStatus(): SyncStatus {
    return this.syncStatus;
  }

  public getLastSyncedAt(): number | null {
    return this.lastSyncedAt;
  }

  private notifyListeners() {
    this.listeners.forEach(fn => {
      try {
        fn(this.syncStatus, this.lastSyncedAt);
      } catch (e) {
        console.error('Error in sync listener:', e);
      }
    });
  }

  private setStatus(status: SyncStatus) {
    this.syncStatus = status;
    this.notifyListeners();
  }

  /**
   * Force stop and reset sync status to 'Saved on phone'
   */
  public forceReset() {
    if (this.syncTimer) {
      clearTimeout(this.syncTimer);
      this.syncTimer = null;
    }
    if (this.watchdogTimer) {
      clearTimeout(this.watchdogTimer);
      this.watchdogTimer = null;
    }
    this.isSyncing = false;
    this.setStatus('Saved on phone');
  }

  /**
   * Mark that local changes occurred. Sets status to 'Saved on phone'
   * and schedules an automatic sync if user is logged in and online.
   */
  public notifyLocalChange() {
    this.setStatus('Saved on phone');

    if (this.syncTimer) {
      clearTimeout(this.syncTimer);
      this.syncTimer = null;
    }

    if (auth.currentUser && typeof navigator !== 'undefined' && navigator.onLine) {
      this.syncTimer = setTimeout(() => {
        this.syncNow().catch(err => {
          console.warn('Auto-sync notice:', err?.message || err);
        });
      }, 3500); // 3.5s debounce
    }
  }

  /**
   * Record explicit user deletion of card/folder to remove from Firestore during sync.
   */
  public async trackDeletion(type: 'card' | 'folder', id: number) {
    try {
      const key = type === 'card' ? 'deleted_card_ids' : 'deleted_folder_ids';
      const current = (await get<number[]>(key)) || [];
      if (!current.includes(id)) {
        await set(key, [...current, id]);
      }
      this.notifyLocalChange();
    } catch (e) {
      console.error('Error tracking deletion:', e);
    }
  }

  /**
   * Performs full bidirectional sync between local IndexedDB and Cloud Firestore:
   * 1. Pulls remote data if local is empty (e.g. after reinstall/cache clear).
   * 2. Pushes local additions/updates to Firestore under users/{userId}.
   * 3. Executes tracked deletions in Firestore.
   * Guarantees a hard timeout so it never spins indefinitely.
   */
  public async syncNow(): Promise<{ cards: Card[]; folders: Folder[]; restoredFromCloud: boolean } | null> {
    const user = auth.currentUser;
    if (!user) {
      this.isSyncing = false;
      this.setStatus('Saved on phone');
      return null;
    }

    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      this.isSyncing = false;
      this.setStatus('Saved on phone');
      return null;
    }

    if (this.isSyncing) {
      console.log('Sync is already in progress, skipping duplicate call.');
      return null;
    }

    if (this.syncTimer) {
      clearTimeout(this.syncTimer);
      this.syncTimer = null;
    }

    this.isSyncing = true;
    this.setStatus('Syncing');

    // Watchdog timer: hard stop after 14 seconds to guarantee the UI never gets stuck
    if (this.watchdogTimer) clearTimeout(this.watchdogTimer);
    this.watchdogTimer = setTimeout(() => {
      if (this.isSyncing) {
        console.warn('Sync watchdog: Sync took longer than 14 seconds. Resetting to Saved on phone.');
        this.isSyncing = false;
        this.setStatus('Saved on phone');
      }
    }, 14000);

    try {
      const userId = user.uid;

      // 1. Read current local data
      let localCards = (await get<Card[]>('flashcards')) || [];
      let localFolders = (await get<Folder[]>('folders')) || [];
      const deletedCardIds = (await get<number[]>('deleted_card_ids')) || [];
      const deletedFolderIds = (await get<number[]>('deleted_folder_ids')) || [];

      const cardsPath = `users/${userId}/cards`;
      const foldersPath = `users/${userId}/folders`;
      const metaPath = `users/${userId}/meta`;

      // 2. Fetch remote documents from Firestore with a strict 8s timeout
      const remoteCardsSnap = await withTimeout(
        getDocs(collection(db, cardsPath)),
        8000,
        'কার্ডের তথ্য আনতে অতিরিক্ত সময় লেগেছে'
      );

      const remoteFoldersSnap = await withTimeout(
        getDocs(collection(db, foldersPath)),
        8000,
        'ফোল্ডারের তথ্য আনতে অতিরিক্ত সময় লেগেছে'
      );

      const remoteCardsMap = new Map<number, Card>();
      remoteCardsSnap.forEach(docSnap => {
        const d = docSnap.data();
        if (!d.deleted) {
          remoteCardsMap.set(Number(d.id), {
            id: Number(d.id),
            folderId: d.folderId !== null && d.folderId !== undefined ? Number(d.folderId) : undefined,
            title: d.title || 'Untitled',
            image: d.image || '',
            rectangles: d.rectangles || [],
            pins: d.pins || [],
            notes: d.notes || '',
            tags: Array.isArray(d.tags) ? d.tags : [],
            interval: d.interval,
            repetition: d.repetition,
            easeFactor: d.easeFactor,
            nextReview: d.nextReview,
            lastReviewed: d.lastReviewed,
            lapses: d.lapses,
            favorite: Boolean(d.favorite),
            createdAt: d.createdAt,
            updatedAt: d.updatedAt || d.createdAt || 0,
          });
        }
      });

      const remoteFoldersMap = new Map<number, Folder>();
      remoteFoldersSnap.forEach(docSnap => {
        const d = docSnap.data();
        if (!d.deleted) {
          remoteFoldersMap.set(Number(d.id), {
            id: Number(d.id),
            name: d.name || 'Untitled Folder',
            parentId: d.parentId !== null && d.parentId !== undefined ? Number(d.parentId) : undefined,
            createdAt: d.createdAt,
            updatedAt: d.updatedAt || d.createdAt || 0,
          });
        }
      });

      let restoredFromCloud = false;
      const prevCardsCount = localCards.length;
      const prevFoldersCount = localFolders.length;

      // 3. Storage clearance / reinstall recovery:
      // If local is empty, but cloud has items, restore them directly to local!
      if (localCards.length === 0 && localFolders.length === 0 && (remoteCardsMap.size > 0 || remoteFoldersMap.size > 0)) {
        localCards = Array.from(remoteCardsMap.values());
        localFolders = Array.from(remoteFoldersMap.values());
        await set('flashcards', localCards);
        await set('folders', localFolders);
        restoredFromCloud = true;
      } else {
        // 4. Merge: Combine local and remote. If conflict, newest updatedAt wins.
        const mergedCardsMap = new Map<number, Card>();
        for (const [id, c] of remoteCardsMap.entries()) {
          if (!deletedCardIds.includes(id)) {
            mergedCardsMap.set(id, c);
          }
        }
        for (const c of localCards) {
          if (deletedCardIds.includes(c.id)) continue;
          const remote = mergedCardsMap.get(c.id);
          if (!remote || (c.updatedAt || 0) >= (remote.updatedAt || 0)) {
            mergedCardsMap.set(c.id, c);
          }
        }

        const mergedFoldersMap = new Map<number, Folder>();
        for (const [id, f] of remoteFoldersMap.entries()) {
          if (!deletedFolderIds.includes(id)) {
            mergedFoldersMap.set(id, f);
          }
        }
        for (const f of localFolders) {
          if (deletedFolderIds.includes(f.id)) continue;
          const remote = mergedFoldersMap.get(f.id);
          if (!remote || (f.updatedAt || 0) >= (remote.updatedAt || 0)) {
            mergedFoldersMap.set(f.id, f);
          }
        }

        localCards = Array.from(mergedCardsMap.values());
        localFolders = Array.from(mergedFoldersMap.values());
        await set('flashcards', localCards);
        await set('folders', localFolders);

        if (localCards.length > prevCardsCount || localFolders.length > prevFoldersCount || remoteCardsMap.size > 0) {
          restoredFromCloud = true;
        }
      }

      // 5. Push any new or modified local items to Firestore (in parallel chunks of 3)
      const cardsToUpload = localCards.filter(card => {
        const remote = remoteCardsMap.get(card.id);
        return !remote || (card.updatedAt || 0) > (remote.updatedAt || 0);
      });

      const uploadCard = async (card: Card) => {
        try {
          let imagePayload = card.image || '';
          // Firestore document limit is 1,048,576 bytes.
          // If image is larger than 900KB, omit image on cloud to avoid Firestore document rejection
          if (imagePayload.length > 900000) {
            console.warn(`Card ${card.id} image exceeds Firestore doc limit; saving metadata.`);
            imagePayload = '';
          }

          await withTimeout(
            setDoc(doc(db, cardsPath, String(card.id)), {
              id: card.id,
              userId,
              folderId: card.folderId ?? null,
              title: card.title || 'Untitled',
              image: imagePayload,
              rectangles: card.rectangles || [],
              pins: card.pins || [],
              notes: card.notes || '',
              tags: card.tags || [],
              interval: card.interval ?? 0,
              repetition: card.repetition ?? 0,
              easeFactor: card.easeFactor ?? 2.5,
              nextReview: card.nextReview ?? 0,
              lastReviewed: card.lastReviewed ?? 0,
              lapses: card.lapses ?? 0,
              favorite: Boolean(card.favorite),
              createdAt: card.createdAt || Date.now(),
              updatedAt: card.updatedAt || Date.now(),
              deleted: false,
            }, { merge: true }),
            6000,
            `কার্ড ${card.id} আপলোড সময়সীমা অতিক্রম করেছে`
          );
        } catch (cardErr) {
          console.warn(`Non-fatal card upload skip for ${card.id}:`, cardErr);
        }
      };

      // Upload in chunks of 3
      const cardChunkSize = 3;
      for (let i = 0; i < cardsToUpload.length; i += cardChunkSize) {
        const chunk = cardsToUpload.slice(i, i + cardChunkSize);
        await Promise.all(chunk.map(c => uploadCard(c)));
      }

      // Folders to upload
      const foldersToUpload = localFolders.filter(folder => {
        const remote = remoteFoldersMap.get(folder.id);
        return !remote || (folder.updatedAt || 0) > (remote.updatedAt || 0);
      });

      const uploadFolder = async (folder: Folder) => {
        try {
          await withTimeout(
            setDoc(doc(db, foldersPath, String(folder.id)), {
              id: folder.id,
              userId,
              name: folder.name,
              parentId: folder.parentId ?? null,
              createdAt: folder.createdAt || Date.now(),
              updatedAt: folder.updatedAt || Date.now(),
              deleted: false,
            }, { merge: true }),
            5000,
            `ফোল্ডার ${folder.id} আপলোড সময়সীমা অতিক্রম করেছে`
          );
        } catch (fErr) {
          console.warn(`Non-fatal folder upload skip for ${folder.id}:`, fErr);
        }
      };

      await Promise.all(foldersToUpload.map(f => uploadFolder(f)));

      // 6. Process tracked deletions in Firestore
      if (deletedCardIds.length > 0) {
        await Promise.all(
          deletedCardIds.map(delId =>
            deleteDoc(doc(db, cardsPath, String(delId))).catch(() => {})
          )
        );
        await set('deleted_card_ids', []);
      }

      if (deletedFolderIds.length > 0) {
        await Promise.all(
          deletedFolderIds.map(delId =>
            deleteDoc(doc(db, foldersPath, String(delId))).catch(() => {})
          )
        );
        await set('deleted_folder_ids', []);
      }

      // 7. Update User Meta Timestamp
      const now = Date.now();
      this.lastSyncedAt = now;
      await set('last_synced_timestamp', now);

      setDoc(doc(db, metaPath, 'status'), {
        userId,
        lastSyncedAt: now,
        totalCards: localCards.length,
        totalFolders: localFolders.length,
      }, { merge: true }).catch(() => {});

      // Successfully synced!
      this.setStatus('Backed up');

      return {
        cards: localCards,
        folders: localFolders,
        restoredFromCloud,
      };
    } catch (err) {
      console.warn('Firestore sync interrupted:', err);
      this.setStatus('Saved on phone');
      throw err;
    } finally {
      if (this.watchdogTimer) {
        clearTimeout(this.watchdogTimer);
        this.watchdogTimer = null;
      }
      this.isSyncing = false;
      // If status is still 'Syncing' somehow, revert to 'Saved on phone'
      if (this.syncStatus === 'Syncing') {
        this.setStatus('Saved on phone');
      }
    }
  }
}

export const syncService = new FirestoreSyncService();
