import { Card } from '../types';

export const PRESET_TAGS = [
  'Biology',
  'History',
  'Hard',
  'Important',
  'Exam'
];

export const cleanTag = (tag: string): string => {
  return tag.trim().replace(/^#+/, '').trim();
};

export const getTagColorClass = (tag: string): string => {
  const normalized = cleanTag(tag).toLowerCase();
  
  if (normalized === 'biology' || normalized === 'জীববিজ্ঞান') {
    return 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800';
  }
  if (normalized === 'history' || normalized === 'ইতিহাস') {
    return 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800';
  }
  if (normalized === 'hard' || normalized === 'কঠিন' || normalized === 'difficult') {
    return 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800';
  }
  if (normalized === 'easy' || normalized === 'সহজ') {
    return 'bg-teal-100 text-teal-800 border-teal-300 dark:bg-teal-950/60 dark:text-teal-300 dark:border-teal-800';
  }
  if (normalized === 'medium' || normalized === 'মাঝারি') {
    return 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800';
  }
  if (normalized === 'important' || normalized === 'গুরুত্বপূর্ণ') {
    return 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800';
  }
  if (normalized === 'exam' || normalized === 'পরীক্ষা') {
    return 'bg-indigo-100 text-indigo-800 border-indigo-300 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800';
  }

  const palette = [
    'bg-sky-100 text-sky-800 border-sky-300 dark:bg-sky-950/60 dark:text-sky-300 dark:border-sky-800',
    'bg-violet-100 text-violet-800 border-violet-300 dark:bg-violet-950/60 dark:text-violet-300 dark:border-violet-800',
    'bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-950/60 dark:text-orange-300 dark:border-orange-800',
    'bg-lime-100 text-lime-800 border-lime-300 dark:bg-lime-950/60 dark:text-lime-300 dark:border-lime-800',
    'bg-fuchsia-100 text-fuchsia-800 border-fuchsia-300 dark:bg-fuchsia-950/60 dark:text-fuchsia-300 dark:border-fuchsia-800',
    'bg-cyan-100 text-cyan-800 border-cyan-300 dark:bg-cyan-950/60 dark:text-cyan-300 dark:border-cyan-800',
    'bg-slate-100 text-slate-800 border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700',
  ];
  let hash = 0;
  for (let i = 0; i < normalized.length; i++) {
    hash = (hash << 5) - hash + normalized.charCodeAt(i);
    hash |= 0;
  }
  const index = Math.abs(hash) % palette.length;
  return palette[index];
};

export interface TagCount {
  name: string;
  count: number;
}

/**
 * Returns all unique tags found across cards with counts, ordered by frequency
 */
export const getAllTags = (cards: Card[]): TagCount[] => {
  const map = new Map<string, { display: string; count: number }>();

  for (const card of cards) {
    if (Array.isArray(card.tags)) {
      for (const t of card.tags) {
        const cleaned = cleanTag(t);
        if (!cleaned) continue;
        const key = cleaned.toLowerCase();
        const existing = map.get(key);
        if (existing) {
          existing.count++;
        } else {
          map.set(key, { display: cleaned, count: 1 });
        }
      }
    }
  }

  return Array.from(map.values())
    .map(item => ({ name: item.display, count: item.count }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
};

export const filterCardsByTag = (cards: Card[], targetTag: string): Card[] => {
  const norm = cleanTag(targetTag).toLowerCase();
  if (!norm) return cards;
  return cards.filter(c => 
    Array.isArray(c.tags) && 
    c.tags.some(t => cleanTag(t).toLowerCase() === norm)
  );
};
