import { Rectangle } from '../types';

export interface ComputedSideBadge {
  id: number;
  idx: number;
  rect: Rectangle;
  isLeft: boolean;
  targetX: number;     // % X on the mask
  targetY: number;     // % Y on the mask
  displayX: number;    // % X for badge box
  displayY: number;    // % Y for badge box (center)
  anchorX: number;     // % X where leader line connects to badge
  anchorY: number;     // % Y where leader line connects to badge
  label?: string;
  isTargetInHideOne?: boolean;
  isTargetInTypeMode?: boolean;
  isRevealed?: boolean;
}

interface MaskBox {
  id: number;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

// Approximate size of a side number badge in percentage of canvas
const BADGE_WIDTH = 7.2;   // ~32-38px across typical diagram width
const BADGE_HEIGHT = 4.2;  // ~22-26px vertical height
const SAFETY_PAD = 1.0;    // Clearance padding to guarantee no touch with masks

/**
 * Checks if a candidate badge box collides with ANY mask rectangle
 */
function collidesWithAnyMask(
  bx1: number,
  by1: number,
  bx2: number,
  by2: number,
  masks: MaskBox[]
): boolean {
  for (const m of masks) {
    const overlapX = Math.max(0, Math.min(bx2, m.x2 + SAFETY_PAD) - Math.max(bx1, m.x1 - SAFETY_PAD));
    const overlapY = Math.max(0, Math.min(by2, m.y2 + SAFETY_PAD) - Math.max(by1, m.y1 - SAFETY_PAD));
    if (overlapX > 0 && overlapY > 0) {
      return true;
    }
  }
  return false;
}

/**
 * Checks if a candidate badge position collides with already placed badges
 */
function collidesWithPlacedBadges(
  bx1: number,
  by1: number,
  bx2: number,
  by2: number,
  placed: Array<{ bx1: number; by1: number; bx2: number; by2: number }>
): boolean {
  for (const p of placed) {
    const overlapX = Math.max(0, Math.min(bx2, p.bx2 + 0.8) - Math.max(bx1, p.bx1 - 0.8));
    const overlapY = Math.max(0, Math.min(by2, p.by2 + 0.8) - Math.max(by1, p.by1 - 0.8));
    if (overlapX > 0 && overlapY > 0) {
      return true;
    }
  }
  return false;
}

/**
 * Computes side badges placed exclusively in empty space (outside all masks)
 * with leader lines connecting to the target masks (Netter Atlas Style).
 */
export function computeCollisionFreeSideBadges(
  rectangles: Rectangle[],
  badgePositionSetting: 'auto' | 'left' | 'right' | 'inside' | 'hidden' = 'auto',
  contextState?: {
    activeRectId?: number | null;
    occlusionMode?: string;
    studyMode?: string;
    revealedIds?: Set<number>;
  }
): ComputedSideBadge[] {
  if (badgePositionSetting === 'hidden' || badgePositionSetting === 'inside' || !rectangles || rectangles.length === 0) {
    return [];
  }

  // 1. Normalized bounding boxes of all masks
  const allMasks: MaskBox[] = rectangles.map(r => {
    const x = r.xPercent !== undefined ? r.xPercent : (r.x / 1000) * 100;
    const y = r.yPercent !== undefined ? r.yPercent : (r.y / 1000) * 100;
    const w = r.widthPercent !== undefined ? r.widthPercent : (r.width / 1000) * 100;
    const h = r.heightPercent !== undefined ? r.heightPercent : (r.height / 1000) * 100;
    return {
      id: r.id,
      x1: x,
      y1: y,
      x2: x + w,
      y2: y + h
    };
  });

  // Track placed badge footprints to prevent badges from overlapping each other
  const placedFootprints: Array<{ bx1: number; by1: number; bx2: number; by2: number }> = [];
  const result: ComputedSideBadge[] = [];

  // Search vertical offset sequence: radiates outward from targetY to find the nearest free space
  const searchOffsets = [
    0,
    1.6, -1.6,
    3.2, -3.2,
    4.8, -4.8,
    6.5, -6.5,
    8.5, -8.5,
    11.0, -11.0,
    14.0, -14.0,
    17.5, -17.5,
    21.5, -21.5,
    26.0, -26.0,
    31.0, -31.0,
    36.5, -36.5,
    42.5, -42.5,
    49.0, -49.0,
    56.0, -56.0,
    63.0, -63.0
  ];

  // Process each rectangle
  rectangles.forEach((rect, idx) => {
    const mask = allMasks[idx];
    const maskMidX = (mask.x1 + mask.x2) / 2;
    const targetY = (mask.y1 + mask.y2) / 2;

    // Determine preferred side based on mask placement and explicit user setting
    const rectSetting = rect.badgePosition || badgePositionSetting;
    if (rectSetting === 'hidden') return;
    let preferredIsLeft = maskMidX < 50;
    if (rectSetting === 'left') preferredIsLeft = true;
    else if (rectSetting === 'right') preferredIsLeft = false;

    // Calculate natural target point on mask edge
    const getTargetX = (isLeft: boolean) => isLeft ? mask.x1 : mask.x2;

    // Candidate evaluation: tests candidate side and offset
    const tryFindEmptySpot = (isLeft: boolean) => {
      // Default edge X position:
      // Left side: 0.8% from edge
      // Right side: 100 - BADGE_WIDTH - 0.8% = 92%
      const baseBx = isLeft ? 0.8 : (100 - BADGE_WIDTH - 0.8);

      // 1. Try along the outer margin with vertical offsets
      for (const dy of searchOffsets) {
        const testY = Math.max(3.2, Math.min(96.8, targetY + dy));
        const by1 = testY - BADGE_HEIGHT / 2;
        const by2 = testY + BADGE_HEIGHT / 2;
        const bx1 = baseBx;
        const bx2 = baseBx + BADGE_WIDTH;

        if (
          !collidesWithAnyMask(bx1, by1, bx2, by2, allMasks) &&
          !collidesWithPlacedBadges(bx1, by1, bx2, by2, placedFootprints)
        ) {
          return {
            isLeft,
            displayX: bx1,
            displayY: testY,
            bx1,
            by1,
            bx2,
            by2,
            offsetDist: Math.abs(dy)
          };
        }
      }

      // 2. If outer edge is completely blocked by edge masks, check slightly shifted inward
      // (e.g. into the white space between diagram and edge mask)
      const inwardXOffsets = isLeft ? [9.0, 15.0] : [100 - BADGE_WIDTH - 9.0, 100 - BADGE_WIDTH - 15.0];
      for (const inX of inwardXOffsets) {
        for (const dy of searchOffsets) {
          const testY = Math.max(3.2, Math.min(96.8, targetY + dy));
          const by1 = testY - BADGE_HEIGHT / 2;
          const by2 = testY + BADGE_HEIGHT / 2;
          const bx1 = inX;
          const bx2 = inX + BADGE_WIDTH;

          if (
            !collidesWithAnyMask(bx1, by1, bx2, by2, allMasks) &&
            !collidesWithPlacedBadges(bx1, by1, bx2, by2, placedFootprints)
          ) {
            return {
              isLeft,
              displayX: bx1,
              displayY: testY,
              bx1,
              by1,
              bx2,
              by2,
              offsetDist: Math.abs(dy) + 20 // penalty for shifting inward
            };
          }
        }
      }

      return null;
    };

    // First search on preferred side
    let bestSpot = tryFindEmptySpot(preferredIsLeft);

    // If preferred side has no free space, or required drifting far away (> 24% vertical distance),
    // and user didn't explicitly lock the side to 'left' or 'right':
    const isLockedSide = rect.badgePosition === 'left' || rect.badgePosition === 'right';
    if (!isLockedSide && (!bestSpot || bestSpot.offsetDist > 24)) {
      const oppositeSpot = tryFindEmptySpot(!preferredIsLeft);
      if (oppositeSpot) {
        if (!bestSpot || oppositeSpot.offsetDist + 6 < bestSpot.offsetDist) {
          bestSpot = oppositeSpot;
        }
      }
    }

    // Fallback if everything is congested: clamp to margin with stagger
    const chosenIsLeft = bestSpot ? bestSpot.isLeft : preferredIsLeft;
    const finalDisplayX = bestSpot ? bestSpot.displayX : (chosenIsLeft ? 0.8 : (100 - BADGE_WIDTH - 0.8));
    const finalDisplayY = bestSpot ? bestSpot.displayY : Math.max(3.5, Math.min(96.5, targetY));

    // Register footprint
    const finalBx1 = finalDisplayX;
    const finalBx2 = finalDisplayX + BADGE_WIDTH;
    const finalBy1 = finalDisplayY - BADGE_HEIGHT / 2;
    const finalBy2 = finalDisplayY + BADGE_HEIGHT / 2;
    placedFootprints.push({ bx1: finalBx1, by1: finalBy1, bx2: finalBx2, by2: finalBy2 });

    // Anchor point for leader line: connects to the side of the badge facing the diagram
    const anchorX = chosenIsLeft ? finalBx2 : finalBx1;
    const anchorY = finalDisplayY;
    const targetX = getTargetX(chosenIsLeft);

    // Context flags for study mode
    const isTargetInHideOne = contextState?.occlusionMode === 'hide-one' && contextState.activeRectId === rect.id;
    const isTargetInTypeMode = contextState?.studyMode === 'type' && contextState.activeRectId === rect.id;
    const isRevealed = contextState?.revealedIds ? contextState.revealedIds.has(rect.id) : false;

    result.push({
      id: rect.id,
      idx,
      rect,
      isLeft: chosenIsLeft,
      targetX,
      targetY,
      displayX: finalDisplayX,
      displayY: finalDisplayY,
      anchorX,
      anchorY,
      label: rect.label,
      isTargetInHideOne,
      isTargetInTypeMode,
      isRevealed
    });
  });

  return result;
}
