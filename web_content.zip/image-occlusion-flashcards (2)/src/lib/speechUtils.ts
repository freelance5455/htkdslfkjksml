/**
 * Premium Web Speech Synthesis, Speech Repetition & Audio FX utility
 * Supports Bengali (বাংলা) & English pronunciation, configurable repetition counts (1x, 2x, 3x),
 * natural pause intervals, auto-pronounce on mask reveal, and native haptic feedback.
 */

export interface SpeechSettings {
  repeatCount: number; // 1, 2, 3, 5 (times to repeat speech)
  repeatIntervalMs: number; // pause between repetitions in ms
  rate: number; // speech rate (0.75 - 1.25)
  pitch: number; // speech pitch (0.9 - 1.1)
  autoPronounceOnReveal: boolean; // automatically speak when a mask is revealed
  hapticFeedback: boolean; // vibrate device on actions (for native APK feel)
  voiceMode: 'auto' | 'bengali' | 'english';
}

const DEFAULT_SETTINGS: SpeechSettings = {
  repeatCount: 2,
  repeatIntervalMs: 850,
  rate: 0.95,
  pitch: 1.0,
  autoPronounceOnReveal: false,
  hapticFeedback: true,
  voiceMode: 'auto',
};

let currentSettings: SpeechSettings = { ...DEFAULT_SETTINGS };

// Load settings from localStorage
try {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('medflash_speech_settings');
    if (saved) {
      currentSettings = { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    }
  }
} catch (e) {
  // Ignore storage errors
}

export const getSpeechSettings = (): SpeechSettings => ({ ...currentSettings });

export const updateSpeechSettings = (updates: Partial<SpeechSettings>): SpeechSettings => {
  currentSettings = { ...currentSettings, ...updates };
  try {
    if (typeof window !== 'undefined') {
      localStorage.setItem('medflash_speech_settings', JSON.stringify(currentSettings));
    }
  } catch (_) {}
  notifySettingsChanged();
  return { ...currentSettings };
};

const settingsListeners = new Set<(settings: SpeechSettings) => void>();
export const subscribeSpeechSettings = (cb: (settings: SpeechSettings) => void): (() => void) => {
  settingsListeners.add(cb);
  cb(currentSettings);
  return () => { settingsListeners.delete(cb); };
};

const notifySettingsChanged = () => {
  settingsListeners.forEach(cb => {
    try { cb(currentSettings); } catch (_) {}
  });
};

/**
 * Device Haptic Vibration feedback for native APK tactile feel
 */
export const triggerHaptic = (type: 'light' | 'medium' | 'success' | 'warning' = 'light'): void => {
  if (!currentSettings.hapticFeedback) return;
  if (typeof window === 'undefined' || !('navigator' in window) || !('vibrate' in navigator)) return;
  
  try {
    switch (type) {
      case 'light':
        navigator.vibrate(10);
        break;
      case 'medium':
        navigator.vibrate([18, 10, 18]);
        break;
      case 'success':
        navigator.vibrate([15, 30, 25]);
        break;
      case 'warning':
        navigator.vibrate([40, 20, 40]);
        break;
    }
  } catch (_) {}
};

let activeUtterance: SpeechSynthesisUtterance | null = null;
let currentSpeakingState = false;
let isGloballyMuted = false;
let currentRepetitionSessionId = 0;
let repetitionProgress: { current: number; total: number; text: string } | null = null;

const speechListeners = new Set<(isSpeaking: boolean, progress?: { current: number; total: number; text: string } | null) => void>();
const muteListeners = new Set<(isMuted: boolean) => void>();

// Load mute preference from localStorage
try {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('medflash_sound_muted');
    if (saved !== null) {
      isGloballyMuted = saved === 'true';
    }
  }
} catch (e) {
  // Ignore storage errors
}

const notifySpeechState = (isSpeaking: boolean, progress: { current: number; total: number; text: string } | null = null) => {
  currentSpeakingState = isSpeaking;
  repetitionProgress = progress;
  speechListeners.forEach(cb => {
    try { cb(isSpeaking, progress); } catch (_) {}
  });
};

const notifyMuteState = (muted: boolean) => {
  isGloballyMuted = muted;
  try {
    localStorage.setItem('medflash_sound_muted', muted ? 'true' : 'false');
  } catch (_) {}
  muteListeners.forEach(cb => {
    try { cb(muted); } catch (_) {}
  });
};

/**
 * Check if sound is muted globally
 */
export const isMuted = (): boolean => isGloballyMuted;

/**
 * Toggle sound mute globally
 */
export const toggleMute = (): boolean => {
  const next = !isGloballyMuted;
  if (next) {
    stopSpeech();
  }
  notifyMuteState(next);
  return next;
};

/**
 * Set sound mute state
 */
export const setMuted = (muted: boolean): void => {
  if (muted) {
    stopSpeech();
  }
  notifyMuteState(muted);
};

/**
 * Subscribe to speech playing changes and repetition progress
 */
export const subscribeSpeechState = (
  callback: (isSpeaking: boolean, progress?: { current: number; total: number; text: string } | null) => void
): (() => void) => {
  speechListeners.add(callback);
  callback(currentSpeakingState, repetitionProgress);
  return () => {
    speechListeners.delete(callback);
  };
};

/**
 * Subscribe to mute state changes
 */
export const subscribeMuteState = (callback: (isMuted: boolean) => void): (() => void) => {
  muteListeners.add(callback);
  callback(isGloballyMuted);
  return () => {
    muteListeners.delete(callback);
  };
};

/**
 * Immediately stop any currently playing speech and cancel any ongoing repetition loop
 */
export const stopSpeech = (): void => {
  currentRepetitionSessionId++;
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch (_) {}
  }
  activeUtterance = null;
  notifySpeechState(false, null);
};

/**
 * Check if speech is currently active
 */
export const isSpeakingNow = (): boolean => {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return false;
  return currentSpeakingState || window.speechSynthesis.speaking;
};

export const getRepetitionProgress = () => repetitionProgress;

/**
 * Internal single utterance speak promise
 */
const playSingleUtterance = (text: string, rate: number, pitch: number, sessionId: number): Promise<boolean> => {
  return new Promise((resolve) => {
    if (sessionId !== currentRepetitionSessionId) return resolve(false);
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return resolve(false);
    if (isGloballyMuted) return resolve(false);

    try {
      const clean = text.trim();
      if (!clean) return resolve(false);

      const safeText = clean.length > 500 ? clean.substring(0, 500) + '...' : clean;
      const utterance = new SpeechSynthesisUtterance(safeText);
      activeUtterance = utterance;

      const hasBengali = /[\u0980-\u09FF]/.test(safeText);
      const voices = window.speechSynthesis.getVoices();

      const prefMode = currentSettings.voiceMode || 'auto';
      const useBengali = prefMode === 'bengali' ? true : (prefMode === 'english' ? false : hasBengali);

      if (useBengali) {
        utterance.lang = 'bn-BD';
        const bnVoice = voices.find(v => v.lang.toLowerCase().includes('bn') || v.name.toLowerCase().includes('bangla') || v.name.toLowerCase().includes('bengali'));
        if (bnVoice) utterance.voice = bnVoice;
      } else {
        utterance.lang = 'en-US';
        const enVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('Google') || v.name.includes('Natural') || v.name.includes('Samantha') || v.name.includes('US')));
        if (enVoice) {
          utterance.voice = enVoice;
        } else {
          const anyEn = voices.find(v => v.lang.startsWith('en'));
          if (anyEn) utterance.voice = anyEn;
        }
      }

      utterance.rate = rate;
      utterance.pitch = pitch;

      let settled = false;
      const finish = (ok: boolean) => {
        if (settled) return;
        settled = true;
        activeUtterance = null;
        resolve(ok && sessionId === currentRepetitionSessionId);
      };

      utterance.onend = () => finish(true);
      utterance.onerror = () => finish(false);

      if (window.speechSynthesis.paused) {
        try { window.speechSynthesis.resume(); } catch (_) {}
      }

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      resolve(false);
    }
  });
};

/**
 * Speak with intelligent repetition (Speech Repetition Feature)
 * Plays the pronunciation, pauses for cognitive digestion, and repeats up to `count` times.
 */
export const speakWithRepetition = async (
  text: string,
  options?: {
    count?: number;
    intervalMs?: number;
    rate?: number;
    pitch?: number;
    onProgress?: (current: number, total: number) => void;
    onEnd?: () => void;
  }
): Promise<boolean> => {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    options?.onEnd?.();
    return false;
  }

  if (isGloballyMuted) {
    options?.onEnd?.();
    return false;
  }

  const clean = text.trim();
  if (!clean) {
    options?.onEnd?.();
    return false;
  }

  // Cancel prior session
  stopSpeech();

  const sessionId = ++currentRepetitionSessionId;
  const totalReps = options?.count ?? currentSettings.repeatCount ?? 2;
  const intervalMs = options?.intervalMs ?? currentSettings.repeatIntervalMs ?? 850;
  const rate = options?.rate ?? currentSettings.rate ?? 0.95;
  const pitch = options?.pitch ?? currentSettings.pitch ?? 1.0;

  try {
    for (let rep = 1; rep <= totalReps; rep++) {
      if (sessionId !== currentRepetitionSessionId) break;

      triggerHaptic('light');
      notifySpeechState(true, { current: rep, total: totalReps, text: clean });
      options?.onProgress?.(rep, totalReps);

      const ok = await playSingleUtterance(clean, rate, pitch, sessionId);
      if (!ok || sessionId !== currentRepetitionSessionId) break;

      // Pause between repetitions
      if (rep < totalReps) {
        await new Promise(r => setTimeout(r, intervalMs));
      }
    }
  } catch (err) {
    console.error('Speech repetition error:', err);
  } finally {
    if (sessionId === currentRepetitionSessionId) {
      notifySpeechState(false, null);
      options?.onEnd?.();
    }
  }

  return true;
};

/**
 * Standard speak function (defaults to repetition settings if enabled)
 */
export const speakText = (text: string, onEnd?: () => void): boolean => {
  speakWithRepetition(text, { count: currentSettings.repeatCount, onEnd });
  return true;
};

/**
 * Speak once only (1x pronunciation)
 */
export const speakOnce = (text: string, onEnd?: () => void): boolean => {
  speakWithRepetition(text, { count: 1, onEnd });
  return true;
};

/**
 * Toggle speech: If currently speaking, stop it immediately. If stopped, start speaking.
 */
export const toggleSpeech = (text: string, onEnd?: () => void): boolean => {
  if (isSpeakingNow()) {
    stopSpeech();
    if (onEnd) onEnd();
    return false;
  } else {
    return speakText(text, onEnd);
  }
};

/**
 * Subtle, pleasant sound effects using Web Audio API
 * Short durations (80-250ms) so they NEVER hang or loop endlessly
 */
export const playSoundEffect = (type: 'correct' | 'incorrect' | 'flip' | 'click' | 'complete'): void => {
  if (isGloballyMuted) return;
  if (typeof window === 'undefined') return;

  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;

    if (type === 'correct') {
      // Pleasant two-tone chime (high notes)
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.setValueAtTime(880, now + 0.08); // A5
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (type === 'incorrect') {
      // Soft low bump
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(260, now);
      osc.frequency.setValueAtTime(200, now + 0.08);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.22);
    } else if (type === 'flip') {
      // Light paper flip / swoosh
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, now);
      osc.frequency.exponentialRampToValueAtTime(600, now + 0.07);
      gain.gain.setValueAtTime(0.04, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
      osc.start(now);
      osc.stop(now + 0.11);
    } else if (type === 'complete') {
      // Triumph arpeggio
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.setValueAtTime(659.25, now + 0.08); // E5
      osc.frequency.setValueAtTime(783.99, now + 0.16); // G5
      osc.frequency.setValueAtTime(1046.50, now + 0.24); // C6
      gain.gain.setValueAtTime(0.09, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
      osc.start(now);
      osc.stop(now + 0.52);
    } else {
      // Subtle click
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      gain.gain.setValueAtTime(0.03, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
      osc.start(now);
      osc.stop(now + 0.06);
    }

    setTimeout(() => {
      try { ctx.close(); } catch (_) {}
    }, 800);
  } catch (e) {
    // Audio context not allowed or failed silently
  }
};
