// Service Worker and AppsGeyser / Web automatic update manager
type UpdateListener = (hasUpdate: boolean) => void;

class AppUpdateService {
  private hasUpdate = false;
  private listeners: Set<UpdateListener> = new Set();
  private registration: ServiceWorkerRegistration | null = null;
  private swUpdateHandler: (() => void) | null = null;
  private lastCheckTime = 0;

  constructor() {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.ready
        .then(reg => {
          this.registration = reg;
          if (reg.waiting) {
            this.setHasUpdate(true);
          }
          reg.addEventListener('updatefound', () => {
            const newWorker = reg.installing;
            if (newWorker) {
              newWorker.addEventListener('statechange', () => {
                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                  this.setHasUpdate(true);
                }
              });
            }
          });
        })
        .catch(err => {
          console.warn('Service worker ready check warning:', err);
        });

      // Conservative background check: at most once every 30 minutes, never during active typing
      setInterval(() => {
        const now = Date.now();
        if (now - this.lastCheckTime > 30 * 60 * 1000) {
          this.checkForUpdate(false).catch(() => {});
        }
      }, 15 * 60 * 1000);
    }
  }

  public registerSWUpdateHandler(fn: () => void) {
    this.swUpdateHandler = fn;
  }

  public subscribe(listener: UpdateListener): () => void {
    this.listeners.add(listener);
    listener(this.hasUpdate);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public setHasUpdate(value: boolean) {
    this.hasUpdate = value;
    this.listeners.forEach(fn => {
      try {
        fn(this.hasUpdate);
      } catch (e) {
        console.warn('Update listener error:', e);
      }
    });
  }

  public getHasUpdate(): boolean {
    return this.hasUpdate;
  }

  public async checkForUpdate(force = true): Promise<boolean> {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
      return false;
    }
    const now = Date.now();
    if (!force && now - this.lastCheckTime < 10 * 60 * 1000) {
      return this.hasUpdate;
    }
    this.lastCheckTime = now;
    try {
      if (this.registration) {
        await this.registration.update();
        if (this.registration.waiting) {
          this.setHasUpdate(true);
          return true;
        }
      } else {
        const regs = await navigator.serviceWorker.getRegistrations();
        for (const reg of regs) {
          await reg.update();
          if (reg.waiting) {
            this.setHasUpdate(true);
            return true;
          }
        }
      }
    } catch (e) {
      console.warn('Update check notice:', e);
    }
    return false;
  }

  public async applyUpdateAndReload(): Promise<void> {
    try {
      if (this.swUpdateHandler) {
        this.swUpdateHandler();
        return;
      }
      if ('caches' in window) {
        const cacheKeys = await caches.keys();
        await Promise.all(cacheKeys.map(k => caches.delete(k)));
      }
      if ('serviceWorker' in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        for (const reg of regs) {
          if (reg.waiting) {
            reg.waiting.postMessage({ type: 'SKIP_WAITING' });
          }
          await reg.update();
        }
      }
    } catch (e) {
      console.warn('Error clearing caches for update:', e);
    }
    window.location.reload();
  }
}

export const appUpdateService = new AppUpdateService();
