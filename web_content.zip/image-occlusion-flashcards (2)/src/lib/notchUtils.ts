/**
 * Utilities to handle Android Status Bar, Notch, and Safe Area Insets for APK / PWA
 */

export type NotchSetting = 'auto' | 'standard' | 'tall' | 'compact' | 'none';
export type BottomNavSetting = 'auto' | 'standard' | 'tall' | 'extra' | 'compact' | 'none';

const STORAGE_KEY = 'io_notch_setting';
const BOTTOM_NAV_KEY = 'io_bottom_nav_setting';

export function isAppEnvironment(): boolean {
  if (typeof window === 'undefined') return false;

  const isStandalone =
    window.matchMedia('(display-mode: standalone)').matches ||
    window.matchMedia('(display-mode: fullscreen)').matches ||
    window.matchMedia('(display-mode: minimal-ui)').matches ||
    (window.navigator as unknown as { standalone?: boolean }).standalone === true ||
    document.referrer.includes('android-app://');

  const isWebView =
    /wv|Android.*Version\/[0-9\.]+|com\.wFlashcard/i.test(navigator.userAgent) ||
    (window as unknown as { Android?: unknown }).Android !== undefined;

  const isAndroidMobile =
    /Android/i.test(navigator.userAgent) &&
    (window.innerWidth <= 768 || navigator.maxTouchPoints > 0);

  return isStandalone || isWebView || isAndroidMobile;
}

export function getNotchSetting(): NotchSetting {
  if (typeof localStorage === 'undefined') return 'auto';
  const saved = localStorage.getItem(STORAGE_KEY) as NotchSetting | null;
  if (saved && ['auto', 'standard', 'tall', 'compact', 'none'].includes(saved)) {
    return saved;
  }
  return 'auto';
}

export function applyNotchSetting(setting?: NotchSetting): void {
  if (typeof document === 'undefined') return;

  const activeSetting = setting || getNotchSetting();
  const root = document.documentElement;

  // Clear previous classes
  root.classList.remove(
    'is-apk-mode',
    'notch-gap-compact',
    'notch-gap-standard',
    'notch-gap-tall',
    'notch-gap-none'
  );

  if (activeSetting === 'standard') {
    root.classList.add('notch-gap-standard');
  } else if (activeSetting === 'tall') {
    root.classList.add('notch-gap-tall');
  } else if (activeSetting === 'compact') {
    root.classList.add('notch-gap-compact');
  } else if (activeSetting === 'none') {
    root.classList.add('notch-gap-none');
  } else {
    // 'auto'
    if (isAppEnvironment()) {
      root.classList.add('is-apk-mode');
    }
  }
}

export function setNotchSetting(setting: NotchSetting): void {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, setting);
  }
  applyNotchSetting(setting);
}

export function getBottomNavSetting(): BottomNavSetting {
  if (typeof localStorage === 'undefined') return 'auto';
  const saved = localStorage.getItem(BOTTOM_NAV_KEY) as BottomNavSetting | null;
  if (saved && ['auto', 'standard', 'tall', 'extra', 'compact', 'none'].includes(saved)) {
    return saved;
  }
  return 'auto';
}

export function applyBottomNavSetting(setting?: BottomNavSetting): void {
  if (typeof document === 'undefined') return;

  const activeSetting = setting || getBottomNavSetting();
  const root = document.documentElement;

  // Clear previous bottom nav classes
  root.classList.remove(
    'bottom-nav-compact',
    'bottom-nav-standard',
    'bottom-nav-tall',
    'bottom-nav-extra',
    'bottom-nav-none'
  );

  if (activeSetting === 'standard') {
    root.classList.add('bottom-nav-standard');
  } else if (activeSetting === 'tall') {
    root.classList.add('bottom-nav-tall');
  } else if (activeSetting === 'extra') {
    root.classList.add('bottom-nav-extra');
  } else if (activeSetting === 'compact') {
    root.classList.add('bottom-nav-compact');
  } else if (activeSetting === 'none') {
    root.classList.add('bottom-nav-none');
  }
}

export function setBottomNavSetting(setting: BottomNavSetting): void {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(BOTTOM_NAV_KEY, setting);
  }
  applyBottomNavSetting(setting);
}

export function initSystemSafeAreaSettings(): void {
  applyNotchSetting();
  applyBottomNavSetting();
}
