/**
 * Image Enhancement Utilities
 * Solves the problem of dark/murky book scans and black transparent backgrounds
 * by automatically boosting brightness & contrast and ensuring clean white backgrounds.
 */

export interface EnhanceOptions {
  /** Brightness adjustment from -100 to 100 (default: 15 for auto-enhance) */
  brightness?: number;
  /** Contrast adjustment from -100 to 100 (default: 25 for auto-enhance) */
  contrast?: number;
  /** Whether to invert colors (e.g. for dark-mode e-reader screenshots) */
  invert?: boolean;
  /** Whether to automatically stretch tonal levels (histogram normalization) */
  autoLevels?: boolean;
  /** Target max dimension (width or height) */
  maxWidth?: number;
}

export interface ImageToneStats {
  isDarkInverted: boolean;
  avgBrightness: number;
  minLuma: number;
  maxLuma: number;
}

/**
 * Load an image safely from DataURL or URL
 */
export const loadImage = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (e) => reject(new Error('Failed to load image: ' + e));
    img.src = src;
  });
};

/**
 * Analyze image tone to detect if it's a dark/night-mode screenshot (e.g. Moon+ Reader night theme)
 */
export const analyzeImageTone = (img: HTMLImageElement): ImageToneStats => {
  const canvas = document.createElement('canvas');
  const sampleWidth = Math.min(200, img.naturalWidth || img.width);
  const sampleHeight = Math.min(200, img.naturalHeight || img.height);
  canvas.width = sampleWidth;
  canvas.height = sampleHeight;
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    return { isDarkInverted: false, avgBrightness: 128, minLuma: 0, maxLuma: 255 };
  }

  // Pure white base to prevent transparent black pixels
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, sampleWidth, sampleHeight);
  ctx.drawImage(img, 0, 0, sampleWidth, sampleHeight);

  const imgData = ctx.getImageData(0, 0, sampleWidth, sampleHeight);
  const data = imgData.data;
  let totalLuma = 0;
  let minLuma = 255;
  let maxLuma = 0;
  const pixelCount = data.length / 4;

  for (let i = 0; i < data.length; i += 4) {
    // Standard perceptual luminance formula
    const luma = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    totalLuma += luma;
    if (luma < minLuma) minLuma = luma;
    if (luma > maxLuma) maxLuma = luma;
  }

  const avgBrightness = totalLuma / pixelCount;
  // If average brightness is very low (< 75), the document background is dark/night mode
  const isDarkInverted = avgBrightness < 75;

  return { isDarkInverted, avgBrightness, minLuma, maxLuma };
};

/**
 * Enhance brightness and contrast of an image data URL
 * Guarantees white background, prevents black transparency bug, and sharpens text/diagrams.
 */
export const enhanceImage = async (
  imageSource: string | HTMLImageElement,
  options: EnhanceOptions = {}
): Promise<string> => {
  const {
    brightness = 15,
    contrast = 25,
    invert = false,
    autoLevels = true,
    maxWidth = 2048,
  } = options;

  const img = typeof imageSource === 'string' ? await loadImage(imageSource) : imageSource;

  let width = img.naturalWidth || img.width || 800;
  let height = img.naturalHeight || img.height || 600;

  if (maxWidth && (width > maxWidth || height > maxWidth)) {
    if (width > height) {
      height = Math.round((height * maxWidth) / width);
      width = maxWidth;
    } else {
      width = Math.round((width * maxWidth) / height);
      height = maxWidth;
    }
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');

  if (!ctx) {
    return typeof imageSource === 'string' ? imageSource : img.src;
  }

  // 1. Fill canvas with pure white background!
  // This is vital: JPEG conversion turns transparent pixels into black if not filled with white first.
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, height);

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, width, height);

  // 2. Read pixel data for histogram normalization and contrast/brightness boost
  const imgData = ctx.getImageData(0, 0, width, height);
  const data = imgData.data;
  const totalPixels = width * height;

  // Auto-levels calculation: find 1st and 99th percentiles
  let minClip = 0;
  let maxClip = 255;

  if (autoLevels) {
    const histogram = new Uint32Array(256);
    for (let i = 0; i < data.length; i += 4) {
      const luma = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
      histogram[luma]++;
    }

    const lowThreshold = totalPixels * 0.015; // 1.5% shadow clip
    const highThreshold = totalPixels * 0.985; // 98.5% highlight clip

    let accum = 0;
    for (let i = 0; i < 256; i++) {
      accum += histogram[i];
      if (accum >= lowThreshold && minClip === 0) {
        minClip = i;
      }
      if (accum >= highThreshold) {
        maxClip = i;
        break;
      }
    }

    // Safety guard to avoid over-stretching already extreme images
    if (maxClip - minClip < 40) {
      minClip = 0;
      maxClip = 255;
    }
  }

  // Contrast factor calculation
  // factor = (259 * (contrast + 255)) / (255 * (259 - contrast))
  const c = Math.max(-100, Math.min(100, contrast));
  const contrastFactor = (259 * (c + 255)) / (255 * (259 - c));
  const b = Math.max(-100, Math.min(100, brightness)) * 2.55;

  const range = Math.max(1, maxClip - minClip);

  for (let i = 0; i < data.length; i += 4) {
    let r = data[i];
    let g = data[i + 1];
    let bVal = data[i + 2];

    // Optional inversion (e.g. night mode reader screenshot)
    if (invert) {
      r = 255 - r;
      g = 255 - g;
      bVal = 255 - bVal;
    }

    // Auto-levels dynamic range stretch
    if (autoLevels) {
      r = Math.min(255, Math.max(0, ((r - minClip) / range) * 255));
      g = Math.min(255, Math.max(0, ((g - minClip) / range) * 255));
      bVal = Math.min(255, Math.max(0, ((bVal - minClip) / range) * 255));
    }

    // Apply Contrast
    r = contrastFactor * (r - 128) + 128;
    g = contrastFactor * (g - 128) + 128;
    bVal = contrastFactor * (bVal - 128) + 128;

    // Apply Brightness
    r += b;
    g += b;
    bVal += b;

    // Paper whitening curve: if near-white (e.g. gray scanner background > 220), push to clean white
    if (r > 220 && g > 220 && bVal > 220) {
      const whiteBoost = Math.min(255, (r + g + bVal) / 3 * 1.06);
      r = Math.max(r, whiteBoost);
      g = Math.max(g, whiteBoost);
      bVal = Math.max(bVal, whiteBoost);
    }

    data[i] = Math.min(255, Math.max(0, r));
    data[i + 1] = Math.min(255, Math.max(0, g));
    data[i + 2] = Math.min(255, Math.max(0, bVal));
    data[i + 3] = 255; // Ensure completely opaque
  }

  ctx.putImageData(imgData, 0, 0);
  return canvas.toDataURL('image/jpeg', 0.92);
};

/**
 * Standard auto-enhancement for uploaded images/scans:
 * Whitens background, enhances contrast so covered text/lines are sharp & clear.
 */
export const autoEnhanceUploadedImage = async (dataUrl: string): Promise<{ enhanced: string; wasInverted: boolean }> => {
  const img = await loadImage(dataUrl);
  const tone = analyzeImageTone(img);

  // If the document is dark mode (Moon+ reader night mode), invert it to clean white page
  const invert = tone.isDarkInverted;

  const enhanced = await enhanceImage(img, {
    brightness: invert ? 20 : 18,
    contrast: invert ? 30 : 26,
    invert: invert,
    autoLevels: true,
  });

  return { enhanced, wasInverted: invert };
};
