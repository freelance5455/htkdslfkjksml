import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
  signOut
} from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Connection test as required by skill guidelines
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline, running in offline mode.');
    }
  }
}
testConnection();

const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/drive.file');

let isSigningIn = false;
let cachedAccessToken: string | null = localStorage.getItem('drive_access_token');

export const clearAccessToken = () => {
  cachedAccessToken = null;
  localStorage.removeItem('drive_access_token');
  localStorage.removeItem('drive_token_saved_at');
};

export const setAccessToken = (token: string | null) => {
  cachedAccessToken = token;
  if (token) {
    localStorage.setItem('drive_access_token', token);
    localStorage.setItem('drive_token_saved_at', String(Date.now()));
  } else {
    clearAccessToken();
  }
};

export const isDriveTokenValid = (): boolean => {
  const token = cachedAccessToken || localStorage.getItem('drive_access_token');
  if (!token) return false;
  const savedAt = localStorage.getItem('drive_token_saved_at');
  if (!savedAt) return false;
  const ageMs = Date.now() - parseInt(savedAt, 10);
  // Expire after 50 minutes (Google tokens last 60 minutes)
  return ageMs < 50 * 60 * 1000;
};

export const initAuth = (
  onAuthSuccess?: (user: User, token: string | null) => void,
  onAuthFailure?: () => void
) => {
  // Check for redirect result on startup (handles Android WebViews & AppsGeyser redirects)
  if (typeof window !== 'undefined') {
    getRedirectResult(auth)
      .then((result) => {
        if (result?.user) {
          const credential = GoogleAuthProvider.credentialFromResult(result);
          const token = credential?.accessToken || null;
          setAccessToken(token);
          if (onAuthSuccess) onAuthSuccess(result.user, token);
        }
      })
      .catch((err) => {
        console.warn('Redirect auth check notice:', err?.message || err);
      });
  }

  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      const validToken = isDriveTokenValid() ? (cachedAccessToken || localStorage.getItem('drive_access_token')) : null;
      if (onAuthSuccess) onAuthSuccess(user, validToken);
    } else {
      clearAccessToken();
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string | null } | null> => {
  try {
    isSigningIn = true;
    provider.setCustomParameters({ prompt: 'select_account' });
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential?.accessToken || null;
    setAccessToken(token);
    return { user: result.user, accessToken: token };
  } catch (error: any) {
    if (
      error?.code === 'auth/popup-closed-by-user' ||
      error?.code === 'auth/cancelled-popup-request' ||
      error?.message?.includes('popup-closed-by-user')
    ) {
      // User closed or dismissed the popup window
      return null;
    }
    if (
      error?.code === 'auth/popup-blocked' ||
      error?.message?.includes('popup-blocked')
    ) {
      // In embedded WebViews (AppsGeyser) where popup is blocked, fallback to redirect
      console.warn('Popup blocked, attempting redirect sign-in...');
      await signInWithRedirect(auth, provider);
      return null;
    }
    console.error('Sign in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (requireFresh = true): Promise<string | null> => {
  if (requireFresh && !isDriveTokenValid()) {
    clearAccessToken();
    return null;
  }
  return cachedAccessToken || localStorage.getItem('drive_access_token');
};

export const logout = async () => {
  await signOut(auth);
  clearAccessToken();
};

