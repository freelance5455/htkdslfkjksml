import { getAccessToken, googleSignIn, clearAccessToken, isDriveTokenValid } from './firebase';
import { Card, Folder } from '../types';

const FILE_NAME = 'memorization_app_backup.json';

export const getLastDriveBackupTime = (): number | null => {
  const ts = localStorage.getItem('drive_last_backup_time');
  return ts ? parseInt(ts, 10) : null;
};

export const ensureDriveToken = async (): Promise<string> => {
  let token = await getAccessToken(true);
  if (!token) {
    const res = await googleSignIn();
    if (res && res.accessToken) {
      token = res.accessToken;
    } else {
      throw new Error('গুগল ড্রাইভ সেশনের মেয়াদ শেষ হয়েছে। দয়া করে পুনরায় গুগল দিয়ে সাইন-ইন করুন।');
    }
  }
  return token;
};

/**
 * Robust fetch wrapper for Google Drive APIs with automatic 401 token refresh & retry.
 */
const driveFetch = async (
  url: string,
  options: RequestInit,
  tokenHolder: { token: string }
): Promise<Response> => {
  const makeHeaders = (tok: string) => {
    const h = new Headers(options.headers || {});
    h.set('Authorization', `Bearer ${tok}`);
    return h;
  };

  let res = await fetch(url, {
    ...options,
    headers: makeHeaders(tokenHolder.token)
  });

  if (res.status === 401) {
    console.warn('Drive access token returned 401. Re-authenticating with Google...');
    clearAccessToken();
    try {
      const signResult = await googleSignIn();
      if (signResult && signResult.accessToken) {
        tokenHolder.token = signResult.accessToken;
        res = await fetch(url, {
          ...options,
          headers: makeHeaders(tokenHolder.token)
        });
      } else {
        throw new Error('গুগল ড্রাইভ সেশনের মেয়াদ শেষ হয়েছে। দয়া করে পুনরায় গুগল দিয়ে সাইন-ইন করুন।');
      }
    } catch (authErr: any) {
      if (authErr?.message === 'POPUP_BLOCKED') {
        throw new Error('ব্রাউজারের পপ-আপ ব্লক করা আছে। দয়া করে পপ-আপ অনুমোদন করুন।');
      }
      throw new Error('গুগল ড্রাইভ সেশনের মেয়াদ শেষ হয়েছে। দয়া করে পুনরায় গুগল দিয়ে সাইন-ইন করুন।');
    }
  }

  if (res.status === 401) {
    clearAccessToken();
    throw new Error('গুগল ড্রাইভ সেশনের মেয়াদ শেষ হয়েছে। দয়া করে পুনরায় গুগল দিয়ে সাইন-ইন করুন।');
  }

  if (!res.ok) {
    const errorText = await res.text().catch(() => '');
    throw new Error(`গুগল ড্রাইভ ত্রুটি (${res.status}): ${errorText || res.statusText}`);
  }

  return res;
};

export interface DriveBackupPayload {
  cards: Card[];
  folders: Folder[];
  backedUpAt: number;
  version?: string;
  deviceInfo?: string;
}

export interface DriveRevisionItem {
  id: string;
  fileId: string;
  modifiedTime: string;
  size: number;
  cardsCount?: number;
  foldersCount?: number;
  backedUpAt?: number;
  isHealthy: boolean;
  isCurrentActive?: boolean;
  sourceLabel?: string;
}

export interface DriveFileItem {
  id: string;
  name: string;
  modifiedTime: string;
  size: number;
}

/**
 * Uploads all cards, folders, and embedded images to Google Drive.
 * CRITICAL SAFEGUARD: If local cards is 0, it inspects all existing Drive backups first.
 * If any existing Drive backup contains cards, it REFUSES to overwrite with empty data!
 */
export const syncToDrive = async (
  cards: Card[],
  folders: Folder[],
  allowEmptyOverwrite = false
): Promise<{ backedUpAt: number; fileId: string }> => {
  const initialToken = await ensureDriveToken();
  const tokenHolder = { token: initialToken };

  const q = encodeURIComponent(`name = '${FILE_NAME}' and trashed = false`);
  const searchRes = await driveFetch(
    `https://www.googleapis.com/drive/v3/files?q=${q}&spaces=drive&fields=files(id,name,modifiedTime,size)`,
    {},
    tokenHolder
  );
  
  const searchData = await searchRes.json();
  const now = Date.now();
  const payload: DriveBackupPayload = {
    cards,
    folders,
    backedUpAt: now,
    version: '2.0',
    deviceInfo: typeof navigator !== 'undefined' ? navigator.userAgent : 'Unknown'
  };

  const fileContent = JSON.stringify(payload);
  const metadata = { name: FILE_NAME, mimeType: 'application/json' };

  let fileId = '';

  // SAFEGUARD: If local device has 0 cards, check all existing files on Google Drive!
  if (cards.length === 0 && !allowEmptyOverwrite) {
    let existingFoundCards = 0;

    // Check files found with name = FILE_NAME
    if (searchData.files && searchData.files.length > 0) {
      for (const f of searchData.files) {
        try {
          const exRes = await driveFetch(
            `https://www.googleapis.com/drive/v3/files/${f.id}?alt=media`,
            {},
            tokenHolder
          );
          const exData = await exRes.json().catch(() => null);
          if (exData && Array.isArray(exData.cards) && exData.cards.length > 0) {
            existingFoundCards = Math.max(existingFoundCards, exData.cards.length);
          }
        } catch (e) {
          // ignore
        }
      }
    }

    // Also check other backup files on Google Drive
    if (existingFoundCards === 0) {
      const altFiles = await searchOtherDriveBackups(tokenHolder);
      for (const af of altFiles) {
        try {
          const afRes = await driveFetch(
            `https://www.googleapis.com/drive/v3/files/${af.id}?alt=media`,
            {},
            tokenHolder
          );
          const afData = await afRes.json().catch(() => null);
          if (afData && Array.isArray(afData.cards) && afData.cards.length > 0) {
            existingFoundCards = Math.max(existingFoundCards, afData.cards.length);
          }
        } catch (e) {
          // ignore
        }
      }
    }

    if (existingFoundCards > 0) {
      throw new Error(
        `সুরক্ষা সতর্কতা: আপনার গুগল ড্রাইভে ইতিমধ্যে ${existingFoundCards}টি কার্ড রয়েছে! নতুন ডিভাইসে ০টি কার্ড থাকায় পুরনো ব্যাকআপ মুছে ফেলা নিষিদ্ধ। আগের কার্ডগুলো উদ্ধার করতে প্রথমে "ড্রাইভ থেকে রিস্টোর" বাটনে চাপ দিন।`
      );
    }
  }

  if (searchData.files && searchData.files.length > 0) {
    fileId = searchData.files[0].id;
    
    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', new Blob([fileContent], { type: 'application/json' }));
    
    // keepRevisionForever=true ensures Google Drive keeps previous versions permanently!
    await driveFetch(
      `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=multipart&keepRevisionForever=true`,
      {
        method: 'PATCH',
        body: form
      },
      tokenHolder
    );
  } else {
    // If cards is 0 on a totally fresh file with no previous backup, warn user
    if (cards.length === 0 && !allowEmptyOverwrite) {
      throw new Error('আপনার ডিভাইসে কোনো ফ্ল্যাশ কার্ড নেই। ব্যাকআপ নেওয়ার আগে অন্তত একটি কার্ড তৈরি করুন।');
    }

    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', new Blob([fileContent], { type: 'application/json' }));
    
    const postRes = await driveFetch(
      `https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&keepRevisionForever=true`,
      {
        method: 'POST',
        body: form
      },
      tokenHolder
    );
    const postData = await postRes.json();
    fileId = postData.id;
  }

  localStorage.setItem('drive_last_backup_time', String(now));
  return { backedUpAt: now, fileId };
};

/**
 * Downloads memorization_app_backup.json from user's Google Drive.
 * RECOVERY INTELLIGENCE:
 * 1. Checks all files named memorization_app_backup.json (handles cases where multiple files exist).
 * 2. If the active file has 0 cards (accidentally overwritten on a fresh phone), it automatically
 *    traverses Google Drive Revisions API and recovers the last healthy version that had cards!
 * 3. Also searches other JSON backup files in Drive.
 * 4. Automatically re-saves the recovered healthy version as the active file so it won't be lost again!
 */
export const loadFromDrive = async (): Promise<{
  cards: Card[];
  folders: Folder[];
  backedUpAt?: number;
  recoveredFromRevision?: boolean;
  revisionDate?: string;
} | null> => {
  const initialToken = await ensureDriveToken();
  const tokenHolder = { token: initialToken };

  const q = encodeURIComponent(`name = '${FILE_NAME}' and trashed = false`);
  const searchRes = await driveFetch(
    `https://www.googleapis.com/drive/v3/files?q=${q}&spaces=drive&fields=files(id,name,modifiedTime,size)&orderBy=modifiedTime desc`,
    {},
    tokenHolder
  );
  
  const searchData = await searchRes.json();
  const files: DriveFileItem[] = searchData.files || [];

  // Track the best found candidate across files & revisions
  let bestCandidate: {
    cards: Card[];
    folders: Folder[];
    backedUpAt?: number;
    recoveredFromRevision: boolean;
    revisionDate?: string;
    fileId?: string;
  } | null = null;

  // Step 1: Examine all files named memorization_app_backup.json
  for (const f of files) {
    try {
      const downloadRes = await driveFetch(
        `https://www.googleapis.com/drive/v3/files/${f.id}?alt=media`,
        {},
        tokenHolder
      );
      const data = await downloadRes.json();

      // Check current active version
      if (data && Array.isArray(data.cards) && data.cards.length > 0) {
        if (!bestCandidate || data.cards.length > bestCandidate.cards.length) {
          bestCandidate = {
            cards: data.cards,
            folders: Array.isArray(data.folders) ? data.folders : [],
            backedUpAt: data.backedUpAt,
            recoveredFromRevision: false,
            fileId: f.id
          };
        }
      }

      // If active has 0 cards, or even if it has cards, check revisions to see if user had an even richer backup
      console.log(`Checking Google Drive revisions for file ${f.id}...`);
      try {
        const revRes = await driveFetch(
          `https://www.googleapis.com/drive/v3/files/${f.id}/revisions?pageSize=100&fields=revisions(id,modifiedTime,size,keepForever)`,
          {},
          tokenHolder
        );
        const revData = await revRes.json();

        if (revData.revisions && Array.isArray(revData.revisions) && revData.revisions.length > 0) {
          const sortedRevisions = [...revData.revisions].reverse();

          for (const rev of sortedRevisions) {
            try {
              const rDl = await driveFetch(
                `https://www.googleapis.com/drive/v3/files/${f.id}/revisions/${rev.id}?alt=media`,
                {},
                tokenHolder
              );
              const rJson = await rDl.json();

              if (rJson && Array.isArray(rJson.cards) && rJson.cards.length > 0) {
                if (!bestCandidate || rJson.cards.length > bestCandidate.cards.length) {
                  bestCandidate = {
                    cards: rJson.cards,
                    folders: Array.isArray(rJson.folders) ? rJson.folders : [],
                    backedUpAt: rJson.backedUpAt,
                    recoveredFromRevision: true,
                    revisionDate: rev.modifiedTime,
                    fileId: f.id
                  };
                }
              }
            } catch (singleRevErr) {
              console.warn(`Error reading revision ${rev.id}:`, singleRevErr);
            }
          }
        }
      } catch (revError) {
        console.warn(`Revision traversal for ${f.id} error:`, revError);
      }
    } catch (fErr) {
      console.warn(`Error inspecting file ${f.id}:`, fErr);
    }
  }

  // Step 2: If still no cards found, search other backup JSON files in Google Drive
  if (!bestCandidate) {
    const altFiles = await searchOtherDriveBackups(tokenHolder);
    for (const alt of altFiles) {
      try {
        const altDl = await driveFetch(
          `https://www.googleapis.com/drive/v3/files/${alt.id}?alt=media`,
          {},
          tokenHolder
        );
        const altJson = await altDl.json();
        if (altJson && Array.isArray(altJson.cards) && altJson.cards.length > 0) {
          if (!bestCandidate || altJson.cards.length > bestCandidate.cards.length) {
            bestCandidate = {
              cards: altJson.cards,
              folders: Array.isArray(altJson.folders) ? altJson.folders : [],
              backedUpAt: altJson.backedUpAt,
              recoveredFromRevision: true,
              revisionDate: alt.modifiedTime,
              fileId: alt.id
            };
          }
        }
      } catch (e) {
        // Continue
      }
    }
  }

  if (bestCandidate) {
    if (bestCandidate.backedUpAt) {
      localStorage.setItem('drive_last_backup_time', String(bestCandidate.backedUpAt));
    }

    // Re-save this healthy data as the active backup file on Drive so it's permanently protected
    if (bestCandidate.recoveredFromRevision && files.length > 0) {
      try {
        const activeFileId = files[0].id;
        const fixForm = new FormData();
        fixForm.append('metadata', new Blob([JSON.stringify({ name: FILE_NAME, mimeType: 'application/json' })], { type: 'application/json' }));
        fixForm.append('file', new Blob([JSON.stringify({
          cards: bestCandidate.cards,
          folders: bestCandidate.folders,
          backedUpAt: bestCandidate.backedUpAt || Date.now(),
          version: '2.0-recovered'
        })], { type: 'application/json' }));

        await driveFetch(
          `https://www.googleapis.com/upload/drive/v3/files/${activeFileId}?uploadType=multipart&keepRevisionForever=true`,
          { method: 'PATCH', body: fixForm },
          tokenHolder
        );
        console.log('Successfully re-saved recovered data as active backup on Drive!');
      } catch (reSaveErr) {
        console.warn('Failed to re-save recovered revision as active:', reSaveErr);
      }
    }

    return {
      cards: bestCandidate.cards,
      folders: bestCandidate.folders,
      backedUpAt: bestCandidate.backedUpAt,
      recoveredFromRevision: bestCandidate.recoveredFromRevision,
      revisionDate: bestCandidate.revisionDate
    };
  }

  // Return empty if completely empty and no revisions exist
  return {
    cards: [],
    folders: [],
    recoveredFromRevision: false
  };
};

/**
 * Searches for all revisions and files of the backup on Google Drive so the user
 * can manually view and choose any historical snapshot to restore.
 */
export const getDriveRevisionsList = async (): Promise<DriveRevisionItem[]> => {
  const initialToken = await ensureDriveToken();
  const tokenHolder = { token: initialToken };

  const items: DriveRevisionItem[] = [];
  const processedKeys = new Set<string>();

  // 1. Search memorization_app_backup.json files
  const q = encodeURIComponent(`name = '${FILE_NAME}' and trashed = false`);
  const searchRes = await driveFetch(
    `https://www.googleapis.com/drive/v3/files?q=${q}&spaces=drive&fields=files(id,name,modifiedTime,size)&orderBy=modifiedTime desc`,
    {},
    tokenHolder
  );
  
  const searchData = await searchRes.json();
  const mainFiles: DriveFileItem[] = searchData.files || [];

  for (let fIdx = 0; fIdx < mainFiles.length; fIdx++) {
    const file = mainFiles[fIdx];

    // Check active file content
    try {
      const activeDl = await driveFetch(
        `https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`,
        {},
        tokenHolder
      );
      const activeJson = await activeDl.json();
      const activeCardsCount = Array.isArray(activeJson?.cards) ? activeJson.cards.length : 0;
      const activeFoldersCount = Array.isArray(activeJson?.folders) ? activeJson.folders.length : 0;
      const activeBackedUpAt = activeJson?.backedUpAt || 0;

      const activeKey = `${file.id}-active`;
      if (!processedKeys.has(activeKey)) {
        processedKeys.add(activeKey);
        items.push({
          id: file.id,
          fileId: file.id,
          modifiedTime: file.modifiedTime,
          size: Number(file.size || 0),
          cardsCount: activeCardsCount,
          foldersCount: activeFoldersCount,
          backedUpAt: activeBackedUpAt,
          isHealthy: activeCardsCount > 0,
          isCurrentActive: fIdx === 0,
          sourceLabel: fIdx === 0 ? 'বর্তমান সক্রিয় ব্যাকআপ ফাইল' : `বিকল্প ব্যাকআপ ফাইল #${fIdx + 1}`
        });
      }
    } catch (e) {
      // Ignored
    }

    // Inspect file revisions
    try {
      const revRes = await driveFetch(
        `https://www.googleapis.com/drive/v3/files/${file.id}/revisions?pageSize=100&fields=revisions(id,modifiedTime,size,keepForever)&orderBy=modifiedTime desc`,
        {},
        tokenHolder
      );
      const revData = await revRes.json();

      if (revData.revisions && Array.isArray(revData.revisions)) {
        for (const r of revData.revisions) {
          const revKey = `${file.id}-${r.id}`;
          if (processedKeys.has(revKey)) continue;
          processedKeys.add(revKey);

          let cardsCount = 0;
          let foldersCount = 0;
          let backedUpAt = 0;

          try {
            const dl = await driveFetch(
              `https://www.googleapis.com/drive/v3/files/${file.id}/revisions/${r.id}?alt=media`,
              {},
              tokenHolder
            );
            const json = await dl.json();
            if (json && Array.isArray(json.cards)) {
              cardsCount = json.cards.length;
              foldersCount = Array.isArray(json.folders) ? json.folders.length : 0;
              backedUpAt = json.backedUpAt || 0;
            }
          } catch (e) {
            // Ignored
          }

          items.push({
            id: r.id,
            fileId: file.id,
            modifiedTime: r.modifiedTime,
            size: Number(r.size || 0),
            cardsCount,
            foldersCount,
            backedUpAt,
            isHealthy: cardsCount > 0,
            isCurrentActive: false,
            sourceLabel: 'ড্রাইভ সংস্করণ ইতিহাস (পূর্ববর্তী সেভ)'
          });
        }
      }
    } catch (e) {
      console.warn(`Error reading revisions for ${file.id}:`, e);
    }
  }

  // 2. Also search other backup files in user's Drive
  const altFiles = await searchOtherDriveBackups(tokenHolder);
  for (const alt of altFiles) {
    if (mainFiles.some(mf => mf.id === alt.id)) continue;
    const altKey = `${alt.id}-alt`;
    if (processedKeys.has(altKey)) continue;
    processedKeys.add(altKey);

    let cardsCount = 0;
    let foldersCount = 0;
    let backedUpAt = 0;

    try {
      const altDl = await driveFetch(
        `https://www.googleapis.com/drive/v3/files/${alt.id}?alt=media`,
        {},
        tokenHolder
      );
      const altJson = await altDl.json();
      if (altJson && Array.isArray(altJson.cards)) {
        cardsCount = altJson.cards.length;
        foldersCount = Array.isArray(altJson.folders) ? altJson.folders.length : 0;
        backedUpAt = altJson.backedUpAt || 0;
      }
    } catch (e) {
      // Ignored
    }

    items.push({
      id: alt.id,
      fileId: alt.id,
      modifiedTime: alt.modifiedTime,
      size: Number(alt.size || 0),
      cardsCount,
      foldersCount,
      backedUpAt,
      isHealthy: cardsCount > 0,
      isCurrentActive: false,
      sourceLabel: `সংরক্ষিত ফাইল: ${alt.name}`
    });
  }

  // Sort: healthy first, then newest modifiedTime
  return items.sort((a, b) => {
    if (a.isHealthy && !b.isHealthy) return -1;
    if (!a.isHealthy && b.isHealthy) return 1;
    return new Date(b.modifiedTime).getTime() - new Date(a.modifiedTime).getTime();
  });
};

/**
 * Restores a specific revision or file by its revision ID and file ID.
 */
export const restoreSpecificRevision = async (
  revisionId: string,
  fileId?: string
): Promise<{ cards: Card[]; folders: Folder[] }> => {
  const initialToken = await ensureDriveToken();
  const tokenHolder = { token: initialToken };

  let data: any = null;

  // Try fetching as revision if fileId provided
  if (fileId && revisionId !== fileId) {
    try {
      const dl = await driveFetch(
        `https://www.googleapis.com/drive/v3/files/${fileId}/revisions/${revisionId}?alt=media`,
        {},
        tokenHolder
      );
      data = await dl.json();
    } catch (e) {
      console.warn('Failed as revision, falling back to file download:', e);
    }
  }

  // If not loaded or revisionId === fileId, fetch as direct file
  if (!data || !Array.isArray(data.cards)) {
    const targetId = fileId || revisionId;
    const dl = await driveFetch(
      `https://www.googleapis.com/drive/v3/files/${targetId}?alt=media`,
      {},
      tokenHolder
    );
    data = await dl.json();
  }

  if (!data || !Array.isArray(data.cards)) {
    throw new Error('নির্বাচিত সংস্করণে কোনো কার্ড ডাটা পাওয়া যায়নি।');
  }

  // Re-save this restored data as the active backup file on Drive with keepRevisionForever
  try {
    const q = encodeURIComponent(`name = '${FILE_NAME}' and trashed = false`);
    const searchRes = await driveFetch(
      `https://www.googleapis.com/drive/v3/files?q=${q}&spaces=drive&fields=files(id)`,
      {},
      tokenHolder
    );
    const sData = await searchRes.json();
    if (sData.files && sData.files.length > 0) {
      const activeFileId = sData.files[0].id;
      const fixForm = new FormData();
      fixForm.append('metadata', new Blob([JSON.stringify({ name: FILE_NAME, mimeType: 'application/json' })], { type: 'application/json' }));
      fixForm.append('file', new Blob([JSON.stringify({
        cards: data.cards,
        folders: data.folders || [],
        backedUpAt: Date.now(),
        version: '2.0-restored'
      })], { type: 'application/json' }));

      await driveFetch(
        `https://www.googleapis.com/upload/drive/v3/files/${activeFileId}?uploadType=multipart&keepRevisionForever=true`,
        { method: 'PATCH', body: fixForm },
        tokenHolder
      );
    }
  } catch (e) {
    console.warn('Failed to set restored revision as active:', e);
  }

  return {
    cards: data.cards,
    folders: Array.isArray(data.folders) ? data.folders : []
  };
};

/**
 * Search Google Drive for any other flashcard JSON backups created by the user.
 */
async function searchOtherDriveBackups(tokenHolder: { token: string }): Promise<DriveFileItem[]> {
  try {
    const q = encodeURIComponent(
      `mimeType = 'application/json' and (name contains 'backup' or name contains 'flashcard' or name contains 'anki' or name contains 'memorization') and trashed = false`
    );
    const res = await driveFetch(
      `https://www.googleapis.com/drive/v3/files?q=${q}&spaces=drive&fields=files(id,name,modifiedTime,size)&orderBy=modifiedTime desc`,
      {},
      tokenHolder
    );
    const data = await res.json();
    return data.files || [];
  } catch (e) {
    console.warn('Alternative files search notice:', e);
    return [];
  }
}
