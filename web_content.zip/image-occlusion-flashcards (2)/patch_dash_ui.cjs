const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

const multiSelectButton = `
        <div className="absolute top-4 left-4 flex gap-2">
          {isSelectionMode ? (
            <>
              <button onClick={() => {
                if (selectedCards.length > 0 || selectedFolders.length > 0) {
                  setDeleteType('card'); // Can be handled via generic delete modal or directly
                  setDeleteConfirmId(-1); // Special ID for bulk delete
                }
              }} className="p-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm font-bold shadow">ডিলিট ({selectedCards.length + selectedFolders.length})</button>
              <button onClick={() => {
                if (selectedCards.length > 0 || selectedFolders.length > 0) {
                  setMoveItemData({ id: -1, type: 'card' }); // Special move modal
                }
              }} className="p-2 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg text-sm font-bold shadow">মুভ ({selectedCards.length + selectedFolders.length})</button>
              <button onClick={cancelSelection} className="p-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg text-sm font-bold shadow">বাতিল</button>
            </>
          ) : (
            <button onClick={() => setIsSelectionMode(true)} className="p-2 bg-white/20 hover:bg-white/30 text-white rounded-lg text-sm font-bold shadow">
              সিলেক্ট করুন
            </button>
          )}
        </div>
`;

code = code.replace(
  '<h1 className="text-2xl font-bold text-center">আমার ফ্ল্যাশকার্ডস</h1>',
  multiSelectButton + '\n        <h1 className="text-2xl font-bold text-center mt-2 sm:mt-0">আমার ফ্ল্যাশকার্ডস</h1>'
);

const folderStart = `<div key={folder.id} onClick={() => { if(isSelectionMode) toggleSelectFolder(folder.id); else onOpenFolder(folder.id); }} className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between cursor-pointer hover:shadow-md transition-shadow group">
                  <div className="flex items-center gap-4 overflow-hidden w-full pr-2">
                    {isSelectionMode && (
                      <input type="checkbox" checked={selectedFolders.includes(folder.id)} onChange={() => toggleSelectFolder(folder.id)} className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500" onClick={e => e.stopPropagation()} />
                    )}`;
code = code.replace(
  `<div key={folder.id} onClick={() => onOpenFolder(folder.id)} className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between cursor-pointer hover:shadow-md transition-shadow group">
                  <div className="flex items-center gap-4 overflow-hidden w-full pr-2">`,
  folderStart
);

const cardStart = `<div key={card.id} className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between group" onClick={() => { if(isSelectionMode) toggleSelectCard(card.id); }}>
                  <div className="flex items-center gap-3 overflow-hidden w-full pr-2">
                    {isSelectionMode && (
                      <input type="checkbox" checked={selectedCards.includes(card.id)} onChange={() => toggleSelectCard(card.id)} className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500" onClick={e => e.stopPropagation()} />
                    )}`;
code = code.replace(
  `<div key={card.id} className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between group">
                  <div className="flex items-center gap-3 overflow-hidden w-full pr-2">`,
  cardStart
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
