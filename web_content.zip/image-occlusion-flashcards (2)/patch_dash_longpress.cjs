const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

// 1. Add imports
code = code.replace(
  "import { BookOpen, Trash2, Plus, Search, Shuffle, Download, Upload, Edit3, X, Folder as FolderIcon, Moon, Sun } from 'lucide-react';",
  "import { BookOpen, Trash2, Plus, Search, Shuffle, Download, Upload, Edit3, X, Folder as FolderIcon, Moon, Sun, MoreVertical, CheckSquare } from 'lucide-react';"
);

// 2. Add state & refs
const states = `
  const [showMenu, setShowMenu] = useState(false);
  const pressTimer = useRef<NodeJS.Timeout | null>(null);

  const startPress = (id: number, type: 'card'|'folder') => {
    if (isSelectionMode) return;
    pressTimer.current = setTimeout(() => {
      setIsSelectionMode(true);
      if (type === 'card') toggleSelectCard(id);
      else toggleSelectFolder(id);
    }, 500);
  };

  const cancelPress = () => {
    if (pressTimer.current) {
      clearTimeout(pressTimer.current);
      pressTimer.current = null;
    }
  };

  const selectAll = () => {
    setSelectedCards(filteredCards.map(c => c.id));
    setSelectedFolders(filteredFolders.map(f => f.id));
    setShowMenu(false);
  };
`;
code = code.replace(
  "const [isSelectionMode, setIsSelectionMode] = useState(false);",
  "const [isSelectionMode, setIsSelectionMode] = useState(false);\n" + states
);

// 3. Update Header
const oldHeader = `<header className="bg-blue-600 dark:bg-blue-800 text-white p-5 shadow-md rounded-b-2xl mb-6 shrink-0 relative">
        
        <div className="absolute top-4 left-4 flex gap-2">
          {isSelectionMode ? (
            <>
              <button onClick={() => {
                if (selectedCards.length > 0 || selectedFolders.length > 0) {
                  setDeleteType('card'); // Can be handled via generic delete modal or directly
                  setDeleteConfirmId(-1); // Special ID for bulk delete
                }
              }} className="p-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm font-bold shadow">ডিলিট ({selectedCards.length + selectedFolders.length})</button>
              <button onClick={() => {
                if (selectedCards.length > 0 || selectedFolders.length > 0) {
                  setMoveItemData({ id: -1, type: 'card' }); // Special move modal
                }
              }} className="p-2 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg text-sm font-bold shadow">মুভ ({selectedCards.length + selectedFolders.length})</button>
              <button onClick={cancelSelection} className="p-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg text-sm font-bold shadow">বাতিল</button>
            </>
          ) : (
            <button onClick={() => setIsSelectionMode(true)} className="p-2 bg-white/20 hover:bg-white/30 text-white rounded-lg text-sm font-bold shadow">
              সিলেক্ট করুন
            </button>
          )}
        </div>

        <h1 className="text-2xl font-bold text-center mt-2 sm:mt-0">আমার ফ্ল্যাশকার্ডস</h1>
        <p className="text-blue-100 dark:text-blue-200 text-sm mt-1 text-center">মোট: {rootFolders.length} টি ফোল্ডার, {cards.length} টি কার্ড</p>
        
        <div className="absolute top-4 right-4 flex gap-2">
          <button onClick={onRecoverLegacy} title="হারানো ডাটা খুঁজুন (Recovery)" className="flex items-center gap-1 p-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-full transition-colors text-xs font-bold">
            রিকভারি চেষ্টা
          </button>
          <SyncButton cards={cards} folders={folders} onDataLoaded={onImport} setAlert={setAlertMsg} />
          {toggleDarkMode && (
            <button onClick={toggleDarkMode} title="ডার্ক মোড টগল করুন" className="p-2 hover:bg-blue-500 dark:hover:bg-blue-700 rounded-full transition-colors">
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          )}
          <button onClick={handleExport} title="ব্যাকআপ (Export)" className="flex items-center gap-1 p-2 hover:bg-blue-500 dark:hover:bg-blue-700 rounded-full transition-colors text-sm font-medium">
            <Download className="w-5 h-5" />
            <span className="hidden sm:inline">ফাইল ব্যাকআপ</span>
          </button>
          <button onClick={() => fileInputRef.current?.click()} title="রিস্টোর (Import)" className="flex items-center gap-1 p-2 hover:bg-blue-500 dark:hover:bg-blue-700 rounded-full transition-colors text-sm font-medium">
            <Upload className="w-5 h-5" />
            <span className="hidden sm:inline">ফাইল রিস্টোর</span>
          </button>
          <input type="file" ref={fileInputRef} onChange={handleImport} accept=".json" className="hidden" />
          <input type="file" ref={bulkFileInputRef} onChange={handleBulkUpload} accept="image/*" multiple className="hidden" />
        </div>
      </header>`;

const newHeader = `{isSelectionMode ? (
        <header className="bg-blue-600 dark:bg-blue-800 text-white p-4 shadow-md rounded-b-2xl mb-6 shrink-0 flex items-center justify-between relative z-20">
          <div className="flex items-center gap-3">
            <button onClick={cancelSelection} className="p-2 hover:bg-blue-700 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <span className="text-xl font-bold">{selectedCards.length + selectedFolders.length} সিলেক্টেড</span>
          </div>
          <div className="relative">
            <button onClick={() => setShowMenu(!showMenu)} className="p-2 hover:bg-blue-700 rounded-full transition-colors">
              <MoreVertical className="w-6 h-6" />
            </button>
            {showMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl py-2 text-gray-800 dark:text-gray-200 z-50 border border-gray-100 dark:border-slate-700">
                <button onClick={selectAll} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left font-medium">
                  <CheckSquare className="w-5 h-5" /> সব সিলেক্ট করুন
                </button>
                <button onClick={() => {
                  setShowMenu(false);
                  if (selectedCards.length > 0 || selectedFolders.length > 0) setMoveItemData({ id: -1, type: 'card' });
                }} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left font-medium">
                  <FolderIcon className="w-5 h-5" /> মুভ করুন
                </button>
                <button onClick={() => {
                  setShowMenu(false);
                  if (selectedCards.length > 0 || selectedFolders.length > 0) {
                    setDeleteType('card');
                    setDeleteConfirmId(-1);
                  }
                }} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-red-50 dark:hover:bg-red-900/30 text-red-500 transition-colors text-left font-medium">
                  <Trash2 className="w-5 h-5" /> ডিলিট করুন
                </button>
              </div>
            )}
          </div>
        </header>
      ) : (
        <header className="bg-blue-600 dark:bg-blue-800 text-white p-5 shadow-md rounded-b-2xl mb-6 shrink-0 relative">
          <h1 className="text-2xl font-bold text-center mt-2 sm:mt-0">আমার ফ্ল্যাশকার্ডস</h1>
          <p className="text-blue-100 dark:text-blue-200 text-sm mt-1 text-center">মোট: {rootFolders.length} টি ফোল্ডার, {cards.length} টি কার্ড</p>
          
          <div className="absolute top-4 left-4 flex gap-2">
            <button onClick={onRecoverLegacy} title="হারানো ডাটা খুঁজুন (Recovery)" className="flex items-center gap-1 p-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-full transition-colors text-xs font-bold shadow">
              রিকভারি
            </button>
          </div>
          
          <div className="absolute top-4 right-4 flex gap-2">
            <SyncButton cards={cards} folders={folders} onDataLoaded={onImport} setAlert={setAlertMsg} />
            {toggleDarkMode && (
              <button onClick={toggleDarkMode} title="ডার্ক মোড টগল করুন" className="p-2 hover:bg-blue-500 dark:hover:bg-blue-700 rounded-full transition-colors">
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
            )}
            <button onClick={handleExport} title="ব্যাকআপ (Export)" className="flex items-center gap-1 p-2 hover:bg-blue-500 dark:hover:bg-blue-700 rounded-full transition-colors text-sm font-medium">
              <Download className="w-5 h-5" />
              <span className="hidden sm:inline">ব্যাকআপ</span>
            </button>
            <button onClick={() => fileInputRef.current?.click()} title="রিস্টোর (Import)" className="flex items-center gap-1 p-2 hover:bg-blue-500 dark:hover:bg-blue-700 rounded-full transition-colors text-sm font-medium">
              <Upload className="w-5 h-5" />
              <span className="hidden sm:inline">রিস্টোর</span>
            </button>
            <input type="file" ref={fileInputRef} onChange={handleImport} accept=".json" className="hidden" />
            <input type="file" ref={bulkFileInputRef} onChange={handleBulkUpload} accept="image/*" multiple className="hidden" />
          </div>
        </header>
      )}`;
      
code = code.replace(oldHeader, newHeader);

// 4. Update the mouse/touch events on folders and cards
const folderStart = `<div key={folder.id} onClick={() => { if(isSelectionMode) toggleSelectFolder(folder.id); else onOpenFolder(folder.id); }} className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between cursor-pointer hover:shadow-md transition-shadow group">`;
const newFolderStart = `<div key={folder.id} 
                  onClick={() => { if(isSelectionMode) toggleSelectFolder(folder.id); else onOpenFolder(folder.id); }} 
                  onPointerDown={(e) => {
                     // Don't trigger long press if it's right click or not main button
                     if (e.button !== 0) return;
                     startPress(folder.id, 'folder');
                  }}
                  onPointerUp={cancelPress}
                  onPointerLeave={cancelPress}
                  onPointerCancel={cancelPress}
                  onContextMenu={(e) => { 
                     // Prevent native context menu from triggering default browser behavior if we want custom long press
                     // e.preventDefault(); 
                  }}
                  className={\`bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border flex items-center justify-between cursor-pointer hover:shadow-md transition-shadow group \${isSelectionMode && selectedFolders.includes(folder.id) ? 'border-blue-500 bg-blue-50 dark:bg-slate-700' : 'border-gray-100'}\`}>`;
code = code.replace(folderStart, newFolderStart);

const cardStart = `<div key={card.id} className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between group" onClick={() => { if(isSelectionMode) toggleSelectCard(card.id); }}>`;
const newCardStart = `<div key={card.id} 
                  onClick={() => { if(isSelectionMode) toggleSelectCard(card.id); }}
                  onPointerDown={(e) => {
                     if (e.button !== 0) return;
                     startPress(card.id, 'card');
                  }}
                  onPointerUp={cancelPress}
                  onPointerLeave={cancelPress}
                  onPointerCancel={cancelPress}
                  className={\`bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border flex items-center justify-between group cursor-pointer \${isSelectionMode && selectedCards.includes(card.id) ? 'border-blue-500 bg-blue-50 dark:bg-slate-700' : 'border-gray-100'}\`}>`;
code = code.replace(cardStart, newCardStart);

fs.writeFileSync('src/components/Dashboard.tsx', code);
