const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

// Update Props interface for onSkip
if (!code.includes('onSkip: () => void;')) {
  code = code.replace(
    "onCancel: () => void;\n  isBulkEdit?: boolean;",
    "onCancel: () => void;\n  onSkip?: () => void;\n  isBulkEdit?: boolean;"
  );
}

if (!code.includes('onSkip, isBulkEdit')) {
  code = code.replace(
    "onCancel, isBulkEdit, bulkRemaining",
    "onCancel, onSkip, isBulkEdit, bulkRemaining"
  );
}

// Revert Cancel to just X
const newCancelBtn = `<button onClick={onCancel} className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1 font-medium">
          {isBulkEdit ? <span className="text-sm">স্কিপ</span> : <X className="w-6 h-6" />}
        </button>`;
const oldCancelBtn = `<button onClick={onCancel} className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-full transition-colors" title="বাতিল">
          <X className="w-6 h-6" />
        </button>`;
code = code.replace(newCancelBtn, oldCancelBtn);

// Add Skip button next to save
const saveBtnBlock = `<button
          onClick={handleSave}
          className="flex items-center gap-2 bg-green-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-600 active:scale-95 transition-transform"
        >
          <Save className="w-5 h-5 hidden sm:block" /> <span className="hidden sm:inline">{isBulkEdit ? 'সেভ ও পরবর্তী' : 'সেভ'}</span><span className="sm:hidden">{isBulkEdit ? 'সেভ ও পরবর্তী' : 'সেভ'}</span>
        </button>`;
const newSaveBtnBlock = `
        <div className="flex items-center gap-2">
          {isBulkEdit && onSkip && (
            <button
              onClick={onSkip}
              className="flex items-center gap-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 px-4 py-2 rounded-lg font-medium active:scale-95 transition-transform"
            >
              স্কিপ (Skip)
            </button>
          )}
          <button
            onClick={handleSave}
            className="flex items-center gap-2 bg-green-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-600 active:scale-95 transition-transform"
          >
            <Save className="w-5 h-5 hidden sm:block" /> <span className="hidden sm:inline">{isBulkEdit ? 'সেভ ও পরবর্তী' : 'সেভ'}</span><span className="sm:hidden">{isBulkEdit ? 'সেভ ও পরবর্তী' : 'সেভ'}</span>
          </button>
        </div>`;
code = code.replace(saveBtnBlock, newSaveBtnBlock);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log("CreateCard patched for skip");
