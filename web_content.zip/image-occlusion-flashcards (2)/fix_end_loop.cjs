const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const targetEndLoop = `      setAutoBulkCompletedCards(processedCards);
      setShowAutoBulkSummary(true);
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate([20, 40, 20]); } catch (_) {}
      }`;

const replacementEndLoop = `      setAutoBulkCompletedCards(processedCards);
      setShowAutoBulkSummary(true);
      
      if (onBulkCreate) {
         onBulkCreate([]);
      }
      
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate([20, 40, 20]); } catch (_) {}
      }`;

if (code.includes(targetEndLoop)) {
    code = code.replace(targetEndLoop, replacementEndLoop);
    console.log('Fixed end loop refresh');
} else {
    console.log('Target End Loop not found');
}

fs.writeFileSync('src/components/CreateCard.tsx', code);
