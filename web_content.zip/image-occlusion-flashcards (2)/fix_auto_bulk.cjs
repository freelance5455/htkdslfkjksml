const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const autoBulkTarget = `    try {
      const { compressImage } = await import('../lib/imageUtils');

      for (let i = 0; i < memoryFiles.length; i++) {
        const file = memoryFiles[i];
        const defaultTitle = file.name.replace(/\\.[^/.]+$/, '').replace(/[-_]/g, ' ');

        setAutoBulkProgress({
          current: i + 1,
          total: memoryFiles.length,
          title: defaultTitle,
          step: 'ছবি ফিল্টারিং, কন্ট্রাস্ট ও রেজ্যুলুশন বাড়ানো হচ্ছে...'
        });

        // Step 1: Quality optimization and sharpness enhancement
        const enhancedBase64 = await compressImage(file, 800, 0.75, true);

        setAutoBulkProgress({
          current: i + 1,
          total: memoryFiles.length,
          title: defaultTitle,
          step: 'AI দ্বারা অটো নাম, একাডেমিক স্টাডি নোট ও মাস্ক তৈরি হচ্ছে...'
        });

        // Step 2: Single-call AI processing for Title, Notes, and Occlusion Masks
        let cardTitle = defaultTitle;
        let cardNotes = '';
        let detectedMasks: Rectangle[] = [];

        try {
          const response = await fetch('/api/auto-process-diagram', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ imageBase64: enhancedBase64 })
          });

          if (response.ok) {
            const result = await response.json();
            if (result.title && result.title.trim()) {
              cardTitle = result.title.trim();
            }
            if (result.notes && result.notes.trim()) {
              cardNotes = result.notes.trim();
            }
            if (Array.isArray(result.boxes) && result.boxes.length > 0) {
              detectedMasks = result.boxes.map((b: any, bIdx: number) => {
                const xmin = b.xmin;
                const ymin = b.ymin;
                const xmax = b.xmax;
                const ymax = b.ymax;
                const padX = 3;
                const padY = 2;
                const clampedXmin = Math.max(0, xmin - padX);
                const clampedYmin = Math.max(0, ymin - padY);
                const clampedXmax = Math.min(1000, xmax + padX);
                const clampedYmax = Math.min(1000, ymax + padY);

                return {
                  id: Date.now() + i * 10000 + bIdx,
                  x: clampedXmin,
                  y: clampedYmin,
                  width: clampedXmax - clampedXmin,
                  height: clampedYmax - clampedYmin,
                  xPercent: (clampedXmin / 1000) * 100,
                  yPercent: (clampedYmin / 1000) * 100,
                  widthPercent: ((clampedXmax - clampedXmin) / 1000) * 100,
                  heightPercent: ((clampedYmax - clampedYmin) / 1000) * 100,
                  label: b.text || '',
                  badgePosition: 'auto'
                };
              });
            }
          }
        } catch (aiErr) {
          console.warn('Auto AI processing error for card', i, aiErr);
        }

        const now = Date.now() + i;
        const newCard: Card = {
          id: now,
          folderId: folderId || undefined,
          title: cardTitle,
          notes: cardNotes,
          tags: [],
          image: enhancedBase64,
          rectangles: detectedMasks,
          pins: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          nextReview: new Date().toISOString(),
          interval: 0,
          repetition: 0,
          efactor: 2.5
        };

        processedCards.push(newCard);
      }
    } catch (err) {`;

const autoBulkReplacement = `    try {
      const { compressImage } = await import('../lib/imageUtils');
      
      const chunkSize = 3; // Process 3 images concurrently to speed up bulk upload without hitting rate limits
      let completedCount = 0;

      for (let i = 0; i < memoryFiles.length; i += chunkSize) {
        const chunk = memoryFiles.slice(i, i + chunkSize);
        
        await Promise.all(chunk.map(async (file, chunkIdx) => {
          const actualIdx = i + chunkIdx;
          const defaultTitle = file.name.replace(/\\.[^/.]+$/, '').replace(/[-_]/g, ' ');

          // Step 1: Quality optimization and sharpness enhancement
          const enhancedBase64 = await compressImage(file, 800, 0.75, true);

          // Step 2: Single-call AI processing for Title, Notes, and Occlusion Masks
          let cardTitle = defaultTitle;
          let cardNotes = '';
          let detectedMasks: Rectangle[] = [];

          try {
            const response = await fetch('/api/auto-process-diagram', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ imageBase64: enhancedBase64 })
            });

            if (response.ok) {
              const result = await response.json();
              if (result.title && result.title.trim()) {
                cardTitle = result.title.trim();
              }
              if (result.notes && result.notes.trim()) {
                cardNotes = result.notes.trim();
              }
              if (Array.isArray(result.boxes) && result.boxes.length > 0) {
                detectedMasks = result.boxes.map((b: any, bIdx: number) => {
                  const xmin = b.xmin;
                  const ymin = b.ymin;
                  const xmax = b.xmax;
                  const ymax = b.ymax;
                  const padX = 3;
                  const padY = 2;
                  const clampedXmin = Math.max(0, xmin - padX);
                  const clampedYmin = Math.max(0, ymin - padY);
                  const clampedXmax = Math.min(1000, xmax + padX);
                  const clampedYmax = Math.min(1000, ymax + padY);

                  return {
                    id: Date.now() + actualIdx * 10000 + bIdx,
                    x: clampedXmin,
                    y: clampedYmin,
                    width: clampedXmax - clampedXmin,
                    height: clampedYmax - clampedYmin,
                    xPercent: (clampedXmin / 1000) * 100,
                    yPercent: (clampedYmin / 1000) * 100,
                    widthPercent: ((clampedXmax - clampedXmin) / 1000) * 100,
                    heightPercent: ((clampedYmax - clampedYmin) / 1000) * 100,
                    label: b.text || '',
                    badgePosition: 'auto'
                  };
                });
              }
            }
          } catch (aiErr) {
            console.warn('Auto AI processing error for card', actualIdx, aiErr);
          }

          const now = Date.now() + actualIdx;
          const newCard: Card = {
            id: now,
            folderId: folderId || undefined,
            title: cardTitle,
            notes: cardNotes,
            tags: [],
            image: enhancedBase64,
            rectangles: detectedMasks,
            pins: [],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            nextReview: new Date().toISOString(),
            interval: 0,
            repetition: 0,
            efactor: 2.5
          };

          processedCards.push(newCard);
          
          completedCount++;
          setAutoBulkProgress(prev => ({
            ...prev,
            current: completedCount,
            title: cardTitle,
            step: \`ছবি প্রসেস হচ্ছে... (\${completedCount}/\${memoryFiles.length})\`
          }));
        }));
      }
      
      // Ensure processedCards retains the original order of memoryFiles
      // Sort them based on their creation ID which incorporates the actualIdx
      processedCards.sort((a, b) => a.id - b.id);
      
    } catch (err) {`;

code = code.replace(autoBulkTarget, autoBulkReplacement);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Done replacing auto bulk');
