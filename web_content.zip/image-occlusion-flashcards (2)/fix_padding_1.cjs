const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

// Fix 1: Auto-process diagram (Bulk mode initial process)
const target1 = `            if (Array.isArray(result.boxes) && result.boxes.length > 0) {
              detectedMasks = result.boxes.map((b: any, bIdx: number) => {
                const padX = 2;
                const padY = 2;
                const clampedXmin = Math.max(0, b.xmin - padX);
                const clampedYmin = Math.max(0, b.ymin - padY);
                const clampedXmax = Math.min(1000, b.xmax + padX);
                const clampedYmax = Math.min(1000, b.ymax + padY);
                return {`;

const replacement1 = `            if (Array.isArray(result.boxes) && result.boxes.length > 0) {
              detectedMasks = result.boxes.map((b: any, bIdx: number) => {
                const padX = 8;
                const padY = 8;
                const clampedXmin = Math.max(0, b.xmin - padX);
                const clampedYmin = Math.max(0, b.ymin - padY);
                const clampedXmax = Math.min(1000, b.xmax + padX);
                const clampedYmax = Math.min(1000, b.ymax + padY);
                return {`;

code = code.replace(target1, replacement1);

// Fix 2: detect-text in bulk mode chunk loop
const target2 = `              const newRects: Rectangle[] = boxes.map((b: any, bIdx: number) => {
                const originalW = b.xmax - b.xmin;
                const originalH = b.ymax - b.ymin;
                const centerX = b.xmin + (originalW / 2);
                const centerY = b.ymin + (originalH / 2);
                const snappedH = Math.min(originalH * 0.85, 45);
                const snappedW = originalW + (originalW * 0.04);
                const xmin = Math.max(0, centerX - (snappedW / 2));
                const xmax = Math.min(1000, centerX + (snappedW / 2));
                const ymin = Math.max(0, centerY - (snappedH / 2));
                const ymax = Math.min(1000, centerY + (snappedH / 2));`;

const replacement2 = `              const newRects: Rectangle[] = boxes.map((b: any, bIdx: number) => {
                const padX = 8;
                const padY = 8;
                const xmin = Math.max(0, b.xmin - padX);
                const xmax = Math.min(1000, b.xmax + padX);
                const ymin = Math.max(0, b.ymin - padY);
                const ymax = Math.min(1000, b.ymax + padY);`;

code = code.replace(target2, replacement2);

// Fix 3: handleAutoDetect single card 
const target3 = `        // 4. Map to Rectangles with smart badge placement away from the central diagram
        const newRects: Rectangle[] = mergedBoxes.map((box, idx) => {
          // The AI now returns precisely tight bounding boxes. We just use them directly,
          // applying a very slight padding for aesthetic "sleek label" look.
          const xmin = Math.max(0, box.xmin);
          const xmax = Math.min(1000, box.xmax);
          const ymin = Math.max(0, box.ymin);
          const ymax = Math.min(1000, box.ymax);`;

const replacement3 = `        // 4. Map to Rectangles with smart badge placement away from the central diagram
        const newRects: Rectangle[] = mergedBoxes.map((box, idx) => {
          // Add generous padding to fully cover the Bengali and English text including diacritics
          const padX = 8;
          const padY = 8;
          const xmin = Math.max(0, box.xmin - padX);
          const xmax = Math.min(1000, box.xmax + padX);
          const ymin = Math.max(0, box.ymin - padY);
          const ymax = Math.min(1000, box.ymax + padY);`;

code = code.replace(target3, replacement3);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed padding');
