const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

// Use regex to replace handleAutoBulkUpload
const autoBulkRegex = /\/\/ 3rd Option: Full Auto Bulk Processing Handler.*?const handleSaveAllAutoBulkCards = \(\) => {/s;
if (autoBulkRegex.test(code)) {
    code = code.replace(autoBulkRegex, `// 3rd Option: Full Auto Bulk Processing Handler (Auto Name, Notes, Masks, and Quality)
  const handleAutoBulkUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawFiles: File[] = Array.from(e.target.files || []);
    const validFiles = rawFiles.filter(f => f.type.match('image.*'));
    if (validFiles.length === 0) {
      if (rawFiles.length > 0) {
        setAlertMsg('দয়া করে শুধুমাত্র সাধারণ ছবি (JPG, PNG) আপলোড করুন।');
      }
      return;
    }

    setIsAutoBulkActive(true);
    
    // Request Wake Lock to prevent screen sleep during processing
    let wakeLock: any = null;
    try {
      if ('wakeLock' in navigator) {
        wakeLock = await (navigator as any).wakeLock.request('screen');
      }
    } catch (err) {
      console.log('WakeLock not supported or denied');
    }

    // Eagerly read all files into memory
    let memoryFiles: File[] = [];
    try {
      memoryFiles = await Promise.all(validFiles.map(async f => {
        const buffer = await f.arrayBuffer();
        return new File([buffer], f.name, { type: f.type });
      }));
    } catch (err) {
      console.error('Failed to read files into memory:', err);
      setAlertMsg('ফাইল পড়তে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
      setIsAutoBulkActive(false);
      e.target.value = '';
      if (wakeLock) { wakeLock.release().catch(()=>{}); }
      return;
    }
    setAutoBulkProgress({
      current: 0,
      total: memoryFiles.length,
      title: 'শুরু হচ্ছে...',
      step: 'ফাইল প্রস্তুতি ও হাই-কোয়ালিটি অপটিমাইজেশন...'
    });
    
    let successCount = 0;
    const processedCards: Card[] = [];

    try {
      const { compressImage } = await import('../lib/imageUtils');

      for (let i = 0; i < memoryFiles.length; i++) {
        const file = memoryFiles[i];
        const defaultTitle = file.name.replace(/\\.[^/.]+$/, '').replace(/[-_]/g, ' ');

        setAutoBulkProgress({
          current: i + 1,
          total: memoryFiles.length,
          title: defaultTitle,
          step: 'ছবি ফিল্টারিং, কন্ট্রাস্ট ও রেজ্যুলুশন বাড়ানো হচ্ছে...'
        });

        // Step 1: Quality optimization and sharpness enhancement
        const enhancedBase64 = await compressImage(file, 800, 0.75, true);

        setAutoBulkProgress({
          current: i + 1,
          total: memoryFiles.length,
          title: defaultTitle,
          step: 'AI দ্বারা অটো নাম, একাডেমিক স্টাডি নোট ও মাস্ক তৈরি হচ্ছে...'
        });

        // Step 2: Single-call AI processing for Title, Notes, and Occlusion Masks
        let cardTitle = defaultTitle;
        let cardNotes = '';
        let detectedMasks: Rectangle[] = [];

        try {
          const response = await fetch('/api/auto-process-diagram', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ imageBase64: enhancedBase64 })
          });

          if (response.ok) {
            const result = await response.json();
            if (result.title && result.title.trim()) {
              cardTitle = result.title.trim();
            }
            if (result.notes && result.notes.trim()) {
              cardNotes = result.notes.trim();
            }
            if (Array.isArray(result.boxes) && result.boxes.length > 0) {
              detectedMasks = result.boxes.map((b: any, bIdx: number) => {
                const padX = 2;
                const padY = 2;
                const clampedXmin = Math.max(0, b.xmin - padX);
                const clampedYmin = Math.max(0, b.ymin - padY);
                const clampedXmax = Math.min(1000, b.xmax + padX);
                const clampedYmax = Math.min(1000, b.ymax + padY);

                return {
                  id: Date.now() + i * 10000 + bIdx,
                  x: 0,
                  y: 0,
                  width: 0,
                  height: 0,
                  xPercent: (clampedXmin / 1000) * 100,
                  yPercent: (clampedYmin / 1000) * 100,
                  widthPercent: ((clampedXmax - clampedXmin) / 1000) * 100,
                  heightPercent: ((clampedYmax - clampedYmin) / 1000) * 100,
                  label: b.text || '',
                  badgePosition: 'auto'
                };
              });
            }
          }
        } catch (aiErr) {
          console.warn('Auto AI processing error for card', i, aiErr);
        }

        const now = Date.now() + i;
        const newCard: Card = {
          id: now,
          title: cardTitle,
          notes: cardNotes,
          image: enhancedBase64,
          rectangles: detectedMasks,
          pins: [],
          tags: tags.length > 0 ? [...tags] : [],
          folderId: folderId || undefined,
          createdAt: now,
          updatedAt: now,
          badgePosition: 'auto',
          badgeDistance: 'far'
        };

        // SAVE IMMEDIATELY to prevent data loss on app switch/OOM
        if (onBulkCreate) {
          await Promise.resolve(onBulkCreate([newCard]));
        } else {
          onSave(newCard);
        }
        successCount++;
        
        // Push lightweight version to memory for summary (empty image to save RAM)
        processedCards.push({ ...newCard, image: '' });
        
        // Yield to main thread to prevent UI freezing
        await new Promise(r => setTimeout(r, 100));
      }

      setAutoBulkCompletedCards(processedCards);
      setShowAutoBulkSummary(true);
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate([20, 40, 20]); } catch (_) {}
      }
      
    } catch (err) {
      console.error('Auto bulk processing error:', err);
      setAlertMsg('বাল্ক প্রসেসিংয়ে সমস্যা হয়েছে।');
    } finally {
      setIsAutoBulkActive(false);
      e.target.value = '';
      if (wakeLock) { wakeLock.release().catch(()=>{}); }
    }
  };

  const handleSaveAllAutoBulkCards = () => {`);
    fs.writeFileSync('src/components/CreateCard.tsx', code);
    console.log("Patched successfully");
} else {
    console.log("Could not find regex match");
}

const targetSummaryBtn = `<button
                type="button"
                onClick={handleSaveAllAutoBulkCards}
                className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold rounded-2xl flex items-center justify-center gap-3 transition-colors shrink-0"
              >
                <Save className="w-5 h-5" />
                সবগুলো সেভ করুন ({autoBulkCompletedCards.length})
              </button>`;

const replacementSummaryBtn = `<button
                type="button"
                onClick={() => {
                  setShowAutoBulkSummary(false);
                  onCancel();
                }}
                className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold rounded-2xl flex items-center justify-center gap-3 transition-colors shrink-0"
              >
                <CheckCircle2 className="w-5 h-5" />
                ঠিক আছে (সেভ সম্পন্ন)
              </button>`;

if (code.includes(targetSummaryBtn)) {
    code = code.replace(targetSummaryBtn, replacementSummaryBtn);
    fs.writeFileSync('src/components/CreateCard.tsx', code);
    console.log('Fixed Summary Button');
} else {
    console.log('Summary button not found');
}
