const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

code = code.replace(
  `CheckCircle2, Hash`,
  `CheckCircle2, Hash, Image`
);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed icon import');
