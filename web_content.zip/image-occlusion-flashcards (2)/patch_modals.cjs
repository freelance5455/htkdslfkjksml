const fs = require('fs');

function fixModals(file) {
    let code = fs.readFileSync(file, 'utf8');
    
    // Fix Folder modal
    code = code.replace(
        /className="bg-white rounded-xl p-6 max-w-sm w-full shadow-xl"/g,
        'className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl"'
    );
    
    // Fix Rename modal
    code = code.replace(
        /className="bg-white rounded-xl p-6 max-w-sm w-full shadow-xl"/g,
        'className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl"'
    );

    // Fix heading text
    code = code.replace(
        /<h3 className="text-lg font-bold mb-4">/g,
        '<h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-gray-100">'
    );

    // Fix Input styling
    code = code.replace(
        /className="w-full border border-gray-300 rounded-lg p-3 mb-6 focus:outline-none focus:ring-2 focus:ring-blue-500"/g,
        'className="w-full border border-gray-300 dark:border-slate-600 rounded-lg p-3 mb-6 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-gray-900 dark:text-gray-100"'
    );
    
    // Fix Cancel buttons
    code = code.replace(
        /className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg font-medium"/g,
        'className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-2 rounded-lg font-medium hover:bg-gray-200 dark:hover:bg-slate-600 transition-colors"'
    );
    
    fs.writeFileSync(file, code);
}

fixModals('src/components/Dashboard.tsx');
fixModals('src/components/FolderView.tsx');

console.log('patched modals');
