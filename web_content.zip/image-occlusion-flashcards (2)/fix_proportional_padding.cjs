const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

// Location 1
const loc1 = `              detectedMasks = result.boxes.map((b: any, bIdx: number) => {
                const padX = 25;
                const padY = 35;
                const clampedXmin = Math.max(0, b.xmin - padX);
                const clampedYmin = Math.max(0, b.ymin - padY);
                const clampedXmax = Math.min(1000, b.xmax + padX);
                const clampedYmax = Math.min(1000, b.ymax + padY);`;

const rep1 = `              detectedMasks = result.boxes.map((b: any, bIdx: number) => {
                const w = b.xmax - b.xmin;
                const h = b.ymax - b.ymin;
                const padX = w * 0.06; // 6% of its own width
                const padY = h * 0.15; // 15% of its own height for diacritics
                const clampedXmin = Math.max(0, b.xmin - padX);
                const clampedYmin = Math.max(0, b.ymin - padY);
                const clampedXmax = Math.min(1000, b.xmax + padX);
                const clampedYmax = Math.min(1000, b.ymax + padY);`;

code = code.replace(loc1, rep1);

// Location 2
const loc2 = `              const newRects: Rectangle[] = boxes.map((b: any, bIdx: number) => {
                const padX = 25;
                const padY = 35;
                const xmin = Math.max(0, b.xmin - padX);
                const xmax = Math.min(1000, b.xmax + padX);
                const ymin = Math.max(0, b.ymin - padY);
                const ymax = Math.min(1000, b.ymax + padY);`;

const rep2 = `              const newRects: Rectangle[] = boxes.map((b: any, bIdx: number) => {
                const w = b.xmax - b.xmin;
                const h = b.ymax - b.ymin;
                const padX = w * 0.06;
                const padY = h * 0.15;
                const xmin = Math.max(0, b.xmin - padX);
                const xmax = Math.min(1000, b.xmax + padX);
                const ymin = Math.max(0, b.ymin - padY);
                const ymax = Math.min(1000, b.ymax + padY);`;

code = code.replace(loc2, rep2);

// Location 3
const loc3 = `        const newRects: Rectangle[] = mergedBoxes.map((box, idx) => {
          // Add generous padding to fully cover the Bengali and English text including diacritics
          const padX = 25;
          const padY = 35;
          const xmin = Math.max(0, box.xmin - padX);
          const xmax = Math.min(1000, box.xmax + padX);
          const ymin = Math.max(0, box.ymin - padY);
          const ymax = Math.min(1000, box.ymax + padY);`;

const rep3 = `        const newRects: Rectangle[] = mergedBoxes.map((box, idx) => {
          // Add smart proportional padding based on the word's own size
          const w = box.xmax - box.xmin;
          const h = box.ymax - box.ymin;
          const padX = w * 0.06;
          const padY = h * 0.15;
          const xmin = Math.max(0, box.xmin - padX);
          const xmax = Math.min(1000, box.xmax + padX);
          const ymin = Math.max(0, box.ymin - padY);
          const ymax = Math.min(1000, box.ymax + padY);`;

code = code.replace(loc3, rep3);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed proportional padding');
