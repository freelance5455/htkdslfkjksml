const fs = require('fs');
let code = fs.readFileSync('src/components/FolderView.tsx', 'utf8');

code = code.replace(
  /<h3 className="font-semibold text-gray-800 truncate">\{subfolder\.name\}<\/h3>/g,
  '<h3 className="font-semibold text-gray-800 dark:text-gray-100 truncate">{subfolder.name}</h3>'
);

code = code.replace(
  /<h3 className="font-semibold text-gray-800 truncate">\{card\.title\}<\/h3>/g,
  '<h3 className="font-semibold text-gray-800 dark:text-gray-100 truncate">{card.title}</h3>'
);

// Check if bulk cards have titles
code = code.replace(
  /title: file.name.split\('\.'\)\[0\] \|\| 'UnTitled',/g,
  "title: file.name.split('.')[0] || 'Untitled',"
)

fs.writeFileSync('src/components/FolderView.tsx', code);
console.log('patched folderview text colors');
