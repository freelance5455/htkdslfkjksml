const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const targetReviewBtn = `<button
                type="button"
                onClick={handleReviewAutoBulkCards}
                className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm border border-slate-700 transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Eye className="w-4 h-4" />
                <span>🔍 কার্ডগুলো রিভিউ ও এডিট করুন</span>
              </button>`;

if (code.includes(targetReviewBtn)) {
  code = code.replace(targetReviewBtn, '');
  fs.writeFileSync('src/components/CreateCard.tsx', code);
  console.log('Removed review btn');
} else {
  console.log('Review btn not found');
}
