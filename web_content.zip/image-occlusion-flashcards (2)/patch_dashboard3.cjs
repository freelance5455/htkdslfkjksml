const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

const modalBlock = `      {/* Delete Confirm Modal */}`;
const bulkModalBlock = `      {/* Bulk Upload Choice Modal */}
      {bulkPendingCards.length > 0 && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-2xl animate-in fade-in zoom-in-95">
            <h3 className="text-xl font-bold mb-4 dark:text-white text-center">অনেকগুলো ছবি সিলেক্ট করেছেন</h3>
            <p className="text-slate-600 dark:text-slate-300 mb-6 text-center">
              আপনি কি ছবিগুলো একবারে সরাসরি সেভ করতে চান, নাকি একে একে এডিট করে (নাম, মাস্ক দিয়ে) সেভ করতে চান?
            </p>
            <div className="flex flex-col gap-3">
              <button
                onClick={() => {
                  if (onStartBulkEdit) onStartBulkEdit(bulkPendingCards);
                  setBulkPendingCards([]);
                }}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold transition-colors"
              >
                একে একে এডিট করুন (প্রস্তাবিত)
              </button>
              <button
                onClick={() => {
                  if (onBulkCreate) onBulkCreate(bulkPendingCards);
                  setAlertMsg(\`\${bulkPendingCards.length} টি কার্ড সফলভাবে তৈরি হয়েছে!\`);
                  setBulkPendingCards([]);
                }}
                className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold transition-colors"
              >
                সব একসাথে সেভ করুন
              </button>
              <button
                onClick={() => setBulkPendingCards([])}
                className="w-full py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-white rounded-lg font-bold transition-colors mt-2"
              >
                বাতিল করুন
              </button>
            </div>
          </div>
        </div>
      )}
`;

if (!code.includes('Bulk Upload Choice Modal')) {
  code = code.replace(modalBlock, bulkModalBlock + "\n" + modalBlock);
  fs.writeFileSync('src/components/Dashboard.tsx', code);
  console.log("Bulk modal added");
}
