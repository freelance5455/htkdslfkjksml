const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetDetect = `STRICT PRECISION RULES FOR ACCURATE BOUNDING BOXES:
1. TEXT-ONLY BOUNDING: Your bounding box MUST ONLY cover the physical letters of the word.
2. EXCLUDE POINTER LINES: If a straight black line points to the word, DO NOT include ANY part of the line in the box. 
3. WARNING ON BENGALI TEXT WIDTH: You MUST significantly extend the 'xmax' value to the right to cover the ENTIRE length of the Bengali word. You often cut off Bengali words halfway (e.g., you might mask "ক্লা" instead of "ক্ল্যাভিকল"). Ensure 'xmax' is large enough to cover the very last letter of the text!
4. FULL GLYPH COVERAGE: Ensure the box covers all Bengali diacritic vowel marks (e.g., ি, ী, ু, ূ, ে, ো).
5. All 4 values must be integers between 0 and 1000.`;

const newDetect = `STRICT PRECISION RULES FOR ACCURATE BOUNDING BOXES (BENGALI OCR INSTRUCTIONS):
1. ছবির মধ্যে থাকা নির্দিষ্ট শব্দ বা লেখাটি OCR ব্যবহার করে সঠিকভাবে শনাক্ত করো। শুধু সেই শব্দের দৃশ্যমান অক্ষরগুলোর ওপর নিখুঁতভাবে Mask (box_2d) বসাও।
2. অক্ষরের আসল আকৃতি, বাংলা বর্ণ, কারচিহ্ন, ফলা, যুক্তাক্ষর, মাত্রা, দাঁড়ি ও প্রয়োজনীয় চিহ্নসহ পুরো শব্দটি Mask-এর মধ্যে থাকবে।
3. Mask যেন অক্ষরের বাইরে অপ্রয়োজনীয় জায়গায় না যায়। শব্দের আশপাশের অন্য লেখা, লাইন, তীরচিহ্ন, ছবি, টেবিল, দাগ বা ব্যাকগ্রাউন্ড Mask করবে না। Mask খুব টাইট হবে এবং অক্ষরের কিনারা অনুসরণ করবে।
4. Mask-এর চারপাশে অতিরিক্ত ফাঁকা জায়গা রাখবে না। Padding সর্বোচ্চ ১ থেকে ২ পিক্সেল হবে।
5. লেখাটি ছোট, ঝাপসা, বাঁকা বা কম রেজোলিউশনের হলেও শব্দটি যাচাই করে যথাসম্ভব নির্ভুলভাবে Mask দাও।
6. All 4 values (ymin, xmin, ymax, xmax) must be integers between 0 and 1000.`;

code = code.replace(targetDetect, newDetect);

const targetDiagram = `BOUNDING BOX RULES:
- EXCLUSION RULE: STRICTLY ONLY mask the specific short names/labels being pointed to by diagram lines. Under NO circumstances should you output bounding boxes for general paragraph texts, descriptions, entire figure captions (e.g., "চিত্র..."), or stray marker letters ("ক", "খ").
- TIGHT BOUNDING: The box MUST cover the physical letters of the biological name or anatomical term.
- WARNING ON BENGALI TEXT WIDTH: You MUST significantly extend the 'xmax' value to the right to cover the entire length of the Bengali word. You often cut off Bengali words halfway. Ensure 'xmax' is large enough to cover the very last letter of the text!
- EXCLUDE POINTERS: Do NOT cover the pointer lines.
- FULL COVERAGE: Cover all Bengali diacritics (কার, ফলা, মাত্রা, রেফ, অনুস্বার, চন্দ্রবিন্দু).
- ZERO OVERLAP: One clean box per distinct anatomical label.`;

const newDiagram = `BOUNDING BOX RULES (BENGALI OCR INSTRUCTIONS):
- EXCLUSION RULE: STRICTLY ONLY mask the specific short names/labels being pointed to by diagram lines. Under NO circumstances should you output bounding boxes for general paragraph texts, descriptions, entire figure captions (e.g., "চিত্র..."), or stray marker letters ("ক", "খ").
- ছবির মধ্যে থাকা নির্দিষ্ট শব্দ বা লেখাটি OCR ব্যবহার করে সঠিকভাবে শনাক্ত করো। শুধু সেই শব্দের দৃশ্যমান অক্ষরগুলোর ওপর নিখুঁতভাবে Mask (box_2d) বসাও।
- অক্ষরের আসল আকৃতি, বাংলা বর্ণ, কারচিহ্ন, ফলা, যুক্তাক্ষর, মাত্রা, দাঁড়ি ও প্রয়োজনীয় চিহ্নসহ পুরো শব্দটি Mask-এর মধ্যে থাকবে।
- Mask যেন অক্ষরের বাইরে অপ্রয়োজনীয় জায়গায় না যায়। শব্দের আশপাশের অন্য লেখা, লাইন, তীরচিহ্ন, ছবি, টেবিল, দাগ বা ব্যাকগ্রাউন্ড Mask করবে না। Mask খুব টাইট হবে এবং অক্ষরের কিনারা অনুসরণ করবে।
- Mask-এর চারপাশে অতিরিক্ত ফাঁকা জায়গা রাখবে না। Padding সর্বোচ্চ ১ থেকে ২ পিক্সেল হবে।
- লেখাটি ছোট, ঝাপসা, বাঁকা বা কম রেজোলিউশনের হলেও শব্দটি যাচাই করে যথাসম্ভব নির্ভুলভাবে Mask দাও।
- ZERO OVERLAP: One clean box per distinct anatomical label.`;

code = code.replace(targetDiagram, newDiagram);

fs.writeFileSync('server.ts', code);
console.log('Fixed prompts');
