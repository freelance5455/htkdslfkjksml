const fs = require('fs');
let code = fs.readFileSync('src/components/FolderView.tsx', 'utf8');
code = code.replace("import React, { useState } from 'react';", "import React, { useState, useRef } from 'react';");
fs.writeFileSync('src/components/FolderView.tsx', code);
