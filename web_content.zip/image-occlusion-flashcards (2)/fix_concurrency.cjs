const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

// Replace handleBatchAiDetectAll loop
const batchTarget = `    let successCount = 0;
    for (let i = 0; i < batchCopy.length; i++) {
      const item = batchCopy[i];
      if (item.rectangles.length > 0 && item.isAiProcessed) {
        continue; // Already processed
      }

      setAlertMsg(\`AI প্রসেসিং চলছে: ছবি \${i + 1}/\${batchCopy.length} ("\${item.title}")...\`);
      try {
        const optimized = await prepareImageForAI(item.image);
        const res = await fetch('/api/detect-text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: optimized,
            mode: 'labels'
          })
        });

        if (res.ok) {
          const data = await res.json();
      const boxes = data.boxes || [];
          if (boxes.length > 0) {
            const newRects: Rectangle[] = boxes.map((b: any, bIdx: number) => {
              // Visual snapping mechanism for occlusion masks
              // Coordinate offset logic to align strictly to text labels 
              // and avoid indicator lines.
              const originalW = b.xmax - b.xmin;
              const originalH = b.ymax - b.ymin;

              // 1. Center alignment: Find the absolute center of the detected bounding box.
              const centerX = b.xmin + (originalW / 2);
              const centerY = b.ymin + (originalH / 2);

              // 2. Vertical Snapping: Shrink vertically by 15% to strictly avoid top/bottom pointer lines
              // and ensure the mask is sleek. Max height clamped to avoid diagonal pointer lines.
              const snappedH = Math.min(originalH * 0.85, 45);

              // 3. Horizontal Offset & Expansion: Expand slightly to cover full text width,
              // but ensure it stays centered to avoid sideway lines.
              const snappedW = originalW + (originalW * 0.04);

              // 4. Calculate final bounds based on snapped offsets
              const xmin = Math.max(0, centerX - (snappedW / 2));
              const xmax = Math.min(1000, centerX + (snappedW / 2));
              const ymin = Math.max(0, centerY - (snappedH / 2));
              const ymax = Math.min(1000, centerY + (snappedH / 2));

              const xPercent = (xmin / 1000) * 100;
              const yPercent = (ymin / 1000) * 100;
              const widthPercent = ((xmax - xmin) / 1000) * 100;
              const heightPercent = ((ymax - ymin) / 1000) * 100;
              return {
                id: Date.now() + i * 1000 + bIdx,
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                xPercent,
                yPercent,
                widthPercent,
                heightPercent,
                label: b.text || '',
                badgePosition: (b.xmin + b.xmax) / 2 >= 500 ? 'right' : 'left'
              };
            });
            batchCopy[i].rectangles = newRects;
            batchCopy[i].isAiProcessed = true;
            successCount++;
          }
        }
      } catch (err) {
        console.error(\`Error processing batch item \${i}:\`, err);
      }
    }`;

const batchReplacement = `    let successCount = 0;
    // Process concurrently in chunks of 3 to avoid rate limits
    const chunkSize = 3;
    let completedCount = 0;

    for (let i = 0; i < batchCopy.length; i += chunkSize) {
      const chunk = batchCopy.slice(i, i + chunkSize);
      await Promise.all(chunk.map(async (item, chunkIdx) => {
        const actualIdx = i + chunkIdx;
        if (item.rectangles.length > 0 && item.isAiProcessed) {
          completedCount++;
          setAlertMsg(\`AI প্রসেসিং চলছে: ছবি \${completedCount}/\${batchCopy.length}...\`);
          return;
        }

        try {
          const optimized = await prepareImageForAI(item.image);
          const res = await fetch('/api/detect-text', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              imageBase64: optimized,
              mode: 'labels'
            })
          });

          if (res.ok) {
            const data = await res.json();
            const boxes = data.boxes || [];
            if (boxes.length > 0) {
              const newRects: Rectangle[] = boxes.map((b: any, bIdx: number) => {
                const originalW = b.xmax - b.xmin;
                const originalH = b.ymax - b.ymin;
                const centerX = b.xmin + (originalW / 2);
                const centerY = b.ymin + (originalH / 2);
                const snappedH = Math.min(originalH * 0.85, 45);
                const snappedW = originalW + (originalW * 0.04);
                const xmin = Math.max(0, centerX - (snappedW / 2));
                const xmax = Math.min(1000, centerX + (snappedW / 2));
                const ymin = Math.max(0, centerY - (snappedH / 2));
                const ymax = Math.min(1000, centerY + (snappedH / 2));

                const xPercent = (xmin / 1000) * 100;
                const yPercent = (ymin / 1000) * 100;
                const widthPercent = ((xmax - xmin) / 1000) * 100;
                const heightPercent = ((ymax - ymin) / 1000) * 100;
                return {
                  id: Date.now() + actualIdx * 1000 + bIdx,
                  x: 0, y: 0, width: 0, height: 0,
                  xPercent, yPercent, widthPercent, heightPercent,
                  label: b.text || '',
                  badgePosition: (b.xmin + b.xmax) / 2 >= 500 ? 'right' : 'left'
                };
              });
              
              // To avoid mutating state directly, we create a new object
              batchCopy[actualIdx] = {
                ...batchCopy[actualIdx],
                rectangles: newRects,
                isAiProcessed: true
              };
              successCount++;
            }
          }
        } catch (err) {
          console.error(\`Error processing batch item \${actualIdx}:\`, err);
        } finally {
          completedCount++;
          setAlertMsg(\`AI প্রসেসিং চলছে: ছবি \${completedCount}/\${batchCopy.length}...\`);
        }
      }));
    }`;

code = code.replace(batchTarget, batchReplacement);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Done');
