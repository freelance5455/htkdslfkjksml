const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

code = code.replace(
  "onBulkCreate?: (cards: Card[]) => void;\n}",
  "onBulkCreate?: (cards: Card[]) => void;\n  onStartBulkEdit?: (cards: Card[]) => void;\n}"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log("Dashboard interface patched");
