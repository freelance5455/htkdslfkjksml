const fs = require('fs');
let code = fs.readFileSync('src/lib/imageUtils.ts', 'utf8');

code = code.replace(/try\s*\{\s*try\s*\{/g, 'try {');

fs.writeFileSync('src/lib/imageUtils.ts', code);
