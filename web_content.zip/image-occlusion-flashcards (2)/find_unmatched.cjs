const fs = require('fs');
const content = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const lines = content.split('\n').slice(1768, 2932);
const stack = [];

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  
  // A crude regex for JSX tags we care about: div, main, button, span
  const tagRegex = /<\/?(div|main|button|span)[^>]*>/g;
  let match;
  while ((match = tagRegex.exec(line)) !== null) {
    const tag = match[0];
    // filter out cases like <div ... />
    const isSelfClosing = tag.endsWith('/>');
    if (isSelfClosing) continue;

    const isClosing = tag.startsWith('</');
    const tagName = match[1];

    if (!isClosing) {
      stack.push({ tag: tagName, line: i + 1769 });
    } else {
      const last = stack.pop();
      if (!last || last.tag !== tagName) {
        console.log(`Mismatch at line ${i + 1769}: Found ${tag}, expected </${last ? last.tag : 'NONE'}> (opened at line ${last ? last.line : 'NONE'})`);
        process.exit(1);
      }
    }
  }
}

if (stack.length > 0) {
  console.log('Unclosed tags:', stack);
} else {
  console.log('All tags balanced!');
}
