const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

code = code.replace(
  /          \}\)\}\n        <\/div>\n      <\/div>\n      <\/div>\n      <\/main>/,
  '          }\n        </div>\n      </main>'
);

fs.writeFileSync('src/components/CreateCard.tsx', code);
