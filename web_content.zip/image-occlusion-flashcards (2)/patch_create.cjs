const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

// Update Props interface
code = code.replace(
  "onCancel: () => void;\n}",
  "onCancel: () => void;\n  isBulkEdit?: boolean;\n  bulkRemaining?: number;\n}"
);

code = code.replace(
  "export default function CreateCard({ folderId, editingCard, onSave, onCancel }: CreateCardProps) {",
  "export default function CreateCard({ folderId, editingCard, onSave, onCancel, isBulkEdit, bulkRemaining }: CreateCardProps) {"
);

// Update Header
const oldHeaderTitle = `<h2 className="font-bold text-gray-800 dark:text-gray-100 text-lg truncate flex-1 text-center px-2">{editingCard ? 'কার্ড এডিট করুন' : 'নতুন কার্ড'}</h2>`;
const newHeaderTitle = `<h2 className="font-bold text-gray-800 dark:text-gray-100 text-lg truncate flex-1 text-center px-2">
          {isBulkEdit ? \`এডিট করুন (\${bulkRemaining} টি বাকি)\` : (editingCard ? 'কার্ড এডিট করুন' : 'নতুন কার্ড')}
        </h2>`;
code = code.replace(oldHeaderTitle, newHeaderTitle);

// Update Save Button
const oldSaveBtn = `<Save className="w-5 h-5 hidden sm:block" /> <span className="hidden sm:inline">সেভ</span><span className="sm:hidden">সেভ</span>`;
const newSaveBtn = `<Save className="w-5 h-5 hidden sm:block" /> <span className="hidden sm:inline">{isBulkEdit ? 'সেভ ও পরবর্তী' : 'সেভ'}</span><span className="sm:hidden">{isBulkEdit ? 'সেভ ও পরবর্তী' : 'সেভ'}</span>`;
code = code.replace(oldSaveBtn, newSaveBtn);

// Update Cancel Button (already has X icon, let's just add text if isBulkEdit)
const oldCancelBtn = `<button onClick={onCancel} className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 rounded-full transition-colors">
          <X className="w-6 h-6" />
        </button>`;
const newCancelBtn = `<button onClick={onCancel} className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1 font-medium">
          {isBulkEdit ? <span className="text-sm">স্কিপ</span> : <X className="w-6 h-6" />}
        </button>`;
code = code.replace(oldCancelBtn, newCancelBtn);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log("CreateCard patched");
