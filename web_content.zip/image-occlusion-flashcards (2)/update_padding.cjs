const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const t1 = `                const w = b.xmax - b.xmin;
                const h = b.ymax - b.ymin;
                const padX = 5;
                const padY = 6;`;

const r1 = `                const w = b.xmax - b.xmin;
                const h = b.ymax - b.ymin;
                // Dynamically calculate 4-6 pixel equivalent padding based on height for Bengali matra/kar-chinhas
                const isBengali = /[\\u0980-\\u09FF]/.test(b.text || '');
                const padX = Math.min(6, Math.max(4, w * 0.05));
                const padY = isBengali ? Math.min(8, Math.max(5, h * 0.12)) : Math.min(6, Math.max(4, h * 0.08));`;

code = code.replace(t1, r1);
code = code.replace(t1, r1); // Because there are two blocks with exactly this (loc 1 and loc 2)

const t3 = `          const w = box.xmax - box.xmin;
          const h = box.ymax - box.ymin;
          const padX = 5;
                const padY = 6;`;

const r3 = `          const w = box.xmax - box.xmin;
          const h = box.ymax - box.ymin;
          const isBengali = /[\\u0980-\\u09FF]/.test(box.text || '');
          const padX = Math.min(6, Math.max(4, w * 0.05));
          const padY = isBengali ? Math.min(8, Math.max(5, h * 0.12)) : Math.min(6, Math.max(4, h * 0.08));`;

code = code.replace(t3, r3);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Padding updated dynamically');
