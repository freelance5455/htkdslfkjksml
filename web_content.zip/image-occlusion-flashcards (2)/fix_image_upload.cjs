const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const target = `  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawFiles: File[] = Array.from(e.target.files || []);
    const validFiles = rawFiles.filter(f => f.type.match('image.*'));
    if (memoryFiles.length === 0) {
      if (rawFiles.length > 0) {
        setAlertMsg('দয়া করে শুধুমাত্র সাধারণ ছবি (JPG, PNG) আপলোড করুন।');
      }
      return;
    }

    setIsProcessing(true);
    try {
      const { compressImage } = await import('../lib/imageUtils');
      
      if (memoryFiles.length === 1 && imageBatch.length === 0) {
        // Standard single-file upload
        const file = validFiles[0];`;

const replacement = `  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawFiles: File[] = Array.from(e.target.files || []);
    const validFiles = rawFiles.filter(f => f.type.match('image.*'));
    if (validFiles.length === 0) {
      if (rawFiles.length > 0) {
        setAlertMsg('দয়া করে শুধুমাত্র সাধারণ ছবি (JPG, PNG) আপলোড করুন।');
      }
      return;
    }

    setIsProcessing(true);

    let memoryFiles: File[] = [];
    try {
      memoryFiles = await Promise.all(validFiles.map(async f => {
        const buffer = await f.arrayBuffer();
        return new File([buffer], f.name, { type: f.type });
      }));
    } catch (err) {
      console.error('Failed to read files into memory:', err);
      setAlertMsg('ফাইল পড়তে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
      setIsProcessing(false);
      e.target.value = '';
      return;
    }

    try {
      const { compressImage } = await import('../lib/imageUtils');
      
      if (memoryFiles.length === 1 && imageBatch.length === 0) {
        // Standard single-file upload
        const file = memoryFiles[0];`;

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/components/CreateCard.tsx', code);
  console.log('Fixed handleImageUpload');
} else {
  console.log('Target not found for handleImageUpload');
}
