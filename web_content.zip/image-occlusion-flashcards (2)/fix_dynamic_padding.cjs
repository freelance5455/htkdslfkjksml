const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const target1 = `                const isBengali = /[\\u0980-\\u09FF]/.test(b.text || '');
                const padX = Math.min(6, Math.max(4, w * 0.05));
                const padY = isBengali ? Math.min(8, Math.max(5, h * 0.12)) : Math.min(6, Math.max(4, h * 0.08));`;

const replace1 = `                const isBengali = /[\\u0980-\\u09FF]/.test(b.text || '');
                // Heavily increase padding for Bengali to ensure all ascenders (matra, ref) and descenders (kar-chinh) are fully masked.
                // It dynamically scales with the height but guarantees a larger absolute minimum padding.
                const padX = Math.min(12, Math.max(8, w * 0.08));
                const padY = isBengali ? Math.min(18, Math.max(12, h * 0.25)) : Math.min(10, Math.max(6, h * 0.10));`;

code = code.replace(target1, replace1);
code = code.replace(target1, replace1); // For the second match


const target2 = `          const isBengali = /[\\u0980-\\u09FF]/.test(box.text || '');
          const padX = Math.min(6, Math.max(4, w * 0.05));
          const padY = isBengali ? Math.min(8, Math.max(5, h * 0.12)) : Math.min(6, Math.max(4, h * 0.08));`;

const replace2 = `          const isBengali = /[\\u0980-\\u09FF]/.test(box.text || '');
          const padX = Math.min(12, Math.max(8, w * 0.08));
          const padY = isBengali ? Math.min(18, Math.max(12, h * 0.25)) : Math.min(10, Math.max(6, h * 0.10));`;

code = code.replace(target2, replace2);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed dynamic padding for Bengali');
