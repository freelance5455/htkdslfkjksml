const fs = require('fs');
let code = fs.readFileSync('src/components/QuizMode.tsx', 'utf8');

// Add showNotes state
code = code.replace(
  "const [activeItemId, setActiveItemId] = useState<string | null>(null);",
  "const [activeItemId, setActiveItemId] = useState<string | null>(null);\n  const [showNotes, setShowNotes] = useState(false);"
);

// Reset showNotes on next card
code = code.replace(
  "setActiveItemId(null);",
  "setActiveItemId(null);\n    setShowNotes(false);"
);

// Replace notes display
const notesBlockOld = `{card.notes && (
          <div className="mt-4 w-full max-w-md bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-slate-200 shrink-0 shadow-lg text-left">
            <h3 className="font-bold text-sm mb-1 text-slate-400 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" /> নোট/ছন্দ:
            </h3>
            <p className="whitespace-pre-wrap">{card.notes}</p>
          </div>
        )}`;

const notesBlockNew = `{card.notes && (
          <div className="mt-4 w-full max-w-md bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-slate-200 shrink-0 shadow-lg text-left transition-all">
            <button 
              onClick={() => setShowNotes(!showNotes)}
              className="flex items-center justify-between w-full font-bold text-sm text-slate-400 hover:text-slate-200 transition-colors"
            >
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4" /> 
                <span>নোট/ছন্দ</span>
              </div>
              <span>{showNotes ? '▲ লুকান' : '▼ দেখুন'}</span>
            </button>
            {showNotes && (
              <p className="whitespace-pre-wrap mt-3 pt-3 border-t border-slate-700 text-sm animate-in fade-in slide-in-from-top-2">{card.notes}</p>
            )}
          </div>
        )}`;

code = code.replace(notesBlockOld, notesBlockNew);

fs.writeFileSync('src/components/QuizMode.tsx', code);
console.log("QuizMode updated successfully");
