const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const oldCancel = `          onCancel={() => {
            const nextQueue = bulkEditQueue.slice(1);
            if (nextQueue.length > 0) {
              setBulkEditQueue(nextQueue);
            } else {
              setView('dashboard');
            }
          }}`;

const newCancel = `          onSkip={() => {
            const nextQueue = bulkEditQueue.slice(1);
            if (nextQueue.length > 0) {
              setBulkEditQueue(nextQueue);
            } else {
              setView('dashboard');
            }
          }}
          onCancel={() => {
            setBulkEditQueue([]);
            setView('dashboard');
          }}`;

code = code.replace(oldCancel, newCancel);
fs.writeFileSync('src/App.tsx', code);
console.log("App patched for onSkip");
