const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const targetId = `      .map((item, idx) => ({
        id: Date.now() + idx + Math.floor(Math.random() * 1000),
        folderId: folderId || undefined,`;

const replacementId = `      .map((item, idx) => ({
        id: item.id.startsWith('batch-') 
             ? parseInt(item.id.replace('batch-', ''), 10) 
             : Date.now() + idx + Math.floor(Math.random() * 1000),
        folderId: folderId || undefined,`;

code = code.replace(targetId, replacementId);
fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed batch save id');
