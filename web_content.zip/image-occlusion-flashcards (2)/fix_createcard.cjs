const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const targetDetect = `              const originalW = b.xmax - b.xmin;
              const originalH = b.ymax - b.ymin;

              // 1. Center alignment: Find the absolute center of the detected bounding box.
              const centerX = b.xmin + (originalW / 2);
              const centerY = b.ymin + (originalH / 2);

              // 2. Vertical Snapping: Shrink vertically by 15% to strictly avoid top/bottom pointer lines
              // and ensure the mask is sleek. Max height clamped to avoid diagonal pointer lines.
              const snappedH = Math.min(originalH * 0.85, 45);

              // 3. Horizontal Offset & Expansion: Expand slightly to cover full text width,
              // but ensure it stays centered to avoid sideway lines.
              const snappedW = originalW + (originalW * 0.04);

              // 4. Calculate final bounds based on snapped offsets
              const xmin = Math.max(0, centerX - (snappedW / 2));
              const xmax = Math.min(1000, centerX + (snappedW / 2));
              const ymin = Math.max(0, centerY - (snappedH / 2));
              const ymax = Math.min(1000, centerY + (snappedH / 2));`;

const replacementDetect = `              // The server already calibrates width correctly for Bengali texts.
              // Apply a small universal padding for aesthetics.
              const padX = 2; // ~2% horizontal padding
              const padY = 2; // ~2% vertical padding
              
              const xmin = Math.max(0, b.xmin - padX);
              const xmax = Math.min(1000, b.xmax + padX);
              const ymin = Math.max(0, b.ymin - padY);
              const ymax = Math.min(1000, b.ymax + padY);`;

code = code.replace(targetDetect, replacementDetect);

const targetAuto = `                const xmin = b.xmin;
                const ymin = b.ymin;
                const xmax = b.xmax;
                const ymax = b.ymax;
                const padX = 3;
                const padY = 2;
                const clampedXmin = Math.max(0, xmin - padX);
                const clampedYmin = Math.max(0, ymin - padY);
                const clampedXmax = Math.min(1000, xmax + padX);
                const clampedYmax = Math.min(1000, ymax + padY);

                return {
                  id: Date.now() + actualIdx * 10000 + bIdx,
                  x: clampedXmin,
                  y: clampedYmin,
                  width: clampedXmax - clampedXmin,
                  height: clampedYmax - clampedYmin,
                  xPercent: (clampedXmin / 1000) * 100,
                  yPercent: (clampedYmin / 1000) * 100,
                  widthPercent: ((clampedXmax - clampedXmin) / 1000) * 100,
                  heightPercent: ((clampedYmax - clampedYmin) / 1000) * 100,
                  label: b.text || '',
                  badgePosition: 'auto'
                };`;

const replacementAuto = `                const padX = 2;
                const padY = 2;
                const clampedXmin = Math.max(0, b.xmin - padX);
                const clampedYmin = Math.max(0, b.ymin - padY);
                const clampedXmax = Math.min(1000, b.xmax + padX);
                const clampedYmax = Math.min(1000, b.ymax + padY);

                return {
                  id: Date.now() + actualIdx * 10000 + bIdx,
                  x: 0,
                  y: 0,
                  width: 0,
                  height: 0,
                  xPercent: (clampedXmin / 1000) * 100,
                  yPercent: (clampedYmin / 1000) * 100,
                  widthPercent: ((clampedXmax - clampedXmin) / 1000) * 100,
                  heightPercent: ((clampedYmax - clampedYmin) / 1000) * 100,
                  label: b.text || '',
                  badgePosition: 'auto'
                };`;

code = code.replace(targetAuto, replacementAuto);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed CreateCard.tsx snapping logic');
