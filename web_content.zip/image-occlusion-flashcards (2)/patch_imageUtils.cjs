const fs = require('fs');
let code = `import heic2any from 'heic2any';

export const compressImage = async (file: File, maxWidth = 1200, quality = 0.7): Promise<string> => {
  let fileToProcess: File | Blob = file;

  // Convert HEIC/HEIF to JPEG first
  if (file.type === 'image/heic' || file.type === 'image/heif' || file.name.toLowerCase().endsWith('.heic') || file.name.toLowerCase().endsWith('.heif')) {
    try {
      const convertedBlob = await heic2any({
        blob: file,
        toType: 'image/jpeg',
        quality: quality
      });
      // heic2any can return an array of blobs if the HEIC has multiple images
      const blob = Array.isArray(convertedBlob) ? convertedBlob[0] : convertedBlob;
      fileToProcess = blob;
    } catch (e) {
      console.error('HEIC conversion failed', e);
      throw new Error(\`Failed to convert HEIC image: \${file.name}\`);
    }
  }

  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(fileToProcess);
    
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      
      if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width);
        width = maxWidth;
      }
      
      canvas.width = width;
      canvas.height = height;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject(new Error('No canvas context'));
      
      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error(\`Failed to load image from file: \${file.name}\`));
    };
    
    img.src = objectUrl;
  });
};
`;

fs.writeFileSync('src/lib/imageUtils.ts', code);
console.log('imageUtils patched');
