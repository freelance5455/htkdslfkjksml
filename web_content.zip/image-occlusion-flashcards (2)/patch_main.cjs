const fs = require('fs');
let code = fs.readFileSync('src/main.tsx', 'utf8');

const injection = `
import { registerSW } from 'virtual:pwa-register';
if ('serviceWorker' in navigator) {
  registerSW({ immediate: true });
}
`;

if (!code.includes('virtual:pwa-register')) {
  code = injection + code;
  fs.writeFileSync('src/main.tsx', code);
  console.log('patched main.tsx for PWA');
}
