const fs = require('fs');
const ts = require('typescript');

const code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');
const sourceFile = ts.createSourceFile(
  'CreateCard.tsx',
  code,
  ts.ScriptTarget.Latest,
  true,
  ts.ScriptKind.TSX
);

function printErrors(node) {
  if (node.kind === ts.SyntaxKind.JsxElement || node.kind === ts.SyntaxKind.JsxSelfClosingElement || node.kind === ts.SyntaxKind.JsxFragment) {
     // Do nothing special, but recurse
  }
  ts.forEachChild(node, printErrors);
}
printErrors(sourceFile);
console.log("TS parse completed.");
