const fs = require('fs');

function fixWrapping(file) {
    let code = fs.readFileSync(file, 'utf8');

    // Remove truncate from flex-1 wrappers
    code = code.replace(/className="truncate flex-1/g, 'className="flex-1 min-w-0');

    // Replace truncate on h3 with line-clamp-2
    code = code.replace(/<h3 className="font-semibold text-gray-800 dark:text-gray-100 truncate">/g, '<h3 className="font-semibold text-gray-800 dark:text-gray-100 line-clamp-2 break-words">');

    // Just in case it didn't have dark mode yet
    code = code.replace(/<h3 className="font-semibold text-gray-800 truncate">/g, '<h3 className="font-semibold text-gray-800 dark:text-gray-100 line-clamp-2 break-words">');

    // Add dark mode to gray-500
    code = code.replace(/text-gray-500/g, 'text-gray-500 dark:text-gray-400');
    
    // Check for "UnTitled" and change to file name or something better
    code = code.replace(/file\.name\.split\('\.'\)\[0\] \|\| 'UnTitled'/g, "file.name.split('.')[0] || 'Untitled'");

    fs.writeFileSync(file, code);
}

fixWrapping('src/components/Dashboard.tsx');
fixWrapping('src/components/FolderView.tsx');

console.log('patched wrapping');
