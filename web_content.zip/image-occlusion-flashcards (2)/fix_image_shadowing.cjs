const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

// Fix import
code = code.replace(
  'Zap, CheckCircle2, Hash, Image',
  'Zap, CheckCircle2, Hash, Image as ImageIcon'
);

// Fix JSX usage
code = code.replace(
  '<Image className="w-5 h-5" />',
  '<ImageIcon className="w-5 h-5" />'
);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed Image shadowing');
