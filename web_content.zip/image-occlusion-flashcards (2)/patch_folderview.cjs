const fs = require('fs');
let code = fs.readFileSync('src/components/FolderView.tsx', 'utf8');

code = code.replace("const [search, setSearch] = useState('');", "const [search, setSearch] = useState('');\n  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);");

code = code.replace("className=\"max-w-4xl mx-auto pb-24 h-full flex flex-col relative\"", "className=\"max-w-4xl mx-auto pb-24 h-full flex flex-col relative\"\n      onClick={() => setActiveDropdown(null)}");

const oldFolderActions = `<div className="flex gap-2 shrink-0 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => { e.stopPropagation(); setMoveItemData({ id: subfolder.id, type: 'folder' }); }}
                      className="w-10 h-10 flex items-center justify-center bg-gray-50 text-gray-600 rounded-full active:bg-gray-200 hover:bg-gray-100 transition-colors"
                      title="ফোল্ডার মুভ করুন"
                    >
                      <FolderIcon className="w-5 h-5" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); setDeleteType('folder'); setDeleteConfirmId(subfolder.id); }}
                      className="w-10 h-10 flex items-center justify-center bg-red-50 text-red-500 rounded-full active:bg-red-200 hover:bg-red-100 transition-colors"
                      title="ফোল্ডার ডিলিট করুন"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>`;

const newFolderActions = `<div className="relative shrink-0 flex items-center">
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveDropdown(activeDropdown === \`folder-\${subfolder.id}\` ? null : \`folder-\${subfolder.id}\`); }}
                      className="w-10 h-10 flex items-center justify-center bg-gray-50 dark:bg-slate-700 text-gray-600 dark:text-gray-300 rounded-full hover:bg-gray-100 dark:hover:bg-slate-600 transition-colors"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </button>
                    {activeDropdown === \`folder-\${subfolder.id}\` && (
                      <div className="absolute right-0 top-12 w-40 bg-white dark:bg-slate-800 rounded-xl shadow-xl py-2 text-gray-800 dark:text-gray-200 z-50 border border-gray-100 dark:border-slate-700">
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setMoveItemData({ id: subfolder.id, type: 'folder' }); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <FolderIcon className="w-4 h-4" /> মুভ করুন
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setDeleteType('folder'); setDeleteConfirmId(subfolder.id); }} className="w-full px-4 py-2 text-left text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 flex items-center gap-2 font-medium">
                           <Trash2 className="w-4 h-4" /> ডিলিট করুন
                        </button>
                      </div>
                    )}
                  </div>`;

const oldCardActions = `<div className="flex gap-2 shrink-0">
                    <button
                      onClick={() => setMoveItemData({ id: card.id, type: 'card' })}
                      className="w-10 h-10 flex items-center justify-center bg-gray-50 text-gray-600 rounded-full active:bg-gray-200 hover:bg-gray-100 transition-colors"
                      title="কার্ড মুভ করুন"
                    >
                      <FolderIcon className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => onEdit(card.id)}
                      className="w-10 h-10 flex items-center justify-center bg-gray-50 text-gray-600 rounded-full active:bg-gray-200 hover:bg-gray-100 transition-colors"
                      title="কার্ড এডিট করুন"
                    >
                      <Edit3 className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => onStartStudy(originalIndex, false)}
                      className="w-10 h-10 flex items-center justify-center bg-blue-50 text-blue-600 rounded-full active:bg-blue-200 hover:bg-blue-100 transition-colors"
                    >
                      <BookOpen className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => { setDeleteType('card'); setDeleteConfirmId(card.id); }}
                      className="w-10 h-10 flex items-center justify-center bg-red-50 text-red-500 rounded-full active:bg-red-200 hover:bg-red-100 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>`;

const newCardActions = `<div className="relative shrink-0 flex items-center gap-1">
                    <button
                      onClick={(e) => { e.stopPropagation(); onStartStudy(originalIndex, false); }}
                      className="w-10 h-10 flex items-center justify-center bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full hover:bg-blue-100 dark:hover:bg-blue-800/40 transition-colors"
                      title="স্টাডি করুন"
                    >
                      <BookOpen className="w-5 h-5" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); setActiveDropdown(activeDropdown === \`card-\${card.id}\` ? null : \`card-\${card.id}\`); }}
                      className="w-10 h-10 flex items-center justify-center bg-gray-50 dark:bg-slate-700 text-gray-600 dark:text-gray-300 rounded-full hover:bg-gray-100 dark:hover:bg-slate-600 transition-colors"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </button>
                    {activeDropdown === \`card-\${card.id}\` && (
                      <div className="absolute right-0 top-12 w-40 bg-white dark:bg-slate-800 rounded-xl shadow-xl py-2 text-gray-800 dark:text-gray-200 z-50 border border-gray-100 dark:border-slate-700">
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); onEdit(card.id); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <Edit3 className="w-4 h-4" /> এডিট করুন
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setMoveItemData({ id: card.id, type: 'card' }); }} className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 font-medium">
                           <FolderIcon className="w-4 h-4" /> মুভ করুন
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdown(null); setDeleteType('card'); setDeleteConfirmId(card.id); }} className="w-full px-4 py-2 text-left text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 flex items-center gap-2 font-medium">
                           <Trash2 className="w-4 h-4" /> ডিলিট করুন
                        </button>
                      </div>
                    )}
                  </div>`;

if(code.includes(oldFolderActions)) {
    code = code.replace(oldFolderActions, newFolderActions);
} else { console.log('oldFolderActions not found'); }

if(code.includes(oldCardActions)) {
    code = code.replace(oldCardActions, newCardActions);
} else { console.log('oldCardActions not found'); }

fs.writeFileSync('src/components/FolderView.tsx', code);
console.log('patched FolderView');
