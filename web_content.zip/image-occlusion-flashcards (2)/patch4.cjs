// just to be 100% sure we also fix any other endpoints if they don't use generateContentWithFallback
