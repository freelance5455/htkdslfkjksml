const fs = require('fs');
let code = fs.readFileSync('src/components/FolderView.tsx', 'utf8');

// 1. Add imports
code = code.replace(
  "import { BookOpen, Trash2, Plus, Search, Shuffle, Edit3, ArrowLeft, Folder as FolderIcon } from 'lucide-react';",
  "import { BookOpen, Trash2, Plus, Search, Shuffle, Edit3, ArrowLeft, Folder as FolderIcon, MoreVertical, CheckSquare, X } from 'lucide-react';"
);

// 2. Add state & refs
const states = `
  const [showMenu, setShowMenu] = useState(false);
  const pressTimer = useRef<NodeJS.Timeout | null>(null);

  const startPress = (id: number, type: 'card'|'folder') => {
    if (isSelectionMode) return;
    pressTimer.current = setTimeout(() => {
      setIsSelectionMode(true);
      if (type === 'card') toggleSelectCard(id);
      else toggleSelectFolder(id);
    }, 500);
  };

  const cancelPress = () => {
    if (pressTimer.current) {
      clearTimeout(pressTimer.current);
      pressTimer.current = null;
    }
  };

  const selectAll = () => {
    setSelectedCards(filteredCards.map(c => c.id));
    setSelectedFolders(filteredFolders.map(f => f.id));
    setShowMenu(false);
  };
`;
code = code.replace(
  "const [isSelectionMode, setIsSelectionMode] = useState(false);",
  "const [isSelectionMode, setIsSelectionMode] = useState(false);\n" + states
);

// 3. Update Header
const oldHeader = `<header className="bg-blue-600 text-white p-4 shadow-md rounded-b-2xl mb-6 shrink-0 relative flex items-center">
        <button onClick={onBack} className="p-2 hover:bg-blue-500 rounded-full transition-colors mr-2">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="flex-1 pr-10 text-center">
          <h1 className="text-xl font-bold truncate">{folder.name}</h1>
          <p className="text-blue-100 text-sm mt-1">{folders.length} সাবফোল্ডার, {cards.length} কার্ড</p>
        </div>
      </header>`;

const newHeader = `{isSelectionMode ? (
        <header className="bg-blue-600 dark:bg-blue-800 text-white p-4 shadow-md rounded-b-2xl mb-6 shrink-0 flex items-center justify-between relative z-20">
          <div className="flex items-center gap-3">
            <button onClick={cancelSelection} className="p-2 hover:bg-blue-700 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <span className="text-xl font-bold">{selectedCards.length + selectedFolders.length} সিলেক্টেড</span>
          </div>
          <div className="relative">
            <button onClick={() => setShowMenu(!showMenu)} className="p-2 hover:bg-blue-700 rounded-full transition-colors">
              <MoreVertical className="w-6 h-6" />
            </button>
            {showMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl py-2 text-gray-800 dark:text-gray-200 z-50 border border-gray-100 dark:border-slate-700">
                <button onClick={selectAll} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left font-medium">
                  <CheckSquare className="w-5 h-5" /> সব সিলেক্ট করুন
                </button>
                <button onClick={() => {
                  setShowMenu(false);
                  if (selectedCards.length > 0 || selectedFolders.length > 0) setMoveItemData({ id: -1, type: 'card' });
                }} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left font-medium">
                  <FolderIcon className="w-5 h-5" /> মুভ করুন
                </button>
                <button onClick={() => {
                  setShowMenu(false);
                  if (selectedCards.length > 0 || selectedFolders.length > 0) {
                    setDeleteType('card');
                    setDeleteConfirmId(-1);
                  }
                }} className="w-full px-4 py-3 flex items-center gap-3 hover:bg-red-50 dark:hover:bg-red-900/30 text-red-500 transition-colors text-left font-medium">
                  <Trash2 className="w-5 h-5" /> ডিলিট করুন
                </button>
              </div>
            )}
          </div>
        </header>
      ) : (
        <header className="bg-blue-600 dark:bg-blue-800 text-white p-4 shadow-md rounded-b-2xl mb-6 shrink-0 relative flex items-center">
          <button onClick={onBack} className="p-2 hover:bg-blue-700 dark:hover:bg-blue-900 rounded-full transition-colors mr-2">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex-1 pr-10 text-center">
            <h1 className="text-xl font-bold truncate">{folder.name}</h1>
            <p className="text-blue-100 dark:text-blue-200 text-sm mt-1">{folders.length} সাবফোল্ডার, {cards.length} কার্ড</p>
          </div>
        </header>
      )}`;

code = code.replace(oldHeader, newHeader);

// 4. Update the mouse/touch events on folders and cards
const folderStart = `<div key={f.id} onClick={() => { if(isSelectionMode) toggleSelectFolder(f.id); else onOpenFolder(f.id); }} className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between cursor-pointer hover:shadow-md transition-shadow group">`;
const newFolderStart = `<div key={f.id} 
                  onClick={() => { if(isSelectionMode) toggleSelectFolder(f.id); else onOpenFolder(f.id); }} 
                  onPointerDown={(e) => {
                     if (e.button !== 0) return;
                     startPress(f.id, 'folder');
                  }}
                  onPointerUp={cancelPress}
                  onPointerLeave={cancelPress}
                  onPointerCancel={cancelPress}
                  onContextMenu={(e) => { }}
                  className={\`bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border flex items-center justify-between cursor-pointer hover:shadow-md transition-shadow group \${isSelectionMode && selectedFolders.includes(f.id) ? 'border-blue-500 bg-blue-50 dark:bg-slate-700' : 'border-gray-100'}\`}>`;
code = code.replace(folderStart, newFolderStart);

const cardStart = `<div key={card.id} className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between group" onClick={() => { if(isSelectionMode) toggleSelectCard(card.id); }}>`;
const newCardStart = `<div key={card.id} 
                  onClick={() => { if(isSelectionMode) toggleSelectCard(card.id); }}
                  onPointerDown={(e) => {
                     if (e.button !== 0) return;
                     startPress(card.id, 'card');
                  }}
                  onPointerUp={cancelPress}
                  onPointerLeave={cancelPress}
                  onPointerCancel={cancelPress}
                  className={\`bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border flex items-center justify-between group cursor-pointer \${isSelectionMode && selectedCards.includes(card.id) ? 'border-blue-500 bg-blue-50 dark:bg-slate-700' : 'border-gray-100'}\`}>`;
code = code.replace(cardStart, newCardStart);

fs.writeFileSync('src/components/FolderView.tsx', code);
