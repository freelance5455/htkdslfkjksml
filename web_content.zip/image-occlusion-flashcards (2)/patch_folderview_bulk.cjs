const fs = require('fs');
let code = fs.readFileSync('src/components/FolderView.tsx', 'utf8');

// 1. Add imports if needed (Upload is probably already imported, let's check)
if (!code.includes('Upload,')) {
    code = code.replace('import { BookOpen,', 'import { BookOpen, Upload,');
}

// 2. Add Props
code = code.replace(
    "onMoveItem?: (itemId: number, targetFolderId: number | null, itemType: 'card' | 'folder') => void;",
    "onMoveItem?: (itemId: number, targetFolderId: number | null, itemType: 'card' | 'folder') => void;\n  onBulkCreate?: (cards: Card[]) => void;\n  onStartBulkEdit?: (cards: Card[]) => void;"
);

// 3. Add to function signature
code = code.replace(
    "onCreateNew, onMoveItem }: FolderViewProps)",
    "onCreateNew, onMoveItem, onBulkCreate, onStartBulkEdit }: FolderViewProps)"
);

// 4. Add states and ref
const statesToAdd = `  const bulkFileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [bulkPendingCards, setBulkPendingCards] = useState<Card[]>([]);
  const [alertMsg, setAlertMsg] = useState('');
  
  const handleBulkUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;
    setIsUploading(true);
    const newCards: Card[] = [];
    let failedCount = 0;
    const { compressImage } = await import('../lib/imageUtils');
    
    for (const file of files) {
      if (!file.type.startsWith('image/') && !file.name.toLowerCase().endsWith('.heic') && !file.name.toLowerCase().endsWith('.heif')) {
        continue;
      }
      try {
         const compressedBase64 = await compressImage(file, 1200, 0.6);
         newCards.push({
            id: Date.now() + Math.random(),
            title: file.name.split('.')[0] || 'UnTitled',
            image: compressedBase64,
            rectangles: [],
            pins: [],
            createdAt: Date.now(),
            folderId: folder.id
         });
      } catch (err) { 
        console.error("Error compressing", err);
        failedCount++;
      }
    }
    
    if (newCards.length > 0) {
      setBulkPendingCards(newCards);
      if (failedCount > 0) {
        setAlertMsg(\`\${failedCount} টি ছবি আপলোড করতে সমস্যা হয়েছে।\`);
      }
    } else if (failedCount > 0) {
      setAlertMsg(\`\${failedCount} টি ছবি আপলোড করতে সমস্যা হয়েছে, সম্ভব হলে অন্য ছবি চেষ্টা করুন।\`);
    }
    setIsUploading(false);
    if (bulkFileInputRef.current) bulkFileInputRef.current.value = '';
  };
`;
code = code.replace("const [activeDropdown, setActiveDropdown] = useState<string | null>(null);", "const [activeDropdown, setActiveDropdown] = useState<string | null>(null);\n" + statesToAdd);

// 5. Add UI elements for bulk upload 
const fixedBottomBar = `<div className="fixed bottom-0 left-0 right-0 p-4 flex justify-center gap-4 bg-gradient-to-t from-gray-50 to-transparent pointer-events-none">`;
const fixedBottomBarNew = `<div className="fixed bottom-0 left-0 right-0 p-4 flex justify-center gap-4 bg-gradient-to-t from-gray-50 to-transparent pointer-events-none z-40">
        <button
          onClick={() => bulkFileInputRef.current?.click()}
          disabled={isUploading}
          title="একসাথে অনেক ছবি দিয়ে কার্ড বানান"
          className="pointer-events-auto flex items-center justify-center bg-green-500 hover:bg-green-600 text-white w-14 h-14 rounded-full shadow-lg active:scale-95 transition-transform disabled:opacity-50"
        >
          {isUploading ? <span className="animate-spin text-xl">⏳</span> : <Upload className="w-6 h-6" />}
        </button>`;
code = code.replace(fixedBottomBar, fixedBottomBarNew);

// 6. Add Modals for bulk upload confirmation and Alert
const modals = `      {/* Bulk Upload Confirmation Modal */}
      {bulkPendingCards.length > 0 && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl p-6 max-w-sm w-full shadow-xl">
            <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-gray-100">সফলভাবে প্রসেস হয়েছে</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">আপনি {bulkPendingCards.length} টি ছবি নির্বাচন করেছেন। এখন কি করবেন?</p>
            <div className="flex flex-col gap-3">
              <button 
                onClick={() => {
                   if (onBulkCreate) onBulkCreate(bulkPendingCards);
                   setBulkPendingCards([]);
                }} 
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-medium shadow-sm transition-colors"
              >
                সরাসরি সেভ করুন (পরে মাস্ক করবেন)
              </button>
              <button 
                onClick={() => {
                   if (onStartBulkEdit) onStartBulkEdit(bulkPendingCards);
                   setBulkPendingCards([]);
                }} 
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-medium shadow-sm transition-colors"
              >
                এখনি মাস্ক তৈরি করুন (একটার পর একটা)
              </button>
              <button 
                onClick={() => setBulkPendingCards([])} 
                className="w-full bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200 py-3 rounded-lg font-medium transition-colors mt-2"
              >
                বাতিল করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Global Alert */}
      {alertMsg && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 bg-red-500 text-white px-6 py-3 rounded-xl shadow-lg z-50 flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
          <span>{alertMsg}</span>
          <button onClick={() => setAlertMsg('')} className="p-1 hover:bg-red-600 rounded-full"><X className="w-4 h-4" /></button>
        </div>
      )}
      
      <input type="file" ref={bulkFileInputRef} onChange={handleBulkUpload} accept="image/*" multiple className="hidden" />
`;

code = code.replace("{/* Create Folder Modal */}", modals + "\n      {/* Create Folder Modal */}");

fs.writeFileSync('src/components/FolderView.tsx', code);
console.log('patched folderview with bulk upload');
