const fs = require('fs');
let code = fs.readFileSync('src/components/FolderView.tsx', 'utf8');

const oldSubfolderInner = `<div className="flex items-center gap-4 overflow-hidden w-full pr-2 pointer-events-none">`;
const newSubfolderInner = `<div className="flex items-center gap-4 overflow-hidden w-full pr-2">
                    {isSelectionMode && (
                      <input type="checkbox" checked={selectedFolders.includes(subfolder.id)} onChange={() => toggleSelectFolder(subfolder.id)} className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500" onClick={e => e.stopPropagation()} />
                    )}
`;

const oldCardInner = `<div className="flex items-center gap-3 overflow-hidden w-full pr-2 pointer-events-none">`;
const newCardInner = `<div className="flex items-center gap-3 overflow-hidden w-full pr-2">
                    {isSelectionMode && (
                      <input type="checkbox" checked={selectedCards.includes(card.id)} onChange={() => toggleSelectCard(card.id)} className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500" onClick={e => e.stopPropagation()} />
                    )}
`;

code = code.replace(oldSubfolderInner, newSubfolderInner);
code = code.replace(oldCardInner, newCardInner);

// Add onContextMenu to pointer events handlers for both
code = code.replace(/onPointerCancel=\{cancelPress\}/g, "onPointerCancel={cancelPress}\n                  onContextMenu={(e) => {\n                     // e.preventDefault();\n                  }}");

fs.writeFileSync('src/components/FolderView.tsx', code);
console.log('patched FolderView cb');
