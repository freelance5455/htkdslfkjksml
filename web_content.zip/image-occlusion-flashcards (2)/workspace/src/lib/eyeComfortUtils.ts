// Eye Comfort Shield / Night Light Utility for System-Wide Warmth and Blue Light Reduction

export type EyeComfortTone = 'amber' | 'sepia' | 'candle';

export interface EyeComfortSettings {
  enabled: boolean;
  intensity: number; // 10 to 65 (%)
  tone: EyeComfortTone;
  autoNight: boolean; // Auto activate between 7:00 PM and 7:00 AM
}

const STORAGE_KEY = 'mcard_eye_comfort_settings';
const OVERLAY_ID = 'system-eye-comfort-shield';

const DEFAULT_SETTINGS: EyeComfortSettings = {
  enabled: false,
  intensity: 30,
  tone: 'amber',
  autoNight: false,
};

type Listener = (settings: EyeComfortSettings, isActive: boolean) => void;
const listeners = new Set<Listener>();

// Check if current hour falls in night time (7 PM to 7 AM)
export function isNightTime(): boolean {
  try {
    const hour = new Date().getHours();
    return hour >= 19 || hour < 7;
  } catch (e) {
    return false;
  }
}

// Check if the shield should be visually active
export function isEyeComfortActive(settings?: EyeComfortSettings): boolean {
  const current = settings || getEyeComfortSettings();
  if (current.enabled) return true;
  if (current.autoNight && isNightTime()) return true;
  return false;
}

// Get saved settings from localStorage
export function getEyeComfortSettings(): EyeComfortSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return {
      enabled: typeof parsed.enabled === 'boolean' ? parsed.enabled : DEFAULT_SETTINGS.enabled,
      intensity: typeof parsed.intensity === 'number' ? Math.min(65, Math.max(10, parsed.intensity)) : DEFAULT_SETTINGS.intensity,
      tone: ['amber', 'sepia', 'candle'].includes(parsed.tone) ? parsed.tone : DEFAULT_SETTINGS.tone,
      autoNight: typeof parsed.autoNight === 'boolean' ? parsed.autoNight : DEFAULT_SETTINGS.autoNight,
    };
  } catch (e) {
    return DEFAULT_SETTINGS;
  }
}

// Save settings and update visual DOM
export function saveEyeComfortSettings(newSettings: Partial<EyeComfortSettings>): EyeComfortSettings {
  const current = getEyeComfortSettings();
  const updated: EyeComfortSettings = {
    ...current,
    ...newSettings,
  };

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to save eye comfort settings to localStorage', e);
  }

  applyEyeComfortToDOM(updated);
  notifyListeners(updated);
  return updated;
}

// Toggle enabled status
export function toggleEyeComfort(): boolean {
  const current = getEyeComfortSettings();
  const nextEnabled = !isEyeComfortActive(current);
  saveEyeComfortSettings({ enabled: nextEnabled });
  return nextEnabled;
}

// Subscribe to updates
export function subscribeEyeComfort(listener: Listener): () => void {
  listeners.add(listener);
  // Send initial state immediately
  const settings = getEyeComfortSettings();
  listener(settings, isEyeComfortActive(settings));
  return () => {
    listeners.delete(listener);
  };
}

function notifyListeners(settings: EyeComfortSettings) {
  const active = isEyeComfortActive(settings);
  listeners.forEach((fn) => {
    try {
      fn(settings, active);
    } catch (e) {
      console.error(e);
    }
  });
}

// Generate the warm tint color based on tone and intensity
function getTintValues(tone: EyeComfortTone, intensity: number) {
  // intensity is 10 to 65%
  // Normalized alpha for multiply blend mode: 0.08 to 0.32
  const factor = intensity / 100;
  const alpha = 0.06 + factor * 0.38;

  switch (tone) {
    case 'sepia':
      return {
        rgba: `rgba(240, 205, 140, ${alpha.toFixed(3)})`,
        softRgba: `rgba(215, 175, 105, ${(alpha * 0.45).toFixed(3)})`,
        name: 'রিডিং পেপার (Paper Sepia)',
        filter: `sepia(${(factor * 0.25).toFixed(2)})`,
      };
    case 'candle':
      return {
        rgba: `rgba(255, 135, 15, ${(alpha * 0.95).toFixed(3)})`,
        softRgba: `rgba(235, 110, 10, ${(alpha * 0.4).toFixed(3)})`,
        name: 'সফট ক্যান্ডেল (Candle Warm)',
        filter: `sepia(${(factor * 0.2).toFixed(2)})`,
      };
    case 'amber':
    default:
      return {
        rgba: `rgba(255, 170, 35, ${alpha.toFixed(3)})`,
        softRgba: `rgba(245, 150, 20, ${(alpha * 0.45).toFixed(3)})`,
        name: 'অ্যাম্বার শিল্ড (Amber Shield)',
        filter: `sepia(${(factor * 0.22).toFixed(2)})`,
      };
  }
}

// Apply or remove the full-screen eye comfort shield overlay
export function applyEyeComfortToDOM(settings?: EyeComfortSettings): void {
  if (typeof document === 'undefined') return;

  const current = settings || getEyeComfortSettings();
  const active = isEyeComfortActive(current);

  let overlay = document.getElementById(OVERLAY_ID);

  if (!active) {
    if (overlay) {
      overlay.style.opacity = '0';
      overlay.style.pointerEvents = 'none';
      setTimeout(() => {
        if (overlay && overlay.parentNode && !isEyeComfortActive()) {
          overlay.parentNode.removeChild(overlay);
        }
      }, 300);
    }
    document.documentElement.classList.remove('eye-comfort-active');
    document.documentElement.style.removeProperty('--eye-comfort-filter');
    return;
  }

  // Active state: ensure overlay element exists
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = OVERLAY_ID;
    overlay.setAttribute('aria-hidden', 'true');
    // Critical: pointer-events: none so clicks and taps pass right through to all buttons & UI
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.right = '0';
    overlay.style.bottom = '0';
    overlay.style.width = '100vw';
    overlay.style.height = '100vh';
    overlay.style.pointerEvents = 'none';
    overlay.style.zIndex = '999980'; // Above main app layout, just below system critical modals
    overlay.style.transition = 'opacity 0.3s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.3s ease';
    overlay.style.opacity = '0';
    document.body.appendChild(overlay);
  }

  const { rgba } = getTintValues(current.tone, current.intensity);

  overlay.style.backgroundColor = rgba;
  overlay.style.mixBlendMode = 'multiply';
  // Also force hardware acceleration for zero stutter
  overlay.style.transform = 'translateZ(0)';
  overlay.style.willChange = 'opacity, background-color';

  requestAnimationFrame(() => {
    if (overlay) {
      overlay.style.opacity = '1';
    }
  });

  document.documentElement.classList.add('eye-comfort-active');
}

// Initialize on page load (sets up schedule timer if autoNight is enabled)
export function initEyeComfort(): () => void {
  if (typeof window === 'undefined') return () => {};

  const current = getEyeComfortSettings();
  applyEyeComfortToDOM(current);

  // Check auto-night transition every 5 minutes
  const interval = setInterval(() => {
    const s = getEyeComfortSettings();
    if (s.autoNight) {
      applyEyeComfortToDOM(s);
      notifyListeners(s);
    }
  }, 5 * 60 * 1000);

  return () => clearInterval(interval);
}
