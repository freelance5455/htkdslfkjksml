const fs = require('fs');
const content = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const lines = content.split('\n');
const stack = [];

// Use strict tag closing checks
for (let i = 1768; i < 2932; i++) {
  const line = lines[i];
  if (!line) continue;
  
  const tagRegex = /<\/?(div|main|button|span|textarea)[^>]*>/g;
  let match;
  while ((match = tagRegex.exec(line)) !== null) {
    const tag = match[0];
    const isSelfClosing = tag.endsWith('/>');
    if (isSelfClosing) continue;

    const isClosing = tag.startsWith('</');
    const tagName = match[1];

    if (!isClosing) {
      stack.push({ tag: tagName, line: i + 1 });
    } else {
      const last = stack.pop();
      if (!last || last.tag !== tagName) {
        console.log(`Mismatch at line ${i + 1}: Found ${tag}, expected </${last ? last.tag : 'NONE'}> (opened at line ${last ? last.line : 'NONE'})`);
        console.log("Lines context:");
        console.log(lines.slice(Math.max(0, i-5), i+5).join('\n'));
        process.exit(1);
      }
    }
  }
}
