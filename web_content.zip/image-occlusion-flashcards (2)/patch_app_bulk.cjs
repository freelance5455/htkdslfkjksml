const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Add state
if (!code.includes('bulkEditQueue')) {
  code = code.replace(
    "const [studyIndex, setStudyIndex] = useState(0);",
    "const [studyIndex, setStudyIndex] = useState(0);\n  const [bulkEditQueue, setBulkEditQueue] = useState<Card[]>([]);"
  );
}
if (!code.includes("'bulk-edit'")) {
  code = code.replace(
    "useState<'dashboard' | 'create' | 'study' | 'folder' | 'quiz'>('dashboard');",
    "useState<'dashboard' | 'create' | 'study' | 'folder' | 'quiz' | 'bulk-edit'>('dashboard');"
  );
}

// Pass onStartBulkEdit to Dashboard
code = code.replace(
  "onBulkCreate={(newCards) => {",
  "onStartBulkEdit={(cards) => {\n          setBulkEditQueue(cards);\n          setView('bulk-edit');\n        }}\n        onBulkCreate={(newCards) => {"
);

// Add view === 'bulk-edit'
const bulkEditView = `
      {view === 'bulk-edit' && bulkEditQueue.length > 0 && (
        <CreateCard
          folderId={null}
          editingCard={bulkEditQueue[0]}
          isBulkEdit={true}
          bulkRemaining={bulkEditQueue.length}
          onSave={(updatedCard) => {
            const newCards = [...cards, updatedCard];
            setCards(newCards);
            set('flashcards', newCards);
            
            const nextQueue = bulkEditQueue.slice(1);
            if (nextQueue.length > 0) {
              setBulkEditQueue(nextQueue);
            } else {
              setView('dashboard');
            }
          }}
          onCancel={() => {
            const nextQueue = bulkEditQueue.slice(1);
            if (nextQueue.length > 0) {
              setBulkEditQueue(nextQueue);
            } else {
              setView('dashboard');
            }
          }}
        />
      )}
`;

const appClosingMatch = code.lastIndexOf('      {(view === \'study\' || view === \'quiz\') && <EyeCareTimer />}');
if (appClosingMatch !== -1 && !code.includes("view === 'bulk-edit'")) {
  code = code.substring(0, appClosingMatch) + bulkEditView + code.substring(appClosingMatch);
}

fs.writeFileSync('src/App.tsx', code);
console.log("App patched for bulkEditQueue");
