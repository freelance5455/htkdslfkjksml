const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

// The proportional padding was added as:
// const padX = w * 0.06;
// const padY = h * 0.15;

const target1 = `const padX = w * 0.06;
                const padY = h * 0.15;`;

const new1 = `const padX = 2;
                const padY = 2;`;

code = code.replace(new RegExp('const padX = w \\* 0.06;\\s*const padY = h \\* 0.15;', 'g'), `const padX = 2;
                const padY = 2;`);

// In location 3, it had different spacing:
// const padX = w * 0.06;
// const padY = h * 0.15;
// RegExp should catch all of them.

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Reverted to tight padX 2, padY 2');
