const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');
code = code.replace(
  "lastError = err;",
  "lastError = err; console.error('Gemini error for model', model, ':', err?.message || err);"
);
fs.writeFileSync('server.ts', code);
