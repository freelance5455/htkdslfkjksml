const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const regex = /const handleImageUpload = \(e: React\.ChangeEvent<HTMLInputElement>\) => \{[\s\S]*?reader\.readAsDataURL\(file\);\s*\};/;

const newHandleImage = `const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.match('image.*')) {
      setAlertMsg('দয়া করে শুধুমাত্র সাধারণ ছবি (JPG, PNG) আপলোড করুন।');
      return;
    }

    setIsProcessing(true);
    try {
      const { compressImage } = await import('../lib/imageUtils');
      const compressedBase64 = await compressImage(file, 1200, 0.6);
      setImage(compressedBase64);
    } catch (err) {
      console.error(err);
      // Fallback
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    } finally {
      setIsProcessing(false);
    }
  };`;

if(regex.test(code)) {
    code = code.replace(regex, newHandleImage);
    fs.writeFileSync('src/components/CreateCard.tsx', code);
    console.log('patched successfully');
} else {
    console.log('regex did not match');
}
