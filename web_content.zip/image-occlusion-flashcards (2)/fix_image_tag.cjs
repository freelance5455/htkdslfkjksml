const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const targetImg = `<img
                      src={card.image}
                      alt={card.title}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-700 shrink-0"
                    />`;

const replacementImg = `<div className="w-12 h-12 rounded-xl bg-slate-700 border border-slate-600 shrink-0 flex items-center justify-center text-slate-400">
                      <Image className="w-5 h-5" />
                    </div>`;

if (code.includes(targetImg)) {
  code = code.replace(targetImg, replacementImg);
  fs.writeFileSync('src/components/CreateCard.tsx', code);
  console.log('Fixed img tag');
} else {
  console.log('Img tag not found');
}
