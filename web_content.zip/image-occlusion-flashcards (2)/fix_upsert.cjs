const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetApp = `        for (let i = 0; i < stamped.length; i += CHUNK_SIZE) {
           const chunk = stamped.slice(i, i + CHUNK_SIZE);
           await update('flashcards', (val: any) => {
              const current = (val as Card[]) || [];
              return [...current, ...chunk];
           });
        }`;

const replacementApp = `        for (let i = 0; i < stamped.length; i += CHUNK_SIZE) {
           const chunk = stamped.slice(i, i + CHUNK_SIZE);
           await update('flashcards', (val: any) => {
              const current = (val as Card[]) || [];
              // Perform upsert based on card ID to prevent duplicates when reviewing
              const currentMap = new Map(current.map(c => [c.id, c]));
              for (const c of chunk) {
                 currentMap.set(c.id, c);
              }
              return Array.from(currentMap.values());
           });
        }`;

code = code.replace(targetApp, replacementApp);
fs.writeFileSync('src/App.tsx', code);
console.log('Fixed Upsert');
