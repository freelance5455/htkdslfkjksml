const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const t1 = `const padX = w * 0.06; // 6% of its own width
                const padY = h * 0.15; // 15% of its own height for diacritics`;

code = code.replace(t1, `const padX = 2;
                const padY = 2;`);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed first padX');
