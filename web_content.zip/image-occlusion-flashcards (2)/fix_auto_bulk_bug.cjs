const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

code = code.replace(
  `    const validFiles = rawFiles.filter(f => f.type.match('image.*'));
    if (memoryFiles.length === 0) {
      if (rawFiles.length > 0) {`,
  `    const validFiles = rawFiles.filter(f => f.type.match('image.*'));
    if (validFiles.length === 0) {
      if (rawFiles.length > 0) {`
);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed memoryFiles initialization bug');
