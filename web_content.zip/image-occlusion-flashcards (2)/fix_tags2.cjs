const fs = require('fs');

const content = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');
const lines = content.split('\n');
const stack = [];

// Better parser using HTML parsing logic
let inJsx = false;
for (let i = 1768; i < lines.length; i++) {
  let line = lines[i];
  
  // simple matching
  const regex = /<(\/)?([a-zA-Z0-9]+)([^>]*?)(\/?)>/g;
  let match;
  while ((match = regex.exec(line)) !== null) {
    const isClosing = match[1] === '/';
    const tagName = match[2];
    const selfClosing = match[4] === '/';

    if (tagName.toLowerCase() === 'br' || tagName.toLowerCase() === 'hr' || tagName.toLowerCase() === 'img' || tagName.toLowerCase() === 'input') {
        continue;
    }

    if (['div', 'main', 'button', 'span', 'textarea', 'label', 'strong', 'h3', 'h4', 'p', 'svg', 'canvas'].includes(tagName.toLowerCase())) {
      if (!isClosing && !selfClosing) {
        stack.push({ tag: tagName.toLowerCase(), line: i + 1 });
      } else if (isClosing) {
        if (stack.length === 0) {
          console.log(`Extra closing tag </${tagName}> at line ${i + 1}`);
          process.exit(1);
        }
        const last = stack.pop();
        if (last.tag !== tagName.toLowerCase()) {
          console.log(`Mismatch at line ${i + 1}: Found </${tagName}>, expected </${last.tag}> (opened at line ${last.line})`);
          console.log("Lines context:");
          console.log(lines.slice(Math.max(0, i-5), i+5).join('\n'));
          process.exit(1);
        }
      }
    }
  }
}

if (stack.length > 0) {
    console.log("Unclosed tags:");
    stack.forEach(s => console.log(s));
} else {
    console.log("All tags matched!");
}
