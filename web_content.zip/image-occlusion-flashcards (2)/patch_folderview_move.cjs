const fs = require('fs');
let code = fs.readFileSync('src/components/FolderView.tsx', 'utf8');

code = code.replace(
  "onMoveItem(moveItemData.id, f.id, moveItemData.type);",
  "if (moveItemData.id === -1 && onMoveMultiple) {\n                      if (selectedFolders.length > 0) onMoveMultiple(selectedFolders, f.id, 'folder');\n                      if (selectedCards.length > 0) onMoveMultiple(selectedCards, f.id, 'card');\n                      cancelSelection();\n                    } else if (onMoveItem) {\n                      onMoveItem(moveItemData.id, f.id, moveItemData.type);\n                    }"
);

code = code.replace(
  "onMoveItem(moveItemData.id, folder.parentId || null, moveItemData.type);",
  "if (moveItemData.id === -1 && onMoveMultiple) {\n                      if (selectedFolders.length > 0) onMoveMultiple(selectedFolders, folder.parentId || null, 'folder');\n                      if (selectedCards.length > 0) onMoveMultiple(selectedCards, folder.parentId || null, 'card');\n                      cancelSelection();\n                    } else if (onMoveItem) {\n                      onMoveItem(moveItemData.id, folder.parentId || null, moveItemData.type);\n                    }"
);

fs.writeFileSync('src/components/FolderView.tsx', code);
