const fs = require('fs');
let code = fs.readFileSync('src/components/SyncButton.tsx', 'utf8');

code = code.replace(
  "} catch (err) {\\n      console.error(err);\\n      setAlert('লগইন করতে সমস্যা হয়েছে।');",
  "} catch (err: any) {\\n      console.error(err);\\n      if (err.code === 'auth/popup-closed-by-user' || (err.message && err.message.includes('popup-closed-by-user'))) {\\n        // Ignore user closing popup\\n      } else {\\n        setAlert('লগইন করতে সমস্যা হয়েছে।');\\n      }"
);

fs.writeFileSync('src/components/SyncButton.tsx', code);
console.log('SyncButton patched');
