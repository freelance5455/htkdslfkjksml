const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

code = code.replace(
  `processedCards.push({ ...newCard, image: '' });`,
  `processedCards.push(newCard);`
);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Restored newCard image for summary UI');
