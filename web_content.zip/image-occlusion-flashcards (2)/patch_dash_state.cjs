const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

const injection = `
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [selectedFolders, setSelectedFolders] = useState<number[]>([]);
  const [isSelectionMode, setIsSelectionMode] = useState(false);

  const toggleSelectCard = (id: number) => {
    setSelectedCards(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };
  
  const toggleSelectFolder = (id: number) => {
    setSelectedFolders(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const cancelSelection = () => {
    setSelectedCards([]);
    setSelectedFolders([]);
    setIsSelectionMode(false);
  };
`;

code = code.replace(
  "const [alertMsg, setAlertMsg] = useState('');",
  "const [alertMsg, setAlertMsg] = useState('');\n" + injection
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
