const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const oldFolderView = `<FolderView 
          folder={folders.find(f => f.id === currentFolderId)!}
          cards={cards.filter(c => c.folderId === currentFolderId)}
          folders={folders.filter(f => f.parentId === currentFolderId)}
          allFolders={folders}
          onAddFolder={(name) => addFolder(name, currentFolderId)}
          onDeleteFolder={deleteFolder}
          onOpenFolder={(id) => { setCurrentFolderId(id); setView('folder'); }}
          onMoveItem={moveItem}
          onBack={() => {
            const current = folders.find(f => f.id === currentFolderId);
            if (current && current.parentId) {
              setCurrentFolderId(current.parentId);
            } else {
              setCurrentFolderId(null);
              setView('dashboard');
            }
          }}
          onDelete={deleteCard}
          onRename={renameCard}
          onEdit={handleEditCard}
          onStartStudy={(index, shuffled) => startStudy(cards.filter(c => c.folderId === currentFolderId), index, shuffled)}
          onStartQuiz={() => startQuiz(cards.filter(c => c.folderId === currentFolderId))}
          onCreateNew={() => { setEditingCardId(null); setView('create'); }}
        />`;

const newFolderView = `<FolderView 
          folder={folders.find(f => f.id === currentFolderId)!}
          cards={cards.filter(c => c.folderId === currentFolderId)}
          folders={folders.filter(f => f.parentId === currentFolderId)}
          allFolders={folders}
          onAddFolder={(name) => addFolder(name, currentFolderId)}
          onDeleteFolder={deleteFolder}
          onOpenFolder={(id) => { setCurrentFolderId(id); setView('folder'); }}
          onMoveItem={moveItem}
          onBack={() => {
            const current = folders.find(f => f.id === currentFolderId);
            if (current && current.parentId) {
              setCurrentFolderId(current.parentId);
            } else {
              setCurrentFolderId(null);
              setView('dashboard');
            }
          }}
          onDelete={deleteCard}
          onDeleteMultiple={deleteMultipleCards}
          onMoveMultiple={moveMultipleCards}
          onRename={renameCard}
          onEdit={handleEditCard}
          onStartStudy={(index, shuffled) => startStudy(cards.filter(c => c.folderId === currentFolderId), index, shuffled)}
          onStartQuiz={() => startQuiz(cards.filter(c => c.folderId === currentFolderId))}
          onCreateNew={() => { setEditingCardId(null); setView('create'); }}
        />`;

if(code.includes(oldFolderView)) {
    code = code.replace(oldFolderView, newFolderView);
    fs.writeFileSync('src/App.tsx', code);
    console.log('patched App.tsx successfully');
} else {
    console.log('regex did not match');
}
