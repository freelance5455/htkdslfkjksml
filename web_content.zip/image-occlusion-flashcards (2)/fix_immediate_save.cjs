const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const immediateSaveBlock = `        // SAVE IMMEDIATELY WITHOUT RE-RENDERING APP to prevent UI freeze and data loss
        try {
          const { update } = await import('idb-keyval');
          await update('flashcards', (val) => {
             const current = (val) || [];
             return [...current, newCard];
          });
        } catch (err) {
          console.error('Fast save error:', err);
        }`;

code = code.replace(immediateSaveBlock, `        // Wait for user to review before committing to IDB`);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Removed immediate save');
