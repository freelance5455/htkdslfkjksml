const fs = require('fs');
let code = fs.readFileSync('index.html', 'utf8');

const headInject = `
    <meta name="theme-color" content="#2563eb" />
    <link rel="apple-touch-icon" href="/icon.svg" />
    <link rel="icon" type="image/svg+xml" href="/icon.svg" />
`;

if (!code.includes('theme-color')) {
    code = code.replace('<title>', headInject + '\n    <title>');
    // Update title
    code = code.replace('<title>My Google AI Studio App</title>', '<title>Flashcards PWA</title>');
    fs.writeFileSync('index.html', code);
    console.log('patched index.html');
}
