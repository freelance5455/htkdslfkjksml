const fs = require('fs');

const content = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');
const lines = content.split('\n');
const stack = [];

// Simplified parser to track HTML tags and find the exact mismatch
for (let i = 1768; i < lines.length; i++) {
  const line = lines[i];
  if (!line) continue;
  
  // Naive regex to match open and close tags, skipping self-closing ones and fragments <>
  const tagRegex = /<(\/)?([a-zA-Z0-9]+)[^>]*>/g;
  let match;
  while ((match = tagRegex.exec(line)) !== null) {
    // Avoid matching self closing tags or specific component usage that doesn't have closing tag usually in this file if it's not a div/main/etc
    const fullTag = match[0];
    if (fullTag.endsWith('/>')) continue;

    const isClosing = match[1] === '/';
    const tagName = match[2];

    // Only track block level elements mostly
    if (['div', 'main', 'button', 'span', 'textarea'].includes(tagName)) {
      if (!isClosing) {
        stack.push({ tag: tagName, line: i + 1 });
      } else {
        if (stack.length === 0) {
          console.log(`Extra closing tag </${tagName}> at line ${i + 1}`);
          process.exit(1);
        }
        const last = stack.pop();
        if (last.tag !== tagName) {
          console.log(`Mismatch at line ${i + 1}: Found </${tagName}>, expected </${last.tag}> (opened at line ${last.line})`);
          console.log("Lines context:");
          console.log(lines.slice(Math.max(0, i-5), i+5).join('\n'));
          process.exit(1);
        }
      }
    }
  }
}
console.log("Tags match successfully!");
