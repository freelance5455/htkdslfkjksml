const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

code = code.replace(
  `processedCards.push(newCard);`,
  `processedCards.push({ ...newCard, image: '' });`
);

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Restored empty image to save RAM');
