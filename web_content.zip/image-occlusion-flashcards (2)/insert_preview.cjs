const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const target = `                <button
                  type="button"
                  onClick={() => setShowBadges(!showBadges)}`;

const replacement = `                <button
                  type="button"
                  onClick={() => setIsPreviewMode(!isPreviewMode)}
                  title={isPreviewMode ? 'এডিট মোডে ফিরুন' : 'প্রিভিউ দেখুন'}
                  className={\`font-semibold active:scale-95 flex items-center gap-1.5 transition-all py-1.5 px-2.5 rounded-xl \${isPreviewMode ? 'text-indigo-700 bg-indigo-100 dark:bg-indigo-900/40 dark:text-indigo-300 shadow-sm' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700'}\`}
                >
                  {isPreviewMode ? <><Edit3 className="w-4 h-4" /> এডিট</> : <><Eye className="w-4 h-4" /> প্রিভিউ</>}
                </button>

                <button
                  type="button"
                  onClick={() => setShowBadges(!showBadges)}`;

if (code.includes(target)) {
    code = code.replace(target, replacement);
    fs.writeFileSync('src/components/CreateCard.tsx', code);
    console.log('Inserted Preview button successfully');
} else {
    console.log('Target string not found');
}
