const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

if (!code.includes('onDeleteMultiple={deleteMultipleCards}')) {
  console.log("NOT FOUND in App.tsx?");
} else {
  // Let's add them to FolderView too
  if (!code.includes('onMoveMultiple={moveMultipleCards}\\n          onRename={renameCard}')) {
    code = code.replace(
      "onDelete={deleteCard}\\n          onRename={renameCard}",
      "onDelete={deleteCard}\\n          onDeleteMultiple={deleteMultipleCards}\\n          onMoveMultiple={moveMultipleCards}\\n          onRename={renameCard}"
    );
  }
}

fs.writeFileSync('src/App.tsx', code);
