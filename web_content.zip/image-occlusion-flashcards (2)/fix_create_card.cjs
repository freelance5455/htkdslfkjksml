const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const targetSaveLoop = `        // SAVE IMMEDIATELY to prevent data loss on app switch/OOM
        if (onBulkCreate) {
          await Promise.resolve(onBulkCreate([newCard]));
        } else {
          onSave(newCard);
        }
        successCount++;`;

const replacementSaveLoop = `        // SAVE IMMEDIATELY WITHOUT RE-RENDERING APP to prevent UI freeze and data loss
        try {
          const { update } = await import('idb-keyval');
          await update('flashcards', (val) => {
             const current = (val) || [];
             return [...current, newCard];
          });
        } catch (err) {
          console.error('Fast save error:', err);
        }
        successCount++;`;

if (code.includes(targetSaveLoop)) {
    code = code.replace(targetSaveLoop, replacementSaveLoop);
    console.log('Fixed save loop');
} else {
    console.log('Target Save Loop not found');
}

const targetEndLoop = `      setAutoBulkCompletedCards(processedCards);
      setShowAutoBulkSummary(true);
    } catch (error) {`;

const replacementEndLoop = `      setAutoBulkCompletedCards(processedCards);
      setShowAutoBulkSummary(true);
      
      // Refresh App UI state after all background saves are done
      if (onBulkCreate) {
         onBulkCreate([]);
      }
    } catch (error) {`;

if (code.includes(targetEndLoop)) {
    code = code.replace(targetEndLoop, replacementEndLoop);
    console.log('Fixed end loop refresh');
} else {
    console.log('Target End Loop not found');
}

fs.writeFileSync('src/components/CreateCard.tsx', code);
