const fs = require('fs');
const content = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const regex = /<div className="relative inline-flex items-center">[\s\S]*?AI মাস্ক শনাক্তকরণ মোড[\s\S]*?<\/div>\s*<\/div>/;
const match = regex.exec(content);
if (match) {
  console.log("Matched length:", match[0].length);
  const matchedStr = match[0];
  console.log("Ends with:\n" + matchedStr.substring(matchedStr.length - 100));
} else {
  console.log("No match");
}
