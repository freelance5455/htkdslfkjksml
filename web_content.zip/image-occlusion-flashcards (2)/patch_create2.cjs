const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

// revert cancel btn to X
const newCancelBtn = `<button onClick={onCancel} className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1 font-medium">
          {isBulkEdit ? <span className="text-sm">স্কিপ</span> : <X className="w-6 h-6" />}
        </button>`;
const oldCancelBtn = `<button onClick={onCancel} className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 rounded-full transition-colors" title="বাতিল">
          <X className="w-6 h-6" />
        </button>`;
code = code.replace(newCancelBtn, oldCancelBtn);

// add skip button next to save
const saveBtnBlock = `<button
          onClick={handleSave}
          className="flex items-center gap-2 bg-green-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-600 active:scale-95 transition-transform"
        >
          <Save className="w-5 h-5 hidden sm:block" /> <span className="hidden sm:inline">{isBulkEdit ? 'সেভ ও পরবর্তী' : 'সেভ'}</span><span className="sm:hidden">{isBulkEdit ? 'সেভ ও পরবর্তী' : 'সেভ'}</span>
        </button>`;

const newSaveBtnBlock = `
        <div className="flex gap-2">
          {isBulkEdit && (
             <button
               onClick={() => {
                 // Trigger skip which we can route through a special prop or just use onCancel? 
                 // Wait, if we use onCancel for X, how do we handle Skip?
                 // Let's add onSkip prop.
               }}
               className=""
             >
             </button>
          )}
        </div>
`;
// Actually, let's just make onCancel mean Skip, and add an onExitBulkEdit prop for the X button?
// If we change App.tsx to pass onSkip, that's better.
