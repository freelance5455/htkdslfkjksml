const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

code = code.replace(/const padX = 25;/g, 'const padX = 25;');
code = code.replace(/const padY = 25;/g, 'const padY = 35;');

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed padding to padX=25, padY=35');
