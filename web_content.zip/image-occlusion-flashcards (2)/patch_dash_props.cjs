const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

code = code.replace(
  "onDelete: (id: number) => void;",
  "onDelete: (id: number) => void;\n  onDeleteMultiple?: (ids: number[], itemType?: 'card'|'folder') => void;\n  onMoveMultiple?: (ids: number[], targetFolderId: number | null, itemType?: 'card'|'folder') => void;"
);

code = code.replace(
  "onBulkCreate?: (cards: Card[]) => void;\n  onStartBulkEdit?: (cards: Card[]) => void;\n}",
  "onBulkCreate?: (cards: Card[]) => void;\n  onStartBulkEdit?: (cards: Card[]) => void;\n}"
);

code = code.replace(
  "export default function Dashboard({ cards, folders, darkMode, toggleDarkMode, onAddFolder, onDeleteFolder, onOpenFolder, onDelete, onRename, onEdit, onImport, onRecoverLegacy, onMoveItem, onStartStudy, onStartQuiz, onCreateNew, onBulkCreate, onStartBulkEdit }: DashboardProps) {",
  "export default function Dashboard({ cards, folders, darkMode, toggleDarkMode, onAddFolder, onDeleteFolder, onOpenFolder, onDelete, onDeleteMultiple, onMoveMultiple, onRename, onEdit, onImport, onRecoverLegacy, onMoveItem, onStartStudy, onStartQuiz, onCreateNew, onBulkCreate, onStartBulkEdit }: DashboardProps) {"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
