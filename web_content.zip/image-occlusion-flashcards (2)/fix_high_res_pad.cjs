const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

// Update compressImage calls
code = code.replace(/compressImage\(file, 800, 0\.75, true\)/g, 'compressImage(file, 1600, 0.85, true)');

// Update prepareImageForAI
code = code.replace(/const maxDim = 800;/g, 'const maxDim = 1600;');
code = code.replace(/resolve\(canvas\.toDataURL\('image\/jpeg', 0\.75\)\);/g, 'resolve(canvas.toDataURL("image/jpeg", 0.85));');

// Update pads. We currently have padX = 2; padY = 2;
// We'll change it to 5.
code = code.replace(/const padX = 2;/g, 'const padX = 5;');
code = code.replace(/const padY = 2;/g, 'const padY = 6;');

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed High Res and 5-6px padding');
