const fs = require('fs');
let code = fs.readFileSync('src/main.tsx', 'utf8');

const targetSW = `  onNeedRefresh() {
    console.log('New update available!');
    if (confirm('অ্যাপের নতুন ভার্সন এসেছে। আপডেট করবেন কি?')) {
      updateSW(true);
    }
  },`;

const replacementSW = `  onNeedRefresh() {
    console.log('New update available!');
    if (confirm('অ্যাপের নতুন ভার্সন এসেছে। আপডেট করবেন কি?')) {
      updateSW(true);
    }
  },
  onOfflineReady() {
    console.log('App ready to work offline');
  },`;

code = code.replace(targetSW, replacementSW);
fs.writeFileSync('src/main.tsx', code);
