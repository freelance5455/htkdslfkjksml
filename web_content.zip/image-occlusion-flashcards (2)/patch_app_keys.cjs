const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
  "{view === 'create' && (\n        <CreateCard",
  "{view === 'create' && (\n        <CreateCard\n          key={editingCardId || 'new'}"
);

code = code.replace(
  "{view === 'bulk-edit' && bulkEditQueue.length > 0 && (\n        <CreateCard",
  "{view === 'bulk-edit' && bulkEditQueue.length > 0 && (\n        <CreateCard\n          key={bulkEditQueue[0].id}"
);

fs.writeFileSync('src/App.tsx', code);
console.log('App.tsx keys patched');
