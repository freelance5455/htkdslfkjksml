const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
  "const deleteCard = (id: number) => {",
  "const deleteMultipleCards = (ids: number[], itemType: 'card'|'folder' = 'card') => {\n    if (itemType === 'card') {\n      saveCards(cards.filter(c => !ids.includes(c.id)));\n    } else {\n      saveFolders(folders.filter(f => !ids.includes(f.id)));\n      saveCards(cards.filter(c => !c.folderId || !ids.includes(c.folderId))); // Also delete cards in folder\n    }\n  };\n\n  const moveMultipleCards = (ids: number[], targetFolderId: number | null, itemType: 'card'|'folder' = 'card') => {\n    if (itemType === 'card') {\n      saveCards(cards.map(c => ids.includes(c.id) ? { ...c, folderId: targetFolderId || undefined } : c));\n    } else {\n      saveFolders(folders.map(f => ids.includes(f.id) ? { ...f, parentId: targetFolderId || undefined } : f));\n    }\n  };\n\n  const deleteCard = (id: number) => {"
);

// Add props to Dashboard and FolderView
code = code.replace(
  "onDelete={deleteCard}",
  "onDelete={deleteCard}\n          onDeleteMultiple={deleteMultipleCards}\n          onMoveMultiple={moveMultipleCards}"
);

code = code.replace(
  "onDeleteCard={deleteCard}",
  "onDeleteCard={deleteCard}\n          onDeleteMultiple={deleteMultipleCards}\n          onMoveMultiple={moveMultipleCards}"
);

fs.writeFileSync('src/App.tsx', code);
console.log('App patched');
