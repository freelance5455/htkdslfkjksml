const fs = require('fs');
let lines = fs.readFileSync('src/components/CreateCard.tsx', 'utf8').split('\n');

// Replace lines 2928 to 2932
lines.splice(2927, 5, 
  '          </div>',
  '        )}',
  '      </main>'
);

fs.writeFileSync('src/components/CreateCard.tsx', lines.join('\n'));
