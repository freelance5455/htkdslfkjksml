import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // Caching headers optimized for offline Android WebViews & PWA
  app.use((req, res, next) => {
    // API endpoints must never be cached
    if (req.path.startsWith('/api')) {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      return next();
    }

    // Service Worker and Manifest: revalidate when online, allow offline fallback
    if (req.path.endsWith('sw.js') || req.path.includes('dev-sw') || req.path === '/manifest.json') {
      res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
      return next();
    }

    // Static assets (images, icons, fonts, chunks)
    if (req.path.startsWith('/assets') || /\.(?:png|jpg|jpeg|svg|webp|ico|woff|woff2)$/.test(req.path)) {
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      return next();
    }

    // HTML / root: allow HTTP cache with revalidation so Android WebView can load from disk offline
    res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
    next();
  });

  // Shared Gemini client helper
  function getGeminiClient() {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is not set');
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }

  // High-performance models ordered for lightning speed and razor-sharp vision precision
  const CANDIDATE_MODELS = [
    'gemini-3.6-flash',
    'gemini-3.1-flash-lite'
  ];

  // Helper with automatic retry for 503 (Service Unavailable) and graceful fallback
  async function generateContentWithFallback(ai: GoogleGenAI, generateParams: { contents: any; config?: any }) {
    let lastError: any = null;

    for (const model of CANDIDATE_MODELS) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const response = await ai.models.generateContent({
            ...generateParams,
            model,
          });
          if (response?.text) {
            return response;
          }
        } catch (err: any) {
          lastError = err; 
          
          const errString = typeof err?.message === 'string' ? err.message : JSON.stringify(err);
          const isOverloaded = 
            err?.status === 503 || err?.code === 503 || err?.error?.code === 503 ||
            err?.status === 'UNAVAILABLE' || err?.error?.status === 'UNAVAILABLE' ||
            errString.includes('503') || errString.includes('UNAVAILABLE');

          // If temporary 503 service overload, wait before retrying
          if (isOverloaded) {
            if (attempt < 2) {
              const delay = 1000 * Math.pow(2, attempt); // 1s, then 2s
              await new Promise(r => setTimeout(r, delay));
              continue;
            }
          } else {
             // For non-overload errors (e.g. 400 Bad Request, 404 Not Found), just try the next model immediately
             break;
          }
          
          // Move to next candidate model if we exhausted retries for this model
          break;
        }
      }
    }

    throw lastError || new Error('All AI models failed to respond');
  }

  // Calculate Intersection over Union (IoU), Containment, and horizontal adjacency to strictly prevent overlapping duplicate masks
  function evaluateOverlap(
    boxA: { ymin: number; xmin: number; ymax: number; xmax: number },
    boxB: { ymin: number; xmin: number; ymax: number; xmax: number }
  ): { shouldMerge: boolean; iou: number; containment: number } {
    const yA = Math.max(boxA.ymin, boxB.ymin);
    const xA = Math.max(boxA.xmin, boxB.xmin);
    const yB = Math.min(boxA.ymax, boxB.ymax);
    const xB = Math.min(boxA.xmax, boxB.xmax);

    const interArea = Math.max(0, yB - yA) * Math.max(0, xB - xA);
    const boxAArea = Math.max(1, (boxA.ymax - boxA.ymin) * (boxA.xmax - boxA.xmin));
    const boxBArea = Math.max(1, (boxB.ymax - boxB.ymin) * (boxB.xmax - boxB.xmin));
    const minArea = Math.min(boxAArea, boxBArea);
    const unionArea = boxAArea + boxBArea - interArea;

    const iou = unionArea > 0 ? interArea / unionArea : 0;
    const containment = minArea > 0 ? interArea / minArea : 0;

    // Check if boxes are horizontally contiguous on the exact same text line (e.g. split words of one label)
    const yOverlap = Math.max(0, Math.min(boxA.ymax, boxB.ymax) - Math.max(boxA.ymin, boxB.ymin));
    const minHeight = Math.min(boxA.ymax - boxA.ymin, boxB.ymax - boxB.ymin);
    const isSameLine = minHeight > 0 && (yOverlap / minHeight) > 0.65;
    const xGap = Math.max(0, Math.max(boxA.xmin, boxB.xmin) - Math.min(boxA.xmax, boxB.xmax));
    const isCloseHorizontally = isSameLine && xGap <= 15;

    // Merge if either IoU > 0.25, or one box is 45%+ contained in the other, or they are contiguous words on the same line
    const shouldMerge = iou > 0.25 || containment > 0.45 || isCloseHorizontally;
    return { shouldMerge, iou, containment };
  }

  // API routes FIRST
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.post("/api/detect-text", async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { imageBase64, mode = 'labels' } = req.body;
      
      if (!imageBase64) {
        return res.status(400).json({ error: 'No image provided' });
      }

      const base64Data = imageBase64.replace(/^data:image\/[^;]+;base64,/, '');
      const mimeType = imageBase64.match(/data:(image\/[^;]+);base64/)?.[1] || 'image/jpeg';
      
      let modeInstruction = '';
      if (mode === 'labels') {
        modeInstruction = `PRIORITY: Detect ALL text labels that point to diagram parts. Find EVERY word that has a line or arrow pointing to it.
CRITICAL: Do NOT ignore any labels around the diagram! You must capture every single anatomical or scientific term.
IGNORE main titles (like "চিত্র:") and long paragraphs.
ONLY mask the actual biological/anatomical/scientific names.`;
      } else if (mode === 'keywords') {
        modeInstruction = `PRIORITY: Detect key terms, definitions, formulas, and critical test answers. Ignore long background paragraphs.`;
      } else {
        modeInstruction = `PRIORITY: Detect all visible text blocks, titles, subheadings, labels, and sentences across the entire image.`;
      }

      const prompt = `You are a world-class OCR and image occlusion bounding box detection AI for educational flashcards.
${modeInstruction}
Support Bengali text and English scientific terminology.

RETURN FORMAT:
JSON object with a "boxes" array.
Each element must have:
- "box_2d": [ymin, xmin, ymax, xmax] as 4 integers from 0 to 1000 representing normalized coordinates.
- "text": string of the exact detected text.

STRICT PRECISION RULES FOR ACCURATE BOUNDING BOXES (BENGALI OCR INSTRUCTIONS):
1. ছবির মধ্যে থাকা নির্দিষ্ট শব্দ বা লেখাটি OCR ব্যবহার করে সঠিকভাবে শনাক্ত করো। শুধু সেই শব্দের দৃশ্যমান অক্ষরগুলোর ওপর নিখুঁতভাবে Mask (box_2d) বসাও।
2. অক্ষরের আসল আকৃতি, বাংলা বর্ণ, কারচিহ্ন, ফলা, যুক্তাক্ষর, মাত্রা, দাঁড়ি ও প্রয়োজনীয় চিহ্নসহ পুরো শব্দটি Mask-এর মধ্যে থাকবে।
3. Mask যেন অক্ষরের বাইরে অপ্রয়োজনীয় জায়গায় না যায়। শব্দের আশপাশের অন্য লেখা, লাইন, তীরচিহ্ন, ছবি, টেবিল, দাগ বা ব্যাকগ্রাউন্ড Mask করবে না। Mask খুব টাইট হবে এবং অক্ষরের কিনারা অনুসরণ করবে।
4. Mask-এর চারপাশে অতিরিক্ত ফাঁকা জায়গা রাখবে না। Padding সর্বোচ্চ ১ থেকে ২ পিক্সেল হবে।
5. লেখাটি ছোট, ঝাপসা, বাঁকা বা কম রেজোলিউশনের হলেও শব্দটি যাচাই করে যথাসম্ভব নির্ভুলভাবে Mask দাও।
6. All 4 values (ymin, xmin, ymax, xmax) must be integers between 0 and 1000.`;

      const response = await generateContentWithFallback(ai, {
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType
              }
            },
            {
              text: prompt
            }
          ]
        },
        config: {
          temperature: 0.0,
          responseMimeType: 'application/json',
          responseSchema: {
            type: "OBJECT",
            properties: {
              boxes: {
                type: "ARRAY",
                items: {
                  type: "OBJECT",
                  properties: {
                    box_2d: {
                      type: "ARRAY",
                      items: { type: "INTEGER" }
                    },
                    text: { type: "STRING" },
                    label_type: { type: "STRING" }
                  },
                  required: ["box_2d"]
                }
              }
            },
            required: ["boxes"]
          }
        }
      });

      let rawResponseText = response?.text || '{"boxes":[]}';
      rawResponseText = rawResponseText.replace(/^\s*```(?:json)?\n?/i, '').replace(/\n?```\s*$/i, '').trim();
      const parsed = JSON.parse(rawResponseText);
      const rawBoxes = Array.isArray(parsed?.boxes) ? parsed.boxes : [];
      
      // Standardize coordinates to [ymin, xmin, ymax, xmax]
      const candidates = rawBoxes
        .map((item: any) => {
          let coords: number[] | null = null;
          let text: string = '';
          let labelType: string = 'label';

          if (Array.isArray(item) && item.length === 4) {
            coords = item;
          } else if (item && Array.isArray(item.box_2d) && item.box_2d.length === 4) {
            coords = item.box_2d;
            text = (item.text || '').trim();
            labelType = item.label_type || 'label';
          } else if (item && typeof item.ymin === 'number') {
            coords = [item.ymin, item.xmin, item.ymax, item.xmax];
            text = (item.text || '').trim();
            labelType = item.label_type || 'label';
          }

          if (!coords) return null;

          const [ymin, xmin, ymax, xmax] = coords.map(n => Math.round(Number(n)));
          if (isNaN(ymin) || isNaN(xmin) || isNaN(ymax) || isNaN(xmax)) return null;
          if (ymax <= ymin || xmax <= xmin) return null;
          if ((ymax - ymin) < 4 && (xmax - xmin) < 4) return null;

          const cleanText = text.replace(/^[\s\d•\-\.\*\"\']+|[\s\"\']+$/g, '').trim() || text;
          
          let finalYmin = Math.max(0, Math.min(1000, ymin));
          let finalXmin = Math.max(0, Math.min(1000, xmin));
          let finalYmax = Math.max(0, Math.min(1000, ymax));
          let finalXmax = Math.max(0, Math.min(1000, xmax));

          // AI models (especially Gemini 1.5) systematically underestimate the horizontal bounding boxes 
          // for Bengali words, often capturing only the first few syllables and cutting off the right side.
          // We calculate an estimated width based on string length and anchor to the left.
          if (cleanText.length > 0) {
            const h = finalYmax - finalYmin;
            // A conservative multiplier for typical font aspect ratios (with some breathing room)
            const estimatedWidth = cleanText.length * h * 0.45;
            const currentWidth = finalXmax - finalXmin;
            
            if (currentWidth < estimatedWidth) {
              // Expand the box to the right to cover the missing text
              finalXmax = Math.min(1000, finalXmin + estimatedWidth);
            }
          }

          return {
            ymin: finalYmin,
            xmin: finalXmin,
            ymax: finalYmax,
            xmax: finalXmax,
            text: cleanText,
            labelType
          };
        })
        .filter(Boolean) as Array<{ ymin: number; xmin: number; ymax: number; xmax: number; text: string; labelType: string }>;

      // Intelligent overlap resolution: merge nested or heavy overlapping boxes
      const resolvedBoxes: typeof candidates = [];
      for (const box of candidates) {
        let merged = false;
        for (let i = 0; i < resolvedBoxes.length; i++) {
          const existing = resolvedBoxes[i];
          const overlap = evaluateOverlap(box, existing);
          if (overlap.shouldMerge) {
            // Merge into unified clean bounding box
            resolvedBoxes[i] = {
              ymin: Math.min(box.ymin, existing.ymin),
              xmin: Math.min(box.xmin, existing.xmin),
              ymax: Math.max(box.ymax, existing.ymax),
              xmax: Math.max(box.xmax, existing.xmax),
              text: (existing.text && box.text && !existing.text.includes(box.text))
                ? `${existing.text} ${box.text}`.trim()
                : (existing.text || box.text),
              labelType: existing.labelType || box.labelType
            };
            merged = true;
            break;
          }
        }
        if (!merged) {
          resolvedBoxes.push(box);
        }
      }

      res.json({ boxes: resolvedBoxes });
    } catch (error: any) {
      console.error('Error with Gemini AI text detection:', error?.message || error);
      if (error?.status === 429 || error?.message?.includes('429') || error?.message?.includes('quota') || error?.message?.includes('Quota')) {
        return res.status(429).json({ error: 'এআই কোটা বা রিকোয়েস্ট লিমিট অতিক্রম করেছে। একটু পর আবার চেষ্টা করুন।' });
      }
      res.status(500).json({ error: 'এআই দিয়ে টেক্সট শনাক্ত করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।' });
    }
  });

  // AI Smart Note Generator for flashcard diagrams
  app.post("/api/generate-card-notes", async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { imageBase64, title } = req.body;
      if (!imageBase64) return res.status(400).json({ error: 'ছবি প্রদান করা হয়নি' });

      const base64Data = imageBase64.replace(/^data:image\/[^;]+;base64,/, '');
      const mimeType = imageBase64.match(/data:(image\/[^;]+);base64/)?.[1] || 'image/jpeg';

      const prompt = `You are an elite academic professor and medical/science flashcard tutor.
Analyze this study diagram/image (Title: "${title || 'Untitled'}").
Generate a rich, high-yield, structured study guide note in clear Bengali (বাংলা).

Structure your response clearly with these sections:
📌 **মূল পরিচিতি ও ভূমিকা**: 2-3 concise summary sentences explaining what this anatomical/scientific diagram represents.
🔍 **প্রধান চিহ্নিত অংশ ও কাজ**: Bulleted list of the most critical parts seen in the diagram with their key function (in 1 line each).
💡 **স্মরণে রাখার বিশেষ ছন্দ বা নেমোনিক (Mnemonic)**: An easy-to-remember Bengali or English mnemonic/rhyme to memorize the sequence or parts.
⭐ **পরীক্ষায় আসা কমন প্রশ্ন (Exam Tips)**: 2 high-frequency questions teachers ask from this diagram.

Tone: Clear, encouraging, academic, and practical for flashcard review.`;

      const response = await generateContentWithFallback(ai, {
        contents: {
          parts: [
            { inlineData: { data: base64Data, mimeType } },
            { text: prompt }
          ]
        }
      });

      const notes = response?.text?.trim() || '';
      if (!notes) throw new Error('Failed to generate notes with AI');
      res.json({ notes });
    } catch (err: any) {
      console.error('Note generation error:', err?.message || err);
      res.status(500).json({ error: 'AI দিয়ে নোট তৈরি করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।' });
    }
  });

  // AI Concept Explainer & Doubt Clearing Tutor
  app.post("/api/explain-concept", async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { imageBase64, title, notes, question } = req.body;

      const parts: any[] = [];

      if (imageBase64) {
        const base64Data = imageBase64.replace(/^data:image\/[^;]+;base64,/, '');
        const mimeType = imageBase64.match(/data:(image\/[^;]+);base64/)?.[1] || 'image/jpeg';
        parts.push({ inlineData: { data: base64Data, mimeType } });
      }

      const prompt = `You are a friendly, world-class tutor explaining this flashcard topic to a student in Bengali (বাংলা).
Card Title: "${title || 'Study Card'}"
Existing Notes: "${notes || 'None'}"
Student's Question or Focus: "${question || 'Explain this diagram/concept simply, step-by-step so I can easily remember it in exams.'}"

Please provide a clear, engaging explanation in simple Bengali:
- Explain what this image or concept is about in plain words.
- Point out why it is important for studies/exams.
- If the student asked a specific question, answer it directly and accurately.
- Conclude with a quick 1-sentence takeaway tip.

Use polite, encouraging tone and neat formatting with bullet points.`;

      parts.push({ text: prompt });

      const response = await generateContentWithFallback(ai, {
        contents: { parts }
      });

      const explanation = response?.text?.trim() || '';
      if (!explanation) throw new Error('AI explanation failed');
      res.json({ explanation });
    } catch (err: any) {
      console.error('Concept explanation error:', err?.message || err);
      res.status(500).json({ error: 'AI টিউটর উত্তর দিতে পারছে না। পরে আবার চেষ্টা করুন।' });
    }
  });

  // AI Smart Interactive Quiz Generator (New Premium Feature)
  app.post("/api/generate-quiz", async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { imageBase64, title, notes, labels = [] } = req.body;

      const parts: any[] = [];
      if (imageBase64) {
        const base64Data = imageBase64.replace(/^data:image\/[^;]+;base64,/, '');
        const mimeType = imageBase64.match(/data:(image\/[^;]+);base64/)?.[1] || 'image/jpeg';
        parts.push({ inlineData: { data: base64Data, mimeType } });
      }

      const prompt = `You are an expert examiner creating practice multiple choice questions (MCQ) based on this diagram/card.
Card Title: "${title || 'Study Card'}"
Labels on Diagram: ${labels.length > 0 ? labels.join(', ') : 'Examine the diagram'}
Notes: "${notes || ''}"

Generate 3 high-yield multiple-choice questions in Bengali (বাংলা).
RETURN FORMAT: Return a JSON object with a "questions" array.
Each question object MUST contain:
- "question": string (the question in Bengali)
- "options": array of 4 strings (options A, B, C, D in Bengali)
- "correctIndex": integer (0, 1, 2, or 3 representing the correct option)
- "explanation": string (1-2 sentence explanation of why this is correct in Bengali)`;

      parts.push({ text: prompt });

      const response = await generateContentWithFallback(ai, {
        contents: { parts },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: "OBJECT",
            properties: {
              questions: {
                type: "ARRAY",
                items: {
                  type: "OBJECT",
                  properties: {
                    question: { type: "STRING" },
                    options: {
                      type: "ARRAY",
                      items: { type: "STRING" }
                    },
                    correctIndex: { type: "INTEGER" },
                    explanation: { type: "STRING" }
                  },
                  required: ["question", "options", "correctIndex", "explanation"]
                }
              }
            },
            required: ["questions"]
          }
        }
      });

      let rawResponseText = response?.text || '{"questions":[]}';
      rawResponseText = rawResponseText.replace(/^\s*```(?:json)?\n?/i, '').replace(/\n?```\s*$/i, '').trim();
      const parsed = JSON.parse(rawResponseText);
      res.json({ questions: parsed.questions || [] });
    } catch (err: any) {
      console.error('Quiz generation error:', err?.message || err);
      res.status(500).json({ error: 'AI কুইজ তৈরি করতে সমস্যা হয়েছে।' });
    }
  });

  // AI Auto-Title & Tag Suggestion (New Premium Feature)
  app.post("/api/suggest-card-metadata", async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { imageBase64 } = req.body;
      if (!imageBase64) return res.status(400).json({ error: 'No image provided' });

      const base64Data = imageBase64.replace(/^data:image\/[^;]+;base64,/, '');
      const mimeType = imageBase64.match(/data:(image\/[^;]+);base64/)?.[1] || 'image/jpeg';

      const prompt = `Analyze this educational study image/diagram.
Provide:
1. "title": A precise, descriptive card title in Bengali (e.g. "রুই মাছের রক্ত সংবহন তন্ত্র", "হৃৎপিণ্ডের লম্বচ্ছেদ", "নিউক্লিয়াসের গঠন").
2. "tags": Array of 2-4 relevant Bengali academic tags (e.g. ["প্রাণিবিজ্ঞান", "রুই মাছ", "HSC"]).
3. "summary": A 1-sentence brief summary of the topic in Bengali.

RETURN FORMAT: JSON with "title", "tags", and "summary".`;

      const response = await generateContentWithFallback(ai, {
        contents: {
          parts: [
            { inlineData: { data: base64Data, mimeType } },
            { text: prompt }
          ]
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: "OBJECT",
            properties: {
              title: { type: "STRING" },
              tags: {
                type: "ARRAY",
                items: { type: "STRING" }
              },
              summary: { type: "STRING" }
            },
            required: ["title", "tags"]
          }
        }
      });

      let rawResponseText = response?.text || '{}';
      rawResponseText = rawResponseText.replace(/^\s*```(?:json)?\n?/i, '').replace(/\n?```\s*$/i, '').trim();
      const parsed = JSON.parse(rawResponseText);
      res.json({
        title: parsed.title || '',
        tags: parsed.tags || [],
        summary: parsed.summary || ''
      });
    } catch (err: any) {
      console.error('Metadata suggestion error:', err?.message || err);
      res.status(500).json({ error: 'স্বয়ংক্রিয় তথ্য তৈরি করা সম্ভব হয়নি।' });
    }
  });

  // All-in-One Auto Bulk Processor: Generates Title, Notes, Quality masks in 1 fast Gemini call
  app.post("/api/auto-process-diagram", async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { imageBase64 } = req.body;
      if (!imageBase64) return res.status(400).json({ error: 'No image provided' });

      const base64Data = imageBase64.replace(/^data:image\/[^;]+;base64,/, '');
      const mimeType = imageBase64.match(/data:(image\/[^;]+);base64/)?.[1] || 'image/jpeg';

      const prompt = `You are an elite educational AI assisting students in creating high-yield flashcards from this study diagram or anatomy illustration.

TASK:
1. "title": Provide a concise, clear, and accurate Bengali title for this diagram (e.g. "রুই মাছের রক্ত সংবহন তন্ত্র", "হৃৎপিণ্ডের লম্বচ্ছেদ", "নিউক্লিয়াসের গঠন", "নেফ্রনের গঠন").
2. "notes": Provide structured, high-yield Bengali study notes formatted in markdown:
   📌 **মূল পরিচিতি**: 2-3 sentences explaining this diagram.
   🔍 **প্রধান চিহ্নিত অংশ ও কাজ**: Bullet points of key anatomical/scientific parts and their core functions.
   💡 **মনে রাখার ছন্দ/নেমোনিক (Mnemonic)**: An easy Bengali/English memory rhyme or trick.
   ⭐ **পরীক্ষার গুরুত্বপূর্ণ টিপস**: 2 top exam questions asked on this topic.
3. "boxes": Detect all diagram labels, anatomical pointer annotations, and organ callouts that need to be masked for image occlusion flashcards.
   Each item in "boxes" must have:
   - "box_2d": [ymin, xmin, ymax, xmax] as 4 integers from 0 to 1000 representing normalized bounding box coordinates.
   - "text": string of the exact label text (in Bengali or English scientific name).

BOUNDING BOX RULES (BENGALI OCR INSTRUCTIONS):
- EXCLUSION RULE: STRICTLY ONLY mask the specific short names/labels being pointed to by diagram lines. Under NO circumstances should you output bounding boxes for general paragraph texts, descriptions, entire figure captions (e.g., "চিত্র..."), or stray marker letters ("ক", "খ").
- ছবির মধ্যে থাকা নির্দিষ্ট শব্দ বা লেখাটি OCR ব্যবহার করে সঠিকভাবে শনাক্ত করো। শুধু সেই শব্দের দৃশ্যমান অক্ষরগুলোর ওপর নিখুঁতভাবে Mask (box_2d) বসাও।
- অক্ষরের আসল আকৃতি, বাংলা বর্ণ, কারচিহ্ন, ফলা, যুক্তাক্ষর, মাত্রা, দাঁড়ি ও প্রয়োজনীয় চিহ্নসহ পুরো শব্দটি Mask-এর মধ্যে থাকবে।
- Mask যেন অক্ষরের বাইরে অপ্রয়োজনীয় জায়গায় না যায়। শব্দের আশপাশের অন্য লেখা, লাইন, তীরচিহ্ন, ছবি, টেবিল, দাগ বা ব্যাকগ্রাউন্ড Mask করবে না। Mask খুব টাইট হবে এবং অক্ষরের কিনারা অনুসরণ করবে।
- Mask-এর চারপাশে অতিরিক্ত ফাঁকা জায়গা রাখবে না। Padding সর্বোচ্চ ১ থেকে ২ পিক্সেল হবে।
- লেখাটি ছোট, ঝাপসা, বাঁকা বা কম রেজোলিউশনের হলেও শব্দটি যাচাই করে যথাসম্ভব নির্ভুলভাবে Mask দাও।
- ZERO OVERLAP: One clean box per distinct anatomical label.

NOTE: Do NOT generate or include tags. Only generate title, notes, and boxes.`;

      const response = await generateContentWithFallback(ai, {
        contents: {
          parts: [
            { inlineData: { data: base64Data, mimeType } },
            { text: prompt }
          ]
        },
        config: {
          temperature: 0.1,
          responseMimeType: 'application/json',
          responseSchema: {
            type: "OBJECT",
            properties: {
              title: { type: "STRING" },
              notes: { type: "STRING" },
              boxes: {
                type: "ARRAY",
                items: {
                  type: "OBJECT",
                  properties: {
                    box_2d: {
                      type: "ARRAY",
                      items: { type: "INTEGER" }
                    },
                    text: { type: "STRING" }
                  },
                  required: ["box_2d", "text"]
                }
              }
            },
            required: ["title", "notes", "boxes"]
          }
        }
      });

      const cleanText = (response?.text || '{"title":"","notes":"","boxes":[]}')
        .replace(/^\s*```(?:json)?\n?/i, '')
        .replace(/\n?```\s*$/i, '')
        .trim();
        
      const parsed = JSON.parse(cleanText);

      // Coordinate normalization and validation
      const rawBoxes = parsed.boxes || [];
      const candidates = rawBoxes
        .map((item: any) => {
          let coords: number[] | null = null;
          let text: string = '';
          if (item && Array.isArray(item.box_2d) && item.box_2d.length === 4) {
            coords = item.box_2d;
            text = (item.text || '').trim();
          } else if (item && typeof item.ymin === 'number') {
            coords = [item.ymin, item.xmin, item.ymax, item.xmax];
            text = (item.text || '').trim();
          }
          if (!coords) return null;

          const [ymin, xmin, ymax, xmax] = coords.map(n => Math.round(Number(n)));
          if (isNaN(ymin) || isNaN(xmin) || isNaN(ymax) || isNaN(xmax)) return null;
          if (ymax <= ymin || xmax <= xmin) return null;
          if ((ymax - ymin) < 4 && (xmax - xmin) < 4) return null;

          const cleanText = text.replace(/^[\s\d•\-\.\*\"\']+|[\s\"\']+$/g, '').trim() || text;
          
          let finalYmin = Math.max(0, Math.min(1000, ymin));
          let finalXmin = Math.max(0, Math.min(1000, xmin));
          let finalYmax = Math.max(0, Math.min(1000, ymax));
          let finalXmax = Math.max(0, Math.min(1000, xmax));

          // AI models (especially Gemini 1.5) systematically underestimate the horizontal bounding boxes 
          // for Bengali words, often capturing only the first few syllables and cutting off the right side.
          // We calculate an estimated width based on string length and anchor to the left.
          if (cleanText.length > 0) {
            const h = finalYmax - finalYmin;
            const estimatedWidth = cleanText.length * h * 0.45;
            const currentWidth = finalXmax - finalXmin;
            
            if (currentWidth < estimatedWidth) {
              finalXmax = Math.min(1000, finalXmin + estimatedWidth);
            }
          }

          return {
            ymin: finalYmin,
            xmin: finalXmin,
            ymax: finalYmax,
            xmax: finalXmax,
            text: cleanText,
            labelType: 'label'
          };
        })
        .filter(Boolean);

      // Overlap resolution
      const resolvedBoxes: any[] = [];
      for (const box of candidates) {
        let merged = false;
        for (let i = 0; i < resolvedBoxes.length; i++) {
          const existing = resolvedBoxes[i];
          const overlap = evaluateOverlap(box, existing);
          if (overlap.shouldMerge) {
            resolvedBoxes[i] = {
              ymin: Math.min(box.ymin, existing.ymin),
              xmin: Math.min(box.xmin, existing.xmin),
              ymax: Math.max(box.ymax, existing.ymax),
              xmax: Math.max(box.xmax, existing.xmax),
              text: (existing.text && box.text && !existing.text.includes(box.text))
                ? `${existing.text} ${box.text}`.trim()
                : (existing.text || box.text),
              labelType: 'label'
            };
            merged = true;
            break;
          }
        }
        if (!merged) {
          resolvedBoxes.push(box);
        }
      }

      res.json({
        title: parsed.title?.trim() || 'চিত্র স্টাডি কার্ড',
        notes: parsed.notes?.trim() || '',
        boxes: resolvedBoxes
      });
    } catch (err: any) {
      console.error('Auto process diagram error:', err?.message || err);
      res.status(500).json({ error: 'স্বয়ংক্রিয় প্রসেসিংয়ে সমস্যা হয়েছে।' });
    }
  });

  // Temporary storage for server-side file downloads to prevent Android WebView/DownloadManager "download failed" with blob URLs
  const downloadStore = new Map<string, { filename: string; content: string; mimeType: string; expires: number }>();

  // Periodically clean expired downloads
  setInterval(() => {
    const now = Date.now();
    for (const [id, item] of downloadStore.entries()) {
      if (item.expires < now) {
        downloadStore.delete(id);
      }
    }
  }, 60000);

  app.post("/api/prepare-download", (req, res) => {
    try {
      const { filename, content, mimeType = "application/json" } = req.body;
      if (!content || !filename) {
        return res.status(400).json({ error: "Filename and content required" });
      }
      const id = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      downloadStore.set(id, {
        filename,
        content: typeof content === 'string' ? content : JSON.stringify(content, null, 2),
        mimeType,
        expires: Date.now() + 10 * 60 * 1000 // 10 minutes
      });
      res.json({
        success: true,
        downloadUrl: `/api/download-file/${id}/${encodeURIComponent(filename)}`
      });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "Failed to prepare download" });
    }
  });

  app.get("/api/download-file/:id/:filename", (req, res) => {
    const { id } = req.params;
    const item = downloadStore.get(id);
    if (!item) {
      return res.status(404).send("ডাউনলোড লিংকটির মেয়াদ শেষ হয়ে গেছে। দয়া করে অ্যাপ থেকে পুনরায় চেষ্টা করুন।");
    }
    const safeFilename = item.filename.replace(/["\r\n]/g, '_');
    res.setHeader("Content-Disposition", `attachment; filename="${safeFilename}"; filename*=UTF-8''${encodeURIComponent(safeFilename)}`);
    res.setHeader("Content-Type", `${item.mimeType}; charset=utf-8`);
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.send(item.content);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: "spa",
    });
    // Route /sw.js so any native WebView or PWA requesting /sw.js gets the active service worker
    app.get('/sw.js', (req, res, next) => {
      req.url = '/dev-sw.js?dev-sw';
      vite.middlewares(req, res, next);
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
