const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// fix addFolder
code = code.replace(
  "saveFolders([...folders, newFolder]);",
  "saveFolders([newFolder, ...folders]);"
);

// fix saveCardAction for new cards
code = code.replace(
  "saveCards([...cards, { ...card, createdAt: Date.now() }]);",
  "saveCards([{ ...card, createdAt: Date.now() }, ...cards]);"
);

// fix bulkCreateCards
code = code.replace(
  "saveCards([...cards, ...newCardsWithIds]);",
  "saveCards([...newCardsWithIds, ...cards]);"
);

fs.writeFileSync('src/App.tsx', code);
console.log('patched App.tsx order');
