const fs = require('fs');
const ts = require('typescript');

const code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');
const sourceFile = ts.createSourceFile(
  'CreateCard.tsx',
  code,
  ts.ScriptTarget.Latest,
  true,
  ts.ScriptKind.TSX
);

let hasError = false;
sourceFile.parseDiagnostics.forEach(diag => {
  hasError = true;
  const pos = sourceFile.getLineAndCharacterOfPosition(diag.start);
  console.log(`Error at line ${pos.line + 1}, col ${pos.character + 1}: ${ts.flattenDiagnosticMessageText(diag.messageText, '\\n')}`);
});
if (!hasError) console.log("No syntax errors");
