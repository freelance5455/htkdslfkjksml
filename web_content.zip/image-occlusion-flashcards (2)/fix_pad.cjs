const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

code = code.replace(
`          const wNorm = xmax - xmin;
          const hNorm = ymax - ymin;
          const xmax = Math.min(1000, box.xmax + padXNorm);
          const ymax = Math.min(1000, box.ymax + padYBottomNorm);`,
`          const wNorm = xmax - xmin;
          const hNorm = ymax - ymin;`
);

fs.writeFileSync('src/components/CreateCard.tsx', code);
