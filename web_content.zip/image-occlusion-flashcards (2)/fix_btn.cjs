const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

const targetBtn = `<button
                type="button"
                onClick={handleSaveAllAutoBulkCards}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/20 transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>✨ সব কার্ড ডেক-এ সেভ করুন ({autoBulkCompletedCards.length}টি)</span>
              </button>`;

const replacementBtn = `<button
                type="button"
                onClick={() => {
                  setShowAutoBulkSummary(false);
                  onCancel();
                }}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/20 transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>✨ ঠিক আছে (সেভ সম্পন্ন)</span>
              </button>`;

if (code.includes(targetBtn)) {
  code = code.replace(targetBtn, replacementBtn);
  fs.writeFileSync('src/components/CreateCard.tsx', code);
  console.log('Fixed btn');
} else {
  console.log('Btn not found');
}
