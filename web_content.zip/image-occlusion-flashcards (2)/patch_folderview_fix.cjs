const fs = require('fs');
let code = fs.readFileSync('src/components/FolderView.tsx', 'utf8');

const folderOld = `<div 
                  key={subfolder.id} 
                  onClick={() => onOpenFolder(subfolder.id)} 
                  className={\`bg-white p-4 rounded-xl shadow-sm border flex items-center justify-between cursor-pointer hover:shadow-md transition-all group \${isDragOver ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200' : 'border-gray-100'}\`}
                  draggable
                  onDragStart={(e) => handleDragStart(e, subfolder.id, 'folder')}
                  onDragOver={(e) => handleDragOver(e, subfolder.id)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, subfolder.id)}
                >`;

const folderNew = `<div 
                  key={subfolder.id} 
                  onClick={() => { if(isSelectionMode) toggleSelectFolder(subfolder.id); else onOpenFolder(subfolder.id); }} 
                  onPointerDown={(e) => {
                     if (e.button !== 0) return;
                     startPress(subfolder.id, 'folder');
                  }}
                  onPointerUp={cancelPress}
                  onPointerLeave={cancelPress}
                  onPointerCancel={cancelPress}
                  className={\`bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border flex items-center justify-between cursor-pointer hover:shadow-md transition-all group \${isSelectionMode && selectedFolders.includes(subfolder.id) ? 'border-blue-500 bg-blue-50 dark:bg-slate-700' : isDragOver ? 'border-blue-500 ring-2 ring-blue-200' : 'border-gray-100'}\`}
                  draggable={!isSelectionMode}
                  onDragStart={(e) => handleDragStart(e, subfolder.id, 'folder')}
                  onDragOver={(e) => handleDragOver(e, subfolder.id)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, subfolder.id)}
                >`;

const cardOld = `<div 
                  key={card.id} 
                  className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between group cursor-grab active:cursor-grabbing"
                  draggable
                  onDragStart={(e) => handleDragStart(e, card.id, 'card')}
                >`;

const cardNew = `<div 
                  key={card.id} 
                  onClick={() => { if(isSelectionMode) toggleSelectCard(card.id); }}
                  onPointerDown={(e) => {
                     if (e.button !== 0) return;
                     startPress(card.id, 'card');
                  }}
                  onPointerUp={cancelPress}
                  onPointerLeave={cancelPress}
                  onPointerCancel={cancelPress}
                  className={\`bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border flex items-center justify-between group cursor-pointer \${isSelectionMode && selectedCards.includes(card.id) ? 'border-blue-500 bg-blue-50 dark:bg-slate-700' : 'border-gray-100'}\`}
                  draggable={!isSelectionMode}
                  onDragStart={(e) => handleDragStart(e, card.id, 'card')}
                >`;

code = code.replace(folderOld, folderNew);
code = code.replace(cardOld, cardNew);
fs.writeFileSync('src/components/FolderView.tsx', code);
console.log('FolderView selection logic patched');
