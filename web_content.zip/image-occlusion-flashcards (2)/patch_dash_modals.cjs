const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

code = code.replace(
  "<p className=\"text-gray-600 mb-6\">আপনি কি নিশ্চিত যে এই {deleteType === 'folder' ? 'ফোল্ডার এবং এর সব কার্ড' : 'কার্ডটি'} ডিলিট করতে চান?</p>",
  "<p className=\"text-gray-600 mb-6\">আপনি কি নিশ্চিত যে {deleteConfirmId === -1 ? `নির্বাচিত ${selectedFolders.length} টি ফোল্ডার এবং ${selectedCards.length} টি কার্ড` : `এই ${deleteType === 'folder' ? 'ফোল্ডার এবং এর সব কার্ড' : 'কার্ডটি'}`} ডিলিট করতে চান?</p>"
);

code = code.replace(
  "if (deleteType === 'folder') onDeleteFolder(deleteConfirmId);\n                else onDelete(deleteConfirmId);",
  "if (deleteConfirmId === -1 && onDeleteMultiple) {\n                  if (selectedFolders.length > 0) onDeleteMultiple(selectedFolders, 'folder');\n                  if (selectedCards.length > 0) onDeleteMultiple(selectedCards, 'card');\n                  cancelSelection();\n                } else {\n                  if (deleteType === 'folder') onDeleteFolder(deleteConfirmId);\n                  else onDelete(deleteConfirmId);\n                }"
);

code = code.replace(
  "onMoveItem(moveItemData.id, null, moveItemData.type);",
  "if (moveItemData.id === -1 && onMoveMultiple) {\n                    if (selectedFolders.length > 0) onMoveMultiple(selectedFolders, null, 'folder');\n                    if (selectedCards.length > 0) onMoveMultiple(selectedCards, null, 'card');\n                    cancelSelection();\n                  } else {\n                    onMoveItem(moveItemData.id, null, moveItemData.type);\n                  }"
);

code = code.replace(
  "onMoveItem(moveItemData.id, folder.id, moveItemData.type);",
  "if (moveItemData.id === -1 && onMoveMultiple) {\n                      if (selectedFolders.length > 0) onMoveMultiple(selectedFolders, folder.id, 'folder');\n                      if (selectedCards.length > 0) onMoveMultiple(selectedCards, folder.id, 'card');\n                      cancelSelection();\n                    } else {\n                      onMoveItem(moveItemData.id, folder.id, moveItemData.type);\n                    }"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log('Modals patched');
