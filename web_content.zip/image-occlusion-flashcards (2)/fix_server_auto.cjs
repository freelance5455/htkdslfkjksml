const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetAutoParse = `          const [ymin, xmin, ymax, xmax] = coords.map(n => Math.round(Number(n)));
          if (isNaN(ymin) || isNaN(xmin) || isNaN(ymax) || isNaN(xmax)) return null;
          if (ymax <= ymin || xmax <= xmin) return null;

          return {
            ymin: Math.max(0, Math.min(1000, ymin)),
            xmin: Math.max(0, Math.min(1000, xmin)),
            ymax: Math.max(0, Math.min(1000, ymax)),
            xmax: Math.max(0, Math.min(1000, xmax)),
            text: text.replace(/^[\\s\\d•\\-\\.\\*\\"\\']+|[\\s\\"\\']+$/g, '').trim() || text,
            labelType: 'label'
          };`;

const replacementAutoParse = `          const [ymin, xmin, ymax, xmax] = coords.map(n => Math.round(Number(n)));
          if (isNaN(ymin) || isNaN(xmin) || isNaN(ymax) || isNaN(xmax)) return null;
          if (ymax <= ymin || xmax <= xmin) return null;
          if ((ymax - ymin) < 4 && (xmax - xmin) < 4) return null;

          const cleanText = text.replace(/^[\\s\\d•\\-\\.\\*\\"\\']+|[\\s\\"\\']+$/g, '').trim() || text;
          
          let finalYmin = Math.max(0, Math.min(1000, ymin));
          let finalXmin = Math.max(0, Math.min(1000, xmin));
          let finalYmax = Math.max(0, Math.min(1000, ymax));
          let finalXmax = Math.max(0, Math.min(1000, xmax));

          // AI models (especially Gemini 1.5) systematically underestimate the horizontal bounding boxes 
          // for Bengali words, often capturing only the first few syllables and cutting off the right side.
          // We calculate an estimated width based on string length and anchor to the left.
          if (cleanText.length > 0) {
            const h = finalYmax - finalYmin;
            const estimatedWidth = cleanText.length * h * 0.45;
            const currentWidth = finalXmax - finalXmin;
            
            if (currentWidth < estimatedWidth) {
              finalXmax = Math.min(1000, finalXmin + estimatedWidth);
            }
          }

          return {
            ymin: finalYmin,
            xmin: finalXmin,
            ymax: finalYmax,
            xmax: finalXmax,
            text: cleanText,
            labelType: 'label'
          };`;

code = code.replace(targetAutoParse, replacementAutoParse);

fs.writeFileSync('server.ts', code);
console.log('Fixed auto parse in server.ts');
