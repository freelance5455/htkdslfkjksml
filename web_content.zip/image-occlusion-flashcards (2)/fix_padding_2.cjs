const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

code = code.replace(/const padX = 2;/g, 'const padX = 15;');
code = code.replace(/const padY = 2;/g, 'const padY = 15;');

code = code.replace(/const padX = 8;/g, 'const padX = 15;');
code = code.replace(/const padY = 8;/g, 'const padY = 15;');

fs.writeFileSync('src/components/CreateCard.tsx', code);
console.log('Fixed padding to 15');
