const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');
console.log(code.includes('await Promise.resolve(onBulkCreate([newCard]));'));
