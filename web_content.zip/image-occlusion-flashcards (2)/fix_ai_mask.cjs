const fs = require('fs');
let code = fs.readFileSync('src/components/CreateCard.tsx', 'utf8');

code = code.replace(/const \[aiDetectMode.*?useState.*?;\n/g, '');
code = code.replace(/const \[showAiModeDropdown.*?useState.*?;\n/g, '');
code = code.replace(/mode: aiDetectMode/g, "mode: 'labels'"); // Default to labels

fs.writeFileSync('src/components/CreateCard.tsx', code);
