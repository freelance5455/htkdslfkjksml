NOVA STORE - Android app project

APK banane ke steps (laptop/PC pe, ek baar):
1. Android Studio (free) install karo: developer.android.com/studio
2. File > Open > is NovaStoreApp folder ko chuno. Pehli baar sync mein kuch minute lagte hain (internet chahiye).
3. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s)
4. Neeche "locate" pe click karo. APK yahan milegi:
   app/build/outputs/apk/debug/app-debug.apk
5. APK phone mein bhejo aur install karo (Unknown sources allow karna padega).

Website badalni ho: app/src/main/assets/index.html ko replace karo, phir dobara build karo.
