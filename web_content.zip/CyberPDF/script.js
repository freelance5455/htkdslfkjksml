// Configurazione PDF.js Worker
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

// URL Backend Vercel con Google Vision API
const GOOGLE_LENS_API_URL = 'https://ocr-backend-virid.vercel.app/api/ocr';

// Chiave API integrata
const GOOGLE_API_KEY = 'AIzaSyBkBtNVMQIhq9sfhn6DymYOSw-LeKrS-ro';

// Stato dell'applicazione
let pdfDoc = null;
let pageNum = 1;
let scale = 1.0;
let renderScale = 2.5; // High-DPI per massima nitidezza OCR
let transformX = 0;
let transformY = 0;

// Elementi DOM
const canvas = document.getElementById('pdf-canvas');
const ctx = canvas.getContext('2d');
const wrapper = document.getElementById('canvas-wrapper');
const container = document.getElementById('viewer-container');
const selectionBox = document.getElementById('selection-box');
const cardsContainer = document.getElementById('cards-container');

// Gestione Selezione e Gesture Touch
let isSelecting = false;
let startX = 0, startY = 0;
let endX = 0, endY = 0;

// Variabili per Pinch-to-Zoom e Pan a 2 dita
let initialPinchDistance = null;
let initialScale = 1.0;
let panStartX = 0, panStartY = 0;

// Caricamento PDF
document.getElementById('pdf-file-input').addEventListener('change', function(e) {
  const file = e.target.files[0];
  if (file && file.type === 'application/pdf') {
    const reader = new FileReader();
    reader.onload = function(ev) {
      const typedarray = new Uint8Array(ev.target.result);
      pdfjsLib.getDocument(typedarray).promise.then(pdf => {
        pdfDoc = pdf;
        document.getElementById('page-count').textContent = pdf.numPages;
        pageNum = 1;
        renderPage(pageNum);
      });
    };
    reader.readAsArrayBuffer(file);
  }
});

// Render della pagina PDF
function renderPage(num) {
  if (!pdfDoc) return;
  
  pdfDoc.getPage(num).then(page => {
    const viewport = page.getViewport({ scale: renderScale });
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    
    canvas.style.width = (viewport.width / renderScale) + 'px';
    canvas.style.height = (viewport.height / renderScale) + 'px';

    const renderContext = {
      canvasContext: ctx,
      viewport: viewport
    };

    page.render(renderContext).promise.then(() => {
      document.getElementById('page-num').textContent = num;
      updateTransform();
    });
  });
}

// Paginazione
document.getElementById('prev-page').addEventListener('click', () => {
  if (pageNum <= 1) return;
  pageNum--;
  renderPage(pageNum);
});

document.getElementById('next-page').addEventListener('click', () => {
  if (!pdfDoc || pageNum >= pdfDoc.numPages) return;
  pageNum++;
  renderPage(pageNum);
});

// Aggiorna trasformazione grafica (GPU Acceleration)
function updateTransform() {
  wrapper.style.transform = `translate(${transformX}px, ${transformY}px) scale(${scale})`;
  document.getElementById('zoom-val').textContent = Math.round(scale * 100) + '%';
}

// Pulsanti Zoom Manuali
document.getElementById('zoom-in').addEventListener('click', () => { scale *= 1.25; updateTransform(); });
document.getElementById('zoom-out').addEventListener('click', () => { scale /= 1.25; updateTransform(); });
document.getElementById('reset-view').addEventListener('click', () => { 
  scale = 1.0; 
  transformX = 0; 
  transformY = 0; 
  updateTransform(); 
});

// Helper per calcolo distanza pinch tra due dita
function getTouchDistance(touches) {
  const dx = touches[0].clientX - touches[1].clientX;
  const dy = touches[0].clientY - touches[1].clientY;
  return Math.sqrt(dx * dx + dy * dy);
}

// Coordinate relative al Canvas ad alta risoluzione
function getCanvasCoordinates(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const x = (clientX - rect.left) * (canvas.width / rect.width);
  const y = (clientY - rect.top) * (canvas.height / rect.height);

  return {
    x: Math.max(0, Math.min(x, canvas.width)),
    y: Math.max(0, Math.min(y, canvas.height)),
    cssX: (clientX - rect.left) / scale,
    cssY: (clientY - rect.top) / scale
  };
}

// GESTIONE TOUCH: SELEZIONE (1 DITO) vs PINCH/PAN (2 DITA)
container.addEventListener('touchstart', (e) => {
  if (!pdfDoc) return;

  if (e.touches.length === 2) {
    isSelecting = false;
    selectionBox.style.display = 'none';
    
    initialPinchDistance = getTouchDistance(e.touches);
    initialScale = scale;
    
    panStartX = ((e.touches[0].clientX + e.touches[1].clientX) / 2) - transformX;
    panStartY = ((e.touches[0].clientY + e.touches[1].clientY) / 2) - transformY;
  } else if (e.touches.length === 1) {
    isSelecting = true;
    const coords = getCanvasCoordinates(e.touches[0].clientX, e.touches[0].clientY);
    startX = coords.x;
    startY = coords.y;

    selectionBox.style.left = coords.cssX + 'px';
    selectionBox.style.top = coords.cssY + 'px';
    selectionBox.style.width = '0px';
    selectionBox.style.height = '0px';
    selectionBox.style.display = 'block';
  }
}, { passive: false });

container.addEventListener('touchmove', (e) => {
  if (e.touches.length === 2 && initialPinchDistance) {
    e.preventDefault();

    const currentDistance = getTouchDistance(e.touches);
    const factor = currentDistance / initialPinchDistance;
    scale = Math.min(Math.max(0.5, initialScale * factor), 5.0);

    const currentCenterX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
    const currentCenterY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
    transformX = currentCenterX - panStartX;
    transformY = currentCenterY - panStartY;

    updateTransform();
  } else if (e.touches.length === 1 && isSelecting) {
    const coords = getCanvasCoordinates(e.touches[0].clientX, e.touches[0].clientY);
    endX = coords.x;
    endY = coords.y;

    const rect = canvas.getBoundingClientRect();
    const currentCssX = (e.touches[0].clientX - rect.left) / scale;
    const currentCssY = (e.touches[0].clientY - rect.top) / scale;

    const startCssX = parseFloat(selectionBox.style.left);
    const startCssY = parseFloat(selectionBox.style.top);

    const width = Math.abs(currentCssX - startCssX);
    const height = Math.abs(currentCssY - startCssY);

    selectionBox.style.width = width + 'px';
    selectionBox.style.height = height + 'px';
    if (currentCssX < startCssX) selectionBox.style.left = currentCssX + 'px';
    if (currentCssY < startCssY) selectionBox.style.top = currentCssY + 'px';
  }
}, { passive: false });

container.addEventListener('touchend', (e) => {
  if (e.touches.length < 2) {
    initialPinchDistance = null;
  }

  if (isSelecting) {
    isSelecting = false;
    selectionBox.style.display = 'none';

    const width = Math.abs(endX - startX);
    const height = Math.abs(endY - startY);

    if (width > 15 && height > 15) {
      const x = Math.min(startX, endX);
      const y = Math.min(startY, endY);
      runOCR(x, y, width, height);
    }
  }
});

// MOUSE EVENTS (Per Desktop / Emulatori)
container.addEventListener('mousedown', (e) => {
  if (!pdfDoc) return;
  isSelecting = true;
  const coords = getCanvasCoordinates(e.clientX, e.clientY);
  startX = coords.x;
  startY = coords.y;

  selectionBox.style.left = coords.cssX + 'px';
  selectionBox.style.top = coords.cssY + 'px';
  selectionBox.style.width = '0px';
  selectionBox.style.height = '0px';
  selectionBox.style.display = 'block';
});

container.addEventListener('mousemove', (e) => {
  if (!isSelecting) return;
  const coords = getCanvasCoordinates(e.clientX, e.clientY);
  endX = coords.x;
  endY = coords.y;

  const rect = canvas.getBoundingClientRect();
  const currentCssX = (e.clientX - rect.left) / scale;
  const currentCssY = (e.clientY - rect.top) / scale;

  const startCssX = parseFloat(selectionBox.style.left);
  const startCssY = parseFloat(selectionBox.style.top);

  selectionBox.style.width = Math.abs(currentCssX - startCssX) + 'px';
  selectionBox.style.height = Math.abs(currentCssY - startCssY) + 'px';
  if (currentCssX < startCssX) selectionBox.style.left = currentCssX + 'px';
  if (currentCssY < startCssY) selectionBox.style.top = currentCssY + 'px';
});

window.addEventListener('mouseup', () => {
  if (isSelecting) {
    isSelecting = false;
    selectionBox.style.display = 'none';

    const width = Math.abs(endX - startX);
    const height = Math.abs(endY - startY);

    if (width > 15 && height > 15) {
      const x = Math.min(startX, endX);
      const y = Math.min(startY, endY);
      runOCR(x, y, width, height);
    }
  }
});

// FUNZIONE OCR GOOGLE LENS
async function runOCR(x, y, width, height) {
  const cropCanvas = document.createElement('canvas');
  cropCanvas.width = width;
  cropCanvas.height = height;
  const cropCtx = cropCanvas.getContext('2d');

  cropCtx.drawImage(
    canvas,
    x, y, width, height,
    0, 0, width, height
  );

  const base64Image = cropCanvas.toDataURL('image/png');
  const cardId = 'ocr-' + Date.now();

  addCard(cardId, base64Image, "⚡ Google Lens in elaborazione...");

  try {
    const response = await fetch(GOOGLE_LENS_API_URL, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 
        base64Image: base64Image, 
        apiKey: GOOGLE_API_KEY 
      })
    });

    const responseText = await response.text();
    let data;
    try {
      data = JSON.parse(responseText);
    } catch (e) {
      throw new Error("Risposta non valida dal server: " + responseText.substring(0, 100));
    }

    if (!response.ok) {
      throw new Error(data.error || 'Errore nella chiamata server (Status: ' + response.status + ')');
    }

    let extractedText = data.text ? data.text.trim() : '';

    const ocrMode = document.getElementById('ocr-mode-select').value;
    if (ocrMode === 'digits') {
      const numberMatches = extractedText.match(/\d{10,18}/g) || extractedText.match(/\d+/g);
      if (numberMatches) {
        extractedText = numberMatches.join('\n');
      } else {
        extractedText = extractedText.replace(/[^0-9 \n\r,.]/g, '');
      }
    }

    updateCard(cardId, extractedText || "[Nessun testo o numero rilevato]");
  } catch (err) {
    console.error("Errore OCR dettagliato:", err);
    updateCard(cardId, "[Errore OCR: " + err.message + "]");
  }
}

// Schede Risultati
function addCard(id, imageSrc, initialText) {
  const emptyState = cardsContainer.querySelector('.empty-state');
  if (emptyState) emptyState.remove();

  const card = document.createElement('div');
  card.className = 'ocr-card';
  card.id = id;
  card.dataset.page = pageNum;
  card.innerHTML = `
    <img src="${imageSrc}" class="card-preview" alt="Ritaglio">
    <div class="card-text">${initialText}</div>
    <div class="card-footer">
      <button class="copy-btn">📋 Copia Tasti / IMEI</button>
    </div>
  `;

  cardsContainer.prepend(card);
}

function updateCard(id, text) {
  const card = document.getElementById(id);
  if (!card) return;

  const textDiv = card.querySelector('.card-text');
  textDiv.textContent = text;

  const copyBtn = card.querySelector('.copy-btn');
  copyBtn.onclick = () => {
    navigator.clipboard.writeText(text).then(() => {
      copyBtn.textContent = '✅ Copiato negli appunti!';
      setTimeout(() => { copyBtn.textContent = '📋 Copia Tasti / IMEI'; }, 1500);
    }).catch(err => {
      console.error('Errore durante la copia:', err);
    });
  };
}

// --- LOGICA ESPORTAZIONE JSON (Compatibile Mobile e WebView) ---
document.getElementById('export-json-btn').addEventListener('click', () => {
  const cards = cardsContainer.querySelectorAll('.ocr-card');
  if (cards.length === 0) {
    alert("Nessun dato estratto da esportare!");
    return;
  }

  let itemsList = [];

  cards.forEach((card, index) => {
    const textContent = card.querySelector('.card-text').textContent.trim();
    const pageSource = card.dataset.page || "1";

    const lines = textContent.split(/\r?\n/).filter(line => line.trim() !== "");

    lines.forEach((line, lineIndex) => {
      itemsList.push({
        id: index + 1,
        lineIndex: lineIndex + 1,
        sourcePage: parseInt(pageSource),
        extractedValue: line.trim(),
        timestamp: new Date().toISOString()
      });
    });
  });

  const businessCentralPayload = {
    metadata: {
      sourceApp: "CyberPDF OCR Lens",
      exportDate: new Date().toISOString(),
      totalRecords: itemsList.length
    },
    lines: itemsList
  };

  const jsonString = JSON.stringify(businessCentralPayload, null, 2);
  const fileName = `BusinessCentral_Import_${Date.now()}.json`;

  try {
    const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
    
    if (navigator.canShare && navigator.canShare({ files: [new File([blob], fileName, { type: 'application/json' })] })) {
      const file = new File([blob], fileName, { type: 'application/json' });
      navigator.share({
        files: [file],
        title: 'Esportazione JSON Business Central',
        text: 'Ecco il file JSON con i dati estratti.'
      }).catch(err => console.log('Condivisione annullata', err));
    } else {
      const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(jsonString);
      const downloadLink = document.createElement('a');
      downloadLink.setAttribute('href', dataUri);
      downloadLink.setAttribute('download', fileName);
      downloadLink.style.display = 'none';
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    }
  } catch (err) {
    console.error("Errore durante l'esportazione del file:", err);
    prompt("Copia il codice JSON generato:", jsonString);
  }
});
