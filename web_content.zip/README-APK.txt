نجم الواحة - حزمة جاهزة للتحويل إلى APK
========================================

تم تجهيز هذه الحزمة بدون ES Modules أو روابط خارجية إجبارية لكي تعمل
مباشرة داخل Android WebView أو أي محول ZIP إلى APK أوفلاين بالكامل.

أهم الملفات في جذر الـ ZIP:
- index.html             (نقطة البداية المباشرة للعبة)
- app.js                 (كود اللعبة الكامل مدمج بصيغة IIFE متوافقة مع WebView)
- app.css                (تنسيقات اللعبة مدمجة بالكامل)
- assets/                (صور الخلفية والأصول)
- icon.png               (أيقونة التطبيق)
- config.xml             (إعدادات Cordova / VoltBuilder لبناء APK)
- manifest.json          (إعدادات تطبيق الويب)
- capacitor.config.json  (إعدادات Capacitor)

طرق التحويل إلى APK:
1. مواقع وبرامج تحويل ZIP إلى APK (مثل WebIntoApp أو Website 2 APK أو VoltBuilder):
   ارفع ملف الـ ZIP كما هو، وسيتم التعرف تلقائياً على index.html و config.xml و icon.png.
2. عبر Capacitor:
   ضع محتويات هذا الملف في مجلد www ثم نفّذ: npx cap add android && npx cap sync
