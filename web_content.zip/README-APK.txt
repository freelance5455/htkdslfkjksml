STUDY COMPANION — PJSA THEORY-ONLY EDITION
Optimised for Xiaomi Pad 8 Pro.

FEATURES
- Overview, weekly study target and saved study time
- Syllabus analysis with editable weekly hours for each theory subject
- Focus timer; only theory subjects appear in the subject selector
- Profile and scientific calculator
- Subject-wise YouTube teachers and learning links
- Daily 3-hour focus meter with manual reset and midnight rollover
- SA app icon and © Made by PJSA

THEORY SUBJECTS INCLUDED
1. Engineering Mathematics-III — 4 h/week
2. Manufacturing Technology — 2.5 h/week
3. Engineering Mechanics — 2.5 h/week
4. Strength of Materials — 3 h/week
5. Material Science and Smart Materials — 2.5 h/week (uploaded PDF covers Material Science only)
6. Engineering Thermodynamics — 2.5 h/week (official syllabus not supplied)
7. Effective Communication Skills — 1 h/week (teacher's group-message topics added)

DEFAULT WEEKLY THEORY TARGET: 18 HOURS.
Change any subject target in Study Analysis. The Overview total, Study Analysis total, and progress calculations update automatically. Use 0.5-hour increments, from 0 to 40 hours per subject. Changes save locally on the device.

LABS
All lab subjects and lab resources have been removed from this theory-only edition. Old saved lab timer sessions are excluded from the app totals.

SYLLABUS ACCURACY
The five uploaded PDFs provide unit-wise checklists for Mathematics-III, Manufacturing Technology, Engineering Mechanics, Strength of Materials and Material Science. Thermodynamics remains without a unit list because its syllabus was not supplied. Effective Communication Skills now includes the two topics and subtopics from Aashna's group message. The timetable says “Material Science and Smart Materials”, but the uploaded Material Science PDF does not show a separate Smart Materials unit.

YOUTUBE TEACHERS
- Mathematics-III: Dr. Gajendra Purohit; Tikle's Academy for extra numericals
- Engineering Mechanics: Mr. Deepak B.S.
- Strength of Materials: Mr. Hanumant Borate
- Manufacturing Technology: Dr. Sachin Bhosle
- Material Science: Dr. Shashank Shekhar (IIT Kanpur lecture-topic search)
- Engineering Thermodynamics: Dr. Avinash Kolekar
- Effective Communication Skills: Aashna is the course trainer; supplementary YouTube searches are included for self-introduction and listening-skills practice.
Links are YouTube channels or topic searches. These are subject-relevant recommendations, not an objective ranking or SRM endorsement.

DATA
Study sessions, profile details and checked topics are stored locally using browser storage. Clearing app data erases them. No cloud account or server is used.

UPLOAD AND BUILD APK
1. Extract this ZIP.
2. Upload the extracted contents to the root of your GitHub repository, preserving www and .github/workflows.
3. Commit changes to main.
4. Open Actions and run “Build Study Companion APK”.
5. After a successful run, download the study-companion-debug-apk artifact and extract app-debug.apk.

EFFECTIVE COMMUNICATION SKILLS — TEACHER'S GROUP MESSAGE
Topic 1: Self Introduction
- Basic biographical details (name, place, age and languages known)
- Educational qualifications (from what you are currently pursuing)
- Work experience (internship or job)
- Awards and certifications
- Skills (soft and hard skills)
- Hobbies (professional practices you follow)
- Goals and aspirations (where you see yourself in the next five years)

Topic 2: Listening Skills
- Role of listening skills in effective communication
- Barriers to listening skills
- Overcoming listening barriers
- Empathetic listening and avoiding selective listening

Presentation date stated in message: 21-09-2026.
External examination stated in message: 24-11-2026, afternoon shift, 1:30 PM–4:00 PM.
External faculty: Mr. Aakash Dahiya.
Soft Skill Trainer: Aashna.
These dates and details are transcribed from the teacher's message; check the class group for any later changes.
