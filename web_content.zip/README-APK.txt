STUDY COMPANION — PJSA THEORY-ONLY EDITION
Optimised for Xiaomi Pad 8 Pro.

FEATURES
- Overview, weekly study target and saved study time
- Syllabus analysis with editable weekly hours for each theory subject
- Focus timer; only theory subjects appear in the subject selector
- Profile and scientific calculator
- Subject-wise instructor references and offline learning guidance
- Daily 3-hour focus meter with manual reset and midnight rollover
- SA app icon and © Made by PJSA

THEORY SUBJECTS INCLUDED
1. Engineering Mathematics-III — 4 h/week
2. Manufacturing Technology — 2.5 h/week
3. Engineering Mechanics — 2.5 h/week
4. Strength of Materials — 3 h/week
5. Material Science and Smart Materials — 2.5 h/week (uploaded PDF covers Material Science only)
6. Engineering Thermodynamics — 2.5 h/week (official syllabus not supplied)
7. Effective Communication Skills — 1 h/week (teacher's group-message topics added)

DEFAULT WEEKLY THEORY TARGET: 18 HOURS.
Change any subject target in Study Analysis. The Overview total, Study Analysis total, and progress calculations update automatically. Use 0.5-hour increments, from 0 to 40 hours per subject. Changes save locally on the device.

LABS
All lab subjects and lab resources have been removed from this theory-only edition. Old saved lab timer sessions are excluded from the app totals.

SYLLABUS ACCURACY
The five uploaded PDFs provide unit-wise checklists for Mathematics-III, Manufacturing Technology, Engineering Mechanics, Strength of Materials and Material Science. Thermodynamics remains without a unit list because its syllabus was not supplied. Effective Communication Skills now includes the two topics and subtopics from Aashna's group message. The timetable says “Material Science and Smart Materials”, but the uploaded Material Science PDF does not show a separate Smart Materials unit.

INSTRUCTOR REFERENCES (OFFLINE)
- Mathematics-III: Dr. Gajendra Purohit; Tikle's Academy for extra numericals
- Engineering Mechanics: Mr. Deepak B.S.
- Strength of Materials: Mr. Hanumant Borate
- Manufacturing Technology: Dr. Sachin Bhosle
- Material Science: Dr. Shashank Shekhar (IIT Kanpur lecture-topic search)
- Engineering Thermodynamics: Dr. Avinash Kolekar
- Effective Communication Skills: Aashna is the course trainer; supplementary YouTube searches are included for self-introduction and listening-skills practice.
Links are Instructor names are retained as study references only. No external learning links are included in this offline edition.

DATA
Study sessions, profile details and checked topics are stored locally using browser storage. Clearing app data erases them. No cloud account, server, API, analytics, telemetry, advertising SDK or external network connection is used by the app.

UPLOAD AND BUILD APK
1. Extract this ZIP.
2. Upload the extracted contents to the root of your GitHub repository, preserving www and .github/workflows.
3. Commit changes to main.
4. Open Actions and run “Build Study Companion APK”.
5. After a successful run, download the study-companion-debug-apk artifact and extract app-debug.apk.

EFFECTIVE COMMUNICATION SKILLS — TEACHER'S GROUP MESSAGE
Topic 1: Self Introduction
- Basic biographical details (name, place, age and languages known)
- Educational qualifications (from what you are currently pursuing)
- Work experience (internship or job)
- Awards and certifications
- Skills (soft and hard skills)
- Hobbies (professional practices you follow)
- Goals and aspirations (where you see yourself in the next five years)

Topic 2: Listening Skills
- Role of listening skills in effective communication
- Barriers to listening skills
- Overcoming listening barriers
- Empathetic listening and avoiding selective listening

Presentation date stated in message: 21-09-2026.
External examination stated in message: 24-11-2026, afternoon shift, 1:30 PM–4:00 PM.
External faculty: Mr. Aakash Dahiya.
Soft Skill Trainer: Aashna.
These dates and details are transcribed from the teacher's message; check the class group for any later changes.


OFFLINE ACCOUNT AND SECURITY FEATURES (CURRENT BUILD)
- Local sign-up and login on this device only.
- Passwords are stored as PBKDF2-HMAC-SHA-256 hashes with random salts (310,000 iterations); plaintext passwords are not stored.
- Account recovery uses a one-time recovery code shown once at account creation. Store it privately. No SMS/email OTP is sent because this build has no OTP delivery server/API.
- Password reset is limited to 3 per local calendar day. This offline limit is a convenience control, not tamper-proof: clearing app data, reinstalling, or changing device time may bypass it.
- Delete study data and permanently delete the local account require the current password.
- App data is local to the Android app sandbox. It is not synced or uploaded.
- Content Security Policy blocks remote scripts, remote connections, object embeds and base URL injection. Calculator uses a restricted arithmetic parser rather than JavaScript eval/Function.
- Android build workflow disables Android backup and cleartext HTTP and adds a network security config that rejects cleartext traffic. No contacts, SMS, location, camera or microphone permission is required by this app.

SECURITY LIMITATIONS — PLEASE READ
This is an offline single-device account gate, not a server-authenticated identity system. There is no real email/SMS OTP, account recovery from another device, cloud sync, server-side rate limiting, or tamper-proof protection against a rooted/compromised Android device, malware with app access, physical access while unlocked, or someone who can extract/modify the APK. Local browser storage is not encrypted by this account layer. Do not reuse an important password. For stronger protection, use Android device screen lock and install only a signed release APK from a trusted source. The GitHub Actions artifact currently builds a DEBUG APK for testing; do not distribute it as a production-trusted release. A production release needs a private release keystore, signed release build, testing and a privacy policy.

ANDROID SECURITY BUILD
The GitHub Actions workflow runs scripts/harden_android.py after Capacitor sync. This applies Android manifest settings: allowBackup=false, usesCleartextTraffic=false and a network security configuration blocking cleartext HTTP. Review generated AndroidManifest.xml after build.


FULL OFFLINE / NO-NETWORK BUILD
- No app API integrations or backend endpoints.
- No Internet permission or network-state permissions in the Android manifest.
- No YouTube/external hyperlinks in the app UI; instructor names remain as offline references.
- No analytics, telemetry, ads, cloud sync, remote fonts, remote scripts or external SDKs.
- GitHub Actions and its build dependencies are used only to compile the APK; they are not part of the installed app runtime.


OFFLINE BACKUP & RESTORE (Option 3)
- Open My profile > Offline backup & restore.
- Export encrypted backup creates a .pjsabackup file protected by a separate passphrase (minimum 10 chars).
- Import the file on another device and enter the same passphrase. Import replaces the current local account, study data, calculator history and saved PDFs.
- The backup uses PBKDF2-SHA256 (310,000 iterations) and AES-256-GCM through Web Crypto. If secure Web Crypto is unavailable, backup/restore fails closed; it does not create plaintext backups.
- Keep the backup file and passphrase in separate safe places. Lost passphrase cannot be recovered. Export regularly after study sessions.
- Account identity remains local; this does not provide online email verification or automatic cloud sync.
