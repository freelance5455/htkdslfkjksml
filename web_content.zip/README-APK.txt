FORMULATRICE LITTÉRAIRE — PRÉPARATION APK

1. Le fichier web original est conservé sous :
   www/index.html

2. Une structure Android WebView est fournie dans :
   android/

3. Pour produire l'APK :
   - ouvrir le dossier android/ dans Android Studio
   - laisser Gradle synchroniser
   - Build > Build APK(s)

Le HTML n'a pas été réécrit : il est simplement copié comme index.html
et embarqué dans les assets Android.
