COMO VIRAR APK - 3 JEITOS

1) JEITO MAIS FÁCIL (2 minutos, sem instalar nada):
   - Vai em https://www.netlify.com/drop e arrasta a pasta www (ou hospeda o index.html)
   - Copia o link que ele gerar
   - Vai em https://www.pwabuilder.com
   - Cola o link > Package For Stores > Android > Download
   - Pronto, sai seu .APK

2) INSTALAR COMO APP SEM APK (teste rápido):
   - Abre o www/index.html no Chrome do Android
   - 3 pontinhos > Adicionar à tela inicial / Instalar app

3) CAPACITOR (profissional):
   npm i -g @capacitor/cli
   npx cap init MeuApp com.meuapp.app
   npx cap add android
   npx cap copy android
   npx cap open android (abre no Android Studio)

ESTRUTURA:
- www/index.html = SEU APP (edite aqui)
- manifest.json = nome, cor, ícone
- icon-*.png = ícones do app
- sw.js = funciona offline

Me diga qual app você quer (ex: barbearia, vendas, finanças) que eu já reescrevo o index.html com tudo pronto.
