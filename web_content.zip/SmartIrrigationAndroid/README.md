# Smart Irrigation Android app project

This project packages the connection-required Smart Irrigation dashboard into an Android WebView app.

## Easiest APK build without Android Studio on your own PC

This project includes a GitHub Actions workflow that builds a debug APK in the cloud. You still need to upload the project to a GitHub repository and start the workflow; this chat cannot sign in to your GitHub account or run builds on your behalf.

1. Download and extract `SmartIrrigationAndroidProject.zip`.
2. Sign in to GitHub and create a new repository (for example, `smart-irrigation-android`).
3. Upload the extracted project files and folders to the repository's main branch. Make sure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab.
5. Select **Build Smart Irrigation APK**, then **Run workflow** if it has not started automatically.
6. When the run finishes successfully, open that run and download the artifact named **Smart-Irrigation-debug-APK**.
7. Extract the downloaded artifact ZIP to find `app-debug.apk`, then transfer it to your Android phone and install it. Android may ask you to allow installation from that source.

Alternatively, use Android Studio: open this folder, let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The output is normally `app/build/outputs/apk/debug/app-debug.apk`.

## Important status
- This is Android source code plus a cloud-build workflow, not a compiled APK.
- The dashboard is bundled offline inside the app. It stays on the connection screen until it receives a valid response from the ESP32 API.
- The app does not control real hardware until compatible ESP32 firmware is installed and running.
- This is a prototype. Before field use, add device authentication and robust pump safety limits in the ESP32 firmware.

## ESP32 API expected by the dashboard
Base URL example: `http://192.168.4.1` (only a common default; use the address configured on your ESP32).

### GET `/api/status`
Return JSON:
```json
{
  "moisture": 42,
  "pump": false,
  "mode": "AUTO"
}
```
Requirements: `moisture` is a number from 0 to 100; `pump` is boolean; `mode` is exactly `AUTO` or `MANUAL`.

### POST `/api/control`
Accept JSON requests:
```json
{"mode":"AUTO"}
{"mode":"MANUAL"}
{"pump":"TOGGLE"}
```
Return the updated status if possible.

### CORS
The ESP32 HTTP server must handle `OPTIONS` preflight if needed and return headers such as:
- `Access-Control-Allow-Origin: *`
- `Access-Control-Allow-Methods: GET, POST, OPTIONS`
- `Access-Control-Allow-Headers: Content-Type`

For real deployment, do not rely on wildcard CORS or unauthenticated pump controls; authenticate trusted clients.

## Connection options
- **ESP32 access point:** connect the phone to the ESP32's Wi-Fi network and enter its actual IP address.
- **Same router:** connect the phone and ESP32 to the same Wi-Fi router and enter the ESP32's LAN IP.

## Safety
Use a low-voltage pump and suitable driver. Add maximum pump run-time, sensor fault handling, and ideally low-water detection in firmware. Never connect a mains-voltage pump directly to an ESP32.
