# Study Pro — Android

مشروع Android جاهز للبناء، مبني حول واجهة Study Pro العربية التي صُممت لتطابق الصورة المرجعية قدر الإمكان.

## البناء
1. افتح المجلد `StudyProAndroid` في Android Studio.
2. انتظر مزامنة Gradle.
3. اختر `Build > Build APK(s)`.
4. ستجد APK داخل `app/build/outputs/apk/`.

المشروع يحتاج Android SDK 35 وJDK مناسبًا لـ Android Studio.
