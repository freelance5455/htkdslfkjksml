EVSL Auto Maintenance Management – Advanced Professional v7 package

This package is a fresh copy of the latest multi-complaint / multi-part offline build.

Breakdown entry improvements included:
- Add multiple complaints under one vehicle/work entry.
- Record each complaint's problem, cause and action/solution separately.
- Add multiple parts used in the same entry.
- For each part, record part name, part number, quantity, unit and remarks.
- Edit saved breakdown entries, including complaint and parts lists.
- Breakdown list shows complaint count, parts count and complaint summary.
- Older single-complaint/single-part records remain supported.

Other included modules:
- Hindi / English language setting.
- Vehicle Master editing and hour meter.
- Item-wise PM schedules: hours, months, whichever earlier, and daily checks.
- Breakdown, welding, fabrication, new-part manufacturing, inventory, daily work report, fault diagnosis, analytics, JSON backup and restore.
- Offline local storage; no Firebase or internet account required.

Files:
- EVSL_Auto_Maintenance_Advanced_v7_Offline.html — open in a modern browser or compatible Android WebView wrapper.
- This is an offline HTML app package, NOT a signed Android APK.

Data safety:
- Export a JSON backup from the old app before switching.
- Restore that JSON backup in this version to carry old records forward.
- Data is stored locally on this device/browser. Clearing app/browser storage can erase it.
- APK update compatibility depends on the same Android package name and signing key.
