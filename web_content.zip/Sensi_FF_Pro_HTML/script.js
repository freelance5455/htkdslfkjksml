const profiles = {
  redmi9a: { "عام":90,"النقطة الحمراء":86,"منظار 2X":80,"منظار 4X":72,"منظار القناصة":48,"النظرة الحرة":65 },
  redmi13c: { "عام":94,"النقطة الحمراء":90,"منظار 2X":84,"منظار 4X":76,"منظار القناصة":52,"النظرة الحرة":70 },
  samsung: { "عام":92,"النقطة الحمراء":88,"منظار 2X":82,"منظار 4X":74,"منظار القناصة":50,"النظرة الحرة":68 },
  iphone: { "عام":96,"النقطة الحمراء":92,"منظار 2X":86,"منظار 4X":78,"منظار القناصة":54,"النظرة الحرة":72 },
  other: { "عام":90,"النقطة الحمراء":85,"منظار 2X":80,"منظار 4X":72,"منظار القناصة":48,"النظرة الحرة":65 }
};
let currentText = "";
function showSection(id){
  document.querySelectorAll('.section').forEach(s=>s.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
  document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active',b.dataset.target===id));
  if(id==="about") document.querySelector('.navbtn[data-target="about"]').classList.add('active');
}
function suggestSettings(){
  const key=document.getElementById('device').value;
  const data=profiles[key];
  const names={redmi9a:"Redmi 9A",redmi13c:"Redmi 13C",samsung:"Samsung Galaxy",iphone:"iPhone",other:"هاتف آخر"};
  let html="";
  currentText="الهاتف: "+names[key]+"\n";
  Object.entries(data).forEach(([k,v])=>{
    html+=`<div class="value"><span>${k}</span><strong>${v}</strong></div>`;
    currentText+=k+": "+v+"\n";
  });
  document.getElementById('values').innerHTML=html;
  document.getElementById('results').classList.remove('hidden');
  document.getElementById('copyMsg').textContent="";
}
async function copySettings(){
  try{await navigator.clipboard.writeText(currentText);document.getElementById('copyMsg').textContent="تم نسخ القيم."}
  catch(e){document.getElementById('copyMsg').textContent="تعذر النسخ تلقائياً؛ يمكنك نسخ القيم يدوياً."}
}
