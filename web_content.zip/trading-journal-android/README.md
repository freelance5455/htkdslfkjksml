# TradeJournal for Android

The same app, packaged for Android with Capacitor. Your trades are stored on the phone and work offline.

## Build an APK (Windows, Mac or Linux)

You need Node.js (18+), Java JDK 17+ and Android Studio.

1. Open a terminal in this folder.
2. `npm install @capacitor/core @capacitor/cli @capacitor/android`
3. `npx cap add android`
4. `npx cap sync`
5. `npx cap open android` opens Android Studio.
6. In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s). The debug APK appears under android/app/build/outputs/apk/debug/. Copy it to your phone and install it (allow installs from unknown sources).

For Google Play, use Build > Generate Signed Bundle / APK and upload the .aab.

## Quick alternative: install as a web app (no Android Studio)

Upload the `www` folder to any HTTPS host (GitHub Pages, Netlify, Cloudflare Pages). Open it in Chrome on Android, then menu > Install app. It opens full screen and works offline.

## After you edit the app

Change `www/index.html`, then run `npx cap sync` and rebuild.

## Not included yet

Cloud sync, biometric lock and background push notifications need native plugins or a server (for example @capacitor/local-notifications and capacitor-native-biometric). Ask for them as the next step.
