const MemoryV1 = {
  version: 1,

  create(type, text, options = {}) {
    const allowed = ['fact', 'episode', 'plan'];
    if (!allowed.includes(type)) {
      throw new Error('Неизвестный тип памяти');
    }

    return {
      id: crypto.randomUUID(),
      type,
      text: String(text).trim().slice(0, 1000),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: options.status || 'active',
      tags: Array.isArray(options.tags)
        ? options.tags.slice(0, 10)
        : []
    };
  },



  findDuplicatePlan(items, text, dueDate) {
    const normalize = value => String(value)
      .toLowerCase()
      .replace(/[.,!?]/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    return items.find(item =>
      item.type === 'plan' &&
      item.status === 'pending' &&
      item.dueDate === dueDate &&
      normalize(item.text) === normalize(text)
    ) || null;
  },

  addPlan(text, dueDate) {
    const plan = this.create('plan', text, {
      status: 'pending'
    });
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dueDate) ||
        !Number.isFinite(Date.parse(dueDate + 'T12:00:00Z'))) {
      throw new Error('Неверная дата плана');
    }
    plan.dueDate = dueDate;
    return plan;
  },

  getDuePlans(items, today) {
    return items.filter(item =>
      item.type === 'plan' &&
      item.status === 'pending' &&
      typeof item.dueDate === 'string' &&
      item.dueDate <= today
    );
  },


  cancelPlan(item) {
    if (!item || item.type !== 'plan') {
      throw new Error('Это не план');
    }

    return {
      ...item,
      status: 'cancelled',
      updatedAt: new Date().toISOString()
    };
  },

  completePlan(item) {
    if (item.type !== 'plan') {
      throw new Error('Это не план');
    }
    return {
      ...item,
      status: 'completed',
      updatedAt: new Date().toISOString()
    };
  },



  findPlansForUpdate(items, message, limit = 3) {
    const actions = {
      buy: /куп|покуп|приобр|заказ/,
      repair: /почин|чин|ремонт|исправ/,
      sell: /прод|прода|продаж/,
      watch: /смотр|посмотр|просмотр/,
      visit: /поед|ехать|езд|посет/
    };

    const detectAction = text => {
      const s = String(text).toLowerCase();
      for (const [action, pattern] of Object.entries(actions)) {
        if (pattern.test(s)) return action;
      }
      return null;
    };

    const normalize = text => String(text)
      .toLowerCase()
      .match(/[а-яёa-z0-9]{4,}/g) || [];

    const ignored = new Set([
      'завтра','сегодня','вчера','послезавтра',
      'планирую','собираюсь','передумал',
      'отменил','отменила','отменяю',
      'сделал','сделала','насчёт','планы'
    ]);

    const words = text => normalize(text)
      .filter(w => !ignored.has(w))
      .filter(w => !Object.values(actions).some(re => re.test(w)));

    const queryAction = detectAction(message);
    const queryWords = words(message);

    if (!queryWords.length) return [];

    return items
      .filter(item =>
        item.type === 'plan' &&
        item.status === 'pending'
      )
      .map(item => {
        const planAction = detectAction(item.text);

        if (queryAction && planAction !== queryAction) {
          return { item, score: 0 };
        }

        const planWords = words(item.text);
        const score = queryWords.filter(word =>
          planWords.some(w =>
            w === word ||
            (word.length >= 5 &&
             w.length >= 5 &&
             w.slice(0,4) === word.slice(0,4))
          )
        ).length;

        return { item, score };
      })
      .filter(x => x.score > 0)
      .sort((a,b) => b.score-a.score)
      .slice(0,limit)
      .map(x => x.item);
  },

  search(items, query, limit = 10) {
    const words = String(query)
      .toLowerCase()
      .match(/[а-яёa-z0-9]{3,}/g) || [];

    return items
      .map(item => {
        const content = (
          item.text + ' ' + (item.tags || []).join(' ')
        ).toLowerCase();

        const score = words.reduce(
          (sum, word) => sum + (content.includes(word) ? 1 : 0),
          0
        );

        return { item, score };
      })
      .filter(result => result.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
      .map(result => result.item);
  }
};

if (typeof module !== 'undefined') {
  module.exports = MemoryV1;
}

if (typeof window !== 'undefined') window.MemoryV1 = MemoryV1;
