/* Aldeia do Reino v5 — motor determinístico de crônicas e finais ramificados.
 * Sem dependências externas; compatível com navegador e Node.js.
 */
export const CHOICES = {
  protect: { title: 'Proteger Cinzaviva', effects: { mercy: 3, bond: 2, region: 2 }, flag: 'protectedVillage', line: 'Você jurou proteger Cinzaviva, mesmo sem saber quem ainda merece ser salvo.' },
  investigate: { title: 'Buscar a verdade', effects: { wisdom: 3, mystery: 2, knowledge: 2 }, flag: 'truthSeeker', line: 'Você decidiu seguir as pistas até a origem da névoa.' },
  pact: { title: 'Negociar com as criaturas', effects: { kinship: 3, mercy: 1, bond: 1 }, flag: 'beastPact', line: 'Você ofereceu diálogo onde outros só levariam aço.' },
  dominate: { title: 'Tomar o poder da névoa', effects: { ambition: 3, brutality: 2, mystery: 1 }, flag: 'claimedMist', line: 'Você escolheu dominar a névoa, mesmo que ela também passe a dominar você.' },
  unite: { title: 'Unir as facções', effects: { alliance: 3, bond: 2, wisdom: 1 }, flag: 'unitedFactions', line: 'Você tentou transformar rivais em aliados.' },
  release: { title: 'Libertar Fagulha', effects: { guideTrust: 3, mercy: 1, wisdom: 1 }, flag: 'freedGuide', line: 'Você libertou Fagulha de um juramento que ela nunca contou por inteiro.' },
  burn: { title: 'Destruir a relíquia', effects: { mercy: 2, brutality: 1, mystery: -2 }, flag: 'destroyedRelic', line: 'Você destruiu a relíquia antes que alguém pudesse usá-la novamente.' },
  remember: { title: 'Preservar as memórias', effects: { memory: 3, wisdom: 1, bond: 1 }, flag: 'preservedMemories', line: 'Você decidiu que nenhuma lembrança seria apagada sem testemunha.' },
  exile: { title: 'Abandonar a região', effects: { freedom: 3, bond: -1, region: -1 }, flag: 'leftRegion', line: 'Você escolheu a estrada aberta, deixando que a região enfrentasse seu próprio destino.' },
  sacrifice: { title: 'Pagar o preço por alguém', effects: { mercy: 3, memory: 1, guideTrust: 1 }, flag: 'madeSacrifice', line: 'Você aceitou pagar um preço pessoal para que outra vida pudesse continuar.' },
  bargain: { title: 'Fazer um acordo secreto', effects: { mystery: 2, ambition: 1, alliance: 1 }, flag: 'secretBargain', line: 'Você fez um acordo cujas condições completas só serão reveladas no fim.' },
  balance: { title: 'Manter o equilíbrio', effects: { wisdom: 2, mercy: 1, kinship: 1, alliance: 1 }, flag: 'soughtBalance', line: 'Você decidiu que nenhum povo deveria governar sozinho sobre os demais.' }
};

export const ENDINGS = [
  { id:'dawn-warden', title:'A Guardiã do Amanhecer', text:'Cinzaviva sobreviveu porque você protegeu seus habitantes sem entregar a região ao medo. Fagulha permanece como uma pequena luz nos portões, mas agora escolhe para onde ir.', score:s=>3*s.mercy+2*s.bond+s.region+2*(s.flags.protectedVillage?4:0)+s.flags.madeSacrifice*2, condition:s=>s.mercy>=3&&s.bond>=1 },
  { id:'mist-crowned', title:'A Coroa da Névoa', text:'Você tomou para si o poder que mantinha a região em ruínas. As estradas ficam seguras — desde que ninguém desafie sua vontade. A névoa obedece, mas nunca esquece.', score:s=>4*s.ambition+2*s.brutality+2*(s.flags.claimedMist?5:0)-s.mercy, condition:s=>s.ambition>=3 },
  { id:'beast-kin', title:'Parentes das Feras', text:'Os monstros deixam de ser apenas uma ameaça. Um pacto frágil nasce entre espécies que aprenderam a temer a mesma coisa. Os viajantes contam que olhos luminosos agora vigiam a floresta ao seu lado.', score:s=>4*s.kinship+2*(s.flags.beastPact?5:0)+s.mercy+s.bond, condition:s=>s.kinship>=3 },
  { id:'last-scholar', title:'O Último Arquivista', text:'Você reuniu pistas que ninguém ousava comparar e descobriu que a névoa é uma prisão construída sobre memórias roubadas. A verdade é salva, embora poucos estejam preparados para ouvi-la.', score:s=>4*s.wisdom+3*s.knowledge+2*s.mystery+2*(s.flags.truthSeeker?4:0), condition:s=>s.wisdom>=3&&s.knowledge>=2 },
  { id:'free-spark', title:'A Luz Sem Correntes', text:'Fagulha recupera uma memória antiga: ela não foi enviada para guiar heróis, mas para impedir que alguém chegasse ao coração da névoa. Ao libertá-la, você permite que ela escolha seu próprio destino — e ela escolhe ficar.', score:s=>5*s.guideTrust+2*s.mercy+2*(s.flags.freedGuide?5:0), condition:s=>s.guideTrust>=3 },
  { id:'many-banners', title:'O Pacto das Três Bandeiras', text:'As facções deixam de disputar cada pedra e passam a proteger caminhos em conjunto. Não é paz perfeita: é uma paz que precisa ser renovada todos os dias, e pela primeira vez isso parece possível.', score:s=>4*s.alliance+2*s.bond+2*(s.flags.unitedFactions?5:0), condition:s=>s.alliance>=3 },
  { id:'memory-keeper', title:'Aquele que Não Esqueceu', text:'Você preserva os nomes dos desaparecidos e devolve à região uma história que não pode mais ser apagada por completo. A névoa recua quando as pessoas começam a lembrar juntas.', score:s=>4*s.memory+3*s.wisdom+2*(s.flags.preservedMemories?5:0), condition:s=>s.memory>=3 },
  { id:'ashless', title:'Cinzas Sobre a Água', text:'A relíquia é destruída. O poder que ela guardava se dispersa, levando junto parte dos segredos da região. Nem todos são salvos, mas ninguém poderá voltar a usar aquele artefato para controlar os outros.', score:s=>3*s.mercy+2*s.brutality+2*(s.flags.destroyedRelic?5:0)-s.ambition, condition:s=>!!s.flags.destroyedRelic },
  { id:'road-beyond', title:'A Estrada Sem Retorno', text:'Você atravessa a última ponte antes do amanhecer. Cinzaviva fica para trás, mas os rumores viajam mais rápido que você: sua partida também se tornou uma decisão que mudou a região.', score:s=>4*s.freedom+2*(s.flags.leftRegion?5:0)-s.bond, condition:s=>s.freedom>=3 },
  { id:'quiet-balance', title:'O Equilíbrio Improvável', text:'Nenhuma força vence por completo. Aldeões, aventureiros e criaturas continuam discordando, mas o mundo já não depende de uma única vontade. Fagulha diz que este é o final mais difícil de manter — e talvez o mais vivo.', score:s=>3*s.wisdom+2*s.mercy+2*s.kinship+2*s.alliance+2*(s.flags.soughtBalance?5:0), condition:s=>s.wisdom>=2&&s.mercy>=1&&s.kinship>=1&&s.alliance>=1 },
  { id:'shadow-bargain', title:'O Nome no Contrato', text:'O acordo secreto cobra seu preço: uma lembrança querida é removida do mundo, mas uma passagem se abre para os desaparecidos. Você vence sem saber se foi você quem escolheu as condições.', score:s=>4*s.mystery+3*s.ambition+2*(s.flags.secretBargain?5:0), condition:s=>!!s.flags.secretBargain },
  { id:'unwritten', title:'O Final Ainda Não Escrito', text:'Você recusa os caminhos mais óbvios. A região permanece transformada, mas nenhuma facção, criatura ou guia consegue explicar o que virá. Pela primeira vez, o próximo capítulo não parece pertencer a ninguém.', score:s=>s.mercy+s.wisdom+s.kinship+s.alliance+s.freedom+s.memory+s.guideTrust+1, condition:()=>true }
];

const metricNames = ['mercy','wisdom','kinship','ambition','brutality','alliance','bond','mystery','memory','freedom','guideTrust','knowledge','region'];
export function createChronicle(seed = Math.floor(Math.random()*0x7fffffff), previous = null) {
  if (previous && previous.version === 5) return previous;
  const metrics = Object.fromEntries(metricNames.map(k=>[k,0]));
  return {version:5,seed,metrics,flags:{},decisions:[],events:[],relationships:{},ending:null,chapter:1,createdAt:Date.now(),guide:{name:['Fagulha','Lume','Pirilume','Brasa'][Math.abs(seed)%4],mood:['curiosa','cautelosa','melancólica','irreverente'][Math.abs(seed>>3)%4],trust:0}};
}
export function applyChoice(state, choiceId) {
  const choice = CHOICES[choiceId]; if (!choice) throw new Error(`Escolha desconhecida: ${choiceId}`);
  for (const [k,v] of Object.entries(choice.effects)) state.metrics[k]=(state.metrics[k]||0)+v;
  state.flags[choice.flag]=true;
  state.decisions.push({id:choiceId,title:choice.title,at:Date.now()});
  state.events.push(choice.line);
  state.chapter=Math.min(6,1+Math.floor(state.decisions.length/2));
  if(state.events.length>60)state.events=state.events.slice(-60);
  return state;
}
export function recordEncounter(state, entity, action, detail='') {
  const key=entity?.id||entity?.name||entity?.species||'ser desconhecido';
  const rel=state.relationships[key]||(state.relationships[key]={trust:0,fear:0,friendship:0,memories:[],lastAction:''});
  const changes={talk:{trust:1,fear:-1,friendship:1},gift:{trust:2,fear:-2,friendship:3},calm:{trust:1,fear:-3,friendship:1},listen:{trust:2,fear:-1,friendship:2},attack:{trust:-3,fear:1,friendship:-3},threaten:{trust:-2,fear:3,friendship:-2},help:{trust:3,fear:-2,friendship:3},ignore:{trust:0,fear:0,friendship:0}}[action]||{trust:0,fear:0,friendship:0};
  for(const k of ['trust','fear','friendship']) rel[k]=Math.max(-100,Math.min(100,rel[k]+changes[k]));
  rel.lastAction=action; rel.memories.push({action,detail:String(detail).slice(0,240),at:Date.now()}); if(rel.memories.length>20)rel.memories.shift();
  state.events.push(`${key}: ${action}${detail?` — ${detail}`:''}`); if(state.events.length>60)state.events.shift();
  return rel;
}
export function chooseEnding(state, base={}) {
  const s={...state.metrics,...state,flags:state.flags||{},...base};
  const available=ENDINGS.filter(e=>e.condition(s));
  const ranked=available.map(e=>({ending:e,score:e.score(s)})).sort((a,b)=>b.score-a.score);
  return {...ranked[0].ending,score:ranked[0].score,alternatives:ranked.slice(1,4).map(x=>({id:x.ending.id,title:x.ending.title,score:x.score}))};
}
export function guideDirection(state) {
  const m=state.metrics, f=state.flags;
  if((m.ambition||0)>=3)return 'A névoa responde ao seu desejo de poder. Procure a relíquia, mas pergunte a si mesmo quem está escolhendo quem.';
  if((m.kinship||0)>=3)return 'As criaturas começaram a reconhecer sua presença. Encontre a Sentinela Oca e ofereça uma trégua antes da próxima disputa territorial.';
  if((m.alliance||0)>=3)return 'As facções estão próximas de um acordo. Leve uma prova da capela às três bandeiras antes que o rumor vire acusação.';
  if((m.memory||0)>=3)return 'Há nomes escondidos nos registros da aldeia. Compare o diário de Nara com as marcas na casa abandonada.';
  if((m.wisdom||0)>=3)return 'Você já reuniu pistas suficientes para formular uma pergunta melhor. Vá às ruínas e observe antes de tocar nas runas.';
  if(f.leftRegion)return 'Você escolheu a estrada, mas os rumores ainda seguem você. O próximo rumo começa com aquilo que decidiu deixar para trás.';
  return `A crônica de ${state.guide?.name||'Fagulha'} ainda não escolheu um destino. ${state.events.at(-1)||'Procure uma testemunha que tenha medo de contar o que viu.'}`;
}
export function getMetrics(state){return Object.entries(state.metrics).map(([key,value])=>({key,value}));}
