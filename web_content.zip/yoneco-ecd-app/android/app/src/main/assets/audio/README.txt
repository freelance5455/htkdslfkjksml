AUDIO FOLDERS

audio/animals/  -> real animal sounds. Name them cow, dog, cat, duck, sheep, lion, elephant, bird  (.mp3 .ogg .wav or .m4a).
audio/songs/    -> real sung recordings, named by song, e.g. twinkle-twinkle-little-star.mp3 (see list below).
audio/ny/       -> Chichewa recordings. Use the SAME file name as the English file in audio/en/ (e.g. monday.mp3 for Lolemba).
audio/en/       -> English voice (computer-generated). You may replace any file with a real recording of the same name.

SONG FILE NAMES
twinkle-twinkle-little-star.mp3
row-row-row-your-boat.mp3
baa-baa-black-sheep.mp3
old-macdonald-had-a-farm.mp3
itsy-bitsy-spider.mp3
mary-had-a-little-lamb.mp3
hickory-dickory-dock.mp3
humpty-dumpty.mp3
jack-and-jill.mp3
the-wheels-on-the-bus.mp3
