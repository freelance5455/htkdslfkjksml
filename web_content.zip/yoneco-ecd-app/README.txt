YONECO ECD APP

FIXES INCLUDED
- Fixed the missing esc() function that could break speaker buttons and sections.
- Made speech controls fail safely when speech synthesis is unavailable.
- Added a PWA manifest and offline service worker.
- Added a native Android WebView project for an APK build.
- The Android wrapper loads the HTML locally, so the learning content itself works without internet.

SECTIONS
Songs, Days & Calendar, Shapes Game, Numbers, Animal Sounds, Weather,
Guess the Picture, Parents' Corner, Body Parts, and Community Helpers.

BUILD APK
Open the android/ folder in Android Studio and build a Debug APK.
Or, with a compatible Android SDK + Gradle environment:
    cd android
    gradle assembleDebug
The APK will be:
    app/build/outputs/apk/debug/app-debug.apk

PWA
Serve the main folder over HTTPS, then open it in Chrome and use
"Install app"/"Add to Home screen".

V2: synthesized animal sounds (no files needed), success sounds + confetti + star counter, Chichewa for all sections (please have a Chichewa speaker review), Android text-to-speech bridge, PNG icons.

V3: all spoken words are pre-recorded MP3 files in audio/ (works offline, no phone speech engine needed). Drop real clips into audio/animals, audio/songs, audio/ny — see audio/README.txt.
V4: real animal sound recordings (audio/animals).
