export type ChatType = 'direct' | 'group' | 'channel' | 'community' | 'broadcast';

export type MessageType = 
  | 'text' 
  | 'image' 
  | 'video' 
  | 'audio' 
  | 'location' 
  | 'live_location'
  | 'document' 
  | 'contact' 
  | 'poll' 
  | 'sticker' 
  | 'call_log';

export interface UserProfile {
  id: string;
  name: string;
  handle: string;
  phone: string;
  email: string;
  avatar: string;
  bio: string;
  isOnline: boolean;
  lastSeen: string;
  passkeyEnrolled: boolean;
  twoFactorEnabled: boolean;
  pinLockEnabled: boolean;
  biometricLockEnabled: boolean;
  verifiedBadge: boolean;
}

export interface Reaction {
  emoji: string;
  userId: string;
  userName: string;
}

export interface PollOption {
  id: string;
  text: string;
  votes: string[]; // user IDs
}

export interface PollData {
  question: string;
  options: PollOption[];
  isMultipleChoice: boolean;
  isQuiz?: boolean;
  correctOptionId?: string;
  totalVotes: number;
}

export interface LiveLocationData {
  isSharing: boolean;
  lat: number;
  lng: number;
  accuracyMeters: number;
  speedKmh: number;
  startedAt: number;
  durationMinutes: number;
  expiresAt: number;
  batteryLevel: number;
  address: string;
  isEmergency?: boolean;
}

export interface ActiveLocationTraceSession {
  sessionId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  chatId: string;
  chatTitle: string;
  lat: number;
  lng: number;
  speedKmh: number;
  headingDeg: number;
  accuracyMeters: number;
  batteryLevel: number;
  connectionStatus: 'live' | 'buffering' | 'stale' | 'offline';
  connectionLatencyMs: number;
  isEmergency?: boolean;
  lastUpdatedTimestamp: number;
  consentVerification: {
    verifiedAt: string;
    verifiedSignature: string;
    consentType: 'explicit_runtime' | 'emergency_sos';
    recipientScope: string;
    expiresAt: number;
  };
  currentStreetAddress: string;
  trailHistory: { lat: number; lng: number; timestamp: number }[];
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  type: MessageType;
  text?: string;
  timestamp: string;
  status: 'sending' | 'sent' | 'delivered' | 'read';
  mediaUrl?: string;
  mediaSize?: string;
  mediaDuration?: string;
  fileName?: string;
  reactions: Reaction[];
  replyTo?: {
    id: string;
    senderName: string;
    text: string;
  };
  pollData?: PollData;
  locationData?: LiveLocationData;
  contactData?: {
    name: string;
    phone: string;
    avatar?: string;
  };
  isEdited?: boolean;
  isStarred?: boolean;
  isBookmarked?: boolean;
  isPinned?: boolean;
  isDeletedForEveryone?: boolean;
  isScheduled?: boolean;
  scheduledFor?: string;
}

export interface ChatThread {
  id: string;
  type: ChatType;
  title: string;
  avatar: string;
  lastMessage?: Message;
  unreadCount: number;
  isPinned: boolean;
  isMuted: boolean;
  isArchived: boolean;
  disappearingTimerDays?: number; // e.g. 1, 7, 90 or 0
  participants: UserProfile[];
  adminIds: string[];
  description?: string;
  createdAt: string;
  draftText?: string;
}

export interface StoryStatus {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  type: 'text' | 'image' | 'video' | 'voice';
  contentUrl?: string;
  textCaption?: string;
  bgColor?: string;
  timestamp: string;
  expiresAt: string;
  viewersCount: number;
  isViewed: boolean;
  musicTrack?: string;
}

export interface GhostModeSettings {
  enabled: boolean;
  hideOnlineStatus: boolean;
  hideLastSeen: boolean;
  disableReadReceipts: boolean;
  hideTypingIndicator: boolean;
  hideRecordingIndicator: boolean;
  privateNotificationPreviews: boolean;
  appLockRequired: boolean;
  screenshotProtection: boolean;
  invisibleChatVault: boolean;
  autoDeleteOldMedia: boolean;
}

export interface CallParticipant {
  id: string;
  name: string;
  avatar: string;
  isMuted: boolean;
  isVideoOff: boolean;
  isScreenSharing?: boolean;
}

export interface CallSession {
  id: string;
  chatId: string;
  type: 'voice' | 'video' | 'group';
  status: 'idle' | 'calling' | 'ringing' | 'connected' | 'ended';
  isIncoming: boolean;
  participants: CallParticipant[];
  startTime?: number;
  durationSeconds: number;
  isMuted: boolean;
  isSpeaker: boolean;
  isVideoMuted: boolean;
  isScreenSharing: boolean;
  networkQuality: 'excellent' | 'good' | 'fair';
}

export type UserRole = 'super_admin' | 'moderator' | 'support' | 'member';

export type UserStatus = 'active' | 'suspended' | 'flagged' | 'pending_verification';

export interface AdminPermissions {
  canManageUsers: boolean;
  canRevokeSessions: boolean;
  canViewAuditLogs: boolean;
  canManageRoles: boolean;
  canModifyFeatureFlags: boolean;
  canBroadcastAnnouncements: boolean;
}

export interface AdminUser extends UserProfile {
  role: UserRole;
  status: UserStatus;
  joinedAt: string;
  reportedCount: number;
  deviceCount: number;
  storageUsedMB: number;
  permissions: AdminPermissions;
}

export interface SystemAnalytics {
  activeUsers24h: number;
  totalMessagesSent: number;
  storageTotalGB: number;
  spamBlocked24h: number;
  activeCallsCount: number;
  serverUptime: string;
  e2eeVerificationRate: number;
  networkLatencyMs: number;
}

export type AppTab = 'chats' | 'stories' | 'calls' | 'ai' | 'settings' | 'admin';

export type LanguageCode = 'en' | 'hi' | 'mr' | 'kok';

export type AppTheme = 'liquid-dark' | 'liquid-light' | 'amoled-black' | 'cyber-neon';
