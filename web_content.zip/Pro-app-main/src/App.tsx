/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { DeviceFrame } from './components/layout/DeviceFrame';
import { BottomTabBar } from './components/layout/BottomTabBar';
import { ChatList } from './components/chat/ChatList';
import { ChatView } from './components/chat/ChatView';
import { AiFeaturesScreen } from './components/ai/AiFeaturesScreen';
import { StoriesScreen } from './components/stories/StoriesScreen';
import { CallsScreen } from './components/calling/CallsScreen';
import { SettingsScreen } from './components/settings/SettingsScreen';
import { LiveLocationModal } from './components/location/LiveLocationModal';
import { GhostModeModal } from './components/ghost/GhostModeModal';
import { CameraXModal } from './components/camera/CameraXModal';
import { CallModal } from './components/calling/CallModal';
import { StatusViewerModal } from './components/stories/StatusViewerModal';
import { StatusCreatorModal } from './components/stories/StatusCreatorModal';
import { AdminArchitectureModal } from './components/admin/AdminArchitectureModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { LiveLocationTrace } from './components/location/LiveLocationTrace';
import { DeveloperOptionsModal } from './components/admin/DeveloperOptionsModal';

const AppContent: React.FC = () => {
  const { 
    activeTab, 
    activeChatId, 
    isDeviceFrame, 
    isLocationTraceOpen, 
    setIsLocationTraceOpen,
    isDevOptionsOpen,
    setIsDevOptionsOpen
  } = useApp();

  return (
    <DeviceFrame>
      {/* Either Desktop Master-Detail or Mobile Stack */}
      {!isDeviceFrame ? (
        /* Desktop Mode: Split Screen Layout */
        <div className="flex-1 flex overflow-hidden">
          {/* Left Column: Navigation & List */}
          <div className="w-80 md:w-96 flex flex-col h-full border-r border-white/10 relative">
            {activeTab === 'chats' && <ChatList />}
            {activeTab === 'stories' && <StoriesScreen />}
            {activeTab === 'calls' && <CallsScreen />}
            {activeTab === 'settings' && <SettingsScreen />}
            {activeTab === 'ai' && <AiFeaturesScreen />}
            {activeTab === 'admin' && <AdminDashboard />}
            <BottomTabBar />
          </div>

          {/* Right Column: Active Conversation or AI Assistant */}
          <div className="flex-1 flex flex-col h-full bg-slate-950">
            {activeTab === 'ai' ? (
              <AiFeaturesScreen />
            ) : activeTab === 'admin' ? (
              <AdminDashboard />
            ) : activeChatId ? (
              <ChatView />
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
                <div className="w-16 h-16 rounded-3xl ios-glass flex items-center justify-center text-cyan-400 mb-3 shadow-xl">
                  💬
                </div>
                <h3 className="text-base font-bold text-white">Aether Liquid Super Messenger</h3>
                <p className="text-xs text-slate-400 max-w-sm mt-1">
                  Select a chat from the sidebar or open the Aether AI Assistant for summaries, translations & security radar.
                </p>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Mobile iPhone Mode: Fluid Stack Layout */
        <div className="flex-1 flex flex-col h-full relative overflow-hidden">
          {activeTab === 'chats' ? (
            activeChatId ? (
              <ChatView />
            ) : (
              <>
                <ChatList />
                <BottomTabBar />
              </>
            )
          ) : activeTab === 'stories' ? (
            <>
              <StoriesScreen />
              <BottomTabBar />
            </>
          ) : activeTab === 'calls' ? (
            <>
              <CallsScreen />
              <BottomTabBar />
            </>
          ) : activeTab === 'ai' ? (
            <>
              <AiFeaturesScreen />
              <BottomTabBar />
            </>
          ) : activeTab === 'admin' ? (
            <>
              <AdminDashboard />
              <BottomTabBar />
            </>
          ) : (
            <>
              <SettingsScreen />
              <BottomTabBar />
            </>
          )}
        </div>
      )}

      {/* Global Interactive Modals */}
      <LiveLocationModal />
      <GhostModeModal />
      <CameraXModal />
      <CallModal />
      <StatusViewerModal />
      <StatusCreatorModal />
      <AdminArchitectureModal />
      <DeveloperOptionsModal isOpen={isDevOptionsOpen} onClose={() => setIsDevOptionsOpen(false)} />

      {/* Live Location Trace Full UI Component Modal */}
      {isLocationTraceOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 md:p-6 bg-black/85 backdrop-blur-xl">
          <div className="relative w-full max-w-2xl h-[92vh] max-h-[760px] ios-glass-card rounded-3xl border border-white/20 shadow-2xl overflow-hidden flex flex-col">
            <LiveLocationTrace onClose={() => setIsLocationTraceOpen(false)} />
          </div>
        </div>
      )}
    </DeviceFrame>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
