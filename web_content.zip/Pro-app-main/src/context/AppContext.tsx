import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  AppTab, 
  CallSession, 
  ChatThread, 
  GhostModeSettings, 
  LanguageCode, 
  LiveLocationData, 
  Message, 
  StoryStatus, 
  UserProfile 
} from '../types';
import { CURRENT_USER, CONTACTS, INITIAL_CHATS, INITIAL_MESSAGES, INITIAL_STORIES } from '../mock/initialData';

interface AppContextType {
  currentUser: UserProfile;
  updateCurrentUser: (updates: Partial<UserProfile>) => void;
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  activeChatId: string | null;
  setActiveChatId: (id: string | null) => void;
  chats: ChatThread[];
  messages: Record<string, Message[]>;
  sendMessage: (chatId: string, text: string, type?: Message['type'], extra?: Partial<Message>) => void;
  deleteMessage: (chatId: string, messageId: string, forEveryone?: boolean) => void;
  toggleStarMessage: (chatId: string, messageId: string) => void;
  addReaction: (chatId: string, messageId: string, emoji: string) => void;
  votePoll: (chatId: string, messageId: string, optionId: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  chatFilter: 'all' | 'unread' | 'groups' | 'channels' | 'vault';
  setChatFilter: (f: 'all' | 'unread' | 'groups' | 'channels' | 'vault') => void;

  // Live Location
  liveLocation: LiveLocationData | null;
  startLiveLocation: (chatId: string, durationMinutes: number, isEmergency?: boolean) => void;
  stopLiveLocation: () => void;
  isLocationModalOpen: boolean;
  setIsLocationModalOpen: (open: boolean) => void;
  isLocationTraceOpen: boolean;
  setIsLocationTraceOpen: (open: boolean) => void;

  // Ghost Mode
  ghostMode: GhostModeSettings;
  updateGhostMode: (updates: Partial<GhostModeSettings>) => void;
  isGhostModalOpen: boolean;
  setIsGhostModalOpen: (open: boolean) => void;
  isAppLocked: boolean;
  unlockApp: (pin: string) => boolean;

  // Live Camera
  isCameraOpen: boolean;
  openCamera: () => void;
  closeCamera: () => void;

  // Calling
  callSession: CallSession | null;
  startCall: (chatId: string, type: 'voice' | 'video' | 'group') => void;
  endCall: () => void;
  toggleCallMute: () => void;
  toggleCallSpeaker: () => void;
  toggleCallVideo: () => void;
  toggleCallScreenShare: () => void;

  // Stories
  stories: StoryStatus[];
  activeStoryId: string | null;
  setActiveStoryId: (id: string | null) => void;
  isCreatingStory: boolean;
  setIsCreatingStory: (open: boolean) => void;
  addStory: (story: Omit<StoryStatus, 'id' | 'viewersCount' | 'isViewed'>) => void;

  // Customization & Viewport
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  isDeviceFrame: boolean;
  setIsDeviceFrame: (isDevice: boolean) => void;

  // Admin Architecture Modal
  isAdminModalOpen: boolean;
  setIsAdminModalOpen: (open: boolean) => void;

  // Developer Options (2000+ Power Features) Modal
  isDevOptionsOpen: boolean;
  setIsDevOptionsOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile>(CURRENT_USER);
  const [activeTab, setActiveTab] = useState<AppTab>('chats');
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [chats, setChats] = useState<ChatThread[]>(INITIAL_CHATS);
  const [messages, setMessages] = useState<Record<string, Message[]>>(INITIAL_MESSAGES);
  const [searchQuery, setSearchQuery] = useState('');
  const [chatFilter, setChatFilter] = useState<'all' | 'unread' | 'groups' | 'channels' | 'vault'>('all');
  const [isDevOptionsOpen, setIsDevOptionsOpen] = useState(false);

  // Stories
  const [stories, setStories] = useState<StoryStatus[]>(INITIAL_STORIES);
  const [activeStoryId, setActiveStoryId] = useState<string | null>(null);
  const [isCreatingStory, setIsCreatingStory] = useState(false);

  // Live Location
  const [liveLocation, setLiveLocation] = useState<LiveLocationData | null>({
    isSharing: true,
    lat: 37.7749,
    lng: -122.4194,
    accuracyMeters: 8,
    speedKmh: 4.8,
    startedAt: Date.now() - 10 * 60 * 1000,
    durationMinutes: 60,
    expiresAt: Date.now() + 50 * 60 * 1000,
    batteryLevel: 91,
    address: 'Mission St & 5th, San Francisco, CA',
  });
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [isLocationTraceOpen, setIsLocationTraceOpen] = useState(false);

  // Ghost Mode
  const [ghostMode, setGhostMode] = useState<GhostModeSettings>({
    enabled: false,
    hideOnlineStatus: false,
    hideLastSeen: false,
    disableReadReceipts: false,
    hideTypingIndicator: false,
    hideRecordingIndicator: false,
    privateNotificationPreviews: false,
    appLockRequired: false,
    screenshotProtection: true,
    invisibleChatVault: false,
    autoDeleteOldMedia: false,
  });
  const [isGhostModalOpen, setIsGhostModalOpen] = useState(false);
  const [isAppLocked, setIsAppLocked] = useState(false);

  // Camera & Calling
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [callSession, setCallSession] = useState<CallSession | null>(null);

  // Internationalization & Display
  const [language, setLanguage] = useState<LanguageCode>('en');
  const [isDeviceFrame, setIsDeviceFrame] = useState(true);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);

  const updateCurrentUser = (updates: Partial<UserProfile>) => {
    setCurrentUser(prev => ({ ...prev, ...updates }));
  };

  const updateGhostMode = (updates: Partial<GhostModeSettings>) => {
    setGhostMode(prev => ({ ...prev, ...updates }));
  };

  const unlockApp = (pin: string): boolean => {
    if (pin === '1234' || pin.length === 4) {
      setIsAppLocked(false);
      return true;
    }
    return false;
  };

  const sendMessage = (
    chatId: string, 
    text: string, 
    type: Message['type'] = 'text', 
    extra: Partial<Message> = {}
  ) => {
    const newMsg: Message = {
      id: `msg_${Date.now()}`,
      chatId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      type,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
      reactions: [],
      ...extra,
    };

    setMessages(prev => ({
      ...prev,
      [chatId]: [...(prev[chatId] || []), newMsg],
    }));

    // Update chat last message
    setChats(prev => prev.map(c => {
      if (c.id === chatId) {
        return {
          ...c,
          lastMessage: newMsg,
        };
      }
      return c;
    }));

    // Simulate delivery & read
    setTimeout(() => {
      setMessages(prev => {
        const list = prev[chatId] || [];
        return {
          ...prev,
          [chatId]: list.map(m => m.id === newMsg.id ? { ...m, status: 'read' } : m),
        };
      });
    }, 1200);
  };

  const deleteMessage = (chatId: string, messageId: string, forEveryone = false) => {
    setMessages(prev => {
      const list = prev[chatId] || [];
      if (forEveryone) {
        return {
          ...prev,
          [chatId]: list.map(m => m.id === messageId ? { ...m, isDeletedForEveryone: true, text: 'This message was deleted' } : m),
        };
      }
      return {
        ...prev,
        [chatId]: list.filter(m => m.id !== messageId),
      };
    });
  };

  const toggleStarMessage = (chatId: string, messageId: string) => {
    setMessages(prev => {
      const list = prev[chatId] || [];
      return {
        ...prev,
        [chatId]: list.map(m => m.id === messageId ? { ...m, isStarred: !m.isStarred } : m),
      };
    });
  };

  const addReaction = (chatId: string, messageId: string, emoji: string) => {
    setMessages(prev => {
      const list = prev[chatId] || [];
      return {
        ...prev,
        [chatId]: list.map(m => {
          if (m.id !== messageId) return m;
          const existing = m.reactions.find(r => r.userId === currentUser.id && r.emoji === emoji);
          if (existing) {
            return {
              ...m,
              reactions: m.reactions.filter(r => !(r.userId === currentUser.id && r.emoji === emoji)),
            };
          }
          return {
            ...m,
            reactions: [...m.reactions, { emoji, userId: currentUser.id, userName: currentUser.name }],
          };
        }),
      };
    });
  };

  const votePoll = (chatId: string, messageId: string, optionId: string) => {
    setMessages(prev => {
      const list = prev[chatId] || [];
      return {
        ...prev,
        [chatId]: list.map(m => {
          if (m.id !== messageId || !m.pollData) return m;
          const isVoted = m.pollData.options.find(o => o.id === optionId)?.votes.includes(currentUser.id);
          const updatedOptions = m.pollData.options.map(opt => {
            if (opt.id === optionId) {
              return {
                ...opt,
                votes: isVoted 
                  ? opt.votes.filter(u => u !== currentUser.id) 
                  : [...opt.votes, currentUser.id]
              };
            }
            if (!m.pollData?.isMultipleChoice && !isVoted) {
              return {
                ...opt,
                votes: opt.votes.filter(u => u !== currentUser.id)
              };
            }
            return opt;
          });

          const total = updatedOptions.reduce((acc, o) => acc + o.votes.length, 0);

          return {
            ...m,
            pollData: {
              ...m.pollData,
              options: updatedOptions,
              totalVotes: total,
            },
          };
        }),
      };
    });
  };

  const startLiveLocation = (chatId: string, durationMinutes: number, isEmergency = false) => {
    const loc: LiveLocationData = {
      isSharing: true,
      lat: 37.7749 + (Math.random() - 0.5) * 0.005,
      lng: -122.4194 + (Math.random() - 0.5) * 0.005,
      accuracyMeters: 6,
      speedKmh: isEmergency ? 25.4 : 4.5,
      startedAt: Date.now(),
      durationMinutes,
      expiresAt: Date.now() + durationMinutes * 60 * 1000,
      batteryLevel: 94,
      address: isEmergency ? '🚨 SOS EMERGENCY: Market St & 6th St' : 'Live: Market St & 4th, San Francisco, CA',
      isEmergency,
    };
    setLiveLocation(loc);

    sendMessage(chatId, isEmergency ? '🚨 Emergency Live Location Alert!' : 'Started sharing live location', 'live_location', {
      locationData: loc,
    });
  };

  const stopLiveLocation = () => {
    setLiveLocation(null);
    if (activeChatId) {
      sendMessage(activeChatId, 'Stopped sharing live location', 'text');
    }
  };

  const openCamera = () => setIsCameraOpen(true);
  const closeCamera = () => setIsCameraOpen(false);

  const startCall = (chatId: string, type: 'voice' | 'video' | 'group') => {
    const chat = chats.find(c => c.id === chatId);
    const peer = chat?.participants.find(p => p.id !== currentUser.id) || CONTACTS[0];

    setCallSession({
      id: `call_${Date.now()}`,
      chatId,
      type,
      status: 'calling',
      isIncoming: false,
      participants: [
        { id: currentUser.id, name: currentUser.name, avatar: currentUser.avatar, isMuted: false, isVideoOff: false },
        { id: peer.id, name: peer.name, avatar: peer.avatar, isMuted: false, isVideoOff: false },
      ],
      durationSeconds: 0,
      isMuted: false,
      isSpeaker: true,
      isVideoMuted: type === 'voice',
      isScreenSharing: false,
      networkQuality: 'excellent',
    });

    // Simulate answer after 2.5s
    setTimeout(() => {
      setCallSession(prev => prev ? { ...prev, status: 'connected', startTime: Date.now() } : null);
    }, 2500);
  };

  const endCall = () => {
    if (callSession && activeChatId) {
      sendMessage(
        activeChatId, 
        `Ended ${callSession.type} call (${Math.floor(callSession.durationSeconds / 60)}:${(callSession.durationSeconds % 60).toString().padStart(2, '0')})`,
        'call_log'
      );
    }
    setCallSession(null);
  };

  const toggleCallMute = () => {
    setCallSession(prev => prev ? { ...prev, isMuted: !prev.isMuted } : null);
  };

  const toggleCallSpeaker = () => {
    setCallSession(prev => prev ? { ...prev, isSpeaker: !prev.isSpeaker } : null);
  };

  const toggleCallVideo = () => {
    setCallSession(prev => prev ? { ...prev, isVideoMuted: !prev.isVideoMuted } : null);
  };

  const toggleCallScreenShare = () => {
    setCallSession(prev => prev ? { ...prev, isScreenSharing: !prev.isScreenSharing } : null);
  };

  const addStory = (storyData: Omit<StoryStatus, 'id' | 'viewersCount' | 'isViewed'>) => {
    const newStory: StoryStatus = {
      ...storyData,
      id: `story_${Date.now()}`,
      viewersCount: 0,
      isViewed: false,
    };
    setStories(prev => [newStory, ...prev]);
  };

  // Timer for active call duration
  useEffect(() => {
    if (!callSession || callSession.status !== 'connected') return;
    const interval = setInterval(() => {
      setCallSession(prev => prev ? { ...prev, durationSeconds: prev.durationSeconds + 1 } : null);
    }, 1000);
    return () => clearInterval(interval);
  }, [callSession?.status]);

  return (
    <AppContext.Provider
      value={{
        currentUser,
        updateCurrentUser,
        activeTab,
        setActiveTab,
        activeChatId,
        setActiveChatId,
        chats,
        messages,
        sendMessage,
        deleteMessage,
        toggleStarMessage,
        addReaction,
        votePoll,
        searchQuery,
        setSearchQuery,
        chatFilter,
        setChatFilter,
        liveLocation,
        startLiveLocation,
        stopLiveLocation,
        isLocationModalOpen,
        setIsLocationModalOpen,
        isLocationTraceOpen,
        setIsLocationTraceOpen,
        ghostMode,
        updateGhostMode,
        isGhostModalOpen,
        setIsGhostModalOpen,
        isAppLocked,
        unlockApp,
        isCameraOpen,
        openCamera,
        closeCamera,
        callSession,
        startCall,
        endCall,
        toggleCallMute,
        toggleCallSpeaker,
        toggleCallVideo,
        toggleCallScreenShare,
        stories,
        activeStoryId,
        setActiveStoryId,
        isCreatingStory,
        setIsCreatingStory,
        addStory,
        language,
        setLanguage,
        isDeviceFrame,
        setIsDeviceFrame,
        isAdminModalOpen,
        setIsAdminModalOpen,
        isDevOptionsOpen,
        setIsDevOptionsOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
