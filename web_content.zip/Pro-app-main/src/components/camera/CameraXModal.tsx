import React, { useState, useRef, useEffect } from 'react';
import { 
  Camera, 
  FlipHorizontal, 
  Zap, 
  ZapOff, 
  X, 
  Check, 
  RotateCw, 
  Sliders, 
  Sparkles, 
  Edit3, 
  Type, 
  Smile, 
  Send, 
  EyeOff, 
  Video, 
  CircleDot,
  Maximize2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const CameraXModal: React.FC = () => {
  const { isCameraOpen, closeCamera, sendMessage, activeChatId, chats } = useApp();

  const [lensFacing, setLensFacing] = useState<'back' | 'front'>('back');
  const [flashMode, setFlashMode] = useState<'off' | 'on' | 'auto'>('auto');
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [exposureLevel, setExposureLevel] = useState<number>(0);
  const [isRecordingVideo, setIsRecordingVideo] = useState(false);
  const [recordedTime, setRecordedTime] = useState(0);

  // Captured snapshot state
  const [capturedPhotoUrl, setCapturedPhotoUrl] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<'none' | 'vivid' | 'mono' | 'cyber' | 'warm'>('none');
  const [rotationAngle, setRotationAngle] = useState(0);
  const [captionText, setCaptionText] = useState('');
  const [isHdEnabled, setIsHdEnabled] = useState(true);
  const [blurSensitiveActive, setBlurSensitiveActive] = useState(false);
  const [activeTool, setActiveTool] = useState<'none' | 'draw' | 'text' | 'stickers'>('none');

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Timer for video recording
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecordingVideo) {
      interval = setInterval(() => {
        setRecordedTime(t => t + 1);
      }, 1000);
    } else {
      setRecordedTime(0);
    }
    return () => clearInterval(interval);
  }, [isRecordingVideo]);

  if (!isCameraOpen) return null;

  const handleCapture = () => {
    // Generate high quality simulated camera capture with rich texture
    const samplePhotos = [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=1080&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1080&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1080&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1080&auto=format&fit=crop&q=80',
    ];
    const picked = samplePhotos[Math.floor(Math.random() * samplePhotos.length)];
    setCapturedPhotoUrl(picked);
  };

  const handleRetake = () => {
    setCapturedPhotoUrl(null);
    setActiveFilter('none');
    setRotationAngle(0);
    setCaptionText('');
    setBlurSensitiveActive(false);
  };

  const handleSendPhoto = () => {
    const targetChat = activeChatId || chats[0]?.id;
    if (targetChat && capturedPhotoUrl) {
      sendMessage(targetChat, captionText || (isRecordingVideo ? 'Live Camera Video' : 'CameraX HD Photo'), 'image', {
        mediaUrl: capturedPhotoUrl,
        mediaSize: isHdEnabled ? '4.2 MB (HD 4K)' : '1.1 MB (Compressed)',
      });
    }
    handleRetake();
    closeCamera();
  };

  const getFilterStyle = () => {
    switch (activeFilter) {
      case 'vivid':
        return 'contrast-125 saturate-150 brightness-105';
      case 'mono':
        return 'grayscale contrast-125';
      case 'cyber':
        return 'hue-rotate-180 contrast-125 saturate-200';
      case 'warm':
        return 'sepia-25 hue-rotate-[-10deg] brightness-105';
      default:
        return '';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-xl">
      <div className="relative w-full max-w-md h-[95vh] max-h-[780px] bg-slate-950 rounded-3xl overflow-hidden border border-white/20 shadow-2xl flex flex-col justify-between">
        
        {/* Top Camera Controls */}
        <div className="relative z-20 px-4 py-3 flex items-center justify-between ios-glass border-b border-white/10">
          <button
            onClick={closeCamera}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
          >
            <X className="w-5 h-5" />
          </button>

          {!capturedPhotoUrl ? (
            <div className="flex items-center gap-3">
              {/* Flash Mode */}
              <button
                onClick={() => setFlashMode(m => m === 'auto' ? 'on' : m === 'on' ? 'off' : 'auto')}
                className="px-2.5 py-1 rounded-full bg-white/10 text-xs font-semibold text-white flex items-center gap-1"
              >
                {flashMode === 'off' ? <ZapOff className="w-3.5 h-3.5 text-slate-400" /> : <Zap className="w-3.5 h-3.5 text-amber-400" />}
                <span className="uppercase text-[10px]">{flashMode}</span>
              </button>

              {/* HD Toggle */}
              <button
                onClick={() => setIsHdEnabled(!isHdEnabled)}
                className={`px-2.5 py-1 rounded-full text-xs font-bold transition-all border ${
                  isHdEnabled ? 'bg-cyan-500/25 border-cyan-400 text-cyan-300' : 'bg-white/10 border-white/10 text-slate-400'
                }`}
              >
                HD
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setRotationAngle(a => (a + 90) % 360)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
                title="Rotate 90deg"
              >
                <RotateCw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setBlurSensitiveActive(!blurSensitiveActive)}
                className={`px-2.5 py-1 rounded-full text-xs font-semibold flex items-center gap-1 border ${
                  blurSensitiveActive ? 'bg-rose-500/30 border-rose-400 text-rose-300' : 'bg-white/10 border-white/10 text-slate-300'
                }`}
              >
                <EyeOff className="w-3.5 h-3.5" />
                Blur Face/ID
              </button>
            </div>
          )}

          {!capturedPhotoUrl && (
            <button
              onClick={() => setLensFacing(f => f === 'back' ? 'front' : 'back')}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
              title="Flip Camera"
            >
              <FlipHorizontal className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Viewfinder / Preview Area */}
        <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden">
          {!capturedPhotoUrl ? (
            /* Live Camera Viewfinder Simulation */
            <div className="relative w-full h-full flex flex-col items-center justify-center">
              {/* Simulated camera background */}
              <div 
                className={`absolute inset-0 bg-cover bg-center transition-transform duration-300 ${
                  lensFacing === 'front' ? 'scale-x-[-1]' : ''
                }`}
                style={{
                  backgroundImage: `url('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=900&auto=format&fit=crop&q=80')`,
                  transform: `scale(${zoomLevel}) ${lensFacing === 'front' ? 'scaleX(-1)' : ''}`,
                }}
              />

              {/* Viewfinder Focus Reticle */}
              <div className="relative z-10 w-28 h-28 border border-white/40 rounded-2xl pointer-events-none flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              </div>

              {/* Recording indicator */}
              {isRecordingVideo && (
                <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 px-3 py-1 rounded-full bg-rose-600/90 text-white text-xs font-mono font-bold flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-white animate-pulse" />
                  <span>REC 00:{recordedTime.toString().padStart(2, '0')}</span>
                </div>
              )}

              {/* Zoom Switcher */}
              <div className="absolute bottom-4 z-20 flex items-center gap-2 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                {[0.5, 1, 2, 3].map(z => (
                  <button
                    key={z}
                    onClick={() => setZoomLevel(z)}
                    className={`w-6 h-6 rounded-full text-[10px] font-bold transition-all ${
                      zoomLevel === z ? 'bg-amber-400 text-slate-950 scale-110' : 'text-white/80 hover:text-white'
                    }`}
                  >
                    {z}x
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Captured Photo Editor Canvas */
            <div className="relative w-full h-full flex items-center justify-center bg-black">
              <div 
                className={`relative w-full h-full flex items-center justify-center transition-all ${getFilterStyle()}`}
                style={{ transform: `rotate(${rotationAngle}deg)` }}
              >
                <img 
                  src={capturedPhotoUrl} 
                  alt="Captured" 
                  className="max-w-full max-h-full object-contain"
                />
                {blurSensitiveActive && (
                  <div className="absolute top-1/3 w-36 h-28 backdrop-blur-2xl bg-black/30 border border-white/20 rounded-2xl flex items-center justify-center">
                    <span className="text-[10px] font-mono font-bold text-white bg-black/70 px-2 py-0.5 rounded">BLURRED</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Shutter & Editing Bar */}
        <div className="relative z-20 px-4 py-4 ios-glass border-t border-white/10 space-y-3">
          {!capturedPhotoUrl ? (
            /* Shutter Controls */
            <div className="flex items-center justify-around">
              {/* Photo / Video Switch */}
              <button
                onClick={() => setIsRecordingVideo(!isRecordingVideo)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  isRecordingVideo ? 'bg-rose-600 text-white' : 'bg-white/10 text-slate-300'
                }`}
              >
                <Video className="w-3.5 h-3.5" />
                {isRecordingVideo ? 'Stop Video' : 'Switch Video'}
              </button>

              {/* Shutter Button */}
              <button
                onClick={handleCapture}
                className="w-18 h-18 rounded-full border-4 border-white p-1 flex items-center justify-center active:scale-95 transition-transform"
              >
                <div className={`w-full h-full rounded-full ${isRecordingVideo ? 'bg-rose-600 rounded-lg scale-75' : 'bg-white'}`} />
              </button>

              {/* Photo Mode Label */}
              <span className="text-xs font-semibold text-slate-400">
                CameraX 60fps
              </span>
            </div>
          ) : (
            /* Photo Editing & Sending Controls */
            <div className="space-y-3">
              {/* Filter Pills */}
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
                {(['none', 'vivid', 'mono', 'cyber', 'warm'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setActiveFilter(f)}
                    className={`px-3 py-1 rounded-full text-[11px] font-semibold capitalize border transition-all whitespace-nowrap ${
                      activeFilter === f
                        ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200'
                        : 'bg-white/10 border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>

              {/* Caption Input */}
              <div className="flex items-center gap-2 bg-black/40 rounded-2xl px-3 py-1.5 border border-white/15">
                <input
                  type="text"
                  value={captionText}
                  onChange={e => setCaptionText(e.target.value)}
                  placeholder="Add a caption..."
                  className="flex-1 bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none"
                />
              </div>

              {/* Retake vs Send */}
              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={handleRetake}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-semibold"
                >
                  Retake
                </button>
                <button
                  onClick={handleSendPhoto}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-cyan-600/30"
                >
                  <span>Send</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
