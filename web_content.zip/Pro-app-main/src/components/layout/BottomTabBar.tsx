import React from 'react';
import { 
  MessageCircle, 
  CircleDot, 
  Phone, 
  Sparkles, 
  Settings as SettingsIcon,
  ShieldAlert 
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { AppTab } from '../../types';

export const BottomTabBar: React.FC = () => {
  const { activeTab, setActiveTab, chats, activeChatId } = useApp();

  const totalUnread = chats.reduce((acc, c) => acc + (c.unreadCount || 0), 0);

  const tabs: Array<{ id: AppTab; label: string; icon: React.ElementType; badge?: number; isAi?: boolean }> = [
    { id: 'chats', label: 'Chats', icon: MessageCircle, badge: totalUnread },
    { id: 'stories', label: 'Stories', icon: CircleDot },
    { id: 'calls', label: 'Calls', icon: Phone },
    { id: 'ai', label: 'Aether AI', icon: Sparkles, isAi: true },
    { id: 'admin', label: 'Admin', icon: ShieldAlert },
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  return (
    <div className="absolute bottom-0 inset-x-0 z-30 ios-glass border-t border-white/10 px-3 py-1.5 backdrop-blur-2xl">
      <div className="flex items-center justify-around max-w-lg mx-auto">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all duration-200 ${
                isActive 
                  ? 'text-cyan-400 scale-105' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                {tab.isAi && isActive && (
                  <div className="absolute -inset-1 rounded-full bg-cyan-500/30 blur-sm animate-pulse" />
                )}
                <Icon className={`w-5 h-5 ${tab.isAi ? 'text-cyan-300' : ''}`} />
                
                {/* Unread badge */}
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1.5 -right-2 px-1.5 py-0.2 rounded-full bg-cyan-500 text-slate-950 text-[9px] font-extrabold shadow-sm">
                    {tab.badge}
                  </span>
                ) : null}
              </div>

              <span className={`text-[10px] mt-0.5 font-medium ${isActive ? 'font-bold text-white' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
