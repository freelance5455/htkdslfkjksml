import React, { useState, useEffect } from 'react';
import { 
  Wifi, 
  Battery, 
  Lock, 
  Radio, 
  Ghost, 
  Sparkles, 
  Maximize2, 
  Minimize2, 
  Code2, 
  ShieldCheck, 
  Navigation,
  Smartphone,
  Terminal,
  MessageSquare,
  Languages
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const DeviceFrame: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { 
    isDeviceFrame, 
    setIsDeviceFrame, 
    liveLocation, 
    ghostMode, 
    setIsGhostModalOpen, 
    setIsLocationModalOpen,
    setIsLocationTraceOpen,
    setIsAdminModalOpen,
    callSession,
    isAppLocked,
    unlockApp,
    isDevOptionsOpen,
    setIsDevOptionsOpen,
    setActiveTab,
    setActiveChatId,
    chats
  } = useApp();

  const [currentTime, setCurrentTime] = useState('');
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handlePinSubmit = () => {
    const ok = unlockApp(pinInput);
    if (!ok) {
      setPinError(true);
      setTimeout(() => setPinError(false), 1500);
      setPinInput('');
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-slate-950 flex flex-col items-center justify-center p-0 md:p-6 overflow-x-hidden selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Background Ambient Glows */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-600/15 rounded-full blur-3xl animate-pulse-glow" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 right-1/3 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl" />
      </div>

      {/* Top Floating Control Bar for Reviewers & Users */}
      <header className="relative z-40 w-full max-w-5xl mb-3 px-4 py-2 ios-glass rounded-2xl border border-white/10 flex flex-wrap items-center justify-between gap-2 shadow-2xl backdrop-blur-2xl">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/30">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <span className="text-sm font-extrabold text-white tracking-tight flex items-center gap-1.5">
              Aether Liquid
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                v2.5
              </span>
            </span>
            <p className="text-[11px] text-slate-400 hidden sm:block">iOS Liquid Glass Super Messaging Suite</p>
          </div>
        </div>

        {/* Quick Reviewer Actions */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Explore Secure Chat */}
          <button
            onClick={() => {
              setActiveTab('chats');
              setActiveChatId(chats[0]?.id || 'chat_elena');
            }}
            className="px-2.5 py-1 rounded-xl text-xs font-bold bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400/40 flex items-center gap-1.5 transition-all shadow-sm"
            title="Explore Secure Chat with E2EE"
          >
            <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
            <span>Explore Secure Chat</span>
          </button>

          {/* View AI & Multi-Lingual Neural Hub */}
          <button
            onClick={() => setActiveTab('ai')}
            className="px-2.5 py-1 rounded-xl text-xs font-bold bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 flex items-center gap-1.5 transition-all shadow-sm"
            title="View AI & Multi-Lingual Neural Hub"
          >
            <Languages className="w-3.5 h-3.5 text-purple-400" />
            <span>AI Neural Hub (मराठी • हिन्दी • EN)</span>
          </button>

          {/* Developer Options 2000+ Feature Matrix */}
          <button
            onClick={() => setIsDevOptionsOpen(true)}
            className="px-2.5 py-1 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-600/40 to-teal-600/40 hover:from-emerald-500/50 hover:to-teal-500/50 text-emerald-200 border border-emerald-400/50 flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/20"
            title="Open Developer Options (2000+ Power Features) & Direct Zero-Login Protocol"
          >
            <Terminal className="w-3.5 h-3.5 text-emerald-400" />
            <span>Developer Options (2000+)</span>
          </button>

          {/* Live Location Quick Status & Trace Map */}
          <button
            onClick={() => setIsLocationTraceOpen(true)}
            className={`px-2.5 py-1 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
              liveLocation?.isSharing
                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 animate-pulse'
                : 'bg-white/5 border-white/10 text-slate-300 hover:text-white'
            }`}
          >
            <Navigation className="w-3 h-3 text-emerald-400" />
            <span>{liveLocation?.isSharing ? 'Live Trace Map' : 'Location Trace'}</span>
          </button>

          {/* Ghost Mode Quick Status */}
          <button
            onClick={() => setIsGhostModalOpen(true)}
            className={`px-2.5 py-1 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
              ghostMode.enabled
                ? 'bg-purple-500/20 border-purple-500/40 text-purple-300'
                : 'bg-white/5 border-white/10 text-slate-300 hover:text-white'
            }`}
          >
            <Ghost className="w-3 h-3 text-purple-400" />
            <span>{ghostMode.enabled ? 'Ghost Stealth ON' : 'Ghost Mode'}</span>
          </button>

          {/* Architecture / Android Code Portal */}
          <button
            onClick={() => setIsAdminModalOpen(true)}
            className="px-2.5 py-1 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/20 text-cyan-300 border border-white/10 flex items-center gap-1.5 transition-colors"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Android & Firebase Code</span>
          </button>

          {/* Viewport Frame Switcher */}
          <button
            onClick={() => setIsDeviceFrame(!isDeviceFrame)}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors"
            title={isDeviceFrame ? 'Switch to Fullscreen Desktop' : 'Switch to iPhone Frame'}
          >
            {isDeviceFrame ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Container: Either iPhone Frame or Fullscreen Desktop */}
      {isDeviceFrame ? (
        /* iOS Phone Device Chassis */
        <div className="relative z-30 w-full max-w-[420px] h-[870px] max-h-[92vh] rounded-[52px] p-3.5 bg-gradient-to-b from-slate-800 via-slate-900 to-slate-950 shadow-[0_25px_70px_rgba(0,0,0,0.85)] border-4 border-slate-700/60 ring-1 ring-white/10 flex flex-col justify-between overflow-hidden">
          
          {/* Inner Titanium Bezel Highlight */}
          <div className="relative w-full h-full rounded-[42px] overflow-hidden bg-slate-950 flex flex-col border border-white/10">
            
            {/* iOS Status Bar + Dynamic Island */}
            <div className="relative z-30 px-6 pt-3 pb-2 flex items-center justify-between text-xs text-white ios-glass select-none">
              <span className="font-semibold text-xs tracking-tight">{currentTime || '09:41'}</span>

              {/* Dynamic Island Pill */}
              <div 
                onClick={() => {
                  if (liveLocation?.isSharing) setIsLocationTraceOpen(true);
                  if (callSession) alert('WebRTC Call in progress');
                }}
                className="cursor-pointer px-3 py-1 rounded-full bg-black/90 border border-white/15 flex items-center gap-2 shadow-lg hover:border-cyan-400/50 transition-colors"
              >
                {liveLocation?.isSharing ? (
                  <>
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span className="text-[10px] font-mono text-emerald-300">Live GPS</span>
                  </>
                ) : callSession ? (
                  <>
                    <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                    <span className="text-[10px] font-mono text-cyan-300">Call Active</span>
                  </>
                ) : (
                  <>
                    <div className="w-2.5 h-2.5 rounded-full bg-cyan-400/80" />
                    <span className="text-[10px] font-medium text-slate-400">Aether Liquid</span>
                  </>
                )}
              </div>

              {/* Status Icons */}
              <div className="flex items-center gap-1.5 text-slate-300">
                <Wifi className="w-3.5 h-3.5" />
                <span className="text-[10px] font-bold">5G</span>
                <Battery className="w-4 h-4 text-emerald-400" />
              </div>
            </div>

            {/* App Lock Guard if PIN active */}
            {isAppLocked ? (
              <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-4 bg-slate-950">
                <div className="w-16 h-16 rounded-3xl bg-purple-500/20 text-purple-300 flex items-center justify-center border border-purple-500/30 animate-pulse">
                  <Lock className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Ghost App Lock</h3>
                  <p className="text-xs text-slate-400">Enter PIN (Default: 1234)</p>
                </div>
                <input
                  type="password"
                  maxLength={4}
                  value={pinInput}
                  onChange={e => setPinInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handlePinSubmit()}
                  placeholder="••••"
                  className="w-32 text-center text-xl tracking-widest bg-white/10 border border-white/20 rounded-xl py-2 text-white focus:outline-none focus:border-cyan-400"
                />
                <button
                  onClick={handlePinSubmit}
                  className="px-6 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold"
                >
                  Unlock
                </button>
                {pinError && <p className="text-xs text-rose-400">Incorrect PIN. Try 1234.</p>}
              </div>
            ) : (
              /* Screen Content */
              <div className="flex-1 relative overflow-hidden flex flex-col">
                {children}
              </div>
            )}

            {/* Home Indicator Bar */}
            <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-32 h-1 rounded-full bg-white/40 pointer-events-none z-40" />
          </div>
        </div>
      ) : (
        /* Fullscreen Desktop Super-App Canvas */
        <div className="relative z-30 w-full max-w-6xl h-[88vh] rounded-3xl overflow-hidden ios-glass border border-white/15 shadow-2xl flex flex-col">
          {children}
        </div>
      )}
    </div>
  );
};
