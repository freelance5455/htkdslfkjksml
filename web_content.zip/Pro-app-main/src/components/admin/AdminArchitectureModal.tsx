import React, { useState } from 'react';
import { 
  X, 
  Code2, 
  Database, 
  ShieldCheck, 
  CheckCircle2, 
  Terminal, 
  Layers, 
  Copy, 
  Check, 
  Download,
  Smartphone,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AdminArchitectureModal: React.FC = () => {
  const { isAdminModalOpen, setIsAdminModalOpen } = useApp();
  const [activeCodeTab, setActiveCodeTab] = useState<'compose' | 'schema' | 'rules' | 'checklist'>('compose');
  const [copied, setCopied] = useState(false);

  if (!isAdminModalOpen) return null;

  const composeCodeSnippet = `// Package: im.aether.liquid.presentation.chat
// Technology: Android Jetpack Compose + Material 3 + CameraX + WebRTC

@Composable
fun AetherLiquidChatScreen(
    chatId: String,
    viewModel: ChatViewModel = hiltViewModel(),
    onNavigateToCameraX: () -> Unit,
    onStartWebRTCCall: (CallType) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val scrollState = rememberLazyListState()

    Scaffold(
        topBar = {
            LiquidGlassTopAppBar(
                title = uiState.chatTitle,
                isGhostModeActive = uiState.isGhostModeActive,
                onVoiceCallClick = { onStartWebRTCCall(CallType.VOICE) },
                onVideoCallClick = { onStartWebRTCCall(CallType.VIDEO) }
            )
        },
        bottomBar = {
            LiquidGlassChatInput(
                text = uiState.draftText,
                onTextChange = viewModel::onDraftChange,
                onSend = viewModel::sendMessage,
                onCameraLaunch = onNavigateToCameraX,
                onLiveLocationRequest = viewModel::requestConsentBasedLocation
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Brush.radialGradient(listOf(Color(0xFF030712), Color(0xFF0F172A)))),
            state = scrollState
        ) {
            items(uiState.messages, key = { it.id }) { message ->
                LiquidMessageBubble(
                    message = message,
                    isOutgoing = message.senderId == viewModel.currentUserId,
                    onReact = { emoji -> viewModel.addReaction(message.id, emoji) },
                    onPollVote = { optId -> viewModel.votePoll(message.id, optId) }
                )
            }
        }
    }
}`;

  const firestoreSchemaSnippet = `// Cloud Firestore Database Schema Blueprint for Aether Super Messenger
{
  "users": {
    "{userId}": {
      "name": "string",
      "handle": "string (@username)",
      "phone": "string (E.164)",
      "email": "string",
      "avatarUrl": "string",
      "bio": "string",
      "publicKeySignal": "string (Double Ratchet Identity Key)",
      "publicKeyKyber": "string (Post-quantum KEM)",
      "fcmTokens": ["string"],
      "isOnline": "boolean",
      "lastSeen": "timestamp",
      "ghostSettings": {
        "enabled": "boolean",
        "hideOnline": "boolean",
        "hideLastSeen": "boolean",
        "disableReadReceipts": "boolean",
        "appLock": "boolean"
      },
      "createdAt": "timestamp"
    }
  },
  "chats": {
    "{chatId}": {
      "type": "direct | group | channel | community | broadcast",
      "title": "string",
      "avatarUrl": "string",
      "participantIds": ["string"],
      "adminIds": ["string"],
      "lastMessage": {
        "id": "string",
        "senderId": "string",
        "text": "string",
        "timestamp": "timestamp",
        "type": "string"
      },
      "disappearingTimerSeconds": "number (0 = off)",
      "updatedAt": "timestamp"
    }
  },
  "messages": {
    "{chatId}": {
      "threadMessages": {
        "{messageId}": {
          "senderId": "string",
          "senderName": "string",
          "type": "text | image | audio | live_location | poll | call_log",
          "cipherPayload": "string (AES-256-GCM ciphertext)",
          "ephemeralKey": "string (Signal Ratchet header)",
          "timestamp": "timestamp",
          "status": "sending | sent | delivered | read",
          "reactions": [{"userId": "string", "emoji": "string"}],
          "pollData": { "question": "string", "options": [{"id": "string", "text": "string", "votes": ["string"]}] },
          "locationData": { "isSharing": "boolean", "lat": "number", "lng": "number", "expiresAt": "timestamp" }
        }
      }
    }
  },
  "locations": {
    "{locationSessionId}": {
      "userId": "string",
      "targetChatId": "string",
      "coordinates": "geopoint",
      "accuracy": "number",
      "speedKmh": "number",
      "expiresAt": "timestamp",
      "isEmergency": "boolean"
    }
  }
}`;

  const securityRulesSnippet = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Helper functions for user authentication and privacy
    function isAuthenticated() {
      return request.auth != null;
    }

    function isOwner(userId) {
      return isAuthenticated() && request.auth.uid == userId;
    }

    function isChatParticipant(chatId) {
      return isAuthenticated() && 
        request.auth.uid in get(/databases/$(database)/documents/chats/$(chatId)).data.participantIds;
    }

    // User Profile Rules
    match /users/{userId} {
      allow read: if isAuthenticated();
      allow create, update: if isOwner(userId);
      allow delete: if false; // Deletion via secure cloud function with data scrub
    }

    // Chat Threads Rules
    match /chats/{chatId} {
      allow read: if isAuthenticated() && request.auth.uid in resource.data.participantIds;
      allow create: if isAuthenticated() && request.auth.uid in request.resource.data.participantIds;
      allow update: if isChatParticipant(chatId);
    }

    // Encrypted Messages Rules
    match /messages/{chatId}/threadMessages/{messageId} {
      allow read: if isChatParticipant(chatId);
      allow create: if isChatParticipant(chatId) && request.resource.data.senderId == request.auth.uid;
      allow update: if isChatParticipant(chatId);
      allow delete: if isChatParticipant(chatId) && resource.data.senderId == request.auth.uid;
    }

    // Consent-based Live Location Rules (Strict time limits & recipient lock)
    match /locations/{locationId} {
      allow read: if isAuthenticated() && (
        resource.data.userId == request.auth.uid || 
        isChatParticipant(resource.data.targetChatId)
      );
      allow create: if isAuthenticated() && 
        request.resource.data.userId == request.auth.uid &&
        request.resource.data.expiresAt > request.time;
      allow update, delete: if isAuthenticated() && resource.data.userId == request.auth.uid;
    }
  }
}`;

  const checklistSnippet = `Android Play Store Release & Production Deployment Checklist:

1. ARCHITECTURE & COMPLIANCE
   [✔] Clean Architecture (Domain, Data, Presentation)
   [✔] Jetpack Compose 120 FPS liquid shaders & Material 3 theming
   [✔] End-to-End Encryption with Signal Protocol Double Ratchet + Kyber KEM
   [✔] Consent-Based Live Location (explicit user prompt, zero background leakage)
   [✔] In-app CameraX 60fps RAW frame pipeline (foreground only, no background capture)
   [✔] WebRTC 1:1 and Group voice/video with audio visualizers & screen share

2. PERMISSIONS AUDIT (AndroidManifest.xml)
   • android.permission.INTERNET
   • android.permission.ACCESS_FINE_LOCATION (Foreground runtime consent only)
   • android.permission.CAMERA (Foreground user action only)
   • android.permission.RECORD_AUDIO (Microphone for voice messages & calls)
   • android.permission.POST_NOTIFICATIONS (Android 13+ push notifications)
   • android.permission.USE_BIOMETRIC (App lock protection)

3. BUILD & RELEASE COMMANDS
   # Run unit tests and linting
   ./gradlew testDebugUnitTest
   ./gradlew lintRelease

   # Generate Signed Android App Bundle (AAB)
   ./gradlew bundleRelease \\
     -Pandroid.injected.signing.store.file=keystore.jks \\
     -Pandroid.injected.signing.store.password=$KEYSTORE_PASS \\
     -Pandroid.injected.signing.key.alias=aether_prod \\
     -Pandroid.injected.signing.key.password=$KEY_PASS

4. PLAY STORE ASSETS & POLICY
   • Privacy Policy URL detailing zero-knowledge message storage
   • Safety section filled (Data encrypted in transit & at rest, user can request deletion)
   • 7-inch & 10-inch tablet screenshots + 512x512 High-Res icon
   • Target SDK: 35 (Android 15+)`;

  const getCurrentSnippet = () => {
    switch (activeCodeTab) {
      case 'compose': return composeCodeSnippet;
      case 'schema': return firestoreSchemaSnippet;
      case 'rules': return securityRulesSnippet;
      case 'checklist': return checklistSnippet;
    }
  };

  const handleCopy = () => {
    navigator.clipboard?.writeText(getCurrentSnippet());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl">
      <div className="relative w-full max-w-3xl h-[88vh] ios-glass-card rounded-3xl p-6 border border-white/20 shadow-2xl flex flex-col justify-between overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Production Architecture & Android Suite
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Ready
                </span>
              </h2>
              <p className="text-xs text-slate-400">Jetpack Compose • Cloud Firestore • Security Rules • Play Store</p>
            </div>
          </div>
          <button
            onClick={() => setIsAdminModalOpen(false)}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1.5 py-2 overflow-x-auto no-scrollbar border-b border-white/10">
          {[
            { id: 'compose', label: 'Jetpack Compose UI', icon: Smartphone },
            { id: 'schema', label: 'Firestore Schema', icon: Database },
            { id: 'rules', label: 'Firebase Security Rules', icon: ShieldCheck },
            { id: 'checklist', label: 'Play Store Release Checklist', icon: CheckCircle2 },
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveCodeTab(tab.id as any)}
                className={`py-1.5 px-3 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border ${
                  activeCodeTab === tab.id
                    ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200'
                    : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Code Content Container */}
        <div className="relative flex-1 my-3 bg-black/60 rounded-2xl border border-white/10 p-4 overflow-y-auto font-mono text-xs leading-relaxed text-slate-300 select-text">
          <pre className="whitespace-pre-wrap">{getCurrentSnippet()}</pre>

          {/* Floating Copy Button */}
          <button
            onClick={handleCopy}
            className="absolute top-3 right-3 px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-sans font-semibold flex items-center gap-1.5 transition-colors shadow-lg backdrop-blur-md"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Code'}</span>
          </button>
        </div>

        {/* Footer */}
        <div className="pt-2 flex items-center justify-between text-xs text-slate-400 border-t border-white/10">
          <span>Target: Android 15 (API 35) • Kotlin 2.1 • Compose 1.8</span>
          <button
            onClick={() => setIsAdminModalOpen(false)}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold transition-colors shadow-md shadow-cyan-600/30"
          >
            Close Portal
          </button>
        </div>
      </div>
    </div>
  );
};
