import React, { useState } from 'react';
import { 
  Users, 
  BarChart3, 
  ShieldAlert, 
  ShieldCheck, 
  Search, 
  Filter, 
  MoreVertical, 
  Lock, 
  UserCheck, 
  UserX, 
  Key, 
  Smartphone, 
  HardDrive, 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  X, 
  Check, 
  Sliders, 
  Radio, 
  Eye, 
  RefreshCw,
  LogOut,
  Send
} from 'lucide-react';
import { AdminUser, AdminPermissions, SystemAnalytics, UserRole, UserStatus } from '../../types';
import { CURRENT_USER, CONTACTS } from '../../mock/initialData';

const INITIAL_ADMIN_USERS: AdminUser[] = [
  {
    ...CURRENT_USER,
    role: 'super_admin',
    status: 'active',
    joinedAt: 'Jan 15, 2026',
    reportedCount: 0,
    deviceCount: 3,
    storageUsedMB: 1420,
    permissions: {
      canManageUsers: true,
      canRevokeSessions: true,
      canViewAuditLogs: true,
      canManageRoles: true,
      canModifyFeatureFlags: true,
      canBroadcastAnnouncements: true,
    },
  },
  {
    ...CONTACTS[0], // Elena Vance
    role: 'moderator',
    status: 'active',
    joinedAt: 'Feb 02, 2026',
    reportedCount: 0,
    deviceCount: 2,
    storageUsedMB: 840,
    permissions: {
      canManageUsers: true,
      canRevokeSessions: false,
      canViewAuditLogs: true,
      canManageRoles: false,
      canModifyFeatureFlags: false,
      canBroadcastAnnouncements: false,
    },
  },
  {
    ...CONTACTS[1], // Rajesh Sharma
    role: 'member',
    status: 'active',
    joinedAt: 'Feb 18, 2026',
    reportedCount: 0,
    deviceCount: 1,
    storageUsedMB: 390,
    permissions: {
      canManageUsers: false,
      canRevokeSessions: false,
      canViewAuditLogs: false,
      canManageRoles: false,
      canModifyFeatureFlags: false,
      canBroadcastAnnouncements: false,
    },
  },
  {
    ...CONTACTS[2], // Dr. Sophia Chen
    role: 'moderator',
    status: 'active',
    joinedAt: 'Jan 28, 2026',
    reportedCount: 0,
    deviceCount: 2,
    storageUsedMB: 1120,
    permissions: {
      canManageUsers: true,
      canRevokeSessions: true,
      canViewAuditLogs: true,
      canManageRoles: false,
      canModifyFeatureFlags: false,
      canBroadcastAnnouncements: true,
    },
  },
  {
    ...CONTACTS[3], // Marcus Brody
    role: 'member',
    status: 'active',
    joinedAt: 'Mar 01, 2026',
    reportedCount: 0,
    deviceCount: 1,
    storageUsedMB: 540,
    permissions: {
      canManageUsers: false,
      canRevokeSessions: false,
      canViewAuditLogs: false,
      canManageRoles: false,
      canModifyFeatureFlags: false,
      canBroadcastAnnouncements: false,
    },
  },
  {
    id: 'user_ananya_5',
    name: 'Ananya Deshmukh',
    handle: '@ananya_d',
    phone: '+91 98205 11234',
    email: 'ananya.deshmukh@pune.in',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    bio: 'Mobile UI/UX designer & Flutter developer 🎨',
    isOnline: true,
    lastSeen: 'Online',
    passkeyEnrolled: true,
    twoFactorEnabled: true,
    pinLockEnabled: true,
    biometricLockEnabled: true,
    verifiedBadge: true,
    role: 'member',
    status: 'active',
    joinedAt: 'Mar 24, 2026',
    reportedCount: 0,
    deviceCount: 2,
    storageUsedMB: 320,
    permissions: {
      canManageUsers: false,
      canRevokeSessions: false,
      canViewAuditLogs: false,
      canManageRoles: false,
      canModifyFeatureFlags: false,
      canBroadcastAnnouncements: false,
    },
  },
];

const ANALYTICS_DATA: SystemAnalytics = {
  activeUsers24h: 18450,
  totalMessagesSent: 482190,
  storageTotalGB: 412.8,
  spamBlocked24h: 312,
  activeCallsCount: 47,
  serverUptime: '99.99%',
  e2eeVerificationRate: 99.98,
  networkLatencyMs: 14,
};

export const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'analytics' | 'users' | 'audit'>('analytics');
  const [usersList, setUsersList] = useState<AdminUser[]>(INITIAL_ADMIN_USERS);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'flagged' | 'suspended' | 'admins'>('all');
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [feedbackToast, setFeedbackToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setFeedbackToast(msg);
    setTimeout(() => setFeedbackToast(null), 2500);
  };

  const filteredUsers = usersList.filter(u => {
    const matchesSearch = 
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.handle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.phone.includes(searchQuery) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (statusFilter === 'active') return u.status === 'active';
    if (statusFilter === 'flagged') return u.status === 'flagged';
    if (statusFilter === 'suspended') return u.status === 'suspended';
    if (statusFilter === 'admins') return u.role === 'super_admin' || u.role === 'moderator';
    return true;
  });

  const handleTogglePermission = (userId: string, permKey: keyof AdminPermissions) => {
    setUsersList(prev => prev.map(u => {
      if (u.id !== userId) return u;
      const updated = {
        ...u,
        permissions: {
          ...u.permissions,
          [permKey]: !u.permissions[permKey],
        },
      };
      if (selectedUser?.id === userId) setSelectedUser(updated);
      return updated;
    }));
    showToast(`Updated permission: ${permKey}`);
  };

  const handleRoleChange = (userId: string, newRole: UserRole) => {
    setUsersList(prev => prev.map(u => {
      if (u.id !== userId) return u;
      const isSuper = newRole === 'super_admin';
      const isMod = newRole === 'moderator';
      const updated = {
        ...u,
        role: newRole,
        permissions: {
          canManageUsers: isSuper || isMod,
          canRevokeSessions: isSuper || isMod,
          canViewAuditLogs: isSuper || isMod,
          canManageRoles: isSuper,
          canModifyFeatureFlags: isSuper,
          canBroadcastAnnouncements: isSuper || isMod,
        },
      };
      if (selectedUser?.id === userId) setSelectedUser(updated);
      return updated;
    }));
    showToast(`User role updated to ${newRole}`);
  };

  const handleStatusChange = (userId: string, newStatus: UserStatus) => {
    setUsersList(prev => prev.map(u => {
      if (u.id !== userId) return u;
      const updated = { ...u, status: newStatus };
      if (selectedUser?.id === userId) setSelectedUser(updated);
      return updated;
    }));
    showToast(`User marked as ${newStatus}`);
  };

  const handleRevokeSessions = (userId: string) => {
    setUsersList(prev => prev.map(u => {
      if (u.id !== userId) return u;
      const updated = { ...u, deviceCount: 1 };
      if (selectedUser?.id === userId) setSelectedUser(updated);
      return updated;
    }));
    showToast('All remote device sessions terminated');
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 overflow-y-auto pb-24 text-slate-100">
      {/* Toast Notification */}
      {feedbackToast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-cyan-600 text-white text-xs font-bold shadow-xl border border-white/20 animate-fade-in flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{feedbackToast}</span>
        </div>
      )}

      {/* Header */}
      <div className="ios-glass px-4 pt-4 pb-3 border-b border-white/10 sticky top-0 z-20 backdrop-blur-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-600/30">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-extrabold text-white tracking-tight flex items-center gap-2">
                Aether Admin Console
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Root Admin
                </span>
              </h1>
              <p className="text-xs text-slate-400">System Monitoring, RBAC Permissions & User Safety</p>
            </div>
          </div>

          {/* Zero Bans Guarantee Status Button */}
          <button
            onClick={() => {
              setUsersList(prev => prev.map(u => ({ ...u, status: 'active', reportedCount: 0 })));
              showToast('Verified: All user accounts are 100% Active with zero bans');
            }}
            className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
            title="Guarantee all accounts remain active and free of bans"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Zero Bans • All 100% Active</span>
            <span className="sm:hidden">100% Active</span>
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="mt-3 grid grid-cols-3 gap-1 p-1 bg-white/5 rounded-xl border border-white/10">
          <button
            onClick={() => setActiveTab('analytics')}
            className={`py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'analytics'
                ? 'bg-white/20 text-white shadow-sm border border-white/15'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Analytics
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'users'
                ? 'bg-white/20 text-white shadow-sm border border-white/15'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            User Management ({usersList.length})
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'audit'
                ? 'bg-white/20 text-white shadow-sm border border-white/15'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            Audit Logs
          </button>
        </div>
      </div>

      {/* TAB 1: ANALYTICS DASHBOARD */}
      {activeTab === 'analytics' && (
        <div className="p-4 space-y-4">
          {/* Top KPIs Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="ios-glass-card rounded-2xl p-3.5 border border-white/10 space-y-1">
              <span className="text-[11px] text-slate-400 font-medium">Daily Active Users</span>
              <p className="text-xl font-bold text-white tracking-tight">{ANALYTICS_DATA.activeUsers24h.toLocaleString()}</p>
              <div className="flex items-center gap-1 text-[10px] text-emerald-400">
                <span>↑ 12.4% vs last week</span>
              </div>
            </div>

            <div className="ios-glass-card rounded-2xl p-3.5 border border-white/10 space-y-1">
              <span className="text-[11px] text-slate-400 font-medium">Messages Sent (24h)</span>
              <p className="text-xl font-bold text-cyan-400 tracking-tight">{ANALYTICS_DATA.totalMessagesSent.toLocaleString()}</p>
              <div className="flex items-center gap-1 text-[10px] text-cyan-300">
                <span>Signal E2EE 99.98%</span>
              </div>
            </div>

            <div className="ios-glass-card rounded-2xl p-3.5 border border-white/10 space-y-1">
              <span className="text-[11px] text-slate-400 font-medium">Cloud Media Storage</span>
              <p className="text-xl font-bold text-purple-400 tracking-tight">{ANALYTICS_DATA.storageTotalGB} GB</p>
              <div className="flex items-center gap-1 text-[10px] text-slate-400">
                <span>Encrypted Buckets</span>
              </div>
            </div>

            <div className="ios-glass-card rounded-2xl p-3.5 border border-white/10 space-y-1">
              <span className="text-[11px] text-slate-400 font-medium">Spam & Phishing Blocked</span>
              <p className="text-xl font-bold text-rose-400 tracking-tight">{ANALYTICS_DATA.spamBlocked24h}</p>
              <div className="flex items-center gap-1 text-[10px] text-rose-300">
                <span>AI Radar Defense</span>
              </div>
            </div>
          </div>

          {/* Infrastructure Health Bar */}
          <div className="ios-glass rounded-2xl p-4 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                Global WebRTC & Firestore Relay Mesh
              </span>
              <span className="text-[11px] text-emerald-400 font-mono">Uptime: {ANALYTICS_DATA.serverUptime}</span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                <span className="text-[10px] text-slate-400 block">Edge Latency</span>
                <span className="text-sm font-bold text-cyan-300">{ANALYTICS_DATA.networkLatencyMs} ms</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                <span className="text-[10px] text-slate-400 block">Concurrent Calls</span>
                <span className="text-sm font-bold text-emerald-300">{ANALYTICS_DATA.activeCallsCount} Active</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                <span className="text-[10px] text-slate-400 block">Signal Kyber Rate</span>
                <span className="text-sm font-bold text-purple-300">{ANALYTICS_DATA.e2eeVerificationRate}%</span>
              </div>
            </div>
          </div>

          {/* Live System Safety Notices */}
          <div className="ios-glass-card rounded-2xl p-4 border border-white/10 space-y-2.5">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">Safety & Privacy Guardrails Active</h3>
            <div className="space-y-1.5 text-xs text-slate-300">
              <div className="flex items-center gap-2 p-2 rounded-xl bg-white/5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Zero-knowledge location architecture: GPS coordinates only transmit with runtime explicit user consent.</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-xl bg-white/5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>CameraX foreground lock: Hardware cameras never activate in background threads or without intent.</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-xl bg-white/5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Signal Double Ratchet post-quantum forward secrecy enforced on all 1:1 and group chats.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: USER MANAGEMENT & PERMISSIONS */}
      {activeTab === 'users' && (
        <div className="p-4 space-y-3.5">
          {/* Search & Filter Bar */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white">
              <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search user by name, handle, email, phone..."
                className="flex-1 bg-transparent placeholder-slate-500 focus:outline-none text-xs"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="text-slate-400 hover:text-white">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
              {[
                { id: 'all', label: 'All Users' },
                { id: 'active', label: 'Active' },
                { id: 'flagged', label: 'Flagged / Reports' },
                { id: 'suspended', label: 'Suspended' },
                { id: 'admins', label: 'Admins & Mods' },
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setStatusFilter(f.id as any)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all border ${
                    statusFilter === f.id
                      ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200'
                      : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* User List Rows */}
          <div className="ios-glass rounded-2xl border border-white/10 divide-y divide-white/5 overflow-hidden">
            {filteredUsers.map(user => {
              const isSuper = user.role === 'super_admin';
              const isMod = user.role === 'moderator';

              return (
                <div
                  key={user.id}
                  className="p-3.5 hover:bg-white/5 transition-colors flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-11 h-11 rounded-full object-cover border border-white/15 shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-white truncate">{user.name}</span>
                        {user.verifiedBadge && (
                          <span className="text-[10px] text-cyan-400 font-semibold">✓</span>
                        )}
                        <span className={`text-[10px] px-1.5 py-0.2 rounded-md font-bold uppercase ${
                          isSuper 
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                            : isMod 
                            ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                            : 'bg-white/10 text-slate-400'
                        }`}>
                          {user.role}
                        </span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded-md font-semibold ${
                          user.status === 'active' 
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : user.status === 'flagged'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}>
                          {user.status}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5 truncate">
                        <span>{user.handle}</span>
                        <span>·</span>
                        <span>{user.phone}</span>
                        <span>·</span>
                        <span>{user.deviceCount} devices</span>
                        {user.reportedCount > 0 && (
                          <span className="text-rose-400 font-bold">({user.reportedCount} reports)</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Inspect & Manage Button */}
                  <button
                    onClick={() => setSelectedUser(user)}
                    className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-cyan-300 border border-white/10 transition-colors shrink-0 flex items-center gap-1.5"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>Permissions</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: AUDIT LOGS */}
      {activeTab === 'audit' && (
        <div className="p-4 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">Security & Administrative Audit Trail</span>
          <div className="ios-glass rounded-2xl border border-white/10 divide-y divide-white/5 text-xs text-slate-300">
            {[
              { event: 'FIDO2 Passkey Enrolled', user: 'Aayush Dalvi (@aayush)', ip: '103.21.244.12', time: '10 mins ago', status: 'Success' },
              { event: 'Consent Live Location Session Started (1h)', user: 'Elena Vance (@elena_v)', ip: '198.51.100.42', time: '24 mins ago', status: 'Consent Verified' },
              { event: 'Role Elevation to Moderator', user: 'Dr. Sophia Chen (@sophia_ai)', ip: '192.0.2.1', time: '1 hour ago', status: 'Approved by Root' },
              { event: 'Suspicious Relay Intercepted by AI Radar', user: 'Suspicious Relay Bot', ip: '45.33.32.156', time: '3 hours ago', status: 'Blocked (18 Reports)' },
              { event: 'WebRTC Group Mesh Connected (5 participants)', user: 'Omni SuperCore Engineers', ip: 'Mesh P2P', time: '4 hours ago', status: 'Encrypted' },
              { event: 'Biometric App Lock Passed', user: 'Aayush Dalvi (@aayush)', ip: 'Device Secure Enclave', time: '5 hours ago', status: 'Hardware Verified' },
            ].map((log, i) => (
              <div key={i} className="p-3 flex items-center justify-between gap-2">
                <div className="space-y-0.5">
                  <span className="font-semibold text-white block">{log.event}</span>
                  <span className="text-[11px] text-slate-400">{log.user} • {log.ip}</span>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[10px] font-mono text-cyan-300 block">{log.status}</span>
                  <span className="text-[10px] text-slate-500">{log.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: USER MANAGEMENT & PERMISSIONS DETAIL VIEW */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl">
          <div className="relative w-full max-w-lg ios-glass-card rounded-3xl p-5 border border-white/20 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <img src={selectedUser.avatar} alt={selectedUser.name} className="w-10 h-10 rounded-full object-cover border border-white/20" />
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                    {selectedUser.name}
                    <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300">
                      {selectedUser.role}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">{selectedUser.handle} • Joined {selectedUser.joinedAt}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedUser(null)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Role & Status Modifiers */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-300">Assign Role</label>
                <select
                  value={selectedUser.role}
                  onChange={e => handleRoleChange(selectedUser.id, e.target.value as UserRole)}
                  className="w-full bg-white/10 border border-white/15 rounded-xl text-xs text-white p-2 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                >
                  <option value="member" className="bg-slate-900 text-white">Member</option>
                  <option value="support" className="bg-slate-900 text-white">Support Specialist</option>
                  <option value="moderator" className="bg-slate-900 text-white">Moderator</option>
                  <option value="super_admin" className="bg-slate-900 text-white">Super Admin</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-300">Account Status</label>
                <select
                  value={selectedUser.status}
                  onChange={e => handleStatusChange(selectedUser.id, e.target.value as UserStatus)}
                  className="w-full bg-white/10 border border-white/15 rounded-xl text-xs text-white p-2 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                >
                  <option value="active" className="bg-slate-900 text-white">Active</option>
                  <option value="flagged" className="bg-slate-900 text-white">Flagged for Review</option>
                  <option value="suspended" className="bg-slate-900 text-white">Suspended (Banned)</option>
                </select>
              </div>
            </div>

            {/* Granular Permissions Matrix */}
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 block">
                Granular Permissions Matrix
              </span>

              <div className="ios-glass rounded-2xl border border-white/10 divide-y divide-white/5 overflow-hidden">
                {[
                  { key: 'canManageUsers' as const, label: 'Manage User Accounts', desc: 'Can suspend, verify, or edit account flags' },
                  { key: 'canRevokeSessions' as const, label: 'Revoke Device Sessions', desc: 'Can remotely log out compromised user devices' },
                  { key: 'canViewAuditLogs' as const, label: 'View Security Audit Logs', desc: 'Access to system events and IP telemetry' },
                  { key: 'canManageRoles' as const, label: 'Manage Staff Roles', desc: 'Promote or demote moderators & staff' },
                  { key: 'canModifyFeatureFlags' as const, label: 'Modify Feature Flags', desc: 'Enable beta messaging codecs and protocols' },
                  { key: 'canBroadcastAnnouncements' as const, label: 'Broadcast Official Alerts', desc: 'Publish verified notices to announcement channels' },
                ].map(perm => {
                  const isChecked = selectedUser.permissions[perm.key];
                  return (
                    <div key={perm.key} className="p-3 flex items-center justify-between gap-3">
                      <div>
                        <span className="text-xs font-semibold text-white block">{perm.label}</span>
                        <span className="text-[10px] text-slate-400">{perm.desc}</span>
                      </div>
                      <button
                        onClick={() => handleTogglePermission(selectedUser.id, perm.key)}
                        className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                          isChecked ? 'bg-cyan-600' : 'bg-slate-700'
                        }`}
                      >
                        <span className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${
                          isChecked ? 'left-5' : 'left-0.5'
                        }`} />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Account Quick Metrics & Security */}
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                <span className="text-[10px] text-slate-400 block">Storage Used</span>
                <span className="font-bold text-white">{selectedUser.storageUsedMB} MB</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                <span className="text-[10px] text-slate-400 block">Active Devices</span>
                <span className="font-bold text-cyan-300">{selectedUser.deviceCount} Linked</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                <span className="text-[10px] text-slate-400 block">Passkey Status</span>
                <span className={`font-bold ${selectedUser.passkeyEnrolled ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {selectedUser.passkeyEnrolled ? 'Enrolled' : 'None'}
                </span>
              </div>
            </div>

            {/* Immediate Action Buttons */}
            <div className="flex gap-2 pt-1">
              <button
                onClick={() => handleRevokeSessions(selectedUser.id)}
                className="flex-1 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Revoke All Devices</span>
              </button>

              <button
                onClick={() => setSelectedUser(null)}
                className="flex-1 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-colors shadow-md shadow-cyan-600/30"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
