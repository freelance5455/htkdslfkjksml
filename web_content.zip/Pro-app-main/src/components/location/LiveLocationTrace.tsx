import React, { useState, useEffect } from 'react';
import { 
  Navigation, 
  ShieldCheck, 
  Clock, 
  Battery, 
  MapPin, 
  AlertOctagon, 
  Radio, 
  Compass, 
  CheckCircle2, 
  X, 
  ZoomIn, 
  ZoomOut, 
  Crosshair, 
  Layers, 
  Wifi, 
  Key, 
  Eye, 
  RefreshCw, 
  ChevronRight,
  UserCheck,
  Send,
  Zap,
  ArrowUpRight,
  AlertTriangle,
  Search,
  Filter,
  Flame,
  PhoneCall
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ActiveLocationTraceSession } from '../../types';
import { CONTACTS } from '../../mock/initialData';

export type TraceFilter = 'all' | 'emergency' | 'low_battery' | 'recent_activity';

interface LiveLocationTraceProps {
  onClose?: () => void;
  standalone?: boolean;
}

export const LiveLocationTrace: React.FC<LiveLocationTraceProps> = ({ onClose, standalone = false }) => {
  const { 
    currentUser, 
    liveLocation, 
    stopLiveLocation, 
    chats, 
    sendMessage, 
    activeChatId 
  } = useApp();

  // Active consent-based sessions list with Emergency and Low Battery states
  const [sessions, setSessions] = useState<ActiveLocationTraceSession[]>([
    {
      sessionId: 'sess_me_1',
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      chatId: 'chat_elena',
      chatTitle: 'Elena Vance',
      lat: 37.7749,
      lng: -122.4194,
      speedKmh: 4.8,
      headingDeg: 42,
      accuracyMeters: 6,
      batteryLevel: 94,
      connectionStatus: 'live',
      connectionLatencyMs: 16,
      isEmergency: false,
      lastUpdatedTimestamp: Date.now(),
      consentVerification: {
        verifiedAt: '12m ago',
        verifiedSignature: 'SIG_ED25519_99af28c... (Biometric Confirmed)',
        consentType: 'explicit_runtime',
        recipientScope: 'Elena Vance (Chat ID: chat_elena)',
        expiresAt: Date.now() + 48 * 60 * 1000,
      },
      currentStreetAddress: 'Market St & 4th, San Francisco, CA',
      trailHistory: [
        { lat: 37.7735, lng: -122.4210, timestamp: Date.now() - 600000 },
        { lat: 37.7742, lng: -122.4201, timestamp: Date.now() - 300000 },
        { lat: 37.7749, lng: -122.4194, timestamp: Date.now() },
      ],
    },
    {
      sessionId: 'sess_elena_2',
      userId: CONTACTS[0].id,
      userName: CONTACTS[0].name,
      userAvatar: CONTACTS[0].avatar,
      chatId: 'chat_elena',
      chatTitle: 'Elena Vance',
      lat: 37.7765,
      lng: -122.4170,
      speedKmh: 3.2,
      headingDeg: 215,
      accuracyMeters: 4,
      batteryLevel: 88,
      connectionStatus: 'live',
      connectionLatencyMs: 22,
      isEmergency: false,
      lastUpdatedTimestamp: Date.now() - 30000,
      consentVerification: {
        verifiedAt: '15m ago',
        verifiedSignature: 'SIG_ED25519_bb7101a... (PIN Verified)',
        consentType: 'explicit_runtime',
        recipientScope: 'Aayush Dalvi (1:1 Direct Session)',
        expiresAt: Date.now() + 45 * 60 * 1000,
      },
      currentStreetAddress: 'Mission St & 3rd, San Francisco, CA',
      trailHistory: [
        { lat: 37.7778, lng: -122.4155, timestamp: Date.now() - 500000 },
        { lat: 37.7770, lng: -122.4162, timestamp: Date.now() - 250000 },
        { lat: 37.7765, lng: -122.4170, timestamp: Date.now() },
      ],
    },
    {
      sessionId: 'sess_marcus_emergency',
      userId: CONTACTS[3].id,
      userName: CONTACTS[3].name,
      userAvatar: CONTACTS[3].avatar,
      chatId: 'chat_group_core',
      chatTitle: 'Incident Response Command',
      lat: 37.7785,
      lng: -122.4150,
      speedKmh: 0.0,
      headingDeg: 0,
      accuracyMeters: 3,
      batteryLevel: 14, // Low Battery Critical
      connectionStatus: 'live',
      connectionLatencyMs: 12,
      isEmergency: true, // Emergency SOS Triggered!
      lastUpdatedTimestamp: Date.now() - 15000,
      consentVerification: {
        verifiedAt: '2m ago',
        verifiedSignature: 'SIG_ED25519_EMERGENCY_SOS_9901 (Hardware SOS)',
        consentType: 'emergency_sos',
        recipientScope: 'All Active Safety Personnel & Contacts',
        expiresAt: Date.now() + 120 * 60 * 1000,
      },
      currentStreetAddress: 'Howard St & 2nd St, San Francisco, CA',
      trailHistory: [
        { lat: 37.7780, lng: -122.4158, timestamp: Date.now() - 180000 },
        { lat: 37.7785, lng: -122.4150, timestamp: Date.now() },
      ],
    },
    {
      sessionId: 'sess_liam_courier',
      userId: 'user_liam_transit',
      userName: 'Liam Sterling',
      userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      chatId: 'chat_group_core',
      chatTitle: 'Field Rapid Transit',
      lat: 37.7710,
      lng: -122.4215,
      speedKmh: 24.6,
      headingDeg: 310,
      accuracyMeters: 5,
      batteryLevel: 18, // Low Battery Warning
      connectionStatus: 'live',
      connectionLatencyMs: 28,
      isEmergency: false,
      lastUpdatedTimestamp: Date.now() - 40000,
      consentVerification: {
        verifiedAt: '25m ago',
        verifiedSignature: 'SIG_ED25519_liam_transit_88a (Verified Driver)',
        consentType: 'explicit_runtime',
        recipientScope: 'Field Rapid Transit Dispatch',
        expiresAt: Date.now() + 35 * 60 * 1000,
      },
      currentStreetAddress: 'Folsom St & 8th St, San Francisco, CA',
      trailHistory: [
        { lat: 37.7690, lng: -122.4240, timestamp: Date.now() - 120000 },
        { lat: 37.7702, lng: -122.4228, timestamp: Date.now() - 60000 },
        { lat: 37.7710, lng: -122.4215, timestamp: Date.now() },
      ],
    },
    {
      sessionId: 'sess_sophia_3',
      userId: CONTACTS[2].id,
      userName: CONTACTS[2].name,
      userAvatar: CONTACTS[2].avatar,
      chatId: 'chat_group_core',
      chatTitle: 'Omni SuperCore Engineers',
      lat: 37.7720,
      lng: -122.4230,
      speedKmh: 0.0,
      headingDeg: 0,
      accuracyMeters: 8,
      batteryLevel: 76,
      connectionStatus: 'live',
      connectionLatencyMs: 31,
      isEmergency: false,
      lastUpdatedTimestamp: Date.now() - 180000,
      consentVerification: {
        verifiedAt: '5m ago',
        verifiedSignature: 'SIG_ED25519_aa490e2... (App Lock Verified)',
        consentType: 'explicit_runtime',
        recipientScope: 'Omni SuperCore Engineers (Group Broadcast)',
        expiresAt: Date.now() + 55 * 60 * 1000,
      },
      currentStreetAddress: 'Howard St & 6th, San Francisco, CA',
      trailHistory: [
        { lat: 37.7720, lng: -122.4230, timestamp: Date.now() },
      ],
    },
  ]);

  const [activeFilter, setActiveFilter] = useState<TraceFilter>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSessionId, setSelectedSessionId] = useState<string>(sessions[0].sessionId);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [mapLayer, setMapLayer] = useState<'streets' | 'satellite' | 'hud'>('hud');
  const [showConsentModal, setShowConsentModal] = useState<boolean>(false);
  const [mutualRequestSent, setMutualRequestSent] = useState<boolean>(false);

  // Dynamic real-time telemetry drift simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setSessions(prev => prev.map(s => {
        if (s.connectionStatus === 'offline' || s.speedKmh === 0) return s;
        // Minor realistic coordinate delta
        const deltaLat = (Math.random() - 0.48) * 0.00015;
        const deltaLng = (Math.random() - 0.48) * 0.00015;
        const newLat = s.lat + deltaLat;
        const newLng = s.lng + deltaLng;
        const newLatency = Math.floor(Math.random() * 12) + 14;

        return {
          ...s,
          lat: newLat,
          lng: newLng,
          connectionLatencyMs: newLatency,
          speedKmh: Math.max(1.2, +(s.speedKmh + (Math.random() - 0.5) * 0.4).toFixed(1)),
          trailHistory: [
            ...s.trailHistory.slice(-5),
            { lat: newLat, lng: newLng, timestamp: Date.now() }
          ]
        };
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Filter calculations & incident metrics
  const emergencyCount = sessions.filter(s => s.isEmergency).length;
  const lowBatteryCount = sessions.filter(s => s.batteryLevel <= 20).length;
  const recentActivityCount = sessions.filter(s => s.speedKmh > 0 || (Date.now() - s.lastUpdatedTimestamp) < 180000).length;

  const filteredSessions = sessions.filter(s => {
    if (activeFilter === 'emergency' && !s.isEmergency) return false;
    if (activeFilter === 'low_battery' && s.batteryLevel > 20) return false;
    if (activeFilter === 'recent_activity' && s.speedKmh === 0 && (Date.now() - s.lastUpdatedTimestamp) >= 180000) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        s.userName.toLowerCase().includes(q) ||
        s.currentStreetAddress.toLowerCase().includes(q) ||
        s.chatTitle.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const activeSession = filteredSessions.find(s => s.sessionId === selectedSessionId) || filteredSessions[0] || sessions[0];

  const handleRevokeSession = (sessionId: string) => {
    setSessions(prev => prev.filter(s => s.sessionId !== sessionId));
    if (sessionId === sessions[0].sessionId) {
      stopLiveLocation();
    }
    alert('Session successfully revoked. Coordinates wiped from active mesh.');
  };

  const handleSendMutualRequest = () => {
    setMutualRequestSent(true);
    if (activeChatId) {
      sendMessage(activeChatId, 'Requested reciprocal consent-based live location sharing for safe arrival confirmation.', 'text');
    }
    setTimeout(() => setMutualRequestSent(false), 3000);
  };

  // Convert GPS delta to SVG canvas coordinate percentages relative to center (37.7745, -122.4200)
  const getMapCoordinates = (lat: number, lng: number) => {
    const centerLat = 37.7745;
    const centerLng = -122.4200;
    const scale = 8000 * zoomLevel;
    const x = 50 + (lng - centerLng) * scale;
    const y = 50 - (lat - centerLat) * scale;
    return {
      x: Math.max(8, Math.min(92, x)),
      y: Math.max(8, Math.min(92, y)),
    };
  };

  return (
    <div className={`flex flex-col h-full bg-slate-950 text-slate-100 overflow-hidden ${standalone ? 'p-0' : ''}`}>
      {/* Top Header / Status Bar */}
      <div className="ios-glass px-4 py-3 border-b border-white/10 z-20 backdrop-blur-2xl flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center border border-cyan-400/40 shadow-lg shadow-cyan-500/25">
            <Navigation className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm font-extrabold text-white tracking-tight flex items-center gap-1.5">
              Live Location Trace
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {sessions.length} Active Sessions
              </span>
              {emergencyCount > 0 && (
                <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded-full bg-rose-500/30 text-rose-300 border border-rose-500/50 animate-pulse">
                  {emergencyCount} SOS Alert
                </span>
              )}
            </h2>
            <p className="text-[11px] text-slate-400">Incident Command & Field Monitoring • 256-bit Signal Mesh</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Layer switcher */}
          <button
            onClick={() => setMapLayer(l => l === 'hud' ? 'satellite' : l === 'satellite' ? 'streets' : 'hud')}
            className="px-2.5 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-[11px] font-semibold text-cyan-300 border border-white/10 flex items-center gap-1 transition-colors"
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="capitalize">{mapLayer}</span>
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Incident Response & Criteria Filter Strip */}
      <div className="ios-glass px-4 py-2 border-b border-white/10 z-20 backdrop-blur-2xl space-y-2">
        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {/* All Active */}
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border whitespace-nowrap ${
              activeFilter === 'all'
                ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 shadow-md ring-1 ring-cyan-400/50'
                : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>All Active</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/10 font-mono">
              {sessions.length}
            </span>
          </button>

          {/* Emergency Status (SOS) */}
          <button
            onClick={() => setActiveFilter('emergency')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border whitespace-nowrap ${
              activeFilter === 'emergency'
                ? 'bg-rose-500/30 border-rose-500 text-rose-200 shadow-lg ring-1 ring-rose-500/50'
                : 'bg-white/5 border-white/10 text-slate-400 hover:text-rose-300'
            }`}
          >
            <AlertOctagon className={`w-3.5 h-3.5 text-rose-400 ${emergencyCount > 0 ? 'animate-pulse' : ''}`} />
            <span>Emergency Status</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-black ${
              emergencyCount > 0 ? 'bg-rose-600 text-white animate-bounce' : 'bg-white/10 text-slate-400'
            }`}>
              {emergencyCount}
            </span>
          </button>

          {/* Low Battery Warning */}
          <button
            onClick={() => setActiveFilter('low_battery')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border whitespace-nowrap ${
              activeFilter === 'low_battery'
                ? 'bg-amber-500/30 border-amber-500 text-amber-200 shadow-md ring-1 ring-amber-500/50'
                : 'bg-white/5 border-white/10 text-slate-400 hover:text-amber-300'
            }`}
          >
            <Battery className="w-3.5 h-3.5 text-amber-400" />
            <span>Low Battery (≤20%)</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-mono">
              {lowBatteryCount}
            </span>
          </button>

          {/* Recent Activity */}
          <button
            onClick={() => setActiveFilter('recent_activity')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border whitespace-nowrap ${
              activeFilter === 'recent_activity'
                ? 'bg-emerald-500/30 border-emerald-500 text-emerald-200 shadow-md ring-1 ring-emerald-500/50'
                : 'bg-white/5 border-white/10 text-slate-400 hover:text-emerald-300'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-emerald-400" />
            <span>Recent Activity / Moving</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-mono">
              {recentActivityCount}
            </span>
          </button>
        </div>

        {/* Search Bar & Filter Summary */}
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 bg-black/40 border border-white/10 rounded-xl px-2.5 py-1 text-xs text-white">
            <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by agent name, street, or mission thread..."
              className="flex-1 bg-transparent placeholder-slate-500 focus:outline-none text-[11px]"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="text-slate-400 hover:text-white">
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Clear Filter Indicator if active */}
          {(activeFilter !== 'all' || searchQuery) && (
            <button
              onClick={() => {
                setActiveFilter('all');
                setSearchQuery('');
              }}
              className="text-[11px] text-cyan-400 hover:underline shrink-0 font-semibold"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Main Map Canvas Area */}
      <div className="relative flex-1 bg-slate-950 overflow-hidden select-none">
        
        {/* Dynamic Vector/Grid Map Background */}
        <div className="absolute inset-0 bg-slate-950">
          {/* Stylized vector street grid */}
          <svg className="w-full h-full opacity-40" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255, 255, 255, 0.08)" strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            {/* Main stylized street vectors */}
            <line x1="0" y1="35%" x2="100%" y2="45%" stroke="rgba(56, 189, 248, 0.25)" strokeWidth="4" />
            <line x1="0" y1="65%" x2="100%" y2="55%" stroke="rgba(56, 189, 248, 0.2)" strokeWidth="3" />
            <line x1="30%" y1="0" x2="40%" y2="100%" stroke="rgba(56, 189, 248, 0.2)" strokeWidth="3" />
            <line x1="70%" y1="0" x2="65%" y2="100%" stroke="rgba(56, 189, 248, 0.2)" strokeWidth="3" />
          </svg>

          {/* Landmarks / Street names */}
          <div className="absolute top-[33%] left-[10%] text-[10px] font-mono text-cyan-400/50 uppercase tracking-widest pointer-events-none">
            Market Street Corridor
          </div>
          <div className="absolute bottom-[36%] right-[15%] text-[10px] font-mono text-cyan-400/50 uppercase tracking-widest pointer-events-none">
            Mission Bay Transit
          </div>
        </div>

        {/* Trail History Lines for Filtered Sessions */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
          {filteredSessions.map(s => {
            if (s.trailHistory.length < 2) return null;
            const points = s.trailHistory.map(p => {
              const coords = getMapCoordinates(p.lat, p.lng);
              return `${coords.x}%,${coords.y}%`;
            }).join(' ');

            const strokeColor = s.isEmergency 
              ? '#f43f5e' 
              : s.userId === currentUser.id 
              ? '#00e5ff' 
              : '#a855f7';

            return (
              <polyline
                key={s.sessionId}
                points={points}
                fill="none"
                stroke={strokeColor}
                strokeWidth={s.isEmergency ? "3.5" : "2.5"}
                strokeDasharray="4 3"
                opacity={0.8}
              />
            );
          })}
        </svg>

        {/* Real-time Filtered Session Markers */}
        {filteredSessions.map(s => {
          const coords = getMapCoordinates(s.lat, s.lng);
          const isSelected = s.sessionId === selectedSessionId;
          const isMe = s.userId === currentUser.id;
          const isLowBat = s.batteryLevel <= 20;

          return (
            <div
              key={s.sessionId}
              onClick={() => setSelectedSessionId(s.sessionId)}
              className="absolute z-20 -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-700 ease-out group"
              style={{ left: `${coords.x}%`, top: `${coords.y}%` }}
            >
              {/* Pulsing Accuracy Radius Circle */}
              <div 
                className={`absolute -inset-4 rounded-full transition-all animate-ping opacity-35 ${
                  s.isEmergency
                    ? 'bg-rose-500 border border-rose-400'
                    : isMe 
                    ? 'bg-cyan-500 border border-cyan-400' 
                    : 'bg-purple-500 border border-purple-400'
                }`}
                style={{ width: `${s.accuracyMeters * 6}px`, height: `${s.accuracyMeters * 6}px`, margin: 'auto' }}
              />

              {/* Concentric Radar Ripple Ring */}
              {s.connectionStatus === 'live' && (
                <div 
                  className={`absolute -inset-2 rounded-full pointer-events-none animate-radar-ripple ${
                    s.isEmergency
                      ? 'bg-rose-500/25 border border-rose-500'
                      : isMe 
                      ? 'bg-cyan-400/15 border border-cyan-400/40' 
                      : 'bg-purple-400/15 border border-purple-400/40'
                  }`}
                />
              )}

              {/* Marker Avatar & Status Glow with Heartbeat Pulse */}
              <div className={`relative w-12 h-12 rounded-full p-0.5 transition-transform duration-200 group-hover:scale-115 ${
                s.connectionStatus === 'live' ? 'animate-live-heartbeat' : ''
              } ${
                s.isEmergency
                  ? 'ring-4 ring-rose-500 shadow-2xl shadow-rose-500/80 bg-gradient-to-tr from-rose-600 to-red-600 scale-110'
                  : isSelected 
                  ? 'ring-4 ring-cyan-400 shadow-xl shadow-cyan-500/50 scale-105' 
                  : 'ring-2 ring-white/40 shadow-lg'
              } ${
                !s.isEmergency && (isMe ? 'bg-gradient-to-tr from-cyan-400 to-blue-600' : 'bg-gradient-to-tr from-purple-500 to-pink-500')
              }`}>
                
                {/* Live or Emergency Micro-Badge Above Avatar */}
                <div className={`absolute -top-3.5 left-1/2 -translate-x-1/2 flex items-center gap-1 px-1.5 py-0.2 rounded-full shadow-lg text-[8px] font-extrabold tracking-wider pointer-events-none ${
                  s.isEmergency
                    ? 'bg-rose-950/95 border border-rose-500 text-rose-200 animate-pulse'
                    : 'bg-slate-950/95 border border-cyan-400/60 text-cyan-300'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full animate-ping ${s.isEmergency ? 'bg-rose-400' : 'bg-emerald-400'}`} />
                  <span>{s.isEmergency ? 'EMERGENCY SOS' : 'LIVE'}</span>
                </div>

                <img
                  src={s.userAvatar}
                  alt={s.userName}
                  className="w-full h-full rounded-full object-cover border-2 border-slate-950"
                />

                {/* Connection Status Indicator Dot */}
                <span className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full ring-2 ring-slate-950 flex items-center justify-center shadow-sm ${
                  s.isEmergency ? 'bg-rose-500' : 'bg-emerald-500'
                }`}>
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                </span>

                {/* Low Battery Warning Badge */}
                {isLowBat && (
                  <div className="absolute -bottom-2 -left-1.5 px-1 py-0.2 rounded bg-amber-950/95 border border-amber-500/80 text-[8px] font-black text-amber-300 flex items-center gap-0.5 shadow-md">
                    <Battery className="w-2.5 h-2.5 text-amber-400" />
                    <span>{s.batteryLevel}%</span>
                  </div>
                )}

                {/* Heading / Directional Arrow Indicator */}
                <div 
                  className={`absolute -top-1.5 right-0 w-3.5 h-3.5 drop-shadow-md transition-transform ${
                    s.isEmergency ? 'text-rose-300' : 'text-cyan-300'
                  }`}
                  style={{ transform: `rotate(${s.headingDeg}deg)` }}
                >
                  ▲
                </div>
              </div>

              {/* Marker Popover Chip */}
              <div className={`absolute top-14 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-md backdrop-blur-md border text-[10px] font-bold text-white whitespace-nowrap shadow-lg flex items-center gap-1 ${
                s.isEmergency 
                  ? 'bg-rose-950/90 border-rose-500/50' 
                  : 'bg-black/80 border-white/15'
              }`}>
                <span>{s.userName.split(' ')[0]}</span>
                <span className={`font-mono ${s.isEmergency ? 'text-rose-300' : 'text-cyan-400'}`}>
                  ({s.speedKmh} km/h)
                </span>
              </div>
            </div>
          );
        })}

        {/* Top-Right HUD Overlay: Connection & GPS Telemetry */}
        <div className="absolute top-3 right-3 z-30 flex flex-col gap-1.5 pointer-events-auto">
          {/* Signal & GPS Fix */}
          <div className="px-3 py-1.5 rounded-xl bg-black/75 backdrop-blur-md border border-white/10 text-xs text-white shadow-xl flex items-center gap-2">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span className="font-mono text-[11px] text-emerald-300 font-bold">3D GPS FIX ±{activeSession.accuracyMeters}m</span>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-black/75 backdrop-blur-md border border-white/10 text-[11px] text-slate-300 shadow-xl flex items-center justify-between gap-3">
            <span className="flex items-center gap-1.5">
              <Wifi className="w-3 h-3 text-cyan-400" />
              <span>Mesh Ping</span>
            </span>
            <span className="font-mono text-cyan-300">{activeSession.connectionLatencyMs} ms</span>
          </div>

          <div className={`px-3 py-1.5 rounded-xl backdrop-blur-md border text-[11px] shadow-xl flex items-center justify-between gap-3 ${
            activeSession.batteryLevel <= 20
              ? 'bg-amber-950/80 border-amber-500/50 text-amber-200'
              : 'bg-black/75 border-white/10 text-slate-300'
          }`}>
            <span className="flex items-center gap-1.5">
              <Battery className={`w-3 h-3 ${activeSession.batteryLevel <= 20 ? 'text-amber-400 animate-pulse' : 'text-emerald-400'}`} />
              <span>Battery</span>
            </span>
            <span className={`font-mono font-bold ${activeSession.batteryLevel <= 20 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {activeSession.batteryLevel}% {activeSession.batteryLevel <= 20 && '⚠️'}
            </span>
          </div>
        </div>

        {/* Bottom-Right Map Zoom & Recenter Controls */}
        <div className="absolute bottom-4 right-3 z-30 flex flex-col gap-1.5 pointer-events-auto">
          <button
            onClick={() => setZoomLevel(z => Math.min(2.2, z + 0.3))}
            className="w-9 h-9 rounded-xl bg-black/80 backdrop-blur-md border border-white/15 text-white hover:bg-black flex items-center justify-center shadow-lg transition-transform active:scale-95"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoomLevel(z => Math.max(0.7, z - 0.3))}
            className="w-9 h-9 rounded-xl bg-black/80 backdrop-blur-md border border-white/15 text-white hover:bg-black flex items-center justify-center shadow-lg transition-transform active:scale-95"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setZoomLevel(1);
              setSelectedSessionId(sessions[0].sessionId);
            }}
            className="w-9 h-9 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white flex items-center justify-center shadow-lg transition-transform active:scale-95"
            title="Recenter on My Position"
          >
            <Crosshair className="w-4 h-4" />
          </button>
        </div>

        {/* Bottom-Left Session Carousel Selector (Filtered) */}
        <div className="absolute bottom-4 left-3 z-30 flex items-center gap-1.5 overflow-x-auto no-scrollbar max-w-[calc(100%-110px)] pointer-events-auto">
          {filteredSessions.map(s => (
            <button
              key={s.sessionId}
              onClick={() => setSelectedSessionId(s.sessionId)}
              className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-2 backdrop-blur-md transition-all shadow-lg whitespace-nowrap ${
                s.sessionId === selectedSessionId
                  ? s.isEmergency
                    ? 'bg-rose-500/30 border-rose-500 text-white ring-2 ring-rose-500'
                    : 'bg-cyan-500/25 border-cyan-400 text-white ring-1 ring-cyan-400'
                  : s.isEmergency
                  ? 'bg-rose-950/80 border-rose-500/40 text-rose-300'
                  : 'bg-black/75 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              <img src={s.userAvatar} alt={s.userName} className="w-4 h-4 rounded-full object-cover" />
              <span>{s.userName.split(' ')[0]}</span>
              {s.isEmergency ? (
                <span className="text-[10px] text-rose-400 font-bold">🚨 SOS</span>
              ) : s.batteryLevel <= 20 ? (
                <span className="text-[10px] text-amber-400 font-mono">⚠️ {s.batteryLevel}%</span>
              ) : (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              )}
            </button>
          ))}
          {filteredSessions.length === 0 && (
            <div className="px-3 py-1.5 rounded-xl bg-black/80 border border-white/10 text-xs text-slate-400">
              No active sessions match the criteria
            </div>
          )}
        </div>
      </div>

      {/* Selected Session Detail & Incident Response Panel */}
      <div className="ios-glass border-t border-white/10 p-4 space-y-3 z-20 backdrop-blur-2xl">
        
        {/* Emergency Beacon Callout if Emergency Status */}
        {activeSession.isEmergency && (
          <div className="p-3 rounded-2xl bg-rose-950/70 border border-rose-500/60 flex items-center justify-between gap-3 animate-pulse shadow-xl shadow-rose-950/40">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0">
                <AlertOctagon className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-black text-rose-100 uppercase tracking-wider block">
                  CRITICAL: HARDWARE EMERGENCY SOS ACTIVE
                </span>
                <span className="text-[11px] text-rose-300">
                  Agent requested immediate field assistance. Battery at critical {activeSession.batteryLevel}%.
                </span>
              </div>
            </div>
            <button
              onClick={() => alert(`Emergency incident response dispatched to ${activeSession.currentStreetAddress}`)}
              className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shrink-0 shadow-lg flex items-center gap-1.5 transition-colors"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Dispatch Unit</span>
            </button>
          </div>
        )}

        {/* Low Battery Warning Banner */}
        {activeSession.batteryLevel <= 20 && !activeSession.isEmergency && (
          <div className="p-2.5 rounded-xl bg-amber-950/50 border border-amber-500/40 flex items-center gap-2 text-xs text-amber-200">
            <Battery className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
            <span>
              <strong>Low Battery Advisory ({activeSession.batteryLevel}%):</strong> Device in power-conservation mode. Coordinates ping throttled to preserve telemetry.
            </span>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={activeSession.userAvatar}
              alt={activeSession.userName}
              className="w-10 h-10 rounded-full object-cover border border-white/20 shadow-md"
            />
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                {activeSession.userName}
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 font-mono">
                  {activeSession.speedKmh} km/h
                </span>
                {activeSession.isEmergency && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-rose-500/25 text-rose-300 font-bold border border-rose-500/40">
                    SOS
                  </span>
                )}
                {activeSession.batteryLevel <= 20 && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/25 text-amber-300 font-bold border border-amber-500/40">
                    {activeSession.batteryLevel}% Bat
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-300 flex items-center gap-1 mt-0.5 truncate max-w-xs">
                <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span className="truncate">{activeSession.currentStreetAddress}</span>
              </p>
            </div>
          </div>

          {/* Consent Verification Stamp */}
          <button
            onClick={() => setShowConsentModal(true)}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Consent Verified</span>
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 pt-1">
          {activeSession.userId === currentUser.id ? (
            <button
              onClick={() => handleRevokeSession(activeSession.sessionId)}
              className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-md shadow-rose-600/30 flex items-center justify-center gap-1.5"
            >
              <AlertOctagon className="w-4 h-4" />
              <span>Revoke My Location Immediately</span>
            </button>
          ) : (
            <button
              onClick={handleSendMutualRequest}
              disabled={mutualRequestSent}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md shadow-cyan-600/30 flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>{mutualRequestSent ? 'Mutual Request Sent ✓' : 'Request Reciprocal Live Share'}</span>
            </button>
          )}

          <button
            onClick={() => {
              if (activeChatId) {
                sendMessage(activeChatId, `Incident Coordinates: ${activeSession.currentStreetAddress} (${activeSession.lat.toFixed(4)}, ${activeSession.lng.toFixed(4)}) - Battery: ${activeSession.batteryLevel}%`, 'text');
                alert('Shared coordinate link in active chat!');
              } else {
                alert(`Pin location: ${activeSession.currentStreetAddress}`);
              }
            }}
            className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white border border-white/10 flex items-center gap-1.5 transition-colors"
          >
            <ArrowUpRight className="w-4 h-4 text-cyan-400" />
            <span>Share Pin</span>
          </button>
        </div>
      </div>

      {/* Consent Verification Audit Modal */}
      {showConsentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl">
          <div className="relative w-full max-w-md ios-glass-card rounded-3xl p-5 border border-white/20 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Cryptographic Consent Record</h3>
                  <p className="text-[11px] text-slate-400">Zero-knowledge proof of authorization</p>
                </div>
              </div>
              <button
                onClick={() => setShowConsentModal(false)}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-1.5">
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>Authorization Type:</span>
                  <span className="text-emerald-400 font-semibold uppercase">Explicit Runtime Consent</span>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>Authorized Recipient:</span>
                  <span className="text-white font-medium">{activeSession.consentVerification.recipientScope}</span>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>Verification Timestamp:</span>
                  <span className="text-white">{activeSession.consentVerification.verifiedAt}</span>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>Automatic Expiry:</span>
                  <span className="text-cyan-300 font-mono">
                    {Math.round((activeSession.consentVerification.expiresAt - Date.now()) / 60000)} mins remaining
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
                  <Key className="w-3 h-3 text-cyan-400" />
                  Ed25519 Device Signature
                </span>
                <p className="font-mono text-[10px] text-cyan-300/80 break-all bg-black/60 p-2 rounded-lg border border-white/5">
                  {activeSession.consentVerification.verifiedSignature}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 text-[11px] text-emerald-200 space-y-1">
                <span className="font-semibold block">Privacy & Legal Compliance:</span>
                <p className="text-slate-300 text-[10px]">
                  This location session is strictly broadcast within the designated chat thread and expires automatically. Coordinates are never logged to public indexes or stored beyond the expiration epoch.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowConsentModal(false)}
              className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-colors"
            >
              Acknowledge & Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
