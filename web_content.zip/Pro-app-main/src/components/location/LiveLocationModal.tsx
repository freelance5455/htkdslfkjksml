import React, { useState } from 'react';
import { 
  Navigation, 
  ShieldCheck, 
  Clock, 
  Battery, 
  MapPin, 
  AlertOctagon, 
  X, 
  Radio, 
  Compass, 
  CheckCircle,
  EyeOff
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const LiveLocationModal: React.FC = () => {
  const { 
    isLocationModalOpen, 
    setIsLocationModalOpen, 
    liveLocation, 
    startLiveLocation, 
    stopLiveLocation, 
    chats, 
    activeChatId 
  } = useApp();

  const [selectedDuration, setSelectedDuration] = useState<number>(60); // minutes
  const [hasUserConsent, setHasUserConsent] = useState(false);
  const [isEmergency, setIsEmergency] = useState(false);
  const [targetChat, setTargetChat] = useState<string>(activeChatId || chats[0]?.id || '');

  if (!isLocationModalOpen) return null;

  const handleStart = () => {
    if (!hasUserConsent) {
      alert('Consent required: Please explicitly agree to share your real-time coordinates.');
      return;
    }
    startLiveLocation(targetChat, selectedDuration, isEmergency);
    setIsLocationModalOpen(false);
  };

  const handleStop = () => {
    stopLiveLocation();
    setIsLocationModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
      <div className="relative w-full max-w-md ios-glass-card rounded-3xl p-5 border border-white/20 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-2xl flex items-center justify-center border ${
              isEmergency 
                ? 'bg-rose-500/20 text-rose-400 border-rose-500/40 animate-pulse' 
                : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
            }`}>
              <Navigation className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-1.5">
                Consent Live Location
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Protected
                </span>
              </h2>
              <p className="text-xs text-slate-400">Zero background leakage • Real-time telemetry</p>
            </div>
          </div>
          <button
            onClick={() => setIsLocationModalOpen(false)}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Real-time Map Canvas / Simulation */}
        <div className="relative w-full h-44 rounded-2xl overflow-hidden border border-white/15 bg-slate-900 flex items-center justify-center">
          {/* Stylized vector radar background */}
          <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-60" />
          
          {/* Animated radar rings */}
          <div className="absolute w-32 h-32 rounded-full border border-cyan-500/30 animate-ping opacity-30" />
          <div className="absolute w-24 h-24 rounded-full border border-cyan-400/40" />
          <div className="absolute w-12 h-12 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center shadow-lg shadow-cyan-500/50">
            <div className="w-4 h-4 rounded-full bg-cyan-400 animate-pulse" />
          </div>

          {/* Telemetry HUD overlays */}
          <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 px-2 py-1 rounded-lg bg-black/60 backdrop-blur-md text-[10px] text-cyan-300 border border-white/10">
            <Radio className="w-3 h-3 animate-pulse" />
            <span>GPS Fix: 6 satellite lock</span>
          </div>

          <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5 px-2 py-1 rounded-lg bg-black/60 backdrop-blur-md text-[10px] text-emerald-300 border border-white/10">
            <Battery className="w-3 h-3" />
            <span>94% • Battery Optimized</span>
          </div>

          <div className="absolute bottom-2.5 inset-x-2.5 px-3 py-1.5 rounded-xl bg-black/75 backdrop-blur-md text-xs text-white border border-white/10 flex items-center justify-between">
            <span className="flex items-center gap-1.5 truncate">
              <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="truncate">Market St & 4th, San Francisco, CA</span>
            </span>
            <span className="text-[11px] text-slate-400 shrink-0 ml-2">Accuracy ±6m</span>
          </div>
        </div>

        {/* Status indicator if currently sharing */}
        {liveLocation?.isSharing ? (
          <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-emerald-300 flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
                Live Location Sharing Active
              </span>
              <span className="text-[11px] text-emerald-400 font-mono">
                {Math.max(0, Math.round((liveLocation.expiresAt - Date.now()) / 60000))}m remaining
              </span>
            </div>
            <p className="text-[11px] text-slate-300">
              Only members of the chosen chat can see your coordinates. Updates stop immediately when time expires or when you tap stop.
            </p>
            <button
              onClick={handleStop}
              className="w-full py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors shadow-md shadow-rose-600/30"
            >
              Stop Sharing Now
            </button>
          </div>
        ) : (
          <>
            {/* Target Chat Selection */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Share with</label>
              <select
                value={targetChat}
                onChange={e => setTargetChat(e.target.value)}
                className="w-full bg-white/10 border border-white/15 rounded-xl text-xs text-white p-2.5 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              >
                {chats.map(c => (
                  <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                    {c.title} ({c.type})
                  </option>
                ))}
              </select>
            </div>

            {/* Duration Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                Sharing Duration
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: '15 Min', val: 15 },
                  { label: '1 Hour', val: 60 },
                  { label: '8 Hours', val: 480 },
                  { label: 'Custom', val: 120 },
                ].map(d => (
                  <button
                    key={d.val}
                    type="button"
                    onClick={() => setSelectedDuration(d.val)}
                    className={`py-2 px-1 rounded-xl text-xs font-semibold transition-all border ${
                      selectedDuration === d.val
                        ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 shadow-sm'
                        : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Emergency SOS Toggle */}
            <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div className="space-y-0.5">
                <span className="text-xs font-semibold text-rose-300 flex items-center gap-1.5">
                  <AlertOctagon className="w-4 h-4 text-rose-400" />
                  Emergency SOS Mode
                </span>
                <p className="text-[11px] text-slate-400">Broadcasts high-frequency location alerts</p>
              </div>
              <button
                type="button"
                onClick={() => setIsEmergency(!isEmergency)}
                className={`w-11 h-6 rounded-full transition-colors relative ${isEmergency ? 'bg-rose-600' : 'bg-slate-700'}`}
              >
                <span className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform ${isEmergency ? 'left-5' : 'left-0.5'}`} />
              </button>
            </div>

            {/* Mandatory User Consent Checkbox */}
            <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-start gap-2.5">
              <input
                id="consentCheck"
                type="checkbox"
                checked={hasUserConsent}
                onChange={e => setHasUserConsent(e.target.checked)}
                className="mt-0.5 w-4 h-4 rounded text-cyan-600 focus:ring-cyan-500 accent-cyan-500 cursor-pointer"
              />
              <label htmlFor="consentCheck" className="text-[11px] text-slate-300 leading-tight cursor-pointer">
                I explicitly consent to share my real-time GPS coordinates with this recipient. I understand I can revoke sharing at any time with a single tap.
              </label>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsLocationModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleStart}
                disabled={!hasUserConsent}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-lg shadow-cyan-600/30 disabled:opacity-40"
              >
                Start Sharing
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
