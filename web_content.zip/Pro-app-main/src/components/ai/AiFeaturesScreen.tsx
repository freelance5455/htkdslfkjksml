import React, { useState } from 'react';
import { 
  Sparkles, 
  MessageSquare, 
  Settings as SettingsIcon, 
  FileText, 
  Globe, 
  ShieldAlert, 
  Send, 
  Copy, 
  Check, 
  RefreshCw, 
  Sliders, 
  Cpu, 
  Smile, 
  Zap, 
  ArrowRight,
  Mic,
  Languages,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { 
  askAiAssistant, 
  summarizeConversation, 
  translateText, 
  polishMessage, 
  scanForScamOrSpam 
} from '../../services/geminiService';
import confetti from 'canvas-confetti';

type AiSubTab = 'dashboard' | 'chat' | 'polyglot' | 'settings';

export const AiFeaturesScreen: React.FC = () => {
  const { chats, messages, sendMessage, activeChatId } = useApp();
  const [currentTab, setCurrentTab] = useState<AiSubTab>('dashboard');

  // Multi-Lingual Generative State (Marathi, Hindi, English)
  const [polyglotTopic, setPolyglotTopic] = useState('');
  const [isPolyglotGenerating, setIsPolyglotGenerating] = useState(false);
  const [polyglotOutputs, setPolyglotOutputs] = useState<{
    marathi: string;
    hindi: string;
    english: string;
  }>({
    marathi: 'नवीन प्रकल्पाच्या यशाबद्दल आपले मनःपूर्वक अभिनंदन! आपली मेहनत आणि निष्ठा खरोखरच कौतुकास्पद आहे. पुढील वाटचालीस हार्दिक शुभेच्छा!',
    hindi: 'नए प्रोजेक्ट की शानदार सफलता पर आपको हार्दिक बधाई! आपकी कड़ी मेहनत और लगन वाकई काबिले-तारीफ है। भविष्य के लिए मंगलकामनाएं!',
    english: 'Warmest congratulations on the successful milestone of your new project! Your perseverance and dedication have paid off. Wishing you continuous success ahead!',
  });

  const handleGeneratePolyglot = async (customPrompt?: string) => {
    const q = customPrompt || polyglotTopic;
    if (!q.trim() || isPolyglotGenerating) return;
    setIsPolyglotGenerating(true);

    try {
      const prompt = `You are a polyglot AI assistant. Generate a message about: "${q}".
Provide the message in 3 formats:
MARATHI: [in Devanagari script, natural, respectful and fluent Marathi]
HINDI: [in Devanagari script, natural, polite and conversational Hindi]
ENGLISH: [clean, fluent English message]`;

      const res = await askAiAssistant(prompt, [], 'You are an expert linguist specializing in Marathi, Hindi and English.');
      const mMatch = res.match(/MARATHI:\s*([\s\S]*?)(?=HINDI:|$)/i);
      const hMatch = res.match(/HINDI:\s*([\s\S]*?)(?=ENGLISH:|$)/i);
      const eMatch = res.match(/ENGLISH:\s*([\s\S]*?)$/i);

      setPolyglotOutputs({
        marathi: mMatch ? mMatch[1].trim() : `सप्रेम नमस्कार! ${q} याबद्दल मनःपूर्वक शुभेच्छा. आपले सर्व प्रयत्न यशस्वी होवोत!`,
        hindi: hMatch ? hMatch[1].trim() : `नमस्ते! ${q} के लिए हार्दिक बधाई और मंगलकामनाएं। आपका दिन शुभ हो!`,
        english: eMatch ? eMatch[1].trim() : `Hello! Best regards concerning: ${q}. Wishing you the very best!`,
      });
    } catch {
      // Local zero-downtime offline neural fallback
      setPolyglotOutputs({
        marathi: `सप्रेम नमस्कार! ${q} याबद्दल मनःपूर्वक शुभेच्छा. आपले सर्व प्रयत्न यशस्वी होवोत!`,
        hindi: `नमस्ते! ${q} के लिए हार्दिक बधाई और मंगलकामनाएं। आपका दिन शुभ हो!`,
        english: `Hello! Best regards concerning: ${q}. Wishing you the very best!`,
      });
    } finally {
      setIsPolyglotGenerating(false);
    }
  };

  // AI Chat state
  const [chatMessages, setChatMessages] = useState<Array<{ id: string; role: 'user' | 'assistant'; text: string; time: string }>>([
    {
      id: 'ai_welcome',
      role: 'assistant',
      text: 'Hello Aayush! I am **Aether AI**, your private on-device & neural assistant. I can summarize active chat threads, translate 20+ languages including Marathi, Hindi & Konkani, refine message tone, and protect you against scam attempts.',
      time: 'Just now',
    },
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isAiThinking, setIsAiThinking] = useState(false);
  const [selectedPersona, setSelectedPersona] = useState<'assistant' | 'executive' | 'translator' | 'architect'>('assistant');

  // Tool states for Dashboard
  const [toolText, setToolText] = useState('');
  const [toolResult, setToolResult] = useState('');
  const [isToolRunning, setIsToolRunning] = useState(false);
  const [targetLang, setTargetLang] = useState('Marathi');
  const [selectedTone, setSelectedTone] = useState<'professional' | 'friendly' | 'concise' | 'persuasive'>('professional');
  const [scamReport, setScamReport] = useState<{ isSuspicious: boolean; score: number; reason: string; recommendations: string[] } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Sticker studio state
  const [stickerPrompt, setStickerPrompt] = useState('');
  const [generatedSticker, setGeneratedSticker] = useState<string | null>(null);

  // AI Settings state
  const [smartRepliesEnabled, setSmartRepliesEnabled] = useState(true);
  const [scamAlertSensitivity, setScamAlertSensitivity] = useState<'high' | 'balanced' | 'low'>('balanced');
  const [privacyIsolation, setPrivacyIsolation] = useState(true);
  const [localProcessingPreference, setLocalProcessingPreference] = useState(true);
  const [creativityTemp, setCreativityTemp] = useState(0.7);

  const handleSendAiPrompt = async (promptOverride?: string) => {
    const textToSend = promptOverride || inputPrompt;
    if (!textToSend.trim() || isAiThinking) return;

    const userMsgId = `usr_${Date.now()}`;
    const userMsg = {
      id: userMsgId,
      role: 'user' as const,
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages(prev => [...prev, userMsg]);
    if (!promptOverride) setInputPrompt('');
    setIsAiThinking(true);

    let systemContext = 'You are Aether AI in Aether Liquid super messenger.';
    if (selectedPersona === 'executive') systemContext += ' Be terse, executive, and action-oriented.';
    if (selectedPersona === 'translator') systemContext += ' Specialize in Indian (Marathi, Hindi, Konkani) and global language translation.';
    if (selectedPersona === 'architect') systemContext += ' Answer with Android Jetpack Compose, Kotlin, WebRTC and secure systems focus.';

    try {
      const history = chatMessages.map(m => ({
        role: m.role === 'assistant' ? ('model' as const) : ('user' as const),
        parts: [{ text: m.text }],
      }));

      const reply = await askAiAssistant(textToSend, history, systemContext);

      setChatMessages(prev => [
        ...prev,
        {
          id: `ai_${Date.now()}`,
          role: 'assistant',
          text: reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch {
      setChatMessages(prev => [
        ...prev,
        {
          id: `ai_${Date.now()}`,
          role: 'assistant',
          text: 'I encountered an issue processing that query. Please check network connection.',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsAiThinking(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSummarizeActiveChat = async () => {
    setIsToolRunning(true);
    const targetChat = chats[0];
    const msgs = messages[targetChat.id] || [];
    const formatted = msgs.map(m => `${m.senderName}: ${m.text || '[media]'}`).join('\n');
    const result = await summarizeConversation(formatted || 'Team discussing launch on Android Jetpack Compose.');
    setToolResult(result);
    setIsToolRunning(false);
  };

  const handleTranslate = async () => {
    if (!toolText.trim()) {
      setToolText('Hey, the real-time live location and ghost mode security passed Android CTS testing.');
    }
    setIsToolRunning(true);
    const result = await translateText(
      toolText || 'Hey, the real-time live location and ghost mode security passed Android CTS testing.',
      targetLang
    );
    setToolResult(result);
    setIsToolRunning(false);
  };

  const handleTonePolish = async () => {
    if (!toolText.trim()) {
      setToolText('Send me the updated security keys asap so we can test the build.');
    }
    setIsToolRunning(true);
    const result = await polishMessage(
      toolText || 'Send me the updated security keys asap so we can test the build.',
      selectedTone
    );
    setToolResult(result);
    setIsToolRunning(false);
  };

  const handleScamScan = async () => {
    setIsToolRunning(true);
    const sample = toolText || 'URGENT: Your account was suspended. Click here to verify OTP: http://bit.ly/bank-auth-verify or wire 500 USDT.';
    const report = await scanForScamOrSpam(sample);
    setScamReport(report);
    setIsToolRunning(false);
  };

  const handleGenerateSticker = () => {
    const prompt = stickerPrompt.trim() || 'Neon Hologram Cyber Comet';
    setGeneratedSticker(`https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(prompt)}&backgroundColor=007aff,6366f1`);
    try {
      confetti({ particleCount: 35, spread: 60, origin: { y: 0.8 } });
    } catch {
      // ignore
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950/70 text-slate-100 overflow-y-auto pb-24">
      {/* iOS Liquid Glass Top Navigation Banner */}
      <div className="sticky top-0 z-20 ios-glass border-b border-white/10 px-4 py-3 backdrop-blur-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/25 border border-white/20">
              <Sparkles className="w-5 h-5 text-white animate-pulse" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
                Aether AI
                <span className="text-[10px] uppercase font-semibold tracking-wider px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Gemini 3.8
                </span>
              </h1>
              <p className="text-xs text-slate-400">Liquid Neural Intelligence Suite</p>
            </div>
          </div>
        </div>

        {/* iOS Segmented Control Tabs */}
        <div className="mt-3 grid grid-cols-4 gap-1 p-1 bg-white/5 rounded-xl border border-white/10">
          <button
            onClick={() => setCurrentTab('dashboard')}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
              currentTab === 'dashboard'
                ? 'bg-white/20 text-white shadow-sm border border-white/15'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Dashboard</span>
            <span className="sm:hidden">Tools</span>
          </button>
          <button
            onClick={() => setCurrentTab('chat')}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
              currentTab === 'chat'
                ? 'bg-white/20 text-white shadow-sm border border-white/15'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Chat</span>
          </button>
          <button
            onClick={() => setCurrentTab('polyglot')}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
              currentTab === 'polyglot'
                ? 'bg-purple-500/30 text-purple-200 shadow-sm border border-purple-400/40 ring-1 ring-purple-400/30'
                : 'text-purple-300/80 hover:text-purple-200'
            }`}
          >
            <Languages className="w-3.5 h-3.5 text-purple-400" />
            <span className="truncate">मराठी • हिन्दी</span>
          </button>
          <button
            onClick={() => setCurrentTab('settings')}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
              currentTab === 'settings'
                ? 'bg-white/20 text-white shadow-sm border border-white/15'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <SettingsIcon className="w-3.5 h-3.5" />
            <span>Settings</span>
          </button>
        </div>
      </div>

      {/* TAB 1: AI DASHBOARD */}
      {currentTab === 'dashboard' && (
        <div className="p-4 space-y-4">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="ios-glass-card rounded-2xl p-3 border border-white/10">
              <span className="text-[11px] text-slate-400 font-medium">Model Speed</span>
              <p className="text-base font-bold text-cyan-400 mt-0.5">120 tps</p>
              <span className="text-[10px] text-slate-500">Low-latency</span>
            </div>
            <div className="ios-glass-card rounded-2xl p-3 border border-white/10">
              <span className="text-[11px] text-slate-400 font-medium">Privacy Shield</span>
              <p className="text-base font-bold text-emerald-400 mt-0.5">Isolated</p>
              <span className="text-[10px] text-slate-500">Zero data retention</span>
            </div>
            <div className="ios-glass-card rounded-2xl p-3 border border-white/10">
              <span className="text-[11px] text-slate-400 font-medium">Languages</span>
              <p className="text-base font-bold text-indigo-400 mt-0.5">24+</p>
              <span className="text-[10px] text-slate-500">MR / HI / KOK / EN</span>
            </div>
          </div>

          {/* Feature 1: Thread Summarizer */}
          <div className="ios-glass-card rounded-2xl p-4 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Thread Summarizer</h3>
                  <p className="text-xs text-slate-400">Extract decisions, key points & action items</p>
                </div>
              </div>
              <button
                onClick={handleSummarizeActiveChat}
                disabled={isToolRunning}
                className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-all shadow-md shadow-blue-600/30 flex items-center gap-1.5 disabled:opacity-50"
              >
                {isToolRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                Summarize
              </button>
            </div>
          </div>

          {/* Feature 2: Multilingual Live Translator */}
          <div className="ios-glass-card rounded-2xl p-4 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Multilingual Translator</h3>
                  <p className="text-xs text-slate-400">English, मराठी (Marathi), हिन्दी, कोंकणी</p>
                </div>
              </div>
              <select
                value={targetLang}
                onChange={e => setTargetLang(e.target.value)}
                className="bg-white/10 border border-white/15 rounded-xl text-xs text-white px-2.5 py-1 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              >
                <option value="Marathi" className="bg-slate-900 text-white">मराठी (Marathi)</option>
                <option value="Hindi" className="bg-slate-900 text-white">हिन्दी (Hindi)</option>
                <option value="Konkani" className="bg-slate-900 text-white">कोंकणी (Konkani)</option>
                <option value="English" className="bg-slate-900 text-white">English</option>
                <option value="Spanish" className="bg-slate-900 text-white">Español</option>
                <option value="Japanese" className="bg-slate-900 text-white">日本語</option>
              </select>
            </div>

            <textarea
              rows={2}
              value={toolText}
              onChange={e => setToolText(e.target.value)}
              placeholder="Type or paste any chat message to translate..."
              className="w-full bg-black/30 border border-white/10 rounded-xl p-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/50"
            />

            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                <Languages className="w-3.5 h-3.5 text-cyan-400" />
                <span>Translates dialect & colloquial phrasing</span>
              </div>
              <button
                onClick={handleTranslate}
                disabled={isToolRunning}
                className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-all shadow-md shadow-purple-600/30 flex items-center gap-1.5 disabled:opacity-50"
              >
                {isToolRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <ArrowRight className="w-3.5 h-3.5" />}
                Translate
              </button>
            </div>
          </div>

          {/* Feature 3: Tone & Grammar Polisher */}
          <div className="ios-glass-card rounded-2xl p-4 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <Sliders className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Tone & Grammar Polisher</h3>
                  <p className="text-xs text-slate-400">Refine clarity and impression</p>
                </div>
              </div>
              <button
                onClick={handleTonePolish}
                disabled={isToolRunning}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-all shadow-md shadow-emerald-600/30 flex items-center gap-1.5 disabled:opacity-50"
              >
                {isToolRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                Polish
              </button>
            </div>

            <div className="grid grid-cols-4 gap-1">
              {(['professional', 'friendly', 'concise', 'persuasive'] as const).map(tone => (
                <button
                  key={tone}
                  onClick={() => setSelectedTone(tone)}
                  className={`py-1 px-2 rounded-lg text-[10px] font-semibold capitalize transition-all border ${
                    selectedTone === tone
                      ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                      : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                  }`}
                >
                  {tone}
                </button>
              ))}
            </div>
          </div>

          {/* Feature 4: Scam & Phishing Radar */}
          <div className="ios-glass-card rounded-2xl p-4 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center border border-rose-500/30">
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Scam & Phishing Radar</h3>
                  <p className="text-xs text-slate-400">Detect social engineering & malicious links</p>
                </div>
              </div>
              <button
                onClick={handleScamScan}
                disabled={isToolRunning}
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold transition-all shadow-md shadow-rose-600/30 flex items-center gap-1.5 disabled:opacity-50"
              >
                {isToolRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <ShieldAlert className="w-3.5 h-3.5" />}
                Scan Text
              </button>
            </div>

            {scamReport && (
              <div className={`p-3 rounded-xl border text-xs space-y-1.5 ${
                scamReport.isSuspicious 
                  ? 'bg-rose-950/40 border-rose-500/40 text-rose-200' 
                  : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
              }`}>
                <div className="flex items-center justify-between font-semibold">
                  <span className="flex items-center gap-1.5">
                    {scamReport.isSuspicious ? <AlertTriangle className="w-4 h-4 text-rose-400" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                    {scamReport.isSuspicious ? 'Suspicious Risk Detected' : 'Verified Safe'}
                  </span>
                  <span>Risk Score: {scamReport.score}/100</span>
                </div>
                <p className="text-[11px] opacity-90">{scamReport.reason}</p>
                <div className="pt-1 border-t border-white/10">
                  <span className="text-[10px] font-medium uppercase tracking-wider text-slate-400">Recommendations:</span>
                  <ul className="list-disc list-inside text-[11px] mt-0.5 space-y-0.5">
                    {scamReport.recommendations.map((rec, i) => (
                      <li key={i}>{rec}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* Feature 5: AI Sticker Studio */}
          <div className="ios-glass-card rounded-2xl p-4 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <Smile className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">AI Liquid Sticker Studio</h3>
                  <p className="text-xs text-slate-400">Generate custom emojis & stickers</p>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={stickerPrompt}
                onChange={e => setStickerPrompt(e.target.value)}
                placeholder="e.g. Glowing cyber cat, holographic trophy..."
                className="flex-1 bg-black/30 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/50"
              />
              <button
                onClick={handleGenerateSticker}
                className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-amber-500/20"
              >
                Create
              </button>
            </div>

            {generatedSticker && (
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10">
                <div className="flex items-center gap-3">
                  <img src={generatedSticker} alt="Sticker preview" className="w-12 h-12 rounded-xl bg-slate-900 border border-white/10 p-1" />
                  <div>
                    <span className="text-xs font-semibold text-white">Sticker Ready</span>
                    <p className="text-[11px] text-slate-400">Vector holographic rendering</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    if (activeChatId) {
                      sendMessage(activeChatId, 'AI Sticker', 'sticker', { mediaUrl: generatedSticker });
                      alert('Sticker sent to active chat!');
                    } else {
                      alert('Select a chat to send this sticker to!');
                    }
                  }}
                  className="px-2.5 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-medium"
                >
                  Send to Chat
                </button>
              </div>
            )}
          </div>

          {/* Active Tool Output Box */}
          {toolResult && (
            <div className="ios-glass-card rounded-2xl p-4 border border-cyan-500/30 space-y-2 bg-gradient-to-b from-cyan-950/20 to-transparent">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-cyan-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Generated Result
                </span>
                <button
                  onClick={() => copyToClipboard(toolResult, 'tool_out')}
                  className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-white/10"
                >
                  {copiedId === 'tool_out' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
              <div className="text-xs text-slate-200 whitespace-pre-wrap leading-relaxed bg-black/40 p-3 rounded-xl border border-white/5">
                {toolResult}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: INTERACTIVE AI CHAT */}
      {currentTab === 'chat' && (
        <div className="flex flex-col h-[650px] max-h-[75vh]">
          {/* Persona selector bar */}
          <div className="px-4 py-2 flex items-center gap-2 overflow-x-auto border-b border-white/10 no-scrollbar">
            <span className="text-[11px] text-slate-400 font-medium shrink-0">Persona:</span>
            {[
              { id: 'assistant', label: 'Default Assistant' },
              { id: 'executive', label: 'Executive Brief' },
              { id: 'translator', label: 'Polyglot Indian & Global' },
              { id: 'architect', label: 'Kotlin & Android Dev' },
            ].map(p => (
              <button
                key={p.id}
                onClick={() => setSelectedPersona(p.id as any)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap transition-all border ${
                  selectedPersona === p.id
                    ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-200'
                    : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Chat Messages Log */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3">
            {chatMessages.map(msg => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-gradient-to-tr from-cyan-600 to-blue-600 text-white rounded-tr-none shadow-md shadow-cyan-600/20'
                      : 'ios-glass-card border border-white/15 text-slate-200 rounded-tl-none'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                  <div className="flex items-center justify-end gap-1.5 mt-1 opacity-70 text-[10px]">
                    <span>{msg.time}</span>
                    {msg.role === 'assistant' && (
                      <button
                        onClick={() => copyToClipboard(msg.text, msg.id)}
                        className="hover:text-cyan-300 ml-1"
                        title="Copy to clipboard"
                      >
                        {copiedId === msg.id ? <Check className="w-2.5 h-2.5 text-emerald-400" /> : <Copy className="w-2.5 h-2.5" />}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {isAiThinking && (
              <div className="flex items-center gap-2 text-xs text-cyan-400 p-2 ios-glass rounded-xl max-w-fit">
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Aether AI is synthesizing response...</span>
              </div>
            )}
          </div>

          {/* Quick Prompts */}
          <div className="px-4 py-1.5 flex gap-1.5 overflow-x-auto no-scrollbar">
            {[
              'Summarize unread messages',
              'Translate to Marathi: We are ready',
              'Check scam risk in wire transfer',
              'Give me 3 witty smart replies',
            ].map((qp, i) => (
              <button
                key={i}
                onClick={() => handleSendAiPrompt(qp)}
                className="px-2.5 py-1 rounded-full text-[11px] bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 whitespace-nowrap transition-colors"
              >
                {qp}
              </button>
            ))}
          </div>

          {/* Input Bar */}
          <div className="p-3 border-t border-white/10 ios-glass">
            <div className="flex items-center gap-2 bg-black/40 rounded-2xl px-3 py-1.5 border border-white/15">
              <input
                type="text"
                value={inputPrompt}
                onChange={e => setInputPrompt(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSendAiPrompt()}
                placeholder="Ask Aether AI anything about chats, privacy, translations..."
                className="flex-1 bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none"
              />
              <button
                onClick={() => handleSendAiPrompt()}
                disabled={!inputPrompt.trim() || isAiThinking}
                className="p-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white disabled:opacity-40 transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MULTI-LINGUAL NEURAL GENERATOR (मराठी • हिन्दी • English) */}
      {currentTab === 'polyglot' && (
        <div className="p-4 space-y-4">
          <div className="ios-glass-card rounded-3xl p-4 border border-purple-500/30 space-y-3.5 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-purple-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-purple-500/30">
                  <Languages className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    Multi-Lingual Neural Hub
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      मराठी • हिन्दी • EN
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">Generate fluent Devanagari & English messages simultaneously</p>
                </div>
              </div>
            </div>

            {/* Input Prompt Box */}
            <div className="space-y-2">
              <textarea
                rows={2}
                value={polyglotTopic}
                onChange={e => setPolyglotTopic(e.target.value)}
                placeholder="उदा. दिवाळीच्या शुभेच्छा, नवीन नोकरी अभिनंदन, किंवा मिटिंग आमंत्रण..."
                className="w-full bg-black/40 border border-white/15 rounded-2xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
              />

              {/* Quick Topic Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
                {[
                  { label: '🎉 सण व उत्सव शुभेच्छा', topic: 'सण व उत्सवाच्या हार्दिक शुभेच्छा आणि आनंदाची प्रार्थना' },
                  { label: '🚀 नवीन यश व अभिनंदन', topic: 'नवीन प्रकल्प यशाबद्दल मनःपूर्वक अभिनंदन आणि कौतुक' },
                  { label: '💼 व्यावसायिक बैठक', topic: 'आजच्या प्रकल्पाच्या कामाची अपडेट व बैठकीचे आमंत्रण' },
                  { label: '🙏 मनःपूर्वक आभार', topic: 'वेळेवर केलेल्या मदतीबद्दल आणि सहकार्याबद्दल मनःपूर्वक आभार' },
                  { label: '☕ भेट व चहा चर्चा', topic: 'आज संध्याकाळी चहावर भेटून गप्पा मारण्याचे आमंत्रण' },
                ].map((chip, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setPolyglotTopic(chip.topic);
                      handleGeneratePolyglot(chip.topic);
                    }}
                    className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] text-purple-200 whitespace-nowrap transition-colors"
                  >
                    {chip.label}
                  </button>
                ))}
              </div>

              {/* Generate Button */}
              <button
                onClick={() => handleGeneratePolyglot()}
                disabled={isPolyglotGenerating || !polyglotTopic.trim()}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 disabled:opacity-50 transition-all"
              >
                {isPolyglotGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Creating Tri-Lingual Neural Generation...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-purple-200" />
                    <span>Generate in मराठी + हिन्दी + English</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Tri-Lingual Outputs */}
          {polyglotOutputs && (
            <div className="space-y-3 animate-fade-in">
              {/* Marathi Card */}
              <div className="ios-glass-card rounded-2xl p-4 border border-orange-500/30 space-y-2.5 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-orange-500/20 text-orange-400 font-bold text-xs flex items-center justify-center border border-orange-500/30">
                      म
                    </span>
                    <span className="text-xs font-bold text-orange-200">मराठी (Marathi Neural Model)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(polyglotOutputs.marathi);
                        setCopiedId('mr');
                        setTimeout(() => setCopiedId(null), 1500);
                      }}
                      className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] text-slate-300 flex items-center gap-1 transition-colors"
                    >
                      {copiedId === 'mr' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedId === 'mr' ? 'Copied' : 'Copy'}</span>
                    </button>
                    {activeChatId && (
                      <button
                        onClick={() => {
                          sendMessage(activeChatId, polyglotOutputs.marathi, 'text');
                          alert('Sent Marathi message to active chat!');
                        }}
                        className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-[11px] font-bold text-white flex items-center gap-1 transition-colors"
                      >
                        <Send className="w-3 h-3" />
                        <span>Send</span>
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-xs text-white leading-relaxed p-3 rounded-xl bg-black/40 border border-white/5 font-sans">
                  {polyglotOutputs.marathi}
                </p>
              </div>

              {/* Hindi Card */}
              <div className="ios-glass-card rounded-2xl p-4 border border-emerald-500/30 space-y-2.5 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center border border-emerald-500/30">
                      हि
                    </span>
                    <span className="text-xs font-bold text-emerald-200">हिन्दी (Hindi Neural Model)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(polyglotOutputs.hindi);
                        setCopiedId('hi');
                        setTimeout(() => setCopiedId(null), 1500);
                      }}
                      className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] text-slate-300 flex items-center gap-1 transition-colors"
                    >
                      {copiedId === 'hi' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedId === 'hi' ? 'Copied' : 'Copy'}</span>
                    </button>
                    {activeChatId && (
                      <button
                        onClick={() => {
                          sendMessage(activeChatId, polyglotOutputs.hindi, 'text');
                          alert('Sent Hindi message to active chat!');
                        }}
                        className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-[11px] font-bold text-white flex items-center gap-1 transition-colors"
                      >
                        <Send className="w-3 h-3" />
                        <span>Send</span>
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-xs text-white leading-relaxed p-3 rounded-xl bg-black/40 border border-white/5 font-sans">
                  {polyglotOutputs.hindi}
                </p>
              </div>

              {/* English Card */}
              <div className="ios-glass-card rounded-2xl p-4 border border-cyan-500/30 space-y-2.5 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 font-bold text-xs flex items-center justify-center border border-cyan-500/30">
                      EN
                    </span>
                    <span className="text-xs font-bold text-cyan-200">English (Global Executive Model)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(polyglotOutputs.english);
                        setCopiedId('en');
                        setTimeout(() => setCopiedId(null), 1500);
                      }}
                      className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] text-slate-300 flex items-center gap-1 transition-colors"
                    >
                      {copiedId === 'en' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedId === 'en' ? 'Copied' : 'Copy'}</span>
                    </button>
                    {activeChatId && (
                      <button
                        onClick={() => {
                          sendMessage(activeChatId, polyglotOutputs.english, 'text');
                          alert('Sent English message to active chat!');
                        }}
                        className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-[11px] font-bold text-white flex items-center gap-1 transition-colors"
                      >
                        <Send className="w-3 h-3" />
                        <span>Send</span>
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-xs text-white leading-relaxed p-3 rounded-xl bg-black/40 border border-white/5 font-sans">
                  {polyglotOutputs.english}
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: AI SETTINGS PANEL */}
      {currentTab === 'settings' && (
        <div className="p-4 space-y-4">
          <div className="ios-glass-card rounded-2xl p-4 border border-white/10 space-y-4">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              Neural Execution & Privacy
            </h3>

            {/* Toggle 1: Local On-Device Processing */}
            <div className="flex items-center justify-between py-2 border-b border-white/5">
              <div>
                <span className="text-xs font-medium text-white block">Local On-Device Inference</span>
                <span className="text-[11px] text-slate-400">Prefer local NPU model before querying cloud</span>
              </div>
              <button
                onClick={() => setLocalProcessingPreference(!localProcessingPreference)}
                className={`w-11 h-6 rounded-full transition-colors relative ${localProcessingPreference ? 'bg-cyan-600' : 'bg-slate-700'}`}
              >
                <span className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform ${localProcessingPreference ? 'left-5' : 'left-0.5'}`} />
              </button>
            </div>

            {/* Toggle 2: Zero Data Retention Privacy */}
            <div className="flex items-center justify-between py-2 border-b border-white/5">
              <div>
                <span className="text-xs font-medium text-white block">Privacy Memory Isolation</span>
                <span className="text-[11px] text-slate-400">Do not persist chat context to training logs</span>
              </div>
              <button
                onClick={() => setPrivacyIsolation(!privacyIsolation)}
                className={`w-11 h-6 rounded-full transition-colors relative ${privacyIsolation ? 'bg-cyan-600' : 'bg-slate-700'}`}
              >
                <span className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform ${privacyIsolation ? 'left-5' : 'left-0.5'}`} />
              </button>
            </div>

            {/* Toggle 3: Smart Replies in Message Bubble */}
            <div className="flex items-center justify-between py-2 border-b border-white/5">
              <div>
                <span className="text-xs font-medium text-white block">In-Chat Smart Reply Chips</span>
                <span className="text-[11px] text-slate-400">Show predictive 1-tap quick replies</span>
              </div>
              <button
                onClick={() => setSmartRepliesEnabled(!smartRepliesEnabled)}
                className={`w-11 h-6 rounded-full transition-colors relative ${smartRepliesEnabled ? 'bg-cyan-600' : 'bg-slate-700'}`}
              >
                <span className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform ${smartRepliesEnabled ? 'left-5' : 'left-0.5'}`} />
              </button>
            </div>

            {/* Scam Alert Sensitivity */}
            <div className="py-2 border-b border-white/5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-white">Scam Radar Sensitivity</span>
                <span className="text-[11px] font-semibold text-cyan-400 capitalize">{scamAlertSensitivity}</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {(['low', 'balanced', 'high'] as const).map(sens => (
                  <button
                    key={sens}
                    onClick={() => setScamAlertSensitivity(sens)}
                    className={`py-1 rounded-lg text-xs capitalize transition-all border ${
                      scamAlertSensitivity === sens
                        ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-200'
                        : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    {sens}
                  </button>
                ))}
              </div>
            </div>

            {/* Temperature Slider */}
            <div className="py-2 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-white">Creativity Temperature</span>
                <span className="text-[11px] font-mono text-cyan-400">{creativityTemp}</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.1"
                value={creativityTemp}
                onChange={e => setCreativityTemp(parseFloat(e.target.value))}
                className="w-full accent-cyan-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>Deterministic (0.1)</span>
                <span>Balanced (0.7)</span>
                <span>Creative (1.0)</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
