import React, { useEffect, useState } from 'react';
import { 
  PhoneOff, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Video, 
  VideoOff, 
  ScreenShare, 
  Wifi, 
  ShieldCheck, 
  Users,
  Maximize2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const CallModal: React.FC = () => {
  const { 
    callSession, 
    endCall, 
    toggleCallMute, 
    toggleCallSpeaker, 
    toggleCallVideo, 
    toggleCallScreenShare 
  } = useApp();

  const [waveformBars, setWaveformBars] = useState<number[]>([40, 65, 30, 85, 95, 45, 70, 80, 50, 90, 60, 75]);

  // Dynamic waveform animation
  useEffect(() => {
    if (!callSession || callSession.status !== 'connected' || callSession.isMuted) return;
    const interval = setInterval(() => {
      setWaveformBars(Array.from({ length: 14 }, () => Math.floor(Math.random() * 70) + 25));
    }, 200);
    return () => clearInterval(interval);
  }, [callSession?.status, callSession?.isMuted]);

  if (!callSession) return null;

  const peer = callSession.participants[1] || callSession.participants[0];
  const minutes = Math.floor(callSession.durationSeconds / 60);
  const seconds = (callSession.durationSeconds % 60).toString().padStart(2, '0');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl">
      <div className="relative w-full max-w-md h-[90vh] max-h-[720px] rounded-3xl overflow-hidden border border-white/20 shadow-2xl flex flex-col justify-between p-6 bg-gradient-to-b from-slate-900 via-slate-950 to-black">
        
        {/* Top Call Info & Network Status */}
        <div className="flex items-center justify-between z-10">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-[11px] text-slate-300 border border-white/10 backdrop-blur-md">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Signal E2EE 256-bit</span>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-[11px] text-emerald-400 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
              <Wifi className="w-3.5 h-3.5" />
              <span>5G HD Voice</span>
            </div>
          </div>
        </div>

        {/* Center Calling Avatar or Video Stream */}
        <div className="flex-1 flex flex-col items-center justify-center space-y-4 my-auto">
          {callSession.type === 'video' && !callSession.isVideoMuted ? (
            /* Video stream simulation */
            <div className="relative w-full h-80 rounded-3xl overflow-hidden border border-white/20 shadow-2xl bg-slate-900">
              <img 
                src={peer.avatar} 
                alt={peer.name} 
                className="w-full h-full object-cover"
              />
              {/* Picture in picture self camera */}
              <div className="absolute top-3 right-3 w-24 h-32 rounded-2xl overflow-hidden border-2 border-white/40 shadow-xl bg-slate-950">
                <img 
                  src={callSession.participants[0].avatar} 
                  alt="You" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute bottom-3 left-3 px-3 py-1 rounded-xl bg-black/60 backdrop-blur-md text-xs text-white">
                {peer.name}
              </div>
            </div>
          ) : (
            /* Voice Calling layout with glowing avatar & audio visualizer */
            <div className="flex flex-col items-center space-y-4">
              <div className="relative">
                {/* Glowing pulse aura */}
                <div className="absolute -inset-4 rounded-full bg-cyan-500/20 blur-xl animate-pulse" />
                <img
                  src={peer.avatar}
                  alt={peer.name}
                  className="relative w-28 h-28 rounded-full object-cover border-4 border-white/20 shadow-2xl"
                />
              </div>

              <div className="text-center space-y-1">
                <h2 className="text-xl font-bold text-white tracking-tight">{peer.name}</h2>
                <p className="text-xs text-slate-400">
                  {callSession.status === 'calling' && 'Connecting WebRTC relay...'}
                  {callSession.status === 'ringing' && 'Ringing...'}
                  {callSession.status === 'connected' && `${minutes}:${seconds}`}
                </p>
              </div>

              {/* Dynamic WebRTC Audio Waveform */}
              {callSession.status === 'connected' && !callSession.isMuted && (
                <div className="flex items-center gap-1.5 h-12 pt-2">
                  {waveformBars.map((height, idx) => (
                    <div
                      key={idx}
                      className="w-1 bg-gradient-to-t from-cyan-500 to-blue-400 rounded-full transition-all duration-150"
                      style={{ height: `${height}%` }}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Screen sharing banner */}
        {callSession.isScreenSharing && (
          <div className="mb-4 py-2 px-4 rounded-2xl bg-cyan-950/60 border border-cyan-500/40 text-center text-xs text-cyan-200">
            🖥️ Live Screen Sharing Active (1080p 60fps)
          </div>
        )}

        {/* Bottom Call Action Dock */}
        <div className="ios-glass rounded-3xl p-4 border border-white/15 space-y-4 shadow-2xl">
          <div className="flex items-center justify-around">
            {/* Mute Mic */}
            <button
              onClick={toggleCallMute}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                callSession.isMuted 
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40' 
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
            >
              {callSession.isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            {/* Video Toggle */}
            <button
              onClick={toggleCallVideo}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                callSession.isVideoMuted 
                  ? 'bg-white/10 text-slate-400' 
                  : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              }`}
            >
              {callSession.isVideoMuted ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
            </button>

            {/* Speaker Toggle */}
            <button
              onClick={toggleCallSpeaker}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                callSession.isSpeaker 
                  ? 'bg-white/20 text-white' 
                  : 'bg-white/10 text-slate-400'
              }`}
            >
              {callSession.isSpeaker ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>

            {/* Screen Share */}
            <button
              onClick={toggleCallScreenShare}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                callSession.isScreenSharing 
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40' 
                  : 'bg-white/10 text-slate-400'
              }`}
            >
              <ScreenShare className="w-5 h-5" />
            </button>

            {/* End Call Button */}
            <button
              onClick={endCall}
              className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/40 transition-transform active:scale-95"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
