import React from 'react';
import { 
  Phone, 
  Video, 
  PhoneIncoming, 
  PhoneOutgoing, 
  PhoneMissed, 
  Plus, 
  Link as LinkIcon, 
  ShieldCheck, 
  Users 
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CONTACTS } from '../../mock/initialData';

export const CallsScreen: React.FC = () => {
  const { startCall, chats, setIsLocationTraceOpen } = useApp();

  const callHistory = [
    {
      id: 'cl_1',
      peer: CONTACTS[0],
      type: 'video' as const,
      direction: 'incoming' as const,
      status: 'completed',
      duration: '14:22',
      time: 'Today, 10:14 AM',
    },
    {
      id: 'cl_2',
      peer: CONTACTS[2],
      type: 'voice' as const,
      direction: 'outgoing' as const,
      status: 'completed',
      duration: '06:45',
      time: 'Yesterday, 4:18 PM',
    },
    {
      id: 'cl_3',
      peer: CONTACTS[1],
      type: 'voice' as const,
      direction: 'missed' as const,
      status: 'missed',
      duration: '0:00',
      time: 'Sep 27, 8:30 PM',
    },
    {
      id: 'cl_4',
      peer: CONTACTS[3],
      type: 'video' as const,
      direction: 'outgoing' as const,
      status: 'completed',
      duration: '22:10',
      time: 'Sep 25, 2:15 PM',
    },
  ];

  return (
    <div className="flex flex-col h-full bg-slate-950 overflow-y-auto pb-24 select-none">
      {/* iOS Liquid Header */}
      <div className="ios-glass px-4 pt-4 pb-3 border-b border-white/10 sticky top-0 z-20 backdrop-blur-2xl flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Calls</span>
            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              WebRTC E2EE
            </span>
          </h1>
          <p className="text-xs text-slate-400">Zero-knowledge Opus & VP9 HD calling</p>
        </div>

        <button
          onClick={() => startCall('chat_group_core', 'video')}
          className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-cyan-600/30 transition-all border border-cyan-400/30"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Call</span>
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Create WebRTC Call Link Card - iOS Liquid Glass Specular */}
        <div className="ios-glass-card rounded-3xl p-4 border border-white/15 flex items-center gap-3.5 shadow-xl">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500/30 to-blue-600/30 text-cyan-300 flex items-center justify-center border border-cyan-400/40 shadow-inner">
            <LinkIcon className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-bold text-white">Create Aether Call Link</h3>
            <p className="text-xs text-slate-400">Share a post-quantum encrypted room with anyone</p>
          </div>
          <button 
            onClick={() => alert('Call link copied to clipboard: https://aether.im/call/room-77a8b')}
            className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold text-cyan-300 transition-colors border border-white/10 shadow-sm"
          >
            Copy Link
          </button>
        </div>

        {/* Recent Calls Header */}
        <div className="pt-2 flex items-center justify-between px-1">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Recent Calls</span>
          <span className="text-xs text-cyan-400/80 font-mono">Signal WebRTC Audio</span>
        </div>

        {/* Calls Log - iOS Liquid Glass Specular Table */}
        <div className="ios-glass-card rounded-3xl border border-white/15 divide-y divide-white/10 overflow-hidden shadow-2xl">
          {callHistory.map(call => (
            <div key={call.id} className="flex items-center justify-between p-3.5 hover:bg-white/[0.06] transition-colors">
              <div className="flex items-center gap-3">
                <img src={call.peer.avatar} alt={call.peer.name} className="w-11 h-11 rounded-full object-cover border border-white/15 shadow-sm" />
                <div>
                  <h4 className="text-sm font-bold text-white">{call.peer.name}</h4>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5">
                    {call.direction === 'incoming' && <PhoneIncoming className="w-3.5 h-3.5 text-emerald-400" />}
                    {call.direction === 'outgoing' && <PhoneOutgoing className="w-3.5 h-3.5 text-cyan-400" />}
                    {call.direction === 'missed' && <PhoneMissed className="w-3.5 h-3.5 text-rose-400" />}
                    <span className={call.direction === 'missed' ? 'text-rose-400 font-semibold' : ''}>
                      {call.time} {call.status !== 'missed' && `(${call.duration})`}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => startCall('chat_elena', call.type)}
                  className="w-9 h-9 rounded-xl bg-white/10 hover:bg-cyan-500/20 text-cyan-300 hover:text-cyan-200 border border-white/10 flex items-center justify-center transition-colors shadow-sm"
                  title={`Call ${call.peer.name}`}
                >
                  {call.type === 'video' ? <Video className="w-4 h-4" /> : <Phone className="w-4 h-4" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
