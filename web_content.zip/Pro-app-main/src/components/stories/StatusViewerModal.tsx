import React, { useState, useEffect } from 'react';
import { X, Heart, Flame, ThumbsUp, Send, Music } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const StatusViewerModal: React.FC = () => {
  const { activeStoryId, setActiveStoryId, stories, sendMessage, activeChatId } = useApp();
  const [progress, setProgress] = useState(0);
  const [replyText, setReplyText] = useState('');

  const currentStoryIndex = stories.findIndex(s => s.id === activeStoryId);
  const story = stories[currentStoryIndex];

  // Auto progression timer
  useEffect(() => {
    if (!story) return;
    setProgress(0);
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          // Advance to next story or close
          if (currentStoryIndex < stories.length - 1) {
            setActiveStoryId(stories[currentStoryIndex + 1].id);
          } else {
            setActiveStoryId(null);
          }
          return 100;
        }
        return p + 2;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [activeStoryId, currentStoryIndex]);

  if (!story) return null;

  const handleSendReaction = (emoji: string) => {
    if (activeChatId) {
      sendMessage(activeChatId, `Reacted ${emoji} to your story!`, 'text');
    }
    setActiveStoryId(null);
  };

  const handleSendReply = () => {
    if (!replyText.trim()) return;
    if (activeChatId) {
      sendMessage(activeChatId, `Replied to story: "${replyText}"`, 'text');
    }
    setReplyText('');
    setActiveStoryId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-2xl">
      <div className="relative w-full max-w-md h-[95vh] max-h-[780px] rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between border border-white/20 bg-slate-950">
        
        {/* Progress Bar Segments */}
        <div className="absolute top-3 inset-x-3 z-30 flex items-center gap-1.5">
          {stories.map((s, idx) => (
            <div key={s.id} className="flex-1 h-1 bg-white/25 rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all duration-100"
                style={{
                  width: idx === currentStoryIndex ? `${progress}%` : idx < currentStoryIndex ? '100%' : '0%'
                }}
              />
            </div>
          ))}
        </div>

        {/* Top Story Header */}
        <div className="relative z-30 pt-7 px-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <img src={story.userAvatar} alt={story.userName} className="w-10 h-10 rounded-full border-2 border-white/60 object-cover" />
            <div>
              <h3 className="text-sm font-bold text-white leading-tight">{story.userName}</h3>
              <p className="text-[11px] text-white/70">{story.timestamp}</p>
            </div>
          </div>
          <button
            onClick={() => setActiveStoryId(null)}
            className="w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Story Center Content */}
        <div className="relative flex-1 flex flex-col items-center justify-center p-6 text-center">
          {story.type === 'image' && story.contentUrl ? (
            <div className="absolute inset-0">
              <img src={story.contentUrl} alt="Story" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />
            </div>
          ) : (
            <div className={`absolute inset-0 bg-gradient-to-br ${story.bgColor || 'from-blue-600 to-indigo-800'}`} />
          )}

          <div className="relative z-20 space-y-4 max-w-sm">
            {story.textCaption && (
              <p className="text-xl md:text-2xl font-bold text-white drop-shadow-lg leading-relaxed">
                {story.textCaption}
              </p>
            )}

            {story.musicTrack && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/40 backdrop-blur-md text-xs text-white border border-white/10 shadow-lg">
                <Music className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                <span>{story.musicTrack}</span>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Story Quick Reply & Reaction Bar */}
        <div className="relative z-30 p-4 space-y-3 ios-glass border-t border-white/10">
          <div className="flex items-center justify-around">
            {['❤️', '🔥', '👏', '😂', '😍', '🎉'].map(emoji => (
              <button
                key={emoji}
                onClick={() => handleSendReaction(emoji)}
                className="text-2xl hover:scale-125 transition-transform active:scale-95"
              >
                {emoji}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={replyText}
              onChange={e => setReplyText(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSendReply()}
              placeholder={`Reply to ${story.userName}...`}
              className="flex-1 bg-white/15 border border-white/20 rounded-2xl px-4 py-2 text-xs text-white placeholder-white/60 focus:outline-none"
            />
            <button
              onClick={handleSendReply}
              className="p-2.5 rounded-2xl bg-cyan-600 hover:bg-cyan-500 text-white"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
