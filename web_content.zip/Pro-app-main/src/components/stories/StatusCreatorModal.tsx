import React, { useState } from 'react';
import { X, Send, Palette, Music, Lock, Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const StatusCreatorModal: React.FC = () => {
  const { isCreatingStory, setIsCreatingStory, addStory, currentUser } = useApp();

  const [caption, setCaption] = useState('');
  const [selectedGradient, setSelectedGradient] = useState('from-indigo-600 via-purple-600 to-pink-600');
  const [audience, setAudience] = useState<'everyone' | 'contacts' | 'private'>('contacts');

  if (!isCreatingStory) return null;

  const gradients = [
    'from-indigo-600 via-purple-600 to-pink-600',
    'from-cyan-600 via-blue-600 to-indigo-800',
    'from-emerald-600 via-teal-600 to-cyan-700',
    'from-amber-600 via-rose-600 to-purple-800',
    'from-slate-900 via-purple-950 to-black',
  ];

  const handlePost = () => {
    if (!caption.trim()) return;
    addStory({
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      type: 'text',
      textCaption: caption,
      bgColor: selectedGradient,
      timestamp: 'Just now',
      expiresAt: '24h remaining',
    });
    setCaption('');
    setIsCreatingStory(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl">
      <div className={`relative w-full max-w-md h-[85vh] max-h-[680px] rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between p-6 bg-gradient-to-br ${selectedGradient} border border-white/20`}>
        
        {/* Top Header */}
        <div className="flex items-center justify-between z-20">
          <button
            onClick={() => setIsCreatingStory(false)}
            className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            {/* Color Palette Switcher */}
            <div className="flex items-center gap-1.5 p-1 bg-black/40 rounded-full border border-white/10">
              {gradients.map((grad, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedGradient(grad)}
                  className={`w-5 h-5 rounded-full bg-gradient-to-br ${grad} border border-white/40 transition-transform ${
                    selectedGradient === grad ? 'scale-125 ring-2 ring-white' : ''
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Center Text Area */}
        <div className="flex-1 flex items-center justify-center py-6">
          <textarea
            rows={4}
            value={caption}
            onChange={e => setCaption(e.target.value)}
            placeholder="Type your liquid status..."
            className="w-full bg-transparent text-center text-2xl font-bold text-white placeholder-white/50 focus:outline-none resize-none leading-relaxed"
            autoFocus
          />
        </div>

        {/* Bottom Options & Publish Bar */}
        <div className="space-y-3 z-20">
          {/* Privacy Audience Selector */}
          <div className="flex items-center justify-between px-3 py-2 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 text-xs text-white">
            <span className="flex items-center gap-1.5 text-white/80">
              <Lock className="w-3.5 h-3.5 text-cyan-400" />
              Audience:
            </span>
            <div className="flex items-center gap-1">
              {(['contacts', 'everyone', 'private'] as const).map(aud => (
                <button
                  key={aud}
                  onClick={() => setAudience(aud)}
                  className={`px-2.5 py-0.5 rounded-lg capitalize text-[11px] font-semibold transition-colors ${
                    audience === aud ? 'bg-white/20 text-white' : 'text-white/60 hover:text-white'
                  }`}
                >
                  {aud}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handlePost}
            disabled={!caption.trim()}
            className="w-full py-3 rounded-2xl bg-white text-slate-950 font-bold text-sm flex items-center justify-center gap-2 hover:bg-slate-100 transition-colors shadow-xl disabled:opacity-40"
          >
            <span>Share to My Status</span>
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
