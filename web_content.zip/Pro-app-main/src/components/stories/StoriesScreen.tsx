import React from 'react';
import { Plus, Camera, Edit3, Eye, Music, ShieldCheck, Sparkles } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const StoriesScreen: React.FC = () => {
  const { 
    stories, 
    setActiveStoryId, 
    setIsCreatingStory, 
    currentUser, 
    openCamera 
  } = useApp();

  const myStory = stories.find(s => s.userId === currentUser.id);
  const otherStories = stories.filter(s => s.userId !== currentUser.id);

  return (
    <div className="flex flex-col h-full bg-slate-950 overflow-y-auto pb-24 select-none">
      {/* iOS Liquid Glass Header */}
      <div className="ios-glass px-4 pt-4 pb-3 border-b border-white/10 sticky top-0 z-20 backdrop-blur-2xl flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Status</span>
            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              E2EE 24h
            </span>
          </h1>
          <p className="text-xs text-slate-400">Encrypted ephemeral stories & moments</p>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsCreatingStory(true)}
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center text-white transition-colors"
            title="Create Text Status"
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            onClick={openCamera}
            className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 border border-cyan-400/30 flex items-center justify-center text-white shadow-md shadow-cyan-600/30 transition-all"
            title="Capture Photo Status"
          >
            <Camera className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* My Status Card - iOS Liquid Glass Specular */}
        <div 
          onClick={() => myStory ? setActiveStoryId(myStory.id) : setIsCreatingStory(true)}
          className="ios-glass-card rounded-3xl p-4 border border-white/15 flex items-center justify-between cursor-pointer hover:bg-white/[0.08] transition-all shadow-xl"
        >
          <div className="flex items-center gap-3.5">
            <div className="relative w-13 h-13 rounded-full p-0.5 border-2 border-cyan-400 shadow-md">
              <img src={currentUser.avatar} alt="You" className="w-full h-full rounded-full object-cover" />
              {!myStory && (
                <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-cyan-500 text-white flex items-center justify-center border-2 border-slate-950 text-xs shadow-sm">
                  <Plus className="w-3 h-3 font-bold" />
                </div>
              )}
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>My Status</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 font-semibold">
                  24h Ephemeral
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {myStory ? `${myStory.timestamp} • ${myStory.expiresAt}` : 'Tap to add encrypted status update'}
              </p>
            </div>
          </div>

          {myStory && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-400/30 text-xs font-bold text-cyan-300 shadow-sm">
              <Eye className="w-3.5 h-3.5" />
              <span>{myStory.viewersCount} views</span>
            </div>
          )}
        </div>

        {/* Recent Updates Header */}
        <div className="pt-2 flex items-center justify-between px-1">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Recent Updates</span>
          <span className="text-xs text-emerald-400 flex items-center gap-1 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            End-to-End Encrypted
          </span>
        </div>

        {/* Contacts Stories List - iOS Liquid Glass Specular Table */}
        <div className="ios-glass-card rounded-3xl border border-white/15 divide-y divide-white/10 overflow-hidden shadow-2xl">
          {otherStories.map(st => (
            <div
              key={st.id}
              onClick={() => setActiveStoryId(st.id)}
              className="flex items-center justify-between p-3.5 hover:bg-white/[0.06] cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-3.5">
                <div className={`w-12 h-12 rounded-full p-0.5 shadow-sm ${
                  st.isViewed 
                    ? 'border-2 border-slate-700' 
                    : 'bg-gradient-to-tr from-cyan-400 via-emerald-400 to-blue-500 p-[2px]'
                }`}>
                  <img src={st.userAvatar} alt={st.userName} className="w-full h-full rounded-full object-cover border-2 border-slate-950" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">{st.userName}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">{st.timestamp}</p>
                </div>
              </div>

              {st.musicTrack && (
                <div className="flex items-center gap-1.5 text-[11px] text-cyan-300 font-semibold px-2.5 py-1 rounded-full bg-cyan-500/15 border border-cyan-400/30 shadow-sm">
                  <Music className="w-3 h-3 text-cyan-400 animate-spin" />
                  <span className="truncate max-w-[110px]">{st.musicTrack.split('•')[0]}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
