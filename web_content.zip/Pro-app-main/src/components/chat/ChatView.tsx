import React, { useState, useRef, useEffect } from 'react';
import { 
  ChevronLeft, 
  Phone, 
  Video, 
  MoreVertical, 
  ShieldCheck, 
  Check, 
  CheckCheck, 
  Play, 
  Pause, 
  MapPin, 
  Star, 
  Bookmark, 
  Trash2, 
  CornerUpLeft, 
  Copy, 
  Navigation, 
  Clock, 
  FileText, 
  Sparkles,
  Pin,
  Lock,
  Ghost
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ChatInput } from './ChatInput';
import { Message } from '../../types';

export const ChatView: React.FC = () => {
  const { 
    chats, 
    activeChatId, 
    setActiveChatId, 
    messages, 
    currentUser, 
    deleteMessage, 
    toggleStarMessage, 
    addReaction, 
    votePoll, 
    startCall, 
    setIsLocationModalOpen,
    setIsLocationTraceOpen,
    ghostMode,
    setIsGhostModalOpen 
  } = useApp();

  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);
  const [activeMenuMsgId, setActiveMenuMsgId] = useState<string | null>(null);
  const [selectedPhotoModal, setSelectedPhotoModal] = useState<string | null>(null);
  const [bubbleTheme, setBubbleTheme] = useState<'whatsapp' | 'ios'>('whatsapp');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentChat = chats.find(c => c.id === activeChatId);
  const chatMessages = activeChatId ? (messages[activeChatId] || []) : [];

  // Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages.length]);

  if (!currentChat) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-slate-400">
        <div className="w-16 h-16 rounded-3xl ios-glass flex items-center justify-center text-cyan-400 mb-3 shadow-xl">
          <Sparkles className="w-8 h-8" />
        </div>
        <h3 className="text-base font-bold text-white">Select a conversation</h3>
        <p className="text-xs text-slate-400 max-w-xs mt-1">
          Pick a chat from the sidebar or tap the search bar to experience real-time messaging, AI summaries, and live location.
        </p>
      </div>
    );
  }

  const handleToggleVoicePlay = (msgId: string) => {
    if (playingVoiceId === msgId) {
      setPlayingVoiceId(null);
    } else {
      setPlayingVoiceId(msgId);
    }
  };

  const handleCopyText = (text?: string) => {
    if (text) {
      navigator.clipboard?.writeText(text);
      setActiveMenuMsgId(null);
    }
  };

  return (
    <div className="relative flex flex-col h-full bg-slate-950 overflow-hidden">
      {/* iOS Liquid Glass Top Navigation Bar */}
      <div className="z-20 ios-glass border-b border-white/10 px-3 py-2.5 backdrop-blur-2xl flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setActiveChatId(null)}
            className="md:hidden p-1 -ml-1 text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5 text-xs font-semibold"
          >
            <ChevronLeft className="w-5 h-5" />
            <span>Chats</span>
          </button>

          {/* Peer Avatar & Status */}
          <div className="relative">
            <img
              src={currentChat.avatar}
              alt={currentChat.title}
              className="w-9 h-9 rounded-full object-cover border border-white/20 shadow-md"
            />
            {currentChat.type === 'direct' && (
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-slate-950" />
            )}
          </div>

          <div className="cursor-pointer">
            <h2 className="text-sm font-bold text-white leading-tight flex items-center gap-1.5">
              {currentChat.title}
              {ghostMode.enabled && (
                <span title="Ghost Mode Active">
                  <Ghost className="w-3.5 h-3.5 text-purple-400" />
                </span>
              )}
            </h2>
            <p className="text-[11px] text-slate-400 flex items-center gap-1">
              <span className="text-emerald-400">●</span>
              <span>{ghostMode.hideOnlineStatus ? 'Stealth' : 'Online'}</span>
              <span className="text-slate-600">·</span>
              <span className="text-[10px] text-slate-500">Signal E2EE</span>
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 text-cyan-400">
          {/* WhatsApp / iOS Theme Quick Switcher */}
          <button
            onClick={() => setBubbleTheme(b => b === 'whatsapp' ? 'ios' : 'whatsapp')}
            className={`px-2 py-1 rounded-xl text-[10px] font-extrabold uppercase tracking-wider transition-all border ${
              bubbleTheme === 'whatsapp'
                ? 'bg-emerald-500/25 border-emerald-400 text-emerald-300 shadow-sm'
                : 'bg-blue-500/25 border-blue-400 text-blue-300 shadow-sm'
            }`}
            title="Toggle between WhatsApp Liquid Emerald & Classic iOS Blue"
          >
            {bubbleTheme === 'whatsapp' ? 'WA Emerald' : 'iOS Blue'}
          </button>

          <button
            onClick={() => startCall(currentChat.id, 'voice')}
            className="p-1.5 rounded-xl hover:bg-white/10 transition-colors"
            title="Start Voice Call"
          >
            <Phone className="w-4 h-4" />
          </button>
          <button
            onClick={() => startCall(currentChat.id, 'video')}
            className="p-1.5 rounded-xl hover:bg-white/10 transition-colors"
            title="Start Video Call"
          >
            <Video className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsGhostModalOpen(true)}
            className="p-1.5 rounded-xl hover:bg-white/10 transition-colors"
            title="Privacy & Ghost Mode"
          >
            <ShieldCheck className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Canvas with Ambient Liquid Wallpaper */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 relative">
        {/* Subtle decorative background watermarks */}
        <div className="pointer-events-none absolute inset-0 opacity-15 bg-[radial-gradient(circle_at_50%_120%,rgba(0,122,255,0.25),transparent_70%)]" />

        {/* Encryption Safety Notice Banner */}
        <div className="flex justify-center mb-2">
          <div className="px-3.5 py-1.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md flex items-center gap-1.5 text-[11px] text-slate-400 max-w-xs text-center shadow-sm">
            <Lock className="w-3 h-3 text-amber-400 shrink-0" />
            <span>Messages are end-to-end encrypted with Signal Double Ratchet & Kyber.</span>
          </div>
        </div>

        {/* Messages List */}
        {chatMessages.map(msg => {
          const isMe = msg.senderId === currentUser.id;
          const isVoicePlaying = playingVoiceId === msg.id;

          return (
            <div
              key={msg.id}
              className={`relative flex flex-col group ${isMe ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`relative max-w-[85%] sm:max-w-[70%] rounded-2xl p-3 transition-all ${
                  isMe
                    ? bubbleTheme === 'whatsapp'
                      ? 'ios-glass-bubble-wa-outgoing text-emerald-50 rounded-br-sm'
                      : 'ios-glass-bubble-outgoing text-white rounded-br-sm'
                    : 'ios-glass-bubble-incoming text-slate-100 rounded-bl-sm'
                }`}
              >
                {/* Sender Name for Groups */}
                {!isMe && currentChat.type !== 'direct' && (
                  <span className="block text-[10px] font-bold text-cyan-300 mb-1">
                    {msg.senderName}
                  </span>
                )}

                {/* Reply To Preview */}
                {msg.replyTo && (
                  <div className="mb-2 p-1.5 rounded-lg bg-black/20 border-l-2 border-cyan-400 text-[11px] text-slate-200">
                    <span className="font-semibold block text-[10px] text-cyan-300">{msg.replyTo.senderName}</span>
                    <p className="truncate opacity-80">{msg.replyTo.text}</p>
                  </div>
                )}

                {/* Text Type */}
                {msg.type === 'text' && (
                  <p className="text-xs leading-relaxed whitespace-pre-wrap select-text">
                    {msg.text}
                  </p>
                )}

                {/* Image Type */}
                {msg.type === 'image' && msg.mediaUrl && (
                  <div className="space-y-1.5">
                    <img
                      src={msg.mediaUrl}
                      alt="Shared media"
                      onClick={() => setSelectedPhotoModal(msg.mediaUrl!)}
                      className="rounded-xl max-h-60 w-full object-cover cursor-pointer hover:opacity-95 transition-opacity"
                    />
                    {msg.text && (
                      <p className="text-xs leading-relaxed pt-1">{msg.text}</p>
                    )}
                    {msg.mediaSize && (
                      <span className="text-[10px] opacity-75 font-mono block">{msg.mediaSize}</span>
                    )}
                  </div>
                )}

                {/* Audio Voice Note Type */}
                {msg.type === 'audio' && (
                  <div className="flex items-center gap-3 py-1 min-w-[200px]">
                    <button
                      onClick={() => handleToggleVoicePlay(msg.id)}
                      className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white shrink-0 transition-transform active:scale-95"
                    >
                      {isVoicePlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                    </button>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-0.5 h-6">
                        {[30, 60, 45, 80, 95, 40, 70, 85, 30, 65, 50, 75, 40, 85, 60, 45].map((h, i) => (
                          <div
                            key={i}
                            className={`w-1 rounded-full transition-all duration-200 ${
                              isVoicePlaying && i % 3 === 0 ? 'bg-cyan-300' : 'bg-white/60'
                            }`}
                            style={{ height: `${isVoicePlaying ? Math.min(100, h + 10) : h}%` }}
                          />
                        ))}
                      </div>
                      <div className="flex justify-between text-[10px] opacity-75">
                        <span>{isVoicePlaying ? 'Playing...' : msg.mediaDuration || '0:34'}</span>
                        <span>Neural 48kHz</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Consent-Based Live Location Card */}
                {msg.type === 'live_location' && msg.locationData && (
                  <div className="space-y-2 min-w-[240px]">
                    <div className="relative h-28 rounded-xl overflow-hidden bg-slate-900 border border-white/20 flex items-center justify-center">
                      <div className="absolute inset-0 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:12px_12px] opacity-40" />
                      <div className="relative z-10 w-9 h-9 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center animate-pulse">
                        <Navigation className="w-5 h-5 text-cyan-300" />
                      </div>
                      <div className="absolute bottom-1.5 left-2 px-2 py-0.5 rounded bg-black/70 text-[9px] text-cyan-300 font-mono">
                        ±{msg.locationData.accuracyMeters}m GPS Accuracy
                      </div>
                    </div>

                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                        {msg.locationData.isEmergency ? '🚨 SOS EMERGENCY LOCATION' : 'Live Location Sharing'}
                      </span>
                      <p className="text-[11px] opacity-80">{msg.locationData.address}</p>
                    </div>

                    <div className="pt-1 flex items-center justify-between text-[10px] opacity-80 border-t border-white/10">
                      <span>Expires in {msg.locationData.durationMinutes}m</span>
                      <button
                        onClick={() => setIsLocationTraceOpen(true)}
                        className="text-cyan-300 font-semibold hover:underline"
                      >
                        View Full Radar
                      </button>
                    </div>
                  </div>
                )}

                {/* Interactive Poll / Quiz Type */}
                {msg.type === 'poll' && msg.pollData && (
                  <div className="space-y-2.5 min-w-[250px]">
                    <span className="text-xs font-bold block text-white">
                      📊 {msg.pollData.question}
                    </span>
                    <div className="space-y-1.5">
                      {msg.pollData.options.map(opt => {
                        const isVoted = opt.votes.includes(currentUser.id);
                        const pct = msg.pollData?.totalVotes && msg.pollData.totalVotes > 0 
                          ? Math.round((opt.votes.length / msg.pollData.totalVotes) * 100) 
                          : 0;

                        return (
                          <button
                            key={opt.id}
                            onClick={() => votePoll(currentChat.id, msg.id, opt.id)}
                            className={`w-full text-left p-2 rounded-xl border transition-all relative overflow-hidden ${
                              isVoted 
                                ? 'bg-cyan-500/30 border-cyan-400 text-white' 
                                : 'bg-black/30 border-white/10 text-slate-200 hover:bg-black/40'
                            }`}
                          >
                            {/* Vote progress fill bar */}
                            <div
                              className="absolute inset-y-0 left-0 bg-white/10 transition-all duration-300 pointer-events-none"
                              style={{ width: `${pct}%` }}
                            />
                            <div className="relative z-10 flex items-center justify-between text-xs">
                              <span className="font-medium truncate pr-2">{opt.text}</span>
                              <span className="text-[10px] font-mono opacity-80">{pct}% ({opt.votes.length})</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                    <span className="text-[10px] opacity-75 block text-right">
                      {msg.pollData.totalVotes} total votes
                    </span>
                  </div>
                )}

                {/* Document Type */}
                {msg.type === 'document' && (
                  <div className="flex items-center gap-3 p-2 rounded-xl bg-black/20 border border-white/10">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div className="flex-1 truncate">
                      <span className="text-xs font-semibold block text-white truncate">{msg.fileName || 'Attachment.pdf'}</span>
                      <span className="text-[10px] opacity-75">{msg.mediaSize || 'PDF Document'}</span>
                    </div>
                  </div>
                )}

                {/* AI Sticker Type */}
                {msg.type === 'sticker' && msg.mediaUrl && (
                  <div className="p-1">
                    <img src={msg.mediaUrl} alt="AI Sticker" className="w-28 h-28 object-contain drop-shadow-2xl animate-pulse" />
                  </div>
                )}

                {/* Timestamp & Status Tick Marks */}
                <div className="flex items-center justify-end gap-1 mt-1 text-[10px] opacity-70">
                  {msg.isStarred && <Star className="w-2.5 h-2.5 text-amber-400 fill-amber-400" />}
                  <span>{msg.timestamp}</span>
                  {isMe && (
                    <span>
                      {msg.status === 'read' && !ghostMode.disableReadReceipts ? (
                        <CheckCheck className="w-3 h-3 text-cyan-300" />
                      ) : msg.status === 'delivered' ? (
                        <CheckCheck className="w-3 h-3 text-slate-300" />
                      ) : (
                        <Check className="w-3 h-3 text-slate-300" />
                      )}
                    </span>
                  )}
                </div>

                {/* Reactions Floating Bar */}
                {msg.reactions.length > 0 && (
                  <div className="absolute -bottom-2.5 right-2 flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-slate-900 border border-white/20 shadow-md text-xs">
                    {msg.reactions.map((r, i) => (
                      <span key={i} title={r.userName}>{r.emoji}</span>
                    ))}
                  </div>
                )}
              </div>

              {/* Hover / Long Press Quick Actions */}
              <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 mt-1 px-1">
                {['❤️', '🔥', '👍'].map(em => (
                  <button
                    key={em}
                    onClick={() => addReaction(currentChat.id, msg.id, em)}
                    className="text-xs hover:scale-125 transition-transform"
                  >
                    {em}
                  </button>
                ))}
                <button
                  onClick={() => toggleStarMessage(currentChat.id, msg.id)}
                  className="p-1 rounded text-slate-400 hover:text-amber-400"
                  title="Star message"
                >
                  <Star className="w-3 h-3" />
                </button>
                <button
                  onClick={() => handleCopyText(msg.text)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                  title="Copy text"
                >
                  <Copy className="w-3 h-3" />
                </button>
                <button
                  onClick={() => deleteMessage(currentChat.id, msg.id, isMe)}
                  className="p-1 rounded text-slate-400 hover:text-rose-400"
                  title="Delete message"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Lightbox Photo Preview Modal */}
      {selectedPhotoModal && (
        <div 
          onClick={() => setSelectedPhotoModal(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl cursor-pointer"
        >
          <img src={selectedPhotoModal} alt="Preview" className="max-w-full max-h-[85vh] rounded-2xl shadow-2xl object-contain" />
        </div>
      )}

      {/* Input Section */}
      <ChatInput chatId={currentChat.id} />
    </div>
  );
};
