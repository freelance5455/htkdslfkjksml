import React from 'react';
import { 
  Search, 
  Plus, 
  Pin, 
  VolumeX, 
  CheckCheck, 
  Radio, 
  Sparkles, 
  Camera, 
  FolderLock, 
  ShieldCheck, 
  Users,
  Compass,
  MessageCircle,
  X,
  Navigation,
  CheckCircle2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ChatThread } from '../../types';

export const ChatList: React.FC = () => {
  const { 
    chats, 
    activeChatId, 
    setActiveChatId, 
    searchQuery, 
    setSearchQuery, 
    chatFilter, 
    setChatFilter, 
    stories, 
    setActiveStoryId, 
    setIsCreatingStory,
    openCamera,
    ghostMode,
    setIsGhostModalOpen,
    currentUser,
    setIsLocationTraceOpen,
    liveLocation
  } = useApp();

  const filteredChats = chats.filter(c => {
    // Search query match
    if (searchQuery.trim()) {
      const matchTitle = c.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchLast = c.lastMessage?.text?.toLowerCase().includes(searchQuery.toLowerCase());
      if (!matchTitle && !matchLast) return false;
    }

    // Tab filter match
    if (chatFilter === 'unread') return c.unreadCount > 0;
    if (chatFilter === 'groups') return c.type === 'group';
    if (chatFilter === 'channels') return c.type === 'channel';
    if (chatFilter === 'vault') return c.disappearingTimerDays !== undefined || ghostMode.enabled;
    return true;
  });

  return (
    <div className="flex flex-col h-full bg-slate-950/90 border-r border-white/10 overflow-hidden select-none">
      {/* iOS Liquid Header */}
      <div className="ios-glass px-4 pt-3.5 pb-2.5 border-b border-white/10 z-20 space-y-2.5 backdrop-blur-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
              <span>Chats</span>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/35 flex items-center gap-1">
                <CheckCircle2 className="w-2.5 h-2.5" />
                <span>Zero Bans • 100% Active</span>
              </span>
            </h1>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Quick Live Location Trace Launch Button */}
            <button
              onClick={() => setIsLocationTraceOpen(true)}
              className={`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all ${
                liveLocation?.isSharing
                  ? 'bg-emerald-500/25 border-emerald-400 text-emerald-300 animate-pulse shadow-md shadow-emerald-500/30'
                  : 'bg-cyan-500/15 border-cyan-400/30 text-cyan-300 hover:bg-cyan-500/25'
              }`}
              title="Explore Live Location Trace in iOS Liquid Glass"
            >
              <Navigation className="w-3.5 h-3.5 text-cyan-300" />
              <span className="hidden sm:inline">Live Radar</span>
            </button>

            <button
              onClick={openCamera}
              className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors border border-white/10"
              title="CameraX Studio"
            >
              <Camera className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsGhostModalOpen(true)}
              className="w-8 h-8 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 flex items-center justify-center text-purple-300 border border-purple-500/40 transition-colors"
              title="Ghost Privacy Shield"
            >
              <ShieldCheck className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search Bar - iOS Frosted Glass Capsule */}
        <div className="relative">
          <div className="flex items-center gap-2 bg-black/40 border border-white/15 rounded-2xl px-3.5 py-2 text-xs text-white shadow-inner">
            <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search chats, contacts, or messages..."
              className="flex-1 bg-transparent placeholder-slate-500 focus:outline-none text-xs"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="text-slate-400 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Filter Segmented Control Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {[
            { id: 'all', label: 'All' },
            { id: 'unread', label: 'Unread' },
            { id: 'groups', label: 'Groups' },
            { id: 'channels', label: 'Channels' },
            { id: 'vault', label: 'Vault' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setChatFilter(f.id as any)}
              className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all border ${
                chatFilter === f.id
                  ? 'bg-cyan-500/30 border-cyan-400 text-cyan-200 shadow-md ring-1 ring-cyan-400/40'
                  : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Stories / Status Carousel Tray */}
      <div className="px-4 py-2.5 border-b border-white/10 bg-black/30 overflow-x-auto no-scrollbar flex items-center gap-3 backdrop-blur-md">
        {/* Add My Status */}
        <div 
          onClick={() => setIsCreatingStory(true)}
          className="flex flex-col items-center gap-1 cursor-pointer shrink-0"
        >
          <div className="relative w-13 h-13 rounded-full p-0.5 border-2 border-dashed border-cyan-400 hover:border-cyan-300 transition-colors shadow-sm">
            <img src={currentUser.avatar} alt="You" className="w-full h-full rounded-full object-cover" />
            <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-cyan-500 text-white flex items-center justify-center border-2 border-slate-950">
              <Plus className="w-3 h-3 font-bold" />
            </div>
          </div>
          <span className="text-[11px] text-slate-300 font-medium">My Status</span>
        </div>

        {/* Contacts Stories */}
        {stories.map(st => (
          <div
            key={st.id}
            onClick={() => setActiveStoryId(st.id)}
            className="flex flex-col items-center gap-1 cursor-pointer shrink-0 group"
          >
            <div className={`w-13 h-13 rounded-full p-0.5 transition-transform group-hover:scale-105 shadow-sm ${
              st.isViewed 
                ? 'border-2 border-slate-700' 
                : 'bg-gradient-to-tr from-cyan-400 via-emerald-400 to-blue-500 p-[2px]'
            }`}>
              <img src={st.userAvatar} alt={st.userName} className="w-full h-full rounded-full object-cover border-2 border-slate-950" />
            </div>
            <span className="text-[11px] text-slate-300 font-medium truncate max-w-[60px]">
              {st.userName.split(' ')[0]}
            </span>
          </div>
        ))}
      </div>

      {/* Chat Threads List */}
      <div className="flex-1 overflow-y-auto divide-y divide-white/5 p-2 space-y-1">
        {filteredChats.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            No conversations found for current filter.
          </div>
        ) : (
          filteredChats.map(c => {
            const isSelected = activeChatId === c.id;
            const lastMsg = c.lastMessage;

            return (
              <div
                key={c.id}
                onClick={() => setActiveChatId(c.id)}
                className={`flex items-center gap-3 px-3.5 py-3 rounded-2xl cursor-pointer transition-all relative ${
                  isSelected 
                    ? 'ios-glass-card border border-cyan-400/40 shadow-lg shadow-cyan-500/15' 
                    : 'hover:bg-white/[0.06] border border-transparent'
                }`}
              >
                {/* Avatar with status */}
                <div className="relative shrink-0">
                  <img
                    src={c.avatar}
                    alt={c.title}
                    className="w-12 h-12 rounded-full object-cover border border-white/15 shadow-md"
                  />
                  {c.type === 'direct' && (
                    <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-slate-950 shadow-sm" />
                  )}
                  {c.type === 'group' && (
                    <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-blue-600 text-white flex items-center justify-center ring-2 ring-slate-950 text-[8px]">
                      <Users className="w-2.5 h-2.5" />
                    </span>
                  )}
                </div>

                {/* Content info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <h3 className="text-sm font-bold text-white truncate flex items-center gap-1.5">
                      {c.title}
                      {c.isPinned && <Pin className="w-2.5 h-2.5 text-cyan-400 fill-cyan-400" />}
                    </h3>
                    <span className="text-[10px] text-slate-400 font-medium shrink-0 ml-1">
                      {lastMsg?.timestamp || '10:00 AM'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <p className="text-xs text-slate-400 truncate flex items-center gap-1">
                      {lastMsg?.senderId === currentUser.id && (
                        <CheckCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      )}
                      {lastMsg?.type === 'audio' && '🎵 Voice Note'}
                      {lastMsg?.type === 'image' && '📷 Photo'}
                      {lastMsg?.type === 'live_location' && '📍 Live Location'}
                      {lastMsg?.type === 'poll' && '📊 Poll'}
                      {lastMsg?.type === 'text' && (lastMsg.text || '')}
                      {!lastMsg && (c.description || 'Tap to start conversation')}
                    </p>

                    <div className="flex items-center gap-1 shrink-0 ml-2">
                      {c.isMuted && <VolumeX className="w-3 h-3 text-slate-500" />}
                      {c.unreadCount > 0 && (
                        <span className="px-1.5 py-0.2 min-w-[20px] h-5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black flex items-center justify-center shadow-md shadow-emerald-500/40">
                          {c.unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
