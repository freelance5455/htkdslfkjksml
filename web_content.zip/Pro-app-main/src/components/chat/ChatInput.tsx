import React, { useState, useRef } from 'react';
import { 
  Smile, 
  Paperclip, 
  Camera, 
  Mic, 
  Send, 
  MapPin, 
  FileText, 
  User, 
  BarChart2, 
  Image as ImageIcon,
  Sparkles,
  StopCircle,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { generateSmartReplies } from '../../services/geminiService';

interface ChatInputProps {
  chatId: string;
}

export const ChatInput: React.FC<ChatInputProps> = ({ chatId }) => {
  const { 
    sendMessage, 
    openCamera, 
    setIsLocationModalOpen,
    messages 
  } = useApp();

  const [inputText, setInputText] = useState('');
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [recordDuration, setRecordDuration] = useState(0);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [smartReplies, setSmartReplies] = useState<string[]>([]);
  const [isGeneratingReplies, setIsGeneratingReplies] = useState(false);
  const [showPollCreator, setShowPollCreator] = useState(false);

  // Poll creator modal state
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['Option 1', 'Option 2']);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const handleSend = () => {
    if (!inputText.trim()) return;
    sendMessage(chatId, inputText.trim(), 'text');
    setInputText('');
    setSmartReplies([]);
  };

  const handleVoiceRecordToggle = () => {
    if (!isRecordingAudio) {
      setIsRecordingAudio(true);
      setRecordDuration(0);
      timerRef.current = setInterval(() => {
        setRecordDuration(d => d + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setIsRecordingAudio(false);
      // Send audio note
      const durationStr = `0:${recordDuration.toString().padStart(2, '0')}`;
      sendMessage(chatId, `Voice note (${durationStr})`, 'audio', {
        mediaDuration: durationStr,
      });
      setRecordDuration(0);
    }
  };

  const handleCancelRecord = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsRecordingAudio(false);
    setRecordDuration(0);
  };

  const handleTriggerSmartReplies = async () => {
    const chatMsgs = messages[chatId] || [];
    const lastMsg = chatMsgs[chatMsgs.length - 1]?.text || 'What time are we meeting?';
    setIsGeneratingReplies(true);
    const replies = await generateSmartReplies(lastMsg);
    setSmartReplies(replies);
    setIsGeneratingReplies(false);
  };

  const handleCreatePoll = () => {
    if (!pollQuestion.trim()) return;
    sendMessage(chatId, pollQuestion, 'poll', {
      pollData: {
        question: pollQuestion,
        isMultipleChoice: false,
        totalVotes: 0,
        options: pollOptions.filter(o => o.trim()).map((opt, idx) => ({
          id: `opt_${Date.now()}_${idx}`,
          text: opt,
          votes: [],
        })),
      },
    });
    setShowPollCreator(false);
    setPollQuestion('');
    setPollOptions(['Option 1', 'Option 2']);
  };

  return (
    <div className="relative px-3 py-2 ios-glass border-t border-white/10 z-20">
      {/* Smart Reply Predictive Chips */}
      {smartReplies.length > 0 && (
        <div className="mb-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
          <span className="text-[10px] uppercase font-bold text-cyan-400 shrink-0 flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            AI Replies:
          </span>
          {smartReplies.map((reply, i) => (
            <button
              key={i}
              onClick={() => {
                sendMessage(chatId, reply, 'text');
                setSmartReplies([]);
              }}
              className="px-3 py-1 rounded-full text-xs bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/30 transition-all whitespace-nowrap shadow-sm"
            >
              {reply}
            </button>
          ))}
          <button
            onClick={() => setSmartReplies([])}
            className="p-1 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Main Input Row */}
      <div className="flex items-center gap-2">
        {/* Emoji Button */}
        <button
          onClick={() => setShowEmojiPicker(!showEmojiPicker)}
          className="p-2 text-slate-400 hover:text-white transition-colors"
        >
          <Smile className="w-5 h-5" />
        </button>

        {/* Attachment Pin */}
        <div className="relative">
          <button
            onClick={() => setShowAttachMenu(!showAttachMenu)}
            className="p-2 text-slate-400 hover:text-white transition-colors"
          >
            <Paperclip className="w-5 h-5" />
          </button>

          {/* Attachment Popup Sheet */}
          {showAttachMenu && (
            <div className="absolute bottom-12 left-0 w-52 ios-glass-card rounded-2xl p-2 border border-white/20 shadow-2xl z-40 space-y-1">
              <button
                onClick={() => {
                  setShowAttachMenu(false);
                  setIsLocationModalOpen(true);
                }}
                className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs text-white hover:bg-white/10 transition-colors"
              >
                <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <MapPin className="w-4 h-4" />
                </div>
                <span>Live Location</span>
              </button>

              <button
                onClick={() => {
                  setShowAttachMenu(false);
                  setShowPollCreator(true);
                }}
                className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs text-white hover:bg-white/10 transition-colors"
              >
                <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                  <BarChart2 className="w-4 h-4" />
                </div>
                <span>Create Poll</span>
              </button>

              <button
                onClick={() => {
                  setShowAttachMenu(false);
                  openCamera();
                }}
                className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs text-white hover:bg-white/10 transition-colors"
              >
                <div className="w-7 h-7 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center">
                  <Camera className="w-4 h-4" />
                </div>
                <span>CameraX Studio</span>
              </button>

              <button
                onClick={() => {
                  setShowAttachMenu(false);
                  sendMessage(chatId, 'Shared document: Specification_v2.5.pdf (14.2 MB)', 'document', {
                    fileName: 'Aether_Architecture_Spec.pdf',
                    mediaSize: '14.2 MB',
                  });
                }}
                className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs text-white hover:bg-white/10 transition-colors"
              >
                <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                  <FileText className="w-4 h-4" />
                </div>
                <span>Document / PDF</span>
              </button>
            </div>
          )}
        </div>

        {/* Text Input / Voice Recording Bar */}
        {isRecordingAudio ? (
          <div className="flex-1 flex items-center justify-between px-3 py-2 bg-rose-950/40 border border-rose-500/30 rounded-2xl animate-pulse">
            <div className="flex items-center gap-2 text-rose-300 text-xs font-mono font-semibold">
              <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span>Recording: 0:{recordDuration.toString().padStart(2, '0')}</span>
            </div>
            <button
              onClick={handleCancelRecord}
              className="text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        ) : (
          <div className="flex-1 flex items-center gap-1.5 bg-black/40 rounded-2xl px-3 py-1.5 border border-white/15">
            <input
              type="text"
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSend()}
              placeholder="Message Aether..."
              className="flex-1 bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none"
            />
            {/* AI Smart Replies Trigger Button */}
            <button
              onClick={handleTriggerSmartReplies}
              disabled={isGeneratingReplies}
              title="Generate AI Smart Replies"
              className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20 transition-colors"
            >
              <Sparkles className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Camera Shortcut */}
        {!isRecordingAudio && !inputText && (
          <button
            onClick={openCamera}
            className="p-2 text-slate-400 hover:text-white transition-colors"
            title="Open CameraX"
          >
            <Camera className="w-5 h-5" />
          </button>
        )}

        {/* Send or Mic Button */}
        {inputText.trim() ? (
          <button
            onClick={handleSend}
            className="w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow-lg shadow-blue-600/30 transition-transform active:scale-95"
          >
            <Send className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={handleVoiceRecordToggle}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
              isRecordingAudio 
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/40' 
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
          >
            {isRecordingAudio ? <StopCircle className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>
        )}
      </div>

      {/* Quick Emoji Bar */}
      {showEmojiPicker && (
        <div className="mt-2 p-2 bg-black/60 rounded-xl border border-white/10 flex items-center justify-around text-lg">
          {['❤️', '🔥', '👍', '😊', '🚀', '✨', '⚡️', '🎉', '🔒', '👏'].map(em => (
            <button
              key={em}
              onClick={() => {
                setInputText(t => t + em);
                setShowEmojiPicker(false);
              }}
              className="hover:scale-125 transition-transform"
            >
              {em}
            </button>
          ))}
        </div>
      )}

      {/* Poll Creator Modal */}
      {showPollCreator && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
          <div className="w-full max-w-sm ios-glass-card rounded-3xl p-5 border border-white/20 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <BarChart2 className="w-4 h-4 text-cyan-400" />
                New Group Poll
              </h3>
              <button onClick={() => setShowPollCreator(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1">
              <label className="text-xs text-slate-300">Question</label>
              <input
                type="text"
                value={pollQuestion}
                onChange={e => setPollQuestion(e.target.value)}
                placeholder="Ask a question..."
                className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500/50"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-300">Options</label>
              {pollOptions.map((opt, i) => (
                <input
                  key={i}
                  type="text"
                  value={opt}
                  onChange={e => {
                    const next = [...pollOptions];
                    next[i] = e.target.value;
                    setPollOptions(next);
                  }}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500/50"
                />
              ))}
              <button
                type="button"
                onClick={() => setPollOptions(o => [...o, `Option ${o.length + 1}`])}
                className="text-[11px] text-cyan-400 hover:underline font-medium"
              >
                + Add Option
              </button>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowPollCreator(false)}
                className="flex-1 py-2 rounded-xl bg-white/10 text-xs text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleCreatePoll}
                disabled={!pollQuestion.trim()}
                className="flex-1 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold disabled:opacity-40"
              >
                Send Poll
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
