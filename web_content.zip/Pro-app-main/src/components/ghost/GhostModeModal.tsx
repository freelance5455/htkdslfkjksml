import React from 'react';
import { 
  Ghost, 
  ShieldCheck, 
  EyeOff, 
  Lock, 
  BellOff, 
  Clock, 
  X, 
  Check, 
  Smartphone,
  FolderLock
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const GhostModeModal: React.FC = () => {
  const { isGhostModalOpen, setIsGhostModalOpen, ghostMode, updateGhostMode } = useApp();

  if (!isGhostModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-md ios-glass-card rounded-3xl p-5 border border-white/20 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-2xl flex items-center justify-center border ${
              ghostMode.enabled
                ? 'bg-purple-500/20 text-purple-300 border-purple-500/40 shadow-lg shadow-purple-500/25'
                : 'bg-white/10 text-slate-400 border-white/10'
            }`}>
              <Ghost className="w-5 h-5 animate-bounce" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-1.5">
                Ghost Privacy Matrix
                {ghostMode.enabled && (
                  <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    Active
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-400">Zero-footprint privacy & stealth defenses</p>
            </div>
          </div>
          <button
            onClick={() => setIsGhostModalOpen(false)}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Master Ghost Mode Toggle */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 to-indigo-950/60 border border-purple-500/30 flex items-center justify-between">
          <div>
            <span className="text-sm font-bold text-white block">Master Stealth Mode</span>
            <span className="text-xs text-purple-200/80">Activate all stealth privacy shields at once</span>
          </div>
          <button
            onClick={() => {
              const next = !ghostMode.enabled;
              updateGhostMode({
                enabled: next,
                hideOnlineStatus: next,
                hideLastSeen: next,
                disableReadReceipts: next,
                hideTypingIndicator: next,
                privateNotificationPreviews: next,
              });
            }}
            className={`w-12 h-6 rounded-full transition-colors relative ${ghostMode.enabled ? 'bg-purple-600' : 'bg-slate-700'}`}
          >
            <span className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform ${ghostMode.enabled ? 'left-6' : 'left-0.5'}`} />
          </button>
        </div>

        {/* Granular Toggles List */}
        <div className="space-y-2.5">
          {/* Hide Online & Last Seen */}
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <EyeOff className="w-4 h-4 text-purple-400" />
              <div>
                <span className="text-xs font-semibold text-white block">Hide Online & Last Seen</span>
                <span className="text-[11px] text-slate-400">Nobody sees your connection activity</span>
              </div>
            </div>
            <button
              onClick={() => updateGhostMode({ hideOnlineStatus: !ghostMode.hideOnlineStatus, hideLastSeen: !ghostMode.hideLastSeen })}
              className={`w-10 h-5 rounded-full transition-colors relative ${ghostMode.hideOnlineStatus ? 'bg-purple-600' : 'bg-slate-700'}`}
            >
              <span className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${ghostMode.hideOnlineStatus ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>

          {/* Disable Read Receipts */}
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Check className="w-4 h-4 text-purple-400" />
              <div>
                <span className="text-xs font-semibold text-white block">Disable Blue Read Receipts</span>
                <span className="text-[11px] text-slate-400">Incoming messages stay marked as delivered</span>
              </div>
            </div>
            <button
              onClick={() => updateGhostMode({ disableReadReceipts: !ghostMode.disableReadReceipts })}
              className={`w-10 h-5 rounded-full transition-colors relative ${ghostMode.disableReadReceipts ? 'bg-purple-600' : 'bg-slate-700'}`}
            >
              <span className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${ghostMode.disableReadReceipts ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>

          {/* Hide Typing & Recording Indicators */}
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Clock className="w-4 h-4 text-purple-400" />
              <div>
                <span className="text-xs font-semibold text-white block">Stealth Typing & Recording</span>
                <span className="text-[11px] text-slate-400">Suppress 'typing...' & 'recording audio...'</span>
              </div>
            </div>
            <button
              onClick={() => updateGhostMode({ hideTypingIndicator: !ghostMode.hideTypingIndicator, hideRecordingIndicator: !ghostMode.hideRecordingIndicator })}
              className={`w-10 h-5 rounded-full transition-colors relative ${ghostMode.hideTypingIndicator ? 'bg-purple-600' : 'bg-slate-700'}`}
            >
              <span className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${ghostMode.hideTypingIndicator ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>

          {/* Private Notification Previews */}
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BellOff className="w-4 h-4 text-purple-400" />
              <div>
                <span className="text-xs font-semibold text-white block">Invisible Lock-Screen Previews</span>
                <span className="text-[11px] text-slate-400">Displays 'New Aether Message' without sender or text</span>
              </div>
            </div>
            <button
              onClick={() => updateGhostMode({ privateNotificationPreviews: !ghostMode.privateNotificationPreviews })}
              className={`w-10 h-5 rounded-full transition-colors relative ${ghostMode.privateNotificationPreviews ? 'bg-purple-600' : 'bg-slate-700'}`}
            >
              <span className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${ghostMode.privateNotificationPreviews ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>

          {/* App Lock & Biometrics */}
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Lock className="w-4 h-4 text-purple-400" />
              <div>
                <span className="text-xs font-semibold text-white block">Biometric App Lock & PIN</span>
                <span className="text-[11px] text-slate-400">Require FaceID / Fingerprint upon reopening</span>
              </div>
            </div>
            <button
              onClick={() => updateGhostMode({ appLockRequired: !ghostMode.appLockRequired })}
              className={`w-10 h-5 rounded-full transition-colors relative ${ghostMode.appLockRequired ? 'bg-purple-600' : 'bg-slate-700'}`}
            >
              <span className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${ghostMode.appLockRequired ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>

          {/* Screenshot Prevention */}
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Smartphone className="w-4 h-4 text-purple-400" />
              <div>
                <span className="text-xs font-semibold text-white block">FLAG_SECURE Screenshot Block</span>
                <span className="text-[11px] text-slate-400">Android window security prevents screen capture</span>
              </div>
            </div>
            <button
              onClick={() => updateGhostMode({ screenshotProtection: !ghostMode.screenshotProtection })}
              className={`w-10 h-5 rounded-full transition-colors relative ${ghostMode.screenshotProtection ? 'bg-purple-600' : 'bg-slate-700'}`}
            >
              <span className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${ghostMode.screenshotProtection ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>
        </div>

        {/* Done Button */}
        <button
          onClick={() => setIsGhostModalOpen(false)}
          className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-lg shadow-purple-600/30"
        >
          Save Privacy Shield
        </button>
      </div>
    </div>
  );
};
