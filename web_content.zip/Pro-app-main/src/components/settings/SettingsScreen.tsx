import React, { useState } from 'react';
import { 
  User, 
  ShieldCheck, 
  Lock, 
  Key, 
  Smartphone, 
  Languages, 
  Palette, 
  Database, 
  Bell, 
  Ghost, 
  ChevronRight, 
  Download, 
  Trash2, 
  Code2, 
  QrCode, 
  Check, 
  HardDrive,
  Monitor,
  Navigation,
  Terminal,
  Sparkles
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const SettingsScreen: React.FC = () => {
  const { 
    currentUser, 
    updateCurrentUser, 
    setIsGhostModalOpen, 
    language, 
    setLanguage, 
    isDeviceFrame, 
    setIsDeviceFrame,
    setIsAdminModalOpen,
    setActiveTab,
    ghostMode,
    chats,
    messages,
    setIsLocationTraceOpen,
    setIsDevOptionsOpen
  } = useApp();

  const [activeTheme, setActiveTheme] = useState<'dark' | 'light' | 'amoled'>('dark');
  const [showQrModal, setShowQrModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);

  const handleExportData = () => {
    const dataToExport = {
      user: currentUser,
      chatsCount: chats.length,
      timestamp: new Date().toISOString(),
      encryptionStandard: 'Signal Double Ratchet + Kyber Post-Quantum',
      exportedMessages: Object.keys(messages).length,
    };
    const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aether_backup_${Date.now()}.json`;
    a.click();
    setShowExportModal(false);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 overflow-y-auto pb-24 text-slate-100">
      {/* iOS Liquid Header */}
      <div className="ios-glass px-4 pt-4 pb-3 border-b border-white/10 sticky top-0 z-20 backdrop-blur-2xl">
        <h1 className="text-xl font-extrabold text-white tracking-tight">Settings</h1>
        <p className="text-xs text-slate-400">Security, Privacy & Preferences</p>
      </div>

      <div className="p-4 space-y-4">
        {/* User Profile Card */}
        <div className="ios-glass-card rounded-3xl p-4 border border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-14 h-14 rounded-full object-cover border-2 border-cyan-400 shadow-lg"
              />
              <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-slate-950" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-1.5">
                {currentUser.name}
                <span className="text-[10px] bg-cyan-500/20 text-cyan-300 font-bold px-1.5 py-0.5 rounded border border-cyan-500/30">
                  PRO
                </span>
              </h2>
              <p className="text-xs text-cyan-400">{currentUser.handle}</p>
              <p className="text-[11px] text-slate-400 mt-0.5 truncate max-w-[180px]">{currentUser.bio}</p>
            </div>
          </div>

          <button
            onClick={() => setShowQrModal(true)}
            className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors"
            title="Show My QR Code"
          >
            <QrCode className="w-5 h-5" />
          </button>
        </div>

        {/* Viewport Frame Mode Toggle (iPhone vs Fullscreen Desktop) */}
        <div className="ios-glass-card rounded-2xl p-4 border border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
              <Monitor className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white">Device Presentation Mode</h3>
              <p className="text-[11px] text-slate-400">
                {isDeviceFrame ? 'iPhone 16 Pro Liquid Glass Frame' : 'Full-Screen Desktop Canvas'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsDeviceFrame(!isDeviceFrame)}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-cyan-300 border border-white/10 transition-colors"
          >
            {isDeviceFrame ? 'Switch to Fullscreen' : 'Switch to iPhone Frame'}
          </button>
        </div>

        {/* Live Location Radar Tile in Settings */}
        <div 
          onClick={() => setIsLocationTraceOpen(true)}
          className="ios-glass-card rounded-2xl p-4 border border-cyan-400/30 flex items-center justify-between cursor-pointer hover:bg-white/[0.08] transition-all shadow-lg"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center border border-cyan-400/30 shadow-inner">
              <Navigation className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>Explore Live Location Trace</span>
                <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  iOS Liquid Glass
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Interactive cartography, real-time markers & incident response filters
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-cyan-400" />
        </div>

        {/* Developer Options & 2000+ Power Feature Generator Tile */}
        <div 
          onClick={() => setIsDevOptionsOpen(true)}
          className="ios-glass-card rounded-2xl p-4 border border-emerald-500/40 flex items-center justify-between cursor-pointer hover:bg-emerald-500/10 transition-all shadow-lg shadow-emerald-950/20 group"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-white flex items-center justify-center border border-emerald-400/40 shadow-md shadow-emerald-500/30 group-hover:scale-105 transition-transform">
              <Terminal className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>Developer Options & 2000+ Features</span>
                <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-emerald-500/25 text-emerald-300 border border-emerald-400/40 animate-pulse">
                  ROOT UNLOCKED
                </span>
              </h3>
              <p className="text-[11px] text-emerald-200/80">
                Direct open • No phone login • No OTP • No Gmail • 2000+ feature generator
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-0.5 transition-transform" />
        </div>

        {/* SECTION 1: Privacy & Ghost Mode */}
        <div className="space-y-1.5">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">Privacy & Security</span>
          <div className="ios-glass rounded-2xl border border-white/10 divide-y divide-white/5 overflow-hidden">
            
            {/* Ghost Mode Launcher */}
            <div 
              onClick={() => setIsGhostModalOpen(true)}
              className="flex items-center justify-between p-3.5 hover:bg-white/5 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center border border-purple-500/30">
                  <Ghost className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-white block">Ghost Privacy Matrix</span>
                  <span className="text-[11px] text-slate-400">
                    {ghostMode.enabled ? 'Active • Stealth Online & Read Receipts' : 'Configure invisible stealth shields'}
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </div>

            {/* Passkey FIDO2 */}
            <div className="flex items-center justify-between p-3.5">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
                  <Key className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-white block">Passkey Authentication</span>
                  <span className="text-[11px] text-slate-400">FIDO2 Hardware-bound key enrolled</span>
                </div>
              </div>
              <span className="text-[11px] text-emerald-400 font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                Enrolled
              </span>
            </div>

            {/* Two-Factor Authentication */}
            <div className="flex items-center justify-between p-3.5">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-white block">Two-Factor Authentication (2FA)</span>
                  <span className="text-[11px] text-slate-400">TOTP Authenticator enabled</span>
                </div>
              </div>
              <span className="text-[11px] text-emerald-400 font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                Active
              </span>
            </div>

            {/* Linked Devices */}
            <div className="flex items-center justify-between p-3.5">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-white block">Linked Devices</span>
                  <span className="text-[11px] text-slate-400">Google Pixel 9 Pro, MacBook Pro M3</span>
                </div>
              </div>
              <span className="text-xs text-slate-400">2 Active</span>
            </div>
          </div>
        </div>

        {/* SECTION 2: Language & Region */}
        <div className="space-y-1.5">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">Language & Localization</span>
          <div className="ios-glass rounded-2xl border border-white/10 p-3 space-y-2">
            <div className="flex items-center gap-2 mb-1">
              <Languages className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-semibold text-white">App Display Language</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {[
                { code: 'en', label: 'English', sub: 'Default' },
                { code: 'mr', label: 'मराठी (Marathi)', sub: 'महाराष्ट्र' },
                { code: 'hi', label: 'हिन्दी (Hindi)', sub: 'भारत' },
                { code: 'kok', label: 'कोंकणी (Konkani)', sub: 'गोवा / कोकण' },
              ].map(lang => (
                <button
                  key={lang.code}
                  onClick={() => setLanguage(lang.code as any)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    language === lang.code
                      ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-sm'
                      : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-xs font-bold block">{lang.label}</span>
                  <span className="text-[10px] opacity-75">{lang.sub}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* SECTION 3: Storage & Data Management */}
        <div className="space-y-1.5">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">Storage & Data</span>
          <div className="ios-glass rounded-2xl border border-white/10 p-3.5 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <HardDrive className="w-4 h-4 text-cyan-400" />
                Device Storage Used
              </span>
              <span className="font-mono text-cyan-300">1.4 GB / 256 GB</span>
            </div>

            {/* Storage visual progress bar */}
            <div className="h-2 rounded-full bg-white/10 overflow-hidden flex">
              <div className="w-[45%] bg-blue-500" title="Media 630 MB" />
              <div className="w-[25%] bg-purple-500" title="Voice Notes 350 MB" />
              <div className="w-[15%] bg-emerald-500" title="Documents 210 MB" />
              <div className="w-[15%] bg-amber-500" title="Cache 210 MB" />
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500" /> Media (630MB)</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-purple-500" /> Audio (350MB)</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500" /> Docs (210MB)</span>
            </div>
          </div>
        </div>

        {/* SECTION 4: Developer Architecture & Play Store Suite */}
        <div className="space-y-1.5">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">Administration & Architecture</span>
          
          {/* Admin Dashboard & User Management Launcher */}
          <button
            onClick={() => setActiveTab('admin')}
            className="w-full ios-glass-card rounded-2xl p-4 border border-cyan-500/30 flex items-center justify-between text-left hover:border-cyan-400 transition-colors shadow-lg shadow-cyan-950/20 mb-2"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-cyan-600/30">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white">Admin Console & Analytics</h3>
                <p className="text-[11px] text-slate-400">User management, RBAC permissions matrix, system metrics</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-cyan-400" />
          </button>

          <button
            onClick={() => setIsAdminModalOpen(true)}
            className="w-full ios-glass-card rounded-2xl p-4 border border-cyan-500/30 flex items-center justify-between text-left hover:border-cyan-400 transition-colors shadow-lg shadow-cyan-950/20"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 text-white flex items-center justify-center shadow-md shadow-cyan-600/30">
                <Code2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white">Android Source & Firestore Rules</h3>
                <p className="text-[11px] text-slate-400">Jetpack Compose UI, schemas, security rules & APK checklist</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-cyan-400" />
          </button>
        </div>

        {/* SECTION 5: Data Export & Account Actions */}
        <div className="space-y-2 pt-2">
          <button
            onClick={() => setShowExportModal(true)}
            className="w-full py-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-200 flex items-center justify-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>Export Encrypted Account Archive</span>
          </button>

          <button
            onClick={() => {
              if (confirm('Delete Account? All private encryption keys, synced sessions, and media will be permanently deleted.')) {
                alert('Account deletion request initiated under zero-knowledge protocol.');
              }
            }}
            className="w-full py-3 rounded-2xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-xs font-semibold text-rose-400 flex items-center justify-center gap-2 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete Aether Account</span>
          </button>
        </div>
      </div>

      {/* QR Code Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-xs ios-glass-card rounded-3xl p-6 border border-white/20 text-center space-y-4">
            <h3 className="text-base font-bold text-white">My Aether Contact QR</h3>
            <div className="p-4 bg-white rounded-2xl inline-block shadow-xl">
              <img
                src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=aether://user/aayush-dalvi"
                alt="QR Code"
                className="w-44 h-44"
              />
            </div>
            <p className="text-xs text-slate-300">Scan to initiate an end-to-end encrypted session with Aayush Dalvi</p>
            <button
              onClick={() => setShowQrModal(false)}
              className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Export Archive Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-sm ios-glass-card rounded-3xl p-5 border border-white/20 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Download className="w-4 h-4 text-cyan-400" />
              Download Encrypted Archive
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Your backup includes chats, contacts, verification keys, and media links formatted in standard JSON. Passwords and identity seeds are never exported in cleartext.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setShowExportModal(false)}
                className="flex-1 py-2 rounded-xl bg-white/10 text-xs text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleExportData}
                className="flex-1 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
              >
                Confirm Export
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
