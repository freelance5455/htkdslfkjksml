/* ==========================================================================
   MentaleKost - Version autonome, stockage IndexedDB (pas de serveur requis)
   IndexedDB est utilisé (au lieu de localStorage) car localStorage est limité
   à ~5-10 Mo : largement insuffisant pour 15 000+ élèves avec leurs notes.
   IndexedDB n'a pas cette limite et reste rapide grâce à des index par classe
   et par élève (les opérations ne relisent jamais toute la base).
   ========================================================================== */

let SETTINGS = {};

// ---------------- Ouverture / schéma IndexedDB ----------------
const IDB_NAME = 'mentalekost';
const IDB_VERSION = 1;
let dbReadyPromise = null;

const SEED_SUBJECTS = [
  { id: 1, nom: 'Mathématiques', type: 'scientifique', ordre: 1 },
  { id: 2, nom: 'P.C.T', type: 'scientifique', ordre: 2 },
  { id: 3, nom: 'S.V.T', type: 'scientifique', ordre: 3 },
  { id: 4, nom: 'Anglais', type: 'litteraire', ordre: 4 },
  { id: 5, nom: 'Français', type: 'litteraire', ordre: 5 },
  { id: 6, nom: 'Lecture', type: 'litteraire', ordre: 6 },
  { id: 7, nom: 'Communication écrite', type: 'litteraire', ordre: 7 },
  { id: 8, nom: 'Histoire-Géographie', type: 'litteraire', ordre: 8 },
  { id: 9, nom: 'Espagnol', type: 'litteraire', ordre: 9 },
  { id: 10, nom: 'Allemand', type: 'litteraire', ordre: 10 },
  { id: 11, nom: 'Économie', type: 'litteraire', ordre: 11 },
  { id: 12, nom: 'Philosophie', type: 'litteraire', ordre: 12 },
  { id: 13, nom: 'E.P.S', type: 'litteraire', ordre: 13 },
  { id: 14, nom: 'Conduite', type: 'litteraire', ordre: 14 }
];
const DEFAULT_SETTINGS = {
  id: 1,
  school_name: "Nom de l'établissement",
  school_logo: '', benin_logo: '',
  ministere_texte: 'Ministère des Enseignements Secondaire, Technique et de la Formation Professionnelle',
  republique_texte: 'République du Bénin',
  adresse_bp: '', adresse: '', email: '', telephones: '', ifu: '',
  directeur_nom: '', directeur_signature: '', directeur_cachet: '',
  annee_scolaire: '2026-2027'
};

function openDatabase() {
  if (dbReadyPromise) return dbReadyPromise;
  dbReadyPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, IDB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      let settingsStore, subjectsStore;
      if (!db.objectStoreNames.contains('settings')) settingsStore = db.createObjectStore('settings', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('classes')) db.createObjectStore('classes', { keyPath: 'id', autoIncrement: true });
      if (!db.objectStoreNames.contains('subjects')) subjectsStore = db.createObjectStore('subjects', { keyPath: 'id', autoIncrement: true });
      if (!db.objectStoreNames.contains('class_subjects')) {
        const s = db.createObjectStore('class_subjects', { keyPath: 'id', autoIncrement: true });
        s.createIndex('class_id', 'class_id');
      }
      if (!db.objectStoreNames.contains('students')) {
        const s = db.createObjectStore('students', { keyPath: 'id', autoIncrement: true });
        s.createIndex('class_id', 'class_id');
        s.createIndex('matricule', 'matricule');
      }
      if (!db.objectStoreNames.contains('grades')) {
        const s = db.createObjectStore('grades', { keyPath: 'id', autoIncrement: true });
        s.createIndex('student_id', 'student_id');
      }
      // Données de base, uniquement à la toute première création de la base.
      if (e.oldVersion < 1) {
        if (settingsStore) settingsStore.add(DEFAULT_SETTINGS);
        if (subjectsStore) SEED_SUBJECTS.forEach(s => subjectsStore.add(s));
      }
    };
    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror = (e) => reject(e.target.error);
  });
  return dbReadyPromise;
}
function reqToPromise(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function withStore(storeName, mode, fn) {
  const db = await openDatabase();
  const tx = db.transaction([storeName], mode);
  return reqToPromise(fn(tx.objectStore(storeName)));
}
async function idbGetAll(store) { return withStore(store, 'readonly', s => s.getAll()); }
async function idbGet(store, key) { return withStore(store, 'readonly', s => s.get(key)); }
async function idbAdd(store, value) { return withStore(store, 'readwrite', s => s.add(value)); }
async function idbPut(store, value) { return withStore(store, 'readwrite', s => s.put(value)); }
async function idbDelete(store, key) { return withStore(store, 'readwrite', s => s.delete(key)); }
async function idbClear(store) { return withStore(store, 'readwrite', s => s.clear()); }
async function idbCount(store) { return withStore(store, 'readonly', s => s.count()); }
async function idbIndexGetAll(store, indexName, value) {
  const db = await openDatabase();
  const tx = db.transaction([store], 'readonly');
  return reqToPromise(tx.objectStore(store).index(indexName).getAll(value));
}
// Notes d'un élève pour UNE année scolaire précise seulement (jamais les
// autres années : chaque nouvelle année repart à zéro).
async function idbGradesEleveAnnee(studentId, annee) {
  const toutes = await idbIndexGetAll('grades', 'student_id', studentId);
  return toutes.filter(g => g.annee_scolaire === annee);
}
async function idbIndexCount(store, indexName, value) {
  const db = await openDatabase();
  const tx = db.transaction([store], 'readonly');
  return reqToPromise(tx.objectStore(store).index(indexName).count(value));
}

// Les matières changent rarement (liste fixe) : on les garde en mémoire pour
// éviter une lecture IndexedDB à chaque action.
let SUBJECTS_CACHE = null;
async function getSubjects() {
  if (!SUBJECTS_CACHE) SUBJECTS_CACHE = await idbGetAll('subjects');
  return SUBJECTS_CACHE;
}

// ---------------- Règles pédagogiques ----------------
const PREMIER_CYCLE = ['6e', '5e', '4e', '3e'];
const SECOND_CYCLE = ['2nd', '1ere', 'tle'];

// Une matière est-elle valable pour ce niveau ? (Français au 2nd cycle,
// Lecture + Communication écrite au 1er cycle)
function subjectApplicable(niveau, nomMatiere) {
  const mn = nomMatiere.toLowerCase();
  if (mn === 'français') return SECOND_CYCLE.includes(niveau);
  if (mn === 'lecture' || mn === 'communication écrite') return PREMIER_CYCLE.includes(niveau);
  return true;
}

// ---------------- Fonctions de calcul ----------------
function moyenneInterro(i1, i2, i3, i4) {
  const notes = [i1, i2, i3, i4].filter(v => v !== null && v !== undefined && v !== '');
  if (notes.length === 0) return null;
  const somme = notes.reduce((a, b) => a + parseFloat(b), 0);
  return Math.round((somme / notes.length) * 100) / 100;
}
function moyenneSemestrielleMatiere(moyInterro, d1, d2) {
  const comp = [];
  if (moyInterro !== null && moyInterro !== undefined) comp.push(moyInterro);
  if (d1 !== null && d1 !== undefined && d1 !== '') comp.push(parseFloat(d1));
  if (d2 !== null && d2 !== undefined && d2 !== '') comp.push(parseFloat(d2));
  if (comp.length === 0) return null;
  return Math.round((comp.reduce((a, b) => a + b, 0) / comp.length) * 100) / 100;
}
function moyenneAnnuelleGenerale(moyS1, moyS2) {
  if (moyS1 === null && moyS2 === null) return null;
  return Math.round(((2 * (moyS2 || 0) + (moyS1 || 0)) / 3) * 100) / 100;
}
function appreciationMoyenne(m) {
  if (m === null || m === undefined) return '';
  if (m >= 19) return 'Excellent';
  if (m >= 16) return 'Très Bien';
  if (m >= 14) return 'Bien';
  if (m >= 12) return 'Assez Bien';
  if (m >= 10) return 'Passable';
  if (m >= 6.5) return 'Insuffisant';
  return 'Médiocre';
}
function decisionAdmission(moyAnnuelle) {
  if (moyAnnuelle === null || moyAnnuelle === undefined) return '';
  return moyAnnuelle >= 10 ? 'Admis(e) en classe supérieure' : 'Non admis(e)';
}
// Coefficients par défaut. Pour les séries A et B du 2nd cycle, une valeur par
// défaut (2) est posée : ajuste-la précisément dans Paramètres > Coefficients.
function coefficientParDefaut(niveau, serie, matiereNom, type) {
  const mn = matiereNom.toLowerCase();
  if (mn === 'conduite') return 1;
  if (niveau === '6e' || niveau === '5e') return 1;
  if (niveau === '4e' || niveau === '3e') return 2;
  const estFrOuHG = mn.includes('français') || mn.includes('histoire');
  if (niveau === '2nd' && (serie === 'C' || serie === 'D')) {
    if (estFrOuHG) return 1;
    return type === 'scientifique' ? 3 : 2;
  }
  if ((niveau === '1ere' || niveau === 'tle') && (serie === 'C' || serie === 'D')) {
    if (mn.includes('mathématiques')) return 6;
    if (mn.includes('p.c.t')) return 5;
    if (mn.includes('s.v.t')) return 2;
    if (mn.includes('histoire')) return 1;
    return 2;
  }
  if (mn.includes('e.p.s')) return 1;
  return 2;
}

// Échappement pour éviter qu'un nom/texte saisi casse l'affichage HTML.
function esc(v) {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ---------------- Couche "API" locale ----------------
function fileToDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
async function apiGet(action, params = {}) { return handleAction(action, params); }
async function apiPost(action, formData) {
  const params = {};
  for (const [k, v] of formData.entries()) {
    params[k] = (v instanceof File) ? (v.size > 0 ? await fileToDataURL(v) : '') : v;
  }
  return handleAction(action, params);
}
function toFD(obj) {
  const fd = new FormData();
  Object.entries(obj).forEach(([k, v]) => { if (v !== undefined && v !== null) fd.append(k, v); });
  return fd;
}

// Moyenne générale d'un élève à un semestre donné, à partir de SES notes déjà
// chargées (gradesList) et des matières de SA classe déjà chargées (csList).
// Ne relit rien en base : utilisable en boucle sur tout un effectif de classe.
function calculerMoyenneDepuisDonnees(semestre, csList, gradesList) {
  let sommeCoefMoy = 0, sommeCoef = 0;
  csList.forEach(c => {
    const g = gradesList.find(g => g.subject_id === c.subject_id && g.semestre == semestre);
    if (!g) return;
    const mi = moyenneInterro(g.interro1, g.interro2, g.interro3, g.interro4);
    const mt = moyenneSemestrielleMatiere(mi, g.devoir1, g.devoir2);
    if (mt !== null) { sommeCoefMoy += mt * c.coefficient; sommeCoef += parseFloat(c.coefficient); }
  });
  return sommeCoef > 0 ? Math.round((sommeCoefMoy / sommeCoef) * 100) / 100 : null;
}

function calculerLignesSemestre(semestre, csList, gradesList) {
  let sommeCoefMoy = 0, sommeCoef = 0;
  const lignes = csList.map(c => {
    const g = gradesList.find(g => g.subject_id === c.subject_id && g.semestre == semestre) || {};
    const mi = moyenneInterro(g.interro1, g.interro2, g.interro3, g.interro4);
    const mt = moyenneSemestrielleMatiere(mi, g.devoir1, g.devoir2);
    if (mt !== null) { sommeCoefMoy += mt * c.coefficient; sommeCoef += parseFloat(c.coefficient); }
    const mc = mt !== null ? Math.round(mt * c.coefficient * 100) / 100 : null;
    return {
      matiere: c.matiere, coefficient: c.coefficient,
      interro1: g.interro1 ?? null, interro2: g.interro2 ?? null, interro3: g.interro3 ?? null, interro4: g.interro4 ?? null,
      moyenne_interro: mi, devoir1: g.devoir1 ?? null, devoir2: g.devoir2 ?? null,
      moyenne_semestrielle: mt, moyenne_coefficiee: mc, appreciation: appreciationMoyenne(mt)
    };
  });
  const moyGen = sommeCoef > 0 ? Math.round((sommeCoefMoy / sommeCoef) * 100) / 100 : null;
  return { lignes, sommeCoefMoy, sommeCoef, moyGen };
}

async function genererBulletin(studentId, semestre) {
  const student = await idbGet('students', parseInt(studentId));
  if (!student) return { error: 'Élève introuvable' };
  const classe = await idbGet('classes', student.class_id);
  const subjects = await getSubjects();
  const subjectMap = new Map(subjects.map(s => [s.id, s]));
  const classSubjectsRaw = await idbIndexGetAll('class_subjects', 'class_id', student.class_id);
  const csList = classSubjectsRaw
    .map(c => ({ ...c, matiere: subjectMap.get(c.subject_id)?.nom || '' }))
    .sort((a, b) => (subjectMap.get(a.subject_id)?.ordre || 0) - (subjectMap.get(b.subject_id)?.ordre || 0));

  const studentGrades = await idbGradesEleveAnnee(student.id, student.annee_scolaire);
  const current = calculerLignesSemestre(semestre, csList, studentGrades);
  const lignesRemplies = current.lignes.filter(l => l.moyenne_semestrielle !== null);

  const classmates = (await idbIndexGetAll('students', 'class_id', student.class_id)).filter(s => s.abandon === 'non');
  const classmatesGrades = await Promise.all(classmates.map(cm => idbGradesEleveAnnee(cm.id, cm.annee_scolaire)));

  const moyennesClasseTrim = {};
  classmates.forEach((cm, idx) => {
    const mg = calculerMoyenneDepuisDonnees(semestre, csList, classmatesGrades[idx]);
    if (mg !== null) moyennesClasseTrim[cm.id] = mg;
  });
  const classement = Object.entries(moyennesClasseTrim).sort((a, b) => b[1] - a[1]);
  const rangIndex = classement.findIndex(([id]) => id == studentId);
  const valeurs = Object.values(moyennesClasseTrim);

  const result = {
    student: { ...student, classe_nom: classe?.nom || '' },
    lignes: lignesRemplies,
    total_points: Math.round(current.sommeCoefMoy * 100) / 100,
    total_coefficients: current.sommeCoef,
    moyenne_generale: current.moyGen,
    appreciation_generale: appreciationMoyenne(current.moyGen),
    rang: rangIndex >= 0 ? rangIndex + 1 : null, effectif: classmates.length,
    moyenne_plus_forte: valeurs.length ? Math.max(...valeurs) : null,
    moyenne_plus_faible: valeurs.length ? Math.min(...valeurs) : null,
    semestre
  };

  if (semestre == 2) {
    const s1 = calculerLignesSemestre(1, csList, studentGrades);
    const moyAnnuelle = moyenneAnnuelleGenerale(s1.moyGen, current.moyGen);
    result.moyenne_generale_t1 = s1.moyGen;
    result.moyenne_annuelle = moyAnnuelle;
    result.decision = decisionAdmission(moyAnnuelle);
    result.appreciation_annuelle = appreciationMoyenne(moyAnnuelle);

    const moyennesAnnuelles = {};
    classmates.forEach((cm, idx) => {
      const mS1 = calculerMoyenneDepuisDonnees(1, csList, classmatesGrades[idx]);
      const mS2 = calculerMoyenneDepuisDonnees(2, csList, classmatesGrades[idx]);
      const ma = moyenneAnnuelleGenerale(mS1, mS2);
      if (ma !== null) moyennesAnnuelles[cm.id] = ma;
    });
    const classementAnnuel = Object.entries(moyennesAnnuelles).sort((a, b) => b[1] - a[1]);
    const rangAnnuelIndex = classementAnnuel.findIndex(([id]) => id == studentId);
    const valeursAnnuelles = Object.values(moyennesAnnuelles);
    result.rang_annuel = rangAnnuelIndex >= 0 ? rangAnnuelIndex + 1 : null;
    result.moyenne_annuelle_plus_forte = valeursAnnuelles.length ? Math.max(...valeursAnnuelles) : null;
    result.moyenne_annuelle_plus_faible = valeursAnnuelles.length ? Math.min(...valeursAnnuelles) : null;
  }
  return result;
}

// Classement de toute une classe (1er au dernier) pour un semestre donné,
// ou "annuel" pour le classement sur la moyenne des 3 semestres.
async function genererBilanClasse(classId, semestre) {
  classId = parseInt(classId);
  const classe = await idbGet('classes', classId);
  if (!classe) return { error: 'Classe introuvable' };
  const subjects = await getSubjects();
  const subjectMap = new Map(subjects.map(s => [s.id, s]));
  const csList = (await idbIndexGetAll('class_subjects', 'class_id', classId))
    .map(c => ({ ...c, matiere: subjectMap.get(c.subject_id)?.nom || '' }));

  const students = (await idbIndexGetAll('students', 'class_id', classId)).filter(s => s.abandon === 'non');
  const gradesByStudent = await Promise.all(students.map(s => idbGradesEleveAnnee(s.id, s.annee_scolaire)));

  const lignes = students.map((s, idx) => {
    let moyenne;
    if (semestre === 'annuel') {
      const m1 = calculerMoyenneDepuisDonnees(1, csList, gradesByStudent[idx]);
      const m2 = calculerMoyenneDepuisDonnees(2, csList, gradesByStudent[idx]);
      moyenne = moyenneAnnuelleGenerale(m1, m2);
    } else {
      moyenne = calculerMoyenneDepuisDonnees(parseInt(semestre), csList, gradesByStudent[idx]);
    }
    return { student_id: s.id, matricule: s.matricule, nom: s.nom, prenoms: s.prenoms, moyenne, appreciation: appreciationMoyenne(moyenne) };
  });

  // Seuls les élèves ayant au moins une moyenne calculable sont classés ; les
  // autres apparaissent en bas de liste, non classés.
  const classes_ = lignes.filter(l => l.moyenne !== null).sort((a, b) => b.moyenne - a.moyenne);
  const nonClasses = lignes.filter(l => l.moyenne === null);
  classes_.forEach((l, i) => { l.rang = i + 1; });
  nonClasses.forEach(l => { l.rang = null; });

  return {
    classe_nom: classe.nom, effectif: students.length, semestre,
    lignes: [...classes_, ...nonClasses]
  };
}

async function handleAction(action, p) {
  switch (action) {

    case 'get_settings': {
      const s = await idbGet('settings', 1);
      return s || DEFAULT_SETTINGS;
    }

    case 'save_settings': {
      const current = (await idbGet('settings', 1)) || { ...DEFAULT_SETTINGS };
      Object.keys(p).forEach(k => {
        if (k === 'action' || k === 'app_name' || k === 'app_logo') return;
        if (p[k] !== '') current[k] = p[k];
      });
      current.id = 1;
      await idbPut('settings', current);
      return { success: true };
    }

    case 'list_classes': {
      let classes = await idbGetAll('classes');
      if (p.annee) classes = classes.filter(c => c.annee_scolaire === p.annee);
      const withEffectif = await Promise.all(classes.map(async c => ({
        ...c, effectif: await idbIndexCount('students', 'class_id', c.id)
      })));
      return withEffectif.sort((a, b) => (b.annee_scolaire || '').localeCompare(a.annee_scolaire || '') || a.niveau.localeCompare(b.niveau) || a.nom.localeCompare(b.nom));
    }

    case 'add_class': {
      if (!p.nom || !p.nom.trim()) return { error: 'Nom de classe requis' };
      const classId = await idbAdd('classes', { nom: p.nom.trim(), niveau: p.niveau, serie: p.serie || null, annee_scolaire: p.annee_scolaire });
      const subjects = await getSubjects();
      await Promise.all(subjects.filter(m => subjectApplicable(p.niveau, m.nom)).map(m => {
        const coef = coefficientParDefaut(p.niveau, p.serie || null, m.nom, m.type);
        if (coef > 0) return idbAdd('class_subjects', { class_id: classId, subject_id: m.id, coefficient: coef });
      }));
      return { success: true, id: classId };
    }

    case 'delete_class': {
      const id = parseInt(p.id);
      const students = await idbIndexGetAll('students', 'class_id', id);
      for (const s of students) {
        const grades = await idbIndexGetAll('grades', 'student_id', s.id);
        await Promise.all(grades.map(g => idbDelete('grades', g.id)));
      }
      await Promise.all(students.map(s => idbDelete('students', s.id)));
      const cs = await idbIndexGetAll('class_subjects', 'class_id', id);
      await Promise.all(cs.map(c => idbDelete('class_subjects', c.id)));
      await idbDelete('classes', id);
      return { success: true };
    }

    case 'reset_annee': {
      // Repartir à zéro : vide classes, élèves, notes, coefficients (vidage en bloc, rapide même avec beaucoup de données).
      await Promise.all([idbClear('grades'), idbClear('students'), idbClear('class_subjects'), idbClear('classes')]);
      return { success: true };
    }

    case 'list_subjects': {
      const subjects = await getSubjects();
      return [...subjects].sort((a, b) => a.ordre - b.ordre);
    }

    case 'get_class_subjects': {
      const classId = parseInt(p.class_id);
      const rows = await idbIndexGetAll('class_subjects', 'class_id', classId);
      const subjects = await getSubjects();
      const subjectMap = new Map(subjects.map(s => [s.id, s]));
      return rows.map(c => ({ id: c.id, subject_id: c.subject_id, nom: subjectMap.get(c.subject_id)?.nom || '', coefficient: c.coefficient }))
        .sort((a, b) => (subjectMap.get(a.subject_id)?.ordre || 0) - (subjectMap.get(b.subject_id)?.ordre || 0));
    }

    case 'save_class_subject': {
      const row = await idbGet('class_subjects', parseInt(p.id));
      if (row) { row.coefficient = parseFloat(p.coefficient); await idbPut('class_subjects', row); }
      return { success: true };
    }

    case 'list_students': {
      const classId = parseInt(p.class_id);
      const students = await idbIndexGetAll('students', 'class_id', classId);
      return students.sort((a, b) => a.nom.localeCompare(b.nom) || a.prenoms.localeCompare(b.prenoms));
    }

    case 'search_students': {
      const q = (p.q || '').toLowerCase();
      if (!q) return [];
      const [all, classes] = await Promise.all([idbGetAll('students'), idbGetAll('classes')]);
      const classMap = new Map(classes.map(c => [c.id, c.nom]));
      const out = [];
      for (const s of all) {
        if (s.nom.toLowerCase().includes(q) || s.prenoms.toLowerCase().includes(q) || s.matricule.toLowerCase().includes(q)) {
          out.push({ ...s, classe_nom: classMap.get(s.class_id) || '' });
          if (out.length >= 100) break;
        }
      }
      return out;
    }

    case 'get_student': return idbGet('students', parseInt(p.id));

    case 'add_student': {
      if (!p.matricule || !p.matricule.trim()) return { error: 'Matricule requis' };
      const existing = await idbIndexGetAll('students', 'matricule', p.matricule.trim());
      if (existing.length > 0) return { error: `Le matricule "${p.matricule}" est déjà utilisé par un autre élève.` };
      const id = await idbAdd('students', {
        matricule: p.matricule.trim(), nom: p.nom, prenoms: p.prenoms,
        date_naissance: p.date_naissance || null, lieu_naissance: p.lieu_naissance || '',
        sexe: p.sexe || 'M', photo: p.photo || '', class_id: parseInt(p.class_id),
        redoublant: p.redoublant || 'non', abandon: p.abandon || 'non', annee_scolaire: p.annee_scolaire
      });
      return { success: true, id };
    }

    case 'update_student': {
      const s = await idbGet('students', parseInt(p.id));
      if (!s) return { error: 'Élève introuvable' };
      if (p.matricule && p.matricule.trim() !== s.matricule) {
        const existing = await idbIndexGetAll('students', 'matricule', p.matricule.trim());
        if (existing.some(e => e.id !== s.id)) return { error: `Le matricule "${p.matricule}" est déjà utilisé par un autre élève.` };
      }
      Object.assign(s, {
        matricule: (p.matricule || s.matricule).trim(), nom: p.nom, prenoms: p.prenoms,
        date_naissance: p.date_naissance || null, lieu_naissance: p.lieu_naissance || '',
        sexe: p.sexe || 'M', class_id: parseInt(p.class_id),
        redoublant: p.redoublant || 'non', abandon: p.abandon || 'non'
      });
      if (p.photo) s.photo = p.photo;
      await idbPut('students', s);
      return { success: true };
    }

    case 'delete_student': {
      const id = parseInt(p.id);
      const grades = await idbIndexGetAll('grades', 'student_id', id);
      await Promise.all(grades.map(g => idbDelete('grades', g.id)));
      await idbDelete('students', id);
      return { success: true };
    }

    case 'get_grades': {
      const student = await idbGet('students', parseInt(p.student_id));
      if (!student) return [];
      const subjects = await getSubjects();
      const subjectMap = new Map(subjects.map(s => [s.id, s]));
      const cs = (await idbIndexGetAll('class_subjects', 'class_id', student.class_id))
        .map(c => ({ ...c, matiere: subjectMap.get(c.subject_id)?.nom || '', ordre: subjectMap.get(c.subject_id)?.ordre || 0 }))
        .sort((a, b) => a.ordre - b.ordre);
      const grades = await idbGradesEleveAnnee(student.id, student.annee_scolaire);
      return cs.map(c => {
        const g = grades.find(g => g.subject_id === c.subject_id && g.semestre == p.semestre) || {};
        const mi = moyenneInterro(g.interro1, g.interro2, g.interro3, g.interro4);
        const mt = moyenneSemestrielleMatiere(mi, g.devoir1, g.devoir2);
        const mc = mt !== null ? Math.round(mt * c.coefficient * 100) / 100 : null;
        return {
          subject_id: c.subject_id, matiere: c.matiere, coefficient: c.coefficient,
          interro1: g.interro1 ?? null, interro2: g.interro2 ?? null, interro3: g.interro3 ?? null, interro4: g.interro4 ?? null,
          moyenne_interro: mi, devoir1: g.devoir1 ?? null, devoir2: g.devoir2 ?? null,
          moyenne_semestrielle: mt, moyenne_coefficiee: mc, appreciation: appreciationMoyenne(mt)
        };
      });
    }

    case 'save_grade': {
      const n = k => (p[k] === '' || p[k] === undefined) ? null : parseFloat(p[k]);
      const studentId = parseInt(p.student_id), subjectId = parseInt(p.subject_id), semestre = parseInt(p.semestre);
      const existing = await idbGradesEleveAnnee(studentId, p.annee_scolaire);
      let g = existing.find(g => g.subject_id === subjectId && g.semestre === semestre);
      if (!g) g = { student_id: studentId, subject_id: subjectId, semestre, annee_scolaire: p.annee_scolaire };
      Object.assign(g, { interro1: n('interro1'), interro2: n('interro2'), interro3: n('interro3'), interro4: n('interro4'), devoir1: n('devoir1'), devoir2: n('devoir2') });
      await idbPut('grades', g);
      return { success: true };
    }

    case 'get_bulletin': return genererBulletin(p.student_id, p.semestre);

    case 'bilan_classe': return genererBilanClasse(p.class_id, p.semestre);

    case 'dashboard_stats': {
      const [eleves, classes] = await Promise.all([idbCount('students'), idbCount('classes')]);
      return { eleves, classes };
    }

    default: return { error: 'Action inconnue' };
  }
}

// ---------------- Navigation ----------------
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => goTo(btn.dataset.page));
});
const PAGE_LABELS = {"dashboard": "Accueil", "classes": "Classes", "students": "Élèves", "grades": "Notes", "bulletin": "Bulletin", "classement": "Classement", "settings": "Réglages"};
function goTo(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  const pt = document.getElementById('page-title'); if (pt) pt.textContent = PAGE_LABELS[page] || '';
  window.scrollTo(0, 0);
  document.querySelector(`.nav-btn[data-page="${page}"]`).classList.add('active');
  if (page === 'dashboard') loadDashboard();
  if (page === 'classes') loadClasses();
  if (page === 'students') { loadClassOptions('student-classe-filter'); loadStudentsTable(); }
  if (page === 'grades') loadClassOptions('grades-classe');
  if (page === 'bulletin') loadClassOptions('bulletin-classe');
  if (page === 'classement') loadClassOptions('classement-classe');
  if (page === 'settings') { loadSettingsForm(); loadClassOptions('coef-classe'); majStatutOtp(); }
}

// ---------------- Paramètres (annee scolaire chargée au démarrage) ----------------
async function loadGlobalSettings() {
  SETTINGS = await apiGet('get_settings');
  document.getElementById('dash-annee').textContent = SETTINGS.annee_scolaire || '';
}

// ---------------- Dashboard ----------------
async function loadDashboard() {
  const stats = await apiGet('dashboard_stats', {});
  document.getElementById('stat-eleves').textContent = stats.eleves ?? 0;
  document.getElementById('stat-classes').textContent = stats.classes ?? 0;
}
// ---------------- Passage en classe supérieure (fin d'année) — 100% automatique ----------------
// Niveau suivant pour chaque niveau (null = fin de cursus, pas de classe suivante).
const NIVEAU_SUIVANT = { '6e': '5e', '5e': '4e', '4e': '3e', '3e': '2nd', '2nd': '1ere', '1ere': 'tle', 'tle': null };
const NIVEAU_LABEL = { '6e': '6ème', '5e': '5ème', '4e': '4ème', '3e': '3ème', '2nd': '2nde', '1ere': '1ère', 'tle': 'Tle' };
const NIVEAU_VARIANTES = {
  '6e': ['6ème', '6eme', '6e'], '5e': ['5ème', '5eme', '5e'], '4e': ['4ème', '4eme', '4e'], '3e': ['3ème', '3eme', '3e'],
  '2nd': ['2nde', '2nd'], '1ere': ['1ère', '1ere'], 'tle': ['terminale', 'tle']
};
function nomClasseParDefaut(niveau, serie) { return NIVEAU_LABEL[niveau] + (serie ? ' ' + serie : ''); }

// Déduit automatiquement le nom de la classe de destination à partir du nom
// actuel (ex: "6eme M1" -> "5eme M1", "2nd C1" -> "1ere C1").
function genererNomClasseSuivante(nomActuel, niveauActuel, niveauSuivant) {
  const variantesActuelles = [...(NIVEAU_VARIANTES[niveauActuel] || [])].sort((a, b) => b.length - a.length);
  const nouveauToken = (NIVEAU_VARIANTES[niveauSuivant] || [niveauSuivant])[0];
  for (const variante of variantesActuelles) {
    const regex = new RegExp(variante.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    if (regex.test(nomActuel)) return nomActuel.replace(regex, nouveauToken);
  }
  return nomClasseParDefaut(niveauSuivant, null);
}

async function calculerMoyenneAnnuelleEtudiant(csList, studentId, anneeActuelle) {
  const grades = await idbGradesEleveAnnee(studentId, anneeActuelle);
  const m1 = calculerMoyenneDepuisDonnees(1, csList, grades);
  const m2 = calculerMoyenneDepuisDonnees(2, csList, grades);
  return moyenneAnnuelleGenerale(m1, m2);
}

// Calcule le plan de promotion sans rien modifier (aperçu). 100% automatique.
async function calculerPlanPromotion(nouvelleAnnee) {
  const anneeActuelle = SETTINGS.annee_scolaire;
  const toutesClasses = await idbGetAll('classes');
  const classesActuelles = toutesClasses.filter(c => c.annee_scolaire === anneeActuelle);
  const classesNouvelleAnnee = toutesClasses.filter(c => c.annee_scolaire === nouvelleAnnee);
  const subjects = await getSubjects();
  const subjectMap = new Map(subjects.map(s => [s.id, s]));

  const plan = [];

  for (const classe of classesActuelles) {
    const csList = (await idbIndexGetAll('class_subjects', 'class_id', classe.id))
      .map(c => ({ ...c, matiere: subjectMap.get(c.subject_id)?.nom || '' }));
    const eleves = (await idbIndexGetAll('students', 'class_id', classe.id)).filter(s => s.abandon === 'non');

    for (const eleve of eleves) {
      const moyenne = await calculerMoyenneAnnuelleEtudiant(csList, eleve.id, anneeActuelle);
      const admis = moyenne !== null && moyenne >= 10;
      const entry = { student: eleve, classeActuelle: classe, moyenne, admis };

      if (!admis) {
        entry.decision = 'redouble';
        entry.destinationNiveau = classe.niveau;
        entry.destinationSerie = classe.serie;
        const existe = classesNouvelleAnnee.find(c => c.nom === classe.nom && c.niveau === classe.niveau && c.serie === classe.serie);
        entry.destinationClasseId = existe ? existe.id : null;
        entry.destinationNom = classe.nom;
      } else {
        const niveauSuivant = NIVEAU_SUIVANT[classe.niveau];
        if (!niveauSuivant) {
          entry.decision = 'diplome';
        } else {
          entry.decision = 'promu';
          entry.destinationNiveau = niveauSuivant;
          entry.destinationSerie = classe.serie || null;
          const nomAuto = genererNomClasseSuivante(classe.nom, classe.niveau, niveauSuivant);
          const cible = classesNouvelleAnnee.find(c => c.niveau === niveauSuivant && c.serie === (classe.serie || null) && c.nom === nomAuto)
            || classesNouvelleAnnee.find(c => c.niveau === niveauSuivant && c.serie === (classe.serie || null));
          entry.destinationClasseId = cible ? cible.id : null;
          entry.destinationNom = cible ? cible.nom : nomAuto;
        }
      }
      entry.destinationNomAffiche = entry.decision === 'diplome' ? 'Diplômé(e)' : (entry.destinationClasseId ? entry.destinationNom : `${entry.destinationNom} (sera créée)`);
      plan.push(entry);
    }
  }
  return plan;
}

// Applique le plan : crée les classes manquantes, déplace les élèves. Aucune
// étape manuelle.
async function appliquerPlanPromotion(plan, nouvelleAnnee) {
  const classeCache = new Map();

  async function obtenirOuCreerClasse(niveau, serie, nom) {
    const cle = `${niveau}|${serie || ''}|${nom}`;
    if (classeCache.has(cle)) return classeCache.get(cle);
    const toutes = await idbGetAll('classes');
    let classe = toutes.find(c => c.annee_scolaire === nouvelleAnnee && c.niveau === niveau && c.serie === (serie || null) && c.nom === nom);
    if (!classe) {
      const id = await idbAdd('classes', { nom, niveau, serie: serie || null, annee_scolaire: nouvelleAnnee });
      const subjects = await getSubjects();
      await Promise.all(subjects.filter(m => subjectApplicable(niveau, m.nom)).map(m => {
        const coef = coefficientParDefaut(niveau, serie || null, m.nom, m.type);
        if (coef > 0) return idbAdd('class_subjects', { class_id: id, subject_id: m.id, coefficient: coef });
      }));
      classe = { id };
    }
    classeCache.set(cle, classe.id);
    return classe.id;
  }

  let compteurs = { promus: 0, redoublants: 0, diplomes: 0 };

  for (const entry of plan) {
    const s = entry.student;
    if (entry.decision === 'diplome') {
      compteurs.diplomes++;
      s.diplome = true;
      await idbPut('students', s);
      continue;
    }
    const destId = entry.destinationClasseId || await obtenirOuCreerClasse(entry.destinationNiveau, entry.destinationSerie, entry.destinationNom);
    s.class_id = destId;
    s.annee_scolaire = nouvelleAnnee;
    s.redoublant = entry.decision === 'redouble' ? 'oui' : 'non';
    await idbPut('students', s);
    if (entry.decision === 'redouble') compteurs.redoublants++; else compteurs.promus++;
  }
  return compteurs;
}

document.getElementById('btn-passage-superieur').addEventListener('click', async () => {
  const nouvelleAnnee = prompt("Clôturer l'année scolaire en cours.\nLes classes de l'année suivante seront créées automatiquement et les élèves y seront placés directement (admis en classe supérieure, non admis redoublent).\n\nNom de la nouvelle année scolaire (ex: 2027-2028) :", '');
  if (!nouvelleAnnee || !nouvelleAnnee.trim()) return;
  if (nouvelleAnnee.trim() === SETTINGS.annee_scolaire) { alert("Le nom de la nouvelle année doit être différent de l'année en cours."); return; }

  const btn = document.getElementById('btn-passage-superieur');
  btn.disabled = true; btn.textContent = '⏳ Calcul en cours...';
  let plan;
  try {
    plan = await calculerPlanPromotion(nouvelleAnnee.trim());
  } finally {
    btn.disabled = false; btn.textContent = "🎓 Clôturer l'année scolaire";
  }

  if (plan.length === 0) { alert("Aucun élève trouvé dans les classes de l'année en cours."); return; }

  const promus = plan.filter(e => e.decision === 'promu').length;
  const redoublants = plan.filter(e => e.decision === 'redouble').length;
  const diplomes = plan.filter(e => e.decision === 'diplome').length;

  const message = `Aperçu du passage vers "${nouvelleAnnee.trim()}" (${plan.length} élèves) :\n\n` +
    `✅ Admis, déplacés en classe supérieure : ${promus}\n` +
    `🔁 Non admis, redoublent : ${redoublants}\n` +
    `🎓 Terminale validée (fin de cursus) : ${diplomes}\n\n` +
    `Toutes les classes nécessaires seront créées automatiquement. Les notes de l'année en cours ne seront PAS reprises : chaque élève repart de zéro. Confirmer ?`;

  if (!confirm(message)) return;

  btn.disabled = true; btn.textContent = '⏳ Application en cours...';
  let compteurs;
  try {
    compteurs = await appliquerPlanPromotion(plan, nouvelleAnnee.trim());
    await apiPost('save_settings', toFD({ annee_scolaire: nouvelleAnnee.trim() }));
    await loadGlobalSettings();
    loadDashboard();
  } finally {
    btn.disabled = false; btn.textContent = "🎓 Clôturer l'année scolaire";
  }
  alert(`Terminé ! Promus : ${compteurs.promus} | Redoublants : ${compteurs.redoublants} | Diplômés : ${compteurs.diplomes}\n\nLes classes de l'année précédente restent consultables dans l'onglet Classes (archives).`);
});

// ---------------- Classes ----------------
async function loadClasses() {
  // La page Classes affiche TOUTES les années (c'est aussi la vue "archives") :
  // aucune classe n'est jamais cachée ici, même après un passage à l'année supérieure.
  const classes = await apiGet('list_classes', {});
  const tbody = document.querySelector('#table-classes tbody');
  tbody.innerHTML = '';
  classes.forEach(c => {
    const estAnneeActuelle = c.annee_scolaire === SETTINGS.annee_scolaire;
    const tr = document.createElement('tr');
    if (!estAnneeActuelle) tr.style.opacity = '0.65';
    tr.innerHTML = `<td data-label="Classe"><strong>${esc(c.nom)}</strong></td><td data-label="Niveau">${esc(c.niveau)}</td><td data-label="Série">${esc(c.serie) || '-'}</td>
      <td data-label="Année">${esc(c.annee_scolaire)}${estAnneeActuelle ? '' : ' <span class="hint">(archive)</span>'}</td>
      <td data-label="Effectif">${c.effectif}</td>
      <td>
        <button class="btn small" onclick="goToEleves(${c.id})">👥 Élèves</button>
        <button class="btn small secondary" onclick="goToCoef(${c.id})">Coef.</button>
        <button class="btn small danger" onclick="deleteClasse(${c.id})">Suppr.</button>
      </td>`;
    tbody.appendChild(tr);
  });
}
// Fonctionne aussi pour une classe d'une année archivée (pas seulement l'année en cours).
async function goToEleves(classId) {
  goTo('students');
  const sel = document.getElementById('student-classe-filter');
  if (![...sel.options].some(o => o.value == classId)) {
    const classe = await idbGet('classes', classId);
    const opt = document.createElement('option');
    opt.value = classId;
    opt.textContent = `${classe.nom} (${classe.annee_scolaire})`;
    sel.appendChild(opt);
  }
  sel.value = classId;
  document.getElementById('student-search').value = '';
  loadStudentsTable();
}
async function goToCoef(classId) {
  goTo('settings');
  await loadClassOptions('coef-classe');
  document.getElementById('coef-classe').value = classId;
  loadCoefTable(classId);
}
async function deleteClasse(id) {
  if (!confirm('Supprimer cette classe et tous ses élèves ? (cela peut prendre quelques secondes pour une grande classe)')) return;
  await apiPost('delete_class', toFD({ id }));
  loadClasses();
}
document.getElementById('btn-add-classe').addEventListener('click', async () => {
  const nom = document.getElementById('new-classe-nom').value.trim();
  const niveau = document.getElementById('new-niveau').value;
  const serie = document.getElementById('new-serie').value;
  if (!nom) return alert('Indique un nom de classe.');
  const res = await apiPost('add_class', toFD({ nom, niveau, serie, annee_scolaire: SETTINGS.annee_scolaire }));
  if (res.error) return alert(res.error);
  document.getElementById('new-classe-nom').value = '';
  loadClasses();
});

async function loadClassOptions(selectId) {
  const classes = await apiGet('list_classes', { annee: SETTINGS.annee_scolaire });
  const sel = document.getElementById(selectId);
  const current = sel.value;
  sel.innerHTML = '<option value="">-- Choisir une classe --</option>' +
    classes.map(c => `<option value="${c.id}">${esc(c.nom)}</option>`).join('');
  sel.value = current;
}

// ---------------- Élèves ----------------
document.getElementById('student-classe-filter').addEventListener('change', loadStudentsTable);
document.getElementById('student-search').addEventListener('input', loadStudentsTable);

async function loadStudentsTable() {
  const classId = document.getElementById('student-classe-filter').value;
  const search = document.getElementById('student-search').value.trim();
  let students = [];
  if (search) students = await apiGet('search_students', { q: search });
  else if (classId) students = await apiGet('list_students', { class_id: classId });
  const tbody = document.querySelector('#table-students tbody');
  tbody.innerHTML = '';
  students.forEach(s => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td data-label="Matricule">${esc(s.matricule)}</td><td data-label="Nom"><strong>${esc(s.nom)}</strong></td><td data-label="Prénoms">${esc(s.prenoms)}</td><td data-label="Classe">${esc(s.classe_nom) || ''}</td>
      <td data-label="Redoublant">${esc(s.redoublant)}</td><td data-label="Abandon">${esc(s.abandon)}</td>
      <td><button class="btn small" onclick="editStudent(${s.id})">Modifier</button>
      <button class="btn small danger" onclick="deleteStudent(${s.id})">Suppr.</button></td>`;
    tbody.appendChild(tr);
  });
}
async function deleteStudent(id) {
  if (!confirm('Supprimer cet élève ?')) return;
  await apiPost('delete_student', toFD({ id }));
  loadStudentsTable();
}
document.getElementById('btn-new-student').addEventListener('click', async () => {
  const classes = await apiGet('list_classes', { annee: SETTINGS.annee_scolaire });
  if (!classes.length) {
    alert("Aucune classe n'existe encore pour l'année en cours. Va d'abord dans l'onglet \"Classes\" pour en créer une, puis reviens ici.");
    return;
  }
  document.getElementById('form-student').reset();
  document.getElementById('s-id').value = '';
  document.getElementById('student-form-title').textContent = 'Nouvel élève';
  await fillClasseSelect('s-classe');
  document.getElementById('modal-student').classList.add('active');
});
async function editStudent(id) {
  const s = await apiGet('get_student', { id });
  if (!s) return alert('Élève introuvable.');
  document.getElementById('student-form-title').textContent = 'Modifier élève';
  document.getElementById('s-id').value = s.id;
  document.getElementById('s-matricule').value = s.matricule;
  document.getElementById('s-nom').value = s.nom;
  document.getElementById('s-prenoms').value = s.prenoms;
  document.getElementById('s-date-naissance').value = s.date_naissance || '';
  document.getElementById('s-lieu-naissance').value = s.lieu_naissance || '';
  document.getElementById('s-sexe').value = s.sexe;
  document.getElementById('s-redoublant').value = s.redoublant;
  document.getElementById('s-abandon').value = s.abandon;
  await fillClasseSelect('s-classe');
  document.getElementById('s-classe').value = s.class_id;
  document.getElementById('modal-student').classList.add('active');
}
async function fillClasseSelect(id) {
  const classes = await apiGet('list_classes', { annee: SETTINGS.annee_scolaire });
  document.getElementById(id).innerHTML = '<option value="" disabled selected>-- Choisir une classe --</option>' +
    classes.map(c => `<option value="${c.id}">${esc(c.nom)} (${esc(c.niveau)}${c.serie ? ' ' + esc(c.serie) : ''})</option>`).join('');
}
document.getElementById('btn-close-student').addEventListener('click', () => document.getElementById('modal-student').classList.remove('active'));
document.getElementById('form-student').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData();
  const id = document.getElementById('s-id').value;
  fd.append('matricule', document.getElementById('s-matricule').value);
  fd.append('nom', document.getElementById('s-nom').value);
  fd.append('prenoms', document.getElementById('s-prenoms').value);
  fd.append('date_naissance', document.getElementById('s-date-naissance').value);
  fd.append('lieu_naissance', document.getElementById('s-lieu-naissance').value);
  fd.append('sexe', document.getElementById('s-sexe').value);
  fd.append('class_id', document.getElementById('s-classe').value);
  fd.append('redoublant', document.getElementById('s-redoublant').value);
  fd.append('abandon', document.getElementById('s-abandon').value);
  fd.append('annee_scolaire', SETTINGS.annee_scolaire);
  const photoFile = document.getElementById('s-photo').files[0];
  if (photoFile) fd.append('photo', photoFile);
  let res;
  if (id) { fd.append('id', id); res = await apiPost('update_student', fd); }
  else res = await apiPost('add_student', fd);
  if (res.error) return alert(res.error);
  document.getElementById('modal-student').classList.remove('active');
  loadStudentsTable();
});

// ---------------- Notes ----------------
document.getElementById('grades-classe').addEventListener('change', async () => {
  const classId = document.getElementById('grades-classe').value;
  const students = await apiGet('list_students', { class_id: classId });
  document.getElementById('grades-eleve').innerHTML = '<option value="">-- Élève --</option>' +
    students.map(s => `<option value="${s.id}">${esc(s.nom)} ${esc(s.prenoms)}</option>`).join('');
});
document.getElementById('grades-eleve').addEventListener('change', loadGradesTable);
document.getElementById('grades-semestre').addEventListener('change', loadGradesTable);

async function loadGradesTable() {
  const studentId = document.getElementById('grades-eleve').value;
  const semestre = document.getElementById('grades-semestre').value;
  if (!studentId) return;
  const rows = await apiGet('get_grades', { student_id: studentId, semestre });
  const tbody = document.querySelector('#table-grades tbody');
  tbody.innerHTML = '';
  let totalPoints = 0, totalCoef = 0;
  rows.forEach(r => {
    const tr = document.createElement('tr');
    tr.dataset.subjectId = r.subject_id;
    tr.innerHTML = `<td>${esc(r.matiere)}</td><td>${r.coefficient}</td>
      <td><input type="number" step="0.25" min="0" max="20" class="i1" value="${r.interro1 ?? ''}"></td>
      <td><input type="number" step="0.25" min="0" max="20" class="i2" value="${r.interro2 ?? ''}"></td>
      <td><input type="number" step="0.25" min="0" max="20" class="i3" value="${r.interro3 ?? ''}"></td>
      <td><input type="number" step="0.25" min="0" max="20" class="i4" value="${r.interro4 ?? ''}"></td>
      <td class="moy-i">${r.moyenne_interro ?? '-'}</td>
      <td><input type="number" step="0.25" min="0" max="20" class="d1" value="${r.devoir1 ?? ''}"></td>
      <td><input type="number" step="0.25" min="0" max="20" class="d2" value="${r.devoir2 ?? ''}"></td>
      <td class="moy-s">${r.moyenne_semestrielle ?? '-'}</td>
      <td class="moy-c">${r.moyenne_coefficiee ?? '-'}</td>
      <td class="obs">${r.appreciation ?? ''}</td>`;
    tbody.appendChild(tr);
    if (r.moyenne_coefficiee !== null) { totalPoints += r.moyenne_coefficiee; totalCoef += parseFloat(r.coefficient); }
  });
  const moyGen = totalCoef > 0 ? Math.round((totalPoints / totalCoef) * 100) / 100 : null;
  document.getElementById('grades-total').innerHTML =
    `Total: <strong>${Math.round(totalPoints * 100) / 100}</strong> / Coef: <strong>${totalCoef}</strong> / Moy. gén.: <strong>${moyGen ?? '-'}</strong>`;
}
document.getElementById('btn-save-grades').addEventListener('click', async () => {
  const studentId = document.getElementById('grades-eleve').value;
  const semestre = document.getElementById('grades-semestre').value;
  if (!studentId) return alert('Choisis un élève.');
  const rows = document.querySelectorAll('#table-grades tbody tr');
  for (const tr of rows) {
    const fd = toFD({
      student_id: studentId, subject_id: tr.dataset.subjectId, semestre,
      interro1: tr.querySelector('.i1').value, interro2: tr.querySelector('.i2').value,
      interro3: tr.querySelector('.i3').value, interro4: tr.querySelector('.i4').value,
      devoir1: tr.querySelector('.d1').value, devoir2: tr.querySelector('.d2').value,
      annee_scolaire: SETTINGS.annee_scolaire
    });
    await apiPost('save_grade', fd);
  }
  alert('Notes enregistrées.');
  loadGradesTable();
});

// ---------------- Bulletin ----------------
document.getElementById('bulletin-classe').addEventListener('change', async () => {
  const classId = document.getElementById('bulletin-classe').value;
  const students = await apiGet('list_students', { class_id: classId });
  document.getElementById('bulletin-eleve').innerHTML = '<option value="">-- Élève --</option>' +
    students.map(s => `<option value="${s.id}">${esc(s.nom)} ${esc(s.prenoms)}</option>`).join('');
});
document.getElementById('btn-generer-bulletin').addEventListener('click', async () => {
  const studentId = document.getElementById('bulletin-eleve').value;
  const semestre = document.getElementById('bulletin-semestre').value;
  if (!studentId) return alert('Choisis un élève.');
  const b = await apiGet('get_bulletin', { student_id: studentId, semestre });
  if (b.error) { document.getElementById('bulletin-container').innerHTML = `<p class="hint">${esc(b.error)}</p>`; return; }
  document.getElementById('bulletin-container').innerHTML = renderBulletin(b);
});
document.getElementById('btn-imprimer-bulletin').addEventListener('click', () => window.print());

// ---------------- Bilan de classe (classement) ----------------
document.getElementById('btn-generer-classement').addEventListener('click', async () => {
  const classId = document.getElementById('classement-classe').value;
  const semestre = document.getElementById('classement-semestre').value;
  if (!classId) return alert('Choisis une classe.');
  const data = await apiGet('bilan_classe', { class_id: classId, semestre });
  if (data.error) { document.getElementById('classement-container').innerHTML = `<p class="hint">${esc(data.error)}</p>`; return; }
  document.getElementById('classement-container').innerHTML = renderClassement(data);
});
document.getElementById('btn-imprimer-classement').addEventListener('click', () => window.print());

let dernierClassement = null;
function texteClassementPartage(data) {
  const periode = data.semestre === 'annuel' ? 'Bilan annuel' : `Semestre ${data.semestre}`;
  let txt = `📊 Classement - ${data.classe_nom} - ${periode} - ${SETTINGS.annee_scolaire}\n` +
    `Établissement : ${SETTINGS.school_name || ''}\n` +
    `Effectif : ${data.effectif}\n\n`;
  data.lignes.forEach(l => {
    txt += `${l.rang ?? '-'}. ${l.nom} ${l.prenoms} — ${l.moyenne ?? '-'}/20 (${l.appreciation || '-'})\n`;
  });
  return txt;
}
document.getElementById('btn-partager-classement').addEventListener('click', async () => {
  if (!dernierClassement) return alert("Génère d'abord le classement.");
  const texte = texteClassementPartage(dernierClassement);
  if (navigator.share) {
    try { await navigator.share({ title: `Classement ${dernierClassement.classe_nom}`, text: texte }); }
    catch (e) { /* partage annule */ }
  } else if (navigator.clipboard) {
    await navigator.clipboard.writeText(texte);
    alert("Le partage direct n'est pas disponible ici : le classement a été copié, tu peux le coller où tu veux (WhatsApp, SMS...).");
  } else {
    alert(texte);
  }
});

function renderClassement(data) {
  dernierClassement = data;
  const periodeLabel = data.semestre === 'annuel' ? 'Bilan annuel' : `Semestre ${data.semestre}`;
  const lignes = data.lignes.map(l => `
    <tr>
      <td>${l.rang ?? '-'}</td>
      <td>${esc(l.matricule)}</td>
      <td style="text-align:left">${esc(l.nom)}</td>
      <td style="text-align:left">${esc(l.prenoms)}</td>
      <td><strong>${l.moyenne ?? '-'}</strong></td>
      <td>${esc(l.appreciation)}</td>
    </tr>`).join('') || '<tr><td colspan="6">Aucun élève dans cette classe.</td></tr>';

  return `
  <div class="bulletin periode-${data.semestre === 'annuel' ? 3 : data.semestre}" style="min-height:auto;">
    <div class="bulletin-title">Bilan de classe - ${esc(data.classe_nom)} - ${periodeLabel} - ${esc(SETTINGS.annee_scolaire)}</div>
    <div class="bulletin-infos"><div><strong>Effectif :</strong> ${data.effectif}</div></div>
    <table>
      <thead><tr><th>Rang</th><th>Matricule</th><th>Nom</th><th>Prénoms</th><th>Moyenne</th><th>Appréciation</th></tr></thead>
      <tbody>${lignes}</tbody>
    </table>
  </div>`;
}

function renderBulletin(b) {
  const s = b.student;
  const fmt = v => v === null || v === undefined ? '-' : v;
  const lignes = b.lignes.map(l => `
    <tr>
      <td style="text-align:left">${esc(l.matiere)}</td><td>${l.coefficient}</td>
      <td>${fmt(l.interro1)}</td><td>${fmt(l.interro2)}</td><td>${fmt(l.interro3)}</td><td>${fmt(l.interro4)}</td>
      <td>${fmt(l.moyenne_interro)}</td>
      <td>${fmt(l.devoir1)}</td><td>${fmt(l.devoir2)}</td>
      <td><strong>${fmt(l.moyenne_semestrielle)}</strong></td>
      <td>${fmt(l.moyenne_coefficiee)}</td>
      <td>${esc(l.appreciation)}</td>
    </tr>`).join('') + (b.lignes.length ? `
    <tr style="font-weight:bold;background:#f0f0f0">
      <td colspan="9" style="text-align:right">TOTAL</td>
      <td>${fmt(b.total_points)}</td>
      <td colspan="1">Coef: ${fmt(b.total_coefficients)}</td>
    </tr>` : `<tr><td colspan="11">Aucune note saisie pour ce semestre.</td></tr>`);

  const bilanAnnuel = b.semestre == 2 ? `
    <div class="bulletin-infos" style="border-top:1px dashed #000;padding-top:6px;margin-top:8px;">
      <strong>BILAN ANNUEL</strong>
    </div>
    <div class="bulletin-recap">
      <div>Moyenne 1er semestre : <strong>${fmt(b.moyenne_generale_t1)}</strong></div>
      <div>Moyenne 2nd semestre : <strong>${fmt(b.moyenne_generale)}</strong></div>
      <div>Moyenne annuelle : <strong>${fmt(b.moyenne_annuelle)}</strong></div>
      <div>Rang annuel : <strong>${fmt(b.rang_annuel)}</strong> / ${b.effectif}</div>
    </div>
    <div class="bulletin-recap">
      <div>Moyenne annuelle la + forte : ${fmt(b.moyenne_annuelle_plus_forte)}</div>
      <div>Moyenne annuelle la + faible : ${fmt(b.moyenne_annuelle_plus_faible)}</div>
      <div>Appréciation : <strong>${esc(b.appreciation_annuelle)}</strong></div>
    </div>
    <div class="bulletin-recap"><div style="font-size:13px"><strong>DÉCISION DU CONSEIL : ${esc(b.decision)}</strong></div></div>
  ` : '';

  return `
  <div class="bulletin periode-${b.semestre}">
    <div class="bulletin-header">
      <div class="col">
        ${SETTINGS.school_logo ? `<img src="${SETTINGS.school_logo}">` : ''}
        <div>${esc(SETTINGS.school_name)}</div>
      </div>
      <div class="col">
        ${SETTINGS.benin_logo ? `<img src="${SETTINGS.benin_logo}">` : ''}
        <div>${esc(SETTINGS.republique_texte)}</div>
        <div>${esc(SETTINGS.ministere_texte)}</div>
      </div>
      <div class="col">
        <div>BP : ${esc(SETTINGS.adresse_bp)}</div>
        <div>${esc(SETTINGS.adresse)}</div>
        <div>Email : ${esc(SETTINGS.email)}</div>
        <div>Tél : ${esc(SETTINGS.telephones)}</div>
        <div>IFU : ${esc(SETTINGS.ifu)}</div>
      </div>
    </div>
    <div class="bulletin-title">Bulletin de notes - ${b.semestre == 1 ? '1er' : '2nd'} Semestre - ${esc(SETTINGS.annee_scolaire)}</div>
    <div class="bulletin-infos">
      <div><strong>Nom :</strong> ${esc(s.nom)}</div>
      <div><strong>Prénoms :</strong> ${esc(s.prenoms)}</div>
      <div><strong>Matricule :</strong> ${esc(s.matricule)}</div>
      <div><strong>Classe :</strong> ${esc(s.classe_nom)}</div>
      <div><strong>Né(e) le :</strong> ${esc(s.date_naissance) || '-'}</div>
      <div><strong>À :</strong> ${esc(s.lieu_naissance) || '-'}</div>
      <div><strong>Effectif classe :</strong> ${b.effectif}</div>
      <div><strong>Redoublant :</strong> ${esc(s.redoublant)}</div>
      <div><strong>Abandon :</strong> ${esc(s.abandon)}</div>
    </div>
    <table>
      <thead><tr>
        <th>Matière</th><th>Coef</th><th>I1</th><th>I2</th><th>I3</th><th>I4</th><th>Moy. Int.</th>
        <th>Dev1</th><th>Dev2</th><th>Moy. Trim.</th><th>Moy. Coef.</th><th>Observation</th>
      </tr></thead>
      <tbody>${lignes}</tbody>
    </table>
    <div class="bulletin-recap">
      <div>Moyenne générale : <strong>${fmt(b.moyenne_generale)}</strong></div>
      <div>Rang : <strong>${fmt(b.rang)}</strong> / ${b.effectif}</div>
      <div>Appréciation : <strong>${esc(b.appreciation_generale)}</strong></div>
    </div>
    <div class="bulletin-recap">
      <div>Moyenne la + forte de la classe : ${fmt(b.moyenne_plus_forte)}</div>
      <div>Moyenne la + faible de la classe : ${fmt(b.moyenne_plus_faible)}</div>
    </div>
    ${bilanAnnuel}
    <div class="bulletin-recap" style="margin-top:20px;">
      <div class="bulletin-signature">
        <div>Le Directeur / La Directrice</div>
        <div>${esc(SETTINGS.directeur_nom)}</div>
        ${SETTINGS.directeur_signature ? `<img src="${SETTINGS.directeur_signature}">` : ''}
        ${SETTINGS.directeur_cachet ? `<img src="${SETTINGS.directeur_cachet}">` : ''}
      </div>
    </div>
  </div>`;
}

// ---------------- Paramètres ----------------
const SETTINGS_FIELDS = ['school_name','ministere_texte','republique_texte','adresse_bp','adresse','email','telephones','ifu','directeur_nom','annee_scolaire'];
async function loadSettingsForm() {
  const s = await apiGet('get_settings');
  SETTINGS_FIELDS.forEach(f => { const el = document.getElementById('set-' + f); if (el) el.value = s[f] || ''; });
}
document.getElementById('form-settings').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData();
  SETTINGS_FIELDS.forEach(f => fd.append(f, document.getElementById('set-' + f).value));
  ['school_logo','benin_logo','directeur_signature','directeur_cachet'].forEach(f => {
    const file = document.getElementById('set-' + f).files[0];
    if (file) fd.append(f, file);
  });
  await apiPost('save_settings', fd);
  await loadGlobalSettings();
  alert('Paramètres enregistrés.');
});

document.getElementById('coef-classe').addEventListener('change', (e) => loadCoefTable(e.target.value));
async function loadCoefTable(classId) {
  if (!classId) return;
  const rows = await apiGet('get_class_subjects', { class_id: classId });
  const tbody = document.querySelector('#table-coef tbody');
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td style="text-align:left">${esc(r.nom)}</td>
      <td><input type="number" step="0.5" min="0" value="${r.coefficient}" onchange="saveCoef(${r.id}, this.value)"></td>
    </tr>`).join('');
}
async function saveCoef(id, coefficient) {
  await apiPost('save_class_subject', toFD({ id, coefficient }));
}

// ---------------- Verrouillage par code d'accès ----------------
// Protection simple côté client (empêche une ouverture occasionnelle) : le code
// n'est jamais stocké en clair, seulement son empreinte SHA-256.
const PIN_KEY = 'mentalekost_pin_hash';
let failedAttempts = 0;

async function sha256(text) {
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}
function getStoredHash() { return localStorage.getItem(PIN_KEY); }
function setStoredHash(h) { localStorage.setItem(PIN_KEY, h); }

// ---------------- OTP (vérification en deux étapes, type Google Authenticator) ----------------
const OTP_KEY = 'mentalekost_otp_secret';
const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function base32Encode(bytes) {
  let bits = '', output = '';
  for (const b of bytes) bits += b.toString(2).padStart(8, '0');
  for (let i = 0; i + 5 <= bits.length; i += 5) output += BASE32_ALPHABET[parseInt(bits.substr(i, 5), 2)];
  const rem = bits.length % 5;
  if (rem) output += BASE32_ALPHABET[parseInt(bits.slice(-rem).padEnd(5, '0'), 2)];
  return output;
}
function base32Decode(str) {
  str = str.toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = '';
  for (const c of str) bits += BASE32_ALPHABET.indexOf(c).toString(2).padStart(5, '0');
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.substr(i, 8), 2));
  return new Uint8Array(bytes);
}
async function hotp(secretBytes, counter) {
  const counterBytes = new ArrayBuffer(8);
  const view = new DataView(counterBytes);
  view.setUint32(4, counter >>> 0, false);
  view.setUint32(0, Math.floor(counter / 0x100000000), false);
  const key = await crypto.subtle.importKey('raw', secretBytes, { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']);
  const sig = new Uint8Array(await crypto.subtle.sign('HMAC', key, counterBytes));
  const offset = sig[sig.length - 1] & 0xf;
  const code = ((sig[offset] & 0x7f) << 24) | ((sig[offset + 1] & 0xff) << 16) | ((sig[offset + 2] & 0xff) << 8) | (sig[offset + 3] & 0xff);
  return (code % 1000000).toString().padStart(6, '0');
}
async function totpCode(secretBase32, stepOffset = 0) {
  const counter = Math.floor(Date.now() / 1000 / 30) + stepOffset;
  return hotp(base32Decode(secretBase32), counter);
}
async function verifierTotp(secretBase32, code) {
  code = (code || '').replace(/\s/g, '');
  for (const offset of [0, -1, 1]) {
    if (await totpCode(secretBase32, offset) === code) return true;
  }
  return false;
}
function otpEstActif() { return !!localStorage.getItem(OTP_KEY); }
function majStatutOtp() {
  document.getElementById('otp-statut').textContent = 'Vérification en deux étapes (OTP) : ' + (otpEstActif() ? 'activée ✅' : 'désactivée.');
  document.getElementById('btn-activer-otp').style.display = otpEstActif() ? 'none' : '';
  document.getElementById('btn-desactiver-otp').style.display = otpEstActif() ? '' : 'none';
}
function renderOtpSetup(onDone, onCancel) {
  const secret = base32Encode(crypto.getRandomValues(new Uint8Array(15)));
  const box = document.getElementById('lock-box');
  box.innerHTML = `
    <h2>Activer la vérification en 2 étapes</h2>
    <p class="hint">Dans une appli d'authentification (Google Authenticator, Authy...), choisis "Ajouter manuellement" et saisis cette clé :</p>
    <p style="font-family:monospace; font-size:1.1em; font-weight:bold; letter-spacing:2px; background:#f4f6f5; padding:10px; border-radius:8px; word-break:break-all;">${secret}</p>
    <p class="hint">Puis entre ici le code à 6 chiffres affiché par l'appli pour confirmer :</p>
    <input type="text" inputmode="numeric" maxlength="6" id="otp-confirm" placeholder="Code à 6 chiffres">
    <button class="btn" id="otp-confirm-btn" type="button">Confirmer et activer</button>
    <p id="lock-error" class="lock-error"></p>
    <button class="btn secondary" id="otp-cancel-btn" type="button">Annuler</button>`;
  document.getElementById('otp-confirm-btn').addEventListener('click', async () => {
    const code = document.getElementById('otp-confirm').value;
    const err = document.getElementById('lock-error');
    if (await verifierTotp(secret, code)) {
      localStorage.setItem(OTP_KEY, secret);
      onDone();
    } else {
      err.textContent = "Code incorrect. Vérifie l'heure de ton téléphone et réessaie.";
    }
  });
  document.getElementById('otp-cancel-btn').addEventListener('click', onCancel);
}
function renderOtpEnter(onDone) {
  const box = document.getElementById('lock-box');
  box.innerHTML = `
    <h2>Vérification en 2 étapes</h2>
    <p class="hint">Entre le code à 6 chiffres de ton appli d'authentification.</p>
    <input type="text" inputmode="numeric" maxlength="6" id="otp-enter" placeholder="Code à 6 chiffres" autocomplete="one-time-code">
    <button class="btn" id="otp-enter-btn" type="button">Valider</button>
    <p id="lock-error" class="lock-error"></p>`;
  const essayer = async () => {
    const code = document.getElementById('otp-enter').value;
    const err = document.getElementById('lock-error');
    if (await verifierTotp(localStorage.getItem(OTP_KEY), code)) { onDone(); return; }
    err.textContent = 'Code incorrect.';
    document.getElementById('otp-enter').value = '';
    document.getElementById('otp-enter').focus();
  };
  document.getElementById('otp-enter-btn').addEventListener('click', essayer);
  document.getElementById('otp-enter').addEventListener('keydown', e => { if (e.key === 'Enter') essayer(); });
  setTimeout(() => document.getElementById('otp-enter')?.focus(), 50);
}
function procederApresPin(onDone) {
  if (otpEstActif()) renderOtpEnter(onDone);
  else onDone();
}

function renderLockCreate(onDone) {
  const box = document.getElementById('lock-box');
  box.innerHTML = `
    <h2>Créer un code d'accès</h2>
    <p class="hint">Ce code sera demandé à chaque ouverture de l'application.</p>
    <input type="password" id="lock-new1" placeholder="Nouveau code (4 caractères min.)" autocomplete="new-password">
    <input type="password" id="lock-new2" placeholder="Confirmer le code" autocomplete="new-password">
    <button class="btn" id="lock-create-btn" type="button">Créer le code</button>
    <p id="lock-error" class="lock-error"></p>`;
  const submit = async () => {
    const p1 = document.getElementById('lock-new1').value;
    const p2 = document.getElementById('lock-new2').value;
    const err = document.getElementById('lock-error');
    if (p1.length < 4) { err.textContent = 'Le code doit faire au moins 4 caractères.'; return; }
    if (p1 !== p2) { err.textContent = 'Les deux codes ne correspondent pas.'; return; }
    setStoredHash(await sha256(p1));
    onDone();
  };
  document.getElementById('lock-create-btn').addEventListener('click', submit);
  document.getElementById('lock-new2').addEventListener('keydown', e => { if (e.key === 'Enter') submit(); });
}

function renderLockEnter(onDone) {
  const box = document.getElementById('lock-box');
  box.innerHTML = `
    <h2>MentaleKost verrouillé</h2>
    <p class="hint">Entre le code d'accès pour continuer.</p>
    <input type="password" id="lock-enter" placeholder="Code d'accès" autocomplete="current-password">
    <button class="btn" id="lock-enter-btn" type="button">Déverrouiller</button>
    <p id="lock-error" class="lock-error"></p>
    <button class="btn secondary" id="lock-forgot-btn" type="button">Code oublié ?</button>`;
  const tryUnlock = async () => {
    const val = document.getElementById('lock-enter').value;
    const err = document.getElementById('lock-error');
    if (await sha256(val) === getStoredHash()) { procederApresPin(onDone); return; }
    failedAttempts++;
    err.textContent = 'Code incorrect.' + (failedAttempts >= 3 ? ' (plusieurs essais échoués)' : '');
    document.getElementById('lock-enter').value = '';
    document.getElementById('lock-enter').focus();
  };
  document.getElementById('lock-enter-btn').addEventListener('click', tryUnlock);
  document.getElementById('lock-enter').addEventListener('keydown', e => { if (e.key === 'Enter') tryUnlock(); });
  document.getElementById('lock-forgot-btn').addEventListener('click', () => {
    if (confirm("Réinitialiser le code d'accès ? (tes classes, élèves et notes ne sont pas touchés, seul le verrou est enlevé)")) {
      localStorage.removeItem(PIN_KEY);
      renderLockCreate(onDone);
    }
  });
  setTimeout(() => document.getElementById('lock-enter')?.focus(), 50);
}

function showLockScreen() { document.getElementById('lock-screen').style.display = 'flex'; }
function hideLockScreen() { document.getElementById('lock-screen').style.display = 'none'; }

function lockNow() {
  if (!getStoredHash()) return; // pas de code défini : rien à verrouiller
  showLockScreen();
  renderLockEnter(hideLockScreen);
}
document.getElementById('btn-verrouiller').addEventListener('click', lockNow);
document.getElementById('btn-verrouiller-2').addEventListener('click', lockNow);

document.getElementById('btn-changer-code').addEventListener('click', () => {
  showLockScreen();
  const finishChange = () => {
    renderLockCreate(() => { hideLockScreen(); alert('Code modifié.'); });
  };
  if (!getStoredHash()) { finishChange(); return; }
  renderLockEnter(finishChange);
});

document.getElementById('btn-activer-otp').addEventListener('click', () => {
  showLockScreen();
  renderOtpSetup(
    () => { hideLockScreen(); majStatutOtp(); alert('Vérification en deux étapes activée.'); },
    () => { hideLockScreen(); }
  );
});
document.getElementById('btn-desactiver-otp').addEventListener('click', () => {
  showLockScreen();
  renderOtpEnter(() => {
    localStorage.removeItem(OTP_KEY);
    hideLockScreen();
    majStatutOtp();
    alert('Vérification en deux étapes désactivée.');
  });
});

async function initLock() {
  if (!(window.crypto && window.crypto.subtle)) {
    // Navigateur trop ancien pour le chiffrement : on n'empêche pas l'accès à l'application.
    hideLockScreen();
    loadGlobalSettings().then(loadDashboard);
    return;
  }
  const afterUnlock = () => { hideLockScreen(); loadGlobalSettings().then(loadDashboard); };
  if (!getStoredHash()) renderLockCreate(afterUnlock);
  else renderLockEnter(afterUnlock);
}

// ---------------- Sauvegarde / restauration (archives qui survivent à une réinstallation) ----------------
// IndexedDB est effacé si l'application est désinstallée : c'est une limite
// normale de toute appli 100% hors-ligne sans serveur. La seule façon fiable
// de conserver les données est d'exporter un fichier de sauvegarde (à garder
// sur Google Drive, carte SD, etc.) et de le restaurer après réinstallation.
async function collecterToutesLesDonnees() {
  const [settings, classes, subjects, class_subjects, students, grades] = await Promise.all([
    idbGet('settings', 1), idbGetAll('classes'), idbGetAll('subjects'),
    idbGetAll('class_subjects'), idbGetAll('students'), idbGetAll('grades')
  ]);
  return {
    app: 'MentaleKost', version: 1, exporte_le: new Date().toISOString(),
    settings, classes, subjects, class_subjects, students, grades
  };
}

document.getElementById('btn-exporter').addEventListener('click', async () => {
  const data = await collecterToutesLesDonnees();
  const json = JSON.stringify(data, null, 0);
  const base64 = btoa(unescape(encodeURIComponent(json)));
  const dateStr = new Date().toISOString().slice(0, 10);
  const filename = `mentalekost-sauvegarde-${dateStr}.json`;
  const dataUri = `data:application/json;base64,${base64}`;

  // Sur navigateur classique (test dans Acode/Chrome), le clic déclenche un
  // vrai téléchargement. Dans l'app Android empaquetée, c'est le
  // DownloadListener de MainActivity.java qui prend le relais pour écrire le
  // fichier dans le dossier Téléchargements.
  const a = document.createElement('a');
  a.href = dataUri;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  alert(`Sauvegarde "${filename}" générée. Range-la dans un endroit sûr (Drive, carte SD...) : c'est ce fichier qui te permettra de retrouver tes classes et élèves après une réinstallation.`);
});

document.getElementById('btn-importer').addEventListener('click', () => {
  document.getElementById('input-importer').click();
});
document.getElementById('input-importer').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  let data;
  try {
    const text = await file.text();
    data = JSON.parse(text);
  } catch (err) {
    alert("Ce fichier n'est pas une sauvegarde MentaleKost valide.");
    return;
  }
  if (data.app !== 'MentaleKost' || !data.students || !data.classes) {
    alert("Ce fichier n'est pas une sauvegarde MentaleKost valide.");
    return;
  }
  if (!confirm(`Restaurer cette sauvegarde (du ${new Date(data.exporte_le).toLocaleDateString('fr-FR')}) ? Cela REMPLACE toutes les données actuelles de l'application (classes, élèves, notes).`)) return;

  await Promise.all([idbClear('grades'), idbClear('students'), idbClear('class_subjects'), idbClear('classes'), idbClear('subjects')]);
  for (const row of data.subjects || []) await idbPut('subjects', row);
  for (const row of data.classes || []) await idbPut('classes', row);
  for (const row of data.class_subjects || []) await idbPut('class_subjects', row);
  for (const row of data.students || []) await idbPut('students', row);
  for (const row of data.grades || []) await idbPut('grades', row);
  if (data.settings) await idbPut('settings', { ...data.settings, id: 1 });
  SUBJECTS_CACHE = null;

  alert('Sauvegarde restaurée avec succès.');
  await loadGlobalSettings();
  loadDashboard();
});

// ---------------- Démarrage ----------------
initLock();
