import os, re, json, uuid, shutil, subprocess, threading, time, zipfile
from pathlib import Path
import httpx
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

DATA = Path(os.getenv("DATA_DIR", "data")); DATA.mkdir(exist_ok=True)
KEY = os.getenv("ANTHROPIC_API_KEY", "")
MODEL = os.getenv("LLM_MODEL", "claude-sonnet-4-6")
WHISPER = os.getenv("WHISPER_MODEL", "small")
MAX_MB = int(os.getenv("MAX_UPLOAD_MB", "500"))
TTL = int(os.getenv("RETENTION_HOURS", "6")) * 3600
LANGS = {"ar": "العربية", "en": "English", "fr": "Français", "es": "Español", "de": "Deutsch",
         "tr": "Türkçe", "ru": "Русский", "it": "Italiano", "pt": "Português",
         "hi": "हिन्दी", "id": "Indonesia", "ur": "اردو"}
JOBS, _model = {}, None
app = FastAPI()


def sh(cmd, cwd=None):
    subprocess.run(cmd, check=True, capture_output=True, cwd=cwd)


def llm(prompt, mx=4000):
    r = httpx.post("https://api.anthropic.com/v1/messages", timeout=180,
                   headers={"x-api-key": KEY, "anthropic-version": "2023-06-01"},
                   json={"model": MODEL, "max_tokens": mx, "messages": [{"role": "user", "content": prompt}]})
    r.raise_for_status()
    return r.json()["content"][0]["text"]


def jparse(t):
    return json.loads(re.search(r"[\[{].*[\]}]", t, re.S).group(0))


def transcribe(src, lang, d):
    global _model
    wav = d / "a.wav"
    sh(["ffmpeg", "-y", "-i", str(src), "-vn", "-ac", "1", "-ar", "16000", str(wav)])
    if _model is None:
        from faster_whisper import WhisperModel
        _model = WhisperModel(WHISPER, compute_type="int8")
    it, info = _model.transcribe(str(wav), language=None if lang == "auto" else lang, vad_filter=True)
    segs = [{"s": round(x.start, 2), "e": round(x.end, 2), "t": x.text.strip()} for x in it if x.text.strip()]
    return segs, info.language


def pick(segs, dur, n):
    txt = "\n".join(f"[{i}] {s['s']:.0f}s: {s['t']}" for i, s in enumerate(segs))
    ask = f"exactly {n}" if n else "up to 8 (only genuinely strong ones)"
    r = jparse(llm(
        f"Transcript segments:\n{txt}\n\nPick {ask} non-overlapping short-video clips. Each is consecutive "
        f"segments i..j forming a complete self-contained idea: a hook at the start, a finished sentence at "
        f"the end, about {dur} seconds long. Prefer compelling stories, useful facts, strong lines, funny "
        f"moments. Return ONLY JSON: [{{\"i\":int,\"j\":int,\"title\":\"short catchy title in the transcript "
        f"language\",\"why\":\"one-sentence reason, in Arabic\"}}]", 3000))
    out, used = [], []
    for c in r:
        i, k = int(c["i"]), int(c["j"])
        if not 0 <= i <= k < len(segs) or any(i <= b and a <= k for a, b in used):
            continue
        if not dur * .5 <= segs[k]["e"] - segs[i]["s"] <= dur * 1.4:
            continue
        used.append((i, k))
        out.append({"i": i, "j": k, "s": segs[i]["s"], "e": segs[k]["e"],
                    "title": c.get("title", ""), "why": c.get("why", "")})
    if not out:
        raise RuntimeError("لم يجد النموذج مقاطع مناسبة بهذه المدة، جرّب مدة أخرى")
    return sorted(out, key=lambda c: c["s"])


def translate(texts, src_name, tgt):
    p = (f"Translate each string from {src_name} to {LANGS[tgt]}. Keep meaning and context, natural phrasing, "
         f"never literal word-for-word; keep proper names and religious terms in their standard form. "
         f"Return ONLY a JSON array of exactly {len(texts)} strings.\n" + json.dumps(texts, ensure_ascii=False))
    for _ in range(2):
        out = jparse(llm(p))
        if len(out) == len(texts):
            return [str(x) for x in out]
    raise RuntimeError(f"فشلت الترجمة إلى {LANGS[tgt]}")


def ts(x):
    return f"{int(x // 3600):02}:{int(x % 3600 // 60):02}:{x % 60:06.3f}".replace(".", ",")


def srt(segs, off):
    return "\n".join(f"{i + 1}\n{ts(max(0, s['s'] - off))} --> {ts(s['e'] - off)}\n{s['t']}\n"
                     for i, s in enumerate(segs))


def render(src, c, cid, lg, d, o):
    h, dur = o["height"], c["e"] - c["s"]
    vf = (f"crop='min(iw,ih*9/16)':'min(ih,iw*16/9)',scale={h * 9 // 16}:{h},fade=t=in:d=0.25,"
          f"subtitles={cid}_{lg}.srt:force_style='FontName=Noto Sans,FontSize={o['fs']},Bold=1,"
          f"Alignment=2,MarginV=90,Outline=2'")
    af = f"afade=t=in:d=0.15,afade=t=out:st={max(0, dur - .4):.2f}:d=0.4"
    sh(["ffmpeg", "-y", "-ss", str(c["s"]), "-i", str(src), "-t", f"{dur:.2f}", "-vf", vf, "-af", af,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-c:a", "aac",
        "-movflags", "+faststart", f"{cid}_{lg}.mp4"], cwd=d)


def run(jid, src, o):
    j, d = JOBS[jid], DATA / jid
    try:
        j.update(pct=5, msg="تفريغ الكلام إلى نص بالتوقيتات...")
        segs, sl = transcribe(src, o["lang"], d)
        if not segs:
            raise RuntimeError("لم يُكتشف كلام في الفيديو")
        j.update(pct=30, msg="الذكاء الاصطناعي يختار أفضل المقاطع...")
        clips = pick(segs, o["dur"], o["count"])
        langs = o["langs"] or [sl]
        total, done = len(clips) * len(langs), 0
        for n, c in enumerate(clips, 1):
            part, cid, files = segs[c["i"]:c["j"] + 1], f"c{n}", {}
            for lg in langs:
                j["msg"] = f"المقطع {n} من {len(clips)} — {LANGS.get(lg, lg)}"
                texts = [x["t"] for x in part]
                if lg != sl:
                    texts = translate(texts, LANGS.get(sl, sl), lg)
                sub = [{"s": x["s"], "e": x["e"], "t": t} for x, t in zip(part, texts)]
                (d / f"{cid}_{lg}.srt").write_text(srt(sub, c["s"]), encoding="utf-8")
                render(src, c, cid, lg, d, o)
                files[lg] = f"{cid}_{lg}"
                done += 1
                j["pct"] = 30 + int(70 * done / total)
            j["clips"].append({"id": cid, "title": c["title"], "why": c["why"],
                               "s": c["s"], "e": c["e"], "files": files})
        j.update(pct=100, msg="اكتملت المعالجة", status="done")
    except Exception as e:
        err = str(e)
        if isinstance(e, subprocess.CalledProcessError) and e.stderr:
            err = e.stderr.decode(errors="ignore")[-300:]
        j.update(status="error", msg=f"حدث خطأ: {err}")


def janitor():
    while True:
        for p in DATA.iterdir():
            if p.is_dir() and time.time() - p.stat().st_mtime > TTL:
                shutil.rmtree(p, True); JOBS.pop(p.name, None)
        time.sleep(600)


threading.Thread(target=janitor, daemon=True).start()


def _dir(jid):
    d = DATA / jid
    if not re.fullmatch(r"[0-9a-f]{12}", jid) or not d.is_dir():
        raise HTTPException(404, "المهمة غير موجودة أو انتهت مدة الاحتفاظ بها")
    return d


@app.get("/api/config")
def config():
    return {"ai": bool(KEY), "langs": LANGS, "max_mb": MAX_MB}


@app.post("/api/jobs")
async def create(file: UploadFile = File(...), lang: str = Form("auto"), dur: int = Form(30),
                 count: int = Form(0), langs: str = Form(""), fs: int = Form(10), height: int = Form(1920)):
    if not KEY:
        raise HTTPException(400, "التحليل الذكي غير مفعّل: عيّن ANTHROPIC_API_KEY على الخادم ثم أعد التشغيل")
    jid = uuid.uuid4().hex[:12]
    d = DATA / jid; d.mkdir()
    src, n = d / ("src" + Path(file.filename or "v.mp4").suffix[:6]), 0
    with open(src, "wb") as f:
        while b := await file.read(1 << 20):
            n += len(b)
            if n > MAX_MB << 20:
                shutil.rmtree(d, True)
                raise HTTPException(413, f"حجم الملف يتجاوز الحد المسموح ({MAX_MB} ميغابايت)")
            f.write(b)
    o = {"lang": lang if lang in LANGS else "auto", "dur": max(10, min(dur, 180)), "count": max(0, min(count, 20)),
         "langs": [x for x in langs.split(",") if x in LANGS], "fs": max(6, min(fs, 24)),
         "height": 1280 if height == 1280 else 1920}
    JOBS[jid] = {"status": "running", "pct": 0, "msg": "في الانتظار...", "clips": []}
    threading.Thread(target=run, args=(jid, src, o), daemon=True).start()
    return {"id": jid}


@app.get("/api/jobs/{jid}")
def status(jid: str):
    _dir(jid)
    if jid not in JOBS:
        raise HTTPException(404, "انتهت هذه المهمة (أُعيد تشغيل الخادم)")
    return JOBS[jid]


@app.get("/api/jobs/{jid}/file/{name}")
def get_file(jid: str, name: str):
    d = _dir(jid)
    if not re.fullmatch(r"[\w-]+\.(mp4|srt)", name) or not (d / name).is_file():
        raise HTTPException(404, "الملف غير موجود")
    return FileResponse(d / name, filename=name)


@app.get("/api/jobs/{jid}/zip")
def zip_all(jid: str):
    d = _dir(jid); z = d / "all.zip"
    with zipfile.ZipFile(z, "w") as f:
        for p in sorted(d.glob("c*_*.*")):
            if p.suffix in (".mp4", ".srt"):
                f.write(p, p.name)
    return FileResponse(z, filename="reels.zip")


app.mount("/", StaticFiles(directory=Path(__file__).parent / "static", html=True))
