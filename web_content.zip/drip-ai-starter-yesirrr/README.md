# DRIP AI // ULTRA KNOWLEDGE — Starter Prototype

> **Important:** This is a static web app starter prototype.
> It is **NOT** a compiled APK or AAB, and it does **NOT** include a working AI API.
> The chat runs in demo mode and only searches your local, in-memory knowledge shelf.

## What's inside

| File | Purpose |
|------|---------|
| index.html | App shell |
| theme.css | Dark cyberpunk theme (cyan/lime) |
| app.js | Demo chat, in-memory knowledge shelf, text-file upload |
| manifest.webmanifest | PWA manifest |
| sw.js | Offline cache service worker |
| icons/icon.svg, icons/icon-maskable.svg | App icons |

## Features
- Demo chat that clearly says the AI backend is not configured.
- Knowledge shelf stored in memory (cleared on reload).
- Upload .txt / .md / .csv / .json files (max 512 KB each). Other file types are rejected.

## Try it locally
Opening index.html directly works for the UI, but the service worker needs a web server:
```
npx serve .
```

## Put it online (needed for Android install)
Upload the folder contents to any static host with HTTPS, e.g. Netlify Drop (drag & drop at app.netlify.com/drop), Cloudflare Pages, or Vercel.
No GitHub account is required for Netlify Drop.

## Make an Android APK with PWABuilder (simple steps)
1. Host the app online over HTTPS (see above) and open the URL once to check it works.
2. Go to **https://www.pwabuilder.com** on your phone or computer.
3. Paste your app's URL and tap **Start**.
4. PWABuilder checks the manifest and service worker. Fix any warnings it shows
   (it may ask for PNG icons — you can export 192x192 and 512x512 PNGs from icons/icon.svg and add them to the manifest).
5. Tap **Package for stores** → **Android** → **Generate**.
6. Download the ZIP it gives you. It contains a test APK (for sideloading) and an AAB (for Google Play).
7. On Android, open the APK and allow "Install unknown apps" for your browser/file manager when asked.

You can also just open the hosted URL in Chrome on Android and choose **⋮ → Add to Home screen / Install app**.

## Adding a real AI backend
Create your own server endpoint that calls an AI provider, keep the API key on the server,
then replace `localReply()` in app.js with a `fetch()` to that endpoint. Never put secret keys in app.js.

## License
Starter code — use and modify freely.
