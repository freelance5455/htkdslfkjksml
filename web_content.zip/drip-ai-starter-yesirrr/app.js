// DRIP AI // ULTRA KNOWLEDGE — starter prototype.
// No AI backend is configured. Replace localReply() with a real API call
// from YOUR OWN server (never put secret API keys in this file).
(function () {
  "use strict";
  var shelf = []; // in-memory only
  var MAX_FILE = 512 * 1024;
  var TEXT_EXT = /\.(txt|md|csv|json)$/i;

  var $ = function (id) { return document.getElementById(id); };

  // Tabs
  document.querySelectorAll("[data-tab]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      document.querySelectorAll("[data-tab]").forEach(function (b) {
        b.setAttribute("aria-selected", String(b === btn));
        $(b.dataset.tab).hidden = b !== btn;
      });
    });
  });

  function addMsg(text, who) {
    var li = document.createElement("li");
    li.className = "msg " + who;
    li.textContent = text;
    $("messages").appendChild(li);
    li.scrollIntoView({ block: "end", behavior: "smooth" });
  }

  function localReply(q) {
    var words = q.toLowerCase().split(/\W+/).filter(function (w) { return w.length > 2; });
    var best = null, score = 0;
    shelf.forEach(function (item) {
      var hay = (item.title + " " + item.body).toLowerCase();
      var s = words.reduce(function (n, w) { return n + (hay.indexOf(w) >= 0 ? 1 : 0); }, 0);
      if (s > score) { score = s; best = item; }
    });
    var prefix = "[demo mode — AI backend not configured]\n";
    if (!shelf.length) return prefix + "Your knowledge shelf is empty. Add a note or upload a text file.";
    if (!best) return prefix + "No matching shelf item found for that question.";
    return prefix + "Closest shelf item: \"" + best.title + "\"\n" + best.body.slice(0, 300) + (best.body.length > 300 ? "…" : "");
  }

  $("chat-form").addEventListener("submit", function (e) {
    e.preventDefault();
    var q = $("prompt").value.trim();
    if (!q) return;
    addMsg(q, "user");
    $("prompt").value = "";
    setTimeout(function () { addMsg(localReply(q), "bot"); }, 250);
  });

  function render() {
    var ul = $("items");
    ul.innerHTML = "";
    if (!shelf.length) {
      var empty = document.createElement("li");
      empty.innerHTML = "<p>Shelf is empty.</p>";
      ul.appendChild(empty);
      return;
    }
    shelf.forEach(function (item, i) {
      var li = document.createElement("li");
      var h = document.createElement("h3"); h.textContent = item.title;
      var p = document.createElement("p"); p.textContent = item.body.slice(0, 200);
      var del = document.createElement("button"); del.type = "button"; del.textContent = "Remove";
      del.setAttribute("aria-label", "Remove " + item.title);
      del.onclick = function () { shelf.splice(i, 1); render(); };
      li.append(h, p, del);
      ul.appendChild(li);
    });
  }

  $("note-form").addEventListener("submit", function (e) {
    e.preventDefault();
    shelf.push({ title: $("note-title").value.trim(), body: $("note-body").value.trim() });
    e.target.reset();
    render();
  });

  $("file").addEventListener("change", function (e) {
    var files = Array.prototype.slice.call(e.target.files || []);
    var msgs = [];
    var pending = files.length;
    if (!pending) return;
    files.forEach(function (f) {
      var isText = TEXT_EXT.test(f.name) || /^text\//.test(f.type) || f.type === "application/json";
      if (!isText) { msgs.push(f.name + ": rejected (text files only)"); done(); return; }
      if (f.size > MAX_FILE) { msgs.push(f.name + ": rejected (over 512 KB)"); done(); return; }
      var r = new FileReader();
      r.onload = function () { shelf.push({ title: f.name, body: String(r.result) }); msgs.push(f.name + ": added"); done(); };
      r.onerror = function () { msgs.push(f.name + ": could not be read"); done(); };
      r.readAsText(f);
    });
    function done() {
      if (--pending === 0) { $("upload-msg").textContent = msgs.join(" · "); e.target.value = ""; render(); }
    }
  });

  render();
  addMsg("Welcome to DRIP AI (starter prototype). The AI backend is NOT configured — replies come from a local demo that searches your knowledge shelf.", "bot");

  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    navigator.serviceWorker.register("sw.js").catch(function () {});
  }
})();
