# Sudoku Zen

**Clear Your Mind. Master the Grid.**

A complete, premium Sudoku web application with polished mobile-first UI, five genuine difficulty levels, Learning Center, Daily Challenges, Statistics, Achievements, light/dark themes, and full offline persistence.

## Features

- **5 Difficulty Levels**: Easy → Medium → Hard → Expert → Hardcore  
  Each uses real unique-solution generation with different clue densities.
- **Full Gameplay**: Notes (pencil marks), Undo/Redo, Hints with technique explanations, Eraser, Timer, Pause, Mistake tracking.
- **Visual Aids**: Selected cell, related row/col/box highlighting, matching numbers, conflict highlighting.
- **Number Pad** with remaining-count indicators (mobile-friendly + keyboard support on desktop).
- **Daily Challenge**: Deterministic date-based puzzle with streak tracking.
- **Learning Center**: 6 progressive lessons covering basics through advanced techniques.
- **Statistics & Achievements**: Completion counts, best/average times, streaks, unlockable achievements.
- **Settings**: Theme (System/Light/Dark), all visual toggles, timer options, data reset.
- **Persistence**: All progress, unfinished games, settings, and stats saved in localStorage.
- **Responsive**: Mobile-first, works beautifully on phones, tablets, and desktop.

## How to Run

```bash
cd sudoku-zen-app
python3 -m http.server 8080
# Open http://localhost:8080
```

Or any static file server (nginx, `npx serve`, VS Code Live Server, etc.).

No build step required — pure HTML / CSS / ES modules. The project also includes a PWA manifest and service worker for installation and offline play.

## Install on Android

1. Upload the project folder to an HTTPS static host (for example, GitHub Pages, Cloudflare Pages, or Netlify).
2. Open the published URL in Chrome on your Android phone.
3. Open Chrome menu (⋮) and choose **Install app** or **Add to Home screen**.
4. Launch Sudoku Zen from your home screen. After the first successful load, the app shell is cached for offline use.

Service workers do not work from a normal `file://` URL. Use HTTPS hosting or `localhost` to test install/offline behavior.

## Project Structure

```
sudoku-zen-app/
├── index.html          # Entry point
├── styles.css          # Complete design system (light + dark)
├── js/
│   ├── app.js          # UI, screens, game loop, events
│   ├── sudoku-engine.js# Generation, validation, solving, hints
│   └── storage.js      # localStorage persistence layer
└── README.md
```

## Architecture Notes

- **Sudoku Engine** generates a full valid grid via backtracking, then removes clues while guaranteeing uniqueness (solution-count check ≤ 1).
- Difficulty is controlled by target clue ranges.
- Hints prioritize Naked Singles → Hidden Singles (row/col/box) → direct reveal.
- Game state, settings, stats, learning progress, and daily completions are fully separated and persisted.
- No external dependencies. No accounts. No network required after first load.

## Keyboard Shortcuts (Game)

| Key            | Action                  |
|----------------|-------------------------|
| 1–9            | Enter number / select   |
| Backspace / 0  | Erase                   |
| Arrow keys     | Move selection          |
| N              | Toggle Notes mode       |
| H              | Hint                    |
| Ctrl/Cmd + Z   | Undo                    |
| Ctrl/Cmd + Shift + Z | Redo              |

## License

Built as a complete demonstration project. Free to use and modify.
