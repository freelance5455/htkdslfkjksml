/**
 * Sudoku Zen — Core Engine
 * Generation, validation, solving, candidates, hints
 */

const DIFFICULTY = {
  easy:     { clues: [40, 46], label: 'Easy',     order: 0 },
  medium:   { clues: [32, 38], label: 'Medium',   order: 1 },
  hard:     { clues: [28, 32], label: 'Hard',     order: 2 },
  expert:   { clues: [24, 28], label: 'Expert',   order: 3 },
  hardcore: { clues: [22, 25], label: 'Hardcore', order: 4 },
};

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function emptyGrid() {
  return Array.from({ length: 9 }, () => Array(9).fill(0));
}

function copyGrid(g) {
  return g.map(row => [...row]);
}

function isValid(grid, row, col, num) {
  for (let i = 0; i < 9; i++) {
    if (grid[row][i] === num || grid[i][col] === num) return false;
  }
  const br = Math.floor(row / 3) * 3;
  const bc = Math.floor(col / 3) * 3;
  for (let r = br; r < br + 3; r++) {
    for (let c = bc; c < bc + 3; c++) {
      if (grid[r][c] === num) return false;
    }
  }
  return true;
}

/** Fill a complete valid Sudoku solution via backtracking */
function generateSolution() {
  const grid = emptyGrid();
  const nums = [1, 2, 3, 4, 5, 6, 7, 8, 9];

  function fill(pos) {
    if (pos === 81) return true;
    const row = Math.floor(pos / 9);
    const col = pos % 9;
    if (grid[row][col] !== 0) return fill(pos + 1);

    for (const num of shuffle(nums)) {
      if (isValid(grid, row, col, num)) {
        grid[row][col] = num;
        if (fill(pos + 1)) return true;
        grid[row][col] = 0;
      }
    }
    return false;
  }

  fill(0);
  return grid;
}

/** Count solutions (stop at 2 for uniqueness check) */
function countSolutions(grid, limit = 2) {
  let count = 0;
  const g = copyGrid(grid);

  function solve(pos) {
    if (count >= limit) return;
    if (pos === 81) {
      count++;
      return;
    }
    const row = Math.floor(pos / 9);
    const col = pos % 9;
    if (g[row][col] !== 0) {
      solve(pos + 1);
      return;
    }
    for (let num = 1; num <= 9; num++) {
      if (isValid(g, row, col, num)) {
        g[row][col] = num;
        solve(pos + 1);
        g[row][col] = 0;
        if (count >= limit) return;
      }
    }
  }

  solve(0);
  return count;
}

/** Generate a puzzle with unique solution for given difficulty */
function generatePuzzle(difficulty = 'medium') {
  const cfg = DIFFICULTY[difficulty] || DIFFICULTY.medium;
  const targetClues = cfg.clues[0] + Math.floor(Math.random() * (cfg.clues[1] - cfg.clues[0] + 1));

  let solution = generateSolution();
  let puzzle = copyGrid(solution);

  // Positions to try removing (shuffled)
  const positions = shuffle(
    Array.from({ length: 81 }, (_, i) => [Math.floor(i / 9), i % 9])
  );

  let removed = 0;
  const maxRemove = 81 - targetClues;

  for (const [r, c] of positions) {
    if (removed >= maxRemove) break;
    const backup = puzzle[r][c];
    puzzle[r][c] = 0;
    if (countSolutions(puzzle, 2) === 1) {
      removed++;
    } else {
      puzzle[r][c] = backup;
    }
  }

  // Ensure we have a valid unique puzzle
  if (countSolutions(puzzle, 2) !== 1) {
    // Fallback: regenerate
    return generatePuzzle(difficulty);
  }

  return {
    puzzle,
    solution,
    difficulty,
    clues: 81 - removed,
  };
}

/** Deterministic daily puzzle based on date string YYYY-MM-DD */
function generateDailyPuzzle(dateStr) {
  // Simple seeded RNG from date
  let seed = 0;
  for (let i = 0; i < dateStr.length; i++) {
    seed = (seed * 31 + dateStr.charCodeAt(i)) >>> 0;
  }

  function seededRandom() {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  }

  function seededShuffle(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(seededRandom() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  // Generate solution with seeded shuffle
  const grid = emptyGrid();
  const nums = [1, 2, 3, 4, 5, 6, 7, 8, 9];

  function fill(pos) {
    if (pos === 81) return true;
    const row = Math.floor(pos / 9);
    const col = pos % 9;
    if (grid[row][col] !== 0) return fill(pos + 1);
    for (const num of seededShuffle(nums)) {
      if (isValid(grid, row, col, num)) {
        grid[row][col] = num;
        if (fill(pos + 1)) return true;
        grid[row][col] = 0;
      }
    }
    return false;
  }
  fill(0);
  const solution = copyGrid(grid);
  let puzzle = copyGrid(solution);

  // Medium difficulty for daily (~34 clues)
  const targetClues = 34;
  const positions = seededShuffle(
    Array.from({ length: 81 }, (_, i) => [Math.floor(i / 9), i % 9])
  );
  let removed = 0;
  const maxRemove = 81 - targetClues;

  for (const [r, c] of positions) {
    if (removed >= maxRemove) break;
    const backup = puzzle[r][c];
    puzzle[r][c] = 0;
    if (countSolutions(puzzle, 2) === 1) {
      removed++;
    } else {
      puzzle[r][c] = backup;
    }
  }

  return {
    puzzle,
    solution,
    difficulty: 'medium',
    clues: 81 - removed,
    isDaily: true,
    date: dateStr,
  };
}

/** Get candidates for a cell */
function getCandidates(grid, row, col) {
  if (grid[row][col] !== 0) return [];
  const cands = [];
  for (let n = 1; n <= 9; n++) {
    if (isValid(grid, row, col, n)) cands.push(n);
  }
  return cands;
}

/** Get all candidates for the board */
function getAllCandidates(grid) {
  const cands = Array.from({ length: 9 }, () => Array.from({ length: 9 }, () => []));
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      cands[r][c] = getCandidates(grid, r, c);
    }
  }
  return cands;
}

/** Check if board is fully and correctly solved */
function isSolved(grid, solution) {
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      if (grid[r][c] !== solution[r][c]) return false;
    }
  }
  return true;
}

/** Check conflicts for a cell (duplicates in row/col/box) */
function hasConflict(grid, row, col) {
  const val = grid[row][col];
  if (val === 0) return false;
  for (let i = 0; i < 9; i++) {
    if (i !== col && grid[row][i] === val) return true;
    if (i !== row && grid[i][col] === val) return true;
  }
  const br = Math.floor(row / 3) * 3;
  const bc = Math.floor(col / 3) * 3;
  for (let r = br; r < br + 3; r++) {
    for (let c = bc; c < bc + 3; c++) {
      if ((r !== row || c !== col) && grid[r][c] === val) return true;
    }
  }
  return false;
}

/** Find a hint: prefer naked single, then hidden single */
function findHint(grid, solution) {
  // Naked singles
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      if (grid[r][c] !== 0) continue;
      const cands = getCandidates(grid, r, c);
      if (cands.length === 1) {
        return {
          row: r,
          col: c,
          value: cands[0],
          technique: 'Naked Single',
          explanation: `Cell R${r + 1}C${c + 1} has only one possible number: ${cands[0]}.`,
        };
      }
    }
  }

  // Hidden singles in rows
  for (let r = 0; r < 9; r++) {
    for (let n = 1; n <= 9; n++) {
      const positions = [];
      for (let c = 0; c < 9; c++) {
        if (grid[r][c] === 0 && getCandidates(grid, r, c).includes(n)) {
          positions.push(c);
        }
      }
      if (positions.length === 1) {
        const c = positions[0];
        return {
          row: r,
          col: c,
          value: n,
          technique: 'Hidden Single (Row)',
          explanation: `In row ${r + 1}, the number ${n} can only go in column ${c + 1}.`,
        };
      }
    }
  }

  // Hidden singles in columns
  for (let c = 0; c < 9; c++) {
    for (let n = 1; n <= 9; n++) {
      const positions = [];
      for (let r = 0; r < 9; r++) {
        if (grid[r][c] === 0 && getCandidates(grid, r, c).includes(n)) {
          positions.push(r);
        }
      }
      if (positions.length === 1) {
        const r = positions[0];
        return {
          row: r,
          col: c,
          value: n,
          technique: 'Hidden Single (Column)',
          explanation: `In column ${c + 1}, the number ${n} can only go in row ${r + 1}.`,
        };
      }
    }
  }

  // Hidden singles in boxes
  for (let b = 0; b < 9; b++) {
    const br = Math.floor(b / 3) * 3;
    const bc = (b % 3) * 3;
    for (let n = 1; n <= 9; n++) {
      const positions = [];
      for (let r = br; r < br + 3; r++) {
        for (let c = bc; c < bc + 3; c++) {
          if (grid[r][c] === 0 && getCandidates(grid, r, c).includes(n)) {
            positions.push([r, c]);
          }
        }
      }
      if (positions.length === 1) {
        const [r, c] = positions[0];
        return {
          row: r,
          col: c,
          value: n,
          technique: 'Hidden Single (Box)',
          explanation: `In this 3×3 box, the number ${n} can only go in R${r + 1}C${c + 1}.`,
        };
      }
    }
  }

  // Fallback: reveal a correct cell from solution (last resort)
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      if (grid[r][c] === 0) {
        return {
          row: r,
          col: c,
          value: solution[r][c],
          technique: 'Direct Reveal',
          explanation: `The correct number for R${r + 1}C${c + 1} is ${solution[r][c]}.`,
        };
      }
    }
  }

  return null;
}

/** Count remaining for each number 1-9 */
function countRemaining(grid) {
  const counts = Array(10).fill(9);
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      if (grid[r][c] !== 0) counts[grid[r][c]]--;
    }
  }
  return counts;
}

export {
  DIFFICULTY,
  generatePuzzle,
  generateDailyPuzzle,
  getCandidates,
  getAllCandidates,
  isSolved,
  hasConflict,
  findHint,
  countRemaining,
  copyGrid,
  isValid,
};
