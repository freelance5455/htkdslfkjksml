/**
 * Sudoku Zen — Main Application
 */

import {
  DIFFICULTY,
  generatePuzzle,
  generateDailyPuzzle,
  isSolved,
  hasConflict,
  findHint,
  countRemaining,
  copyGrid,
} from './sudoku-engine.js';

import {
  loadSettings,
  saveSettings,
  loadStats,
  saveStats,
  loadCurrentGame,
  saveCurrentGame,
  clearCurrentGame,
  loadLearning,
  saveLearning,
  loadDaily,
  saveDaily,
  loadAchievements,
  checkAndUnlockAchievements,
  getAchievementDefs,
  resetAllData,
} from './storage.js';

// ─── State ───────────────────────────────────────────────────
let settings = loadSettings();
let stats = loadStats();
let learning = loadLearning();
let currentGame = null;
let selectedCell = null; // { r, c }
let notesMode = false;
let selectedNumber = null; // for number-first input
let history = [];
let historyIndex = -1;
let timerInterval = null;
let paused = false;
let currentScreen = 'home';

// ─── Theme ───────────────────────────────────────────────────
function applyTheme() {
  let theme = settings.theme;
  if (theme === 'system') {
    theme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  document.documentElement.setAttribute('data-theme', theme);
}

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
  if (settings.theme === 'system') applyTheme();
});

// ─── Helpers ─────────────────────────────────────────────────
function $(sel) { return document.querySelector(sel); }
function $all(sel) { return document.querySelectorAll(sel); }

function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function todayStr() {
  // Use local date for daily consistency
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function toast(msg, ms = 2200) {
  const existing = $('.toast');
  if (existing) existing.remove();
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), ms);
}

function pushHistory() {
  if (!currentGame) return;
  // Truncate future if we undid
  history = history.slice(0, historyIndex + 1);
  history.push({
    grid: copyGrid(currentGame.grid),
    notes: currentGame.notes.map(row => row.map(n => new Set(n))),
    mistakes: currentGame.mistakes,
    hintsUsed: currentGame.hintsUsed,
  });
  historyIndex = history.length - 1;
  // Cap history
  if (history.length > 80) {
    history.shift();
    historyIndex--;
  }
}

// ─── Screen routing ──────────────────────────────────────────
function showScreen(name) {
  currentScreen = name;
  const app = $('#app');
  app.innerHTML = '';
  stopTimer();

  switch (name) {
    case 'home': renderHome(app); break;
    case 'game': renderGame(app); break;
    case 'settings': renderSettings(app); break;
    case 'learning': renderLearning(app); break;
    case 'lesson': renderLesson(app, arguments[1]); break;
    case 'stats': renderStats(app); break;
    default: renderHome(app);
  }
}

// ─── Home ────────────────────────────────────────────────────
function renderHome(app) {
  const saved = loadCurrentGame();
  const dailyData = loadDaily();
  const today = todayStr();
  const dailyDone = dailyData[today]?.completed;

  app.innerHTML = `
    <div class="screen">
      <div class="home-logo">
        <h1>Sudoku Zen</h1>
        <p class="tagline">Clear Your Mind. Master the Grid.</p>
      </div>
      <p class="home-greeting">Ready for a little brain training?</p>

      <div class="stats-row">
        <div class="stat-pill">
          <div class="value">${stats.currentStreak}</div>
          <div class="label">Streak</div>
        </div>
        <div class="stat-pill">
          <div class="value">${stats.totalCompleted}</div>
          <div class="label">Completed</div>
        </div>
      </div>

      <div class="daily-card" id="daily-btn">
        <div class="info">
          <h3>Daily Challenge</h3>
          <p>${dailyDone ? 'Completed ✓' : 'A fresh puzzle every day'}</p>
        </div>
        <div class="badge">${dailyDone ? 'Done' : 'Play'}</div>
      </div>

      <div class="btn-group">
        ${saved ? `<button class="btn-primary" id="continue-btn">Continue Game</button>` : ''}
        <button class="btn-primary" id="new-game-btn">${saved ? 'New Game' : 'Start Playing'}</button>
      </div>

      <div class="difficulty-selector">
        <label>Difficulty</label>
        <div class="difficulty-pills" id="diff-pills">
          ${Object.entries(DIFFICULTY).map(([k, v]) =>
            `<button class="diff-pill ${settings.difficulty === k ? 'active' : ''}" data-diff="${k}">${v.label}</button>`
          ).join('')}
        </div>
      </div>

      <div class="home-nav">
        <button class="nav-card" id="learning-btn">
          <div class="icon">📚</div>
          <div class="title">Learning</div>
        </button>
        <button class="nav-card" id="stats-btn">
          <div class="icon">📊</div>
          <div class="title">Statistics</div>
        </button>
        <button class="nav-card" id="settings-btn">
          <div class="icon">⚙️</div>
          <div class="title">Settings</div>
        </button>
        <button class="nav-card" id="how-btn">
          <div class="icon">❓</div>
          <div class="title">How to Play</div>
        </button>
      </div>
    </div>
  `;

  $('#continue-btn')?.addEventListener('click', () => {
    resumeGame(saved);
  });

  $('#new-game-btn').addEventListener('click', () => {
    startNewGame(settings.difficulty);
  });

  $('#daily-btn').addEventListener('click', () => {
    startDailyChallenge();
  });

  $all('.diff-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      settings.difficulty = btn.dataset.diff;
      saveSettings(settings);
      $all('.diff-pill').forEach(b => b.classList.toggle('active', b.dataset.diff === settings.difficulty));
    });
  });

  $('#learning-btn').addEventListener('click', () => showScreen('learning'));
  $('#stats-btn').addEventListener('click', () => showScreen('stats'));
  $('#settings-btn').addEventListener('click', () => showScreen('settings'));
  $('#how-btn').addEventListener('click', () => showScreen('lesson', 0));
}

// ─── Game start / resume ─────────────────────────────────────
function startNewGame(difficulty) {
  toast('Generating puzzle…');
  // Slight delay so UI updates
  setTimeout(() => {
    const data = generatePuzzle(difficulty);
    currentGame = {
      grid: copyGrid(data.puzzle),
      given: data.puzzle.map(row => row.map(v => v !== 0)),
      solution: data.solution,
      notes: Array.from({ length: 9 }, () => Array.from({ length: 9 }, () => new Set())),
      difficulty,
      mistakes: 0,
      hintsUsed: 0,
      elapsed: 0,
      startedAt: Date.now(),
      isDaily: false,
    };
    history = [];
    historyIndex = -1;
    selectedCell = null;
    selectedNumber = null;
    notesMode = settings.notesByDefault;
    paused = false;
    pushHistory();
    saveCurrentGame(serializeGame(currentGame));
    showScreen('game');
  }, 50);
}

function startDailyChallenge() {
  const today = todayStr();
  const dailyStore = loadDaily();
  if (dailyStore[today]?.completed) {
    toast('You already completed today’s challenge!');
    return;
  }
  toast('Loading daily puzzle…');
  setTimeout(() => {
    const data = generateDailyPuzzle(today);
    currentGame = {
      grid: copyGrid(data.puzzle),
      given: data.puzzle.map(row => row.map(v => v !== 0)),
      solution: data.solution,
      notes: Array.from({ length: 9 }, () => Array.from({ length: 9 }, () => new Set())),
      difficulty: 'medium',
      mistakes: 0,
      hintsUsed: 0,
      elapsed: 0,
      startedAt: Date.now(),
      isDaily: true,
      date: today,
    };
    history = [];
    historyIndex = -1;
    selectedCell = null;
    selectedNumber = null;
    notesMode = settings.notesByDefault;
    paused = false;
    pushHistory();
    saveCurrentGame(serializeGame(currentGame));
    showScreen('game');
  }, 50);
}

function resumeGame(saved) {
  currentGame = deserializeGame(saved);
  history = [];
  historyIndex = -1;
  selectedCell = null;
  selectedNumber = null;
  notesMode = settings.notesByDefault;
  paused = false;
  pushHistory();
  showScreen('game');
}

function serializeGame(g) {
  return {
    ...g,
    notes: g.notes.map(row => row.map(s => [...s])),
  };
}

function deserializeGame(s) {
  return {
    ...s,
    notes: s.notes.map(row => row.map(arr => new Set(arr))),
  };
}

// ─── Game Screen ─────────────────────────────────────────────
function renderGame(app) {
  if (!currentGame) {
    showScreen('home');
    return;
  }

  app.innerHTML = `
    <div class="screen">
      <div class="game-header">
        <button class="back-btn" id="exit-btn" title="Exit">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <div class="game-meta">
          <span>${DIFFICULTY[currentGame.difficulty]?.label || currentGame.difficulty}</span>
          ${settings.showTimer ? `<span class="timer" id="timer">${formatTime(currentGame.elapsed)}</span>` : ''}
          ${settings.showMistakes ? `<span class="mistakes" id="mistake-count">Mistakes: ${currentGame.mistakes}</span>` : ''}
        </div>
        <button class="icon-btn" id="pause-btn" title="Pause">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
        </button>
      </div>

      <div class="grid-wrapper" id="grid-wrap">
        <div class="sudoku-grid" id="grid"></div>
      </div>

      <div class="number-pad" id="num-pad"></div>

      <div class="toolbar">
        <button class="tool-btn ${notesMode ? 'active' : ''}" id="notes-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
          Notes
        </button>
        <button class="tool-btn" id="erase-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 20H7L3 16c-1.5-1.5-1.5-3.5 0-5l7-7 11 11v5z"/><path d="M6 11l5 5"/></svg>
          Erase
        </button>
        <button class="tool-btn" id="undo-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 00-9-9 9 9 0 00-6.7 2.9L3 13"/></svg>
          Undo
        </button>
        <button class="tool-btn" id="redo-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 7v6h-6"/><path d="M3 17a9 9 0 019-9 9 9 0 016.7 2.9L21 13"/></svg>
          Redo
        </button>
        <button class="tool-btn" id="hint-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          Hint
        </button>
        <button class="tool-btn" id="restart-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/></svg>
          Restart
        </button>
      </div>
    </div>
  `;

  renderGrid();
  renderNumberPad();
  bindGameEvents();
  startTimer();
}

function renderGrid() {
  const gridEl = $('#grid');
  if (!gridEl || !currentGame) return;
  const { grid, given, notes } = currentGame;
  const counts = countRemaining(grid);

  let html = '';
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      const val = grid[r][c];
      const isGiven = given[r][c];
      const isSelected = selectedCell && selectedCell.r === r && selectedCell.c === c;
      const classes = ['cell'];
      if (isGiven) classes.push('given');
      else if (val) classes.push('player');
      if (isSelected) classes.push('selected');

      // Related (row/col/box)
      if (settings.highlightRelated && selectedCell && !isSelected) {
        const sameRow = selectedCell.r === r;
        const sameCol = selectedCell.c === c;
        const sameBox = Math.floor(selectedCell.r / 3) === Math.floor(r / 3) &&
                        Math.floor(selectedCell.c / 3) === Math.floor(c / 3);
        if (sameRow || sameCol || sameBox) classes.push('related');
      }

      // Matching numbers
      if (settings.highlightMatching && selectedCell) {
        const selVal = grid[selectedCell.r][selectedCell.c];
        if (selVal && val === selVal && !isSelected) classes.push('matching');
      }
      if (settings.highlightMatching && selectedNumber && val === selectedNumber) {
        classes.push('matching');
      }

      // Conflicts
      if (settings.highlightConflicts && val && hasConflict(grid, r, c)) {
        classes.push('conflict');
      }

      let content = '';
      if (val) {
        content = val;
      } else if (notes[r][c].size > 0) {
        content = `<div class="notes">${[1,2,3,4,5,6,7,8,9].map(n =>
          `<span>${notes[r][c].has(n) ? n : ''}</span>`
        ).join('')}</div>`;
      }

      html += `<div class="${classes.join(' ')}" data-r="${r}" data-c="${c}">${content}</div>`;
    }
  }
  gridEl.innerHTML = html;

  // Update number pad counts
  updateNumberPad(counts);
}

function renderNumberPad() {
  const pad = $('#num-pad');
  if (!pad) return;
  const counts = countRemaining(currentGame.grid);
  pad.innerHTML = [1,2,3,4,5,6,7,8,9].map(n => `
    <button class="num-btn ${selectedNumber === n ? 'active' : ''} ${counts[n] <= 0 ? 'complete' : ''}" data-num="${n}">
      ${n}
      ${settings.showNumberCounts ? `<span class="count">${counts[n]}</span>` : ''}
    </button>
  `).join('');
}

function updateNumberPad(counts) {
  $all('.num-btn').forEach(btn => {
    const n = +btn.dataset.num;
    btn.classList.toggle('active', selectedNumber === n);
    btn.classList.toggle('complete', counts[n] <= 0);
    const countEl = btn.querySelector('.count');
    if (countEl) countEl.textContent = counts[n];
  });
}

function bindGameEvents() {
  $('#grid').addEventListener('click', (e) => {
    const cell = e.target.closest('.cell');
    if (!cell || paused) return;
    const r = +cell.dataset.r;
    const c = +cell.dataset.c;
    selectCell(r, c);

    // Number-first: if a number is selected, place it
    if (selectedNumber !== null && !currentGame.given[r][c]) {
      placeNumber(r, c, selectedNumber);
    }
  });

  $all('.num-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (paused) return;
      const n = +btn.dataset.num;
      if (selectedCell && !currentGame.given[selectedCell.r][selectedCell.c]) {
        placeNumber(selectedCell.r, selectedCell.c, n);
      } else {
        // Toggle number selection for number-first mode
        selectedNumber = selectedNumber === n ? null : n;
        renderGrid();
      }
    });
  });

  $('#notes-btn').addEventListener('click', () => {
    notesMode = !notesMode;
    $('#notes-btn').classList.toggle('active', notesMode);
  });

  $('#erase-btn').addEventListener('click', () => {
    if (paused || !selectedCell) return;
    const { r, c } = selectedCell;
    if (currentGame.given[r][c]) return;
    eraseCell(r, c);
  });

  $('#undo-btn').addEventListener('click', undo);
  $('#redo-btn').addEventListener('click', redo);
  $('#hint-btn').addEventListener('click', useHint);
  $('#restart-btn').addEventListener('click', confirmRestart);
  $('#exit-btn').addEventListener('click', confirmExit);
  $('#pause-btn').addEventListener('click', togglePause);

  // Keyboard
  document.onkeydown = handleKey;
}

function selectCell(r, c) {
  selectedCell = { r, c };
  selectedNumber = null;
  renderGrid();
}

function placeNumber(r, c, num) {
  if (currentGame.given[r][c]) return;

  if (notesMode) {
    // Toggle note
    const set = currentGame.notes[r][c];
    if (set.has(num)) set.delete(num);
    else set.add(num);
    currentGame.grid[r][c] = 0;
  } else {
    // Clear notes and place value
    currentGame.notes[r][c].clear();
    const prev = currentGame.grid[r][c];
    currentGame.grid[r][c] = num;

    // Mistake check
    if (num !== currentGame.solution[r][c]) {
      currentGame.mistakes++;
      if (settings.showMistakes) {
        const el = $('#mistake-count');
        if (el) el.textContent = `Mistakes: ${currentGame.mistakes}`;
      }
      if (settings.mistakeLimit > 0 && currentGame.mistakes >= settings.mistakeLimit) {
        toast('Mistake limit reached');
      }
    }
  }

  pushHistory();
  persistGame();
  renderGrid();
  checkWin();
}

function eraseCell(r, c) {
  if (currentGame.given[r][c]) return;
  currentGame.grid[r][c] = 0;
  currentGame.notes[r][c].clear();
  pushHistory();
  persistGame();
  renderGrid();
}

function undo() {
  if (historyIndex <= 0 || paused) return;
  historyIndex--;
  restoreHistory();
}

function redo() {
  if (historyIndex >= history.length - 1 || paused) return;
  historyIndex++;
  restoreHistory();
}

function restoreHistory() {
  const snap = history[historyIndex];
  currentGame.grid = copyGrid(snap.grid);
  currentGame.notes = snap.notes.map(row => row.map(s => new Set(s)));
  currentGame.mistakes = snap.mistakes;
  currentGame.hintsUsed = snap.hintsUsed;
  persistGame();
  renderGrid();
  if (settings.showMistakes) {
    const el = $('#mistake-count');
    if (el) el.textContent = `Mistakes: ${currentGame.mistakes}`;
  }
}

function useHint() {
  if (paused) return;
  if (settings.hintConfirm) {
    // Simple confirm via toast + auto apply after short delay, or just apply
  }
  const hint = findHint(currentGame.grid, currentGame.solution);
  if (!hint) {
    toast('No hint available');
    return;
  }
  currentGame.grid[hint.row][hint.col] = hint.value;
  currentGame.notes[hint.row][hint.col].clear();
  currentGame.hintsUsed++;
  selectedCell = { r: hint.row, c: hint.col };
  pushHistory();
  persistGame();
  renderGrid();
  // Flash the cell
  const cell = $(`.cell[data-r="${hint.row}"][data-c="${hint.col}"]`);
  if (cell) {
    cell.classList.add('hinted');
    setTimeout(() => cell.classList.remove('hinted'), 600);
  }
  toast(`${hint.technique}: ${hint.explanation}`, 3500);
  checkWin();
}

function checkWin() {
  if (!isSolved(currentGame.grid, currentGame.solution)) return;
  stopTimer();
  clearCurrentGame();
  onPuzzleComplete();
}

function onPuzzleComplete() {
  const elapsed = currentGame.elapsed;
  const diff = currentGame.difficulty;
  const mistakes = currentGame.mistakes;
  const hints = currentGame.hintsUsed;

  // Update stats
  stats.totalCompleted++;
  stats.byDifficulty[diff] = (stats.byDifficulty[diff] || 0) + 1;
  stats.totalTime[diff] = (stats.totalTime[diff] || 0) + elapsed;
  if (stats.bestTime[diff] == null || elapsed < stats.bestTime[diff]) {
    stats.bestTime[diff] = elapsed;
  }
  stats.totalHints += hints;
  stats.totalMistakes += mistakes;

  // Streak
  const today = todayStr();
  if (stats.lastPlayDate !== today) {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
    if (stats.lastPlayDate === yStr) {
      stats.currentStreak++;
    } else {
      stats.currentStreak = 1;
    }
    stats.lastPlayDate = today;
    if (stats.currentStreak > stats.longestStreak) {
      stats.longestStreak = stats.currentStreak;
    }
  }
  saveStats(stats);

  // Daily
  if (currentGame.isDaily) {
    const dailyStore = loadDaily();
    dailyStore[currentGame.date] = {
      completed: true,
      time: elapsed,
      mistakes,
      hints,
    };
    saveDaily(dailyStore);
  }

  // Achievements
  const newAch = checkAndUnlockAchievements(stats, { hintsUsed: hints, mistakes });

  // Show modal
  const isBest = stats.bestTime[diff] === elapsed;
  showCompletionModal({ elapsed, mistakes, hints, diff, isBest, newAch });
}

function showCompletionModal({ elapsed, mistakes, hints, diff, isBest, newAch }) {
  const overlay = document.createElement('div');
  overlay.className = 'overlay';
  overlay.innerHTML = `
    <div class="modal">
      <h2>Puzzle Completed!</h2>
      <p>${DIFFICULTY[diff]?.label || diff}${isBest ? ' · Personal Best!' : ''}</p>
      <div class="result-stats">
        <div class="item"><div class="val">${formatTime(elapsed)}</div><div class="lbl">Time</div></div>
        <div class="item"><div class="val">${mistakes}</div><div class="lbl">Mistakes</div></div>
        <div class="item"><div class="val">${hints}</div><div class="lbl">Hints</div></div>
        <div class="item"><div class="val">${stats.currentStreak}</div><div class="lbl">Streak</div></div>
      </div>
      ${newAch.length ? `<p style="color:var(--success);font-weight:600">Achievement unlocked!</p>` : ''}
      <div class="modal-actions">
        <button class="btn-primary" id="next-btn">Next Puzzle</button>
        <button class="btn-secondary" id="home-btn">Return Home</button>
        <button class="btn-secondary" id="share-btn">Share Results</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  $('#next-btn').addEventListener('click', () => {
    overlay.remove();
    startNewGame(diff);
  });
  $('#home-btn').addEventListener('click', () => {
    overlay.remove();
    currentGame = null;
    showScreen('home');
  });
  $('#share-btn').addEventListener('click', () => {
    const text = `Sudoku Zen — ${DIFFICULTY[diff]?.label} completed in ${formatTime(elapsed)} with ${mistakes} mistakes! 🧠`;
    if (navigator.share) {
      navigator.share({ text }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(text);
      toast('Copied to clipboard!');
    }
  });
}

function confirmRestart() {
  if (!confirm('Restart this puzzle? Progress will be lost.')) return;
  // Reset to initial given state
  const given = currentGame.given;
  const solution = currentGame.solution;
  currentGame.grid = given.map((row, r) => row.map((g, c) => g ? solution[r][c] : 0));
  // Actually restore original puzzle values
  // We need the original puzzle. Reconstruct from given + solution
  currentGame.grid = currentGame.given.map((row, r) =>
    row.map((isGiven, c) => isGiven ? currentGame.solution[r][c] : 0)
  );
  currentGame.notes = Array.from({ length: 9 }, () => Array.from({ length: 9 }, () => new Set()));
  currentGame.mistakes = 0;
  currentGame.hintsUsed = 0;
  currentGame.elapsed = 0;
  history = [];
  historyIndex = -1;
  selectedCell = null;
  pushHistory();
  persistGame();
  renderGrid();
  if (settings.showMistakes) {
    const el = $('#mistake-count');
    if (el) el.textContent = 'Mistakes: 0';
  }
  startTimer();
}

function confirmExit() {
  if (!confirm('Leave this game? You can continue later.')) return;
  persistGame();
  currentGame = null;
  showScreen('home');
}

function togglePause() {
  paused = !paused;
  const wrap = $('#grid-wrap');
  if (paused) {
    stopTimer();
    const overlay = document.createElement('div');
    overlay.className = 'pause-overlay';
    overlay.id = 'pause-overlay';
    overlay.innerHTML = `
      <h3>Paused</h3>
      <button class="btn-primary" id="resume-btn" style="width:auto;padding:12px 28px">Resume</button>
    `;
    wrap.appendChild(overlay);
    $('#resume-btn').addEventListener('click', togglePause);
  } else {
    $('#pause-overlay')?.remove();
    startTimer();
  }
}

function startTimer() {
  stopTimer();
  if (!settings.showTimer || paused) return;
  timerInterval = setInterval(() => {
    if (!currentGame || paused) return;
    currentGame.elapsed++;
    const el = $('#timer');
    if (el) el.textContent = formatTime(currentGame.elapsed);
    // Persist every 10s
    if (currentGame.elapsed % 10 === 0) persistGame();
  }, 1000);
}

function stopTimer() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

function persistGame() {
  if (currentGame) saveCurrentGame(serializeGame(currentGame));
}

function handleKey(e) {
  if (currentScreen !== 'game' || !currentGame || paused) return;
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;

  if (e.key >= '1' && e.key <= '9') {
    e.preventDefault();
    const n = +e.key;
    if (selectedCell && !currentGame.given[selectedCell.r][selectedCell.c]) {
      placeNumber(selectedCell.r, selectedCell.c, n);
    } else {
      selectedNumber = selectedNumber === n ? null : n;
      renderGrid();
    }
  } else if (e.key === 'Backspace' || e.key === 'Delete' || e.key === '0') {
    e.preventDefault();
    if (selectedCell) eraseCell(selectedCell.r, selectedCell.c);
  } else if (e.key === 'ArrowUp' && selectedCell) {
    e.preventDefault();
    selectCell(Math.max(0, selectedCell.r - 1), selectedCell.c);
  } else if (e.key === 'ArrowDown' && selectedCell) {
    e.preventDefault();
    selectCell(Math.min(8, selectedCell.r + 1), selectedCell.c);
  } else if (e.key === 'ArrowLeft' && selectedCell) {
    e.preventDefault();
    selectCell(selectedCell.r, Math.max(0, selectedCell.c - 1));
  } else if (e.key === 'ArrowRight' && selectedCell) {
    e.preventDefault();
    selectCell(selectedCell.r, Math.min(8, selectedCell.c + 1));
  } else if (e.key === 'z' && (e.ctrlKey || e.metaKey)) {
    e.preventDefault();
    if (e.shiftKey) redo(); else undo();
  } else if (e.key === 'n' || e.key === 'N') {
    notesMode = !notesMode;
    $('#notes-btn')?.classList.toggle('active', notesMode);
  } else if (e.key === 'h' || e.key === 'H') {
    useHint();
  }
}

// ─── Settings ────────────────────────────────────────────────
function renderSettings(app) {
  app.innerHTML = `
    <div class="screen">
      <div class="screen-header">
        <button class="back-btn" id="back-btn">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <h1 class="screen-title">Settings</h1>
        <div style="width:40px"></div>
      </div>

      <div class="settings-group">
        <h3>Gameplay</h3>
        <div class="settings-card">
          ${toggleRow('showMistakes', 'Show mistakes', 'Display mistake counter')}
          ${toggleRow('highlightConflicts', 'Highlight conflicts', 'Red highlight on duplicates')}
          ${toggleRow('highlightMatching', 'Highlight matching numbers', 'Highlight same numbers')}
          ${toggleRow('highlightRelated', 'Highlight row / column / box', 'Highlight related cells')}
          ${toggleRow('notesByDefault', 'Notes mode by default', 'Start with pencil marks on')}
          ${toggleRow('showNumberCounts', 'Number count indicators', 'Show remaining counts')}
          ${toggleRow('autoCheck', 'Auto-check completed puzzle', 'Detect win automatically')}
        </div>
      </div>

      <div class="settings-group">
        <h3>Appearance</h3>
        <div class="settings-card">
          <div class="setting-row">
            <div class="label">Theme</div>
            <div class="select-wrap">
              <select id="theme-select">
                <option value="system" ${settings.theme === 'system' ? 'selected' : ''}>System</option>
                <option value="light" ${settings.theme === 'light' ? 'selected' : ''}>Light</option>
                <option value="dark" ${settings.theme === 'dark' ? 'selected' : ''}>Dark</option>
              </select>
            </div>
          </div>
          ${toggleRow('animations', 'Animations', 'Enable transitions')}
          ${toggleRow('sound', 'Sound effects', 'Subtle audio feedback')}
        </div>
      </div>

      <div class="settings-group">
        <h3>Timer</h3>
        <div class="settings-card">
          ${toggleRow('showTimer', 'Show timer', 'Display elapsed time')}
          ${toggleRow('pauseOnInactive', 'Pause when inactive', 'Pause timer on tab switch')}
        </div>
      </div>

      <div class="settings-group">
        <h3>Learning & Help</h3>
        <div class="settings-card">
          <div class="setting-row" style="cursor:pointer" id="goto-learning">
            <div class="label">Learning Center</div>
            <span style="color:var(--text-muted)">›</span>
          </div>
          <div class="setting-row" style="cursor:pointer" id="goto-rules">
            <div class="label">Sudoku Rules</div>
            <span style="color:var(--text-muted)">›</span>
          </div>
        </div>
      </div>

      <div class="settings-group">
        <h3>Privacy & About</h3>
        <div class="settings-card">
          <div class="setting-row">
            <div>
              <div class="label">About Sudoku Zen</div>
              <div class="desc">Version 1.0.0 · Local-first, no accounts</div>
            </div>
          </div>
          <div class="setting-row" style="cursor:pointer" id="reset-data">
            <div class="label" style="color:var(--danger)">Reset all game data</div>
          </div>
        </div>
      </div>
    </div>
  `;

  $('#back-btn').addEventListener('click', () => showScreen('home'));

  $all('[data-toggle]').forEach(el => {
    el.addEventListener('change', () => {
      const key = el.dataset.toggle;
      settings[key] = el.checked;
      saveSettings(settings);
      if (key === 'sound' || key === 'animations') { /* future */ }
    });
  });

  $('#theme-select').addEventListener('change', (e) => {
    settings.theme = e.target.value;
    saveSettings(settings);
    applyTheme();
  });

  $('#goto-learning').addEventListener('click', () => showScreen('learning'));
  $('#goto-rules').addEventListener('click', () => showScreen('lesson', 0));
  $('#reset-data').addEventListener('click', () => {
    if (confirm('This will erase all progress, statistics, and settings. Continue?')) {
      resetAllData();
      settings = loadSettings();
      stats = loadStats();
      learning = loadLearning();
      applyTheme();
      toast('All data reset');
      showScreen('home');
    }
  });
}

function toggleRow(key, label, desc) {
  return `
    <div class="setting-row">
      <div>
        <div class="label">${label}</div>
        ${desc ? `<div class="desc">${desc}</div>` : ''}
      </div>
      <label class="toggle">
        <input type="checkbox" data-toggle="${key}" ${settings[key] ? 'checked' : ''}>
        <span class="slider"></span>
      </label>
    </div>
  `;
}

// ─── Learning Center ─────────────────────────────────────────
const LESSONS = [
  {
    title: 'Sudoku Basics',
    desc: 'The grid, rows, columns, and boxes',
    content: `
      <p>Sudoku is played on a 9×9 grid, divided into nine 3×3 boxes.</p>
      <ul>
        <li>Each <strong>row</strong> must contain the numbers 1–9 with no repeats.</li>
        <li>Each <strong>column</strong> must contain 1–9 with no repeats.</li>
        <li>Each <strong>3×3 box</strong> must contain 1–9 with no repeats.</li>
      </ul>
      <p>The puzzle starts with some numbers already filled in (the “givens”). Your job is to fill the rest correctly.</p>
    `,
  },
  {
    title: 'How to Start',
    desc: 'Scanning and finding singles',
    content: `
      <p>Begin by scanning rows, columns, and boxes for cells that can only hold one number.</p>
      <ul>
        <li>Look for a row that is missing only one number — place it.</li>
        <li>Do the same for columns and boxes.</li>
        <li>When a cell has only one possible candidate, fill it in (Naked Single).</li>
      </ul>
      <p>These simple steps solve many Easy puzzles completely.</p>
    `,
  },
  {
    title: 'Candidate Notes',
    desc: 'Pencil marks and elimination',
    content: `
      <p>When a cell has several possible numbers, write small “notes” (pencil marks) in the cell.</p>
      <ul>
        <li>Toggle Notes mode, then tap numbers to add or remove candidates.</li>
        <li>As you place numbers elsewhere, eliminate candidates that become impossible.</li>
        <li>When only one candidate remains, you have a Naked Single.</li>
      </ul>
    `,
  },
  {
    title: 'Single Candidates',
    desc: 'Naked & Hidden Singles',
    content: `
      <p><strong>Naked Single:</strong> A cell that has only one remaining candidate. Fill it immediately.</p>
      <p><strong>Hidden Single:</strong> A number that can go in only one cell within a row, column, or box — even if that cell still has other candidates. Place the number and clear the rest.</p>
      <p>These two techniques solve the majority of Easy and Medium puzzles.</p>
    `,
  },
  {
    title: 'Intermediate Techniques',
    desc: 'Pairs and pointing',
    content: `
      <p><strong>Naked Pair:</strong> Two cells in the same unit (row/col/box) that contain exactly the same two candidates. Those two numbers can be eliminated from all other cells in that unit.</p>
      <p><strong>Hidden Pair:</strong> Two numbers that appear as candidates in only two cells of a unit. Those cells can keep only those two numbers.</p>
      <p><strong>Pointing Pair / Box-Line Reduction:</strong> If a candidate in a box appears only in one row (or column), it can be eliminated from the rest of that row (or column) outside the box.</p>
    `,
  },
  {
    title: 'Advanced Techniques',
    desc: 'X-Wing, Swordfish & more',
    content: `
      <p><strong>X-Wing:</strong> When a candidate appears in exactly two cells of two different rows, and those cells align in the same two columns, the candidate can be eliminated from the rest of those columns (and vice-versa for columns→rows).</p>
      <p><strong>Swordfish:</strong> An extension of X-Wing to three rows and three columns.</p>
      <p>These patterns are powerful but less common. Most Expert and Hardcore puzzles can still be solved with careful singles, pairs, and box-line reductions — advanced techniques just speed things up.</p>
      <p>Remember: a well-designed Sudoku never requires guessing. Every number has a logical path.</p>
    `,
  },
];

function renderLearning(app) {
  app.innerHTML = `
    <div class="screen">
      <div class="screen-header">
        <button class="back-btn" id="back-btn">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <h1 class="screen-title">Learning Center</h1>
        <div style="width:40px"></div>
      </div>
      <p style="color:var(--text-secondary);margin-bottom:16px;font-size:0.9rem">
        ${learning.completed.length} of ${LESSONS.length} lessons completed
      </p>
      ${LESSONS.map((l, i) => `
        <div class="lesson-card ${learning.completed.includes(i) ? 'completed' : ''}" data-lesson="${i}">
          <div class="num">${learning.completed.includes(i) ? '✓' : i + 1}</div>
          <div class="content">
            <h4>${l.title}</h4>
            <p>${l.desc}</p>
          </div>
        </div>
      `).join('')}
    </div>
  `;

  $('#back-btn').addEventListener('click', () => showScreen('home'));
  $all('.lesson-card').forEach(card => {
    card.addEventListener('click', () => showScreen('lesson', +card.dataset.lesson));
  });
}

function renderLesson(app, index = 0) {
  const lesson = LESSONS[index];
  if (!lesson) {
    showScreen('learning');
    return;
  }

  app.innerHTML = `
    <div class="screen">
      <div class="screen-header">
        <button class="back-btn" id="back-btn">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <h1 class="screen-title">Lesson ${index + 1}</h1>
        <div style="width:40px"></div>
      </div>
      <div class="lesson-detail">
        <h2>${lesson.title}</h2>
        ${lesson.content}
      </div>
      <div class="btn-group">
        <button class="btn-primary" id="complete-btn">
          ${learning.completed.includes(index) ? 'Completed ✓' : 'Mark as Complete'}
        </button>
        ${index < LESSONS.length - 1
          ? `<button class="btn-secondary" id="next-lesson">Next Lesson</button>`
          : `<button class="btn-secondary" id="back-learning">Back to Learning</button>`}
      </div>
    </div>
  `;

  $('#back-btn').addEventListener('click', () => showScreen('learning'));
  $('#complete-btn').addEventListener('click', () => {
    if (!learning.completed.includes(index)) {
      learning.completed.push(index);
      saveLearning(learning);
      toast('Lesson completed!');
      $('#complete-btn').textContent = 'Completed ✓';
    }
  });
  $('#next-lesson')?.addEventListener('click', () => showScreen('lesson', index + 1));
  $('#back-learning')?.addEventListener('click', () => showScreen('learning'));
}

// ─── Statistics ──────────────────────────────────────────────
function renderStats(app) {
  const achDefs = getAchievementDefs();
  const unlocked = loadAchievements();

  const avg = (diff) => {
    const count = stats.byDifficulty[diff] || 0;
    if (!count) return '—';
    return formatTime(Math.round((stats.totalTime[diff] || 0) / count));
  };
  const best = (diff) => stats.bestTime[diff] != null ? formatTime(stats.bestTime[diff]) : '—';

  app.innerHTML = `
    <div class="screen">
      <div class="screen-header">
        <button class="back-btn" id="back-btn">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <h1 class="screen-title">Statistics</h1>
        <div style="width:40px"></div>
      </div>

      <div class="stat-grid">
        <div class="stat-card"><div class="value">${stats.totalCompleted}</div><div class="label">Total Solved</div></div>
        <div class="stat-card"><div class="value">${stats.currentStreak}</div><div class="label">Current Streak</div></div>
        <div class="stat-card"><div class="value">${stats.longestStreak}</div><div class="label">Longest Streak</div></div>
        <div class="stat-card"><div class="value">${stats.totalHints}</div><div class="label">Hints Used</div></div>
      </div>

      <h3 style="font-size:0.8rem;text-transform:uppercase;letter-spacing:0.05em;color:var(--text-secondary);margin-bottom:10px">By Difficulty</h3>
      <div class="settings-card" style="margin-bottom:20px">
        ${Object.keys(DIFFICULTY).map(d => `
          <div class="setting-row">
            <div class="label">${DIFFICULTY[d].label}</div>
            <div style="text-align:right;font-size:0.85rem;color:var(--text-secondary)">
              ${stats.byDifficulty[d] || 0} solved<br>
              Best ${best(d)} · Avg ${avg(d)}
            </div>
          </div>
        `).join('')}
      </div>

      <h3 style="font-size:0.8rem;text-transform:uppercase;letter-spacing:0.05em;color:var(--text-secondary);margin-bottom:10px">Achievements</h3>
      <div class="achievements">
        ${achDefs.map(a => `
          <div class="achievement ${unlocked.includes(a.id) ? '' : 'locked'}">
            <div class="icon">${a.icon}</div>
            <div class="info">
              <h4>${a.title}</h4>
              <p>${a.desc}</p>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  $('#back-btn').addEventListener('click', () => showScreen('home'));
}

// ─── Init ────────────────────────────────────────────────────
function init() {
  applyTheme();
  showScreen('home');

  // Visibility pause
  document.addEventListener('visibilitychange', () => {
    if (settings.pauseOnInactive && currentScreen === 'game' && currentGame) {
      if (document.hidden && !paused) {
        // soft pause timer only
        stopTimer();
      } else if (!document.hidden && !paused) {
        startTimer();
      }
    }
  });
}

init();
