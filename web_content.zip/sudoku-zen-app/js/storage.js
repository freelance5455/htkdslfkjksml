/**
 * Sudoku Zen — Persistence Layer
 */

const KEYS = {
  settings: 'sz_settings',
  stats: 'sz_stats',
  currentGame: 'sz_current_game',
  learning: 'sz_learning',
  daily: 'sz_daily',
  achievements: 'sz_achievements',
};

const DEFAULT_SETTINGS = {
  difficulty: 'medium',
  showMistakes: true,
  highlightConflicts: true,
  highlightMatching: true,
  highlightRelated: true,
  notesByDefault: false,
  showNumberCounts: true,
  hintConfirm: true,
  mistakeLimit: 0, // 0 = unlimited
  autoCheck: true,
  theme: 'system', // system | light | dark
  animations: true,
  reducedMotion: false,
  sound: false,
  showTimer: true,
  pauseOnInactive: true,
};

const DEFAULT_STATS = {
  totalCompleted: 0,
  byDifficulty: { easy: 0, medium: 0, hard: 0, expert: 0, hardcore: 0 },
  bestTime: { easy: null, medium: null, hard: null, expert: null, hardcore: null },
  totalTime: { easy: 0, medium: 0, hard: 0, expert: 0, hardcore: 0 },
  currentStreak: 0,
  longestStreak: 0,
  lastPlayDate: null,
  totalHints: 0,
  totalMistakes: 0,
};

const DEFAULT_LEARNING = {
  completed: [],
};

const ACHIEVEMENTS = [
  { id: 'first', title: 'First Puzzle', desc: 'Complete your first puzzle', icon: '🎯' },
  { id: 'five', title: 'Getting Started', desc: 'Complete 5 puzzles', icon: '🔥' },
  { id: 'ten', title: 'Dedicated', desc: 'Complete 10 puzzles', icon: '💪' },
  { id: 'hard', title: 'Hard Mode', desc: 'Complete a Hard puzzle', icon: '🧠' },
  { id: 'expert', title: 'Expert Solver', desc: 'Complete an Expert puzzle', icon: '⭐' },
  { id: 'hardcore', title: 'Hardcore Conqueror', desc: 'Complete a Hardcore puzzle', icon: '👑' },
  { id: 'streak7', title: 'Seven-Day Streak', desc: 'Play 7 days in a row', icon: '📅' },
  { id: 'hintfree', title: 'Hint-Free Victory', desc: 'Complete a puzzle without hints', icon: '✨' },
  { id: 'perfect', title: 'Perfect Game', desc: 'Complete with 0 mistakes and 0 hints', icon: '💎' },
];

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (raw == null) return structuredClone(fallback);
    return { ...structuredClone(fallback), ...JSON.parse(raw) };
  } catch {
    return structuredClone(fallback);
  }
}

function save(key, data) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.warn('Storage save failed', e);
  }
}

export function loadSettings() {
  return load(KEYS.settings, DEFAULT_SETTINGS);
}

export function saveSettings(s) {
  save(KEYS.settings, s);
}

export function loadStats() {
  return load(KEYS.stats, DEFAULT_STATS);
}

export function saveStats(s) {
  save(KEYS.stats, s);
}

export function loadCurrentGame() {
  try {
    const raw = localStorage.getItem(KEYS.currentGame);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function saveCurrentGame(game) {
  if (!game) {
    localStorage.removeItem(KEYS.currentGame);
    return;
  }
  save(KEYS.currentGame, game);
}

export function clearCurrentGame() {
  localStorage.removeItem(KEYS.currentGame);
}

export function loadLearning() {
  return load(KEYS.learning, DEFAULT_LEARNING);
}

export function saveLearning(l) {
  save(KEYS.learning, l);
}

export function loadDaily() {
  try {
    const raw = localStorage.getItem(KEYS.daily);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function saveDaily(d) {
  save(KEYS.daily, d);
}

export function loadAchievements() {
  try {
    const raw = localStorage.getItem(KEYS.achievements);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveAchievements(a) {
  save(KEYS.achievements, a);
}

export function checkAndUnlockAchievements(stats, gameResult) {
  const unlocked = loadAchievements();
  const newly = [];

  const has = (id) => unlocked.includes(id);
  const unlock = (id) => {
    if (!has(id)) {
      unlocked.push(id);
      newly.push(id);
    }
  };

  if (stats.totalCompleted >= 1) unlock('first');
  if (stats.totalCompleted >= 5) unlock('five');
  if (stats.totalCompleted >= 10) unlock('ten');
  if (stats.byDifficulty.hard >= 1) unlock('hard');
  if (stats.byDifficulty.expert >= 1) unlock('expert');
  if (stats.byDifficulty.hardcore >= 1) unlock('hardcore');
  if (stats.longestStreak >= 7 || stats.currentStreak >= 7) unlock('streak7');

  if (gameResult) {
    if (gameResult.hintsUsed === 0) unlock('hintfree');
    if (gameResult.hintsUsed === 0 && gameResult.mistakes === 0) unlock('perfect');
  }

  if (newly.length) saveAchievements(unlocked);
  return newly;
}

export function getAchievementDefs() {
  return ACHIEVEMENTS;
}

export function resetAllData() {
  Object.values(KEYS).forEach(k => localStorage.removeItem(k));
}

export { DEFAULT_SETTINGS, DEFAULT_STATS, ACHIEVEMENTS };
