W.A.S — Workers Attendance System
===================================

Files:
- index.html
- style.css
- script.js

Open index.html in a modern browser.

Notes:
- This is a prototype using localStorage.
- GPS requires browser location permission and generally works best from HTTPS or localhost.
- Passwords are stored in localStorage for prototype testing only. Do not use this authentication model in production.
- Production should use a backend, secure password hashing, server-side authorization and server-side GPS/attendance validation.
