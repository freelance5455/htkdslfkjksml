(() => {
  "use strict";

  const KEYS = {
    admins: "was_admins_v1",
    workers: "was_workers_v1",
    attendance: "was_attendance_v1",
    session: "was_admin_session_v1",
    captcha: "was_captcha_v1"
  };

  const $ = (id) => document.getElementById(id);
  const load = (key, fallback = []) => {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
    catch { return fallback; }
  };
  const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));
  const today = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  };
  const formatDate = (date = today()) => {
    const d = new Date(date + "T00:00:00");
    return d.toLocaleDateString(undefined, {year:"numeric", month:"long", day:"numeric"});
  };
  const timeNow = () => new Date().toLocaleTimeString(undefined, {hour:"2-digit",minute:"2-digit",second:"2-digit"});
  const escapeHtml = (s="") => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const normalize = s => String(s || "").trim().toLowerCase();

  function showMessage(text, type="info") {
    const box = $("messageBox");
    box.textContent = text;
    box.className = `message ${type}`;
    clearTimeout(showMessage.timer);
    showMessage.timer = setTimeout(() => box.classList.add("hidden"), 5000);
    window.scrollTo({top:0, behavior:"smooth"});
  }

  function page(id) {
    document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
    $(id).classList.add("active");
    window.scrollTo({top:0, behavior:"smooth"});
  }

  function currentSession() {
    const s = load(KEYS.session, null);
    if (!s) return null;
    if (s.date !== today()) {
      localStorage.removeItem(KEYS.session);
      return null;
    }
    const admins = load(KEYS.admins);
    return admins.find(a => a.adminId === s.adminId) || null;
  }

  function setTopActions() {
    const admin = currentSession();
    $("topActions").innerHTML = admin
      ? `<button class="btn small outline" data-action="logout">Logout</button>`
      : "";
  }

  function randomChars(n) {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
    let out = "";
    for (let i=0;i<n;i++) out += chars[Math.floor(Math.random()*chars.length)];
    return out;
  }

  function generateAdminId(admins) {
    let id;
    do {
      const code = String(Math.floor(10 + Math.random()*90)) + randomChars(1).toUpperCase();
      const num = String(Math.floor(10000 + Math.random()*90000));
      id = "AAS" + code + num;
    } while (admins.some(a => a.adminId === id));
    return id;
  }

  function generateWorkerId(admin, workers) {
    const prefix = "WAS" + admin.adminId.slice(3,5);
    let id;
    do {
      id = prefix + String(Math.floor(100 + Math.random()*900));
    } while (workers.some(w => w.adminId === admin.adminId && w.workerId === id));
    return id;
  }

  function makeCaptcha() {
    const value = randomChars(5);
    save(KEYS.captcha, value);
    $("captchaText").textContent = value;
  }

  function adminAttendanceOpen(admin) {
    return admin.attendanceDate === today() && admin.attendanceOpen === true;
  }

  function getWorkers(adminId) {
    return load(KEYS.workers).filter(w => w.adminId === adminId);
  }

  function getRecords(adminId) {
    return load(KEYS.attendance).filter(r => r.adminId === adminId);
  }

  function updateAdminDashboard() {
    const admin = currentSession();
    if (!admin) { page("adminLoginPage"); setTopActions(); return; }

    $("dashBusinessName").textContent = admin.businessName;
    $("dashAdminName").textContent = admin.fullName;
    $("dashDate").textContent = formatDate();
    $("infoBusiness").textContent = admin.businessName;
    $("infoAdmin").textContent = admin.fullName;
    $("infoAdminId").textContent = admin.adminId;
    $("infoPhone").textContent = admin.phone;

    const open = adminAttendanceOpen(admin);
    const badge = $("attendanceStatusBadge");
    badge.textContent = open ? "OPEN" : "CLOSED";
    badge.className = "status " + (open ? "open" : "closed");
    $("attendanceControlText").textContent = open
      ? "Workers can check in if they pass GPS verification."
      : "Workers cannot check in while attendance is closed.";
    $("openAttendanceBtn").disabled = open;
    $("closeAttendanceBtn").disabled = !open;

    $("gpsLat").textContent = admin.workplace?.lat ?? "—";
    $("gpsLng").textContent = admin.workplace?.lng ?? "—";
    $("gpsRadius").textContent = admin.workplace?.radius ?? "—";
    $("gpsSummary").textContent = admin.workplace
      ? "Workplace location is configured and ready for GPS verification."
      : "Workplace GPS has not been configured.";

    const workers = getWorkers(admin.adminId);
    $("workerCount").textContent = workers.length;
    $("workersTableBody").innerHTML = workers.length ? workers.map(w => `
      <tr><td>${escapeHtml(w.name)}</td><td>${escapeHtml(w.workerId)}</td><td>${escapeHtml(w.phone)}</td><td>${escapeHtml(w.dob)}</td></tr>
    `).join("") : `<tr><td colspan="4" class="empty-state">No workers registered yet.</td></tr>`;

    renderHistory();
    setTopActions();
  }

  function renderHistory() {
    const admin = currentSession();
    if (!admin) return;
    const id = normalize($("searchWorkerId").value);
    const name = normalize($("searchWorkerName").value);
    const date = $("searchDate").value;

    let records = getRecords(admin.adminId).filter(r => {
      const idOk = !id || normalize(r.workerId).includes(id);
      const nameOk = !name || normalize(r.workerName).includes(name);
      const dateOk = !date || r.date === date;
      return idOk && nameOk && dateOk;
    }).sort((a,b) => (b.date+b.checkIn).localeCompare(a.date+a.checkIn));

    $("attendanceTableBody").innerHTML = records.map(r => `
      <tr>
        <td>${escapeHtml(r.workerName)}</td>
        <td>${escapeHtml(r.workerId)}</td>
        <td>${escapeHtml(r.date)}</td>
        <td>${escapeHtml(r.checkIn || "—")}</td>
        <td>${escapeHtml(r.checkOut || "—")}</td>
        <td>${Number.isFinite(r.distance) ? r.distance.toFixed(1)+" m" : "—"}</td>
        <td>${escapeHtml(r.status)}</td>
        <td>${escapeHtml(r.checkoutReason || "—")}</td>
      </tr>
    `).join("");
    $("historyEmpty").classList.toggle("hidden", records.length !== 0);
  }

  function openAdminDashboard() {
    if (!currentSession()) {
      showMessage("Your admin session has expired. Please login again.", "info");
      page("adminLoginPage");
      return;
    }
    page("adminDashboardPage");
    updateAdminDashboard();
  }

  function findWorker(workerId) {
    return load(KEYS.workers).find(w => normalize(w.workerId) === normalize(workerId));
  }

  function getWorkerTodayRecord(worker) {
    return load(KEYS.attendance).find(r => r.workerId === worker.workerId && r.date === today());
  }

  function showWorkerPanel(worker) {
    const admins = load(KEYS.admins);
    const admin = admins.find(a => a.adminId === worker.adminId);
    if (!admin) {
      showMessage("The worker's admin account could not be found.", "error");
      return;
    }
    window.currentWorkerId = worker.workerId;
    $("workerLookup").classList.add("hidden");
    $("workerAttendancePanel").classList.remove("hidden");
    $("workerDashName").textContent = worker.name;
    $("workerDashId").textContent = worker.workerId;
    $("workerDashDate").textContent = formatDate();
    $("workerInfoName").textContent = worker.name;
    $("workerInfoId").textContent = worker.workerId;
    $("workerInfoBusiness").textContent = admin.businessName;
    $("workerInfoAdmin").textContent = admin.adminId;
    refreshWorkerPanel();
  }

  function refreshWorkerPanel() {
    const worker = findWorker(window.currentWorkerId);
    if (!worker) return;
    const admin = load(KEYS.admins).find(a => a.adminId === worker.adminId);
    const open = admin && adminAttendanceOpen(admin);
    const record = getWorkerTodayRecord(worker);

    const badge = $("workerAttendanceBadge");
    badge.textContent = open ? "OPEN" : "CLOSED";
    badge.className = "status " + (open ? "open" : "closed");

    $("workerAttendanceMessage").textContent = !admin
      ? "Admin account unavailable."
      : !open && !record
        ? "Attendance is currently CLOSED by admin."
        : record?.status === "Present"
          ? record.checkOut
            ? "Attendance completed for today."
            : "You are marked Present. You may check out when needed."
          : "Attendance is OPEN. GPS verification is required for check-in.";

    $("workerCheckInBtn").disabled = !open || !!record;
    $("workerCheckOutBtn").disabled = !record || !!record.checkOut;
    $("checkoutReason").disabled = !record || !!record.checkOut;

    if (record) {
      $("record-box");
      $("workerRecord").classList.remove("hidden");
      $("workerRecord").innerHTML = `
        <strong>Check-in:</strong> ${escapeHtml(record.checkIn || "—")}<br>
        <strong>Check-out:</strong> ${escapeHtml(record.checkOut || "—")}<br>
        <strong>GPS Distance:</strong> ${Number.isFinite(record.distance) ? record.distance.toFixed(1)+" meters" : "—"}<br>
        <strong>Status:</strong> ${escapeHtml(record.status)}<br>
        <strong>Reason:</strong> ${escapeHtml(record.checkoutReason || "—")}
      `;
    } else {
      $("workerRecord").classList.add("hidden");
      $("workerRecord").innerHTML = "";
    }

    if (record?.checkOut) {
      $("workerAttendanceMessage").textContent = "Attendance completed for today.";
    }
  }

  function haversine(lat1, lon1, lat2, lon2) {
    const R = 6371000;
    const toRad = x => x * Math.PI / 180;
    const dLat = toRad(lat2-lat1);
    const dLon = toRad(lon2-lon1);
    const a = Math.sin(dLat/2)**2 +
      Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  }

  function getHighAccuracyPosition() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error("Geolocation is not supported by this browser."));
        return;
      }
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0
      });
    });
  }

  async function workerCheckIn() {
    const worker = findWorker(window.currentWorkerId);
    if (!worker) return showMessage("Worker not found.", "error");
    const admin = load(KEYS.admins).find(a => a.adminId === worker.adminId);
    if (!admin || !adminAttendanceOpen(admin)) return showMessage("Attendance is currently closed by admin.", "error");
    if (!admin.workplace) return showMessage("Workplace GPS has not been configured.", "error");
    if (getWorkerTodayRecord(worker)) return showMessage("You have already checked in today.", "info");

    $("workerCheckInBtn").disabled = true;
    $("workerGpsStatus").textContent = "Getting high-accuracy GPS location…";
    try {
      const pos = await getHighAccuracyPosition();
      const {latitude, longitude, accuracy} = pos.coords;
      $("workerAccuracy").textContent = Number.isFinite(accuracy) ? `${accuracy.toFixed(1)} m` : "Unavailable";

      // This threshold is intentionally conservative for a prototype.
      if (Number.isFinite(accuracy) && accuracy > 200) {
        $("workerGpsStatus").textContent = "GPS accuracy is too low. Please move to an open area and try again.";
        $("workerCheckInBtn").disabled = false;
        return;
      }

      const distance = haversine(admin.workplace.lat, admin.workplace.lng, latitude, longitude);
      $("workerDistance").textContent = `${distance.toFixed(1)} m`;

      if (distance > admin.workplace.radius) {
        $("workerGpsStatus").textContent = `You are outside the allowed workplace radius (${admin.workplace.radius} m).`;
        showMessage("You are outside the allowed workplace radius.", "error");
        $("workerCheckInBtn").disabled = false;
        return;
      }

      const attendance = load(KEYS.attendance);
      attendance.push({
        workerName: worker.name,
        workerId: worker.workerId,
        adminId: admin.adminId,
        businessName: admin.businessName,
        date: today(),
        checkIn: timeNow(),
        checkOut: null,
        workerLatitude: latitude,
        workerLongitude: longitude,
        distance,
        gpsAccuracy: accuracy ?? null,
        status: "Present",
        checkoutReason: ""
      });
      save(KEYS.attendance, attendance);
      $("workerGpsStatus").textContent = "GPS verified. Check-in successful.";
      showMessage("Check-in successful. You are marked Present.", "success");
      refreshWorkerPanel();
    } catch (err) {
      $("workerGpsStatus").textContent = "Unable to get GPS location.";
      $("workerCheckInBtn").disabled = false;
      if (err.code === 1) showMessage("Location permission was denied. Please allow location access and try again.", "error");
      else if (err.code === 2) showMessage("Unable to determine your GPS location.", "error");
      else if (err.code === 3) showMessage("GPS request timed out. Please try again.", "error");
      else showMessage("Unable to get GPS location.", "error");
    }
  }

  function workerCheckOut() {
    const worker = findWorker(window.currentWorkerId);
    if (!worker) return showMessage("Worker not found.", "error");
    const record = getWorkerTodayRecord(worker);
    if (!record) return showMessage("You have not checked in today.", "error");
    if (record.checkOut) return showMessage("Attendance completed for today.", "info");

    const reason = $("checkoutReason").value.trim();
    if (!reason) return showMessage("Please enter a reason for leaving.", "error");

    const all = load(KEYS.attendance);
    const idx = all.findIndex(r => r.workerId === worker.workerId && r.date === today());
    if (idx < 0) return showMessage("You have not checked in today.", "error");
    all[idx].checkOut = timeNow();
    all[idx].checkoutReason = reason;
    save(KEYS.attendance, all);
    $("checkoutReason").value = "";
    showMessage("Check-out successful. Attendance completed for today.", "success");
    refreshWorkerPanel();
  }

  function exportCsv() {
    const admin = currentSession();
    if (!admin) return showMessage("Please login again.", "error");

    const id = normalize($("searchWorkerId").value);
    const name = normalize($("searchWorkerName").value);
    const date = $("searchDate").value;
    const records = getRecords(admin.adminId).filter(r =>
      (!id || normalize(r.workerId).includes(id)) &&
      (!name || normalize(r.workerName).includes(name)) &&
      (!date || r.date === date)
    );

    const headers = ["Worker Name","Worker ID","Admin ID","Business Name","Date","Check-in","Check-out","GPS Distance","Status","Checkout Reason"];
    const csvEscape = v => `"${String(v ?? "").replace(/"/g,'""')}"`;
    const rows = records.map(r => [
      r.workerName,r.workerId,r.adminId,r.businessName,r.date,r.checkIn,r.checkOut,
      Number.isFinite(r.distance) ? r.distance.toFixed(1)+" meters" : "",r.status,r.checkoutReason
    ]);
    const csv = [headers,...rows].map(row => row.map(csvEscape).join(",")).join("\r\n");
    const blob = new Blob(["\uFEFF"+csv], {type:"text/csv;charset=utf-8"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `WAS_Attendance_${date || today()}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
    showMessage(`${records.length} attendance record(s) exported.`, "success");
  }

  document.addEventListener("click", e => {
    const action = e.target.closest("[data-action]")?.dataset.action;
    if (!action) return;
    if (action === "show-admin-login") page("adminLoginPage");
    if (action === "show-admin-register") { page("adminRegisterPage"); makeCaptcha(); }
    if (action === "show-worker") { page("workerPage"); $("workerLookup").classList.remove("hidden"); $("workerAttendancePanel").classList.add("hidden"); }
    if (action === "home") page("homePage");
    if (action === "logout") {
      localStorage.removeItem(KEYS.session);
      window.currentWorkerId = null;
      page("homePage"); setTopActions(); showMessage("Logged out successfully.", "success");
    }
    if (action === "worker-reset") {
      window.currentWorkerId = null;
      $("workerLookup").classList.remove("hidden");
      $("workerAttendancePanel").classList.add("hidden");
      $("workerLookupId").value = "";
    }
  });

  $("refreshCaptcha").addEventListener("click", makeCaptcha);

  $("adminRegisterForm").addEventListener("submit", e => {
    e.preventDefault();
    const businessName = $("regBusinessName").value.trim();
    const fullName = $("regAdminName").value.trim();
    const dob = $("regDob").value;
    const phone = $("regPhone").value.trim();
    const password = $("regPassword").value;
    const confirm = $("regConfirmPassword").value;
    const captcha = $("regCaptcha").value.trim();
    const expected = load(KEYS.captcha, "");

    if (!businessName || !fullName || !dob || !phone || !password || !confirm || !captcha)
      return showMessage("Please fill all required fields.", "error");
    if (password !== confirm) return showMessage("Passwords do not match.", "error");
    if (captcha !== expected) return showMessage("Incorrect CAPTCHA.", "error");

    const admins = load(KEYS.admins);
    const adminId = generateAdminId(admins);
    admins.push({
      adminId, businessName, fullName, dob, phone,
      // Prototype only. Production must use server-side password hashing.
      password,
      attendanceDate: today(),
      attendanceOpen: false,
      workplace: null,
      createdAt: new Date().toISOString()
    });
    save(KEYS.admins, admins);
    $("adminRegisterForm").reset();

    $("messageBox").className = "message success";
    $("messageBox").innerHTML = `Registration successful.<br><strong>Admin ID: ${escapeHtml(adminId)}</strong><br>Please save your Admin ID and password.`;
    page("adminLoginPage");
    $("loginAdminId").value = adminId;
    makeCaptcha();
  });

  $("adminLoginForm").addEventListener("submit", e => {
    e.preventDefault();
    const adminId = $("loginAdminId").value.trim().toUpperCase();
    const password = $("loginAdminPassword").value;
    const admins = load(KEYS.admins);
    const admin = admins.find(a => a.adminId === adminId && a.password === password);
    if (!admin) return showMessage("Invalid Admin ID or password.", "error");

    save(KEYS.session, {adminId: admin.adminId, date: today()});
    $("loginAdminPassword").value = "";
    page("adminDashboardPage");
    updateAdminDashboard();
    showMessage("Login successful.", "success");
  });

  $("openAttendanceBtn").addEventListener("click", () => {
    const admin = currentSession();
    if (!admin) return;
    const admins = load(KEYS.admins);
    const i = admins.findIndex(a => a.adminId === admin.adminId);
    admins[i].attendanceDate = today();
    admins[i].attendanceOpen = true;
    save(KEYS.admins, admins);
    updateAdminDashboard();
    showMessage("Attendance is now OPEN.", "success");
  });

  $("closeAttendanceBtn").addEventListener("click", () => {
    const admin = currentSession();
    if (!admin) return;
    const admins = load(KEYS.admins);
    const i = admins.findIndex(a => a.adminId === admin.adminId);
    admins[i].attendanceDate = today();
    admins[i].attendanceOpen = false;
    save(KEYS.admins, admins);
    updateAdminDashboard();
    showMessage("Attendance is now CLOSED.", "success");
  });

  $("setGpsBtn").addEventListener("click", async () => {
    const admin = currentSession();
    if (!admin) return;
    const radius = Number($("radiusInput").value);
    if (!Number.isFinite(radius) || radius < 1) return showMessage("Please enter a valid allowed radius.", "error");
    try {
      showMessage("Getting high-accuracy GPS location…", "info");
      const pos = await getHighAccuracyPosition();
      const {latitude, longitude, accuracy} = pos.coords;
      if (Number.isFinite(accuracy) && accuracy > 200)
        return showMessage("GPS accuracy is too low. Please move to an open area and try again.", "error");

      const admins = load(KEYS.admins);
      const i = admins.findIndex(a => a.adminId === admin.adminId);
      admins[i].workplace = {lat: latitude, lng: longitude, radius, accuracy: accuracy ?? null};
      save(KEYS.admins, admins);
      updateAdminDashboard();
      showMessage("Workplace GPS location saved successfully.", "success");
    } catch {
      showMessage("Unable to get GPS location. Please allow location access.", "error");
    }
  });

  $("workerRegisterForm").addEventListener("submit", e => {
    e.preventDefault();
    const admin = currentSession();
    if (!admin) return showMessage("Your admin session has expired. Please login again.", "error");

    const name = $("workerName").value.trim();
    const phone = $("workerPhone").value.trim();
    const dob = $("workerDob").value;
    if (!name || !phone || !dob) return showMessage("Please fill all required fields.", "error");

    const workers = load(KEYS.workers);
    const workerId = generateWorkerId(admin, workers);
    workers.push({workerId, adminId: admin.adminId, name, phone, dob, createdAt:new Date().toISOString()});
    save(KEYS.workers, workers);
    $("workerRegisterForm").reset();
    $("newWorkerResult").classList.remove("hidden");
    $("newWorkerResult").innerHTML = `<strong>Worker registered successfully.</strong><br>Worker ID: <strong>${escapeHtml(workerId)}</strong><br>Give this Worker ID to the worker.`;
    updateAdminDashboard();
    showMessage("Worker registered successfully.", "success");
  });

  ["searchWorkerId","searchWorkerName","searchDate"].forEach(id => {
    $(id).addEventListener("input", renderHistory);
    $(id).addEventListener("change", renderHistory);
  });
  $("clearSearchBtn").addEventListener("click", () => {
    $("searchWorkerId").value = "";
    $("searchWorkerName").value = "";
    $("searchDate").value = "";
    renderHistory();
  });
  $("exportCsvBtn").addEventListener("click", exportCsv);

  $("workerLookupForm").addEventListener("submit", e => {
    e.preventDefault();
    const worker = findWorker($("workerLookupId").value.trim());
    if (!worker) return showMessage("Worker ID not found.", "error");
    showWorkerPanel(worker);
  });
  $("workerCheckInBtn").addEventListener("click", workerCheckIn);
  $("workerCheckOutBtn").addEventListener("click", workerCheckOut);

  // Keep daily rules correct if the page remains open over midnight.
  let lastDate = today();
  setInterval(() => {
    const now = today();
    if (now !== lastDate) {
      lastDate = now;
      localStorage.removeItem(KEYS.session);
      if ($("adminDashboardPage").classList.contains("active")) {
        page("adminLoginPage");
        setTopActions();
        showMessage("A new calendar day has started. Please login again.", "info");
      }
      if ($("workerAttendancePanel").classList.contains("active")) refreshWorkerPanel();
    }
  }, 15000);

  // Initial state
  setTopActions();
  page("homePage");
  if (!localStorage.getItem(KEYS.captcha)) makeCaptcha();
})();
