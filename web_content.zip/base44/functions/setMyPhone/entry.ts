import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { normalizePhone, isValidPhone } from '../../shared/phone.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));

    if (!body.phone || String(body.phone).trim() === '') {
      await base44.asServiceRole.entities.User.update(user.id, { phone: '' });
      return Response.json({ phone: '' });
    }

    const normalized = normalizePhone(body.phone);
    if (!isValidPhone(normalized)) {
      return Response.json({ error: 'Enter a valid 10-digit mobile number.' }, { status: 400 });
    }

    const found = await base44.asServiceRole.entities.User.filter({ phone: normalized });
    const users = Array.isArray(found) ? found : (found?.items || []);
    const others = users.filter((row) => row.id !== user.id);
    if (others.length > 0) {
      return Response.json(
        { error: 'That number is already linked to another account.' },
        { status: 409 }
      );
    }

    await base44.asServiceRole.entities.User.update(user.id, { phone: normalized });
    return Response.json({ phone: normalized });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}