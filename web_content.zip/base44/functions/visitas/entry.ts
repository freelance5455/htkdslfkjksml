import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

/* Registro de visitantes de TiempoHoy.
   - record:  guarda la visita (IP + geolocalización aproximada + dispositivo)
   - gps:     añade el GPS exacto a una visita
   - list / favorite / delete: requieren la contraseña del panel (2087) */

const CLAVE = '2087';

async function geoPorIp(ip) {
  if (!ip || ip === 'desconocida') return null;

  const fuentes = [
    async () => {
      const res = await fetch(`https://ipwho.is/${encodeURIComponent(ip)}`);
      if (!res.ok) return null;
      const d = await res.json();
      if (!d || d.success === false) return null;
      return {
        ciudad: d.city || '',
        region: d.region || '',
        pais: d.country || '',
        isp: d.connection?.isp || d.connection?.org || '',
        lat: typeof d.latitude === 'number' ? d.latitude : undefined,
        lon: typeof d.longitude === 'number' ? d.longitude : undefined
      };
    },
    async () => {
      const res = await fetch(`http://ip-api.com/json/${encodeURIComponent(ip)}?fields=status,country,regionName,city,lat,lon,isp`);
      if (!res.ok) return null;
      const d = await res.json();
      if (!d || d.status !== 'success') return null;
      return { ciudad: d.city || '', region: d.regionName || '', pais: d.country || '', isp: d.isp || '', lat: d.lat, lon: d.lon };
    },
    async () => {
      const res = await fetch(`https://freeipapi.com/api/json/${encodeURIComponent(ip)}`);
      if (!res.ok) return null;
      const d = await res.json();
      if (!d || !d.countryName) return null;
      return { ciudad: d.cityName || '', region: d.regionName || '', pais: d.countryName || '', isp: '', lat: d.latitude, lon: d.longitude };
    }
  ];

  for (const fuente of fuentes) {
    try {
      const geo = await fuente();
      if (geo) return geo;
    } catch {
      /* siguiente fuente */
    }
  }
  return null;
}

function ipDe(req) {
  const fwd = req.headers.get('x-forwarded-for') || '';
  const ip = (fwd.split(',')[0] || req.headers.get('cf-connecting-ip') || req.headers.get('x-real-ip') || '').trim();
  return ip || 'desconocida';
}

export default async function (req) {
  try {
    const body = await req.json().catch(() => ({}));
    const action = body.action;
    const base44 = createClientFromRequest(req);

    if (action === 'record') {
      const ip = ipDe(req);
      const geo = await geoPorIp(ip);
      const visita = await base44.asServiceRole.entities.Visita.create({
        ip,
        ciudad: geo?.ciudad || '',
        region: geo?.region || '',
        pais: geo?.pais || '',
        isp: geo?.isp || '',
        lat: geo?.lat,
        lon: geo?.lon,
        dispositivo: String(body.dispositivo || '').slice(0, 40),
        sistema: String(body.sistema || '').slice(0, 40),
        navegador: String(body.navegador || '').slice(0, 60),
        origen: String(body.origen || '').slice(0, 80),
        referrer: String(body.referrer || '').slice(0, 300),
        userAgent: String(body.userAgent || '').slice(0, 400),
        favorito: false
      });
      return Response.json({ ok: true, id: visita.id });
    }

    if (action === 'gps') {
      const id = String(body.id || '');
      if (!id) return Response.json({ ok: false, error: 'Falta la visita' }, { status: 400 });
      const lat = Number(body.lat);
      const lon = Number(body.lon);
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
        return Response.json({ ok: false, error: 'Coordenadas no válidas' }, { status: 400 });
      }
      await base44.asServiceRole.entities.Visita.update(id, {
        gpsLat: lat,
        gpsLon: lon,
        gpsPrecision: Number.isFinite(Number(body.precisicion || body.precision)) ? Number(body.precisicion || body.precision) : undefined
      });
      return Response.json({ ok: true });
    }

    // A partir de aquí hace falta la contraseña del panel
    if (String(body.password || '') !== CLAVE) {
      return Response.json({ ok: false, error: 'Contraseña incorrecta' });
    }

    if (action === 'list') {
      const visitas = await base44.asServiceRole.entities.Visita.list('-created_date', 500);
      const visits = (visitas || []).map(v => ({
        id: v.id,
        ip: v.ip,
        ciudad: v.ciudad,
        region: v.region,
        pais: v.pais,
        isp: v.isp,
        lat: v.lat,
        lon: v.lon,
        gpsLat: v.gpsLat,
        gpsLon: v.gpsLon,
        gpsPrecision: v.gpsPrecision,
        dispositivo: v.dispositivo,
        sistema: v.sistema,
        navegador: v.navegador,
        origen: v.origen,
        favorito: !!v.favorito,
        createdAt: v.created_date
      }));
      return Response.json({ ok: true, visits });
    }

    if (action === 'favorite') {
      const id = String(body.id || '');
      if (!id) return Response.json({ ok: false, error: 'Falta la visita' }, { status: 400 });
      await base44.asServiceRole.entities.Visita.update(id, { favorito: !!body.favorite });
      return Response.json({ ok: true });
    }

    if (action === 'delete') {
      const id = String(body.id || '');
      if (!id) return Response.json({ ok: false, error: 'Falta la visita' }, { status: 400 });
      await base44.asServiceRole.entities.Visita.delete(id);
      return Response.json({ ok: true });
    }

    return Response.json({ ok: false, error: 'Acción no reconocida' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}