import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { normalizePhone, isValidPhone } from '../../shared/phone.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const normalized = normalizePhone(body.phone);

    if (!isValidPhone(normalized)) {
      return Response.json({ error: 'Enter a valid mobile number.' }, { status: 400 });
    }

    const found = await base44.asServiceRole.entities.User.filter({ phone: normalized });
    const users = Array.isArray(found) ? found : (found?.items || []);

    if (users.length !== 1) {
      return Response.json(
        { error: 'No account is linked to that number yet. Sign in with your email, or add your number from your account page.' },
        { status: 404 }
      );
    }

    return Response.json({ email: users[0].email });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}