MEDIVISION ADVISORY - ANDROID APP STARTER PACKAGE

This package contains:
1) www/ - an installable Progressive Web App (PWA) version of the current website.
2) android-app/ - an Android Studio WebView wrapper project, with the website bundled locally.

IMPORTANT LIMITATIONS
- This is a starter app/prototype, not a finished production marketplace.
- Enquiry buttons use the website's configured contact flow. No backend database, supplier login, real order processing, stock verification, payment processing or commission settlement is implemented.
- Do not collect patient medical records or sensitive health information in this app.
- The Android project source is provided; a signed APK/AAB has NOT been compiled in this environment. Build it in Android Studio after reviewing and testing.

INSTALLABLE APP WITHOUT PLAY STORE (PWA)
1. Upload the CONTENTS of the www folder to a static HTTPS host (for example Cloudflare Pages Direct Upload).
2. Open the deployed HTTPS site in Chrome on Android.
3. Chrome menu > Install app (or Add to Home screen).

ANDROID APK / PLAY STORE BUILD
1. Open android-app/ in Android Studio on a computer.
2. Allow Gradle sync and install Android SDK 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) for a test APK.
4. For Google Play, use Build > Generate Signed Bundle / APK > Android App Bundle (AAB), create and safely back up your signing key, then upload the AAB in Play Console.
5. Replace the default app icon with branded adaptive launcher icons before release; complete privacy policy, Data safety, content rating, testing and Play review.

GOOGLE PLAY ACCOUNT
Google currently lists a US$25 one-time Play Console registration fee. New personal developer accounts may need a closed test with at least 12 opted-in testers for 14 continuous days before applying for production access. Check current official requirements before paying or publishing:
https://support.google.com/googleplay/android-developer/answer/6112435
https://support.google.com/googleplay/android-developer/answer/14151465


BUILD STATUS
This archive contains Android source code, not a compiled APK. A valid APK requires Android SDK + Gradle build tools. Build in Android Studio: open android-app/, wait for Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). The debug APK will be in app/build/outputs/apk/debug/.
