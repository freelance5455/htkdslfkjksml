MedNest Medicine Reminder — prototype package

Files:
- index.html: responsive medicine reminder app
- manifest.webmanifest: installable web app metadata
- sw.js: basic offline cache when hosted over HTTPS or localhost

Features implemented in this prototype:
- Add/edit/delete medicine entries; long names are supported
- Up to four reminder times per medicine in the form
- Selected weekdays and start/end dates
- Dose instructions, meal notes and free-text notes
- Mark individual scheduled times Taken, Snoozed or Skipped (skip reason optional)
- Daily list, local history, CSV export, JSON backup/restore
- English/Telugu UI toggle
- Browser notification request and foreground timer check

Important limitations:
- This is a web/PWA prototype, not a compiled Android APK.
- Browser notifications here are checked while the page is running; this does NOT provide reliable background alarms when the browser/app is closed or the phone restarts.
- For dependable Android alarms, this must be ported to a native Android app using AlarmManager/notifications and tested on the target phones.
- Data is stored in browser localStorage and may be lost if browser data is cleared. Export backups.
- No medical advice is provided; use clinician-prescribed instructions only.

To try locally, open index.html in a modern browser. For PWA installation/offline cache, host these files over HTTPS; opening a local file may not enable service workers.
