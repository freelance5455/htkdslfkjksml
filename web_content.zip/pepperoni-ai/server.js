import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.disable("x-powered-by");
app.use(express.json({ limit: "40kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: "The AI key isn't set up yet. Add OPENAI_API_KEY to your .env file and restart the server." });
  }
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message) return res.status(400).json({ error: "Type a message first." });
  if (message.length > 4000) return res.status(413).json({ error: "That message is too long. Please keep it under 4,000 characters." });

  const suppliedHistory = Array.isArray(req.body?.history) ? req.body.history : [];
  const history = suppliedHistory
    .filter(item => item && ["user", "assistant"].includes(item.role) && typeof item.content === "string")
    .slice(-16)
    .map(item => ({ role: item.role, content: item.content.slice(0, 4000) }));

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions: "You are Pepperoni AI, a friendly, upbeat gaming assistant with a playful pizza theme. Help with video games, game design, walkthroughs, tips, coding projects, and fun challenges. Be clear, encouraging, and age-appropriate. Do not pretend to know live game updates unless you have a source. If unsure, say so. Keep most replies concise but provide detail when asked. Never claim to have performed actions outside this chat.",
      input: [...history, { role: "user", content: message }],
      max_output_tokens: 700
    });
    const reply = response.output_text?.trim();
    if (!reply) return res.status(502).json({ error: "The AI returned an empty reply. Try again." });
    res.json({ reply });
  } catch (error) {
    console.error("OpenAI request failed:", error?.status || error?.message || "Unknown error");
    if (error?.status === 401) return res.status(502).json({ error: "The AI key was rejected. Check your OPENAI_API_KEY in .env." });
    if (error?.status === 429) return res.status(429).json({ error: "The API has hit a usage or billing limit. Check your API account and try again." });
    res.status(502).json({ error: "Pepperoni couldn't reach the AI service just now. Check your internet and API account, then try again." });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Pepperoni AI is running at http://localhost:${port}`);
});
