const chat = document.querySelector("#chat");
const form = document.querySelector("#chatForm");
const input = document.querySelector("#messageInput");
const sendBtn = document.querySelector("#sendBtn");
const notice = document.querySelector("#notice");
const clearBtn = document.querySelector("#clearBtn");
let history = [];
let busy = false;

function addMessage(role, text, extraClass = "") {
  const row = document.createElement("article");
  row.className = `message ${role} ${extraClass}`.trim();
  if (role !== "user") {
    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = "🍕";
    row.appendChild(avatar);
  }
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  const p = document.createElement("p");
  p.textContent = text;
  bubble.appendChild(p);
  row.appendChild(bubble);
  chat.appendChild(row);
  chat.scrollTop = chat.scrollHeight;
  row.scrollIntoView({ behavior: "smooth", block: "end" });
  return row;
}

function setBusy(value) {
  busy = value;
  sendBtn.disabled = value;
  input.disabled = value;
  sendBtn.textContent = value ? "…" : "➤";
}

async function sendMessage(raw) {
  const message = raw.trim();
  if (!message || busy) return;
  notice.textContent = "";
  addMessage("user", message);
  input.value = "";
  input.style.height = "auto";
  const typing = addMessage("assistant", "Pepperoni is thinking…", "typing");
  setBusy(true);
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, history })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "The AI request failed. Please try again.");
    typing.querySelector(".bubble p").textContent = data.reply;
    typing.classList.remove("typing");
    history.push({ role: "user", content: message }, { role: "assistant", content: data.reply });
    history = history.slice(-16);
  } catch (error) {
    typing.remove();
    notice.textContent = error.message || "Could not reach Pepperoni AI. Check your connection and server.";
  } finally {
    setBusy(false);
    input.focus();
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  sendMessage(input.value);
});
input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 140) + "px";
});
input.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});
document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});
clearBtn.addEventListener("click", () => {
  if (busy) return;
  history = [];
  chat.replaceChildren();
  notice.textContent = "";
  addMessage("assistant", "Fresh match! 🍕 I'm Pepperoni AI, your gaming sidekick. What are we playing today?");
});
