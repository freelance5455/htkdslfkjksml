# Pepperoni AI 🍕🎮

A purple, mobile-friendly gaming chatbot. The frontend is plain HTML/CSS/JavaScript; the Node.js server keeps your API key off the browser and sends messages to the OpenAI Responses API.

## Important

- You need an OpenAI API key to use the real AI. API usage may cost money and is separate from a ChatGPT subscription.
- Never put your API key in `index.html` or `app.js`. Keep it in `.env` on the server.
- Opening `index.html` directly from a phone's file manager is not enough for real AI; the server must be running and reachable.

## Run it on a computer

1. Install Node.js (current LTS) from https://nodejs.org/.
2. Extract this ZIP and open a terminal in the `pepperoni-ai` folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to a new file named `.env`.
5. Open `.env` and replace `your_api_key_here` with your API key from https://platform.openai.com/api-keys. Do not share the key.
6. Start Pepperoni AI:
   ```bash
   npm start
   ```
7. Open http://localhost:3000 in your browser.

## Use it on Android

### Easiest option: run the server on a computer
1. Run the server using the steps above.
2. Connect your Android phone and the computer to the same Wi-Fi.
3. Find the computer's local IP address (for example `192.168.1.20`).
4. On the phone, open `http://COMPUTER-IP:3000` in Chrome, replacing `COMPUTER-IP` with that address.
5. If it does not load, allow Node.js through the computer firewall on your private network. Do not expose this development server directly to the public internet.

### Run directly on Android (more advanced)
1. Install Termux from its official source: https://termux.dev/.
2. Extract the project into a folder accessible to Termux, then open Termux and `cd` into that folder.
3. Install Node.js using `pkg update && pkg install nodejs`.
4. Run `npm install`, create `.env` from `.env.example`, add your API key, then run `npm start`.
5. Open `http://127.0.0.1:3000` in Android Chrome.

Termux commands vary by installation. If the project is in Android shared storage, you may need `termux-setup-storage` and to move into the correct folder.

## Troubleshooting

- **AI key isn't set up:** ensure the file is named `.env` (not `.env.example.txt`) and has `OPENAI_API_KEY=sk-...`, then restart the server.
- **API key rejected:** create/check the key in the OpenAI API platform.
- **Usage/billing limit:** check your API account limits and billing.
- **Phone cannot connect to computer:** use the same Wi-Fi, the correct computer IP and port `3000`, and check the firewall.
- **Model unavailable:** set `OPENAI_MODEL` in `.env` to a model available to your API project.

## Files

- `public/index.html` — chat interface
- `public/style.css` — purple mobile design
- `public/app.js` — chat behaviour
- `server.js` — secure server-side API calls
- `.env.example` — safe template for configuration
