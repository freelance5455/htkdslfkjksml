/* Rift Mate - saved drafts panel, meta extras, effects settings. Loaded last. */
(function(){
'use strict';
const $=id=>document.getElementById(id);
const A=()=>lang==='ar';
const L=(a,e)=>A()?a:e;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const store=k=>{try{return JSON.parse(mraStorage.getItem(k)||'[]')}catch(e){return[]}};
/* ---------- saved drafts ---------- */
function ensureCard(){
  if($('savedDraftsCard'))return;
  const anchor=$('saveDraft');if(!anchor)return;
  const host=anchor.closest('.card')||anchor.parentElement;
  const d=document.createElement('div');d.className='card';d.id='savedDraftsCard';d.style.marginTop='14px';
  host.parentElement.insertBefore(d,host.nextSibling);
}
function renderSaved(){
  ensureCard();const el=$('savedDraftsCard');if(!el)return;
  const a=store('mra_drafts');
  const chips=(o)=>Object.entries(o||{}).map(([lane,id])=>{const c=CHAMPS.find(x=>x.id===id);return c?`<span class="chip" title="${esc(roleAr[lane]||lane)}">${img(c)}${esc(displayName(c))}</span>`:''}).join('')||'<span class="muted small">—</span>';
  el.innerHTML=`<div class="row between"><h2>${L('الدرافتات المحفوظة','Saved drafts')}</h2><span class="tag">${a.length}</span></div>`+(a.length?a.map((x,i)=>`<div class="saved-draft" style="display:block;padding:10px 4px;border-top:1px solid rgba(255,255,255,.07)"><div class="row between"><b>${new Date(x.date).toLocaleString(A()?'ar-EG':'en-US')}</b><span><button class="btn primary" data-sd-load="${i}">${L('فتح','Open')}</button> <button class="btn ghost" data-sd-del="${i}">${L('حذف','Delete')}</button></span></div><div class="small muted">${L('فريقك','Your team')}</div><div class="chips">${chips(x.draft&&x.draft.ally)}</div><div class="small muted">${L('الخصم','Enemy')}</div><div class="chips">${chips(x.draft&&x.draft.enemy)}</div></div>`).join(''):`<div class="empty">${L('لا توجد درافتات محفوظة بعد. اختار أبطال واضغط حفظ.','No saved drafts yet. Pick champions and press Save.')}</div>`);
  el.querySelectorAll('[data-sd-load]').forEach(b=>b.onclick=()=>{const x=store('mra_drafts')[+b.dataset.sdLoad];if(!x)return;draft=JSON.parse(JSON.stringify(x.draft));try{renderSlots();renderDraftPool()}catch(e){console.error(e)}try{scoreDraft();analyzeComp()}catch(e){}toast(L('تم فتح الدرافت المحفوظ','Saved draft opened'));window.scrollTo({top:0,behavior:'smooth'})});
  el.querySelectorAll('[data-sd-del]').forEach(b=>b.onclick=()=>{const a=store('mra_drafts');a.splice(+b.dataset.sdDel,1);mraStorage.setItem('mra_drafts',JSON.stringify(a));const c=$('savedCount');if(c)c.textContent=a.length;renderSaved()});
}
/* ---------- meta extras ---------- */
let metaSort='tier';
function metaExtras(){
  const t=$('metaTable');if(!t)return;
  let bar=$('metaExtra');
  if(!bar){bar=document.createElement('div');bar.id='metaExtra';t.parentElement.insertBefore(bar,t)}
  const lane=$('metaLane')?.value||'all';
  const rows=(lane==='all'?CHAMPS:CHAMPS.filter(c=>(c.roles||[c.lane]).includes(lane)));
  const st=rows.filter(c=>c.stats&&c.stats.winRate!=null);
  const top=(k,n)=>st.slice().sort((a,b)=>b.stats[k]-a.stats[k]).slice(0,n);
  const list=(k)=>top(k,5).map(c=>`<span class="chip">${img(c)}${esc(displayName(c))} <b dir="ltr">${c.stats[k]}%</b></span>`).join('');
  const missing=rows.filter(c=>!(c.stats&&c.stats.winRate!=null));
  const tiers={};rows.forEach(c=>{tiers[c.tier]=(tiers[c.tier]||0)+1});
  bar.innerHTML=`<div class="card" style="margin:10px 0"><div class="row"><label>${L('الترتيب','Sort')}</label><select id="metaSortSel"><option value="tier">${L('حسب الفئة (Tier)','By Tier')}</option><option value="winRate">${L('الأعلى فوزًا','Highest win rate')}</option><option value="pickRate">${L('الأعلى اختيارًا','Most picked')}</option><option value="banRate">${L('الأعلى حظرًا','Most banned')}</option></select></div>
  <h4>${L('الأعلى نسبة فوز','Top win rate')}</h4><div class="chips">${list('winRate')}</div>
  <h4>${L('الأكثر اختيارًا','Most picked')}</h4><div class="chips">${list('pickRate')}</div>
  <h4>${L('الأكثر حظرًا','Most banned')}</h4><div class="chips">${list('banRate')}</div>
  <h4>${L('توزيع الفئات','Tier distribution')}</h4><div class="chips">${Object.keys(tiers).sort((a,b)=>tierScore(b)-tierScore(a)).map(k=>`<span class="chip">${k} <b>${tiers[k]}</b></span>`).join('')}</div>
  <p class="small muted">${L(`إحصائيات الرانكد الموثقة متوفرة لـ ${st.length} من ${rows.length} بطل في هذا العرض`,`Documented ranked stats available for ${st.length} of ${rows.length} champions in this view`)}${missing.length?L(` · غير متوفرة: ${missing.map(displayName).join('، ')}. لا تتوفر بيانات موثقة حاليًا ولا يتم تقديرها.`,` · unavailable: ${missing.map(displayName).join(', ')}. No documented data available; not estimated.`):''}</p></div>`;
  const sel=$('metaSortSel');sel.value=metaSort;sel.onchange=()=>{metaSort=sel.value;renderMeta()};
  // sort + translate tags
  const wrap=t.querySelector('.meta-cards');
  if(wrap){
    const cards=[...wrap.children];
    const val=(el,key)=>{const m=new RegExp(key+'\\s*([\\d.]+)%').exec(el.textContent.replace(/نسبة الفوز|الاختيار|الحظر/g,x=>({'نسبة الفوز':'WR','الاختيار':'Pick','الحظر':'Ban'}[x])));return m?+m[1]:-1};
    if(metaSort!=='tier'){const key={winRate:'WR',pickRate:'Pick',banRate:'Ban'}[metaSort];cards.sort((a,b)=>val(b,key)-val(a,key));cards.forEach((c,i)=>{wrap.appendChild(c);const r=c.querySelector('.rank');if(r)r.textContent=String(i+1).padStart(2,'0')})}
    if(A())wrap.querySelectorAll('.tag').forEach(x=>{x.textContent=x.textContent.replace(/^WR /,'فوز ').replace(/^Pick /,'اختيار ').replace(/^Ban /,'حظر ')});
  }
}
/* ---------- effects settings ---------- */
const FX={tap:'mra_fx_tap',emoji:'mra_fx_emoji',motion:'mra_fx_motion',smooth:'mra_fx_smooth',haptic:'mra_fx_haptic'};
const on=k=>mraStorage.getItem(FX[k])!=='0';
const EMO=/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u2B50\u2B06\u2194-\u21AA]\uFE0F?\s?/gu;
const emoOrig=new Map();
function applyEmoji(){
  const root=$('app')||document.body;
  if(on('emoji')){emoOrig.forEach((v,n)=>{if(n.isConnected)n.nodeValue=v});emoOrig.clear();return}
  const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n,l=[];
  while(n=w.nextNode()){if(/[\u{1F300}-\u{1FAFF}]/u.test(n.nodeValue)&&!n.parentElement.closest('script,style,select,option'))l.push(n)}
  l.forEach(n=>{emoOrig.set(n,n.nodeValue);n.nodeValue=n.nodeValue.replace(/[\u{1F300}-\u{1FAFF}]\uFE0F?\s?/gu,'')});
}
function applyFx(){
  document.body.classList.toggle('fx-motion-off',!on('motion'));
  document.body.classList.toggle('fx-smooth',on('smooth'));
  document.documentElement.style.scrollBehavior=on('smooth')?'smooth':'auto';
  applyEmoji();
}
function settingsPanel(){
  if($('fxPanel'))return;
  const anchor=$('sfxToggle')?.closest('.sound-panel');if(!anchor)return;
  const p=document.createElement('div');p.className='sound-panel';p.id='fxPanel';
  const rows=[['tap','✨ تأثير الضغط على الأيقونات والأزرار','Tap effect on icons and buttons'],['haptic','📳 اهتزاز خفيف عند الضغط (لو الجهاز بيدعمه)','Light vibration on tap (if supported)'],['motion','🎬 مؤثرات الحركة (انتقال الصفحات والبطاقات)','Motion effects (page and card transitions)'],['smooth','🧈 تمرير سلس','Smooth scrolling'],['emoji','😀 الإيموجي في الواجهة','Emojis in the interface']];
  p.innerHTML=`<div class="sound-head"><div><b id="fxTitle"></b><div class="muted small" id="fxSub"></div></div></div>`+rows.map(r=>`<div class="fxrow" style="display:flex;justify-content:space-between;align-items:center;padding:10px 4px;border-top:1px solid rgba(255,255,255,.07)"><div><b data-fx-label="${r[0]}"></b></div><input type="checkbox" data-fx="${r[0]}" style="width:20px"></div>`).join('');
  anchor.parentElement.insertBefore(p,anchor.nextSibling);
  p.querySelectorAll('[data-fx]').forEach(i=>{i.checked=on(i.dataset.fx);i.onchange=()=>{mraStorage.setItem(FX[i.dataset.fx],i.checked?'1':'0');applyFx()}});
  p._rows=rows;labelFx();
}
function labelFx(){
  const p=$('fxPanel');if(!p)return;
  $('fxTitle').textContent=L('المؤثرات والحركة','Effects & motion');$('fxSub').textContent=L('كل خيار له زرار تشغيل/إيقاف مستقل','Each option has its own on/off switch');
  p._rows.forEach(r=>{p.querySelector('[data-fx-label="'+r[0]+'"]').textContent=L(r[1],r[2])});
}
document.addEventListener('pointerdown',e=>{
  const t=e.target.closest('button,.btn,.champ,.nav-item,[data-go],.item,.chip,.result');if(!t)return;
  if(on('haptic')&&navigator.vibrate)try{navigator.vibrate(8)}catch(_){}
  if(!on('tap'))return;
  const r=document.createElement('span');r.className='fx-ripple';const b=t.getBoundingClientRect();
  r.style.left=(e.clientX-b.left)+'px';r.style.top=(e.clientY-b.top)+'px';
  const cs=getComputedStyle(t);if(cs.position==='static')t.style.position='relative';t.style.overflow=t.style.overflow||'hidden';
  t.appendChild(r);setTimeout(()=>r.remove(),600);
},true);
function init(){
  settingsPanel();renderSaved();applyFx();
  $('saveDraft')?.addEventListener('click',()=>setTimeout(renderSaved,30));
  $('resetDraft')?.addEventListener('click',()=>setTimeout(renderSaved,30));
  document.querySelectorAll('.stat-saved,#savedCount').forEach(el=>{const c=el.closest('.card')||el;c.style.cursor='pointer';c.addEventListener('click',()=>{go('draft');setTimeout(()=>$('savedDraftsCard')?.scrollIntoView({behavior:'smooth'}),80)})});
  const _rm=window.renderMeta;if(_rm){window.renderMeta=function(){const r=_rm.apply(this,arguments);try{metaExtras()}catch(e){console.error(e)}return r};if($('metaLane'))$('metaLane').onchange=()=>renderMeta();try{renderMeta()}catch(e){}}

/* ---------- builds under picked champions in team slots ---------- */
function slotBuilds(){
  document.querySelectorAll('.slot-build').forEach(e=>e.remove());return; /* v4.0.13: البيلد يظهر فقط داخل معلومات البطل */
  const lanes=['Baron','Jungle','Mid','Dragon','Support'];
  ['ally','enemy'].forEach(side=>{
    const box=$(side+'Slots');if(!box)return;
    box.querySelectorAll('.lane-teamrow').forEach((row,i)=>{
      const role=lanes[i],c=CHAMPS.find(x=>x.id===draft[side][role]);
      row.querySelector('.slot-build')?.remove();
      if(!c)return;
      const g=(WRC_DB.guides||{})[c.name];const b=((g&&g.builds)||[]).find(x=>!x.lane||x.lane===role)||((g&&g.builds)||[])[0];
      const d=document.createElement('div');d.className='slot-build';d.style.cssText='grid-column:1/-1;width:100%;padding:6px 0';
      d.innerHTML=b&&window.WRC4?`<small class="muted">${A()?'البيلد المناسب':'Recommended build'}</small>${WRC4.itemRow(b.items)}`:`<small class="muted">${A()?'لا تتوفر بيانات موثقة حاليًا':'No documented data available'}</small>`;
      row.appendChild(d);
    });
  });
}
const _rs=window.renderSlots;
if(_rs){window.renderSlots=function(){const r=_rs.apply(this,arguments);try{slotBuilds()}catch(e){console.error(e)}return r};try{renderSlots()}catch(e){}}
  const _tr=window.translate;window.translate=function(){const r=_tr.apply(this,arguments);try{renderSaved();labelFx();applyEmoji();if(typeof renderMeta==='function')renderMeta()}catch(e){console.error(e)}return r};
  new MutationObserver(()=>{if(!on('emoji'))applyEmoji()}).observe($('app')||document.body,{childList:true,subtree:true});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(init,10));else setTimeout(init,10);
})();

window.openChampDetail=function(id){const c=CHAMPS.find(x=>x.id===id);if(!c)return;try{go('champions')}catch(e){}try{showDetail(c)}catch(e){console.error(e)}setTimeout(()=>{const d=document.getElementById('champDetail');if(d)d.scrollIntoView({behavior:'smooth',block:'start'})},60)};

document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('#dashboard [data-go="champions"]');if(!b)return;setTimeout(()=>{try{go('champions')}catch(x){}const d=document.getElementById('champDetail');if(d)d.classList.add('hidden');const t=document.getElementById('champLibrary')||document.getElementById('champSearch');if(t)t.scrollIntoView({behavior:'smooth',block:'start'})},60)},true);

/* developer page sections (v4.0.18) */
(function(){
const APP_VER='4.0.39';
const css='.dv-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;max-width:850px;margin-top:16px}.dv-stat{background:#14101d;border:1px solid #3a2a50;border-radius:14px;padding:12px}.dv-stat small{display:block;color:var(--muted);font-size:10px;letter-spacing:.06em}.dv-stat b{font-size:16px}.dv-sec{max-width:850px;margin-top:16px;border:1px solid #3a2a50;border-radius:18px;background:#120f1b;padding:16px}.dv-sec h3{margin:0 0 10px;font-size:15px}.dv-sec ul{margin:0;padding-inline-start:18px;line-height:1.9;font-size:13px}.dv-log{border-inline-start:2px solid #7d35ad;padding-inline-start:12px;margin:0 0 12px}.dv-log b{font-size:13px}.dv-log div{color:var(--muted);font-size:12px;line-height:1.8}';
function build(){
  const p=document.getElementById('developer');if(!p||p.dataset.dvDone)return;p.dataset.dvDone='1';
  if(!document.getElementById('dvStyle')){const st=document.createElement('style');st.id='dvStyle';st.textContent=css;document.head.appendChild(st)}
  const ar=(typeof lang==='undefined'||lang==='ar');const T=(a,e)=>ar?a:e;
  const src=(window.WRC_DB&&WRC_DB.source)||{};const cov=(window.WRC_DB&&WRC_DB.coverage)||{};
  const n=(typeof CHAMPS!=='undefined')?CHAMPS.length:'—';const items=(window.WRC_DB&&WRC_DB.items)?WRC_DB.items.length:'—';
  const vb=[...p.querySelectorAll('.developer-bottom b')].find(b=>/4\.0\.0/.test(b.textContent));if(vb)vb.textContent=APP_VER+' · DB '+(WRC_DB.appVersion||WRC_DB.version||'—');
  const stat=(k,v)=>`<div class="dv-stat"><small>${k}</small><b>${v}</b></div>`;
  const log=[
   ['4.0.29',T('الدرافت اتعاد بناؤه: الدرجة = 80 + الميتا + المواجهة + الانسجام + احتياج الفريق + ضد تشكيلة الخصم + الأمان العشوائي + التوقيع (تُضغط فوق 170)، من تصنيفات الأبطال المحفوظة','Draft score rebuilt: 80 + meta + matchup + synergy + team needs + vs enemy comp + blind safety + signature (compressed above 170), from stored champion classifications')],
   ['4.0.28',T('إضافة أولوية مهارات Wukong (Q > E > W) في SKILL ORDER','Added Wukong skill priority (Q > E > W) to SKILL ORDER')],
   ['4.0.27',T('قسم SKILL ORDER لكل بطل: جدول مستويات 1-15 بأربعة صفوف (Q/W/E/R) بألوان المهارات وأولوية مشتقة من بيانات الترقية، وملاحظة مستويات الأولتميت','SKILL ORDER section per champion: a 1-15 level grid with four rows (Q/W/E/R), skill colors, priority derived from the level data, and an ultimate-levels note')],
   ['4.0.26',T('قائمة الترشيحات: 12 ترشيحًا مرقّمًا (شارة التير، سبب الترشيح، السكور) مع كشف تفصيلي لكل بطل بالقنوات السبع (تقدير) والإشارات','Recommendations: 12 ranked picks (tier badge, reason tag, score) with a per-pick breakdown of the seven channels (estimate) and signals')],
   ['4.0.25',T('إصلاح قوائم اختيار الأبطال (الانسجام والكاونتر والبيلدز): اللمس للتمرير لم يعد يختار بطلًا ويقفل القائمة، والاختيار صار بالنقر فقط','Fixed champion pickers (Synergy, Counter, Builds): touching to scroll no longer selects a champion and closes the menu; selection is by tap only')],
   ['4.0.24',T('تصحيح ترتيب قائمة الكاونتر الصعب لـRiven (Poppy ثم Warwick ثم Volibear)','Fixed Riven hard-counter list order (Poppy, Warwick, Volibear)')],
   ['4.0.23',T('أوزان الدرافت معايَرة على 90 مسودة مرجعية: تطابق أعلى 7 ارتفع من 36.5% إلى 43.5% على حالات اختبار منفصلة','Draft weights calibrated on 90 reference drafts: top-7 match rose from 36.5% to 43.5% on held-out cases')],
   ['4.0.22',T('ترتيب الكاونترات: يحافظ على الترتيب الموثق في الداتا داخل نفس درجة الصعوبة بدل ترتيب التير','Counter order: keeps the documented data order within the same severity instead of tier order')],
   ['4.0.21',T('المساعد: 228 موقفًا جديدًا و1296 رد جديد مكتوب يدويًا (المجموع 355 موقفًا و1514 صيغة رد). محرك الدرافت: عوامل CC والاشتباك والجيم المبكر والمتأخر (موسومة تقدير)، وترتيب الكاونترات يكسر التعادل بالتير','Draft engine: CC, engage, early/late scaling factors (labeled estimate); counter ties broken by tier')],
   ['4.0.20',T('محرك الدرافت: عامل «تكامل التشكيلة» (توازن الضرر، الخط الأمامي، الحماية من القتلة) بأسباب موثقة','Draft engine: new team-fit factor (damage balance, frontline, protection vs assassins) with documented reasons')],
   ['4.0.19',T('توسيع المساعد: 73 موقفًا جديدًا و146 صيغة رد، ومؤشر تفكير','Assistant expansion: 73 new situations, 146 reply variants, thinking indicator')],
   ['4.0.18',T('تطوير قائمة المطور','Developer page upgrade')],
   ['4.0.17',T('حذف مركز استيراد/تصدير البيانات، وزر استكشف الأبطال يفتح قائمة الأبطال','Removed data import/export center; Explore button opens the champion list')],
   ['4.0.16',T('تمرير سلس لقوائم الأبطال، لينات ثانوية موثقة لـ23 بطلًا، وزر تفاصيل البطل في الميتا','Smooth champion-list scrolling, documented secondary lanes for 23 champions, Meta details button')],
   ['4.0.15',T('ردود أكثر للمساعد: مرح وضحك وألقاب','More assistant replies: humor, laughs, friendly nicknames')],
   ['4.0.14',T('طلب صلاحية الصور تلقائيًا لميزة الصورة إلى درافت','Automatic photo permission request for photo-to-draft')],
   ['4.0.12',T('اسم Rift Mate وأيقونة جديدة وشريط تنقل سفلي بكل الأقسام','Rift Mate name, new icon, bottom navigation with every section')]
  ];
  const feats=[T('مساعد الدرافت مع ترشيحات وأسباب','Draft assistant with recommendations and reasons'),T('محلل الكاونتر ومحلل الانسجام','Counter and synergy analyzers'),T('معمل البيلدات والرونات مع تكيّف حسب تشكيلة الخصم','Build lab and runes, adapting to the enemy comp'),T('الصورة إلى درافت مع شاشة مراجعة','Photo-to-draft with a review step'),T('مدرب ومساعد بقواعد محلية بدون إنترنت','Offline rule-based coach and assistant'),T('الأبطال والعناصر والميتا بالعربية والإنجليزية','Champions, items and meta in Arabic and English'),T('يعمل بالكامل بدون إنترنت','Works fully offline')];
  const html=`<div class="dv-grid">${stat(T('الإصدار','APP VERSION'),APP_VER)}${stat(T('الباتش','PATCH'),src.patch||'—')}${stat(T('الأبطال','CHAMPIONS'),n)}${stat(T('العناصر','ITEMS'),items)}${stat(T('أدلة كاملة','FULL GUIDES'),cov.championsFullGuide??'—')}${stat(T('تاريخ البيانات','DATA DATE'),src.updated||'—')}</div>
  <div class="dv-sec"><h3>${T('عن المشروع','About the project')}</h3><div class="muted small" style="line-height:1.9">${T('Rift Mate مساعد مستقل للاعبي وايلد ريفت. يركز على فهم الدرافت والمواجهات، ويستخدم بيانات محلية موثقة، ولا يعرض رقمًا غير متاح.','Rift Mate is an independent companion for Wild Rift players. It focuses on draft and matchup reasoning, uses documented local data, and never shows a number it does not have.')}</div></div>
  <div class="dv-sec"><h3>${T('المميزات','Features')}</h3><ul>${feats.map(f=>'<li>'+f+'</li>').join('')}</ul></div>
  <div class="dv-sec"><h3>${T('سجل التحديثات','Changelog')}</h3>${log.map(l=>`<div class="dv-log"><b>v${l[0]}</b><div>${l[1]}</div></div>`).join('')}</div>`;
  const note=p.querySelector('.developer-note');if(note)note.insertAdjacentHTML('beforebegin',html);else p.insertAdjacentHTML('beforeend',html);
}
const _go=window.go;if(typeof _go==='function'){window.go=function(id){const r=_go.apply(this,arguments);if(id==='developer')try{build()}catch(e){console.error(e)}return r}}
document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>{try{build()}catch(e){console.error(e)}},1500));
})();
