package com.yusef.mmdrun;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.view.View;
import android.content.ContentValues;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import java.io.OutputStream;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    private static final int FILE_REQ = 1;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    /** Called from the game's settings ("auto" / "portrait" / "landscape"). */
    public class Bridge {
        @JavascriptInterface
        public void shareImage(final String b64) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME, "mmd-run-" + System.currentTimeMillis() + ".png");
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MMD RUN");
                final Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                OutputStream os = getContentResolver().openOutputStream(uri);
                os.write(data); os.close();
                runOnUiThread(new Runnable() { public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("image/png");
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, "MMD RUN"));
                } });
            } catch (Exception e) { e.printStackTrace(); }
        }
        /** Vibration from the game: "40" = one buzz (ms), "20,30,20" = buzz,pause,buzz... */
        @JavascriptInterface
        public void vibrate(final String pattern) {
            try {
                Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (vb == null || !vb.hasVibrator()) return;
                String[] parts = pattern.split(",");
                long[] w = new long[parts.length + 1];
                for (int i = 0; i < parts.length; i++) w[i + 1] = Math.max(0, Long.parseLong(parts[i].trim()));
                if (parts.length == 1) vb.vibrate(VibrationEffect.createOneShot(Math.max(1, w[1]), VibrationEffect.DEFAULT_AMPLITUDE));
                else vb.vibrate(VibrationEffect.createWaveform(w, -1));
            } catch (Exception e) { e.printStackTrace(); }
        }
        @JavascriptInterface
        public void setOrientation(final String mode) {
            getSharedPreferences("game", 0).edit().putString("orient", mode).apply();
            runOnUiThread(new Runnable() { public void run() { applyOrientation(mode); } });
        }
    }

    private void applyOrientation(String m) {
        int o = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
        if ("landscape".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
        else if ("auto".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR;
        setRequestedOrientation(o);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        applyOrientation(getSharedPreferences("game", 0).getString("orient", "portrait"));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(0xFF070812);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                 // localStorage (save data)
        s.setMediaPlaybackRequiresUserGesture(false); // audio
        s.setAllowFileAccess(true);
        web.setOnLongClickListener(v -> true);        // no text-selection menu
        web.setHapticFeedbackEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        // Needed so the "phone photo" button (<input type=file>) works in a WebView
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    startActivityForResult(p.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        hideBars();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCallback = null;
            }
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideBars(); }

    @Override protected void onPause() {
        web.evaluateJavascript("if(window.pauseGame)pauseGame();", null); // pause a running game
        web.onPause();
        super.onPause();
    }

    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override public void onBackPressed() {
        // back = pause / close the current screen; only leaves the app from the main menu
        web.evaluateJavascript("(function(){try{return !!(window.androidBack&&window.androidBack())}catch(e){return false}})()",
            new ValueCallback<String>() {
                @Override public void onReceiveValue(String v) { if (!"true".equals(v)) moveTaskToBack(true); }
            });
    }
}
