ساخت APK بدون نصب چیزی روی کامپیوتر (با GitHub):
1) در github.com یک حساب بساز و یک Repository جدید (Private هم اشکالی ندارد) بساز.
2) همه‌ی فایل‌های همین پوشه (شامل پوشه‌ی مخفی .github) را در آن آپلود کن.
3) به تب Actions برو -> Build APK -> اگر خودکار اجرا نشد، Run workflow را بزن.
4) بعد از ~۳ دقیقه، داخل همان اجرا در بخش Artifacts فایل MMD-RUN-apk را دانلود کن.
5) zip را باز کن، app-debug.apk را روی گوشی نصب کن (اجازه‌ی نصب از منبع ناشناخته لازم است).

یا: پوشه را در Android Studio باز کن و Build > Build APK(s) بزن.
بازی در app/src/main/assets/index.html است؛ برای به‌روزرسانی فقط همین فایل را عوض کن.
