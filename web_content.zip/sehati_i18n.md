# 🌐 دليل ونظام التدويل والترجمة المتكامل (i18n Architecture & Translation Dictionaries)

تم تحديث الهوية وتسمية التطبيق رسمياً إلى **"صحتي / Sehati"**.
يغطي هذا النظام كافة شاشات وتدفقات التطبيق الطبي (Dashboard، المواعيد، حجز موعد، الجلسة المرئية، الملف الطبي، الرسائل، الإعدادات، تسجيل الدخول، والتسجيل) عبر 3 لغات مدعومة:
- 🇩🇿 **العربية (ar)**: "صحتي" مع توجيه `dir="rtl"` وخط عربي متناسق.
- 🇫🇷 **الفرنسية (fr)**: "Sehati Santé" (اللغة الافتراضية) مع توجيه `dir="ltr"`.
- 🇬🇧 **الإنجليزية (en)**: "Sehati Health" مع توجيه `dir="ltr"`.

يتم تخزين واختيار اللغة وحفظها في `localStorage.getItem('app_lang')` مع تفعيل فوري لـ `document.documentElement.dir` و `document.documentElement.lang`.

---

## 1. ملف الترجمة العربية: `ar.json`
```json
{
  "common": {
    "app_name": "صحتي - Sehati",
    "search_placeholder": "ابحث عن طبيب، تخصص، عيادة...",
    "save": "حفظ التغييرات",
    "cancel": "إلغاء",
    "confirm": "تأكيد",
    "back": "رجوع",
    "next": "التالي",
    "loading": "جاري التحميل...",
    "see_all": "عرض الكل",
    "status_active": "نشط",
    "status_completed": "مكتمل",
    "status_pending": "قيد الانتظار",
    "filter": "تصفية",
    "notifications": "الإشعارات"
  },
  "nav": {
    "dashboard": "الرئيسية",
    "appointments": "المواعيد",
    "booking": "حجز موعد",
    "telehealth": "استشارة فيديو",
    "messages": "الرسائل",
    "records": "الملف الصحي",
    "settings": "الإعدادات",
    "logout": "تسجيل الخروج"
  },
  "auth": {
    "login_title": "تسجيل الدخول",
    "login_subtitle": "مرحباً بعودتك إلى تطبيق صحتي",
    "register_title": "إنشاء حساب جديد",
    "register_subtitle": "انضم إلى صحتي واستفد من استشارات طبية فورية ومتابعة صحية دقيقة",
    "email_label": "البريد الإلكتروني",
    "email_placeholder": "amine@sehati.dz",
    "password_label": "كلمة المرور",
    "password_placeholder": "••••••••",
    "confirm_password_label": "تأكيد كلمة المرور",
    "remember_me": "تذكرني في هذا الجهاز",
    "forgot_password": "نسيت كلمة المرور؟",
    "btn_login": "تسجيل الدخول",
    "btn_register": "إنشاء الحساب",
    "no_account": "ليس لديك حساب؟",
    "have_account": "لديك حساب بالفعل؟"
  },
  "dashboard": {
    "greeting": "مرحباً، أمين بلقاسم 👋",
    "subgreeting": "كيف تشعر اليوم؟ إليك ملخص مواعيدك وخطتك الصحية عبر صحتي",
    "next_appointment_title": "موعدك القادم بعد ساعتين",
    "quick_actions": "إجراءات سريعة",
    "action_book": "حجز موعد جديد",
    "action_consult": "جلسة فيديو فورية",
    "action_prescriptions": "الوصفات الطبية",
    "action_vitals": "المؤشرات الحيوية",
    "upcoming_consultations": "الاستشارات القادمة",
    "metrics_heart_rate": "معدل نبضات القلب",
    "metrics_blood_pressure": "ضغط الدم",
    "metrics_glucose": "مستوى السكر"
  },
  "appointments": {
    "page_title": "إدارة المواعيد",
    "upcoming_tab": "المواعيد القادمة",
    "past_tab": "السابقة",
    "dr_name_1": "د. صوفيا بن علال",
    "dr_spec_1": "أخصائية أمراض القلب والشرايين",
    "dr_name_2": "د. كريم منصوري",
    "dr_spec_2": "طب عام واستشارات أسرية",
    "date_time": "اليوم • 14:30 بتوقيت الجزائر",
    "join_call": "انضمام لجلسة الفيديو",
    "reschedule": "إعادة جدولة",
    "cancel_booking": "إلغاء الموعد"
  },
  "booking": {
    "page_title": "حجز موعد طبي جديد",
    "select_specialty": "اختر التخصص المطلوب",
    "select_date": "اختر التاريخ والوقت",
    "consultation_type": "نوع الاستشارة",
    "telehealth_badge": "عن بُعد (فيديو)",
    "in_person_badge": "في العيادة",
    "patient_notes": "أعراضك أو ملاحظات للطبيب",
    "notes_placeholder": "صف ما تشعر به بإيجاز للمساعدة في التشخيص المبدئي...",
    "btn_confirm_booking": "تأكيد الحجز والدفع"
  },
  "telehealth": {
    "page_title": "غرفة الاستشارة الطبية المباشرة",
    "encrypted_notice": "مكالمة مشفرة طبياً وآمنة بالكامل HIPAA & GDPR",
    "mic_mute": "كتم الميكروفون",
    "cam_off": "إيقاف الكاميرا",
    "chat_toggle": "المحادثة الفورية",
    "end_call": "إنهاء الجلسة",
    "doctor_note_badge": "الطبيب يدون ملاحظات الوصفة الطبية الآن"
  },
  "messages": {
    "page_title": "الرسائل والاستشارات المكتوبة",
    "active_doctors": "الأطباء المتاحون الآن",
    "type_message": "اكتب رسالتك أو استفسارك هنا...",
    "send_btn": "إرسال",
    "attach_file": "إرفاق تحاليل أو صور"
  },
  "records": {
    "page_title": "السجل الطبي الرقمي",
    "prescriptions": "الوصفات الطبية الإلكترونية",
    "lab_results": "نتائج الفحوصات والتحاليل",
    "vaccines": "سجل اللقاحات",
    "download_pdf": "تحميل التقرير الطبي (PDF)",
    "last_updated": "آخر تحديث: 24 مايو 2025"
  },
  "settings": {
    "page_title": "الإعدادات العامة",
    "language_section": "لغة الواجهة (Interface Language)",
    "lang_ar": "العربية 🇩🇿 (RTL)",
    "lang_fr": "الفرنسية 🇫🇷 (LTR)",
    "lang_en": "الإنجليزية 🇬🇧 (LTR)",
    "notifications_setting": "تنبيهات المواعيد والأدوية",
    "security": "الأمان والتحقق الثنائي",
    "dark_mode": "الوضع الليلي",
    "privacy_policy": "سياسة الخصوصية والشروط"
  },
  "errors": {
    "network_error": "تعذر الاتصال بالخادم، يرجى التحقق من الشبكة.",
    "invalid_email": "صيغة البريد الإلكتروني غير صالحة.",
    "required_field": "هذا الحقل مطلوب.",
    "booking_conflict": "هذا التوقيت تم حجزه مسبقاً، يرجى اختيار موعد آخر."
  }
}
```

---

## 2. ملف الترجمة الفرنسية: `fr.json` (اللغة الافتراضية)
```json
{
  "common": {
    "app_name": "Sehati Santé",
    "search_placeholder": "Rechercher médecin, spécialité, clinique...",
    "save": "Enregistrer",
    "cancel": "Annuler",
    "confirm": "Confirmer",
    "back": "Retour",
    "next": "Suivant",
    "loading": "Chargement...",
    "see_all": "Voir tout",
    "status_active": "Actif",
    "status_completed": "Terminé",
    "status_pending": "En attente",
    "filter": "Filtrer",
    "notifications": "Notifications"
  },
  "nav": {
    "dashboard": "Accueil",
    "appointments": "Rendez-vous",
    "booking": "Réserver",
    "telehealth": "Téléconsultation",
    "messages": "Messages",
    "records": "Dossier Médical",
    "settings": "Paramètres",
    "logout": "Déconnexion"
  },
  "auth": {
    "login_title": "Connexion Sécurisée",
    "login_subtitle": "Bon retour sur votre plateforme de santé Sehati",
    "register_title": "Créer un compte Sehati",
    "register_subtitle": "Rejoignez Sehati pour un suivi médical moderne et instantané",
    "email_label": "Adresse e-mail",
    "email_placeholder": "amine@sehati.dz",
    "password_label": "Mot de passe",
    "password_placeholder": "••••••••",
    "confirm_password_label": "Confirmer le mot de passe",
    "remember_me": "Se souvenir de moi",
    "forgot_password": "Mot de passe oublié ?",
    "btn_login": "Se connecter",
    "btn_register": "S'inscrire",
    "no_account": "Pas encore de compte ?",
    "have_account": "Vous avez déjà un compte ?"
  },
  "dashboard": {
    "greeting": "Bonjour, Amine Belkacem 👋",
    "subgreeting": "Comment allez-vous aujourd'hui ? Voici le résumé de votre suivi sur Sehati",
    "next_appointment_title": "Prochain RDV dans 2 heures",
    "quick_actions": "Actions Rapides",
    "action_book": "Prendre RDV",
    "action_consult": "Téléconsultation",
    "action_prescriptions": "Ordonnances",
    "action_vitals": "Constantes",
    "upcoming_consultations": "Consultations à venir",
    "metrics_heart_rate": "Fréquence Cardiaque",
    "metrics_blood_pressure": "Tension Artérielle",
    "metrics_glucose": "Glycémie à jeun"
  },
  "appointments": {
    "page_title": "Mes Rendez-vous",
    "upcoming_tab": "À venir",
    "past_tab": "Passés",
    "dr_name_1": "Dr. Sophia Benallal",
    "dr_spec_1": "Cardiologue Spécialiste",
    "dr_name_2": "Dr. Karim Mansouri",
    "dr_spec_2": "Médecin Généraliste & Famille",
    "date_time": "Aujourd'hui • 14:30 (Heure locale)",
    "join_call": "Rejoindre l'appel vidéo",
    "reschedule": "Reprogrammer",
    "cancel_booking": "Annuler RDV"
  },
  "booking": {
    "page_title": "Réserver une consultation",
    "select_specialty": "Sélectionner la spécialité",
    "select_date": "Date & Créneau horaire",
    "consultation_type": "Type de consultation",
    "telehealth_badge": "En Ligne (Vidéo)",
    "in_person_badge": "Au Cabinet",
    "patient_notes": "Symptômes ou motif de visite",
    "notes_placeholder": "Décrivez brièvement vos symptômes pour orienter le praticien...",
    "btn_confirm_booking": "Confirmer le rendez-vous"
  },
  "telehealth": {
    "page_title": "Salle de Téléconsultation",
    "encrypted_notice": "Liaison chiffrée de bout en bout conforme santé",
    "mic_mute": "Couper le micro",
    "cam_off": "Arrêter caméra",
    "chat_toggle": "Messagerie instantanée",
    "end_call": "Terminer l'appel",
    "doctor_note_badge": "Le praticien rédige votre ordonnance"
  },
  "messages": {
    "page_title": "Messagerie Médicale",
    "active_doctors": "Praticiens en ligne",
    "type_message": "Écrivez votre message ou question...",
    "send_btn": "Envoyer",
    "attach_file": "Joindre analyses ou photos"
  },
  "records": {
    "page_title": "Mon Dossier Santé",
    "prescriptions": "Ordonnances Numériques",
    "lab_results": "Résultats d'Analyses & Imagerie",
    "vaccines": "Carnet de Vaccination",
    "download_pdf": "Télécharger Synthèse Médicale (PDF)",
    "last_updated": "Dernière mise à jour : 24 Mai 2025"
  },
  "settings": {
    "page_title": "Paramètres Généraux",
    "language_section": "Langue de l'interface (Language)",
    "lang_ar": "Arabe 🇩🇿 (RTL)",
    "lang_fr": "Français 🇫🇷 (LTR)",
    "lang_en": "Anglais 🇬🇧 (LTR)",
    "notifications_setting": "Rappels de rendez-vous et pilulier",
    "security": "Sécurité & Double Authentification (2FA)",
    "dark_mode": "Mode Sombre",
    "privacy_policy": "Politique de confidentialité & RGPD"
  },
  "errors": {
    "network_error": "Erreur de connexion au serveur. Vérifiez votre réseau.",
    "invalid_email": "Format d'adresse e-mail invalide.",
    "required_field": "Ce champ est obligatoire.",
    "booking_conflict": "Ce créneau horaire n'est plus disponible."
  }
}
```

---

## 3. ملف الترجمة الإنجليزية: `en.json`
```json
{
  "common": {
    "app_name": "Sehati Health",
    "search_placeholder": "Search doctors, specialty, clinics...",
    "save": "Save Changes",
    "cancel": "Cancel",
    "confirm": "Confirm",
    "back": "Back",
    "next": "Next",
    "loading": "Loading...",
    "see_all": "See All",
    "status_active": "Active",
    "status_completed": "Completed",
    "status_pending": "Pending",
    "filter": "Filter",
    "notifications": "Notifications"
  },
  "nav": {
    "dashboard": "Home",
    "appointments": "Appointments",
    "booking": "Book Visit",
    "telehealth": "Telehealth",
    "messages": "Messages",
    "records": "Health Records",
    "settings": "Settings",
    "logout": "Log Out"
  },
  "auth": {
    "login_title": "Secure Login",
    "login_subtitle": "Welcome back to your certified Sehati healthcare app",
    "register_title": "Create Sehati Account",
    "register_subtitle": "Join Sehati for instant tele-consultations and holistic care",
    "email_label": "Email Address",
    "email_placeholder": "amine@sehati.dz",
    "password_label": "Password",
    "password_placeholder": "••••••••",
    "confirm_password_label": "Confirm Password",
    "remember_me": "Remember this device",
    "forgot_password": "Forgot password?",
    "btn_login": "Sign In",
    "btn_register": "Register",
    "no_account": "Don't have an account?",
    "have_account": "Already have an account?"
  },
  "dashboard": {
    "greeting": "Hello, Amine Belkacem 👋",
    "subgreeting": "How are you feeling today? Here is your healthcare schedule on Sehati",
    "next_appointment_title": "Upcoming Visit in 2 hours",
    "quick_actions": "Quick Actions",
    "action_book": "Book Visit",
    "action_consult": "Video Consult",
    "action_prescriptions": "Prescriptions",
    "action_vitals": "Health Vitals",
    "upcoming_consultations": "Upcoming Consultations",
    "metrics_heart_rate": "Heart Rate",
    "metrics_blood_pressure": "Blood Pressure",
    "metrics_glucose": "Fasting Glucose"
  },
  "appointments": {
    "page_title": "My Appointments",
    "upcoming_tab": "Upcoming",
    "past_tab": "Past Visits",
    "dr_name_1": "Dr. Sophia Benallal",
    "dr_spec_1": "Cardiology Specialist",
    "dr_name_2": "Dr. Karim Mansouri",
    "dr_spec_2": "General Practitioner & Family",
    "date_time": "Today • 14:30 (Local Time)",
    "join_call": "Join Video Session",
    "reschedule": "Reschedule",
    "cancel_booking": "Cancel Appointment"
  },
  "booking": {
    "page_title": "Book Consultation",
    "select_specialty": "Select Specialty",
    "select_date": "Date & Time Slot",
    "consultation_type": "Consultation Mode",
    "telehealth_badge": "Telehealth (Video)",
    "in_person_badge": "In-Clinic Visit",
    "patient_notes": "Symptoms or reason for visit",
    "notes_placeholder": "Briefly describe your health concern to guide the physician...",
    "btn_confirm_booking": "Confirm & Reserve Slot"
  },
  "telehealth": {
    "page_title": "Telehealth Video Room",
    "encrypted_notice": "HIPAA & GDPR end-to-end encrypted medical connection",
    "mic_mute": "Mute Mic",
    "cam_off": "Turn Off Camera",
    "chat_toggle": "Instant Chat",
    "end_call": "End Session",
    "doctor_note_badge": "Doctor is preparing your digital e-prescription"
  },
  "messages": {
    "page_title": "Medical Chat",
    "active_doctors": "Available Physicians",
    "type_message": "Type your medical message...",
    "send_btn": "Send",
    "attach_file": "Attach lab reports or files"
  },
  "records": {
    "page_title": "Electronic Health Record",
    "prescriptions": "E-Prescriptions",
    "lab_results": "Lab Reports & Imaging",
    "vaccines": "Immunization History",
    "download_pdf": "Download Health Summary (PDF)",
    "last_updated": "Last updated: May 24, 2025"
  },
  "settings": {
    "page_title": "Application Settings",
    "language_section": "Interface Language",
    "lang_ar": "Arabic 🇩🇿 (RTL)",
    "lang_fr": "French 🇫🇷 (LTR)",
    "lang_en": "English 🇬🇧 (LTR)",
    "notifications_setting": "Appointments & medication reminders",
    "security": "Security & Two-Factor Authentication (2FA)",
    "dark_mode": "Dark Theme",
    "privacy_policy": "Privacy Policy & GDPR Terms"
  },
  "errors": {
    "network_error": "Connection error. Please verify your internet connection.",
    "invalid_email": "Please provide a valid email address.",
    "required_field": "This field is required.",
    "booking_conflict": "This timeslot is already reserved. Please pick another."
  }
}
```

---

## 4. بنية React / i18n Integration (`i18n.js` / Hook)
```javascript
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import ar from './locales/ar.json';
import fr from './locales/fr.json';
import en from './locales/en.json';

const savedLang = localStorage.getItem('app_lang') || 'fr';

i18n.use(initReactI18next).init({
  resources: {
    ar: { translation: ar },
    fr: { translation: fr },
    en: { translation: en }
  },
  lng: savedLang,
  fallbackLng: 'fr',
  interpolation: { escapeValue: false }
});

export const changeAppLanguage = (langKey) => {
  i18n.changeLanguage(langKey);
  localStorage.setItem('app_lang', langKey);
  const isRtl = langKey === 'ar';
  document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
  document.documentElement.lang = langKey;
};
```
