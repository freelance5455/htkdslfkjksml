'use strict';
/* ترید یار — مسیر /trade/v1 داخل Cloudflare Worker (بدون سرور اختصاصی)
 * همان API سرور اختصاصی (بازار، تحلیل، اتصال و معامله فیوچرز) ولی بدون ربات ۲۴ساعته سمت سرور.
 * کلیدهای API هیچ‌جا ذخیره یا لاگ نمی‌شوند؛ فقط برای امضای همان درخواست استفاده می‌شوند. */
const { CONNECTORS, ALL_HOSTS, listExchanges, ExchangeError, prepareOrder } = require('../server/exchanges.js');

const CORS = {
  'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-tradyar-token', 'Access-Control-Max-Age': '86400',
};
const reply = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { ...CORS, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
const httpErr = (status, code) => Object.assign(new Error(code), { status, code });
const hostOk = (h) => { h = h.toLowerCase(); return ALL_HOSTS.some((x) => h === x || h.endsWith('.' + x)); };

const tradeCtx = {
  now: () => Date.now(),
  async http(method, urlStr, { headers = {}, body } = {}) {
    let u; try { u = new URL(urlStr); } catch { throw httpErr(400, 'bad_url'); }
    if (u.protocol !== 'https:' || !hostOk(u.hostname)) throw httpErr(403, 'host_not_allowed');
    const resp = await fetch(u.toString(), { method, redirect: 'manual', signal: AbortSignal.timeout(20000), headers: { 'user-agent': 'TradYar/1.1', accept: 'application/json', ...headers }, body });
    const text = await resp.text();
    let json = null; try { json = JSON.parse(text); } catch { /* ممکن است JSON نباشد */ }
    return { status: resp.status, json, text: text.slice(0, 2000) };
  },
};

const marketsCache = new Map(), tickersCache = new Map(), klinesCache = new Map();
function getConnector(id) { const c = CONNECTORS[String(id || '').toLowerCase()]; if (!c) throw httpErr(400, 'unknown_exchange'); return c; }
async function getMarkets(c, force) {
  const e = marketsCache.get(c.id);
  if (e && !force && Date.now() - e.at < 600000) return e;
  const list = await c.markets(tradeCtx);
  const fresh = { at: Date.now(), list, map: new Map(list.map((m) => [m.symbol, m])) };
  marketsCache.set(c.id, fresh); return fresh;
}
async function getTickers(c) {
  const e = tickersCache.get(c.id);
  if (e && Date.now() - e.at < 4000) return e.list;
  const list = await c.tickers(tradeCtx); tickersCache.set(c.id, { at: Date.now(), list }); return list;
}
function sanitizeCreds(cr) {
  if (!cr || typeof cr !== 'object') throw httpErr(400, 'missing_creds');
  const out = {};
  for (const k of ['apiKey', 'apiSecret', 'passphrase']) if (cr[k] !== undefined) { const v = String(cr[k]).trim(); if (v.length > 512 || /[\r\n]/.test(v)) throw httpErr(400, 'bad_creds'); out[k] = v; }
  return out;
}

async function placeOrderFlow(c, creds, o) {
  const mk = (await getMarkets(c)).map.get(String(o.symbol));
  const prepared = prepareOrder(mk, o);
  const order = {
    ...prepared, symbol: mk.symbol, test: o.test === true, clientId: o.clientId ? String(o.clientId).slice(0, 36).replace(/[^\w-]/g, '') : undefined,
    sl: Number(o.sl) || 0, tp: Number(o.tp) || 0, leverage: Number(o.leverage) || 0, marginMode: o.marginMode === 'cross' ? 'cross' : o.marginMode ? 'isolated' : undefined, reduceOnly: o.reduceOnly === true,
  };
  if (c.type === 'futures' && order.leverage && mk.maxLeverage && order.leverage > mk.maxLeverage) throw new ExchangeError('اهرم بیشتر از سقف مجاز این جفت‌ارز است (' + mk.maxLeverage + ')', { code: 'leverage_too_high' });
  const r = await c.placeOrder(tradeCtx, creds, order);
  const out = { ok: true, exchange: c.id, test: order.test, symbol: mk.symbol, side: order.side, type: order.type, sent: { qty: order.qty, quoteQty: order.quoteQty, price: order.price }, orderId: r.orderId, status: r.status, filledQty: r.filledQty, quoteSpent: r.quoteSpent };
  if (c.type === 'futures') out.protection = { native: !!r.nativeProtection, mode: 'attached' };
  return out;
}

const SIGNED = new Set(['balance', 'verify', 'order', 'orders', 'cancel', 'positions', 'close', 'leverage']);
const PUBLIC = new Set(['markets', 'tickers', 'klines']);

async function handleTrade(request) {
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  try {
    const url = new URL(request.url);
    const op = url.pathname.replace(/^\/trade(\/v1)?\/?/, '').replace(/\/+$/, '');
    if (op === 'health') return reply({ ok: true, trade: true, version: '1.1.0-worker', exchanges: Object.keys(CONNECTORS).length, tokenRequired: false });
    if (op === 'exchanges') return reply({ ok: true, exchanges: listExchanges() });
    if (op === 'egress') return reply({ ok: true, ip: null });
    if (op === 'bot/info') return reply({ ok: true, enabled: false, ai: false, caps: null });
    if (request.method !== 'POST') throw httpErr(405, 'method_not_allowed');
    if (!SIGNED.has(op) && !PUBLIC.has(op)) throw httpErr(404, 'unknown_op');
    let body; try { body = JSON.parse((await request.text()) || '{}'); } catch { throw httpErr(400, 'bad_json'); }
    const c = getConnector(body.exchange);
    if (op === 'markets') { const m = await getMarkets(c, body.refresh === true); return reply({ ok: true, exchange: c.id, type: c.type, at: m.at, markets: m.list }); }
    if (op === 'tickers') return reply({ ok: true, exchange: c.id, at: Date.now(), tickers: await getTickers(c) });
    if (op === 'klines') {
      const symbol = String(body.symbol || ''); if (!symbol || symbol.length > 40) throw httpErr(400, 'bad_symbol');
      const limit = Math.max(20, Math.min(parseInt(body.limit, 10) || 300, 1000));
      const key = [c.id, symbol, body.interval, limit].join('|'), hit = klinesCache.get(key);
      let data;
      if (hit && Date.now() - hit.at < 3000) data = hit.data;
      else { data = await c.klines(tradeCtx, symbol, body.interval, limit); klinesCache.set(key, { at: Date.now(), data }); if (klinesCache.size > 200) klinesCache.delete(klinesCache.keys().next().value); }
      return reply({ ok: true, exchange: c.id, symbol, klines: data });
    }
    const creds = sanitizeCreds(body.creds);
    if (op === 'balance' || op === 'verify') {
      const t0 = Date.now(), b = await c.balance(tradeCtx, creds), out = { ok: true, exchange: c.id, latencyMs: Date.now() - t0, ...b };
      if (op === 'verify') {
        out.warnings = [];
        if (b.canWithdraw === true) out.warnings.push('این کلید دسترسی «برداشت» دارد — برای امنیت، کلید را فقط با دسترسی Trade بسازید.');
        if (b.canTrade === false) out.warnings.push('این کلید اجازهٔ معامله ندارد.');
      }
      return reply(out);
    }
    if (op === 'order') return reply(await placeOrderFlow(c, creds, body.order || {}));
    if (op === 'orders') return reply({ ok: true, orders: typeof c.openOrders === 'function' ? await c.openOrders(tradeCtx, creds, body.symbol) : [] });
    if (op === 'cancel') { const r = await c.cancelOrder(tradeCtx, creds, String(body.symbol), String(body.orderId)); return reply({ ok: true, orderId: r.orderId }); }
    if (op === 'positions') return reply({ ok: true, positions: typeof c.positions === 'function' ? await c.positions(tradeCtx, creds, body.symbol) : [] });
    if (op === 'close') { await c.closePosition(tradeCtx, creds, String(body.positionId)); return reply({ ok: true }); }
    if (op === 'leverage') { await c.setLeverage(tradeCtx, creds, String(body.symbol), Number(body.leverage), body.marginMode); return reply({ ok: true }); }
    throw httpErr(404, 'unknown_op');
  } catch (e) {
    if (e instanceof ExchangeError) return reply({ ok: false, error: 'exchange_error', message: String(e.message || 'خطای صرافی').slice(0, 300), code: e.exCode !== undefined ? String(e.exCode) : undefined, status: e.exStatus }, 422);
    if (e && e.status && e.code) return reply({ ok: false, error: e.code }, e.status);
    return reply({ ok: false, error: 'internal_error', message: String(e && e.message || e).slice(0, 200) }, 500);
  }
}
module.exports = { handleTrade };
