'use strict';
/* جایگزین سبک و همگام (sync) برای node:crypto داخل Cloudflare Worker — بدون نیاز به nodejs_compat
 * فقط همان چیزهایی که کانکتورها لازم دارند: createHmac / createHash (sha256, sha512, md5) / randomBytes */
/*CONSTS*/
const enc = new TextEncoder();
const toBytes = (m) => (typeof m === 'string' ? enc.encode(m) : m instanceof Uint8Array ? m : new Uint8Array(m));
const rotr = (x, n) => (x >>> n) | (x << (32 - n));

function sha256(msg) {
  const m = toBytes(msg), l = m.length, padLen = (((l + 9 + 63) >> 6) << 6);
  const b = new Uint8Array(padLen); b.set(m); b[l] = 0x80;
  const dv = new DataView(b.buffer); dv.setUint32(padLen - 4, (l * 8) >>> 0); dv.setUint32(padLen - 8, Math.floor((l * 8) / 4294967296));
  const H = Uint32Array.from(H256), w = new Uint32Array(64);
  for (let o = 0; o < padLen; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
    for (let i = 16; i < 64; i++) { const a = w[i - 15], c = w[i - 2]; const s0 = rotr(a, 7) ^ rotr(a, 18) ^ (a >>> 3), s1 = rotr(c, 17) ^ rotr(c, 19) ^ (c >>> 10); w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0; }
    let [a, b2, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25), ch = (e & f) ^ (~e & g), t1 = (h + S1 + ch + K256[i] + w[i]) | 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22), mj = (a & b2) ^ (a & c) ^ (b2 & c), t2 = (S0 + mj) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b2; b2 = a; a = (t1 + t2) | 0;
    }
    H[0] += a; H[1] += b2; H[2] += c; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += h;
  }
  const out = new Uint8Array(32), ov = new DataView(out.buffer); H.forEach((x, i) => ov.setUint32(i * 4, x)); return out;
}

const M64 = (1n << 64n) - 1n;
const r64 = (x, n) => ((x >> BigInt(n)) | (x << BigInt(64 - n))) & M64;
function sha512(msg) {
  const m = toBytes(msg), l = m.length, padLen = (((l + 17 + 127) >> 7) << 7);
  const b = new Uint8Array(padLen); b.set(m); b[l] = 0x80;
  const dv = new DataView(b.buffer); dv.setUint32(padLen - 4, (l * 8) >>> 0); dv.setUint32(padLen - 8, Math.floor((l * 8) / 4294967296));
  const H = H512.map((x) => BigInt('0x' + x)), K = K512B, w = new Array(80);
  for (let o = 0; o < padLen; o += 128) {
    for (let i = 0; i < 16; i++) w[i] = (BigInt(dv.getUint32(o + i * 8)) << 32n) | BigInt(dv.getUint32(o + i * 8 + 4));
    for (let i = 16; i < 80; i++) { const a = w[i - 15], c = w[i - 2]; const s0 = r64(a, 1) ^ r64(a, 8) ^ (a >> 7n), s1 = r64(c, 19) ^ r64(c, 61) ^ (c >> 6n); w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & M64; }
    let [a, b2, c, d, e, f, g, h] = H;
    for (let i = 0; i < 80; i++) {
      const S1 = r64(e, 14) ^ r64(e, 18) ^ r64(e, 41), ch = (e & f) ^ (~e & M64 & g), t1 = (h + S1 + ch + K[i] + w[i]) & M64;
      const S0 = r64(a, 28) ^ r64(a, 34) ^ r64(a, 39), mj = (a & b2) ^ (a & c) ^ (b2 & c), t2 = (S0 + mj) & M64;
      h = g; g = f; f = e; e = (d + t1) & M64; d = c; c = b2; b2 = a; a = (t1 + t2) & M64;
    }
    [a, b2, c, d, e, f, g, h].forEach((x, i) => { H[i] = (H[i] + x) & M64; });
  }
  const out = new Uint8Array(64), ov = new DataView(out.buffer);
  H.forEach((x, i) => { ov.setUint32(i * 8, Number(x >> 32n)); ov.setUint32(i * 8 + 4, Number(x & 0xffffffffn)); }); return out;
}

function md5(msg) {
  const m = toBytes(msg), l = m.length, padLen = (((l + 9 + 63) >> 6) << 6);
  const b = new Uint8Array(padLen); b.set(m); b[l] = 0x80;
  const dv = new DataView(b.buffer); dv.setUint32(padLen - 8, (l * 8) >>> 0, true); dv.setUint32(padLen - 4, Math.floor((l * 8) / 4294967296), true);
  let a0 = 0x67452301, b0 = 0xefcdab89 | 0, c0 = 0x98badcfe | 0, d0 = 0x10325476;
  for (let o = 0; o < padLen; o += 64) {
    let A = a0, B = b0, C = c0, D = d0;
    for (let i = 0; i < 64; i++) {
      let F, g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; } else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; } else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; } else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      F = (F + A + MK[i] + dv.getUint32(o + g * 4, true)) | 0; A = D; D = C; C = B; B = (B + ((F << MS[i]) | (F >>> (32 - MS[i])))) | 0;
    }
    a0 = (a0 + A) | 0; b0 = (b0 + B) | 0; c0 = (c0 + C) | 0; d0 = (d0 + D) | 0;
  }
  const out = new Uint8Array(16), ov = new DataView(out.buffer); [a0, b0, c0, d0].forEach((x, i) => ov.setUint32(i * 4, x >>> 0, true)); return out;
}

const ALGO = { sha256: [sha256, 64], sha512: [sha512, 128], md5: [md5, 64] };
const hex = (u) => Array.from(u, (x) => x.toString(16).padStart(2, '0')).join('');
const b64 = (u) => { let s = ''; for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return btoa(s); };
const fmt = (u, e) => (e === 'hex' ? hex(u) : e === 'base64' ? b64(u) : u);
const concat = (a, b) => { const r = new Uint8Array(a.length + b.length); r.set(a); r.set(b, a.length); return r; };

function createHash(algo) {
  const e = ALGO[algo]; if (!e) throw new Error('algo ' + algo);
  let buf = new Uint8Array(0);
  const o = { update(d) { buf = concat(buf, toBytes(d)); return o; }, digest(encn) { return fmt(e[0](buf), encn); } };
  return o;
}
function createHmac(algo, key) {
  const e = ALGO[algo]; if (!e) throw new Error('algo ' + algo);
  const [fn, bs] = e; let k = toBytes(key); if (k.length > bs) k = fn(k);
  const kp = new Uint8Array(bs); kp.set(k);
  const ip = kp.map((x) => x ^ 0x36), op = kp.map((x) => x ^ 0x5c);
  let buf = new Uint8Array(0);
  const o = { update(d) { buf = concat(buf, toBytes(d)); return o; }, digest(encn) { return fmt(fn(concat(op, fn(concat(ip, buf)))), encn); } };
  return o;
}
function randomBytes(n) {
  const u = new Uint8Array(n); crypto.getRandomValues(u);
  return { toString: (e) => (e === 'hex' ? hex(u) : String.fromCharCode(...u)) };
}
module.exports = { createHash, createHmac, randomBytes };
