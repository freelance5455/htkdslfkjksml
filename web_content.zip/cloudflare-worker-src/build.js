'use strict';
/* ساخت یک فایل واحد Worker (relay + sync + trade) بدون نیاز به npm/bundler:  node cloudflare-worker-src/build.js */
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

/* ثابت‌های هش (به‌صورت عددی از ریشه‌های اول‌ها ساخته می‌شود) */
const primes = []; for (let n = 2; primes.length < 80; n++) if (primes.every((p) => n % p)) primes.push(n);
const iroot = (x, k) => { let lo = 0n, hi = 1n << (BigInt(x.toString(2).length) / BigInt(k) + 2n); while (lo < hi) { const mid = (lo + hi + 1n) >> 1n; if (mid ** BigInt(k) <= x) lo = mid; else hi = mid - 1n; } return lo; };
const frac = (p, k, bits) => { const r = iroot(BigInt(p) << BigInt(bits * k), k); return r & ((1n << BigInt(bits)) - 1n); };
const K256 = primes.slice(0, 64).map((p) => Number(frac(p, 3, 32)) | 0), H256 = primes.slice(0, 8).map((p) => Number(frac(p, 2, 32)) | 0);
const K512 = primes.map((p) => frac(p, 3, 64).toString(16).padStart(16, '0')), H512 = primes.slice(0, 8).map((p) => frac(p, 2, 64).toString(16).padStart(16, '0'));
const MK = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) | 0);
const MS = [].concat(...[[7, 12, 17, 22], [5, 9, 14, 20], [4, 11, 16, 23], [6, 10, 15, 21]].map((a) => [...a, ...a, ...a, ...a]));
const consts = `const K256 = ${JSON.stringify(K256)}, H256 = ${JSON.stringify(H256)}, H512 = ${JSON.stringify(H512)}, K512B = ${JSON.stringify(K512)}.map((x) => BigInt('0x' + x)), MK = ${JSON.stringify(MK)}, MS = ${JSON.stringify(MS)};`;

const mods = {
  'node:crypto': read('cloudflare-worker-src/shim-crypto.js').replace('/*CONSTS*/', consts),
  './exchanges.js': read('server/exchanges.js'), './futures-a.js': read('server/futures-a.js'), './futures-b.js': read('server/futures-b.js'), './futures-c.js': read('server/futures-c.js'),
  '../server/exchanges.js': null, './trade.js': read('cloudflare-worker-src/trade.js'),
};
let out = '/* ترید یار — Worker یکپارچه (ساخته‌شده خودکار با cloudflare-worker-src/build.js؛ دستی ویرایش نکنید)\n * همگام‌سازی + ریلی + مسیر /trade/v1 (اتصال و معامله فیوچرز روی صرافی‌ها) */\n';
out += 'const __defs = {};\nconst __cache = {};\nfunction __req(n) { if (n === "../server/exchanges.js") n = "./exchanges.js"; if (__cache[n]) return __cache[n].exports; const m = (__cache[n] = { exports: {} }); __defs[n](m, m.exports, __req); return m.exports; }\n';
for (const [k, v] of Object.entries(mods)) if (v) out += `__defs[${JSON.stringify(k)}] = function (module, exports, require) {\n${v}\n};\n`;
/* relay اصلی: export default → relay */
const relay = read('cloudflare-worker-src/relay.js').replace('export default {', 'const __relay = {');
out += relay + '\n';
out += `export default {
  async fetch(request, env, ctx) {
    const p = new URL(request.url).pathname;
    if (p === '/trade' || p.startsWith('/trade/')) return __req('./trade.js').handleTrade(request);
    return __relay.fetch(request, env, ctx);
  },
};\n`;
fs.writeFileSync(path.join(root, 'cloudflare-worker-relay.js'), out);
console.log('written', out.length);
