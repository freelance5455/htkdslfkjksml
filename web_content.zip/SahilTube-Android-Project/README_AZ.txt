SAHİLTUBE — ANDROID LAYİHƏSİ

Bu arxiv Android Studio üçün standart Gradle Android layihəsidir.

Layihənin açılması:
1. ZIP-i çıxarın.
2. Android Studio-da File > Open seçin.
3. Çıxardığınız SahilTube-Android-Project qovluğunu seçin.
4. Gradle sinxronizasiyasının tamamlanmasını gözləyin.
5. Build > Build APK(s) seçin.

Tələblər:
- Android Studio və JDK 17
- Android SDK Platform 35
- Gradle Plugin 8.6.1 (ilk sinxronizasiya zamanı internet lazımdır)

Qeydlər:
- HTML faylı app/src/main/assets/index.html daxilində saxlanılır.
- AndroidManifest.xml internet icazəsini ehtiva edir.
- WebView JavaScript və DOM Storage aktivdir; buna görə tətbiqin localStorage yaddaşı işləyə bilər.
- Tailwind CSS, Font Awesome, Google Fonts və YouTube embed-ləri HTML-də CDN/YouTube vasitəsilə yüklənir; tam görünüş və video üçün internet bağlantısı lazımdır.
- HTML-də API açarı üçün pəncərə var, lakin hazırkı HTML kodunda YouTube Data API sorğuları reallaşdırılmayıb. Buna görə API açarı əlavə etmək real axtarışı avtomatik aktiv etmir; mövcud videolar demo siyahısıdır.

Bu ZIP APK deyil. Bu, APK yaratmaq üçün mənbə Android layihəsidir. Burada Android SDK/Gradle ilə APK kompilyasiyası aparılmayıb.
