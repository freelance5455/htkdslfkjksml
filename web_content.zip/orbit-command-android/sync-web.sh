#!/bin/sh
# Copy the web game into the app's assets (run after editing the game)
set -e
SRC="${1:-../orbit-command}"
rm -rf app/src/main/assets/www && mkdir -p app/src/main/assets/www
cp -r "$SRC"/index.html "$SRC"/styles.css "$SRC"/js app/src/main/assets/www/
echo "synced from $SRC"
