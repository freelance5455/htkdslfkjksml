'use strict';

(function (OC) {
  const { CONFIG, S, TAU, OMEGA, PAD_LON0, MOON_N, ORBIT_PTS, MOON_RING_UNIT, add, sub, mul, dot, cross, len, unit, clamp, state: st } = OC;

  function isOccludedBySphere(pt, sphereCenter, sphereR) {
    const ax = pt[0] - st.CAM.pos[0], ay = pt[1] - st.CAM.pos[1], az = pt[2] - st.CAM.pos[2];
    const bx = sphereCenter[0] - st.CAM.pos[0], by = sphereCenter[1] - st.CAM.pos[1], bz = sphereCenter[2] - st.CAM.pos[2];
    const aa = ax * ax + ay * ay + az * az;
    if (aa < 1e-6) return false;
    const ab = ax * bx + ay * by + az * bz;
    if (ab <= 0 || ab >= aa) return false;
    const tProj = ab / aa;
    const cx = bx - ax * tProj, cy = by - ay * tProj, cz = bz - az * tProj;
    return (cx * cx + cy * cy + cz * cz) < sphereR * sphereR * 0.992;
  }

  function isOccludedRel(relPt) {
    const camP = st.VIS.camRelP;
    const ax = relPt[0] - camP[0], ay = relPt[1] - camP[1], az = relPt[2] - camP[2];
    const aa = ax * ax + ay * ay + az * az;
    if (aa < 1e-6) return false;
    const abP = -(ax * camP[0] + ay * camP[1] + az * camP[2]);
    if (abP > 0 && abP < aa) {
      const tP = abP / aa;
      const cx = -camP[0] - ax * tP, cy = -camP[1] - ay * tP, cz = -camP[2] - az * tP;
      if (cx * cx + cy * cy + cz * cz < CONFIG.body.radius * CONFIG.body.radius * 0.992) return true;
    }
    const bx = st.VIS.Mrel[0] - camP[0], by = st.VIS.Mrel[1] - camP[1], bz = st.VIS.Mrel[2] - camP[2];
    const abM = ax * bx + ay * by + az * bz;
    if (abM > 0 && abM < aa) {
      const tM = abM / aa;
      const cx = bx - ax * tM, cy = by - ay * tM, cz = bz - az * tM;
      if (cx * cx + cy * cy + cz * cz < CONFIG.moon.radius * CONFIG.moon.radius * 0.992) return true;
    }
    return false;
  }

  function drawWorldLine(ctx, pts, closeLoop, color, width, dash = []) {
    ctx.beginPath();
    let pen = false;
    const n = pts.length;
    for (let i = 0; i <= (closeLoop ? n : n - 1); i++) {
      const p = pts[i % n];
      if (isOccludedBySphere(p, st.VIS.P, CONFIG.body.radius)) { pen = false; continue; }
      const q = OC.project(p);
      if (!q) { pen = false; continue; }
      pen ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]);
      pen = true;
    }
    ctx.setLineDash(dash); ctx.strokeStyle = color; ctx.lineWidth = width; ctx.stroke(); ctx.setLineDash([]);
  }

  function drawRelLine(ctx, pts, closeLoop, frontColor, backColor, width, dash = []) {
    const n = pts.length;
    if (n < 2) return;
    const pass = (drawBack, col) => {
      if (!col) return;
      ctx.beginPath();
      let pen = false;
      for (let i = 0; i < n; i++) {
        const p = pts[i];
        if (isOccludedRel(p) !== drawBack) { pen = false; continue; }
        const q = OC.projectRel(p);
        if (!q) { pen = false; continue; }
        pen ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]);
        pen = true;
      }
      if (closeLoop && n > 1) {
        const p0 = pts[0], pLast = pts[n - 1];
        if (isOccludedRel(p0) === drawBack && isOccludedRel(pLast) === drawBack) {
          const q0 = OC.projectRel(p0), qLast = OC.projectRel(pLast);
          if (q0 && qLast) { ctx.moveTo(qLast[0], qLast[1]); ctx.lineTo(q0[0], q0[1]); }
        }
      }
      ctx.setLineDash(dash); ctx.strokeStyle = col; ctx.lineWidth = width; ctx.stroke(); ctx.setLineDash([]);
    };
    pass(true, backColor);
    pass(false, frontColor);
  }

  function drawPredLine(ctx, pred, frontColor, backColor, width) {
    const n = pred.count, buf = pred.pts;
    if (n < 2) return;
    const pt = [0, 0, 0];
    const pass = (drawBack, col) => {
      ctx.beginPath();
      let pen = false;
      const startOcc = isOccludedRel(st.VIS.r);
      if (startOcc === drawBack) {
        const q0 = OC.projectRel(st.VIS.r);
        if (q0) { ctx.moveTo(q0[0], q0[1]); pen = true; }
      }
      for (let i = 0; i < n; i++) {
        pt[0] = buf[i * 3]; pt[1] = buf[i * 3 + 1]; pt[2] = buf[i * 3 + 2];
        if (isOccludedRel(pt) !== drawBack) { pen = false; continue; }
        const q = OC.projectRel(pt);
        if (!q) { pen = false; continue; }
        pen ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]);
        pen = true;
      }
      // If closed orbit, smoothly connect the final point back to the start without chords
      if (pred.drawClosed && n > 2) {
        const lastPt = [buf[(n - 1) * 3], buf[(n - 1) * 3 + 1], buf[(n - 1) * 3 + 2]];
        if (Math.hypot(lastPt[0] - st.VIS.r[0], lastPt[1] - st.VIS.r[1], lastPt[2] - st.VIS.r[2]) < 300) {
          if (startOcc === drawBack && isOccludedRel(lastPt) === drawBack) {
            const q0 = OC.projectRel(st.VIS.r);
            if (q0 && pen) ctx.lineTo(q0[0], q0[1]);
          }
        }
      }
      ctx.strokeStyle = col; ctx.lineWidth = width; ctx.stroke();
    };
    pass(true, backColor);
    pass(false, frontColor);
  }

  const _labelBoxes = [];
  function placeLabel(ctx, x, y, text, color) {
    const w = ctx.measureText(text).width + 6;
    const h = 13;
    let ly = y;
    for (let tries = 0; tries < 6; tries++) {
      let clash = false;
      for (const b of _labelBoxes) {
        if (x < b.x + b.w && x + w > b.x && ly - 10 < b.y + b.h && ly + 4 > b.y) { clash = true; break; }
      }
      if (!clash) break;
      ly += h;
    }
    _labelBoxes.push({ x, y: ly - 10, w, h });
    ctx.save();
    ctx.fillStyle = 'rgba(6,11,22,0.62)';
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(x - 4, ly - 10.5, w + 2, 14.5, 4); else ctx.rect(x - 4, ly - 10.5, w + 2, 14.5);
    ctx.fill();
    ctx.strokeStyle = color; ctx.globalAlpha = 0.28; ctx.lineWidth = 0.8; ctx.stroke();
    ctx.restore();
    ctx.fillStyle = color;
    ctx.fillText(text, x, ly);
  }

  function drawRelMarker(ctx, pos, label, color, symbol = '◆') {
    const p = OC.projectRel(pos);
    if (!p) return;
    ctx.globalAlpha = isOccludedRel(pos) ? 0.35 : 1;
    ctx.fillStyle = color;
    ctx.font = 'bold 12px ui-monospace, monospace';
    ctx.fillText(symbol, p[0] - 5, p[1] + 4);
    ctx.font = '11px ui-monospace, monospace';
    placeLabel(ctx, p[0] + 9, p[1] + 4, label, color);
    ctx.globalAlpha = 1;
  }

  function drawPlanetGrid(ctx, spin) {
    const R = CONFIG.body.radius * 1.003;
    const drawCurve = (fn, col) => {
      ctx.beginPath(); let pen = false;
      for (let i = 0; i <= 96; i++) {
        const pt = fn(i / 96 * TAU);
        if (dot(sub(pt, st.VIS.camRelP), pt) >= 0) { pen = false; continue; }
        const q = OC.projectRel(pt);
        if (!q) { pen = false; continue; }
        pen ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]);
        pen = true;
      }
      ctx.strokeStyle = col; ctx.lineWidth = 0.9; ctx.stroke();
    };
    drawCurve(a => [R * Math.cos(a), R * Math.sin(a), 0], 'rgba(255,220,130,0.22)');
    const pm = spin + PAD_LON0;
    drawCurve(a => [R * Math.cos(a) * Math.cos(pm), R * Math.cos(a) * Math.sin(pm), R * Math.sin(a)], 'rgba(130,225,255,0.20)');
  }

  function drawMapBody2D(ctx, relCenter, R, dayCol, nightCol, rimCol) {
    const c = OC.projectRel(relCenter);
    const d = len(sub(relCenter, st.VIS.camRelP));
    if (!c || d <= R) return;
    const rpx = Math.max(2.5, st.F * Math.tan(Math.asin(Math.min(0.999999, R / d))));
    const sx = dot(st.SUNDIR, st.CAM.right), sy = -dot(st.SUNDIR, st.CAM.up);
    const g = ctx.createRadialGradient(c[0] + sx * rpx * 0.48, c[1] + sy * rpx * 0.48, rpx * 0.12, c[0], c[1], rpx * 1.15);
    g.addColorStop(0, dayCol); g.addColorStop(0.65, nightCol); g.addColorStop(1, '#09111f');
    ctx.beginPath(); ctx.arc(c[0], c[1], rpx, 0, TAU);
    ctx.fillStyle = g; ctx.fill();
    ctx.strokeStyle = rimCol; ctx.lineWidth = 1.1; ctx.stroke();
    ctx.beginPath(); ctx.arc(c[0], c[1], rpx + 2.5, 0, TAU);
    ctx.strokeStyle = 'rgba(90,170,255,0.18)'; ctx.lineWidth = 3; ctx.stroke();
  }

  function drawSOIBubble(ctx, relCenter, soiR, strokeCol, fillCol, label, dashLimb = [2, 6]) {
    const eqPts = [];
    for (let i = 0; i < 96; i++) {
      const a = i / 96 * TAU;
      eqPts.push([relCenter[0] + soiR * Math.cos(a), relCenter[1] + soiR * Math.sin(a), relCenter[2]]);
    }
    drawRelLine(ctx, eqPts, true, strokeCol, strokeCol, 1, [4, 5]);

    const toCam = sub(st.VIS.camRelP, relCenter);
    const d = len(toCam);
    if (d > soiR * 1.05) {
      const nDir = mul(toCam, 1 / d);
      let u = cross(nDir, [0, 0, 1]);
      if (len(u) < 1e-4) u = cross(nDir, [1, 0, 0]);
      u = unit(u);
      const v = cross(nDir, u);
      const sinA = soiR / d, cosA = Math.sqrt(1 - sinA * sinA);
      const cOff = add(relCenter, mul(nDir, soiR * sinA));
      const rLimb = soiR * cosA;
      ctx.beginPath();
      let pen = false;
      for (let i = 0; i <= 96; i++) {
        const a = i / 96 * TAU;
        const pt = add(cOff, add(mul(u, rLimb * Math.cos(a)), mul(v, rLimb * Math.sin(a))));
        const q = OC.projectRel(pt);
        if (!q) { pen = false; continue; }
        pen ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]);
        pen = true;
      }
      if (fillCol) { ctx.fillStyle = fillCol; ctx.fill(); }
      ctx.setLineDash(dashLimb); ctx.strokeStyle = strokeCol; ctx.lineWidth = 1.1; ctx.stroke(); ctx.setLineDash([]);

      const lblPt = OC.projectRel(add(cOff, mul(u, rLimb)));
      if (lblPt && label) { ctx.font = '10.5px ui-monospace, monospace'; placeLabel(ctx, lblPt[0] + 6, lblPt[1] + 3, label, strokeCol); }
    }
  }

  function drawSatelliteIcon(ctx, shipRelPos) {
    const s = OC.projectRel(shipRelPos);
    if (!s) return;
    const stepKm = clamp(st.dist * 0.05, 0.05, 50);
    const fwdEnd = OC.projectRel(add(shipRelPos, mul(st.VIS.att, stepKm)));
    const ang = fwdEnd ? Math.atan2(fwdEnd[1] - s[1], fwdEnd[0] - s[0]) : -Math.PI / 2;

    ctx.save();
    ctx.globalAlpha = isOccludedRel(shipRelPos) ? 0.3 : 1;
    ctx.translate(s[0], s[1]);
    ctx.rotate(ang);

    if (st.thrustedLastStep) {
      ctx.fillStyle = 'rgba(255,175,65,0.85)';
      ctx.beginPath(); ctx.moveTo(-4, -2.5); ctx.lineTo(-12, 0); ctx.lineTo(-4, 2.5); ctx.closePath(); ctx.fill();
    }

    ctx.fillStyle = '#38bdf8';
    ctx.fillRect(-1.5, -10, 3, 6.5); ctx.fillRect(-1.5, 3.5, 3, 6.5);
    ctx.strokeStyle = '#bae6fd'; ctx.lineWidth = 0.8;
    ctx.strokeRect(-1.5, -10, 3, 6.5); ctx.strokeRect(-1.5, 3.5, 3, 6.5);

    ctx.fillStyle = '#f8fafc';
    ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(0, -3.5); ctx.lineTo(-4.5, -2.5); ctx.lineTo(-4.5, 2.5); ctx.lineTo(0, 3.5); ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function drawMapView(ctx, nowMs) {
    _labelBoxes.length = 0;
    const vt = st.VIS.t;
    const P = st.VIS.P, M = st.VIS.M;
    const pRelCam = sub(P, st.CAM.pos), mRelCam = sub(M, st.CAM.pos);
    const spinPlanet = vt * OMEGA, spinMoon = vt * MOON_N;
    const sunDirMoon = unit(mul(M, -1));

    let drewPlanetGL = false, drewMoonGL = false;
    if (OC.GLR) {
      OC.GLR.beginFrame(st.glFocal, 500, [0, 0, 1], vt, spinPlanet);
      OC.GLR.drawSun();
      if (len(pRelCam) >= len(mRelCam)) {
        drewPlanetGL = OC.GLR.drawBody(pRelCam, CONFIG.body.radius, CONFIG.body.atmoKm, st.SUNDIR, spinPlanet, vt, true, st.glFocal, 1.0);
        drewMoonGL = OC.GLR.drawBody(mRelCam, CONFIG.moon.radius, 0, sunDirMoon, spinMoon, vt, false, st.glFocal, 1.0);
      } else {
        drewMoonGL = OC.GLR.drawBody(mRelCam, CONFIG.moon.radius, 0, sunDirMoon, spinMoon, vt, false, st.glFocal, 1.0);
        drewPlanetGL = OC.GLR.drawBody(pRelCam, CONFIG.body.radius, CONFIG.body.atmoKm, st.SUNDIR, spinPlanet, vt, true, st.glFocal, 1.0);
      }
      ctx.clearRect(0, 0, st.W, st.H);
    } else {
      ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, st.W, st.H);
      const sp = OC.project([0, 0, 0]);
      if (sp) { ctx.beginPath(); ctx.arc(sp[0], sp[1], 8, 0, TAU); ctx.fillStyle = '#fff5cc'; ctx.fill(); }
    }

    if (!drewPlanetGL) drawMapBody2D(ctx, [0, 0, 0], CONFIG.body.radius, '#4596df', '#1c4478', 'rgba(110,190,255,0.65)');
    if (!drewMoonGL) drawMapBody2D(ctx, st.VIS.Mrel, CONFIG.moon.radius, '#b8bfc9', '#555b66', 'rgba(200,210,225,0.55)');

    drawPlanetGrid(ctx, spinPlanet);

    const dPlanet = len(st.VIS.camRelP);
    if (dPlanet < 18000) {
      const atmoR = CONFIG.body.radius + CONFIG.body.atmoKm;
      drawSOIBubble(
        ctx, [0, 0, 0], atmoR,
        'rgba(86, 198, 255, 0.58)',
        'rgba(70, 175, 255, 0.04)',
        dPlanet < 8500 ? `ATMO (${CONFIG.body.atmoKm} km)` : null,
        [4, 4]
      );
    }

    if (dPlanet > 2500) {
      const pc = OC.projectRel([0, 0, 0]);
      if (pc) { ctx.font = '11px ui-monospace, monospace'; placeLabel(ctx, pc[0] + 10, pc[1] - 8, CONFIG.body.name, 'rgba(180,215,255,0.85)'); }
    }
    const mc = OC.projectRel(st.VIS.Mrel);
    if (mc && len(sub(st.VIS.Mrel, st.VIS.camRelP)) > 1100) {
      ctx.font = '11px ui-monospace, monospace';
      placeLabel(ctx, mc[0] + 10, mc[1] - 8, 'SELENE', 'rgba(210,220,235,0.85)');
    }

    drawWorldLine(ctx, ORBIT_PTS, true, 'rgba(150,170,220,0.20)', 1);
    drawSOIBubble(ctx, [0, 0, 0], CONFIG.body.soiKm, 'rgba(110,165,255,0.34)', null, `KERBIN SOI (${CONFIG.body.soiKm} km)`);
    drawSOIBubble(ctx, st.VIS.Mrel, CONFIG.moon.soiKm, 'rgba(195,155,255,0.42)', 'rgba(165,130,255,0.035)', `SELENE SOI (${CONFIG.moon.soiKm} km)`);
    drawRelLine(ctx, MOON_RING_UNIT, true, 'rgba(180,195,220,0.28)', 'rgba(180,195,220,0.08)', 1, [4, 4]);

    const kscPos = OC.padRelPos(vt);
    if (dot(sub(kscPos, st.VIS.camRelP), kscPos) < 0) drawRelMarker(ctx, kscPos, 'SPACEPORT', '#6eff9e', '▲');

    if (st.surfaceBeacon) {
      const bp = OC.beaconRelPos(st.surfaceBeacon, vt);
      if (dot(sub(bp, st.VIS.camRelP), bp) < 0) drawRelMarker(ctx, bp, st.surfaceBeacon.label, '#ff85b3', '◉');
    }

    if (st.targetBody && !st.targetBody.isMoon && st.VIS.tgtRel) {
      const tRing = [];
      for (let i = 0; i < 180; i++) tRing.push(st.targetBody.relPosAt(vt + i * 20));
      drawRelLine(ctx, tRing, true, 'rgba(255,110,200,0.42)', 'rgba(255,110,200,0.12)', 1, [5, 5]);
      drawRelMarker(ctx, st.VIS.tgtRel, st.targetBody.name, '#ff88d4', '□');
    }

    const pred = OC.getPrediction(nowMs);
    if (pred && pred.count > 1) {
      drawPredLine(ctx, pred, pred.impactPt ? 'rgba(255,120,120,0.82)' : 'rgba(110,220,255,0.75)', pred.impactPt ? 'rgba(255,120,120,0.18)' : 'rgba(110,220,255,0.16)', 1.45);
      if (pred.apPt && pred.closed && pred.maxAlt > 1.5) {
        const apLabel = pred.hadAtmo && pred.postAtmoAp !== null
          ? `AP ${pred.maxAlt.toFixed(0)} -> ${pred.postAtmoAp.toFixed(0)} km`
          : `AP ${pred.maxAlt.toFixed(0)} km`;
        drawRelMarker(ctx, pred.apPt, apLabel, '#7ad8ff');
      }
      if (pred.pePt && pred.minAlt > -15) drawRelMarker(ctx, pred.pePt, `PE ${pred.minAlt.toFixed(0)} km`, pred.minAlt < CONFIG.body.atmoKm ? '#ffaa55' : '#7affb8');
      if (pred.impactPt) drawRelMarker(ctx, pred.impactPt, 'IMPACT', '#ff6b7a', '✕');
      if (pred.moonSoiEntryPt) drawRelMarker(ctx, pred.moonSoiEntryPt, 'SOI ENTRY', '#c79bff', '◎');
      if (pred.minMoonAlt < 1600 && pred.moonPePt) drawRelMarker(ctx, pred.moonPePt, `SELENE PE ${pred.minMoonAlt.toFixed(0)} km`, '#e2c2ff', '◆');
      if (pred.soiEscapePt) drawRelMarker(ctx, pred.soiEscapePt, 'SOI ESCAPE', '#ffcc66', '↗');
      if (st.targetBody && pred.cpaPt && pred.closestTargetKm < 3500) {
        drawRelMarker(ctx, pred.cpaPt, `CPA ${pred.closestTargetKm.toFixed(1)} km`, '#ff88d4', '◎');
      }
    }

    if (!st.crashed) {
      const rr = st.VIS.r, rv = st.VIS.v;
      const L = clamp(st.dist * 0.09, 0.05, 180);
      if (!st.ship.onPad && !st.ship.landed) {
        ctx.globalAlpha = 0.65;
        if (st.navRef === 'target' && st.VIS.tgtRel && st.VIS.tgtVelRel) {
          const relRt = sub(rr, st.VIS.tgtRel), relVt = sub(rv, st.VIS.tgtVelRel);
          OC.drawArrowRel(ctx, rr, unit(relVt), L, '#ff77dd', 'T-PRO');
          OC.drawArrowRel(ctx, rr, unit(mul(relRt, -1)), L, '#7ab8ff', 'TO-TGT');
        } else {
          OC.drawArrowRel(ctx, rr, unit(rv), L, '#7aff9a', 'PRO');
          OC.drawArrowRel(ctx, rr, unit(rr), L, '#7ab8ff', 'UP');
        }
        ctx.globalAlpha = 1;
      }
      drawSatelliteIcon(ctx, rr);
    }

    OC.drawParticlesRel(ctx);
    if (S.gizmo) OC.drawBall(ctx);
  }

  Object.assign(OC, { drawMapView, isOccludedRel });
})(window.OC);