'use strict';
// Touch / mobile glue: menu button, Android back button, orientation + resize handling.
(function (OC) {
  const st = OC.state;
  const btn = document.getElementById('btnMenu');
  const toggleMenu = () => { OC.SFX && OC.SFX.init(); st.menuOpen ? OC.closeMenu() : OC.openMenu(); };
  if (btn) btn.addEventListener('click', toggleMenu);
  // Android native wrapper calls this from the hardware Back button
  window.OC_back = () => {
    const m = document.getElementById('missionsOverlay');
    if (m && !m.classList.contains('hidden') && document.getElementById('closeMissions') && !document.getElementById('closeMissions').classList.contains('hidden')) {
      document.getElementById('closeMissions').click(); return;
    }
    toggleMenu();
  };
  // tap a HUD panel to expand / collapse it on small screens
  ['hudPanel', 'missionHud'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('click', e => { if (e.target.closest('button')) return; el.classList.toggle('open'); });
  });
  // pause when app goes to background
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && st.ship && !st.menuOpen && !st.crashed) { try { OC.openMenu(); } catch (_) {} }
  });
  addEventListener('orientationchange', () => setTimeout(() => dispatchEvent(new Event('resize')), 200));
  // swallow browser gestures (pull-to-refresh, long-press menu) on the UI
  document.addEventListener('contextmenu', e => e.preventDefault());
})(window.OC);
