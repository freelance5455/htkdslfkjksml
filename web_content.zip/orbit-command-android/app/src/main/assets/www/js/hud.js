'use strict';

(function (OC) {
  const { CONFIG, S, B, LABELS, TAU, PAD_LON0, sub, mul, dot, cross, len, clamp, keyName, state: st } = OC;

  const hudPanel = document.getElementById('hudPanel');
  const helpPanel = document.getElementById('helpPanel');
  const menu = document.getElementById('menu');
  const sandboxModal = document.getElementById('sandboxModal');

  const hudEls = {
    head: document.getElementById('h-head'),
    status: document.getElementById('h-status'),
    atmo: document.getElementById('h-atmo'),
    cam: document.getElementById('h-cam'),
    alt: document.getElementById('h-alt'),
    spd: document.getElementById('h-spd'),
    ap: document.getElementById('h-ap'),
    pe: document.getElementById('h-pe'),
    per: document.getElementById('h-per'),
    tapsRow: document.getElementById('h-taps-row'),
    taps: document.getElementById('h-taps'),
    fuel: document.getElementById('h-fuel'),
    rock: document.getElementById('h-rock'),
    tgtRow: document.getElementById('h-tgt-row'),
    tgt: document.getElementById('h-tgt'),
    test: document.getElementById('h-test'),
    fuelBar: document.getElementById('h-fuel-bar')
  };
  const burnBtnEls = Array.from(document.querySelectorAll('#burnBtns .burn'));
  const sasBtnEls = Array.from(document.querySelectorAll('#sasBtns .sas'));
  const btnPauseEl = document.getElementById('btnPause');
  const btnStageEl = document.getElementById('btnStage');
  const btnEngEl = document.getElementById('btnEng');
  const btnChuteEl = document.getElementById('btnChute');
  let objDomRows = [];

  function setText(el, val) {
    if (el._v !== val) { el._v = val; el.textContent = val; }
  }

  function showToast(msg) {
    const el = document.getElementById('toast');
    el.textContent = msg; el.classList.add('show');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => el.classList.remove('show'), 2200);
  }

  function renderKeys() {
    const box = document.getElementById('keylist');
    box.innerHTML = '';
    for (const a in LABELS) {
      const row = document.createElement('label');
      row.textContent = LABELS[a];
      const btn = document.createElement('button');
      btn.textContent = st.listening === a ? 'press a key...' : keyName(B[a]);
      btn.className = st.listening === a ? 'on' : '';
      btn.onclick = () => { st.listening = a; renderKeys(); };
      row.appendChild(btn); box.appendChild(row);
    }
  }

  function renderWarpBtns() {
    const box = document.getElementById('warpBtns');
    box.innerHTML = '<span style="opacity:.75;font-size:11px;">WARP</span>';
    CONFIG.warpLevels.forEach((w, idx) => {
      const b = document.createElement('button');
      b.textContent = w + 'x';
      b.className = 'mini' + (idx === st.warpIdx ? ' on' : '');
      b.onclick = () => { OC.SFX.init(); st.autoWarp = null; st.warpIdx = idx; renderWarpBtns(); };
      box.appendChild(b);
    });
  }

  function setThrottle(v) {
    st.throttle = clamp(Math.round(v * 20) / 20, 0, 1);
    document.getElementById('thrSlider').value = st.throttle;
    document.getElementById('thrVal').textContent = Math.round(st.throttle * 100) + '%';
    if (st.throttle === 0 && st.ship) st.ship.mainEngine = false;
  }

  function syncNavRefBtn() {
    const btn = document.getElementById('btnNavRef');
    if (!st.targetBody && st.navRef === 'target') st.navRef = 'orbit';
    btn.disabled = !st.targetBody;
    btn.textContent = st.navRef === 'target' ? 'REF:TARGET' : 'REF:ORBIT';
    btn.classList.toggle('tgt-on', st.navRef === 'target');
  }

  function syncControlModeBtn() {
    const btn = document.getElementById('btnCtrlMode');
    if (!btn) return;
    const isManual = st.controlMode === 'manual';
    btn.textContent = isManual ? 'MANUAL (Y)' : 'AUTO (Y)';
    btn.classList.toggle('eng-on', isManual);
    btn.title = isManual
      ? 'Manual Attitude Control: Pitch/yaw with A/D/W/S/Arrows, fire engine with Enter / Throttle. Press Y for Auto-Vector.'
      : 'Auto-Vector Control: Burn keys auto-slew rocket to orbital vectors. Press Y for Manual Free Attitude.';
  }

  function toggleControlMode() {
    st.controlMode = st.controlMode === 'manual' ? 'auto' : 'manual';
    syncControlModeBtn();
    showToast(st.controlMode === 'manual' ? 'Control Mode: MANUAL (Free Attitude)' : 'Control Mode: AUTO (Vector Assisted)');
    if (OC.SFX) OC.SFX.beep(st.controlMode === 'manual' ? 520 : 640, 0.08, 'sine', 0.05);
  }

  function toggleNavRef() {
    if (!st.targetBody) { showToast('No active target — Orbit reference locked'); return; }
    st.navRef = st.navRef === 'orbit' ? 'target' : 'orbit';
    syncNavRefBtn();
    showToast(`Nav/Burn reference: ${st.navRef.toUpperCase()}`);
    OC.SFX.beep(640, 0.07, 'sine', 0.05);
  }

  function syncViewBtn() {
    const btn = document.getElementById('btnView');
    const isMap = st.viewMode === 'map';
    btn.textContent = isMap ? 'VIEW: MAP' : 'VIEW: FLIGHT';
    btn.classList.toggle('primary', !isMap);
    btn.classList.toggle('map-on', isMap);
  }

  function syncSasBtns() {
    if (!st.ship) return;
    for (const b of sasBtnEls) b.classList.toggle('on', b.dataset.sas === st.ship.sas);
  }

  function initMissionHudDom() {
    const m = OC.MISSIONS[st.currentMissionIdx];
    document.getElementById('mh-title').textContent = typeof m.num === 'number' ? `M${m.num}: ${m.title}` : `${m.num}: ${m.title}`;
    document.getElementById('mh-hint').textContent = m.hint;
    const box = document.getElementById('mh-objs');
    box.innerHTML = '';
    objDomRows = st.missionStatus.objs.map(() => {
      const row = document.createElement('div'); row.className = 'm-obj';
      const ico = document.createElement('span'), txt = document.createElement('span');
      row.appendChild(ico); row.appendChild(txt); box.appendChild(row);
      return { row, ico, txt, _ok: null, _text: null };
    });
    updateMissionHud(true);
  }

  function updateMissionHud(force = false) {
    const now = performance.now();
    if (!force && now - st.lastMissionHudMs < 90) return;
    st.lastMissionHudMs = now;
    const objs = st.missionStatus.objs;
    if (objs.length !== objDomRows.length) { initMissionHudDom(); return; }
    for (let i = 0; i < objs.length; i++) {
      const o = objs[i], dom = objDomRows[i];
      if (dom._ok !== o.ok) { dom._ok = o.ok; dom.row.className = o.ok ? 'm-obj done' : 'm-obj'; dom.ico.textContent = o.ok ? '✔' : '○'; }
      if (dom._text !== o.text) { dom._text = o.text; dom.txt.textContent = o.text; }
    }
  }

  function updateHud() {
    const helpTxt = [
      `${keyName(B.viewToggle)} flight/map  ${keyName(B.stage)} launch/stage  ${keyName(B.engine)} main eng  ${keyName(B.chute)} chute`,
      `Shift/Ctrl thr  T sas mode  Y auto/man ctrl  A/D or Arrows steer  Z/0 max/cut thr  [/] or 1-4 thr`,
      `${keyName(B.prograde)}/${keyName(B.retro)}/${keyName(B.radialOut)}/${keyName(B.radialIn)}/${keyName(B.normal)}/${keyName(B.antiNormal)} burns  ${keyName(B.warpDown)}/${keyName(B.warpUp)} warp  ${keyName(B.pause)} pause`,
      `M missions  C cam  N sfx  ${keyName(B.reset)} restart  drag rotate  right-drag pan  wheel zoom`
    ].join('\n');
    setText(helpPanel, helpTxt);
    syncControlModeBtn();

    const s = st.ship;
    const rr = st.VIS.r, rv = st.VIS.v;
    const info = OC.orbitInfo(rr, rv, st.VIS.t);
    const rn = len(rr), spin = st.VIS.t * OC.OMEGA + PAD_LON0;
    const lat = Math.asin(clamp(rr[2] / Math.max(1e-9, rn), -1, 1)) * 180 / Math.PI;
    const lon = (((Math.atan2(rr[1], rr[0]) - spin) * 180 / Math.PI) % 360 + 540) % 360 - 180;

    const status = st.menuOpen ? ' [MENU]' : st.crashed ? ' [IMPACT]' : st.missionDone ? ' [COMPLETE]' : st.paused ? ' [PAUSED]'
      : s.onPad ? ' [PAD PRELAUNCH]' : s.landedMoon ? ' [LANDED ON SELENE]' : s.landed ? ' [LANDED]' : s.chuteState === 2 ? ' [MAIN CHUTE]' : s.chuteState === 1 ? ' [DROGUE]'
      : st.autoWarp ? ` [AUTO->${st.autoWarp.label}]` : '';
    const ap = info.apoapsisKm === null ? 'escape' : info.apoapsisKm.toFixed(1) + ' km';
    const pe = info.periapsisKm === null ? 'n/a' : info.periapsisKm.toFixed(1) + ' km';
    const per = info.periodS === null ? 'n/a' : (info.periodS / 60).toFixed(1) + ' min';
    const fCur = OC.activeFuel(s), fMax = Math.max(0.001, OC.activeMaxFuel(s));
    const fuelPct = clamp((fCur / fMax) * 100, 0, 100);
    const atmoTag = info.altKm < CONFIG.body.atmoKm && !s.onPad && !s.landed && !info.inMoonSoi ? (s.dynQ > 5 ? ' [MAX-Q ATMO]' : ' [ATMO]') : '';

    const rawAgl = Math.max(0, rn - OC.surfaceRadiusAt(rr, st.VIS.t) - (s.onPad ? 0.0011 : 0));
    const aglStr = rawAgl < 20 && !info.inMoonSoi ? ` | AGL ${rawAgl < 1 ? (rawAgl * 1000).toFixed(0) + 'm' : rawAgl.toFixed(1) + 'km'}` : '';

    const { dtAp, dtPe } = OC.timeToApsis(rr, rv, st.VIS.t);
    const fmtTime = sec => {
      if (sec === null || isNaN(sec)) return '--';
      const m = Math.floor(sec / 60);
      const secR = Math.floor(sec % 60);
      return `${String(m).padStart(2, '0')}m ${String(secR).padStart(2, '0')}s`;
    };
    if (dtAp !== null || dtPe !== null) {
      hudEls.tapsRow.classList.remove('hidden');
      setText(hudEls.taps, `Ap in ${fmtTime(dtAp)} | Pe in ${fmtTime(dtPe)}`);
    } else {
      hudEls.tapsRow.classList.add('hidden');
    }

    setText(hudEls.head, `${CONFIG.ship.name} [${st.viewMode.toUpperCase()}]  T+${st.VIS.t.toFixed(0)} s  x${CONFIG.warpLevels[st.warpIdx]}`);
    setText(hudEls.status, status);
    setText(hudEls.atmo, atmoTag);
    setText(hudEls.cam, `${st.mode.toUpperCase()}   dist ${st.dist.toFixed(st.dist < 10 ? 2 : 0)} km`);
    const bodyTag = info.inMoonSoi ? ' (Selene)' : '';
    setText(hudEls.alt, `${Math.max(0, info.altKm).toFixed(info.altKm < 10 ? 2 : 1)} km${bodyTag}     ${lat.toFixed(1)}°, ${lon.toFixed(1)}°`);
    setText(hudEls.spd, `${len(info.vRef || rv).toFixed(3)} km/s   e ${info.e.toFixed(3)}`);
    setText(hudEls.ap, ap);
    setText(hudEls.pe, pe);
    setText(hudEls.per, `${per.padEnd(10)} Inclination ${info.incDeg.toFixed(1)}°`);
    const fuelText = s.stage === 1
      ? `S1 ${s.fuel1.toFixed(2)}/${s.maxFuel1.toFixed(1)}t  S2 ${s.fuel.toFixed(1)}t  dV ${OC.remainingDv().toFixed(2)} km/s`
      : `${s.fuel.toFixed(2)}/${s.maxFuel.toFixed(2)} t   dV ${OC.remainingDv().toFixed(2)} km/s`;
    setText(hudEls.fuel, fuelText);
    setText(hudEls.rock, `M ${s.mach.toFixed(2)} | Q ${s.dynQ.toFixed(1)} kPa | ${s.gLoad.toFixed(1)}G | TWR ${s.twr.toFixed(2)} | Pit ${s.pitchDeg.toFixed(0)}°${aglStr}`);
    setText(hudEls.test, st.testOk === null ? '' : (st.testOk ? 'PASS' : 'FAIL'));

    if (st.targetBody && st.VIS.tgtRel && st.VIS.tgtVelRel) {
      hudEls.tgtRow.classList.remove('hidden');
      const td = len(sub(rr, st.VIS.tgtRel)), tv = len(sub(rv, st.VIS.tgtVelRel));
      setText(hudEls.tgt, `${st.targetBody.name.padEnd(9)} ${td.toFixed(1)} km | relV ${tv.toFixed(3)} km/s`);
    } else {
      hudEls.tgtRow.classList.add('hidden');
    }

    const pctStr = fuelPct.toFixed(1) + '%';
    if (hudEls.fuelBar._w !== pctStr) { hudEls.fuelBar._w = pctStr; hudEls.fuelBar.style.width = pctStr; }
    const isLow = fuelPct < 18;
    if (hudEls.fuelBar._low !== isLow) { hudEls.fuelBar._low = isLow; hudEls.fuelBar.classList.toggle('low', isLow); }

    const stgLbl = s.onPad ? 'LAUNCH' : s.stage === 1 ? (s.fuel1 <= 0.01 ? 'STAGE NOW!' : 'STAGE (G)') : 'STG 2';
    setText(btnStageEl, stgLbl);
    btnStageEl.disabled = !s.onPad && s.stage >= 2;
    btnStageEl.className = 'mini ' + (s.onPad ? 'launch-btn' : (s.stage === 1 && s.fuel1 <= 0.01) ? 'eng-on' : '');

    setText(btnEngEl, s.mainEngine ? 'ENG:ON' : 'ENG:OFF');
    btnEngEl.className = 'mini' + (s.mainEngine ? ' eng-on' : '');

    const chLbl = s.chuteState === 2 ? 'CHUTE:OPEN' : s.chuteState === 1 ? 'DROGUE' : s.chuteArmed ? 'CHUTE:ARM' : 'CHUTE';
    setText(btnChuteEl, chLbl);
    btnChuteEl.className = 'mini' + (s.chuteState > 0 || s.chuteArmed ? ' chute-on' : '');

    for (let i = 0; i < burnBtnEls.length; i++) {
      const b = burnBtnEls[i], act = b.dataset.act;
      const firing = (st.keys.has(B[act]) || st.uiThrust.has(act)) && fCur > 0 && !st.paused && !st.crashed && !s.onPad;
      if (b._firing !== firing) { b._firing = firing; b.classList.toggle('firing', firing); }
    }
    if (btnPauseEl._on !== st.paused) { btnPauseEl._on = st.paused; btnPauseEl.classList.toggle('on', st.paused); }
  }

  function drawBall(ctx) {
    const cx = 86, cy = OC.gizmoY ? OC.gizmoY() : st.H - 86, R = 48;
    const g = ctx.createRadialGradient(cx - 8, cy - 8, 2, cx, cy, R);
    g.addColorStop(0, st.navRef === 'target' ? '#4a2658' : '#2c4a78');
    g.addColorStop(1, '#0a1220');
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fillStyle = g; ctx.fill();
    ctx.strokeStyle = st.navRef === 'target' ? 'rgba(255,140,220,0.9)' : 'rgba(160,190,230,0.9)';
    ctx.lineWidth = 1.2; ctx.stroke();

    const line = (fn) => {
      ctx.beginPath(); let pen = false;
      for (let s = 0; s <= 64; s++) {
        const v = fn(s / 64);
        if (dot(v, st.CAM.fwd) >= 0) { pen = false; continue; }
        const x = cx + R * dot(v, st.CAM.right), y = cy - R * dot(v, st.CAM.up);
        pen ? ctx.lineTo(x, y) : ctx.moveTo(x, y); pen = true;
      }
      ctx.stroke();
    };
    ctx.strokeStyle = 'rgba(150,200,255,0.40)'; ctx.lineWidth = 1;
    for (let lon = 0; lon < 360; lon += 30) {
      const L = lon * Math.PI / 180;
      line(u => { const la = (u - 0.5) * Math.PI; return [Math.cos(la) * Math.cos(L), Math.cos(la) * Math.sin(L), Math.sin(la)]; });
    }
    for (let lat = -60; lat <= 60; lat += 30) {
      const La = lat * Math.PI / 180;
      line(u => { const L = u * TAU; return [Math.cos(La) * Math.cos(L), Math.cos(La) * Math.sin(L), Math.sin(La)]; });
    }
    ctx.strokeStyle = 'rgba(255,230,140,0.85)';
    line(u => { const L = u * TAU; return [Math.cos(L), Math.sin(L), 0]; });

    const pip = (vec, col, sym) => {
      const l = len(vec);
      if (l < 1e-9) return;
      const v = mul(vec, 1 / l);
      if (dot(v, st.CAM.fwd) >= 0.05) return;
      const x = cx + R * dot(v, st.CAM.right), y = cy - R * dot(v, st.CAM.up);
      ctx.fillStyle = col; ctx.font = 'bold 11px ui-monospace, monospace';
      ctx.fillText(sym, x - 4, y + 4);
    };

    const rr = st.VIS.r, rv = st.VIS.v;
    pip(st.VIS.att, '#ffffff', '▲');
    if (st.navRef === 'target' && st.VIS.tgtRel && st.VIS.tgtVelRel) {
      const relVt = sub(rv, st.VIS.tgtVelRel), toTgt = sub(st.VIS.tgtRel, rr);
      pip(relVt, '#ff77dd', '⊕'); pip(mul(relVt, -1), '#ffd45c', '⊗');
      pip(toTgt, '#7aff9a', '◎'); pip(cross(sub(rr, st.VIS.tgtRel), relVt), '#c79bff', '△');
    } else {
      pip(rv, '#7aff9a', '⊕'); pip(mul(rv, -1), '#ffd45c', '⊗'); pip(cross(rr, rv), '#c79bff', '△');
      if (st.VIS.tgtRel) pip(sub(st.VIS.tgtRel, rr), '#ff6ec7', '◎');
    }

    ctx.fillStyle = st.navRef === 'target' ? '#ff9be0' : '#9bc0e8';
    ctx.font = 'bold 10.5px ui-monospace, monospace';
    const lbl = st.navRef === 'target' ? 'NAV: TARGET' : 'NAV: ORBIT';
    ctx.fillText(lbl, cx - ctx.measureText(lbl).width * 0.5, cy + R + 14);
  }

  const KEYMAP = {
    render: 'step', clouds: 'clouds', bump: 'bump', perf: 'perf', atmo: 'atmo',
    stars: 'stars', pred: 'pred', hud: 'hud', help: 'help', gizmo: 'gizmo',
    sfx: 'sfx', thrust: 'thrust', sens: 'sens', invert: 'invert'
  };

  function syncMenu() {
    for (const id in KEYMAP) {
      const el = document.getElementById('s-' + id);
      if (!el) continue;
      const v = S[KEYMAP[id]];
      if (el.type === 'checkbox') el.checked = v; else el.value = String(v);
    }
  }

  function applyPreset(on) {
    if (on) Object.assign(S, { step: 2, clouds: false, bump: false, atmo: false, stars: false, pred: 120 });
    else    Object.assign(S, { step: 1, clouds: true, bump: true, atmo: true, stars: true, pred: 360 });
  }

  function openMenu() {
    st.menuOpen = true; st.wasPaused = st.paused; st.paused = true; st.autoWarp = null;
    st.keys.clear(); st.uiThrust.clear(); OC.SFX.setThrust(0);
    menu.classList.remove('hidden');
    syncMenu();
  }

  function closeMenu() {
    st.menuOpen = false; st.paused = st.wasPaused;
    menu.classList.add('hidden');
  }

  function bindUI() {
    document.getElementById('thrSlider').addEventListener('input', e => setThrottle(Number(e.target.value)));
    burnBtnEls.forEach(b => {
      const act = b.dataset.act;
      b.addEventListener('pointerdown', e => { e.stopPropagation(); try { b.setPointerCapture(e.pointerId); } catch (_) {} OC.SFX.init(); OC.dropWarpForThrust(); st.uiThrust.add(act); });
      b.addEventListener('pointerup', () => st.uiThrust.delete(act));
      b.addEventListener('pointerleave', () => st.uiThrust.delete(act));
      b.addEventListener('pointercancel', () => st.uiThrust.delete(act));
    });
    sasBtnEls.forEach(b => {
      b.onclick = () => {
        OC.SFX.init();
        if (!st.ship) return;
        st.ship.sas = b.dataset.sas;
        syncSasBtns();
        OC.SFX.beep(580, 0.05, 'sine', 0.04);
      };
    });
    btnStageEl.onclick = () => { OC.SFX.init(); OC.launchOrStage(); };
    btnEngEl.onclick = () => { OC.SFX.init(); OC.toggleMainEngine(); };
    btnChuteEl.onclick = () => { OC.SFX.init(); OC.toggleChute(); };

    document.getElementById('btnView').onclick = () => { OC.SFX.init(); OC.setViewMode(st.viewMode === 'flight' ? 'map' : 'flight'); };
    document.getElementById('btnNavRef').onclick = () => { OC.SFX.init(); toggleNavRef(); };
    const btnCtrlMode = document.getElementById('btnCtrlMode');
    if (btnCtrlMode) btnCtrlMode.onclick = () => { OC.SFX.init(); toggleControlMode(); };
    document.getElementById('btnWarpAp').onclick = () => { OC.SFX.init(); OC.startWarpToApsis('ap'); };
    document.getElementById('btnWarpPe').onclick = () => { OC.SFX.init(); OC.startWarpToApsis('pe'); };
    document.getElementById('btnCam').onclick = () => OC.setMode(st.modeList[(st.modeList.indexOf(st.mode) + 1) % st.modeList.length]);
    document.getElementById('btnPause').onclick = () => { if (!st.crashed && !st.missionDone) { st.paused = !st.paused; if (st.paused) st.autoWarp = null; } };
    document.getElementById('btnAudio').onclick = () => { OC.SFX.init(); OC.toggleMute(); };
    document.getElementById('btnAudio').classList.add('on');
    document.getElementById('btnMissions').onclick = () => OC.openMissionModal(true);
    document.getElementById('closeMissions').onclick = () => { document.getElementById('missionModal').classList.add('hidden'); st.paused = false; };
    document.getElementById('launchMission').onclick = () => OC.startMission(st.selectedMissionIdx);
    document.getElementById('openMissionsFromMenu').onclick = () => { closeMenu(); OC.openMissionModal(true); };
    document.getElementById('resMenuBtn').onclick = () => { document.getElementById('resultModal').classList.add('hidden'); OC.openMissionModal(false); };
    document.getElementById('resRetryBtn').onclick = () => OC.resetMission();
    document.getElementById('resNextBtn').onclick = () => OC.startMission(Math.min(OC.MISSIONS.length - 1, st.currentMissionIdx + 1));

    document.getElementById('btnSandboxTools').onclick = () => sandboxModal.classList.remove('hidden');
    document.getElementById('sbClose').onclick = () => sandboxModal.classList.add('hidden');
    document.getElementById('sbLaunchPad').onclick = () => {
      st.t = 0; st.accum = 0; st.crashed = false;
      st.ship = OC.makeShip({ onPad: true });
      st.targetBody = null; st.surfaceBeacon = null; st.navRef = 'orbit';
      st.dist = CONFIG.view.padStartDistKm; st.yaw = PAD_LON0 + 1.32; st.pitch = 0.12;
      OC.predCache.dirty = true; syncNavRefBtn(); syncSasBtns(); setThrottle(1);
      showToast('Placed rocket on Spaceport Launchpad!'); sandboxModal.classList.add('hidden');
    };
    document.getElementById('sbOrbitStart').onclick = () => {
      st.t = 0; st.accum = 0; st.crashed = false;
      st.ship = OC.makeShip({ altKm: 100, incDeg: 10, fuel: 2.5 });
      st.ship.onPad = false; st.ship.landed = false; st.ship.landedMoon = false;
      st.dist = st.viewMode === 'flight' ? CONFIG.view.flightStartDistKm : CONFIG.view.mapStartDistKm;
      OC.predCache.dirty = true; syncSasBtns(); setThrottle(1);
      showToast('Placed Kestrel-V in 100 km Orbit!'); sandboxModal.classList.add('hidden');
    };
    document.getElementById('sbRefuel').onclick = () => {
      st.ship.fuel1 = st.ship.maxFuel1; st.ship.fuel = st.ship.maxFuel;
      st.lowFuelWarned = false;
      showToast('All propellant tanks refilled!'); sandboxModal.classList.add('hidden');
    };
    document.getElementById('sbCirc').onclick = () => {
      st.ship.onPad = false; st.ship.landed = false; st.ship.landedMoon = false;
      const rr = OC.relR(), rv = OC.relV(), tang = OC.unit(cross(cross(rr, rv), rr));
      const vc = Math.sqrt(CONFIG.body.mu / Math.max(1, len(rr)));
      st.ship.v = [tang[0] * vc, tang[1] * vc, tang[2] * vc];
      OC.predCache.dirty = true;
      showToast('Orbit circularized!'); sandboxModal.classList.add('hidden');
    };
    document.getElementById('sbSpawnPod').onclick = () => {
      st.targetBody = OC.createOrbitTarget('TARGET POD', 165, 18, 0.45);
      syncNavRefBtn(); OC.predCache.dirty = true;
      showToast('Spawned Target Pod at 165 km!'); sandboxModal.classList.add('hidden');
    };
    document.getElementById('sbBoostMoon').onclick = () => {
      st.ship.onPad = false; st.ship.landed = false; st.ship.landedMoon = false;
      st.targetBody = { name: 'SELENE', relPosAt: tt => OC.moonRelPos(tt), relVelAt: tt => OC.moonRelVel(tt), isMoon: true };
      syncNavRefBtn();
      const rr = OC.relR(), rv = OC.relV(), rLen = len(rr), tang = OC.unit(cross(cross(rr, rv), rr));
      const vTrans = Math.sqrt(CONFIG.body.mu * (2 / Math.max(1, rLen) - 2 / (rLen + OC.MOON_A)));
      st.ship.v = [tang[0] * vTrans, tang[1] * vTrans, tang[2] * vTrans];
      OC.predCache.dirty = true;
      showToast('Trans-Lunar burn applied!'); sandboxModal.classList.add('hidden');
    };

    document.querySelectorAll('[id^="s-"]').forEach(el => el.addEventListener('change', () => {
      const id = el.id.slice(2), key = KEYMAP[id];
      const v = el.type === 'checkbox' ? el.checked : Number(el.value);
      S[key] = v;
      if (id === 'perf') applyPreset(v);
      if (id === 'render' || id === 'perf') OC.resizeGL(Math.min(window.devicePixelRatio || 1, 2));
      if (id === 'pred') OC.predCache.dirty = true;
      if (id === 'thrust') CONFIG.ship.thrustF = v;
      if (id === 'sfx') { OC.SFX.setMuted(!v); document.getElementById('btnAudio').classList.toggle('on', v); }
      syncMenu();
    }));

    document.querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => {
      document.querySelectorAll('[data-tab]').forEach(x => x.classList.toggle('on', x === b));
      document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x.id === b.dataset.tab));
    }));
    document.getElementById('resume').addEventListener('click', closeMenu);
    document.getElementById('resetShip').addEventListener('click', () => { closeMenu(); OC.resetMission(); });
  }

  Object.assign(OC, {
    hudPanel, helpPanel, showToast, renderKeys, renderWarpBtns, setThrottle,
    syncNavRefBtn, toggleNavRef, syncViewBtn, syncSasBtns, syncControlModeBtn, toggleControlMode,
    initMissionHudDom, updateMissionHud, updateHud, drawBall, openMenu, closeMenu, syncMenu, bindUI
  });
})(window.OC);