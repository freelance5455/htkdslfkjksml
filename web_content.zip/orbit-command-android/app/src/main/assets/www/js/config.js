'use strict';

window.OC = window.OC || {};

(function (OC) {
  const TAU = Math.PI * 2;
  const G0 = 0.00980665;
  const PAD_LON0 = 2.45; // Start Spaceport in bright morning sunlight at T+0

  const CONFIG = {
    body:  { name: 'Kerbin-like', mu: 3531.6, radius: 600, rotationPeriodS: 21600, atmoKm: 70, seaLevel: 0.5, seed: 3.7, soiKm: 84159 },
    moon:  { name: 'Selene', mu: 65.14, radius: 200, orbitRadiusKm: 12000, soiKm: 2430 },
    sun:   { orbitRadiusKm: 13599840, periodS: 9203545, radiusKm: 130000 },
    ship:  {
      name: 'Kestrel-V', altitudeKm: 90, inclinationDeg: 20,
      dryMassT: 1.0, fuelMassT: 2.0, thrustF: 0.05, ispS: 340, ispSL: 220,
      s1DryMassT: 1.4, s1FuelMassT: 6.6, s1ThrustF: 0.195, s1IspVac: 310, s1IspSL: 265
    },
    sim:   { physicsStepS: 0.5 },
    view:  { fovDeg: 50, padStartDistKm: 0.085, flightStartDistKm: 120, mapStartDistKm: 1900, minDistKm: 0.035, maxDistKm: 500000 },
    warpLevels: [1, 5, 20, 100, 1000, 10000]
  };

  const PH = CONFIG.sim.physicsStepS;
  const SUN_A = CONFIG.sun.orbitRadiusKm;
  const SUN_A2 = SUN_A * SUN_A;
  const SUN_MU = 4 * Math.PI * Math.PI * Math.pow(SUN_A, 3) / (CONFIG.sun.periodS ** 2);
  const SUN_N = TAU / CONFIG.sun.periodS;
  const SUN_N2 = SUN_N * SUN_N;
  const MOON_A = CONFIG.moon.orbitRadiusKm;
  const MOON_A3 = MOON_A * MOON_A * MOON_A;
  const MOON_PERIOD = TAU * Math.sqrt(MOON_A3 / CONFIG.body.mu);
  const MOON_N = TAU / MOON_PERIOD;

  const S = {
    step: 1, clouds: true, bump: true, atmo: true, stars: true, pred: 360,
    hud: true, help: true, gizmo: true, perf: false, sfx: true,
    thrust: CONFIG.ship.thrustF, sens: 1, invert: false
  };

  const DEFAULT_BINDS = {
    prograde: 'w', retro: 's', radialOut: 'r', radialIn: 'f', normal: 'q', antiNormal: 'e',
    stage: 'g', engine: 'enter', chute: 'u', ctrlMode: 'y',
    navRef: 'v', viewToggle: 'tab', warpUp: '.', warpDown: ',', pause: ' ', reset: 'x', camera: 'c', resetView: 'home'
  };

  const LABELS = {
    prograde: 'Prograde burn', retro: 'Retrograde burn', radialOut: 'Radial out', radialIn: 'Radial in',
    normal: 'Normal', antiNormal: 'Anti-normal', stage: 'Launch / Stage', engine: 'Toggle main engine',
    chute: 'Arm / Deploy chute', ctrlMode: 'Toggle Auto/Manual Control', navRef: 'Orbit/Target ref', viewToggle: 'Flight/Map view',
    warpUp: 'Warp up', warpDown: 'Warp down', pause: 'Pause', reset: 'Restart mission',
    camera: 'Cycle camera', resetView: 'Reset view'
  };

  const THRUST_ACTS = ['prograde', 'retro', 'radialOut', 'radialIn', 'normal', 'antiNormal'];
  const B = { ...DEFAULT_BINDS };

  const keyName = k => k === ' ' ? 'Space' : k.length === 1 ? k.toUpperCase() : k[0].toUpperCase() + k.slice(1);

  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const len = a => Math.hypot(a[0], a[1], a[2]);
  const unit = a => { const l = len(a); return l > 0 ? mul(a, 1 / l) : [0, 0, 0]; };
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

  const ORBIT_PTS = Array.from({ length: 360 }, (_, i) => {
    const a = i / 360 * TAU;
    return [SUN_A * Math.cos(a), SUN_A * Math.sin(a), 0];
  });

  const MOON_RING_UNIT = Array.from({ length: 180 }, (_, i) => {
    const a = i / 180 * TAU;
    return [MOON_A * Math.cos(a), MOON_A * Math.sin(a), 0];
  });

  const STARS = Array.from({ length: 360 }, () => {
    const u = Math.random() * 2 - 1, th = Math.random() * TAU, s = Math.sqrt(1 - u * u);
    return { dir: [s * Math.cos(th), s * Math.sin(th), u], sz: Math.random() < 0.16 ? 2.1 : 1.25, br: 0.45 + Math.random() * 0.55 };
  });

  const state = {
    ship: null, t: 0, accum: 0, warpIdx: 0, throttle: 1,
    paused: false, menuOpen: false, wasPaused: false,
    keys: new Set(), uiThrust: new Set(),
    thrustedLastStep: false, lastDirVec: [0, 1, 0], crashed: false, testOk: null,
    particles: [],
    screenShake: 0,
    controlMode: 'auto', // 'auto' (vector-assisted) or 'manual' (free attitude)
    viewMode: 'flight',
    modeList: ['ship', 'planet', 'moon', 'target', 'free'],
    mode: 'ship',
    navRef: 'orbit',
    autoWarp: null,
    yaw: 1.13, pitch: 0.04, dist: CONFIG.view.flightStartDistKm, panOff: [0, 0, 0], freePivot: [0, 0, 0],
    viewCameras: {
      flight: { mode: 'ship', yaw: 1.13, pitch: 0.04, dist: CONFIG.view.flightStartDistKm, panOff: [0, 0, 0], freePivot: [0, 0, 0] },
      map:    { mode: 'ship', yaw: 0.40, pitch: 0.65, dist: CONFIG.view.mapStartDistKm, panOff: [0, 0, 0], freePivot: [0, 0, 0] }
    },
    F: 1, glFocal: 1, W: 0, H: 0,
    CAM: null, SUNDIR: [1, 0, 0],
    VIS: {
      t: 0, P: [0, 0, 0], Mrel: [0, 0, 0], M: [0, 0, 0],
      r: [0, 0, 0], v: [0, 0, 0], att: [1, 0, 0], tgtRel: null, tgtVelRel: null, camRelP: [0, 0, 0]
    },
    currentMissionIdx: 0, selectedMissionIdx: 0,
    missionState: {}, missionDone: false, missionStatus: { done: false, objs: [] },
    targetBody: null, surfaceBeacon: null,
    prevDoneCount: 0, lowFuelWarned: false, lastMissionHudMs: -9999,
    listening: null
  };

  Object.assign(OC, {
    TAU, G0, PAD_LON0, PH, SUN_A, SUN_A2, SUN_MU, SUN_N, SUN_N2, MOON_A, MOON_A3, MOON_PERIOD, MOON_N,
    CONFIG, S, DEFAULT_BINDS, LABELS, THRUST_ACTS, B, keyName,
    add, sub, mul, dot, cross, len, unit, clamp,
    ORBIT_PTS, MOON_RING_UNIT, STARS, state
  });
})(window.OC);