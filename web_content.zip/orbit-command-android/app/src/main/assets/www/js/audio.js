'use strict';

(function (OC) {
  OC.SFX = (() => {
    let ac = null, noiseNode = null, thrGain = null, thrFilter = null, muted = false;

    function init() {
      if (ac) { if (ac.state === 'suspended') ac.resume(); return; }
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      ac = new AudioCtx();
      const lenBuf = ac.sampleRate * 2;
      const buf = ac.createBuffer(1, lenBuf, ac.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < lenBuf; i++) data[i] = Math.random() * 2 - 1;
      noiseNode = ac.createBufferSource();
      noiseNode.buffer = buf; noiseNode.loop = true;
      thrFilter = ac.createBiquadFilter();
      thrFilter.type = 'lowpass'; thrFilter.frequency.value = 180;
      thrGain = ac.createGain(); thrGain.gain.value = 0;
      noiseNode.connect(thrFilter); thrFilter.connect(thrGain); thrGain.connect(ac.destination);
      noiseNode.start();
    }

    function setThrust(level) {
      if (!ac || !thrGain) return;
      const target = (OC.S.sfx && !muted && level > 0) ? 0.08 * level : 0;
      thrGain.gain.setTargetAtTime(target, ac.currentTime, 0.04);
      thrFilter.frequency.setTargetAtTime(120 + 280 * level, ac.currentTime, 0.05);
    }

    function beep(freq = 520, dur = 0.09, type = 'sine', vol = 0.07) {
      if (!OC.S.sfx || muted) return;
      init();
      if (!ac) return;
      const o = ac.createOscillator(), g = ac.createGain();
      o.type = type; o.frequency.value = freq;
      g.gain.setValueAtTime(vol, ac.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0005, ac.currentTime + dur);
      o.connect(g); g.connect(ac.destination);
      o.start(); o.stop(ac.currentTime + dur);
    }

    function stageSep() {
      if (!OC.S.sfx || muted) return;
      beep(190, 0.12, 'triangle', 0.11);
      setTimeout(() => beep(420, 0.08, 'sine', 0.07), 50);
    }

    function fanfare() {
      [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => setTimeout(() => beep(f, 0.22, 'triangle', 0.08), i * 95));
    }

    function crash() {
      if (!OC.S.sfx || muted) return;
      init();
      if (!ac) return;
      beep(110, 0.45, 'sawtooth', 0.14);
      beep(65, 0.6, 'square', 0.10);
    }

    return { init, setThrust, beep, stageSep, fanfare, crash, setMuted(m) { muted = m; if (m) setThrust(0); } };
  })();
})(window.OC);