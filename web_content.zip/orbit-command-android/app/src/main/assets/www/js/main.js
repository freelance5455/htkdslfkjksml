'use strict';

(function (OC) {
  const { CONFIG, S, B, THRUST_ACTS, PH, OMEGA, PAD_LON0, add, sub, mul, dot, cross, len, unit, clamp, state: st } = OC;

  const canvas = document.getElementById('c');
  const ctx = canvas.getContext('2d');
  const missionModal = document.getElementById('missionModal');
  const resultModal = document.getElementById('resultModal');
  const sandboxModal = document.getElementById('sandboxModal');

  let last = performance.now();

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    st.W = window.innerWidth; st.H = window.innerHeight;
    canvas.width = Math.round(st.W * dpr); canvas.height = Math.round(st.H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    st.F = (st.H / 2) / Math.tan(CONFIG.view.fovDeg * Math.PI / 360);
    OC.resizeGL(dpr);
  }

  function updateVisualSnapshot() {
    const vt = st.t + st.accum;
    st.VIS.t = vt;
    const pp = OC.planetPos(vt);
    st.VIS.P[0] = pp[0]; st.VIS.P[1] = pp[1]; st.VIS.P[2] = pp[2];
    const mp = OC.moonRelPos(vt);
    st.VIS.Mrel[0] = mp[0]; st.VIS.Mrel[1] = mp[1]; st.VIS.Mrel[2] = mp[2];
    st.VIS.M[0] = pp[0] + mp[0]; st.VIS.M[1] = pp[1] + mp[1]; st.VIS.M[2] = pp[2] + mp[2];
    const s = st.ship;

    if (st.accum > 1e-6 && !st.crashed) {
      if (s.onPad || s.landed) {
        const ang = OMEGA * st.accum, cs = Math.cos(ang), sn = Math.sin(ang);
        const rx = s.r[0] * cs - s.r[1] * sn, ry = s.r[0] * sn + s.r[1] * cs;
        st.VIS.r[0] = rx; st.VIS.r[1] = ry; st.VIS.r[2] = s.r[2];
        const sv = OC.surfaceVelAt(st.VIS.r);
        st.VIS.v[0] = sv[0]; st.VIS.v[1] = sv[1]; st.VIS.v[2] = sv[2];
        const u = unit(st.VIS.r);
        st.VIS.att[0] = u[0]; st.VIS.att[1] = u[1]; st.VIS.att[2] = u[2];
      } else {
        const dir = st.thrustedLastStep ? st.lastDirVec : [0, 0, 0];
        const spec = OC.stageThrustSpec(s, len(s.r) - CONFIG.body.radius);
        const tAcc = st.thrustedLastStep ? (spec.thrustF * st.throttle) / OC.totalMass(s) : 0;
        OC.rk2StepInto(
          s.r[0], s.r[1], s.r[2], s.v[0], s.v[1], s.v[2],
          st.t, st.accum, tAcc, dir[0], dir[1], dir[2],
          OC.totalMass(s), OC.currentCdArea(s), OC._visBuf
        );
        st.VIS.r[0] = OC._visBuf[0]; st.VIS.r[1] = OC._visBuf[1]; st.VIS.r[2] = OC._visBuf[2];
        st.VIS.v[0] = OC._visBuf[3]; st.VIS.v[1] = OC._visBuf[4]; st.VIS.v[2] = OC._visBuf[5];
        st.VIS.att[0] = s.att[0]; st.VIS.att[1] = s.att[1]; st.VIS.att[2] = s.att[2];
      }
    } else {
      st.VIS.r[0] = s.r[0]; st.VIS.r[1] = s.r[1]; st.VIS.r[2] = s.r[2];
      st.VIS.v[0] = s.v[0]; st.VIS.v[1] = s.v[1]; st.VIS.v[2] = s.v[2];
      st.VIS.att[0] = s.att[0]; st.VIS.att[1] = s.att[1]; st.VIS.att[2] = s.att[2];
    }

    if (st.targetBody) {
      st.VIS.tgtRel = st.targetBody.relPosAt(vt);
      st.VIS.tgtVelRel = st.targetBody.relVelAt(vt);
    } else {
      st.VIS.tgtRel = null; st.VIS.tgtVelRel = null;
    }
  }

  function getPivot() {
    if (st.mode === 'free') return st.freePivot;
    let base;
    if (st.mode === 'ship') {
      base = add(st.VIS.P, st.VIS.r);
      if (st.viewMode === 'flight' && st.ship) {
        const objScale = st.dist < 1.8 ? 1.0 : st.dist * 0.56;
        const centerOff = (st.ship.stage === 1 ? 0.017 : 0.007) * objScale;
        base = add(base, mul(st.VIS.att, centerOff));
      }
    }
    else if (st.mode === 'planet') base = st.VIS.P;
    else if (st.mode === 'moon') base = st.VIS.M;
    else if (st.mode === 'target' && st.VIS.tgtRel) base = add(st.VIS.P, st.VIS.tgtRel);
    else base = add(st.VIS.P, st.VIS.r);
    return add(base, st.panOff);
  }

  function camBasis() {
    const cp = Math.cos(st.pitch), sp = Math.sin(st.pitch);
    const pivot = getPivot();

    if (st.viewMode === 'flight' && st.mode === 'ship') {
      const upRef = unit(st.VIS.r);
      let east = cross([0, 0, 1], upRef);
      east = len(east) > 1e-4 ? unit(east) : [0, 1, 0];
      const north = cross(upRef, east);

      // Align default pad yaw (PAD_LON0 + 1.32) to a clean Southeast sunlit 3/4 view
      const az = st.yaw - (PAD_LON0 + 2.17);
      const d = add(
        mul(east, cp * Math.cos(az)),
        add(mul(north, cp * Math.sin(az)), mul(upRef, sp))
      );
      let pos = add(pivot, mul(d, st.dist));

      const camRelP = sub(pos, st.VIS.P);
      const minCamR = OC.surfaceRadiusAt(camRelP, st.VIS.t) + 0.003;
      const camR = len(camRelP);
      if (camR < minCamR) {
        pos = add(st.VIS.P, mul(unit(camRelP), minCamR));
      }

      const fwd = unit(sub(pivot, pos));
      let right = cross(fwd, upRef);
      right = len(right) > 1e-4 ? unit(right) : east;
      const up = cross(right, fwd);

      if (st.screenShake > 0.001) {
        const shakeMag = st.screenShake * Math.min(1.0, st.dist * 0.035);
        const sx = (Math.random() - 0.5) * 2 * shakeMag;
        const sy = (Math.random() - 0.5) * 2 * shakeMag;
        pos = add(pos, add(mul(right, sx), mul(up, sy)));
      }

      return { pos, fwd, right, up };
    }

    const d = [cp * Math.cos(st.yaw), cp * Math.sin(st.yaw), sp];
    let pos = add(pivot, mul(d, st.dist));
    const fwd = mul(d, -1);
    const right = unit(cross(fwd, [0, 0, 1]));
    const up = cross(right, fwd);
    if (st.screenShake > 0.001) {
      const shakeMag = st.screenShake * Math.min(1.0, st.dist * 0.035);
      const sx = (Math.random() - 0.5) * 2 * shakeMag;
      const sy = (Math.random() - 0.5) * 2 * shakeMag;
      pos = add(pos, add(mul(right, sx), mul(up, sy)));
    }
    return { pos, fwd, right, up };
  }

  function project(p) {
    const qx = p[0] - st.CAM.pos[0], qy = p[1] - st.CAM.pos[1], qz = p[2] - st.CAM.pos[2];
    const z = qx * st.CAM.fwd[0] + qy * st.CAM.fwd[1] + qz * st.CAM.fwd[2];
    if (z < 0.01) return null;
    const rx = qx * st.CAM.right[0] + qy * st.CAM.right[1] + qz * st.CAM.right[2];
    const uy = qx * st.CAM.up[0] + qy * st.CAM.up[1] + qz * st.CAM.up[2];
    return [st.W * 0.5 + st.F * rx / z, st.H * 0.5 - st.F * uy / z];
  }

  function projectRel(q) {
    const dx = q[0] - st.VIS.camRelP[0], dy = q[1] - st.VIS.camRelP[1], dz = q[2] - st.VIS.camRelP[2];
    const z = dx * st.CAM.fwd[0] + dy * st.CAM.fwd[1] + dz * st.CAM.fwd[2];
    if (z < 0.01) return null;
    const rx = dx * st.CAM.right[0] + dy * st.CAM.right[1] + dz * st.CAM.right[2];
    const uy = dx * st.CAM.up[0] + dy * st.CAM.up[1] + dz * st.CAM.up[2];
    return [st.W * 0.5 + st.F * rx / z, st.H * 0.5 - st.F * uy / z];
  }

  function setMode(m) {
    if (m === 'target' && !st.targetBody) m = 'free';
    const p = getPivot();
    if (m === 'free') st.freePivot = p;
    st.panOff = [0, 0, 0];
    st.mode = m;
    document.getElementById('btnCam').textContent = 'CAM:' + st.mode.toUpperCase();
  }

  function setViewMode(vm) {
    if (vm === st.viewMode) return;
    st.viewCameras[st.viewMode] = {
      mode: st.mode, yaw: st.yaw, pitch: st.pitch, dist: st.dist,
      panOff: [...st.panOff], freePivot: [...st.freePivot]
    };
    st.viewMode = vm;
    const next = st.viewCameras[vm];
    st.mode = (next.mode === 'target' && !st.targetBody) ? 'ship' : next.mode;
    st.yaw = next.yaw; st.pitch = next.pitch; st.dist = next.dist;
    st.panOff = [...next.panOff]; st.freePivot = [...next.freePivot];

    OC.glCanvas.style.display = 'block';
    OC.resizeGL(Math.min(window.devicePixelRatio || 1, 2));
    document.getElementById('btnCam').textContent = 'CAM:' + st.mode.toUpperCase();
    OC.syncViewBtn();
    OC.showToast(vm === 'map' ? 'Map View — Orbit & SOI Planner' : 'Flight View — 3D Spacecraft Camera');
  }

  function resetView() {
    const onPad = st.ship && st.ship.onPad;
    const def = st.viewMode === 'flight'
      ? { yaw: onPad ? PAD_LON0 + 1.32 : 0.45, pitch: onPad ? 0.14 : 0.25, dist: onPad ? CONFIG.view.padStartDistKm : CONFIG.view.flightStartDistKm }
      : { yaw: onPad ? PAD_LON0 + 0.4 : 0.40, pitch: 0.55, dist: CONFIG.view.mapStartDistKm };
    st.yaw = def.yaw; st.pitch = def.pitch; st.dist = def.dist; st.panOff = [0, 0, 0];
    if (st.mode === 'free') st.freePivot = st.VIS.P;
  }

  function dropWarpForThrust() {
    if (st.autoWarp) { st.autoWarp = null; OC.showToast('Auto-warp cancelled (burn)'); }
    if (st.warpIdx > 1) {
      st.warpIdx = 0; OC.renderWarpBtns();
      st.accum = Math.min(st.accum, PH);
      OC.showToast('Warp dropped to 1x for engine burn');
    }
  }

  function launchOrStage() {
    const s = st.ship;
    if (!s || st.crashed || st.missionDone) return;
    if (s.onPad) {
      s.onPad = false;
      s.mainEngine = true;
      if (st.throttle < 0.2) OC.setThrottle(1);
      dropWarpForThrust();
      for (let i = 0; i < 22; i++) {
        const a = Math.random() * 6.283;
        const spread = [Math.cos(a) * 0.04, Math.sin(a) * 0.04, (Math.random() - 0.5) * 0.04];
        st.particles.push({ p: [...s.r], v: add(s.v, spread), life: 1.0, col: '#d8e2ec', size: 4.5 });
      }
      OC.showToast('T-0 LIFTOFF!');
      st.screenShake = Math.max(st.screenShake, 0.08);
      OC.SFX.beep(680, 0.14, 'triangle', 0.10);
    } else if (s.stage === 1) {
      const s1Pos = sub(s.r, mul(s.att, 0.021));
      let tumbleAxis = cross(s.att, [0, 0, 1]);
      if (len(tumbleAxis) < 0.1) tumbleAxis = cross(s.att, [1, 0, 0]);
      tumbleAxis = unit(tumbleAxis);
      s.debris.push({
        r: [s1Pos[0], s1Pos[1], s1Pos[2]],
        v: add(s.v, mul(s.att, -0.008)),
        att: [s.att[0], s.att[1], s.att[2]],
        tumbleAxis: [tumbleAxis[0], tumbleAxis[1], tumbleAxis[2]],
        spin: 0, spinRate: 0.35, age: 0
      });
      s.stage = 2;
      st.screenShake = Math.max(st.screenShake, 0.10);
      OC.predCache.dirty = true;
      OC.SFX.stageSep();
      OC.showToast('STAGE 1 SEPARATION — STAGE 2 ACTIVE');
    }
  }

  function toggleMainEngine() {
    const s = st.ship;
    if (!s || st.crashed || st.missionDone) return;
    if (s.onPad) { launchOrStage(); return; }
    s.mainEngine = !s.mainEngine;
    if (s.mainEngine) {
      if (st.throttle <= 0) OC.setThrottle(1);
      dropWarpForThrust();
      OC.showToast('Main Engine: IGNITION');
    } else {
      OC.showToast('Main Engine: CUTOFF');
    }
    OC.SFX.beep(s.mainEngine ? 540 : 320, 0.08, 'sine', 0.06);
  }

  function toggleChute() {
    const s = st.ship;
    if (!s || st.crashed || st.missionDone) return;
    if (s.chuteState > 0) { OC.showToast('Parachute already deployed'); return; }
    const agl = len(s.r) - OC.surfaceRadiusAt(s.r, st.t);
    const radVel = dot(s.v, unit(s.r));
    if (!s.onPad && !s.landed && agl < 10 && radVel < 0) {
      s.chuteState = agl < 2.6 ? 2 : 1;
      OC.showToast(s.chuteState === 2 ? 'MAIN CHUTE OPEN!' : 'DROGUE CHUTE DEPLOYED!');
      OC.SFX.beep(600, 0.12, 'triangle', 0.08);
    } else {
      s.chuteArmed = !s.chuteArmed;
      OC.showToast(`Parachute: ${s.chuteArmed ? 'ARMED (<10 km)' : 'DISARMED'}`);
      OC.SFX.beep(480, 0.07, 'sine', 0.05);
    }
  }

  function startWarpToApsis(kind) {
    if (st.crashed || st.missionDone || st.ship.onPad || st.ship.landed) return;
    const { dtAp, dtPe } = OC.timeToApsis(st.ship.r, st.ship.v);
    const dt = kind === 'ap' ? dtAp : dtPe;
    if (dt === null) { OC.showToast('Apsis undefined (orbit near-circular or hyperbolic)'); return; }
    if (dt < 14) { OC.showToast(`Already near ${kind.toUpperCase()}`); return; }
    st.autoWarp = { targetT: st.t + dt - 12, label: kind.toUpperCase() };
    st.paused = false;
    OC.showToast(`Warping to ${kind.toUpperCase()} (${(dt / 60).toFixed(1)} min)`);
    OC.SFX.beep(520, 0.08, 'triangle', 0.06);
  }

  function updateAutoWarp() {
    if (!st.autoWarp) return;
    const rem = st.autoWarp.targetT - st.t;
    if (rem <= 0) {
      const lbl = st.autoWarp.label;
      st.autoWarp = null;
      if (st.warpIdx !== 0) { st.warpIdx = 0; OC.renderWarpBtns(); }
      OC.showToast(`Approaching ${lbl} — 1x warp`);
      OC.SFX.beep(780, 0.10, 'triangle', 0.07);
      return;
    }
    const desired = rem > 25000 ? 5 : rem > 2500 ? 4 : rem > 280 ? 3 : rem > 55 ? 2 : rem > 12 ? 1 : 0;
    if (desired !== st.warpIdx) { st.warpIdx = desired; OC.renderWarpBtns(); }
  }

  function toggleMute() {
    S.sfx = !S.sfx;
    OC.SFX.setMuted(!S.sfx);
    document.getElementById('btnAudio').classList.toggle('on', S.sfx);
    OC.syncMenu();
  }

  addEventListener('resize', resize);
  addEventListener('keydown', e => {
    OC.SFX.init();
    const k = e.key.toLowerCase();
    if (st.listening) {
      e.preventDefault();
      if (k !== 'escape') { const old = B[st.listening]; for (const a in B) if (B[a] === k) B[a] = old; B[st.listening] = k; }
      st.listening = null; OC.renderKeys(); return;
    }
    if (k === 'escape') {
      if (!sandboxModal.classList.contains('hidden')) { sandboxModal.classList.add('hidden'); return; }
      if (!missionModal.classList.contains('hidden')) { if (!document.getElementById('closeMissions').classList.contains('hidden')) { missionModal.classList.add('hidden'); st.paused = false; } return; }
      st.menuOpen ? OC.closeMenu() : OC.openMenu(); return;
    }
    if (!missionModal.classList.contains('hidden') || !resultModal.classList.contains('hidden')) {
      if (k === B.reset && !resultModal.classList.contains('hidden')) OC.resetMission();
      return;
    }
    if (st.menuOpen) return;
    if (k === B.viewToggle) { e.preventDefault(); setViewMode(st.viewMode === 'flight' ? 'map' : 'flight'); return; }
    if (k === B.stage) { launchOrStage(); return; }
    if (k === B.engine) { e.preventDefault(); toggleMainEngine(); return; }
    if (k === B.chute) { toggleChute(); return; }
    if (k === 't') {
      if (!st.ship) return;
      const modes = ['off', 'hold', 'up', 'pro', 'ret'];
      const curIdx = modes.indexOf(st.ship.sas);
      st.ship.sas = modes[(curIdx + 1) % modes.length];
      OC.syncSasBtns();
      OC.showToast(`SAS: ${st.ship.sas.toUpperCase()}`);
      OC.SFX.beep(600, 0.05, 'sine', 0.04);
      return;
    }
    if (k === 'y' || k === B.ctrlMode) {
      if (OC.toggleControlMode) OC.toggleControlMode();
      return;
    }
    if (k === 'shift' || k === 'control') { st.keys.add(k); }
    if (k === 'm') { OC.openMissionModal(true); return; }
    if (k === 'n') { toggleMute(); return; }
    if (k === '0') { OC.setThrottle(0); OC.showToast('Engine Cutoff (0%)'); return; }
    if (k === 'z') { OC.setThrottle(1); OC.showToast('Throttle 100%'); return; }
    if (k === '[') { OC.setThrottle(st.throttle - 0.1); return; }
    if (k === ']') { OC.setThrottle(st.throttle + 0.1); return; }
    if (k === '1') { OC.setThrottle(0.1); return; }
    if (k === '2') { OC.setThrottle(0.25); return; }
    if (k === '3') { OC.setThrottle(0.5); return; }
    if (k === '4') { OC.setThrottle(1.0); return; }
    if (k === B.navRef) { OC.toggleNavRef(); return; }
    if (k === B.pause) { if (!st.crashed && !st.missionDone) { st.paused = !st.paused; if (st.paused) st.autoWarp = null; } e.preventDefault(); return; }
    if (k === B.reset) { OC.resetMission(); return; }
    if (k === B.camera) { setMode(st.modeList[(st.modeList.indexOf(st.mode) + 1) % st.modeList.length]); return; }
    if (k === B.resetView) { resetView(); return; }
    if (k === B.warpUp) { st.autoWarp = null; st.warpIdx = Math.min(CONFIG.warpLevels.length - 1, st.warpIdx + 1); OC.renderWarpBtns(); }
    if (k === B.warpDown) { st.autoWarp = null; st.warpIdx = Math.max(0, st.warpIdx - 1); OC.renderWarpBtns(); }
    if (['a', 'd', 'arrowleft', 'arrowright', 'arrowup', 'arrowdown'].includes(k)) { e.preventDefault(); st.keys.add(k); return; }
    if (THRUST_ACTS.some(a => B[a] === k)) { dropWarpForThrust(); st.keys.add(k); }
  });
  addEventListener('keyup', e => st.keys.delete(e.key.toLowerCase()));
  addEventListener('blur', () => { st.keys.clear(); st.uiThrust.clear(); });

  let dragging = false, panning = false, lastX = 0, lastY = 0;
  const ptrs = new Map(); let pinchD = 0, pinchX = 0, pinchY = 0, lastTap = 0;
  const gizY = () => st.H - 86 - (document.documentElement.classList.contains('touch') ? 70 : 0);
  OC.gizmoY = gizY;
  canvas.addEventListener('contextmenu', e => e.preventDefault());
  canvas.addEventListener('pointerdown', e => {
    OC.SFX.init();
    if (S.gizmo && Math.hypot(e.clientX - 86, e.clientY - gizY()) <= 50) {
      if (st.targetBody) OC.toggleNavRef();
      return;
    }
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
    if (ptrs.size === 2) {
      dragging = false;
      const [a, b] = [...ptrs.values()];
      pinchD = Math.hypot(a.x - b.x, a.y - b.y) || 1; pinchX = (a.x + b.x) / 2; pinchY = (a.y + b.y) / 2;
      return;
    }
    if (e.pointerType === 'touch') { const n = performance.now(); if (n - lastTap < 280) resetView(); lastTap = n; }
    dragging = true; panning = e.button === 2 || e.shiftKey;
    lastX = e.clientX; lastY = e.clientY;
  });
  const endPtr = e => {
    ptrs.delete(e.pointerId);
    if (ptrs.size === 0) dragging = false;
    else if (ptrs.size === 1) { const p = [...ptrs.values()][0]; lastX = p.x; lastY = p.y; dragging = true; panning = false; }
  };
  addEventListener('pointerup', endPtr);
  addEventListener('pointercancel', endPtr);
  addEventListener('pointermove', e => {
    if (st.menuOpen || !st.CAM) return;
    const rec = ptrs.get(e.pointerId);
    if (rec) { rec.x = e.clientX; rec.y = e.clientY; }
    if (ptrs.size >= 2) { // pinch zoom + two-finger pan
      const [a, b] = [...ptrs.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y) || 1, mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      st.dist = clamp(st.dist * pinchD / d, CONFIG.view.minDistKm, CONFIG.view.maxDistKm);
      const k = st.dist * 0.0016, delta = add(mul(st.CAM.right, -(mx - pinchX) * k), mul(st.CAM.up, (my - pinchY) * k));
      if (st.mode === 'free') st.freePivot = add(st.freePivot, delta); else st.panOff = add(st.panOff, delta);
      pinchD = d; pinchX = mx; pinchY = my;
      return;
    }
    if (!dragging) return;
    const dx = e.clientX - lastX, dy = e.clientY - lastY;
    lastX = e.clientX; lastY = e.clientY;
    if (panning) {
      const k = st.dist * 0.0016;
      const delta = add(mul(st.CAM.right, -dx * k), mul(st.CAM.up, dy * k));
      if (st.mode === 'free') st.freePivot = add(st.freePivot, delta);
      else st.panOff = add(st.panOff, delta);
    } else {
      st.yaw += (S.invert ? 1 : -1) * dx * 0.005 * S.sens;
      st.pitch = clamp(st.pitch + dy * 0.005, -1.45, 1.45);
    }
  });
  canvas.addEventListener('wheel', e => {
    st.dist = clamp(st.dist * Math.exp(e.deltaY * 0.001), CONFIG.view.minDistKm, CONFIG.view.maxDistKm);
    e.preventDefault();
  }, { passive: false });

  function frame(now) {
    const dtFrame = Math.min(0.05, Math.max(0, (now - last) / 1000));
    last = now;
    { // adaptive resolution: trade pixels for frame rate on slow GPUs
      const raw = dtFrame * 1000;
      if (raw > 0 && raw < 249) st._ema = (st._ema || 16.7) * 0.93 + raw * 0.07;
      if ((st._n = (st._n || 0) + 1) % 45 === 0 && !document.hidden && !st.menuOpen && !st.paused) {
        const cur = st.dynRes || 1; let d = cur;
        if (st._ema > 27 && d > 0.5) d = Math.max(0.5, d - 0.12);
        else if (st._ema < 18 && d < 1) d = Math.min(1, d + 0.06);
        if (Math.abs(d - cur) > 0.01) { st.dynRes = d; OC.resizeGL(Math.min(window.devicePixelRatio || 1, 2)); }
      }
    }
    if (st.screenShake > 0.0001) st.screenShake *= Math.exp(-dtFrame * 6.5);

    for (let i = st.particles.length - 1; i >= 0; i--) {
      const pt = st.particles[i];
      pt.p[0] += pt.v[0] * dtFrame * 8; pt.p[1] += pt.v[1] * dtFrame * 8; pt.p[2] += pt.v[2] * dtFrame * 8;
      pt.life -= dtFrame * 1.3;
      if (pt.life <= 0) st.particles.splice(i, 1);
    }

    if (st.keys.has('shift')) OC.setThrottle(st.throttle + dtFrame * 0.45);
    if (st.keys.has('control')) OC.setThrottle(st.throttle - dtFrame * 0.45);

    if (!st.paused && !st.crashed && !st.missionDone && !st.menuOpen) {
      const s = st.ship;
      OC.stepAttitude(dtFrame);

      const engBurning = !s.onPad && (OC.anyThrustRequested() || (s.mainEngine && st.throttle > 0)) && OC.activeFuel(s) > 0;
      if (engBurning && st.warpIdx > 1) dropWarpForThrust();
      updateAutoWarp();

      st.accum += dtFrame * CONFIG.warpLevels[st.warpIdx];
      let n = 0;
      const m = OC.MISSIONS[st.currentMissionIdx];
      while (st.accum >= PH && n < 2500) {
        OC.stepShip(PH); st.accum -= PH; n++;

        const rLenNow = len(s.r);
        const surfR = OC.surfaceRadiusAt(s.r, st.t);
        const altNow = rLenNow - CONFIG.body.radius;
        const aglNow = rLenNow - surfR;

        if (!s.onPad && !s.landed) {
          if (s.mach >= 1.0 && !s.milestones.mach1) { s.milestones.mach1 = true; OC.showToast('MACH 1.0 — SUPERSONIC!'); OC.SFX.beep(680, 0.10, 'triangle', 0.08); }
          if (altNow >= CONFIG.body.atmoKm && !s.milestones.space) { s.milestones.space = true; OC.showToast('70 km SPACE — Press Y for Manual Attitude'); OC.SFX.beep(880, 0.14, 'triangle', 0.09); }
          if (s.stage === 1 && s.fuel1 <= 0 && !s.milestones.s1dry) { s.milestones.s1dry = true; OC.showToast('Stage 1 Empty — Press G to Separate!'); OC.SFX.beep(440, 0.14, 'square', 0.07); }
          if (st.warpIdx > 1 && altNow < CONFIG.body.atmoKm) {
            st.autoWarp = null; st.warpIdx = 1; OC.renderWarpBtns();
            st.accum = Math.min(st.accum, dtFrame * CONFIG.warpLevels[1]);
            OC.showToast('Atmosphere entry — Warp dropped to 5x');
          }
          if (st.warpIdx > 1) {
            const dMoonNow = len(sub(s.r, OC.moonRelPos(st.t)));
            if (dMoonNow < CONFIG.moon.soiKm) {
              st.autoWarp = null; st.warpIdx = 0; OC.renderWarpBtns();
              st.accum = Math.min(st.accum, dtFrame);
              OC.showToast('Entering Selene SOI — Warp dropped to 1x');
            } else if (st.targetBody) {
              const tDist = len(sub(s.r, st.targetBody.relPosAt(st.t)));
              const safeDist = st.targetBody.isMoon ? CONFIG.moon.soiKm : 45;
              if (tDist < safeDist) {
                st.autoWarp = null; st.warpIdx = 0; OC.renderWarpBtns();
                st.accum = Math.min(st.accum, dtFrame);
                OC.showToast(`Entering ${st.targetBody.name} zone — 1x warp`);
              }
            }
          }
          if (st.thrustedLastStep && n % 2 === 0) {
            const nearPad = aglNow < 0.25;
            const pVel = nearPad
              ? add(s.v, [(Math.random() - 0.5) * 0.04, (Math.random() - 0.5) * 0.04, (Math.random() - 0.5) * 0.04])
              : add(s.v, mul(st.lastDirVec, -(1.2 + Math.random() * 1.5)));
            st.particles.push({ p: [s.r[0], s.r[1], s.r[2]], v: pVel, life: nearPad ? 1.0 : 0.7, col: nearPad ? '#dce4ee' : '#ffbe66', size: nearPad ? 4.2 : 1.8 });
          }

          // Atmospheric hypersonic re-entry plasma fire trails
          if (altNow < 65 && s.dynQ > 0.6 && len(s.v) > 1.1) {
            const heatInt = clamp((s.dynQ - 0.6) * 0.35 * (len(s.v) - 0.9), 0, 1);
            if (Math.random() < heatInt * 0.75) {
              const revV = unit(mul(s.v, -1));
              const spread = [
                revV[0] + (Math.random() - 0.5) * 0.22,
                revV[1] + (Math.random() - 0.5) * 0.22,
                revV[2] + (Math.random() - 0.5) * 0.22
              ];
              st.particles.push({
                p: [s.r[0], s.r[1], s.r[2]],
                v: mul(spread, len(s.v) * 0.55),
                life: 0.35 + Math.random() * 0.35,
                col: Math.random() < 0.35 ? '#ffffff' : (Math.random() < 0.7 ? '#ff9922' : '#ff3311'),
                size: 2.8 + heatInt * 3.5
              });
            }
          }
        }

        const info = OC.orbitInfo(OC.relR(), OC.relV());
        st.missionStatus = m.update(st.missionState, PH, info);
        const doneCnt = st.missionStatus.objs.filter(o => o.ok).length;
        if (doneCnt > st.prevDoneCount) { OC.SFX.beep(740, 0.11, 'triangle', 0.08); st.prevDoneCount = doneCnt; }
        if (st.missionStatus.done) { OC.completeMission(); break; }

        if (OC.activeFuel(s) > 0 && OC.activeFuel(s) / Math.max(0.001, OC.activeMaxFuel(s)) < 0.15 && !st.lowFuelWarned) {
          st.lowFuelWarned = true; OC.showToast('WARNING: Stage Propellant < 15%'); OC.SFX.beep(310, 0.18, 'square', 0.07);
        }

        if (!s.onPad && !s.landed && rLenNow <= surfR + 0.0006) {
          const vSurf = OC.surfaceVelAt(s.r);
          const vRel = sub(s.v, vSurf);
          const nGround = OC.terrainNormalAtRel(s.r, st.t);
          const vNorm = dot(vRel, nGround);
          const vDown = -vNorm;
          const vTang = sub(vRel, mul(nGround, vNorm));
          const vTangSpd = len(vTang);
          const vTotal = len(vRel);
          const splash = OC.isWaterAtRel(s.r, st.t);
          const attAlign = dot(s.att, nGround);

          // Tier 1: Nominal Safe Touchdown / Splashdown
          const maxSafeDown = splash ? 0.024 : 0.013;
          const maxSafeTang = splash ? 0.020 : 0.008;
          const isUpright = splash ? attAlign > 0.40 : attAlign > 0.65;

          if (vDown <= maxSafeDown && vTangSpd <= maxSafeTang && isUpright) {
            s.r = mul(unit(s.r), surfR + 0.0012);
            s.v = vSurf;
            s.att = nGround;
            s.angVel = [0, 0, 0];
            s.landed = true; s.mainEngine = false; s.chuteState = 0; s.chuteArmed = false;
            st.thrustedLastStep = false; st.accum = 0;
            st.screenShake = Math.max(st.screenShake, 0.06);

            const sprayCol = splash ? '#9ed4f8' : '#d2cbbf';
            for (let k = 0; k < 28; k++) {
              const a = Math.random() * TAU, spd = 0.004 + Math.random() * 0.018;
              st.particles.push({
                p: [s.r[0], s.r[1], s.r[2]],
                v: add(vSurf, [Math.cos(a) * spd, Math.sin(a) * spd, Math.random() * 0.012]),
                life: 0.8 + Math.random() * 0.5,
                col: sprayCol,
                size: splash ? 3.5 : 2.5
              });
            }

            OC.showToast(`${splash ? 'SPLASHDOWN' : 'TOUCHDOWN'} SAFE (${(vTotal * 1000).toFixed(1)} m/s)!`);
            st.missionStatus = m.update(st.missionState, 0, OC.orbitInfo(OC.relR(), OC.relV()));
            if (st.missionStatus.done) { OC.completeMission(); break; }
            OC.SFX.beep(660, 0.18, 'triangle', 0.09);
            break;
          } else if (vDown <= (splash ? 0.034 : 0.024) && vTangSpd <= 0.022) {
            // Tier 2: Hard Landing Contact / Bouncing / Ground Friction
            s.r = mul(unit(s.r), surfR + 0.0016);
            const restitution = splash ? 0.08 : 0.22;
            const newNorm = Math.max(0.002, -vNorm * restitution);
            const friction = splash ? 0.40 : 0.60;
            const newTang = mul(vTang, friction);
            s.v = add(vSurf, add(mul(nGround, newNorm), newTang));
            st.screenShake = Math.max(st.screenShake, 0.18);
            if (OC.SFX) OC.SFX.beep(120, 0.16, 'sawtooth', 0.12);

            for (let k = 0; k < 18; k++) {
              st.particles.push({
                p: [s.r[0], s.r[1], s.r[2]],
                v: add(vSurf, [(Math.random() - 0.5) * 0.02, (Math.random() - 0.5) * 0.02, Math.random() * 0.015]),
                life: 0.5 + Math.random() * 0.4,
                col: splash ? '#c4e8ff' : (Math.random() < 0.5 ? '#ffaa33' : '#a89d8d'),
                size: 2.8
              });
            }
            OC.showToast(`HARD CONTACT (${(vTotal * 1000).toFixed(1)} m/s) — BOUNCED!`);
          } else {
            // Tier 3: Catastrophic Crash Detonation
            st.screenShake = 0.45;
            OC.triggerCrash(CONFIG.body.name, (vTotal * 1000).toFixed(1));
            break;
          }
        }

        const mRelNow = sub(s.r, OC.moonRelPos(st.t));
        const moonSurfR = OC.moonSurfaceRadiusAt(mRelNow);
        const distMoonNow = len(mRelNow);
        if (distMoonNow <= moonSurfR + 0.0006) {
          const vMoon = OC.moonRelVel(st.t);
          const vRelM = sub(s.v, vMoon);
          const nMoon = OC.moonNormalAtRel(mRelNow);
          const vNorm = dot(vRelM, nMoon);
          const vDown = -vNorm;
          const vTang = sub(vRelM, mul(nMoon, vNorm));
          const vTangSpd = len(vTang);
          const vTotal = len(vRelM);
          const attAlign = dot(s.att, nMoon);

          if (vDown <= 0.015 && vTangSpd <= 0.008 && attAlign > 0.65) {
            s.landedMoon = true;
            s.landed = true;
            s.moonLandingUnit = nMoon;
            s.r = add(OC.moonRelPos(st.t), mul(nMoon, moonSurfR + 0.0012));
            s.v = vMoon;
            s.att = nMoon;
            s.angVel = [0, 0, 0];
            s.mainEngine = false; s.chuteState = 0; s.chuteArmed = false;
            st.thrustedLastStep = false; st.accum = 0;
            st.screenShake = Math.max(st.screenShake, 0.08);

            for (let k = 0; k < 24; k++) {
              const a = Math.random() * TAU, spd = 0.003 + Math.random() * 0.012;
              st.particles.push({
                p: [s.r[0], s.r[1], s.r[2]],
                v: add(vMoon, [Math.cos(a) * spd, Math.sin(a) * spd, Math.random() * 0.008]),
                life: 0.9 + Math.random() * 0.6,
                col: '#bfc4cc',
                size: 2.4
              });
            }

            OC.showToast(`SAFE TOUCHDOWN ON SELENE (${(vTotal * 1000).toFixed(1)} m/s)!`);
            OC.SFX.beep(720, 0.22, 'triangle', 0.10);
            st.missionStatus = m.update(st.missionState, 0, OC.orbitInfo(OC.relR(), OC.relV(), st.t));
            if (st.missionStatus.done) { OC.completeMission(); break; }
            break;
          } else if (vDown <= 0.025 && vTangSpd <= 0.020) {
            s.r = add(OC.moonRelPos(st.t), mul(unit(mRelNow), moonSurfR + 0.0016));
            const newNorm = Math.max(0.002, -vNorm * 0.22);
            s.v = add(vMoon, add(mul(nMoon, newNorm), mul(vTang, 0.65)));
            st.screenShake = Math.max(st.screenShake, 0.16);
            if (OC.SFX) OC.SFX.beep(110, 0.16, 'sawtooth', 0.12);
            OC.showToast(`LUNAR REGOLITH HARD BOUNCE (${(vTotal * 1000).toFixed(1)} m/s)!`);
          } else {
            st.screenShake = 0.45;
            OC.triggerCrash(CONFIG.moon.name, (vTotal * 1000).toFixed(1));
            break;
          }
        }
        if (st.autoWarp && st.t >= st.autoWarp.targetT) { updateAutoWarp(); break; }
      }
      if (n >= 2500) st.accum = Math.min(st.accum, PH * 0.99);
      OC.SFX.setThrust(st.thrustedLastStep ? st.throttle : 0);
      OC.updateMissionHud(false);
    } else {
      OC.SFX.setThrust(0);
    }

    OC.hudPanel.classList.toggle('hidden', !S.hud);
    OC.helpPanel.classList.toggle('hidden', !S.help);

    updateVisualSnapshot();
    st.CAM = camBasis();
    st.VIS.camRelP[0] = st.CAM.pos[0] - st.VIS.P[0];
    st.VIS.camRelP[1] = st.CAM.pos[1] - st.VIS.P[1];
    st.VIS.camRelP[2] = st.CAM.pos[2] - st.VIS.P[2];
    st.SUNDIR[0] = -st.VIS.P[0]; st.SUNDIR[1] = -st.VIS.P[1]; st.SUNDIR[2] = -st.VIS.P[2];
    const sLen = Math.hypot(st.SUNDIR[0], st.SUNDIR[1], st.SUNDIR[2]) || 1;
    st.SUNDIR[0] /= sLen; st.SUNDIR[1] /= sLen; st.SUNDIR[2] /= sLen;

    if (st.viewMode === 'flight') OC.drawFlightView(ctx, now);
    else OC.drawMapView(ctx, now);

    OC.updateHud();
    requestAnimationFrame(frame);
  }

  Object.assign(OC, {
    updateVisualSnapshot, project, projectRel, setMode, setViewMode,
    resetView, dropWarpForThrust, launchOrStage, toggleMainEngine, toggleChute, startWarpToApsis, toggleMute
  });

  resize();
  OC.bindUI();
  OC.renderKeys();
  OC.renderWarpBtns();
  st.ship = OC.makeShip();
  st.testOk = OC.selfTest();
  OC.startMission(0);
  OC.openMissionModal(false);
  requestAnimationFrame(now => { last = now; frame(now); });
})(window.OC);