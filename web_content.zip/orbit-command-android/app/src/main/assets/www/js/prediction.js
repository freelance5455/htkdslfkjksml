'use strict';

(function (OC) {
  const { CONFIG, S, MOON_A, MOON_N, clamp, len, orbitInfo, rk4RelInto, totalMass, currentCdArea, state: st } = OC;

  const MAX_PRED_PTS = 1200;
  const predPtsBuf = new Float64Array(MAX_PRED_PTS * 3);
  const _rkOut = new Float64Array(6);

  const predCache = {
    pts: predPtsBuf, count: 0, startT: 0, dt: 1, closed: false, drawClosed: false,
    pePt: null, minAlt: Infinity, apPt: null, maxAlt: -Infinity,
    impactPt: null, impactBody: null, hadAtmo: false, postAtmoAp: null,
    closestTargetKm: Infinity, cpaPt: null,
    moonSoiEntryPt: null, minMoonAlt: Infinity, moonPePt: null, soiEscapePt: null,
    lastCalcMs: -9999, lastSimT: -9999, lastSamples: 0, dirty: true
  };

  function predictPath(samples) {
    if (st.ship.onPad || st.ship.landed) {
      predCache.count = 0;
      predCache.closed = false; predCache.drawClosed = false;
      predCache.pePt = null; predCache.apPt = null; predCache.impactPt = null;
      predCache.cpaPt = null; predCache.moonSoiEntryPt = null; predCache.moonPePt = null; predCache.soiEscapePt = null;
      predCache.lastCalcMs = performance.now(); predCache.lastSimT = st.t; predCache.dirty = false;
      return predCache;
    }

    let rx = st.VIS.r[0], ry = st.VIS.r[1], rz = st.VIS.r[2];
    let vx = st.VIS.v[0], vy = st.VIS.v[1], vz = st.VIS.v[2];
    let tt = st.VIS.t;

    const info = orbitInfo([rx, ry, rz], [vx, vy, vz], tt);
    const closed = info.periodS !== null && info.e < 0.992;
    const spanS = closed ? Math.min(info.periodS * 1.01, 75000) : 36000;
    const fullLoop = closed && (info.periodS * 1.01 <= 75000);
    const mass = totalMass(st.ship);
    const cdArea = currentCdArea(st.ship);

    let minAlt = Infinity, maxAlt = -Infinity;
    let pePt = null, apPt = null, impactPt = null, impactBody = null;
    let closestTargetKm = Infinity, cpaPt = null;
    let moonSoiEntryPt = null, minMoonAlt = Infinity, moonPePt = null, soiEscapePt = null;
    let hadAtmo = false, inAtmoNow = false, postAtmoAp = null;
    let count = 0;

    // Point 0 is exactly the ship's current visual position
    predPtsBuf[0] = rx; predPtsBuf[1] = ry; predPtsBuf[2] = rz;
    count = 1;

    let lastRecordX = rx, lastRecordY = ry, lastRecordZ = rz;
    let lastRecordT = tt;
    let elapsedS = 0;

    const maInit = MOON_N * tt + 0.9;
    let inMoonSoi = Math.hypot(rx - MOON_A * Math.cos(maInit), ry - MOON_A * Math.sin(maInit), rz) <= CONFIG.moon.soiKm;
    let hadMoonEncounter = inMoonSoi;

    while (elapsedS < spanS && count < MAX_PRED_PTS - 1) {
      const rLen0 = Math.hypot(rx, ry, rz);
      const alt0 = rLen0 - CONFIG.body.radius;
      if (alt0 < minAlt) { minAlt = alt0; pePt = [rx, ry, rz]; }
      if (alt0 > maxAlt) { maxAlt = alt0; apPt = [rx, ry, rz]; }

      const ma0 = MOON_N * tt + 0.9;
      const mx0 = MOON_A * Math.cos(ma0), my0 = MOON_A * Math.sin(ma0);
      const distMoon0 = Math.hypot(rx - mx0, ry - my0, rz);
      const moonAlt0 = distMoon0 - CONFIG.moon.radius;
      if (moonAlt0 < minMoonAlt) {
        minMoonAlt = moonAlt0;
        moonPePt = [rx, ry, rz];
      }

      let distTgt0 = Infinity;
      if (st.targetBody) {
        const tp0 = st.targetBody.relPosAt(tt);
        distTgt0 = Math.hypot(rx - tp0[0], ry - tp0[1], rz - tp0[2]);
        if (distTgt0 < closestTargetKm) { closestTargetKm = distTgt0; cpaPt = [rx, ry, rz]; }
      }

      const surfElev0 = alt0 < 3.5 && OC.terrainHeightAtRel ? OC.terrainHeightAtRel([rx, ry, rz], tt) : 0;
      if (alt0 <= surfElev0) {
        impactPt = [rx, ry, rz]; impactBody = CONFIG.body.name;
        predPtsBuf[count * 3] = rx; predPtsBuf[count * 3 + 1] = ry; predPtsBuf[count * 3 + 2] = rz;
        count++;
        break;
      }
      if (distMoon0 <= CONFIG.moon.radius) {
        impactPt = [rx, ry, rz]; impactBody = CONFIG.moon.name;
        predPtsBuf[count * 3] = rx; predPtsBuf[count * 3 + 1] = ry; predPtsBuf[count * 3 + 2] = rz;
        count++;
        break;
      }

      // Dynamic curvature-adaptive integration step: smaller near planet & inside lunar SOI
      const spd = Math.hypot(vx, vy, vz);
      let stepDt = 45.0;
      if (distMoon0 < CONFIG.moon.soiKm) {
        hadMoonEncounter = true;
        const vRelM = Math.hypot(vx - (-MOON_A * MOON_N * Math.sin(ma0)), vy - (MOON_A * MOON_N * Math.cos(ma0)), vz);
        stepDt = clamp(0.04 * distMoon0 / Math.max(0.1, vRelM), 2.0, 24.0);
      } else if (alt0 < CONFIG.body.atmoKm + 50) {
        // High-density integration during atmospheric ascent & suborbital arc
        stepDt = clamp(0.007 * rLen0 / Math.max(0.35, spd), 0.6, 3.5);
      } else if (rLen0 < CONFIG.body.radius * 2.8) {
        stepDt = clamp(0.035 * rLen0 / Math.max(0.2, spd), 3.0, 30.0);
      } else {
        stepDt = clamp(0.045 * rLen0 / Math.max(0.2, spd), 15.0, 90.0);
      }

      const prevRx = rx, prevRy = ry, prevRz = rz, prevT = tt;
      rk4RelInto(rx, ry, rz, vx, vy, vz, tt, stepDt, 0, 0, 0, 0, mass, true, cdArea, _rkOut);
      rx = _rkOut[0]; ry = _rkOut[1]; rz = _rkOut[2];
      vx = _rkOut[3]; vy = _rkOut[4]; vz = _rkOut[5];
      tt += stepDt;
      elapsedS += stepDt;

      const rNow = Math.hypot(rx, ry, rz);
      const altNow = rNow - CONFIG.body.radius;
      if (altNow > 0 && altNow < CONFIG.body.atmoKm) {
        hadAtmo = true; inAtmoNow = true;
      } else if (inAtmoNow && altNow >= CONFIG.body.atmoKm) {
        inAtmoNow = false;
        const postInfo = orbitInfo([rx, ry, rz], [vx, vy, vz], tt);
        if (postInfo.apoapsisKm !== null) postAtmoAp = postInfo.apoapsisKm;
      }

      if (altNow < minAlt) { minAlt = altNow; pePt = [rx, ry, rz]; }
      if (altNow > maxAlt) { maxAlt = altNow; apPt = [rx, ry, rz]; }

      const ma = MOON_N * tt + 0.9;
      const distM = Math.hypot(rx - MOON_A * Math.cos(ma), ry - MOON_A * Math.sin(ma), rz);
      if (!inMoonSoi && distM <= CONFIG.moon.soiKm) {
        inMoonSoi = true; hadMoonEncounter = true;
        if (!moonSoiEntryPt) moonSoiEntryPt = [rx, ry, rz];
      } else if (distM > CONFIG.moon.soiKm) {
        inMoonSoi = false;
      }
      if (distM - CONFIG.moon.radius < minMoonAlt) {
        minMoonAlt = distM - CONFIG.moon.radius;
        moonPePt = [rx, ry, rz];
      }
      if (!soiEscapePt && rNow >= CONFIG.body.soiKm) soiEscapePt = [rx, ry, rz];

      if (st.targetBody) {
        const tpA = st.targetBody.relPosAt(prevT), tpB = st.targetBody.relPosAt(tt);
        const d0x = prevRx - tpA[0], d0y = prevRy - tpA[1], d0z = prevRz - tpA[2];
        const d1x = rx - tpB[0], d1y = ry - tpB[1], d1z = rz - tpB[2];
        const ddx = d1x - d0x, ddy = d1y - d0y, ddz = d1z - d0z;
        const dd2 = ddx * ddx + ddy * ddy + ddz * ddz;
        const u = dd2 > 1e-12 ? clamp(-(d0x * ddx + d0y * ddy + d0z * ddz) / dd2, 0, 1) : 0;
        const cDist = Math.hypot(d0x + ddx * u, d0y + ddy * u, d0z + ddz * u);
        if (cDist < closestTargetKm) {
          closestTargetKm = cDist;
          cpaPt = [prevRx + (rx - prevRx) * u, prevRy + (ry - prevRy) * u, prevRz + (rz - prevRz) * u];
        }
      }

      const surfElev = altNow < 3.5 && OC.terrainHeightAtRel ? OC.terrainHeightAtRel([rx, ry, rz], tt) : 0;
      if (altNow <= surfElev) { impactPt = [rx, ry, rz]; impactBody = CONFIG.body.name; }
      if (distM <= CONFIG.moon.radius) { impactPt = [rx, ry, rz]; impactBody = CONFIG.moon.name; }

      // Record point if distance or angle from last point reached recording resolution
      const moveD = Math.hypot(rx - lastRecordX, ry - lastRecordY, rz - lastRecordZ);
      const isAscentOrSuborbital = altNow < CONFIG.body.atmoKm + 50 || minAlt < 0;
      const targetMoveD = isAscentOrSuborbital ? 2.2 : (inMoonSoi ? 6.0 : 18.0);
      const maxRecordDt = isAscentOrSuborbital ? 10.0 : 45.0;
      const isRecord = impactPt || inMoonSoi || moveD >= targetMoveD || (tt - lastRecordT) >= maxRecordDt;
      if (isRecord) {
        predPtsBuf[count * 3] = rx;
        predPtsBuf[count * 3 + 1] = ry;
        predPtsBuf[count * 3 + 2] = rz;
        count++;
        lastRecordX = rx; lastRecordY = ry; lastRecordZ = rz;
        lastRecordT = tt;
      }

      if (impactPt) break;
      if (!closed && rNow > 115000) break;
    }

    predCache.count = count;
    predCache.startT = st.VIS.t;
    predCache.dt = (tt - st.VIS.t) / Math.max(1, count);
    predCache.closed = fullLoop && !hadMoonEncounter;
    predCache.drawClosed = fullLoop && !impactPt && !hadAtmo && !hadMoonEncounter;
    predCache.pePt = pePt; predCache.minAlt = minAlt;
    predCache.apPt = apPt; predCache.maxAlt = maxAlt;
    predCache.impactPt = impactPt; predCache.impactBody = impactBody;
    predCache.hadAtmo = hadAtmo; predCache.postAtmoAp = postAtmoAp;
    predCache.closestTargetKm = closestTargetKm; predCache.cpaPt = cpaPt;
    predCache.moonSoiEntryPt = moonSoiEntryPt;
    predCache.minMoonAlt = minMoonAlt; predCache.moonPePt = moonPePt;
    predCache.soiEscapePt = soiEscapePt;
    predCache.lastCalcMs = performance.now();
    predCache.lastSimT = st.t;
    predCache.lastSamples = samples;
    predCache.dirty = false;
    return predCache;
  }

  function getPrediction(nowMs) {
    const s = st.ship;
    const inAtmo = len(st.VIS.r) - CONFIG.body.radius < CONFIG.body.atmoKm;
    const burning = !s.onPad && !s.landed && (st.thrustedLastStep || (s.mainEngine && st.throttle > 0) || OC.anyThrustRequested()) && OC.activeFuel(s) > 0;
    const minInterval = (burning || inAtmo) ? 50 : 1500;
    const minSimDelta = (burning || inAtmo) ? 0 : 8;
    const need = predCache.dirty ||
      predCache.lastSamples !== S.pred ||
      (!st.paused && !st.crashed && (nowMs - predCache.lastCalcMs >= minInterval) &&
        (burning || inAtmo || Math.abs(st.t - predCache.lastSimT) >= minSimDelta));
    return need ? predictPath(S.pred) : predCache;
  }

  Object.assign(OC, { predCache, predictPath, getPrediction });
})(window.OC);