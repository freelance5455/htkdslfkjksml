'use strict';

(function (OC) {
  const { CONFIG, S, STARS, SHADERS, dot, mul, len, clamp, state: st } = OC;

  const glCanvas = document.getElementById('gl');
  const gl = glCanvas.getContext('webgl', { alpha: false, antialias: false, depth: true, preserveDrawingBuffer: false });

  function resizeGL(dpr) {
    const step = S.step;
    const cap = document.documentElement.classList.contains('touch') ? 1.5 : 4;
    const scale = Math.min(dpr, cap) / step * (st.dynRes || 1);
    glCanvas.width = Math.max(1, Math.round(st.W * scale));
    glCanvas.height = Math.max(1, Math.round(st.H * scale));
    st.glFocal = st.F * (glCanvas.height / Math.max(1, st.H));
    if (gl) gl.viewport(0, 0, glCanvas.width, glCanvas.height);
  }

  const GLR = (() => {
    if (!gl || !SHADERS) return null;

    function compile(type, src) {
      const sh = gl.createShader(type);
      gl.shaderSource(sh, src);
      gl.compileShader(sh);
      if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
        console.warn('WebGL shader error:', gl.getShaderInfoLog(sh));
        gl.deleteShader(sh);
        return null;
      }
      return sh;
    }

    function link(vsSrc, fsSrc) {
      const vs = compile(gl.VERTEX_SHADER, vsSrc);
      const fs = compile(gl.FRAGMENT_SHADER, fsSrc);
      if (!vs || !fs) return null;
      const p = gl.createProgram();
      gl.attachShader(p, vs); gl.attachShader(p, fs);
      gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
        console.warn('WebGL link error:', gl.getProgramInfoLog(p));
        return null;
      }
      return p;
    }

    const skyProg = link(SHADERS.skyVS, SHADERS.skyFS);
    const starProg = link(SHADERS.starVS, SHADERS.starFS);
    const sunProg = link(SHADERS.sunVS, SHADERS.sunFS);
    const bodyProg = link(SHADERS.bodyVS, SHADERS.bodyFS);
    const meshProg = link(SHADERS.meshVS, SHADERS.meshFS);
    if (!skyProg || !starProg || !sunProg || !bodyProg || !meshProg) return null;

    const quadBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);

    const starData = new Float32Array(STARS.length * 5);
    for (let i = 0; i < STARS.length; i++) {
      const s = STARS[i];
      starData[i * 5] = s.dir[0]; starData[i * 5 + 1] = s.dir[1]; starData[i * 5 + 2] = s.dir[2];
      starData[i * 5 + 3] = s.sz; starData[i * 5 + 4] = s.br;
    }
    const starBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, starBuf);
    gl.bufferData(gl.ARRAY_BUFFER, starData, gl.STATIC_DRAW);

    const gpuMeshes = {};
    if (OC.buildAllMeshes) {
      const raw = OC.buildAllMeshes();
      for (const name in raw) {
        const m = raw[name];
        const vbo = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
        gl.bufferData(gl.ARRAY_BUFFER, m.verts, gl.STATIC_DRAW);
        const ibo = gl.createBuffer();
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo);
        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, m.idx, gl.STATIC_DRAW);
        gpuMeshes[name] = { vbo, ibo, count: m.count };
      }
    }

    const U = (p, names) => Object.fromEntries(names.map(n => [n, gl.getUniformLocation(p, n)]));
    const skyA = gl.getAttribLocation(skyProg, 'aPos');
    const skyU = U(skyProg, ['uGlRes', 'uFocalGl', 'uCamAlt', 'uCamFwd', 'uCamRight', 'uCamUp', 'uCamZenith', 'uSunDir', 'uTime', 'uSpin', 'uCamRelP', 'uEnableClouds']);
    const starA = { dir: gl.getAttribLocation(starProg, 'aDir'), size: gl.getAttribLocation(starProg, 'aSize'), bright: gl.getAttribLocation(starProg, 'aBright') };
    const starU = U(starProg, ['uCamFwd', 'uCamRight', 'uCamUp', 'uFocalGl', 'uGlRes', 'uPointScale', 'uStarAlpha']);
    const sunA = gl.getAttribLocation(sunProg, 'aPos');
    const sunU = U(sunProg, ['uSunNdc', 'uHalfExtNdc']);
    const bodyA = gl.getAttribLocation(bodyProg, 'aPos');
    const bodyU = U(bodyProg, [
      'uBounds', 'uGlRes', 'uFocalGl', 'uCamFwd', 'uCamRight', 'uCamUp',
      'uBodyRelCam', 'uSunDir', 'uRadius', 'uAtmoThick', 'uSpin', 'uTime',
      'uIsPlanet', 'uOc2MinusR2', 'uCamAlt', 'uMapMode', 'uEnableClouds', 'uEnableBump', 'uEnableAtmo', 'uDetail', 'uSeed', 'uSeaLevel'
    ]);
    const meshA = { pos: gl.getAttribLocation(meshProg, 'aPos'), normal: gl.getAttribLocation(meshProg, 'aNormal'), color: gl.getAttribLocation(meshProg, 'aColor') };
    const meshU = U(meshProg, [
      'uObjBasis', 'uObjScale', 'uObjRelCam', 'uCamFwd', 'uCamRight', 'uCamUp',
      'uProjScale', 'uDepthRange', 'uSunDir', 'uPlanetUp', 'uCamZenith', 'uCamRelP',
      'uEmissive', 'uAlpha', 'uTerrainMode', 'uTileOrigin', 'uAnchorLocal', 'uPatchRadius',
      'uCamAlt', 'uEnableAtmo', 'uEnableBump', 'uEnableClouds', 'uTime', 'uSpin', 'uSeed', 'uSeaLevel', 'uDetail'
    ]);

    function updateDynamicMesh(name, verts, idx, count, dynamicIdx = false) {
      let m = gpuMeshes[name];
      if (!m) {
        m = { vbo: gl.createBuffer(), ibo: gl.createBuffer(), count: 0, init: false };
        gpuMeshes[name] = m;
      }
      gl.bindBuffer(gl.ARRAY_BUFFER, m.vbo);
      gl.bufferData(gl.ARRAY_BUFFER, verts, gl.DYNAMIC_DRAW);
      if (idx && (!m.init || dynamicIdx)) {
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.ibo);
        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, dynamicIdx ? gl.DYNAMIC_DRAW : gl.STATIC_DRAW);
        m.init = true;
      }
      m.count = count;
    }

    function axisBounds(ca, cz, rEff, focalCss, halfCss) {
      const d2 = ca * ca + cz * cz;
      if (d2 <= rEff * rEff) return [-1, 1];
      const ang = Math.atan2(ca, cz), alpha = Math.asin(Math.min(0.999999, rEff / Math.sqrt(d2)));
      const lo = ang - alpha, hi = ang + alpha, scale = focalCss / halfCss;
      return [
        lo <= -Math.PI * 0.5 + 0.02 ? -1 : clamp(scale * Math.tan(lo) - 0.015, -1, 1),
        hi >=  Math.PI * 0.5 - 0.02 ?  1 : clamp(scale * Math.tan(hi) + 0.015, -1, 1)
      ];
    }

    function sphereNdcBounds(relCam, rEff) {
      const cx = dot(relCam, st.CAM.right), cy = dot(relCam, st.CAM.up), cz = dot(relCam, st.CAM.fwd);
      if (cz <= -rEff) return null;
      if (cz <= rEff * 1.08 || Math.hypot(cx, cy, cz) <= rEff * 1.15) return [-1, -1, 1, 1];
      const bx = axisBounds(cx, cz, rEff, st.F, st.W * 0.5);
      const by = axisBounds(cy, cz, rEff, st.F, st.H * 0.5);
      if (bx[1] < -1 || bx[0] > 1 || by[1] < -1 || by[0] > 1) return null;
      return [bx[0], by[0], bx[1], by[1]];
    }

    function beginFrame(focalGl, camAlt, camZenith, vt = 0, spinPlanet = 0) {
      gl.disable(gl.DEPTH_TEST);
      gl.clearColor(0.0196, 0.0275, 0.051, 1.0);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

      let starAlpha = 1.0;
      if (S.atmo && camAlt < 75) {
        gl.useProgram(skyProg);
        gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
        gl.enableVertexAttribArray(skyA);
        gl.vertexAttribPointer(skyA, 2, gl.FLOAT, false, 0, 0);
        gl.uniform2f(skyU.uGlRes, glCanvas.width, glCanvas.height);
        gl.uniform1f(skyU.uFocalGl, focalGl);
        gl.uniform1f(skyU.uCamAlt, camAlt);
        gl.uniform3fv(skyU.uCamFwd, st.CAM.fwd);
        gl.uniform3fv(skyU.uCamRight, st.CAM.right);
        gl.uniform3fv(skyU.uCamUp, st.CAM.up);
        gl.uniform3fv(skyU.uCamZenith, camZenith);
        gl.uniform3fv(skyU.uSunDir, st.SUNDIR);
        gl.uniform1f(skyU.uTime, vt);
        gl.uniform1f(skyU.uSpin, spinPlanet);
        gl.uniform3fv(skyU.uCamRelP, st.VIS.camRelP);
        gl.uniform1f(skyU.uEnableClouds, S.clouds ? 1.0 : 0.0);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        gl.disableVertexAttribArray(skyA);

        const dayFactor = clamp((dot(camZenith, st.SUNDIR) + 0.15) / 0.4, 0, 1);
        const dens = Math.exp(-Math.max(0, camAlt) / 10);
        starAlpha = clamp(1.0 - dens * dayFactor * 2.2, 0.0, 1.0);
      }

      if (!S.stars || starAlpha < 0.02) return;
      gl.useProgram(starProg);
      gl.bindBuffer(gl.ARRAY_BUFFER, starBuf);
      gl.enableVertexAttribArray(starA.dir);
      gl.vertexAttribPointer(starA.dir, 3, gl.FLOAT, false, 20, 0);
      gl.enableVertexAttribArray(starA.size);
      gl.vertexAttribPointer(starA.size, 1, gl.FLOAT, false, 20, 12);
      gl.enableVertexAttribArray(starA.bright);
      gl.vertexAttribPointer(starA.bright, 1, gl.FLOAT, false, 20, 16);
      gl.uniform3fv(starU.uCamFwd, st.CAM.fwd);
      gl.uniform3fv(starU.uCamRight, st.CAM.right);
      gl.uniform3fv(starU.uCamUp, st.CAM.up);
      gl.uniform1f(starU.uFocalGl, focalGl);
      gl.uniform2f(starU.uGlRes, glCanvas.width, glCanvas.height);
      gl.uniform1f(starU.uPointScale, glCanvas.height / Math.max(1, st.H));
      gl.uniform1f(starU.uStarAlpha, starAlpha);
      gl.drawArrays(gl.POINTS, 0, STARS.length);
      gl.disableVertexAttribArray(starA.dir);
      gl.disableVertexAttribArray(starA.size);
      gl.disableVertexAttribArray(starA.bright);
    }

    function drawSun() {
      if (dot(mul(st.CAM.pos, -1), st.CAM.fwd) <= 0.1) return;
      const p = OC.project([0, 0, 0]);
      if (!p) return;
      const ext = clamp(st.F * CONFIG.sun.radiusKm / len(st.CAM.pos), 4, 90) * 4.0;
      gl.useProgram(sunProg);
      gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
      gl.enableVertexAttribArray(sunA);
      gl.vertexAttribPointer(sunA, 2, gl.FLOAT, false, 0, 0);
      gl.uniform2f(sunU.uSunNdc, (p[0] / st.W) * 2 - 1, 1 - (p[1] / st.H) * 2);
      gl.uniform2f(sunU.uHalfExtNdc, (ext / st.W) * 2, (ext / st.H) * 2);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      gl.disableVertexAttribArray(sunA);
    }

    function drawBody(relCam, R, atmoThick, sunDir, spin, vt, isPlanet, focalGl, mapMode = 0) {
      const dist0 = len(relCam);
      if (dist0 <= R) return false;
      if (st.F * Math.tan(Math.asin(Math.min(0.999999, R / dist0))) < 2.2) return false;
      const haloPad = isPlanet && S.atmo ? atmoThick * 1.15 : 0;
      const bounds = sphereNdcBounds(relCam, R + haloPad);
      if (!bounds) return true;

      const camAlt = dist0 - R;
      const oc2MinusR2 = camAlt * (dist0 + R);

      gl.useProgram(bodyProg);
      gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
      gl.enableVertexAttribArray(bodyA);
      gl.vertexAttribPointer(bodyA, 2, gl.FLOAT, false, 0, 0);
      gl.uniform4fv(bodyU.uBounds, bounds);
      gl.uniform2f(bodyU.uGlRes, glCanvas.width, glCanvas.height);
      gl.uniform1f(bodyU.uFocalGl, focalGl);
      gl.uniform3fv(bodyU.uCamFwd, st.CAM.fwd);
      gl.uniform3fv(bodyU.uCamRight, st.CAM.right);
      gl.uniform3fv(bodyU.uCamUp, st.CAM.up);
      gl.uniform3fv(bodyU.uBodyRelCam, relCam);
      gl.uniform3fv(bodyU.uSunDir, sunDir);
      gl.uniform1f(bodyU.uRadius, R);
      gl.uniform1f(bodyU.uAtmoThick, atmoThick);
      gl.uniform1f(bodyU.uSpin, spin);
      gl.uniform1f(bodyU.uTime, vt);
      gl.uniform1f(bodyU.uIsPlanet, isPlanet ? 1.0 : 0.0);
      gl.uniform1f(bodyU.uOc2MinusR2, oc2MinusR2);
      gl.uniform1f(bodyU.uCamAlt, camAlt);
      gl.uniform1f(bodyU.uMapMode, mapMode);
      gl.uniform1f(bodyU.uEnableClouds, S.clouds ? 1.0 : 0.0);
      gl.uniform1f(bodyU.uEnableBump, S.bump ? 1.0 : 0.0);
      gl.uniform1f(bodyU.uEnableAtmo, S.atmo ? 1.0 : 0.0);
      gl.uniform1f(bodyU.uDetail, (S.perf || (st.dynRes || 1) < 0.7) ? 0.0 : 1.0);
      gl.uniform1f(bodyU.uSeed, CONFIG.body.seed);
      gl.uniform1f(bodyU.uSeaLevel, CONFIG.body.seaLevel);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      gl.disableVertexAttribArray(bodyA);
      return true;
    }

    function beginMeshPass(camAlt = 100, camZenith = [1, 0, 0], vt = 0, spinPlanet = 0) {
      gl.clear(gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.DEPTH_TEST);
      gl.depthFunc(gl.LEQUAL);
      gl.useProgram(meshProg);
      gl.uniform3fv(meshU.uCamFwd, st.CAM.fwd);
      gl.uniform3fv(meshU.uCamRight, st.CAM.right);
      gl.uniform3fv(meshU.uCamUp, st.CAM.up);
      gl.uniform2f(meshU.uProjScale, (2 * st.F) / st.W, (2 * st.F) / st.H);
      const near = st.dist < 12 ? 0.003 : st.dist < 180 ? 0.03 : 0.25;
      const far = st.dist < 12 ? 160.0 : st.dist < 180 ? 900.0 : 6000.0;
      gl.uniform2f(meshU.uDepthRange, near, far);
      gl.uniform3fv(meshU.uCamZenith, camZenith);
      gl.uniform3fv(meshU.uCamRelP, st.VIS.camRelP);
      gl.uniform1f(meshU.uCamAlt, camAlt);
      gl.uniform1f(meshU.uEnableAtmo, S.atmo ? 1.0 : 0.0);
      gl.uniform1f(meshU.uEnableBump, S.bump ? 1.0 : 0.0);
      gl.uniform1f(meshU.uEnableClouds, S.clouds ? 1.0 : 0.0);
      gl.uniform1f(meshU.uTime, vt);
      gl.uniform1f(meshU.uSpin, spinPlanet);
      gl.uniform1f(meshU.uSeed, CONFIG.body.seed);
      gl.uniform1f(meshU.uSeaLevel, CONFIG.body.seaLevel);
      gl.uniform1f(meshU.uDetail, (S.perf || (st.dynRes || 1) < 0.7) ? 0.0 : 1.0);
    }

    const ZERO3 = [0, 0, 0];
    function drawMesh(name, relCam, basis9, scale, sunDir, planetUp, emissive = 0, alpha = 1, additive = false, terrainMode = 0, tileOrigin = ZERO3, patchRadius = 1, anchorLocal = ZERO3) {
      const m = gpuMeshes[name];
      if (!m || m.count <= 0) return;
      gl.depthMask(!additive && alpha >= 0.99);
      gl.blendFunc(gl.SRC_ALPHA, additive ? gl.ONE : gl.ONE_MINUS_SRC_ALPHA);
      gl.bindBuffer(gl.ARRAY_BUFFER, m.vbo);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.ibo);
      gl.enableVertexAttribArray(meshA.pos);
      gl.vertexAttribPointer(meshA.pos, 3, gl.FLOAT, false, 36, 0);
      gl.enableVertexAttribArray(meshA.normal);
      gl.vertexAttribPointer(meshA.normal, 3, gl.FLOAT, false, 36, 12);
      gl.enableVertexAttribArray(meshA.color);
      gl.vertexAttribPointer(meshA.color, 3, gl.FLOAT, false, 36, 24);
      gl.uniformMatrix3fv(meshU.uObjBasis, false, basis9);
      gl.uniform1f(meshU.uObjScale, scale);
      gl.uniform3fv(meshU.uObjRelCam, relCam);
      gl.uniform3fv(meshU.uSunDir, sunDir);
      gl.uniform3fv(meshU.uPlanetUp, planetUp);
      gl.uniform1f(meshU.uEmissive, emissive);
      gl.uniform1f(meshU.uAlpha, alpha);
      gl.uniform1f(meshU.uTerrainMode, terrainMode);
      gl.uniform3fv(meshU.uTileOrigin, tileOrigin);
      gl.uniform3fv(meshU.uAnchorLocal, anchorLocal);
      gl.uniform1f(meshU.uPatchRadius, patchRadius);
      gl.drawElements(gl.TRIANGLES, m.count, gl.UNSIGNED_SHORT, 0);
      gl.disableVertexAttribArray(meshA.pos);
      gl.disableVertexAttribArray(meshA.normal);
      gl.disableVertexAttribArray(meshA.color);
    }

    function endMeshPass() {
      gl.depthMask(true);
      gl.disable(gl.DEPTH_TEST);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    }

    return { beginFrame, drawSun, drawBody, beginMeshPass, drawMesh, endMeshPass, updateDynamicMesh };
  })();

  Object.assign(OC, { glCanvas, gl, GLR, resizeGL });
})(window.OC);