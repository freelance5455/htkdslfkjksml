'use strict';

(function (OC) {
  const {
    CONFIG, B, THRUST_ACTS, TAU, G0, PAD_LON0, PH,
    SUN_A, SUN_A2, SUN_MU, SUN_N, SUN_N2,
    MOON_A, MOON_A3, MOON_N,
    add, sub, mul, dot, cross, len, unit, clamp, state: st
  } = OC;

  const OMEGA = TAU / CONFIG.body.rotationPeriodS;
  const ATMO_FLOOR = Math.exp(-CONFIG.body.atmoKm / 6.2);

  const planetPos = tt => { const a = SUN_N * tt; return [SUN_A * Math.cos(a), SUN_A * Math.sin(a), 0]; };
  const planetVel = tt => { const a = SUN_N * tt; return [-SUN_A * SUN_N * Math.sin(a), SUN_A * SUN_N * Math.cos(a), 0]; };
  const moonRelPos = tt => { const a = MOON_N * tt + 0.9; return [MOON_A * Math.cos(a), MOON_A * Math.sin(a), 0]; };
  const moonRelVel = tt => { const a = MOON_N * tt + 0.9; return [-MOON_A * MOON_N * Math.sin(a), MOON_A * MOON_N * Math.cos(a), 0]; };
  const moonPos = tt => add(planetPos(tt), moonRelPos(tt));
  const moonVel = tt => add(planetVel(tt), moonRelVel(tt));
  const padRelPos = tt => { const a = OMEGA * tt + PAD_LON0; return [CONFIG.body.radius * Math.cos(a), CONFIG.body.radius * Math.sin(a), 0]; };
  const surfaceVelAt = r => [-OMEGA * r[1], OMEGA * r[0], 0];

  // Exact JS port of GLSL snoiseGrad in shaders.js so CPU collision, 3D mesh, and global GPU shader match 1:1
  function mod289(x) { return x - Math.floor(x * (1.0 / 289.0)) * 289.0; }
  function permute(x) { return mod289(((x * 34.0) + 1.0) * x); }

  function snoise3D(vx, vy, vz) {
    const C0 = 1.0 / 6.0, C1 = 1.0 / 3.0;
    const s = (vx + vy + vz) * C1;
    let ix = Math.floor(vx + s), iy = Math.floor(vy + s), iz = Math.floor(vz + s);
    const t = (ix + iy + iz) * C0;
    const x0 = vx - (ix - t), y0 = vy - (iy - t), z0 = vz - (iz - t);

    let i1x, i1y, i1z, i2x, i2y, i2z;
    if (x0 >= y0) {
      if (y0 >= z0) { i1x = 1; i1y = 0; i1z = 0; i2x = 1; i2y = 1; i2z = 0; }
      else if (x0 >= z0) { i1x = 1; i1y = 0; i1z = 0; i2x = 1; i2y = 0; i2z = 1; }
      else { i1x = 0; i1y = 0; i1z = 1; i2x = 1; i2y = 0; i2z = 1; }
    } else {
      if (y0 < z0) { i1x = 0; i1y = 0; i1z = 1; i2x = 0; i2y = 1; i2z = 1; }
      else if (x0 < z0) { i1x = 0; i1y = 1; i1z = 0; i2x = 0; i2y = 1; i2z = 1; }
      else { i1x = 0; i1y = 1; i1z = 0; i2x = 1; i2y = 1; i2z = 0; }
    }

    const x1 = x0 - i1x + C0, y1 = y0 - i1y + C0, z1 = z0 - i1z + C0;
    const x2 = x0 - i2x + C1, y2 = y0 - i2y + C1, z2 = z0 - i2z + C1;
    const x3 = x0 - 0.5,      y3 = y0 - 0.5,      z3 = z0 - 0.5;

    ix = mod289(ix); iy = mod289(iy); iz = mod289(iz);
    let p0 = permute(iz), p1 = permute(iz + i1z), p2 = permute(iz + i2z), p3 = permute(iz + 1.0);
    p0 = permute(p0 + iy); p1 = permute(p1 + iy + i1y); p2 = permute(p2 + iy + i2y); p3 = permute(p3 + iy + 1.0);
    p0 = permute(p0 + ix); p1 = permute(p1 + ix + i1x); p2 = permute(p2 + ix + i2x); p3 = permute(p3 + ix + 1.0);

    const n_ = 0.142857142857;
    const nsx = 2.0 * n_, nsy = 0.5 * n_ - 1.0, nsz = n_;

    let sum = 0.0;
    const evalCorner = (pv, ax, ay, az) => {
      const m = 0.6 - (ax * ax + ay * ay + az * az);
      if (m <= 0.0) return;
      const j = pv - 49.0 * Math.floor(pv * nsz * nsz);
      const x_ = Math.floor(j * nsz);
      const y_ = Math.floor(j - 7.0 * x_);
      const x = x_ * nsx + nsy, y = y_ * nsx + nsy;
      const h = 1.0 - Math.abs(x) - Math.abs(y);
      const sx = Math.floor(x) * 2.0 + 1.0, sy = Math.floor(y) * 2.0 + 1.0;
      const sh = h <= 0.0 ? -1.0 : 0.0;
      const px = x + sx * sh, py = y + sy * sh;
      const nrm = 1.79284291400159 - 0.85373472095314 * (px * px + py * py + h * h);
      const m2 = m * m;
      sum += m2 * m2 * nrm * (px * ax + py * ay + h * az);
    };

    evalCorner(p0, x0, y0, z0);
    evalCorner(p1, x1, y1, z1);
    evalCorner(p2, x2, y2, z2);
    evalCorner(p3, x3, y3, z3);
    return 42.0 * sum;
  }

  const PAD_LOC_X = Math.cos(PAD_LON0), PAD_LOC_Y = Math.sin(PAD_LON0);
  const _ebRawX = PAD_LOC_X - PAD_LOC_Y * 0.042, _ebRawY = PAD_LOC_Y + PAD_LOC_X * 0.042;
  const _ebLen = Math.hypot(_ebRawX, _ebRawY);
  const EAST_BAY_X = _ebRawX / _ebLen, EAST_BAY_Y = _ebRawY / _ebLen;

  function terrainInfoAtLocal(nx, ny, nz) {
    const seed = CONFIG.body.seed;
    const bx = nx * 2.55 + seed, by = ny * 2.55 + seed, bz = nz * 2.55 + seed;
    let res = 0.0, amp = 0.5, freq = 1.0, norm = 0.0;
    for (let i = 0; i < 4; i++) {
      res += amp * snoise3D(bx * freq, by * freq, bz * freq);
      norm += amp; freq *= 2.06; amp *= 0.5;
    }
    const fg = res / norm;

    const kscD = Math.hypot(nx - PAD_LOC_X, ny - PAD_LOC_Y, nz);
    const bayD = Math.hypot(nx - EAST_BAY_X, ny - EAST_BAY_Y, nz);
    // Mirror of the shader's two lowest detail octaves (terrainH in shaders.js) so mesh, collision and colours agree
    const pm = 1.0 - Math.exp(-kscD * kscD * 2.0e6);
    const d0 = snoise3D(nx * 38.0 + seed * 3.1, ny * 38.0, nz * 38.0 + 9.2);
    const d1 = snoise3D(nx * 102.6 + seed * 3.1, ny * 102.6 + 1.7, nz * 102.6 + 9.2);
    const h = 0.5 + 0.48 * fg + Math.exp(-kscD * kscD * 180.0) * 0.08 - Math.exp(-bayD * bayD * 220.0) * 0.28 + pm * (0.011 * d0 + 0.00374 * d1);
    const depth = h - CONFIG.body.seaLevel;

    const gMed = snoise3D(nx * 28.0 + seed, ny * 28.0 + seed, nz * 28.0 + seed);
    const gFine = snoise3D(nx * 96.0 + seed, ny * 96.0 + seed, nz * 96.0 + seed);
    const hill = gMed * 0.65 + gFine * 0.35;
    const padFlat = Math.exp(-kscD * kscD * 140000.0);
    const coastalPlain = Math.exp(-kscD * kscD * 12000.0);

    let elevKm = 0.0;
    const isWater = depth <= 0.0;
    if (!isWater) {
      const rawElev = Math.max(0.008, depth * 5.0 + hill * 0.14 * Math.min(1.0, depth * 20.0));
      const plainElev = rawElev * (1.0 - coastalPlain * 0.85) + 0.08 * (coastalPlain * 0.85);
      elevKm = plainElev * (1.0 - padFlat) + 0.08 * padFlat;
    }
    // Exact color variation matching bodyFS: 0.92 + 0.10*gMed + 0.06*gFine
    const detail = 0.10 * gMed + 0.06 * gFine;
    return { elevKm, depth, isWater, padFlat, kscD, detail };
  }

  function terrainHeightAtRel(r, tt) {
    const rl = len(r);
    if (rl < 1e-6) return 0;
    const spin = tt * OMEGA;
    const cs = Math.cos(spin), sn = Math.sin(spin);
    const ux = r[0] / rl, uy = r[1] / rl, uz = r[2] / rl;
    const lx = ux * cs + uy * sn;
    const ly = -ux * sn + uy * cs;
    return terrainInfoAtLocal(lx, ly, uz).elevKm;
  }

  function surfaceRadiusAt(r, tt) {
    return CONFIG.body.radius + terrainHeightAtRel(r, tt);
  }

  function isWaterAtRel(r, tt) {
    const rl = len(r);
    if (rl < 1e-6) return false;
    const spin = tt * OMEGA;
    const cs = Math.cos(spin), sn = Math.sin(spin);
    const ux = r[0] / rl, uy = r[1] / rl, uz = r[2] / rl;
    return terrainInfoAtLocal(ux * cs + uy * sn, -ux * sn + uy * cs, uz).isWater;
  }

  function terrainNormalAtRel(r, tt) {
    const rl = len(r);
    if (rl < 1e-6) return [0, 0, 1];
    const u = [r[0] / rl, r[1] / rl, r[2] / rl];
    const eps = 0.0006;
    let ref = Math.abs(u[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0];
    const e1 = unit(cross(ref, u));
    const e2 = cross(u, e1);
    const r0 = surfaceRadiusAt(r, tt);
    const r1 = surfaceRadiusAt([r[0] + e1[0] * eps, r[1] + e1[1] * eps, r[2] + e1[2] * eps], tt);
    const r2 = surfaceRadiusAt([r[0] + e2[0] * eps, r[1] + e2[1] * eps, r[2] + e2[2] * eps], tt);
    const dr1 = (r1 - r0) / eps;
    const dr2 = (r2 - r0) / eps;
    const n = [u[0] - e1[0] * dr1 - e2[0] * dr2, u[1] - e1[1] * dr1 - e2[1] * dr2, u[2] - e1[2] * dr1 - e2[2] * dr2];
    return unit(n);
  }

  function moonSurfaceRadiusAt(rRelM) {
    const rl = len(rRelM);
    if (rl < 1e-6) return CONFIG.moon.radius;
    const nx = rRelM[0] / rl, ny = rRelM[1] / rl, nz = rRelM[2] / rl;
    const maria = snoise3D(nx * 3.1 + 11.3, ny * 3.1 + 11.3, nz * 3.1 + 11.3);
    const cr = snoise3D(nx * 9.5 + 4.2, ny * 9.5 + 1.7, nz * 9.5 + 9.1);
    const elev = maria * 0.42 + cr * 0.28;
    return CONFIG.moon.radius + elev;
  }

  function moonNormalAtRel(rRelM) {
    const rl = len(rRelM);
    if (rl < 1e-6) return [0, 0, 1];
    const u = [rRelM[0] / rl, rRelM[1] / rl, rRelM[2] / rl];
    const eps = 0.0008;
    let ref = Math.abs(u[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0];
    const e1 = unit(cross(ref, u));
    const e2 = cross(u, e1);
    const r0 = moonSurfaceRadiusAt(rRelM);
    const r1 = moonSurfaceRadiusAt([rRelM[0] + e1[0] * eps, rRelM[1] + e1[1] * eps, rRelM[2] + e1[2] * eps]);
    const r2 = moonSurfaceRadiusAt([rRelM[0] + e2[0] * eps, rRelM[1] + e2[1] * eps, rRelM[2] + e2[2] * eps]);
    const dr1 = (r1 - r0) / eps;
    const dr2 = (r2 - r0) / eps;
    const n = [u[0] - e1[0] * dr1 - e2[0] * dr2, u[1] - e1[1] * dr1 - e2[1] * dr2, u[2] - e1[2] * dr1 - e2[2] * dr2];
    return unit(n);
  }

  function atmoDensity(alt) {
    if (alt >= CONFIG.body.atmoKm) return 0;
    if (alt <= 0) return 1 - ATMO_FLOOR;
    return Math.max(0, Math.exp(-alt / 6.2) - ATMO_FLOOR);
  }

  function speedOfSoundKmS(alt) {
    return alt < 11 ? 0.340 - 0.0041 * Math.max(0, alt) : 0.295;
  }

  function rotateAroundAxis(v, axis, ang) {
    if (Math.abs(ang) < 1e-8) return unit(v);
    const c = Math.cos(ang), s = Math.sin(ang);
    const kdv = dot(axis, v);
    const kxv = cross(axis, v);
    return unit([
      v[0] * c + kxv[0] * s + axis[0] * kdv * (1 - c),
      v[1] * c + kxv[1] * s + axis[1] * kdv * (1 - c),
      v[2] * c + kxv[2] * s + axis[2] * kdv * (1 - c)
    ]);
  }

  const _acc = new Float64Array(3);
  const _k1r = new Float64Array(3), _k1v = new Float64Array(3);
  const _k2r = new Float64Array(3), _k2v = new Float64Array(3);
  const _k3r = new Float64Array(3), _k3v = new Float64Array(3);
  const _k4r = new Float64Array(3), _k4v = new Float64Array(3);
  const _rkOut = new Float64Array(6);
  const _visBuf = new Float64Array(6);

  function computeRelAccel(rx, ry, rz, vx, vy, vz, tt, thrustAcc, dx, dy, dz, mass, withAtmo, cdArea) {
    const r2 = rx * rx + ry * ry + rz * rz;
    const rLen = Math.sqrt(r2);
    const invR3 = rLen > 1e-6 ? -CONFIG.body.mu / (r2 * rLen) : 0;
    let ax = rx * invR3 + dx * thrustAcc;
    let ay = ry * invR3 + dy * thrustAcc;
    let az = rz * invR3 + dz * thrustAcc;

    const sa = SUN_N * tt;
    const px = SUN_A * Math.cos(sa), py = SUN_A * Math.sin(sa);
    const q = (2 * (px * rx + py * ry) + r2) / SUN_A2;
    if (q > -0.98) {
      const s = Math.sqrt(1 + q);
      const fq = -q * (1 + s + s * s) / (s * s * s * (1 + s));
      ax -= SUN_N2 * ((1 + fq) * rx + fq * px);
      ay -= SUN_N2 * ((1 + fq) * ry + fq * py);
      az -= SUN_N2 * ((1 + fq) * rz);
    } else {
      const sx = px + rx, sy = py + ry, sz = rz;
      const rs = Math.hypot(sx, sy, sz);
      const invRs3 = rs > 1 ? -SUN_MU / (rs * rs * rs) : 0;
      ax += sx * invRs3 + SUN_N2 * px;
      ay += sy * invRs3 + SUN_N2 * py;
      az += sz * invRs3;
    }

    const ma = MOON_N * tt + 0.9;
    const mx = MOON_A * Math.cos(ma), my = MOON_A * Math.sin(ma);
    const rmx = rx - mx, rmy = ry - my, rmz = rz;
    const rm2 = rmx * rmx + rmy * rmy + rmz * rmz;
    const rm = Math.sqrt(rm2);
    const invRm3 = -CONFIG.moon.mu / Math.max(1, rm2 * rm);
    const invPm3 = CONFIG.moon.mu / MOON_A3;
    ax += rmx * invRm3 - mx * invPm3;
    ay += rmy * invRm3 - my * invPm3;
    az += rmz * invRm3;

    if (withAtmo) {
      const alt = rLen - CONFIG.body.radius;
      if (alt > 0 && alt < CONFIG.body.atmoKm) {
        const rho = atmoDensity(alt);
        if (rho > 0) {
          const vax = vx + OMEGA * ry, vay = vy - OMEGA * rx, vaz = vz;
          const spd = Math.hypot(vax, vay, vaz);
          if (spd > 1e-9) {
            const alpha = (cdArea * rho) / Math.max(0.5, mass);
            const effAlpha = alpha / (1 + alpha * spd * 0.5 * PH);
            const decel = effAlpha * spd * spd;
            const k = -decel / spd;
            ax += vax * k; ay += vay * k; az += vaz * k;
          }
        }
      }
    }

    _acc[0] = ax; _acc[1] = ay; _acc[2] = az;
  }

  function rk4RelInto(rx, ry, rz, vx, vy, vz, tt, dt, tAcc, dx, dy, dz, mass, withAtmo, cdArea, out) {
    const h = dt * 0.5;
    computeRelAccel(rx, ry, rz, vx, vy, vz, tt, tAcc, dx, dy, dz, mass, withAtmo, cdArea);
    _k1r[0] = vx; _k1r[1] = vy; _k1r[2] = vz;
    _k1v[0] = _acc[0]; _k1v[1] = _acc[1]; _k1v[2] = _acc[2];

    const rx2 = rx + _k1r[0] * h, ry2 = ry + _k1r[1] * h, rz2 = rz + _k1r[2] * h;
    const vx2 = vx + _k1v[0] * h, vy2 = vy + _k1v[1] * h, vz2 = vz + _k1v[2] * h;
    computeRelAccel(rx2, ry2, rz2, vx2, vy2, vz2, tt + h, tAcc, dx, dy, dz, mass, withAtmo, cdArea);
    _k2r[0] = vx2; _k2r[1] = vy2; _k2r[2] = vz2;
    _k2v[0] = _acc[0]; _k2v[1] = _acc[1]; _k2v[2] = _acc[2];

    const rx3 = rx + _k2r[0] * h, ry3 = ry + _k2r[1] * h, rz3 = rz + _k2r[2] * h;
    const vx3 = vx + _k2v[0] * h, vy3 = vy + _k2v[1] * h, vz3 = vz + _k2v[2] * h;
    computeRelAccel(rx3, ry3, rz3, vx3, vy3, vz3, tt + h, tAcc, dx, dy, dz, mass, withAtmo, cdArea);
    _k3r[0] = vx3; _k3r[1] = vy3; _k3r[2] = vz3;
    _k3v[0] = _acc[0]; _k3v[1] = _acc[1]; _k3v[2] = _acc[2];

    const rx4 = rx + _k3r[0] * dt, ry4 = ry + _k3r[1] * dt, rz4 = rz + _k3r[2] * dt;
    const vx4 = vx + _k3v[0] * dt, vy4 = vy + _k3v[1] * dt, vz4 = vz + _k3v[2] * dt;
    computeRelAccel(rx4, ry4, rz4, vx4, vy4, vz4, tt + dt, tAcc, dx, dy, dz, mass, withAtmo, cdArea);
    _k4r[0] = vx4; _k4r[1] = vy4; _k4r[2] = vz4;
    _k4v[0] = _acc[0]; _k4v[1] = _acc[1]; _k4v[2] = _acc[2];

    const d6 = dt / 6;
    out[0] = rx + (_k1r[0] + 2 * _k2r[0] + 2 * _k3r[0] + _k4r[0]) * d6;
    out[1] = ry + (_k1r[1] + 2 * _k2r[1] + 2 * _k3r[1] + _k4r[1]) * d6;
    out[2] = rz + (_k1r[2] + 2 * _k2r[2] + 2 * _k3r[2] + _k4r[2]) * d6;
    out[3] = vx + (_k1v[0] + 2 * _k2v[0] + 2 * _k3v[0] + _k4v[0]) * d6;
    out[4] = vy + (_k1v[1] + 2 * _k2v[1] + 2 * _k3v[1] + _k4v[1]) * d6;
    out[5] = vz + (_k1v[2] + 2 * _k2v[2] + 2 * _k3v[2] + _k4v[2]) * d6;
  }

  function rk2StepInto(rx, ry, rz, vx, vy, vz, tt, dt, tAcc, dx, dy, dz, mass, cdArea, out) {
    const h = dt * 0.5;
    computeRelAccel(rx, ry, rz, vx, vy, vz, tt, tAcc, dx, dy, dz, mass, true, cdArea);
    const mx = rx + vx * h, my = ry + vy * h, mz = rz + vz * h;
    const mvx = vx + _acc[0] * h, mvy = vy + _acc[1] * h, mvz = vz + _acc[2] * h;
    computeRelAccel(mx, my, mz, mvx, mvy, mvz, tt + h, tAcc, dx, dy, dz, mass, true, cdArea);
    out[0] = rx + mvx * dt; out[1] = ry + mvy * dt; out[2] = rz + mvz * dt;
    out[3] = vx + _acc[0] * dt; out[4] = vy + _acc[1] * dt; out[5] = vz + _acc[2] * dt;
  }

  function currentCdArea(s) {
    if (s.chuteState === 2) return 350;
    if (s.chuteState === 1) return 18;
    return 0.09;
  }

  function totalMass(s = st.ship) {
    const c = CONFIG.ship;
    if (s.stage === 1) return c.s1DryMassT + s.fuel1 + c.dryMassT + s.fuel;
    return c.dryMassT + s.fuel;
  }

  function activeFuel(s = st.ship) { return s.stage === 1 ? s.fuel1 : s.fuel; }
  function activeMaxFuel(s = st.ship) { return s.stage === 1 ? s.maxFuel1 : s.maxFuel; }

  function stageThrustSpec(s = st.ship, altKm = 100) {
    const c = CONFIG.ship;
    const p = atmoDensity(altKm);
    if (s.stage === 1) {
      return { thrustF: c.s1ThrustF, isp: c.s1IspVac - (c.s1IspVac - c.s1IspSL) * p };
    }
    return { thrustF: c.thrustF, isp: c.ispS - (c.ispS - c.ispSL) * p };
  }

  function makeShip(opts = {}) {
    const c = CONFIG;
    if (opts.onPad) {
      const u0 = unit(padRelPos(0));
      const r0 = surfaceRadiusAt(u0, 0) + 0.0011;
      const r = mul(u0, r0);
      return {
        r,
        v: surfaceVelAt(r),
        att: [u0[0], u0[1], u0[2]],
        angVel: [0, 0, 0],
        sas: 'up',
        onPad: true,
        landed: false,
        stage: 1,
        mainEngine: false,
        chuteArmed: true,
        chuteState: 0,
        fuel1: opts.fuel1 ?? c.ship.s1FuelMassT,
        maxFuel1: opts.fuel1 ?? c.ship.s1FuelMassT,
        fuel: opts.fuel ?? c.ship.fuelMassT,
        maxFuel: opts.fuel ?? c.ship.fuelMassT,
        lastDir: [u0[0], u0[1], u0[2]],
        peakAltKm: 0, peakSpd: 0, peakMaxQ: 0, peakG: 0,
        mach: 0, dynQ: 0, gLoad: 1, twr: 0, pitchDeg: 90, downrangeKm: 0,
        debris: [],
        milestones: {}
      };
    }

    const alt = opts.altKm ?? c.ship.altitudeKm;
    const r0 = c.body.radius + alt;
    const inc = (opts.incDeg ?? c.ship.inclinationDeg) * Math.PI / 180;
    const vc = Math.sqrt(c.body.mu / r0) * (opts.vScale ?? 1);
    const phase = opts.phase ?? 0;
    const rx = r0 * Math.cos(phase), ry = r0 * Math.sin(phase);
    const tx = -Math.sin(phase), ty = Math.cos(phase);
    const vx = vc * tx * Math.cos(inc), vy = vc * ty * Math.cos(inc), vz = vc * Math.sin(inc);
    const fwd = unit([vx, vy, vz]);
    return {
      r: [rx, ry, 0],
      v: [vx, vy, vz],
      att: fwd,
      angVel: [0, 0, 0],
      sas: 'hold',
      onPad: false,
      landed: false,
      stage: 2,
      mainEngine: false,
      chuteArmed: false,
      chuteState: 0,
      fuel1: 0,
      maxFuel1: 0,
      fuel: opts.fuel ?? c.ship.fuelMassT,
      maxFuel: opts.fuel ?? c.ship.fuelMassT,
      lastDir: fwd,
      peakAltKm: alt, peakSpd: vc, peakMaxQ: 0, peakG: 0,
      mach: 0, dynQ: 0, gLoad: 0, twr: 0, pitchDeg: 0, downrangeKm: 0,
      debris: [],
      milestones: {}
    };
  }

  const relR = () => st.ship.r;
  const relV = () => st.ship.v;

  function anyThrustRequested() {
    if (st.controlMode === 'manual') return Boolean(st.ship && st.ship.mainEngine && st.throttle > 0);
    for (const a of THRUST_ACTS) if (st.keys.has(B[a]) || st.uiThrust.has(a)) return true;
    return false;
  }

  function thrustDir() {
    const r = st.ship.r, v = st.ship.v;
    let refR = r, refV = v;
    if (st.navRef === 'target' && st.targetBody) {
      refR = sub(r, st.targetBody.relPosAt(st.t));
      refV = sub(v, st.targetBody.relVelAt(st.t));
    }
    const h = cross(refR, refV);
    let d = [0, 0, 0];
    if (st.keys.has(B.prograde) || st.uiThrust.has('prograde')) d = add(d, unit(refV));
    if (st.keys.has(B.retro) || st.uiThrust.has('retro')) d = add(d, mul(unit(refV), -1));
    if (st.keys.has(B.radialOut) || st.uiThrust.has('radialOut')) d = add(d, unit(refR));
    if (st.keys.has(B.radialIn) || st.uiThrust.has('radialIn')) d = add(d, mul(unit(refR), -1));
    if (st.keys.has(B.normal) || st.uiThrust.has('normal')) d = add(d, unit(h));
    if (st.keys.has(B.antiNormal) || st.uiThrust.has('antiNormal')) d = add(d, mul(unit(h), -1));
    return len(d) > 0 ? unit(d) : [0, 0, 0];
  }

  // Called continuously every frame (60 FPS) with rotational inertia & PD SAS torque
  function stepAttitude(dt) {
    const s = st.ship;
    if (!s || st.crashed) return;
    if (!s.angVel) s.angVel = [0, 0, 0];
    const up = unit(s.r);

    if (s.onPad || s.landed) {
      s.att = up;
      s.angVel = [0, 0, 0];
      s.pitchDeg = 90;
      return;
    }

    const dtC = Math.min(dt, 0.05);
    const heavy = s.stage === 1;
    const torqAccel = heavy ? 1.55 : 3.2; // Stage 1 has larger moment of inertia than nimble Stage 2
    const maxRate = heavy ? 0.85 : 1.45;
    const sasKd = heavy ? 4.4 : 6.2;
    const sasKp = heavy ? 14.0 : 24.0;

    // Subtle atmospheric weathervane + rotational air damping below 45 km
    const alt = len(s.r) - CONFIG.body.radius;
    const rho = atmoDensity(alt);
    if (rho > 0 && s.dynQ > 0.05) {
      const airDamp = Math.exp(-Math.min(1.5, s.dynQ * 0.025) * dtC);
      s.angVel = mul(s.angVel, airDamp);
    }

    const manualDir = thrustDir();
    let east = cross([0, 0, 1], up);
    east = len(east) > 1e-4 ? unit(east) : [0, 1, 0];
    const north = unit(cross(up, east));

    const isManual = st.controlMode === 'manual';
    let pitchEast = 0, pitchNorth = 0;
    if (st.keys.has('d') || st.keys.has('arrowright')) pitchEast += 1;
    if (st.keys.has('a') || st.keys.has('arrowleft')) pitchEast -= 1;
    if (st.keys.has('arrowup') || (isManual && st.keys.has('s'))) pitchNorth += 1;
    if (st.keys.has('arrowdown') || (isManual && st.keys.has('w'))) pitchNorth -= 1;

    if (!isManual && len(manualDir) > 0) {
      const cDot = clamp(dot(s.att, manualDir), -1, 1);
      const ang = Math.acos(cDot);
      let ax = cross(s.att, manualDir);
      if (len(ax) < 1e-5 && cDot < 0) ax = north;
      if (ang > 1e-4 && len(ax) > 1e-6) {
        const axU = unit(ax);
        const desVel = mul(axU, Math.min(maxRate * 1.4, ang * 6.5));
        const dv = sub(desVel, s.angVel);
        const dvLen = len(dv);
        const maxDv = torqAccel * 2.2 * dtC;
        s.angVel = dvLen > maxDv ? add(s.angVel, mul(dv, maxDv / dvLen)) : desVel;
      } else {
        s.angVel = mul(s.angVel, Math.exp(-sasKd * dtC));
      }
    } else if (pitchEast !== 0 || pitchNorth !== 0) {
      let torqueAxis = [0, 0, 0];
      if (pitchEast !== 0) torqueAxis = add(torqueAxis, mul(north, pitchEast));
      if (pitchNorth !== 0) torqueAxis = add(torqueAxis, mul(east, -pitchNorth));
      torqueAxis = unit(torqueAxis);
      s.angVel = add(s.angVel, mul(torqueAxis, torqAccel * dtC));
      // Gently damp cross-axis spin so manual turns feel responsive yet weighty
      const along = dot(s.angVel, torqueAxis);
      const perp = sub(s.angVel, mul(torqueAxis, along));
      s.angVel = add(mul(torqueAxis, along), mul(perp, Math.exp(-3.0 * dtC)));
      if (s.sas !== 'off' && s.sas !== 'hold') {
        s.sas = 'hold';
        if (OC.syncSasBtns) OC.syncSasBtns();
      }
    } else {
      let tgt = null;
      const airV = sub(s.v, surfaceVelAt(s.r));
      if (s.sas === 'up') tgt = up;
      else if (s.sas === 'pro') {
        const refV = alt < 40 ? airV : (st.navRef === 'target' && st.targetBody ? sub(s.v, st.targetBody.relVelAt(st.t)) : s.v);
        if (len(refV) > 0.004) tgt = unit(refV);
      } else if (s.sas === 'ret') {
        const refV = alt < 40 ? airV : (st.navRef === 'target' && st.targetBody ? sub(s.v, st.targetBody.relVelAt(st.t)) : s.v);
        if (len(refV) > 0.004) tgt = mul(unit(refV), -1);
      }

      if (tgt) {
        const cDot = clamp(dot(s.att, tgt), -1, 1);
        const ang = Math.acos(cDot);
        let ax = cross(s.att, tgt);
        if (len(ax) < 1e-5 && cDot < 0) ax = north;
        if (ang > 1e-4 && len(ax) > 1e-6) {
          const axU = unit(ax);
          const desOmega = mul(axU, Math.min(maxRate, Math.sqrt(2 * torqAccel * ang) * 0.85));
          const reqAcc = sub(mul(desOmega, sasKp * 0.25), mul(s.angVel, sasKd * 0.55));
          const accLen = len(reqAcc);
          const capAcc = torqAccel * 1.1;
          const applied = accLen > capAcc ? mul(reqAcc, capAcc / accLen) : reqAcc;
          s.angVel = add(s.angVel, mul(applied, dtC));
        } else {
          s.angVel = mul(s.angVel, Math.exp(-sasKd * dtC));
        }
      } else if (s.sas === 'hold') {
        // Finite PD damping: momentum carries rocket slightly after releasing turn key before settling
        const wMag = len(s.angVel);
        if (wMag > 1e-5) {
          const brake = Math.min(wMag, torqAccel * 0.85 * dtC + wMag * (1 - Math.exp(-sasKd * 0.45 * dtC)));
          s.angVel = mul(s.angVel, Math.max(0, (wMag - brake) / wMag));
        }
      }
      // If s.sas === 'off': pure unassisted rotational inertia!
    }

    // Clamp peak angular velocity & remove spin strictly along s.att
    const axial = dot(s.angVel, s.att);
    if (Math.abs(axial) > 1e-6) s.angVel = sub(s.angVel, mul(s.att, axial));
    const wMag = len(s.angVel);
    if (wMag > maxRate * 1.5) s.angVel = mul(s.angVel, (maxRate * 1.5) / wMag);
    if (wMag > 1e-6) s.att = rotateAroundAxis(s.att, mul(s.angVel, 1 / wMag), wMag * dtC);

    s.pitchDeg = Math.asin(clamp(dot(s.att, up), -1, 1)) * 180 / Math.PI;
  }

  function stepDebris(dt) {
    for (let i = st.ship.debris.length - 1; i >= 0; i--) {
      const d = st.ship.debris[i];
      rk2StepInto(d.r[0], d.r[1], d.r[2], d.v[0], d.v[1], d.v[2], st.t, dt, 0, 0, 0, 0, CONFIG.ship.s1DryMassT, 0.25, _rkOut);
      d.r[0] = _rkOut[0]; d.r[1] = _rkOut[1]; d.r[2] = _rkOut[2];
      d.v[0] = _rkOut[3]; d.v[1] = _rkOut[4]; d.v[2] = _rkOut[5];
      if (d.tumbleAxis) d.att = rotateAroundAxis(d.att, d.tumbleAxis, d.spinRate * dt);
      d.spin += d.spinRate * dt;
      d.age += dt;
      if (len(d.r) <= surfaceRadiusAt(d.r, st.t) || d.age > 900) st.ship.debris.splice(i, 1);
    }
  }

  function stepShip(dt) {
    const s = st.ship;
    const manualDir = thrustDir();

    if (s.onPad) {
      const u = unit(padRelPos(st.t + dt));
      const r0 = surfaceRadiusAt(u, st.t + dt) + 0.0011;
      s.r[0] = u[0] * r0; s.r[1] = u[1] * r0; s.r[2] = u[2] * r0;
      const sv = surfaceVelAt(s.r);
      s.v[0] = sv[0]; s.v[1] = sv[1]; s.v[2] = sv[2];
      s.att = u; s.lastDir = u; s.angVel = [0, 0, 0];
      st.t += dt;
      st.thrustedLastStep = false;
      const spec = stageThrustSpec(s, 0);
      s.twr = spec.thrustF / (totalMass(s) * G0);
      s.gLoad = 1.0; s.mach = 0; s.dynQ = 0; s.pitchDeg = 90;
      return;
    }

    if (s.landedMoon) {
      const wantLiftoff = (s.mainEngine || len(manualDir) > 0) && activeFuel(s) > 0 && (st.throttle > 0.05 || len(manualDir) > 0);
      if (wantLiftoff) {
        s.landedMoon = false;
        s.landed = false;
      } else {
        const mPos = moonRelPos(st.t + dt);
        if (!s.moonLandingUnit) s.moonLandingUnit = unit(sub(s.r, moonRelPos(st.t)));
        const uMoon = s.moonLandingUnit;
        s.r = add(mPos, mul(uMoon, CONFIG.moon.radius + 0.001));
        s.v = moonRelVel(st.t + dt);
        s.att = uMoon; s.lastDir = uMoon; s.angVel = [0, 0, 0];
        st.t += dt;
        st.thrustedLastStep = false;
        s.gLoad = (CONFIG.moon.mu / (CONFIG.moon.radius * CONFIG.moon.radius)) / G0;
        s.mach = 0; s.dynQ = 0; s.pitchDeg = 90;
        return;
      }
    }

    if (s.landed) {
      const wantLiftoff = (s.mainEngine || len(manualDir) > 0) && activeFuel(s) > 0 && (st.throttle > 0.05 || len(manualDir) > 0);
      if (wantLiftoff) {
        s.landed = false;
      } else {
        const nextU = rotateAroundAxis(unit(s.r), [0, 0, 1], OMEGA * dt);
        s.r = mul(nextU, surfaceRadiusAt(nextU, st.t + dt) + 0.001);
        s.v = surfaceVelAt(s.r);
        s.att = unit(s.r); s.lastDir = s.att; s.angVel = [0, 0, 0];
        st.t += dt;
        st.thrustedLastStep = false;
        s.gLoad = 1.0; s.mach = 0; s.dynQ = 0; s.pitchDeg = 90;
        return;
      }
    }

    const rLen0 = len(s.r);
    const alt0 = rLen0 - CONFIG.body.radius;
    const fuelAvail = activeFuel(s);
    const isManual = st.controlMode === 'manual';
    const useVectorThrust = !isManual && len(manualDir) > 0;
    const useMain = (isManual || !useVectorThrust) && s.mainEngine && st.throttle > 0;
    const thrusting = (useVectorThrust || useMain) && fuelAvail > 0;
    const dir = useVectorThrust ? manualDir : s.att;

    const spec = stageThrustSpec(s, alt0);
    const thrustF = thrusting ? spec.thrustF * st.throttle : 0;
    const mass = totalMass(s);
    const cdArea = currentCdArea(s);

    rk4RelInto(
      s.r[0], s.r[1], s.r[2], s.v[0], s.v[1], s.v[2],
      st.t, dt, thrustF / mass, dir[0], dir[1], dir[2], mass, true, cdArea, _rkOut
    );
    s.r[0] = _rkOut[0]; s.r[1] = _rkOut[1]; s.r[2] = _rkOut[2];
    s.v[0] = _rkOut[3]; s.v[1] = _rkOut[4]; s.v[2] = _rkOut[5];
    st.t += dt;

    if (thrusting) {
      const dm = thrustF * dt / (spec.isp * G0);
      if (s.stage === 1) s.fuel1 = Math.max(0, s.fuel1 - dm);
      else s.fuel = Math.max(0, s.fuel - dm);
    }
    s.lastDir = s.att;
    st.thrustedLastStep = thrusting;
    st.lastDirVec = dir;

    stepDebris(dt);

    const rLen = len(s.r);
    const alt = Math.max(0, rLen - CONFIG.body.radius);
    const agl = Math.max(0, rLen - surfaceRadiusAt(s.r, st.t));
    const airV = sub(s.v, surfaceVelAt(s.r));
    const airSpd = len(airV);
    const rho = atmoDensity(alt);
    s.mach = airSpd / speedOfSoundKmS(alt);
    s.dynQ = 0.5 * 1.225 * rho * airSpd * airSpd * 1000;
    const dragAcc = (cdArea * rho * airSpd * airSpd) / Math.max(0.5, mass);
    s.gLoad = ((thrustF / mass) + dragAcc) / G0;
    const localG = CONFIG.body.mu / (rLen * rLen);
    s.twr = spec.thrustF / (mass * localG);
    s.pitchDeg = Math.asin(clamp(dot(s.att, unit(s.r)), -1, 1)) * 180 / Math.PI;
    const padNow = padRelPos(st.t);
    s.downrangeKm = CONFIG.body.radius * Math.acos(clamp(dot(unit(s.r), unit(padNow)), -1, 1));
    s.peakAltKm = Math.max(s.peakAltKm, alt);
    s.peakSpd = Math.max(s.peakSpd, len(s.v));
    s.peakMaxQ = Math.max(s.peakMaxQ, s.dynQ);
    s.peakG = Math.max(s.peakG, s.gLoad);

    const radVel = dot(s.v, unit(s.r));
    if (s.chuteArmed && agl < 10 && radVel < -0.005) {
      if (s.chuteState === 0) { s.chuteState = 1; OC.showToast('DROGUE CHUTE DEPLOYED'); OC.SFX.beep(480, 0.12, 'triangle', 0.08); }
      if (agl < 2.6 && s.chuteState < 2) { s.chuteState = 2; OC.showToast('MAIN CHUTE OPEN!'); OC.SFX.beep(620, 0.14, 'triangle', 0.09); }
    }
  }

  function orbitInfo(r, v, tt = (st && st.VIS ? st.VIS.t : 0)) {
    let mu = CONFIG.body.mu, R = CONFIG.body.radius, bodyName = CONFIG.body.name, inMoonSoi = false;
    let rRef = r, vRef = v;
    if (tt !== undefined && tt !== null) {
      const mPos = moonRelPos(tt);
      const rRelM = sub(r, mPos);
      const dM = len(rRelM);
      if (dM < CONFIG.moon.soiKm) {
        inMoonSoi = true;
        bodyName = CONFIG.moon.name;
        mu = CONFIG.moon.mu;
        R = CONFIG.moon.radius;
        rRef = rRelM;
        vRef = sub(v, moonRelVel(tt));
      }
    }
    const rl = len(rRef), vl = len(vRef);
    const energy = vl * vl / 2 - mu / rl;
    const a = energy < 0 ? -mu / (2 * energy) : Infinity;
    const rdv = dot(rRef, vRef);
    const eVec = mul(sub(mul(rRef, vl * vl - mu / rl), mul(vRef, rdv)), 1 / mu);
    const e = len(eVec);
    const h = cross(rRef, vRef);
    return {
      energy, e, eVec, h, a, inMoonSoi, bodyName, rRef, vRef, mu, R,
      periapsisKm: (e < 1 && a !== Infinity) ? a * (1 - e) - R : (a === Infinity ? (dot(h, h) / mu) / (1 + e) - R : null),
      apoapsisKm: (a === Infinity || e >= 1) ? null : a * (1 + e) - R,
      periodS: (a === Infinity || e >= 1) ? null : TAU * Math.sqrt(a * a * a / mu),
      incDeg: Math.acos(clamp(h[2] / Math.max(1e-9, len(h)), -1, 1)) * 180 / Math.PI,
      altKm: rl - R
    };
  }

  function timeToApsis(r, v, tt = (st && st.VIS ? st.VIS.t : 0)) {
    const info = orbitInfo(r, v, tt);
    const mu = info.mu;
    const rRef = info.rRef, vRef = info.vRef;
    const rl = len(rRef), vl = len(vRef);
    const energy = vl * vl / 2 - mu / rl;
    if (energy >= 0) return { dtAp: null, dtPe: null };
    const a = -mu / (2 * energy);
    const rdv = dot(rRef, vRef);
    const e = info.e, eVec = info.eVec;
    if (e < 1e-4 || e >= 0.995) return { dtAp: null, dtPe: null };
    const cosNu = clamp(dot(eVec, rRef) / (e * rl), -1, 1);
    let nu = Math.acos(cosNu);
    if (rdv < 0) nu = TAU - nu;
    let E = 2 * Math.atan2(Math.sqrt(1 - e) * Math.sin(nu * 0.5), Math.sqrt(1 + e) * Math.cos(nu * 0.5));
    E = ((E % TAU) + TAU) % TAU;
    const M = ((E - e * Math.sin(E)) % TAU + TAU) % TAU;
    const n = Math.sqrt(mu / (a * a * a));
    return { dtPe: ((TAU - M) % TAU) / n, dtAp: ((Math.PI - M + TAU) % TAU) / n };
  }

  function remainingDv(s = st.ship) {
    const c = CONFIG.ship;
    const m2 = c.dryMassT + s.fuel;
    const dv2 = c.ispS * G0 * Math.log(m2 / c.dryMassT);
    if (s.stage === 1) {
      const mStart = c.s1DryMassT + s.fuel1 + m2;
      const mEnd1 = c.s1DryMassT + m2;
      const dv1 = c.s1IspVac * G0 * Math.log(mStart / mEnd1);
      return dv1 + dv2;
    }
    return dv2;
  }

  function selfTest() {
    const saved = { ship: st.ship, t: st.t, thr: st.throttle, keys: new Set(st.keys), ui: new Set(st.uiThrust), navRef: st.navRef, targetBody: st.targetBody };
    st.keys.clear(); st.uiThrust.clear(); st.throttle = 1; st.navRef = 'orbit'; st.targetBody = null;
    st.ship = makeShip(); st.t = 0;
    const info0 = orbitInfo(relR(), relV());
    const rel0 = [st.ship.r[0], st.ship.r[1], st.ship.r[2]], e0 = info0.energy;
    const steps = Math.round(info0.periodS / PH);
    for (let i = 0; i < steps; i++) stepShip(PH);
    const drift = len(sub(relR(), rel0));
    const eDrift = Math.abs(orbitInfo(relR(), relV()).energy - e0) / Math.abs(e0);
    st.ship = saved.ship; st.t = saved.t; st.throttle = saved.thr;
    st.keys = saved.keys; st.uiThrust = saved.ui; st.navRef = saved.navRef; st.targetBody = saved.targetBody;
    const ok = drift < 2 && eDrift < 2e-3;
    console.log(`[self-test] rel pos drift ${drift.toFixed(3)} km, energy drift ${(eDrift * 100).toExponential(2)} % -> ${ok ? 'PASS' : 'FAIL'}`);
    return ok;
  }

  Object.assign(OC, {
    OMEGA, _visBuf, planetPos, planetVel, moonRelPos, moonRelVel, moonPos, moonVel,
    padRelPos, surfaceVelAt, terrainInfoAtLocal, terrainHeightAtRel, surfaceRadiusAt, isWaterAtRel,
    terrainNormalAtRel, moonSurfaceRadiusAt, moonNormalAtRel,
    atmoDensity, speedOfSoundKmS, totalMass, activeFuel, activeMaxFuel,
    currentCdArea, stageThrustSpec, rk4RelInto, rk2StepInto, makeShip, relR, relV,
    anyThrustRequested, thrustDir, stepAttitude, stepShip, orbitInfo, timeToApsis, remainingDv, selfTest
  });
})(window.OC);