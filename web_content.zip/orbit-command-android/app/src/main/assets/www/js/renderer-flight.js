'use strict';

(function (OC) {
  const { CONFIG, S, TAU, MOON_N, OMEGA, PAD_LON0, add, sub, mul, dot, cross, len, unit, clamp, state: st } = OC;

  const _basis = new Float32Array(9);
  const _spinBasis = new Float32Array(9);
  let _shipRefHint = [0, 0, 1];

  function makeBasis(upVec, refHint = [0, 0, 1]) {
    const up = unit(upVec);
    const ref = Math.abs(dot(up, refHint)) > 0.94 ? [1, 0, 0] : refHint;
    const right = unit(cross(ref, up));
    const fwd = cross(up, right);
    _basis[0] = right[0]; _basis[1] = right[1]; _basis[2] = right[2];
    _basis[3] = fwd[0];   _basis[4] = fwd[1];   _basis[5] = fwd[2];
    _basis[6] = up[0];    _basis[7] = up[1];    _basis[8] = up[2];
    return _basis;
  }

  function makeShipBasis(upVec) {
    const up = unit(upVec);
    if (Math.abs(dot(up, _shipRefHint)) > 0.92) {
      const alt = Math.abs(up[2]) < 0.85 ? [0, 0, 1] : [1, 0, 0];
      _shipRefHint = unit(cross(alt, up));
    }
    const right = unit(cross(_shipRefHint, up));
    const fwd = cross(up, right);
    _shipRefHint = unit(cross(up, right));
    _basis[0] = right[0]; _basis[1] = right[1]; _basis[2] = right[2];
    _basis[3] = fwd[0];   _basis[4] = fwd[1];   _basis[5] = fwd[2];
    _basis[6] = up[0];    _basis[7] = up[1];    _basis[8] = up[2];
    return _basis;
  }

  function makePadBasis(spin) {
    const a = spin + PAD_LON0;
    const ux = Math.cos(a), uy = Math.sin(a);
    const ex = -uy, ey = ux;
    _basis[0] = ex; _basis[1] = ey; _basis[2] = 0;
    _basis[3] = 0;  _basis[4] = 0;  _basis[5] = 1;
    _basis[6] = ux; _basis[7] = uy; _basis[8] = 0;
    return _basis;
  }

  function makeSpinBasis(spin) {
    const cs = Math.cos(spin), sn = Math.sin(spin);
    _spinBasis[0] = cs;  _spinBasis[1] = sn; _spinBasis[2] = 0;
    _spinBasis[3] = -sn; _spinBasis[4] = cs; _spinBasis[5] = 0;
    _spinBasis[6] = 0;   _spinBasis[7] = 0;  _spinBasis[8] = 1;
    return _spinBasis;
  }

  // Concentric polar 3D terrain mesh (30 rings x 52 sectors = 1561 verts)
  // Dense (~15-60m) near craft/pad; tapers cleanly onto R=600 at rim where meshFS matches bodyFS pixel-for-pixel
  const RINGS = 30, SEGS = 52;
  const VERTS_T = 1 + RINGS * SEGS;
  const _tVerts = new Float32Array(VERTS_T * 9);
  const _tPosTrue = new Float32Array(VERTS_T * 3);
  const _tIdx = new Uint16Array(SEGS * 3 + (RINGS - 1) * SEGS * 6);
  {
    let k = 0;
    for (let i = 0; i < SEGS; i++) {
      const i1 = (i + 1) % SEGS;
      _tIdx[k++] = 0;
      _tIdx[k++] = 1 + i;
      _tIdx[k++] = 1 + i1;
    }
    for (let j = 0; j < RINGS - 1; j++) {
      const r0 = 1 + j * SEGS;
      const r1 = r0 + SEGS;
      for (let i = 0; i < SEGS; i++) {
        const i1 = (i + 1) % SEGS;
        const a = r0 + i, b = r0 + i1;
        const c = r1 + i, d = r1 + i1;
        _tIdx[k++] = a; _tIdx[k++] = c; _tIdx[k++] = b;
        _tIdx[k++] = b; _tIdx[k++] = c; _tIdx[k++] = d;
      }
    }
  }

  const _terrainCache = {
    anchorLocal: [1, 0, 0],
    anchorPosLocal: [CONFIG.body.radius, 0, 0],
    tileOrigin: [0, 0, 0],
    halfSpanKm: -1,
    altElevFade: -1,
    hasMesh: false
  };

  function smoothstep(e0, e1, x) {
    const t = clamp((x - e0) / (e1 - e0), 0, 1);
    return t * t * (3 - 2 * t);
  }

  function writeTerrainVertex(vi, nx, ny, nz, rTrue, rTapered, ap) {
    _tPosTrue[vi * 3] = nx * rTrue - ap[0];
    _tPosTrue[vi * 3 + 1] = ny * rTrue - ap[1];
    _tPosTrue[vi * 3 + 2] = nz * rTrue - ap[2];
    const vo = vi * 9;
    _tVerts[vo] = nx * rTapered - ap[0];
    _tVerts[vo + 1] = ny * rTapered - ap[1];
    _tVerts[vo + 2] = nz * rTapered - ap[2];
    _tVerts[vo + 6] = 0.5;
    _tVerts[vo + 7] = 0.5;
    _tVerts[vo + 8] = 0.5;
  }

  function updateLocalTerrainPatch(targetRelP, spinPlanet, camAlt) {
    if (!OC.GLR || !OC.GLR.updateDynamicMesh || camAlt > 32) return false;
    const R = CONFIG.body.radius;
    const uWorld = unit(targetRelP);
    const cs = Math.cos(spinPlanet), sn = Math.sin(spinPlanet);
    const ux = uWorld[0] * cs + uWorld[1] * sn;
    const uy = -uWorld[0] * sn + uWorld[1] * cs;
    const uz = uWorld[2];

    const targetRadius = clamp(camAlt * 2.8 + 38.0, 38.0, 110.0);
    const altElevFade = 1.0 - smoothstep(10.0, 30.0, camAlt);
    const movedKm = Math.hypot(
      ux - _terrainCache.anchorLocal[0],
      uy - _terrainCache.anchorLocal[1],
      uz - _terrainCache.anchorLocal[2]
    ) * R;

    const needRebuild = !_terrainCache.hasMesh ||
      movedKm > targetRadius * 0.14 ||
      Math.abs(targetRadius - _terrainCache.halfSpanKm) > _terrainCache.halfSpanKm * 0.25 ||
      Math.abs(altElevFade - _terrainCache.altElevFade) > 0.04;

    if (!needRebuild) return true;

    const ap = [ux * R, uy * R, uz * R];
    _terrainCache.anchorLocal = [ux, uy, uz];
    _terrainCache.anchorPosLocal = ap;
    _terrainCache.tileOrigin = [
      ap[0] - Math.floor(ap[0] / 64.0) * 64.0,
      ap[1] - Math.floor(ap[1] / 64.0) * 64.0,
      ap[2] - Math.floor(ap[2] / 64.0) * 64.0
    ];
    _terrainCache.halfSpanKm = targetRadius;
    _terrainCache.altElevFade = altElevFade;
    _terrainCache.hasMesh = true;

    const ref = Math.abs(uz) > 0.92 ? [1, 0, 0] : [0, 0, 1];
    const east = unit(cross(ref, [ux, uy, uz]));
    const north = cross([ux, uy, uz], east);

    const cInfo = OC.terrainInfoAtLocal(ux, uy, uz);
    const cH = cInfo.elevKm * altElevFade;
    writeTerrainVertex(0, ux, uy, uz, R + cH, R + cH, ap);

    for (let j = 0; j < RINGS; j++) {
      const t = (j + 1) / RINGS;
      const radKm = targetRadius * Math.pow(t, 2.55);
      const edgeTaper = 1.0 - smoothstep(0.65, 0.98, t);
      const rowBase = 1 + j * SEGS;
      for (let i = 0; i < SEGS; i++) {
        const ang = (i / SEGS) * TAU;
        const dx = Math.cos(ang) * radKm, dy = Math.sin(ang) * radKm;
        const px = ap[0] + east[0] * dx + north[0] * dy;
        const py = ap[1] + east[1] * dx + north[1] * dy;
        const pz = ap[2] + east[2] * dx + north[2] * dy;
        const pLen = Math.hypot(px, py, pz);
        const nx = px / pLen, ny = py / pLen, nz = pz / pLen;
        const info = OC.terrainInfoAtLocal(nx, ny, nz);
        const hTrue = info.elevKm * altElevFade;
        writeTerrainVertex(rowBase + i, nx, ny, nz, R + hTrue, R + hTrue * edgeTaper, ap);
      }
    }

    _tVerts[3] = ux; _tVerts[4] = uy; _tVerts[5] = uz;

    for (let j = 0; j < RINGS; j++) {
      const rowBase = 1 + j * SEGS;
      const prevBase = j === 0 ? 0 : rowBase - SEGS;
      const nextBase = j === RINGS - 1 ? rowBase : rowBase + SEGS;
      for (let i = 0; i < SEGS; i++) {
        const im = (i + SEGS - 1) % SEGS, ip = (i + 1) % SEGS;
        const l = (rowBase + im) * 3, r = (rowBase + ip) * 3;
        const d = (j === 0 ? 0 : prevBase + i) * 3;
        const u = (nextBase + i) * 3;
        const tx = _tPosTrue[r] - _tPosTrue[l], ty = _tPosTrue[r + 1] - _tPosTrue[l + 1], tz = _tPosTrue[r + 2] - _tPosTrue[l + 2];
        const bx = _tPosTrue[u] - _tPosTrue[d], by = _tPosTrue[u + 1] - _tPosTrue[d + 1], bz = _tPosTrue[u + 2] - _tPosTrue[d + 2];
        let nx = by * tz - bz * ty, ny = bz * tx - bx * tz, nz = bx * ty - by * tx;
        if (nx * ux + ny * uy + nz * uz < 0) { nx = -nx; ny = -ny; nz = -nz; }
        const nl = Math.hypot(nx, ny, nz) || 1;
        const vo = (rowBase + i) * 9;
        _tVerts[vo + 3] = nx / nl;
        _tVerts[vo + 4] = ny / nl;
        _tVerts[vo + 5] = nz / nl;
      }
    }

    OC.GLR.updateDynamicMesh('terrain', _tVerts, _tIdx, _tIdx.length, false);
    return true;
  }

  // Distance-culled 3D ground boulders & shrubs (loads < 2.4 km AGL, unloads past it)
  const PROP_HALF = 5;
  const PROP_CELL_RAD = 0.00024;
  const MAX_PROPS = 121;
  const _pVerts = new Float32Array(MAX_PROPS * 12 * 9);
  const _pIdx = new Uint16Array(MAX_PROPS * 12);
  for (let i = 0; i < MAX_PROPS * 12; i++) _pIdx[i] = i;

  const _propCache = {
    latI: -999999,
    lonI: -999999,
    anchorPosLocal: [CONFIG.body.radius, 0, 0],
    vertCount: 0,
    active: false
  };

  function cellRand(a, b, c) {
    let n = Math.imul(a, 374761393) + Math.imul(b, 668265263) + Math.imul(c, 1274126177);
    n = Math.imul(n ^ (n >>> 13), 1274126177);
    return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
  }

  function updateGroundProps(shipRelP, spinPlanet, aglKm) {
    if (!OC.GLR || !OC.GLR.updateDynamicMesh || aglKm > 2.4 || st.dist > 1.8) {
      _propCache.active = false;
      return false;
    }

    const uWorld = unit(shipRelP);
    const cs = Math.cos(spinPlanet), sn = Math.sin(spinPlanet);
    const ux = uWorld[0] * cs + uWorld[1] * sn;
    const uy = -uWorld[0] * sn + uWorld[1] * cs;
    const uz = uWorld[2];

    const lat = Math.asin(clamp(uz, -1, 1));
    const lon = Math.atan2(uy, ux);
    const latI = Math.round(lat / PROP_CELL_RAD);
    const lonI = Math.round(lon / PROP_CELL_RAD);

    if (_propCache.active && latI === _propCache.latI && lonI === _propCache.lonI) {
      return _propCache.vertCount > 0;
    }

    const R = CONFIG.body.radius;
    const ap = [ux * R, uy * R, uz * R];
    _propCache.latI = latI;
    _propCache.lonI = lonI;
    _propCache.anchorPosLocal = ap;
    _propCache.active = true;

    let vCursor = 0;
    const pushTri = (a, b, c, col) => {
      const ux0 = b[0] - a[0], uy0 = b[1] - a[1], uz0 = b[2] - a[2];
      const vx0 = c[0] - a[0], vy0 = c[1] - a[1], vz0 = c[2] - a[2];
      const n = unit(cross([ux0, uy0, uz0], [vx0, vy0, vz0]));
      const pts = [a, b, c];
      for (let m = 0; m < 3; m++) {
        const o = (vCursor++) * 9;
        _pVerts[o] = pts[m][0]; _pVerts[o + 1] = pts[m][1]; _pVerts[o + 2] = pts[m][2];
        _pVerts[o + 3] = n[0];   _pVerts[o + 4] = n[1];   _pVerts[o + 5] = n[2];
        _pVerts[o + 6] = col[0]; _pVerts[o + 7] = col[1]; _pVerts[o + 8] = col[2];
      }
    };

    for (let di = -PROP_HALF; di <= PROP_HALF; di++) {
      for (let dj = -PROP_HALF; dj <= PROP_HALF; dj++) {
        const ci = latI + di, cj = lonI + dj;
        if (cellRand(ci, cj, 1) < 0.35) continue;
        const pLat = (ci + (cellRand(ci, cj, 2) - 0.5) * 0.8) * PROP_CELL_RAD;
        if (Math.abs(pLat) > 1.54) continue;
        const pLon = (cj + (cellRand(ci, cj, 3) - 0.5) * 0.8) * PROP_CELL_RAD;
        const cLat = Math.cos(pLat);
        const nx = cLat * Math.cos(pLon), ny = cLat * Math.sin(pLon), nz = Math.sin(pLat);

        const info = OC.terrainInfoAtLocal(nx, ny, nz);
        // Leave a 300 m concrete perimeter around Spaceport pad & crawlerway
        if (info.isWater || info.kscD < 0.0005) continue;

        const rBase = R + info.elevKm - 0.0004;
        const cx = nx * rBase - ap[0], cy = ny * rBase - ap[1], cz = nz * rBase - ap[2];
        const up = [nx, ny, nz];
        const ref = Math.abs(nz) > 0.92 ? [1, 0, 0] : [0, 0, 1];
        const e = unit(cross(ref, up));
        const nrm = cross(up, e);

        const isShrub = info.elevKm < 0.55 && cellRand(ci, cj, 4) > 0.45;
        const rad = (isShrub ? 0.0032 : 0.0038) + cellRand(ci, cj, 5) * 0.0040;
        const hgt = rad * (isShrub ? 0.65 : 0.42 + cellRand(ci, cj, 6) * 0.25);
        const ang0 = cellRand(ci, cj, 7) * TAU;
        const col = isShrub
          ? [0.16 + cellRand(ci, cj, 8) * 0.07, 0.34 + cellRand(ci, cj, 9) * 0.09, 0.14]
          : [0.40 + cellRand(ci, cj, 8) * 0.10, 0.39 + cellRand(ci, cj, 8) * 0.09, 0.36 + cellRand(ci, cj, 8) * 0.08];

        const basePts = [];
        for (let s = 0; s < 4; s++) {
          const a = ang0 + (s / 4) * TAU;
          const ox = Math.cos(a) * rad, oy = Math.sin(a) * rad;
          basePts.push([cx + e[0] * ox + nrm[0] * oy, cy + e[1] * ox + nrm[1] * oy, cz + e[2] * ox + nrm[2] * oy]);
        }
        const tip = [cx + up[0] * hgt, cy + up[1] * hgt, cz + up[2] * hgt];
        for (let s = 0; s < 4; s++) {
          const f = 1 - s * 0.06;
          pushTri(basePts[s], basePts[(s + 1) % 4], tip, [col[0] * f, col[1] * f, col[2] * f]);
        }
      }
    }

    _propCache.vertCount = vCursor;
    if (vCursor > 0) {
      OC.GLR.updateDynamicMesh('groundProps', _pVerts.subarray(0, vCursor * 9), _pIdx.subarray(0, vCursor), vCursor, true);
    }
    return vCursor > 0;
  }

  function drawParticlesRel(ctx) {
    for (const pt of st.particles) {
      const q = OC.projectRel(pt.p);
      if (!q) continue;
      ctx.globalAlpha = clamp(pt.life, 0, 1);
      ctx.fillStyle = pt.col;
      ctx.beginPath(); ctx.arc(q[0], q[1], pt.size, 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawArrowRel(ctx, from, dir, length, color, label) {
    const a = OC.projectRel(from), b = OC.projectRel(add(from, mul(dir, length)));
    if (!a || !b) return;
    ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]);
    ctx.strokeStyle = color; ctx.lineWidth = 1.15; ctx.stroke();
    ctx.fillStyle = color; ctx.font = '11px ui-monospace, monospace';
    ctx.fillText(label, b[0] + 4, b[1] + 3);
  }

  function drawFallbackDisc(ctx, relCam, R, color, hasAtmo) {
    const center = add(st.CAM.pos, relCam);
    const c = OC.project(center);
    const d = len(relCam);
    if (!c || d <= R) return;
    const rpx = st.F * Math.tan(Math.asin(Math.min(0.999999, R / d)));
    if (hasAtmo && S.atmo) {
      const g = ctx.createRadialGradient(c[0], c[1], rpx * 0.85, c[0], c[1], rpx * 1.15);
      g.addColorStop(0, 'rgba(90,175,255,0.45)');
      g.addColorStop(1, 'rgba(90,175,255,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(c[0], c[1], rpx * 1.15, 0, TAU); ctx.fill();
    }
    ctx.beginPath(); ctx.arc(c[0], c[1], Math.max(2.2, rpx), 0, TAU);
    ctx.fillStyle = color; ctx.fill();
  }

  function drawFlightView(ctx, nowMs) {
    const vt = st.VIS.t;
    const P = st.VIS.P, M = st.VIS.M;
    const pRelCam = sub(P, st.CAM.pos);
    const mRelCam = sub(M, st.CAM.pos);
    const sunDirMoon = unit(mul(M, -1));
    const spinPlanet = vt * OMEGA;
    const spinMoon = vt * MOON_N;
    const camAlt = len(pRelCam) - CONFIG.body.radius;
    const camZenith = unit(sub(st.CAM.pos, P));

    let drewPlanetGL = false, drewMoonGL = false;
    if (OC.GLR) {
      OC.GLR.beginFrame(st.glFocal, camAlt, camZenith, vt, spinPlanet);
      OC.GLR.drawSun();
      if (len(pRelCam) >= len(mRelCam)) {
        drewPlanetGL = OC.GLR.drawBody(pRelCam, CONFIG.body.radius, CONFIG.body.atmoKm, st.SUNDIR, spinPlanet, vt, true, st.glFocal, 0);
        drewMoonGL = OC.GLR.drawBody(mRelCam, CONFIG.moon.radius, 0, sunDirMoon, spinMoon, vt, false, st.glFocal, 0);
      } else {
        drewMoonGL = OC.GLR.drawBody(mRelCam, CONFIG.moon.radius, 0, sunDirMoon, spinMoon, vt, false, st.glFocal, 0);
        drewPlanetGL = OC.GLR.drawBody(pRelCam, CONFIG.body.radius, CONFIG.body.atmoKm, st.SUNDIR, spinPlanet, vt, true, st.glFocal, 0);
      }

      OC.GLR.beginMeshPass(camAlt, camZenith, vt, spinPlanet);

      const cs = Math.cos(spinPlanet), sn = Math.sin(spinPlanet);
      const camRelPlanet = st.VIS.camRelP;
      const camDistCenter = len(camRelPlanet);
      const camAltKm = Math.max(0.001, camDistCenter - CONFIG.body.radius);
      // Anchor terrain patch and ground props directly under the CAMERA's nadir (proximity to camera, not rocket)
      const camNadirRel = mul(unit(camRelPlanet), CONFIG.body.radius);
      const patchTarget = camAltKm < 40 ? camNadirRel : (st.mode === 'ship' ? st.VIS.r : camNadirRel);
      const localZenith = unit(patchTarget);

      if (updateLocalTerrainPatch(patchTarget, spinPlanet, camAltKm)) {
        const ap = _terrainCache.anchorPosLocal;
        const anchorRelP = [ap[0] * cs - ap[1] * sn, ap[0] * sn + ap[1] * cs, ap[2]];
        const terrainRelCam = sub(anchorRelP, st.VIS.camRelP);
        OC.GLR.drawMesh(
          'terrain', terrainRelCam, makeSpinBasis(spinPlanet), 1.0,
          st.SUNDIR, localZenith, 0, 1, false,
          1.0, _terrainCache.tileOrigin, _terrainCache.halfSpanKm, _terrainCache.anchorPosLocal
        );
      }

      if (updateGroundProps(patchTarget, spinPlanet, camAltKm)) {
        const ap = _propCache.anchorPosLocal;
        const propAnchorRelP = [ap[0] * cs - ap[1] * sn, ap[0] * sn + ap[1] * cs, ap[2]];
        const propRelCam = sub(propAnchorRelP, st.VIS.camRelP);
        const propAlpha = clamp((2.4 - camAltKm) / 0.5, 0, 1) * clamp((1.8 - st.dist) / 0.35, 0, 1);
        if (propAlpha > 0.02) {
          OC.GLR.drawMesh('groundProps', propRelCam, makeSpinBasis(spinPlanet), 1.0, st.SUNDIR, localZenith, 0, propAlpha, false, 2.0);
        }
      }

      const padDir = unit(OC.padRelPos(vt));
      const padRel = mul(padDir, OC.surfaceRadiusAt(padDir, vt));
      const padRelCam = sub(padRel, st.VIS.camRelP);
      if (len(padRelCam) < 90) {
        OC.GLR.drawMesh('pad', padRelCam, makePadBasis(spinPlanet), 1.0, st.SUNDIR, padDir, 0, 1, false);
      }

      const objScale = st.dist < 1.8 ? 1.0 : st.dist * 0.56;
      for (const d of st.ship.debris) {
        // Visual interpolation with st.accum prevents alternating-frame sub-step jitter relative to the camera
        const dPos = st.accum > 1e-6 ? [
          d.r[0] + d.v[0] * st.accum,
          d.r[1] + d.v[1] * st.accum,
          d.r[2] + d.v[2] * st.accum
        ] : d.r;
        const dRelCam = sub(dPos, st.VIS.camRelP);
        if (len(dRelCam) < 300) {
          const debBasis = makeShipBasis(d.att);
          OC.GLR.drawMesh('stage1', dRelCam, debBasis, objScale, st.SUNDIR, unit(dPos), 0, 1, false);
        }
      }

      if (st.targetBody && !st.targetBody.isMoon && st.VIS.tgtRel) {
        const tgtRelCam = sub(st.VIS.tgtRel, st.VIS.camRelP);
        if (len(tgtRelCam) < 4000) {
          const tgtScale = Math.max(1.0, len(tgtRelCam) * 0.45);
          OC.GLR.drawMesh('targetSat', tgtRelCam, makeBasis(unit(st.VIS.tgtVelRel || [0, 1, 0])), tgtScale, st.SUNDIR, unit(st.VIS.tgtRel), 0, 1, false);
        }
      }

      if (!st.crashed) {
        const shipRelCam = sub(st.VIS.r, st.VIS.camRelP);
        const shipUp = unit(st.VIS.r);
        const att = st.VIS.att;
        const altNow = len(st.VIS.r) - CONFIG.body.radius;
        const bShip = makeShipBasis(att);
        const wingsOpen = altNow > 35 && st.ship.chuteState === 0;

        if (st.ship.stage === 1) {
          OC.GLR.drawMesh('stage1', shipRelCam, bShip, objScale, st.SUNDIR, shipUp, 0, 1, false);
          const s2RelCam = add(shipRelCam, mul(att, 0.021 * objScale));
          OC.GLR.drawMesh('stage2', s2RelCam, bShip, objScale, st.SUNDIR, shipUp, 0, 1, false);
          if (wingsOpen) OC.GLR.drawMesh('solarWings', s2RelCam, bShip, objScale, st.SUNDIR, shipUp, 0, 1, false);
          if (st.ship.chuteState > 0) {
            OC.GLR.drawMesh('chute', s2RelCam, makeBasis(shipUp), objScale * (st.ship.chuteState === 1 ? 0.55 : 1.0), st.SUNDIR, shipUp, 0, 0.94, false);
          }
        } else {
          OC.GLR.drawMesh('stage2', shipRelCam, bShip, objScale, st.SUNDIR, shipUp, 0, 1, false);
          if (wingsOpen) OC.GLR.drawMesh('solarWings', shipRelCam, bShip, objScale, st.SUNDIR, shipUp, 0, 1, false);
          if (st.ship.chuteState > 0) {
            OC.GLR.drawMesh('chute', shipRelCam, makeBasis(shipUp), objScale * (st.ship.chuteState === 1 ? 0.55 : 1.0), st.SUNDIR, shipUp, 0, 0.94, false);
          }
        }

        if (st.thrustedLastStep) {
          const isVac = altNow > 38;
          const plumeMesh = isVac ? 'plumeVac' : 'plume';
          const pScale = objScale * (st.ship.stage === 1 ? 1.25 : 0.72) * (0.65 + 0.55 * st.throttle) * (0.9 + 0.2 * Math.random());
          OC.GLR.drawMesh(plumeMesh, shipRelCam, bShip, pScale, st.SUNDIR, shipUp, 1.0, 0.85, true);
        }
      }
      OC.GLR.endMeshPass();
    }

    ctx.clearRect(0, 0, st.W, st.H);
    if (!OC.GLR) { ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, st.W, st.H); }
    if (!drewPlanetGL) drawFallbackDisc(ctx, pRelCam, CONFIG.body.radius, '#4888d0', true);
    if (!drewMoonGL) drawFallbackDisc(ctx, mRelCam, CONFIG.moon.radius, '#b0b8c5', false);

    // Depth cue: dashed drop line + ground ring with AGL readout (helps judge height over terrain)
    if (!st.crashed && st.ship && !st.landed) {
      const shipR = st.VIS.r, surfRad = OC.surfaceRadiusAt(shipR, vt);
      const agl = len(shipR) - surfRad;
      if (agl > 0.012 && agl < 40) {
        const gp = mul(unit(shipR), surfRad);
        const g2 = OC.projectRel(gp), s2 = OC.projectRel(shipR);
        if (g2 && s2 && !OC.isOccludedRel(gp)) {
          const al = clamp(1.0 - agl / 40, 0.25, 1) * 0.75;
          const rr = clamp(14 / Math.max(0.02, st.dist) + 6, 6, 40);
          ctx.save();
          ctx.strokeStyle = `rgba(120,220,255,${al.toFixed(2)})`; ctx.lineWidth = 1.2; ctx.setLineDash([4, 5]);
          ctx.beginPath(); ctx.moveTo(s2[0], s2[1]); ctx.lineTo(g2[0], g2[1]); ctx.stroke(); ctx.setLineDash([]);
          ctx.beginPath(); ctx.ellipse(g2[0], g2[1], rr, rr * 0.38, 0, 0, TAU); ctx.stroke();
          ctx.fillStyle = `rgba(0,0,0,${(al * 0.25).toFixed(2)})`; ctx.fill();
          ctx.font = '11px ui-monospace, monospace'; ctx.fillStyle = `rgba(190,240,255,${al.toFixed(2)})`;
          ctx.fillText(agl < 1 ? (agl * 1000).toFixed(0) + ' m' : agl.toFixed(1) + ' km', (s2[0] + g2[0]) / 2 + 8, (s2[1] + g2[1]) / 2);
          ctx.restore();
        }
      }
    }

    // Ground exhaust plume lighting when firing engines close to pad / planetary terrain
    if (!st.crashed && st.thrustedLastStep) {
      const shipR = st.VIS.r;
      const surfRad = OC.surfaceRadiusAt(shipR, vt);
      const aglNow = Math.max(0, len(shipR) - surfRad);
      if (aglNow < 0.35) {
        const groundPt = mul(unit(shipR), surfRad);
        const gScr = OC.projectRel(groundPt);
        if (gScr && !OC.isOccludedRel(groundPt)) {
          const glowAlpha = clamp((1.0 - aglNow / 0.35) * (0.45 + 0.45 * st.throttle), 0, 0.9);
          const glowR = clamp((42 / Math.max(0.02, st.dist)) * (0.8 + 0.4 * Math.random()), 12, 160);
          const grad = ctx.createRadialGradient(gScr[0], gScr[1], 2, gScr[0], gScr[1], glowR);
          grad.addColorStop(0, `rgba(255, 230, 160, ${glowAlpha})`);
          grad.addColorStop(0.35, `rgba(255, 140, 40, ${glowAlpha * 0.65})`);
          grad.addColorStop(1, 'rgba(255, 60, 10, 0)');
          ctx.save();
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(gScr[0], gScr[1], glowR, 0, TAU);
          ctx.fill();
          ctx.restore();
        }
      }
    }

    // Hypersonic re-entry plasma fire glow around the spacecraft
    if (!st.crashed && st.ship && st.ship.dynQ > 0.6) {
      const altNow = len(st.VIS.r) - CONFIG.body.radius;
      const spd = len(st.VIS.v);
      if (altNow < 65 && spd > 1.1) {
        const plasmaInt = clamp((st.ship.dynQ - 0.6) * 0.35 * (spd - 0.9), 0, 1);
        if (plasmaInt > 0.02) {
          const sScr = OC.projectRel(st.VIS.r);
          if (sScr) {
            const glowR = clamp(25 + plasmaInt * 45, 15, 80);
            const grad = ctx.createRadialGradient(sScr[0], sScr[1], 4, sScr[0], sScr[1], glowR);
            grad.addColorStop(0, `rgba(255, 240, 200, ${(plasmaInt * 0.65).toFixed(2)})`);
            grad.addColorStop(0.35, `rgba(255, 120, 30, ${(plasmaInt * 0.45).toFixed(2)})`);
            grad.addColorStop(0.75, `rgba(220, 40, 80, ${(plasmaInt * 0.20).toFixed(2)})`);
            grad.addColorStop(1, 'rgba(160, 20, 80, 0)');
            ctx.save();
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(sScr[0], sScr[1], glowR, 0, TAU);
            ctx.fill();
            ctx.restore();
          }
        }
      }
    }

    if (st.surfaceBeacon) {
      const bp = OC.beaconRelPos(st.surfaceBeacon, vt);
      if (dot(sub(bp, st.VIS.camRelP), bp) < 0) {
        const bScr = OC.projectRel(bp);
        if (bScr) {
          const pulse = 6 + 4 * Math.sin(nowMs * 0.008);
          ctx.strokeStyle = '#ff6699'; ctx.lineWidth = 1.6;
          ctx.beginPath(); ctx.arc(bScr[0], bScr[1], pulse, 0, TAU); ctx.stroke();
          ctx.fillStyle = '#ff99bb'; ctx.font = 'bold 11px ui-monospace, monospace';
          ctx.fillText(st.surfaceBeacon.label, bScr[0] + 10, bScr[1] + 4);
        }
      }
    }

    if (st.targetBody && !st.targetBody.isMoon && st.VIS.tgtRel) {
      const tScr = OC.projectRel(st.VIS.tgtRel);
      if (tScr && !OC.isOccludedRel(st.VIS.tgtRel)) {
        const d = len(sub(st.VIS.tgtRel, st.VIS.r));
        ctx.strokeStyle = '#ff6ec7'; ctx.lineWidth = 1.3;
        ctx.strokeRect(tScr[0] - 8, tScr[1] - 8, 16, 16);
        ctx.fillStyle = '#ff9be0'; ctx.font = 'bold 11px ui-monospace, monospace';
        ctx.fillText(`${st.targetBody.name} (${d.toFixed(1)} km)`, tScr[0] + 12, tScr[1] + 4);
      }
    }

    if (!st.crashed && st.dist > 1.5) {
      const rr = st.VIS.r, rv = st.VIS.v;
      const L = clamp(st.dist * 0.11, 0.2, 220);
      ctx.globalAlpha = 0.60;
      if (st.navRef === 'target' && st.VIS.tgtRel && st.VIS.tgtVelRel) {
        const relRt = sub(rr, st.VIS.tgtRel), relVt = sub(rv, st.VIS.tgtVelRel);
        drawArrowRel(ctx, rr, unit(relVt), L, '#ff77dd', 'T-PRO');
        drawArrowRel(ctx, rr, unit(mul(relRt, -1)), L, '#7ab8ff', 'TO-TGT');
      } else {
        drawArrowRel(ctx, rr, unit(rv), L, '#7aff9a', 'PRO');
        drawArrowRel(ctx, rr, unit(rr), L, '#7ab8ff', 'UP');
      }
      ctx.globalAlpha = 1;
    }

    drawParticlesRel(ctx);
    if (S.gizmo) OC.drawBall(ctx);
  }

  Object.assign(OC, { drawFlightView, drawArrowRel, drawParticlesRel });
})(window.OC);