'use strict';

(function (OC) {
  const { CONFIG, TAU, PAD_LON0, sub, len, add, mul, unit, cross, state: st } = OC;

  const SAVE_KEY = 'orbit_command_save_v2';
  let saveData = { stars: {}, bestTime: {} };
  try { const raw = localStorage.getItem(SAVE_KEY); if (raw) saveData = JSON.parse(raw); } catch {}
  const saveProgress = () => { try { localStorage.setItem(SAVE_KEY, JSON.stringify(saveData)); } catch {} };

  function createOrbitTarget(name, altKm, incDeg, phaseOffset) {
    const r0 = CONFIG.body.radius + altKm;
    const n = Math.sqrt(CONFIG.body.mu / (r0 * r0 * r0));
    const inc = incDeg * Math.PI / 180;
    return {
      name, isMoon: false,
      relPosAt(tt) {
        const a = n * tt + phaseOffset;
        return [r0 * Math.cos(a), r0 * Math.sin(a) * Math.cos(inc), r0 * Math.sin(a) * Math.sin(inc)];
      },
      relVelAt(tt) {
        const a = n * tt + phaseOffset, v = n * r0;
        return [-v * Math.sin(a), v * Math.cos(a) * Math.cos(inc), v * Math.cos(a) * Math.sin(inc)];
      }
    };
  }

  function beaconRelPos(b, tt) {
    const spin = tt * TAU / CONFIG.body.rotationPeriodS;
    const lat = b.latDeg * Math.PI / 180, lon = b.lonDeg * Math.PI / 180 + spin;
    const R = CONFIG.body.radius + 2;
    return [R * Math.cos(lat) * Math.cos(lon), R * Math.cos(lat) * Math.sin(lon), R * Math.sin(lat)];
  }

  const MISSIONS = [
    {
      id: 't1', num: 'T1', title: 'Pad Test: Suborbital Hop', tag: 'ROCKET TEST',
      desc: 'Launch from Kerbin Spaceport, break Mach 1, cross the 70 km Karman Line, and recover safely by parachute.',
      hint: 'Click LAUNCH (G) at 100% throttle. Cut engine (0) above 70 km; auto-chute opens on descent!',
      parTimeS: 540, parFuelFrac: 0.25,
      shipCfg: { onPad: true },
      setup() { return { mach1: false, space: false }; },
      update(ms) {
        const s = st.ship;
        if (s.mach >= 1.0) ms.mach1 = true;
        if (s.peakAltKm >= CONFIG.body.atmoKm) ms.space = true;
        const recovered = ms.space && s.landed;
        return {
          done: recovered,
          objs: [
            { text: `Liftoff & break Mach 1.0 (now M ${s.mach.toFixed(2)})`, ok: ms.mach1 },
            { text: `Cross 70 km Karman Line (peak ${s.peakAltKm.toFixed(1)} km)`, ok: ms.space },
            { text: `Safe parachute recovery (${s.landed ? 'LANDED' : s.chuteState > 0 ? 'CHUTE OPEN' : 'CHUTE ARMED'})`, ok: recovered }
          ]
        };
      }
    },
    {
      id: 't2', num: 'T2', title: 'Gravity Turn to Orbit', tag: 'PAD LAUNCH',
      desc: 'Launch from the Spaceport, pitch East into a gravity turn, separate Stage 1, and insert into an 80+ km orbit.',
      hint: 'Hit LAUNCH (G), pitch East with D/Right after liftoff, hit G to stage when Stage 1 empties, circularize at Ap!',
      parTimeS: 900, parFuelFrac: 0.20,
      shipCfg: { onPad: true },
      setup() { return { spaceAp: false }; },
      update(ms, dt, info) {
        const s = st.ship;
        if (info.apoapsisKm === null || info.apoapsisKm >= 80) ms.spaceAp = true;
        const staged = s.stage === 2;
        const inOrbit = info.periapsisKm !== null && info.periapsisKm >= 75 && info.apoapsisKm !== null && info.apoapsisKm >= 80;
        return {
          done: staged && inOrbit,
          objs: [
            { text: `Raise Apoapsis >= 80 km (${info.apoapsisKm?.toFixed(1) ?? 'esc'} km)`, ok: ms.spaceAp },
            { text: `Separate Stage 1 Booster (Stage ${s.stage}/2)`, ok: staged },
            { text: `Insert Orbit Pe >= 75 km (${info.periapsisKm?.toFixed(1) ?? 'n/a'} km)`, ok: inOrbit }
          ]
        };
      }
    },
    {
      id: 't3', num: 'T3', title: 'Pad-to-Selene Expedition', tag: 'LUNAR LAUNCH',
      desc: 'Launch from Kerbin Spaceport all the way to a lunar flyby within 600 km altitude of Selene.',
      hint: 'Reach ~85 km parking orbit first, open Map View (Tab), then burn Prograde when Selene is ahead!',
      parTimeS: 32000, parFuelFrac: 0.10,
      shipCfg: { onPad: true },
      setup() {
        st.targetBody = { name: 'SELENE', relPosAt: tt => OC.moonRelPos(tt), relVelAt: tt => OC.moonRelVel(tt), isMoon: true };
        return { orbited: false, tli: false, scan: 0 };
      },
      update(ms, dt, info) {
        if (info.periapsisKm !== null && info.periapsisKm >= 72) ms.orbited = true;
        if (info.apoapsisKm === null || info.apoapsisKm >= 10000) ms.tli = true;
        const mAlt = len(sub(st.ship.r, OC.moonRelPos(st.t))) - CONFIG.moon.radius;
        if (mAlt <= 600) ms.scan = Math.min(100, ms.scan + dt * 35);
        const done = ms.scan >= 100;
        return {
          done,
          objs: [
            { text: 'Reach parking orbit Pe >= 72 km', ok: ms.orbited },
            { text: 'Trans-Lunar Injection Ap >= 10,000 km', ok: ms.tli },
            { text: `Selene flyby < 600 km alt (${mAlt.toFixed(0)} km | ${ms.scan.toFixed(0)}%)`, ok: done }
          ]
        };
      }
    },
    {
      id: 'm1', num: 1, title: 'Orbit Calibration', tag: 'BASICS',
      desc: 'Stabilize an eccentric starting orbit into a clean 140–185 km circular band.',
      hint: 'Switch to Map View (Tab), use AP / PE warp, and burn PROGRADE (W) to circularize.',
      parTimeS: 2600, parFuelFrac: 0.72,
      shipCfg: { altKm: 85, incDeg: 10, vScale: 1.03, fuel: 1.8 },
      setup() { return { hold: 0 }; },
      update(ms, dt, info) {
        const apOk = info.apoapsisKm !== null && info.apoapsisKm >= 140 && info.apoapsisKm <= 185;
        const peOk = info.periapsisKm !== null && info.periapsisKm >= 135 && info.periapsisKm <= 185;
        const eOk = info.e <= 0.03;
        if (apOk && peOk && eOk) ms.hold += dt; else ms.hold = 0;
        const done = ms.hold >= 3;
        return {
          done,
          objs: [
            { text: `Apoapsis 140–185 km (${info.apoapsisKm?.toFixed(1) ?? 'esc'} km)`, ok: apOk },
            { text: `Periapsis 135–185 km (${info.periapsisKm?.toFixed(1) ?? 'n/a'} km)`, ok: peOk },
            { text: `Circularize e <= 0.03 & hold 3s (${ms.hold.toFixed(1)}s)`, ok: done }
          ]
        };
      }
    },
    {
      id: 'm2', num: 2, title: 'Polar Recon Scan', tag: 'INCLINATION',
      desc: 'Tilt into a high-inclination orbit and sweep over the northern research beacon.',
      hint: 'Burn NORMAL / ANTI-NORMAL (Q / E) near the equator, then pass within 240 km of the beacon.',
      parTimeS: 3400, parFuelFrac: 0.35,
      shipCfg: { altKm: 95, incDeg: 5, vScale: 1.0, fuel: 2.4 },
      setup() {
        st.surfaceBeacon = { latDeg: 62, lonDeg: 35, label: 'ALPHA BEACON' };
        return { scan: 0, incHit: false };
      },
      update(ms, dt, info) {
        if (info.incDeg >= 60 && info.incDeg <= 120) ms.incHit = true;
        const bp = beaconRelPos(st.surfaceBeacon, st.t);
        const d = len(sub(st.ship.r, bp));
        if (d <= 240) ms.scan = Math.min(100, ms.scan + dt * 28);
        const done = ms.incHit && ms.scan >= 100;
        return {
          done,
          objs: [
            { text: `Orbit inclination 60–120 deg (${info.incDeg.toFixed(1)} deg)`, ok: ms.incHit },
            { text: `Scan Alpha Beacon < 240 km (${d.toFixed(0)} km | ${ms.scan.toFixed(0)}%)`, ok: ms.scan >= 100 }
          ]
        };
      }
    },
    {
      id: 'm3', num: 3, title: 'Kestrel-4 Rescue', tag: 'RENDEZVOUS',
      desc: 'Rendezvous with stranded pod Kestrel-4. Approach within 14 km at low relative speed.',
      hint: 'Plan CPA in Map View (Tab), switch REF:TARGET (V), and burn RET (S) to match velocity.',
      parTimeS: 4500, parFuelFrac: 0.48,
      shipCfg: { altKm: 95, incDeg: 14, vScale: 1.0, phase: 0, fuel: 2.2 },
      setup() {
        st.targetBody = createOrbitTarget('KESTREL-4', 165, 14, 0.55);
        return { dockTimer: 0 };
      },
      update(ms, dt) {
        const tp = st.targetBody.relPosAt(st.t), tv = st.targetBody.relVelAt(st.t);
        const distKm = len(sub(st.ship.r, tp));
        const relSpd = len(sub(st.ship.v, tv));
        if (distKm <= 14 && relSpd <= 0.08) ms.dockTimer += dt; else ms.dockTimer = Math.max(0, ms.dockTimer - dt * 0.5);
        const done = ms.dockTimer >= 2.5;
        return {
          done,
          objs: [
            { text: `Approach Kestrel-4 < 14 km (${distKm.toFixed(1)} km)`, ok: distKm <= 14 },
            { text: `Match velocity < 0.08 km/s (${relSpd.toFixed(3)} km/s)`, ok: relSpd <= 0.08 && distKm <= 25 },
            { text: `Hold dock 2.5s (${ms.dockTimer.toFixed(1)}s)`, ok: done }
          ]
        };
      }
    },
    {
      id: 'm4', num: 4, title: 'Synchronous Relay', tag: 'PRECISION',
      desc: 'Deploy a stationary comms relay with an orbital period matching the 360.0 min Kerbin day.',
      hint: 'Synchronous altitude is ~2,868.8 km. Use Map View + 1000x warp + AP/PE helpers!',
      parTimeS: 16000, parFuelFrac: 0.50,
      shipCfg: { altKm: 1900, incDeg: 2, vScale: 1.0, fuel: 1.8 },
      setup() { return { hold: 0 }; },
      update(ms, dt, info) {
        const perMin = info.periodS ? info.periodS / 60 : 9999;
        const perOk = Math.abs(perMin - 360.0) <= 6.0;
        const eOk = info.e <= 0.04;
        if (perOk && eOk) ms.hold += dt; else ms.hold = 0;
        const done = ms.hold >= 3;
        return {
          done,
          objs: [
            { text: `Orbital period 360 +/- 6 min (${perMin < 5000 ? perMin.toFixed(1) : 'n/a'} min)`, ok: perOk },
            { text: `Eccentricity <= 0.04 (${info.e.toFixed(3)})`, ok: eOk },
            { text: `Station-keep 3s (${ms.hold.toFixed(1)}s)`, ok: done }
          ]
        };
      }
    },
    {
      id: 'm5', num: 5, title: 'Project Selene', tag: 'LUNAR FLYBY',
      desc: 'Perform a trans-lunar injection to Selene at 12,000 km and fly within 600 km altitude.',
      hint: 'Open Map View (Tab), burn PROGRADE until Apoapsis reaches ~11,500 km and SOI ENTRY appears!',
      parTimeS: 32000, parFuelFrac: 0.30,
      shipCfg: { altKm: 100, incDeg: 0, vScale: 1.0, phase: -0.9, fuel: 2.8 },
      setup() {
        st.targetBody = { name: 'SELENE', relPosAt: tt => OC.moonRelPos(tt), relVelAt: tt => OC.moonRelVel(tt), isMoon: true };
        return { apHit: false, scan: 0 };
      },
      update(ms, dt, info) {
        if (info.apoapsisKm === null || info.apoapsisKm >= 10000) ms.apHit = true;
        const mAlt = len(sub(st.ship.r, OC.moonRelPos(st.t))) - CONFIG.moon.radius;
        if (mAlt <= 600) ms.scan = Math.min(100, ms.scan + dt * 35);
        const done = ms.scan >= 100;
        return {
          done,
          objs: [
            { text: 'Raise Apoapsis >= 10,000 km', ok: ms.apHit },
            { text: `Selene flyby < 600 km alt (${mAlt.toFixed(0)} km | ${ms.scan.toFixed(0)}%)`, ok: done }
          ]
        };
      }
    },
    {
      id: 'm6', num: 6, title: 'Aerobrake Skim', tag: 'ATMOSPHERE',
      desc: 'Use upper-atmosphere drag below 70 km to shrink a high orbit without burning all fuel.',
      hint: 'Starting at Ap 750 km / Pe 109 km: dip Pe to ~34-42 km, let drag slow you, then raise Pe >= 75 km.',
      parTimeS: 5200, parFuelFrac: 0.65,
      shipCfg: { altKm: 750, incDeg: 12, vScale: 0.83, phase: 0, fuel: 1.2 },
      setup() { return { skimmed: false }; },
      update(ms, dt, info) {
        if (info.altKm < CONFIG.body.atmoKm && info.altKm > 1) ms.skimmed = true;
        const recovered = ms.skimmed && info.periapsisKm !== null && info.periapsisKm >= 75 && info.apoapsisKm !== null && info.apoapsisKm <= 480;
        return {
          done: recovered,
          objs: [
            { text: `Skim atmosphere < ${CONFIG.body.atmoKm} km alt (now ${info.altKm.toFixed(1)} km)`, ok: ms.skimmed },
            { text: 'Re-stabilize Pe >= 75 km & Ap <= 480 km', ok: recovered }
          ]
        };
      }
    },
    {
      id: 'm7', num: 7, title: 'Voyager Escape', tag: 'DEEP SPACE',
      desc: 'Break free of planetary gravity and transmit deep-space data past 5,000 km altitude.',
      hint: 'Burn PROGRADE near Periapsis until eccentricity exceeds 1.02!',
      parTimeS: 6000, parFuelFrac: 0.15,
      shipCfg: { altKm: 90, incDeg: 5, vScale: 1.0, fuel: 3.0 },
      setup() { return {}; },
      update(ms, dt, info) {
        const esc = info.e >= 1.02;
        const far = info.altKm >= 5000;
        return {
          done: esc && far,
          objs: [
            { text: `Achieve escape eccentricity >= 1.02 (${info.e.toFixed(3)})`, ok: esc },
            { text: `Reach 5,000 km altitude (${info.altKm.toFixed(0)} km)`, ok: far }
          ]
        };
      }
    },
    {
      id: 'sandbox', num: '∞', title: 'Free Sandbox', tag: 'OPEN TEST',
      desc: 'Unrestricted rocket testpad & orbital sandbox. Launch from Spaceport or jump straight to orbit.',
      hint: 'Press G to launch from the pad, Tab for Map View, or open TOOLS for instant orbital setups.',
      parTimeS: 99999, parFuelFrac: 0,
      shipCfg: { onPad: true },
      setup() { return {}; },
      update() {
        const s = st.ship;
        const phase = s.onPad ? 'PRELAUNCH PAD' : s.landed ? 'LANDED' : s.chuteState > 0 ? 'PARACHUTE DESCENT' : 'FREE FLIGHT';
        return { done: false, objs: [{ text: `${phase} | Peak Alt ${s.peakAltKm.toFixed(1)} km | Max-Q ${s.peakMaxQ.toFixed(1)} kPa`, ok: false }] };
      }
    }
  ];

  function startMission(idx) {
    st.currentMissionIdx = idx;
    st.selectedMissionIdx = idx;
    const m = MISSIONS[idx];
    st.t = 0; st.accum = 0; st.particles = [];
    st.crashed = false; st.paused = false; st.missionDone = false;
    st.warpIdx = 0; st.autoWarp = null; st.prevDoneCount = 0; st.lowFuelWarned = false;
    st.targetBody = null; st.surfaceBeacon = null; st.navRef = 'orbit';
    st.ship = OC.makeShip(m.shipCfg);
    st.missionState = m.setup ? m.setup() : {};
    st.missionStatus = m.update(st.missionState, 0, OC.orbitInfo(OC.relR(), OC.relV()));

    const onPad = !!m.shipCfg.onPad;
    st.viewCameras.flight = {
      mode: 'ship', yaw: onPad ? PAD_LON0 + 1.32 : 0.45, pitch: onPad ? 0.12 : 0.25,
      dist: onPad ? CONFIG.view.padStartDistKm : CONFIG.view.flightStartDistKm, panOff: [0, 0, 0], freePivot: [0, 0, 0]
    };
    st.viewCameras.map = {
      mode: 'ship', yaw: onPad ? PAD_LON0 + 0.4 : 0.40, pitch: 0.55, dist: CONFIG.view.mapStartDistKm, panOff: [0, 0, 0], freePivot: [0, 0, 0]
    };
    const camCfg = st.viewCameras[st.viewMode];
    st.mode = camCfg.mode; st.yaw = camCfg.yaw; st.pitch = camCfg.pitch; st.dist = camCfg.dist;
    st.panOff = [...camCfg.panOff]; st.freePivot = [...camCfg.freePivot];

    OC.predCache.dirty = true;
    OC.syncNavRefBtn();
    OC.syncViewBtn();
    OC.syncSasBtns();
    OC.setThrottle(1);
    document.getElementById('btnSandboxTools').classList.toggle('hidden', m.id !== 'sandbox');
    document.getElementById('btnCam').textContent = 'CAM:' + st.mode.toUpperCase();
    document.getElementById('missionModal').classList.add('hidden');
    document.getElementById('resultModal').classList.add('hidden');
    OC.renderWarpBtns();
    OC.initMissionHudDom();
    OC.updateVisualSnapshot();
    OC.showToast(`${m.num}: ${m.title}`);
    OC.SFX.beep(580, 0.12, 'triangle', 0.08);
  }

  function resetMission() { startMission(st.currentMissionIdx); }

  function completeMission() {
    if (st.missionDone) return;
    st.missionDone = true; st.paused = true; st.autoWarp = null;
    OC.SFX.setThrust(0); OC.SFX.fanfare();
    OC.updateMissionHud(true);
    const m = MISSIONS[st.currentMissionIdx];
    const s = st.ship;
    const fuelFrac = OC.activeFuel(s) / Math.max(0.001, OC.activeMaxFuel(s));
    let stars = 1;
    if (fuelFrac >= m.parFuelFrac * 0.7 || st.t <= m.parTimeS * 1.2) stars = 2;
    if (fuelFrac >= m.parFuelFrac && st.t <= m.parTimeS) stars = 3;
    saveData.stars[m.id] = Math.max(saveData.stars[m.id] || 0, stars);
    if (!saveData.bestTime[m.id] || st.t < saveData.bestTime[m.id]) saveData.bestTime[m.id] = st.t;
    saveProgress();

    document.getElementById('resTitle').textContent = `MISSION COMPLETE — ${m.title}`;
    document.getElementById('resTitle').style.color = '#6eff9e';
    document.getElementById('resStars').innerHTML = '★'.repeat(stars) + `<span class="dim">${'★'.repeat(3 - stars)}</span>`;
    document.getElementById('resDesc').textContent = 'Flight test report verified by Mission Control.';
    document.getElementById('resStats').textContent = [
      `Mission Time  : ${(st.t / 60).toFixed(1)} min  (Par ${(m.parTimeS / 60).toFixed(1)} min)`,
      `Peak Altitude : ${s.peakAltKm.toFixed(1)} km   | Max Speed : ${s.peakSpd.toFixed(2)} km/s`,
      `Peak Max-Q    : ${s.peakMaxQ.toFixed(1)} kPa   | Peak G    : ${s.peakG.toFixed(1)} G`,
      `Downrange     : ${s.downrangeKm.toFixed(1)} km | Delta-V   : ${OC.remainingDv().toFixed(2)} km/s`
    ].join('\n');
    document.getElementById('resNextBtn').classList.toggle('hidden', st.currentMissionIdx >= MISSIONS.length - 1);
    document.getElementById('resultModal').classList.remove('hidden');
  }

  function triggerCrash(bodyName, spdMs = null) {
    if (st.crashed) return;
    st.crashed = true; st.paused = true; st.autoWarp = null;
    st.screenShake = 0.45;
    OC.SFX.setThrust(0); OC.SFX.crash();

    const r0 = st.ship.r, v0 = st.ship.v;
    // 1. High-velocity fireball detonation
    for (let i = 0; i < 55; i++) {
      const a = Math.random() * TAU, z = Math.random() * 2 - 1, s = Math.sqrt(1 - z * z);
      const blastSpd = 0.008 + Math.random() * 0.045;
      st.particles.push({
        p: [r0[0], r0[1], r0[2]],
        v: add(v0, [s * Math.cos(a) * blastSpd, s * Math.sin(a) * blastSpd, z * blastSpd]),
        life: 0.9 + Math.random() * 0.5,
        col: Math.random() < 0.35 ? '#ffffff' : (Math.random() < 0.7 ? '#ff9922' : '#ff4411'),
        size: 3.5 + Math.random() * 4.5
      });
    }

    // 2. Ground shockwave ring
    const up = unit(r0);
    let ref = Math.abs(up[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0];
    const e1 = unit(cross(ref, up)), e2 = cross(up, e1);
    for (let i = 0; i < 32; i++) {
      const th = (i / 32) * TAU;
      const ringVel = add(mul(e1, Math.cos(th) * 0.025), mul(e2, Math.sin(th) * 0.025));
      st.particles.push({
        p: [r0[0], r0[1], r0[2]],
        v: add(v0, ringVel),
        life: 0.75 + Math.random() * 0.3,
        col: '#ffddaa',
        size: 3.0
      });
    }

    // 3. Dark rising smoke plume puffs
    for (let i = 0; i < 22; i++) {
      const puff = [
        up[0] * (0.005 + Math.random() * 0.015) + (Math.random() - 0.5) * 0.01,
        up[1] * (0.005 + Math.random() * 0.015) + (Math.random() - 0.5) * 0.01,
        up[2] * (0.005 + Math.random() * 0.015) + (Math.random() - 0.5) * 0.01
      ];
      st.particles.push({
        p: [r0[0], r0[1], r0[2]],
        v: add(v0, puff),
        life: 1.2 + Math.random() * 0.8,
        col: Math.random() < 0.5 ? '#555b63' : '#33373d',
        size: 4.5 + Math.random() * 4.0
      });
    }

    const m = MISSIONS[st.currentMissionIdx], s = st.ship;
    document.getElementById('resTitle').textContent = `LOSS OF SIGNAL — ${bodyName} IMPACT`;
    document.getElementById('resTitle').style.color = '#ff6b7a';
    document.getElementById('resStars').innerHTML = '';
    const spdStr = spdMs ? ` (${spdMs} m/s)` : '';
    document.getElementById('resDesc').textContent = `Craft impacted ${bodyName}${spdStr} too violently. Deploy parachutes (< 10 km) or perform a retrograde landing burn!`;
    document.getElementById('resStats').textContent = `Mission: ${m.title}\nPeak Alt: ${s.peakAltKm.toFixed(1)} km | Max-Q: ${s.peakMaxQ.toFixed(1)} kPa`;
    document.getElementById('resNextBtn').classList.add('hidden');
    setTimeout(() => { if (st.crashed) document.getElementById('resultModal').classList.remove('hidden'); }, 700);
  }

  function renderMissionGrid() {
    const grid = document.getElementById('missionGrid');
    grid.innerHTML = '';
    let earned = 0, maxStars = 0;
    MISSIONS.forEach((m, i) => {
      if (m.id !== 'sandbox') { earned += saveData.stars[m.id] || 0; maxStars += 3; }
      const stars = saveData.stars[m.id] || 0;
      const card = document.createElement('div');
      card.className = 'm-card' + (i === st.selectedMissionIdx ? ' selected' : '');
      const starHtml = m.id === 'sandbox' ? '<span class="badge">SANDBOX</span>' :
        `<span class="stars">${'★'.repeat(stars)}<span class="dim">${'★'.repeat(3 - stars)}</span></span>`;
      const prefix = typeof m.num === 'number' ? 'M' + m.num + ' · ' : m.num + ' · ';
      card.innerHTML = [
        `<div style="display:flex;justify-content:space-between;align-items:center;">`,
        `<span class="badge ${stars > 0 ? 'ok' : ''}">${prefix}${m.tag}</span>`,
        starHtml,
        `</div>`,
        `<div style="font-weight:bold;color:#fff;">${m.title}</div>`,
        `<div style="font-size:11.5px;opacity:.75;">${m.desc}</div>`
      ].join('');
      card.onclick = () => { st.selectedMissionIdx = i; renderMissionGrid(); };
      card.ondblclick = () => startMission(i);
      grid.appendChild(card);
    });
    document.getElementById('totalStarsBox').innerHTML = `Campaign Stars<br><span class="stars">${earned} / ${maxStars} ★</span>`;
    const sel = MISSIONS[st.selectedMissionIdx];
    const bt = saveData.bestTime[sel.id];
    document.getElementById('missionBrief').innerHTML =
      `<b>${sel.title}</b> — ${sel.desc}<br><span style="color:#8dc2ff;">Flight Tip:</span> ${sel.hint}` +
      (bt ? `<br><span style="color:#6eff9e;font-size:11.5px;">Best Time: ${(bt / 60).toFixed(1)} min</span>` : '');
  }

  function openMissionModal(allowClose = true) {
    st.paused = true; st.autoWarp = null; st.keys.clear(); st.uiThrust.clear(); OC.SFX.setThrust(0);
    document.getElementById('closeMissions').classList.toggle('hidden', !allowClose);
    renderMissionGrid();
    document.getElementById('missionModal').classList.remove('hidden');
  }

  Object.assign(OC, {
    MISSIONS, saveData, saveProgress, createOrbitTarget, beaconRelPos,
    startMission, resetMission, completeMission, triggerCrash, renderMissionGrid, openMissionModal
  });
})(window.OC);