'use strict';

(function (OC) {
  const { TAU, cross, unit } = OC;

  function createMeshBuilder() {
    const verts = [];
    const idx = [];

    function pushVert(x, y, z, nx, ny, nz, col) {
      verts.push(x, y, z, nx, ny, nz, col[0], col[1], col[2]);
      return (verts.length / 9) - 1;
    }

    function addTri(a, b, c, col) {
      const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
      const vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
      const n = unit(cross([ux, uy, uz], [vx, vy, vz]));
      const i0 = pushVert(a[0], a[1], a[2], n[0], n[1], n[2], col);
      const i1 = pushVert(b[0], b[1], b[2], n[0], n[1], n[2], col);
      const i2 = pushVert(c[0], c[1], c[2], n[0], n[1], n[2], col);
      idx.push(i0, i1, i2);
    }

    function addQuad(a, b, c, d, col) {
      addTri(a, b, c, col);
      addTri(a, c, d, col);
    }

    function addBox(cx, cy, cz, sx, sy, sz, col) {
      const x0 = cx - sx * 0.5, x1 = cx + sx * 0.5;
      const y0 = cy - sy * 0.5, y1 = cy + sy * 0.5;
      const z0 = cz - sz * 0.5, z1 = cz + sz * 0.5;
      addQuad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], col);
      addQuad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], col);
      addQuad([x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1], col);
      addQuad([x0, y1, z0], [x0, y0, z0], [x0, y0, z1], [x0, y1, z1], col);
      addQuad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], col);
      addQuad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], col);
    }

    function addFrustum(z0, z1, r0, r1, segs, colFn, cap0 = true, cap1 = true) {
      const dz = z1 - z0, dr = r0 - r1;
      const sl = Math.hypot(dz, dr);
      const nz = sl > 1e-9 ? dr / sl : 0, nr = sl > 1e-9 ? dz / sl : 1;

      for (let i = 0; i < segs; i++) {
        const a0 = i / segs * TAU, a1 = (i + 1) / segs * TAU;
        const c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
        const col = typeof colFn === 'function' ? colFn(i, segs) : colFn;
        const v0 = pushVert(r0 * c0, r0 * s0, z0, nr * c0, nr * s0, nz, col);
        const v1 = pushVert(r0 * c1, r0 * s1, z0, nr * c1, nr * s1, nz, col);
        const v2 = pushVert(r1 * c1, r1 * s1, z1, nr * c1, nr * s1, nz, col);
        const v3 = pushVert(r1 * c0, r1 * s0, z1, nr * c0, nr * s0, nz, col);
        idx.push(v0, v1, v2, v0, v2, v3);

        if (cap0 && r0 > 1e-6) {
          const b0 = pushVert(0, 0, z0, 0, 0, -1, col);
          const b1 = pushVert(r0 * c1, r0 * s1, z0, 0, 0, -1, col);
          const b2 = pushVert(r0 * c0, r0 * s0, z0, 0, 0, -1, col);
          idx.push(b0, b1, b2);
        }
        if (cap1 && r1 > 1e-6) {
          const t0 = pushVert(0, 0, z1, 0, 0, 1, col);
          const t1 = pushVert(r1 * c0, r1 * s0, z1, 0, 0, 1, col);
          const t2 = pushVert(r1 * c1, r1 * s1, z1, 0, 0, 1, col);
          idx.push(t0, t1, t2);
        }
      }
    }

    function addFin(ang, rBase, zBase, chord, span, thick, col) {
      const ca = Math.cos(ang), sa = Math.sin(ang);
      const rot = (x, y, z) => [x * ca - y * sa, x * sa + y * ca, z];
      const ht = thick * 0.5;
      const pA = rot(rBase, -ht, zBase), pB = rot(rBase + span, -ht * 0.4, zBase);
      const pC = rot(rBase + span * 0.55, -ht * 0.4, zBase + chord * 0.45), pD = rot(rBase, -ht, zBase + chord);
      const qA = rot(rBase, ht, zBase), qB = rot(rBase + span, ht * 0.4, zBase);
      const qC = rot(rBase + span * 0.55, ht * 0.4, zBase + chord * 0.45), qD = rot(rBase, ht, zBase + chord);
      addQuad(pA, pB, pC, pD, col);
      addQuad(qD, qC, qB, qA, col);
      addQuad(pB, qB, qC, pC, col);
      addQuad(pC, qC, qD, pD, col);
      addQuad(pA, qA, qB, pB, col);
    }

    function build() {
      return { verts: new Float32Array(verts), idx: new Uint16Array(idx), count: idx.length };
    }

    return { addTri, addQuad, addBox, addFrustum, addFin, build };
  }

  function buildAllMeshes() {
    // 1. Stage 1 Heavy Booster
    const s1 = createMeshBuilder();
    s1.addFrustum(0.0000, 0.0028, 0.00145, 0.00075, 14, [0.22, 0.25, 0.30]);
    s1.addFrustum(0.0028, 0.0046, 0.00175, 0.00160, 16, [0.34, 0.38, 0.44]);
    s1.addFrustum(0.0046, 0.0085, 0.00160, 0.00160, 16, [0.92, 0.94, 0.97]);
    s1.addFrustum(0.0085, 0.0110, 0.00161, 0.00161, 16, i => (i % 2 === 0 ? [0.95, 0.45, 0.12] : [0.12, 0.14, 0.18]), false, false);
    s1.addFrustum(0.0110, 0.0195, 0.00160, 0.00160, 16, [0.92, 0.94, 0.97]);
    s1.addFrustum(0.0195, 0.0218, 0.00165, 0.00142, 16, [0.28, 0.32, 0.38]);
    for (let k = 0; k < 4; k++) s1.addFin(k * Math.PI * 0.5, 0.00155, 0.0032, 0.0062, 0.0022, 0.00025, k % 2 === 0 ? [0.92, 0.44, 0.12] : [0.20, 0.24, 0.30]);

    // 2. Stage 2 Orbital Core (Kestrel-V)
    const s2 = createMeshBuilder();
    s2.addFrustum(0.0000, 0.0022, 0.00105, 0.00050, 14, [0.26, 0.29, 0.35]);
    s2.addFrustum(0.0022, 0.0052, 0.00135, 0.00135, 16, [0.84, 0.64, 0.18]);
    s2.addFrustum(0.0052, 0.0092, 0.00135, 0.00135, 16, [0.93, 0.95, 0.98]);
    s2.addFrustum(0.0092, 0.0098, 0.00144, 0.00144, 16, [0.16, 0.18, 0.22]);
    s2.addFrustum(0.0098, 0.0132, 0.00138, 0.00055, 16, [0.90, 0.93, 0.97]);
    s2.addBox(0.00095, 0.0, 0.0114, 0.00045, 0.00065, 0.00075, [0.08, 0.20, 0.36]);
    s2.addFrustum(0.0132, 0.0150, 0.00045, 0.00010, 10, [0.75, 0.80, 0.88]);

    // 3. Deployable Solar Wings
    const wings = createMeshBuilder();
    wings.addBox(0,  0.0044, 0.0068, 0.00014, 0.0056, 0.0022, [0.10, 0.28, 0.64]);
    wings.addBox(0, -0.0044, 0.0068, 0.00014, 0.0056, 0.0022, [0.10, 0.28, 0.64]);
    wings.addBox(0,  0.0015, 0.0068, 0.00024, 0.0007, 0.0003, [0.72, 0.78, 0.85]);
    wings.addBox(0, -0.0015, 0.0068, 0.00024, 0.0007, 0.0003, [0.72, 0.78, 0.85]);

    // 4. Exhaust Plumes (Atmospheric columnar jet with shock diamonds & Expanding Vacuum Bell)
    const plume = createMeshBuilder();
    plume.addFrustum(-0.018, 0.000, 0.0001, 0.0014, 12, [1.0, 0.52, 0.12], false, false);
    plume.addFrustum(-0.009, 0.000, 0.0001, 0.0008, 10, [1.0, 0.88, 0.45], false, false);
    // Shock diamond inner flame
    plume.addFrustum(-0.004, -0.001, 0.0003, 0.0006, 8, [1.0, 0.98, 0.92], false, false);

    const plumeVac = createMeshBuilder();
    // Expanding supersonic vacuum bell with violet/cyan luminescence
    plumeVac.addFrustum(-0.026, 0.000, 0.0046, 0.0009, 14, [0.38, 0.65, 1.0], false, false);
    plumeVac.addFrustum(-0.015, 0.000, 0.0022, 0.0007, 12, [0.75, 0.48, 0.96], false, false);
    plumeVac.addFrustum(-0.008, 0.000, 0.0009, 0.0005, 10, [1.0, 0.96, 0.85], false, false);

    // 5. Parachute Canopy & Risers
    const chute = createMeshBuilder();
    const cSegs = 14, cZ0 = 0.025, cH = 0.0065, cR = 0.0075;
    for (let i = 0; i < cSegs; i++) {
      const a0 = i / cSegs * TAU, a1 = (i + 1) / cSegs * TAU;
      const col = i % 2 === 0 ? [0.95, 0.42, 0.12] : [0.96, 0.97, 0.99];
      const p0 = [cR * Math.cos(a0), cR * Math.sin(a0), cZ0];
      const p1 = [cR * Math.cos(a1), cR * Math.sin(a1), cZ0];
      const p2 = [cR * 0.55 * Math.cos(a1), cR * 0.55 * Math.sin(a1), cZ0 + cH * 0.65];
      const p3 = [cR * 0.55 * Math.cos(a0), cR * 0.55 * Math.sin(a0), cZ0 + cH * 0.65];
      chute.addQuad(p0, p1, p2, p3, col);
      chute.addTri(p3, p2, [0, 0, cZ0 + cH], col);
      if (i % 2 === 0) chute.addTri([0, 0, 0.014], p0, [p0[0] * 0.95, p0[1] * 0.95, p0[2] + 0.0004], [0.78, 0.82, 0.88]);
    }

    // 6. Concrete Spaceport Launch Complex (deep foundation embedded directly into 3D terrain plateau)
    const pad = createMeshBuilder();
    pad.addFrustum(-0.0024, 0.0004, 0.028, 0.024, 8, [0.36, 0.38, 0.41]); // Concrete apron skirt
    pad.addFrustum(0.0004, 0.0011, 0.016, 0.013, 8, [0.54, 0.56, 0.60]);  // Octagonal launch deck
    pad.addBox(0, 0, 0.0009, 0.019, 0.006, 0.0008, [0.14, 0.15, 0.17]);     // Flame trench
    pad.addBox(0.045, 0, -0.0009, 0.11, 0.014, 0.0026, [0.38, 0.40, 0.44]); // East crawlerway embedded into terrain
    pad.addBox(-0.019, -0.018, 0.0030, 0.0055, 0.0055, 0.008, [0.90, 0.92, 0.95]); // LOX tank 1
    pad.addBox(-0.019,  0.018, 0.0030, 0.0060, 0.0060, 0.008, [0.75, 0.78, 0.82]); // Fuel tank 2
    for (let t = 0; t < 6; t++) {
      const z0 = (t === 0 ? -0.001 : 0.001 + t * 0.007), hSeg = t === 0 ? 0.009 : 0.0068;
      const col = t % 2 === 0 ? [0.85, 0.22, 0.16] : [0.92, 0.94, 0.97];
      pad.addBox(-0.011, 0, z0 + hSeg * 0.5, 0.0045, 0.0045, hSeg, col);
    }
    pad.addBox(-0.0055, 0, 0.025, 0.009, 0.0014, 0.0012, [0.75, 0.78, 0.82]); // Swing arm
    pad.addBox(-0.011, 0, 0.046, 0.0008, 0.0008, 0.006, [0.85, 0.88, 0.92]);  // Lightning mast

    // 7. 3D Target Pod
    const tgt = createMeshBuilder();
    tgt.addFrustum(-0.0025, 0.0025, 0.0012, 0.0012, 12, [0.88, 0.66, 0.20]);
    tgt.addFrustum(0.0025, 0.0045, 0.0012, 0.0004, 12, [0.90, 0.93, 0.97]);
    tgt.addBox(0,  0.0040, 0, 0.00014, 0.0050, 0.0018, [0.12, 0.30, 0.68]);
    tgt.addBox(0, -0.0040, 0, 0.00014, 0.0050, 0.0018, [0.12, 0.30, 0.68]);

    return {
      stage1: s1.build(), stage2: s2.build(), solarWings: wings.build(),
      plume: plume.build(), plumeVac: plumeVac.build(), chute: chute.build(), pad: pad.build(), targetSat: tgt.build()
    };
  }

  OC.buildAllMeshes = buildAllMeshes;
})(window.OC);