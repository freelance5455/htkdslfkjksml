# Orbit Command – Android

The game (with touch UI) is already in `app/src/main/assets/www`. The app is a fullscreen WebView, landscape, Back button = in-game menu.

## Option A – Android Studio (easiest)
1. Install Android Studio, choose **Open** and select this folder, let Gradle sync.
2. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. APK: `app/build/outputs/apk/debug/app-debug.apk` – copy to the phone and install (allow "unknown sources").

## Option B – command line (needs JDK 17 + Android SDK, ANDROID_HOME set)
    gradle assembleDebug          # or run `gradle wrapper` once, then ./gradlew assembleDebug

## Option C – no install: GitHub Actions
Push this folder to a GitHub repo; the "Build APK" workflow produces the APK under Actions > Artifacts.

## Updating the game
Edit the web game, then `./sync-web.sh path/to/orbit-command` and rebuild.
For a Play Store release use a signed release build (Build > Generate Signed Bundle).
