const $=id=>document.getElementById(id);
const screens=[...document.querySelectorAll('.screen')], navs=[...document.querySelectorAll('.nav')];
let history=[],busy=false,persona='assistant',ttsOn=false;
const personaNames={assistant:'TOWSIF AI · Assistant',study:'Study Mode',creative:'Creative Mode',tech:'Tech Pro Mode'};
function go(tab){screens.forEach(s=>s.classList.toggle('active',s.id===tab));navs.forEach(n=>n.classList.toggle('active',n.dataset.tab===tab));window.scrollTo({top:0,behavior:'smooth'});}
navs.forEach(n=>n.addEventListener('click',()=>go(n.dataset.tab)));
document.querySelectorAll('[data-open]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.open)));
$('topSettings').addEventListener('click',()=>go('settings'));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>{go(b.dataset.go);if(b.dataset.prompt)sendMessage(b.dataset.prompt)}));

function addMessage(role,text,error=false){const box=document.createElement('div');box.className='msg '+(role==='user'?'user':'ai');if(error)box.style.borderColor='#df91a8';const who=document.createElement('div');who.className='who';who.textContent=role==='user'?'তুমি':error?'সমস্যা':'TOWSIF AI';const body=document.createElement('div');body.textContent=text;box.append(who,body);$('messages').append(box);box.scrollIntoView({behavior:'smooth',block:'end'});return box;}
function setBusy(v){busy=v;$('send').disabled=v;$('input').disabled=v;$('send').textContent=v?'Thinking…':'Send ↑';}
async function sendMessage(raw){const text=raw.trim();if(!text||busy)return;go('chat');addMessage('user',text);history.push({role:'user',text});history=history.slice(-20);$('input').value='';$('input').style.height='auto';setBusy(true);const wait=addMessage('model','TOWSIF AI উত্তর তৈরি করছে…');
try{const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:history,persona,language:$('language')?.value||'auto',memory:localStorage.getItem('towsif-memory')||''})});const data=await r.json().catch(()=>({}));wait.remove();if(!r.ok)throw Error(data.error||'অনুরোধ ব্যর্থ হয়েছে।');addMessage('model',data.answer);history.push({role:'model',text:data.answer});history=history.slice(-20);localStorage.setItem('towsif-chat',JSON.stringify(history));if(ttsOn&&'speechSynthesis'in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(data.answer);u.lang=( $('language').value==='en'?'en-US':'bn-BD');speechSynthesis.speak(u)}}catch(e){wait.remove();addMessage('model',e.message||'নেটওয়ার্ক সমস্যা হয়েছে।',true);history.pop()}finally{setBusy(false)}}
$('send').addEventListener('click',()=>sendMessage($('input').value));
$('input').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage($('input').value)}});
$('input').addEventListener('input',()=>{$('input').style.height='auto';$('input').style.height=Math.min($('input').scrollHeight,130)+'px'});
function newChat(){if(busy)return;history=[];$('messages').replaceChildren();addMessage('model','নতুন চ্যাট শুরু হয়েছে। কীভাবে সাহায্য করব?');localStorage.removeItem('towsif-chat');}
$('newChat').addEventListener('click',newChat);
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){$('voiceSupport').textContent='Supported';$('voice').addEventListener('click',()=>{const rec=new SR();rec.lang=$('language').value==='en'?'en-US':'bn-BD';rec.interimResults=false;rec.maxAlternatives=1;$('hint').textContent='শুনছি… কথা বলো';$('voice').disabled=true;rec.onresult=e=>{$('input').value=e.results[0][0].transcript;$('input').dispatchEvent(new Event('input'));$('hint').textContent='কথা শনাক্ত হয়েছে'};rec.onerror=()=>{$('hint').textContent='মাইক্রোফোন অনুমতি ও নেটওয়ার্ক পরীক্ষা করো'};rec.onend=()=>{$('voice').disabled=false};try{rec.start()}catch(e){$('voice').disabled=false;$('hint').textContent='Voice start করা যায়নি'}})}else{$('voiceSupport').textContent='Not supported';$('voice').disabled=true;$('voice').title='এই ব্রাউজারে voice input নেই'}
$('ttsToggle').addEventListener('change',e=>{ttsOn=e.target.checked;if(!ttsOn&&'speechSynthesis'in window)speechSynthesis.cancel()});
$('speakToggle').addEventListener('click',()=>{ttsOn=!ttsOn;$('ttsToggle').checked=ttsOn;$('speakToggle').textContent=ttsOn?'🔊 On':'🔊';$('hint').textContent=ttsOn?'AI replies will be read aloud':'Reply voice is off'});
function updatePersonaUI(){document.querySelectorAll('.persona').forEach(l=>{const r=l.querySelector('input');l.classList.toggle('selected',r.value===persona);r.checked=r.value===persona});$('activePersonaName').textContent=personaNames[persona]}
document.querySelectorAll('input[name="persona"]').forEach(r=>r.addEventListener('change',()=>{persona=r.value;updatePersonaUI()}));
$('activatePersona').addEventListener('click',()=>{persona=document.querySelector('input[name="persona"]:checked').value;updatePersonaUI();go('chat');$('hint').textContent=personaNames[persona]+' activated'});
$('saveMemory').addEventListener('click',()=>{localStorage.setItem('towsif-memory',$('memory').value.trim());$('memoryStatus').textContent=' · Saved on this device';});
$('memory').value=localStorage.getItem('towsif-memory')||'';
async function checkApi(){ $('apiStatus').textContent='Checking…';try{const r=await fetch('/api/health');const d=await r.json();$('apiStatus').textContent=d.configured?'Connected':'API key missing';$('modelName').textContent=d.configured?d.model+' · Server configured':'Render Environment-এ GEMINI_API_KEY যোগ করো';$('status').innerHTML='<i class="dot"></i><span>'+(d.configured?'AI READY':'API KEY NEEDED')+'</span>';$('dailyTitle').textContent=d.configured?'Live Assistant · Ready to chat':'AI setup needed';$('dailyText').textContent=d.configured?'AI server is configured':'API key সেট না করলে AI উত্তর দেবে না'}catch(e){$('apiStatus').textContent='Offline';$('modelName').textContent='সার্ভারের সঙ্গে যোগাযোগ হয়নি';$('status').innerHTML='<span>SERVER OFFLINE</span>'}}
$('checkApi').addEventListener('click',checkApi);
$('clearLocal').addEventListener('click',()=>{if(confirm('এই ব্রাউজারের saved chat ও memory note মুছে ফেলবে?')){localStorage.removeItem('towsif-memory');localStorage.removeItem('towsif-chat');$('memory').value='';$('memoryStatus').textContent=' Cleared';newChat()}});
function clock(){const d=new Date();$('clock').textContent=d.toLocaleDateString('bn-BD',{weekday:'long',day:'numeric',month:'short'})+' · '+d.toLocaleTimeString('bn-BD',{hour:'2-digit',minute:'2-digit'})}
clock();setInterval(clock,30000);updatePersonaUI();checkApi();
try{const saved=JSON.parse(localStorage.getItem('towsif-chat')||'[]');if(saved.length){history=saved.slice(-20);$('messages').replaceChildren();saved.forEach(m=>addMessage(m.role,m.text))}}catch(e){}
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
