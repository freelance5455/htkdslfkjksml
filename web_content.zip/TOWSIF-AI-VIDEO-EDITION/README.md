# TOWSIF AI — Video-inspired MVP

This is a separate, mobile-first web assistant inspired by the uploaded reference video. It does not modify TK Tools Pro.

## Features in this build
- Responsive home, chat, persona, settings and updates screens
- Gemini API calls from the server; API key is never placed in browser code
- Four response styles: Assistant, Study, Creative and Tech Pro
- Browser-supported Bengali/English voice input
- Optional read-aloud via device text-to-speech
- Local browser chat history and local preference notes
- API health/status check
- Basic PWA manifest and service worker shell caching

## Deploy to Render from Android
1. Extract this ZIP on your phone.
2. Create a **new separate** GitHub repository, e.g. `towsif-ai-video-edition`. Do not upload these files into `TK.WEB` or the TK Tools Pro repo.
3. Upload the contents of this folder to the new repo root (so `package.json` and `server.js` are at root).
4. On Render, create a new Web Service from that repo. Runtime: Node. Build command: `npm install`. Start command: `npm start`. Leave Root Directory blank.
5. Add `GEMINI_API_KEY` in Render Environment using a key from Google AI Studio. Never put the key in HTML, JS, screenshots, or a public repo.
6. Deploy. Check `/api/health` and make sure `configured` is true.

## Honest limits
This is a PWA-style web app, not a native Android APK. Voice recognition depends on browser support and microphone permission. The memory notes and chat history are stored only in this browser on this device; they are not encrypted cloud memory. The app does not currently control other apps, read notifications, perform accessibility actions, show a native floating overlay, or run an always-on assistant in the background. Those require a separately built Android app and explicit Android permissions. Personas alter response style, not device permissions. The server does not yet provide user accounts or durable multi-device storage.
