# STUDY VERSE

Student study companion.

## Use

1. Open `index.html` in a browser.
2. Optional: add your own AI key under Settings if you want enhanced assistant answers.

## Notes

- Study data stays on the device where you use the app.
- For personal / educational use.
- Developed by Mehedi Atik.
