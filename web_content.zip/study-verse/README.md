# STUDY VERSE — Enhanced Edition (v2)

Smart study companion for HSC & GST admission students in Bangladesh.

## What's New in This Edition

### Bilingual MCQ Bank (1,764 questions)
All questions are original, curriculum-based, and presented in **both Bangla and English**.

| Group | Subjects | Questions |
|-------|----------|-----------|
| GST Humanities | 10 (Bangla, English, History, Islamic History, Philosophy, Political Science, Sociology, Economics, Social Work, Geography) | 504 |
| GST Science | 4 (Physics, Chemistry, Math, Biology) | 20 |
| HSC Science | 6 (Physics, Chemistry, Biology, Higher Math, ICT, Statistics) | 280 |
| HSC Arts | 10 (Bangla, English, Economics, Civics, History, Islamic Studies, Geography, Philosophy, Sociology, Psychology) | 306 |
| HSC Business | 3 (Accounting, Business Organization, Finance) | 109 |
| **GK B Unit (NEW)** | **17 sub-topics** | **545** |
| **Total** | **50 subjects** | **1,764 MCQs** |

### GK B Unit (NEW) — 545 questions across 3 main areas:
1. **Bangladesh Affairs (180 Qs)** — Liberation War 1971 (30), Geography (25), Government & Politics (25), Economy (25), History pre-1971 (25), Culture & Society (20), Education & Sports (20), Important People (10)
2. **International Affairs (180 Qs)** — UN & Organizations (30), World Geography (25), World History (25), World Leaders (20), World Sports (20), Science & Discoveries (20), Literature & Arts (20), Economy & Currencies (20)
3. **General Science & Misc (185 Qs)** — Human Body & Biology (30), Physics & Measurement (25), Chemistry Basics (25), Space & Astronomy (25), Environment & Climate (25), Inventions (25), Bangladesh Scientists (15), Awards & Honors (15)

### Sections
- **Dashboard** — overview, streak, recent activity
- **Study Assistant** — chat help in Bangla & English (optional AI)
- **Ask Google** — search Google in Bangla or English
- **Quiz Arena** — practice MCQs with instant feedback + wrong-answer review
- **Exam Hall** — timed exam simulation with custom questions, timer, negative marking
- **HSC MCQs** — 19 HSC subjects organized by group
- **GST / Admission** — 14 GST subjects (Humanities + Science)
- **GK (B Unit) (NEW)** — 545 General Knowledge MCQs for B Unit admission
- **Memories** — spaced-repetition flashcards
- **Notes Library** — write & organize notes
- **Study Planner** — tasks, exam countdowns, study goal
- **Progress Tracker** — study history, quiz performance
- **Resources** — Google Books & YouTube search shortcuts
- **Settings** — display, optional AI key, data export/import

## Use

1. Open `index.html` in any modern browser.
2. Use the sidebar to navigate between sections.
3. Optional: add your own AI key under Settings for enhanced assistant answers.

## Notes

- All study data stays in your browser's local storage.
- For personal / educational use.
- All MCQs are original, written based on official HSC/GST syllabus topics and well-known facts.
- Developed by Mehedi Atik. Enhanced edition by Admin Edge.
