/**
 * STUDY VERSE — Main Application Logic
 */

(function () {
  'use strict';

  // ---------- Storage helpers ----------
  const STORAGE_KEY = 'studyverse_data_v1';

  function defaultData() {
    return {
      notes: [],
      decks: [
        { id: 'deck_bio', name: 'Biology' },
        { id: 'deck_chem', name: 'Chemistry' },
        { id: 'deck_hist', name: 'History' },
        { id: 'deck_math', name: 'Math' },
      ],
      cards: getSampleCards(),
      tasks: [],
      exams: [],
      goalMinutes: 60,
      studyLog: {}, // { "YYYY-MM-DD": minutes }
      quizHistory: [], // { subject, score, total, date }
      activity: [],
      settings: { reduceMotion: false, geminiKey: '', geminiModel: 'gemini-2.0-flash' },
      lastStudyDate: null,
      streak: 0,
      googleQuestions: [],
    };
  }

  function getSampleCards() {
    const now = Date.now();
    return [
      { id: 'c1', deckId: 'deck_bio', front: 'What is photosynthesis?', back: 'Process by which green plants convert light energy into chemical energy (glucose) using CO₂ and H₂O.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c2', deckId: 'deck_bio', front: 'What is the powerhouse of the cell?', back: 'Mitochondria — produces ATP through cellular respiration.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c3', deckId: 'deck_bio', front: 'What is DNA?', back: 'Deoxyribonucleic acid — molecule that carries genetic instructions for development and function.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c4', deckId: 'deck_chem', front: 'What is the atomic number of Carbon?', back: '6 — it has 6 protons.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c5', deckId: 'deck_chem', front: 'What is pH?', back: 'A scale (0–14) measuring how acidic or basic a solution is. 7 is neutral.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c6', deckId: 'deck_chem', front: 'What is a mole?', back: '6.022 × 10²³ particles (Avogadro\'s number). Unit for amount of substance.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c7', deckId: 'deck_hist', front: 'When did World War II end?', back: '1945 (in Europe: May 8; in Asia: September 2 after Japan surrendered).', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c8', deckId: 'deck_hist', front: 'Who was the first President of the United States?', back: 'George Washington (1789–1797).', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c9', deckId: 'deck_math', front: 'What is the Pythagorean theorem?', back: 'In a right triangle: a² + b² = c², where c is the hypotenuse.', interval: 1, ease: 2.5, due: now, reps: 0 },
      { id: 'c10', deckId: 'deck_math', front: 'What is the derivative of x²?', back: '2x (power rule: d/dx[xⁿ] = n·xⁿ⁻¹).', interval: 1, ease: 2.5, due: now, reps: 0 },
    ];
  }

  function loadData() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultData();
      const data = JSON.parse(raw);
      // Merge with defaults for any missing keys
      const def = defaultData();
      return { ...def, ...data, settings: { ...def.settings, ...(data.settings || {}) } };
    } catch (e) {
      console.warn('Failed to load data, using defaults', e);
      return defaultData();
    }
  }

  function saveData() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  let state = loadData();

  // ---------- Quiz bank (loaded from questions.js) ----------
  // Use external question bank if available, otherwise fall back to small inline bank
  const QUIZ_BANK = (window.QUESTION_BANK && Object.keys(window.QUESTION_BANK).length > 0)
    ? window.QUESTION_BANK
    : {
        Biology: [
          { q: 'Which organelle is responsible for photosynthesis?', qEn: '', options: ['Mitochondria', 'Chloroplast', 'Nucleus', 'Ribosome'], optionsEn: [], answer: 1, explain: 'Chloroplasts contain chlorophyll and carry out photosynthesis in plant cells.', explainEn: '' },
          { q: 'What is the basic unit of life?', qEn: '', options: ['Atom', 'Tissue', 'Cell', 'Organ'], optionsEn: [], answer: 2, explain: 'The cell is the smallest structural and functional unit of living organisms.', explainEn: '' },
        ],
      };

  // Subject metadata from questions.js
  const SUBJECT_META = window.SUBJECT_META || {};

  // Group keys for filtering
  const SUBJECT_GROUPS = {
    'gst-humanities': { label: 'GST Humanities', labelBn: 'জিএসটি মানবিক', keys: ['GST Bangla', 'GST English', 'GST History', 'GST Islamic History', 'GST Philosophy', 'GST Political Science', 'GST Sociology', 'GST Economics', 'GST Social Work', 'GST Geography'] },
    'gst-science': { label: 'GST Science', labelBn: 'জিএসটি বিজ্ঞান', keys: ['GST Physics', 'GST Chemistry', 'GST Math', 'GST Biology'] },
    'hsc-science': { label: 'HSC Science', labelBn: 'এইচএসসি বিজ্ঞান', keys: ['HSC Physics', 'HSC Chemistry', 'HSC Biology', 'HSC Higher Math', 'HSC ICT', 'HSC Statistics'] },
    'hsc-arts': { label: 'HSC Arts', labelBn: 'এইচএসসি মানবিক', keys: ['HSC Bangla', 'HSC English', 'HSC Economics', 'HSC Civics', 'HSC History', 'HSC Islamic Studies', 'HSC Geography', 'HSC Philosophy', 'HSC Sociology', 'HSC Psychology'] },
    'hsc-business': { label: 'HSC Business', labelBn: 'এইচএসসি ব্যবসায়', keys: ['HSC Accounting', 'HSC Business Organization', 'HSC Finance'] },
    'gk-b-unit': { label: 'GK B Unit', labelBn: 'জিকে বি ইউনিট', keys: [
      'GK Bangladesh Affairs - Liberation War 1971',
      'GK Bangladesh Affairs - Geography',
      'GK Bangladesh Affairs - Government & Politics',
      'GK Bangladesh Affairs - Economy',
      'GK Bangladesh Affairs - History Pre-1971',
      'GK Bangladesh Affairs - Culture & Society',
      'GK Bangladesh Affairs - Education & Sports',
      'GK Bangladesh Affairs - Important People',
      'GK International Affairs',
      'GK General Science - Human Body',
      'GK General Science - Physics',
      'GK General Science - Chemistry',
      'GK General Science - Space',
      'GK General Science - Environment',
      'GK General Science - Inventions',
      'GK General Science - Bangladesh Scientists',
      'GK General Science - Awards & Honors',
    ] },
  };

  const GST_SUBJECTS = ['GST Physics', 'GST Chemistry', 'GST Math', 'GST Biology', 'GST Bangla', 'GST English', 'GST History', 'GST Islamic History', 'GST Philosophy', 'GST Political Science', 'GST Sociology', 'GST Economics', 'GST Social Work', 'GST Geography'];
  let quizNegativeMarking = true; // GST rule by default
  // ---------- Utility ----------
  function uid() {
    return 'id_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function todayStr() {
    return new Date().toISOString().slice(0, 10);
  }

  function daysBetween(a, b) {
    const d1 = new Date(a);
    const d2 = new Date(b);
    return Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
  }

  function addActivity(text) {
    state.activity.unshift({ text, date: new Date().toISOString() });
    if (state.activity.length > 30) state.activity.pop();
    saveData();
  }

  function updateStreak() {
    const today = todayStr();
    if (state.lastStudyDate === today) return;
    if (state.lastStudyDate) {
      const diff = daysBetween(state.lastStudyDate, today);
      if (diff === 1) state.streak += 1;
      else if (diff > 1) state.streak = 1;
    } else {
      state.streak = 1;
    }
    state.lastStudyDate = today;
    saveData();
  }

  // ---------- Navigation ----------
  const sections = document.querySelectorAll('.section');
  const navBtns = document.querySelectorAll('.nav-btn');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('overlay');
  const menuToggle = document.getElementById('menuToggle');

  function showSection(id) {
    sections.forEach((s) => s.classList.toggle('active', s.id === id));
    navBtns.forEach((b) => b.classList.toggle('active', b.dataset.section === id));
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
    // Refresh section data
    if (id === 'dashboard') renderDashboard();
    if (id === 'memories') renderMemories();
    if (id === 'notes') renderNotes();
    if (id === 'planner') renderPlanner();
    if (id === 'progress') renderProgress();
    if (id === 'quiz') renderQuizSetup();
    if (id === 'exam') renderExamSetup();
    if (id === 'hsc') renderHscSection();
    if (id === 'admission') renderAdmissionSection();
    if (id === 'gk') renderGkSection();
    if (id === 'resources') renderResources();
    if (id === 'askgoogle') renderAskGoogle();
  }

  navBtns.forEach((btn) => {
    btn.addEventListener('click', () => showSection(btn.dataset.section));
  });

  document.querySelectorAll('[data-goto]').forEach((btn) => {
    btn.addEventListener('click', () => showSection(btn.dataset.goto));
  });

  menuToggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlay.classList.toggle('show');
  });
  overlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  });

  // ---------- Global search ----------
  const searchToggle = document.getElementById('searchToggle');
  const globalSearch = document.getElementById('globalSearch');
  const searchInput = document.getElementById('searchInput');
  const searchResults = document.getElementById('searchResults');

  searchToggle.addEventListener('click', () => {
    globalSearch.classList.toggle('show');
    if (globalSearch.classList.contains('show')) searchInput.focus();
  });

  searchInput.addEventListener('input', () => {
    const q = searchInput.value.trim().toLowerCase();
    if (q.length < 2) {
      searchResults.classList.remove('show');
      searchResults.innerHTML = '';
      return;
    }
    const hits = [];
    state.notes.forEach((n) => {
      if ((n.title + ' ' + n.body).toLowerCase().includes(q)) {
        hits.push({ type: 'Note', label: n.title || 'Untitled', action: () => { showSection('notes'); selectNote(n.id); } });
      }
    });
    state.cards.forEach((c) => {
      if ((c.front + ' ' + c.back).toLowerCase().includes(q)) {
        hits.push({ type: 'Card', label: c.front.slice(0, 60), action: () => showSection('memories') });
      }
    });
    Object.keys(QUIZ_BANK).forEach((subj) => {
      if (subj.toLowerCase().includes(q)) {
        hits.push({ type: 'Quiz', label: subj + ' quiz', action: () => { showSection('quiz'); startQuiz(subj); } });
      }
    });
    searchResults.innerHTML = hits.slice(0, 8).map((h, i) =>
      `<div class="search-hit" data-i="${i}"><div class="hit-type">${h.type}</div>${escapeHtml(h.label)}</div>`
    ).join('') || '<div class="search-hit">No results</div>';
    searchResults.classList.add('show');
    searchResults.querySelectorAll('.search-hit[data-i]').forEach((el) => {
      el.addEventListener('click', () => {
        hits[+el.dataset.i].action();
        searchResults.classList.remove('show');
        searchInput.value = '';
        globalSearch.classList.remove('show');
      });
    });
  });

  function escapeHtml(str) {
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
  }

  // ---------- Dashboard ----------
  function renderDashboard() {
    const today = todayStr();
    const studied = state.studyLog[today] || 0;
    const goal = state.goalMinutes || 60;
    document.getElementById('todayGoal').textContent = `${studied} / ${goal} min`;
    document.getElementById('goalProgress').style.width = Math.min(100, (studied / goal) * 100) + '%';
    document.getElementById('dashStreak').textContent = state.streak + ' days';
    document.getElementById('streakCount').textContent = state.streak;

    const due = state.cards.filter((c) => c.due <= Date.now()).length;
    document.getElementById('cardsDue').textContent = due;
    document.getElementById('quizzesTaken').textContent = state.quizHistory.length;

    // Exams
    const exams = [...state.exams].sort((a, b) => a.date.localeCompare(b.date));
    const examEl = document.getElementById('dashExams');
    if (exams.length === 0) {
      examEl.innerHTML = '<li style="color:var(--text-muted)">No exams added yet</li>';
    } else {
      examEl.innerHTML = exams.slice(0, 5).map((e) => {
        const days = daysBetween(today, e.date);
        const label = days < 0 ? 'Past' : days === 0 ? 'Today!' : days + ' days left';
        return `<li><span>${escapeHtml(e.name)}</span><span class="days-left">${label}</span></li>`;
      }).join('');
    }

    // Activity
    const actEl = document.getElementById('activityList');
    if (state.activity.length === 0) {
      actEl.innerHTML = '<li style="color:var(--text-muted)">No activity yet — start studying!</li>';
    } else {
      actEl.innerHTML = state.activity.slice(0, 8).map((a) => {
        const d = new Date(a.date);
        return `<li><span>${escapeHtml(a.text)}</span><span style="color:var(--text-muted);font-size:0.8rem">${d.toLocaleDateString()}</span></li>`;
      }).join('');
    }
  }

  // ---------- Smart Study Assistant (local logic only) ----------
  const chatWindow = document.getElementById('chatWindow');
  const assistantInput = document.getElementById('assistantInput');
  const assistantSend = document.getElementById('assistantSend');

  const KNOWLEDGE = {
    photosynthesis: 'Photosynthesis is how green plants make food. They use sunlight, water (H₂O), and carbon dioxide (CO₂) to produce glucose (C₆H₁₂O₆) and oxygen (O₂). The main equation is: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂. It happens in chloroplasts. Light reactions split water; the Calvin cycle builds sugar.',
    'spaced repetition': 'Spaced repetition is a learning technique where you review material at increasing intervals. You study something, wait a bit, review, wait longer, review again. This fights the forgetting curve. STUDY VERSE Memories uses a simple version: when you mark "Remember", the interval grows; "Forgot" resets it shorter. Review daily for best results.',
    mitochondria: 'Mitochondria are organelles often called the "powerhouse of the cell". They generate most of the cell\'s ATP through cellular respiration. They have their own DNA and a double membrane.',
    'study plan': 'A solid 7-day study plan: Day 1–2: Map all topics and gather materials. Day 3–4: Deep study of hardest subjects + active recall (flashcards/quizzes). Day 5: Practice problems and past papers. Day 6: Review weak areas from quiz results. Day 7: Light review + rest. Study in 25–50 min focused blocks with short breaks (Pomodoro). Sleep well — memory consolidates during sleep.',
    formulas: 'To remember formulas better: (1) Understand derivation instead of pure memorization. (2) Write them by hand repeatedly. (3) Use spaced repetition flashcards. (4) Connect to a visual or story. (5) Practice applying them in problems immediately. (6) Teach the formula to someone else.',
    atom: 'An atom is the smallest unit of ordinary matter. It has a nucleus of protons and neutrons, with electrons in orbitals around it. Atomic number = number of protons. Mass number ≈ protons + neutrons.',
    dna: 'DNA (deoxyribonucleic acid) is a double-helix molecule that stores genetic information. Base pairs: A–T and C–G. It is replicated during cell division and transcribed into RNA for protein synthesis.',
    gravity: 'Gravity is the force of attraction between masses. On Earth it gives weight. Newton\'s law: F = G·m₁·m₂/r². Einstein described it as curvature of spacetime in general relativity.',
    photosynthesis: null, // already defined above
  };

  // Fix duplicate key - knowledge already has photosynthesis
  delete KNOWLEDGE.photosynthesis;
  KNOWLEDGE['photosynthesis'] = 'Photosynthesis is how green plants make food. They use sunlight, water (H₂O), and carbon dioxide (CO₂) to produce glucose (C₆H₁₂O₆) and oxygen (O₂). The main equation is: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂. It happens in chloroplasts. Light reactions split water; the Calvin cycle builds sugar.';

  function assistantReply(question) {
    const q = question.toLowerCase().trim();

    // Check user notes first
    const noteHits = state.notes.filter((n) =>
      (n.title + ' ' + n.body).toLowerCase().includes(q.split(/\s+/).find((w) => w.length > 3) || q)
    );
    if (noteHits.length && (q.includes('note') || q.includes('summar') || q.includes('my '))) {
      const n = noteHits[0];
      return `From your notes **${n.title || 'Untitled'}**:\n\n${n.body.slice(0, 500)}${n.body.length > 500 ? '…' : ''}`;
    }

    // Keyword knowledge
    for (const [key, val] of Object.entries(KNOWLEDGE)) {
      if (q.includes(key)) return val;
    }

    // Study strategy patterns
    if (/study plan|schedule|how (to|should) study|exam prep/.test(q)) {
      return KNOWLEDGE['study plan'];
    }
    if (/remember|memory|memorize|forget/.test(q)) {
      return KNOWLEDGE.formulas;
    }
    if (/spaced|repetition|anki|flashcard/.test(q)) {
      return KNOWLEDGE['spaced repetition'];
    }
    if (/motivate|lazy|focus|procrastinat/.test(q)) {
      return 'Start tiny: open the book and do 5 minutes. Momentum beats motivation. Use a timer (25 min work / 5 min break). Remove phone from the room. Study the hardest subject first when your energy is highest. Track progress in STUDY VERSE so you can see streaks grow.';
    }
    if (/hello|hi |hey |help/.test(q)) {
      return 'Hi! I can explain common topics (photosynthesis, DNA, atoms, gravity…), give study plans, memory tips, and pull from your saved notes. Ask a specific question or try a tip chip below.';
    }
    if (/gst|ভর্তি|admission|udvash|প্রশ্নব্যাংক|mcq|পদার্থ|রসায়ন|জীববিজ্ঞান/.test(q)) {
      return 'GST / Admission practice is in the **GST / Admission** menu.\n\nSubjects: GST Physics, Chemistry, Math, Biology, English, Bangla.\nScoring: +1 correct, −0.25 wrong (like many admission papers).\n\nOpen **GST / Admission** for practice MCQs (Physics, Chemistry, Math, Biology, English, Bangla) with −0.25 marking. Use **Ask Google** for any syllabus topic in English or বাংলা.';
    }

    // Generic helpful fallback
    return 'I don\'t have a built-in article for that exact topic, but here\'s what you can do:\n\n• Add notes in Notes Library so I can quote them later\n• Create flashcards in Memories for active recall\n• Try Quiz Arena or GST / Admission MCQs\n• Search Resources or Ask Google (English or বাংলা)\n\nTip: Rephrase with a key term like "explain photosynthesis" or "GST physics".';
  }

  function appendMsg(text, isUser) {
    const div = document.createElement('div');
    div.className = 'msg ' + (isUser ? 'user' : 'bot');
    div.innerHTML = `
      <div class="msg-avatar">${isUser ? 'You' : '✦'}</div>
      <div class="msg-body">${text.split('\n').map((p) => `<p>${escapeHtml(p).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')}</p>`).join('')}</div>
    `;
    chatWindow.appendChild(div);
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }

  function sanitizePublicError(msg) {
    // Never surface API keys or long tokens in the UI
    return String(msg || 'Request failed')
      .replace(/AIza[0-9A-Za-z_\-]{10,}/g, '[REDACTED]')
      .replace(/key=[^&\s]+/gi, 'key=[REDACTED]')
      .slice(0, 120);
  }

  async function callGemini(question) {
    const key = (state.settings.geminiKey || '').trim();
    const model = state.settings.geminiModel || 'gemini-2.0-flash';
    if (!key) throw new Error('No API key configured');

    const noteHint = state.notes.slice(0, 5).map((n) =>
      (n.title || 'Note') + ': ' + (n.body || '').slice(0, 200)
    ).join('\n');

    const systemText =
      'You are STUDY VERSE Study Assistant for students (Bangladesh admission / GST friendly). ' +
      'Answer clearly in the same language as the user (English or Bangla). ' +
      'Be accurate, concise, and educational. Use short paragraphs or bullets. ' +
      'If the topic is uncertain, say so. Do not invent exam questions from copyrighted banks. ' +
      (noteHint ? 'User notes (may help):\n' + noteHint : '');

    // Key goes in header only — never in the URL (avoids query-string leaks in logs/history)
    const url = 'https://generativelanguage.googleapis.com/v1beta/models/' +
      encodeURIComponent(model) + ':generateContent';

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': key,
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemText }] },
        contents: [{ role: 'user', parts: [{ text: question }] }],
        generationConfig: { temperature: 0.6, maxOutputTokens: 1024 },
      }),
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = (data.error && data.error.message) || ('HTTP ' + res.status);
      throw new Error(sanitizePublicError(msg));
    }
    const text = data.candidates &&
      data.candidates[0] &&
      data.candidates[0].content &&
      data.candidates[0].content.parts &&
      data.candidates[0].content.parts.map((p) => p.text || '').join('');
    if (!text) throw new Error('Empty response from AI');
    return text.trim();
  }

  function updateAssistantSubtitle() {
    const el = document.getElementById('assistantSubtitle');
    if (!el) return;
    if ((state.settings.geminiKey || '').trim()) {
      el.textContent = 'Gemini mode (' + (state.settings.geminiModel || 'gemini-2.0-flash') + ') — English & বাংলা.';
    } else {
      el.textContent = 'Study help in English & বাংলা. Optional AI can be enabled in Settings.';
    }
  }

  function updateGeminiStatus(extra) {
    const el = document.getElementById('geminiStatus');
    if (!el) return;
    const has = !!(state.settings.geminiKey || '').trim();
    el.textContent = extra || (has
      ? 'Status: AI ready (' + (state.settings.geminiModel || 'gemini-2.0-flash') + ')'
      : 'Status: standard mode');
  }

  async function sendAssistant() {
    const text = assistantInput.value.trim();
    if (!text) return;
    appendMsg(text, true);
    assistantInput.value = '';
    assistantSend.disabled = true;

    const hasKey = !!(state.settings.geminiKey || '').trim();
    if (hasKey) {
      appendMsg('Thinking with Gemini…', false);
      const thinking = chatWindow.lastElementChild;
      try {
        const reply = await callGemini(text);
        if (thinking && thinking.parentNode) thinking.remove();
        appendMsg(reply, false);
      } catch (err) {
        if (thinking && thinking.parentNode) thinking.remove();
        appendMsg('AI unavailable (' + sanitizePublicError(err.message) + ').\n\nUsing local assistant…\n\n' + assistantReply(text), false);
      }
    } else {
      setTimeout(() => {
        appendMsg(assistantReply(text), false);
      }, 300);
    }
    assistantSend.disabled = false;
  }

  assistantSend.addEventListener('click', sendAssistant);
  assistantInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendAssistant();
  });
  document.querySelectorAll('.chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      assistantInput.value = chip.dataset.q;
      sendAssistant();
    });
  });

  // ---------- Quiz Arena ----------
  let currentQuiz = null; // { subject, questions, index, score, wrong, negative, wrongList }

  // Helper: format a question's bilingual text
  function bilingualQuestionHtml(q) {
    let html = '<div class="q-bn">' + escapeHtml(q.q || '') + '</div>';
    if (q.qEn) html += '<div class="q-en">' + escapeHtml(q.qEn) + '</div>';
    return html;
  }
  function bilingualOptionHtml(o, oEn) {
    let html = '<span class="opt-bn">' + escapeHtml(o || '') + '</span>';
    if (oEn) html += '<span class="opt-en">' + escapeHtml(oEn) + '</span>';
    return html;
  }
  function bilingualExplainHtml(ex, exEn) {
    let html = '<div class="ex-bn">' + escapeHtml(ex || '') + '</div>';
    if (exEn) html += '<div class="ex-en">' + escapeHtml(exEn) + '</div>';
    return html;
  }

  function renderSubjectGrid(gridId, keys) {
    const grid = document.getElementById(gridId);
    if (!grid) return;
    grid.innerHTML = keys.map((s) => {
      const meta = SUBJECT_META[s] || {};
      const cnt = QUIZ_BANK[s] ? QUIZ_BANK[s].length : 0;
      const bn = meta.nameBn || s;
      const en = meta.nameEn || s;
      return `<button class="subject-btn" data-subj="${escapeHtml(s)}">
        <span class="subj-bn">${escapeHtml(bn)}</span>
        <span class="subj-en">${escapeHtml(en)}</span>
        <span class="subj-count">${cnt} MCQs</span>
      </button>`;
    }).join('');
    grid.querySelectorAll('.subject-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        // Apply group filter for negative marking preference
        const groupFilter = document.getElementById('quizGroupFilter');
        const filterVal = groupFilter ? groupFilter.value : 'all';
        // Negative marking applies to all GST subjects by default per GST rule
        quizNegativeMarking = btn.dataset.subj.startsWith('GST');
        startQuiz(btn.dataset.subj);
      });
    });
  }

  function renderQuizStatsRow(elId) {
    const el = document.getElementById(elId);
    if (!el) return;
    const groups = ['gst-humanities', 'gst-science', 'hsc-science', 'hsc-arts', 'hsc-business', 'gk-b-unit'];
    el.innerHTML = groups.map((g) => {
      const keys = SUBJECT_GROUPS[g].keys.filter((k) => QUIZ_BANK[k]);
      const total = keys.reduce((acc, k) => acc + QUIZ_BANK[k].length, 0);
      return `<div class="stat-chip">
        <span class="chip-label">${SUBJECT_GROUPS[g].labelBn}</span>
        <span class="chip-count">${total}</span>
        <span class="chip-subjects">${keys.length} subjects</span>
      </div>`;
    }).join('');
  }

  function renderQuizSetup(mode) {
    document.getElementById('quizSetup').classList.remove('hidden');
    if (document.getElementById('quizSetup2')) document.getElementById('quizSetup2').classList.remove('hidden');
    document.getElementById('quizPlay').classList.add('hidden');
    document.getElementById('quizResult').classList.add('hidden');
    if (document.getElementById('quizWrongReview')) document.getElementById('quizWrongReview').classList.add('hidden');

    // Stats row
    renderQuizStatsRow('quizStatsRow');

    // Subject grid based on filter
    const filter = document.getElementById('quizGroupFilter');
    const filterVal = filter ? filter.value : 'all';
    let keys;
    if (filterVal === 'all' || !SUBJECT_GROUPS[filterVal]) {
      keys = Object.keys(QUIZ_BANK).sort();
    } else {
      keys = SUBJECT_GROUPS[filterVal].keys.filter((k) => QUIZ_BANK[k]);
    }
    renderSubjectGrid('quizSubjects', keys);
  }

  // Re-render subject grid when filter changes
  const quizGroupFilterEl = document.getElementById('quizGroupFilter');
  if (quizGroupFilterEl) {
    quizGroupFilterEl.addEventListener('change', () => renderQuizSetup());
  }

  function startQuiz(subject) {
    const allQs = QUIZ_BANK[subject];
    if (!allQs || allQs.length === 0) {
      alert('No questions available for this subject yet.');
      return;
    }
    if (GST_SUBJECTS.includes(subject)) quizNegativeMarking = true;
    // Shuffle and pick requested count
    const shuffled = [...allQs].sort(() => Math.random() - 0.5);
    const countSel = document.getElementById('quizCount');
    let n = countSel ? parseInt(countSel.value, 10) : 10;
    if (n === 0 || n > shuffled.length) n = shuffled.length;
    const questions = shuffled.slice(0, n);
    currentQuiz = {
      subject,
      questions,
      index: 0,
      score: 0,
      wrong: 0,
      negative: quizNegativeMarking,
      wrongList: [], // array of {q, selected, correct}
      answeredList: new Array(questions.length).fill(null),
    };
    document.getElementById('quizSetup').classList.add('hidden');
    if (document.getElementById('quizSetup2')) document.getElementById('quizSetup2').classList.add('hidden');
    document.getElementById('quizResult').classList.add('hidden');
    if (document.getElementById('quizWrongReview')) document.getElementById('quizWrongReview').classList.add('hidden');
    document.getElementById('quizPlay').classList.remove('hidden');
    showQuestion();
  }

  function showQuestion() {
    const cq = currentQuiz;
    const q = cq.questions[cq.index];
    document.getElementById('quizSubjectLabel').textContent = cq.subject + (cq.negative ? ' (−0.25)' : '');
    document.getElementById('quizProgress').textContent = `Q ${cq.index + 1} / ${cq.questions.length}`;
    const displayScore = cq.negative ? (cq.score - cq.wrong * 0.25).toFixed(2) : cq.score;
    document.getElementById('quizScore').textContent = `Score: ${displayScore}`;
    document.getElementById('quizQuestion').innerHTML = bilingualQuestionHtml(q);
    const opts = document.getElementById('quizOptions');
    opts.innerHTML = q.options.map((o, i) =>
      `<button class="option-btn" data-i="${i}">${bilingualOptionHtml(o, (q.optionsEn && q.optionsEn[i]) || '')}</button>`
    ).join('');
    document.getElementById('quizFeedback').classList.add('hidden');
    document.getElementById('quizNext').classList.add('hidden');

    opts.querySelectorAll('.option-btn').forEach((btn) => {
      btn.addEventListener('click', () => selectAnswer(+btn.dataset.i));
    });
  }

  function selectAnswer(i) {
    const cq = currentQuiz;
    const q = cq.questions[cq.index];
    const buttons = document.querySelectorAll('.option-btn');
    buttons.forEach((b) => { b.disabled = true; });
    buttons[q.answer].classList.add('correct');
    if (i === q.answer) {
      cq.score++;
    } else {
      buttons[i].classList.add('wrong');
      cq.wrong++;
      cq.wrongList.push({ q, selected: i, correct: q.answer });
    }
    cq.answeredList[cq.index] = i;
    const displayScore = cq.negative ? (cq.score - cq.wrong * 0.25).toFixed(2) : cq.score;
    document.getElementById('quizScore').textContent = `Score: ${displayScore}`;
    const fb = document.getElementById('quizFeedback');
    const label = i === q.answer ? '✓ সঠিক / Correct!' : (cq.negative ? '✗ ভুল (−0.25) / Wrong' : '✗ ভুল / Wrong');
    fb.innerHTML = `<div class="feedback-label ${i === q.answer ? 'feedback-correct' : 'feedback-wrong'}">${label}</div>
      <div class="feedback-explain">${bilingualExplainHtml(q.explain, q.explainEn)}</div>`;
    fb.classList.remove('hidden');
    document.getElementById('quizNext').classList.remove('hidden');
  }

  document.getElementById('quizNext').addEventListener('click', () => {
    currentQuiz.index++;
    if (currentQuiz.index >= currentQuiz.questions.length) {
      finishQuiz();
    } else {
      showQuestion();
    }
  });

  function finishQuiz() {
    const cq = currentQuiz;
    document.getElementById('quizPlay').classList.add('hidden');
    document.getElementById('quizResult').classList.remove('hidden');
    const net = cq.negative ? cq.score - cq.wrong * 0.25 : cq.score;
    const pct = Math.round((cq.score / cq.questions.length) * 100);
    const scoreText = cq.negative
      ? `Net: ${net.toFixed(2)} (Correct ${cq.score}, Wrong ${cq.wrong}, −0.25 each, of ${cq.questions.length})`
      : `${cq.score} / ${cq.questions.length} (${pct}%)`;
    document.getElementById('resultScore').textContent = scoreText;
    let msg = 'Keep practicing! অনুশীলন চালিয়ে যান।';
    if (pct === 100) msg = 'Perfect score! অসাধারণ! 🎉';
    else if (pct >= 80) msg = 'Great job — you know this well. 👏';
    else if (pct >= 60) msg = 'Solid effort. Review the explanations and try again.';
    else if (pct >= 40) msg = 'Needs work — review the explanations below and retry.';
    else msg = 'Keep practicing — every expert was once a beginner!';
    document.getElementById('resultMessage').textContent = msg;

    state.quizHistory.push({
      subject: cq.subject,
      score: net,
      total: cq.questions.length,
      date: todayStr(),
    });
    updateStreak();
    addActivity(`Quiz: ${cq.subject} — ${typeof net === 'number' ? net.toFixed(2) : net}/${cq.questions.length}`);
    saveData();
  }

  // Review wrong answers
  function renderQuizWrongReview() {
    if (!currentQuiz || !currentQuiz.wrongList.length) {
      alert('No wrong answers to review. Great job!');
      return;
    }
    document.getElementById('quizResult').classList.add('hidden');
    document.getElementById('quizWrongReview').classList.remove('hidden');
    const list = document.getElementById('quizWrongList');
    list.innerHTML = currentQuiz.wrongList.map((item, idx) => {
      const q = item.q;
      return `<div class="wrong-item">
        <div class="wrong-q-num">Q${idx + 1}</div>
        <div class="wrong-q-text">${bilingualQuestionHtml(q)}</div>
        <div class="wrong-options">
          ${q.options.map((o, i) => {
            let cls = 'wrong-opt';
            if (i === item.correct) cls = 'wrong-opt correct';
            else if (i === item.selected) cls = 'wrong-opt wrong';
            const enTxt = (q.optionsEn && q.optionsEn[i]) ? `<span class="opt-en">${escapeHtml(q.optionsEn[i])}</span>` : '';
            return `<div class="${cls}"><span class="opt-bn">${escapeHtml(o)}</span>${enTxt}</div>`;
          }).join('')}
        </div>
        <div class="wrong-explain">${bilingualExplainHtml(q.explain, q.explainEn)}</div>
      </div>`;
    }).join('');
  }

  document.getElementById('quizRetry').addEventListener('click', () => {
    if (currentQuiz) startQuiz(currentQuiz.subject);
  });
  document.getElementById('quizHome').addEventListener('click', () => renderQuizSetup());
  const quizReviewWrongBtn = document.getElementById('quizReviewWrong');
  if (quizReviewWrongBtn) quizReviewWrongBtn.addEventListener('click', renderQuizWrongReview);
  const quizRetryFromReviewBtn = document.getElementById('quizRetryFromReview');
  if (quizRetryFromReviewBtn) quizRetryFromReviewBtn.addEventListener('click', () => {
    if (currentQuiz) startQuiz(currentQuiz.subject);
  });
  const quizBackToResultBtn = document.getElementById('quizBackToResult');
  if (quizBackToResultBtn) quizBackToResultBtn.addEventListener('click', () => {
    document.getElementById('quizWrongReview').classList.add('hidden');
    document.getElementById('quizResult').classList.remove('hidden');
  });

  // ---------- GST / Admission section ----------
  function renderAdmissionSection() {
    // Stats
    renderQuizStatsRow('gstStats');
    // Override to show only GST groups
    const gstStatsEl = document.getElementById('gstStats');
    if (gstStatsEl) {
      const keys1 = SUBJECT_GROUPS['gst-humanities'].keys.filter((k) => QUIZ_BANK[k]);
      const total1 = keys1.reduce((a, k) => a + QUIZ_BANK[k].length, 0);
      const keys2 = SUBJECT_GROUPS['gst-science'].keys.filter((k) => QUIZ_BANK[k]);
      const total2 = keys2.reduce((a, k) => a + QUIZ_BANK[k].length, 0);
      gstStatsEl.innerHTML = `
        <div class="stat-chip"><span class="chip-label">GST Humanities</span><span class="chip-count">${total1}</span><span class="chip-subjects">${keys1.length} subjects</span></div>
        <div class="stat-chip"><span class="chip-label">GST Science</span><span class="chip-count">${total2}</span><span class="chip-subjects">${keys2.length} subjects</span></div>
        <div class="stat-chip"><span class="chip-label">GST Total</span><span class="chip-count">${total1 + total2}</span><span class="chip-subjects">${keys1.length + keys2.length} subjects</span></div>
      `;
    }
    // Subject grids
    renderSubjectGrid('gstHumanitiesGrid', SUBJECT_GROUPS['gst-humanities'].keys.filter((k) => QUIZ_BANK[k]));
    renderSubjectGrid('gstScienceGrid', SUBJECT_GROUPS['gst-science'].keys.filter((k) => QUIZ_BANK[k]));
    // Override click handlers to start quiz in quiz section
    document.querySelectorAll('#gstHumanitiesGrid .subject-btn, #gstScienceGrid .subject-btn').forEach((btn) => {
      btn.onclick = () => {
        showSection('quiz');
        quizNegativeMarking = true;
        startQuiz(btn.dataset.subj);
      };
    });
  }

  // ---------- HSC section ----------
  function renderHscSection() {
    renderQuizStatsRow('hscStats');
    const hscStatsEl = document.getElementById('hscStats');
    if (hscStatsEl) {
      const groups = ['hsc-science', 'hsc-arts', 'hsc-business'];
      hscStatsEl.innerHTML = groups.map((g) => {
        const keys = SUBJECT_GROUPS[g].keys.filter((k) => QUIZ_BANK[k]);
        const total = keys.reduce((a, k) => a + QUIZ_BANK[k].length, 0);
        return `<div class="stat-chip"><span class="chip-label">${SUBJECT_GROUPS[g].labelBn}</span><span class="chip-count">${total}</span><span class="chip-subjects">${keys.length} subjects</span></div>`;
      }).join('');
      const allKeys = ['hsc-science', 'hsc-arts', 'hsc-business'].flatMap((g) => SUBJECT_GROUPS[g].keys).filter((k) => QUIZ_BANK[k]);
      const allTotal = allKeys.reduce((a, k) => a + QUIZ_BANK[k].length, 0);
      hscStatsEl.innerHTML += `<div class="stat-chip"><span class="chip-label">HSC Total</span><span class="chip-count">${allTotal}</span><span class="chip-subjects">${allKeys.length} subjects</span></div>`;
    }
    renderSubjectGrid('hscScienceGrid', SUBJECT_GROUPS['hsc-science'].keys.filter((k) => QUIZ_BANK[k]));
    renderSubjectGrid('hscArtsGrid', SUBJECT_GROUPS['hsc-arts'].keys.filter((k) => QUIZ_BANK[k]));
    renderSubjectGrid('hscBusinessGrid', SUBJECT_GROUPS['hsc-business'].keys.filter((k) => QUIZ_BANK[k]));
    document.querySelectorAll('#hscScienceGrid .subject-btn, #hscArtsGrid .subject-btn, #hscBusinessGrid .subject-btn').forEach((btn) => {
      btn.onclick = () => {
        showSection('quiz');
        quizNegativeMarking = false; // HSC quiz = no negative by default
        startQuiz(btn.dataset.subj);
      };
    });
  }

  // ---------- GK B Unit section ----------
  function renderGkSection() {
    // Stats
    const gkStatsEl = document.getElementById('gkStats');
    if (gkStatsEl) {
      const bdKeys = SUBJECT_GROUPS['gk-b-unit'].keys.filter((k) => k.startsWith('GK Bangladesh Affairs') && QUIZ_BANK[k]);
      const bdTotal = bdKeys.reduce((a, k) => a + QUIZ_BANK[k].length, 0);
      const intlKeys = SUBJECT_GROUPS['gk-b-unit'].keys.filter((k) => k.startsWith('GK International') && QUIZ_BANK[k]);
      const intlTotal = intlKeys.reduce((a, k) => a + QUIZ_BANK[k].length, 0);
      const sciKeys = SUBJECT_GROUPS['gk-b-unit'].keys.filter((k) => k.startsWith('GK General Science') && QUIZ_BANK[k]);
      const sciTotal = sciKeys.reduce((a, k) => a + QUIZ_BANK[k].length, 0);
      gkStatsEl.innerHTML = `
        <div class="stat-chip"><span class="chip-label">বাংলাদেশ বিষয়াবলি / Bangladesh Affairs</span><span class="chip-count">${bdTotal}</span><span class="chip-subjects">${bdKeys.length} sub-topics</span></div>
        <div class="stat-chip"><span class="chip-label">আন্তর্জাতিক বিষয়াবলি / International Affairs</span><span class="chip-count">${intlTotal}</span><span class="chip-subjects">${intlKeys.length} sub-topics</span></div>
        <div class="stat-chip"><span class="chip-label">সাধারণ বিজ্ঞান / General Science</span><span class="chip-count">${sciTotal}</span><span class="chip-subjects">${sciKeys.length} sub-topics</span></div>
        <div class="stat-chip"><span class="chip-label">GK Total</span><span class="chip-count">${bdTotal + intlTotal + sciTotal}</span><span class="chip-subjects">${bdKeys.length + intlKeys.length + sciKeys.length} sub-topics</span></div>
      `;
    }
    // Three subject grids
    const bdKeys = SUBJECT_GROUPS['gk-b-unit'].keys.filter((k) => k.startsWith('GK Bangladesh Affairs') && QUIZ_BANK[k]);
    const intlKeys = SUBJECT_GROUPS['gk-b-unit'].keys.filter((k) => k.startsWith('GK International') && QUIZ_BANK[k]);
    const sciKeys = SUBJECT_GROUPS['gk-b-unit'].keys.filter((k) => k.startsWith('GK General Science') && QUIZ_BANK[k]);
    renderSubjectGrid('gkBangladeshGrid', bdKeys);
    renderSubjectGrid('gkInternationalGrid', intlKeys);
    renderSubjectGrid('gkScienceGrid', sciKeys);
    document.querySelectorAll('#gkBangladeshGrid .subject-btn, #gkInternationalGrid .subject-btn, #gkScienceGrid .subject-btn').forEach((btn) => {
      btn.onclick = () => {
        showSection('quiz');
        quizNegativeMarking = true; // GST B Unit uses negative marking
        startQuiz(btn.dataset.subj);
      };
    });
  }

  // GK quick start button
  const startGkAllBtn = document.getElementById('startGkAll');
  if (startGkAllBtn) {
    startGkAllBtn.addEventListener('click', () => {
      showSection('quiz');
      const filter = document.getElementById('quizGroupFilter');
      if (filter) filter.value = 'gk-b-unit';
      renderQuizSetup();
    });
  }

  // GST quick start buttons
  const startGstHumanitiesBtn = document.getElementById('startGstHumanities');
  if (startGstHumanitiesBtn) {
    startGstHumanitiesBtn.addEventListener('click', () => {
      showSection('quiz');
      const filter = document.getElementById('quizGroupFilter');
      if (filter) filter.value = 'gst-humanities';
      renderQuizSetup();
    });
  }
  const startGstScienceBtn = document.getElementById('startGstScience');
  if (startGstScienceBtn) {
    startGstScienceBtn.addEventListener('click', () => {
      showSection('quiz');
      const filter = document.getElementById('quizGroupFilter');
      if (filter) filter.value = 'gst-science';
      renderQuizSetup();
    });
  }
  const startHscAllBtn = document.getElementById('startHscAll');
  if (startHscAllBtn) {
    startHscAllBtn.addEventListener('click', () => {
      showSection('quiz');
      const filter = document.getElementById('quizGroupFilter');
      if (filter) filter.value = 'all';
      renderQuizSetup();
    });
  }

  // ---------- Exam Hall ----------
  let currentExam = null; // { questions, index, answers[], negative, timeLimit, timeLeft, timerId }
  let examTimerId = null;

  function renderExamSetup() {
    document.getElementById('examSetup').classList.remove('hidden');
    document.getElementById('examPlay').classList.add('hidden');
    document.getElementById('examResult').classList.add('hidden');
    if (document.getElementById('examWrongReview')) document.getElementById('examWrongReview').classList.add('hidden');
    // Populate subject dropdown based on selected group
    updateExamSubjectOptions();
  }

  function updateExamSubjectOptions() {
    const groupSel = document.getElementById('examGroup');
    const subjSel = document.getElementById('examSubject');
    if (!groupSel || !subjSel) return;
    const group = groupSel.value;
    let keys;
    if (group === 'all' || !SUBJECT_GROUPS[group]) {
      keys = Object.keys(QUIZ_BANK).sort();
    } else {
      keys = SUBJECT_GROUPS[group].keys.filter((k) => QUIZ_BANK[k]);
    }
    subjSel.innerHTML = '<option value="">— Any subject —</option>' +
      keys.map((k) => {
        const meta = SUBJECT_META[k] || {};
        const cnt = QUIZ_BANK[k] ? QUIZ_BANK[k].length : 0;
        return `<option value="${escapeHtml(k)}">${escapeHtml(k)} (${meta.nameBn || ''} — ${cnt} Qs)</option>`;
      }).join('');
  }

  const examGroupSel = document.getElementById('examGroup');
  if (examGroupSel) examGroupSel.addEventListener('change', updateExamSubjectOptions);

  function startExam() {
    const group = document.getElementById('examGroup').value;
    const subject = document.getElementById('examSubject').value;
    const count = parseInt(document.getElementById('examCount').value, 10);
    const timeMin = parseInt(document.getElementById('examTime').value, 10);
    const negative = document.getElementById('examNegative').value === '1';

    // Collect questions
    let pool = [];
    if (subject && QUIZ_BANK[subject]) {
      pool = [...QUIZ_BANK[subject]];
    } else if (SUBJECT_GROUPS[group]) {
      pool = SUBJECT_GROUPS[group].keys.flatMap((k) => QUIZ_BANK[k] ? QUIZ_BANK[k].map((q) => ({...q, _subject: k})) : []);
    } else {
      pool = Object.keys(QUIZ_BANK).flatMap((k) => QUIZ_BANK[k].map((q) => ({...q, _subject: k})));
    }
    if (pool.length === 0) {
      alert('No questions available for this selection.');
      return;
    }
    // Shuffle and take count
    const shuffled = pool.sort(() => Math.random() - 0.5);
    const questions = shuffled.slice(0, Math.min(count, shuffled.length));

    currentExam = {
      questions,
      index: 0,
      answers: new Array(questions.length).fill(null),
      negative,
      timeLimit: timeMin * 60 * 1000,
      timeLeft: timeMin * 60 * 1000,
      startTime: Date.now(),
    };
    document.getElementById('examSetup').classList.add('hidden');
    document.getElementById('examResult').classList.add('hidden');
    if (document.getElementById('examWrongReview')) document.getElementById('examWrongReview').classList.add('hidden');
    document.getElementById('examPlay').classList.remove('hidden');
    renderExamQuestion();
    renderExamQuestionGrid();
    startExamTimer();
  }

  const startExamBtn = document.getElementById('startExamBtn');
  if (startExamBtn) startExamBtn.addEventListener('click', startExam);

  function renderExamQuestion() {
    const e = currentExam;
    const q = e.questions[e.index];
    const subjLabel = q._subject || 'Mixed';
    document.getElementById('examSubjectLabel').textContent = subjLabel + (e.negative ? ' (−0.25)' : '');
    document.getElementById('examProgress').textContent = `Q ${e.index + 1} / ${e.questions.length}`;
    const answered = e.answers.filter((a) => a !== null).length;
    document.getElementById('examScore').textContent = `Answered: ${answered}`;
    document.getElementById('examQuestion').innerHTML = bilingualQuestionHtml(q);
    const opts = document.getElementById('examOptions');
    opts.innerHTML = q.options.map((o, i) => {
      const selected = e.answers[e.index] === i ? ' selected' : '';
      return `<button class="option-btn${selected}" data-i="${i}">${bilingualOptionHtml(o, (q.optionsEn && q.optionsEn[i]) || '')}</button>`;
    }).join('');
    opts.querySelectorAll('.option-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const i = +btn.dataset.i;
        if (e.answers[e.index] === i) {
          // Deselect on second click
          e.answers[e.index] = null;
        } else {
          e.answers[e.index] = i;
        }
        renderExamQuestion();
        renderExamQuestionGrid();
      });
    });
  }

  function renderExamQuestionGrid() {
    const e = currentExam;
    const grid = document.getElementById('examQuestionGrid');
    if (!grid) return;
    grid.innerHTML = e.questions.map((_, i) => {
      let cls = 'qcell';
      if (i === e.index) cls += ' current';
      if (e.answers[i] !== null) cls += ' answered';
      return `<button class="${cls}" data-i="${i}">${i + 1}</button>`;
    }).join('');
    grid.querySelectorAll('.qcell').forEach((btn) => {
      btn.addEventListener('click', () => {
        e.index = +btn.dataset.i;
        renderExamQuestion();
        renderExamQuestionGrid();
      });
    });
  }

  const examPrevBtn = document.getElementById('examPrev');
  if (examPrevBtn) examPrevBtn.addEventListener('click', () => {
    if (!currentExam) return;
    if (currentExam.index > 0) {
      currentExam.index--;
      renderExamQuestion();
      renderExamQuestionGrid();
    }
  });
  const examNextBtn = document.getElementById('examNext');
  if (examNextBtn) examNextBtn.addEventListener('click', () => {
    if (!currentExam) return;
    if (currentExam.index < currentExam.questions.length - 1) {
      currentExam.index++;
      renderExamQuestion();
      renderExamQuestionGrid();
    } else {
      // Last question — prompt submit
      if (confirm('This is the last question. Submit exam?')) finishExam();
    }
  });
  const examSkipBtn = document.getElementById('examSkip');
  if (examSkipBtn) examSkipBtn.addEventListener('click', () => {
    if (!currentExam) return;
    currentExam.answers[currentExam.index] = null;
    if (currentExam.index < currentExam.questions.length - 1) {
      currentExam.index++;
      renderExamQuestion();
      renderExamQuestionGrid();
    }
  });
  const examSubmitBtn = document.getElementById('examSubmit');
  if (examSubmitBtn) examSubmitBtn.addEventListener('click', () => {
    if (!currentExam) return;
    const answered = currentExam.answers.filter((a) => a !== null).length;
    const unanswered = currentExam.questions.length - answered;
    if (unanswered > 0) {
      if (!confirm(`You have ${unanswered} unanswered question(s). Submit anyway?`)) return;
    }
    finishExam();
  });

  function startExamTimer() {
    if (examTimerId) clearInterval(examTimerId);
    if (!currentExam.timeLimit) {
      document.getElementById('examTimer').textContent = '⏱ No timer';
      return;
    }
    updateExamTimerDisplay();
    examTimerId = setInterval(() => {
      currentExam.timeLeft -= 1000;
      if (currentExam.timeLeft <= 0) {
        currentExam.timeLeft = 0;
        clearInterval(examTimerId);
        alert('Time is up! Submitting your exam.');
        finishExam();
        return;
      }
      updateExamTimerDisplay();
    }, 1000);
  }

  function updateExamTimerDisplay() {
    const t = Math.max(0, currentExam.timeLeft);
    const mins = Math.floor(t / 60000);
    const secs = Math.floor((t % 60000) / 1000);
    const el = document.getElementById('examTimer');
    el.textContent = '⏱ ' + String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');
    if (t < 60000) el.classList.add('timer-warning');
    else el.classList.remove('timer-warning');
  }

  function finishExam() {
    if (examTimerId) { clearInterval(examTimerId); examTimerId = null; }
    const e = currentExam;
    let correct = 0, wrong = 0, skipped = 0;
    const wrongList = [];
    e.questions.forEach((q, i) => {
      const a = e.answers[i];
      if (a === null) {
        skipped++;
      } else if (a === q.answer) {
        correct++;
      } else {
        wrong++;
        wrongList.push({ q, selected: a, correct: q.answer });
      }
    });
    const net = e.negative ? correct - wrong * 0.25 : correct;
    const pct = Math.round((correct / e.questions.length) * 100);
    const scoreText = e.negative
      ? `Net: ${net.toFixed(2)} | Correct: ${correct} | Wrong: ${wrong} (−0.25) | Skipped: ${skipped} | Total: ${e.questions.length}`
      : `Correct: ${correct} | Wrong: ${wrong} | Skipped: ${skipped} | Total: ${e.questions.length} (${pct}%)`;

    document.getElementById('examPlay').classList.add('hidden');
    document.getElementById('examResult').classList.remove('hidden');
    document.getElementById('examResultScore').textContent = scoreText;
    let msg = 'Keep practicing! অনুশীলন চালিয়ে যান।';
    if (pct === 100) msg = 'Perfect score! অসাধারণ! 🎉';
    else if (pct >= 80) msg = 'Excellent — you are well prepared! 👏';
    else if (pct >= 60) msg = 'Good effort. Review wrong answers and try again.';
    else if (pct >= 40) msg = 'Needs improvement. Focus on weak topics.';
    else msg = 'Keep practicing — review the explanations and retry.';
    document.getElementById('examResultMessage').textContent = msg;

    // Store for wrong-answer review
    currentExam.wrongList = wrongList;
    currentExam.result = { correct, wrong, skipped, net, pct };

    // Save to history
    state.quizHistory.push({
      subject: 'Exam: ' + (document.getElementById('examGroup').selectedOptions[0].textContent),
      score: net,
      total: e.questions.length,
      date: todayStr(),
    });
    updateStreak();
    addActivity(`Exam: ${e.questions.length} questions, net ${net.toFixed(2)}`);
    saveData();
  }

  const examRetryBtn = document.getElementById('examRetry');
  if (examRetryBtn) examRetryBtn.addEventListener('click', () => {
    renderExamSetup();
  });
  const examHomeBtn = document.getElementById('examHome');
  if (examHomeBtn) examHomeBtn.addEventListener('click', () => {
    renderExamSetup();
  });
  const examReviewWrongBtn = document.getElementById('examReviewWrong');
  if (examReviewWrongBtn) examReviewWrongBtn.addEventListener('click', () => {
    if (!currentExam || !currentExam.wrongList || !currentExam.wrongList.length) {
      alert('No wrong answers to review. Perfect!');
      return;
    }
    document.getElementById('examResult').classList.add('hidden');
    document.getElementById('examWrongReview').classList.remove('hidden');
    const list = document.getElementById('examWrongList');
    list.innerHTML = currentExam.wrongList.map((item, idx) => {
      const q = item.q;
      return `<div class="wrong-item">
        <div class="wrong-q-num">Q${idx + 1}</div>
        <div class="wrong-q-text">${bilingualQuestionHtml(q)}</div>
        <div class="wrong-options">
          ${q.options.map((o, i) => {
            let cls = 'wrong-opt';
            if (i === item.correct) cls = 'wrong-opt correct';
            else if (i === item.selected) cls = 'wrong-opt wrong';
            const enTxt = (q.optionsEn && q.optionsEn[i]) ? `<span class="opt-en">${escapeHtml(q.optionsEn[i])}</span>` : '';
            return `<div class="${cls}"><span class="opt-bn">${escapeHtml(o)}</span>${enTxt}</div>`;
          }).join('')}
        </div>
        <div class="wrong-explain">${bilingualExplainHtml(q.explain, q.explainEn)}</div>
      </div>`;
    }).join('');
  });
  const examRetryFromReviewBtn = document.getElementById('examRetryFromReview');
  if (examRetryFromReviewBtn) examRetryFromReviewBtn.addEventListener('click', () => {
    renderExamSetup();
  });
  const examBackToResultBtn = document.getElementById('examBackToResult');
  if (examBackToResultBtn) examBackToResultBtn.addEventListener('click', () => {
    document.getElementById('examWrongReview').classList.add('hidden');
    document.getElementById('examResult').classList.remove('hidden');
  });

  // ---------- Memories (Flashcards + spaced repetition) ----------
  let reviewQueue = [];
  let reviewIndex = 0;

  function renderMemories() {
    const sel = document.getElementById('deckSelect');
    const deckInput = document.getElementById('cardDeckInput');
    const decks = state.decks;
    sel.innerHTML = '<option value="all">All decks</option>' +
      decks.map((d) => `<option value="${d.id}">${escapeHtml(d.name)}</option>`).join('');
    deckInput.innerHTML = decks.map((d) => `<option value="${d.id}">${escapeHtml(d.name)}</option>`).join('');
    renderCardList();
    document.getElementById('cardReview').classList.add('hidden');
    document.getElementById('cardListView').classList.remove('hidden');
  }

  function renderCardList() {
    const deckId = document.getElementById('deckSelect').value;
    let cards = state.cards;
    if (deckId !== 'all') cards = cards.filter((c) => c.deckId === deckId);
    const list = document.getElementById('cardList');
    if (cards.length === 0) {
      list.innerHTML = '<p style="color:var(--text-muted)">No cards in this deck.</p>';
      return;
    }
    list.innerHTML = cards.map((c) => `
      <div class="card-item">
        <span class="front-preview">${escapeHtml(c.front)}</span>
        <span class="card-btns">
          <button class="btn" data-edit="${c.id}">Edit</button>
          <button class="btn danger" data-del="${c.id}">Del</button>
        </span>
      </div>
    `).join('');
    list.querySelectorAll('[data-edit]').forEach((b) => b.addEventListener('click', () => openCardModal(b.dataset.edit)));
    list.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', () => {
      if (confirm('Delete this card?')) {
        state.cards = state.cards.filter((c) => c.id !== b.dataset.del);
        saveData();
        renderCardList();
      }
    }));
  }

  document.getElementById('deckSelect').addEventListener('change', renderCardList);

  document.getElementById('startReview').addEventListener('click', () => {
    const deckId = document.getElementById('deckSelect').value;
    const now = Date.now();
    reviewQueue = state.cards.filter((c) => {
      if (deckId !== 'all' && c.deckId !== deckId) return false;
      return c.due <= now;
    });
    if (reviewQueue.length === 0) {
      // If none due, take all from deck for practice
      reviewQueue = state.cards.filter((c) => deckId === 'all' || c.deckId === deckId);
    }
    if (reviewQueue.length === 0) {
      alert('No cards to review. Add some first!');
      return;
    }
    reviewQueue = reviewQueue.sort(() => Math.random() - 0.5);
    reviewIndex = 0;
    document.getElementById('cardListView').classList.add('hidden');
    document.getElementById('cardReview').classList.remove('hidden');
    showReviewCard();
  });

  function showReviewCard() {
    if (reviewIndex >= reviewQueue.length) {
      document.getElementById('cardReview').classList.add('hidden');
      document.getElementById('cardListView').classList.remove('hidden');
      addActivity(`Reviewed ${reviewQueue.length} flashcards`);
      updateStreak();
      renderCardList();
      alert('Review complete! Great work.');
      return;
    }
    const card = reviewQueue[reviewIndex];
    document.getElementById('flashcard').classList.remove('flipped');
    document.getElementById('cardFront').textContent = card.front;
    document.getElementById('cardBack').textContent = card.back;
    document.getElementById('reviewCount').textContent = `${reviewQueue.length - reviewIndex} remaining`;
  }

  document.getElementById('flipBtn').addEventListener('click', () => {
    document.getElementById('flashcard').classList.toggle('flipped');
  });
  document.getElementById('flashcard').addEventListener('click', () => {
    document.getElementById('flashcard').classList.toggle('flipped');
  });

  // Simple SM-2 inspired spacing
  function scheduleCard(card, remembered) {
    if (remembered) {
      card.reps = (card.reps || 0) + 1;
      card.ease = Math.min(3, (card.ease || 2.5) + 0.1);
      card.interval = card.reps === 1 ? 1 : card.reps === 2 ? 3 : Math.round(card.interval * card.ease);
    } else {
      card.reps = 0;
      card.ease = Math.max(1.3, (card.ease || 2.5) - 0.2);
      card.interval = 1;
    }
    card.due = Date.now() + card.interval * 24 * 60 * 60 * 1000;
  }

  document.getElementById('rememberBtn').addEventListener('click', () => {
    const card = reviewQueue[reviewIndex];
    scheduleCard(card, true);
    // Update in state
    const idx = state.cards.findIndex((c) => c.id === card.id);
    if (idx >= 0) state.cards[idx] = card;
    saveData();
    reviewIndex++;
    showReviewCard();
  });

  document.getElementById('forgotBtn').addEventListener('click', () => {
    const card = reviewQueue[reviewIndex];
    scheduleCard(card, false);
    const idx = state.cards.findIndex((c) => c.id === card.id);
    if (idx >= 0) state.cards[idx] = card;
    saveData();
    // Put back at end for another pass
    reviewQueue.push(card);
    reviewIndex++;
    showReviewCard();
  });

  // Card modal
  let editingCardId = null;
  const cardModal = document.getElementById('cardModal');

  function openCardModal(id) {
    editingCardId = id || null;
    document.getElementById('cardModalTitle').textContent = id ? 'Edit Card' : 'New Card';
    if (id) {
      const c = state.cards.find((x) => x.id === id);
      document.getElementById('cardFrontInput').value = c.front;
      document.getElementById('cardBackInput').value = c.back;
      document.getElementById('cardDeckInput').value = c.deckId;
    } else {
      document.getElementById('cardFrontInput').value = '';
      document.getElementById('cardBackInput').value = '';
    }
    cardModal.classList.remove('hidden');
  }

  document.getElementById('addCardBtn').addEventListener('click', () => openCardModal(null));
  document.getElementById('cardModalCancel').addEventListener('click', () => cardModal.classList.add('hidden'));
  document.getElementById('cardModalSave').addEventListener('click', () => {
    const front = document.getElementById('cardFrontInput').value.trim();
    const back = document.getElementById('cardBackInput').value.trim();
    const deckId = document.getElementById('cardDeckInput').value;
    if (!front || !back) { alert('Front and back are required.'); return; }
    if (editingCardId) {
      const c = state.cards.find((x) => x.id === editingCardId);
      c.front = front; c.back = back; c.deckId = deckId;
    } else {
      state.cards.push({
        id: uid(), deckId, front, back,
        interval: 1, ease: 2.5, due: Date.now(), reps: 0,
      });
      addActivity('Added a new flashcard');
    }
    saveData();
    cardModal.classList.add('hidden');
    renderCardList();
  });

  // Deck management
  const deckModal = document.getElementById('deckModal');
  document.getElementById('manageDecksBtn').addEventListener('click', () => {
    renderDeckList();
    deckModal.classList.remove('hidden');
  });
  document.getElementById('deckModalClose').addEventListener('click', () => {
    deckModal.classList.add('hidden');
    renderMemories();
  });

  function renderDeckList() {
    const el = document.getElementById('deckList');
    el.innerHTML = state.decks.map((d) => {
      const count = state.cards.filter((c) => c.deckId === d.id).length;
      return `<div class="card-item"><span>${escapeHtml(d.name)} (${count})</span>
        <button class="btn danger" data-deldeck="${d.id}">Delete</button></div>`;
    }).join('');
    el.querySelectorAll('[data-deldeck]').forEach((b) => {
      b.addEventListener('click', () => {
        if (!confirm('Delete deck and all its cards?')) return;
        state.cards = state.cards.filter((c) => c.deckId !== b.dataset.deldeck);
        state.decks = state.decks.filter((d) => d.id !== b.dataset.deldeck);
        saveData();
        renderDeckList();
      });
    });
  }

  document.getElementById('addDeckBtn').addEventListener('click', () => {
    const name = document.getElementById('newDeckName').value.trim();
    if (!name) return;
    state.decks.push({ id: uid(), name });
    document.getElementById('newDeckName').value = '';
    saveData();
    renderDeckList();
  });

  // ---------- Notes ----------
  let currentNoteId = null;

  function renderNotes() {
    const subjSel = document.getElementById('noteSubject');
    const subjects = ['Biology', 'Chemistry', 'History', 'Math', 'Physics', 'Literature', 'Other'];
    subjSel.innerHTML = '<option value="">No subject</option>' +
      subjects.map((s) => `<option value="${s}">${s}</option>`).join('');

    const list = document.getElementById('notesList');
    if (state.notes.length === 0) {
      list.innerHTML = '<p style="color:var(--text-muted);padding:0.5rem">No notes yet</p>';
    } else {
      list.innerHTML = [...state.notes].sort((a, b) => b.updated - a.updated).map((n) => `
        <div class="note-item ${n.id === currentNoteId ? 'active' : ''}" data-id="${n.id}">
          <div>${escapeHtml(n.title || 'Untitled')}</div>
          <div class="note-date">${new Date(n.updated).toLocaleDateString()}</div>
        </div>
      `).join('');
      list.querySelectorAll('.note-item').forEach((el) => {
        el.addEventListener('click', () => selectNote(el.dataset.id));
      });
    }
  }

  function selectNote(id) {
    currentNoteId = id;
    const n = state.notes.find((x) => x.id === id);
    if (!n) return;
    document.getElementById('noteTitle').value = n.title;
    document.getElementById('noteBody').value = n.body;
    document.getElementById('noteSubject').value = n.subject || '';
    document.getElementById('noteMeta').textContent = `Last saved: ${new Date(n.updated).toLocaleString()}`;
    renderNotes();
  }

  document.getElementById('newNoteBtn').addEventListener('click', () => {
    currentNoteId = null;
    document.getElementById('noteTitle').value = '';
    document.getElementById('noteBody').value = '';
    document.getElementById('noteSubject').value = '';
    document.getElementById('noteMeta').textContent = 'New note — not saved yet';
    renderNotes();
  });

  document.getElementById('saveNoteBtn').addEventListener('click', () => {
    const title = document.getElementById('noteTitle').value.trim();
    const body = document.getElementById('noteBody').value.trim();
    const subject = document.getElementById('noteSubject').value;
    if (!title && !body) { alert('Write something first.'); return; }
    if (currentNoteId) {
      const n = state.notes.find((x) => x.id === currentNoteId);
      n.title = title; n.body = body; n.subject = subject; n.updated = Date.now();
    } else {
      const note = { id: uid(), title, body, subject, updated: Date.now(), created: Date.now() };
      state.notes.push(note);
      currentNoteId = note.id;
      addActivity('Created note: ' + (title || 'Untitled'));
    }
    saveData();
    document.getElementById('noteMeta').textContent = `Saved at ${new Date().toLocaleString()}`;
    renderNotes();
  });

  document.getElementById('deleteNoteBtn').addEventListener('click', () => {
    if (!currentNoteId) return;
    if (!confirm('Delete this note?')) return;
    state.notes = state.notes.filter((n) => n.id !== currentNoteId);
    currentNoteId = null;
    document.getElementById('noteTitle').value = '';
    document.getElementById('noteBody').value = '';
    document.getElementById('noteMeta').textContent = '';
    saveData();
    renderNotes();
  });

  // ---------- Planner ----------
  function renderPlanner() {
    const today = todayStr();
    // Exams
    const examList = document.getElementById('examList');
    const exams = [...state.exams].sort((a, b) => a.date.localeCompare(b.date));
    if (exams.length === 0) {
      examList.innerHTML = '<p style="color:var(--text-muted);font-size:0.9rem">No exams scheduled</p>';
    } else {
      examList.innerHTML = exams.map((e) => {
        const days = daysBetween(today, e.date);
        const label = days < 0 ? 'Past' : days === 0 ? 'Today' : days + 'd left';
        return `<div class="exam-item">
          <span><strong>${escapeHtml(e.name)}</strong><br><small style="color:var(--text-muted)">${e.date}</small></span>
          <span class="days-left">${label}</span>
          <button class="btn danger" data-delexam="${e.id}" style="padding:0.25rem 0.5rem;font-size:0.75rem">✕</button>
        </div>`;
      }).join('');
      examList.querySelectorAll('[data-delexam]').forEach((b) => {
        b.addEventListener('click', () => {
          state.exams = state.exams.filter((e) => e.id !== b.dataset.delexam);
          saveData();
          renderPlanner();
          renderDashboard();
        });
      });
    }

    // Tasks
    const taskList = document.getElementById('taskList');
    const tasks = state.tasks.filter((t) => t.date === today || !t.done);
    if (tasks.length === 0) {
      taskList.innerHTML = '<li style="color:var(--text-muted)">No tasks for today</li>';
    } else {
      taskList.innerHTML = tasks.map((t) => `
        <li class="${t.done ? 'done' : ''}">
          <input type="checkbox" data-task="${t.id}" ${t.done ? 'checked' : ''} />
          <span>${escapeHtml(t.text)}</span>
          <button class="btn danger" data-deltask="${t.id}" style="margin-left:auto;padding:0.2rem 0.4rem;font-size:0.7rem">✕</button>
        </li>
      `).join('');
      taskList.querySelectorAll('[data-task]').forEach((cb) => {
        cb.addEventListener('change', () => {
          const t = state.tasks.find((x) => x.id === cb.dataset.task);
          if (t) { t.done = cb.checked; saveData(); renderPlanner(); }
        });
      });
      taskList.querySelectorAll('[data-deltask]').forEach((b) => {
        b.addEventListener('click', () => {
          state.tasks = state.tasks.filter((t) => t.id !== b.dataset.deltask);
          saveData();
          renderPlanner();
        });
      });
    }

    document.getElementById('goalMinutes').value = state.goalMinutes;
  }

  document.getElementById('addTaskBtn').addEventListener('click', () => {
    const text = document.getElementById('taskInput').value.trim();
    if (!text) return;
    state.tasks.push({ id: uid(), text, done: false, date: todayStr() });
    document.getElementById('taskInput').value = '';
    saveData();
    renderPlanner();
  });
  document.getElementById('taskInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('addTaskBtn').click();
  });

  document.getElementById('saveGoalBtn').addEventListener('click', () => {
    state.goalMinutes = Math.max(15, parseInt(document.getElementById('goalMinutes').value, 10) || 60);
    saveData();
    renderDashboard();
    alert('Daily goal saved: ' + state.goalMinutes + ' minutes');
  });

  document.getElementById('logStudyBtn').addEventListener('click', () => {
    const mins = parseInt(document.getElementById('logMinutes').value, 10);
    if (!mins || mins < 1) { alert('Enter minutes studied.'); return; }
    const today = todayStr();
    state.studyLog[today] = (state.studyLog[today] || 0) + mins;
    document.getElementById('logMinutes').value = '';
    updateStreak();
    addActivity(`Studied ${mins} minutes`);
    saveData();
    renderDashboard();
    renderProgress();
    alert(`Logged ${mins} minutes. Total today: ${state.studyLog[today]} min`);
  });

  // Exam modal
  const examModal = document.getElementById('examModal');
  document.getElementById('addExamBtn').addEventListener('click', () => {
    document.getElementById('examName').value = '';
    document.getElementById('examDate').value = '';
    examModal.classList.remove('hidden');
  });
  document.getElementById('examModalCancel').addEventListener('click', () => examModal.classList.add('hidden'));
  document.getElementById('examModalSave').addEventListener('click', () => {
    const name = document.getElementById('examName').value.trim();
    const date = document.getElementById('examDate').value;
    if (!name || !date) { alert('Name and date required.'); return; }
    state.exams.push({ id: uid(), name, date });
    saveData();
    examModal.classList.add('hidden');
    renderPlanner();
    renderDashboard();
  });

  // ---------- Progress ----------
  function renderProgress() {
    let total = 0;
    Object.values(state.studyLog).forEach((m) => { total += m; });
    document.getElementById('totalMinutes').textContent = total + ' min';
    document.getElementById('progStreak').textContent = state.streak + ' days';
    document.getElementById('progQuizzes').textContent = state.quizHistory.length;
    const mastered = state.cards.filter((c) => (c.reps || 0) >= 3).length;
    document.getElementById('progMastered').textContent = mastered;

    // History bars last 14 days
    const bars = document.getElementById('historyBars');
    const days = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      days.push(d.toISOString().slice(0, 10));
    }
    const maxM = Math.max(1, ...days.map((d) => state.studyLog[d] || 0));
    bars.innerHTML = days.map((d) => {
      const m = state.studyLog[d] || 0;
      const h = Math.max(4, (m / maxM) * 100);
      const label = d.slice(5);
      return `<div class="hist-bar" style="height:${h}%" title="${m} min"><span>${label}</span></div>`;
    }).join('');

    // Quiz by subject
    const bySubj = {};
    state.quizHistory.forEach((h) => {
      if (!bySubj[h.subject]) bySubj[h.subject] = { score: 0, total: 0, n: 0 };
      bySubj[h.subject].score += h.score;
      bySubj[h.subject].total += h.total;
      bySubj[h.subject].n += 1;
    });
    const qs = document.getElementById('quizStats');
    if (Object.keys(bySubj).length === 0) {
      qs.innerHTML = '<p style="color:var(--text-muted)">No quizzes taken yet</p>';
    } else {
      qs.innerHTML = Object.entries(bySubj).map(([s, v]) => {
        const pct = Math.round((v.score / v.total) * 100);
        return `<div class="quiz-stat-row"><span>${s} (${v.n} quizzes)</span><span style="color:var(--neon)">${pct}% avg</span></div>`;
      }).join('');
    }
  }

  // ---------- Resources ----------
  function renderResources() {
    const subjects = ['Biology', 'Chemistry', 'Physics', 'Calculus', 'World History', 'Python programming', 'Organic Chemistry'];
    document.getElementById('quickLinks').innerHTML = subjects.map((s) => {
      const q = encodeURIComponent(s + ' textbook');
      const yq = encodeURIComponent(s + ' explained');
      return `<a href="https://www.google.com/search?tbm=bks&q=${q}" target="_blank" rel="noopener">📚 ${s} Books</a>
              <a href="https://www.youtube.com/results?search_query=${yq}" target="_blank" rel="noopener">▶ ${s} Videos</a>`;
    }).join('');
  }

  document.getElementById('searchBooks').addEventListener('click', () => {
    const q = document.getElementById('booksQuery').value.trim();
    if (!q) return;
    const url = `https://www.google.com/search?tbm=bks&q=${encodeURIComponent(q)}`;
    document.getElementById('booksLinks').innerHTML =
      `<a href="${url}" target="_blank" rel="noopener">Open Google Books results for “${escapeHtml(q)}”</a>`;
    window.open(url, '_blank', 'noopener');
  });

  document.getElementById('searchYT').addEventListener('click', () => {
    const q = document.getElementById('ytQuery').value.trim();
    if (!q) return;
    const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`;
    document.getElementById('ytLinks').innerHTML =
      `<a href="${url}" target="_blank" rel="noopener">Open YouTube results for “${escapeHtml(q)}”</a>`;
    window.open(url, '_blank', 'noopener');
  });

  // ---------- Ask Google (Text Q&A, Bangla + English) ----------
  function googleSearchUrl(question, preferBangla) {
    const q = preferBangla ? question + ' বাংলা' : question;
    return 'https://www.google.com/search?q=' + encodeURIComponent(q) + '&hl=' + (preferBangla ? 'bn' : 'en');
  }

  function saveGoogleQuestion(text) {
    if (!state.googleQuestions) state.googleQuestions = [];
    state.googleQuestions = state.googleQuestions.filter((x) => x !== text);
    state.googleQuestions.unshift(text);
    if (state.googleQuestions.length > 15) state.googleQuestions.pop();
    saveData();
  }

  function renderAskGoogle() {
    const list = document.getElementById('recentQuestions');
    const items = state.googleQuestions || [];
    if (items.length === 0) {
      list.innerHTML = '<li style="color:var(--text-muted)">No recent questions yet</li>';
      return;
    }
    list.innerHTML = items.map((q, i) =>
      `<li><span>${escapeHtml(q)}</span>
        <button type="button" class="btn" data-rq="${i}">Ask again</button></li>`
    ).join('');
    list.querySelectorAll('[data-rq]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const text = items[+btn.dataset.rq];
        document.getElementById('googleQuestion').value = text;
        runGoogleSearch(false);
      });
    });
  }

  function runGoogleSearch(preferBangla) {
    const text = document.getElementById('googleQuestion').value.trim();
    if (!text) {
      alert('Please type a question first.\nআগে একটি প্রশ্ন লিখুন।');
      return;
    }
    const url = googleSearchUrl(text, preferBangla);
    const box = document.getElementById('googleAnswerBox');
    box.innerHTML =
      `<p class="q-preview"><strong>Question:</strong> ${escapeHtml(text)}</p>
       <p><a href="${url}" target="_blank" rel="noopener">Open Google answer →</a></p>
       <p class="muted" style="margin-top:0.5rem;font-size:0.85rem">Answer is provided by Google Search (opens in a new tab).</p>`;
    saveGoogleQuestion(text);
    addActivity('Asked Google: ' + text.slice(0, 40));
    renderAskGoogle();
    window.open(url, '_blank', 'noopener');
  }

  document.getElementById('askGoogleBtn').addEventListener('click', () => runGoogleSearch(false));
  document.getElementById('askGoogleBnBtn').addEventListener('click', () => runGoogleSearch(true));
  document.getElementById('clearQuestionBtn').addEventListener('click', () => {
    document.getElementById('googleQuestion').value = '';
    document.getElementById('googleAnswerBox').innerHTML =
      '<p class="muted">Ask a question above. The Google Search link will appear here.</p>';
  });
  document.querySelectorAll('.g-example').forEach((chip) => {
    chip.addEventListener('click', () => {
      document.getElementById('googleQuestion').value = chip.dataset.q;
    });
  });

  // ---------- Settings ----------
  document.getElementById('reduceMotion').checked = state.settings.reduceMotion;
  if (state.settings.reduceMotion) document.body.classList.add('reduce-motion');

  document.getElementById('reduceMotion').addEventListener('change', (e) => {
    state.settings.reduceMotion = e.target.checked;
    document.body.classList.toggle('reduce-motion', e.target.checked);
    saveData();
  });

  // Gemini key UI — never display the raw key after save
  const geminiKeyInput = document.getElementById('geminiKeyInput');
  const geminiModelSel = document.getElementById('geminiModel');
  if (geminiKeyInput) {
    geminiKeyInput.value = '';
    geminiKeyInput.placeholder = (state.settings.geminiKey || '').trim()
      ? 'Key saved — type a new key only to replace'
      : 'AIza… (kept private on this device)';
    if (geminiModelSel) geminiModelSel.value = state.settings.geminiModel || 'gemini-2.0-flash';
    updateGeminiStatus();
    updateAssistantSubtitle();

    document.getElementById('saveGeminiKey').addEventListener('click', () => {
      const typed = (geminiKeyInput.value || '').trim();
      if (typed) state.settings.geminiKey = typed;
      // empty field + existing key = keep existing (user did not re-type it)
      state.settings.geminiModel = geminiModelSel ? geminiModelSel.value : 'gemini-2.0-flash';
      saveData();
      geminiKeyInput.value = '';
      geminiKeyInput.placeholder = (state.settings.geminiKey || '').trim()
        ? 'Key saved — type a new key only to replace'
        : 'AIza… (kept private on this device)';
      updateGeminiStatus();
      updateAssistantSubtitle();
      alert((state.settings.geminiKey || '').trim() ? 'Key saved privately on this device.' : 'No key stored.');
    });

    document.getElementById('clearGeminiKey').addEventListener('click', () => {
      geminiKeyInput.value = '';
      state.settings.geminiKey = '';
      saveData();
      geminiKeyInput.placeholder = 'AIza… (kept private on this device)';
      updateGeminiStatus();
      updateAssistantSubtitle();
    });

    document.getElementById('testGeminiKey').addEventListener('click', async () => {
      const typed = (geminiKeyInput.value || '').trim();
      if (typed) state.settings.geminiKey = typed;
      state.settings.geminiModel = geminiModelSel ? geminiModelSel.value : 'gemini-2.0-flash';
      if (!(state.settings.geminiKey || '').trim()) {
        updateGeminiStatus('Status: enter a key first');
        return;
      }
      updateGeminiStatus('Status: testing…');
      try {
        await callGemini('Reply with exactly: OK');
        geminiKeyInput.value = '';
        geminiKeyInput.placeholder = 'Key saved — type a new key only to replace';
        saveData();
        updateGeminiStatus('Status: connected (key not shown)');
        updateAssistantSubtitle();
      } catch (err) {
        updateGeminiStatus('Status: failed — ' + sanitizePublicError(err.message));
      }
    });
  }

  document.getElementById('exportData').addEventListener('click', () => {
    // Strip secrets before any file leaves the device
    const safe = JSON.parse(JSON.stringify(state));
    if (safe.settings) {
      safe.settings.geminiKey = '';
      safe.settings._keyExcluded = true;
    }
    const blob = new Blob([JSON.stringify(safe, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'studyverse-backup.json';
    a.click();
    URL.revokeObjectURL(a.href);
  });

  document.getElementById('importData').addEventListener('click', () => {
    document.getElementById('importFile').click();
  });
  document.getElementById('importFile').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data.notes || !data.cards) throw new Error('Invalid file');
        state = { ...defaultData(), ...data };
        saveData();
        alert('Data imported successfully. Reloading…');
        location.reload();
      } catch (err) {
        alert('Import failed: invalid JSON or format.');
      }
    };
    reader.readAsText(file);
  });

  document.getElementById('resetData').addEventListener('click', () => {
    if (!confirm('This will erase ALL notes, cards, progress, and settings. Continue?')) return;
    if (!confirm('Really sure? This cannot be undone.')) return;
    localStorage.removeItem(STORAGE_KEY);
    location.reload();
  });

  // ---------- Init ----------
  function init() {
    // Seed sample notes if empty
    if (state.notes.length === 0) {
      state.notes.push({
        id: uid(),
        title: 'Welcome to STUDY VERSE',
        body: 'This is a sample note. You can edit or delete it.\n\nTips:\n• Use Memories for flashcards\n• Log study time in the Planner\n• Ask the Assistant when you need help',
        subject: 'Other',
        updated: Date.now(),
        created: Date.now(),
      });
      saveData();
    }
    renderDashboard();
    showSection('dashboard');
  }

  init();
})();
