NavYuva Durga Puja Samiti - Final Secure/Print build

1. Upload this ZIP to your HTML-to-APK builder.
2. Publish firestore.rules in Firebase Console -> Firestore Database -> Rules.
3. Normal users can read only receipts whose ownerUid matches their Firebase UID or legacy receipts whose createdBy matches their own Login ID. Only Admin can update/delete receipts or manage users.
4. Print Receipt generates a print-only A4 receipt image. Save PDF tries Android file picker/download/share and a PDF viewer fallback.
5. If the APK builder blocks downloads/popups/printing, use an Android WebView builder with download and print support; pure HTML cannot override those native restrictions.
