FORGE Gym Tracker - app package
1) Put this whole folder online (free): Netlify Drop (app.netlify.com/drop) - drag the folder in, you get an https link.
2) Open pwabuilder.com, paste that link, press Start, then Package for stores > Android.
3) Download the APK, copy it to your phone/tablet and install it (allow 'install unknown apps' when asked).
Your workout data is saved on the device you install it on.
