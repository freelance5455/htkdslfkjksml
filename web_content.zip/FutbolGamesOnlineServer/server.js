const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*', methods: ['GET','POST'] } });
const rooms = new Map();
function makeCode(){ for(let i=0;i<900;i++){const c=String(Math.floor(100+Math.random()*900));if(!rooms.has(c))return c;} return null; }
app.get('/', (_req,res)=>res.send('Futbol Games online room server is running.'));
io.on('connection', socket => {
 socket.on('create-room',()=>{
  const code=makeCode(); if(!code){socket.emit('room-error',{message:'Otaqlar doludur, sonra yenidən yoxla.'});return;}
  rooms.set(code,{players:[socket.id]}); socket.data.roomCode=code; socket.join(code); socket.emit('room-created',{code});
 });
 socket.on('join-room',({code}={})=>{
  const room=rooms.get(String(code||''));
  if(!/^\d{3}$/.test(String(code||''))||!room){socket.emit('room-error',{message:'Bu 3 rəqəmli kodla aktiv oda tapılmadı.'});return;}
  if(room.players.length>=2){socket.emit('room-error',{message:'Bu oda artıq 2 nəfərlə doludur.'});return;}
  if(room.players.includes(socket.id)){socket.emit('room-joined',{code});return;}
  room.players.push(socket.id);socket.data.roomCode=String(code);socket.join(String(code));socket.emit('room-joined',{code:String(code)});socket.to(String(code)).emit('opponent-joined');
 });
 socket.on('player-shot',({code,direction}={})=>{
  const room=rooms.get(String(code||'')); if(!room||!room.players.includes(socket.id))return;
  if(!['left','center','right'].includes(direction))return;
  socket.to(String(code)).emit('opponent-shot',{direction});
 });
 socket.on('disconnect',()=>{const code=socket.data.roomCode; if(!code)return;const room=rooms.get(code);if(!room)return;room.players=room.players.filter(id=>id!==socket.id);socket.to(code).emit('opponent-left');if(room.players.length===0)rooms.delete(code);});
});
const port=process.env.PORT||3000;server.listen(port,()=>console.log(`Futbol Games room server listening on ${port}`));
