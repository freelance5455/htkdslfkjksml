FUTBOL GAMES — 3 rəqəmli onlayn otaqlar

1) Bu qovluğu Node.js dəstəkləyən hosta (məsələn, Render kimi) yerləşdir.
2) Build command: npm install
3) Start command: npm start
4) Hostun verdiyi HTTPS ünvanını götür.
5) FutbolGames_OnlineRooms.html faylında bu sətri tap:
   const SERVER_URL='https://YOUR-SERVER-URL';
   YOUR-SERVER-URL hissəsini hostun HTTPS ünvanı ilə əvəz et.
6) HTML faylını yenidən Android WebView layihəsinə daxil et və ya brauzerdə aç.

Oda kodları 100–999 aralığında 3 rəqəmlidir, oda maksimum 2 nəfər qəbul edir.
Qeyd: Bu paket otaq yaratma/qoşulma və zərbə istiqamətinin rəqibə ötürülməsini təmin edən başlanğıc versiyadır. Tam real vaxt matç qaydaları üçün oyun nəticələri və növbə sistemi əlavə edilməlidir. Server internetdə yayımlanmadan fərqli Wi-Fi şəbəkələrində işləməyəcək.
