create table if not exists public.app_state_snapshots (
  company_id uuid primary key references public.companies(id) on delete cascade,
  state jsonb not null default '{}'::jsonb,
  schema_version text not null default '1.6.0',
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);
alter table public.app_state_snapshots enable row level security;
drop policy if exists app_state_select on public.app_state_snapshots;
drop policy if exists app_state_insert on public.app_state_snapshots;
drop policy if exists app_state_update on public.app_state_snapshots;
drop policy if exists app_state_delete on public.app_state_snapshots;
create policy app_state_select on public.app_state_snapshots for select to authenticated using (app.has_company_access(company_id));
create policy app_state_insert on public.app_state_snapshots for insert to authenticated with check (app.has_company_access(company_id) and app.can_write(company_id));
create policy app_state_update on public.app_state_snapshots for update to authenticated using (app.has_company_access(company_id) and app.can_write(company_id)) with check (app.has_company_access(company_id) and app.can_write(company_id));
create policy app_state_delete on public.app_state_snapshots for delete to authenticated using (app.can_manage_users(company_id));
