# Android build

این ماژول WebView پروژه `web/` را به‌صورت APK یونیورسال اجرا می‌کند.

- Java 17
- AGP 9.2.0
- Gradle 9.4.1
- compileSdk/targetSdk 36
- minSdk 23
- FileChooser برای XLSX/CSV/JSON
- AndroidBridge برای ذخیره خروجی‌ها در Downloads/MR-KHORASANI
