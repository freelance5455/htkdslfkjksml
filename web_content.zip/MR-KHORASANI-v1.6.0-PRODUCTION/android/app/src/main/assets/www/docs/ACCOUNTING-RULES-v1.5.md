# Accounting Rules — MR,KHORASANI v1.5

## Sales
- Debit cash/bank/receivable according to settlement.
- Credit sales revenue.
- Record VAT/indirect tax only when configured by the company.
- Record COGS and inventory reduction for stock sales.

## Sales Return
- Debit sales return.
- Debit tax reversal when applicable.
- Credit customer/cash/bank according to original settlement.
- Debit inventory.
- Credit COGS using the original sale cost when available.

## Purchase
- Debit inventory/expense according to the operation.
- Credit supplier/cash/bank according to settlement.
- Record deductible purchase tax when applicable.

## Purchase Return
- Debit supplier/cash/bank.
- Credit inventory or purchase-related account.
- Reverse deductible purchase tax when applicable.

## Checks
Cheque state transitions are stored as events. Sayyad number is exactly 16 numeric digits.

## Year-end
Temporary income, return, COGS and expense accounts are closed to profit/loss summary, then net profit/loss is transferred to retained earnings. Permanent accounts continue into the next fiscal year through an opening balance process.

## Costing methods
Supported setting values in the application:
- `WEIGHTED_AVERAGE`
- `FIFO`
- `STANDARD`
