# Excel Import Wizard

Templates are intentionally empty except for Persian column headers.

Files:
- `templates/قالب-ورود-اشخاص-v1.5.xlsx`
- `templates/قالب-ورود-کالاها-v1.5.xlsx`
- `templates/قالب-ورود-انبارها-v1.5.xlsx`

Validation includes duplicate codes, missing required fields, numeric validation, unsupported methods, and company/warehouse consistency. Import is previewed before commit.
