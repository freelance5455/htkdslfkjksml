# MR,KHORASANI v1.6.0

سامانه حسابداری و مدیریت مالی فارسی/RTL.

## Cloud
این نسخه به Supabase واقعی متصل است: Auth، شرکت/نقش، Snapshot چندشرکتی، RLS و Storage.

## Android
همان Web App داخل WebView اجرا می‌شود و پل `window.Android.saveFile` برای ذخیره مستقیم خروجی‌ها در Downloads/MR-KHORASANI دارد.

سامانه مؤدیان واقعی در این نسخه عمداً وجود ندارد.
