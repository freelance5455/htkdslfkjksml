# Android Storage Bridge

The web/PWA layer expects a native Android bridge when packaged as APK.

## Preferred bridge
`window.Android.saveFile(fileName, mimeType, base64, relativeDir)`

Recommended relative directory:
`Download/MR-KHORASANI/<Company>/<FiscalYear>/<Date>/`

The APK layer should implement the bridge with Android's official storage APIs and return a boolean success value. The web client has browser fallbacks for environments where the bridge is unavailable.

This ZIP is not an Android Studio project and therefore is not itself an installable APK.
