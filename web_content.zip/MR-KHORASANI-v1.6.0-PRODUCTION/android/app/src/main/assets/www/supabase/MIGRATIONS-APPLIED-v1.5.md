# Supabase migrations applied for MR,KHORASANI v1.5

Project Ref: `klomsegarpfdkhkmoazy`

Applied v1.5 migrations:

- `mrk_v1_5_finance_modules`
- `mrk_v1_5_security_and_rls`
- `mrk_v1_5_security_storage_cleanup`
- `mrk_v1_5_drop_legacy_broad_policies`
- `mrk_v1_5_accounting_rule_catalog`

Additional pre-existing migration specifically relevant to the requested cheque requirement:

- `change_check_sayyad_to_16_digits`

The live database currently exposes a 16-digit numeric constraint on `public.checks.check_no`.

## Important
Do not recreate these migrations blindly against another database without reviewing the base schema. This document records the live project state; it is not a replacement for a generated migration bundle.
