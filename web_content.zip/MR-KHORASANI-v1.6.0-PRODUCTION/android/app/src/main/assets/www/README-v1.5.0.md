# MR,KHORASANI v1.5.0

سامانه حسابداری و مدیریت مالی — فارسی / RTL

## اجرا
فایل `index.html` را از طریق یک static web server اجرا کنید. برای قابلیت PWA، HTTPS یا localhost توصیه می‌شود.

## فعال‌سازی اولیه دستگاه
رمز فعال‌سازی اولیه: `0371317037`

## قالب‌های Excel
قالب‌های خالی v1.5 در پوشه `templates` قرار دارند.

## Backend
Schema/RLS/Storage موردنیاز در Supabase پروژه MR-KHORASANI-Finance آماده شده است. جزئیات در `docs/SUPABASE-BACKEND-STATUS.md` آمده است.

## محدودیت مهم
این ZIP شامل Android Native/Gradle project نیست؛ برای APK Release باید از Capacitor/Android Studio/GitHub Actions/Replit در محیط دارای Android SDK استفاده شود.

اتصال واقعی به سامانه مؤدیان در این نسخه عمداً انجام نشده است.
