# Backend Status — Supabase

Project: MR-KHORASANI-Finance
Project Ref: `klomsegarpfdkhkmoazy`
Region: `eu-central-1`

## Tables added/extended in v1.5
- `inventory_opening_balances`
- `bank_reconciliations`
- `bank_reconciliation_lines`
- `projects`
- `budgets`
- `budget_lines`
- `fixed_assets`
- `fixed_asset_depreciation`
- `payroll_runs`
- `payroll_lines`
- `documents`
- `report_definitions`
- `backup_jobs`

Existing tenant tables such as `companies`, `company_members`, `parties`, `products`, `warehouses`, `transactions`, `journals`, `checks` remain the source schema.

## Security
- Company-level RLS is enabled for the new tenant tables.
- Audit log UPDATE/DELETE is blocked by database trigger.
- Daily closing is restricted server-side to OWNER / ADMIN / FINANCE.
- Private Storage buckets prepared: `mrk-documents`, `mrk-backups`.

## Important production note
The current single-file web client still contains an offline-first/local-state compatibility layer. The database schema, RLS and Storage infrastructure are real, but a full production login/session + bidirectional sync adapter is a separate integration step and should not be represented as completed until a real authenticated user session is exercised end-to-end.
