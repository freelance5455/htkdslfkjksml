package com.mrkhorasani.finance;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowInsets;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private static final int FILE_CHOOSER = 8016;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(android.graphics.Color.rgb(23,17,10));
        w.setNavigationBarColor(android.graphics.Color.rgb(23,17,10));
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(fileChooserCallback!=null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback=cb;
                Intent i=params.createIntent();
                i.addCategory(Intent.CATEGORY_OPENABLE);
                try{ startActivityForResult(i, FILE_CHOOSER); }catch(Exception e){ fileChooserCallback=null; return false; }
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER && fileChooserCallback!=null){
            Uri[] r=(resultCode==RESULT_OK && data!=null && data.getData()!=null)?new Uri[]{data.getData()}:null;
            fileChooserCallback.onReceiveValue(r); fileChooserCallback=null;
        }
    }

    @Override public void onBackPressed(){
        if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class AndroidBridge {
        @android.webkit.JavascriptInterface public String getDeviceId(){
            try{return Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);}catch(Exception e){return "";}
        }
        @android.webkit.JavascriptInterface public boolean saveFile(String fileName,String mime,String base64,String directory){
            try{
                byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                if(Build.VERSION.SDK_INT>=29){
                    android.content.ContentValues v=new android.content.ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME,fileName);
                    v.put(MediaStore.Downloads.MIME_TYPE,mime==null?"application/octet-stream":mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/MR-KHORASANI");
                    Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(uri==null)return false;
                    try(OutputStream os=getContentResolver().openOutputStream(uri)){if(os==null)return false;os.write(bytes);}
                    return true;
                }
                File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"MR-KHORASANI");
                if(!dir.exists() && !dir.mkdirs())return false;
                try(FileOutputStream fos=new FileOutputStream(new File(dir,fileName))){fos.write(bytes);}
                return true;
            }catch(Exception e){return false;}
        }
        @android.webkit.JavascriptInterface public boolean saveToDownloads(String fileName,String mime,String base64){return saveFile(fileName,mime,base64,"Download/MR-KHORASANI");}
        @android.webkit.JavascriptInterface public boolean writeFile(String path,String mime,String base64){
            String name=path==null?"file.bin":path.substring(path.lastIndexOf('/')+1);
            return saveFile(name,mime,base64,path);
        }
    }
}
