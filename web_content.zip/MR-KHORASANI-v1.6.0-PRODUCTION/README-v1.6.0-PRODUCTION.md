# MR,KHORASANI v1.6.0 — Production Cloud + Android Build Ready

این بسته بر پایه نسخه 1.5 ساخته شده و شامل Web/PWA، Cloud واقعی Supabase و سورس Android مستقل است.

## Cloud واقعی
- Supabase Auth برای ورود ابری
- تشخیص شرکت و نقش از `company_members`
- RLS بر اساس tenant
- Snapshot وضعیت شرکت در `app_state_snapshots`
- Storage خصوصی برای `mrk-documents` و `mrk-backups`
- کلید Service Role داخل اپلیکیشن وجود ندارد
- سامانه مؤدیان واقعی عمداً اضافه نشده است

## Web/PWA
فایل شروع: `web/index.html`

برای اجرای PWA از HTTPS یا localhost استفاده شود.

## Android
پروژه در `android/` قرار دارد و از Android WebView با پل ذخیره‌سازی فایل استفاده می‌کند.
- package: `com.mrkhorasani.finance`
- compileSdk/targetSdk: 36
- minSdk: 23
- خروجی Release: Universal APK
- انتخاب فایل از حافظه گوشی پشتیبانی می‌شود.
- ذخیره خروجی‌ها در Downloads/MR-KHORASANI با MediaStore انجام می‌شود.

## Build در GitHub Actions
Workflow: `.github/workflows/android-release.yml`

Workflow برای ساخت APK Release/Universal، تولید Checksum و آپلود Artifact تنظیم شده است.

## وضعیت Build در این محیط
این محیط فعلی Android SDK/Gradle را در اختیار نداشت، بنابراین APK باینری در همین محیط اجرا و امضاء نهایی نشد. سورس Android و Workflow کامل داخل بسته قرار دارد.
