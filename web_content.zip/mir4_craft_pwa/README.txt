MIR4 Craft Calculator — PWA v0.7

Atualizações:
- Logo reduzida aproximadamente 50%, permanecendo centralizada.
- Campo de meta começa em 0 para que você informe a quantidade desejada.
- Créditos adicionados nas configurações: Feito por 鬼 Ruby usando ChatGPT; © Todos os direitos reservados.
- Moldura de espinhos CSS mantida.
- Lógica dos cálculos preservada.

Para instalar/atualizar:
1. Extraia o ZIP mantendo todos os arquivos juntos.
2. Publique os arquivos em hospedagem estática HTTPS.
3. Abra no Chrome Android para instalar ou atualizar o PWA.
