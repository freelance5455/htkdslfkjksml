StudyGrid - Android project (Capacitor)
=======================================

This folder turns StudyGrid into a real Android app (APK) you can install and share.

WHAT YOU NEED (one time, on a computer)
  1. Node.js (nodejs.org, LTS version)
  2. Android Studio (developer.android.com/studio)

BUILD THE APK
  1. Unzip this folder and open a terminal inside it.
  2. Run:   npm install
  3. Run:   npm run setup
     (creates the android/ folder, makes the app icons, and copies the app in)
  4. Run:   npm run open
     (opens the project in Android Studio; wait for it to finish syncing)
  5. In Android Studio:  Build > Build Bundle(s) / APK(s) > Build APK(s)
  6. Click "locate" in the popup. Your file is app-debug.apk.

SHARE IT
  - Send app-debug.apk to anyone. On their Android phone they open it and allow
    "Install unknown apps" when asked.
  - For Google Play you need a signed release build instead:
    Build > Generate Signed Bundle / APK.

CHANGING THE APP
  - The app itself is www/index.html. After editing it, run:  npm run sync
    then build the APK again.
  - To change the icon, replace the images in assets/ and run:
    npx capacitor-assets generate --android

NO COMPUTER?
  Upload the separate StudyGrid web zip to a free host (Netlify, GitHub Pages),
  then paste the link into pwabuilder.com and choose Package for stores > Android.
