/* Minimal dependency-free PDF writer for report models (Helvetica, tables, cards). */
(function (root) {
  "use strict";
  const WH = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
  const WB = [278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584];
  const sw = (s, size, bold) => { const t = bold ? WB : WH; let w = 0; for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); w += c >= 32 && c <= 126 ? t[c - 32] : 556; } return (w * size) / 1000; };
  const clean = (s) => String(s == null ? "" : s).replace(/[\u2013\u2014]/g, "-").replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').replace(/[^\x20-\x7E\xA0-\xFF]/g, "?");
  const esc = (s) => clean(s).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
  const fit = (s, size, bold, maxW) => { s = clean(s); if (sw(s, size, bold) <= maxW) return s; while (s.length > 1 && sw(s + "...", size, bold) > maxW) s = s.slice(0, -1); return s + "..."; };
  const rgb = (h) => [1, 3, 5].map((i) => (parseInt(h.slice(i, i + 2), 16) / 255).toFixed(3)).join(" ");
  const N = (v) => (Math.round(v * 100) / 100).toString();

  class Doc {
    constructor(landscape, w, h) { this.W = w || (landscape ? 842 : 595); this.H = h || (landscape ? 595 : 842); this.pages = []; this.ops = null; }
    dline(x1, y1, x2, y2, color) { this.ops.push(rgb(color || "#999999") + " RG 0.5 w [2 2] 0 d " + N(x1) + " " + N(this.H - y1) + " m " + N(x2) + " " + N(this.H - y2) + " l S [] 0 d"); }
    stamp(s, size, color) { const c = 0.866, sn = 0.5, w = sw(s, size, true); this.ops.push("q " + c + " " + sn + " " + -sn + " " + c + " " + N(this.W / 2 - (w / 2) * c) + " " + N(this.H / 2 - (w / 2) * sn) + " cm BT " + rgb(color) + " rg /F2 " + size + " Tf 0 0 Td (" + esc(s) + ") Tj ET Q"); }
    newPage() { this.ops = []; this.pages.push(this.ops); }
    rect(x, y, w, h, fill, stroke) {
      let o = "";
      if (fill) o += rgb(fill) + " rg "; if (stroke) o += rgb(stroke) + " RG 0.5 w ";
      this.ops.push(o + N(x) + " " + N(this.H - y - h) + " " + N(w) + " " + N(h) + " re " + (fill && stroke ? "B" : fill ? "f" : "S"));
    }
    line(x1, y1, x2, y2, color, w) { this.ops.push(rgb(color) + " RG " + (w || 0.5) + " w " + N(x1) + " " + N(this.H - y1) + " m " + N(x2) + " " + N(this.H - y2) + " l S"); }
    text(x, y, s, size, o) {
      o = o || {}; s = clean(s); const bold = !!o.bold, w = sw(s, size, bold);
      if (o.align === "right") x -= w; else if (o.align === "center") x -= w / 2;
      this.ops.push("BT " + rgb(o.color || "#1b1f29") + " rg /" + (bold ? "F2" : "F1") + " " + size + " Tf " + N(x) + " " + N(this.H - y) + " Td (" + esc(s) + ") Tj ET");
    }
  }

  const BCs = root.Barcodes || (typeof require !== "undefined" ? require("./barcodes.js") : null);
  // Draw a barcode with human-readable digits. (x, yTop) = top-left of the bars; h = bar height.
  function drawCode(doc, code, x, yTop, w, h, fsize) {
    const e = BCs.encode(code), q = e.quiet, bits = e.bits, mw = w / (bits.length + 2 * q), bx = x + q * mw;
    let j = 0;
    while (j < bits.length) {
      if (bits[j] === "1") { let k = j; while (k < bits.length && bits[k] === "1") k++; doc.rect(bx + j * mw, yTop, (k - j) * mw, h, "#000000"); j = k; } else j++;
    }
    const ty = yTop + h + fsize + 1;
    if (e.ean) {
      const d = e.ean;
      if (e.kind === "EAN-13") doc.text(x + (q - 7) * mw, ty, d[0], fsize);
      doc.text(x + (q + 24) * mw, ty, d.slice(1, 7), fsize, { align: "center" });
      doc.text(x + (q + 71) * mw, ty, d.slice(7), fsize, { align: "center" });
    } else doc.text(x + w / 2, ty, e.text.length > 40 ? e.text.slice(0, 37) + "..." : e.text, fsize, { align: "center" });
  }


  const mny = (v) => (v < 0 ? "-$" : "$") + Math.abs(v).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const wrap = (s, size, bold, maxW) => {
    const out = []; for (const para of String(s || "").split(/\r?\n/)) {
      let line = ""; for (const w of para.split(/\s+/)) { const t = line ? line + " " + w : w; if (sw(t, size, bold) <= maxW || !line) line = t; else { out.push(line); line = w; } }
      out.push(line);
    } return out.filter((l, i) => l || i < out.length - 1);
  };
  const bizLines = (b) => [].concat(wrap(b.address, 9, false, 250), b.phone ? ["Tel: " + b.phone] : []).slice(0, 4);

  function buildA4(d) {
    const doc = new Doc(false), M = 40, cw = doc.W - 2 * M, NAVY = "#1F3864", GRAY = "#667085", B = d.business || {};
    const cols = [5, 41, 8, 14, 14, 16], tot = cols.reduce((a, b) => a + b, 0), widths = cols.map((c) => (cw * c) / tot), xs = []; let ax = M; for (const w of widths) { xs.push(ax); ax += w; }
    const LIM = doc.H - 70; let y;
    const first = () => {
      doc.newPage();
      doc.text(M, 52, fit(B.name || "Your Business", 20, true, cw * 0.55), 20, { bold: true, color: NAVY });
      bizLines(B).forEach((l, i) => doc.text(M, 68 + i * 12, l, 9, { color: GRAY }));
      doc.text(doc.W - M, 54, d.title, 26, { bold: true, color: NAVY, align: "right" });
      doc.text(doc.W - M, 72, "No. " + d.number, 11, { bold: true, align: "right" });
      doc.text(doc.W - M, 86, "Date: " + d.date, 9.5, { color: GRAY, align: "right" });
      doc.line(M, 114, doc.W - M, 114, "#d5dbe7", 1);
      doc.text(M, 134, "BILL TO", 7.5, { bold: true, color: GRAY });
      doc.text(M, 150, fit(d.customer, 12, true, cw * 0.55), 12, { bold: true });
      doc.text(doc.W - M, 134, "Payment: " + d.payment, 9.5, { align: "right" });
      if (d.agent) doc.text(doc.W - M, 148, "Served by: " + d.agent, 9.5, { align: "right" });
      y = 172;
    };
    const cont = () => { doc.newPage(); doc.text(M, 38, d.title + " " + d.number + " (continued)", 9, { bold: true, color: GRAY }); doc.line(M, 46, doc.W - M, 46, "#d5dbe7"); y = 60; };
    const thead = () => {
      doc.rect(M, y, cw, 20, NAVY);
      ["#", "Item", "Qty", "Unit price", "Discount", "Amount"].forEach((h, i) => { const r = i !== 1; doc.text(r ? xs[i] + widths[i] - 5 : xs[i] + 5, y + 13.5, h, 8, { bold: true, color: "#ffffff", align: r ? "right" : "left" }); });
      y += 20;
    };
    first(); thead();
    d.lines.forEach((l, n) => {
      if (y + 26 > LIM) { cont(); thead(); }
      if (n % 2 === 1) doc.rect(M, y, cw, 26, "#F3F5F9");
      doc.text(xs[0] + widths[0] - 5, y + 15, String(n + 1), 8.5, { color: GRAY, align: "right" });
      doc.text(xs[1] + 5, y + 12, fit(l.name, 9.5, true, widths[1] - 10), 9.5, { bold: true });
      doc.text(xs[1] + 5, y + 22, fit(l.sku, 7, false, widths[1] - 10), 7, { color: GRAY });
      doc.text(xs[2] + widths[2] - 5, y + 15, String(Math.round(l.qty * 1e6) / 1e6), 9, { align: "right" });
      doc.text(xs[3] + widths[3] - 5, y + 15, mny(l.unit), 9, { align: "right" });
      doc.text(xs[4] + widths[4] - 5, y + 15, l.disc ? "-" + mny(l.disc) : "-", 9, { align: "right", color: l.disc ? "#B42318" : GRAY });
      doc.text(xs[5] + widths[5] - 5, y + 15, mny(l.amount), 9, { bold: true, align: "right" });
      doc.line(M, y + 26, M + cw, y + 26, "#e2e6ee", 0.4); y += 26;
    });
    if (y + 130 > LIM) { cont(); }
    y += 16;
    const tx = doc.W - M - 220, rows = [["Subtotal", mny(d.subtotal)], ["Discounts", d.discounts ? "-" + mny(d.discounts) : mny(0)]];
    if (d.tax_rate > 0) rows.push(["Tax (" + d.tax_rate + "%)", mny(d.tax)]);
    rows.forEach(([a, b]) => { doc.text(tx + 10, y + 12, a, 9.5, { color: GRAY }); doc.text(doc.W - M - 6, y + 12, b, 9.5, { align: "right" }); y += 18; });
    doc.rect(tx, y + 2, 220, 26, NAVY); doc.text(tx + 10, y + 20, "TOTAL", 11, { bold: true, color: "#ffffff" }); doc.text(doc.W - M - 6, y + 20, mny(d.total), 13, { bold: true, color: "#ffffff", align: "right" }); y += 40;
    const paid = d.payment === "Cash";
    doc.rect(tx, y, 220, 24, paid ? "#E4F7EA" : "#FFF0C7", paid ? "#9ED8B2" : "#E8C766");
    doc.text(tx + 110, y + 16, paid ? "PAID IN FULL (CASH)" : "AMOUNT DUE: " + mny(d.total), 10, { bold: true, color: paid ? "#0a7d3b" : "#9c5700", align: "center" });
    if (d.note) wrap("Note: " + d.note, 9, false, tx - M - 20).slice(0, 4).forEach((l, i) => doc.text(M, y - 70 + i * 12, l, 9, { color: GRAY }));
    const total = doc.pages.length;
    doc.pages.forEach((ops, i) => {
      doc.ops = ops;
      if (i === total - 1 && B.footer) wrap(B.footer, 9, false, cw).slice(0, 3).forEach((l, k) => doc.text(doc.W / 2, doc.H - 52 + k * 11, l, 9, { color: GRAY, align: "center" }));
      doc.line(M, doc.H - 32, doc.W - M, doc.H - 32, "#d5dbe7");
      if (total > 1) doc.text(doc.W - M, doc.H - 20, "Page " + (i + 1) + " of " + total, 8, { color: GRAY, align: "right" });
      if (d.status === "void") doc.stamp("VOID", 110, "#F4B6B3");
    });
    return assemble(doc, d.title + " " + d.number, false);
  }

  function buildReceipt(d) {
    const W = 226, M = 10, cw = W - 2 * M, B = d.business || {};
    const render = (doc) => {
      doc.newPage(); let y = 22;
      doc.text(W / 2, y, fit(B.name || "Your Business", 12, true, cw), 12, { bold: true, align: "center" }); y += 13;
      for (const l of bizLines(B)) { doc.text(W / 2, y, fit(l, 7.5, false, cw), 7.5, { color: "#555555", align: "center" }); y += 10; }
      y += 3; doc.dline(M, y, W - M, y); y += 13;
      doc.text(W / 2, y, d.title, 11, { bold: true, align: "center" }); y += 13;
      doc.text(M, y, d.number, 8.5, { bold: true }); doc.text(W - M, y, d.date, 8.5, { align: "right" }); y += 11;
      doc.text(M, y, "Customer: " + fit(d.customer, 8, false, cw - 52), 8); y += 10;
      if (d.agent) { doc.text(M, y, "Served by: " + fit(d.agent, 8, false, cw - 58), 8); y += 10; }
      y += 2; doc.dline(M, y, W - M, y); y += 11;
      for (const l of d.lines) {
        doc.text(M, y, fit(l.name, 8.5, true, cw), 8.5, { bold: true }); y += 10;
        const q = String(Math.round(l.qty * 1e6) / 1e6) + " x " + mny(l.unit);
        doc.text(M + 4, y, q, 8, { color: "#444444" }); doc.text(W - M, y, mny(l.amount), 8.5, { bold: true, align: "right" }); y += 10;
        if (l.disc) { doc.text(M + 4, y, "Discount -" + mny(l.disc), 7.5, { color: "#B42318" }); y += 10; }
        y += 2;
      }
      doc.dline(M, y, W - M, y); y += 12;
      const row = (a, b, bold, size) => { doc.text(M, y, a, size || 8.5, { bold }); doc.text(W - M, y, b, size || 8.5, { bold, align: "right" }); y += 12; };
      row("Subtotal", mny(d.subtotal)); if (d.discounts) row("Discounts", "-" + mny(d.discounts)); if (d.tax_rate > 0) row("Tax (" + d.tax_rate + "%)", mny(d.tax));
      y += 2; row("TOTAL", mny(d.total), true, 11); y += 2;
      doc.text(W / 2, y, d.payment === "Cash" ? "PAID - CASH" : "AMOUNT DUE: " + mny(d.total), 9, { bold: true, align: "center" }); y += 12;
      if (d.note) for (const l of wrap("Note: " + d.note, 7.5, false, cw).slice(0, 3)) { doc.text(M, y, l, 7.5, { color: "#555555" }); y += 9; }
      y += 3; doc.dline(M, y, W - M, y); y += 12;
      for (const l of wrap(B.footer || "", 8, false, cw).slice(0, 3)) { doc.text(W / 2, y, l, 8, { align: "center", color: "#555555" }); y += 10; }
      if (d.status === "void") doc.stamp("VOID", 60, "#F4B6B3");
      return y;
    };
    const probe = new Doc(false, W, 2000); const endY = render(probe);
    const doc = new Doc(false, W, Math.ceil(endY + 16)); render(doc);
    return assemble(doc, d.title + " " + d.number, false);
  }

  function buildInvoice(d, fmt) { return fmt === "receipt" ? buildReceipt(d) : buildA4(d); }

  function buildLabels(model) {
    const doc = new Doc(false), cols = 3, rows = 8, mx = 28.35, my = 34, lw = (doc.W - 2 * mx) / cols, lh = (doc.H - 2 * my) / rows;
    const labels = []; for (const it of model.items) for (let c = 0; c < model.copies; c++) labels.push(it);
    const per = cols * rows; doc.newPage();
    if (!labels.length) doc.text(mx, 60, "No items to print.", 12);
    labels.forEach((it, n) => {
      if (n && n % per === 0) doc.newPage();
      const k = n % per, x0 = mx + (k % cols) * lw, y0 = my + Math.floor(k / cols) * lh;
      doc.rect(x0, y0, lw, lh, null, "#c9ced9");
      doc.text(x0 + 6, y0 + 13, fit(it.name, 8.5, true, lw - 12), 8.5, { bold: true });
      doc.text(x0 + 6, y0 + 23, it.sku + (model.showPrice ? "   " + it.price : ""), 7, { color: "#444444" });
      drawCode(doc, it.barcode, x0 + 8, y0 + 35, lw - 16, lh - 50, 7);
    });
    return assemble(doc, model.title);
  }

  function build(model, opts) {
    if (model.kind === "labels") return buildLabels(model);
    opts = opts || {};
    const doc = new Doc(model.landscape), M = 36, cw = doc.W - 2 * M, NAVY = "#1F3864", GRAY = "#667085", LIM = doc.H - 46;
    const gen = opts.generated || "";
    let y;
    const header = (first) => {
      if (first) {
        doc.rect(0, 0, doc.W, 62, NAVY);
        doc.text(M, 28, model.title, 17, { bold: true, color: "#ffffff" });
        doc.text(M, 46, "Period: " + model.period, 9.5, { color: "#C9D6F2" });
        if (opts.business) doc.text(doc.W - M, 28, fit(opts.business, 11, true, cw * 0.4), 11, { bold: true, color: "#ffffff", align: "right" });
        doc.text(doc.W - M, 46, "Generated " + gen, 8.5, { color: "#C9D6F2", align: "right" });
        y = 80;
      } else {
        doc.text(M, 30, model.title + "  |  " + model.period, 9, { bold: true, color: GRAY });
        doc.line(M, 38, doc.W - M, 38, "#d5dbe7"); y = 52;
      }
    };
    const newPage = (first) => { doc.newPage(); header(first); };
    newPage(true);

    if (model.cards && model.cards.length) {
      const n = model.cards.length, gap = 8, w = (cw - gap * (n - 1)) / n;
      model.cards.forEach((c, i) => {
        const x = M + i * (w + gap);
        doc.rect(x, y, w, 40, "#F3F5F9", "#d5dbe7");
        doc.text(x + 8, y + 14, fit(c[0], 7.5, false, w - 16), 7.5, { color: GRAY });
        let size = 12; while (size > 8 && sw(c[1], size, true) > w - 16) size -= 1;
        doc.text(x + 8, y + 31, c[1], size, { bold: true, color: NAVY });
      });
      y += 56;
    }

    for (const tb of model.tables) {
      const tot = tb.cols.reduce((s, c) => s + c.w, 0), widths = tb.cols.map((c) => (cw * c.w) / tot);
      const xs = []; let acc = M; for (const w of widths) { xs.push(acc); acc += w; }
      const cell = (i, s, base, size, bold, color, al) => {
        const w = widths[i] - 8, t = fit(s, size, bold, w);
        if ((al || tb.cols[i].a) === "r") doc.text(xs[i] + widths[i] - 4, base, t, size, { bold, color, align: "right" }); else doc.text(xs[i] + 4, base, t, size, { bold, color });
      };
      const heading = (cont) => { if (tb.heading) { doc.text(M, y + 11, tb.heading + (cont ? " (continued)" : ""), 11, { bold: true, color: NAVY }); y += 18; } };
      const thead = () => { doc.rect(M, y, cw, 18, NAVY); tb.cols.forEach((c, i) => cell(i, c.h, y + 12.5, 8, true, "#ffffff")); y += 18; };
      if (y + 18 + 30 > LIM) newPage(false);
      heading(false); thead();
      if (!tb.rows.length) { doc.text(M + 4, y + 12, "No records for this period.", 8.5, { color: GRAY }); y += 22; }
      const RH = tb.rowH || 15;
      tb.rows.forEach((r, ri) => {
        if (y + RH > LIM) { newPage(false); heading(true); thead(); }
        if (ri % 2 === 1) doc.rect(M, y, cw, RH, "#F3F5F9");
        r.forEach((v, i) => {
          if (tb.cols[i].img) drawCode(doc, v, xs[i] + 4, y + 4, Math.min(widths[i] - 10, 150), RH - 16, 6.5);
          else cell(i, v, y + (RH > 20 ? RH / 2 + 3 : 10.5), 8, false, "#1b1f29");
        });
        doc.line(M, y + RH, M + cw, y + RH, "#e2e6ee", 0.3); y += RH;
      });
      if (tb.rows.length && tb.total) {
        if (y + 18 > LIM) { newPage(false); heading(true); thead(); }
        doc.rect(M, y, cw, 17, "#E4F7EA"); doc.line(M, y, M + cw, y, NAVY, 0.8);
        tb.total.forEach((v, i) => cell(i, v, y + 11.5, 8, true, "#1b1f29")); y += 17;
      }
      y += 18;
    }

    return assemble(doc, model.title, true);
  }

  function assemble(doc, title, footers) {
    const M = 36, GRAY = "#667085";
    const total = doc.pages.length;
    if (footers) doc.pages.forEach((ops, i) => {
      doc.ops = ops;
      doc.line(M, doc.H - 32, doc.W - M, doc.H - 32, "#d5dbe7");
      doc.text(M, doc.H - 20, "Inventory & Sales Tracker", 8, { color: GRAY });
      doc.text(doc.W - M, doc.H - 20, "Page " + (i + 1) + " of " + total, 8, { color: GRAY, align: "right" });
    });

    // assemble file (latin-1: 1 char == 1 byte)
    const objs = [];
    const nPages = doc.pages.length;
    objs.push("<</Type/Catalog/Pages 2 0 R>>");
    objs.push("<</Type/Pages/Kids[" + doc.pages.map((_, i) => 6 + 2 * i + " 0 R").join(" ") + "]/Count " + nPages + ">>");
    objs.push("<</Type/Font/Subtype/Type1/BaseFont/Helvetica/Encoding/WinAnsiEncoding>>");
    objs.push("<</Type/Font/Subtype/Type1/BaseFont/Helvetica-Bold/Encoding/WinAnsiEncoding>>");
    objs.push("<</Title(" + esc(title) + ")/Producer(Inventory & Sales Tracker)>>");
    doc.pages.forEach((ops, i) => {
      const content = ops.join("\n");
      objs.push("<</Type/Page/Parent 2 0 R/MediaBox[0 0 " + doc.W + " " + doc.H + "]/Resources<</Font<</F1 3 0 R/F2 4 0 R>>>>/Contents " + (7 + 2 * i) + " 0 R>>");
      objs.push("<</Length " + content.length + ">>\nstream\n" + content + "\nendstream");
    });
    let out = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n"; const offs = [];
    objs.forEach((o, i) => { offs.push(out.length); out += (i + 1) + " 0 obj\n" + o + "\nendobj\n"; });
    const xref = out.length;
    out += "xref\n0 " + (objs.length + 1) + "\n0000000000 65535 f \n" + offs.map((o) => String(o).padStart(10, "0") + " 00000 n \n").join("");
    out += "trailer\n<</Size " + (objs.length + 1) + "/Root 1 0 R/Info 5 0 R>>\nstartxref\n" + xref + "\n%%EOF";
    const bytes = new Uint8Array(out.length); for (let i = 0; i < out.length; i++) bytes[i] = out.charCodeAt(i) & 255;
    return bytes;
  }

  root.PDF = { build, buildInvoice, textWidth: sw };
  if (typeof module !== "undefined" && module.exports) module.exports = root.PDF;
})(typeof window !== "undefined" ? window : globalThis);
