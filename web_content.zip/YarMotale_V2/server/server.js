const express = require('express');
const cron = require('node-cron');
const nodemailer = require('nodemailer');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const PORT = process.env.PORT || 3000;
const REPORT_TO = process.env.REPORT_TO || '';
const SMTP_HOST = process.env.SMTP_HOST || '';
const SMTP_PORT = Number(process.env.SMTP_PORT || 587);
const SMTP_USER = process.env.SMTP_USER || '';
const SMTP_PASS = process.env.SMTP_PASS || '';

let dailyData = { studentName: 'دانش‌آموز', minutes: 0, sessions: 0, lastSession: null, updatedAt: null };

function transporter() {
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS || !REPORT_TO) return null;
  return nodemailer.createTransport({host: SMTP_HOST, port: SMTP_PORT, secure: SMTP_PORT === 465, auth:{user:SMTP_USER, pass:SMTP_PASS}});
}

async function sendReport() {
  const t = transporter();
  if (!t) return {sent:false, reason:'SMTP یا REPORT_TO تنظیم نشده است.'};
  const d = dailyData;
  const text = `گزارش مطالعه روزانه\n\nنام دانش‌آموز: ${d.studentName}\nمجموع مطالعه: ${d.minutes} دقیقه\nتعداد جلسات: ${d.sessions}\nآخرین جلسه: ${d.lastSession || 'ندارد'}`;
  await t.sendMail({from: SMTP_USER, to: REPORT_TO, subject:`گزارش مطالعه ${new Date().toLocaleDateString('fa-IR')}`, text});
  return {sent:true};
}

app.post('/api/session', (req,res)=>{
  const {studentName='دانش‌آموز', minutes=0} = req.body || {};
  const m = Math.max(0, Math.round(Number(minutes)));
  dailyData.studentName = String(studentName).slice(0,100);
  dailyData.minutes += m;
  dailyData.sessions += 1;
  dailyData.lastSession = new Date().toLocaleTimeString('fa-IR');
  dailyData.updatedAt = new Date().toISOString();
  res.json({ok:true, data:dailyData});
});

app.get('/api/report', (req,res)=>res.json(dailyData));
app.post('/api/send-now', async (req,res)=>{try{res.json(await sendReport());}catch(e){res.status(500).json({sent:false,error:e.message});}});

// ارسال روزانه ساعت 20:00 به وقت سرور
cron.schedule('0 20 * * *', async ()=>{try{await sendReport(); console.log('Daily report sent.')}catch(e){console.error('Daily report failed:',e.message)}});

app.listen(PORT, ()=>console.log(`Yar Motale V2 running on http://localhost:${PORT}`));
