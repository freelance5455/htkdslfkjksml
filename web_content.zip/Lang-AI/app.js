const chatBox = document.getElementById('chat-box');
const chatForm = document.getElementById('chat-form');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const statusBadge = document.getElementById('status-badge');
const clearBtn = document.getElementById('clear-btn');

// Riwayat percakapan untuk konteks AI
let conversationHistory = [
    {
        role: "system",
        content: "Kamu adalah Lang AI, asisten kecerdasan buatan yang cerdas, ramah, dan selalu memberikan jawaban yang akurat, faktual, dan mudah dipahami dalam bahasa Indonesia."
    }
];

// Cek status koneksi internet
function updateOnlineStatus() {
    if (navigator.onLine) {
        statusBadge.textContent = 'Online';
        statusBadge.className = 'status-online';
    } else {
        statusBadge.textContent = 'Offline (Butuh Internet)';
        statusBadge.className = 'status-offline';
    }
}

window.addEventListener('online', updateOnlineStatus);
window.addEventListener('offline', updateOnlineStatus);
updateOnlineStatus();

// Hapus riwayat chat
clearBtn.addEventListener('click', () => {
    conversationHistory = [conversationHistory[0]];
    chatBox.innerHTML = `
        <div class="message ai-message">
            <div class="bubble">
                Riwayat percakapan telah dibersihkan. Ada yang bisa <strong>Lang AI</strong> bantu?
            </div>
        </div>
    `;
});

// Tambah pesan ke layar
function appendMessage(text, isUser) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${isUser ? 'user-message' : 'ai-message'}`;
    
    const bubble = document.createElement('div');
    bubble.className = 'bubble';
    bubble.textContent = text;
    
    msgDiv.appendChild(bubble);
    chatBox.appendChild(msgDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
    return bubble;
}

// Ambil ringkasan fakta dari Wikipedia Indonesia jika dibutuhkan
async function fetchWikiContext(query) {
    try {
        const searchUrl = `https://id.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&origin=*&srlimit=1`;
        const res = await fetch(searchUrl);
        const data = await res.json();
        const topResult = data?.query?.search?.[0];
        if (topResult) {
            const cleanSnippet = topResult.snippet.replace(/<[^>]*>?/gm, '');
            return `Referensi tambahan (${topResult.title}): ${cleanSnippet}`;
        }
    } catch (e) {
        // Abaikan jika gagal mengambil referensi tambahan
    }
    return "";
}

// Kirim pertanyaan ke layanan AI publik gratis tanpa API Key
async function askLangAI(promptText) {
    if (!navigator.onLine) {
        return 'Tidak ada koneksi internet. Lang AI membutuhkan internet untuk menjawab dengan akurat.';
    }

    const wikiContext = await fetchWikiContext(promptText);
    const enrichedPrompt = wikiContext 
        ? `${promptText}\n\n[Konteks Internet: ${wikiContext}]` 
        : promptText;

    conversationHistory.push({
        role: "user",
        content: enrichedPrompt
    });

    // Batasi riwayat agar permintaan tetap cepat
    if (conversationHistory.length > 11) {
        conversationHistory = [conversationHistory[0], ...conversationHistory.slice(-10)];
    }

    try {
        const response = await fetch('https://text.pollinations.ai/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                messages: conversationHistory,
                model: 'openai',
                seed: Math.floor(Math.random() * 100000)
            })
        });

        if (!response.ok) {
            throw new Error('Server sibuk');
        }

        const aiReply = await response.text();
        
        // Simpan pesan asli user ke riwayat
        conversationHistory[conversationHistory.length - 1].content = promptText;
        conversationHistory.push({
            role: "assistant",
            content: aiReply
        });

        return aiReply.trim() || 'Maaf, saya tidak dapat menghasilkan jawaban saat ini.';
    } catch (error) {
        conversationHistory.pop();
        return 'Koneksi ke server AI sedang sibuk. Silakan coba kirim ulang pertanyaanmu.';
    }
}

chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = userInput.value.trim();
    if (!text) return;

    appendMessage(text, true);
    userInput.value = '';
    userInput.disabled = true;
    sendBtn.disabled = true;

    const loadingBubble = appendMessage('Lang AI sedang mencari & berpikir...', false);

    const answer = await askLangAI(text);
    loadingBubble.textContent = answer;

    userInput.disabled = false;
    sendBtn.disabled = false;
    userInput.focus();
    chatBox.scrollTop = chatBox.scrollHeight;
});
