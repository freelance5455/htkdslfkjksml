# Lang AI - Source Code Aplikasi (Tanpa API Key)

Paket kode ini berisi aplikasi **Lang AI** yang langsung siap digunakan tanpa perlu memasukkan API Key apa pun. Aplikasi ini terhubung langsung ke endpoint AI publik gratis dan dilengkapi pencarian referensi otomatis dari internet (Wikipedia) agar jawaban lebih akurat.

## Struktur File
- `index.html` : Tampilan utama aplikasi Lang AI.
- `style.css` : Desain antarmuka (Dark Mode modern & responsif untuk HP).
- `app.js` : Logika kecerdasan buatan, pencarian referensi internet, dan deteksi status koneksi.
- `manifest.json` : Konfigurasi agar file ini siap diubah menjadi aplikasi Android (APK) atau PWA.

## Cara Menggunakan & Mengubah Menjadi Aplikasi (APK)
1. **Langsung Jalankan:**
   - Ekstrak file ZIP ini, lalu buka `index.html` di browser HP atau laptop. Lang AI langsung bisa diajak mengobrol selama ada internet.
2. **Ubah Menjadi Aplikasi Android (APK):**
   - **Cara 1 (Website-to-APK):** Gunakan aplikasi/web seperti *Website 2 APK Builder*, *AppsGeyser*, atau *Median.co*, lalu pilih folder hasil ekstrak file ZIP ini untuk di-compile menjadi file `.apk`.
   - **Cara 2 (Capacitor):** Bungkus folder ini dengan Capacitor (`npx cap init` lalu `npx cap add android`) untuk build APK melalui Android Studio.
   - **Cara 3 (Install Langsung via Browser / PWA):** Upload isi folder ini ke hosting gratis (Vercel, Netlify, atau GitHub Pages), buka link-nya di Chrome HP, lalu pilih **"Tambahkan ke Layar Utama" (Install App)**.
