#!/system/bin/sh
# T10_stop_thermal_debug — Disable thermal debug tracing
MODULE_ID="T10_stop_thermal_debug"
. "$(dirname "$0")/../../lib/core.sh"
vcg_init
apply() {
    vcg_apply_or_skip T10_ENABLED || return 0
    vcg_put global thermal_debug 0
}
revert() { vcg_log INFO "revert T10_stop_thermal_debug: transient"; }
case "${1:-apply}" in apply) apply ;; revert) revert ;; *) exit 1 ;; esac
