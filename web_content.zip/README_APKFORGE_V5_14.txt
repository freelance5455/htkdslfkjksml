CGD V117 — V5.14 CORRECTION GALACTIQUE ET PAYSAGE

PAQUET SOURCE HTML5 POUR APKFORGE

Modifications de cette révision :
- Suppression de l'écran bloquant « Joue en paysage horizontal » au démarrage.
- Le conteneur Android doit être configuré en orientation Landscape dans APKForge.
- Remplacement de la liste de pays terrestres du profil manager par les 24 origines galactiques officielles.
- Les fiches de damistes générées utilisent des origines galactiques au lieu de nationalités terrestres.
- Première harmonisation des formulaires et panneaux pour les écrans mobiles en paysage.
- Les contenus longs restent défilables à l'intérieur de leur panneau ; la page globale ne doit pas défiler horizontalement.

IMPORT APKFORGE :
- Importer ce ZIP comme projet HTML5 / site web.
- Définir l'orientation de l'application sur Landscape / Paysage.
- Activer l'affichage plein écran si cette option est disponible.
- Ne pas choisir Portrait.

IMPORTANT :
Ce ZIP est un paquet source HTML5, pas un APK compilé.
La prévisualisation APKForge peut rester en portrait selon son propre cadre de prévisualisation.
La validation finale du verrouillage paysage et du rendu doit être faite dans l'APK généré sur le TECNO Spark 20 Pro+.
