from flask import Flask, jsonify, request
import os

app = Flask(__name__)

@app.get("/health")
def health():
    configured = {
        "gemini": bool(os.getenv("GEMINI_API_KEY")),
        "openai": bool(os.getenv("OPENAI_API_KEY")),
        "fal": bool(os.getenv("FAL_KEY")),
        "runway": bool(os.getenv("RUNWAY_API_KEY")),
        "elevenlabs": bool(os.getenv("ELEVENLABS_API_KEY")),
    }
    return jsonify({"app": "NEXORA AI", "status": "online", "configured": configured})

@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    if not message:
        return jsonify({"error": "Le message est vide."}), 400
    # Branchez ici un adaptateur officiel Gemini ou OpenAI.
    # Ne renvoyez pas de fausse réponse et ne transmettez jamais les secrets au navigateur.
    if not (os.getenv("GEMINI_API_KEY") or os.getenv("OPENAI_API_KEY")):
        return jsonify({"error": "Aucun moteur de conversation n'est configuré sur le serveur."}), 503
    return jsonify({"error": "Le connecteur de conversation doit encore être installé côté serveur."}), 501

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")))
