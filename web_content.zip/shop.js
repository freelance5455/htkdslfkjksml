/* ============================================================
   m1li shop: منتجات + سلة + دفع عند الاستلام + توصيل + لوحة الطلبات
   عدّل الإعدادات أدناه، وعدّل المنتجات والتوصيل من ملف products.json
   ============================================================ */
var SHOP_CONFIG = {
  whatsappNumber: '212600000000', // رقم التاجر بصيغة دولية بدون + أو أصفار (مثال: 212612345678)
  storeName: 'متجر m1li',
  currency: 'د.م',
  adminPin: '1234'                // رمز الدخول للوحة الطلبات — غيّره!
};

/* التوصيل (يمكن تعديله من products.json ← "delivery") — الأثمنة أمثلة فقط */
var DELIVERY = {
  freeFrom: 500,   // توصيل مجاني ابتداءً من هذا المبلغ (0 = معطّل)
  defaultFee: 40,  // ثمن التوصيل للمدن غير المذكورة
  cities: { 'الدار البيضاء': 25, 'الرباط': 30, 'مراكش': 35, 'فاس': 35, 'طنجة': 35, 'أكادير': 40 }
};
var OTHER_CITY = 'مدينة أخرى';

/* كوبونات / عرض اليوم / تتبع — تُقرأ من products.json (انظر README) */
var COUPONS = [];   // [{code, type:'percent'|'fixed', value, min, expires:'YYYY-MM-DD'}]
var DEAL = null;    // {id, price, endsAt?}  — بدون endsAt ينتهي منتصف الليل كل يوم
var TRACKING = {};  // {'M1-XXXX': 'shipped'}
var POINTS_PER_DH = 0.1;   // نقطة لكل 10 د.م
var POINTS_VALUE = 0.1;    // كل نقطة = 0.1 د.م (يعني 10 نقاط = 1 د.م)
var appliedCoupon = null;
var usePoints = false;

var ORDER_STATUS = {
  new:       { label: 'جديد',       cls: 'bg-sky-500/15 text-sky-300 border-sky-500/30' },
  confirmed: { label: 'مؤكد',       cls: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30' },
  shipped:   { label: 'في الشحن',   cls: 'bg-amber-500/15 text-amber-300 border-amber-500/30' },
  delivered: { label: 'تم التسليم', cls: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' },
  cancelled: { label: 'ملغى',       cls: 'bg-slate-500/15 text-slate-300 border-slate-500/30' },
  returned:  { label: 'مرتجع',      cls: 'bg-rose-500/15 text-rose-300 border-rose-500/30' }
};

/* نسخة احتياطية تعمل عند فتح الملف مباشرة (بدون خادم) */
var FALLBACK_PRODUCTS = [
  { id: 'p1', title: 'سماعات لاسلكية', category: 'إلكترونيات', price: 199, image: '🎧', desc: 'سماعات بلوتوث بجودة صوت عالية وبطارية تدوم 20 ساعة.' },
  { id: 'p2', title: 'شاحن سريع 33 واط', category: 'إلكترونيات', price: 89, image: '🔌', desc: 'شاحن حائط بمنفذين يدعم الشحن السريع لمعظم الهواتف.' },
  { id: 'p3', title: 'حافظة هاتف شفافة', category: 'إكسسوارات', price: 39, image: '📱', desc: 'حماية ضد الصدمات مع حواف مرتفعة للشاشة والكاميرا.' },
  { id: 'p4', title: 'حامل هاتف للسيارة', category: 'إكسسوارات', price: 59, image: '🚗', desc: 'حامل مغناطيسي ثابت يناسب جميع أحجام الهواتف.' },
  { id: 'p5', title: 'ساعة ذكية', category: 'إلكترونيات', price: 349, image: '⌚', desc: 'تتبع النشاط والنوم مع إشعارات الهاتف وشاشة AMOLED.' },
  { id: 'p6', title: 'حقيبة ظهر عملية', category: 'إكسسوارات', price: 149, image: '🎒', desc: 'مقاومة للماء بجيب مخصص للابتوب حتى 15.6 بوصة.' }
];

var products = FALLBACK_PRODUCTS.slice();
var cart = LS.get('m1li_cart', {});       // { productId: quantity }
var orders = LS.get('m1li_orders', []);
var points = LS.get('m1li_points', 0);
var reviews = LS.get('m1li_reviews', {});   // { productId: [{n, s, t, ts}] }   // الطلبات المحفوظة على هذا الجهاز
var adminFilter = 'all';
var adminQuery = '';

function saveCart() { LS.set('m1li_cart', cart); }
function saveOrders() { LS.set('m1li_orders', orders); }
function findProduct(id) { return products.filter(function (p) { return p.id === id; })[0]; }
function money(n) { return (Math.round(n * 100) / 100).toLocaleString('ar-MA') + ' ' + SHOP_CONFIG.currency; }

function cartItems() {
  var out = [];
  Object.keys(cart).forEach(function (id) {
    var p = findProduct(id);
    if (p && cart[id] > 0) out.push({ p: p, qty: cart[id] });
  });
  return out;
}
function cartCount() { return cartItems().reduce(function (s, i) { return s + i.qty; }, 0); }
function dealEnd() {
  if (!DEAL) return 0;
  var t = DEAL.endsAt ? new Date(DEAL.endsAt).getTime() : NaN;
  if (!isFinite(t)) { var d = new Date(); d.setHours(24, 0, 0, 0); t = d.getTime(); }
  return t;
}
function dealActive(p) { return !!(DEAL && p && p.id === DEAL.id && isFinite(DEAL.price) && Number(DEAL.price) < p.price && dealEnd() > Date.now()); }
function unitPrice(p) { return dealActive(p) ? Number(DEAL.price) : p.price; }
function priceHTML(p) {
  return dealActive(p)
    ? '<span class="font-black text-rose-400">' + money(unitPrice(p)) + '</span> <s class="text-[11px] text-slate-500">' + money(p.price) + '</s>'
    : '<span class="font-black text-emerald-400">' + money(p.price) + '</span>';
}
function cartTotal() { return cartItems().reduce(function (s, i) { return s + i.qty * unitPrice(i.p); }, 0); }

/* عدّاد عرض اليوم */
function pad2(n) { return (n < 10 ? '0' : '') + n; }
function renderDeal() {
  var box = document.getElementById('deal-banner'); if (!box) return;
  var p = DEAL && findProduct(DEAL.id);
  if (!p || !dealActive(p)) { if (box.innerHTML) box.innerHTML = ''; delete box.dataset.id; box.classList.add('hidden'); return; }
  var left = Math.max(0, dealEnd() - Date.now()), sec = Math.floor(left / 1000);
  var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), ss = sec % 60;
  box.classList.remove('hidden');
  if (!box.dataset.id || box.dataset.id !== p.id) {
    box.dataset.id = p.id;
    box.innerHTML = '<div class="flex flex-wrap items-center gap-4 bg-gradient-to-l from-rose-600/20 to-amber-500/10 border border-rose-500/30 rounded-2xl p-4">' +
      '<div class="w-16 h-16 rounded-xl bg-slate-900 flex items-center justify-center text-4xl overflow-hidden shrink-0">' + shopImg(p) + '</div>' +
      '<div class="flex-1 min-w-[150px]"><div class="text-xs font-bold text-rose-300">🔥 عرض اليوم</div><div class="font-bold text-white">' + esc(p.title) + '</div><div>' + priceHTML(p) + '</div></div>' +
      '<div class="text-center"><div class="text-[10px] text-slate-400 mb-1">ينتهي بعد</div><div id="deal-timer" dir="ltr" class="font-black text-lg text-white tabular-nums"></div></div>' +
      '<button data-add="' + esc(p.id) + '" class="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white keep-white rounded-xl text-sm font-bold">اطلبه الآن</button></div>';
  }
  document.getElementById('deal-timer').textContent = pad2(h) + ':' + pad2(m) + ':' + pad2(ss);
}
var dealWasActive = false;
setInterval(function () {
  var p = DEAL && findProduct(DEAL.id), now = !!(p && dealActive(p));
  renderDeal();
  if (dealWasActive && !now) { renderProducts(); renderCart(); }
  dealWasActive = now;
}, 1000);

/* ---------------- الصور ---------------- */
function isImgSrc(v) {
  if (typeof v !== 'string' || !v) return false;
  return isHttpUrl(v) || /^(\.\/|img\/|images\/)/i.test(v) || /\.(png|jpe?g|webp|gif|svg|avif)(\?.*)?$/i.test(v);
}
function productImages(p) {
  var list = [];
  if (Array.isArray(p.images)) list = p.images.filter(isImgSrc);
  if (!list.length && isImgSrc(p.image)) list = [p.image];
  return list;
}
function productEmoji(p) { return (p.image && !isImgSrc(p.image)) ? p.image : '🛍️'; }
function imgTag(src, fallback, cls) {
  return '<img src="' + esc(src) + '" alt="" class="' + (cls || 'w-full h-full object-cover') + '" loading="lazy" referrerpolicy="no-referrer" onerror="this.replaceWith(document.createTextNode(\'' + esc(fallback) + '\'))">';
}
function shopImg(p) {
  var imgs = productImages(p);
  return imgs.length ? imgTag(imgs[0], productEmoji(p)) : esc(productEmoji(p));
}

/* ---------------- المنتجات ---------------- */
function renderProducts() {
  var grid = document.getElementById('products-grid');
  if (!grid) return;
  var q = (document.getElementById('product-search').value || '').trim().toLowerCase();
  var list = products.filter(function (p) { return !q || (p.title + ' ' + p.desc + ' ' + p.category).toLowerCase().indexOf(q) !== -1; });
  grid.innerHTML = list.map(function (p) {
    var n = productImages(p).length;
    return '<article data-ad="' + esc(p.id) + '" class="app-card bg-slate-800/60 border border-slate-700 rounded-2xl p-5 flex flex-col gap-3 hover:border-brand-500/50">' +
      '<button type="button" data-view="' + esc(p.id) + '" class="relative w-full h-40 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center text-6xl overflow-hidden" aria-label="عرض التفاصيل">' + shopImg(p) +
      (dealActive(p) ? '<span class="absolute top-2 right-2 text-[10px] bg-rose-600 text-white keep-white rounded-full px-2 py-0.5">🔥 عرض</span>' : '') +
      (n > 1 ? '<span class="absolute bottom-2 left-2 text-[10px] bg-black/60 text-white keep-white rounded-full px-2 py-0.5"><i class="fa-regular fa-images ml-1"></i>' + n + '</span>' : '') + '</button>' +
      '<div class="flex-1"><h3 class="font-bold text-white text-base mb-1">' + esc(p.title) + '</h3>' +
      '<span class="inline-block text-[10px] px-2 py-0.5 rounded-full border bg-indigo-500/15 text-indigo-300 border-indigo-500/30 mb-2">' + esc(p.category) + '</span>' +
      ratingLine(p.id) +
      '<span data-vc=\"' + esc(p.id) + '\" class=\"hidden text-[11px] text-slate-400 mb-1\"></span>' +
      '<p class="text-xs text-slate-400 leading-relaxed line-clamp-2">' + esc(p.desc) + '</p></div>' +
      '<div class="flex items-center justify-between gap-2"><span>' + priceHTML(p) + '</span>' +
      '<button data-add="' + esc(p.id) + '" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-sm font-bold transition keep-white"><i class="fa-solid fa-cart-plus ml-1"></i> أضف</button></div>' +
      '</article>';
  }).join('');
  document.getElementById('products-empty').classList.toggle('hidden', list.length > 0);
  hookViews(list);
}

/* عدّاد المشاهدات — من سيرفر M1li الخاص (server/)؛ إلى لم يكن متاحاً لا تظهر الأرقام */
function hookViews(list) {
  if (!window.M1Views || !M1Views.configured) return;
  var cards = {};
  Array.prototype.forEach.call(document.querySelectorAll('[data-ad]'), function (el) { cards[el.getAttribute('data-ad')] = el; });
  list.forEach(function (p) { if (cards[p.id]) M1Views.track(cards[p.id], p.id); });
  M1Views.counts(list.map(function (p) { return p.id; })).then(function (m) {
    var vcs = {};
    Array.prototype.forEach.call(document.querySelectorAll('[data-vc]'), function (el) { vcs[el.getAttribute('data-vc')] = el; });
    Object.keys(m).forEach(function (id) {
      var el = vcs[id];
      if (el) { el.textContent = '👁 ' + m[id] + ' مشاهدة'; el.classList.remove('hidden'); }
    });
  });
}

var galleryState = { id: null, i: 0 };
function openProduct(id) {
  var p = findProduct(id); if (!p) return;
  galleryState = { id: id, i: 0 };
  document.getElementById('pm-title').textContent = p.title;
  document.getElementById('pm-cat').textContent = p.category || '';
  document.getElementById('pm-desc').textContent = p.desc || '';
  document.getElementById('pm-price').innerHTML = priceHTML(p);
  document.getElementById('pm-add').setAttribute('data-add', p.id);
  rvStars = 5;
  renderGallery(); renderReviews();
  document.getElementById('product-modal').classList.remove('hidden');
}
function renderGallery() {
  var p = findProduct(galleryState.id); if (!p) return;
  var imgs = productImages(p);
  var main = document.getElementById('pm-main');
  main.innerHTML = imgs.length ? imgTag(imgs[galleryState.i], productEmoji(p), 'w-full h-full object-contain') : esc(productEmoji(p));
  document.getElementById('pm-thumbs').innerHTML = imgs.length > 1 ? imgs.map(function (src, i) {
    return '<button type="button" data-gal="' + i + '" class="w-14 h-14 rounded-lg overflow-hidden border-2 shrink-0 ' + (i === galleryState.i ? 'border-brand-500' : 'border-slate-700') + '">' + imgTag(src, productEmoji(p)) + '</button>';
  }).join('') : '';
  var nav = imgs.length > 1;
  document.getElementById('pm-prev').classList.toggle('hidden', !nav);
  document.getElementById('pm-next').classList.toggle('hidden', !nav);
}
function galleryStep(d) {
  var p = findProduct(galleryState.id); if (!p) return;
  var n = productImages(p).length; if (n < 2) return;
  galleryState.i = (galleryState.i + d + n) % n;
  renderGallery();
}
function closeProduct() { document.getElementById('product-modal').classList.add('hidden'); }

/* ---------------- السلة والتوصيل ---------------- */
function deliveryFee(city, subtotal) {
  if (!subtotal) return 0;
  if (DELIVERY.freeFrom > 0 && subtotal >= DELIVERY.freeFrom) return 0;
  if (city && DELIVERY.cities[city] != null) return Number(DELIVERY.cities[city]) || 0;
  return Number(DELIVERY.defaultFee) || 0;
}
function fillCities() {
  var sel = document.getElementById('cust-city'); if (!sel) return;
  var cur = sel.value;
  sel.innerHTML = '<option value="">اختر المدينة *</option>' +
    Object.keys(DELIVERY.cities).map(function (c) { return '<option>' + esc(c) + '</option>'; }).join('') +
    '<option>' + OTHER_CITY + '</option>';
  if (cur) sel.value = cur;
}
function couponValid(c, sub) {
  if (!c) return 'أدخل كود الخصم';
  if (c.expires) { var e = new Date(c.expires + 'T23:59:59').getTime(); if (isFinite(e) && e < Date.now()) return 'انتهت صلاحية هذا الكود'; }
  if (c.min && sub < c.min) return 'الحد الأدنى لهذا الكود ' + money(c.min);
  return '';
}
function couponDiscount(c, sub) {
  if (!c) return 0;
  var d = c.type === 'fixed' ? Number(c.value) : sub * Number(c.value) / 100;
  return Math.max(0, Math.min(sub, Math.round((d || 0) * 100) / 100));
}
function calcTotals(city) {
  var sub = cartTotal();
  var disc = couponDiscount(appliedCoupon, sub);
  var after = sub - disc;
  var pts = 0;
  if (usePoints) pts = Math.min(points, Math.floor(after * 0.5 / POINTS_VALUE));  // حد أقصى 50% من المبلغ
  var ptsVal = Math.round(pts * POINTS_VALUE * 100) / 100;
  var fee = city ? deliveryFee(city, after) : 0;
  return { sub: sub, disc: disc, after: after, pts: pts, ptsVal: ptsVal, fee: fee, total: after - ptsVal + fee };
}
function applyCoupon() {
  var code = (document.getElementById('coupon-input').value || '').trim().toUpperCase();
  var c = COUPONS.filter(function (x) { return String(x.code).toUpperCase() === code; })[0];
  var err = c ? couponValid(c, cartTotal()) : 'كود غير صحيح';
  if (err) { toast(err); return; }
  appliedCoupon = c; toast('تم تطبيق الكود 🎉'); updateTotals();
}
function removeCoupon() { appliedCoupon = null; document.getElementById('coupon-input').value = ''; updateTotals(); }
function togglePoints(on) { usePoints = !!on; updateTotals(); }

function updateTotals() {
  if (appliedCoupon && couponValid(appliedCoupon, cartTotal())) { toast('أُزيل الكود: ' + couponValid(appliedCoupon, cartTotal())); appliedCoupon = null; }
  var city = (document.getElementById('cust-city') || {}).value || '';
  var t = calcTotals(city);
  var free = city && DELIVERY.freeFrom > 0 && t.after >= DELIVERY.freeFrom;
  document.getElementById('cart-sub').textContent = money(t.sub);
  var dr = document.getElementById('cart-disc-row');
  dr.classList.toggle('hidden', !t.disc);
  document.getElementById('cart-disc').textContent = '− ' + money(t.disc);
  var pr = document.getElementById('cart-pts-row');
  pr.classList.toggle('hidden', !t.pts);
  document.getElementById('cart-pts').textContent = '− ' + money(t.ptsVal);
  document.getElementById('cart-fee').textContent = !city ? 'اختر المدينة' : (free ? 'مجاني 🎉' : money(t.fee));
  document.getElementById('cart-total').textContent = money(t.total);
  document.getElementById('coupon-applied').classList.toggle('hidden', !appliedCoupon);
  document.getElementById('coupon-form').classList.toggle('hidden', !!appliedCoupon);
  if (appliedCoupon) document.getElementById('coupon-applied-txt').textContent = appliedCoupon.code + ' (− ' + money(t.disc) + ')';
  var pbox = document.getElementById('points-box');
  pbox.classList.toggle('hidden', points < 10);
  document.getElementById('points-txt').textContent = 'استعمل نقاطي (' + points + ' نقطة = ' + money(points * POINTS_VALUE) + ')';
  document.getElementById('points-check').checked = usePoints;
  var hint = document.getElementById('cart-free-hint');
  if (DELIVERY.freeFrom > 0 && !free && t.sub > 0) {
    hint.textContent = 'أضف ' + money(Math.max(0, DELIVERY.freeFrom - t.after)) + ' للحصول على توصيل مجاني';
    hint.classList.remove('hidden');
  } else hint.classList.add('hidden');
}

/* اقتراحات ذكية: "يشتريها الزبناء معه" */
function renderSuggestions() {
  var box = document.getElementById('cart-suggest'); if (!box) return;
  var items = cartItems(), inCart = {}, out = [];
  items.forEach(function (i) { inCart[i.p.id] = 1; });
  function push(id) { var p = findProduct(id); if (p && !inCart[id] && out.indexOf(p) === -1) out.push(p); }
  items.forEach(function (i) { (i.p.related || []).forEach(push); });
  items.forEach(function (i) { products.forEach(function (p) { if (p.category === i.p.category) push(p.id); }); });
  out = out.slice(0, 3);
  box.classList.toggle('hidden', !out.length || !items.length);
  box.innerHTML = out.length ? '<div class="text-xs font-bold text-slate-300 mb-2">🛍️ يشتريها الزبناء معه</div><div class="grid grid-cols-3 gap-2">' + out.map(function (p) {
    return '<div class="bg-slate-800/60 border border-slate-700 rounded-xl p-2 text-center"><div class="h-14 flex items-center justify-center text-3xl overflow-hidden rounded-lg bg-slate-900 mb-1">' + shopImg(p) + '</div>' +
      '<div class="text-[11px] text-white truncate">' + esc(p.title) + '</div><div class="text-[11px] text-emerald-400 mb-1">' + money(unitPrice(p)) + '</div>' +
      '<button data-add="' + esc(p.id) + '" class="w-full py-1 bg-brand-600 hover:bg-brand-700 text-white keep-white rounded-lg text-[11px] font-bold">+ أضف</button></div>';
  }).join('') + '</div>' : '';
}

function renderCart() {
  var items = cartItems();
  var box = document.getElementById('cart-items');
  box.innerHTML = items.map(function (i) {
    return '<div class="flex items-center gap-3 bg-slate-800/60 border border-slate-700 rounded-xl p-3">' +
      '<div class="w-12 h-12 rounded-lg bg-slate-900 flex items-center justify-center text-2xl overflow-hidden shrink-0">' + shopImg(i.p) + '</div>' +
      '<div class="flex-1 min-w-0"><div class="font-bold text-sm text-white truncate">' + esc(i.p.title) + '</div>' +
      '<div class="text-xs text-slate-400">' + money(unitPrice(i.p)) + '</div></div>' +
      '<div class="flex items-center gap-1">' +
      '<button data-dec="' + esc(i.p.id) + '" class="w-7 h-7 rounded-lg bg-slate-700 text-white keep-white" aria-label="إنقاص">−</button>' +
      '<span class="w-6 text-center text-sm font-bold">' + i.qty + '</span>' +
      '<button data-inc="' + esc(i.p.id) + '" class="w-7 h-7 rounded-lg bg-slate-700 text-white keep-white" aria-label="زيادة">+</button></div>' +
      '<button data-del="' + esc(i.p.id) + '" class="text-rose-400 hover:text-rose-500 px-1" aria-label="إزالة"><i class="fa-solid fa-trash"></i></button></div>';
  }).join('');
  document.getElementById('cart-empty').classList.toggle('hidden', items.length > 0);
  document.getElementById('cart-footer').classList.toggle('hidden', items.length === 0);
  updateTotals(); renderSuggestions();
  var n = cartCount();
  var b = document.getElementById('cart-badge');
  b.textContent = n;
  b.classList.toggle('hidden', n === 0);
}

function cartChange(id, delta) {
  var q = (cart[id] || 0) + delta;
  if (q <= 0) delete cart[id]; else cart[id] = Math.min(q, 99);
  saveCart(); renderCart();
}
function cartRemove(id) { delete cart[id]; saveCart(); renderCart(); }
function clearCart() { cart = {}; saveCart(); renderCart(); }

function toggleCart(open) {
  var d = document.getElementById('cart-drawer');
  var show = typeof open === 'boolean' ? open : d.classList.contains('hidden');
  d.classList.toggle('hidden', !show);
  if (show) {
    document.getElementById('order-done').classList.add('hidden');
    document.getElementById('cart-main').classList.remove('hidden');
    var c = LS.get('m1li_cust', {});
    ['name', 'phone', 'addr', 'note'].forEach(function (k) {
      var el = document.getElementById('cust-' + k); if (el && !el.value && c[k]) el.value = c[k];
    });
    fillCities();
    var cs = document.getElementById('cust-city'); if (cs && !cs.value && c.city) cs.value = c.city;
    renderCart();
  }
}

/* ---------------- الطلب ---------------- */
function normPhone(raw) {
  var d = String(raw || '').replace(/[\s\-.()]/g, '').replace(/^\+/, '');
  if (/^212[567]\d{8}$/.test(d)) d = '0' + d.slice(3);
  else if (/^00212[567]\d{8}$/.test(d)) d = '0' + d.slice(5);
  return /^0[567]\d{8}$/.test(d) ? d : '';
}
function waNumber(local) { return '212' + String(local).replace(/^0/, ''); }
function newOrderId() { return 'M1-' + Date.now().toString(36).slice(-5).toUpperCase() + Math.floor(Math.random() * 90 + 10); }

function encodeOrder(o) {
  var compact = { n: o.id, t: o.ts, c: o.cust, i: o.items.map(function (x) { return [x.id, x.title, x.price, x.qty]; }), s: o.sub, f: o.fee, T: o.total, d: o.disc || 0, k: o.coupon || '' };
  return '#M1:' + btoa(unescape(encodeURIComponent(JSON.stringify(compact)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function decodeOrders(text) {
  var out = [], re = /#M1:([A-Za-z0-9_\-]+)/g, m;
  while ((m = re.exec(String(text || '')))) {
    try {
      var b = m[1].replace(/-/g, '+').replace(/_/g, '/'); while (b.length % 4) b += '=';
      var c = JSON.parse(decodeURIComponent(escape(atob(b))));
      var o = sanitizeOrder(c);
      if (o) out.push(o);
    } catch (e) { /* تجاهل الرموز التالفة */ }
  }
  return out;
}
function str(v, n) { return String(v == null ? '' : v).slice(0, n); }
function num(v) { v = Number(v); return isFinite(v) && v >= 0 ? v : 0; }
function sanitizeOrder(c) {
  if (!c || !c.n || !Array.isArray(c.i) || !c.c) return null;
  var items = c.i.slice(0, 50).map(function (x) { return { id: str(x[0], 40), title: str(x[1], 120), price: num(x[2]), qty: Math.min(99, Math.floor(num(x[3])) || 1) }; });
  if (!items.length) return null;
  return {
    id: str(c.n, 30), ts: num(c.t) || Date.now(), status: 'new', pay: 'cod',
    cust: { name: str(c.c.name, 60), phone: str(c.c.phone, 20), city: str(c.c.city, 40), addr: str(c.c.addr, 200), note: str(c.c.note, 200) },
    items: items, sub: num(c.s), fee: num(c.f), total: num(c.T), disc: num(c.d), coupon: str(c.k, 30), pts: 0
  };
}

function buildWhatsAppMessage(o) {
  var lines = ['🛒 *طلب جديد — ' + SHOP_CONFIG.storeName + '*', 'رقم الطلب: ' + o.id, ''];
  o.items.forEach(function (i, idx) { lines.push((idx + 1) + '. ' + i.title + ' × ' + i.qty + ' = ' + money(i.price * i.qty)); });
  lines.push('', 'المجموع: ' + money(o.sub));
  if (o.disc) lines.push('الخصم' + (o.coupon ? ' (' + o.coupon + ')' : '') + ': − ' + money(o.disc));
  lines.push('التوصيل (' + o.cust.city + '): ' + (o.fee ? money(o.fee) : 'مجاني'),
    '*الإجمالي عند الاستلام: ' + money(o.total) + '*', '💵 الدفع: عند الاستلام', '',
    '👤 الاسم: ' + o.cust.name, '📞 الهاتف: ' + o.cust.phone, '📍 المدينة: ' + o.cust.city, '🏠 العنوان: ' + o.cust.addr);
  if (o.cust.note) lines.push('📝 ملاحظات: ' + o.cust.note);
  lines.push('', encodeOrder(o));
  return lines.join('\n');
}

function whatsappUrl(num_, text) { return 'https://wa.me/' + String(num_).replace(/\D/g, '') + '?text=' + encodeURIComponent(text); }

function checkoutWhatsApp() {
  var items = cartItems();
  if (!items.length) { toast('السلة فارغة'); return; }
  var cust = {
    name: document.getElementById('cust-name').value.trim(),
    phone: normPhone(document.getElementById('cust-phone').value),
    city: document.getElementById('cust-city').value,
    addr: document.getElementById('cust-addr').value.trim(),
    note: document.getElementById('cust-note').value.trim()
  };
  if (cust.name.length < 2) { toast('أدخل اسمك الكامل'); document.getElementById('cust-name').focus(); return; }
  if (!cust.phone) { toast('رقم الهاتف غير صحيح (مثال: 0612345678)'); document.getElementById('cust-phone').focus(); return; }
  if (!cust.city) { toast('اختر المدينة'); document.getElementById('cust-city').focus(); return; }
  if (cust.addr.length < 6) { toast('أدخل عنواناً مفصلاً للتوصيل'); document.getElementById('cust-addr').focus(); return; }

  var t = calcTotals(cust.city);
  var order = {
    id: newOrderId(), ts: Date.now(), status: 'new', pay: 'cod', cust: cust,
    items: items.map(function (i) { return { id: i.p.id, title: i.p.title, price: unitPrice(i.p), qty: i.qty }; }),
    sub: t.sub, fee: t.fee, total: t.total,
    disc: t.disc + t.ptsVal, coupon: appliedCoupon ? appliedCoupon.code : '', pts: t.pts
  };
  var earned = Math.floor(order.total * POINTS_PER_DH);
  points = Math.max(0, points - t.pts) + earned; LS.set('m1li_points', points);
  appliedCoupon = null; usePoints = false;
  orders.unshift(order); saveOrders();
  LS.set('m1li_cust', cust);

  var num_ = String(SHOP_CONFIG.whatsappNumber).replace(/\D/g, '');
  var url = whatsappUrl(num_, buildWhatsAppMessage(order));
  if (!num_ || num_ === '212600000000') toast('⚠️ رقم الواتساب لم يُضبط بعد في shop.js');
  window.open(url, '_blank', 'noopener');

  cart = {}; saveCart(); renderCart();
  document.getElementById('cart-main').classList.add('hidden');
  document.getElementById('order-done').classList.remove('hidden');
  document.getElementById('od-id').textContent = order.id;
  document.getElementById('od-total').textContent = money(order.total);
  document.getElementById('od-pts').textContent = earned ? '🎁 ربحت ' + earned + ' نقطة ولاء (رصيدك ' + points + ')' : '';
  document.getElementById('od-link').href = url;
}

/* ---------------- لوحة الطلبات ---------------- */
function adminUnlocked() { try { return sessionStorage.getItem('m1li_admin') === '1'; } catch (e) { return false; } }
function openAdmin() { switchTab('admin'); }
function adminLogin() {
  var v = (document.getElementById('admin-pin') || {}).value;
  if (v === String(SHOP_CONFIG.adminPin)) { try { sessionStorage.setItem('m1li_admin', '1'); } catch (e) {} renderAdmin(); }
  else toast('الرمز غير صحيح');
}
function adminLogout() { try { sessionStorage.removeItem('m1li_admin'); } catch (e) {} switchTab('store'); }

function fmtDate(ts) {
  try { return new Date(ts).toLocaleString('ar-MA', { dateStyle: 'short', timeStyle: 'short' }); } catch (e) { return ''; }
}
function isToday(ts) { return new Date(ts).toDateString() === new Date().toDateString(); }

function renderAdmin() {
  var root = document.getElementById('admin-root'); if (!root) return;
  if (!adminUnlocked()) {
    root.innerHTML = '<div class="max-w-sm mx-auto bg-slate-800/60 border border-slate-700 rounded-2xl p-6 space-y-4 text-center">' +
      '<div class="text-4xl">🔒</div><h2 class="text-lg font-bold text-white">لوحة الطلبات</h2>' +
      '<input id="admin-pin" type="password" inputmode="numeric" autocomplete="off" placeholder="رمز الدخول" onkeydown="if(event.key===\'Enter\')adminLogin()" class="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-center text-white focus:outline-none focus:border-brand-500">' +
      '<button onclick="adminLogin()" class="w-full py-2.5 bg-brand-600 hover:bg-brand-700 text-white keep-white rounded-xl font-bold">دخول</button></div>';
    return;
  }
  var counts = { all: orders.length };
  Object.keys(ORDER_STATUS).forEach(function (k) { counts[k] = 0; });
  orders.forEach(function (o) { counts[o.status] = (counts[o.status] || 0) + 1; });
  var todayN = orders.filter(function (o) { return isToday(o.ts); }).length;
  var delivered = orders.filter(function (o) { return o.status === 'delivered'; }).reduce(function (s, o) { return s + o.total; }, 0);
  var pending = orders.filter(function (o) { return o.status === 'new' || o.status === 'confirmed' || o.status === 'shipped'; }).reduce(function (s, o) { return s + o.total; }, 0);

  var q = adminQuery.toLowerCase();
  var list = orders.filter(function (o) {
    if (adminFilter !== 'all' && o.status !== adminFilter) return false;
    return !q || (o.id + ' ' + o.cust.name + ' ' + o.cust.phone + ' ' + o.cust.city).toLowerCase().indexOf(q) !== -1;
  });

  function stat(label, val, color) {
    return '<div class="bg-slate-800/60 border border-slate-700 rounded-xl p-3 text-center"><div class="text-lg font-black ' + color + '">' + val + '</div><div class="text-[11px] text-slate-400">' + label + '</div></div>';
  }
  var chips = [['all', 'الكل']].concat(Object.keys(ORDER_STATUS).map(function (k) { return [k, ORDER_STATUS[k].label]; })).map(function (c) {
    var on = adminFilter === c[0];
    return '<button data-afilter="' + c[0] + '" class="shrink-0 px-3 py-1.5 rounded-lg text-xs ' + (on ? 'bg-brand-600 text-white keep-white font-bold' : 'bg-slate-800 text-slate-300 border border-slate-700') + '">' + c[1] + ' (' + (counts[c[0]] || 0) + ')</button>';
  }).join('');

  var cards = list.map(function (o) {
    var st = ORDER_STATUS[o.status] || ORDER_STATUS.new;
    var opts = Object.keys(ORDER_STATUS).map(function (k) { return '<option value="' + k + '"' + (k === o.status ? ' selected' : '') + '>' + ORDER_STATUS[k].label + '</option>'; }).join('');
    var ph = normPhone(o.cust.phone);
    var confirmMsg = 'مرحباً ' + o.cust.name + '، معك ' + SHOP_CONFIG.storeName + '. نؤكد طلبك رقم ' + o.id + ' بقيمة ' + money(o.total) + ' (الدفع عند الاستلام). هل العنوان صحيح؟\n' + o.cust.city + ' — ' + o.cust.addr;
    return '<div class="bg-slate-800/60 border border-slate-700 rounded-2xl p-4 space-y-3">' +
      '<div class="flex flex-wrap items-center justify-between gap-2"><div><span class="font-black text-white">' + esc(o.id) + '</span> <span class="text-[11px] text-slate-400">' + esc(fmtDate(o.ts)) + '</span></div>' +
      '<span class="text-[11px] px-2 py-0.5 rounded-full border ' + st.cls + '">' + st.label + '</span></div>' +
      '<div class="text-sm text-slate-200"><i class="fa-solid fa-user ml-1 text-slate-500"></i>' + esc(o.cust.name) + ' · <bdi dir="ltr">' + esc(o.cust.phone) + '</bdi></div>' +
      '<div class="text-xs text-slate-400"><i class="fa-solid fa-location-dot ml-1"></i>' + esc(o.cust.city) + ' — ' + esc(o.cust.addr) + '</div>' +
      (o.cust.note ? '<div class="text-xs text-amber-300/80"><i class="fa-regular fa-note-sticky ml-1"></i>' + esc(o.cust.note) + '</div>' : '') +
      '<ul class="text-xs text-slate-300 space-y-0.5 border-t border-slate-700 pt-2">' + o.items.map(function (i) { return '<li>' + esc(i.title) + ' × ' + i.qty + ' <span class="text-slate-500">(' + money(i.price * i.qty) + ')</span></li>'; }).join('') + '</ul>' +
      '<div class="flex items-center justify-between text-xs text-slate-400"><span>توصيل: ' + (o.fee ? money(o.fee) : 'مجاني') + (o.disc ? ' · خصم: ' + money(o.disc) + (o.coupon ? ' (' + esc(o.coupon) + ')' : '') : '') + '</span><span class="text-base font-black text-emerald-400">' + money(o.total) + ' <span class="text-[10px] text-slate-400 font-normal">عند الاستلام</span></span></div>' +
      '<div class="flex flex-wrap items-center gap-2">' +
      '<select data-ostatus="' + esc(o.id) + '" class="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white">' + opts + '</select>' +
      (ph ? '<a href="tel:' + ph + '" class="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white keep-white rounded-lg text-xs"><i class="fa-solid fa-phone ml-1"></i>اتصال</a>' +
        '<a href="' + esc(whatsappUrl(waNumber(ph), confirmMsg)) + '" target="_blank" rel="noopener noreferrer" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white keep-white rounded-lg text-xs"><i class="fa-brands fa-whatsapp ml-1"></i>تأكيد مع الزبون</a>' : '') +
      '<button data-odel="' + esc(o.id) + '" class="mr-auto px-3 py-1.5 text-rose-400 hover:text-rose-500 text-xs" aria-label="حذف"><i class="fa-solid fa-trash"></i></button></div></div>';
  }).join('');

  root.innerHTML =
    '<div class="flex items-center justify-between gap-3"><h2 class="text-xl font-bold text-white flex items-center gap-2"><i class="fa-solid fa-clipboard-list text-brand-400"></i> لوحة الطلبات</h2>' +
    '<button onclick="adminLogout()" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs border border-slate-700"><i class="fa-solid fa-lock ml-1"></i>خروج</button></div>' +
    (String(SHOP_CONFIG.adminPin) === '1234' ? '<div class="text-xs bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-xl p-3">⚠️ مازلت تستعمل الرمز الافتراضي 1234. غيّر <b>adminPin</b> في shop.js.</div>' : '') +
    '<div class="grid grid-cols-2 md:grid-cols-4 gap-3">' + stat('طلبات اليوم', todayN, 'text-sky-400') + stat('طلبات جديدة', counts.new || 0, 'text-amber-400') +
      stat('قيد التحصيل', money(pending), 'text-indigo-300') + stat('تم تحصيله', money(delivered), 'text-emerald-400') + '</div>' +
    '<div class="bg-slate-800/60 border border-slate-700 rounded-2xl p-4 space-y-2">' +
      '<div class="text-sm font-bold text-white">استيراد طلب من الواتساب</div>' +
      '<p class="text-[11px] text-slate-400 leading-relaxed">كل طلب يصلك فواتساب ينتهي بسطر يبدأ بـ <bdi dir="ltr">#M1:</bdi>. انسخ الرسالة كاملة والصقها هنا لتظهر في اللوحة (يمكنك لصق عدة رسائل).</p>' +
      '<textarea id="import-box" rows="3" dir="ltr" placeholder="الصق رسالة الطلب هنا..." class="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-brand-500"></textarea>' +
      '<div class="flex flex-wrap gap-2"><button onclick="importOrders()" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white keep-white rounded-lg text-xs font-bold"><i class="fa-solid fa-file-import ml-1"></i>استيراد</button>' +
      '<button onclick="copyTracking()" class="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white keep-white rounded-lg text-xs font-bold"><i class="fa-solid fa-route ml-1"></i>نسخ حالات التتبع</button>' +
      '<button onclick="exportOrdersCsv()" class="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white keep-white rounded-lg text-xs font-bold"><i class="fa-solid fa-file-csv ml-1"></i>تصدير Excel/CSV</button></div></div>' +
    '<input id="admin-search" type="search" value="' + esc(adminQuery) + '" placeholder="ابحث بالاسم أو الهاتف أو رقم الطلب أو المدينة..." class="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-brand-500">' +
    '<div class="flex gap-2 overflow-x-auto pb-1">' + chips + '</div>' +
    '<div class="space-y-3">' + (cards || '<div class="text-center text-slate-400 text-sm py-12">لا توجد طلبات هنا.</div>') + '</div>' +
    '<p class="text-[11px] text-slate-500 text-center">الطلبات تُحفظ في متصفح هذا الجهاز فقط. الرمز يحمي الواجهة من الفضول العادي وليس حماية أمنية حقيقية.</p>';
}

function setOrderStatus(id, st) {
  if (!ORDER_STATUS[st]) return;
  orders.forEach(function (o) { if (o.id === id) o.status = st; });
  saveOrders(); renderAdmin();
}
function deleteOrder(id) {
  if (!confirm('حذف الطلب ' + id + ' نهائياً؟')) return;
  orders = orders.filter(function (o) { return o.id !== id; });
  saveOrders(); renderAdmin();
}
function importOrders() {
  var found = decodeOrders(document.getElementById('import-box').value);
  if (!found.length) { toast('لم أجد رمز طلب (#M1:) في النص'); return; }
  var have = {}; orders.forEach(function (o) { have[o.id] = 1; });
  var added = 0;
  found.forEach(function (o) { if (!have[o.id]) { orders.push(o); have[o.id] = 1; added++; } });
  orders.sort(function (a, b) { return b.ts - a.ts; });
  saveOrders(); renderAdmin();
  toast(added ? 'تم استيراد ' + added + ' طلب ✅' : 'هذه الطلبات موجودة مسبقاً');
}
function copyTracking() {
  var map = {}; orders.forEach(function (o) { if (o.status !== 'new') map[o.id] = o.status; });
  var txt = JSON.stringify(map, null, 2);
  if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { toast('نُسخت. ألصقها في products.json داخل "tracking"'); }, function () { prompt('انسخ هذا النص:', txt); });
  else prompt('انسخ هذا النص:', txt);
}
function csvCell(v) { v = String(v == null ? '' : v); if (/^[=+\-@]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; }
function exportOrdersCsv() {
  if (!orders.length) { toast('لا توجد طلبات للتصدير'); return; }
  var rows = [['رقم الطلب', 'التاريخ', 'الحالة', 'الاسم', 'الهاتف', 'المدينة', 'العنوان', 'المنتجات', 'المجموع', 'التوصيل', 'الإجمالي', 'ملاحظات']];
  orders.forEach(function (o) {
    rows.push([o.id, fmtDate(o.ts), (ORDER_STATUS[o.status] || {}).label, o.cust.name, o.cust.phone, o.cust.city, o.cust.addr,
      o.items.map(function (i) { return i.title + ' x' + i.qty; }).join(' | '), o.sub, o.fee, o.total, o.cust.note]);
  });
  var csv = '﻿' + rows.map(function (r) { return r.map(csvCell).join(','); }).join('\r\n');
  var a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  a.download = 'm1li-orders.csv';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
}

/* ---------------- التقييمات ---------------- */
var rvStars = 5;
function saveReviews() { LS.set('m1li_reviews', reviews); }
function reviewStats(pid) {
  var l = reviews[pid] || [];
  if (!l.length) return { avg: 0, n: 0 };
  return { avg: l.reduce(function (s, r) { return s + r.s; }, 0) / l.length, n: l.length };
}
function starRow(avg) {
  var out = '', r = Math.round(avg);
  for (var i = 1; i <= 5; i++) out += '<i class="fa-solid fa-star text-[11px] ' + (i <= r ? 'text-amber-400' : 'text-slate-600') + '"></i>';
  return out;
}
function ratingLine(pid) {
  var st = reviewStats(pid);
  return st.n ? '<div class="flex items-center gap-1 mb-1">' + starRow(st.avg) + '<span class="text-[10px] text-slate-400">' + st.avg.toFixed(1) + ' (' + st.n + ')</span></div>' : '';
}
function setRvStars(n) { rvStars = n; renderReviews(); }
function renderReviews() {
  var box = document.getElementById('pm-reviews'); if (!box || !galleryState.id) return;
  var pid = galleryState.id, list = (reviews[pid] || []).slice().reverse().slice(0, 20), st = reviewStats(pid);
  var keepName = (document.getElementById('rv-name') || {}).value || LS.get('m1li_rvname', '');
  var keepText = (document.getElementById('rv-text') || {}).value || '';
  var stars = '';
  for (var i = 1; i <= 5; i++) stars += '<button type="button" onclick="setRvStars(' + i + ')" class="text-xl ' + (i <= rvStars ? 'text-amber-400' : 'text-slate-600') + '" aria-label="' + i + ' نجوم"><i class="fa-solid fa-star"></i></button>';
  box.innerHTML = '<div class="border-t border-slate-700 pt-4 space-y-3">' +
    '<div class="flex items-center justify-between"><h4 class="font-bold text-white text-sm">آراء الزبناء</h4>' + (st.n ? '<div class="flex items-center gap-1">' + starRow(st.avg) + '<span class="text-xs text-slate-400">' + st.avg.toFixed(1) + ' (' + st.n + ')</span></div>' : '') + '</div>' +
    (list.length ? list.map(function (r) {
      return '<div class="bg-slate-800/60 border border-slate-700 rounded-xl p-3"><div class="flex items-center justify-between text-xs"><span class="font-bold text-white">' + esc(r.n) + '</span>' + starRow(r.s) + '</div>' +
        (r.t ? '<p class="text-xs text-slate-300 mt-1 leading-relaxed">' + esc(r.t) + '</p>' : '') + '</div>';
    }).join('') : '<p class="text-xs text-slate-500">لا توجد تقييمات بعد. كن أول من يقيّم.</p>') +
    '<div class="space-y-2 bg-slate-800/40 border border-slate-700 rounded-xl p-3"><div class="flex items-center gap-1">' + stars + '</div>' +
    '<input id="rv-name" maxlength="30" placeholder="اسمك" value="' + esc(keepName) + '" class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-brand-500">' +
    '<textarea id="rv-text" rows="2" maxlength="300" placeholder="رأيك في المنتج (اختياري)" class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-brand-500">' + esc(keepText) + '</textarea>' +
    '<button onclick="submitReview()" class="w-full py-2 bg-brand-600 hover:bg-brand-700 text-white keep-white rounded-lg text-xs font-bold">إرسال التقييم</button>' +
    '<p class="text-[10px] text-slate-500">التقييمات تُحفظ على هذا الجهاز فقط.</p></div></div>';
}
function submitReview() {
  var pid = galleryState.id; if (!pid) return;
  var n = (document.getElementById('rv-name').value || '').trim().slice(0, 30);
  var t = (document.getElementById('rv-text').value || '').trim().slice(0, 300);
  if (n.length < 2) { toast('أدخل اسمك'); return; }
  LS.set('m1li_rvname', n);
  (reviews[pid] = reviews[pid] || []).push({ n: n, s: rvStars, t: t, ts: Date.now() });
  if (reviews[pid].length > 200) reviews[pid].shift();
  saveReviews();
  document.getElementById('rv-text').value = '';
  renderReviews(); renderProducts();
  toast('شكراً لتقييمك ⭐');
}

/* ---------------- تتبع الطلب ---------------- */
var TRACK_STEPS = ['new', 'confirmed', 'shipped', 'delivered'];
function openTrack() { document.getElementById('track-modal').classList.remove('hidden'); document.getElementById('track-result').innerHTML = ''; }
function closeTrack() { document.getElementById('track-modal').classList.add('hidden'); }
function doTrack() {
  var id = (document.getElementById('track-input').value || '').trim().toUpperCase();
  var box = document.getElementById('track-result');
  if (!id) { toast('أدخل رقم الطلب'); return; }
  var st = TRACKING[id];
  if (!ORDER_STATUS[st]) {
    var o = orders.filter(function (x) { return x.id.toUpperCase() === id; })[0];
    st = o ? o.status : null;
  }
  if (!st) {
    var num_ = String(SHOP_CONFIG.whatsappNumber).replace(/\D/g, '');
    box.innerHTML = '<div class="text-sm text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 leading-relaxed">لم نجد هذا الرقم. تأكد منه، أو تواصل معنا عبر <a class="underline" target="_blank" rel="noopener noreferrer" href="' + esc(whatsappUrl(num_, 'مرحباً، أريد معرفة حالة طلبي رقم ' + id)) + '">الواتساب</a>.</div>';
    return;
  }
  var info = ORDER_STATUS[st], html;
  if (st === 'cancelled' || st === 'returned') {
    html = '<div class="text-center"><span class="text-sm px-3 py-1 rounded-full border ' + info.cls + '">' + info.label + '</span></div>';
  } else {
    var idx = TRACK_STEPS.indexOf(st);
    html = '<ol class="space-y-3">' + TRACK_STEPS.map(function (k, i) {
      var done = i <= idx;
      return '<li class="flex items-center gap-3"><span class="w-7 h-7 rounded-full flex items-center justify-center text-xs ' + (done ? 'bg-emerald-600 text-white keep-white' : 'bg-slate-700 text-slate-400') + '">' + (done ? '✓' : (i + 1)) + '</span>' +
        '<span class="text-sm ' + (done ? 'text-white font-bold' : 'text-slate-500') + '">' + ORDER_STATUS[k].label + '</span></li>';
    }).join('') + '</ol>';
  }
  box.innerHTML = '<div class="bg-slate-800/60 border border-slate-700 rounded-xl p-4 space-y-3"><div class="text-xs text-slate-400">الطلب <b class="text-white">' + esc(id) + '</b></div>' + html + '</div>';
}

/* ---------------- الأحداث ---------------- */
document.addEventListener('click', function (e) {
  var t = e.target.closest('[data-add],[data-inc],[data-dec],[data-del],[data-view],[data-gal],[data-afilter],[data-odel]');
  if (!t) return;
  if (t.dataset.add) { cartChange(t.dataset.add, 1); toast('أُضيف إلى السلة 🛒'); }
  else if (t.dataset.inc) cartChange(t.dataset.inc, 1);
  else if (t.dataset.dec) cartChange(t.dataset.dec, -1);
  else if (t.dataset.del) cartRemove(t.dataset.del);
  else if (t.dataset.view) openProduct(t.dataset.view);
  else if (t.dataset.gal) { galleryState.i = +t.dataset.gal; renderGallery(); }
  else if (t.dataset.afilter) { adminFilter = t.dataset.afilter; renderAdmin(); }
  else if (t.dataset.odel) deleteOrder(t.dataset.odel);
});
document.addEventListener('change', function (e) {
  if (e.target.dataset && e.target.dataset.ostatus) setOrderStatus(e.target.dataset.ostatus, e.target.value);
  if (e.target.id === 'cust-city') updateTotals();
});
document.addEventListener('input', function (e) {
  if (e.target.id === 'admin-search') {
    adminQuery = e.target.value.trim();
    var pos = e.target.selectionStart; renderAdmin();
    var s = document.getElementById('admin-search'); s.focus(); try { s.setSelectionRange(pos, pos); } catch (er) {}
  }
});
document.addEventListener('keydown', function (e) {
  if (document.getElementById('product-modal').classList.contains('hidden')) return;
  if (e.key === 'Escape') closeProduct();
  if (e.target && /INPUT|TEXTAREA/.test(e.target.tagName)) return;
  if (e.key === 'ArrowLeft') galleryStep(1);
  if (e.key === 'ArrowRight') galleryStep(-1);
});

function loadProducts() {
  renderProducts(); renderCart();
  if (!window.fetch) return;
  fetch('products.json', { cache: 'no-cache' }).then(function (r) { return r.json(); }).then(function (d) {
    if (d && Array.isArray(d.products) && d.products.length) {
      products = d.products.filter(function (p) { return p && p.id && p.title && isFinite(p.price); });
      if (d.currency) SHOP_CONFIG.currency = d.currency;
      if (d.delivery && typeof d.delivery === 'object') {
        if (d.delivery.cities && typeof d.delivery.cities === 'object') DELIVERY.cities = d.delivery.cities;
        if (isFinite(d.delivery.freeFrom)) DELIVERY.freeFrom = Number(d.delivery.freeFrom);
        if (isFinite(d.delivery.defaultFee)) DELIVERY.defaultFee = Number(d.delivery.defaultFee);
      }
      if (Array.isArray(d.coupons)) COUPONS = d.coupons.filter(function (c) { return c && c.code && isFinite(c.value); });
      DEAL = d.deal && d.deal.id ? d.deal : null;
      TRACKING = d.tracking && typeof d.tracking === 'object' ? d.tracking : {};
      renderProducts(); renderCart(); fillCities(); renderDeal();
    }
  }).catch(function () { /* keep fallback */ });
}

/* PWA */
if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
  window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); });
}

loadProducts();
if (location.hash === '#admin') openAdmin();
