import * as THREE from 'three';
import { PSX } from 'three-psx';
import { PRESETS } from './settings.js';

export function createRenderer(canvas, initialPreset = 'medium') {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false, powerPreference: 'low-power' });
  renderer.setPixelRatio(1);
  renderer.shadowMap.enabled = false;
  const size = () => ({ width: Math.max(1,innerWidth), height: Math.max(1,innerHeight) });
  let preset = PRESETS[initialPreset] ? initialPreset : 'medium';
  const initial = size(), config = PRESETS[preset];
  renderer.setSize(initial.width,initial.height,false);
  const psx = new PSX({
    renderer, width: Math.max(1,Math.floor(initial.width*config.scale)),
    height: Math.max(1,Math.floor(initial.height*config.scale)),
    scaleMode: 'stretch', dither: config.dither, ditherMode: 2,
    colorBits: config.colorBits, bloom: 0, wobbleHoldFps: 15
  });
  psx.setLight([-0.35,-1,-0.25],0x536274,0x29231f);
  psx.setPointLight([0,3.25,0],0xffbd70,9);
  psx.shared.jitter.value = 0.85;
  psx.setFog(0x11171a,2,config.fogFar);
  canvas.style.width='100vw'; canvas.style.height='100vh'; canvas.style.imageRendering='pixelated';

  function resize(){
    const {width,height}=size(); renderer.setSize(width,height,false); psx.setSize(width,height);
    const current=PRESETS[preset]; psx.setResolution(Math.max(1,Math.floor(width*current.scale)),Math.max(1,Math.floor(height*current.scale)));
  }
  function applyPreset(name){
    preset=PRESETS[name]?name:'medium'; const current=PRESETS[preset],{width,height}=size();
    psx.setResolution(Math.max(1,Math.floor(width*current.scale)),Math.max(1,Math.floor(height*current.scale)));
    psx.setColorBits(current.colorBits); psx.blitMaterial.uniforms.uDither.value=current.dither;
    psx.setFog(0x11171a,2,current.fogFar);
  }
  return { psx, applyPreset, resize, render:(scene,camera,time)=>psx.render(scene,camera,time), dispose(){psx.dispose();renderer.dispose();} };
}
