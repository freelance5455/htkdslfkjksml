import * as THREE from 'three';
import { PSX } from 'three-psx';
import { PRESETS } from './settings.js';

export function getViewportSize(){
  const rotated=document.body?.classList.contains('portrait-rotated')===true;
  return {width:Math.max(1,rotated?innerHeight:innerWidth),height:Math.max(1,rotated?innerWidth:innerHeight)};
}

export function createRenderer(canvas, initialPreset = 'medium') {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false, powerPreference: 'low-power' });
  renderer.setPixelRatio(1);
  renderer.shadowMap.enabled = false;
  const size = getViewportSize;
  let preset = PRESETS[initialPreset] ? initialPreset : 'medium';
  const initial = size(), config = PRESETS[preset];
  renderer.setSize(initial.width,initial.height,false);
  const psx = new PSX({
    renderer, width: Math.max(1,Math.floor(initial.width*config.scale)),
    height: Math.max(1,Math.floor(initial.height*config.scale)),
    scaleMode: 'stretch', dither: config.dither, ditherMode: 2,
    colorBits: config.colorBits, bloom: 0, wobbleHoldFps: 15
  });
  psx.setLight([-0.35,-1,-0.25],0x536274,0x29231f);
  psx.setPointLight([0,3.25,0],0xffbd70,9);
  const baseLight=psx.shared.lightColor.value.clone(),baseAmbient=psx.shared.ambient.value.clone(),basePoint=psx.shared.pointColor.value.clone();
  let lightIntensity=1;
  function setLightIntensity(level=1){const amount=Math.max(0,Math.min(1,level));if(amount===lightIntensity)return;lightIntensity=amount;psx.shared.lightColor.value.copy(baseLight).multiplyScalar(amount);psx.shared.ambient.value.copy(baseAmbient).multiplyScalar(amount);psx.shared.pointColor.value.copy(basePoint).multiplyScalar(amount);}
  psx.shared.jitter.value = 0.85;
  psx.setFog(0x11171a,2,config.fogFar);
  canvas.style.width='100vw'; canvas.style.height='100vh'; canvas.style.imageRendering='pixelated';

  function resize(){
    const {width,height}=size(); renderer.setSize(width,height,false); psx.setSize(width,height);
    const current=PRESETS[preset]; psx.setResolution(Math.max(1,Math.floor(width*current.scale)),Math.max(1,Math.floor(height*current.scale)));
  }
  function applyPreset(name){
    preset=PRESETS[name]?name:'medium'; const current=PRESETS[preset],{width,height}=size();
    psx.setResolution(Math.max(1,Math.floor(width*current.scale)),Math.max(1,Math.floor(height*current.scale)));
    psx.setColorBits(current.colorBits); psx.blitMaterial.uniforms.uDither.value=current.dither;
    psx.setFog(0x11171a,2,current.fogFar);
  }
  return { psx, applyPreset, resize, setLightIntensity, render:(scene,camera,time)=>psx.render(scene,camera,time), dispose(){psx.dispose();renderer.dispose();} };
}
