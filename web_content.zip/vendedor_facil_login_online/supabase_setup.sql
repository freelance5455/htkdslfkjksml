-- Vendedor Fácil: execute este script no SQL Editor do Supabase.
-- Cada linha pertence ao usuário autenticado que a criou.
create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  customer_name text not null,
  phone text not null default '',
  address text not null default '',
  product_name text not null,
  sale_date date not null,
  amount numeric(12,2) not null check (amount > 0),
  cost numeric(12,2) not null default 0 check (cost >= 0),
  due_date date not null,
  notes text not null default '',
  is_paid boolean not null default false,
  paid_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.sales enable row level security;

-- Políticas limitam leitura, inclusão, alteração e exclusão ao dono do registro.
drop policy if exists "seller reads own sales" on public.sales;
create policy "seller reads own sales" on public.sales
for select to authenticated using (auth.uid() = user_id);

drop policy if exists "seller inserts own sales" on public.sales;
create policy "seller inserts own sales" on public.sales
for insert to authenticated with check (auth.uid() = user_id);

drop policy if exists "seller updates own sales" on public.sales;
create policy "seller updates own sales" on public.sales
for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "seller deletes own sales" on public.sales;
create policy "seller deletes own sales" on public.sales
for delete to authenticated using (auth.uid() = user_id);

create index if not exists sales_user_due_date_idx on public.sales(user_id, due_date);
create index if not exists sales_user_sale_date_idx on public.sales(user_id, sale_date);

-- Não crie políticas públicas. Nunca coloque a service_role key no aplicativo.
