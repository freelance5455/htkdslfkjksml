/* AsimAI Pro upgrades: isolated UI and voice layer; original app modules remain active. */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);

  function buildHistoryPage(app) {
    if (!$('historyPage')) {
      const page = document.createElement('section');
      page.id = 'historyPage';
      page.hidden = true;
      page.innerHTML = `
        <header class="history-page-head">
          <button id="historyBackBtn" type="button" aria-label="Back to chat"><i class="fa-solid fa-arrow-left"></i></button>
          <h2>Chat history</h2><span class="history-count" id="historyCount"></span>
        </header>
        <div class="history-page-list" id="historyPageList"></div>`;
      document.body.appendChild(page);
    }
    const page = $('historyPage');
    const list = $('historyPageList');
    const persist = async () => {
      await Storage.saveConversations(app.conversations);
      app.renderSidebarHistory?.();
    };
    const open = () => {
      app.headerMoreMenu?.classList.add('hidden');
      list.replaceChildren();
      const chats = [...(app.conversations || [])].sort((a,b) =>
        new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0));
      $('historyCount').textContent = `${chats.length} chats`;
      if (!chats.length) {
        const empty = document.createElement('div');
        empty.className = 'history-empty';
        empty.innerHTML = '<i class="fa-regular fa-comments"></i><p>No saved conversations yet</p>';
        list.appendChild(empty);
      }
      chats.forEach(conv => {
        const item = document.createElement('article');
        item.className = 'history-entry';
        const openBtn = document.createElement('button');
        openBtn.type = 'button'; openBtn.className = 'history-entry-open';
        const icon = document.createElement('i'); icon.className = 'fa-regular fa-message';
        const content = document.createElement('span'); content.className = 'history-entry-content';
        const title = document.createElement('strong'); title.textContent = conv.title || 'New chat';
        const preview = document.createElement('span'); preview.className = 'history-preview';
        preview.textContent = (conv.messages || []).slice(-1)[0]?.text?.slice(0,100) || 'No messages';
        const date = document.createElement('small');
        date.textContent = new Date(conv.updatedAt || conv.createdAt || Date.now()).toLocaleDateString();
        content.append(title, preview); openBtn.append(icon, content, date);
        openBtn.addEventListener('click', async () => {
          app.activeConversationId = conv.id;
          try { await Storage.setActiveId(conv.id); } catch(e) {}
          app.renderSidebarHistory?.(); app.renderActiveConversation?.();
          page.hidden = true; document.body.classList.remove('history-page-open');
        });
        const actions = document.createElement('div'); actions.className = 'history-entry-actions';
        const rename = document.createElement('button'); rename.type='button'; rename.title='Rename chat'; rename.setAttribute('aria-label','Rename chat'); rename.innerHTML='<i class="fa-solid fa-pen"></i>';
        rename.addEventListener('click', async () => {
          const next = window.prompt('Enter a new chat name:', conv.title || 'New chat');
          if (next === null) return;
          const clean = next.trim();
          if (!clean) { window.alert('Chat name cannot be empty.'); return; }
          conv.title = clean; conv.updatedAt = new Date().toISOString();
          await persist(); open();
        });
        const remove = document.createElement('button'); remove.type='button'; remove.title='Delete chat'; remove.setAttribute('aria-label','Delete chat'); remove.innerHTML='<i class="fa-solid fa-trash"></i>';
        remove.addEventListener('click', async () => {
          if (!window.confirm(`Delete "${conv.title || 'New chat'}"? This cannot be undone.`)) return;
          app.conversations = app.conversations.filter(c => c.id !== conv.id);
          if (app.activeConversationId === conv.id) {
            app.activeConversationId = app.conversations[0]?.id || null;
            try {
              if (app.activeConversationId) await Storage.setActiveId(app.activeConversationId);
              else await Storage.setActiveId(null);
            } catch(e) {}
            if (!app.activeConversationId) await app.createNewConversation?.();
            else app.renderActiveConversation?.();
          }
          await persist(); open();
        });
        actions.append(rename, remove); item.append(openBtn, actions); list.appendChild(item);
      });
      page.hidden = false; document.body.classList.add('history-page-open');
    };
    $('historyBackBtn').onclick = () => { page.hidden = true; document.body.classList.remove('history-page-open'); };
    app.openHistoryPage = open;
    ['openHistoryPageBtn', 'openHistorySidebarBtn'].forEach(id => {
      const historyBtn = $(id);
      if (historyBtn && !historyBtn.dataset.bound) {
        historyBtn.dataset.bound = '1';
        historyBtn.addEventListener('click', e => {
          e.preventDefault(); e.stopPropagation();
          app.toggleSidebar?.(false);
          open();
        });
      }
    });
  }

  function apply(app) {
    if (!app || app.__asimProApplied) return;
    app.__asimProApplied = true;
    buildHistoryPage(app);

    // JARVIS is deliberately ephemeral: never read, render, or write a transcript.
    try { localStorage.removeItem('asimai_jarvis_conversation_v1'); } catch(e) {}
    app.jarvisMessages = [];
    app.loadJarvisMessages = () => [];
    app.saveJarvisMessages = () => { try { localStorage.removeItem('asimai_jarvis_conversation_v1'); } catch(e) {} };
    app.renderJarvisMessages = () => { if (app.jarvisConversationLog) app.jarvisConversationLog.replaceChildren(); };
    app.appendJarvisMessage = () => {}; // no in-memory transcript either
    app.settings = app.settings || {};
    app.settings.jarvisVoice = true;
    if (app.jarvisVoiceToggle) app.jarvisVoiceToggle.checked = true;

    app.stopJarvisSpeech = function() {
      this._jarvisHandsFree = false;
      try { this._jarvisRecognition?.stop(); } catch(e) {}
      this._jarvisRecognition = null;
      try { window.speechSynthesis?.cancel(); } catch(e) {}
      this.jarvisCore?.classList.remove('jarvis-speaking');
      if (this.jarvisState) this.jarvisState.textContent = 'VOICE PAUSED';
    };

    app.speakJarvis = function(text) {
      if (!('speechSynthesis' in window)) return;
      const clean = String(text || '').replace(/```[\s\S]*?```/g,'Code block omitted from voice reply.')
        .replace(/[*_#>`[\]()]/g,' ').replace(/\s+/g,' ').trim();
      if (!clean) return;
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(clean);
      const voices = window.speechSynthesis.getVoices();
      const voice = voices.find(v => /en-IN/i.test(v.lang)) || voices.find(v => /hi-IN/i.test(v.lang)) ||
                    voices.find(v => /en-GB|en-US/i.test(v.lang));
      if (voice) utterance.voice = voice;
      utterance.lang = voice?.lang || 'en-IN';
      utterance.rate = 0.96; utterance.pitch = 1.02; utterance.volume = 1;
      utterance.onstart = () => { this.jarvisCore?.classList.add('jarvis-speaking'); if (this.jarvisState) this.jarvisState.textContent = 'JARVIS SPEAKING'; };
      utterance.onend = () => {
        this.jarvisCore?.classList.remove('jarvis-speaking');
        if (this._jarvisHandsFree) {
          if (this.jarvisState) this.jarvisState.textContent = 'LISTENING FOR YOUR NEXT COMMAND';
          setTimeout(() => { if (this._jarvisHandsFree && !this._jarvisGenerating) this.startJarvisVoiceInput(); }, 450);
        } else if (this.jarvisState) this.jarvisState.textContent = 'TAP MIC TO SPEAK';
      };
      utterance.onerror = () => { this.jarvisCore?.classList.remove('jarvis-speaking'); };
      window.speechSynthesis.speak(utterance);
    };

    app.startJarvisVoiceInput = function() {
      if (this._jarvisGenerating) return;
      if (this._jarvisRecognition) {
        try { this._jarvisRecognition.stop(); } catch(e) {}
        this._jarvisRecognition = null;
        this._jarvisHandsFree = false;
        if (this.jarvisState) this.jarvisState.textContent = 'VOICE PAUSED';
        return;
      }
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SR) {
        if (this.jarvisState) this.jarvisState.textContent = 'VOICE INPUT NOT SUPPORTED';
        ChatRenderer.showToast('Voice recognition ke liye Chrome aur microphone permission check karein.');
        return;
      }
      this._jarvisHandsFree = true;
      try {
        const rec = new SR();
        rec.lang = 'en-IN'; // Best broadly-supported locale for Hinglish code-switching.
        rec.continuous = false; rec.interimResults = false; rec.maxAlternatives = 1;
        rec.onstart = () => { if (this.jarvisState) this.jarvisState.textContent = 'SUN RAHA HOON…'; this.jarvisCore?.classList.add('jarvis-speaking'); };
        rec.onresult = (event) => {
          const transcript = Array.from(event.results || []).map(r => r?.[0]?.transcript || '').join(' ').trim();
          this.jarvisCore?.classList.remove('jarvis-speaking');
          if (transcript) this.sendJarvisMessage(transcript);
        };
        rec.onerror = (event) => {
          this.jarvisCore?.classList.remove('jarvis-speaking');
          if (this.jarvisState) this.jarvisState.textContent = 'MICROPHONE ERROR';
          if (event?.error !== 'no-speech' && event?.error !== 'aborted') ChatRenderer.showToast('Mic issue: ' + (event?.error || 'permission check karein'));
        };
        rec.onend = () => { this._jarvisRecognition = null; this.jarvisCore?.classList.remove('jarvis-speaking'); };
        this._jarvisRecognition = rec; rec.start();
      } catch(err) {
        this._jarvisRecognition = null;
        this._jarvisHandsFree = false;
        if (this.jarvisState) this.jarvisState.textContent = 'MICROPHONE UNAVAILABLE';
        ChatRenderer.showToast('Mic start nahi ho saka. Permission check karein.');
      }
    };

    app.sendJarvisMessage = async function(rawText) {
      const text = String(rawText || '').trim();
      if (!text || this._jarvisGenerating) return;
      if (this.handleJarvisCommand(text)) return;
      this._jarvisGenerating = true;
      if (this.jarvisState) this.jarvisState.textContent = 'SOCH RAHA HOON…';
      try {
        const settings = await Storage.getSettings();
        const model = settings.providerModels?.[settings.provider] || settings.model || 'auto';
        const system = `You are J.A.R.V.I.S., AsimAI's voice-only assistant. Speak naturally in friendly Pakistani Hinglish written in Roman Urdu mixed with simple English. Reply in concise, smooth, conversational Hinglish by default. Understand Urdu, Hindi and English voice input. Do not use Devanagari or Urdu script unless explicitly requested. Avoid markdown, tables, code fences and long lists in spoken replies; for code requests, explain briefly and offer the code in the main AsimAI chat only if asked. Be accurate, helpful and warm. Current date: ${new Date().toLocaleDateString()}.`;
        let answer = '';
        const result = await AIEngine.generateResponse([{ sender: 'user', text }], model, system, !!settings.realWebSearch, chunk => {
          if (this.jarvisState) this.jarvisState.textContent = 'JAWAB TAYYAR HO RAHA HAI…';
        });
        answer = typeof result === 'string' ? result : (AIEngine.lastResponse || '');
        if (!String(answer).trim()) throw new Error('Empty AI response');
        this.settings.jarvisVoice = true;
        this.speakJarvis(answer);
      } catch(err) {
        if (this.jarvisState) this.jarvisState.textContent = 'CONNECTION ISSUE';
        ChatRenderer.showToast('JARVIS: ' + (err.message || 'request failed'));
        if (this._jarvisHandsFree) this.speakJarvis('Connection mein issue aa gaya hai. Please dobara try karein.');
      } finally {
        this._jarvisGenerating = false;
      }
    };

    // Remove every visual text/chat control; keep only the microphone as the interaction.
    ['jarvisComposerInput','jarvisComposerSendBtn','jarvisConversationLog','jarvisReadBtn','jarvisModeToggle','jarvisVoiceToggle'].forEach(id => {
      const el = $(id); if (el) { el.value = ''; el.classList.add('hidden'); el.setAttribute('aria-hidden','true'); }
    });
    document.querySelectorAll('#jarvisModal .jarvis-setting-row,#jarvisModal .jarvis-conversation-log').forEach(el => el.remove());
    if ($('jarvisState')) $('jarvisState').textContent = 'TAP MIC TO SPEAK';
    if ($('jarvisListenBtn')) {
      const oldMic = $('jarvisListenBtn');
      const mic = oldMic.cloneNode(true);
      oldMic.replaceWith(mic);
      app.jarvisListenBtn = mic;
      mic.setAttribute('aria-label','Start or pause voice conversation');
      mic.addEventListener('click', () => {
        if (app._jarvisHandsFree) app.stopJarvisSpeech();
        else app.startJarvisVoiceInput();
      });
    }

    // The IDE activity rail now has four distinct, generously sized hit targets.
    document.querySelectorAll('#idePage .ide-activity button').forEach(btn => {
      btn.setAttribute('role','button');
      btn.style.webkitTapHighlightColor = 'transparent';
    });
  }

  function bootPatch() {
    const app = window.appInstance;
    if (app) { apply(app); return; }
    setTimeout(bootPatch, 180);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(bootPatch, 0), {once:true});
  else setTimeout(bootPatch, 0);
})();
