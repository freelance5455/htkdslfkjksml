CAMPUS BEAST Android wrapper project

This project packages the supplied HTML prototype and embedded logo into a basic Android WebView app. The prototype is local; the Google Fonts stylesheet may use internet if available, but system fonts are the fallback. Demo listings and actions remain sample/prototype behavior.

To build an installable APK:
1. Install Android Studio on a computer.
2. Open this CampusBeast folder as an existing project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK under app/build/outputs/apk/debug/app-debug.apk and transfer it to your phone.
6. On the phone, tap the APK and allow your file manager to install unknown apps if Android asks.

Note: This source bundle is not itself an APK. It needs Android SDK/Gradle build tools to compile.
