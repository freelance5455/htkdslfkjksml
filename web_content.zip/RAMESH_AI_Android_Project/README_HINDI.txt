RAMESH AI STUDIO — Android Studio Project
=========================================

यह Android WebView wrapper project है। इसमें आपकी HTML ऐप assets में रखी गई है।
ऐप का शुरुआती स्क्रीन और HTML के उपलब्ध फीचर फोन पर ऑफलाइन चल सकते हैं।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio > Open > इस फोल्डर (RAMESH_AI_Android_Project) को चुनें।
4. Gradle Sync पूरा होने दें और Android SDK Platform 35 इंस्टॉल करें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. बनी APK को अपने फोन में भेजकर इंस्टॉल करें।

ध्यान दें:
- इस प्रोजेक्ट को इस चैट के वातावरण में APK के रूप में compile नहीं किया गया है।
- ChatGPT जैसी ऑनलाइन AI, फोटो/वीडियो जनरेशन, और APK cloud build के लिए अलग सुरक्षित backend
  तथा API/service connection चाहिए।
- API key को HTML या Android ऐप में कभी न रखें; उसे backend पर सुरक्षित रखें।
- फोन कॉल लिंक डायलर खोलने के लिए है; कॉल उपयोगकर्ता खुद confirm करेगा।
- HTML का PIN lock अकेले पूर्ण encryption या सुरक्षित account system नहीं है।
- माइक्रोफोन, फाइल और बाहरी ऐप सुविधाएँ Android/WebView और फोन की permissions पर निर्भर हैं।
- यह प्रोजेक्ट निजी उपयोग के लिए starter है; इसमें कोई public server अपने-आप नहीं बनता।
