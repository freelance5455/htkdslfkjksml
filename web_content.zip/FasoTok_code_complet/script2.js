document.addEventListener("DOMContentLoaded", () => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => Array.from(root.querySelectorAll(s));

  const feed = $("#video-feed");
  const emptyFeed = $("#empty-feed");
  const uploadModal = $("#upload-modal");
  const commentsModal = $("#comments-modal");
  const picker = $("#media-picker");
  const webcam = $("#webcam");
  const cameraPlaceholder = $("#camera-placeholder");
  const publishBtn = $("#publish-btn");
  const captionInput = $("#post-caption");
  const recordButton = $("#record-button");
  const recordStatus = $("#record-status");
  let posts = [];
  let currentPostForComments = null;
  let chosenFile = null;
  let chosenUrl = "";
  let cameraStream = null;
  let recorder = null;
  let recordedChunks = [];
  let activeFilter = "none";
  let lastTapTime = 0;
  let lastTapCard = null;
  let lastTapPoint = null;

  const profile = {
    username: localStorage.getItem("fasotok_username") || "fasotok",
    bio: localStorage.getItem("fasotok_bio") || "Bienvenue sur mon profil FasoTok !"
  };

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, ch => ({
      "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
    }[ch]));
  }
  function toast(message) {
    const old = $(".toast");
    if (old) old.remove();
    const node = document.createElement("div");
    node.className = "toast";
    node.textContent = message;
    $(".fasotoc-app").appendChild(node);
    setTimeout(() => node.remove(), 2600);
  }
  function showScreen(id) {
    $$(".screen").forEach(screen => {
      screen.classList.toggle("active-screen", screen.id === id);
      screen.classList.toggle("hidden", screen.id !== id);
    });
    $$(".nav-item[data-screen]").forEach(btn => btn.classList.toggle("active-nav", btn.dataset.screen === id));
    $("#top-nav").classList.toggle("hidden", id !== "home-screen");
    if (id === "profile-screen") renderProfile();
    if (id === "discover-screen") renderSearch($("#search-input").value);
  }
  function updateEmpty() {
    emptyFeed.classList.toggle("hidden", posts.length > 0);
    feed.classList.toggle("hidden", posts.length === 0);
  }
  function countText(n) {
    if (n >= 1000000) return (n/1000000).toFixed(1).replace(".0","") + "M";
    if (n >= 1000) return (n/1000).toFixed(1).replace(".0","") + "k";
    return String(n);
  }
  function addHeart(card, x, y) {
    const heart = document.createElement("div");
    heart.className = "fasotok-heart-animation";
    heart.textContent = "❤️";
    const rect = card.getBoundingClientRect();
    heart.style.left = (x - rect.left) + "px";
    heart.style.top = (y - rect.top) + "px";
    card.appendChild(heart);
    setTimeout(() => heart.remove(), 800);
  }
  function mediaNode(post, className="video-media") {
    const el = document.createElement(post.type === "video" ? "video" : "img");
    el.className = className;
    el.src = post.url;
    if (post.type === "video") {
      el.loop = true;
      el.muted = true;
      el.autoplay = true;
      el.playsInline = true;
      el.setAttribute("playsinline", "");
      el.addEventListener("click", () => {
        if (el.paused) el.play().catch(()=>{}); else el.pause();
      });
      el.play().catch(()=>{});
    } else {
      el.alt = "Publication photo";
    }
    return el;
  }
  function makePostCard(post) {
    const card = document.createElement("article");
    card.className = "video-card";
    card.dataset.postId = post.id;

    card.appendChild(mediaNode(post));
    const shade = document.createElement("div");
    shade.className = "video-shade";
    card.appendChild(shade);

    const footer = document.createElement("div");
    footer.className = "video-footer";
    footer.innerHTML = `<h3>@${escapeHTML(post.username)}</h3><p>${escapeHTML(post.caption || "Ma publication 🇧🇫")}</p><div class="music-ticker">🎵 Son original · FasoTok</div>`;
    card.appendChild(footer);

    const side = document.createElement("div");
    side.className = "interaction-sidebar";
    side.innerHTML = `
      <div class="icon-group"><div class="circle-profile">🇧🇫</div><div class="plus-badge" aria-label="Suivre">+</div></div>
      <div class="icon-group"><button class="action-btn like-btn ${post.liked ? "liked" : ""}" aria-label="J’aime">♥</button><span class="count like-count">${countText(post.likes)}</span></div>
      <div class="icon-group"><button class="action-btn comment-btn" aria-label="Commentaires">▢</button><span class="count comment-count">${post.comments.length}</span></div>
      <div class="icon-group"><button class="action-btn save-btn ${post.saved ? "saved" : ""}" aria-label="Favoris">★</button><span class="count">Favoris</span></div>
      <div class="icon-group"><button class="action-btn share-btn" aria-label="Partager">↗</button><span class="count">Partager</span></div>`;
    card.appendChild(side);

    $(".like-btn", side).addEventListener("click", () => toggleLike(post, card));
    $(".comment-btn", side).addEventListener("click", () => openComments(post));
    $(".save-btn", side).addEventListener("click", () => {
      post.saved = !post.saved;
      $(".save-btn", side).classList.toggle("saved", post.saved);
      toast(post.saved ? "Ajouté aux favoris sur cet appareil" : "Retiré des favoris");
    });
    $(".share-btn", side).addEventListener("click", () => sharePost(post));
    card.addEventListener("pointerup", event => {
      if (event.target.closest("button, input, textarea, a")) return;
      const now = Date.now();
      const point = {x:event.clientX,y:event.clientY};
      const doubleTap = now-lastTapTime < 360 && lastTapCard === card && lastTapPoint &&
        Math.abs(point.x-lastTapPoint.x)<50 && Math.abs(point.y-lastTapPoint.y)<50;
      lastTapTime = now; lastTapCard = card; lastTapPoint = point;
      if (doubleTap) {
        if (!post.liked) toggleLike(post, card);
        addHeart(card, point.x, point.y);
      }
    });
    return card;
  }
  function renderFeed() {
    feed.replaceChildren();
    posts.forEach(post => feed.appendChild(makePostCard(post)));
    updateEmpty();
    renderProfilePosts();
    renderSearch($("#search-input").value);
  }
  function toggleLike(post, card) {
    post.liked = !post.liked;
    post.likes = Math.max(0, post.likes + (post.liked ? 1 : -1));
    const btn = $(".like-btn", card);
    if (btn) {
      btn.classList.toggle("liked", post.liked);
      $(".like-count", card).textContent = countText(post.likes);
    }
  }
  async function sharePost(post) {
    const text = `Regarde cette publication sur FasoTok : @${post.username} — ${post.caption || "🇧🇫"}`;
    if (navigator.share) {
      try { await navigator.share({title:"FasoTok", text}); } catch (_) {}
    } else if (navigator.clipboard && navigator.clipboard.writeText) {
      try { await navigator.clipboard.writeText(text); toast("Texte de partage copié"); }
      catch (_) { toast(text); }
    } else toast(text);
  }
  function openComments(post) {
    currentPostForComments = post;
    renderComments();
    commentsModal.classList.remove("hidden");
  }
  function renderComments() {
    const list = $("#comments-list");
    list.replaceChildren();
    if (!currentPostForComments || !currentPostForComments.comments.length) {
      const empty = document.createElement("p");
      empty.className = "muted";
      empty.textContent = "Aucun commentaire pour le moment. Sois le premier !";
      list.appendChild(empty);
      return;
    }
    currentPostForComments.comments.forEach(comment => {
      const row = document.createElement("div");
      row.className = "comment-row";
      row.innerHTML = `<div class="comment-avatar">🇧🇫</div><div class="comment-body"><strong>@${escapeHTML(comment.username)}</strong><p>${escapeHTML(comment.text)}</p></div>`;
      list.appendChild(row);
    });
  }
  $("#comment-form").addEventListener("submit", event => {
    event.preventDefault();
    const text = $("#comment-input").value.trim();
    if (!text || !currentPostForComments) return;
    currentPostForComments.comments.push({username:profile.username, text});
    $("#comment-input").value = "";
    renderComments();
    renderFeed();
    // Keep the comments panel open after feed refresh.
    commentsModal.classList.remove("hidden");
    currentPostForComments = posts.find(p => p.id === currentPostForComments.id) || currentPostForComments;
    renderComments();
  });
  function renderSearch(query="") {
    const container = $("#search-results");
    if (!container) return;
    container.replaceChildren();
    const q = query.trim().toLowerCase();
    const found = posts.filter(p => !q || (`${p.username} ${p.caption}`).toLowerCase().includes(q));
    if (!found.length) {
      const msg = document.createElement("p");
      msg.className = "muted";
      msg.textContent = q ? "Aucun résultat." : "Les publications apparaîtront ici. Ajoute une photo ou une vidéo avec le bouton +.";
      container.appendChild(msg);
      return;
    }
    found.forEach(post => {
      const card = document.createElement("button");
      card.className = "search-card";
      card.type = "button";
      const thumb = document.createElement("div");
      thumb.className = "search-thumb";
      thumb.appendChild(mediaNode(post, ""));
      const caption = document.createElement("p");
      caption.textContent = `@${post.username} · ${post.caption || "Publication FasoTok"}`;
      card.append(thumb, caption);
      card.addEventListener("click", () => {
        showScreen("home-screen");
        const target = $(`[data-post-id="${post.id}"]`, feed);
        if (target) target.scrollIntoView({behavior:"smooth",block:"start"});
      });
      container.appendChild(card);
    });
  }
  function renderProfile() {
    $("#profile-name-display").textContent = "@" + profile.username;
    $("#profile-bio-display").textContent = profile.bio || "Aucune biographie.";
    $("#profile-post-count").textContent = posts.filter(p => p.username === profile.username).length;
    renderProfilePosts();
  }
  function renderProfilePosts() {
    const container = $("#profile-posts");
    if (!container) return;
    container.replaceChildren();
    const mine = posts.filter(p => p.username === profile.username);
    if (!mine.length) {
      const msg = document.createElement("p");
      msg.className = "muted";
      msg.textContent = "Tes publications apparaîtront ici.";
      container.appendChild(msg);
      return;
    }
    mine.forEach(post => {
      const thumb = document.createElement("div");
      thumb.className = "profile-post-thumb";
      thumb.appendChild(mediaNode(post, ""));
      container.appendChild(thumb);
    });
  }
  function setFilter(filter) {
    activeFilter = filter;
    webcam.style.filter = filter === "sepia" ? "sepia(1)" : filter === "grayscale" ? "grayscale(1)" : "none";
    $$(".filter-btn").forEach(btn => btn.classList.toggle("active-filter", btn.dataset.filter === filter));
  }
  function openStudio() {
    uploadModal.classList.remove("hidden");
    publishBtn.disabled = !chosenFile;
  }
  function stopCamera() {
    if (cameraStream) cameraStream.getTracks().forEach(track => track.stop());
    cameraStream = null;
    webcam.srcObject = null;
    cameraPlaceholder.classList.remove("hidden");
    $("#start-camera").disabled = false;
    $("#stop-camera").disabled = true;
    if (recorder && recorder.state === "recording") recorder.stop();
  }
  async function startCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      toast("Caméra indisponible ici. Essaie avec le bouton Choisir une photo ou vidéo.");
      return;
    }
    try {
      cameraStream = await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"},audio:true});
      webcam.srcObject = cameraStream;
      webcam.classList.remove("hidden");
      cameraPlaceholder.classList.add("hidden");
      $("#start-camera").disabled = true;
      $("#stop-camera").disabled = false;
      await webcam.play().catch(()=>{});
      toast("Caméra activée");
    } catch (err) {
      toast("Accès caméra refusé ou indisponible. Choisis un fichier à la place.");
    }
  }
  function setChosenFile(file, url=null) {
    if (!file) return;
    if (chosenUrl && chosenUrl.startsWith("blob:")) URL.revokeObjectURL(chosenUrl);
    chosenFile = file;
    chosenUrl = url || URL.createObjectURL(file);
    publishBtn.disabled = false;
    recordStatus.textContent = "Média prêt à publier";
    toast("Média sélectionné. Ajoute une description puis publie.");
  }
  picker.addEventListener("change", () => {
    const file = picker.files && picker.files[0];
    if (file) setChosenFile(file);
  });
  $("#start-camera").addEventListener("click", startCamera);
  $("#stop-camera").addEventListener("click", stopCamera);
  $$(".filter-btn").forEach(btn => btn.addEventListener("click", () => setFilter(btn.dataset.filter)));
  recordButton.addEventListener("click", () => {
    if (!cameraStream) {
      toast("Active d’abord la caméra, ou choisis une vidéo depuis ton téléphone.");
      return;
    }
    if (typeof MediaRecorder === "undefined") {
      toast("L’enregistrement caméra n’est pas pris en charge par ce navigateur.");
      return;
    }
    if (recorder && recorder.state === "recording") {
      recorder.stop();
      return;
    }
    try {
      recordedChunks = [];
      const options = MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? {mimeType:"video/webm;codecs=vp9"} : {};
      recorder = new MediaRecorder(cameraStream, options);
      recorder.ondataavailable = event => { if (event.data && event.data.size) recordedChunks.push(event.data); };
      recorder.onstop = () => {
        const blob = new Blob(recordedChunks, {type:recorder.mimeType || "video/webm"});
        const file = new File([blob], "fasotok-video.webm", {type:blob.type});
        setChosenFile(file);
        recordButton.classList.remove("recording");
        recordStatus.textContent = "Vidéo enregistrée, prête à publier";
      };
      recorder.start();
      recordButton.classList.add("recording");
      recordStatus.textContent = "Enregistrement en cours… Appuie pour arrêter.";
    } catch (_) {
      toast("Impossible de démarrer l’enregistrement sur cet appareil.");
    }
  });
  publishBtn.addEventListener("click", () => {
    if (!chosenFile || !chosenUrl) return;
    const type = chosenFile.type.startsWith("video/") ? "video" : chosenFile.type.startsWith("image/") ? "image" : "";
    if (!type) { toast("Choisis un fichier image ou vidéo."); return; }
    const post = {
      id: "post-" + Date.now() + "-" + Math.random().toString(36).slice(2,7),
      type, url:chosenUrl, caption:captionInput.value.trim(), username:profile.username,
      likes:0, liked:false, saved:false, comments:[]
    };
    posts.unshift(post);
    // The feed owns the object URL now; do not revoke it until the page is closed.
    chosenFile = null;
    chosenUrl = "";
    picker.value = "";
    captionInput.value = "";
    publishBtn.disabled = true;
    stopCamera();
    uploadModal.classList.add("hidden");
    renderFeed();
    showScreen("home-screen");
    feed.scrollTop = 0;
    toast("Publication ajoutée à Accueil sur cet appareil.");
  });
  $("#open-studio").addEventListener("click", openStudio);
  $("#empty-upload-btn").addEventListener("click", openStudio);
  $("#close-studio").addEventListener("click", () => { uploadModal.classList.add("hidden"); stopCamera(); });
  uploadModal.addEventListener("click", event => { if (event.target === uploadModal) { uploadModal.classList.add("hidden"); stopCamera(); } });
  $("#close-comments").addEventListener("click", () => commentsModal.classList.add("hidden"));
  commentsModal.addEventListener("click", event => { if (event.target === commentsModal) commentsModal.classList.add("hidden"); });
  $$(".nav-item[data-screen]").forEach(btn => btn.addEventListener("click", () => showScreen(btn.dataset.screen)));
  $("#search-input").addEventListener("input", event => renderSearch(event.target.value));
  $("#edit-profile-btn").addEventListener("click", () => {
    $("#profile-username").value = profile.username;
    $("#profile-bio").value = profile.bio;
    $("#profile-form").classList.remove("hidden");
  });
  $("#cancel-profile").addEventListener("click", () => $("#profile-form").classList.add("hidden"));
  $("#profile-form").addEventListener("submit", event => {
    event.preventDefault();
    const username = $("#profile-username").value.trim().replace(/^@+/, "").replace(/\s+/g,"_");
    if (!username) { toast("Choisis un nom d’utilisateur."); return; }
    profile.username = username;
    profile.bio = $("#profile-bio").value.trim();
    localStorage.setItem("fasotok_username", profile.username);
    localStorage.setItem("fasotok_bio", profile.bio);
    $("#profile-form").classList.add("hidden");
    renderProfile();
    toast("Profil enregistré sur cet appareil.");
  });
  $$(".top-tab").forEach(btn => btn.addEventListener("click", () => {
    $$(".top-tab").forEach(tab => tab.classList.toggle("active-tab", tab === btn));
    if (btn.dataset.feed === "following") toast("Le flux Abonnements sera connecté quand le système d’abonnements sera disponible.");
    else toast("Tu regardes le flux Pour toi.");
  }));
  window.addEventListener("beforeunload", stopCamera);

  // Demo post to make the interface visible before the user adds their own media.
  posts.push({
    id:"demo-fasotok", type:"demo", url:"", caption:"Bienvenue sur FasoTok ! Ajoute une photo ou une vidéo avec le bouton +. 🇧🇫 #FasoTok",
    username:"Burkina_Concept", likes:12, liked:false, saved:false, comments:[]
  });
  // Demo cards use a visual placeholder instead of a broken media URL.
  const originalMakePostCard = makePostCard;
  // Wrap renderer for the demo card.
  function renderInitialDemo() {
    feed.replaceChildren();
    const demo = posts[0];
    const card = document.createElement("article");
    card.className = "video-card";
    card.dataset.postId = demo.id;
    const placeholder = document.createElement("div");
    placeholder.className = "video-placeholder";
    placeholder.innerHTML = `<div class="video-sim-text">🇧🇫<br>Bienvenue sur FasoTok<br><small>Ajoute ta première vidéo avec +</small></div>`;
    card.appendChild(placeholder);
    const shade = document.createElement("div"); shade.className = "video-shade"; card.appendChild(shade);
    const footer = document.createElement("div");
    footer.className = "video-footer";
    footer.innerHTML = `<h3>@Burkina_Concept</h3><p>${escapeHTML(demo.caption)}</p><div class="music-ticker">🎵 Son original · FasoTok</div>`;
    card.appendChild(footer);
    const side = document.createElement("div");
    side.className = "interaction-sidebar";
    side.innerHTML = `<div class="icon-group"><div class="circle-profile">🇧🇫</div><div class="plus-badge">+</div></div><div class="icon-group"><button class="action-btn like-btn" aria-label="J’aime">♥</button><span class="count like-count">12</span></div><div class="icon-group"><button class="action-btn comment-btn" aria-label="Commentaires">▢</button><span class="count comment-count">0</span></div><div class="icon-group"><button class="action-btn save-btn" aria-label="Favoris">★</button><span class="count">Favoris</span></div><div class="icon-group"><button class="action-btn share-btn" aria-label="Partager">↗</button><span class="count">Partager</span></div>`;
    card.appendChild(side);
    $(".like-btn",side).addEventListener("click",()=>toggleLike(demo,card));
    $(".comment-btn",side).addEventListener("click",()=>openComments(demo));
    $(".save-btn",side).addEventListener("click",()=>{demo.saved=!demo.saved;$(".save-btn",side).classList.toggle("saved",demo.saved);toast(demo.saved?"Ajouté aux favoris":"Retiré des favoris");});
    $(".share-btn",side).addEventListener("click",()=>sharePost(demo));
    card.addEventListener("pointerup",event=>{
      if(event.target.closest("button")) return;
      const now=Date.now(), point={x:event.clientX,y:event.clientY};
      const dbl=now-lastTapTime<360 && lastTapCard===card && lastTapPoint && Math.abs(point.x-lastTapPoint.x)<50 && Math.abs(point.y-lastTapPoint.y)<50;
      lastTapTime=now;lastTapCard=card;lastTapPoint=point;
      if(dbl){if(!demo.liked)toggleLike(demo,card);addHeart(card,point.x,point.y);}
    });
    feed.appendChild(card);
    updateEmpty();
  }
  renderInitialDemo();
});
