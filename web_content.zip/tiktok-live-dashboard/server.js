import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import { TikTokLiveConnection, WebcastEvent } from 'tiktok-live-connector';

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 8085;

app.use(express.static('public'));
app.get('/health', (_req, res) => res.json({ ok: true, service: 'TikTok LIVE dashboard' }));

let connection = null;
let currentUsername = null;
let connecting = false;

const cleanUsername = (value) => String(value || '')
  .trim()
  .replace(/^https?:\/\/www\.tiktok\.com\/@?/i, '')
  .replace(/^@/, '')
  .replace(/\/.*$/, '')
  .replace(/[^A-Za-z0-9._-]/g, '');

function broadcast(type, payload = {}) {
  io.emit('event', { type, timestamp: Date.now(), ...payload });
}

function userOf(data) {
  const u = data?.user || {};
  return {
    nickname: u.nickname || data?.nickname || data?.uniqueId || 'مستخدم',
    uniqueId: u.uniqueId || data?.uniqueId || '',
    userId: u.userId || data?.userId || '',
    avatar: u.profilePictureUrl || data?.profilePictureUrl || ''
  };
}

function attachEvents(conn) {
  conn.on(WebcastEvent.CHAT, data => {
    const user = userOf(data);
    broadcast('chat', { user, comment: data.comment || '' });
  });

  conn.on(WebcastEvent.GIFT, data => {
    const user = userOf(data);
    broadcast('gift', {
      user,
      giftName: data.giftName || `Gift #${data.giftId ?? ''}`,
      giftId: data.giftId ?? null,
      repeatCount: data.repeatCount || 1,
      diamondCount: data.diamondCount || 0,
      repeatEnd: data.repeatEnd ?? true,
      giftType: data.giftType ?? 0
    });
  });

  conn.on(WebcastEvent.MEMBER, data => broadcast('member', { user: userOf(data) }));
  conn.on(WebcastEvent.FOLLOW, data => broadcast('follow', { user: userOf(data) }));
  conn.on(WebcastEvent.SHARE, data => broadcast('share', { user: userOf(data) }));
  conn.on(WebcastEvent.SOCIAL, data => broadcast('social', { user: userOf(data), raw: data }));

  conn.on(WebcastEvent.LIKE, data => broadcast('like', {
    user: userOf(data),
    likeCount: data.likeCount || 0,
    totalLikeCount: data.totalLikeCount || 0
  }));

  conn.on(WebcastEvent.ROOM_USER, data => broadcast('viewerCount', {
    viewerCount: data.viewerCount || 0
  }));

  conn.on(WebcastEvent.SUBSCRIBE, data => broadcast('subscribe', { user: userOf(data) }));
  conn.on(WebcastEvent.QUESTION_NEW, data => broadcast('question', { user: userOf(data), question: data.questionDetails?.content || data.content || '' }));
  conn.on(WebcastEvent.STREAM_END, () => {
    broadcast('streamEnd', { message: 'انتهى البث أو أصبح غير متاح.' });
    currentUsername = null;
  });

  conn.on('connected', state => broadcast('connected', {
    username: currentUsername,
    roomId: state?.roomId || null
  }));

  conn.on('disconnected', () => broadcast('disconnected', { username: currentUsername }));
  conn.on('error', error => broadcast('error', { message: error?.message || String(error) }));
}

async function disconnectCurrent() {
  if (connection) {
    try { await connection.disconnect(); } catch {}
  }
  connection = null;
  currentUsername = null;
}

io.on('connection', socket => {
  socket.emit('state', { connected: !!connection, username: currentUsername });

  socket.on('connectLive', async rawUsername => {
    const username = cleanUsername(rawUsername);
    if (!username) return socket.emit('errorMessage', 'أدخل اسم مستخدم صحيحاً.');
    if (connecting) return socket.emit('errorMessage', 'هناك محاولة اتصال جارية بالفعل.');

    connecting = true;
    await disconnectCurrent();
    currentUsername = username;
    broadcast('connecting', { username });

    try {
      connection = new TikTokLiveConnection(username);
      attachEvents(connection);
      const state = await connection.connect();
      broadcast('connected', { username, roomId: state?.roomId || null });
    } catch (err) {
      broadcast('connectionFailed', { username, message: err?.message || String(err) });
      await disconnectCurrent();
    } finally {
      connecting = false;
    }
  });

  socket.on('disconnectLive', async () => {
    await disconnectCurrent();
    broadcast('manualDisconnect', {});
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`TikTok LIVE Dashboard: http://localhost:${PORT}`);
  console.log(`Health: http://localhost:${PORT}/health`);
});
