# My Private File Manager - Android Project

Open this folder in Android Studio, let Gradle sync, then use **Build > Build APK(s)**.
The original HTML interface is bundled as an Android WebView asset at `app/src/main/assets/index.html`.

Application ID: `com.example.filemanager`
Version: `1.0` (1)
