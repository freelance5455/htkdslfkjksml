# v1.62.12 — Correção efetiva do tamanho dos escudos

- Corrigida a cascata CSS: `.crest.crest-official` sobrescrevia o ajuste anterior de 36px.
- Real Betis, Celta Vigo e Levante usam 40×40px nos contextos normais e 54×54px nos contextos grandes.
- Na tela de seleção de clube, esses três escudos usam 280×280px.
- Regras aplicadas depois das regras genéricas, com especificidade e prioridade suficientes.
- Cache PWA atualizado para forçar a instalação dos estilos novos.
- Nenhum outro clube teve o tamanho alterado.
