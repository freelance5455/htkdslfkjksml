/* Rift Mate - full Arabic/English switch. Loaded last. English mode: any remaining Arabic UI text is converted to English. */
(function(){
'use strict';
const D=[
['لا تتوفر بيانات موثقة حاليًا','No documented data available'],
['معلومات المطور','Developer info'],['تابع الحساب الرسمي','Follow the official account'],['معلومات التطبيق','App info'],['اسم التطبيق','App name'],['المطوّر','Developer'],['إصدار التطبيق','App version'],['إصدار قاعدة البيانات','Database version'],['تاريخ آخر تحديث','Last update'],['إصدار اللعبة في البيانات','Game patch in data'],
['طبيعة البيانات غير الموثقة:','Undocumented data:'],['أي معلومة لم تظهر في البيانات مكتوب عندها','Any information missing from the data is marked'],['ولا يتم اختراعها. التقييمات المكتوب عليها «تقدير» هي تحليل خوارزمي وليست إحصائيات. إحصائيات الفوز هي Master+ على سيرفر Wild Rift الصيني (CN) كما ينشرها المصدر','and is never invented. Ratings marked "estimate" are algorithmic analysis, not statistics. Win stats are Master+ on the Wild Rift China (CN) server.'],['ولا يتم اختراعها.','and is never invented.'],
['التغطية الحالية:','Current coverage:'],['بدليل كامل','with full guide'],['ناقص جزئيًا','partially incomplete'],['بطل','champions'],['عنصر','items'],['مواجهة','matchups'],['علاقة انسجام','synergy links'],
['معلومات التواصل: كما في بطاقة المطوّر أعلاه (حساب إنستغرام الموجود في المشروع الأصلي). لا تُضاف بيانات تواصل أخرى','Contact info: as on the developer card above (the Instagram account in the original project). No other contact details are added'],
['تصدير ملف البيانات JSON','Export data file (JSON)'],['استيراد ملف البيانات JSON','Import data file (JSON)'],['اختار ملف MAZEN_RIFT_DATA.json من الهاتف. يتم التحقق منه ثم حفظه محليًا داخل مساحة التطبيق','Pick MAZEN_RIFT_DATA.json from your phone. It is validated, then saved locally inside the app'],
['الموسيقى الخلفية','Background music'],['موسيقى هادئة مولّدة داخل التطبيق — لا تحتاج ملفًا خارجيًا','Calm music generated inside the app, no external file needed'],['متوقفة','Stopped'],['تشغيل الموسيقى','Play music'],['إيقاف الموسيقى','Stop music'],['كتم الصوت','Mute'],['مستوى الموسيقى','Music volume'],['خفض الصوت','Volume down'],['رفع الصوت','Volume up'],['المؤثرات الصوتية','Sound effects'],['نقرة قصيرة وناعمة عند الضغط على الأزرار والعناصر','A short soft click when tapping buttons and items'],['تجربة صوت النقر','Test click sound'],['المؤثرات مفعّلة','Effects on'],['تشغيل','On'],
['تحديث البيانات','Refresh data'],['مسح الفلاتر','Clear filters'],['جاهز','Ready'],['محرك الحساب','Scoring engine'],['يشمل Tier','includes Tier'],['مواجهة وانسجام واحتياج فقط','matchup, synergy and team needs only'],
['غابة','Jungle'],['بارون','Baron'],['وسط','Mid'],['ميد','Mid'],['دراجون','Dragon'],['دعم','Support'],['سبورت','Support'],
['مثالي','Ideal'],['قوي','Strong'],['مرتبط','Related'],
['ضرر جسدي','Physical damage'],['ضرر سحري','Magic damage'],['ضرر مختلط','Mixed damage'],['جسدي','Physical'],['سحري','Magic'],['مختلط','Mixed'],
['تحليل التشكيلة','Team composition analysis'],['درجة ثقة التحليل','Analysis confidence'],['اختيارات في فريقك','picks on your team'],['عند الخصم','on the enemy'],['في الخصم','on the enemy'],
['البيانات غير كافية للحكم النهائي، التوصيات استرشادية','Not enough data for a final verdict; recommendations are indicative'],['؛ البنود المكتوب بجانبها «تقدير» تحليل خوارزمي من تصنيف الأبطال وليست إحصائية','; items marked "estimate" are algorithmic analysis from champion classes, not statistics'],
['منخفضة','Low'],['متوسطة','Medium'],['عالية نسبيًا','Relatively high'],
['لا نقاط قوة مؤكدة بعد','No confirmed strengths yet'],['نقاط القوة والضعف','Strengths & weaknesses'],['نقاط الضعف والمشكلات','Weaknesses & issues'],['نقاط القوة','Strengths'],['نقاط الضعف','Weaknesses'],['لا مشكلات ظاهرة في البيانات المتاحة','No visible issues in the available data'],
['موضوع في مسار','is placed in the'],['وليس من مساراته الموثقة','lane, which is not one of its documented lanes'],
['المسارات الناقصة','Missing lanes'],['احتياجات الفريق','Team needs'],
['توازن جيد بين الضرر الجسدي والسحري','Good balance between physical and magic damage'],['كل الضرر تقريبًا جسدي، فيسهل على الخصم بناء دروع','Almost all damage is physical, so the enemy can easily stack armor'],['كل الضرر تقريبًا سحري، فيسهل على الخصم بناء مقاومة سحر','Almost all damage is magic, so the enemy can easily stack magic resist'],
['توازن الضرر','Damage balance'],['الخط الأمامي','Frontline'],['بدء الاشتباك','Engage'],['بدء الاشتباكات','Engage'],['الحماية','Peel'],['التحكم الجماعي','Crowd control'],['قوة البداية/المنتصف/النهاية','Early/Mid/Late strength'],['مواجهات موثقة مع الخصم','Documented matchups vs enemy'],['لصالحك','in your favor'],['ضدك','against you'],['الخصم','Enemy'],['من','of'],
['خط أمامي','frontline'],['يوجد خط أمامي (تانك أو مقاتل','Has a frontline (tank or fighter'],['لا يوجد خط أمامي واضح','No clear frontline'],
['قدرة جيدة على بدء الاشتباكات (تقدير','Good ability to start fights (estimate'],['قدرة ضعيفة على بدء الاشتباك (تقدير','Weak ability to start fights (estimate'],['حماية كافية للكاري (تقدير','Enough protection for the carry (estimate'],['حماية ضعيفة لحامل الضرر (تقدير','Weak protection for the damage dealer (estimate'],['تحكم جماعي جيد (تقدير','Good crowd control (estimate'],['تحكم جماعي قليل (تقدير','Little crowd control (estimate'],
['تشكيلتك أقوى في البداية؛ حاول إنهاء المباراة مبكرًا قبل أن يتفوق الخصم','Your comp is stronger early; try to end the game before the enemy catches up'],['تشكيلتك أقوى في النهاية؛ العب بأمان وركّز على المحافظة على الموارد حتى المرحلة المتأخرة','Your comp is stronger late; play safe and preserve resources until the late game'],
['الخصم بلا خط أمامي واضح: ضغط الضرر والكايتنج مناسب','The enemy has no clear frontline: damage pressure and kiting are a good fit'],['ضرر الخصم جسدي غالبًا، فكّر في عناصر مقاومة الدروع','Enemy damage is mostly physical; consider armor items'],['ضرر الخصم سحري غالبًا، فكّر في عناصر مقاومة السحر','Enemy damage is mostly magic; consider magic resist items'],['أضف أبطال الخصم لتحليل أفضل طريقة لمواجهته','Add enemy champions to analyze the best way to face them'],
['أفضل الاختيارات المقترحة لمسار','Best suggested picks for the'],['قراءة التشكيلة','Comp reading'],['خصائص فريقك','Your team traits'],['خصائص الخصم','Enemy traits'],['غير مكتملة: بعض خصائص الأبطال لم تُلتقط بعد','Incomplete: some champion traits are not captured yet'],['الموجود','Present'],['غير المرصود','Not detected'],['الوضع','Mode'],['الأوزان الأساسية','Base weights'],['المسار','Lane'],
['مطابق للمسار المطلوب','matches the requested lane'],['لا توجد مواجهة منشورة محفوظة مع الخصم في هذا المسار؛ استُبعد هذا العامل','no saved published matchup vs the enemy in this lane; this factor is excluded'],['خصمك المباشر في اللين','your direct lane opponent'],['مواجهة','matchup'],['ملاءمة المسار','Lane fit'],['التصنيف','Rating'],['المواجهة','Matchup'],['الانسجام','Synergy'],['احتياج الفريق','Team needs'],
['ثانية','sec'],['ثوانٍ','sec'],['على النفس','Self'],['تقدير','estimate'],['فوز','win'],
['شحنة جديدة كل','new charge every'],['،',','],['·','·']
];
const FULL={};
// spells English
const SP={Flash:['Teleports your champion a short distance toward your cursor. Flash is disabled while you cannot cast abilities.','Range 400'],Ignite:['Ignites the target enemy champion for 5 seconds: reveals them, applies 60% Grievous Wounds, and deals 72 to 380 true damage (by level).',''],Heal:['Heals you and the most injured nearby ally for 110 to 400 (by level); both gain 30% movement speed briefly.',''],Barrier:['Shields your champion for 120 to 560 (by level) for 2.5 seconds.',''],Exhaust:['Exhausts the target enemy champion for 2.5 seconds: their damage is reduced by 40% and they are slowed by 35%, decaying over the duration.',''],Cleanse:['Removes all disables (except Nearsight and Suppression) and negative summoner spell effects (except Mark) from your champion.',''],Ghost:['A movement speed boost that decays to 25% bonus speed over 8 seconds. Champion kills extend the duration.',''],Smite:['Deals 600 true damage to a target large monster, epic monster or minion and heals you.',''],Teleport:['After a 3-second channel, removes any homestart/homeguard buff and teleports to an allied champion, minion or structure.',''],Clarity:['Restores 50% max mana to your champion and 25% max mana to nearby allies. Available in Howling Abyss.','']};
const nm={};
function names(){const a=(typeof nameAr!=='undefined'?nameAr:{});for(const k in a)nm[a[k]]=k}
const isEn=()=>lang==='en';
const AR=/[\u0600-\u06FF]/;
const DS=D.slice().sort((a,b)=>b[0].length-a[0].length);
function conv(t){
  if(!AR.test(t))return t;
  let s=t;
  for(const [a,e] of DS){if(s.indexOf(a)>=0)s=s.split(a).join(e)}
  if(AR.test(s)){for(const k in nm){if(s.indexOf(k)>=0)s=s.split(k).join(nm[k])}}
  return s;
}
let busy=false;const ORIG=new Map(),ATTR=[];
function walk(root){
  if(!isEn()||busy)return;busy=true;
  try{
    const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n,list=[];
    while(n=w.nextNode()){if(AR.test(n.nodeValue)&&!n.parentElement.closest('script,style'))list.push(n)}
    list.forEach(n=>{const v=conv(n.nodeValue);if(v!==n.nodeValue){ORIG.set(n,n.nodeValue);n.nodeValue=v}});
    root.querySelectorAll&&root.querySelectorAll('[placeholder],[title],[aria-label]').forEach(el=>{['placeholder','title','aria-label'].forEach(a=>{const v=el.getAttribute(a);if(v&&AR.test(v)){ATTR.push([el,a,v]);el.setAttribute(a,conv(v))}})});
  }finally{busy=false}
}
function spellsFix(){
  if(!isEn())return;
  document.querySelectorAll('.spell-card,[data-spell]').forEach(()=>{});
}
function init(){
  names();
  const app=document.getElementById('app')||document.body;
  new MutationObserver(()=>{if(isEn())walk(app)}).observe(app,{childList:true,subtree:true,characterData:true});
  // English spell text: patch data so the renderer shows English when lang=en
  if(window.WRC4_SPELLS)window.WRC4_SPELLS.forEach(s=>{const e=SP[s.en];if(e){s.dEn=e[0]}});
  const _tr=window.translate;
  let last=null;
  const _sd=window.showDetail;
  if(_sd)window.showDetail=function(c){last=c;return _sd.apply(this,arguments)};
  window.translate=function(){
    if(lang!=='en'){ORIG.forEach((v,n)=>{if(n.isConnected)n.nodeValue=v});ORIG.clear();ATTR.forEach(([e,a,v])=>e.setAttribute(a,v));ATTR.length=0}
    const r=_tr.apply(this,arguments);
    try{
      names();
      if(typeof renderLibrary!=='undefined')renderLibrary();
      const det=document.getElementById('champDetail');
      if(last&&det&&!det.classList.contains('hidden')){const tab=document.querySelector('[data-detail-tab].active')?.dataset.detailTab;_sd(last);if(tab){const b=document.querySelector('[data-detail-tab="'+tab+'"]');b&&b.click()}}
      if(document.getElementById('draftResults')?.querySelector('.score-breakdown')&&typeof scoreDraft!=='undefined'){scoreDraft();try{analyzeComp()}catch(e){}}
      if(typeof renderItems!=='undefined')try{renderItems()}catch(e){}
      if((typeof metaData!=='undefined'&&metaData)&&typeof renderMeta!=='undefined')try{renderMeta()}catch(e){}
    }catch(e){console.error(e)}
    if(lang!=='en'){ORIG.forEach((v,n)=>{if(n.isConnected)n.nodeValue=v});ORIG.clear();ATTR.forEach(([e,a,v])=>e.setAttribute(a,v));ATTR.length=0}
    walk(app);return r;
  };
  const sel=document.getElementById('settingLang');if(sel)sel.value=lang;
  walk(app);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(init,0));else setTimeout(init,0);
})();
