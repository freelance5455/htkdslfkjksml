// يسلم المحتوى المدفوع (مجزوءة واحدة أو بنك الأسئلة) بعد التحقق من الجلسة والجهاز
import { res, body, auth } from "./lib/util.mjs";
import { LIB, BANK } from "../data/index.mjs";

export default async (req) => {
  if (req.method !== "POST") return res(405, { error: "POST فقط" });
  const b = await body(req);
  const a = await auth(b.token);
  if (!a) return res(401, { error: "انتهت الجلسة على هذا الجهاز. ادخل من جديد." });
  if (b.what === "bank") return res(200, { bank: BANK });
  if (b.what === "lib") {
    const m = LIB[String(b.id || "")];
    if (!m) return res(404, { error: "مجزوءة غير موجودة." });
    return res(200, { module: m });
  }
  return res(200, { email: a.email, name: a.user.name });
};
