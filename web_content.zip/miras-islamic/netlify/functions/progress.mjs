// حفظ تقدم المشترك ومزامنته بين الأجهزة + لوحة الترتيب + إحصائيات الإحالة
import { res, body, auth, store, refCode } from "./lib/util.mjs";

const weekKey = () => { const d = new Date(); const t = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()); return Math.floor((t / 864e5 + 3) / 7); };
const clean = (s) => String(s || "").replace(/[<>]/g, "").trim().slice(0, 24);

async function board() {
  const s = await store("board");
  return { s, all: (await s.get("all")) || {} };
}
function top(all, me) {
  const wk = weekKey();
  const rows = Object.entries(all).map(([k, v]) => ({ k, n: v.n, xp: v.xp || 0, w: v.wk === wk ? v.w || 0 : 0, st: v.st || 0 }));
  const by = (f) => rows.slice().sort((a, b) => b[f] - a[f]);
  const pack = (arr, f) => ({ top: arr.slice(0, 30).map((r, i) => ({ r: i + 1, n: r.n, v: r[f], me: r.k === me, st: r.st })), me: arr.findIndex((r) => r.k === me) + 1, total: arr.length });
  return { all: pack(by("xp"), "xp"), week: pack(by("w"), "w") };
}

export default async (req) => {
  if (req.method !== "POST") return res(405, { error: "POST فقط" });
  const b = await body(req);
  const a = await auth(b.token);
  if (!a) return res(401, { error: "انتهت الجلسة. ادخل من جديد." });
  const me = refCode(a.email);
  const ps = await store("progress");

  if (b.action === "get") {
    return res(200, { state: (await ps.get(a.email)) || null });
  }

  if (b.action === "save") {
    const st = b.state || {};
    const raw = JSON.stringify(st);
    if (raw.length > 400000) return res(413, { error: "حجم التقدم كبير." });
    st.saved = Date.now();
    await ps.setJSON(a.email, st);
    const { s, all } = await board();
    const wk = weekKey();
    const prev = all[me] || {};
    const nick = clean(st.nick) || clean(a.user.name).split(" ")[0] || "مشترك";
    const xp = Math.max(0, Number(st.xp) || 0);
    let w = prev.wk === wk ? prev.w || 0 : 0;
    if (xp > (prev.xp || 0)) w += xp - (prev.xp || 0);
    all[me] = { n: nick, xp, w, wk, st: Number(st.streak) || 0 };
    await s.setJSON("all", all);
    return res(200, { ok: true, saved: st.saved });
  }

  if (b.action === "board") {
    const { all } = await board();
    return res(200, top(all, me));
  }

  if (b.action === "refs") {
    const orders = await store("orders");
    const { blobs } = await orders.list();
    const mine = (await Promise.all(blobs.map((x) => orders.get(x.key)))).filter((o) => o && o.ref === me);
    return res(200, { code: me, pending: mine.filter((o) => o.status === "pending").length, active: mine.filter((o) => o.status === "active").length });
  }

  return res(400, { error: "إجراء غير معروف." });
};
