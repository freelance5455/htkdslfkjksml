// دخول المشترك بالبريد ورمز الدخول، مع حد أقصى لجهازين
import { res, body, normEmail, sha, safeEq, store, signToken, accessUntil, env, refCode } from "./lib/util.mjs";

export default async (req) => {
  if (req.method !== "POST") return res(405, { error: "POST فقط" });
  const b = await body(req);
  const email = normEmail(b.email), code = String(b.code || "").trim().toUpperCase().replace(/\s/g, "");
  const device = String(b.device || "").slice(0, 64);
  if (!email || !code || device.length < 8) return res(400, { error: "أدخل البريد الإلكتروني ورمز الدخول." });
  const users = await store("users");
  const u = await users.get(email);
  if (!u || u.status !== "active" || !safeEq(u.codeHash, sha(code))) return res(403, { error: "البريد أو الرمز غير صحيح. انسخ الرمز كما وصلك في البريد." });
  const until = accessUntil();
  if (Date.now() > until) return res(403, { error: "انتهت مدة الولوج لهذه الدورة." });
  const max = Number(env("MAX_DEVICES", "2"));
  u.devices = u.devices || [];
  if (!u.devices.includes(device)) {
    if (u.devices.length >= max) return res(403, { error: "استُعمل هذا الحساب على جهازين. راسلنا عبر واتساب إذا غيرت جهازك." });
    u.devices.push(device);
    await users.setJSON(email, u);
  }
  const token = signToken({ e: email, d: device, x: Math.min(until, Date.now() + 30 * 864e5) });
  return res(200, { token, name: u.name, email, ref: refCode(email) });
};
