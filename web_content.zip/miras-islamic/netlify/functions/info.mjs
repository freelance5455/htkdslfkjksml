// معلومات عامة للصفحة (الثمن، واتساب، مدة التفعيل، تاريخ المباراة، مكافأة الإحالة)
import { res, payInfo, env } from "./lib/util.mjs";
export default async () => {
  const p = payInfo();
  return res(200, { price: p.price, oldPrice: env("OLD_PRICE", ""), whatsapp: p.whatsapp, hours: p.hours, examDate: env("EXAM_DATE", "2026-11-29"), refReward: env("REF_REWARD", "20 درهم عن كل صديق يشترك برابطك") });
};
