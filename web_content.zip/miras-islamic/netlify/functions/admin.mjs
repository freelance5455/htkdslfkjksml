// لوحة الإدارة: عرض الطلبات، التفعيل، الرفض، إعادة إرسال الرمز، تصفير الأجهزة
import { res, body, env, safeEq, sha, randCode, store, normEmail } from "./lib/util.mjs";

async function sendMail(to, name, code) {
  const key = env("RESEND_API_KEY"), from = env("MAIL_FROM");
  if (!key || !from) return { sent: false, reason: "لم تُضبط خدمة البريد (RESEND_API_KEY و MAIL_FROM)." };
  const site = env("SITE_URL", "");
  const html = `<div dir="rtl" style="font-family:Arial,sans-serif;font-size:16px;line-height:1.8">
<p>مرحبا ${name}،</p><p>تم تفعيل اشتراكك في <b>MiRas</b> (التربية الإسلامية: مادة التخصص + علوم التربية + الديداكتيك).</p>
<p>رمز الدخول الخاص بك:</p><p style="font-size:26px;font-weight:bold;letter-spacing:3px;direction:ltr">${code}</p>
<p>ادخل من صفحة المشتركين${site ? `: <a href="${site}/app.html">${site}/app.html</a>` : ""} بهذا البريد وهذا الرمز. يعمل الحساب على جهازين.</p>
<p>بالتوفيق في المباراة.</p></div>`;
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: "Bearer " + key, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: [to], subject: "رمز الدخول إلى MiRas", html }),
    });
    if (!r.ok) return { sent: false, reason: "رفضت خدمة البريد الإرسال (" + r.status + ")." };
    return { sent: true };
  } catch (e) { return { sent: false, reason: "تعذر الاتصال بخدمة البريد." }; }
}

export default async (req) => {
  if (req.method !== "POST") return res(405, { error: "POST فقط" });
  const b = await body(req);
  const pass = env("ADMIN_PASSWORD");
  if (!pass || pass.length < 8) return res(500, { error: "اضبط ADMIN_PASSWORD (8 أحرف على الأقل) في إعدادات Netlify." });
  if (!safeEq(sha(b.password || ""), sha(pass))) return res(401, { error: "كلمة السر غير صحيحة." });

  const orders = await store("orders"), users = await store("users");

  if (b.action === "list") {
    const { blobs } = await orders.list();
    const all = (await Promise.all(blobs.map((x) => orders.get(x.key)))).filter(Boolean);
    all.sort((a, c) => c.created - a.created);
    const ub = (await users.list()).blobs;
    return res(200, { orders: all, activeCount: ub.length });
  }

  if (b.action === "activate" || b.action === "resend") {
    const o = await orders.get(String(b.id || ""));
    if (!o) return res(404, { error: "الطلب غير موجود." });
    const code = randCode(8);
    const prev = (await users.get(o.email)) || {};
    await users.setJSON(o.email, { name: o.name, phone: o.phone, orderId: o.id, status: "active", codeHash: sha(code), devices: b.action === "resend" ? prev.devices || [] : [], activated: prev.activated || Date.now() });
    o.status = "active"; o.activated = o.activated || Date.now();
    await orders.setJSON(o.id, o);
    const mail = await sendMail(o.email, o.name, code);
    return res(200, { code, mail, order: o });
  }

  if (b.action === "reject") {
    const o = await orders.get(String(b.id || ""));
    if (!o) return res(404, { error: "الطلب غير موجود." });
    o.status = "rejected"; await orders.setJSON(o.id, o);
    return res(200, { order: o });
  }

  if (b.action === "reset_devices") {
    const email = normEmail(b.email);
    const u = await users.get(email);
    if (!u) return res(404, { error: "لا يوجد مشترك بهذا البريد." });
    u.devices = []; await users.setJSON(email, u);
    return res(200, { ok: true });
  }

  if (b.action === "disable") {
    const email = normEmail(b.email);
    const u = await users.get(email);
    if (!u) return res(404, { error: "لا يوجد مشترك بهذا البريد." });
    u.status = "disabled"; await users.setJSON(email, u);
    return res(200, { ok: true });
  }

  return res(400, { error: "إجراء غير معروف." });
};
