// إنشاء طلب شراء جديد (أداء يدوي)
import { res, body, normEmail, isEmail, store, payInfo, randCode } from "./lib/util.mjs";

export default async (req) => {
  if (req.method !== "POST") return res(405, { error: "POST فقط" });
  const b = await body(req);
  const name = String(b.name || "").trim().slice(0, 80);
  const email = normEmail(b.email);
  const phone = String(b.phone || "").replace(/[^\d+]/g, "").slice(0, 20);
  const method = b.method === "cashplus" ? "cashplus" : "virement";
  if (name.length < 3) return res(400, { error: "اكتب اسمك الكامل." });
  if (!isEmail(email)) return res(400, { error: "البريد الإلكتروني غير صحيح. سيصلك عليه رمز الدخول." });
  if (phone.replace(/\D/g, "").length < 9) return res(400, { error: "اكتب رقم الهاتف (واتساب) كاملا." });

  const users = await store("users");
  if (await users.get(email)) return res(409, { error: "هذا البريد مفعل من قبل. ادخل من صفحة «دخول المشتركين»، أو اطلب إعادة إرسال الرمز عبر واتساب." });

  const orders = await store("orders");
  const index = await store("order_by_email");
  const prev = await index.get(email);
  if (prev) {
    const o = await orders.get(prev.id);
    if (o && o.status === "pending") return res(200, { id: o.id, existing: true, pay: payInfo() });
  }
  const id = "MR-" + randCode(5);
  const ref = /^[A-F0-9]{6}$/.test(String(b.ref || "").toUpperCase()) ? String(b.ref).toUpperCase() : "";
  const o = { id, name, email, phone, method, ref, status: "pending", created: Date.now() };
  await orders.setJSON(id, o);
  await index.setJSON(email, { id });
  return res(200, { id, pay: payInfo() });
};
