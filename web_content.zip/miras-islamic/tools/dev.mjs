process.env.LOCAL_STORE ||= "/tmp/miras-store"; process.env.ADMIN_PASSWORD ||= "adminpass123"; process.env.SESSION_SECRET ||= "dev"; process.env.WHATSAPP ||= "0600000000";
import http from "node:http"; import fs from "node:fs"; import path from "node:path";
const root = path.resolve("public"), types = { ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".png": "image/png", ".webmanifest": "application/manifest+json", ".json": "application/json" };
http.createServer(async (req, res) => {
  const u = new URL(req.url, "http://x");
  if (u.pathname.startsWith("/.netlify/functions/")) {
    const fn = (await import("../netlify/functions/" + u.pathname.split("/").pop() + ".mjs")).default;
    const body = await new Promise((r) => { let d = ""; req.on("data", (c) => (d += c)); req.on("end", () => r(d)); });
    const r = await fn(new Request("http://x" + req.url, { method: req.method, body: req.method === "POST" ? body : undefined }));
    res.writeHead(r.status, { "Content-Type": "application/json" }); return res.end(await r.text());
  }
  let f = path.join(root, u.pathname === "/" ? "index.html" : u.pathname);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { "Content-Type": types[path.extname(f)] || "application/octet-stream" }); fs.createReadStream(f).pipe(res);
}).listen(8899, () => console.log("dev on 8899"));
