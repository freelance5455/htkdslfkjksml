/* مِراس · تطبيق المشتركين (التربية الإسلامية) */
(() => {
"use strict";
const $ = (s, r = document) => r.querySelector(s);
const V = $("#view");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} },
  del(k) { try { localStorage.removeItem(k); } catch (e) {} },
};
// مخزن IndexedDB للمحتوى (يعمل بلا أنترنت)
const IDB = {
  p: null,
  open() {
    if (!this.p) this.p = new Promise((ok) => {
      try {
        const r = indexedDB.open("miras", 1);
        r.onupgradeneeded = () => r.result.createObjectStore("kv");
        r.onsuccess = () => ok(r.result); r.onerror = () => ok(null);
      } catch (e) { ok(null); }
    });
    return this.p;
  },
  async get(k) { const db = await this.open(); if (!db) return null; return new Promise((ok) => { try { const q = db.transaction("kv").objectStore("kv").get(k); q.onsuccess = () => ok(q.result ?? null); q.onerror = () => ok(null); } catch (e) { ok(null); } }); },
  async set(k, v) { const db = await this.open(); if (!db) return; try { db.transaction("kv", "readwrite").objectStore("kv").put(v, k); } catch (e) {} },
};
const ARL = ["أ", "ب", "ج", "د", "هـ"];
const NUM = (n) => Number(n || 0).toLocaleString("ar-MA");
const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0);
function toast(t) { const el = $("#toast"); el.innerHTML = '<div class="toast">' + esc(t) + "</div>"; clearTimeout(toast.h); toast.h = setTimeout(() => (el.innerHTML = ""), 2600); }
const shuffle = (a, rnd = Math.random) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const seeded = (s) => { let h = 2166136261; for (const c of String(s)) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; return ((h >>> 0) % 1e6) / 1e6; }; };

// ---------- الأيام ----------
const dayKey = (d = new Date()) => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
const dayNum = (d = new Date()) => Math.floor((d.getTime() - d.getTimezoneOffset() * 6e4) / 864e5);

// ---------- الجلسة والحالة ----------
let S = LS.get("miras:s", null);
let device = LS.get("miras:device", null);
if (!device) { device = (crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2) + Date.now()); LS.set("miras:device", device); }
const DEF = () => ({ v: 1, t: 0, nick: "", xp: 0, streak: 0, best: 0, lastDay: "", goal: 60, days: {}, read: {}, bm: [], last: null, srs: {}, hist: [], fs: 18, daily: {} });
let ST = Object.assign(DEF(), LS.get("miras:st", {}));
let CAT = null, BANK = null, BYID = {}, INFO = {};
const MODS = {};

async function api(fn, data) {
  const r = await fetch("/.netlify/functions/" + fn, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data || {}) });
  let j = {}; try { j = await r.json(); } catch (e) {}
  if (r.status === 401) { logout(true); throw new Error(j.error || "انتهت الجلسة"); }
  if (!r.ok) throw new Error(j.error || "خطأ في الاتصال (" + r.status + ")");
  return j;
}
let syncT = null;
function save(sync = true) { ST.t = Date.now(); LS.set("miras:st", ST); if (sync && S) { clearTimeout(syncT); syncT = setTimeout(pushState, 4000); } }
async function pushState(keep) {
  if (!S) return;
  try {
    const body = JSON.stringify({ token: S.token, action: "save", state: slim(ST) });
    if (keep && navigator.sendBeacon) { navigator.sendBeacon("/.netlify/functions/progress", new Blob([body], { type: "application/json" })); return; }
    await fetch("/.netlify/functions/progress", { method: "POST", headers: { "Content-Type": "application/json" }, body });
  } catch (e) {}
}
function slim(st) { const o = Object.assign({}, st); o.hist = (o.hist || []).slice(-60); const ks = Object.keys(o.days || {}).sort().slice(-90); o.days = Object.fromEntries(ks.map((k) => [k, o.days[k]])); return o; }
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") { clearTimeout(syncT); pushState(true); } });

// ---------- النقاط والمواظبة والمراجعة الذكية ----------
const INT = [0, 1, 3, 7, 16, 35];
function touchDay() {
  const k = dayKey();
  if (ST.lastDay !== k) {
    const y = dayKey(new Date(Date.now() - 864e5));
    ST.streak = ST.lastDay === y ? ST.streak + 1 : 1;
    ST.best = Math.max(ST.best || 0, ST.streak);
    ST.lastDay = k;
  }
  return (ST.days[k] = ST.days[k] || { x: 0, a: 0, c: 0, r: 0 });
}
function award(x) { const d = touchDay(); d.x += x; ST.xp += x; }
function grade(q, ok) {
  const d = touchDay(); d.a++; if (ok) d.c++;
  const r = ST.srs[q.id] || { b: 0, s: 0, k: 0 };
  r.s++; r.l = ok ? 1 : 0;
  if (ok) { r.k++; r.b = Math.min(5, r.b + 1); r.due = dayNum() + INT[r.b]; } else { r.b = 0; r.due = dayNum(); }
  ST.srs[q.id] = r;
  award(ok ? 10 : 2);
}
const dueList = () => BANK ? BANK.q.filter((q) => { const r = ST.srs[q.id]; return r && r.s && r.due <= dayNum(); }) : [];
const wrongList = () => BANK ? BANK.q.filter((q) => { const r = ST.srs[q.id]; return r && r.l === 0; }) : [];
function mastery(deck) {
  if (!BANK) return 0;
  const qs = BANK.q.filter((q) => q.d === deck);
  let s = 0; for (const q of qs) { const r = ST.srs[q.id]; if (r) s += Math.min(r.b, 3) / 3; }
  return pct(s, qs.length);
}
const totals = () => { let a = 0, c = 0; for (const d of Object.values(ST.days)) { a += d.a || 0; c += d.c || 0; } return { a, c }; };

// ---------- تحميل المحتوى ----------
async function loadCat() {
  if (CAT) return CAT;
  try { const r = await fetch("assets/catalog.json", { cache: "no-cache" }); CAT = await r.json(); LS.set("miras:cat", CAT); }
  catch (e) { CAT = LS.get("miras:cat", null); }
  return CAT;
}
async function loadBank() {
  if (BANK) return BANK;
  const key = "bank:" + CAT.v;
  BANK = await IDB.get(key);
  if (!BANK) { BANK = (await api("content", { token: S.token, what: "bank" })).bank; IDB.set(key, BANK); }
  BYID = Object.fromEntries(BANK.q.map((q) => [q.id, q]));
  return BANK;
}
async function loadMod(id) {
  if (MODS[id]) return MODS[id];
  const key = "lib:" + id + ":" + CAT.v;
  let m = await IDB.get(key);
  if (!m) { m = (await api("content", { token: S.token, what: "lib", id })).module; IDB.set(key, m); }
  return (MODS[id] = m);
}
const modOf = (cid) => CAT.modules.find((m) => m.chapters.some((c) => c.id === cid));
const deckTitle = (d) => (CAT.decks[d] || {}).title || d;
const DECK_ICON = { quran: "📖", hadith: "📜", aqida: "🕋", fiqh: "⚖️", sira: "🌙", didac: "🧩", tarbiya: "🎓" };
const SPEC = ["quran", "hadith", "aqida", "fiqh", "sira"];
const W_SPEC = { quran: 0.3, hadith: 0.15, aqida: 0.2, fiqh: 0.25, sira: 0.1 };

// ---------- الحماية ----------
["copy", "cut", "contextmenu", "dragstart"].forEach((ev) => document.addEventListener(ev, (e) => { if (!e.target.closest("input,textarea")) e.preventDefault(); }));
document.addEventListener("keydown", (e) => { const k = (e.key || "").toLowerCase(); if ((e.ctrlKey || e.metaKey) && ["c", "x", "s", "p", "a", "u"].includes(k) && !e.target.closest("input,textarea")) e.preventDefault(); });
let WM = "";
function watermark() {
  if (WM || !S) return WM;
  const c = document.createElement("canvas"); c.width = 380; c.height = 220;
  const g = c.getContext("2d"); g.translate(190, 110); g.rotate(-0.4);
  g.fillStyle = getComputedStyle(document.body).color; g.font = "15px sans-serif"; g.textAlign = "center";
  g.fillText(S.email, 0, 0); g.fillText("مِراس · " + (S.name || ""), 0, 24);
  return (WM = "url(" + c.toDataURL() + ")");
}

// ---------- الثيم والخط ----------
function applyPrefs() {
  const th = LS.get("miras:theme", "auto");
  if (th === "auto") document.documentElement.removeAttribute("data-theme"); else document.documentElement.setAttribute("data-theme", th);
  document.documentElement.style.setProperty("--fs", (ST.fs || 18) + "px");
  WM = "";
}
$("#bTheme").onclick = () => {
  const dark = document.documentElement.getAttribute("data-theme") === "dark" || (!document.documentElement.getAttribute("data-theme") && matchMedia("(prefers-color-scheme: dark)").matches);
  LS.set("miras:theme", dark ? "light" : "dark"); applyPrefs(); route();
};
$("#bSearch").onclick = () => (location.hash = "#search");

// ---------- الدخول ----------
function viewLogin(err) {
  $("#nav").hidden = true; $("#bSearch").hidden = true;
  V.innerHTML = `<div class="login">
    <div class="hero"><img src="assets/icon-192.png" alt=""><h1 class="h1" style="margin-top:12px">دخول المشتركين</h1><p class="sub">ادخل بالبريد الإلكتروني ورمز الدخول اللي وصلك بعد التفعيل.</p></div>
    <form class="card" id="lf" style="display:flex;flex-direction:column;gap:14px" novalidate>
      <label class="l">البريد الإلكتروني<input class="f" id="le" type="email" autocomplete="email" dir="ltr" required></label>
      <label class="l">رمز الدخول<input class="f" id="lc" autocomplete="one-time-code" placeholder="XXXXXXXX" dir="ltr" required></label>
      <p class="err" id="lerr" ${err ? "" : "hidden"}>${esc(err || "")}</p>
      <button class="btn pri block" id="lb">دخول</button>
      <p class="sub" style="text-align:center">ما مشتركش؟ <a href="index.html#order">اشترك دابا</a></p>
    </form></div>`;
  $("#lf").onsubmit = async (e) => {
    e.preventDefault();
    const b = $("#lb"); b.disabled = true; b.textContent = "جاري الدخول…";
    try {
      const j = await api("login", { email: $("#le").value, code: $("#lc").value, device });
      S = { token: j.token, name: j.name, email: j.email, ref: j.ref }; LS.set("miras:s", S);
      try { const g = await api("progress", { token: S.token, action: "get" }); if (g.state && (g.state.t || 0) > (ST.t || 0)) { ST = Object.assign(DEF(), g.state); LS.set("miras:st", ST); } } catch (x) {}
      if (!ST.nick) ST.nick = (S.name || "").split(" ")[0];
      save(); applyPrefs(); location.hash = "#home"; route();
    } catch (x) { $("#lerr").hidden = false; $("#lerr").textContent = x.message; b.disabled = false; b.textContent = "دخول"; }
  };
}
function logout(expired) {
  pushState(true); S = null; LS.del("miras:s");
  viewLogin(expired ? "انتهت الجلسة على هذا الجهاز. ادخل من جديد." : "");
}

// ---------- الراوتر ----------
const ROUTES = {};
let SES = null;
async function route() {
  if (!S) return viewLogin();
  $("#nav").hidden = false; $("#bSearch").hidden = false; $("#readbar").hidden = true;
  const [r, ...a] = (location.hash.slice(1) || "home").split("/");
  const tab = { home: "home", lib: "lib", mod: "lib", read: "lib", train: "train", deck: "train", review: "train", quiz: SES && SES.tab || "train", exams: "exams", me: "me", stats: "me", board: "me", refer: "me", search: "" }[r] || "home";
  document.querySelectorAll("#nav a").forEach((x) => x.classList.toggle("on", x.dataset.n === tab));
  window.scrollTo(0, 0);
  try {
    await loadCat();
    if (!CAT) throw new Error("تعذر تحميل الفهرس. تحقق من الاتصال.");
    await (ROUTES[r] || ROUTES.home)(...a.map(decodeURIComponent));
  } catch (e) { V.innerHTML = `<div class="empty"><p>${esc(e.message)}</p><button class="btn" onclick="location.reload()">إعادة المحاولة</button></div>`; }
}
window.addEventListener("hashchange", route);
const spin = () => (V.innerHTML = '<div class="spin"></div>');

// ---------- الرئيسية ----------
ROUTES.home = async () => {
  spin(); await loadBank();
  const d = ST.days[dayKey()] || { x: 0 };
  const exam = new Date((INFO.examDate || "2026-11-29") + "T08:00:00");
  const left = Math.max(0, Math.ceil((exam - Date.now()) / 864e5));
  const due = dueList().length, dl = ST.daily[dayKey()];
  const last = ST.last && modOf(ST.last) ? { m: modOf(ST.last), c: modOf(ST.last).chapters.find((c) => c.id === ST.last) } : null;
  const h = new Date().getHours(), greet = h < 12 ? "صباح الخير" : h < 18 ? "مساء الخير" : "مساء النور";
  V.innerHTML = `
  <section class="card hero-c">
    <div class="row" style="position:relative;z-index:1">
      <div style="flex:1;min-width:0"><div style="opacity:.8;font-size:13.5px">${greet}،</div><h1 class="h1" style="color:#fff">${esc(ST.nick || S.name)}</h1>
      <div style="opacity:.85;font-size:13.5px;margin-top:2px">${left ? `باقي <b style="color:#f1cf86">${NUM(left)}</b> يوم على المباراة` : "بالتوفيق في المباراة!"}</div></div>
      <div class="ring" style="--p:${Math.min(100, pct(d.x, ST.goal))}"><div>${Math.min(100, pct(d.x, ST.goal))}%</div></div>
    </div>
    <div class="k">
      <div class="stat"><b>🔥 ${NUM(ST.streak || 0)}</b><span>أيام متتالية</span></div>
      <div class="stat"><b>${NUM(ST.xp)}</b><span>نقطة XP</span></div>
      <div class="stat"><b>${NUM(d.x)}/${NUM(ST.goal)}</b><span>هدف اليوم</span></div>
    </div>
  </section>
  ${last ? `<h2 class="h2">كمّل القراءة</h2><a class="card act" href="#read/${last.c.id}"><span class="ic">${last.m.icon}</span><span style="min-width:0"><b>${esc(last.c.title)}</b><small>${esc(last.m.title)}</small></span><span class="go">‹</span></a>` : ""}
  <h2 class="h2">برنامج اليوم</h2>
  <div class="grid g2">
    <a class="card act" href="#quiz" data-daily><span class="ic o">⚡</span><span><b>تحدي اليوم</b><small>${dl ? `أنجزته: ${NUM(dl.c)}/${NUM(dl.n)} ✓` : "10 أسئلة متنوعة · +100 XP"}</small></span><span class="go">‹</span></a>
    <a class="card act" href="#review"><span class="ic b">🔁</span><span><b>المراجعة الذكية</b><small>${due ? NUM(due) + " سؤال حان وقت مراجعته" : "ما كاين حتى سؤال للمراجعة اليوم"}</small></span><span class="go">‹</span></a>
    <a class="card act" href="#exams"><span class="ic r">⏱️</span><span><b>امتحان تجريبي</b><small>بنفس شروط المباراة وبالتوقيت</small></span><span class="go">‹</span></a>
    <a class="card act" href="#board"><span class="ic p">🏆</span><span><b>ترتيب المتنافسين</b><small>شوف بلاصتك هاد السيمانة</small></span><span class="go">‹</span></a>
  </div>
  <h2 class="h2">المجزوءات <a class="more" href="#lib">الكل</a></h2>
  <div class="grid g3">${CAT.modules.map(modCard).join("")}</div>`;
  V.querySelector("[data-daily]").onclick = (e) => { e.preventDefault(); startDaily(); };
};
function modCard(m) {
  const done = m.chapters.filter((c) => ST.read[c.id]).length;
  return `<a class="card mod" href="#mod/${m.id}"><div class="t"><span class="em">${m.icon}</span><b>${esc(m.title)}</b></div>
  <div class="bar"><i style="width:${pct(done, m.chapters.length)}%"></i></div>
  <div class="meta"><span>${NUM(done)}/${NUM(m.chapters.length)} فصل</span><span>إتقان الأسئلة ${NUM(mastery(m.deck))}%</span></div></a>`;
}

// ---------- المكتبة ----------
ROUTES.lib = async () => {
  spin(); await loadBank();
  const g = (k) => CAT.modules.filter((m) => m.group === k);
  V.innerHTML = `<h1 class="h1">المكتبة</h1><p class="sub">${NUM(CAT.total.chapters)} فصل، و${NUM(Math.round(CAT.total.words / 1000))} ألف كلمة من الملخصات المنهجية، محيّنة بأسئلة الدورات 2020–2025.</p>
  <h2 class="h2">مادة التخصص</h2><div class="grid g3">${g("spec").map(modCard).join("")}</div>
  <h2 class="h2">علوم التربية والديداكتيك</h2><div class="grid g3">${g("tarbiya").map(modCard).join("")}</div>
  ${ST.bm.length ? `<h2 class="h2">🔖 العلامات</h2><div class="card">${ST.bm.map((b) => { const m = modOf(b); const c = m && m.chapters.find((x) => x.id === b); return c ? `<a class="chap" href="#read/${b}"><span class="n">${m.icon}</span><span class="x"><b>${esc(c.title)}</b><small>${esc(m.title)}</small></span></a>` : ""; }).join("")}</div>` : ""}`;
};
ROUTES.mod = async (id) => {
  const m = CAT.modules.find((x) => x.id === id); if (!m) return (location.hash = "#lib");
  await loadBank();
  const done = m.chapters.filter((c) => ST.read[c.id]).length;
  const n = BANK.q.filter((q) => q.d === m.deck).length;
  V.innerHTML = `<a href="#lib" class="sub" style="text-decoration:none">‹ المكتبة</a>
  <div class="row" style="margin:8px 0 4px"><span class="em" style="font-size:34px">${m.icon}</span><h1 class="h1">${esc(m.title)}</h1></div>
  <p class="sub">${NUM(m.chapters.length)} فصل · قرأت ${NUM(done)} · ${NUM(Math.round(m.chapters.reduce((s, c) => s + c.words, 0) / 180))} دقيقة قراءة تقريبا</p>
  <div class="bar gold" style="margin:12px 0"><i style="width:${pct(done, m.chapters.length)}%"></i></div>
  <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:14px">
    <a class="btn pri" href="#read/${(m.chapters.find((c) => !ST.read[c.id]) || m.chapters[0]).id}">${done ? "كمّل القراءة" : "ابدأ القراءة"}</a>
    <a class="btn" href="#deck/${m.deck}">تدرّب: ${NUM(n)} سؤال</a>
  </div>
  <div class="card">${m.chapters.map((c, i) => `<a class="chap ${ST.read[c.id] ? "done" : ""}" href="#read/${c.id}"><span class="n">${ST.read[c.id] ? "✓" : NUM(i)}</span><span class="x"><b>${esc(c.title)}</b><small>${NUM(c.secs.length)} محور · ${NUM(Math.max(1, Math.round(c.words / 180)))} د</small></span>${ST.bm.includes(c.id) ? "🔖" : ""}</a>`).join("")}</div>`;
};
ROUTES.read = async (cid) => {
  const meta = modOf(cid); if (!meta) return (location.hash = "#lib");
  spin();
  const m = await loadMod(meta.id);
  const i = m.chapters.findIndex((c) => c.id === cid), c = m.chapters[i];
  const prev = m.chapters[i - 1], next = m.chapters[i + 1];
  ST.last = cid; save(false);
  V.innerHTML = `<a href="#mod/${m.id}" class="sub" style="text-decoration:none">‹ ${esc(m.title)}</a>
  <div class="rtools" style="margin-top:10px">
    <button class="btn sm" id="rToc">☰ المحاور</button>
    <button class="btn sm" id="rBm">${ST.bm.includes(cid) ? "🔖 معلَّم" : "🔖 علامة"}</button>
    <span style="flex:1"></span>
    <button class="btn sm" id="rM" aria-label="تصغير الخط">أ−</button><button class="btn sm" id="rP" aria-label="تكبير الخط">أ+</button>
  </div>
  <article class="doc"><div class="wm" style="background-image:${watermark()}"></div>${c.html}</article>
  <div class="card" style="margin-top:14px;text-align:center">
    ${ST.read[cid] ? `<p class="sub" style="margin:0 0 10px">✓ قرأت هذا الفصل</p>` : `<button class="btn gold block" id="rDone">أنهيت هذا الفصل ✓ (+15 XP)</button>`}
    <div class="pager">${next ? `<a class="btn pri" href="#read/${next.id}">الفصل التالي ‹</a>` : ""}${prev ? `<a class="btn" href="#read/${prev.id}">› السابق</a>` : ""}</div>
    <a class="btn ghost block" href="#deck/${m.deck}" style="margin-top:8px">تدرّب على أسئلة ${esc(deckTitle(m.deck))}</a>
  </div>`;
  V.querySelectorAll(".doc table").forEach((t) => { if (!t.parentElement.classList.contains("tw")) { const w = document.createElement("div"); w.className = "tw"; t.replaceWith(w); w.appendChild(t); } });
  $("#rToc").onclick = () => sheet("محاور الفصل", `<div class="toc2">${c.secs.map((s, k) => `<a href="javascript:void 0" data-k="${k + 1}">${esc(s)}</a>`).join("") || '<p class="sub">ما كاينش محاور فرعية.</p>'}</div>`, (el) => el.querySelectorAll("[data-k]").forEach((a) => (a.onclick = () => { closeSheet(); const h = document.getElementById(cid + "-h" + a.dataset.k); if (h) h.scrollIntoView({ behavior: "smooth" }); })));
  $("#rBm").onclick = () => { const k = ST.bm.indexOf(cid); if (k >= 0) ST.bm.splice(k, 1); else ST.bm.unshift(cid); save(); $("#rBm").textContent = ST.bm.includes(cid) ? "🔖 معلَّم" : "🔖 علامة"; toast(ST.bm.includes(cid) ? "تزادت العلامة" : "تحيدات العلامة"); };
  const fs = (d) => { ST.fs = Math.min(26, Math.max(14, (ST.fs || 18) + d)); applyPrefs(); save(false); };
  $("#rM").onclick = () => fs(-1); $("#rP").onclick = () => fs(1);
  const rd = $("#rDone"); if (rd) rd.onclick = () => { ST.read[cid] = Date.now(); touchDay().r++; award(15); save(); toast("مبروك! +15 XP"); route(); };
  const rb = $("#readbar"); rb.hidden = false;
  const onScroll = () => { if (!location.hash.startsWith("#read/")) { rb.hidden = true; return window.removeEventListener("scroll", onScroll); } const h = document.documentElement; rb.firstChild.style.width = Math.min(100, (h.scrollTop / Math.max(1, h.scrollHeight - h.clientHeight)) * 100) + "%"; };
  window.addEventListener("scroll", onScroll, { passive: true }); onScroll();
};

// ---------- الورقة المنبثقة ----------
function sheet(title, html, after) {
  closeSheet();
  const d = document.createElement("div"); d.className = "sheetbg"; d.id = "sheet";
  d.innerHTML = `<div class="sheet" role="dialog" aria-label="${esc(title)}"><div class="hd"><b>${esc(title)}</b><button class="ib" data-x aria-label="إغلاق">✕</button></div>${html}</div>`;
  d.onclick = (e) => { if (e.target === d || e.target.closest("[data-x]")) closeSheet(); };
  document.body.appendChild(d); if (after) after(d);
}
const closeSheet = () => { const s = $("#sheet"); if (s) s.remove(); };

// ---------- التدريب ----------
ROUTES.train = async () => {
  spin(); await loadBank();
  const due = dueList().length, wr = wrongList().length, dl = ST.daily[dayKey()];
  V.innerHTML = `<h1 class="h1">التدريب</h1><p class="sub">${NUM(BANK.q.length)} سؤال من الدورات 2020–2025 والأسئلة المتوقعة، بالجواب المباشر والتوضيح.</p>
  <div class="grid g2" style="margin-top:16px">
    <a class="card act" href="#quiz" data-daily><span class="ic o">⚡</span><span><b>تحدي اليوم</b><small>${dl ? `أنجزته: ${NUM(dl.c)}/${NUM(dl.n)} ✓` : "10 أسئلة · +100 XP"}</small></span><span class="go">‹</span></a>
    <a class="card act" href="#review"><span class="ic b">🔁</span><span><b>المراجعة الذكية</b><small>${NUM(due)} سؤال اليوم (التكرار المتباعد)</small></span><span class="go">‹</span></a>
    <a class="card act" href="#quiz" data-wrong><span class="ic r">❌</span><span><b>أخطائي</b><small>${NUM(wr)} سؤال غلطت فيه آخر مرة</small></span><span class="go">‹</span></a>
  </div>
  <h2 class="h2">بنوك الأسئلة</h2>
  <div class="grid g2">${Object.entries(CAT.decks).map(([k, d]) => `<a class="card mod" href="#deck/${k}"><div class="t"><span class="em">${DECK_ICON[k]}</span><span><b>${esc(d.title)}</b><br><small class="muted">${NUM(d.count)} سؤال</small></span></div><div class="bar"><i style="width:${mastery(k)}%"></i></div><div class="meta"><span>الإتقان</span><span class="num">${NUM(mastery(k))}%</span></div></a>`).join("")}</div>`;
  V.querySelector("[data-daily]").onclick = (e) => { e.preventDefault(); startDaily(); };
  V.querySelector("[data-wrong]").onclick = (e) => { e.preventDefault(); const w = wrongList(); if (!w.length) return toast("ما عندك حتى خطأ دابا 👏"); startSession({ title: "أخطائي", qs: shuffle(w).slice(0, 30), mode: "practice", back: "#train" }); };
};
ROUTES.deck = async (k) => {
  const d = CAT.decks[k]; if (!d) return (location.hash = "#train");
  await loadBank();
  const all = BANK.q.filter((q) => q.d === k);
  const F = { src: "all", t: "", mode: "practice", n: 20, fresh: false };
  const years = d.years.filter((y) => /^\d{4}$/.test(y));
  const draw = () => {
    const pool = filter();
    V.innerHTML = `<a href="#train" class="sub" style="text-decoration:none">‹ التدريب</a>
    <div class="row" style="margin:8px 0 4px"><span style="font-size:32px">${DECK_ICON[k]}</span><div><h1 class="h1">${esc(d.title)}</h1><p class="sub">${NUM(all.length)} سؤال · الإتقان ${NUM(mastery(k))}%</p></div></div>
    <h2 class="h2">المصدر</h2><div class="chips" id="cSrc">${[["all", "الكل"], ["past", "الدورات السابقة"], ["pred", "المتوقعة"], ...years.map((y) => [y, "دورة " + y])].map(([v, l]) => `<button class="chip ${F.src === v ? "on" : ""}" data-v="${v}">${l}</button>`).join("")}</div>
    ${Object.keys(d.topics).length ? `<h2 class="h2">المحور</h2><select class="f" id="cT"><option value="">جميع المحاور</option>${Object.entries(d.topics).filter(([t]) => all.some((q) => q.t === t)).map(([t, l]) => `<option value="${t}" ${F.t === t ? "selected" : ""}>${esc(l)} (${NUM(all.filter((q) => q.t === t).length)})</option>`).join("")}</select>` : ""}
    <h2 class="h2">طريقة التدريب</h2>
    <div class="grid g2" id="cMode">
      <button class="card act" data-v="practice" style="text-align:right;${F.mode === "practice" ? "border-color:var(--pri);background:var(--pri-soft)" : ""}"><span class="ic">✅</span><span><b>اختيار من متعدد</b><small>كتعرف الجواب والتوضيح مباشرة</small></span></button>
      <button class="card act" data-v="flash" style="text-align:right;${F.mode === "flash" ? "border-color:var(--pri);background:var(--pri-soft)" : ""}"><span class="ic o">🃏</span><span><b>بطاقات الحفظ</b><small>السؤال ← الجواب المباشر، وقيّم راسك</small></span></button>
    </div>
    <h2 class="h2">عدد الأسئلة</h2><div class="chips" id="cN">${[10, 20, 40, 0].map((n) => `<button class="chip ${F.n === n ? "on" : ""}" data-v="${n}">${n ? NUM(n) : "الكل"}</button>`).join("")}</div>
    <label class="set" style="cursor:pointer"><span>غير الأسئلة اللي ما جاوبتش عليها</span><input type="checkbox" id="cF" ${F.fresh ? "checked" : ""} style="width:22px;height:22px;accent-color:var(--pri)"></label>
    <button class="btn pri block" id="go" style="margin-top:8px" ${pool.length ? "" : "disabled"}>ابدأ (${NUM(F.n ? Math.min(F.n, pool.length) : pool.length)} سؤال)</button>`;
    V.querySelectorAll("#cSrc [data-v]").forEach((b) => (b.onclick = () => { F.src = b.dataset.v; draw(); }));
    V.querySelectorAll("#cN [data-v]").forEach((b) => (b.onclick = () => { F.n = +b.dataset.v; draw(); }));
    V.querySelectorAll("#cMode [data-v]").forEach((b) => (b.onclick = () => { F.mode = b.dataset.v; draw(); }));
    const ct = $("#cT"); if (ct) ct.onchange = () => { F.t = ct.value; draw(); };
    $("#cF").onchange = (e) => { F.fresh = e.target.checked; draw(); };
    $("#go").onclick = () => { let qs = shuffle(pool); if (F.n) qs = qs.slice(0, F.n); startSession({ title: d.title, qs, mode: F.mode, back: "#deck/" + k }); };
  };
  const filter = () => all.filter((q) => (F.src === "all" || (F.src === "past" ? /^\d{4}$/.test(q.y) || q.official : F.src === "pred" ? q.y === "متوقع" : q.y === F.src)) && (!F.t || q.t === F.t) && (!F.fresh || !ST.srs[q.id]));
  draw();
};
ROUTES.review = async () => {
  await loadBank();
  const due = dueList();
  if (!due.length) {
    V.innerHTML = `<div class="empty"><div style="font-size:52px">🌿</div><h2 class="h2" style="justify-content:center">ما كاين حتى سؤال للمراجعة اليوم</h2><p>كل سؤال كتجاوب عليه كيرجع ليك ف الوقت المناسب: الغلط كيرجع غدا، والصحيح بعد 3 أيام ثم 7 ثم 16…</p><a class="btn pri" href="#train">تدرّب على أسئلة جديدة</a></div>`;
    return;
  }
  due.sort((a, b) => (ST.srs[a.id].b - ST.srs[b.id].b));
  startSession({ title: "المراجعة الذكية", qs: due.slice(0, 30), mode: "flash", back: "#train" });
};
function startDaily() {
  if (!BANK) return;
  const k = dayKey();
  if (ST.daily[k]) return toast("سبق ليك درتي تحدي اليوم ✓ رجع غدا!");
  const rnd = seeded(k + S.email);
  const decks = Object.keys(CAT.decks);
  const qs = [];
  const used = new Set();
  for (let i = 0; i < 10; i++) {
    const d = decks[i % decks.length];
    const pool = BANK.q.filter((q) => q.d === d && !used.has(q.id));
    const fresh = pool.filter((q) => !ST.srs[q.id] || ST.srs[q.id].b < 3);
    const src = fresh.length ? fresh : pool;
    const q = src[Math.floor(rnd() * src.length)];
    if (q) { used.add(q.id); qs.push(q); }
  }
  startSession({ title: "⚡ تحدي اليوم", qs: shuffle(qs, rnd), mode: "practice", back: "#home", daily: k });
}

// ---------- محرك الأسئلة ----------
function startSession(o) {
  SES = Object.assign({ i: 0, ans: {}, fl: {}, shown: {}, t0: Date.now(), done: false, tab: o.exam ? "exams" : "train" }, o);
  SES.ord = SES.qs.map((q) => shuffleOpts(q));
  if (location.hash === "#quiz") route(); else location.hash = "#quiz";
}
function shuffleOpts(q) {
  const o = q.o || [q.a]; const idx = o.map((_, i) => i);
  if (q.gen) return shuffle(idx, seeded(q.id + (SES ? SES.t0 : "")));
  return idx;
}
let TICK = null;
ROUTES.quiz = async () => {
  clearInterval(TICK);
  if (!SES) return (location.hash = "#train");
  if (SES.done) return results();
  const s = SES, q = s.qs[s.i], n = s.qs.length, ord = s.ord[s.i];
  const exam = s.mode === "exam";
  const answered = s.ans[s.i] != null || s.fl[s.i] != null;
  const meta = `<div class="qmeta"><span class="pill g">${esc(deckTitle(q.d))}</span>${q.src ? `<span class="pill">${esc(q.src)}</span>` : q.y === "متوقع" ? '<span class="pill o">سؤال متوقع</span>' : ""}${q.t && CAT.decks[q.d].topics[q.t] ? `<span class="pill">${esc(CAT.decks[q.d].topics[q.t].slice(0, 42))}</span>` : ""}</div>`;
  let body;
  if (s.mode === "flash") {
    const sh = s.shown[s.i];
    body = `<div class="qcard flash">${meta}<p class="qtext">${esc(q.q)}</p>
      ${sh ? `<div class="ans">${esc(q.a)}</div>${q.e ? `<div class="expl"><b>توضيح: </b>${esc(q.e)}</div>` : ""}` : ""}</div>
      <div class="qnav">${!sh ? `<button class="btn pri" id="fShow">أظهر الجواب</button>` : s.fl[s.i] == null ? `<button class="btn" id="fNo" style="border-color:var(--bad);color:var(--bad)">✗ ما عرفتهاش</button><button class="btn pri" id="fOk">✓ عرفتها</button>` : `<button class="btn pri" id="next">${s.i < n - 1 ? "التالي ‹" : "النتيجة"}</button>`}</div>`;
  } else {
    const sel = s.ans[s.i], showFb = !exam && sel != null;
    body = `<div class="qcard">${meta}<p class="qtext">${esc(q.q)}</p><div class="opts">${ord.map((oi, k) => {
      let cl = "";
      if (showFb) cl = oi === q.ai ? "ok" : oi === sel ? "no" : "";
      else if (sel === oi) cl = "sel";
      return `<button class="opt ${cl}" data-o="${oi}" ${showFb ? "disabled" : ""}><span class="L">${ARL[k]}</span><span>${esc(q.o[oi])}</span></button>`;
    }).join("")}</div>
    ${showFb ? `<div class="expl">${sel === q.ai ? "<b>✓ صحيح!</b> " : `<b>✗ الجواب الصحيح:</b> ${esc(q.o[q.ai])}. `}${q.e ? esc(q.e) : ""}</div>` : ""}</div>
    <div class="qnav">${exam ? `${s.i > 0 ? '<button class="btn" id="prev">› السابق</button>' : ""}${s.i < n - 1 ? '<button class="btn pri" id="next">التالي ‹</button>' : '<button class="btn gold" id="fin">إنهاء الامتحان</button>'}` : showFb ? `<button class="btn pri" id="next">${s.i < n - 1 ? "التالي ‹" : "النتيجة"}</button>` : ""}</div>
    ${exam ? `<div class="dots">${s.qs.map((_, k) => `<button data-j="${k}" class="${s.ans[k] != null ? "a" : ""} ${k === s.i ? "cur" : ""}">${NUM(k + 1)}</button>`).join("")}</div><button class="btn ghost block" id="fin2" style="margin-top:12px">إنهاء الامتحان وتصحيحه</button>` : ""}`;
  }
  V.innerHTML = `<div class="qtop"><button class="ib" id="qx" aria-label="خروج">✕</button><div class="bar"><i style="width:${pct(s.i + (answered ? 1 : 0), n)}%"></i></div><span class="num muted" style="font-size:13px">${NUM(s.i + 1)}/${NUM(n)}</span>${s.limit ? '<span class="timer" id="tm"></span>' : ""}</div>
  ${body}`;
  $("#qx").onclick = () => sheet("بغيتي تخرج؟", `<p class="sub">${exam ? "الامتحان غادي يتصحح بالأجوبة اللي عطيتي حتى لدابا." : "التقدم ديالك ف هاد الأسئلة محفوظ."}</p><div class="qnav"><button class="btn" data-x>كمّل</button><button class="btn pri" id="qxx">${exam ? "صحّح وخرج" : "خروج"}</button></div>`, (el) => (el.querySelector("#qxx").onclick = () => { closeSheet(); if (exam || s.daily) finish(); else { SES = null; location.hash = s.back; } }));
  V.querySelectorAll(".opt[data-o]").forEach((b) => (b.onclick = () => {
    const oi = +b.dataset.o;
    if (exam) { s.ans[s.i] = oi; route(); return; }
    if (s.ans[s.i] != null) return;
    s.ans[s.i] = oi; grade(q, oi === q.ai); save(); route();
  }));
  const go = (d) => { s.i = Math.max(0, Math.min(n - 1, s.i + d)); route(); };
  const nx = $("#next"); if (nx) nx.onclick = () => (s.i < n - 1 ? go(1) : finish());
  const pv = $("#prev"); if (pv) pv.onclick = () => go(-1);
  V.querySelectorAll("[data-j]").forEach((b) => (b.onclick = () => { s.i = +b.dataset.j; route(); }));
  const askFin = () => { const left = n - Object.keys(s.ans).length; sheet("إنهاء الامتحان", `<p class="sub">${left ? `باقي ${NUM(left)} سؤال بلا جواب.` : "جاوبتي على جميع الأسئلة."} بغيتي تصحح دابا؟</p><div class="qnav"><button class="btn" data-x>رجوع</button><button class="btn gold" id="ok">صحّح</button></div>`, (el) => (el.querySelector("#ok").onclick = () => { closeSheet(); finish(); })); };
  [$("#fin"), $("#fin2")].forEach((b) => b && (b.onclick = askFin));
  const fs = $("#fShow"); if (fs) fs.onclick = () => { s.shown[s.i] = 1; route(); };
  const fo = $("#fOk"), fn = $("#fNo");
  if (fo) fo.onclick = () => { s.fl[s.i] = 1; grade(q, true); save(); s.i < n - 1 ? go(1) : finish(); };
  if (fn) fn.onclick = () => { s.fl[s.i] = 0; grade(q, false); save(); s.i < n - 1 ? go(1) : finish(); };
  if (s.limit) {
    const tm = $("#tm");
    const tick = () => { const left = Math.max(0, s.limit - Math.floor((Date.now() - s.t0) / 1000)); tm.textContent = String(Math.floor(left / 60)).padStart(2, "0") + ":" + String(left % 60).padStart(2, "0"); tm.classList.toggle("low", left < 300); if (!left) { clearInterval(TICK); toast("سالا الوقت!"); finish(); } };
    tick(); TICK = setInterval(tick, 1000);
  }
};
function finish() {
  clearInterval(TICK);
  const s = SES; if (!s || s.done) return;
  s.done = true; s.dur = Math.round((Date.now() - s.t0) / 1000);
  let c = 0, w = 0, b = 0;
  s.qs.forEach((q, i) => {
    if (s.mode === "flash") { if (s.fl[i] === 1) c++; else if (s.fl[i] === 0) w++; else b++; return; }
    const a = s.ans[i];
    if (a == null) b++; else if (a === q.ai) c++; else w++;
    if (s.mode === "exam" && a != null) grade(q, a === q.ai);
  });
  s.score = { c, w, b, n: s.qs.length };
  if (s.mode === "exam") { award(50); ST.hist.push({ id: s.examId || "mock", t: s.title, c, w, b, n: s.qs.length, d: Date.now(), dur: s.dur }); }
  if (s.daily) { ST.daily[s.daily] = { c, n: s.qs.length }; award(100); }
  save(); route();
}
function results() {
  const s = SES, { c, w, b, n } = s.score;
  const p = pct(c, n), m20 = ((c / n) * 20).toFixed(2), neg = Math.max(0, ((c - 0.25 * w) / n) * 20).toFixed(2);
  const msg = p >= 80 ? "ممتاز! ماشي ف الطريق الصحيح 🌟" : p >= 60 ? "مزيان، كمّل بنفس الوتيرة 💪" : p >= 40 ? "لا باس، راجع الأخطاء وعاود 📚" : "ما تقلقش، المراجعة الذكية غادي تعاونك 🔁";
  let filt = "all";
  const draw = () => {
    V.innerHTML = `<div class="card res"><div class="sub">${esc(s.title)}</div><div class="big num">${NUM(p)}%</div><p style="margin:6px 0 0;font-weight:600">${msg}</p>
    <div class="mark"><div><b style="color:var(--ok)">${NUM(c)}</b><span>صحيح</span></div><div><b style="color:var(--bad)">${NUM(w)}</b><span>خطأ</span></div><div><b>${NUM(b)}</b><span>${s.mode === "flash" ? "بلا تقييم" : "بلا جواب"}</span></div>${s.mode !== "flash" ? `<div><b>${m20}</b><span>النقطة /20</span></div>` : ""}${s.mode === "exam" ? `<div><b>${neg}</b><span>بالتنقيط السالب</span></div>` : ""}</div>
    <p class="sub">${s.dur ? "المدة: " + NUM(Math.floor(s.dur / 60)) + " د " + NUM(s.dur % 60) + " ث · " : ""}${s.mode === "exam" ? "+50 XP لإنهاء الامتحان" : s.daily ? "+100 XP لتحدي اليوم" : ""}</p>
    <div class="qnav"><a class="btn" href="${s.back}">رجوع</a><button class="btn pri" id="again">${s.mode === "exam" ? "عاود الامتحان" : "عاود نفس الأسئلة"}</button></div></div>
    <h2 class="h2">مراجعة الأجوبة <span class="more"><span class="seg"><button data-f="all" class="${filt === "all" ? "on" : ""}">الكل</button><button data-f="no" class="${filt === "no" ? "on" : ""}">الأخطاء</button></span></span></h2>
    <div class="card">${s.qs.map((q, i) => {
      const a = s.mode === "flash" ? (s.fl[i] === 1 ? q.ai : s.fl[i] === 0 ? -1 : null) : s.ans[i];
      const ok = a === q.ai;
      if (filt === "no" && ok) return "";
      return `<div class="rev"><p>${NUM(i + 1)}. ${esc(q.q)}</p>${a != null && !ok && a >= 0 ? `<div class="a no">✗ جوابك: ${esc(q.o[a])}</div>` : a == null ? '<div class="a muted">— بلا جواب</div>' : ""}<div class="a ok">✓ ${esc(q.a)}</div>${q.e ? `<div class="a muted">${esc(q.e)}</div>` : ""}</div>`;
    }).join("") || '<p class="empty">ما كاين حتى خطأ 👏</p>'}</div>`;
    V.querySelectorAll("[data-f]").forEach((x) => (x.onclick = () => { filt = x.dataset.f; draw(); }));
    $("#again").onclick = () => startSession(Object.assign({}, s, { qs: s.mode === "exam" ? s.qs : shuffle(s.qs), daily: null, done: false, ans: {}, fl: {}, shown: {}, i: 0, t0: Date.now() }));
  };
  draw();
}

// ---------- الامتحانات ----------
ROUTES.exams = async () => {
  spin(); await loadBank();
  const G = { spec: "مادة التخصص", tarbiya: "علوم التربية", didac: "الديداكتيك" };
  const best = (id) => { const h = ST.hist.filter((x) => x.id === id); return h.length ? Math.max(...h.map((x) => pct(x.c, x.n))) : null; };
  const M = { g: "spec", n: 40 };
  const draw = () => {
    V.innerHTML = `<h1 class="h1">الامتحانات</h1><p class="sub">امتحان تجريبي ذكي بالتوقيت، والدورات الرسمية السابقة بالتصحيح.</p>
    <section class="card" style="margin-top:16px">
      <div class="row"><span style="font-size:28px">⏱️</span><div><b style="font-size:16.5px">امتحان تجريبي ذكي</b><div class="sub">أسئلة مختارة حسب أوزان المجالات، وكتعطي الأولوية للي ما زال ما تقنتيهش.</div></div></div>
      <h2 class="h2" style="margin-top:14px">المادة</h2><div class="chips" id="mG">${Object.entries(G).map(([k, l]) => `<button class="chip ${M.g === k ? "on" : ""}" data-v="${k}">${l}</button>`).join("")}</div>
      <h2 class="h2">عدد الأسئلة</h2><div class="chips" id="mN">${[20, 40, 60, 80].map((n) => `<button class="chip ${M.n === n ? "on" : ""}" data-v="${n}">${NUM(n)} سؤال · ${NUM(n * (M.g === "spec" ? 3 : 2))} د</button>`).join("")}</div>
      <button class="btn pri block" id="mGo" style="margin-top:14px">ابدأ الامتحان</button>
    </section>
    ${Object.entries(G).map(([g, l]) => `<h2 class="h2">الدورات الرسمية · ${l}</h2><div class="grid g2">${CAT.exams.filter((e) => e.group === g).map((e) => { const bs = best(e.id); return `<div class="card"><div class="row"><b style="flex:1">${esc(e.title.split(" · ")[1] || e.title)}</b>${bs != null ? `<span class="pill ${bs >= 60 ? "g" : "o"}">أحسن نتيجة ${NUM(bs)}%</span>` : `<span class="pill">${NUM(e.n)} سؤال</span>`}</div><p class="sub" style="margin:6px 0 10px">${e.real ? "بالاختيارات الأصلية والتصحيح الرسمي." : "الأجوبة حسب التصحيح، والاختيارات الأخرى للتدريب."}</p><div class="row"><button class="btn pri sm" data-ex="${e.id}">⏱️ امتحان</button><button class="btn sm" data-pr="${e.id}">تدرّب سؤال بسؤال</button></div></div>`; }).join("")}</div>`).join("")}
    ${ST.hist.length ? `<h2 class="h2">آخر النتائج <a class="more" href="#stats">الإحصائيات</a></h2><div class="card">${ST.hist.slice(-6).reverse().map((h) => `<div class="set"><span>${esc(h.t)}<br><small class="muted">${new Date(h.d).toLocaleDateString("ar-MA")}</small></span><b class="num" style="color:${pct(h.c, h.n) >= 60 ? "var(--ok)" : "var(--bad)"}">${NUM(((h.c / h.n) * 20).toFixed(2))}/20</b></div>`).join("")}</div>` : ""}`;
    V.querySelectorAll("#mG [data-v]").forEach((b) => (b.onclick = () => { M.g = b.dataset.v; draw(); }));
    V.querySelectorAll("#mN [data-v]").forEach((b) => (b.onclick = () => { M.n = +b.dataset.v; draw(); }));
    $("#mGo").onclick = () => startSession({ title: "امتحان تجريبي · " + G[M.g], qs: buildMock(M.g, M.n), mode: "exam", exam: true, limit: M.n * (M.g === "spec" ? 180 : 120), back: "#exams", examId: "mock-" + M.g });
    V.querySelectorAll("[data-ex],[data-pr]").forEach((b) => (b.onclick = () => {
      const id = b.dataset.ex || b.dataset.pr, e = BANK.exams.find((x) => x.id === id), meta = CAT.exams.find((x) => x.id === id);
      const qs = e.qs.map((k) => BYID[k]).filter(Boolean);
      if (b.dataset.ex) startSession({ title: meta.title, qs, mode: "exam", exam: true, limit: qs.length * (meta.group === "spec" ? 180 : 120), back: "#exams", examId: id });
      else startSession({ title: meta.title, qs, mode: "practice", back: "#exams", tab: "exams" });
    }));
  };
  draw();
};
function buildMock(g, n) {
  const rnd = Math.random;
  const w = g === "spec" ? W_SPEC : { [g]: 1 };
  const out = [];
  for (const [d, f] of Object.entries(w)) {
    const k = Math.round(n * f);
    const pool = shuffle(BANK.q.filter((q) => q.d === d), rnd);
    pool.sort((a, b) => ((ST.srs[a.id] || { b: -1 }).b - (ST.srs[b.id] || { b: -1 }).b));
    out.push(...pool.slice(0, Math.max(k * 2, k)).sort(() => rnd() - 0.5).slice(0, k));
  }
  return shuffle(out).slice(0, n);
}

// ---------- البحث ----------
ROUTES.search = async () => {
  V.innerHTML = `<h1 class="h1">البحث</h1><input class="f" id="sq" placeholder="ابحث في الملخصات والأسئلة… (مثلا: المرسل، الإخفاء، فيغوتسكي)" style="margin-top:12px" autofocus><p class="sub" id="ss"></p><div id="sr"></div>`;
  const inp = $("#sq");
  let ready = false, T = null;
  const AR = /[ً-ْـ]/g, nz = (s) => s.replace(AR, "").replace(/[أإآ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه");
  const docs = [];
  $("#ss").textContent = "جاري تجهيز الفهرس…";
  (async () => {
    await loadBank();
    for (const m of CAT.modules) {
      const mm = await loadMod(m.id);
      for (const c of mm.chapters) { const tx = c.html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " "); docs.push({ m, c, tx, n: nz(tx) }); }
    }
    ready = true; $("#ss").textContent = "اكتب كلمتين على الأقل للبحث."; if (inp.value) run();
  })().catch((e) => ($("#ss").textContent = e.message));
  const run = () => {
    const q = inp.value.trim(); if (!ready || q.length < 2) return;
    const nq = nz(q), res = [];
    for (const d of docs) {
      let i = d.n.indexOf(nq), k = 0;
      while (i >= 0 && k < 3) { const sn = d.tx.slice(Math.max(0, i - 70), i + 110); res.push(`<a class="sr" href="#read/${d.c.id}"><small>📖 ${esc(d.m.title)} · ${esc(d.c.title)}</small><p>…${hl(sn, q)}…</p></a>`); k++; i = d.n.indexOf(nq, i + 200); }
      if (res.length > 40) break;
    }
    const qr = BANK.q.filter((x) => nz(x.q + " " + x.a).includes(nq)).slice(0, 25);
    $("#ss").textContent = `${NUM(res.length)} نتيجة ف الملخصات · ${NUM(qr.length)} سؤال`;
    $("#sr").innerHTML = (res.length ? `<div class="card">${res.join("")}</div>` : "") + (qr.length ? `<h2 class="h2">أسئلة <button class="btn sm more" id="sPr">تدرّب عليها</button></h2><div class="card">${qr.map((x) => `<div class="sr"><small>${esc(deckTitle(x.d))} · ${esc(x.src || (x.y === "متوقع" ? "متوقع" : x.y))}</small><p style="color:var(--fg)">${hl(x.q, q)}</p><p>✓ ${hl(x.a, q)}</p></div>`).join("")}</div>` : "");
    const sp = $("#sPr"); if (sp) sp.onclick = () => startSession({ title: "أسئلة البحث: " + q, qs: qr, mode: "practice", back: "#search" });
  };
  const hl = (s, q) => { const e = esc(s); const i = e.indexOf(esc(q)); return i < 0 ? e : e.slice(0, i) + "<mark>" + e.slice(i, i + esc(q).length) + "</mark>" + e.slice(i + esc(q).length); };
  inp.oninput = () => { clearTimeout(T); T = setTimeout(run, 250); };
};

// ---------- الإحصائيات ----------
ROUTES.stats = async () => {
  spin(); await loadBank();
  const t = totals(), mastered = Object.values(ST.srs).filter((r) => r.b >= 3).length;
  const reads = Object.keys(ST.read).length, ex = ST.hist.length;
  const bestM = ex ? Math.max(...ST.hist.map((h) => (h.c / h.n) * 20)).toFixed(2) : "—";
  const days = [...Array(14)].map((_, i) => { const d = new Date(Date.now() - (13 - i) * 864e5); return { k: dayKey(d), l: d.getDate(), v: (ST.days[dayKey(d)] || {}).x || 0 }; });
  const mx = Math.max(ST.goal, ...days.map((d) => d.v));
  V.innerHTML = `<a href="#me" class="sub" style="text-decoration:none">‹ حسابي</a><h1 class="h1" style="margin-top:6px">الإحصائيات</h1>
  <div class="kpis" style="margin-top:14px">
    <div class="kpi"><b>${NUM(t.a)}</b><span>سؤال مجاوب</span></div><div class="kpi"><b>${NUM(pct(t.c, t.a))}%</b><span>نسبة الصواب</span></div>
    <div class="kpi"><b>${NUM(mastered)}</b><span>سؤال متقن</span></div><div class="kpi"><b>${NUM(reads)}/${NUM(CAT.total.chapters)}</b><span>فصل مقروء</span></div>
    <div class="kpi"><b>${NUM(ex)}</b><span>امتحان منجز</span></div><div class="kpi"><b>${bestM}</b><span>أحسن نقطة /20</span></div>
    <div class="kpi"><b>🔥 ${NUM(ST.streak)}</b><span>المواظبة (الأحسن ${NUM(ST.best || 0)})</span></div><div class="kpi"><b>${NUM(ST.xp)}</b><span>مجموع XP</span></div>
  </div>
  <h2 class="h2">نشاط آخر 14 يوم (XP)</h2><div class="card"><div class="chart">${days.map((d, i) => `<div title="${d.k}: ${d.v}"><i class="${i === 13 ? "t" : ""}" style="height:${Math.round((d.v / mx) * 100)}%"></i><span>${d.l}</span></div>`).join("")}</div></div>
  <h2 class="h2">الإتقان حسب المادة</h2><div class="card">${Object.entries(CAT.decks).map(([k, d]) => `<div class="mast"><span>${DECK_ICON[k]} ${esc(d.title)}</span><div class="bar"><i style="width:${mastery(k)}%"></i></div><span class="num">${NUM(mastery(k))}%</span></div>`).join("")}</div>
  <p class="sub" style="margin-top:8px">الإتقان: السؤال كيتحسب متقن ملي كتجاوب عليه صحيح 3 مرات متباعدة.</p>`;
};

// ---------- الترتيب ----------
ROUTES.board = async () => {
  spin();
  let j; try { await pushState(); j = await api("progress", { token: S.token, action: "board" }); } catch (e) { V.innerHTML = `<div class="empty">${esc(e.message)}</div>`; return; }
  let tab = "week";
  const draw = () => {
    const b = j[tab];
    V.innerHTML = `<a href="#me" class="sub" style="text-decoration:none">‹ حسابي</a><h1 class="h1" style="margin-top:6px">🏆 ترتيب المتنافسين</h1>
    <p class="sub">${b.me ? `ترتيبك: <b>${NUM(b.me)}</b> من ${NUM(b.total)}` : "جاوب على الأسئلة باش يبان سميتك ف الترتيب."} · كتربح XP بالأسئلة والقراءة والامتحانات.</p>
    <div class="seg" style="margin:14px 0"><button data-t="week" class="${tab === "week" ? "on" : ""}">هاد السيمانة</button><button data-t="all" class="${tab === "all" ? "on" : ""}">الترتيب العام</button></div>
    <div class="card">${b.top.length ? b.top.map((r) => `<div class="lb ${r.r <= 3 ? "t" + r.r : ""} ${r.me ? "me" : ""}"><span class="r">${r.r <= 3 ? ["🥇", "🥈", "🥉"][r.r - 1] : NUM(r.r)}</span><span class="n">${esc(r.n)}${r.me ? " (أنت)" : ""}${r.st > 2 ? ` <small class="muted">🔥${NUM(r.st)}</small>` : ""}</span><span class="v">${NUM(r.v)} XP</span></div>`).join("") : '<p class="empty">ما زال حتى واحد. كن الأول!</p>'}</div>
    <p class="sub" style="margin-top:10px">السمية اللي كتبان للآخرين: <b>${esc(ST.nick)}</b> · <a href="#me">بدّلها</a></p>`;
    V.querySelectorAll("[data-t]").forEach((x) => (x.onclick = () => { tab = x.dataset.t; draw(); }));
  };
  draw();
};

// ---------- حسابي ----------
let installEv = null;
window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); installEv = e; });
ROUTES.me = async () => {
  spin(); await loadBank();
  const th = LS.get("miras:theme", "auto");
  const certs = Object.entries(CAT.decks).map(([k, d]) => ({ k, d, m: mastery(k) }));
  V.innerHTML = `<section class="card hero-c"><div class="row" style="position:relative;z-index:1"><div style="width:56px;height:56px;border-radius:18px;background:rgba(255,255,255,.12);display:grid;place-items:center;font-size:24px;font-weight:700;color:#f1cf86">${esc((ST.nick || S.name || "م").slice(0, 1))}</div><div style="min-width:0"><b style="font-size:18px;color:#fff">${esc(S.name)}</b><div style="opacity:.8;font-size:13px;direction:ltr;text-align:right">${esc(S.email)}</div></div></div>
  <div class="k"><div class="stat"><b>${NUM(ST.xp)}</b><span>XP</span></div><div class="stat"><b>🔥 ${NUM(ST.streak)}</b><span>أيام</span></div><div class="stat"><b>${NUM(Object.values(ST.srs).filter((r) => r.b >= 3).length)}</b><span>سؤال متقن</span></div></div></section>
  <div class="grid g2" style="margin-top:14px">
    <a class="card act" href="#stats"><span class="ic b">📊</span><span><b>الإحصائيات</b><small>تقدمك ونقط القوة والضعف</small></span><span class="go">‹</span></a>
    <a class="card act" href="#board"><span class="ic p">🏆</span><span><b>الترتيب</b><small>تنافس مع المترشحين</small></span><span class="go">‹</span></a>
    <a class="card act" href="#refer"><span class="ic o">🎁</span><span><b>ادعُ صحابك واربح</b><small>${esc(INFO.refReward || "")}</small></span><span class="go">‹</span></a>
    <button class="card act" id="inst" style="text-align:right"><span class="ic">📲</span><span><b>ثبّت التطبيق</b><small>على الهاتف، ويخدم حتى بلا أنترنت</small></span><span class="go">‹</span></button>
  </div>
  <h2 class="h2">🎖️ شواهد الإتقان</h2>
  <div class="card">${certs.map((c) => `<div class="set"><span>${DECK_ICON[c.k]} ${esc(c.d.title)}<br><small class="muted">${c.m >= 70 ? "مستحقة ✓" : `خاصك 70% (دابا ${NUM(c.m)}%)`}</small></span>${c.m >= 70 ? `<button class="btn gold sm" data-c="${c.k}">عرض الشهادة</button>` : `<div class="bar" style="width:90px"><i style="width:${Math.round((c.m / 70) * 100)}%"></i></div>`}</div>`).join("")}</div>
  <h2 class="h2">الإعدادات</h2>
  <div class="card">
    <div class="set"><span>سميتك ف الترتيب</span><span class="row" style="gap:6px"><input class="f" id="nk" value="${esc(ST.nick)}" maxlength="24" style="width:150px;min-height:38px"><button class="btn sm" id="nkS">حفظ</button></span></div>
    <div class="set"><span>المظهر</span><span class="seg" id="th">${[["auto", "تلقائي"], ["light", "نهاري"], ["dark", "ليلي"]].map(([v, l]) => `<button data-v="${v}" class="${th === v ? "on" : ""}">${l}</button>`).join("")}</span></div>
    <div class="set"><span>هدف اليوم (XP)</span><span class="seg" id="gl">${[30, 60, 120, 200].map((v) => `<button data-v="${v}" class="${ST.goal === v ? "on" : ""}">${NUM(v)}</button>`).join("")}</span></div>
    <div class="set"><span>حجم الخط</span><span class="seg" id="fz">${[[16, "صغير"], [18, "متوسط"], [21, "كبير"]].map(([v, l]) => `<button data-v="${v}" class="${ST.fs === v ? "on" : ""}">${l}</button>`).join("")}</span></div>
    <div class="set"><span>تحميل المحتوى كامل للاستعمال بلا أنترنت</span><button class="btn sm" id="dl">تحميل</button></div>
    <div class="set"><span>تواصل معنا</span>${INFO.whatsapp ? `<a class="btn sm" href="https://wa.me/${esc(String(INFO.whatsapp).replace(/\D/g, "").replace(/^0/, "212"))}" target="_blank" rel="noopener">واتساب</a>` : ""}</div>
    <div class="set"><span>الخروج من الحساب</span><button class="btn sm" id="lo" style="color:var(--bad)">خروج</button></div>
  </div>`;
  $("#nkS").onclick = () => { ST.nick = $("#nk").value.replace(/[<>]/g, "").trim().slice(0, 24) || ST.nick; save(); pushState(); toast("تحفظات السمية ✓"); };
  V.querySelectorAll("#th [data-v]").forEach((b) => (b.onclick = () => { LS.set("miras:theme", b.dataset.v); applyPrefs(); route(); }));
  V.querySelectorAll("#gl [data-v]").forEach((b) => (b.onclick = () => { ST.goal = +b.dataset.v; save(); route(); }));
  V.querySelectorAll("#fz [data-v]").forEach((b) => (b.onclick = () => { ST.fs = +b.dataset.v; applyPrefs(); save(false); route(); }));
  V.querySelectorAll("[data-c]").forEach((b) => (b.onclick = () => cert(b.dataset.c)));
  $("#lo").onclick = () => sheet("الخروج", `<p class="sub">التقدم ديالك محفوظ ف الحساب. غادي تحتاج رمز الدخول باش ترجع.</p><div class="qnav"><button class="btn" data-x>رجوع</button><button class="btn pri" id="lox">خروج</button></div>`, (el) => (el.querySelector("#lox").onclick = () => { closeSheet(); logout(); }));
  $("#dl").onclick = async () => { const b = $("#dl"); b.disabled = true; let i = 0; for (const m of CAT.modules) { b.textContent = NUM(++i) + "/" + NUM(CAT.modules.length); try { await loadMod(m.id); } catch (e) { b.textContent = "خطأ"; return; } } b.textContent = "✓ محمّل"; toast("المحتوى كامل متوفر بلا أنترنت ✓"); };
  $("#inst").onclick = async () => {
    if (installEv) { installEv.prompt(); installEv = null; return; }
    sheet("ثبّت مِراس على الهاتف", `<p><b>أندرويد:</b> حمّل تطبيق APK أو من Chrome: القائمة ⋮ ← «إضافة إلى الشاشة الرئيسية».</p><p><b>آيفون:</b> من Safari: زر المشاركة ← «إضافة إلى الشاشة الرئيسية».</p><a class="btn pri block" href="miras.apk" download>تحميل تطبيق أندرويد (APK)</a>`);
  };
};
ROUTES.refer = async () => {
  const link = location.origin + "/?ref=" + S.ref;
  V.innerHTML = `<a href="#me" class="sub" style="text-decoration:none">‹ حسابي</a><h1 class="h1" style="margin-top:6px">🎁 ادعُ صحابك واربح</h1>
  <p class="sub">${esc(INFO.refReward || "")}. شارك الرابط ديالك، وكل صاحب يشترك من خلالو كيتحسب ليك.</p>
  <div class="card" style="margin-top:14px"><div class="refbox"><code>${esc(link)}</code><button class="btn pri sm" id="cp">نسخ</button></div>
  <div class="row" style="margin-top:12px;gap:8px"><a class="btn block" style="background:#25d366;border-color:#25d366;color:#05210f" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent("كنوجد لمباراة التعليم (التربية الإسلامية) بمنصة مِراس: ملخصات كاملة + آلاف الأسئلة + امتحانات تجريبية. سجّل من هنا: " + link)}">مشاركة ف واتساب</a></div></div>
  <div class="kpis" style="margin-top:14px" id="rk"><div class="kpi"><b>…</b><span>اشتراك مفعّل برابطك</span></div><div class="kpi"><b>…</b><span>ف انتظار التفعيل</span></div></div>
  <div class="card" style="margin-top:14px"><b>كيفاش كتخدم؟</b><ol style="margin:8px 0 0;padding-inline-start:20px;line-height:2"><li>صيفط الرابط لصحابك ف المجموعات.</li><li>صاحبك كيطلب الاشتراك من الرابط ديالك.</li><li>ملي يتفعل الاشتراك ديالو، كنتواصلو معاك باش تاخد المكافأة.</li></ol></div>`;
  $("#cp").onclick = () => { try { navigator.clipboard.writeText(link); toast("تنسخ الرابط ✓"); } catch (e) { toast(link); } };
  try { const r = await api("progress", { token: S.token, action: "refs" }); $("#rk").innerHTML = `<div class="kpi"><b>${NUM(r.active)}</b><span>اشتراك مفعّل برابطك</span></div><div class="kpi"><b>${NUM(r.pending)}</b><span>ف انتظار التفعيل</span></div>`; } catch (e) {}
};
function cert(k) {
  const d = CAT.decks[k], m = mastery(k), date = new Date().toLocaleDateString("ar-MA", { year: "numeric", month: "long", day: "numeric" });
  const w = window.open("", "_blank"); if (!w) return toast("سمح بالنوافذ المنبثقة باش تبان الشهادة");
  w.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>شهادة إتقان · ${esc(d.title)}</title><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Reem+Kufi:wght@700&family=Readex+Pro:wght@400;600&family=Aref+Ruqaa:wght@700&display=swap"><style>@page{size:A4 landscape;margin:0}body{margin:0;background:#eee;font-family:"Readex Pro",sans-serif}.c{width:297mm;height:210mm;margin:0 auto;background:#fffdf6;position:relative;box-sizing:border-box;padding:18mm;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:#1c2520}.c::before{content:"";position:absolute;inset:8mm;border:3px solid #0d4f43;border-radius:6mm}.c::after{content:"";position:absolute;inset:11mm;border:1.2px solid #c9973a;border-radius:4mm}h1{font-family:"Reem Kufi";color:#0d4f43;font-size:46px;margin:6px 0}.n{font-family:"Aref Ruqaa";font-size:52px;color:#a8781f;margin:10px 0}.s{font-size:19px;line-height:1.9;max-width:200mm}.f{display:flex;justify-content:space-between;width:220mm;margin-top:16mm;font-size:15px}.b{font-size:15px;letter-spacing:.1em;color:#a8781f}button{position:fixed;top:12px;left:12px;padding:10px 18px;font:inherit;background:#0d4f43;color:#fff;border:0;border-radius:10px;cursor:pointer}@media print{button{display:none}body{background:#fff}}</style></head><body><button onclick="print()">طباعة / حفظ PDF</button><div class="c"><div class="b">منصة مِراس · MiRas</div><h1>شهادة إتقان</h1><div class="s">تشهد منصة مِراس للتحضير لمباراة ولوج المراكز الجهوية لمهن التربية والتكوين بأن</div><div class="n">${esc(S.name)}</div><div class="s">قد أتمّ التدريب على بنك أسئلة <b>${esc(d.title)}</b> بنسبة إتقان بلغت <b>${m}%</b>، عن طريق نظام المراجعة الذكية المتباعدة.</div><div class="f"><span>التاريخ: ${date}</span><span>تخصص التربية الإسلامية · طبعة 2026</span></div></div></body></html>`);
  w.document.close();
}

// ---------- الإقلاع ----------
(async () => {
  applyPrefs();
  try { INFO = await (await fetch("/.netlify/functions/info")).json(); LS.set("miras:info", INFO); } catch (e) { INFO = LS.get("miras:info", {}); }
  if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
  route();
})();
})();
