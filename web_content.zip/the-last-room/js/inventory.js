/* THE LAST ROOM - item registry + inventory (persisted through the save system) */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {};
  const NOTE_TYPE = { letter: 'note', photo: 'photo', audio: 'audio', doc: 'doc', msg: 'msg' };
  const Inv = TLR.Inv = {
    items: {}, recipes: [],
    build() {
      this.items = {}; this.recipes = [];
      TLR.LEVELS.forEach(l => {
        l.objects.forEach((o, i) => {
          o.id = o.id || (l.id + '#' + i);
          const reg = (it) => { if (it && !this.items[it.id]) this.items[it.id] = Object.assign({ lv: l.id }, it); };
          if (o.item) reg(o.item); if (o.give) [].concat(o.give).forEach(reg);
          if (o.k === 'note' && o.keep !== false) { o.itemId = 'note:' + l.id + ':' + i; this.items[o.itemId] = { id: o.itemId, name: o.title, type: NOTE_TYPE[o.kind2] || 'note', desc: o.text, lv: l.id, text: o.text, note: true, kind2: o.kind2 }; }
        });
        l.recipes.forEach(r => { r.lv = l.id; const it = r.out; if (!this.items[it.id]) this.items[it.id] = Object.assign({ lv: l.id }, it); this.recipes.push(r); });
      });
    },
    list() { return TLR.Save.data.inv; },
    count(id) { return TLR.Save.data.inv.filter(i => i === id).length; },
    has(id) { return this.count(id) > 0; },
    def(id) { return this.items[id]; },
    add(it) { const inv = TLR.Save.data.inv; if (!this.items[it.id]) this.items[it.id] = it; if (!it.stack && inv.indexOf(it.id) >= 0) return false; inv.push(it.id); return true; },
    remove(id, n) { const inv = TLR.Save.data.inv; n = n || 1; for (let i = inv.length - 1; i >= 0 && n > 0; i--) if (inv[i] === id) { inv.splice(i, 1); n--; } },
    recipeFor(a, b) { return this.recipes.find(r => (r.a === a && r.b === b) || (r.a === b && r.b === a)); }
  };
})(window);
