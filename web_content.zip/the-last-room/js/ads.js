/* THE LAST ROOM - coins and rewarded ads.
   Coins are earned by finishing levels and by watching an optional rewarded ad. Coins pay for help (solve a puzzle, show where a part is).
   Real ads: the Android app exposes window.AndroidAds.showRewarded(); when the ad is finished the app calls TLR.Ads.done(true) (or done(false) if skipped/failed).
   Without that bridge (browser, desktop) a clearly-labelled demo ad is shown instead. */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {};
  const Ads = TLR.Ads = {
    REWARD: 30, _cb: null,
    coins() { return (TLR.Save.data.coins | 0); },
    add(n) { TLR.Save.data.coins = Math.max(0, this.coins() + n); TLR.Save.save(); this.refresh(); if (n > 0) this.pop(n); },
    pop(n) { const ch = document.getElementById('hud-coin'); if (!ch) return; ch.classList.remove('bump'); void ch.offsetWidth; ch.classList.add('bump'); const f = document.createElement('span'); f.className = 'coin-fly'; f.textContent = '+' + n; ch.appendChild(f); setTimeout(() => f.remove(), 1400); },

    spend(n) { if (this.coins() < n) return false; this.add(-n); return true; },
    refresh() { const e = document.getElementById('coin-n'); if (e) e.textContent = this.coins(); document.querySelectorAll('.coin-n2').forEach(x => { x.textContent = this.coins(); }); },
    watch(cb) {
      if (g.AndroidAds && g.AndroidAds.showRewarded) { this._cb = cb; try { g.AndroidAds.showRewarded(); } catch (e) { this.done(false); } return; }
      TLR.UI.adDemo(ok => { if (ok) this.add(this.REWARD); if (cb) cb(!!ok); });
    },
    done(ok) { const cb = this._cb; this._cb = null; if (ok) this.add(this.REWARD); if (cb) cb(!!ok); }
  };
})(window);
