/* THE LAST ROOM - layered environment renderer: 10 hand-built procedural themes, lights, particles */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {}, U = TLR.U, TAU = U.TAU;
  const PAD = 260;
  const TH = {
    mansion: { dark: .5, amb: 'mansion', mat: 'wood', part: 'dust', pf: 0, fog: '#2a1b14', lt: '#ffd9a0', c1: '#c9a24a' },
    city: { dark: .6, amb: 'city', mat: 'stone', part: 'rain', pf: .35, fog: '#1a1430', lt: '#cfe4ff', c1: '#ff4fa3' },
    sewer: { dark: .66, amb: 'sewer', mat: 'stone', part: 'drip', pf: 0, fog: '#0f2a1c', lt: '#b6ffd2', c1: '#5cff9a' },
    factory: { dark: .5, amb: 'factory', mat: 'metal', part: 'ember', pf: .2, fog: '#2a1408', lt: '#ffd6a0', c1: '#ff9a3a' },
    lab: { dark: .42, amb: 'lab', mat: 'metal', part: 'spark', pf: 0, fog: '#0a1c30', lt: '#d8f3ff', c1: '#3fd0ff' },
    temple: { dark: .58, amb: 'temple', mat: 'stone', part: 'dust', pf: 0, fog: '#1a2412', lt: '#ffd9a0', c1: '#ffb347' },
    sky: { dark: .08, amb: 'sky', mat: 'stone', part: 'wind', pf: .3, fog: '#ffd0a0', lt: '#fff0d0', c1: '#7ae7ff' },
    dream: { dark: .3, amb: 'dream', mat: 'glass', part: 'spark', pf: .25, fog: '#3a1a5a', lt: '#f0d8ff', c1: '#d77aff' },
    space: { dark: .38, amb: 'space', mat: 'metal', part: 'dust', pf: .15, fog: '#06101e', lt: '#d8f0ff', c1: '#5ab8ff' },
    final: { dark: .68, amb: 'final', mat: 'stone', part: 'ember', pf: 0, fog: '#240808', lt: '#ffb0a0', c1: '#ff2a3a' }
  };
  /* ---------- small helpers ---------- */
  const rr = U.rr, lg = U.lg, rg = U.rg;
  function light(S, x, y, r, col, fl, a) { S.lights.push({ x, y, r, c: col, fl: fl || 0, a: a == null ? 1 : a }); }
  function beam(c, x, y0, w0, w1, len, col, a) { c.save(); c.globalAlpha = a; c.fillStyle = lg(c, 0, y0, 0, y0 + len, [[0, col], [1, 'rgba(0,0,0,0)']]); c.beginPath(); c.moveTo(x - w0 / 2, y0); c.lineTo(x + w0 / 2, y0); c.lineTo(x + w1 / 2, y0 + len); c.lineTo(x - w1 / 2, y0 + len); c.fill(); c.restore(); }
  function bricks(c, x, y, w, h, bw, bh, col, hi, r) {
    c.fillStyle = col; c.fillRect(x, y, w, h);
    for (let j = 0, yy = y; yy < y + h; yy += bh, j++) for (let xx = x - (j % 2 ? bw / 2 : 0); xx < x + w; xx += bw) {
      const a = r() * .22; c.fillStyle = r() < .5 ? 'rgba(0,0,0,' + a + ')' : 'rgba(255,255,255,' + a / 2.2 + ')';
      const bx = Math.max(x, xx + 1), bex = Math.min(x + w, xx + bw - 1); if (bex > bx) c.fillRect(bx, yy + 1, bex - bx, Math.min(bh - 2, y + h - yy - 1));
    }
    c.fillStyle = hi || 'rgba(0,0,0,.35)';
    for (let yy = y; yy < y + h; yy += bh) c.fillRect(x, yy, w, 1);
  }
  function blocks(c, x, y, w, h, bw, bh, base, r) {
    c.fillStyle = base; c.fillRect(x, y, w, h);
    for (let j = 0, yy = y; yy < y + h; yy += bh, j++) { let xx = x - (j % 2 ? bw * .5 : 0); while (xx < x + w) { const ww = bw * (.8 + r() * .5); const sh = (r() - .5) * 26; c.fillStyle = 'rgba(' + (sh > 0 ? '255,255,255,' + sh / 400 : '0,0,0,' + -sh / 120) + ')'; c.fillRect(Math.max(x, xx), yy, Math.min(ww, x + w - Math.max(x, xx)), bh); c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(Math.max(x, xx), yy, 1, bh); xx += ww; } c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(x, yy, w, 1); }
  }
  function vignetteEdges(c, x, y, w, h, a) { c.fillStyle = lg(c, 0, y, 0, y + h, [[0, 'rgba(0,0,0,' + a + ')'], [.3, 'rgba(0,0,0,0)'], [.75, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,' + a * .9 + ')']]); c.fillRect(x, y, w, h); }
  function stars(c, w, h, n, r, y0) { for (let i = 0; i < n; i++) { const a = r() * .8 + .15; c.fillStyle = 'rgba(255,255,255,' + a + ')'; const s = r() < .08 ? 2 : 1; c.fillRect(r() * w, y0 + r() * h, s, s); } }
  /* ---------- decor primitives used by several themes ---------- */
  function archWindow(S, x, y, w, h, o) {
    const c = S.nc; o = o || {};
    c.fillStyle = '#0a0709'; c.beginPath(); c.moveTo(x - w / 2 - 5, y + h); c.lineTo(x - w / 2 - 5, y + w / 2); c.arc(x, y + w / 2, w / 2 + 5, Math.PI, 0); c.lineTo(x + w / 2 + 5, y + h); c.fill();
    c.fillStyle = lg(c, 0, y, 0, y + h, [[0, o.top || '#1b2a4a'], [1, o.bot || '#0e1426']]); c.beginPath(); c.moveTo(x - w / 2, y + h); c.lineTo(x - w / 2, y + w / 2); c.arc(x, y + w / 2, w / 2, Math.PI, 0); c.lineTo(x + w / 2, y + h); c.fill();
    c.strokeStyle = '#06050a'; c.lineWidth = 2.5; c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + h); c.moveTo(x - w / 2, y + h * .45); c.lineTo(x + w / 2, y + h * .45); c.stroke();
    if (o.broken) { c.fillStyle = '#0a0709'; c.beginPath(); c.moveTo(x - w / 2, y + h * .5); c.lineTo(x - w * .1, y + h * .62); c.lineTo(x - w * .3, y + h * .8); c.lineTo(x + w * .1, y + h * .72); c.lineTo(x + w / 2, y + h * .9); c.lineTo(x + w / 2, y + h); c.lineTo(x - w / 2, y + h); c.fill(); }
    if (o.beam) beam(c, x, y + h * .3, w * .8, w * 1.8, S.FY - y - h * .3, o.beamCol || 'rgba(150,180,255,.5)', .1);
  }
  function framePic(c, x, y, w, h, r, seed) {
    c.fillStyle = '#2a1a0c'; c.fillRect(x - w / 2 - 5, y - 5, w + 10, h + 10); c.fillStyle = '#9b7a35'; c.fillRect(x - w / 2 - 3, y - 3, w + 6, h + 6);
    c.fillStyle = '#18100a'; c.fillRect(x - w / 2, y, w, h);
    const rr2 = U.rnd(seed), pal = [['#3a2a22', '#775a43'], ['#1e2a35', '#587290'], ['#2a2f20', '#7d8a55'], ['#35202a', '#8a5a6a']][Math.floor(rr2() * 4)];
    c.fillStyle = lg(c, 0, y, 0, y + h, [[0, pal[0]], [1, pal[1]]]); c.fillRect(x - w / 2, y, w, h);
    c.fillStyle = 'rgba(0,0,0,.55)'; c.beginPath(); c.ellipse(x, y + h * .42, w * .2, h * .22, 0, 0, TAU); c.fill(); c.fillRect(x - w * .3, y + h * .62, w * .6, h * .4);
    c.fillStyle = 'rgba(255,230,190,.14)'; c.beginPath(); c.ellipse(x - 2, y + h * .38, w * .1, h * .12, 0, 0, TAU); c.fill();
  }
  function pillar(S, x, w, col, top) { const c = S.nc; c.fillStyle = lg(c, x - w / 2, 0, x + w / 2, 0, [[0, col[0]], [.5, col[1]], [1, col[0]]]); c.fillRect(x - w / 2, top, w, S.FY - top); c.fillStyle = col[2] || 'rgba(0,0,0,.4)'; c.fillRect(x - w / 2 - 4, top, w + 8, 8); c.fillRect(x - w / 2 - 4, S.FY - 10, w + 8, 10); }
  function ceilingChain(c, x, len) { c.strokeStyle = '#1a1210'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(x, 0); c.lineTo(x, len); c.stroke(); }
  function pipeH(c, x0, x1, y, h, cols) { c.fillStyle = lg(c, 0, y, 0, y + h, [[0, cols[0]], [.4, cols[1]], [1, cols[2]]]); c.fillRect(x0, y, x1 - x0, h); for (let x = x0 + 30; x < x1; x += 120) { c.fillStyle = cols[2]; c.fillRect(x, y - 2, 6, h + 4); } }
  function pipeV(c, x, y0, y1, w, cols) { c.fillStyle = lg(c, x, 0, x + w, 0, [[0, cols[2]], [.4, cols[1]], [1, cols[0]]]); c.fillRect(x, y0, w, y1 - y0); for (let y = y0 + 20; y < y1; y += 70) { c.fillStyle = cols[2]; c.fillRect(x - 2, y, w + 4, 5); } }
  /* ---------- THEMES ---------- */
  const B = {};
  B.mansion = function (S) {
    const c = S.nc, W = S.W, FY = S.FY, r = S.r;
    c.fillStyle = lg(c, 0, -PAD, 0, FY, [[0, '#07050a'], [.4, '#1a0f13'], [1, '#2d1b19']]); c.fillRect(0, -PAD, W, FY + PAD + 90);
    c.globalAlpha = .07; c.fillStyle = '#d8b25f'; for (let x = 0; x < W; x += 34) for (let y = 24; y < FY - 90; y += 34) { c.beginPath(); c.moveTo(x + 17, y); c.lineTo(x + 25, y + 12); c.lineTo(x + 17, y + 24); c.lineTo(x + 9, y + 12); c.fill(); } c.globalAlpha = 1;
    c.fillStyle = '#100809'; c.fillRect(0, -PAD, W, PAD + 16); c.fillStyle = '#3a2219'; c.fillRect(0, 12, W, 5); c.fillStyle = '#1d100c'; c.fillRect(0, 17, W, 5);
    c.fillStyle = '#25140f'; c.fillRect(0, FY - 84, W, 84); c.fillStyle = '#4a2c1c'; c.fillRect(0, FY - 86, W, 5);
    for (let x = 14; x < W; x += 62) { c.strokeStyle = 'rgba(0,0,0,.5)'; c.lineWidth = 2; c.strokeRect(x, FY - 72, 48, 58); c.strokeStyle = 'rgba(255,210,150,.09)'; c.strokeRect(x + 3, FY - 69, 42, 52); }
    let x = 110 + r() * 50, n = 0;
    while (x < W - 100) {
      const k = (n++ + Math.floor(r() * 3)) % 5;
      if (k === 0 || k === 3) { archWindow(S, x, 34, 54, 128, { broken: r() < .5, beam: true }); light(S, x, 110, 120, 'rgba(120,150,255,1)', 0, .35); x += 170 + r() * 90; }
      else if (k === 1) { framePic(c, x, 62, 44 + r() * 14, 58 + r() * 14, r, Math.floor(r() * 9999)); x += 150 + r() * 80; }
      else if (k === 2) { // sconce
        c.fillStyle = '#3a2a14'; c.fillRect(x - 3, 90, 6, 14); c.fillStyle = '#7a5a22'; c.beginPath(); c.arc(x, 88, 7, Math.PI, 0); c.fill();
        S.dyn.push({ t: 'flame', x, y: 80, s: 1 }); light(S, x, 80, 130, '#ffb56a', 1, .9); x += 170 + r() * 80;
      } else { // background door
        c.fillStyle = '#0d0707'; c.fillRect(x - 31, FY - 128, 62, 128); c.fillStyle = '#34190f'; c.fillRect(x - 27, FY - 124, 54, 124); c.strokeStyle = 'rgba(0,0,0,.5)'; c.lineWidth = 2; c.strokeRect(x - 20, FY - 112, 18, 42); c.strokeRect(x + 2, FY - 112, 18, 42); c.strokeRect(x - 20, FY - 62, 40, 52);
        c.fillStyle = '#c9a24a'; c.beginPath(); c.arc(x + 17, FY - 60, 3, 0, TAU); c.fill(); x += 190 + r() * 80;
      }
    }
    for (let cx = 330 + r() * 80; cx < W - 120; cx += 560 + r() * 160) { // chandelier
      ceilingChain(c, cx, 62); c.fillStyle = '#6a5224'; c.beginPath(); c.arc(cx, 66, 4, 0, TAU); c.fill(); c.strokeStyle = '#8a6c30'; c.lineWidth = 2; c.beginPath(); c.arc(cx, 72, 26, .15 * Math.PI, .85 * Math.PI); c.stroke(); c.beginPath(); c.moveTo(cx - 26, 72); c.lineTo(cx - 22, 82); c.moveTo(cx + 26, 72); c.lineTo(cx + 22, 82); c.moveTo(cx, 66); c.lineTo(cx, 84); c.stroke();
      for (let i = -2; i <= 2; i++) { c.fillStyle = '#d8c9a0'; c.fillRect(cx + i * 11 - 1.5, 76 + Math.abs(i) * 3, 3, 8); S.dyn.push({ t: 'flame', x: cx + i * 11, y: 75 + Math.abs(i) * 3, s: .7 }); }
      c.fillStyle = 'rgba(200,220,255,.5)'; for (let i = -3; i <= 3; i++) c.fillRect(cx + i * 7, 90 + Math.abs(i), 1.5, 5 + (i & 1) * 3);
      light(S, cx, 80, 190, '#ffc87a', 1, .85);
    }
    c.fillStyle = lg(c, 0, FY, 0, S.H, [[0, '#4a2c19'], [.15, '#3a2214'], [1, '#150b07']]); c.fillRect(0, FY, W, S.H - FY);
    for (let px = 0; px < W; px += 7 + ((px / 7) % 3)) { c.fillStyle = 'rgba(0,0,0,' + (.15 + r() * .25) + ')'; c.fillRect(px, FY, 1, S.H - FY); }
    c.fillStyle = 'rgba(255,220,170,.28)'; c.fillRect(0, FY, W, 2); c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(0, FY + 2, W, 3);
    for (let rx = 160 + r() * 200; rx < W - 200; rx += 420 + r() * 220) { c.fillStyle = '#5a1620'; c.fillRect(rx, FY + 8, 160, 28); c.fillStyle = '#b8964a'; c.fillRect(rx, FY + 8, 160, 2); c.fillRect(rx, FY + 34, 160, 2); c.fillStyle = 'rgba(0,0,0,.25)'; for (let i = 0; i < 160; i += 8) c.fillRect(rx + i, FY + 10, 3, 24); }
    // cobwebs
    c.strokeStyle = 'rgba(255,255,255,.16)'; c.lineWidth = .8; for (const cx of [0, W]) { const d = cx ? -1 : 1; for (let i = 0; i < 5; i++) { c.beginPath(); c.moveTo(cx, 20); c.quadraticCurveTo(cx + d * 20, 20 + i * 8, cx + d * (14 + i * 8), 22 + i * 14 + 10); c.stroke(); } }
    vignetteEdges(c, 0, -PAD, W, S.H + PAD, .25);
  };
  B.city = function (S) {
    const c = S.nc, f = S.fc, W = S.W, FY = S.FY, r = S.r, FW = S.FW;
    f.fillStyle = lg(f, 0, -PAD, 0, FY, [[0, '#04050c'], [.5, '#120f28'], [1, '#2d1636']]); f.fillRect(0, -PAD, FW, FY + PAD + 100);
    stars(f, FW, 160, 60, r, -PAD + 60);
    for (let l = 0; l < 3; l++) { for (let x = -40; x < FW; x += 60 + r() * 90) { const bw = 70 + r() * 110, bh = 120 + r() * 150 + l * 20; f.fillStyle = ['#0b0a18', '#0f0d20', '#151229'][l]; f.fillRect(x, FY - bh - l * 15, bw, bh + l * 15 + 60);
        for (let wy = FY - bh - l * 15 + 10; wy < FY - 20; wy += 14) for (let wx = x + 6; wx < x + bw - 8; wx += 12) if (r() < .13 + l * .05) { f.fillStyle = r() < .6 ? 'rgba(255,200,120,.55)' : 'rgba(120,200,255,.5)'; f.fillRect(wx, wy, 5, 7); } } }
    f.fillStyle = lg(f, 0, FY - 80, 0, FY + 20, [[0, 'rgba(255,60,160,0)'], [1, 'rgba(255,60,160,.18)']]); f.fillRect(0, FY - 80, FW, 100);
    // near facades
    let x = -20;
    while (x < W) {
      const bw = 230 + r() * 120, top = 30 + r() * 40; const col = ['#16121f', '#1b1626', '#120f1a'][Math.floor(r() * 3)];
      bricks(c, x, top, bw, FY - top, 14, 7, col, 'rgba(0,0,0,.4)', r);
      c.fillStyle = '#0a0810'; c.fillRect(x, top - 6, bw, 6); c.fillStyle = '#251d33'; c.fillRect(x, top, bw, 2);
      for (let wy = top + 24; wy < FY - 100; wy += 54) for (let wx = x + 22; wx < x + bw - 36; wx += 52) {
        const lit = r() < .22; c.fillStyle = '#07060b'; c.fillRect(wx - 3, wy - 3, 36, 40);
        c.fillStyle = lit ? (r() < .5 ? '#e6b46a' : '#6fb7e8') : lg(c, 0, wy, 0, wy + 34, [[0, '#101826'], [1, '#080b14']]); c.fillRect(wx, wy, 30, 34);
        if (lit) { c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(wx, wy + 18, 30, 16); light(S, wx + 15, wy + 17, 50, '#ffcf80', 0, .35); }
        c.strokeStyle = '#05040a'; c.lineWidth = 2; c.strokeRect(wx, wy, 30, 34); c.beginPath(); c.moveTo(wx + 15, wy); c.lineTo(wx + 15, wy + 34); c.stroke();
        if (r() < .15) { c.fillStyle = 'rgba(255,255,255,.1)'; c.fillRect(wx, wy + 8, 30, 3); }
      }
      // door & shutter
      const dx = x + bw * (.3 + r() * .4); c.fillStyle = '#07060b'; c.fillRect(dx - 22, FY - 76, 44, 76); c.fillStyle = r() < .5 ? '#2a1d1d' : '#1c2733'; c.fillRect(dx - 19, FY - 72, 38, 72); c.fillStyle = 'rgba(0,0,0,.35)'; for (let s = 0; s < 72; s += 6) c.fillRect(dx - 19, FY - 72 + s, 38, 2);
      // neon sign
      if (r() < .8) { const nc = ['#ff3fa4', '#3fe7ff', '#ffd13f', '#8f5bff', '#43ff9a'][Math.floor(r() * 5)]; S.dyn.push({ t: 'neon', x: x + bw * .5 + (r() - .5) * 60, y: top + 10 + r() * 20, w: 70 + r() * 30, h: 22, c: nc, ph: r() * 9, txt: ['HOTEL', 'BAR', 'OPEN', 'CAFE', 'NOODLE', 'MOTEL', '24H'][Math.floor(r() * 7)] }); light(S, x + bw * .5, top + 24, 120, nc, 1, .45); }
      x += bw + 6 + r() * 20;
    }
    // sidewalk and road
    c.fillStyle = '#2b2736'; c.fillRect(0, FY, W, 14); c.fillStyle = '#403a52'; c.fillRect(0, FY, W, 2); c.fillStyle = 'rgba(0,0,0,.5)'; for (let sx = 0; sx < W; sx += 64) c.fillRect(sx, FY, 1, 14);
    c.fillStyle = lg(c, 0, FY + 14, 0, S.H, [[0, '#0b0a12'], [1, '#050409']]); c.fillRect(0, FY + 14, W, S.H - FY - 14);
    c.fillStyle = 'rgba(255,220,100,.3)'; for (let sx = 20; sx < W; sx += 90) c.fillRect(sx, FY + 40, 44, 3);
    for (let i = 0; i < 6; i++) { const px = r() * W; c.fillStyle = lg(c, px, 0, px + 120, 0, [[0, 'rgba(120,160,255,0)'], [.5, 'rgba(120,160,255,.14)'], [1, 'rgba(120,160,255,0)']]); c.fillRect(px, FY + 20 + r() * 20, 120, 2); }
    // street lamps
    for (let lx = 260 + r() * 100; lx < W - 100; lx += 520 + r() * 150) { c.fillStyle = '#0d0c14'; c.fillRect(lx - 3, FY - 150, 6, 150); c.fillRect(lx - 3, FY - 152, 36, 5); c.fillStyle = '#ffe9b0'; c.fillRect(lx + 22, FY - 148, 12, 5); const broken = r() < .35; S.dyn.push({ t: 'lamp', x: lx + 28, y: FY - 145, broken, ph: r() * 20 }); light(S, lx + 28, FY - 130, broken ? 110 : 190, '#ffd89a', broken ? 3 : .25, broken ? .6 : .8); beam(c, lx + 28, FY - 144, 14, 120, 144, 'rgba(255,230,170,.5)', broken ? .04 : .09); }
    vignetteEdges(c, 0, -PAD, W, S.H + PAD, .2);
  };
  B.sewer = function (S) {
    const c = S.nc, W = S.W, FY = S.FY, r = S.r, H = S.H;
    c.fillStyle = '#0a1410'; c.fillRect(0, -PAD, W, H + PAD);
    bricks(c, 0, 0, W, FY, 18, 9, '#1a2a22', 'rgba(0,0,0,.5)', r);
    c.fillStyle = lg(c, 0, -PAD, 0, 40, [[0, '#040807'], [1, '#0f1b16']]); c.fillRect(0, -PAD, W, PAD + 40);
    for (let x = 0; x < W; x += 140) { c.fillStyle = 'rgba(0,0,0,.45)'; c.beginPath(); c.moveTo(x, 40); c.quadraticCurveTo(x + 70, -20, x + 140, 40); c.lineTo(x + 140, 0); c.lineTo(x, 0); c.fill(); }
    c.fillStyle = 'rgba(40,120,70,.12)'; for (let i = 0; i < 40; i++) { c.beginPath(); c.ellipse(r() * W, 20 + r() * (FY - 30), 10 + r() * 28, 5 + r() * 12, 0, 0, TAU); c.fill(); }
    pipeH(c, 0, W, 56, 14, ['#3a2a1c', '#6a4a2e', '#241810']); pipeH(c, 0, W, 78, 9, ['#2a3a30', '#4a6a58', '#15221b']);
    for (let x = 120 + r() * 100; x < W - 80; x += 200 + r() * 160) {
      const k = Math.floor(r() * 4);
      if (k === 0) { pipeV(c, x, 56, FY, 16, ['#3a2a1c', '#6a4a2e', '#241810']); S.dyn.push({ t: 'drip', x: x + 8, y: 200, ph: r() * 9 }); }
      else if (k === 1) { c.fillStyle = '#0a1210'; c.fillRect(x - 24, 96, 48, 40); c.fillStyle = '#233'; for (let i = 0; i < 7; i++) c.fillRect(x - 22 + i * 7, 98, 3, 36); beam(c, x, 130, 40, 110, FY - 130, 'rgba(120,255,170,.6)', .12); light(S, x, 140, 150, '#60ff9a', 0, .35); }
      else if (k === 2) { c.fillStyle = '#2a1a12'; c.fillRect(x - 24, FY - 94, 48, 94); c.fillStyle = '#4a2f1d'; c.fillRect(x - 21, FY - 91, 42, 91); c.fillStyle = 'rgba(180,80,20,.4)'; for (let i = 0; i < 12; i++) c.fillRect(x - 21 + r() * 40, FY - 91 + r() * 90, 4 + r() * 8, 3); c.fillStyle = '#16100c'; c.fillRect(x - 21, FY - 52, 42, 3); }
      else { c.fillStyle = '#26301e'; c.fillRect(x - 3, 110, 6, 18); c.fillStyle = '#9dffc0'; c.beginPath(); c.arc(x, 134, 8, 0, TAU); c.fill(); c.strokeStyle = '#111'; c.lineWidth = 1.5; c.strokeRect(x - 10, 124, 20, 20); light(S, x, 134, 170, '#55ffa0', 1.2, .85); }
    }
    c.fillStyle = lg(c, 0, FY, 0, FY + 14, [[0, '#4a5a50'], [1, '#1a241e']]); c.fillRect(0, FY, W, 14); c.fillStyle = 'rgba(190,255,210,.25)'; c.fillRect(0, FY, W, 2); for (let x = 0; x < W; x += 55) { c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(x, FY, 1, 14); }
    c.fillStyle = '#04100b'; c.fillRect(0, FY + 14, W, H - FY - 14);
    S.dyn.push({ t: 'water', x0: 0, x1: W, y0: FY + 14, y1: H, c: '#0d3a2a' });
    vignetteEdges(c, 0, -PAD, W, H + PAD, .3);
  };
  B.factory = function (S) {
    const c = S.nc, f = S.fc, W = S.W, FY = S.FY, r = S.r, H = S.H, FW = S.FW;
    f.fillStyle = lg(f, 0, -PAD, 0, FY, [[0, '#120a06'], [1, '#3a1c0c']]); f.fillRect(0, -PAD, FW, FY + PAD + 80);
    for (let x = 0; x < FW; x += 160) { f.fillStyle = 'rgba(0,0,0,.4)'; f.fillRect(x, -PAD, 14, FY + PAD); f.fillRect(x, 40, 160, 8); f.fillRect(x, 150, 160, 6); }
    for (let x = 60; x < FW; x += 260 + r() * 100) { f.fillStyle = 'rgba(255,140,50,.14)'; f.beginPath(); f.arc(x, 130, 70 + r() * 20, 0, TAU); f.fill(); }
    c.fillStyle = lg(c, 0, -PAD, 0, FY, [[0, '#0a0a0e'], [.5, '#191c24'], [1, '#262a33']]); c.fillRect(0, -PAD, W, FY + PAD + 80);
    for (let y = 8; y < FY; y += 52) for (let x = 0; x < W; x += 74) { c.fillStyle = 'rgba(255,255,255,.035)'; c.fillRect(x + 2, y + 2, 70, 48); c.strokeStyle = 'rgba(0,0,0,.45)'; c.lineWidth = 1.5; c.strokeRect(x + 2, y + 2, 70, 48); c.fillStyle = 'rgba(0,0,0,.5)'; for (const [rx, ry] of [[6, 6], [66, 6], [6, 46], [66, 46]]) { c.beginPath(); c.arc(x + rx, y + ry, 1.5, 0, TAU); c.fill(); } }
    for (let x = 100; x < W; x += 340) { c.fillStyle = '#0c0d11'; c.fillRect(x - 9, -PAD, 18, FY + PAD); c.fillStyle = 'rgba(255,255,255,.07)'; c.fillRect(x - 9, -PAD, 3, FY + PAD); c.save(); c.strokeStyle = '#0c0d11'; c.lineWidth = 6; c.beginPath(); c.moveTo(x + 9, 20); c.lineTo(x + 340 - 9, FY - 20); c.moveTo(x + 340 - 9, 20); c.lineTo(x + 9, FY - 20); c.globalAlpha = .55; c.stroke(); c.restore(); }
    pipeH(c, 0, W, 34, 12, ['#4a3a24', '#8a6a3a', '#2a2014']);
    for (let x = 180 + r() * 100; x < W - 100; x += 260 + r() * 140) {
      const k = Math.floor(r() * 4);
      if (k === 0) S.dyn.push({ t: 'gear', x, y: 120 + r() * 30, r: 40 + r() * 28, sp: (r() < .5 ? -1 : 1) * (.3 + r() * .4), col: '#3d4048' });
      else if (k === 1) { S.dyn.push({ t: 'conv', x: x - 90, y: 166, w: 180 }); }
      else if (k === 2) { S.dyn.push({ t: 'warn', x, y: 62, ph: r() * 6 }); light(S, x, 66, 130, '#ff3a2a', 4, .6); }
      else { c.fillStyle = '#16171c'; c.fillRect(x - 22, 70, 44, FY - 70); c.fillStyle = '#2a2d36'; c.fillRect(x - 18, 74, 36, 60); S.dyn.push({ t: 'steam', x, y: FY - 6, ph: r() * 5 }); }
    }
    c.fillStyle = lg(c, 0, FY, 0, H, [[0, '#454a55'], [.12, '#2a2d36'], [1, '#101116']]); c.fillRect(0, FY, W, H - FY);
    c.fillStyle = 'rgba(255,255,255,.18)'; c.fillRect(0, FY, W, 2);
    c.fillStyle = 'rgba(0,0,0,.35)'; for (let x = 0; x < W; x += 9) c.fillRect(x, FY + 4, 3, H - FY);
    for (let x = 0; x < W; x += 40) { c.fillStyle = (x / 40) % 2 ? '#d9a21e' : '#1a1a1a'; c.beginPath(); c.moveTo(x, H); c.lineTo(x + 20, H); c.lineTo(x + 30, H - 8); c.lineTo(x + 10, H - 8); c.fill(); }
    vignetteEdges(c, 0, -PAD, W, H + PAD, .28);
  };
  B.lab = function (S) {
    const c = S.nc, W = S.W, FY = S.FY, r = S.r, H = S.H;
    c.fillStyle = lg(c, 0, -PAD, 0, FY, [[0, '#050a14'], [.5, '#0f1b2e'], [1, '#1b2e48']]); c.fillRect(0, -PAD, W, H + PAD);
    for (let x = 0; x < W; x += 90) { c.strokeStyle = 'rgba(120,200,255,.08)'; c.lineWidth = 1; c.strokeRect(x + 3, 24, 84, FY - 34); c.fillStyle = 'rgba(255,255,255,.02)'; c.fillRect(x + 3, 24, 84, FY - 34); }
    c.fillStyle = '#060b14'; c.fillRect(0, -PAD, W, PAD + 22); for (let x = 60; x < W; x += 260) { c.fillStyle = '#d8f3ff'; c.fillRect(x, 16, 110, 4); light(S, x + 55, 22, 170, '#9fdcff', .3, .9); beam(c, x + 55, 20, 110, 220, FY - 20, 'rgba(160,220,255,.55)', .07); }
    c.fillStyle = 'rgba(63,208,255,.55)'; c.fillRect(0, FY - 106, W, 2); c.fillStyle = 'rgba(63,208,255,.15)'; c.fillRect(0, FY - 108, W, 6);
    for (let x = 130 + r() * 80; x < W - 90; x += 220 + r() * 140) {
      const k = Math.floor(r() * 4);
      if (k === 0) { c.fillStyle = '#04070d'; c.fillRect(x - 28, 60, 56, FY - 70); c.fillStyle = 'rgba(80,190,255,.1)'; c.fillRect(x - 24, 64, 48, FY - 78); S.dyn.push({ t: 'tube', x, y: FY - 14, h: FY - 90, c: ['#3fd0ff', '#5cff9a', '#b57aff'][Math.floor(r() * 3)] }); light(S, x, FY - 80, 100, '#4fd0ff', .4, .5); }
      else if (k === 1) { c.fillStyle = '#0a1018'; c.fillRect(x - 30, 70, 60, 42); c.strokeStyle = '#2a4a6a'; c.lineWidth = 2; c.strokeRect(x - 30, 70, 60, 42); S.dyn.push({ t: 'blink', x: x - 18, y: 82, c: '#5cff9a', ph: r() * 6 }, { t: 'blink', x, y: 82, c: '#3fd0ff', ph: r() * 6 }, { t: 'blink', x: x + 18, y: 82, c: '#ff5a5a', ph: r() * 6 }); c.fillStyle = '#16314a'; c.fillRect(x - 24, 92, 48, 14); }
      else if (k === 2) { c.fillStyle = '#0b1320'; c.fillRect(x - 40, FY - 40, 80, 40); c.fillStyle = '#13243a'; c.fillRect(x - 40, FY - 40, 80, 5); c.fillStyle = 'rgba(100,220,255,.5)'; c.fillRect(x - 30, FY - 62, 22, 22); c.fillStyle = '#fff3'; c.beginPath(); c.arc(x + 14, FY - 52, 8, 0, TAU); c.fill(); }
      else { c.strokeStyle = '#1b2f48'; c.lineWidth = 7; c.beginPath(); c.moveTo(x - 60, 40); c.bezierCurveTo(x - 20, 100, x + 20, 20, x + 60, 70); c.stroke(); c.strokeStyle = '#3fd0ff55'; c.lineWidth = 2; c.stroke(); }
    }
    c.fillStyle = lg(c, 0, FY, 0, H, [[0, '#1c2d44'], [.1, '#0e1a2b'], [1, '#050a12']]); c.fillRect(0, FY, W, H - FY);
    c.fillStyle = 'rgba(160,220,255,.4)'; c.fillRect(0, FY, W, 2); for (let x = 0; x < W; x += 60) { c.fillStyle = 'rgba(160,220,255,.08)'; c.fillRect(x, FY + 2, 1, H - FY); }
    c.fillStyle = lg(c, 0, FY, 0, H, [[0, 'rgba(120,200,255,.2)'], [1, 'rgba(120,200,255,0)']]); c.fillRect(0, FY + 2, W, 30);
    vignetteEdges(c, 0, -PAD, W, H + PAD, .22);
  };
  B.temple = function (S) {
    const c = S.nc, W = S.W, FY = S.FY, r = S.r, H = S.H;
    blocks(c, 0, -PAD, W, FY + PAD, 54, 28, '#2a2f26', r);
    c.fillStyle = lg(c, 0, -PAD, 0, FY, [[0, 'rgba(0,0,0,.8)'], [.45, 'rgba(0,0,0,.1)'], [1, 'rgba(0,0,0,.25)']]); c.fillRect(0, -PAD, W, FY + PAD);
    for (let i = 0; i < 70; i++) { c.fillStyle = 'rgba(60,120,40,' + (.1 + r() * .15) + ')'; c.beginPath(); c.ellipse(r() * W, r() * FY, 6 + r() * 30, 4 + r() * 12, 0, 0, TAU); c.fill(); }
    c.fillStyle = '#0c0e0a'; c.fillRect(0, 70, W, 26); c.fillStyle = '#1d2418'; c.fillRect(0, 72, W, 22);
    for (let x = 14; x < W; x += 42) U.glyph(c, U.GLYPHS[Math.floor(r() * U.GLYPHS.length)], x + 14, 83, 14, 'rgba(200,170,90,.35)', 1.2);
    for (let x = 110 + r() * 60; x < W - 90; x += 230 + r() * 150) {
      const k = Math.floor(r() * 3);
      if (k === 0) { c.fillStyle = '#0a0c08'; c.fillRect(x - 38, 100, 76, FY - 100); c.fillStyle = '#12160f'; c.fillRect(x - 33, 104, 66, FY - 104); // statue
        c.fillStyle = '#34392c'; c.beginPath(); c.moveTo(x - 20, FY); c.lineTo(x - 14, 160); c.lineTo(x - 22, 140); c.lineTo(x - 30, 120); c.lineTo(x - 10, 128); c.arc(x, 128, 11, Math.PI, 0); c.lineTo(x + 10, 128); c.lineTo(x + 30, 120); c.lineTo(x + 22, 140); c.lineTo(x + 14, 160); c.lineTo(x + 20, FY); c.fill(); c.fillStyle = 'rgba(255,200,120,.06)'; c.fillRect(x - 33, 104, 66, FY - 104); }
      else if (k === 1) { c.fillStyle = '#3b2a18'; c.fillRect(x - 3, 108, 6, 30); c.fillStyle = '#15110c'; c.beginPath(); c.moveTo(x - 9, 108); c.lineTo(x + 9, 108); c.lineTo(x + 6, 118); c.lineTo(x - 6, 118); c.fill(); S.dyn.push({ t: 'flame', x, y: 102, s: 1.6 }); light(S, x, 100, 200, '#ffa83c', 1, 1); }
      else { pillar(S, x, 38, ['#1b1f18', '#3a4031', 'rgba(0,0,0,.45)'], 24); c.fillStyle = 'rgba(70,130,50,.35)'; for (let i = 0; i < 9; i++) c.fillRect(x - 19 + r() * 30, 30 + r() * 250, 6 + r() * 10, 3 + r() * 6); }
    }
    for (let x = 40; x < W; x += 80 + r() * 160) { c.strokeStyle = 'rgba(40,110,40,.8)'; c.lineWidth = 2; const L = 30 + r() * 70; c.beginPath(); c.moveTo(x, 0); c.bezierCurveTo(x + 6, L * .4, x - 6, L * .7, x + 2, L); c.stroke(); c.fillStyle = 'rgba(60,150,50,.8)'; for (let i = 0; i < 5; i++) { c.beginPath(); c.ellipse(x + (i & 1 ? 4 : -4), L * i / 5 + 6, 4, 2, 0, 0, TAU); c.fill(); } }
    c.fillStyle = lg(c, 0, FY, 0, H, [[0, '#4a4f40'], [.12, '#2a2e24'], [1, '#0e100b']]); c.fillRect(0, FY, W, H - FY);
    c.fillStyle = 'rgba(255,230,160,.25)'; c.fillRect(0, FY, W, 2); for (let x = 0; x < W; x += 80 + (x % 3) * 10) { c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(x, FY, 1.5, H - FY); }
    vignetteEdges(c, 0, -PAD, W, H + PAD, .3);
  };
  B.sky = function (S) {
    const c = S.nc, f = S.fc, W = S.W, FY = S.FY, r = S.r, H = S.H, FW = S.FW;
    f.fillStyle = lg(f, 0, -PAD, 0, H + 100, [[0, '#14245a'], [.35, '#5a4a9a'], [.65, '#f0906a'], [1, '#ffd0a0']]); f.fillRect(0, -PAD, FW, H + PAD + 120);
    f.fillStyle = rg(f, FW * .7, 160, 10, 220, [[0, 'rgba(255,240,200,.9)'], [.2, 'rgba(255,200,150,.35)'], [1, 'rgba(255,160,120,0)']]); f.fillRect(0, -PAD, FW, H + PAD + 120);
    stars(f, FW, 150, 40, r, -PAD + 40);
    S.islands = []; for (let i = 0; i < Math.ceil(FW / 330); i++) { const sp = U.mk(240, 200), sc = sp.getContext('2d'); const iw = 90 + r() * 90, ix = 120, iy = 70; // floating island sprite
      sc.fillStyle = '#3a3358'; sc.beginPath(); sc.moveTo(ix - iw, iy); sc.lineTo(ix + iw, iy); sc.lineTo(ix + iw * .5, iy + 40 + r() * 30); sc.lineTo(ix + iw * .1, iy + 90 + r() * 40); sc.lineTo(ix - iw * .4, iy + 40 + r() * 20); sc.fill();
      sc.fillStyle = '#5a7a58'; sc.fillRect(ix - iw, iy - 4, iw * 2, 8);
      if (r() < .7) { sc.fillStyle = '#2a2542'; sc.fillRect(ix - 30, iy - 50, 60, 46); for (const dx of [-36, -14, 8, 30]) sc.fillRect(ix + dx, iy - 62, 10, 14); sc.fillRect(ix - 8, iy - 84, 16, 34); sc.fillStyle = '#ffd080'; sc.fillRect(ix - 5, iy - 30, 10, 14); sc.fillRect(ix - 3, iy - 70, 6, 8); } else { sc.fillStyle = '#2f4a3a'; for (let t = 0; t < 4; t++) { const tx = ix - iw * .6 + t * iw * .4; sc.beginPath(); sc.moveTo(tx, iy); sc.lineTo(tx + 9, iy - 34); sc.lineTo(tx + 18, iy); sc.fill(); } }
      S.dyn.push({ t: 'island', far: true, x: i * 330 + r() * 120, y: 20 + r() * 150, spr: sp, amp: 4 + r() * 5, ph: r() * 9, sc: .5 + r() * .6 }); }
    for (let i = 0; i < 12; i++) S.dyn.push({ t: 'cloud', far: true, x: r() * FW, y: 60 + r() * (FY - 30), s: .6 + r() * 1.2, sp: 4 + r() * 8, a: .35 + r() * .35 });
    // near: ruined terrace
    for (let x = 100 + r() * 100; x < W - 80; x += 280 + r() * 160) { const k = Math.floor(r() * 3);
      if (k === 0) { pillar(S, x, 34, ['#4a4a62', '#8a8aa8', 'rgba(0,0,0,.3)'], 60 + r() * 60); c.fillStyle = '#3a3a52'; c.beginPath(); c.moveTo(x - 20, 80); c.lineTo(x + 24, 60); c.lineTo(x + 20, 80); c.fill(); }
      else if (k === 1) { c.strokeStyle = '#5a5a78'; c.lineWidth = 12; c.beginPath(); c.arc(x, FY, 60, Math.PI, 0); c.stroke(); c.strokeStyle = '#2a2a40'; c.lineWidth = 3; c.stroke(); }
      else { c.fillStyle = '#4a4a66'; c.fillRect(x - 26, FY - 22, 52, 22); c.fillStyle = '#6a6a88'; c.fillRect(x - 26, FY - 24, 52, 3); c.fillStyle = '#c9b06a'; c.beginPath(); c.moveTo(x, FY - 90); c.lineTo(x + 22, FY - 70); c.lineTo(x, FY - 50); c.lineTo(x - 22, FY - 70); c.fill(); S.dyn.push({ t: 'banner', x, y: FY - 90, c: '#c0505a' }); } }
    // terrace slab + underside
    c.fillStyle = lg(c, 0, FY, 0, FY + 14, [[0, '#8a8aa6'], [1, '#4a4a66']]); c.fillRect(0, FY, W, 14); c.fillStyle = 'rgba(255,255,255,.45)'; c.fillRect(0, FY, W, 2);
    for (let x = 0; x < W; x += 60 + (x % 5) * 6) { c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(x, FY, 1.5, 14); }
    c.fillStyle = '#2a2a42'; c.beginPath(); c.moveTo(0, FY + 14); for (let x = 0; x <= W; x += 40) c.lineTo(x, FY + 14 + 8 + r() * 24 + Math.sin(x * .02) * 8); c.lineTo(W, FY + 14); c.fill();
    vignetteEdges(c, 0, -PAD, W, H + PAD, .08);
    if (S.lv.bridgeFlag) S.bridge = true;
  };
  B.dream = function (S) {
    const c = S.nc, f = S.fc, W = S.W, FY = S.FY, r = S.r, H = S.H, FW = S.FW;
    f.fillStyle = lg(f, 0, -PAD, 0, H + 80, [[0, '#0a0420'], [.4, '#35125a'], [.8, '#7a2a8a'], [1, '#c05ab0']]); f.fillRect(0, -PAD, FW, H + PAD + 100);
    for (let i = 0; i < 5; i++) { f.fillStyle = rg(f, r() * FW, r() * 280, 0, 200, [[0, 'rgba(255,120,255,.18)'], [1, 'rgba(255,120,255,0)']]); f.fillRect(0, -PAD, FW, H + PAD); }
    stars(f, FW, H, 90, r, -100);
    f.strokeStyle = 'rgba(255,200,255,.15)'; f.lineWidth = 1.5; for (let i = 0; i < 4; i++) { f.beginPath(); const cx = r() * FW, cy = 20 + r() * 200; for (let a = 0; a < 40; a++) { const rr0 = 4 + a * 3, an = a * .45; f.lineTo(cx + Math.cos(an) * rr0, cy + Math.sin(an) * rr0); } f.stroke(); }
    for (let i = 0; i < Math.ceil(FW / 170); i++) S.dyn.push({ t: 'float', far: true, x: i * 170 + r() * 90, y: -10 + r() * 230, shape: Math.floor(r() * 3), s: 14 + r() * 30, ph: r() * 9, c: ['#8a4ac0', '#c04aa0', '#4a6ac0'][Math.floor(r() * 3)] });
    c.fillStyle = 'rgba(30,6,50,.35)'; c.fillRect(0, -PAD, W, FY + PAD);
    for (let x = 120 + r() * 100; x < W - 100; x += 240 + r() * 160) { const k = Math.floor(r() * 4);
      if (k === 0) { c.strokeStyle = 'rgba(220,150,255,.7)'; c.lineWidth = 5; c.beginPath(); c.moveTo(x - 40, FY); c.lineTo(x - 40, 110); c.arc(x, 110, 40, Math.PI, 0); c.lineTo(x + 40, FY); c.stroke(); c.fillStyle = rg(c, x, 150, 5, 60, [[0, 'rgba(255,220,255,.45)'], [1, 'rgba(180,80,255,.05)']]); c.fillRect(x - 38, 70, 76, FY - 70); }
      else if (k === 1) S.dyn.push({ t: 'eye', x, y: 70 + r() * 80, s: 1 + r() * .6, ph: r() * 9 });
      else if (k === 2) { c.strokeStyle = 'rgba(255,170,255,.5)'; c.lineWidth = 2; for (let i = 0; i < 6; i++) { c.beginPath(); c.moveTo(x - 50 + i * 16, FY); c.lineTo(x - 50 + i * 16 + 16, FY - 14 * (i + 1)); c.lineTo(x - 50 + i * 16 + 32, FY - 14 * (i + 1)); c.stroke(); } }
      else { S.dyn.push({ t: 'rune', x, y: 90 + r() * 90, s: 22 + r() * 16, c: '#ffb0ff', g: U.GLYPHS[Math.floor(r() * 20)], ph: r() * 9 }); } }
    for (let x = 0; x < W; x += 24) { const y0 = FY + Math.sin(x * .03) * 4; c.fillStyle = ((x / 24) | 0) % 2 ? 'rgba(200,120,255,.35)' : 'rgba(90,30,150,.5)'; c.fillRect(x, y0, 24, H - y0); }
    c.fillStyle = lg(c, 0, FY - 4, 0, H, [[0, 'rgba(255,200,255,.5)'], [.1, 'rgba(120,40,160,.1)'], [1, 'rgba(0,0,0,.6)']]); c.fillRect(0, FY - 4, W, H - FY + 4);
    vignetteEdges(c, 0, -PAD, W, H + PAD, .2);
  };
  B.space = function (S) {
    const c = S.nc, f = S.fc, W = S.W, FY = S.FY, r = S.r, H = S.H, FW = S.FW;
    f.fillStyle = '#02040a'; f.fillRect(0, -PAD, FW, H + PAD + 100); stars(f, FW, H + 300, 300, r, -PAD);
    f.fillStyle = rg(f, FW * .62, 150, 10, 190, [[0, '#7ac0ff'], [.45, '#2a6ac0'], [.8, '#0e2a6a'], [1, '#040a1a']]); f.beginPath(); f.arc(FW * .62, 150, 190, 0, TAU); f.fill();
    f.fillStyle = 'rgba(255,255,255,.35)'; for (let i = 0; i < 9; i++) { f.beginPath(); f.ellipse(FW * .62 + (r() - .5) * 200, 150 + (r() - .5) * 200, 20 + r() * 40, 5 + r() * 8, r(), 0, TAU); f.fill(); }
    f.fillStyle = '#9aa'; f.beginPath(); f.arc(FW * .2, 90, 22, 0, TAU); f.fill();
    c.fillStyle = lg(c, 0, -PAD, 0, FY, [[0, '#070d18'], [.5, '#111c2e'], [1, '#1b2a42']]); c.fillRect(0, -PAD, W, H + PAD);
    for (let x = 0; x < W; x += 110) { c.strokeStyle = 'rgba(0,0,0,.5)'; c.lineWidth = 2; c.strokeRect(x, 0, 110, FY); c.fillStyle = 'rgba(255,255,255,.03)'; c.fillRect(x + 2, 2, 106, FY - 4); }
    for (let x = 90 + r() * 60; x < W - 160; x += 330 + r() * 160) { const ww = 150 + r() * 60; c.globalCompositeOperation = 'destination-out'; U.rr(c, x - ww / 2, 36, ww, 150, 12); c.fill(); c.globalCompositeOperation = 'source-over'; c.strokeStyle = '#2a3a55'; c.lineWidth = 7; U.rr(c, x - ww / 2, 36, ww, 150, 12); c.stroke(); c.strokeStyle = '#06101e'; c.lineWidth = 2; U.rr(c, x - ww / 2 - 4, 32, ww + 8, 158, 14); c.stroke(); c.fillStyle = 'rgba(160,220,255,.05)'; c.fillRect(x - ww / 2, 40, 14, 140); S.win = S.win || []; S.win.push(x); light(S, x, 140, 180, '#7ac0ff', 0, .4); }
    c.fillStyle = '#05080f'; c.fillRect(0, -PAD, W, PAD + 18); c.fillStyle = 'rgba(90,184,255,.7)'; c.fillRect(0, 14, W, 2);
    for (let x = 60; x < W; x += 140 + r() * 70) { if (r() < .5) { c.fillStyle = '#0a1220'; c.fillRect(x, FY - 64, 54, 64); c.fillStyle = '#1b3050'; c.fillRect(x + 4, FY - 60, 46, 28); S.dyn.push({ t: 'blink', x: x + 12, y: FY - 20, c: '#5cff9a', ph: r() * 6 }, { t: 'blink', x: x + 27, y: FY - 20, c: '#ffb43a', ph: r() * 6 }, { t: 'blink', x: x + 42, y: FY - 20, c: '#5ab8ff', ph: r() * 6 }); } else { c.strokeStyle = '#26364f'; c.lineWidth = 6; c.beginPath(); c.moveTo(x, 20); c.lineTo(x, FY - 60); c.stroke(); } }
    c.fillStyle = lg(c, 0, FY, 0, H, [[0, '#3a4a66'], [.1, '#18223a'], [1, '#080c18']]); c.fillRect(0, FY, W, H - FY);
    c.fillStyle = 'rgba(120,200,255,.5)'; c.fillRect(0, FY, W, 2); for (let x = 0; x < W; x += 70) { c.fillStyle = 'rgba(120,200,255,.12)'; c.fillRect(x, FY + 20, 34, 3); c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(x, FY, 1, H - FY); }
    vignetteEdges(c, 0, -PAD, W, H + PAD, .25);
  };
  B.final = function (S) {
    const c = S.nc, W = S.W, FY = S.FY, r = S.r, H = S.H;
    blocks(c, 0, -PAD, W, FY + PAD, 60, 30, '#1a1214', r);
    c.fillStyle = lg(c, 0, -PAD, 0, FY, [[0, 'rgba(0,0,0,.92)'], [.5, 'rgba(0,0,0,.3)'], [1, 'rgba(60,0,0,.3)']]); c.fillRect(0, -PAD, W, FY + PAD);
    const cx = S.lv.ringX || W * .5; S.dyn.push({ t: 'ring', x: cx, y: 150, r: 150, sp: .15, c: '#ff2a3a' });
    for (let x = 80; x < W; x += 190 + r() * 90) { if (Math.abs(x - cx) < 170) continue; pillar(S, x, 44, ['#120c0e', '#2c1f22', 'rgba(0,0,0,.5)'], 10); S.dyn.push({ t: 'rune', x, y: 100 + r() * 100, s: 20, c: '#ff3a4a', g: U.GLYPHS[Math.floor(r() * 20)], ph: r() * 9 }); }
    for (let x = 60 + r() * 100; x < W; x += 260 + r() * 120) { beam(c, x, -PAD, 30, 140, FY + PAD, 'rgba(255,140,120,.6)', .06); }
    c.fillStyle = lg(c, 0, FY, 0, H, [[0, '#2a1c1f'], [.1, '#150d0f'], [1, '#050203']]); c.fillRect(0, FY, W, H - FY);
    c.strokeStyle = 'rgba(255,40,60,.5)'; c.lineWidth = 1.4; for (let i = 0; i < 24; i++) { c.beginPath(); let x = r() * W, y = FY + 2; c.moveTo(x, y); for (let k = 0; k < 4; k++) { x += (r() - .5) * 30; y += 4 + r() * 8; c.lineTo(x, Math.min(H, y)); } c.stroke(); }
    c.fillStyle = 'rgba(255,90,90,.3)'; c.fillRect(0, FY, W, 2);
    vignetteEdges(c, 0, -PAD, W, H + PAD, .4);
  };
  /* ---------- build + draw ---------- */
  const Scenery = TLR.Scenery = {
    TH, PAD,
    build(lv) {
      const th = TH[lv.theme], W = lv.w, H = lv.h || 360, FY = H - 60, cs = 1.5, pf = th.pf;
      const near = U.mk(W * cs, (H + PAD) * cs), nc = near.getContext('2d'); nc.scale(cs, cs); nc.translate(0, PAD);
      const FW = Math.ceil(W * pf + 1000); let far = null, fc = null;
      if (pf > 0) { far = U.mk(FW * cs, (H + PAD) * cs); fc = far.getContext('2d'); fc.scale(cs, cs); fc.translate(0, PAD); }
      const S = { nc, fc, W, H, FY, FW, r: U.rnd(U.hash(lv.id)), lv, th, dyn: [], lights: [], PAD };
      B[lv.theme](S);
      return { near, far, FW, pf, cs, dyn: S.dyn, lights: S.lights, th, H, FY, win: S.win };
    },
    /* animated elements */
    drawDyn(c, d, t, bg, lvState) {
      switch (d.t) {
        case 'flame': { const s = d.s || 1, fl = Math.sin(t * 17 + d.x) * .5 + Math.sin(t * 29 + d.x * 2) * .5; c.fillStyle = 'rgba(255,170,60,.9)'; c.beginPath(); c.moveTo(d.x - 3 * s, d.y); c.quadraticCurveTo(d.x - 3 * s, d.y - 6 * s, d.x + fl * s, d.y - 12 * s - fl * 2); c.quadraticCurveTo(d.x + 3 * s, d.y - 6 * s, d.x + 3 * s, d.y); c.fill(); c.fillStyle = 'rgba(255,240,170,.95)'; c.beginPath(); c.ellipse(d.x, d.y - 3 * s, 1.5 * s, 4 * s, 0, 0, TAU); c.fill(); break; }
        case 'neon': { const on = (Math.sin(t * 7 + d.ph) > -.8 || (Math.floor(t * 5 + d.ph) % 9 === 0 ? false : true)) ? 1 : .25; const fl = lvState && lvState.power === false ? .15 : on; c.save(); c.globalAlpha = fl; c.shadowColor = d.c; c.shadowBlur = 14; c.strokeStyle = d.c; c.lineWidth = 2.5; U.rr(c, d.x - d.w / 2, d.y, d.w, d.h, 6); c.stroke(); c.font = 'bold 13px sans-serif'; c.textAlign = 'center'; c.fillStyle = d.c; c.fillText(d.txt, d.x, d.y + 16); c.restore(); break; }
        case 'lamp': { const on = !d.broken || Math.sin(t * 13 + d.ph) > .4 && Math.sin(t * 3.1 + d.ph) > -.3; if (on) { c.fillStyle = 'rgba(255,230,160,.35)'; c.beginPath(); c.arc(d.x, d.y, 11, 0, TAU); c.fill(); c.fillStyle = '#fff2c8'; c.beginPath(); c.arc(d.x, d.y, 3, 0, TAU); c.fill(); } break; }
        case 'gear': { c.save(); c.translate(d.x, d.y); c.rotate(t * d.sp); c.fillStyle = d.col; c.beginPath(); const n = 14; for (let i = 0; i < n * 2; i++) { const a = i * Math.PI / n, r = i % 2 ? d.r * .86 : d.r; c.lineTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.fill(); c.fillStyle = '#1b1d22'; c.beginPath(); c.arc(0, 0, d.r * .6, 0, TAU); c.fill(); c.fillStyle = d.col; for (let i = 0; i < 5; i++) { c.save(); c.rotate(i * TAU / 5); c.fillRect(-4, 0, 8, d.r * .6); c.restore(); } c.beginPath(); c.arc(0, 0, d.r * .15, 0, TAU); c.fill(); c.restore(); break; }
        case 'conv': { c.fillStyle = '#16181d'; c.fillRect(d.x, d.y, d.w, 10); c.fillStyle = '#3a3d46'; const off = (t * 30) % 16; for (let x = d.x - 16 + off; x < d.x + d.w; x += 16) if (x >= d.x) c.fillRect(x, d.y + 2, 8, 6); c.fillStyle = '#0c0d10'; c.beginPath(); c.arc(d.x, d.y + 5, 7, 0, TAU); c.arc(d.x + d.w, d.y + 5, 7, 0, TAU); c.fill(); break; }
        case 'steam': { for (let i = 0; i < 5; i++) { const p = ((t * .5 + d.ph + i * .2) % 1), a = (1 - p) * .35; c.fillStyle = 'rgba(210,220,230,' + a + ')'; c.beginPath(); c.arc(d.x + Math.sin(p * 6 + i) * 8, d.y - p * 70, 6 + p * 16, 0, TAU); c.fill(); } break; }
        case 'warn': { const on = Math.sin(t * 5 + d.ph) > 0; c.fillStyle = '#2a0a08'; c.fillRect(d.x - 6, d.y - 6, 12, 14); c.fillStyle = on ? '#ff3a2a' : '#4a1410'; c.beginPath(); c.arc(d.x, d.y, 7, Math.PI, 0); c.fill(); if (on) { c.fillStyle = 'rgba(255,60,40,.2)'; c.beginPath(); c.arc(d.x, d.y, 28, 0, TAU); c.fill(); } break; }
        case 'tube': { c.fillStyle = d.c; c.globalAlpha = .28; c.fillRect(d.x - 20, d.y - d.h + 20, 40, d.h - 20); c.globalAlpha = .9; for (let i = 0; i < 6; i++) { const p = (t * .35 + i * .17 + d.x) % 1; c.fillStyle = 'rgba(255,255,255,' + (.5 - p * .4) + ')'; c.beginPath(); c.arc(d.x + Math.sin(t + i * 2) * 10, d.y - p * (d.h - 30), 2 + (i % 3), 0, TAU); c.fill(); } c.globalAlpha = 1; break; }
        case 'blink': { const on = Math.sin(t * 3 + d.ph * 2) > -.2; c.fillStyle = on ? d.c : 'rgba(255,255,255,.1)'; c.beginPath(); c.arc(d.x, d.y, 2.5, 0, TAU); c.fill(); if (on) { c.globalAlpha = .25; c.beginPath(); c.arc(d.x, d.y, 7, 0, TAU); c.fill(); c.globalAlpha = 1; } break; }
        case 'drip': { const p = (t * .8 + d.ph) % 2; if (p < 1) { c.fillStyle = 'rgba(150,255,190,.8)'; c.beginPath(); c.arc(d.x, d.y + p * p * 100, 2, 0, TAU); c.fill(); } break; }
        case 'water': { const lvl = lvState && lvState.water != null ? lvState.water : 0; const y0 = d.y0 + lvl; c.fillStyle = lg(c, 0, y0, 0, d.y1, [[0, '#0f5a3e'], [1, '#04140e']]); c.fillRect(d.x0, y0, d.x1 - d.x0, d.y1 - y0 + 30); c.strokeStyle = 'rgba(160,255,200,.28)'; c.lineWidth = 1.2; for (let k = 0; k < 3; k++) { c.beginPath(); for (let x = d.x0; x <= d.x1; x += 12) { const y = y0 + 3 + k * 9 + Math.sin(x * .05 + t * (1.2 + k * .4) + k) * 1.8; x === d.x0 ? c.moveTo(x, y) : c.lineTo(x, y); } c.stroke(); } c.fillStyle = 'rgba(180,255,210,.12)'; c.fillRect(d.x0, y0, d.x1 - d.x0, 2); break; }
        case 'cloud': { const w = bg ? bg.FW : 2000; let x = ((d.x + t * d.sp) % (w + 400)) - 200; c.fillStyle = 'rgba(255,230,240,' + d.a + ')'; for (const [dx, dy, r] of [[0, 0, 26], [28, -8, 32], [60, 0, 26], [30, 8, 24]]) { c.beginPath(); c.arc(x + dx * d.s, d.y + dy * d.s, r * d.s, 0, TAU); c.fill(); } break; }
        case 'island': { const yy = d.y + Math.sin(t * .6 + d.ph) * d.amp; c.drawImage(d.spr, d.x, yy, 240 * d.sc, 200 * d.sc); break; }
        case 'banner': { c.fillStyle = d.c; c.beginPath(); c.moveTo(d.x, d.y); for (let i = 0; i <= 10; i++) c.lineTo(d.x + i * 3, d.y + Math.sin(t * 3 + i * .5) * 3 * i / 10); for (let i = 10; i >= 0; i--) c.lineTo(d.x + i * 3, d.y + 22 + Math.sin(t * 3 + i * .5) * 3 * i / 10); c.fill(); c.fillStyle = '#4a3a22'; c.fillRect(d.x - 1, d.y - 3, 2, 40); break; }
        case 'portal': { const s = d.r; c.save(); c.translate(d.x, d.y); for (let i = 0; i < 4; i++) { c.rotate(t * (.6 + i * .2) * (i % 2 ? -1 : 1)); c.strokeStyle = d.c; c.globalAlpha = .7 - i * .12; c.lineWidth = 3 - i * .5; c.beginPath(); c.ellipse(0, 0, s * (1 - i * .18), s * (1.35 - i * .22), 0, 0, TAU * .8); c.stroke(); } c.restore(); break; }
        case 'rune': { const a = .35 + .5 * Math.max(0, Math.sin(t * 1.4 + d.ph)); c.save(); c.globalAlpha = a; c.shadowColor = d.c; c.shadowBlur = 14; U.glyph(c, d.g, d.x, d.y, d.s, d.c, 2); c.restore(); break; }
        case 'ring': { c.save(); c.translate(d.x, d.y); for (let i = 0; i < 4; i++) { const rr0 = d.r * (1 - i * .2); c.save(); c.rotate(t * d.sp * (i % 2 ? -1 : 1) * (1 + i * .3)); c.strokeStyle = 'rgba(255,50,70,' + (.55 - i * .08) + ')'; c.lineWidth = 6 - i; c.beginPath(); c.arc(0, 0, rr0, 0, TAU); c.stroke(); c.fillStyle = d.c; for (let k = 0; k < 12 + i * 4; k++) { const a = k * TAU / (12 + i * 4); c.globalAlpha = .4 + .4 * Math.sin(t * 2 + k + i); c.fillRect(Math.cos(a) * rr0 - 2, Math.sin(a) * rr0 - 5, 4, 10); } c.globalAlpha = 1; c.restore(); } c.fillStyle = rg(c, 0, 0, 2, d.r * .5, [[0, 'rgba(255,60,80,.5)'], [1, 'rgba(255,60,80,0)']]); c.beginPath(); c.arc(0, 0, d.r * .5, 0, TAU); c.fill(); c.restore(); break; }
        case 'eye': { const bl = Math.sin(t * .8 + d.ph) > .96 ? .1 : 1; c.save(); c.translate(d.x, d.y); c.scale(d.s, d.s * bl); c.fillStyle = 'rgba(255,230,255,.85)'; c.beginPath(); c.moveTo(-26, 0); c.quadraticCurveTo(0, -24, 26, 0); c.quadraticCurveTo(0, 24, -26, 0); c.fill(); c.fillStyle = '#6a1a9a'; c.beginPath(); c.arc(Math.sin(t + d.ph) * 6, 0, 9, 0, TAU); c.fill(); c.fillStyle = '#000'; c.beginPath(); c.arc(Math.sin(t + d.ph) * 6, 0, 4, 0, TAU); c.fill(); c.restore(); break; }
        case 'float': { const y = d.y + Math.sin(t * .7 + d.ph) * 10; c.save(); c.translate(d.x, y); c.rotate(t * .2 + d.ph); c.strokeStyle = d.c; c.fillStyle = d.c + '44'; c.lineWidth = 2; if (d.shape === 0) { c.fillRect(-d.s / 2, -d.s / 2, d.s, d.s); c.strokeRect(-d.s / 2, -d.s / 2, d.s, d.s); } else if (d.shape === 1) { c.beginPath(); c.moveTo(0, -d.s); c.lineTo(d.s, d.s * .7); c.lineTo(-d.s, d.s * .7); c.closePath(); c.fill(); c.stroke(); } else { c.beginPath(); c.arc(0, 0, d.s * .6, 0, TAU); c.fill(); c.stroke(); } c.restore(); break; }
      }
    }
  };
  /* ---------- particles (screen space, fixed pools) ---------- */
  const N = 90, P = { x: new Float32Array(N), y: new Float32Array(N), v: new Float32Array(N), s: new Float32Array(N), z: new Float32Array(N) };
  let inited = false;
  Scenery.particles = function (c, kind, vw, vh, dt, t, camx, camy) {
    if (!inited) { for (let i = 0; i < N; i++) { P.x[i] = Math.random(); P.y[i] = Math.random(); P.v[i] = .5 + Math.random(); P.s[i] = Math.random(); P.z[i] = Math.random(); } inited = true; }
    c.save(); c.setTransform(c.getTransform());
    if (kind === 'rain') { c.strokeStyle = 'rgba(170,200,255,.35)'; c.lineWidth = 1; c.beginPath(); for (let i = 0; i < 80; i++) { P.y[i] += dt * (1.3 + P.v[i]); P.x[i] -= dt * .12; if (P.y[i] > 1) { P.y[i] = -.05; P.x[i] = Math.random() * 1.2; } const x = P.x[i] * vw, y = P.y[i] * vh; c.moveTo(x, y); c.lineTo(x - 2, y + 9 + P.v[i] * 5); } c.stroke(); }
    else if (kind === 'dust' || kind === 'spark' || kind === 'ember') {
      const col = kind === 'ember' ? '255,150,70' : kind === 'spark' ? '150,230,255' : '255,235,200';
      for (let i = 0; i < 55; i++) { P.x[i] += Math.sin(t * .3 + i) * dt * .01 + dt * (kind === 'ember' ? .01 : .004) * (P.v[i] - .7); P.y[i] -= dt * (kind === 'ember' ? .05 : .006) * P.v[i]; if (P.y[i] < -.02) { P.y[i] = 1.02; P.x[i] = Math.random(); } if (P.x[i] > 1.02) P.x[i] = -.02; if (P.x[i] < -.02) P.x[i] = 1.02; const a = (.12 + .38 * (.5 + .5 * Math.sin(t * 1.5 + i * 3))) * (kind === 'dust' ? .8 : 1); c.fillStyle = 'rgba(' + col + ',' + a + ')'; const s = .8 + P.s[i] * 1.6; c.fillRect(P.x[i] * vw, P.y[i] * vh, s, s); }
    } else if (kind === 'wind') { c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 1; c.beginPath(); for (let i = 0; i < 28; i++) { P.x[i] -= dt * (.4 + P.v[i] * .5); if (P.x[i] < -.2) { P.x[i] = 1.1; P.y[i] = Math.random(); } const x = P.x[i] * vw, y = P.y[i] * vh; c.moveTo(x, y); c.lineTo(x + 24 + P.s[i] * 30, y + Math.sin(t + i) * 2); } c.stroke(); }
    else if (kind === 'drip') { c.fillStyle = 'rgba(160,255,200,.25)'; for (let i = 0; i < 30; i++) { P.y[i] += dt * .03 * P.v[i]; if (P.y[i] > 1) { P.y[i] = 0; P.x[i] = Math.random(); } c.fillRect(P.x[i] * vw, P.y[i] * vh, 1.2, 3); } for (let i = 30; i < 50; i++) { P.x[i] += dt * .004; if (P.x[i] > 1) P.x[i] = 0; c.fillStyle = 'rgba(180,255,200,' + (.1 + .15 * Math.sin(t + i)) + ')'; c.fillRect(P.x[i] * vw, P.y[i] * vh, 1.5, 1.5); } }
    c.restore();
  };
})(window);
