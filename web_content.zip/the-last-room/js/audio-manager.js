/* THE LAST ROOM - procedural audio (WebAudio synth: music, ambience, sfx). No audio files needed -> works offline. */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {};
  let ctx = null, master, comp, an, musicG, sfxG, ambG, noiseBuf, delay, fb;
  let musicTimer = null, curMusic = -1, nextT = 0, beat = 0, ambNodes = [], ambTimer = null, curAmb = '';
  const MUS = [ // per chapter [root midi, scale, bpm, wave, mood]
    { r: 45, s: [0, 2, 3, 5, 7, 8, 10], bpm: 62, w: 'triangle', m: 'soft' },
    { r: 43, s: [0, 3, 5, 6, 7, 10], bpm: 70, w: 'sawtooth', m: 'noir' },
    { r: 40, s: [0, 1, 3, 5, 7, 8], bpm: 56, w: 'sine', m: 'drip' },
    { r: 38, s: [0, 3, 5, 7, 10], bpm: 84, w: 'square', m: 'industrial' },
    { r: 50, s: [0, 2, 4, 7, 9], bpm: 76, w: 'sine', m: 'tech' },
    { r: 41, s: [0, 2, 3, 7, 8], bpm: 58, w: 'triangle', m: 'ancient' },
    { r: 52, s: [0, 2, 4, 5, 7, 9, 11], bpm: 66, w: 'sine', m: 'airy' },
    { r: 46, s: [0, 1, 4, 6, 7, 10], bpm: 52, w: 'triangle', m: 'dream' },
    { r: 48, s: [0, 2, 3, 5, 7, 9], bpm: 64, w: 'sine', m: 'tech' },
    { r: 36, s: [0, 1, 3, 6, 7], bpm: 96, w: 'sawtooth', m: 'final' }
  ];
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
  const Audio = TLR.Audio = {
    ok() { return !!ctx; },
    init() {
      if (ctx) { this.resume(); return; }
      try {
        const AC = g.AudioContext || g.webkitAudioContext; if (!AC) return;
        ctx = new AC();
        master = ctx.createGain(); master.gain.value = 2.0;
        comp = ctx.createDynamicsCompressor(); comp.threshold.value = -16; comp.knee.value = 12; comp.ratio.value = 5; comp.attack.value = 0.004; comp.release.value = 0.2;
        const lim = ctx.createGain(); lim.gain.value = 1.15; master.connect(comp); comp.connect(lim); lim.connect(ctx.destination);
        an = ctx.createAnalyser(); an.fftSize = 1024; lim.connect(an);
        musicG = ctx.createGain(); sfxG = ctx.createGain(); ambG = ctx.createGain();
        musicG.connect(master); sfxG.connect(master); ambG.connect(sfxG);
        delay = ctx.createDelay(1.5); delay.delayTime.value = 0.42; fb = ctx.createGain(); fb.gain.value = 0.38;
        const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1800;
        delay.connect(lp); lp.connect(fb); fb.connect(delay); lp.connect(musicG);
        noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
        const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
        this.applyVolumes();
        document.addEventListener('visibilitychange', () => { if (!ctx) return; if (document.hidden) ctx.suspend(); else ctx.resume(); });
      } catch (e) { ctx = null; }
    },
    level() { if (!an) return -99; const d = new Float32Array(an.fftSize); an.getFloatTimeDomainData(d); let m = 0; for (let i = 0; i < d.length; i++) m += d[i] * d[i]; return 10 * Math.log10(m / d.length + 1e-12); },
    resume() { if (ctx && ctx.state === 'suspended' && !document.hidden) ctx.resume(); },
    applyVolumes() {
      if (!ctx) return; const S = TLR.Save.settings;
      musicG.gain.setTargetAtTime(S.music * 0.8, ctx.currentTime, 0.05);
      sfxG.gain.setTargetAtTime(S.sfx * 1.6, ctx.currentTime, 0.05);
    },
    /* ---------- primitives ---------- */
    osc(type, f, t, dur, vol, f2, dest) {
      const o = ctx.createOscillator(), gn = ctx.createGain();
      o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(Math.max(20, f2), t + dur);
      gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.02, dur / 3)); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(gn); gn.connect(dest || sfxG); o.start(t); o.stop(t + dur + 0.05); return gn;
    },
    noise(t, dur, type, f, q, vol, f2, dest) {
      const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
      const fl = ctx.createBiquadFilter(); fl.type = type; fl.frequency.setValueAtTime(f, t); if (f2) fl.frequency.exponentialRampToValueAtTime(f2, t + dur); fl.Q.value = q;
      const gn = ctx.createGain(); gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.03, dur / 3)); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      s.connect(fl); fl.connect(gn); gn.connect(dest || sfxG); s.start(t, Math.random()); s.stop(t + dur + 0.05);
    },
    tone(freq, dur, vol) { if (!ctx) return; this.osc('sine', freq, ctx.currentTime, dur || 0.4, vol || 0.25); this.osc('triangle', freq * 2, ctx.currentTime, (dur || 0.4) * 0.6, (vol || 0.25) * 0.3); },
    /* ---------- sound effects ---------- */
    sfx(n, o) {
      if (!ctx || ctx.state !== 'running') return; const t = ctx.currentTime; o = o || {};
      switch (n) {
        case 'click': this.osc('square', 880, t, 0.05, 0.08, 520); break;
        case 'step': { const m = o.mat || 'wood'; const f = { wood: 260, stone: 420, metal: 900, water: 500, cloud: 180, glass: 700 }[m] || 300; this.noise(t, 0.09, 'bandpass', f * (0.8 + Math.random() * 0.4), 1.2, m === 'metal' ? 1.0 : 0.8); if (m === 'metal') this.osc('sine', 180, t, 0.08, 0.05); break; }
        case 'jump': this.noise(t, 0.12, 'highpass', 600, 0.7, 0.22, 1800); break;
        case 'land': this.noise(t, 0.14, 'lowpass', 500, 0.8, 0.28); break;
        case 'pickup': [880, 1320, 1760].forEach((f, i) => this.osc('triangle', f, t + i * 0.06, 0.18, 0.13)); break;
        case 'key': [1320, 1760, 2093].forEach((f, i) => this.osc('sine', f, t + i * 0.07, 0.5, 0.12)); this.noise(t, 0.06, 'highpass', 5000, 1, 0.1); break;
        case 'drawer': this.noise(t, 0.28, 'lowpass', 400, 1, 0.22, 900); this.osc('sawtooth', 90, t, 0.25, 0.05, 140); break;
        case 'door': this.osc('sawtooth', 120, t, 0.7, 0.07, 70); this.osc('sawtooth', 128, t + 0.05, 0.7, 0.05, 76); this.noise(t, 0.5, 'bandpass', 700, 4, 0.08, 300); this.noise(t + 0.55, 0.15, 'lowpass', 300, 1, 0.2); break;
        case 'lock': this.noise(t, 0.04, 'highpass', 3000, 1, 0.2); this.noise(t + 0.09, 0.05, 'highpass', 2000, 1, 0.25); this.osc('square', 180, t + 0.09, 0.08, 0.06); break;
        case 'unlock': this.noise(t, 0.04, 'highpass', 3500, 1, 0.2); this.osc('triangle', 660, t + 0.08, 0.12, 0.1); this.noise(t + 0.16, 0.12, 'lowpass', 500, 1, 0.25); break;
        case 'solve': [523, 659, 784, 1047, 1319].forEach((f, i) => { this.osc('triangle', f, t + i * 0.09, 0.5, 0.14); this.osc('sine', f * 2, t + i * 0.09, 0.4, 0.05); }); break;
        case 'wrong': this.osc('sawtooth', 160, t, 0.28, 0.12, 90); this.osc('square', 150, t, 0.28, 0.06, 80); break;
        case 'machine': this.osc('sawtooth', 50, t, 1.4, 0.18, 110); this.noise(t, 1.4, 'lowpass', 300, 1, 0.3, 900); this.osc('square', 60, t + 0.5, 0.9, 0.06, 90); break;
        case 'switch': this.osc('square', 300, t, 0.05, 0.12, 200); this.noise(t + 0.05, 0.08, 'bandpass', 1200, 3, 0.2); break;
        case 'power': this.osc('sawtooth', 60, t, 0.9, 0.16, 300); this.osc('sine', 1200, t + 0.4, 0.4, 0.07, 2400); break;
        case 'shock': this.osc('triangle', 300, t, 0.25, 0.14, 900); this.osc('sine', 1800, t + 0.02, 0.2, 0.08); break;
        case 'hurt': this.osc('sawtooth', 220, t, 0.3, 0.14, 80); this.noise(t, 0.2, 'lowpass', 600, 1, 0.2); break;
        case 'read': this.noise(t, 0.2, 'highpass', 3000, 0.6, 0.12); this.noise(t + 0.12, 0.15, 'highpass', 2500, 0.6, 0.1); break;
        case 'crystal': [1568, 2093, 2637].forEach((f, i) => this.osc('sine', f, t + i * 0.08, 0.8, 0.1)); break;
        case 'portal': this.osc('sine', 200, t, 0.9, 0.16, 900); this.osc('triangle', 300, t + 0.1, 0.8, 0.08, 1300); break;
        case 'checkpoint': [660, 880].forEach((f, i) => this.osc('sine', f, t + i * 0.1, 0.4, 0.09)); break;
        case 'hint': [988, 1319].forEach((f, i) => this.osc('sine', f, t + i * 0.08, 0.3, 0.09)); break;
        case 'water': this.noise(t, 1.1, 'bandpass', 500, 2, 0.15, 1500); break;
        case 'ending': [262, 330, 392, 523, 659, 784].forEach((f, i) => this.osc('triangle', f, t + i * 0.25, 2.5, 0.12)); break;
        case 'whisper': this.noise(t, 1.4, 'bandpass', 1800, 6, 0.1, 700); this.noise(t + 0.5, 1.1, 'bandpass', 2600, 8, 0.07, 900); this.osc('sine', 70, t, 1.6, 0.07, 55); break;
        case 'beat': this.osc('sine', 62, t, 0.14, 0.4, 40); this.osc('sine', 58, t + 0.17, 0.16, 0.3, 38); break;
        case 'creak': this.osc('sawtooth', 90, t, 0.9, 0.05, 140); this.noise(t, 0.9, 'bandpass', 500, 5, 0.09, 1100); break;
        case 'zap': this.noise(t, 0.3, 'highpass', 2000, 0.7, 0.28, 6000); this.osc('square', 1400, t, 0.2, 0.1, 400); break;
        case 'scare': this.noise(t, 0.9, 'highpass', 900, 0.6, 0.6, 3000); this.osc('sawtooth', 110, t, 0.9, 0.3, 60); this.osc('sawtooth', 117, t, 0.9, 0.25, 63); this.osc('square', 880, t, 0.5, 0.12, 300); break;
        case 'thunder': this.noise(t, 2.2, 'lowpass', 220, 0.7, 0.5, 60); break;
      }
    },
    /* ---------- music ---------- */
    music(ch) {
      if (!ctx) return; ch = Math.max(0, Math.min(9, ch)); if (ch === curMusic) return; curMusic = ch; beat = 0; nextT = ctx.currentTime + 0.1;
      if (musicTimer) clearInterval(musicTimer);
      const cfg = MUS[ch];
      musicTimer = setInterval(() => {
        if (!ctx || ctx.state !== 'running') { nextT = ctx ? ctx.currentTime + 0.1 : 0; return; }
        while (nextT < ctx.currentTime + 0.4) { this.beatTick(cfg, nextT, beat); nextT += 60 / cfg.bpm; beat++; }
      }, 120);
    },
    beatTick(c, t, b) {
      const sc = c.s, bar = b % 16;
      const deg = i => c.r + sc[i % sc.length] + 12 * Math.floor(i / sc.length);
      if (bar === 0 || bar === 8) { // pad chord
        const root = bar === 0 ? 0 : (Math.random() < 0.5 ? 2 : 3); [0, 2, 4].forEach(k => { const f = mtof(deg(root + k) + 12); const o = this.osc(c.w === 'sawtooth' ? 'triangle' : c.w, f, t, 60 / c.bpm * 7.5, 0.05, null, musicG); });
        this.osc('sine', mtof(deg(root) - 12), t, 60 / c.bpm * 7.5, 0.14, null, musicG);
      }
      if (c.m === 'final') { if (b % 2 === 0) { this.osc('sine', 55, t, 0.3, 0.3, 40, musicG); this.osc('sine', 55, t + 0.18, 0.25, 0.2, 40, musicG); } if (b % 8 === 4) this.osc('sawtooth', mtof(c.r + 6 + 12), t, 2, 0.04, null, musicG); }
      if (c.m === 'industrial' && b % 2 === 0) this.noise(t, 0.08, 'bandpass', 200, 2, 0.12, null, musicG);
      if (c.m === 'tech' && b % 2 === 1) this.osc('square', mtof(deg((b * 3) % 7) + 24), t, 0.12, 0.025, null, musicG);
      if (c.m === 'drip' && Math.random() < 0.25) this.osc('sine', mtof(deg(Math.floor(Math.random() * 7)) + 36), t, 0.5, 0.08, null, delay);
      if (Math.random() < (c.m === 'final' ? 0.2 : 0.38)) { // sparse melody
        const n = deg(Math.floor(Math.random() * 7)) + 12 + (Math.random() < 0.3 ? 12 : 0);
        const d = this.osc(c.m === 'airy' || c.m === 'dream' ? 'sine' : 'triangle', mtof(n), t, 1.6, 0.07, null, musicG);
        this.osc('sine', mtof(n), t + 0.01, 1.6, 0.05, null, delay);
      }
    },
    stopMusic() { if (musicTimer) clearInterval(musicTimer); musicTimer = null; curMusic = -1; },
    /* ---------- ambience ---------- */
    amb(type) {
      if (!ctx || type === curAmb) return; curAmb = type; this.stopAmb();
      const mk = (ft, f, q, vol, lfo, depth) => {
        const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true; const fl = ctx.createBiquadFilter(); fl.type = ft; fl.frequency.value = f; fl.Q.value = q;
        const gn = ctx.createGain(); gn.gain.value = vol; s.connect(fl); fl.connect(gn); gn.connect(ambG); s.start();
        if (lfo) { const l = ctx.createOscillator(), lg = ctx.createGain(); l.frequency.value = lfo; lg.gain.value = depth; l.connect(lg); lg.connect(gn.gain); l.start(); ambNodes.push(l); }
        ambNodes.push(s); ambNodes.push(gn);
      };
      const hum = (f, vol, type) => { const o = ctx.createOscillator(), gn = ctx.createGain(); o.type = type || 'sine'; o.frequency.value = f; gn.gain.value = vol; o.connect(gn); gn.connect(ambG); o.start(); ambNodes.push(o); ambNodes.push(gn); };
      switch (type) {
        case 'mansion': mk('lowpass', 300, 0.5, 0.05, 0.12, 0.03); break;
        case 'city': mk('highpass', 3500, 0.5, 0.07); mk('bandpass', 900, 0.7, 0.03, 0.2, 0.01); hum(55, 0.02); break;
        case 'sewer': mk('bandpass', 600, 1.5, 0.05, 0.3, 0.025); mk('lowpass', 150, 0.5, 0.07); break;
        case 'factory': hum(48, 0.05, 'sawtooth'); mk('lowpass', 400, 0.7, 0.06, 0.5, 0.02); mk('highpass', 5000, 0.5, 0.012, 0.15, 0.01); break;
        case 'lab': hum(120, 0.015, 'triangle'); hum(60, 0.03); mk('highpass', 6000, 1, 0.006); break;
        case 'temple': mk('lowpass', 250, 0.5, 0.05, 0.08, 0.03); mk('bandpass', 1500, 3, 0.008, 0.2, 0.006); break;
        case 'sky': mk('bandpass', 700, 0.7, 0.07, 0.1, 0.04); mk('highpass', 2500, 0.5, 0.02, 0.17, 0.015); break;
        case 'dream': hum(110, 0.02, 'sine'); hum(165.5, 0.014, 'sine'); mk('bandpass', 2000, 4, 0.01, 0.07, 0.008); break;
        case 'space': hum(40, 0.06); hum(80.5, 0.02, 'triangle'); mk('lowpass', 200, 0.5, 0.03); break;
        case 'final': hum(32, 0.09); hum(48.5, 0.04, 'sawtooth'); mk('lowpass', 150, 0.6, 0.06, 0.1, 0.03); break;
      }
      ambTimer = setInterval(() => {
        if (!ctx || ctx.state !== 'running') return; const t = ctx.currentTime;
        if (type === 'sewer' && Math.random() < 0.5) this.osc('sine', 1400 + Math.random() * 600, t, 0.12, 0.05, 700, ambG);
        if (type === 'temple' && Math.random() < 0.3) this.osc('sine', 1800 + Math.random() * 500, t, 0.1, 0.04, 800, ambG);
        if (type === 'mansion' && Math.random() < 0.25) { this.osc('sawtooth', 200, t, 0.9, 0.025, 120, ambG); }
        if (type === 'city' && Math.random() < 0.12) this.sfx('thunder');
        if (type === 'factory' && Math.random() < 0.35) this.noise(t, 0.7, 'highpass', 3000, 0.7, 0.06, 1500, ambG);
      }, 2500);
    },
    stopAmb() { ambNodes.forEach(n => { try { n.stop ? n.stop() : n.disconnect(); } catch (e) {} }); ambNodes = []; if (ambTimer) clearInterval(ambTimer); ambTimer = null; },
    stopAmbience() { this.stopAmb(); curAmb = ''; }
  };
})(window);
