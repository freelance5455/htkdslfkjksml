/* THE LAST ROOM - game core: loop, level runtime, camera, interaction engine, lighting, rendering, progression */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {}, U = TLR.U, TAU = U.TAU, Save = TLR.Save, Inv = TLR.Inv, Ph = TLR.Physics, Sc = TLR.Scenery, A = () => TLR.Audio, UI = () => TLR.UI;
  const G = TLR.Game = {
    mode: 'boot', t: 0, L: null, objs: [], plats: [], bg: null, cam: { x: 0, y: 0 }, flags: {}, near: null, lvState: {}, act: null, anim: 'idle', animT: 0, landT: 0, holdT: 0, qa: false, paused: false, resScale: 1, fade: 0, fadeTo: 0, locks: 0,
    p: { x: 80, y: 300, vx: 0, vy: 0, onG: true, plat: null, face: 1, crouch: false, z0: 0, z1: 1400, jbuf: 0, coy: 0 }
  };
  let cv, ctx, W = 800, H = 450, dpr = 1, scale = 1, VW = 640, VH = 360, lightCv, lctx, vig, bgCache = {}, last = 0, fpsAcc = 0, fpsN = 0, stepT = 0, lastFrame = 0;
  const flagOf = n => { if (n.indexOf('have:') === 0) { const q = n.split(':'); return Inv.count(q[1]) >= +q[2]; } return !!G.flags[n]; };
  G.flag = flagOf;
  /* ---------------- setup ---------------- */
  G.init = function () {
    cv = document.getElementById('cv'); ctx = cv.getContext('2d'); lightCv = U.mk(10, 10); lctx = lightCv.getContext('2d');
    this.cv = cv; this.resize(); addEventListener('resize', () => G.resize()); addEventListener('orientationchange', () => setTimeout(() => G.resize(), 200));
    document.addEventListener('visibilitychange', () => { if (document.hidden) { Save.save(); } });
    addEventListener('pagehide', () => Save.save());
    TLR.Input.on('interact', () => G.interact()); TLR.Input.on('inv', () => { if (G.mode === 'play' && !G.blocked()) UI().inventory(); }); TLR.Input.on('hint', () => { if (G.mode === 'play' && !G.blocked()) G.hint(); }); TLR.Input.on('pause', () => { if (G.mode === 'play' && !TLR.Puzzles.isOpen() && !UI().modalOpen()) UI().pause(); else if (G.mode === 'play') UI().closeTop(); });
    TLR.Input.on('jump', () => { G.jumpPressed = true; }); TLR.Input.on('light', () => { if (TLR.Ghost) TLR.Ghost.flash(); });
    requestAnimationFrame(G.frame);
  };
  G.resize = function () {
    dpr = Math.min(window.devicePixelRatio || 1, 2) * G.resScale; W = window.innerWidth; H = window.innerHeight;
    cv.width = Math.floor(W * dpr); cv.height = Math.floor(H * dpr); cv.style.width = W + 'px'; cv.style.height = H + 'px';
    const asp = W / H; scale = asp >= 1.6 ? H / 360 : W / 576; VW = W / scale; VH = H / scale;
    lightCv.width = Math.ceil(cv.width / 3); lightCv.height = Math.ceil(cv.height / 3);
    vig = U.mk(Math.ceil(W / 4), Math.ceil(H / 4)); const v = vig.getContext('2d'); v.fillStyle = U.rg(v, vig.width / 2, vig.height / 2, vig.height * .3, vig.width * .75, [[0, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,.65)']]); v.fillRect(0, 0, vig.width, vig.height);
    G.view = { w: VW, h: VH };
  };
  G.blocked = function () { return !!(G.locks > 0 || TLR.Puzzles.isOpen() || UI().modalOpen()); };
  /* ---------------- level loading ---------------- */
  G.loadLevel = function (id, o) {
    o = o || {}; const L = TLR.getLevel(id); if (!L) return; this.L = L; Save.data.level = id; Save.data.chapter = L.ch;
    if (o.fresh) Save.resetLevel(id);
    this.flags = Save.flags(id); this.coll = Save.collected(id); this.solved = Save.solved(id);
    this.H = L.h || 360; this.floorY = this.H - 60; this.th = Sc.TH[L.theme];
    this.objs = L.objects.map(ob => { ob._y = this.floorY - (ob.hy || 0); return ob; });
    this.plats = (L.plat || []).map(pl => ({ cx: pl.x, x0: pl.x - pl.w / 2, x1: pl.x + pl.w / 2, hy: pl.hy, top: this.floorY - pl.hy, mv: pl.mv, if: pl.if, active: true, dx: 0, dy: 0, w: pl.w }));
    const keys = Object.keys(bgCache); if (!bgCache[id]) { if (keys.length > 2) delete bgCache[keys[0]]; bgCache[id] = Sc.build(Object.assign({}, L)); }
    this.bg = bgCache[id]; this.zones = L.zones || [[0, L.w]];
    const cpx = Save.data.cp[id] || 80, p = this.p; p.x = cpx; p.y = this.floorY; p.vx = p.vy = 0; p.onG = true; p.plat = null; p.crouch = false; p.face = 1; this.setZone(cpx);
    this.cam.x = Math.max(0, Math.min(L.w - VW, p.x - VW / 2)); this.cam.y = this.floorY - VH * .72 + 60; this.clampCam(); this.act = null; this.near = null; this.lvState = { water: 0, power: true }; this.waterT = 0;
    if (o.fresh || this._lvId !== id) { this.lvDeaths = 0; this.lvT = 0; } this._lvId = id; this.mode = 'play'; this.paused = false; if (TLR.Ghost) TLR.Ghost.reset(); UI().hud(true); UI().resetSay(); UI().setObjective(this.objective()); UI().setLevelLabel(L); UI().setJumpVisible(!!(L.plat.length || L.lowG));
    A().music(L.ch - 1); A().amb(this.th.amb); Save.save();
    if (!this.qa && !Save.data.seen[id] && L.intro.length) { Save.data.seen[id] = 1; UI().say(L.intro); }
  };
  G.setZone = function (x) { const z = this.zones.find(z => x >= z[0] && x <= z[1]) || this.zones[0]; this.p.z0 = z[0]; this.p.z1 = z[1]; };
  G.objective = function () { const L = this.L; if (L.task) return TLR.taskStep(L); for (const s of L.steps) if (!flagOf(s[0])) return s; return [null, TLR.I18N.t('Go through the exit'), TLR.I18N.t('The exit door is open - walk to it and press the interact button.')]; };
  G.refresh = function () { UI().setObjective(this.objective()); if (TLR.Guide) { TLR.Guide.tt = 0; TLR.Guide.idle = 0; } Save.save(); };
  G.hint = function () { const s = this.objective(); this.beacon = 6; if (TLR.Guide) { TLR.Guide.tt = 0; TLR.Guide.idle = 0; } Save.data.hints = (Save.data.hints || 0) + 1; A().sfx('hint'); UI().toast(TLR.I18N.t('Hint: {0}', s[2] || TLR.I18N.t('Explore the room and examine everything.')), 5000); };
  G.start = function (id, fresh) { this.loadLevel(id, { fresh }); };
  /* ---------------- object helpers ---------------- */
  const vis = o => { const f = flagOf; if (o.hide && !f(o.hide)) return false; if (o.hideIf && f(o.hideIf)) return false; if (o.world && (o.world === 'b') !== !!G.flags.shift) return false; if (o.k === 'pick' && G.coll.indexOf(o.id) >= 0 && o.v === 'loose') return false; return true; };
  const isDone = o => { if (o.k === 'pick') return G.coll.indexOf(o.id) >= 0; if (o.k === 'puzzle' || o.k === 'lock') return G.solved.indexOf(o.id) >= 0; if (o.k === 'switch') return !!G.flags[o.set]; if (o.k === 'cp') return Save.data.cp[G.L.id] >= o.x - 1; return false; };
  const needOK = o => !o.need || o.need.every(flagOf);
  G.vis = vis; G.isDone = isDone;
  /* ---------------- effects & actions ---------------- */
  function say(m) { if (m) UI().toast(m, 3200); }
  G.fx = function (o) {
    if (TLR.Ghost && o.sfx === 'drawer') TLR.Ghost.noise(G.p.x, 380);
    if (o.lore && Save.data.lore.indexOf(o.lore) < 0) { Save.data.lore.push(o.lore); }
    if (o.curse && TLR.Ghost && TLR.Ghost.enabled) TLR.Ghost.curse(TLR.I18N.t(o.curseMsg || 'You hear a whisper right behind you...'));
    [].concat(o.set || []).forEach(f => { G.flags[f] = true; });
    if (o.give) [].concat(o.give).forEach(it => G.giveItem(it));
    if (o.sfx) A().sfx(o.sfx); say(o.msg); G.refresh();
  };
  G.giveItem = function (it) { if (Inv.add(it)) { A().sfx(it.type === 'key' ? 'key' : 'pickup'); UI().flashItem(it); } };
  G.playAct = function (name, dur, cb) { G.act = { name, t: 0, dur: dur || .6, cb }; };
  G.interact = function () { if (G.mode !== 'play' || G.blocked() || G.act) return; if (G.near) G.use(G.near); };
  G.use = function (o, held) {
    const p = G.p;
    if (p.hidden && o.k !== 'hide') return;
    if (o.crouch && !p.crouch && !G.qa) { say('Something is down there. Crouch (hold Down) to reach it.'); return; }
    if (!needOK(o)) { A().sfx('lock'); say(o.nm || 'Not yet.'); G.playAct('shock', .5); return; }
    switch (o.k) {
      case 'pick': if (G.coll.indexOf(o.id) >= 0) { say('Nothing more here.'); return; } G.coll.push(o.id); G.playAct('pickup', .7, () => { }); if (o.sfx === 'drawer') A().sfx('drawer'); G.fx(Object.assign({}, o, { give: o.item, msg: o.msg || TLR.I18N.t('Picked up: {0}', o.item.name) })); break;
      case 'note': A().sfx('read'); G.playAct('inspect', .5); UI().reader(o, () => { if (o.itemId) { const d = Inv.def(o.itemId); G.giveItem(d); } const m = o.msg; G.fx({ set: o.set, msg: m }); }); break;
      case 'puzzle': if (G.solved.indexOf(o.id) >= 0) { say('Already solved.'); return; } G.playAct('solve', 30); TLR.Puzzles.onWrong = () => G.playAct('shock', .5, () => G.playAct('solve', 30));
        TLR.Puzzles.open({ type: o.pz, cfg: o.cfg, title: o.title || 'Puzzle', key: G.L.id + ':' + o.id }, ok => { G.act = null; TLR.Puzzles.onWrong = null; if (ok) { G.solved.push(o.id); Save.data.prog[G.L.id + ':' + o.id] = 0; G.playAct('victory', .9); G.fx(o); } }); break;
      case 'lock': { if (G.solved.indexOf(o.id) >= 0) { say('Already done.'); return; } const n = o.n || 1; if (o.key && Inv.count(o.key) < n) { A().sfx('lock'); say(o.nm && !needOK(o) ? o.nm : (o.msgLocked || 'It will not budge. Perhaps something in your inventory fits.')); G.playAct('shock', .5); return; }
        if (o.key && o.use !== false) Inv.remove(o.key, n); G.solved.push(o.id); G.playAct('usekey', .8); A().sfx('unlock'); G.fx(o); break; }
      case 'switch': if (o.toggle) { G.flags[o.set] = !G.flags[o.set]; A().sfx('switch'); say(o.msg); G.playAct('door', .6); G.refresh(); } else { if (G.flags[o.set]) { say('Already pulled.'); return; } G.playAct('door', .6); G.fx(o); } break;
      case 'hide': if (p.hidden) { p.hidden = null; A().sfx('drawer'); } else { p.hidden = o; p.x = o.x; p.vx = 0; A().sfx('drawer'); say('You hold your breath...'); } break;
      case 'portal': A().sfx('portal'); G.beginFade(() => { p.x = o.to[0]; p.y = G.floorY - (o.to[1] || 0); p.vx = p.vy = 0; p.onG = true; p.plat = null; G.setZone(p.x); G.cam.x = p.x - VW / 2; G.clampCam(); }); break;
      case 'door': {
        if (!(o.need || []).every(flagOf)) { A().sfx('lock'); say(o.nm || 'The way is blocked. Something still needs to be done here.'); G.playAct('shock', .5); return; }
        if (o.key) { if (!Inv.has(o.key)) { A().sfx('lock'); say(o.nm || 'It is locked. You need a key.'); G.playAct('shock', .5); return; } Inv.remove(o.key); }
        G.locks++; G.playAct('door', .9, () => { }); A().sfx('door'); G.doorOpen = true; setTimeout(() => { G.locks--; G.finishLevel(); }, G.qa ? 10 : 900); break; }
    }
  };
  G.beginFade = function (mid) { if (G.qa) { mid(); return; } G.fadeTo = 1; G.fadeCb = mid; };
  G.useHeld = function (id) { // inventory "Use": apply an item to the nearest compatible object
    const o = G.objs.filter(q => vis(q) && (q.k === 'lock' || q.k === 'door') && q.key === id && Math.abs(q.x - G.p.x) < 70 && Math.abs(q._y - G.p.y) < 50)[0];
    if (!o) return false; G.use(o); return true;
  };
  G.combine = function (a, b) {
    const r = Inv.recipeFor(a, b); if (!r) return false;
    Inv.remove(r.a); Inv.remove(r.b); Inv.add(r.out); A().sfx('solve'); UI().flashItem(r.out);
    if (r.set && r.lv === G.L.id) G.flags[r.set] = true; say(r.msg || TLR.I18N.t('Created: {0}', r.out.name)); G.refresh(); return true;
  };
  /* ---------------- progression ---------------- */
  G.finishLevel = function () {
    const L = this.L, S = Save.data; if (S.completed.indexOf(L.id) < 0) S.completed.push(L.id);
    const i = TLR.levelIndex(L.id), nxt = TLR.LEVELS[i + 1], lastOfCh = !nxt || nxt.ch !== L.ch;
    if (lastOfCh && S.unlocked < L.ch + 1) S.unlocked = Math.min(10, L.ch + 1);
    const par = 140 + 55 * (L.task ? L.task.n : 4), tm = Math.round(this.lvT || 0), dth = this.lvDeaths || 0, stars = 1 + (dth === 0 ? 1 : 0) + (dth === 0 && tm <= par ? 1 : 0);
    S.stars = S.stars || {}; S.best = S.best || {}; const prevBest = S.best[L.id]; S.stars[L.id] = Math.max(S.stars[L.id] || 0, stars); if (!prevBest || tm < prevBest) S.best[L.id] = tm;
    const info = { stars, time: tm, par, deaths: dth, best: S.best[L.id], newBest: !prevBest || tm < prevBest, lore: (S.lore || []).length };
    A().sfx('unlock'); Save.save();
    const go = () => { if (!nxt) { UI().hud(false); TLR.Story.ending(() => G.toMenu()); return; } S.level = nxt.id; S.chapter = nxt.ch; delete S.cp[nxt.id]; Save.save(); if (lastOfCh) TLR.UI.chapterIntro(nxt.ch, () => G.loadLevel(nxt.id, { fresh: Save.isDone(nxt.id) })); else G.loadLevel(nxt.id, { fresh: Save.isDone(nxt.id) }); };
    if (this.qa) { this.qaDone = (this.qaDone || 0) + 1; go(); return; }
    this.doorOpen = false;
    this.mode = 'done'; if (TLR.Ghost) TLR.Ghost.fear = 0;
    UI().results(info, () => { if (lastOfCh) { this.mode = 'idle'; UI().hud(false); UI().chapterComplete(L.ch, go); } else { G.beginFade(go); } });
  };
  G.toMenu = function () { Save.save(); this.mode = 'menu'; UI().hud(false); A().music(0); A().amb('mansion'); UI().menu(); };
  G.restartLevel = function () { this.loadLevel(this.L.id, { fresh: true }); };
  G.startChapter = function (n) { const lv = TLR.LEVELS.filter(l => l.ch === n); let tgt = lv.find(l => !Save.isDone(l.id)) || lv[0]; if (n > Save.data.unlocked) return; UI().chapterIntro(n, () => G.loadLevel(tgt.id, { fresh: Save.isDone(tgt.id) })); };
  G.continueGame = function () { const id = Save.data.level; const L = TLR.getLevel(id) || TLR.LEVELS[0]; this.loadLevel(L.id); };
  G.newGame = function () { Save.newGame(); TLR.Story.opening(() => UI().chapterIntro(1, () => G.loadLevel('1-1'))); };
  /* ---------------- update ---------------- */
  G.clampCam = function () { const L = this.L, c = this.cam; c.x = Math.max(0, Math.min(L.w - VW, c.x)); const mn = -Sc.PAD + 10, mx = this.H - VH; c.y = Math.max(Math.min(mn, mx), Math.min(mx, c.y)); if (VW > L.w) c.x = (L.w - VW) / 2; };
  G.update = function (dt) {
    const p = this.p, L = this.L; this.t += dt; if (this.beacon > 0) this.beacon -= dt; if (TLR.Guide) TLR.Guide.update(dt);
    if (this.fadeTo !== this.fade) { this.fade += Math.sign(this.fadeTo - this.fade) * dt * 3.5; if (Math.abs(this.fadeTo - this.fade) < .06) { this.fade = this.fadeTo; if (this.fade === 1 && this.fadeCb) { const cb = this.fadeCb; this.fadeCb = null; cb(); this.fadeTo = 0; } } }
    if (this.mode === 'over' && TLR.Ghost) { TLR.Ghost.updateOver(dt); return; }
    if (this.mode !== 'play') return;
    if (TLR.Ghost) TLR.Ghost.update(dt); if (!this.blocked()) this.lvT = (this.lvT || 0) + dt;
    const blocked = this.blocked(); const I = TLR.Input;
    Ph.updatePlats(this.plats, this.t, this.floorY);
    this.plats.forEach(pl => { pl.active = !pl.if || flagOf(pl.if); });
    let dir = 0, run = false, crouch = false, jp = false;
    if (!blocked && !this.act && !p.hidden) { dir = (I.held('right') ? 1 : 0) - (I.held('left') ? 1 : 0); crouch = I.held('crouch'); if (dir) { this.holdT += dt; } else this.holdT = 0; run = I.held('run') || this.holdT > .5; jp = this.jumpPressed; }
    this.jumpPressed = false;
    const lowG = L.lowG && !!this.flags.lowg;
    const was = p.onG; const r = Ph.step(p, dt, { dir, run, crouch, jump: !blocked && !this.act && I.held('jump'), jumpPressed: jp && !blocked && !this.act }, { floorY: this.floorY, plats: this.plats, lowG, locked: !!this.act || blocked });
    if (r.jumped) A().sfx('jump'); if (r.landed > 260) { this.landT = .18; A().sfx('land'); }
    if (this.landT > 0) this.landT -= dt;
    // animation selection
    let name = 'idle';
    if (this.act) { name = this.act.name; this.act.t += dt; if (this.act.t >= this.act.dur) { const cb = this.act.cb; this.act = null; if (cb) cb(); } }
    if (!this.act) name = !p.onG ? 'jump' : this.landT > 0 ? 'land' : p.crouch ? 'crouch' : Math.abs(p.vx) > 150 ? 'run' : Math.abs(p.vx) > 12 ? 'walk' : 'idle';
    if (name !== this.anim) { this.anim = name; this.animT = 0; } else this.animT += dt;
    const PL = TLR.Player, fps = PL.fps(name), n = PL.frameCount(name);
    this.afr = name === 'jump' ? (p.vy < -150 ? 0 : p.vy > 150 ? 2 : 1) : PL.loops(name) ? Math.floor(this.animT * fps) % n : Math.min(n - 1, Math.floor(this.animT * fps));
    if ((name === 'walk' || name === 'run') && p.onG) { const fi = this.afr; if (fi !== this.lastFi && (fi === 0 || fi === 4)) { A().sfx('step', { mat: this.th.mat }); if (TLR.Ghost && !p.crouch) TLR.Ghost.noise(p.x, name === 'run' ? 420 : 180); } this.lastFi = fi; }
    // camera
    const tx = p.x + p.face * 50 - VW / 2, ty = p.y - VH * .66; const k = 1 - Math.pow(.0015, dt);
    this.cam.x += (tx - this.cam.x) * k; this.cam.y += (ty - this.cam.y) * k; this.clampCam();
    // water level
    if (L.waterFlag) { const target = flagOf(L.waterFlag) ? 34 : 0; this.lvState.water += (target - this.lvState.water) * Math.min(1, dt * .8); }
    if (L.powerFlag) this.lvState.power = flagOf(L.powerFlag);
    // checkpoints + nearest interactable
    let best = null, bd = 1e9;
    for (const o of this.objs) {
      if (!vis(o)) continue; const dx = Math.abs(o.x - p.x), dy = Math.abs(o._y - p.y);
      if (o.k === 'cp') { if (dx < 26 && dy < 40 && Save.data.cp[L.id] !== o.x) { Save.data.cp[L.id] = o.x; A().sfx('checkpoint'); UI().toast('Checkpoint saved', 1400); Save.save(); } continue; }
      const rng = o.k === 'door' ? 46 : (o.r || 52); if (dx < rng && dy < 52 && dx < bd) { bd = dx; best = o; }
    }
    if (best !== this.near) { this.near = best; UI().setNear(best ? this.labelOf(best) : null); }
  };
  G.labelOf = function (o) { return TLR.I18N.t(G.labelOf0(o)); };
  G.labelOf0 = function (o) { if (o.k === 'hide') return this.p.hidden ? 'Come out' : 'Hide'; if (o.k === 'door') return 'Exit'; if (o.k === 'portal') return o.lab || 'Enter'; if (o.crouch && !this.p.crouch) return 'Crouch ↓'; return o.lab || ({ pick: 'Take', note: 'Read', puzzle: 'Use', lock: 'Use item', switch: 'Pull' }[o.k] || 'Interact'); };
  /* ---------------- render ---------------- */
  function drawLight(c, x, y, r, a) { const gr = c.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(0,0,0,' + a + ')'); gr.addColorStop(.55, 'rgba(0,0,0,' + a * .55 + ')'); gr.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = gr; c.fillRect(x - r, y - r, r * 2, r * 2); }
  G.render = function () {
    const c = ctx, s = dpr * scale; c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = '#05040a'; c.fillRect(0, 0, cv.width, cv.height);
    if (this.mode === 'menu' || this.mode === 'story' || this.mode === 'idle' || !this.L) { c.setTransform(dpr, 0, 0, dpr, 0, 0); TLR.Story.draw(c, W, H, this.t, this.mode); return this.renderFade(c); }
    const L = this.L, bg = this.bg, cam = this.cam, cs = bg.cs, t = this.t, p = this.p, PAD = Sc.PAD;
    c.setTransform(s, 0, 0, s, 0, 0); if (TLR.Ghost && TLR.Ghost.shake > 0) c.translate((Math.random() - .5) * 8, (Math.random() - .5) * 8);
    if (bg.far) { const fx = Math.max(0, Math.min(bg.FW - VW, cam.x * bg.pf)); c.drawImage(bg.far, fx * cs, (cam.y + PAD) * cs, VW * cs, VH * cs, 0, 0, VW, VH); }
    else { c.fillStyle = '#0a0810'; c.fillRect(0, 0, VW, VH); }
    // far dynamic items (parallax)
    if (bg.far) { c.save(); c.translate(-Math.max(0, Math.min(bg.FW - VW, cam.x * bg.pf)), -cam.y); for (const d of bg.dyn) if (d.far) Sc.drawDyn(c, d, t, bg, this.lvState); c.restore(); }
    c.drawImage(bg.near, cam.x * cs, (cam.y + PAD) * cs, VW * cs, VH * cs, 0, 0, VW, VH);
    c.save(); c.translate(-cam.x, -cam.y);
    for (const d of bg.dyn) { if (d.far) continue; const dx = d.x == null ? d.x0 : d.x; if (dx != null && (dx < cam.x - 300 || dx > cam.x + VW + 300) && d.t !== 'water') continue; Sc.drawDyn(c, d, t, bg, this.lvState); }
    // bridge visual for levels with bridge flag
    if (L.id === '7-1' || L.id === '7-4') { const on = flagOf(L.id === '7-1' ? 'bridge' : 'open'); c.save(); c.translate(L.w - 330, this.floorY + 2); c.fillStyle = on ? '#8a6a44' : 'rgba(122,231,255,.2)'; c.fillRect(-100, 6, 200, 8); c.restore(); }
    // platforms
    for (const pl of this.plats) { if (pl.if && !pl.active) continue; const x = pl.x0, y = pl.top, w = pl.x1 - pl.x0; c.fillStyle = U.lg(c, 0, y, 0, y + 12, [[0, this.th.c1 + 'cc'], [.2, '#4a4a58'], [1, '#1c1c26']]); U.rr(c, x, y, w, 12, 3); c.fill(); c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(x + 2, y, w - 4, 1.5); if (pl.mv) { c.fillStyle = 'rgba(255,255,255,.5)'; c.fillRect(x + 4, y + 8, w - 8, 1.5); } }
    // objects
    for (const o of this.objs) {
      if (o.k === 'cp' && false) continue; if (!vis(o)) continue; if (o.x < cam.x - 120 || o.x > cam.x + VW + 120) continue;
      const done = isDone(o), st = { y: o._y, done, near: this.near === o, occ: p.hidden === o, open: o.k === 'door' && (o.need || []).every(flagOf) && (!o.key || Inv.has(o.key)), off: this.lvState.power === false };
      TLR.Props.draw(c, o, st, t);
    }
    if (this.near) { const o = this.near, yy = o._y - (o.k === 'door' ? 112 : 78) + Math.sin(t * 5) * 3; c.fillStyle = 'rgba(255,230,140,.95)'; c.beginPath(); c.moveTo(o.x - 6, yy - 8); c.lineTo(o.x + 6, yy - 8); c.lineTo(o.x, yy); c.fill(); }
    if (!p.hidden && this.mode !== 'over') TLR.Player.draw(c, p.x, p.y, this.anim, this.afr || 0, p.face, 1);
    c.restore();

    // particles
    c.save(); Sc.particles(c, this.th.part, VW, VH, 1 / 60, t); c.restore();
    // lighting
    const dk = (L.dark != null ? L.dark : this.th.dark) * (Inv.has('flashlight') ? .82 : 1);
    if (dk > .02) {
      const lc = lctx, k = 1 / 3, ls = s * k; lc.setTransform(1, 0, 0, 1, 0, 0); lc.globalCompositeOperation = 'source-over'; lc.clearRect(0, 0, lightCv.width, lightCv.height);
      lc.fillStyle = 'rgba(4,5,12,' + dk + ')'; lc.fillRect(0, 0, lightCv.width, lightCv.height); lc.globalCompositeOperation = 'destination-out'; lc.setTransform(ls, 0, 0, ls, -cam.x * ls, -cam.y * ls);
      const fl = Inv.has('flashlight'); drawLight(lc, p.x, p.y - 34, fl ? 120 : (L.blackout ? 135 : 80), .95); if (fl) drawLight(lc, p.x + p.face * 80, p.y - 30, 130, .9);
      for (const o of this.objs) if (vis(o) && o.k !== 'cp' && Math.abs(o.x - p.x) < VW * .8) drawLight(lc, o.x, o._y - 30, 46, .6);
      for (const li of bg.lights) { if (li.x < cam.x - li.r || li.x > cam.x + VW + li.r) continue; let a = .85 * li.a, rr = li.r; if (li.fl >= 3) a *= (Math.sin(t * 13 + li.x) > .2 && Math.sin(t * 3.1 + li.x) > -.3) ? 1 : .15; else if (li.fl) rr *= 1 + .05 * Math.sin(t * 11 + li.x * 3) * li.fl; if (this.lvState.power === false && li.c.charAt(0) !== '#') a *= .3; drawLight(lc, li.x, li.y, rr, Math.min(1, a)); }
      c.setTransform(1, 0, 0, 1, 0, 0); c.imageSmoothingEnabled = true; c.drawImage(lightCv, 0, 0, cv.width, cv.height);
      // coloured glow
      c.setTransform(s, 0, 0, s, -cam.x * s, -cam.y * s); c.globalCompositeOperation = 'lighter';
      for (const li of bg.lights) { if (li.x < cam.x - li.r || li.x > cam.x + VW + li.r || li.c.charAt(0) === 'r' && false) continue; c.globalAlpha = .11 * li.a; c.fillStyle = li.c; c.beginPath(); c.arc(li.x, li.y, li.r * .5, 0, TAU); c.fill(); }
      c.globalCompositeOperation = 'source-over'; c.globalAlpha = 1;
    }
    c.setTransform(1, 0, 0, 1, 0, 0); c.drawImage(vig, 0, 0, cv.width, cv.height);
    if (TLR.Ghost && TLR.Ghost.enabled) { c.setTransform(s, 0, 0, s, -cam.x * s, -cam.y * s); TLR.Ghost.draw(c, t); TLR.Ghost.drawBeam(c); TLR.Ghost.drawScreen(c, cv.width, cv.height); }
    if (TLR.Guide && !this.qa && this.mode === 'play') TLR.Guide.draw(c, s);
    this.renderFade(c);
  };
  G.renderFade = function (c) { if (this.fade > 0.01) { c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = 'rgba(0,0,0,' + Math.min(1, this.fade) + ')'; c.fillRect(0, 0, cv.width, cv.height); } };
  G.frame = function (ts) {
    requestAnimationFrame(G.frame); let dt = (ts - last) / 1000; last = ts; if (dt > .06) dt = .06; if (dt <= 0) return;
    if (!G.paused) { try { G.update(dt); G.render(); } catch (e) { console.error(e); G.errors = (G.errors || 0) + 1; } }
    if (!G.qa && G.mode === 'play') { fpsAcc += dt; fpsN++; if (fpsAcc > 2.5) { const avg = fpsAcc / fpsN; if (avg > .026 && G.resScale > .6) { G.resScale -= .15; G.resize(); } fpsAcc = 0; fpsN = 0; } }
  };
  /* ---------------- QA helper: plays the level through the real engine ---------------- */
  G.qaStep = function () {
    const L = this.L, p = this.p; if (TLR.Puzzles.isOpen() || UI().modalOpen() || this.locks > 0 || this.act && this.act.name !== 'solve') return { wait: true };
    // try crafting
    const inv = Inv.list(); for (const r of Inv.recipes) if (inv.indexOf(r.a) >= 0 && inv.indexOf(r.b) >= 0 && r.lv === L.id) { this.combine(r.a, r.b); return { did: 'combine ' + r.out.id }; }
    const req = this.objs.find(o => o.k === 'door'); const doorReady = req && (req.need || []).every(flagOf) && (!req.key || Inv.has(req.key));
    const order = this.objs.filter(o => o.k !== 'cp' && o.k !== 'hide' && o.k !== 'door' && o.k !== 'portal' && vis(o) && !isDone(o) && needOK(o) && !(o.k === 'note' && Inv.has(o.itemId)) && !(o.k === 'note' && !o.itemId && o.__seen) && !(o.k === 'switch' && o.toggle));
    for (const o of order) {
      if (o.k === 'lock' && o.key && Inv.count(o.key) < (o.n || 1)) continue; if (o.k === 'note' && !o.itemId) { if (o.__seen) continue; o.__seen = 1; }
      if (o.k === 'note' && o.itemId && Inv.has(o.itemId)) continue;
      p.x = o.x; p.y = o._y; p.crouch = !!o.crouch; this.setZone(o.x); this.use(o); return { did: o.k + ' ' + o.id };
    }
    // portals that are visible and lead to unseen zones
    const por = this.objs.find(o => o.k === 'portal' && vis(o) && !o.__used && this.zones.length > 1 && (o.to[0] > p.z1 || o.to[0] < p.z0) && (o.col == null || o.col === '#b57aff'));
    if (por) { por.__used = 1; p.x = por.x; p.y = por._y; this.setZone(por.x); this.use(por); return { did: 'portal ' + por.id }; }
    if (doorReady) { p.x = req.x; p.y = req.y || this.floorY; if (!this.zones.some(z => req.x >= z[0] && req.x <= z[1] && p.x >= z[0])) { } this.setZone(req.x); this.use(req); return { did: 'door' }; }
    // maybe the door lies in another zone: try a portal
    const any = this.objs.find(o => o.k === 'portal' && vis(o) && !o.__used2); if (any) { any.__used2 = 1; p.x = any.x; p.y = any._y; this.setZone(any.x); this.use(any); return { did: 'portal2 ' + any.id }; }
    const tg = this.objs.find(o => o.k === 'switch' && o.toggle && vis(o)); if (tg && (this.qaTog = (this.qaTog || 0) + 1) < 8 && this.qaTog !== 99) { p.x = tg.x; p.y = tg._y; this.setZone(tg.x); this.use(tg); return { did: 'toggle' }; }
    return { stuck: true, level: L.id, flags: Object.assign({}, this.flags) };
  };
})(window);
