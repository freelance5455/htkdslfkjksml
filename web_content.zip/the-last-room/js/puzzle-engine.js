/* THE LAST ROOM - reusable puzzle engine. 14 interactive puzzle types here + key/lock puzzles handled by the level engine.
   Every generated puzzle is solvable by construction (scrambles are built by reversing legal moves from the solved state). */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {}, U = TLR.U, TAU = U.TAU;
  const L10 = (...a) => TLR.I18N.t(...a);
  const h = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = typeof txt === 'string' ? L10(txt) : txt; return e; };
  const T = {};
  let cur = null;
  const A = () => TLR.Audio;
  /* ---------- helpers ---------- */
  function mkCanvas(x, w, hh) {
    const cv = h('canvas', 'pz-cv'); cv.width = w * 2; cv.height = hh * 2; cv.style.aspectRatio = w + '/' + hh; cv.style.maxWidth = w + 'px';
    const c = cv.getContext('2d'); c.scale(2, 2); x.body.appendChild(cv);
    cv.pt = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * w, (e.clientY - r.top) / r.height * hh]; };
    return [cv, c];
  }
  function glyphCv(name, size, col) { const cv = h('canvas', 'gcv'); cv.width = cv.height = size * 2; cv.style.width = cv.style.height = size + 'px'; const c = cv.getContext('2d'); c.scale(2, 2); U.glyph(c, name, size / 2, size / 2, size * .8, col || '#f3e6c4', size / 12); return cv; }
  function drawShape(c, shape, col, cx, cy, s, fill) {
    c.save(); c.translate(cx, cy); c.beginPath();
    if (shape === 'circle') c.arc(0, 0, s, 0, TAU);
    else if (shape === 'square') c.rect(-s * .85, -s * .85, s * 1.7, s * 1.7);
    else if (shape === 'triangle') { c.moveTo(0, -s); c.lineTo(s, s * .8); c.lineTo(-s, s * .8); c.closePath(); }
    else if (shape === 'diamond') { c.moveTo(0, -s * 1.1); c.lineTo(s, 0); c.lineTo(0, s * 1.1); c.lineTo(-s, 0); c.closePath(); }
    else if (shape === 'star') { for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? s * .45 : s * 1.05; c.lineTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); }
    else { for (let i = 0; i < 6; i++) { const a = i * TAU / 6; c.lineTo(Math.cos(a) * s, Math.sin(a) * s); } c.closePath(); }
    if (fill !== false) { c.fillStyle = col; c.fill(); } c.lineWidth = 2.4; c.strokeStyle = fill === false ? col : 'rgba(0,0,0,.55)'; c.stroke(); c.restore();
  }
  /* ---------- 1. NUMBER COMBINATION / PASSWORD ---------- */
  T.code = function (x) {
    const cfg = x.cfg, code = String(cfg.code).toUpperCase(), n = code.length, alpha = !!cfg.alpha;
    x.help = cfg.help || (alpha ? 'Enter the password.' : L10('Enter the {0}-digit code.', n));
    x.hints = cfg.hints || ['Look carefully at the notes and objects in this room.', L10('The code has {0} {1}. Every number you need has been left somewhere nearby.', n, L10(alpha ? 'letters' : 'digits'))];
    const wrap = h('div', 'code ' + (cfg.skin || '')); x.body.appendChild(wrap);
    const disp = []; let buf = '';
    const ok = () => { const v = alpha || !cfg.pad ? disp.map(d => d.v).join('') : buf; if (v === code) x.win(); else { x.wrong(alpha ? 'ACCESS DENIED' : 'Wrong code.'); if (cfg.pad) { buf = ''; refresh(); } } };
    const syms = alpha ? 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' : '0123456789';
    const show = (el, v) => { el.textContent = ''; if (/^\d$/.test(v) && TLR.Guide) el.appendChild(TLR.Guide.digit(v, 46)); else el.textContent = v === undefined ? '_' : v; };
    function refresh() { if (cfg.pad && !alpha) disp.forEach((d, i) => show(d.el, buf[i])); else disp.forEach(d => show(d.el, d.v)); }
    const row = h('div', 'code-row'); wrap.appendChild(row);
    for (let i = 0; i < n; i++) {
      const col = h('div', 'code-col'), d = { v: syms[0], el: h('div', 'code-d') }; show(d.el, d.v);
      if (!(cfg.pad && !alpha)) { const up = h('button', 'code-b', '▲'), dn = h('button', 'code-b', '▼'); const step = k => { const j = (syms.indexOf(d.v) + k + syms.length) % syms.length; d.v = syms[j]; show(d.el, d.v); A().sfx('click'); }; up.onclick = () => step(1); dn.onclick = () => step(-1); col.append(up, d.el, dn); } else col.append(d.el);
      disp.push(d); row.appendChild(col);
    }
    if (cfg.pad && !alpha) {
      refresh(); const pad = h('div', 'pad'); wrap.appendChild(pad);
      ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', 'OK'].forEach(k => { const b = h('button', 'pad-b' + (k === 'OK' ? ' go' : ''), /\d/.test(k) ? '' : k); if (/\d/.test(k) && TLR.Guide) b.appendChild(TLR.Guide.digit(k, 40)); b.onclick = () => { A().sfx('click'); if (k === 'C') buf = ''; else if (k === 'OK') return ok(); else if (buf.length < n) buf += k; refresh(); if (buf.length === n && k !== 'C') setTimeout(ok, 150); }; pad.appendChild(b); });
    } else { const go = h('button', 'btn go', alpha ? 'LOG IN' : 'UNLOCK'); go.onclick = ok; wrap.appendChild(go); }
    return { solve() { if (cfg.pad && !alpha) { buf = code; refresh(); } else disp.forEach((d, i) => { d.v = code[i]; show(d.el, code[i]); }); ok(); } };
  };
  /* ---------- 2. SYMBOL MATCHING ---------- */
  T.symbols = function (x) {
    const cfg = x.cfg, gl = (cfg.glyphs || U.GLYPHS.slice(0, 5)).slice(); const rnd = Math.random;
    x.help = cfg.help || 'Match every symbol with its name. Tap a symbol, then its name.';
    x.hints = cfg.hints || ['Study the shape of each symbol - the names describe what they depict.'];
    const L = U.shuffle(gl.slice(), rnd), R = U.shuffle(gl.slice(), rnd), wrap = h('div', 'sym'); x.body.appendChild(wrap);
    const lc = h('div', 'sym-col'), rc = h('div', 'sym-col'); wrap.append(lc, rc); let sel = null, done = 0; const matched = {};
    const lb = {}, rb = {};
    L.forEach(n => { const b = h('button', 'sym-b'); b.appendChild(glyphCv(n, 46, cfg.col)); b.onclick = () => { if (matched[n]) return; A().sfx('click'); sel = n; Object.values(lb).forEach(e => e.classList.remove('sel')); b.classList.add('sel'); }; lb[n] = b; lc.appendChild(b); });
    R.forEach(n => { const b = h('button', 'sym-b txt', U.GNAME[n]); b.onclick = () => { if (matched[n] || !sel) return; if (sel === n) { matched[n] = 1; lb[n].classList.add('ok'); b.classList.add('ok'); lb[n].classList.remove('sel'); sel = null; A().sfx('pickup'); if (++done === gl.length) x.win(); } else { lb[sel].classList.remove('sel'); sel = null; x.wrong('Not a match.'); } }; rb[n] = b; rc.appendChild(b); });
    return { solve() { gl.forEach(n => { matched[n] = 1; }); x.win(); } };
  };
  /* ---------- 3. HIDDEN OBJECTS ---------- */
  T.hidden = function (x) {
    const cfg = x.cfg, n = cfg.n || 4, names = (cfg.items || U.GLYPHS.slice(5, 5 + n)).slice(0, n);
    x.help = cfg.help || L10('Search the clutter. Tap the {0} hidden objects listed below.', names.length);
    x.hints = cfg.hints || ['Objects are partly covered by clutter. Look for faint outlines.', 'Tap "Reveal" to highlight one object.'];
    const W = 520, H = 290, [cv, c] = mkCanvas(x, W, H), r = U.rnd(U.hash(x.key || 'h') + 7), pal = cfg.pal || ['#2a2018', '#4a3828', '#6a5238', '#3a2a1c'];
    const pos = names.map((nm, i) => ({ nm, x: 50 + ((i + r() * .8) / names.length) * (W - 100), y: 50 + r() * (H - 100), found: false }));
    U.shuffle(pos, r);
    const clutter = [], over = [];
    for (let i = 0; i < 90; i++) clutter.push({ k: Math.floor(r() * 3), x: r() * W, y: r() * H, s: 10 + r() * 34, c: pal[Math.floor(r() * pal.length)], a: r() * 3 });
    for (let i = 0; i < 26; i++) over.push({ k: Math.floor(r() * 3), x: r() * W, y: r() * H, s: 10 + r() * 22, c: pal[Math.floor(r() * pal.length)], a: r() * 3 });
    pos.forEach(p => over.push({ k: 0, x: p.x + (r() - .5) * 26, y: p.y + (r() - .5) * 26, s: 8 + r() * 6, c: pal[1], a: 0 }));
    function shp(o, alpha) { c.save(); c.globalAlpha = alpha; c.translate(o.x, o.y); c.rotate(o.a); c.fillStyle = o.c; if (o.k === 0) { c.beginPath(); c.arc(0, 0, o.s * .6, 0, TAU); c.fill(); } else if (o.k === 1) c.fillRect(-o.s / 2, -o.s / 3, o.s, o.s * .66); else { c.beginPath(); c.moveTo(0, -o.s * .6); c.lineTo(o.s * .6, o.s * .5); c.lineTo(-o.s * .6, o.s * .5); c.fill(); } c.restore(); }
    let misses = 0, reveal = null, flash = 0;
    const list = h('div', 'hid-list'); x.body.appendChild(list); const chips = {};
    names.forEach(nm => { const ch = h('span', 'chip'); ch.appendChild(glyphCv(nm, 22)); ch.appendChild(h('b', '', U.GNAME[nm])); chips[nm] = ch; list.appendChild(ch); });
    const rv = h('button', 'btn small', 'Reveal one'); rv.onclick = () => { const p = pos.find(q => !q.found); if (p) { reveal = { p, t: 0 }; Object.assign(reveal, {}); A().sfx('hint'); } }; x.body.appendChild(rv);
    function check() { if (pos.every(p => p.found)) x.win(); }
    cv.addEventListener('pointerdown', e => { const [px, py] = cv.pt(e); let hit = pos.find(p => !p.found && Math.hypot(p.x - px, p.y - py) < 24); if (hit) { hit.found = true; chips[hit.nm].classList.add('found'); A().sfx('pickup'); check(); } else { misses++; flash = .25; A().sfx('click'); } });
    x.loop(t => {
      c.fillStyle = '#120d09'; c.fillRect(0, 0, W, H); clutter.forEach(o => shp(o, .9));
      c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(0, 0, W, H);
      pos.forEach(p => { U.glyph(c, p.nm, p.x, p.y, 30, p.found ? '#5cff8a' : 'rgba(210,190,150,.55)', 2.2); });
      over.forEach(o => shp(o, .55));
      pos.forEach(p => { if (p.found) { c.strokeStyle = '#5cff8a'; c.lineWidth = 2; c.beginPath(); c.arc(p.x, p.y, 24, 0, TAU); c.stroke(); } });
      if (reveal) { reveal.t += .016; const k = reveal.t; c.strokeStyle = 'rgba(255,230,120,' + Math.max(0, 1 - k / 2.2) + ')'; c.lineWidth = 3; c.beginPath(); c.arc(reveal.p.x, reveal.p.y, 20 + (k * 40) % 40, 0, TAU); c.stroke(); if (k > 2.2) reveal = null; }
      if (flash > 0) { flash -= .016; c.fillStyle = 'rgba(255,60,60,' + flash * .5 + ')'; c.fillRect(0, 0, W, H); }
    });
    return { solve() { pos.forEach(p => { p.found = true; }); x.win(); } };
  };
  /* ---------- 4. SLIDING BLOCKS ---------- */
  T.slide = function (x) {
    const cfg = x.cfg, n = cfg.n || 3, W = 340, [cv, c] = mkCanvas(x, W, W), N = n * n, cell = W / n;
    x.help = cfg.help || 'Slide the pieces to restore the picture. Tap a piece next to the gap.';
    x.hints = cfg.hints || ['Work row by row, top to bottom. The finished picture is a glowing emblem.', 'Solve the first row, then the first column, then repeat on the smaller square.'];
    const art = U.mk(W, W), a = art.getContext('2d'); a.fillStyle = U.rg(a, W / 2, W / 2, 10, W * .75, [[0, cfg.c1 || '#7a3aa0'], [1, '#12081c']]); a.fillRect(0, 0, W, W);
    a.strokeStyle = 'rgba(255,230,160,.85)'; a.lineWidth = 6; for (let i = 1; i <= 4; i++) { a.beginPath(); a.arc(W / 2, W / 2, i * W * .1, 0, TAU); a.stroke(); } U.glyph(a, cfg.g || 'eye', W / 2, W / 2, W * .5, '#ffe9a8', 8);
    for (let i = 0; i < 12; i++) { a.save(); a.translate(W / 2, W / 2); a.rotate(i * TAU / 12); a.fillStyle = 'rgba(255,230,160,.7)'; a.fillRect(W * .46, -3, W * .05, 6); a.restore(); }
    let grid = []; for (let i = 0; i < N; i++) grid.push(i); let blank = N - 1; const r = Math.random; let prev = -1;
    const steps = 30 + (x.d || 1) * 24;
    for (let s = 0; s < steps; s++) { const bx = blank % n, by = (blank / n) | 0, nb = []; if (bx > 0) nb.push(blank - 1); if (bx < n - 1) nb.push(blank + 1); if (by > 0) nb.push(blank - n); if (by < n - 1) nb.push(blank + n); const ch = nb.filter(q => q !== prev); const m = ch[Math.floor(r() * ch.length)]; grid[blank] = grid[m]; grid[m] = N - 1; prev = blank; blank = m; }
    if (grid.every((v, i) => v === i)) { grid[N - 2] = N - 1; grid[N - 1] = N - 2; blank = N - 2; } // (never taken in practice)
    const anim = {}; let solved = false, win = 0;
    const isSolved = () => grid.every((v, i) => v === i);
    cv.addEventListener('pointerdown', e => { if (solved) return; const [px, py] = cv.pt(e), cx = Math.floor(px / cell), cy = Math.floor(py / cell), i = cy * n + cx; const bx = blank % n, by = (blank / n) | 0; if (Math.abs(cx - bx) + Math.abs(cy - by) === 1) { anim[grid[i]] = { fx: cx, fy: cy, t: 0 }; grid[blank] = grid[i]; grid[i] = N - 1; blank = i; A().sfx('drawer'); if (isSolved()) { solved = true; setTimeout(() => x.win(), 500); } } else A().sfx('click'); });
    x.loop(t => {
      c.fillStyle = '#0a0610'; c.fillRect(0, 0, W, W);
      for (let i = 0; i < N; i++) { const id = grid[i]; if (id === N - 1 && !solved) continue; let px = (i % n) * cell, py = ((i / n) | 0) * cell; const an = anim[id]; if (an) { an.t += .09; const k = Math.min(1, an.t); const e = 1 - Math.pow(1 - k, 3); px = U.lerp(an.fx * cell, px, e); py = U.lerp(an.fy * cell, py, e); if (k >= 1) delete anim[id]; }
        const sx = (id % n) * cell, sy = ((id / n) | 0) * cell; c.drawImage(art, sx, sy, cell, cell, px + 2, py + 2, cell - 4, cell - 4); c.strokeStyle = solved ? 'rgba(255,230,160,.0)' : 'rgba(255,230,160,.5)'; c.lineWidth = 2; c.strokeRect(px + 2, py + 2, cell - 4, cell - 4); c.fillStyle = 'rgba(0,0,0,.55)'; c.font = 'bold 15px sans-serif'; c.textAlign = 'left'; c.fillText(id + 1, px + 8, py + 20); }
      if (solved) { win += .02; c.fillStyle = 'rgba(255,240,200,' + Math.max(0, .6 - win) + ')'; c.fillRect(0, 0, W, W); }
    });
    return { solve() { grid = grid.map((_, i) => i); solved = true; x.win(); } };
  };
  /* ---------- 5. MIRROR / LASER / WIND REDIRECTION ---------- */
  T.mirror = function (x) {
    const cfg = x.cfg, d = x.d || 1, GW = cfg.w || (d > 1 ? 8 : 7), GH = cfg.h || (d > 1 ? 6 : 5), CS = 60, W = GW * CS, H = GH * CS, [cv, c] = mkCanvas(x, W, H);
    const skin = cfg.skin || 'laser', col = { laser: '#ff4a5a', mirror: '#ffe9a0', wind: '#bfefff' }[skin], nm = { laser: 'mirror', mirror: 'mirror', wind: 'deflector' }[skin];
    x.help = cfg.help || L10(skin === 'wind' ? 'Tap the deflectors to flip them and guide the wind into the target on the right.' : 'Tap the mirrors to flip them and guide the beam into the target on the right.');
    x.hints = cfg.hints || [L10(skin === 'wind' ? 'Follow the wind from the source: it bends at every deflector. Flip the first one that sends it the wrong way.' : 'Follow the beam from the source: it bends at every mirror. Flip the first one that sends it the wrong way.'), 'The beam must leave the grid through the target on the right edge.'];
    const r = Math.random, M = {}; let row = Math.floor(r() * GH); const r0 = row; const cells = [];
    let colN = 1; const turns = []; let cc = 1; const k = 2 + (d > 1 ? 1 : 0) + Math.floor(r() * 2);
    const cols = []; while (cols.length < Math.min(k, GW - 3)) { const q = 1 + Math.floor(r() * (GW - 2)); if (cols.indexOf(q) < 0) cols.push(q); } cols.sort((a, b) => a - b);
    let pr = row;
    cols.forEach(q => { let nr; do { nr = Math.floor(r() * GH); } while (nr === pr); const dir = nr < pr ? 'N' : 'S'; M[pr + ',' + q] = { sol: dir === 'N' ? '/' : '\\', path: true }; M[nr + ',' + q] = { sol: dir === 'N' ? '/' : '\\', path: true }; pr = nr; });
    // second mirror of each turn: from vertical heading back to east: N->E uses '/', S->E uses '\\' (same char as first turn) - handled above
    const tr = pr;
    // decoys on cells that are not on the path
    const onPath = new Set(); { let rr = r0, c2 = 0; const ev = cols.slice(); let dirv = 'E'; const key = (a, b) => a + ',' + b; let guard = 0; let rr2 = r0, cc2 = 0, dr = 0, dc = 1; while (cc2 >= 0 && cc2 < GW && rr2 >= 0 && rr2 < GH && guard++ < 200) { onPath.add(key(rr2, cc2)); const m = M[key(rr2, cc2)]; if (m) { if (m.sol === '/') { const nd = [-dc, -dr]; dr = nd[0]; dc = nd[1]; } else { const nd = [dc, dr]; dr = nd[0]; dc = nd[1]; } } rr2 += dr; cc2 += dc; } }
    const nd = 2 + d; for (let i = 0; i < nd; i++) { const q = Math.floor(r() * GH) + ',' + (1 + Math.floor(r() * (GW - 1))); if (!onPath.has(q) && !M[q]) M[q] = { sol: r() < .5 ? '/' : '\\', path: false }; }
    Object.keys(M).forEach(q => { M[q].o = M[q].path ? (M[q].sol === '/' ? '\\' : '/') : M[q].sol; });
    function trace() { const pts = [[0, r0]]; let rr = r0, c2 = 0, dr = 0, dc = 1, hit = false, g2 = 0; while (g2++ < 300) { const m = M[rr + ',' + c2]; pts.push([c2 + .5, rr + .5]); if (m) { if (m.o === '/') { const t = dc; dc = -dr; dr = -t; } else { const t = dc; dc = dr; dr = t; } } rr += dr; c2 += dc; if (c2 < 0 || rr < 0 || rr >= GH || c2 >= GW) { pts.push([Math.max(0, Math.min(GW, c2)), Math.max(0, Math.min(GH, rr)) + (rr < 0 || rr >= GH ? 0 : .5)]); hit = (c2 >= GW && rr === tr); break; } } return { pts, hit }; }
    let solved = false, glow = 0, moved = false;
    cv.addEventListener('pointerdown', e => { if (solved) return; const [px, py] = cv.pt(e), q = Math.floor(py / CS) + ',' + Math.floor(px / CS); const m = M[q]; if (m) { m.o = m.o === '/' ? '\\' : '/'; moved = true; A().sfx('switch'); if (trace().hit) { solved = true; setTimeout(() => x.win(), 700); A().sfx('crystal'); } } });
    x.loop(t => {
      c.fillStyle = skin === 'wind' ? '#10202e' : '#0b0d16'; c.fillRect(0, 0, W, H);
      c.strokeStyle = 'rgba(255,255,255,.07)'; c.lineWidth = 1; for (let i = 0; i <= GW; i++) { c.beginPath(); c.moveTo(i * CS, 0); c.lineTo(i * CS, H); c.stroke(); } for (let j = 0; j <= GH; j++) { c.beginPath(); c.moveTo(0, j * CS); c.lineTo(W, j * CS); c.stroke(); }
      const tr2 = trace(); c.save(); c.shadowColor = col; c.shadowBlur = 12; c.strokeStyle = col; c.lineWidth = skin === 'wind' ? 5 : 3; c.setLineDash(skin === 'wind' ? [14, 8] : []); c.lineDashOffset = -t * 60; c.beginPath(); tr2.pts.forEach((p, i) => i ? c.lineTo(p[0] * CS, p[1] * CS) : c.moveTo(p[0] * CS, p[1] * CS)); c.stroke(); c.restore();
      Object.keys(M).forEach(q => { const [rr, c2] = q.split(',').map(Number), m = M[q], cx = c2 * CS + CS / 2, cy = rr * CS + CS / 2; c.save(); c.translate(cx, cy); c.fillStyle = 'rgba(255,255,255,.05)'; c.fillRect(-CS / 2 + 4, -CS / 2 + 4, CS - 8, CS - 8); c.strokeStyle = skin === 'wind' ? '#d8f4ff' : '#cfe4ff'; c.lineWidth = skin === 'wind' ? 7 : 6; c.shadowColor = '#fff'; c.shadowBlur = 8; c.lineCap = 'round'; c.beginPath(); if (m.o === '/') { c.moveTo(-18, 18); c.lineTo(18, -18); } else { c.moveTo(-18, -18); c.lineTo(18, 18); } c.stroke(); c.restore(); });
      c.fillStyle = '#2a2f40'; c.fillRect(0, r0 * CS + CS / 2 - 14, 14, 28); c.fillStyle = col; c.beginPath(); c.arc(14, r0 * CS + CS / 2, 5, 0, TAU); c.fill();
      c.strokeStyle = solved ? '#5cff8a' : col; c.lineWidth = 4; c.beginPath(); c.arc(W - 12, tr * CS + CS / 2, 14 + Math.sin(t * 5) * (solved ? 3 : 1), 0, TAU); c.stroke(); c.fillStyle = solved ? '#5cff8a' : 'rgba(255,255,255,.2)'; c.beginPath(); c.arc(W - 12, tr * CS + CS / 2, 6, 0, TAU); c.fill();
    });
    return { solve() { Object.values(M).forEach(m => { m.o = m.sol; }); if (!trace().hit) { x.wrong('(internal) unsolvable'); return; } solved = true; x.win(); } };
  };
  /* ---------- 6. ELECTRICAL CIRCUIT (power relays: pressing one toggles its neighbours) ---------- */
  T.circuit = function (x) {
    const cfg = x.cfg, d = x.d || 1, GW = cfg.w || (d > 2 ? 4 : 3), GH = cfg.h || (d > 1 ? 4 : 3), CS = 78, W = GW * CS, H = GH * CS, [cv, c] = mkCanvas(x, W, H);
    x.help = cfg.help || 'Light every node. Pressing a node also flips the nodes touching it.';
    x.hints = cfg.hints || ['Each press flips a node and its four neighbours. Pressing the same node twice cancels out.', 'Try to light one row at a time, from the top.'];
    const N = GW * GH, st = new Array(N).fill(true);
    const press = i => { const cx = i % GW, cy = (i / GW) | 0; [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([dx, dy]) => { const a = cx + dx, b = cy + dy; if (a >= 0 && b >= 0 && a < GW && b < GH) st[b * GW + a] = !st[b * GW + a]; }); };
    const hist = []; let k = 4 + d * 2; for (let i = 0; i < k; i++) { const q = Math.floor(Math.random() * N); hist.push(q); press(q); } if (st.every(v => v)) { press(0); hist.push(0); }
    let solved = false;
    cv.addEventListener('pointerdown', e => { if (solved) return; const [px, py] = cv.pt(e), i = Math.floor(py / CS) * GW + Math.floor(px / CS); press(i); A().sfx('switch'); if (st.every(v => v)) { solved = true; A().sfx('power'); setTimeout(() => x.win(), 700); } });
    const col = cfg.c || '#5ad8ff';
    x.loop(t => {
      c.fillStyle = '#071018'; c.fillRect(0, 0, W, H); c.strokeStyle = 'rgba(90,216,255,.15)'; c.lineWidth = 4;
      for (let i = 0; i < N; i++) { const cx = i % GW, cy = (i / GW) | 0; if (cx < GW - 1) { c.beginPath(); c.moveTo(cx * CS + CS / 2, cy * CS + CS / 2); c.lineTo((cx + 1) * CS + CS / 2, cy * CS + CS / 2); c.stroke(); } if (cy < GH - 1) { c.beginPath(); c.moveTo(cx * CS + CS / 2, cy * CS + CS / 2); c.lineTo(cx * CS + CS / 2, (cy + 1) * CS + CS / 2); c.stroke(); } }
      for (let i = 0; i < N; i++) { const cx = (i % GW) * CS + CS / 2, cy = ((i / GW) | 0) * CS + CS / 2, on = st[i]; c.save(); c.translate(cx, cy); c.fillStyle = '#0d1a26'; c.beginPath(); c.arc(0, 0, 28, 0, TAU); c.fill(); c.strokeStyle = on ? col : '#2a3a4a'; c.lineWidth = 3; c.stroke(); if (on) { c.shadowColor = col; c.shadowBlur = 22; c.fillStyle = col; c.beginPath(); c.arc(0, 0, 14 + Math.sin(t * 4 + i) * 1.2, 0, TAU); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.arc(-4, -4, 4, 0, TAU); c.fill(); } else { c.fillStyle = '#17222e'; c.beginPath(); c.arc(0, 0, 12, 0, TAU); c.fill(); } c.restore(); }
    });
    return { solve() { st.fill(true); solved = true; x.win(); } };
  };
  /* ---------- 7. GEAR / STATUE / VALVE ROTATION ---------- */
  T.gears = function (x) {
    const cfg = x.cfg, d = x.d || 1, n = cfg.n || 4, m = cfg.pos || 4, skin = cfg.skin || 'gear', W = 540, H = 210, [cv, c] = mkCanvas(x, W, H);
    x.help = cfg.help || (skin === 'statue' ? 'Rotate the statues so every one faces the gate (up). Turning one also turns its neighbours.' : skin === 'valve' ? 'Turn the valves until every handle points up. Neighbouring valves turn the other way.' : 'Align every gear marker to the top. Turning a gear turns its neighbours the other way.');
    x.hints = cfg.hints || ['Turning a piece moves it one step forward and its neighbours one step back.', 'Fix the pieces from left to right; the last one will fall into place with a few extra turns.'];
    const pos = new Array(n).fill(0), press = i => { pos[i] = (pos[i] + 1) % m; if (i > 0) pos[i - 1] = (pos[i - 1] + m - 1) % m; if (i < n - 1) pos[i + 1] = (pos[i + 1] + m - 1) % m; };
    let k = 3 + d * 2; for (let i = 0; i < k; i++) press(Math.floor(Math.random() * n)); if (pos.every(v => v === 0)) press(0);
    const R = Math.min(48, (W - 40) / (n * 1.9)), sp = R * 1.9, x0 = W / 2 - (n - 1) * sp / 2, vis = new Array(n).fill(0); let solved = false, taps = 0;
    pos.forEach((v, i) => vis[i] = v);
    cv.addEventListener('pointerdown', e => { if (solved) return; const [px, py] = cv.pt(e); let best = -1, bd = 1e9; for (let i = 0; i < n; i++) { const dd = Math.abs(px - (x0 + i * sp)); if (dd < bd) { bd = dd; best = i; } } if (best >= 0 && bd < sp * .62) { press(best); taps++; A().sfx('switch'); if (pos.every(v => v === 0)) { solved = true; A().sfx('machine'); setTimeout(() => x.win(), 700); } } });
    x.loop(t => {
      c.fillStyle = '#0c0e12'; c.fillRect(0, 0, W, H);
      for (let i = 0; i < n; i++) { let dv = pos[i] - vis[i]; if (dv > m / 2) dv -= m; if (dv < -m / 2) dv += m; vis[i] += dv * .18; const cx = x0 + i * sp, cy = H / 2, ang = vis[i] * TAU / m; c.save(); c.translate(cx, cy);
        if (skin === 'gear') { c.rotate(ang); c.fillStyle = '#8a7a52'; c.beginPath(); for (let q = 0; q < 24; q++) { const a = q * TAU / 24, rr = q % 2 ? R * .82 : R; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.closePath(); c.fill(); c.strokeStyle = '#2a2010'; c.lineWidth = 2; c.stroke(); c.fillStyle = '#3a3020'; c.beginPath(); c.arc(0, 0, R * .55, 0, TAU); c.fill(); c.strokeStyle = pos[i] === 0 ? '#5cff8a' : '#ffd36a'; c.lineWidth = 4; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, -R * .85); c.stroke(); c.fillStyle = '#ffd36a'; c.beginPath(); c.arc(0, -R * .8, 5, 0, TAU); c.fill(); }
        else if (skin === 'statue') { c.fillStyle = '#3a3e34'; c.beginPath(); c.arc(0, 0, R * .95, 0, TAU); c.fill(); c.strokeStyle = '#1a1c16'; c.lineWidth = 3; c.stroke(); c.rotate(ang); c.fillStyle = '#8a8c78'; c.beginPath(); c.ellipse(0, 0, R * .6, R * .42, 0, 0, TAU); c.fill(); c.stroke(); c.fillStyle = '#6a6c58'; c.beginPath(); c.arc(0, 0, R * .3, 0, TAU); c.fill(); c.fillStyle = pos[i] === 0 ? '#5cff8a' : '#ffb347'; c.beginPath(); c.moveTo(0, -R * .95); c.lineTo(R * .22, -R * .55); c.lineTo(-R * .22, -R * .55); c.closePath(); c.fill(); }
        else { c.strokeStyle = '#3a2a1c'; c.lineWidth = 8; c.beginPath(); c.arc(0, 0, R * .9, 0, TAU); c.stroke(); c.rotate(ang); c.strokeStyle = pos[i] === 0 ? '#5cff8a' : '#c24a2a'; c.lineWidth = 6; c.beginPath(); c.arc(0, 0, R * .9, 0, TAU); c.stroke(); c.lineWidth = 5; c.beginPath(); c.moveTo(0, -R * .9); c.lineTo(0, R * .9); c.moveTo(-R * .9, 0); c.lineTo(R * .9, 0); c.stroke(); c.fillStyle = '#ffd36a'; c.beginPath(); c.arc(0, -R * .9, 7, 0, TAU); c.fill(); }
        c.restore(); c.fillStyle = pos[i] === 0 ? '#5cff8a' : '#555'; c.beginPath(); c.arc(cx, H - 16, 4, 0, TAU); c.fill(); }
    });
    return { solve() { pos.fill(0); solved = true; x.win(); } };
  };
  /* ---------- 8. MEMORY SEQUENCE ---------- */
  T.memory = function (x) {
    const cfg = x.cfg, np = cfg.pads || 4, len = cfg.len || 4, cols = ['#e85a5a', '#5ab0e8', '#e8c95a', '#5be88a', '#b07be8', '#e8905a'], fr = [262, 330, 392, 523, 659, 784];
    x.help = cfg.help || 'Watch the sequence, then repeat it.';
    x.hints = cfg.hints || ['Say the colours out loud as they light up.', 'Tap "Replay" to watch the sequence again.'];
    const gl = cfg.glyphs || U.shuffle(U.GLYPHS.slice(), Math.random).slice(0, np), wrap = h('div', 'mem p' + np); x.body.appendChild(wrap);
    const pads = [], seq = []; for (let i = 0; i < len; i++) seq.push(Math.floor(Math.random() * np));
    const info = h('div', 'mem-info'); x.body.appendChild(info);
    let round = Math.min(2, len), idx = 0, busy = true, over = false;
    for (let i = 0; i < np; i++) { const b = h('button', 'mem-pad'); b.style.setProperty('--c', cols[i]); b.appendChild(glyphCv(gl[i], 40, '#10080c')); b.onclick = () => press(i); pads.push(b); wrap.appendChild(b); }
    const rp = h('button', 'btn small', 'Replay'); rp.onclick = () => { if (!busy) play(); }; x.body.appendChild(rp);
    const flash = i => { pads[i].classList.add('lit'); A().tone(fr[i], .35, .22); x.later(() => pads[i].classList.remove('lit'), 360); };
    function play() { busy = true; idx = 0; info.textContent = L10('Round {0} / {1} - watch...', round - 1, len - 1); let k = 0; const step = () => { if (over) return; if (k >= round) { busy = false; info.textContent = L10('Round {0} / {1} - your turn', round - 1, len - 1); return; } flash(seq[k++]); x.later(step, 600); }; x.later(step, 600); }
    function press(i) { if (busy || over) return; flash(i); if (seq[idx] === i) { idx++; if (idx === round) { if (round === len) { over = true; x.win(); } else { round++; busy = true; info.textContent = L10('Correct!'); x.later(play, 700); } } } else { x.wrong('Wrong note.'); busy = true; x.later(play, 900); } }
    play();
    return { solve() { over = true; x.win(); } };
  };
  /* ---------- 9. PRESSURE PLATES ---------- */
  T.plates = function (x) {
    const cfg = x.cfg, order = cfg.order || ['star', 'moon', 'sun'], n = order.length;
    x.help = cfg.help || 'Step on the plates in the correct order. A wrong step resets them all. Read the carvings.';
    x.hints = cfg.hints || ['Find the symbol that never "follows" another - it goes first.', 'Each carving says which symbol comes right after another one.'];
    const clues = []; for (let i = 1; i < n; i++) clues.push(L10('The {0} comes right after the {1}.', L10(U.GNAME[order[i]]), L10(U.GNAME[order[i - 1]]))); U.shuffle(clues, Math.random);
    const rid = h('div', 'riddle'); clues.forEach(s => rid.appendChild(h('p', '', '"' + s + '"'))); x.body.appendChild(rid);
    const wrap = h('div', 'plates'); x.body.appendChild(wrap); let idx = 0; const els = [];
    U.shuffle(order.slice(), Math.random).forEach(nm => { const b = h('button', 'plate'); b.appendChild(glyphCv(nm, 44, '#d9c58a')); b.onclick = () => { if (b.classList.contains('down')) return; if (nm === order[idx]) { b.classList.add('down'); A().sfx('lock'); idx++; if (idx === n) x.later(() => x.win(), 400); } else { els.forEach(e => e.classList.remove('down')); idx = 0; x.wrong('The plates spring back up!'); } }; els.push(b); wrap.appendChild(b); });
    return { solve() { els.forEach(e => e.classList.add('down')); x.win(); } };
  };
  /* ---------- 10. PIPE CONNECTION ---------- */
  T.pipes = function (x) {
    const cfg = x.cfg, d = x.d || 1, GW = cfg.w || (d > 1 ? 7 : 6), GH = cfg.h || (d > 1 ? 5 : 4), CS = 62, W = GW * CS, H = GH * CS, [cv, c] = mkCanvas(x, W, H);
    const skin = cfg.skin || 'water', liq = skin === 'oxygen' ? '#9fe8ff' : skin === 'steam' ? '#e0e8f0' : '#3ad8a0';
    x.help = cfg.help || 'Rotate the pipes to connect the inlet on the left to the outlet on the right. Tap a pipe to turn it.';
    x.hints = cfg.hints || ['Start at the inlet and rotate each pipe so it leads to the next.', L10(skin === 'oxygen' ? 'Pipes that carry the oxygen light up - fix the first dark pipe.' : 'Pipes that carry the flow light up - fix the first dark pipe.')];
    const N = 1, E = 2, S = 4, Wd = 8, rot1 = b => ((b << 1) | (b >> 3)) & 15, BASE = { I: E | Wd, L: N | E, T: N | E | Wd, X: 15 };
    const r = Math.random, tiles = []; for (let i = 0; i < GW * GH; i++) { const t = ['I', 'L', 'T', 'L', 'I', 'X'][Math.floor(r() * 6)]; tiles.push({ t, rot: Math.floor(r() * 4), path: false }); }
    const bitsOf = t => { let b = BASE[t.t]; for (let i = 0; i < t.rot; i++) b = rot1(b); return b; };
    const turnsN = 2 + d, cols = []; while (cols.length < Math.min(turnsN, GW - 2)) { const q = 1 + Math.floor(r() * (GW - 2)); if (cols.indexOf(q) < 0) cols.push(q); } cols.sort((a, b) => a - b);
    const r0 = Math.floor(r() * GH); let rr = r0, cc = 0; const path = [[rr, cc]]; const mv = (nr, nc) => { while (rr !== nr || cc !== nc) { if (cc !== nc) cc += Math.sign(nc - cc); else rr += Math.sign(nr - rr); path.push([rr, cc]); } };
    cols.forEach(q => { mv(rr, q); let nr; do { nr = Math.floor(r() * GH); } while (nr === rr); mv(nr, q); }); mv(rr, GW - 1); const tr = rr;
    path.forEach((p, i) => { const prev = i ? path[i - 1] : [p[0], -1], next = i < path.length - 1 ? path[i + 1] : [p[0], GW]; const dirTo = (a, b) => b[1] > a[1] ? E : b[1] < a[1] ? Wd : b[0] > a[0] ? S : N; const need = dirTo(p, prev) | dirTo(p, next); const straight = need === (E | Wd) || need === (N | S); const t = tiles[p[0] * GW + p[1]]; t.t = straight ? 'I' : 'L'; t.path = true; t.sol = 0; let b = BASE[t.t]; while (b !== need) { b = rot1(b); t.sol++; if (t.sol > 4) break; } t.rot = (t.sol + 1 + Math.floor(r() * 3)) % 4; });
    const wet = () => { const w = new Set(), q = []; const t0 = tiles[r0 * GW]; if (bitsOf(t0) & Wd) { q.push([r0, 0]); w.add(r0 * GW); } let drain = false; while (q.length) { const [a, b] = q.shift(), bits = bitsOf(tiles[a * GW + b]); if (a === tr && b === GW - 1 && (bits & E)) drain = true; [[N, -1, 0, S], [E, 0, 1, Wd], [S, 1, 0, N], [Wd, 0, -1, E]].forEach(([bit, da, db, opp]) => { if (!(bits & bit)) return; const na = a + da, nb = b + db; if (na < 0 || nb < 0 || na >= GH || nb >= GW) return; if (w.has(na * GW + nb)) return; if (bitsOf(tiles[na * GW + nb]) & opp) { w.add(na * GW + nb); q.push([na, nb]); } }); } return { w, drain }; };
    let solved = false;
    const spin = tiles.map(t => t.rot * 90);
    cv.addEventListener('pointerdown', e => { if (solved) return; const [px, py] = cv.pt(e), i = Math.floor(py / CS) * GW + Math.floor(px / CS); if (tiles[i]) { tiles[i].rot = (tiles[i].rot + 1) % 4; A().sfx('click'); if (wet().drain) { solved = true; A().sfx('water'); setTimeout(() => x.win(), 900); } } });
    x.loop(t => {
      c.fillStyle = '#0a1210'; c.fillRect(0, 0, W, H); const { w } = wet();
      for (let i = 0; i < tiles.length; i++) { const tl = tiles[i], cx = (i % GW) * CS + CS / 2, cy = ((i / GW) | 0) * CS + CS / 2, b = bitsOf(tl), isW = w.has(i); spin[i] += (tl.rot * 90 - spin[i] + 360 * 8) % 360 > 180 ? 0 : 0; c.save(); c.translate(cx, cy); c.fillStyle = 'rgba(255,255,255,.03)'; c.fillRect(-CS / 2 + 2, -CS / 2 + 2, CS - 4, CS - 4);
        const dirs = [[N, 0, -1], [E, 1, 0], [S, 0, 1], [Wd, -1, 0]]; c.lineCap = 'butt'; c.strokeStyle = '#4a5560'; c.lineWidth = 17; c.beginPath(); dirs.forEach(([bit, dx, dy]) => { if (b & bit) { c.moveTo(0, 0); c.lineTo(dx * CS / 2, dy * CS / 2); } }); c.stroke(); c.fillStyle = '#4a5560'; c.beginPath(); c.arc(0, 0, 8.5, 0, TAU); c.fill(); c.strokeStyle = '#161b20'; c.lineWidth = 11; c.beginPath(); dirs.forEach(([bit, dx, dy]) => { if (b & bit) { c.moveTo(0, 0); c.lineTo(dx * CS / 2, dy * CS / 2); } }); c.stroke(); c.fillStyle = '#161b20'; c.beginPath(); c.arc(0, 0, 5.5, 0, TAU); c.fill();
        if (isW) { c.strokeStyle = liq; c.lineWidth = 7; c.shadowColor = liq; c.shadowBlur = 8; c.beginPath(); dirs.forEach(([bit, dx, dy]) => { if (b & bit) { c.moveTo(0, 0); c.lineTo(dx * CS / 2, dy * CS / 2); } }); c.stroke(); c.fillStyle = liq; c.beginPath(); c.arc(0, 0, 4, 0, TAU); c.fill(); }
        c.restore(); }
      c.fillStyle = liq; c.fillRect(0, r0 * CS + CS / 2 - 5, 8, 10); c.fillStyle = solved ? '#5cff8a' : '#6a7480'; c.fillRect(W - 8, tr * CS + CS / 2 - 5, 8, 10);
    });
    return { solve() { tiles.forEach(tl => { if (tl.path) tl.rot = tl.sol % 4; }); if (!wet().drain) { x.wrong('(internal) unsolvable'); return; } solved = true; x.win(); } };
  };
  /* ---------- 11. PATTERN RECOGNITION ---------- */
  T.pattern = function (x) {
    const cfg = x.cfg, d = x.d || 1, r = Math.random;
    x.help = cfg.help || 'Every row and column follows the same rules. Which piece completes the grid?';
    x.hints = cfg.hints || [L10(d > 1 ? 'Look at one attribute at a time: shape first, then colour, then whether it is filled.' : 'Look at one attribute at a time: shape first, then colour.'), 'Each shape and each colour appears once in every row and every column.'];
    const shapes = U.shuffle(['circle', 'square', 'triangle', 'diamond', 'star', 'hex'], r).slice(0, 3), colors = U.shuffle(['#e85a5a', '#5ab0e8', '#e8c95a', '#5be88a', '#b07be8'], r).slice(0, 3);
    const cellAt = (a, b) => ({ s: shapes[(a + b) % 3], c: colors[(2 * a + b) % 3], f: d > 1 ? (a % 2 === 0) : true });
    const ans = cellAt(2, 2), wrap = h('div', 'pat'); x.body.appendChild(wrap); const gr = h('div', 'pat-grid'); wrap.appendChild(gr);
    const mkc = (o, q) => { const cv = h('canvas', 'pat-c'); cv.width = cv.height = 120; cv.style.width = cv.style.height = '60px'; const c = cv.getContext('2d'); c.scale(2, 2); if (o) drawShape(c, o.s, o.c, 30, 30, 18, o.f); else { c.fillStyle = 'rgba(255,255,255,.08)'; c.fillRect(8, 8, 44, 44); c.fillStyle = '#ffd36a'; c.font = 'bold 28px sans-serif'; c.textAlign = 'center'; c.fillText('?', 30, 41); } return cv; };
    for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) gr.appendChild(mkc(a === 2 && b === 2 ? null : cellAt(a, b)));
    const opts = [ans]; const variants = [o => ({ ...o, s: shapes.concat(['star', 'hex', 'diamond']).filter(q => q !== o.s)[Math.floor(r() * 4)] }), o => ({ ...o, c: colors.concat(['#ff9a3a']).filter(q => q !== o.c)[Math.floor(r() * 3)] }), o => ({ ...o, f: !o.f })];
    let g2 = 0; while (opts.length < 4 && g2++ < 50) { const v = variants[Math.floor(r() * (d > 1 ? 3 : 2))](ans); if (!opts.some(q => q.s === v.s && q.c === v.c && q.f === v.f)) opts.push(v); }
    U.shuffle(opts, r); const row = h('div', 'pat-opts'); wrap.appendChild(row); const bt = [];
    opts.forEach(o => { const b = h('button', 'pat-o'); b.appendChild(mkc(o)); b.onclick = () => { if (o === ans) { b.classList.add('ok'); x.later(() => x.win(), 300); } else { x.wrong('That piece breaks the pattern.'); } }; bt.push(b); row.appendChild(b); });
    return { solve() { bt[opts.indexOf(ans)].click(); } };
  };
  /* ---------- 12. LOGIC SEQUENCE ---------- */
  T.logic = function (x) {
    const cfg = x.cfg, d = x.d || 1, rounds = cfg.rounds || 1, r = Math.random; let rd = 0;
    x.help = cfg.help || 'Find the rule and choose the number that comes next.';
    x.hints = cfg.hints || ['Look at the difference between neighbouring numbers.', 'If the differences change, look at how the differences change.'];
    function gen() {
      const k = Math.floor(r() * (d === 1 ? 2 : d === 2 ? 3 : 3)) + (d - 1) * 2, a = 2 + Math.floor(r() * 7); let s = [];
      if (k === 0) { const df = 2 + Math.floor(r() * 6); for (let i = 0; i < 6; i++) s.push(a + df * i); }
      else if (k === 1) { for (let i = 1; i <= 6; i++) s.push((i + (a % 3)) * (i + (a % 3))); }
      else if (k === 2) { const m = 2 + Math.floor(r() * 2); let v = 1 + Math.floor(r() * 3); for (let i = 0; i < 6; i++) { s.push(v); v *= m; } }
      else if (k === 3) { let p = 1 + Math.floor(r() * 3), q = 2 + Math.floor(r() * 3); for (let i = 0; i < 6; i++) { s.push(p); const t = p + q; p = q; q = t; } }
      else if (k === 4) { let v = a; for (let i = 0; i < 6; i++) { s.push(v); v += i + 1; } }
      else { let u = a, v = 20 + a, du = 3 + Math.floor(r() * 3); for (let i = 0; i < 6; i++) { s.push(i % 2 ? v : u); if (i % 2) v -= 2; else u += du; } }
      return { seq: s.slice(0, 5), ans: s[5] };
    }
    const box = h('div', 'logic'); x.body.appendChild(box); let cur2, btns;
    function show() {
      box.innerHTML = ''; cur2 = cfg.seq ? { seq: cfg.seq, ans: cfg.ans } : gen(); const sq = h('div', 'seq'); cur2.seq.forEach(v => sq.appendChild(h('span', 'seq-n', v))); sq.appendChild(h('span', 'seq-n q', '?')); box.appendChild(sq);
      const o = [cur2.ans]; let g2 = 0; while (o.length < 4 && g2++ < 50) { const v = cur2.ans + (Math.floor(r() * 9) - 4) * (1 + Math.floor(r() * 2)); if (v > 0 && o.indexOf(v) < 0) o.push(v); } U.shuffle(o, r); const row = h('div', 'logic-opts'); box.appendChild(row); btns = [];
      o.forEach(v => { const b = h('button', 'btn opt', v); b.onclick = () => { if (v === cur2.ans) { b.classList.add('ok'); if (++rd >= rounds) x.later(() => x.win(), 300); else x.later(show, 500); } else x.wrong('Not that number.'); }; btns.push([v, b]); row.appendChild(b); });
      if (rounds > 1) box.appendChild(h('div', 'mem-info', L10('Sequence {0} of {1}', rd + 1, rounds)));
    }
    show();
    return { solve() { for (let i = 0; i < rounds; i++) { const b = btns.find(q => q[0] === cur2.ans)[1]; b.click(); } } };
  };
  /* ---------- 13. ANCIENT INSCRIPTION / CIPHER ---------- */
  T.inscription = function (x) {
    const cfg = x.cfg, word = String(cfg.word).toUpperCase(), r = Math.random;
    x.help = cfg.help || 'Decode the inscription using the key stone, then set the letters.';
    x.hints = cfg.hints || ['Each carved symbol stands for one letter - find it on the key stone.', 'The same symbol always means the same letter.'];
    const letters = Array.from(new Set(word.split(''))), extra = 'ABCDEFGHIJKLMNOPRSTUVWY'.split('').filter(l => letters.indexOf(l) < 0); U.shuffle(extra, r); const all = letters.concat(extra.slice(0, cfg.extra == null ? 3 : cfg.extra)).sort();
    const gl = U.shuffle(U.GLYPHS.slice(), r).slice(0, all.length), map = {}; all.forEach((l, i) => map[l] = gl[i]);
    const ins = h('div', 'ins'); word.split('').forEach(l => ins.appendChild(glyphCv(map[l], 44, '#ffcf70'))); x.body.appendChild(ins);
    const key = h('div', 'ins-key'); all.forEach(l => { const e = h('div', 'ins-k'); e.appendChild(glyphCv(map[l], 26, '#cdb98a')); e.appendChild(h('b', '', '= ' + l)); key.appendChild(e); }); x.body.appendChild(key);
    const row = h('div', 'ins-row'); const val = []; word.split('').forEach((_, i) => { val.push(0); const b = h('button', 'btn slot', all[0]); b.onclick = () => { val[i] = (val[i] + 1) % all.length; b.textContent = all[val[i]]; A().sfx('click'); }; row.appendChild(b); }); x.body.appendChild(row);
    const go = h('button', 'btn go', 'SPEAK THE WORD'); go.onclick = () => { if (val.map(v => all[v]).join('') === word) x.win(); else x.wrong('The stones stay silent.'); }; x.body.appendChild(go);
    return { solve() { word.split('').forEach((l, i) => { val[i] = all.indexOf(l); row.children[i].textContent = l; }); go.click(); } };
  };
  /* ---------- 14. MULTI-STAGE PUZZLE ---------- */

  /* ---------- NEW A. LIGHTS: tap a tile, it and its neighbours flip - light them all ---------- */
  T.lights = function (x) {
    const cfg = x.cfg, n = cfg.n || 3, r = Math.random; x.help = 'Tap the tiles to light them all.';
    x.hints = ['Tapping a tile also flips the tiles next to it.', 'Try to light the corners first.'];
    const on = []; for (let i = 0; i < n * n; i++) on.push(true);
    const flip = (i, st) => { const a = (i / n) | 0, b = i % n; [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([da, db]) => { const q = a + da, w = b + db; if (q >= 0 && w >= 0 && q < n && w < n) st[q * n + w] = !st[q * n + w]; }); };
    const presses = []; for (let i = 0; i < n * n; i++) if (r() < .5) presses.push(i); if (presses.length < 3) presses.push(0, n * n - 1, (n * n / 2) | 0);
    presses.forEach(i => flip(i, on)); if (on.every(v => v)) flip(0, on);
    const grid = h('div', 'lt-grid'); grid.style.gridTemplateColumns = 'repeat(' + n + ',1fr)'; x.body.appendChild(grid); const cells = [];
    const paint = () => cells.forEach((b, i) => b.classList.toggle('lit', on[i]));
    for (let i = 0; i < n * n; i++) { const b = h('button', 'lt-c'); b.onclick = () => { A().sfx('click'); flip(i, on); paint(); if (on.every(v => v)) x.later(() => x.win(), 250); }; cells.push(b); grid.appendChild(b); }
    paint();
    return { solve() { for (let i = 0; i < n * n; i++) if (on[i]) { } on.fill(true); paint(); x.win(); } };
  };
  /* ---------- NEW B. SWAP: swap tiles until the row matches the picture ---------- */
  T.swap = function (x) {
    const cfg = x.cfg, n = cfg.n || 5, r = Math.random; x.help = 'Swap the tiles so they match the picture above.';
    x.hints = ['Tap a tile to swap it with the one you tapped before.', 'Fix one tile at a time, starting from the left.'];
    const base = ['#e85a5a', '#ff9a3a', '#ffe14a', '#5be88a', '#5ab0e8', '#b07be8', '#ff7ac0'], glyphs = ['sun', 'moon', 'star', 'leaf', 'flame', 'drop', 'bolt'];
    const target = []; for (let i = 0; i < n; i++) target.push(i);
    let cur = U.shuffle(target.slice(), r); let g = 0; while (cur.every((v, i) => v === i) && g++ < 20) cur = U.shuffle(target.slice(), r);
    const mk = (id, big) => { const cv = h('canvas', 'sw-c'); cv.width = cv.height = 128; const c = cv.getContext('2d'); c.scale(2, 2); c.fillStyle = 'rgba(12,9,22,.92)'; c.strokeStyle = base[id]; c.lineWidth = 4; c.beginPath(); c.roundRect ? c.roundRect(3, 3, 58, 58, 12) : c.rect(3, 3, 58, 58); c.fill(); c.stroke(); U.glyph(c, glyphs[id], 32, 32, 18, base[id], 3.4); return cv; };
    const ref = h('div', 'sw-row ref'); target.forEach(i => { const c = mk(i); ref.append(c); }); x.body.appendChild(ref);
    x.body.appendChild(h('div', 'sw-arrow', '▼'));
    const row = h('div', 'sw-row'); x.body.appendChild(row); let sel = -1;
    function paint() { row.innerHTML = ''; cur.forEach((id, i) => { const b = h('button', 'sw-b' + (i === sel ? ' sel' : '') + (id === i ? ' ok' : '')); b.append(mk(id)); b.onclick = () => { A().sfx('click'); if (sel < 0) sel = i; else if (sel === i) sel = -1; else { const t = cur[sel]; cur[sel] = cur[i]; cur[i] = t; sel = -1; } paint(); if (cur.every((v, k) => v === k)) x.later(() => x.win(), 300); }; row.append(b); }); }
    paint();
    return { solve() { cur = target.slice(); paint(); x.win(); } };
  };
  T.multi = function (x) {
    const st = x.cfg.stages; let i = Math.min(st.length - 1, (TLR.Save.data.prog[x.key] || 0)); let inst = null, pips = h('div', 'pips');
    x.body.appendChild(pips); const holder = h('div', 'multi-body'); x.body.appendChild(holder);
    function run() {
      pips.innerHTML = ''; st.forEach((s, k) => pips.appendChild(h('span', 'pip' + (k < i ? ' done' : k === i ? ' now' : ''))));
      holder.innerHTML = ''; x.stopLoops(); const s = st[i]; const sub = Object.create(x); sub.body = holder; sub.cfg = Object.assign({}, s.cfg); sub.d = s.cfg.d || x.d; sub.key = x.key + ':' + i;
      sub.win = () => { A().sfx('unlock'); i++; TLR.Save.data.prog[x.key] = i; TLR.Save.save(); if (i >= st.length) x.win(); else x.later(run, 600); };
      sub.setHelp = t => { x.help = t; x.helpEl.textContent = L10(t); };
      T[s.type](sub); x.helpEl.textContent = L10(sub.help || ''); x.hints = sub.hints; x.hintIdx = 0;
      inst = T[s.type](Object.assign(sub, {})); // (see note below)
    }
    // NOTE: build each stage exactly once - the line above would double build, so we replace run() cleanly:
    function run2() {
      pips.innerHTML = ''; st.forEach((s, k) => pips.appendChild(h('span', 'pip' + (k < i ? ' done' : k === i ? ' now' : ''))));
      holder.innerHTML = ''; x.stopLoops(); const s = st[i]; const sub = Object.create(x); sub.body = holder; sub.cfg = Object.assign({}, s.cfg); sub.d = s.cfg.d || x.d; sub.key = x.key + ':' + i;
      sub.win = () => { A().sfx('unlock'); i++; TLR.Save.data.prog[x.key] = i; TLR.Save.save(); if (i >= st.length) x.win(); else { x.later(run2, 650); } };
      inst = T[s.type](sub); x.helpEl.textContent = L10(sub.help || ''); x.hints = sub.hints; x.hintIdx = 0; x.stage = i;
      if (x.qa) x.later(() => { try { inst.solve(); } catch (e) { console.error(e); } }, 60);
    }
    run2();
    return { solve() { /* QA solves each stage automatically as they appear */ } };
  };
  /* ---------- modal shell ---------- */
  const Puzzles = TLR.Puzzles = {
    qa: false, types: Object.keys(T),
    isOpen() { return !!cur; },
    onWrong: null,
    open(spec, cb) {
      if (cur) this.close(false);
      const key = spec.key || spec.type, cfg = spec.cfg || {};
      const ov = h('div', 'pz-ov'), box = h('div', 'pz-box ' + (cfg.skin || '')), head = h('div', 'pz-head'), title = h('div', 'pz-title', spec.title || 'Puzzle'), close = h('button', 'pz-x', '✕'), help = h('div', 'pz-help'), body = h('div', 'pz-body'), msg = h('div', 'pz-msg'), foot = h('div', 'pz-foot'), hb = h('button', 'btn small', 'Hint');
      head.append(title, close); foot.append(hb); box.append(head, help, body, msg, foot); ov.appendChild(box); (document.getElementById('app') || document.body).appendChild(ov);
      const loops = [], timers = []; let raf = 0, lastT = 0, finished = false;
      const x = { body, cfg, d: cfg.d || 1, key, qa: Puzzles.qa, helpEl: help, hints: null, hintIdx: 0, help: '',
        later(fn, ms) { const id = setTimeout(() => { if (cur === obj) fn(); }, ms); timers.push(id); return id; },
        loop(fn) { loops.push(fn); if (!raf) tick(0); },
        stopLoops() { loops.length = 0; },
        win() { if (finished) return; finished = true; box.classList.add('won'); msg.textContent = L10('Solved'); msg.className = 'pz-msg good'; A().sfx('solve'); setTimeout(() => { if (cur === obj) Puzzles.close(true); }, x.qa ? 20 : 1000); },
        wrong(m) { if (finished) return; msg.textContent = L10(m || 'Wrong.'); msg.className = 'pz-msg bad'; box.classList.remove('shake'); void box.offsetWidth; box.classList.add('shake'); A().sfx('wrong'); if (Puzzles.onWrong) Puzzles.onWrong(); }
      };
      function tick(ts) { raf = requestAnimationFrame(tick); const t = ts / 1000; if (!loops.length) { cancelAnimationFrame(raf); raf = 0; return; } loops.forEach(f => f(t)); }
      const obj = { ov, x, timers, getRaf: () => raf, cancel() { cancelAnimationFrame(raf); raf = 0; timers.forEach(clearTimeout); }, cb };
      cur = obj; ov.classList.add('show');
      let inst; try { inst = T[spec.type](x); } catch (e) { console.error('puzzle build failed', spec.type, e); }
      help.textContent = L10(x.help || '');
      hb.onclick = () => { const hs = x.hints || ['Look around the room again.']; const s = hs[Math.min(x.hintIdx, hs.length - 1)]; x.hintIdx++; msg.textContent = L10('Hint: {0}', L10(s)); msg.className = 'pz-msg hint'; A().sfx('hint'); TLR.Save.data.hints = (TLR.Save.data.hints || 0) + 1; };
      close.onclick = () => { A().sfx('click'); Puzzles.close(false); };
      obj.inst = inst;
      if (Puzzles.qa && inst && spec.type !== 'multi') setTimeout(() => { try { inst.solve(); } catch (e) { console.error(e); } }, 30);
      return obj;
    },
    close(ok) { if (!cur) return; const o = cur; cur = null; o.cancel(); o.ov.classList.remove('show'); setTimeout(() => o.ov.remove(), 200); if (o.cb) o.cb(!!ok); }
  };
})(window);
