/* THE LAST ROOM - DOM user interface: menu, HUD, inventory, reader, settings, chapter screens */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {}, U = TLR.U, Save = TLR.Save, Inv = TLR.Inv;
  const $ = id => document.getElementById(id), h = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = typeof txt === 'string' ? T(txt) : txt; return e; };
  const A = () => TLR.Audio, G = () => TLR.Game, T = (...a) => TLR.I18N.t(...a);
  const stack = []; let toastT = 0, sayQ = [], sayBusy = false, root, hudEl;
  const btn = (txt, fn, cls) => { const b = h('button', 'btn ' + (cls || ''), txt); b.onclick = () => { A().init(); A().sfx('click'); fn(); }; return b; };
  function overlay(cls) { const ov = h('div', 'ov ' + (cls || '')); root.appendChild(ov); requestAnimationFrame(() => ov.classList.add('show')); const o = { ov, close() { const i = stack.indexOf(o); if (i >= 0) stack.splice(i, 1); ov.classList.remove('show'); setTimeout(() => ov.remove(), 180); if (o.onClose) o.onClose(); } }; if ((cls || '').indexOf('dim') >= 0) { const x = h('button', 'ov-x', '✕'); x.setAttribute('aria-label', 'Close'); x.onclick = e => { e.stopPropagation(); o.close(); }; ov.appendChild(x); }
    stack.push(o); return o; }
  const UI = TLR.UI = {
    init() {
      root = $('app'); hudEl = $('hud');
      $('hud-hint').onclick = () => { A().init(); G().hint(); }; $('hud-inv').onclick = () => { A().init(); A().sfx('click'); UI.inventory(); }; $('hud-pause').onclick = () => { A().init(); A().sfx('click'); UI.pause(); };
      $('tb-use').addEventListener('pointerdown', () => A().init()); $('tb-inv').addEventListener('pointerdown', () => { });
      const pc = $('portrait'); TLR.Player.bake(); TLR.Player.portrait(pc);
      this.applySettings();
    },
    relocalize() { TLR.I18N.dom(); if (this._lv && G().mode === 'play') { this.setLevelLabel(this._lv); G().refresh && G().refresh(); } if (G().mode === 'menu') this.menu(); },
    modalOpen() { return stack.length > 0; }, closeTop() { const t = stack[stack.length - 1]; if (t) t.close(); },
    applySettings() { const s = Save.settings, t = $('touch'), on = s.touch === 'on' || (s.touch === 'auto' && ('ontouchstart' in window || navigator.maxTouchPoints > 0)); t.classList.toggle('force', on); document.body.classList.toggle('touchui', on); document.body.classList.toggle('lefty', s.lefty === 'on'); document.body.dataset.btn = s.btn || 'medium'; A().applyVolumes(); },
    hud(on) { hudEl.classList.toggle('hidden', !on); $('touch').classList.toggle('hidden', !on); if (!on) { this.setNear(null); } },
    setObjective(s) { $('obj-text').textContent = s[1]; if (TLR.Guide) { TLR.Guide.tt = 0; setTimeout(() => TLR.Guide.hud(), 60); } },
    resetSay() { sayQ = []; $('subtitle').classList.remove('show'); },
    setLevelLabel(L) { $('lvl-label').textContent = T('Ch {0} - {1}', L.ch, L.name); this._lv = L; },
    setJumpVisible(v) { $('tb-jump').style.visibility = v ? 'visible' : 'hidden'; },
    setNear(label) { const b = $('tb-use'); b.textContent = T(label || 'Interact'); b.classList.toggle('ready', !!label); const k = $('use-key'); if (k) { k.textContent = label ? 'E - ' + label : ''; k.classList.toggle('show', !!label && !document.body.classList.contains('touchui')); } },
    toast(m, ms) { const t = $('toast'); t.textContent = T(m); t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), ms || 2600); },
    banner(m) { const b = $('banner'); b.textContent = T(m); b.classList.add('show'); setTimeout(() => b.classList.remove('show'), 1100); },
    flashItem(it) { const f = $('itemflash'); f.innerHTML = ''; const im = new Image(); im.src = U.itemIcon(it); const n = h('span', '', it.name); f.append(im, n); f.classList.remove('show'); void f.offsetWidth; f.classList.add('show'); },
    say(lines) { sayQ = sayQ.concat(lines); if (!sayBusy) $('subtitle').classList.remove('show'); if (!sayBusy) next(); function next() { const l = sayQ.shift(); if (!l) { sayBusy = false; $('subtitle').classList.remove('show'); return; } sayBusy = true; const s = $('subtitle'); s.textContent = T(l); s.classList.add('show'); setTimeout(next, 2800); } },
    confirm(msg, yes, yesTxt) { const o = overlay('dim'); const c = h('div', 'card small'); c.append(h('p', '', msg)); const row = h('div', 'row'); row.append(btn('Cancel', () => o.close()), btn(yesTxt || 'Yes', () => { o.close(); yes(); }, 'danger')); c.append(row); o.ov.appendChild(c); },
    /* ---------------- menu ---------------- */
    hideMenu() { const m = $('menu'); m.classList.add('hidden'); },
    menu() {
      const m = $('menu'); m.classList.remove('hidden'); m.innerHTML = ''; const logo = h('div', 'logo'); logo.innerHTML = '<svg class="keyhole" viewBox="0 0 40 56"><circle cx="20" cy="20" r="14" fill="none" stroke="#e8c36a" stroke-width="3"/><path d="M20 14a6 6 0 0 1 3 11l4 22h-14l4-22a6 6 0 0 1 3-11z" fill="#e8c36a"/></svg><div class="logo-t1">THE</div><div class="logo-t2">LAST ROOM</div><div class="tagline">' + T('ESCAPE \u2022 SOLVE \u2022 SURVIVE') + '</div>'; m.appendChild(logo);
      const col = h('div', 'menu-btns'); m.appendChild(col);
      if (Save.hasSave()) col.appendChild(btn('Continue', () => { UI.hideMenu(); G().continueGame(); }, 'big'));
      col.appendChild(btn('New Game', () => { const go = () => { Save.newGame(); UI.hideMenu(); G().newGame(); }; if (Save.hasSave()) UI.confirm('Start a new game? Your saved progress will be erased.', go, 'Erase and start'); else go(); }, 'big'));
      col.appendChild(btn('Chapter Selection', () => UI.chapters())); col.appendChild(btn('Settings', () => UI.settings())); col.appendChild(btn('Credits', () => UI.credits()));
      m.appendChild(h('div', 'ver', 'v1.0  -  works offline'));
    },
    chapters() {
      const o = overlay('dim'), c = h('div', 'card wide'); c.append(h('h2', '', 'Chapter Selection')); const grid = h('div', 'chgrid'); const S = Save.data;
      TLR.CHAPTERS.forEach(ch => { const lock = ch.n > S.unlocked || !S.started; const done = TLR.LEVELS.filter(l => l.ch === ch.n && S.completed.indexOf(l.id) >= 0).length; const b = h('button', 'chcard' + (lock ? ' lock' : ''));
        b.style.setProperty('--c', TLR.Scenery.TH[ch.theme].c1); b.innerHTML = '<b>' + String(ch.n).padStart(2, '0') + '</b><span>' + ch.name + '</span><i>' + (lock ? T('Locked') : T('{0} / 5 levels', done) + ' \u00b7 \u2605 ' + TLR.LEVELS.filter(l => l.ch === ch.n).reduce((q, l) => q + ((S.stars || {})[l.id] || 0), 0)) + '</i>'; b.onclick = () => { if (lock) { A().sfx('wrong'); return; } A().init(); A().sfx('click'); o.close(); UI.hideMenu(); G().startChapter(ch.n); }; grid.appendChild(b); });
      c.append(grid, btn('Back', () => o.close())); if (!S.started) c.insertBefore(h('p', 'dim', 'Start a New Game to unlock chapters.'), grid); o.ov.appendChild(c);
    },
    settings() {
      const o = overlay('dim'), c = h('div', 'card'); c.append(h('h2', '', 'Settings')); const S = Save.settings;
      const slider = (lab, key, test) => { const r = h('label', 'set'); r.append(h('span', '', lab)); const i = h('input'); i.type = 'range'; i.min = 0; i.max = 1; i.step = .05; i.value = S[key]; i.oninput = () => { S[key] = +i.value; A().applyVolumes(); Save.saveSettings(); }; i.onchange = () => { if (test) A().sfx(test); }; r.append(i); c.append(r); };
      slider('Music volume', 'music'); slider('Sound volume', 'sfx', 'pickup');
      const t = h('label', 'set'); t.append(h('span', '', 'Touch controls')); const sel = h('select'); ['auto', 'on', 'off'].forEach(v => { const op = h('option', '', v); op.value = v; sel.append(op); }); sel.value = S.touch; sel.onchange = () => { S.touch = sel.value; Save.saveSettings(); UI.applySettings(); }; t.append(sel); c.append(t);
      const lr = h('label', 'set'); lr.append(h('span', '', 'Language')); const ls = h('select'); ['auto'].concat(TLR.I18N.list()).forEach(v => { const op = h('option', '', v === 'auto' ? 'auto' : TLR.I18N.name(v)); op.value = v; ls.append(op); }); ls.value = S.lang || 'auto'; ls.onchange = () => { S.lang = ls.value; Save.saveSettings(); TLR.I18N.setLang(); o.close(); UI.relocalize(); UI.settings(); }; lr.append(ls); c.append(lr); { const gr = h('label', 'set'); gr.append(h('span', '', 'Guidance icons')); const gs = h('select'); [['on', 'On'], ['off', 'Off']].forEach(v => { const op = h('option', '', v[1]); op.value = v[0]; gs.append(op); }); gs.value = S.guide || 'on'; gs.onchange = () => { S.guide = gs.value; Save.saveSettings(); if (TLR.Guide) TLR.Guide.hud(); }; gr.append(gs); c.append(gr); }
      [['diff', 'Difficulty', [['easy', 'Easy'], ['normal', 'Normal'], ['hard', 'Hard']]], ['vib', 'Vibration', [['on', 'On'], ['off', 'Off']]], ['lefty', 'Left-handed buttons', [['off', 'Off'], ['on', 'On']]], ['btn', 'Button size', [['small', 'Small'], ['medium', 'Medium'], ['large', 'Large']]]].forEach(q => { const r = h('label', 'set'); r.append(h('span', '', q[1])); const sl = h('select'); q[2].forEach(v => { const op = h('option', '', v[1]); op.value = v[0]; sl.append(op); }); sl.value = S[q[0]] || q[2][0][0]; sl.onchange = () => { S[q[0]] = sl.value; Save.saveSettings(); UI.applySettings(); }; r.append(sl); c.append(r); });
      c.append(btn('Reset all progress', () => UI.confirm('Erase ALL saved progress? This cannot be undone.', () => { Save.resetAll(); UI.toast('Progress erased'); if (G().mode === 'menu') UI.menu(); else { o.close(); G().toMenu(); } }, 'Erase everything'), 'danger'), btn('Back', () => o.close()));
      o.ov.appendChild(c);
    },
    credits() { const o = overlay('dim'), c = h('div', 'card'); c.innerHTML = '<h2>' + T('Credits') + '</h2><p>THE LAST ROOM</p><p class="dim">' + T('Design, code, art and sound: generated procedurally in HTML5 Canvas and WebAudio.') + '</p><p class="dim">' + T('No external assets. No network needed.') + '</p>'; c.append(btn('Back', () => o.close())); o.ov.appendChild(c); },
    results(info, next) {
      const o = overlay('dim'); const c = h('div', 'card results'); c.append(h('h2', '', 'Level complete'));
      const st = h('div', 'stars'); for (let i = 1; i <= 3; i++) st.append(h('span', 'star' + (i <= info.stars ? ' on' : ''), '\u2605')); c.append(st);
      const row = (a, b) => { const r = h('div', 'rrow'); r.append(h('span', '', a), h('b', '', b)); c.append(r); };
      const fmt = s => Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
      row(T('Time'), fmt(info.time) + (info.newBest ? '  \u2605 ' + T('New record') : '  (' + T('Best') + ' ' + fmt(info.best) + ')')); row(T('Deaths'), String(info.deaths)); row(T('Memories found'), String(info.lore) + '/20');
      c.append(h('p', 'dim', info.stars < 3 ? (info.deaths ? 'Finish without dying for more stars.' : 'Finish faster for the third star.') : 'Perfect!'));
      c.append(btn('Continue', () => { o.close(); next(); }, 'big')); o.ov.appendChild(c); const x = o.ov.querySelector('.ov-x'); if (x) x.remove();
    },
    gameOver() {
      const o = overlay('dim over'); const c = h('div', 'card gameover'); c.append(h('h2', '', 'YOU DIED')); c.append(h('p', 'dim', 'The darkness took you. Hide, use your lantern, or run next time.'));
      c.append(btn('Try again', () => { o.close(); if (TLR.Ghost) TLR.Ghost.shown = false; G().loadLevel(G().L.id); }, 'big'), btn('Restart Level', () => { o.close(); if (TLR.Ghost) TLR.Ghost.shown = false; G().restartLevel(); }), btn('Main Menu', () => { o.close(); if (TLR.Ghost) TLR.Ghost.shown = false; G().toMenu(); }));
      o.ov.appendChild(c); const x = o.ov.querySelector('.ov-x'); if (x) x.remove();
    },
    setLight(cd) { const b = $('tb-light'); if (!b) return; b.classList.add('cool'); clearTimeout(this._lt); this._lt = setTimeout(() => b.classList.remove('cool'), cd * 1000); },
    pause() { const o = overlay('dim'); G().paused = false; const c = h('div', 'card'); c.append(h('h2', '', 'Paused')); c.append(btn('Resume', () => o.close(), 'big'), btn('Restart Level', () => UI.confirm('Restart this level from the beginning?', () => { o.close(); G().restartLevel(); }, 'Restart')), btn('Settings', () => UI.settings()), btn('Main Menu', () => { o.close(); G().toMenu(); })); o.ov.appendChild(c); TLR.Input.clear(); },
    /* ---------------- chapter screens ---------------- */
    chapterIntro(n, cb) {
      const ch = TLR.CHAPTERS[n - 1], th = TLR.Scenery.TH[ch.theme]; UI.hideMenu(); UI.hud(false); G().mode = 'idle'; A().music(n - 1);
      const o = overlay('chapter'); o.ov.style.setProperty('--c', th.c1); o.ov.style.setProperty('--f', th.fog); const c = h('div', 'ch-card'); c.append(h('div', 'ch-n', T('CHAPTER {0}', String(n).padStart(2, '0'))), h('div', 'ch-name', ch.name), h('div', 'ch-tag', ch.tag), h('p', 'ch-intro', ch.intro), h('div', 'story-hint', 'Tap to begin')); o.ov.appendChild(c); let done = false; const go = () => { if (done) return; done = true; o.close(); cb(); }; o.ov.onclick = go; if (G().qa) go();
    },
    chapterComplete(n, cb) {
      const ch = TLR.CHAPTERS[n - 1]; const o = overlay('chapter done'); o.ov.style.setProperty('--c', TLR.Scenery.TH[ch.theme].c1); const c = h('div', 'ch-card'); const dn = TLR.LEVELS.filter(l => l.ch === n && Save.data.completed.indexOf(l.id) >= 0).length;
      c.append(h('div', 'ch-n', T('CHAPTER {0} COMPLETE', String(n).padStart(2, '0'))), h('div', 'ch-name', ch.name), h('p', 'ch-intro', ch.outro), h('div', 'ch-stats', T('Levels cleared: {0} / 5   -   Hints used: {1}', dn, Save.data.hints || 0)), btn('Continue', () => { o.close(); cb(); }, 'big')); o.ov.appendChild(c); A().sfx('solve');
    },
    /* ---------------- note reader ---------------- */
    reader(note, onClose) {
      const o = overlay('dim'); const c = h('div', 'card reader k-' + (note.kind2 || 'letter')); c.append(h('h2', '', note.title));
      if (note.kind2 === 'photo') { const cv = h('canvas', 'photo'); cv.width = 440; cv.height = 280; const x = cv.getContext('2d'); x.fillStyle = '#e8e4da'; x.fillRect(0, 0, 440, 280); const gr = U.lg(x, 0, 14, 0, 220, [[0, '#6a8aa8'], [1, '#c8b890']]); x.fillStyle = gr; x.fillRect(16, 14, 408, 206); x.fillStyle = '#3a4a3a'; x.beginPath(); x.moveTo(16, 160); x.lineTo(120, 110); x.lineTo(220, 150); x.lineTo(330, 100); x.lineTo(424, 150); x.lineTo(424, 220); x.lineTo(16, 220); x.fill(); x.fillStyle = '#2a2018'; x.fillRect(180, 120, 80, 100); x.fillStyle = '#d8c8a0'; for (const [px, py] of [[200, 140], [226, 140]]) { x.beginPath(); x.arc(px, py, 7, 0, 6.3); x.fill(); x.fillRect(px - 6, py + 8, 12, 30); } x.fillStyle = 'rgba(80,60,30,.12)'; x.fillRect(0, 0, 440, 280); x.fillStyle = '#4a3a2a'; x.font = 'italic 15px Georgia'; x.fillText(note.text.slice(0, 60), 20, 252); c.append(cv); }
      if (note.kind2 === 'audio') { const w = h('div', 'wave'); for (let i = 0; i < 28; i++) { const b = h('i'); b.style.animationDelay = (i * .06) + 's'; w.append(b); } c.append(w); const pb = btn('Play recording', () => { w.classList.add('on'); A().sfx('read'); [0, 1, 2, 3, 4].forEach(i => setTimeout(() => A().tone(300 + Math.random() * 200, .2, .12), i * 160)); setTimeout(() => w.classList.remove('on'), 1000); }); c.append(pb); }
      TLR.Guide.markSeen(note); { const bp = h('p', 'note-body', ''); const strip = TLR.Guide.decorate(bp, note.text); if (strip) c.append(strip); c.append(bp); } c.append(btn('Close', () => o.close(), 'big')); o.ov.appendChild(c); o.onClose = onClose;
      if (G().qa) setTimeout(() => o.close(), 5);
    },
    /* ---------------- inventory ---------------- */
    inventory() {
      if (G().mode !== 'play') return; const o = overlay('dim inv'); let tab = 'items', sel = null, comb = null; TLR.Input.clear();
      const c = h('div', 'card wide'); o.ov.appendChild(c);
      function render() {
        c.innerHTML = ''; const top = h('div', 'inv-top'); top.append(h('h2', '', 'Inventory')); const tabs = h('div', 'tabs'); ['items', 'clues'].forEach(t => { const b = h('button', 'tab' + (tab === t ? ' on' : ''), t === 'items' ? 'Items' : 'Clues'); b.onclick = () => { tab = t; sel = null; comb = null; A().sfx('click'); render(); }; tabs.append(b); }); top.append(tabs); c.append(top);
        const ids = Inv.list().filter(i => { const d = Inv.def(i); return d && (tab === 'clues' ? d.note : !d.note); }); const uniq = []; ids.forEach(i => { if (uniq.indexOf(i) < 0) uniq.push(i); });
        const body = h('div', 'inv-body'); const grid = h('div', 'inv-grid'); if (!uniq.length) grid.append(h('p', 'dim', tab === 'items' ? 'No items yet. Search the room.' : 'No clues yet. Read notes and examine photographs.'));
        uniq.forEach(i => { const d = Inv.def(i), cnt = Inv.count(i), b = h('button', 'slot' + (sel === i ? ' sel' : '') + (comb === i ? ' comb' : '')); const im = new Image(); im.src = U.itemIcon(d); b.append(im); if (cnt > 1) b.append(h('b', 'cnt', 'x' + cnt));
          b.onclick = () => { A().sfx('click'); if (comb && comb !== i) { const a = comb; comb = null; if (!G().combine(a, i)) { UI.toast("These don't fit together."); A().sfx('wrong'); } else { sel = null; } render(); return; } sel = i; render(); }; grid.append(b); });
        const det = h('div', 'inv-det'); if (sel && Inv.def(sel)) { const d = Inv.def(sel); const im = new Image(); im.src = U.itemIcon(d); det.append(im, h('h3', '', d.name), h('p', '', d.note ? d.text : d.desc)); const row = h('div', 'row');
          if (d.note) row.append(btn('Read', () => { o.close(); UI.reader({ title: d.name, text: d.text, kind2: d.kind2 }, () => { }); })); else { row.append(btn('Use', () => { if (G().useHeld(sel)) o.close(); else UI.toast('There is nothing to use it on here.'); })); row.append(btn(comb ? 'Cancel' : 'Combine', () => { comb = comb ? null : sel; if (comb) UI.toast('Select a second item to combine with.'); render(); }, comb ? 'danger' : '')); }
          det.append(row); } else det.append(h('p', 'dim', 'Select an item.')); body.append(grid, det); c.append(body); c.append(btn('Close', () => o.close()));
      }
      render(); if (G().qa) setTimeout(() => o.close(), 5);
    }
  };
})(window);
