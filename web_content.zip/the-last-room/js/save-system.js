/* THE LAST ROOM - save system (localStorage with in-memory fallback) */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {};
  const KEY = 'thelastroom.save.v1', SKEY = 'thelastroom.settings.v1';
  const mem = {};
  function store() { try { return g.localStorage; } catch (e) { return null; } }
  function rd(k) { try { const s = store(); const v = s ? s.getItem(k) : mem[k]; return v ? JSON.parse(v) : null; } catch (e) { return null; } }
  function wr(k, v) { const j = JSON.stringify(v); try { const s = store(); if (s) s.setItem(k, j); else mem[k] = j; } catch (e) { mem[k] = j; } }
  function blank() {
    return { v: 1, started: false, chapter: 1, level: '1-1', completed: [], unlocked: 1, inv: [], collected: {}, flags: {}, solved: {}, prog: {}, cp: {}, hints: 0, seen: {}, stars: {}, best: {}, lore: [], tut: false, deaths: 0, coins: 20 };
  }
  const Save = TLR.Save = {
    data: blank(),
    settings: { music: 0.85, sfx: 1, touch: 'auto', quality: 'high', lang: 'auto', vol: 2, diff: 'normal', vib: 'on', lefty: 'off', btn: 'medium', guide: 'on' },
    init() {
      const d = rd(KEY); if (d && d.v === 1) this.data = Object.assign(blank(), d);
      const s = rd(SKEY); if (s) { Object.assign(this.settings, s); if (s.vol !== 2) { this.settings.music = 0.85; this.settings.sfx = 1; this.settings.vol = 2; } }
    },
    save() { wr(KEY, this.data); },
    saveSettings() { wr(SKEY, this.settings); },
    hasSave() { return !!this.data.started; },
    newGame() { this.data = blank(); this.data.started = true; this.save(); },
    resetAll() { this.data = blank(); this.save(); },
    flags(id) { return this.data.flags[id] || (this.data.flags[id] = {}); },
    collected(id) { return this.data.collected[id] || (this.data.collected[id] = []); },
    solved(id) { return this.data.solved[id] || (this.data.solved[id] = []); },
    resetLevel(id) {
      delete this.data.flags[id]; delete this.data.collected[id]; delete this.data.solved[id]; delete this.data.cp[id];
      Object.keys(this.data.prog).forEach(k => { if (k.indexOf(id + ':') === 0) delete this.data.prog[k]; });
    },
    isDone(id) { return this.data.completed.indexOf(id) >= 0; }
  };
})(window);
