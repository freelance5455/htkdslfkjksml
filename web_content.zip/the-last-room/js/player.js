/* THE LAST ROOM - protagonist "Kai": procedurally drawn character baked into a sprite sheet (14 animations) + player entity */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {}, U = TLR.U, TAU = U.TAU;
  const CW = 84, CH = 100, OX = 42, OY = 92, SC = 2, OUT = '#07070c';
  const DEF = { ox: 0, oy: 0, sx: 1, sy: 1, lean: 0, drop: 0, hx: 0, hy: 0, hr: 0, t1: 0, k1: .1, t2: 0, k2: .1, a1: .1, b1: .2, a2: -.1, b2: .2, eye: 'open', mouth: 0, prop: null, propA: 0, fx: null, fl: 0 };
  const stroke = (c, w) => { c.lineWidth = w || 1.1; c.strokeStyle = OUT; c.stroke(); };
  function seg(c, x0, y0, x1, y1, w, col) { c.lineCap = 'round'; c.strokeStyle = OUT; c.lineWidth = w + 2; c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.stroke(); c.strokeStyle = col; c.lineWidth = w; c.stroke(); }
  function leg(c, hx, hy, t, k, back) {
    const L1 = 11.5, L2 = 11.5, kx = hx + Math.sin(t) * L1, ky = hy + Math.cos(t) * L1, s = t - k, ax = kx + Math.sin(s) * L2, ay = ky + Math.cos(s) * L2;
    const col = back ? '#2c3340' : '#3a4352';
    seg(c, hx, hy, kx, ky, 8, col); seg(c, kx, ky, ax, ay, 6.6, col);
    if (!back) { c.fillStyle = '#4a5468'; c.save(); c.translate((hx + kx) / 2, (hy + ky) / 2); c.rotate(-t); c.fillRect(-1, -2, 5, 5); c.strokeStyle = OUT; c.lineWidth = .8; c.strokeRect(-1, -2, 5, 5); c.restore(); }
    // sneaker
    c.save(); c.translate(ax, ay + 1.5); c.rotate(-s * .25);
    c.fillStyle = back ? '#101016' : '#17171e'; U.rr(c, -4.5, -2.5, 13, 6.5, 2.6); c.fill(); stroke(c, 1);
    c.fillStyle = '#efeff5'; c.fillRect(-4, 2, 12, 1.8); c.fillRect(5.5, -1.5, 3.2, 3.2); c.fillStyle = '#c0c0ca'; c.fillRect(-1, -1, 4, 1);
    c.restore();
  }
  function arm(c, sx, sy, a, b, front, p) {
    const L1 = 9, L2 = 8, ex = sx + Math.sin(a) * L1, ey = sy + Math.cos(a) * L1, fa = a + b, hx = ex + Math.sin(fa) * L2, hy = ey + Math.cos(fa) * L2;
    const col = front ? '#1d1d27' : '#13131a';
    seg(c, sx, sy, ex, ey, 6.4, col); seg(c, ex, ey, hx, hy, 5.6, col);
    if (front) { // wristwatch
      const wx = ex + Math.sin(fa) * L2 * .72, wy = ey + Math.cos(fa) * L2 * .72; c.save(); c.translate(wx, wy); c.rotate(-fa); c.fillStyle = '#c4cbd8'; c.fillRect(-3.2, -1.6, 6.4, 3.2); stroke(c, .8); c.fillStyle = '#233'; c.fillRect(-1.5, -.8, 3, 1.6); c.restore();
    }
    c.fillStyle = '#f2d1b1'; c.beginPath(); c.arc(hx, hy, 2.9, 0, TAU); c.fill(); stroke(c, .9);
    return [hx, hy];
  }
  function head(c, p) {
    c.save(); c.translate(3 + p.hx, -33 + p.hy); c.rotate(p.hr);
    // back hair
    c.fillStyle = '#0d0d15'; c.beginPath(); c.moveTo(-10, -2); c.quadraticCurveTo(-13, -10, -8, -13); c.lineTo(-13, -17); c.lineTo(-6, -15); c.lineTo(-7, -21); c.lineTo(0, -16); c.lineTo(3, -22); c.lineTo(6, -16); c.lineTo(12, -19); c.lineTo(10, -11); c.quadraticCurveTo(12, 0, 6, 6); c.lineTo(-8, 7); c.closePath(); c.fill(); stroke(c, 1);
    // face
    c.fillStyle = '#f4d4b5'; c.beginPath(); c.ellipse(1, 0, 10, 10.5, 0, 0, TAU); c.fill(); stroke(c, 1.1);
    c.fillStyle = '#e7b995'; c.beginPath(); c.ellipse(-8, 2, 2, 3, 0, 0, TAU); c.fill(); stroke(c, .8);
    // fringe
    c.fillStyle = '#0d0d15'; c.beginPath(); c.moveTo(-10, -2); c.quadraticCurveTo(-11, -12, -2, -14); c.quadraticCurveTo(8, -16, 11, -8); c.lineTo(9, -3); c.lineTo(7, -9); c.lineTo(5, -2); c.lineTo(2, -9); c.lineTo(-1, -3); c.lineTo(-3, -9); c.lineTo(-6, -2); c.closePath(); c.fill(); stroke(c, 1);
    c.strokeStyle = '#33426a'; c.lineWidth = .9; c.beginPath(); c.moveTo(-4, -12); c.quadraticCurveTo(1, -14, 6, -12); c.stroke();
    // eyes
    const ey = 1.2, ex = 5.6;
    if (p.eye === 'closed' || p.eye === 'happy') {
      c.strokeStyle = OUT; c.lineWidth = 1.6; c.lineCap = 'round'; c.beginPath(); if (p.eye === 'happy') { c.arc(ex, ey + 1.6, 3, Math.PI * 1.1, Math.PI * 1.9); c.moveTo(ex + 5.8 + 3, ey + 1.6); c.arc(ex + 5.8, ey + 1.6, 2.4, Math.PI * 1.1, Math.PI * 1.9); } else { c.moveTo(ex - 3.4, ey); c.lineTo(ex + 3.4, ey + .6); c.moveTo(ex + 3, ey + .3); c.lineTo(ex + 8.5, ey + .8); } c.stroke();
    } else if (p.eye === 'hurt') {
      c.strokeStyle = OUT; c.lineWidth = 1.6; c.lineCap = 'round'; c.beginPath(); c.moveTo(ex - 3, ey - 2.2); c.lineTo(ex + 2, ey); c.lineTo(ex - 3, ey + 2.2); c.moveTo(ex + 10, ey - 2); c.lineTo(ex + 6, ey); c.lineTo(ex + 10, ey + 2); c.stroke();
    } else {
      const w = p.eye === 'wide' ? 1.25 : 1;
      for (const far of [0, 1]) {
        const x = ex + far * 5.4, s = far ? .72 : 1;
        c.fillStyle = '#fff'; c.beginPath(); c.ellipse(x, ey, 3.5 * s * w, 4.8 * s * w, 0, 0, TAU); c.fill(); stroke(c, .8);
        c.fillStyle = U.lg(c, 0, ey - 4, 0, ey + 4, [[0, '#183e78'], [.6, '#3f8fd6'], [1, '#8fd0ff']]); c.beginPath(); c.ellipse(x + .5, ey + .4, 2.5 * s * (p.eye === 'wide' ? .8 : 1), 3.9 * s * w, 0, 0, TAU); c.fill();
        c.fillStyle = '#05070f'; c.beginPath(); c.ellipse(x + .6, ey + .5, 1.2 * s, 2 * s, 0, 0, TAU); c.fill();
        c.fillStyle = '#fff'; c.beginPath(); c.arc(x - .6, ey - 1.4, 1.1 * s, 0, TAU); c.fill(); c.beginPath(); c.arc(x + 1.5, ey + 1.8, .6 * s, 0, TAU); c.fill();
        c.strokeStyle = OUT; c.lineWidth = 1.5; c.beginPath(); c.moveTo(x - 3.6 * s, ey - 2 * s); c.quadraticCurveTo(x, ey - 5.6 * s * w, x + 3.6 * s, ey - 2.4 * s); c.stroke();
      }
      c.strokeStyle = '#0d0d15'; c.lineWidth = 1.3; c.beginPath(); c.moveTo(ex - 3, ey - 7.4); c.lineTo(ex + 4, ey - 7.9); c.moveTo(ex + 6.8, ey - 7.4); c.lineTo(ex + 11, ey - 6.4); c.stroke();
    }
    c.fillStyle = 'rgba(255,120,120,.25)'; c.beginPath(); c.ellipse(5, 6.2, 2.6, 1.3, 0, 0, TAU); c.fill();
    c.strokeStyle = '#6a3a30'; c.fillStyle = '#7a2a2a'; c.lineWidth = 1.1; c.lineCap = 'round'; c.beginPath();
    if (p.mouth === 1) { c.ellipse(9, 6.8, 1.5, 2.2, 0, 0, TAU); c.fill(); } else if (p.mouth === 2) { c.arc(8.5, 5, 2.4, .2, Math.PI - .2); c.stroke(); } else if (p.mouth === 3) { c.moveTo(7, 7.6); c.lineTo(8, 6.6); c.lineTo(9, 7.6); c.lineTo(10, 6.6); c.stroke(); } else { c.moveTo(7.6, 7); c.lineTo(10, 7); c.stroke(); }
    c.restore();
  }
  function drawChar(c, pp) {
    const p = Object.assign({}, DEF, pp);
    c.save(); c.translate(p.ox, p.oy); c.scale(p.sx, p.sy);
    // soft shadow
    c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(0, 0, 14, 3.2, 0, 0, TAU); c.fill();
    const hipY = -27 + p.drop;
    leg(c, -1, hipY, p.t2, p.k2, true);
    c.save(); c.translate(0, hipY); c.rotate(p.lean);
    arm(c, 0, -19, p.a2, p.b2, false, p);
    // backpack
    c.fillStyle = '#0c0c12'; U.rr(c, -17, -21, 10, 21, 3.5); c.fill(); stroke(c, 1); c.fillStyle = '#17171f'; U.rr(c, -16, -20, 7, 8, 2); c.fill(); c.strokeStyle = '#2b2b38'; c.lineWidth = .9; c.beginPath(); c.moveTo(-16, -10); c.lineTo(-9, -10); c.stroke(); c.fillStyle = '#3a3a48'; c.fillRect(-12.5, -8, 2, 3);
    // hood bunch
    c.fillStyle = '#16161e'; c.beginPath(); c.ellipse(-6, -22, 7, 4.5, -.3, 0, TAU); c.fill(); stroke(c, 1);
    // torso (oversized hoodie)
    c.fillStyle = '#1b1b25'; c.beginPath(); c.moveTo(-10, 1.5); c.quadraticCurveTo(-13, -9, -9.5, -19); c.quadraticCurveTo(-3, -23, 7, -22); c.quadraticCurveTo(10, -19, 11, -8); c.quadraticCurveTo(12, -2, 10.5, 2); c.closePath(); c.fill(); stroke(c, 1.2);
    c.fillStyle = '#e9ebf2'; c.beginPath(); c.moveTo(-9.5, 1.2); c.lineTo(10.2, 1.4); c.lineTo(10, 3.6); c.lineTo(-9.8, 3.4); c.closePath(); c.fill(); stroke(c, .8);
    c.beginPath(); c.moveTo(3, -22); c.lineTo(7, -22); c.lineTo(5.5, -15); c.closePath(); c.fillStyle = '#e9ebf2'; c.fill();
    c.strokeStyle = '#2e2e3c'; c.lineWidth = 1; c.beginPath(); c.moveTo(-6, -4); c.quadraticCurveTo(0, 1, 7, -4); c.moveTo(-1, -14); c.lineTo(-3, -8); c.stroke();
    c.strokeStyle = '#d8d8e4'; c.lineWidth = .9; c.beginPath(); c.moveTo(3.5, -19); c.lineTo(3, -13); c.moveTo(6.5, -19); c.lineTo(7, -13); c.stroke();
    c.fillStyle = '#f4d4b5'; c.fillRect(1, -25, 5, 4);
    head(c, p);
    c.restore();
    leg(c, 1, hipY, p.t1, p.k1, false);
    c.save(); c.translate(0, hipY); c.rotate(p.lean);
    const h = arm(c, 1, -19, p.a1, p.b1, true, p);
    if (p.prop) { c.save(); c.translate(h[0], h[1]); c.rotate(p.propA); if (p.prop === 'key') { c.fillStyle = '#e8c35e'; c.beginPath(); c.arc(2, 0, 3, 0, TAU); c.fill(); c.fillRect(4, -.8, 7, 1.8); c.fillRect(9, 0, 1.6, 3); stroke(c, .7); } else { c.shadowColor = '#9fe8ff'; c.shadowBlur = 8; c.fillStyle = '#cff4ff'; c.beginPath(); c.moveTo(0, -5); c.lineTo(3.5, 0); c.lineTo(0, 5); c.lineTo(-3.5, 0); c.closePath(); c.fill(); } c.restore(); }
    c.restore();
    if (p.fx === 'shock') { c.strokeStyle = '#fff'; c.lineWidth = 1.6; c.lineCap = 'round'; c.beginPath(); for (const [a, b, d, e] of [[-6, -72, -9, -78], [4, -74, 4, -81], [14, -72, 17, -78]]) { c.moveTo(a, b); c.lineTo(d, e); } c.stroke(); }
    if (p.fx === 'solve') { c.fillStyle = 'rgba(255,230,120,' + (.4 + .5 * Math.sin(p.fl * 6)) + ')'; c.beginPath(); c.arc(14, -64, 2.5, 0, TAU); c.fill(); c.beginPath(); c.arc(-4, -72, 1.8, 0, TAU); c.fill(); }
    if (p.fx === 'victory') { c.fillStyle = '#ffe28a'; for (let i = 0; i < 4; i++) { const a = p.fl * 3 + i * 1.6; c.beginPath(); c.arc(Math.cos(a) * 22, -50 + Math.sin(a) * 26, 1.6, 0, TAU); c.fill(); } }
    c.restore();
  }
  /* ---------- animation definitions: [frameCount, fps, loop, poseFn(i,n)] ---------- */
  const S = Math.sin, C = Math.cos;
  const ANIMS = {
    idle: [8, 5, true, (i, n) => { const ph = i / n * TAU; return { drop: .5 + S(ph) * .7, hy: S(ph + 1) * .5, a1: .08 + S(ph) * .04, a2: -.08 - S(ph) * .04, eye: (i === 6) ? 'closed' : 'open', t1: .05, t2: -.05, k1: .05, k2: .05 }; }],
    walk: [8, 11, true, (i, n) => { const ph = i / n * TAU; return { t1: S(ph) * .62, k1: .1 + .75 * Math.max(0, C(ph)), t2: S(ph + Math.PI) * .62, k2: .1 + .75 * Math.max(0, C(ph + Math.PI)), a1: -S(ph) * .55, b1: .35, a2: S(ph) * .55, b2: .35, drop: 1 + 3 * Math.abs(S(ph)), lean: .06, hr: S(ph * 2) * .02 }; }],
    run: [8, 15, true, (i, n) => { const ph = i / n * TAU; return { t1: S(ph) * .95, k1: .3 + 1.2 * Math.max(0, C(ph)), t2: S(ph + Math.PI) * .95, k2: .3 + 1.2 * Math.max(0, C(ph + Math.PI)), a1: -S(ph) * .95, b1: 1.2, a2: S(ph) * .95, b2: 1.2, drop: 2 + 4 * Math.abs(S(ph * 2)) * .6, lean: .24, hy: 1, hr: .05, mouth: 1 }; }],
    jump: [3, 1, false, (i) => [{ t1: .5, k1: 1, t2: -.3, k2: .6, a1: 2.3, b1: .3, a2: 2.0, b2: .3, drop: -1, eye: 'open', hy: -1, lean: .05 }, { t1: .9, k1: 1.3, t2: .3, k2: 1.1, a1: 1.7, b1: .4, a2: 1.3, b2: .5, drop: -2, lean: .08 }, { t1: .25, k1: .2, t2: -.25, k2: .15, a1: 1.5, b1: .1, a2: 1.1, b2: .1, drop: -1, hy: .5, eye: 'wide', mouth: 1 }][i]],
    land: [3, 14, false, (i) => [{ drop: 9, t1: .95, k1: 1.9, t2: .8, k2: 1.7, lean: .3, a1: .9, b1: .3, a2: .6, b2: .3, sy: .96 }, { drop: 6, t1: .7, k1: 1.4, t2: .6, k2: 1.3, lean: .2, a1: .5, b1: .3, a2: .3, b2: .3 }, { drop: 2, t1: .25, k1: .5, t2: .15, k2: .4, lean: .08 }][i]],
    crouch: [2, 6, true, (i) => ({ drop: 9, t1: 1, k1: 1.95, t2: .85, k2: 1.8, lean: .28, hx: 1, hy: 1 + i * .4, a1: .8, b1: .5, a2: .4, b2: .6, hr: .06 })],
    inspect: [6, 5, true, (i, n) => { const ph = i / n * TAU; return { lean: .14, drop: 1.5, hx: 1.5, hy: 1, hr: .12 + S(ph) * .05, a1: .55, b1: 1.95 + S(ph) * .08, a2: -.05, b2: .3, t1: .15, t2: -.1, k1: .2, k2: .1, eye: i === 4 ? 'closed' : 'open', mouth: 0 }; }],
    door: [6, 9, false, (i) => [{ a1: .3, b1: .3, lean: .05 }, { a1: 1.0, b1: .2, lean: .1 }, { a1: 1.55, b1: .05, lean: .12 }, { a1: 1.55, b1: .05, lean: .2, drop: 1.5, t1: .3, k1: .4 }, { a1: 1.5, b1: .05, lean: .24, drop: 2, t1: .5, k1: .5, t2: -.2 }, { a1: .6, b1: .2, lean: .1 }][i]],
    pickup: [6, 8, false, (i) => [{ lean: .1, drop: 2 }, { lean: .45, drop: 6, a1: .7, b1: .2, t1: .8, k1: 1.4, t2: .5, k2: 1, hy: 1 }, { lean: .6, drop: 9, a1: .95, b1: .15, t1: 1, k1: 1.9, t2: .7, k2: 1.5, hy: 2, hx: 2 }, { lean: .6, drop: 9, a1: .95, b1: .15, t1: 1, k1: 1.9, t2: .7, k2: 1.5, hx: 2, hy: 2, prop: 'item' }, { lean: .25, drop: 4, a1: .6, b1: .8, t1: .5, k1: .9, prop: 'item', hy: 1 }, { lean: .02, drop: 0, a1: .9, b1: 1.6, prop: 'item', eye: 'open', mouth: 2 }][i]],
    usekey: [6, 8, false, (i) => ({ lean: .12, drop: 1.5, a1: 1.45, b1: .1, a2: .1, b2: .3, prop: 'key', propA: -.3 + i * .35, t1: .2, k1: .3, hy: 0.5, mouth: 0, hr: .05 })],
    solve: [8, 9, true, (i, n) => { const ph = i / n * TAU; return { lean: .12, drop: 1.5, a1: 1.2 + S(ph) * .25, b1: .55, a2: 1.0 + S(ph + 2) * .25, b2: .7, hy: .5, hx: 1, hr: S(ph) * .05, eye: 'open', fx: 'solve', fl: ph, t1: .2, t2: -.05, mouth: i % 4 === 2 ? 2 : 0 }; }],
    shock: [4, 12, false, (i) => [{ lean: -.05, a1: .5, b1: .8, a2: .4, b2: .8, eye: 'wide', mouth: 1 }, { ox: -3, lean: -.18, drop: 1, a1: 2.3, b1: .3, a2: 2.0, b2: .4, t1: .5, t2: -.4, k1: .3, k2: .3, eye: 'wide', mouth: 1, hy: -1, fx: 'shock' }, { ox: -4, lean: -.22, a1: 2.45, b1: .2, a2: 2.15, b2: .3, t1: .4, t2: -.4, eye: 'wide', mouth: 1, hy: -1.5, fx: 'shock' }, { ox: -4, lean: -.2, a1: 2.4, b1: .25, a2: 2.1, b2: .3, t1: .4, t2: -.4, eye: 'wide', mouth: 1, hy: -1.5, fx: 'shock' }][i]],
    hurt: [4, 10, false, (i) => [{ ox: -2, lean: -.2, eye: 'hurt', mouth: 3, a1: .7, b1: 1.8, a2: .6, b2: .8, t1: .3, t2: -.3 }, { ox: -5, lean: -.35, eye: 'hurt', mouth: 3, a1: .6, b1: 2, a2: -.7, b2: .3, hr: -.12, t1: .4, t2: -.5, drop: 2, hx: -2 }, { ox: -4, lean: -.28, eye: 'hurt', mouth: 3, a1: .6, b1: 2, a2: .3, b2: .6, hr: -.1, t1: .3, t2: -.4, drop: 3 }, { ox: -2, lean: -.12, eye: 'hurt', mouth: 3, a1: .5, b1: 1.8, a2: .2, b2: .5, drop: 2 }][i]],
    victory: [8, 8, true, (i, n) => { const ph = i / n * TAU, up = Math.max(0, S(ph)); return { oy: -up * 6, a1: 3.0, b1: .05, a2: .7, b2: 1.6, lean: -.04, drop: 1 - up * 2, t1: .3 * up, k1: .2 + up * .6, t2: -.2 * up, k2: .2 + up * .6, eye: 'happy', mouth: 2, hy: -up, fx: 'victory', fl: ph }; }]
  };
  const NAMES = Object.keys(ANIMS), sheet = {};
  const Player = TLR.Player = {
    NAMES, ANIMS,
    bake() {
      if (this.sheet) return;
      const maxF = 8, cv = U.mk(maxF * CW * SC, NAMES.length * CH * SC), c = cv.getContext('2d');
      NAMES.forEach((nm, r) => { const [n, , , fn] = ANIMS[nm]; for (let i = 0; i < n; i++) { c.save(); c.translate(i * CW * SC, r * CH * SC); c.scale(SC, SC); c.translate(OX, OY); drawChar(c, fn(i, n)); c.restore(); } sheet[nm] = r; });
      this.sheet = cv;
    },
    frameCount(nm) { return ANIMS[nm][0]; },
    fps(nm) { return ANIMS[nm][1]; },
    loops(nm) { return ANIMS[nm][2]; },
    draw(c, x, y, nm, fr, face, scale) {
      const a = ANIMS[nm] || ANIMS.idle; const r = sheet[nm] != null ? sheet[nm] : 0; fr = Math.max(0, Math.min(a[0] - 1, fr | 0)); const s = scale || 1;
      c.save(); c.translate(x, y); if (face < 0) c.scale(-1, 1); c.drawImage(this.sheet, fr * CW * SC, r * CH * SC, CW * SC, CH * SC, -OX * s, -OY * s, CW * s, CH * s); c.restore();
    },
    portrait(cv) { const c = cv.getContext('2d'), w = cv.width; c.clearRect(0, 0, w, w); c.fillStyle = U.rg(c, w / 2, w / 2, 2, w * .7, [[0, '#2a3552'], [1, '#0a0d18']]); c.fillRect(0, 0, w, w); const sz = 62 * SC; c.drawImage(this.sheet, (OX - 28) * SC, (OY - 94) * SC, sz, sz, 0, 0, w, w); }
  };
})(window);
