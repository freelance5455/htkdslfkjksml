/* THE LAST ROOM - localisation. Detects the device language, swaps every on-screen text (menus, notes, puzzles, story)
   for the matching dictionary and falls back to English. Dictionaries live in js/lang-XX.js: TLR.I18N.add('xx','Name',{English:'Translated'}). */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {};
  const dicts = {}, names = { en: 'English' }, RTL = ['ar', 'he', 'fa', 'ur'];
  let refs = null;
  /* level / chapter fields that are shown to the player (everything else in the data is logic and is never touched) */
  const KEYS = ['name', 'tag', 'intro', 'outro', 'title', 'text', 'lab', 'msg', 'nm', 'desc', 'exitNm', 'msgLocked'];
  function collect() {
    refs = [];
    const add = (o, k) => { const v = o[k]; if (typeof v === 'string') refs.push([o, k, v]); };
    const item = it => { if (it && typeof it === 'object') { add(it, 'name'); add(it, 'desc'); } };
    (TLR.CHAPTERS || []).forEach(c => ['name', 'tag', 'intro', 'outro'].forEach(k => add(c, k)));
    (TLR.LEVELS || []).forEach(l => {
      add(l, 'name'); add(l, 'exitNm');
      (l.intro || []).forEach((_, i) => add(l.intro, i));
      (l.steps || []).forEach(s => { add(s, 1); add(s, 2); });
      (l.objects || []).forEach(o => { ['title', 'text', 'lab', 'msg', 'nm', 'msgLocked'].forEach(k => add(o, k)); item(o.item); [].concat(o.give || []).forEach(item); });
      (l.recipes || []).forEach(r => { item(r.out); add(r, 'msg'); });
    });
  }
  const I = TLR.I18N = {
    lang: 'en',
    add(code, name, dict) { dicts[code] = Object.assign(dicts[code] || {}, dict); if (name) names[code] = name; },
    list() { return ['en'].concat(Object.keys(dicts).filter(k => k !== 'en')); },
    name(c) { return names[c] || c; },
    /* which language to use: the player's choice, else the device language, else English */
    detect() {
      const pref = (TLR.Save && TLR.Save.settings && TLR.Save.settings.lang) || 'auto';
      if (pref !== 'auto') return pref === 'en' || dicts[pref] ? pref : 'en';
      let langs = []; try { langs = (navigator.languages && navigator.languages.length) ? navigator.languages : [navigator.language || 'en']; } catch (e) { }
      for (const l of langs) { const c = String(l).toLowerCase().split('-')[0]; if (c === 'en') return 'en'; if (dicts[c]) return c; }
      return 'en';
    },
    /* translate a string; {0} {1} are replaced by the extra arguments */
    t(s, ...a) {
      if (typeof s !== 'string') return s;
      const d = dicts[I.lang]; let r = d && d[s] != null ? d[s] : s;
      if (a.length) r = r.replace(/\{(\d+)\}/g, (m, i) => a[i] != null ? a[i] : m);
      return r;
    },
    /* choose the language and re-apply it to level data, items and the static HTML */
    setLang(code) {
      I.lang = code || I.detect();
      try { document.documentElement.lang = I.lang; document.documentElement.dir = RTL.indexOf(I.lang) >= 0 ? 'rtl' : 'ltr'; } catch (e) { }
      if (!refs) collect();
      refs.forEach(r => { r[0][r[1]] = I.t(r[2]); });
      if (TLR.Inv && TLR.Inv.build) TLR.Inv.build();
      I.dom();
    },
    dom() { document.querySelectorAll('[data-i18n]').forEach(e => { if (!e.dataset.en) e.dataset.en = e.textContent; e.textContent = I.t(e.dataset.en); }); },
    init() { I.setLang(I.detect()); }
  };
})(window);
