THE LAST ROOM - Escape / Solve / Survive
Open index.html in any modern browser (Chrome on Android recommended, landscape). No install, no server, works offline.
Desktop: A/D or arrows move, Shift run, Space jump, S/Down crouch, E/Enter interact, I inventory, H hint, P/Esc pause.
Mobile: on-screen buttons (left/right, Jump, Crouch, Interact, Bag).
Structure: js/level-data.js = all 50 levels (data only); puzzle-engine.js = 14 puzzle types; scenery.js/props.js/player.js = all art (drawn with Canvas);
audio-manager.js = synthesized music/sfx. Self-test: open index.html?qa=1 and run TLR.Game.qaStep() in the console.

LANGUAGES
The game picks the device language automatically (Settings > Language can override it). Dictionaries live in js/lang-XX.js
(English is the source text; Bengali = js/lang-bn.js). To add a language, copy lang-bn.js, translate the values and load it in index.html + sw.js.

HORROR TASK MODE
Every level is a job (restore power, light braziers...). Search furniture for parts, use them at the station (a touch puzzle), survive the ghost.
Ghosts: Wailer (hunts), Sensor (follows noise - crouch to be quiet), Watcher (freezes when you face it), Seeker (may find you in hiding - use Light).
Survive: hide (Interact at wardrobes/lockers/curtains), Light button / F key (stuns the ghost), or run (ghost is slower than running).
Levels x-3 are blackouts, the last level of each chapter is a boss haunt. Stars: finish, no deaths, under par time.
Settings: difficulty, vibration, left-handed buttons, button size, guidance icons, language.
