# LIFE CITY — Lightweight Playable MVP

This is the first, lightweight-but-fully-playable version of LIFE CITY, built in the
order requested: **Login → Character → City → Movement → Multiplayer → Jobs →
Money → House → Admin.**

Everything listed below actually works end-to-end (real accounts, a real
database, real multiplayer sync, real jobs that pay real money, real house
purchases, and a real server-checked admin system) — it is not a mockup.

Deferred to later updates (the project is structured so you can add these
without breaking anything): cars/driving, clothing shop & inventory items,
wandering NPCs, admin UI for adding characters/clothes, a rendered minimap,
and a Low/Medium/High graphics-quality toggle.

## 1. Folder structure

```
life-city/
  backend/            ← Node.js server (API + multiplayer + database)
    server.js
    db.js
    auth.js
    package.json
    .env.example
    data/              ← SQLite file lives here (created automatically)
  frontend/           ← static files, open directly in a browser or host anywhere
    index.html
    admin.html
    style.css
    config.js          ← ONLY file to edit when you change the backend's address
    game.js
    admin.js
```

The **frontend never touches the database directly** — it only talks to the
backend over HTTP + WebSockets. That separation is what makes it possible to
update the game safely (see section 9).

## 2. Running it locally

```bash
cd life-city/backend
npm install
cp .env.example .env     # edit JWT_SECRET and ADMIN_USERNAME inside
npm start                # starts the backend on http://localhost:3000
```

In a second terminal, serve the frontend folder with any static file server, e.g.:

```bash
cd life-city/frontend
npx serve .               # or: python3 -m http.server 8080
```

Open the printed local URL in your browser (or on your phone over the same
Wi-Fi, using your computer's local IP, to test touch controls).
`frontend/config.js` defaults to `http://localhost:3000` for both the API and
the realtime connection — that's correct for local testing.

## 3. How the database works

- The backend uses **SQLite** (via `better-sqlite3`) — a single file, no
  separate database server to install.
- Its path is set by `DB_PATH` in `.env` (default `./data/lifecity.db`).
- Tables: `users`, `houses`, `jobs`, `job_sessions` — created automatically
  on first run, with starter houses and jobs seeded once.
- If you later outgrow SQLite (hundreds of concurrent players), the queries
  in `db.js` are plain SQL and port over to Postgres/MySQL with small changes.

## 4. Creating the Admin account

There is exactly **one** admin, and it is decided entirely on the server:

1. In `.env`, set `ADMIN_USERNAME=whatever-you-want`.
2. Register a normal account in the game using exactly that username.
3. That's it — every admin API route (`/api/admin/*`) checks
   `req.user.username === ADMIN_USERNAME` on the server before doing
   anything. There is no client-side "isAdmin" flag that can be edited to
   grant access — the `ADMIN` button simply doesn't appear for anyone else,
   and even if someone forced it to appear, every admin request would still
   be rejected with `403` by the backend.

## 5. Updating the game without wiping players

- `data/lifecity.db` (your players, money, houses, jobs) is **never**
  inside the code you redeploy. Replace `backend/*.js` and everything in
  `frontend/` freely — the database file is untouched.
- **Never delete `data/lifecity.db`** and never run `DROP TABLE` in
  production. If you need to change the schema later, add new columns with
  `ALTER TABLE` in a small migration script rather than recreating tables.
- Before a big update, just copy `data/lifecity.db` somewhere safe as a backup.

## 6. Putting it online

Cheapest reliable path for this stack:

1. **Backend** → a small Node host with a persistent disk, e.g. **Railway**
   or **Render** (paid tier, or free tier **with a persistent volume** —
   SQLite needs its file to survive restarts/redeploys, so double-check the
   plan keeps `data/` around). Set the same environment variables from
   `.env` in the host's dashboard.
2. **Frontend** → any static host (Netlify, Vercel, GitHub Pages, or just
   the same box as the backend via `express.static`). Edit
   `frontend/config.js` to point `API_URL`/`SOCKET_URL` at your backend's
   public URL (e.g. `https://life-city-backend.up.railway.app`).
3. Make sure `CORS_ORIGIN` in the backend's `.env` matches your frontend's
   real domain once you're live (not `*`).
4. Share the frontend's URL — players only ever need that link, a
   username, and a password. No Claude account, ever.

## 7. Connecting to the database remotely

For SQLite there's nothing to "connect" externally — it's just the file at
`DB_PATH` next to the backend process. If you migrate to Postgres later,
you'd set a `DATABASE_URL` connection string in `.env` instead and swap the
queries in `db.js` for a Postgres client (e.g. `pg`); the rest of the server
(routes, sockets, auth) stays the same.

## 8. What's in this MVP, mapped to your spec

| Your spec section | Status in this build |
|---|---|
| Third-person camera, smooth follow | ✅ drag-to-orbit + smoothed follow, adjustable distance |
| 10 selectable, customizable cartoon characters | ✅ 10 original presets × 10 colors |
| A small living city (shop, bank, garage, park, etc.) | ✅ simplified low-poly layout |
| Jobs (8 starter jobs, timed, paid) | ✅ real server-timed sessions |
| Money / Bank / Inventory | ✅ money + bank; inventory slot left for a future update |
| Houses (view, price, buy, own) | ✅ |
| Cars | ⏳ next update (noted above) |
| Real multiplayer (see others, names) | ✅ Socket.io, throttled position sync |
| Touch controls (joystick, camera area, buttons) | ✅ |
| Keyboard + mouse controls | ✅ WASD / Shift / Space / E / Esc |
| One server-enforced Admin | ✅ ban/unban, edit money, broadcast, add jobs/houses |
| Updates never wipe player data | ✅ DB file fully separate from code |
| Register / Login / Logout | ✅ |

Next natural additions, in the structure already laid out: cars (new
`cars` table + a driving state in `game.js`), a clothing shop and
`inventory` table, simple patrolling NPCs, and an admin UI tab for
characters/clothes/cars.
