// db.js — all database setup and seed data lives here.
// The DB file (DB_PATH) is completely separate from the game/code files,
// so replacing the backend or frontend code on update NEVER touches it.

const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = process.env.DB_PATH || './data/lifecity.db';
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  money INTEGER NOT NULL DEFAULT 500,
  bank INTEGER NOT NULL DEFAULT 0,
  character_preset INTEGER NOT NULL DEFAULT 0,
  character_color TEXT NOT NULL DEFAULT '#58b0ff',
  pos_x REAL NOT NULL DEFAULT 0,
  pos_y REAL NOT NULL DEFAULT 0,
  pos_z REAL NOT NULL DEFAULT 0,
  house_id INTEGER DEFAULT NULL,
  is_banned INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS houses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  price INTEGER NOT NULL,
  x REAL NOT NULL, y REAL NOT NULL, z REAL NOT NULL,
  owner_id INTEGER DEFAULT NULL REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  x REAL NOT NULL, y REAL NOT NULL, z REAL NOT NULL,
  duration_seconds INTEGER NOT NULL,
  pay INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS job_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  job_id INTEGER NOT NULL REFERENCES jobs(id),
  started_at TEXT NOT NULL,
  completed INTEGER NOT NULL DEFAULT 0
);
`);

// Seed starter houses/jobs only once
const houseCount = db.prepare('SELECT COUNT(*) c FROM houses').get().c;
if (houseCount === 0) {
  const insertHouse = db.prepare('INSERT INTO houses (name, price, x, y, z) VALUES (?,?,?,?,?)');
  insertHouse.run('Small Apartment', 1200, 30, 0, -20);
  insertHouse.run('Cozy Cottage', 3000, 55, 0, -10);
  insertHouse.run('City House', 7500, 70, 0, 15);
  insertHouse.run('Riverside Villa', 15000, -40, 0, 40);
}

const jobCount = db.prepare('SELECT COUNT(*) c FROM jobs').get().c;
if (jobCount === 0) {
  const insertJob = db.prepare('INSERT INTO jobs (name, x, y, z, duration_seconds, pay) VALUES (?,?,?,?,?,?)');
  insertJob.run('Taxi Driver', -20, 0, 0, 20, 80);
  insertJob.run('Delivery', 10, 0, 25, 15, 60);
  insertJob.run('Mechanic', -35, 0, -15, 25, 100);
  insertJob.run('Shop Worker', 5, 0, -30, 20, 70);
  insertJob.run('Builder', 40, 0, 0, 30, 120);
  insertJob.run('Security', -10, 0, 10, 20, 90);
  insertJob.run('Doctor', 20, 0, -5, 30, 150);
  insertJob.run('Bus Driver', 0, 0, 40, 25, 100);
}

module.exports = db;
