// auth.js — password hashing + JWT helpers + express middleware.
// IMPORTANT: admin status is NEVER trusted from the client. It is decided
// here, on the server, by comparing the logged-in username to ADMIN_USERNAME.

const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const JWT_SECRET = process.env.JWT_SECRET || 'insecure_dev_secret_change_me';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'owner';

function hashPassword(pw) {
  return bcrypt.hashSync(pw, 10);
}
function checkPassword(pw, hash) {
  return bcrypt.compareSync(pw, hash);
}
function signToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username },
    JWT_SECRET,
    { expiresIn: '30d' }
  );
}
function verifyToken(token) {
  try { return jwt.verify(token, JWT_SECRET); } catch { return null; }
}

// Express middleware: requires a valid Bearer token, attaches req.user
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  const payload = token && verifyToken(token);
  if (!payload) return res.status(401).json({ error: 'Not authenticated' });
  req.user = payload;
  next();
}

// Express middleware: requires requireAuth to have run first, and that the
// authenticated username matches the one and only admin account.
function requireAdmin(req, res, next) {
  if (!req.user || req.user.username !== ADMIN_USERNAME) {
    return res.status(403).json({ error: 'Admin access only' });
  }
  next();
}

module.exports = {
  hashPassword, checkPassword, signToken, verifyToken,
  requireAuth, requireAdmin, ADMIN_USERNAME
};
