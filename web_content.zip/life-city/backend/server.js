// server.js — LIFE CITY backend: REST API + realtime multiplayer (Socket.io)
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const db = require('./db');
const {
  hashPassword, checkPassword, signToken, verifyToken,
  requireAuth, requireAdmin, ADMIN_USERNAME
} = require('./auth');

const app = express();
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CORS_ORIGIN || '*' } });

// ---------- helpers ----------
function publicUser(u) {
  return {
    id: u.id, username: u.username,
    money: u.money, bank: u.bank,
    characterPreset: u.character_preset, characterColor: u.character_color,
    pos: { x: u.pos_x, y: u.pos_y, z: u.pos_z },
    houseId: u.house_id,
    isAdmin: u.username === ADMIN_USERNAME,
    isBanned: !!u.is_banned
  };
}

// ---------- AUTH ----------
app.post('/api/register', (req, res) => {
  const { username, password, characterPreset, characterColor } = req.body || {};
  if (!username || !password || username.length < 3 || password.length < 4) {
    return res.status(400).json({ error: 'Username (3+) and password (4+) required' });
  }
  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (exists) return res.status(409).json({ error: 'Username already taken' });

  const info = db.prepare(
    `INSERT INTO users (username, password_hash, character_preset, character_color)
     VALUES (?,?,?,?)`
  ).run(username, hashPassword(password), characterPreset || 0, characterColor || '#58b0ff');

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  res.json({ token: signToken(user), user: publicUser(user) });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !checkPassword(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  if (user.is_banned) return res.status(403).json({ error: 'This account is banned' });
  res.json({ token: signToken(user), user: publicUser(user) });
});

app.get('/api/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user: publicUser(user) });
});

app.post('/api/character', requireAuth, (req, res) => {
  const { characterPreset, characterColor } = req.body || {};
  db.prepare('UPDATE users SET character_preset=?, character_color=? WHERE id=?')
    .run(characterPreset ?? 0, characterColor || '#58b0ff', req.user.id);
  res.json({ ok: true });
});

// ---------- HOUSES ----------
app.get('/api/houses', requireAuth, (req, res) => {
  res.json({ houses: db.prepare('SELECT * FROM houses').all() });
});

app.post('/api/houses/buy', requireAuth, (req, res) => {
  const { houseId } = req.body || {};
  const house = db.prepare('SELECT * FROM houses WHERE id=?').get(houseId);
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (!house) return res.status(404).json({ error: 'House not found' });
  if (house.owner_id) return res.status(409).json({ error: 'House already owned' });
  if (user.money < house.price) return res.status(400).json({ error: 'Not enough money' });

  db.prepare('UPDATE houses SET owner_id=? WHERE id=?').run(user.id, house.id);
  db.prepare('UPDATE users SET money = money - ?, house_id=? WHERE id=?')
    .run(house.price, house.id, user.id);
  res.json({ ok: true });
});

// ---------- JOBS ----------
app.get('/api/jobs', requireAuth, (req, res) => {
  res.json({ jobs: db.prepare('SELECT * FROM jobs').all() });
});

app.post('/api/jobs/start', requireAuth, (req, res) => {
  const { jobId } = req.body || {};
  const job = db.prepare('SELECT * FROM jobs WHERE id=?').get(jobId);
  if (!job) return res.status(404).json({ error: 'Job not found' });

  const open = db.prepare(
    `SELECT * FROM job_sessions WHERE user_id=? AND completed=0 ORDER BY id DESC LIMIT 1`
  ).get(req.user.id);
  if (open) return res.status(409).json({ error: 'A job is already in progress' });

  const info = db.prepare(
    `INSERT INTO job_sessions (user_id, job_id, started_at) VALUES (?,?,datetime('now'))`
  ).run(req.user.id, jobId);
  res.json({ sessionId: info.lastInsertRowid, durationSeconds: job.duration_seconds });
});

app.post('/api/jobs/complete', requireAuth, (req, res) => {
  const { sessionId } = req.body || {};
  const session = db.prepare('SELECT * FROM job_sessions WHERE id=? AND user_id=?')
    .get(sessionId, req.user.id);
  if (!session || session.completed) return res.status(400).json({ error: 'No active session' });

  const job = db.prepare('SELECT * FROM jobs WHERE id=?').get(session.job_id);
  const elapsed = (Date.now() - new Date(session.started_at + 'Z').getTime()) / 1000;
  if (elapsed < job.duration_seconds) {
    return res.status(400).json({ error: 'Job not finished yet', remaining: job.duration_seconds - elapsed });
  }
  db.prepare('UPDATE job_sessions SET completed=1 WHERE id=?').run(sessionId);
  db.prepare('UPDATE users SET money = money + ? WHERE id=?').run(job.pay, req.user.id);
  res.json({ ok: true, pay: job.pay });
});

// ---------- BANK ----------
app.post('/api/bank/deposit', requireAuth, (req, res) => {
  const amount = Math.floor(Number(req.body?.amount) || 0);
  if (amount <= 0) return res.status(400).json({ error: 'Invalid amount' });
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (user.money < amount) return res.status(400).json({ error: 'Not enough cash' });
  db.prepare('UPDATE users SET money=money-?, bank=bank+? WHERE id=?').run(amount, amount, user.id);
  res.json({ ok: true });
});
app.post('/api/bank/withdraw', requireAuth, (req, res) => {
  const amount = Math.floor(Number(req.body?.amount) || 0);
  if (amount <= 0) return res.status(400).json({ error: 'Invalid amount' });
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (user.bank < amount) return res.status(400).json({ error: 'Not enough in bank' });
  db.prepare('UPDATE users SET money=money+?, bank=bank-? WHERE id=?').run(amount, amount, user.id);
  res.json({ ok: true });
});

// ---------- ADMIN (every route re-checks on the server, every time) ----------
app.get('/api/admin/players', requireAuth, requireAdmin, (req, res) => {
  const users = db.prepare('SELECT * FROM users').all();
  res.json({ players: users.map(publicUser) });
});
app.post('/api/admin/ban', requireAuth, requireAdmin, (req, res) => {
  db.prepare('UPDATE users SET is_banned=1 WHERE id=?').run(req.body.userId);
  io.to(`user:${req.body.userId}`).emit('forceDisconnect', { reason: 'banned' });
  res.json({ ok: true });
});
app.post('/api/admin/unban', requireAuth, requireAdmin, (req, res) => {
  db.prepare('UPDATE users SET is_banned=0 WHERE id=?').run(req.body.userId);
  res.json({ ok: true });
});
app.post('/api/admin/set-money', requireAuth, requireAdmin, (req, res) => {
  db.prepare('UPDATE users SET money=? WHERE id=?').run(req.body.money, req.body.userId);
  res.json({ ok: true });
});
app.post('/api/admin/jobs/add', requireAuth, requireAdmin, (req, res) => {
  const { name, x, y, z, durationSeconds, pay } = req.body;
  db.prepare('INSERT INTO jobs (name,x,y,z,duration_seconds,pay) VALUES (?,?,?,?,?,?)')
    .run(name, x, y, z, durationSeconds, pay);
  res.json({ ok: true });
});
app.post('/api/admin/jobs/delete', requireAuth, requireAdmin, (req, res) => {
  db.prepare('DELETE FROM jobs WHERE id=?').run(req.body.jobId);
  res.json({ ok: true });
});
app.post('/api/admin/houses/add', requireAuth, requireAdmin, (req, res) => {
  const { name, price, x, y, z } = req.body;
  db.prepare('INSERT INTO houses (name,price,x,y,z) VALUES (?,?,?,?,?)').run(name, price, x, y, z);
  res.json({ ok: true });
});
app.post('/api/admin/houses/delete', requireAuth, requireAdmin, (req, res) => {
  db.prepare('DELETE FROM houses WHERE id=?').run(req.body.houseId);
  res.json({ ok: true });
});
app.post('/api/admin/broadcast', requireAuth, requireAdmin, (req, res) => {
  io.emit('adminMessage', { text: req.body.text || '' });
  res.json({ ok: true });
});

// ---------- REALTIME MULTIPLAYER ----------
const online = new Map(); // socket.id -> { id, username, preset, color, pos, rot }

io.use((socket, next) => {
  const payload = verifyToken(socket.handshake.auth?.token);
  if (!payload) return next(new Error('unauthorized'));
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(payload.id);
  if (!user || user.is_banned) return next(new Error('unauthorized'));
  socket.user = user;
  next();
});

io.on('connection', (socket) => {
  const u = socket.user;
  socket.join('city');
  socket.join(`user:${u.id}`);

  const me = {
    id: u.id, username: u.username,
    preset: u.character_preset, color: u.character_color,
    pos: { x: u.pos_x, y: u.pos_y, z: u.pos_z }, rot: 0
  };
  online.set(socket.id, me);

  socket.emit('currentPlayers', Array.from(online.values()));
  socket.to('city').emit('playerJoined', me);

  socket.on('move', (data) => {
    if (!data || typeof data.x !== 'number') return;
    me.pos = { x: data.x, y: data.y || 0, z: data.z };
    me.rot = data.rot || 0;
    me.anim = data.anim || 'idle';
    socket.to('city').emit('playerMoved', { id: u.id, pos: me.pos, rot: me.rot, anim: me.anim });
    // persist occasionally (cheap: every move is fine for small servers)
    db.prepare('UPDATE users SET pos_x=?, pos_y=?, pos_z=? WHERE id=?')
      .run(me.pos.x, me.pos.y, me.pos.z, u.id);
  });

  socket.on('forceDisconnect', () => socket.disconnect(true));

  socket.on('disconnect', () => {
    online.delete(socket.id);
    socket.to('city').emit('playerLeft', { id: u.id });
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`LIFE CITY backend running on port ${PORT}`));
