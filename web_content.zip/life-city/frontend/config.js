// config.js — the ONLY file you need to edit when you deploy the backend
// somewhere else. Point these at your running backend's address.
window.LIFE_CITY_CONFIG = {
  API_URL: 'http://localhost:3000',
  SOCKET_URL: 'http://localhost:3000'
};
