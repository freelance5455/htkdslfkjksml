// game.js — LIFE CITY client. Vanilla Three.js, no build step needed.
import * as THREE from 'three';

const CFG = window.LIFE_CITY_CONFIG;
const $ = (id) => document.getElementById(id);

// ---------------- auth state ----------------
let TOKEN = localStorage.getItem('lc_token') || null;
let ME = null; // {id, username, money, bank, characterPreset, characterColor, isAdmin, ...}

async function api(path, opts = {}) {
  const res = await fetch(CFG.API_URL + path, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      ...(TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {}),
      ...(opts.headers || {})
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ---------------- character presets (all original, not copied from any game) ----------------
const CHAR_PRESETS = [
  { name: 'Mochi',  head: 'round',  accessory: 'none' },
  { name: 'Buddy',  head: 'round',  accessory: 'cap' },
  { name: 'Pixel',  head: 'square', accessory: 'none' },
  { name: 'Nori',   head: 'square', accessory: 'cap' },
  { name: 'Zuzu',   head: 'round',  accessory: 'horn' },
  { name: 'Coco',   head: 'round',  accessory: 'bow' },
  { name: 'Tofu',   head: 'square', accessory: 'horn' },
  { name: 'Biscuit',head: 'round',  accessory: 'glasses' },
  { name: 'Marble', head: 'square', accessory: 'bow' },
  { name: 'Sprout', head: 'round',  accessory: 'leaf' }
];
const COLORS = ['#58b0ff','#ff8a65','#7ed957','#ffd166','#c77dff','#ff6f91','#4fd1c5','#ffffff','#2d2d2d','#ffb703'];

let selectedPreset = 0, selectedColor = COLORS[0];

function fillCharUI(gridId, colorId, onPick) {
  const grid = $(gridId); grid.innerHTML = '';
  CHAR_PRESETS.forEach((p, i) => {
    const el = document.createElement('div');
    el.className = 'char-swatch' + (i === selectedPreset ? ' selected' : '');
    el.textContent = p.name[0];
    el.title = p.name;
    el.onclick = () => { selectedPreset = i; fillCharUI(gridId, colorId, onPick); };
    grid.appendChild(el);
  });
  const row = $(colorId); row.innerHTML = '';
  COLORS.forEach((c) => {
    const el = document.createElement('div');
    el.className = 'swatch' + (c === selectedColor ? ' selected' : '');
    el.style.background = c;
    el.onclick = () => { selectedColor = c; fillCharUI(gridId, colorId, onPick); };
    row.appendChild(el);
  });
}

// ---------------- screens ----------------
function show(id) { ['screen-auth','screen-character'].forEach(s => $(s).classList.toggle('hidden', s !== id)); }

$('btn-login').onclick = () => doAuth('/api/login');
$('btn-register').onclick = () => doAuth('/api/register');

async function doAuth(path) {
  $('auth-error').textContent = '';
  const username = $('auth-username').value.trim();
  const password = $('auth-password').value;
  try {
    const data = await api(path, { method: 'POST', body: { username, password } });
    TOKEN = data.token; localStorage.setItem('lc_token', TOKEN);
    ME = data.user;
    afterLogin();
  } catch (e) { $('auth-error').textContent = e.message; }
}

function afterLogin() {
  if (ME.money === 500 && ME.bank === 0 && ME.characterPreset === 0 && !localStorage.getItem('lc_char_done_' + ME.id)) {
    selectedPreset = 0; selectedColor = COLORS[0];
    fillCharUI('char-grid', 'color-row');
    show('screen-character');
  } else {
    enterGame();
  }
}

$('btn-confirm-character').onclick = async () => {
  await api('/api/character', { method: 'POST', body: { characterPreset: selectedPreset, characterColor: selectedColor } });
  localStorage.setItem('lc_char_done_' + ME.id, '1');
  ME.characterPreset = selectedPreset; ME.characterColor = selectedColor;
  enterGame();
};

// try auto-login with stored token
(async function tryAutoLogin() {
  if (!TOKEN) return;
  try {
    const data = await api('/api/me');
    ME = data.user;
    enterGame();
  } catch { TOKEN = null; localStorage.removeItem('lc_token'); }
})();

// ================= GAME =================
let renderer, scene, camera, clock;
let playerGroup, playerMixerState = { t: 0 };
let houses = [], jobs = [];
let otherPlayers = new Map(); // id -> {group, nameSprite, target:{pos,rot}}
let socket;
let activeJobSession = null, activeJobEnd = 0;

const keys = {};
const input = { moveX: 0, moveZ: 0, run: false, jump: false };
let camYaw = Math.PI, camPitch = 0.35, camDist = 7;

function enterGame() {
  show(''); $('hud').classList.remove('hidden');
  $('hud-name').textContent = ME.username;
  if (ME.isAdmin) $('btn-admin').classList.remove('hidden');
  updateHUD();
  initThree();
  initControls();
  connectSocket();
  loadWorldData();
  animate();
}

function updateHUD() {
  $('hud-money').textContent = ME.money;
  $('hud-bank').textContent = ME.bank;
}

// ---------------- Three.js setup ----------------
function initThree() {
  const canvas = $('scene');
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x8fd3ff);
  scene.fog = new THREE.Fog(0x8fd3ff, 60, 220);

  camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 500);

  const sun = new THREE.DirectionalLight(0xffffff, 1.1);
  sun.position.set(40, 60, 20);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.left = -80; sun.shadow.camera.right = 80;
  sun.shadow.camera.top = 80; sun.shadow.camera.bottom = -80;
  scene.add(sun);
  scene.add(new THREE.AmbientLight(0xffffff, 0.6));

  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(400, 400),
    new THREE.MeshStandardMaterial({ color: 0x7ed957 })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  buildRoads();
  buildCity();

  playerGroup = buildCharacter(ME.characterPreset, ME.characterColor);
  playerGroup.position.set(0, 0, 8);
  scene.add(playerGroup);

  clock = new THREE.Clock();
  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });
}

function box(w, h, d, color, x, y, z) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshStandardMaterial({ color }));
  m.position.set(x, y + h / 2, z);
  m.castShadow = true; m.receiveShadow = true;
  scene.add(m);
  return m;
}

function makeLabel(text, x, y, z) {
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffffee'; ctx.roundRect ? ctx.roundRect(0,0,256,64,16) : ctx.fillRect(0,0,256,64);
  ctx.fill ? ctx.fill() : null;
  ctx.fillStyle = '#1f2d3d'; ctx.font = 'bold 28px sans-serif'; ctx.textAlign = 'center';
  ctx.fillText(text, 128, 42);
  const tex = new THREE.CanvasTexture(canvas);
  const mat = new THREE.SpriteMaterial({ map: tex, depthTest: false });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(4, 1, 1);
  sprite.position.set(x, y, z);
  scene.add(sprite);
  return sprite;
}

function buildRoads() {
  const roadMat = new THREE.MeshStandardMaterial({ color: 0x3b3b45 });
  const h = new THREE.Mesh(new THREE.PlaneGeometry(220, 10), roadMat);
  h.rotation.x = -Math.PI / 2; h.position.y = 0.01; scene.add(h);
  const v = new THREE.Mesh(new THREE.PlaneGeometry(10, 220), roadMat);
  v.rotation.x = -Math.PI / 2; v.position.y = 0.01; scene.add(v);
}

function buildCity() {
  // simple distinct original low-poly buildings, laid out around the roads
  box(10, 6, 10, 0xffb703, -20, 0, 0); makeLabel('Garage', -20, 6.5, 0);
  box(8, 10, 8, 0x4fd1c5, 10, 0, 25); makeLabel('Bank', 10, 10.5, 25);
  box(8, 5, 8, 0xff8a65, 5, 0, -30); makeLabel('Shop', 5, 5.5, -30);
  box(10, 4, 10, 0x9fd8ff, -10, 0, 10); makeLabel('Security HQ', -10, 4.5, 10);
  box(9, 6, 9, 0xffd166, 20, 0, -5); makeLabel('Hospital', 20, 6.5, -5);
  box(10, 5, 10, 0xc77dff, 0, 0, 40); makeLabel('Bus Depot', 0, 5.5, 40);
  box(12, 4, 12, 0x7ed957, -35, 0, -15); makeLabel('Mechanic', -35, 4.5, -15);
  box(9, 6, 9, 0xff6f91, 40, 0, 0); makeLabel('Construction Co.', 40, 6.5, 0);
  // park
  const park = new THREE.Mesh(new THREE.CircleGeometry(10, 24), new THREE.MeshStandardMaterial({ color: 0x4caf50 }));
  park.rotation.x = -Math.PI / 2; park.position.set(-55, 0.02, 30); scene.add(park);
  makeLabel('Park', -55, 2, 30);
  // parking
  box(14, 0.2, 14, 0x555566, 25, 0, 25); makeLabel('Parking', 25, 1, 25);
}

// ---- cartoon character builder (original shapes, not copied assets) ----
function buildCharacter(presetIndex, colorHex) {
  const p = CHAR_PRESETS[presetIndex] || CHAR_PRESETS[0];
  const color = new THREE.Color(colorHex || '#58b0ff');
  const group = new THREE.Group();
  group.userData.legs = [];

  const bodyMat = new THREE.MeshStandardMaterial({ color });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.4, 0.5, 4, 8), bodyMat);
  body.position.y = 1.1; body.castShadow = true;
  group.add(body);

  const headGeo = p.head === 'square' ? new THREE.BoxGeometry(0.6, 0.6, 0.6) : new THREE.SphereGeometry(0.4, 16, 16);
  const head = new THREE.Mesh(headGeo, bodyMat);
  head.position.y = 1.95; head.castShadow = true;
  group.add(head);

  // accessory
  if (p.accessory === 'cap') {
    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.35, 0.35, 12), new THREE.MeshStandardMaterial({ color: 0x1f2d3d }));
    cap.position.y = 2.25; group.add(cap);
  } else if (p.accessory === 'horn') {
    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.3, 8), new THREE.MeshStandardMaterial({ color: 0xffd166 }));
    horn.position.set(0, 2.3, 0.1); group.add(horn);
  } else if (p.accessory === 'bow') {
    const bow = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), new THREE.MeshStandardMaterial({ color: 0xff6f91 }));
    bow.position.set(0, 2.25, 0.3); group.add(bow);
  } else if (p.accessory === 'glasses') {
    const g = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.1, 0.05), new THREE.MeshStandardMaterial({ color: 0x1f2d3d }));
    g.position.set(0, 2.0, 0.38); group.add(g);
  } else if (p.accessory === 'leaf') {
    const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.35, 6), new THREE.MeshStandardMaterial({ color: 0x4caf50 }));
    leaf.position.set(0, 2.3, 0); leaf.rotation.z = 0.4; group.add(leaf);
  }

  // simple legs for a walk bob
  const legMat = new THREE.MeshStandardMaterial({ color: color.clone().multiplyScalar(0.8) });
  for (const side of [-1, 1]) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.6, 0.22), legMat);
    leg.position.set(0.18 * side, 0.3, 0);
    leg.castShadow = true;
    group.add(leg);
    group.userData.legs.push(leg);
  }
  group.userData.nameSprite = null;
  return group;
}

function attachNameTag(group, username) {
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#000a'; ctx.fillRect(0, 10, 256, 44);
  ctx.fillStyle = '#fff'; ctx.font = 'bold 26px sans-serif'; ctx.textAlign = 'center';
  ctx.fillText(username, 128, 42);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), depthTest: false }));
  sprite.scale.set(2, 0.5, 1);
  sprite.position.set(0, 2.6, 0);
  group.add(sprite);
}

// ---------------- input ----------------
function initControls() {
  addEventListener('keydown', (e) => { keys[e.code] = true; handleKeyAction(e.code); });
  addEventListener('keyup', (e) => { keys[e.code] = false; });

  // desktop camera orbit via drag
  let dragging = false, lastX = 0, lastY = 0;
  const canvas = $('scene');
  canvas.addEventListener('pointerdown', (e) => { dragging = true; lastX = e.clientX; lastY = e.clientY; });
  addEventListener('pointerup', () => dragging = false);
  addEventListener('pointermove', (e) => {
    if (!dragging) return;
    camYaw -= (e.clientX - lastX) * 0.005;
    camPitch = Math.max(0.1, Math.min(1.1, camPitch - (e.clientY - lastY) * 0.005));
    lastX = e.clientX; lastY = e.clientY;
  });
  canvas.addEventListener('wheel', (e) => {
    camDist = Math.max(3, Math.min(14, camDist + e.deltaY * 0.01));
  });

  // touch: show controls on touch devices
  if ('ontouchstart' in window) {
    $('touch-controls').classList.add('active');
    $('controls-hint').classList.add('hidden');
    initJoystick();
    initTouchCamera();
    $('t-jump').addEventListener('touchstart', () => input.jump = true);
    $('t-run').addEventListener('touchstart', () => input.run = !input.run);
    $('t-interact').addEventListener('touchstart', onInteract);
    $('t-enter').addEventListener('touchstart', () => {}); // car system: future update
  }

  // menu buttons
  document.querySelectorAll('#menu-bar button[data-panel]').forEach((b) => {
    b.onclick = () => togglePanel(b.dataset.panel);
  });
  $('btn-logout').onclick = () => { localStorage.removeItem('lc_token'); location.reload(); };
  $('btn-admin').onclick = () => { location.href = 'admin.html'; };

  $('bank-deposit').onclick = () => bankAction('/api/bank/deposit');
  $('bank-withdraw').onclick = () => bankAction('/api/bank/withdraw');
  $('btn-save-character').onclick = async () => {
    await api('/api/character', { method: 'POST', body: { characterPreset: selectedPreset, characterColor: selectedColor } });
    scene.remove(playerGroup);
    playerGroup = buildCharacter(selectedPreset, selectedColor);
    playerGroup.position.copy(savedPos || new THREE.Vector3(0, 0, 8));
    scene.add(playerGroup);
    ME.characterPreset = selectedPreset; ME.characterColor = selectedColor;
  };
}

let savedPos = null;
function handleKeyAction(code) {
  if (code === 'Space') input.jump = true;
  if (code === 'KeyE') onInteract();
  if (code === 'Escape') closeAllPanels();
}

function initJoystick() {
  const zone = $('joystick-zone'), knob = $('joystick-knob');
  let active = false, cx = 0, cy = 0;
  zone.addEventListener('touchstart', (e) => {
    active = true;
    const r = zone.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2;
  });
  zone.addEventListener('touchmove', (e) => {
    if (!active) return;
    const t = e.touches[0];
    let dx = t.clientX - cx, dy = t.clientY - cy;
    const max = 40, len = Math.hypot(dx, dy);
    if (len > max) { dx = dx / len * max; dy = dy / len * max; }
    knob.style.left = 34 + dx + 'px'; knob.style.top = 34 + dy + 'px';
    input.moveX = dx / max; input.moveZ = dy / max;
  });
  zone.addEventListener('touchend', () => {
    active = false; input.moveX = 0; input.moveZ = 0;
    knob.style.left = '34px'; knob.style.top = '34px';
  });
}
function initTouchCamera() {
  const zone = $('camera-zone'); let lastX = 0, lastY = 0;
  zone.addEventListener('touchstart', (e) => { lastX = e.touches[0].clientX; lastY = e.touches[0].clientY; });
  zone.addEventListener('touchmove', (e) => {
    const t = e.touches[0];
    camYaw -= (t.clientX - lastX) * 0.006;
    camPitch = Math.max(0.1, Math.min(1.1, camPitch - (t.clientY - lastY) * 0.006));
    lastX = t.clientX; lastY = t.clientY;
  });
}

function togglePanel(name) {
  const id = 'panel-' + name;
  const wasOpen = !$(id).classList.contains('hidden');
  closeAllPanels();
  if (!wasOpen) {
    $(id).classList.remove('hidden');
    if (name === 'jobs') renderJobsList();
    if (name === 'house') renderHouseList();
    if (name === 'character') { selectedPreset = ME.characterPreset; selectedColor = ME.characterColor; fillCharUI('char-grid-2', 'color-row-2'); }
  }
}
function closeAllPanels() { document.querySelectorAll('.panel').forEach(p => p.classList.add('hidden')); }

async function bankAction(path) {
  const amount = Number($('bank-amount').value);
  try {
    await api(path, { method: 'POST', body: { amount } });
    const me = await api('/api/me'); ME = me.user; updateHUD();
  } catch (e) { alert(e.message); }
}

// ---------------- world data ----------------
async function loadWorldData() {
  const h = await api('/api/houses'); houses = h.houses;
  const j = await api('/api/jobs'); jobs = j.jobs;
  houses.forEach(hh => { box(3, 3, 3, 0xffb703, hh.x, hh.y, hh.z); makeLabel(hh.name + (hh.owner_id ? ' (owned)' : ' $' + hh.price), hh.x, hh.y + 3.6, hh.z); });
  jobs.forEach(jj => { const m = box(1.2, 2, 1.2, 0xef5350, jj.x, jj.y, jj.z); m.geometry = new THREE.ConeGeometry(0.8, 2, 8); makeLabel(jj.name, jj.x, jj.y + 2.6, jj.z); });
}

function renderJobsList() {
  const list = $('jobs-list'); list.innerHTML = '';
  jobs.forEach(j => {
    const row = document.createElement('div'); row.className = 'list-item';
    row.innerHTML = `<span>${j.name}<br><small>${j.duration_seconds}s · pays $${j.pay}</small></span>`;
    const btn = document.createElement('button'); btn.textContent = 'START';
    btn.onclick = () => startJob(j.id);
    row.appendChild(btn); list.appendChild(row);
  });
}
function renderHouseList() {
  const list = $('house-list'); list.innerHTML = '';
  houses.forEach(h => {
    const row = document.createElement('div'); row.className = 'list-item';
    row.innerHTML = `<span>${h.name}<br><small>$${h.price}${h.owner_id ? ' · OWNED' : ''}</small></span>`;
    if (!h.owner_id) {
      const btn = document.createElement('button'); btn.textContent = 'BUY';
      btn.onclick = async () => {
        try { await api('/api/houses/buy', { method: 'POST', body: { houseId: h.id } }); const me = await api('/api/me'); ME = me.user; updateHUD(); loadWorldData(); togglePanel('house'); togglePanel('house'); }
        catch (e) { alert(e.message); }
      };
      row.appendChild(btn);
    }
    list.appendChild(row);
  });
}

async function startJob(jobId) {
  try {
    const res = await api('/api/jobs/start', { method: 'POST', body: { jobId } });
    activeJobSession = res.sessionId;
    activeJobEnd = Date.now() + res.durationSeconds * 1000;
    togglePanel('jobs');
    $('job-timer').classList.remove('hidden');
  } catch (e) { alert(e.message); }
}

function onInteract() {
  const near = findNearbyJob();
  if (near && !activeJobSession) startJob(near.id);
}
function findNearbyJob() {
  for (const j of jobs) {
    const d = Math.hypot(playerGroup.position.x - j.x, playerGroup.position.z - j.z);
    if (d < 3) return j;
  }
  return null;
}

// ---------------- socket.io multiplayer ----------------
function connectSocket() {
  socket = io(CFG.SOCKET_URL, { auth: { token: TOKEN } });
  socket.on('currentPlayers', (list) => list.forEach(addOrUpdateOther));
  socket.on('playerJoined', addOrUpdateOther);
  socket.on('playerMoved', (d) => {
    const o = otherPlayers.get(d.id);
    if (o) { o.target.pos.set(d.pos.x, d.pos.y, d.pos.z); o.target.rot = d.rot; }
  });
  socket.on('playerLeft', (d) => {
    const o = otherPlayers.get(d.id);
    if (o) { scene.remove(o.group); otherPlayers.delete(d.id); }
  });
  socket.on('adminMessage', (d) => alert('📢 Admin: ' + d.text));
  socket.on('forceDisconnect', () => { alert('You have been banned.'); localStorage.removeItem('lc_token'); location.reload(); });
}
function addOrUpdateOther(p) {
  if (p.id === ME.id || otherPlayers.has(p.id)) return;
  const group = buildCharacter(p.preset, p.color);
  group.position.set(p.pos.x, p.pos.y, p.pos.z);
  attachNameTag(group, p.username);
  scene.add(group);
  otherPlayers.set(p.id, { group, target: { pos: new THREE.Vector3(p.pos.x, p.pos.y, p.pos.z), rot: p.rot || 0 } });
}

let lastSent = 0;
function sendMove() {
  const now = performance.now();
  if (now - lastSent < 100) return;
  lastSent = now;
  socket.emit('move', { x: playerGroup.position.x, y: playerGroup.position.y, z: playerGroup.position.z, rot: playerGroup.rotation.y, anim: moving ? 'walk' : 'idle' });
}

// ---------------- main loop ----------------
let velY = 0, moving = false;
function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);

  // --- movement input ---
  let mx = input.moveX, mz = input.moveZ;
  if (keys['KeyA']) mx -= 1; if (keys['KeyD']) mx += 1;
  if (keys['KeyW']) mz -= 1; if (keys['KeyS']) mz += 1;
  const running = keys['ShiftLeft'] || keys['ShiftRight'] || input.run;
  const len = Math.hypot(mx, mz);
  moving = len > 0.05;

  if (moving) {
    mx /= len; mz /= len;
    // move relative to camera yaw
    const forward = new THREE.Vector3(Math.sin(camYaw), 0, Math.cos(camYaw));
    const right = new THREE.Vector3(Math.cos(camYaw), 0, -Math.sin(camYaw));
    const dir = forward.multiplyScalar(mz).add(right.multiplyScalar(mx));
    const speed = running ? 6 : 3;
    playerGroup.position.addScaledVector(dir, speed * dt);
    playerGroup.rotation.y = Math.atan2(dir.x, dir.z);
    // leg bob
    playerMixerState.t += dt * (running ? 14 : 8);
    playerGroup.userData.legs.forEach((leg, i) => { leg.rotation.x = Math.sin(playerMixerState.t + i * Math.PI) * 0.6; });
  } else {
    playerGroup.userData.legs.forEach((leg) => { leg.rotation.x *= 0.8; });
  }

  // jump (very simple)
  if (input.jump && playerGroup.position.y <= 0.001) { velY = 5.5; input.jump = false; }
  velY -= 14 * dt;
  playerGroup.position.y = Math.max(0, playerGroup.position.y + velY * dt);
  if (playerGroup.position.y <= 0) { playerGroup.position.y = 0; velY = 0; }

  // --- camera follow ---
  const target = playerGroup.position.clone().add(new THREE.Vector3(0, 1.6, 0));
  const camOffset = new THREE.Vector3(
    Math.sin(camYaw) * Math.cos(camPitch),
    Math.sin(camPitch) + 0.3,
    Math.cos(camYaw) * Math.cos(camPitch)
  ).multiplyScalar(camDist);
  const desired = target.clone().add(camOffset);
  camera.position.lerp(desired, 1 - Math.pow(0.001, dt));
  camera.lookAt(target);

  // --- interact hint ---
  const near = findNearbyJob();
  $('interact-hint').classList.toggle('hidden', !near || !!activeJobSession);
  if (near) $('interact-hint').textContent = `Press E / USE to start: ${near.name}`;

  if (activeJobSession) {
    const remain = Math.max(0, Math.ceil((activeJobEnd - Date.now()) / 1000));
    $('job-timer').textContent = remain > 0 ? `Working… ${remain}s` : 'Done! Collecting…';
    if (remain <= 0) {
      api('/api/jobs/complete', { method: 'POST', body: { sessionId: activeJobSession } })
        .then(async (r) => { ME.money += r.pay; updateHUD(); activeJobSession = null; $('job-timer').classList.add('hidden'); })
        .catch(() => { activeJobSession = null; $('job-timer').classList.add('hidden'); });
    }
  }

  // --- other players interpolation ---
  otherPlayers.forEach((o) => {
    o.group.position.lerp(o.target.pos, 0.2);
    o.group.rotation.y += (o.target.rot - o.group.rotation.y) * 0.2;
  });

  sendMove();
  renderer.render(scene, camera);
}
