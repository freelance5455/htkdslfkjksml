// admin.js — talks to /api/admin/* only. The server re-checks admin rights
// on every single call, so this page has no real power of its own.
const CFG = window.LIFE_CITY_CONFIG;
const $ = (id) => document.getElementById(id);
const TOKEN = localStorage.getItem('lc_token');

async function api(path, opts = {}) {
  const res = await fetch(CFG.API_URL + path, {
    ...opts,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + TOKEN, ...(opts.headers || {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

async function init() {
  if (!TOKEN) return location.href = 'index.html';
  try {
    const me = await api('/api/me');
    if (!me.user.isAdmin) throw new Error('not admin');
  } catch {
    $('admin-denied').classList.remove('hidden');
    setTimeout(() => location.href = 'index.html', 1500);
    return;
  }
  await loadPlayers();
}

async function loadPlayers() {
  const { players } = await api('/api/admin/players');
  const list = $('players-list'); list.innerHTML = '';
  players.forEach(p => {
    const row = document.createElement('div'); row.className = 'list-item';
    row.innerHTML = `<span>${p.username} ${p.isAdmin ? '👑' : ''} ${p.isBanned ? '<b style="color:#ef5350">BANNED</b>' : ''}<br><small>$${p.money} cash · $${p.bank} bank</small></span>`;
    const actions = document.createElement('div');

    const moneyBtn = document.createElement('button');
    moneyBtn.textContent = 'SET $'; moneyBtn.className = 'ghost';
    moneyBtn.onclick = async () => {
      const val = prompt('New cash amount for ' + p.username, p.money);
      if (val === null) return;
      await api('/api/admin/set-money', { method: 'POST', body: { userId: p.id, money: Number(val) } });
      loadPlayers();
    };
    actions.appendChild(moneyBtn);

    const banBtn = document.createElement('button');
    banBtn.textContent = p.isBanned ? 'UNBAN' : 'BAN';
    banBtn.style.marginLeft = '6px';
    banBtn.onclick = async () => {
      await api(p.isBanned ? '/api/admin/unban' : '/api/admin/ban', { method: 'POST', body: { userId: p.id } });
      loadPlayers();
    };
    actions.appendChild(banBtn);

    row.appendChild(actions);
    list.appendChild(row);
  });
}

$('bc-send').onclick = async () => {
  const text = $('bc-text').value.trim();
  if (!text) return;
  await api('/api/admin/broadcast', { method: 'POST', body: { text } });
  $('bc-text').value = '';
  alert('Sent!');
};

$('job-add').onclick = async () => {
  await api('/api/admin/jobs/add', {
    method: 'POST',
    body: {
      name: $('job-name').value,
      x: Number($('job-x').value), y: Number($('job-y').value), z: Number($('job-z').value),
      durationSeconds: Number($('job-duration').value), pay: Number($('job-pay').value)
    }
  });
  alert('Job added. It will appear next time players load the world.');
};

$('house-add').onclick = async () => {
  await api('/api/admin/houses/add', {
    method: 'POST',
    body: {
      name: $('house-name').value, price: Number($('house-price').value),
      x: Number($('house-x').value), y: Number($('house-y').value), z: Number($('house-z').value)
    }
  });
  alert('House added. It will appear next time players load the world.');
};

init();
