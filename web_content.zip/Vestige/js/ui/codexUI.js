import { $ } from '../core/utilities.js';
import { metaSave } from '../core/save.js';
import { CODEX_LORE } from '../systems/codex.js';

const LORE_RUNES = ['ᚠ', 'ᚢ', 'ᚦ', 'ᚨ', 'ᚱ', 'ᚲ', 'ᚷ', 'ᚹ', 'ᚺ', 'ᚾ', 'ᛁ', 'ᛃ', 'ᛇ', 'ᛈ', 'ᛉ', 'ᛊ'];
const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII', 'XVIII', 'XIX', 'XX'];
const TOTAL_ENDINGS = 4;

function ensureCodexStyles() {
  if (typeof document === 'undefined' || document.getElementById('codex-reliquary-styles')) return;
  const style = document.createElement('style');
  style.id = 'codex-reliquary-styles';
  style.textContent = `
    .codex-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      margin: 2px 0 6px;
      font-size: 13px;
      font-weight: 800;
      letter-spacing: 1.2px;
      text-transform: uppercase;
      color: #f4d68c;
      text-shadow: 0 0 12px rgba(201, 160, 80, 0.3);
    }

    .codex-count {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.4px;
      color: #b7ab94;
      text-transform: none;
      text-shadow: none;
    }

    .codex-bar {
      height: 6px;
      margin-bottom: 12px;
      border-radius: 4px;
      overflow: hidden;
      background: #0d0b11;
      border: 1px solid rgba(196, 156, 78, 0.35);
    }

    .codex-bar > div {
      height: 100%;
      background: linear-gradient(90deg, #8b6324, #f4d68c);
      box-shadow: 0 0 8px rgba(244, 214, 140, 0.5);
    }

    .codex-lore-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
      gap: 10px;
      margin-bottom: 18px;
    }

    .codex-card {
      position: relative;
      display: flex;
      flex-direction: column;
      gap: 5px;
      padding: 10px 12px 11px;
      border-radius: 7px;
      overflow: hidden;
      background: linear-gradient(165deg, #1b1724 0%, #100d15 100%);
      border: 1.5px solid #4a4554;
    }

    .codex-card::before {
      content: '';
      position: absolute;
      inset: 3px;
      border-radius: 5px;
      border: 1px solid rgba(255, 255, 255, 0.05);
      pointer-events: none;
    }

    .codex-card.unlocked {
      border-color: #8c6d34;
      background:
        radial-gradient(circle at 12% 10%, rgba(201, 160, 80, 0.16), transparent 56%),
        linear-gradient(165deg, #231c26 0%, #120e16 100%);
      box-shadow:
        0 0 12px rgba(201, 160, 80, 0.14),
        inset 0 1px 0 rgba(255, 232, 166, 0.14);
    }

    .codex-card.unlocked::before {
      border-color: rgba(244, 214, 140, 0.22);
    }

    .codex-card.locked {
      border-style: dashed;
      border-color: rgba(180, 155, 102, 0.28);
      background: linear-gradient(165deg, rgba(22, 19, 29, 0.72), rgba(12, 10, 16, 0.85));
    }

    .codex-card-top {
      position: relative;
      z-index: 1;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 9.5px;
      letter-spacing: 0.7px;
      text-transform: uppercase;
      color: #a9a1b8;
    }

    .codex-rune {
      font-size: 13px;
      color: #f4d68c;
      text-shadow: 0 0 8px rgba(244, 214, 140, 0.5);
    }

    .codex-card.locked .codex-rune {
      color: #7d7590;
      text-shadow: none;
    }

    .codex-title {
      position: relative;
      z-index: 1;
      font-size: 14px;
      color: #f6f1e7;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.85);
    }

    .codex-card.locked .codex-title {
      color: #8f889e;
    }

    .codex-text {
      position: relative;
      z-index: 1;
      margin: 0;
      font-size: 12px;
      line-height: 1.45;
      color: #b8b0c8;
    }

    .codex-card.locked .codex-text {
      color: #6f6880;
      font-style: italic;
    }

    .codex-panel {
      padding: 10px 12px;
      margin-bottom: 14px;
      border-radius: 7px;
      background:
        radial-gradient(circle at 8% 12%, rgba(201, 160, 80, 0.08), transparent 48%),
        linear-gradient(180deg, #1a1622 0%, #100d15 100%);
      border: 1.5px solid #755b2c;
      box-shadow: inset 0 0 24px rgba(0, 0, 0, 0.62);
    }

    .codex-chip-row {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
    }

    .codex-chip {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 3px 9px;
      border-radius: 5px;
      font-size: 11.5px;
      color: #d9d0c0;
      background: linear-gradient(180deg, rgba(28, 22, 37, 0.94), rgba(13, 10, 18, 0.96));
      border: 1px solid rgba(196, 156, 78, 0.4);
    }

    .codex-chip.reached {
      color: #f8dc94;
      border-color: rgba(244, 214, 140, 0.65);
      background: rgba(201, 160, 80, 0.16);
    }

    .codex-chip.empty {
      color: #6f6880;
      border-style: dashed;
      border-color: rgba(180, 155, 102, 0.28);
      background: transparent;
    }

    .codex-empty-note {
      font-size: 12px;
      color: #8f889e;
      font-style: italic;
    }

    .codex-stat-line {
      margin-top: 8px;
      font-size: 12px;
      color: #b7ab94;
    }

    .codex-stat-line b {
      color: #fae09b;
    }
  `;
  document.head.appendChild(style);
}

export function renderCodex(targetId) {
  ensureCodexStyles();

  const unlockedFlags = CODEX_LORE.map(l => Boolean(l.unlocked || metaSave.unlockedLore.includes(l.id)));
  const found = unlockedFlags.filter(Boolean).length;
  const pct = CODEX_LORE.length ? Math.round((found / CODEX_LORE.length) * 100) : 0;

  const loreHTML = CODEX_LORE.map((l, i) => {
    const un = unlockedFlags[i];
    const rune = un ? LORE_RUNES[i % LORE_RUNES.length] : '🔒';
    const tag = `Entry ${ROMAN[i] || i + 1}`;
    return (
      `<div class="codex-card sans ${un ? 'unlocked' : 'locked'}">` +
      `<div class="codex-card-top"><span class="codex-rune">${rune}</span><span>${tag}</span></div>` +
      `<b class="codex-title">${un ? l.title : '??? (Locked)'}</b>` +
      `<p class="codex-text">${un ? l.text : 'Defeat Fallen Lords or achieve Endings to uncover this memory.'}</p>` +
      `</div>`
    );
  }).join('');

  const achievements = metaSave.achievements;
  const achHTML = achievements.length
    ? `<div class="codex-chip-row">${achievements.map(a => `<span class="codex-chip reached">🏆 ${a}</span>`).join('')}</div>`
    : `<div class="codex-empty-note">None yet — your deeds will be remembered here.</div>`;

  const endings = metaSave.endings;
  const endingChips =
    endings.map(e => `<span class="codex-chip reached">✦ ${e}</span>`).join('') +
    Array.from({ length: Math.max(0, TOTAL_ENDINGS - endings.length) })
      .map(() => `<span class="codex-chip empty">??? Undiscovered</span>`)
      .join('');

  $(targetId).innerHTML =
    `<div class="codex-head"><span>✦ Lore &amp; Bosses</span><span class="codex-count sans">${found} / ${CODEX_LORE.length} uncovered</span></div>` +
    `<div class="codex-bar"><div style="width:${pct}%"></div></div>` +
    `<div class="codex-lore-grid">${loreHTML}</div>` +
    `<div class="codex-head"><span>✦ Achievements</span><span class="codex-count sans">${achievements.length} earned</span></div>` +
    `<div class="codex-panel sans">${achHTML}</div>` +
    `<div class="codex-head"><span>✦ Endings</span><span class="codex-count sans">${endings.length} / ${TOTAL_ENDINGS}</span></div>` +
    `<div class="codex-panel sans"><div class="codex-chip-row">${endingChips}</div>` +
    `<div class="codex-stat-line">Lifetime Boss Kills: <b>${metaSave.bossKills}</b></div></div>`;
}
