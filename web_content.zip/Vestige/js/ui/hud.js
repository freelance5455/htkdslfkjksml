import { $, fmtTime } from '../core/utilities.js';
import { metaSave, persistSave } from '../core/save.js';
import { state } from '../core/game.js';

import { WEAPONS_DEF } from '../data/classes.js';
import { WorldTierConfig } from '../data/worldTierData.js';
import { BIOMES } from '../world/biomes.js';
import { QuestlineManager, getQuestTrackerData, onQuestHook } from '../systems/questlines.js';
import { openQuestModal } from './questUI.js';

export const DOM = {};

// Consistent line icons (replace mixed-style emoji in the HUD)
const svgIcon = (paths, solid = false) =>
  `<svg class="hud-ico${solid ? ' solid' : ''}" viewBox="0 0 24 24" aria-hidden="true">${paths}</svg>`;

const ICON = {
  gear: svgIcon('<path d="M12 3l7 3v5c0 5-3.2 8.2-7 10-3.8-1.8-7-5-7-10V6z"/>'),
  tree: svgIcon('<path d="M12 21v-8M12 13c-3 0-5-2-5-5M12 13c3 0 5-2 5-5M12 9V3"/>'),
  forge: svgIcon('<path d="M4 8h13a3 3 0 01-3 3h-1l1 3H8l1-3H8a4 4 0 01-4-3zM6 17h12v3H6z"/>'),
  journal: svgIcon('<path d="M5 4h10a3 3 0 013 3v13H8a3 3 0 01-3-3zM8 4v13"/>'),
  codex: svgIcon('<path d="M7 4h11v13a3 3 0 01-3 3H6a2 2 0 002-2V6a2 2 0 00-1-2zM10 9h5M10 13h5"/>'),
  menu: svgIcon('<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>'),
  gold: svgIcon('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/>', true),
  shards: svgIcon('<path d="M12 3l7 6-7 12L5 9zM5 9h14"/>', true),
  essence: svgIcon('<path d="M12 3c3 4 6 6 6 10a6 6 0 01-12 0c0-4 3-6 6-10z"/>', true),
  flames: svgIcon('<path d="M12 21a6 6 0 01-4-10c1 1 2 1.5 2.5 1C10 9 11 6 14 3c0 3 4 5 4 9a6 6 0 01-6 9z"/>', true)
};

const DOM_IDS = [
  'xp-fill', 'lvl-badge', 'hp-fill', 'hp-text', 'hud-gold', 'hud-shards', 'hud-essence', 'hud-flames',
  'timer-text', 'biome-text', 'boss-bar-wrap', 'boss-name', 'boss-fill', 'quest-title', 'quest-desc',
  'bag-dot', 'tree-dot', 'dash-pill', 'weapons-bar', 'loot-feed', 'mobile-dash', 'menu-modal',
  'levelup-modal', 'inv-modal', 'tree-modal', 'craft-modal', 'npc-modal', 'codex-modal', 'pause-modal',
  'ending-modal', 'vault-bar', 'class-grid', 'rel-content', 'tier-buttons', 'tier-desc',
  'start-biome-select', 'dungeon-select', 'modes-list', 'upgrade-cards', 'lvlup-title', 'equipped-slots',
  'set-bonuses-box', 'char-stats-box', 'bag-count', 'gem-count', 'bag-grid', 'item-inspector',
  'tree-pts', 'tree-node-info', 'craft-gold', 'craft-shards', 'craft-essence', 'craft-item-list',
  'craft-selected-box', 'npc-name', 'npc-quote', 'npc-body', 'npc-choices', 'pause-stats',
  'end-title', 'end-sub', 'end-choices', 'end-summary', 'btn-return-menu'
];

const HUD_BUTTONS = [
  { id: 'btn-inv', icon: ICON.gear, label: 'Gear [I]', dot: 'bag-dot' },
  { id: 'btn-tree', icon: ICON.tree, label: 'Tree [T]', dot: 'tree-dot' },
  { id: 'btn-craft', icon: ICON.forge, label: 'Forge [C]' },
  { id: 'btn-quest', icon: ICON.journal, label: 'Journal [J]' },
  { id: 'btn-codex', icon: ICON.codex, label: 'Codex' },
  { id: 'btn-pause', icon: ICON.menu, label: 'Menu [P]' }
];

const RESOURCE_SPECS = [
  { id: 'hud-gold', icon: ICON.gold, label: 'Gold', color: '#f6da8e' },
  { id: 'hud-shards', icon: ICON.shards, label: 'Shards', color: '#7cc8ff' },
  { id: 'hud-essence', icon: ICON.essence, label: 'Essence', color: '#df94ff' },
  { id: 'hud-flames', icon: ICON.flames, label: 'Fragments', color: '#ff934d' }
];

const MAP_LEGEND = [
  { icon: '★', label: 'Boss', color: '#ff5263' },
  { icon: '⚔', label: 'Champion', color: '#ff9d47' },
  { icon: '✦', label: 'Fragment', color: '#ffe078' },
  { icon: '♦', label: 'Event', color: '#7ce8ff' },
  { icon: '▲', label: 'Vault', color: '#f4c752' },
  { icon: '●', label: 'Merchant', color: '#6effb0' },
  { icon: '✚', label: 'Shrine', color: '#d7a8ff' }
];

const BOSS_FACTION_THEMES = [
  { match: /ashen|flame|cinder|ember|pyre|king/, crest: '🔥', title: 'Sovereign of the First Flame', color: '#ff8238' },
  { match: /void|astral|cosmic|star|abyss|eclipse/, crest: '🌌', title: 'Herald of the Astral Rift', color: '#d866ff' },
  { match: /death|necro|grave|bone|lich|wraith|plague/, crest: '💀', title: 'Warden of the Undying Choir', color: '#5effb1' },
  { match: /holy|choir|seraph|sun|sanct|warden|archon/, crest: '☀️', title: 'Fallen Prelate of the Sanctum', color: '#ffd966' },
  { match: /shadow|night|umbral|stalker|dread|veil/, crest: '🗡️', title: 'Phantom of the Lost Kingdom', color: '#b48cff' }
];

const QUEST_STATE_THEMES = {
  started:   { title: 'QUEST STARTED',   color: '#f4d68c', border: '#e0b860', glow: 'rgba(244, 214, 140, 0.40)', icon: '✦' },
  updated:   { title: 'QUEST UPDATED',   color: '#63b4ff', border: '#4da6ff', glow: 'rgba(99, 180, 255, 0.38)',  icon: '◈' },
  completed: { title: 'QUEST COMPLETED', color: '#5effb1', border: '#4be89a', glow: 'rgba(94, 255, 177, 0.40)',  icon: '✔' },
  failed:    { title: 'QUEST FAILED',    color: '#ff5b6c', border: '#e84356', glow: 'rgba(255, 91, 108, 0.42)',  icon: '✖' }
};

const FACTION_ICONS = {
  throne: '👑',
  choir: '✧',
  veiled: '👁',
  bramble: '🌿',
  pilgrim: '🕯',
  main: '🔥',
  unaligned: '◈'
};

let lastBossAnnouncedId = null;
let questHooksWired = false;
let lastTrackerSignature = '';

const setBarPct = (el, val, max) => {
  if (el) el.style.width = `${Math.max(0, Math.min(100, (val / Math.max(1, max)) * 100))}%`;
};

const setElText = (key, text) => {
  if (DOM[key]) DOM[key].textContent = text;
};

const setBadgeCount = (el, count) => {
  if (!el) return;
  el.style.display = count > 0 ? 'inline-block' : 'none';
  el.textContent = count;
};

const renderTabButtons = (items, attr) =>
  items
    .map(([k, l, active]) => `<button class="tab-btn ${active ? 'active' : ''}" data-${attr}="${k}">${l}</button>`)
    .join('');

const modalHdr = (title, btns) =>
  `<div class="modal-header"><h2>${title}</h2><div class="flex-row sans" style="gap:8px;flex-wrap:wrap;">${btns}</div></div>`;

const overlay = (id, inner, boxStyle = '', active = false) =>
  `<div class="modal-overlay${active ? ' active' : ''}" id="${id}"><div class="modal-box" style="${boxStyle}">${inner}</div></div>`;

function ensureHudStyles() {
  if (typeof document === 'undefined' || document.getElementById('hud-reliquary-styles')) return;
  const style = document.createElement('style');
  style.id = 'hud-reliquary-styles';
  style.textContent = `
    /* Unified Reliquary Panel Language (Matching Blessing Screen) */
    .rel-hud-panel {
      position: relative;
      background:
        radial-gradient(circle at 50% 0%, rgba(224, 178, 88, 0.12), transparent 64%),
        linear-gradient(180deg, rgba(25, 20, 34, 0.94) 0%, rgba(11, 9, 16, 0.96) 100%);
      border: 1.5px solid #917036;
      border-radius: 8px;
      box-shadow:
        inset 0 0 0 1px rgba(248, 220, 148, 0.14),
        inset 0 0 22px rgba(0, 0, 0, 0.65),
        0 8px 24px rgba(0, 0, 0, 0.68);
    }

    .rel-hud-panel::before,
    .rel-hud-panel::after {
      content: '✦';
      position: absolute;
      font-size: 9px;
      color: rgba(244, 214, 140, 0.62);
      pointer-events: none;
      line-height: 1;
    }
    .rel-hud-panel::before { top: 3px; left: 5px; }
    .rel-hud-panel::after { bottom: 3px; right: 5px; }

    .rel-rune-divider {
      display: flex;
      align-items: center;
      gap: 6px;
      width: 100%;
      margin: 4px 0;
      font-size: 9px;
      color: rgba(244, 214, 140, 0.72);
      line-height: 1;
    }
    .rel-rune-divider::before,
    .rel-rune-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: linear-gradient(90deg, transparent, rgba(244, 214, 140, 0.45), transparent);
    }

    /* Action Buttons */
    #hud-btns .hud-btn {
      position: relative;
      background: linear-gradient(180deg, #241d2e 0%, #120e18 100%);
      border: 1.5px solid rgba(201, 160, 80, 0.58);
      color: #f6ebd3;
      letter-spacing: 0.4px;
      box-shadow:
        inset 0 0 0 1px rgba(244, 214, 140, 0.1),
        0 4px 12px rgba(0, 0, 0, 0.58);
      transition: transform 0.13s ease, border-color 0.16s ease, box-shadow 0.16s ease, filter 0.15s ease;
    }

    #hud-btns .hud-btn:hover {
      transform: translateY(-2px);
      border-color: #f4d68c;
      box-shadow: 0 0 16px rgba(244, 214, 140, 0.28), 0 6px 14px rgba(0, 0, 0, 0.65);
      filter: brightness(1.12);
    }

    #lvl-badge {
      background: linear-gradient(180deg, #422e14 0%, #1e1408 100%);
      border: 1.5px solid #e0b860;
      color: #fae09b;
      letter-spacing: 0.8px;
      text-shadow: 0 1px 2px #000;
      box-shadow: 0 0 14px rgba(201, 160, 80, 0.36), inset 0 1px 0 rgba(255, 255, 255, 0.2);
    }

    /* Icon-First Resource Panel */
    .rel-res-bar {
      display: inline-flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 6px;
    }

    .rel-res-pill {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 4px 9px;
      border-radius: 6px;
      background: linear-gradient(180deg, rgba(28, 22, 37, 0.94), rgba(13, 10, 18, 0.96));
      border: 1px solid rgba(196, 156, 78, 0.48);
      box-shadow:
        inset 0 0 0 1px rgba(244, 214, 140, 0.08),
        0 4px 10px rgba(0, 0, 0, 0.5);
      font-size: 12.5px;
    }

    .rel-res-ico {
      font-size: 14px;
      line-height: 1;
      filter: drop-shadow(0 0 6px rgba(244, 214, 140, 0.35));
    }

    .rel-res-val {
      font-weight: 800;
      font-size: 13px;
      letter-spacing: 0.3px;
      text-shadow: 0 1px 2px #000;
    }

    /* Quest Tracker Beneath Player Resources */
    #hud-quest-tracker {
      margin-top: 7px;
      padding: 8px 11px;
      width: 100%;
      max-width: 278px;
      pointer-events: auto;
      cursor: pointer;
      transition: transform 0.14s ease, border-color 0.16s ease, box-shadow 0.16s ease;
    }
    #hud-quest-tracker:hover {
      transform: translateY(-1px);
      border-color: #f4d68c;
      box-shadow: 0 0 16px rgba(244, 214, 140, 0.22), 0 8px 24px rgba(0, 0, 0, 0.72);
    }

    .rel-qt-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
    }

    .rel-qt-title {
      display: flex;
      align-items: center;
      gap: 6px;
      min-width: 0;
      font-size: 12.5px;
      font-weight: 800;
      color: #f8dc94;
      letter-spacing: 0.35px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .rel-qt-actions {
      display: flex;
      align-items: center;
      gap: 4px;
      flex-shrink: 0;
    }

    .rel-qt-mini-btn {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(201, 160, 80, 0.42);
      color: #e6c67c;
      border-radius: 4px;
      font-size: 10px;
      font-weight: 700;
      padding: 2px 6px;
      cursor: pointer;
      line-height: 1.2;
    }
    .rel-qt-mini-btn:hover {
      border-color: #f4d68c;
      background: rgba(201, 160, 80, 0.18);
    }

    .rel-qt-obj {
      font-size: 11px;
      color: #dfd6ec;
      line-height: 1.3;
      margin-top: 2px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .rel-qt-prog-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      margin-top: 5px;
      font-size: 10.5px;
      font-weight: 700;
      color: #cfc6b0;
    }

    .rel-qt-track {
      flex: 1;
      height: 4px;
      border-radius: 3px;
      background: #0a070d;
      border: 1px solid rgba(224, 184, 96, 0.42);
      overflow: hidden;
    }

    .rel-qt-fill {
      height: 100%;
      border-radius: 2px;
      background: linear-gradient(90deg, #8a6420 0%, #f4d68c 100%);
      box-shadow: 0 0 8px rgba(244, 214, 140, 0.45);
      transition: width 0.25s ease;
    }

    /* Minimal HUD Mode for Quest Tracker */
    #hud-quest-tracker.minimal {
      padding: 5px 10px;
      max-width: 235px;
    }
    #hud-quest-tracker.minimal .rel-rune-divider,
    #hud-quest-tracker.minimal .rel-qt-obj,
    #hud-quest-tracker.minimal .rel-qt-track {
      display: none;
    }
    #hud-quest-tracker.minimal .rel-qt-prog-row {
      margin-top: 2px;
      justify-content: flex-end;
    }

    /* Animated Reliquary Quest Notifications */
    #hud-quest-toasts {
      position: fixed;
      left: 50%;
      transform: translateX(-50%);
      top: 182px;
      z-index: 32;
      display: flex;
      flex-direction: column;
      gap: 8px;
      width: min(310px, calc(100vw - 24px));
      pointer-events: none;
    }

    .rel-q-toast {
      position: relative;
      padding: 9px 13px 10px;
      border-radius: 8px;
      background:
        radial-gradient(circle at 14% 12%, rgba(255, 255, 255, 0.08), transparent 55%),
        linear-gradient(180deg, rgba(27, 20, 36, 0.96) 0%, rgba(11, 9, 16, 0.98) 100%);
      border: 1.5px solid #e0b860;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.82), inset 0 0 18px rgba(0, 0, 0, 0.65);
      animation: relToastIn 0.35s cubic-bezier(0.22, 1, 0.36, 1) forwards;
    }

    .rel-q-toast.leaving {
      animation: relToastOut 0.35s ease forwards;
    }

    @keyframes relToastIn {
      from { opacity: 0; transform: translateX(28px) scale(0.96); }
      to   { opacity: 1; transform: translateX(0) scale(1); }
    }
    @keyframes relToastOut {
      from { opacity: 1; transform: translateX(0) scale(1); }
      to   { opacity: 0; transform: translateX(24px) scale(0.96); }
    }

    /* Minimal Quest Objective Plaque */
    .rel-quest-plaque {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 6px 12px;
      min-width: 0;
    }
    .rel-quest-plaque .rel-rune-divider { display: none; }
    #quest-title { margin: 0 !important; }

    .hud-ico {
      width: 13px; height: 13px; flex-shrink: 0;
      fill: none; stroke: currentColor; stroke-width: 1.7;
      stroke-linecap: round; stroke-linejoin: round;
    }
    .hud-ico.solid { fill: currentColor; fill-opacity: 0.22; }
    #hud-btns .hud-btn { display: inline-flex; align-items: center; gap: 5px; }
    .rel-res-ico { display: inline-flex; align-items: center; }
    .rel-res-ico .hud-ico { width: 15px; height: 15px; }

    #quest-title {
      color: #f4d68c !important;
      font-size: 10.5px !important;
      font-weight: 800;
      letter-spacing: 1.2px;
      text-transform: uppercase;
      text-align: center;
    }

    #quest-desc {
      color: #f5effa !important;
      font-size: 12.5px !important;
      font-weight: 700;
      text-align: center;
      letter-spacing: 0.2px;
    }

    /* Timer & Biome Plaque */
    .rel-world-plaque {
      padding: 5px 11px;
      text-align: center;
    }

    #timer-text {
      font-weight: 800;
      color: #fae09b;
      letter-spacing: 0.8px;
    }

    #biome-text {
      font-size: 11px;
      color: #cfc6dc;
      letter-spacing: 0.5px;
    }

    /* Ceremonial Boss Alert (Tarot / Reliquary Standard) */
    #boss-bar-wrap.rel-boss-ceremony {
      position: relative;
      background:
        radial-gradient(circle at 50% 10%, rgba(204, 46, 68, 0.22), transparent 65%),
        linear-gradient(180deg, rgba(28, 15, 22, 0.96), rgba(11, 8, 14, 0.98));
      border: 1.5px solid #b5893e;
      border-radius: 9px;
      padding: 10px 18px 11px;
      box-shadow:
        inset 0 0 0 1px rgba(248, 220, 148, 0.2),
        inset 0 0 28px rgba(0, 0, 0, 0.72),
        0 14px 36px rgba(0, 0, 0, 0.85),
        0 0 28px rgba(196, 40, 56, 0.3);
    }

    #boss-bar-wrap.rel-boss-awaken {
      animation: relBossCeremony 0.8s cubic-bezier(0.22, 1, 0.36, 1);
    }

    @keyframes relBossCeremony {
      0% { transform: translateY(-16px) scale(0.93); opacity: 0; filter: brightness(1.4); }
      60% { transform: translateY(2px) scale(1.015); opacity: 1; }
      100% { transform: translateY(0) scale(1); opacity: 1; filter: brightness(1); }
    }

    .rel-boss-header {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      margin-bottom: 6px;
    }

    .rel-boss-crest {
      position: relative;
      width: 44px;
      height: 44px;
      border-radius: 50%;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      flex-shrink: 0;
      background: radial-gradient(circle at 50% 35%, rgba(255, 255, 255, 0.16), rgba(10, 8, 14, 0.96));
      border: 2px solid #e0b860;
      box-shadow: 0 0 18px rgba(224, 184, 96, 0.45), inset 0 0 10px rgba(0, 0, 0, 0.82);
    }

    .rel-boss-crest::after {
      content: '';
      position: absolute;
      inset: -4px;
      border-radius: 50%;
      border: 1px dashed rgba(244, 214, 140, 0.42);
      pointer-events: none;
    }

    .rel-boss-titles {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      line-height: 1.18;
    }

    .rel-boss-epithet {
      font-size: 10px;
      font-weight: 800;
      letter-spacing: 1.4px;
      text-transform: uppercase;
      color: #e6c67c;
    }

    #boss-name {
      font-size: 17px !important;
      font-weight: 900;
      letter-spacing: 1.6px;
      color: #fff6e5 !important;
      text-shadow: 0 0 14px rgba(255, 112, 92, 0.48), 0 2px 4px #000;
    }

    .rel-boss-bar-track {
      position: relative;
      border: 1px solid rgba(224, 184, 96, 0.62);
      border-radius: 4px;
      overflow: hidden;
      background: #0a070d;
      box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.88);
    }

    .rel-boss-bar-track::after {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(90deg, transparent 24.8%, rgba(255, 232, 180, 0.22) 25%, transparent 25.3%, transparent 49.8%, rgba(255, 232, 180, 0.25) 50%, transparent 50.3%, transparent 74.8%, rgba(255, 232, 180, 0.22) 75%, transparent 75.3%);
      pointer-events: none;
    }

    #boss-fill {
      background: linear-gradient(90deg, #75101e 0%, #c92638 52%, #f79d42 100%) !important;
      box-shadow: 0 0 16px rgba(220, 48, 64, 0.6);
    }

    .rel-key {
      display: inline-block;
      margin-left: 3px;
      padding: 0 5px;
      border-radius: 4px;
      font-family: inherit;
      font-size: 9.5px;
      font-weight: 800;
      letter-spacing: 0.4px;
      color: #e6c67c;
      border: 1px solid rgba(244, 214, 140, 0.4);
      background: rgba(0, 0, 0, 0.42);
    }

    .rel-bar-track {
      border: 1px solid rgba(224, 184, 96, 0.55) !important;
      border-radius: 4px;
      background: #0a070d !important;
      box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.85);
      overflow: hidden;
    }

    #hp-fill {
      background: linear-gradient(90deg, #6d0f1c 0%, #c92638 55%, #f0634a 100%) !important;
      box-shadow: 0 0 10px rgba(220, 48, 64, 0.5);
    }

    #xp-fill {
      background: linear-gradient(90deg, #8a6420 0%, #f4d68c 100%) !important;
      box-shadow: 0 0 8px rgba(244, 214, 140, 0.45);
    }

    #hp-text {
      font-weight: 800;
      letter-spacing: 0.4px;
      text-shadow: 0 1px 2px #000;
    }

    .weapon-pill {
      background: linear-gradient(180deg, rgba(28, 22, 36, 0.94), rgba(13, 10, 18, 0.96)) !important;
      border: 1.5px solid rgba(196, 156, 78, 0.5);
      box-shadow: inset 0 0 0 1px rgba(244, 214, 140, 0.08), 0 4px 10px rgba(0, 0, 0, 0.52);
      letter-spacing: 0.3px;
    }

    .weapon-pill.evolved {
      border-color: #f4d68c !important;
      box-shadow: 0 0 16px rgba(244, 214, 140, 0.36), inset 0 0 10px rgba(244, 214, 140, 0.16);
    }

    #dash-pill {
      background: linear-gradient(180deg, #272031, #14101b);
      border: 1.5px solid rgba(201, 160, 80, 0.56);
      color: #f6e2b4;
      letter-spacing: 0.6px;
      box-shadow: inset 0 0 0 1px rgba(244, 214, 140, 0.1), 0 4px 14px rgba(0, 0, 0, 0.58);
    }

    .rel-minimap-frame {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 5px;
      padding: 9px 10px 8px;
      pointer-events: none;
    }

    #rel-minimap-panel {
      position: fixed;
      right: 14px;
      bottom: 58px;
      z-index: 9;
      width: 174px;
    }

    .rel-map-header {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 9.5px;
      font-weight: 800;
      letter-spacing: 1px;
      text-transform: uppercase;
      color: #e7cb88;
    }

    .rel-compass-wrap {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 12px;
      border-radius: 6px;
      background: radial-gradient(circle, rgba(36, 28, 19, 0.85), rgba(11, 9, 15, 0.96));
      border: 1px solid rgba(201, 160, 80, 0.38);
    }

    .rel-compass-wrap canvas {
      display: block;
      border-radius: 4px;
      border: 1px solid rgba(201, 160, 80, 0.3);
    }

    .rel-compass-dir {
      position: absolute;
      font-size: 9px;
      font-weight: 900;
      color: #d8b56b;
      text-shadow: 0 1px 2px #000;
      line-height: 1;
    }
    .rel-compass-dir.n { top: 2px; left: 50%; transform: translateX(-50%); color: #ffe08a; }
    .rel-compass-dir.s { bottom: 2px; left: 50%; transform: translateX(-50%); }
    .rel-compass-dir.w { left: 3px; top: 50%; transform: translateY(-50%); }
    .rel-compass-dir.e { right: 3px; top: 50%; transform: translateY(-50%); }

    .rel-map-legend {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 2px 7px;
      font-size: 11px;
      pointer-events: auto;
    }

    .rel-map-legend-item {
      font-weight: 800;
      line-height: 1.2;
      cursor: help;
      text-shadow: 0 1px 2px #000;
    }

    @media (max-width: 760px) {
      #rel-minimap-panel { display: none; }
      #hud-quest-tracker { max-width: 215px; padding: 6px 9px; }
      #hud-quest-toasts {
        right: auto;
        left: 50%;
        transform: translateX(-50%);
        top: 86px;
        width: min(290px, 92vw);
      }
    }

    @media (max-height: 540px) {
      #hud-quest-tracker { max-width: 220px; padding: 5px 8px; margin-top: 4px; }
      #hud-quest-tracker .rel-qt-obj { font-size: 10px; }
      #hud-quest-toasts { top: 64px; }
    }

    /* ── Reliquary chrome for Skill Tree / Codex / Pause menus ── */
    #tree-modal .modal-box,
    #codex-modal .modal-box,
    #pause-modal .modal-box {
      background:
        radial-gradient(circle at 50% 0%, rgba(201, 160, 80, 0.09), transparent 55%),
        linear-gradient(180deg, #17131d 0%, #0d0b12 100%);
      border: 1.5px solid #8c6d34;
      box-shadow:
        inset 0 0 0 1px rgba(244, 214, 140, 0.16),
        inset 0 0 36px rgba(0, 0, 0, 0.72),
        0 26px 75px rgba(0, 0, 0, 0.9);
    }

    #tree-modal .modal-header,
    #codex-modal .modal-header {
      border-bottom: 1px solid rgba(201, 160, 80, 0.34);
      padding-bottom: 10px;
      margin-bottom: 12px;
      gap: 10px;
      flex-wrap: wrap;
    }

    #tree-modal .modal-header h2,
    #codex-modal .modal-header h2,
    #pause-modal h2 {
      color: #f4d68c;
      letter-spacing: 1.4px;
      text-shadow: 0 0 14px rgba(201, 160, 80, 0.35);
    }

    #tree-modal .modal-header .flex-row > span {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 12px;
      color: #d9cfb8;
      background: linear-gradient(180deg, rgba(28, 22, 37, 0.94), rgba(13, 10, 18, 0.96));
      border: 1px solid rgba(196, 156, 78, 0.48);
      box-shadow: inset 0 0 0 1px rgba(244, 214, 140, 0.08);
    }

    #tree-modal .modal-header .flex-row > span b { font-size: 15px; }

    #tree-modal .btn-dark,
    #codex-modal .btn-dark,
    #pause-modal .btn-dark {
      background: linear-gradient(180deg, #272130 0%, #16121d 100%);
      border: 1px solid rgba(201, 160, 80, 0.45);
      color: #e9d7ad;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.08);
      cursor: pointer;
      transition: transform 0.12s ease, filter 0.15s ease, border-color 0.15s ease;
    }

    #tree-modal .btn-dark:hover,
    #codex-modal .btn-dark:hover,
    #pause-modal .btn-dark:hover {
      transform: translateY(-1px);
      filter: brightness(1.14);
      border-color: #e0b860;
    }

    #tree-modal .btn-gold,
    #codex-modal .btn-gold,
    #pause-modal .btn-gold {
      border: 1.5px solid #e0b860;
      letter-spacing: 0.5px;
      box-shadow: 0 0 14px rgba(201, 160, 80, 0.36), inset 0 1px 0 rgba(255, 255, 255, 0.2);
      transition: transform 0.12s ease, filter 0.15s ease;
    }

    #tree-modal .btn-gold:hover,
    #codex-modal .btn-gold:hover,
    #pause-modal .btn-gold:hover {
      transform: translateY(-1px);
      filter: brightness(1.12);
    }

    #tree-modal #tree-canvas {
      display: block;
      width: 100%;
      height: auto;
      border: 1.5px solid #755b2c;
      border-radius: 7px;
      background:
        radial-gradient(circle at 50% 50%, rgba(201, 160, 80, 0.09), transparent 62%),
        linear-gradient(180deg, #171320 0%, #0c0a11 100%);
      box-shadow: inset 0 0 36px rgba(0, 0, 0, 0.7);
      cursor: default;
    }
    #tree-modal #tree-canvas.hovering { cursor: pointer; }

    #tree-modal #tree-node-info {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 4px 8px;
      min-height: 46px;
      padding: 10px 14px;
      font-size: 13px;
      line-height: 1.45;
      color: #e6dfd0;
      background:
        radial-gradient(circle at 8% 12%, rgba(201, 160, 80, 0.08), transparent 48%),
        linear-gradient(180deg, #1a1622 0%, #100d15 100%);
      border: 1.5px solid #755b2c;
      border-radius: 7px;
      box-shadow: inset 0 0 24px rgba(0, 0, 0, 0.62);
    }

    .rel-tree-pill {
      display: inline-flex; align-items: center; padding: 1px 8px; border-radius: 4px;
      font-size: 10px; font-weight: 800; letter-spacing: 0.6px; text-transform: uppercase;
      border: 1px solid rgba(255, 255, 255, 0.14); background: rgba(0, 0, 0, 0.32);
    }
    .rel-tree-pill.key { color: #ffd966; border-color: rgba(255, 217, 102, 0.55); }
    .rel-tree-pill.owned { color: #69ffb8; border-color: rgba(94, 255, 177, 0.55); background: rgba(20, 84, 54, 0.45); }
    .rel-tree-pill.avail { color: #f8dc94; border-color: rgba(244, 214, 140, 0.55); background: rgba(201, 160, 80, 0.14); }
    .rel-tree-pill.locked { color: #8f889e; }
    .rel-tree-desc { flex-basis: 100%; color: #d9d1e6; }

    #npc-modal .modal-box {
      padding: 20px 22px 18px;
      background:
        radial-gradient(circle at 50% 0%, rgba(201, 160, 80, 0.09), transparent 55%),
        linear-gradient(180deg, #17131d 0%, #0d0b12 100%);
      border: 1.5px solid #8c6d34;
      box-shadow: inset 0 0 0 1px rgba(244, 214, 140, 0.16), inset 0 0 36px rgba(0, 0, 0, 0.72), 0 26px 75px rgba(0, 0, 0, 0.9);
    }

    #npc-modal #npc-name {
      font-size: 24px; color: #f4d68c; letter-spacing: 1.4px; text-shadow: 0 0 14px rgba(201, 160, 80, 0.35);
    }

    #npc-modal .lore-quote { margin: 0; padding-left: 10px; border-left: 2px solid #c9a050; color: #bdb2a0; font-style: italic; }
    #npc-modal #npc-body { color: #e0d8ea; }
    #npc-modal .rel-rune-divider { margin: 10px 0 2px; }

    #npc-modal #npc-choices button {
      display: flex; align-items: center; justify-content: center; gap: 8px; padding: 10px 14px;
      font-size: 13px; letter-spacing: 0.3px; cursor: pointer; color: #e9d7ad;
      background: linear-gradient(180deg, #272130 0%, #16121d 100%);
      border: 1px solid rgba(201, 160, 80, 0.45);
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.08);
      transition: transform 0.12s ease, filter 0.15s ease, border-color 0.15s ease, box-shadow 0.15s ease;
    }
    #npc-modal #npc-choices button::before { content: '✦'; font-size: 10px; color: rgba(244, 214, 140, 0.7); }
    #npc-modal #npc-choices button:hover,
    #npc-modal #npc-choices button:focus-visible {
      transform: translateY(-1px); filter: brightness(1.14); border-color: #f4d68c;
      box-shadow: 0 0 14px rgba(244, 214, 140, 0.26), inset 0 1px 0 rgba(255, 255, 255, 0.1);
      outline: none;
    }

    #pause-modal .modal-box { padding: 22px 22px 18px; }
    #pause-modal h2 { font-size: 26px; letter-spacing: 2.4px; margin: 0 0 2px !important; }
    #pause-modal .rel-rune-divider { margin: 6px 0 10px; }
    #pause-stats { display: flex; justify-content: center; flex-wrap: wrap; gap: 6px; margin-bottom: 16px !important; }

    .rel-pause-chip {
      display: inline-flex; align-items: center; gap: 5px; padding: 3px 9px; border-radius: 5px;
      font-size: 11.5px; color: #b7ab94;
      background: linear-gradient(180deg, rgba(28, 22, 37, 0.94), rgba(13, 10, 18, 0.96));
      border: 1px solid rgba(196, 156, 78, 0.4);
      box-shadow: inset 0 0 0 1px rgba(244, 214, 140, 0.06);
    }
    .rel-pause-chip b { color: #fae09b; }

    #pause-modal .flex-col > button {
      display: flex; align-items: center; justify-content: center; gap: 8px;
      padding: 10px 14px; font-size: 13px; letter-spacing: 0.5px;
    }
    #pause-modal #btn-resume-pause { padding: 13px 14px; font-size: 15px; letter-spacing: 1.4px; text-transform: uppercase; }
    #pause-modal .rel-pause-sep {
      height: 1px; margin: 4px 0;
      background: linear-gradient(90deg, transparent, rgba(201, 160, 80, 0.45), transparent);
    }
    #pause-modal .btn-crimson { border: 1px solid rgba(255, 107, 122, 0.55); letter-spacing: 0.5px; }
  `;
  document.head.appendChild(style);
}

// ============================================================================
// REUSABLE QUEST TRACKER & ANIMATED NOTIFICATION COMPONENTS
// ============================================================================

export function showQuestNotification(kind, questName, detail = '', faction = 'main') {
  if (typeof document === 'undefined') return;
  let tray = document.getElementById('hud-quest-toasts');
  if (!tray) {
    tray = document.createElement('div');
    tray.id = 'hud-quest-toasts';
    tray.className = 'sans';
    document.body.appendChild(tray);
  }

  const theme = QUEST_STATE_THEMES[kind] || QUEST_STATE_THEMES.updated;
  const fIcon = FACTION_ICONS[faction] || theme.icon;

  while (tray.children.length >= 3) {
    tray.firstElementChild.remove();
  }

  const toast = document.createElement('div');
  toast.className = 'rel-hud-panel rel-q-toast';
  toast.style.borderColor = theme.border;
  toast.style.boxShadow = `0 10px 28px rgba(0,0,0,0.8), 0 0 18px ${theme.glow}`;
  toast.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
      <span style="font-size:10px;font-weight:900;letter-spacing:1.2px;color:${theme.color};">
        ${theme.icon} ${theme.title}
      </span>
      <span style="font-size:13px;">${fIcon}</span>
    </div>
    <div class="rel-rune-divider"><span>✦</span></div>
    <div style="font-size:13px;font-weight:800;color:#f8f1e4;line-height:1.25;">${questName}</div>
    ${detail ? `<div style="font-size:11px;color:#cfc6b0;margin-top:2px;">${detail}</div>` : ''}
  `;
  tray.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('leaving');
    setTimeout(() => toast.remove(), 360);
  }, 3200);
}

function wireQuestNotifications() {
  if (questHooksWired) return;
  questHooksWired = true;

  onQuestHook('notify', evt => {
    const f = evt.quest?.faction || 'main';
    if (evt.kind === 'discover') {
      showQuestNotification('started', evt.quest.name, evt.quest.description, f);
    } else if (evt.kind === 'progress') {
      showQuestNotification('updated', evt.quest.name, `${evt.objective.label} (${evt.progress}/${evt.required})`, f);
    } else if (evt.kind === 'choice_ready') {
      showQuestNotification('updated', evt.quest.name, 'Decision Ready — Open Journal [J]', f);
    }
    updateHudQuestTracker();
  });

  onQuestHook('stageComplete', evt => {
    showQuestNotification('updated', evt.quest.name, `Completed: ${evt.stage?.title || 'Stage'}`, evt.quest?.faction);
    updateHudQuestTracker();
  });

  onQuestHook('questComplete', evt => {
    showQuestNotification('completed', evt.quest.name, evt.state?.npcState || 'Chronicle Resolved', evt.quest?.faction);
    updateHudQuestTracker();
  });

  onQuestHook('questFailed', evt => {
    showQuestNotification('failed', evt.quest.name, evt.reason || 'Chronicle Severed', evt.quest?.faction);
    updateHudQuestTracker();
  });
}

function getPrimaryTrackerModel(p) {
  const active = getQuestTrackerData();
  if (active.length) {
    const q = active[0];
    const ql = QuestlineManager.registry.get(q.id);
    let done = 0;
    let total = 0;
    let curObjLabel = q.stageTitle || 'In Progress';

    for (const o of q.objectives || []) {
      done += Math.min(o.current, o.required);
      total += o.required;
      if (!o.done && curObjLabel === (q.stageTitle || 'In Progress')) {
        curObjLabel = o.label;
      }
    }

    return {
      icon: FACTION_ICONS[ql?.faction] || q.icon || '✦',
      name: q.name,
      objective: q.awaitingChoice ? 'Decision Ready — Open Journal' : curObjLabel,
      progressText: q.awaitingChoice ? 'Ready' : `${done} / ${Math.max(1, total)} Objectives`,
      pct: total > 0 ? Math.round((done / total) * 100) : 100,
      color: q.color || '#f4d68c'
    };
  }

  // Fallback primary run expedition tracker so the player always knows their goal
  if (state.activeBoss?.alive) {
    return {
      icon: '★',
      name: state.activeBoss.bossData?.name || 'Fallen Lord',
      objective: 'Slay the Awakened Boss',
      progressText: `${p.flamesGathered} / 5 Flames`,
      pct: Math.round(((1 - state.activeBoss.hp / Math.max(1, state.activeBoss.maxHp)) * 100)),
      color: '#ff7b6b'
    };
  }

  return {
    icon: '🔥',
    name: 'First Flame Fragments',
    objective: p.flamesGathered >= 5 ? 'Enter the Altar of the First Flame' : 'Defeat Fallen Lords across the Expanse',
    progressText: `${p.flamesGathered} / 5 Objectives`,
    pct: Math.min(100, Math.round((p.flamesGathered / 5) * 100)),
    color: '#f4d68c'
  };
}

function ensureResourceQuestTracker() {
  if (typeof document === 'undefined') return null;
  let tracker = document.getElementById('hud-quest-tracker');
  if (tracker) return tracker;

  const anchor =
    document.querySelector('.hud-left') ||
    DOM['hud-gold']?.closest('.hud-left') ||
    DOM['hud-gold']?.parentElement?.parentElement;
  if (!anchor) return null;

  tracker = document.createElement('div');
  tracker.id = 'hud-quest-tracker';
  tracker.className = 'rel-hud-panel sans';
  tracker.onclick = e => {
    if (e.target.closest('[data-qt-toggle]')) return;
    openQuestModal('active');
  };
  anchor.appendChild(tracker);
  return tracker;
}

function updateHudQuestTracker() {
  const p = state.player;
  const tracker = ensureResourceQuestTracker();
  if (!tracker || !p) return;

  const minimal = Boolean(metaSave.settings.minimalHud);
  tracker.classList.toggle('minimal', minimal);

  const model = getPrimaryTrackerModel(p);
  const sig = `${minimal}|${model.name}|${model.objective}|${model.progressText}|${model.pct}`;
  if (sig === lastTrackerSignature) return;
  lastTrackerSignature = sig;

  tracker.style.borderColor = `${model.color}aa`;
  tracker.innerHTML = `
    <div class="rel-qt-head">
      <div class="rel-qt-title" style="color:${model.color};">
        <span>${model.icon}</span>
        <span style="overflow:hidden;text-overflow:ellipsis;">${model.name}</span>
      </div>
      <div class="rel-qt-actions">
        <button type="button" class="rel-qt-mini-btn" data-qt-toggle="1" title="Toggle Minimal Quest Tracker">${minimal ? '▾' : '▴'}</button>
        <button type="button" class="rel-qt-mini-btn" data-qt-journal="1" title="Open Quest Journal [J]">📖</button>
      </div>
    </div>
    <div class="rel-rune-divider"><span>✦</span></div>
    <div class="rel-qt-obj" title="${model.objective}">${model.objective}</div>
    <div class="rel-qt-prog-row">
      <div class="rel-qt-track"><div class="rel-qt-fill" style="width:${model.pct}%;background:linear-gradient(90deg, ${model.color}88, ${model.color});"></div></div>
      <span style="white-space:nowrap;color:${model.color};">${model.progressText}</span>
    </div>
  `;

  const toggleBtn = tracker.querySelector('[data-qt-toggle]');
  if (toggleBtn) {
    toggleBtn.onclick = e => {
      e.stopPropagation();
      metaSave.settings.minimalHud = !metaSave.settings.minimalHud;
      persistSave();
      lastTrackerSignature = '';
      updateHudQuestTracker();
    };
  }
  const jBtn = tracker.querySelector('[data-qt-journal]');
  if (jBtn) {
    jBtn.onclick = e => {
      e.stopPropagation();
      openQuestModal('active');
    };
  }
}

// ============================================================================
// EXISTING HUD ENHANCEMENTS & BUILD
// ============================================================================

function enhanceResourceDisplay() {
  for (const spec of RESOURCE_SPECS) {
    const valEl = DOM[spec.id];
    if (!valEl || valEl.dataset.relResDone) continue;
    valEl.dataset.relResDone = '1';

    const parent = valEl.parentElement;
    if (!parent) continue;

    const siblingResCount = RESOURCE_SPECS.filter(s => parent.querySelector(`#${s.id}`)).length;
    valEl.classList.add('rel-res-val');
    valEl.style.color = spec.color;

    const ico = document.createElement('span');
    ico.className = 'rel-res-ico';
    ico.innerHTML = spec.icon;
    ico.style.color = spec.color;
    ico.title = spec.label;

    if (siblingResCount === 1) {
      parent.classList.add('rel-res-pill');
      parent.title = spec.label;
      parent.replaceChildren(ico, valEl);
    } else {
      parent.classList.add('rel-res-bar');
      const prev = valEl.previousSibling;
      if (prev && prev.nodeType === 3 && /gold|shard|essence|flame|frag/i.test(prev.textContent)) {
        prev.textContent = '';
      }
      const pill = document.createElement('span');
      pill.className = 'rel-res-pill';
      pill.title = spec.label;
      parent.insertBefore(pill, valEl);
      pill.append(ico, valEl);
    }
  }
}

function enhanceHudPanels() {
  const titleEl = DOM['quest-title'];
  const descEl = DOM['quest-desc'];
  if (titleEl) {
    titleEl.textContent = '✦ Objective';
    const box = titleEl.parentElement;
    if (box && !box.dataset.relQuestDone) {
      box.dataset.relQuestDone = '1';
      box.classList.add('rel-hud-panel', 'rel-quest-plaque');
      if (descEl) {
        const div = document.createElement('div');
        div.className = 'rel-rune-divider';
        div.innerHTML = '<span>✦</span>';
        box.insertBefore(div, descEl);
      }
    }
  }
  if (descEl) {
    descEl.textContent = '0 / 5 Fragments';
  }

  const timerBox = DOM['timer-text']?.parentElement;
  if (timerBox && timerBox === DOM['biome-text']?.parentElement && !timerBox.dataset.relWorldDone) {
    timerBox.dataset.relWorldDone = '1';
    timerBox.classList.add('rel-hud-panel', 'rel-world-plaque');
  }
}

function enhanceHudBars() {
  const track = DOM['hp-fill']?.parentElement;
  if (track && !track.dataset.relBarDone) {
    track.dataset.relBarDone = '1';
    track.classList.add('rel-bar-track');
  }
}

function enhanceBossBar() {
  const wrap = DOM['boss-bar-wrap'];
  const nameEl = DOM['boss-name'];
  const fillEl = DOM['boss-fill'];
  if (!wrap || !nameEl || wrap.dataset.relBossDone) return;
  wrap.dataset.relBossDone = '1';
  wrap.classList.add('rel-hud-panel', 'rel-boss-ceremony');

  const header = document.createElement('div');
  header.className = 'rel-boss-header';

  const crest = document.createElement('div');
  crest.className = 'rel-boss-crest';
  crest.id = 'rel-boss-crest';
  crest.textContent = '★';

  const titles = document.createElement('div');
  titles.className = 'rel-boss-titles';

  const epithet = document.createElement('div');
  epithet.className = 'rel-boss-epithet';
  epithet.id = 'rel-boss-epithet';
  epithet.textContent = 'Sovereign of the Sundering';

  titles.append(epithet, nameEl);
  header.append(crest, titles);

  const divider = document.createElement('div');
  divider.className = 'rel-rune-divider';
  divider.innerHTML = '<span>❖</span>';

  const track = fillEl?.parentElement;
  if (track && track !== wrap) {
    track.classList.add('rel-boss-bar-track');
    wrap.insertBefore(header, track);
    wrap.insertBefore(divider, track);
  } else {
    wrap.prepend(header, divider);
  }
}

function attachCompassAndLegend(container, mapNode) {
  container.classList.add('rel-hud-panel', 'rel-minimap-frame');

  const hdr = document.createElement('div');
  hdr.className = 'rel-map-header sans';
  hdr.innerHTML = '<span>✦ Cartograph</span><span>🧭</span>';

  const compass = document.createElement('div');
  compass.className = 'rel-compass-wrap';
  compass.innerHTML = `
    <span class="rel-compass-dir n">N</span>
    <span class="rel-compass-dir s">S</span>
    <span class="rel-compass-dir w">W</span>
    <span class="rel-compass-dir e">E</span>
  `;
  mapNode.classList.remove('panel-box');
  compass.appendChild(mapNode);

  const divBot = document.createElement('div');
  divBot.className = 'rel-rune-divider';
  divBot.innerHTML = '<span>✦</span>';

  const legendWrap = document.createElement('div');
  legendWrap.className = 'rel-map-legend sans';
  legendWrap.innerHTML = MAP_LEGEND.map(
    m => `<span class="rel-map-legend-item" title="${m.label}" style="color:${m.color};">${m.icon}</span>`
  ).join('');

  container.append(hdr, compass, divBot, legendWrap);
}

function enhanceMinimap() {
  if (typeof document === 'undefined') return;
  if (document.getElementById('rel-minimap-panel') || document.querySelector('[data-rel-minimap-ready]')) return;

  const existingCanvas = document.querySelector('canvas#minimap, canvas#minimap-canvas, canvas[id*="minimap"]');
  if (existingCanvas) {
    const frame = document.createElement('div');
    frame.dataset.relMinimapReady = '1';
    existingCanvas.parentNode.insertBefore(frame, existingCanvas);
    attachCompassAndLegend(frame, existingCanvas);
    return;
  }

  const panel = document.createElement('div');
  panel.id = 'rel-minimap-panel';
  panel.dataset.relMinimapReady = '1';

  const canvas = document.createElement('canvas');
  canvas.id = 'rel-minimap-canvas';
  canvas.width = 128;
  canvas.height = 128;
  canvas.style.display = 'block';
  canvas.style.borderRadius = '4px';

  attachCompassAndLegend(panel, canvas);
  document.body.appendChild(panel);
}

function collectMapMarkers() {
  const markers = [];
  const pushMarker = (entity, icon, color, size = 11) => {
    if (!entity || typeof entity.x !== 'number' || typeof entity.y !== 'number') return;
    markers.push({ x: entity.x, y: entity.y, icon, color, size });
  };

  if (state.activeBoss?.alive) {
    pushMarker(state.activeBoss, '★', '#ff5263', 13);
  }

  if (Array.isArray(state.enemies)) {
    for (const e of state.enemies) {
      if (!e?.alive || e === state.activeBoss) continue;
      if (e.isBoss || e.bossData) pushMarker(e, '★', '#ff5263', 13);
      else if (e.isElite || e.isChampion || e.elite || e.champion) pushMarker(e, '⚔', '#ff9d47', 11);
    }
  }

  const poiLists = [state.pois, state.worldEvents, state.events, state.shrines, state.vaults, state.npcs, state.merchants, state.flames, state.fragments];
  for (const list of poiLists) {
    if (!Array.isArray(list)) continue;
    for (const item of list) {
      if (!item || item.collected || item.used || item.completed) continue;
      const kind = String(item.type || item.kind || item.role || '').toLowerCase();
      if (kind.includes('boss')) pushMarker(item, '★', '#ff5263', 12);
      else if (kind.includes('champ') || kind.includes('elite')) pushMarker(item, '⚔', '#ff9d47', 11);
      else if (kind.includes('flame') || kind.includes('frag') || list === state.flames || list === state.fragments) pushMarker(item, '✦', '#ffe078', 11);
      else if (kind.includes('vault')) pushMarker(item, '▲', '#f4c752', 11);
      else if (kind.includes('merch') || kind.includes('peddler') || list === state.merchants) pushMarker(item, '●', '#6effb0', 10);
      else if (kind.includes('shrine') || kind.includes('altar') || list === state.shrines) pushMarker(item, '✚', '#d7a8ff', 11);
      else if (kind.includes('event') || list === state.events || list === state.worldEvents) pushMarker(item, '♦', '#7ce8ff', 11);
    }
  }

  return markers;
}

function updateMinimapHud(p) {
  const canvas = document.getElementById('rel-minimap-canvas');
  if (!canvas || !p) return;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const w = canvas.width;
  const h = canvas.height;
  const cx = w / 2;
  const cy = h / 2;
  const range = 1450;

  ctx.clearRect(0, 0, w, h);

  const bg = ctx.createRadialGradient(cx, cy, 8, cx, cy, w * 0.72);
  bg.addColorStop(0, '#231b15');
  bg.addColorStop(1, '#0d0a10');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = 'rgba(201, 160, 80, 0.16)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(cx, cy, 24, 0, Math.PI * 2);
  ctx.arc(cx, cy, 48, 0, Math.PI * 2);
  ctx.moveTo(cx, 4);
  ctx.lineTo(cx, h - 4);
  ctx.moveTo(4, cy);
  ctx.lineTo(w - 4, cy);
  ctx.stroke();

  const markers = collectMapMarkers();
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  for (const m of markers) {
    const dx = ((m.x - p.x) / range) * (w * 0.44);
    const dy = ((m.y - p.y) / range) * (h * 0.44);
    const dist = Math.hypot(dx, dy);
    const maxR = w * 0.43;
    const px = dist > maxR ? cx + (dx / dist) * maxR : cx + dx;
    const py = dist > maxR ? cy + (dy / dist) * maxR : cy + dy;

    ctx.font = `bold ${m.size}px sans-serif`;
    ctx.fillStyle = m.color;
    ctx.fillText(m.icon, px, py);
  }

  ctx.fillStyle = '#fff5d6';
  ctx.strokeStyle = '#c9a050';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(cx, cy, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
}

function resolveBossPresentation(boss) {
  const data = boss.bossData || {};
  const keyText = `${data.id || ''} ${data.name || ''} ${data.faction || ''} ${data.title || ''}`.toLowerCase();
  const theme = BOSS_FACTION_THEMES.find(t => t.match.test(keyText)) || {
    crest: '👑',
    title: 'Lord of the Ashen Expanse',
    color: '#ff6b52'
  };

  return {
    crest: data.crest || theme.crest,
    title: data.title || data.epithet || theme.title,
    name: String(data.name || 'Ancient Warden').toUpperCase(),
    phase: boss.phase || 1,
    color: theme.color
  };
}

function updateBossHud() {
  const wrap = DOM['boss-bar-wrap'];
  if (!wrap) return;

  if (!state.activeBoss?.alive) {
    wrap.style.display = 'none';
    lastBossAnnouncedId = null;
    return;
  }

  wrap.style.display = 'block';
  const boss = state.activeBoss;
  const info = resolveBossPresentation(boss);
  const bossKey = boss.id || boss.bossData?.name || 'boss';

  if (lastBossAnnouncedId !== bossKey) {
    lastBossAnnouncedId = bossKey;
    wrap.classList.remove('rel-boss-awaken');
    void wrap.offsetWidth;
    wrap.classList.add('rel-boss-awaken');
  }

  const crestEl = document.getElementById('rel-boss-crest');
  const epithetEl = document.getElementById('rel-boss-epithet');
  if (crestEl) {
    crestEl.textContent = info.crest;
    crestEl.style.borderColor = info.color;
    crestEl.style.boxShadow = `0 0 18px ${info.color}66`;
  }
  if (epithetEl) {
    epithetEl.textContent = `${info.title} • Phase ${info.phase}`;
  }

  setElText('boss-name', info.name);
  setBarPct(DOM['boss-fill'], boss.hp, boss.maxHp);
}

function updateQuestHud(p) {
  setElText('quest-title', '✦ Objective');
  if (state.activeBoss?.alive) {
    setElText('quest-desc', `Slay ${state.activeBoss.bossData?.name || 'Boss'} (${p.flamesGathered}/5)`);
  } else if (p.flamesGathered >= 5) {
    setElText('quest-desc', 'Confront Boss • 5 / 5');
  } else {
    setElText('quest-desc', `Fragments • ${p.flamesGathered} / 5`);
  }
  updateHudQuestTracker();
}

function updateWeaponsHud(p) {
  if (!DOM['weapons-bar']) return;
  DOM['weapons-bar'].innerHTML = Object.entries(p.weapons)
    .map(([k, w]) => {
      const def = WEAPONS_DEF[k];
      if (!def) return '';
      return `<div class="weapon-pill ${w.evolved ? 'evolved' : ''}" style="border-color:${def.color}66"><span style="color:${def.color}">✦</span>${w.evolved ? def.evolved : def.name} Lv.${w.level}</div>`;
    })
    .join('');
}

export function buildUI() {
  ensureHudStyles();

  $('hud-btns').innerHTML = HUD_BUTTONS.map(b => {
    const m = b.label.match(/^(.*?)\s*\[(.+)\]$/);
    const name = m ? m[1] : b.label;
    const key = m ? ` <kbd class="rel-key">${m[2]}</kbd>` : '';
    return `<button class="hud-btn" id="${b.id}">${b.icon} ${name}${key}${b.dot ? `<span class="badge-dot" id="${b.dot}">0</span>` : ''}</button>`;
  }).join('');

  const journalBtn = $('btn-quest');
  if (journalBtn) journalBtn.onclick = () => openQuestModal('active');

  const menuTabs = [
    ['play', 'Embark', 1],
    ['reliquary', 'Reliquary'],
    ['modes', 'Tiers &amp; Realms'],
    ['codex-main', 'Codex'],
    ['settings-main', 'Settings']
  ];

  const relTabs = [
    ['upgrades', 'Sanctum Upgrades', 1],
    ['relics', 'Relics (Max 3)'],
    ['masteries', 'Weapon Masteries'],
    ['unlocks', 'Evolutions, Bosses &amp; Realms']
  ];

  const settingsChecks = [
    ['opt-sound', 'Procedural Audio &amp; Ambient Drone'],
    ['opt-shake', 'Screen Shake on Heavy Hits'],
    ['opt-dmgnum', 'Floating Damage Numbers'],
    ['opt-autosalvage', 'Auto-Salvage Common Drops When Bag Full'],
    ['opt-postfx', 'Post-Processing (Bloom, Grading &amp; Vignette)'],
    ['opt-minimalhud', 'Minimal Quest Tracker HUD']
  ];

  const forgeBtns = [
    ['cf-reroll', 'btn-dark', 'Reroll Affixes (40 Gold)'],
    ['cf-reforge', 'btn-dark', 'Reforge Values (60 Gold)'],
    ['cf-enchant', 'btn-dark', 'Enchant +1 Affix (3 Shards)'],
    ['cf-upgrade', 'btn-dark', 'Upgrade Rarity (2 Essence)'],
    ['cf-socket', 'btn-dark', 'Socket Random Gem (50 Gold)'],
    ['cf-salvage', 'btn-crimson', 'Salvage for Essence &amp; Shards']
  ];

  $('modal-root').innerHTML = [
    overlay(
      'menu-modal',
      `
      <h1 class="title">THE ASHEN EXPANSE</h1>
      <p class="subtitle">"Thousands of years after the Sundering, the First Flame lingers only in ash and madness."</p>
      <div class="tabs sans" style="justify-content:center;">${renderTabButtons(menuTabs, 'menutab')}</div>
      <div class="sans" style="text-align:center;font-size:12px;color:var(--ash);margin-bottom:12px;" id="vault-bar"></div>
      <div id="mtab-play">
        <div class="grid-3" id="class-grid"></div>
        <div class="flex-row" style="justify-content:center;margin-top:16px;">
          <button class="btn-gold" id="btn-begin-run" style="font-size:16px;padding:12px 38px;">ENTER THE ASHEN EXPANSE</button>
        </div>
        <p class="sans" style="text-align:center;font-size:11px;color:#8f899e;margin-top:10px;">
          WASD / Arrows / Touch • Space/Shift: Dash • I: Gear • T: Tree • C: Forge • J: Journal
        </p>
      </div>
      <div id="mtab-reliquary" style="display:none;" class="sans">
        <div class="tabs" id="rel-subtabs">${renderTabButtons(relTabs, 'reltab')}</div>
        <div id="rel-content"></div>
      </div>
      <div id="mtab-modes" style="display:none;" class="sans">
        <div class="grid-2">
          <div class="card">
            <h3 style="margin:0 0 8px;color:var(--gold);">World Tiers &amp; Realms</h3>
            <div id="tier-buttons" class="tabs"></div>
            <div id="tier-desc" style="font-size:11px;color:var(--ash);margin-bottom:10px;"></div>
            <label style="display:block;font-size:12px;margin-bottom:4px;color:var(--gold);">Starting Biome:</label>
            <select id="start-biome-select" class="btn-dark" style="width:100%;margin-bottom:8px;"></select>
            <label style="display:block;font-size:12px;margin-bottom:4px;color:var(--gold);">Endgame Dungeon (Unlock in Reliquary):</label>
            <select id="dungeon-select" class="btn-dark" style="width:100%;"></select>
          </div>
          <div class="card">
            <h3 style="margin:0 0 8px;color:var(--gold);">Expeditions, Arenas &amp; Hunts</h3>
            <div id="modes-list" class="flex-col" style="gap:7px;font-size:12px;"></div>
          </div>
        </div>
      </div>
      <div id="mtab-codex-main" style="display:none;"><div id="main-codex-content"></div></div>
      <div id="mtab-settings-main" style="display:none;" class="sans">
        <div class="card" style="max-width:480px;margin:0 auto;">
          <h3 style="margin-top:0;color:var(--gold);">Settings</h3>
          ${settingsChecks
            .map(([id, lbl]) => `<label class="flex-row" style="justify-content:space-between;margin-bottom:10px;"><span>${lbl}</span><input type="checkbox" id="${id}" checked></label>`)
            .join('')}
          <label class="flex-row" style="justify-content:space-between;margin-bottom:14px;">
            <span>Visual Quality</span>
            <select id="opt-quality" class="btn-dark">
              <option value="high">High (Dynamic Lights &amp; Parallax)</option>
              <option value="low">Low (Performance Mode)</option>
            </select>
          </label>
          <button class="btn-crimson" id="btn-wipe-save">Reset All Saved Progress</button>
        </div>
      </div>`,
      '',
      true
    ),
    overlay(
      'levelup-modal',
      `<h2 style="text-align:center;color:var(--gold2);margin:0 0 4px;" id="lvlup-title">FLAME AWAKENED</h2>
       <p class="subtitle" style="margin-bottom:14px;">Choose a Blessing (Keys 1, 2, 3) • +1 Tree Point [T]</p>
       <div class="grid-3" id="upgrade-cards"></div>`,
      'max-width:820px;'
    ),
    overlay(
      'inv-modal',
      `${modalHdr(
        'RELIQUARY &amp; EQUIPMENT',
        '<button class="btn-dark" id="btn-salvage-junk">Salvage Common/Magic</button><button class="btn-gold" id="btn-close-inv">Resume [I / Esc]</button>'
      )}
      <div class="inv-cols">
        <div>
          <div class="sans" style="font-size:12px;color:var(--gold);font-weight:700;margin-bottom:6px;">EQUIPPED (6 SLOTS)</div>
          <div id="equipped-slots"></div>
          <div id="set-bonuses-box" class="stat-pill sans" style="margin-top:8px;"></div>
          <div id="char-stats-box" class="stat-pill sans" style="margin-top:8px;line-height:1.55;"></div>
        </div>
        <div>
          <div class="sans flex-row" style="justify-content:space-between;font-size:12px;color:var(--gold);font-weight:700;margin-bottom:6px;">
            <span>PACK (<span id="bag-count">0</span>/20)</span>
            <span>GEMS: <span id="gem-count">0</span></span>
          </div>
          <div class="bag-grid" id="bag-grid"></div>
          <div class="item-tooltip-box" id="item-inspector"></div>
        </div>
      </div>`
    ),
    overlay(
      'tree-modal',
      `${modalHdr(
        'PATH OF ASH — PASSIVE SKILL TREE',
        '<span>Points: <b id="tree-pts" style="color:var(--gold2);">0</b></span><button class="btn-dark" id="btn-reset-tree">Respec (100G)</button><button class="btn-gold" id="btn-close-tree">Resume [T / Esc]</button>'
      )}
      <canvas id="tree-canvas" width="960" height="420"></canvas>
      <div id="tree-node-info" class="item-tooltip-box sans" style="margin-top:8px;">
        Click any highlighted node to allocate. Gold nodes are <b>Keystones</b>.
      </div>`
    ),
    overlay(
      'craft-modal',
      `${modalHdr(
        'THE ASHEN FORGE',
        '<span>Gold: <b id="craft-gold">0</b> | Shards: <b id="craft-shards">0</b> | Essence: <b id="craft-essence">0</b></span><button class="btn-gold" id="btn-close-craft">Resume [C / Esc]</button>'
      )}
      <div class="inv-cols">
        <div>
          <div class="sans" style="font-size:12px;color:var(--gold);margin-bottom:6px;">SELECT ITEM</div>
          <div id="craft-item-list" style="max-height:360px;overflow-y:auto;"></div>
        </div>
        <div>
          <div id="craft-selected-box" class="item-tooltip-box" style="margin-top:0;"></div>
          <div class="grid-2 sans" style="margin-top:10px;gap:8px;">
            ${forgeBtns.map(([id, c, t]) => `<button class="${c}" id="${id}">${t}</button>`).join('')}
          </div>
        </div>
      </div>`
    ),
    overlay(
      'npc-modal',
      `<h2 id="npc-name" style="color:var(--gold2);margin:0 0 6px;"></h2>
       <p id="npc-quote" class="lore-quote" style="font-size:14px;"></p>
       <div class="rel-rune-divider"><span>✦</span></div>
       <div id="npc-body" class="sans" style="font-size:13px;color:#d7d0e6;margin:12px 0;line-height:1.5;"></div>
       <div id="npc-choices" class="flex-col" style="gap:8px;"></div>`,
      'max-width:620px;'
    ),
    overlay(
      'codex-modal',
      `${modalHdr('CODEX OF THE SUNDERING', '<button class="btn-gold" id="btn-close-codex">Close [Esc]</button>')}
       <div id="ingame-codex-content"></div>`
    ),
    overlay(
      'pause-modal',
      `<h2 style="color:var(--gold2);margin-top:0;">RIFT SUSPENDED</h2>
       <div class="rel-rune-divider"><span>✦</span></div>
       <div id="pause-stats" class="sans" style="font-size:13px;color:var(--ash);margin-bottom:16px;"></div>
       <div class="flex-col" style="gap:8px;">
         <button class="btn-gold" id="btn-resume-pause">✦ Resume Expedition</button>
         <button class="btn-dark" id="btn-open-inv-p">🛡 Equipment &amp; Reliquary</button>
         <button class="btn-dark" id="btn-open-tree-p">🌿 Passive Skill Tree</button>
         <button class="btn-dark" id="btn-open-craft-p">⚒ Ashen Forge</button>
         <button class="btn-dark" id="btn-open-quest-p">📖 Quest Journal</button>
         <div class="rel-pause-sep"></div>
         <button class="btn-crimson" id="btn-abandon">☠ Abandon Run</button>
       </div>`,
      'max-width:440px;text-align:center;'
    ),
    overlay(
      'ending-modal',
      `<h2 id="end-title" style="font-size:28px;color:var(--gold2);margin:0 0 6px;"></h2>
       <p id="end-sub" class="lore-quote" style="text-align:left;font-size:14px;"></p>
       <div id="end-choices" class="grid-2" style="margin:14px 0;"></div>
       <div id="end-summary" class="grid-3 sans" style="margin:14px 0;"></div>
       <button class="btn-gold" id="btn-return-menu" style="display:none;font-size:15px;padding:11px 30px;">RETURN TO RELIQUARY</button>`,
      'max-width:740px;text-align:center;'
    )
  ].join('');

  DOM_IDS.forEach(id => {
    DOM[id] = $(id);
  });

  const pauseQuestBtn = $('btn-open-quest-p');
  if (pauseQuestBtn) {
    pauseQuestBtn.onclick = () => {
      DOM['pause-modal']?.classList.remove('active');
      openQuestModal('active');
    };
  }

  enhanceResourceDisplay();
  enhanceHudPanels();
  enhanceBossBar();
  enhanceHudBars();
  enhanceMinimap();
  ensureResourceQuestTracker();
  wireQuestNotifications();

  const postFxEl = $('opt-postfx');
  if (postFxEl) {
    postFxEl.checked = metaSave.settings.postFx !== false;
    postFxEl.onchange = () => {
      metaSave.settings.postFx = postFxEl.checked;
      persistSave();
    };
  }
  const minHudEl = $('opt-minimalhud');
  if (minHudEl) {
    minHudEl.checked = Boolean(metaSave.settings.minimalHud);
    minHudEl.onchange = () => {
      metaSave.settings.minimalHud = minHudEl.checked;
      persistSave();
      lastTrackerSignature = '';
      updateHudQuestTracker();
    };
  }
  const qualEl = $('opt-quality');
  if (qualEl) {
    qualEl.value = metaSave.settings.gfxQuality || 'high';
    qualEl.onchange = () => {
      metaSave.settings.gfxQuality = qualEl.value;
      persistSave();
    };
  }
}

export function updateHud() {
  const p = state.player;
  if (!p) return;

  const wt = WorldTierConfig.tiers[state.worldTier] || { roman: 'I' };
  const biomeName = BIOMES[state.biomeIdx]?.name || 'Ashen Wastes';

  setBarPct(DOM['xp-fill'], p.xp, p.xpToNext);
  setBarPct(DOM['hp-fill'], p.hp, p.maxHp);
  setElText('lvl-badge', `LV ${p.level}`);
  setElText('hp-text', `${Math.ceil(p.hp)} / ${p.maxHp}`);

  setElText('hud-gold', state.runGold);
  setElText('hud-shards', state.runShards);
  setElText('hud-essence', state.runEssence);
  setElText('hud-flames', `${p.flamesGathered}/5`);

  setElText('timer-text', `⏳ ${fmtTime(state.time)}`);
  setElText('biome-text', `❖ ${biomeName} • Tier ${wt.roman}`);

  updateQuestHud(p);
  updateBossHud();

  setBadgeCount(DOM['bag-dot'], state.newLoot);
  setBadgeCount(DOM['tree-dot'], p.treePoints);
  setElText('dash-pill', p.dashCd > 0 ? `⚡ DASH (${p.dashCd.toFixed(1)}s)` : '⚡ DASH [SPACE]');

  updateWeaponsHud(p);
  updateMinimapHud(p);
}