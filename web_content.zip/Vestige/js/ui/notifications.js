import { CFG } from '../core/config.js';
import { mk, drawText } from '../core/utilities.js';
import { metaSave } from '../core/save.js';
import { state, textPool } from '../core/game.js';
import { DOM } from './hud.js';

export function addFeed(msg, color = '#c9a050') {
  const d = mk('div', 'feed-msg');
  d.style.borderLeftColor = d.style.color = color;
  d.textContent = msg;
  DOM['loot-feed'].appendChild(d);
  setTimeout(() => d.remove(), CFG.ui.FEED_MS);
  while (DOM['loot-feed'].children.length > CFG.ui.FEED_MAX) {
    DOM['loot-feed'].firstChild.remove();
  }
}

export function showBanner(title, sub, color = '#f0cf85', dur = 2.6) {
  state.banner = { title, sub, color, life: dur, maxLife: dur };
}

function pathRounded(ctx, x, y, w, h, r) {
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, r);
  else ctx.rect(x, y, w, h);
}

function drawDiamond(ctx, x, y, r) {
  ctx.beginPath();
  ctx.moveTo(x, y - r);
  ctx.lineTo(x + r, y);
  ctx.lineTo(x, y + r);
  ctx.lineTo(x - r, y);
  ctx.closePath();
  ctx.fill();
}

// Ornate plaque matching the HUD panels: gradient body, double gold frame,
// corner diamonds, glowing title and a rune divider. Eases in and fades out.
export function renderBanner(ctx, viewW) {
  if (!state.banner) return;
  const b = state.banner;
  const a = Math.min(1, b.life * 2, (b.maxLife - b.life) * 4 + 0.2);
  const intro = Math.min(1, (b.maxLife - b.life) / 0.35);
  const ease = 1 - Math.pow(1 - intro, 3);

  const w = 480;
  const h = 66;
  const x = viewW / 2 - w / 2;
  const y = 104 - (1 - ease) * 14;
  const cx = viewW / 2;

  ctx.save();
  ctx.globalAlpha = a;

  // Body
  const body = ctx.createLinearGradient(0, y, 0, y + h);
  body.addColorStop(0, 'rgba(30, 24, 40, 0.94)');
  body.addColorStop(1, 'rgba(10, 8, 15, 0.96)');
  ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
  ctx.shadowBlur = 18;
  ctx.shadowOffsetY = 6;
  ctx.fillStyle = body;
  pathRounded(ctx, x, y, w, h, 8);
  ctx.fill();
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;

  // Soft accent glow from the top edge
  const glow = ctx.createRadialGradient(cx, y, 4, cx, y, w * 0.55);
  glow.addColorStop(0, b.color + '33');
  glow.addColorStop(1, b.color + '00');
  ctx.fillStyle = glow;
  pathRounded(ctx, x, y, w, h, 8);
  ctx.fill();

  // Double frame
  ctx.strokeStyle = b.color;
  ctx.lineWidth = 1.5;
  pathRounded(ctx, x, y, w, h, 8);
  ctx.stroke();
  ctx.globalAlpha = a * 0.35;
  ctx.lineWidth = 1;
  pathRounded(ctx, x + 4, y + 4, w - 8, h - 8, 5);
  ctx.stroke();
  ctx.globalAlpha = a;

  // Corner diamonds + side ornaments
  ctx.fillStyle = b.color;
  drawDiamond(ctx, x, y + h / 2, 4);
  drawDiamond(ctx, x + w, y + h / 2, 4);
  drawDiamond(ctx, cx, y, 3.5);
  drawDiamond(ctx, cx, y + h, 3.5);

  // Title
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  if ('letterSpacing' in ctx) ctx.letterSpacing = '3px';
  ctx.font = 'bold 20px Georgia, serif';
  ctx.shadowColor = b.color;
  ctx.shadowBlur = 12;
  ctx.fillStyle = b.color;
  ctx.fillText(String(b.title).toUpperCase(), cx, y + 24);
  ctx.shadowBlur = 0;
  if ('letterSpacing' in ctx) ctx.letterSpacing = '0px';

  // Rune divider
  const dy = y + 38;
  const lg = ctx.createLinearGradient(cx - 150, 0, cx + 150, 0);
  lg.addColorStop(0, b.color + '00');
  lg.addColorStop(0.5, b.color + 'aa');
  lg.addColorStop(1, b.color + '00');
  ctx.strokeStyle = lg;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(cx - 150, dy);
  ctx.lineTo(cx + 150, dy);
  ctx.stroke();
  ctx.fillStyle = b.color;
  drawDiamond(ctx, cx, dy, 2.5);

  // Subtitle
  drawText(ctx, b.sub, cx, y + 53, '#d8d0e6', '12px sans-serif');

  ctx.restore();
}

export function spawnFloatText(x, y, text, color = '#fff', size = 13) {
  if (metaSave.settings.dmgNum && textPool.active.length <= 180) {
    Object.assign(textPool.spawn(), {
      x: x + (Math.random() - 0.5) * 14,
      y: y - 14,
      vy: -38,
      text,
      color,
      life: 0.58,
      size
    });
  }
}

export function renderFloatTexts(ctx) {
  for (let i = 0; i < textPool.active.length; i++) {
    const ft = textPool.active[i];
    ctx.globalAlpha = Math.min(1, ft.life * 2);
    drawText(ctx, ft.text, ft.x + 1, ft.y + 1, '#000', `700 ${ft.size}px sans-serif`);
    drawText(ctx, ft.text, ft.x, ft.y, ft.color, `700 ${ft.size}px sans-serif`);
  }
  ctx.globalAlpha = 1;
}
