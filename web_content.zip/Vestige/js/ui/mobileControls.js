import { drawCircle, drawRing } from '../core/utilities.js';
import { joy } from '../core/input.js';
import { triggerDash } from '../entities/player.js';
import { DOM } from './hud.js';

let initialized = false;

export function initMobileControls() {
  if (initialized) return;
  initialized = true;
  DOM['mobile-dash'].addEventListener(
    'touchstart',
    e => {
      e.stopPropagation();
      triggerDash();
    },
    { passive: true }
  );
}

export function showMobileDash() {
  if (DOM['mobile-dash']) DOM['mobile-dash'].style.display = 'block';
}

export function renderJoystick(ctx) {
  if (!joy.active) return;
  drawRing(ctx, joy.sx, joy.sy, 48, 'rgba(255,255,255,.3)', 2);
  drawCircle(ctx, joy.sx + joy.dx * 48, joy.sy + joy.dy * 48, 20, 'rgba(201,160,80,.55)');
}