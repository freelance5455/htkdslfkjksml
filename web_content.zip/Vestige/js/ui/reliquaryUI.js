import { $, mk, fmtTime } from '../core/utilities.js';
import { metaSave, persistSave, resetSave, spendCost, fmtCost, hasUnlock } from '../core/save.js';
import { state } from '../core/game.js';

import { CLASSES } from '../data/classes.js';
import { RELICS, RELIQUARY_UNLOCKS, META_UPGRADES_DEF } from '../data/relicData.js';
import { WorldTierConfig, MODES_CONFIG } from '../data/worldTierData.js';

import { MASTERIES, addMasteryXp } from '../systems/mastery.js';
import { toggleRelic } from '../systems/relics.js';
import { purchaseMetaUpgrade, purchaseReliquaryUnlock } from '../systems/reliquary.js';
import { DUNGEONS } from '../systems/dungeons.js';
import { BIOMES } from '../world/biomes.js';

import { renderCodex } from './codexUI.js';
import { DOM } from './hud.js';

const expandedLoreIds = new Set();

const CLASS_HERO_META = {
  warrior: {
    icon: '⚔',
    faction: 'Warfare',
    rune: 'ᛟ',
    color: '#ff704d',
    glow: 'rgba(255, 112, 77, 0.36)',
    surface: 'rgba(138, 36, 20, 0.28)',
    specialty: 'Frontline Cleave & Iron Endurance',
    attrs: [
      ['🩸', 'Vitality'],
      ['⚔', 'Heavy Cleave'],
      ['🛡', 'Vanguard']
    ],
    silhouette: `
      <path d="M60 16l7 8-3 8 14 7 6 19-9 4 4 42H41l4-42-9-4 6-19 14-7-3-8 7-8z"/>
      <path d="M88 18l5 4-16 42-6-3z"/>
      <path d="M48 16l-6-8 10 4zM72 16l6-8-10 4z"/>
    `
  },
  mage: {
    icon: '✧',
    faction: 'Arcane',
    rune: 'ᚲ',
    color: '#5eb0ff',
    glow: 'rgba(94, 176, 255, 0.4)',
    surface: 'rgba(24, 68, 146, 0.28)',
    specialty: 'Elemental Convergence & Wide Area',
    attrs: [
      ['🔮', 'Arcane Burst'],
      ['💥', 'Wide Area'],
      ['⚡', 'Spell Haste']
    ],
    silhouette: `
      <path d="M60 12l12 18-4 10 14 18-8 46H46l-8-46 14-18-4-10z"/>
      <circle cx="88" cy="24" r="7"/>
      <path d="M86 33h4v68h-4z"/>
    `
  },
  necromancer: {
    icon: '☠',
    faction: 'Death',
    rune: 'ᚦ',
    color: '#5effb1',
    glow: 'rgba(94, 255, 177, 0.34)',
    surface: 'rgba(18, 92, 58, 0.28)',
    specialty: 'Undead Legion & Soul Attrition',
    attrs: [
      ['💀', 'Summons'],
      ['🧲', 'Soul Harvest'],
      ['☠', 'Blight Drain']
    ],
    silhouette: `
      <path d="M60 15c8 0 12 7 10 15l13 14-6 60H43l-6-60 13-14c-2-8 2-15 10-15z"/>
      <path d="M86 14c-14 2-22 10-25 18 10-4 18-3 24 1v68h4V14h-3z"/>
      <circle cx="32" cy="40" r="6"/>
    `
  },
  ranger: {
    icon: '🏹',
    faction: 'Warfare',
    rune: 'ᛇ',
    color: '#9ee86b',
    glow: 'rgba(158, 232, 107, 0.34)',
    surface: 'rgba(42, 92, 26, 0.28)',
    specialty: 'Long-Range Precision & Mobility',
    attrs: [
      ['🏹', 'Long Range'],
      ['🎯', 'Precision'],
      ['💨', 'Swift Stride']
    ],
    silhouette: `
      <path d="M56 16l10 10-3 10 12 14-6 54H43l-4-54 11-14-3-10z"/>
      <path d="M80 18c15 14 15 54 0 68l-4-3c12-12 12-50 0-62l4-3z"/>
      <path d="M62 50h30v3H62z"/>
    `
  },
  assassin: {
    icon: '🗡',
    faction: 'Shadow',
    rune: 'ᛉ',
    color: '#c084ff',
    glow: 'rgba(192, 132, 255, 0.38)',
    surface: 'rgba(74, 28, 128, 0.3)',
    specialty: 'Critical Ambush & Blade Flurry',
    attrs: [
      ['🗡', 'Lethal Crit'],
      ['⚡', 'Rapid Hits'],
      ['🌑', 'Shadow Step']
    ],
    silhouette: `
      <path d="M60 16l9 12-3 9 14 13-8 54H48l-8-54 14-13-3-9z"/>
      <path d="M35 48l12 14-3 3-13-13zM85 48l-12 14 3 3 13-13z"/>
    `
  },
  paladin: {
    icon: '🛡',
    faction: 'Holy',
    rune: '☀️',
    color: '#ffd666',
    glow: 'rgba(255, 214, 102, 0.42)',
    surface: 'rgba(136, 98, 22, 0.28)',
    specialty: 'Sacred Bastion & Radiant Wrath',
    attrs: [
      ['🛡', 'Bastion'],
      ['☀️', 'Radiant Aura'],
      ['💚', 'Sustain']
    ],
    silhouette: `
      <circle cx="60" cy="24" r="14" fill="none" stroke="currentColor" stroke-width="2.5" opacity="0.55"/>
      <path d="M60 15l8 7-2 10 15 8 4 22-8 42H43l-8-42 4-22 15-8-2-10z"/>
      <path d="M27 42h18v26c0 12-9 19-9 19s-9-7-9-19V42z"/>
    `
  }
};

const TIER_NODE_FALLBACKS = ['Pilgrim', 'Remnant', 'Ascendant', 'Vestige', 'Flamebearer'];
const TIER_ICONS = ['🕯️', '🪨', '⚔️', '❖', '🔥'];

const BIOME_ATLAS_THEMES = [
  { match: /forest|wood|grove|thorn/, icon: '🌲', diff: 'Standard', diffColor: '#6effb0', color: '#59c97b', desc: 'Twisted canopy haunted by beasts and rootbound hollows.' },
  { match: /frozen|frost|ice|glacial|snow|waste/, icon: '❄', diff: 'Harsh', diffColor: '#7ad7ff', color: '#63b8ff', desc: 'Shattered tundra where bitter winds slow the unwary.' },
  { match: /capital|ashen|city|citadel|kingdom/, icon: '🏛', diff: 'Perilous', diffColor: '#ffbe5c', color: '#f0a943', desc: 'Collapsed seat of kings shrouded in embers and ash.' },
  { match: /catacomb|crypt|tomb|barrow|ossuary/, icon: '⚰', diff: 'Deadly', diffColor: '#c98aff', color: '#a876ff', desc: 'Labyrinthine vaults teeming with restless dead.' },
  { match: /void|abyss|rift|astral|star/, icon: '🌀', diff: 'Abyssal', diffColor: '#ff5e8a', color: '#e65cff', desc: 'Fractured reality bleeding cosmic anomalies.' }
];

const ACTIVITY_THEMES = [
  { match: /standard|expedition/, icon: '🧭', badge: 'Core Delve', color: '#e6bc5c', glow: 'rgba(230, 188, 92, 0.25)' },
  { match: /endless|abyss/, icon: '🌀', badge: 'Infinite', color: '#c46bff', glow: 'rgba(196, 107, 255, 0.28)' },
  { match: /arena|challenge/, icon: '⚔', badge: 'Gauntlet', color: '#ff704d', glow: 'rgba(255, 112, 77, 0.28)' },
  { match: /mythic|hunt/, icon: '👑', badge: 'Apex Quarry', color: '#ffae38', glow: 'rgba(255, 174, 56, 0.3)' },
  { match: /relic/, icon: '🏺', badge: 'Treasure', color: '#5effb1', glow: 'rgba(94, 255, 177, 0.26)' },
  { match: /hardcore|oath/, icon: '💀', badge: 'Iron Oath', color: '#ff4757', glow: 'rgba(255, 71, 87, 0.3)' },
  { match: /daily|rite/, icon: '🕯️', badge: 'Daily Omen', color: '#66d9ff', glow: 'rgba(102, 217, 255, 0.26)' }
];

function ensureMenuStyles() {
  if (typeof document === 'undefined' || document.getElementById('reliquary-menu-styles')) return;
  const style = document.createElement('style');
  style.id = 'reliquary-menu-styles';
  style.textContent = `
    #menu-modal .modal-box {
      background:
        radial-gradient(circle at 50% 0%, rgba(212, 168, 82, 0.14), transparent 55%),
        radial-gradient(circle at 50% 100%, rgba(120, 38, 62, 0.12), transparent 55%),
        linear-gradient(180deg, #16121d 0%, #0b0910 100%);
      border: 1.5px solid #967336;
      box-shadow:
        inset 0 0 0 1px rgba(244, 214, 140, 0.16),
        inset 0 0 42px rgba(0, 0, 0, 0.78),
        0 28px 90px rgba(0, 0, 0, 0.92);
    }

    #menu-modal .title {
      letter-spacing: 3px;
      text-shadow: 0 0 24px rgba(236, 188, 92, 0.42), 0 3px 8px #000;
    }

    #menu-modal #vault-bar {
      background: linear-gradient(180deg, rgba(28, 22, 36, 0.85), rgba(14, 11, 19, 0.92));
      border: 1px solid rgba(196, 156, 78, 0.35);
      border-radius: 6px;
      padding: 8px 12px;
      line-height: 1.65;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.05);
    }

    /* ── Title screen: fit everything on one screen (no scrolling) ── */
    #menu-modal .modal-box {
      padding: clamp(10px, 2vh, 20px) clamp(12px, 2vw, 22px);
    }

    #menu-modal h1.title {
      font-size: clamp(22px, 4.4vh, 34px);
      margin: 0 0 2px;
      line-height: 1.1;
    }

    #menu-modal .subtitle {
      margin: 0 0 clamp(6px, 1.2vh, 12px);
      font-size: clamp(11px, 1.6vh, 13px);
    }

    #menu-modal .modal-box > .tabs {
      margin-top: 0;
      margin-bottom: clamp(6px, 1.2vh, 10px);
    }

    #menu-modal #vault-bar {
      padding: 5px 10px;
      font-size: 11.5px;
      line-height: 1.45;
      margin-bottom: clamp(6px, 1.2vh, 10px) !important;
    }

    #mtab-play > .flex-row {
      margin-top: clamp(8px, 1.6vh, 14px) !important;
    }

    #mtab-play > p {
      margin: 6px 0 0 !important;
    }

    #menu-modal #btn-begin-run {
      padding: clamp(9px, 1.6vh, 12px) 40px !important;
      font-size: clamp(14px, 2vh, 16px) !important;
    }

    @media (min-width: 861px) {
      /* 3 x 2 grid of compact, horizontal hero cards */
      #menu-modal #class-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
        gap: 10px !important;
      }

      #menu-modal .hero-tarot-card {
        min-height: 0;
        gap: 7px;
        padding: 9px 11px 8px;
      }

      #menu-modal .hero-tarot-card:hover {
        transform: translateY(-3px);
      }

      #menu-modal .hero-crest-wrap {
        display: grid;
        grid-template-columns: auto minmax(0, 1fr);
        column-gap: 11px;
        align-items: center;
        text-align: left;
        margin-top: 4px;
      }

      #menu-modal .hero-crest {
        grid-row: 1 / span 2;
        width: 48px;
        height: 48px;
        font-size: 24px;
        margin: 0;
      }

      #menu-modal .hero-name {
        align-self: end;
        font-size: 17px;
        line-height: 1.15;
      }

      #menu-modal .hero-specialty {
        align-self: start;
        margin-top: 1px;
        line-height: 1.25;
      }

      #menu-modal .hero-silhouette-bg {
        top: 6px;
        left: auto;
        right: 8px;
        transform: none;
        width: 86px;
        height: 86px;
      }

      #menu-modal .hero-tarot-card:hover .hero-silhouette-bg,
      #menu-modal .hero-tarot-card.selected .hero-silhouette-bg {
        transform: scale(1.05);
      }

      #menu-modal .hero-attr-row {
        margin: 0;
        gap: 4px;
      }

      #menu-modal .hero-attr-chip {
        flex-direction: row;
        justify-content: center;
        gap: 4px;
        padding: 3px 4px;
      }

      #menu-modal .hero-attr-ico {
        font-size: 12px;
      }

      #menu-modal .hero-passive-box {
        padding: 6px 8px;
        font-size: 11px;
        line-height: 1.33;
      }

      #menu-modal .hero-lore-details {
        padding-top: 4px;
      }
    }

    /* Short screens: drop the decorative extras so both rows still fit */
    @media (min-width: 861px) and (max-height: 760px) {
      #menu-modal .hero-attr-row,
      #menu-modal .hero-silhouette-bg {
        display: none;
      }
    }

    /* Hero Class Grid */
    #class-grid {
      gap: 14px !important;
      align-items: stretch;
    }

    @media (max-width: 860px) {
      #class-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      }
    }

    @media (max-width: 560px) {
      #class-grid {
        grid-template-columns: 1fr !important;
      }
    }

    /* Collectible Tarot Hero Cards */
    .hero-tarot-card {
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      gap: 9px;
      min-height: 286px;
      padding: 13px 13px 11px;
      border-radius: 9px;
      cursor: pointer;
      overflow: hidden;
      background:
        radial-gradient(circle at 50% 22%, var(--hero-surface, rgba(201, 160, 80, 0.18)), transparent 62%),
        linear-gradient(180deg, #1d1727 0%, #100c16 68%, #0a080f 100%);
      border: 1.5px solid #6e5732;
      box-shadow:
        0 10px 26px rgba(0, 0, 0, 0.65),
        inset 0 0 24px rgba(0, 0, 0, 0.58);
      transition: transform 0.18s cubic-bezier(0.22, 1, 0.36, 1), border-color 0.18s ease, box-shadow 0.2s ease, filter 0.16s ease;
    }

    .hero-tarot-card::before {
      content: '';
      position: absolute;
      inset: 5px;
      border-radius: 6px;
      border: 1px solid rgba(244, 214, 140, 0.2);
      pointer-events: none;
    }

    .hero-tarot-card:hover {
      transform: translateY(-5px) scale(1.015);
      border-color: var(--hero-color, #d4aa57);
      box-shadow:
        0 14px 32px rgba(0, 0, 0, 0.78),
        0 0 24px var(--hero-glow, rgba(212, 170, 87, 0.32)),
        inset 0 0 22px rgba(255, 255, 255, 0.04);
      filter: brightness(1.06);
    }

    .hero-tarot-card.selected {
      border-color: #f7dc94 !important;
      box-shadow:
        0 16px 36px rgba(0, 0, 0, 0.82),
        0 0 28px var(--hero-glow, rgba(247, 220, 148, 0.45)),
        inset 0 0 0 1px rgba(247, 220, 148, 0.55),
        inset 0 0 26px var(--hero-surface, rgba(212, 170, 87, 0.18));
    }

    .hero-tarot-card.locked {
      filter: saturate(0.76);
    }

    .hero-tarot-card.locked:hover {
      filter: saturate(1) brightness(1.06);
    }

    .hero-silhouette-bg {
      position: absolute;
      top: 12px;
      left: 50%;
      transform: translateX(-50%);
      width: 132px;
      height: 132px;
      color: var(--hero-color, #d4aa57);
      opacity: 0.16;
      pointer-events: none;
      filter: drop-shadow(0 0 14px var(--hero-glow, transparent));
      transition: opacity 0.2s ease, transform 0.22s ease;
    }

    .hero-tarot-card:hover .hero-silhouette-bg,
    .hero-tarot-card.selected .hero-silhouette-bg {
      opacity: 0.28;
      transform: translateX(-50%) scale(1.05);
    }

    .hero-top-corners {
      position: relative;
      z-index: 1;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
    }

    .hero-rune {
      font-size: 12px;
      color: var(--hero-color, #d4aa57);
      text-shadow: 0 0 8px var(--hero-glow, transparent);
    }

    .hero-state-pill {
      font-size: 10px;
      font-weight: 800;
      letter-spacing: 0.65px;
      text-transform: uppercase;
      padding: 2px 8px;
      border-radius: 99px;
      border: 1px solid rgba(255, 255, 255, 0.16);
      background: rgba(0, 0, 0, 0.48);
    }

    .hero-state-pill.active {
      color: #fae09b;
      border-color: #f4d68c;
      background: rgba(186, 140, 52, 0.26);
      box-shadow: 0 0 10px rgba(244, 214, 140, 0.28);
    }

    .hero-state-pill.unlocked {
      color: #6effb8;
      border-color: rgba(94, 255, 177, 0.48);
    }

    .hero-state-pill.locked {
      color: #ffb147;
      border-color: rgba(255, 140, 0, 0.55);
      background: rgba(88, 42, 8, 0.52);
    }

    .hero-crest-wrap {
      position: relative;
      z-index: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      margin-top: 2px;
    }

    .hero-crest {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 28px;
      color: #fff6e0;
      background: radial-gradient(circle at 50% 35%, rgba(255, 255, 255, 0.14), rgba(10, 8, 16, 0.96));
      border: 2px solid var(--hero-color, #d4aa57);
      box-shadow:
        0 0 18px var(--hero-glow, rgba(212, 170, 87, 0.35)),
        inset 0 0 12px rgba(0, 0, 0, 0.85);
      margin-bottom: 7px;
    }

    .hero-name {
      font-size: 18px;
      font-weight: 800;
      letter-spacing: 0.6px;
      color: #faf4e6;
      text-shadow: 0 2px 6px rgba(0, 0, 0, 0.85);
    }

    .hero-specialty {
      font-size: 11px;
      font-weight: 700;
      color: var(--hero-color, #d4aa57);
      letter-spacing: 0.35px;
      margin-top: 2px;
    }

    .hero-attr-row {
      position: relative;
      z-index: 1;
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 5px;
      margin: 4px 0;
    }

    .hero-attr-chip {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 2px;
      padding: 5px 3px;
      border-radius: 5px;
      background: rgba(0, 0, 0, 0.42);
      border: 1px solid rgba(255, 255, 255, 0.08);
      text-align: center;
    }

    .hero-attr-ico {
      font-size: 14px;
      line-height: 1;
    }

    .hero-attr-lbl {
      font-size: 9.5px;
      font-weight: 700;
      color: #cdc5da;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 100%;
    }

    .hero-passive-box {
      position: relative;
      z-index: 1;
      padding: 7px 9px;
      border-radius: 5px;
      background: rgba(14, 11, 20, 0.72);
      border: 1px solid rgba(201, 160, 80, 0.28);
      font-size: 11.5px;
      line-height: 1.38;
      color: #dcd5e8;
    }

    .hero-lore-details {
      position: relative;
      z-index: 1;
      border-top: 1px solid rgba(255, 255, 255, 0.08);
      padding-top: 6px;
      font-size: 11px;
    }

    .hero-lore-details summary {
      cursor: pointer;
      color: #cbb98c;
      font-weight: 700;
      letter-spacing: 0.4px;
      list-style: none;
      display: flex;
      align-items: center;
      justify-content: space-between;
      user-select: none;
    }

    .hero-lore-details summary::-webkit-details-marker {
      display: none;
    }

    .hero-lore-text {
      margin-top: 5px;
      font-style: italic;
      color: #aba2ba;
      line-height: 1.4;
    }

    /* Monumental Entry Action Button */
    #btn-begin-run {
      position: relative;
      font-size: 16.5px !important;
      font-weight: 900 !important;
      letter-spacing: 2px;
      padding: 14px 44px !important;
      color: #fff7df !important;
      background: linear-gradient(180deg, #8b6324 0%, #52360e 52%, #2c1b06 100%) !important;
      border: 2px solid #f2cf7e !important;
      border-radius: 7px;
      box-shadow:
        0 0 26px rgba(232, 180, 74, 0.45),
        0 8px 22px rgba(0, 0, 0, 0.72),
        inset 0 1px 0 rgba(255, 244, 210, 0.42),
        inset 0 0 18px rgba(255, 152, 48, 0.22);
      transition: transform 0.16s cubic-bezier(0.22, 1, 0.36, 1), box-shadow 0.2s ease, filter 0.16s ease;
      animation: entryButtonAura 2.8s ease-in-out infinite;
    }

    #btn-begin-run::before,
    #btn-begin-run::after {
      content: '✦';
      margin: 0 10px;
      color: #ffe39e;
      font-size: 14px;
    }

    #btn-begin-run:hover {
      transform: translateY(-3px) scale(1.035);
      filter: brightness(1.16);
      box-shadow:
        0 0 38px rgba(248, 206, 108, 0.72),
        0 12px 28px rgba(0, 0, 0, 0.82),
        inset 0 1px 0 rgba(255, 250, 232, 0.6),
        inset 0 0 22px rgba(255, 174, 66, 0.36);
    }

    #btn-begin-run:active {
      transform: translateY(1px) scale(0.97);
      filter: brightness(0.95);
      box-shadow:
        0 0 16px rgba(232, 180, 74, 0.4),
        0 3px 10px rgba(0, 0, 0, 0.8),
        inset 0 3px 8px rgba(0, 0, 0, 0.55);
    }

    @keyframes entryButtonAura {
      0%, 100% {
        box-shadow:
          0 0 22px rgba(232, 180, 74, 0.4),
          0 8px 22px rgba(0, 0, 0, 0.72),
          inset 0 1px 0 rgba(255, 244, 210, 0.38);
      }
      50% {
        box-shadow:
          0 0 34px rgba(244, 198, 92, 0.62),
          0 8px 24px rgba(0, 0, 0, 0.76),
          inset 0 1px 0 rgba(255, 244, 210, 0.52);
      }
    }

    /* Reliquary tabs: fixed-size content area so switching tabs never resizes the menu.
       Height fits the tallest tab (Evolutions, Bosses & Realms); shorter tabs leave empty
       space and anything taller scrolls inside the box. Change the 470px to taste. */
    #menu-modal #rel-content {
      height: clamp(280px, 56vh, 470px);
      overflow-y: auto;
      overflow-x: hidden;
      padding-right: 6px;
      scrollbar-width: thin;
      scrollbar-color: #6e5732 transparent;
    }

    #menu-modal #rel-content::-webkit-scrollbar {
      width: 6px;
    }

    #menu-modal #rel-content::-webkit-scrollbar-thumb {
      background: #6e5732;
      border-radius: 3px;
    }

    /* Reliquary Sub-Cards */
    .rel-sanctum-card {
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      gap: 8px;
      background: linear-gradient(180deg, #1b1624 0%, #100d16 100%);
      border: 1.5px solid #5e4c2d;
      box-shadow: inset 0 0 18px rgba(0, 0, 0, 0.55);
    }

    .rel-sanctum-card.selected {
      border-color: #e8c26b;
      box-shadow: 0 0 18px rgba(232, 194, 107, 0.28), inset 0 0 18px rgba(232, 194, 107, 0.12);
    }

    /* ==========================================
       TIERS & REALMS: compact atlas (no scrolling)
       ========================================== */
    #mtab-modes .grid-2 {
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      align-items: start;
    }

    @media (max-width: 860px) {
      #mtab-modes .grid-2 {
        grid-template-columns: 1fr;
      }
    }

    #mtab-modes .card {
      padding: 12px 14px;
      background: linear-gradient(180deg, #1b1622 0%, #100d15 100%);
      border: 1.5px solid #7d6130;
      box-shadow:
        inset 0 0 0 1px rgba(244, 214, 140, 0.1),
        inset 0 0 24px rgba(0, 0, 0, 0.6);
    }

    .atlas-section-hdr {
      display: flex;
      align-items: center;
      gap: 6px;
      border-bottom: 1px solid rgba(201, 160, 80, 0.3);
      padding-bottom: 6px;
      margin: 0 0 10px;
      color: #f4d68c;
      font-size: 13px;
      font-weight: 800;
      letter-spacing: 0.9px;
      text-transform: uppercase;
    }

    .atlas-sub-label {
      display: block;
      margin: 12px 0 6px;
      font-size: 10.5px;
      font-weight: 800;
      letter-spacing: 0.9px;
      text-transform: uppercase;
      color: #b8aa8a;
    }

    /* World tiers: one compact row of five */
    .atlas-tier-spine {
      display: grid !important;
      grid-template-columns: repeat(5, minmax(0, 1fr));
      gap: 6px !important;
      margin-bottom: 8px !important;
    }

    .atlas-tier-node {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 3px;
      padding: 8px 4px 7px;
      border-radius: 7px;
      cursor: pointer;
      background: linear-gradient(180deg, rgba(28, 22, 36, 0.88), rgba(14, 11, 19, 0.95));
      border: 1.5px solid #594729;
      transition: transform 0.14s ease, border-color 0.16s ease, box-shadow 0.18s ease;
    }

    .atlas-tier-node:hover {
      transform: translateY(-2px);
      border-color: #c9a050;
    }

    .atlas-tier-node.reached {
      border-color: rgba(201, 160, 80, 0.55);
    }

    .atlas-tier-node.selected {
      border-color: #f7dc94;
      background:
        radial-gradient(circle at 50% 30%, rgba(244, 214, 140, 0.2), transparent 65%),
        linear-gradient(180deg, #2d2213 0%, #16100a 100%);
      box-shadow: 0 0 16px rgba(244, 214, 140, 0.26), inset 0 0 10px rgba(244, 214, 140, 0.1);
    }

    .atlas-tier-ico {
      font-size: 18px;
      line-height: 1;
    }

    .atlas-tier-num {
      font-size: 12px;
      font-weight: 800;
      letter-spacing: 0.5px;
      color: #ebe4f4;
    }

    .atlas-tier-node.selected .atlas-tier-num {
      color: #fae09b;
    }

    /* Tier stats: four numbers instead of a paragraph */
    .atlas-plaque {
      padding: 9px 10px;
      border-radius: 6px;
      background: rgba(10, 8, 14, 0.78);
      border: 1px solid rgba(201, 160, 80, 0.35);
    }

    .atlas-plaque-title {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      margin-bottom: 8px;
      color: #f4d68c;
      font-size: 13px;
      font-weight: 800;
    }

    .atlas-plaque-tag {
      font-size: 9.5px;
      font-weight: 800;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      padding: 1px 6px;
      border-radius: 4px;
      color: #a59cb5;
      border: 1px solid rgba(255, 255, 255, 0.14);
    }

    .atlas-plaque-tag.on {
      color: #fae09b;
      border-color: rgba(244, 214, 140, 0.45);
    }

    .atlas-stat-row {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 6px;
    }

    .atlas-stat {
      text-align: center;
    }

    .atlas-stat b {
      display: block;
      font-size: 14px;
      color: #f1ebfa;
    }

    .atlas-stat span {
      display: block;
      margin-top: 1px;
      font-size: 9.5px;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      color: #9d94ad;
    }

    /* Realm / expedition / seal chips: icon + name only */
    .atlas-card-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 6px;
      margin-bottom: 6px;
    }

    .atlas-tile {
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 0;
      padding: 7px 9px;
      border-radius: 7px;
      cursor: pointer;
      background:
        radial-gradient(circle at 12% 50%, var(--tile-glow, rgba(201, 160, 80, 0.12)), transparent 60%),
        linear-gradient(180deg, #1d1826 0%, #100d16 100%);
      border: 1.5px solid #57462a;
      transition: transform 0.14s ease, border-color 0.16s ease, box-shadow 0.18s ease;
    }

    .atlas-tile:hover {
      transform: translateY(-1px);
      border-color: var(--tile-color, #d4aa57);
    }

    .atlas-tile.selected {
      border-color: #f7dc94;
      box-shadow:
        0 0 14px var(--tile-glow, rgba(244, 214, 140, 0.3)),
        inset 0 0 12px rgba(244, 214, 140, 0.12);
    }

    .atlas-tile-ico {
      width: 26px;
      height: 26px;
      border-radius: 6px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      font-size: 15px;
      background: rgba(8, 7, 12, 0.85);
      border: 1px solid var(--tile-color, rgba(201, 160, 80, 0.5));
    }

    .atlas-tile-name {
      flex: 1;
      min-width: 0;
      font-size: 12px;
      font-weight: 700;
      color: #f1ebfa;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .atlas-tile.selected .atlas-tile-name {
      color: #fae09b;
    }

    .atlas-tile-dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      flex-shrink: 0;
      background: var(--dot-color, transparent);
      box-shadow: 0 0 6px var(--dot-color, transparent);
    }

    /* One description line per section: shows the selected (or hovered) item.
       Fixed minimum height so the layout never jumps while hovering. */
    .atlas-hint {
      display: flex;
      align-items: center;
      min-height: 46px;
      padding: 6px 10px;
      border-radius: 6px;
      background: rgba(10, 8, 14, 0.6);
      border: 1px solid rgba(201, 160, 80, 0.22);
      font-size: 11px;
      line-height: 1.4;
      color: #cfc7dd;
    }
  `;
  document.head.appendChild(style);
}

function createReliquaryCard({ classes = '', headerLeft = '', headerRight = '', bodyHTML = '', actionLabel = '', actionClass = 'btn-dark', onAction = null }) {
  const card = mk(
    'div',
    `card rel-sanctum-card ${classes}`.trim(),
    `
      <div>
        <div class="flex-row" style="justify-content:space-between;gap:8px;margin-bottom:5px;">
          ${headerLeft}
          ${headerRight}
        </div>
        ${bodyHTML}
      </div>
      ${actionLabel ? `<button class="${actionClass}" style="margin-top:4px;">${actionLabel}</button>` : ''}
    `
  );
  if (actionLabel && onAction) {
    const btn = card.querySelector('button');
    if (btn) btn.onclick = onAction;
  }
  return card;
}

function createHeroClassCard(c, { isSelected, isUnlocked }) {
  const meta = CLASS_HERO_META[c.id] || {
    icon: '⚔',
    faction: 'Warfare',
    rune: '✦',
    color: '#d4aa57',
    glow: 'rgba(212, 170, 87, 0.32)',
    surface: 'rgba(110, 86, 38, 0.25)',
    specialty: c.title || 'Ashen Wanderer',
    attrs: [
      ['⚔', 'Combat'],
      ['🛡', 'Resilience'],
      ['✦', 'Relics']
    ],
    silhouette: '<circle cx="60" cy="48" r="26"/>'
  };

  const stateClass = isSelected ? 'active' : isUnlocked ? 'unlocked' : 'locked';
  const stateLabel = isSelected ? '✦ Selected' : isUnlocked ? '✓ Unlocked' : `🔒 ${c.cost} Shards`;
  const isOpen = expandedLoreIds.has(c.id);

  const card = mk(
    'div',
    `card hero-tarot-card sans ${isSelected ? 'selected' : ''} ${isUnlocked ? '' : 'locked'}`,
    `
      <svg class="hero-silhouette-bg" viewBox="0 0 120 120" fill="currentColor" aria-hidden="true">
        ${meta.silhouette}
      </svg>

      <div>
        <div class="hero-top-corners">
          <span class="hero-rune">${meta.rune} ${meta.faction}</span>
          <span class="hero-state-pill ${stateClass}">${stateLabel}</span>
        </div>

        <div class="hero-crest-wrap">
          <div class="hero-crest">${meta.icon}</div>
          <div class="hero-name">${c.name}</div>
          <div class="hero-specialty">${c.title || meta.specialty}</div>
        </div>
      </div>

      <div class="hero-attr-row">
        ${meta.attrs
          .map(
            ([ico, lbl]) => `
              <div class="hero-attr-chip">
                <span class="hero-attr-ico">${ico}</span>
                <span class="hero-attr-lbl">${lbl}</span>
              </div>`
          )
          .join('')}
      </div>

      <div class="hero-passive-box">
        <b style="color:#f4d68c;">${c.passiveName}:</b> ${c.passiveDesc}
      </div>

      <details class="hero-lore-details" ${isOpen ? 'open' : ''}>
        <summary><span>📜 Kingdom Lore</span><span>▾</span></summary>
        <div class="hero-lore-text">"${c.lore}"</div>
      </details>
    `
  );

  card.style.setProperty('--hero-color', meta.color);
  card.style.setProperty('--hero-glow', meta.glow);
  card.style.setProperty('--hero-surface', meta.surface);

  const details = card.querySelector('.hero-lore-details');
  if (details) {
    details.addEventListener('click', e => e.stopPropagation());
    details.addEventListener('toggle', () => {
      if (details.open) expandedLoreIds.add(c.id);
      else expandedLoreIds.delete(c.id);
    });
  }

  card.onclick = () => {
    if (isUnlocked) {
      state.selectedClassId = c.id;
      renderMainMenu();
    } else if (spendCost({ shards: c.cost })) {
      metaSave.unlockedClasses.push(c.id);
      state.selectedClassId = c.id;
      persistSave();
      renderMainMenu();
    }
  };

  return card;
}

function resolveBiomeMeta(bm, idx) {
  const txt = `${bm.id || ''} ${bm.name || ''}`.toLowerCase();
  const found = BIOME_ATLAS_THEMES.find(t => t.match.test(txt));
  const fallback = BIOME_ATLAS_THEMES[idx % BIOME_ATLAS_THEMES.length];
  const theme = found || fallback;
  return {
    icon: bm.icon || theme.icon,
    desc: bm.desc || bm.description || theme.desc,
    diff: bm.difficulty || bm.diff || theme.diff,
    diffColor: theme.diffColor,
    color: bm.color || theme.color
  };
}

function resolveActivityMeta(m, idx) {
  const txt = `${m.id || ''} ${m.name || ''}`.toLowerCase();
  const found = ACTIVITY_THEMES.find(t => t.match.test(txt));
  return found || ACTIVITY_THEMES[idx % ACTIVITY_THEMES.length];
}

function createAtlasTile({ icon, title, color, glow, dotColor, selected, hintEl, hintHTML, extraHTML = '', onClick }) {
  const tile = mk(
    'div',
    `atlas-tile ${selected ? 'selected' : ''}`,
    `
      <div class="atlas-tile-ico">${icon}</div>
      <div class="atlas-tile-name">${title}</div>
      ${dotColor ? `<span class="atlas-tile-dot" style="--dot-color:${dotColor};"></span>` : ''}
      ${extraHTML}
    `
  );
  tile.title = title;
  tile.style.setProperty('--tile-color', color);
  tile.style.setProperty('--tile-glow', glow || `${color}33`);

  if (hintEl) {
    tile.addEventListener('mouseenter', () => {
      hintEl.innerHTML = hintHTML;
    });
    tile.addEventListener('mouseleave', () => {
      hintEl.innerHTML = hintEl.dataset.rest || '';
    });
    if (selected) {
      hintEl.dataset.rest = hintHTML;
      hintEl.innerHTML = hintHTML;
    }
  }

  if (onClick) tile.onclick = onClick;
  return tile;
}

function ensureAtlasGrid(select, id) {
  let grid = document.getElementById(id);
  if (!grid) {
    grid = mk('div', 'atlas-card-grid');
    grid.id = id;
    select.parentElement.insertBefore(grid, select.nextSibling);
  }
  grid.innerHTML = '';
  return grid;
}

function ensureAtlasHint(grid, id) {
  let hint = document.getElementById(id);
  if (!hint) {
    hint = mk('div', 'atlas-hint');
    hint.id = id;
    grid.insertAdjacentElement('afterend', hint);
  }
  hint.dataset.rest = '';
  hint.innerHTML = '';
  return hint;
}

function styleSubLabel(select, text) {
  const label = select.previousElementSibling;
  if (label && label.tagName === 'LABEL') {
    label.className = 'atlas-sub-label';
    label.innerHTML = text;
  }
  return label && label.tagName === 'LABEL' ? label : null;
}

function renderTierPlaque(t, isActive) {
  const el = DOM['tier-desc'];
  el.className = 'atlas-plaque';
  el.title = `Elites +${Math.round(t.eliteAdd * 100)}% • Champions +${Math.round(t.champAdd * 100)}%`;
  el.innerHTML = `
    <div class="atlas-plaque-title">
      <span>Tier ${t.roman} · ${t.name}</span>
      <span class="atlas-plaque-tag ${isActive ? 'on' : ''}">${isActive ? '✦ Active' : 'Preview'}</span>
    </div>
    <div class="atlas-stat-row">
      <div class="atlas-stat"><b>${t.hp}x</b><span>Enemy HP</span></div>
      <div class="atlas-stat"><b>${t.dmg}x</b><span>Enemy DMG</span></div>
      <div class="atlas-stat"><b>${t.frag}x</b><span>Fragments</span></div>
      <div class="atlas-stat"><b>+${Math.round(t.luck * 100)}%</b><span>Luck</span></div>
    </div>
  `;
}

function renderWorldTierProgression() {
  const tierWrap = DOM['tier-buttons'];
  tierWrap.innerHTML = '';
  tierWrap.classList.add('atlas-tier-spine');

  const tiers = WorldTierConfig.tiers.slice(1);
  const curWt = WorldTierConfig.tiers[state.worldTier];

  tiers.forEach((t, idx) => {
    const isSelected = state.worldTier === t.id;
    const isReached = state.worldTier >= t.id;
    const nodeName = t.name || TIER_NODE_FALLBACKS[idx] || `Tier ${t.roman}`;
    const nodeIcon = TIER_ICONS[idx % TIER_ICONS.length];

    const node = mk(
      'div',
      `atlas-tier-node ${isSelected ? 'selected' : ''} ${isReached ? 'reached' : ''}`,
      `
        <div class="atlas-tier-ico">${nodeIcon}</div>
        <div class="atlas-tier-num">${t.roman}</div>
      `
    );
    node.title = `Tier ${t.roman} • ${nodeName}`;

    // Hover previews that tier's stats; leaving restores the active tier
    node.addEventListener('mouseenter', () => renderTierPlaque(t, isSelected));
    node.addEventListener('mouseleave', () => renderTierPlaque(curWt, true));

    node.onclick = () => {
      state.worldTier = t.id;
      renderMainMenu();
    };
    tierWrap.appendChild(node);
  });

  renderTierPlaque(curWt, true);
}

function renderBiomeAtlas(selectedBiomeIdx) {
  const select = DOM['start-biome-select'];
  if (!select) return;
  select.style.display = 'none';
  styleSubLabel(select, '✦ Starting Realm');

  const grid = ensureAtlasGrid(select, 'atlas-biome-grid');
  const hint = ensureAtlasHint(grid, 'atlas-biome-hint');

  BIOMES.forEach((bm, idx) => {
    const meta = resolveBiomeMeta(bm, idx);
    grid.appendChild(
      createAtlasTile({
        icon: meta.icon,
        title: bm.name,
        color: meta.color,
        dotColor: meta.diffColor,
        selected: selectedBiomeIdx === idx,
        hintEl: hint,
        hintHTML: `<span><b style="color:${meta.diffColor};">⚠ ${meta.diff}</b> · ${meta.desc}</span>`,
        onClick: () => {
          select.value = String(idx);
          renderModesAndTiers();
        }
      })
    );
  });
}

function renderDungeonAtlas(curDng) {
  const select = DOM['dungeon-select'];
  if (!select) return;
  select.style.display = 'none';
  const label = styleSubLabel(select, '✦ Dungeon Seal');

  const grid = ensureAtlasGrid(select, 'atlas-dungeon-grid');
  const hint = ensureAtlasHint(grid, 'atlas-dungeon-hint');

  const unlockedDungeons = DUNGEONS.filter(d => !d.req || hasUnlock(d.req));

  // With only the default "Open Atlas" available there is nothing to choose, so hide the section
  const hidden = unlockedDungeons.length <= 1;
  if (label) label.style.display = hidden ? 'none' : '';
  grid.style.display = hidden ? 'none' : '';
  hint.style.display = hidden ? 'none' : '';

  unlockedDungeons.forEach(d => {
    const isNone = d.id === 'none';
    const desc = d.desc || (isNone ? 'Explore the open realm without a sealed dungeon modifier.' : `Sealed dungeon delve (${d.hpM || 1}x Enemy Vitality).`);
    grid.appendChild(
      createAtlasTile({
        icon: isNone ? '🗺️' : '⛩',
        title: d.name,
        color: isNone ? '#c9a050' : '#ff7b47',
        selected: curDng === d.id,
        hintEl: hint,
        hintHTML: `<span>${desc}</span>`,
        onClick: () => {
          select.value = d.id;
          renderModesAndTiers();
        }
      })
    );
  });
}

function renderActivityAtlas() {
  const list = DOM['modes-list'];
  if (!list) return;

  const currentChecked = list.querySelector('input[name="gmode"]:checked')?.value;
  const activeModeId = currentChecked || state.gameMode || MODES_CONFIG[0]?.id;

  list.className = 'atlas-card-grid';
  list.style.gridTemplateColumns = '';
  list.innerHTML = '';

  const hint = ensureAtlasHint(list, 'atlas-mode-hint');

  MODES_CONFIG.forEach((m, idx) => {
    const meta = resolveActivityMeta(m, idx);
    const isSelected = activeModeId === m.id;
    const radioHtml = `<input type="radio" name="gmode" value="${m.id}" ${isSelected ? 'checked' : ''} style="display:none;">`;

    list.appendChild(
      createAtlasTile({
        icon: meta.icon,
        title: m.name,
        color: meta.color,
        glow: meta.glow,
        selected: isSelected,
        extraHTML: radioHtml,
        hintEl: hint,
        hintHTML: `<span><b style="color:${meta.color};">${meta.badge}</b> · ${m.desc}</span>`,
        onClick: () => {
          state.gameMode = m.id;
          const radio = list.querySelector(`input[name="gmode"][value="${m.id}"]`);
          if (radio) radio.checked = true;
          renderModesAndTiers();
        }
      })
    );
  });
}

function renderAtlasHeaders() {
  const modesTab = $('mtab-modes');
  if (!modesTab) return;

  // The old "Active Chart" summary bar repeated what the highlighted chips already show
  document.getElementById('atlas-summary-bar')?.remove();

  const cards = modesTab.querySelectorAll('.grid-2 > .card');
  const titles = ['🧭 World Tier', '📜 Expedition'];
  cards.forEach((card, i) => {
    const h3 = card.querySelector('h3');
    if (h3 && titles[i]) {
      h3.className = 'atlas-section-hdr';
      h3.innerHTML = `<span>${titles[i]}</span>`;
    }
  });
}

export function renderReliquary() {
  ensureMenuStyles();
  const el = DOM['rel-content'];
  const tab = state.relTab;
  el.innerHTML = '';
  const grid = mk('div', 'grid-3');

  if (tab === 'upgrades') {
    META_UPGRADES_DEF.forEach(m => {
      const rank = metaSave.metaRanks[m.id] || 0;
      const cost = { [m.cur]: m.baseCost * (rank + 1) };
      grid.appendChild(
        createReliquaryCard({
          headerLeft: `<b style="color:var(--gold2);">${m.name}</b>`,
          headerRight: `<span style="font-size:11px;color:#5effb1;">${rank}/${m.max}</span>`,
          bodyHTML: `<div style="font-size:12px;color:#d0c8e0;margin:6px 0;">${m.desc}</div>`,
          actionLabel: rank >= m.max ? 'MAXED' : `Upgrade (${fmtCost(cost)})`,
          onAction: () => {
            if (purchaseMetaUpgrade(m)) renderMainMenu();
          }
        })
      );
    });
  } else if (tab === 'relics') {
    RELICS.forEach(r => {
      const un = hasUnlock(`rel_${r.id}`);
      const eq = metaSave.equippedRelics.includes(r.id);
      grid.appendChild(
        createReliquaryCard({
          classes: `${eq ? 'selected' : ''} ${un ? '' : 'locked'}`,
          headerLeft: `<b style="color:var(--gold2);">${r.name}</b>`,
          headerRight: `<span style="font-size:11px;color:${eq ? '#5effb1' : un ? 'var(--ash)' : '#ff8c00'}">${eq ? 'EQUIPPED' : un ? 'Unlocked' : fmtCost(r.cost)}</span>`,
          bodyHTML:
            `<div style="font-size:12px;color:#5effb1;margin-top:4px;">+ ${r.pro}</div>` +
            `<div style="font-size:12px;color:#ff4757;margin:3px 0 6px;">- ${r.con}</div>`,
          actionLabel: !un
            ? `Unlock (${fmtCost(r.cost)})`
            : eq
              ? 'Unequip Relic'
              : metaSave.equippedRelics.length >= 3
                ? '3/3 Equipped'
                : 'Equip Relic',
          actionClass: eq ? 'btn-gold' : 'btn-dark',
          onAction: () => {
            if (toggleRelic(r)) renderMainMenu();
          }
        })
      );
    });
  } else if (tab === 'masteries') {
    MASTERIES.forEach(m => {
      const st = metaSave.masteries[m.id] || { xp: 0, lvl: 0 };
      const need = 120 * (st.lvl + 1);
      grid.appendChild(
        createReliquaryCard({
          headerLeft: `<b style="color:var(--gold2);">${m.name}</b>`,
          headerRight: `<span style="font-size:12px;color:#5effb1;">Rank ${st.lvl}/5</span>`,
          bodyHTML:
            `<div style="font-size:11px;color:var(--ash);margin-bottom:6px;">${m.sub} • XP: ${st.lvl >= 5 ? 'MAX' : `${Math.floor(st.xp)}/${need}`}</div>` +
            `<div style="font-size:12px;color:#e0d9ee;">• ${m.bonusTxt}<br>• ${m.passiveTxt}<br>• ${m.evoTxt}</div>`,
          actionLabel: st.lvl >= 5 ? 'MASTERED' : 'Train (+60 XP for 4 Ash)',
          onAction: () => {
            if (st.lvl < 5 && spendCost({ ash: 4 })) {
              addMasteryXp(m.id, 60);
              renderMainMenu();
            }
          }
        })
      );
    });
  } else {
    RELIQUARY_UNLOCKS.forEach(u => {
      const un = hasUnlock(u.id);
      grid.appendChild(
        createReliquaryCard({
          classes: un ? 'selected' : '',
          headerLeft: `<span style="font-size:10px;color:var(--gold);text-transform:uppercase;">${u.cat}</span>`,
          headerRight: `<span style="font-size:11px;color:${un ? '#5effb1' : '#ff8c00'}">${un ? 'UNLOCKED' : fmtCost(u.cost)}</span>`,
          bodyHTML:
            `<b style="color:var(--gold2);display:block;margin:2px 0 4px;">${u.name}</b>` +
            `<div style="font-size:12px;color:#d0c8e0;">${u.desc}</div>`,
          actionLabel: un ? '' : `Unlock (${fmtCost(u.cost)})`,
          onAction: un
            ? null
            : () => {
                if (purchaseReliquaryUnlock(u)) renderMainMenu();
              }
        })
      );
    });
  }

  el.appendChild(grid);
}

function renderVaultBar() {
  const f = metaSave.fragments;
  DOM['vault-bar'].innerHTML =
    `🪙 Gold: <b style="color:var(--gold2)">${metaSave.gold}</b> &nbsp;•&nbsp; 💎 Shards: <b style="color:#8ec5ff">${metaSave.shards}</b> &nbsp;•&nbsp; 🕯️ Essence: <b style="color:#ff8c00">${metaSave.essence}</b> &nbsp;•&nbsp; 💀 Bosses: <b style="color:#f5b7b1">${metaSave.bossKills}</b> &nbsp;•&nbsp; ⏳ Best: <b style="color:#fff">${fmtTime(metaSave.bestTime)}</b><br>` +
    `🔥 Flame: <b style="color:#ff8c38">${f.flame}</b> &nbsp;•&nbsp; 🌌 Void: <b style="color:#c56cf0">${f.void}</b> &nbsp;•&nbsp; ✦ Star: <b style="color:#8ec5ff">${f.star}</b> &nbsp;•&nbsp; ⚱️ Ash: <b style="color:#cbc4d8">${f.ash}</b> &nbsp;•&nbsp; ❖ Relics: <b style="color:#5effb1">${metaSave.equippedRelics.length}/3</b>`;
}

function renderClassSelection() {
  const grid = DOM['class-grid'];
  grid.innerHTML = '';
  CLASSES.forEach(c => {
    const isUnlocked = metaSave.unlockedClasses.includes(c.id);
    const isSelected = state.selectedClassId === c.id;
    grid.appendChild(createHeroClassCard(c, { isSelected, isUnlocked }));
  });
}

function renderModesAndTiers() {
  if (!DOM['start-biome-select'].options.length) {
    BIOMES.forEach((bm, i) => DOM['start-biome-select'].add(new Option(bm.name, i)));
  }
  const selectedBiomeIdx = Math.max(0, Number(DOM['start-biome-select'].value || 0));

  const curDng = DOM['dungeon-select'].value || 'none';
  DOM['dungeon-select'].innerHTML = '';
  DUNGEONS.forEach(d => {
    if (!d.req || hasUnlock(d.req)) DOM['dungeon-select'].add(new Option(d.name, d.id));
  });
  const validDng = DUNGEONS.some(d => d.id === curDng && (!d.req || hasUnlock(d.req))) ? curDng : 'none';
  DOM['dungeon-select'].value = validDng;

  renderWorldTierProgression();
  renderDungeonAtlas(validDng);
  renderBiomeAtlas(selectedBiomeIdx);
  renderActivityAtlas();
  renderAtlasHeaders();
}

export function renderMainMenu() {
  ensureMenuStyles();
  renderVaultBar();
  renderClassSelection();
  renderReliquary();
  renderModesAndTiers();
  renderCodex('main-codex-content');
}

export function initReliquaryUI() {
  ensureMenuStyles();

  document.querySelectorAll('[data-menutab]').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('[data-menutab]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      ['play', 'reliquary', 'modes', 'codex-main', 'settings-main'].forEach(t => {
        $(`mtab-${t}`).style.display = t === btn.dataset.menutab ? 'block' : 'none';
      });
    };
  });

  document.querySelectorAll('[data-reltab]').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('[data-reltab]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.relTab = btn.dataset.reltab;
      renderReliquary();
    };
  });

  [
    ['opt-sound', 'sound'],
    ['opt-shake', 'shake'],
    ['opt-dmgnum', 'dmgNum'],
    ['opt-autosalvage', 'autoSalvage']
  ].forEach(([id, key]) => {
    const el = $(id);
    el.checked = metaSave.settings[key];
    el.onchange = () => {
      metaSave.settings[key] = el.checked;
      persistSave();
    };
  });

  $('btn-wipe-save').onclick = () => {
    if (confirm('Erase all persistent currencies, masteries, relics, and Codex lore?')) {
      resetSave();
      renderMainMenu();
    }
  };
}