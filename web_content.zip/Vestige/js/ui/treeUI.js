import { $ } from '../core/utilities.js';
import { state } from '../core/game.js';

import { PASSIVE_TREE, canAllocate, allocateTreeNode } from '../systems/skilltree.js';
import { DOM } from './hud.js';

let tCanvas = null;
let tCtx = null;
let hoverId = null;

const DEFAULT_INFO = 'Click any highlighted node to allocate. Gold nodes are <b>Keystones</b>.';
const INFO_BOX_HEIGHT = 64; // px, tall enough for name + pill + 2 lines of description

export function treeHit(e) {
  if (!tCanvas) return null;
  const r = tCanvas.getBoundingClientRect();
  const mx = (e.clientX - r.left) * (tCanvas.width / r.width);
  const my = (e.clientY - r.top) * (tCanvas.height / r.height);
  return PASSIVE_TREE.find(n => (n.x - mx) ** 2 + (n.y - my) ** 2 < 196);
}

function nodeRadius(n) {
  return n.keystone ? 12 : n.id === 0 ? 11 : 7;
}

function showNodeInfo(h) {
  const p = state.player;
  const owned = p.allocatedNodes.has(h.id);
  const avail = !owned && canAllocate(h.id);
  const [label, cls] = owned ? ['Allocated', 'owned'] : avail ? ['Available', 'avail'] : ['Locked', 'locked'];

  DOM['tree-node-info'].innerHTML =
    `<b style="color:${h.keystone ? '#ffd700' : '#fff'};font-size:14px;">${h.name}</b>` +
    (h.keystone ? '<span class="rel-tree-pill key">Keystone</span>' : '') +
    `<span class="rel-tree-pill ${cls}">${label}</span>` +
    `<span class="rel-tree-desc">${h.desc}</span>`;
}

export function renderTree() {
  if (!tCanvas || !tCtx) return;
  const p = state.player;
  DOM['tree-pts'].textContent = p.treePoints;
  tCtx.clearRect(0, 0, tCanvas.width, tCanvas.height);

  // Links
  for (const n of PASSIVE_TREE) {
    for (const lid of n.links) {
      if (lid < n.id) continue;
      const o = PASSIVE_TREE[lid];
      const a = p.allocatedNodes.has(n.id);
      const b = p.allocatedNodes.has(lid);

      tCtx.save();
      if (a && b) {
        tCtx.strokeStyle = '#f4d68c';
        tCtx.lineWidth = 2.8;
        tCtx.shadowColor = 'rgba(244, 214, 140, 0.7)';
        tCtx.shadowBlur = 9;
      } else if (a || b) {
        tCtx.strokeStyle = '#7a6238';
        tCtx.lineWidth = 1.6;
      } else {
        tCtx.strokeStyle = '#32293d';
        tCtx.lineWidth = 1.2;
      }
      tCtx.beginPath();
      tCtx.moveTo(n.x, n.y);
      tCtx.lineTo(o.x, o.y);
      tCtx.stroke();
      tCtx.restore();
    }
  }

  // Nodes
  for (const n of PASSIVE_TREE) {
    const owned = p.allocatedNodes.has(n.id);
    const avail = !owned && canAllocate(n.id);
    const r = nodeRadius(n);

    tCtx.save();

    if (owned) {
      tCtx.shadowColor = n.color || '#f0cf85';
      tCtx.shadowBlur = 14;
    } else if (avail) {
      tCtx.shadowColor = 'rgba(201, 160, 80, 0.85)';
      tCtx.shadowBlur = 10;
    }

    tCtx.beginPath();
    tCtx.arc(n.x, n.y, r, 0, Math.PI * 2);
    tCtx.fillStyle = owned ? n.color || '#f0cf85' : avail ? '#3e354d' : '#181420';
    tCtx.fill();
    tCtx.lineWidth = n.keystone ? 2.5 : 1.5;
    tCtx.strokeStyle = owned ? '#fff' : avail ? '#c9a050' : '#4a3f59';
    tCtx.stroke();

    tCtx.shadowBlur = 0;

    // Keystone outer ring
    if (n.keystone) {
      tCtx.beginPath();
      tCtx.arc(n.x, n.y, r + 4, 0, Math.PI * 2);
      tCtx.lineWidth = 1.2;
      tCtx.strokeStyle = owned ? 'rgba(255, 217, 102, 0.8)' : avail ? 'rgba(244, 214, 140, 0.45)' : 'rgba(110, 96, 128, 0.35)';
      tCtx.stroke();
    }

    // Hover ring
    if (n.id === hoverId) {
      tCtx.beginPath();
      tCtx.arc(n.x, n.y, r + (n.keystone ? 8 : 5), 0, Math.PI * 2);
      tCtx.lineWidth = 1.5;
      tCtx.strokeStyle = '#fff3c4';
      tCtx.stroke();
    }

    tCtx.restore();
  }
}

export function initTreeUI() {
  tCanvas = $('tree-canvas');
  tCtx = tCanvas.getContext('2d');

  // Fixed-size info box so the layout never shifts when its text changes
  const info = DOM['tree-node-info'];
  info.style.boxSizing = 'border-box';
  info.style.height = INFO_BOX_HEIGHT + 'px';
  info.style.overflow = 'hidden';
  info.style.flexShrink = '0';

  tCanvas.addEventListener('mousemove', e => {
    const h = state.mode === 'tree' && treeHit(e);
    const id = h ? h.id : null;

    tCanvas.classList.toggle('hovering', Boolean(h) && !state.player.allocatedNodes.has(h.id) && canAllocate(h.id));

    if (id !== hoverId) {
      hoverId = id;
      renderTree();
    }
    if (h) showNodeInfo(h);
  });

  tCanvas.addEventListener('mouseleave', () => {
    tCanvas.classList.remove('hovering');
    if (hoverId !== null) {
      hoverId = null;
      renderTree();
    }
    DOM['tree-node-info'].innerHTML = DEFAULT_INFO;
  });

  tCanvas.addEventListener('click', e => {
    const h = state.mode === 'tree' && treeHit(e);
    if (h && allocateTreeNode(h.id)) {
      renderTree();
      showNodeInfo(h);
    }
  });
}