import { $, mk } from '../core/utilities.js';
import { state } from '../core/game.js';

import { RARITIES, SLOTS, SLOT_LABELS } from '../data/items.js';
import {
  rerollItemAffixes,
  reforgeItemValues,
  enchantItemAffix,
  upgradeItemRarity,
  socketItemGem
} from '../systems/crafting.js';
import { salvageItem, getItemIcon, scoreItem, isItemLocked } from '../systems/inventory.js';
import { DOM, updateHud } from './hud.js';

let craftTarget = null;
let lastRenderedTarget = null;
let pendingForgeFx = null;

const FORGE_RARITY_FRAMES = {
  common: { cls: 'forge-rar-common', rune: '•', color: '#8e889b' },
  magic: { cls: 'forge-rar-magic', rune: '✧', color: '#4da6ff' },
  rare: { cls: 'forge-rar-rare', rune: '◆', color: '#f0b938' },
  legendary: { cls: 'forge-rar-legendary', rune: '✦', color: '#ff8524' },
  mythic: { cls: 'forge-rar-mythic', rune: '❖', color: '#e45cff' }
};

const FORGE_ACTIONS = [
  {
    id: 'cf-reforge',
    icon: '⚒',
    title: 'Reforge',
    sub: 'Rebalance Values',
    cost: '60 Gold',
    sparkColor: '#ffb347',
    fxLabel: 'REFORGED',
    run: item => reforgeItemValues(item)
  },
  {
    id: 'cf-enchant',
    icon: '🪄',
    title: 'Enchant',
    sub: '+1 Affix Mod',
    cost: '3 Shards',
    sparkColor: '#6bb8ff',
    fxLabel: 'ENCHANTED',
    run: item => enchantItemAffix(item)
  },
  {
    id: 'cf-socket',
    icon: '💎',
    title: 'Socket',
    sub: 'Inlay Random Gem',
    cost: '50 Gold',
    sparkColor: '#66ffd1',
    fxLabel: 'SOCKETED',
    run: item => socketItemGem(item)
  },
  {
    id: 'cf-upgrade',
    icon: '🔥',
    title: 'Upgrade',
    sub: 'Ascend Rarity',
    cost: '2 Essence',
    sparkColor: '#ff7038',
    fxLabel: 'ASCENDED',
    run: item => upgradeItemRarity(item)
  },
  {
    id: 'cf-reroll',
    icon: '🎲',
    title: 'Reroll',
    sub: 'New Affix Pool',
    cost: '40 Gold',
    sparkColor: '#f4d68c',
    fxLabel: 'REROLLED',
    run: item => rerollItemAffixes(item)
  },
  {
    id: 'cf-salvage',
    icon: '♻',
    title: 'Salvage',
    sub: 'Extract Essence',
    cost: 'Pack Item Only',
    danger: true,
    sparkColor: '#ff5c6c',
    fxLabel: 'SALVAGED',
    canUse: (item, p) => Boolean(item && p && p.bag.includes(item) && !isItemLocked(item)),
    run: (item, p) => {
      const bi = p.bag.indexOf(item);
      if (bi < 0 || isItemLocked(item)) return false;
      const ok = salvageItem(item, bi);
      if (ok !== false) craftTarget = null;
      return ok !== false;
    }
  }
];

function ensureForgeStyles() {
  if (typeof document === 'undefined' || document.getElementById('forge-reliquary-styles')) return;
  const style = document.createElement('style');
  style.id = 'forge-reliquary-styles';
  style.textContent = `
    #craft-modal .modal-box {
      background:
        radial-gradient(circle at 55% 0%, rgba(255, 118, 40, 0.14), transparent 52%),
        radial-gradient(circle at 50% 100%, rgba(190, 62, 22, 0.14), transparent 54%),
        linear-gradient(180deg, #1a1216 0%, #0d0a0f 100%);
      border: 1.5px solid #9c6f34;
      box-shadow:
        inset 0 0 0 1px rgba(244, 198, 120, 0.14),
        inset 0 0 40px rgba(0, 0, 0, 0.8),
        0 28px 90px rgba(0, 0, 0, 0.92);
    }

    #craft-modal .modal-header {
      border-bottom: 1px solid rgba(224, 152, 72, 0.34);
      padding-bottom: 10px;
      margin-bottom: 12px;
    }

    #craft-modal .modal-header h2 {
      color: #f8d48c;
      letter-spacing: 1.4px;
      text-shadow: 0 0 16px rgba(255, 128, 48, 0.42);
    }

    #craft-item-list.forge-list-scroll {
      display: flex;
      flex-direction: column;
      gap: 7px;
      max-height: 390px !important;
      padding-right: 4px;
    }

    #craft-item-list.forge-list-scroll::-webkit-scrollbar {
      width: 6px;
    }
    #craft-item-list.forge-list-scroll::-webkit-scrollbar-thumb {
      background: linear-gradient(180deg, #8c5c28, #4d3014);
      border-radius: 4px;
    }

    .forge-list-card {
      position: relative;
      display: flex;
      align-items: center;
      gap: 9px;
      padding: 8px 10px;
      border-radius: 6px;
      cursor: pointer;
      background: linear-gradient(165deg, #211922 0%, #110d14 100%);
      border: 1.5px solid #564638;
      transition: transform 0.13s ease, border-color 0.16s ease, box-shadow 0.18s ease, filter 0.15s ease;
    }

    .forge-list-card:hover {
      transform: translateX(3px);
      filter: brightness(1.1);
    }

    .forge-list-card.selected {
      outline: 2px solid #f7dc94;
      outline-offset: 1px;
      box-shadow: 0 0 18px rgba(255, 146, 56, 0.34);
    }

    .forge-mini-icon {
      width: 34px;
      height: 34px;
      border-radius: 5px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 19px;
      flex-shrink: 0;
      background: rgba(8, 6, 11, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    /* Central Sacred Anvil Pedestal */
    #craft-selected-box.forge-anvil-box {
      position: relative;
      overflow: hidden;
      min-height: 205px;
      padding: 15px 14px;
      border-radius: 9px;
      background:
        radial-gradient(circle at 50% 24%, rgba(255, 130, 48, 0.16), transparent 62%),
        linear-gradient(180deg, #21171b 0%, #100c12 100%);
      border: 1.5px solid #8a6432;
      box-shadow:
        inset 0 0 0 1px rgba(244, 214, 140, 0.14),
        inset 0 0 28px rgba(0, 0, 0, 0.72),
        0 10px 26px rgba(0, 0, 0, 0.65);
    }

    #craft-selected-box.forge-select-anim {
      animation: forgeSelectIn 0.24s cubic-bezier(0.22, 1, 0.36, 1);
    }

    #craft-selected-box.forge-strike-anim {
      animation: forgeHammerStrike 0.38s cubic-bezier(0.22, 1, 0.36, 1);
    }

    @keyframes forgeSelectIn {
      0% { transform: scale(0.96); opacity: 0.65; }
      100% { transform: scale(1); opacity: 1; }
    }

    @keyframes forgeHammerStrike {
      0% { transform: scale(1); filter: brightness(1); }
      25% { transform: scale(0.97); filter: brightness(1.45); }
      60% { transform: scale(1.02); filter: brightness(1.18); }
      100% { transform: scale(1); filter: brightness(1); }
    }

    /* Rarity Frames for Forge Anvil & List */
    .forge-rar-common { border-color: #6f6a7a !important; }
    .forge-rar-magic {
      border-color: #3f8ef7 !important;
      box-shadow: 0 0 14px rgba(63, 142, 247, 0.24), inset 0 0 18px rgba(63, 142, 247, 0.12) !important;
    }
    .forge-rar-rare {
      border-color: #e4b136 !important;
      box-shadow: 0 0 16px rgba(228, 177, 54, 0.28), inset 0 0 18px rgba(228, 177, 54, 0.14) !important;
    }
    .forge-rar-legendary {
      border-color: #ff7e21 !important;
      box-shadow: 0 0 22px rgba(255, 126, 33, 0.38), inset 0 0 22px rgba(255, 112, 24, 0.18) !important;
    }
    .forge-rar-mythic {
      border-color: #e24bff !important;
      box-shadow: 0 0 24px rgba(226, 75, 255, 0.42), inset 0 0 26px rgba(196, 52, 235, 0.22) !important;
    }

    .forge-anvil-hero {
      position: relative;
      z-index: 2;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding-bottom: 10px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .forge-big-icon {
      position: relative;
      width: 62px;
      height: 62px;
      border-radius: 9px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 34px;
      flex-shrink: 0;
      background: radial-gradient(circle at 50% 35%, rgba(255, 198, 120, 0.14), rgba(8, 6, 12, 0.96));
      border: 2px solid #d4aa57;
      box-shadow: inset 0 0 14px rgba(0, 0, 0, 0.85);
    }

    .forge-score-badge {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      flex-shrink: 0;
      padding: 5px 10px;
      border-radius: 6px;
      background: rgba(0, 0, 0, 0.45);
      border: 1px solid rgba(244, 214, 140, 0.35);
    }

    .forge-affix-grid {
      position: relative;
      z-index: 2;
      display: flex;
      flex-direction: column;
      gap: 4px;
      margin-top: 10px;
      font-size: 12px;
      color: #e4dcee;
    }

    .forge-affix-line {
      padding: 4px 8px;
      border-radius: 4px;
      background: rgba(255, 255, 255, 0.04);
      border-left: 2px solid rgba(236, 188, 92, 0.55);
    }

    /* Ritual Action Nodes Grid */
    .forge-ritual-grid {
      display: grid !important;
      grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
      gap: 9px !important;
      margin-top: 12px !important;
    }

    @media (max-width: 680px) {
      .forge-ritual-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      }
    }

    .forge-action-node {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      gap: 3px;
      padding: 11px 8px 9px;
      border-radius: 8px;
      cursor: pointer;
      background:
        radial-gradient(circle at 50% 18%, var(--node-glow, rgba(255, 160, 64, 0.16)), transparent 65%),
        linear-gradient(180deg, #261c1d 0%, #130e12 100%);
      border: 1.5px solid #755830;
      color: #f6efe0;
      box-shadow:
        inset 0 1px 0 rgba(255, 240, 200, 0.1),
        0 6px 14px rgba(0, 0, 0, 0.55);
      transition: transform 0.14s ease, border-color 0.16s ease, box-shadow 0.18s ease, filter 0.15s ease;
    }

    .forge-action-node:hover:not(:disabled) {
      transform: translateY(-3px) scale(1.02);
      border-color: var(--node-color, #f4d68c);
      box-shadow:
        0 10px 22px rgba(0, 0, 0, 0.72),
        0 0 20px var(--node-glow, rgba(255, 168, 72, 0.38)),
        inset 0 1px 0 rgba(255, 255, 255, 0.18);
      filter: brightness(1.12);
    }

    .forge-action-node:active:not(:disabled) {
      transform: translateY(1px) scale(0.96);
    }

    .forge-action-node:disabled {
      opacity: 0.42;
      cursor: not-allowed;
      filter: grayscale(0.5);
    }

    .forge-action-node.danger {
      border-color: #78333b;
      background:
        radial-gradient(circle at 50% 18%, rgba(255, 82, 98, 0.18), transparent 65%),
        linear-gradient(180deg, #2a1519 0%, #140b0e 100%);
    }

    .forge-node-ico {
      font-size: 24px;
      line-height: 1;
      margin-bottom: 2px;
      filter: drop-shadow(0 0 8px var(--node-glow, rgba(255, 180, 90, 0.45)));
    }

    .forge-node-title {
      font-size: 13px;
      font-weight: 800;
      letter-spacing: 0.4px;
      color: #fbf3e2;
    }

    .forge-node-sub {
      font-size: 10px;
      color: #b7abbe;
    }

    .forge-node-cost {
      margin-top: 3px;
      font-size: 10px;
      font-weight: 800;
      padding: 1px 7px;
      border-radius: 99px;
      background: rgba(0, 0, 0, 0.45);
      border: 1px solid rgba(255, 255, 255, 0.12);
      color: var(--node-color, #f4d68c);
    }

    /* Spark Particle System */
    .forge-spark-layer {
      position: absolute;
      inset: 0;
      pointer-events: none;
      overflow: hidden;
      z-index: 4;
    }

    .forge-spark {
      position: absolute;
      width: 5px;
      height: 5px;
      border-radius: 50%;
      pointer-events: none;
      animation: forgeSparkFly 0.72s cubic-bezier(0.16, 0.84, 0.44, 1) forwards;
    }

    @keyframes forgeSparkFly {
      0% {
        transform: translate(0, 0) scale(1.2);
        opacity: 1;
      }
      100% {
        transform: translate(var(--sx, 0px), var(--sy, -55px)) scale(0.15);
        opacity: 0;
      }
    }

    .forge-fx-banner {
      position: absolute;
      top: 10px;
      right: 12px;
      z-index: 5;
      font-size: 10.5px;
      font-weight: 900;
      letter-spacing: 1.2px;
      padding: 2px 8px;
      border-radius: 4px;
      background: rgba(0, 0, 0, 0.72);
      border: 1px solid currentColor;
      animation: forgeBannerFade 0.9s ease forwards;
      pointer-events: none;
    }

    @keyframes forgeBannerFade {
      0% { transform: translateY(4px) scale(0.9); opacity: 0; }
      20% { transform: translateY(0) scale(1.05); opacity: 1; }
      80% { opacity: 1; }
      100% { transform: translateY(-6px); opacity: 0; }
    }
  `;
  document.head.appendChild(style);
}

function getRarityFrame(rarityKey) {
  const rar = RARITIES[rarityKey] || RARITIES.common;
  const frame = FORGE_RARITY_FRAMES[rarityKey] || FORGE_RARITY_FRAMES.common;
  return {
    name: rar.name || 'Common',
    color: rar.color || frame.color,
    cls: frame.cls,
    rune: frame.rune
  };
}

function getItemScoreSafe(item, player) {
  if (!item) return 0;
  return typeof scoreItem === 'function' ? scoreItem(item, player) : (item.score || 0);
}

function createForgeListCard(it, { isEquipped, isSelected, player, onClick }) {
  const frame = getRarityFrame(it.rarity);
  const icon = getItemIcon(it);
  const score = getItemScoreSafe(it, player);
  const locked = isItemLocked(it);
  const slotLbl = it.subType || SLOT_LABELS[it.slot] || it.slot;

  const card = mk(
    'div',
    `forge-list-card sans ${frame.cls} ${isSelected ? 'selected' : ''}`,
    `
      <div class="forge-mini-icon" style="border-color:${frame.color};text-shadow:0 0 8px ${frame.color};">${icon}</div>
      <div style="min-width:0;flex:1;">
        <div style="font-weight:700;font-size:12px;line-height:1.22;color:#f5efe4;word-break:break-word;">
          ${locked ? '🔒 ' : ''}${it.name}
        </div>
        <div style="font-size:10px;color:#a99fb8;margin-top:2px;">
          ${isEquipped ? '✦ Equipped' : 'Pack'} • ${slotLbl}
        </div>
      </div>
      <div style="font-size:13px;font-weight:900;color:#fae09b;flex-shrink:0;">★ ${score}</div>
    `
  );
  card.onclick = onClick;
  return card;
}

function spawnForgeSparks(container, color = '#ffb347', label = 'FORGED') {
  const layer = mk('div', 'forge-spark-layer');
  for (let i = 0; i < 18; i++) {
    const spark = document.createElement('span');
    spark.className = 'forge-spark';
    const angle = (Math.PI * 2 * i) / 18 + (Math.random() - 0.5) * 0.4;
    const dist = 36 + Math.random() * 68;
    spark.style.left = `${44 + (Math.random() - 0.5) * 18}px`;
    spark.style.top = `${44 + (Math.random() - 0.5) * 18}px`;
    spark.style.background = color;
    spark.style.boxShadow = `0 0 8px ${color}`;
    spark.style.setProperty('--sx', `${Math.cos(angle) * dist}px`);
    spark.style.setProperty('--sy', `${Math.sin(angle) * dist - 18}px`);
    spark.style.animationDelay = `${Math.random() * 90}ms`;
    layer.appendChild(spark);
  }
  container.appendChild(layer);

  if (label) {
    const banner = mk('div', 'forge-fx-banner sans', `✦ ${label}`);
    banner.style.color = color;
    container.appendChild(banner);
  }

  setTimeout(() => {
    layer.remove();
  }, 850);
}

function renderSelectedAnvilItem(p) {
  const box = DOM['craft-selected-box'];
  if (!box) return;

  box.className = 'item-tooltip-box forge-anvil-box';

  if (!craftTarget) {
    lastRenderedTarget = null;
    box.innerHTML =
      '<div style="text-align:center;padding:48px 12px;color:var(--ash);font-size:13px;">⚒ Select a relic or vessel from the left to place upon the Sacred Anvil.</div>';
    return;
  }

  const frame = getRarityFrame(craftTarget.rarity);
  const icon = getItemIcon(craftTarget);
  const score = getItemScoreSafe(craftTarget, p);
  const locked = isItemLocked(craftTarget);
  const isEquipped = !p.bag.includes(craftTarget);
  const slotLbl = craftTarget.subType || SLOT_LABELS[craftTarget.slot] || craftTarget.slot;

  box.classList.add(frame.cls);

  const affixes = Array.isArray(craftTarget.affixes) ? craftTarget.affixes : [];
  const gems = Array.isArray(craftTarget.gems) ? craftTarget.gems : [];

  box.innerHTML = `
    <div class="forge-anvil-hero">
      <div style="display:flex;align-items:center;gap:12px;min-width:0;flex:1;">
        <div class="forge-big-icon" style="border-color:${frame.color};box-shadow:inset 0 0 14px rgba(0,0,0,0.85), 0 0 18px ${frame.color}44;text-shadow:0 0 12px ${frame.color};">
          ${icon}
        </div>
        <div style="min-width:0;flex:1;">
          <div style="font-weight:800;font-size:16px;line-height:1.22;color:#faf3e4;word-break:break-word;">
            ${locked ? '🔒 ' : ''}${craftTarget.name}
          </div>
          <div style="font-size:11.5px;font-weight:700;color:${frame.color};margin-top:3px;">
            ${frame.rune} ${frame.name} • ${slotLbl} • ${isEquipped ? 'Equipped' : 'In Pack'}
          </div>
        </div>
      </div>
      <div class="forge-score-badge">
        <span style="font-size:9px;letter-spacing:0.8px;color:#b8aa8c;text-transform:uppercase;font-weight:700;">Item Score</span>
        <span style="font-size:21px;font-weight:900;color:#fae09b;line-height:1.1;">★ ${score}</span>
      </div>
    </div>

    <div class="forge-affix-grid sans">
      ${
        affixes.length
          ? affixes.map(a => `<div class="forge-affix-line">✦ ${a.text}</div>`).join('')
          : '<div class="forge-affix-line" style="color:var(--ash);">No forged affixes yet.</div>'
      }
      ${gems
        .map(
          g =>
            `<div class="forge-affix-line" style="border-left-color:${g.color};color:${g.color};">💎 ${g.name}: ${g.text}</div>`
        )
        .join('')}
      ${
        craftTarget.unique
          ? `<div class="forge-affix-line" style="border-left-color:#ff9436;color:#ffd089;">🔥 ${craftTarget.unique.power}</div>`
          : ''
      }
    </div>
  `;

  if (pendingForgeFx) {
    const fx = pendingForgeFx;
    pendingForgeFx = null;
    box.classList.remove('forge-strike-anim');
    void box.offsetWidth;
    box.classList.add('forge-strike-anim');
    spawnForgeSparks(box, fx.color, fx.label);
  } else if (lastRenderedTarget !== craftTarget) {
    box.classList.remove('forge-select-anim');
    void box.offsetWidth;
    box.classList.add('forge-select-anim');
  }

  lastRenderedTarget = craftTarget;
}

function updateForgeActionNodes(p) {
  for (const act of FORGE_ACTIONS) {
    const btn = $(act.id);
    if (!btn) continue;

    const usable = act.canUse ? act.canUse(craftTarget, p) : Boolean(craftTarget);
    btn.disabled = !usable;

    if (act.id === 'cf-salvage') {
      const subEl = btn.querySelector('.forge-node-sub');
      if (subEl) {
        if (!craftTarget) subEl.textContent = 'Select Item';
        else if (isItemLocked(craftTarget)) subEl.textContent = 'Item Sealed 🔒';
        else if (!p.bag.includes(craftTarget)) subEl.textContent = 'Unequip First';
        else subEl.textContent = act.sub;
      }
    }
  }
}

function setupForgeActionNodes() {
  const firstBtn = $(FORGE_ACTIONS[0].id);
  const grid = firstBtn?.parentElement;
  if (grid) {
    grid.className = 'forge-ritual-grid sans';
    FORGE_ACTIONS.forEach(act => {
      const b = $(act.id);
      if (b) grid.appendChild(b);
    });
  }

  for (const act of FORGE_ACTIONS) {
    const btn = $(act.id);
    if (!btn) continue;

    btn.className = `forge-action-node ${act.danger ? 'danger' : ''}`;
    btn.style.setProperty('--node-color', act.sparkColor);
    btn.style.setProperty('--node-glow', `${act.sparkColor}38`);
    btn.innerHTML = `
      <span class="forge-node-ico">${act.icon}</span>
      <span class="forge-node-title">${act.title}</span>
      <span class="forge-node-sub">${act.sub}</span>
      <span class="forge-node-cost">${act.cost}</span>
    `;

    btn.onclick = () => {
      const p = state.player;
      if (!p || !craftTarget) return;
      if (act.canUse && !act.canUse(craftTarget, p)) return;

      if (act.run(craftTarget, p)) {
        pendingForgeFx = { color: act.sparkColor, label: act.fxLabel };
        renderCraft();
        updateHud();
      }
    };
  }
}

export function renderCraft() {
  ensureForgeStyles();
  const p = state.player;
  if (!p) return;

  const list = DOM['craft-item-list'];
  list.classList.add('forge-list-scroll');

  DOM['craft-gold'].textContent = state.runGold;
  DOM['craft-shards'].textContent = state.runShards;
  DOM['craft-essence'].textContent = state.runEssence;
  list.innerHTML = '';

  const equippedItems = SLOTS.map(s => p.equipped[s]).filter(Boolean);
  const all = [...equippedItems, ...p.bag];
  if (!craftTarget || !all.includes(craftTarget)) craftTarget = all[0] || null;

  all.forEach(it => {
    const isEquipped = equippedItems.includes(it);
    list.appendChild(
      createForgeListCard(it, {
        isEquipped,
        isSelected: craftTarget === it,
        player: p,
        onClick: () => {
          craftTarget = it;
          renderCraft();
        }
      })
    );
  });

  renderSelectedAnvilItem(p);
  updateForgeActionNodes(p);
}

export function initForgeUI() {
  ensureForgeStyles();
  setupForgeActionNodes();
}