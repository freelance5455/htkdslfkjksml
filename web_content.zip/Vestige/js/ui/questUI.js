import { mk } from '../core/utilities.js';
import { state, openModal, closeAllModals } from '../core/game.js';
import {
  QuestlineManager,
  QUEST_STATUS,
  REWARD_TYPES,
  getQuestTrackerData,
  getQuestLogData,
  getQuestRewards,
  advanceQuest,
  onQuestHook,
  consumeQuestCinematic
} from '../systems/questlines.js';

let activeSection = 'active';
let selectedQuestId = null;
let primaryQuestId = null;
let previousModeBeforeQuest = null;
let hooksBound = false;

const SECTION_TABS = [
  { id: 'active', label: 'Active', icon: '✦' },
  { id: 'completed', label: 'Completed', icon: '✔' },
  { id: 'failed', label: 'Failed', icon: '✖' },
  { id: 'faction', label: 'Faction Quests', icon: '⚜' },
  { id: 'main', label: 'Main Story', icon: '🔥' }
];

const FACTION_LABELS = {
  throne: 'Shattered Throne',
  choir: 'Choir of Stars',
  veiled: 'Veiled Abyss',
  bramble: 'Bramble Court',
  pilgrim: 'Ashen Pilgrimage',
  main: 'First Flame',
  unaligned: 'Wandering Chronicle'
};

const REWARD_TYPE_META = {
  [REWARD_TYPES.RELIC]:          { icon: '🏺', label: 'Relic',          color: '#ff9f43' },
  [REWARD_TYPES.BLESSING]:       { icon: '✨', label: 'Blessing',       color: '#ffe082' },
  [REWARD_TYPES.WORLD_MODIFIER]: { icon: '🌌', label: 'World Modifier', color: '#9fb4ff' },
  [REWARD_TYPES.FORGE_UPGRADE]:  { icon: '⚒', label: 'Forge Upgrade',  color: '#ff7b29' },
  [REWARD_TYPES.LORE]:           { icon: '📜', label: 'Lore Entry',     color: '#d6cba8' },
  [REWARD_TYPES.VENDOR]:         { icon: '⚖', label: 'Vendor Wares',   color: '#f4d68c' },
  [REWARD_TYPES.CLASS]:          { icon: '🛡', label: 'Class Unlock',   color: '#5effb1' },
  [REWARD_TYPES.BIOME]:          { icon: '🗺', label: 'Biome Echo',     color: '#6be3ff' },
  [REWARD_TYPES.BOSS]:           { icon: '💀', label: 'Boss Encounter', color: '#ff5b6c' },
  [REWARD_TYPES.RECIPE]:         { icon: '📐', label: 'Craft Recipe',   color: '#f0b938' },
  [REWARD_TYPES.CURRENCY]:       { icon: '🪙', label: 'Spoils',         color: '#ffd700' }
};

const STATUS_META = {
  [QUEST_STATUS.ACTIVE]:       { label: 'Active',       color: '#f4d68c', bg: 'rgba(201,160,80,0.16)', border: 'rgba(244,214,140,0.55)' },
  [QUEST_STATUS.COMPLETED]:    { label: 'Completed',    color: '#5effb1', bg: 'rgba(20,84,54,0.45)',  border: 'rgba(94,255,177,0.55)' },
  [QUEST_STATUS.FAILED]:       { label: 'Failed',       color: '#ff6b7a', bg: 'rgba(94,22,32,0.48)',  border: 'rgba(255,107,122,0.55)' },
  [QUEST_STATUS.UNDISCOVERED]: { label: 'Undiscovered', color: '#8f889e', bg: 'rgba(255,255,255,0.04)', border: 'rgba(255,255,255,0.14)' }
};

// ============================================================================
// ANCIENT RELIQUARY STYLES (BLESSING-INSPIRED ORNATE DARK FANTASY)
// ============================================================================

function ensureQuestStyles() {
  if (typeof document === 'undefined' || document.getElementById('rel-quest-styles')) return;
  const style = document.createElement('style');
  style.id = 'rel-quest-styles';
  style.textContent = `
    /* Minimal Gameplay Quest Tracker */
    .rel-q-tracker {
      pointer-events: auto;
      cursor: pointer;
      display: flex;
      flex-direction: column;
      gap: 3px;
      padding: 7px 11px;
      min-width: 175px;
      max-width: 245px;
      border-radius: 6px;
      background: linear-gradient(165deg, rgba(24, 19, 32, 0.90) 0%, rgba(11, 9, 16, 0.92) 100%);
      border: 1px solid rgba(201, 160, 80, 0.48);
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.6), inset 0 0 14px rgba(201, 160, 80, 0.08);
      transition: transform 0.14s ease, border-color 0.18s ease, box-shadow 0.18s ease;
    }
    .rel-q-tracker:hover {
      transform: translateY(-1px);
      border-color: #f4d68c;
      box-shadow: 0 8px 22px rgba(0, 0, 0, 0.72), 0 0 14px rgba(244, 214, 140, 0.2);
    }
    .rel-q-tracker.floating {
      position: fixed;
      left: 14px;
      top: 122px;
      z-index: 25;
    }
    .rel-q-tracker-title {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      font-weight: 800;
      color: #f8dc94;
      letter-spacing: 0.3px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .rel-q-tracker-sub {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      font-size: 10.5px;
      color: #cfc6b0;
    }
    .rel-q-tracker-bar {
      height: 3px;
      width: 100%;
      border-radius: 2px;
      background: rgba(255, 255, 255, 0.1);
      overflow: hidden;
      margin-top: 2px;
    }
    .rel-q-tracker-fill {
      height: 100%;
      border-radius: 2px;
      background: linear-gradient(90deg, #c9a050, #f8dc94);
      transition: width 0.25s ease;
    }

    /* Full Quest Journal Modal with Subtle Background Dimming */
    #quest-modal.modal-overlay {
      background: rgba(5, 4, 9, 0.76);
      backdrop-filter: blur(3px);
    }

    #quest-modal .modal-box {
      background:
        radial-gradient(circle at 50% 0%, rgba(201, 160, 80, 0.12), transparent 58%),
        linear-gradient(180deg, #17131e 0%, #0b0910 100%);
      border: 1.5px solid #8c6d34;
      box-shadow:
        inset 0 0 0 1px rgba(244, 214, 140, 0.16),
        inset 0 0 42px rgba(0, 0, 0, 0.78),
        0 28px 80px rgba(0, 0, 0, 0.92);
      width: min(1060px, 96vw);
      max-height: 90dvh;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    #quest-modal .modal-header {
      border-bottom: 1px solid rgba(201, 160, 80, 0.34);
      padding-bottom: 10px;
      margin-bottom: 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      flex-wrap: wrap;
    }

    #quest-modal .modal-header h2 {
      margin: 0;
      color: #f4d68c;
      letter-spacing: 1.8px;
      text-shadow: 0 0 16px rgba(201, 160, 80, 0.38);
      font-size: 20px;
    }

    .rel-q-tabs {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 12px;
    }

    .rel-q-tab {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 12px;
      border-radius: 5px;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.4px;
      cursor: pointer;
      color: #c2b9a5;
      background: linear-gradient(180deg, #211c2b 0%, #131019 100%);
      border: 1px solid rgba(201, 160, 80, 0.3);
      transition: transform 0.12s ease, border-color 0.15s ease, color 0.15s ease;
    }
    .rel-q-tab:hover {
      transform: translateY(-1px);
      border-color: rgba(244, 214, 140, 0.65);
      color: #fff2cc;
    }
    .rel-q-tab.active {
      color: #161007;
      background: linear-gradient(180deg, #f8dc94 0%, #c9a050 100%);
      border-color: #fff2cc;
      box-shadow: 0 0 14px rgba(244, 214, 140, 0.35);
    }
    .rel-q-tab-count {
      padding: 1px 5px;
      border-radius: 3px;
      font-size: 10px;
      background: rgba(0, 0, 0, 0.25);
    }

    .rel-q-layout {
      display: grid;
      grid-template-columns: minmax(280px, 1.05fr) minmax(320px, 1.25fr);
      gap: 14px;
      min-height: 0;
      flex: 1;
      overflow: hidden;
    }

    .rel-q-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
      overflow-y: auto;
      padding-right: 4px;
      min-height: 220px;
    }

    .rel-q-detail {
      display: flex;
      flex-direction: column;
      gap: 12px;
      overflow-y: auto;
      padding: 14px;
      border-radius: 8px;
      background:
        radial-gradient(circle at 12% 8%, rgba(201, 160, 80, 0.08), transparent 46%),
        linear-gradient(180deg, #1a1523 0%, #0f0c15 100%);
      border: 1.5px solid #6b542b;
      box-shadow: inset 0 0 28px rgba(0, 0, 0, 0.68);
    }

    .rel-q-list::-webkit-scrollbar,
    .rel-q-detail::-webkit-scrollbar { width: 7px; }
    .rel-q-list::-webkit-scrollbar-thumb,
    .rel-q-detail::-webkit-scrollbar-thumb {
      background: linear-gradient(180deg, #755b2c, #49381b);
      border-radius: 4px;
    }

    /* Blessing-Inspired Quest Card */
    .rel-q-card {
      position: relative;
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 12px 13px;
      border-radius: 8px;
      cursor: pointer;
      overflow: hidden;
      background:
        radial-gradient(circle at 14% 12%, rgba(201, 160, 80, 0.14), transparent 56%),
        linear-gradient(165deg, #211b2b 0%, #110e17 100%);
      border: 1.5px solid rgba(201, 160, 80, 0.42);
      box-shadow: inset 0 0 18px rgba(0, 0, 0, 0.55);
      transition: transform 0.14s ease, border-color 0.16s ease, box-shadow 0.18s ease;
    }
    .rel-q-card::before {
      content: '';
      position: absolute;
      inset: 3px;
      border-radius: 6px;
      border: 1px solid rgba(255, 255, 255, 0.05);
      pointer-events: none;
    }
    .rel-q-card:hover {
      transform: translateY(-2px);
      border-color: #f4d68c;
      box-shadow: 0 0 18px rgba(244, 214, 140, 0.24), inset 0 0 18px rgba(0, 0, 0, 0.55);
    }
    .rel-q-card.selected {
      border-color: #ffe39e;
      box-shadow: 0 0 24px rgba(244, 214, 140, 0.38), inset 0 0 20px rgba(244, 214, 140, 0.14);
    }
    .rel-q-card.undiscovered {
      opacity: 0.72;
      border-style: dashed;
      border-color: rgba(160, 150, 180, 0.35);
    }

    .rel-q-card-head {
      display: flex;
      align-items: flex-start;
      gap: 11px;
    }

    .rel-q-crest {
      width: 46px;
      height: 46px;
      border-radius: 7px;
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      background: radial-gradient(circle at 50% 35%, rgba(255, 255, 255, 0.1), rgba(8, 7, 13, 0.94));
      border: 1.5px solid rgba(244, 214, 140, 0.5);
      box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.8);
    }

    .rel-q-card-title {
      font-size: 14.5px;
      font-weight: 800;
      color: #f8f1e4;
      line-height: 1.25;
    }
    .rel-q-card-stage {
      font-size: 11.5px;
      color: #d6cba8;
      margin-top: 2px;
    }
    .rel-q-status-pill {
      padding: 2px 7px;
      border-radius: 4px;
      font-size: 10px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      white-space: nowrap;
    }

    .rel-q-prog-row {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 11px;
      color: #cfc6b0;
    }
    .rel-q-prog-track {
      flex: 1;
      height: 5px;
      border-radius: 3px;
      background: rgba(255, 255, 255, 0.09);
      overflow: hidden;
    }
    .rel-q-prog-bar {
      height: 100%;
      border-radius: 3px;
      background: linear-gradient(90deg, #b88b3a, #ffe08c);
    }

    .rel-q-rw-strip {
      display: flex;
      flex-wrap: wrap;
      gap: 5px;
    }
    .rel-q-rw-chip {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 7px;
      border-radius: 4px;
      font-size: 10.5px;
      font-weight: 600;
      background: rgba(0, 0, 0, 0.34);
      border: 1px solid rgba(255, 255, 255, 0.14);
      color: #e4dcc8;
    }
    .rel-q-rw-chip.claimed {
      border-color: rgba(94, 255, 177, 0.5);
      background: rgba(20, 76, 48, 0.36);
      color: #9effd1;
    }

    .rel-q-section-box {
      padding: 10px 12px;
      border-radius: 6px;
      background: rgba(12, 10, 18, 0.65);
      border: 1px solid rgba(201, 160, 80, 0.26);
    }
    .rel-q-section-title {
      font-size: 10.5px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.9px;
      color: #c9a050;
      margin-bottom: 7px;
    }

    .rel-q-quote {
      font-style: italic;
      font-size: 12.5px;
      line-height: 1.45;
      color: #e5d8bc;
      padding: 8px 11px;
      border-left: 2.5px solid #c9a050;
      background: rgba(201, 160, 80, 0.08);
      border-radius: 0 5px 5px 0;
    }

    .rel-q-obj-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 5px 0;
      font-size: 12px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }
    .rel-q-obj-row:last-child { border-bottom: none; }

    .rel-q-choice-btn {
      width: 100%;
      text-align: left;
      padding: 9px 11px;
      border-radius: 6px;
      cursor: pointer;
      background: linear-gradient(180deg, #2a2117 0%, #19130d 100%);
      border: 1px solid rgba(244, 214, 140, 0.55);
      color: #f8e5b4;
      transition: transform 0.12s ease, filter 0.15s ease;
    }
    .rel-q-choice-btn:hover {
      transform: translateY(-1px);
      filter: brightness(1.14);
    }

    .rel-q-reward-card {
      display: flex;
      align-items: flex-start;
      gap: 9px;
      padding: 8px 10px;
      border-radius: 6px;
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.1);
    }
    .rel-q-reward-card.claimed {
      background: rgba(22, 74, 48, 0.25);
      border-color: rgba(94, 255, 177, 0.45);
    }

    .rel-q-history-step {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      font-size: 11.5px;
      color: #cfc6b0;
      padding: 4px 0;
    }

    @media (max-width: 820px) {
      .rel-q-layout {
        grid-template-columns: 1fr;
        overflow-y: auto;
      }
      .rel-q-list {
        overflow-y: visible;
        min-height: 0;
      }
      .rel-q-detail {
        overflow-y: visible;
      }
      .rel-q-tracker.floating {
        left: 8px;
        top: auto;
        bottom: 132px;
        max-width: 195px;
        padding: 6px 9px;
      }
    }
  `;
  document.head.appendChild(style);
}

// ============================================================================
// QUEST DATA ENRICHMENT & SECTION CLASSIFICATION
// ============================================================================

function getEnrichedQuests() {
  const entries = getQuestLogData();
  return entries.map(entry => {
    const ql = QuestlineManager.registry.get(entry.id);
    const faction = ql?.faction || 'unaligned';
    const rewards = getQuestRewards(entry.id);
    const totalStages = ql ? Object.keys(ql.stages).length : 0;
    const isMainStory =
      ql?.isMainStory ||
      faction === 'main' ||
      faction === 'pilgrim' ||
      entry.id === 'last_pilgrim' ||
      entry.id === 'veiled_seer';
    const isFaction = ['throne', 'choir', 'veiled', 'bramble', 'iron'].includes(faction);

    let objDone = 0;
    let objTotal = 0;
    if (entry.currentStage?.objectives?.length) {
      for (const o of entry.currentStage.objectives) {
        objDone += Math.min(o.current, o.required);
        objTotal += o.required;
      }
    }

    return {
      ...entry,
      faction,
      factionLabel: FACTION_LABELS[faction] || faction,
      isMainStory,
      isFaction,
      rewards,
      totalStages,
      ql,
      objDone,
      objTotal
    };
  });
}

function filterQuestsBySection(quests, sectionId) {
  switch (sectionId) {
    case 'active':
      return quests.filter(q => q.status === QUEST_STATUS.ACTIVE);
    case 'completed':
      return quests.filter(q => q.status === QUEST_STATUS.COMPLETED);
    case 'failed':
      return quests.filter(q => q.status === QUEST_STATUS.FAILED);
    case 'faction':
      return quests.filter(q => q.isFaction);
    case 'main':
      return quests.filter(q => q.isMainStory);
    default:
      return quests;
  }
}

export function setPrimaryTrackedQuest(questId) {
  primaryQuestId = questId;
  renderQuestTracker();
}

export function getPrimaryTrackedQuest() {
  const active = getQuestTrackerData();
  if (!active.length) return null;
  if (primaryQuestId) {
    const match = active.find(q => q.id === primaryQuestId);
    if (match) return match;
  }
  primaryQuestId = active[0].id;
  return active[0];
}

// ============================================================================
// MINIMAL GAMEPLAY QUEST TRACKER (NON-BLOCKING)
// ============================================================================

function ensureTrackerElement() {
  if (typeof document === 'undefined') return null;
  // When HUD already renders #hud-quest-tracker beneath player resources, skip duplicate tracker
  if (document.getElementById('hud-quest-tracker')) return null;

  let el = document.getElementById('rel-quest-tracker');
  if (!el) {
    el = mk('div', 'rel-q-tracker sans');
    el.id = 'rel-quest-tracker';
    el.title = 'Click to open Quest Journal [J]';
    el.onclick = () => openQuestModal('active');

    const host = document.getElementById('quest-box');
    if (host) {
      host.innerHTML = '';
      host.appendChild(el);
    } else {
      el.classList.add('floating');
      (document.getElementById('hud') || document.body).appendChild(el);
    }
  }
  return el;
}

export function renderQuestTracker() {
  ensureQuestStyles();
  const tracker = ensureTrackerElement();
  if (!tracker) return;

  if (!state?.player || state.mode === 'menu') {
    tracker.style.display = 'none';
    return;
  }

  const primary = getPrimaryTrackedQuest();
  if (!primary) {
    tracker.style.display = 'none';
    return;
  }

  let cur = 0;
  let req = 0;
  for (const o of primary.objectives) {
    cur += Math.min(o.current, o.required);
    req += o.required;
  }
  const pct = req > 0 ? Math.min(100, Math.round((cur / req) * 100)) : 100;
  const statusLine = primary.awaitingChoice
    ? 'Decision Ready'
    : `${cur} / ${req || 1} Objectives`;

  tracker.style.display = 'flex';
  tracker.style.borderColor = `${primary.color}99`;
  tracker.innerHTML = `
    <div class="rel-q-tracker-title">
      <span style="color:${primary.color};">${primary.icon || '✦'}</span>
      <span style="overflow:hidden;text-overflow:ellipsis;">${primary.name}</span>
    </div>
    <div class="rel-q-tracker-sub">
      <span>${statusLine}</span>
      <span style="color:${primary.color};font-weight:700;">Journal ▸</span>
    </div>
    <div class="rel-q-tracker-bar">
      <div class="rel-q-tracker-fill" style="width:${pct}%;"></div>
    </div>
  `;
}

// ============================================================================
// QUEST JOURNAL MODAL (REUSES GAME MENU PAUSE SYSTEM)
// ============================================================================

function resumeFromQuestJournal() {
  if (state.player && typeof closeAllModals === 'function') {
    closeAllModals();
    return;
  }
  closeQuestModal();
  if (previousModeBeforeQuest && state.mode === 'quest') {
    state.mode = previousModeBeforeQuest;
  }
  previousModeBeforeQuest = null;
}

function ensureQuestModal() {
  if (typeof document === 'undefined') return null;
  let modal = document.getElementById('quest-modal');
  if (!modal) {
    modal = mk('div', 'modal-overlay');
    modal.id = 'quest-modal';
    modal.innerHTML = `
      <div class="modal-box">
        <div class="modal-header">
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
            <h2>QUEST JOURNAL</h2>
            <span id="rel-q-summary-badge" class="sans" style="font-size:11.5px;color:#cfc6b0;"></span>
          </div>
          <button type="button" class="btn-gold" id="btn-close-quest">Resume [J / Esc]</button>
        </div>
        <div class="rel-q-tabs sans" id="rel-q-tabs"></div>
        <div class="rel-q-layout">
          <div class="rel-q-list" id="rel-q-list"></div>
          <div class="rel-q-detail sans" id="rel-q-detail"></div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    modal.querySelector('#btn-close-quest').onclick = resumeFromQuestJournal;
    modal.onclick = e => {
      if (e.target === modal) resumeFromQuestJournal();
    };
  }
  return modal;
}

function buildQuestCard(q, isSelected, isPrimary) {
  const stMeta = STATUS_META[q.status] || STATUS_META.undiscovered;
  const undiscovered = q.status === QUEST_STATUS.UNDISCOVERED;
  const stageText = undiscovered
    ? 'Undiscovered NPC Questline'
    : q.status === QUEST_STATUS.COMPLETED
      ? `Resolved • ${q.ending || q.npcState}`
      : q.status === QUEST_STATUS.FAILED
        ? `Severed • ${q.ending || 'Failed'}`
        : q.currentStage?.title || q.npcState;

  const pct =
    q.status === QUEST_STATUS.COMPLETED
      ? 100
      : q.objTotal > 0
        ? Math.round((q.objDone / q.objTotal) * 100)
        : 0;

  const progText =
    q.status === QUEST_STATUS.COMPLETED
      ? 'Completed'
      : q.status === QUEST_STATUS.FAILED
        ? 'Failed'
        : undiscovered
          ? 'Unmet'
          : q.currentStage?.readyForChoice
            ? 'Choice Ready'
            : `${q.objDone} / ${q.objTotal || 1}`;

  const previewRewards = q.rewards.slice(0, 3);
  const rwChips = previewRewards
    .map(rw => {
      const meta = REWARD_TYPE_META[rw.type] || { icon: '◈', color: '#f4d68c' };
      return `<span class="rel-q-rw-chip ${rw.claimed ? 'claimed' : ''}">${meta.icon} ${rw.name}</span>`;
    })
    .join('');

  const card = mk(
    'div',
    `rel-q-card sans ${isSelected ? 'selected' : ''} ${undiscovered ? 'undiscovered' : ''}`,
    `
      <div class="rel-q-card-head">
        <div class="rel-q-crest" style="border-color:${q.color}99;color:${q.color};text-shadow:0 0 10px ${q.color}66;">
          ${undiscovered ? '?' : q.icon}
        </div>
        <div style="min-width:0;flex:1;">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:6px;">
            <div class="rel-q-card-title">${q.name}</div>
            <span class="rel-q-status-pill" style="color:${stMeta.color};background:${stMeta.bg};border:1px solid ${stMeta.border};">${stMeta.label}</span>
          </div>
          <div class="rel-q-card-stage">${stageText}</div>
          <div style="font-size:10px;color:#9a92a8;margin-top:2px;">
            ${q.factionLabel}${isPrimary ? ' • <span style="color:#ffd700;font-weight:700;">★ Tracked</span>' : ''}
          </div>
        </div>
      </div>

      <div class="rel-q-prog-row">
        <div class="rel-q-prog-track">
          <div class="rel-q-prog-bar" style="width:${pct}%;background:${q.status === QUEST_STATUS.FAILED ? '#ff5b6c' : ''};"></div>
        </div>
        <span style="min-width:64px;text-align:right;font-weight:700;">${progText}</span>
      </div>

      ${rwChips ? `<div class="rel-q-rw-strip">${rwChips}</div>` : ''}
    `
  );

  card.onclick = () => {
    selectedQuestId = q.id;
    renderQuestJournal();
  };
  return card;
}

function renderQuestDetailPanel(container, q) {
  if (!q) {
    container.innerHTML = `<div style="color:#9a92a8;font-size:13px;padding:24px;text-align:center;">Select a questline to inspect its chronicle, NPC state, rewards, and history.</div>`;
    return;
  }

  const stMeta = STATUS_META[q.status] || STATUS_META.undiscovered;
  const isPrimary = primaryQuestId === q.id;
  const undiscovered = q.status === QUEST_STATUS.UNDISCOVERED;

  if (undiscovered) {
    container.innerHTML = `
      <div style="display:flex;align-items:center;gap:12px;">
        <div class="rel-q-crest" style="width:54px;height:54px;font-size:26px;color:${q.color};border-color:${q.color}66;">?</div>
        <div>
          <h3 style="margin:0;color:#f8f1e4;font-size:17px;">${q.name}</h3>
          <div style="font-size:11.5px;color:#9a92a8;margin-top:2px;">${q.factionLabel} • Undiscovered Chronicle</div>
        </div>
      </div>
      <div class="rel-q-section-box">
        <div class="rel-q-section-title">Rumors in the Expanse</div>
        <div style="font-size:12.5px;color:#cfc6b0;line-height:1.5;">${q.description}</div>
        <div style="font-size:11.5px;color:#9a92a8;margin-top:8px;">Seek this NPC through world events, dungeons, or biome discoveries to begin their questline.</div>
      </div>
    `;
    return;
  }

  let objectivesHTML = '';
  if (q.currentStage?.objectives?.length) {
    objectivesHTML = q.currentStage.objectives
      .map(o => {
        const done = o.done || q.status === QUEST_STATUS.COMPLETED;
        return `
          <div class="rel-q-obj-row">
            <span style="color:${done ? '#5effb1' : '#f4ece0'};">${done ? '✔' : '◈'} ${o.label}</span>
            <span style="font-weight:800;color:${done ? '#5effb1' : '#f4d68c'};">${Math.min(o.current, o.required)} / ${o.required}</span>
          </div>`;
      })
      .join('');
  }

  let choicesHTML = '';
  if (q.status === QUEST_STATUS.ACTIVE && q.currentStage?.readyForChoice && q.currentStage.choices?.length) {
    choicesHTML = `
      <div class="rel-q-section-box" style="border-color:rgba(244,214,140,0.6);">
        <div class="rel-q-section-title">✦ Fateful Decision</div>
        <div style="display:flex;flex-direction:column;gap:7px;">
          ${q.currentStage.choices
            .map(
              c => `
              <button type="button" class="rel-q-choice-btn" data-quest-choice="${c.id}">
                <div style="font-weight:800;font-size:12.5px;">${c.label}</div>
                <div style="font-size:11px;color:#cfc6b0;margin-top:2px;">${c.description}</div>
              </button>`
            )
            .join('')}
        </div>
      </div>
    `;
  }

  const rewardsHTML = q.rewards.length
    ? q.rewards
        .map(rw => {
          const meta = REWARD_TYPE_META[rw.type] || { icon: '◈', label: rw.type, color: '#f4d68c' };
          return `
            <div class="rel-q-reward-card ${rw.claimed ? 'claimed' : ''}">
              <div style="font-size:20px;line-height:1;">${meta.icon}</div>
              <div style="min-width:0;flex:1;">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;">
                  <span style="font-weight:800;font-size:12.5px;color:${rw.claimed ? '#9effd1' : '#f6f1e7'};">${rw.name}</span>
                  <span style="font-size:10px;font-weight:800;color:${rw.claimed ? '#5effb1' : meta.color};">
                    ${rw.claimed ? '✓ Claimed' : meta.label}
                  </span>
                </div>
                ${rw.description ? `<div style="font-size:11px;color:#b8afc4;margin-top:2px;">${rw.description}</div>` : ''}
              </div>
            </div>
          `;
        })
        .join('')
    : '<div style="font-size:11.5px;color:#9a92a8;">No registered rewards for this chronicle.</div>';

  const historyRows = [];
  if (q.ql) {
    for (const stepId of q.completedSteps) {
      const stDef = q.ql.getStage(stepId);
      const dec = q.decisions[stepId];
      const decLabel = dec && stDef?.choices ? stDef.choices.find(c => c.id === dec)?.label || dec : null;
      historyRows.push(`
        <div class="rel-q-history-step">
          <span style="color:#5effb1;">✔</span>
          <div>
            <b>${stDef?.title || stepId}</b>
            ${decLabel ? `<div style="font-size:11px;color:#f4d68c;">Decision: ${decLabel}</div>` : ''}
          </div>
        </div>
      `);
    }
  }
  if (q.ending) {
    historyRows.push(`
      <div class="rel-q-history-step">
        <span style="color:${q.status === QUEST_STATUS.FAILED ? '#ff6b7a' : '#ffd700'};">✦</span>
        <div><b>Ending:</b> ${q.ending}</div>
      </div>
    `);
  }

  container.innerHTML = `
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;flex-wrap:wrap;">
      <div style="display:flex;align-items:center;gap:12px;">
        <div class="rel-q-crest" style="width:54px;height:54px;font-size:28px;color:${q.color};border-color:${q.color};">
          ${q.icon}
        </div>
        <div>
          <h3 style="margin:0;color:#f8f1e4;font-size:17px;">${q.name}</h3>
          <div style="font-size:11.5px;color:#cfc6b0;margin-top:2px;">
            ${q.factionLabel} • NPC State: <b style="color:${q.color};">${q.npcState}</b>
          </div>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:8px;">
        <span class="rel-q-status-pill" style="color:${stMeta.color};background:${stMeta.bg};border:1px solid ${stMeta.border};">${stMeta.label}</span>
        ${
          q.status === QUEST_STATUS.ACTIVE
            ? `<button type="button" class="${isPrimary ? 'btn-gold' : 'btn-dark'}" id="btn-pin-primary-quest" style="font-size:11px;padding:4px 9px;">${isPrimary ? '★ Primary' : '☆ Track'}</button>`
            : ''
        }
      </div>
    </div>

    <div style="font-size:12.5px;color:#d6cba8;line-height:1.45;">${q.description}</div>

    ${q.currentStage?.dialogue ? `<div class="rel-q-quote">${q.currentStage.dialogue}</div>` : ''}

    ${
      q.currentStage
        ? `<div class="rel-q-section-box">
             <div class="rel-q-section-title">Current Stage — ${q.currentStage.title}</div>
             <div style="font-size:12px;color:#cfc6b0;margin-bottom:6px;">${q.currentStage.description}</div>
             ${objectivesHTML}
           </div>`
        : ''
    }

    ${choicesHTML}

    <div class="rel-q-section-box">
      <div class="rel-q-section-title">Chronicle Rewards</div>
      <div style="display:flex;flex-direction:column;gap:7px;">${rewardsHTML}</div>
    </div>

    <div class="rel-q-section-box">
      <div class="rel-q-section-title">Quest History</div>
      ${historyRows.length ? historyRows.join('') : '<div style="font-size:11.5px;color:#9a92a8;">Chronicle recently begun.</div>'}
    </div>
  `;

  const pinBtn = container.querySelector('#btn-pin-primary-quest');
  if (pinBtn) {
    pinBtn.onclick = () => {
      setPrimaryTrackedQuest(q.id);
      renderQuestJournal();
    };
  }

  container.querySelectorAll('[data-quest-choice]').forEach(btn => {
    btn.onclick = () => {
      const choiceId = btn.getAttribute('data-quest-choice');
      advanceQuest(q.id, { choiceId });
      renderQuestJournal();
      renderQuestTracker();
    };
  });
}

export function renderQuestJournal() {
  ensureQuestStyles();
  const modal = ensureQuestModal();
  if (!modal) return;

  const allQuests = getEnrichedQuests();
  const tabsEl = modal.querySelector('#rel-q-tabs');
  const listEl = modal.querySelector('#rel-q-list');
  const detailEl = modal.querySelector('#rel-q-detail');
  const summaryEl = modal.querySelector('#rel-q-summary-badge');

  const completedCount = allQuests.filter(q => q.status === QUEST_STATUS.COMPLETED).length;
  const activeCount = allQuests.filter(q => q.status === QUEST_STATUS.ACTIVE).length;
  if (summaryEl) {
    summaryEl.textContent = `${activeCount} Active • ${completedCount}/${allQuests.length} Resolved`;
  }

  tabsEl.innerHTML = '';
  for (const tab of SECTION_TABS) {
    const count = filterQuestsBySection(allQuests, tab.id).length;
    const btn = mk(
      'button',
      `rel-q-tab ${activeSection === tab.id ? 'active' : ''}`,
      `${tab.icon} ${tab.label} <span class="rel-q-tab-count">${count}</span>`
    );
    btn.type = 'button';
    btn.onclick = () => {
      activeSection = tab.id;
      selectedQuestId = null;
      renderQuestJournal();
    };
    tabsEl.appendChild(btn);
  }

  const visible = filterQuestsBySection(allQuests, activeSection);
  if (!visible.some(q => q.id === selectedQuestId)) {
    selectedQuestId = visible[0]?.id || null;
  }

  listEl.innerHTML = '';
  if (!visible.length) {
    listEl.appendChild(
      mk(
        'div',
        'sans',
        `<div style="padding:24px 12px;text-align:center;color:#9a92a8;font-size:12.5px;">No chronicles recorded in this section yet.</div>`
      )
    );
  } else {
    for (const q of visible) {
      listEl.appendChild(buildQuestCard(q, q.id === selectedQuestId, primaryQuestId === q.id));
    }
  }

  const selected = visible.find(q => q.id === selectedQuestId) || null;
  renderQuestDetailPanel(detailEl, selected);
}

/**
 * Opens the Quest Journal using the game's unified menu/pause state (`state.mode = 'quest'`).
 */
export function openQuestModal(section = null) {
  ensureQuestStyles();
  const modal = ensureQuestModal();
  if (!modal) return;
  if (section) activeSection = section;

  // Route through openModal('quest') so other open menus close and gameplay pauses cleanly
  if (state.mode !== 'quest') {
    previousModeBeforeQuest = state.mode;
    if (state.player && typeof openModal === 'function') {
      openModal('quest');
      return;
    }
    if (typeof closeAllModals === 'function') closeAllModals(true);
    state.mode = 'quest';
  }

  renderQuestJournal();
  modal.classList.add('active');
}

/**
 * Pure visual close called by `closeAllModals()` without recursion.
 */
export function closeQuestModal() {
  const modal = document.getElementById('quest-modal');
  if (modal) modal.classList.remove('active');
}

// ============================================================================
// INITIALIZATION & QUESTLINE HOOK BINDING
// ============================================================================

export function initQuestUI() {
  ensureQuestStyles();
  ensureTrackerElement();
  ensureQuestModal();

  if (!hooksBound) {
    hooksBound = true;
    const refresh = () => {
      renderQuestTracker();
      const modal = document.getElementById('quest-modal');
      if (modal?.classList.contains('active')) {
        renderQuestJournal();
      }
      consumeQuestCinematic();
    };

    onQuestHook('notify', refresh);
    onQuestHook('stageComplete', refresh);
    onQuestHook('questComplete', refresh);
    onQuestHook('questFailed', refresh);
    onQuestHook('rewardGranted', refresh);
  }

  renderQuestTracker();
}