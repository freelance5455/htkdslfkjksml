import { CFG } from '../core/config.js';
import { $ } from '../core/utilities.js';
import { state, events, enemyPool } from '../core/game.js';

const SIZE = 118;

// Marker icons and colors match the legend in hud.js.
// Merchant/shrine use plain symbols (not emoji) so they render in the same style as the rest.
const MARKERS = {
  boss: { icon: '★', color: '#ff5263', size: 13 },
  champion: { icon: '⚔', color: '#ff9d47', size: 10 },
  event: { icon: '♦', color: '#7ce8ff', size: 10 },
  vault: { icon: '▲', color: '#f4c752', size: 10 },
  merchant: { icon: '●', color: '#6effb0', size: 9 },
  shrine: { icon: '✚', color: '#d7a8ff', size: 10 }
};

let mCtx = null;
let backdrop = null;
let dpr = 1;

// Parchment-dark backdrop with compass rings and a soft edge vignette, drawn once and reused
function buildBackdrop() {
  const c = document.createElement('canvas');
  c.width = c.height = Math.round(SIZE * dpr);
  const g = c.getContext('2d');
  g.scale(dpr, dpr);
  const mid = SIZE / 2;

  const bg = g.createRadialGradient(mid, mid, 6, mid, mid, SIZE * 0.72);
  bg.addColorStop(0, '#2a2018');
  bg.addColorStop(1, '#0d0a10');
  g.fillStyle = bg;
  g.fillRect(0, 0, SIZE, SIZE);

  g.strokeStyle = 'rgba(201, 160, 80, 0.16)';
  g.lineWidth = 1;
  g.beginPath();
  g.arc(mid, mid, 22, 0, Math.PI * 2);
  g.moveTo(mid + 44, mid);
  g.arc(mid, mid, 44, 0, Math.PI * 2);
  g.moveTo(mid, 4);
  g.lineTo(mid, SIZE - 4);
  g.moveTo(4, mid);
  g.lineTo(SIZE - 4, mid);
  g.stroke();

  // Edge vignette so markers near the border sit on a darker, calmer field
  const vg = g.createRadialGradient(mid, mid, SIZE * 0.38, mid, mid, SIZE * 0.72);
  vg.addColorStop(0, 'rgba(0,0,0,0)');
  vg.addColorStop(1, 'rgba(0,0,0,0.45)');
  g.fillStyle = vg;
  g.fillRect(0, 0, SIZE, SIZE);

  return c;
}

const KIND_TO_MARKER = { vault: 'vault', merchant: 'merchant', shrine: 'shrine', altar: 'shrine', monument: 'shrine' };

function classifyEvent(ev) {
  if (KIND_TO_MARKER[ev.kind]) return KIND_TO_MARKER[ev.kind];
  const txt = `${ev.type || ''} ${ev.kind || ''} ${ev.id || ''} ${ev.name || ''}`.toLowerCase();
  if (/vault/.test(txt)) return 'vault';
  if (/merchant|peddler|trader|shop/.test(txt)) return 'merchant';
  if (/shrine|altar|monument|obelisk|idol/.test(txt)) return 'shrine';
  return 'event';
}

// Shared with events.js so world markers use the same icons as the minimap
export function eventMarker(ev) {
  const m = MARKERS[classifyEvent(ev)];
  return { icon: m.icon, color: ev.color || m.color };
}

function drawMarker(ctx, kind, x, y) {
  const m = MARKERS[kind];
  ctx.font = `bold ${m.size}px sans-serif`;
  // Dark halo keeps icons readable over the rings
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.75)';
  ctx.strokeText(m.icon, x, y);
  ctx.fillStyle = m.color;
  ctx.shadowColor = m.color;
  ctx.shadowBlur = 4;
  ctx.fillText(m.icon, x, y);
  ctx.shadowBlur = 0;
}

export function renderMinimap() {
  if (!mCtx) {
    const el = $('minimap');
    if (!el) return;
    // Render at device resolution so the map is crisp on HiDPI screens
    dpr = Math.min(2, window.devicePixelRatio || 1);
    el.width = el.height = Math.round(SIZE * dpr);
    mCtx = el.getContext('2d');
    backdrop = buildBackdrop();
  }

  const p = state.player;
  if (!p) return;

  mCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  mCtx.clearRect(0, 0, SIZE, SIZE);
  mCtx.drawImage(backdrop, 0, 0, SIZE, SIZE);
  mCtx.textAlign = 'center';
  mCtx.textBaseline = 'middle';

  const sx = SIZE / CFG.game.W;
  const sy = SIZE / CFG.game.H;

  // Current camera view rectangle
  const cam = state.camera;
  if (cam && cam.worldW && cam.worldH) {
    const vw = cam.worldW * sx;
    const vh = cam.worldH * sy;
    mCtx.strokeStyle = 'rgba(240, 207, 133, 0.45)';
    mCtx.lineWidth = 1;
    mCtx.strokeRect(cam.x * sx - vw / 2, cam.y * sy - vh / 2, vw, vh);
  }

  for (const ev of events) {
    if (ev.done || ev.used || ev.collected || ev.completed) continue;
    drawMarker(mCtx, classifyEvent(ev), ev.x * sx, ev.y * sy);
  }

  for (let i = 0; i < enemyPool.active.length; i++) {
    const e = enemyPool.active[i];
    if (!e.alive || e.boss || e === state.activeBoss) continue;
    if (e.elite || e.role === 'champion' || e.role === 'elite') {
      drawMarker(mCtx, 'champion', e.x * sx, e.y * sy);
    }
  }

  const boss = state.activeBoss;
  if (boss?.alive) {
    const bx = boss.x * sx;
    const by = boss.y * sy;
    const pulse = 0.5 + 0.5 * Math.sin(performance.now() / 260);
    mCtx.strokeStyle = `rgba(255, 82, 99, ${0.25 + 0.45 * pulse})`;
    mCtx.lineWidth = 1;
    mCtx.beginPath();
    mCtx.arc(bx, by, 6 + pulse * 2, 0, Math.PI * 2);
    mCtx.stroke();
    drawMarker(mCtx, 'boss', bx, by);
  }

  // Player: glowing gold pip with a pulsing ring
  const px = p.x * sx;
  const py = p.y * sy;
  const ping = (performance.now() / 1400) % 1;
  mCtx.strokeStyle = `rgba(240, 207, 133, ${0.4 * (1 - ping)})`;
  mCtx.lineWidth = 1;
  mCtx.beginPath();
  mCtx.arc(px, py, 3 + ping * 8, 0, Math.PI * 2);
  mCtx.stroke();

  mCtx.shadowColor = '#f0cf85';
  mCtx.shadowBlur = 6;
  mCtx.fillStyle = '#fff5d6';
  mCtx.strokeStyle = '#c9a050';
  mCtx.lineWidth = 1.5;
  mCtx.beginPath();
  mCtx.arc(px, py, 3, 0, Math.PI * 2);
  mCtx.fill();
  mCtx.stroke();
  mCtx.shadowBlur = 0;
}
