import { mk } from '../core/utilities.js';
import { metaSave } from '../core/save.js';
import { state } from '../core/game.js';

import { RARITIES, SLOTS, SLOT_LABELS, SETS } from '../data/items.js';
import { RELICS } from '../data/relicData.js';
import {
  INVENTORY_CATEGORIES,
  equipBagItem,
  salvageItem,
  sellItem,
  isItemLocked,
  toggleLockItem,
  canEquipItem,
  getSlotIcon,
  getItemIcon,
  getSlotCategory,
  getSlotFilter,
  setSlotFilter,
  organizeInventory,
  sortBag,
  scoreItem,
  getUpgradeIndicator,
  getItemSellValue,
  formatCompactTags,
  renderBulkActionButtons
} from '../systems/inventory.js';
import { DOM, updateHud } from './hud.js';

let selItem = null;
let selSource = null;
let preferredEqSlot = null;

const RARITY_THEMES = {
  common:    { cls: 'rel-rarity-common',    rune: '•', label: 'Common',    accent: '#8f8a99' },
  magic:     { cls: 'rel-rarity-magic',     rune: '✧', label: 'Magic',     accent: '#4da6ff' },
  rare:      { cls: 'rel-rarity-rare',      rune: '◆', label: 'Rare',      accent: '#f0b938' },
  legendary: { cls: 'rel-rarity-legendary', rune: '✦', label: 'Legendary', accent: '#ff8524' },
  mythic:    { cls: 'rel-rarity-mythic',    rune: '❖', label: 'Mythic',    accent: '#e45cff' }
};

const FILTER_DISPLAY_NAMES = {
  weapon: 'Weapons',
  helmet: 'Helmets',
  chest: 'Armor',
  ring: 'Rings',
  amulet: 'Amulets',
  relic: 'Relics'
};

function ensureReliquaryStyles() {
  if (typeof document === 'undefined' || document.getElementById('reliquary-inv-styles')) return;
  const style = document.createElement('style');
  style.id = 'reliquary-inv-styles';
  style.textContent = `
    #inv-modal .modal-box {
      background:
        radial-gradient(circle at 50% 0%, rgba(201, 160, 80, 0.09), transparent 55%),
        linear-gradient(180deg, #17131d 0%, #0d0b12 100%);
      border: 1.5px solid #8c6d34;
      box-shadow:
        inset 0 0 0 1px rgba(244, 214, 140, 0.16),
        inset 0 0 36px rgba(0, 0, 0, 0.72),
        0 26px 75px rgba(0, 0, 0, 0.9);
    }

    #inv-modal .modal-header {
      border-bottom: 1px solid rgba(201, 160, 80, 0.34);
      padding-bottom: 10px;
      margin-bottom: 12px;
      gap: 10px;
      flex-wrap: wrap;
    }

    #inv-modal .modal-header h2 {
      color: #f4d68c;
      letter-spacing: 1.4px;
      text-shadow: 0 0 14px rgba(201, 160, 80, 0.35);
    }

    .rel-bulk-bar {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      align-items: center;
      justify-content: flex-end;
      max-width: 100%;
    }

    .rel-bulk-bar button {
      white-space: nowrap;
      flex-shrink: 0;
      font-size: 11.5px;
      padding: 6px 10px;
      border-radius: 4px;
      transition: transform 0.12s ease, filter 0.15s ease, box-shadow 0.15s ease;
    }

    .rel-bulk-bar button:hover {
      transform: translateY(-1px);
      filter: brightness(1.12);
    }

    .rel-btn-ornate {
      background: linear-gradient(180deg, #272130 0%, #16121d 100%);
      border: 1px solid rgba(201, 160, 80, 0.45);
      color: #e9d7ad;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.08);
      cursor: pointer;
    }

    .rel-btn-ornate.danger {
      border-color: rgba(214, 86, 98, 0.55);
      color: #f3b2b9;
      background: linear-gradient(180deg, #321820 0%, #1b0d12 100%);
    }

    .rel-btn-ornate.gold-accent {
      border-color: rgba(235, 192, 92, 0.65);
      color: #f8dc94;
      background: linear-gradient(180deg, #332714 0%, #1b1409 100%);
    }

    #equipped-slots.rel-eq-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 9px;
    }

    #bag-grid.rel-bag-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(198px, 1fr));
      gap: 10px;
      max-height: 332px;
      overflow-y: auto;
      padding: 2px 5px 4px 2px;
    }

    #bag-grid.rel-bag-grid::-webkit-scrollbar { width: 7px; }
    #bag-grid.rel-bag-grid::-webkit-scrollbar-track { background: #0d0b11; border-radius: 4px; }
    #bag-grid.rel-bag-grid::-webkit-scrollbar-thumb {
      background: linear-gradient(180deg, #755b2c, #49381b);
      border-radius: 4px;
      border: 1px solid #16121d;
    }

    /* Filter Banner & Category Pills */
    .rel-filter-wrap {
      display: flex;
      flex-direction: column;
      gap: 7px;
      margin: 8px 0 10px;
    }

    .rel-filter-banner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      flex-wrap: wrap;
      padding: 7px 11px;
      border-radius: 6px;
      background: linear-gradient(90deg, rgba(201, 160, 80, 0.22), rgba(201, 160, 80, 0.06));
      border: 1.5px solid #e6bc5c;
      box-shadow: 0 0 16px rgba(230, 188, 92, 0.22);
    }

    .rel-filter-title {
      font-size: 12.5px;
      font-weight: 800;
      letter-spacing: 0.5px;
      color: #fae09b;
      display: flex;
      align-items: center;
      gap: 7px;
    }

    .rel-filter-pills {
      display: flex;
      flex-wrap: wrap;
      gap: 5px;
    }

    .rel-filter-pill {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 4px 9px;
      min-height: 28px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      color: #cfc6b0;
      background: rgba(24, 20, 32, 0.88);
      border: 1px solid rgba(201, 160, 80, 0.28);
      transition: transform 0.1s ease, border-color 0.15s ease, background 0.15s ease;
    }

    .rel-filter-pill:hover {
      border-color: rgba(244, 214, 140, 0.65);
      color: #fff2cc;
    }

    .rel-filter-pill.active {
      color: #140f08;
      background: linear-gradient(180deg, #f4d68c 0%, #c9a050 100%);
      border-color: #fff2cc;
      box-shadow: 0 0 12px rgba(244, 214, 140, 0.35);
    }

    /* Comparison Panel */
    .rel-compare-panel {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 8px;
      margin-bottom: 10px;
      padding: 8px 10px;
      border-radius: 6px;
      background: linear-gradient(180deg, rgba(26, 22, 34, 0.96), rgba(14, 12, 20, 0.98));
      border: 1px solid rgba(201, 160, 80, 0.42);
      box-shadow: inset 0 0 14px rgba(0, 0, 0, 0.55);
    }

    .rel-cmp-cell {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4px 6px;
      border-radius: 4px;
      background: rgba(0, 0, 0, 0.28);
      border: 1px solid rgba(255, 255, 255, 0.06);
      text-align: center;
    }

    .rel-cmp-lbl {
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.6px;
      color: #a9a1b8;
    }

    .rel-cmp-val {
      font-size: 18px;
      font-weight: 900;
      line-height: 1.2;
      color: #f6f1e7;
    }

    .rel-cmp-val.pos { color: #5effb1; text-shadow: 0 0 10px rgba(94, 255, 177, 0.35); }
    .rel-cmp-val.neg { color: #ff6b7a; }
    .rel-cmp-val.neu { color: #d6cba8; }

    /* Bag Category Divider */
    .rel-bag-group-hdr {
      grid-column: 1 / -1;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 4px 8px;
      margin-top: 4px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 800;
      letter-spacing: 0.7px;
      text-transform: uppercase;
      color: #e6bc5c;
      background: linear-gradient(90deg, rgba(201, 160, 80, 0.14), transparent);
      border-left: 2px solid #c9a050;
    }

    /* Base Reliquary Card */
    .rel-card {
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      gap: 8px;
      padding: 10px 10px 8px;
      border-radius: 7px;
      cursor: pointer;
      user-select: none;
      overflow: hidden;
      background: linear-gradient(165deg, #1b1724 0%, #100d15 100%);
      border: 1.5px solid #4a4554;
      transition: transform 0.14s ease, box-shadow 0.18s ease, border-color 0.18s ease, filter 0.15s ease;
    }

    .rel-card::before,
    .rel-card::after {
      content: '';
      position: absolute;
      pointer-events: none;
      border-radius: 5px;
    }

    .rel-card::before {
      inset: 3px;
      border: 1px solid rgba(255, 255, 255, 0.05);
    }

    .rel-card:hover {
      transform: translateY(-2px);
      filter: brightness(1.09);
    }

    .rel-card.empty-slot {
      cursor: pointer;
      border: 1px dashed rgba(180, 155, 102, 0.34);
      background: linear-gradient(165deg, rgba(22, 19, 29, 0.72), rgba(12, 10, 16, 0.85));
      min-height: 92px;
      justify-content: center;
    }

    .rel-card.empty-slot:hover {
      border-color: rgba(244, 214, 140, 0.72);
      transform: translateY(-1px);
    }

    /* Rarity Tiers */
    .rel-card.rel-rarity-common {
      border-color: #6d6976;
      background: linear-gradient(165deg, #211e28 0%, #131118 100%);
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.08), inset 0 -8px 16px rgba(0, 0, 0, 0.55);
    }
    .rel-card.rel-rarity-magic {
      border-color: #3f8ef7;
      background: radial-gradient(circle at 12% 14%, rgba(63, 142, 247, 0.18), transparent 54%), linear-gradient(165deg, #172034 0%, #0e1320 100%);
      box-shadow: 0 0 12px rgba(63, 142, 247, 0.22), inset 0 0 16px rgba(63, 142, 247, 0.14);
    }
    .rel-card.rel-rarity-rare {
      border-color: #e4b136;
      background: radial-gradient(circle at 15% 12%, rgba(228, 177, 54, 0.2), transparent 56%), linear-gradient(165deg, #272013 0%, #13100a 100%);
      box-shadow: 0 0 15px rgba(228, 177, 54, 0.28), inset 0 0 18px rgba(228, 177, 54, 0.14);
    }
    .rel-card.rel-rarity-legendary {
      border-color: #ff7e21;
      background: radial-gradient(circle at 16% 12%, rgba(255, 126, 33, 0.25), transparent 58%), linear-gradient(165deg, #2d1910 0%, #140c09 100%);
      box-shadow: 0 0 19px rgba(255, 126, 33, 0.38), inset 0 0 22px rgba(255, 112, 24, 0.18);
    }
    .rel-card.rel-rarity-mythic {
      border-color: #e24bff;
      background: radial-gradient(circle at 18% 12%, rgba(226, 75, 255, 0.26), transparent 58%), linear-gradient(165deg, #271330 0%, #120919 100%);
      box-shadow: 0 0 22px rgba(226, 75, 255, 0.42), inset 0 0 24px rgba(196, 52, 235, 0.24);
      animation: relMythicPulse 3.2s ease-in-out infinite;
    }

    @keyframes relMythicPulse {
      0%, 100% { box-shadow: 0 0 20px rgba(226, 75, 255, 0.38), inset 0 0 22px rgba(196, 52, 235, 0.22); }
      50% { box-shadow: 0 0 28px rgba(226, 75, 255, 0.58), inset 0 0 28px rgba(226, 75, 255, 0.3); }
    }

    /* Active Slot Filter Glow */
    .rel-card.rel-slot-filtering {
      border-color: #ffd700 !important;
      box-shadow:
        0 0 20px rgba(255, 215, 0, 0.5),
        inset 0 0 18px rgba(255, 215, 0, 0.22) !important;
    }

    /* Recommended Highest-Scoring Item Highlight */
    .rel-card.rel-recommended-card {
      box-shadow:
        0 0 18px rgba(94, 255, 177, 0.34),
        inset 0 0 16px rgba(94, 255, 177, 0.14);
    }

    .rel-rec-badge {
      display: inline-flex;
      align-items: center;
      gap: 3px;
      padding: 1px 6px;
      border-radius: 3px;
      font-size: 9.5px;
      font-weight: 800;
      letter-spacing: 0.35px;
      color: #69ffb8;
      background: rgba(16, 74, 48, 0.72);
      border: 1px solid rgba(94, 255, 177, 0.65);
      box-shadow: 0 0 8px rgba(94, 255, 177, 0.24);
      white-space: nowrap;
    }

    .rel-filtering-tag {
      display: inline-block;
      padding: 1px 5px;
      border-radius: 3px;
      font-size: 8.5px;
      font-weight: 800;
      letter-spacing: 0.5px;
      color: #140f08;
      background: #ffd700;
    }

    .rel-card.selected {
      outline: 2px solid #f7dc94;
      outline-offset: 1px;
      box-shadow: 0 0 22px rgba(247, 220, 148, 0.48), inset 0 0 18px rgba(247, 220, 148, 0.18);
    }

    .rel-card.restricted { opacity: 0.72; }
    .rel-card.locked-card {
      box-shadow: inset 0 0 0 1px rgba(244, 214, 140, 0.42), 0 0 14px rgba(244, 214, 140, 0.16);
    }

    .rel-card-top { display: flex; align-items: flex-start; gap: 10px; min-width: 0; position: relative; z-index: 1; }
    .rel-icon-pedestal {
      position: relative; display: flex; align-items: center; justify-content: center; flex-shrink: 0; border-radius: 6px;
      background: radial-gradient(circle at 50% 35%, rgba(255, 255, 255, 0.08), rgba(8, 7, 12, 0.92));
      border: 1.5px solid rgba(255, 255, 255, 0.2);
      box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.8), inset 0 -1px 0 rgba(255, 255, 255, 0.08);
    }
    .rel-card-meta { min-width: 0; flex: 1; display: flex; flex-direction: column; gap: 3px; }
    .rel-card-kicker {
      display: flex; align-items: center; justify-content: space-between; gap: 6px;
      font-size: 9.5px; letter-spacing: 0.65px; text-transform: uppercase; color: #a9a1b8;
    }
    .rel-item-name {
      font-weight: 700; font-size: 13px; line-height: 1.24; color: #f6f1e7;
      display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
      overflow: hidden; word-break: break-word; overflow-wrap: anywhere; min-height: 32px;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.85);
    }
    .rel-item-type { font-size: 10.5px; color: #b7aec7; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .rel-lock-seal {
      display: inline-flex; align-items: center; gap: 2px; padding: 1px 5px; border-radius: 3px;
      font-size: 9.5px; font-weight: 700; letter-spacing: 0.4px;
      background: rgba(244, 214, 140, 0.16); border: 1px solid rgba(244, 214, 140, 0.6); color: #f8dc94; cursor: pointer; flex-shrink: 0;
    }
    .rel-lock-seal.unlocked {
      background: rgba(255, 255, 255, 0.04); border-color: rgba(255, 255, 255, 0.12); color: #8f889e; opacity: 0.72;
    }
    .rel-lock-seal.unlocked:hover { opacity: 1; border-color: rgba(244, 214, 140, 0.5); color: #f4d68c; }

    .rel-card-footer {
      position: relative; z-index: 1; display: flex; align-items: center; justify-content: space-between; gap: 6px;
      padding-top: 6px; border-top: 1px solid rgba(255, 255, 255, 0.08);
    }
    .rel-score-wrap { display: flex; align-items: baseline; gap: 4px; }
    .rel-score-star { font-size: 14px; color: #e6bc5c; filter: drop-shadow(0 0 5px rgba(230, 188, 92, 0.45)); }
    .rel-score-val { font-size: 20px; font-weight: 900; line-height: 1; letter-spacing: 0.3px; color: #fae09b; text-shadow: 0 0 10px rgba(244, 214, 140, 0.35), 0 1px 2px #000; }

    .rel-upg-pill {
      display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: 800; letter-spacing: 0.3px;
      padding: 2px 7px; border-radius: 4px; white-space: nowrap; text-transform: uppercase;
    }
    .rel-upg-pill.better { color: #69ffb8; background: rgba(20, 84, 54, 0.55); border: 1px solid rgba(94, 255, 177, 0.55); }
    .rel-upg-pill.worse { color: #ff7b89; background: rgba(94, 22, 32, 0.55); border: 1px solid rgba(255, 107, 122, 0.5); }
    .rel-upg-pill.equal { color: #d6cba8; background: rgba(66, 59, 44, 0.5); border: 1px solid rgba(201, 160, 80, 0.38); }

    .rel-rarity-badge {
      font-size: 10px; font-weight: 700; letter-spacing: 0.6px; text-transform: uppercase;
      padding: 2px 6px; border-radius: 3px; border: 1px solid rgba(255, 255, 255, 0.14); background: rgba(0, 0, 0, 0.32);
    }

    #inv-modal .stat-pill {
      background: linear-gradient(180deg, rgba(28, 24, 36, 0.92), rgba(15, 13, 20, 0.96));
      border: 1px solid rgba(186, 148, 76, 0.32); border-radius: 6px; padding: 8px 10px;
    }

    #equipped-slots.rel-eq-grid .rel-card { min-height: 110px; }
    .rel-card.rel-card-compact { gap: 6px; padding: 8px 8px 7px; }
    .rel-card-compact .rel-card-top { gap: 8px; }
    .rel-card-compact .rel-card-kicker { font-size: 9px; letter-spacing: 0.5px; }
    .rel-card-compact .rel-item-name { font-size: 12.5px; min-height: 0; }
    .rel-card-compact .rel-item-type-full { position: relative; z-index: 1; font-size: 10px; color: #b7aec7; line-height: 1.25; overflow-wrap: anywhere; }
    .rel-card-compact .rel-score-val { font-size: 18px; }
    .rel-card.empty-slot .rel-empty-row { display: flex; align-items: center; gap: 8px; opacity: 0.72; min-width: 0; }

    .rel-set-row { display: flex; flex-wrap: wrap; gap: 5px; align-items: center; }
    .rel-set-title { width: 100%; font-size: 10px; font-weight: 700; letter-spacing: 0.8px; text-transform: uppercase; color: #c9a050; }
    .rel-set-chip { display: inline-flex; align-items: center; gap: 4px; padding: 2px 7px; border-radius: 4px; font-size: 11px; white-space: nowrap; color: #d9d0c0; background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(201, 160, 80, 0.28); }
    .rel-set-chip.active { color: #f8dc94; border-color: rgba(244, 214, 140, 0.6); background: rgba(201, 160, 80, 0.14); }
    .rel-relic-line { width: 100%; margin-top: 2px; font-size: 10.5px; color: #9d95ab; overflow-wrap: anywhere; }

    .rel-stat-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 4px 10px; }
    .rel-stat-cell { display: flex; align-items: baseline; gap: 5px; min-width: 0; font-size: 11.5px; line-height: 1.5; }
    .rel-stat-ico { flex-shrink: 0; width: 16px; text-align: center; }
    .rel-stat-lbl { color: #9d95ab; font-size: 10.5px; white-space: nowrap; }
    .rel-stat-val { margin-left: auto; color: #f6f1e7; font-weight: 700; white-space: nowrap; }

    #item-inspector.rel-inspector {
      margin-top: 10px;
      background: radial-gradient(circle at 8% 12%, rgba(201, 160, 80, 0.08), transparent 48%), linear-gradient(180deg, #1a1622 0%, #100d15 100%);
      border: 1.5px solid #755b2c; border-radius: 7px; padding: 12px;
      box-shadow: inset 0 0 24px rgba(0, 0, 0, 0.62);
    }

    .rel-lock-banner {
      display: flex; align-items: center; gap: 6px; margin-top: 8px; padding: 5px 9px; border-radius: 4px;
      font-size: 11px; font-weight: 700; letter-spacing: 0.3px; color: #fae09b;
      background: rgba(201, 160, 80, 0.14); border: 1px solid rgba(244, 214, 140, 0.45);
    }

    /* Responsive Mobile Portrait, Landscape & Tablet */
    @media (max-width: 760px) {
      #equipped-slots.rel-eq-grid { grid-template-columns: 1fr; }
      #bag-grid.rel-bag-grid { grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); max-height: 40dvh; }
      .rel-filter-pill { padding: 6px 10px; min-height: 34px; font-size: 11.5px; }
      .rel-cmp-val { font-size: 16px; }
    }
    @media (max-height: 540px) {
      #bag-grid.rel-bag-grid { max-height: 44dvh; }
      .rel-compare-panel { padding: 6px 8px; gap: 6px; }
    }
  `;
  document.head.appendChild(style);
}

function getRarityMeta(rarityKey) {
  const rar = RARITIES[rarityKey] || RARITIES.common;
  const theme = RARITY_THEMES[rarityKey] || RARITY_THEMES.common;
  return {
    key: rarityKey || 'common',
    name: rar.name || theme.label,
    color: rar.color || theme.accent,
    cls: theme.cls,
    rune: theme.rune
  };
}

function resolveUpgradeInfo(item, player, showUpgrade) {
  if (!showUpgrade || !item || !player) return null;
  const upg = getUpgradeIndicator(item, player);
  const eq = player.equipped?.[item.slot];
  let diff = upg?.diff;
  if (typeof diff !== 'number') {
    diff = eq ? scoreItem(item, player) - scoreItem(eq, player) : scoreItem(item, player);
  }
  if (diff > 0) return { label: '▲ Better', diffText: `+${diff}`, tone: 'better' };
  if (diff < 0) return { label: '▼ Worse', diffText: `${diff}`, tone: 'worse' };
  return { label: '◆ Equal', diffText: '0', tone: 'equal' };
}

function createIconPedestalHTML(icon, rarMeta, size = 46, fontSize = 27) {
  return `
    <div class="rel-icon-pedestal" style="width:${size}px;height:${size}px;font-size:${fontSize}px;border-color:${rarMeta.color};box-shadow:inset 0 2px 7px rgba(0,0,0,0.85), 0 0 12px ${rarMeta.color}33;text-shadow:0 0 10px ${rarMeta.color};">
      ${icon}
    </div>
  `;
}

function buildLockButtonHTML(locked) {
  return `<button
    type="button"
    class="rel-lock-seal ${locked ? '' : 'unlocked'}"
    data-lock-toggle="1"
    title="${locked ? 'Unlock item (allow salvage/sale)' : 'Lock item (protect from salvage/sale)'}"
  >${locked ? '🔒 Sealed' : '🔓'}</button>`;
}

function wireCardEvents(card, item, onClick, onQuickLock) {
  if (onQuickLock && item) {
    const lockBtn = card.querySelector('[data-lock-toggle]');
    if (lockBtn) {
      lockBtn.onclick = e => {
        e.stopPropagation();
        onQuickLock(item);
      };
    }
  }
  if (onClick) card.onclick = onClick;
  return card;
}

function createItemCard(
  item,
  { slot, selected = false, filtering = false, recommended = false, showUpgrade = false, isEquipped = false, onClick, onQuickLock } = {}
) {
  const p = state.player;
  if (!item) {
    const emptyCard = mk(
      'div',
      `rel-card empty-slot sans ${filtering ? 'rel-slot-filtering' : ''}`,
      `<div class="rel-empty-row">
         <div class="rel-icon-pedestal" style="width:40px;height:40px;font-size:21px;border-color:${filtering ? '#ffd700' : 'rgba(180,155,102,0.3)'};">
           ${getSlotIcon(slot)}
         </div>
         <div style="min-width:0;flex:1;">
           <div style="font-size:12px;font-weight:700;color:#cfc6b0;">${SLOT_LABELS[slot]}</div>
           <div style="font-size:10px;color:#857d93;letter-spacing:0.4px;text-transform:uppercase;">
             ${filtering ? '<span class="rel-filtering-tag">FILTERING</span>' : 'Click to Filter'}
           </div>
         </div>
       </div>`
    );
    return wireCardEvents(emptyCard, null, onClick, null);
  }

  const rarMeta = getRarityMeta(item.rarity);
  const icon = getItemIcon(item);
  const locked = isItemLocked(item);
  const score = scoreItem(item, p);
  const upg = resolveUpgradeInfo(item, p, showUpgrade);
  const allowed = canEquipItem(item, p);
  const typeLabel = item.subType || SLOT_LABELS[item.slot];
  const typeText = `${typeLabel}${item.ilvl ? ` • iLv ${item.ilvl}` : ''}`;

  const cardClasses = [
    'rel-card',
    isEquipped ? 'rel-card-compact' : '',
    'sans',
    rarMeta.cls,
    selected ? 'selected' : '',
    filtering ? 'rel-slot-filtering' : '',
    recommended ? 'rel-recommended-card' : '',
    allowed ? '' : 'restricted',
    locked ? 'locked-card' : ''
  ].filter(Boolean).join(' ');

  const topRightBadge = isEquipped
    ? (filtering ? '<span class="rel-filtering-tag">FILTERING</span>' : '')
    : buildLockButtonHTML(locked);

  const footerRight = isEquipped
    ? buildLockButtonHTML(locked)
    : upg
      ? `<span class="rel-upg-pill ${upg.tone}" title="Score delta: ${upg.diffText}">${upg.label}</span>`
      : `<span class="rel-rarity-badge" style="color:${rarMeta.color};border-color:${rarMeta.color}55;">${rarMeta.name}</span>`;

  const recBadgeHTML = recommended ? `<span class="rel-rec-badge">⭐ Recommended</span>` : '';

  const card = mk(
    'div',
    cardClasses,
    `
      <div class="rel-card-top">
        ${createIconPedestalHTML(icon, rarMeta, isEquipped ? 40 : 46, isEquipped ? 23 : 27)}
        <div class="rel-card-meta">
          <div class="rel-card-kicker">
            <span style="color:${rarMeta.color};font-weight:700;">${rarMeta.rune} ${rarMeta.name}</span>
            ${topRightBadge}
          </div>
          <div class="rel-item-name" title="${item.name}">${item.name}</div>
          ${!isEquipped ? `<div class="rel-item-type">${typeText}</div>` : ''}
        </div>
      </div>
      ${isEquipped ? `<div class="rel-item-type-full" title="${typeText}">${typeText}</div>` : ''}
      ${recBadgeHTML ? `<div style="position:relative;z-index:1;">${recBadgeHTML}</div>` : ''}
      <div class="rel-card-footer">
        <div class="rel-score-wrap" title="Item Score: ${score}">
          <span class="rel-score-star">★</span>
          <span class="rel-score-val">${score}</span>
        </div>
        ${footerRight}
      </div>
    `
  );

  return wireCardEvents(card, item, onClick, onQuickLock);
}

function syncSelectionAfterBagMutation() {
  const p = state.player;
  if (!p || !selItem || selSource === 'eq') return;
  const idx = p.bag.indexOf(selItem);
  if (idx === -1) clearSelectedItem();
  else selSource = idx;
}

function runBulkBagAction(actionType, predicate = () => true) {
  const p = state.player;
  if (!p || !p.bag?.length) return;

  for (let i = p.bag.length - 1; i >= 0; i--) {
    const item = p.bag[i];
    if (!item || isItemLocked(item) || !predicate(item)) continue;
    if (actionType === 'salvage') salvageItem(item, i);
    else if (actionType === 'sell') sellItem(item, i);
  }

  sortBag(p);
  syncSelectionAfterBagMutation();
  renderInventory();
  updateHud();
}

function setupBulkActionBar(headerBtns) {
  headerBtns.classList.add('rel-bulk-bar');
  renderBulkActionButtons(headerBtns, () => {
    syncSelectionAfterBagMutation();
    renderInventory();
    updateHud();
  });

  const existingTexts = Array.from(headerBtns.querySelectorAll('button')).map(b =>
    b.textContent.trim().toLowerCase()
  );

  const bulkDefinitions = [
    { id: 'btn-rel-salvage-all', label: 'Salvage All', match: /^salvage\s*all$/i, cls: 'rel-btn-ornate danger', title: 'Salvage all unlocked items in your pack', action: () => runBulkBagAction('salvage') },
    { id: 'btn-rel-sell-all', label: 'Sell All', match: /^sell\s*all$/i, cls: 'rel-btn-ornate gold-accent', title: 'Sell all unlocked items in your pack', action: () => runBulkBagAction('sell') },
    { id: 'btn-rel-sell-common', label: 'Sell All Common', match: /sell.*common/i, cls: 'rel-btn-ornate', title: 'Sell all unlocked Common items', action: () => runBulkBagAction('sell', it => it.rarity === 'common') },
    { id: 'btn-rel-sell-magic', label: 'Sell All Magic', match: /sell.*magic/i, cls: 'rel-btn-ornate', title: 'Sell all unlocked Magic items', action: () => runBulkBagAction('sell', it => it.rarity === 'magic') }
  ];

  const closeBtn = headerBtns.querySelector('#btn-close-inv');
  for (const def of bulkDefinitions) {
    if (existingTexts.some(t => def.match.test(t)) || headerBtns.querySelector(`#${def.id}`)) continue;
    const btn = mk('button', def.cls, def.label);
    btn.id = def.id;
    btn.type = 'button';
    btn.title = def.title;
    btn.onclick = def.action;
    headerBtns.appendChild(btn);
  }
  if (closeBtn) {
    closeBtn.style.order = '99';
    headerBtns.appendChild(closeBtn);
  }
}

function ensureFilterAndCompareContainers() {
  const bagEl = DOM['bag-grid'];
  if (!bagEl || !bagEl.parentNode) return {};

  let filterWrap = document.getElementById('rel-filter-wrap');
  if (!filterWrap) {
    filterWrap = mk('div', 'rel-filter-wrap sans');
    filterWrap.id = 'rel-filter-wrap';
    bagEl.parentNode.insertBefore(filterWrap, bagEl);
  }

  let comparePanel = document.getElementById('rel-compare-panel');
  if (!comparePanel) {
    comparePanel = mk('div', 'rel-compare-panel sans');
    comparePanel.id = 'rel-compare-panel';
    bagEl.parentNode.insertBefore(comparePanel, bagEl);
  }

  return { filterWrap, comparePanel };
}

function getEquippedReferenceItem(p, category) {
  if (!p || !category || category === 'all') return null;
  if (category === 'ring') {
    if (preferredEqSlot === 'ring2' && p.equipped.ring2) return p.equipped.ring2;
    if (preferredEqSlot === 'ring1' && p.equipped.ring1) return p.equipped.ring1;
    const r1 = p.equipped.ring1;
    const r2 = p.equipped.ring2;
    if (r1 && r2) return scoreItem(r1, p) <= scoreItem(r2, p) ? r1 : r2;
    return r1 || r2 || null;
  }
  return p.equipped[category] || null;
}

function renderFilterAndComparison(org) {
  const p = state.player;
  const { filterWrap, comparePanel } = ensureFilterAndCompareContainers();
  if (!filterWrap || !comparePanel || !p) return;

  const active = org.activeFilter;
  filterWrap.innerHTML = '';

  if (active !== 'all') {
    const label = FILTER_DISPLAY_NAMES[active] || active;
    const catCount = org.countsByCategory[active] || 0;
    const banner = mk(
      'div',
      'rel-filter-banner',
      `<div class="rel-filter-title">◈ Filtering: <span>${label}</span> <span style="opacity:.75;font-weight:600;">(${catCount})</span></div>
       <button type="button" class="rel-btn-ornate gold-accent" id="btn-clear-slot-filter" style="padding:5px 11px;border-radius:4px;font-weight:800;font-size:11px;">✕ Clear Filter</button>`
    );
    banner.querySelector('#btn-clear-slot-filter').onclick = () => {
      setSlotFilter('all');
      preferredEqSlot = null;
      renderInventory();
    };
    filterWrap.appendChild(banner);
  }

  // Category quick-filter pills (supports Desktop, Portrait & Landscape, including Relics)
  const pillsRow = mk('div', 'rel-filter-pills');
  const addPill = (id, text, count) => {
    const pill = mk('button', `rel-filter-pill ${active === id ? 'active' : ''}`, `${text} (${count})`);
    pill.type = 'button';
    pill.onclick = () => {
      setSlotFilter(active === id ? 'all' : id);
      if (getSlotFilter() === 'all') preferredEqSlot = null;
      renderInventory();
    };
    pillsRow.appendChild(pill);
  };

  addPill('all', 'All', org.totalCount);
  for (const cat of INVENTORY_CATEGORIES) {
    addPill(cat.id, `${cat.icon} ${cat.filterLabel}`, org.countsByCategory[cat.id] || 0);
  }
  filterWrap.appendChild(pillsRow);

  // Comparison Panel when filtering a category
  if (active === 'all') {
    comparePanel.style.display = 'none';
    return;
  }

  comparePanel.style.display = 'grid';
  const curItem = getEquippedReferenceItem(p, active);
  const curScore = curItem ? scoreItem(curItem, p) : 0;

  const bagTarget =
    selSource !== 'eq' && selItem && getSlotCategory(selItem) === active
      ? selItem
      : org.recommendedByCategory.get(active) || org.entries[0]?.item || null;

  const selScore = bagTarget ? scoreItem(bagTarget, p) : null;
  const diff = selScore !== null ? selScore - curScore : null;
  const diffCls = diff === null ? 'neu' : diff > 0 ? 'pos' : diff < 0 ? 'neg' : 'neu';
  const diffText = diff === null ? '—' : diff > 0 ? `+${diff}` : `${diff}`;
  const selLabel =
    bagTarget && bagTarget !== selItem
      ? 'Recommended'
      : 'Selected';

  comparePanel.innerHTML = `
    <div class="rel-cmp-cell">
      <div class="rel-cmp-lbl">Current</div>
      <div class="rel-cmp-val">${curItem ? curScore : '—'}</div>
    </div>
    <div class="rel-cmp-cell">
      <div class="rel-cmp-lbl">${selLabel}</div>
      <div class="rel-cmp-val">${selScore !== null ? selScore : '—'}</div>
    </div>
    <div class="rel-cmp-cell">
      <div class="rel-cmp-lbl">Difference</div>
      <div class="rel-cmp-val ${diffCls}">${diffText}</div>
    </div>
  `;
}

export function clearSelectedItem() {
  selItem = null;
  selSource = null;
}

export function initInventoryUI() {
  ensureReliquaryStyles();
  clearSelectedItem();
  setSlotFilter('all');
  preferredEqSlot = null;

  const headerBtns = DOM['inv-modal']?.querySelector('.modal-header .flex-row');
  if (headerBtns) setupBulkActionBar(headerBtns);

  DOM['equipped-slots']?.classList.add('rel-eq-grid');
  DOM['bag-grid']?.classList.add('rel-bag-grid');
  DOM['item-inspector']?.classList.add('rel-inspector');
}

function renderInspector(recommendedSet) {
  const box = DOM['item-inspector'];
  const p = state.player;
  if (!box || !p) return;

  if (!selItem) {
    box.style.borderColor = '#755b2c';
    box.innerHTML =
      '<div style="color:var(--ash);font-size:12px;">✦ Click an equipped slot to filter its category, or select any item to inspect & compare.</div>';
    return;
  }

  const isEq = selSource === 'eq';
  const rarMeta = getRarityMeta(selItem.rarity);
  const icon = getItemIcon(selItem);
  const locked = isItemLocked(selItem);
  const score = scoreItem(selItem, p);
  const upg = resolveUpgradeInfo(selItem, p, !isEq);
  const allowed = canEquipItem(selItem, p);
  const sellVal = getItemSellValue(selItem);
  const isRec = !isEq && recommendedSet?.has(selItem);

  let html = `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap;">
      <div style="display:flex;align-items:flex-start;gap:11px;flex:1;min-width:200px;">
        ${createIconPedestalHTML(icon, rarMeta, 54, 31)}
        <div style="min-width:0;flex:1;">
          <div style="color:#f6f1e7;font-weight:800;font-size:15px;line-height:1.25;white-space:normal;word-break:break-word;">
            ${locked ? '🔒 ' : ''}${selItem.name}
          </div>
          <div style="font-size:11.5px;color:${rarMeta.color};font-weight:700;margin-top:3px;">
            ${rarMeta.rune} ${rarMeta.name} • ${SLOT_LABELS[selItem.slot]}${selItem.subType ? ` (${selItem.subType})` : ''} • iLv ${selItem.ilvl}
          </div>
          ${isRec ? '<div style="margin-top:4px;"><span class="rel-rec-badge">⭐ Recommended</span></div>' : ''}
        </div>
      </div>
      <div class="flex-row" style="gap:10px;flex-shrink:0;align-items:center;">
        <div class="rel-score-wrap" style="padding:4px 9px;border-radius:5px;background:rgba(0,0,0,0.35);border:1px solid rgba(244,214,140,0.28);">
          <span class="rel-score-star" style="font-size:16px;">★</span>
          <span class="rel-score-val" style="font-size:22px;">${score}</span>
        </div>
        ${upg ? `<span class="rel-upg-pill ${upg.tone}" style="font-size:12px;padding:4px 9px;">${upg.label} (${upg.diffText})</span>` : ''}
      </div>
    </div>`;

  if (locked) {
    html += `<div class="rel-lock-banner sans">🔒 SEALED RELIC — Locked items cannot be sold or salvaged.</div>`;
  }
  if (selItem.set) {
    html += `<div class="sans" style="font-size:11.5px;color:#5effb1;margin-top:8px;">✦ Set: ${SETS[selItem.set] || selItem.set}</div>`;
  }

  html += `<div class="sans" style="display:flex;flex-wrap:wrap;gap:5px;margin:9px 0;">${formatCompactTags(selItem)}</div>`;

  if (selItem.unique) {
    html += `<div class="sans" style="font-size:12px;color:#ffd089;background:rgba(255,140,0,0.12);padding:6px 9px;border-left:2px solid #ff8c00;margin-bottom:7px;">✦ ${selItem.unique.power}</div>`;
  }
  if (!isEq && !allowed) {
    html += `<div class="sans" style="font-size:11.5px;color:#ff5b6c;margin-bottom:7px;">✖ ${p.cls.name} cannot equip ${selItem.subType}</div>`;
  }

  const dis = 'disabled style="opacity:.42;cursor:not-allowed;"';
  html += `
    <div class="flex-row" style="gap:8px;margin-top:9px;flex-wrap:wrap;">
      <button class="${locked ? 'btn-gold' : 'rel-btn-ornate'}" id="lock-now">${locked ? '🔓 Unlock Item' : '🔒 Lock Item'}</button>
      ${
        isEq
          ? ''
          : `<button class="btn-gold" id="eq-now" ${allowed ? '' : dis}>Equip</button>
             <button class="btn-dark" id="sell-now" ${locked ? dis : ''}>Sell (+${sellVal}G)</button>
             <button class="btn-dark" id="sal-now" ${locked ? dis : ''}>Salvage</button>`
      }
    </div>`;

  box.style.borderColor = rarMeta.color;
  box.innerHTML = html;

  const actions = [
    ['#lock-now', () => { toggleLockItem(selItem); renderInventory(); }],
    ['#eq-now', !isEq && allowed ? () => {
      const equipped = equipBagItem(selItem, selSource);
      if (equipped) {
        selItem = equipped;
        selSource = 'eq';
      }
      renderInventory();
      updateHud();
    } : null],
    ['#sell-now', !isEq && !locked ? () => {
      if (sellItem(selItem, selSource)) clearSelectedItem();
      renderInventory();
      updateHud();
    } : null],
    ['#sal-now', !isEq && !locked ? () => {
      if (salvageItem(selItem, selSource)) clearSelectedItem();
      renderInventory();
      updateHud();
    } : null]
  ];

  for (const [sel, fn] of actions) {
    const btn = box.querySelector(sel);
    if (btn && fn) btn.onclick = fn;
  }
}

export function renderInventory() {
  ensureReliquaryStyles();
  const p = state.player;
  if (!p) return;

  sortBag(p);
  const org = organizeInventory(p.bag, { slotFilter: getSlotFilter(), player: p, sort: true });
  const activeFilter = org.activeFilter;

  const eqEl = DOM['equipped-slots'];
  const bagEl = DOM['bag-grid'];
  eqEl.innerHTML = '';
  bagEl.innerHTML = '';

  const handleQuickLock = item => {
    toggleLockItem(item);
    renderInventory();
  };

  SLOTS.forEach(sl => {
    const it = p.equipped[sl];
    const slCat = getSlotCategory(sl);
    const isFilteringSlot = activeFilter === slCat;

    eqEl.appendChild(
      createItemCard(it, {
        slot: sl,
        isEquipped: true,
        filtering: isFilteringSlot,
        selected: selItem === it && Boolean(it),
        onClick: () => {
          preferredEqSlot = sl;
          const nextFilter = isFilteringSlot && (!it || selItem === it) ? 'all' : slCat;
          setSlotFilter(nextFilter);
          if (nextFilter === 'all') preferredEqSlot = null;
          if (it) {
            selItem = it;
            selSource = 'eq';
          }
          renderInventory();
        },
        onQuickLock: handleQuickLock
      })
    );
  });

  const s = p.stats;
  const relNames =
    metaSave.equippedRelics
      .map(id => RELICS.find(r => r.id === id)?.name)
      .filter(Boolean)
      .join(', ') || 'None';

  const setChip = (label, n) =>
    `<span class="rel-set-chip ${n > 0 ? 'active' : ''}">${label} <b>${n}/6</b></span>`;
  const relicCount = metaSave.equippedRelics.length;

  DOM['set-bonuses-box'].innerHTML =
    `<div class="rel-set-row">` +
    `<div class="rel-set-title">✦ Set Bonuses</div>` +
    setChip('Ashen', s.sets.ashenking || 0) +
    setChip('Choir', s.sets.choir || 0) +
    `<span class="rel-set-chip ${relicCount > 0 ? 'active' : ''}">Relics <b>${relicCount}/3</b></span>` +
    `<div class="rel-relic-line">${relNames}</div>` +
    `</div>`;

  const statCell = (ico, lbl, val, tip = '') =>
    `<div class="rel-stat-cell" ${tip ? `title="${tip}"` : ''}>` +
    `<span class="rel-stat-ico">${ico}</span><span class="rel-stat-lbl">${lbl}</span><span class="rel-stat-val">${val}</span></div>`;

  DOM['char-stats-box'].innerHTML =
    `<div class="rel-set-title" style="margin-bottom:5px;">✦ Attributes</div>` +
    `<div class="rel-stat-grid">` +
    statCell('⚔', 'Damage', Math.round(s.flatDmg * s.dmgPct)) +
    statCell('⚡', 'Atk Speed', `${Math.round(s.atkSpeed * 100)}%`) +
    statCell('🎯', 'Crit', `${Math.round(s.critChance * 100)}%`, 'Crit chance') +
    statCell('💥', 'Crit Dmg', `${Math.round(s.critDmg * 100)}%`) +
    statCell('🛡', 'Armor', s.armor) +
    statCell('🩸', 'Lifesteal', `${Math.round(s.lifeSteal * 100)}%`) +
    statCell('🧲', 'Pickup', Math.round(s.pickupRadius)) +
    statCell('✦', 'Projectiles', `+${s.projBonus}`) +
    `</div>`;

  DOM['bag-count'].textContent =
    activeFilter === 'all' ? p.bag.length : `${org.entries.length}/${p.bag.length}`;
  DOM['gem-count'].textContent = p.gemsCount;

  renderFilterAndComparison(org);

  if (!org.entries.length) {
    bagEl.appendChild(
      mk(
        'div',
        'sans',
        `<div style="grid-column:1/-1;padding:24px 12px;text-align:center;color:#9d95ab;font-size:12px;">
          ${activeFilter === 'all' ? 'Your pack is empty.' : `No ${FILTER_DISPLAY_NAMES[activeFilter] || activeFilter} in your pack.`}
        </div>`
      )
    );
  } else {
    for (const grp of org.groups) {
      if (activeFilter === 'all') {
        bagEl.appendChild(
          mk('div', 'rel-bag-group-hdr sans', `<span>${grp.icon} ${grp.label}</span><span>${grp.entries.length}</span>`)
        );
      }
      for (const entry of grp.entries) {
        bagEl.appendChild(
          createItemCard(entry.item, {
            slot: entry.item.slot,
            selected: selItem === entry.item,
            recommended: entry.recommended,
            showUpgrade: true,
            onClick: () => {
              selItem = entry.item;
              selSource = entry.bagIndex;
              renderInventory();
            },
            onQuickLock: handleQuickLock
          })
        );
      }
    }
  }

  renderInspector(org.recommendedSet);
}