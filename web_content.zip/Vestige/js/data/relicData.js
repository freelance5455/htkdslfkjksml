import { unpack } from '../core/utilities.js';

export const RELICS = unpack([
  ['cinderheart',   'Cinderheart Brand',    '+45% All Damage',                  '-25% Max Health',          { ash: 8, flame: 1 },   s => { s.dmgPct += 0.45; s.maxHpMult -= 0.25; }],
  ['obsidianpact',  'Obsidian Pact',        '+30 Armor & +5 HP/s Regen',        '-20% Movement Speed',      { ash: 10 },            s => { s.armor += 30; s.regen += 5; s.moveSpeedMult -= 0.20; }],
  ['bloodchalice',  'Bloodstained Chalice', '+10% Life Steal & +35% Crit Dmg',  'Passive Regen Disabled',   { ash: 12, flame: 2 },  s => { s.lifeSteal += 0.10; s.critDmg += 0.35; s.noRegen = 1; }],
  ['hourglass',     'Shattered Hourglass',  '+22% CDR & +25% Attack Speed',     '+20% Enemy Damage Taken',  { ash: 12, star: 2 },   s => { s.cdr += 0.22; s.atkSpeed += 0.25; s.dmgTakenMult += 0.20; }],
  ['voidlodestone', 'Void Lodestone',       '+60% XP Gain & +45% Pickup Radius','+25% Enemy Speed',         { ash: 10, void: 2 },   s => { s.xpGain += 0.60; s.pickupBonus += 0.45; s.enemySpdAdd += 0.25; }],
  ['astralmirror',  'Astral Mirror',        '+2 Projectiles',                   '-25% Hit Damage',          { star: 3, void: 1 },   s => { s.projBonus += 2; s.dmgPct -= 0.25; }],
  ['ruincrown',     'Crown of Ruin',        '+80% Drop Luck & +35% Rewards',    '-15 Armor & +15% Enemy HP',{ flame: 2, void: 2 },  s => { s.armor -= 15; s.relicLuck += 0.80; s.relicReward += 0.35; s.enemyHpAdd += 0.15; }]
], ['id', 'name', 'pro', 'con', 'cost', 'apply']);

export const RELIQUARY_UNLOCKS = unpack([
  ['evo_surge',     'Evolution',  'Primordial Awakening',  'Evolved weapons deal +25% bonus damage & +10% Area.',          { flame: 3, ash: 15 }],
  ['evo_catalyst',  'Evolution',  'Relic Conduit',         'Evolution Catalysts appear 2x more often on Level Up.',       { star: 3, ash: 12 }],
  ['boss_echo',     'Boss Hunt',  'Awakened Fallen Lords', 'Bosses gain +30% HP & drop +2 bonus Flame/Void/Star Frags.', { flame: 4, void: 2 }],
  ['tree_start',    'Skill Tree', 'Ancestral Memory',      '+2 Starting Passive Skill Points every run.',                 { star: 4, ash: 15 }],
  ['tree_keystone', 'Skill Tree', 'Keystone Resonance',    '+12% Damage for every allocated Keystone.',                   { star: 5, void: 2 }],
  ['dng_crypt',     'Dungeon',    'Crypt of Ash',          'Realm +45% Ash Fragments & +25% Enemy HP.',                  { ash: 14 }],
  ['dng_spire',     'Dungeon',    'Celestial Spire',       'Realm +60% Star Fragments & +20% Boss Speed.',               { star: 3, ash: 10 }],
  ['dng_rift',      'Dungeon',    'The Void Rift',         'Realm +60% Void Fragments, +35% Elites & +25% Drop Luck.',   { void: 3, ash: 10 }],
  ['dng_abyss',     'Dungeon',    'Endless Sanctum',       'Endgame Ancient Bosses, +35% All Fragments & +30% Enemy HP.',{ flame: 5, void: 4, star: 4 }]
], ['id', 'cat', 'name', 'desc', 'cost']);

export const META_UPGRADES_DEF = unpack([
  ['m_hp',     'Ashen Vitality',     '+15 Max Health per rank',         8, 15, 'shards'],
  ['m_dmg',    'Ember Might',        '+6% Damage per rank',             8, 18, 'shards'],
  ['m_armor',  'Iron Resolve',       '+3 Starting Armor per rank',      6, 16, 'shards'],
  ['m_xp',     'Memory of Kings',    '+10% XP Gain per rank',           6, 20, 'shards'],
  ['m_luck',   'Pilgrim Fortune',    '+15% Rare/Mythic Luck per rank',  5, 25, 'shards'],
  ['m_magnet', 'Lodestone Resonance','+12% Pickup Radius per rank',     5, 16, 'shards'],
  ['m_tree',   'Echoing Wisdom',     '+1 Starting Tree Point per rank', 4, 3,  'essence']
], ['id', 'name', 'desc', 'max', 'baseCost', 'cur']);