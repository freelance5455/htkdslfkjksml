import { unpack } from '../core/utilities.js';

export const BossScalingConfig = {
  mini:    { hpMult: 26,  dmgMult: 1.65, spd: 96, r: 32, xp: 32,  gold: 55,  shards: 8,  essence: 1, frags: { ash: 3 },                 rarity: 'rare',      luck: 1.0, introDur: 0 },
  major:   { hpMult: 64,  dmgMult: 2.35, spd: 88, r: 52, xp: 60,  gold: 120, shards: 18, essence: 2, frags: { flame: 1 },               rarity: 'legendary', luck: 1.2, introDur: 1.6, deathDur: 1.4, stdCd: 68, apocCd: 42, rushCd: 48 },
  ancient: { hpMult: 105, dmgMult: 2.85, spd: 94, r: 64, xp: 95,  gold: 210, shards: 30, essence: 3, frags: { flame: 2, star: 1 },      rarity: 'mythic',    luck: 1.6, introDur: 1.8, deathDur: 1.5 },
  secret:  { hpMult: 125, dmgMult: 3.1,  spd: 98, r: 62, xp: 120, gold: 280, shards: 40, essence: 4, frags: { void: 3, star: 2, flame: 2 }, rarity: 'mythic', luck: 2.0, introDur: 1.8, deathDur: 1.6 }
};

export const FACTIONS = {
  throne:   { name: 'The Golden Throne',    color: '#e6b84c', pool: ['knight', 'cultist'] },
  hollow:   { name: 'The Hollow Communion', color: '#7ed6df', pool: ['walker', 'beast', 'cultist'] },
  choir:    { name: 'The Celestial Choir',  color: '#8fa8ff', pool: ['cultist', 'walker'] },
  covenant: { name: 'The Iron Covenant',    color: '#e056fd', pool: ['knight', 'beast'] },
  veiled:   { name: 'The Veiled Court',     color: '#ff4757', pool: ['cultist', 'beast', 'knight'] }
};

export const BOSSES = unpack([
  ['godrick',      'Godrick the Fallen Flamebearer', 'throne',   '#ff9f43', 52, 'Last king of the Golden Throne. He tore a Flame Fragment into his own chest rather than watch his crown turn to ash.', 0],
  ['astrea',       'The Choir Saint Astrea',         'choir',    '#70a1ff', 48, 'A prophet consumed by forbidden starlight. Her hymns shatter the minds of those who still cling to dawn.', 0],
  ['colossus',     'The Ash Colossus',               'covenant', '#a4b0be', 64, 'Forged of black temple stone, forever waiting beside a shattered gate for a monarch who died ten centuries ago.', 0],
  ['matriarch',    'The Weeping Matriarch',          'hollow',   '#7bed9f', 50, 'Mother of a forgotten dynasty. She cradles the bone-relics of seven kingdoms beneath the catacombs.', 0],
  ['nameless',     'The Nameless Star',              'veiled',   '#ff2a4b', 58, 'An imprisoned cosmic deity chained beneath the Observatory before time itself was measured.', 0],
  ['vaelor',       'Vaelor, the Sundered Architect', 'veiled',   '#f368e0', 62, 'Secret Lord who fractured the First Flame into four elemental shards to sever mortal destiny from divine law.', 1],
  ['remnant_echo', 'The First Remnant',              'throne',   '#ffd700', 56, 'Secret Echo of the very first traveler who walked the Ashen Expanse and refused to fade.', 1]
], ['id', 'name', 'faction', 'color', 'r', 'lore', 'secret']);

export const ELITE_MODS = unpack([
  ['frozen',      'Frozen',      '#70a1ff'],
  ['stormbound',  'Stormbound',  '#8ec5ff'],
  ['corrupted',   'Corrupted',   '#833471'],
  ['voidtouched', 'Voidtouched', '#a55eea'],
  ['vampiric',    'Vampiric',    '#e03c4f'],
  ['burning',     'Burning',     '#ff7f50'],
  ['shielded',    'Shielded',    '#ffd700'],
  ['hasted',      'Hasted',      '#2ed573'],
  ['arcane',      'Arcane',      '#c56cf0']
], ['id', 'name', 'color']);