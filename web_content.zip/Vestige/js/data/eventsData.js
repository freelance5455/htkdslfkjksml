import { unpack } from '../core/utilities.js';

export const NPCS = [
  {
    name: 'Vaelen, the Ash Pilgrim',
    quote: 'Many seek the Flame. Few survive its truth.',
    body: 'A hooded wanderer kneels beside a cracked sun-statue. He offers a choice of pilgrimage.',
    choices: [
      ['Accept his Oath of Cinders (+25% Damage, +15% Enemy Speed)', 'pilgrim_oath'],
      ['Share your warmth (+35 Max HP & Full Heal)', 'pilgrim_mercy'],
      ['Demand his relics (Spawn Champion Pack for Guaranteed Legendary)', 'pilgrim_betray']
    ]
  },
  {
    name: 'Isolde, Blind Seeress of the Choir',
    quote: 'The stars are silent tonight. That is when they whisper loudest.',
    body: 'Silver tears streak her blindfold. She hears the Nameless Star stirring beneath the ruins.',
    choices: [
      ['Gaze into the Starlight (+18% Crit Chance & +2 Passive Skill Points)', 'seer_gaze'],
      ['Silence her visions (+100 Soul Shards & +20% Area Size)', 'seer_silence']
    ]
  },
  {
    name: 'Kaelen, Hollowed Smith',
    quote: 'The dead are not sleeping. They are remembering.',
    body: 'An iron anvil hums with ancient heat in the middle of the wasteland.',
    choices: [
      ['Temper your Equipped Weapon (+12 Flat Damage & +15% Atk Speed)', 'smith_temper'],
      ['Forge a Mythic Catalyst (+1 Projectile & +2 Ancient Essence)', 'smith_catalyst']
    ]
  }
];

export const MERCHANT_ENC = {
  name: 'Orin, Ashen Reliquary Merchant',
  quote: 'Gold buys steel, Remnant. Ash buys tomorrow.',
  body: 'A hunched peddler unpacks glowing curiosities beside a lantern of blue fire.',
  choices: [
    ['Purchase Tempering Draught (+18% Damage & +10% Atk Spd — 55 Gold)', 'orin_draught'],
    ['Purchase Relic Coffer (Guaranteed Rare/Legendary Gear — 85 Gold)', 'orin_coffer'],
    ['Purchase Fragment Satchel (+2 Random Fragments — 75 Gold)', 'orin_frags'],
    ['Depart in Silence', 'orin_leave']
  ]
};

export const WORLD_EVENTS = unpack([
  ['shrine',   'Ancient Shrine',      '#8ec5ff'],
  ['vault',    'Reliquary Vault',     '#ffd700'],
  ['merchant', 'Wandering Merchant',  '#5effb1'],
  ['goblin',   'Goblin Portal',       '#f6b93b'],
  ['altar',    'Cursed Altar',        '#ff4757'],
  ['monument', 'Forgotten Monument',  '#c56cf0'],
  ['npc',      'Lost Pilgrim',        '#c9a050'],
  ['special',  'Eclipse Seal (Boss)', '#f368e0']
], ['kind', 'label', 'color']);

export const ENDINGS_DATA = [
  {
    id: 'ending_flame',
    name: 'Age of Flame',
    desc: 'Rekindle the First Flame and restore divine order.',
    text: 'You rekindled the First Flame. Order returns to scarred marble—until the next cycle of ember and hubris.',
    req: { tier: 5, frag: 'flame', amt: 50, bosses: 10 }
  },
  {
    id: 'ending_stars',
    name: 'Age of Stars',
    desc: 'Ascend beyond mortality into the cold cosmos.',
    text: 'You bore the Flame beyond the sky, leaving mortal fate to the cold wisdom of the cosmos.',
    req: { tier: 5, frag: 'star', amt: 50, bosses: 0 }
  },
  {
    id: 'ending_ash',
    name: 'Age of Ash',
    desc: 'Let the embers fade and grant the realm eternal rest.',
    text: 'You let the embers die. Soft gray snow covers every throne and grave alike, granting peace to a weary world.',
    req: { tier: 5, frag: 'ash', amt: 50, bosses: 0 }
  },
  {
    id: 'ending_silence',
    name: 'Age of Silence',
    desc: 'Shatter divinity forever so mortals walk alone.',
    text: 'You shattered the Flame forever. No gods whisper now; humanity stands alone beneath an empty heaven.',
    req: { tier: 5, frag: 'void', amt: 50, bosses: 0 }
  }
];