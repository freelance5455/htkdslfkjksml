import { dailyIndex } from '../core/config.js';
import { unpack } from '../core/utilities.js';

export const WorldTierConfig = {
  tiers: [
    null,
    { id: 1, roman: 'I',   name: 'Pilgrim',     hp: 1.0,  dmg: 1.0,  spd: 1.0,  dens: 1.0,  luck: 0.0,  ancient: 0.04, reward: 1.0,  frag: 1.0,  eliteAdd: 0,    champAdd: 0 },
    { id: 2, roman: 'II',  name: 'Remnant',     hp: 1.65, dmg: 1.4,  spd: 1.06, dens: 1.12, luck: 0.28, ancient: 0.08, reward: 1.25, frag: 1.3,  eliteAdd: 0.03, champAdd: 0.02 },
    { id: 3, roman: 'III', name: 'Ascendant',   hp: 2.55, dmg: 1.9,  spd: 1.12, dens: 1.25, luck: 0.58, ancient: 0.12, reward: 1.55, frag: 1.65, eliteAdd: 0.06, champAdd: 0.05 },
    { id: 4, roman: 'IV',  name: 'Vestige',     hp: 3.8,  dmg: 2.55, spd: 1.18, dens: 1.4,  luck: 0.9,  ancient: 0.16, reward: 1.95, frag: 2.1,  eliteAdd: 0.10, champAdd: 0.08 },
    { id: 5, roman: 'V',   name: 'Flamebearer', hp: 5.5,  dmg: 3.35, spd: 1.25, dens: 1.58, luck: 1.3,  ancient: 0.22, reward: 2.45, frag: 2.7,  eliteAdd: 0.15, champAdd: 0.12 }
  ]
};

export const DifficultyConfig = {
  timeHpRate: 0.045,
  timeHpExp: 1.52,
  timeDmgRate: 0.018,
  timeSpdRate: 0.0014,
  maxTimeSpd: 1.48,
  lvlHp: 0.08,
  lvlDmg: 0.05,
  lvlSpd: 0.01,
  lvlDens: 0.025,
  bossHp: 0.22,
  bossDmg: 0.14,
  bossSpd: 0.04,
  bossDens: 0.08,
  apoc: { hp: 2.35, dmg: 1.65, spd: 1.2, dens: 1.65, eliteBonus: 0.22, rewardMult: 1.5, luckBonus: 0.75 },
  phases: [
    { min: 0,   max: 60,  name: 'Foundation',          hp: 1.0,  dmg: 1.0,  spd: 1.0,  dens: 0.9,  elite: 0.01, spawnCd: 0.92, batch: 1 },
    { min: 60,  max: 120, name: 'Elites Stir',         hp: 1.2,  dmg: 1.1,  spd: 1.04, dens: 1.1,  elite: 0.09, spawnCd: 0.76, batch: 2 },
    { min: 120, max: 180, name: 'Champion Ascendancy', hp: 1.45, dmg: 1.22, spd: 1.08, dens: 1.25, elite: 0.14, spawnCd: 0.64, batch: 2 },
    { min: 180, max: 240, name: 'Warden Hunt',         hp: 1.75, dmg: 1.35, spd: 1.12, dens: 1.4,  elite: 0.17, spawnCd: 0.54, batch: 3 },
    { min: 240, max: 300, name: 'Legion of Champions', hp: 2.1,  dmg: 1.5,  spd: 1.16, dens: 1.6,  elite: 0.24, spawnCd: 0.44, batch: 3 },
    { min: 300, max: 360, name: 'The Fallen Lord',     hp: 2.45, dmg: 1.65, spd: 1.2,  dens: 1.75, elite: 0.28, spawnCd: 0.36, batch: 4 },
    { min: 360, max: 1e9, name: 'Apocalypse',          hp: 2.9,  dmg: 1.85, spd: 1.26, dens: 2.1,  elite: 0.34, spawnCd: 0.24, batch: 5 }
  ]
};

export const DirectorConfig = {
  tickSec: 1.0,
  minPower: 0.55,
  maxPower: 1.85,
  highThresh: 1.18,
  lowThresh: 0.88,
  strong: { dens: 1.38, elite: 0.14, eventCd: 0.72, spd: 1.08, dmg: 1.08 },
  weak:   { dens: 0.76, elite: -0.05, eventCd: 0.85, spd: 0.88, dmg: 0.86, healDropChance: 0.18, shrineBias: 0.65 }
};

export const DAILY_MODS = [
  'Blood Moon: +30% Enemy Speed, +50% Crit Chance, +50% Drop Rate',
  'Astral Convergence: +2 Projectiles for All, +35% Enemy Health',
  'Famine of Ash: No Passive Regen, +45% Damage & Life Steal'
];

export const MODES_CONFIG = unpack([
  ['standard',    'Standard Expedition', '6-Min Escalation, gather 5 Flame Fragments & reach the Altar (Apocalypse at 06:00).', 1.0,  68, 0,    0,    0],
  ['endless',     'Endless Abyss',       'Infinite escalating depth, faster Boss Rushes, Ancient Bosses & +25% Fragments.',     1.25, 48, 0,    0,    0.25],
  ['arena',       'Challenge Arena',     'Dense crucible waves, rapid Elites & Bosses, +40% Gold & Fragment Rewards.',         1.4,  38, 0.12, 0,    0.4],
  ['mythic_hunt', 'Mythic Hunt',         'Ancient & Secret Bosses stalk the realm. +110% Mythic Drop Luck.',                   1.3,  44, 0.1,  1.1,  0.2],
  ['relic_hunt',  'Relic Hunt',          'Frequent Vaults, Goblins & Shrines. +60% Fragment & Relic Rewards.',                 1.6,  56, 0.06, 0.45, 0.5],
  ['hardcore',    'Hardcore Oath',       'Death forfeits run Gold; +65% Legendary/Mythic Luck & +35% Fragments.',              1.35, 62, 0.05, 0.65, 0.3],
  ['daily',       'Daily Rite',          DAILY_MODS[dailyIndex],                                                               1.35, 58, 0.05, 0.35, 0.3]
], ['id', 'name', 'desc', 'fragMult', 'bossCd', 'eliteAdd', 'luckAdd', 'densAdd']);