import { unpack } from '../core/utilities.js';

export const RARITIES = {
  common:    { name: 'Common',    color: '#e6e4ed', cls: 'r-common',    affixes: 1, mult: 1.0,  weight: 46 },
  magic:     { name: 'Magic',     color: '#5ca8ff', cls: 'r-magic',     affixes: 2, mult: 1.32, weight: 30 },
  rare:      { name: 'Rare',      color: '#ffd700', cls: 'r-rare',      affixes: 3, mult: 1.68, weight: 16 },
  legendary: { name: 'Legendary', color: '#ff8c00', cls: 'r-legendary', affixes: 3, mult: 2.15, weight: 6.2 },
  mythic:    { name: 'Mythic',    color: '#ff2a4b', cls: 'r-mythic',    affixes: 4, mult: 2.75, weight: 1.8 }
};

export const SLOTS = ['weapon', 'helmet', 'chest', 'ring1', 'ring2', 'amulet'];

export const SLOT_LABELS = {
  weapon: 'Weapon',
  helmet: 'Helmet',
  chest: 'Chest',
  ring1: 'Ring I',
  ring2: 'Ring II',
  amulet: 'Amulet'
};

export const PREFIXES = [
  'Ancient', 'Savage', 'Flaming', 'Frozen', 'Toxic', 'Celestial', 'Bloodforged', 'Voidtouched'
];

export const SUFFIXES = [
  'of Slaughter', 'of Giants', 'of the Eclipse', 'of Memory', 'of Ruin', 'of Nightfall', 'of Immortality'
];

export const ITEM_BASES = {
  weapon: [
    'Greatsword', 'Longsword', 'Warhammer', 'Sunforged Relic',
    'Runed Staff', 'Arcane Wand', 'Bone Grimoire', 'Hollow Relic',
    'Shadowblade', 'Ritual Dagger', 'Crescent Bow'
  ],
  helmet: ['Iron Crown', 'Cowl', 'Visor', 'Star Diadem'],
  chest:  ['Plate Cuirass', 'Ashen Vestments', 'Brigandine', 'Choir Robes'],
  ring1:  ['Signet', 'Band', 'Loop', 'Seal'],
  ring2:  ['Signet', 'Band', 'Loop', 'Seal'],
  amulet: ['Talisman', 'Reliquary', 'Medallion', 'Pendant']
};

// Item type for each base. Class gear rules (systems/equipment.js) work off these.
// Rings and amulets get 'Ring' / 'Amulet' from their slot and are usable by every class.
export const BASE_SUBTYPES = {
  Greatsword: 'Greatsword',
  Longsword: 'Sword',
  Warhammer: 'Hammer',
  'Sunforged Relic': 'Holy Relic',
  'Runed Staff': 'Staff',
  'Arcane Wand': 'Wand',
  'Bone Grimoire': 'Grimoire',
  'Hollow Relic': 'Necromantic Relic',
  Shadowblade: 'Dagger',
  'Ritual Dagger': 'Ritual Dagger',
  'Crescent Bow': 'Bow',
  'Iron Crown': 'Heavy Armor',
  Cowl: 'Light Armor',
  Visor: 'Heavy Armor',
  'Star Diadem': 'Robes',
  'Plate Cuirass': 'Heavy Armor',
  'Ashen Vestments': 'Robes',
  Brigandine: 'Light Armor',
  'Choir Robes': 'Robes'
};

export const ITEM_LORE = [
  'A relic salvaged from the shattered spires of the Ashen Capital.',
  'The traveler reached the edge of the world and found only silence.',
  'Voices echo from heavens that no longer exist.',
  'Forged when the First Flame still cast shadows across unbroken stone.',
  'Even rust refuses to touch steel tempered in royal sorrow.',
  'Inscribed with vows spoken by knights whose names were burned from history.'
];

export const SETS = {
  ashenking: 'Armor of the Ashen King',
  choir: 'Vestments of the Choir'
};

export const UNIQUES = unpack([
  ['phoenixheart', 'Phoenix Heart', 'amulet', 'legendary', null, 'Revive once per run with 65% HP and a Solar Eruption.', 'An ember torn from the First Flame before the sky cracked.'],
  ['bloodcrown', 'Blood Crown', 'helmet', 'legendary', 'ashenking', 'Gain 20% healing from all damage dealt.', 'Worn by monarchs who drank memory and blood alike.'],
  ['voidprism', 'Void Prism', 'amulet', 'mythic', null, 'Projectiles pierce infinitely and deal +35% Damage.', 'A shard of non-existence where light bends into hunger.'],
  ['stormlord', 'Storm Lord Relic', 'ring1', 'legendary', null, 'Lightning chains up to 12 nearby enemies on hit.', 'Sky-fire trapped inside tarnished bronze by the Iron Covenant.'],
  ['forgottenstars', 'Crown of Forgotten Stars', 'helmet', 'mythic', 'choir', 'Summons Celestial Meteors periodically onto foes.', ITEM_LORE[2]],
  ['ashenblade', "Ashen King's Blade", 'weapon', 'legendary', 'ashenking', 'Slain enemies erupt in ash explosions dealing 60% damage.', 'A sword carried by the final monarch of a kingdom that no longer remembers its own name.'],
  ['pilgrimring', 'Ring of the Last Pilgrim', 'ring2', 'legendary', null, '+25% Move Speed, +35% Pickup Radius, +25% Rare Loot Luck.', ITEM_LORE[1]],
  ['lodestone', 'Soul Lodestone', 'amulet', 'legendary', null, '+50% Pickup Radius & +20% XP Gain.', 'Iron drawn from fallen stars pulls lingering souls from afar.'],

  // --- Added so every class can find unique weapons and armor ---
  // NOTE: 'power' text needs matching effect code keyed on the unique id (stats.uniques.has('<id>')).
  ['emberspire', 'Emberspire', 'weapon', 'legendary', null, 'Fire spells leave burning ground that deals 40% damage per second.', 'A staff grown from the last tree to burn in the First Flame.'],
  ['hollowchoir', 'Hollow Choir', 'weapon', 'legendary', 'choir', 'Undead Sentinels deal +25% damage and share your crits.', 'Every page whispers the name of someone who should have stayed buried.'],
  ['nightwhisper', 'Nightwhisper', 'weapon', 'legendary', null, 'Critical hits reduce Dash cooldown by 0.5s.', 'The Veiled Court never recovered the hand that last held it.'],
  ['lunarstring', 'Lunarstring', 'weapon', 'legendary', null, 'Every 5th shot fires a piercing moonbolt for 150% damage.', 'Strung with a thread of starlight that refuses to fade.'],
  ['shadowcowl', 'Cowl of Quiet Steps', 'helmet', 'legendary', null, '+12% Move Speed and +10% Crit Chance.', 'It muffles footsteps, heartbeats, and eventually the wearer\'s name.'],
  ['veilbrigandine', 'Veilweave Brigandine', 'chest', 'legendary', null, '+20% Dodge Chance after dashing for 3s.', 'Stitched from the banners of kings the Court erased.'],
  ['covenantcuirass', 'Iron Covenant Cuirass', 'chest', 'legendary', 'ashenking', 'Take 15% less damage while above 70% HP.', 'No blade has found its seams since the gods began dying.'],
  ['choirshroud', 'Choir Shroud', 'chest', 'legendary', 'choir', '+20% Area Size and +10% Cooldown Reduction.', 'Woven from hymns no living voice can finish.']
], ['id', 'name', 'slot', 'rarity', 'set', 'power', 'lore']);

// Unique items that are weapons or armor need a type too (rings and amulets are free for all classes)
export const UNIQUE_SUBTYPES = {
  ashenblade: 'Sword',
  bloodcrown: 'Heavy Armor',
  forgottenstars: 'Robes',
  emberspire: 'Staff',
  hollowchoir: 'Grimoire',
  nightwhisper: 'Dagger',
  lunarstring: 'Bow',
  shadowcowl: 'Light Armor',
  veilbrigandine: 'Light Armor',
  covenantcuirass: 'Heavy Armor',
  choirshroud: 'Robes'
};

export const GEMS = unpack([
  ['Crimson Ruby', '#e03c4f', 'flatDmg', 10, '+10 Damage'],
  ['Moonlit Sapphire', '#6fa8dc', 'cdr', 0.08, '+8% Cooldown Reduction'],
  ['Verdant Emerald', '#5effb1', 'critChance', 0.06, '+6% Crit Chance'],
  ['Tarnished Onyx', '#9a96a6', 'armor', 8, '+8 Armor'],
  ['Astral Opal', '#ff8c00', 'areaPct', 0.15, '+15% Area Size'],
  ['Lodestone Amber', '#f6b93b', 'pickupRadius', 0.20, '+20% Pickup Radius']
], ['name', 'color', 'key', 'val', 'text']);
