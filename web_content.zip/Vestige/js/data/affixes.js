import { unpack } from '../core/utilities.js';

export const AFFIX_DEFS = unpack([
  ['flatDmg',      '+{v} Damage',             5,  16, false, 0],
  ['dmgPct',       '+{v}% Damage',            7,  20, true,  0],
  ['atkSpeed',     '+{v}% Attack Speed',      6,  18, true,  0],
  ['critChance',   '+{v}% Crit Chance',       3,  10, true,  0],
  ['critDmg',      '+{v}% Crit Damage',       14, 38, true,  0],
  ['maxHp',        '+{v} Max Health',         18, 52, false, 0],
  ['armor',        '+{v} Armor',              3,  12, false, 0],
  ['moveSpeed',    '+{v}% Movement Speed',    5,  15, true,  0],
  ['areaPct',      '+{v}% Area Size',         8,  24, true,  0],
  ['cdr',          '+{v}% Cooldown Reduction',4,  12, true,  0],
  ['regen',        '+{v} HP/sec Regen',       1,  5,  false, 0],
  ['lifeSteal',    '+{v}% Life Steal',        2,  6,  true,  0],
  ['summonDmg',    '+{v}% Summon Power',      12, 32, true,  0],
  ['pickupRadius', '+{v}% Pickup Radius',     12, 30, true,  0],
  ['projBonus',    '+{v} Projectile',         1,  1,  false, 1]
], ['key', 'label', 'min', 'max', 'pct', 'rareOnly']);