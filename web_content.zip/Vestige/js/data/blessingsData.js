// `classes` (optional): only these class ids are offered the blessing. Omit for all classes.
export const BLESSINGS_DATA = [
  { tag: 'Offense',    name: 'Ember Might',       desc: '+16% Damage',                                   apply: p => { p.bonus.dmgPct += 0.16; } },
  { tag: 'Crit',       name: 'Fell Precision',    desc: '+8% Crit Chance & +25% Crit Damage',            apply: p => { p.bonus.critChance += 0.08; p.bonus.critDmg += 0.25; } },
  { tag: 'Speed',      name: 'Tempest Cadence',   desc: '+14% Attack Speed & +8% Move Speed',            apply: p => { p.bonus.atkSpeed += 0.14; p.bonus.moveSpeed += 0.08; } },
  { tag: 'Area',       name: 'Shattered Horizon', desc: '+22% Area Size',                                apply: p => { p.bonus.areaPct += 0.22; } },
  { tag: 'Projectile', name: 'Multishot',         desc: '+1 Projectile to all weapons',                  classes: ['ranger', 'mage', 'assassin', 'necromancer'], apply: p => { p.bonus.projBonus++; } },
  { tag: 'Defense',    name: 'Iron Oath',         desc: '+10 Armor & +28 Max Health',                    apply: p => { p.bonus.armor += 10; p.bonus.maxHp += 28; } },
  { tag: 'Sustain',    name: 'Sanguine Rite',     desc: '+4% Life Steal & +3 HP/sec Regen',              apply: p => { p.bonus.lifeSteal += 0.04; p.bonus.regen += 3; } },
  { tag: 'Caster',     name: 'Chronomancy',       desc: '+10% Cooldown Reduction & +15% XP Gain',        classes: ['mage', 'necromancer'], apply: p => { p.bonus.cdr += 0.10; p.bonus.xpGain += 0.15; } },
  { tag: 'Magnet',     name: 'Soul Magnetism',    desc: '+25% Pickup Radius & +10% Move Speed',          apply: p => { p.bonus.pickupRadius += 0.25; p.bonus.moveSpeed += 0.10; } },
  { tag: 'Summon',     name: 'Soul Chorus',       desc: '+30% Summon Power',                             classes: ['necromancer', 'mage'], apply: p => { p.bonus.summonDmg += 0.30; } },

  // Class-flavored additions
  { tag: 'Melee',      name: 'Warbound Fury',     desc: '+20% Damage & +12% Area Size',                  classes: ['warrior', 'paladin'], apply: p => { p.bonus.dmgPct += 0.20; p.bonus.areaPct += 0.12; } },
  { tag: 'Holy',       name: 'Radiant Vow',       desc: '+4 HP/sec Regen & +12 Armor',                   classes: ['paladin'],            apply: p => { p.bonus.regen += 4; p.bonus.armor += 12; } },
  { tag: 'Stealth',    name: 'Knife in the Dark', desc: '+12% Crit Chance & +30% Crit Damage',           classes: ['assassin', 'ranger'], apply: p => { p.bonus.critChance += 0.12; p.bonus.critDmg += 0.30; } }
];

// Use this wherever blessings are offered (level-up picker, shop, etc.)
export const blessingsFor = classId =>
  BLESSINGS_DATA.filter(b => !b.classes || b.classes.includes(classId));
