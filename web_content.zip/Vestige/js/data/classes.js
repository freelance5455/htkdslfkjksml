import { unpack } from '../core/utilities.js';

export const CLASSES = unpack([
  [
    'warrior', 'Warrior', 'Oathbound of the Iron Covenant', 'greatsword',
    165, 205, 12, 0.08, 1.15,
    'Unbroken Steel', '+12 Armor, +15% Damage, wide sweeping Greatsword arcs.',
    'When the Iron Covenant challenged the dying gods, only a few blades remained unbroken.',
    0, '#e05656'
  ],
  [
    'ranger', 'Ranger', 'Watcher of the Ashen Canopy', 'moonbow',
    115, 235, 4, 0.16, 1.0,
    'Windstrider', '+16% Crit Chance, +18% Attack Speed, high mobility.',
    'Arrows loosed beneath a starless sky still remember the constellations that guided them.',
    0, '#7bed9f'
  ],
  [
    'mage', 'Mage', 'Pyromancer of the First Spark', 'firestaff',
    105, 210, 3, 0.08, 1.1,
    'Arcane Resonance', '+25% Area Size, +12% Cooldown Reduction.',
    'They studied the embers of Eternity until their blood turned to smoke and starlight.',
    0, '#ff8c38'
  ],
  [
    'necromancer', 'Necromancer', 'Cantor of the Hollow Communion', 'grimoire',
    110, 208, 5, 0.06, 0.95,
    'Lord of Bones', 'Starts with 2 Undead Sentinels, +35% Summon Power.',
    'The dead are not sleeping. They are remembering the names the living forgot.',
    25, '#5effb1'
  ],
  [
    'paladin', 'Paladin', 'Templar of the Golden Throne', 'sunhammer',
    155, 202, 14, 0.07, 1.05,
    'Sacred Bastion', '+3 HP/sec Regen, +14 Armor, orbiting consecrated hammers.',
    'Even after the Golden Throne cracked, its knights kept vigil over empty cathedrals.',
    35, '#ffd700'
  ],
  [
    'assassin', 'Assassin', 'Blade of the Veiled Court', 'shadowdagger',
    100, 245, 3, 0.22, 1.1,
    'Phantom Step', '+22% Crit Chance, +45% Crit Damage, -25% Dash Cooldown.',
    'The Veiled Court never fought wars; they merely erased the kings who began them.',
    40, '#c56cf0'
  ]
], [
  'id', 'name', 'title', 'weapon', 'hp', 'speed', 'armor', 'crit', 'dmg',
  'passiveName', 'passiveDesc', 'lore', 'cost', 'color'
]);

export const WEAPONS_DEF = {
  greatsword:   { name: 'Iron Greatsword', evolved: 'Ashen Executioner',      catalyst: 'ashenhilt',      catName: 'Ashen Hilt',      color: '#e05656', mastery: 'greatsword' },
  moonbow:      { name: 'Moon Bow',        evolved: 'Lunar Cataclysm',        catalyst: 'celestialrelic', catName: 'Celestial Relic', color: '#8ec5ff', mastery: 'bow' },
  firestaff:    { name: 'Fire Staff',      evolved: 'Phoenix Inferno Staff',  catalyst: 'phoenixfeather', catName: 'Phoenix Feather', color: '#ff8c38', mastery: 'staff' },
  shadowdagger: { name: 'Shadow Dagger',   evolved: 'Voidfang',               catalyst: 'voidessence',    catName: 'Void Essence',    color: '#c56cf0', mastery: 'dagger' },
  grimoire:     { name: 'Bone Grimoire',   evolved: 'Sovereign Necronomicon', catalyst: 'soullantern',    catName: 'Soul Lantern',    color: '#5effb1', mastery: 'staff' },
  sunhammer:    { name: 'Sun Hammer',      evolved: 'Solaris Judgement',      catalyst: 'goldenseal',     catName: 'Golden Seal',     color: '#ffd700', mastery: 'sword' }
};