import { metaSave } from './save.js';

export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.drone = null;
    this.lastHit = 0;
  }

  init() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) this.ctx = new AC();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setBiomeTone(hz) {
    if (!this.ctx || !metaSave.settings.sound) return;
    if (!this.drone) {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = hz;
      g.gain.value = 0.018;
      osc.connect(g);
      g.connect(this.ctx.destination);
      osc.start();
      this.drone = { osc, g };
    } else {
      this.drone.osc.frequency.setTargetAtTime(hz, this.ctx.currentTime, 1.2);
      this.drone.g.gain.setTargetAtTime(metaSave.settings.sound ? 0.018 : 0, this.ctx.currentTime, 0.3);
    }
  }

  tone(type, f0, f1, dur, gain, delay = 0) {
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(this.ctx.destination);
    o.start(t);
    o.stop(t + dur + 0.01);
  }

  play(kind) {
    if (!this.ctx || !metaSave.settings.sound) return;
    const t = this.ctx.currentTime;
    if (kind === 'hit') {
      if (t - this.lastHit < 0.045) return;
      this.lastHit = t;
      this.tone('triangle', 140 + Math.random() * 60, 48, 0.06, 0.05);
    } else if (kind === 'dash') {
      this.tone('sawtooth', 240, 75, 0.14, 0.06);
    } else if (kind === 'gem') {
      this.tone('sine', 660 + Math.random() * 140, 990, 0.05, 0.028);
    } else {
      const notes = kind === 'legendary' ? [392, 493, 587, 784] : [330, 440, 554, 659];
      notes.forEach((f, i) => this.tone('triangle', f, 0, 0.32, 0.075, i * 0.07));
    }
  }
}

export const sfx = new AudioEngine();