export const CFG = {
  game: {
    W: 3200,
    H: 3200,
    SAVE_KEY: 'ashen_expanse_save_v1',
    BIOME_SEC: 120,
    APOC_SEC: 360,
    MAX_BAG: 20,
    MAX_ENEMIES: 440,
    EVENTS_CAP: 7
  },
  combat: {
    BASE_PICKUP: 120,
    MAGNET_LVL: 0.05,
    BASE_DASH_CD: 1.75,
    HIT_INVULN: 0.34,
    CRIT_MULT: 1.75,
    MAX_CDR: 0.72,
    MAX_CRIT: 0.95
  },
  loot: {
    ANCIENT_BASE: 0.12,
    DROP_CHANCE: 0.032,
    ELITE_DROP: 0.65,
    GOBLIN_GOLD: 45
  },
  ui: {
    HUD_STEP: 0.08,
    FEED_MAX: 5,
    FEED_MS: 3600
  }
};

export const dailyIndex = new Date().getDate() % 3;