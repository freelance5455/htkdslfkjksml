import { CFG, dailyIndex } from './config.js';
import { $, SpatialGrid, Pool, poly, drawCircle, drawRing, drawBeam, SIL } from './utilities.js';
import { metaSave, persistSave, addMetaCurrency, grantFrag, registerRunFragsGetter } from './save.js';
import { sfx } from './audio.js';
import { initInput, getMoveVec } from './input.js';

import { CLASSES } from '../data/classes.js';
import { RARITIES } from '../data/items.js';
import { BossScalingConfig } from '../data/bossData.js';
import { ENDINGS_DATA } from '../data/eventsData.js';
import { WorldTierConfig, MODES_CONFIG } from '../data/worldTierData.js';

import { createPlayer, recalcStats, triggerDash, updatePlayerMovement, renderPlayer } from '../entities/player.js';
import { spawnEnemy, updateEnemies, drawEnemy } from '../entities/enemies.js';
import { spawnElitePack } from '../entities/champions.js';
import { updateBossDeaths, renderBossDeaths } from '../entities/bosses.js';
import {
  updateProjectiles,
  updateTelegraphs,
  updateHazards,
  renderProjectiles,
  renderTelegraphs,
  renderHazards,
  getSpellParticleCount
} from '../entities/projectiles.js';
import { updateSummons, renderSummons } from '../entities/summons.js';
import { updateGemsAndLoot, renderGemsAndLoot, getMythicTimeScale } from '../entities/loot.js';

import { salvageJunk } from '../systems/inventory.js';
import { updateWeapons, updatePeriodicProcs, renderWeaponEffects } from '../systems/skills.js';
import { spawnWorldEvent, updateWorldEvents, renderWorldEvents } from '../systems/events.js';
import { DUNGEONS } from '../systems/dungeons.js';
import { unlockLore } from '../systems/codex.js';
import { unlockAchievement } from '../systems/achievements.js';
import { getScaling } from '../systems/worldtiers.js';
import { updateDirector } from '../systems/aiDirector.js';
import {
  QuestlineManager,
  OBJECTIVE_TYPES,
  addQuestProgress,
  advanceQuest,
  notifyQuestEvent
} from '../systems/questlines.js';

import {
  BIOMES,
  generateWorldProps,
  updateBiomeCycle,
  renderParallaxBackground,
  renderWorldBackdrop,
  renderDynamicLighting,
  renderWeather,
  renderPostFX
} from '../world/biomes.js';

import { buildUI, DOM, updateHud } from '../ui/hud.js';
import { renderInventory, initInventoryUI, clearSelectedItem } from '../ui/inventoryUI.js';
import { renderTree, initTreeUI } from '../ui/treeUI.js';
import { renderCraft, initForgeUI } from '../ui/forgeUI.js';
import { renderMainMenu, initReliquaryUI } from '../ui/reliquaryUI.js';
import { renderCodex } from '../ui/codexUI.js';
import { initQuestUI, openQuestModal, closeQuestModal, renderQuestTracker } from '../ui/questUI.js';
import { renderMinimap } from '../ui/minimap.js';
import { initMobileControls, renderJoystick } from '../ui/mobileControls.js';
import { addFeed, showBanner, renderBanner, renderFloatTexts } from '../ui/notifications.js';

export const canvas = $('gameCanvas');
export const ctx = canvas.getContext('2d', { alpha: false });
export let viewW = window.innerWidth;
export let viewH = window.innerHeight;
export let viewDpr = 1;

function getLayoutProfile(w, h) {
  const portrait = h > w;
  if (portrait && w < 640) return 'portrait-phone';
  if (portrait) return 'tablet-portrait';
  if (h < 540) return 'landscape-phone';
  if (w / Math.max(1, h) > 2.05) return 'ultrawide';
  return 'desktop';
}

function computeVirtualCamera(w, h) {
  const portrait = h > w;
  const zoom = portrait
    ? Math.max(0.48, Math.min(1.10, Math.min(w / 660, h / 880)))
    : Math.max(0.78, Math.min(1.3, h / 840));
  return { zoom, worldW: w / zoom, worldH: h / zoom };
}

function ensureResponsiveStyles() {
  if (typeof document === 'undefined' || document.getElementById('vestige-responsive-css')) return;
  const s = document.createElement('style');
  s.id = 'vestige-responsive-css';
  s.textContent = `
    #hud {
      padding: max(12px, env(safe-area-inset-top)) max(14px, env(safe-area-inset-right)) max(10px, env(safe-area-inset-bottom)) max(14px, env(safe-area-inset-left));
    }
    .modal-overlay {
      padding: max(10px, env(safe-area-inset-top)) max(10px, env(safe-area-inset-right)) max(10px, env(safe-area-inset-bottom)) max(10px, env(safe-area-inset-left));
    }
    .modal-box {
      max-width: min(1080px, 100%);
      max-height: 92dvh;
      padding: clamp(10px, 2.2vw, 20px);
    }
    .grid-2 { grid-template-columns: repeat(auto-fit, minmax(min(280px, 100%), 1fr)); }
    .grid-3 { grid-template-columns: repeat(auto-fit, minmax(min(220px, 100%), 1fr)); }
    .bag-grid { grid-template-columns: repeat(auto-fill, minmax(min(175px, 100%), 1fr)) !important; }
    #tree-canvas { height: auto !important; aspect-ratio: 960 / 420; max-height: 55dvh; }

    /* Mobile Portrait & Narrow Viewports */
    html[data-layout="portrait-phone"] #hud { padding: max(10px, env(safe-area-inset-top)) 8px max(8px, env(safe-area-inset-bottom)) 8px; }
    html[data-layout="portrait-phone"] .hud-top { flex-wrap: wrap; gap: 6px; }
    html[data-layout="portrait-phone"] .hud-left { order: 1; min-width: 0; flex: 1 1 56%; max-width: none; }
    html[data-layout="portrait-phone"] .hud-right { order: 2; flex: 0 1 auto; align-items: flex-end; gap: 4px; }
    html[data-layout="portrait-phone"] .hud-center { order: 3; flex: 1 0 100%; max-width: 100%; }
    html[data-layout="portrait-phone"] #minimap { width: 74px; height: 74px; }
    html[data-layout="portrait-phone"] .hud-btns { max-width: 185px; gap: 3px; }
    html[data-layout="portrait-phone"] .hud-btn { padding: 4px 6px; font-size: 10px; }
    html[data-layout="portrait-phone"] #quest-box { display: none; }
    html[data-layout="portrait-phone"] .hud-bottom { flex-wrap: wrap; gap: 6px; }
    html[data-layout="portrait-phone"] #weapons-bar { max-width: 100%; flex: 1 1 65%; }
    html[data-layout="portrait-phone"] #loot-feed { left: 8px; bottom: 86px; max-width: 68vw; }
    html[data-layout="portrait-phone"] #mobile-dash { right: 12px; bottom: 64px; width: 58px; height: 58px; }
    html[data-layout="portrait-phone"] h1.title { font-size: 24px; letter-spacing: 2px; }

    /* Tablet Portrait */
    html[data-layout="tablet-portrait"] .hud-top { flex-wrap: wrap; gap: 8px; }
    html[data-layout="tablet-portrait"] .hud-left { order: 1; flex: 1 1 45%; }
    html[data-layout="tablet-portrait"] .hud-right { order: 2; }
    html[data-layout="tablet-portrait"] .hud-center { order: 3; flex: 1 0 100%; max-width: 100%; }

    /* Mobile Landscape (short vertical space) */
    html[data-layout="landscape-phone"] #hud { padding: 8px 12px; }
    html[data-layout="landscape-phone"] #quest-box { display: none; }
    html[data-layout="landscape-phone"] #minimap { width: 76px; height: 76px; }
    html[data-layout="landscape-phone"] .hud-left { min-width: 210px; max-width: 260px; }
    html[data-layout="landscape-phone"] .biome-banner { padding: 2px 12px; }
    html[data-layout="landscape-phone"] #timer-text { font-size: 15px; }
    html[data-layout="landscape-phone"] #mobile-dash { right: 14px; bottom: 54px; width: 56px; height: 56px; }
    html[data-layout="landscape-phone"] #loot-feed { bottom: 48px; }
  `;
  document.head.appendChild(s);
}

export function onResize() {
  ensureResponsiveStyles();
  const vv = window.visualViewport;
  viewW = Math.max(320, Math.round(vv ? vv.width : window.innerWidth));
  viewH = Math.max(320, Math.round(vv ? vv.height : window.innerHeight));
  viewDpr = Math.min(2, window.devicePixelRatio || 1);

  canvas.width = Math.round(viewW * viewDpr);
  canvas.height = Math.round(viewH * viewDpr);
  canvas.style.width = `${viewW}px`;
  canvas.style.height = `${viewH}px`;

  const profile = getLayoutProfile(viewW, viewH);
  document.documentElement.dataset.layout = profile;
  if (state?.camera) {
    const cam = computeVirtualCamera(viewW, viewH);
    state.camera.zoom = cam.zoom;
    state.camera.worldW = cam.worldW;
    state.camera.worldH = cam.worldH;
  }
}

window.addEventListener('resize', onResize);
window.addEventListener('orientationchange', onResize);
if (window.visualViewport) window.visualViewport.addEventListener('resize', onResize);

export const enemyGrid = new SpatialGrid(CFG.game.W, CFG.game.H, 115);
export const qBuf = [];

export const enemyPool = new Pool(() => ({
  alive: false, x: 0, y: 0, r: 13, hp: 20, maxHp: 20, speed: 80, dmg: 10, xp: 3,
  color: '#c0392b', faction: 'hollow', kind: 'walker', role: 'normal', elite: false,
  mod: null, boss: false, bossData: null, goblin: false, hitFlash: 0, shieldHp: 0,
  atkCd: 1.5, phase: 1, fleeAngle: 0, spawnT: 0, seed: 0
}), 480);

export const projPool = new Pool(() => ({
  alive: false, x: 0, y: 0, vx: 0, vy: 0, r: 6, dmg: 10, pierce: 0, life: 1.5,
  color: '#8ec5ff', isEnemy: false, critBonus: 0, homing: false, weaponKey: null, hitIds: new Set()
}), 360);

export const gemPool = new Pool(() => ({
  alive: false, x: 0, y: 0, val: 2, color: '#6fa8dc', magnet: false, heal: false
}), 500);

export const lootPool = new Pool(() => ({
  alive: false, x: 0, y: 0, item: null, bob: 0
}), 70);

export const partPool = new Pool(() => ({
  alive: false, x: 0, y: 0, vx: 0, vy: 0, r: 2.5, color: '#fff', life: 0.4, maxLife: 0.4
}), 420);

export const textPool = new Pool(() => ({
  alive: false, x: 0, y: 0, vy: -35, text: '', color: '#fff', life: 0.6, size: 13
}), 200);

export const arcs = [];
export const hazards = [];
export const events = [];
export const summons = [];
export const telegraphs = [];
export const impacts = [];
export const bossDeaths = [];
export const cracks = [];

// ============================================================================
// PERFORMANCE GOVERNOR
// Watches effect load + frame time and steps through 4 quality levels
// (0 = full fidelity ... 3 = lean). Gameplay is never affected - only visuals.
// Tweak live from the console via window.__vestigePerf (e.g. forceLevel = 2).
// ============================================================================
export const PARTICLE_BUDGET = 500; // hard cap: main particles + spell particles

export const PERF_CFG = {
  forceLevel: -1,     // -1 = automatic, 0..3 = pin a level
  lightFilter: true,  // limit / merge dynamic lights
  showStats: false    // tiny FPS / level overlay
};
if (typeof window !== 'undefined') window.__vestigePerf = PERF_CFG;

const PERF_PRESETS = [
  { trailMode: 0, trailStepMul: 1.0, spellCap: 220, impactCap: 54, impactProb: 1.0,  burstMul: 1.0,  liteProj: false, decor: true,  lightMax: 40, lightMerge: 0,   lightFar: false, textCell: false, textWindow: 0.20, arcCap: 30, burstCap: 28, decalCap: 30, hitImpactCap: 40, ghostCap: 10 },
  { trailMode: 1, trailStepMul: 1.6, spellCap: 170, impactCap: 40, impactProb: 0.7,  burstMul: 0.75, liteProj: false, decor: true,  lightMax: 28, lightMerge: 70,  lightFar: false, textCell: true,  textWindow: 0.30, arcCap: 24, burstCap: 22, decalCap: 24, hitImpactCap: 30, ghostCap: 8 },
  { trailMode: 2, trailStepMul: 2.8, spellCap: 110, impactCap: 24, impactProb: 0.4,  burstMul: 0.5,  liteProj: true,  decor: false, lightMax: 16, lightMerge: 110, lightFar: true,  textCell: true,  textWindow: 0.40, arcCap: 18, burstCap: 16, decalCap: 16, hitImpactCap: 18, ghostCap: 6 },
  { trailMode: 3, trailStepMul: 5.0, spellCap: 60,  impactCap: 12, impactProb: 0.15, burstMul: 0.3,  liteProj: true,  decor: false, lightMax: 9,  lightMerge: 150, lightFar: true,  textCell: true,  textWindow: 0.50, arcCap: 12, burstCap: 8,  decalCap: 8,  hitImpactCap: 10, ghostCap: 4 }
];

export const perf = {
  level: 0,
  frameMs: 16.7,
  load: 0,
  hold: 0,
  denseAoe: false,
  lowGfx: false,
  ...PERF_PRESETS[0]
};

function applyPerfPreset(level) {
  perf.level = level;
  Object.assign(perf, PERF_PRESETS[level]);
  if (perf.lowGfx) {
    perf.spellCap = Math.min(perf.spellCap, 75);
    perf.impactCap = Math.min(perf.impactCap, 22);
    perf.burstCap = Math.min(perf.burstCap, 12);
    perf.decalCap = Math.min(perf.decalCap, 12);
  }
}

// Is a world point inside the camera rect (plus padding)?
export function onScreen(x, y, pad = 0) {
  const c = state.camera;
  return Math.abs(x - c.x) <= c.worldW * 0.5 + pad && Math.abs(y - c.y) <= c.worldH * 0.5 + pad;
}

function updatePerf(rawDt) {
  const low = metaSave.settings.gfxQuality === 'low';
  if (perf.lowGfx !== low) {
    perf.lowGfx = low;
    applyPerfPreset(perf.level);
  }

  perf.frameMs += (Math.min(rawDt * 1000, 100) - perf.frameMs) * 0.06;

  const load =
    projPool.active.length +
    (partPool.active.length + getSpellParticleCount()) * 0.25 +
    telegraphs.length * 6 +
    hazards.length * 5 +
    textPool.active.length * 0.4 +
    arcs.length * 2;
  perf.load += (load - perf.load) * 0.2;

  let target = perf.load >= 650 ? 3 : perf.load >= 420 ? 2 : perf.load >= 240 ? 1 : 0;
  // Frame-time safety net: if we're actually slow while effects are present, step down further
  if (perf.load > 100) {
    if (perf.frameMs > 30) target += 2;
    else if (perf.frameMs > 21) target += 1;
  }
  if (low && target < 1) target = 1;
  if (PERF_CFG.forceLevel >= 0) target = PERF_CFG.forceLevel;
  target = Math.min(3, target);

  perf.denseAoe = telegraphs.length >= 6 || perf.level >= 3;

  if (target > perf.level) {
    applyPerfPreset(target);   // degrade immediately
    perf.hold = 2.5;
  } else if (target < perf.level) {
    if ((perf.hold -= rawDt) <= 0) { // recover slowly (no flicker between levels)
      applyPerfPreset(perf.level - 1);
      perf.hold = 1.5;
    }
  } else {
    perf.hold = 1.5;
  }
}

// --- dynamic light limiter (wraps inView for renderDynamicLighting) ---
const lightX = new Float32Array(64);
const lightY = new Float32Array(64);
let lightN = 0;
let lightCx = 0;
let lightCy = 0;
let lightFar2 = 0;
let lightBase = null;

function lightInView(x, y, pad) {
  if (!lightBase(x, y, perf.lightFar ? pad * 0.5 : pad)) return false;
  // Re-query of an already accepted light (same position) is the same light
  const merge2 = perf.lightMerge * perf.lightMerge;
  for (let i = 0; i < lightN; i++) {
    const dx = x - lightX[i];
    const dy = y - lightY[i];
    const d2 = dx * dx + dy * dy;
    if (d2 <= 1) return true;
    if (d2 < merge2) return false; // merged into a nearby light
  }
  if (perf.lightFar) {
    const dx = x - lightCx;
    const dy = y - lightCy;
    if (dx * dx + dy * dy > lightFar2) return false; // distant lights dropped
  }
  if (lightN >= perf.lightMax) return false;
  lightX[lightN] = x;
  lightY[lightN] = y;
  lightN++;
  return true;
}

function drawPerfStats(ctx) {
  ctx.save();
  ctx.setTransform(viewDpr, 0, 0, viewDpr, 0, 0);
  ctx.font = '11px monospace';
  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  ctx.fillRect(8, viewH - 74, 230, 18);
  ctx.fillStyle = '#9fe9a0';
  ctx.fillText(
    `FPS ${(1000 / Math.max(1, perf.frameMs)) | 0}  FX L${perf.level}  load ${perf.load | 0}  proj ${projPool.active.length}  pt ${partPool.active.length + getSpellParticleCount()}`,
    12, viewH - 61
  );
  ctx.restore();
}

const decals = [];
const deathBursts = [];
const dashGhosts = [];
let dashGhostCd = 0;
let wasDashing = false;

export const state = {
  mode: 'menu',
  selectedClassId: 'warrior',
  worldTier: 1,
  startBiomeIdx: 0,
  gameMode: 'standard',
  modeCfg: MODES_CONFIG[0],
  dungeon: DUNGEONS[0],
  relTab: 'upgrades',
  time: 0,
  kills: 0,
  runGold: 0,
  runShards: 0,
  runEssence: 0,
  runFrags: { flame: 0, void: 0, star: 0, ash: 0 },
  biomeIdx: 0,
  nextBiomeTime: CFG.game.BIOME_SEC,
  spawnCd: 0,
  bossCd: BossScalingConfig.major.stdCd,
  eventCd: 16,
  meteorCd: 3.5,
  enemySpeedMult: 1,
  apocalypse: false,
  shake: 0,
  dmgFlash: 0,
  newLoot: 0,
  banner: null,
  camera: { x: CFG.game.W / 2, y: CFG.game.H / 2, zoom: 1, worldW: viewW, worldH: viewH },
  ambientParticles: Array.from({ length: 85 }, () => ({
    x: Math.random() * viewW,
    y: Math.random() * viewH,
    s: 1 + Math.random() * 2.2,
    phase: Math.random() * 6.28
  })),
  player: null,
  activeBoss: null,
  director: {
    power: 1, dpsEma: 0, killsEma: 0, takenEma: 0,
    fDmg: 0, fKills: 0, fTaken: 0, tickCd: 0, phaseIdx: -1, flags: {}
  }
};

onResize();
registerRunFragsGetter(() => state.runFrags);

// ============================================================================
// REUSABLE QUESTLINE EVENT BUS & CONFIGURABLE HOTKEY HOOKS
// ============================================================================

const questBridge = {
  lastBiomeIdx: -1,
  lastFrags: { flame: 0, void: 0, star: 0, ash: 0 },
  seenBossDeaths: new WeakSet(),
  seenBagItems: new WeakSet(),
  trackedEvents: new Map(),
  hooksBound: false
};

const hotkeyConfig = {
  questJournal: 'j'
};

const hotkeyListeners = new Map();

export function configureQuestHotkey(key) {
  if (typeof key === 'string' && key.trim()) {
    hotkeyConfig.questJournal = key.trim().toLowerCase();
  }
}

export function registerHotkeyHook(key, handler) {
  if (typeof key !== 'string' || typeof handler !== 'function') return;
  hotkeyListeners.set(key.toLowerCase(), handler);
}

export function emitQuestGameplayEvent(eventType, payload = {}) {
  const changed = notifyQuestEvent(eventType, payload);
  if (changed) renderQuestTracker();
  return changed;
}

export function triggerNpcQuestEncounter(npcId, questId = null, action = {}) {
  emitQuestGameplayEvent(OBJECTIVE_TYPES.NPC_ENCOUNTER, { id: npcId, target: npcId });
  if (questId) {
    QuestlineManager.discoverQuest(questId);
    if (action.complete) {
      QuestlineManager.completeQuest(questId, action.endingId || 'resolved');
    } else if (action.choiceId || action.advance) {
      advanceQuest(questId, { choiceId: action.choiceId || null, force: Boolean(action.force) });
    }
  }
  renderQuestTracker();
}

const WORLD_EVENT_HANDLERS = [
  {
    test: lbl => /pilgrim/.test(lbl),
    onSpawn: () => triggerNpcQuestEncounter('last_pilgrim', 'last_pilgrim'),
    onComplete: () => triggerNpcQuestEncounter('last_pilgrim', 'last_pilgrim')
  },
  {
    test: lbl => /seer|prophet|observatory/.test(lbl),
    onSpawn: () => triggerNpcQuestEncounter('veiled_seer', 'veiled_seer'),
    onComplete: () => addQuestProgress('veiled_seer', 'complete_astral_event', 1)
  },
  {
    test: lbl => /smith|kaelen|forge|merchant/.test(lbl),
    onSpawn: () => triggerNpcQuestEncounter('kaelen_smith', 'kaelen_smith'),
    onComplete: () => addQuestProgress('kaelen_smith', 'find_forge_frags', 1)
  },
  {
    test: lbl => /vault|anvil|chest/.test(lbl),
    onComplete: () => {
      addQuestProgress('kaelen_smith', 'find_forge_frags', 1);
      addQuestProgress('kaelen_smith', 'recover_ember_anvil', 1);
    }
  },
  {
    test: lbl => /shrine|altar/.test(lbl),
    onComplete: () => triggerNpcQuestEncounter('last_pilgrim', 'last_pilgrim')
  }
];

function initQuestlineSystem() {
  QuestlineManager.load();
  if (questBridge.hooksBound) return;
  questBridge.hooksBound = true;

  QuestlineManager.on('notify', evt => {
    if (evt.kind === 'discover') {
      showBanner('QUEST STARTED', evt.quest.name, evt.quest.color, 2.5);
    } else if (evt.kind === 'progress') {
      addFeed(`QUEST UPDATED: ${evt.quest.name} (${evt.progress}/${evt.required})`, evt.quest.color);
    } else if (evt.kind === 'choice_ready') {
      showBanner('QUEST UPDATED', `${evt.quest.name} — Decision Ready [${hotkeyConfig.questJournal.toUpperCase()}]`, evt.quest.color, 2.6);
    }
    renderQuestTracker();
  });

  QuestlineManager.on('stageComplete', evt => {
    addFeed(`QUEST UPDATED: ${evt.quest.name} — Stage Complete`, evt.quest.color);
    renderQuestTracker();
  });

  QuestlineManager.on('questComplete', evt => {
    showBanner('QUEST COMPLETED', evt.quest.name, evt.quest.color, 3.0);
    renderQuestTracker();
  });

  QuestlineManager.on('questFailed', () => renderQuestTracker());
}

function resetQuestBridgeForRun() {
  questBridge.lastBiomeIdx = state.biomeIdx;
  questBridge.lastFrags = { ...state.runFrags };
  questBridge.seenBossDeaths = new WeakSet();
  questBridge.seenBagItems = new WeakSet();
  questBridge.trackedEvents = new Map();
}

function pollGameplayEventsForQuests() {
  const p = state.player;
  if (!p) return;

  // 1) Biome Entered
  if (state.biomeIdx !== questBridge.lastBiomeIdx) {
    questBridge.lastBiomeIdx = state.biomeIdx;
    const b = BIOMES[state.biomeIdx];
    if (b) emitQuestGameplayEvent(OBJECTIVE_TYPES.BIOME_EXPLORE, { id: b.id, biomeId: b.id });
  }

  // 2) Fragments Acquired
  for (const fk of ['flame', 'void', 'star', 'ash']) {
    const cur = state.runFrags[fk] || 0;
    const prev = questBridge.lastFrags[fk] || 0;
    if (cur > prev) {
      emitQuestGameplayEvent(OBJECTIVE_TYPES.FRAGMENT_COLLECT, { target: fk, amount: cur - prev });
      questBridge.lastFrags[fk] = cur;
    }
  }

  // 3) Bosses & Dungeons
  for (let i = 0; i < bossDeaths.length; i++) {
    const bd = bossDeaths[i];
    if (questBridge.seenBossDeaths.has(bd)) continue;
    questBridge.seenBossDeaths.add(bd);
    const bId = bd.bossData?.id;
    emitQuestGameplayEvent(OBJECTIVE_TYPES.BOSS_KILL, { id: bId, bossId: bId });
    if (bd.bossData?.faction === 'throne' || bId === 'colossus') {
      addQuestProgress('kaelen_smith', 'slay_iron_champion', 1);
    }
    if (state.dungeon && state.dungeon.id !== 'none') {
      emitQuestGameplayEvent(OBJECTIVE_TYPES.DUNGEON_CLEAR, { id: state.dungeon.id });
    }
  }

  // 4) Champions / Elites
  for (let i = 0; i < enemyPool.active.length; i++) {
    const e = enemyPool.active[i];
    if (e.alive || e._questProcessed) continue;
    e._questProcessed = true;
    if (e.elite) {
      emitQuestGameplayEvent(OBJECTIVE_TYPES.ENEMY_KILL, { id: e.kind, faction: e.faction, elite: true });
      if (e.faction === 'throne' && Math.random() < 0.35) addQuestProgress('kaelen_smith', 'find_forge_frags', 1);
      if (e.faction === 'veiled' && Math.random() < 0.25) addQuestProgress('veiled_seer', 'collect_stars', 1);
    }
  }

  // 5) World Events (Vaults, Shrines, Merchants, NPCs, Future Events)
  const liveEvents = new Set(events);
  for (let i = 0; i < events.length; i++) {
    const ev = events[i];
    if (questBridge.trackedEvents.has(ev)) continue;
    const label = `${ev.kind || ''} ${ev.type || ''} ${ev.name || ''} ${ev.label || ''}`.toLowerCase();
    const kind = ev.kind || ev.type || 'world_event';
    questBridge.trackedEvents.set(ev, { label, kind });
    for (const h of WORLD_EVENT_HANDLERS) {
      if (h.onSpawn && h.test(label)) h.onSpawn(ev);
    }
  }

  for (const [evObj, meta] of questBridge.trackedEvents.entries()) {
    if (!liveEvents.has(evObj) || evObj.done || evObj.completed) {
      questBridge.trackedEvents.delete(evObj);
      emitQuestGameplayEvent(OBJECTIVE_TYPES.WORLD_EVENT, { id: meta.kind, target: meta.kind });
      for (const h of WORLD_EVENT_HANDLERS) {
        if (h.onComplete && h.test(meta.label)) h.onComplete(evObj);
      }
    }
  }

  // 6) Relics & Item Discoveries
  for (let i = 0; i < p.bag.length; i++) {
    const item = p.bag[i];
    if (!item || questBridge.seenBagItems.has(item)) continue;
    questBridge.seenBagItems.add(item);
    emitQuestGameplayEvent(OBJECTIVE_TYPES.ITEM_DISCOVERY, { id: item.id || item.subType, item });
    if ((item.unique || item.rarity === 'legendary' || item.rarity === 'mythic') && Math.random() < 0.45) {
      addQuestProgress('kaelen_smith', 'find_forge_frags', 1);
    }
  }
}

export function addShake(amt) {
  if (metaSave.settings.shake) state.shake = Math.max(state.shake, amt);
}

export function spawnParticles(x, y, color, count = 6, spd = 130) {
  if (!onScreen(x, y, 80)) return; // never spawn off-screen particles
  const low = metaSave.settings.gfxQuality === 'low';
  // Shared hard budget with the spell-particle ring buffer
  const room = Math.min(low ? 160 : 380, PARTICLE_BUDGET - getSpellParticleCount()) - partPool.active.length;
  if (room <= 0) return;
  let n = low ? Math.max(1, (count * 0.5) | 0) : count;
  n = Math.max(1, Math.round(n * perf.burstMul));
  if (n > room) n = room;
  for (let i = 0; i < n; i++) {
    const pt = partPool.spawn();
    const a = Math.random() * 6.28;
    const s = spd * (0.4 + Math.random() * 0.8);
    pt.x = x;
    pt.y = y;
    pt.vx = Math.cos(a) * s;
    pt.vy = Math.sin(a) * s;
    pt.r = 2 + Math.random() * 2.5;
    pt.color = color;
    pt.life = pt.maxLife = 0.25 + Math.random() * 0.25;
  }
}

function pushCapped(arr, item, max) {
  if (arr.length >= max) arr.shift();
  arr.push(item);
}

function tickFadeList(arr, dt) {
  for (let i = arr.length - 1; i >= 0; i--) {
    if ((arr[i].life -= dt) <= 0) arr.splice(i, 1);
  }
}

function collectKilledEnemyVfx() {
  const maxBursts = perf.burstCap;
  const maxDecals = perf.decalCap;

  for (let i = 0; i < enemyPool.active.length; i++) {
    const e = enemyPool.active[i];
    if (e.alive || e.boss || e._vfxCollected) continue;
    e._vfxCollected = true;
    pushCapped(deathBursts, {
      x: e.x, y: e.y, r: e.r, color: e.color, elite: e.elite,
      life: e.elite ? 0.34 : 0.22, maxLife: e.elite ? 0.34 : 0.22
    }, maxBursts);

    if (e.elite) {
      pushCapped(decals, { x: e.x, y: e.y, r: e.r * 1.65, color: e.color, fill: e.color + '44', life: 6.5, maxLife: 6.5 }, maxDecals);
      addShake(4);
    }
  }
}

function updateDashVfx(dt) {
  const p = state.player;
  const dashing = p.dashTimer > 0;
  if (dashing && !wasDashing) {
    pushCapped(arcs, { ring: { x: p.x, y: p.y, r: 34 }, life: 0.2, color: '#8ec5ff' }, 30);
    pushCapped(decals, { x: p.x, y: p.y, r: 16, color: p.cls.color, fill: p.cls.color + '44', life: 3.5, maxLife: 3.5 }, 24);
  }
  wasDashing = dashing;

  if (dashing) {
    if ((dashGhostCd -= dt) <= 0) {
      dashGhostCd = 0.025;
      pushCapped(dashGhosts, {
        x: p.x, y: p.y, color: p.cls.color, life: 0.22, maxLife: 0.22
      }, perf.ghostCap);
    }
  } else {
    dashGhostCd = 0;
  }
}

function renderVfxUnderlay(ctx, inView) {
  for (let i = 0; i < decals.length; i++) {
    const d = decals[i];
    if (!inView(d.x, d.y, d.r + 8)) continue;
    ctx.globalAlpha = Math.min(0.28, (d.life / d.maxLife) * 0.30);
    drawCircle(ctx, d.x, d.y, d.r, d.fill);
    drawRing(ctx, d.x, d.y, d.r * 0.7, d.color, 1.1);
  }
  ctx.globalAlpha = 1;

  for (let i = 0; i < dashGhosts.length; i++) {
    const g = dashGhosts[i];
    const k = g.life / g.maxLife;
    ctx.save();
    ctx.globalAlpha = k * 0.45;
    ctx.translate(g.x, g.y);
    poly(ctx, 0, 0, 1.0, SIL.player, g.color, '#8ec5ff', 1);
    ctx.restore();
  }
}

function renderEnhancedLootBeams(ctx, inView) {
  const t = state.time;
  for (let i = 0; i < lootPool.active.length; i++) {
    const l = lootPool.active[i];
    const rar = l.item.rarity;
    // Mythic beams/reveal are drawn by loot.js (drawMythicDrop)
    if (rar !== 'legendary' || !inView(l.x, l.y, 140)) continue;
    const col = RARITIES[rar].color;
    const pulse = Math.sin(t * 5 + l.bob);

    ctx.save();
    if (rar === 'mythic') {
      ctx.globalAlpha = 0.85;
      drawBeam(ctx, l.x, l.y, 155 + pulse * 14, col);
      drawBeam(ctx, l.x, l.y, 95, '#ffffff');
      drawRing(ctx, l.x, l.y, 16 + pulse * 4, col, 2.2);
      drawRing(ctx, l.x, l.y, 24, '#c56cf0aa', 1.3);
    } else {
      ctx.globalAlpha = 0.72;
      drawBeam(ctx, l.x, l.y, 110 + pulse * 8, col);
      drawRing(ctx, l.x, l.y, 13 + pulse * 2.5, col, 1.6);
    }
    ctx.restore();
  }
}

function renderCombatVfxOverlay(ctx, inView) {
  const lite = perf.level >= 2;
  const dense = perf.denseAoe;

  for (let i = 0; i < deathBursts.length; i++) {
    const d = deathBursts[i];
    if (!inView(d.x, d.y, d.r * 3)) continue;
    const k = d.life / d.maxLife;
    ctx.globalAlpha = k * 0.75;
    drawRing(ctx, d.x, d.y, d.r * (0.7 + (1 - k) * (d.elite ? 1.8 : 1.05)), d.color, d.elite ? 2.6 : 1.5);
    if (d.elite && !lite) drawCircle(ctx, d.x, d.y, d.r * k * 0.7, '#ffffff55');
  }

  for (let i = 0; i < arcs.length; i++) {
    const a = arcs[i];
    if (a.ring && !inView(a.ring.x, a.ring.y, a.ring.r + 12)) continue;
    if (a.cone && !inView(a.cone.x, a.cone.y, a.cone.r + 12)) continue;
    if (a.pts && !inView(a.pts[0].x, a.pts[0].y, 260)) continue;
    ctx.globalAlpha = Math.max(0, a.life / 0.22);
    if (a.ring) {
      drawRing(ctx, a.ring.x, a.ring.y, a.ring.r, a.color, 4);
      if (!lite) drawRing(ctx, a.ring.x, a.ring.y, a.ring.r * 0.92, '#ffffff66', 1.2);
    } else if (a.cone) {
      ctx.beginPath();
      ctx.moveTo(a.cone.x, a.cone.y);
      ctx.arc(a.cone.x, a.cone.y, a.cone.r, a.cone.ang - a.cone.spread * 0.5, a.cone.ang + a.cone.spread * 0.5);
      ctx.closePath();
      if (dense) {
        ctx.strokeStyle = a.color;
        ctx.lineWidth = 3;
        ctx.stroke();
      } else {
        ctx.fillStyle = a.color;
        ctx.fill();
      }
    } else if (a.beam) {
      ctx.strokeStyle = a.color;
      ctx.lineWidth = a.beam.w;
      ctx.beginPath();
      ctx.moveTo(a.beam.x, a.beam.y);
      ctx.lineTo(a.beam.ex, a.beam.ey);
      ctx.stroke();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 4;
      ctx.stroke();
    } else if (a.pts) {
      ctx.strokeStyle = a.color;
      ctx.lineWidth = 2.6;
      ctx.beginPath();
      ctx.moveTo(a.pts[0].x, a.pts[0].y);
      for (let j = 1; j < a.pts.length; j++) ctx.lineTo(a.pts[j].x, a.pts[j].y);
      ctx.stroke();
    }
  }

  for (let i = 0; i < impacts.length; i++) {
    const im = impacts[i];
    if (!inView(im.x, im.y, im.r + 24)) continue;
    const k = im.life / im.maxLife;
    ctx.globalAlpha = k;
    drawRing(ctx, im.x, im.y, im.r * (1.28 - k * 0.45), im.color, im.crit ? 2.8 : 1.5);
    if (im.crit) {
      if (!lite) drawRing(ctx, im.x, im.y, im.r * (0.7 + (1 - k) * 0.65), '#ffffff', 1.3);
      ctx.strokeStyle = '#ffd700';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(im.x - Math.cos(im.ang) * 18, im.y - Math.sin(im.ang) * 18);
      ctx.lineTo(im.x + Math.cos(im.ang) * 18, im.y + Math.sin(im.ang) * 18);
      if (!lite) {
        ctx.moveTo(im.x - Math.sin(im.ang) * 12, im.y + Math.cos(im.ang) * 12);
        ctx.lineTo(im.x + Math.sin(im.ang) * 12, im.y - Math.cos(im.ang) * 12);
      }
      ctx.stroke();
    }
  }
  ctx.globalAlpha = 1;
}

export function openModal(which) {
  closeAllModals(true);
  state.mode = which;
  if (which === 'quest') {
    openQuestModal();
    return;
  }
  if (which === 'inv') {
    state.newLoot = 0;
    renderInventory();
  } else if (which === 'tree') {
    renderTree();
  } else if (which === 'craft') {
    renderCraft();
  } else if (which === 'codex') {
    renderCodex('ingame-codex-content');
  } else if (which === 'pause') {
    DOM['pause-stats'].innerHTML =
      `<span class="rel-pause-chip">⚔ Kills <b>${state.kills}</b></span>` +
      `<span class="rel-pause-chip">★ Level <b>${state.player.level}</b></span>` +
      `<span class="rel-pause-chip">🔥 Fragments <b>${state.player.flamesGathered}/5</b></span>`;
  }
  DOM[`${which}-modal`]?.classList.add('active');
}

export function closeAllModals(keep = false) {
  ['inv', 'tree', 'craft', 'codex', 'pause', 'npc'].forEach(k => {
    DOM[`${k}-modal`]?.classList.remove('active');
  });
  closeQuestModal();
  if (!keep && state.player) {
    state.mode = 'playing';
    updateHud();
    renderQuestTracker();
  }
}

export function checkEndingReq(req) {
  return state.worldTier >= req.tier &&
    metaSave.fragments[req.frag] >= req.amt &&
    metaSave.bossKills >= req.bosses;
}

export function openEndingModal(victory) {
  state.mode = 'ending';
  const p = state.player;
  const ch = DOM['end-choices'];
  const ret = DOM['btn-return-menu'];
  ch.innerHTML = '';

  const hcLost = !victory && state.gameMode === 'hardcore';
  const ashBonus = Math.max(2, Math.floor((state.time / 25 + state.kills / 35 + p.level) * WorldTierConfig.tiers[state.worldTier].frag));
  grantFrag('ash', ashBonus);
  if (!hcLost) addMetaCurrency(state.runGold, state.runShards + p.level * 2, state.runEssence);
  if (state.time > metaSave.bestTime) metaSave.bestTime = state.time | 0;
  metaSave.runs++;

  if (victory && state.dungeon && state.dungeon.id !== 'none') {
    emitQuestGameplayEvent(OBJECTIVE_TYPES.DUNGEON_CLEAR, { id: state.dungeon.id });
  }
  QuestlineManager.save();
  persistSave();

  const fStr = Object.entries(state.runFrags)
    .filter(([, v]) => v > 0)
    .map(([k, v]) => `+${v} ${k[0].toUpperCase() + k.slice(1)}`)
    .join(' ') || '+0';

  DOM['end-summary'].innerHTML =
    `<div class="stat-pill">Time: <b>${DOM['timer-text'].textContent}</b></div>` +
    `<div class="stat-pill">Slain: <b>${state.kills}</b></div>` +
    `<div class="stat-pill">Vaulted: <b>${hcLost ? 'Gold Lost (HC)' : `+${state.runGold}G / +${state.runShards}S`}</b><br>` +
    `<span style="font-size:11px;color:var(--gold2);">Fragments: ${fStr}</span></div>`;

  if (victory) {
    DOM['end-title'].textContent = 'THE ALTAR OF THE FIRST FLAME';
    DOM['end-sub'].textContent = 'Five Fallen Lords lie silent. True Endings awaken at World Tier V (Flamebearer) with 50 Fragments:';
    ret.style.display = 'inline-block';
    ENDINGS_DATA.forEach(en => {
      const ok = checkEndingReq(en.req);
      const r = en.req;
      const reqStr = `Tier ${r.tier} (${state.worldTier >= r.tier ? '✓' : '✗'}) • ${metaSave.fragments[r.frag]}/${r.amt} ${r.frag[0].toUpperCase() + r.frag.slice(1)}${r.bosses ? ` • ${metaSave.bossKills}/${r.bosses} Bosses` : ''}`;
      const c = document.createElement('div');
      c.className = `card sans ${ok ? '' : 'locked'}`;
      c.innerHTML = `<b style="color:var(--gold2);">${en.name}</b><div style="font-size:12px;color:#ccc;margin:4px 0;">${en.desc}</div><div style="font-size:11px;color:${ok ? '#5effb1' : '#ff8c00'};">${ok ? 'UNLOCKED — Click to Claim Ending' : reqStr}</div>`;
      if (ok) {
        c.onclick = () => {
          unlockLore(en.id);
          if (!metaSave.endings.includes(en.name)) metaSave.endings.push(en.name);
          unlockAchievement(en.name);
          addMetaCurrency(250, 50, 4, { flame: 2, star: 2, void: 2, ash: 10 });
          ch.innerHTML = `<div class="lore-quote" style="grid-column:1/-1;font-size:14px;">${en.text}</div>`;
        };
      }
      ch.appendChild(c);
    });
  } else {
    DOM['end-title'].textContent = 'ASHES TO ASHES';
    DOM['end-sub'].textContent = '"The Flame remembers your footsteps, even when your body turns to dust."';
    ret.style.display = 'inline-block';
  }
  renderQuestTracker();
  DOM['ending-modal'].classList.add('active');
}

export function startRun() {
  sfx.init();
  onResize();
  [enemyPool, projPool, gemPool, lootPool, partPool, textPool].forEach(pl => pl.clear());
  arcs.length = hazards.length = events.length = summons.length = telegraphs.length = impacts.length = bossDeaths.length = cracks.length = decals.length = deathBursts.length = dashGhosts.length = 0;
  wasDashing = false;
  perf.load = 0;
  perf.hold = 0;
  applyPerfPreset(0);

  state.gameMode = document.querySelector('input[name="gmode"]:checked').value;
  state.modeCfg = MODES_CONFIG.find(m => m.id === state.gameMode) || MODES_CONFIG[0];
  state.dungeon = DUNGEONS.find(d => d.id === DOM['dungeon-select'].value) || DUNGEONS[0];
  state.startBiomeIdx = state.biomeIdx = parseInt(DOM['start-biome-select'].value, 10) || 0;

  Object.assign(state, {
    time: 0,
    kills: 0,
    runGold: 0,
    runShards: 0,
    runEssence: 0,
    runFrags: { flame: 0, void: 0, star: 0, ash: 0 },
    nextBiomeTime: CFG.game.BIOME_SEC,
    spawnCd: 0.2,
    bossCd: state.modeCfg.bossCd,
    eventCd: 10,
    enemySpeedMult: state.gameMode === 'daily' && dailyIndex === 0 ? 1.3 : 1,
    apocalypse: false,
    dmgFlash: 0,
    activeBoss: null,
    newLoot: 0,
    banner: null,
    director: { power: 1, dpsEma: 0, killsEma: 0, takenEma: 0, fDmg: 0, fKills: 0, fTaken: 0, tickCd: 0, phaseIdx: -1, flags: {} }
  });

  state.player = createPlayer(CLASSES.find(c => c.id === state.selectedClassId) || CLASSES[0]);
  recalcStats();
  state.camera.x = state.player.x;
  state.camera.y = state.player.y;
  generateWorldProps();
  for (let i = 0; i < 4; i++) spawnWorldEvent();

  resetQuestBridgeForRun();
  QuestlineManager.beginRun();
  const rolledQuest = QuestlineManager.rollRunEncounterCandidate();
  if (rolledQuest) QuestlineManager.discoverQuest(rolledQuest.id);
  const startBiome = BIOMES[state.biomeIdx];
  if (startBiome) emitQuestGameplayEvent(OBJECTIVE_TYPES.BIOME_EXPLORE, { id: startBiome.id, biomeId: startBiome.id });

  DOM['menu-modal'].classList.remove('active');
  DOM['ending-modal'].classList.remove('active');
  state.mode = 'playing';
  sfx.setBiomeTone(BIOMES[state.biomeIdx].musicHz);

  const wt = WorldTierConfig.tiers[state.worldTier];
  showBanner(
    (state.dungeon.id === 'none' ? BIOMES[state.biomeIdx].name : state.dungeon.name).toUpperCase(),
    `Tier ${wt.roman}: ${wt.name} • ${state.modeCfg.name}`,
    BIOMES[state.biomeIdx].fog,
    2.3
  );
  updateHud();
  renderQuestTracker();
}

function update(dt) {
  state.time += dt;
  updateDirector(dt);
  const sc = getScaling();

  if (state.shake > 0) state.shake = Math.max(0, state.shake - dt * 26);
  if (state.dmgFlash > 0) state.dmgFlash = Math.max(0, state.dmgFlash - dt * 2.6);
  if (state.banner && (state.banner.life -= dt) <= 0) state.banner = null;

  const fl = state.director.flags;
  if (sc.ph.idx !== state.director.phaseIdx) {
    state.director.phaseIdx = sc.ph.idx;
    if (sc.ph.idx > 0 && sc.ph.idx < 6) addFeed(`Wave Escalation: ${sc.ph.name}`, '#c9a050');
  }
  if (state.time >= 120 && !fl.e2) { fl.e2 = 1; spawnEnemy('elite'); addFeed('Guaranteed Champion Appears!', '#ffd700'); }
  if (state.time >= 180 && !fl.m3) { fl.m3 = 1; spawnEnemy('mini'); }
  if (state.time >= 240 && !fl.p4) { fl.p4 = 1; spawnElitePack(3); }
  if (state.time >= 270 && !fl.p4b) { fl.p4b = 1; spawnElitePack(3); }
  if (state.time >= 300 && !fl.b5) {
    fl.b5 = 1;
    if (!state.activeBoss?.alive) spawnEnemy(state.worldTier >= 4 && Math.random() < 0.4 ? 'ancient' : 'major');
    state.bossCd = state.modeCfg.bossCd;
  }
  if (!state.apocalypse && state.time >= CFG.game.APOC_SEC) {
    state.apocalypse = true;
    addShake(12);
    addFeed('APOCALYPSE MODE! Crimson Sky, Ash Storms & Endless Bosses!', '#ff2a4b');
    showBanner('APOCALYPSE MODE', 'Density, Elites, Bosses & Rewards Surged', '#ff2a4b', 3.4);
    unlockAchievement('Witness of the Apocalypse');
    for (let i = 0; i < 16; i++) {
      cracks.push({ x: Math.random() * CFG.game.W, y: Math.random() * CFG.game.H, a: Math.random() * 6.28, l: 80 + Math.random() * 140 });
    }
  }

  updateBiomeCycle();
  updatePlayerMovement(dt, getMoveVec());
  updateDashVfx(dt);
  updatePeriodicProcs(dt);

  enemyGrid.clear();
  for (let i = 0; i < enemyPool.active.length; i++) {
    if (enemyPool.active[i].alive) {
      enemyPool.active[i]._vfxCollected = false;
      enemyGrid.insert(enemyPool.active[i]);
    }
  }

  updateWeapons(dt);
  updateSummons(dt);
  updateProjectiles(dt);
  updateTelegraphs(dt);
  updateHazards(dt);
  collectKilledEnemyVfx();
  updateEnemies(dt);
  updateGemsAndLoot(dt);
  updateWorldEvents();
  updateBossDeaths(dt);
  pollGameplayEventsForQuests();

  for (let i = partPool.active.length - 1; i >= 0; i--) {
    const pt = partPool.active[i];
    pt.x += pt.vx * dt;
    pt.y += pt.vy * dt;
    if ((pt.life -= dt) <= 0) partPool.release(i);
  }
  for (let i = textPool.active.length - 1; i >= 0; i--) {
    const t = textPool.active[i];
    t.y += t.vy * dt;
    if ((t.life -= dt) <= 0) textPool.release(i);
  }
  tickFadeList(arcs, dt);
  tickFadeList(impacts, dt);
  tickFadeList(decals, dt);
  tickFadeList(deathBursts, dt);
  tickFadeList(dashGhosts, dt);

  if ((state.spawnCd -= dt) <= 0) {
    state.spawnCd = Math.max(0.12, sc.ph.spawnCd / Math.sqrt(sc.dens));
    const batch = Math.max(1, Math.round(sc.ph.batch * sc.dens));
    for (let b = 0; b < batch; b++) spawnEnemy(Math.random() < sc.eliteChance ? 'elite' : 'normal');
    if (Math.random() < sc.champPackChance * 0.25) spawnElitePack(2);
    if (Math.random() < (state.gameMode === 'relic_hunt' ? 0.05 : 0.015)) spawnEnemy('goblin');
  }

  if ((state.bossCd -= dt) <= 0) {
    state.bossCd = state.apocalypse ? BossScalingConfig.major.apocCd : state.modeCfg.bossCd;
    const ancRoll = state.worldTier >= 3 && Math.random() < (0.22 + state.dungeon.ancient + (state.gameMode === 'mythic_hunt' ? 0.35 : 0));
    const secRoll = state.worldTier >= 4 && state.gameMode === 'mythic_hunt' && Math.random() < 0.2;
    if (!state.activeBoss?.alive) spawnEnemy(secRoll ? 'secret' : ancRoll ? 'ancient' : 'major');
    else if (state.apocalypse || state.gameMode === 'arena') spawnEnemy('mini');
  }

  if ((state.eventCd -= dt) <= 0) {
    state.eventCd = (state.gameMode === 'relic_hunt' ? 12 : 20) * sc.dir.eventCd;
    spawnWorldEvent();
  }
}

function render() {
  const biome = BIOMES[state.biomeIdx];
  const sk = state.shake;
  const t = state.time;
  const ap = state.apocalypse;

  const cam = computeVirtualCamera(viewW, viewH);
  const zoom = cam.zoom;
  const worldW = cam.worldW;
  const worldH = cam.worldH;
  state.camera.zoom = zoom;
  state.camera.worldW = worldW;
  state.camera.worldH = worldH;

  const shakeX = sk ? (Math.random() - 0.5) * sk : 0;
  const shakeY = sk ? (Math.random() - 0.5) * sk : 0;
  const camX = state.camera.x - worldW / 2 + shakeX;
  const camY = state.camera.y - worldH / 2 + shakeY;
  const inView = (x, y, pad) =>
    x >= camX - pad && x <= camX + worldW + pad && y >= camY - pad && y <= camY + worldH + pad;

  ctx.setTransform(viewDpr, 0, 0, viewDpr, 0, 0);
  ctx.fillStyle = ap ? '#19080d' : biome.bg;
  ctx.fillRect(0, 0, viewW, viewH);

  renderParallaxBackground(ctx, camX, camY, viewW, viewH);

  ctx.save();
  ctx.scale(zoom, zoom);
  ctx.translate(-camX, -camY);

  renderWorldBackdrop(ctx, camX, camY, worldW, worldH, inView);
  renderVfxUnderlay(ctx, inView);
  renderHazards(ctx, inView);
  renderTelegraphs(ctx, inView);
  renderWorldEvents(ctx);
  renderEnhancedLootBeams(ctx, inView);
  renderGemsAndLoot(ctx, inView);

  for (let i = 0; i < enemyPool.active.length; i++) {
    const e = enemyPool.active[i];
    if (inView(e.x, e.y, 90)) drawEnemy(ctx, e, t);
  }

  renderBossDeaths(ctx);
  renderWeaponEffects(ctx);
  renderSummons(ctx);
  renderPlayer(ctx, t);
  renderProjectiles(ctx, inView);
  renderCombatVfxOverlay(ctx, inView);

  let lastCol = null;
  for (let i = 0; i < partPool.active.length; i++) {
    const pt = partPool.active[i];
    if (!inView(pt.x, pt.y, 8)) continue; // cull off-screen particles
    const a = pt.life / pt.maxLife;
    if (a <= 0.03) continue;
    ctx.globalAlpha = a;
    if (pt.color !== lastCol) {
      ctx.fillStyle = pt.color;
      lastCol = pt.color;
    }
    ctx.fillRect(pt.x - pt.r / 2, pt.y - pt.r / 2, pt.r, pt.r);
  }
  ctx.globalAlpha = 1;

  // Dynamic lights: capped, merged and distance-trimmed according to quality level
  if (PERF_CFG.lightFilter) {
    lightBase = inView;
    lightN = 0;
    lightCx = camX + worldW * 0.5;
    lightCy = camY + worldH * 0.5;
    const far = Math.max(worldW, worldH) * 0.55;
    lightFar2 = far * far;
    renderDynamicLighting(ctx, camX, camY, worldW, worldH, lightInView);
  } else {
    renderDynamicLighting(ctx, camX, camY, worldW, worldH, inView);
  }
  renderFloatTexts(ctx);
  ctx.globalAlpha = 1;
  ctx.restore();

  if (perf.level < 3) renderWeather(ctx, viewW, viewH);
  renderPostFX(ctx, viewW, viewH);
  renderBanner(ctx, viewW);
  renderJoystick(ctx);
  renderMinimap();
  if (PERF_CFG.showStats) drawPerfStats(ctx);
}

function bindGlobalEvents() {
  initInput({ openModal, closeAllModals, triggerDash });
  initInventoryUI();
  initTreeUI();
  initForgeUI();
  initReliquaryUI();
  initMobileControls();

  [
    ['btn-inv', 'inv'],
    ['btn-tree', 'tree'],
    ['btn-craft', 'craft'],
    ['btn-codex', 'codex'],
    ['btn-pause', 'pause'],
    ['btn-open-inv-p', 'inv'],
    ['btn-open-tree-p', 'tree'],
    ['btn-open-craft-p', 'craft']
  ].forEach(([id, m]) => { $(id).onclick = () => openModal(m); });

  const hudBtns = document.querySelector('.hud-btns');
  if (hudBtns && !document.getElementById('btn-quest')) {
    const qBtn = document.createElement('button');
    qBtn.id = 'btn-quest';
    qBtn.className = 'hud-btn';
    qBtn.textContent = `Quests [${hotkeyConfig.questJournal.toUpperCase()}]`;
    qBtn.onclick = () => openModal('quest');
    hudBtns.appendChild(qBtn);
  }

  window.addEventListener('keydown', e => {
    if (e.repeat) return;
    const tag = document.activeElement?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    const key = e.key?.toLowerCase();

    if (hotkeyListeners.has(key)) {
      hotkeyListeners.get(key)(e);
      return;
    }

    if (key === hotkeyConfig.questJournal && state.player) {
      if (state.mode === 'quest') closeAllModals();
      else if (state.mode === 'playing') openModal('quest');
    } else if (key === 'escape' && state.mode === 'quest') {
      closeAllModals();
    }
  });

  ['btn-close-inv', 'btn-close-tree', 'btn-close-craft', 'btn-close-codex', 'btn-resume-pause']
    .forEach(id => { $(id).onclick = () => closeAllModals(); });

  $('btn-begin-run').onclick = startRun;
  DOM['dash-pill'].onclick = triggerDash;
  $('btn-abandon').onclick = () => { closeAllModals(); openEndingModal(false); };
  DOM['btn-return-menu'].onclick = () => {
    DOM['ending-modal'].classList.remove('active');
    state.mode = 'menu';
    renderMainMenu();
    renderQuestTracker();
    DOM['menu-modal'].classList.add('active');
  };
  $('btn-salvage-junk').onclick = () => {
    salvageJunk();
    clearSelectedItem();
    renderInventory();
    updateHud();
  };
  $('btn-reset-tree').onclick = () => {
    if (state.runGold < 100) return;
    state.runGold -= 100;
    state.player.treePoints += state.player.allocatedNodes.size - 1;
    state.player.allocatedNodes = new Set([0]);
    recalcStats();
    renderTree();
  };
}

function boot() {
  buildUI();
  onResize();
  initQuestlineSystem();
  initQuestUI();
  bindGlobalEvents();
  renderMainMenu();

  let lastT = performance.now();
  let hudT = 0;

  function loop(now) {
    const rawDt = (now - lastT) / 1000;
    const dt = Math.min(rawDt, 0.05);
    lastT = now;
    if (state.mode === 'playing') {
      updatePerf(rawDt);
      update(dt * getMythicTimeScale()); // brief slow-motion during a Mythic drop reveal
      render();
      if ((hudT += dt) >= CFG.ui.HUD_STEP) {
        hudT = 0;
        updateHud();
      }
    } else if (state.player && state.mode !== 'menu') {
      render();
    }
    requestAnimationFrame(loop);
  }

  requestAnimationFrame(loop);
}

boot();