export const unpack = (rows, keys) =>
  rows.map(r => Object.fromEntries(keys.map((k, i) => [k, r[i]])));

export const $ = id => document.getElementById(id);

export const mk = (tag, cls, html) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
};

export const pick = arr => arr[(Math.random() * arr.length) | 0];

export const fmtTime = sec =>
  `${String((sec / 60) | 0).padStart(2, '0')}:${String((sec % 60) | 0).padStart(2, '0')}`;

export class SpatialGrid {
  constructor(w, h, cell) {
    this.cell = cell;
    this.cols = Math.ceil(w / cell);
    this.rows = Math.ceil(h / cell);
    this.b = Array.from({ length: this.cols * this.rows }, () => []);
  }

  clear() {
    for (let i = 0; i < this.b.length; i++) this.b[i].length = 0;
  }

  insert(o) {
    const cx = Math.max(0, Math.min(this.cols - 1, (o.x / this.cell) | 0));
    const cy = Math.max(0, Math.min(this.rows - 1, (o.y / this.cell) | 0));
    this.b[cy * this.cols + cx].push(o);
  }

  query(x, y, r, out) {
    out.length = 0;
    const x0 = Math.max(0, ((x - r) / this.cell) | 0);
    const x1 = Math.min(this.cols - 1, ((x + r) / this.cell) | 0);
    const y0 = Math.max(0, ((y - r) / this.cell) | 0);
    const y1 = Math.min(this.rows - 1, ((y + r) / this.cell) | 0);
    for (let cy = y0; cy <= y1; cy++) {
      for (let cx = x0, off = cy * this.cols; cx <= x1; cx++) {
        const bk = this.b[off + cx];
        for (let i = 0; i < bk.length; i++) out.push(bk[i]);
      }
    }
  }
}

export class Pool {
  constructor(fn, cap) {
    this.fn = fn;
    this.active = [];
    this.free = Array.from({ length: cap }, fn);
  }

  spawn() {
    const o = this.free.length ? this.free.pop() : this.fn();
    o.alive = true;
    this.active.push(o);
    return o;
  }

  release(i) {
    const o = this.active[i];
    o.alive = false;
    this.free.push(o);
    const l = this.active.pop();
    if (i < this.active.length) this.active[i] = l;
  }

  clear() {
    while (this.active.length) {
      const o = this.active.pop();
      o.alive = false;
      this.free.push(o);
    }
  }
}

export const poly = (c, x, y, sc, pts, fill, stroke, lw = 1.5) => {
  c.beginPath();
  c.moveTo(x + pts[0] * sc, y + pts[1] * sc);
  for (let i = 2; i < pts.length; i += 2) {
    c.lineTo(x + pts[i] * sc, y + pts[i + 1] * sc);
  }
  c.closePath();
  if (fill) {
    c.fillStyle = fill;
    c.fill();
  }
  if (stroke) {
    c.strokeStyle = stroke;
    c.lineWidth = lw;
    c.stroke();
  }
};

export const drawCircle = (c, x, y, r, fill, stroke, lw = 2) => {
  c.beginPath();
  c.arc(x, y, r, 0, 6.283);
  if (fill) {
    c.fillStyle = fill;
    c.fill();
  }
  if (stroke) {
    c.strokeStyle = stroke;
    c.lineWidth = lw;
    c.stroke();
  }
};

export const drawRing = (c, x, y, r, color, lw = 2) =>
  drawCircle(c, x, y, r, null, color, lw);

export const drawText = (c, txt, x, y, color, font = 'bold 11px sans-serif', align = 'center') => {
  c.font = font;
  c.textAlign = align;
  c.fillStyle = color;
  c.fillText(txt, x, y);
};

export const drawDiamond = (c, x, y, r, color) =>
  poly(c, x, y, r, [0, -1, 0.8, 0, 0, 1, -0.8, 0], color);

export const drawBeam = (c, x, y, h, color) => {
  const g = c.createLinearGradient(x, y, x, y - h);
  g.addColorStop(0, color + 'cc');
  g.addColorStop(1, color + '00');
  c.fillStyle = g;
  c.fillRect(x - 4, y - h, 8, h);
};

export const SIL = {
  walker:       [0, -13, 6, -9, 10, 2, 6, 13, 2, 8, -2, 13, -6, 9, -10, 2, -6, -9],
  cultist:      [0, -17, 6, -9, 5, -3, 12, 13, 4, 10, -4, 10, -12, 13, -5, -3, -6, -9],
  knight:       [0, -15, 5, -13, 4, -8, 13, -7, 11, 3, 8, 13, -8, 13, -11, 3, -13, -7, -4, -8, -5, -13],
  beast:        [-14, -4, -8, -12, -3, -6, 0, -11, 3, -6, 8, -12, 14, -4, 10, 8, 4, 13, 0, 7, -4, 13, -10, 8],
  champion:     [0, -17, 6, -12, 15, -8, 12, 3, 10, 15, 0, 11, -10, 15, -12, 3, -15, -8, -6, -12],
  goblin:       [-11, -5, -5, -14, 2, -10, 12, -6, 13, 6, 5, 13, -6, 12, -10, 4],
  player:       [0, -16, 6, -10, 12, 4, 7, 15, 0, 11, -7, 15, -12, 4, -6, -10],
  crown:        [-8, 0, -10, -9, -4, -4, 0, -11, 4, -4, 10, -9, 8, 0],
  godrick:      [0, -22, 8, -16, 20, -12, 24, -2, 16, 6, 14, 20, 0, 15, -14, 20, -18, 4, -24, -8, -9, -16],
  astrea:       [0, -23, 5, -14, 9, 4, 13, 22, 0, 16, -13, 22, -9, 4, -5, -14],
  colossus:     [-18, -18, -7, -22, 7, -22, 18, -18, 22, -4, 18, 20, 6, 20, 3, 12, -3, 12, -6, 20, -18, 20, -22, -4],
  matriarch:    [0, -22, 7, -14, 14, -4, 17, 18, 6, 22, 0, 15, -6, 22, -17, 18, -14, -4, -7, -14],
  nameless:     [0, -24, 9, -13, 21, -9, 13, 2, 18, 19, 4, 11, 0, 23, -4, 11, -18, 19, -13, 2, -21, -9, -9, -13],
  vaelor:       [0, -24, 11, -15, 22, -6, 15, 8, 19, 21, 5, 14, 0, 24, -5, 14, -19, 21, -15, 8, -22, -6, -11, -15],
  remnant_echo: [0, -22, 8, -14, 18, 4, 11, 21, 0, 15, -11, 21, -18, 4, -8, -14]
};