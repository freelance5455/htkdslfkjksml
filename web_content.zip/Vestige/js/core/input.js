import { $ } from './utilities.js';
import { sfx } from './audio.js';
import { state } from './game.js';

export const keys = {};
export const joy = { active: false, id: null, sx: 0, sy: 0, dx: 0, dy: 0 };
export const modalMap = { i: 'inv', t: 'tree', c: 'craft', j: 'codex', p: 'pause' };

let initialized = false;

export function initInput({ openModal, closeAllModals, triggerDash }) {
  if (initialized) return;
  initialized = true;

  const canvas = $('gameCanvas');

  window.addEventListener('keydown', e => {
    const k = e.key.toLowerCase();
    keys[k] = true;
    if (state.mode === 'playing') {
      if (k === ' ' || k === 'shift') {
        e.preventDefault();
        triggerDash();
      } else if (modalMap[k]) {
        openModal(modalMap[k]);
      } else if (k === 'escape') {
        openModal('pause');
      }
    } else if (['inv', 'tree', 'craft', 'codex', 'pause'].includes(state.mode)) {
      if (k === 'escape' || modalMap[k] === state.mode) {
        closeAllModals();
      }
    } else if (state.mode === 'levelup' && ['1', '2', '3'].includes(k)) {
      $('upgrade-cards')?.children[+k - 1]?.click();
    }
  });

  window.addEventListener('keyup', e => {
    keys[e.key.toLowerCase()] = false;
  });

  canvas.addEventListener('touchstart', e => {
    sfx.init();
    if (state.mode !== 'playing') return;
    const mobileDash = $('mobile-dash');
    if (mobileDash) mobileDash.style.display = 'block';
    const viewW = canvas.width || window.innerWidth;
    for (const t of e.changedTouches) {
      if (!joy.active && t.clientX < viewW * 0.72) {
        joy.active = true;
        joy.id = t.identifier;
        joy.sx = t.clientX;
        joy.sy = t.clientY;
      }
    }
  }, { passive: true });

  canvas.addEventListener('touchmove', e => {
    if (!joy.active) return;
    for (const t of e.changedTouches) {
      if (t.identifier === joy.id) {
        const dx = t.clientX - joy.sx;
        const dy = t.clientY - joy.sy;
        const d = Math.hypot(dx, dy);
        if (d > 4) {
          const c = Math.min(d, 48) / 48;
          joy.dx = (dx / d) * c;
          joy.dy = (dy / d) * c;
        } else {
          joy.dx = joy.dy = 0;
        }
      }
    }
  }, { passive: true });

  const endTouch = e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joy.id) {
        joy.active = false;
        joy.dx = joy.dy = 0;
      }
    }
  };

  ['touchend', 'touchcancel'].forEach(ev => {
    canvas.addEventListener(ev, endTouch, { passive: true });
  });
}

export function getMoveVec() {
  const dx = (keys.d || keys.arrowright ? 1 : 0) - (keys.a || keys.arrowleft ? 1 : 0) + (joy.active ? joy.dx : 0);
  const dy = (keys.s || keys.arrowdown ? 1 : 0) - (keys.w || keys.arrowup ? 1 : 0) + (joy.active ? joy.dy : 0);
  const l = Math.hypot(dx, dy);
  return l > 0.04 ? [dx / Math.max(1, l), dy / Math.max(1, l), true] : [0, 0, false];
}