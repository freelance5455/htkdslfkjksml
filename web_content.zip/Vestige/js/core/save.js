import { CFG } from './config.js';

export const defaultSave = () => ({
  gold: 120,
  shards: 30,
  essence: 2,
  bestTime: 0,
  unlockedClasses: ['warrior', 'ranger', 'mage'],
  metaRanks: {},
  unlockedLore: ['sundering', 'remnant'],
  achievements: [],
  endings: [],
  runs: 0,
  totalKills: 0,
  bossKills: 0,
  fragments: { flame: 0, void: 0, star: 0, ash: 10 },
  masteries: {
    sword: { xp: 0, lvl: 0 },
    bow: { xp: 0, lvl: 0 },
    dagger: { xp: 0, lvl: 0 },
    staff: { xp: 0, lvl: 0 },
    greatsword: { xp: 0, lvl: 0 }
  },
  unlocks: [],
  equippedRelics: [],
  settings: { sound: true, shake: true, dmgNum: true, autoSalvage: true }
});

export function loadSave() {
  let save = defaultSave();
  try {
    const r = localStorage.getItem(CFG.game.SAVE_KEY);
    if (r) {
      const p = JSON.parse(r);
      const d = defaultSave();
      save = {
        ...d,
        ...p,
        fragments: { ...d.fragments, ...(p.fragments || {}) },
        masteries: { ...d.masteries, ...(p.masteries || {}) },
        settings: { ...d.settings, ...(p.settings || {}) }
      };
    }
  } catch (e) {}
  return save;
}

export let metaSave = loadSave();

export function persistSave() {
  try {
    localStorage.setItem(CFG.game.SAVE_KEY, JSON.stringify(metaSave));
  } catch (e) {}
}

export function resetSave() {
  metaSave = defaultSave();
  persistSave();
  return metaSave;
}

export function addMetaCurrency(g, s, e, frags = null) {
  metaSave.gold += g;
  metaSave.shards += s;
  metaSave.essence += e;
  if (frags) {
    for (const k in frags) {
      metaSave.fragments[k] = (metaSave.fragments[k] || 0) + frags[k];
    }
  }
  persistSave();
}

export const canAfford = cost =>
  Object.entries(cost).every(([k, v]) => (k in metaSave.fragments ? metaSave.fragments[k] : metaSave[k] || 0) >= v);

export function spendCost(cost) {
  if (!canAfford(cost)) return false;
  for (const [k, v] of Object.entries(cost)) {
    if (k in metaSave.fragments) metaSave.fragments[k] -= v;
    else metaSave[k] -= v;
  }
  persistSave();
  return true;
}

export const fmtCost = cost =>
  Object.entries(cost)
    .map(([k, v]) => `${v} ${k[0].toUpperCase() + k.slice(1)}`)
    .join(' + ');

export const hasUnlock = id => metaSave.unlocks.includes(id);

let getRunFrags = null;

export function registerRunFragsGetter(fn) {
  getRunFrags = fn;
}

export function grantFrag(key, amt) {
  if (amt <= 0) return;
  const runFrags = getRunFrags ? getRunFrags() : null;
  if (runFrags) runFrags[key] = (runFrags[key] || 0) + amt;
  metaSave.fragments[key] = (metaSave.fragments[key] || 0) + amt;
}