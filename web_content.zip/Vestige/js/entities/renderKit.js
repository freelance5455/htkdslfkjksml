import { poly, drawCircle, drawDiamond } from '../core/utilities.js';

/*
 * Shared drawing kit for players, enemies, champions and bosses.
 * Everything here draws around the current origin in "base units" so callers
 * can scale a whole sprite once (ctx.scale) instead of multiplying every coordinate.
 */

export const TAU = Math.PI * 2;
export const OUTLINE = '#09070d';

/** Idle / locomotion motion values shared by every character. */
export function idleMotion(t, seed = 0, moving = false) {
  const breath = Math.sin(t * 3.0 + seed);
  return {
    breath,                                              // -1..1 chest rise / fall
    sway: Math.sin(t * (moving ? 10 : 2.1) + seed),      // weapon / cloak sway
    head: Math.sin(t * (moving ? 7 : 1.6) + seed + 1.3), // head look-around
    bob: moving ? -Math.abs(Math.sin(t * 12 + seed)) * 2.2 : breath * -1.1
  };
}

export function groundShadow(ctx, x, y, rx, ry, alpha = 0.44) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = '#040307';
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, TAU);
  ctx.fill();
  ctx.restore();
}

/** Calls cb(x, y, index, angle) for n points orbiting an ellipse. */
export function orbit(n, t, speed, rx, ry, cb, phase = 0) {
  for (let i = 0; i < n; i++) {
    const a = t * speed + phase + (TAU * i) / n;
    cb(Math.cos(a) * rx, Math.sin(a) * ry, i, a);
  }
}

/** One-sided cloak that trails behind a character facing `dir`. */
export function flowCloak(ctx, o) {
  const { dir = 1, fill, stroke = OUTLINE, t = 0, seed = 0, top = -7, width = 8, len = 20, drift = 0, speed = 5, lw = 1.2 } = o;
  const w1 = Math.sin(t * speed + seed);
  const w2 = Math.sin(t * speed * 1.35 + seed + 1.7);
  const back = -dir;
  poly(ctx, 0, 0, 1, [
    dir * 3, top,
    back * 5, top,
    back * (width + drift + w1 * 2.5), top + len * 0.55,
    back * (width * 0.75 + drift * 1.2 + w2 * 3.2), top + len,
    back * width * 0.1 + w1 * 1.5, top + len * 0.88,
    dir * 2, top + len * 0.55
  ], fill, stroke, lw);
}

/** Symmetric mantle with a waving hem (bosses, big robes). */
export function hemCloak(ctx, o) {
  const { fill, stroke = OUTLINE, t = 0, seed = 0, top = -15, w = 18, len = 34, amp = 2.5, speed = 2.6, lw = 2 } = o;
  const a = Math.sin(t * speed + seed) * amp;
  const b = Math.sin(t * speed * 1.4 + seed + 1.3) * amp;
  const m = Math.sin(t * speed * 0.9 + seed + 2.6) * amp;
  poly(ctx, 0, 0, 1, [
    -w * 0.65, top, w * 0.65, top,
    w * 1.4 + a, top + len * 0.7,
    w * 0.8 + b, top + len,
    m, top + len * 0.9,
    -w * 0.8 - b, top + len,
    -w * 1.4 - a, top + len * 0.7
  ], fill, stroke, lw);
}

export function drawPauldron(ctx, x, y, r, fill, stroke = OUTLINE, spike = null, side = 1) {
  if (spike) poly(ctx, x, y, 1, [-r * 0.5, -r * 0.6, side * r * 0.5, -r * 2.1, r * 0.5, -r * 0.6], spike, stroke, 1.2);
  drawCircle(ctx, x, y, r, fill, stroke, 1.4);
}

export function drawRune(ctx, x, y, r, color, rot = 0) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  drawCircle(ctx, 0, 0, r * 1.9, color + '33');
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(0, -r); ctx.lineTo(r, 0); ctx.lineTo(0, r); ctx.lineTo(-r, 0); ctx.closePath();
  ctx.moveTo(0, -r * 0.55); ctx.lineTo(0, r * 0.55);
  ctx.moveTo(-r * 0.5, 0); ctx.lineTo(r * 0.5, r * 0.35);
  ctx.stroke();
  ctx.restore();
}

export function drawSkull(ctx, x, y, r, bone = '#d8d2c5', glow = '#5effb1') {
  drawCircle(ctx, x, y, r * 1.7, glow + '33');
  drawCircle(ctx, x, y - r * 0.1, r, bone, OUTLINE, 1);
  ctx.fillStyle = bone;
  ctx.fillRect(x - r * 0.55, y + r * 0.5, r * 1.1, r * 0.7);
  ctx.fillStyle = '#0b0810';
  ctx.fillRect(x - r * 0.6, y - r * 0.3, r * 0.45, r * 0.5);
  ctx.fillRect(x + r * 0.15, y - r * 0.3, r * 0.45, r * 0.5);
  ctx.fillStyle = glow;
  ctx.fillRect(x - r * 0.45, y - r * 0.15, r * 0.2, r * 0.2);
  ctx.fillRect(x + r * 0.25, y - r * 0.15, r * 0.2, r * 0.2);
}

/** Glowing wisp with a fading tail pointing along tailAng. */
export function drawWisp(ctx, x, y, r, color, tailAng) {
  for (let k = 3; k >= 1; k--) {
    drawCircle(
      ctx,
      x + Math.cos(tailAng) * k * r * 1.15,
      y + Math.sin(tailAng) * k * r * 0.85,
      r * (1 - k * 0.2),
      color + (k === 1 ? '88' : k === 2 ? '55' : '33')
    );
  }
  drawCircle(ctx, x, y, r, color);
  drawCircle(ctx, x, y, r * 0.45, '#ffffff');
}

/** Bow facing +x. pull draws the string back, arrow nocks an arrow. */
export function drawBowShape(ctx, rad, o = {}) {
  const { wood = '#b5835a', string = '#d9ecffcc', pull = 0, arrow = false, glow = null, lw = 3.2 } = o;
  const ang = 1.15;
  const tx = Math.cos(ang) * rad;
  const ty = Math.sin(ang) * rad;
  ctx.save();
  ctx.lineCap = 'round';
  if (glow) {
    ctx.globalAlpha *= 0.4;
    ctx.strokeStyle = glow;
    ctx.lineWidth = lw + 5;
    ctx.beginPath();
    ctx.arc(0, 0, rad, -ang, ang);
    ctx.stroke();
    ctx.globalAlpha /= 0.4;
  }
  ctx.strokeStyle = wood;
  ctx.lineWidth = lw;
  ctx.beginPath();
  ctx.arc(0, 0, rad, -ang, ang);
  ctx.stroke();
  ctx.strokeStyle = string;
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(tx, -ty);
  ctx.lineTo(tx - pull, 0);
  ctx.lineTo(tx, ty);
  ctx.stroke();
  if (arrow) {
    const ax = rad + 9;
    ctx.strokeStyle = '#e8e2d0';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(tx - pull, 0);
    ctx.lineTo(ax, 0);
    ctx.stroke();
    poly(ctx, 0, 0, 1, [ax, -2.6, ax + 6, 0, ax, 2.6], '#e6e4ed', OUTLINE, 1);
  }
  ctx.restore();
}

/** Kite shield centered on the origin. */
export function drawKiteShield(ctx, w, h, o = {}) {
  const { fill = '#57606f', rim = '#dfe4ea', emblem = null, glow = null } = o;
  const pts = [-w, -h * 0.7, w, -h * 0.7, w * 1.08, h * 0.1, 0, h, -w * 1.08, h * 0.1];
  if (glow) drawCircle(ctx, 0, h * 0.1, Math.max(w, h) * 1.1, glow + '22');
  poly(ctx, 0, 0, 1, pts, fill, rim, 2);
  poly(ctx, 0, 0, 0.7, pts, 'rgba(0,0,0,0.22)', rim + '66', 1);
  if (emblem) {
    ctx.strokeStyle = emblem;
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(0, -h * 0.5); ctx.lineTo(0, h * 0.6);
    ctx.moveTo(-w * 0.55, -h * 0.12); ctx.lineTo(w * 0.55, -h * 0.12);
    ctx.stroke();
  }
}

/** Blade pointing up (-y) from a hand at the origin. */
export function drawBlade(ctx, len, w, fill, stroke, guard) {
  ctx.fillStyle = '#4a3524';
  ctx.fillRect(-1.3, 1.5, 2.6, 6);
  ctx.fillStyle = guard;
  ctx.fillRect(-w * 1.8, -2, w * 3.6, 3.5);
  poly(ctx, 0, 0, 1, [-w, -2, w, -2, w * 0.8, -len * 0.9, 0, -len, -w * 0.8, -len * 0.9], fill, stroke, 1.4);
  ctx.strokeStyle = '#ffffff66';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, -4);
  ctx.lineTo(0, -len * 0.85);
  ctx.stroke();
}

/** Orbiting diamonds (shards, gems, motes). */
export function drawShardOrbit(ctx, n, t, speed, rx, ry, size, colors, yOff = 0, phase = 0) {
  orbit(n, t, speed, rx, ry, (x, y, i) => drawDiamond(ctx, x, y + yOff, size, colors[i % colors.length]), phase);
}
