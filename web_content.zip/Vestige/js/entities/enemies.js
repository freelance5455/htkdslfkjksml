import { CFG } from '../core/config.js';
import { pick, poly, drawCircle, drawRing, drawDiamond, drawBeam } from '../core/utilities.js';
import { metaSave, hasUnlock, grantFrag } from '../core/save.js';
import {
  state,
  viewW,
  viewH,
  enemyGrid,
  qBuf,
  enemyPool,
  gemPool,
  arcs,
  hazards,
  impacts,
  addShake,
  spawnParticles
} from '../core/game.js';

import { BOSSES, BossScalingConfig, ELITE_MODS, FACTIONS } from '../data/bossData.js';
import { WEAPONS_DEF } from '../data/classes.js';
import { DirectorConfig } from '../data/worldTierData.js';
import { BIOMES } from '../world/biomes.js';

import { damagePlayer } from './player.js';
import * as championsSys from './champions.js';
import { drawBossBody, updateBossBehavior, grantBossRewards, drawRuneCircle } from './bosses.js';
import {
  OUTLINE, idleMotion, groundShadow, orbit, flowCloak, drawPauldron, drawRune, drawSkull,
  drawBowShape, drawKiteShield, drawBlade, drawShardOrbit
} from './renderKit.js';
import { addTelegraph, spawnEnemyProj } from './projectiles.js';
import { generateLootItem, dropLoot } from './loot.js';

import { getScaling } from '../systems/worldtiers.js';
import { addMasteryXp } from '../systems/mastery.js';
import { unlockAchievement } from '../systems/achievements.js';
import { addFeed, showBanner } from '../ui/notifications.js';

export const ENEMY_BALANCE_CFG = {
  contactDmgMult: 1.35,
  spawnCurve: {
    introEndSec: 30,       // 0:00-0:30: 3-5 nearby enemies
    introMinNearby: 3,
    introMaxNearby: 5,
    introOverflowChance: 0.3,
    rampEndSec: 60,        // 0:30-1:00: gradual ramp 5 -> 16 nearby
    rampMaxNearby: 16,
    midEndSec: 120,        // 1:00-2:00: introduce elites, up to 34 nearby
    midMaxNearby: 34,
    midEliteFloor: 0.09,
    lateEliteBase: 0.16,   // 2:00+: escalating elite & champion frequency
    lateEliteSlope: 1 / 520,
    lateEliteCap: 0.38,
    lateChampBase: 0.22,
    lateChampSlope: 1 / 460,
    lateChampCap: 0.50,
    lateAggroCdMult: 0.78,
    lateSpeedBonus: 0.14
  },
  antiAfk: {
    moveDistThresh: 26,
    triggerSec: 2.2,
    maxStillSec: 9.0,
    punishCd: 2.6,
    maxContactBonus: 0.75,
    maxSpeedBonus: 0.38,
    maxAggroMult: 0.65,
    maxBudgetBonus: 4,     // extra simultaneous attackers granted while the player stands still
    hunterPool: ['hound', 'archer', 'priest', 'caller', 'stalker']
  },
  threatPools: {
    throne:   ['knight', 'spearman', 'bulwark', 'archer', 'priest', 'hound'],
    hollow:   ['walker', 'hound', 'priest', 'caller', 'archer', 'cultist'],
    choir:    ['archer', 'priest', 'cultist', 'caller', 'hound'],
    covenant: ['knight', 'spearman', 'bulwark', 'hound', 'archer', 'caller'],
    veiled:   ['archer', 'stalker', 'hound', 'caller', 'priest', 'cultist']
  }
};

/* ==================== ENEMY ENGAGEMENT SYSTEM ====================
 * Every enemy always detects, chases and surrounds the player (no aggro radius).
 * Actually *attacking* is a privilege: an enemy whose cooldown is ready calls
 * requestAttack(); the engagement manager grants a limited number of slots
 * (the global attack budget, scaled by World Tier). Everyone else repositions,
 * circles, advances or holds until a slot frees up.
 *
 * Attack lifecycle:  IDLE --(slot granted)--> TELL --(commit)--> ATTACK --> IDLE (cooldown)
 */
export const ENGAGEMENT_CFG = {
  // Simultaneous attackers per World Tier (index 0 = Tier I)
  budgetByTier: [3, 5, 7, 10, 15],
  // Slot hand-out pacing: prevents many enemies from committing on the same frame
  maxGrantsPerBatch: 2,
  grantStagger: 0.1,
  // A slot that cannot be used (target out of range) is returned after this long
  maxSlotLease: 2.5,
  // Late-game FPS safety valve: shrink the budget when the pool is huge
  perf: { enemyThreshold: 240, budgetScale: 0.8, minBudget: 3 },
  // Touching the player without a committed attack only grazes
  grazeMult: 0.35,
  contactInterval: 0.45,
  // Cooldown multipliers (champions / elites attack more often)
  eliteCooldownMult: 0.82,
  championCooldownMult: 0.7,
  cooldownJitter: 0.1,
  // Fallback cooldowns for enemies without an archetype (melee 1.5-2.0s)
  kindCooldown: { walker: 1.9, knight: 1.7, cultist: 1.9, beast: 1.6, champion: 1.6 },
  defaultCooldown: 1.8,
  // Soft holding ring that unslotted melee enemies circle at (relative to the player)
  ringBase: 72,
  ringVar: 88,
  ringBand: 28
};

const ENG = { IDLE: 0, TELL: 1, ATTACK: 2 };

// Per-role attack profile.
//  range   : max distance at which this enemy wants to attack (an attack range, NOT an aggro radius)
//  tell    : seconds of visible wind-up before committing
//  active  : seconds the enemy stays "committed" (slot is held) after the attack fires
//  budget  : whether it consumes an attacker slot (support utility casts do not)
//  advance : melee-style movement (hold ring / circle while waiting, strike forward when allowed)
//  strikeSpd: speed multiplier while committed
//  ai      : ARCHETYPE_AI handler fired on commit
export const ENEMY_ATTACK_PROFILES = {
  reach:    { id: 'reach',    ai: 'reach',    range: 245, tell: 0.34, active: 0.50, budget: true,  advance: false, strikeSpd: 0 },
  ranged:   { id: 'ranged',   ai: 'ranged',   range: 420, tell: 0.38, active: 0.45, budget: true,  advance: false, strikeSpd: 0 },
  support:  { id: 'support',  ai: 'support',  range: 560, tell: 0.45, active: 0.25, budget: false, advance: false, strikeSpd: 0 },
  summoner: { id: 'summoner', ai: 'summoner', range: 560, tell: 0.50, active: 0.35, budget: true,  advance: false, strikeSpd: 0 },
  tank:     { id: 'tank',     ai: 'tank',     range: 300, tell: 0.42, active: 0.70, budget: true,  advance: true,  strikeSpd: 0.5 },
  rush:     { id: 'rush',     ai: 'rush',     range: 280, tell: 0.30, active: 0.45, budget: true,  advance: true,  strikeSpd: 1.0 },
  ambush:   { id: 'ambush',   ai: 'ambush',   range: 380, tell: 0.35, active: 0.60, budget: true,  advance: true,  strikeSpd: 0.4 },
  melee:    { id: 'melee',    ai: 'melee',    range: 200, tell: 0.34, active: 0.80, budget: true,  advance: true,  strikeSpd: 1.8 },
  elite:    { id: 'elite',    ai: 'elite',    range: 390, tell: 0.35, active: 0.60, budget: true,  advance: true,  strikeSpd: 1.0 }
};

const engagement = {
  budget: 3,
  used: 0,
  grantTimer: 0,
  queue: []
};

export function getEngagementStats() {
  return { budget: engagement.budget, attackers: engagement.used, waiting: engagement.queue.length };
}

function getAttackBudget(afk) {
  const E = ENGAGEMENT_CFG;
  const sc = getScaling();
  let budget;
  if (sc && Number.isFinite(sc.attackBudget)) {
    budget = sc.attackBudget;
  } else {
    const tier = Math.min(E.budgetByTier.length, Math.max(1, Math.round(Number(state.worldTier) || 1)));
    budget = E.budgetByTier[tier - 1];
  }
  if (enemyPool.active.length >= E.perf.enemyThreshold) {
    budget = Math.max(E.perf.minBudget, Math.round(budget * E.perf.budgetScale));
  }
  return budget + (afk ? afk.budget : 0);
}

// Frame start: recount live slot holders (robust against deaths / pool resets), refresh the budget.
function beginEngagementFrame(dt, afk) {
  let used = 0;
  const act = enemyPool.active;
  for (let i = 0; i < act.length; i++) {
    const e = act[i];
    if (!e.hasSlot) continue;
    if (e.alive) used++;
    else e.hasSlot = false;
  }
  engagement.used = used;
  engagement.budget = getAttackBudget(afk);
  if (engagement.grantTimer > 0) engagement.grantTimer -= dt;
  engagement.queue.length = 0;
}

/**
 * Enemy asks permission to attack.
 * Returns true if it may attack right now (already holds a slot, or is a non-budget utility cast).
 * Otherwise the enemy is queued and the manager decides at the end of the frame
 * (see resolveAttackQueue); the enemy will see hasSlot = true next frame if it was chosen.
 */
export function requestAttack(e, d) {
  const prof = e.prof;
  if (!prof || !prof.budget || e.hasSlot) return true;
  if (!e.queued) {
    e.queued = true;
    engagement.queue.push(e);
  }
  // Priority: waiting longest, then mini-bosses/elites, then closeness to the player
  e.engScore =
    e.waitT +
    (e.role === 'mini' || e.invader ? 4 : e.elite ? 1.2 : 0) +
    (1 - Math.min(1, d / 700)) * 0.8 +
    Math.random() * 0.15;
  return false;
}

export function releaseAttackSlot(e) {
  if (e.hasSlot) {
    e.hasSlot = false;
    engagement.used = Math.max(0, engagement.used - 1);
  }
}

function byScoreDesc(a, b) {
  return b.engScore - a.engScore;
}

// Frame end: the engagement manager hands out free slots to the best requesters.
function resolveAttackQueue() {
  const q = engagement.queue;
  if (!q.length) return;
  const E = ENGAGEMENT_CFG;
  let free = engagement.budget - engagement.used;
  if (free > 0 && engagement.grantTimer <= 0) {
    if (q.length > 1) q.sort(byScoreDesc);
    let grants = 0;
    for (let i = 0; i < q.length && free > 0 && grants < E.maxGrantsPerBatch; i++) {
      const e = q[i];
      if (!e.alive || e.hasSlot) continue;
      e.hasSlot = true;
      e.slotT = E.maxSlotLease;
      e.waitT = 0;
      engagement.used++;
      free--;
      grants++;
    }
    if (grants > 0) engagement.grantTimer = E.grantStagger;
  }
  for (let i = 0; i < q.length; i++) q[i].queued = false;
  q.length = 0;
}

function resetCooldown(e, aggroMult) {
  const J = ENGAGEMENT_CFG.cooldownJitter;
  e.currentCooldown = e.attackCooldown * aggroMult * (1 - J + Math.random() * J * 2);
}

function beginTell(e, prof) {
  e.engState = ENG.TELL;
  e.tellMax = e.tellT = prof.tell * (e.elite ? 0.85 : 1);
}

function endAttack(e, aggroMult, cooldown) {
  releaseAttackSlot(e);
  e.engState = ENG.IDLE;
  e.tellT = 0;
  if (cooldown !== undefined) e.currentCooldown = cooldown;
  else resetCooldown(e, aggroMult);
}

// One state machine for every non-boss attacker (archetypes, elites, plain melee grunts).
function updateEngagement(e, dt, dx, dy, d, aggroMult) {
  const prof = e.prof;
  if (e.currentCooldown > 0) e.currentCooldown -= dt;

  if (e.engState === ENG.IDLE) {
    if (e.currentCooldown > 0) {
      e.waitT = 0;
      return;
    }
    if (d > prof.range) {
      // Holding a slot but not yet in range: keep advancing; give the slot back if it goes stale
      if (e.hasSlot && (e.slotT -= dt) <= 0) endAttack(e, aggroMult, 0.4);
      return;
    }
    if (prof.budget && !e.hasSlot) {
      e.waitT += dt;
      requestAttack(e, d); // decided at the end of the frame
      return;
    }
    beginTell(e, prof);
    return;
  }

  if (e.engState === ENG.TELL) {
    if ((e.tellT -= dt) > 0) return;
    const fired = ARCHETYPE_AI[prof.ai](e, dx, dy, d);
    if (!fired) {
      endAttack(e, aggroMult, 0.38);
      return;
    }
    e.engState = ENG.ATTACK;
    e.attackT = prof.active;
    e.contactCd = 0; // a committed strike may hit immediately
    return;
  }

  // ENG.ATTACK: committed
  if ((e.attackT -= dt) <= 0) endAttack(e, aggroMult);
}

function initEngagement(e, curve) {
  const E = ENGAGEMENT_CFG;
  e.engState = ENG.IDLE;
  e.tellT = 0;
  e.tellMax = 0;
  e.attackT = 0;
  e.hasSlot = false;
  e.slotT = 0;
  e.waitT = 0;
  e.queued = false;
  e.engScore = 0;
  e.contactCd = 0;
  e.circleDir = Math.random() < 0.5 ? -1 : 1;
  e.circleT = 1 + Math.random() * 3;
  e.ringR = e.r + E.ringBase + Math.random() * E.ringVar;

  if (e.boss || e.goblin) {
    e.prof = null;
    e.attackCooldown = 0;
    e.currentCooldown = 0;
    return;
  }

  e.prof = e.elite && e.mod
    ? ENEMY_ATTACK_PROFILES.elite
    : ENEMY_ATTACK_PROFILES[e.arch ? e.arch.role : 'melee'] || ENEMY_ATTACK_PROFILES.melee;

  const base = e.arch ? e.arch.attackCooldown : (E.kindCooldown[e.kind] ?? E.defaultCooldown);
  const mult =
    e.kind === 'champion' || e.role === 'mini' || e.invader ? E.championCooldownMult :
    e.elite ? E.eliteCooldownMult : 1;
  e.attackCooldown = base * mult;
  // Keep the original staggered opening delay so a fresh wave never fires in unison
  e.currentCooldown = (1.2 + Math.random() * 0.8) * curve.aggroMult;
}

/* ==================== ARCHETYPES ==================== */

// attackCooldown (seconds): melee 1.5-2.0, ranged 2.0-3.0, support 3.0-5.0. `cd` kept as a legacy alias.
export const ENEMY_ARCHETYPES = {
  spearman: { name: 'Ash Spearman',  r: 15, hpM: 1.25, spd: 90,  dmgM: 1.25, minD: 145, maxD: 225, cd: 2.0, attackCooldown: 2.0, role: 'reach',    color: '#d4a373' },
  archer:   { name: 'Void Archer',   r: 13, hpM: 0.92, spd: 88,  dmgM: 1.22, minD: 205, maxD: 330, cd: 2.2, attackCooldown: 2.2, role: 'ranged',   color: '#9e7bff' },
  priest:   { name: 'Hollow Priest', r: 14, hpM: 1.15, spd: 78,  dmgM: 0.95, minD: 170, maxD: 270, cd: 3.2, attackCooldown: 3.2, role: 'support',  color: '#5effb1' },
  caller:   { name: 'Corpse Caller', r: 16, hpM: 1.35, spd: 72,  dmgM: 1.00, minD: 195, maxD: 300, cd: 4.2, attackCooldown: 4.2, role: 'summoner', color: '#7ed6df' },
  bulwark:  { name: 'Iron Bulwark',  r: 19, hpM: 2.35, spd: 66,  dmgM: 1.35, minD: 0,   maxD: 0,   cd: 2.0, attackCooldown: 2.0, role: 'tank',     color: '#a4b0be', shieldRatio: 0.35 },
  hound:    { name: 'Blood Hound',   r: 12, hpM: 0.85, spd: 158, dmgM: 1.20, minD: 0,   maxD: 0,   cd: 1.6, attackCooldown: 1.6, role: 'rush',     color: '#e03c4f' },
  stalker:  { name: 'Void Stalker',  r: 14, hpM: 1.18, spd: 118, dmgM: 1.40, minD: 0,   maxD: 0,   cd: 2.0, attackCooldown: 2.0, role: 'ambush',   color: '#c56cf0' }
};

const afkTracker = { x: 0, y: 0, stillSec: 0, punishCd: 0, lastT: -1 };

function getCurveState(t = state.time) {
  const C = ENEMY_BALANCE_CFG.spawnCurve;
  if (t < C.introEndSec) {
    return {
      maxNearby: C.introMaxNearby,
      minNearby: C.introMinNearby,
      overflowChance: C.introOverflowChance,
      allowElite: false,
      eliteFloor: 0,
      champChance: 0,
      aggroMult: 1.15,
      spdBonus: 0
    };
  }
  if (t < C.rampEndSec) {
    const k = (t - C.introEndSec) / (C.rampEndSec - C.introEndSec);
    return {
      maxNearby: Math.round(C.introMaxNearby + k * (C.rampMaxNearby - C.introMaxNearby)),
      minNearby: C.introMaxNearby,
      overflowChance: 0.55,
      allowElite: false,
      eliteFloor: 0,
      champChance: 0,
      aggroMult: 1.02,
      spdBonus: k * 0.05
    };
  }
  if (t < C.midEndSec) {
    return {
      maxNearby: C.midMaxNearby,
      minNearby: C.rampMaxNearby,
      overflowChance: 0.8,
      allowElite: true,
      eliteFloor: C.midEliteFloor,
      champChance: 0.08,
      aggroMult: 0.92,
      spdBonus: 0.06
    };
  }
  const lateSec = t - C.midEndSec;
  return {
    maxNearby: Infinity,
    minNearby: C.midMaxNearby,
    overflowChance: 1,
    allowElite: true,
    eliteFloor: Math.min(C.lateEliteCap, C.lateEliteBase + lateSec * C.lateEliteSlope),
    champChance: Math.min(C.lateChampCap, C.lateChampBase + lateSec * C.lateChampSlope),
    aggroMult: Math.max(0.65, C.lateAggroCdMult - lateSec * 0.0004),
    spdBonus: C.lateSpeedBonus + Math.min(0.14, lateSec * 0.0004)
  };
}

function countNearbyActive(px, py, radius = 640) {
  const r2 = radius * radius;
  let count = 0;
  for (let i = 0; i < enemyPool.active.length; i++) {
    const e = enemyPool.active[i];
    if (e.alive && !e.boss && (e.x - px) ** 2 + (e.y - py) ** 2 <= r2) count++;
  }
  return count;
}

function updateAntiAfk(dt) {
  const p = state.player;
  const A = ENEMY_BALANCE_CFG.antiAfk;
  if (state.time < afkTracker.lastT) {
    afkTracker.stillSec = 0;
    afkTracker.punishCd = 0;
    afkTracker.x = p.x;
    afkTracker.y = p.y;
  }
  afkTracker.lastT = state.time;

  const moved = Math.hypot(p.x - afkTracker.x, p.y - afkTracker.y);
  if (moved > A.moveDistThresh) {
    afkTracker.x = p.x;
    afkTracker.y = p.y;
    afkTracker.stillSec = Math.max(0, afkTracker.stillSec - dt * 2.5);
  } else {
    afkTracker.stillSec = Math.min(A.maxStillSec, afkTracker.stillSec + dt);
  }

  if (afkTracker.stillSec >= A.triggerSec) {
    if ((afkTracker.punishCd -= dt) <= 0) {
      afkTracker.punishCd = A.punishCd;
      const hunterKind = pick(A.hunterPool);
      spawnEnemy('normal', null, null, hunterKind);
      if (afkTracker.stillSec >= A.triggerSec * 2) {
        spawnEnemy(state.time >= ENEMY_BALANCE_CFG.spawnCurve.rampEndSec ? 'elite' : 'normal', null, null, 'hound');
        addTelegraph('circle', p.x, p.y, 12 * getScaling().dmg, 0.95, '#ff4757', { r: 62 });
      }
    }
  }
}

function getAfkMultipliers() {
  const A = ENEMY_BALANCE_CFG.antiAfk;
  if (afkTracker.stillSec < A.triggerSec) return { dmg: 1, spd: 1, aggro: 1, budget: 0 };
  const ratio = Math.min(1, (afkTracker.stillSec - A.triggerSec) / (A.maxStillSec - A.triggerSec));
  return {
    dmg: 1 + ratio * A.maxContactBonus,
    spd: 1 + ratio * A.maxSpeedBonus,
    aggro: 1 - ratio * (1 - A.maxAggroMult),
    budget: Math.round(ratio * A.maxBudgetBonus)
  };
}

function getSpawnPos(nearView, cx, cy) {
  const p = state.player;
  const ang = Math.random() * 6.283;
  const dist = nearView ? 340 : Math.max(viewW, viewH) * 0.58 + 70;
  return [
    cx ?? Math.max(60, Math.min(CFG.game.W - 60, p.x + Math.cos(ang) * dist)),
    cy ?? Math.max(60, Math.min(CFG.game.H - 60, p.y + Math.sin(ang) * dist))
  ];
}

export function spawnEnemy(role = 'normal', cx = null, cy = null, forcedKind = null) {
  const isBoss = role === 'major' || role === 'ancient' || role === 'secret';
  if (enemyPool.active.length >= CFG.game.MAX_ENEMIES && !isBoss && role !== 'mini') return null;

  const p = state.player;
  const curve = getCurveState(state.time);
  const isAmbientWave = cx === null && cy === null && forcedKind === null && !isBoss && role !== 'mini' && role !== 'goblin' && role !== 'invader';

  if (isAmbientWave) {
    if (role === 'elite' && !curve.allowElite) role = 'normal';
    else if (role === 'normal' && curve.allowElite && Math.random() < curve.eliteFloor) role = 'elite';

    if (Number.isFinite(curve.maxNearby)) {
      const nearby = countNearbyActive(p.x, p.y, 640);
      if (nearby >= curve.maxNearby) return null;
      if (nearby >= curve.minNearby && Math.random() > curve.overflowChance) return null;
    }
  }

  const biome = BIOMES[state.biomeIdx];
  const sc = getScaling();
  const [x, y] = getSpawnPos(isBoss || role === 'mini', cx, cy);

  const e = enemyPool.spawn();
  const isEl = role === 'elite' || role === 'mini' || role === 'invader';
  const mod = isEl ? pick(ELITE_MODS) : null;

  Object.assign(e, {
    x,
    y,
    role,
    hitFlash: 0,
    atkCd: (1.2 + Math.random() * 0.8) * curve.aggroMult,
    phase: 1,
    goblin: role === 'goblin',
    invader: role === 'invader',
    elite: isEl,
    boss: isBoss,
    mod,
    arch: null,
    faction: biome.faction,
    shieldHp: 0,
    spawnT: 0,
    buffT: 0,
    lungeT: 0,
    lungeVx: 0,
    lungeVy: 0,
    packId: null,
    seed: Math.random() * 6.28
  });

  if (role === 'goblin') {
    Object.assign(e, {
      kind: 'goblin',
      r: 16,
      maxHp: Math.round(70 * sc.hp),
      speed: 185,
      dmg: 0,
      xp: 15,
      color: '#ffd700',
      fleeAngle: Math.random() * 6.28
    });
    addFeed('A Treasure Goblin scurries across the ash!', '#ffd700');
  } else if (isBoss) {
    const pool = BOSSES.filter(b => (role === 'secret' ? b.secret : !b.secret));
    const bd = role === 'secret' ? pick(pool) : pool[p.bossesDefeated.length % pool.length];
    const B = BossScalingConfig[role];
    const echoHp = hasUnlock('boss_echo') ? 1.3 : 1;
    const prefix = role === 'ancient' ? 'Ancient ' : role === 'secret' ? 'Secret: ' : '';

    Object.assign(e, {
      kind: 'boss',
      bossData: { ...bd, name: `${prefix}${bd.name}` },
      faction: bd.faction,
      r: role === 'ancient' ? Math.max(bd.r, 62) : bd.r,
      maxHp: Math.round(B.hpMult * 22 * sc.hp * echoHp),
      speed: B.spd * sc.spd * state.dungeon.bossSpd,
      dmg: Math.round(11 * B.dmgMult * sc.dmg),
      xp: B.xp,
      color: role === 'ancient' ? '#ffd700' : bd.color,
      spawnT: B.introDur
    });

    state.activeBoss = e;
    addShake(10);
    addFeed(
      `${role === 'secret' ? 'SECRET' : role === 'ancient' ? 'ANCIENT' : 'BOSS'} ENCOUNTER: ${e.bossData.name}`,
      e.color
    );
    showBanner(
      e.bossData.name.toUpperCase(),
      `${FACTIONS[bd.faction].name} • ${role === 'secret' ? 'Secret Lord' : role === 'ancient' ? 'Ancient Lord' : 'Fallen Lord'}`,
      e.color,
      3.2
    );
  } else if (role === 'mini' || role === 'invader') {
    const M = BossScalingConfig.mini;
    const inv = role === 'invader';
    Object.assign(e, {
      kind: 'champion',
      r: inv ? 26 : M.r,
      maxHp: Math.round(M.hpMult * (inv ? 26 : 22) * sc.hp),
      speed: (inv ? 132 : M.spd) * sc.spd,
      dmg: Math.round((inv ? 13 : 11) * M.dmgMult * sc.dmg * ENEMY_BALANCE_CFG.contactDmgMult),
      xp: inv ? 45 : M.xp,
      color: inv ? '#ff2a4b' : mod.color
    });
    if (!inv) {
      addFeed(`MINI-BOSS: ${mod.name} Warden Emerges!`, '#ff8c00');
      showBanner(`${mod.name.toUpperCase()} WARDEN`, 'Mini-Boss Encounter', mod.color, 2.5);
    }
  } else {
    const fPool = ENEMY_BALANCE_CFG.threatPools[biome.faction] || FACTIONS[biome.faction].pool;
    const promoteChamp = isEl && (role === 'elite' || Math.random() < curve.champChance);
    const kind = forcedKind || (promoteChamp ? 'champion' : pick(fPool));
    const arch = ENEMY_ARCHETYPES[kind] || null;
    const baseR = isEl ? 23 : arch ? arch.r : kind === 'knight' ? 16 : kind === 'beast' ? 14 : 13;
    const hpMult = isEl ? 5.0 : arch ? arch.hpM : kind === 'knight' ? 1.35 : 1;
    const baseSpd = arch ? arch.spd : (82 + Math.random() * 36) * (kind === 'beast' ? 1.24 : kind === 'knight' ? 0.88 : 1);

    Object.assign(e, {
      kind,
      arch,
      r: baseR,
      maxHp: Math.round(22 * sc.hp * hpMult),
      speed: baseSpd * sc.spd * (1 + curve.spdBonus) * (mod?.id === 'hasted' ? 1.42 : 1),
      dmg: Math.round(10 * sc.dmg * ENEMY_BALANCE_CFG.contactDmgMult * (isEl ? 1.5 : arch ? arch.dmgM : 1)),
      xp: isEl ? 14 : arch ? 5 : 3,
      color: mod ? mod.color : arch ? arch.color : FACTIONS[biome.faction].color
    });

    if (mod?.id === 'shielded') e.shieldHp = Math.round(e.maxHp * 0.45);
    else if (arch?.shieldRatio) e.shieldHp = Math.round(e.maxHp * arch.shieldRatio);
  }

  initEngagement(e, curve);
  e.hp = e.maxHp;
  return e;
}

// Attack handlers fired when an enemy commits (after its tell). Return false to cancel
// (e.g. the player moved out of range during the tell).
const ARCHETYPE_AI = {
  // Elite mod attacks live in champions.js, which fires when its own atkCd hits 0. The engagement
  // system owns pacing (currentCooldown + slots), so force it ready and fire it once on commit.
  elite: (e, dx, dy, d) => {
    if (d >= 390) return false;
    e.atkCd = 0;
    championsSys.updateEliteBehavior(e, 0, dx, dy);
    return true;
  },
  melee: (e, dx, dy, d) => d <= 230, // strike is the committed forward charge (see moveEnemy)
  reach: (e, dx, dy, d) => {
    if (d > 245) return false;
    addTelegraph('beam', e.x, e.y, e.dmg, 0.72, '#f0cf85', { ang: Math.atan2(dy, dx), len: 235, w: 15 });
    return true;
  },
  ranged: (e, dx, dy, d) => {
    if (d > 420) return false;
    const ba = Math.atan2(dy, dx);
    addTelegraph('beam', e.x, e.y, 0, 0.42, '#9e7bff', { ang: ba, len: 360, w: 6 });
    spawnEnemyProj(e.x, e.y, Math.cos(ba) * 335, Math.sin(ba) * 335, 6, e.dmg, 2.0, '#c780ff');
    return true;
  },
  support: e => {
    enemyGrid.query(e.x, e.y, 175, qBuf);
    for (let i = 0; i < qBuf.length; i++) {
      const a = qBuf[i];
      if (!a.alive) continue;
      a.hp = Math.min(a.maxHp, a.hp + a.maxHp * 0.16);
      a.buffT = 3.2;
    }
    arcs.push({ ring: { x: e.x, y: e.y, r: 175 }, life: 0.25, color: '#5effb1' });
    return true;
  },
  summoner: e => {
    if (enemyPool.active.length >= CFG.game.MAX_ENEMIES - 12) return false;
    const count = Math.random() < 0.4 ? 2 : 1;
    for (let i = 0; i < count; i++) {
      spawnEnemy('normal', e.x + (Math.random() - 0.5) * 52, e.y + (Math.random() - 0.5) * 52, Math.random() < 0.3 ? 'hound' : 'walker');
    }
    spawnParticles(e.x, e.y, '#7ed6df', 8, 95);
    return true;
  },
  tank: (e, dx, dy, d) => {
    enemyGrid.query(e.x, e.y, 135, qBuf);
    for (let i = 0; i < qBuf.length; i++) {
      const a = qBuf[i];
      if (a.alive && a.shieldHp < a.maxHp * 0.2) a.shieldHp = Math.max(a.shieldHp, Math.round(a.maxHp * 0.16));
    }
    arcs.push({ ring: { x: e.x, y: e.y, r: 135 }, life: 0.26, color: '#a4b0be' });
    if (d < 145) addTelegraph('shockwave', e.x, e.y, e.dmg * 1.15, 0.9, '#a4b0be', { r: 120 });
    return true;
  },
  rush: (e, dx, dy, d) => {
    if (d > 280 || d < 46) return false;
    const ba = Math.atan2(dy, dx);
    addTelegraph('beam', e.x, e.y, 0, 0.32, '#e03c4f', { ang: ba, len: 175, w: 12 });
    e.lungeT = 0.24;
    e.lungeVx = Math.cos(ba) * 470;
    e.lungeVy = Math.sin(ba) * 470;
    return true;
  },
  ambush: (e, dx, dy, d) => {
    if (d > 380) return false;
    const p = state.player;
    const ba = Math.atan2(dy, dx);
    spawnParticles(e.x, e.y, '#c56cf0', 10, 120);
    e.x = Math.max(40, Math.min(CFG.game.W - 40, p.x - Math.cos(ba) * 76));
    e.y = Math.max(40, Math.min(CFG.game.H - 40, p.y - Math.sin(ba) * 76));
    spawnParticles(e.x, e.y, '#c56cf0', 10, 120);
    addTelegraph('cone', e.x, e.y, e.dmg, 0.55, '#c56cf0', { r: 112, ang: Math.atan2(p.y - e.y, p.x - e.x), spread: 1.15 });
    return true;
  }
};

/* ==================== MOVEMENT ==================== */

function stepToward(e, dx, dy, d, dist) {
  e.x += (dx / d) * dist;
  e.y += (dy / d) * dist;
}

function tickCircle(e, dt) {
  if ((e.circleT -= dt) <= 0) {
    if (Math.random() < 0.5) e.circleDir = -e.circleDir;
    e.circleT = 2.5 + Math.random() * 3;
  }
}

// Orbit the player at speedFrac of full speed, with an optional radial pull (radial > 0 = inward).
function strafe(e, dt, dx, dy, d, speed, speedFrac, radial) {
  tickCircle(e, dt);
  const nx = dx / d;
  const ny = dy / d;
  const tx = -ny * e.circleDir;
  const ty = nx * e.circleDir;
  e.x += (tx * speedFrac + nx * radial) * speed * dt;
  e.y += (ty * speedFrac + ny * radial) * speed * dt;
}

function moveEnemy(e, dt, dx, dy, d, spdBonus) {
  const spdMult = (e.buffT > 0 ? 1.25 : 1) * spdBonus;
  if (e.goblin) {
    if (d < 340) e.fleeAngle = Math.atan2(-dy, -dx);
    e.x = Math.max(40, Math.min(CFG.game.W - 40, e.x + Math.cos(e.fleeAngle) * e.speed * dt));
    e.y = Math.max(40, Math.min(CFG.game.H - 40, e.y + Math.sin(e.fleeAngle) * e.speed * dt));
    return;
  }
  if (e.lungeT > 0) {
    e.lungeT -= dt;
    e.x += e.lungeVx * dt;
    e.y += e.lungeVy * dt;
    return;
  }

  const speed = e.speed * spdMult;
  const prof = e.prof;

  // Committed enemies: wind up in place (creep forward), then strike / hold their ground
  if (prof) {
    if (e.engState === ENG.TELL) {
      if (prof.advance) stepToward(e, dx, dy, d, speed * 0.2 * dt);
      return;
    }
    if (e.engState === ENG.ATTACK) {
      if (prof.advance) stepToward(e, dx, dy, d, speed * prof.strikeSpd * dt);
      return;
    }
  }

  if (e.arch && e.arch.maxD > 0) {
    if (d < e.arch.minD) {
      stepToward(e, dx, dy, d, -speed * 0.65 * dt);
      return;
    }
    if (d <= e.arch.maxD) {
      // In firing band: circle the player while waiting for an attack slot
      if (!e.hasSlot) strafe(e, dt, dx, dy, d, speed, 0.5, 0);
      return;
    }
  } else if (prof && prof.advance && !e.hasSlot) {
    // Not allowed to attack: advance to the holding ring, then circle / reposition around the player
    const band = ENGAGEMENT_CFG.ringBand;
    if (d <= e.ringR + band) {
      if (d < e.ringR - band) stepToward(e, dx, dy, d, -speed * 0.45 * dt);
      else strafe(e, dt, dx, dy, d, speed, 0.6, Math.max(-1, Math.min(1, (d - e.ringR) / band)) * 0.35);
      return;
    }
  }

  stepToward(e, dx, dy, d, speed * dt);
}

function resolveEnemySeparation(e) {
  enemyGrid.query(e.x, e.y, e.r * 2, qBuf);
  for (let j = 0; j < qBuf.length; j++) {
    const o = qBuf[j];
    if (o === e || !o.alive || o.spawnT > 0) continue;
    const sx = e.x - o.x;
    const sy = e.y - o.y;
    const d2 = sx * sx + sy * sy;
    const md = e.r + o.r;
    if (d2 > 0.01 && d2 < md * md) {
      const dist = Math.sqrt(d2);
      const push = (md - dist) * 0.32;
      e.x += (sx / dist) * push;
      e.y += (sy / dist) * push;
    }
  }
}

export function updateEnemies(dt) {
  const p = state.player;
  updateAntiAfk(dt);
  const curve = getCurveState(state.time);
  const afk = getAfkMultipliers();
  const aggroMult = curve.aggroMult * afk.aggro;

  beginEngagementFrame(dt, afk);

  for (let i = enemyPool.active.length - 1; i >= 0; i--) {
    const e = enemyPool.active[i];
    if (!e.alive) {
      enemyPool.release(i);
      continue;
    }
    if (e.hitFlash > 0) e.hitFlash -= dt;
    if (e.buffT > 0) e.buffT -= dt;
    if (e.contactCd > 0) e.contactCd -= dt;
    if (e.spawnT > 0) {
      if ((e.spawnT -= dt) <= 0) {
        arcs.push({ ring: { x: e.x, y: e.y, r: e.r * 2.4 }, life: 0.32, color: e.color });
        spawnParticles(e.x, e.y, e.color, 26, 220);
        addShake(7);
      }
      continue;
    }

    const dx = p.x - e.x;
    const dy = p.y - e.y;
    const d = Math.hypot(dx, dy) || 1;

    moveEnemy(e, dt, dx, dy, d, afk.spd);
    e.x = Math.max(20, Math.min(CFG.game.W - 20, e.x));
    e.y = Math.max(20, Math.min(CFG.game.H - 20, e.y));

    if (e.boss) {
      updateBossBehavior(e, dt / aggroMult, dx, dy, spawnEnemy);
    } else if (e.prof) {
      updateEngagement(e, dt, dx, dy, d, aggroMult);
    }

    if (e.elite && e.mod && Math.random() < 0.11) {
      const mCol =
        e.mod.id === 'corrupted' ? '#120d17' :
        e.mod.id === 'frozen' ? '#bce2ff' :
        e.mod.id === 'voidtouched' ? '#a55eea' :
        e.mod.id === 'vampiric' ? '#e03c4f' : e.mod.color;
      spawnParticles(e.x + (Math.random() - 0.5) * e.r, e.y + (Math.random() - 0.5) * e.r, mCol, 1, 48);
    }

    resolveEnemySeparation(e);

    if (!e.goblin && d < e.r + p.r) {
      // Bosses keep continuous contact damage. Everyone else only hits hard while committed to an
      // attack; incidental touching just grazes (rate limited).
      if (e.boss || e.contactCd <= 0) {
        const base = e.dmg * (e.buffT > 0 ? 1.2 : 1) * afk.dmg;
        const committed = e.boss || e.engState === ENG.ATTACK;
        damagePlayer(committed ? base : base * ENGAGEMENT_CFG.grazeMult);
        e.contactCd = ENGAGEMENT_CFG.contactInterval;
        if (e.mod?.id === 'vampiric') e.hp = Math.min(e.maxHp, e.hp + e.dmg);
      }
    }
  }

  resolveAttackQueue();
}

export function killEnemy(e) {
  const p = state.player;
  const sc = getScaling();
  const rw = sc.rewardMult;
  const dng = state.dungeon;

  releaseAttackSlot(e);
  e.alive = false;
  state.kills++;
  metaSave.totalKills++;
  state.director.fKills++;

  if (e.packId && typeof championsSys.onElitePackMemberKilled === 'function') {
    championsSys.onElitePackMemberKilled(e);
  }

  if (state.kills % 25 === 0) {
    grantFrag('ash', Math.max(1, Math.round(dng.ashM * sc.fragMult)));
  }

  Object.keys(p.weapons).forEach(wk =>
    addMasteryXp(WEAPONS_DEF[wk].mastery, e.boss ? 35 : e.role === 'mini' ? 15 : e.elite ? 4 : 0.8)
  );

  spawnParticles(e.x, e.y, e.color, e.boss ? 46 : e.elite ? 18 : 7, e.boss ? 280 : 140);
  if (e.elite && !e.boss) {
    impacts.push({ x: e.x, y: e.y, r: 44, color: e.color, life: 0.28, maxLife: 0.28, ang: 0, crit: true });
  }
  if (p.stats.uniques.has('ashenblade')) {
    hazards.push({
      x: e.x,
      y: e.y,
      r: 58 * p.stats.areaPct,
      dmg: p.stats.flatDmg * p.stats.dmgPct * 0.65,
      life: 0.2,
      maxLife: 0.2,
      color: '#ff8c00',
      isEnemy: false
    });
  }

  const healOrb = sc.dir.recovery && Math.random() < DirectorConfig.weak.healDropChance;
  Object.assign(gemPool.spawn(), {
    x: e.x,
    y: e.y,
    val: e.xp,
    magnet: false,
    heal: healOrb,
    color: healOrb ? '#ff4757' : e.xp >= 15 ? '#c56cf0' : e.xp >= 6 ? '#ffd700' : '#6fa8dc'
  });

  if (e.goblin) {
    state.runGold += Math.round(CFG.loot.GOBLIN_GOLD * rw);
    state.runShards += Math.round(5 * rw);
    grantFrag('ash', Math.round(2 * sc.fragMult));
    addFeed('Treasure Goblin Slain! +Gold, Ash & Rare+ Loot!', '#ffd700');
    dropLoot(e.x, e.y, generateLootItem(p.level + state.worldTier, Math.random() < 0.35 ? 'legendary' : 'rare', 0.9));
    unlockAchievement('Goblin Slayer');
  } else if (e.invader) {
    if (metaSave.runRecords) metaSave.runRecords.invadersSlain++;
    grantFrag(pick(['flame', 'void', 'star']), 3);
    addFeed('Invading Champion Slain! Relics & Mythic Spoils Claimed!', '#ff2a4b');
    dropLoot(e.x, e.y, generateLootItem(p.level + state.worldTier + 2, Math.random() < 0.45 ? 'mythic' : 'legendary', 1.5));
  } else if (e.boss || e.role === 'mini') {
    grantBossRewards(e, sc);
  } else if (e.elite) {
    state.runGold += Math.round(15 * rw);
    state.runShards += Math.round(2 * rw);
    if (Math.random() < 0.4) {
      grantFrag(
        e.faction === 'choir' ? 'star' : e.faction === 'veiled' ? 'void' : e.faction === 'throne' ? 'flame' : 'ash',
        Math.max(1, Math.round(sc.fragMult))
      );
    }
    if (Math.random() < CFG.loot.ELITE_DROP) {
      dropLoot(e.x, e.y, generateLootItem(p.level + state.worldTier, null, 0.7));
    }
  } else {
    if (Math.random() < 0.08) state.runGold += Math.round(3 * rw);
    if (Math.random() < CFG.loot.DROP_CHANCE) {
      dropLoot(e.x, e.y, generateLootItem(p.level + state.worldTier));
    }
  }
}

export function drawFactionAccent(c, faction, x, y, r, t, stroke) {
  if (faction === 'throne') {
    c.strokeStyle = stroke;
    c.lineWidth = 1.8;
    c.beginPath();
    c.arc(x, y - r * 0.9, r * 0.55, Math.PI * 0.15, Math.PI * 0.85);
    c.moveTo(x - r * 0.35, y - r * 1.3);
    c.lineTo(x + r * 0.35, y - r * 1.3);
    c.stroke();
  } else if (faction === 'hollow') {
    c.strokeStyle = '#d8d2c5';
    c.lineWidth = 1.4;
    c.beginPath();
    for (let i = -1; i <= 1; i += 2) {
      c.moveTo(x, y - r * 0.2);
      c.lineTo(x + i * r * 0.45, y - r * 0.35);
      c.moveTo(x, y + r * 0.15);
      c.lineTo(x + i * r * 0.4, y);
    }
    c.stroke();
  } else if (faction === 'choir') {
    const a = t * 1.6;
    drawDiamond(c, x + Math.cos(a) * r * 1.15, y + Math.sin(a) * r * 0.7, r * 0.24, '#dbe8ff');
    drawDiamond(c, x - Math.cos(a) * r * 1.1, y - Math.sin(a) * r * 0.7, r * 0.2, '#8fa8ff');
  } else if (faction === 'covenant') {
    c.strokeStyle = '#c8d6e5';
    c.lineWidth = 2;
    c.strokeRect(x - r * 0.7, y - r * 0.45, r * 0.35, r * 0.55);
    c.strokeRect(x + r * 0.35, y - r * 0.45, r * 0.35, r * 0.55);
  } else if (faction === 'veiled') {
    c.strokeStyle = '#ff4757aa';
    c.lineWidth = 1.6;
    c.beginPath();
    c.arc(x, y, r * 1.08, t, t + 1.4);
    c.stroke();
    c.beginPath();
    c.arc(x, y, r * 1.08, t + 3.14, t + 4.54);
    c.stroke();
  }
}

/* ==================== ENEMY SILHOUETTE RENDERING ==================== */
// Sprites are drawn in "base units" and scaled once per enemy (see drawEnemy), so shapes below
// never multiply by a scale factor. Hitboxes (e.r) are untouched; only the visuals are exaggerated.

// Extra silhouette exaggeration per kind (elites use a flat 1.1 so their aura still fits)
const KIND_SCALE = {
  walker: 1.1, knight: 1.25, cultist: 1.15, champion: 1.25, goblin: 1.15,
  spearman: 1.2, archer: 1.2, priest: 1.2, caller: 1.2, bulwark: 1.15,
  stalker: 1.25, hound: 1.25, beast: 1.2
};

const HUMANOID_CFG = {
  walker:   { eyeCol: '#ffeb99' },
  knight:   { cloak: true, heavy: true, shoulder: 1.25, eyeCol: '#ffd700' },
  cultist:  { cloak: true, hood: true, tallHood: true, robes: true, robeLen: 20, legs: false, eyeCol: '#ffeb99' },
  champion: { cloak: true, heavy: true, shoulder: 1.5, eyeCol: '#fff3c4' },
  goblin:   { hood: true, shoulder: 0.9, eyeCol: '#ffffff' },
  spearman: { shoulder: 1.05, eyeCol: '#ffeb99' },
  archer:   { cloak: true, hood: true, tallHood: true, shoulder: 0.9, eyeCol: '#d6a3ff' },
  priest:   { cloak: true, hood: true, tallHood: true, robes: true, robeLen: 27, legs: false, shoulder: 0.95, eyeCol: '#5effb1' },
  caller:   { cloak: true, hood: true, tallHood: true, robes: true, robeLen: 23, legs: false, eyeCol: '#7ed6df' },
  bulwark:  { heavy: true, shoulder: 1.55, eyeCol: '#ffd700' },
  stalker:  { hood: true, tallHood: true, wraith: true, legs: false, shoulder: 0.9, eyeCol: '#ff4757' }
};

function drawHumanoid(c, e, o) {
  const { fill, stroke, sw, stride, t, m, cfg } = o;
  const {
    cloak = false, heavy = false, hood = false, tallHood = false, robes = false,
    wraith = false, legs = true, shoulder = 1, robeLen = 13, eyeCol
  } = cfg;
  const tw = (heavy ? 10 : 7) * shoulder;
  const seed = e.seed;

  if (cloak) {
    flowCloak(c, { dir: 1, fill: '#1a1522', stroke, t, seed, top: -7, width: tw * 0.9, len: robes ? robeLen + 6 : 20, drift: 3, speed: 4.5 });
  }

  if (wraith) {
    // Floating body: ragged tail instead of legs
    const a = Math.sin(t * 5 + seed) * 3;
    const b = Math.sin(t * 6.3 + seed + 1) * 4;
    const d = Math.sin(t * 4.1 + seed + 2) * 3;
    poly(c, 0, 0, 1, [-tw, -6, tw, -6, tw * 0.7 + a, 8, tw * 0.35 + b, 19, 3 + d, 30, -tw * 0.3 + b, 20, -tw * 0.75 + a, 9], fill, stroke, sw);
  } else {
    if (legs && !robes) {
      c.fillStyle = '#1d1924';
      c.fillRect(-5.5, 5 + stride * 2.5, 4, 8);
      c.fillRect(1.5, 5 - stride * 2.5, 4, 8);
    }
    const hem = robes ? Math.sin(t * 3 + seed) : 0;
    const botW = robes ? 11 : tw * 0.78;
    const bot = robes ? robeLen : 6;
    poly(c, 0, 0, 1, [-tw, -6, tw, -6, botW + hem * 1.5, bot, 0, bot + (robes ? 3 + hem * 2 : 0), -botW - hem * 1.5, bot], fill, stroke, sw);
  }

  [-1, 1].forEach(side => {
    if (heavy) drawPauldron(c, side * (tw + 1.5), -5, 4.4 * Math.min(shoulder, 1.5) + 0.8, fill, stroke, cfg.spikes || null, side);
    drawCircle(c, side * (tw + 1), 1 - side * stride * 2, 2.5, fill, stroke, 1);
  });

  // Head: looks around while idle
  c.save();
  c.translate(m.head * 0.8, -Math.abs(m.head) * 0.5);
  if (hood) {
    const peak = tallHood ? -13 : -7;
    poly(c, 0, -10, 1, [0, peak, 6, -1, 4.5, 4.5, -4.5, 4.5, -6, -1], fill, stroke, 1.2);
  } else {
    drawCircle(c, 0, -10.5, 4.8, fill, stroke, 1.2);
  }
  c.fillStyle = e.hitFlash > 0 ? '#000' : eyeCol;
  const eye = wraith ? 2.8 : 2;
  c.fillRect(-2.6, -11, eye, eye);
  c.fillRect(0.8, -11, eye, eye);
  c.restore();
}

function drawHound(c, e, o) {
  const { fill, stroke, sw, stride: g, t } = o;
  const seed = e.seed;

  // Gallop: body stretches and compresses with the stride
  c.scale(1 + Math.abs(g) * 0.08, 1 - Math.abs(g) * 0.05);

  c.save();
  c.lineCap = 'round';
  // Tail
  c.strokeStyle = fill;
  c.lineWidth = 3;
  c.beginPath();
  c.moveTo(-21, -2);
  c.quadraticCurveTo(-27, -8 + Math.sin(t * 9 + seed) * 5, -35, -2 + Math.sin(t * 9 + seed + 1) * 7);
  c.stroke();
  // Legs
  c.strokeStyle = '#1c1116';
  c.lineWidth = 3.4;
  [[-14, g], [-8, -g], [8, -g], [14, g]].forEach(([lx, s]) => {
    c.beginPath();
    c.moveTo(lx, 2);
    c.lineTo(lx + s * 6, 7);
    c.lineTo(lx + s * 9, 13 - Math.max(0, -s) * 3);
    c.stroke();
  });
  c.restore();

  // Long body with spine ridges
  poly(c, 0, 0, 1, [-22, -1, -14, -7, 0, -8, 12, -6, 20, -3, 19, 4, 2, 6, -20, 5], fill, stroke, sw);
  for (let i = 0; i < 3; i++) {
    poly(c, -9 + i * 8, -7, 1, [-2.5, 0, 0, -5.5, 2.5, 0], '#1c1116', stroke, 1);
  }

  // Head with snout, jaw and ears
  const hy = -4 + Math.sin(t * 8 + seed) * 1;
  poly(c, 22, hy, 1, [-4, -5, 3, -8, 10, -3, 17, -1, 15, 3, 4, 4], fill, stroke, sw);
  poly(c, 24, hy, 1, [-2, -7, 0, -14 + Math.sin(t * 10 + seed) * 1.5, 3, -8], fill, stroke, 1);
  poly(c, 21, hy, 1, [11, 3, 13, 7, 8, 3], '#f1ece0', stroke, 0.8);
  c.fillStyle = e.hitFlash > 0 ? '#000' : '#ff4757';
  c.fillRect(26, hy - 2, 2.6, 2.6);
}

function drawTome(c, x, y, t, seed) {
  const flap = Math.sin(t * 3 + seed) * 2.2;
  drawCircle(c, x, y, 13, 'rgba(94,255,177,.20)');
  poly(c, x, y, 1, [-9, -4, 0, -2.5, 0, 6, -9, 4], '#d8d2c5', '#5c4938', 1.2);
  poly(c, x, y, 1, [9, -4 - flap, 0, -2.5, 0, 6, 9, 4 + flap * 0.5], '#e9e4d6', '#5c4938', 1.2);
  c.strokeStyle = '#5effb1';
  c.lineWidth = 1;
  c.beginPath();
  c.moveTo(x - 6, y); c.lineTo(x - 2, y + 0.5);
  c.moveTo(x + 2, y); c.lineTo(x + 6, y - 0.5);
  c.stroke();
  drawRune(c, x, y - 11 - ((t * 8 + seed * 3) % 6), 3, '#5effb1', t * 2);
}

const ENEMY_GEAR = {
  knight: (c, e, m) => {
    c.save();
    c.translate(11, 3);
    c.rotate(0.35 + m.sway * 0.1);
    drawBlade(c, 30, 3.8, '#dfe4ea', '#2a2633', '#c9a050');
    c.restore();
    c.save();
    c.translate(-11, 2);
    drawKiteShield(c, 6, 11, { fill: '#57606f', rim: '#dfe4ea' });
    c.restore();
  },
  champion: (c, e, m) => {
    c.save();
    c.translate(12, 4);
    c.rotate(0.45 + m.sway * 0.1);
    drawBlade(c, 44, 5.5, '#f6e3a8', '#3a2b12', '#f0cf85');
    c.restore();
  },
  cultist: (c, e, m, t) => {
    const y = -6 + Math.sin(t * 2.4 + e.seed) * 2.5;
    c.strokeStyle = '#7a5810';
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(9, 0); c.lineTo(14, y);
    c.stroke();
    drawCircle(c, 14, y, 9, 'rgba(255,215,0,.22)');
    drawCircle(c, 14, y, 4, '#ffd700', '#7a5810', 1);
    orbit(3, t, 3, 7, 7, (x, yy) => drawCircle(c, 14 + x, y + yy, 1.5, '#ffeb99'));
  },
  goblin: (c, e, m, t) => {
    drawCircle(c, -9, 3 + m.sway * 0.8, 8, '#ffd700', '#7a5810', 1.5);
    drawDiamond(c, -9 + Math.sin(t * 6) * 5, -6 + Math.cos(t * 6) * 2, 2.2, '#fff3b0');
  },
  spearman: (c, e, m) => {
    c.save();
    c.translate(8, 4);
    c.rotate(0.5 + m.sway * 0.07);
    c.strokeStyle = '#9c7a4c';
    c.lineWidth = 2.6;
    c.beginPath();
    c.moveTo(0, 16); c.lineTo(0, -50);
    c.stroke();
    poly(c, 0, 0, 1, [-4, -49, 0, -63, 4, -49, 0, -46], '#e6e4ed', '#2a2633', 1);
    poly(c, 0, 0, 1, [0, -44, 9 + m.sway * 2, -41, 0, -37], '#a82232', '#2a2633', 1);
    c.restore();
  },
  archer: (c, e, m) => {
    // Bow draws back during the attack tell
    const windup = e.tellT > 0 && e.tellMax > 0 ? (1 - e.tellT / e.tellMax) * 6 : 0;
    c.save();
    c.translate(10, -1);
    c.rotate(m.sway * 0.05);
    drawBowShape(c, 20, { wood: '#c780ff', string: '#e6d4ffcc', pull: 2 + (m.breath + 1) * 1.5 + windup, arrow: true, glow: '#9e7bff', lw: 2.8 });
    c.restore();
  },
  priest: (c, e, m, t) => drawTome(c, 15, -12 + Math.sin(t * 2.2 + e.seed) * 3.5, t, e.seed),
  caller: (c, e, m, t) => {
    orbit(3, t, 2.2, 19, 10, (x, y) => drawSkull(c, x, y - 4, 3.8, '#d8d2c5', '#7ed6df'));
    c.save();
    c.translate(10, 4);
    c.rotate(0.12 + m.sway * 0.06);
    c.strokeStyle = '#4b5a56';
    c.lineWidth = 2.4;
    c.beginPath();
    c.moveTo(0, 12); c.lineTo(0, -30);
    c.stroke();
    drawSkull(c, 0, -34, 4.4, '#d8d2c5', '#7ed6df');
    c.restore();
  },
  bulwark: (c, e, m) => {
    c.save();
    c.translate(15 + m.sway * 0.6, 1);
    drawKiteShield(c, 14, 22, { fill: '#57606f', rim: '#dfe4ea', emblem: '#a4b0be', glow: '#a4b0be' });
    c.fillStyle = '#dfe4ea';
    [[-8, -9], [8, -9], [0, 8]].forEach(([rx, ry]) => c.fillRect(rx - 1.2, ry - 1.2, 2.4, 2.4));
    c.restore();
  },
  stalker: (c, e, m, t) => {
    drawRing(c, 0, 8, 17, '#9e47ff66', 1.5);
    drawShardOrbit(c, 3, t, 3.2, 17, 7, 3.4, ['#d6a3ff'], 4);
    [-1, 1].forEach(side => {
      c.save();
      c.translate(side * 8, -2);
      c.rotate(side * (0.9 + m.sway * 0.2));
      poly(c, 0, 0, 1, [-2.4, 0, 2.4, 0, 0, -26], '#d6a3ff', '#6c2bd9', 1.2);
      c.restore();
    });
  }
};

export function drawEnemy(ctx, e, t) {
  const fill = e.hitFlash > 0 ? '#ffffff' : e.color;

  if (e.boss) {
    groundShadow(ctx, e.x, e.y + e.r * 0.88, e.r * 0.92, e.r * 0.38);
    const iDur = BossScalingConfig[e.role].introDur || 1.6;
    if (e.spawnT > 0) {
      const pr = 1 - e.spawnT / iDur;
      drawBeam(ctx, e.x, e.y, 260 * (1 - pr * 0.5), e.color);
      drawRuneCircle(ctx, e.x, e.y, e.r * (1.8 - pr * 0.35), e.color, t * 3);
      ctx.globalAlpha = pr;
      drawBossBody(ctx, e, t, fill);
      ctx.globalAlpha = 1;
    } else {
      drawBossBody(ctx, e, t, fill);
    }
    return;
  }

  const kind = e.kind;
  const isStalker = kind === 'stalker';
  const isQuad = kind === 'hound' || kind === 'beast';

  // Ground shadow: long for hounds, small and faint for floaters
  groundShadow(
    ctx,
    e.x,
    e.y + e.r * 0.88,
    e.r * 0.92 * (isQuad ? 1.8 : isStalker ? 0.7 : 1.1),
    e.r * 0.38,
    isStalker ? 0.26 : 0.42
  );

  if (e.elite) championsSys.drawEliteAura(ctx, e, t);
  if (e.buffT > 0) drawRing(ctx, e.x, e.y, e.r + 4, '#5effb199', 1.4);
  if (e.shieldHp > 0 && !e.elite) drawRing(ctx, e.x, e.y, e.r + 3, '#a4b0be', 1.8);

  // Attack feedback: tell (wind-up) -> committed strike
  if (e.tellT > 0 && e.tellMax > 0) {
    const k = 1 - e.tellT / e.tellMax;
    drawRing(ctx, e.x, e.y, e.r + 4 + k * 12, '#ff4757dd', 1.4 + k * 1.6);
    drawDiamond(ctx, e.x, e.y - e.r * 2.2 - 4, 3.5 + k * 3, '#ff4757');
  } else if (e.engState === ENG.ATTACK) {
    drawRing(ctx, e.x, e.y, e.r + 5, '#ffb347cc', 1.8);
  } else if (e.elite && e.atkCd < 0.42) {
    drawRing(ctx, e.x, e.y, e.r + 6 + (0.42 - e.atkCd) * 14, '#ffd700aa', 1.6);
  }

  const isChamp = kind === 'champion' || e.role === 'mini' || e.invader;
  const stride = Math.sin(t * (e.speed * 0.085) + e.seed);
  const m = idleMotion(t, e.seed, true);
  const sc = (e.r / 13.5) * (e.elite ? 1.1 : KIND_SCALE[kind] || 1.1);
  const dir = state.player && state.player.x < e.x ? -1 : 1; // always face the player
  const lift = isStalker ? 8 + Math.sin(t * 4.5 + e.seed) * 3 : Math.abs(stride) * 2;
  const stroke = isChamp ? '#fff3c4' : e.elite ? '#f0cf85' : OUTLINE;
  const sw = isChamp ? 2.2 : e.elite ? 1.8 : e.r >= 16 ? 1.6 : 1.2;

  ctx.save();
  ctx.translate(e.x, e.y - lift);
  ctx.scale(dir * sc, sc);
  if (!isStalker && !isQuad) ctx.rotate(stride * 0.07);
  ctx.scale(1 + m.breath * 0.025, 1 - m.breath * 0.03);

  const o = { fill, stroke, sw, stride, t, m };
  if (isQuad) drawHound(ctx, e, o);
  else drawHumanoid(ctx, e, { ...o, cfg: HUMANOID_CFG[kind] || HUMANOID_CFG.walker });

  ENEMY_GEAR[kind]?.(ctx, e, m, t);
  ctx.restore();

  if (e.elite || kind === 'knight' || kind === 'bulwark' || kind === 'spearman') {
    drawFactionAccent(ctx, e.faction, e.x, e.y, e.r, t, '#f0cf85');
  }
}
