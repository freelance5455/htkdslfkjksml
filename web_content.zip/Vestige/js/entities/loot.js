import { CFG } from '../core/config.js';
import { pick, drawCircle, drawRing, drawText, drawDiamond, drawBeam } from '../core/utilities.js';
import { metaSave } from '../core/save.js';
import { sfx } from '../core/audio.js';
import { state, gemPool, lootPool, arcs, addShake, spawnParticles } from '../core/game.js';

import { RARITIES, SLOTS, PREFIXES, SUFFIXES, ITEM_BASES, BASE_SUBTYPES, UNIQUE_SUBTYPES, ITEM_LORE, UNIQUES } from '../data/items.js';
import { AFFIX_DEFS } from '../data/affixes.js';
import { WorldTierConfig, DifficultyConfig } from '../data/worldTierData.js';

import { gainXp, recalcStats } from './player.js';
import { getScaling } from '../systems/worldtiers.js';
import { canClassEquip } from '../systems/equipment.js';
import { addFeed, showBanner, spawnFloatText } from '../ui/notifications.js';

let itemUid = 1;

// Chance that weapon/armor drops are something your class can actually equip (the rest can be sold or salvaged)
const CLASS_LOOT_BIAS = 0.8;

// ============================================================================
// LOOT MAGNET CONFIG (tweakable at runtime, e.g. LOOT_CFG.attractRadius = 900)
// ============================================================================
export const LOOT_CFG = {
  attractRadius: 700,      // loot starts flying toward the player inside this radius
  autoPickupRadius: 150,   // loot is collected automatically inside this radius
  startSpeed: 140,         // px/s when a drop starts moving
  accel: 1500,             // px/s^2 base acceleration
  maxSpeed: 1250,          // px/s cap
  maxDrops: 60,            // ground drops allowed (match the lootPool size in game.js); extra drops are
                           // collected instantly instead of being lost
  gemMaxSpeed: 900,
  gemAccel: 1800,
  gemStartSpeed: 300,
  // Priority tiers: 0 common/magic, 1 rare, 2 relic/fragment/quest, 3 legendary, 4 mythic
  tierRadiusMul: [1.0, 1.0, 1.2, 1.35, 1.5],  // higher tiers are pulled from farther away...
  tierDelay: [0.35, 0.25, 0.12, 0.04, 0],      // ...and start moving sooner (seconds after entering range)
  tierAccelMul: [1.0, 1.2, 1.5, 2.0, 2.5],
  hideCommonNamesAbove: 40 // skip text labels on common/magic drops when this many are on the ground
};

const subTypeFor = (slot, base, uniqueId) =>
  UNIQUE_SUBTYPES[uniqueId] ||
  BASE_SUBTYPES[base] ||
  (slot === 'ring1' || slot === 'ring2' ? 'Ring' : slot === 'amulet' ? 'Amulet' : null);

function pickBase(slot, classId) {
  const bases = ITEM_BASES[slot];
  if (classId && Math.random() < CLASS_LOOT_BIAS) {
    const usable = bases.filter(b => canClassEquip(classId, { subType: subTypeFor(slot, b, null) }));
    if (usable.length) return pick(usable);
  }
  return pick(bases);
}

export const calcItemScore = it =>
  Math.round(
    it.ilvl * 4 +
      RARITIES[it.rarity].mult * 45 +
      (it.ancient ? 65 : 0) +
      (it.unique ? 110 : 0) +
      it.affixes.length * 18 +
      it.gems.length * 25
  );

// Mythic is never rolled here: mythics only enter the game through the world-drop handler below.
export function rollRarity(luck = 0) {
  const wt = WorldTierConfig.tiers[state.worldTier];
  const st = state.player?.stats;
  const tl =
    wt.luck +
    (metaSave.metaRanks.m_luck || 0) * 0.15 +
    state.modeCfg.luckAdd +
    (state.apocalypse ? DifficultyConfig.apoc.luckBonus : 0) +
    (st?.relicLuck || 0) +
    state.dungeon.luckAdd +
    luck;

  const r = Math.random() * 100;
  const l = RARITIES.legendary.weight * (1 + tl);
  const ra = l + RARITIES.rare.weight * (1 + tl * 0.5);
  const ma = ra + RARITIES.magic.weight;

  return r < l ? 'legendary' : r < ra ? 'rare' : r < ma ? 'magic' : 'common';
}

export function rollSingleAffix(rarityKey, ilvl, used, ancient) {
  const rarity = RARITIES[rarityKey];
  const pool = AFFIX_DEFS.filter(a => !used.includes(a.key) && (!a.rareOnly || rarity.affixes >= 3));
  if (!pool.length) return null;

  const def = pick(pool);
  const raw =
    def.key === 'projBonus'
      ? 1
      : Math.max(
          1,
          Math.round((def.min + Math.random() * (def.max - def.min)) * rarity.mult * (1 + ilvl * 0.04) * (ancient ? 1.35 : 1))
        );
  return {
    key: def.key,
    raw,
    val: def.pct ? raw / 100 : raw,
    text: def.label.replace('{v}', raw)
  };
}

/**
 * Public item factory (vendors, reliquary, quests, crafting, drops...).
 * It can NEVER return a Mythic: a requested 'mythic' is issued as a Legendary and tagged
 * `mythicRequested` so the world-drop handler can give it an elevated promotion chance.
 */
export function generateLootItem(ilvl = 1, forcedRarity = null, luck = 0) {
  return buildItem(ilvl, forcedRarity, luck, false);
}

// Private: the only code path that can produce a Mythic (see MYTHIC DROP HANDLER).
function buildItem(ilvl, forcedRarity, luck, allowMythic) {
  let rarityKey = forcedRarity || rollRarity(luck);
  let mythicRequested = false;
  if (rarityKey === 'mythic' && !allowMythic) {
    rarityKey = 'legendary';
    mythicRequested = true;
  }

  const rarity = RARITIES[rarityKey];
  const classId = state.player?.cls?.id;
  const ancient =
    ['rare', 'legendary', 'mythic'].includes(rarityKey) &&
    Math.random() < CFG.loot.ANCIENT_BASE + WorldTierConfig.tiers[state.worldTier].ancient;

  let unique = null;
  let slot = pick(SLOTS);
  let set = null;
  let name = '';

  if ((rarityKey === 'legendary' || rarityKey === 'mythic') && Math.random() < 0.8) {
    const cands = UNIQUES.filter(u => u.rarity === rarityKey);
    if (cands.length) {
      let uniquePool = cands;
      if (classId && Math.random() < CLASS_LOOT_BIAS) {
        const usable = cands.filter(u => canClassEquip(classId, { subType: subTypeFor(u.slot, null, u.id) }));
        if (usable.length) uniquePool = usable;
      }
      unique = pick(uniquePool);
      slot = unique.slot;
      set = unique.set;
      name = unique.name;
    }
  }

  if (!set && (rarityKey === 'rare' || rarityKey === 'legendary') && Math.random() < 0.28) {
    set = Math.random() < 0.55 ? 'ashenking' : 'choir';
  }

  let base = null;
  if (!name) {
    base = pickBase(slot, classId);
    name =
      rarityKey === 'common'
        ? base
        : rarityKey === 'magic'
        ? `${pick(PREFIXES)} ${base}`
        : `${pick(PREFIXES)} ${base} ${pick(SUFFIXES)}`;
  }

  if (ancient) name = `[Ancient] ${name}`;

  const affixes = [];
  const used = [];
  for (let i = 0; i < rarity.affixes; i++) {
    const af = rollSingleAffix(rarityKey, ilvl, used, ancient);
    if (af) {
      used.push(af.key);
      affixes.push(af);
    }
  }

  const item = {
    uid: itemUid++,
    name,
    slot,
    subType: subTypeFor(slot, base, unique?.id),
    rarity: rarityKey,
    ilvl,
    ancient,
    unique,
    set,
    affixes,
    gems: [],
    lore: unique ? unique.lore : pick(ITEM_LORE),
    score: 0
  };
  if (mythicRequested) item.mythicRequested = true;
  if (allowMythic && rarityKey === 'mythic') item.worldMythic = true;
  item.score = calcItemScore(item);
  return item;
}

// ============================================================================
// MYTHIC DROP HANDLER
// World drops only. Responsibilities:
//   1) roll / pace Mythic promotion (target ~1.5 per successful run, never a flood)
//   2) run the arrival presentation (slow-mo, flash, beam, floating reveal)
//   3) keep the drop locked (no attraction, no pickup) until the reveal has finished
// ============================================================================
export const MYTHIC_CFG = {
  // ---- Drop rate ----
  runTargetSec: 1200,       // length of a "successful run" the pacing is tuned to
  targetPerRun: 1.5,        // expected Mythics by runTargetSec
  baseChance: 0.05,         // per eligible drop, before weights / pacing
  rarityWeight: { common: 0.01, magic: 0.03, rare: 0.16, legendary: 1 },
  requestedWeight: 0.7,     // drops that explicitly asked for a Mythic (e.g. invader champions)
  luckScale: 0.25,          // how strongly the relic-luck stat nudges the chance
  maxChance: 0.5,
  // Pacing controller: behind the target pace -> boosted, ahead -> damped
  pace: { behindBoost: 3, maxBoost: 4, aheadDamp: 2.5, minMult: 0.2 },
  minTimeSec: 90,           // nothing in the opening minutes
  minSpacingSec: 60,        // never two in quick succession
  softCap: 3,               // from the 3rd Mythic on, chance is heavily reduced (3+ stays rare)
  softCapMult: 0.2,
  hardCap: 5,               // absolute per-run ceiling

  // ---- Presentation (all durations in REAL seconds so slow-mo can't stretch them) ----
  revealDur: 2.6,           // drop is locked until the reveal completes
  slow: { scale: 0.2, rampIn: 0.15, hold: 0.9, rampOut: 0.7 },
  flashDur: 0.45,
  beamBase: 60,             // normal rare+ beam length
  beamPeak: 300,            // beam length at the end of the reveal
  beamIdle: 150             // beam length while waiting for pickup
};

const mythicTracker = { found: 0, lastFoundT: -1e9, lastSeenT: 0 };
const mythicFx = { slowT: Infinity, lastReal: 0 };

function resetMythicIfNewRun() {
  if (state.time < mythicTracker.lastSeenT) {
    mythicTracker.found = 0;
    mythicTracker.lastFoundT = -1e9;
    mythicFx.slowT = Infinity;
  }
  mythicTracker.lastSeenT = state.time;
}

export function getMythicStats() {
  return { found: mythicTracker.found, lastFoundAt: mythicTracker.lastFoundT };
}

function mythicChance(item) {
  const C = MYTHIC_CFG;
  const t = state.time;
  if (t < C.minTimeSec || t - mythicTracker.lastFoundT < C.minSpacingSec) return 0;
  if (mythicTracker.found >= C.hardCap) return 0;

  const weight = item.mythicRequested ? C.requestedWeight : C.rarityWeight[item.rarity] || 0;
  if (weight <= 0) return 0;

  // Pace: how many we "should" have by now vs how many we have
  const expected = C.targetPerRun * Math.min(1, t / C.runTargetSec);
  const deficit = expected - mythicTracker.found;
  const pace =
    deficit > 0
      ? Math.min(C.pace.maxBoost, 1 + deficit * C.pace.behindBoost)
      : Math.max(C.pace.minMult, 1 / (1 + -deficit * C.pace.aheadDamp));

  const luck = 1 + Math.max(0, state.player?.stats?.relicLuck || 0) * C.luckScale;
  const cap = mythicTracker.found >= C.softCap ? C.softCapMult : 1;
  return Math.min(C.maxChance, C.baseChance * weight * pace * luck * cap);
}

// Called for every world drop. Returns the item to actually drop (possibly promoted to a Mythic).
function processWorldDrop(item) {
  resetMythicIfNewRun();

  // A Mythic that did not come from this handler is not legitimate: reissue as Legendary
  if (item.rarity === 'mythic' && !item.worldMythic) {
    item = buildItem(item.ilvl, 'legendary', 0, false);
    item.mythicRequested = true;
  }
  if (item.rarity === 'mythic') return item;

  if (Math.random() < mythicChance(item)) {
    const mythic = buildItem(item.ilvl, 'mythic', 0, true);
    mythicTracker.found++;
    mythicTracker.lastFoundT = state.time;
    return mythic;
  }
  return item;
}

// ---- Real-time clock (reveal timers must not depend on the slowed game dt) ----
function realDelta() {
  const now = performance.now() / 1000;
  const d = mythicFx.lastReal ? Math.min(0.1, Math.max(0, now - mythicFx.lastReal)) : 0.016;
  mythicFx.lastReal = now;
  return d;
}

function tickMythicFx(rdt) {
  if (mythicFx.slowT !== Infinity) {
    mythicFx.slowT += rdt;
    const S = MYTHIC_CFG.slow;
    if (mythicFx.slowT >= S.rampIn + S.hold + S.rampOut) mythicFx.slowT = Infinity;
  }
}

/**
 * Game-speed multiplier for the main loop (1 = normal). Multiply the simulation dt by this:
 *   const sim = dt * getMythicTimeScale();
 */
export function getMythicTimeScale() {
  const t = mythicFx.slowT;
  if (t === Infinity) return 1;
  const S = MYTHIC_CFG.slow;
  if (t < S.rampIn) return 1 - (1 - S.scale) * (t / S.rampIn);
  if (t < S.rampIn + S.hold) return S.scale;
  const k = (t - S.rampIn - S.hold) / S.rampOut;
  return S.scale + (1 - S.scale) * (k * k * (3 - 2 * k));
}

export function isMythicRevealActive() {
  for (let i = 0; i < lootPool.active.length; i++) if (lootPool.active[i].locked) return true;
  return false;
}

function onMythicArrival(l) {
  const col = l.col;
  mythicFx.slowT = 0;
  mythicFx.lastReal = performance.now() / 1000;
  sfx.play('legendary');
  addShake(9);
  spawnParticles(l.x, l.y, '#ffffff', 22, 330);
  spawnParticles(l.x, l.y, col, 26, 240);
  arcs.push({ ring: { x: l.x, y: l.y, r: 70 }, life: 0.34, color: col });
  arcs.push({ ring: { x: l.x, y: l.y, r: 150 }, life: 0.22, color: '#ffffff' });
  addFeed(`A Mythic stirs... ${RARITIES.mythic.name} Drop!`, col);
}

function onMythicRevealed(l) {
  const col = l.col;
  l.locked = false;
  addShake(4);
  spawnParticles(l.x, l.y - 30, col, 20, 200);
  arcs.push({ ring: { x: l.x, y: l.y, r: 110 }, life: 0.26, color: col });
  addFeed(`${RARITIES.mythic.name} Drop: ${l.item.name}`, col);
  showBanner('MYTHIC DROP', l.item.name, col, 2.4);
}

// Mythic drops must never be skipped by a full pool: sacrifice (auto-collect) the cheapest ground drop
function makeRoomForMythic() {
  let idx = -1;
  for (let i = 0; i < lootPool.active.length; i++) {
    const l = lootPool.active[i];
    if (l.locked || l.tier >= 3) continue;
    if (idx < 0 || l.tier < lootPool.active[idx].tier) idx = i;
  }
  if (idx < 0) return false;
  if (state.player) collectLoot(state.player, lootPool.active[idx].item);
  lootPool.release(idx);
  return true;
}

const easeOut = k => 1 - (1 - k) * (1 - k) * (1 - k);
const clamp01 = k => (k < 0 ? 0 : k > 1 ? 1 : k);

function drawMythicDrop(ctx, l, t) {
  const C = MYTHIC_CFG;
  const col = l.col;
  const revealing = l.locked;
  const k = revealing ? clamp01(l.revealT / C.revealDur) : 1;

  ctx.save();

  if (revealing) {
    // Arrival flash + expanding shock rings
    if (l.revealT < C.flashDur) {
      const a = 1 - l.revealT / C.flashDur;
      ctx.globalAlpha = a * 0.85;
      drawCircle(ctx, l.x, l.y, 50 + l.revealT * 520, '#ffffff');
      ctx.globalAlpha = a * 0.5;
      drawCircle(ctx, l.x, l.y, 30 + l.revealT * 340, col);
    }
    ctx.globalAlpha = (1 - k) * 0.9;
    drawRing(ctx, l.x, l.y, 24 + easeOut(k) * 190, col, 3.2);
    drawRing(ctx, l.x, l.y, 12 + easeOut(clamp01(k * 1.4)) * 120, '#ffffff', 1.8);
  }

  // Intensified beam: grows during the reveal, then pulses while it waits for pickup
  const len = revealing
    ? C.beamBase + (C.beamPeak - C.beamBase) * easeOut(k)
    : C.beamIdle + Math.sin(t * 3 + l.bob) * 18;
  ctx.globalAlpha = revealing ? 0.55 + 0.45 * k : 0.8;
  drawBeam(ctx, l.x, l.y, len, col);
  ctx.globalAlpha = revealing ? 0.4 * k : 0.45;
  drawBeam(ctx, l.x, l.y, len * 0.7, '#ffffff');
  if (revealing) {
    ctx.globalAlpha = 0.35 * k;
    drawBeam(ctx, l.x, l.y, len * 1.25, col);
  }

  // Floating reveal: the item rises out of the ground and hovers
  const rise = revealing ? easeOut(clamp01((l.revealT - 0.3) / 1.5)) : 1;
  const hover = revealing ? 0 : Math.sin(l.bob) * 3;
  const iy = l.y + 28 - rise * 62 + hover;

  ctx.globalAlpha = 0.25 + 0.2 * rise;
  drawCircle(ctx, l.x, iy, 16 + rise * 10, col);
  ctx.globalAlpha = 1;
  ctx.save();
  ctx.translate(l.x, iy);
  ctx.rotate(t * (revealing ? 2 + k * 4 : 2.2));
  drawDiamond(ctx, 0, 0, 7 + rise * 3, col, '#ffffff', 1.6);
  ctx.restore();
  drawRing(ctx, l.x, iy, 15 + rise * 8 + Math.sin(t * 6) * 1.5, col, 1.6);

  // Name fades in near the end of the reveal
  const nameA = revealing ? clamp01((k - 0.65) / 0.3) : 1;
  if (nameA > 0) {
    ctx.globalAlpha = nameA;
    drawText(ctx, l.item.name, l.x, iy - 26, col);
  }

  ctx.restore();
}

// ============================================================================
// PICKUP HELPERS
// ============================================================================

// Priority tier: Mythic > Legendary > Relic/Fragment/Quest > Rare > everything else.
// Relic/fragment/quest drops are detected from common flags/types on the item so any system can mark them.
export function lootPriority(item) {
  if (!item) return 0;
  if (item.rarity === 'mythic') return 4;
  if (item.rarity === 'legendary') return 3;
  if (
    item.relic || item.fragment || item.quest || item.questItem || item.isQuest ||
    item.type === 'relic' || item.type === 'fragment' || item.type === 'quest' ||
    item.slot === 'relic'
  ) {
    return 2;
  }
  return item.rarity === 'rare' ? 1 : 0;
}

const canEquipFree = (p, item) => !p.equipped[item.slot] && canClassEquip(p.cls?.id, item);

// Single place that turns a loot item into an inventory/equipment result
function collectLoot(p, item) {
  if (canEquipFree(p, item)) {
    p.equipped[item.slot] = item;
    recalcStats();
    addFeed(`Equipped [${RARITIES[item.rarity].name}] ${item.name}`, RARITIES[item.rarity].color);
  } else if (p.bag.length < CFG.game.MAX_BAG) {
    p.bag.push(item);
    state.newLoot++;
    if (Math.random() < 0.25) {
      p.gemsCount++;
      addFeed('Found a Socketable Gem!', '#5effb1');
    }
  } else if (metaSave.settings.autoSalvage) {
    state.runGold += 12;
    state.runShards++;
  }
}

/**
 * World drop entry point. Every ground drop goes through here, which is also where a Mythic can
 * be conferred (see MYTHIC DROP HANDLER). Items handed directly to the player by vendors,
 * reliquary, quests or crafting never pass through here, so they can never become Mythic.
 */
export function dropLoot(x, y, item) {
  item = processWorldDrop(item);
  const isMythic = item.rarity === 'mythic';

  // Pool is full: never lose the item. Mythics get a slot (and their reveal); others go straight to the player
  if (lootPool.active.length >= LOOT_CFG.maxDrops && !(isMythic && makeRoomForMythic())) {
    if (state.player) collectLoot(state.player, item);
    return;
  }

  const tier = lootPriority(item);
  const r = LOOT_CFG.attractRadius * LOOT_CFG.tierRadiusMul[tier];

  // Pooled object: every field is reset so nothing leaks from a previous drop
  const l = Object.assign(lootPool.spawn(), {
    x: isMythic ? x : x + (Math.random() - 0.5) * 20,
    y: isMythic ? y : y + (Math.random() - 0.5) * 20,
    item,
    bob: Math.random() * 6,
    tier,
    col: RARITIES[item.rarity].color,
    attR2: r * r,          // per-drop attraction radius (squared, computed once)
    wait: 0,               // time spent inside attraction range
    spd: 0,
    flying: false,
    dirX: 0,
    dirY: 0,
    locked: isMythic,      // Mythic reveal in progress: no attraction, no pickup
    revealT: 0
  });

  if (isMythic) {
    onMythicArrival(l);
  } else if (item.rarity === 'legendary') {
    sfx.play('legendary');
    addFeed(`${RARITIES[item.rarity].name} Drop: ${item.name}`, RARITIES[item.rarity].color);
  }
}

export function updateGemsAndLoot(dt) {
  const p = state.player;
  const sc = getScaling();
  const px = p.x;
  const py = p.y;

  resetMythicIfNewRun();
  const rdt = realDelta();
  tickMythicFx(rdt);

  // ---- Gems: stat pickup radius, now with acceleration ----
  const mag2 = p.stats.pickupRadius ** 2;
  const gemHit2 = (p.r + 12) ** 2;
  for (let i = gemPool.active.length - 1; i >= 0; i--) {
    const g = gemPool.active[i];
    const dx = px - g.x;
    const dy = py - g.y;
    const d2 = dx * dx + dy * dy;
    if (d2 < mag2) g.magnet = true;
    if (g.magnet) {
      const d = Math.sqrt(d2) || 1;
      g.spd = Math.min(LOOT_CFG.gemMaxSpeed, (g.spd || LOOT_CFG.gemStartSpeed) + LOOT_CFG.gemAccel * dt);
      const step = Math.min(g.spd * dt, d);
      g.x += (dx / d) * step;
      g.y += (dy / d) * step;
    }
    if (d2 < gemHit2) {
      if (g.heal) {
        const h = Math.round(p.maxHp * 0.12);
        p.hp = Math.min(p.maxHp, p.hp + h);
        spawnFloatText(px, py, `+${h} HP`, '#5effb1', 14);
      } else {
        gainXp(g.val * p.stats.xpGain * sc.rewardMult);
      }
      sfx.play('gem');
      g.spd = 0;
      gemPool.release(i);
    }
  }

  // ---- Loot: attraction + auto pickup (one distance calc per drop, shared by both) ----
  const autoR2 = LOOT_CFG.autoPickupRadius ** 2;
  const touchR2 = (p.r + 22) ** 2;
  const pickR2 = Math.max(autoR2, touchR2);
  const bagFull = p.bag.length >= CFG.game.MAX_BAG && !metaSave.settings.autoSalvage;
  const { startSpeed, accel, maxSpeed, tierDelay, tierAccelMul } = LOOT_CFG;

  for (let i = lootPool.active.length - 1; i >= 0; i--) {
    const l = lootPool.active[i];

    // Mythic reveal: fully completes before the item can be attracted or picked up
    if (l.locked) {
      l.bob += rdt * 4;
      if ((l.revealT += rdt) >= MYTHIC_CFG.revealDur) onMythicRevealed(l);
      continue;
    }

    const dx = px - l.x;
    const dy = py - l.y;
    const d2 = dx * dx + dy * dy;

    // Out of range: idle bob, reset momentum
    if (d2 > l.attR2) {
      l.bob += dt * 4;
      l.wait = 0;
      l.spd = 0;
      l.flying = false;
      continue;
    }

    // Bag full and nothing to equip: leave it on the ground instead of destroying it
    if (bagFull && !canEquipFree(p, l.item)) {
      l.bob += dt * 4;
      l.flying = false;
      continue;
    }

    // Auto pickup
    if (d2 <= pickR2) {
      collectLoot(p, l.item);
      l.flying = false;
      l.spd = 0;
      lootPool.release(i);
      continue;
    }

    // Attraction: higher priority starts sooner and accelerates harder
    l.wait += dt;
    if (l.wait < tierDelay[l.tier]) {
      l.bob += dt * 4;
      continue;
    }

    const d = Math.sqrt(d2);
    l.spd = Math.min(maxSpeed, (l.spd || startSpeed) + accel * tierAccelMul[l.tier] * dt);
    const step = Math.min(l.spd * dt, d);
    l.dirX = dx / d;
    l.dirY = dy / d;
    l.x += l.dirX * step;
    l.y += l.dirY * step;
    l.flying = true;
  }
}

export function renderGemsAndLoot(ctx, inView) {
  for (let i = 0; i < gemPool.active.length; i++) {
    const g = gemPool.active[i];
    if (inView(g.x, g.y, 20)) drawDiamond(ctx, g.x, g.y, g.heal ? 7 : 5, g.color);
  }

  const n = lootPool.active.length;
  const crowded = n > LOOT_CFG.hideCommonNamesAbove;

  for (let i = 0; i < n; i++) {
    const l = lootPool.active[i];
    if (!inView(l.x, l.y, l.tier === 4 ? 320 : 90)) continue;

    const col = l.col;
    const tier = l.tier;

    // Mythics: reveal sequence, then the intensified idle beam. In flight they use the comet below.
    if (tier === 4 && !l.flying) {
      drawMythicDrop(ctx, l, state.time);
      continue;
    }

    if (l.flying) {
      // Comet streak behind items flying toward the player
      const len = Math.min(70, l.spd * 0.05);
      ctx.save();
      ctx.lineCap = 'round';
      ctx.globalAlpha = 0.5;
      ctx.strokeStyle = col;
      ctx.lineWidth = tier >= 3 ? 5 : 3;
      ctx.beginPath();
      ctx.moveTo(l.x - l.dirX * len, l.y - l.dirY * len);
      ctx.lineTo(l.x, l.y);
      ctx.stroke();
      ctx.restore();
      drawCircle(ctx, l.x, l.y, 6.5, col);
      if (tier >= 2) drawText(ctx, l.item.name, l.x, l.y - 12, col);
      continue;
    }

    const by = Math.sin(l.bob) * 3;
    if (tier >= 1 && l.item.rarity !== 'common' && l.item.rarity !== 'magic') {
      drawBeam(ctx, l.x, l.y, 60, col);
    }
    drawCircle(ctx, l.x, l.y + by, 6.5, col);
    if (!crowded || tier >= 1) drawText(ctx, l.item.name, l.x, l.y - 12 + by, col);
  }
}
