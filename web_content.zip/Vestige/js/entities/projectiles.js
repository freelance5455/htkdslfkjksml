import { CFG } from '../core/config.js';
import { drawCircle, drawRing, drawDiamond } from '../core/utilities.js';
import { metaSave } from '../core/save.js';
import { sfx } from '../core/audio.js';
import {
  state,
  enemyGrid,
  qBuf,
  projPool,
  arcs,
  hazards,
  telegraphs,
  impacts,
  partPool,
  textPool,
  perf,
  PARTICLE_BUDGET,
  onScreen,
  addShake,
  spawnParticles
} from '../core/game.js';

import { WEAPONS_DEF } from '../data/classes.js';
import { damagePlayer } from './player.js';
import { killEnemy } from './enemies.js';
import { addMasteryXp, weaponMult } from '../systems/mastery.js';
import { spawnFloatText } from '../ui/notifications.js';

// ============================================================================
// REUSABLE ELEMENTAL SPELL VFX SYSTEM
// ============================================================================

// Fixed-size ring buffers: zero allocation after load. When full, the oldest
// slot is recycled instead of growing or shift()/splice()-ing arrays.
const SP_MAX = 260;
const IM_MAX = 54;
const spellParticles = Array.from({ length: SP_MAX }, () => ({
  kind: 'ember', x: 0, y: 0, vx: 0, vy: 0, r: 1, color: '#fff', life: 0, maxLife: 1
}));
const spellImpacts = Array.from({ length: IM_MAX }, () => ({
  x: 0, y: 0, elem: 'fire', r: 10, ang: 0, crit: false, life: 0, maxLife: 1
}));
let spHead = 0;
let imHead = 0;
let spLive = 0;
let lastSpellTime = 0;

export function getSpellParticleCount() {
  return spLive;
}

function resetSpellVfxIfNeeded() {
  if (state.time < lastSpellTime) {
    for (let i = 0; i < SP_MAX; i++) spellParticles[i].life = 0;
    for (let i = 0; i < IM_MAX; i++) spellImpacts[i].life = 0;
    spHead = imHead = spLive = 0;
    dmgAgg.clear();
  }
  lastSpellTime = state.time;
}

function pushArc(a) {
  if (arcs.length >= perf.arcCap) arcs.shift();
  arcs.push(a);
}

// ---------------------------------------------------------------------------
// Damage-number aggregation: "4 Hits / 19484 Damage" instead of 4 stacked numbers
// ---------------------------------------------------------------------------
const dmgAgg = new Map();
const aggFree = [];

function queueDamageText(e, dmg, crit) {
  if (!onScreen(e.x, e.y, 40)) return;
  const key = perf.textCell ? ((e.x / 96) | 0) * 4099 + ((e.y / 96) | 0) : e;
  let a = dmgAgg.get(key);
  if (!a) {
    a = aggFree.pop() || { age: 0, n: 0, total: 0, sx: 0, sy: 0, crit: false };
    a.age = 0; a.n = 0; a.total = 0; a.sx = 0; a.sy = 0; a.crit = false;
    dmgAgg.set(key, a);
    // Snappy feedback: first hit of a burst shows instantly while the scene is calm.
    if (!perf.textCell && textPool.active.length < 28) {
      spawnFloatText(e.x, e.y, crit ? `${dmg}!` : `${dmg}`, crit ? '#ffd700' : '#fff', crit ? 17 : 12);
      return;
    }
  }
  a.n++;
  a.total += dmg;
  a.sx += e.x;
  a.sy += e.y;
  if (crit) a.crit = true;
}

function emitAggText(a) {
  if (a.n <= 0) return;
  const x = a.sx / a.n;
  const y = a.sy / a.n;
  if (a.n === 1) {
    spawnFloatText(x, y, a.crit ? `${a.total}!` : `${a.total}`, a.crit ? '#ffd700' : '#fff', a.crit ? 17 : 12);
    return;
  }
  spawnFloatText(x, y - 13, `${a.n} Hits`, a.crit ? '#ffe27a' : '#d0d0d0', 11);
  spawnFloatText(x, y, `${a.total} Damage`, a.crit ? '#ffd700' : '#fff', a.crit ? 17 : 14);
}

function flushDamageText(dt) {
  if (!dmgAgg.size) return;
  const win = perf.textWindow;
  for (const [key, a] of dmgAgg) {
    if ((a.age += dt) < win) continue;
    dmgAgg.delete(key);
    emitAggText(a);
    aggFree.push(a);
  }
}

let lastHitSfx = -1;

function parseHexRgb(hex) {
  if (typeof hex !== 'string' || !hex.startsWith('#')) return null;
  if (hex.length === 4) {
    return [
      parseInt(hex[1] + hex[1], 16),
      parseInt(hex[2] + hex[2], 16),
      parseInt(hex[3] + hex[3], 16)
    ];
  }
  if (hex.length >= 7) {
    return [
      parseInt(hex.slice(1, 3), 16),
      parseInt(hex.slice(3, 5), 16),
      parseInt(hex.slice(5, 7), 16)
    ];
  }
  return null;
}

const elemMemo = new Map();

export function resolveSpellElement(wKey, color, isEnemy = false) {
  const key = `${wKey || ''}|${color || ''}|${isEnemy ? 1 : 0}`;
  let v = elemMemo.get(key);
  if (v === undefined) {
    if (elemMemo.size > 600) elemMemo.clear();
    v = computeSpellElement(wKey, color, isEnemy);
    elemMemo.set(key, v);
  }
  return v;
}

function computeSpellElement(wKey, color, isEnemy) {
  const k = (wKey || '').toLowerCase();
  if (k) {
    if (/fire|flame|ember|pyro|inferno|meteor|magma|burn|phoenix/.test(k)) return 'fire';
    if (/lightning|storm|shock|arc|thunder|volt|spark|tempest/.test(k)) return 'lightning';
    if (/void|shadow|abyss|chaos|rift|star|astral|cosmic|stalker/.test(k)) return 'void';
    if (/sun|holy|divine|halo|sacred|radiant|smite|dawn|light|angel/.test(k)) return 'holy';
    if (/necro|bone|soul|death|skull|grave|plague|spirit|wraith|scythe/.test(k)) return 'necromancy';
  }

  const rgb = parseHexRgb(color);
  if (rgb) {
    const [r, g, b] = rgb;
    if (r > 205 && g > 170 && b < 145) return 'holy';
    if (r > 185 && g < 165 && b < 115) return isEnemy && r > 220 && b > 55 ? 'void' : 'fire';
    if (b > 170 && g > 125 && r < 165) return 'lightning';
    if (b > 130 && r > 105 && g < 145) return 'void';
    if (g > 155 && r < 170) return 'necromancy';
  }
  return isEnemy ? 'void' : 'lightning';
}

const ELEMENT_VFX = {
  fire: {
    core: '#fff5cc',
    mid: '#ff8c38',
    outer: '#ff3b1f',
    trailColors: ['#ffaa44', '#ff5722', '#ffe082'],
    drawProjectile(ctx, pr, ang, spd, t) {
      const len = Math.min(28, 12 + spd * 0.032);
      // Flame comet envelope
      ctx.save();
      ctx.translate(pr.x, pr.y);
      ctx.rotate(ang);
      ctx.globalAlpha = 0.42;
      ctx.fillStyle = '#ff4518';
      ctx.beginPath();
      ctx.moveTo(pr.r * 1.15, 0);
      ctx.quadraticCurveTo(-pr.r * 0.4, -pr.r * 1.45, -len * 1.35, Math.sin(t * 24 + pr.x) * 2.5);
      ctx.quadraticCurveTo(-pr.r * 0.4, pr.r * 1.45, pr.r * 1.15, 0);
      ctx.fill();

      ctx.globalAlpha = 0.85;
      ctx.fillStyle = '#ff9838';
      ctx.beginPath();
      ctx.moveTo(pr.r * 0.9, 0);
      ctx.quadraticCurveTo(0, -pr.r * 0.9, -len * 0.85, 0);
      ctx.quadraticCurveTo(0, pr.r * 0.9, pr.r * 0.9, 0);
      ctx.fill();

      drawCircle(ctx, 0, 0, pr.r * 0.72, '#fff5cc');
      ctx.restore();
    },
    emitTrail(pr, o) {
      const ang = Math.atan2(pr.vy, pr.vx) + Math.PI;
      const spread = (Math.random() - 0.5) * 0.9;
      o.kind = 'ember';
      o.x = pr.x + (Math.random() - 0.5) * pr.r;
      o.y = pr.y + (Math.random() - 0.5) * pr.r;
      o.vx = Math.cos(ang + spread) * (25 + Math.random() * 45);
      o.vy = Math.sin(ang + spread) * (25 + Math.random() * 45) - 22;
      o.r = 1.8 + Math.random() * 2.4;
      o.color = this.trailColors[(Math.random() * this.trailColors.length) | 0];
      o.life = 0.22 + Math.random() * 0.16;
    },
    drawImpact(ctx, im, k) {
      const r = im.r * (0.6 + (1 - k) * 1.15);
      ctx.globalAlpha = k * 0.75;
      drawCircle(ctx, im.x, im.y, r * 0.55, '#ff5e1a55');
      drawRing(ctx, im.x, im.y, r, '#ff7b29', 2.8 * k + 0.8);
      drawRing(ctx, im.x, im.y, r * 0.62, '#fff0b3', 1.6);
      // Burning flare tongues
      ctx.strokeStyle = '#ff9f43';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = im.ang + (i / 6) * 6.283;
        ctx.moveTo(im.x + Math.cos(a) * r * 0.35, im.y + Math.sin(a) * r * 0.35);
        ctx.lineTo(im.x + Math.cos(a) * r * 1.08, im.y + Math.sin(a) * r * 1.08);
      }
      ctx.stroke();
    }
  },

  lightning: {
    core: '#ffffff',
    mid: '#7ce8ff',
    outer: '#26a9ff',
    trailColors: ['#ffffff', '#7ce8ff', '#38bdf8'],
    drawProjectile(ctx, pr, ang, spd, t) {
      drawCircle(ctx, pr.x, pr.y, pr.r * 1.75, 'rgba(64, 196, 255, 0.24)');
      // Crackling mini arcs around orb
      ctx.save();
      ctx.strokeStyle = '#9ceeff';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (let i = 0; i < 3; i++) {
        const a = t * 18 + i * 2.09;
        const r1 = pr.r * 0.9;
        const r2 = pr.r * 2.1;
        const midA = a + Math.sin(t * 45 + i) * 0.6;
        ctx.moveTo(pr.x + Math.cos(a) * r1, pr.y + Math.sin(a) * r1);
        ctx.lineTo(pr.x + Math.cos(midA) * (r1 + r2) * 0.5, pr.y + Math.sin(midA) * (r1 + r2) * 0.5);
        ctx.lineTo(pr.x + Math.cos(a + 0.35) * r2, pr.y + Math.sin(a + 0.35) * r2);
      }
      ctx.stroke();
      drawCircle(ctx, pr.x, pr.y, pr.r * 0.92, '#7ce8ff', '#ffffff', 1.4);
      ctx.restore();
    },
    emitTrail(pr, o) {
      o.kind = 'spark';
      o.x = pr.x + (Math.random() - 0.5) * pr.r * 1.4;
      o.y = pr.y + (Math.random() - 0.5) * pr.r * 1.4;
      o.vx = (Math.random() - 0.5) * 95;
      o.vy = (Math.random() - 0.5) * 95;
      o.r = 2 + Math.random() * 2;
      o.color = Math.random() < 0.45 ? '#ffffff' : '#6be3ff';
      o.life = 0.14 + Math.random() * 0.1;
    },
    drawImpact(ctx, im, k) {
      const r = im.r * (0.65 + (1 - k) * 0.95);
      ctx.globalAlpha = k * 0.9;
      drawCircle(ctx, im.x, im.y, r * 0.45, '#ffffff88');
      drawRing(ctx, im.x, im.y, r, '#6be3ff', 2.4);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.9;
      ctx.beginPath();
      for (let i = 0; i < 5; i++) {
        const a = im.ang + i * 1.256;
        const mx = im.x + Math.cos(a + 0.28) * r * 0.58;
        const my = im.y + Math.sin(a + 0.28) * r * 0.58;
        ctx.moveTo(im.x, im.y);
        ctx.lineTo(mx, my);
        ctx.lineTo(im.x + Math.cos(a) * r * 1.25, im.y + Math.sin(a) * r * 1.25);
      }
      ctx.stroke();
    }
  },

  void: {
    core: '#090314',
    mid: '#b55cff',
    outer: '#6d1dc9',
    trailColors: ['#c084fc', '#9333ea', '#f0abfc'],
    drawProjectile(ctx, pr, ang, spd, t) {
      // Distortion ripple & dark singularity core
      drawRing(ctx, pr.x, pr.y, pr.r * (1.75 + Math.sin(t * 16) * 0.25), 'rgba(181, 92, 255, 0.42)', 1.6);
      drawCircle(ctx, pr.x, pr.y, pr.r * 1.15, '#120524', '#d88cff', 1.8);
      drawDiamond(ctx, pr.x, pr.y, pr.r * 0.55, '#f5d0fe');
    },
    emitTrail(pr, o) {
      const a = Math.random() * 6.283;
      o.kind = 'wisp';
      o.x = pr.x + Math.cos(a) * pr.r * 0.7;
      o.y = pr.y + Math.sin(a) * pr.r * 0.7;
      o.vx = -pr.vx * 0.08 + Math.cos(a) * 24;
      o.vy = -pr.vy * 0.08 + Math.sin(a) * 24;
      o.r = 2.5 + Math.random() * 2.5;
      o.color = this.trailColors[(Math.random() * this.trailColors.length) | 0];
      o.life = 0.26 + Math.random() * 0.14;
    },
    drawImpact(ctx, im, k) {
      const r = im.r * (0.7 + (1 - k) * 0.85);
      // Void spatial tear slash + distortion pulse
      ctx.save();
      ctx.translate(im.x, im.y);
      ctx.rotate(im.ang + 0.6);
      ctx.globalAlpha = k * 0.88;
      drawRing(ctx, 0, 0, r * 0.9, '#b55cff', 2.2);
      ctx.fillStyle = '#090314';
      ctx.strokeStyle = '#f0abfc';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-r * 1.35, 0);
      ctx.quadraticCurveTo(0, -r * 0.36 * k, r * 1.35, 0);
      ctx.quadraticCurveTo(0, r * 0.36 * k, -r * 1.35, 0);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
  },

  holy: {
    core: '#fffbe0',
    mid: '#ffd700',
    outer: '#ff9f1a',
    trailColors: ['#fff4b8', '#ffd700', '#ffb703'],
    drawProjectile(ctx, pr, ang, spd, t) {
      drawCircle(ctx, pr.x, pr.y, pr.r * 1.7, 'rgba(255, 215, 0, 0.22)');
      drawRing(ctx, pr.x, pr.y, pr.r * 1.35, '#ffd700aa', 1.4);
      ctx.save();
      ctx.translate(pr.x, pr.y);
      ctx.rotate(ang + t * 5);
      drawDiamond(ctx, 0, 0, pr.r * 1.15, '#ffd700', '#ffffff', 1.3);
      ctx.restore();
    },
    emitTrail(pr, o) {
      o.kind = 'rune';
      o.x = pr.x + (Math.random() - 0.5) * pr.r * 1.3;
      o.y = pr.y + (Math.random() - 0.5) * pr.r * 1.3;
      o.vx = -pr.vx * 0.05 + (Math.random() - 0.5) * 20;
      o.vy = -pr.vy * 0.05 - 14;
      o.r = 2.2 + Math.random() * 2;
      o.color = Math.random() < 0.5 ? '#ffd700' : '#fff7cc';
      o.life = 0.25 + Math.random() * 0.15;
    },
    drawImpact(ctx, im, k) {
      const r = im.r * (0.65 + (1 - k) * 1.05);
      ctx.globalAlpha = k * 0.9;
      drawRing(ctx, im.x, im.y, r, '#ffd700', 2.6);
      drawRing(ctx, im.x, im.y, r * 0.62, '#fffbe0', 1.5);
      // Radiant 4-point divine cross + rune circle ticks
      ctx.strokeStyle = '#fff4b8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < 4; i++) {
        const a = im.ang + i * 1.5708;
        ctx.moveTo(im.x + Math.cos(a) * r * 0.2, im.y + Math.sin(a) * r * 0.2);
        ctx.lineTo(im.x + Math.cos(a) * r * 1.35, im.y + Math.sin(a) * r * 1.35);
      }
      ctx.stroke();
    }
  },

  necromancy: {
    core: '#a8ffd6',
    mid: '#5effb1',
    outer: '#112e22',
    trailColors: ['#5effb1', '#1a3d2e', '#d6d0c0'],
    drawProjectile(ctx, pr, ang, spd, t) {
      // Green-black shroud + spectral soul orb
      drawCircle(ctx, pr.x, pr.y, pr.r * 1.65, 'rgba(12, 28, 22, 0.55)', 'rgba(94, 255, 177, 0.45)', 1.2);
      drawCircle(ctx, pr.x, pr.y, pr.r * 0.85, '#5effb1', '#0a1712', 1.3);
      const bx = pr.x + Math.cos(t * 10 + pr.y) * pr.r * 1.2;
      const by = pr.y + Math.sin(t * 10 + pr.x) * pr.r * 1.2;
      ctx.fillStyle = '#dcd4c4';
      ctx.fillRect(bx - 1.5, by - 1.5, 3, 3);
    },
    emitTrail(pr, o) {
      const isBone = Math.random() < 0.26;
      o.kind = isBone ? 'bone' : 'mist';
      o.x = pr.x + (Math.random() - 0.5) * pr.r * 1.2;
      o.y = pr.y + (Math.random() - 0.5) * pr.r * 1.2;
      o.vx = -pr.vx * 0.08 + (Math.random() - 0.5) * 38;
      o.vy = -pr.vy * 0.08 + (Math.random() - 0.5) * 38 - (isBone ? 0 : 12);
      o.r = isBone ? 2.4 : 3.6 + Math.random() * 2.5;
      o.color = isBone ? '#dcd4c4' : Math.random() < 0.45 ? '#5effb1' : '#0f241c';
      o.life = 0.28 + Math.random() * 0.18;
    },
    drawImpact(ctx, im, k) {
      const r = im.r * (0.65 + (1 - k) * 0.95);
      // Necrotic green-black mist ring + rising soul & bone splinters
      ctx.globalAlpha = k * 0.82;
      drawCircle(ctx, im.x, im.y, r * 0.72, 'rgba(12, 28, 22, 0.55)');
      drawRing(ctx, im.x, im.y, r, '#5effb1', 2.2);
      // Rising soul wisp
      drawCircle(ctx, im.x, im.y - (1 - k) * 18, 4.5 * k, '#a8ffd6');
      // Outward bone shards
      ctx.strokeStyle = '#dcd4c4';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < 4; i++) {
        const a = im.ang + i * 1.57 + (1 - k) * 0.8;
        const d = r * (0.45 + (1 - k) * 0.6);
        ctx.moveTo(im.x + Math.cos(a) * d, im.y + Math.sin(a) * d);
        ctx.lineTo(im.x + Math.cos(a) * (d + 6), im.y + Math.sin(a) * (d + 6));
      }
      ctx.stroke();
    }
  }
};

function acquireSpellParticle() {
  const cap = Math.min(SP_MAX, perf.spellCap);
  if (spHead >= cap) spHead = 0;
  const sp = spellParticles[spHead];
  if (sp.life <= 0) {
    // Global particle budget (shared with the main particle pool).
    if (partPool.active.length + spLive >= PARTICLE_BUDGET) return null;
    spLive++;
  }
  spHead++;
  return sp;
}

export function spawnElementalImpact(x, y, elem, r = 18, crit = false, ang = Math.random() * 6.283) {
  if (!onScreen(x, y, 60)) return;
  if (!crit && perf.impactProb < 1 && Math.random() > perf.impactProb) return;

  const rad = r * (crit ? 1.45 : 1.0);

  // Merge with a fresh, nearby impact of the same element instead of stacking another.
  if (perf.level >= 1) {
    for (let i = 0; i < IM_MAX; i++) {
      const o = spellImpacts[i];
      if (o.life > o.maxLife * 0.55 && o.elem === elem) {
        const dx = o.x - x;
        const dy = o.y - y;
        if (dx * dx + dy * dy < 400) {
          if (rad > o.r) o.r = rad;
          return;
        }
      }
    }
  }

  const cap = Math.min(IM_MAX, perf.impactCap);
  if (imHead >= cap) imHead = 0;
  const im = spellImpacts[imHead++];
  im.x = x;
  im.y = y;
  im.elem = elem;
  im.r = rad;
  im.ang = ang;
  im.crit = crit;
  im.life = im.maxLife = crit ? 0.28 : 0.20;

  // Burst of element-specific particles (scaled by quality level + budget)
  const low = metaSave.settings.gfxQuality === 'low';
  const vfx = ELEMENT_VFX[elem] || ELEMENT_VFX.fire;
  let count = low ? 2 : crit ? 7 : 4;
  count = Math.round(count * perf.burstMul);
  if (crit) count = Math.max(2, count);
  else if (perf.level >= 3 && Math.random() < 0.5) count = 0;
  for (let i = 0; i < count; i++) {
    const sp = acquireSpellParticle();
    if (!sp) break;
    const a = (i / count) * 6.283 + (Math.random() - 0.5) * 0.6;
    const spd = (crit ? 175 : 115) * (0.5 + Math.random() * 0.7);
    sp.kind = elem === 'holy' ? 'rune' : elem === 'necromancy' ? (i % 2 ? 'bone' : 'mist') : elem === 'lightning' ? 'spark' : 'ember';
    sp.x = x;
    sp.y = y;
    sp.vx = Math.cos(a) * spd;
    sp.vy = Math.sin(a) * spd;
    sp.r = (crit ? 3.2 : 2.3) + Math.random() * 1.4;
    sp.color = vfx.trailColors[i % vfx.trailColors.length];
    sp.life = sp.maxLife = 0.22 + Math.random() * 0.14;
  }
}

function initTrail(pr) {
  if (!pr._trail) {
    pr._trail = [
      { x: pr.x, y: pr.y },
      { x: pr.x, y: pr.y },
      { x: pr.x, y: pr.y },
      { x: pr.x, y: pr.y },
      { x: pr.x, y: pr.y }
    ];
  } else {
    for (let i = 0; i < pr._trail.length; i++) {
      pr._trail[i].x = pr.x;
      pr._trail[i].y = pr.y;
    }
  }
  pr._trailCd = Math.random() * 0.02;
}

function pushTrailPoint(pr) {
  if (!pr._trail) initTrail(pr);
  const tr = pr._trail;
  for (let i = tr.length - 1; i > 0; i--) {
    tr[i].x = tr[i - 1].x;
    tr[i].y = tr[i - 1].y;
  }
  tr[0].x = pr.x;
  tr[0].y = pr.y;
}

// ============================================================================
// CORE PROJECTILE & COMBAT HELPERS
// ============================================================================

// ============================================================================
// WEAPON RANGE, TARGETING & PROJECTILE TRAVEL (single source of truth)
// ============================================================================

export const RANGE_CFG = {
  // Base attack range per weapon type (world units). Fully configurable.
  weaponTypes: { dagger: 120, sword: 180, greatsword: 220, hammer: 180, bow: 550, staff: 500, grimoire: 450 },
  defaultWeaponRange: 400,
  // Fallback when a weapon key matches no rule (and WEAPONS_DEF has no rangeType)
  classWeaponType: { warrior: 'greatsword', assassin: 'dagger', paladin: 'hammer', ranger: 'bow', mage: 'staff', necromancer: 'grimoire' },
  meleeTypes: ['dagger', 'sword', 'greatsword', 'hammer'],
  // Max distance a projectile may travel before it is destroyed
  projectileTravel: { fireball: 650, arrow: 700, bonespear: 600, lightning: 500, void: 600, holy: 600 },
  defaultProjectileTravel: 600,
  meleeTravelMult: 1.15,     // melee "projectiles" only overshoot their weapon range slightly
  rangedTravelMargin: 1.1,   // a shot always out-travels the range it was fired at
  fadeStart: 0.88,           // projectiles shrink out over the last 12% of their travel
  // Summon attack ranges (before the range stat)
  summonRange: { default: 320, melee: 130, ranged: 380 },
  // Clamp for the player's range stat multiplier
  minMult: 0.5,
  maxMult: 3,
  // Optionally also require targets to be on screen
  requireOnScreen: false,
  onScreenPad: 40
};

// First match wins (greatsword before sword, etc.). Per-weapon overrides: WEAPONS_DEF[key].rangeType / .range / .projRange
const WEAPON_TYPE_RULES = [
  [/dagger|knife|claw|shiv|stiletto|kris/, 'dagger'],
  [/greatsword|claymore|zweihander|scythe|halberd|glaive|axe/, 'greatsword'],
  [/hammer|mace|maul|flail|crusher/, 'hammer'],
  [/sword|blade|saber|sabre|katana|rapier|cleaver|spear/, 'sword'],
  [/bow|arrow|crossbow/, 'bow'],
  [/grimoire|tome|spellbook|codex|book/, 'grimoire'],
  [/staff|wand|rod|scepter|orb|fireball|bolt|nova|lightning|storm/, 'staff']
];
const weaponTypeMemo = new Map();

export function getWeaponType(wKey, clsId = state.player?.cls?.id) {
  const k = `${wKey || ''}|${clsId || ''}`;
  let v = weaponTypeMemo.get(k);
  if (v !== undefined) return v;
  const def = wKey ? WEAPONS_DEF[wKey] : null;
  v = null;
  if (def && RANGE_CFG.weaponTypes[def.rangeType] !== undefined) {
    v = def.rangeType;
  } else if (wKey) {
    const lk = String(wKey).toLowerCase();
    for (let i = 0; i < WEAPON_TYPE_RULES.length; i++) {
      if (WEAPON_TYPE_RULES[i][0].test(lk)) {
        v = WEAPON_TYPE_RULES[i][1];
        break;
      }
    }
  }
  if (!v && clsId) v = RANGE_CFG.classWeaponType[clsId] || null;
  weaponTypeMemo.set(k, v);
  return v;
}

export function isMeleeWeapon(wKey, clsId) {
  return RANGE_CFG.meleeTypes.includes(getWeaponType(wKey, clsId));
}

// The player's range stat (multiplier). Blessings, relics, items and the skill tree raise `stats.range`.
export function getRangeMult() {
  const m = state.player?.stats?.range;
  return Number.isFinite(m) ? Math.min(RANGE_CFG.maxMult, Math.max(RANGE_CFG.minMult, m)) : 1;
}

export function getWeaponRange(wKey, clsId) {
  const def = wKey ? WEAPONS_DEF[wKey] : null;
  const type = getWeaponType(wKey, clsId);
  const base = def && Number.isFinite(def.range) ? def.range : RANGE_CFG.weaponTypes[type] ?? RANGE_CFG.defaultWeaponRange;
  return base * getRangeMult();
}

const ELEM_TRAVEL_KEY = { fire: 'fireball', lightning: 'lightning', necromancy: 'bonespear', void: 'void', holy: 'holy' };

// Max travel distance for a player projectile. Skill projectiles (no weapon key) use their element only.
export function getProjectileTravel(wKey, elem, clsId) {
  const def = wKey ? WEAPONS_DEF[wKey] : null;
  const mult = getRangeMult();
  if (def && Number.isFinite(def.projRange)) return def.projRange * mult;
  const type = wKey ? getWeaponType(wKey, clsId) : null;
  const wRange = wKey ? getWeaponRange(wKey, clsId) : 0;
  if (type && RANGE_CFG.meleeTypes.includes(type)) return wRange * RANGE_CFG.meleeTravelMult;
  const typeKey = type === 'bow' ? 'arrow' : ELEM_TRAVEL_KEY[elem];
  const base = RANGE_CFG.projectileTravel[typeKey] ?? RANGE_CFG.defaultProjectileTravel;
  return Math.max(base * mult, wRange * RANGE_CFG.rangedTravelMargin);
}

export function getSummonRange(key, kind = 'default') {
  const def = key ? WEAPONS_DEF[key] : null;
  const base = def && Number.isFinite(def.range) ? def.range : RANGE_CFG.summonRange[kind] ?? RANGE_CFG.summonRange.default;
  return base * getRangeMult();
}

/**
 * THE targeting function. Returns the closest living enemy within `range` of (x, y), or null.
 * Range is measured to the enemy's edge, so a dagger can hit what it can touch.
 * opts.hitBias (<1) makes recently-hit enemies preferred (used for melee VFX facing).
 */
export function findTarget(x, y, range, opts) {
  if (!(range > 0)) return null;
  const hitBias = opts?.hitBias ?? 1;
  const visible = opts?.requireVisible ?? RANGE_CFG.requireOnScreen;
  enemyGrid.query(x, y, range + 48, qBuf);
  let best = null;
  let bd = Infinity;
  for (let i = 0; i < qBuf.length; i++) {
    const e = qBuf[i];
    if (!e.alive || e.spawnT > 0) continue;
    const reach = range + e.r;
    const d2 = (e.x - x) ** 2 + (e.y - y) ** 2;
    if (d2 > reach * reach) continue;
    if (visible && !onScreen(e.x, e.y, RANGE_CFG.onScreenPad)) continue;
    const w = hitBias !== 1 && e.hitFlash > 0.02 ? d2 * hitBias : d2;
    if (w < bd) {
      bd = w;
      best = e;
    }
  }
  return best;
}

// Weapon auto-target: nearest enemy inside this weapon's range, else null (=> do not attack).
export function targetForWeapon(wKey, x = state.player.x, y = state.player.y) {
  return findTarget(x, y, getWeaponRange(wKey));
}

export function targetForSummon(s, key, kind) {
  return findTarget(s.x, s.y, getSummonRange(key, kind));
}

// Back-compat wrapper. Third argument may be a radius or a weapon key.
export function nearestEnemy(x, y, maxR = 620) {
  return findTarget(x, y, typeof maxR === 'string' ? getWeaponRange(maxR) : maxR);
}

export function fireProj(x, y, dx, dy, spd, dmgMult, color, pierce = 0, life = 1.4, homing = false, critB = 0, wKey = null, maxTravel = null) {
  const p = state.player;
  const pr = projPool.spawn();
  const mult = p.stats.dmgPct + (p.stats.keystones.has('Blood Sacrifice') ? (1 - p.hp / p.maxHp) * 1.1 : 0);
  const elem = resolveSpellElement(wKey, color, false);
  Object.assign(pr, {
    x,
    y,
    vx: dx * spd,
    vy: dy * spd,
    r: 6 * Math.min(1.8, 0.85 + p.stats.areaPct * 0.18),
    dmg: p.stats.flatDmg * mult * dmgMult * (wKey ? weaponMult(wKey) : 1),
    pierce: p.stats.uniques.has('voidprism') ? 999 : pierce,
    life,
    color,
    isEnemy: false,
    homing,
    weaponKey: wKey,
    critBonus: critB,
    elem,
    travel: 0,
    maxTravel: maxTravel > 0 ? maxTravel : getProjectileTravel(wKey, elem, p.cls?.id),
    _fade: 1
  });
  pr.hitIds.clear();
  pr._tgt = null;
  pr._homeCd = 0;
  initTrail(pr);
}

export function spawnEnemyProj(x, y, vx, vy, r, dmg, life, color, maxTravel = null) {
  const ep = projPool.spawn();
  const elem = resolveSpellElement(null, color, true);
  Object.assign(ep, {
    x,
    y,
    vx,
    vy,
    r,
    dmg,
    life,
    color,
    isEnemy: true,
    pierce: 0,
    homing: false,
    weaponKey: null,
    critBonus: 0,
    elem,
    travel: 0,
    maxTravel: maxTravel > 0 ? maxTravel : Math.hypot(vx, vy) * life,
    _fade: 1
  });
  ep.hitIds.clear();
  initTrail(ep);
}

export function addTelegraph(kind, x, y, dmg, dur, color, extra = {}) {
  if (telegraphs.length < 36) {
    telegraphs.push({ kind, x, y, dmg, t: 0, dur, color, r: 60, ang: 0, spread: 1, len: 260, w: 18, ...extra });
  }
}

export function hitEnemy(e, rawDmg, critB = 0, allowChain = true, wKey = null, hitElem = null) {
  if (!e.alive || e.spawnT > 0) return;

  const p = state.player;
  const crit = Math.random() < p.stats.critChance + critB;
  let dmg = Math.max(1, Math.round(rawDmg * (crit ? p.stats.critDmg : 1)));

  if (e.shieldHp > 0) {
    const ab = Math.min(e.shieldHp, dmg);
    e.shieldHp -= ab;
    dmg -= ab;
    spawnParticles(e.x, e.y, '#ffd700', 3, 90);
    if (dmg <= 0) {
      spawnFloatText(e.x, e.y, 'SHIELD', '#ffd700', 11);
      return;
    }
  }

  e.hp -= dmg;
  e.hitFlash = 0.08;
  if (state.time - lastHitSfx >= 0.035 || state.time < lastHitSfx) {
    lastHitSfx = state.time;
    sfx.play('hit');
  }
  state.director.fDmg += dmg;

  if (wKey) addMasteryXp(WEAPONS_DEF[wKey].mastery, 0.35);
  if (p.stats.lifeSteal > 0 && p.hp < p.maxHp) {
    p.hp = Math.min(
      p.maxHp,
      p.hp + dmg * p.stats.lifeSteal * 0.25 * (p.stats.keystones.has('Blood Sacrifice') ? 0.75 : 1)
    );
  }

  const elem = hitElem || (wKey ? resolveSpellElement(wKey, null, false) : null);
  if (elem) {
    spawnElementalImpact(e.x, e.y, elem, Math.max(14, e.r * 1.1), crit);
  }

  if (crit) {
    addShake(2.2);
    if (impacts.length < perf.hitImpactCap) {
      impacts.push({ x: e.x, y: e.y, r: e.r + 12, color: '#ffd700', life: 0.16, maxLife: 0.16, ang: Math.random() * 3.14, crit: true });
    }
    spawnParticles(e.x, e.y, '#ffd700', 4, 150);
  } else if (impacts.length < perf.hitImpactCap && Math.random() < 0.35 * perf.impactProb) {
    impacts.push({ x: e.x, y: e.y, r: e.r + 6, color: '#ffffff', life: 0.1, maxLife: 0.1, ang: Math.random() * 3.14, crit: false });
  }

  queueDamageText(e, dmg, crit);

  if (allowChain && p.stats.uniques.has('stormlord') && Math.random() < 0.35) {
    chainLightning(e.x, e.y, dmg * 0.55, 10, '#6fa8dc');
  }

  if (e.hp <= 0) killEnemy(e);
}

export function chainLightning(sx, sy, dmg, jumps, color) {
  const seen = new Set();
  const pts = [{ x: sx, y: sy }];
  let cx = sx;
  let cy = sy;

  for (let j = 0; j < jumps; j++) {
    enemyGrid.query(cx, cy, 240, qBuf);
    let nxt = null;
    let bd2 = 240 * 240;
    for (let i = 0; i < qBuf.length; i++) {
      const e = qBuf[i];
      if (!e.alive || e.spawnT > 0 || seen.has(e)) continue;
      const d2 = (e.x - cx) ** 2 + (e.y - cy) ** 2;
      if (d2 < bd2) {
        bd2 = d2;
        nxt = e;
      }
    }
    if (!nxt) break;
    seen.add(nxt);

    // Jagged intermediate lightning vertices for sharp electrical arc feel
    const mx = (cx + nxt.x) * 0.5 + (Math.random() - 0.5) * 26;
    const my = (cy + nxt.y) * 0.5 + (Math.random() - 0.5) * 26;
    pts.push({ x: mx, y: my }, { x: nxt.x, y: nxt.y });

    hitEnemy(nxt, dmg, 0, false, null, 'lightning');
    cx = nxt.x;
    cy = nxt.y;
  }

  if (pts.length > 1) {
    pushArc({ pts, life: 0.18, color: color || '#7ce8ff' });
    spawnElementalImpact(sx, sy, 'lightning', 18, false);
  }
}

// Reset range bookkeeping on release so a recycled pool slot never inherits a stale limit.
function releaseProj(i, pr) {
  pr.travel = 0;
  pr.maxTravel = 0;
  pr._fade = 1;
  projPool.release(i);
}

export function updateProjectiles(dt) {
  resetSpellVfxIfNeeded();

  let live = 0;
  for (let i = 0; i < SP_MAX; i++) {
    const sp = spellParticles[i];
    if (sp.life <= 0) continue;
    sp.x += sp.vx * dt;
    sp.y += sp.vy * dt;
    if ((sp.life -= dt) > 0) live++;
  }
  spLive = live;
  for (let i = 0; i < IM_MAX; i++) {
    const im = spellImpacts[i];
    if (im.life > 0) im.life -= dt;
  }
  flushDamageText(dt);

  const p = state.player;
  const low = metaSave.settings.gfxQuality === 'low';
  const trailStep = (low ? 0.045 : 0.022) * perf.trailStepMul;

  // Camera rect (with margin) - trail particles are never emitted off-screen
  const cam = state.camera;
  const vx0 = cam.x - cam.worldW * 0.5 - 80;
  const vx1 = cam.x + cam.worldW * 0.5 + 80;
  const vy0 = cam.y - cam.worldH * 0.5 - 80;
  const vy1 = cam.y + cam.worldH * 0.5 + 80;

  for (let i = projPool.active.length - 1; i >= 0; i--) {
    const pr = projPool.active[i];
    if (pr.homing && !pr.isEnemy) {
      // Re-target 10x/sec instead of a spatial query every frame
      if ((pr._homeCd -= dt) <= 0 || !pr._tgt || !pr._tgt.alive) {
        pr._homeCd = 0.1;
        pr._tgt = nearestEnemy(pr.x, pr.y, 260);
      }
      const tgt = pr._tgt;
      if (tgt && tgt.alive) {
        const a = Math.atan2(tgt.y - pr.y, tgt.x - pr.x);
        const spd = Math.hypot(pr.vx, pr.vy);
        pr.vx += (Math.cos(a) * spd - pr.vx) * dt * 6;
        pr.vy += (Math.sin(a) * spd - pr.vy) * dt * 6;
      }
    }

    pr.x += pr.vx * dt;
    pr.y += pr.vy * dt;
    pr.life -= dt;

    // Travel limit: expire cleanly (shrink, then fizzle) instead of flying on
    let rangeDone = false;
    if (pr.maxTravel > 0) {
      pr.travel += Math.hypot(pr.vx, pr.vy) * dt;
      const f = pr.travel / pr.maxTravel;
      if (f >= 1) rangeDone = true;
      else pr._fade = f > RANGE_CFG.fadeStart ? (1 - f) / (1 - RANGE_CFG.fadeStart) : 1;
    }

    pushTrailPoint(pr);
    let elem = pr.elem;
    if (!elem) elem = pr.elem = resolveSpellElement(pr.weaponKey, pr.color, pr.isEnemy);

    if ((pr._trailCd -= dt) <= 0) {
      pr._trailCd = trailStep;
      if (pr._fade >= 1 && pr.x > vx0 && pr.x < vx1 && pr.y > vy0 && pr.y < vy1) {
        const vfx = ELEMENT_VFX[elem];
        const sp = vfx ? acquireSpellParticle() : null;
        if (sp) {
          vfx.emitTrail(pr, sp);
          sp.maxLife = sp.life;
        }
      }
    }

    if (pr.life <= 0 || rangeDone || pr.x < 0 || pr.x > CFG.game.W || pr.y < 0 || pr.y > CFG.game.H) {
      if (pr.life <= 0 || rangeDone) {
        spawnElementalImpact(pr.x, pr.y, elem, pr.r * (rangeDone ? 1.15 : 1.9), false, Math.atan2(pr.vy, pr.vx));
      }
      releaseProj(i, pr);
      continue;
    }

    if (pr.isEnemy) {
      if ((pr.x - p.x) ** 2 + (pr.y - p.y) ** 2 < (pr.r + p.r) ** 2) {
        spawnElementalImpact(pr.x, pr.y, elem, pr.r * 2.4, false, Math.atan2(pr.vy, pr.vx));
        damagePlayer(pr.dmg);
        releaseProj(i, pr);
      }
    } else {
      enemyGrid.query(pr.x, pr.y, pr.r + 68, qBuf);
      for (let j = 0; j < qBuf.length; j++) {
        const e = qBuf[j];
        if (e.alive && e.spawnT <= 0 && !pr.hitIds.has(e) && (pr.x - e.x) ** 2 + (pr.y - e.y) ** 2 < (pr.r + e.r) ** 2) {
          pr.hitIds.add(e);
          hitEnemy(e, pr.dmg, pr.critBonus, true, pr.weaponKey, elem);
          if (pr.pierce > 0) {
            pr.pierce--;
          } else {
            releaseProj(i, pr);
            break;
          }
        }
      }
    }
  }
}

export function updateTelegraphs(dt) {
  const p = state.player;
  for (let i = telegraphs.length - 1; i >= 0; i--) {
    const tg = telegraphs[i];
    tg.t += dt;
    if (tg.t < tg.dur) continue;

    const elem = resolveSpellElement(null, tg.color, true);
    if (tg.kind === 'circle' || tg.kind === 'shockwave') {
      if ((p.x - tg.x) ** 2 + (p.y - tg.y) ** 2 <= (tg.r + p.r) ** 2) damagePlayer(tg.dmg);
      pushArc({ ring: { x: tg.x, y: tg.y, r: tg.r }, life: 0.22, color: tg.color });
      spawnElementalImpact(tg.x, tg.y, elem, tg.r * 0.65, true);
      spawnParticles(tg.x, tg.y, tg.color, 14, 180);
    } else if (tg.kind === 'cone') {
      if (Math.hypot(p.x - tg.x, p.y - tg.y) <= tg.r + p.r) {
        let da = Math.atan2(p.y - tg.y, p.x - tg.x) - tg.ang;
        while (da > Math.PI) da -= 6.283;
        while (da < -Math.PI) da += 6.283;
        if (Math.abs(da) <= tg.spread * 0.5) damagePlayer(tg.dmg);
      }
      pushArc({ cone: { x: tg.x, y: tg.y, r: tg.r, ang: tg.ang, spread: tg.spread }, life: 0.2, color: tg.color });
    } else if (tg.kind === 'beam') {
      const vx = Math.cos(tg.ang);
      const vy = Math.sin(tg.ang);
      const px = p.x - tg.x;
      const py = p.y - tg.y;
      const proj = Math.max(0, Math.min(tg.len, px * vx + py * vy));
      if ((px - vx * proj) ** 2 + (py - vy * proj) ** 2 <= (tg.w * 0.5 + p.r) ** 2) damagePlayer(tg.dmg);
      pushArc({ beam: { x: tg.x, y: tg.y, ex: tg.x + vx * tg.len, ey: tg.y + vy * tg.len, w: tg.w }, life: 0.22, color: tg.color });
      addShake(4);
    }
    telegraphs.splice(i, 1);
  }
}

export function updateHazards(dt) {
  const p = state.player;
  for (let i = hazards.length - 1; i >= 0; i--) {
    const h = hazards[i];
    h.life -= dt;
    if (h.isEnemy) {
      if ((h.x - p.x) ** 2 + (h.y - p.y) ** 2 < (h.r + p.r) ** 2) damagePlayer(h.dmg);
    } else {
      enemyGrid.query(h.x, h.y, h.r, qBuf);
      const elem = h._elemU || (h._elemU = resolveSpellElement(h.weaponKey, h.color, false));
      for (let j = 0; j < qBuf.length; j++) {
        const e = qBuf[j];
        if (e.alive && e.spawnT <= 0 && e.hitFlash <= 0 && (e.x - h.x) ** 2 + (e.y - h.y) ** 2 < (h.r + e.r) ** 2) {
          hitEnemy(e, h.dmg * dt * 2.5, 0, false, h.weaponKey, elem);
        }
      }
    }
    if (h.life <= 0) hazards.splice(i, 1);
  }
}

export function renderHazards(ctx, inView) {
  const n = hazards.length;
  if (!n) return;
  const t = state.time;
  const pulse = Math.sin(t * 9) * 0.04;
  // 0 = full fill + ring, 1 = faint single fill, 2 = outline only (many overlapping pools)
  const mode = n >= 9 || perf.level >= 3 ? 2 : n >= 5 || perf.level >= 2 ? 1 : 0;

  for (let i = 0; i < n; i++) {
    const h = hazards[i];
    if (inView && !inView(h.x, h.y, h.r + 16)) continue;
    const k = Math.max(0.15, h.life / h.maxLife);
    const elem = h._elemR || (h._elemR = resolveSpellElement(h.weaponKey, h.color, h.isEnemy));

    if (mode === 0) {
      ctx.globalAlpha = k * 0.36;
      drawCircle(ctx, h.x, h.y, h.r, h.color);
    } else if (mode === 1) {
      ctx.globalAlpha = k * 0.14;
      drawCircle(ctx, h.x, h.y, h.r, h.color);
    }
    ctx.globalAlpha = Math.min(1, k * (mode === 2 ? 0.9 : 0.72));
    drawRing(ctx, h.x, h.y, h.r * (0.94 + pulse), h.color, mode === 2 || h.isEnemy ? 2.8 : 2.2);
    if (mode < 2) {
      if (elem === 'holy') {
        drawRing(ctx, h.x, h.y, h.r * 0.65, '#fff4b8', 1.4);
      } else if (elem === 'void') {
        drawRing(ctx, h.x, h.y, h.r * 0.55, '#090314', 3);
      }
    }
  }
  ctx.globalAlpha = 1;
}

export function drawTelegraph(ctx, tg, dense = perf.denseAoe) {
  const p = Math.min(1, tg.t / tg.dur);
  ctx.save();
  if (tg.kind === 'circle') {
    if (dense) {
      // Outline-only: danger zone ring + growing fill-progress ring
      ctx.globalAlpha = 0.9;
      drawRing(ctx, tg.x, tg.y, tg.r, tg.color, 2.4);
      ctx.globalAlpha = 0.4 + p * 0.5;
      drawRing(ctx, tg.x, tg.y, tg.r * p, tg.color, 2);
    } else {
      ctx.globalAlpha = 0.16 + p * 0.14;
      drawCircle(ctx, tg.x, tg.y, tg.r, tg.color);
      ctx.globalAlpha = 0.35 + p * 0.45;
      drawCircle(ctx, tg.x, tg.y, tg.r * p, tg.color);
      ctx.globalAlpha = 0.85;
      drawRing(ctx, tg.x, tg.y, tg.r, tg.color, 2);
    }
  } else if (tg.kind === 'shockwave') {
    ctx.globalAlpha = 0.75;
    drawRing(ctx, tg.x, tg.y, tg.r, tg.color, 2);
    ctx.globalAlpha = 0.35 + p * 0.5;
    drawRing(ctx, tg.x, tg.y, tg.r * p, tg.color, 4);
  } else if (tg.kind === 'cone') {
    const a0 = tg.ang - tg.spread * 0.5;
    const a1 = tg.ang + tg.spread * 0.5;
    ctx.fillStyle = tg.color;
    ctx.strokeStyle = tg.color;
    ctx.lineWidth = 2;
    if (!dense) {
      ctx.globalAlpha = 0.18;
      ctx.beginPath();
      ctx.moveTo(tg.x, tg.y);
      ctx.arc(tg.x, tg.y, tg.r, a0, a1);
      ctx.closePath();
      ctx.fill();
      ctx.globalAlpha = 0.38;
      ctx.beginPath();
      ctx.moveTo(tg.x, tg.y);
      ctx.arc(tg.x, tg.y, tg.r * p, a0, a1);
      ctx.closePath();
      ctx.fill();
    } else {
      ctx.globalAlpha = 0.45 + p * 0.4;
      ctx.beginPath();
      ctx.arc(tg.x, tg.y, tg.r * p, a0, a1);
      ctx.stroke();
    }
    ctx.globalAlpha = 0.85;
    ctx.beginPath();
    ctx.moveTo(tg.x, tg.y);
    ctx.arc(tg.x, tg.y, tg.r, a0, a1);
    ctx.closePath();
    ctx.stroke();
  } else if (tg.kind === 'beam') {
    ctx.translate(tg.x, tg.y);
    ctx.rotate(tg.ang);
    ctx.fillStyle = tg.color;
    if (!dense) {
      ctx.globalAlpha = 0.2 + p * 0.25;
      ctx.fillRect(0, -tg.w * 0.5, tg.len, tg.w);
    }
    ctx.globalAlpha = 0.85;
    ctx.fillRect(0, -1.5, tg.len, 3);
    ctx.strokeStyle = tg.color;
    ctx.lineWidth = dense ? 2 : 1.5;
    ctx.strokeRect(0, -tg.w * 0.5, tg.len, tg.w);
  }
  ctx.restore();
}

export function renderTelegraphs(ctx, inView) {
  const dense = perf.denseAoe;
  for (let i = 0; i < telegraphs.length; i++) {
    const tg = telegraphs[i];
    if (inView && !inView(tg.x, tg.y, (tg.kind === 'beam' ? tg.len : tg.r) + 24)) continue;
    drawTelegraph(ctx, tg, dense);
  }
}

const ELEM_KEYS = ['fire', 'lightning', 'void', 'holy', 'necromancy'];
const ELEM_INDEX = { fire: 0, lightning: 1, void: 2, holy: 3, necromancy: 4 };
const LITE_CORE = { fire: '#fff5cc', lightning: '#ffffff', void: '#f5d0fe', holy: '#fffbe0', necromancy: '#a8ffd6' };
const ENEMY_FULL_MAX = 60; // beyond this many visible enemy projectiles, they also get the lite style
const projBuckets = [[], [], [], [], []];

function renderSpellParticles(ctx, inView) {
  const skipMist = !perf.decor;
  for (let i = 0; i < SP_MAX; i++) {
    const sp = spellParticles[i];
    if (sp.life <= 0) continue;
    const kind = sp.kind;
    if (skipMist && kind === 'mist') continue;
    if (!inView(sp.x, sp.y, 24)) continue;
    const k = sp.life / sp.maxLife;
    ctx.globalAlpha = kind === 'mist' ? k * 0.55 : k * 0.88;
    if (kind === 'rune') {
      drawDiamond(ctx, sp.x, sp.y, sp.r * (0.7 + k * 0.5), sp.color);
    } else if (kind === 'bone') {
      ctx.save();
      ctx.translate(sp.x, sp.y);
      ctx.rotate(sp.life * 14);
      ctx.fillStyle = sp.color;
      ctx.fillRect(-sp.r * 1.1, -sp.r * 0.45, sp.r * 2.2, sp.r * 0.9);
      ctx.restore();
    } else if (kind === 'spark') {
      ctx.strokeStyle = sp.color;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(sp.x - sp.vx * 0.03, sp.y - sp.vy * 0.03);
      ctx.lineTo(sp.x, sp.y);
      ctx.stroke();
    } else {
      const rad = Math.max(0.3, sp.r * (kind === 'mist' ? 1.5 - k * 0.4 : k));
      ctx.fillStyle = sp.color;
      ctx.beginPath();
      ctx.arc(sp.x, sp.y, rad, 0, 6.2832);
      ctx.fill();
    }
  }
  ctx.globalAlpha = 1;
}

function renderProjectileBodies(ctx, inView, t) {
  const act = projPool.active;
  const n = act.length;
  if (!n) return;

  // Single culling pass (result reused by every later pass)
  let vis = 0;
  let enemyVis = 0;
  for (let i = 0; i < n; i++) {
    const pr = act[i];
    const v = inView(pr.x, pr.y, 48);
    pr._vis = v;
    if (v) {
      vis++;
      if (pr.isEnemy) enemyVis++;
    }
  }
  if (!vis) return;

  const mode = perf.trailMode; // 0 full ribbon, 1 short ribbon, 2 batched streak, 3 batched velocity streak
  const lite = perf.liteProj;
  const enemyLite = enemyVis > ENEMY_FULL_MAX;

  const needBuckets = mode >= 2 || lite;
  if (needBuckets) {
    for (let b = 0; b < 5; b++) projBuckets[b].length = 0;
    for (let i = 0; i < n; i++) {
      const pr = act[i];
      if (!pr._vis) continue;
      const ei = ELEM_INDEX[pr.elem];
      if (ei !== undefined) projBuckets[ei].push(pr);
    }
  }

  ctx.save();
  ctx.lineCap = 'round';

  // ---- 1) Motion streaks ----
  if (mode <= 1) {
    const segMax = mode === 0 ? 5 : 3;
    for (let i = 0; i < n; i++) {
      const pr = act[i];
      if (!pr._vis || !pr._trail) continue;
      const tr = pr._trail;
      const tl = Math.min(tr.length, segMax);
      if (tl < 2) continue;
      const vfx = ELEMENT_VFX[pr.elem] || ELEMENT_VFX.fire;
      ctx.strokeStyle = vfx.mid;
      for (let j = 0; j < tl - 1; j++) {
        const a = tr[j];
        const b = tr[j + 1];
        const f = 1 - j / tl;
        ctx.globalAlpha = f * 0.48;
        ctx.lineWidth = Math.max(1.5, pr.r * 1.45 * f);
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
    }
  } else {
    // One stroke per element for ALL projectiles
    ctx.globalAlpha = 0.4;
    ctx.lineWidth = 5.5;
    for (let e = 0; e < 5; e++) {
      const arr = projBuckets[e];
      if (!arr.length) continue;
      ctx.beginPath();
      for (let i = 0; i < arr.length; i++) {
        const pr = arr[i];
        let sx;
        let sy;
        if (mode === 2 && pr._trail && pr._trail.length > 3) {
          sx = pr._trail[3].x;
          sy = pr._trail[3].y;
        } else {
          sx = pr.x - pr.vx * 0.035;
          sy = pr.y - pr.vy * 0.035;
        }
        ctx.moveTo(sx, sy);
        ctx.lineTo(pr.x, pr.y);
      }
      ctx.strokeStyle = ELEMENT_VFX[ELEM_KEYS[e]].mid;
      ctx.stroke();
    }
  }
  ctx.globalAlpha = 1;

  // ---- 2) Projectile bodies ----
  // Full elemental silhouettes: everything when not lite; only enemy shots when lite (readability).
  for (let i = 0; i < n; i++) {
    const pr = act[i];
    if (!pr._vis) continue;
    if (lite && !(pr.isEnemy && !enemyLite)) continue;
    const vfx = ELEMENT_VFX[pr.elem] || ELEMENT_VFX.fire;
    const ang = Math.atan2(pr.vy, pr.vx);
    const spd = Math.hypot(pr.vx, pr.vy);
    if (pr._fade < 1) {
      const baseR = pr.r;
      pr.r = baseR * Math.max(0.15, pr._fade);
      vfx.drawProjectile(ctx, pr, ang, spd, t);
      pr.r = baseR;
    } else {
      vfx.drawProjectile(ctx, pr, ang, spd, t);
    }
    // Subtle crimson warning ring on enemy projectiles so danger stays readable
    if (pr.isEnemy) drawRing(ctx, pr.x, pr.y, pr.r * 1.32, '#ff2a4baa', 1.4);
  }

  // Lite bodies: two batched fills per element (glow + bright core)
  if (lite) {
    for (let e = 0; e < 5; e++) {
      const arr = projBuckets[e];
      if (!arr.length) continue;
      const key = ELEM_KEYS[e];

      ctx.beginPath();
      let any = false;
      for (let i = 0; i < arr.length; i++) {
        const pr = arr[i];
        if (pr.isEnemy && !enemyLite) continue;
        const rr = pr.r * 1.15;
        ctx.moveTo(pr.x + rr, pr.y);
        ctx.arc(pr.x, pr.y, rr, 0, 6.2832);
        any = true;
      }
      if (!any) continue;
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = ELEMENT_VFX[key].mid;
      ctx.fill();

      ctx.beginPath();
      for (let i = 0; i < arr.length; i++) {
        const pr = arr[i];
        if (pr.isEnemy && !enemyLite) continue;
        const rr = pr.r * 0.55;
        ctx.moveTo(pr.x + rr, pr.y);
        ctx.arc(pr.x, pr.y, rr, 0, 6.2832);
      }
      ctx.globalAlpha = 1;
      ctx.fillStyle = LITE_CORE[key];
      ctx.fill();
    }
    if (enemyLite) {
      ctx.beginPath();
      for (let e = 0; e < 5; e++) {
        const arr = projBuckets[e];
        for (let i = 0; i < arr.length; i++) {
          const pr = arr[i];
          if (!pr.isEnemy) continue;
          const rr = pr.r * 1.32;
          ctx.moveTo(pr.x + rr, pr.y);
          ctx.arc(pr.x, pr.y, rr, 0, 6.2832);
        }
      }
      ctx.globalAlpha = 0.67;
      ctx.strokeStyle = '#ff2a4b';
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }
  }
  ctx.restore();
}

function renderSpellImpacts(ctx, inView) {
  const lite = perf.liteProj;
  for (let i = 0; i < IM_MAX; i++) {
    const im = spellImpacts[i];
    if (im.life <= 0) continue;
    if (!inView(im.x, im.y, im.r + 30)) continue;
    const k = im.life / im.maxLife;
    const vfx = ELEMENT_VFX[im.elem] || ELEMENT_VFX.fire;
    if (lite && !im.crit) {
      ctx.globalAlpha = k * 0.85;
      ctx.strokeStyle = vfx.mid;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(im.x, im.y, im.r * (0.65 + (1 - k) * 0.95), 0, 6.2832);
      ctx.stroke();
    } else {
      ctx.save();
      vfx.drawImpact(ctx, im, k);
      ctx.restore();
    }
  }
  ctx.globalAlpha = 1;
}

export function renderProjectiles(ctx, inView) {
  renderSpellParticles(ctx, inView);
  renderProjectileBodies(ctx, inView, state.time);
  renderSpellImpacts(ctx, inView);
}

export function renderArcsAndImpacts(ctx) {
  for (const a of arcs) {
    ctx.globalAlpha = Math.max(0, a.life / 0.22);
    if (a.ring) {
      drawRing(ctx, a.ring.x, a.ring.y, a.ring.r, a.color, 4);
    } else if (a.cone) {
      ctx.fillStyle = a.color;
      ctx.beginPath();
      ctx.moveTo(a.cone.x, a.cone.y);
      ctx.arc(a.cone.x, a.cone.y, a.cone.r, a.cone.ang - a.cone.spread * 0.5, a.cone.ang + a.cone.spread * 0.5);
      ctx.closePath();
      ctx.fill();
    } else if (a.beam) {
      ctx.strokeStyle = a.color;
      ctx.lineWidth = a.beam.w;
      ctx.beginPath();
      ctx.moveTo(a.beam.x, a.beam.y);
      ctx.lineTo(a.beam.ex, a.beam.ey);
      ctx.stroke();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 4;
      ctx.stroke();
    } else if (a.pts) {
      ctx.strokeStyle = a.color;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(a.pts[0].x, a.pts[0].y);
      for (let i = 1; i < a.pts.length; i++) ctx.lineTo(a.pts[i].x, a.pts[i].y);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  for (const im of impacts) {
    const k = im.life / im.maxLife;
    ctx.globalAlpha = k;
    drawRing(ctx, im.x, im.y, im.r * (1.2 - k * 0.4), im.color, im.crit ? 2.6 : 1.4);
    if (im.crit) {
      ctx.strokeStyle = '#ffd700';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(im.x - Math.cos(im.ang) * 16, im.y - Math.sin(im.ang) * 16);
      ctx.lineTo(im.x + Math.cos(im.ang) * 16, im.y + Math.sin(im.ang) * 16);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
}