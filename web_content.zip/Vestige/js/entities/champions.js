import { CFG } from '../core/config.js';
import { poly, drawCircle, drawRing, drawDiamond, SIL } from '../core/utilities.js';
import { state } from '../core/game.js';

import { spawnEnemy } from './enemies.js';
import { drawRuneCircle } from './bosses.js';
import { addTelegraph } from './projectiles.js';
import { orbit } from './renderKit.js';
import { addFeed } from '../ui/notifications.js';

export function spawnElitePack(cnt = 3) {
  const p = state.player;
  const ang = Math.random() * 6.283;
  const bx = Math.max(100, Math.min(CFG.game.W - 100, p.x + Math.cos(ang) * 380));
  const by = Math.max(100, Math.min(CFG.game.H - 100, p.y + Math.sin(ang) * 380));
  for (let i = 0; i < cnt; i++) {
    spawnEnemy('elite', bx + (Math.random() - 0.5) * 90, by + (Math.random() - 0.5) * 90);
  }
  addFeed('An Elite Champion Pack Closes In!', '#ff8c00');
}

export function updateEliteBehavior(e, dt, dx, dy) {
  if ((e.atkCd -= dt) > 0) return;

  const p = state.player;
  e.atkCd = e.role === 'mini' ? 2.5 : 3.6;
  const ba = Math.atan2(dy, dx);

  if (e.mod.id === 'stormbound' || e.mod.id === 'arcane') {
    addTelegraph('beam', e.x, e.y, e.dmg, 0.95, e.mod.color, { ang: ba, len: 320, w: 18 });
  } else if (e.mod.id === 'voidtouched') {
    addTelegraph('shockwave', e.x, e.y, e.dmg, 1.05, e.mod.color, { r: 125 });
  } else if (e.mod.id === 'vampiric') {
    addTelegraph('cone', e.x, e.y, e.dmg, 0.85, e.mod.color, { r: 140, ang: ba, spread: 1.0 });
  } else if (['frozen', 'burning', 'corrupted'].includes(e.mod.id)) {
    addTelegraph('circle', p.x, p.y, e.dmg, 1.0, e.mod.color, { r: 58 });
  }
}

/* ==================== ELITE / CHAMPION VISUALS ==================== */

// Per-modifier effect drawn around the elite. This is the single implementation
// (it used to be duplicated between enemies.js and this file).
const MODIFIER_VFX = {
  frozen: (c, e, t) => {
    drawRing(c, e.x, e.y, e.r * 1.32, '#8cd3ff88', 1.6);
    orbit(6, t, 1.5, e.r * 1.38, e.r * 1.38, (x, y) => drawDiamond(c, e.x + x, e.y + y, 4.6, '#bce6ff'));
  },
  stormbound: (c, e, t) => {
    c.strokeStyle = '#9fd3ff';
    c.lineWidth = 1.9;
    c.beginPath();
    for (let i = 0; i < 4; i++) {
      const a = t * 6.5 + i * 1.57;
      c.moveTo(e.x + Math.cos(a) * e.r * 0.9, e.y + Math.sin(a) * e.r * 0.9);
      c.lineTo(e.x + Math.cos(a + 0.14) * e.r * 1.35, e.y + Math.sin(a + 0.14) * e.r * 1.35);
      c.lineTo(e.x + Math.cos(a + 0.32) * e.r * 1.68, e.y + Math.sin(a + 0.32) * e.r * 1.68);
    }
    c.stroke();
  },
  corrupted: (c, e, t) => {
    for (let i = 0; i < 5; i++) {
      const a = t * 1.8 + i * 1.25;
      const lift = (t * 24 + i * 11) % 16;
      drawCircle(c, e.x + Math.cos(a) * e.r * 0.9, e.y + Math.sin(a) * e.r * 0.65 - lift, 5.5, 'rgba(12, 8, 16, 0.80)', '#4a1c5c', 0.9);
    }
  },
  voidtouched: (c, e, t) => {
    drawRing(c, e.x, e.y, e.r * (1.26 + Math.sin(t * 5) * 0.14), '#b86bff', 2.2);
    orbit(3, t, -2.6, e.r * 1.3, e.r * 1.3, (x, y) => drawCircle(c, e.x + x, e.y + y, 3.8, '#d6a3ff', '#6c2bd9', 1));
  },
  vampiric: (c, e, t) => {
    drawCircle(c, e.x, e.y, e.r * 1.44, 'rgba(224, 60, 79, 0.24)');
    orbit(4, t, -2.4, e.r * 1.22, e.r * 1.22, (x, y) => drawCircle(c, e.x + x, e.y + y, 3.4, '#ff4757'));
  },
  shielded: (c, e) => {
    if (e.shieldHp > 0) drawRing(c, e.x, e.y, e.r * 1.3, '#ffd700', 2.4);
  }
};

/**
 * Rune seal, floating crown and modifier effect for elites, mini-boss wardens and invaders.
 * Called once per elite from enemies.js drawEnemy.
 */
export function drawEliteAura(c, e, t) {
  const col = e.mod ? e.mod.color : e.color;
  const isChamp = e.kind === 'champion' || e.role === 'mini' || e.invader;
  const crownCol = e.invader ? '#ff2a4b' : e.role === 'mini' ? '#ff8c00' : '#f0cf85';

  drawRuneCircle(c, e.x, e.y, e.r * (isChamp ? 1.45 : 1.26), col, t * (isChamp ? 1.8 : 1.1) + e.seed);
  if (isChamp) drawRing(c, e.x, e.y, e.r * 1.16, e.invader ? '#ff2a4b' : '#f0cf85aa', 1.8);

  // Crown hovers and bobs above the head so elites read as "marked" at a glance
  const crownY = e.y - e.r * (isChamp ? 1.55 : 1.4) + Math.sin(t * 3 + e.seed) * 2.5;
  poly(c, e.x, crownY, e.r * (isChamp ? 0.11 : 0.09), SIL.crown, crownCol, '#000', 1.1);

  if (e.mod && MODIFIER_VFX[e.mod.id]) MODIFIER_VFX[e.mod.id](c, e, t);
}
