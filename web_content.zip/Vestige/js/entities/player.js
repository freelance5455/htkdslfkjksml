import { CFG, dailyIndex } from '../core/config.js';
import { poly, drawCircle, drawRing, drawDiamond } from '../core/utilities.js';
import {
  TAU, OUTLINE, idleMotion, groundShadow, orbit, flowCloak, drawPauldron, drawRune, drawSkull,
  drawWisp, drawBowShape, drawKiteShield, drawBlade, drawShardOrbit
} from './renderKit.js';
import { metaSave, hasUnlock } from '../core/save.js';
import { sfx } from '../core/audio.js';
import { getMoveVec } from '../core/input.js';
import {
  state,
  enemyPool,
  projPool,
  arcs,
  hazards,
  impacts,
  addShake,
  spawnParticles,
  openEndingModal
} from '../core/game.js';

import { WEAPONS_DEF } from '../data/classes.js';
import { generateLootItem } from './loot.js';
import { syncSummons } from './summons.js';
import { findTarget, getWeaponRange, RANGE_CFG } from './projectiles.js';

import { applyEquipmentStats } from '../systems/equipment.js';
import { applyEquippedRelics } from '../systems/relics.js';
import { applyMasteryStats } from '../systems/mastery.js';
import { applyTreeStats } from '../systems/skilltree.js';
import { openLevelUp } from '../systems/blessings.js';
import { unlockAchievement } from '../systems/achievements.js';
import { addFeed, showBanner, spawnFloatText } from '../ui/notifications.js';

// ============================================================================
// MELEE SLASH & IMPACT VFX SYSTEM
// ============================================================================

const SLASH_STYLES = {
  greatsword: {
    type: 'greatsword',
    color: '#e8eef7',
    trail: '#ff8c38',
    core: '#ffffff',
    radius: 96,
    arc: 2.35,
    width: 24,
    dur: 0.22,
    shake: 2.4,
    groundShock: false,
    streak: false,
    patterns: ['horizontal', 'diagonal_down', 'diagonal_up', 'heavy_cleave']
  },
  dagger: {
    type: 'dagger',
    color: '#d8b8ff',
    trail: '#c56cf0',
    core: '#ffffff',
    radius: 62,
    arc: 1.38,
    width: 11,
    dur: 0.14,
    shake: 0.8,
    groundShock: false,
    streak: true,
    patterns: ['diagonal_down', 'diagonal_up', 'horizontal', 'diagonal_down']
  },
  hammer: {
    type: 'hammer',
    color: '#ffc078',
    trail: '#ff6b3d',
    core: '#fff4d4',
    radius: 86,
    arc: 1.95,
    width: 26,
    dur: 0.25,
    shake: 4.2,
    groundShock: true,
    streak: false,
    patterns: ['vertical', 'heavy_cleave', 'horizontal']
  },
  paladin: {
    type: 'paladin',
    color: '#ffd700',
    trail: '#ff9f1a',
    core: '#fffbe0',
    radius: 94,
    arc: 2.25,
    width: 21,
    dur: 0.23,
    shake: 2.8,
    groundShock: true,
    streak: false,
    patterns: ['horizontal', 'vertical', 'diagonal_down', 'heavy_cleave']
  }
};

const slashEffects = [];
const groundImpacts = [];
const impactSparks = [];

function resetMeleeVfx() {
  slashEffects.length = 0;
  groundImpacts.length = 0;
  impactSparks.length = 0;
}

function classifyMeleeWeapon(wKey, clsId) {
  const k = (wKey || '').toLowerCase();
  if (/dagger|knife|claw|shadow/.test(k)) return 'dagger';
  if (/sunhammer|holy|paladin|aegis/.test(k)) return 'paladin';
  if (/hammer|mace|maul|flail|crusher/.test(k)) return 'hammer';
  if (/greatsword|sword|blade|axe|scythe|cleaver|spear|halberd/.test(k)) return 'greatsword';
  if (!wKey) {
    if (clsId === 'warrior') return 'greatsword';
    if (clsId === 'assassin') return 'dagger';
    if (clsId === 'paladin') return 'paladin';
  }
  return null;
}

function findAttackAngle(p, wKey) {
  let bestAng = Math.atan2(p.facingY, p.facingX);

  // Face the closest enemy inside this weapon's range (recently-hit enemies preferred)
  const target = findTarget(p.x, p.y, getWeaponRange(wKey, p.cls.id), { hitBias: 0.45 });
  if (target) bestAng = Math.atan2(target.y - p.y, target.x - p.x);

  // Fallback check on freshly launched melee projectile matching weaponKey
  if (wKey) {
    for (let i = projPool.active.length - 1; i >= 0; i--) {
      const pr = projPool.active[i];
      if (!pr.isEnemy && pr.weaponKey === wKey) {
        bestAng = Math.atan2(pr.vy, pr.vx);
        break;
      }
    }
  }
  return bestAng;
}

export function spawnGroundImpact(x, y, radius, color, isHoly = false, isCrit = false) {
  if (groundImpacts.length >= 18) groundImpacts.shift();
  const cracks = [];
  const count = isCrit ? 7 : 5;
  for (let i = 0; i < count; i++) {
    const a = (i / count) * TAU + (Math.random() - 0.5) * 0.45;
    cracks.push({
      a,
      len: radius * (0.45 + Math.random() * 0.48),
      bend: (Math.random() - 0.5) * 0.45
    });
  }
  groundImpacts.push({
    x,
    y,
    r: radius,
    color,
    isHoly,
    isCrit,
    cracks,
    life: isCrit ? 0.42 : 0.34,
    maxLife: isCrit ? 0.42 : 0.34
  });
}

export function spawnHitSparkBurst(x, y, ang, color, isCrit = false) {
  if (impactSparks.length >= 36) impactSparks.shift();
  impactSparks.push({
    x,
    y,
    ang,
    color: isCrit ? '#ffd700' : color,
    isCrit,
    life: isCrit ? 0.22 : 0.14,
    maxLife: isCrit ? 0.22 : 0.14
  });
  spawnParticles(x, y, isCrit ? '#ffd700' : color, isCrit ? 9 : 4, isCrit ? 220 : 150);
}

export function spawnSlashEffect(x, y, ang, styleKey = 'greatsword', opt = {}) {
  const style = SLASH_STYLES[styleKey] || SLASH_STYLES.greatsword;
  const isCrit = !!opt.crit;
  const evolved = !!opt.evolved;
  const pattern = opt.pattern || 'horizontal';
  const flip = opt.flip ? -1 : 1;
  const areaMult = opt.areaMult || 1;

  const isHeavy = pattern === 'heavy_cleave';
  const scale = (isCrit ? 1.32 : 1) * (evolved ? 1.14 : 1) * (isHeavy ? 1.18 : 1) * Math.min(1.45, 0.85 + areaMult * 0.15);
  const r = style.radius * scale;
  const arc = isHeavy ? Math.max(style.arc, 3.05) : style.arc;
  const dur = style.dur * (isHeavy ? 1.15 : 1);

  if (slashEffects.length >= 26) slashEffects.shift();
  slashEffects.push({
    x,
    y,
    ang,
    styleKey,
    color: isCrit ? '#fff4b8' : style.color,
    trail: isCrit ? '#ffd700' : style.trail,
    core: style.core,
    r,
    arc,
    width: style.width * (isCrit ? 1.25 : 1) * (isHeavy ? 1.2 : 1),
    pattern,
    flip,
    streak: style.streak,
    isCrit,
    isHeavy,
    life: dur,
    maxLife: dur
  });

  // Dagger twin cross-slash accent on crit or evolved
  if (styleKey === 'dagger' && (isCrit || evolved)) {
    slashEffects.push({
      x,
      y,
      ang: ang + (Math.random() - 0.5) * 0.25,
      styleKey,
      color: '#f2e0ff',
      trail: '#ff70e0',
      core: '#ffffff',
      r: r * 0.92,
      arc: arc * 0.9,
      width: style.width * 0.95,
      pattern: pattern === 'diagonal_down' ? 'diagonal_up' : 'diagonal_down',
      flip: -flip,
      streak: true,
      isCrit,
      isHeavy: false,
      life: dur * 1.1,
      maxLife: dur * 1.1
    });
  }

  // Impact point ahead of player along attack vector
  const ix = x + Math.cos(ang) * (r * 0.62);
  const iy = y + Math.sin(ang) * (r * 0.62);

  if (style.groundShock || isHeavy || isCrit) {
    const shockR = r * (style.groundShock ? 0.72 : 0.52);
    spawnGroundImpact(ix, iy, shockR, isCrit ? '#ffd700' : style.trail, styleKey === 'paladin', isCrit);
  }

  if (style.shake > 0) addShake(style.shake * (isCrit ? 1.35 : 1));
  spawnParticles(ix, iy, isCrit ? '#ffd700' : style.trail, isCrit ? 8 : 4, isCrit ? 190 : 135);
}

function drawCrescentArc(ctx, r, thickness, startAng, endAng) {
  const span = endAng - startAng;
  if (Math.abs(span) < 0.03) return;
  const steps = 14;

  ctx.beginPath();
  for (let i = 0; i <= steps; i++) {
    const f = i / steps;
    const a = startAng + span * f;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  for (let i = steps; i >= 0; i--) {
    const f = i / steps;
    const a = startAng + span * f;
    const taper = Math.sin(Math.pow(f, 0.72) * Math.PI);
    const ir = Math.max(4, r - thickness * taper);
    ctx.lineTo(Math.cos(a) * ir, Math.sin(a) * ir);
  }
  ctx.closePath();
  ctx.fill();
}

function drawSingleSlash(ctx, s) {
  const prog = 1 - s.life / s.maxLife;
  const fade = Math.max(0, 1 - Math.pow(prog, 1.55));
  const headP = 1 - Math.pow(1 - Math.min(1, prog * 1.6), 3);
  const tailP = Math.pow(Math.max(0, (prog - 0.1) / 0.9), 1.45);

  const halfArc = s.arc * 0.5;
  const aStart = -halfArc * s.flip;
  const aEnd = halfArc * s.flip;
  const curHead = aStart + (aEnd - aStart) * headP;
  const curTail = aStart + (aEnd - aStart) * tailP;

  ctx.save();
  ctx.translate(s.x, s.y);
  ctx.rotate(s.ang);

  // Pattern-specific 2.5D perspective transform
  if (s.pattern === 'vertical') {
    ctx.scale(1.14, 0.42);
  } else if (s.pattern === 'diagonal_down') {
    ctx.rotate(-0.36);
    ctx.scale(1.06, 0.72);
  } else if (s.pattern === 'diagonal_up') {
    ctx.rotate(0.36);
    ctx.scale(1.06, 0.72);
  } else if (s.pattern === 'heavy_cleave') {
    ctx.scale(1.05, 0.88);
  } else {
    ctx.scale(1.0, 0.82);
  }

  // 1) Fast fading outer motion trail
  ctx.globalAlpha = fade * 0.42;
  ctx.fillStyle = s.trail;
  drawCrescentArc(ctx, s.r * 1.04, s.width * 1.45, aStart, curHead);

  // 2) Main bright slash arc
  ctx.globalAlpha = fade * 0.92;
  ctx.fillStyle = s.color;
  drawCrescentArc(ctx, s.r, s.width, curTail, curHead);

  // 3) Razor white-hot leading edge
  ctx.globalAlpha = fade;
  ctx.fillStyle = s.core;
  drawCrescentArc(ctx, s.r * 1.01, Math.max(3, s.width * 0.34), curTail + (curHead - curTail) * 0.25, curHead);

  // 4) Dagger narrow piercing streak
  if (s.streak) {
    ctx.globalAlpha = fade * 0.95;
    ctx.fillStyle = s.core;
    ctx.beginPath();
    ctx.moveTo(10, 0);
    ctx.lineTo(s.r * (0.85 + headP * 0.38), -3.5 * fade);
    ctx.lineTo(s.r * (1.05 + headP * 0.42), 0);
    ctx.lineTo(s.r * (0.85 + headP * 0.38), 3.5 * fade);
    ctx.closePath();
    ctx.fill();
  }

  // 5) Directional impact line along swing tip & forward strike axis
  const tipX = Math.cos(curHead) * s.r;
  const tipY = Math.sin(curHead) * s.r;
  ctx.globalAlpha = fade * 0.88;
  ctx.strokeStyle = s.core;
  ctx.lineWidth = s.isCrit ? 2.8 : 1.8;
  ctx.beginPath();
  ctx.moveTo(tipX - Math.sin(curHead) * 16 * s.flip, tipY + Math.cos(curHead) * 16 * s.flip);
  ctx.lineTo(tipX + Math.sin(curHead) * 20 * s.flip, tipY - Math.cos(curHead) * 20 * s.flip);
  ctx.stroke();

  if (s.isCrit || s.isHeavy) {
    ctx.globalAlpha = fade * 0.65;
    ctx.strokeStyle = s.trail;
    ctx.lineWidth = s.isCrit ? 3.2 : 2.2;
    ctx.beginPath();
    ctx.moveTo(s.r * 0.25, 0);
    ctx.lineTo(s.r * 1.24, 0);
    ctx.stroke();
  }

  ctx.restore();
}

export function renderSlashEffects(ctx) {
  // Ground impacts beneath player & slashes
  for (let i = 0; i < groundImpacts.length; i++) {
    const g = groundImpacts[i];
    const k = g.life / g.maxLife;
    const exp = 0.45 + (1 - k) * 0.72;
    ctx.save();
    ctx.globalAlpha = k * 0.78;
    drawRing(ctx, g.x, g.y, g.r * exp, g.color, g.isCrit ? 3.6 : 2.5);
    if (g.isHoly) {
      drawRing(ctx, g.x, g.y, g.r * exp * 0.68, '#fff7c2', 1.8);
    }
    ctx.strokeStyle = g.isHoly ? '#ffd700' : '#1b1412';
    ctx.lineWidth = g.isCrit ? 2.4 : 1.8;
    ctx.beginPath();
    for (let j = 0; j < g.cracks.length; j++) {
      const ck = g.cracks[j];
      const l = ck.len * (0.55 + (1 - k) * 0.45);
      ctx.moveTo(g.x, g.y);
      ctx.lineTo(g.x + Math.cos(ck.a + ck.bend) * l * 0.5, g.y + Math.sin(ck.a + ck.bend) * l * 0.5);
      ctx.lineTo(g.x + Math.cos(ck.a) * l, g.y + Math.sin(ck.a) * l);
    }
    ctx.stroke();
    ctx.restore();
  }

  // Main directional melee slashes
  for (let i = 0; i < slashEffects.length; i++) {
    drawSingleSlash(ctx, slashEffects[i]);
  }

  // Hit spark cross-flashes
  for (let i = 0; i < impactSparks.length; i++) {
    const sp = impactSparks[i];
    const k = sp.life / sp.maxLife;
    const len = (sp.isCrit ? 26 : 16) * (1.2 - k * 0.4);
    ctx.save();
    ctx.translate(sp.x, sp.y);
    ctx.rotate(sp.ang);
    ctx.globalAlpha = k;
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = sp.isCrit ? 2.6 : 1.8;
    ctx.beginPath();
    ctx.moveTo(-len, 0);
    ctx.lineTo(len, 0);
    ctx.moveTo(0, -len * 0.55);
    ctx.lineTo(0, len * 0.55);
    ctx.stroke();
    drawCircle(ctx, 0, 0, sp.isCrit ? 7 * k : 4.5 * k, sp.color);
    ctx.restore();
  }
}

function updateMeleeVfx(p, dt) {
  if (!p._meleeVfx) {
    p._meleeVfx = {
      prevCd: {},
      swingIdx: 0,
      activeSwing: null,
      seenImpacts: new WeakSet(),
      seenArcs: new WeakSet(),
      enemyFlashSeen: new WeakMap()
    };
  }
  const mvx = p._meleeVfx;

  // Tick active slash / ground / spark pools
  for (let i = slashEffects.length - 1; i >= 0; i--) {
    if ((slashEffects[i].life -= dt) <= 0) slashEffects.splice(i, 1);
  }
  for (let i = groundImpacts.length - 1; i >= 0; i--) {
    if ((groundImpacts[i].life -= dt) <= 0) groundImpacts.splice(i, 1);
  }
  for (let i = impactSparks.length - 1; i >= 0; i--) {
    if ((impactSparks[i].life -= dt) <= 0) impactSparks.splice(i, 1);
  }
  if (mvx.activeSwing) {
    mvx.activeSwing.timer -= dt;
    if (mvx.activeSwing.timer <= 0) mvx.activeSwing = null;
  }

  // Inspect recent combat impacts for crits & hit sparks near player
  let recentCritNearPlayer = false;
  for (let i = impacts.length - 1; i >= 0; i--) {
    const im = impacts[i];
    if (mvx.seenImpacts.has(im)) continue;
    mvx.seenImpacts.add(im);
    const d2 = (im.x - p.x) ** 2 + (im.y - p.y) ** 2;
    if (im.crit && d2 < 240 * 240) recentCritNearPlayer = true;
    if (d2 < 220 * 220) {
      const ang = Math.atan2(im.y - p.y, im.x - p.x);
      spawnHitSparkBurst(im.x, im.y, ang, im.color, im.crit);
      if (im.crit) {
        const clsStyle = classifyMeleeWeapon(p.cls.weapon, p.cls.id);
        if (clsStyle) {
          spawnSlashEffect(p.x, p.y, ang, clsStyle, {
            pattern: 'heavy_cleave',
            crit: true,
            areaMult: p.stats.areaPct || 1
          });
        }
      }
    }
  }

  // Detect melee weapon attacks when weapon cooldown resets upward
  for (const [wKey, w] of Object.entries(p.weapons)) {
    const prev = mvx.prevCd[wKey] ?? w.cd;
    if (w.cd > prev + 0.04) {
      const styleKey = classifyMeleeWeapon(wKey, p.cls.id);
      if (styleKey) {
        const style = SLASH_STYLES[styleKey];
        const ang = findAttackAngle(p, wKey);
        const pat = style.patterns[mvx.swingIdx % style.patterns.length];
        const flip = (mvx.swingIdx % 2) === 1;
        mvx.swingIdx++;

        spawnSlashEffect(p.x, p.y, ang, styleKey, {
          pattern: pat,
          flip,
          evolved: w.evolved,
          crit: recentCritNearPlayer,
          areaMult: p.stats.areaPct || 1
        });

        mvx.activeSwing = {
          dir: flip ? -1 : 1,
          timer: style.dur,
          maxTimer: style.dur,
          styleKey,
          ang
        };
      }
    }
    mvx.prevCd[wKey] = w.cd;
  }

  // Detect melee skill shockwave/cone arcs centered on player
  for (let i = arcs.length - 1; i >= 0; i--) {
    const a = arcs[i];
    if (mvx.seenArcs.has(a)) continue;
    mvx.seenArcs.add(a);
    if (a.cone && (a.cone.x - p.x) ** 2 + (a.cone.y - p.y) ** 2 < 900) {
      const styleKey = classifyMeleeWeapon(p.cls.weapon, p.cls.id) || 'greatsword';
      spawnSlashEffect(p.x, p.y, a.cone.ang, styleKey, {
        pattern: 'heavy_cleave',
        crit: recentCritNearPlayer,
        areaMult: p.stats.areaPct || 1
      });
    }
  }

  // Add melee impact sparks on close enemies that just took damage
  for (let i = 0; i < enemyPool.active.length; i++) {
    const e = enemyPool.active[i];
    if (!e.alive || e.hitFlash <= 0.055) continue;
    const prevFlash = mvx.enemyFlashSeen.get(e) || 0;
    if (e.hitFlash > prevFlash + 0.02) {
      const dx = e.x - p.x;
      const dy = e.y - p.y;
      if (dx * dx + dy * dy < 165 * 165) {
        const styleKey = classifyMeleeWeapon(p.cls.weapon, p.cls.id);
        if (styleKey) {
          spawnHitSparkBurst(e.x, e.y, Math.atan2(dy, dx), SLASH_STYLES[styleKey].trail, false);
        }
      }
    }
    mvx.enemyFlashSeen.set(e, e.hitFlash);
  }
}

// ============================================================================
// PLAYER CREATION, STATS, MOVEMENT & COMBAT
// ============================================================================

export function createPlayer(cls) {
  resetMeleeVfx();
  const r = metaSave.metaRanks;
  const mHp = (r.m_hp || 0) * 15;
  const p = {
    cls,
    x: CFG.game.W / 2,
    y: CFG.game.H / 2,
    r: 15,
    hp: cls.hp + mHp,
    maxHp: cls.hp + mHp,
    level: 1,
    xp: 0,
    xpToNext: 18,
    dashCd: 0,
    dashTimer: 0,
    dashVx: 0,
    dashVy: 0,
    invuln: 0,
    moving: false,
    facingX: 1,
    facingY: 0,
    phoenixUsed: false,
    flamesGathered: 0,
    bossesDefeated: [],
    treePoints: 1 + (r.m_tree || 0) + (hasUnlock('tree_start') ? 2 : 0),
    allocatedNodes: new Set([0]),
    catalysts: new Set(),
    weapons: { [cls.weapon]: { level: 1, cd: 0, evolved: false } },
    equipped: { weapon: null, helmet: null, chest: null, ring1: null, ring2: null, amulet: null },
    bag: [],
    gemsCount: 0,
    quests: { pilgrim: 'Undiscovered', seer: 'Undiscovered' },
    bonus: {
      flatDmg: 0,
      dmgPct: (r.m_dmg || 0) * 0.06,
      atkSpeed: 0,
      areaPct: 0,
      projBonus: 0,
      moveSpeed: 0,
      critChance: 0,
      critDmg: 0,
      cdr: 0,
      lifeSteal: 0,
      armor: (r.m_armor || 0) * 3,
      regen: 0,
      xpGain: (r.m_xp || 0) * 0.10,
      pickupRadius: (r.m_magnet || 0) * 0.12,
      dashCdr: 0,
      maxHp: mHp,
      summonDmg: 0,
      range: 0 // additive: 0.10 = +10% weapon, summon and projectile range
    },
    stats: {}
  };

  p.equipped.weapon = Object.assign(
    generateLootItem(1, 'common'),
    { slot: 'weapon', name: `Starter ${WEAPONS_DEF[cls.weapon].name}` }
  );
  return p;
}

export function recalcStats() {
  const p = state.player;
  if (!p) return;

  const c = p.cls;
  const b = p.bonus;
  const s = {
    flatDmg: 15 + b.flatDmg,
    dmgPct: c.dmg + b.dmgPct,
    atkSpeed: 1 + b.atkSpeed + (c.id === 'ranger' ? 0.18 : 0),
    areaPct: 1 + b.areaPct + (c.id === 'mage' ? 0.25 : 0),
    projBonus: b.projBonus + (state.gameMode === 'daily' && dailyIndex === 1 ? 2 : 0),
    moveSpeedMult: 1 + b.moveSpeed,
    critChance: c.crit + b.critChance + (state.gameMode === 'daily' && dailyIndex === 0 ? 0.5 : 0),
    critDmg: CFG.combat.CRIT_MULT + b.critDmg + (c.id === 'assassin' ? 0.45 : 0),
    cdr: (c.id === 'mage' ? 0.12 : 0) + b.cdr,
    lifeSteal: b.lifeSteal + (state.gameMode === 'daily' && dailyIndex === 2 ? 0.45 : 0),
    armor: c.armor + b.armor,
    regen: (c.id === 'paladin' ? 3 : 0.5) + b.regen,
    xpGain: 1 + b.xpGain,
    pickupBonus: (p.level - 1) * CFG.combat.MAGNET_LVL + b.pickupRadius,
    dashCdr: b.dashCdr,
    dashMaxCd: CFG.combat.BASE_DASH_CD * (c.id === 'assassin' ? 0.75 : 1),
    maxHpBase: c.hp + b.maxHp,
    maxHpMult: 1,
    summonDmg: 1 + b.summonDmg + (c.id === 'necromancer' ? 0.35 : 0),
    range: 1 + (b.range || 0), // range multiplier; blessings/relics/items/tree do `s.range += 0.1`
    dmgTakenMult: 1,
    relicLuck: 0,
    relicReward: 0,
    enemySpdAdd: 0,
    enemyHpAdd: 0,
    noRegen: 0,
    uniques: new Set(),
    keystones: new Set(),
    sets: {}
  };

  applyTreeStats(p, s);
  applyEquipmentStats(p, s);
  applyEquippedRelics(s);
  applyMasteryStats(s);

  if (hasUnlock('tree_keystone')) s.dmgPct += s.keystones.size * 0.12;

  if ((s.sets.ashenking || 0) >= 2) s.dmgPct += 0.15;
  if ((s.sets.ashenking || 0) >= 4) { s.dmgPct += 0.25; s.areaPct += 0.15; }
  if ((s.sets.choir || 0) >= 2) s.cdr += 0.15;
  if ((s.sets.choir || 0) >= 4) { s.critDmg += 0.35; s.projBonus += 1; }
  if (s.uniques.has('bloodcrown')) s.lifeSteal += 0.20;
  if (s.uniques.has('voidprism')) s.dmgPct += 0.35;
  if (s.uniques.has('pilgrimring')) { s.moveSpeedMult += 0.25; s.pickupBonus += 0.35; }
  if (s.uniques.has('lodestone')) { s.pickupBonus += 0.50; s.xpGain += 0.20; }

  if (s.keystones.has('Divine Resolve') || s.titanResolve) {
    s.flatDmg += Math.round(Math.max(0, s.armor) * (s.armorToDmg || 1.2));
  }
  if (s.keystones.has('Echoes of Eternity')) { s.projBonus += 2; s.atkSpeed += 0.35; s.dmgPct -= 0.20; }
  if (s.keystones.has('Forbidden Knowledge')) {
    const cv = Math.round(s.armor * 0.5);
    s.armor -= cv;
    s.areaPct += cv * 0.025;
    s.dmgPct += cv * 0.025;
  }
  if (s.keystones.has('Avatar of the Hollow')) { s.summonDmg += 0.80; s.dmgPct -= 0.30; }
  if (s.keystones.has('Glass Apotheosis')) { s.dmgPct += 0.85; s.critChance += 0.25; s.maxHpMult -= 0.45; }
  if (s.noRegen || (state.gameMode === 'daily' && dailyIndex === 2)) s.regen = 0;

  s.cdr = Math.min(CFG.combat.MAX_CDR, s.cdr);
  s.range = Math.min(RANGE_CFG.maxMult, Math.max(RANGE_CFG.minMult, s.range));
  s.critChance = Math.min(CFG.combat.MAX_CRIT, s.critChance);
  s.moveSpeed = c.speed * Math.max(0.4, s.moveSpeedMult);
  s.pickupRadius = CFG.combat.BASE_PICKUP * Math.max(0.5, 1 + s.pickupBonus);
  s.dashMaxCd = Math.max(0.5, s.dashMaxCd * (1 - Math.min(0.6, s.dashCdr)));

  const prev = p.maxHp;
  p.maxHp = Math.max(35, Math.round(s.maxHpBase * Math.max(0.25, s.maxHpMult)));
  if (p.maxHp > prev) p.hp += (p.maxHp - prev);
  p.hp = Math.min(p.hp, p.maxHp);
  p.stats = s;

  syncSummons(p, s);

  for (const [k, w] of Object.entries(p.weapons)) {
    const def = WEAPONS_DEF[k];
    if (!w.evolved && w.level >= 3 && p.catalysts.has(def.catalyst)) {
      w.evolved = true;
      sfx.play('legendary');
      addFeed(`WEAPON EVOLVED: ${def.name} → ${def.evolved}!`, '#ff8c00');
      showBanner('WEAPON EVOLVED', `${def.name} → ${def.evolved}`, '#ff8c00', 2.8);
      unlockAchievement(`Evolved ${def.evolved}`);
    }
  }
}

export function triggerDash() {
  const p = state.player;
  if (!p || state.mode !== 'playing' || p.dashCd > 0) return;
  const [mx, my, moved] = getMoveVec();
  const dx = moved ? mx : p.facingX;
  const dy = moved ? my : p.facingY;

  p.dashTimer = 0.16;
  p.invuln = Math.max(p.invuln, 0.25);
  p.dashVx = dx * 740;
  p.dashVy = dy * 740;
  p.dashCd = p.stats.dashMaxCd;

  sfx.play('dash');
  spawnParticles(p.x, p.y, '#6fa8dc', 10, 150);
}

export function updatePlayerMovement(dt, moveVec) {
  const p = state.player;
  const [mx, my, moved] = moveVec;

  if (p.hp < p.maxHp) p.hp = Math.min(p.maxHp, p.hp + p.stats.regen * dt);
  if (p.dashCd > 0) p.dashCd = Math.max(0, p.dashCd - dt);
  if (p.invuln > 0) p.invuln = Math.max(0, p.invuln - dt);

  p.moving = moved || p.dashTimer > 0;

  if (p.dashTimer > 0) {
    p.dashTimer -= dt;
    p.x += p.dashVx * dt;
    p.y += p.dashVy * dt;
    spawnParticles(p.x, p.y, '#6fa8dc', 1, 35);
  } else if (moved) {
    p.facingX = mx;
    p.facingY = my;
    p.x += mx * p.stats.moveSpeed * dt;
    p.y += my * p.stats.moveSpeed * dt;
  }

  p.x = Math.max(p.r, Math.min(CFG.game.W - p.r, p.x));
  p.y = Math.max(p.r, Math.min(CFG.game.H - p.r, p.y));
  state.camera.x += (p.x - state.camera.x) * Math.min(1, dt * 10);
  state.camera.y += (p.y - state.camera.y) * Math.min(1, dt * 10);

  updateMeleeVfx(p, dt);
}

export function damagePlayer(rawDmg) {
  const p = state.player;
  if (p.invuln > 0) return;

  const dmg = Math.max(
    1,
    Math.round(rawDmg * (p.stats.dmgTakenMult || 1) * (100 / (100 + Math.max(0, p.stats.armor) * 2.1)))
  );
  p.hp -= dmg;
  p.invuln = CFG.combat.HIT_INVULN;
  state.director.fTaken += dmg;
  if ('dmgFlash' in state) state.dmgFlash = 1.0;
  addShake(8);
  spawnFloatText(p.x, p.y, `-${dmg}`, '#e03c4f', 15);
  spawnParticles(p.x, p.y, '#e03c4f', 8, 120);

  if (p.hp <= 0) {
    if (p.stats.uniques.has('phoenixheart') && !p.phoenixUsed) {
      p.phoenixUsed = true;
      p.hp = Math.round(p.maxHp * 0.65);
      p.invuln = 2.4;
      sfx.play('legendary');
      addShake(11);
      addFeed('PHOENIX HEART: Reborn in Solar Flame!', '#ff8c00');
      hazards.push({
        x: p.x,
        y: p.y,
        r: 260,
        dmg: p.stats.flatDmg * p.stats.dmgPct * 4,
        life: 0.35,
        maxLife: 0.35,
        color: '#ff8c38',
        isEnemy: false
      });
    } else {
      p.hp = 0;
      openEndingModal(false);
    }
  }
}

export function gainXp(amt) {
  const p = state.player;
  p.xp += amt;
  if (p.xp >= p.xpToNext) {
    p.xp -= p.xpToNext;
    p.level++;
    p.treePoints++;
    p.xpToNext = Math.round(p.xpToNext * 1.26 + 12);
    recalcStats();
    openLevelUp();
  }
}

/* ==================== LAYERED PROCEDURAL PLAYER RENDERING ==================== */

const PLAYER_SCALE = 1.4;

const CLASS_STYLES = {
  warrior:     { torso: '#5e2328', trim: '#b89652', cloak: '#8b1e28', helm: '#757d8a', eyes: '#ffd280', heavy: true,  robes: false, hood: false, shoulder: 1.5,  spikes: '#c8d0da', crest: '#c0303c' },
  mage:        { torso: '#4a1d19', trim: '#ff9c47', cloak: '#802318', helm: '#2d1a24', eyes: '#ffae42', heavy: false, robes: true,  hood: true,  shoulder: 0.95, robeLen: 24 },
  necromancer: { torso: '#1c2624', trim: '#5effb1', cloak: '#131c1a', helm: '#cfc7b8', eyes: '#5effb1', heavy: false, robes: true,  hood: true,  shoulder: 0.9,  robeLen: 24 },
  ranger:      { torso: '#213b2c', trim: '#98724b', cloak: '#1b472f', helm: '#1d4a31', eyes: '#9ef7bd', heavy: false, robes: false, hood: true,  shoulder: 1.0 },
  assassin:    { torso: '#241a30', trim: '#c56cf0', cloak: '#1b1126', helm: '#181022', eyes: '#e08aff', heavy: false, robes: false, hood: true,  shoulder: 0.85 },
  paladin:     { torso: '#b09142', trim: '#fff1b8', cloak: '#a82232', helm: '#d9c27e', eyes: '#fff6cc', heavy: true,  robes: false, hood: false, shoulder: 1.3,  spikes: '#ffd700', crest: '#fff1b8' }
};

function drawCloakPart(ctx, st, dir, mv, t) {
  const drift = mv.dashing ? 16 : mv.moving ? 6 : 1;
  const speed = mv.dashing ? 11 : mv.moving ? 7 : 2.6;
  flowCloak(ctx, { dir, fill: st.cloak, t, top: -7, width: 8 + st.shoulder * 2.5, len: st.robes ? 27 : 23, drift, speed });
  if (st.robes) {
    const w = 11;
    const a = Math.sin(t * speed) * 1.6;
    const b = Math.sin(t * speed * 1.3 + 1) * 2;
    poly(ctx, 0, 0, 1, [-w * 0.5, 2, w * 0.5, 2, w * 0.9 + a, st.robeLen, 0, st.robeLen + 3 + b, -w * 0.9 - a, st.robeLen], st.torso, st.trim, 1.1);
  }
}

function drawLegsPart(ctx, st, stride) {
  if (st.robes) return;
  const spread = st.heavy ? 5 : 4;
  const leg = (sx, swing) => {
    ctx.fillStyle = '#25212c';
    ctx.strokeStyle = OUTLINE;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(sx - 2.8, 6 + swing * 0.3, 5.6, 9 + swing * 0.4, 2) : ctx.rect(sx - 2.8, 6, 5.6, 9);
    ctx.fill();
    ctx.stroke();
  };
  leg(-spread, stride * 3.5);
  leg(spread, -stride * 3.5);
}

function drawTorsoPart(ctx, st, m) {
  const w = (st.heavy ? 9.5 : 7.5) * st.shoulder;
  ctx.save();
  ctx.scale(1 + m.breath * 0.03, 1 - m.breath * 0.02);
  poly(ctx, 0, 0, 1, [-w, -7, w, -7, w * 0.75, 7, -w * 0.75, 7], st.torso, OUTLINE, 1.4);
  ctx.fillStyle = st.trim;
  ctx.fillRect(-w * 0.72, 3, w * 1.44, 2.2);
  ctx.restore();
  return w;
}

function drawArmsPart(ctx, st, w, stride, dir) {
  [-1, 1].forEach(side => {
    const swing = -side * stride;
    const ax = side * (w + 1.5);
    if (st.heavy) drawPauldron(ctx, ax, -6, 4.2 + st.shoulder * 1.4, st.helm, OUTLINE, st.spikes, side);
    else drawCircle(ctx, ax, -5, 3.4, st.torso, OUTLINE, 1);
    drawCircle(ctx, ax + dir * 1.2, -1 + swing * 2.4, 2.6, st.torso, OUTLINE, 1);
  });
}

function drawHeadPart(ctx, st, dir, fy, m, t) {
  ctx.save();
  ctx.translate(dir * m.head * 0.8, -Math.abs(m.head) * 0.6);
  ctx.rotate(m.head * 0.05);
  if (st.hood) {
    poly(ctx, 0, -11, 1, [0, -11, 7.5, -2, 5.5, 5.5, -5.5, 5.5, -7.5, -2], st.helm, OUTLINE, 1.3);
    drawCircle(ctx, 0, -10.5, 4.4, '#131018');
  } else {
    drawCircle(ctx, 0, -11.5, 5.8, st.helm, OUTLINE, 1.4);
    ctx.fillStyle = st.trim;
    ctx.fillRect(-4.4, -14, 8.8, 1.9);
  }
  if (st.crest) {
    const f = Math.sin(t * 5) * 2;
    poly(ctx, 0, 0, 1, [0, -17, -dir * (6 + f), -23, -dir * (14 + f * 1.5), -17, -dir * 5, -14], st.crest, OUTLINE, 1);
  }
  ctx.fillStyle = st.eyes;
  const ex = dir * 1.8;
  const ey = -11 + fy * 1.2;
  ctx.fillRect(ex - 2.3, ey, 1.9, 1.9);
  ctx.fillRect(ex + 0.8, ey, 1.9, 1.9);
  ctx.restore();
}

const CLASS_GEAR = {
  warrior: (ctx, dir, m, t, mv, swingAmt) => {
    ctx.save();
    ctx.translate(dir * 12, 2);
    ctx.rotate(dir * (0.55 + m.sway * 0.12) + swingAmt * 1.65);
    drawBlade(ctx, 50, 6, '#dce2eb', '#2a2633', '#c9a050');
    ctx.restore();
  },

  mage: (ctx, dir, m, t) => {
    orbit(4, t, 1.8, 25, 8, (x, y, i) => drawRune(ctx, x, y - 10 + Math.sin(t * 3 + i * 1.7) * 2.5, 4.6, '#ff9c47', t * 1.4 + i * 1.57));
    ctx.save();
    ctx.translate(dir * 11, 4);
    ctx.rotate(dir * (0.2 + m.sway * 0.08));
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#6b4226';
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.moveTo(0, 12);
    ctx.lineTo(0, -36);
    ctx.stroke();
    ctx.strokeStyle = '#c9a050';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, -40, 8.5, Math.PI * 0.05, Math.PI * 0.95);
    ctx.stroke();
    const pulse = 1 + Math.sin(t * 4) * 0.12;
    drawCircle(ctx, 0, -42, 14 * pulse, 'rgba(255,140,56,.22)');
    drawCircle(ctx, 0, -42, 6.5 * pulse, '#ff8c38', '#ffe3a3', 1.4);
    ctx.restore();
  },

  necromancer: (ctx, dir, m, t) => {
    drawRing(ctx, 0, 14, 20 + Math.sin(t * 4) * 1.5, '#5effb166', 1.4);
    drawShardOrbit(ctx, 3, t, -2.0, 28, 11, 4.2, ['#d8d2c5', '#5effb1', '#d8d2c5'], -4);
    orbit(2, t, 1.4, 23, 9, (x, y, i) => drawSkull(ctx, x, y - 14 + Math.sin(t * 2.5 + i * 3) * 2, 4.6));
    orbit(3, t, 2.3, 33, 14, (x, y, i, a) => drawWisp(ctx, x, y - 6, 3.2, '#5effb1', a - Math.PI / 2), 1);
    ctx.save();
    ctx.translate(dir * 11, 3);
    ctx.rotate(dir * (0.2 + m.sway * 0.1));
    ctx.strokeStyle = '#3d4f48';
    ctx.lineWidth = 2.8;
    ctx.beginPath();
    ctx.moveTo(0, 11);
    ctx.lineTo(0, -30);
    ctx.stroke();
    drawSkull(ctx, 0, -35, 5.2);
    ctx.restore();
  },

  ranger: (ctx, dir, m) => {
    ctx.save();
    ctx.translate(-dir * 8, -4);
    ctx.rotate(-dir * 0.35);
    ctx.fillStyle = '#5b3d24';
    ctx.fillRect(-3, -8, 6, 16);
    ctx.strokeStyle = '#e8e2d0';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    for (let i = -1; i <= 1; i++) { ctx.moveTo(i * 1.8, -8); ctx.lineTo(i * 2.4, -14); }
    ctx.stroke();
    ctx.restore();

    ctx.save();
    ctx.translate(dir * 13, -2);
    ctx.rotate(m.sway * 0.07);
    ctx.scale(dir, 1);
    drawBowShape(ctx, 24, { pull: 3 + (m.breath + 1) * 1.2, arrow: true, glow: '#9ef7bd' });
    ctx.restore();
  },

  assassin: (ctx, dir, m, t, mv, swingAmt) => {
    ctx.save();
    ctx.translate(0, -6);
    flowCloak(ctx, { dir, fill: '#c56cf0', t, top: -2, width: 5, len: 18, drift: mv.moving ? 10 : 2, speed: 8 });
    ctx.restore();
    [-1, 1].forEach(side => {
      ctx.save();
      ctx.translate(side * 10, 4);
      ctx.rotate(side * (0.75 + m.sway * 0.18) + swingAmt * side * 1.35);
      if (mv.moving) {
        ctx.strokeStyle = '#c56cf055';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, 18, -Math.PI * 0.65, -Math.PI * 0.35);
        ctx.stroke();
      }
      drawBlade(ctx, 26, 3.6, '#d5b8ff', '#6c2bd9', '#2a1740');
      ctx.restore();
    });
  },

  paladin: (ctx, dir, m, t, mv, swingAmt) => {
    ctx.save();
    ctx.globalAlpha *= 0.28;
    ctx.strokeStyle = '#ffe9a0';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const a = t * 0.6 + (TAU * i) / 8;
      ctx.moveTo(Math.cos(a) * 15, Math.sin(a) * 15 - 2);
      ctx.lineTo(Math.cos(a) * 32, Math.sin(a) * 32 - 2);
    }
    ctx.stroke();
    ctx.restore();

    ctx.save();
    ctx.translate(0, -23 + m.head * 0.6);
    ctx.scale(1, 0.35);
    drawRing(ctx, 0, 0, 9, '#fff1b8', 2.4);
    ctx.restore();

    for (let i = 0; i < 5; i++) {
      drawDiamond(ctx, Math.sin(t * 2 + i * 2) * 18, 12 - ((t * 14 + i * 9) % 42), 2.2, '#fff1b8');
    }

    ctx.save();
    ctx.translate(-dir * 14, 3);
    ctx.rotate(-dir * (0.06 + m.sway * 0.03));
    drawKiteShield(ctx, 11, 21, { fill: '#d9c27e', rim: '#3a2b12', emblem: '#fff6cc', glow: '#ffd700' });
    ctx.restore();

    ctx.save();
    ctx.translate(dir * 12, 3);
    ctx.rotate(dir * (0.5 + m.sway * 0.12) + swingAmt * 1.55);
    ctx.strokeStyle = '#704b26';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, 8);
    ctx.lineTo(0, -30);
    ctx.stroke();
    drawCircle(ctx, 0, -33, 15, 'rgba(255,215,0,.22)');
    ctx.fillStyle = '#ffd700';
    ctx.strokeStyle = '#3a2b12';
    ctx.lineWidth = 1.4;
    ctx.fillRect(-10, -40, 20, 12);
    ctx.strokeRect(-10, -40, 20, 12);
    ctx.restore();
  }
};

export function renderPlayer(ctx, t) {
  const p = state.player;
  const st = CLASS_STYLES[p.cls.id] || CLASS_STYLES.warrior;
  const dir = p.facingX >= 0 ? 1 : -1;
  const dashing = p.dashTimer > 0;
  const mv = { moving: p.moving, dashing };
  const m = idleMotion(t, 0, p.moving);
  const stride = p.moving ? Math.sin(t * 14) : 0;
  const bobY = p.moving ? -Math.abs(stride) * 2.6 : m.bob * 1.2;

  const sw = p._meleeVfx?.activeSwing;
  const swingAmt = sw ? sw.dir * Math.sin((1 - sw.timer / sw.maxTimer) * Math.PI) : 0;

  // Ground shockwaves beneath player
  for (let i = 0; i < groundImpacts.length; i++) {
    const g = groundImpacts[i];
    const k = g.life / g.maxLife;
    const exp = 0.45 + (1 - k) * 0.72;
    ctx.save();
    ctx.globalAlpha = k * 0.78;
    drawRing(ctx, g.x, g.y, g.r * exp, g.color, g.isCrit ? 3.6 : 2.5);
    if (g.isHoly) drawRing(ctx, g.x, g.y, g.r * exp * 0.68, '#fff7c2', 1.8);
    ctx.strokeStyle = g.isHoly ? '#ffd700' : '#1b1412';
    ctx.lineWidth = g.isCrit ? 2.4 : 1.8;
    ctx.beginPath();
    for (let j = 0; j < g.cracks.length; j++) {
      const ck = g.cracks[j];
      const l = ck.len * (0.55 + (1 - k) * 0.45);
      ctx.moveTo(g.x, g.y);
      ctx.lineTo(g.x + Math.cos(ck.a + ck.bend) * l * 0.5, g.y + Math.sin(ck.a + ck.bend) * l * 0.5);
      ctx.lineTo(g.x + Math.cos(ck.a) * l, g.y + Math.sin(ck.a) * l);
    }
    ctx.stroke();
    ctx.restore();
  }

  groundShadow(ctx, p.x, p.y + 21, dashing ? 26 : 19, 7);
  drawRing(ctx, p.x, p.y + 12, p.r + 5, 'rgba(201,160,80,.36)', 1.5);

  if (dashing) {
    ctx.save();
    ctx.globalAlpha = 0.45;
    ctx.strokeStyle = '#8ec5ff';
    ctx.lineWidth = 2.4;
    for (let i = -1; i <= 1; i++) {
      ctx.beginPath();
      ctx.moveTo(p.x - p.facingX * 36, p.y + i * 9);
      ctx.lineTo(p.x - p.facingX * 8, p.y + i * 9);
      ctx.stroke();
    }
    ctx.restore();
  }

  ctx.save();
  ctx.translate(p.x, p.y + bobY);
  ctx.scale(PLAYER_SCALE, PLAYER_SCALE);
  if (p.invuln > 0 && ((t * 22) | 0) % 2 === 0) ctx.globalAlpha = 0.52;

  drawCircle(ctx, 0, 0, 26, st.trim + '14');

  if (dashing) {
    ctx.rotate(dir * 0.22);
    ctx.scale(1.16, 0.9);
  } else if (p.moving) {
    ctx.rotate(dir * 0.06 + stride * 0.03);
  }
  if (swingAmt !== 0) {
    ctx.rotate(swingAmt * 0.14);
  }

  drawCloakPart(ctx, st, dir, mv, t);
  drawLegsPart(ctx, st, stride);
  const tw = drawTorsoPart(ctx, st, m);
  drawArmsPart(ctx, st, tw, stride, dir);
  drawHeadPart(ctx, st, dir, p.facingY, m, t);

  (CLASS_GEAR[p.cls.id] || CLASS_GEAR.warrior)(ctx, dir, m, t, mv, swingAmt);

  ctx.restore();

  // Render bright slash arcs & directional hit spark impacts over combat space
  for (let i = 0; i < slashEffects.length; i++) {
    drawSingleSlash(ctx, slashEffects[i]);
  }
  for (let i = 0; i < impactSparks.length; i++) {
    const sp = impactSparks[i];
    const k = sp.life / sp.maxLife;
    const len = (sp.isCrit ? 26 : 16) * (1.2 - k * 0.4);
    ctx.save();
    ctx.translate(sp.x, sp.y);
    ctx.rotate(sp.ang);
    ctx.globalAlpha = k;
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = sp.isCrit ? 2.6 : 1.8;
    ctx.beginPath();
    ctx.moveTo(-len, 0);
    ctx.lineTo(len, 0);
    ctx.moveTo(0, -len * 0.55);
    ctx.lineTo(0, len * 0.55);
    ctx.stroke();
    drawCircle(ctx, 0, 0, sp.isCrit ? 7 * k : 4.5 * k, sp.color);
    ctx.restore();
  }
}