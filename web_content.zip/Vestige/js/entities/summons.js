import { poly } from '../core/utilities.js';
import { state, summons } from '../core/game.js';
import { targetForSummon, getSummonRange, fireProj } from './projectiles.js';
import { weaponMult } from '../systems/mastery.js';

export function syncSummons(p, s) {
  const c = p.cls;
  const cnt =
    (c.id === 'necromancer' ? 2 : 0) +
    (p.weapons.grimoire ? p.weapons.grimoire.level + (p.weapons.grimoire.evolved ? 2 : 0) : 0) +
    (s.keystones.has('Avatar of the Hollow') ? 3 : 0);
  const total = cnt + ((s.sets.ashenking || 0) >= 6 ? 2 : 0);

  while (summons.length < total) {
    summons.push({
      x: p.x,
      y: p.y,
      ang: Math.random() * 6.28,
      cd: 0.3,
      isKnight: summons.length >= cnt
    });
  }
  summons.length = total;
}

export function updateSummons(dt) {
  const p = state.player;
  const evolvedGr = p.weapons.grimoire?.evolved;
  const grMult = weaponMult('grimoire');

  for (let i = 0; i < summons.length; i++) {
    const s = summons[i];
    s.ang += dt * 1.9;
    const rad = s.isKnight ? 85 : 58;
    s.x += (p.x + Math.cos(s.ang + i * 1.9) * rad - s.x) * Math.min(1, dt * 6);
    s.y += (p.y + Math.sin(s.ang + i * 1.9) * rad - s.y) * Math.min(1, dt * 6);

    if ((s.cd -= dt * p.stats.atkSpeed) <= 0) {
      // Summons only attack enemies inside their own attack range (scales with the range stat)
      const t = targetForSummon(s, null, 'ranged');
      if (t) {
        s.cd = evolvedGr || s.isKnight ? 0.42 : 0.68;
        const a = Math.atan2(t.y - s.y, t.x - s.x);
        fireProj(
          s.x,
          s.y,
          Math.cos(a),
          Math.sin(a),
          500,
          p.stats.summonDmg * (s.isKnight ? 1.4 : 0.9) * grMult,
          s.isKnight ? '#ffd700' : '#5effb1',
          evolvedGr ? 2 : 0,
          1.2,
          false,
          0.05,
          p.weapons.grimoire ? 'grimoire' : null,
          getSummonRange(null, 'ranged') * 1.15
        );
      }
    }
  }
}

export function renderSummons(ctx) {
  for (const s of summons) {
    poly(ctx, s.x, s.y, 8, [0, -1.1, 0.9, 0.9, -0.9, 0.9], s.isKnight ? '#ffd700' : '#5effb1', '#09070d', 1.2);
  }
}