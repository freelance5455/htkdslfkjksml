import { poly, drawCircle, drawRing, drawDiamond, drawBeam, SIL } from '../core/utilities.js';
import { metaSave, hasUnlock, grantFrag } from '../core/save.js';
import { sfx } from '../core/audio.js';
import {
  state,
  arcs,
  hazards,
  bossDeaths,
  addShake,
  spawnParticles,
  openEndingModal
} from '../core/game.js';

import { BossScalingConfig } from '../data/bossData.js';
import { drawFactionAccent } from './enemies.js';
import { damagePlayer } from './player.js';
import { spawnEnemyProj, spawnElementalImpact, resolveSpellElement } from './projectiles.js';
import { generateLootItem, dropLoot } from './loot.js';
import { idleMotion, orbit, hemCloak, drawPauldron, drawShardOrbit } from './renderKit.js';

import { unlockLore } from '../systems/codex.js';
import { unlockAchievement } from '../systems/achievements.js';
import { addFeed, showBanner } from '../ui/notifications.js';

// ============================================================================
// SHARED BOSS VFX STATE & LIFECYCLE (ONCE-PER-FRAME GUARDED)
// ============================================================================

const bossTelegraphs = [];
const bossMeteors = [];
const bossArenaFlashes = [];
const bossRewardBursts = [];

let lastVfxUpdateTime = -1;
let lastVfxRenderTime = -1;

function resetBossVfxIfNeeded() {
  if (state.time < lastVfxUpdateTime) {
    bossTelegraphs.length = 0;
    bossMeteors.length = 0;
    bossArenaFlashes.length = 0;
    bossRewardBursts.length = 0;
    lastVfxRenderTime = -1;
  }
}

function spawnArenaFlash(x, y, color, radius = 420, dur = 0.65, tintAlpha = 0.24) {
  if (bossArenaFlashes.length >= 8) bossArenaFlashes.shift();
  bossArenaFlashes.push({ x, y, color, radius, t: 0, dur, tintAlpha });
}

function spawnRewardBurst(x, y, color, count = 18) {
  if (bossRewardBursts.length >= 6) bossRewardBursts.shift();
  const motes = [];
  for (let i = 0; i < count; i++) {
    const a = (i / count) * 6.283 + (Math.random() - 0.5) * 0.35;
    const spd = 90 + Math.random() * 210;
    motes.push({
      x,
      y,
      vx: Math.cos(a) * spd,
      vy: Math.sin(a) * spd - 65,
      r: 3 + Math.random() * 3.5,
      col: i % 3 === 0 ? '#ffd700' : i % 3 === 1 ? '#ffffff' : color
    });
  }
  bossRewardBursts.push({ x, y, color, motes, t: 0, dur: 1.15 });
}

function spawnBossTelegraph(kind, x, y, dmg, dur, color, extra = {}) {
  if (bossTelegraphs.length >= 28) bossTelegraphs.shift();
  bossTelegraphs.push({
    kind,
    x,
    y,
    dmg,
    t: 0,
    dur,
    color,
    r: 80,
    ang: 0,
    spread: 1.1,
    len: 420,
    w: 28,
    elem: resolveSpellElement(null, color, true),
    hazardDur: 0,
    ...extra
  });
}

// ============================================================================
// REUSABLE RUNE, TELEGRAPH & ARENA VFX RENDERERS
// ============================================================================

export function drawRuneCircle(c, x, y, r, color, rot, innerRatio = 0.76) {
  drawRing(c, x, y, r, color + 'aa', 1.8);
  drawRing(c, x, y, r * innerRatio, color + '66', 1.2);
  c.strokeStyle = color + '88';
  c.lineWidth = 1.4;
  c.beginPath();
  for (let i = 0; i < 4; i++) {
    const a = rot + i * 1.5708;
    c.moveTo(x + Math.cos(a) * r, y + Math.sin(a) * r);
    c.lineTo(x + Math.cos(a + 2.356) * r * 0.8, y + Math.sin(a + 2.356) * r * 0.8);
  }
  c.stroke();
}

function drawBossTelegraph(c, tg, t) {
  const p = Math.min(1, tg.t / tg.dur);
  const pulse = 0.5 + 0.5 * Math.sin(t * (8 + p * 14));
  const warnCol = p > 0.84 ? '#ffffff' : tg.color;

  c.save();
  if (tg.kind === 'cone' || tg.kind === 'infernal_cleave') {
    const a0 = tg.ang - tg.spread * 0.5;
    const a1 = tg.ang + tg.spread * 0.5;

    // Outer danger sector
    c.fillStyle = tg.color;
    c.globalAlpha = 0.14 + pulse * 0.08;
    c.beginPath();
    c.moveTo(tg.x, tg.y);
    c.arc(tg.x, tg.y, tg.r, a0, a1);
    c.closePath();
    c.fill();

    // Growing danger fill sweeping outward
    c.globalAlpha = 0.28 + p * 0.34;
    c.beginPath();
    c.moveTo(tg.x, tg.y);
    c.arc(tg.x, tg.y, tg.r * p, a0, a1);
    c.closePath();
    c.fill();

    // Rune arc ticks along perimeter
    c.globalAlpha = 0.9;
    c.strokeStyle = warnCol;
    c.lineWidth = p > 0.84 ? 3 : 2;
    c.beginPath();
    c.moveTo(tg.x, tg.y);
    c.arc(tg.x, tg.y, tg.r, a0, a1);
    c.closePath();
    c.stroke();

    for (let i = 0; i <= 4; i++) {
      const ra = a0 + (tg.spread * i) / 4;
      drawDiamond(c, tg.x + Math.cos(ra) * tg.r, tg.y + Math.sin(ra) * tg.r, 4.5, warnCol);
    }
  } else if (tg.kind === 'beam' || tg.kind === 'holy_beam') {
    c.translate(tg.x, tg.y);
    c.rotate(tg.ang);
    // Pulsing danger corridor
    c.globalAlpha = 0.16 + pulse * 0.12;
    c.fillStyle = tg.color;
    c.fillRect(0, -tg.w * 0.5, tg.len, tg.w);
    // Growing inner lethal core
    const innerW = tg.w * p;
    c.globalAlpha = 0.32 + p * 0.44;
    c.fillStyle = warnCol;
    c.fillRect(0, -innerW * 0.5, tg.len, innerW);
    c.globalAlpha = 0.9;
    c.strokeStyle = warnCol;
    c.lineWidth = 1.8;
    c.strokeRect(0, -tg.w * 0.5, tg.len, tg.w);
    drawRuneCircle(c, 0, 0, tg.w * 0.72, warnCol, t * 4);
  } else {
    // Pulsing Circle + Rune Indicator + Growing Danger Zone
    c.globalAlpha = 0.15 + pulse * 0.10;
    drawCircle(c, tg.x, tg.y, tg.r, tg.color);

    c.globalAlpha = 0.24 + p * 0.38;
    drawCircle(c, tg.x, tg.y, tg.r * p, warnCol);

    c.globalAlpha = 0.88;
    drawRuneCircle(c, tg.x, tg.y, tg.r, warnCol, t * (1.8 + p * 4));

    // Orbiting warning diamonds on perimeter
    for (let i = 0; i < 4; i++) {
      const a = t * 2.4 + i * 1.5708;
      drawDiamond(c, tg.x + Math.cos(a) * tg.r, tg.y + Math.sin(a) * tg.r, 4.5 + pulse * 1.5, warnCol);
    }
  }
  c.restore();
}

function tickBossVfx(dt) {
  resetBossVfxIfNeeded();
  if (lastVfxUpdateTime === state.time) return;
  lastVfxUpdateTime = state.time;

  const p = state.player;

  // 1) Telegraphs -> resolve strikes & elemental impacts
  for (let i = bossTelegraphs.length - 1; i >= 0; i--) {
    const tg = bossTelegraphs[i];
    tg.t += dt;
    if (tg.t < tg.dur) continue;

    if (tg.kind === 'cone' || tg.kind === 'infernal_cleave') {
      if (p && Math.hypot(p.x - tg.x, p.y - tg.y) <= tg.r + p.r) {
        let da = Math.atan2(p.y - tg.y, p.x - tg.x) - tg.ang;
        while (da > Math.PI) da -= 6.283;
        while (da < -Math.PI) da += 6.283;
        if (Math.abs(da) <= tg.spread * 0.5) damagePlayer(tg.dmg);
      }
      arcs.push({ cone: { x: tg.x, y: tg.y, r: tg.r, ang: tg.ang, spread: tg.spread }, life: 0.25, color: tg.color });
      spawnElementalImpact(tg.x + Math.cos(tg.ang) * tg.r * 0.55, tg.y + Math.sin(tg.ang) * tg.r * 0.55, tg.elem, tg.r * 0.35, true, tg.ang);
      if (tg.kind === 'infernal_cleave') {
        addShake(9);
        for (let s = -2; s <= 2; s++) {
          const sa = tg.ang + s * 0.22;
          spawnEnemyProj(tg.x, tg.y, Math.cos(sa) * 280, Math.sin(sa) * 280, 9, tg.dmg * 0.72, 2.2, tg.color);
        }
      }
    } else if (tg.kind === 'beam' || tg.kind === 'holy_beam') {
      const vx = Math.cos(tg.ang);
      const vy = Math.sin(tg.ang);
      if (p) {
        const px = p.x - tg.x;
        const py = p.y - tg.y;
        const proj = Math.max(0, Math.min(tg.len, px * vx + py * vy));
        if ((px - vx * proj) ** 2 + (py - vy * proj) ** 2 <= (tg.w * 0.5 + p.r) ** 2) damagePlayer(tg.dmg);
      }
      arcs.push({ beam: { x: tg.x, y: tg.y, ex: tg.x + vx * tg.len, ey: tg.y + vy * tg.len, w: tg.w }, life: 0.26, color: tg.color });
      spawnElementalImpact(tg.x + vx * tg.len * 0.45, tg.y + vy * tg.len * 0.45, tg.elem, 34, true, tg.ang);
      addShake(6);
    } else {
      // Circle / Meteor / Void Eruption / Holy Judgment / Shockwave
      if (p && (p.x - tg.x) ** 2 + (p.y - tg.y) ** 2 <= (tg.r + p.r) ** 2) damagePlayer(tg.dmg);
      arcs.push({ ring: { x: tg.x, y: tg.y, r: tg.r }, life: 0.28, color: tg.color });
      spawnElementalImpact(tg.x, tg.y, tg.elem, tg.r * 0.78, true);
      spawnParticles(tg.x, tg.y, tg.color, 18, 220);

      if (tg.kind === 'meteor' || tg.kind === 'void_eruption' || tg.kind === 'holy_judgment') {
        addShake(9);
        spawnArenaFlash(tg.x, tg.y, tg.color, tg.r * 2.2, 0.42, 0.14);
        if (tg.kind === 'void_eruption') {
          for (let k = 0; k < 8; k++) {
            const a = (k / 8) * 6.283;
            spawnEnemyProj(tg.x, tg.y, Math.cos(a) * 210, Math.sin(a) * 210, 8, tg.dmg * 0.65, 2.3, '#b55cff');
          }
        }
        if (tg.hazardDur > 0) {
          hazards.push({
            x: tg.x,
            y: tg.y,
            r: tg.r * 0.8,
            dmg: tg.dmg * 0.35,
            life: tg.hazardDur,
            maxLife: tg.hazardDur,
            color: tg.color,
            isEnemy: true
          });
        }
      }
    }
    bossTelegraphs.splice(i, 1);
  }

  // 2) Falling meteors / sky lances synced with impact
  for (let i = bossMeteors.length - 1; i >= 0; i--) {
    const m = bossMeteors[i];
    m.t += dt;
    if (m.t >= m.dur) bossMeteors.splice(i, 1);
  }

  // 3) Arena flashes & screen tints
  for (let i = bossArenaFlashes.length - 1; i >= 0; i--) {
    if ((bossArenaFlashes[i].t += dt) >= bossArenaFlashes[i].dur) bossArenaFlashes.splice(i, 1);
  }

  // 4) Boss death reward bursts
  for (let i = bossRewardBursts.length - 1; i >= 0; i--) {
    const rb = bossRewardBursts[i];
    rb.t += dt;
    for (let j = 0; j < rb.motes.length; j++) {
      const m = rb.motes[j];
      m.x += m.vx * dt;
      m.y += m.vy * dt;
      m.vy += 240 * dt;
      m.vx *= 0.98;
    }
    if (rb.t >= rb.dur) bossRewardBursts.splice(i, 1);
  }
}

function renderSharedBossVfx(c) {
  if (lastVfxRenderTime === state.time) return;
  lastVfxRenderTime = state.time;
  const t = state.time;

  for (let i = 0; i < bossTelegraphs.length; i++) {
    drawBossTelegraph(c, bossTelegraphs[i], t);
  }

  // Sky-falling meteors & holy judgment sky beams
  for (let i = 0; i < bossMeteors.length; i++) {
    const m = bossMeteors[i];
    const p = Math.min(1, m.t / m.dur);
    if (m.kind === 'meteor') {
      const startY = m.y - 360 * (1 - p);
      const startX = m.x + 120 * (1 - p);
      c.save();
      c.strokeStyle = '#ff8c38';
      c.lineWidth = 10;
      c.globalAlpha = 0.55;
      c.beginPath();
      c.moveTo(startX + 45, startY - 120);
      c.lineTo(startX, startY);
      c.stroke();
      c.globalAlpha = 1;
      drawCircle(c, startX, startY, 16, '#ff4518', '#ffe099', 2.5);
      c.restore();
    } else if (m.kind === 'holy_judgment' && p > 0.72) {
      const k = (p - 0.72) / 0.28;
      c.save();
      c.globalAlpha = k;
      drawBeam(c, m.x, m.y, 440, '#ffd700');
      drawBeam(c, m.x, m.y, 320, '#ffffff');
      c.restore();
    }
  }

  // Arena wave flashes + screen tint overlay
  for (let i = 0; i < bossArenaFlashes.length; i++) {
    const f = bossArenaFlashes[i];
    const p = f.t / f.dur;
    const inv = 1 - p;
    c.save();
    c.globalAlpha = inv * 0.85;
    drawRing(c, f.x, f.y, f.radius * (0.25 + p * 0.95), f.color, 7 * inv + 1);
    drawRing(c, f.x, f.y, f.radius * (0.15 + p * 0.65), '#ffffff', 3.5 * inv);

    if (f.tintAlpha > 0) {
      c.setTransform(1, 0, 0, 1, 0, 0);
      c.globalAlpha = inv * f.tintAlpha;
      c.fillStyle = f.color;
      c.fillRect(0, 0, c.canvas.width, c.canvas.height);
    }
    c.restore();
  }

  // Reward burst motes
  for (let i = 0; i < bossRewardBursts.length; i++) {
    const rb = bossRewardBursts[i];
    const k = 1 - rb.t / rb.dur;
    c.save();
    c.globalAlpha = k;
    for (let j = 0; j < rb.motes.length; j++) {
      const m = rb.motes[j];
      drawDiamond(c, m.x, m.y, m.r * (0.6 + k * 0.6), m.col);
    }
    c.restore();
  }
}

// ============================================================================
// BOSS ULTIMATE ATTACK DISPATCHER
// ============================================================================

const BOSS_ULTIMATES = {
  meteor_strike(e, p) {
    addFeed(`${e.bossData.name}: METEOR STRIKE!`, '#ff7b29');
    const count = e.phase === 2 ? 5 : 3;
    for (let i = 0; i < count; i++) {
      const tx = p.x + (i === 0 ? 0 : (Math.random() - 0.5) * 260);
      const ty = p.y + (i === 0 ? 0 : (Math.random() - 0.5) * 260);
      const dur = 1.25 + i * 0.18;
      spawnBossTelegraph('meteor', tx, ty, e.dmg * 1.45, dur, '#ff5a1f', {
        r: 92,
        elem: 'fire',
        hazardDur: 3.2
      });
      bossMeteors.push({ kind: 'meteor', x: tx, y: ty, t: 0, dur });
    }
  },

  void_eruption(e, p) {
    addFeed(`${e.bossData.name}: VOID ERUPTION!`, '#c084fc');
    const pts = [
      { x: e.x, y: e.y, r: 155 },
      { x: p.x, y: p.y, r: 112 },
      { x: p.x + 150, y: p.y - 90, r: 95 },
      { x: p.x - 150, y: p.y + 90, r: 95 }
    ];
    const cnt = e.phase === 2 ? pts.length : 3;
    for (let i = 0; i < cnt; i++) {
      spawnBossTelegraph('void_eruption', pts[i].x, pts[i].y, e.dmg * 1.38, 1.35 + i * 0.12, '#a855f7', {
        r: pts[i].r,
        elem: 'void',
        hazardDur: 3.0
      });
    }
  },

  holy_judgment(e, p) {
    addFeed(`${e.bossData.name}: HOLY JUDGMENT!`, '#ffd700');
    const ba = Math.atan2(p.y - e.y, p.x - e.x);
    for (let i = -1; i <= 1; i++) {
      spawnBossTelegraph('holy_beam', e.x, e.y, e.dmg * 1.35, 1.25, '#ffd700', {
        ang: ba + i * 0.45,
        len: 520,
        w: 34,
        elem: 'holy'
      });
    }
    const strikes = e.phase === 2 ? 4 : 2;
    for (let i = 0; i < strikes; i++) {
      const tx = p.x + (Math.random() - 0.5) * 200;
      const ty = p.y + (Math.random() - 0.5) * 200;
      const dur = 1.15 + i * 0.2;
      spawnBossTelegraph('holy_judgment', tx, ty, e.dmg * 1.4, dur, '#ffd700', {
        r: 96,
        elem: 'holy'
      });
      bossMeteors.push({ kind: 'holy_judgment', x: tx, y: ty, t: 0, dur });
    }
  },

  infernal_cleave(e, p) {
    addFeed(`${e.bossData.name}: INFERNAL CLEAVE!`, '#ff4757');
    const ba = Math.atan2(p.y - e.y, p.x - e.x);
    spawnBossTelegraph('infernal_cleave', e.x, e.y, e.dmg * 1.5, 1.18, e.phase === 2 ? '#ff2a4b' : e.color, {
      r: 295,
      ang: ba,
      spread: e.phase === 2 ? 2.45 : 1.9,
      elem: e.faction === 'bramble' ? 'necromancy' : 'fire'
    });
  }
};

function chooseBossUltimate(e) {
  const id = e.bossData?.id;
  if (id === 'astrea' || id === 'remnant_echo') return 'holy_judgment';
  if (id === 'nameless' || id === 'vaelor') return 'void_eruption';
  if (id === 'colossus') return 'meteor_strike';
  if (id === 'godrick' || id === 'matriarch') return e.phase === 2 && Math.random() < 0.5 ? 'meteor_strike' : 'infernal_cleave';
  if (e.faction === 'choir') return 'holy_judgment';
  if (e.faction === 'veiled') return 'void_eruption';
  return 'infernal_cleave';
}

// ============================================================================
// BOSS AURA, ARENA & LAYERED RENDERING
// ============================================================================

function drawBossAuraAndArena(c, e, t) {
  const col = e.color;
  const arenaR = e.r * 3.3;

  // Encounter arena ring, environmental storm wisps & orbiting boundary runes
  c.save();
  c.globalAlpha = e.phase === 2 ? 0.34 : 0.18;
  drawRing(c, e.x, e.y, arenaR, col, e.phase === 2 ? 2.8 : 2.2);
  if (e.phase === 2) {
    drawRing(c, e.x, e.y, arenaR * 0.88, '#ff2a4b88', 1.4);
  }
  for (let i = 0; i < 6; i++) {
    const a = t * (e.phase === 2 ? 0.65 : 0.35) + (Math.PI * 2 * i) / 6;
    drawDiamond(c, e.x + Math.cos(a) * arenaR, e.y + Math.sin(a) * arenaR, e.phase === 2 ? 6.5 : 5, col);
  }
  c.restore();

  // Double counter-rotating boss rune seals
  drawRuneCircle(c, e.x, e.y, e.r * 1.55, col, t * (e.phase === 2 ? 2.1 : 0.9));
  drawRuneCircle(c, e.x, e.y, e.r * 1.22, e.phase === 2 ? '#ff2a4b' : col, -t * 1.15);

  if (e.phase === 2 || e.role === 'ancient') {
    drawRing(
      c,
      e.x,
      e.y,
      e.r * (1.28 + Math.sin(t * 8) * 0.08),
      e.role === 'ancient' ? '#ffd700' : '#ff2a4b',
      3.2
    );
  }

  // Phase transition flare wave
  if (e.phaseFxT > 0) {
    const k = 1 - e.phaseFxT / 1.1;
    c.save();
    c.globalAlpha = 1 - k;
    drawRing(c, e.x, e.y, e.r * (1.4 + k * 3.6), '#ff2a4b', 5.5 * (1 - k));
    drawRing(c, e.x, e.y, e.r * (1.0 + k * 2.6), '#ffd700', 3.4 * (1 - k));
    c.restore();
  }

  // Pre-attack boss telegraph windup glow
  if (e.atkCd < 0.55) {
    drawRing(c, e.x, e.y, e.r * (1.42 + (0.55 - e.atkCd) * 0.7), '#ffffffcc', 2.4);
  }
}

function drawBossLayeredFrame(c, e, sc, fill, cloakFill, trimCol, t, opt = {}) {
  const seed = e.seed || 0;
  const m = idleMotion(t, seed, true);
  const shoulder = opt.shoulder ?? 1;
  const sil = SIL[e.bossData.id] || SIL.godrick;
  c.scale(1 - m.breath * 0.035, 1 + m.breath * 0.045);

  poly(c, 0, 0, sc * 1.07, sil, 'rgba(0,0,0,0)', e.color + '99', 5);

  if (cloakFill) {
    c.save();
    c.scale(sc, sc);
    hemCloak(c, { fill: cloakFill, t, seed, top: -15, w: 18 * shoulder, len: 36, amp: 3 });
    c.restore();
  }

  poly(c, 0, 0, sc, sil, fill, '#060409', 3);
  poly(c, 0, 0, sc * 0.72, sil, 'rgba(0,0,0,0.26)', 'rgba(0,0,0,0)', 0);

  if (opt.pauldrons !== false) {
    [-1, 1].forEach(s => drawPauldron(c, s * 17 * sc * shoulder, -10 * sc, 7.5 * sc, fill, '#060409', trimCol, s));
  }

  if (trimCol) {
    c.strokeStyle = trimCol;
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(-8 * sc, -6 * sc);
    c.lineTo(0, 6 * sc);
    c.lineTo(8 * sc, -6 * sc);
    c.stroke();
  }

  c.fillStyle = e.hitFlash > 0 ? '#000' : e.phase === 2 ? '#ff2a4b' : '#fff4c2';
  c.fillRect((-4.5 + m.head * 0.9) * sc, -13 * sc, 3.6, 3.6);
  c.fillRect((1.5 + m.head * 0.9) * sc, -13 * sc, 3.6, 3.6);
}

function drawSwayPoly(c, x, y, scale, baseRot, sway, pts, fill, stroke, lw) {
  c.save();
  c.translate(x, y);
  c.rotate(baseRot + sway);
  poly(c, 0, 0, scale, pts, fill, stroke, lw);
  c.restore();
}

const BOSS_RENDER_THEMES = {
  godrick: (c, e, sc, fill, t) => {
    drawBossLayeredFrame(c, e, sc, fill, '#4f121b', '#ffd700', t, { shoulder: 1.2 });
    const bob = Math.sin(t * 2.2) * 1.5 * sc;
    poly(c, 0, -e.r * 1.2 + bob, sc * 1.45, SIL.crown, '#ffd700', '#2b1905', 1.8);
    drawCircle(c, 0, -2 * sc, 5.5 * sc, '#ff6b3d', '#ffd700', 1.6);
    const sway = Math.sin(t * 2) * 0.1;
    drawSwayPoly(c, -28 * sc, -2 * sc, sc * 1.8, -0.25, sway, [-3, 16, 3, 16, 4.5, -18, 0, -25, -4.5, -18], '#c4cdd6', '#111', 1.6);
    drawCircle(c, -28 * sc - Math.sin(-0.25 + sway) * 40 * sc, -2 * sc - Math.cos(-0.25 + sway) * 26 * sc, (5 + Math.sin(t * 9) * 1.2) * sc, '#ff8c38aa');
  },
  astrea: (c, e, sc, fill, t) => {
    for (let s = -1; s <= 1; s += 2) {
      for (let w = 0; w < 3; w++) {
        const flap = Math.sin(t * 3.2 + w * 0.7) * 5 * sc;
        poly(c, s * (13 + w * 8) * sc, (-12 + w * 8) * sc + flap, sc * 1.4, [0, -4, s * 22, -12, s * 14, 5], '#8ec5ff88', '#e3efff', 1.2);
      }
    }
    drawBossLayeredFrame(c, e, sc, fill, '#16254a', '#dbe8ff', t, { shoulder: 1.1 });
    drawRing(c, 0, -e.r * 1.1, 14 * sc, '#ffd700', 2.4);
    drawRing(c, 0, -e.r * 1.1, 19 * sc, '#8ec5ff88', 1.2);
  },
  colossus: (c, e, sc, fill, t) => {
    drawBossLayeredFrame(c, e, sc, fill, null, '#ff7f50', t, { shoulder: 1.4 });
    c.strokeStyle = '#ff7f50';
    c.lineWidth = 2.8;
    c.beginPath();
    c.moveTo(0, -18 * sc);
    c.lineTo(-4 * sc, -1 * sc);
    c.lineTo(3 * sc, 12 * sc);
    c.stroke();
    drawSwayPoly(c, -30 * sc, 2 * sc, sc * 1.9, 0, Math.sin(t * 1.8) * 0.05, [-6, -13, 6, -13, 7, 11, 0, 16, -7, 11], '#2f3542', '#a4b0be', 1.8);
  },
  matriarch: (c, e, sc, fill, t) => {
    drawBossLayeredFrame(c, e, sc, fill, '#162e26', '#7bed9f', t, { shoulder: 1.05 });
    orbit(4, t, 2.2, 34 * sc, 19 * sc, (x, y) => drawCircle(c, x, y, 6.5 * sc, '#d8f3dc', '#2d6a4f', 1.5));
    poly(c, 0, -e.r * 1.14 + Math.sin(t * 2.4) * 1.5 * sc, sc * 1.2, SIL.crown, '#7bed9f', '#0a1410', 1.4);
  },
  nameless: (c, e, sc, fill, t) => {
    c.save();
    c.strokeStyle = '#ff2a4b88';
    c.lineWidth = 3.2 * sc;
    c.lineCap = 'round';
    for (let i = 0; i < 6; i++) {
      const a = (Math.PI * 2 * i) / 6 + t * 0.4;
      const w = Math.sin(t * 3 + i * 1.3) * 12 * sc;
      c.beginPath();
      c.moveTo(Math.cos(a) * 14 * sc, Math.sin(a) * 14 * sc);
      c.quadraticCurveTo(Math.cos(a + 0.5) * 34 * sc + w, Math.sin(a + 0.5) * 34 * sc - w, Math.cos(a) * 48 * sc, Math.sin(a) * 48 * sc);
      c.stroke();
    }
    c.restore();
    drawBossLayeredFrame(c, e, sc, fill, '#140717', '#ff2a4b', t, { shoulder: 1.1 });
    drawRing(c, 0, 0, e.r * 1.25, '#ff2a4b', 2.2);
    drawCircle(c, 0, 0, 8 * sc, '#050308', '#ff2a4b', 2.2);
    drawDiamond(c, 0, 0, 5.2 * sc, '#ff708d');
  },
  vaelor: (c, e, sc, fill, t) => {
    drawBossLayeredFrame(c, e, sc, fill, '#230d36', '#f368e0', t, { shoulder: 1.15 });
    drawShardOrbit(c, 4, t, 2.1, 38 * sc, 26 * sc, 7.5 * sc, ['#ff8c38', '#9e47ff', '#8ec5ff', '#cbc4d8']);
    drawCircle(c, 0, 0, 6.5 * sc, '#08060c', '#f368e0', 2);
  },
  remnant_echo: (c, e, sc, fill, t) => {
    drawBossLayeredFrame(c, e, sc, fill, '#38240c', '#ffd700', t, { shoulder: 1.25 });
    poly(c, 0, -e.r * 1.2 + Math.sin(t * 2.2) * 1.5 * sc, sc * 1.4, SIL.crown, '#ffd700', '#000', 1.6);
    drawRing(c, 0, 0, e.r * 1.26, '#ff8c00', 2.2);
    [-1, 1].forEach(side => {
      drawSwayPoly(c, side * 28 * sc, 0, sc * 1.7, side * 0.18, Math.sin(t * 2 + side) * 0.1, [-2, 12, 2, 12, 0, -18], '#fff0b3', '#ff8c00', 1.2);
    });
  }
};

export function drawBossBody(c, e, t, fill) {
  const id = e.bossData.id;
  const sc = (e.r / 20) * 1.18;

  renderSharedBossVfx(c);

  if (e.spawnT > 0) {
    const iDur = BossScalingConfig[e.role].introDur || 1.6;
    const pr = 1 - e.spawnT / iDur;
    drawBeam(c, e.x, e.y, 340 * (1 - pr * 0.35), e.color);
    drawRing(c, e.x, e.y, e.r * (2.8 - pr * 1.6), '#ffffffcc', 2.5);
  }

  drawBossAuraAndArena(c, e, t);

  c.save();
  c.translate(e.x, e.y - Math.sin(t * 2.6) * 2.5);
  const drawTheme = BOSS_RENDER_THEMES[id] || BOSS_RENDER_THEMES.godrick;
  drawTheme(c, e, sc, fill, t);
  c.restore();

  drawFactionAccent(c, e.faction, e.x, e.y, e.r * 1.12, t, e.color);
}

// ============================================================================
// BOSS AI, PHASE TRANSITIONS & SPECTACLE ATTACKS
// ============================================================================

export function updateBossBehavior(e, dt, dx, dy, spawnEnemyFn) {
  tickBossVfx(dt);
  const p = state.player;
  if (e.phaseFxT > 0) e.phaseFxT = Math.max(0, e.phaseFxT - dt);
  if (e.ultCd == null) e.ultCd = 6.5;

  // Phase II Transition: Arena Flash, Rune Seal, Environmental Hazards & Reinforcements
  if (e.hp < e.maxHp * 0.5 && e.phase === 1) {
    e.phase = 2;
    e.phaseFxT = 1.1;
    e.speed *= 1.25;
    e.ultCd = 1.2;
    addFeed(`${e.bossData.name} Enters Phase II!`, '#ff2a4b');
    showBanner('PHASE II', `${e.bossData.name} Unleashes True Power`, '#ff2a4b', 2.4);

    arcs.push({ ring: { x: e.x, y: e.y, r: 260 }, life: 0.42, color: '#ff2a4b' });
    spawnArenaFlash(e.x, e.y, '#ff2a4b', 520, 0.78, 0.28);
    addShake(12);
    spawnParticles(e.x, e.y, e.color, 36, 280);

    // Environmental Phase II hazard zones around the arena perimeter
    for (let k = 0; k < 4; k++) {
      const a = (k / 4) * 6.283 + 0.4;
      hazards.push({
        x: e.x + Math.cos(a) * 175,
        y: e.y + Math.sin(a) * 175,
        r: 72,
        dmg: e.dmg * 0.4,
        life: 6.5,
        maxLife: 6.5,
        color: e.color,
        isEnemy: true
      });
      spawnEnemyFn('normal');
    }
  }

  // Ultimate Attack Cadence
  if ((e.ultCd -= dt) <= 0) {
    e.ultCd = e.phase === 2 ? 6.2 : 8.8;
    const ultName = chooseBossUltimate(e);
    BOSS_ULTIMATES[ultName](e, p);
    e.atkCd = Math.max(e.atkCd, 1.5);
  }

  // Standard Boss Attacks (using enhanced pulsing rune telegraphs)
  if ((e.atkCd -= dt) <= 0) {
    e.atkCd = e.phase === 2 ? 1.7 : 2.5;
    const ba = Math.atan2(dy, dx);
    const roll = Math.random();

    if (roll < 0.32) {
      spawnBossTelegraph('cone', e.x, e.y, e.dmg * 1.2, 0.95, e.color, { r: 245, ang: ba, spread: 1.15 });
    } else if (
      roll < 0.62 &&
      (e.bossData.id === 'astrea' || e.bossData.id === 'nameless' || e.bossData.secret || e.phase === 2)
    ) {
      spawnBossTelegraph('beam', e.x, e.y, e.dmg * 1.3, 1.05, e.color, { ang: ba, len: 490, w: 30 });
    } else if (roll < 0.82) {
      spawnBossTelegraph('shockwave', e.x, e.y, e.dmg * 1.15, 1.15, e.color, { r: 195 });
    } else {
      const cnt = e.phase === 2 ? 8 : 5;
      for (let s = 0; s < cnt; s++) {
        const a = ba + (s - (cnt - 1) / 2) * 0.25;
        spawnEnemyProj(e.x, e.y, Math.cos(a) * 230, Math.sin(a) * 230, 8, e.dmg, 2.4, e.color);
      }
      spawnBossTelegraph('circle', p.x, p.y, e.dmg, 1.0, '#ff2a4b', { r: 72 });
    }
  }
}

// ============================================================================
// BOSS REWARDS & DEATH EXPLOSION SEQUENCE
// ============================================================================

export function grantBossRewards(e, sc) {
  const p = state.player;
  const cfg = BossScalingConfig[e.role];
  const rw = sc.rewardMult;
  const fm = sc.fragMult;
  const dng = state.dungeon;

  state.runGold += Math.round(cfg.gold * rw);
  state.runShards += Math.round(cfg.shards * rw);
  state.runEssence += cfg.essence;

  for (const [fk, base] of Object.entries(cfg.frags)) {
    grantFrag(fk, Math.max(1, Math.round(base * fm * (dng[`${fk}M`] || 1))));
  }

  if (e.boss) {
    p.flamesGathered++;
    metaSave.bossKills++;
    const echoB = hasUnlock('boss_echo') ? 2 : 0;
    const fKey =
      e.bossData.faction === 'throne'
        ? 'flame'
        : e.bossData.faction === 'choir'
        ? 'star'
        : e.bossData.faction === 'veiled'
        ? 'void'
        : 'ash';
    grantFrag(fKey, Math.max(1, Math.round((2 + echoB) * fm)));
    if (!p.bossesDefeated.includes(e.bossData.id)) p.bossesDefeated.push(e.bossData.id);
    bossDeaths.push({
      x: e.x,
      y: e.y,
      r: e.r,
      color: e.color,
      bossData: e.bossData,
      t: 0,
      dur: cfg.deathDur,
      nextPulse: 0.15
    });
    spawnArenaFlash(e.x, e.y, e.color, 360, 0.55, 0.18);
    addShake(15);
    sfx.play('legendary');
    showBanner(
      `${e.bossData.name.toUpperCase()} FELLED`,
      `${e.role === 'ancient' ? 'Ancient Relic' : e.role === 'secret' ? 'Secret Truth' : 'Flame Fragment'} Claimed (${p.flamesGathered}/5)`,
      e.color,
      3.0
    );
    unlockLore(e.bossData.id);
    unlockAchievement(`Slayer of ${e.bossData.name}`);
    if (state.activeBoss === e) state.activeBoss = null;
    if (p.flamesGathered >= 5 && state.gameMode === 'standard') openEndingModal(true);
  } else {
    addFeed('Mini-Boss Warden Slain! Fragments & Relic!', '#ff8c00');
  }

  const rRoll = e.role === 'major' && Math.random() < 0.4 ? 'mythic' : cfg.rarity;
  dropLoot(e.x, e.y, generateLootItem(p.level + state.worldTier * 2, rRoll, cfg.luck));
}

export function updateBossDeaths(dt) {
  tickBossVfx(dt);
  for (let i = bossDeaths.length - 1; i >= 0; i--) {
    const bd = bossDeaths[i];
    bd.t += dt;

    // Rhythmic multi-stage explosion pulses during collapse
    if (bd.nextPulse == null) bd.nextPulse = 0.2;
    if (bd.t >= bd.nextPulse) {
      bd.nextPulse += 0.24;
      const rx = bd.x + (Math.random() - 0.5) * bd.r * 1.4;
      const ry = bd.y + (Math.random() - 0.5) * bd.r * 1.4;
      arcs.push({ ring: { x: rx, y: ry, r: bd.r * 1.6 }, life: 0.24, color: bd.color });
      spawnParticles(rx, ry, '#ffffff', 6, 190);
      addShake(5);
    }

    if (Math.random() < 0.78) {
      spawnParticles(
        bd.x + (Math.random() - 0.5) * bd.r,
        bd.y + (Math.random() - 0.5) * bd.r,
        bd.color,
        2,
        235
      );
    }

    if (bd.t >= bd.dur) {
      // Finale explosion, energy release, screen tint & reward burst
      arcs.push({ ring: { x: bd.x, y: bd.y, r: bd.r * 4.2 }, life: 0.48, color: bd.color });
      spawnArenaFlash(bd.x, bd.y, bd.color, 580, 0.85, 0.30);
      spawnRewardBurst(bd.x, bd.y, bd.color, 22);
      spawnElementalImpact(bd.x, bd.y, resolveSpellElement(null, bd.color, true), bd.r * 2.4, true);
      spawnParticles(bd.x, bd.y, '#ffd700', 24, 300);
      addShake(14);
      bossDeaths.splice(i, 1);
    }
  }
}

export function renderBossDeaths(ctx) {
  renderSharedBossVfx(ctx);

  for (const bd of bossDeaths) {
    const pr = Math.min(1, bd.t / bd.dur);
    const tremor = Math.sin(pr * 70) * (4 * pr);

    ctx.save();
    ctx.globalAlpha = 1 - pr;
    drawBeam(ctx, bd.x, bd.y, 380 * (1 - pr * 0.25), bd.color);
    drawBeam(ctx, bd.x, bd.y, 260 * (1 - pr * 0.35), '#ffffff');
    drawRuneCircle(ctx, bd.x, bd.y, bd.r * (1.2 + pr * 2.2), bd.color, pr * 6);
    drawRing(ctx, bd.x, bd.y, bd.r * (1 + pr * 3.1), bd.color, 4.0);
    drawRing(ctx, bd.x, bd.y, bd.r * (0.6 + pr * 2.1), '#ffffff', 2.0);

    // Radiating light fracture rays during collapse
    ctx.strokeStyle = bd.color;
    ctx.lineWidth = 2.6;
    for (let k = 0; k < 8; k++) {
      const a = pr * 2.8 + (Math.PI * 2 * k) / 8;
      ctx.beginPath();
      ctx.moveTo(bd.x, bd.y);
      ctx.lineTo(bd.x + Math.cos(a) * bd.r * (0.8 + pr * 2.6), bd.y + Math.sin(a) * bd.r * (0.8 + pr * 2.6));
      ctx.stroke();
    }

    poly(ctx, bd.x + tremor, bd.y, (bd.r / 20) * (1 - pr * 0.35), SIL[bd.bossData.id] || SIL.godrick, '#ffffff', bd.color, 2);
    ctx.restore();
  }
}