export const OBSERVATORY_BIOME = {
  id: 'observatory',
  name: 'Celestial Observatory',
  bg: '#090b16',
  grid: '#181c36',
  fog: '#8fa8ff',
  particle: '#d4deff',
  faction: 'choir',
  musicHz: 73
};

export const CORRUPTED_VOID_BIOME = {
  id: 'void',
  name: 'Corrupted Void',
  bg: '#09060d',
  grid: '#1c1229',
  fog: '#9e47ff',
  particle: '#c780ff',
  faction: 'veiled',
  musicHz: 41
};