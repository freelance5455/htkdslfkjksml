import { CFG } from '../core/config.js';
import { pick, drawCircle, drawRing, drawDiamond } from '../core/utilities.js';
import { metaSave } from '../core/save.js';
import { sfx } from '../core/audio.js';
import { state, cracks, enemyPool, projPool, events, lootPool, hazards } from '../core/game.js';

import { FACTIONS } from '../data/bossData.js';
import { RARITIES } from '../data/items.js';
import { addFeed, showBanner } from '../ui/notifications.js';

import { DARK_FOREST_BIOME } from './darkForest.js';
import { FROZEN_WASTES_BIOME } from './frozenWastes.js';
import { ASHEN_CAPITAL_BIOME, INFERNAL_CHASM_BIOME } from './ashenCapital.js';
import { OBSERVATORY_BIOME, CORRUPTED_VOID_BIOME } from './voidRealms.js';
import { CATACOMBS_BIOME } from './catacombs.js';

export const BIOMES = [
  DARK_FOREST_BIOME,
  FROZEN_WASTES_BIOME,
  ASHEN_CAPITAL_BIOME,
  INFERNAL_CHASM_BIOME,
  OBSERVATORY_BIOME,
  CORRUPTED_VOID_BIOME,
  CATACOMBS_BIOME
];

// ============================================================================
// BIOME VISUAL & STORYTELLING CONFIGURATION
// ============================================================================

const BIOME_THEMES = {
  forest: {
    cosmic: false,
    sparse: false,
    weather: 'forest',
    ambientColor: '#457a59',
    accentColor: '#90c79e',
    roadColor: 'rgba(54, 46, 34, 0.30)',
    roadEdge: 'rgba(84, 108, 72, 0.22)',
    gradeTop: 'rgba(10, 32, 22, 0.16)',
    gradeBot: 'rgba(26, 52, 34, 0.10)',
    silhouetteColor: '#13241a',
    midColor: '#1b3324',
    landmarks: ['great_tree', 'broken_temple', 'ancient_graves', 'ancient_altar', 'collapsed_tower'],
    groundKinds: ['moss_bed', 'dead_grass', 'forest_loam', 'root_mat', 'stone_flag'],
    roleMap: {
      tree: ['gnarled_tree', 'dead_tree'],
      flora: ['dead_veg', 'roots', 'moss_patch'],
      ruin: ['fallen_statue', 'broken_pillar', 'ruined_wall'],
      wall: ['ruined_wall', 'roots'],
      grave: ['ancient_grave', 'fallen_statue'],
      statue: ['fallen_statue', 'shrine'],
      shrine: ['shrine', 'ancient_grave'],
      torch: ['moss_lantern', 'shrine'],
      debris: ['forest_floor', 'roots', 'dead_veg'],
      corpse: ['ancient_grave', 'bone_pile'],
      fog: ['fog_patch', 'moss_patch'],
      floor: ['forest_floor', 'moss_patch']
    }
  },
  frozen: {
    cosmic: false,
    sparse: false,
    weather: 'snow',
    ambientColor: '#5fa0db',
    accentColor: '#cce8ff',
    roadColor: 'rgba(136, 174, 212, 0.16)',
    roadEdge: 'rgba(195, 228, 255, 0.20)',
    gradeTop: 'rgba(18, 52, 104, 0.18)',
    gradeBot: 'rgba(135, 192, 240, 0.08)',
    silhouetteColor: '#132438',
    midColor: '#1c3552',
    landmarks: ['broken_bridge', 'collapsed_tower', 'ancient_altar', 'broken_temple', 'courtyard'],
    groundKinds: ['snow_buildup', 'ice_sheet', 'frozen_earth', 'stone_flag', 'cracked_earth'],
    roleMap: {
      tree: ['ice_pillar', 'frozen_ruin'],
      flora: ['ice_crack', 'snow_drift'],
      ruin: ['frozen_ruin', 'broken_bridge_seg', 'ancient_monument'],
      wall: ['frozen_ruin', 'ice_pillar'],
      grave: ['frozen_corpse', 'ancient_monument'],
      statue: ['ancient_monument', 'ice_pillar'],
      shrine: ['frost_shrine', 'ancient_monument'],
      torch: ['frost_shrine', 'ice_pillar'],
      debris: ['ice_crack', 'snow_drift', 'rubble'],
      corpse: ['frozen_corpse', 'bone_pile'],
      fog: ['snow_drift', 'ice_crack'],
      floor: ['snow_drift', 'ice_crack']
    }
  },
  capital: {
    cosmic: false,
    sparse: false,
    weather: 'ash',
    ambientColor: '#b08648',
    accentColor: '#f2c985',
    roadColor: 'rgba(88, 78, 92, 0.34)',
    roadEdge: 'rgba(148, 132, 152, 0.22)',
    gradeTop: 'rgba(46, 32, 20, 0.16)',
    gradeBot: 'rgba(96, 64, 30, 0.10)',
    silhouetteColor: '#211b24',
    midColor: '#302733',
    landmarks: ['courtyard', 'broken_temple', 'collapsed_tower', 'ancient_monument_plaza', 'broken_bridge'],
    groundKinds: ['stone_flag', 'ash_patch', 'cracked_earth', 'courtyard_tile', 'dead_grass'],
    roleMap: {
      tree: ['statue', 'broken_pillar'],
      flora: ['rubble', 'cracked_earth_prop'],
      ruin: ['collapsed_building', 'ruined_wall', 'broken_pillar'],
      wall: ['ruined_wall', 'collapsed_building'],
      grave: ['ancient_monument', 'statue'],
      statue: ['statue', 'ancient_monument'],
      shrine: ['brazier', 'shrine'],
      torch: ['brazier', 'torch'],
      debris: ['rubble', 'road', 'courtyard_tile'],
      corpse: ['bone_pile', 'rubble'],
      fog: ['ash_drift', 'rubble'],
      floor: ['road', 'courtyard_tile']
    }
  },
  infernal: {
    cosmic: false,
    sparse: false,
    weather: 'ash',
    ambientColor: '#c7322e',
    accentColor: '#ff8a47',
    roadColor: 'rgba(66, 34, 34, 0.34)',
    roadEdge: 'rgba(176, 62, 42, 0.24)',
    gradeTop: 'rgba(92, 14, 20, 0.20)',
    gradeBot: 'rgba(148, 44, 18, 0.12)',
    silhouetteColor: '#290d11',
    midColor: '#3d1319',
    landmarks: ['ritual_circle', 'collapsed_tower', 'broken_temple', 'courtyard', 'ancient_altar'],
    groundKinds: ['cracked_earth', 'ash_patch', 'scorched_slag', 'stone_flag'],
    roleMap: {
      tree: ['charred_spire', 'broken_pillar'],
      flora: ['ash_crater', 'cracked_earth_prop'],
      ruin: ['collapsed_building', 'ruined_wall', 'ancient_monument'],
      wall: ['ruined_wall', 'collapsed_building'],
      grave: ['bone_pile', 'ash_crater'],
      statue: ['statue', 'charred_spire'],
      shrine: ['brazier', 'ancient_monument'],
      torch: ['torch', 'brazier'],
      debris: ['rubble', 'ash_crater'],
      corpse: ['bone_pile', 'ash_crater'],
      fog: ['ash_drift', 'ash_crater'],
      floor: ['road', 'ash_crater']
    }
  },
  catacombs: {
    cosmic: false,
    sparse: false,
    weather: 'ash',
    ambientColor: '#9c7344',
    accentColor: '#ffbe73',
    roadColor: 'rgba(54, 46, 38, 0.36)',
    roadEdge: 'rgba(116, 98, 76, 0.24)',
    gradeTop: 'rgba(30, 22, 15, 0.20)',
    gradeBot: 'rgba(74, 52, 28, 0.11)',
    silhouetteColor: '#1a140f',
    midColor: '#261e16',
    landmarks: ['grand_crypt', 'collapsed_hallway', 'ritual_circle', 'ancient_graves', 'ancient_altar'],
    groundKinds: ['stone_flag', 'ossuary_dust', 'cracked_earth', 'courtyard_tile'],
    roleMap: {
      tree: ['pillar', 'tomb'],
      flora: ['bone_pile', 'ossuary_urn'],
      ruin: ['crypt_entrance', 'collapsed_hallway_seg', 'tomb'],
      wall: ['collapsed_hallway_seg', 'pillar'],
      grave: ['tomb', 'crypt_entrance'],
      statue: ['tomb', 'pillar'],
      shrine: ['ossuary_urn', 'torch'],
      torch: ['torch', 'brazier'],
      debris: ['bone_pile', 'stone_floor', 'ossuary_urn'],
      corpse: ['bone_pile', 'tomb'],
      fog: ['stone_floor', 'bone_pile'],
      floor: ['stone_floor', 'collapsed_hallway_seg']
    }
  },
  observatory: {
    cosmic: true,
    sparse: true,
    weather: 'void',
    ambientColor: '#6d8aff',
    accentColor: '#c9d7ff',
    roadColor: 'rgba(84, 110, 210, 0.14)',
    roadEdge: 'rgba(160, 184, 255, 0.18)',
    gradeTop: 'rgba(22, 34, 108, 0.18)',
    gradeBot: 'rgba(66, 86, 175, 0.10)',
    silhouetteColor: '#0e1330',
    midColor: '#171f4d',
    landmarks: ['impossible_monument', 'ritual_circle', 'broken_bridge'],
    groundKinds: ['astral_scar', 'void_scorch'],
    roleMap: {
      tree: ['cosmic_monolith'],
      flora: ['astral_fragment'],
      ruin: ['floating_ruin', 'astral_ring'],
      wall: ['cosmic_monolith'],
      grave: ['astral_ring'],
      statue: ['impossible_geo'],
      shrine: ['void_rift_prop'],
      torch: ['astral_fragment'],
      debris: ['astral_fragment', 'floating_ruin'],
      corpse: ['impossible_geo'],
      fog: ['astral_ring'],
      floor: ['floating_ruin']
    }
  },
  void: {
    cosmic: true,
    sparse: true,
    weather: 'void',
    ambientColor: '#9b4aff',
    accentColor: '#e0b3ff',
    roadColor: 'rgba(130, 56, 214, 0.14)',
    roadEdge: 'rgba(205, 138, 255, 0.20)',
    gradeTop: 'rgba(54, 12, 98, 0.22)',
    gradeBot: 'rgba(105, 32, 155, 0.12)',
    silhouetteColor: '#18082b',
    midColor: '#280e47',
    landmarks: ['impossible_monument', 'ritual_circle', 'ancient_altar'],
    groundKinds: ['void_scorch', 'astral_scar'],
    roleMap: {
      tree: ['cosmic_monolith'],
      flora: ['astral_fragment'],
      ruin: ['floating_ruin', 'void_rift_prop'],
      wall: ['impossible_geo'],
      grave: ['astral_ring'],
      statue: ['impossible_geo'],
      shrine: ['void_rift_prop'],
      torch: ['astral_fragment'],
      debris: ['astral_fragment', 'floating_ruin'],
      corpse: ['impossible_geo'],
      fog: ['void_rift_prop'],
      floor: ['floating_ruin']
    }
  }
};

const ALL_ROLES = [
  'tree', 'flora', 'ruin', 'wall', 'grave', 'statue',
  'shrine', 'torch', 'debris', 'corpse', 'fog', 'floor'
];

// ============================================================================
// WORLD DATA & SPATIAL HASHING (60 FPS O(VISIBLE) RENDERING)
// ============================================================================

const CELL_SIZE = 320;

let worldProps = [];
let worldLandmarks = [];
let worldGroundPatches = [];
let worldRoads = [];

let propGrid = new Map();
let groundGrid = new Map();
let landmarkGrid = new Map();
let roadGrid = new Map();

let renderStamp = 1;
let lastRunSeedTime = -1;
let lastLightTime = 0;
const timedLights = [];
const glowCache = new Map();

function cellKey(cx, cy) {
  return (cx << 12) ^ cy;
}

function insertPointToGrid(grid, item, x, y, radius = 0) {
  const minCx = Math.floor((x - radius) / CELL_SIZE);
  const maxCx = Math.floor((x + radius) / CELL_SIZE);
  const minCy = Math.floor((y - radius) / CELL_SIZE);
  const maxCy = Math.floor((y + radius) / CELL_SIZE);
  for (let cy = minCy; cy <= maxCy; cy++) {
    for (let cx = minCx; cx <= maxCx; cx++) {
      const k = cellKey(cx, cy);
      let arr = grid.get(k);
      if (!arr) {
        arr = [];
        grid.set(k, arr);
      }
      arr.push(item);
    }
  }
}

function forEachInGrid(grid, minX, minY, maxX, maxY, fn) {
  const c0x = Math.floor(minX / CELL_SIZE);
  const c1x = Math.floor(maxX / CELL_SIZE);
  const c0y = Math.floor(minY / CELL_SIZE);
  const c1y = Math.floor(maxY / CELL_SIZE);
  const stamp = ++renderStamp;

  for (let cy = c0y; cy <= c1y; cy++) {
    for (let cx = c0x; cx <= c1x; cx++) {
      const arr = grid.get(cellKey(cx, cy));
      if (!arr) continue;
      for (let i = 0; i < arr.length; i++) {
        const item = arr[i];
        if (item._stamp === stamp) continue;
        item._stamp = stamp;
        fn(item);
      }
    }
  }
}

// ============================================================================
// LIGHTING UTILITIES
// ============================================================================

function normalizeHexAlpha(hex, alphaHex) {
  if (typeof hex !== 'string') return '#ffffff' + alphaHex;
  if (hex.startsWith('#')) {
    if (hex.length === 4) {
      const r = hex[1], g = hex[2], b = hex[3];
      return `#${r}${r}${g}${g}${b}${b}${alphaHex}`;
    }
    if (hex.length === 7) return hex + alphaHex;
    if (hex.length === 9) return hex.slice(0, 7) + alphaHex;
  }
  return hex;
}

function getGlowStamp(color) {
  if (glowCache.has(color)) return glowCache.get(color);
  const off = document.createElement('canvas');
  off.width = off.height = 128;
  const octx = off.getContext('2d');
  const g = octx.createRadialGradient(64, 64, 2, 64, 64, 64);
  g.addColorStop(0, color);
  g.addColorStop(0.30, normalizeHexAlpha(color, '88'));
  g.addColorStop(0.65, normalizeHexAlpha(color, '26'));
  g.addColorStop(1, 'rgba(0,0,0,0)');
  octx.fillStyle = g;
  octx.fillRect(0, 0, 128, 128);
  glowCache.set(color, off);
  return off;
}

export function emitLight(
  ctx,
  x,
  y,
  radius,
  color,
  alpha = 0.25,
  inView = null,
  budget = null,
  coreColor = null,
  coreScale = 0.42
) {
  if (budget && budget.left <= 0) return false;
  if (inView && !inView(x, y, radius)) return false;
  if (budget) budget.left--;

  ctx.globalAlpha = alpha;
  ctx.drawImage(getGlowStamp(color), x - radius, y - radius, radius * 2, radius * 2);

  if (coreColor && (!budget || budget.left > 0)) {
    const cr = radius * coreScale;
    ctx.globalAlpha = Math.min(0.6, alpha * 1.18);
    ctx.drawImage(getGlowStamp(coreColor), x - cr, y - cr, cr * 2, cr * 2);
  }
  return true;
}

export function timedLight(x, y, radius, color, alpha = 0.35, life = 0.25, coreColor = null) {
  if (timedLights.length >= 22) timedLights.shift();
  timedLights.push({ x, y, radius, color, coreColor, alpha, life, maxLife: life });
}

export const emitTimedLight = timedLight;

// ============================================================================
// DRAWING PRIMITIVES
// ============================================================================

function drawGroundShadow(ctx, x, y, rx, ry = rx * 0.44, alpha = 0.42) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = '#040307';
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, 6.283);
  ctx.fill();
  ctx.restore();
}

function drawStoneRect(ctx, x, y, w, h, fill, stroke, lw = 1.4) {
  ctx.fillStyle = fill;
  ctx.fillRect(x, y, w, h);
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = lw;
    ctx.strokeRect(x, y, w, h);
  }
}

function drawBrokenPillar(ctx, x, y, w, h, fill, stroke, cap = '#7c8594') {
  drawGroundShadow(ctx, x, y + h * 0.42, w * 0.9, w * 0.4);
  drawStoneRect(ctx, x - w * 0.5, y - h * 0.65, w, h, fill, stroke);
  ctx.fillStyle = cap;
  ctx.beginPath();
  ctx.moveTo(x - w * 0.5, y - h * 0.65);
  ctx.lineTo(x - w * 0.1, y - h * 0.78);
  ctx.lineTo(x + w * 0.25, y - h * 0.58);
  ctx.lineTo(x + w * 0.5, y - h * 0.65);
  ctx.lineTo(x + w * 0.5, y - h * 0.48);
  ctx.lineTo(x - w * 0.5, y - h * 0.48);
  ctx.closePath();
  ctx.fill();
}

// ============================================================================
// CLUSTER TEMPLATES & WORLD GENERATION (250-300% DENSITY WITH CLEAR LANES)
// ============================================================================

const CLUSTER_TEMPLATES = [
  {
    id: 'shrine_graves',
    sparse: true,
    items: [
      { role: 'shrine', dx: 0, dy: 0, s: 1.08 },
      { role: 'grave', dx: -34, dy: 14, s: 0.95 },
      { role: 'grave', dx: 34, dy: 12, s: 0.92 },
      { role: 'grave', dx: -16, dy: -28, s: 0.88 },
      { role: 'torch', dx: 22, dy: -18, s: 0.95 },
      { role: 'flora', dx: 6, dy: 26, s: 1.0 }
    ]
  },
  {
    id: 'wall_rubble',
    sparse: false,
    items: [
      { role: 'wall', dx: 0, dy: -6, s: 1.05 },
      { role: 'ruin', dx: 42, dy: 8, s: 0.95 },
      { role: 'debris', dx: -24, dy: 18, s: 1.05 },
      { role: 'debris', dx: 18, dy: 24, s: 0.9 },
      { role: 'statue', dx: -38, dy: -12, s: 0.9 }
    ]
  },
  {
    id: 'crypt_torches',
    sparse: false,
    items: [
      { role: 'ruin', dx: 0, dy: -4, s: 1.1 },
      { role: 'torch', dx: -30, dy: 12, s: 1.0 },
      { role: 'torch', dx: 30, dy: 12, s: 1.0 },
      { role: 'corpse', dx: -12, dy: 28, s: 0.95 },
      { role: 'floor', dx: 0, dy: 16, s: 1.1 }
    ]
  },
  {
    id: 'statue_roots',
    sparse: true,
    items: [
      { role: 'statue', dx: 0, dy: 0, s: 1.1 },
      { role: 'flora', dx: -20, dy: 14, s: 1.05 },
      { role: 'flora', dx: 22, dy: 12, s: 0.95 },
      { role: 'debris', dx: 4, dy: -24, s: 0.9 }
    ]
  },
  {
    id: 'wild_thicket',
    sparse: false,
    items: [
      { role: 'tree', dx: -22, dy: -14, s: 1.12 },
      { role: 'tree', dx: 26, dy: 6, s: 0.96 },
      { role: 'tree', dx: -4, dy: 28, s: 0.88 },
      { role: 'flora', dx: 14, dy: -20, s: 1.05 },
      { role: 'fog', dx: 0, dy: 8, s: 1.15 }
    ]
  },
  {
    id: 'fallen_camp',
    sparse: false,
    items: [
      { role: 'corpse', dx: -10, dy: 4, s: 1.0 },
      { role: 'torch', dx: 20, dy: -8, s: 0.95 },
      { role: 'debris', dx: -26, dy: -14, s: 1.0 },
      { role: 'grave', dx: 28, dy: 20, s: 0.92 }
    ]
  },
  {
    id: 'courtyard_ruin',
    sparse: true,
    items: [
      { role: 'floor', dx: 0, dy: 0, s: 1.2 },
      { role: 'wall', dx: -36, dy: -18, s: 0.95 },
      { role: 'ruin', dx: 36, dy: -16, s: 0.95 },
      { role: 'debris', dx: 10, dy: 26, s: 0.9 }
    ]
  }
];

function pointDistSq(ax, ay, bx, by) {
  const dx = ax - bx;
  const dy = ay - by;
  return dx * dx + dy * dy;
}

function pointToSegmentDistSq(px, py, ax, ay, bx, by) {
  const vx = bx - ax;
  const vy = by - ay;
  const lenSq = vx * vx + vy * vy;
  if (lenSq < 1) return pointDistSq(px, py, ax, ay);
  let t = ((px - ax) * vx + (py - ay) * vy) / lenSq;
  if (t < 0) t = 0;
  else if (t > 1) t = 1;
  const cx = ax + t * vx;
  const cy = ay + t * vy;
  return pointDistSq(px, py, cx, cy);
}

function isNearRoad(x, y, marginSq) {
  for (let i = 0; i < worldRoads.length; i++) {
    const r = worldRoads[i];
    if (pointToSegmentDistSq(x, y, r.x1, r.y1, r.x2, r.y2) < marginSq) return true;
  }
  return false;
}

function isNearLandmark(x, y, pad = 135) {
  for (let i = 0; i < worldLandmarks.length; i++) {
    const lm = worldLandmarks[i];
    const r = lm.r + pad;
    if (pointDistSq(x, y, lm.x, lm.y) < r * r) return true;
  }
  return false;
}

function generateLandmarks() {
  worldLandmarks.length = 0;
  landmarkGrid.clear();

  const W = CFG.game.W;
  const H = CFG.game.H;
  const count = 20;
  const minDistSq = 430 * 430;
  const centerX = W * 0.5;
  const centerY = H * 0.5;

  let attempts = 0;
  while (worldLandmarks.length < count && attempts < 450) {
    attempts++;
    const x = 220 + Math.random() * (W - 440);
    const y = 220 + Math.random() * (H - 440);

    // Keep immediate spawn center open for player orientation
    if (pointDistSq(x, y, centerX, centerY) < 220 * 220) continue;

    let ok = true;
    for (let i = 0; i < worldLandmarks.length; i++) {
      if (pointDistSq(x, y, worldLandmarks[i].x, worldLandmarks[i].y) < minDistSq) {
        ok = false;
        break;
      }
    }
    if (!ok) continue;

    const lm = {
      x,
      y,
      r: 120 + Math.random() * 48,
      slot: worldLandmarks.length,
      rot: (Math.random() - 0.5) * 0.7,
      seed: Math.random() * 25,
      _stamp: 0
    };
    worldLandmarks.push(lm);
    insertPointToGrid(landmarkGrid, lm, lm.x, lm.y, lm.r + 35);
  }
}

function generateRoads() {
  worldRoads.length = 0;
  roadGrid.clear();

  if (worldLandmarks.length < 2) return;

  const connected = new Set();
  const addEdge = (a, b) => {
    const key = a < b ? `${a}_${b}` : `${b}_${a}`;
    if (connected.has(key)) return;
    connected.add(key);

    const la = worldLandmarks[a];
    const lb = worldLandmarks[b];
    const mx = (la.x + lb.x) * 0.5 + (Math.random() - 0.5) * 140;
    const my = (la.y + lb.y) * 0.5 + (Math.random() - 0.5) * 140;

    const segs = [
      { x1: la.x, y1: la.y, x2: mx, y2: my, w: 42 + Math.random() * 14, seed: Math.random() * 10, _stamp: 0 },
      { x1: mx, y1: my, x2: lb.x, y2: lb.y, w: 42 + Math.random() * 14, seed: Math.random() * 10, _stamp: 0 }
    ];
    for (const seg of segs) {
      worldRoads.push(seg);
      const cx = (seg.x1 + seg.x2) * 0.5;
      const cy = (seg.y1 + seg.y2) * 0.5;
      const rad = Math.hypot(seg.x2 - seg.x1, seg.y2 - seg.y1) * 0.5 + 48;
      insertPointToGrid(roadGrid, seg, cx, cy, rad);
    }
  };

  // Connect each landmark to its 1-2 nearest neighbors to form ruined road networks
  for (let i = 0; i < worldLandmarks.length; i++) {
    let best1 = -1, best2 = -1;
    let d1 = Infinity, d2 = Infinity;
    for (let j = 0; j < worldLandmarks.length; j++) {
      if (i === j) continue;
      const d = pointDistSq(worldLandmarks[i].x, worldLandmarks[i].y, worldLandmarks[j].x, worldLandmarks[j].y);
      if (d < d1) {
        d2 = d1; best2 = best1;
        d1 = d; best1 = j;
      } else if (d < d2) {
        d2 = d; best2 = j;
      }
    }
    if (best1 !== -1) addEdge(i, best1);
    if (best2 !== -1 && i % 2 === 0) addEdge(i, best2);
  }
}

function generateGroundPatches() {
  worldGroundPatches.length = 0;
  groundGrid.clear();

  const W = CFG.game.W;
  const H = CFG.game.H;
  for (let i = 0; i < 360; i++) {
    const gp = {
      x: 60 + Math.random() * (W - 120),
      y: 60 + Math.random() * (H - 120),
      rx: 46 + Math.random() * 88,
      ry: 28 + Math.random() * 54,
      rot: Math.random() * 6.283,
      slot: i,
      seed: Math.random() * 15,
      sparse: i % 4 !== 0,
      _stamp: 0
    };
    worldGroundPatches.push(gp);
    insertPointToGrid(groundGrid, gp, gp.x, gp.y, gp.rx + 12);
  }
}

export function generateWorldProps(target = worldProps) {
  target.length = 0;
  timedLights.length = 0;
  lastLightTime = 0;

  const isMain = target === worldProps;
  if (isMain) {
    propGrid.clear();
    generateLandmarks();
    generateRoads();
    generateGroundPatches();
  }

  const W = CFG.game.W;
  const H = CFG.game.H;

  const pushProp = (x, y, role, s, rot, seed, sparseKeep, idx) => {
    const prop = {
      x,
      y,
      role,
      kind: role, // kept for compatibility with external inspection
      s,
      rot,
      seed,
      sparseKeep,
      idx,
      _stamp: 0
    };
    target.push(prop);
    if (isMain) insertPointToGrid(propGrid, prop, x, y, 56 * s);
  };

  let propCounter = 0;

  // 1) Perimeter environmental storytelling clusters around every Landmark
  if (isMain) {
    for (let l = 0; l < worldLandmarks.length; l++) {
      const lm = worldLandmarks[l];
      const ringCount = 5 + (l % 3);
      for (let k = 0; k < ringCount; k++) {
        const a = (k / ringCount) * Math.PI * 2 + (Math.random() - 0.5) * 0.45;
        const dist = lm.r + 36 + Math.random() * 56;
        const px = lm.x + Math.cos(a) * dist;
        const py = lm.y + Math.sin(a) * dist;
        if (px < 60 || px > W - 60 || py < 60 || py > H - 60) continue;

        const tpl = CLUSTER_TEMPLATES[(l + k) % CLUSTER_TEMPLATES.length];
        for (let m = 0; m < tpl.items.length; m++) {
          const it = tpl.items[m];
          const jx = px + it.dx + (Math.random() - 0.5) * 14;
          const jy = py + it.dy + (Math.random() - 0.5) * 14;
          if (jx < 55 || jx > W - 55 || jy < 55 || jy > H - 55) continue;
          pushProp(
            jx,
            jy,
            it.role,
            it.s * (0.85 + Math.random() * 0.34),
            Math.random() * 6.283,
            Math.random() * 18,
            tpl.sparse && m < 2,
            propCounter++
          );
        }
      }
    }
  }

  // 2) Open-world environmental clusters (avoiding road corridors & landmark cores)
  const clusterCount = 135;
  let spawnedClusters = 0;
  let tries = 0;

  while (spawnedClusters < clusterCount && tries < 600) {
    tries++;
    const cx = 90 + Math.random() * (W - 180);
    const cy = 90 + Math.random() * (H - 180);

    if (isMain) {
      if (isNearLandmark(cx, cy, 70)) continue;
      if (isNearRoad(cx, cy, 42 * 42)) continue;
    }

    const tpl = pick(CLUSTER_TEMPLATES);
    const rotBase = Math.random() * 6.283;
    const cosR = Math.cos(rotBase);
    const sinR = Math.sin(rotBase);

    for (let m = 0; m < tpl.items.length; m++) {
      const it = tpl.items[m];
      const rx = it.dx * cosR - it.dy * sinR;
      const ry = it.dx * sinR + it.dy * cosR;
      const px = cx + rx + (Math.random() - 0.5) * 10;
      const py = cy + ry + (Math.random() - 0.5) * 10;
      if (px < 55 || px > W - 55 || py < 55 || py > H - 55) continue;
      if (isMain && isNearRoad(px, py, 26 * 26)) continue;

      pushProp(
        px,
        py,
        it.role,
        it.s * (0.82 + Math.random() * 0.4),
        Math.random() * 6.283,
        Math.random() * 18,
        tpl.sparse && m === 0 && spawnedClusters % 3 === 0,
        propCounter++
      );
    }
    spawnedClusters++;
  }

  // 3) Roadside milestones (torches, broken statues, rubble flanking ancient roads)
  if (isMain) {
    for (let r = 0; r < worldRoads.length; r++) {
      const seg = worldRoads[r];
      const len = Math.hypot(seg.x2 - seg.x1, seg.y2 - seg.y1);
      const steps = Math.max(1, Math.floor(len / 260));
      const nx = -(seg.y2 - seg.y1) / Math.max(1, len);
      const ny = (seg.x2 - seg.x1) / Math.max(1, len);

      for (let s = 1; s <= steps; s++) {
        const f = s / (steps + 1);
        const side = (r + s) % 2 === 0 ? 1 : -1;
        const offset = (seg.w * 0.72 + 16) * side;
        const px = seg.x1 + (seg.x2 - seg.x1) * f + nx * offset;
        const py = seg.y1 + (seg.y2 - seg.y1) * f + ny * offset;
        if (isNearLandmark(px, py, 35)) continue;
        const role = s % 2 === 0 ? 'torch' : 'statue';
        pushProp(px, py, role, 0.95 + Math.random() * 0.25, Math.random() * 6.283, Math.random() * 14, true, propCounter++);
      }
    }
  }

  return target;
}

function ensureWorldProps() {
  if (!worldProps.length || state.time < lastRunSeedTime) {
    generateWorldProps(worldProps);
  }
  lastRunSeedTime = state.time;
}

// ============================================================================
// REUSABLE PROP DRAWERS
// ============================================================================

const PROP_DRAWERS = {
  // --- DARK FOREST ---
  dead_tree: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 8, 19 * p.s);
    c.strokeStyle = '#2d231c';
    c.lineWidth = 4.8 * p.s;
    c.beginPath();
    c.moveTo(p.x, p.y + 8);
    c.lineTo(p.x - 2 * p.s, p.y - 24 * p.s);
    c.stroke();
    c.lineWidth = 2.2 * p.s;
    c.beginPath();
    c.moveTo(p.x - 1, p.y - 11 * p.s);
    c.lineTo(p.x - 17 * p.s, p.y - 23 * p.s);
    c.moveTo(p.x - 2, p.y - 17 * p.s);
    c.lineTo(p.x + 15 * p.s, p.y - 29 * p.s);
    c.moveTo(p.x - 10 * p.s, p.y - 18 * p.s);
    c.lineTo(p.x - 20 * p.s, p.y - 12 * p.s);
    c.stroke();
    drawCircle(c, p.x - 16 * p.s, p.y - 22 * p.s, 3.5 * p.s, '#3c594466');
  },
  gnarled_tree: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 10, 24 * p.s, 11 * p.s);
    c.strokeStyle = '#261e18';
    c.lineWidth = 6 * p.s;
    c.beginPath();
    c.moveTo(p.x - 6 * p.s, p.y + 9);
    c.quadraticCurveTo(p.x - 8 * p.s, p.y - 12 * p.s, p.x + 3 * p.s, p.y - 28 * p.s);
    c.stroke();
    c.strokeStyle = '#382c22';
    c.lineWidth = 2.6 * p.s;
    c.beginPath();
    c.moveTo(p.x - 1, p.y - 16 * p.s);
    c.lineTo(p.x - 18 * p.s, p.y - 28 * p.s);
    c.moveTo(p.x + 2, p.y - 22 * p.s);
    c.lineTo(p.x + 19 * p.s, p.y - 31 * p.s);
    c.stroke();
    drawCircle(c, p.x - 13 * p.s, p.y - 28 * p.s, 11 * p.s, '#1f3a29');
    drawCircle(c, p.x + 11 * p.s, p.y - 30 * p.s, 10 * p.s, '#2a4a33');
    drawCircle(c, p.x, p.y - 34 * p.s, 13 * p.s, '#1b3324');
    // moonlit highlights give the canopy volume
    drawCircle(c, p.x - 3 * p.s, p.y - 38 * p.s, 6 * p.s, '#4a7d5788');
    drawCircle(c, p.x + 9 * p.s, p.y - 33 * p.s, 4 * p.s, '#6a9f7266');
  },
  roots: (c, p) => {
    c.strokeStyle = 'rgba(52, 38, 27, 0.7)';
    c.lineWidth = 2.2;
    c.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = p.rot + i * 1.25;
      c.moveTo(p.x, p.y);
      c.quadraticCurveTo(
        p.x + Math.cos(a + 0.3) * 14 * p.s,
        p.y + Math.sin(a + 0.3) * 14 * p.s,
        p.x + Math.cos(a) * 28 * p.s,
        p.y + Math.sin(a) * 28 * p.s
      );
    }
    c.stroke();
  },
  dead_veg: (c, p) => {
    c.strokeStyle = '#4e5938';
    c.lineWidth = 1.6;
    c.beginPath();
    for (let i = -2; i <= 2; i++) {
      c.moveTo(p.x + i * 3 * p.s, p.y + 4);
      c.lineTo(p.x + i * 5 * p.s + Math.sin(p.seed + i) * 3, p.y - (7 + (i % 2) * 3) * p.s);
    }
    c.stroke();
  },
  moss_patch: (c, p) => {
    drawCircle(c, p.x, p.y, 16 * p.s, 'rgba(42, 74, 48, 0.28)');
    drawCircle(c, p.x + 9 * p.s, p.y - 4 * p.s, 10 * p.s, 'rgba(66, 104, 62, 0.24)');
  },
  moss_lantern: (c, p, b, t) => {
    drawGroundShadow(c, p.x, p.y + 6, 9 * p.s);
    drawStoneRect(c, p.x - 4, p.y - 11, 8, 15, '#2b332d', '#4f5e53');
    drawCircle(c, p.x, p.y - 8, 3.2 + Math.sin(t * 5 + p.seed) * 0.7, '#8dffba', '#e3ffef', 1);
  },
  shrine: (c, p, b, t) => {
    drawGroundShadow(c, p.x, p.y + 8, 17 * p.s);
    drawStoneRect(c, p.x - 13, p.y - 6, 26, 14, '#2c3138', '#4b5563');
    drawStoneRect(c, p.x - 7, p.y - 16, 14, 12, '#373e48', '#5c6675');
    drawCircle(c, p.x, p.y - 17, 4.6 + Math.sin(t * 4 + p.seed) * 1.1, b.fog, '#d9ecff', 1.2);
  },
  fog_patch: (c, p, b, t) => {
    const drift = Math.sin(t * 0.65 + p.seed) * 12;
    drawCircle(c, p.x + drift, p.y, 46 * p.s, b.fog + '16');
    drawCircle(c, p.x - drift * 0.5 + 14, p.y + 6, 32 * p.s, b.fog + '10');
  },
  fallen_statue: (c, p) => {
    c.save();
    c.translate(p.x, p.y);
    c.rotate(p.rot);
    drawGroundShadow(c, 0, 5, 22 * p.s, 9 * p.s);
    drawStoneRect(c, -18 * p.s, -7 * p.s, 34 * p.s, 14 * p.s, '#373b3a', '#535c56');
    drawCircle(c, -18 * p.s, 0, 7 * p.s, '#444b48', '#66736b', 1.2);
    c.restore();
  },
  ancient_grave: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 7, 13 * p.s, 6 * p.s);
    c.fillStyle = '#242924';
    c.fillRect(p.x - 9 * p.s, p.y + 1, 18 * p.s, 8 * p.s);
    drawStoneRect(c, p.x - 6 * p.s, p.y - 13 * p.s, 12 * p.s, 15 * p.s, '#383d39', '#616b62');
    c.strokeStyle = '#535e54';
    c.lineWidth = 1.4;
    c.beginPath();
    c.moveTo(p.x, p.y - 10 * p.s);
    c.lineTo(p.x, p.y - 2 * p.s);
    c.moveTo(p.x - 3 * p.s, p.y - 7 * p.s);
    c.lineTo(p.x + 3 * p.s, p.y - 7 * p.s);
    c.stroke();
  },
  forest_floor: (c, p) => {
    drawCircle(c, p.x, p.y, 14 * p.s, '#192a1f55');
    c.fillStyle = '#3c543e88';
    for (let i = 0; i < 4; i++) {
      const a = p.rot + i * 1.6;
      c.fillRect(p.x + Math.cos(a) * 10 * p.s, p.y + Math.sin(a) * 8 * p.s, 4, 2.5);
    }
  },

  // --- FROZEN WASTES ---
  snow_drift: (c, p) => {
    c.save();
    c.fillStyle = 'rgba(217, 236, 255, 0.14)';
    c.beginPath();
    c.ellipse(p.x, p.y, 40 * p.s, 16 * p.s, p.rot * 0.3, 0, 6.283);
    c.fill();
    c.fillStyle = 'rgba(255, 255, 255, 0.08)';
    c.beginPath();
    c.ellipse(p.x - 6, p.y - 3, 24 * p.s, 8 * p.s, p.rot * 0.3, 0, 6.283);
    c.fill();
    c.restore();
  },
  ice_crack: (c, p) => {
    c.strokeStyle = '#7eb8eb77';
    c.lineWidth = 1.7;
    c.beginPath();
    c.moveTo(p.x - 24 * p.s, p.y - 4);
    c.lineTo(p.x - 4, p.y + 7 * p.s);
    c.lineTo(p.x + 22 * p.s, p.y - 7 * p.s);
    c.moveTo(p.x - 4, p.y + 7 * p.s);
    c.lineTo(p.x + 8 * p.s, p.y + 18 * p.s);
    c.stroke();
  },
  ice_pillar: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 8, 15 * p.s);
    c.fillStyle = '#31577d';
    c.strokeStyle = '#bce2ff';
    c.lineWidth = 1.4;
    c.beginPath();
    c.moveTo(p.x, p.y - 28 * p.s);
    c.lineTo(p.x + 12 * p.s, p.y - 5 * p.s);
    c.lineTo(p.x + 9 * p.s, p.y + 8 * p.s);
    c.lineTo(p.x - 9 * p.s, p.y + 8 * p.s);
    c.lineTo(p.x - 12 * p.s, p.y - 5 * p.s);
    c.closePath();
    c.fill();
    c.stroke();
  },
  frozen_ruin: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 9, 25 * p.s);
    drawStoneRect(c, p.x - 19 * p.s, p.y - 15 * p.s, 12 * p.s, 25 * p.s, '#263445', '#6c8cad');
    drawStoneRect(c, p.x + 7 * p.s, p.y - 7 * p.s, 12 * p.s, 17 * p.s, '#263445', '#6c8cad');
    drawStoneRect(c, p.x - 21 * p.s, p.y - 16 * p.s, 16 * p.s, 5, '#cfe7ff66');
  },
  frozen_corpse: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 5, 13 * p.s, 6 * p.s);
    c.save();
    c.translate(p.x, p.y);
    c.rotate(p.rot * 0.4);
    c.fillStyle = '#536f8c';
    c.fillRect(-10 * p.s, -4 * p.s, 16 * p.s, 8 * p.s);
    drawCircle(c, -11 * p.s, 0, 4.5 * p.s, '#89accf', '#d5ecff', 1);
    c.fillStyle = 'rgba(180, 224, 255, 0.35)';
    c.fillRect(-15 * p.s, -6 * p.s, 24 * p.s, 11 * p.s);
    c.restore();
  },
  broken_bridge_seg: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 9, 26 * p.s, 10 * p.s);
    drawStoneRect(c, p.x - 24 * p.s, p.y - 8 * p.s, 48 * p.s, 16 * p.s, '#283647', '#6c8eb0');
    drawStoneRect(c, p.x - 24 * p.s, p.y - 10 * p.s, 48 * p.s, 3, '#cde6ff55');
  },
  frost_shrine: (c, p, b, t) => {
    drawGroundShadow(c, p.x, p.y + 8, 16 * p.s);
    drawStoneRect(c, p.x - 11, p.y - 5, 22, 13, '#25364a', '#6b91b5');
    drawDiamond(c, p.x, p.y - 14, 7 + Math.sin(t * 3 + p.seed) * 1.2, '#7bc4ff', '#e8f5ff', 1.2);
  },
  ancient_monument: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 10, 16 * p.s, 8 * p.s);
    drawStoneRect(c, p.x - 12 * p.s, p.y - 2, 24 * p.s, 11 * p.s, '#2c2f3b', '#5d677a');
    c.fillStyle = '#3c4352';
    c.strokeStyle = '#8091ab';
    c.lineWidth = 1.3;
    c.beginPath();
    c.moveTo(p.x - 6 * p.s, p.y - 2);
    c.lineTo(p.x - 4 * p.s, p.y - 28 * p.s);
    c.lineTo(p.x, p.y - 34 * p.s);
    c.lineTo(p.x + 4 * p.s, p.y - 28 * p.s);
    c.lineTo(p.x + 6 * p.s, p.y - 2);
    c.closePath();
    c.fill();
    c.stroke();
  },

  // --- ASHEN CAPITAL & INFERNAL ---
  road: (c, p) => {
    c.save();
    c.translate(p.x, p.y);
    c.rotate((p.rot * 0.25) % 1.2);
    c.fillStyle = 'rgba(72, 65, 78, 0.25)';
    c.fillRect(-40 * p.s, -14, 80 * p.s, 28);
    c.fillStyle = 'rgba(130, 118, 138, 0.16)';
    for (let i = -2; i <= 2; i++) {
      c.fillRect(i * 15 * p.s - 5, (i % 2) * 8 - 8, 11, 7);
    }
    c.restore();
  },
  courtyard_tile: (c, p) => {
    c.save();
    c.translate(p.x, p.y);
    c.fillStyle = 'rgba(62, 56, 68, 0.24)';
    c.fillRect(-28 * p.s, -22 * p.s, 56 * p.s, 44 * p.s);
    c.strokeStyle = 'rgba(128, 112, 134, 0.22)';
    c.lineWidth = 1;
    c.strokeRect(-26 * p.s, -20 * p.s, 24 * p.s, 18 * p.s);
    c.strokeRect(2 * p.s, -20 * p.s, 24 * p.s, 18 * p.s);
    c.strokeRect(-26 * p.s, 2 * p.s, 24 * p.s, 18 * p.s);
    c.restore();
  },
  rubble: (c, p) => {
    c.fillStyle = '#3b3442';
    for (let i = 0; i < 6; i++) {
      c.fillRect(p.x + (i - 2.5) * 7, p.y + ((i % 2) - 0.5) * 10, 6.5 * p.s, 5 * p.s);
    }
  },
  ruined_wall: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 7, 36 * p.s, 7);
    drawStoneRect(c, p.x - 34 * p.s, p.y - 6, 27 * p.s, 12, '#2d2734', '#50465c');
    drawStoneRect(c, p.x + 5 * p.s, p.y - 6, 29 * p.s, 12, '#2d2734', '#50465c');
  },
  collapsed_building: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 12, 32 * p.s, 14 * p.s);
    drawStoneRect(c, p.x - 26 * p.s, p.y - 20 * p.s, 52 * p.s, 40 * p.s, '#191620', '#4a4054');
    c.strokeStyle = '#3f3548';
    c.lineWidth = 3;
    c.beginPath();
    c.moveTo(p.x - 22 * p.s, p.y - 12 * p.s);
    c.lineTo(p.x + 18 * p.s, p.y + 14 * p.s);
    c.stroke();
  },
  statue: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 8, 14 * p.s);
    drawStoneRect(c, p.x - 10, p.y - 4, 20, 12, '#302b36', '#5c5266');
    drawStoneRect(c, p.x - 5, p.y - 21 * p.s, 10, 18 * p.s, '#443d4d', '#736780');
    drawCircle(c, p.x, p.y - 24 * p.s, 4.5, '#585063');
  },
  broken_pillar: (c, p) => {
    drawBrokenPillar(c, p.x, p.y, 12 * p.s, 22 * p.s, '#2f2936', '#5e526b', '#7a6c8a');
  },
  brazier: (c, p, b, t) => {
    drawGroundShadow(c, p.x, p.y + 7, 12 * p.s, 6 * p.s);
    drawStoneRect(c, p.x - 8, p.y - 4, 16, 10, '#2a2224', '#634f46');
    drawCircle(c, p.x, p.y - 7, 5.4 + Math.sin(t * 11 + p.seed) * 1.4, '#ff7329', '#ffe194', 1.2);
  },
  ash_drift: (c, p) => {
    drawCircle(c, p.x, p.y, 26 * p.s, 'rgba(92, 82, 86, 0.16)');
    drawCircle(c, p.x + 12 * p.s, p.y + 4, 16 * p.s, 'rgba(130, 114, 118, 0.12)');
  },
  ash_crater: (c, p) => {
    drawCircle(c, p.x, p.y, 18 * p.s, 'rgba(18, 8, 10, 0.55)', 'rgba(145, 42, 28, 0.45)', 1.5);
    drawCircle(c, p.x, p.y, 8 * p.s, 'rgba(255, 86, 36, 0.22)');
  },
  charred_spire: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 8, 15 * p.s);
    c.fillStyle = '#1b0f12';
    c.strokeStyle = '#6e2528';
    c.lineWidth = 1.4;
    c.beginPath();
    c.moveTo(p.x - 9 * p.s, p.y + 6);
    c.lineTo(p.x - 2 * p.s, p.y - 28 * p.s);
    c.lineTo(p.x + 8 * p.s, p.y + 6);
    c.closePath();
    c.fill();
    c.stroke();
  },
  cracked_earth_prop: (c, p) => {
    c.strokeStyle = 'rgba(20, 14, 16, 0.72)';
    c.lineWidth = 1.8;
    c.beginPath();
    c.moveTo(p.x - 18 * p.s, p.y - 5);
    c.lineTo(p.x, p.y + 4);
    c.lineTo(p.x + 19 * p.s, p.y - 6);
    c.moveTo(p.x, p.y + 4);
    c.lineTo(p.x + 5 * p.s, p.y + 17 * p.s);
    c.stroke();
  },

  // --- CATACOMBS ---
  tomb: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 10, 18 * p.s, 9 * p.s);
    drawStoneRect(c, p.x - 13 * p.s, p.y - 18 * p.s, 26 * p.s, 36 * p.s, '#25211d', '#5c5042');
    c.strokeStyle = '#12100e';
    c.lineWidth = 1.5;
    c.beginPath();
    c.moveTo(p.x - 8 * p.s, p.y - 6);
    c.lineTo(p.x + 8 * p.s, p.y + 6);
    c.stroke();
  },
  torch: (c, p, b, t) => {
    c.fillStyle = '#3a2b1d';
    c.fillRect(p.x - 2, p.y - 8, 4, 15);
    drawCircle(c, p.x, p.y - 10, 4.9 + Math.sin(t * 10 + p.seed) * 1.4, '#ff9848', '#ffe3a3', 1);
  },
  pillar: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 7, 13 * p.s);
    drawCircle(c, p.x, p.y, 10.5 * p.s, '#2d2833', '#5f566b', 1.6);
    drawRing(c, p.x, p.y, 6 * p.s, '#484052', 1);
  },
  bone_pile: (c, p) => {
    c.strokeStyle = '#d0c8b8';
    c.lineWidth = 1.8;
    c.beginPath();
    c.moveTo(p.x - 10, p.y - 4);
    c.lineTo(p.x + 10, p.y + 5);
    c.moveTo(p.x - 8, p.y + 6);
    c.lineTo(p.x + 9, p.y - 5);
    c.stroke();
    drawCircle(c, p.x + 2, p.y - 5, 3.6, '#dcd4c4');
  },
  crypt_entrance: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 11, 25 * p.s, 11 * p.s);
    drawStoneRect(c, p.x - 22 * p.s, p.y - 17 * p.s, 44 * p.s, 34 * p.s, '#1d1916', '#6e5e47');
    c.fillStyle = '#040305';
    c.fillRect(p.x - 9 * p.s, p.y - 6 * p.s, 18 * p.s, 19 * p.s);
    c.strokeStyle = '#3a3228';
    c.lineWidth = 1.5;
    for (let s = 0; s < 3; s++) {
      c.beginPath();
      c.moveTo(p.x - 8 * p.s, p.y + (2 + s * 4) * p.s);
      c.lineTo(p.x + 8 * p.s, p.y + (2 + s * 4) * p.s);
      c.stroke();
    }
  },
  collapsed_hallway_seg: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 8, 30 * p.s, 10 * p.s);
    drawStoneRect(c, p.x - 28 * p.s, p.y - 14 * p.s, 56 * p.s, 8, '#26201a', '#594a3a');
    drawStoneRect(c, p.x - 28 * p.s, p.y + 6 * p.s, 56 * p.s, 8, '#26201a', '#594a3a');
    drawCircle(c, p.x - 6, p.y, 5 * p.s, '#382f25');
  },
  stone_floor: (c, p) => {
    c.fillStyle = 'rgba(64, 54, 44, 0.25)';
    c.fillRect(p.x - 24 * p.s, p.y - 18 * p.s, 48 * p.s, 36 * p.s);
    c.strokeStyle = 'rgba(110, 94, 74, 0.22)';
    c.lineWidth = 1;
    c.strokeRect(p.x - 22 * p.s, p.y - 16 * p.s, 20 * p.s, 14 * p.s);
    c.strokeRect(p.x + 2 * p.s, p.y - 16 * p.s, 20 * p.s, 14 * p.s);
  },
  ossuary_urn: (c, p) => {
    drawGroundShadow(c, p.x, p.y + 5, 7 * p.s);
    drawCircle(c, p.x, p.y - 2, 6.5 * p.s, '#4a3d31', '#8a745d', 1.2);
    drawCircle(c, p.x, p.y - 7, 3.5 * p.s, '#332920');
  },

  // --- VOID & OBSERVATORY (SPARSE COSMIC) ---
  void_rift_prop: (c, p, b, t) => {
    drawRing(c, p.x, p.y, 19 * p.s, b.fog + '88', 1.8);
    drawCircle(c, p.x, p.y, 8 + Math.sin(t * 4 + p.seed) * 2, '#0c0518', b.particle, 1.4);
  },
  cosmic_monolith: (c, p, b, t) => {
    drawGroundShadow(c, p.x, p.y + 12, 13 * p.s);
    const hover = Math.sin(t * 2 + p.seed) * 3.5;
    drawStoneRect(c, p.x - 7 * p.s, p.y - 24 * p.s + hover, 14 * p.s, 32 * p.s, '#141226', b.fog);
    drawDiamond(c, p.x, p.y - 10 * p.s + hover, 4 * p.s, b.particle);
  },
  astral_ring: (c, p, b, t) => {
    drawRing(c, p.x, p.y, 20 * p.s, b.fog + '55', 1.2);
    const a = t * 1.2 + p.seed;
    drawDiamond(c, p.x + Math.cos(a) * 20 * p.s, p.y + Math.sin(a) * 20 * p.s, 4, b.particle);
  },
  floating_ruin: (c, p, b, t) => {
    const hover = Math.sin(t * 1.8 + p.seed) * 4;
    drawGroundShadow(c, p.x, p.y + 14, 18 * p.s, 7 * p.s, 0.25);
    c.save();
    c.translate(p.x, p.y + hover);
    c.rotate(Math.sin(p.rot) * 0.25);
    drawStoneRect(c, -16 * p.s, -10 * p.s, 32 * p.s, 20 * p.s, '#181430', b.fog);
    c.strokeStyle = b.particle + '66';
    c.strokeRect(-10 * p.s, -5 * p.s, 20 * p.s, 10 * p.s);
    c.restore();
  },
  astral_fragment: (c, p, b, t) => {
    const hover = Math.sin(t * 2.6 + p.seed) * 3;
    drawDiamond(c, p.x, p.y - 4 + hover, 6 * p.s, '#1a1538', b.particle, 1.3);
  },
  impossible_geo: (c, p, b, t) => {
    const rot = t * 0.55 + p.seed;
    c.save();
    c.translate(p.x, p.y - 4);
    c.rotate(rot);
    c.strokeStyle = b.fog;
    c.lineWidth = 1.4;
    c.strokeRect(-11 * p.s, -11 * p.s, 22 * p.s, 22 * p.s);
    c.rotate(0.785);
    c.strokeStyle = b.particle;
    c.strokeRect(-8 * p.s, -8 * p.s, 16 * p.s, 16 * p.s);
    c.restore();
  }
};

// ============================================================================
// PROCEDURAL GROUND VARIATION & ANCIENT ROADS
// ============================================================================

function hexToRgb(hex) {
  const h = String(hex || '#556').replace('#', '');
  const f = h.length === 3 ? h.split('').map(c => c + c).join('') : h.slice(0, 6);
  const n = parseInt(f, 16);
  return `${(n >> 16) & 255},${(n >> 8) & 255},${n & 255}`;
}

// Radial falloff so ground patches melt into the floor instead of showing a hard ellipse edge
function softBlob(ctx, rx, ry, rgb, a) {
  ctx.save();
  ctx.scale(1, ry / Math.max(1, rx));
  const g = ctx.createRadialGradient(0, 0, rx * 0.12, 0, 0, rx);
  g.addColorStop(0, `rgba(${rgb},${a})`);
  g.addColorStop(0.6, `rgba(${rgb},${a * 0.55})`);
  g.addColorStop(1, `rgba(${rgb},0)`);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, rx, 0, 6.283);
  ctx.fill();
  ctx.restore();
}

function slab(ctx, x, y, w, h, fill, edge) {
  ctx.fillStyle = fill;
  ctx.strokeStyle = edge;
  ctx.lineWidth = 1;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, 3);
  else ctx.rect(x, y, w, h);
  ctx.fill();
  ctx.stroke();
}

function renderGroundPatch(ctx, gp, kind, biome) {
  ctx.save();
  ctx.translate(gp.x, gp.y);
  ctx.rotate(gp.rot);

  if (kind === 'moss_bed') {
    softBlob(ctx, gp.rx, gp.ry, '52,104,62', 0.38);
  } else if (kind === 'dead_grass') {
    softBlob(ctx, gp.rx * 0.95, gp.ry * 0.9, '92,84,48', 0.28);
  } else if (kind === 'forest_loam' || kind === 'root_mat') {
    softBlob(ctx, gp.rx, gp.ry, '14,10,8', 0.34);
  } else if (kind === 'snow_buildup') {
    softBlob(ctx, gp.rx, gp.ry, '214,236,255', 0.18);
  } else if (kind === 'ice_sheet') {
    softBlob(ctx, gp.rx, gp.ry, '130,186,232', 0.2);
  } else if (kind === 'frozen_earth') {
    softBlob(ctx, gp.rx, gp.ry, '34,52,74', 0.32);
  } else if (kind === 'stone_flag' || kind === 'courtyard_tile') {
    // Paving slabs with gaps instead of one big hard-edged tilted rectangle
    const w = gp.rx * 0.62;
    const h = gp.ry * 0.62;
    const gap = 3;
    for (let i = 0; i < 2; i++) {
      for (let j = 0; j < 2; j++) {
        const shade = (i + j) % 2 ? 'rgba(88,80,94,0.15)' : 'rgba(70,64,78,0.18)';
        slab(ctx, -w + i * w + gap * 0.5, -h + j * h + gap * 0.5, w - gap, h - gap, shade, 'rgba(150,134,156,0.13)');
      }
    }
  } else if (kind === 'ash_patch' || kind === 'ossuary_dust') {
    softBlob(ctx, gp.rx, gp.ry, '104,94,90', 0.26);
  } else if (kind === 'cracked_earth' || kind === 'scorched_slag') {
    const slag = kind === 'scorched_slag';
    softBlob(ctx, gp.rx * 0.9, gp.ry * 0.9, slag ? '84,18,22' : '12,9,11', 0.36);
    ctx.strokeStyle = slag ? 'rgba(255,96,56,0.30)' : 'rgba(8,6,8,0.45)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(-gp.rx * 0.5, -gp.ry * 0.2);
    ctx.lineTo(0, gp.ry * 0.15);
    ctx.lineTo(gp.rx * 0.45, -gp.ry * 0.25);
    ctx.stroke();
  } else if (kind === 'astral_scar' || kind === 'void_scorch') {
    softBlob(ctx, gp.rx * 0.85, gp.ry * 0.65, hexToRgb(biome.fog), 0.14);
  }
  ctx.restore();
}

function renderRoadSegment(ctx, seg, theme) {
  ctx.save();
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(seg.x1, seg.y1);
  ctx.lineTo(seg.x2, seg.y2);
  // soft verge, packed-earth bed, then a lighter worn centre (no dashed "debug" line)
  ctx.strokeStyle = theme.roadEdge;
  ctx.lineWidth = seg.w + 14;
  ctx.globalAlpha = 0.55;
  ctx.stroke();
  ctx.globalAlpha = 1;
  ctx.strokeStyle = theme.roadColor;
  ctx.lineWidth = seg.w;
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255, 240, 210, 0.035)';
  ctx.lineWidth = seg.w * 0.42;
  ctx.stroke();
  ctx.restore();
}

// ============================================================================
// REUSABLE LANDMARK GENERATORS (RECOGNIZABLE FROM EDGE OF SCREEN)
// ============================================================================

function getBiomePalette(biomeId, biome) {
  switch (biomeId) {
    case 'forest':
      return { base: '#212b24', stone: '#354038', trim: '#5f7363', glow: '#7ae89b', dark: '#101612' };
    case 'frozen':
      return { base: '#1e2c3d', stone: '#304761', trim: '#8ec2ed', glow: '#9ad8ff', dark: '#0e1722' };
    case 'capital':
      return { base: '#28222e', stone: '#3e3547', trim: '#8c7a96', glow: '#f2be6b', dark: '#130f17' };
    case 'infernal':
      return { base: '#2b1418', stone: '#452026', trim: '#993d3d', glow: '#ff6338', dark: '#14080a' };
    case 'catacombs':
      return { base: '#241e18', stone: '#3d3328', trim: '#856e52', glow: '#ffad54', dark: '#110e0b' };
    case 'observatory':
      return { base: '#141938', stone: '#232c61', trim: '#7591ff', glow: '#b8c9ff', dark: '#090b1c' };
    default:
      return { base: '#1f1233', stone: '#341e54', trim: biome.fog, glow: biome.particle, dark: '#0d0617' };
  }
}

const LANDMARK_DRAWERS = {
  broken_temple: (c, lm, pal, b, t) => {
    const r = lm.r;
    drawGroundShadow(c, lm.x, lm.y + 10, r * 0.95, r * 0.65, 0.36);
    drawStoneRect(c, lm.x - r * 0.78, lm.y - r * 0.56, r * 1.56, r * 1.12, pal.base, pal.trim, 2);
    drawStoneRect(c, lm.x - r * 0.62, lm.y - r * 0.42, r * 1.24, r * 0.84, pal.dark, pal.stone, 1.5);
    // Colonnade pillars (some broken)
    const cols = [-0.54, -0.2, 0.2, 0.54];
    for (let i = 0; i < cols.length; i++) {
      const px = lm.x + cols[i] * r;
      drawBrokenPillar(c, px, lm.y - r * 0.34, 15, i % 2 === 0 ? 34 : 22, pal.stone, pal.trim);
      if (i !== 2) drawBrokenPillar(c, px, lm.y + r * 0.36, 15, i === 0 ? 28 : 19, pal.stone, pal.trim);
    }
    // Central shattered sanctuary & glowing relic
    drawRing(c, lm.x, lm.y, r * 0.26, pal.trim, 2);
    drawCircle(c, lm.x, lm.y, 11 + Math.sin(t * 2.6 + lm.seed) * 2, pal.glow, '#ffffff', 1.5);
  },

  collapsed_tower: (c, lm, pal, b, t) => {
    const r = lm.r * 0.92;
    drawGroundShadow(c, lm.x, lm.y + 12, r * 0.95, r * 0.6, 0.42);
    // Fallen masonry debris arc extending outward
    c.save();
    c.translate(lm.x, lm.y);
    c.rotate(lm.rot);
    drawStoneRect(c, 16, -24, r * 0.95, 48, pal.base, pal.stone, 1.8);
    c.restore();
    // Tower circular shell
    drawCircle(c, lm.x, lm.y, r * 0.62, pal.base, pal.trim, 2.5);
    drawCircle(c, lm.x, lm.y, r * 0.44, pal.dark, pal.stone, 2);
    // Battlement merlons
    for (let i = 0; i < 6; i++) {
      if (i === 1 || i === 2) continue; // collapsed side
      const a = (i / 6) * Math.PI * 2 + lm.rot;
      drawStoneRect(c, lm.x + Math.cos(a) * r * 0.52 - 9, lm.y + Math.sin(a) * r * 0.52 - 9, 18, 18, pal.stone, pal.trim);
    }
    drawCircle(c, lm.x, lm.y, 9 + Math.sin(t * 3 + lm.seed) * 1.5, pal.glow + 'aa', pal.trim, 1.4);
  },

  ancient_altar: (c, lm, pal, b, t) => {
    const r = lm.r * 0.85;
    drawRing(c, lm.x, lm.y, r * 0.78, pal.trim + '66', 2);
    drawRing(c, lm.x, lm.y, r * 0.58, pal.glow + '55', 1.4);
    drawStoneRect(c, lm.x - 42, lm.y - 26, 84, 52, pal.base, pal.trim, 2);
    drawStoneRect(c, lm.x - 24, lm.y - 14, 48, 28, pal.stone, pal.glow, 1.5);
    for (let i = 0; i < 4; i++) {
      const a = i * 1.57 + 0.785;
      drawCircle(c, lm.x + Math.cos(a) * r * 0.68, lm.y + Math.sin(a) * r * 0.68, 7, pal.stone, pal.glow, 1.3);
    }
    drawDiamond(c, lm.x, lm.y, 12 + Math.sin(t * 3.5 + lm.seed) * 2.2, pal.glow, '#ffffff', 1.5);
  },

  great_tree: (c, lm, pal, b, t) => {
    const r = lm.r * 1.05;
    drawGroundShadow(c, lm.x, lm.y + 14, r * 0.9, r * 0.55, 0.45);
    // Sprawling ancient roots
    c.strokeStyle = '#33251a';
    c.lineWidth = 7;
    c.beginPath();
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 2 + lm.rot;
      c.moveTo(lm.x, lm.y);
      c.quadraticCurveTo(
        lm.x + Math.cos(a + 0.35) * r * 0.5,
        lm.y + Math.sin(a + 0.35) * r * 0.5,
        lm.x + Math.cos(a) * r * 0.92,
        lm.y + Math.sin(a) * r * 0.92
      );
    }
    c.stroke();
    // Massive hollowed trunk & dead boughs
    drawCircle(c, lm.x, lm.y, 34, '#241a13', '#4a3829', 3);
    drawCircle(c, lm.x, lm.y, 16, '#0d0907', pal.glow + '88', 1.6);
    c.strokeStyle = '#3b2b1e';
    c.lineWidth = 4;
    c.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2 + 0.4;
      c.moveTo(lm.x + Math.cos(a) * 20, lm.y + Math.sin(a) * 20);
      c.lineTo(lm.x + Math.cos(a) * r * 0.65, lm.y + Math.sin(a) * r * 0.65 - 12);
    }
    c.stroke();
    drawCircle(c, lm.x, lm.y, 6 + Math.sin(t * 2.5 + lm.seed) * 1.5, pal.glow, '#ffffff', 1);
  },

  ancient_graves: (c, lm, pal, b, t) => {
    const r = lm.r * 0.88;
    drawStoneRect(c, lm.x - r * 0.72, lm.y - r * 0.52, r * 1.44, r * 1.04, 'rgba(20, 22, 20, 0.35)', pal.stone, 2);
    // Rows of ancient tombstones
    for (let gx = -2; gx <= 2; gx++) {
      for (let gy = -1; gy <= 1; gy++) {
        if (gx === 0 && gy === 0) continue;
        const tx = lm.x + gx * 32;
        const ty = lm.y + gy * 34;
        drawStoneRect(c, tx - 6, ty - 11, 12, 16, pal.stone, pal.trim);
      }
    }
    // Central obelisk
    drawStoneRect(c, lm.x - 14, lm.y - 14, 28, 28, pal.base, pal.trim, 2);
    drawCircle(c, lm.x, lm.y, 7 + Math.sin(t * 2.2 + lm.seed) * 1.2, pal.glow, '#ffffff', 1.2);
  },

  ritual_circle: (c, lm, pal, b, t) => {
    const r = lm.r * 0.9;
    drawCircle(c, lm.x, lm.y, r * 0.82, 'rgba(12, 8, 16, 0.45)', pal.glow + 'aa', 2.2);
    drawRing(c, lm.x, lm.y, r * 0.58, pal.trim + '88', 1.5);
    c.strokeStyle = pal.glow + '66';
    c.lineWidth = 1.4;
    c.beginPath();
    for (let i = 0; i < 5; i++) {
      const a1 = (i / 5) * Math.PI * 2 + t * 0.08;
      const a2 = ((i + 2) / 5) * Math.PI * 2 + t * 0.08;
      c.moveTo(lm.x + Math.cos(a1) * r * 0.76, lm.y + Math.sin(a1) * r * 0.76);
      c.lineTo(lm.x + Math.cos(a2) * r * 0.76, lm.y + Math.sin(a2) * r * 0.76);
    }
    c.stroke();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const mx = lm.x + Math.cos(a) * r * 0.82;
      const my = lm.y + Math.sin(a) * r * 0.82;
      drawStoneRect(c, mx - 7, my - 12, 14, 20, pal.stone, pal.trim);
      drawCircle(c, mx, my - 13, 3.5, pal.glow);
    }
    drawCircle(c, lm.x, lm.y, 12 + Math.sin(t * 4 + lm.seed) * 2.5, pal.glow, '#ffffff', 1.4);
  },

  broken_bridge: (c, lm, pal) => {
    const r = lm.r * 1.05;
    c.save();
    c.translate(lm.x, lm.y);
    c.rotate(lm.rot);
    // Chasm beneath bridge
    c.fillStyle = '#04050a';
    c.beginPath();
    c.ellipse(0, 0, r * 0.46, r * 0.96, 0, 0, 6.283);
    c.fill();
    c.strokeStyle = pal.trim + '55';
    c.lineWidth = 2;
    c.stroke();
    // Left & right shattered bridge spans
    drawStoneRect(c, -r * 0.95, -28, r * 0.68, 56, pal.base, pal.trim, 2);
    drawStoneRect(c, r * 0.27, -28, r * 0.68, 56, pal.base, pal.trim, 2);
    // Guard pillars
    drawStoneRect(c, -r * 0.42, -36, 16, 16, pal.stone, pal.trim);
    drawStoneRect(c, -r * 0.42, 20, 16, 16, pal.stone, pal.trim);
    drawStoneRect(c, r * 0.30, -36, 16, 16, pal.stone, pal.trim);
    drawStoneRect(c, r * 0.30, 20, 16, 16, pal.stone, pal.trim);
    c.restore();
  },

  courtyard: (c, lm, pal, b, t) => {
    const r = lm.r;
    drawStoneRect(c, lm.x - r * 0.85, lm.y - r * 0.68, r * 1.7, r * 1.36, pal.base, pal.trim, 2);
    // Flagstone grid
    c.strokeStyle = pal.stone;
    c.lineWidth = 1.2;
    for (let x = -r * 0.6; x <= r * 0.6; x += r * 0.4) {
      c.beginPath();
      c.moveTo(lm.x + x, lm.y - r * 0.66);
      c.lineTo(lm.x + x, lm.y + r * 0.66);
      c.stroke();
    }
    // Central shattered fountain / royal statue plinth
    drawCircle(c, lm.x, lm.y, r * 0.32, pal.dark, pal.trim, 2.2);
    drawStoneRect(c, lm.x - 16, lm.y - 18, 32, 32, pal.stone, pal.trim);
    drawCircle(c, lm.x, lm.y - 4, 7 + Math.sin(t * 2.5 + lm.seed) * 1.2, pal.glow);
  },

  ancient_monument_plaza: (c, lm, pal, b, t) => {
    LANDMARK_DRAWERS.courtyard(c, lm, pal, b, t);
    drawBrokenPillar(c, lm.x, lm.y - 6, 26, 48, pal.stone, pal.trim, pal.glow);
  },

  grand_crypt: (c, lm, pal, b, t) => {
    const r = lm.r * 0.94;
    drawGroundShadow(c, lm.x, lm.y + 12, r * 0.92, r * 0.62, 0.45);
    drawStoneRect(c, lm.x - r * 0.74, lm.y - r * 0.56, r * 1.48, r * 1.12, pal.base, pal.trim, 2.2);
    // Sunken descending stairway
    drawStoneRect(c, lm.x - 28, lm.y - 24, 56, 64, '#050406', pal.trim, 1.8);
    c.strokeStyle = pal.stone;
    c.lineWidth = 2;
    for (let s = 0; s < 5; s++) {
      c.beginPath();
      c.moveTo(lm.x - 24, lm.y - 12 + s * 11);
      c.lineTo(lm.x + 24, lm.y - 12 + s * 11);
      c.stroke();
    }
    // Flanking braziers
    for (const sx of [-48, 48]) {
      drawCircle(c, lm.x + sx, lm.y - 18, 10, pal.stone, pal.trim, 1.5);
      drawCircle(c, lm.x + sx, lm.y - 18, 5.5 + Math.sin(t * 10 + sx) * 1.5, '#ff8e3c', '#ffe49e', 1);
    }
  },

  collapsed_hallway: (c, lm, pal, b, t) => {
    const r = lm.r;
    c.save();
    c.translate(lm.x, lm.y);
    c.rotate(lm.rot);
    drawStoneRect(c, -r * 0.95, -44, r * 1.9, 88, pal.dark, pal.stone, 1.6);
    drawStoneRect(c, -r * 0.95, -48, r * 1.9, 14, pal.base, pal.trim, 1.8);
    drawStoneRect(c, -r * 0.95, 34, r * 1.9, 14, pal.base, pal.trim, 1.8);
    for (let x = -r * 0.65; x <= r * 0.65; x += r * 0.42) {
      drawCircle(c, x, -38, 9, pal.stone, pal.trim, 1.5);
      drawCircle(c, x, 38, 9, pal.stone, pal.trim, 1.5);
    }
    drawCircle(c, 0, 0, 8 + Math.sin(t * 6 + lm.seed) * 1.6, pal.glow + 'aa');
    c.restore();
  },

  impossible_monument: (c, lm, pal, b, t) => {
    const r = lm.r * 0.92;
    drawRing(c, lm.x, lm.y, r * 0.8, pal.trim + '66', 1.6);
    drawRing(c, lm.x, lm.y, r * 0.52 + Math.sin(t * 2) * 5, pal.glow + '88', 1.4);
    c.save();
    c.translate(lm.x, lm.y);
    c.rotate(t * 0.25 + lm.seed);
    c.strokeStyle = pal.trim;
    c.lineWidth = 2;
    c.strokeRect(-r * 0.36, -r * 0.36, r * 0.72, r * 0.72);
    c.rotate(-t * 0.5);
    c.strokeStyle = pal.glow;
    c.strokeRect(-r * 0.24, -r * 0.24, r * 0.48, r * 0.48);
    c.restore();
    for (let i = 0; i < 4; i++) {
      const a = t * 0.4 + (i / 4) * Math.PI * 2;
      drawDiamond(c, lm.x + Math.cos(a) * r * 0.68, lm.y + Math.sin(a) * r * 0.68, 9, pal.base, pal.glow, 1.5);
    }
    drawCircle(c, lm.x, lm.y, 13 + Math.sin(t * 4) * 3, '#0b0618', pal.glow, 2);
  }
};

// ============================================================================
// BIOME PROGRESSION
// ============================================================================

export function updateBiomeCycle() {
  if (state.time < state.nextBiomeTime) return;
  state.nextBiomeTime += CFG.game.BIOME_SEC;
  state.biomeIdx = (state.biomeIdx + 1) % BIOMES.length;
  const b = BIOMES[state.biomeIdx];
  addFeed(`Entered Biome: ${b.name}`, b.fog);
  showBanner(b.name.toUpperCase(), FACTIONS[b.faction].name, b.fog, 2.4);
  sfx.setBiomeTone(b.musicHz);
}

// ============================================================================
// PARALLAX & DEPTH PERCEPTION (BACKGROUND SILHOUETTES + MIDGROUND RUINS)
// ============================================================================

export function renderParallaxBackground(ctx, camX, camY, viewW, viewH) {
  if (metaSave.settings.gfxQuality === 'low') return;
  const biome = BIOMES[state.biomeIdx];
  const theme = BIOME_THEMES[biome.id] || BIOME_THEMES.forest;
  const ap = state.apocalypse;

  const skyGrad = ctx.createLinearGradient(0, 0, 0, viewH);
  skyGrad.addColorStop(0, ap ? '#26080e' : biome.bg);
  skyGrad.addColorStop(1, '#050408');
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, viewW, viewH);

  ctx.save();
  // Layer 1: Far Horizon Silhouettes (0.07x parallax)
  ctx.globalAlpha = 0.28;
  ctx.fillStyle = ap ? '#3d0e17' : theme.silhouetteColor;
  const farSpan = 280;
  const farX = -(camX * 0.07) % farSpan;
  const farY = -(camY * 0.07) % farSpan;

  for (let x = farX - farSpan; x < viewW + farSpan; x += farSpan) {
    for (let y = farY - farSpan; y < viewH + farSpan; y += farSpan) {
      if (theme.cosmic) {
        drawCircle(ctx, x + 40, y + 40, 2.5, biome.particle);
        drawDiamond(ctx, x + 150, y + 110, 18, theme.silhouetteColor, biome.fog + '44', 1);
      } else if (biome.id === 'frozen') {
        // Distant jagged glacial peaks
        ctx.beginPath();
        ctx.moveTo(x, y + 130);
        ctx.lineTo(x + 65, y + 25);
        ctx.lineTo(x + 125, y + 90);
        ctx.lineTo(x + 185, y + 10);
        ctx.lineTo(x + 255, y + 130);
        ctx.closePath();
        ctx.fill();
      } else if (biome.id === 'forest') {
        // Ancient giant canopy & distant broken spires
        drawCircle(ctx, x + 70, y + 70, 48, theme.silhouetteColor);
        drawCircle(ctx, x + 155, y + 85, 38, theme.silhouetteColor);
        ctx.fillRect(x + 210, y + 25, 16, 95);
      } else if (biome.id === 'catacombs') {
        // Vast subterranean vault ribs
        ctx.fillRect(x + 20, y, 22, 160);
        ctx.fillRect(x + 140, y + 30, 80, 18);
      } else {
        // Ruined capital skyline silhouettes
        ctx.fillRect(x + 20, y + 40, 34, 110);
        ctx.fillRect(x + 74, y + 15, 24, 135);
        ctx.fillRect(x + 125, y + 55, 48, 95);
      }
    }
  }

  // Layer 2: Midground Architectural Silhouettes (0.20x parallax)
  ctx.globalAlpha = 0.16;
  ctx.strokeStyle = ap ? '#821c2a' : theme.midColor;
  ctx.fillStyle = ap ? '#4a121b' : theme.midColor;
  ctx.lineWidth = 1.2;
  const midSpan = 360;
  const midX = -(camX * 0.20) % midSpan;
  const midY = -(camY * 0.20) % midSpan;

  ctx.beginPath();
  for (let x = midX - midSpan; x < viewW + midSpan; x += midSpan) {
    ctx.moveTo(x, 0);
    ctx.lineTo(x, viewH);
  }
  for (let y = midY - midSpan; y < viewH + midSpan; y += midSpan) {
    ctx.moveTo(0, y);
    ctx.lineTo(viewW, y);
  }
  ctx.stroke();

  for (let x = midX - midSpan; x < viewW + midSpan; x += midSpan) {
    for (let y = midY - midSpan; y < viewH + midSpan; y += midSpan) {
      if (theme.cosmic) {
        drawRing(ctx, x + 180, y + 180, 44, biome.fog + '55', 1.4);
      } else {
        ctx.fillRect(x + 90, y + 90, 26, 26);
        ctx.fillRect(x + 250, y + 210, 18, 42);
      }
    }
  }
  ctx.restore();
}

// ============================================================================
// WORLD BACKDROP RENDERING (GROUND -> ROADS -> LANDMARKS -> CLUSTERS)
// ============================================================================

export function renderWorldBackdrop(ctx, camX, camY, viewW, viewH, inView) {
  ensureWorldProps();

  const biome = BIOMES[state.biomeIdx];
  const theme = BIOME_THEMES[biome.id] || BIOME_THEMES.forest;
  const pal = getBiomePalette(biome.id, biome);
  const t = state.time;
  const ap = state.apocalypse;
  const low = metaSave.settings.gfxQuality === 'low';

  // Subtle floor grid for spatial speed reference
  const tile = 110;
  const x0 = Math.max(0, Math.floor(camX / tile) * tile);
  const x1 = Math.min(CFG.game.W, camX + viewW + tile);
  const y0 = Math.max(0, Math.floor(camY / tile) * tile);
  const y1 = Math.min(CFG.game.H, camY + viewH + tile);

  ctx.strokeStyle = ap ? 'rgba(56, 18, 27, 0.30)' : biome.grid + '30';
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = x0; x <= x1; x += tile) {
    ctx.moveTo(x, y0);
    ctx.lineTo(x, y1);
  }
  for (let y = y0; y <= y1; y += tile) {
    ctx.moveTo(x0, y);
    ctx.lineTo(x1, y);
  }
  ctx.stroke();

  const minX = camX - 160;
  const minY = camY - 160;
  const maxX = camX + viewW + 160;
  const maxY = camY + viewH + 160;

  // 1) Procedural Ground Variation
  if (!low) {
    const gKinds = theme.groundKinds;
    forEachInGrid(groundGrid, minX, minY, maxX, maxY, gp => {
      if (theme.sparse && gp.sparse) return;
      if (!inView(gp.x, gp.y, gp.rx + 15)) return;
      renderGroundPatch(ctx, gp, gKinds[gp.slot % gKinds.length], biome);
    });
  }

  // 2) Ancient Roads & Trails linking Landmarks
  if (!theme.cosmic) {
    forEachInGrid(roadGrid, minX, minY, maxX, maxY, seg => {
      const cx = (seg.x1 + seg.x2) * 0.5;
      const cy = (seg.y1 + seg.y2) * 0.5;
      const rad = Math.hypot(seg.x2 - seg.x1, seg.y2 - seg.y1) * 0.5 + 45;
      if (!inView(cx, cy, rad)) return;
      renderRoadSegment(ctx, seg, theme);
    });
  }

  // 3) Rare Large Landmarks
  const lmTypes = theme.landmarks;
  forEachInGrid(landmarkGrid, minX - 60, minY - 60, maxX + 60, maxY + 60, lm => {
    if (theme.sparse && lm.slot % 2 === 1) return;
    if (!inView(lm.x, lm.y, lm.r + 50)) return;
    const arch = lmTypes[lm.slot % lmTypes.length];
    LANDMARK_DRAWERS[arch]?.(ctx, lm, pal, biome, t);
  });

  // 4) Environmental Clusters (mapped per biome role)
  const roleMap = theme.roleMap;
  forEachInGrid(propGrid, minX, minY, maxX, maxY, pr => {
    if (theme.sparse && !pr.sparseKeep) return;
    if (!inView(pr.x, pr.y, 75)) return;
    const role = pr.role || ALL_ROLES[pr.idx % ALL_ROLES.length];
    const choices = roleMap[role] || roleMap.debris;
    const kind = choices[pr.idx % choices.length];
    PROP_DRAWERS[kind]?.(ctx, pr, biome, t);
  });

  // 5) Apocalypse Rift Cracks
  if (ap) {
    ctx.strokeStyle = `rgba(255,42,75,${0.28 + Math.sin(t * 4) * 0.12})`;
    ctx.lineWidth = 2.5;
    for (const ck of cracks) {
      if (!inView(ck.x, ck.y, 150)) continue;
      ctx.beginPath();
      ctx.moveTo(ck.x, ck.y);
      ctx.lineTo(ck.x + Math.cos(ck.a) * ck.l * 0.5, ck.y + Math.sin(ck.a) * ck.l * 0.5);
      ctx.lineTo(ck.x + Math.cos(ck.a + 0.4) * ck.l, ck.y + Math.sin(ck.a + 0.4) * ck.l);
      ctx.stroke();
    }
  }

  ctx.strokeStyle = '#9e1f2f';
  ctx.lineWidth = 4;
  ctx.strokeRect(0, 0, CFG.game.W, CFG.game.H);
}

// ============================================================================
// DYNAMIC LIGHTING (SHRINES, TORCHES, VAULTS, BOSS AURA, BIOME TINT)
// ============================================================================

const PROP_LIGHT_SPECS = {
  torch: (pr, b, t) => ({
    x: pr.x, y: pr.y - 10,
    r: 96 + Math.sin(t * 9 + pr.seed) * 10,
    col: '#ff7b29', core: '#ffe099', a: 0.31
  }),
  brazier: (pr, b, t) => ({
    x: pr.x, y: pr.y - 7,
    r: 108 + Math.sin(t * 10 + pr.seed) * 11,
    col: '#ff6424', core: '#ffe099', a: 0.33
  }),
  moss_lantern: (pr, b, t) => ({
    x: pr.x, y: pr.y - 8,
    r: 86 + Math.sin(t * 4 + pr.seed) * 7,
    col: '#5fd68d', core: '#d9ffea', a: 0.24
  }),
  shrine: (pr, b, t) => ({
    x: pr.x, y: pr.y - 14,
    r: 118 + Math.sin(t * 3 + pr.seed) * 9,
    col: b.fog, core: '#e6f4ff', a: 0.28
  }),
  frost_shrine: (pr, b, t) => ({
    x: pr.x, y: pr.y - 14,
    r: 116 + Math.sin(t * 3 + pr.seed) * 8,
    col: '#63b4ff', core: '#e8f6ff', a: 0.28
  }),
  void_rift_prop: (pr, b, t) => ({
    x: pr.x, y: pr.y,
    r: 104 + Math.sin(t * 4 + pr.seed) * 7,
    col: '#7b2cbf', core: '#d6a3ff', a: 0.27
  }),
  cosmic_monolith: (pr, b, t) => ({
    x: pr.x, y: pr.y - 8,
    r: 94 + Math.sin(t * 2 + pr.seed) * 6,
    col: '#6d8aff', core: '#d4deff', a: 0.22
  })
};

const isFireSpell = pr =>
  pr.weaponKey === 'firestaff' || pr.weaponKey === 'sunhammer' || pr.color === '#ff8c38' || pr.color === '#ff4757' || pr.color === '#ff6b3d';

const isVoidSource = e =>
  e.faction === 'veiled' || e.kind === 'stalker' || e.kind === 'archer' || e.mod?.id === 'voidtouched';

function renderPropAndLandmarkLights(ctx, camX, camY, viewW, viewH, theme, biome, t, inView, budget) {
  const minX = camX - 150;
  const minY = camY - 150;
  const maxX = camX + viewW + 150;
  const maxY = camY + viewH + 150;
  const pal = getBiomePalette(biome.id, biome);

  // Landmark ambient shrine / altar / brazier / vault glow
  forEachInGrid(landmarkGrid, minX, minY, maxX, maxY, lm => {
    if (budget.left <= 0) return;
    if (theme.sparse && lm.slot % 2 === 1) return;
    if (!inView(lm.x, lm.y, lm.r + 70)) return;
    const pulse = Math.sin(t * 2.5 + lm.seed) * 14;
    emitLight(ctx, lm.x, lm.y, lm.r * 1.45 + pulse, pal.glow, 0.23, inView, budget, '#ffffff', 0.30);
  });

  // Torch / Shrine / Brazier cluster lights
  const roleMap = theme.roleMap;
  forEachInGrid(propGrid, minX, minY, maxX, maxY, pr => {
    if (budget.left <= 0) return;
    if (theme.sparse && !pr.sparseKeep) return;
    if (!inView(pr.x, pr.y, 120)) return;
    const role = pr.role || ALL_ROLES[pr.idx % ALL_ROLES.length];
    const choices = roleMap[role] || roleMap.debris;
    const kind = choices[pr.idx % choices.length];
    const spec = PROP_LIGHT_SPECS[kind]?.(pr, biome, t);
    if (spec) emitLight(ctx, spec.x, spec.y, spec.r, spec.col, spec.a, inView, budget, spec.core, 0.38);
  });
}

function renderEntityAndSpellLights(ctx, theme, t, inView, budget) {
  const p = state.player;
  if (p) {
    emitLight(ctx, p.x, p.y, 175, theme.ambientColor, 0.16, inView, budget, p.cls.color, 0.45);
    if (p.weapons?.firestaff || p.weapons?.sunhammer) {
      emitLight(ctx, p.x, p.y, 102, '#ff7b29', 0.17, inView, budget, '#ffe099', 0.38);
    }
  }

  // Vaults, Shrines, Obelisks, World Events Glow
  for (let i = 0; i < events.length && budget.left > 0; i++) {
    const ev = events[i];
    const isVault = ev.kind === 'vault' || ev.type === 'vault' || /vault/i.test(ev.name || ev.label || '');
    const rad = isVault ? 170 + Math.sin(t * 3.5) * 14 : 134;
    const alpha = isVault ? 0.36 : 0.29;
    emitLight(ctx, ev.x, ev.y, rad, ev.color || theme.accentColor, alpha, inView, budget, '#ffffff', 0.36);
  }

  for (let i = 0; i < lootPool.active.length && budget.left > 0; i++) {
    const l = lootPool.active[i];
    if (l.item.rarity === 'legendary' || l.item.rarity === 'mythic') {
      const col = RARITIES[l.item.rarity].color;
      emitLight(ctx, l.x, l.y, l.item.rarity === 'mythic' ? 102 : 76, col, 0.29, inView, budget, '#ffffff', 0.35);
    }
  }

  for (let i = 0; i < enemyPool.active.length && budget.left > 0; i++) {
    const e = enemyPool.active[i];
    if (!e.alive) continue;
    if (e.boss) {
      const pulse = e.phase === 2 ? Math.sin(t * 7) * 24 : Math.sin(t * 2.5) * 8;
      const core = e.phase === 2 ? '#ff2a4b' : '#ffffff';
      emitLight(ctx, e.x, e.y, e.r * 4.4 + pulse, e.color, 0.38, inView, budget, core, 0.44);
    } else if (isVoidSource(e)) {
      emitLight(ctx, e.x, e.y, e.r * 2.7, '#7b2cbf', 0.24, inView, budget, '#d6a3ff', 0.4);
    } else if (e.mod?.id === 'burning') {
      emitLight(ctx, e.x, e.y, e.r * 2.8, '#ff6b2b', 0.25, inView, budget, '#ffd080', 0.4);
    } else if (e.elite) {
      emitLight(ctx, e.x, e.y, e.r * 2.4, e.color, 0.19, inView, budget);
    }
  }

  for (let i = 0; i < hazards.length && budget.left > 0; i++) {
    const h = hazards[i];
    emitLight(ctx, h.x, h.y, h.r * 1.45, h.color, 0.28, inView, budget, '#ffd8a8', 0.35);
  }

  for (let i = 0; i < projPool.active.length && budget.left > 0; i++) {
    const pr = projPool.active[i];
    if (isFireSpell(pr)) {
      emitLight(ctx, pr.x, pr.y, 44, '#ff6b2b', 0.24, inView, budget, '#ffd080', 0.42);
    } else if (pr.isEnemy || pr.weaponKey === 'shadowdagger') {
      emitLight(ctx, pr.x, pr.y, 38, pr.color, 0.20, inView, budget);
    }
  }
}

function renderTimedLights(ctx, dt, inView, budget) {
  for (let i = timedLights.length - 1; i >= 0; i--) {
    const tl = timedLights[i];
    tl.life -= dt;
    if (tl.life <= 0) {
      timedLights.splice(i, 1);
      continue;
    }
    const k = tl.life / tl.maxLife;
    emitLight(ctx, tl.x, tl.y, tl.radius * (0.85 + k * 0.2), tl.color, tl.alpha * k, inView, budget, tl.coreColor, 0.42);
  }
}

export function renderDynamicLighting(ctx, camX, camY, viewW, viewH, inView) {
  ensureWorldProps();
  const low = metaSave.settings.gfxQuality === 'low';
  const budget = { left: low ? 14 : 52 };
  const biome = BIOMES[state.biomeIdx];
  const theme = BIOME_THEMES[biome.id] || BIOME_THEMES.forest;
  const t = state.time;
  const dt = Math.max(0.001, Math.min(0.05, t - lastLightTime));
  lastLightTime = t;

  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  renderEntityAndSpellLights(ctx, theme, t, inView, budget);
  renderTimedLights(ctx, dt, inView, budget);
  if (!low) renderPropAndLandmarkLights(ctx, camX, camY, viewW, viewH, theme, biome, t, inView, budget);
  ctx.restore();
}

// ============================================================================
// WEATHER, FOREGROUND PARALLAX & POST-FX BIOME TINTING
// ============================================================================

export function renderWeather(ctx, viewW, viewH) {
  const biome = BIOMES[state.biomeIdx];
  const theme = BIOME_THEMES[biome.id] || BIOME_THEMES.forest;
  const ap = state.apocalypse;
  const t = state.time;
  const wType = ap ? 'ash' : theme.weather;
  const low = metaSave.settings.gfxQuality === 'low';
  const count = low ? Math.min(35, state.ambientParticles.length) : state.ambientParticles.length;

  ctx.save();
  for (let i = 0; i < count; i++) {
    const pt = state.ambientParticles[i];
    const phase = pt.phase ?? i;
    let vx = -0.6;
    let vy = 0.8;
    let lit = false;

    if (wType === 'snow') {
      vx = Math.sin(t * 1.8 + phase) * 0.9 - 1.45;
      vy = 2.05;
      ctx.fillStyle = i % 3 === 0 ? 'rgba(235, 248, 255, 0.78)' : 'rgba(205, 232, 255, 0.50)';
    } else if (wType === 'forest') {
      vx = Math.sin(t * 1.1 + phase) * 0.9 - 0.3;
      vy = 0.75;
      lit = i % 5 === 0;
      ctx.fillStyle = lit ? 'rgba(175, 235, 165, 0.65)' : i % 3 === 0 ? 'rgba(130, 175, 110, 0.44)' : 'rgba(160, 200, 175, 0.24)';
    } else if (wType === 'void') {
      vx = Math.cos(t * 1.2 + phase) * 0.85;
      vy = -0.95;
      lit = i % 4 === 0;
      ctx.fillStyle = lit ? 'rgba(224, 178, 255, 0.74)' : 'rgba(165, 105, 255, 0.42)';
    } else {
      vx = ap ? -4.4 : -1.25;
      vy = ap ? 2.6 : 0.95;
      lit = i % 5 === 0;
      ctx.fillStyle = ap
        ? lit ? 'rgba(255, 165, 90, 0.70)' : 'rgba(255, 85, 65, 0.46)'
        : lit ? 'rgba(255, 185, 115, 0.50)' : biome.particle + '55';
    }

    pt.x = (pt.x + vx + viewW) % viewW;
    pt.y = (pt.y + vy + viewH) % viewH;
    ctx.fillRect(pt.x, pt.y, pt.s * (ap ? 1.8 : 1), pt.s);
  }

  // Extra Blizzard Storm Streaks in Frozen Wastes / Void Storm Wisps
  if (!low && wType === 'snow' && !ap) {
    ctx.strokeStyle = 'rgba(220, 242, 255, 0.22)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    for (let s = 0; s < 32; s++) {
      const sx = ((s * 173 - t * 340) % viewW + viewW) % viewW;
      const sy = ((s * 97 + t * 260) % viewH + viewH) % viewH;
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx - 18, sy + 14);
    }
    ctx.stroke();
  }

  // Foreground Parallax Wisps & Peripheral Depth Silhouettes (1.18x camera feel)
  if (!low && (wType === 'forest' || wType === 'snow' || wType === 'void' || ap)) {
    ctx.globalCompositeOperation = 'lighter';
    const wCol = ap ? '#ff3b30' : theme.ambientColor;
    const pxOff = state.player ? -(state.player.x * 0.18) : 0;
    const pyOff = state.player ? -(state.player.y * 0.18) : 0;
    for (let k = 0; k < 4; k++) {
      const fx = ((t * (18 + k * 6) + pxOff + k * 420) % (viewW + 420) + (viewW + 420)) % (viewW + 420) - 210;
      const fy = ((pyOff * 0.4 + viewH * (0.16 + k * 0.22)) % viewH + viewH) % viewH;
      emitLight(ctx, fx, fy, 210, wCol, ap ? 0.085 : 0.055);
    }
  }
  ctx.restore();
}

export function renderPostFX(ctx, viewW, viewH) {
  const biome = BIOMES[state.biomeIdx];
  const theme = BIOME_THEMES[biome.id] || BIOME_THEMES.forest;
  const ap = state.apocalypse;
  const postFx = metaSave.settings.postFx !== false;

  if (postFx) {
    if (!ap) {
      const grade = ctx.createLinearGradient(0, 0, 0, viewH);
      grade.addColorStop(0, theme.gradeTop);
      grade.addColorStop(1, theme.gradeBot);
      ctx.fillStyle = grade;
      ctx.fillRect(0, 0, viewW, viewH);
    }
    if (state.activeBoss?.alive) {
      const bossPulse = state.activeBoss.phase === 2 ? 0.22 + Math.sin(state.time * 5) * 0.04 : 0.16;
      ctx.fillStyle = `rgba(112, 14, 28, ${bossPulse})`;
      ctx.fillRect(0, 0, viewW, viewH);
    }
    if (ap) {
      const sky = ctx.createLinearGradient(0, 0, 0, viewH);
      sky.addColorStop(0, 'rgba(130, 12, 24, 0.34)');
      sky.addColorStop(0.5, 'rgba(70, 8, 18, 0.12)');
      sky.addColorStop(1, 'rgba(20, 4, 8, 0.38)');
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, viewW, viewH);
    }
    if (state.player && metaSave.settings.gfxQuality !== 'low') {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      emitLight(ctx, viewW / 2, viewH / 2, Math.min(viewW, viewH) * 0.44, theme.ambientColor, 0.085);
      ctx.restore();
    }
  }

  if (state.dmgFlash > 0) {
    ctx.fillStyle = `rgba(210, 24, 42, ${Math.min(0.42, state.dmgFlash * 0.42)})`;
    ctx.fillRect(0, 0, viewW, viewH);
  }

  const vig = ctx.createRadialGradient(viewW / 2, viewH / 2, viewH * 0.38, viewW / 2, viewH / 2, viewW * 0.74);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, ap ? 'rgba(40, 4, 10, 0.78)' : postFx ? 'rgba(5, 4, 8, 0.54)' : 'rgba(5, 4, 8, 0.48)');
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, viewW, viewH);
}

export function renderAtmosphereOverlay(ctx, viewW, viewH) {
  renderWeather(ctx, viewW, viewH);
  renderPostFX(ctx, viewW, viewH);
}