export const ASHEN_CAPITAL_BIOME = {
  id: 'capital',
  name: 'Ashen Capital',
  bg: '#121014',
  grid: '#241f29',
  fog: '#c9a050',
  particle: '#b8aa99',
  faction: 'throne',
  musicHz: 49
};

export const INFERNAL_CHASM_BIOME = {
  id: 'infernal',
  name: 'Infernal Chasm',
  bg: '#14090b',
  grid: '#291216',
  fog: '#9e1f2f',
  particle: '#ff6b3d',
  faction: 'covenant',
  musicHz: 44
};