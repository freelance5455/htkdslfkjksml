export const FROZEN_WASTES_BIOME = {
  id: 'frozen',
  name: 'Frozen Wastes',
  bg: '#0b1017',
  grid: '#172330',
  fog: '#6fa8dc',
  particle: '#cbe4ff',
  faction: 'choir',
  musicHz: 65
};