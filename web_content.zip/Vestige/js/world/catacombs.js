export const CATACOMBS_BIOME = {
  id: 'catacombs',
  name: 'Ancient Catacombs',
  bg: '#0d0c0b',
  grid: '#211d19',
  fog: '#8c7853',
  particle: '#a89f91',
  faction: 'hollow',
  musicHz: 52
};