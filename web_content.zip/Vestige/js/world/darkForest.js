export const DARK_FOREST_BIOME = {
  id: 'forest',
  name: 'Dark Forest',
  bg: '#0c100e',
  grid: '#18211b',
  fog: '#4c7559',
  particle: '#7d8a7e',
  faction: 'hollow',
  musicHz: 55
};