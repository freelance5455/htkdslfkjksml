import { metaSave, hasUnlock, spendCost, persistSave } from '../core/save.js';

export function purchaseMetaUpgrade(upgradeDef) {
  const rank = metaSave.metaRanks[upgradeDef.id] || 0;
  if (rank >= upgradeDef.max) return false;
  const cost = { [upgradeDef.cur]: upgradeDef.baseCost * (rank + 1) };
  if (!spendCost(cost)) return false;
  metaSave.metaRanks[upgradeDef.id] = rank + 1;
  persistSave();
  return true;
}

export function purchaseReliquaryUnlock(unlockDef) {
  if (hasUnlock(unlockDef.id) || !spendCost(unlockDef.cost)) return false;
  metaSave.unlocks.push(unlockDef.id);
  persistSave();
  return true;
}