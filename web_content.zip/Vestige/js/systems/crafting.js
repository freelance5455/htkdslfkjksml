import { pick } from '../core/utilities.js';
import { state } from '../core/game.js';

import { GEMS } from '../data/items.js';
import { AFFIX_DEFS } from '../data/affixes.js';

import { calcItemScore, rollSingleAffix } from '../entities/loot.js';
import { recalcStats } from '../entities/player.js';

function finalizeCraft(item) {
  item.score = calcItemScore(item);
  recalcStats();
  return true;
}

export function rerollItemAffixes(item) {
  if (!item || state.runGold < 40) return false;
  state.runGold -= 40;
  const n = item.affixes.length;
  const used = [];
  item.affixes = [];
  for (let i = 0; i < n; i++) {
    const af = rollSingleAffix(item.rarity, item.ilvl, used, item.ancient);
    if (af) {
      used.push(af.key);
      item.affixes.push(af);
    }
  }
  return finalizeCraft(item);
}

export function reforgeItemValues(item) {
  if (!item || state.runGold < 60) return false;
  state.runGold -= 60;
  item.affixes = item.affixes.map(a => {
    const nr = Math.round(a.raw * (1.05 + Math.random() * 0.15));
    const def = AFFIX_DEFS.find(d => d.key === a.key);
    return {
      ...a,
      raw: nr,
      val: def.pct ? nr / 100 : nr,
      text: def.label.replace('{v}', nr)
    };
  });
  return finalizeCraft(item);
}

export function enchantItemAffix(item) {
  if (!item || state.runShards < 3 || item.affixes.length >= 5) return false;
  const af = rollSingleAffix(
    item.rarity,
    item.ilvl,
    item.affixes.map(a => a.key),
    item.ancient
  );
  if (!af) return false;
  state.runShards -= 3;
  item.affixes.push(af);
  return finalizeCraft(item);
}

export function upgradeItemRarity(item) {
  const ord = ['common', 'magic', 'rare', 'legendary', 'mythic'];
  const i = item ? ord.indexOf(item.rarity) : -1;
  if (i < 0 || i >= ord.length - 1 || state.runEssence < 2) return false;
  state.runEssence -= 2;
  item.rarity = ord[i + 1];
  return finalizeCraft(item);
}

export function socketItemGem(item) {
  if (!item || state.runGold < 50 || item.gems.length >= 2) return false;
  state.runGold -= 50;
  item.gems.push(pick(GEMS));
  return finalizeCraft(item);
}