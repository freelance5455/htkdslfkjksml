import { state } from '../core/game.js';
import { recalcStats } from '../entities/player.js';

const statMod = mods => s => {
  for (const [k, v] of Object.entries(mods)) s[k] += v;
};

const keystoneNode = (name, extraMods, applyFn) => (s, p) => {
  s.keystones.add(name);
  if (extraMods) statMod(extraMods)(s);
  if (applyFn) applyFn(s, p);
};

export const PASSIVE_TREE = (() => {
  const nodes = [];

  const addNode = (x, y, name, desc, color, apply, keystone = false) => {
    const id = nodes.length;
    nodes.push({ id, x, y, name, desc, keystone, color, links: [], apply });
    return id;
  };

  const linkNodes = (a, b) => {
    if (!nodes[a].links.includes(b)) nodes[a].links.push(b);
    if (!nodes[b].links.includes(a)) nodes[b].links.push(a);
  };

  addNode(
    480,
    210,
    'Forsaken Spark',
    'Origin of the Remnant (+15 Max Health, +6% Damage)',
    '#f0cf85',
    statMod({ maxHpBase: 15, dmgPct: 0.06 })
  );

  const branches = [
    {
      name: 'Iron',
      angle: -Math.PI / 2,
      color: '#e05656',
      steps: [
        ['Tempered Flesh', '+24 Max Health & +5 Armor', statMod({ maxHpBase: 24, armor: 5 })],
        ['Crushing Heft', '+10 Flat Damage & +10% Area Size', statMod({ flatDmg: 10, areaPct: 0.10 })],
        ['Bulwark Stance', '+10 Armor & +2 HP/s Regen', statMod({ armor: 10, regen: 2 })],
        ['Vanguard Momentum', '+12% Damage & -10% Dash Cooldown', statMod({ dmgPct: 0.12, dashCdr: 0.10 })],
        ['Siegebreaker', '+14 Flat Damage & +18% Area Size', statMod({ flatDmg: 14, areaPct: 0.18 })],
        ['Unbreakable Plate', '+14 Armor & +36 Max Health', statMod({ armor: 14, maxHpBase: 36 })],
        ['Juggernaut Oath', '+16% Damage & +10 Armor', statMod({ dmgPct: 0.16, armor: 10 })]
      ],
      bridge: ['Bastion Bridge', '+12 Armor & +10% Damage', statMod({ armor: 12, dmgPct: 0.10 })],
      keystone: [
        "Titan's Resolve",
        'KEYSTONE: Armor Contributes To Damage (+135% of Armor as Flat Damage) & +25 Armor, -15% Move Speed.',
        keystoneNode("Titan's Resolve", { armor: 25, moveSpeedMult: -0.15 }, s => {
          s.titanResolve = true;
          s.armorToDmg = 1.35;
          s.flatDmg += Math.round(Math.max(0, s.armor) * 1.35);
        })
      ]
    },
    {
      name: 'Wind',
      angle: -Math.PI / 6,
      color: '#8ec5ff',
      steps: [
        ['Keen Sight', '+6% Crit Chance & +6% Move Speed', statMod({ critChance: 0.06, moveSpeedMult: 0.06 })],
        ['Gale Cadence', '+12% Attack Speed', statMod({ atkSpeed: 0.12 })],
        ['Split Gale', '+1 Projectile & -8% Attack Speed', statMod({ projBonus: 1, atkSpeed: -0.08 })],
        ['Zephyr Reflex', '+10% Move Speed & -12% Dash Cooldown', statMod({ moveSpeedMult: 0.10, dashCdr: 0.12 })],
        ['Hawk Eye', '+8% Crit Chance & +25% Crit Damage', statMod({ critChance: 0.08, critDmg: 0.25 })],
        ['Tempest Volley', '+15% Attack Speed & +15% Pickup Radius', statMod({ atkSpeed: 0.15, pickupBonus: 0.15 })],
        ['Cyclone Mastery', '+14% Damage & +10% Attack Speed', statMod({ dmgPct: 0.14, atkSpeed: 0.10 })]
      ],
      bridge: ['Gale Bridge', '+10% Attack Speed & +6% Move Speed', statMod({ atkSpeed: 0.10, moveSpeedMult: 0.06 })],
      keystone: [
        'Echoes of Eternity',
        'KEYSTONE: +2 Projectiles & +35% Attack Speed, -20% Hit Damage.',
        keystoneNode('Echoes of Eternity', { projBonus: 2, atkSpeed: 0.35, dmgPct: -0.20 })
      ]
    },
    {
      name: 'Flame',
      angle: Math.PI / 6,
      color: '#ff8c38',
      steps: [
        ['Kindled Spark', '+14% Area Size & +8% Damage', statMod({ areaPct: 0.14, dmgPct: 0.08 })],
        ['Chrono Rune', '+8% Cooldown Reduction & +10% XP Gain', statMod({ cdr: 0.08, xpGain: 0.10 })],
        ['Pyre Mastery', '+12 Flat Damage & +14% Area Size', statMod({ flatDmg: 12, areaPct: 0.14 })],
        ['Astral Conduit', '+10% Cooldown Reduction & +10% Damage', statMod({ cdr: 0.10, dmgPct: 0.10 })],
        ['Solar Flare', '+22% Area Size & +6% Crit Chance', statMod({ areaPct: 0.22, critChance: 0.06 })],
        ['Spellweave', '+16% Attack Speed & +8% Cooldown Reduction', statMod({ atkSpeed: 0.16, cdr: 0.08 })],
        ['Cataclysm Focus', '+20% Damage & +15% Area Size', statMod({ dmgPct: 0.20, areaPct: 0.15 })]
      ],
      bridge: ['Ember Bridge', '+12% Area Size & +8% Cooldown Reduction', statMod({ areaPct: 0.12, cdr: 0.08 })],
      keystone: [
        'Arcane Ascension',
        'KEYSTONE: Projectiles Ignore Armor, +45% Damage & +25% Area Size; Maximum Health Reduced By 50%.',
        keystoneNode('Arcane Ascension', { dmgPct: 0.45, areaPct: 0.25, maxHpMult: -0.50 }, s => {
          s.ignoreArmor = true;
        })
      ]
    },
    {
      name: 'Hollow',
      angle: Math.PI / 2,
      color: '#5effb1',
      steps: [
        ['Bone Whisper', '+20% Summon Power & +6% CDR', statMod({ summonDmg: 0.20, cdr: 0.06 })],
        ['Soul Harvester', '+25% Pickup Radius & +15% XP Gain', statMod({ pickupBonus: 0.25, xpGain: 0.15 })],
        ['Ossuary Guard', '+18 Max Health & +22% Summon Power', statMod({ maxHpBase: 18, summonDmg: 0.22 })],
        ['Wraith Cadence', '+14% Attack Speed & +18% Summon Power', statMod({ atkSpeed: 0.14, summonDmg: 0.18 })],
        ['Deathly Grip', '+30% Pickup Radius & +4% Life Steal', statMod({ pickupBonus: 0.30, lifeSteal: 0.04 })],
        ['Necrotic Surge', '+32% Summon Power & +8% CDR', statMod({ summonDmg: 0.32, cdr: 0.08 })],
        ['Lord of Ash', '+15% Damage & +25% Summon Power', statMod({ dmgPct: 0.15, summonDmg: 0.25 })]
      ],
      bridge: ['Hollow Bridge', '+20% Summon Power & +12% XP Gain', statMod({ summonDmg: 0.20, xpGain: 0.12 })],
      keystone: [
        'Grave Sovereign',
        'KEYSTONE: Summons Never Expire, +3 Max Summons & +85% Summon Power; -25% Direct Weapon Damage.',
        keystoneNode('Grave Sovereign', { summonDmg: 0.85, dmgPct: -0.25 }, s => {
          s.permanentSummons = true;
          s.bonusSummons = (s.bonusSummons || 0) + 3;
        })
      ]
    },
    {
      name: 'Throne',
      angle: (5 * Math.PI) / 6,
      color: '#ffd700',
      steps: [
        ['Crimson Tithe', '+3% Life Steal & +15 Max Health', statMod({ lifeSteal: 0.03, maxHpBase: 15 })],
        ['Martyr Vitality', '+32 Max Health & +2 HP/s Regen', statMod({ maxHpBase: 32, regen: 2 })],
        ['Sanguine Edge', '+12% Damage & +3% Life Steal', statMod({ dmgPct: 0.12, lifeSteal: 0.03 })],
        ['Vigilant Ward', '+8 Armor & +3 HP/s Regen', statMod({ armor: 8, regen: 3 })],
        ['Bloodletting', '+28% Crit Damage & +4% Life Steal', statMod({ critDmg: 0.28, lifeSteal: 0.04 })],
        ['Sacred Vessel', '+45 Max Health & +10% Damage', statMod({ maxHpBase: 45, dmgPct: 0.10 })],
        ['Judgment Vow', '+18% Damage & +6 Armor', statMod({ dmgPct: 0.18, armor: 6 })]
      ],
      bridge: ['Throne Bridge', '+25 Max Health & +3% Life Steal', statMod({ maxHpBase: 25, lifeSteal: 0.03 })],
      keystone: [
        'Blood Pact',
        'KEYSTONE: Cannot Regenerate Health; Gain Flat Damage Equal To Missing Health & +6% Life Steal.',
        keystoneNode('Blood Pact', { lifeSteal: 0.06 }, (s, p) => {
          s.noRegen = 1;
          s.bloodPact = true;
          if (p) s.flatDmg += Math.max(0, Math.round((p.maxHp || 0) - (p.hp || 0)));
        })
      ]
    },
    {
      name: 'Veil',
      angle: (-5 * Math.PI) / 6,
      color: '#c56cf0',
      steps: [
        ['Razor Ambush', '+22% Crit Damage & +4% Crit Chance', statMod({ critDmg: 0.22, critChance: 0.04 })],
        ['Nightstep', '+8% Move Speed & -12% Dash Cooldown', statMod({ moveSpeedMult: 0.08, dashCdr: 0.12 })],
        ['Wicked Edge', '+10 Flat Damage & +6% Crit Chance', statMod({ flatDmg: 10, critChance: 0.06 })],
        ['Lethal Tempo', '+14% Attack Speed & +18% Crit Damage', statMod({ atkSpeed: 0.14, critDmg: 0.18 })],
        ['Void Execution', '+20% Damage & -10% Max Health', statMod({ dmgPct: 0.20, maxHpMult: -0.10 })],
        ['Fatal Precision', '+9% Crit Chance & +35% Crit Damage', statMod({ critChance: 0.09, critDmg: 0.35 })],
        ['Phantom Edge', '+16% Damage & +10% Move Speed', statMod({ dmgPct: 0.16, moveSpeedMult: 0.10 })]
      ],
      bridge: ['Veil Bridge', '+18% Crit Damage & +6% Move Speed', statMod({ critDmg: 0.18, moveSpeedMult: 0.06 })],
      keystone: [
        'Glass Apotheosis',
        'KEYSTONE: +90% Total Damage, +25% Crit Chance & +45% Crit Damage; -45% Max Health.',
        keystoneNode('Glass Apotheosis', { dmgPct: 0.90, critChance: 0.25, critDmg: 0.45, maxHpMult: -0.45 })
      ]
    }
  ];

  const ringConnectors = [];

  for (const b of branches) {
    let prev = 0;
    let ringNodeId = null;

    for (let step = 1; step <= 8; step++) {
      const r = 32 + step * 21;
      const a = b.angle + (step === 8 ? 0 : (step % 2 === 0 ? 0.14 : -0.14) * (step > 4 ? 0.6 : 1));
      const x = Math.round(480 + Math.cos(a) * r * 1.45);
      const y = Math.round(210 + Math.sin(a) * r * 0.85);
      const isKs = step === 8;
      const [name, desc, apply] = isKs ? b.keystone : b.steps[step - 1];

      const id = addNode(x, y, name, desc, b.color, apply, isKs);
      linkNodes(prev, id);
      if (step === 3) ringNodeId = id;

      if (step === 4) {
        const sa = b.angle + 0.28;
        const sr = r * 1.05;
        const sx = Math.round(480 + Math.cos(sa) * sr * 1.45);
        const sy = Math.round(210 + Math.sin(sa) * sr * 0.85);
        const [bName, bDesc, bApply] = b.bridge;
        const sid = addNode(sx, sy, bName, bDesc, b.color, bApply, false);
        linkNodes(id, sid);
      }
      prev = id;
    }

    ringConnectors.push(ringNodeId);
  }

  for (let i = 0; i < ringConnectors.length; i++) {
    linkNodes(ringConnectors[i], ringConnectors[(i + 1) % ringConnectors.length]);
  }

  return nodes;
})();

export function canAllocate(id) {
  const p = state.player;
  return (
    p.treePoints > 0 &&
    !p.allocatedNodes.has(id) &&
    PASSIVE_TREE[id].links.some(l => p.allocatedNodes.has(l))
  );
}

export function allocateTreeNode(id) {
  if (!canAllocate(id)) return false;
  state.player.allocatedNodes.add(id);
  state.player.treePoints--;
  recalcStats();
  return true;
}

export function respecTree() {
  if (state.runGold < 100) return false;
  state.runGold -= 100;
  state.player.treePoints += state.player.allocatedNodes.size - 1;
  state.player.allocatedNodes = new Set([0]);
  recalcStats();
  return true;
}

export function applyTreeStats(p, s) {
  for (const nid of p.allocatedNodes) {
    PASSIVE_TREE[nid]?.apply(s, p);
  }
}