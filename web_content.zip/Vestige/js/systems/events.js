import { CFG } from '../core/config.js';
import { pick, drawCircle, drawRing, drawText } from '../core/utilities.js';
import { metaSave, persistSave, grantFrag } from '../core/save.js';
import { state, events, spawnParticles } from '../core/game.js';

import { WORLD_EVENTS, MERCHANT_ENC } from '../data/eventsData.js';
import { DirectorConfig } from '../data/worldTierData.js';

import { recalcStats } from '../entities/player.js';
import { spawnEnemy } from '../entities/enemies.js';
import { generateLootItem, dropLoot } from '../entities/loot.js';
import { BIOMES } from '../world/biomes.js';

import { getDirectorMods } from './aiDirector.js';
import { openNpcModal } from './merchants.js';
import {
  QuestlineManager,
  QUEST_STATUS,
  OBJECTIVE_TYPES,
  addQuestProgress,
  advanceQuest,
  getQuestState,
  notifyQuestEvent
} from './questlines.js';
import { showBanner, addFeed } from '../ui/notifications.js';
import { eventMarker } from '../ui/minimap.js';
import { DOM, showQuestNotification } from '../ui/hud.js';
import { renderQuestTracker } from '../ui/questUI.js';

// ============================================================================
// PERSISTENCE FOR QUEST WORLD EVENTS, NPCS & ONE-TIME ENCOUNTERS
// ============================================================================

function getEventStore() {
  if (!metaSave.questEvents || typeof metaSave.questEvents !== 'object') {
    metaSave.questEvents = {
      encounteredNpcs: [],
      completedChains: [],
      decisions: {},
      oneTimeEncounters: []
    };
  }
  const s = metaSave.questEvents;
  if (!Array.isArray(s.encounteredNpcs)) s.encounteredNpcs = [];
  if (!Array.isArray(s.completedChains)) s.completedChains = [];
  if (!s.decisions || typeof s.decisions !== 'object') s.decisions = {};
  if (!Array.isArray(s.oneTimeEncounters)) s.oneTimeEncounters = [];
  return s;
}

export function hasOneTimeEncounter(id) {
  return getEventStore().oneTimeEncounters.includes(id);
}

export function markOneTimeEncounter(id) {
  if (!id) return;
  const store = getEventStore();
  if (!store.oneTimeEncounters.includes(id)) {
    store.oneTimeEncounters.push(id);
    persistSave();
  }
}

export function recordQuestNpcDecision(npcId, questId, choiceId) {
  const store = getEventStore();
  if (npcId && !store.encounteredNpcs.includes(npcId)) {
    store.encounteredNpcs.push(npcId);
  }
  if (questId && choiceId) {
    store.decisions[`${questId}:${choiceId}`] = {
      npcId,
      questId,
      choiceId,
      at: Date.now()
    };
  }
  persistSave();
}

export function markEventChainCompleted(chainId) {
  if (!chainId) return;
  const store = getEventStore();
  if (!store.completedChains.includes(chainId)) {
    store.completedChains.push(chainId);
    persistSave();
  }
}

export function getQuestEventHistory() {
  const store = getEventStore();
  return {
    encounteredNpcs: [...store.encounteredNpcs],
    completedChains: [...store.completedChains],
    decisions: { ...store.decisions },
    oneTimeEncounters: [...store.oneTimeEncounters]
  };
}

// ============================================================================
// REUSABLE QUESTLINE HOOK SYSTEM
// ============================================================================

const HOOK_DEFINITIONS = {
  bossDefeat: payload => {
    const bossId = payload?.bossData?.id || payload?.bossId || payload?.id;
    notifyQuestEvent(OBJECTIVE_TYPES.BOSS_KILL, { id: bossId, bossId });
    if (payload?.bossData?.faction === 'throne' || bossId === 'colossus') {
      addQuestProgress('kaelen_smith', 'slay_iron_champion', 1);
    }
  },
  championDefeat: payload => {
    const kind = payload?.kind || 'champion';
    notifyQuestEvent(OBJECTIVE_TYPES.ENEMY_KILL, { id: kind, elite: true, faction: payload?.faction });
  },
  vaultCompletion: ev => {
    notifyQuestEvent(OBJECTIVE_TYPES.WORLD_EVENT, { id: 'vault', target: 'vault', x: ev?.x, y: ev?.y });
    addQuestProgress('kaelen_smith', 'find_forge_frags', 1);
  },
  dungeonCompletion: dungeon => {
    const id = dungeon?.id || dungeon;
    notifyQuestEvent(OBJECTIVE_TYPES.DUNGEON_CLEAR, { id, target: id });
  },
  merchantEncounter: npc => {
    const id = npc?.id || 'merchant';
    notifyQuestEvent(OBJECTIVE_TYPES.NPC_ENCOUNTER, { id, target: id });
  },
  relicDiscovery: item => {
    const id = item?.id || item?.unique?.id || item?.subType || 'relic';
    notifyQuestEvent(OBJECTIVE_TYPES.ITEM_DISCOVERY, { id, target: id, item });
  },
  fragmentCollection: ({ fragKey, amount = 1 } = {}) => {
    if (!fragKey) return;
    notifyQuestEvent(OBJECTIVE_TYPES.FRAGMENT_COLLECT, { target: fragKey, amount });
  },
  worldEventCompleted: ev => {
    const id = ev?.questEventId || ev?.kind || 'world_event';
    notifyQuestEvent(OBJECTIVE_TYPES.WORLD_EVENT, { id, target: id });
  },
  npcEncountered: npcId => {
    notifyQuestEvent(OBJECTIVE_TYPES.NPC_ENCOUNTER, { id: npcId, target: npcId });
  }
};

export const QUEST_HOOKS = Object.freeze(
  Object.fromEntries(
    Object.keys(HOOK_DEFINITIONS).map(key => [key, payload => dispatchQuestHook(key, payload)])
  )
);

export function dispatchQuestHook(hookName, payload = {}) {
  const fn = HOOK_DEFINITIONS[hookName];
  if (!fn) return false;
  fn(payload);
  renderQuestTracker();
  return true;
}

// ============================================================================
// INTERACTIVE NPC ENCOUNTER MODAL HELPER
// ============================================================================

function closeNpcModalToGame() {
  DOM['npc-modal']?.classList.remove('active');
  if (state.player) state.mode = 'playing';
  recalcStats();
  renderQuestTracker();
}

function openQuestNpcDialog({ name, quote, body, choices = [] }) {
  if (!DOM['npc-modal']) return;
  state.mode = 'npc';
  DOM['npc-name'].textContent = name;
  DOM['npc-quote'].textContent = quote || '';
  DOM['npc-body'].innerHTML = body || '';
  DOM['npc-choices'].innerHTML = '';

  for (const ch of choices) {
    const btn = document.createElement('button');
    btn.className = ch.primary ? 'btn-gold' : 'btn-dark';
    btn.innerHTML = ch.label;
    btn.onclick = () => {
      ch.onSelect?.();
      if (!ch.keepOpen) closeNpcModalToGame();
    };
    DOM['npc-choices'].appendChild(btn);
  }

  DOM['npc-modal'].classList.add('active');
}

// ============================================================================
// DATA-DRIVEN QUEST NPC ENCOUNTER REGISTRY (EXPANSIBLE)
// ============================================================================

const QUEST_NPC_REGISTRY = new Map();

export function registerQuestNpcEncounter(def) {
  if (!def?.id) return;
  QUEST_NPC_REGISTRY.set(def.id, def);
}

const DEFAULT_QUEST_NPCS = [
  {
    id: 'kaelen_smith',
    questId: 'kaelen_smith',
    label: 'Kaelen, Hollowed Smith',
    icon: '⚒',
    color: '#ff9442',
    kind: 'npc',
    locations: ['forge', 'ruins', 'shrine'],
    preferredBiomes: ['capital', 'infernal', 'catacombs', 'forest'],
    getWeight({ worldTier, biomeId, questState }) {
      if (questState?.status === QUEST_STATUS.COMPLETED || questState?.status === QUEST_STATUS.FAILED) {
        return 0.04; // rare lingering smith visit after completion
      }
      let w = questState?.status === QUEST_STATUS.ACTIVE ? 0.42 : 0.30;
      if (this.preferredBiomes.includes(biomeId)) w *= 1.45;
      if (worldTier >= 2) w *= 1.2;
      return w;
    },
    onInteract(ev, p) {
      const st = QuestlineManager.discoverQuest('kaelen_smith');
      const store = getEventStore();
      if (!store.encounteredNpcs.includes('kaelen_smith')) {
        store.encounteredNpcs.push('kaelen_smith');
        persistSave();
      }
      QUEST_HOOKS.npcEncountered('kaelen_smith');

      const ql = QuestlineManager.registry.get('kaelen_smith');
      const stage = ql?.getStage(st?.currentStageId);
      const ready = st?.status === QUEST_STATUS.ACTIVE && stage && QuestlineManager.areStageObjectivesComplete(ql, st, stage);

      const choices = [];

      if (st?.currentStageId === 'forge_fragments') {
        choices.push({
          label: '⚒ Claim Loose Forge Sparks (+1 Ancient Forge Fragment & +25 Shards)',
          primary: true,
          onSelect: () => {
            state.runShards += 25;
            addQuestProgress('kaelen_smith', 'find_forge_frags', 1);
            showQuestNotification('updated', 'Kaelen, Hollowed Smith', 'Recovered an Ancient Forge Fragment', 'throne');
          }
        });
      }

      if (stage?.choices?.length && ready) {
        for (const ch of stage.choices) {
          choices.push({
            label: `✦ ${ch.label}`,
            primary: ch.outcome !== 'fail',
            onSelect: () => {
              recordQuestNpcDecision('kaelen_smith', 'kaelen_smith', ch.id);
              advanceQuest('kaelen_smith', { choiceId: ch.id });
              if (ch.outcome === 'fail') markEventChainCompleted('kaelen_betrayed');
            }
          });
        }
      }

      choices.push({
        label: '🔥 Temper Weapons in Kaelen’s Hearth (+10% Damage & +15 Gold)',
        onSelect: () => {
          p.bonus.dmgPct += 0.10;
          state.runGold += 15;
          addFeed('Kaelen tempered your armaments (+10% Damage)', '#ff9442');
        }
      });
      choices.push({ label: 'Leave the Forge', onSelect: () => {} });

      openQuestNpcDialog({
        name: 'Kaelen, Hollowed Smith',
        quote: stage?.dialogue || '"The First Flame sleeps in cold iron. Bring its embers back to my anvil."',
        body: `<b>Stage:</b> ${stage ? stage.title : st?.npcState || 'Master Smith'}<br>` +
              `<span style="color:#b8afc4;">${stage ? stage.description : 'Kaelen tends the ancient forge.'}</span>`,
        choices
      });
    }
  },

  {
    id: 'last_pilgrim',
    questId: 'last_pilgrim',
    label: 'The Last Pilgrim',
    icon: '🕯',
    color: '#e6c88a',
    kind: 'npc',
    oneTimeId: 'pilgrim_initial_choice',
    locations: ['road', 'monument', 'exploration'],
    preferredBiomes: ['forest', 'capital', 'catacombs'],
    getWeight({ biomeId, questState }) {
      if (questState?.status === QUEST_STATUS.COMPLETED || questState?.status === QUEST_STATUS.FAILED) return 0;
      if (hasOneTimeEncounter('pilgrim_initial_choice') && questState?.currentStageId === 'encounter_pilgrim') return 0;
      let w = questState?.status === QUEST_STATUS.ACTIVE ? 0.34 : 0.28;
      if (this.preferredBiomes.includes(biomeId)) w *= 1.4;
      return w;
    },
    onInteract(ev, p) {
      const st = QuestlineManager.discoverQuest('last_pilgrim');
      QUEST_HOOKS.npcEncountered('last_pilgrim');
      const ql = QuestlineManager.registry.get('last_pilgrim');
      const stage = ql?.getStage(st?.currentStageId);

      // Initial branching encounter: Help / Ignore / Refuse
      if (st?.currentStageId === 'encounter_pilgrim') {
        openQuestNpcDialog({
          name: 'The Last Pilgrim',
          quote: stage?.dialogue || '"The road to the First Flame is long, traveler. Will you share your warmth?"',
          body: 'A ragged wanderer clutches an unlit brass lantern along the ruined road. Your choice will shape their fate across runs.',
          choices: [
            {
              label: '🕯 Help the Pilgrim (Share warmth & guide toward Sanctuary)',
              primary: true,
              onSelect: () => {
                markOneTimeEncounter('pilgrim_initial_choice');
                recordQuestNpcDecision('last_pilgrim', 'last_pilgrim', 'help');
                p.hp = Math.min(p.maxHp, p.hp + Math.round(p.maxHp * 0.35));
                p.bonus.moveSpeed += 0.06;
                advanceQuest('last_pilgrim', { choiceId: 'help', force: true });
                showQuestNotification('updated', 'The Last Pilgrim', 'You shared your flame with the wanderer.', 'pilgrim');
              }
            },
            {
              label: '🌫 Ignore (Walk past in silence)',
              onSelect: () => {
                markOneTimeEncounter('pilgrim_initial_choice');
                recordQuestNpcDecision('last_pilgrim', 'last_pilgrim', 'ignore');
                advanceQuest('last_pilgrim', { choiceId: 'ignore', force: true });
                showQuestNotification('updated', 'The Last Pilgrim', 'Left behind in the drifting ash.', 'pilgrim');
              }
            },
            {
              label: '⚔ Refuse (Claim their spark & turn them away)',
              onSelect: () => {
                markOneTimeEncounter('pilgrim_initial_choice');
                recordQuestNpcDecision('last_pilgrim', 'last_pilgrim', 'refuse');
                state.runGold += 45;
                advanceQuest('last_pilgrim', { choiceId: 'refuse', force: true });
                spawnEnemy('elite', ev.x + 35, ev.y);
                showQuestNotification('failed', 'The Last Pilgrim', 'You severed the Pilgrim’s path.', 'pilgrim');
              }
            }
          ]
        });
        return;
      }

      // Subsequent stages
      const ready = stage && QuestlineManager.areStageObjectivesComplete(ql, st, stage);
      const choices = [];
      if (stage?.choices?.length && ready) {
        for (const ch of stage.choices) {
          choices.push({
            label: `✦ ${ch.label}`,
            primary: true,
            onSelect: () => {
              recordQuestNpcDecision('last_pilgrim', 'last_pilgrim', ch.id);
              advanceQuest('last_pilgrim', { choiceId: ch.id });
              markEventChainCompleted(`pilgrim_${ch.id}`);
            }
          });
        }
      } else {
        choices.push({
          label: '🕯 Rest Briefly Beside the Pilgrim’s Lantern (+50% HP & +1 Ash Fragment)',
          primary: true,
          onSelect: () => {
            p.hp = Math.min(p.maxHp, p.hp + Math.round(p.maxHp * 0.5));
            grantFrag('ash', 1);
            QUEST_HOOKS.fragmentCollection({ fragKey: 'ash', amount: 1 });
          }
        });
      }
      choices.push({ label: 'Continue Onward', onSelect: () => {} });

      openQuestNpcDialog({
        name: 'The Last Pilgrim',
        quote: stage?.dialogue || '"Every footstep leaves an ember in the ash."',
        body: `<b>Current Chronicle:</b> ${stage?.title || st?.npcState}<br><span style="color:#b8afc4;">${stage?.description || ''}</span>`,
        choices
      });
    }
  },

  {
    id: 'veiled_seer',
    questId: 'veiled_seer',
    label: 'The Veiled Seer',
    icon: '✧',
    color: '#9fb4ff',
    kind: 'npc',
    locations: ['celestial', 'monument', 'high_tier'],
    preferredBiomes: ['observatory', 'void', 'frozen'],
    getWeight({ worldTier, biomeId, questState }) {
      if (questState?.status === QUEST_STATUS.COMPLETED) return 0.05;
      let w = 0.14 + (worldTier - 1) * 0.10;
      if (this.preferredBiomes.includes(biomeId)) w *= 1.9;
      if (questState?.status === QUEST_STATUS.ACTIVE) w *= 1.3;
      return w;
    },
    onInteract(ev, p) {
      const st = QuestlineManager.discoverQuest('veiled_seer');
      QUEST_HOOKS.npcEncountered('veiled_seer');
      const ql = QuestlineManager.registry.get('veiled_seer');
      const stage = ql?.getStage(st?.currentStageId);
      const ready = stage && QuestlineManager.areStageObjectivesComplete(ql, st, stage);

      const choices = [
        {
          label: '🔭 Reveal Future Encounters (Manifest 2 World Events & +1 Star Fragment)',
          primary: true,
          onSelect: () => {
            grantFrag('star', 1);
            QUEST_HOOKS.fragmentCollection({ fragKey: 'star', amount: 1 });
            spawnWorldEvent(true);
            spawnWorldEvent(true);
            showBanner('FORESIGHT UNVEILED', 'Two Hidden World Events Revealed', '#9fb4ff', 2.2);
          }
        },
        {
          label: '🌌 Modify Current Run: Astral Surge (+18% Area & +12% Cooldown Speed)',
          onSelect: () => {
            p.bonus.areaPct += 0.18;
            p.bonus.cdr += 0.12;
            state.enemySpeedMult *= 1.06;
            addQuestProgress('veiled_seer', 'complete_astral_event', 1);
            addFeed('Run Modified: Astral Surge (+18% Area, +12% CDR)', '#9fb4ff');
          }
        }
      ];

      if (stage?.choices?.length && ready) {
        for (const ch of stage.choices) {
          choices.unshift({
            label: `✧ ${ch.label}`,
            primary: true,
            onSelect: () => {
              recordQuestNpcDecision('veiled_seer', 'veiled_seer', ch.id);
              advanceQuest('veiled_seer', { choiceId: ch.id });
              markEventChainCompleted(`seer_${ch.id}`);
            }
          });
        }
      }

      choices.push({ label: 'Step Back from the Veil', onSelect: () => {} });

      openQuestNpcDialog({
        name: 'The Veiled Seer',
        quote: stage?.dialogue || '"Look closely at the shattered stars—tomorrow has already happened."',
        body: `<b>Prophecy Stage:</b> ${stage?.title || st?.npcState}<br><span style="color:#b8afc4;">${stage?.description || ''}</span>`,
        choices
      });
    }
  }
];

DEFAULT_QUEST_NPCS.forEach(registerQuestNpcEncounter);

// ============================================================================
// DATA-DRIVEN SPECIAL QUEST WORLD EVENTS (6 NEW TYPES + EXPANSION SUPPORT)
// ============================================================================

const QUEST_WORLD_EVENT_REGISTRY = new Map();

export function registerWorldEventType(def) {
  if (!def?.id) return;
  QUEST_WORLD_EVENT_REGISTRY.set(def.id, def);
}

const DEFAULT_QUEST_WORLD_EVENTS = [
  {
    id: 'ancient_forge_fragment',
    kind: 'monument',
    label: 'Ancient Forge Fragment',
    icon: '⚒',
    color: '#ff9442',
    weight: ({ biomeId }) => (biomeId === 'capital' || biomeId === 'infernal' ? 0.34 : 0.24),
    onTrigger(ev, p) {
      state.runGold += 35;
      state.runShards += 10;
      const kaelenState = getQuestState('kaelen_smith');
      if (kaelenState?.currentStageId === 'ember_anvil' && state.worldTier >= 2 && !hasOneTimeEncounter('ember_anvil_unearthed')) {
        markOneTimeEncounter('ember_anvil_unearthed');
        addQuestProgress('kaelen_smith', 'recover_ember_anvil', 1);
        showBanner('THE EMBER ANVIL', 'Relic of Kaelen Unearthed!', '#ff9442', 2.6);
      } else {
        addQuestProgress('kaelen_smith', 'find_forge_frags', 1);
        showBanner('ANCIENT FORGE FRAGMENT', '+1 Forge Fragment & +10 Shards', '#ff9442', 2.2);
      }
      QUEST_HOOKS.worldEventCompleted(ev);
    }
  },
  {
    id: 'lost_journal',
    kind: 'monument',
    label: 'Lost Journal',
    icon: '📖',
    color: '#e6c88a',
    oneTimeId: null,
    weight: ({ biomeId }) => (biomeId === 'forest' || biomeId === 'capital' ? 0.30 : 0.20),
    onTrigger(ev, p) {
      p.xp += 18;
      grantFrag('ash', 1);
      QUEST_HOOKS.fragmentCollection({ fragKey: 'ash', amount: 1 });
      addQuestProgress('last_pilgrim', 'explore_ash_path', 1);
      addQuestProgress('last_pilgrim', 'clear_pilgrim_events', 1);
      QUEST_HOOKS.worldEventCompleted(ev);
      showBanner('LOST JOURNAL', 'Forgotten Footsteps Recorded (+1 Ash Fragment)', '#e6c88a', 2.1);
    }
  },
  {
    id: 'ancient_relic_cache',
    kind: 'vault',
    label: 'Ancient Relic',
    icon: '🏺',
    color: '#ffd700',
    weight: ({ worldTier }) => 0.18 + worldTier * 0.04,
    onTrigger(ev, p) {
      const item = generateLootItem(p.level + state.worldTier + 1, 'legendary', 1.15);
      dropLoot(ev.x, ev.y, item);
      QUEST_HOOKS.relicDiscovery(item);
      QUEST_HOOKS.worldEventCompleted(ev);
      showBanner('ANCIENT RELIC', 'A Storied Relic Emerges from the Dust', '#ffd700', 2.3);
    }
  },
  {
    id: 'forgotten_shrine',
    kind: 'shrine',
    label: 'Forgotten Shrine',
    icon: '⛩',
    color: '#8ec5ff',
    weight: () => 0.28,
    onTrigger(ev, p) {
      p.hp = p.maxHp;
      p.bonus.regen += 1.5;
      recalcStats();
      addQuestProgress('last_pilgrim', 'clear_pilgrim_events', 1);
      addQuestProgress('veiled_seer', 'complete_astral_event', 1);
      QUEST_HOOKS.worldEventCompleted(ev);
      showBanner('FORGOTTEN SHRINE', 'Vitality Restored & +1.5 Regeneration', '#8ec5ff', 2.1);
    }
  },
  {
    id: 'broken_monument',
    kind: 'monument',
    label: 'Broken Monument',
    icon: '🗿',
    color: '#c56cf0',
    weight: ({ biomeId }) => (biomeId === 'observatory' || biomeId === 'void' ? 0.36 : 0.22),
    onTrigger(ev, p) {
      p.treePoints++;
      grantFrag('star', 1);
      QUEST_HOOKS.fragmentCollection({ fragKey: 'star', amount: 1 });
      addQuestProgress('veiled_seer', 'complete_astral_event', 1);
      QUEST_HOOKS.worldEventCompleted(ev);
      showBanner('BROKEN MONUMENT', '+1 Skill Point & Star Fragment', '#c56cf0', 2.2);
    }
  },
  {
    id: 'hidden_tomb',
    kind: 'vault',
    label: 'Hidden Tomb',
    icon: '⚰',
    color: '#5effb1',
    oneTimeId: 'hidden_tomb_unsealed',
    weight: ({ biomeId, worldTier }) => (biomeId === 'catacombs' ? 0.35 : 0.16) + worldTier * 0.03,
    onTrigger(ev, p) {
      markOneTimeEncounter('hidden_tomb_unsealed');
      markEventChainCompleted('hidden_tomb');
      state.runGold += 85;
      state.runEssence += 1;
      spawnEnemy('elite', ev.x + 38, ev.y);
      const item = generateLootItem(p.level + state.worldTier + 1, 'legendary', 1.2);
      dropLoot(ev.x, ev.y, item);
      QUEST_HOOKS.relicDiscovery(item);
      addQuestProgress('kaelen_smith', 'find_forge_frags', 1);
      QUEST_HOOKS.vaultCompletion(ev);
      showBanner('HIDDEN TOMB UNSEALED', 'Ancient Guardian & Tomb Treasures Awakened', '#5effb1', 2.4);
    }
  }
];

DEFAULT_QUEST_WORLD_EVENTS.forEach(registerWorldEventType);

// ============================================================================
// CORE STANDARD EVENT HANDLERS (PRESERVED + HOOKED)
// ============================================================================

const EVENT_HANDLERS = {
  shrine: (ev, p) => {
    p.hp = p.maxHp;
    p.bonus.atkSpeed += 0.12;
    recalcStats();
    QUEST_HOOKS.worldEventCompleted(ev);
    showBanner('ANCIENT SHRINE', 'Vitality Restored & +12% Attack Speed', '#8ec5ff', 2);
  },
  vault: (ev, p) => {
    state.runGold += 75;
    state.runShards += 10;
    const fKey = pick(['flame', 'void', 'star']);
    grantFrag('ash', 3);
    grantFrag(fKey, 1);
    QUEST_HOOKS.fragmentCollection({ fragKey: 'ash', amount: 3 });
    QUEST_HOOKS.fragmentCollection({ fragKey: fKey, amount: 1 });
    const item = generateLootItem(p.level + state.worldTier, 'legendary', 1.0);
    dropLoot(ev.x, ev.y, item);
    QUEST_HOOKS.relicDiscovery(item);
    spawnEnemy('elite', ev.x + 40, ev.y);
    QUEST_HOOKS.vaultCompletion(ev);
    showBanner('RELIQUARY VAULT', 'Treasures & Fragments Unsealed', '#ffd700', 2.2);
  },
  merchant: ev => {
    QUEST_HOOKS.merchantEncounter({ id: 'merchant', event: ev });
    openNpcModal(MERCHANT_ENC);
  },
  goblin: ev => {
    spawnEnemy('goblin', ev.x, ev.y);
    if (Math.random() < 0.45) spawnEnemy('goblin', ev.x + 20, ev.y);
    QUEST_HOOKS.worldEventCompleted(ev);
    showBanner('GOBLIN PORTAL', 'Treasure Goblins Escaped!', '#f6b93b', 2);
  },
  altar: (ev, p) => {
    for (let i = 0; i < 3; i++) spawnEnemy('elite');
    const item = generateLootItem(p.level + state.worldTier + 1, 'legendary', 1);
    dropLoot(ev.x, ev.y, item);
    QUEST_HOOKS.relicDiscovery(item);
    QUEST_HOOKS.worldEventCompleted(ev);
    showBanner('CURSED ALTAR', 'Champions Summoned', '#ff4757', 2.2);
  },
  monument: (ev, p) => {
    p.treePoints++;
    grantFrag('star', 1);
    QUEST_HOOKS.fragmentCollection({ fragKey: 'star', amount: 1 });
    QUEST_HOOKS.worldEventCompleted(ev);
    showBanner('FORGOTTEN MONUMENT', '+1 Skill Point & Star Fragment', '#c56cf0', 2);
  },
  npc: () => {
    QUEST_HOOKS.npcEncountered('wandering_npc');
    openNpcModal();
  },
  special: ev => {
    QUEST_HOOKS.worldEventCompleted(ev);
    spawnEnemy('secret');
  },
  // Dungeon entrances: play the entry sequence, then hand off to an optional ev.onEnter(ev, p) hook
  // (e.g. a data-driven entrance can load its own dungeon from there).
  dungeon: (ev, p) => {
    showBanner('DUNGEON ENTRY', ev.label || 'The Descent Begins', ev.color || '#c56cf0', 2.4);
    addFeed(`Entering ${ev.label || 'the dungeon'}...`, ev.color || '#c56cf0');
    QUEST_HOOKS.worldEventCompleted(ev);
    ev.onEnter?.(ev, p);
  }
};

export function registerEventHandler(kind, fn) {
  if (kind && typeof fn === 'function') EVENT_HANDLERS[kind] = fn;
}

// ============================================================================
// REUSABLE PROXIMITY INTERACTION SYSTEM
// Walk near something and it just happens: no buttons, keys or prompts.
//  - one rule lookup per interactable (cached), one distance calc per frame
//  - only the CLOSEST in-range interactable triggers, one at a time
//  - repeat protection: completion flag + spawn grace + global cooldown
//  - also drives the proximity glow/pulse/highlight used by the renderer
// ============================================================================

export const INTERACTION_CFG = {
  radii: {
    merchant: 350,
    questNpc: 400,
    shrine: 250,
    forgeFragment: 250,
    vault: 350,
    dungeon: 350,
    npc: 350,        // wandering NPCs
    monument: 250,
    altar: 200,
    goblin: 200,
    special: 250,
    default: 200
  },
  cooldown: 0.75,     // seconds of gameplay time between any two interactions
  spawnGrace: 1.2,    // new events can't fire instantly (e.g. spawning inside range)
  awarenessMul: 1.6   // proximity glow begins at radius * this
};

export function registerInteractionRadius(category, radius) {
  if (category && radius > 0) INTERACTION_CFG.radii[category] = radius;
}

class ProximityInteractor {
  constructor(cfg, classify) {
    this.cfg = cfg;
    this.classify = classify;
    this.lockUntil = 0;
    this.lastT = 0;
  }

  radiusFor(ev) {
    const radii = this.cfg.radii;
    return radii[this.classify(ev)] ?? radii.default;
  }

  // Cached per-interactable rule (category, radii squared)
  rule(ev) {
    let ix = ev._ix;
    if (!ix) {
      const cat = this.classify(ev);
      const r = this.cfg.radii[cat] ?? this.cfg.radii.default;
      const ar = r * this.cfg.awarenessMul;
      ix = ev._ix = { cat, r, r2: r * r, aware: ar, aware2: ar * ar };
    }
    return ix;
  }

  // Returns the single interactable to activate this frame (already removed from the list), or null.
  update(list, p, now) {
    if (now < this.lastT) this.lockUntil = 0; // new run
    this.lastT = now;
    const locked = now < this.lockUntil;

    let best = -1;
    let bestD2 = Infinity;

    for (let i = 0; i < list.length; i++) {
      const ev = list[i];
      const ix = this.rule(ev);
      const dx = p.x - ev.x;
      const dy = p.y - ev.y;
      const d2 = dx * dx + dy * dy;

      // Proximity feedback state (eased so glow fades in/out softly)
      let target = 0;
      const armed = now >= (ev._armedAt || 0);
      const inRange = d2 <= ix.r2;
      if (inRange) {
        target = 0.7;
        if (armed && !ev.done && d2 < bestD2) {
          bestD2 = d2;
          best = i;
        }
      } else if (d2 < ix.aware2) {
        target = 0.55 * (1 - (Math.sqrt(d2) - ix.r) / (ix.aware - ix.r));
      }
      ev._near = inRange;
      ev._closest = false;
      const g = ev._glow || 0;
      ev._glow = g + (target - g) * 0.12;
      if (ev._glow < 0.004 && target === 0) ev._glow = 0;
    }

    if (best < 0) return null;
    const chosen = list[best];
    chosen._closest = true;
    chosen._glow = Math.min(1, chosen._glow + 0.1);
    if (locked) return null; // highlighted, waiting for the cooldown

    chosen.done = true;      // completion flag: can never fire twice
    list.splice(best, 1);
    this.lockUntil = now + this.cfg.cooldown;
    return chosen;
  }
}

function classifyEvent(ev) {
  if (ev.questNpcId) return 'questNpc';
  if (ev.questEventId === 'ancient_forge_fragment') return 'forgeFragment';
  const radii = INTERACTION_CFG.radii;
  return ev.kind && ev.kind in radii ? ev.kind : 'default';
}

const INTERACTOR = new ProximityInteractor(INTERACTION_CFG, classifyEvent);

// ============================================================================
// WEIGHTED EVENT SELECTION, SPAWNING, UPDATING & RENDERING
// ============================================================================

function pickWeighted(candidates) {
  let total = 0;
  for (const c of candidates) total += Math.max(0, c.weight);
  if (total <= 0) return null;
  let roll = Math.random() * total;
  for (const c of candidates) {
    roll -= Math.max(0, c.weight);
    if (roll <= 0) return c.item;
  }
  return candidates[candidates.length - 1]?.item || null;
}

function buildQuestEventCandidate() {
  const biomeId = BIOMES[state.biomeIdx]?.id || 'forest';
  const ctxInfo = { worldTier: state.worldTier, biomeId };
  const candidates = [];

  // NPCs (rare, weighted by tier, biome & quest state)
  for (const npc of QUEST_NPC_REGISTRY.values()) {
    if (events.some(e => e.questNpcId === npc.id)) continue;
    if (npc.oneTimeId && hasOneTimeEncounter(npc.oneTimeId)) continue;
    const questState = npc.questId ? getQuestState(npc.questId) : null;
    const w = npc.getWeight ? npc.getWeight({ ...ctxInfo, questState }) : 0.2;
    if (w > 0) {
      candidates.push({
        weight: w,
        item: {
          kind: npc.kind || 'npc',
          label: npc.label,
          icon: npc.icon,
          color: npc.color,
          questNpcId: npc.id,
          isQuestEvent: true
        }
      });
    }
  }

  // Quest World Events
  for (const qEv of QUEST_WORLD_EVENT_REGISTRY.values()) {
    if (qEv.oneTimeId && hasOneTimeEncounter(qEv.oneTimeId)) continue;
    if (events.some(e => e.questEventId === qEv.id)) continue;
    const w = typeof qEv.weight === 'function' ? qEv.weight(ctxInfo) : (qEv.weight || 0.2);
    if (w > 0) {
      candidates.push({
        weight: w,
        item: {
          kind: qEv.kind,
          label: qEv.label,
          icon: qEv.icon,
          color: qEv.color,
          questEventId: qEv.id,
          isQuestEvent: true
        }
      });
    }
  }

  return pickWeighted(candidates);
}

export function spawnWorldEvent(forceNormal = false) {
  if (events.length >= CFG.game.EVENTS_CAP) return;
  const p = state.player;
  if (!p) return;

  const rec = getDirectorMods().recovery;
  let ev = null;

  // Normal events remain the most common (~76%); quest events/NPCs appear naturally (~24%)
  const questChance = rec ? 0.14 : Math.min(0.32, 0.20 + state.worldTier * 0.025);
  if (!forceNormal && Math.random() < questChance) {
    ev = buildQuestEventCandidate();
  }

  if (!ev) {
    ev =
      rec && Math.random() < DirectorConfig.weak.shrineBias
        ? WORLD_EVENTS[0]
        : state.gameMode === 'relic_hunt' && Math.random() < 0.5
        ? pick([WORLD_EVENTS[1], WORLD_EVENTS[3], WORLD_EVENTS[0]])
        : pick(WORLD_EVENTS);

    if (ev.kind === 'special' && state.worldTier < 3 && Math.random() < 0.65) {
      ev = WORLD_EVENTS[1];
    }
  }

  const a = Math.random() * 6.28;
  const d = Math.max(350, INTERACTOR.radiusFor(ev) + 60) + Math.random() * 380;
  events.push({
    x: Math.max(120, Math.min(CFG.game.W - 120, p.x + Math.cos(a) * d)),
    y: Math.max(120, Math.min(CFG.game.H - 120, p.y + Math.sin(a) * d)),
    r: 22,
    ...ev,
    done: false,
    _glow: 0,
    _near: false,
    _closest: false,
    _armedAt: state.time + INTERACTION_CFG.spawnGrace
  });
}

function activateEvent(ev, p) {
  try {
    if (ev.questNpcId && QUEST_NPC_REGISTRY.has(ev.questNpcId)) {
      QUEST_NPC_REGISTRY.get(ev.questNpcId).onInteract(ev, p);
    } else if (ev.questEventId && QUEST_WORLD_EVENT_REGISTRY.has(ev.questEventId)) {
      QUEST_WORLD_EVENT_REGISTRY.get(ev.questEventId).onTrigger(ev, p);
    } else {
      EVENT_HANDLERS[ev.kind]?.(ev, p);
    }
  } catch (err) {
    console.error('World event failed:', ev?.kind, err);
  }
  spawnParticles(ev.x, ev.y, ev.color, 20, 170);
  renderQuestTracker();
}

export function updateWorldEvents() {
  const p = state.player;
  if (!p || state.mode !== 'playing') return;
  const ev = INTERACTOR.update(events, p, state.time);
  if (ev) activateEvent(ev, p);
}

export function renderWorldEvents(ctx) {
  const t = performance.now() / 1000;
  const cam = state.camera;
  const hw = cam.worldW * 0.5 + 460; // margin covers the largest activation ring
  const hh = cam.worldH * 0.5 + 460;

  for (const ev of events) {
    if (Math.abs(ev.x - cam.x) > hw || Math.abs(ev.y - cam.y) > hh) continue;

    const marker = eventMarker(ev) || {};
    const icon = ev.icon || marker.icon || '✦';
    const g = ev._glow || 0;
    const speed = 2.2 + g * 2.4;
    const pulse = 0.5 + 0.5 * Math.sin(t * speed + ev.x * 0.01);

    // Soft glow (golden double halo on Quest NPCs & Quest Events)
    drawCircle(ctx, ev.x, ev.y, (ev.isQuestEvent ? 32 : 26) + pulse * 3, ev.color + '28');

    ctx.save();

    // Proximity feedback: breathing halo, faint activation ring, brighter when in range / closest
    if (g > 0.01) {
      ctx.globalAlpha = (0.10 + 0.26 * g) * (0.75 + 0.5 * pulse);
      drawCircle(ctx, ev.x, ev.y, 30 + g * (18 + pulse * 7), ev.color);
      if (ev._ix) {
        ctx.globalAlpha = (ev._near ? 0.30 : 0.12) * g * (0.8 + 0.4 * pulse);
        drawRing(ctx, ev.x, ev.y, ev._ix.r, ev.color, ev._closest ? 2.2 : 1.2);
      }
      ctx.globalAlpha = 1;
    }

    if (ev.isQuestEvent) {
      drawRing(ctx, ev.x, ev.y, 23 + pulse * 2.5, '#f4d68c88', 1.4);
    }

    // Pulsing outer ring
    ctx.beginPath();
    ctx.arc(ev.x, ev.y, 18 + pulse * 1.5 + g * 3, 0, Math.PI * 2);
    ctx.lineWidth = 1 + g;
    ctx.strokeStyle = ev.color + (g > 0.4 ? 'cc' : '66');
    ctx.stroke();

    // Medallion (swells slightly as the player approaches)
    const medR = 14 * (1 + g * 0.1 * (0.6 + pulse * 0.4));
    ctx.beginPath();
    ctx.arc(ev.x, ev.y, medR, 0, Math.PI * 2);
    ctx.fillStyle = '#0d0a12';
    ctx.fill();
    ctx.lineWidth = 2 + (ev._near ? 0.8 : 0);
    ctx.strokeStyle = ev.color;
    ctx.stroke();

    // Icon
    ctx.font = 'bold 14px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = ev.color;
    ctx.fillText(icon, ev.x, ev.y + 1);

    ctx.restore();

    drawText(ctx, ev.isQuestEvent ? `✦ ${ev.label}` : ev.label, ev.x, ev.y - 27, ev.color);
  }
}
