import { state } from '../core/game.js';
import { WorldTierConfig, DifficultyConfig } from '../data/worldTierData.js';
import { getDirectorMods } from './aiDirector.js';

export function getRunPhase(t = state.time) {
  const ps = DifficultyConfig.phases;
  for (let i = 0; i < ps.length; i++) {
    if (t < ps[i].max) return { idx: i, ...ps[i] };
  }
  return { idx: ps.length - 1, ...ps[ps.length - 1] };
}

export function getScaling() {
  const p = state.player;
  const t = state.time;
  const D = DifficultyConfig;
  const wt = WorldTierConfig.tiers[state.worldTier];
  const ph = getRunPhase(t);
  const dir = getDirectorMods();

  const bosses = p ? p.bossesDefeated.length : 0;
  const lvl = p ? p.level - 1 : 0;
  const ap = state.apocalypse ? D.apoc : null;
  const st = p?.stats;
  const dng = state.dungeon;
  const mc = state.modeCfg;

  const tHp = 1 + t * D.timeHpRate + Math.pow(t / 72, D.timeHpExp);
  const tDmg = 1 + t * D.timeDmgRate;
  const tSpd = Math.min(D.maxTimeSpd, 1 + t * D.timeSpdRate);

  return {
    ph,
    dir,
    wt,
    hp:
      tHp *
      (1 + lvl * D.lvlHp) *
      (1 + bosses * D.bossHp) *
      wt.hp *
      ph.hp *
      (ap ? ap.hp : 1) *
      (1 + (st?.enemyHpAdd || 0)) *
      dng.hpM,
    dmg: tDmg * (1 + lvl * D.lvlDmg) * (1 + bosses * D.bossDmg) * wt.dmg * ph.dmg * dir.dmg * (ap ? ap.dmg : 1),
    spd:
      tSpd *
      (1 + lvl * D.lvlSpd) *
      (1 + bosses * D.bossSpd) *
      wt.spd *
      ph.spd *
      dir.spd *
      state.enemySpeedMult *
      (ap ? ap.spd : 1) *
      (1 + (st?.enemySpdAdd || 0)),
    dens:
      (1 + lvl * D.lvlDens) *
      (1 + bosses * D.bossDens) *
      wt.dens *
      ph.dens *
      dir.dens *
      (ap ? ap.dens : 1) *
      (1 + mc.densAdd),
    eliteChance: Math.max(
      0.01,
      ph.elite + wt.eliteAdd + dir.elite + (ap ? ap.eliteBonus : 0) + dng.eliteAdd + mc.eliteAdd
    ),
    champPackChance: wt.champAdd + (state.apocalypse ? 0.08 : 0) + (state.gameMode === 'arena' ? 0.06 : 0),
    rewardMult: wt.reward * (ap ? ap.rewardMult : 1) * (1 + (st?.relicReward || 0)),
    fragMult: wt.frag * mc.fragMult * (ap ? 1.35 : 1)
  };
}