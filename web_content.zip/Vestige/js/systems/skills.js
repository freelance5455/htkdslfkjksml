import { hasUnlock } from '../core/save.js';
import { state, enemyGrid, qBuf, arcs, hazards, spawnParticles } from '../core/game.js';

import { nearestEnemy, targetForWeapon, getWeaponRange, getRangeMult, fireProj, hitEnemy, chainLightning } from '../entities/projectiles.js';
import { weaponMult } from './mastery.js';

const TAU = Math.PI * 2;

// ============================================================================
// SHARED COOLDOWN UTILITIES
// ============================================================================

/**
 * Per-target cooldown gate. Remembers when each target was last hit and only
 * lets it be hit again after `interval` seconds. Uses a WeakMap so pooled /
 * dead enemies never leak, and tolerates the game clock being reset between
 * runs (a stored time in the "future" counts as expired).
 */
function createTargetGate() {
  const last = new WeakMap();
  return {
    /** Returns true (and records the hit) if `target` may be hit now. */
    tryHit(target, now, interval) {
      const t = last.get(target);
      if (t !== undefined && now >= t && now - t < interval) return false;
      last.set(target, now);
      return true;
    }
  };
}

// ============================================================================
// SUN HAMMER
// ============================================================================
// Hammers orbit the player continuously (visual + hitbox), but damage is rate
// limited PER ENEMY. Previously the orbit hit every enemy in reach on every
// frame (only throttled by the 0.08s hit-flash), which spawned a stream of
// damage numbers, impacts, particles and chain lightning.
//
// Tuning knobs:
const SUNHAMMER = {
  hitInterval: 0.55, // seconds between hits on the same enemy
  evolvedHitInterval: 0.4,
  minInterval: 0.12, // hard floor so huge attack speed can never degrade to per-frame hits
  baseMult: 1.1, // damage multiplier per hit (hits are far less frequent than before)
  evolvedMult: 1.7,
  levelScale: 0.15, // +15% damage per weapon level above 1
  hitRadius: 16, // hammer head radius added to enemy radius
  broadphase: 28, // grid query radius
  chainChance: 0.2 // evolved: chance per hit to chain lightning
};

const sunHammerGate = createTargetGate();

function sunHammerGeometry(w, p, evoArea) {
  const count = 2 + w.level + (w.evolved ? 2 : 0);
  // The orbit can never extend past the hammer's attack range
  const radius = Math.min(
    75 * Math.min(1.8, 0.85 + p.stats.areaPct * 0.2 * (w.evolved ? evoArea : 1)),
    getWeaponRange('sunhammer')
  );
  return { count, radius };
}

function updateSunHammer(w, p, dt, rate, evoArea, wm) {
  // Orbit angle is its own field; it was previously stored in w.cd, which
  // doubled as an (unused) cooldown and grew without bound.
  w.orbit = ((w.orbit || 0) + dt * (2.5 + w.level * 0.25)) % TAU;

  const { count, radius } = sunHammerGeometry(w, p, evoArea);
  const base = w.evolved ? SUNHAMMER.evolvedHitInterval : SUNHAMMER.hitInterval;
  const interval = Math.max(SUNHAMMER.minInterval, base / Math.max(0.1, rate));
  const now = state.time;
  const dmgMult =
    (w.evolved ? SUNHAMMER.evolvedMult : SUNHAMMER.baseMult) * (1 + (w.level - 1) * SUNHAMMER.levelScale) * wm;

  for (let i = 0; i < count; i++) {
    const a = w.orbit + (TAU * i) / count;
    const hx = p.x + Math.cos(a) * radius;
    const hy = p.y + Math.sin(a) * radius;
    enemyGrid.query(hx, hy, SUNHAMMER.broadphase, qBuf);
    for (let j = 0; j < qBuf.length; j++) {
      const e = qBuf[j];
      if (!e.alive || e.spawnT > 0) continue;
      const reach = e.r + SUNHAMMER.hitRadius;
      if ((e.x - hx) ** 2 + (e.y - hy) ** 2 >= reach * reach) continue;
      // One hit per enemy per interval, no matter how many hammers overlap it.
      if (!sunHammerGate.tryHit(e, now, interval)) continue;

      hitEnemy(e, p.stats.flatDmg * p.stats.dmgPct * dmgMult, 0.05, true, 'sunhammer');
      if (w.evolved && Math.random() < SUNHAMMER.chainChance) {
        chainLightning(hx, hy, p.stats.flatDmg * p.stats.dmgPct * wm, 3, '#ffd700');
      }
    }
  }
}

// ============================================================================
// WEAPON UPDATE
// ============================================================================

export function updateWeapons(dt) {
  const p = state.player;
  const rate = p.stats.atkSpeed / (1 - p.stats.cdr);
  const evoArea = hasUnlock('evo_surge') ? 1.1 : 1;

  for (const [k, w] of Object.entries(p.weapons)) {
    const wm = weaponMult(k);

    if (k === 'sunhammer') {
      updateSunHammer(w, p, dt, rate, evoArea, wm);
      continue;
    }

    if (k === 'grimoire') continue;

    w.cd -= dt * rate;
    if (w.cd > 0) continue;

    // Auto-target only enemies inside this weapon's range; nothing in range = no attack
    const t = targetForWeapon(k);
    if (!t) {
      w.cd = 0; // stay ready, fire the moment something enters range
      continue;
    }

    if (k === 'greatsword') {
      w.cd = w.evolved ? 0.68 : 0.92;
      const arcR = Math.min(
        (105 + w.level * 12) * p.stats.areaPct * (w.evolved ? 1.35 * evoArea : 1),
        getWeaponRange(k)
      );
      arcs.push({ ring: { x: p.x, y: p.y, r: arcR }, life: 0.18, color: w.evolved ? '#ff2a4b' : '#e05656' });
      enemyGrid.query(p.x, p.y, arcR, qBuf);
      for (let i = 0; i < qBuf.length; i++) {
        const e = qBuf[i];
        if (e.alive && e.spawnT <= 0 && (e.x - p.x) ** 2 + (e.y - p.y) ** 2 <= (arcR + e.r) ** 2) {
          hitEnemy(
            e,
            p.stats.flatDmg * p.stats.dmgPct * (1.25 + w.level * 0.22) * (w.evolved ? 1.45 : 1) * wm,
            0.08,
            true,
            k
          );
        }
      }
    } else {
      const ba = Math.atan2(t.y - p.y, t.x - p.x);
      const fan = (cnt, spread, spd, dm, col, prc, life, hom, cb) => {
        for (let i = 0; i < cnt; i++) {
          const a = ba + (i - (cnt - 1) / 2) * spread;
          fireProj(p.x, p.y, Math.cos(a), Math.sin(a), spd, dm, col, prc, life, hom, cb, k);
        }
      };

      if (k === 'moonbow') {
        w.cd = w.evolved ? 0.34 : 0.48;
        fan(
          1 + p.stats.projBonus + ((w.level / 2) | 0) + (w.evolved ? 2 : 0),
          0.14,
          640,
          w.evolved ? 1.35 : 0.95,
          w.evolved ? '#d4deff' : '#8ec5ff',
          w.evolved ? 3 : 0,
          1.4,
          w.evolved,
          0.08
        );
      } else if (k === 'firestaff') {
        w.cd = w.evolved ? 0.72 : 1.05;
        fan(
          1 + p.stats.projBonus + (w.evolved ? 1 : 0),
          0.22,
          440,
          1.2 + w.level * 0.2,
          w.evolved ? '#ff4757' : '#ff8c38',
          0,
          1.5,
          false,
          0.05
        );
        if (w.evolved) {
          hazards.push({
            x: t.x,
            y: t.y,
            r: 85 * p.stats.areaPct * evoArea,
            dmg: p.stats.flatDmg * p.stats.dmgPct * 0.85 * wm,
            life: 1.4,
            maxLife: 1.4,
            color: '#ff6b3d',
            isEnemy: false
          });
        }
      } else if (k === 'shadowdagger') {
        w.cd = w.evolved ? 0.30 : 0.44;
        fan(
          2 + p.stats.projBonus + ((w.level / 2) | 0),
          0.18,
          680,
          w.evolved ? 1.2 : 0.8,
          w.evolved ? '#ff2a4b' : '#c56cf0',
          w.evolved ? 99 : 1,
          1.2,
          w.evolved,
          0.18
        );
      }
    }
  }
}

export function updatePeriodicProcs(dt) {
  const p = state.player;
  if (p.stats.uniques.has('forgottenstars') || (p.stats.sets.choir || 0) >= 6) {
    if ((state.meteorCd -= dt) <= 0) {
      state.meteorCd = 2.6;
      const t = nearestEnemy(p.x, p.y, 450 * getRangeMult());
      if (t) {
        hazards.push({
          x: t.x,
          y: t.y,
          r: 90 * p.stats.areaPct,
          dmg: p.stats.flatDmg * p.stats.dmgPct * 2.4,
          life: 0.28,
          maxLife: 0.28,
          color: '#8fa8ff',
          isEnemy: false
        });
        spawnParticles(t.x, t.y, '#8fa8ff', 16, 180);
      }
    }
  }
}

export function renderWeaponEffects(ctx) {
  const p = state.player;
  const w = p.weapons.sunhammer;
  if (!w) return;

  // Same geometry as the hitbox update, so what you see is what hits.
  const evoArea = hasUnlock('evo_surge') ? 1.1 : 1;
  const { count, radius } = sunHammerGeometry(w, p, evoArea);
  const orbit = w.orbit || 0;
  ctx.fillStyle = w.evolved ? '#ff8c00' : '#ffd700';
  for (let i = 0; i < count; i++) {
    const a = orbit + (TAU * i) / count;
    ctx.fillRect(p.x + Math.cos(a) * radius - 7, p.y + Math.sin(a) * radius - 7, 14, 14);
  }
}
