import { hasUnlock } from '../core/save.js';

export const DUNGEONS = [
  { id: 'none',      name: 'Ashen Expanse (Standard)',    req: null,        ashM: 1,    starM: 1,    voidM: 1,    flameM: 1,    hpM: 1,    eliteAdd: 0,    luckAdd: 0,    bossSpd: 1,    ancient: 0 },
  { id: 'dng_crypt', name: 'Crypt of Ash',                req: 'dng_crypt', ashM: 1.45, starM: 1,    voidM: 1,    flameM: 1,    hpM: 1.25, eliteAdd: 0,    luckAdd: 0,    bossSpd: 1,    ancient: 0 },
  { id: 'dng_spire', name: 'Celestial Spire',             req: 'dng_spire', ashM: 1,    starM: 1.6,  voidM: 1,    flameM: 1,    hpM: 1.1,  eliteAdd: 0.05, luckAdd: 0.1,  bossSpd: 1.2,  ancient: 0.2 },
  { id: 'dng_rift',  name: 'The Void Rift',               req: 'dng_rift',  ashM: 1,    starM: 1,    voidM: 1.6,  flameM: 1,    hpM: 1.15, eliteAdd: 0.35, luckAdd: 0.25, bossSpd: 1.1,  ancient: 0.3 },
  { id: 'dng_abyss', name: 'Endless Sanctum (Endgame)',   req: 'dng_abyss', ashM: 1.35, starM: 1.35, voidM: 1.35, flameM: 1.35, hpM: 1.3,  eliteAdd: 0.25, luckAdd: 0.35, bossSpd: 1.15, ancient: 0.6 }
];

export const getUnlockedDungeons = () =>
  DUNGEONS.filter(d => !d.req || hasUnlock(d.req));

export const getDungeonById = id =>
  DUNGEONS.find(d => d.id === id) || DUNGEONS[0];