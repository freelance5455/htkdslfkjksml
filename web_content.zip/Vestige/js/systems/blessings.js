import { mk } from '../core/utilities.js';
import { hasUnlock } from '../core/save.js';
import { sfx } from '../core/audio.js';
import { state } from '../core/game.js';

import * as classesMod from '../data/classes.js';
import { BLESSINGS_DATA } from '../data/blessingsData.js';

import { recalcStats } from '../entities/player.js';
import { DOM, updateHud } from '../ui/hud.js';

const PATH_BY_TAG = {
  Offense: 'Warfare',
  Crit: 'Shadow',
  Speed: 'Warfare',
  Area: 'Arcane',
  Projectile: 'Warfare',
  Defense: 'Holy',
  Sustain: 'Holy',
  Caster: 'Arcane',
  Magnet: 'Death',
  Summon: 'Death'
};

const DEFAULT_CLASS_WEIGHTS = {
  warrior:     { Warfare: 4.0, Holy: 1.4, Shadow: 0.9, Arcane: 0.4, Death: 0.4, Cosmic: 0.4 },
  mage:        { Arcane: 4.0, Cosmic: 3.0, Shadow: 0.9, Holy: 0.6, Death: 0.7, Warfare: 0.4 },
  necromancer: { Death: 4.2, Shadow: 1.5, Arcane: 1.2, Cosmic: 0.8, Warfare: 0.4, Holy: 0.2 },
  ranger:      { Warfare: 3.3, Shadow: 2.6, Cosmic: 1.0, Arcane: 0.6, Holy: 0.6, Death: 0.4 },
  assassin:    { Shadow: 4.2, Warfare: 1.6, Death: 1.3, Cosmic: 1.0, Arcane: 0.5, Holy: 0.3 },
  paladin:     { Holy: 4.2, Warfare: 2.0, Arcane: 0.6, Cosmic: 0.6, Shadow: 0.3, Death: 0.2 }
};

const FACTION_CONFIG = {
  Warfare: {
    icon: '⚔️',
    rune: 'ᛟ',
    color: '#ff6b4a',
    glow: 'rgba(255, 107, 74, 0.36)',
    surface: 'rgba(130, 34, 20, 0.24)'
  },
  Arcane: {
    icon: '🔮',
    rune: 'ᚲ',
    color: '#5ca8ff',
    glow: 'rgba(92, 168, 255, 0.38)',
    surface: 'rgba(28, 66, 138, 0.26)'
  },
  Holy: {
    icon: '☀️',
    rune: 'ᛇ',
    color: '#ffd666',
    glow: 'rgba(255, 214, 102, 0.4)',
    surface: 'rgba(148, 112, 26, 0.25)'
  },
  Death: {
    icon: '💀',
    rune: 'ᚦ',
    color: '#5effa8',
    glow: 'rgba(94, 255, 168, 0.34)',
    surface: 'rgba(20, 96, 62, 0.26)'
  },
  Shadow: {
    icon: '🗡️',
    rune: 'ᛉ',
    color: '#b87dff',
    glow: 'rgba(184, 125, 255, 0.38)',
    surface: 'rgba(72, 30, 122, 0.28)'
  },
  Cosmic: {
    icon: '🌌',
    rune: '✦',
    color: '#ff66d9',
    glow: 'rgba(255, 102, 217, 0.42)',
    surface: 'rgba(116, 24, 96, 0.28)'
  }
};

const RARITY_CONFIG = {
  common: {
    cls: 'tarot-rarity-common',
    label: 'Blessed Page',
    crest: '•',
    accent: '#c5b79c'
  },
  rare: {
    cls: 'tarot-rarity-rare',
    label: 'Rare Decree',
    crest: '◆',
    accent: '#63b3ff'
  },
  legendary: {
    cls: 'tarot-rarity-legendary',
    label: 'Exalted Relic',
    crest: '✦',
    accent: '#ffb347'
  },
  mythic: {
    cls: 'tarot-rarity-mythic',
    label: 'Mythic Awakening',
    crest: '❖',
    accent: '#f06bff'
  }
};

let currentOfferingNames = [];
let isShuffling = false;

function ensureFateStyles() {
  if (typeof document === 'undefined' || document.getElementById('fate-reroll-styles')) return;
  const style = document.createElement('style');
  style.id = 'fate-reroll-styles';
  style.textContent = `
    #levelup-modal .modal-box {
      max-width: 920px !important;
      background:
        radial-gradient(circle at 50% 0%, rgba(224, 178, 88, 0.16), transparent 58%),
        radial-gradient(circle at 50% 100%, rgba(118, 44, 148, 0.12), transparent 55%),
        linear-gradient(180deg, #17121e 0%, #0b0910 100%);
      border: 1.5px solid #9c7938;
      box-shadow:
        inset 0 0 0 1px rgba(248, 220, 148, 0.18),
        inset 0 0 42px rgba(0, 0, 0, 0.78),
        0 28px 90px rgba(0, 0, 0, 0.92);
    }

    #lvlup-title {
      font-size: 26px !important;
      letter-spacing: 2px;
      text-shadow: 0 0 18px rgba(244, 214, 140, 0.42);
    }

    #upgrade-cards {
      gap: 16px !important;
      perspective: 1100px;
      align-items: stretch;
    }

    #upgrade-cards .card.tarot-card {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      justify-content: space-between;
      min-height: 292px;
      padding: 16px 15px 14px;
      border-radius: 10px;
      cursor: pointer;
      overflow: hidden;
      background:
        radial-gradient(circle at 50% 24%, var(--faction-surface, rgba(201, 160, 80, 0.12)), transparent 62%),
        linear-gradient(180deg, #1f1928 0%, #110d17 65%, #0c0911 100%);
      border: 1.5px solid #6c5733;
      box-shadow:
        0 10px 26px rgba(0, 0, 0, 0.65),
        inset 0 0 22px rgba(0, 0, 0, 0.55);
      transition: transform 0.2s cubic-bezier(0.22, 1, 0.36, 1), box-shadow 0.22s ease, border-color 0.2s ease, filter 0.18s ease;
    }

    /* Decorative Sacred Reliquary Inner Frame */
    #upgrade-cards .card.tarot-card::before {
      content: '';
      position: absolute;
      inset: 6px;
      border-radius: 7px;
      border: 1px solid rgba(244, 214, 140, 0.2);
      pointer-events: none;
    }

    #upgrade-cards .card.tarot-card::after {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(125deg, rgba(255, 255, 255, 0.06) 0%, transparent 38%, transparent 65%, rgba(244, 214, 140, 0.04) 100%);
      pointer-events: none;
    }

    #upgrade-cards .card.tarot-card:hover {
      transform: translateY(-7px) scale(1.025);
      filter: brightness(1.1);
    }

    /* Rarity Card Styling */
    #upgrade-cards .card.tarot-rarity-common {
      border-color: #7c6844;
    }
    #upgrade-cards .card.tarot-rarity-common:hover {
      border-color: #c9a050;
      box-shadow: 0 14px 30px rgba(0, 0, 0, 0.72), 0 0 22px var(--faction-glow, rgba(201, 160, 80, 0.28));
    }

    #upgrade-cards .card.tarot-rarity-rare {
      border-color: #4f9cff;
      background:
        radial-gradient(circle at 50% 18%, rgba(79, 156, 255, 0.22), transparent 60%),
        linear-gradient(180deg, #172136 0%, #0e1321 70%, #090c16 100%);
      box-shadow:
        0 10px 28px rgba(0, 0, 0, 0.72),
        0 0 18px rgba(79, 156, 255, 0.26),
        inset 0 0 24px rgba(79, 156, 255, 0.14);
    }
    #upgrade-cards .card.tarot-rarity-rare::before {
      border-color: rgba(132, 194, 255, 0.42);
    }
    #upgrade-cards .card.tarot-rarity-rare:hover {
      box-shadow: 0 16px 34px rgba(0, 0, 0, 0.8), 0 0 28px rgba(79, 156, 255, 0.46);
    }

    #upgrade-cards .card.tarot-rarity-legendary {
      border-color: #ff9c38;
      background:
        radial-gradient(circle at 50% 16%, rgba(255, 156, 56, 0.28), transparent 60%),
        linear-gradient(180deg, #2d1b10 0%, #170e09 70%, #0e0806 100%);
      box-shadow:
        0 12px 30px rgba(0, 0, 0, 0.78),
        0 0 22px rgba(255, 145, 42, 0.38),
        inset 0 0 26px rgba(255, 130, 32, 0.18);
    }
    #upgrade-cards .card.tarot-rarity-legendary::before {
      border-color: rgba(255, 206, 122, 0.55);
      box-shadow: inset 0 0 12px rgba(255, 160, 64, 0.16);
    }
    #upgrade-cards .card.tarot-rarity-legendary:hover {
      box-shadow: 0 18px 38px rgba(0, 0, 0, 0.84), 0 0 34px rgba(255, 156, 56, 0.58);
    }

    #upgrade-cards .card.tarot-rarity-mythic {
      border-color: #e95cff;
      background:
        radial-gradient(circle at 50% 16%, rgba(233, 92, 255, 0.3), transparent 58%),
        radial-gradient(circle at 50% 88%, rgba(255, 210, 118, 0.16), transparent 55%),
        linear-gradient(180deg, #291333 0%, #14091b 70%, #0b0510 100%);
      box-shadow:
        0 14px 34px rgba(0, 0, 0, 0.84),
        0 0 26px rgba(233, 92, 255, 0.44),
        0 0 12px rgba(255, 214, 122, 0.3),
        inset 0 0 28px rgba(212, 62, 245, 0.24);
      animation: tarotMythicGlow 3s ease-in-out infinite;
    }
    #upgrade-cards .card.tarot-rarity-mythic::before {
      border-color: rgba(248, 184, 255, 0.62);
    }
    #upgrade-cards .card.tarot-rarity-mythic:hover {
      box-shadow: 0 18px 42px rgba(0, 0, 0, 0.88), 0 0 38px rgba(233, 92, 255, 0.68), 0 0 18px rgba(255, 218, 130, 0.45);
    }

    @keyframes tarotMythicGlow {
      0%, 100% {
        box-shadow: 0 14px 34px rgba(0,0,0,0.84), 0 0 22px rgba(233, 92, 255, 0.38), inset 0 0 24px rgba(212, 62, 245, 0.2);
      }
      50% {
        box-shadow: 0 14px 34px rgba(0,0,0,0.84), 0 0 32px rgba(233, 92, 255, 0.62), inset 0 0 30px rgba(233, 92, 255, 0.32);
      }
    }

    .tarot-top-bar {
      position: relative;
      z-index: 1;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 10px;
      font-weight: 800;
      letter-spacing: 0.9px;
      text-transform: uppercase;
      color: var(--rarity-accent, #c5b79c);
      padding: 0 4px;
    }

    .tarot-rune-corner {
      font-size: 12px;
      opacity: 0.85;
      color: var(--faction-color, var(--gold2));
      text-shadow: 0 0 8px var(--faction-glow, transparent);
    }

    .tarot-medallion {
      position: relative;
      z-index: 1;
      width: 62px;
      height: 62px;
      margin: 10px auto 8px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 31px;
      background: radial-gradient(circle at 50% 35%, rgba(255, 255, 255, 0.14), rgba(10, 8, 15, 0.95));
      border: 2px solid var(--faction-color, var(--gold2));
      box-shadow:
        0 0 20px var(--faction-glow, rgba(201, 160, 80, 0.3)),
        inset 0 0 12px rgba(0, 0, 0, 0.82);
    }

    .tarot-medallion::after {
      content: '';
      position: absolute;
      inset: -5px;
      border-radius: 50%;
      border: 1px dashed rgba(244, 214, 140, 0.32);
      pointer-events: none;
    }

    .tarot-faction-tag {
      position: relative;
      z-index: 1;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 2px 9px;
      border-radius: 99px;
      font-size: 10.5px;
      font-weight: 800;
      letter-spacing: 0.7px;
      text-transform: uppercase;
      color: var(--faction-color, var(--gold));
      background: rgba(0, 0, 0, 0.42);
      border: 1px solid rgba(255, 255, 255, 0.12);
    }

    .tarot-title {
      position: relative;
      z-index: 1;
      margin: 10px 0 4px;
      font-size: 19px;
      font-weight: 800;
      line-height: 1.2;
      color: #fbf6eb;
      text-shadow: 0 2px 6px rgba(0, 0, 0, 0.85);
    }

    .tarot-divider {
      position: relative;
      z-index: 1;
      width: 72%;
      margin: 6px auto;
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--faction-color, var(--gold));
      font-size: 10px;
      opacity: 0.75;
    }

    .tarot-divider::before,
    .tarot-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: linear-gradient(90deg, transparent, rgba(244, 214, 140, 0.45), transparent);
    }

    .tarot-desc {
      position: relative;
      z-index: 1;
      font-size: 13px;
      line-height: 1.45;
      color: #d7cfdf;
      margin: 4px 0 12px;
      padding: 0 4px;
    }

    .tarot-footer-key {
      position: relative;
      z-index: 1;
      font-size: 11px;
      font-weight: 800;
      letter-spacing: 1px;
      text-transform: uppercase;
      color: var(--gold2);
      padding: 4px 12px;
      border-radius: 4px;
      background: rgba(0, 0, 0, 0.45);
      border: 1px solid rgba(201, 160, 80, 0.35);
    }

    .tarot-card-back {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 10px;
      height: 100%;
      min-height: 248px;
      color: var(--gold2);
    }

    .tarot-back-sigil {
      width: 68px;
      height: 68px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 28px;
      border: 2px solid rgba(244, 214, 140, 0.65);
      box-shadow: 0 0 24px rgba(244, 214, 140, 0.32), inset 0 0 16px rgba(244, 214, 140, 0.16);
    }

    #fate-reroll-wrap {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 7px;
      margin-top: 18px;
    }

    #btn-fate-reroll {
      background: linear-gradient(180deg, #422e15, #1f150a);
      border: 2px solid var(--gold2);
      color: var(--gold2);
      border-radius: 6px;
      padding: 11px 28px;
      font-weight: 800;
      font-size: 14px;
      letter-spacing: 0.7px;
      cursor: pointer;
      box-shadow: 0 0 22px rgba(201, 160, 80, 0.36), inset 0 1px 0 rgba(255, 255, 255, 0.18);
      transition: transform 0.14s ease, box-shadow 0.18s ease, filter 0.15s ease;
    }

    #btn-fate-reroll:hover:not(:disabled) {
      transform: translateY(-2px) scale(1.03);
      box-shadow: 0 0 30px rgba(244, 214, 140, 0.56), inset 0 1px 0 rgba(255, 255, 255, 0.28);
      filter: brightness(1.15);
    }

    #btn-fate-reroll:active:not(:disabled) {
      transform: scale(0.96);
    }

    #btn-fate-reroll:disabled {
      opacity: 0.55;
      border-color: #6b3842;
      color: #d99aa3;
      cursor: not-allowed;
      box-shadow: none;
    }

    #upgrade-cards .card.fate-flip-out {
      animation: fateFlipOut 0.24s cubic-bezier(0.55, 0.06, 0.68, 0.19) forwards;
    }

    #upgrade-cards .card.fate-shuffling {
      animation: fateShufflePulse 0.16s ease-in-out infinite alternate;
    }

    #upgrade-cards .card.fate-roll-in {
      animation: fateRollIn 0.36s cubic-bezier(0.22, 1, 0.36, 1) backwards;
    }

    @keyframes fateFlipOut {
      0%   { transform: perspective(750px) rotateY(0deg) scale(1); opacity: 1; }
      100% { transform: perspective(750px) rotateY(90deg) translateY(-6px) scale(0.88); opacity: 0.12; }
    }

    @keyframes fateShufflePulse {
      0%   { transform: translateY(0) rotate(-1.6deg) scale(0.94); opacity: 0.65; }
      100% { transform: translateY(-7px) rotate(1.6deg) scale(0.98); opacity: 0.92; }
    }

    @keyframes fateRollIn {
      0%   { transform: perspective(750px) rotateY(-88deg) translateY(14px) scale(0.86); opacity: 0; }
      100% { transform: perspective(750px) rotateY(0deg) translateY(0) scale(1); opacity: 1; }
    }
  `;
  document.head.appendChild(style);
}

function ensureFateState(p) {
  if (p.fateRerollsUsed === undefined) p.fateRerollsUsed = 0;
  if (p.freeFateCharges === undefined) p.freeFateCharges = 0;
}

export function getFateRerollCost(p = state.player) {
  if (!p) return 0;
  ensureFateState(p);
  if (p.freeFateCharges > 0 || p.fateRerollsUsed === 0) return 0;
  return 25 * (2 ** (p.fateRerollsUsed - 1));
}

function resolveBlessingPath(b) {
  if (b.path && FACTION_CONFIG[b.path]) return b.path;
  if (b.tag) {
    const prefix = b.tag.split('•')[0].trim();
    if (PATH_BY_TAG[prefix]) return PATH_BY_TAG[prefix];
    if (FACTION_CONFIG[prefix]) return prefix;
  }
  return 'Warfare';
}

function inferWeaponFaction(key, def) {
  if (def.path && FACTION_CONFIG[def.path]) return def.path;
  const text = `${key} ${def.name || ''} ${def.evolved || ''} ${def.catName || ''}`.toLowerCase();
  if (/cosmic|star|astral|meteor|void|galaxy|eclipse|comet|nebula/.test(text)) return 'Cosmic';
  if (/holy|sun|radiant|light|sanct|smite|divine|seraph|halo|hammer|paladin/.test(text)) return 'Holy';
  if (/death|scythe|necro|bone|grave|soul|plague|wraith|skull|blood|reap/.test(text)) return 'Death';
  if (/shadow|dagger|knife|fang|night|shade|assassin|cloak|venom|kunai/.test(text)) return 'Shadow';
  if (/arcane|wand|staff|orb|bolt|spell|frost|fire|flame|lightning|storm|rune|sigil/.test(text)) return 'Arcane';
  return 'Warfare';
}

function normalizeBlessingRarity(raw, fallback = 'common') {
  if (!raw) return fallback;
  const key = String(raw).toLowerCase();
  if (key === 'mythic' || key === 'ancient' || key === 'celestial') return 'mythic';
  if (key === 'legendary' || key === 'epic' || key === 'exalted') return 'legendary';
  if (key === 'rare' || key === 'magic' || key === 'uncommon') return 'rare';
  return 'common';
}

function inferBlessingRarity(b) {
  if (b.rarity) return normalizeBlessingRarity(b.rarity);
  if (b.tier) return normalizeBlessingRarity(b.tier);
  const tagText = `${b.tag || ''} ${b.name || ''}`.toLowerCase();
  if (/mythic|ascendant|keystone|singularity|apotheosis/.test(tagText)) return 'mythic';
  if (/legendary|mastery|supreme|titan|arch/.test(tagText)) return 'legendary';
  if (/projectile|crit|summon|cosmic|area/.test(tagText)) return 'rare';
  return 'common';
}

function buildUnifiedBlessingPool(p) {
  const weights =
    (classesMod.CLASS_BLESSING_WEIGHTS && classesMod.CLASS_BLESSING_WEIGHTS[p.cls.id]) ||
    DEFAULT_CLASS_WEIGHTS[p.cls.id] ||
    {};

  const pool = BLESSINGS_DATA.map(b => {
    const faction = resolveBlessingPath(b);
    return {
      tag: b.tag,
      name: b.name,
      desc: b.desc,
      apply: () => b.apply(p),
      weight: weights[faction] || 1.0,
      faction,
      rarity: inferBlessingRarity(b)
    };
  });

  const weaponsDef = classesMod.WEAPONS_DEF || {};
  for (const [k, def] of Object.entries(weaponsDef)) {
    const cur = p.weapons[k];
    const faction = inferWeaponFaction(k, def);

    if (!cur) {
      pool.push({
        tag: 'New Weapon',
        name: def.name,
        desc: `Unlock ${def.name} (Evolves with ${def.catName})`,
        apply: () => { p.weapons[k] = { level: 1, cd: 0, evolved: false }; },
        weight: 2.2,
        faction,
        rarity: 'legendary'
      });
    } else if (cur.level < 5) {
      pool.push({
        tag: 'Weapon Rank',
        name: `${def.name} +1`,
        desc: `Upgrade ${def.name} to Lv.${cur.level + 1}`,
        apply: () => { cur.level++; },
        weight: 2.6,
        faction,
        rarity: cur.level >= 4 ? 'legendary' : 'rare'
      });
    }
    if (cur && !p.catalysts.has(def.catalyst)) {
      const catWeight = hasUnlock('evo_catalyst') ? 4.4 : 2.3;
      pool.push({
        tag: 'Evolution Catalyst',
        name: def.catName,
        desc: `Relic needed to evolve ${def.name} → ${def.evolved} (at Lv.3+)`,
        apply: () => { p.catalysts.add(def.catalyst); },
        weight: catWeight,
        faction,
        rarity: 'mythic'
      });
    }
  }

  return pool;
}

function weightedPick(pool) {
  const total = pool.reduce((sum, item) => sum + Math.max(0.01, item.weight), 0);
  let r = Math.random() * total;
  for (let i = 0; i < pool.length; i++) {
    r -= Math.max(0.01, pool[i].weight);
    if (r <= 0) return pool.splice(i, 1)[0];
  }
  return pool.pop();
}

export function buildBlessingChoices(excludeNames = []) {
  const p = state.player;
  const excludeSet = new Set(excludeNames);

  const rollSet = () => {
    const pool = buildUnifiedBlessingPool(p).map(entry => ({
      ...entry,
      weight: excludeSet.has(entry.name) ? entry.weight * 0.05 : entry.weight
    }));
    const picks = [];
    for (let i = 0; i < 3 && pool.length; i++) {
      picks.push(weightedPick(pool));
    }
    return picks;
  };

  let picks = rollSet();
  if (excludeSet.size > 0) {
    const sameCount = picks.filter(c => excludeSet.has(c.name)).length;
    if (sameCount === picks.length) {
      picks = rollSet();
    }
  }

  return picks.map(c => {
    const tuple = [c.tag, c.name, c.desc, c.apply];
    tuple.meta = {
      faction: c.faction,
      rarity: c.rarity
    };
    return tuple;
  });
}

function resolveChoiceMeta(choice) {
  const [tag, name] = choice;
  if (choice.meta) return choice.meta;

  const faction = resolveBlessingPath({ tag, name });
  const rarity = inferBlessingRarity({ tag, name });
  return { faction, rarity };
}

function createBlessingCard(choice, index, animateRollIn) {
  const [tag, name, desc, fn] = choice;
  const { faction, rarity } = resolveChoiceMeta(choice);
  const fac = FACTION_CONFIG[faction] || FACTION_CONFIG.Warfare;
  const rar = RARITY_CONFIG[rarity] || RARITY_CONFIG.common;

  const card = mk(
    'div',
    `card tarot-card sans ${rar.cls} ${animateRollIn ? 'fate-roll-in' : ''}`,
    `
      <div class="tarot-top-bar">
        <span class="tarot-rune-corner">${fac.rune}</span>
        <span>${rar.crest} ${rar.label}</span>
        <span class="tarot-rune-corner">${fac.rune}</span>
      </div>
      <div style="width:100%;">
        <div class="tarot-medallion">${fac.icon}</div>
        <div class="tarot-faction-tag">${faction} • ${tag}</div>
        <h3 class="tarot-title">${name}</h3>
        <div class="tarot-divider"><span>✦</span></div>
        <div class="tarot-desc">${desc}</div>
      </div>
      <div class="tarot-footer-key">[ Key ${index + 1} ]</div>
    `
  );

  card.style.setProperty('--faction-color', fac.color);
  card.style.setProperty('--faction-glow', fac.glow);
  card.style.setProperty('--faction-surface', fac.surface);
  card.style.setProperty('--rarity-accent', rar.accent);

  if (animateRollIn) {
    card.style.animationDelay = `${index * 85}ms`;
  }

  card.onclick = () => {
    if (!isShuffling) applyBlessingChoice(fn);
  };

  return card;
}

function createShuffleBackHTML() {
  return `
    <div class="tarot-card-back">
      <div class="tarot-back-sigil">🎲</div>
      <div style="font-size:12px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase;">✦ Fate Shifting ✦</div>
      <div style="font-size:10.5px;color:#b8ad96;">Drawing from the Reliquary...</div>
    </div>
  `;
}

function ensureFateButton() {
  ensureFateStyles();
  const modalBox = DOM['levelup-modal']?.querySelector('.modal-box');
  if (!modalBox) return null;

  let wrap = modalBox.querySelector('#fate-reroll-wrap');
  if (!wrap) {
    wrap = mk(
      'div',
      'sans',
      `<button id="btn-fate-reroll" title="Spend Gold to shuffle and draw a new set of Blessings.">🎲 Fate Reroll (Free)</button>
       <div id="fate-gold-note" style="font-size:11.5px;color:var(--ash);"></div>`
    );
    wrap.id = 'fate-reroll-wrap';
    modalBox.appendChild(wrap);
  }
  return wrap.querySelector('#btn-fate-reroll');
}

function updateFateButton() {
  const btn = ensureFateButton();
  const note = DOM['levelup-modal']?.querySelector('#fate-gold-note');
  if (!btn) return;

  const p = state.player;
  if (!p) return;

  const cost = getFateRerollCost(p);
  const canAfford = state.runGold >= cost;
  const costLabel = cost === 0 ? 'Free' : `${cost}G`;

  btn.title = 'Spend Gold to roll a new set of Blessings.';
  btn.disabled = isShuffling || !canAfford;

  btn.textContent = canAfford
    ? `🎲 Fate Reroll • ${costLabel}`
    : `🎲 Fate Reroll • ${costLabel} (Need ${cost - state.runGold}G)`;

  if (note) {
    note.textContent = `Vault Gold: ${state.runGold}G • Click to redraw all three Tarot Blessings`;
  }

  btn.onclick = () => rerollFateOfferings();
}

export function renderBlessingScreen(choices = null, animateRollIn = false) {
  ensureFateStyles();
  const p = state.player;
  if (!p) return;

  const g = DOM['upgrade-cards'];
  const list = choices || buildBlessingChoices();

  currentOfferingNames = list.map(c => c[1]);
  g.innerHTML = '';

  list.forEach((choice, i) => {
    g.appendChild(createBlessingCard(choice, i, animateRollIn));
  });

  DOM['lvlup-title'].textContent = `LEVEL ${p.level} — FLAME AWAKENED`;
  updateFateButton();
}

export function rerollFateOfferings() {
  const p = state.player;
  if (!p || isShuffling) return;

  const cost = getFateRerollCost(p);
  if (state.runGold < cost) {
    updateFateButton();
    return;
  }

  state.runGold -= cost;
  if (p.freeFateCharges > 0 && cost === 0 && p.fateRerollsUsed > 0) {
    p.freeFateCharges--;
  } else {
    p.fateRerollsUsed++;
  }

  isShuffling = true;
  updateFateButton();
  sfx.play('dash');

  const g = DOM['upgrade-cards'];
  const cards = Array.from(g.children);
  cards.forEach(c => c.classList.add('fate-flip-out'));

  setTimeout(() => {
    cards.forEach((c, idx) => {
      c.classList.remove('fate-flip-out');
      c.classList.add('fate-shuffling');
      c.style.animationDelay = `${idx * 65}ms`;
      c.innerHTML = createShuffleBackHTML();
    });

    setTimeout(() => {
      const nextChoices = buildBlessingChoices(currentOfferingNames);
      isShuffling = false;
      sfx.play('gem');
      renderBlessingScreen(nextChoices, true);
      updateHud();
    }, 240);
  }, 240);
}

export function applyBlessingChoice(fn) {
  fn();
  recalcStats();
  DOM['levelup-modal'].classList.remove('active');
  state.mode = 'playing';
  updateHud();
}

export function openLevelUp() {
  isShuffling = false;
  state.mode = 'levelup';
  sfx.play('levelup');
  renderBlessingScreen(buildBlessingChoices(), false);
  DOM['levelup-modal'].classList.add('active');
}