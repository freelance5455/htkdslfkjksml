import { state } from '../core/game.js';
import { SLOTS } from '../data/items.js';
import { DirectorConfig } from '../data/worldTierData.js';

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const clamp01 = v => clamp(v, 0, 1);
const lerp = (a, b, t) => a + (b - a) * clamp01(t);
const ema = (prev, sample, alpha = 0.35) => prev * (1 - alpha) + sample * alpha;

function ensureTrackingFields(d, p) {
  if (d.moveEma === undefined) {
    d.moveEma = 1;
    d.stillSec = 0;
    d.lastX = p.x;
    d.lastY = p.y;
    d.buildScore = 1;
    d.pressure = 0;
  }
}

function measureBuildStrength(p) {
  const eqSum = SLOTS.reduce((sum, slot) => sum + (p.equipped[slot]?.score || 22), 0);
  const expectedGear = (65 + p.level * 7.5) * SLOTS.length;
  const gearRatio = eqSum / expectedGear;

  const evoCount = Object.values(p.weapons || {}).filter(w => w.evolved).length;
  const keystoneCount = p.stats?.keystones?.size || 0;
  const statBurst =
    ((p.stats?.flatDmg || 15) * (p.stats?.dmgPct || 1)) / (28 + p.level * 4);

  return clamp(gearRatio * 0.52 + statBurst * 0.36 + evoCount * 0.14 + keystoneCount * 0.08, 0.45, 2.4);
}

export function updateDirector(dt) {
  const d = state.director;
  const p = state.player;
  if (!p) return;

  ensureTrackingFields(d, p);
  if ((d.tickCd += dt) < DirectorConfig.tickSec) return;
  const tickDt = d.tickCd;
  d.tickCd = 0;

  // 1) Track Movement & Anti-Comfort Stillness
  const movedDist = Math.hypot(p.x - d.lastX, p.y - d.lastY);
  d.lastX = p.x;
  d.lastY = p.y;
  const expectedMove = Math.max(40, (p.stats?.moveSpeed || 200) * tickDt * 0.45);
  d.moveEma = ema(d.moveEma, clamp(movedDist / expectedMove, 0, 1.6), 0.4);
  d.stillSec = movedDist < 24 ? Math.min(12, d.stillSec + tickDt) : Math.max(0, d.stillSec - tickDt * 2.0);

  // 2) Track Damage Taken, Kill Speed & DPS
  d.dpsEma = ema(d.dpsEma, d.fDmg / tickDt);
  d.killsEma = ema(d.killsEma, d.fKills / tickDt);
  d.takenEma = ema(d.takenEma, d.fTaken / tickDt);
  d.fDmg = d.fKills = d.fTaken = 0;

  const expDps = 34 + state.time * 1.45 + p.level * 15;
  const expKills = 1.2 + state.time * 0.013;

  const dmgScore = clamp(d.dpsEma / expDps, 0.3, 2.2);
  const killScore = clamp(d.killsEma / expKills, 0.25, 2.1);
  const takenRatio = d.takenEma / Math.max(1, p.maxHp * 0.28);
  const hpRatio = p.hp / Math.max(1, p.maxHp);

  // Surviving effortlessly with minimal damage taken drives comfort pressure up
  const comfortScore = clamp(
    hpRatio * 0.95 - takenRatio * 0.55 + Math.min(0.35, (p.stats?.armor || 0) / 90),
    0.1,
    1.6
  );

  // 3) Track Build Strength
  d.buildScore = measureBuildStrength(p);

  const bossProgress = 0.85 + p.bossesDefeated.length * 0.16;
  const rawPower =
    dmgScore * 0.25 +
    killScore * 0.22 +
    comfortScore * 0.23 +
    d.buildScore * 0.20 +
    bossProgress * 0.10;

  d.power = clamp(ema(d.power, rawPower, 0.4), DirectorConfig.minPower, DirectorConfig.maxPower);

  // Normalized pressure scalar [-1..+1.5]: ramps harder when outscaling, unhurt, or standing still
  const outscaleBonus = Math.max(0, d.buildScore - 1.12) * 0.55 + Math.max(0, dmgScore - 1.2) * 0.35;
  const stillPenalty = d.stillSec >= 2.2 ? clamp01((d.stillSec - 2.2) / 6.0) * 0.75 : 0;
  const baseNorm = (d.power - 0.95) / 0.65;
  d.pressure = clamp(baseNorm + outscaleBonus + stillPenalty, -1.0, 1.5);
}

export function getDirectorMods() {
  const d = state.director;
  const p = state.player;
  const hpR = p ? p.hp / Math.max(1, p.maxHp) : 1;
  const pw = d.power ?? 1;
  const pr = d.pressure ?? 0;
  const strong = DirectorConfig.strong;
  const weak = DirectorConfig.weak;

  // Low-HP / struggling recovery window (disabled if player is merely standing still)
  if ((pw <= DirectorConfig.lowThresh || hpR < 0.36) && (d.stillSec || 0) < 2.5) {
    const t = clamp01((DirectorConfig.lowThresh - pw) / 0.35 + (0.36 - Math.min(0.36, hpR)));
    return {
      dens: lerp(1.0, weak.dens, t),
      elite: lerp(0, weak.elite, t),
      champ: 0,
      eventCd: lerp(1.0, weak.eventCd, t),
      spd: lerp(1.0, weak.spd, t),
      dmg: lerp(1.0, weak.dmg, t),
      recovery: 1
    };
  }

  // Continuous challenge normalization & high-pressure escalation
  const push = clamp(pr, 0, 1.5);
  return {
    dens: 1 + push * (strong.dens - 1) * 0.95,
    elite: push * (strong.elite + 0.04),
    champ: push * 0.14,
    eventCd: Math.max(0.54, 1 - push * (1 - strong.eventCd) * 1.15),
    spd: 1 + push * (strong.spd - 1) * 1.1,
    dmg: 1 + push * (strong.dmg - 1) * 1.15,
    recovery: 0
  };
}