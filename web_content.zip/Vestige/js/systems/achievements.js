import { metaSave, persistSave } from '../core/save.js';
import { addFeed } from '../ui/notifications.js';

export function unlockAchievement(name) {
  if (metaSave.achievements.includes(name)) return;
  metaSave.achievements.push(name);
  addFeed(`Achievement: ${name}`, '#ffd700');
  persistSave();
}