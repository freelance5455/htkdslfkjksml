import { mk } from '../core/utilities.js';
import { state } from '../core/game.js';
import { RARITIES, SLOT_LABELS, SETS } from '../data/items.js';
import { recalcStats } from '../entities/player.js';
import * as equipmentSys from './equipment.js';
import { addFeed } from '../ui/notifications.js';

const SLOT_ICONS = {
  weapon: '⚔',
  helmet: '🪖',
  chest: '🛡',
  ring: '💍',
  ring1: '💍',
  ring2: '💍',
  amulet: '📿',
  relic: '✦'
};

const SUBTYPE_ICONS = {
  Sword: '⚔',
  Greatsword: '🗡',
  Hammer: '🔨',
  Staff: '🪄',
  Wand: '✨',
  Grimoire: '📖',
  'Ritual Dagger': '🔪',
  Bow: '🏹',
  Dagger: '🗡',
  'Holy Relic': '☀',
  'Necromantic Relic': '💀',
  'Heavy Armor': '🛡',
  Robes: '👘',
  'Light Armor': '🧥',
  Ring: '💍',
  Amulet: '📿',
  Relic: '✦'
};

const AFFIX_BASE_WEIGHTS = {
  flatDmg: 2.4,
  dmgPct: 2.2,
  atkSpeed: 2.0,
  critChance: 3.1,
  critDmg: 1.1,
  maxHp: 0.75,
  armor: 2.1,
  moveSpeed: 1.7,
  areaPct: 1.5,
  cdr: 2.5,
  regen: 3.0,
  lifeSteal: 3.4,
  summonDmg: 1.3,
  pickupRadius: 0.8,
  projBonus: 48
};

const CLASS_SCORE_BIAS = {
  warrior:     { flatDmg: 1.3, armor: 1.35, maxHp: 1.25, critDmg: 1.2 },
  mage:        { areaPct: 1.35, cdr: 1.35, dmgPct: 1.25, projBonus: 1.25 },
  necromancer: { summonDmg: 1.65, cdr: 1.25, pickupRadius: 1.15 },
  ranger:      { atkSpeed: 1.35, projBonus: 1.35, critChance: 1.25, moveSpeed: 1.2 },
  assassin:    { critChance: 1.4, critDmg: 1.35, moveSpeed: 1.25, dmgPct: 1.2 },
  paladin:     { armor: 1.4, regen: 1.4, maxHp: 1.3, areaPct: 1.15 }
};

export const INVENTORY_CATEGORIES = [
  { id: 'weapon', label: 'Weapons', filterLabel: 'Weapon', icon: '⚔' },
  { id: 'helmet', label: 'Helmets', filterLabel: 'Helmet', icon: '🪖' },
  { id: 'chest', label: 'Chest Armor', filterLabel: 'Armor', icon: '🛡' },
  { id: 'ring', label: 'Rings', filterLabel: 'Ring', icon: '💍' },
  { id: 'amulet', label: 'Amulets', filterLabel: 'Amulet', icon: '📿' },
  { id: 'relic', label: 'Relics', filterLabel: 'Relic', icon: '✦' }
];

const CATEGORY_ORDER = Object.fromEntries(INVENTORY_CATEGORIES.map((c, idx) => [c.id, idx]));

const FILTER_ALIASES = {
  all: 'all',
  weapon: 'weapon',
  weapons: 'weapon',
  helmet: 'helmet',
  helmets: 'helmet',
  helm: 'helmet',
  chest: 'chest',
  armor: 'chest',
  'chest armor': 'chest',
  ring: 'ring',
  rings: 'ring',
  ring1: 'ring',
  ring2: 'ring',
  amulet: 'amulet',
  amulets: 'amulet',
  relic: 'relic',
  relics: 'relic'
};

const RARITY_ORDER = {
  common: 0,
  magic: 1,
  rare: 2,
  legendary: 3,
  mythic: 4
};

let activeSlotFilter = 'all';

export const isItemLocked = item => Boolean(item?.locked);

export function setItemLocked(item, locked) {
  if (!item) return false;
  item.locked = Boolean(locked);
  return item.locked;
}

export function toggleLockItem(item) {
  if (!item) return false;
  item.locked = !item.locked;
  addFeed(`${item.locked ? '🔒 Locked' : '🔓 Unlocked'}: ${item.name}`, item.locked ? '#f0cf85' : '#9a96a6');
  return item.locked;
}

export function canEquipItem(item, player = state.player) {
  if (!item || !player?.cls) return true;
  if (typeof equipmentSys.canClassEquip === 'function') {
    return equipmentSys.canClassEquip(player.cls.id, item);
  }
  return true;
}

export const getSlotIcon = slot => SLOT_ICONS[slot] || '◈';

export function getItemIcon(item) {
  if (!item) return '◈';
  if (item.unique) return '✦';
  return SUBTYPE_ICONS[item.subType] || getSlotIcon(item.slot);
}

export const getRarityBorderClass = item =>
  item ? RARITIES[item.rarity]?.cls || 'r-common' : '';

export const getRarityColor = item =>
  item ? RARITIES[item.rarity]?.color || '#e6e4ed' : '#9a96a6';

export function scoreItem(item, player = state.player) {
  if (!item) return 0;
  const rarityMult = RARITIES[item.rarity]?.mult || 1;
  const clsBias = CLASS_SCORE_BIAS[player?.cls?.id] || {};

  let affixScore = 0;
  for (const a of item.affixes || []) {
    const baseW = AFFIX_BASE_WEIGHTS[a.key] || 1.2;
    const bias = clsBias[a.key] || 1;
    affixScore += (a.raw || 1) * baseW * bias;
  }

  return Math.round(
    (item.ilvl || 1) * 5 +
      rarityMult * 42 +
      (item.ancient ? 65 : 0) +
      (item.unique ? 115 : 0) +
      (item.set ? 24 : 0) +
      (item.gems?.length || 0) * 28 +
      affixScore
  );
}

export function getUpgradeIndicator(item, player = state.player) {
  if (!item) return { arrow: '•', text: '• Same', diff: 0, color: '#9a96a6', isUpgrade: false };
  if (!canEquipItem(item, player)) {
    return { arrow: '✖', text: '✖ Locked', diff: 0, color: '#ff4757', isUpgrade: false };
  }

  const newScore = scoreItem(item, player);
  const equipped = player?.equipped?.[item.slot];
  if (!equipped) {
    return { arrow: '▲', text: '▲ Better', diff: newScore, color: '#5effb1', isUpgrade: true };
  }

  const diff = newScore - scoreItem(equipped, player);
  if (diff > 0) return { arrow: '▲', text: '▲ Better', diff, color: '#5effb1', isUpgrade: true };
  if (diff < 0) return { arrow: '▼', text: '▼ Worse', diff, color: '#ff4757', isUpgrade: false };
  return { arrow: '•', text: '• Same', diff: 0, color: '#9a96a6', isUpgrade: false };
}

/* ==================== AUTO-SORTING, RECOMMENDATION & FILTERING ==================== */

export function normalizeSlotFilter(filter) {
  if (!filter || typeof filter !== 'string') return 'all';
  return FILTER_ALIASES[filter.trim().toLowerCase()] || 'all';
}

export function getSlotFilter() {
  return activeSlotFilter;
}

export function setSlotFilter(filter) {
  activeSlotFilter = normalizeSlotFilter(filter);
  return activeSlotFilter;
}

export function getSlotCategory(itemOrSlot) {
  if (!itemOrSlot) return 'weapon';
  if (typeof itemOrSlot === 'string') {
    const norm = normalizeSlotFilter(itemOrSlot);
    return norm === 'all' ? 'weapon' : norm;
  }
  if (itemOrSlot.slot) {
    const norm = normalizeSlotFilter(itemOrSlot.slot);
    if (norm !== 'all') return norm;
  }
  if (itemOrSlot.isRelic || itemOrSlot.relic || itemOrSlot.subType === 'Relic') return 'relic';
  return 'weapon';
}

export function compareInventoryItems(a, b, player = state.player) {
  const catDiff =
    (CATEGORY_ORDER[getSlotCategory(a)] ?? 99) -
    (CATEGORY_ORDER[getSlotCategory(b)] ?? 99);
  if (catDiff !== 0) return catDiff;

  const scoreDiff = scoreItem(b, player) - scoreItem(a, player);
  if (scoreDiff !== 0) return scoreDiff;

  const rarDiff = (RARITY_ORDER[b?.rarity] ?? 0) - (RARITY_ORDER[a?.rarity] ?? 0);
  if (rarDiff !== 0) return rarDiff;

  const ilvlDiff = (b?.ilvl || 0) - (a?.ilvl || 0);
  if (ilvlDiff !== 0) return ilvlDiff;

  return (a?.name || '').localeCompare(b?.name || '');
}

export function sortInventoryItems(items, player = state.player, inPlace = false) {
  if (!Array.isArray(items)) return [];
  const target = inPlace ? items : items.slice();
  target.sort((a, b) => compareInventoryItems(a, b, player));
  return target;
}

export function sortBag(player = state.player) {
  if (!player?.bag?.length) return player?.bag || [];
  return sortInventoryItems(player.bag, player, true);
}

export function filterInventoryItems(items = state.player?.bag, slotFilter = activeSlotFilter) {
  if (!Array.isArray(items)) return [];
  const norm = normalizeSlotFilter(slotFilter);
  if (norm === 'all') return items.slice();
  return items.filter(it => getSlotCategory(it) === norm);
}

export function getRecommendedItems(items = state.player?.bag, player = state.player) {
  const bestEquippable = new Map();
  const bestFallback = new Map();

  for (const it of items || []) {
    if (!it) continue;
    const cat = getSlotCategory(it);
    const sc = scoreItem(it, player);

    const prevAny = bestFallback.get(cat);
    if (!prevAny || sc > prevAny.score) {
      bestFallback.set(cat, { item: it, score: sc });
    }

    if (canEquipItem(it, player)) {
      const prevEq = bestEquippable.get(cat);
      if (!prevEq || sc > prevEq.score) {
        bestEquippable.set(cat, { item: it, score: sc });
      }
    }
  }

  const byCategory = new Map();
  const recommendedSet = new Set();
  for (const cat of INVENTORY_CATEGORIES) {
    const chosen = bestEquippable.get(cat.id) || bestFallback.get(cat.id);
    if (chosen) {
      byCategory.set(cat.id, chosen.item);
      recommendedSet.add(chosen.item);
    }
  }

  return { byCategory, recommendedSet };
}

export function isRecommendedItem(item, items = state.player?.bag, player = state.player) {
  if (!item) return false;
  const { byCategory } = getRecommendedItems(items, player);
  return byCategory.get(getSlotCategory(item)) === item;
}

export function organizeInventory(
  items = state.player?.bag,
  { slotFilter = activeSlotFilter, player = state.player, sort = true } = {}
) {
  const source = Array.isArray(items) ? items : [];
  const normFilter = normalizeSlotFilter(slotFilter);
  const { byCategory, recommendedSet } = getRecommendedItems(source, player);

  const countsByCategory = Object.fromEntries(INVENTORY_CATEGORIES.map(c => [c.id, 0]));
  const entries = [];

  for (let i = 0; i < source.length; i++) {
    const item = source[i];
    if (!item) continue;
    const category = getSlotCategory(item);
    countsByCategory[category] = (countsByCategory[category] || 0) + 1;
    if (normFilter !== 'all' && category !== normFilter) continue;

    entries.push({
      item,
      bagIndex: i,
      category,
      score: scoreItem(item, player),
      recommended: recommendedSet.has(item),
      upgrade: getUpgradeIndicator(item, player)
    });
  }

  if (sort) {
    entries.sort((a, b) => compareInventoryItems(a.item, b.item, player));
  }

  const groupMap = new Map();
  for (const cat of INVENTORY_CATEGORIES) {
    groupMap.set(cat.id, { ...cat, entries: [] });
  }
  for (const entry of entries) {
    groupMap.get(entry.category)?.entries.push(entry);
  }

  const groups = [];
  for (const cat of INVENTORY_CATEGORIES) {
    const grp = groupMap.get(cat.id);
    if (grp.entries.length > 0) groups.push(grp);
  }

  return {
    activeFilter: normFilter,
    entries,
    groups,
    recommendedSet,
    recommendedByCategory: byCategory,
    countsByCategory,
    totalCount: source.length
  };
}

/* ==================== VALUATION, EQUIP & DISPOSAL ==================== */

export function getItemSalvageYield(item) {
  const shardMap = { common: 1, magic: 2, rare: 3, legendary: 5, mythic: 8 };
  return {
    gold: 12,
    shards: shardMap[item.rarity] || 1,
    essence: item.rarity === 'legendary' || item.rarity === 'mythic' ? 1 : 0
  };
}

export function getItemSellValue(item) {
  const mult = RARITIES[item.rarity]?.mult || 1;
  return Math.round(
    (16 + (item.ilvl || 1) * 4) *
      mult *
      (item.ancient ? 1.45 : 1) *
      (item.unique ? 1.55 : 1) +
      (item.gems?.length || 0) * 18
  );
}

export function equipBagItem(item, bagIndex) {
  const p = state.player;
  if (!canEquipItem(item, p)) {
    addFeed(`${p.cls.name} cannot equip ${item.subType || 'this item'}!`, '#ff4757');
    return null;
  }

  const resolvedIdx = bagIndex >= 0 && p.bag[bagIndex] === item ? bagIndex : p.bag.indexOf(item);
  if (resolvedIdx === -1) return null;

  const old = p.equipped[item.slot];
  p.equipped[item.slot] = item;
  p.bag.splice(resolvedIdx, 1);
  if (old) p.bag.push(old);

  sortBag(p);
  recalcStats();
  return p.equipped[item.slot];
}

function disposeBagItem(it, idx, mode, skipSort = false) {
  const bag = state.player?.bag;
  if (!it || !bag) return null;

  const resolvedIdx = idx >= 0 && bag[idx] === it ? idx : bag.indexOf(it);
  if (resolvedIdx < 0) return null;

  if (isItemLocked(it)) {
    addFeed(`🔒 ${it.name} is locked and cannot be ${mode === 'sell' ? 'sold' : 'salvaged'}!`, '#ff8c00');
    return null;
  }

  const gain = mode === 'sell'
    ? { gold: getItemSellValue(it), shards: 0, essence: 0 }
    : getItemSalvageYield(it);

  bag.splice(resolvedIdx, 1);
  state.runGold += gain.gold;
  state.runShards += gain.shards;
  state.runEssence += gain.essence;
  if (!skipSort) sortBag(state.player);
  return gain;
}

export const salvageItem = (it, idx) => disposeBagItem(it, idx, 'salvage');
export const sellItem = (it, idx) => disposeBagItem(it, idx, 'sell');

function processBagBulk(predicate, mode, feedLabel, feedColor) {
  const bag = state.player?.bag;
  const totals = { count: 0, skippedLocked: 0, gold: 0, shards: 0, essence: 0 };
  if (!bag?.length) return totals;

  for (let i = bag.length - 1; i >= 0; i--) {
    const it = bag[i];
    if (!predicate(it)) continue;
    if (isItemLocked(it)) {
      totals.skippedLocked++;
      continue;
    }
    const res = disposeBagItem(it, i, mode, true);
    if (!res) continue;
    totals.count++;
    totals.gold += res.gold;
    totals.shards += res.shards;
    totals.essence += res.essence;
  }

  if (totals.count > 0) sortBag(state.player);

  if (totals.count > 0 && feedLabel) {
    const parts = [`+${totals.gold}G`];
    if (totals.shards) parts.push(`+${totals.shards} Shards`);
    if (totals.essence) parts.push(`+${totals.essence} Essence`);
    const lockNote = totals.skippedLocked ? ` • ${totals.skippedLocked} 🔒 skipped` : '';
    addFeed(`${feedLabel} ${totals.count} (${parts.join(', ')}${lockNote})`, feedColor);
  } else if (totals.skippedLocked > 0) {
    addFeed(`Skipped ${totals.skippedLocked} 🔒 locked item(s)`, '#f0cf85');
  }

  return totals;
}

export const salvageJunk = () =>
  processBagBulk(it => it.rarity === 'common' || it.rarity === 'magic', 'salvage', 'Salvaged Common/Magic', '#c9a050');

export const salvageAll = () =>
  processBagBulk(() => true, 'salvage', 'Salvaged All', '#ff8c00');

export const sellAll = () =>
  processBagBulk(() => true, 'sell', 'Sold All', '#ffd700');

export const sellAllCommon = () =>
  processBagBulk(it => it.rarity === 'common', 'sell', 'Sold Common', '#e6e4ed');

export const sellAllMagic = () =>
  processBagBulk(it => it.rarity === 'magic', 'sell', 'Sold Magic', '#5ca8ff');

/* ==================== SHARED READABLE INVENTORY UI HELPERS ==================== */

export function formatCompactTags(item) {
  const affixes = (item.affixes || []).map(a => `<span class="rarity-tag">${a.text}</span>`).join(' ');
  const gems = (item.gems || [])
    .map(g => `<span class="rarity-tag" style="color:${g.color};">◆ ${g.text}</span>`)
    .join(' ');
  return `${affixes} ${gems}`.trim();
}

export function renderSlotFilterBar(container, countsByCategory = {}, onFilterChange) {
  if (!container) return;
  container.innerHTML = '';

  const total = Object.values(countsByCategory).reduce((a, b) => a + b, 0);
  const pills = [{ id: 'all', label: `All (${total})` }];
  for (const cat of INVENTORY_CATEGORIES) {
    const n = countsByCategory[cat.id] || 0;
    pills.push({ id: cat.id, label: `${cat.icon} ${cat.filterLabel} (${n})` });
  }

  for (const pill of pills) {
    const isActive = activeSlotFilter === pill.id;
    const btn = mk('button', isActive ? 'btn-gold' : 'btn-dark', pill.label);
    btn.type = 'button';
    btn.style.fontSize = '11px';
    btn.style.padding = '4px 8px';
    btn.onclick = () => {
      setSlotFilter(pill.id);
      onFilterChange?.(pill.id);
    };
    container.appendChild(btn);
  }
}

export function createItemCard(
  item,
  { slot, selected = false, showUpgrade = false, recommended = false, compact = false, onClick } = {}
) {
  const p = state.player;
  if (!item) {
    return mk(
      'div',
      'slot-row sans',
      `<div style="font-size:11px;color:#6e657d;">${getSlotIcon(slot)} ${SLOT_LABELS[slot] || slot} — Empty</div>`
    );
  }

  const rar = RARITIES[item.rarity] || RARITIES.common;
  const icon = getItemIcon(item);
  const lockIcon = isItemLocked(item) ? '🔒 ' : '';
  const score = scoreItem(item, p);
  const upg = showUpgrade ? getUpgradeIndicator(item, p) : null;
  const allowed = canEquipItem(item, p);

  const badge = upg
    ? `<span style="color:${upg.color};font-weight:800;font-size:11px;">${upg.arrow} ${upg.diff > 0 ? `+${upg.diff}` : upg.diff < 0 ? upg.diff : ''}</span>`
    : `<span style="color:${rar.color};font-size:10px;font-weight:700;">★ ${score}</span>`;

  const recBadge = recommended
    ? `<span style="display:inline-block;margin-left:5px;padding:1px 5px;border-radius:3px;font-size:9px;font-weight:800;letter-spacing:0.4px;background:rgba(94,255,177,0.16);border:1px solid rgba(94,255,177,0.55);color:#5effb1;">RECOMMENDED</span>`
    : '';

  const subInfo = compact
    ? `${SLOT_LABELS[item.slot]} • ★ ${score}`
    : `${SLOT_LABELS[item.slot]}${item.subType ? ` (${item.subType})` : ''} • iLv ${item.ilvl} • ★ ${score}`;

  const el = mk(
    'div',
    `slot-row sans ${rar.cls} ${selected ? 'selected' : ''} ${allowed ? '' : 'restricted'}`,
    `<div class="flex-row" style="justify-content:space-between;gap:6px;">
       <span style="font-size:10px;opacity:.78;">${icon} ${subInfo}</span>
       ${badge}
     </div>
     <div style="font-weight:700;font-size:${compact ? '11px' : '12px'};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:2px;">
       ${lockIcon}${item.name}${recBadge}
     </div>`
  );

  if (onClick) el.onclick = onClick;
  return el;
}

export function renderItemInspector(
  container,
  item,
  { isEquipped = false, recommended = false, onEquip, onSalvage, onSell, onLockToggle } = {}
) {
  if (!container) return;
  if (!item) {
    container.innerHTML = '<div style="color:var(--ash);font-size:12px;">Select an item to inspect stats, lock, or compare upgrades.</div>';
    return;
  }

  const p = state.player;
  const rar = RARITIES[item.rarity] || RARITIES.common;
  const icon = getItemIcon(item);
  const locked = isItemLocked(item);
  const score = scoreItem(item, p);
  const upg = isEquipped ? null : getUpgradeIndicator(item, p);
  const allowed = canEquipItem(item, p);
  const sellVal = getItemSellValue(item);
  const rec = recommended || (!isEquipped && isRecommendedItem(item, p?.bag, p));

  let html = `
    <div class="flex-row" style="justify-content:space-between;gap:8px;flex-wrap:wrap;">
      <b style="color:${rar.color};font-size:14px;">${locked ? '🔒 ' : ''}${icon} ${item.name}</b>
      <div class="flex-row" style="gap:6px;">
        ${rec ? '<span class="rarity-tag" style="color:#5effb1;border-color:#5effb1;">★ Recommended</span>' : ''}
        <span class="rarity-tag ${rar.cls}">${rar.name} • ★ ${score}</span>
      </div>
    </div>`;

  if (upg) {
    html += `<div class="sans" style="font-size:12px;font-weight:700;color:${upg.color};margin-top:4px;">${upg.text} (${upg.diff >= 0 ? `+${upg.diff}` : upg.diff} Score)</div>`;
  }
  if (item.set) {
    html += `<div class="sans" style="font-size:11px;color:#5effb1;margin-top:3px;">✦ Set: ${SETS[item.set] || item.set}</div>`;
  }

  html += `<div class="sans" style="display:flex;flex-wrap:wrap;gap:5px;margin:8px 0;">${formatCompactTags(item)}</div>`;

  if (item.unique) {
    html += `<div class="sans" style="font-size:12px;color:#ffd089;background:rgba(255,140,0,.12);padding:6px 8px;border-left:2px solid #ff8c00;margin-bottom:6px;"><b>Unique:</b> ${item.unique.power}</div>`;
  }
  if (!isEquipped && !allowed) {
    html += `<div class="sans" style="font-size:11px;color:#ff4757;margin:4px 0;">✖ ${p.cls.name} cannot equip ${item.subType}.</div>`;
  }

  const lockBtn = `<button class="btn-dark" id="inv-act-lock">${locked ? '🔓 Unlock' : '🔒 Lock'}</button>`;
  const disabledAttr = 'disabled style="opacity:.45;cursor:not-allowed;"';
  const bagBtns = isEquipped
    ? ''
    : `<button class="btn-gold" id="inv-act-equip" ${allowed ? '' : disabledAttr}>Equip</button>` +
      `<button class="btn-dark" id="inv-act-sell" ${locked ? disabledAttr : ''}>Sell (+${sellVal}G)</button>` +
      `<button class="btn-dark" id="inv-act-salvage" ${locked ? disabledAttr : ''}>Salvage</button>`;

  html += `<div class="flex-row" style="gap:8px;margin-top:8px;flex-wrap:wrap;">${lockBtn}${bagBtns}</div>`;
  container.innerHTML = html;

  const actions = [
    ['#inv-act-lock', () => { toggleLockItem(item); onLockToggle?.(item); }],
    ['#inv-act-equip', allowed ? onEquip : null],
    ['#inv-act-sell', !locked ? onSell : null],
    ['#inv-act-salvage', !locked ? onSalvage : null]
  ];
  for (const [sel, fn] of actions) {
    const btn = container.querySelector(sel);
    if (btn && fn) btn.onclick = fn;
  }
}

const BULK_ACTIONS = [
  ['btn-salvage-all', 'btn-dark', 'Salvage All', salvageAll],
  ['btn-sell-common', 'btn-dark', 'Sell Common', sellAllCommon],
  ['btn-sell-magic', 'btn-dark', 'Sell Magic', sellAllMagic],
  ['btn-sell-all', 'btn-dark', 'Sell All', sellAll]
];

export function renderBulkActionButtons(headerContainer, onRefresh) {
  if (!headerContainer || headerContainer.dataset.bulkWired) return;
  headerContainer.dataset.bulkWired = '1';

  const anchor = headerContainer.querySelector('#btn-close-inv');
  for (const [id, cls, label, actionFn] of BULK_ACTIONS) {
    if (headerContainer.querySelector(`#${id}`)) continue;
    const btn = mk('button', cls, label);
    btn.id = id;
    btn.onclick = () => {
      actionFn();
      onRefresh?.();
    };
    if (anchor) headerContainer.insertBefore(btn, anchor);
    else headerContainer.appendChild(btn);
  }
}