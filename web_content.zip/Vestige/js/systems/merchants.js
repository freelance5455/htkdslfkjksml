import { mk, pick } from '../core/utilities.js';
import { addMetaCurrency, grantFrag } from '../core/save.js';
import { state, closeAllModals } from '../core/game.js';

import { NPCS } from '../data/eventsData.js';
import { recalcStats } from '../entities/player.js';
import { spawnEnemy } from '../entities/enemies.js';
import { generateLootItem, dropLoot } from '../entities/loot.js';
import { DOM } from '../ui/hud.js';

const NPC_CHOICE_ACTIONS = {
  pilgrim_oath: p => {
    p.bonus.dmgPct += 0.25;
    state.enemySpeedMult += 0.15;
    p.quests.pilgrim = 'Oath Sworn';
  },
  pilgrim_mercy: p => {
    p.bonus.maxHp += 35;
    recalcStats();
    p.hp = p.maxHp;
    p.quests.pilgrim = 'Mercy Given';
  },
  pilgrim_betray: p => {
    for (let i = 0; i < 3; i++) spawnEnemy('elite');
    dropLoot(p.x + 20, p.y, generateLootItem(p.level, 'legendary'));
    p.quests.pilgrim = 'Betrayed';
  },
  seer_gaze: p => {
    p.bonus.critChance += 0.18;
    p.treePoints += 2;
    p.quests.seer = 'Star-Touched';
  },
  seer_silence: p => {
    addMetaCurrency(0, 100, 0);
    p.bonus.areaPct += 0.20;
    p.quests.seer = 'Silenced';
  },
  smith_temper: p => {
    p.bonus.flatDmg += 12;
    p.bonus.atkSpeed += 0.15;
  },
  smith_catalyst: p => {
    p.bonus.projBonus += 1;
    addMetaCurrency(0, 0, 2);
  },
  orin_draught: p => {
    if (state.runGold >= 55) {
      state.runGold -= 55;
      p.bonus.dmgPct += 0.18;
      p.bonus.atkSpeed += 0.10;
    }
  },
  orin_coffer: p => {
    if (state.runGold >= 85) {
      state.runGold -= 85;
      dropLoot(
        p.x + 20,
        p.y,
        generateLootItem(p.level + state.worldTier, Math.random() < 0.35 ? 'legendary' : 'rare', 0.8)
      );
    }
  },
  orin_frags: () => {
    if (state.runGold >= 75) {
      state.runGold -= 75;
      grantFrag(pick(['flame', 'void', 'star', 'ash']), 2);
    }
  },
  orin_leave: () => {}
};

export function openNpcModal(customNpc = null) {
  state.mode = 'npc';
  const npc = customNpc || pick(NPCS);
  DOM['npc-name'].textContent = npc.name;
  DOM['npc-quote'].textContent = npc.quote;
  DOM['npc-body'].textContent = npc.body;
  DOM['npc-choices'].innerHTML = '';

  npc.choices.forEach(([txt, actionKey]) => {
    const b = mk('button', 'btn-dark', txt);
    b.onclick = () => {
      NPC_CHOICE_ACTIONS[actionKey]?.(state.player);
      recalcStats();
      closeAllModals();
    };
    DOM['npc-choices'].appendChild(b);
  });

  DOM['npc-modal'].classList.add('active');
}