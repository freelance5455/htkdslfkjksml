import { SLOTS } from '../data/items.js';

// Which item subtypes each class may equip (weapons + armor).
// Rings ('Ring') and amulets ('Amulet') are open to every class.
export const CLASS_GEAR = {
  warrior:     ['Greatsword', 'Sword', 'Hammer', 'Heavy Armor', 'Light Armor'],
  paladin:     ['Sword', 'Hammer', 'Holy Relic', 'Heavy Armor', 'Light Armor'],
  mage:        ['Staff', 'Wand', 'Robes'],
  necromancer: ['Grimoire', 'Necromantic Relic', 'Ritual Dagger', 'Staff', 'Robes'],
  ranger:      ['Bow', 'Dagger', 'Light Armor'],
  assassin:    ['Dagger', 'Ritual Dagger', 'Bow', 'Light Armor']
};

const OPEN_SUBTYPES = ['Ring', 'Amulet'];

export function canClassEquip(classId, item) {
  const sub = item?.subType;
  if (!sub || OPEN_SUBTYPES.includes(sub)) return true;
  const allowed = CLASS_GEAR[classId];
  return !allowed || allowed.includes(sub);
}

export function addStatKv(s, k, v) {
  if (k === 'moveSpeed') s.moveSpeedMult += v;
  else if (k === 'maxHp') s.maxHpBase += v;
  else if (k === 'pickupRadius') s.pickupBonus += v;
  else if (k in s) s[k] += v;
}

export function applyEquipmentStats(p, s) {
  for (const sl of SLOTS) {
    const it = p.equipped[sl];
    if (!it) continue;
    if (it.unique) s.uniques.add(it.unique.id);
    if (it.set) s.sets[it.set] = (s.sets[it.set] || 0) + 1;
    it.affixes.forEach(a => addStatKv(s, a.key, a.val));
    it.gems.forEach(g => addStatKv(s, g.key, g.val));
  }
}
