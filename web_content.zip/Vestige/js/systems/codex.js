import { metaSave, persistSave } from '../core/save.js';
import { BOSSES } from '../data/bossData.js';
import { ENDINGS_DATA } from '../data/eventsData.js';
import { addFeed } from '../ui/notifications.js';

export const CODEX_LORE = [
  {
    id: 'sundering',
    title: 'The Sundering',
    unlocked: true,
    text: 'When the First Flame of Eternity shattered, time fractured into ash. Five great factions tore fragments of divinity into their crowns.'
  },
  {
    id: 'remnant',
    title: 'The Forsaken Remnant',
    unlocked: true,
    text: 'Neither fully living nor truly dead, the Remnant walks each cycle to gather Flame Fragments and decide the fate of existence.'
  },
  ...BOSSES.map(b => ({
    id: b.id,
    title: `${b.secret ? 'Secret ' : ''}Boss: ${b.name}`,
    unlocked: false,
    text: b.lore
  })),
  ...ENDINGS_DATA.map(e => ({
    id: e.id,
    title: `Ending: ${e.name}`,
    unlocked: false,
    text: e.text
  }))
];

export function unlockLore(id) {
  if (metaSave.unlockedLore.includes(id)) return;
  metaSave.unlockedLore.push(id);
  const entry = CODEX_LORE.find(l => l.id === id);
  if (entry) addFeed(`Codex Unlocked: ${entry.title}`, '#c9a050');
  persistSave();
}