import { metaSave, persistSave, addMetaCurrency, grantFrag } from '../core/save.js';
import { state } from '../core/game.js';
import { unlockLore } from './codex.js';
import { unlockAchievement } from './achievements.js';
import { addFeed, showBanner } from '../ui/notifications.js';

const QUEST_STORAGE_KEY = 'vestige_questlines_v1';

// ============================================================================
// ENUMS & CORE DATA CLASSES
// ============================================================================

export const QUEST_STATUS = Object.freeze({
  UNDISCOVERED: 'undiscovered',
  ACTIVE: 'active',
  COMPLETED: 'completed',
  FAILED: 'failed'
});

export const OBJECTIVE_TYPES = Object.freeze({
  ITEM_DISCOVERY: 'item_discovery',
  FRAGMENT_COLLECT: 'fragment_collect',
  BOSS_KILL: 'boss_kill',
  ENEMY_KILL: 'enemy_kill',
  DUNGEON_CLEAR: 'dungeon_clear',
  WORLD_EVENT: 'world_event',
  NPC_ENCOUNTER: 'npc_encounter',
  BIOME_EXPLORE: 'biome_explore',
  CUSTOM: 'custom'
});

export const REWARD_TYPES = Object.freeze({
  RELIC: 'relic',
  BLESSING: 'blessing',
  WORLD_MODIFIER: 'world_modifier',
  FORGE_UPGRADE: 'forge_upgrade',
  LORE: 'lore',
  VENDOR: 'vendor',
  CLASS: 'class',
  BIOME: 'biome',
  BOSS: 'boss',
  RECIPE: 'recipe',
  CURRENCY: 'currency'
});

export class QuestObjective {
  constructor(def = {}) {
    this.id = def.id;
    this.type = def.type || OBJECTIVE_TYPES.CUSTOM;
    this.target = def.target || null; // string or array of matching IDs
    this.required = Math.max(1, def.required || 1);
    this.label = def.label || '';
    this.optional = Boolean(def.optional);
    this.hidden = Boolean(def.hidden);
    this.condition = typeof def.condition === 'function' ? def.condition : null;
  }

  matches(eventType, payload = {}) {
    if (this.type !== eventType) return false;
    if (this.condition && !this.condition(payload)) return false;
    if (!this.target) return true;

    const candidate = payload.target ?? payload.id ?? payload.bossId ?? payload.itemId ?? payload.eventId ?? payload.biomeId;
    if (Array.isArray(this.target)) {
      return this.target.includes(candidate);
    }
    return candidate === this.target;
  }
}

export class QuestReward {
  constructor(def = {}) {
    this.id = def.id;
    this.type = def.type || REWARD_TYPES.LORE;
    this.name = def.name || def.id;
    this.description = def.description || '';
    this.payload = def.payload || {};
  }
}

export class QuestState {
  constructor(questId, saved = null) {
    this.questId = questId;
    this.status = saved?.status || QUEST_STATUS.UNDISCOVERED;
    this.currentStageId = saved?.currentStageId || null;
    this.completedSteps = Array.isArray(saved?.completedSteps) ? [...saved.completedSteps] : [];
    this.objectives = saved?.objectives ? { ...saved.objectives } : {};
    this.npcState = saved?.npcState || 'Unknown';
    this.decisions = saved?.decisions ? { ...saved.decisions } : {};
    this.rewardsClaimed = Array.isArray(saved?.rewardsClaimed) ? [...saved.rewardsClaimed] : [];
    this.ending = saved?.ending || null;
    this.failedReason = saved?.failedReason || null;
    this.runsSeen = saved?.runsSeen || 0;
    this.lastRunId = saved?.lastRunId ?? -1;
    this.discoveredAt = saved?.discoveredAt || null;
    this.completedAt = saved?.completedAt || null;
    this.flags = saved?.flags ? { ...saved.flags } : {};
  }

  toJSON() {
    return {
      questId: this.questId,
      status: this.status,
      currentStageId: this.currentStageId,
      completedSteps: [...this.completedSteps],
      objectives: { ...this.objectives },
      npcState: this.npcState,
      decisions: { ...this.decisions },
      rewardsClaimed: [...this.rewardsClaimed],
      ending: this.ending,
      failedReason: this.failedReason,
      runsSeen: this.runsSeen,
      lastRunId: this.lastRunId,
      discoveredAt: this.discoveredAt,
      completedAt: this.completedAt,
      flags: { ...this.flags }
    };
  }
}

export class Questline {
  constructor(def) {
    this.id = def.id;
    this.name = def.name;
    this.description = def.description;
    this.npcName = def.npcName || def.name;
    this.faction = def.faction || 'unaligned';
    this.icon = def.icon || '◈';
    this.color = def.color || '#f4d68c';
    this.playerQuestKey = def.playerQuestKey || null;
    this.initialStageId = def.initialStageId;
    this.appearanceChance = def.appearanceChance ?? 0.55;
    this.minRunsBetween = def.minRunsBetween ?? 0;
    this.unlockCondition = typeof def.unlockCondition === 'function' ? def.unlockCondition : null;
    this.stages = {};

    for (const [stageId, sDef] of Object.entries(def.stages || {})) {
      this.stages[stageId] = {
        ...sDef,
        id: stageId,
        objectives: (sDef.objectives || []).map(o => new QuestObjective(o)),
        rewards: (sDef.rewards || []).map(r => new QuestReward(r)),
        choices: Array.isArray(sDef.choices) ? sDef.choices.map(c => ({
          ...c,
          rewards: (c.rewards || []).map(r => new QuestReward(r))
        })) : null
      };
    }
  }

  getStage(stageId) {
    return stageId ? this.stages[stageId] || null : null;
  }

  getAllRewards() {
    const out = [];
    for (const st of Object.values(this.stages)) {
      out.push(...st.rewards);
      if (st.choices) {
        for (const ch of st.choices) out.push(...ch.rewards);
      }
    }
    return out;
  }
}

// ============================================================================
// DATA-DRIVEN QUESTLINE DEFINITIONS
// ============================================================================

const QUESTLINE_DEFINITIONS = [
  {
    id: 'kaelen_smith',
    name: 'Kaelen, Hollowed Smith',
    description: 'A master smith searching for relics from the First Flame.',
    npcName: 'Kaelen',
    faction: 'throne',
    icon: '⚒',
    color: '#ff9442',
    appearanceChance: 0.65,
    initialStageId: 'forge_fragments',
    stages: {
      forge_fragments: {
        title: 'Embers of the Old Forge',
        description: 'Search ruins and fallen champions for 3 Ancient Forge Fragments.',
        npcState: 'Seeking Forge Fragments',
        dialogue: '"Even ash remembers the hammer. Bring me three fragments of the old hearth."',
        autoAdvance: true,
        nextStageId: 'iron_champion',
        objectives: [
          {
            id: 'find_forge_frags',
            type: OBJECTIVE_TYPES.ITEM_DISCOVERY,
            target: 'ancient_forge_fragment',
            required: 3,
            label: 'Find Ancient Forge Fragments'
          }
        ],
        rewards: [
          {
            id: 'unlock_improved_forge',
            type: REWARD_TYPES.FORGE_UPGRADE,
            name: 'Improved Forge',
            description: 'Unlocks higher-tier tempering and reforging options at the Forge.',
            payload: { tier: 1, bonusAffixPower: 0.15 }
          }
        ],
        cinematic: { id: 'kaelen_stage1', title: 'Kaelen Rekindles the Bellows' }
      },

      iron_champion: {
        title: 'Trial of Tempered Iron',
        description: 'Defeat the Iron Covenant Champion guarding the broken foundry.',
        npcState: 'Testing Mettle',
        dialogue: '"The Covenant hoards our steel in rusted vaults. Break their Champion."',
        autoAdvance: true,
        nextStageId: 'ember_anvil',
        objectives: [
          {
            id: 'slay_iron_champion',
            type: OBJECTIVE_TYPES.BOSS_KILL,
            target: ['iron_covenant_champion', 'colossus'],
            required: 1,
            label: 'Defeat Iron Covenant Champion'
          }
        ],
        rewards: [
          {
            id: 'recipe_first_flame_edge',
            type: REWARD_TYPES.RECIPE,
            name: 'Unique Recipe: Edge of the First Flame',
            description: 'Unlocks a unique weapon crafting recipe.',
            payload: { recipeId: 'first_flame_edge', weaponBonusDmg: 0.18 }
          },
          {
            id: 'kaelen_vendor_wares',
            type: REWARD_TYPES.VENDOR,
            name: 'Masterwork Tempering Stock',
            description: 'Expands smithing vendor inventory with rare ingots.'
          }
        ]
      },

      ember_anvil: {
        title: 'The Ember Anvil',
        description: 'Recover The Ember Anvil from the Ashen Vaults or Forged Dungeon.',
        npcState: 'Awaiting the Anvil',
        dialogue: '"Without the Ember Anvil, even god-iron shatters. Recover it from the ash."',
        autoAdvance: false,
        objectives: [
          {
            id: 'recover_ember_anvil',
            type: OBJECTIVE_TYPES.ITEM_DISCOVERY,
            target: 'ember_anvil',
            required: 1,
            label: 'Recover The Ember Anvil'
          }
        ],
        choices: [
          {
            id: 'restore_anvil',
            label: 'Deliver the Ember Anvil to Kaelen',
            description: 'Restore Kaelen’s forge to legendary strength.',
            outcome: 'next',
            nextStageId: 'forgemaster_wraith',
            npcState: 'Forging Legend',
            rewards: [
              {
                id: 'legendary_smithing_options',
                type: REWARD_TYPES.FORGE_UPGRADE,
                name: 'Legendary Smithing Options',
                description: 'Unlocks legendary affixes and socket tempering at the Forge.',
                payload: { tier: 2, legendarySmithing: true }
              }
            ]
          },
          {
            id: 'shatter_anvil',
            label: 'Shatter the Anvil for Raw Essence',
            description: 'Claim immediate shards and essence, severing Kaelen’s trust.',
            outcome: 'fail',
            endingId: 'kaelen_betrayed',
            npcState: 'Hollowed & Betrayed',
            rewards: [
              {
                id: 'shattered_anvil_shards',
                type: REWARD_TYPES.CURRENCY,
                name: 'Shattered Anvil Spoils',
                description: 'Gain 120 Gold, 25 Shards, and 2 Essence.',
                payload: { gold: 120, shards: 25, essence: 2 }
              }
            ]
          }
        ]
      },

      forgemaster_wraith: {
        title: 'Ashes of the Forgemaster',
        description: 'Defeat The Forgemaster Wraith to reclaim the First Flame’s craft.',
        npcState: 'Bound to the Hearth',
        dialogue: '"My old master still haunts the crucible. Put his hammer to rest."',
        autoAdvance: true,
        nextStageId: null,
        objectives: [
          {
            id: 'slay_forgemaster_wraith',
            type: OBJECTIVE_TYPES.BOSS_KILL,
            target: 'forgemaster_wraith',
            required: 1,
            label: 'Defeat The Forgemaster Wraith'
          }
        ],
        rewards: [
          {
            id: 'permanent_forge_upgrade',
            type: REWARD_TYPES.FORGE_UPGRADE,
            name: 'Permanent First-Flame Forge Upgrade',
            description: 'Permanently empowers all forged items and reduces crafting cost.',
            payload: { tier: 3, costReduction: 0.2, permanentMasterwork: true }
          },
          {
            id: 'lore_kaelen_oath',
            type: REWARD_TYPES.LORE,
            name: 'Chronicle: Kaelen’s Last Hammer',
            description: 'Unlocks Kaelen’s lore entry in the Codex.',
            payload: { loreId: 'kaelen_smith' }
          }
        ],
        ending: {
          id: 'kaelen_rekindled',
          title: 'The Hearth Rekindled',
          summary: 'Kaelen’s hammer rings once more across the ruins, blessing future runs.',
          type: 'victory'
        },
        cinematic: { id: 'kaelen_finale', title: 'The First Anvil Sings' }
      }
    }
  },

  {
    id: 'last_pilgrim',
    name: 'The Last Pilgrim',
    description: 'A mysterious traveler wandering the Ashen Expanse.',
    npcName: 'The Last Pilgrim',
    faction: 'pilgrim',
    icon: '🕯',
    color: '#e6c88a',
    playerQuestKey: 'pilgrim',
    appearanceChance: 0.55,
    initialStageId: 'encounter_pilgrim',
    stages: {
      encounter_pilgrim: {
        title: 'Lantern in the Ash',
        description: 'You cross paths with a cloaked wanderer bearing a dying lantern.',
        npcState: 'Wandering the Expanse',
        dialogue: '"The road to the First Flame is long, traveler. Will you share your warmth?"',
        autoAdvance: false,
        objectives: [
          {
            id: 'meet_pilgrim',
            type: OBJECTIVE_TYPES.NPC_ENCOUNTER,
            target: 'last_pilgrim',
            required: 1,
            label: 'Encounter the Last Pilgrim'
          }
        ],
        choices: [
          {
            id: 'help',
            label: 'Help the Pilgrim',
            description: 'Share your lantern ember and guide them safely.',
            outcome: 'next',
            nextStageId: 'pilgrim_shrine_escort',
            npcState: 'Grateful Companion',
            rewards: [
              {
                id: 'pilgrim_blessing_ember',
                type: REWARD_TYPES.BLESSING,
                name: 'Pilgrim’s Shared Ember',
                description: 'Grants +8% Movement Speed & Pickup Radius blessing pool unlock.',
                payload: { blessingId: 'pilgrim_stride' }
              }
            ]
          },
          {
            id: 'ignore',
            label: 'Ignore',
            description: 'Walk past without speaking into the ash wind.',
            outcome: 'next',
            nextStageId: 'pilgrim_fading_trail',
            npcState: 'Distant Silhouette'
          },
          {
            id: 'refuse',
            label: 'Refuse',
            description: 'Turn the Pilgrim away and claim their lantern spark for yourself.',
            outcome: 'next',
            nextStageId: 'pilgrim_forsaken',
            npcState: 'Bitter & Forsaken'
          }
        ]
      },

      pilgrim_shrine_escort: {
        title: 'Sanctuary Beyond the Cinder',
        description: 'Cleanse 2 World Events or Dungeons while carrying the Pilgrim’s token.',
        npcState: 'Awaiting Sanctuary',
        dialogue: '"There is a forgotten altar ahead. Clear the corrupted rites so I may rest."',
        autoAdvance: false,
        objectives: [
          {
            id: 'clear_pilgrim_events',
            type: OBJECTIVE_TYPES.WORLD_EVENT,
            required: 2,
            label: 'Complete World Events along the Pilgrimage'
          }
        ],
        choices: [
          {
            id: 'grant_sanctuary',
            label: 'Entrust the Sanctuary Lantern',
            description: 'Let the Pilgrim guard the safe haven for future travelers.',
            outcome: 'complete',
            endingId: 'keeper_pale_lantern',
            npcState: 'Keeper of the Sanctuary',
            rewards: [
              {
                id: 'relic_pilgrim_lantern',
                type: REWARD_TYPES.RELIC,
                name: 'Pale Sanctuary Lantern',
                description: 'Unlocks a permanent Pilgrim Relic and vendor curios.',
                payload: { relicId: 'pale_lantern' }
              },
              {
                id: 'lore_pilgrim_sanctuary',
                type: REWARD_TYPES.LORE,
                name: 'Chronicle: The Pale Lantern',
                payload: { loreId: 'last_pilgrim_light' }
              }
            ]
          },
          {
            id: 'kindle_oath',
            label: 'Ask the Pilgrim to Join the Frontlines',
            description: 'Bind their vow to your future expeditions.',
            outcome: 'complete',
            endingId: 'kindled_oath',
            npcState: 'Oathbound',
            rewards: [
              {
                id: 'modifier_pilgrim_oath',
                type: REWARD_TYPES.WORLD_MODIFIER,
                name: 'Path of the Ashwalker',
                description: 'Unlocks a world modifier increasing shrine & event density.',
                payload: { modifierId: 'pilgrim_oath', eventRateBonus: 0.25 }
              }
            ]
          }
        ]
      },

      pilgrim_fading_trail: {
        title: 'Footprints in the Ash',
        description: 'Cross the Ashen Capital or Catacombs to see what became of the wanderer.',
        npcState: 'Drifting Alone',
        dialogue: '"Some roads are walked twice before two strangers truly meet."',
        autoAdvance: false,
        objectives: [
          {
            id: 'explore_ash_path',
            type: OBJECTIVE_TYPES.BIOME_EXPLORE,
            target: ['capital', 'catacombs', 'infernal'],
            required: 1,
            label: 'Traverse the Ashlands'
          }
        ],
        choices: [
          {
            id: 'reclaim_journal',
            label: 'Preserve the Pilgrim’s Abandoned Journal',
            description: 'Learn their quiet history.',
            outcome: 'complete',
            endingId: 'footprints_in_ash',
            npcState: 'Remembered in Ink',
            rewards: [
              {
                id: 'lore_pilgrim_footprints',
                type: REWARD_TYPES.LORE,
                name: 'Journal: Footprints in Ash',
                payload: { loreId: 'last_pilgrim_ash' }
              }
            ]
          }
        ],
        failureTriggers: [
          { type: OBJECTIVE_TYPES.BOSS_KILL, target: 'pilgrim_hollow' }
        ]
      },

      pilgrim_forsaken: {
        title: 'The Extinguished Wick',
        description: 'Confront the Hollowed Pilgrim consumed by the ash you denied them.',
        npcState: 'Hostile Wraith',
        dialogue: '"You kept the flame... and left me to the cold."',
        autoAdvance: true,
        nextStageId: null,
        objectives: [
          {
            id: 'slay_forsaken_pilgrim',
            type: OBJECTIVE_TYPES.BOSS_KILL,
            target: 'forsaken_pilgrim',
            required: 1,
            label: 'Defeat the Forsaken Pilgrim'
          }
        ],
        rewards: [
          {
            id: 'unlock_forsaken_boss',
            type: REWARD_TYPES.BOSS,
            name: 'Encounter: The Forsaken Wanderer',
            description: 'Unlocks the Forsaken Pilgrim as a rare roaming boss encounter.',
            payload: { bossId: 'forsaken_pilgrim' }
          },
          {
            id: 'relic_cinder_shackle',
            type: REWARD_TYPES.RELIC,
            name: 'Extinguished Lantern Shard',
            payload: { relicId: 'cinder_shackle' }
          }
        ],
        ending: {
          id: 'severed_pilgrimage',
          title: 'Severed Pilgrimage',
          summary: 'The wanderer fell into hollow madness by your refusal.',
          type: 'failed'
        }
      }
    }
  },

  {
    id: 'veiled_seer',
    name: 'The Veiled Seer',
    description: 'A prophet who remembers fragments of forgotten futures.',
    npcName: 'The Veiled Seer',
    faction: 'choir',
    icon: '✧',
    color: '#9fb4ff',
    playerQuestKey: 'seer',
    appearanceChance: 0.50,
    initialStageId: 'collect_star_fragments',
    stages: {
      collect_star_fragments: {
        title: 'Shards of Unwritten Sky',
        description: 'Collect 5 Star Fragments to restore the Seer’s fractured memory.',
        npcState: 'Gazing Beyond the Veil',
        dialogue: '"Time is cracked glass. Bring me five Star Fragments and I will name what approaches."',
        autoAdvance: true,
        nextStageId: 'attune_futures',
        objectives: [
          {
            id: 'collect_stars',
            type: OBJECTIVE_TYPES.FRAGMENT_COLLECT,
            target: 'star',
            required: 5,
            label: 'Collect Star Fragments'
          }
        ],
        rewards: [
          {
            id: 'reveal_future_events',
            type: REWARD_TYPES.WORLD_MODIFIER,
            name: 'Foresight of the Veil',
            description: 'Reveals upcoming world events and boss omens ahead of time.',
            payload: { modifierId: 'reveal_future_events', revealEvents: true }
          },
          {
            id: 'lore_seer_memory',
            type: REWARD_TYPES.LORE,
            name: 'Prophecy: Fractured Futures',
            payload: { loreId: 'veiled_seer_intro' }
          }
        ],
        cinematic: { id: 'seer_foresight', title: 'Threads of Tomorrow Revealed' }
      },

      attune_futures: {
        title: 'Convergence of the Observatory',
        description: 'Reach the Astral Observatory or Corrupted Void and survive an Astral Event.',
        npcState: 'Weaving World Modifiers',
        dialogue: '"Stand beneath the broken astrolabe. Let the void rewrite what binds this world."',
        autoAdvance: true,
        nextStageId: 'shatter_or_seal_prophecy',
        objectives: [
          {
            id: 'explore_cosmic_biome',
            type: OBJECTIVE_TYPES.BIOME_EXPLORE,
            target: ['observatory', 'void'],
            required: 1,
            label: 'Enter Observatory or Void Realm'
          },
          {
            id: 'complete_astral_event',
            type: OBJECTIVE_TYPES.WORLD_EVENT,
            required: 1,
            label: 'Complete a World Event under the Stars'
          }
        ],
        rewards: [
          {
            id: 'astral_convergence_mod',
            type: REWARD_TYPES.WORLD_MODIFIER,
            name: 'Astral Convergence',
            description: 'Unlocks a toggleable world modifier boosting Star & Void encounters.',
            payload: { modifierId: 'astral_convergence', starFragMult: 1.35, eliteRate: 1.2 }
          },
          {
            id: 'biome_horologium_echo',
            type: REWARD_TYPES.BIOME,
            name: 'Echo of the Shattered Horologium',
            description: 'Unlocks hidden astral anomalies within Observatory cycles.',
            payload: { biomeId: 'observatory_echo' }
          }
        ]
      },

      shatter_or_seal_prophecy: {
        title: 'The Seventh Horizon',
        description: 'Slay a Choir or Void Lord, then decide the fate of the remembered future.',
        npcState: 'Standing at the Crossroads',
        dialogue: '"One last echo blocks the seventh horizon. Defeat it—and choose what survives."',
        autoAdvance: false,
        objectives: [
          {
            id: 'defeat_astral_lord',
            type: OBJECTIVE_TYPES.BOSS_KILL,
            target: ['astrea', 'nameless', 'vaelor'],
            required: 1,
            label: 'Defeat Astrea, Nameless, or Vaelor'
          }
        ],
        choices: [
          {
            id: 'embrace_prophecy',
            label: 'Preserve the Remembered Future',
            description: 'Unlock special cosmic encounters and the Seer’s Astrolabe.',
            outcome: 'complete',
            endingId: 'prophet_of_stars',
            npcState: 'Anchored in Starlight',
            rewards: [
              {
                id: 'special_encounter_horologium',
                type: REWARD_TYPES.BOSS,
                name: 'Special Encounter: Vaelor’s Echo',
                description: 'Unlocks rare special encounters in deep World Tiers.',
                payload: { encounterId: 'shattered_horologium', bossId: 'vaelor' }
              },
              {
                id: 'relic_seer_astrolabe',
                type: REWARD_TYPES.RELIC,
                name: 'Veiled Astrolabe',
                payload: { relicId: 'veiled_astrolabe' }
              }
            ]
          },
          {
            id: 'break_prophecy',
            label: 'Shatter the Prophecy',
            description: 'Destroy destiny to empower mortal blessings and forge freedom.',
            outcome: 'complete',
            endingId: 'unbound_horizon',
            npcState: 'Freed from Sight',
            rewards: [
              {
                id: 'blessing_unbound_fate',
                type: REWARD_TYPES.BLESSING,
                name: 'Unbound Horizon',
                description: 'Unlocks an ultimate fate-breaking blessing.',
                payload: { blessingId: 'unbound_horizon' }
              },
              {
                id: 'class_echo_unlock',
                type: REWARD_TYPES.CLASS,
                name: 'Prophet’s Mantle Sigil',
                description: 'Unlocks Prophet-themed class relic synergy.',
                payload: { classPerkId: 'seer_mantle' }
              }
            ]
          }
        ]
      }
    }
  }
];

// ============================================================================
// QUESTLINE MANAGER (PERSISTENCE, PROGRESSION, BRANCHING & HOOKS)
// ============================================================================

class QuestlineManagerImpl {
  constructor() {
    this.registry = new Map();
    this.states = new Map();
    this.unlockedRewards = new Map(); // type -> Set(id)
    this.pendingCinematics = [];
    this.listeners = {
      notify: new Set(),
      stageComplete: new Set(),
      questComplete: new Set(),
      questFailed: new Set(),
      rewardGranted: new Set(),
      cinematic: new Set()
    };
    this.initialized = false;
    this.currentRunId = 0;
    this.runQuestEventsSpawned = 0;

    for (const def of QUESTLINE_DEFINITIONS) {
      this.registerQuestline(def);
    }
  }

  registerQuestline(def) {
    const q = def instanceof Questline ? def : new Questline(def);
    this.registry.set(q.id, q);
    if (!this.states.has(q.id)) {
      this.states.set(q.id, new QuestState(q.id));
    }
    return q;
  }

  ensureInit() {
    if (this.initialized) return;
    this.initialized = true;
    this.load();
  }

  // -------------------- PERSISTENCE --------------------

  serialize() {
    this.ensureInit();
    const quests = {};
    for (const [id, st] of this.states.entries()) {
      quests[id] = st.toJSON();
    }
    const unlocks = {};
    for (const [type, set] of this.unlockedRewards.entries()) {
      unlocks[type] = [...set];
    }
    return {
      version: 1,
      currentRunId: this.currentRunId,
      quests,
      unlocks
    };
  }

  load(rawData = null) {
    let data = rawData;

    if (!data && metaSave?.questlines) {
      data = metaSave.questlines;
    }
    if (!data && typeof localStorage !== 'undefined') {
      try {
        const raw = localStorage.getItem(QUEST_STORAGE_KEY);
        if (raw) data = JSON.parse(raw);
      } catch (_) {
        data = null;
      }
    }

    this.unlockedRewards.clear();
    for (const t of Object.values(REWARD_TYPES)) {
      this.unlockedRewards.set(t, new Set());
    }

    if (data && typeof data === 'object') {
      this.currentRunId = data.currentRunId || 0;
      const savedQuests = data.quests || {};
      for (const [id, ql] of this.registry.entries()) {
        const st = new QuestState(id, savedQuests[id] || null);
        if (st.status === QUEST_STATUS.ACTIVE && !ql.getStage(st.currentStageId)) {
          st.currentStageId = ql.initialStageId;
        }
        this.states.set(id, st);
      }
      const savedUnlocks = data.unlocks || {};
      for (const [type, ids] of Object.entries(savedUnlocks)) {
        if (!this.unlockedRewards.has(type)) this.unlockedRewards.set(type, new Set());
        const set = this.unlockedRewards.get(type);
        for (const id of ids || []) set.add(id);
      }
    } else {
      for (const id of this.registry.keys()) {
        this.states.set(id, new QuestState(id));
      }
    }

    this.initialized = true;
    this.syncPlayerQuestMirror();
  }

  save() {
    const payload = this.serialize();
    if (metaSave) {
      metaSave.questlines = payload;
      metaSave.questUnlocks = payload.unlocks;
      try {
        persistSave?.();
      } catch (_) {}
    }
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem(QUEST_STORAGE_KEY, JSON.stringify(payload));
      } catch (_) {}
    }
    return payload;
  }

  syncPlayerQuestMirror() {
    if (!state?.player?.quests) return;
    for (const ql of this.registry.values()) {
      if (!ql.playerQuestKey) continue;
      const st = this.states.get(ql.id);
      if (!st) continue;
      if (st.status === QUEST_STATUS.UNDISCOVERED) {
        state.player.quests[ql.playerQuestKey] = 'Undiscovered';
      } else if (st.status === QUEST_STATUS.COMPLETED) {
        state.player.quests[ql.playerQuestKey] = `Completed (${st.ending || 'Resolved'})`;
      } else if (st.status === QUEST_STATUS.FAILED) {
        state.player.quests[ql.playerQuestKey] = `Failed (${st.ending || 'Severed'})`;
      } else {
        state.player.quests[ql.playerQuestKey] = st.npcState || 'Active';
      }
    }
  }

  // -------------------- HOOKS & NOTIFICATIONS --------------------

  on(hookName, listener) {
    if (!this.listeners[hookName] || typeof listener !== 'function') return () => {};
    this.listeners[hookName].add(listener);
    return () => this.listeners[hookName].delete(listener);
  }

  emitHook(hookName, payload) {
    const set = this.listeners[hookName];
    if (!set) return;
    for (const fn of set) {
      try {
        fn(payload);
      } catch (_) {}
    }
  }

  queueCinematic(ql, stage, extra = {}) {
    if (!stage?.cinematic) return;
    const entry = {
      questId: ql.id,
      questName: ql.name,
      stageId: stage.id,
      ...stage.cinematic,
      ...extra
    };
    this.pendingCinematics.push(entry);
    this.emitHook('cinematic', entry);
  }

  // -------------------- CORE PROGRESSION ENGINE --------------------

  discoverQuest(questId, { silent = false } = {}) {
    this.ensureInit();
    const ql = this.registry.get(questId);
    const st = this.states.get(questId);
    if (!ql || !st) return null;
    if (st.status !== QUEST_STATUS.UNDISCOVERED) return st;
    if (ql.unlockCondition && !ql.unlockCondition(this)) return null;

    const firstStage = ql.getStage(ql.initialStageId);
    st.status = QUEST_STATUS.ACTIVE;
    st.currentStageId = ql.initialStageId;
    st.npcState = firstStage?.npcState || 'Active';
    st.discoveredAt = Date.now();
    st.lastRunId = this.currentRunId;
    st.runsSeen++;

    if (!silent) {
      addFeed?.(`Quest Started: ${ql.name}`, ql.color);
      showBanner?.('NEW QUESTLINE', ql.name, ql.color, 2.4);
      this.emitHook('notify', { kind: 'discover', quest: ql, state: st });
    }
    this.syncPlayerQuestMirror();
    this.save();
    return st;
  }

  areStageObjectivesComplete(ql, st, stage) {
    if (!stage) return false;
    for (const obj of stage.objectives) {
      if (obj.optional) continue;
      if ((st.objectives[obj.id] || 0) < obj.required) return false;
    }
    return true;
  }

  grantRewards(ql, st, rewards = []) {
    for (const rw of rewards) {
      if (st.rewardsClaimed.includes(rw.id)) continue;
      st.rewardsClaimed.push(rw.id);

      if (!this.unlockedRewards.has(rw.type)) {
        this.unlockedRewards.set(rw.type, new Set());
      }
      this.unlockedRewards.get(rw.type).add(rw.id);

      // Integrate directly with core game reward hooks when present
      if (rw.type === REWARD_TYPES.LORE && rw.payload?.loreId) {
        try { unlockLore?.(rw.payload.loreId); } catch (_) {}
      } else if (rw.type === REWARD_TYPES.CURRENCY) {
        const p = rw.payload || {};
        try {
          addMetaCurrency?.(p.gold || 0, p.shards || 0, p.essence || 0);
          if (p.frags) {
            for (const [fk, amt] of Object.entries(p.frags)) grantFrag?.(fk, amt);
          }
        } catch (_) {}
      }

      addFeed?.(`Quest Reward [${ql.npcName}]: ${rw.name}`, ql.color);
      this.emitHook('rewardGranted', { quest: ql, state: st, reward: rw });
    }
  }

  addProgress(questId, objectiveIdOrEvent, amount = 1, payload = {}) {
    this.ensureInit();
    const ql = this.registry.get(questId);
    let st = this.states.get(questId);
    if (!ql || !st) return false;

    if (st.status === QUEST_STATUS.UNDISCOVERED) {
      st = this.discoverQuest(questId);
      if (!st) return false;
    }
    if (st.status !== QUEST_STATUS.ACTIVE) return false;

    const stage = ql.getStage(st.currentStageId);
    if (!stage) return false;

    let changed = false;
    for (const obj of stage.objectives) {
      const idMatch = objectiveIdOrEvent === obj.id;
      const evtMatch = obj.matches(objectiveIdOrEvent, payload);
      if (!idMatch && !evtMatch) continue;

      const prev = st.objectives[obj.id] || 0;
      if (prev >= obj.required) continue;

      const next = Math.min(obj.required, prev + Math.max(1, amount));
      st.objectives[obj.id] = next;
      changed = true;

      addFeed?.(`${ql.name}: ${obj.label} (${next}/${obj.required})`, ql.color);
      this.emitHook('notify', { kind: 'progress', quest: ql, stage, objective: obj, progress: next, required: obj.required });
    }

    if (changed) {
      if (stage.autoAdvance && this.areStageObjectivesComplete(ql, st, stage)) {
        this.advance(questId);
      } else {
        this.syncPlayerQuestMirror();
        this.save();
      }
    }
    return changed;
  }

  advance(questId, { choiceId = null, force = false } = {}) {
    this.ensureInit();
    const ql = this.registry.get(questId);
    const st = this.states.get(questId);
    if (!ql || !st) return null;

    if (st.status === QUEST_STATUS.UNDISCOVERED) {
      return this.discoverQuest(questId);
    }
    if (st.status !== QUEST_STATUS.ACTIVE) return st;

    const stage = ql.getStage(st.currentStageId);
    if (!stage) return st;

    if (!force && !this.areStageObjectivesComplete(ql, st, stage)) {
      return st;
    }

    // Handle branching player choice if present on stage
    let chosen = null;
    if (stage.choices?.length) {
      if (!choiceId) {
        // Stage completed objectives and awaits a player decision
        this.emitHook('notify', { kind: 'choice_ready', quest: ql, stage, state: st });
        this.save();
        return st;
      }
      chosen = stage.choices.find(c => c.id === choiceId);
      if (!chosen) return st;
      st.decisions[stage.id] = choiceId;
      if (chosen.npcState) st.npcState = chosen.npcState;
    }

    if (!st.completedSteps.includes(stage.id)) {
      st.completedSteps.push(stage.id);
    }

    this.grantRewards(ql, st, stage.rewards);
    if (chosen?.rewards?.length) {
      this.grantRewards(ql, st, chosen.rewards);
    }
    this.queueCinematic(ql, stage, { choiceId });
    this.emitHook('stageComplete', { quest: ql, stage, state: st, choice: chosen });

    // Determine next transition
    if (chosen?.outcome === 'fail') {
      return this.failQuest(questId, chosen.endingId || 'branch_failed', chosen.description || 'Quest failed by choice.');
    }

    const nextStageId = chosen ? (chosen.outcome === 'complete' ? null : chosen.nextStageId) : stage.nextStageId;
    if (!nextStageId) {
      return this.completeQuest(questId, chosen?.endingId || stage.ending?.id || 'resolved');
    }

    const nextStage = ql.getStage(nextStageId);
    if (!nextStage) {
      return this.completeQuest(questId, chosen?.endingId || 'resolved');
    }

    st.currentStageId = nextStage.id;
    st.npcState = chosen?.npcState || nextStage.npcState || st.npcState;
    addFeed?.(`${ql.name} — ${nextStage.title}`, ql.color);
    this.syncPlayerQuestMirror();
    this.save();
    return st;
  }

  completeQuest(questId, endingId = 'resolved') {
    this.ensureInit();
    const ql = this.registry.get(questId);
    const st = this.states.get(questId);
    if (!ql || !st || st.status === QUEST_STATUS.COMPLETED) return st;

    const stage = ql.getStage(st.currentStageId);
    st.status = QUEST_STATUS.COMPLETED;
    st.ending = endingId;
    st.completedAt = Date.now();
    if (stage?.ending?.title) {
      st.npcState = stage.ending.title;
    }

    showBanner?.('QUESTLINE COMPLETE', `${ql.name}: ${st.npcState}`, ql.color, 2.8);
    try { unlockAchievement?.(`Quest: ${ql.name}`); } catch (_) {}
    this.emitHook('questComplete', { quest: ql, state: st, endingId });
    this.syncPlayerQuestMirror();
    this.save();
    return st;
  }

  failQuest(questId, endingId = 'failed', reason = 'Quest failed.') {
    this.ensureInit();
    const ql = this.registry.get(questId);
    const st = this.states.get(questId);
    if (!ql || !st || st.status === QUEST_STATUS.FAILED) return st;

    st.status = QUEST_STATUS.FAILED;
    st.ending = endingId;
    st.failedReason = reason;
    st.completedAt = Date.now();

    addFeed?.(`Quest Failed: ${ql.name} (${endingId})`, '#ff5b6c');
    showBanner?.('QUESTLINE FAILED', ql.name, '#ff5b6c', 2.6);
    this.emitHook('questFailed', { quest: ql, state: st, endingId, reason });
    this.syncPlayerQuestMirror();
    this.save();
    return st;
  }

  // -------------------- WORLD INTEGRATION DISPATCHER --------------------

  beginRun() {
    this.ensureInit();
    this.currentRunId++;
    this.runQuestEventsSpawned = 0;
    this.syncPlayerQuestMirror();
    this.save();
  }

  /**
   * Natural pacing check so not every run contains every quest event.
   */
  rollRunEncounterCandidate(allowedQuestIds = null) {
    this.ensureInit();
    if (this.runQuestEventsSpawned >= 2) return null;

    const candidates = [];
    for (const ql of this.registry.values()) {
      if (allowedQuestIds && !allowedQuestIds.includes(ql.id)) continue;
      const st = this.states.get(ql.id);
      if (!st) continue;
      if (st.status === QUEST_STATUS.COMPLETED || st.status === QUEST_STATUS.FAILED) continue;
      if (st.lastRunId === this.currentRunId) continue;
      if (this.currentRunId - st.lastRunId < ql.minRunsBetween) continue;
      if (ql.unlockCondition && !ql.unlockCondition(this)) continue;
      candidates.push({ ql, st });
    }

    if (!candidates.length) return null;
    const chosen = candidates[(Math.random() * candidates.length) | 0];
    if (Math.random() > chosen.ql.appearanceChance) return null;

    this.runQuestEventsSpawned++;
    chosen.st.lastRunId = this.currentRunId;
    chosen.st.runsSeen++;
    this.save();
    return chosen.ql;
  }

  notify(eventType, payload = {}) {
    this.ensureInit();
    let anyChanged = false;

    for (const ql of this.registry.values()) {
      const st = this.states.get(ql.id);
      if (!st) continue;

      // Auto-discover from matching world triggers if eligible
      if (st.status === QUEST_STATUS.UNDISCOVERED) {
        const first = ql.getStage(ql.initialStageId);
        const matchesFirst = first?.objectives.some(o => o.matches(eventType, payload));
        if (!matchesFirst) continue;
        this.discoverQuest(ql.id);
      }

      if (st.status !== QUEST_STATUS.ACTIVE) continue;
      const stage = ql.getStage(st.currentStageId);
      if (!stage) continue;

      // Check optional failure triggers
      if (stage.failureTriggers?.length) {
        const failed = stage.failureTriggers.some(ft => {
          const id = payload.target ?? payload.id ?? payload.bossId;
          return ft.type === eventType && (!ft.target || ft.target === id);
        });
        if (failed) {
          this.failQuest(ql.id, 'lost_in_ash', 'A vital thread was severed.');
          anyChanged = true;
          continue;
        }
      }

      const amt = payload.amount ?? 1;
      if (this.addProgress(ql.id, eventType, amt, payload)) {
        anyChanged = true;
      }
    }

    return anyChanged;
  }

  // -------------------- QUERY & UI HOOK HELPERS --------------------

  getState(questId) {
    this.ensureInit();
    return this.states.get(questId) || null;
  }

  isComplete(questId) {
    this.ensureInit();
    return this.states.get(questId)?.status === QUEST_STATUS.COMPLETED;
  }

  getActiveQuestlines() {
    this.ensureInit();
    const list = [];
    for (const ql of this.registry.values()) {
      const st = this.states.get(ql.id);
      if (st?.status === QUEST_STATUS.ACTIVE) {
        list.push({ questline: ql, state: st, stage: ql.getStage(st.currentStageId) });
      }
    }
    return list;
  }

  getRewards(questId) {
    this.ensureInit();
    if (!questId) {
      const all = [];
      for (const ql of this.registry.values()) {
        const st = this.states.get(ql.id);
        all.push(...ql.getAllRewards().map(r => ({
          ...r,
          questId: ql.id,
          claimed: st?.rewardsClaimed.includes(r.id) || false
        })));
      }
      return all;
    }
    const ql = this.registry.get(questId);
    const st = this.states.get(questId);
    if (!ql) return [];
    return ql.getAllRewards().map(r => ({
      ...r,
      claimed: st?.rewardsClaimed.includes(r.id) || false
    }));
  }

  hasUnlock(rewardType, rewardId) {
    this.ensureInit();
    return this.unlockedRewards.get(rewardType)?.has(rewardId) || false;
  }

  getUnlockedRewards(rewardType) {
    this.ensureInit();
    return [...(this.unlockedRewards.get(rewardType) || [])];
  }

  getActiveWorldModifiers() {
    this.ensureInit();
    const mods = [];
    for (const ql of this.registry.values()) {
      for (const rw of ql.getAllRewards()) {
        if (rw.type === REWARD_TYPES.WORLD_MODIFIER && this.hasUnlock(REWARD_TYPES.WORLD_MODIFIER, rw.id)) {
          mods.push(rw);
        }
      }
    }
    return mods;
  }

  getTrackerEntries() {
    return this.getActiveQuestlines().map(({ questline, state: st, stage }) => ({
      id: questline.id,
      name: questline.name,
      icon: questline.icon,
      color: questline.color,
      stageTitle: stage?.title || '',
      npcState: st.npcState,
      awaitingChoice: Boolean(stage?.choices?.length && questline && this.areStageObjectivesComplete(questline, st, stage)),
      objectives: (stage?.objectives || [])
        .filter(o => !o.hidden)
        .map(o => ({
          id: o.id,
          label: o.label,
          current: st.objectives[o.id] || 0,
          required: o.required,
          done: (st.objectives[o.id] || 0) >= o.required
        }))
    }));
  }

  getQuestLog() {
    this.ensureInit();
    const out = [];
    for (const ql of this.registry.values()) {
      const st = this.states.get(ql.id);
      const stage = ql.getStage(st?.currentStageId);
      out.push({
        id: ql.id,
        name: ql.name,
        description: ql.description,
        npcName: ql.npcName,
        icon: ql.icon,
        color: ql.color,
        status: st?.status || QUEST_STATUS.UNDISCOVERED,
        npcState: st?.npcState || 'Unknown',
        currentStage: stage
          ? {
              id: stage.id,
              title: stage.title,
              description: stage.description,
              dialogue: stage.dialogue,
              choices: stage.choices || null,
              readyForChoice: Boolean(stage.choices?.length && this.areStageObjectivesComplete(ql, st, stage)),
              objectives: stage.objectives.map(o => ({
                id: o.id,
                label: o.label,
                current: st.objectives[o.id] || 0,
                required: o.required,
                done: (st.objectives[o.id] || 0) >= o.required
              }))
            }
          : null,
        completedSteps: [...(st?.completedSteps || [])],
        decisions: { ...(st?.decisions || {}) },
        rewardsClaimed: [...(st?.rewardsClaimed || [])],
        ending: st?.ending || null
      });
    }
    return out;
  }

  consumeCinematic() {
    return this.pendingCinematics.shift() || null;
  }
}

// ============================================================================
// SINGLETON INSTANCE & REQUIRED PUBLIC EXPORTS
// ============================================================================

export const QuestlineManager = new QuestlineManagerImpl();

export function addQuestProgress(questId, objectiveIdOrEvent, amount = 1, payload = {}) {
  return QuestlineManager.addProgress(questId, objectiveIdOrEvent, amount, payload);
}

export function advanceQuest(questId, options = {}) {
  return QuestlineManager.advance(questId, options);
}

export function getQuestState(questId) {
  return QuestlineManager.getState(questId);
}

export function isQuestComplete(questId) {
  return QuestlineManager.isComplete(questId);
}

export function getActiveQuestlines() {
  return QuestlineManager.getActiveQuestlines();
}

export function getQuestRewards(questId) {
  return QuestlineManager.getRewards(questId);
}

// Save & UI Hook Exports
export const serializeQuests = () => QuestlineManager.serialize();
export const loadQuests = data => QuestlineManager.load(data);
export const getQuestTrackerData = () => QuestlineManager.getTrackerEntries();
export const getQuestLogData = () => QuestlineManager.getQuestLog();
export const onQuestHook = (hookName, listener) => QuestlineManager.on(hookName, listener);
export const consumeQuestCinematic = () => QuestlineManager.consumeCinematic();
export const notifyQuestEvent = (eventType, payload) => QuestlineManager.notify(eventType, payload);
export const hasQuestUnlock = (type, id) => QuestlineManager.hasUnlock(type, id);