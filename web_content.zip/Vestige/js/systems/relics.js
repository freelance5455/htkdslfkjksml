import { metaSave, hasUnlock, spendCost, persistSave } from '../core/save.js';
import { RELICS } from '../data/relicData.js';

export function unlockRelic(relic) {
  const key = `rel_${relic.id}`;
  if (hasUnlock(key) || !spendCost(relic.cost)) return false;
  metaSave.unlocks.push(key);
  if (metaSave.equippedRelics.length < 3) {
    metaSave.equippedRelics.push(relic.id);
  }
  persistSave();
  return true;
}

export function toggleRelic(relic) {
  const key = `rel_${relic.id}`;
  if (!hasUnlock(key)) {
    return unlockRelic(relic);
  }
  const eq = metaSave.equippedRelics.includes(relic.id);
  if (eq) {
    metaSave.equippedRelics = metaSave.equippedRelics.filter(x => x !== relic.id);
    persistSave();
    return true;
  }
  if (metaSave.equippedRelics.length < 3) {
    metaSave.equippedRelics.push(relic.id);
    persistSave();
    return true;
  }
  return false;
}

export function applyEquippedRelics(s) {
  for (const rid of metaSave.equippedRelics) {
    RELICS.find(r => r.id === rid)?.apply(s);
  }
}