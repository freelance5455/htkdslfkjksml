import { unpack } from '../core/utilities.js';
import { metaSave, hasUnlock, persistSave } from '../core/save.js';
import { state } from '../core/game.js';

import { WEAPONS_DEF } from '../data/classes.js';
import { recalcStats } from '../entities/player.js';
import { addFeed, showBanner } from '../ui/notifications.js';

export const MASTERIES = unpack([
  [
    'sword',
    'Sword Mastery',
    'Sun Hammer & Blades',
    '+8% Blade/Hammer Dmg/lv',
    'Lv2: +4 Armor & +6% Atk Spd',
    'Lv5: +25% Evolved Blade Potency',
    (s, lv) => {
      if (lv >= 2) {
        s.armor += 4;
        s.atkSpeed += 0.06;
      }
      if (lv >= 4) s.dmgPct += 0.12;
    }
  ],
  [
    'bow',
    'Bow Mastery',
    'Moon Bow Precision',
    '+8% Bow Damage/lv',
    'Lv2: +8% Move Spd & +4% Crit',
    'Lv5: +1 Proj & +25% Evo Potency',
    (s, lv) => {
      if (lv >= 2) {
        s.moveSpeedMult += 0.08;
        s.critChance += 0.04;
      }
      if (lv >= 5) s.projBonus += 1;
    }
  ],
  [
    'dagger',
    'Dagger Mastery',
    'Shadow Dagger Arts',
    '+8% Dagger Damage/lv',
    'Lv2: +5% Crit & +20% Crit Dmg',
    'Lv5: -15% Dash CD & +25% Evo',
    (s, lv) => {
      if (lv >= 2) {
        s.critChance += 0.05;
        s.critDmg += 0.20;
      }
      if (lv >= 5) s.dashCdr += 0.15;
    }
  ],
  [
    'staff',
    'Staff Mastery',
    'Fire Staff & Grimoire',
    '+8% Spell/Summon Dmg/lv',
    'Lv2: +10% Area & +6% CDR',
    'Lv5: +20% Summons & +25% Evo',
    (s, lv) => {
      if (lv >= 2) {
        s.areaPct += 0.10;
        s.cdr += 0.06;
      }
      if (lv >= 5) s.summonDmg += 0.20;
    }
  ],
  [
    'greatsword',
    'Greatsword Mastery',
    'Iron Greatsword Might',
    '+8% Cleave Damage/lv',
    'Lv2: +8 Flat Dmg & +15% Area',
    'Lv5: +25% Cleave Size & +25% Evo',
    (s, lv) => {
      if (lv >= 2) {
        s.flatDmg += 8;
        s.areaPct += 0.15;
      }
      if (lv >= 5) s.areaPct += 0.25;
    }
  ]
], ['id', 'name', 'sub', 'bonusTxt', 'passiveTxt', 'evoTxt', 'apply']);

export function addMasteryXp(id, amt) {
  const m = metaSave.masteries[id];
  if (!m || m.lvl >= 5) return;
  m.xp += amt;
  const need = 120 * (m.lvl + 1);
  if (m.xp >= need) {
    m.xp -= need;
    m.lvl++;
    const def = MASTERIES.find(x => x.id === id);
    addFeed(`${def.name} reached Rank ${m.lvl}!`, '#ffd700');
    showBanner(def.name.toUpperCase(), `Mastery Rank ${m.lvl} Unlocked`, '#ffd700', 2.4);
    if (state.player) recalcStats();
    persistSave();
  }
}

export function weaponMult(wKey) {
  const w = state.player.weapons[wKey];
  const def = WEAPONS_DEF[wKey];
  const mLvl = metaSave.masteries[def?.mastery]?.lvl || 0;
  return (
    (1 + mLvl * 0.08) *
    (w?.evolved && hasUnlock('evo_surge') ? 1.25 : 1) *
    (w?.evolved && mLvl >= 5 ? 1.25 : 1)
  );
}

export function applyMasteryStats(s) {
  for (const m of MASTERIES) {
    const lv = metaSave.masteries[m.id]?.lvl || 0;
    if (lv > 0) m.apply(s, lv);
  }
}