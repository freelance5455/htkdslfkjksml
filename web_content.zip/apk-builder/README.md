# HTML → APK

## চালানোর নিয়ম
    docker build -t html-to-apk .
    docker run -p 3000:3000 -e KS_PASS=তোমার_পাসওয়ার্ড -v $(pwd)/keystore:/app/keystore html-to-apk

তারপর http://localhost:3000 খোলো।

- `keystore/` ফোল্ডার সংরক্ষণ করো: আপডেটের জন্য একই key লাগে।
- `MAX_BUILDS` env দিয়ে একসাথে কয়টা বিল্ড চলবে ঠিক করো (ডিফল্ট ১)।
- HTML ফাইলে CSS/JS ইনলাইন রাখো (একটাই ফাইল আপলোড হয়)।
