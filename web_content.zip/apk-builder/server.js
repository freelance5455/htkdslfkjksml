const express = require('express');
const multer = require('multer');
const rateLimit = require('express-rate-limit');
const sharp = require('sharp');
const { spawn } = require('child_process');
const fs = require('fs/promises');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const MAX_BUILDS = +process.env.MAX_BUILDS || 1;       // একসাথে কয়টা বিল্ড চলবে
const KS_PASS = process.env.KS_PASS || 'changeit';     // প্রোডাকশনে অবশ্যই বদলাও
const ROOT = __dirname;
const TEMPLATE = path.join(ROOT, 'template');
const WORK = path.join(ROOT, 'work');
const OUT = path.join(ROOT, 'out');
const KEYSTORE = path.join(ROOT, 'keystore', 'release.jks');
const SIZES = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };

const jobs = new Map(); // id -> { status, error, created }

// ---------- helpers ----------
function run(cmd, args, opts = {}) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { timeout: 5 * 60 * 1000, ...opts });
    let log = '';
    p.stdout.on('data', d => (log += d));
    p.stderr.on('data', d => (log += d));
    p.on('error', reject);
    p.on('close', code => (code === 0 ? resolve(log) : reject(new Error(log.slice(-1500)))));
  });
}

async function ensureKeystore() {
  try { await fs.access(KEYSTORE); return; } catch {}
  await fs.mkdir(path.dirname(KEYSTORE), { recursive: true });
  await run('keytool', [
    '-genkeypair', '-keystore', KEYSTORE, '-alias', 'key', '-keyalg', 'RSA', '-keysize', '2048',
    '-validity', '10000', '-storepass', KS_PASS, '-keypass', KS_PASS, '-dname', 'CN=HtmlToApk',
  ]);
}

let running = 0;
const queue = [];
function enqueue(fn) { queue.push(fn); pump(); }
function pump() {
  while (running < MAX_BUILDS && queue.length) {
    running++;
    queue.shift()().finally(() => { running--; pump(); });
  }
}

async function build(id, { html, icon, appName, appId }) {
  const dir = path.join(WORK, id);
  try {
    await fs.cp(TEMPLATE, dir, { recursive: true });
    await fs.writeFile(path.join(dir, 'app/src/main/assets/index.html'), html);

    for (const [density, px] of Object.entries(SIZES)) {
      const d = path.join(dir, `app/src/main/res/mipmap-${density}`);
      await fs.mkdir(d, { recursive: true });
      await sharp(icon).resize(px, px, { fit: 'cover' }).png().toFile(path.join(d, 'ic_launcher.png'));
    }

    await run('gradle', [
      '-p', dir, 'assembleRelease', '--no-daemon', '-q',
      `-PappId=${appId}`, `-PappName=${appName}`,
      `-PksFile=${KEYSTORE}`, `-PksPass=${KS_PASS}`, `-PksAlias=key`,
    ]);

    await fs.mkdir(OUT, { recursive: true });
    await fs.copyFile(path.join(dir, 'app/build/outputs/apk/release/app-release.apk'), path.join(OUT, `${id}.apk`));
    jobs.get(id).status = 'done';
  } catch (e) {
    console.error(id, e.message);
    Object.assign(jobs.get(id), { status: 'error', error: 'বিল্ড ব্যর্থ হয়েছে। HTML বা আইকন ফাইল চেক করে আবার চেষ্টা করো।' });
  } finally {
    fs.rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}

// ---------- app ----------
const app = express();
app.use(express.static(path.join(ROOT, 'public')));

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 2 } });
const limiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 10, message: { error: 'অনেক বেশি রিকোয়েস্ট। কিছুক্ষণ পরে চেষ্টা করো।' } });

app.post('/api/build', limiter, upload.fields([{ name: 'html', maxCount: 1 }, { name: 'icon', maxCount: 1 }]), async (req, res) => {
  try {
    const htmlFile = req.files?.html?.[0];
    const iconFile = req.files?.icon?.[0];
    if (!htmlFile || !iconFile) return res.status(400).json({ error: 'HTML ফাইল ও আইকন দুটোই দাও।' });
    if (!/\.html?$/i.test(htmlFile.originalname)) return res.status(400).json({ error: 'ফাইলটি .html হতে হবে।' });

    const meta = await sharp(iconFile.buffer).metadata().catch(() => null);
    if (!meta || !['png', 'jpeg', 'webp'].includes(meta.format)) return res.status(400).json({ error: 'আইকন PNG, JPG বা WebP হতে হবে।' });

    const appName = (req.body.appName || 'My App').replace(/[^\p{L}\p{M}\p{N} _-]/gu, '').trim().slice(0, 30) || 'My App';
    let appId = (req.body.appId || '').trim().toLowerCase();
    if (!appId) appId = 'com.webapk.app' + crypto.randomBytes(3).toString('hex');
    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(appId)) return res.status(400).json({ error: 'প্যাকেজ আইডি সঠিক নয় (যেমন: com.example.app)।' });

    const id = crypto.randomBytes(8).toString('hex');
    jobs.set(id, { status: 'queued', created: Date.now() });
    enqueue(async () => { jobs.get(id).status = 'building'; await build(id, { html: htmlFile.buffer, icon: iconFile.buffer, appName, appId }); });
    res.json({ id });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'সার্ভারে সমস্যা হয়েছে।' });
  }
});

app.get('/api/status/:id', (req, res) => {
  const j = jobs.get(req.params.id);
  if (!j) return res.status(404).json({ error: 'জব পাওয়া যায়নি।' });
  res.json({ status: j.status, error: j.error });
});

app.get('/download/:id', (req, res) => {
  if (!/^[a-f0-9]{16}$/.test(req.params.id)) return res.sendStatus(400);
  res.download(path.join(OUT, `${req.params.id}.apk`), 'app.apk', err => { if (err && !res.headersSent) res.sendStatus(404); });
});

// ১ ঘণ্টা পর পুরনো APK ও জব মুছে ফেলো
setInterval(async () => {
  const now = Date.now();
  for (const [id, j] of jobs) {
    if (now - j.created > 60 * 60 * 1000) { jobs.delete(id); fs.rm(path.join(OUT, `${id}.apk`), { force: true }).catch(() => {}); }
  }
}, 10 * 60 * 1000);

ensureKeystore().then(() => app.listen(PORT, () => console.log('http://localhost:' + PORT))).catch(e => { console.error('keystore error', e.message); process.exit(1); });
