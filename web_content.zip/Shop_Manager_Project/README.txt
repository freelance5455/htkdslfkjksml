SHOP MANAGER — MOBILE PROJECT ZIP
=================================

This is a simple offline-first web app project intended for Android/mobile testing.

FEATURES
- Home dashboard: product count, customers, outstanding credit, payments received.
- Stock: custom categories, custom main/small units, conversion factor, sale rate, add/reduce stock, archive product.
- Udhari: customer name, required address, optional phone, custom typed items, quantity x rate, automatic stock reduction, payment collection and balance.
- Hisaab: month-wise credit/payment totals and stock movement history.
- English, Hindi, Hinglish UI.
- JSON backup download and restore.
- Browser localStorage: data is stored locally on this device/browser, no account/server required.

IMPORTANT LIMITATIONS / SAFE USE
- This is a starter version. Test it with dummy records first and keep frequent backups.
- Browser storage is not identical to a native Android app database; clearing browser/app data may erase it. Export backups regularly.
- For app-wrapper APKs, confirm the wrapper supports local files, JavaScript, file picker/downloads, and persistent WebView storage.
- No purchase-cost field/profit calculation is included because the selected requirement was sale rate and credit accounting.
- Stock quantities are stored in the product's small/base unit; main-unit display uses the conversion factor.
- Manual items are created under “Manual item” category when used in a credit entry and can drive stock negative.
- Payments are applied to oldest outstanding credit entries first.
- Deleting a customer removes that customer's credit/payment records after confirmation; export a backup first.
- Not a tax/GST invoicing app; no formal bill generation.

HOW TO TEST ON ANDROID
1. Extract this ZIP using a file manager.
2. Open index.html in a modern browser if your browser permits local HTML. Some browser features may be restricted for file:// URLs.
3. For offline/PWA installation and service worker, serve it from HTTPS hosting (e.g. free Cloudflare Pages) or use a compatible APK wrapper.
4. In the app, add a few test products/customers, then test backup and restore before using real shop data.

APKForge
--------
Use APKForge's documented workflow to import the project. This ZIP contains a web project, not a prebuilt APK. APKForge's exact input requirements vary, so if it asks for a particular folder/file structure, compare its instructions before proceeding. Do not assume a ZIP automatically becomes an APK without a compatible build step.

CLOUDFLARE PAGES
----------------
You can publish the files as a static site on Cloudflare Pages using its free tier. A Cloudflare Pages URL is a free subdomain; a custom domain is optional and typically costs money. Avoid uploading real customer data to a public code repository.

UPDATED QUANTITY ENTRY
----------------------
Product setup now asks for full main units and loose small units separately. Example: 5 boxes x 10 pieces + 7 loose pieces = 57 pieces total. Stock add/reduce allows choosing the unit. Credit item defaults to the small unit and offers a unit selector for matched products. Home recent activity is scrollable.
