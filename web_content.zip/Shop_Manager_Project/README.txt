SHOP MANAGER — MOBILE PROJECT ZIP
=================================

This is a simple offline-first web app project intended for Android/mobile testing.

FEATURES
- Home dashboard: product count, customers, outstanding credit, payments received.
- Stock: custom categories, custom main/small units, conversion factor, sale rate, add/reduce stock, archive product.
- Udhari: customer name, required address, optional phone, custom typed items, quantity x rate, automatic stock reduction, payment collection and balance.
- Hisaab: month-wise credit/payment totals and stock movement history.
- English, Hindi, Hinglish UI.
- JSON backup download and restore.
- Browser localStorage: data is stored locally on this device/browser, no account/server required.

IMPORTANT LIMITATIONS / SAFE USE
- This is a starter version. Test it with dummy records first and keep frequent backups.
- Browser storage is not identical to a native Android app database; clearing browser/app data may erase it. Export backups regularly.
- For app-wrapper APKs, confirm the wrapper supports local files, JavaScript, file picker/downloads, and persistent WebView storage.
- No purchase-cost field/profit calculation is included because the selected requirement was sale rate and credit accounting.
- Stock quantities are stored in the product's small/base unit; main-unit display uses the conversion factor.
- Manual items are created under “Manual item” category when used in a credit entry and can drive stock negative.
- Payments are applied to oldest outstanding credit entries first.
- Deleting a customer removes that customer's credit/payment records after confirmation; export a backup first.
- Not a tax/GST invoicing app; no formal bill generation.

HOW TO TEST ON ANDROID
1. Extract this ZIP using a file manager.
2. Open index.html in a modern browser if your browser permits local HTML. Some browser features may be restricted for file:// URLs.
3. For offline/PWA installation and service worker, serve it from HTTPS hosting (e.g. free Cloudflare Pages) or use a compatible APK wrapper.
4. In the app, add a few test products/customers, then test backup and restore before using real shop data.

APKForge
--------
Use APKForge's documented workflow to import the project. This ZIP contains a web project, not a prebuilt APK. APKForge's exact input requirements vary, so if it asks for a particular folder/file structure, compare its instructions before proceeding. Do not assume a ZIP automatically becomes an APK without a compatible build step.

CLOUDFLARE PAGES
----------------
You can publish the files as a static site on Cloudflare Pages using its free tier. A Cloudflare Pages URL is a free subdomain; a custom domain is optional and typically costs money. Avoid uploading real customer data to a public code repository.

UPDATED QUANTITY ENTRY
----------------------
Product setup now asks for full main units and loose small units separately. Example: 5 boxes x 10 pieces + 7 loose pieces = 57 pieces total. Stock add/reduce allows choosing the unit. Credit item defaults to the small unit and offers a unit selector for matched products. Home recent activity is scrollable.

UI POLISH UPDATE
----------------
Navigation tabs and section cards now have stronger borders. Home recent activity is contained in a scrollable box. Udhari product suggestions render in a bordered panel directly below the item field rather than relying on the native browser datalist popup.


UI / SCROLL IMPROVEMENTS
------------------------
- Home recent activity no longer uses a nested inner scroll box that can fight with the phone's page scrolling. It shows the latest 5 items by default; use Show all activity to expand the list and normal page scrolling to browse.
- Stock products are shown in compact responsive wrap cards (two columns on most phones, three on wider screens; one column on very narrow screens) so the list is easier to scan.

NEW SECTION: PURANA PAISA JAMA
------------------------------
- Separate fifth tab for "Purana paisa jama".
- Saves customer name, address, date, and optional note.
- Record either a money deposit (amount) or returned goods (item name and quantity).
- This section is deliberately separate from Udhari: entries do not alter credit balances, product stock, or Udhari payment records.
- New entries are included in the existing JSON backup/restore because the full local database is exported.
- Existing stored data is preserved; the new records list initializes empty for old installs.


PDF BACKUP REPORT
- Backup / Restore now includes a separate "PDF हिसाब डाउनलोड / प्रिंट" button.
- It opens a print-ready report with products, stock, customers, credit records, payments, old-money deposits/goods returns, and stock activity.
- In Chrome, choose "Save as PDF" in the print dialog to save the report as a PDF file.
- The original JSON backup/restore button is kept. PDF is for viewing/printing and cannot restore app data.
- If Chrome blocks the report window, allow pop-ups for the app/site and tap the PDF button again.


SCROLL BOX + PDF PRINT FIX (2026-10)
- Home recent activity now stays inside a fixed-height, touch-scrollable box. It no longer expands the page with a "show all" button.
- Stock products are inside a bounded scroll area; product cards remain in a responsive wrap/grid layout.
- Udhari customer cards are also inside a bounded touch-scrollable box.
- PDF report now uses an in-page hidden print frame instead of window.open, to reduce popup-blocker issues in mobile preview/WebView. On supported Chrome, use the print dialog's "Save as PDF" destination.
- The JSON backup/restore feature remains unchanged. Keep using JSON for actual data restoration.
- Note: Some embedded app previews/WebViews do not support printing. If print UI does not appear, open the app's web page in Chrome and use the PDF report button there.
