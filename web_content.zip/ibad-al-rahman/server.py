#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
خادم برنامج عباد الرحمن (Ibad Al-Rahman Local Server)
يعمل على المنفذ 8369 ويدعم التصفح من الكمبيوتر والهاتف وتحميل ملف APK
"""

import os
import sys
import socket
import webbrowser
from http.server import HTTPServer, SimpleHTTPRequestHandler

PORT = 8369
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'

class IbadAlRahmanHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-cache, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

    def guess_type(self, path):
        mime_type = super().guess_type(path)
        if path.endswith('.js'):
            return 'application/javascript; charset=utf-8'
        elif path.endswith('.css'):
            return 'text/css; charset=utf-8'
        elif path.endswith('.html'):
            return 'text/html; charset=utf-8'
        elif path.endswith('.apk'):
            return 'application/vnd.android.package-archive'
        return mime_type

def run():
    os.chdir(DIRECTORY)
    server_address = ('0.0.0.0', PORT)
    local_ip = get_local_ip()
    local_url = f"http://localhost:{PORT}"
    mobile_url = f"http://{local_ip}:{PORT}"

    try:
        httpd = HTTPServer(server_address, IbadAlRahmanHandler)
        print("=" * 65)
        print("✨ تم تشغيل برنامج 'عباد الرحمن' بنجاح ✨")
        print(f"💻 للكمبيوتر: {local_url}")
        print(f"📱 للهاتف المحمول (في نفس شبكة الواي فاي): {mobile_url}")
        print("📦 رابط تنزيل ملف APK مباشرة: " + f"{mobile_url}/IbadAlRahman.apk")
        print("⚡ نظام ترددات 369 والنسبة الذهبية مفعّل")
        print("📖 القرآن الكريم بدون تشكيل • لفظ 'الله' بدون شدة")
        print("📿 الأذكار 3 مرات مع التصفير التلقائي بداية كل يوم جديد")
        print("=" * 65)

        try:
            webbrowser.open(local_url)
        except Exception:
            pass

        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nتم إيقاف الخادم بسلام.")
        sys.exit(0)
    except Exception as e:
        print(f"حدث خطأ أثناء تشغيل الخادم: {e}")
        sys.exit(1)

if __name__ == '__main__':
    run()
