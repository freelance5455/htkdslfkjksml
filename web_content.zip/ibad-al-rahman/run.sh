#!/usr/bin/env bash
# تشغيل برنامج عباد الرحمن الذكي
cd "/home/aelhariri/المشاريع/ibad-al-rahman"

# إذا كان السيرفر يعمل مسبقاً، افتح المتصفح مباشرة
if python3 -c "import urllib.request; urllib.request.urlopen('http://localhost:8369', timeout=1)" >/dev/null 2>&1; then
    echo "✨ برنامج عباد الرحمن يعمل بالفعل، جاري فتح المتصفح..."
    xdg-open "http://localhost:8369" 2>/dev/null || python3 -m webbrowser "http://localhost:8369"
else
    echo "✨ جاري إطلاق خادم برنامج عباد الرحمن..."
    python3 server.py
fi
