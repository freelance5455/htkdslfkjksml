/**
 * تطبيق عباد الرحمن (Ibad Al-Rahman) - المنطق البرمجي الرئيسي
 * إدارة المصحف، الأدعية القرآنية مع عدادات 369 المدمجة، الترددات، والتنفس الذهبي
 */

class IbadAlRahmanApp {
  constructor() {
    this.currentTab = 'quran';
    this.currentSurah = null;
    this.fontSize = 24; // الحجم الافتراضي لخط القراءة
    this.selectedReciter = 'ar.alafasy';
    this.duaCounts = {}; // تخزين عدادات الأدعية المستقلة
    this.tasbihCount = 0;
    this.tasbihTarget = 9;
    this.audioElement = document.getElementById('quranAudioElement');
    this.currentPlayingSurah = null;
    this.isAudioPlaying = false;

    // استعادة العدادات والإعدادات المحفوظة
    this.loadSavedState();
    this.init();
  }

  init() {
    this.initNavigation();
    this.initQuranIndex();
    this.initDuasSection();
    this.initTasbihSection();
    this.initFrequenciesSection();
    this.initRefreshEngine();
    this.initThemeToggle();
    this.initAudioPlayer();

    // ربط صوت التلاوة بمحرك رنين 528 هرتز
    if (this.audioElement && window.freqEngine) {
      window.freqEngine.attachRecitationAudio(this.audioElement);
    }
  }

  // --- حفظ واستعادة الحالة مع التصفير التلقائي اليومي وتطهير الـ 33 ---
  loadSavedState() {
    try {
      this.checkAndResetDailyDuas();

      const savedDuaCounts = localStorage.getItem('ibad_dua_counts');
      if (savedDuaCounts) this.duaCounts = JSON.parse(savedDuaCounts);

      // تطهير فوري وشامل لأي قيمة 33 قديمة كانت مخزنة في ذاكرة المتصفح
      let purged = false;
      for (let id in this.duaCounts) {
        if (this.duaCounts[id] && (this.duaCounts[id].target === 33 || this.duaCounts[id].count === 33)) {
          this.duaCounts[id].target = 1;
          this.duaCounts[id].count = 0;
          purged = true;
        }
      }

      const savedTasbih = localStorage.getItem('ibad_tasbih_count');
      if (savedTasbih) this.tasbihCount = parseInt(savedTasbih, 10) || 0;
      if (this.tasbihCount === 33) {
        this.tasbihCount = 0;
        purged = true;
      }
      if (this.tasbihTarget === 33) {
        this.tasbihTarget = 9;
        purged = true;
      }

      if (purged) this.saveState();

      const savedTheme = localStorage.getItem('ibad_theme');
      if (savedTheme === 'light') document.body.classList.add('light-theme');
    } catch (e) {}
  }

  /**
   * التصفير التلقائي اليومي مع بداية كل يوم جديد (منتصف الليل)
   */
  checkAndResetDailyDuas() {
    try {
      const now = new Date();
      // تاريخ اليوم بصيغة YYYY-MM-DD
      const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
      const lastActiveDate = localStorage.getItem('ibad_last_day_stamp');

      if (!lastActiveDate) {
        localStorage.setItem('ibad_last_day_stamp', todayStr);
      } else if (lastActiveDate !== todayStr) {
        // يوم جديد بدأ! تصفير جميع عدادات الأدعية اليومية تلقائياً
        this.duaCounts = {};
        localStorage.removeItem('ibad_dua_counts');
        localStorage.setItem('ibad_last_day_stamp', todayStr);
        console.log("✨ يوم جديد مبارك: تم تصفير عدادات الأدعية تلقائياً للورد الجديد.");
      }
    } catch (e) {}
  }

  saveState() {
    try {
      localStorage.setItem('ibad_dua_counts', JSON.stringify(this.duaCounts));
      localStorage.setItem('ibad_tasbih_count', this.tasbihCount.toString());
    } catch (e) {}
  }

  // --- 1. إدارة التنقل بين الأقسام ---
  initNavigation() {
    const tabs = document.querySelectorAll('.nav-tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const targetSection = tab.getAttribute('data-tab');
        this.switchTab(targetSection);
      });
    });

    document.getElementById('brandBtn').addEventListener('click', () => {
      this.switchTab('quran');
    });
  }

  switchTab(tabId) {
    this.currentTab = tabId;
    document.querySelectorAll('.nav-tab').forEach(t => {
      t.classList.toggle('active', t.getAttribute('data-tab') === tabId);
    });

    document.querySelectorAll('.section-view').forEach(s => {
      s.classList.remove('active');
    });

    const target = document.getElementById(`section-${tabId}`);
    if (target) {
      target.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  // --- 2. قسم المصحف الشريف (بدون تشكيل) ---
  initQuranIndex() {
    const surahsGrid = document.getElementById('surahsGrid');
    const searchInput = document.getElementById('quranSearchInput');
    const backBtn = document.getElementById('backToIndexBtn');
    const randomBtn = document.getElementById('randomAyahBtn');
    const incFont = document.getElementById('increaseFontBtn');
    const decFont = document.getElementById('decreaseFontBtn');
    const playAudioBtn = document.getElementById('playSurahAudioBtn');
    const reciterSelect = document.getElementById('reciterSelect');

    if (reciterSelect) {
      reciterSelect.addEventListener('change', (e) => {
        this.selectedReciter = e.target.value;
        if (this.isAudioPlaying && this.currentSurah) {
          this.playSurahAudio(this.currentSurah.num);
        }
      });
    }

    if (!window.QURAN_DATA || !surahsGrid) return;

    this.renderSurahs(window.QURAN_DATA);

    // البحث بدون تشكيل
    searchInput.addEventListener('input', (e) => {
      const q = e.target.value.trim().toLowerCase();
      if (!q) {
        this.renderSurahs(window.QURAN_DATA);
        return;
      }
      const filtered = window.QURAN_DATA.filter(s => 
        s.name.includes(q) || s.enName.toLowerCase().includes(q) || s.num.toString() === q
      );
      this.renderSurahs(filtered);
    });

    backBtn.addEventListener('click', () => {
      document.getElementById('quran-reader-view').style.display = 'none';
      document.getElementById('quran-index-view').style.display = 'block';
    });

    randomBtn.addEventListener('click', () => {
      this.pickRandomAyah();
    });

    incFont.addEventListener('click', () => {
      this.fontSize = Math.min(48, this.fontSize + 2);
      document.getElementById('readerVersesContainer').style.fontSize = `${this.fontSize}px`;
    });

    decFont.addEventListener('click', () => {
      this.fontSize = Math.max(18, this.fontSize - 2);
      document.getElementById('readerVersesContainer').style.fontSize = `${this.fontSize}px`;
    });

    playAudioBtn.addEventListener('click', () => {
      if (this.currentSurah) {
        this.playSurahAudio(this.currentSurah.num);
      }
    });

    this.pickRandomAyah(); // اختيار قبس أولي
  }

  renderSurahs(list) {
    const grid = document.getElementById('surahsGrid');
    grid.innerHTML = '';

    list.forEach(surah => {
      const card = document.createElement('div');
      card.className = 'surah-card';
      card.innerHTML = `
        <div class="surah-number-badge">${surah.num}</div>
        <div class="surah-info">
          <div class="surah-title">${surah.name}</div>
          <div class="surah-meta">${surah.type} • ${surah.count} آية</div>
        </div>
        <div style="color:var(--gold-primary); font-size: 1.1rem;">📖</div>
      `;
      card.addEventListener('click', () => this.openSurahReader(surah));
      grid.appendChild(card);
    });
  }

  openSurahReader(surah) {
    this.currentSurah = surah;
    document.getElementById('quran-index-view').style.display = 'none';
    const reader = document.getElementById('quran-reader-view');
    reader.style.display = 'block';

    document.getElementById('readerSurahTitle').textContent = `سورة ${surah.name}`;
    document.getElementById('readerSurahMeta').textContent = `${surah.type} • عدد آياتها ${surah.count} • بالرسم العربي البسيط بدون تشكيل`;

    // إخفاء البسملة لسورة التوبة
    const basmalahEl = document.getElementById('readerBasmalah');
    if (surah.num === 9) {
      basmalahEl.style.display = 'none';
    } else {
      basmalahEl.style.display = 'block';
    }

    const container = document.getElementById('readerVersesContainer');
    container.style.fontSize = `${this.fontSize}px`;
    container.innerHTML = '';

    surah.ayahs.forEach(ayah => {
      const ayahSpan = document.createElement('span');
      ayahSpan.className = 'ayah-text';
      ayahSpan.id = `ayah-${ayah.num}`;
      ayahSpan.textContent = ayah.text + ' ';

      const numBadge = document.createElement('span');
      numBadge.className = 'ayah-number';
      numBadge.textContent = ayah.num;

      container.appendChild(ayahSpan);
      container.appendChild(numBadge);
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  pickRandomAyah() {
    if (!window.QURAN_DATA) return;
    const sIndex = Math.floor(Math.random() * window.QURAN_DATA.length);
    const surah = window.QURAN_DATA[sIndex];
    if (surah && surah.ayahs && surah.ayahs.length > 0) {
      const aIndex = Math.floor(Math.random() * surah.ayahs.length);
      const ayah = surah.ayahs[aIndex];
      const textEl = document.getElementById('featuredVerseText');
      const refEl = document.getElementById('featuredVerseRef');
      if (textEl && refEl) {
        textEl.style.opacity = '0';
        setTimeout(() => {
          textEl.textContent = ayah.text;
          refEl.textContent = `سورة ${surah.name} • الآية ${ayah.num}`;
          textEl.style.opacity = '1';
        }, 200);
      }
    }
  }

  // --- 3. قسم الأدعية القرآنية مع عدادات 369 المدمجة تحت كل دعاء ---
  initDuasSection() {
    const grid = document.getElementById('duasGrid');
    const categoryBtns = document.querySelectorAll('.category-pill');

    if (!window.QURANIC_DUAS || !grid) return;

    this.renderDuas(window.QURANIC_DUAS);

    categoryBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        categoryBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const cat = btn.getAttribute('data-category');
        if (cat === 'all') {
          this.renderDuas(window.QURANIC_DUAS);
        } else {
          const filtered = window.QURANIC_DUAS.filter(d => d.category === cat);
          this.renderDuas(filtered);
        }
      });
    });
  }

  renderDuas(duasList) {
    const grid = document.getElementById('duasGrid');
    grid.innerHTML = '';

    duasList.forEach(dua => {
      if (!this.duaCounts[dua.id]) {
        // للأذكار 3 مرات وللأدعية العامة قراءة وتدبر مرة واحدة يومياً
        const defaultTarget = dua.category === 'أذكار التحصين الكبرى' ? 3 : (dua.targetCount || 1);
        this.duaCounts[dua.id] = { count: 0, target: defaultTarget };
      }
      const item = this.duaCounts[dua.id];

      const card = document.createElement('div');
      card.className = `dua-card ${item.count >= item.target ? 'completed-card' : ''}`;
      card.id = `dua-card-${dua.id}`;

      card.innerHTML = `
        <div>
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span class="dua-category-badge">${dua.category}</span>
            <span style="font-size:var(--font-xs); color:var(--text-muted);">${dua.title}</span>
          </div>

          <div class="dua-text" id="dua-text-${dua.id}">
            ﴿ ${dua.text} ﴾
          </div>

          <div class="dua-reference">
            <span>سورة ${dua.surah} • آية ${dua.ayah}</span>
            <span style="color:var(--emerald-accent);">${dua.wisdom}</span>
          </div>
        </div>

        <!-- عداد الأذكار الذكي المدمج تحت الدعاء باهتزاز 369 وتصفير يومي -->
        <div style="margin-top:15px; padding-top:12px; border-top:1px solid var(--border-subtle); background:var(--bg-surface-elevated); border-radius:var(--radius-md); padding:12px;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
            <span style="font-size:var(--font-xs); color:var(--gold-primary); font-weight:bold;">
              📿 ورد القراءة اليومي:
            </span>
            <div style="display:flex; gap:4px;">
              <button class="target-btn ${item.target === 1 ? 'active' : ''}" data-id="${dua.id}" data-t="1">1</button>
              <button class="target-btn ${item.target === 3 ? 'active' : ''}" data-id="${dua.id}" data-t="3">3</button>
              <button class="target-btn ${item.target === 6 ? 'active' : ''}" data-id="${dua.id}" data-t="6">6</button>
              <button class="target-btn ${item.target === 9 ? 'active' : ''}" data-id="${dua.id}" data-t="9">9</button>
            </div>
          </div>

          <div style="display:flex; gap:10px; align-items:center;">
            <button class="btn-icon dua-counter-btn" id="dua-btn-${dua.id}" style="flex:1; justify-content:center; background:var(--bg-surface); border:1px solid var(--gold-dark); font-size:var(--font-md); padding:8px;">
              <span id="dua-count-val-${dua.id}">${item.count}</span> / <span id="dua-target-val-${dua.id}">${item.target}</span>
              <span id="dua-btn-label-${dua.id}" style="font-size:var(--font-xs); margin-right:6px; color:var(--gold-light);">
                ${item.count >= item.target ? '✓ تم إنجاز ورد اليوم' : 'قراءة وتدبر ⚡'}
              </span>
            </button>
            <button class="btn-icon reset-dua-btn" data-id="${dua.id}" title="تصفير عداد هذا الدعاء" style="padding:8px 12px;">
              🔄
            </button>
          </div>
        </div>
      `;

      grid.appendChild(card);

      // ربط زر التسبيح والاهتزاز الخاص بالدعاء
      const counterBtn = card.querySelector(`#dua-btn-${dua.id}`);
      counterBtn.addEventListener('click', () => {
        this.incrementDuaCount(dua.id);
      });

      // ربط أزرار تبديل الهدف (3 / 6 / 9 / 33)
      card.querySelectorAll('.target-btn').forEach(tBtn => {
        tBtn.addEventListener('click', (e) => {
          const tVal = parseInt(e.target.getAttribute('data-t'), 10);
          this.duaCounts[dua.id].target = tVal;
          card.querySelectorAll('.target-btn').forEach(b => b.classList.remove('active'));
          e.target.classList.add('active');
          card.querySelector(`#dua-target-val-${dua.id}`).textContent = tVal;
          this.saveState();
        });
      });

      // زر تصفير عداد هذا الدعاء
      const resetBtn = card.querySelector('.reset-dua-btn');
      resetBtn.addEventListener('click', () => {
        this.duaCounts[dua.id].count = 0;
        card.querySelector(`#dua-count-val-${dua.id}`).textContent = '0';
        card.classList.remove('completed-card');
        this.saveState();
      });
    });
  }

  incrementDuaCount(duaId) {
    const item = this.duaCounts[duaId];
    item.count++;

    // تشغيل نظام الاهتزاز الحسي التناغمي 369
    if (window.engine369) {
      window.engine369.triggerVibration(item.count);
    }

    // تحديث الشاشة
    const countDisplay = document.getElementById(`dua-count-val-${duaId}`);
    if (countDisplay) countDisplay.textContent = item.count;

    const card = document.getElementById(`dua-card-${duaId}`);
    if (item.count >= item.target) {
      if (card) {
        card.style.borderColor = 'var(--emerald-accent)';
        card.style.boxShadow = '0 0 25px var(--emerald-glow)';
        const label = document.getElementById(`dua-btn-label-${duaId}`);
        if (label) label.textContent = '✓ تم إنجاز ورد اليوم';
      }
    }

    this.saveState();
  }

  // --- 4. قسم مسبحة 369 والتنفس الذهبي ---
  initTasbihSection() {
    const ring = document.getElementById('tasbihRingBtn');
    const countEl = document.getElementById('tasbihCountDisplay');
    const targetEl = document.getElementById('tasbihTargetDisplay');
    const resetBtn = document.getElementById('resetTasbihBtn');
    const breathingBtn = document.getElementById('toggleBreathingBtn');
    const breathingCircle = document.getElementById('breathingCircle');
    const breathingText = document.getElementById('breathingText');
    const modeBtns = document.querySelectorAll('.tasbih-modes button');

    countEl.textContent = this.tasbihCount;
    targetEl.textContent = `الهدف: ${this.tasbihTarget}`;

    modeBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        modeBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.tasbihTarget = parseInt(btn.getAttribute('data-target'), 10);
        targetEl.textContent = `الهدف: ${this.tasbihTarget}`;
      });
    });

    ring.addEventListener('click', () => {
      this.tasbihCount++;
      countEl.textContent = this.tasbihCount;

      // إطلاق الاهتزاز التناغمي 369
      if (window.engine369) {
        window.engine369.triggerVibration(this.tasbihCount);
      }

      this.saveState();
    });

    resetBtn.addEventListener('click', () => {
      this.tasbihCount = 0;
      countEl.textContent = '0';
      this.saveState();
    });

    // التنفس الذهبي 369
    let isBreathing = false;
    breathingBtn.addEventListener('click', () => {
      if (!isBreathing) {
        isBreathing = true;
        breathingBtn.innerHTML = '⏹️ إيقاف تمرين التنفس';
        window.engine369.startBreathing((text, duration, phase) => {
          breathingText.textContent = text;
          breathingCircle.className = `breathing-circle ${phase}`;
        });
      } else {
        isBreathing = false;
        breathingBtn.innerHTML = '▶️ بدء تمرين التنفس الذهبي';
        window.engine369.stopBreathing();
        breathingText.textContent = 'جاهز لبدء تمرين السكينة';
        breathingCircle.className = 'breathing-circle';
      }
    });
  }

  // --- 5. مختبر الترددات 369 ومكسر الصوت (528 هرتز الأساسي) ---
  initFrequenciesSection() {
    const deck = document.getElementById('frequencyDeck');
    const quickBtn = document.getElementById('quickFreqBtn');
    const volSlider = document.getElementById('freqVolumeSlider');
    const volVal = document.getElementById('freqVolumeVal');
    const binauralCheck = document.getElementById('binauralCheckbox');

    if (!window.freqEngine || !deck) return;

    window.freqEngine.frequencies.forEach(f => {
      const card = document.createElement('div');
      card.className = `frequency-card ${f.hz === 528 ? 'active-primary' : ''}`;
      card.id = `freq-card-${f.hz}`;
      card.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
          <span class="freq-hz">${f.name}</span>
          <span class="freq-root">جذر: ${f.root}</span>
        </div>
        <p style="font-size:var(--font-xs); color:var(--text-secondary); margin-bottom:12px; line-height:1.6;">
          ${f.description}
        </p>
        <button class="btn-icon toggle-freq-btn" style="width:100%; justify-content:center;">
          ${window.freqEngine.isPlaying && window.freqEngine.currentFreq === f.hz ? '⏹️ إيقاف' : '▶️ تشغيل التردد'}
        </button>
      `;

      card.querySelector('.toggle-freq-btn').addEventListener('click', () => {
        window.freqEngine.toggle(f.hz);
      });

      deck.appendChild(card);
    });

    // الزر السريع بالأعلى (تردد 528 هرتز للسكينة)
    if (quickBtn) {
      quickBtn.addEventListener('click', () => {
        window.freqEngine.toggle(528);
      });
    }

    volSlider.addEventListener('input', (e) => {
      const v = e.target.value / 100;
      volVal.textContent = `${e.target.value}%`;
      window.freqEngine.setVolume(v);
    });

    binauralCheck.addEventListener('change', (e) => {
      window.freqEngine.setBinaural(e.target.checked);
    });

    // مراقبة تبدل حالة التردد لتحديث الواجهة
    window.addEventListener('frequencyStateChange', (e) => {
      const { isPlaying, freq } = e.detail;
      document.querySelectorAll('.frequency-card').forEach(c => c.classList.remove('active'));
      if (isPlaying) {
        const activeCard = document.getElementById(`freq-card-${freq}`);
        if (activeCard) activeCard.classList.add('active');
        if (quickBtn) quickBtn.classList.add('active');
      } else {
        if (quickBtn) quickBtn.classList.remove('active');
      }
    });
  }

  // --- 6. مشغل التلاوة الصوتي المدمج مع رنين 528 هرتز ---
  initAudioPlayer() {
    const playBar = document.getElementById('audioPlayerBar');
    const toggleBtn = document.getElementById('toggleAudioPlayBtn');
    const closeBtn = document.getElementById('closeAudioPlayerBtn');
    const titleEl = document.getElementById('audioPlayerTitle');

    if (!this.audioElement) return;

    toggleBtn.addEventListener('click', () => {
      if (this.audioElement.paused) {
        this.audioElement.play();
        toggleBtn.innerHTML = '⏸️ إيقاف مؤقت';
        this.isAudioPlaying = true;
      } else {
        this.audioElement.pause();
        toggleBtn.innerHTML = '▶️ استئناف';
        this.isAudioPlaying = false;
      }
    });

    closeBtn.addEventListener('click', () => {
      this.audioElement.pause();
      this.audioElement.currentTime = 0;
      playBar.style.display = 'none';
      this.isAudioPlaying = false;
    });

    this.audioElement.addEventListener('ended', () => {
      toggleBtn.innerHTML = '▶️ إعادة الاستماع';
      this.isAudioPlaying = false;
    });
  }

  playSurahAudio(surahNum) {
    if (!this.audioElement) return;
    this.currentPlayingSurah = surahNum;
    const playBar = document.getElementById('audioPlayerBar');
    const titleEl = document.getElementById('audioPlayerTitle');
    const reciterEl = document.getElementById('audioPlayerReciter');
    const toggleBtn = document.getElementById('toggleAudioPlayBtn');

    // جلب رابط التلاوة من سيرفر القرآن المعتمد بجودة عالية MP3
    const padNum = surahNum.toString().padStart(3, '0');
    let reciterFolder = 'ar.alafasy';
    let reciterName = 'مشاري راشد العفاسي';

    if (this.selectedReciter === 'ar.abdulbasitmurattal') {
      reciterFolder = 'ar.abdulbasitmurattal';
      reciterName = 'عبد الباسط عبد الصمد (مرتل)';
    } else if (this.selectedReciter === 'ar.minshawi') {
      reciterFolder = 'ar.minshawi';
      reciterName = 'محمد صديق المنشاوي';
    } else if (this.selectedReciter === 'ar.husary') {
      reciterFolder = 'ar.husary';
      reciterName = 'محمود خليل الحصري';
    }

    const audioUrl = `https://cdn.islamic.network/quran/audio-surah/128/${this.selectedReciter}/${surahNum}.mp3`;

    this.audioElement.src = audioUrl;
    playBar.style.display = 'flex';
    titleEl.textContent = `تلاوة سورة ${this.currentSurah ? this.currentSurah.name : surahNum} (بصيغة ورنين 528 هرتز)`;
    reciterEl.textContent = `بصوت الشيخ ${reciterName} • التردد التناغمي مفعّل`;
    toggleBtn.innerHTML = '⏸️ إيقاف مؤقت';

    this.audioElement.play().then(() => {
      this.isAudioPlaying = true;
      // إشعار خدمة الخلفية في الأندرويد للاستمرار عند قفل الشاشة
      if (window.AndroidApp && typeof window.AndroidApp.startBackgroundAudio === 'function') {
        window.AndroidApp.startBackgroundAudio();
      }
      // تشغيل نغمة 528 هرتز خافتة اختيارية للسكينة في الخلفية
      if (window.freqEngine && !window.freqEngine.isPlaying) {
        window.freqEngine.start(528);
      }
    }).catch(err => {
      console.warn("Audio playback notice:", err);
    });
  }

  // --- 7. محرك الريفرش 369 ---
  initRefreshEngine() {
    const select = document.getElementById('refreshRateSelect');
    if (select && window.engine369) {
      window.engine369.setRefreshMode(select.value);

      select.addEventListener('change', (e) => {
        window.engine369.setRefreshMode(e.target.value);
      });

      // عند إطلاق حدث الريفرش الدوري 369، يتم تحديث الآية المختارة
      window.addEventListener('refresh369', () => {
        this.pickRandomAyah();
      });
    }
  }

  // --- 8. تبديل النمط المظلم / الفاتح ---
  initThemeToggle() {
    const themeBtn = document.getElementById('themeToggleBtn');
    const themeIcon = document.getElementById('themeIcon');

    themeBtn.addEventListener('click', () => {
      document.body.classList.toggle('light-theme');
      const isLight = document.body.classList.contains('light-theme');
      themeIcon.textContent = isLight ? '🌙' : '☀️';
      localStorage.setItem('ibad_theme', isLight ? 'light' : 'dark');
    });
  }
}

// تشغيل التطبيق عند اكتمال تحميل الصفحة
window.addEventListener('DOMContentLoaded', () => {
  window.app = new IbadAlRahmanApp();
});
