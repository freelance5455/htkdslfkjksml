/**
 * محرك إيقاع 369، نظام التحديث (Refresh)، ونظام الاهتزاز التناغمي (Haptic 369)
 * تطبيق عباد الرحمن
 */

class Engine369 {
  constructor() {
    this.hasVibration = 'vibrate' in navigator;
    this.refreshIntervalId = null;
    this.microPulseIntervalId = null;
    this.refreshMode = '9s'; // الخيار الافتراضي: تحديث كل 9 ثوانٍ
    this.sessionTimerId = null;
    this.sessionRemainingSeconds = 0;
    this.breathingActive = false;
    this.breathingPhase = 'idle'; // inhale, hold, exhale
    this.breathingTimerId = null;

    this.initMicroPulse();
  }

  // --- 1. نظام الاهتزاز التناغمي المعتمد على 369 (Haptic 369) ---

  /**
   * تشغيل الاهتزاز الحسي ومطابقته بدقة مع أنماط 3-6-9
   * @param {number} currentCount - رقم العداد الحالي
   * @param {string} mode - 'tap', 'step3', 'step6', 'step9', 'custom'
   */
  triggerVibration(currentCount = 1) {
    let pattern = [36]; // نبضة ناعمة 36ms عند كل ضغطة
    let toneType = 'click';

    if (currentCount > 0) {
      if (currentCount % 9 === 0 || currentCount === 99) {
        // نمط التناغم الأسمى عند مضاعفات 9 أو 99
        pattern = [120, 60, 120, 60, 369];
        toneType = 'step9';
      } else if (currentCount % 6 === 0) {
        // نمط الرنين السداسي عند مضاعفات 6
        pattern = [90, 60, 90, 60, 90];
        toneType = 'step6';
      } else if (currentCount % 3 === 0) {
        // نمط الاستفتاح الثلاثي عند مضاعفات 3
        pattern = [60, 60, 60];
        toneType = 'step3';
      }
    }

    // إرسال الاهتزاز للهاتف المحمول
    if (this.hasVibration) {
      try {
        navigator.vibrate(pattern);
      } catch (e) {
        // إذا كان هناك تقييد من المتصفح
      }
    }

    // تشغيل الرنين الصوتي التناغمي كبديل فوري على الكمبيوتر
    if (window.freqEngine) {
      window.freqEngine.playHapticTone(toneType);
    }
  }

  // --- 2. محرك التحديث والريفرش 369 (Dynamic 369 Refresh) ---

  /**
   * نبضات دقيقة كل 369 ميلي ثانية لتناغم الرسوم والمؤشرات
   */
  initMicroPulse() {
    if (this.microPulseIntervalId) clearInterval(this.microPulseIntervalId);
    this.microPulseIntervalId = setInterval(() => {
      window.dispatchEvent(new CustomEvent('pulse369', { detail: { timestamp: Date.now() } }));
    }, 369);
  }

  /**
   * ضبط دورة التحديث التلقائي للآيات والأدعية (3s / 6s / 9s / 3m / 6m / 9m)
   */
  setRefreshMode(mode) {
    this.refreshMode = mode;
    if (this.refreshIntervalId) {
      clearInterval(this.refreshIntervalId);
      this.refreshIntervalId = null;
    }

    let intervalMs = 9000; // الافتراضي 9 ثوانٍ
    switch (mode) {
      case '3s': intervalMs = 3000; break;
      case '6s': intervalMs = 6000; break;
      case '9s': intervalMs = 9000; break;
      case '3m': intervalMs = 3 * 60 * 1000; break;
      case '6m': intervalMs = 6 * 60 * 1000; break;
      case '9m': intervalMs = 9 * 60 * 1000; break;
      case 'off': return;
    }

    this.refreshIntervalId = setInterval(() => {
      window.dispatchEvent(new CustomEvent('refresh369', { detail: { mode: this.refreshMode } }));
    }, intervalMs);

    window.dispatchEvent(new CustomEvent('refreshModeChange', { detail: { mode: this.refreshMode, intervalMs } }));
  }

  // --- 3. مؤقت الجلسات الروحية 369 (Spiritual Session Timer) ---

  /**
   * بدء جلسة قراءة وتدبر مؤقتة (3 دقائق، 6 دقائق، أو 9 دقائق)
   */
  startSession(minutes, onTick, onComplete) {
    this.stopSession();
    this.sessionRemainingSeconds = minutes * 60;

    this.sessionTimerId = setInterval(() => {
      this.sessionRemainingSeconds--;

      if (typeof onTick === 'function') {
        const mins = Math.floor(this.sessionRemainingSeconds / 60);
        const secs = this.sessionRemainingSeconds % 60;
        onTick(mins, secs, this.sessionRemainingSeconds);
      }

      if (this.sessionRemainingSeconds <= 0) {
        this.stopSession();
        // اهتزاز ثلاثي عند نهاية الجلسة
        if (this.hasVibration) navigator.vibrate([180, 100, 180, 100, 369]);
        if (window.freqEngine) window.freqEngine.playHapticTone('golden');
        if (typeof onComplete === 'function') onComplete();
      }
    }, 1000);
  }

  stopSession() {
    if (this.sessionTimerId) {
      clearInterval(this.sessionTimerId);
      this.sessionTimerId = null;
    }
    this.sessionRemainingSeconds = 0;
  }

  // --- 4. تمرين التنفس التناغمي الذهبي (Golden 3-6-9 Breathing) ---
  // شهيق: 3 ثوانٍ | حبس: 6 ثوانٍ | زفير: 9 ثوانٍ

  startBreathing(onStateChange) {
    this.breathingActive = true;
    const cycle = () => {
      if (!this.breathingActive) return;

      // 1. شهيق (3 ثوانٍ)
      this.breathingPhase = 'inhale';
      if (this.hasVibration) navigator.vibrate([60]);
      if (onStateChange) onStateChange('شهيق عميق وملء الصدر بالسكينة', 3, 'inhale');

      this.breathingTimerId = setTimeout(() => {
        if (!this.breathingActive) return;

        // 2. حبس النفس (6 ثوانٍ)
        this.breathingPhase = 'hold';
        if (this.hasVibration) navigator.vibrate([60, 40, 60]);
        if (onStateChange) onStateChange('احتباس النفس واستشعار الطمأنينة', 6, 'hold');

        this.breathingTimerId = setTimeout(() => {
          if (!this.breathingActive) return;

          // 3. زفير (9 ثوانٍ)
          this.breathingPhase = 'exhale';
          if (this.hasVibration) navigator.vibrate([90, 60, 90]);
          if (onStateChange) onStateChange('زفير هادئ وبطيء وإخراج كل توتر', 9, 'exhale');

          this.breathingTimerId = setTimeout(() => {
            if (this.breathingActive) cycle();
          }, 9000);
        }, 6000);
      }, 3000);
    };

    cycle();
  }

  stopBreathing() {
    this.breathingActive = false;
    this.breathingPhase = 'idle';
    if (this.breathingTimerId) {
      clearTimeout(this.breathingTimerId);
      this.breathingTimerId = null;
    }
  }
}

window.engine369 = new Engine369();
