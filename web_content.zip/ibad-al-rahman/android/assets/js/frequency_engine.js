/**
 * محرك الترددات الصوتية التناغمية 369 والنسبة الذهبية
 * مع دعم رنين تردد 528 هرتز (تردد السلام والتحول الإيجابي) للتلاوة
 * مبني عبر Web Audio API
 */

class FrequencyEngine {
  constructor() {
    this.audioCtx = null;
    this.oscillatorL = null;
    this.oscillatorR = null;
    this.gainNode = null;
    this.pannerL = null;
    this.pannerR = null;
    this.isPlaying = false;
    this.currentFreq = 528; // التردد الافتراضي الأساسي المعتمد: 528 هرتز
    this.volume = 0.20; // مستوى صوت التردد المتناغم
    this.binauralEnabled = true;
    this.binauralDiff = 3.69; // فارق النبضة الثنائية 3.69 هرتز

    // عقدة الفلتر الصوتي للقرآن لضبط الرنين عند 528 هرتز
    this.audioSourceNode = null;
    this.filter528Node = null;

    // قائمة الترددات المدعومة المرتبطة بنظام 369 والنسبة الذهبية
    this.frequencies = [
      { hz: 528, name: "528 هرتز (الأساسي)", root: 6, description: "تردد السلام الداخلي، الصفاء الروحي، وتجديد السكينة (جذر 6 من 369)" },
      { hz: 432, name: "432 هرتز", root: 9, description: "تردد التناغم الطبيعي المتناسق مع النسبة الذهبية والكون (جذر 9)" },
      { hz: 396, name: "396 هرتز", root: 9, description: "تردد السكينة والطمأنينة وإزالة التوتر والخوف (جذر 9)" },
      { hz: 639, name: "639 هرتز", root: 9, description: "تردد التراحم والمودة والتناغم القلبي والوجداني (جذر 9)" },
      { hz: 741, name: "741 هرتز", root: 3, description: "تردد النقاء والوضوح واليقظة الذهنية أثناء التلاوة (جذر 3)" },
      { hz: 852, name: "852 هرتز", root: 6, description: "تردد البصيرة والوعي الروحي والتأمل العميق (جذر 6)" },
      { hz: 963, name: "963 هرتز", root: 9, description: "تردد الصفاء الروحي والتسامي والاتصال النوراني (جذر 9)" }
    ];
  }

  initContext() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      this.audioCtx = new AudioContextClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  /**
   * ربط عنصر صوت التلاوة بفلتر رنين 528 هرتز التناغمي
   */
  attachRecitationAudio(audioElement) {
    try {
      this.initContext();
      if (!this.audioSourceNode && audioElement) {
        this.audioSourceNode = this.audioCtx.createMediaElementSource(audioElement);
        
        // فلتر ذروة رنين عند 528 هرتز لتعزيز النغمة التناغمية
        this.filter528Node = this.audioCtx.createBiquadFilter();
        this.filter528Node.type = 'peaking';
        this.filter528Node.frequency.setValueAtTime(528, this.audioCtx.currentTime);
        this.filter528Node.Q.setValueAtTime(3.69, this.audioCtx.currentTime); // عرض النطاق بمعامل 3.69
        this.filter528Node.gain.setValueAtTime(3.69, this.audioCtx.currentTime); // تعزيز ناعم بمقدار 3.69dB

        this.audioSourceNode.connect(this.filter528Node);
        this.filter528Node.connect(this.audioCtx.destination);
      }
    } catch (e) {
      console.warn("Recitation filter attached in fallback mode", e);
    }
  }

  start(freq = this.currentFreq) {
    this.initContext();
    this.stop(); // إيقاف أي مذبذب صوتي سابق

    this.currentFreq = freq;
    const now = this.audioCtx.currentTime;

    // عقدة التحكم بالصوت الرئيسية
    this.gainNode = this.audioCtx.createGain();
    this.gainNode.gain.setValueAtTime(0.0001, now);
    this.gainNode.gain.exponentialRampToValueAtTime(this.volume, now + 1.618); // تدرج زمني بنسبة النسبة الذهبية
    this.gainNode.connect(this.audioCtx.destination);

    if (this.binauralEnabled && this.audioCtx.createStereoPanner) {
      // مذبذب الأذن اليسرى
      this.oscillatorL = this.audioCtx.createOscillator();
      this.oscillatorL.type = 'sine';
      this.oscillatorL.frequency.setValueAtTime(this.currentFreq, now);

      this.pannerL = this.audioCtx.createStereoPanner();
      this.pannerL.pan.setValueAtTime(-1, now);
      this.oscillatorL.connect(this.pannerL);
      this.pannerL.connect(this.gainNode);

      // مذبذب الأذن اليمنى (+3.69 هرتز)
      this.oscillatorR = this.audioCtx.createOscillator();
      this.oscillatorR.type = 'sine';
      this.oscillatorR.frequency.setValueAtTime(this.currentFreq + this.binauralDiff, now);

      this.pannerR = this.audioCtx.createStereoPanner();
      this.pannerR.pan.setValueAtTime(1, now);
      this.oscillatorR.connect(this.pannerR);
      this.pannerR.connect(this.gainNode);

      this.oscillatorL.start(now);
      this.oscillatorR.start(now);
    } else {
      this.oscillatorL = this.audioCtx.createOscillator();
      this.oscillatorL.type = 'sine';
      this.oscillatorL.frequency.setValueAtTime(this.currentFreq, now);
      this.oscillatorL.connect(this.gainNode);
      this.oscillatorL.start(now);
    }

    this.isPlaying = true;
    if (window.AndroidApp && typeof window.AndroidApp.startBackgroundAudio === 'function') {
      window.AndroidApp.startBackgroundAudio();
    }
    window.dispatchEvent(new CustomEvent('frequencyStateChange', { detail: { isPlaying: true, freq: this.currentFreq } }));
  }

  stop() {
    if (!this.isPlaying) return;

    if (this.gainNode && this.audioCtx) {
      const now = this.audioCtx.currentTime;
      this.gainNode.gain.cancelScheduledValues(now);
      this.gainNode.gain.setValueAtTime(this.gainNode.gain.value, now);
      this.gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.8);

      setTimeout(() => {
        if (this.oscillatorL) {
          try { this.oscillatorL.stop(); this.oscillatorL.disconnect(); } catch (e) {}
          this.oscillatorL = null;
        }
        if (this.oscillatorR) {
          try { this.oscillatorR.stop(); this.oscillatorR.disconnect(); } catch (e) {}
          this.oscillatorR = null;
        }
      }, 850);
    }

    this.isPlaying = false;
    if (window.AndroidApp && typeof window.AndroidApp.stopBackgroundAudio === 'function') {
      if (!window.app || !window.app.isAudioPlaying) {
        window.AndroidApp.stopBackgroundAudio();
      }
    }
    window.dispatchEvent(new CustomEvent('frequencyStateChange', { detail: { isPlaying: false, freq: this.currentFreq } }));
  }

  toggle(freq) {
    if (this.isPlaying) {
      if (freq && freq !== this.currentFreq) {
        this.start(freq);
      } else {
        this.stop();
      }
    } else {
      this.start(freq || this.currentFreq);
    }
  }

  setVolume(val) {
    this.volume = Math.max(0, Math.min(1, val));
    if (this.gainNode && this.audioCtx && this.isPlaying) {
      const now = this.audioCtx.currentTime;
      this.gainNode.gain.cancelScheduledValues(now);
      this.gainNode.gain.setValueAtTime(this.gainNode.gain.value, now);
      this.gainNode.gain.linearRampToValueAtTime(this.volume, now + 0.2);
    }
  }

  setBinaural(enabled) {
    this.binauralEnabled = enabled;
    if (this.isPlaying) {
      this.start(this.currentFreq);
    }
  }

  /**
   * رنين صوتي تناغمي 369 / 528 بديل للاهتزاز
   */
  playHapticTone(type = 'click') {
    try {
      this.initContext();
      const now = this.audioCtx.currentTime;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      let freq = 369;
      let duration = 0.06;

      if (type === 'step3') {
        freq = 369;
        duration = 0.12;
      } else if (type === 'step6') {
        freq = 528;
        duration = 0.18;
      } else if (type === 'step9' || type === 'golden') {
        freq = 528;
        duration = 0.369;
      }

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(0.15, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start(now);
      osc.stop(now + duration);
    } catch (e) {
      // تجنب أي أخطاء في حال عدم التفاعل الأولي مع الصفحة
    }
  }
}

window.freqEngine = new FrequencyEngine();
