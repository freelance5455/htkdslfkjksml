#!/usr/bin/env bash
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo "=================================================="
echo "🚀 جاري بناء ملف APK لبرنامج عباد الرحمن..."
echo "=================================================="

# 1. إعداد مسارات جافا وأدوات الأندرويد
export JAVA_HOME="/home/aelhariri/.local/share/flatpak/app/com.google.AndroidStudio/x86_64/stable/e2cf906817efd38b804936f04650e09d19cd8461fff73374ddccb55a1c644463/files/extra/jbr"
export PATH="$JAVA_HOME/bin:$PATH"
ANDROID_JAR="/home/aelhariri/Android/Sdk/platforms/android-36/android.jar"
BUILD_TOOLS="/home/aelhariri/Android/Sdk/build-tools/35.0.0"

# 2. تحديث مجلد الأصول (assets) بأحدث ملفات البرنامج
echo "📦 تحديث الأصول والبيانات..."
mkdir -p android/assets
cp index.html android/assets/
cp -r css android/assets/
cp -r js android/assets/
cp -r data android/assets/

# تنظيف مجلدات البناء المؤقتة
rm -rf android/build android/classes android/dex android/base.apk android/aligned.apk
mkdir -p android/build android/classes android/dex

# 3. تجميع الموارد عبر aapt2
echo "🎨 تجميع الموارد..."
"$BUILD_TOOLS/aapt2" compile --dir android/res -o android/build/resources.zip
"$BUILD_TOOLS/aapt2" link -I "$ANDROID_JAR" \
    --manifest android/AndroidManifest.xml \
    -A android/assets \
    -o android/base.apk \
    android/build/resources.zip \
    --auto-add-overlay

# 4. ترجمة كود الجافا
echo "☕ ترجمة كود الجافا..."
javac --release 17 -d android/classes -cp "$ANDROID_JAR" android/src/com/ibadalrahman/app/*.java

# 5. توليد كود DEX عبر d8
echo "⚙️ توليد dex عبر D8..."
"$BUILD_TOOLS/d8" --lib "$ANDROID_JAR" --output android/dex/ android/classes/com/ibadalrahman/app/*.class

# 6. إضافة classes.dex لحزمة الـ APK
echo "📂 دمج ملفات الـ DEX في الـ APK..."
cd android/dex
jar -uf ../base.apk classes.dex
cd "$DIR"

# 7. محاذاة الحزمة عبر zipalign
echo "📐 محاذاة الحزمة (zipalign)..."
"$BUILD_TOOLS/zipalign" -f -p 4 android/base.apk android/aligned.apk

# 8. توليد مفتاح التوقيع وتوقيع الـ APK
echo "🔐 توقيع ملف الـ APK..."
if [ ! -f android/debug.keystore ]; then
    keytool -genkeypair -validity 10000 \
        -dname "CN=IbadAlRahman,O=IslamicApp,C=SA" \
        -keystore android/debug.keystore \
        -storepass android -keypass android \
        -alias androiddebugkey -keyalg RSA -keysize 2048
fi

"$BUILD_TOOLS/apksigner" sign --ks android/debug.keystore \
    --ks-pass pass:android --key-pass pass:android \
    --ks-key-alias androiddebugkey \
    --out IbadAlRahman.apk android/aligned.apk

# 9. التحقق من صحة التوقيع
echo "✅ التحقق من سلامة الملف النهائي..."
"$BUILD_TOOLS/apksigner" verify IbadAlRahman.apk

echo "=================================================="
echo "🎉 تم إنشاء وتوقيع ملف APK بنجاح تام!"
echo "📁 المسار: $DIR/IbadAlRahman.apk"
echo "الحجم: $(du -h IbadAlRahman.apk | cut -f1)"
echo "=================================================="
