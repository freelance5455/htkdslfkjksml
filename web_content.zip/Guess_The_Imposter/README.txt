GUESS THE IMPOSTER — Offline mobile game

PLAY NOW
1. Extract this ZIP on your Android phone.
2. Open index.html with Chrome.
3. Add 1 to 8 player names (at least 3 are required to start a playable round) and tap গেম শুরু করো.
4. Pass the phone around. Each player taps “আমার পরিচয় দেখাও” privately.
5. Discuss, then each player secretly votes once.
6. Results and leaderboard are calculated automatically.

OFFLINE
The game is a single HTML file and its game logic does not need internet.
After extracting it, keep index.html on your phone and open it in Chrome.

INSTALL-LIKE SHORTCUT
Chrome may offer “Add to Home screen” from its menu when the page is open.
For a true installable Android APK, this package is not an APK; it is an offline browser game.

SCORING
- Each player who votes for the Imposter gets 1 point, even if fewer than half identify them.
- Incorrect votes get 0.
- If correct votes are fewer than incorrect votes, the Imposter gets 3 points.
- If correct votes are more than incorrect votes, the Imposter gets 0.
- Tie: Imposter gets 0 (tie rule used because no tie outcome was specified).

NOTE
Names, scores and round data stay in the current game session. A new game/reset clears them.
