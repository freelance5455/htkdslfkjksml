# File Cleanup & Consolidation Report — 2.4.0

## Consolidated architecture

- `admin.php` remains the single authoritative administration controller/view.
- `app/admin.php` remains the single authoritative admin action handler.
- The authoritative admin UI now uses a grouped responsive sidebar, with dedicated wallet/credit ledger and payment sections.
- `admin-panel.php`, `admin/index.php` and `dashboard/admin.php` are compatibility aliases only; they contain no parallel admin logic.
- `admin_resources_view.php` and `admin_magichour_view.php` remain functional tab partials included by the authoritative admin page.
- `app/payments.php` is the single payment and package service.
- `api/payments.php` handles authenticated checkout and redirect verification.
- `api/flutterwave-webhook.php` handles signed provider notifications.
- `credits.php` is the customer credit purchase page.
- Existing wallet tables and service functions are reused; no parallel wallet was created.

## Removed / replaced

- Removed `ADMIN-PROMOTION.sql`, which promoted a hardcoded email address.
- Removed the registration email allow-list setting from `config.local.example.php`.
- Replaced obsolete README instructions describing the email allow-list.
- Added private storage access-denial files and a root storage rewrite rule.
- Added additive migration `003` for SQLite and MySQL.

## Preserved

- Existing user records and user table structure.
- Existing wallet balances and `credit_transactions` history.
- Existing workspace implementations and provider integrations.
- Existing resource centre and Magic Hour administration partials.
- Existing media, assets, prompts, tutorials and frontend styles/scripts.
- Existing admin aliases to avoid breaking bookmarks or deployed links.

## File inventory

The rebuilt archive contains 139 files. It retains existing historical build/audit reports as historical records; they are not used as evidence of current functionality. No broad deletion was performed solely from filename similarity.
