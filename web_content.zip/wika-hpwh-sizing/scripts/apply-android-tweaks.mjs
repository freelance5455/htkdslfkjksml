// Dijalankan setelah "cap add android": mengganti ikon aplikasi (tetesan air + gelombang panas)
// dan warna latar ikon adaptif dengan file di resources/android-res.
import { cpSync, existsSync } from 'node:fs';

const src = 'resources/android-res';
const dst = 'android/app/src/main/res';
if (!existsSync(dst)) { console.error('Folder android belum ada. Jalankan "npx cap add android" dulu.'); process.exit(1); }
cpSync(src, dst, { recursive: true, force: true });
console.log('Ikon aplikasi diterapkan.');
