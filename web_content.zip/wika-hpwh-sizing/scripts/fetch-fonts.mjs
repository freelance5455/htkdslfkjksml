// Mengunduh font Google (Space Grotesk, IBM Plex Sans, IBM Plex Mono) ke www/fonts agar aplikasi
// tampil sama persis saat offline. Aman dijalankan ulang; jika gagal, aplikasi memakai font sistem.
import { writeFile, mkdir } from 'node:fs/promises';

const CSS_URL = 'https://fonts.googleapis.com/css2?' + [
  'family=Space+Grotesk:wght@400;500;600;700',
  'family=IBM+Plex+Sans:wght@400;500;600;700',
  'family=IBM+Plex+Mono:wght@400;500;600;700',
  'display=swap',
].join('&');

try {
  const res = await fetch(CSS_URL, { headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36' } });
  if (!res.ok) throw new Error('CSS HTTP ' + res.status);
  let css = await res.text();
  await mkdir('www/fonts', { recursive: true });
  const urls = [...new Set([...css.matchAll(/url\((https:[^)]+)\)/g)].map(m => m[1]))];
  let i = 0;
  for (const u of urls) {
    const r = await fetch(u);
    if (!r.ok) throw new Error('Font HTTP ' + r.status);
    const name = 'font' + (++i) + '.woff2';
    await writeFile('www/fonts/' + name, Buffer.from(await r.arrayBuffer()));
    css = css.split(u).join(name);
  }
  await writeFile('www/fonts/fonts.css', css);
  console.log('Font tersimpan:', urls.length, 'file');
} catch (e) {
  console.warn('Font dilewati (aplikasi memakai font sistem):', e.message);
}
