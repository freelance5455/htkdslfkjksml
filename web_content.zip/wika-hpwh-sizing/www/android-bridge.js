/* Jembatan Android untuk aplikasi web WIKA HPWH Sizing.
   WebView Android tidak menjalankan unduhan <a download> dari blob:, jadi file (PDF laporan,
   proyek .json, dll.) disimpan ke cache lalu dibuka lewat dialog "Bagikan / Simpan" Android. */
(function () {
  var C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return; // hanya aktif di dalam aplikasi APK

  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onloadend = function () { resolve(String(r.result).split(',')[1] || ''); };
      r.onerror = reject;
      r.readAsDataURL(blob);
    });
  }

  async function saveAndShare(url, name) {
    var P = C.Plugins || {};
    try {
      var blob = await (await fetch(url)).blob();
      var data = await blobToBase64(blob);
      var safe = String(name || 'file').replace(/[\\/:*?"<>|]+/g, '_');
      var saved = await P.Filesystem.writeFile({ path: safe, data: data, directory: 'CACHE' });
      await P.Share.share({ title: safe, files: [saved.uri], dialogTitle: 'Simpan / bagikan ' + safe });
    } catch (e) {
      var msg = (e && e.message) || String(e);
      if (/cancel/i.test(msg)) return; // pengguna menutup dialog
      alert('Gagal menyimpan file: ' + msg);
    }
  }

  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (this.hasAttribute('download') && /^blob:/.test(this.href)) {
      saveAndShare(this.href, this.getAttribute('download'));
      return;
    }
    return origClick.apply(this, arguments);
  };
})();
