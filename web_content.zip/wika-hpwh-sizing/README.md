# WIKA HPWH Sizing — paket pembuat APK Android (Capacitor)

Paket ini membungkus aplikasi web **WIKA HPWH Pool Heating Sizing Instrument V2** (`www/index.html`)
menjadi aplikasi Android. APK dibuat otomatis oleh **GitHub Actions** (gratis), jadi Anda tidak perlu
memasang Android Studio, Java, atau Android SDK di komputer.

APK yang dihasilkan adalah **APK debug**: bisa langsung diinstal di ponsel Android untuk uji coba dan
dibagikan secara internal. Untuk rilis resmi / Google Play, lihat bagian "Rilis resmi" di bawah.

## Cara membuat APK (sekitar 10–15 menit)

1. Buat akun gratis di <https://github.com> (jika belum punya).
2. Buat repositori baru: tombol **New repository** → beri nama, mis. `wika-hpwh-sizing` →
   pilih **Private** (disarankan, karena berisi rumus perusahaan) → **Create repository**.
3. Ekstrak file ZIP ini, lalu di halaman repositori klik **uploading an existing file** dan
   seret **semua isi folder** ke sana (termasuk folder `.github`, `www`, `scripts`, `resources`).
   Pastikan folder `.github` ikut terunggah (di Windows aktifkan *Show hidden items* bila tidak terlihat).
   Klik **Commit changes**.
4. Buka tab **Actions**. Jika muncul tombol "I understand my workflows, go ahead and enable them", klik.
5. Pilih workflow **Build APK Android** → **Run workflow** → **Run workflow**.
   (Build juga jalan otomatis setiap ada perubahan file.)
6. Tunggu 5–10 menit sampai ada tanda centang hijau. Klik run tersebut, lalu di bagian
   **Artifacts** unduh **WIKA-HPWH-Sizing-APK** (berbentuk ZIP).
7. Ekstrak ZIP itu → didapat **`app-debug.apk`**.

## Memasang di ponsel

1. Kirim `app-debug.apk` ke ponsel (kabel USB, Google Drive, WhatsApp, dll.).
2. Buka file tersebut. Jika diminta, izinkan **Instal dari sumber tidak dikenal** untuk aplikasi
   yang Anda pakai membukanya (Pengaturan → Keamanan / Aplikasi).
3. Ketuk **Instal**. Jika Google Play Protect memperingatkan, pilih **Tetap instal** (ini normal untuk
   APK yang tidak berasal dari Play Store).

## Memperbarui aplikasi

Ganti isi `www/index.html` di repositori dengan versi terbaru file HTML Anda (nama tetap `index.html`).
Pastikan baris berikut tetap ada di dalam `<head>` supaya fitur simpan file bekerja di Android:

    <script src="android-bridge.js"></script>
    <link href="fonts/fonts.css" rel="stylesheet">

Lalu jalankan workflow lagi. Naikkan `version` di `package.json` bila perlu.

## Yang sudah disiapkan

- **Ikon aplikasi** tetesan air + gelombang panas (`resources/android-res`), bukan ikon bawaan Capacitor.
- **Font** (Space Grotesk, IBM Plex Sans/Mono) diunduh saat build, sehingga tampilan sama saat offline.
  Jika langkah ini gagal, aplikasi tetap jalan dengan font bawaan sistem.
- **Simpan PDF / simpan proyek**: WebView Android tidak mendukung unduhan file dari halaman web.
  `www/android-bridge.js` mengalihkannya ke dialog **Bagikan / Simpan** Android (pilih "Simpan ke
  File/Drive", WhatsApp, email, dll.).
- Aplikasi berjalan **offline** setelah terpasang.

## Rilis resmi (Google Play / tanda tangan sendiri)

APK debug ditandatangani kunci debug otomatis dan tidak cocok untuk Google Play. Untuk rilis:
buat keystore sendiri (simpan baik-baik, jangan hilang), tambahkan sebagai GitHub *Secrets*, dan ubah
langkah build menjadi `assembleRelease`/`bundleRelease` dengan penandatanganan. Anda juga perlu kebijakan
privasi (aplikasi memuat kolom nama proyek, alamat, dan klien) dan akun Google Play Developer.
Minta bantuan untuk menyiapkan ini bila diperlukan.

## Build di komputer sendiri (opsional)

Butuh Node.js 20, Java 17, dan Android SDK (atau Android Studio):

    npm install
    npm run fonts
    npx cap add android && npm run icons
    npx cap sync android
    cd android && ./gradlew assembleDebug      # hasil: android/app/build/outputs/apk/debug/app-debug.apk

## Jika build gagal

Buka run yang gagal di tab Actions, klik langkah berwarna merah, salin pesan error-nya, lalu kirim
ke Claude beserta langkah yang gagal agar bisa diperbaiki.

## Catatan

- Paket ini belum diuji sampai tahap kompilasi APK (lingkungan pembuatnya tidak punya Android SDK).
  Struktur proyek, plugin, dan skrip sudah diuji sampai pembuatan proyek Android; kompilasi dilakukan
  GitHub saat Anda menjalankan workflow. Uji hasilnya di ponsel, terutama **Simpan PDF** dan **Simpan Proyek**.
- Keterangan konstanta dan metodologi di dalam aplikasi adalah estimasi awal, bukan jaminan kinerja.
