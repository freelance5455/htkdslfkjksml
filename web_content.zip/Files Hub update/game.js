(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const selectScreen = $("selectScreen"), gameScreen = $("gameScreen");
  const canvas = $("gameCanvas"), ctx = canvas.getContext("2d");
  const WORLD = { w: 1500, h: 1050 };
  const ZOOM = 0.7;
  let currentMap = "original";
 
  const MATCH_SECONDS = 240;
  const killers = [
    {name:"Stab", size:72, key:"stab", image:"assets/characters/killer-stab.png", desc:"Um perseguidor veloz que pressiona os Survivors.", hp:160, speed:120, sprint:200, stamina:100, damage:20, cooldown:.99, range:40, hitboxSize:30, color:"#e44755", role:"VELOCISTA"},
    {name:"JJ", size:71, key:"jj", image:"assets/characters/killer-jj.png", desc:"Resistente, com bastante vida e stamina.", hp:200, speed:117, sprint:185, stamina:150, damage:25, cooldown:.99, range:40, hitboxSize:45, color:"#72dc61", role:"RESISTENTE"},
    {name:"H4ck4r", size:73, key:"hacker", image:"assets/characters/killer-hacker.png", desc:"Imprevisível: cada M1 pode causar dano diferente.", hp:175, speed:114, sprint:180, stamina:115, damages:[20,24,28,22,30], cooldown:.99, range:50, hitboxSize:32, color:"#53c8d4", role:"IMPREVISÍVEL"},
    {name:"Sixer", size:80, key:"sixer", image:"assets/characters/killer-sixer.png", desc:"O mais resistente, com uma reserva enorme de stamina.", hp:220, speed:125, sprint:178, stamina:180, damage:28, cooldown:.99, range:62, hitboxSize:58, color:"#e44755", role:"TANQUE"},
    {name:"Wesley", size:70, key:"wesley", image:"assets/characters/killer-wesley.png", desc:"Corre muito rápido, mas tem pouca stamina e vida.", hp:140, speed:110, sprint:210, stamina:85, damage:26.3, cooldown:.83, range:28, hitboxSize:40, color:"#a68aff", role:"ALTA VELOCIDADE"}
  ];
  const killerImages = killers.map(k => { const img = new Image(); img.src = k.image; return img; });
  const survivorImage = new Image();
survivorImage.src = "assets/characters/survivor-dummy.png";
  const survivorNames = ["Davi","Kauansempinto","Micaelarrogante","Gabsreidoff","Luiscamisa10","derrame"];
  let selected = 0, running = false, ended = false, lastTime = 0, elapsed = 0, timeLeft = MATCH_SECONDS;
  let killer = null, survivors = [], obstacles = [], particles = [], keys = new Set(), attackCooldown = 0, attackFlash = 0, attackDelay = 0, activeHitbox = null, camera = {x:0,y:0}, toastTimer = 0;
  const stabDash = { cooldown:0, phase:"", timer:0, traveled:0, x:1, y:0, trail:0 };
  const wesleyDash = { cooldown:0, phase:"", timer:0, traveled:0, x:1, y:0, trail:0, hitIds:new Set(), maxDistance:437, speed:680 };
  const hackerHand = {
    cooldown:0, phase:"", x:0, y:0, dirX:1, dirY:0,
    traveled:0, range:780, speed:578, returnSpeed:780, targetId:null, hit:false
  };
  const jjBlast = { cooldown:0, phase:"", timer:0, radius:155, explosionTimer:0 };
  const sixerH1 = { cooldown:0, phase:"", timer:0, traveled:0, dirX:1, dirY:0, targetId:null, hitCount:0, hitTimer:0, hitboxTimer:0, dashDistance:1000, dashSpeed:700 };
  const sixerH2 = { cooldown:0, phase:"", timer:0, dirX:1, dirY:0, traveled:0, waveX:0, waveY:0, waveRadius:34, hitIds:new Set(), jumpY:0 };
  let dpr = 1, viewW = 800, viewH = 500;
  const touch = {x:0,y:0,sprint:false,attack:false};
  let joyActive = false, joyCenter = {x:0,y:0};
  const HITBOX_TURN_DELAY = 0.12;
  const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));
  const dist = (a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
  const rand = (a,b)=>a+Math.random()*(b-a);
  
  function touchesSurvivor(s, x, y, attackRadius = 0) {
  return s.alive &&
    Math.hypot(s.x - x, s.y - y) <= s.r + attackRadius;
}

  function silhouetteSVG(index, accent) {
    const shapes = [
      '<path class="body" d="M28 40 L20 62 L25 95 L17 126 L39 126 L43 91 L48 91 L53 126 L75 126 L66 93 L72 61 L62 40 Z"/><path class="body" d="M27 17 Q45 1 63 17 L66 40 L24 40 Z"/><path class="detail" d="M28 25 L40 29 L34 34 Z M51 29 L62 25 L56 34 Z"/><path class="detail" d="M43 40 L48 40 L46 64 Z"/><path class="body" d="M22 47 L5 76 L14 82 L32 60 M65 47 L84 71 L77 79 L59 61"/>',
      '<path class="body" d="M23 39 L15 65 L23 98 L18 126 L42 126 L46 93 L51 93 L58 126 L81 126 L68 92 L74 64 L65 39 Z"/><path class="body" d="M25 18 Q44 4 65 18 L67 41 L23 41 Z"/><path class="detail" d="M29 28 L39 29 L34 34 Z M51 29 L61 28 L56 34 Z"/><path class="body" d="M23 45 L2 70 L11 80 L34 59 M66 45 L86 72 L77 81 L58 60"/><path class="detail" d="M42 45 L49 45 L47 70 Z"/>',
      '<path class="body" d="M31 39 L24 63 L29 96 L24 125 L42 125 L46 91 L51 91 L57 125 L75 125 L65 94 L69 63 L62 39 Z"/><path class="body" d="M28 17 L64 17 L67 41 L24 41 Z"/><path class="detail" d="M29 25 L61 25 L61 30 L29 30 Z M34 34 L56 34 L56 37 L34 37 Z"/><path class="body" d="M25 46 L7 71 L13 77 L34 59 M64 46 L83 70 L77 77 L57 59"/>',
      '<path class="body" d="M27 41 L19 66 L25 96 L19 125 L40 125 L45 92 L50 92 L55 125 L76 125 L67 94 L72 64 L63 41 Z"/><path class="body" d="M29 15 Q45 7 62 15 L67 41 L24 41 Z"/><path class="detail" d="M29 24 L42 30 L33 34 Z M61 24 L48 30 L57 34 Z"/><path class="detail" d="M40 40 L52 40 L46 57 Z"/><path class="body" d="M24 46 L7 75 L15 81 L35 59 M65 46 L83 72 L75 80 L58 59"/>',
      '<path class="body" d="M27 40 L18 64 L26 98 L21 125 L43 125 L46 91 L51 91 L58 125 L78 125 L67 94 L73 63 L63 40 Z"/><path class="body" d="M26 17 Q45 2 64 17 L67 41 L23 41 Z"/><path class="detail" d="M29 26 L41 29 L34 35 Z M51 29 L62 26 L56 35 Z"/><path class="detail" d="M39 39 L52 39 L46 58 Z"/><path class="body" d="M23 46 L5 70 L14 81 L34 60 M66 46 L84 72 L76 81 L58 60"/>'
    ];
    return `<svg class="silhouette" viewBox="0 0 90 135" aria-hidden="true"><style>.body{fill:#0b0d12;stroke:${accent};stroke-width:2.4;stroke-linejoin:round}.detail{fill:${accent}}</style>${shapes[index]}</svg>`;
  }

  function buildSelection() {
    const grid = $("killerGrid"); grid.innerHTML = "";
    killers.forEach((k,i)=>{
      const card = document.createElement("button");
      card.className = "killer-card" + (i===selected?" selected":"");
      card.innerHTML = `<div class="killer-art ${k.key}-art"><span class="initial">0${i+1}</span><img class="killer-card-image" src="${k.image}" alt="Visual de ${k.name}"><span class="card-check">✓</span></div><div class="card-copy"><h3>${k.name}</h3><p>${k.desc}</p><div class="card-stat"><span>${k.role}</span><span class="stat-dots">●●●●</span></div></div>`;
      card.addEventListener("click",()=>{selected=i;buildSelection();updateSelectedInfo();});
      grid.appendChild(card);
    });
    updateSelectedInfo();
  }
  function updateSelectedInfo(){
    const k=killers[selected];
    $("selectedName").textContent=k.name;
    $("selectedDescription").textContent=`${k.desc} HP ${k.hp} • Speed ${k.speed} • Sprint ${k.sprint} • Stamina ${k.stamina}`;
    $("selectedInitial").textContent="";
    $("selectedPortrait").className=`selected-portrait ${k.key}-art`;
    $("selectedPortrait").style.backgroundImage=`url("${k.image}")`;
  }
  function resizeCanvas(){
    const rect=canvas.getBoundingClientRect();
    dpr=Math.min(window.devicePixelRatio||1,2);
    viewW=Math.max(320,rect.width); viewH=Math.max(280,rect.height);
    canvas.width=Math.floor(viewW*dpr);canvas.height=Math.floor(viewH*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  
  function chooseMap(){
  currentMap = Math.random() < 0.5 ? "original" : "estacao";
}
  
  
function makeObstacles(){
  obstacles=[];

  // Bordas do mapa
  obstacles.push(
    {x:0,y:0,w:WORLD.w,h:35},
    {x:0,y:WORLD.h-35,w:WORLD.w,h:35},
    {x:0,y:0,w:35,h:WORLD.h},
    {x:WORLD.w-35,y:0,w:35,h:WORLD.h}
  );

  let blocks;

  if(currentMap === "estacao"){
    // A Estação do Fim: laboratórios e salas de pesquisa
    blocks=[
      [160,130,220,65],
      [460,100,75,200],
      [610,145,240,60],
      [950,105,75,210],
      [1120,160,220,65],

      // Corredores e salas centrais
      [140,370,80,190],
      [300,380,200,65],
      [590,350,80,200],
      [720,410,220,60],
      [1080,370,200,70],

      // Gerador e estufa
      [180,680,230,70],
      [500,640,80,190],
      [680,700,220,65],
      [1010,650,80,180],
      [1150,740,180,65],

      // Área externa e heliponto
      [400,890,190,55],
      [780,880,220,55]
    ];
  }else{
    // Mapa original
    blocks=[
      [220,170,170,65],[510,105,70,175],
      [770,170,210,58],[1110,125,150,75],
      [120,400,85,180],[330,365,220,60],
      [670,360,95,180],[910,390,185,65],
      [1160,420,160,155],[250,690,180,70],
      [520,650,75,175],[800,690,210,65],
      [1110,760,190,65],[410,885,170,55],
      [920,900,90,80]
    ];
  }

  blocks.forEach(([x,y,w,h])=>{
    obstacles.push({x,y,w,h});
  });
}

  function collides(x,y,r){
    return obstacles.some(o=>x+r>o.x&&x-r<o.x+o.w&&y+r>o.y&&y-r<o.y+o.h);
  }
  
  
function survivorCollides(x, y, r = 16) {
  // Hitbox física independente do tamanho visual do Survivor.
  return collides(x, y, Math.min(r, 12));
}

  
  
function moveEntity(e, dx, dy, r) {
    const isSurvivor = survivors.includes(e);
    // Não altere e.r/e.size: eles controlam o desenho. Só a colisão usa hitboxR.
    const hitbox = isSurvivor ? (e.hitboxR || 12) : r;

    if (!collides(e.x + dx, e.y, hitbox)) e.x += dx;
    if (!collides(e.x, e.y + dy, hitbox)) e.y += dy;

    e.x = clamp(e.x, hitbox, WORLD.w - hitbox);
    e.y = clamp(e.y, hitbox, WORLD.h - hitbox);
}

  
  
function resolveKillerSurvivorCollision() {
  if (!killer) return;

  for (const s of survivors) {
    if (!s.alive) continue;

    const dx = s.x - killer.x;
    const dy = s.y - killer.y;
    const distance = Math.hypot(dx, dy);
    const minDistance = killer.r + s.r;

    if (distance < minDistance) {
      const angle = distance > 0
        ? Math.atan2(dy, dx)
        : Math.random() * Math.PI * 2;

      const overlap = minDistance - distance;
      const pushX = Math.cos(angle) * overlap;
      const pushY = Math.sin(angle) * overlap;

      const newSX = s.x + pushX;
      const newSY = s.y + pushY;

      if (!collides(newSX, s.y, s.r)) s.x = newSX;
      if (!collides(s.x, newSY, s.r)) s.y = newSY;
    }
  }
}

  
  // Se uma habilidade ou uma posição inválida deixar alguém dentro de um bloco,
  // procura uma posição livre próxima e desloca o personagem para fora.
  function pushOutOfWall(e,r){
    if(!e||!Number.isFinite(e.x)||!Number.isFinite(e.y)||!collides(e.x,e.y,r))return false;
    const startX=e.x,startY=e.y;
    const maxDistance=325,step=5;
    for(let distance=step;distance<=maxDistance;distance+=step){
      for(let i=0;i<32;i++){
        const angle=(Math.PI*2*i)/32;
        const x=clamp(startX+Math.cos(angle)*distance,r,WORLD.w-r);
        const y=clamp(startY+Math.sin(angle)*distance,r,WORLD.h-r);
        if(!collides(x,y,r)){
          e.x=x;e.y=y;
          return true;
        }
      }
    }
    // Plano de segurança: procura uma posição livre em uma grade pelo mapa.
    let nearest=null,nearestDistance=Infinity;
    for(let y=r+35;y<WORLD.h-r-35;y+=20){
      for(let x=r+35;x<WORLD.w-r-35;x+=20){
        const d=Math.hypot(x-startX,y-startY);
        if(d<nearestDistance&&!collides(x,y,r)){nearest={x,y};nearestDistance=d;}
      }
    }
    if(nearest){e.x=nearest.x;e.y=nearest.y;return true;}
    return false;
  }
  function recoverEntitiesFromWalls(){
    if(killer)pushOutOfWall(killer,killer.r);
    for(const s of survivors){if(s.alive)pushOutOfWall(s,s.hitboxR||12);}
  }
  // A* em uma grade invisível: os Survivors planejam um caminho pelos corredores
  // e consideram a hitbox deles, não apenas o centro do personagem.
  const PATH_CELL=35;
  function findSurvivorPath(s, goalX, goalY){
    const cols=Math.ceil(WORLD.w/PATH_CELL), rows=Math.ceil(WORLD.h/PATH_CELL);
    const toCell=(x,y)=>({x:clamp(Math.floor(x/PATH_CELL),0,cols-1),y:clamp(Math.floor(y/PATH_CELL),0,rows-1)});
    const start=toCell(s.x,s.y), goal=toCell(goalX,goalY);
    const key=(x,y)=>y*cols+x;
    const blocked=new Uint8Array(cols*rows);
    for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){
      const cx=x*PATH_CELL+PATH_CELL/2, cy=y*PATH_CELL+PATH_CELL/2;
      if(collides(cx,cy,(s.hitboxR||12)+5))blocked[key(x,y)]=1;
    }
    blocked[key(start.x,start.y)]=0;
    // Se o ponto-alvo caiu dentro de um obstáculo, procura a célula livre mais próxima.
    if(blocked[key(goal.x,goal.y)]){
      let best=null,bd=Infinity;
      for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)if(!blocked[key(x,y)]){
        const dd=(x-goal.x)**2+(y-goal.y)**2;if(dd<bd){bd=dd;best={x,y};}
      }
      if(best){goal.x=best.x;goal.y=best.y;}
    }
    const startK=key(start.x,start.y),goalK=key(goal.x,goal.y);
    const open=[{x:start.x,y:start.y,g:0,f:Math.abs(goal.x-start.x)+Math.abs(goal.y-start.y)}];
    const came=new Int32Array(cols*rows);came.fill(-1);
    const costs=new Float32Array(cols*rows);costs.fill(Infinity);costs[startK]=0;
    const closed=new Uint8Array(cols*rows);
    const dirs=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
    let found=false, iterations=0;
    while(open.length&&iterations++<cols*rows*3){
      let bi=0;for(let i=1;i<open.length;i++)if(open[i].f<open[bi].f)bi=i;
      const cur=open.splice(bi,1)[0], ck=key(cur.x,cur.y);
      if(closed[ck])continue;closed[ck]=1;
      if(ck===goalK){found=true;break;}
      for(const [dx,dy] of dirs){
        const nx=cur.x+dx,ny=cur.y+dy;if(nx<0||ny<0||nx>=cols||ny>=rows)continue;
        const nk=key(nx,ny);if(blocked[nk]||closed[nk])continue;
        // Impede cortar diagonalmente pela quina de dois obstáculos.
        if(dx&&dy&&(blocked[key(cur.x+dx,cur.y)]||blocked[key(cur.x,cur.y+dy)]))continue;
        const ng=costs[ck]+(dx&&dy?1.414:1);
        if(ng<costs[nk]){costs[nk]=ng;came[nk]=ck;const h=Math.hypot(goal.x-nx,goal.y-ny);open.push({x:nx,y:ny,g:ng,f:ng+h});}
      }
    }
    if(!found)return [];
    const path=[];let at=goalK;
    while(at!==startK&&at>=0){path.push({x:(at%cols)*PATH_CELL+PATH_CELL/2,y:Math.floor(at/cols)*PATH_CELL+PATH_CELL/2});at=came[at];}
    path.reverse();return path;
  }
  function setSurvivorGoal(s,x,y){
    s.goalX=clamp(x,105,WORLD.w-105);s.goalY=clamp(y,105,WORLD.h-105);
    s.goalX=clamp(x,180,WORLD.w-180);s.goalY=clamp(y,180,WORLD.h-180);
    s.path=findSurvivorPath(s,s.goalX,s.goalY);s.pathIndex=0;s.pathTimer=.55;
  }
  function spawnSurvivor(i){
    let x,y,tries=0;
    do{x=rand(100,WORLD.w-100);y=rand(100,WORLD.h-100);tries++}while((collides(x,y,12)||(killer&&Math.hypot(x-killer.x,y-killer.y)<300))&&tries<100);
    const survivorSpeed=rand(145,165);
    return {
  id: i,
  name: survivorNames[i],
  x,
  y,
  size: 60,
  get r() { return this.size / 2; },hp:100,maxHp:100,speed:survivorSpeed,baseSpeed:survivorSpeed,speedBoost:0,dodgeTimer:0,alive:true,angle:0,think:rand(.1,.8),wander:rand(0,Math.PI*2),hurt:0,panic:0,stuck:0,lastX:x,lastY:y,goalX:x,goalY:y,path:[],pathIndex:0,pathTimer:0};
  }
  function survivorTakesDamage(s,amount){s.hp-=amount;s.speedBoost=1;s.panic=2.5;}
  function startGame(){
    const k=killers[selected];
    $("skillTouch").classList.toggle("hidden",selected!==0&&selected!==1&&selected!==2&&selected!==3&&selected!==4);
    $("skillTouch").innerHTML=selected===1?"H1<br>BLAST":selected===2?"H1<br>BRAÇO":selected===3?"H1<br>INVESTIDA":selected===4?"H1<br>INVESTIDA":"H1<br>SHADOW";
    $("skill2Touch").classList.toggle("hidden",selected!==3);
    stabDash.cooldown=0;stabDash.phase="";stabDash.timer=0;stabDash.traveled=0;stabDash.trail=0;
    Object.assign(wesleyDash,{cooldown:0,phase:"",timer:0,traveled:0,x:Math.cos(killer?.angle||0),y:Math.sin(killer?.angle||0),trail:0,hitIds:new Set()});
    hackerHand.cooldown=0;hackerHand.phase="";hackerHand.traveled=0;hackerHand.targetId=null;hackerHand.hit=false;
    jjBlast.cooldown=0;jjBlast.phase="";jjBlast.timer=0;jjBlast.explosionTimer=0;
    Object.assign(sixerH1,{cooldown:0,phase:"",timer:0,traveled:0,targetId:null,hitCount:0,hitTimer:0,hitboxTimer:0});
    Object.assign(sixerH2,{cooldown:0,phase:"",timer:0,traveled:0,waveX:0,waveY:0,hitIds:new Set(),jumpY:0});
    killer={x:WORLD.w/2,y:WORLD.h/2,r:17,size:k.size,hp:k.hp,maxHp:k.hp,speed:k.speed,sprintSpeed:k.sprint,angle:-Math.PI/2,facingX:0,facingY:-1,facing:0,stamina:k.stamina,maxStamina:k.stamina,staminaExhausted:false,attackRange:k.range,damage:k.damage};
    survivors=[];for(let i=0;i<survivorNames.length;i++)survivors.push(spawnSurvivor(i));
    particles=[];elapsed=0;timeLeft=MATCH_SECONDS;attackCooldown=0;attackFlash=0;attackDelay=0;activeHitbox=null;touch.sprint=false;$("sprintTouch").classList.remove("active");$("sprintTouch").setAttribute("aria-pressed","false");running=true;ended=false;lastTime=performance.now();
    chooseMap();
    makeObstacles();
    // Ensure spawn after obstacles are created.
    killer.x=WORLD.w/2;killer.y=WORLD.h/2;
    if(collides(killer.x,killer.y,killer.r)){killer.x=100;killer.y=100;}
    survivors.forEach((s,i)=>{if(collides(s.x,s.y,s.r)){s.x=100+i*35;s.y=100;}});
    $("hudKillerName").textContent=k.name;$("hudInitial").textContent="";$("hudPortrait").className=`hud-portrait ${k.key}-art`;$("hudPortrait").style.backgroundImage=`url("${k.image}")`;
    $("killerHealthBar").style.width="100%";$("killerHealthText").textContent=`${killer.hp} / ${killer.maxHp}`;
    $("timer").textContent="04:00";$("objectiveText").textContent="Elimine todos os Survivors";
    $("endOverlay").classList.add("hidden");$("toast").classList.add("hidden");
    selectScreen.classList.add("hidden");gameScreen.classList.remove("hidden");
    resizeCanvas();updateSurvivorHud();showToast(`${k.name}: caçada iniciada!`);requestAnimationFrame(loop);
  }
  function updateSurvivorHud(){
    const alive=survivors.filter(s=>s.alive).length;
    $("survivorCount").textContent=alive;
    $("survivorPips").innerHTML=survivors.map(s=>`<span class="survivor-pip ${s.alive?"":"dead"}"></span>`).join("");
  }
  function showToast(message){const t=$("toast");t.textContent=message;t.classList.remove("hidden");toastTimer=1.8;}
  function doAttack(){
    if(!running||ended||attackCooldown>0)return;
    const k=killers[selected];
    attackCooldown=k.cooldown;attackDelay=.15;attackFlash=0;
    activeHitbox={x:0,y:0,angle:killer.angle,targetAngle:killer.angle,size:k.hitboxSize,range:k.range,damage:k.damages? k.damages[Math.floor(Math.random()*k.damages.length)] : k.damage,hitIds:new Set(),visible:0};
    showToast(`${k.name}: ataque!`);
  }
  function burst(x,y,color,n){for(let i=0;i<n;i++){const a=rand(0,Math.PI*2),v=rand(35,160);particles.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,life:rand(.2,.65),max:.65,color,size:rand(2,5)});}}
  function activateStabDash(){
    if(!running||ended||selected!==0||stabDash.cooldown>0||stabDash.phase)return;
    // A preparação dura 1 segundo e permite ajustar a direção antes do dash.
    const angle=killer.angle||0;
    stabDash.x=Math.cos(angle);stabDash.y=Math.sin(angle);
    stabDash.phase="prepare";stabDash.timer=1;stabDash.traveled=0;stabDash.trail=0;
    stabDash.cooldown=17;
    showToast("STAB: Shadow Dash carregando...");
  }
  function activateWesleyDash(){
    if(!running||ended||selected!==4||wesleyDash.cooldown>0||wesleyDash.phase)return;
    const angle=killer.angle||0;
    wesleyDash.x=Math.cos(angle);wesleyDash.y=Math.sin(angle);
    wesleyDash.phase="prepare";wesleyDash.timer=.45;wesleyDash.traveled=0;wesleyDash.trail=0;wesleyDash.hitIds=new Set();
    wesleyDash.cooldown=15;
    showToast("Wesley: Investida Brutal carregando!");
  }
  
function activateHackerHand(){
  if(!running || ended || selected !== 2) return;

  // Se o braço estiver puxando um Survivor, solta imediatamente.
  // Isso funciona mesmo durante o cooldown.
  if(hackerHand.phase === "pulling" && hackerHand.targetId !== null){
    const target = survivors.find(
      s => s.id === hackerHand.targetId && s.alive
    );

    hackerHand.phase = "returning";
    hackerHand.targetId = null;

    if(target){
      showToast(`${target.name} foi solto pelo H4ck4r!`);
    }else{
      showToast("H4ck4r: braço retornando!");
    }

    return;
  }

  // Se não estiver puxando ninguém, respeita o cooldown normal.
  if(hackerHand.cooldown > 0 || hackerHand.phase) return;

  const angle = killer.angle || 0;
  hackerHand.dirX = Math.cos(angle);
  hackerHand.dirY = Math.sin(angle);
  hackerHand.x = killer.x;
  hackerHand.y = killer.y;
  hackerHand.traveled = 0;
  hackerHand.targetId = null;
  hackerHand.hit = false;
  hackerHand.phase = "outbound";
  hackerHand.cooldown = 13;

  burst(killer.x, killer.y, "#53c8d4", 8);
  showToast("H4ck4r: Braço Robótico lançado!");
}

  function activateJJBlast(){
    if(!running||ended||selected!==1||jjBlast.cooldown>0||jjBlast.phase)return;
    jjBlast.phase="charge";jjBlast.timer=2;jjBlast.explosionTimer=0;jjBlast.cooldown=14;
    burst(killer.x,killer.y,"#ff2020",10);
    showToast("JJ: sobrecarga iniciada!");
  }
  function updateJJBlast(dt){
    jjBlast.cooldown=Math.max(0,jjBlast.cooldown-dt);
    if(jjBlast.explosionTimer>0)jjBlast.explosionTimer=Math.max(0,jjBlast.explosionTimer-dt);
    if(selected!==1||jjBlast.phase!=="charge")return;
    jjBlast.timer-=dt;
    if(jjBlast.timer>0)return;
    jjBlast.phase="";jjBlast.explosionTimer=.35;
    burst(killer.x,killer.y,"#ff2020",45);
    for(const s of survivors){
      if(!s.alive)continue;
      const dx=s.x-killer.x,dy=s.y-killer.y,distance=Math.hypot(dx,dy);
      // A explosão ignora paredes e outros obstáculos.
      if(distance<=jjBlast.radius+s.r){
        survivorTakesDamage(s,37);s.hurt=.5;
        const length=distance||1,pushDistance=95;
        const tx=s.x+dx/length*pushDistance,ty=s.y+dy/length*pushDistance;
        if(!collides(tx,s.y,s.r))s.x=tx;
        if(!collides(s.x,ty,s.r))s.y=ty;
        burst(s.x,s.y,"#ff3030",12);showToast(`${s.name}: -37 HP (Sobrecarga do JJ)`);
        if(s.hp<=0){s.hp=0;s.alive=false;burst(s.x,s.y,"#e44755",18);showToast(`${s.name} foi eliminado!`);}
      }
    }
    updateSurvivorHud();
  }

  function updateHackerHand(dt){
    hackerHand.cooldown=Math.max(0,hackerHand.cooldown-dt);
    if(selected!==2||!hackerHand.phase)return;
    const step=(hackerHand.phase==="returning"?hackerHand.returnSpeed:hackerHand.speed)*dt;
    if(hackerHand.phase==="outbound"){
      const travel=Math.min(step,hackerHand.range-hackerHand.traveled);
      const steps=Math.max(1,Math.ceil(travel/5));
      for(let i=0;i<steps;i++){
        const sx=hackerHand.dirX*travel/steps,sy=hackerHand.dirY*travel/steps;
        const nx=hackerHand.x+sx,ny=hackerHand.y+sy;
        // O braço robótico atravessa paredes e obstáculos durante o percurso.
        hackerHand.x=nx;hackerHand.y=ny;hackerHand.traveled+=Math.hypot(sx,sy);
        // Ao tocar a borda interna da arena, o braço começa a voltar automaticamente.
        if(hackerHand.x<=35||hackerHand.x>=WORLD.w-35||hackerHand.y<=35||hackerHand.y>=WORLD.h-35){
          hackerHand.phase="returning";hackerHand.targetId=null;break;
        }
        const target=survivors.find(s=>s.alive&&Math.hypot(s.x-hackerHand.x,s.y-hackerHand.y)<=s.r+13);
        if(target){
          target.hp-=15;target.hurt=.5;target.panic=2.5;
          burst(target.x,target.y,"#53c8d4",14);
          showToast(`${target.name}: -15 HP (Braço Robótico)`);
          if(target.hp<=0){target.hp=0;target.alive=false;burst(target.x,target.y,"#e44755",18);showToast(`${target.name} foi eliminado!`);updateSurvivorHud();hackerHand.phase="returning";break;}
          hackerHand.targetId=target.id;hackerHand.phase="pulling";break;
        }
        if(hackerHand.traveled>=hackerHand.range){hackerHand.phase="returning";break;}
      }
    }else if(hackerHand.phase==="pulling"){
      const target=survivors.find(s=>s.id===hackerHand.targetId&&s.alive);
      if(!target){hackerHand.phase="returning";hackerHand.targetId=null;return;}
      const dx=killer.x-target.x,dy=killer.y-target.y,distance=Math.hypot(dx,dy);
      const pull=Math.min(step,Math.max(0,distance-killer.r-target.r-3));
      if(distance<=killer.r+target.r+4){
        hackerHand.phase="returning";hackerHand.targetId=null;
      }else{
        // O survivor fica preso à mão durante o puxão, sem poder se mover por conta própria.
        target.x+=dx/(distance||1)*pull;target.y+=dy/(distance||1)*pull;
        hackerHand.x=target.x;hackerHand.y=target.y;
        if(pull<=0.01){hackerHand.phase="returning";hackerHand.targetId=null;}
      }
    }else if(hackerHand.phase==="returning"){
      const dx=killer.x-hackerHand.x,dy=killer.y-hackerHand.y,distance=Math.hypot(dx,dy);
      if(distance<=step+ killer.r){
        hackerHand.x=killer.x;hackerHand.y=killer.y;hackerHand.phase="";hackerHand.targetId=null;
        burst(killer.x,killer.y,"#53c8d4",7);showToast("H4ck4r: braço recolhido.");
      }else{
        hackerHand.x+=dx/(distance||1)*step;hackerHand.y+=dy/(distance||1)*step;
      }
    }
  }

  function updateStabDash(dt){
    if(selected!==0)return;
    stabDash.cooldown=Math.max(0,stabDash.cooldown-dt);
    if(!stabDash.phase)return;
    stabDash.trail=Math.max(0,stabDash.trail-dt);
    if(stabDash.phase==="prepare"){
      // Durante o segundo de preparação, a mira acompanha o controle direcional.
      let ax=(keys.has("a")||keys.has("arrowleft")?-1:0)+(keys.has("d")||keys.has("arrowright")?1:0)+touch.x;
      let ay=(keys.has("w")||keys.has("arrowup")?-1:0)+(keys.has("s")||keys.has("arrowdown")?1:0)+touch.y;
      if(Math.hypot(ax,ay)>.15){const a=Math.atan2(ay,ax);stabDash.x=Math.cos(a);stabDash.y=Math.sin(a);killer.angle=a;}
      stabDash.timer-=dt;
      if(stabDash.timer<=0){stabDash.phase="dash";stabDash.timer=1.0;burst(killer.x,killer.y,"#ff9d32",10);}
      return;
    }
    if(stabDash.phase!=="dash")return;
    const step=Math.min(500*dt,400-stabDash.traveled);
    const steps=Math.max(1,Math.ceil(step/4));
    for(let i=0;i<steps;i++){
      const sx=stabDash.x*step/steps,sy=stabDash.y*step/steps;
      const nx=killer.x+sx,ny=killer.y+sy;
      if(collides(nx,ny,killer.r)){
        stabDash.phase="";stabDash.timer=0;burst(killer.x,killer.y,"#ff9d32",7);break;
      }
      killer.x=clamp(nx,killer.r,WORLD.w-killer.r);killer.y=clamp(ny,killer.r,WORLD.h-killer.r);
      stabDash.traveled+=Math.hypot(sx,sy);stabDash.trail=.12;
      // A hitbox acompanha a ponta do Stab durante toda a investida.
      const hitboxX=killer.x+stabDash.x*(killer.r+13);
      const hitboxY=killer.y+stabDash.y*(killer.r+13);
      for(const s of survivors){
        if(!s.alive)continue;
        if(touchesSurvivor(s, hitboxX, hitboxY, 9)){
          survivorTakesDamage(s,34);s.hurt=.35;
          // Empurrão leve na direção da investida, sem atravessar paredes.
          const push=18,px=s.x+stabDash.x*push,py=s.y+stabDash.y*push;
          if(!collides(px,s.y,s.r))s.x=px;
          if(!collides(s.x,py,s.r))s.y=py;
          burst(s.x,s.y,"#ff9d32",14);showToast(`${s.name}: -34 HP (Shadow Dash)`);
          if(s.hp<=0){s.alive=false;burst(s.x,s.y,"#e44755",18);showToast(`${s.name} foi eliminado!`);}
          updateSurvivorHud();stabDash.phase="";stabDash.timer=0;break;
        }
      }
      if(!stabDash.phase)break;
      if(stabDash.traveled>=400){stabDash.phase="";stabDash.timer=0;break;}
    }
    stabDash.timer-=dt;
    if(stabDash.timer<=0){stabDash.phase="";stabDash.timer=0;}
  }

  function updateWesleyDash(dt){
    if(selected!==4)return;
    wesleyDash.cooldown=Math.max(0,wesleyDash.cooldown-dt);
    if(!wesleyDash.phase)return;
    wesleyDash.trail=Math.max(0,wesleyDash.trail-dt);
    if(wesleyDash.phase==="prepare"){
      // During the short wind-up the player may adjust the aim.
      const ax=(keys.has("a")||keys.has("arrowleft")?-1:0)+(keys.has("d")||keys.has("arrowright")?1:0)+touch.x;
      const ay=(keys.has("w")||keys.has("arrowup")?-1:0)+(keys.has("s")||keys.has("arrowdown")?1:0)+touch.y;
      if(Math.hypot(ax,ay)>.15){const a=Math.atan2(ay,ax);wesleyDash.x=Math.cos(a);wesleyDash.y=Math.sin(a);killer.angle=a;}
      wesleyDash.timer-=dt;
      if(wesleyDash.timer<=0){wesleyDash.phase="dash";wesleyDash.timer=.5;burst(killer.x,killer.y,"#a68aff",10);}
      return;
    }
    if(wesleyDash.phase!=="dash")return;
    // Almost-perfect steering while dashing: direction follows input smoothly.
    let ax=(keys.has("a")||keys.has("arrowleft")?-1:0)+(keys.has("d")||keys.has("arrowright")?1:0)+touch.x;
    let ay=(keys.has("w")||keys.has("arrowup")?-1:0)+(keys.has("s")||keys.has("arrowdown")?1:0)+touch.y;
    if(Math.hypot(ax,ay)>.15){const mag=Math.hypot(ax,ay);ax/=mag;ay/=mag;const tx=ax,ty=ay;wesleyDash.x=wesleyDash.x*.05+tx*.95;wesleyDash.y=wesleyDash.y*.05+ty*.95;const m=Math.hypot(wesleyDash.x,wesleyDash.y)||1;wesleyDash.x/=m;wesleyDash.y/=m;}
    killer.angle=Math.atan2(wesleyDash.y,wesleyDash.x);
    const step=Math.min(wesleyDash.speed*dt,wesleyDash.maxDistance-wesleyDash.traveled);
    const steps=Math.max(1,Math.ceil(step/4));
    for(let i=0;i<steps;i++){
      const sx=wesleyDash.x*step/steps,sy=wesleyDash.y*step/steps,nx=killer.x+sx,ny=killer.y+sy;
      if(collides(nx,ny,killer.r)){wesleyDash.phase="";wesleyDash.timer=0;burst(killer.x,killer.y,"#a68aff",8);break;}
      killer.x=clamp(nx,killer.r,WORLD.w-killer.r);killer.y=clamp(ny,killer.r,WORLD.h-killer.r);
      wesleyDash.traveled+=Math.hypot(sx,sy);wesleyDash.trail=.1;
      // Visible hitbox is the outlined capsule/rectangle just ahead of Wesley.
      const hx=killer.x+wesleyDash.x*(killer.r+18),hy=killer.y+wesleyDash.y*(killer.r+18);
      for(const target of survivors){if(!target.alive||wesleyDash.hitIds.has(target.id))continue;
        if(touchesSurvivor(target, hx, hy, 12)){
          wesleyDash.hitIds.add(target.id);target.hp-=30;target.hurt=.35;target.panic=2;
          const push=100,px=target.x+wesleyDash.x*push,py=target.y+wesleyDash.y*push;
          if(!collides(px,target.y,target.r))target.x=px;
          if(!collides(target.x,py,target.r))target.y=py;
          burst(target.x,target.y,"#a68aff",15);showToast(`${target.name}: -30 HP (Investida Brutal)`);
          if(target.hp<=0){target.alive=false;burst(target.x,target.y,"#a68aff",18);showToast(`${target.name} foi eliminado!`);}
          updateSurvivorHud();wesleyDash.phase="";wesleyDash.timer=0;break;
        }
      }
      if(!wesleyDash.phase)break;
      if(wesleyDash.traveled>=wesleyDash.maxDistance){wesleyDash.phase="";wesleyDash.timer=0;break;}
    }
    wesleyDash.timer-=dt;if(wesleyDash.timer<=0){wesleyDash.phase="";wesleyDash.timer=0;}
  }

  function activateSixerH1(){
    if(!running||ended||selected!==3||sixerH1.cooldown>0||sixerH1.phase)return;
    const angle=killer.angle||0;
    sixerH1.dirX=Math.cos(angle);sixerH1.dirY=Math.sin(angle);
    sixerH1.phase="prepare";sixerH1.timer=1;sixerH1.traveled=0;sixerH1.targetId=null;sixerH1.hitCount=0;sixerH1.hitTimer=0;sixerH1.hitboxTimer=0;sixerH1.cooldown=18;
    burst(killer.x,killer.y,"#ff263f",10);showToast("Sixer: Investida Multigolpe carregando!");
  }
  function activateSixerH2(){
    if(!running||ended||selected!==3||sixerH2.cooldown>0||sixerH2.phase)return;
    const angle=killer.angle||0;
    sixerH2.dirX=Math.cos(angle);sixerH2.dirY=Math.sin(angle);
    sixerH2.phase="jump";sixerH2.timer=.45;sixerH2.traveled=0;sixerH2.waveX=killer.x;sixerH2.waveY=killer.y;sixerH2.hitIds=new Set();sixerH2.jumpY=0;sixerH2.cooldown=15;
    burst(killer.x,killer.y,"#ff6633",8);showToast("Sixer: salto de impacto!");
  }
  function updateSixerH1(dt){
    sixerH1.cooldown=Math.max(0,sixerH1.cooldown-dt);
    if(selected!==3||!sixerH1.phase)return;
    if(sixerH1.phase==="prepare"){
      // Durante o segundo de mira, o Sixer pode virar sem sair do lugar.
      // A linha vermelha usa esta direção, então acompanha cada mudança de direção.
      let aimX=0,aimY=0;
      if(keys.has("w")||keys.has("arrowup"))aimY--;
      if(keys.has("s")||keys.has("arrowdown"))aimY++;
      if(keys.has("a")||keys.has("arrowleft"))aimX--;
      if(keys.has("d")||keys.has("arrowright"))aimX++;
      aimX+=touch.x;aimY+=touch.y;
      const aimMag=Math.hypot(aimX,aimY);
      if(aimMag>.1){
        aimX/=aimMag;aimY/=aimMag;
        sixerH1.dirX=aimX;sixerH1.dirY=aimY;
        killer.angle=Math.atan2(aimY,aimX);killer.facingX=aimX;killer.facingY=aimY;
      }
      sixerH1.timer-=dt;
      if(sixerH1.timer<=0){sixerH1.phase="dash";sixerH1.timer=1000/sixerH1.dashSpeed;burst(killer.x,killer.y,"#ff263f",12);}
      return;
    }
    if(sixerH1.phase==="dash"){
      // Pequeno controle direcional durante o dash, sem permitir curvas bruscas.
      let ix=0,iy=0;
      if(keys.has("w")||keys.has("arrowup"))iy--;
      if(keys.has("s")||keys.has("arrowdown"))iy++;
      if(keys.has("a")||keys.has("arrowleft"))ix--;
      if(keys.has("d")||keys.has("arrowright"))ix++;
      ix+=touch.x;iy+=touch.y;
      const im=Math.hypot(ix,iy);
      if(im>.1){ix/=im;iy/=im;const steer=.16;let nx=sixerH1.dirX+ix*steer*dt*3,ny=sixerH1.dirY+iy*steer*dt*3,nm=Math.hypot(nx,ny)||1;sixerH1.dirX=nx/nm;sixerH1.dirY=ny/nm;}
      const step=Math.min(sixerH1.dashSpeed*dt,sixerH1.dashDistance-sixerH1.traveled);
      const sx=sixerH1.dirX*step,sy=sixerH1.dirY*step;
      // Durante a investida ignoramos collides()/moveEntity(): paredes e blocos
      // do cenário não interrompem nem desviam o dash. Só os limites externos do mapa valem.
      killer.x=clamp(killer.x+sx,35+killer.r,WORLD.w-35-killer.r);
      killer.y=clamp(killer.y+sy,35+killer.r,WORLD.h-35-killer.r);
      sixerH1.traveled+=step;sixerH1.hitboxTimer=.08;
      for(const target of survivors){
        if(!target.alive)continue;
        if(touchesSurvivor(target, killer.x, killer.y, killer.r + 17)){
          sixerH1.phase="combo";sixerH1.targetId=target.id;sixerH1.hitCount=0;sixerH1.hitTimer=.05;
          showToast(`${target.name}: preso na Investida Multigolpe!`);break;
        }
      }
      if(sixerH1.phase==="dash"&&sixerH1.traveled>=sixerH1.dashDistance){sixerH1.phase="";burst(killer.x,killer.y,"#ff263f",12);}
      return;
    }
    if(sixerH1.phase==="combo"){
      const target=survivors.find(s=>s.id===sixerH1.targetId&&s.alive);
      if(!target){sixerH1.phase="";return;}
      sixerH1.hitTimer-=dt;
      if(sixerH1.hitTimer<=0){
        sixerH1.hitCount++;sixerH1.hitboxTimer=.20;target.hp-=10;target.hurt=.25;target.panic=1.5;
        burst(target.x,target.y,"#ff263f",8);showToast(`${target.name}: -10 HP (${sixerH1.hitCount}/4)`);
        if(target.hp<=0){target.hp=0;target.alive=false;burst(target.x,target.y,"#e44755",18);showToast(`${target.name} foi eliminado!`);updateSurvivorHud();sixerH1.phase="";return;}
        if(sixerH1.hitCount>=4){
          const px=target.x+sixerH1.dirX*95,py=target.y+sixerH1.dirY*95;
          if(!collides(px,target.y,target.r))target.x=clamp(px,target.r,WORLD.w-target.r);
          if(!collides(target.x,py,target.r))target.y=clamp(py,target.r,WORLD.h-target.r);
          target.hurt=.5;target.panic=2;burst(target.x,target.y,"#ff763f",18);sixerH1.phase="";sixerH1.targetId=null;showToast(`${target.name} foi empurrado!`);
        }else sixerH1.hitTimer=.24;
        updateSurvivorHud();
      }
    }
    sixerH1.hitboxTimer=Math.max(0,sixerH1.hitboxTimer-dt);
  }
  function updateSixerH2(dt){
    sixerH2.cooldown=Math.max(0,sixerH2.cooldown-dt);
    if(selected!==3||!sixerH2.phase)return;
    if(sixerH2.phase==="jump"){
      sixerH2.timer-=dt;sixerH2.jumpY=Math.sin((.45-sixerH2.timer)/.45*Math.PI)*24;
      if(sixerH2.timer<=0){sixerH2.phase="wave";sixerH2.traveled=0;sixerH2.waveX=killer.x;sixerH2.waveY=killer.y;burst(killer.x,killer.y,"#ff6633",20);}
      return;
    }
    if(sixerH2.phase==="wave"){
      // Durante a onda, o Sixer pode curvar para os dois lados usando o controle direcional.
      let ax=(keys.has("a")||keys.has("arrowleft")?-1:0)+(keys.has("d")||keys.has("arrowright")?1:0)+touch.x;
      let ay=(keys.has("w")||keys.has("arrowup")?-1:0)+(keys.has("s")||keys.has("arrowdown")?1:0)+touch.y;
      const inputMag=Math.hypot(ax,ay);
      if(inputMag>.2){ax/=inputMag;ay/=inputMag;const steer=.9;let nx=sixerH2.dirX*(1-steer)+ax*steer,ny=sixerH2.dirY*(1-steer)+ay*steer,nm=Math.hypot(nx,ny)||1;sixerH2.dirX=nx/nm;sixerH2.dirY=ny/nm;}
      const step=Math.min(325*dt,700-sixerH2.traveled);sixerH2.waveX+=sixerH2.dirX*step;sixerH2.waveY+=sixerH2.dirY*step;sixerH2.traveled+=step;
      // A onda pode acertar o mesmo Survivor novamente se sair do alcance e voltar a tocá-lo.
      for(const target of survivors){
        if(!target.alive) { sixerH2.hitIds.delete(target.id); continue; }
        const touching=Math.hypot(target.x-sixerH2.waveX,target.y-sixerH2.waveY)<=target.r+sixerH2.waveRadius;
        if(!touching){sixerH2.hitIds.delete(target.id);continue;}
        if(sixerH2.hitIds.has(target.id))continue;
        if(touching){
          sixerH2.hitIds.add(target.id);target.hp-=20;target.hurt=.35;target.panic=2;
          burst(target.x,target.y,"#ff6633",12);showToast(`${target.name}: -20 HP (Onda de Impacto)`);
          if(target.hp<=0){target.hp=0;target.alive=false;burst(target.x,target.y,"#e44755",18);showToast(`${target.name} foi eliminado!`);}
          updateSurvivorHud();
        }
      }
      if(sixerH2.traveled>=700){sixerH2.phase="";sixerH2.jumpY=0;}
    }
  }

  function update(dt){
    if(!running||ended)return;
    recoverEntitiesFromWalls();
    resolveKillerSurvivorCollision();
    elapsed+=dt;timeLeft=Math.max(0,MATCH_SECONDS-elapsed);
    attackCooldown=Math.max(0,attackCooldown-dt);
    updateStabDash(dt);
    updateWesleyDash(dt);
    updateHackerHand(dt);
    updateJJBlast(dt);
    updateSixerH1(dt);
    updateSixerH2(dt);
    if(attackDelay>0){
      attackDelay=Math.max(0,attackDelay-dt);
      if(attackDelay===0&&activeHitbox){activeHitbox.visible=.25;attackFlash=.25;}
    }
    if(activeHitbox){
      // A hitbox gira com um pequeno atraso suave, durante a preparação e a janela ativa.
      activeHitbox.targetAngle=killer.angle;
      const angleDiff=Math.atan2(
        Math.sin(activeHitbox.targetAngle-activeHitbox.angle),
        Math.cos(activeHitbox.targetAngle-activeHitbox.angle)
      );
      const turnAlpha=1-Math.exp(-dt/HITBOX_TURN_DELAY);
      activeHitbox.angle+=angleDiff*turnAlpha;

      if(activeHitbox.visible>0){
        activeHitbox.visible=Math.max(0,activeHitbox.visible-dt);
        const a=activeHitbox.angle, ux=Math.cos(a), uy=Math.sin(a);
        const cx=killer.x+ux*(killer.r+activeHitbox.range/2-8),
      cy=killer.y+uy*(killer.r+activeHitbox.range/2-8);
        const halfL=activeHitbox.range/2, halfW=activeHitbox.size/2;
        for(const s of survivors){if(!s.alive||activeHitbox.hitIds.has(s.id))continue;
          const rx=s.x-cx, ry=s.y-cy, along=rx*ux+ry*uy, across=-rx*uy+ry*ux;
          if(along>=-s.r&&along<=halfL+s.r&&Math.abs(across)<=halfW+s.r){
            activeHitbox.hitIds.add(s.id);survivorTakesDamage(s,activeHitbox.damage);s.hurt=.25;
            burst(s.x,s.y,killers[selected].color,10);showToast(`${s.name}: -${activeHitbox.damage} HP`);
            if(s.hp<=0){s.alive=false;burst(s.x,s.y,"#e44755",18);showToast(`${s.name} foi eliminado!`);}
            updateSurvivorHud();
          }
        }
      }
      if(activeHitbox.visible<=0&&attackDelay<=0)activeHitbox=null;
    }
    attackFlash=Math.max(0,attackFlash-dt);
    if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)$("toast").classList.add("hidden");}
    const k=killers[selected];
    let dx=0,dy=0;
    if(keys.has("w")||keys.has("arrowup"))dy--;
    if(keys.has("s")||keys.has("arrowdown"))dy++;
    if(keys.has("a")||keys.has("arrowleft"))dx--;
    if(keys.has("d")||keys.has("arrowright"))dx++;
    dx+=touch.x;dy+=touch.y;
    const mag=Math.hypot(dx,dy);if(mag>1){dx/=mag;dy/=mag;}
    const stabBusy=selected===0&&!!stabDash.phase;
    const wesleyBusy=selected===4&&!!wesleyDash.phase;
    const hackerBusy=selected===2&&!!hackerHand.phase;
    // JJ pode andar normalmente enquanto a explosão carrega.
    const jjBusy=false;
    const sixerBusy=selected===3&&["prepare","dash","combo"].includes(sixerH1.phase);
    const sixerH2Busy=selected===3&&sixerH2.phase==="jump";
    const abilityBusy=stabBusy||wesleyBusy||hackerBusy||jjBusy||sixerBusy||sixerH2Busy;
    // Ao zerar a stamina, a corrida fica bloqueada até recuperar 25% da barra.
    if(killer.staminaExhausted&&killer.stamina>=killer.maxStamina*.25)killer.staminaExhausted=false;
    const sprint=!abilityBusy&&!killer.staminaExhausted&&(keys.has("shift")||touch.sprint)&&killer.stamina>0&&mag>.1;
    const speed=sprint?k.sprint:k.speed;
    if(sprint){
      killer.stamina=Math.max(0,killer.stamina-28*dt);
      if(killer.stamina<=0)killer.staminaExhausted=true;
    }else killer.stamina=Math.min(killer.maxStamina,killer.stamina+19*dt);
    if(mag>.1&&!abilityBusy){killer.angle=Math.atan2(dy,dx);killer.facingX=dx; killer.facingY=dy; killer.facing=dx<0?0:1;moveEntity(killer,dx*speed*dt,dy*speed*dt,killer.r);}
    survivors.forEach(s=>{
      if(!s.alive)return;
      s.think-=dt;s.hurt=Math.max(0,s.hurt-dt);s.panic=Math.max(0,s.panic-dt);
      s.speedBoost=Math.max(0,(s.speedBoost||0)-dt);
      s.dodgeTimer=Math.max(0,(s.dodgeTimer||0)-dt);
      s.speed=s.baseSpeed+(s.speedBoost>0?65:0);
      // Os Survivors nem sempre percebem uma habilidade: às vezes reagem e mudam de rota.
      let dangerX=killer.x,dangerY=killer.y,dangerRadius=0,abilityThreat=false;
      if(selected===1&&jjBlast.phase==="charge"){dangerRadius=jjBlast.radius+70;abilityThreat=true;}
      if(selected===0&&stabDash.phase==="prepare"){dangerRadius=250;abilityThreat=true;}
      if(selected===4&&wesleyDash.phase==="prepare"){dangerRadius=220;abilityThreat=true;}
      if(selected===3&&sixerH1.phase==="prepare"){dangerRadius=260;abilityThreat=true;}
      if(selected===2&&hackerHand.phase==="outbound"){dangerX=hackerHand.x;dangerY=hackerHand.y;dangerRadius=95;abilityThreat=true;}
      if(abilityThreat&&Math.hypot(s.x-dangerX,s.y-dangerY)<dangerRadius&&s.dodgeTimer<=0&&Math.random()<.42){
        s.dodgeTimer=1.1;s.panic= Math.max(s.panic,1.5);
        const away=Math.atan2(s.y-dangerY,s.x-dangerX)+rand(-.9,.9);
        setSurvivorGoal(s,s.x+Math.cos(away)*rand(220,340),s.y+Math.sin(away)*rand(220,340));
      }
      if(selected===3&&sixerH1.phase==="combo"&&sixerH1.targetId===s.id){s.angle=Math.atan2(-sixerH1.dirY,-sixerH1.dirX);return;}
      if(selected===2&&hackerHand.phase==="pulling"&&hackerHand.targetId===s.id){
        s.angle=Math.atan2(killer.y-s.y,killer.x-s.x);
        if(Math.hypot(s.x-killer.x,s.y-killer.y)<=killer.r+s.r+4){hackerHand.phase="returning";hackerHand.targetId=null;}
        return;
      }
      const d=dist(s,killer);let ax=0,ay=0;
      s.pathTimer-=dt;
      const fleeing=d<270||s.panic>0;
      // Escolhe um destino, então usa o caminho calculado para contornar blocos.
      if(fleeing){
        if(s.pathTimer<=0||!s.path.length||s.pathIndex>=s.path.length){
          const a=Math.atan2(s.y-killer.y,s.x-killer.x);
          const fleeDistance=rand(260,390);
          setSurvivorGoal(s,s.x+Math.cos(a)*fleeDistance+rand(-100,100),s.y+Math.sin(a)*fleeDistance+rand(-100,100));
        }
      }else if(s.think<=0||s.pathTimer<=0||!s.path.length||s.pathIndex>=s.path.length){
        s.think=rand(.7,1.5);
        // Tenta destinos aleatórios que sejam acessíveis em vez de andar reto contra uma parede.
        let chosen=false;
        for(let attempt=0;attempt<7&&!chosen;attempt++){
          const a=rand(0,Math.PI*2),len=rand(150,330);
          const gx=clamp(s.x+Math.cos(a)*len,180,WORLD.w-180),gy=clamp(s.y+Math.sin(a)*len,180,WORLD.h-180);
          setSurvivorGoal(s,gx,gy);chosen=s.path.length>0;
        }
      }
      // Recalcula periodicamente para reagir ao movimento do killer e a mudanças no caminho.
      if(s.pathTimer<=0&&s.goalX!=null)setSurvivorGoal(s,s.goalX,s.goalY);
      let waypoint=s.path[s.pathIndex];
      if(waypoint&&Math.hypot(waypoint.x-s.x,waypoint.y-s.y)<19){s.pathIndex++;waypoint=s.path[s.pathIndex];}
      if(waypoint){ax=waypoint.x-s.x;ay=waypoint.y-s.y;}
      else if(fleeing){const a=Math.atan2(s.y-killer.y,s.x-killer.x);ax=Math.cos(a);ay=Math.sin(a);}
      else {ax=Math.cos(s.wander);ay=Math.sin(s.wander);}
      // Proteção extra: se a próxima etapa estiver bloqueada, planeja uma rota nova.
      const norm=Math.hypot(ax,ay)||1;ax/=norm;ay/=norm;
      const step=Math.max(3,s.speed*dt*2.2);
      if(collides(s.x+ax*step,s.y+ay*step,s.r)){
        const oldGoalX=s.goalX,oldGoalY=s.goalY;
        s.path=[];s.pathIndex=0;s.pathTimer=0;
        if(oldGoalX!=null)setSurvivorGoal(s,oldGoalX,oldGoalY);
        waypoint=s.path[s.pathIndex];
        if(waypoint){ax=waypoint.x-s.x;ay=waypoint.y-s.y;const n=Math.hypot(ax,ay)||1;ax/=n;ay/=n;}
      }
      const oldX=s.x,oldY=s.y;
      moveEntity(s,ax*s.speed*dt,ay*s.speed*dt,s.r);
      if(Math.hypot(s.x-oldX,s.y-oldY)<.2){
        s.stuck+=dt;
        // Se ficar preso junto a um canto/obstáculo, abandona o destino antigo e
        // procura uma nova rota válida em vez de insistir na mesma parede.
        if(s.stuck>.7){
          s.path=[];s.pathIndex=0;s.pathTimer=0;s.think=0;
          let rerouted=false;
          for(let attempt=0;attempt<14&&!rerouted;attempt++){
            const a=rand(0,Math.PI*2),len=rand(220,430);
            const gx=clamp(s.x+Math.cos(a)*len,180,WORLD.w-180);
            const gy=clamp(s.y+Math.sin(a)*len,180,WORLD.h-180);
            setSurvivorGoal(s,gx,gy);
            rerouted=s.path.length>0;
          }
          // Último recurso: escolhe uma direção local livre para sair do canto.
          if(!rerouted){
            const escapes=[[-1,0],[1,0],[0,-1],[0,1],[-.7,-.7],[.7,-.7],[-.7,.7],[.7,.7]];
            for(const [ex,ey] of escapes){
              if(!collides(s.x+ex*32,s.y+ey*32,s.r)){
                s.goalX=clamp(s.x+ex*180,180,WORLD.w-180);s.goalY=clamp(s.y+ey*180,180,WORLD.h-180);
                s.path=findSurvivorPath(s,s.goalX,s.goalY);s.pathIndex=0;s.pathTimer=.5;break;
              }
            }
          }
          s.stuck=0;
        }
      }else s.stuck=0;
      s.angle=Math.atan2(ay,ax);
      // Encostar em um Survivor não causa dano ao Killer. O Killer só perde HP por ataques dos Survivors.
    });
    particles.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.96;p.vy*=.96;p.life-=dt;});
    particles=particles.filter(p=>p.life>0);
    camera.x = clamp(
  killer.x - viewW / (2 * ZOOM),
  0,
  WORLD.w - viewW / ZOOM
);

camera.y = clamp(
  killer.y - viewH / (2 * ZOOM),
  0,
  WORLD.h - viewH / ZOOM
);
    $("timer").textContent=`${Math.floor(timeLeft/60).toString().padStart(2,"0")}:${Math.floor(timeLeft%60).toString().padStart(2,"0")}`;
    $("killerHealthBar").style.width=`${clamp(killer.hp/killer.maxHp*100,0,100)}%`;
    $("killerHealthText").textContent=`${Math.ceil(killer.hp)} / ${killer.maxHp}`;
    if(timeLeft<=0)finish(false,"O tempo acabou antes de você eliminar todos os Survivors.");
    checkEnd();
  }
  function checkEnd(){if(!running||ended)return;if(survivors.every(s=>!s.alive))finish(true,"Todos os Survivors foram eliminados.");}
  function finish(won,description){
    if(ended)return;ended=true;running=false;
    $("endTitle").textContent=won?"CAÇADA CONCLUÍDA":"OS SURVIVORS ESCAPARAM";
    $("endDescription").textContent=description;
    $("endOverlay").classList.remove("hidden");
  }
  
function drawFloor(){
  if(currentMap === "estacao"){
    // Chão industrial da Estação do Fim
    ctx.fillStyle = "#182126";
    ctx.fillRect(0,0,WORLD.w,WORLD.h);

    // Placas metálicas no piso
    ctx.strokeStyle = "#a4b6bd12";
    ctx.lineWidth = 2;

    for(let x=35;x<WORLD.w;x+=100){
      ctx.beginPath();
      ctx.moveTo(x,35);
      ctx.lineTo(x,WORLD.h-35);
      ctx.stroke();
    }

    for(let y=35;y<WORLD.h;y+=100){
      ctx.beginPath();
      ctx.moveTo(35,y);
      ctx.lineTo(WORLD.w-35,y);
      ctx.stroke();
    }

    // Manchas de ferrugem e sujeira
    for(let i=0;i<48;i++){
      const x=(i*317+83)%WORLD.w;
      const y=(i*191+57)%WORLD.h;

      ctx.fillStyle=i%2 ? "#59664a22" : "#74452b30";
      ctx.beginPath();
      ctx.ellipse(
        x,y,
        randStatic(i,18,55),
        randStatic(i+1,10,32),
        i*.2,0,Math.PI*2
      );
      ctx.fill();
    }

    // Linhas de segurança amarelas
    ctx.strokeStyle = "#b8a34b55";
    ctx.lineWidth = 4;
    ctx.setLineDash([18,12]);

    ctx.strokeRect(55,55,WORLD.w-110,WORLD.h-110);

    ctx.setLineDash([]);

    // Contorno industrial
    ctx.strokeStyle = "#56666c";
    ctx.lineWidth = 3;
    ctx.strokeRect(35,35,WORLD.w-70,WORLD.h-70);

  }else{
    // Chão original, preservado
    ctx.fillStyle="#111820";
    ctx.fillRect(0,0,WORLD.w,WORLD.h);

    ctx.strokeStyle="#ffffff08";
    ctx.lineWidth=1;

    for(let x=35;x<WORLD.w;x+=50){
      ctx.beginPath();
      ctx.moveTo(x,35);
      ctx.lineTo(x,WORLD.h-35);
      ctx.stroke();
    }

    for(let y=35;y<WORLD.h;y+=50){
      ctx.beginPath();
      ctx.moveTo(35,y);
      ctx.lineTo(WORLD.w-35,y);
      ctx.stroke();
    }

    // Manchas de concreto úmido
    for(let i=0;i<40;i++){
      const x=(i*317+83)%WORLD.w;
      const y=(i*191+57)%WORLD.h;

      ctx.fillStyle=i%2?"#25302c22":"#5c343015";
      ctx.beginPath();
      ctx.ellipse(
        x,y,
        randStatic(i,15,48),
        randStatic(i+1,9,28),
        i*.2,0,Math.PI*2
      );
      ctx.fill();
    }

    ctx.strokeStyle="#38434b";
    ctx.lineWidth=3;
    ctx.strokeRect(35,35,WORLD.w-70,WORLD.h-70);
  }
}

  function randStatic(n,a,b){const x=Math.sin(n*127.1)*43758.5453;return a+(x-Math.floor(x))*(b-a);}
  
function drawObstacle(o){
    // Sombra
    ctx.fillStyle="#0008";
    ctx.fillRect(o.x+5,o.y+7,o.w,o.h);

    // Corpo do obstáculo
    const g=ctx.createLinearGradient(
      o.x,o.y,o.x+o.w,o.y+o.h
    );

    if(currentMap === "estacao"){
      g.addColorStop(0,"#35464b");
      g.addColorStop(1,"#19262c");
    }else{
      g.addColorStop(0,"#343b43");
      g.addColorStop(1,"#1b222b");
    }

    ctx.fillStyle=g;
    ctx.fillRect(o.x,o.y,o.w,o.h);

    // Contorno
    ctx.strokeStyle=currentMap === "estacao"
      ? "#75888a"
      : "#59616b";

    ctx.lineWidth=2;
    ctx.strokeRect(o.x+1,o.y+1,o.w-2,o.h-2);

    // Faixa superior metálica
    ctx.strokeStyle="#ffffff0c";
    ctx.beginPath();
    ctx.moveTo(o.x+8,o.y+8);
    ctx.lineTo(o.x+o.w-8,o.y+8);
    ctx.stroke();

    if(currentMap === "estacao"){
      // Pequenos detalhes de segurança
      ctx.fillStyle="#c5a84b";
      ctx.fillRect(o.x+8,o.y+o.h-7,Math.min(o.w-16,35),3);

      // Painel luminoso de emergência
      ctx.fillStyle="#d34b43";
      ctx.fillRect(o.x+o.w-15,o.y+10,5,5);
    }
}
  function drawPerson(e,type,color,label,hp,maxHp,angle){
    const size = e.size || (e.r * 2);
    ctx.save();
    ctx.translate(e.x,e.y);
    if(type==="killer"){
      const img=killerImages[selected];
      if(img&&img.complete&&img.naturalWidth){
        // Os sprites apontam para cima quando angle = -PI/2.
        ctx.save();
        ctx.rotate((Number.isFinite(angle)?angle:-Math.PI/2)+Math.PI/2);
        ctx.drawImage(img,-size/2,-size/2,size,size);
        ctx.restore();
      }else{
        ctx.fillStyle=color;ctx.beginPath();ctx.arc(0,0,e.r,0,Math.PI*2);ctx.fill();
        ctx.save();ctx.rotate(Number.isFinite(angle)?angle:0);ctx.fillStyle="#fff";
        ctx.beginPath();ctx.moveTo(e.r+5,0);ctx.lineTo(e.r-2,-5);ctx.lineTo(e.r-2,5);ctx.closePath();ctx.fill();ctx.restore();
      }
    }else{
  // Imagem do Survivor, dimensionada por e.size.
  if (survivorImage.complete && survivorImage.naturalWidth > 0) {
    ctx.drawImage(
      survivorImage,
      -size / 2,
      -size / 2,
      size,
      size
    );
  } else {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(0, 0, e.r, 0, Math.PI * 2);
    ctx.fill();
  }
      // Indicador de direção para mostrar para onde cada Survivor está virado.
      ctx.save();ctx.rotate(Number.isFinite(angle)?angle:0);ctx.fillStyle="#d5f7e5";
      ctx.beginPath();ctx.moveTo(e.r+4,0);ctx.lineTo(e.r-3,-4);ctx.lineTo(e.r-3,4);ctx.closePath();ctx.fill();ctx.restore();
      ctx.fillStyle="#0008";ctx.fillRect(-16,-e.r-12,32,4);ctx.fillStyle="#58d39b";ctx.fillRect(-16,-e.r-12,32*clamp(hp/maxHp,0,1),4);
    }
    ctx.restore();
    ctx.font=type==="killer"?"bold 11px Inter":"10px Inter";ctx.textAlign="center";ctx.fillStyle=type==="killer"?"#fff":"#c5e5d5";
    ctx.fillText(label,e.x,e.y-size/2-7);
  }
  function render(){
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,viewW,viewH);

ctx.save();
ctx.scale(ZOOM, ZOOM);
ctx.translate(-camera.x, -camera.y);
    drawFloor();obstacles.forEach(drawObstacle);
    
    if(currentMap === "estacao"){
      const signs = [
        {x:270,y:105,text:"LABORATORIO"},
        {x:720,y:115,text:"PESQUISA"},
        {x:1200,y:120,text:"ARQUIVO"},
        {x:390,y:345,text:"SALA DO GERADOR"},
        {x:820,y:390,text:"CONTROLE"},
        {x:290,y:635,text:"ESTUFA"},
        {x:770,y:655,text:"MANUTENCAO"},
        {x:1190,y:700,text:"HELIPONTO"}
      ];

      signs.forEach(sign=>{
        ctx.fillStyle="#071015cc";
        ctx.fillRect(sign.x-75,sign.y-17,150,30);

        ctx.strokeStyle="#82969a";
        ctx.lineWidth=1;
        ctx.strokeRect(sign.x-75,sign.y-17,150,30);

        ctx.fillStyle="#d6e2df";
        ctx.font="bold 11px monospace";
        ctx.textAlign="center";
        ctx.textBaseline="middle";
        ctx.fillText(sign.text,sign.x,sign.y-2);
      });

      ctx.textBaseline="alphabetic";
    }

    // Hitbox quadrada à frente do Killer, visível por 0,25 s após o delay de 0,15 s.
    if(activeHitbox&&activeHitbox.visible>0){
      const a=activeHitbox.angle, range=activeHitbox.range, size=activeHitbox.size;
      ctx.save();ctx.translate(killer.x,killer.y);ctx.rotate(a);
      ctx.fillStyle="#ff2020a0";ctx.strokeStyle="#ff3939";ctx.lineWidth=2;
      ctx.fillRect(killer.r, -size/2, range, size);ctx.strokeRect(killer.r, -size/2, range, size);ctx.restore();
    }
    if(selected===0&&stabDash.phase){
      ctx.save();ctx.translate(killer.x,killer.y);
      if(stabDash.phase==="prepare"){
        const pulse=.75+Math.sin(elapsed*28)*.18;ctx.strokeStyle="#ff9d32";ctx.lineWidth=3;ctx.globalAlpha=.85;
        ctx.beginPath();ctx.arc(0,0,killer.r+8*pulse,0,Math.PI*2);ctx.stroke();
        ctx.globalAlpha=.95;ctx.strokeStyle="#ffb347";ctx.lineWidth=4;
        ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(stabDash.x*400,stabDash.y*400);ctx.stroke();
        ctx.globalAlpha=.16;ctx.fillStyle="#ff9d32";ctx.beginPath();ctx.arc(0,0,killer.r+8,0,Math.PI*2);ctx.fill();
      }else{
        ctx.rotate(Math.atan2(stabDash.y,stabDash.x));
        ctx.globalAlpha=.34;ctx.fillStyle="#ff9d32";ctx.strokeStyle="#ffd09a";ctx.lineWidth=3;
        ctx.fillRect(killer.r-2,-killer.r*.72,58,killer.r*1.44);ctx.strokeRect(killer.r-2,-killer.r*.72,58,killer.r*1.44);
      }
      ctx.restore();
    }
    if(selected===1&&(jjBlast.phase==="charge"||jjBlast.explosionTimer>0)){
      ctx.save();ctx.translate(killer.x,killer.y);
      if(jjBlast.phase==="charge"){
        const progress=1-jjBlast.timer/2;
        const blinking=jjBlast.timer<.6&&Math.floor(elapsed*14)%2===0;
        ctx.globalAlpha=blinking?.95:.15+progress*.5;ctx.fillStyle="#ff1010";
        ctx.beginPath();ctx.arc(0,0,jjBlast.radius,0,Math.PI*2);ctx.fill();
        ctx.globalAlpha=.5+progress*.5;ctx.strokeStyle="#ff3030";ctx.lineWidth=3+progress*3;
        ctx.beginPath();ctx.arc(0,0,jjBlast.radius,0,Math.PI*2);ctx.stroke();
      }
      if(jjBlast.explosionTimer>0){
        const progress=1-jjBlast.explosionTimer/.35;
        ctx.globalAlpha=jjBlast.explosionTimer/.35;ctx.fillStyle="#ff2020";
        ctx.beginPath();ctx.arc(0,0,jjBlast.radius*(.65+progress*.35),0,Math.PI*2);ctx.fill();
        ctx.strokeStyle="#ff7777";ctx.lineWidth=5;ctx.beginPath();
        ctx.arc(0,0,jjBlast.radius*(.65+progress*.35),0,Math.PI*2);ctx.stroke();
      }
      ctx.restore();
    }
    if(selected===2&&hackerHand.phase){
      ctx.save();
      ctx.strokeStyle="#53c8d4";ctx.lineWidth=9;ctx.lineCap="round";ctx.globalAlpha=.9;
      ctx.beginPath();ctx.moveTo(killer.x,killer.y);ctx.lineTo(hackerHand.x,hackerHand.y);ctx.stroke();
      ctx.strokeStyle="#b8fbff";ctx.lineWidth=3;ctx.globalAlpha=.95;
      ctx.beginPath();ctx.moveTo(killer.x,killer.y);ctx.lineTo(hackerHand.x,hackerHand.y);ctx.stroke();
      ctx.translate(hackerHand.x,hackerHand.y);ctx.rotate(Math.atan2(hackerHand.dirY,hackerHand.dirX));
      ctx.fillStyle="#263b45";ctx.strokeStyle="#7af0ff";ctx.lineWidth=3;
      ctx.beginPath();ctx.arc(0,0,13,0,Math.PI*2);ctx.fill();ctx.stroke();
      ctx.beginPath();ctx.moveTo(4,-7);ctx.lineTo(19,-12);ctx.lineTo(22,-7);ctx.moveTo(4,7);ctx.lineTo(19,12);ctx.lineTo(22,7);ctx.stroke();
      ctx.restore();
    }
    if(selected===4&&wesleyDash.phase){
      ctx.save();ctx.translate(killer.x,killer.y);
      if(wesleyDash.phase==="prepare"){
        ctx.strokeStyle="#bda7ff";ctx.lineWidth=4;ctx.globalAlpha=.9;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(wesleyDash.x*260,wesleyDash.y*260);ctx.stroke();
        ctx.fillStyle="#a68aff";ctx.globalAlpha=.2;ctx.beginPath();ctx.arc(0,0,killer.r+8,0,Math.PI*2);ctx.fill();
      }else{
        ctx.rotate(Math.atan2(wesleyDash.y,wesleyDash.x));ctx.globalAlpha=.38;ctx.fillStyle="#a68aff";ctx.strokeStyle="#e0d7ff";ctx.lineWidth=3;
        ctx.fillRect(killer.r-2,-killer.r*.78,48,killer.r*1.56);ctx.strokeRect(killer.r-2,-killer.r*.78,48,killer.r*1.56);
      }
      ctx.restore();
    }
    if(selected===3&&sixerH1.phase){
      ctx.save();
      if(sixerH1.phase==="prepare"){
        ctx.strokeStyle="#ff263f";ctx.lineWidth=4;ctx.globalAlpha=.9;ctx.beginPath();ctx.moveTo(killer.x,killer.y);ctx.lineTo(killer.x+sixerH1.dirX*330,killer.y+sixerH1.dirY*330);ctx.stroke();
        ctx.fillStyle="#ff263f";ctx.globalAlpha=.12;ctx.beginPath();ctx.arc(killer.x,killer.y, killer.r+13,0,Math.PI*2);ctx.fill();
      }else if(sixerH1.phase==="dash"){
        const hx=killer.x+sixerH1.dirX*20,hy=killer.y+sixerH1.dirY*20;ctx.translate(hx,hy);ctx.rotate(Math.atan2(sixerH1.dirY,sixerH1.dirX));
        ctx.fillStyle="#ff263f88";ctx.strokeStyle="#ff344d";ctx.lineWidth=3;ctx.fillRect(-8,-31,75,62);ctx.strokeRect(-8,-31,75,62);
      }else if(sixerH1.phase==="combo"&&sixerH1.hitboxTimer>0){
        const target=survivors.find(s=>s.id===sixerH1.targetId&&s.alive);if(target){ctx.fillStyle="#ff263fa8";ctx.strokeStyle="#ffb0b8";ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(target.x,target.y,30,22,Math.atan2(sixerH1.dirY,sixerH1.dirX),0,Math.PI*2);ctx.fill();ctx.stroke();}
      }
      ctx.restore();
    }
    if(selected===3&&sixerH2.phase){
      ctx.save();
      if(sixerH2.phase==="jump"){
        ctx.globalAlpha=.45;ctx.strokeStyle="#ff6633";ctx.lineWidth=4;ctx.beginPath();ctx.ellipse(killer.x,killer.y+12, killer.r+8,killer.r*.55+8,0,0,Math.PI*2);ctx.stroke();
        ctx.globalAlpha=.7;ctx.fillStyle="#ff6633";ctx.beginPath();ctx.arc(killer.x,killer.y-sixerH2.jumpY,killer.r*.72,0,Math.PI*2);ctx.fill();
      }else if(sixerH2.phase==="wave"){
        ctx.globalAlpha=.36;ctx.fillStyle="#ff6633";ctx.beginPath();ctx.arc(sixerH2.waveX,sixerH2.waveY,sixerH2.waveRadius,0,Math.PI*2);ctx.fill();
        ctx.globalAlpha=.95;ctx.strokeStyle="#ffb078";ctx.lineWidth=4;ctx.beginPath();ctx.arc(sixerH2.waveX,sixerH2.waveY,sixerH2.waveRadius,0,Math.PI*2);ctx.stroke();
        ctx.globalAlpha=.65;ctx.strokeStyle="#ff6633";ctx.lineWidth=2;ctx.beginPath();ctx.arc(sixerH2.waveX,sixerH2.waveY,sixerH2.waveRadius+9,0,Math.PI*2);ctx.stroke();
      }
      ctx.restore();
    }
    survivors.forEach(s=>{if(s.alive)drawPerson(s,"survivor","#58d39b",s.name,s.hp,s.maxHp,s.angle);});
    drawPerson(killer,"killer",killers[selected].color,killers[selected].name,killer.hp,killer.maxHp,killer.angle);
    particles.forEach(p=>{ctx.globalAlpha=clamp(p.life/p.max,0,1);ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,Math.PI*2);ctx.fill();});ctx.globalAlpha=1;
    ctx.restore();
    // stamina bar at the bottom of the arena.
    const barW=Math.min(180,viewW*.4),bx=(viewW-barW)/2,by=viewH-18;
    ctx.fillStyle="#0009";ctx.fillRect(bx-2,by-2,barW+4,9);ctx.fillStyle="#303440";ctx.fillRect(bx,by,barW,5);
    ctx.fillStyle="#6fc8ed";ctx.fillRect(bx,by,barW*(killer.stamina/killer.maxStamina),5);
    ctx.fillStyle="#c3cbd8";ctx.font="9px Inter";ctx.textAlign="center";ctx.fillText("STAMINA",viewW/2,by-5);
    if(selected===0){
      const ready=stabDash.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";
      ctx.fillStyle=ready?"#ff6674":"#d0d4dc";
      ctx.fillText(`Q • SHADOW DASH ${ready?"PRONTO":stabDash.cooldown.toFixed(1)+"s"}`,viewW-12,22);
    }else if(selected===1){
      const ready=jjBlast.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";
      ctx.fillStyle=ready?"#ff6674":"#d0d4dc";
      ctx.fillText(`E • SOBRECARGA ${ready?"PRONTO":jjBlast.cooldown.toFixed(1)+"s"}`,viewW-12,22);
    }else if(selected===2){
      const ready=hackerHand.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";
      ctx.fillStyle=ready?"#65e8f5":"#d0d4dc";
      ctx.fillText(`E • BRAÇO ROBÓTICO ${ready?"PRONTO":hackerHand.cooldown.toFixed(1)+"s"}`,viewW-12,22);
        }else if(selected===3){
      const ready1=sixerH1.cooldown<=0,ready2=sixerH2.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";
      ctx.fillStyle=ready1?"#ff6674":"#d0d4dc";ctx.fillText(`Q • INVESTIDA ${ready1?"PRONTA":sixerH1.cooldown.toFixed(1)+"s"}`,viewW-12,22);
      ctx.fillStyle=ready2?"#ff9a66":"#d0d4dc";ctx.fillText(`E • IMPACTO ${ready2?"PRONTO":sixerH2.cooldown.toFixed(1)+"s"}`,viewW-12,39);
    }else if(selected===4){
      const ready=wesleyDash.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";ctx.fillStyle=ready?"#c4b5fd":"#d0d4dc";ctx.fillText(`Q • INVESTIDA BRUTAL ${ready?"PRONTA":wesleyDash.cooldown.toFixed(1)+"s"}`,viewW-12,22);
    }
  }
  function loop(now){
    if(!running)return;
    const dt=Math.min((now-lastTime)/1000,.035);lastTime=now;
    update(dt);render();
    if(running)requestAnimationFrame(loop);
  }
  function goMenu(){running=false;ended=false;gameScreen.classList.add("hidden");selectScreen.classList.remove("hidden");}
  $("startButton").addEventListener("click",startGame);
  $("restartButton").addEventListener("click",startGame);
  $("menuButton").addEventListener("click",goMenu);
  $("backButton").addEventListener("click",goMenu);
  window.addEventListener("resize",()=>{if(!gameScreen.classList.contains("hidden"))resizeCanvas();});
  window.addEventListener("keydown",e=>{
    const key=e.key.toLowerCase();
    if(["arrowup","arrowdown","arrowleft","arrowright"," "].includes(key))e.preventDefault();
    keys.add(key);
    if(key===" "&&!e.repeat)doAttack();
    if(key==="q"&&!e.repeat){if(selected===0)activateStabDash();else if(selected===3)activateSixerH1();else if(selected===4)activateWesleyDash();}
    if(key==="e"&&!e.repeat){if(selected===1)activateJJBlast();else if(selected===2)activateHackerHand();else if(selected===3)activateSixerH2();}
  });
  window.addEventListener("keyup",e=>keys.delete(e.key.toLowerCase()));
  window.addEventListener("blur",()=>keys.clear());
  $("attackTouch").addEventListener("pointerdown",e=>{e.preventDefault();doAttack();});
  $("skillTouch").addEventListener("pointerdown",e=>{
    e.preventDefault();
    if(selected===0)activateStabDash();
    else if(selected===1)activateJJBlast();
    else if(selected===2)activateHackerHand();
    else if(selected===3)activateSixerH1();
    else if(selected===4)activateWesleyDash();
  });
  $("skill2Touch").addEventListener("pointerdown",e=>{e.preventDefault();if(selected===3)activateSixerH2();});
  $("sprintTouch").addEventListener("pointerdown",e=>{
    e.preventDefault();
    touch.sprint=!touch.sprint; // Toque para ativar, outro toque para desativar.
    $("sprintTouch").classList.toggle("active",touch.sprint);
    $("sprintTouch").setAttribute("aria-pressed",String(touch.sprint));
  });
  const joystick=$("joystick"),stick=$("stick");
  joystick.addEventListener("pointerdown",e=>{joyActive=true;joystick.setPointerCapture(e.pointerId);const r=joystick.getBoundingClientRect();joyCenter={x:r.left+r.width/2,y:r.top+r.height/2};updateJoy(e);});
  joystick.addEventListener("pointermove",e=>{if(joyActive)updateJoy(e);});
  function updateJoy(e){const dx=e.clientX-joyCenter.x,dy=e.clientY-joyCenter.y,len=Math.hypot(dx,dy),max=25,scale=len>max?max/len:1;touch.x=dx*scale/max;touch.y=dy*scale/max;stick.style.left=`${25+dx*scale}px`;stick.style.top=`${25+dy*scale}px`;}
  function resetJoy(){joyActive=false;touch.x=0;touch.y=0;stick.style.left="25px";stick.style.top="25px";}
  ["pointerup","pointercancel","lostpointercapture"].forEach(ev=>joystick.addEventListener(ev,resetJoy));
  buildSelection();
})();