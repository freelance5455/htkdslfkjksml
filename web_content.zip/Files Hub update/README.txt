# ASYM 2D — protótipo sem engine

## Como jogar
1. Extraia a pasta `ASYM_2D`.
2. Abra `index.html` em um navegador moderno.
3. Escolha um dos cinco Killers e pressione **Iniciar partida**.

## Controles
- WASD ou setas: movimentar
- Espaço: atacar
- Shift: correr
- Celular: joystick virtual, botão Atacar e botão Correr

## O que já funciona
- Tela de seleção de Stab, JJ, H4ck4r, Sixer e Wesley
- Arena top-down desenhada em Canvas
- Seis Survivors bots que fogem quando o Killer se aproxima
- Colisão com obstáculos, HP, stamina, ataque corpo a corpo e dano de contato
- Temporizador de 4 minutos e telas de vitória/derrota
- Layout adaptável para celular

## Notas
O protótipo usa desenhos vetoriais provisórios para representar os personagens. Eles podem ser substituídos por sprites PNG depois. Não usa engine de jogo nem bibliotecas de gameplay. A fonte visual da interface é carregada de Google Fonts quando há conexão; o jogo funciona sem ela.
