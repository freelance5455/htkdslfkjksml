import { initRouter, registerRoute } from './core/router.js';
import { initXPEngine } from './core/xp/xpEngine.js';
import { initToastListeners } from './core/notifications/toast.js';
import { renderNavBar } from './components/layout/navBar.js';
import { Dashboard } from './pages/Dashboard.js';
import { Settings } from './pages/Settings.js';
import { BodyPage } from './pages/BodyPage.js';
import { MindPage } from './pages/MindPage.js';
import { DisciplinePage } from './pages/DisciplinePage.js';
import { PresencePage } from './pages/PresencePage.js';
import { ProgressPage } from './pages/ProgressPage.js';
import { icon } from './components/icons.js';
import { navigate } from './core/router.js';

// --- Boot core services (order matters: XP engine before any events fire) ---
initXPEngine();
initToastListeners();

// --- Register routes ---
registerRoute('/', Dashboard);
registerRoute('/body', BodyPage);
registerRoute('/mind', MindPage);
registerRoute('/discipline', DisciplinePage);
registerRoute('/presence', PresencePage);
registerRoute('/progress', ProgressPage);
registerRoute('/settings', Settings);

// --- Mount ---
const appRoot = document.getElementById('app');
initRouter(appRoot);
renderNavBar();

// --- Floating settings access (top-right, present on every route) ---
const settingsBtn = document.createElement('button');
settingsBtn.id = 'settings-fab';
settingsBtn.setAttribute('aria-label', 'Settings');
settingsBtn.append(icon('settings'));
settingsBtn.addEventListener('click', () => navigate('/settings'));
document.body.appendChild(settingsBtn);

// --- Register service worker ---
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch((err) => {
      console.error('[sw] registration failed', err);
    });
  });
}

// --- Custom install prompt handling ---
let deferredInstallPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  document.dispatchEvent(new CustomEvent('pwa:installable'));
});

export function triggerInstallPrompt() {
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  deferredInstallPrompt = null;
}
