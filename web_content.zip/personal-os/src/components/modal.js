/**
 * modal.js — generic bottom-sheet used by the Quick Actions panel and
 * any future module. One implementation, imported everywhere, so
 * modal behavior (backdrop, close, focus trap) never gets duplicated.
 */

import { el } from './ui.js';

let activeSheet = null;

export function closeSheet() {
  if (!activeSheet) return;
  activeSheet.backdrop.classList.remove('sheet-backdrop--visible');
  activeSheet.sheet.classList.remove('bottom-sheet--visible');
  setTimeout(() => {
    activeSheet.backdrop.remove();
    activeSheet = null;
  }, 220);
}

/**
 * @param {string} title
 * @param {(bodyEl: HTMLElement, close: Function) => void} buildBody
 */
export function openSheet(title, buildBody) {
  closeSheet();

  const backdrop = el('div', 'sheet-backdrop');
  const sheet = el('div', 'bottom-sheet');
  const header = el('div', 'bottom-sheet__header', [
    el('div', 'bottom-sheet__handle'),
    el('h3', null, title),
  ]);
  const body = el('div', 'bottom-sheet__body');

  sheet.append(header, body);
  backdrop.append(sheet);
  document.body.append(backdrop);

  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) closeSheet();
  });

  requestAnimationFrame(() => {
    backdrop.classList.add('sheet-backdrop--visible');
    sheet.classList.add('bottom-sheet--visible');
  });

  activeSheet = { backdrop, sheet };
  buildBody(body, closeSheet);
}
