/**
 * icons.js — minimal inline SVG icon set, hand-picked lucide-style paths.
 * Bundled as strings (no icon font/CDN) so the app stays 100% offline.
 */

const wrap = (paths) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;

export const ICONS = {
  home: wrap('<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>'),
  body: wrap('<circle cx="12" cy="5" r="2.5"/><path d="M8 22v-6l-2-6 4-2 2 2 2-2 4 2-2 6v6"/>'),
  mind: wrap('<path d="M9 4a3 3 0 0 0-3 3v1a3 3 0 0 0-2 5 3 3 0 0 0 2 5h1a3 3 0 0 0 3 3"/><path d="M15 4a3 3 0 0 1 3 3v1a3 3 0 0 1 2 5 3 3 0 0 1-2 5h-1a3 3 0 0 1-3 3"/>'),
  discipline: wrap('<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M9 12l2 2 4-4"/>'),
  presence: wrap('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>'),
  progress: wrap('<path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/>'),
  settings: wrap('<circle cx="12" cy="12" r="3"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'),
  flame: wrap('<path d="M12 2s5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 2 1 0 0-2-1-3-1-5 1 0 3 1 3-1z"/>'),
  droplet: wrap('<path d="M12 2s7 8 7 13a7 7 0 0 1-14 0c0-5 7-13 7-13z"/>'),
  book: wrap('<path d="M4 4h9a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4z"/><path d="M20 4h-9a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h10z"/>'),
  dumbbell: wrap('<path d="M6 7v10M18 7v10M2 12h2M20 12h2M6 12h12"/>'),
  chevronRight: wrap('<path d="M9 6l6 6-6 6"/>'),
  plus: wrap('<path d="M12 5v14M5 12h14"/>'),
  timer: wrap('<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2"/><path d="M9 2h6"/>'),
  utensils: wrap('<path d="M6 2v8M4 2v6a2 2 0 0 0 4 0V2"/><path d="M18 2c-2 0-3 3-3 6s1 4 3 4v10"/>'),
  smile: wrap('<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><path d="M9 9h.01M15 9h.01"/>'),
  notebook: wrap('<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 3v18M4 8h4M4 13h4M4 18h4"/>'),
  x: wrap('<path d="M6 6l12 12M18 6L6 18"/>'),
};

export function icon(name) {
  const span = document.createElement('span');
  span.innerHTML = ICONS[name] || '';
  return span.firstChild;
}
