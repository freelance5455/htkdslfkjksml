import { icon } from '../icons.js';
import { navigate } from '../../core/router.js';

const NAV_ITEMS = [
  { path: '/', label: 'Home', icon: 'home' },
  { path: '/body', label: 'Body', icon: 'body' },
  { path: '/mind', label: 'Mind', icon: 'mind' },
  { path: '/discipline', label: 'Discipline', icon: 'discipline' },
  { path: '/presence', label: 'Presence', icon: 'presence' },
  { path: '/progress', label: 'Progress', icon: 'progress' },
];

export function renderNavBar() {
  const existing = document.getElementById('nav-bar');
  if (existing) existing.remove();

  const nav = document.createElement('nav');
  nav.id = 'nav-bar';
  nav.className = 'nav-bar';

  const currentPath = window.location.hash.replace('#', '') || '/';

  NAV_ITEMS.forEach(({ path, label, icon: iconName }) => {
    const item = document.createElement('button');
    item.className = `nav-item${path === currentPath ? ' nav-item--active' : ''}`;
    item.append(icon(iconName), document.createTextNode(label));
    item.addEventListener('click', () => navigate(path));
    nav.appendChild(item);
  });

  document.body.appendChild(nav);
}

document.addEventListener('route:changed', renderNavBar);
