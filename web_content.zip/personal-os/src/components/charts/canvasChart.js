/**
 * canvasChart.js — dependency-free chart rendering on <canvas>.
 * Chosen over a charting library so the app has zero runtime dependencies
 * to fetch/bundle — critical for a project that must stay installable
 * and fully offline for years without a rebuild.
 */

function getCSSVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

function setupHiDPICanvas(canvas, width, height) {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  return ctx;
}

/**
 * Renders a smooth line chart.
 * @param {HTMLCanvasElement} canvas
 * @param {{date:string, value:number}[]} series
 * @param {{color?:string, maxOverride?:number, height?:number}} opts
 */
export function renderLineChart(canvas, series, opts = {}) {
  const width = canvas.parentElement.clientWidth || 320;
  const height = opts.height || 120;
  const ctx = setupHiDPICanvas(canvas, width, height);
  const color = opts.color || getCSSVar('--c-emerald-soft') || '#17C77E';
  const gridColor = getCSSVar('--c-border') || 'rgba(255,255,255,0.08)';

  ctx.clearRect(0, 0, width, height);

  const values = series.map((s) => s.value);
  const max = opts.maxOverride || Math.max(1, ...values);
  const paddingX = 8;
  const paddingY = 12;
  const chartW = width - paddingX * 2;
  const chartH = height - paddingY * 2;
  const stepX = series.length > 1 ? chartW / (series.length - 1) : 0;

  // gridlines
  ctx.strokeStyle = gridColor;
  ctx.lineWidth = 1;
  [0.25, 0.5, 0.75].forEach((frac) => {
    const y = paddingY + chartH * (1 - frac);
    ctx.beginPath();
    ctx.moveTo(paddingX, y);
    ctx.lineTo(width - paddingX, y);
    ctx.stroke();
  });

  const points = series.map((s, i) => ({
    x: paddingX + stepX * i,
    y: paddingY + chartH * (1 - Math.min(1, s.value / max)),
  }));

  // filled area
  const gradient = ctx.createLinearGradient(0, paddingY, 0, height - paddingY);
  gradient.addColorStop(0, `${color}33`);
  gradient.addColorStop(1, `${color}00`);
  ctx.beginPath();
  ctx.moveTo(points[0].x, height - paddingY);
  points.forEach((p) => ctx.lineTo(p.x, p.y));
  ctx.lineTo(points[points.length - 1].x, height - paddingY);
  ctx.closePath();
  ctx.fillStyle = gradient;
  ctx.fill();

  // line
  ctx.beginPath();
  points.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.5;
  ctx.lineJoin = 'round';
  ctx.stroke();

  // last-point dot
  const last = points[points.length - 1];
  ctx.beginPath();
  ctx.arc(last.x, last.y, 3.5, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
}

/**
 * Renders a simple bar chart (used for habit consistency %, study hours/day).
 */
export function renderBarChart(canvas, series, opts = {}) {
  const width = canvas.parentElement.clientWidth || 320;
  const height = opts.height || 120;
  const ctx = setupHiDPICanvas(canvas, width, height);
  const color = opts.color || getCSSVar('--c-royal') || '#2A4DD0';

  ctx.clearRect(0, 0, width, height);

  const values = series.map((s) => s.value);
  const max = opts.maxOverride || Math.max(1, ...values);
  const paddingX = 8;
  const paddingY = 12;
  const chartW = width - paddingX * 2;
  const chartH = height - paddingY * 2;
  const gap = 4;
  const barW = (chartW - gap * (series.length - 1)) / series.length;

  series.forEach((s, i) => {
    const barH = chartH * Math.min(1, s.value / max);
    const x = paddingX + i * (barW + gap);
    const y = paddingY + (chartH - barH);
    const r = Math.min(4, barW / 2);
    ctx.beginPath();
    ctx.moveTo(x, y + barH);
    ctx.lineTo(x, y + r);
    ctx.arcTo(x, y, x + r, y, r);
    ctx.lineTo(x + barW - r, y);
    ctx.arcTo(x + barW, y, x + barW, y + r, r);
    ctx.lineTo(x + barW, y + barH);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
  });
}

/** Convenience wrapper: builds a labeled chart card body (canvas + legend row). */
export function chartCanvas(height = 120) {
  const canvas = document.createElement('canvas');
  canvas.style.display = 'block';
  canvas.style.width = '100%';
  canvas.style.height = `${height}px`;
  return canvas;
}
