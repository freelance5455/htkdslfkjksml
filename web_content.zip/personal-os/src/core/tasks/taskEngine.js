/**
 * taskEngine.js — generates the unified "Today" task list.
 * Tasks are NOT a separate store — they are a derived view over `habits`
 * (and, in future modules, goals), so there is one source of truth and
 * no duplicated completion logic between Dashboard and Discipline.
 */

import { getTodaySnapshot, toggleHabitLog } from '../../modules/discipline/habits/habitsService.js';
import { todayISO } from '../utils/dateUtils.js';

const DOMAIN_ICON = {
  body: 'body',
  mind: 'mind',
  discipline: 'discipline',
  presence: 'presence',
};

/** Returns today's tasks as a flat, render-ready list. */
export async function getTodayTasks() {
  const snapshot = await getTodaySnapshot();

  return snapshot.habits.map(({ habit, completedToday, completedThisWeek, streak }) => {
    const isWeekly = habit.frequency === 'weekly';
    const done = isWeekly ? completedThisWeek : completedToday;
    return {
      id: habit.id,
      label: habit.name,
      domain: habit.domain,
      icon: DOMAIN_ICON[habit.domain] || 'discipline',
      frequency: habit.frequency,
      done,
      streak,
      habit,
    };
  });
}

export async function completeTask(task, completed) {
  await toggleHabitLog(task.habit, todayISO(), completed);
}

export async function taskCompletionSummary() {
  const tasks = await getTodayTasks();
  const done = tasks.filter((t) => t.done).length;
  return { done, total: tasks.length, tasks };
}
