/**
 * achievements.js — declarative achievement list + evaluator.
 * Each achievement has a `key`, display info, and a `check(ctx)` predicate.
 * ctx gives read access to aggregated data needed for evaluation.
 */

import { put, getAll, newId, todayISO } from '../storage/storageService.js';
import { emit } from '../utils/eventBus.js';

function daysAgoISO(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

async function currentStreak(storeName, dateField = 'date') {
  const all = await getAll(storeName);
  const dates = new Set(all.map((r) => r[dateField]));
  let streak = 0;
  let cursor = new Date();
  while (dates.has(cursor.toISOString().slice(0, 10))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

export const ACHIEVEMENTS = [
  {
    key: 'streak_7',
    title: '7-Day Streak',
    description: 'Logged a habit 7 days in a row.',
    icon: '🔥',
    check: async () => (await currentStreak('habitLogs')) >= 7,
  },
  {
    key: 'anki_century',
    title: 'Anki Century',
    description: 'Reviewed 100+ cards in a single day.',
    icon: '🧠',
    check: async () => {
      const logs = await getAll('ankiLogs');
      return logs.some((l) => l.cardsReviewed >= 100);
    },
  },
  {
    key: 'glowup_month1',
    title: 'Glow-Up: Month 1 Complete',
    description: '30 days of skincare logging since you started.',
    icon: '✨',
    check: async () => {
      const logs = await getAll('skincareLogs');
      const uniqueDays = new Set(logs.map((l) => l.date));
      return uniqueDays.size >= 30;
    },
  },
  {
    key: 'consistency_king',
    title: 'Consistency King',
    description: '4 weeks of habits at 90%+ completion.',
    icon: '👑',
    check: async () => {
      const logs = await getAll('habitLogs');
      const habits = await getAll('habits');
      if (habits.length === 0) return false;
      const last28Start = daysAgoISO(28);
      const recent = logs.filter((l) => l.date >= last28Start && l.completed);
      const expected = habits.length * 28;
      return expected > 0 && recent.length / expected >= 0.9;
    },
  },
  {
    key: 'first_weekly_review',
    title: 'Reflective Practice',
    description: 'Completed your first Sunday weekly review.',
    icon: '📝',
    check: async () => (await getAll('weeklyReviews')).length >= 1,
  },
];

export async function checkAchievements() {
  const unlocked = await getAll('achievements');
  const unlockedKeys = new Set(unlocked.map((a) => a.key));
  const newlyUnlocked = [];

  for (const achievement of ACHIEVEMENTS) {
    if (unlockedKeys.has(achievement.key)) continue;
    const passed = await achievement.check();
    if (passed) {
      await put('achievements', {
        id: newId(),
        key: achievement.key,
        unlockedAt: todayISO(),
      });
      newlyUnlocked.push(achievement);
    }
  }

  newlyUnlocked.forEach((a) => emit('achievement:unlocked', a));
  return newlyUnlocked;
}

export async function getUnlockedAchievements() {
  const unlocked = await getAll('achievements');
  const byKey = new Map(unlocked.map((u) => [u.key, u]));
  return ACHIEVEMENTS.map((def) => ({
    ...def,
    unlocked: byKey.has(def.key),
    unlockedAt: byKey.get(def.key)?.unlockedAt ?? null,
  }));
}
