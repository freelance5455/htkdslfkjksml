/**
 * xpEngine.js — cross-cutting XP system.
 * Listens on the event bus for domain events and awards XP,
 * completely decoupled from Body/Mind/Discipline/Presence internals.
 * Adding a 5th module later needs zero changes here.
 */

import { on, emit } from '../utils/eventBus.js';
import { put, getAll, newId, todayISO } from '../storage/storageService.js';
import { checkAchievements } from './achievements.js';

export const XP_RULES = {
  'habit:completed': 8,
  'routine:completed': 10,
  'skincare:completed': 10,
  'workout:completed': 15,
  'anki:logged': 10,
  'study:blockCompleted': 15,
  'weeklyReview:completed': 25,
  'nutrition:logged': 5,
  'confidence:logged': 5,
};

/** XP required to go from `level` to `level + 1`. */
export function xpForLevel(level) {
  return Math.round(100 * Math.pow(level, 1.4));
}

export function levelFromTotalXP(totalXP) {
  let level = 1;
  let remaining = totalXP;
  while (remaining >= xpForLevel(level)) {
    remaining -= xpForLevel(level);
    level += 1;
  }
  return { level, xpIntoLevel: remaining, xpForNextLevel: xpForLevel(level) };
}

export async function getTotalXP() {
  const ledger = await getAll('xpLedger');
  return ledger.reduce((sum, entry) => sum + entry.amount, 0);
}

export async function awardXP(domain, reason, amount = null) {
  const xpAmount = amount ?? XP_RULES[reason] ?? 5;
  await put('xpLedger', {
    id: newId(),
    date: todayISO(),
    domain,
    reason,
    amount: xpAmount,
  });
  const totalXP = await getTotalXP();
  emit('xp:awarded', { amount: xpAmount, reason, totalXP });
  await checkAchievements();
  return totalXP;
}

/** Wire up listeners once at app boot. */
export function initXPEngine() {
  Object.keys(XP_RULES).forEach((eventName) => {
    const [domain] = eventName.split(':');
    on(eventName, () => awardXP(domain, eventName));
  });
}
