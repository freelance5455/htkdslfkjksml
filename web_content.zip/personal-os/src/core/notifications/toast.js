/**
 * toast.js — lightweight toast/notification renderer.
 * Subscribes to xp:awarded and achievement:unlocked automatically,
 * and exposes showToast() for any module to call directly.
 */

import { on } from '../utils/eventBus.js';

let stackEl = null;

function ensureStack() {
  if (stackEl) return stackEl;
  stackEl = document.createElement('div');
  stackEl.className = 'toast-stack';
  document.body.appendChild(stackEl);
  return stackEl;
}

export function showToast(message, { variant = 'default', duration = 3200 } = {}) {
  const stack = ensureStack();
  const el = document.createElement('div');
  el.className = `toast ${variant === 'xp' ? 'toast--xp' : ''} ${variant === 'achievement' ? 'toast--achievement' : ''}`;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity 200ms ease';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 200);
  }, duration);
}

export function initToastListeners() {
  on('xp:awarded', ({ amount }) => {
    showToast(`+${amount} XP`, { variant: 'xp', duration: 1800 });
  });
  on('achievement:unlocked', (achievement) => {
    showToast(`${achievement.icon} Achievement unlocked: ${achievement.title}`, {
      variant: 'achievement',
      duration: 4000,
    });
  });
}
