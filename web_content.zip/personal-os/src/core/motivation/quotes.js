/**
 * motivation.js — daily quotes + the user's editable "Why I started" vision.
 * The vision text is stored via the existing settings key/value store
 * (core/storage/storageService.js) rather than a new object store,
 * keeping the schema lean.
 */

import { getSetting, setSetting } from '../storage/storageService.js';

export const AFFIRMATIONS = [
  'Discipline today is the sharp jawline, the cleared mind, and the calm presence tomorrow.',
  'You already have the foundation — the work now is refinement, not repair.',
  'Small consistent actions compound. Show up for today\'s version of the plan.',
  'Alhamdulillah for another day to build. Make it count.',
  'Confidence is the byproduct of kept promises to yourself.',
  'The body reveals what the discipline builds in private.',
  'Every Anki card reviewed today is a patient served better tomorrow.',
  'You don\'t need motivation. You need the next small habit, done.',
  'Consistency compounds quietly, then all at once.',
  'Privacy is power — let the results speak when they\'re ready.',
];

const VISION_KEY = 'motivation.whyIStarted';
const DEFAULT_VISION =
  'Tap to write why you started — your MBBS goal, SMEA mission, or the version of yourself you\'re building.';

export function getDailyAffirmation(date = new Date()) {
  const dayIndex = Math.floor(date.getTime() / (1000 * 60 * 60 * 24));
  return AFFIRMATIONS[dayIndex % AFFIRMATIONS.length];
}

export async function getVisionText() {
  return getSetting(VISION_KEY, DEFAULT_VISION);
}

export async function setVisionText(text) {
  return setSetting(VISION_KEY, text);
}

export { DEFAULT_VISION };
