/**
 * router.js — tiny hash router. Hash-based so it works from a plain
 * file:// or static host with zero server config, and survives PWA
 * install/offline reloads without any rewrite rules.
 */

const routes = new Map();
let rootEl = null;
let currentPath = null;

export function registerRoute(path, renderFn) {
  routes.set(path, renderFn);
}

export function navigate(path) {
  window.location.hash = path;
}

async function render() {
  const path = window.location.hash.replace('#', '') || '/';
  if (path === currentPath) return;
  currentPath = path;

  const renderFn = routes.get(path) || routes.get('/');
  rootEl.innerHTML = '';
  await renderFn(rootEl);
  window.scrollTo(0, 0);
  document.dispatchEvent(new CustomEvent('route:changed', { detail: { path } }));
}

export function initRouter(mountEl) {
  rootEl = mountEl;
  window.addEventListener('hashchange', render);
  render();
}

export function currentRoute() {
  return currentPath;
}
