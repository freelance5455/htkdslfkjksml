/**
 * eventBus.js — minimal pub/sub so modules can fire events ("habit:completed")
 * without knowing anything about XP, achievements, or toasts.
 */

const listeners = new Map();

export function on(eventName, handler) {
  if (!listeners.has(eventName)) listeners.set(eventName, new Set());
  listeners.get(eventName).add(handler);
  return () => listeners.get(eventName).delete(handler);
}

export function emit(eventName, payload) {
  (listeners.get(eventName) || new Set()).forEach((handler) => {
    try {
      handler(payload);
    } catch (err) {
      console.error(`[eventBus] handler for "${eventName}" threw:`, err);
    }
  });
}
