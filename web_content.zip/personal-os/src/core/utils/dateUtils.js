export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export function isoDaysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

export function startOfWeekISO(date = new Date()) {
  const d = new Date(date);
  const day = d.getDay(); // 0 = Sunday
  d.setDate(d.getDate() - day);
  return d.toISOString().slice(0, 10);
}

export function formatFriendlyDate(iso) {
  const d = new Date(`${iso}T00:00:00`);
  return d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}

export function dayLabel(iso) {
  if (iso === todayISO()) return 'Today';
  if (iso === isoDaysAgo(1)) return 'Yesterday';
  return formatFriendlyDate(iso);
}

/** Build an array of the last N date strings (oldest first), inclusive of today. */
export function lastNDates(n) {
  const dates = [];
  for (let i = n - 1; i >= 0; i -= 1) {
    dates.push(isoDaysAgo(i));
  }
  return dates;
}
