/**
 * scoreEngine.js — turns raw logs into 0-100 performance scores.
 * Pure, storage-read-only, no side effects — safe to call as often as needed
 * (e.g. every Dashboard render) without polluting the ledger.
 */

import { getAll } from '../storage/storageService.js';
import { lastNDates, isoDaysAgo } from '../utils/dateUtils.js';

const WINDOW_DAYS = 7; // scores reflect a rolling 7-day window

function pct(hit, total) {
  if (total === 0) return 0;
  return Math.round((hit / total) * 100);
}

/** Health Score: skincare consistency + water/nutrition logging + sleep proxy via routines. */
export async function computeHealthScore() {
  const dates = lastNDates(WINDOW_DAYS);
  const skincare = await getAll('skincareLogs');
  const nutrition = await getAll('nutritionLogs');

  const skincareDates = new Set(skincare.map((s) => s.date));
  const skincareHit = dates.filter((d) => skincareDates.has(d)).length;

  const nutritionByDate = new Map(nutrition.map((n) => [n.date, n]));
  const hydrationHit = dates.filter((d) => {
    const n = nutritionByDate.get(d);
    return n && n.waterMl >= 3000;
  }).length;

  const skincarePct = pct(skincareHit, dates.length);
  const hydrationPct = pct(hydrationHit, dates.length);

  return Math.round(skincarePct * 0.6 + hydrationPct * 0.4);
}

/** Study Score: study session frequency + Anki streak consistency. */
export async function computeStudyScore() {
  const dates = lastNDates(WINDOW_DAYS);
  const sessions = await getAll('studySessions');
  const anki = await getAll('ankiLogs');

  const sessionDates = new Set(sessions.map((s) => s.date));
  const ankiDates = new Set(anki.map((a) => a.date));

  const sessionHit = dates.filter((d) => sessionDates.has(d)).length;
  const ankiHit = dates.filter((d) => ankiDates.has(d)).length;

  return Math.round(pct(sessionHit, dates.length) * 0.5 + pct(ankiHit, dates.length) * 0.5);
}

/** Fitness Score: workout frequency vs. the 3-4x/week target from the blueprint. */
export async function computeFitnessScore() {
  const dates = lastNDates(WINDOW_DAYS);
  const workouts = await getAll('workoutLogs');
  const workoutDatesThisWindow = new Set(
    workouts.filter((w) => dates.includes(w.date) && w.completed).map((w) => w.date)
  );
  const target = 4; // days/week target from the fitness plan
  return Math.min(100, Math.round((workoutDatesThisWindow.size / target) * 100));
}

/** Confidence Score: confidence-practice logging frequency. */
export async function computeConfidenceScore() {
  const dates = lastNDates(WINDOW_DAYS);
  const logs = await getAll('confidenceLogs');
  const logDates = new Set(logs.map((l) => l.date));
  const hit = dates.filter((d) => logDates.has(d)).length;
  return pct(hit, dates.length);
}

/** Life Score: weighted composite of all four domain scores. */
export async function computeLifeScore() {
  const [health, study, fitness, confidence] = await Promise.all([
    computeHealthScore(),
    computeStudyScore(),
    computeFitnessScore(),
    computeConfidenceScore(),
  ]);
  const life = Math.round(health * 0.3 + study * 0.3 + fitness * 0.25 + confidence * 0.15);
  return { life, health, study, fitness, confidence };
}

/** Daily XP totals for the last N days, for the XP growth chart. */
export async function dailyXPSeries(days = 14) {
  const ledger = await getAll('xpLedger');
  const dates = lastNDates(days);
  const byDate = new Map(dates.map((d) => [d, 0]));
  ledger.forEach((entry) => {
    if (byDate.has(entry.date)) {
      byDate.set(entry.date, byDate.get(entry.date) + entry.amount);
    }
  });
  return dates.map((d) => ({ date: d, value: byDate.get(d) || 0 }));
}

/** Habit consistency series: % of habits completed per day, last N days. */
export async function habitConsistencySeries(days = 14) {
  const [habits, logs] = await Promise.all([getAll('habits'), getAll('habitLogs')]);
  const dates = lastNDates(days);
  const dailyHabits = habits.filter((h) => h.frequency === 'daily');

  return dates.map((date) => {
    if (dailyHabits.length === 0) return { date, value: 0 };
    const completedCount = dailyHabits.filter((h) =>
      logs.some((l) => l.habitId === h.id && l.date === date && l.completed)
    ).length;
    return { date, value: Math.round((completedCount / dailyHabits.length) * 100) };
  });
}

/** Study hours per day, last N days (from studySessions.durationMin). */
export async function studyHoursSeries(days = 14) {
  const sessions = await getAll('studySessions');
  const dates = lastNDates(days);
  const byDate = new Map(dates.map((d) => [d, 0]));
  sessions.forEach((s) => {
    if (byDate.has(s.date)) {
      byDate.set(s.date, byDate.get(s.date) + (s.durationMin || 0) / 60);
    }
  });
  return dates.map((d) => ({ date: d, value: Math.round(byDate.get(d) * 10) / 10 }));
}

/** Weekly summary: this week vs last week, for the monthly/weekly progress bars. */
export async function weeklyProgressSummary() {
  const thisWeekDates = lastNDates(7);
  const lastWeekDates = lastNDates(14).slice(0, 7);
  const logs = await getAll('habitLogs');

  const countCompleted = (dates) =>
    logs.filter((l) => dates.includes(l.date) && l.completed).length;

  const thisWeek = countCompleted(thisWeekDates);
  const lastWeek = countCompleted(lastWeekDates);

  return { thisWeek, lastWeek, deltaPct: lastWeek === 0 ? null : Math.round(((thisWeek - lastWeek) / lastWeek) * 100) };
}

export { isoDaysAgo };
