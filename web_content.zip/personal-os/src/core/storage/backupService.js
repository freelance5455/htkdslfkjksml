/**
 * backupService.js — full export/import of all app data.
 * Export produces one JSON file the user can save anywhere
 * (Drive, email to self, USB) since this app has no server.
 */

import { getStoreNames, DB_VERSION } from './db.js';
import { getAll, put } from './storageService.js';

export async function exportAllData() {
  const stores = getStoreNames();
  const data = {};
  for (const storeName of stores) {
    data[storeName] = await getAll(storeName);
  }
  return {
    app: 'personalOS',
    schemaVersion: DB_VERSION,
    exportedAt: new Date().toISOString(),
    data,
  };
}

export async function downloadBackup() {
  const backup = await exportAllData();
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const dateStamp = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `personal-os-backup-${dateStamp}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/**
 * Import a backup file. `mode`:
 *  - 'merge'     -> put() each record, overwriting only matching ids
 *  - 'overwrite' -> same effect at the record level (put is upsert either way);
 *                   true wipe-then-restore is intentionally not offered here
 *                   to avoid accidental data loss from a bad file.
 */
export async function importBackupFile(file) {
  const text = await file.text();
  const parsed = JSON.parse(text);

  if (!parsed?.data || parsed.app !== 'personalOS') {
    throw new Error('This file is not a recognized Personal OS backup.');
  }

  if (parsed.schemaVersion > DB_VERSION) {
    throw new Error('This backup was made with a newer app version. Please update the app first.');
  }

  let restoredCount = 0;
  for (const [storeName, records] of Object.entries(parsed.data)) {
    for (const record of records) {
      await put(storeName, record);
      restoredCount += 1;
    }
  }
  return restoredCount;
}
