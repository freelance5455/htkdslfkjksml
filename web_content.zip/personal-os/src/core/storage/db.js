/**
 * db.js — IndexedDB connection + versioned schema for Personal OS.
 *
 * All app data lives here. Nothing is ever sent over a network.
 * Every schema change bumps DB_VERSION and adds a migration branch
 * inside onupgradeneeded, so multi-year data survives upgrades.
 */

const DB_NAME = 'personalOS';
const DB_VERSION = 1;

/** Object store definitions: name -> keyPath/indexes */
const STORE_DEFS = {
  habits:          { keyPath: 'id', indexes: ['domain'] },
  habitLogs:       { keyPath: 'id', indexes: ['habitId', 'date'] },
  routines:        { keyPath: 'id', indexes: ['type', 'date'] },
  skincareLogs:    { keyPath: 'id', indexes: ['date', 'period'] },
  nutritionLogs:   { keyPath: 'id', indexes: ['date'] },
  workoutLogs:     { keyPath: 'id', indexes: ['date'] },
  bodyMetrics:     { keyPath: 'id', indexes: ['date'] },
  studySessions:   { keyPath: 'id', indexes: ['date', 'subject'] },
  ankiLogs:        { keyPath: 'id', indexes: ['date'] },
  notesEntries:    { keyPath: 'id', indexes: ['date', 'type'] },
  weeklyReviews:   { keyPath: 'id', indexes: ['weekStartDate'] },
  confidenceLogs:  { keyPath: 'id', indexes: ['date'] },
  xpLedger:        { keyPath: 'id', indexes: ['date', 'domain'] },
  achievements:    { keyPath: 'id', indexes: ['key'] },
  settings:        { keyPath: 'key' },
};

let dbPromise = null;

function openDB() {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;

      // --- v1: create all stores ---
      Object.entries(STORE_DEFS).forEach(([name, def]) => {
        if (!db.objectStoreNames.contains(name)) {
          const store = db.createObjectStore(name, { keyPath: def.keyPath });
          (def.indexes || []).forEach((idx) => {
            store.createIndex(idx, idx, { unique: false });
          });
        }
      });

      // Future migrations go here, gated by event.oldVersion:
      // if (event.oldVersion < 2) { ... }
    };

    request.onsuccess = (event) => resolve(event.target.result);
    request.onerror = (event) => reject(event.target.error);
    request.onblocked = () => console.warn('[db] upgrade blocked by another open tab');
  });

  return dbPromise;
}

export function getStoreNames() {
  return Object.keys(STORE_DEFS);
}

export async function withStore(storeName, mode, callback) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, mode);
    const store = tx.objectStore(storeName);
    const result = callback(store);

    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export function requestToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export { DB_NAME, DB_VERSION };
