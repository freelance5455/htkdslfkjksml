/**
 * storageService.js — generic get/set/query API on top of db.js.
 * Every module (Body, Mind, Discipline, Presence) talks to storage
 * exclusively through this file. No module should import db.js directly.
 */

import { withStore, requestToPromise } from './db.js';

function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

export function newId() {
  return uid();
}

export function todayISO() {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD
}

/** Insert or update a record. Adds createdAt/updatedAt automatically. */
export async function put(storeName, record) {
  const now = new Date().toISOString();
  const withMeta = {
    ...record,
    id: record.id || uid(),
    createdAt: record.createdAt || now,
    updatedAt: now,
  };
  await withStore(storeName, 'readwrite', (store) => store.put(withMeta));
  return withMeta;
}

export async function get(storeName, id) {
  return withStore(storeName, 'readonly', (store) => requestToPromise(store.get(id)));
}

export async function getAll(storeName) {
  return withStore(storeName, 'readonly', (store) => requestToPromise(store.getAll()));
}

export async function remove(storeName, id) {
  return withStore(storeName, 'readwrite', (store) => store.delete(id));
}

export async function getByIndex(storeName, indexName, value) {
  return withStore(storeName, 'readonly', (store) =>
    requestToPromise(store.index(indexName).getAll(value))
  );
}

/** Get all records whose `date` field falls within [startISO, endISO] inclusive. */
export async function getByDateRange(storeName, startISO, endISO) {
  const all = await getAll(storeName);
  return all.filter((r) => r.date >= startISO && r.date <= endISO);
}

/** Simple settings key/value helpers (theme, onboarding flags, etc.) */
export async function getSetting(key, fallback = null) {
  const rec = await get('settings', key);
  return rec ? rec.value : fallback;
}

export async function setSetting(key, value) {
  return withStore('settings', 'readwrite', (store) => store.put({ key, value }));
}
