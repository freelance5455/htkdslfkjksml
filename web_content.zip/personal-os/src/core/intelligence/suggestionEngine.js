/**
 * suggestionEngine.js — simple rule-based "what to focus on today" system.
 * No ML, fully deterministic and explainable — each rule reads current
 * scores/habit state and produces a suggestion object if its condition fires.
 * Rules are ordered by priority; the Dashboard shows the top 1-3.
 */

import { computeLifeScore } from '../scoring/scoreEngine.js';
import { habitsAtRiskToday, getTodaySnapshot } from '../../modules/discipline/habits/habitsService.js';
import { getAll } from '../storage/storageService.js';
import { lastNDates } from '../utils/dateUtils.js';

const SCORE_LABELS = {
  study: 'study consistency',
  fitness: 'fitness consistency',
  health: 'skin & health routine',
  confidence: 'confidence practice',
};

async function studyDropRule() {
  const dates = lastNDates(7);
  const sessions = await getAll('studySessions');
  const sessionDates = new Set(sessions.map((s) => s.date));
  const hitThisWeek = dates.filter((d) => sessionDates.has(d)).length;
  if (hitThisWeek <= 2) {
    return {
      priority: 90,
      icon: '📚',
      message: 'Your study consistency dropped this week → prioritize 2 focused Pomodoro sessions today.',
    };
  }
  return null;
}

async function lowScoreRule(scores) {
  const entries = Object.entries(SCORE_LABELS)
    .map(([key, label]) => ({ key, label, value: scores[key] }))
    .sort((a, b) => a.value - b.value);

  const lowest = entries[0];
  if (lowest.value < 50) {
    return {
      priority: 80,
      icon: '⚠️',
      message: `Your ${lowest.label} is at ${lowest.value}/100 — the lowest of your four scores. Give it deliberate attention today.`,
    };
  }
  return null;
}

async function streakRiskRule() {
  const atRisk = await habitsAtRiskToday();
  if (atRisk.length === 0) return null;
  const top = atRisk.sort((a, b) => b.streak - a.streak)[0];
  return {
    priority: 95,
    icon: '🔥',
    message: `"${top.habit.name}" has a ${top.streak}-day streak on the line — log it today before you lose it.`,
  };
}

async function missedHabitsRule() {
  const snapshot = await getTodaySnapshot();
  const missed = snapshot.habits.filter((h) => h.habit.frequency === 'daily' && !h.completedToday);
  if (missed.length >= 3) {
    return {
      priority: 60,
      icon: '✅',
      message: `${missed.length} daily habits are still open today. Start with the easiest one to build momentum.`,
    };
  }
  return null;
}

async function allGoodRule() {
  return {
    priority: 10,
    icon: '🌱',
    message: 'Everything is on track. Stay consistent — this is the boring middle part that produces results.',
  };
}

export async function getTodaySuggestions(limit = 3) {
  const scores = await computeLifeScore();
  const rules = [studyDropRule(), lowScoreRule(scores), streakRiskRule(), missedHabitsRule()];
  const results = (await Promise.all(rules)).filter(Boolean);

  if (results.length === 0) {
    results.push(await allGoodRule());
  }

  return results.sort((a, b) => b.priority - a.priority).slice(0, limit);
}
