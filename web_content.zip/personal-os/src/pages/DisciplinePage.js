/**
 * DisciplinePage.js — full Habit management, Routines, Weekly Review.
 * Habit logic is entirely delegated to habitsService.js (no duplication
 * with Dashboard, which uses the same service).
 */
import { el, card, sectionHeader, checklistItem, button, xpBar, textareaInput, emptyState } from '../components/ui.js';
import { icon } from '../components/icons.js';
import {
  getAllHabits, habitStreak, habitCompletionPct, createHabit, FREQUENCY,
} from '../modules/discipline/habits/habitsService.js';
import {
  getRoutineForToday, toggleRoutineStep,
} from '../modules/discipline/routines/routinesService.js';
import {
  submitWeeklyReview, getReviewHistory, hasReviewedThisWeek,
} from '../modules/discipline/weeklyReview/weeklyReviewService.js';
import { showToast } from '../core/notifications/toast.js';

let activeTab = 'habits';
let habitFilter = FREQUENCY.DAILY;

function tabRow(root) {
  const row = el('div', 'tab-row');
  [
    { key: 'habits', label: 'Habits' },
    { key: 'routines', label: 'Routines' },
    { key: 'review', label: 'Weekly Review' },
  ].forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${activeTab === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', async () => { activeTab = key; await rerender(root); });
    row.append(pill);
  });
  return row;
}

async function renderHabitsTab(page, root) {
  const filterRow = el('div', 'tab-row');
  [
    { key: FREQUENCY.DAILY, label: 'Daily' },
    { key: FREQUENCY.WEEKLY, label: 'Weekly' },
    { key: FREQUENCY.CUSTOM, label: 'Custom' },
  ].forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${habitFilter === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', async () => { habitFilter = key; await rerender(root); });
    filterRow.append(pill);
  });
  page.append(filterRow);

  const all = await getAllHabits();
  const filtered = all.filter((h) => h.frequency === habitFilter);

  if (filtered.length === 0) {
    page.append(emptyState('No habits here yet', 'Add one below.'));
  } else {
    for (const h of filtered) {
      const streak = await habitStreak(h);
      const pct = await habitCompletionPct(h);
      page.append(card([
        el('div', 'flex justify-between items-center', [
          el('span', null, h.name),
          streak > 0 ? el('span', 'streak-pill', [icon('flame'), String(streak)]) : null,
        ]),
        el('div', 'mt-4', xpBar(pct)),
        el('p', 'text-xs text-dim mt-1', `${pct}% consistency · ${h.domain}`),
      ]));
    }
  }

  page.append(el('div', 'mt-3', button('+ Add habit', { variant: 'ghost', block: true, onClick: async () => {
    const name = window.prompt('Habit name:');
    if (!name) return;
    await createHabit({ name, frequency: habitFilter, domain: 'discipline' });
    await rerender(root);
  } })));
}

async function renderRoutinesTab(page, root) {
  const morning = await getRoutineForToday('morning');
  const evening = await getRoutineForToday('evening');

  page.append(sectionHeader('Morning', 'Routine'));
  page.append(card(morning.steps.map((s, i) => checklistItem(s.label, s.done, async (checked) => {
    await toggleRoutineStep('morning', i, checked);
    await rerender(root);
  }))));

  page.append(sectionHeader('Evening', 'Routine'));
  page.append(card(evening.steps.map((s, i) => checklistItem(s.label, s.done, async (checked) => {
    await toggleRoutineStep('evening', i, checked);
    await rerender(root);
  }))));
}

async function renderReviewTab(page, root) {
  const alreadyDone = await hasReviewedThisWeek();
  const history = await getReviewHistory(6);

  page.append(sectionHeader(null, 'Sunday reflection'));
  if (alreadyDone) {
    page.append(card([el('p', null, 'You\'ve already completed this week\'s review. Nice work.')]));
  } else {
    const wins = textareaInput({ placeholder: 'Wins this week' });
    const misses = textareaInput({ placeholder: 'What slipped' });
    const adjustments = textareaInput({ placeholder: 'Adjustments for next week' });
    page.append(card([
      wins, el('div', 'mt-3', misses), el('div', 'mt-3', adjustments),
      el('div', 'mt-3', button('Submit review', { block: true, onClick: async () => {
        await submitWeeklyReview({ wins: wins.value, misses: misses.value, adjustments: adjustments.value });
        showToast('Weekly review saved — nice consistency.');
        await rerender(root);
      } })),
    ]));
  }

  page.append(sectionHeader(null, 'History'));
  page.append(card(
    history.length === 0
      ? [emptyState('No reviews yet', 'Complete your first one above.')]
      : history.map((r) => el('div', 'checklist-item', [
          el('span', 'checklist-item__label', r.weekStartDate),
          el('span', 'text-xs text-dim', `Life ${r.metricsSnapshot?.life ?? '—'}`),
        ]))
  ));
}

async function rerender(root) {
  root.innerHTML = '';
  await DisciplinePage(root);
}

export async function DisciplinePage(root) {
  const page = el('div', 'page');
  page.append(el('h1', 'page-title', 'Discipline'), el('p', 'page-subtitle', 'Habits · Routines · Weekly review'));
  page.append(tabRow(root));

  if (activeTab === 'habits') await renderHabitsTab(page, root);
  else if (activeTab === 'routines') await renderRoutinesTab(page, root);
  else await renderReviewTab(page, root);

  root.appendChild(page);
}
