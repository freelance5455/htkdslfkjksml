import {
  el, card, sectionHeader, checklistItem, xpBar, button,
  progressRing, emptyState,
} from '../components/ui.js';
import { icon } from '../components/icons.js';
import { chartCanvas, renderLineChart, renderBarChart } from '../components/charts/canvasChart.js';
import { getTotalXP, levelFromTotalXP } from '../core/xp/xpEngine.js';
import {
  computeLifeScore, dailyXPSeries, habitConsistencySeries,
  studyHoursSeries, weeklyProgressSummary,
} from '../core/scoring/scoreEngine.js';
import { getTodayTasks, completeTask } from '../core/tasks/taskEngine.js';
import {
  ensureDefaultHabits, getAllHabits, habitStreak, habitCompletionPct,
  overallDailyStreak, habitsAtRiskToday, createHabit, FREQUENCY,
} from '../modules/discipline/habits/habitsService.js';
import { getDailyAffirmation, getVisionText, setVisionText } from '../core/motivation/quotes.js';
import { getTodaySuggestions } from '../core/intelligence/suggestionEngine.js';
import { getAll, todayISO } from '../core/storage/storageService.js';
import {
  actionStartPomodoro, actionLogStudySession, actionAddWorkout,
  actionLogMeal, actionMoodCheck, actionOpenJournal, actionQuickHydration,
} from '../modules/dashboard/quickActions.js';
import { dayLabel } from '../core/utils/dateUtils.js';

// Module-level UI state (which habit-frequency tab is active).
// Intentionally simple: this is view state, not app data, so it does not
// belong in IndexedDB.
let habitTabState = FREQUENCY.DAILY;

function getCSSColor(varName) {
  return getComputedStyle(document.documentElement).getPropertyValue(varName).trim() || undefined;
}

async function xpEarnedToday() {
  const ledger = await getAll('xpLedger');
  const today = todayISO();
  return ledger.filter((e) => e.date === today).reduce((sum, e) => sum + e.amount, 0);
}

function scoreTile(label, value) {
  return el('div', 'score-tile', [
    progressRing(value, 44, 4),
    el('span', 'score-tile__label', label),
  ]);
}

async function rerender(root) {
  root.innerHTML = '';
  await Dashboard(root);
}

export async function Dashboard(root) {
  await ensureDefaultHabits();

  // --- Gather all data up front (parallel reads, no waterfalling) ---
  const [
    totalXP, todaysXP, scores, tasks, allHabits, dailyStreak, atRisk,
    xpSeries, consistencySeries, studySeries, weeklySummary, vision, suggestions,
  ] = await Promise.all([
    getTotalXP(),
    xpEarnedToday(),
    computeLifeScore(),
    getTodayTasks(),
    getAllHabits(),
    overallDailyStreak(),
    habitsAtRiskToday(),
    dailyXPSeries(14),
    habitConsistencySeries(14),
    studyHoursSeries(14),
    weeklyProgressSummary(),
    getVisionText(),
    getTodaySuggestions(3),
  ]);

  const affirmation = getDailyAffirmation();
  const { level, xpIntoLevel, xpForNextLevel } = levelFromTotalXP(totalXP);
  const levelPct = (xpIntoLevel / xpForNextLevel) * 100;

  const page = el('div', 'page');

  // ============================================================
  // 1. SMART DAILY OVERVIEW
  // ============================================================
  const overviewCard = card([
    el('div', 'flex justify-between items-center', [
      el('div', 'flex items-center gap-2', [icon('flame'), el('span', null, `${dailyStreak}-day streak`)]),
      el('span', 'text-xs text-dim', `LEVEL ${level}`),
    ]),
    el('div', 'mt-4', xpBar(levelPct)),
    el('div', 'flex justify-between mt-4', [
      el('span', 'text-xs text-dim', `+${todaysXP} XP today`),
      el('span', 'text-xs text-dim', `${xpIntoLevel}/${xpForNextLevel} to next level`),
    ]),
  ]);
  overviewCard.classList.add('card--glass');
  page.append(overviewCard);

  page.append(sectionHeader('Scores', 'Your five vitals'));
  page.append(
    card([
      el('div', 'flex items-center gap-3', [
        progressRing(scores.life, 64, 6),
        el('div', null, [
          el('div', 'stat-tile__value', 'Life Score'),
          el('p', 'text-dim text-xs mt-1', 'Weighted average of health, study, fitness & confidence.'),
        ]),
      ]),
    ])
  );
  const scoreGrid = el('div', 'score-grid mt-4', [
    scoreTile('Health', scores.health),
    scoreTile('Study', scores.study),
    scoreTile('Fitness', scores.fitness),
    scoreTile('Confidence', scores.confidence),
  ]);
  page.append(scoreGrid);

  // ============================================================
  // 2. INTELLIGENCE LAYER — today's focus suggestions
  // ============================================================
  page.append(sectionHeader('Focus', "Today's suggestions"));
  page.append(
    card(
      suggestions.map((s) =>
        el('div', 'suggestion-item', [
          el('span', 'suggestion-item__icon', s.icon),
          el('span', 'suggestion-item__text', s.message),
        ])
      )
    )
  );

  // Streak-protection warning (only shown when a habit is actually at risk)
  if (atRisk.length > 0) {
    page.append(
      el('div', 'mt-4', el('div', 'warning-banner', [
        icon('flame'),
        el('span', null,
          `${atRisk.length} habit${atRisk.length > 1 ? 's' : ''} with a streak on the line today — log ${atRisk.length > 1 ? 'them' : 'it'} before the day ends.`
        ),
      ]))
    );
  }

  // ============================================================
  // 3. DAILY TASK ENGINE
  // ============================================================
  const doneCount = tasks.filter((t) => t.done).length;
  page.append(sectionHeader(`${doneCount}/${tasks.length} done`, "Today's tasks"));
  page.append(
    card(
      tasks.length === 0
        ? [emptyState('No tasks yet', 'Add a habit below to populate today\'s tasks.')]
        : tasks.map((task) =>
            checklistItem(
              `${task.label}${task.streak > 0 ? ` · ${task.streak}d streak` : ''}`,
              task.done,
              async (nextChecked) => {
                await completeTask(task, nextChecked);
                await rerender(root);
              }
            )
          )
    )
  );

  // ============================================================
  // 4. HABIT TRACKING SYSTEM (daily / weekly / custom tabs)
  // ============================================================
  page.append(sectionHeader(null, 'Habit tracker'));
  const tabRow = el('div', 'tab-row');
  [
    { key: FREQUENCY.DAILY, label: 'Daily' },
    { key: FREQUENCY.WEEKLY, label: 'Weekly' },
    { key: FREQUENCY.CUSTOM, label: 'Custom' },
  ].forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${habitTabState === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', async () => {
      habitTabState = key;
      await rerender(root);
    });
    tabRow.append(pill);
  });
  page.append(tabRow);

  const filteredHabits = allHabits.filter((h) => h.frequency === habitTabState);
  if (filteredHabits.length === 0) {
    page.append(emptyState('No habits in this category yet', 'Use "Add habit" below.'));
  } else {
    for (const h of filteredHabits) {
      const streak = await habitStreak(h);
      const completionPct = await habitCompletionPct(h);
      page.append(
        card([
          el('div', 'flex justify-between items-center', [
            el('span', null, h.name),
            streak > 0 ? el('span', 'streak-pill', [icon('flame'), String(streak)]) : null,
          ]),
          el('div', 'mt-4', xpBar(completionPct)),
          el('div', 'flex justify-between mt-1', [
            el('span', 'text-xs text-dim', `${completionPct}% consistency`),
          ]),
        ])
      );
    }
  }
  page.append(
    el('div', 'mt-3', button('+ Add habit', {
      variant: 'ghost',
      block: true,
      onClick: async () => {
        const name = window.prompt('Habit name:');
        if (!name) return;
        await createHabit({ name, frequency: habitTabState, domain: 'discipline' });
        await rerender(root);
      },
    }))
  );

  // ============================================================
  // 5. PROGRESS VISUALIZATION
  // ============================================================
  page.append(sectionHeader(null, 'Progress'));

  const weeklyDelta = weeklySummary.deltaPct;
  const weeklyPct = weeklySummary.lastWeek === 0
    ? 100
    : Math.min(100, (weeklySummary.thisWeek / Math.max(weeklySummary.lastWeek, 1)) * 100);
  page.append(
    card([
      el('div', 'chart-card__header', [
        el('span', 'chart-card__title', 'This week vs last week'),
        el('span', 'chart-card__meta', weeklyDelta === null ? '—' : `${weeklyDelta > 0 ? '+' : ''}${weeklyDelta}%`),
      ]),
      xpBar(weeklyPct),
      el('p', 'text-xs text-dim mt-1', `${weeklySummary.thisWeek} habit completions this week vs ${weeklySummary.lastWeek} last week`),
    ])
  );

  const xpChartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'XP growth (14 days)')])]);
  const xpCanvas = chartCanvas(100);
  xpChartCard.append(xpCanvas);
  page.append(xpChartCard);

  const consistencyChartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Habit consistency (14 days)')])]);
  const consistencyCanvas = chartCanvas(100);
  consistencyChartCard.append(consistencyCanvas);
  page.append(consistencyChartCard);

  const studyChartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Study hours / day (14 days)')])]);
  const studyCanvas = chartCanvas(100);
  studyChartCard.append(studyCanvas);
  page.append(studyChartCard);

  // ============================================================
  // 6. MOTIVATION ENGINE
  // ============================================================
  page.append(sectionHeader(null, 'Motivation'));
  page.append(card([el('p', null, `"${affirmation}"`)]));

  const visionBox = el('div', 'vision-box');
  visionBox.textContent = vision;
  visionBox.contentEditable = 'true';
  visionBox.addEventListener('blur', async () => {
    await setVisionText(visionBox.textContent.trim());
  });
  page.append(
    el('div', 'mt-3', card([
      el('span', 'text-xs text-dim', 'WHY I STARTED'),
      el('div', 'mt-1', visionBox),
    ]))
  );

  // ============================================================
  // 7. QUICK ACTIONS PANEL
  // ============================================================
  page.append(sectionHeader(null, 'Quick actions'));
  const quickGrid = el('div', 'quick-actions-grid');
  const quickActions = [
    { label: 'Pomodoro', iconName: 'timer', onClick: actionStartPomodoro },
    { label: 'Study log', iconName: 'book', onClick: actionLogStudySession },
    { label: 'Workout', iconName: 'dumbbell', onClick: actionAddWorkout },
    { label: 'Meal', iconName: 'utensils', onClick: actionLogMeal },
    { label: 'Mood', iconName: 'smile', onClick: actionMoodCheck },
    { label: 'Journal', iconName: 'notebook', onClick: actionOpenJournal },
    { label: 'Hydration', iconName: 'droplet', onClick: async () => { await actionQuickHydration(); await rerender(root); } },
  ];
  quickActions.forEach(({ label, iconName, onClick }) => {
    const btn = el('button', 'quick-action', [icon(iconName), el('span', null, label)]);
    btn.addEventListener('click', onClick);
    quickGrid.append(btn);
  });
  page.append(quickGrid);

  root.appendChild(page);

  // Charts render after mount so canvases have real layout width.
  requestAnimationFrame(() => {
    renderLineChart(xpCanvas, xpSeries, { color: getCSSColor('--c-emerald-soft') });
    renderBarChart(consistencyCanvas, consistencySeries, { maxOverride: 100, color: getCSSColor('--c-royal') });
    renderLineChart(studyCanvas, studySeries, { color: getCSSColor('--c-gold') });
  });
}
