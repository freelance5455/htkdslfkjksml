/**
 * BodyPage.js — Skin / Fitness / Nutrition tabs.
 * Each tab is backed by its own service module; this file is presentation only.
 */
import { el, card, sectionHeader, checklistItem, button, xpBar, textInput, emptyState } from '../components/ui.js';
import { icon } from '../components/icons.js';
import { chartCanvas, renderLineChart } from '../components/charts/canvasChart.js';
import {
  getRoutineForToday, toggleSkincareStep, AM_STEPS, PM_STEPS,
} from '../modules/body/skin/skinService.js';
import {
  todaysSplitFocus, logWorkout, getRecentWorkouts, logBodyMetric,
  bodyMetricsSeries, weeklyWorkoutCount,
} from '../modules/body/fitness/fitnessService.js';
import {
  getTodayNutrition, logMeal, logHydration, nutritionSeries,
  MEAL_IDEAS, FOODS_TO_EAT, FOODS_TO_AVOID, DEFAULT_TARGETS,
} from '../modules/body/nutrition/nutritionService.js';
import { showToast } from '../core/notifications/toast.js';

let activeTab = 'skin';

function tabRow(root) {
  const row = el('div', 'tab-row');
  [
    { key: 'skin', label: 'Skin' },
    { key: 'fitness', label: 'Fitness' },
    { key: 'nutrition', label: 'Nutrition' },
  ].forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${activeTab === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', async () => { activeTab = key; await rerender(root); });
    row.append(pill);
  });
  return row;
}

async function renderSkinTab(page) {
  const am = await getRoutineForToday('AM');
  const pm = await getRoutineForToday('PM');

  page.append(sectionHeader('Morning', 'AM routine'));
  page.append(card(am.steps.map((s, i) =>
    checklistItem(s.name, s.done, async (checked) => {
      await toggleSkincareStep('AM', i, checked);
      showToast(checked ? 'Step logged.' : 'Step unmarked.');
    })
  )));

  page.append(sectionHeader('Evening', 'PM routine'));
  page.append(card(pm.steps.map((s, i) =>
    checklistItem(s.name, s.done, async (checked) => {
      await toggleSkincareStep('PM', i, checked);
      showToast(checked ? 'Step logged.' : 'Step unmarked.');
    })
  )));
}

async function renderFitnessTab(page, root) {
  const focus = todaysSplitFocus();
  const recent = await getRecentWorkouts(5);
  const weeklyCount = await weeklyWorkoutCount();
  const series = await bodyMetricsSeries(30);

  page.append(sectionHeader('Today\'s split', focus.day));
  page.append(card([el('p', null, focus.focus)]));

  page.append(sectionHeader(`${weeklyCount}/4 this week`, 'Log a workout'));
  const notesInput = textInput({ placeholder: 'Exercises / notes (optional)' });
  page.append(card([
    notesInput,
    el('div', 'mt-3', button('Mark today\'s workout done', { block: true, onClick: async () => {
      await logWorkout({ splitDay: focus.focus, notes: notesInput.value });
      showToast('Workout logged.');
      await rerender(root);
    } })),
  ]));

  page.append(sectionHeader(null, 'Recent workouts'));
  page.append(card(
    recent.length === 0
      ? [emptyState('No workouts logged yet', 'Log today\'s session above.')]
      : recent.map((w) => el('div', 'checklist-item', [
          el('span', 'checklist-item__label', `${w.date} — ${w.splitDay}`),
        ]))
  ));

  page.append(sectionHeader(null, 'Body metrics'));
  const weightInput = textInput({ placeholder: 'Weight (kg)', type: 'number' });
  const bfInput = textInput({ placeholder: 'Body fat % (estimate)', type: 'number' });
  page.append(card([
    weightInput, el('div', 'mt-3', bfInput),
    el('div', 'mt-3', button('Save today\'s metrics', { variant: 'ghost', block: true, onClick: async () => {
      await logBodyMetric({
        weightKg: weightInput.value ? parseFloat(weightInput.value) : null,
        bodyFatPct: bfInput.value ? parseFloat(bfInput.value) : null,
      });
      showToast('Metrics saved.');
      await rerender(root);
    } })),
  ]));

  const chartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Body fat % trend (30 days)')])]);
  const canvas = chartCanvas(100);
  chartCard.append(canvas);
  page.append(chartCard);
  requestAnimationFrame(() => {
    const points = series.filter((s) => s.bodyFat != null).map((s) => ({ date: s.date, value: s.bodyFat }));
    if (points.length > 0) renderLineChart(canvas, points, { color: '#E0A93B' });
  });
}

async function renderNutritionTab(page, root) {
  const today = await getTodayNutrition();
  const series = await nutritionSeries(14);

  page.append(sectionHeader(`${today.caloriesLogged}/${today.caloriesTarget} kcal`, 'Today'));
  page.append(card([
    xpBar(Math.min(100, (today.caloriesLogged / today.caloriesTarget) * 100)),
    el('p', 'text-xs text-dim mt-1', `Protein: ${today.proteinG}g target ${DEFAULT_TARGETS.proteinG}g · Water: ${(today.waterMl / 1000).toFixed(2)}L / ${(DEFAULT_TARGETS.waterMl / 1000)}L`),
  ]));

  const descInput = textInput({ placeholder: 'What did you eat?' });
  const calInput = textInput({ placeholder: 'Calories', type: 'number' });
  const proteinInput = textInput({ placeholder: 'Protein (g)', type: 'number' });
  page.append(sectionHeader(null, 'Log a meal'));
  page.append(card([
    descInput, el('div', 'mt-3', calInput), el('div', 'mt-3', proteinInput),
    el('div', 'mt-3', button('Save meal', { block: true, onClick: async () => {
      if (!descInput.value) { showToast('Describe the meal first.'); return; }
      await logMeal({ description: descInput.value, calories: parseInt(calInput.value, 10) || 0, protein: parseInt(proteinInput.value, 10) || 0 });
      showToast('Meal logged.');
      await rerender(root);
    } })),
    el('div', 'mt-3', button('+250ml water', { variant: 'ghost', block: true, onClick: async () => {
      await logHydration(250);
      showToast('Hydration logged.');
      await rerender(root);
    } })),
  ]));

  page.append(sectionHeader(null, 'Meal ideas'));
  Object.entries(MEAL_IDEAS).forEach(([mealType, ideas]) => {
    page.append(card([
      el('span', 'text-xs text-dim', mealType.toUpperCase()),
      ...ideas.map((idea) => el('p', 'mt-1', idea)),
    ]));
  });

  page.append(sectionHeader(null, 'Foods to favor / avoid'));
  page.append(card([
    el('span', 'text-xs text-dim', 'EAT REGULARLY'),
    el('p', 'mt-1', FOODS_TO_EAT.join(' · ')),
    el('span', 'text-xs text-dim mt-4', 'REDUCE / AVOID'),
    el('p', 'mt-1', FOODS_TO_AVOID.join(' · ')),
  ]));

  const chartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Calories logged (14 days)')])]);
  const canvas = chartCanvas(100);
  chartCard.append(canvas);
  page.append(chartCard);
  requestAnimationFrame(() => {
    renderLineChart(canvas, series.map((s) => ({ date: s.date, value: s.calories })), { color: '#0F9D64' });
  });
}

async function rerender(root) {
  root.innerHTML = '';
  await BodyPage(root);
}

export async function BodyPage(root) {
  const page = el('div', 'page');
  page.append(el('h1', 'page-title', 'Body'), el('p', 'page-subtitle', 'Skin · Fitness · Nutrition'));
  page.append(tabRow(root));

  if (activeTab === 'skin') await renderSkinTab(page);
  else if (activeTab === 'fitness') await renderFitnessTab(page, root);
  else await renderNutritionTab(page, root);

  root.appendChild(page);
}
