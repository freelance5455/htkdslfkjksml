/**
 * MindPage.js — Study / Anki / Notes / MBBS tabs.
 */
import { el, card, sectionHeader, button, xpBar, textInput, textareaInput, emptyState } from '../components/ui.js';
import { chartCanvas, renderBarChart } from '../components/charts/canvasChart.js';
import { TIMETABLE_BLOCKS, logStudySession, getRecentSessions, weeklyStudyHours, subjectBreakdown } from '../modules/mind/study/studyService.js';
import { logAnkiReview, ankiStreak, ankiSeries, todayCardsReviewed } from '../modules/mind/anki/ankiService.js';
import { createNote, getNotesByType } from '../modules/mind/notes/notesService.js';
import { getMBBSTracker, updateMBBSTracker, daysUntil } from '../modules/mind/academics/academicsService.js';
import { showToast } from '../core/notifications/toast.js';

let activeTab = 'study';
let notesSubTab = 'cornell';

function tabRow(root) {
  const row = el('div', 'tab-row');
  [
    { key: 'study', label: 'Study' },
    { key: 'anki', label: 'Anki' },
    { key: 'notes', label: 'Notes' },
    { key: 'mbbs', label: 'MBBS' },
  ].forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${activeTab === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', async () => { activeTab = key; await rerender(root); });
    row.append(pill);
  });
  return row;
}

async function renderStudyTab(page, root) {
  const hours = await weeklyStudyHours();
  const recent = await getRecentSessions(6);
  const breakdown = await subjectBreakdown(14);

  page.append(sectionHeader(`${hours}h this week`, 'Timetable'));
  page.append(card(TIMETABLE_BLOCKS.map((b) => el('div', 'checklist-item', [
    el('span', 'text-xs text-dim', b.time),
    el('span', 'checklist-item__label', b.label),
  ]))));

  const subjectInput = textInput({ placeholder: 'Subject (e.g. Physiology)' });
  const durationInput = textInput({ placeholder: 'Minutes', type: 'number' });
  page.append(sectionHeader(null, 'Log a session'));
  page.append(card([
    subjectInput, el('div', 'mt-3', durationInput),
    el('div', 'mt-3', button('Save session', { block: true, onClick: async () => {
      const mins = parseInt(durationInput.value, 10) || 0;
      if (!subjectInput.value || mins <= 0) { showToast('Add subject and duration.'); return; }
      await logStudySession({ subject: subjectInput.value, durationMin: mins });
      showToast('Session logged.');
      await rerender(root);
    } })),
  ]));

  page.append(sectionHeader(null, 'Recent sessions'));
  page.append(card(
    recent.length === 0
      ? [emptyState('No sessions yet', 'Log one above.')]
      : recent.map((s) => el('div', 'checklist-item', [
          el('span', 'checklist-item__label', `${s.subject} — ${s.durationMin}min`),
          el('span', 'text-xs text-dim', s.date),
        ]))
  ));

  if (breakdown.length > 0) {
    page.append(sectionHeader(null, 'Subject breakdown (14 days)'));
    page.append(card(breakdown.map(([subject, mins]) => el('div', 'checklist-item', [
      el('span', 'checklist-item__label', subject),
      el('span', 'text-xs text-dim', `${Math.round(mins / 6) / 10}h`),
    ]))));
  }
}

async function renderAnkiTab(page, root) {
  const streak = await ankiStreak();
  const today = await todayCardsReviewed();
  const series = await ankiSeries(14);

  page.append(sectionHeader(`${streak}-day streak`, 'Anki'));
  page.append(card([
    el('p', null, `${today} cards reviewed today`),
  ]));

  const cardsInput = textInput({ placeholder: 'Cards reviewed', type: 'number' });
  const maturedInput = textInput({ placeholder: 'Cards matured (optional)', type: 'number' });
  page.append(sectionHeader(null, 'Log review'));
  page.append(card([
    cardsInput, el('div', 'mt-3', maturedInput),
    el('div', 'mt-3', button('Save review', { block: true, onClick: async () => {
      const cards = parseInt(cardsInput.value, 10) || 0;
      if (cards <= 0) { showToast('Enter a card count.'); return; }
      await logAnkiReview({ cardsReviewed: cards, cardsMatured: parseInt(maturedInput.value, 10) || 0 });
      showToast('Review logged.');
      await rerender(root);
    } })),
  ]));

  const chartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Cards reviewed (14 days)')])]);
  const canvas = chartCanvas(100);
  chartCard.append(canvas);
  page.append(chartCard);
  requestAnimationFrame(() => renderBarChart(canvas, series, { color: '#2A4DD0' }));
}

async function renderNotesTab(page, root) {
  const subRow = el('div', 'tab-row');
  [{ key: 'cornell', label: 'Cornell' }, { key: 'memoryPalace', label: 'Memory Palace' }].forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${notesSubTab === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', async () => { notesSubTab = key; await rerender(root); });
    subRow.append(pill);
  });
  page.append(subRow);

  const notes = await getNotesByType(notesSubTab);
  const titleInput = textInput({ placeholder: 'Title' });
  const contentInput = textareaInput({ placeholder: notesSubTab === 'cornell' ? 'Notes / cues / summary' : 'Pathway → location mapping', rows: 4 });

  page.append(card([
    titleInput, el('div', 'mt-3', contentInput),
    el('div', 'mt-3', button('Save note', { block: true, onClick: async () => {
      if (!titleInput.value || !contentInput.value) { showToast('Add a title and content.'); return; }
      await createNote({ type: notesSubTab, title: titleInput.value, content: contentInput.value });
      showToast('Note saved.');
      await rerender(root);
    } })),
  ]));

  page.append(sectionHeader(null, `${notes.length} saved`));
  page.append(card(
    notes.length === 0
      ? [emptyState('No notes yet', 'Add your first note above.')]
      : notes.map((n) => el('div', 'checklist-item', [
          el('span', 'checklist-item__label', n.title),
          el('span', 'text-xs text-dim', n.date),
        ]))
  ));
}

async function renderMBBSTab(page, root) {
  const tracker = await getMBBSTracker();
  const remaining = daysUntil(tracker.screeningDeadline);

  page.append(sectionHeader(remaining >= 0 ? `${remaining} days left` : 'Deadline passed', 'KASU MBBS Post-UTME'));
  page.append(card([
    el('p', null, `Application: ${tracker.applicationNumber}`),
    el('p', 'mt-1 text-dim text-xs', `Deadline: ${tracker.screeningDeadline}`),
    el('p', 'mt-3', tracker.status),
  ]));

  const statusInput = textInput({ placeholder: 'Update status', value: tracker.status });
  const notesInput = textareaInput({ placeholder: 'Notes', value: tracker.notes });
  page.append(sectionHeader(null, 'Update tracker'));
  page.append(card([
    statusInput, el('div', 'mt-3', notesInput),
    el('div', 'mt-3', button('Save', { block: true, onClick: async () => {
      await updateMBBSTracker({ status: statusInput.value, notes: notesInput.value });
      showToast('Tracker updated.');
      await rerender(root);
    } })),
  ]));
}

async function rerender(root) {
  root.innerHTML = '';
  await MindPage(root);
}

export async function MindPage(root) {
  const page = el('div', 'page');
  page.append(el('h1', 'page-title', 'Mind'), el('p', 'page-subtitle', 'Study · Anki · Notes · MBBS'));
  page.append(tabRow(root));

  if (activeTab === 'study') await renderStudyTab(page, root);
  else if (activeTab === 'anki') await renderAnkiTab(page, root);
  else if (activeTab === 'notes') await renderNotesTab(page, root);
  else await renderMBBSTab(page, root);

  root.appendChild(page);
}
