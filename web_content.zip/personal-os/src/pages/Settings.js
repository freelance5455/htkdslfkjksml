import { el, card, button, sectionHeader } from '../components/ui.js';
import { downloadBackup, importBackupFile } from '../core/storage/backupService.js';
import { showToast } from '../core/notifications/toast.js';

export async function Settings(root) {
  const page = el('div', 'page');
  page.append(
    el('h1', 'page-title', 'Settings'),
    el('p', 'page-subtitle', 'Your data, your device.')
  );

  page.append(sectionHeader('Data', 'Backup & restore'));
  const fileInput = el('input');
  fileInput.type = 'file';
  fileInput.accept = 'application/json';
  fileInput.style.display = 'none';

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files[0];
    if (!file) return;
    try {
      const count = await importBackupFile(file);
      showToast(`Restored ${count} records.`);
    } catch (err) {
      showToast(err.message || 'Import failed.');
    }
  });

  page.append(
    card([
      el('p', 'text-dim text-xs', 'Everything is stored only on this device. Export regularly so a lost phone never means lost progress.'),
      el('div', 'mt-4 flex gap-3', [
        button('Export backup', { onClick: () => downloadBackup() }),
        button('Import backup', { variant: 'ghost', onClick: () => fileInput.click() }),
      ]),
      fileInput,
    ])
  );

  page.append(sectionHeader('About', null));
  page.append(
    card([
      el('p', 'text-dim text-xs', 'Personal OS — built for one user, offline-first, no accounts, no tracking.'),
    ])
  );

  root.appendChild(page);
}
