/**
 * quickActions.js — the 7 Quick Action handlers from the Dashboard.
 * Each writes real data into the existing IndexedDB stores (no placeholder
 * data), so logs made here will already be present when the Study/Fitness
 * modules are built next — nothing gets lost or needs re-entry.
 */

import { openSheet, closeSheet } from '../../components/modal.js';
import { el, button, textInput, textareaInput, fieldLabel, chipSelect } from '../../components/ui.js';
import { put, newId, todayISO, getByIndex } from '../../core/storage/storageService.js';
import { emit } from '../../core/utils/eventBus.js';
import { showToast } from '../../core/notifications/toast.js';

function field(labelText, inputEl) {
  return el('div', 'field', [fieldLabel(labelText), inputEl]);
}

function actionsFooter(onSave) {
  return el('div', 'bottom-sheet__footer', [button('Save', { block: true, onClick: onSave })]);
}

/** 1. Start Pomodoro — a real 25-min countdown rendered inline in the sheet. */
export function actionStartPomodoro() {
  let seconds = 25 * 60;
  let timerHandle = null;

  openSheet('Pomodoro', (body, close) => {
    const display = el('div', 'pomodoro-display', formatTime(seconds));
    const subject = textInput({ placeholder: 'Subject (e.g. Physiology)' });

    const startBtn = button('Start 25:00', {
      block: true,
      onClick: () => {
        if (timerHandle) return;
        startBtn.textContent = 'Running…';
        timerHandle = setInterval(() => {
          seconds -= 1;
          display.textContent = formatTime(seconds);
          if (seconds <= 0) {
            clearInterval(timerHandle);
            logStudySession(subject.value || 'Focused study', 25);
            showToast('Pomodoro complete — 25 min logged.');
            close();
          }
        }, 1000);
      },
    });

    body.append(
      field('Subject', subject),
      el('div', 'mt-6', display),
      el('div', 'mt-6', startBtn)
    );
  });
}

function formatTime(totalSeconds) {
  const m = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
  const s = (totalSeconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

async function logStudySession(subject, durationMin) {
  await put('studySessions', {
    id: newId(),
    date: todayISO(),
    subject,
    durationMin,
    type: 'pomodoro',
  });
  emit('study:blockCompleted', { subject, durationMin });
}

/** 2. Log a study session manually (for non-Pomodoro blocks). */
export function actionLogStudySession() {
  openSheet('Log study session', (body, close) => {
    const subject = textInput({ placeholder: 'Subject (e.g. Anatomy)' });
    const duration = textInput({ placeholder: 'Minutes', type: 'number' });
    const notes = textareaInput({ placeholder: 'Notes (optional)' });

    body.append(
      field('Subject', subject),
      field('Duration (minutes)', duration),
      field('Notes', notes),
      actionsFooter(async () => {
        const durationMin = parseInt(duration.value, 10) || 0;
        if (!subject.value || durationMin <= 0) {
          showToast('Add a subject and duration.');
          return;
        }
        await put('studySessions', {
          id: newId(),
          date: todayISO(),
          subject: subject.value,
          durationMin,
          type: 'block',
          notes: notes.value,
        });
        emit('study:blockCompleted', { subject: subject.value, durationMin });
        showToast('Study session logged.');
        close();
      })
    );
  });
}

/** 3. Add a workout. */
export function actionAddWorkout() {
  openSheet('Log workout', (body, close) => {
    const splitDay = textInput({ placeholder: 'e.g. Upper Body, Legs, Cardio' });
    const notes = textareaInput({ placeholder: 'Exercises / notes (optional)' });

    body.append(
      field('Workout / split', splitDay),
      field('Notes', notes),
      actionsFooter(async () => {
        if (!splitDay.value) {
          showToast('Name the workout first.');
          return;
        }
        await put('workoutLogs', {
          id: newId(),
          date: todayISO(),
          splitDay: splitDay.value,
          exercises: [],
          notes: notes.value,
          completed: true,
        });
        emit('workout:completed', {});
        showToast('Workout logged.');
        close();
      })
    );
  });
}

/** 4. Log a meal (rolls into today's nutritionLogs record). */
export function actionLogMeal() {
  openSheet('Log meal', (body, close) => {
    const description = textInput({ placeholder: 'What did you eat?' });
    const calories = textInput({ placeholder: 'Calories (optional)', type: 'number' });
    const protein = textInput({ placeholder: 'Protein g (optional)', type: 'number' });

    body.append(
      field('Meal', description),
      field('Calories', calories),
      field('Protein (g)', protein),
      actionsFooter(async () => {
        if (!description.value) {
          showToast('Describe the meal first.');
          return;
        }
        const today = todayISO();
        const existing = (await getByIndex('nutritionLogs', 'date', today))[0];
        await put('nutritionLogs', {
          id: existing?.id || newId(),
          date: today,
          caloriesTarget: existing?.caloriesTarget || 1900,
          caloriesLogged: (existing?.caloriesLogged || 0) + (parseInt(calories.value, 10) || 0),
          proteinG: (existing?.proteinG || 0) + (parseInt(protein.value, 10) || 0),
          waterMl: existing?.waterMl || 0,
          meals: [...(existing?.meals || []), description.value],
        });
        emit('nutrition:logged', {});
        showToast('Meal logged.');
        close();
      })
    );
  });
}

/** 5. Mood / confidence check-in. */
export function actionMoodCheck() {
  let selectedMood = 'good';
  openSheet('Mood check', (body, close) => {
    const notes = textareaInput({ placeholder: 'What\'s driving this mood? (optional)' });
    const chips = chipSelect(
      [
        { label: '😔 Low', value: 'low' },
        { label: '😐 Okay', value: 'okay' },
        { label: '🙂 Good', value: 'good' },
        { label: '🔥 Great', value: 'great' },
      ],
      selectedMood,
      (value) => {
        selectedMood = value;
        rerenderChips();
      }
    );

    function rerenderChips() {
      const fresh = chipSelect(
        [
          { label: '😔 Low', value: 'low' },
          { label: '😐 Okay', value: 'okay' },
          { label: '🙂 Good', value: 'good' },
          { label: '🔥 Great', value: 'great' },
        ],
        selectedMood,
        (value) => {
          selectedMood = value;
          rerenderChips();
        }
      );
      chips.replaceWith(fresh);
    }

    body.append(
      chips,
      field('Notes', notes),
      actionsFooter(async () => {
        await put('confidenceLogs', {
          id: newId(),
          date: todayISO(),
          practiceType: 'mood-check',
          note: `${selectedMood}${notes.value ? ` — ${notes.value}` : ''}`,
        });
        emit('confidence:logged', {});
        showToast('Mood logged.');
        close();
      })
    );
  });
}

/** 6. Journal entry. */
export function actionOpenJournal() {
  openSheet('Journal', (body, close) => {
    const entry = textareaInput({ placeholder: 'Write freely…', rows: 6 });
    body.append(
      entry,
      actionsFooter(async () => {
        if (!entry.value.trim()) {
          showToast('Write something first.');
          return;
        }
        await put('notesEntries', {
          id: newId(),
          date: todayISO(),
          type: 'journal',
          title: 'Journal entry',
          content: entry.value,
        });
        showToast('Journal entry saved.');
        close();
      })
    );
  });
}

/** 7. Quick hydration log — adds 250ml to today's nutritionLogs. */
export async function actionQuickHydration() {
  const today = todayISO();
  const existing = (await getByIndex('nutritionLogs', 'date', today))[0];
  await put('nutritionLogs', {
    id: existing?.id || newId(),
    date: today,
    caloriesTarget: existing?.caloriesTarget || 1900,
    caloriesLogged: existing?.caloriesLogged || 0,
    proteinG: existing?.proteinG || 0,
    waterMl: (existing?.waterMl || 0) + 250,
    meals: existing?.meals || [],
  });
  emit('nutrition:logged', {});
  const total = (existing?.waterMl || 0) + 250;
  showToast(`+250ml logged — ${(total / 1000).toFixed(2)}L today.`);
}

export { closeSheet };
