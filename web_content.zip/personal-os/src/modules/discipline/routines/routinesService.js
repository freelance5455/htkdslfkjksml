/**
 * routinesService.js — morning/evening routine checklists.
 * Steps mirror the report's productivity system recommendations.
 */

import { getByIndex, put, newId, todayISO } from '../../../core/storage/storageService.js';
import { emit } from '../../../core/utils/eventBus.js';

export const MORNING_STEPS = [
  'Wake at consistent time',
  'Natural sunlight within 30 min of waking',
  'Drink 500ml water immediately',
  'No phone/social media for first 45 minutes',
];

export const EVENING_STEPS = [
  'Bright overhead lights off 2h before bed',
  'Screens away 1h before sleep',
  'Low-stimulation wind-down (reading, packing bag, stretching)',
  'Hard stop on study materials',
];

export async function getRoutineForToday(type) {
  const today = todayISO();
  const logs = await getByIndex('routines', 'date', today);
  const existing = logs.find((l) => l.type === type);
  const stepNames = type === 'morning' ? MORNING_STEPS : EVENING_STEPS;
  if (existing) return existing;
  return { id: null, date: today, type, steps: stepNames.map((label) => ({ label, done: false })) };
}

export async function toggleRoutineStep(type, stepIndex, done) {
  const today = todayISO();
  const routine = await getRoutineForToday(type);
  const steps = routine.steps.map((s, i) => (i === stepIndex ? { ...s, done } : s));
  const record = await put('routines', { id: routine.id || newId(), date: today, type, steps });
  if (steps.every((s) => s.done)) emit('routine:completed', { type });
  return record;
}
