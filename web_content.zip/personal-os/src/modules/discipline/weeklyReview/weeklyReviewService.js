/**
 * weeklyReviewService.js — the Sunday ritual: reflections + auto metrics snapshot.
 */

import { getAll, put, newId } from '../../../core/storage/storageService.js';
import { startOfWeekISO } from '../../../core/utils/dateUtils.js';
import { computeLifeScore } from '../../../core/scoring/scoreEngine.js';
import { emit } from '../../../core/utils/eventBus.js';

export async function submitWeeklyReview({ wins, misses, adjustments }) {
  const metricsSnapshot = await computeLifeScore();
  const record = await put('weeklyReviews', {
    id: newId(),
    weekStartDate: startOfWeekISO(),
    reflections: { wins, misses, adjustments },
    metricsSnapshot,
  });
  emit('weeklyReview:completed', {});
  return record;
}

export async function getReviewHistory(limit = 8) {
  const all = await getAll('weeklyReviews');
  return all.sort((a, b) => (a.weekStartDate < b.weekStartDate ? 1 : -1)).slice(0, limit);
}

export async function hasReviewedThisWeek() {
  const all = await getAll('weeklyReviews');
  const thisWeekStart = startOfWeekISO();
  return all.some((r) => r.weekStartDate === thisWeekStart);
}
