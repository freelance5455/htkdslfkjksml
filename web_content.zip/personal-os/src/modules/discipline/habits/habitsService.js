/**
 * habitsService.js — the single source of truth for habit data + logic.
 * Both Dashboard (Module 2) and the future full Discipline module import
 * from here, so habit rules are never duplicated across modules.
 */

import { getAll, put, newId, getByIndex } from '../../../core/storage/storageService.js';
import { todayISO, isoDaysAgo, startOfWeekISO, lastNDates } from '../../../core/utils/dateUtils.js';
import { emit } from '../../../core/utils/eventBus.js';

export const FREQUENCY = {
  DAILY: 'daily',
  WEEKLY: 'weekly',
  CUSTOM: 'custom',
};

const DEFAULT_HABITS = [
  { name: 'Morning skincare', domain: 'body', frequency: FREQUENCY.DAILY },
  { name: 'Night skincare', domain: 'body', frequency: FREQUENCY.DAILY },
  { name: 'Water 3.5L+', domain: 'body', frequency: FREQUENCY.DAILY },
  { name: 'Workout / steps', domain: 'body', frequency: FREQUENCY.DAILY },
  { name: 'Anki review', domain: 'mind', frequency: FREQUENCY.DAILY },
  { name: 'Study block', domain: 'mind', frequency: FREQUENCY.DAILY },
  { name: 'Phone grayscale / low distraction', domain: 'discipline', frequency: FREQUENCY.DAILY },
  { name: 'Barber / grooming check', domain: 'body', frequency: FREQUENCY.WEEKLY, targetPerWeek: 1 },
  { name: 'Weekly review', domain: 'discipline', frequency: FREQUENCY.WEEKLY, targetPerWeek: 1 },
];

export async function ensureDefaultHabits() {
  const existing = await getAll('habits');
  if (existing.length > 0) return existing;
  const created = [];
  for (const h of DEFAULT_HABITS) {
    created.push(await put('habits', { id: newId(), ...h }));
  }
  return created;
}

export async function getAllHabits() {
  return getAll('habits');
}

export async function createHabit({ name, domain = 'discipline', frequency = FREQUENCY.DAILY, targetPerWeek = null }) {
  return put('habits', { id: newId(), name, domain, frequency, targetPerWeek });
}

export async function getLogsForHabit(habitId) {
  return getByIndex('habitLogs', 'habitId', habitId);
}

export async function getLogsForDate(date) {
  return getByIndex('habitLogs', 'date', date);
}

export async function toggleHabitLog(habit, date, completed) {
  const logsOnDate = await getLogsForDate(date);
  const existingLog = logsOnDate.find((l) => l.habitId === habit.id);
  await put('habitLogs', {
    id: existingLog?.id || newId(),
    habitId: habit.id,
    date,
    completed,
  });
  if (completed) emit('habit:completed', { habitId: habit.id, domain: habit.domain });
  return true;
}

/** Current consecutive-day streak for a single habit (daily habits only). */
export async function habitStreak(habit) {
  const logs = await getLogsForHabit(habit.id);
  const completedDates = new Set(logs.filter((l) => l.completed).map((l) => l.date));
  let streak = 0;
  let cursor = new Date();
  // Grace: if today isn't logged yet, still count yesterday's streak.
  if (!completedDates.has(todayISO())) cursor.setDate(cursor.getDate() - 1);
  while (completedDates.has(cursor.toISOString().slice(0, 10))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

/** Completion percentage for a habit over the last N days (daily) or weeks (weekly). */
export async function habitCompletionPct(habit, windowDays = 28) {
  const logs = await getLogsForHabit(habit.id);
  const completedDates = new Set(logs.filter((l) => l.completed).map((l) => l.date));

  if (habit.frequency === FREQUENCY.WEEKLY) {
    const weeksToCheck = Math.max(1, Math.round(windowDays / 7));
    let hits = 0;
    for (let w = 0; w < weeksToCheck; w += 1) {
      const weekStart = startOfWeekISO(isoDaysAgo(w * 7));
      const weekEnd = w === 0 ? todayISO() : startOfWeekISO(isoDaysAgo((w - 1) * 7));
      const hitInWeek = [...completedDates].some((d) => d >= weekStart && d <= weekEnd);
      if (hitInWeek) hits += 1;
    }
    return Math.round((hits / weeksToCheck) * 100);
  }

  const dates = lastNDates(windowDays);
  const hits = dates.filter((d) => completedDates.has(d)).length;
  return Math.round((hits / windowDays) * 100);
}

/** Overall "today" snapshot across all habits: counts + which are done. */
export async function getTodaySnapshot() {
  const habits = await ensureDefaultHabits();
  const today = todayISO();
  const logsToday = await getLogsForDate(today);
  const dueToday = habits; // all habits appear daily: daily ones as today's task, weekly ones as an open task until logged this week

  const withStatus = await Promise.all(
    dueToday.map(async (h) => {
      const log = logsToday.find((l) => l.habitId === h.id);
      let completedThisWeek = false;
      if (h.frequency === FREQUENCY.WEEKLY) {
        const weekStart = startOfWeekISO();
        const logs = await getLogsForHabit(h.id);
        completedThisWeek = logs.some((l) => l.completed && l.date >= weekStart);
      }
      return {
        habit: h,
        completedToday: !!log?.completed,
        completedThisWeek,
        streak: await habitStreak(h),
      };
    })
  );

  return { habits: withStatus, date: today };
}

/** Daily overall streak: consecutive days where at least one habit was completed. */
export async function overallDailyStreak() {
  const logs = await getAll('habitLogs');
  const completedDates = new Set(logs.filter((l) => l.completed).map((l) => l.date));
  let streak = 0;
  let cursor = new Date();
  if (!completedDates.has(todayISO())) cursor.setDate(cursor.getDate() - 1);
  while (completedDates.has(cursor.toISOString().slice(0, 10))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

/** Habits that were missed yesterday but had an active streak — used for streak-protection warnings. */
export async function habitsAtRiskToday() {
  const habits = await ensureDefaultHabits();
  const atRisk = [];
  for (const h of habits) {
    if (h.frequency !== FREQUENCY.DAILY) continue;
    const logs = await getLogsForHabit(h.id);
    const todayLog = logs.find((l) => l.date === todayISO());
    const streak = await habitStreak(h);
    if (streak >= 3 && !todayLog?.completed) {
      atRisk.push({ habit: h, streak });
    }
  }
  return atRisk;
}
