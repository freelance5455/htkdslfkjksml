/**
 * notesService.js — Cornell notes + Memory Palace entries.
 * Both note types share the `notesEntries` store, differentiated by `type`.
 */

import { getAll, put, newId, todayISO } from '../../../core/storage/storageService.js';

export async function createNote({ type, title, content }) {
  return put('notesEntries', { id: newId(), date: todayISO(), type, title, content });
}

export async function getNotesByType(type) {
  const all = await getAll('notesEntries');
  return all.filter((n) => n.type === type).sort((a, b) => (a.date < b.date ? 1 : -1));
}
