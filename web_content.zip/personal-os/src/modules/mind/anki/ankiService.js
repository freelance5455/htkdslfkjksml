/**
 * ankiService.js — daily Anki review logging + streak/maturity tracking.
 */

import { getAll, put, newId, todayISO, getByIndex } from '../../../core/storage/storageService.js';
import { emit } from '../../../core/utils/eventBus.js';
import { lastNDates } from '../../../core/utils/dateUtils.js';

export async function logAnkiReview({ cardsReviewed, cardsMatured = 0 }) {
  const today = todayISO();
  const existing = (await getByIndex('ankiLogs', 'date', today))[0];
  const record = await put('ankiLogs', {
    id: existing?.id || newId(),
    date: today,
    cardsReviewed: (existing?.cardsReviewed || 0) + cardsReviewed,
    cardsMatured: cardsMatured || existing?.cardsMatured || 0,
    streakDay: true,
  });
  emit('anki:logged', {});
  return record;
}

export async function ankiStreak() {
  const logs = await getAll('ankiLogs');
  const dates = new Set(logs.map((l) => l.date));
  let streak = 0;
  const cursor = new Date();
  if (!dates.has(todayISO())) cursor.setDate(cursor.getDate() - 1);
  while (dates.has(cursor.toISOString().slice(0, 10))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

export async function ankiSeries(days = 14) {
  const logs = await getAll('ankiLogs');
  const dates = lastNDates(days);
  const byDate = new Map(logs.map((l) => [l.date, l]));
  return dates.map((d) => ({ date: d, value: byDate.get(d)?.cardsReviewed || 0 }));
}

export async function todayCardsReviewed() {
  const today = todayISO();
  const existing = (await getByIndex('ankiLogs', 'date', today))[0];
  return existing?.cardsReviewed || 0;
}
