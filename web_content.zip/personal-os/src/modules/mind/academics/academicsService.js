/**
 * academicsService.js — MBBS/KASU Post-UTME application tracker.
 * Deliberately stored as a single JSON blob under the existing `settings`
 * store (key/value) rather than a new object store — this is a handful
 * of fields the user edits occasionally, not a growing log of records.
 */

import { getSetting, setSetting } from '../../../core/storage/storageService.js';

const KEY = 'academics.mbbsTracker';

const DEFAULTS = {
  applicationNumber: '2026-MED-00028',
  screeningDeadline: '2026-07-13',
  status: 'Submitted — O\'level correction confirmed',
  notes: '',
};

export async function getMBBSTracker() {
  return getSetting(KEY, DEFAULTS);
}

export async function updateMBBSTracker(partial) {
  const current = await getMBBSTracker();
  const updated = { ...current, ...partial };
  await setSetting(KEY, updated);
  return updated;
}

export function daysUntil(dateISO) {
  const target = new Date(`${dateISO}T23:59:59`);
  const diffMs = target.getTime() - Date.now();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}
