/**
 * skinService.js — AM/PM skincare routine tracking.
 * Steps come from the facial-analysis report's skincare plan.
 * Reuses the existing `skincareLogs` store (one record per date+period).
 */

import { getByIndex, put, newId, todayISO } from '../../../core/storage/storageService.js';
import { emit } from '../../../core/utils/eventBus.js';

export const AM_STEPS = [
  'Gentle hydrating cleanser',
  '2% Alpha Arbutin / Vitamin C serum',
  'Lightweight oil-free moisturizer',
  'Broad-spectrum SPF 50 sunscreen',
];

export const PM_STEPS = [
  'Salicylic acid (BHA) cleanser',
  'Retinol / Tretinoin (per tolerance schedule)',
  'Mewing practice (tongue posture)',
  'Non-comedogenic night moisturizer',
];

export async function getRoutineForToday(period) {
  const today = todayISO();
  const logs = await getByIndex('skincareLogs', 'date', today);
  const existing = logs.find((l) => l.period === period);
  const stepNames = period === 'AM' ? AM_STEPS : PM_STEPS;
  if (existing) return existing;
  return { id: null, date: today, period, steps: stepNames.map((name) => ({ name, done: false })) };
}

export async function toggleSkincareStep(period, stepIndex, done) {
  const today = todayISO();
  const routine = await getRoutineForToday(period);
  const steps = routine.steps.map((s, i) => (i === stepIndex ? { ...s, done } : s));
  const record = await put('skincareLogs', { id: routine.id || newId(), date: today, period, steps });

  const allDone = steps.every((s) => s.done);
  if (allDone) emit('skincare:completed', { period });
  return record;
}

/** Days remaining until the next recommended barber visit (every 14-21 days). */
export async function daysUntilNextBarber(lastVisitISO, cycleDays = 17) {
  if (!lastVisitISO) return null;
  const last = new Date(`${lastVisitISO}T00:00:00`);
  const next = new Date(last);
  next.setDate(next.getDate() + cycleDays);
  const diffMs = next.getTime() - Date.now();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}
