/**
 * nutritionService.js — calorie/protein/water tracking + meal idea library.
 * Targets default to the report's recommendations (1800-2000 kcal, 1.6-2.2g/kg protein).
 */

import { getByIndex, put, newId, todayISO, getAll } from '../../../core/storage/storageService.js';
import { emit } from '../../../core/utils/eventBus.js';
import { lastNDates } from '../../../core/utils/dateUtils.js';

export const DEFAULT_TARGETS = { calories: 1900, proteinG: 150, waterMl: 3500 };

export const MEAL_IDEAS = {
  Breakfast: [
    'Boiled eggs with oatmeal and a side of spinach',
    'Steamed Moin-Moin (minimal oil) with a lean protein source',
  ],
  Lunch: [
    'Grilled chicken or fish with boiled sweet potato + Efo Riro (minimal palm oil)',
    'Lean beef with brown rice and a large vegetable soup portion',
  ],
  Dinner: [
    'Peppered fish or lean beef soup packed with vegetables',
    'Small portion Jollof rice with skinless chicken breast, minimal oil',
  ],
};

export const FOODS_TO_EAT = ['Chicken breast', 'Turkey', 'Fish', 'Eggs', 'Beans', 'Lentils', 'Oats', 'Brown rice', 'Sweet potatoes', 'Spinach / ugu / cabbage'];
export const FOODS_TO_AVOID = ['Refined sugars', 'Sodas', 'Deep-fried snacks', 'Excess vegetable oils', 'Processed simple carbs'];

export async function getTodayNutrition() {
  const today = todayISO();
  const existing = (await getByIndex('nutritionLogs', 'date', today))[0];
  return existing || {
    id: null,
    date: today,
    caloriesTarget: DEFAULT_TARGETS.calories,
    caloriesLogged: 0,
    proteinG: 0,
    waterMl: 0,
    meals: [],
  };
}

export async function logMeal({ description, calories = 0, protein = 0 }) {
  const today = todayISO();
  const existing = (await getByIndex('nutritionLogs', 'date', today))[0];
  const record = await put('nutritionLogs', {
    id: existing?.id || newId(),
    date: today,
    caloriesTarget: existing?.caloriesTarget || DEFAULT_TARGETS.calories,
    caloriesLogged: (existing?.caloriesLogged || 0) + calories,
    proteinG: (existing?.proteinG || 0) + protein,
    waterMl: existing?.waterMl || 0,
    meals: [...(existing?.meals || []), description],
  });
  emit('nutrition:logged', {});
  return record;
}

export async function logHydration(amountMl = 250) {
  const today = todayISO();
  const existing = (await getByIndex('nutritionLogs', 'date', today))[0];
  const record = await put('nutritionLogs', {
    id: existing?.id || newId(),
    date: today,
    caloriesTarget: existing?.caloriesTarget || DEFAULT_TARGETS.calories,
    caloriesLogged: existing?.caloriesLogged || 0,
    proteinG: existing?.proteinG || 0,
    waterMl: (existing?.waterMl || 0) + amountMl,
    meals: existing?.meals || [],
  });
  emit('nutrition:logged', {});
  return record;
}

export async function nutritionSeries(days = 14) {
  const all = await getAll('nutritionLogs');
  const dates = lastNDates(days);
  const byDate = new Map(all.map((n) => [n.date, n]));
  return dates.map((d) => ({
    date: d,
    calories: byDate.get(d)?.caloriesLogged || 0,
    water: byDate.get(d)?.waterMl || 0,
  }));
}
