/**
 * fitnessService.js — workout logging + body metrics trend.
 * Weekly split mirrors the report's plan (Upper/Lower/Cardio/Rest).
 */

import { getAll, put, newId, todayISO, getByIndex } from '../../../core/storage/storageService.js';
import { emit } from '../../../core/utils/eventBus.js';
import { lastNDates } from '../../../core/utils/dateUtils.js';

export const WEEKLY_SPLIT = [
  { day: 'Monday', focus: 'Upper Body Strength + Posture work' },
  { day: 'Tuesday', focus: '45 min LISS Cardio or 10k Steps + Core' },
  { day: 'Wednesday', focus: 'Lower Body Strength' },
  { day: 'Thursday', focus: 'Active Recovery (10k Steps + Mobility)' },
  { day: 'Friday', focus: 'Upper Body Strength' },
  { day: 'Saturday', focus: 'Lower Body Strength + Cardio' },
  { day: 'Sunday', focus: 'Full Rest & Mobility' },
];

export function todaysSplitFocus(date = new Date()) {
  const dayName = date.toLocaleDateString(undefined, { weekday: 'long' });
  return WEEKLY_SPLIT.find((d) => d.day === dayName) || WEEKLY_SPLIT[0];
}

export async function logWorkout({ splitDay, exercises = [], notes = '' }) {
  const record = await put('workoutLogs', {
    id: newId(),
    date: todayISO(),
    splitDay,
    exercises,
    notes,
    completed: true,
  });
  emit('workout:completed', {});
  return record;
}

export async function getRecentWorkouts(limit = 10) {
  const all = await getAll('workoutLogs');
  return all.sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, limit);
}

export async function logBodyMetric({ weightKg = null, bodyFatPct = null, steps = null }) {
  const today = todayISO();
  const existing = (await getByIndex('bodyMetrics', 'date', today))[0];
  return put('bodyMetrics', {
    id: existing?.id || newId(),
    date: today,
    weightKg: weightKg ?? existing?.weightKg ?? null,
    bodyFatPct: bodyFatPct ?? existing?.bodyFatPct ?? null,
    steps: steps ?? existing?.steps ?? null,
  });
}

export async function bodyMetricsSeries(days = 30) {
  const all = await getAll('bodyMetrics');
  const dates = lastNDates(days);
  const byDate = new Map(all.map((m) => [m.date, m]));
  return dates.map((d) => ({
    date: d,
    weight: byDate.get(d)?.weightKg ?? null,
    bodyFat: byDate.get(d)?.bodyFatPct ?? null,
  }));
}

/** Workout days completed in the last 7 days vs. the 3-4x/week target. */
export async function weeklyWorkoutCount() {
  const dates = lastNDates(7);
  const workouts = await getAll('workoutLogs');
  return workouts.filter((w) => dates.includes(w.date) && w.completed).length;
}
