/**
 * groomingService.js — barber cycle + wardrobe/style notes.
 * Settings-backed (small, occasionally-edited fields), same pattern as
 * academicsService.js — avoids a new object store for a handful of fields.
 */

import { getSetting, setSetting, todayISO } from '../../../core/storage/storageService.js';
import { daysUntilNextBarber } from '../../body/skin/skinService.js';

const KEY = 'presence.grooming';

const DEFAULTS = {
  lastBarberVisit: null,
  wardrobeNotes: 'High-contrast colors: emerald green, royal blue, crisp white, burgundy.',
};

export async function getGroomingData() {
  return getSetting(KEY, DEFAULTS);
}

export async function logBarberVisit() {
  const current = await getGroomingData();
  const updated = { ...current, lastBarberVisit: todayISO() };
  await setSetting(KEY, updated);
  return updated;
}

export async function updateWardrobeNotes(notes) {
  const current = await getGroomingData();
  const updated = { ...current, wardrobeNotes: notes };
  await setSetting(KEY, updated);
  return updated;
}

export async function daysUntilBarber() {
  const { lastBarberVisit } = await getGroomingData();
  return daysUntilNextBarber(lastBarberVisit);
}
