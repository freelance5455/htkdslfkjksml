/**
 * confidenceService.js — confidence/social-presence practice logging.
 * Practice types come from the report's Confidence & Social Presence section.
 */

import { getAll, put, newId, todayISO } from '../../../core/storage/storageService.js';
import { emit } from '../../../core/utils/eventBus.js';

export const PRACTICE_TYPES = [
  'Posture check (shoulders back, chin level)',
  'Eye contact practice',
  'Slowed speech cadence',
  'Mirror smile practice (Duchenne smile)',
  'Confident walk (deliberate pace, hips-led stride)',
];

export async function logConfidencePractice({ practiceType, note = '' }) {
  const record = await put('confidenceLogs', {
    id: newId(),
    date: todayISO(),
    practiceType,
    note,
  });
  emit('confidence:logged', {});
  return record;
}

export async function getRecentConfidenceLogs(limit = 10) {
  const all = await getAll('confidenceLogs');
  return all.sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, limit);
}
