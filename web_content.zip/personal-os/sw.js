/**
 * sw.js — hand-rolled service worker (no build tool, no CDN dependency).
 * Strategy: cache-first for the app shell, since this app has no server
 * and no remote data — everything it needs to run lives in this cache.
 */

const CACHE_VERSION = 'personal-os-v7';

const SHELL_ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './src/main.js',
  './src/styles/globals.css',
  './src/styles/tokens.css',
  './src/core/router.js',
  './src/core/storage/db.js',
  './src/core/storage/storageService.js',
  './src/core/storage/backupService.js',
  './src/core/xp/xpEngine.js',
  './src/core/xp/achievements.js',
  './src/core/notifications/toast.js',
  './src/core/utils/eventBus.js',
  './src/core/utils/dateUtils.js',
  './src/core/scoring/scoreEngine.js',
  './src/core/tasks/taskEngine.js',
  './src/core/motivation/quotes.js',
  './src/core/intelligence/suggestionEngine.js',
  './src/components/ui.js',
  './src/components/icons.js',
  './src/components/modal.js',
  './src/components/charts/canvasChart.js',
  './src/components/layout/navBar.js',
  './src/modules/discipline/habits/habitsService.js',
  './src/modules/dashboard/quickActions.js',
  './src/modules/body/skin/skinService.js',
  './src/modules/body/fitness/fitnessService.js',
  './src/modules/body/nutrition/nutritionService.js',
  './src/modules/mind/study/studyService.js',
  './src/modules/mind/anki/ankiService.js',
  './src/modules/mind/notes/notesService.js',
  './src/modules/mind/academics/academicsService.js',
  './src/modules/discipline/routines/routinesService.js',
  './src/modules/discipline/weeklyReview/weeklyReviewService.js',
  './src/modules/presence/confidence/confidenceService.js',
  './src/modules/presence/grooming/groomingService.js',
  './src/pages/Dashboard.js',
  './src/pages/Settings.js',
  './src/pages/BodyPage.js',
  './src/pages/MindPage.js',
  './src/pages/DisciplinePage.js',
  './src/pages/PresencePage.js',
  './src/pages/ProgressPage.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(SHELL_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_VERSION)
          .map((key) => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;

      return fetch(event.request)
        .then((response) => {
          const clone = response.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, clone));
          return response;
        })
        .catch(() => caches.match('./index.html'));
    })
  );
});

// Listen for a manual "skip waiting" trigger from the update toast.
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});
