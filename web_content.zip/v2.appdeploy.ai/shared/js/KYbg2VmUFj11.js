"use strict";(function(){"use strict";const H=window.__appDeployOverlayBootstrap,c=H&&typeof H.claim=="function"?H.claim():null;if(H&&!c||!c&&window.__appDeployOverlayLoaded)return;const P=c?.config||null,v=c?.fetch||(typeof window.fetch=="function"?window.fetch.bind(window):null),d=c?.createElement||(t=>document.createElement(t)),u=c?.appendChild||((t,e)=>t.appendChild(e)),y=c?.setAttribute||((t,e,n)=>t.setAttribute(e,n)),wt=c?.removeAttribute||((t,e)=>t.removeAttribute(e)),de=c?.getAttribute||((t,e)=>t.getAttribute(e)),Y=c?.hasAttribute||((t,e)=>t.hasAttribute(e)),_t=c?.attachShadow||((t,e)=>t.attachShadow(e)),z=c?.addEventListener||((t,e,n,i)=>t.addEventListener(e,n,i)),ue=c?.createMutationObserver||(t=>new MutationObserver(t)),k=c?.setTimeout||window.setTimeout.bind(window),me=window.clearTimeout.bind(window),tt=c?.getBoundingClientRect||(t=>t.getBoundingClientRect()),he=typeof document.elementFromPoint=="function"?document.elementFromPoint.bind(document):()=>null,I=c?.promiseThen||((t,e,n)=>t.then(e,n)),xt=c?.showPopover||(t=>t.showPopover?.()),et=c?.hidePopover||(t=>t.hidePopover?.()),vt=c?.getInert||(t=>t.inert),At=c?.setInert||((t,e)=>t.inert=e);try{Object.defineProperty(window,"__appDeployOverlayLoaded",{value:!0,writable:!1,configurable:!1})}catch{window.__appDeployOverlayLoaded=!0}window.__appDeployOverlayNetworkReporterActive=!0;const q="[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?",Et=new RegExp(`^${q}$`,"i"),fe=new RegExp(`^(${q})\\.`,"i"),ye=new RegExp(`/app/(${q})(?:/|$)`,"i"),be=()=>{if(typeof P?.appId=="string"&&Et.test(P.appId))return P.appId;if(typeof window.__APPDEPLOY_APP_ID=="string"&&Et.test(window.__APPDEPLOY_APP_ID))return window.__APPDEPLOY_APP_ID;const t=window.location.hostname.match(fe);if(t)return t[1];const e=window.location.pathname.match(ye);return e?e[1]:null},ge=()=>Math.random().toString(36).slice(2)+Date.now().toString(36),g=be(),we=ge(),Pt=typeof P?.appVersion=="string"?P.appVersion:typeof window.__APPDEPLOY_APP_VERSION=="string"?window.__APPDEPLOY_APP_VERSION:null,_e="https://api-v2.appdeploy.ai",T=()=>_e,xe="request-latency-log-v1",Lt="x-appdeploy-ai",ve=60*1e3,Ae=500,Tt=240,St=new Set(["/metrics","/logs","/p"]),Ee=["/api","/rpc","/auth"],F="/app/:app_id/api",Pe=new RegExp(`^/app/(?:${q}|:app_id)/api(?=/|$)`,"i"),Le=/^\d{6,}$/,Te=/^[a-f0-9]{18}$/i,Se=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,ke=/^[A-Za-z0-9_-]{24,}$/,kt="x-appdeploy-app-availability",Rt="temporarily-unavailable",It="APP_TEMPORARILY_UNAVAILABLE",Ot="CREDITS_EXHAUSTED";let nt=Date.now(),Ct=null;const N=[];let ot=0;const M=t=>{if(typeof t!="string"||t.length===0)return null;try{return new URL(t,window.location.href)}catch{return null}},Re=t=>{if(typeof t!="string"||t.length===0)return"/";let n=t.split("/").map(i=>i&&(Te.test(i)?":app_id":Se.test(i)?":uuid":Le.test(i)?":id":ke.test(i)?":token":i)).join("/")||"/";return n=n.replace(Pe,F),n===F?n="/":n.startsWith(`${F}/`)&&(n=n.slice(F.length)),n.length<=Tt?n:n.slice(0,Tt)},Ie=t=>{if(!t||St.has(t))return!0;for(const e of St)if(t.startsWith(`${e}/`))return!0;return!1},Oe=t=>{if(!t||Ie(t.pathname))return!1;const e=M(T());return e&&t.origin===e.origin?!0:t.origin!==window.location.origin?!1:Ee.some(n=>t.pathname===n||t.pathname.startsWith(`${n}/`))},Dt=t=>{const e=M(t);return Oe(e)?{pathKey:Re(e.pathname)}:null},Nt=t=>{try{const e=typeof t=="string"?JSON.parse(t):t;return e?.code===It||e?.code===Ot}catch{return!1}},Ce=t=>{try{return t?.status===402&&t.headers?.get(kt)===Rt}catch{return!1}},De=async t=>{if(t?.status!==402)return!1;try{return Nt(await t.clone().text())}catch{return!1}},rt=(t=!1)=>{if(!g)return;if(N.length===0){nt=Date.now();return}const e=Date.now(),n=nt,i=Math.max(n,e),b=N.splice(0,N.length),l=ot;nt=i,ot=0;const p={a:g,metric:xe,v:1,window_start_ms:n,window_end_ms:i,...l>0?{dropped_count:l}:{},requests:b},h=JSON.stringify(p),r=`${T()}/metrics`;t&&typeof navigator.sendBeacon=="function"&&navigator.sendBeacon(r,h)||v&&v(r,{method:"POST",headers:{"Content-Type":"application/json"},body:h,keepalive:t}).catch(()=>{})},it=t=>{if(g){if(N.length>=Ae){ot+=1;return}N.push(t)}},Ne=()=>{Ct||(Ct=setInterval(()=>{rt(!1)},ve),window.addEventListener("pagehide",()=>{rt(!0)}),document.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"&&rt(!0)}))},Me=async t=>{if(g)try{if(!v)return;await v(`${T()}/logs`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({app_id:g,source:"frontend",message:t,session_id:we,...Pt?{app_version:Pt}:{}})})}catch{}},at=new Set,Mt=t=>typeof t=="string"&&/\b402\b/.test(t)&&(t.includes(It)||t.includes(Ot)||/(request failed|axios|xhr|fetch)/i.test(t)),S=t=>{if(Mt(t))return;const e=t.slice(0,200);at.has(e)||(at.add(e),setTimeout(()=>at.delete(e),6e4),console.log("[AppDeploy] Caught error:",t),Me(t))};if(g){window.addEventListener("error",r=>{if(r.target&&r.target!==window){const L=r.target,Z=L.tagName?.toLowerCase()||"unknown",B=L.src||L.href||"unknown";S(`Resource error: Failed to load ${Z} - ${B}`);return}const{message:a,filename:o,lineno:f,colno:s,error:w}=r,E=w?.stack||"",$=`${a}
  at ${o}:${f}:${s}${E?`
`+E:""}`;S($)},!0),window.addEventListener("unhandledrejection",r=>{const a=r.reason,o=a instanceof Error?`Unhandled Promise Rejection: ${a.message}
${a.stack||""}`:`Unhandled Promise Rejection: ${String(a)}`;S(o)});const t=v,e=r=>typeof r=="string"?r:r instanceof URL?r.href:r&&typeof r=="object"?r.url||String(r):"",n=r=>{const a=r[0],o=r[1];return{url:e(a),method:(o?.method||a?.method||"GET").toUpperCase()}},i=r=>{try{return r.headers.get(Lt)==="1"}catch{return!1}},b=r=>{try{return r.getResponseHeader(Lt)==="1"}catch{return!1}};window.fetch=async(...r)=>{const a=n(r);if(Qt(a.url))return new Promise(()=>{});const o=Dt(a.url),f=o?Date.now():0;try{const s=await t(...r);if(Ce(s)||await De(s))mt(a.url);else if(!s.ok&&s.status>=400){const w=a.url||"unknown";let E="";try{E=await s.clone().text(),E.length>500&&(E=E.slice(0,500)+"...")}catch{E="(unable to read response)"}S(`Fetch error: ${s.status} ${s.statusText} - ${w}
Response: ${E}`)}if(o&&f>0){const w=i(s);it({ts_ms:f,path_key:o.pathKey,method:a.method,duration_ms:Math.max(0,Date.now()-f),http_status:s.status,outcome:s.status>=400?"http_error":"ok",...w?{used_ai:!0}:{}})}return s}catch(s){const w=a.url||"unknown";throw S(`Fetch failed: ${s.message} - ${w}`),o&&f>0&&it({ts_ms:f,path_key:o.pathKey,method:a.method,duration_ms:Math.max(0,Date.now()-f),outcome:"network_error"}),s}};const l=XMLHttpRequest.prototype.open,p=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(r,a,...o){const f=typeof a=="string"?a:String(a||"");this._appDeployUrl=f,this._appDeployMethod=r;const s=Dt(f);return this._appDeployLatencyPathKey=s?.pathKey||null,l.call(this,r,a,...o)},XMLHttpRequest.prototype.send=function(...r){if(Qt(this._appDeployUrl))return;const a=Date.now();return this._appDeployLatencyStartedAt=a,this.addEventListener("load",function(){if(this.status===402&&(this.getResponseHeader(kt)===Rt||Nt(this.responseText)))mt(this._appDeployUrl);else if(this.status>=400){const f=this._appDeployUrl||"unknown";let s="";try{s=this.responseText||"",s.length>500&&(s=s.slice(0,500)+"...")}catch{s="(unable to read response)"}S(`XHR error: ${this.status} ${this.statusText} - ${this._appDeployMethod} ${f}
Response: ${s}`)}}),this.addEventListener("error",function(){const o=this._appDeployUrl||"unknown";S(`XHR failed: Network error - ${this._appDeployMethod} ${o}`)}),this.addEventListener("loadend",function(){if(!this._appDeployLatencyPathKey||!this._appDeployLatencyStartedAt)return;const o=Number.isFinite(this.status)?this.status:void 0,f=typeof o=="number"&&o>0?o>=400?"http_error":"ok":"network_error",s=b(this);it({ts_ms:this._appDeployLatencyStartedAt,path_key:this._appDeployLatencyPathKey,method:String(this._appDeployMethod||"GET").toUpperCase(),duration_ms:Math.max(0,Date.now()-this._appDeployLatencyStartedAt),http_status:typeof o=="number"&&o>0?o:void 0,outcome:f,...s?{used_ai:!0}:{}})}),p.apply(this,r)};const h=console.error;console.error=function(...r){const a=r.map(o=>{if(o instanceof Error)return`${o.message}${o.stack?`
`+o.stack:""}`;if(typeof o=="object")try{return JSON.stringify(o)}catch{return String(o)}return String(o)}).join(" ");return!a.startsWith("[AppDeploy]")&&!Mt(a)&&S(`Console error: ${a}`),h.apply(console,r)},Ne(),console.log("[AppDeploy] Error tracking enabled")}const Ut=typeof P?.notificationOpenQueryParam=="string"&&P.notificationOpenQueryParam.trim().length>0?P.notificationOpenQueryParam.trim():typeof window.__APPDEPLOY_NOTIFICATION_OPEN_QUERY_PARAM=="string"&&window.__APPDEPLOY_NOTIFICATION_OPEN_QUERY_PARAM.trim().length>0?window.__APPDEPLOY_NOTIFICATION_OPEN_QUERY_PARAM.trim():"appdeploy_notification_open",Ue="hideInstallPrompt",R="pwa-install",st="pwa-install",$e="manifest.json",Be="0.6.3",lt="pwa-install.bundle.js",He=`https://unpkg.com/@khmyznikov/pwa-install@${Be}/dist/${lt}`,Ye="sha384-Y/8ZP8Y+L1PZ9LFmLykD3Ao2udUqJ/jYlWWkJbjA+hQo5TpbXO1EcWQJuSt2RAGT",ze=/Android|iPhone|iPad|iPod|Tablet|PlayBook|Silk|Kindle|KF[A-Z0-9]+|Windows Phone|IEMobile|BlackBerry|Opera Mini|Opera Tablet/i,$t=t=>{if(typeof window.matchMedia!="function")return!1;try{return window.matchMedia(t).matches}catch{return!1}},qe=()=>(typeof navigator.userAgentData?.platform=="string"?navigator.userAgentData.platform:navigator.platform||"")==="MacIntel"&&typeof navigator.maxTouchPoints=="number"&&navigator.maxTouchPoints>1,Fe=()=>typeof navigator.maxTouchPoints=="number"&&navigator.maxTouchPoints>0||"ontouchstart"in window?!0:$t("(pointer: coarse)")||$t("(any-pointer: coarse)"),je=()=>{const t=typeof navigator.userAgentData?.mobile=="boolean"?navigator.userAgentData.mobile:null;if(qe())return!0;const e=navigator.userAgent||"",n=ze.test(e),i=/Android/i.test(e)&&!/Mobile/i.test(e);return t===!0?!0:!(!n&&!i||!Fe())},Bt=()=>{if(typeof window.matchMedia=="function")try{if(window.matchMedia("(display-mode: standalone)").matches)return!0}catch{}return typeof navigator<"u"&&navigator.standalone===!0},O=new URL(window.location.href),Ht=!!g,pt=!(O.searchParams.get(Ue)==="1")&&je()&&!Bt(),Yt=O.searchParams.get(Ut)==="1";if(Yt&&(O.searchParams.delete(Ut),window.history&&typeof window.history.replaceState=="function")){const t=`${O.pathname}${O.search}${O.hash}`;window.history.replaceState(window.history.state,"",t)}let zt=!0,ct=Promise.resolve(),j="available",_,V,x,dt;const Ve=5e3,Xe=3e4,We=3e5;let qt=-1/0,Ft=Xe,ut=!1,jt=!1,X=!1,Vt,Xt;const Wt=t=>{if(!g)return!1;const e=M(t),n=M(T())||M(window.location.origin);if(!e||!n||e.origin!==n.origin)return!1;const i=`/app/${g}`;return e.pathname===i||e.pathname.startsWith(`${i}/`)},Qt=t=>j==="temporarily_unavailable"&&Wt(t),Gt=t=>{try{document.body&&At(document.body,t)}catch{}},Kt=()=>{if(j="available",_){Gt(Vt),document.documentElement.style.overflow=Xt;try{et(_)}catch{}_.remove(),_=null,V=null,x=null}},Jt=()=>{if(window.crypto?.randomUUID)return window.crypto.randomUUID();if(!window.crypto?.getRandomValues)return;const t=window.crypto.getRandomValues(new Uint8Array(16));t[6]=t[6]&15|64,t[8]=t[8]&63|128;const e=Array.from(t,n=>n.toString(16).padStart(2,"0")).join("");return`${e.slice(0,8)}-${e.slice(8,12)}-${e.slice(12,16)}-${e.slice(16,20)}-${e.slice(20)}`},Zt=(t,e)=>{try{if(!g||!v||!e)return;const n=Jt();if(!n)return;const i=JSON.stringify({a:g,metric:t,v:1,event_id:n,popup_id:e,client_ts_ms:Date.now()}),b=l=>{try{const p=()=>{l<2&&k(()=>b(l+1),500*(l+1))};I(v(`${T()}/metrics`,{method:"POST",headers:{"Content-Type":"application/json"},body:i,keepalive:!0}),h=>{(h.status>=500||h.status===429)&&p()},p)}catch{}};b(0)}catch{}},Qe=t=>{if(j="temporarily_unavailable",_)return;let e;try{e=Jt()}catch{}Vt=document.body?vt(document.body):!1,Xt=document.documentElement.style.overflow,Gt(!0),document.documentElement.style.overflow="hidden",_=d(`${ae}-availability`),y(_,"style",Q),y(_,"popover","manual"),V=_t(_,{mode:"closed"});const n=d("style");n.textContent=`
            :host { all: initial; direction: ltr; }
            * { box-sizing: border-box; }
            .layer { position: fixed; inset: 0; width: 100vw; height: 100vh; height: 100dvh;
                overflow: auto; direction: ltr; text-align: left; color: #173450;
                font: 16px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
                pointer-events: auto; overscroll-behavior: contain; }
            .scrim { position: fixed; inset: 0; background: rgba(15,23,42,.52); }
            .banner { position: relative; z-index: 1; width: 100%;
                padding: max(24px, env(safe-area-inset-top)) clamp(22px, 4vw, 40px) 24px;
                border-bottom: 1px solid #cbdcf0; background: #eef5ff;
                box-shadow: 0 6px 24px #0f172a1a; }
            .inner { max-width: 1280px; margin: auto; display: flex; align-items: center;
                justify-content: space-between; gap: 32px; }
            .message { display: flex; gap: 14px; align-items: flex-start; min-width: 0; }
            .icon { display: flex; flex: 0 0 38px; align-items: center; justify-content: center;
                gap: 4px; width: 38px; height: 38px; margin-top: 2px;
                border-radius: 11px; background: #dceaff; }
            .icon::before, .icon::after { content: ""; width: 4px; height: 15px;
                border-radius: 1px; background: #315b83; }
            .content { min-width: 0; }
            h2 { margin: 0 0 6px; color: #173450; font-size: 24px;
                font-weight: 700; letter-spacing: -.4px; line-height: 1.25; }
            p { margin: 0; color: #4b627c; font-size: 16px; line-height: 1.5; }
            .actions { display: grid; gap: 8px; flex: 0 0 204px; text-align: center; }
            .owner { color: #4b627c; font-size: 12px; line-height: 1.4; }
            .primary { display: flex; align-items: center; justify-content: center; gap: 12px;
                min-height: 46px; padding: 12px 20px; border-radius: 9px; background: #1d64cf;
                color: #fff; font-size: 14px; font-weight: 650; line-height: 1.4; text-decoration: none; }
            .primary:hover { background: #1959b9; }
            .secondary { color: #3c628a; font-size: 12px; line-height: 1.5;
                text-underline-offset: 3px; min-height: 20px; }
            a:focus-visible { outline: 3px solid #0891b2; outline-offset: 4px; }
            @media (max-width: 600px) {
                .banner { padding: calc(env(safe-area-inset-top) + 24px) 22px 20px; }
                .inner { display: block; }
                .message { gap: 12px; }
                .icon { width: 34px; height: 34px; flex-basis: 34px; border-radius: 10px; margin-top: 0; }
                h2 { font-size: 21px; margin-bottom: 7px; }
                p { font-size: 14px; line-height: 1.55; }
                .actions { margin-top: 20px; gap: 9px; }
                .primary { min-height: 48px; font-size: 15px; }
                .secondary { display: flex; align-items: center; justify-content: center; min-height: 28px; }
            }
        `,u(V,n),x=d("div"),x.className="layer",y(x,"role","dialog"),y(x,"aria-modal","true"),y(x,"dir","ltr"),y(x,"aria-live","assertive"),y(x,"aria-labelledby","appdeploy-availability-title"),y(x,"aria-describedby","appdeploy-availability-copy"),x.tabIndex=-1;const i=d("div");i.className="scrim",y(i,"aria-hidden","true");const b=d("header");b.className="banner";const l=d("div");l.className="inner";const p=d("div");p.className="message";const h=d("span");h.className="icon",y(h,"aria-hidden","true");const r=d("div");r.className="content";const a=d("h2");a.id="appdeploy-availability-title",a.textContent="This app is paused";const o=d("p");o.id="appdeploy-availability-copy",o.textContent="This app has reached its credit limit.",u(r,a),u(r,o),u(p,h),u(p,r);const f=d("div");f.className="actions";const s=d("span");s.className="owner",s.textContent="Own this app?";const w=d("a");w.className="primary",w.textContent=t.plan==="plus"?"Manage credits":"Upgrade to Plus";let E=!1;z(w,"click",()=>{t.plan!=="free"||E||(E=!0,Zt("credit_limit_upgrade_clicked",e))}),y(w,"href",t.plan==="plus"?t.dashboard_url:"https://appdeploy.ai/pricing?utm_source=appdeploy_overlay&utm_medium=referral&utm_campaign=credit_limit");const $=d("span");$.textContent="\u2197",y($,"aria-hidden","true"),u(w,$);const L=d("a");L.className="secondary",L.textContent="View usage and reset time",y(L,"href",t.dashboard_url);for(const gt of[w,L])y(gt,"target","_blank"),y(gt,"rel","noopener");u(f,s),u(f,w),u(f,L),u(l,p),u(l,f),u(b,l),u(x,i),u(x,b),u(V,x),u(document.documentElement,_),xt(_);const Z=_,B=()=>{document.visibilityState==="visible"&&(document.removeEventListener("visibilitychange",B),Z.isConnected&&_===Z&&Zt("credit_limit_popup_shown",e))};document.visibilityState==="visible"?B():z(document,"visibilitychange",B),k(()=>x?.focus(),0)},te=t=>{const e=t?.credit_limit??t?.monthly_credit_limit;e&&(e.plan==="free"||e.plan==="plus")&&typeof e.dashboard_url=="string"?(X=!0,e.plan==="free"?Qe(e):Kt()):j==="available"&&(X=!1,Kt())},mt=t=>{if(!Wt(t)||!v||_||X||dt||ut||Date.now()<qt)return;const e=typeof AbortController=="function"?new AbortController:null;let n;const i=new Promise(l=>{n=k(()=>{l(null),e?.abort()},Ve),I(v(`${T()}/p`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({a:g,availability_only:!0}),...e?{signal:e.signal}:{}}),async p=>{try{l(p.ok?await p.json():null)}catch{l(null)}},()=>l(null))}),b=l=>{if(me(n),dt=null,l&&te(l),_||X)return;const p=Ft;qt=Date.now()+p,Ft=Math.min(p*2,We),jt||(jt=!0,ut=!0,k(()=>{ut=!1,mt(t)},p))};dt=I(i,b,()=>b(null))};if(g){const t=v?v(`${T()}/p`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({a:g,pwa:Bt(),notification_open:Yt})}):Promise.resolve(null);ct=I(t,async e=>{if(!(!e||!e.ok))try{const n=await e.json();te(n),n&&n.show_overlay===!1&&(zt=!1)}catch{}},()=>{})}const Ge=t=>{if(!t||typeof t.src!="string")return!1;if(t.dataset?.appdeployPwaInstall==="1")return!0;try{const e=new URL(t.src,window.location.href);return e.pathname.endsWith(`/${lt}`)&&e.pathname.includes("/@khmyznikov/pwa-install")}catch{return t.src.includes(lt)}},Ke=()=>Array.from(document.querySelectorAll("script[src]")).find(Ge)||null;let ht=null;const Je=()=>document.getElementById(st)||document.querySelector(R),ee=t=>{if(!t||!ht)return;const e=()=>{try{t.externalPromptEvent=ht}catch{}};if(typeof window.customElements<"u"&&typeof window.customElements.whenDefined=="function"&&!window.customElements.get(R)){window.customElements.whenDefined(R).then(e).catch(()=>{});return}e()},Ze=t=>{ht=t,typeof t.preventDefault=="function"&&t.preventDefault(),ee(Je())};pt&&window.addEventListener("beforeinstallprompt",Ze,!0);const tn=()=>{const t=Array.from(document.querySelectorAll("link[rel][href]")).find(i=>`${i.getAttribute("rel")||""} ${i.rel||""}`.toLowerCase().split(/\s+/).includes("manifest"))||null,e=typeof t?.href=="string"?t.href.trim():"",n=t?.getAttribute("href")?.trim()||"";return e||n||$e},en=()=>{if(typeof window.customElements<"u"&&window.customElements.get(R)||Ke())return;const t=document.createElement("script");t.src=He,t.async=!0,t.integrity=Ye,t.crossOrigin="anonymous",t.dataset.appdeployPwaInstall="1",(document.head||document.documentElement).appendChild(t)},nn=()=>{const t=Array.from(document.querySelectorAll(R)),n=t.find(i=>i.id===st)||t[0]||document.createElement(R);n.id=st,n.setAttribute("manifest-url",tn()),n.setAttribute("disable-screenshots","true"),n.setAttribute("use-local-storage","true"),!n.isConnected&&document.body&&document.body.appendChild(n),ee(n);for(const i of t)i!==n&&i.remove()},ne=()=>{!pt||!document.body||(nn(),en())},W=t=>{!g||typeof t!="string"||t.length===0||v&&v(`${T()}/metrics`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({a:g,metric:t})}).catch(()=>{})},oe=()=>{const t=document.querySelector('meta[property="og:title"]');return t?t.content:document.title||"Check out this app"},re=()=>{const t=document.querySelector('meta[property="og:url"]');return t?t.content:window.location.href},ie=()=>{const t=document.querySelector('meta[property="og:description"]');if(t)return t.content;const e=document.querySelector('meta[name="description"]');return e?e.content:""},on=`
        .appdeploy-overlay {
            position: fixed !important;
            bottom: 16px !important;
            right: 16px !important;
            left: auto !important;
            top: auto !important;
            z-index: 999999 !important;
            display: flex !important;
            flex-direction: row !important;
            align-items: center !important;
            justify-content: flex-end !important;
            gap: 8px !important;
            width: auto !important;
            height: auto !important;
            margin: 0 !important;
            padding: 8px !important;
            background: rgba(30, 41, 59, 0.4) !important;
            backdrop-filter: blur(8px) !important;
            -webkit-backdrop-filter: blur(8px) !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            border-radius: 14px !important;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15) !important;
            font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
            box-sizing: border-box !important;
        }

        .appdeploy-btn {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            width: 36px !important;
            min-width: 36px !important;
            max-width: 36px !important;
            height: 36px !important;
            min-height: 36px !important;
            max-height: 36px !important;
            border: none !important;
            border-radius: 8px !important;
            cursor: pointer !important;
            transition: all 0.15s ease !important;
            position: relative !important;
            background: rgba(255, 255, 255, 0.15) !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            box-shadow: none !important;
            color: rgba(255, 255, 255, 0.85) !important;
            text-decoration: none !important;
            padding: 0 !important;
            margin: 0 !important;
            box-sizing: border-box !important;
            flex-shrink: 0 !important;
            flex-grow: 0 !important;
            overflow: hidden !important;
        }

        .appdeploy-btn:hover {
            background: rgba(255, 255, 255, 0.25) !important;
            box-shadow: none !important;
            transform: none !important;
            color: #fff !important;
        }

        .appdeploy-btn:active {
            background: rgba(255, 255, 255, 0.3) !important;
            transform: none !important;
        }

        .appdeploy-btn svg {
            width: 22px !important;
            min-width: 22px !important;
            max-width: 22px !important;
            height: 22px !important;
            min-height: 22px !important;
            max-height: 22px !important;
            flex-shrink: 0 !important;
            display: block !important;
        }

        .appdeploy-btn--brand {
            padding: 0 !important;
        }

        .appdeploy-btn--brand svg {
            width: 20px !important;
            min-width: 20px !important;
            max-width: 20px !important;
            height: 20px !important;
            min-height: 20px !important;
            max-height: 20px !important;
        }

        /* Tooltip */
        .appdeploy-btn[data-tooltip]::before {
            content: attr(data-tooltip);
            position: absolute !important;
            bottom: calc(100% + 8px) !important;
            right: 0 !important;
            left: auto !important;
            top: auto !important;
            padding: 6px 10px !important;
            background: rgba(30, 41, 59, 0.9) !important;
            color: #fff !important;
            font-size: 12px !important;
            font-weight: 500 !important;
            white-space: nowrap !important;
            border-radius: 6px !important;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.15s, visibility 0.15s !important;
            pointer-events: none !important;
            width: auto !important;
            height: auto !important;
            margin: 0 !important;
            border: none !important;
            box-shadow: none !important;
        }

        .appdeploy-btn[data-tooltip]:hover::before {
            opacity: 1;
            visibility: visible;
        }

        /* Share bubble - hidden by default */
        .appdeploy-share-bubble {
            position: absolute !important;
            bottom: calc(100% + 12px) !important;
            right: 44px !important;
            left: auto !important;
            top: auto !important;
            display: none !important;
            flex-direction: row !important;
            gap: 6px !important;
            padding: 8px !important;
            margin: 0 !important;
            background: rgba(255, 255, 255, 0.95) !important;
            backdrop-filter: blur(12px) !important;
            -webkit-backdrop-filter: blur(12px) !important;
            border-radius: 12px !important;
            border: none !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15) !important;
            animation: appdeploy-fade-in 0.15s ease !important;
            box-sizing: border-box !important;
            width: auto !important;
            height: auto !important;
        }

        .appdeploy-share-bubble.is-open {
            display: flex !important;
        }

        .appdeploy-share-bubble-btn {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            width: 36px !important;
            min-width: 36px !important;
            max-width: 36px !important;
            height: 36px !important;
            min-height: 36px !important;
            max-height: 36px !important;
            border: none !important;
            border-radius: 8px !important;
            cursor: pointer !important;
            background: transparent !important;
            color: #64748b !important;
            transition: all 0.15s ease !important;
            padding: 0 !important;
            margin: 0 !important;
            box-sizing: border-box !important;
            flex-shrink: 0 !important;
            flex-grow: 0 !important;
        }

        .appdeploy-share-bubble-btn:hover {
            background: rgba(0, 0, 0, 0.05) !important;
        }

        .appdeploy-share-bubble-btn svg {
            width: 20px !important;
            min-width: 20px !important;
            max-width: 20px !important;
            height: 20px !important;
            min-height: 20px !important;
            max-height: 20px !important;
            flex-shrink: 0 !important;
            display: block !important;
        }

        /* Social colors on hover */
        .appdeploy-share-bubble-btn--x:hover { color: #000 !important; }
        .appdeploy-share-bubble-btn--facebook:hover { color: #1877f2 !important; }
        .appdeploy-share-bubble-btn--reddit:hover { color: #ff4500 !important; }
        .appdeploy-share-bubble-btn--linkedin:hover { color: #0a66c2 !important; }
        .appdeploy-share-bubble-btn--email:hover { color: #64748b !important; }

        .appdeploy-close-btn {
            position: absolute !important;
            top: -6px !important;
            right: -6px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            width: 20px !important;
            height: 20px !important;
            padding: 0 !important;
            border: 2px solid rgba(30, 41, 59, 0.6) !important;
            border-radius: 50% !important;
            background: rgba(71, 85, 105, 0.9) !important;
            color: #fff !important;
            cursor: pointer !important;
            box-sizing: border-box !important;
            z-index: 1 !important;
        }

        .appdeploy-close-btn:hover {
            background: rgb(51, 65, 85) !important;
        }

        .appdeploy-close-btn svg {
            display: block !important;
            width: 10px !important;
            height: 10px !important;
        }

        @keyframes appdeploy-fade-in {
            from { opacity: 0; transform: translateY(4px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Mobile adjustments */
        @media (max-width: 480px) {
            .appdeploy-overlay {
                bottom: 12px !important;
                right: 12px !important;
                padding: 6px !important;
                border-radius: 12px !important;
            }

            .appdeploy-btn {
                width: 32px !important;
                min-width: 32px !important;
                max-width: 32px !important;
                height: 32px !important;
                min-height: 32px !important;
                max-height: 32px !important;
            }

            .appdeploy-btn svg {
                width: 18px !important;
                min-width: 18px !important;
                max-width: 18px !important;
                height: 18px !important;
                min-height: 18px !important;
                max-height: 18px !important;
            }

            .appdeploy-btn--brand {
                padding: 5px !important;
            }

            .appdeploy-btn--brand svg {
                width: 20px !important;
                min-width: 20px !important;
                max-width: 20px !important;
                height: 20px !important;
                min-height: 20px !important;
                max-height: 20px !important;
            }

            .appdeploy-share-bubble {
                right: 40px !important;
            }
        }

        /* Hide tooltip on touch devices */
        @media (hover: none) {
            .appdeploy-btn[data-tooltip]::before {
                display: none !important;
            }
        }
    `,U={share:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="18" cy="5" r="3"></circle>
            <circle cx="6" cy="12" r="3"></circle>
            <circle cx="18" cy="19" r="3"></circle>
            <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
            <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
        </svg>`,x:`<svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
        </svg>`,facebook:`<svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>`,reddit:`<svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z"/>
        </svg>`,linkedin:`<svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
        </svg>`,email:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
            <polyline points="22,6 12,13 2,6"></polyline>
        </svg>`,chatgpt:`<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997Z"/>
        </svg>`,logo:`<svg viewBox="0 0 600 600" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M23.976 488.639L25.5262 256.101C25.8001 214.012 53.3411 185.964 95.8715 169.907L256.042 120.118C308.771 104.613 360.064 151.65 359.697 207.516L358.147 440.054C357.873 482.143 328.298 504.914 287.801 526.248L127.631 576.038C72.8681 596.033 23.6246 544.505 23.976 488.639Z" fill="white" fill-opacity="0.4"/>
            <path d="M141.141 371.516L142.691 138.978C142.965 96.8886 170.506 68.8407 213.037 52.7841L373.207 2.99503C425.936 -12.51 477.229 34.5271 476.862 90.3931L475.312 322.931C475.038 365.02 445.463 387.791 404.966 409.125L244.796 458.915C190.033 478.91 140.79 427.382 141.141 371.516Z" fill="white" fill-opacity="0.6"/>
            <path d="M240.295 508.192L241.846 275.653C242.119 233.564 269.66 205.516 312.191 189.46L472.361 139.671C525.09 124.166 576.383 171.203 576.016 227.069L574.466 459.606C574.192 501.696 544.617 524.467 504.121 545.8L343.95 595.59C289.187 615.586 239.944 564.058 240.295 508.192Z" fill="white" fill-opacity="0.8"/>
            <path d="M415.232 218.876L421.685 267.985C427.457 311.908 456.421 338.037 493.691 332.943L535.362 327.247L493.552 349.889C456.158 370.141 426.602 416.135 420.075 464.233L412.778 518.009L406.324 468.9C400.553 424.977 371.588 398.848 334.318 403.942L292.647 409.638L334.457 386.995C371.852 366.744 401.408 320.75 407.934 272.652L415.232 218.876Z" fill="black"/>
        </svg>`,close:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>`},rn=()=>typeof navigator.share!="function"?!1:"ontouchstart"in window||navigator.maxTouchPoints>0,an=async()=>{const t=oe(),e=re(),n=ie();try{await navigator.share({title:t,text:n||`Check out ${t}!`,url:e})}catch(i){i.name!=="AbortError"&&console.warn("[AppDeploy] Share failed:",i)}},sn=()=>{const t=oe(),e=encodeURIComponent(re()),n=encodeURIComponent(`Check out ${t}!`),i=encodeURIComponent(ie()||`Check out ${t}!`);return{x:`https://twitter.com/intent/tweet?text=${n}&url=${e}`,facebook:`https://www.facebook.com/sharer/sharer.php?u=${e}`,reddit:`https://reddit.com/submit?url=${e}&title=${encodeURIComponent(t)}`,linkedin:`https://www.linkedin.com/sharing/share-offsite/?url=${e}`,email:`mailto:?subject=${encodeURIComponent(t)}&body=${i}%0A%0A${e}`}},ln=/^[a-f0-9]{36}$/i,pn=()=>globalThis.crypto?.getRandomValues?Array.from(globalThis.crypto.getRandomValues(new Uint8Array(18)),t=>t.toString(16).padStart(2,"0")).join(""):`${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`,ft=P?.overlayStyleToken||document.currentScript?.dataset?.appdeployOverlayStyle,ae=`appdeploy-overlay-${typeof ft=="string"&&ln.test(ft)?ft:pn()}`,Q=["all:initial","display:block","position:fixed","inset:auto 0 0 auto","width:0","height:0","margin:0","padding:0","border:0","background:transparent","opacity:1","visibility:visible","pointer-events:auto","z-index:2147483647","transform:none","filter:none","clip-path:none","content-visibility:visible","contain:none","overflow:visible","isolation:isolate"].map(t=>`${t} !important`).join(";");let m,A,se,C,D=!1,yt=null,G=null;const cn=250,dn=1e3,un=()=>{if(document.fullscreenElement)return document.fullscreenElement;try{const t=document.querySelectorAll("dialog:modal");if(t.length)return t[t.length-1]}catch{}try{const t=document.querySelectorAll("dialog[open]");if(t.length)return t[t.length-1]}catch{}return document.documentElement},le=()=>{if(m)try{et(m),xt(m)}catch{}},mn=()=>{if(!m||!A||!C)return null;try{if(!m.matches(":popover-open"))return"closed";const t=tt(A),e=tt(C);if(t.width<=0||t.height<=0)return null;const n=t.top+t.height/2,i=[.1,.3,.5,.7,.9].map(b=>[t.left+t.width*b,n]);i.push([e.left+e.width/2,e.top+e.height/2]);for(const[b,l]of i){const p=he(b,l);if(!p)return null;if(p!==m)return p}return!0}catch{return null}},bt=()=>{D||yt!==null||(yt=k(()=>{if(yt=null,D)return;const t=mn();t===!0?G=null:(t==="closed"||t&&t!==G)&&(t!=="closed"&&(G=t),le())},cn))},hn=t=>{try{const e=t?.target;e&&e!==m&&Y(e,"popover")&&(G=null)}catch{}bt()},pe=()=>{c||D||k(()=>{bt(),pe()},dn)},K=()=>{if(!m||D)return;let t=!1;de(m,"style")!==Q&&(y(m,"style",Q),t=!0),Y(m,"hidden")&&(wt(m,"hidden"),t=!0),Y(m,"popover")||(y(m,"popover","manual"),t=!0);let e=m;for(;e;){Y(e,"inert")&&(wt(e,"inert"),t=!0);try{vt(e)&&(At(e,!1),t=!0)}catch{}if(e===document.documentElement)break;e=e.parentNode}const n=un();m.parentNode!==n&&(u(n,m),t=!0),t?le():bt()},ce=()=>{if(!D){D=!0,c?.stopRepair?.(),A&&y(A,"style","display:none !important");try{m&&et(m)}catch{}}},fn=t=>{if(!t?.isTrusted||!C)return!1;if(t.type==="keydown")return(t.key==="Enter"||t.key===" ")&&se?.activeElement===C;if(typeof t.clientX!="number"||typeof t.clientY!="number")return!1;const e=tt(C);return t.clientX>=e.left&&t.clientX<=e.right&&t.clientY>=e.top&&t.clientY<=e.bottom};c?.setTrustedInputHandler&&c.setTrustedInputHandler(t=>{fn(t)&&(t.preventDefault?.(),t.stopImmediatePropagation?.(),ce())});const yn=()=>{m=d(ae),y(m,"style",Q),y(m,"popover","manual"),z(document,"toggle",hn,!0);const t=_t(m,{mode:"closed"});se=t;const e=d("style");e.textContent=on,u(t,e),A=d("div"),A.className="appdeploy-overlay";const n=d("div");n.className="appdeploy-share-bubble";const i=sn();[{key:"x",label:"Share on X"},{key:"facebook",label:"Share on Facebook"},{key:"reddit",label:"Share on Reddit"},{key:"linkedin",label:"Share on LinkedIn"},{key:"email",label:"Share via Email"}].forEach(({key:o,label:f})=>{const s=d("button");s.className=`appdeploy-share-bubble-btn appdeploy-share-bubble-btn--${o}`,s.setAttribute("aria-label",f),s.innerHTML=U[o],s.addEventListener("click",w=>{w.preventDefault(),w.stopPropagation(),o==="email"?window.location.href=i[o]:window.open(i[o],"_blank","noopener,noreferrer,width=600,height=400"),n.classList.remove("is-open")}),u(n,s)});const l=d("button");l.className="appdeploy-btn",l.setAttribute("data-tooltip","Share with friends"),l.setAttribute("aria-label","Share this app"),l.innerHTML=U.share;let p=!1;l.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),W("share-button-click"),rn()?an():(p=!p,n.classList.toggle("is-open",p))}),document.addEventListener("click",o=>{p&&!n.contains(o.target)&&o.target!==l&&(p=!1,n.classList.remove("is-open"))});const h=d("a");h.className="appdeploy-btn",h.setAttribute("data-tooltip","Build your own in ChatGPT"),h.setAttribute("aria-label","Open AppDeploy in the ChatGPT app store"),h.href="https://chatgpt.com/plugins/plugin_asdk_app_6956e6ff740481919946ceae8e5d6304",h.target="_blank",h.rel="noopener",h.innerHTML=U.chatgpt,h.addEventListener("click",()=>{W("chatgpt-store-click")});const r=d("a");r.className="appdeploy-btn appdeploy-btn--brand",r.setAttribute("data-tooltip","Built with AppDeploy"),r.setAttribute("aria-label","Go to AppDeploy website"),r.href=g?`https://appdeploy.ai?ref=overlay&from_app=${encodeURIComponent(g)}&utm_source=appdeploy_overlay&utm_medium=referral`:"https://appdeploy.ai?ref=overlay&utm_source=appdeploy_overlay&utm_medium=referral",r.target="_blank",r.rel="noopener",r.innerHTML=U.logo,r.addEventListener("click",()=>{W("appdeploy-site-click")});const a=d("button");C=a,c?.registerOverlayCloseControl?.(a),a.className="appdeploy-close-btn",a.setAttribute("aria-label","Close overlay"),a.innerHTML=U.close,z(a,"click",o=>{o.isTrusted&&(o.preventDefault(),o.stopPropagation(),ce())}),u(A,n),u(A,l),u(A,h),u(A,r),u(A,a),u(t,A),K(),c?.setRepairHandler?c.setRepairHandler(K):(ue(K).observe(document.documentElement,{attributes:!0,attributeFilter:["style","hidden","inert","open","popover"],childList:!0,subtree:!0}),k(K,0),pe())};pt&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",ne):ne(),document.addEventListener("click",t=>{if(typeof t.composedPath!="function")return;const e=t.composedPath(),n=e.findIndex(l=>(l?.tagName??"").toLowerCase()===R);n===-1||!e.slice(0,n).some(l=>{const p=(l?.tagName??"").toLowerCase(),h=String(l?.className??"").toLowerCase();return p==="button"&&h.includes("install")})||W("pwa-install-click")}));const J=()=>{Ht&&zt&&!m&&yn()};Ht&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{I(ct,J,J)}):I(ct,J,J))})();
