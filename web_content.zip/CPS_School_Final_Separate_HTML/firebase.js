// CPS shared Firebase setup — project: school-adms
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import { getAuth, GoogleAuthProvider } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
export const firebaseConfig={apiKey:"AIzaSyC8E9vlcpU4hXwJBHqtwqmxGbPMEKrOs1M",authDomain:"school-adms.firebaseapp.com",projectId:"school-adms",storageBucket:"school-adms.firebasestorage.app",messagingSenderId:"5220075846",appId:"1:5220075846:web:e6cdecba8d49a04aa4fd47",measurementId:"G-Q5TJ7YTK9V"};
export const app=initializeApp(firebaseConfig); export const auth=getAuth(app); export const db=getFirestore(app); export const googleProvider=new GoogleAuthProvider();
