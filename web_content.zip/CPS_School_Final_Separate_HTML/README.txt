CPS School Website Firebase Package

1. Keep index.html and the assets folder together.
2. Open index.html in a browser for local UI review; Firebase Auth/Firestore may require HTTPS hosting and correct Firebase settings.
3. Deploy this folder with Firebase Hosting after reviewing firestore.rules and deploying any required trusted backend functions.
4. Never expose service-account private keys in frontend files.
