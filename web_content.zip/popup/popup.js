const EXT = globalThis.browser ?? globalThis.chrome;

const state = {
  enabled: false,
  feedback: 0.00,
  delay: 0.00,
  mic: false,
  ipxb: false
};

function updateUI() {
  const switchKnob = document.getElementById('switchKnob');
  const switchText = document.getElementById('switchText');
  
  if (state.enabled) {
    document.body.classList.add('active');
    switchKnob.classList.remove('btn-off');
    switchKnob.classList.add('btn-on');
    switchText.textContent = 'ON';
  } else {
    document.body.classList.remove('active');
    switchKnob.classList.remove('btn-on');
    switchKnob.classList.add('btn-off');
    switchText.textContent = 'OFF';
  }

  document.getElementById('feedback').value = state.feedback;
  document.getElementById('feedbackVal').textContent = parseFloat(state.feedback).toFixed(2);

  document.getElementById('delay').value = state.delay;
  document.getElementById('delayVal').textContent = parseFloat(state.delay).toFixed(2);

  const micBtn = document.getElementById('micToggle');
  const ipxbBtn = document.getElementById('ipxbToggle');

  if (state.mic) micBtn.classList.add('active');
  else micBtn.classList.remove('active');

  if (state.ipxb) ipxbBtn.classList.add('active');
  else ipxbBtn.classList.remove('active');
}

function saveState() {
  if (EXT?.storage?.local) {
    EXT.storage.local.set({ micAppConfig: state });
  }
}

function loadState() {
  if (EXT?.storage?.local) {
    EXT.storage.local.get('micAppConfig', (res) => {
      if (res && res.micAppConfig) {
        Object.assign(state, res.micAppConfig);
      }
      updateUI();
    });
  } else {
    updateUI();
  }
}

function init() {
  document.getElementById('switchKnob').addEventListener('click', () => {
    state.enabled = !state.enabled;
    updateUI();
    saveState();
  });

  document.getElementById('feedback').addEventListener('input', (e) => {
    state.feedback = e.target.value;
    document.getElementById('feedbackVal').textContent = parseFloat(state.feedback).toFixed(2);
    saveState();
  });

  document.getElementById('delay').addEventListener('input', (e) => {
    state.delay = e.target.value;
    document.getElementById('delayVal').textContent = parseFloat(state.delay).toFixed(2);
    saveState();
  });

  document.getElementById('micToggle').addEventListener('click', () => {
    state.mic = !state.mic;
    updateUI();
    saveState();
  });

  document.getElementById('ipxbToggle').addEventListener('click', () => {
    state.ipxb = !state.ipxb;
    updateUI();
    saveState();
  });

  loadState();
}

document.addEventListener('DOMContentLoaded', init);