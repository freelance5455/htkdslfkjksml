// Omni Messenger Lord v4 — popup controller. Developer: Mahir.
const EXT = globalThis.browser ?? globalThis.chrome;
const HAS_PROMISE_API = typeof globalThis.browser !== 'undefined' && EXT === globalThis.browser;

const PRESETS = {
  studio: {
    label: 'Studio HD',
    enabled: true, gainDb: 48, loudness: 6, maxBoost: 2000, drive: 0.6,
    thresholdDb: -42, ratio: 10, limiterDb: -1.5,
    presenceDb: 6, lowShelfDb: 2, highShelfDb: 4,
    sustain: true, sustainTargetDb: -10, sustainMaxGain: 10, forceRawMic: true,
    noiseGate: true, gateThresholdDb: -50, deEsserDb: -3, mudCutDb: -3
  },
  royal: {
    label: 'Royal Clear',
    enabled: true, gainDb: 24, loudness: 4, maxBoost: 2000, drive: 0.28,
    thresholdDb: -38, ratio: 12, limiterDb: -2,
    presenceDb: 8, lowShelfDb: 4, highShelfDb: 6,
    sustain: true, sustainTargetDb: -8, sustainMaxGain: 12, forceRawMic: true,
    noiseGate: true, gateThresholdDb: -54, deEsserDb: -2, mudCutDb: -2
  },
  lord: {
    label: 'Lord',
    enabled: true, gainDb: 84, loudness: 20, maxBoost: 5000, drive: 1.8,
    thresholdDb: -60, ratio: 20, limiterDb: -0.1,
    presenceDb: 20, lowShelfDb: 14, highShelfDb: 16,
    sustain: true, sustainTargetDb: -2, sustainMaxGain: 64, forceRawMic: true,
    noiseGate: false, gateThresholdDb: -50, deEsserDb: 0, mudCutDb: 0
  }
};
const DEFAULTS = { ...PRESETS.studio };
delete DEFAULTS.label;
const ids = Object.keys(DEFAULTS);
const PRESET_KEYS = Object.keys(PRESETS);
const $ = (id) => document.getElementById(id);

function storageGet(key) {
  if (HAS_PROMISE_API) return EXT.storage.local.get(key);
  return new Promise((resolve) => {
    try {
      EXT.storage.local.get(key, (res) => resolve(EXT.runtime?.lastError ? {} : res || {}));
    } catch (_) { resolve({}); }
  });
}

function storageSet(value) {
  if (HAS_PROMISE_API) return EXT.storage.local.set(value);
  return new Promise((resolve) => {
    try {
      EXT.storage.local.set(value, () => resolve(!EXT.runtime?.lastError));
    } catch (_) { resolve(false); }
  });
}

function sendMessage(message) {
  if (HAS_PROMISE_API) return EXT.runtime.sendMessage(message);
  return new Promise((resolve) => {
    try {
      EXT.runtime.sendMessage(message, (res) => resolve(EXT.runtime?.lastError ? null : res || null));
    } catch (_) { resolve(null); }
  });
}

function numberText(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return String(value);
  return Number.isInteger(n) ? String(n) : n.toFixed(Math.abs(n) < 10 ? 2 : 1).replace(/\.?0+$/, '');
}

function paintRange(el) {
  const min = Number(el.min || 0);
  const max = Number(el.max || 100);
  const pct = max > min ? ((Number(el.value) - min) / (max - min)) * 100 : 0;
  el.style.setProperty('--pct', `${Math.min(100, Math.max(0, pct))}%`);
}

function updateDial() {
  const g = $('gainDb');
  const arc = $('arc');
  const val = $('dialVal');
  if (!g || !arc) return;
  const f = Math.min(1, Math.max(0, Number(g.value) / Number(g.max || 120)));
  arc.style.strokeDasharray = `${(f * 653.5).toFixed(1)} 654`;
  if (val) val.textContent = numberText(g.value);
}

function updateLabels() {
  ids.forEach((id) => {
    const el = $(id);
    if (!el || el.type === 'checkbox') return;
    const label = $(`${id}Val`);
    if (label) {
      const next = numberText(el.value);
      if (label.textContent && label.textContent !== next) {
        label.classList.remove('pop');
        void label.offsetWidth;
        label.classList.add('pop');
      }
      label.textContent = next;
    }
    paintRange(el);
  });
  updateDial();
}

function presetMatches(config, preset) {
  return Object.entries(preset).every(([key, value]) => key === 'label' || config[key] === value || Number(config[key]) === Number(value));
}

function activePreset(config) {
  return PRESET_KEYS.find((key) => presetMatches(config, PRESETS[key])) || 'custom';
}

function updatePresetState(config) {
  const active = activePreset(config);
  const seg = document.querySelector('.seg');
  if (seg) seg.dataset.pos = active === 'custom' ? 'none' : String(PRESET_KEYS.indexOf(active));
  document.body.dataset.off = config.enabled ? '0' : '1';
  PRESET_KEYS.forEach((key) => {
    const button = $(`${key}Preset`);
    button?.classList.toggle('active', active === key);
    button?.setAttribute('aria-pressed', String(active === key));
  });
}

function applyToControls(config) {
  ids.forEach((id) => {
    const el = $(id);
    if (!el) return;
    if (el.type === 'checkbox') el.checked = Boolean(config[id]);
    else el.value = config[id];
  });
  updateLabels();
  updatePresetState(config);
}

async function readConfig() {
  const stored = await storageGet('micMaximizerConfig');
  return { ...DEFAULTS, ...(stored.micMaximizerConfig || {}) };
}

async function saveConfig(config) {
  const merged = { ...DEFAULTS, ...config };
  await storageSet({ micMaximizerConfig: merged });
  applyToControls(merged);
}

async function onControlInput(id, el) {
  const merged = await readConfig();
  merged[id] = el.type === 'checkbox' ? el.checked : Number(el.value);
  await saveConfig(merged);
}

async function init() {
  if (!EXT?.storage?.local) return;
  applyToControls(await readConfig());
  ids.forEach((id) => {
    const el = $(id);
    if (!el) return;
    el.addEventListener('input', () => onControlInput(id, el));
  });
  PRESET_KEYS.forEach((key) => {
    $(`${key}Preset`)?.addEventListener('click', async () => {
      const { label, ...values } = PRESETS[key];
      await saveConfig(values);
    });
  });
}

async function refreshHookStatus() {
  const box = $('hookStatus');
  if (!box || !EXT?.runtime) return;
  const text = box.querySelector('span');
  try {
    const status = await sendMessage({ type: 'MICMAX_STATUS_REQUEST' });
    const ageMs = status?.lastHeartbeat ? Date.now() - status.lastHeartbeat : Infinity;
    if (status?.ok && ageMs < 12000) {
      text.textContent = 'Active on Messenger';
      box.className = 'glass live ok';
    } else {
      text.textContent = 'Open / reload Messenger tab';
      box.className = 'glass live warn';
    }
  } catch (_) {
    text.textContent = 'Hook unavailable';
    box.className = 'glass live warn';
  }
}

init();
setInterval(refreshHookStatus, 3000);
refreshHookStatus();
