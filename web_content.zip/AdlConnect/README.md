# AdlConnect V7 — Client Intake & Contract Workflow Prototype

## Open
1. Extract this ZIP.
2. Open `AdlConnect/web/index.html` in a modern browser.
3. Select a role and accept the prototype agreement to enter.
4. Open **معرفی موکل** to fill out and review the client introduction form.
5. Open **قرارداد و امضا** to create a draft, review it, draw a sample signature, or print/save a PDF.
6. In **ثبت پرونده** and **ثبت درخواست پرونده**, choose **سایر پرونده‌ها** and provide the custom case type.

## Critical limitations
- This is an offline front-end prototype. Client information, files, signatures and contract drafts are not sent to a lawyer or saved to a secure server. Do not enter real confidential data.
- Role selection is only a browser-side demo control, not authorization.
- The signature canvas and typed names are demonstrations only. They do not provide identity verification, trusted timestamps, a digital certificate, an audit-grade evidence package, or a legally guaranteed electronic signature.
- Raw fingerprints must not be collected by this app. A production biometric confirmation should use device-controlled WebAuthn/Passkeys with a server challenge, explicit consent, and jurisdiction-specific compliance.
- Contract templates, e-signature methods, attorney fee disclosures, retention, privacy and cross-border transfers must be reviewed by qualified counsel in every launch jurisdiction. Some documents require advanced/qualified signatures, witnesses, notarization or wet signatures.
- No real payments, email/WhatsApp delivery, online meeting, database, encrypted document store, server-side authorization, or secure identity checks are connected.

## Production implementation plan
Use a secure API (for example NestJS), PostgreSQL with tenant/case-level authorization, private encrypted document storage, audited contract versions, reliable timestamps, identity checks proportionate to risk, and a vetted e-signature provider or jurisdiction-appropriate signature service. Integrate WhatsApp/email only after verified consent, and never expose API secrets in the browser.


## V8 additions
- Added a shared client/lawyer deletion-request panel requiring re-authentication fields and explicit typed confirmation in the UI. This is a demo only: password verification and deletion are NOT implemented; no data is deleted.
- Added a suggested Free Client, Solo Lawyer, Law Office, and usage-based add-on feature split with indicative launch price ranges. Prices are research hypotheses, not live offers.
- Before production, implement server-side re-authentication, authorization, legal-retention checks, revocation, audit events, backup lifecycle, and deletion completion receipts.
