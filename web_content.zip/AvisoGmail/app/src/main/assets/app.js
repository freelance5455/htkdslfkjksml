// La app Android expone un objeto "Android" (ver MainActivity.kt).
// Si abres este HTML en un navegador, se usa una simulación para ver el diseño.
const demo = {
  state: { logged: false, email: "", hour: 9, minute: 0, soundLabel: "Bling", customSound: false },
  ready() { onState(this.state); },
  signIn() { this.state.logged = true; this.state.email = "tu@gmail.com"; onState(this.state); onCount(3, "correos sin leer"); },
  signOut() { this.state.logged = false; onState(this.state); },
  setTime(h, m) { this.state.hour = h; this.state.minute = m; },
  pickSound() { this.state.soundLabel = "Sonido del sistema"; this.state.customSound = true; onState(this.state); },
  useBling() { this.state.soundLabel = "Bling"; this.state.customSound = false; onState(this.state); },
  test() { onMsg("Aviso de prueba (simulado)"); },
  refresh() {}
};
const A = window.Android || demo;

const $ = (id) => document.getElementById(id);
const pad = (n) => String(n).padStart(2, "0");

function onState(s) {
  $("email").textContent = s.logged ? s.email : "Sin sesión iniciada";
  $("btnLogin").hidden = s.logged;
  $("btnLogout").hidden = !s.logged;
  $("btnProbar").disabled = !s.logged;
  if (!s.logged) {
    $("count").textContent = "–";
    $("countLabel").textContent = "Inicia sesión para ver tus correos";
  }
  $("hora").value = pad(s.hour) + ":" + pad(s.minute);
  $("sonido").textContent = s.soundLabel;
  $("btnBling").hidden = !s.customSound;
}

function onCount(n, label) {
  $("count").textContent = n;
  $("countLabel").textContent = label;
}

let toastTimer;
function onMsg(text) {
  const t = $("toast");
  t.textContent = text;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 3500);
}

$("btnLogin").addEventListener("click", () => A.signIn());
$("btnLogout").addEventListener("click", () => A.signOut());
$("btnProbar").addEventListener("click", () => A.test());
$("rowSonido").addEventListener("click", () => A.pickSound());
$("btnBling").addEventListener("click", () => A.useBling());
$("hora").addEventListener("change", (e) => {
  const [h, m] = e.target.value.split(":").map(Number);
  if (!Number.isNaN(h) && !Number.isNaN(m)) A.setTime(h, m);
});

A.ready();
