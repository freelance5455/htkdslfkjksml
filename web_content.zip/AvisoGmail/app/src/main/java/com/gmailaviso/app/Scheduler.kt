package com.gmailaviso.app

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.time.Duration
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

/**
 * Programa el aviso de cada día a la hora elegida.
 * Cada ejecución programa la siguiente (más fiable que un periódico de 24 h).
 */
object Scheduler {
    private const val NAME = "aviso_diario"
    const val KEY_ATTEMPT = "attempt"

    fun scheduleDaily(ctx: Context) {
        enqueue(ctx, millisUntil(Prefs.hour(ctx), Prefs.minute(ctx)), 0)
    }

    fun scheduleRetry(ctx: Context, attempt: Int) {
        enqueue(ctx, TimeUnit.MINUTES.toMillis(30), attempt)
    }

    fun cancel(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
    }

    private fun enqueue(ctx: Context, delayMs: Long, attempt: Int) {
        val request = OneTimeWorkRequestBuilder<CheckWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf(KEY_ATTEMPT to attempt))
            .setConstraints(
                Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
            )
            .build()
        WorkManager.getInstance(ctx)
            .enqueueUniqueWork(NAME, ExistingWorkPolicy.REPLACE, request)
    }

    private fun millisUntil(hour: Int, minute: Int): Long {
        val now = ZonedDateTime.now()
        var next = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return Duration.between(now, next).toMillis()
    }
}
