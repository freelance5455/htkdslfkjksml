package com.gmailaviso.app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class CheckWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        if (Prefs.email(ctx) == null) return Result.success() // sin sesión: nada que hacer

        val attempt = inputData.getInt(Scheduler.KEY_ATTEMPT, 0)
        when (val outcome = Checker.run(ctx)) {
            is Outcome.Ok -> {
                Notifier.showSummary(ctx, outcome.summary)
                Scheduler.scheduleDaily(ctx)
            }
            Outcome.NeedsLogin -> {
                Notifier.showLoginNeeded(ctx)
                Scheduler.scheduleDaily(ctx)
            }
            is Outcome.Error -> {
                // Reintenta hasta 3 veces cada 30 min; después espera al día siguiente.
                if (attempt < 3) Scheduler.scheduleRetry(ctx, attempt + 1)
                else Scheduler.scheduleDaily(ctx)
            }
        }
        return Result.success()
    }
}
