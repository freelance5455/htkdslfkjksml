package com.gmailaviso.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Notifier {
    private const val CHANNEL_PREFIX = "aviso_"
    private const val NOTIF_ID = 1

    fun defaultSound(ctx: Context): Uri =
        Uri.parse("android.resource://${ctx.packageName}/${R.raw.bling}")

    /** null = silencio. */
    fun soundUri(ctx: Context): Uri? = when (val s = Prefs.sound(ctx)) {
        null -> defaultSound(ctx)
        "" -> null
        else -> Uri.parse(s)
    }

    /**
     * En Android el sonido va ligado al canal y no se puede cambiar después de crearlo,
     * así que cada sonido distinto tiene su propio canal y se borran los antiguos.
     */
    private fun ensureChannel(ctx: Context): String {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val uri = soundUri(ctx)
        val id = CHANNEL_PREFIX + (uri?.toString()?.hashCode() ?: 0).toString().replace("-", "n")

        if (nm.getNotificationChannel(id) == null) {
            val channel = NotificationChannel(
                id,
                ctx.getString(R.string.canal_nombre),
                NotificationManager.IMPORTANCE_HIGH
            )
            channel.setSound(
                uri,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            nm.createNotificationChannel(channel)
        }
        nm.notificationChannels
            .filter { it.id.startsWith(CHANNEL_PREFIX) && it.id != id }
            .forEach { nm.deleteNotificationChannel(it.id) }
        return id
    }

    fun showSummary(ctx: Context, s: Summary) {
        val title = when (s.unread) {
            0 -> ctx.getString(R.string.aviso_cero)
            1 -> ctx.getString(R.string.aviso_uno)
            else -> ctx.getString(R.string.aviso_varios, s.unread)
        }
        val builder = base(ctx).setContentTitle(title)

        if (s.latest.isEmpty()) {
            builder.setContentText(ctx.getString(R.string.aviso_al_dia))
        } else {
            val first = s.latest.first()
            builder.setContentText("${first.from} · ${first.subject}")
            val style = NotificationCompat.InboxStyle().setBigContentTitle(title)
            s.latest.forEach { style.addLine("${it.from} · ${it.subject}") }
            if (s.unread > s.latest.size) {
                style.setSummaryText(ctx.getString(R.string.aviso_y_mas, s.unread - s.latest.size))
            }
            builder.setStyle(style)
        }
        notify(ctx, builder)
    }

    fun showLoginNeeded(ctx: Context) {
        notify(
            ctx,
            base(ctx)
                .setContentTitle(ctx.getString(R.string.login_necesario_titulo))
                .setContentText(ctx.getString(R.string.login_necesario_texto))
        )
    }

    private fun base(ctx: Context): NotificationCompat.Builder {
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(ctx, ensureChannel(ctx))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EMAIL)
    }

    @SuppressLint("MissingPermission")
    private fun notify(ctx: Context, builder: NotificationCompat.Builder) {
        val allowed = android.os.Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (allowed) NotificationManagerCompat.from(ctx).notify(NOTIF_ID, builder.build())
    }
}
