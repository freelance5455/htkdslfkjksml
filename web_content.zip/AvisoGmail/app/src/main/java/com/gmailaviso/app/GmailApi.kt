package com.gmailaviso.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Mail(val from: String, val subject: String)
data class Summary(val unread: Int, val latest: List<Mail>)

/** El token ya no vale: hay que volver a iniciar sesión. */
class AuthExpired : Exception()

object GmailApi {
    private const val BASE = "https://gmail.googleapis.com/gmail/v1/users/me"

    suspend fun summary(token: String): Summary = withContext(Dispatchers.IO) {
        // Número de mensajes sin leer en la bandeja de entrada
        val label = JSONObject(get("$BASE/labels/INBOX", token))
        val unread = label.optInt("messagesUnread", 0)

        val mails = mutableListOf<Mail>()
        if (unread > 0) {
            val list = JSONObject(
                get("$BASE/messages?labelIds=INBOX&labelIds=UNREAD&maxResults=5", token)
            ).optJSONArray("messages")

            if (list != null) {
                for (i in 0 until list.length()) {
                    val id = list.getJSONObject(i).getString("id")
                    val msg = JSONObject(
                        get(
                            "$BASE/messages/$id?format=metadata" +
                                "&metadataHeaders=From&metadataHeaders=Subject",
                            token
                        )
                    )
                    val headers = msg.optJSONObject("payload")?.optJSONArray("headers")
                    var from = ""
                    var subject = ""
                    if (headers != null) {
                        for (j in 0 until headers.length()) {
                            val h = headers.getJSONObject(j)
                            when (h.getString("name").lowercase()) {
                                "from" -> from = h.getString("value")
                                "subject" -> subject = h.getString("value")
                            }
                        }
                    }
                    mails += Mail(cleanSender(from), subject.ifBlank { "(sin asunto)" })
                }
            }
        }
        Summary(unread, mails)
    }

    /** "Ana López <ana@x.com>" -> "Ana López" */
    private fun cleanSender(raw: String): String {
        val name = raw.substringBefore("<").trim().trim('"')
        return name.ifBlank { raw.trim('<', '>', ' ') }
    }

    private fun get(url: String, token: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 15_000
            conn.readTimeout = 15_000
            conn.setRequestProperty("Authorization", "Bearer $token")
            val code = conn.responseCode
            if (code == 401) throw AuthExpired()
            if (code !in 200..299) throw IOException("Gmail respondió HTTP $code")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
