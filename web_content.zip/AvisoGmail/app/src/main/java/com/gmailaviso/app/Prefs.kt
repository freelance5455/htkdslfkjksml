package com.gmailaviso.app

import android.content.Context

/** Ajustes guardados en el móvil. */
object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("aviso", Context.MODE_PRIVATE)

    fun email(ctx: Context): String? = sp(ctx).getString("email", null)
    fun setEmail(ctx: Context, v: String?) = sp(ctx).edit().putString("email", v).apply()

    fun hour(ctx: Context): Int = sp(ctx).getInt("hour", 9)
    fun minute(ctx: Context): Int = sp(ctx).getInt("minute", 0)
    fun setTime(ctx: Context, h: Int, m: Int) =
        sp(ctx).edit().putInt("hour", h).putInt("minute", m).apply()

    /** null = bling por defecto, "" = silencio, otro valor = URI del sonido elegido. */
    fun sound(ctx: Context): String? = sp(ctx).getString("sound", null)
    fun setSound(ctx: Context, v: String?) = sp(ctx).edit().putString("sound", v).apply()
}
