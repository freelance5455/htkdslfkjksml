package com.gmailaviso.app

import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.tasks.await

/** Inicio de sesión con Google + permiso de solo lectura sobre Gmail. */
object Auth {
    private val GMAIL_READONLY = Scope("https://www.googleapis.com/auth/gmail.readonly")

    private fun request(): AuthorizationRequest =
        AuthorizationRequest.builder()
            .setRequestedScopes(listOf(GMAIL_READONLY))
            .build()

    /** Si ya diste permiso devuelve el token sin mostrar nada; si no, trae un pendingIntent. */
    suspend fun authorize(ctx: Context): AuthorizationResult =
        Identity.getAuthorizationClient(ctx).authorize(request()).await()

    fun resultFromIntent(ctx: Context, data: Intent?): AuthorizationResult =
        Identity.getAuthorizationClient(ctx).getAuthorizationResultFromIntent(data)
}
