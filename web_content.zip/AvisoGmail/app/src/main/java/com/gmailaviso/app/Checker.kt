package com.gmailaviso.app

import android.content.Context
import kotlin.coroutines.cancellation.CancellationException

sealed class Outcome {
    data class Ok(val summary: Summary) : Outcome()
    object NeedsLogin : Outcome()
    data class Error(val message: String) : Outcome()
}

/** Pide un token y consulta Gmail. Lo usan la pantalla y el aviso diario. */
object Checker {
    suspend fun run(ctx: Context): Outcome = try {
        val auth = Auth.authorize(ctx)
        val token = auth.accessToken
        if (auth.hasResolution() || token == null) {
            Outcome.NeedsLogin
        } else {
            Outcome.Ok(GmailApi.summary(token))
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: AuthExpired) {
        Outcome.NeedsLogin
    } catch (e: Exception) {
        Outcome.Error(e.message ?: "Error desconocido")
    }
}
