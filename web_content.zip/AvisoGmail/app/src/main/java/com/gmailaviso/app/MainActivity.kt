package com.gmailaviso.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.auth.api.identity.AuthorizationResult
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * La pantalla es una página HTML (assets/index.html) dentro de un WebView.
 * Todo lo "de verdad" (login, Gmail, avisos, sonido) lo hace Kotlin a través del puente `Android`.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val authLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
            try {
                onAuthorized(Auth.resultFromIntent(this, res.data))
            } catch (e: Exception) {
                msg(getString(R.string.login_cancelado))
            }
        }

    private val soundLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == RESULT_OK) {
                val uri = res.data?.let {
                    IntentCompat.getParcelableExtra(
                        it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java
                    )
                }
                Prefs.setSound(this, uri?.toString() ?: "")
                pushState()
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            // Solo se permite la página local de la app
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ) = true
            }
            addJavascriptInterface(Bridge(), "Android")
        }
        setContentView(web)

        // Respeta la barra de estado y la de navegación
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        pushState()
        if (Prefs.email(this) != null) refreshCount()
    }

    // ---------- Puente HTML <-> Kotlin ----------

    /** Funciones que llama la página HTML. Se ejecutan en otro hilo, por eso runOnUiThread. */
    inner class Bridge {
        @JavascriptInterface fun ready() = runOnUiThread {
            pushState()
            if (Prefs.email(this@MainActivity) != null) refreshCount()
        }
        @JavascriptInterface fun signIn() = runOnUiThread { doSignIn() }
        @JavascriptInterface fun signOut() = runOnUiThread { doSignOut() }
        @JavascriptInterface fun setTime(h: Int, m: Int) = runOnUiThread {
            Prefs.setTime(this@MainActivity, h, m)
            if (Prefs.email(this@MainActivity) != null) Scheduler.scheduleDaily(this@MainActivity)
        }
        @JavascriptInterface fun pickSound() = runOnUiThread { doPickSound() }
        @JavascriptInterface fun useBling() = runOnUiThread {
            Prefs.setSound(this@MainActivity, null)
            pushState()
        }
        @JavascriptInterface fun test() = runOnUiThread { doTest() }
        @JavascriptInterface fun refresh() = runOnUiThread { refreshCount() }
    }

    private fun js(code: String) = web.evaluateJavascript(code, null)

    private fun pushState() {
        val sound = Prefs.sound(this)
        val label = when (sound) {
            null -> getString(R.string.sonido_bling)
            "" -> getString(R.string.sonido_silencio)
            else -> try {
                RingtoneManager.getRingtone(this, Uri.parse(sound)).getTitle(this)
            } catch (e: Exception) {
                getString(R.string.sonido_personalizado)
            }
        }
        val email = Prefs.email(this)
        val state = JSONObject()
            .put("logged", email != null)
            .put("email", email ?: "")
            .put("hour", Prefs.hour(this))
            .put("minute", Prefs.minute(this))
            .put("soundLabel", label)
            .put("customSound", sound != null)
        js("onState($state)")
    }

    private fun showCount(n: Int) {
        val label = resources.getQuantityString(R.plurals.sin_leer, n)
        js("onCount($n, ${JSONObject.quote(label)})")
    }

    private fun msg(text: String) = js("onMsg(${JSONObject.quote(text)})")

    // ---------- Sesión ----------

    private fun doSignIn() {
        lifecycleScope.launch {
            try {
                val r = Auth.authorize(this@MainActivity)
                if (r.hasResolution()) {
                    val pi = r.pendingIntent ?: return@launch
                    authLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                } else {
                    onAuthorized(r)
                }
            } catch (e: Exception) {
                msg(getString(R.string.error_login, e.message ?: ""))
            }
        }
    }

    private fun onAuthorized(r: AuthorizationResult) {
        val email = r.toGoogleSignInAccount()?.email ?: Prefs.email(this) ?: "Gmail"
        Prefs.setEmail(this, email)
        Scheduler.scheduleDaily(this)
        pushState()
        refreshCount()
    }

    private fun doSignOut() {
        Prefs.setEmail(this, null)
        Scheduler.cancel(this)
        pushState()
        msg(getString(R.string.sesion_cerrada))
    }

    // ---------- Consulta ----------

    private fun refreshCount() {
        lifecycleScope.launch {
            when (val o = Checker.run(this@MainActivity)) {
                is Outcome.Ok -> showCount(o.summary.unread)
                Outcome.NeedsLogin -> {
                    Prefs.setEmail(this@MainActivity, null)
                    pushState()
                }
                is Outcome.Error -> msg(getString(R.string.sin_conexion))
            }
        }
    }

    private fun doTest() {
        lifecycleScope.launch {
            when (val o = Checker.run(this@MainActivity)) {
                is Outcome.Ok -> {
                    showCount(o.summary.unread)
                    Notifier.showSummary(this@MainActivity, o.summary)
                }
                Outcome.NeedsLogin -> {
                    Prefs.setEmail(this@MainActivity, null)
                    pushState()
                }
                is Outcome.Error -> msg(o.message)
            }
        }
    }

    // ---------- Sonido ----------

    private fun doPickSound() {
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, getString(R.string.sonido_del_aviso))
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, false)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Notifier.soundUri(this))
        }
        soundLauncher.launch(intent)
    }
}
