# Aviso Gmail

App Android muy sencilla: una sola pantalla, inicias sesión con tu cuenta de Google y cada día, a la hora que elijas, te llega una notificación con los correos sin leer de tu bandeja de entrada y un sonido.

## Qué hace

- Inicio de sesión con Google dentro de la propia app (permiso de **solo lectura** de Gmail).
- Notificación diaria: número de correos sin leer y los 5 últimos (remitente · asunto).
- Sonido por defecto: **bling** (incluido en la app). Pulsa "Sonido" para elegir cualquier tono de notificación de tu móvil, o silencio.
- Hora del aviso configurable. Botón "Probar aviso ahora" para ver y oír cómo queda.

## Paso 1. Preparar Google Cloud (una sola vez)

Google exige esto a cualquier app que lea Gmail. Se hace en https://console.cloud.google.com

1. Crea un proyecto nuevo (por ejemplo "Aviso Gmail").
2. **APIs y servicios → Biblioteca** → busca **Gmail API** → Habilitar.
3. **APIs y servicios → Pantalla de consentimiento de OAuth**:
   - Tipo de usuario: **Externo**.
   - Rellena nombre de la app y tu correo.
   - En **Permisos (scopes)** añade `https://www.googleapis.com/auth/gmail.readonly`.
   - En **Usuarios de prueba** añade tu Gmail.
   - Cuando termines, pulsa **Publicar aplicación** (pasar a producción). Si la dejas en "Prueba", Google caduca el permiso cada 7 días y tendrías que volver a iniciar sesión. En producción sin verificar, al iniciar sesión verás un aviso de "app no verificada": pulsa **Avanzado → Continuar**. Es normal, la app es tuya.
4. **Credenciales → Crear credenciales → ID de cliente de OAuth**:
   - Tipo: **Android**.
   - Nombre del paquete: `com.gmailaviso.app`
   - Huella SHA-1: la de tu clave de depuración (ver abajo).

### Obtener el SHA-1 en Windows

En PowerShell:

```
keytool -list -v -keystore "$env:USERPROFILE\.android\debug.keystore" -alias androiddebugkey -storepass android -keypass android
```

Copia la línea `SHA1:` y pégala en Google Cloud. (Si no existe el archivo, compila la app una vez en Android Studio y se crea.) También sale en Android Studio → pestaña Gradle → `app → Tasks → android → signingReport`.

No hay que copiar ningún ID dentro del código: Google reconoce la app por el nombre de paquete y el SHA-1.

## Paso 2. Abrir y ejecutar

1. Instala **Android Studio** si no lo tienes y abre la carpeta `AvisoGmail`.
2. Deja que sincronice Gradle (si propone actualizar versiones del plugin, acepta).
3. En el móvil: Ajustes → Acerca del teléfono → pulsa 7 veces en "Número de compilación" → Opciones de desarrollador → activa **Depuración USB**.
4. Conecta el móvil por USB, acepta el aviso en el teléfono y pulsa ▶ **Run** en Android Studio.

## Paso 3. Usarla

1. Abre la app → **Iniciar sesión con Google** → elige tu cuenta y acepta el permiso de lectura.
2. Acepta el permiso de notificaciones.
3. Elige la hora y el sonido, y pulsa **Probar aviso ahora**.

## Para que no se pierda ningún aviso

Algunos móviles (Xiaomi, Samsung, Huawei, OPPO…) matan las apps en segundo plano. Si un día no llega el aviso:

- Ajustes → Apps → Aviso Gmail → Batería → **Sin restricciones**.
- Mantén las notificaciones activadas para la app.

Android puede retrasar el aviso unos minutos respecto a la hora elegida para ahorrar batería; es normal.

## Notas

- La cuenta se guarda solo en el móvil; la app no usa ningún servidor propio.
- Para quitar el permiso por completo: https://myaccount.google.com/permissions → Aviso Gmail → Eliminar acceso. "Cerrar sesión" en la app solo detiene los avisos y borra los datos locales.
- Se cuentan los mensajes sin leer de la bandeja de entrada (incluye pestañas como Promociones o Social).

## Interfaz en HTML

La pantalla es una página web local (HTML + CSS + JavaScript) que la app muestra dentro de un WebView. Está en `app/src/main/assets/`:

- `index.html` estructura de la pantalla
- `style.css` diseño (claro y oscuro)
- `app.js` lógica de la pantalla; habla con Kotlin mediante el objeto `Android`

Puedes abrir `index.html` directamente en el navegador del móvil o del PC para ver el diseño con datos simulados. El login, la consulta a Gmail, el aviso diario y el sonido siguen siendo Kotlin, porque una página web sola no puede hacerlos en segundo plano.

Una web no se puede instalar como app por sí sola en Android: para tener la app hay que compilar el APK (Build → Build APK(s) en Android Studio).

## Estructura

```
app/src/main/assets/   index.html, style.css, app.js (interfaz)
app/src/main/java/com/gmailaviso/app/
  MainActivity.kt   contenedor WebView y puente con la página
  Auth.kt           login con Google y permiso de Gmail
  GmailApi.kt       consulta de no leídos
  Checker.kt        pide token y consulta (compartido)
  Scheduler.kt      programa el aviso de cada día
  CheckWorker.kt    tarea que se ejecuta a la hora elegida
  Notifier.kt       notificación y canal con sonido
  Prefs.kt          ajustes guardados
app/src/main/res/raw/bling.wav   sonido por defecto
```
