
const $ = id => document.getElementById(id);

const DAYS = [
  {name:"Chest + Triceps",short:"Chest / Tri",groups:["Chest","Triceps"]},
  {name:"Back + Biceps",short:"Back / Bi",groups:["Back","Biceps"]},
  {name:"Legs",short:"Legs",groups:["Legs"]},
  {name:"Shoulders + Abs",short:"Shoulders / Abs",groups:["Shoulders","Abs"]},
  {name:"Arms + Core",short:"Arms / Core",groups:["Arms","Core"]},
  {name:"Full Body",short:"Full Body",groups:["Full Body"]},
  {name:"Active Recovery",short:"Recovery",groups:["Recovery"]}
];

const EXERCISES = {
  "Chest":[
    ["Barbell Bench Press",8],
    ["Incline Dumbbell Press",10],
    ["Dumbbell Flyes",12],
    ["Push-Ups",15],
    ["Decline Press",10],
    ["Cable Chest Fly",12],
    ["Machine Chest Press",10],
    ["Incline Push-Ups",15],
    ["Pec Deck",12],
    ["Dumbbell Pullover",12],
    ["Wide Push-Ups",12]
  ],

  "Triceps":[
    ["Close-Grip Bench Press",10],
    ["Cable Pushdowns",12],
    ["Overhead Triceps Extension",12],
    ["Skull Crushers",10],
    ["Bench Dips",12],
    ["Diamond Push-Ups",10]
  ],

  "Back":[
    ["Lat Pulldown",10],
    ["Barbell Row",8],
    ["Seated Cable Row",12],
    ["Single-Arm Dumbbell Row",10],
    ["Pull-Ups",6],
    ["Straight-Arm Pulldown",12],
    ["Chest-Supported Row",10],
    ["Back Extensions",12],
    ["Face Pulls",15],
    ["Reverse-Grip Row",10],
    ["Deadlift",6]
  ],

  "Biceps":[
    ["Barbell Curl",10],
    ["Dumbbell Hammer Curl",12],
    ["Preacher Curl",10],
    ["Incline Dumbbell Curl",12],
    ["Cable Curl",12],
    ["Concentration Curl",10]
  ],

  "Legs":[
    ["Barbell Squat",8],
    ["Leg Press",12],
    ["Romanian Deadlift",10],
    ["Walking Lunges",12],
    ["Leg Extension",12],
    ["Lying Leg Curl",12],
    ["Standing Calf Raise",15],
    ["Hip Thrust",10],
    ["Goblet Squat",12],
    ["Bulgarian Split Squat",10],
    ["Seated Calf Raise",15],
    ["Glute Bridge",15]
  ],

  "Shoulders":[
    ["Overhead Press",8],
    ["Dumbbell Lateral Raise",12],
    ["Front Raise",12],
    ["Rear Delt Fly",12],
    ["Arnold Press",10],
    ["Upright Row",10],
    ["Cable Lateral Raise",12]
  ],

  "Abs":[
    ["Crunches",15],
    ["Plank",30],
    ["Leg Raises",12],
    ["Bicycle Crunches",20],
    ["Russian Twists",20]
  ],

  "Arms":[
    ["EZ-Bar Curl",10],
    ["Rope Triceps Pushdown",12],
    ["Alternating Curl",12],
    ["Overhead Triceps Extension",12],
    ["Reverse Curl",12],
    ["Dips",10],
    ["Wrist Curl",15],
    ["Cable Hammer Curl",12]
  ],

  "Core":[
    ["Plank",30],
    ["Mountain Climbers",20],
    ["Dead Bug",12],
    ["Side Plank",30],
    ["Reverse Crunch",15]
  ],

  "Full Body":[
    ["Squat",10],
    ["Bench Press",8],
    ["Bent-Over Row",10],
    ["Overhead Press",10],
    ["Romanian Deadlift",10],
    ["Push-Ups",12],
    ["Lat Pulldown",10],
    ["Walking Lunges",12],
    ["Plank",30],
    ["Burpees",10],
    ["Dumbbell Thruster",10]
  ],

  "Recovery":[
    ["Easy Walk",10],
    ["Bodyweight Squat",12],
    ["Cat-Cow Stretch",10],
    ["Hip Flexor Stretch",30],
    ["Hamstring Stretch",30],
    ["Shoulder Mobility",12],
    ["Bird Dog",10],
    ["Glute Bridge",12]
  ]
};

const DEFAULT_STATE = {
  days:6,
  rest:60,
  steps:0,
  xp:0,
  history:[]
};

let state = loadState();
let activeDay = 0;
let sessionStart = null;
let sessionTicker = null;
let restTimers = {};
let exerciseTimers = {};
let sessionFinished = false;

function loadState(){
  try {
    return {
      ...DEFAULT_STATE,
      ...JSON.parse(localStorage.getItem("philbigFitness") || "{}")
    };
  } catch(error) {
    return {...DEFAULT_STATE};
  }
}

function saveState(){
  localStorage.setItem("philbigFitness",JSON.stringify(state));
}

function toast(message){
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");

  setTimeout(()=>{
    el.classList.remove("show");
  },2300);
}

function fmt(seconds){
  seconds = Math.max(0,Math.floor(seconds));

  return `${String(Math.floor(seconds/60)).padStart(2,"0")}:${String(seconds%60).padStart(2,"0")}`;
}

function schedule(){
  return Array.from({length:state.days},(_,i)=>DAYS[i]);
}

function exercisesFor(dayIndex){
  const day = DAYS[dayIndex];
  let list = [];

  day.groups.forEach(group=>{
    (EXERCISES[group] || []).forEach(([name,reps])=>{
      list.push({name,reps,group});
    });
  });

  return list;
}

function getAdaptiveReps(name,base){
  const recent = [...state.history]
    .reverse()
    .flatMap(h=>h.exercises || [])
    .find(e=>e.name===name && e.completedSets>0);

  return recent
    ? Math.max(4,Math.min(30,Math.round((recent.avgReps || base)+1)))
    : base;
}

function escapeHtml(value){
  return String(value).replace(/[&<>"']/g,char=>({
    "&":"&amp;",
    "<":"&lt;",
    ">":"&gt;",
    '"':"&quot;",
    "'":"&#39;"
  }[char]));
}

function showView(view){
  document.querySelectorAll(".view").forEach(el=>{
    el.classList.toggle("active",el.id===view);
  });

  document.querySelectorAll(".tab").forEach(el=>{
    el.classList.toggle("active",el.dataset.view===view);
  });

  if(view==="workout"){
    renderWorkout();
  }
}

document.querySelectorAll(".tab").forEach(button=>{
  button.addEventListener("click",()=>{
    showView(button.dataset.view);
  });
});

$("start-today").addEventListener("click",()=>{
  showView("workout");
  startSession();
});

$("day-select").addEventListener("change",event=>{
  activeDay = Number(event.target.value);
  sessionFinished = false;
  renderWorkout();
});

function renderSchedule(){
  $("days-label").textContent = `${state.days} days / week`;

  $("week-plan").innerHTML = schedule().map((day,index)=>`
    <div class="week-day">
      <b>DAY ${index+1}</b>
      <span>${day.short}</span>
    </div>
  `).join("");

  $("today-title").textContent = DAYS[0].name;
  $("today-subtitle").textContent =
    `${state.days} training days this week • Your next session starts here`;
}

function renderStats(){
  const total = state.history.length;

  const minutes = state.history.reduce(
    (sum,workout)=>sum+(workout.duration || 0),0
  );

  $("workouts-count").textContent = total;
  $("steps-count").textContent = Number(state.steps || 0).toLocaleString();
  $("minutes-count").textContent = Math.round(minutes/60);

  $("level").textContent = `LVL ${Math.floor(state.xp/500)+1}`;
  $("xp").textContent = `${state.xp} XP`;

  $("progress-workouts").textContent = total;
  $("progress-xp").textContent = state.xp;
  $("progress-time").textContent = `${Math.round(minutes/60)}m`;

  const percent = Math.min(100,(state.steps/8000)*100);

  $("step-progress").style.width = percent+"%";
  $("step-progress-label").textContent =
    `${Number(state.steps || 0).toLocaleString()} / 8,000`;

  $("step-percent").textContent = Math.round(percent)+"%";
  $("steps-input").value = state.steps || "";

  $("history-list").innerHTML = state.history.length
    ? [...state.history].reverse().slice(0,20).map(workout=>`
      <div class="history-item">
        <div>
          <strong>${escapeHtml(workout.title)}</strong>
          <small>
            ${new Date(workout.date).toLocaleString()}
            • ${workout.exerciseCount} exercises
          </small>
        </div>
        <div>
          <strong>${fmt(workout.duration)}</strong>
          <small>+${workout.xp} XP</small>
        </div>
      </div>
    `).join("")
    : '<p class="muted">No workouts completed yet.</p>';
}

function renderWorkout(){
  $("day-select").innerHTML = schedule().map((day,index)=>`
    <option value="${index}">
      ${index+1}. ${day.name}
    </option>
  `).join("");

  if(activeDay>=state.days){
    activeDay = 0;
  }

  $("day-select").value = activeDay;

  const list = exercisesFor(activeDay);

  $("exercise-count").textContent =
    `${list.length} exercises • 5 sets each`;

  $("exercise-list").innerHTML = list.map((exercise,index)=>{
    const reps = getAdaptiveReps(exercise.name,exercise.reps);
    const key = `${activeDay}-${index}`;

    return `
      <article class="exercise-card" data-key="${key}">
        <div class="exercise-head">
          <div>
            <h4>${index+1}. ${escapeHtml(exercise.name)}</h4>
            <p>
              ${escapeHtml(exercise.group)}
              • Target ${reps} reps × 5 sets
            </p>
          </div>
          <span class="tag">ADAPTIVE</span>
        </div>

        <div class="sets">
          ${[1,2,3,4,5].map(number=>`
            <div class="set-box" id="set-${key}-${number}">
              <small>SET ${number}</small>
              <strong>${reps}</strong>
            </div>
          `).join("")}
        </div>

        <div class="exercise-actions">
          <button class="small-btn"
            data-action="start" data-key="${key}">
            Start timer
          </button>

          <button class="small-btn"
            data-action="stop" data-key="${key}">
            Stop timer
          </button>

          <button class="small-btn complete"
            data-action="set"
            data-key="${key}"
            data-reps="${reps}">
            Complete next set
          </button>

          <span class="timer-readout" id="timer-${key}">
            Not started
          </span>
        </div>

        <div class="rest-box" id="rest-${key}" hidden>
          <span>REST</span>
          <strong id="rest-time-${key}">00:00</strong>
          <button class="small-btn"
            data-action="skip-rest" data-key="${key}">
            Skip rest
          </button>
        </div>

        <p class="hint" id="stamp-${key}">
          Timer records start time, stop time and total duration.
        </p>
      </article>
    `;
  }).join("");
}

$("exercise-list").addEventListener("click",event=>{
  const button = event.target.closest("button[data-action]");

  if(!button) return;

  const key = button.dataset.key;
  const card = button.closest(".exercise-card");
  const action = button.dataset.action;

  if(action==="start"){
    startExerciseTimer(key);
  }

  if(action==="stop"){
    stopExerciseTimer(key);
  }

  if(action==="set"){
    completeSet(key,Number(button.dataset.reps),card);
  }

  if(action==="skip-rest"){
    clearRest(key);
  }
});

function startSession(){
  if(sessionStart) return;

  sessionStart = Date.now();
  sessionFinished = false;

  sessionTicker = setInterval(()=>{
    $("session-time").textContent =
      fmt((Date.now()-sessionStart)/1000);
  },500);

  toast("Workout session started");
}

function startExerciseTimer(key){
  startSession();

  if(exerciseTimers[key]?.running){
    return;
  }

  exerciseTimers[key] = {
    start:Date.now(),
    stop:null,
    running:true
  };

  $("timer-"+key).textContent = "00:00 running";

  $("stamp-"+key).textContent =
    `Started: ${new Date(exerciseTimers[key].start).toLocaleTimeString()} • In progress`;

  exerciseTimers[key].interval = setInterval(()=>{
    const timer = exerciseTimers[key];

    if(timer?.running){
      $("timer-"+key).textContent =
        fmt((Date.now()-timer.start)/1000)+" elapsed";
    }
  },500);
}

function stopExerciseTimer(key){
  const timer = exerciseTimers[key];

  if(!timer || !timer.running){
    toast("Start this exercise timer first");
    return;
  }

  timer.stop = Date.now();
  timer.running = false;

  clearInterval(timer.interval);

  const elapsed = (timer.stop-timer.start)/1000;

  $("timer-"+key).textContent = fmt(elapsed)+" total";

  $("stamp-"+key).textContent =
    `Started: ${new Date(timer.start).toLocaleTimeString()} • Stopped: ${new Date(timer.stop).toLocaleTimeString()} • Duration: ${fmt(elapsed)}`;
}

function completeSet(key,reps,card){
  startSession();

  const completed = card.querySelectorAll(".set-box.done").length;

  if(completed>=5){
    toast("All five sets completed");
    return;
  }

  const next = completed+1;

  card.querySelector(`#set-${key}-${next}`).classList.add("done");

  if(next===5){
    toast("Exercise completed — great work!");
    return;
  }

  startRest(key,state.rest);
}

function startRest(key,seconds){
  clearRest(key);

  const box = $("rest-"+key);
  box.hidden = false;

  let remaining = seconds;

  $("rest-time-"+key).textContent = fmt(remaining);

  restTimers[key] = setInterval(()=>{
    remaining--;

    $("rest-time-"+key).textContent = fmt(remaining);

    if(remaining<=0){
      clearRest(key);
      toast("Rest complete — next set!");
    }
  },1000);
}

function clearRest(key){
  if(restTimers[key]){
    clearInterval(restTimers[key]);
  }

  delete restTimers[key];

  const box = $("rest-"+key);

  if(box){
    box.hidden = true;
  }
}

$("finish-workout").addEventListener("click",()=>{
  if(!sessionStart){
    toast("Start your workout before finishing");
    return;
  }

  if(sessionFinished) return;

  Object.keys(exerciseTimers).forEach(key=>{
    if(exerciseTimers[key]?.running){
      stopExerciseTimer(key);
    }
  });

  const duration = Math.round((Date.now()-sessionStart)/1000);

  const cards = [
    ...$("exercise-list").querySelectorAll(".exercise-card")
  ];

  const exercises = cards.map(card=>{
    const sets = card.querySelectorAll(".set-box.done").length;
    const timer = exerciseTimers[card.dataset.key];

    return {
      name:card.querySelector("h4").textContent.replace(/^\d+\.\s*/,""),
      completedSets:sets,
      avgReps:Number(card.querySelector(".set-box strong").textContent),
      duration:timer?.start && timer?.stop
        ? Math.round((timer.stop-timer.start)/1000)
        : 0
    };
  }).filter(exercise=>exercise.completedSets>0);

  const xp = exercises.reduce(
    (sum,exercise)=>sum+exercise.completedSets*10,0
  )+25;

  state.history.push({
    title:DAYS[activeDay].name,
    date:new Date().toISOString(),
    duration,
    exerciseCount:exercises.length,
    exercises,
    xp
  });

  state.xp += xp;

  saveState();

  sessionFinished = true;

  clearInterval(sessionTicker);
  sessionTicker = null;
  sessionStart = null;

  exerciseTimers = {};

  Object.keys(restTimers).forEach(clearRest);

  $("session-time").textContent = "00:00";

  renderStats();

  toast(`Workout saved • +${xp} XP`);

  showView("progress");
});

$("save-steps").addEventListener("click",()=>{
  state.steps = Math.max(0,Number($("steps-input").value)||0);

  saveState();
  renderStats();

  toast("Step count saved");
});

$("save-settings").addEventListener("click",()=>{
  const newDays = Number($("training-days").value);
  const newRest = Number($("rest-seconds").value);

  state.days = newDays;
  state.rest = newRest;

  activeDay = Math.min(activeDay,newDays-1);

  saveState();
  renderSchedule();
  renderWorkout();

  toast("Training settings saved");
});

$("reset-data").addEventListener("click",()=>{
  if(!confirm("Reset all PhilBig Fitness data on this device?")){
    return;
  }

  localStorage.removeItem("philbigFitness");

  state = {...DEFAULT_STATE};
  activeDay = 0;

  renderAll();

  toast("App data reset");
});

function renderAll(){
  renderSchedule();
  renderStats();
  renderWorkout();

  $("training-days").value = state.days;
  $("rest-seconds").value = state.rest;
}

renderAll();
