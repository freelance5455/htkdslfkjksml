MY BANK CIRCULARS — OFFLINE PERSONAL APP

What this is:
- A single-file offline web app for storing your own bank circular PDFs.
- PDFs are encrypted with AES-GCM in the browser's local IndexedDB database.
- The PIN is never stored; a PBKDF2-derived key is used.
- No server, cloud account, analytics, ads, or network code is included.

Important:
- Use only if your bank's policy permits storing internal documents on the device/browser.
- This is not a substitute for your bank's approved information-security controls.
- Clearing the browser/site data can delete the stored circulars. Keep an approved backup if your policy permits.

How to use:
1. Open index.html on an Android phone in a browser that supports IndexedDB and Web Crypto.
2. Create a PIN.
3. Add PDFs and fill in circular number, subject, category and date.
4. Use Search and Categories to find circulars.
5. Lock the app when finished.

For a true installable APK, this same interface can be packaged as an offline Android WebView app without adding a server.
