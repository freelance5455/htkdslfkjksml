مسیر سرمایه - پروژه اندروید

این بسته، سورس پروژه Android Studio است و هنوز APK کامپایل‌شده نیست.
برای ساخت APK:
1) Android Studio را نصب کنید.
2) این پوشه را با گزینه Open باز کنید.
3) در صورت درخواست، Android SDK و Gradle مورد نیاز را نصب/همگام‌سازی کنید.
4) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) استفاده کنید.
5) فایل APK معمولاً در app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

اپلیکیشن با WebView اجرا می‌شود و محتوای آموزشی داخل assets/index.html قرار دارد.
لینک‌های بیرونی در مرورگر گوشی باز می‌شوند.
پیشرفت درس‌ها در ذخیره‌سازی محلی WebView ثبت می‌شود.
