/**
 * KORDEL — Backend Express + Vite middleware
 * ---------------------------------------------------------------------------
 * - Em desenvolvimento serve o frontend Vite via middleware.
 * - Em produção serve o build estático de /dist.
 * - POST /api/upload — recebe base64, grava em /public/uploads/{pasta} e faz
 *   backup na coleção `storageImages` do Firestore. GET /uploads/:folder/:file
 *   restaura o arquivo do Firestore se ele não existir mais no disco local.
 * - Pix: geração de BR Code (EMV + CRC16-CCITT) e registro anti-fraude.
 * - Stripe: criação de checkout e verificação de sessão.
 */
import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const PORT = Number(process.env.PORT ?? 3000);
const isProd = process.env.NODE_ENV === 'production';

const app = express();
app.use(cors());
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

/* ══════════════════════════════════════════════════════════════════════════
   Diretórios de mídia
   ══════════════════════════════════════════════════════════════════════════ */
const UPLOAD_ROOT = path.join(process.cwd(), 'public', 'uploads');
const ALLOWED_FOLDERS = ['avatars', 'covers', 'posts', 'banners', 'audios'] as const;
type Folder = (typeof ALLOWED_FOLDERS)[number];

for (const f of ALLOWED_FOLDERS) {
  fs.mkdirSync(path.join(UPLOAD_ROOT, f), { recursive: true });
}

const MIME_EXT: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'image/svg+xml': 'svg',
  'audio/mpeg': 'mp3',
  'audio/mp3': 'mp3',
  'audio/wav': 'wav',
  'audio/ogg': 'ogg',
  'audio/webm': 'webm',
  'video/mp4': 'mp4',
  'video/webm': 'webm',
};

const EXT_MIME: Record<string, string> = {
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  png: 'image/png',
  webp: 'image/webp',
  gif: 'image/gif',
  svg: 'image/svg+xml',
  mp3: 'audio/mpeg',
  wav: 'audio/wav',
  ogg: 'audio/ogg',
  webm: 'video/webm',
  mp4: 'video/mp4',
};

/* ══════════════════════════════════════════════════════════════════════════
   Firestore Admin (opcional) — backup de mídia, pedidos Pix, comprovantes.
   Sem credenciais, o backend cai para armazenamento local/em memória.
   ══════════════════════════════════════════════════════════════════════════ */
type AdminDb = {
  collection: (name: string) => any;
};
let adminDb: AdminDb | null = null;

async function initAdmin() {
  try {
    const hasCreds =
      (process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PRIVATE_KEY) ||
      process.env.GOOGLE_APPLICATION_CREDENTIALS;

    if (!hasCreds) {
      console.log('[KORDEL] Firebase Admin sem credenciais — persistência de mídia em disco apenas.');
      return;
    }
    const admin = await import('firebase-admin');
    if (!admin.apps.length) {
      if (process.env.GOOGLE_APPLICATION_CREDENTIALS) {
        admin.initializeApp({ credential: admin.credential.applicationDefault() });
      } else {
        admin.initializeApp({
          credential: admin.credential.cert({
            projectId: process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: String(process.env.FIREBASE_PRIVATE_KEY).replace(/\\n/g, '\n'),
          }),
        });
      }
    }
    adminDb = admin.firestore() as unknown as AdminDb;
    console.log('[KORDEL] Firebase Admin conectado — backup em storageImages ativo.');
  } catch (err) {
    console.warn('[KORDEL] Firebase Admin indisponível:', (err as Error).message);
    adminDb = null;
  }
}

/* ══════════════════════════════════════════════════════════════════════════
   Uploads
   ══════════════════════════════════════════════════════════════════════════ */

function parseDataUrl(dataUrl: string): { mime: string; buffer: Buffer } | null {
  const m = /^data:([\w/+.-]+);base64,(.+)$/s.exec(dataUrl.trim());
  if (!m) return null;
  try {
    return { mime: m[1]!.toLowerCase(), buffer: Buffer.from(m[2]!, 'base64') };
  } catch {
    return null;
  }
}

app.post('/api/upload', async (req: Request, res: Response) => {
  try {
    const { file, folder, filename } = req.body ?? {};
    if (typeof file !== 'string' || !file.startsWith('data:')) {
      return res.status(400).json({ error: 'Campo "file" deve ser um data URL base64.' });
    }
    const target = String(folder ?? 'posts') as Folder;
    if (!ALLOWED_FOLDERS.includes(target)) {
      return res.status(400).json({ error: `Pasta inválida. Use: ${ALLOWED_FOLDERS.join(', ')}` });
    }

    const parsed = parseDataUrl(file);
    if (!parsed) return res.status(400).json({ error: 'Data URL malformado.' });

    const ext = MIME_EXT[parsed.mime] ?? 'bin';
    if (!MIME_EXT[parsed.mime]) {
      return res.status(415).json({ error: `Tipo não suportado: ${parsed.mime}` });
    }
    if (parsed.buffer.byteLength > 20 * 1024 * 1024) {
      return res.status(413).json({ error: 'Arquivo maior que 20 MB.' });
    }

    const safeBase = (filename ? path.parse(String(filename)).name : 'media')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9-_]/g, '-')
      .slice(0, 48) || 'media';
    const name = `${safeBase}-${Date.now().toString(36)}-${crypto.randomBytes(4).toString('hex')}.${ext}`;
    const dir = path.join(UPLOAD_ROOT, target);
    fs.mkdirSync(dir, { recursive: true });
    await fs.promises.writeFile(path.join(dir, name), parsed.buffer);

    // Backup no Firestore → permite restaurar após reinício do container.
    if (adminDb) {
      try {
        await adminDb.collection('storageImages').doc(`${target}__${name}`).set({
          folder: target,
          filename: name,
          mime: parsed.mime,
          base64: parsed.buffer.toString('base64'),
          size: parsed.buffer.byteLength,
          createdAt: new Date().toISOString(),
        });
      } catch (e) {
        console.warn('[KORDEL] Falha no backup Firestore:', (e as Error).message);
      }
    }

    return res.json({
      ok: true,
      url: `/uploads/${target}/${name}`,
      folder: target,
      filename: name,
      mime: parsed.mime,
      size: parsed.buffer.byteLength,
      backedUp: Boolean(adminDb),
    });
  } catch (err) {
    console.error('[KORDEL] /api/upload', err);
    return res.status(500).json({ error: 'Falha ao processar upload.' });
  }
});

/** Serve mídia enviada; restaura do Firestore se o arquivo sumiu do disco. */
app.get('/uploads/:folder/:filename', async (req: Request, res: Response) => {
  const folder = String(req.params.folder);
  const filename = path.basename(String(req.params.filename));
  if (!ALLOWED_FOLDERS.includes(folder as Folder)) {
    return res.status(404).end();
  }
  const localPath = path.join(UPLOAD_ROOT, folder, filename);
  const ext = path.extname(filename).slice(1).toLowerCase();

  if (fs.existsSync(localPath)) {
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    res.type(EXT_MIME[ext] ?? 'application/octet-stream');
    return res.sendFile(localPath);
  }

  if (adminDb) {
    try {
      const doc = await adminDb.collection('storageImages').doc(`${folder}__${filename}`).get();
      if (doc.exists) {
        const data = doc.data() as { base64: string; mime: string };
        const buf = Buffer.from(data.base64, 'base64');
        fs.mkdirSync(path.dirname(localPath), { recursive: true });
        await fs.promises.writeFile(localPath, buf);
        res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        res.type(data.mime);
        return res.send(buf);
      }
    } catch (e) {
      console.warn('[KORDEL] Restauração falhou:', (e as Error).message);
    }
  }
  return res.status(404).json({ error: 'Mídia não encontrada.' });
});

/* ══════════════════════════════════════════════════════════════════════════
   PIX — BR Code (EMV® QRCPS-MPM) com CRC16-CCITT/FALSE
   ══════════════════════════════════════════════════════════════════════════ */

const PIX_KEY = process.env.PIX_KEY ?? 'kordel@pix.exemplo.com.br';
const PIX_MERCHANT = (process.env.PIX_MERCHANT_NAME ?? 'KORDEL').slice(0, 25);
const PIX_CITY = (process.env.PIX_MERCHANT_CITY ?? 'SAO PAULO').slice(0, 15);
const PRICES: Record<string, number> = {
  reader: Number(process.env.PIX_READER_PRICE ?? 4.9),
  writer: Number(process.env.PIX_WRITER_PRICE ?? 13.49),
};

const emv = (id: string, value: string) => `${id}${String(value.length).padStart(2, '0')}${value}`;

const sanitize = (s: string) =>
  s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\x20-\x7E]/g, '')
    .toUpperCase();

/** CRC16/CCITT-FALSE — polinômio 0x1021, init 0xFFFF. */
export function crc16(payload: string): string {
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let b = 0; b < 8; b++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

export interface PixCharge {
  payload: string;
  amount: number;
  txid: string;
  key: string;
  merchant: string;
  city: string;
  expiresIn: number;
}

export function buildPixPayload(opts: {
  amount: number;
  txid: string;
  description?: string;
}): PixCharge {
  const amount = Math.max(0.01, Number(opts.amount));
  const txid = sanitize(opts.txid).replace(/[^A-Z0-9]/g, '').slice(0, 25) || 'KORDELPIX';
  const desc = sanitize(opts.description ?? 'ASSINATURA KORDEL').slice(0, 40);

  const merchantAccount = emv(
    '26',
    emv('00', 'BR.GOV.BCB.PIX') +
      emv('01', PIX_KEY) +
      emv('02', desc.slice(0, 72)),
  );

  const additional = emv('62', emv('05', txid));

  let payload =
    emv('00', '01') +
    emv('01', '12') +
    merchantAccount +
    emv('52', '0000') +
    emv('53', '986') +
    emv('54', amount.toFixed(2)) +
    emv('58', 'BR') +
    emv('59', PIX_MERCHANT) +
    emv('60', PIX_CITY) +
    additional +
    '6304';

  payload += crc16(payload);

  return {
    payload,
    amount,
    txid,
    key: PIX_KEY,
    merchant: PIX_MERCHANT,
    city: PIX_CITY,
    expiresIn: 1800,
  };
}

/** Valida o formato de um E2EID (End-to-End ID) de comprovante Pix. */
export function isValidE2EID(raw: string): { valid: boolean; reason?: string } {
  const v = String(raw ?? '').trim().toUpperCase();
  if (!v) return { valid: false, reason: 'Informe o código E2EID do comprovante.' };
  // Formato Bacen: E + 8 dígitos ISPB + YYYYMMDDHHMM + 11 alfanuméricos = 32 chars
  if (!/^E\d{8}\d{12}[A-Z0-9]{11}$/.test(v)) {
    return {
      valid: false,
      reason: 'E2EID inválido: esperado E + ISPB(8) + data/hora(12) + identificador(11) = 32 caracteres.',
    };
  }
  const ispb = v.slice(1, 9);
  if (ispb === '00000000') return { valid: false, reason: 'ISPB do recebedor inválido.' };
  return { valid: true };
}

const memoryPixReceipts = new Set<string>();

async function receiptAlreadyUsed(e2eid: string): Promise<boolean> {
  if (memoryPixReceipts.has(e2eid)) return true;
  if (!adminDb) return false;
  const doc = await adminDb.collection('usedPixReceipts').doc(e2eid).get();
  return Boolean(doc.exists);
}

async function registerReceipt(e2eid: string, meta: Record<string, unknown>) {
  memoryPixReceipts.add(e2eid);
  if (adminDb) {
    await adminDb
      .collection('usedPixReceipts')
      .doc(e2eid)
      .set({ e2eid, usedAt: new Date().toISOString(), ...meta });
  }
}

app.post('/api/create-pix-charge', (req: Request, res: Response) => {
  try {
    const plan = String(req.body?.plan ?? 'reader');
    if (!PRICES[plan]) return res.status(400).json({ error: 'Plano inválido.' });
    const txid = `KDL${Date.now().toString(36).toUpperCase()}${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
    const charge = buildPixPayload({
      amount: PRICES[plan]!,
      txid,
      description: plan === 'writer' ? 'ASSINATURA ESCRITOR' : 'ASSINATURA LEITOR',
    });
    return res.json({ ok: true, plan, ...charge });
  } catch (err) {
    console.error('[KORDEL] /api/create-pix-charge', err);
    return res.status(500).json({ error: 'Falha ao gerar cobrança Pix.' });
  }
});

app.post('/api/verify-pix-receipt', async (req: Request, res: Response) => {
  try {
    const { e2eid, plan, userId, amount } = req.body ?? {};
    const check = isValidE2EID(String(e2eid ?? ''));
    if (!check.valid) return res.status(400).json({ ok: false, error: check.reason });

    if (await receiptAlreadyUsed(String(e2eid).toUpperCase())) {
      return res.status(409).json({
        ok: false,
        error: 'Este comprovante já foi utilizado em outro pedido.',
      });
    }

    await registerReceipt(String(e2eid).toUpperCase(), { userId, plan, amount });

    const order = {
      userId: userId ?? null,
      plan: plan === 'writer' ? 'writer' : 'reader',
      amount: Number(amount ?? PRICES[plan as string] ?? PRICES.reader),
      e2eid: String(e2eid).toUpperCase(),
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    let orderId = `pix_${Date.now().toString(36)}`;
    if (adminDb) {
      const ref = await adminDb.collection('pixOrders').add(order);
      orderId = ref.id;
    }

    return res.json({
      ok: true,
      orderId,
      status: 'pending',
      message:
        'Comprovante registrado. A liberação é validada manualmente pela curadoria no Painel do Desenvolvedor.',
    });
  } catch (err) {
    console.error('[KORDEL] /api/verify-pix-receipt', err);
    return res.status(500).json({ error: 'Falha ao validar comprovante.' });
  }
});

/* ══════════════════════════════════════════════════════════════════════════
   STRIPE — checkout de cartão
   ══════════════════════════════════════════════════════════════════════════ */
const STRIPE_SECRET = process.env.STRIPE_SECRET_KEY ?? '';
const APP_URL = process.env.APP_URL ?? `http://localhost:${PORT}`;

async function getStripe() {
  if (!STRIPE_SECRET) return null;
  const { default: Stripe } = await import('stripe');
  return new Stripe(STRIPE_SECRET, { apiVersion: '2024-12-18.acacia' as any });
}

app.post('/api/create-stripe-checkout', async (req: Request, res: Response) => {
  try {
    const plan = String(req.body?.plan ?? 'reader');
    const userId = String(req.body?.userId ?? '');
    const email = req.body?.email ? String(req.body.email) : undefined;
    if (!PRICES[plan]) return res.status(400).json({ error: 'Plano inválido.' });

    const stripe = await getStripe();
    if (!stripe) {
      return res.status(503).json({
        ok: false,
        error: 'STRIPE_SECRET_KEY não configurada no backend. Use o checkout Pix ou configure a chave.',
        simulated: true,
      });
    }

    const priceId = plan === 'writer' ? process.env.STRIPE_PRICE_WRITER : process.env.STRIPE_PRICE_READER;

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      customer_email: email,
      client_reference_id: userId || undefined,
      line_items: priceId
        ? [{ price: priceId, quantity: 1 }]
        : [
            {
              quantity: 1,
              price_data: {
                currency: 'brl',
                unit_amount: Math.round(PRICES[plan]! * 100),
                recurring: { interval: 'month' },
                product_data: {
                  name: plan === 'writer' ? 'Assinatura Escritor — KORDEL' : 'Assinatura Leitor — KORDEL',
                },
              },
            },
          ],
      metadata: { plan, userId },
      subscription_data: { metadata: { plan, userId } },
      success_url: `${APP_URL}/assinaturas?stripe_success=true&session_id={CHECKOUT_SESSION_ID}&plan=${plan}`,
      cancel_url: `${APP_URL}/assinaturas?stripe_cancel=true`,
    });

    return res.json({ ok: true, url: session.url, sessionId: session.id });
  } catch (err) {
    console.error('[KORDEL] /api/create-stripe-checkout', err);
    return res.status(500).json({ ok: false, error: (err as Error).message });
  }
});

app.post('/api/verify-stripe-payment', async (req: Request, res: Response) => {
  try {
    const sessionId = String(req.body?.sessionId ?? req.query.session_id ?? '');
    if (!sessionId) return res.status(400).json({ ok: false, error: 'session_id obrigatório.' });

    const stripe = await getStripe();
    if (!stripe) {
      return res.status(503).json({ ok: false, error: 'Stripe não configurado.', simulated: true });
    }

    const session = await stripe.checkout.sessions.retrieve(sessionId);
    const paid = session.payment_status === 'paid' || session.status === 'complete';
    return res.json({
      ok: paid,
      paymentStatus: session.payment_status,
      plan: session.metadata?.plan ?? 'reader',
      userId: session.metadata?.userId ?? session.client_reference_id ?? null,
      customerEmail: session.customer_details?.email ?? null,
      amountTotal: session.amount_total,
      currency: session.currency,
    });
  } catch (err) {
    console.error('[KORDEL] /api/verify-stripe-payment', err);
    return res.status(500).json({ ok: false, error: (err as Error).message });
  }
});

/* ══════════════════════════════════════════════════════════════════════════
   Health
   ══════════════════════════════════════════════════════════════════════════ */
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    ok: true,
    app: 'KORDEL',
    version: '1.0.0',
    env: isProd ? 'production' : 'development',
    uptime: Math.round(process.uptime()),
    integrations: {
      firebaseAdmin: Boolean(adminDb),
      stripe: Boolean(STRIPE_SECRET),
      pix: Boolean(PIX_KEY),
    },
    uploadFolders: ALLOWED_FOLDERS,
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/pix/plans', (_req, res) => {
  res.json({ plans: Object.entries(PRICES).map(([id, price]) => ({ id, price })) });
});

/* ══════════════════════════════════════════════════════════════════════════
   Frontend
   ══════════════════════════════════════════════════════════════════════════ */
async function start() {
  await initAdmin();

  // Arquivos enviados (mesmo em produção o volume public/uploads é servido)
  app.use('/uploads', express.static(UPLOAD_ROOT, { maxAge: '1y', immutable: true }));

  if (isProd) {
    const dist = path.join(process.cwd(), 'dist');
    app.use(express.static(dist, { maxAge: '1h' }));
    app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true, hmr: { port: 24679 } },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, () => {
    console.log(`\n  🎻  KORDEL rodando em http://localhost:${PORT}  (${isProd ? 'produção' : 'desenvolvimento'})\n`);
  });
}

start().catch((err) => {
  console.error('[KORDEL] Falha ao iniciar:', err);
  process.exit(1);
});
