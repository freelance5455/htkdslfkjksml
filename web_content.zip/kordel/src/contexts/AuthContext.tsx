import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
} from 'firebase/auth';
import { firebaseAuth, isFirebaseConfigured } from '../firebase';
import { useStore } from './StoreContext';
import { avatarArt } from '../lib/art';
import type { AppUser } from '../types';

interface AuthValue {
  loading: boolean;
  pending: boolean;
  error: string | null;
  mode: 'live' | 'demo';
  signInGoogle: () => Promise<void>;
  signInEmail: (email: string, password: string) => Promise<void>;
  signUpEmail: (name: string, email: string, password: string) => Promise<void>;
  signInDemo: (email?: string) => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthValue | null>(null);

const DEMO_KEY = 'kordel.demo.identity';

function mapFirebaseError(code: string): string {
  const table: Record<string, string> = {
    'auth/invalid-email': 'E-mail inválido.',
    'auth/user-not-found': 'Conta não encontrada para este e-mail.',
    'auth/wrong-password': 'Senha incorreta.',
    'auth/invalid-credential': 'Credenciais inválidas. Confira e-mail e senha.',
    'auth/email-already-in-use': 'Este e-mail já está cadastrado.',
    'auth/weak-password': 'A senha precisa ter ao menos 6 caracteres.',
    'auth/popup-closed-by-user': 'Login cancelado antes de concluir.',
    'auth/popup-blocked': 'O navegador bloqueou o popup. Permita popups para entrar com Google.',
    'auth/cancelled-popup-request': 'Já existe uma solicitação de login em andamento.',
    'auth/too-many-requests': 'Muitas tentativas. Aguarde alguns minutos.',
    'auth/network-request-failed': 'Falha de rede. Verifique sua conexão.',
    'auth/operation-not-allowed': 'Este método de login não está habilitado no Firebase Console.',
  };
  return table[code] ?? 'Não foi possível autenticar. Tente novamente.';
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const { setSessionUser, currentUser, resetDemoData } = useStore();
  const [loading, setLoading] = useState(true);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Guarda contra cliques duplos enquanto o popup do Google está aberto.
  const pendingRef = useRef(false);

  const applyIdentity = useCallback(
    (identity: { uid: string; displayName: string | null; email: string | null; photoURL: string | null }) => {
      setSessionUser({
        uid: identity.uid,
        displayName: identity.displayName || (identity.email ? identity.email.split('@')[0]! : 'Leitor Kordel'),
        email: identity.email ?? '',
        photoURL: identity.photoURL,
      });
    },
    [setSessionUser],
  );

  // Sessão demo persistida (modo sem Firebase configurado).
  useEffect(() => {
    if (isFirebaseConfigured) return;
    try {
      const raw = localStorage.getItem(DEMO_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as { uid: string; displayName: string; email: string; photoURL: string };
        applyIdentity(parsed);
      }
    } catch {
      /* noop */
    }
    setLoading(false);
  }, [applyIdentity]);

  // Sessão Firebase real.
  useEffect(() => {
    if (!isFirebaseConfigured || !firebaseAuth) return;
    const unsub = onAuthStateChanged(firebaseAuth, (user) => {
      if (user) {
        applyIdentity({
          uid: user.uid,
          displayName: user.displayName,
          email: user.email,
          photoURL: user.photoURL ?? avatarArt(user.displayName ?? 'Kordel'),
        });
      } else {
        setSessionUser(null);
      }
      setLoading(false);
    });
    return unsub;
  }, [applyIdentity, setSessionUser]);

  const withGuard = useCallback(async (fn: () => Promise<void>) => {
    if (pendingRef.current) return;
    pendingRef.current = true;
    setPending(true);
    setError(null);
    try {
      await fn();
    } catch (err: unknown) {
      const code = (err as { code?: string }).code ?? '';
      setError(mapFirebaseError(code));
    } finally {
      pendingRef.current = false;
      setPending(false);
    }
  }, []);

  const signInGoogle = useCallback(
    () =>
      withGuard(async () => {
        if (!isFirebaseConfigured || !firebaseAuth) {
          setError('Firebase não configurado. Use o acesso de demonstração.');
          return;
        }
        const provider = new GoogleAuthProvider();
        provider.setCustomParameters({ prompt: 'select_account' });
        await signInWithPopup(firebaseAuth, provider);
      }),
    [withGuard],
  );

  const signInEmail = useCallback(
    (email: string, password: string) =>
      withGuard(async () => {
        if (!isFirebaseConfigured || !firebaseAuth) {
          setError('Firebase não configurado. Use o acesso de demonstração.');
          return;
        }
        await signInWithEmailAndPassword(firebaseAuth, email.trim(), password);
      }),
    [withGuard],
  );

  const signUpEmail = useCallback(
    (name: string, email: string, password: string) =>
      withGuard(async () => {
        if (!isFirebaseConfigured || !firebaseAuth) {
          setError('Firebase não configurado. Use o acesso de demonstração.');
          return;
        }
        const cred = await createUserWithEmailAndPassword(firebaseAuth, email.trim(), password);
        if (cred.user) await updateProfile(cred.user, { displayName: name.trim() });
        applyIdentity({
          uid: cred.user.uid,
          displayName: name.trim(),
          email: cred.user.email,
          photoURL: avatarArt(name.trim()),
        });
      }),
    [applyIdentity, withGuard],
  );

  const signInDemo = useCallback(
    async (email?: string) => {
      await withGuard(async () => {
        const seedEmail = email ?? 'rafa@kordel.app';
        const seeded = ['dev@kordel.app', 'marina@kordel.app', 'joao@kordel.app', 'lia@kordel.app', 'rafa@kordel.app', 'cecilia@kordel.app'];
        if (seedEmail === 'dev@kordel.app') resetDemoData();
        const uid =
          seedEmail === 'dev@kordel.app' ? 'u-dev'
          : seedEmail === 'marina@kordel.app' ? 'u-marina'
          : seedEmail === 'joao@kordel.app' ? 'u-joao'
          : seedEmail === 'lia@kordel.app' ? 'u-lia'
          : seedEmail === 'cecilia@kordel.app' ? 'u-cecilia'
          : seedEmail === 'rafa@kordel.app' ? 'u-rafa'
          : `demo_${btoa(seedEmail).replace(/[^a-z0-9]/gi, '').slice(0, 12)}`;
        const displayName =
          seedEmail === 'dev@kordel.app' ? 'Dona Kordel'
          : seedEmail === 'marina@kordel.app' ? 'Marina Cordeiro'
          : seedEmail === 'joao@kordel.app' ? 'João Bento de Sá'
          : seedEmail === 'lia@kordel.app' ? 'Lia Ventura'
          : seedEmail === 'cecilia@kordel.app' ? 'Cecília Prado'
          : 'Rafa Nunes';
        const identity = { uid, displayName, email: seedEmail, photoURL: avatarArt(displayName) };
        localStorage.setItem(DEMO_KEY, JSON.stringify(identity));
        applyIdentity(identity);
        if (!seeded.includes(seedEmail)) {
          // visitante novo recebe identidade própria
        }
      });
    },
    [applyIdentity, resetDemoData, withGuard],
  );

  const logout = useCallback(async () => {
    try {
      localStorage.removeItem(DEMO_KEY);
    } catch {
      /* noop */
    }
    if (isFirebaseConfigured && firebaseAuth) {
      await signOut(firebaseAuth);
    }
    setSessionUser(null);
  }, [setSessionUser]);

  const value = useMemo<AuthValue>(
    () => ({
      loading,
      pending,
      error,
      mode: isFirebaseConfigured ? 'live' : 'demo',
      signInGoogle,
      signInEmail,
      signUpEmail,
      signInDemo,
      logout,
      clearError: () => setError(null),
    }),
    [error, loading, logout, pending, signInDemo, signInEmail, signInGoogle, signUpEmail],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth precisa estar dentro de <AuthProvider>.');
  return ctx;
}

/** Usuário autenticado (documento completo do Firestore). */
export function useCurrentUser(): AppUser | null {
  const { currentUser } = useStore();
  return currentUser;
}
