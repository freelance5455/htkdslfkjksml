import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import type {
  AppNotification,
  AppUser,
  BetaApplication,
  Book,
  Branding,
  Chapter,
  Community,
  CommunityMember,
  CommunityRole,
  Genre,
  KardsTransaction,
  LibraryItem,
  LibraryStatus,
  ModerationState,
  PixOrder,
  Post,
  Report,
  ToastMsg,
} from '../types';
import { buildSeed, DB_VERSION, type Database } from '../lib/seed';
import { ACHIEVEMENTS, badgesForSubscription, levelFromXp, TITLES, XP_REWARDS } from '../lib/xp';
import { avatarArt } from '../lib/art';
import { nowIso, uid as makeId } from '../lib/utils';

const STORAGE_KEY = 'kordel.db.v1';
const SESSION_KEY = 'kordel.session.v1';

export interface Identity {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string | null;
}

type Draft = Database;

interface StoreValue {
  db: Database;
  currentUser: AppUser | null;
  toasts: ToastMsg[];
  pushToast: (t: Omit<ToastMsg, 'id'>) => void;
  dismissToast: (id: string) => void;

  setSessionUser: (identity: Identity | null) => AppUser | null;
  updateUser: (uid: string, patch: Partial<AppUser>) => void;

  updateBranding: (patch: Partial<Branding>) => void;

  awardXp: (amount: number, reason?: string) => void;
  grantAchievement: (achievementId: string) => void;
  equipTitle: (titleId: string | null) => void;
  addKards: (userId: string, amount: number, description: string) => void;

  toggleFollow: (targetUid: string) => void;
  isFollowing: (targetUid: string) => boolean;

  setLibrary: (bookId: string, patch: Partial<LibraryItem>) => void;
  toggleFavoritePost: (postId: string) => void;

  createBook: (input: Partial<Book> & { title: string; synopsis: string }) => Book;
  updateBook: (bookId: string, patch: Partial<Book>) => void;
  deleteBook: (bookId: string) => void;
  addChapter: (bookId: string, input: { title: string; content: string; earlyAccess: boolean; status: 'draft' | 'published' }) => void;
  updateChapter: (bookId: string, chapterId: string, patch: Partial<Chapter>) => void;
  deleteChapter: (bookId: string, chapterId: string) => void;
  addReview: (bookId: string, rating: number, text: string) => void;

  createCommunity: (input: { name: string; description: string; privacy: 'public' | 'private'; cover: string; tags: string[] }) => Community | null;
  joinCommunity: (communityId: string) => void;
  leaveCommunity: (communityId: string) => void;
  setMemberRole: (communityId: string, memberId: string, role: CommunityRole) => void;
  setMemberModeration: (communityId: string, memberId: string, state: ModerationState) => void;
  updateCommunity: (communityId: string, patch: Partial<Community>) => void;

  createPost: (input: {
    communityId: string | null;
    type: Post['type'];
    text: string;
    media?: string[];
    poll?: Post['poll'];
    audioUrl?: string | null;
  }) => Post | null;
  deletePost: (postId: string, flux: boolean) => void;
  toggleLikePost: (postId: string, flux: boolean) => void;
  toggleSavePost: (postId: string) => void;
  votePoll: (postId: string, optionId: string, flux: boolean) => void;
  addChapterComment: (bookId: string, chapterId: string, content: string, parentId: string | null) => void;
  editChapterComment: (bookId: string, chapterId: string, commentId: string, content: string) => void;
  deleteChapterComment: (bookId: string, chapterId: string, commentId: string) => void;

  addPostComment: (postId: string, content: string, parentId: string | null, flux: boolean) => void;
  editPostComment: (postId: string, commentId: string, content: string, flux: boolean) => void;
  deletePostComment: (postId: string, commentId: string, flux: boolean) => void;

  applyBeta: (bookId: string, motivation: string) => boolean;
  decideBeta: (appId: string, status: 'approved' | 'rejected') => void;
  submitBetaFeedback: (appId: string, feedback: string) => void;

  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;

  createReport: (input: Omit<Report, 'id' | 'status' | 'createdAt' | 'reporterId' | 'reporterName'>) => void;
  resolveReport: (id: string, status: 'resolved' | 'dismissed') => void;

  boostBook: (bookId: string) => boolean;
  consumeBoost: (bookId: string) => void;

  createPixOrder: (plan: 'reader' | 'writer', e2eid: string) => void;
  approvePixOrder: (orderId: string) => void;
  rejectPixOrder: (orderId: string) => void;

  setSubscription: (userId: string, plan: 'free' | 'reader' | 'writer', method: 'pix' | 'card' | 'granted') => void;
  banUser: (userId: string, banned: boolean) => void;
  adjustKards: (userId: string, delta: number, reason: string) => void;

  audit: (action: string, target: string) => void;
  resetDemoData: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

function loadDb(): Database {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Database;
      if (parsed.version === DB_VERSION && Array.isArray(parsed.users) && parsed.books?.length) {
        return parsed;
      }
    }
  } catch {
    /* ignora e recria */
  }
  return buildSeed();
}

function persist(db: Database) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch {
    // Quota excedida (mídia grande em base64). Mantém estado em memória.
    console.warn('[KORDEL] Persistência local cheia — seguindo em memória.');
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<Database>(() => loadDb());
  const [currentUserId, setCurrentUserId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(SESSION_KEY);
    } catch {
      return null;
    }
  });
  const [toasts, setToasts] = useState<ToastMsg[]>([]);
  const dbRef = useRef(db);
  dbRef.current = db;

  useEffect(() => {
    persist(db);
  }, [db]);

  useEffect(() => {
    try {
      if (currentUserId) localStorage.setItem(SESSION_KEY, currentUserId);
      else localStorage.removeItem(SESSION_KEY);
    } catch {
      /* noop */
    }
  }, [currentUserId]);

  const mutate = useCallback((fn: (draft: Draft) => void) => {
    setDb((prev) => {
      const next = structuredClone(prev);
      fn(next);
      return next;
    });
  }, []);

  const pushToast = useCallback((t: Omit<ToastMsg, 'id'>) => {
    const id = makeId('toast');
    setToasts((prev) => [...prev.slice(-3), { ...t, id }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((x) => x.id !== id));
    }, 5200);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const currentUser = useMemo(
    () => db.users.find((u) => u.uid === currentUserId) ?? null,
    [db.users, currentUserId],
  );

  /* ── Sessão ───────────────────────────────────────────────────────── */
  const setSessionUser = useCallback(
    (identity: Identity | null): AppUser | null => {
      if (!identity) {
        setCurrentUserId(null);
        return null;
      }
      let created: AppUser | null = null;
      setDb((prev) => {
        const next = structuredClone(prev);
        const existing = next.users.find((u) => u.uid === identity.uid);
        if (existing) {
          existing.displayName = identity.displayName || existing.displayName;
          existing.email = identity.email || existing.email;
          if (identity.photoURL) existing.photoURL = identity.photoURL;
          created = existing;
        } else {
          const isWriterEmail = identity.email.endsWith('@kordel.app');
          const doc: AppUser = {
            uid: identity.uid,
            displayName: identity.displayName || 'Leitor Kordel',
            email: identity.email,
            photoURL: identity.photoURL || avatarArt(identity.displayName || 'K'),
            bio: '',
            role: isWriterEmail ? 'escritor' : 'leitor',
            xp: 0,
            kards: 25,
            subscription: { plan: 'free', status: 'none', renewsAt: null },
            badges: [],
            achievements: [],
            titles: ['aprendiz'],
            equippedTitle: 'aprendiz',
            followers: 0,
            following: 0,
            banned: false,
            createdAt: nowIso(),
            boostsAvailable: 0,
            boostsResetAt: nowIso(),
          };
          next.users.push(doc);
          next.libraries[doc.uid] = {};
          created = doc;
        }
        return next;
      });
      setCurrentUserId(identity.uid);
      return created;
    },
    [],
  );

  const updateUser = useCallback(
    (userId: string, patch: Partial<AppUser>) => {
      mutate((d) => {
        const u = d.users.find((x) => x.uid === userId);
        if (u) Object.assign(u, patch);
      });
    },
    [mutate],
  );

  const updateBranding = useCallback(
    (patch: Partial<Branding>) => {
      mutate((d) => {
        d.branding = { ...d.branding, ...patch };
      });
    },
    [mutate],
  );

  /* ── Notificações & XP ────────────────────────────────────────────── */
  const notify = useCallback(
    (d: Draft, userId: string, n: Omit<AppNotification, 'id' | 'userId' | 'createdAt' | 'read'>) => {
      d.notifications.unshift({
        ...n,
        id: makeId('ntf'),
        userId,
        read: false,
        createdAt: nowIso(),
      });
    },
    [],
  );

  const grantAchievement = useCallback(
    (achievementId: string) => {
      if (!currentUserId) return;
      const def = ACHIEVEMENTS.find((a) => a.id === achievementId);
      if (!def) return;
      let granted = false;
      mutate((d) => {
        const u = d.users.find((x) => x.uid === currentUserId);
        if (!u || u.achievements.includes(achievementId)) return;
        u.achievements.push(achievementId);
        u.xp += def.xp;
        granted = true;
        notify(d, u.uid, {
          type: 'achievement',
          title: `Conquista desbloqueada: ${def.name}`,
          body: `${def.description} +${def.xp} XP.`,
          link: '/conquistas',
        });
      });
      if (granted) {
        pushToast({
          title: `${def.icon} ${def.name}`,
          body: `Conquista desbloqueada • +${def.xp} XP`,
          tone: 'success',
          link: '/conquistas',
        });
      }
    },
    [currentUserId, mutate, notify, pushToast],
  );

  const awardXp = useCallback(
    (amount: number, reason?: string) => {
      if (!currentUserId) return;
      mutate((d) => {
        const u = d.users.find((x) => x.uid === currentUserId);
        if (!u) return;
        const before = levelFromXp(u.xp).level;
        u.xp = Math.max(0, u.xp + amount);
        const after = levelFromXp(u.xp).level;
        if (after > before) {
          pushToast({
            title: `Nível ${after} alcançado!`,
            body: 'Novos títulos podem estar disponíveis em Conquistas.',
            tone: 'success',
            link: '/conquistas',
          });
        }
        const unlockedTitles = TITLES.filter((t) => t.minLevel && after >= t.minLevel && !u.titles.includes(t.id));
        for (const t of unlockedTitles) u.titles.push(t.id);
        if (reason) {
          d.transactions.unshift({
            id: makeId('xp'),
            userId: u.uid,
            amount,
            type: 'credit',
            description: reason,
            createdAt: nowIso(),
          });
        }
      });
    },
    [currentUserId, mutate, pushToast],
  );

  const equipTitle = useCallback(
    (titleId: string | null) => {
      if (!currentUserId) return;
      mutate((d) => {
        const u = d.users.find((x) => x.uid === currentUserId);
        if (!u) return;
        if (titleId && !u.titles.includes(titleId)) return;
        u.equippedTitle = titleId;
      });
    },
    [currentUserId, mutate],
  );

  const addKards = useCallback(
    (userId: string, amount: number, description: string) => {
      mutate((d) => {
        const u = d.users.find((x) => x.uid === userId);
        if (!u) return;
        u.kards = Math.max(0, u.kards + amount);
        const tx: KardsTransaction = {
          id: makeId('tx'),
          userId,
          amount: Math.abs(amount),
          type: amount >= 0 ? 'credit' : 'debit',
          description,
          createdAt: nowIso(),
        };
        d.transactions.unshift(tx);
      });
    },
    [mutate],
  );

  /* ── Social: seguir ───────────────────────────────────────────────── */
  const toggleFollow = useCallback(
    (targetUid: string) => {
      if (!currentUserId || targetUid === currentUserId) return;
      mutate((d) => {
        const me = d.users.find((u) => u.uid === currentUserId);
        const target = d.users.find((u) => u.uid === targetUid);
        if (!me || !target) return;
        const idx = d.follows.findIndex(
          (f) => f.followerId === currentUserId && f.followingId === targetUid,
        );
        if (idx >= 0) {
          d.follows.splice(idx, 1);
          me.following = Math.max(0, me.following - 1);
          target.followers = Math.max(0, target.followers - 1);
        } else {
          d.follows.push({ followerId: currentUserId, followingId: targetUid, createdAt: nowIso() });
          me.following += 1;
          target.followers += 1;
          me.xp += XP_REWARDS.followUser;
          notify(d, targetUid, {
            type: 'follow',
            title: `${me.displayName} começou a te seguir`,
            body: 'Abra o perfil para retribuir.',
            link: '/social',
          });
        }
      });
    },
    [currentUserId, mutate, notify],
  );

  const isFollowing = useCallback(
    (targetUid: string) =>
      Boolean(
        currentUserId &&
          db.follows.some((f) => f.followerId === currentUserId && f.followingId === targetUid),
      ),
    [currentUserId, db.follows],
  );

  /* ── Biblioteca ───────────────────────────────────────────────────── */
  const setLibrary = useCallback(
    (bookId: string, patch: Partial<LibraryItem>) => {
      if (!currentUserId) return;
      mutate((d) => {
        const shelf = (d.libraries[currentUserId] ??= {});
        const existing = shelf[bookId];
        shelf[bookId] = {
          bookId,
          status: existing?.status ?? 'reading',
          progress: existing?.progress ?? 0,
          lastChapterId: existing?.lastChapterId ?? null,
          updatedAt: nowIso(),
          ...patch,
        };
        if (patch.status === 'completed') {
          const book = d.books.find((b) => b.id === bookId);
          if (book) {
            book.readers += 1;
            if (!book.reviews.some((r) => r.userId === currentUserId)) {
              // marca como lido sem review; nota é opcional
            }
          }
        }
      });
    },
    [currentUserId, mutate],
  );

  const toggleFavoritePost = useCallback(
    (postId: string) => {
      if (!currentUserId) return;
      mutate((d) => {
        const list = (d.favoritePosts[currentUserId] ??= []);
        const i = list.indexOf(postId);
        if (i >= 0) list.splice(i, 1);
        else list.unshift(postId);
      });
    },
    [currentUserId, mutate],
  );

  /* ── Obras & Capítulos ────────────────────────────────────────────── */
  const createBook = useCallback(
    (input: Partial<Book> & { title: string; synopsis: string }): Book => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      const id = makeId('book');
      const book: Book = {
        id,
        title: input.title,
        synopsis: input.synopsis,
        cover: input.cover ?? '',
        genres: (input.genres as Genre[]) ?? ['Romance'],
        ageRating: input.ageRating ?? 'Livre',
        status: input.status ?? 'draft',
        authorId: me?.uid ?? 'anon',
        authorName: me?.displayName ?? 'Autor',
        authorPhoto: me?.photoURL ?? '',
        betaMode: input.betaMode ?? false,
        betaSlots: input.betaSlots ?? 0,
        betaRules: input.betaRules ?? '',
        betaDeadline: input.betaDeadline ?? null,
        readers: 0,
        views: 0,
        likes: 0,
        rating: 0,
        ratingCount: 0,
        chapters: [],
        reviews: [],
        featured: false,
        boostedUntil: null,
        createdAt: nowIso(),
        updatedAt: nowIso(),
      };
      mutate((d) => {
        d.books.unshift(book);
        if (me && me.role === 'leitor') {
          const target = d.users.find((u) => u.uid === me.uid);
          if (target) target.role = 'escritor';
        }
        if (me) notify(d, me.uid, {
          type: 'system',
          title: 'Obra criada no Estúdio',
          body: `“${book.title}” está em rascunho. Publique quando estiver pronto.`,
          link: '/estudio',
        });
      });
      if ((book.status as string) === 'published') grantAchievement('primeira-obra');
      return book;
    },
    [currentUserId, grantAchievement, mutate, notify],
  );

  const updateBook = useCallback(
    (bookId: string, patch: Partial<Book>) => {
      mutate((d) => {
        const b = d.books.find((x) => x.id === bookId);
        if (!b) return;
        Object.assign(b, patch, { updatedAt: nowIso() });
        if (patch.status === 'published') {
          const me = d.users.find((u) => u.uid === currentUserId);
          if (me && !me.achievements.includes('primeira-obra')) {
            me.achievements.push('primeira-obra');
            me.xp += 150;
          }
        }
      });
    },
    [currentUserId, mutate],
  );

  const deleteBook = useCallback(
    (bookId: string) => {
      mutate((d) => {
        d.books = d.books.filter((b) => b.id !== bookId);
        d.branding.featuredBookIds = d.branding.featuredBookIds.filter((id) => id !== bookId);
        Object.values(d.libraries).forEach((shelf) => delete shelf[bookId]);
      });
      pushToast({ title: 'Obra removida', body: 'A obra e o progresso associado foram apagados.', tone: 'warn' });
    },
    [mutate, pushToast],
  );

  const addChapter = useCallback(
    (
      bookId: string,
      input: { title: string; content: string; earlyAccess: boolean; status: 'draft' | 'published' },
    ) => {
      mutate((d) => {
        const b = d.books.find((x) => x.id === bookId);
        if (!b) return;
        const number = b.chapters.length + 1;
        b.chapters.push({
          id: makeId('ch'),
          number,
          title: input.title,
          content: input.content,
          status: input.status,
          earlyAccess: input.earlyAccess,
          createdAt: nowIso(),
          reads: 0,
          comments: [],
        });
        b.updatedAt = nowIso();
      });
    },
    [mutate],
  );

  const updateChapter = useCallback(
    (bookId: string, chapterId: string, patch: Partial<Chapter>) => {
      mutate((d) => {
        const b = d.books.find((x) => x.id === bookId);
        const c = b?.chapters.find((x) => x.id === chapterId);
        if (!b || !c) return;
        Object.assign(c, patch);
        b.updatedAt = nowIso();
      });
    },
    [mutate],
  );

  const deleteChapter = useCallback(
    (bookId: string, chapterId: string) => {
      mutate((d) => {
        const b = d.books.find((x) => x.id === bookId);
        if (!b) return;
        b.chapters = b.chapters.filter((c) => c.id !== chapterId);
        b.chapters.forEach((c, i) => {
          c.number = i + 1;
        });
      });
    },
    [mutate],
  );

  const addReview = useCallback(
    (bookId: string, rating: number, text: string) => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      if (!me) return;
      mutate((d) => {
        const b = d.books.find((x) => x.id === bookId);
        if (!b) return;
        const existing = b.reviews.find((r) => r.userId === me.uid);
        if (existing) {
          existing.rating = rating;
          existing.text = text;
          existing.createdAt = nowIso();
        } else {
          b.reviews.unshift({
            id: makeId('rv'),
            userId: me.uid,
            userName: me.displayName,
            userPhoto: me.photoURL,
            rating,
            text,
            createdAt: nowIso(),
          });
          b.ratingCount += 1;
        }
        const sum = b.reviews.reduce((acc, r) => acc + r.rating, 0);
        b.rating = Math.round((sum / Math.max(1, b.reviews.length)) * 10) / 10;
        const u = d.users.find((x) => x.uid === me.uid);
        if (u) u.xp += XP_REWARDS.reviewBook;
      });
      pushToast({ title: 'Avaliação publicada', body: `+${XP_REWARDS.reviewBook} XP`, tone: 'success' });
      const totalReviews = dbRef.current.books.find((b) => b.id === bookId)?.reviews.length ?? 0;
      if (totalReviews >= 2) grantAchievement('critico');
    },
    [currentUserId, grantAchievement, mutate, pushToast],
  );

  /* ── Comunidades ──────────────────────────────────────────────────── */
  const createCommunity = useCallback(
    (input: { name: string; description: string; privacy: 'public' | 'private'; cover: string; tags: string[] }) => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      if (!me) return null;
      if (me.subscription.plan === 'free' && dbRef.current.communities.filter((c) => c.creatorId === me.uid).length >= 3) {
        pushToast({
          title: 'Limite de comunidades',
          body: 'O plano gratuito permite 3 comunidades. A Assinatura Escritor libera comunidades exclusivas por ciclo.',
          tone: 'warn',
          link: '/assinaturas',
        });
        return null;
      }
      const id = makeId('com');
      const community: Community = {
        id,
        name: input.name,
        description: input.description,
        cover: input.cover,
        privacy: input.privacy,
        creatorId: me.uid,
        creatorName: me.displayName,
        members: [
          {
            userId: me.uid,
            userName: me.displayName,
            userPhoto: me.photoURL,
            role: 'creator',
            moderation: 'active',
            joinedAt: nowIso(),
          },
        ],
        tags: input.tags,
        featured: false,
        createdAt: nowIso(),
      };
      mutate((d) => {
        d.communities.unshift(community);
        const u = d.users.find((x) => x.uid === me.uid);
        if (u) u.xp += XP_REWARDS.createCommunity;
      });
      grantAchievement('fundador');
      pushToast({ title: 'Comunidade criada', body: input.name, tone: 'success' });
      return community;
    },
    [currentUserId, grantAchievement, mutate, pushToast],
  );

  const joinCommunity = useCallback(
    (communityId: string) => {
      if (!currentUserId) return;
      mutate((d) => {
        const c = d.communities.find((x) => x.id === communityId);
        const me = d.users.find((u) => u.uid === currentUserId);
        if (!c || !me || c.members.some((m) => m.userId === me.uid)) return;
        c.members.push({
          userId: me.uid,
          userName: me.displayName,
          userPhoto: me.photoURL,
          role: 'member',
          moderation: 'active',
          joinedAt: nowIso(),
        });
      });
    },
    [currentUserId, mutate],
  );

  const leaveCommunity = useCallback(
    (communityId: string) => {
      if (!currentUserId) return;
      mutate((d) => {
        const c = d.communities.find((x) => x.id === communityId);
        if (!c) return;
        c.members = c.members.filter((m) => m.userId !== currentUserId);
      });
    },
    [currentUserId, mutate],
  );

  const setMemberRole = useCallback(
    (communityId: string, memberId: string, role: CommunityRole) => {
      mutate((d) => {
        const m = d.communities.find((x) => x.id === communityId)?.members.find((x) => x.userId === memberId);
        if (m) m.role = role;
      });
    },
    [mutate],
  );

  const setMemberModeration = useCallback(
    (communityId: string, memberId: string, state: ModerationState) => {
      mutate((d) => {
        const m = d.communities.find((x) => x.id === communityId)?.members.find((x) => x.userId === memberId);
        if (m) m.moderation = state;
      });
    },
    [mutate],
  );

  const updateCommunity = useCallback(
    (communityId: string, patch: Partial<Community>) => {
      mutate((d) => {
        const c = d.communities.find((x) => x.id === communityId);
        if (c) Object.assign(c, patch);
      });
    },
    [mutate],
  );

  /* ── Posts ────────────────────────────────────────────────────────── */
  const createPost = useCallback<StoreValue['createPost']>(
    (input) => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      if (!me) return null;
      if (input.communityId) {
        const community = dbRef.current.communities.find((c) => c.id === input.communityId);
        const member = community?.members.find((m) => m.userId === me.uid);
        if (!member) {
          pushToast({ title: 'Entre na comunidade para publicar', tone: 'warn' });
          return null;
        }
        if (member.moderation !== 'active') {
          pushToast({ title: 'Sua participação está restrita nesta comunidade', tone: 'error' });
          return null;
        }
      }
      const post: Post = {
        id: makeId(input.communityId ? 'post' : 'flux'),
        communityId: input.communityId,
        communityName: input.communityId
          ? dbRef.current.communities.find((c) => c.id === input.communityId)?.name ?? null
          : null,
        authorId: me.uid,
        authorName: me.displayName,
        authorPhoto: me.photoURL,
        type: input.type,
        text: input.text,
        media: input.media ?? [],
        poll: input.poll ?? null,
        audioUrl: input.audioUrl ?? null,
        likes: [],
        savedBy: [],
        comments: [],
        createdAt: nowIso(),
        views: 0,
      };
      mutate((d) => {
        if (input.communityId) d.posts.unshift(post);
        else d.fluxPosts.unshift(post);
        const u = d.users.find((x) => x.uid === me.uid);
        if (u) u.xp += XP_REWARDS.createPost;
      });
      const posted = dbRef.current.fluxPosts.filter((p) => p.authorId === me.uid).length;
      if (posted >= 10) grantAchievement('voz-ativa');
      return post;
    },
    [currentUserId, grantAchievement, mutate, pushToast],
  );

  const deletePost = useCallback(
    (postId: string, flux: boolean) => {
      mutate((d) => {
        if (flux) d.fluxPosts = d.fluxPosts.filter((p) => p.id !== postId);
        else d.posts = d.posts.filter((p) => p.id !== postId);
        Object.values(d.favoritePosts).forEach((list) => {
          const i = list.indexOf(postId);
          if (i >= 0) list.splice(i, 1);
        });
      });
    },
    [mutate],
  );

  const toggleLikePost = useCallback(
    (postId: string, flux: boolean) => {
      if (!currentUserId) return;
      mutate((d) => {
        const list = flux ? d.fluxPosts : d.posts;
        const p = list.find((x) => x.id === postId);
        if (!p) return;
        const i = p.likes.indexOf(currentUserId);
        if (i >= 0) p.likes.splice(i, 1);
        else p.likes.push(currentUserId);
      });
    },
    [currentUserId, mutate],
  );

  const toggleSavePost = useCallback(
    (postId: string) => {
      if (!currentUserId) return;
      mutate((d) => {
        const list = (d.favoritePosts[currentUserId] ??= []);
        const i = list.indexOf(postId);
        if (i >= 0) list.splice(i, 1);
        else list.unshift(postId);
        [...d.posts, ...d.fluxPosts].forEach((p) => {
          if (p.id !== postId) return;
          const j = p.savedBy.indexOf(currentUserId);
          if (j >= 0) p.savedBy.splice(j, 1);
          else p.savedBy.push(currentUserId);
        });
      });
    },
    [currentUserId, mutate],
  );

  const votePoll = useCallback(
    (postId: string, optionId: string, flux: boolean) => {
      if (!currentUserId) return;
      mutate((d) => {
        const list = flux ? d.fluxPosts : d.posts;
        const p = list.find((x) => x.id === postId);
        if (!p?.poll) return;
        p.poll.options.forEach((o) => {
          o.votes = o.votes.filter((v) => v !== currentUserId);
        });
        const opt = p.poll.options.find((o) => o.id === optionId);
        opt?.votes.push(currentUserId);
      });
    },
    [currentUserId, mutate],
  );

  /* ── Comentários de capítulo ──────────────────────────────────────── */
  const addChapterComment = useCallback(
    (bookId: string, chapterId: string, content: string, parentId: string | null) => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      if (!me || !content.trim()) return;
      mutate((d) => {
        const chapter = d.books.find((b) => b.id === bookId)?.chapters.find((c) => c.id === chapterId);
        if (!chapter) return;
        chapter.comments.push({
          id: makeId('cc'),
          parentId,
          userId: me.uid,
          userName: me.displayName,
          userPhoto: me.photoURL,
          content: content.trim(),
          createdAt: nowIso(),
          editedAt: null,
          likes: 0,
        });
        const u = d.users.find((x) => x.uid === me.uid);
        if (u) u.xp += XP_REWARDS.chapterComment;
        const book = d.books.find((b) => b.id === bookId);
        if (book && book.authorId !== me.uid) {
          notify(d, book.authorId, {
            type: 'comment',
            title: `${me.displayName} comentou seu capítulo`,
            body: content.slice(0, 90),
            link: `/ler/${bookId}/${chapterId}`,
          });
        }
      });
    },
    [currentUserId, mutate, notify],
  );

  const editChapterComment = useCallback(
    (bookId: string, chapterId: string, commentId: string, content: string) => {
      mutate((d) => {
        const c = d.books
          .find((b) => b.id === bookId)
          ?.chapters.find((x) => x.id === chapterId)
          ?.comments.find((x) => x.id === commentId);
        if (c) {
          c.content = content;
          c.editedAt = nowIso();
        }
      });
    },
    [mutate],
  );

  const deleteChapterComment = useCallback(
    (bookId: string, chapterId: string, commentId: string) => {
      mutate((d) => {
        const chapter = d.books.find((b) => b.id === bookId)?.chapters.find((x) => x.id === chapterId);
        if (!chapter) return;
        chapter.comments = chapter.comments.filter((c) => c.id !== commentId && c.parentId !== commentId);
      });
    },
    [mutate],
  );

  const addPostComment = useCallback(
    (postId: string, content: string, parentId: string | null, flux: boolean) => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      if (!me || !content.trim()) return;
      mutate((d) => {
        const list = flux ? d.fluxPosts : d.posts;
        const p = list.find((x) => x.id === postId);
        if (!p) return;
        p.comments.push({
          id: makeId('cm'),
          parentId,
          userId: me.uid,
          userName: me.displayName,
          userPhoto: me.photoURL,
          content: content.trim(),
          createdAt: nowIso(),
          likes: 0,
        });
        const u = d.users.find((x) => x.uid === me.uid);
        if (u) u.xp += 4;
        if (!flux && p.authorId !== me.uid) {
          notify(d, p.authorId, {
            type: 'comment',
            title: `${me.displayName} comentou seu post`,
            body: content.slice(0, 90),
            link: `/social/comunidades`,
          });
        }
      });
    },
    [currentUserId, mutate, notify],
  );

  const editPostComment = useCallback(
    (postId: string, commentId: string, content: string, flux: boolean) => {
      mutate((d) => {
        const list = flux ? d.fluxPosts : d.posts;
        const c = list.find((x) => x.id === postId)?.comments.find((x) => x.id === commentId);
        if (c) {
          c.content = content;
          c.editedAt = nowIso();
        }
      });
    },
    [mutate],
  );

  const deletePostComment = useCallback(
    (postId: string, commentId: string, flux: boolean) => {
      mutate((d) => {
        const list = flux ? d.fluxPosts : d.posts;
        const p = list.find((x) => x.id === postId);
        if (!p) return;
        p.comments = p.comments.filter((c) => c.id !== commentId && c.parentId !== commentId);
      });
    },
    [mutate],
  );

  /* ── Beta ─────────────────────────────────────────────────────────── */
  const applyBeta = useCallback(
    (bookId: string, motivation: string): boolean => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      if (!me) {
        pushToast({ title: 'Entre para se candidatar', tone: 'warn' });
        return false;
      }
      if (me.subscription.status !== 'active') {
        pushToast({
          title: 'Leitura Beta é exclusiva para assinantes',
          body: 'A Assinatura Leitor libera obras em beta e capítulos antecipados.',
          tone: 'warn',
          link: '/assinaturas',
        });
        return false;
      }
      if (dbRef.current.betaApplications.some((a) => a.bookId === bookId && a.userId === me.uid)) {
        pushToast({ title: 'Você já tem uma candidatura nesta obra', tone: 'warn' });
        return false;
      }
      const book = dbRef.current.books.find((b) => b.id === bookId);
      const approved = dbRef.current.betaApplications.filter((a) => a.bookId === bookId && a.status === 'approved').length;
      if (book && book.betaSlots > 0 && approved >= book.betaSlots) {
        pushToast({ title: 'Vagas beta esgotadas', body: 'Aguarde nova temporada de leitura.', tone: 'warn' });
        return false;
      }
      mutate((d) => {
        const app: BetaApplication = {
          id: makeId('beta'),
          bookId,
          bookTitle: book?.title ?? '',
          userId: me.uid,
          userName: me.displayName,
          userPhoto: me.photoURL,
          motivation,
          status: 'pending',
          feedback: null,
          feedbackStatus: 'none',
          createdAt: nowIso(),
        };
        d.betaApplications.unshift(app);
        if (book) {
          notify(d, book.authorId, {
            type: 'beta',
            title: 'Nova candidatura beta',
            body: `${me.displayName} quer ler “${book.title}”.`,
            link: '/estudio',
          });
        }
      });
      pushToast({ title: 'Candidatura enviada', body: 'O autor decide em até 7 dias.', tone: 'success' });
      return true;
    },
    [currentUserId, mutate, notify, pushToast],
  );

  const decideBeta = useCallback(
    (appId: string, status: 'approved' | 'rejected') => {
      mutate((d) => {
        const app = d.betaApplications.find((a) => a.id === appId);
        if (!app) return;
        app.status = status;
        notify(d, app.userId, {
          type: 'beta',
          title: status === 'approved' ? 'Você foi aprovado na Leitura Beta' : 'Candidatura beta não aprovada',
          body:
            status === 'approved'
              ? `“${app.bookTitle}” liberou os capítulos antecipados para você.`
              : `“${app.bookTitle}” — obrigado pelo interesse.`,
          link: `/obra/${app.bookId}`,
        });
      });
      pushToast({
        title: status === 'approved' ? 'Candidato aprovado' : 'Candidatura recusada',
        tone: status === 'approved' ? 'success' : 'info',
      });
    },
    [mutate, notify, pushToast],
  );

  const submitBetaFeedback = useCallback(
    (appId: string, feedback: string) => {
      mutate((d) => {
        const app = d.betaApplications.find((a) => a.id === appId);
        if (!app) return;
        app.feedback = feedback;
        app.feedbackStatus = 'submitted';
        const me = d.users.find((u) => u.uid === app.userId);
        if (me) me.xp += XP_REWARDS.betaFeedback;
        const book = d.books.find((b) => b.id === app.bookId);
        if (book) {
          notify(d, book.authorId, {
            type: 'beta',
            title: 'Feedback beta recebido',
            body: `${app.userName} enviou feedback em “${book.title}”.`,
            link: '/estudio',
          });
        }
      });
      grantAchievement('beta-host');
      pushToast({ title: 'Feedback enviado', body: `+${XP_REWARDS.betaFeedback} XP`, tone: 'success' });
    },
    [grantAchievement, mutate, notify, pushToast],
  );

  /* ── Notificações ─────────────────────────────────────────────────── */
  const markNotificationRead = useCallback(
    (id: string) => {
      mutate((d) => {
        const n = d.notifications.find((x) => x.id === id);
        if (n) n.read = true;
      });
    },
    [mutate],
  );

  const markAllNotificationsRead = useCallback(() => {
    if (!currentUserId) return;
    mutate((d) => {
      d.notifications.forEach((n) => {
        if (n.userId === currentUserId) n.read = true;
      });
    });
  }, [currentUserId, mutate]);

  /* ── Denúncias ────────────────────────────────────────────────────── */
  const createReport = useCallback<StoreValue['createReport']>(
    (input) => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      if (!me) return;
      mutate((d) => {
        d.reports.unshift({
          ...input,
          id: makeId('rpt'),
          reporterId: me.uid,
          reporterName: me.displayName,
          status: 'open',
          createdAt: nowIso(),
        });
      });
      pushToast({ title: 'Denúncia registrada', body: 'Nossa curadoria analisa em até 48h.', tone: 'success' });
    },
    [currentUserId, mutate, pushToast],
  );

  const resolveReport = useCallback(
    (id: string, status: 'resolved' | 'dismissed') => {
      mutate((d) => {
        const r = d.reports.find((x) => x.id === id);
        if (r) r.status = status;
      });
    },
    [mutate],
  );

  /* ── Boost ────────────────────────────────────────────────────────── */
  const boostBook = useCallback(
    (bookId: string): boolean => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      if (!me) return false;
      if (me.subscription.status !== 'active' || me.subscription.plan !== 'writer') {
        pushToast({
          title: 'Impulsionamento é exclusivo da Assinatura Escritor',
          body: '2 boosts por mês, 7 dias cada.',
          tone: 'warn',
          link: '/assinaturas',
        });
        return false;
      }
      if (me.boostsAvailable <= 0) {
        pushToast({ title: 'Sem impulsionamentos disponíveis', body: 'Renova no próximo ciclo.', tone: 'warn' });
        return false;
      }
      mutate((d) => {
        const b = d.books.find((x) => x.id === bookId);
        const u = d.users.find((x) => x.uid === me.uid);
        if (!b || !u) return;
        b.boostedUntil = new Date(Date.now() + 7 * 86400000).toISOString();
        u.boostsAvailable -= 1;
        notify(d, u.uid, {
          type: 'system',
          title: 'Impulsionamento ativado',
          body: `“${b.title}” fica em evidência por 7 dias.`,
          link: `/obra/${b.id}`,
        });
      });
      grantAchievement('impulsionado');
      pushToast({ title: 'Boost ativado por 7 dias', tone: 'success' });
      return true;
    },
    [currentUserId, grantAchievement, mutate, notify, pushToast],
  );

  const consumeBoost = useCallback((_bookId: string) => {}, []);

  /* ── Pix / Assinaturas / Dev ──────────────────────────────────────── */
  const createPixOrder = useCallback(
    (plan: 'reader' | 'writer', e2eid: string) => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      if (!me) return;
      mutate((d) => {
        d.pixOrders.unshift({
          id: makeId('pix'),
          userId: me.uid,
          userName: me.displayName,
          plan,
          amount: plan === 'reader' ? 4.9 : 13.49,
          e2eid,
          status: 'pending',
          createdAt: nowIso(),
        });
        notify(d, me.uid, {
          type: 'payment',
          title: 'Comprovante Pix em análise',
          body: 'A liberação é feita manualmente pela curadoria.',
          link: '/assinaturas',
        });
        d.users
          .filter((u) => u.role === 'desenvolvedor')
          .forEach((dev) =>
            notify(d, dev.uid, {
              type: 'payment',
              title: 'Pedido Pix aguardando aprovação',
              body: `${me.displayName} — plano ${plan}.`,
              link: '/dev',
            }),
          );
      });
    },
    [currentUserId, mutate, notify],
  );

  const setSubscription = useCallback(
    (userId: string, plan: 'free' | 'reader' | 'writer', method: 'pix' | 'card' | 'granted') => {
      mutate((d) => {
        const u = d.users.find((x) => x.uid === userId);
        if (!u) return;
        u.subscription = {
          plan,
          status: plan === 'free' ? 'none' : 'active',
          renewsAt: plan === 'free' ? null : new Date(Date.now() + 30 * 86400000).toISOString(),
          method,
        };
        u.badges = Array.from(new Set([...badgesForSubscription(plan), ...u.badges.filter((b) => b === 'fundador' || b === 'beta')]));
        if (plan === 'writer') {
          u.boostsAvailable = 2;
          u.boostsResetAt = nowIso();
          if (!u.titles.includes('autor-verificado')) u.titles.push('autor-verificado');
        }
        if (plan !== 'free') {
          if (!u.achievements.includes('assinante')) {
            u.achievements.push('assinante');
            u.xp += 200;
          }
        }
      });
    },
    [mutate],
  );

  const approvePixOrder = useCallback(
    (orderId: string) => {
      mutate((d) => {
        const o = d.pixOrders.find((x) => x.id === orderId);
        if (!o) return;
        o.status = 'approved';
        const u = d.users.find((x) => x.uid === o.userId);
        if (!u) return;
        u.subscription = {
          plan: o.plan,
          status: 'active',
          renewsAt: new Date(Date.now() + 30 * 86400000).toISOString(),
          method: 'pix',
        };
        u.badges = Array.from(new Set([...u.badges, ...badgesForSubscription(o.plan)]));
        if (o.plan === 'writer') {
          u.boostsAvailable = 2;
          if (!u.titles.includes('autor-verificado')) u.titles.push('autor-verificado');
        }
        notify(d, u.uid, {
          type: 'payment',
          title: 'Assinatura ativada',
          body: `Plano ${o.plan === 'writer' ? 'Escritor' : 'Leitor'} liberado via Pix.`,
          link: '/assinaturas',
        });
      });
      pushToast({ title: 'Pedido aprovado', body: 'Assinatura liberada.', tone: 'success' });
    },
    [mutate, notify, pushToast],
  );

  const rejectPixOrder = useCallback(
    (orderId: string) => {
      mutate((d) => {
        const o = d.pixOrders.find((x) => x.id === orderId);
        if (!o) return;
        o.status = 'rejected';
        notify(d, o.userId, {
          type: 'payment',
          title: 'Comprovante recusado',
          body: 'O código E2EID não pôde ser validado. Envie um novo comprovante.',
          link: '/assinaturas',
        });
      });
      pushToast({ title: 'Pedido recusado', tone: 'warn' });
    },
    [mutate, notify, pushToast],
  );

  const banUser = useCallback(
    (userId: string, banned: boolean) => {
      mutate((d) => {
        const u = d.users.find((x) => x.uid === userId);
        if (u) u.banned = banned;
      });
      pushToast({ title: banned ? 'Usuário banido' : 'Banimento revogado', tone: banned ? 'error' : 'success' });
    },
    [mutate, pushToast],
  );

  const adjustKards = useCallback(
    (userId: string, delta: number, reason: string) => {
      addKards(userId, delta, reason);
      pushToast({ title: 'Kards ajustados', body: `${delta > 0 ? '+' : ''}${delta} Kards`, tone: 'success' });
    },
    [addKards, pushToast],
  );

  const audit = useCallback(
    (action: string, target: string) => {
      const me = dbRef.current.users.find((u) => u.uid === currentUserId);
      mutate((d) => {
        d.auditLogs.unshift({
          id: makeId('log'),
          actorId: me?.uid ?? 'system',
          actorName: me?.displayName ?? 'Sistema',
          action,
          target,
          createdAt: nowIso(),
        });
      });
    },
    [currentUserId, mutate],
  );

  const resetDemoData = useCallback(() => {
    const fresh = buildSeed();
    setDb(fresh);
    pushToast({ title: 'Dados de demonstração restaurados', tone: 'success' });
  }, [pushToast]);

  const value: StoreValue = {
    db,
    currentUser,
    toasts,
    pushToast,
    dismissToast,
    setSessionUser,
    updateUser,
    updateBranding,
    awardXp,
    grantAchievement,
    equipTitle,
    addKards,
    toggleFollow,
    isFollowing,
    setLibrary,
    toggleFavoritePost,
    createBook,
    updateBook,
    deleteBook,
    addChapter,
    updateChapter,
    deleteChapter,
    addReview,
    createCommunity,
    joinCommunity,
    leaveCommunity,
    setMemberRole,
    setMemberModeration,
    updateCommunity,
    createPost,
    deletePost,
    toggleLikePost,
    toggleSavePost,
    votePoll,
    addChapterComment,
    editChapterComment,
    deleteChapterComment,
    addPostComment,
    editPostComment,
    deletePostComment,
    applyBeta,
    decideBeta,
    submitBetaFeedback,
    markNotificationRead,
    markAllNotificationsRead,
    createReport,
    resolveReport,
    boostBook,
    consumeBoost,
    createPixOrder,
    approvePixOrder,
    rejectPixOrder,
    setSubscription,
    banUser,
    adjustKards,
    audit,
    resetDemoData,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore precisa estar dentro de <StoreProvider>.');
  return ctx;
}
