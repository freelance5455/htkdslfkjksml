import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, Bookmark, CheckCircle2, Heart, HeartOff, Play, Trash2 } from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Badge, EmptyState, Pills, Progress, Stars, btnGhost, btnPink } from '../components/ui';
import { compact, cx, timeAgo } from '../lib/utils';
import type { LibraryStatus } from '../types';

type Tab = 'reading' | 'completed' | 'saved' | 'favorite' | 'posts';

export default function LibraryView() {
  const { db, currentUser, setLibrary, toggleSavePost } = useStore();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('reading');

  const shelf = currentUser ? db.libraries[currentUser.uid] ?? {} : {};
  const entries = useMemo(
    () =>
      Object.values(shelf)
        .map((item) => ({ item, book: db.books.find((b) => b.id === item.bookId) }))
        .filter((x) => x.book)
        .sort((a, b) => +new Date(b.item.updatedAt) - +new Date(a.item.updatedAt)),
    [shelf, db.books],
  );

  const counts = {
    reading: entries.filter((e) => e.item.status === 'reading').length,
    completed: entries.filter((e) => e.item.status === 'completed').length,
    saved: entries.filter((e) => e.item.status === 'saved').length,
    favorite: entries.filter((e) => e.item.status === 'favorite').length,
  };

  const filtered = entries.filter((e) => e.item.status === (tab as LibraryStatus));
  const savedPosts = useMemo(() => {
    if (!currentUser) return [];
    const ids = db.favoritePosts[currentUser.uid] ?? [];
    return [...db.posts, ...db.fluxPosts].filter((p) => ids.includes(p.id));
  }, [currentUser, db.favoritePosts, db.posts, db.fluxPosts]);

  if (!currentUser) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20">
        <EmptyState
          icon={<BookOpen size={30} />}
          title="Sua biblioteca está esperando"
          body="Entre para salvar obras, favoritar histórias e sincronizar seu progresso de leitura entre dispositivos."
          action={
            <button type="button" onClick={() => navigate('/entrar')} className={btnPink}>
              Entrar na KORDEL
            </button>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 pb-10 pt-5 sm:px-6">
      <div className="mb-4">
        <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">Minha estante</p>
        <h1 className="mt-1 text-[23px] font-bold tracking-tight text-chalk">Biblioteca</h1>
        <p className="mt-1 text-[12px] text-mute">
          {compact(entries.length)} obras na estante · {counts.completed} concluídas · {savedPosts.length} posts salvos
        </p>
      </div>

      <Pills
        className="mb-4 w-full sm:w-auto"
        items={[
          { id: 'reading', label: 'Lendo', count: counts.reading },
          { id: 'completed', label: 'Concluídos', count: counts.completed },
          { id: 'saved', label: 'Salvos', count: counts.saved },
          { id: 'favorite', label: 'Favoritos', count: counts.favorite },
          { id: 'posts', label: 'Posts Favoritos', count: savedPosts.length },
        ]}
        value={tab}
        onChange={(v) => setTab(v as Tab)}
      />

      {tab === 'posts' ? (
        savedPosts.length === 0 ? (
          <EmptyState
            icon={<Bookmark size={28} />}
            title="Nenhum post salvo"
            body="No Flux e nas comunidades, toque no ícone de marcador para guardar posts aqui — eles ficam disponíveis offline na sua estante."
            action={
              <button type="button" onClick={() => navigate('/social/flux')} className={btnGhost}>
                Abrir o Flux
              </button>
            }
          />
        ) : (
          <div className="grid gap-2.5 sm:grid-cols-2">
            {savedPosts.map((p) => (
              <article key={p.id} className="liquid-card p-3">
                <div className="flex items-center gap-2">
                  <img src={p.authorPhoto} alt="" className="h-7 w-7 rounded-full object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11.5px] font-semibold text-chalk">{p.authorName}</p>
                    <p className="text-[9.5px] text-faint">
                      {timeAgo(p.createdAt)} atrás · {p.communityName ?? 'Flux'}
                    </p>
                  </div>
                  <Badge tone="neutral" className="!text-[9px]">
                    {p.type}
                  </Badge>
                </div>
                <p className="clamp-4 mt-2 text-[12px] leading-relaxed text-mute">{p.text}</p>
                {p.media[0] && (
                  <img src={p.media[0]} alt="" className="mt-2 h-32 w-full rounded-lg object-cover" />
                )}
                <div className="mt-2 flex items-center gap-3 text-[10.5px] text-faint">
                  <span className="inline-flex items-center gap-1">
                    <Heart size={10} /> {p.likes.length}
                  </span>
                  <span>{p.comments.length} comentários</span>
                  <button
                    type="button"
                    onClick={() => toggleSavePost(p.id)}
                    className="ml-auto inline-flex items-center gap-1 text-[#fca5a5] hover:text-[#f87171]"
                  >
                    <Trash2 size={10} /> remover
                  </button>
                </div>
              </article>
            ))}
          </div>
        )
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<BookOpen size={28} />}
          title={
            tab === 'reading' ? 'Nada em andamento'
            : tab === 'completed' ? 'Nenhuma obra concluída'
            : tab === 'saved' ? 'Nenhuma obra salva'
            : 'Nenhum favorito ainda'
          }
          body={
            tab === 'reading'
              ? 'Comece uma leitura e o progresso aparece aqui automaticamente, capítulo por capítulo.'
              : tab === 'completed'
                ? 'Ao terminar uma obra, ela vem para cá com o selo de concluída.'
                : tab === 'saved'
                  ? 'Salve obras para ler depois. Elas não entram no seu progresso até você abrir.'
                  : 'Favoritos são as obras que você quer reler ou recomendar.'
          }
          action={
            <button type="button" onClick={() => navigate('/explorar')} className={btnPink}>
              Explorar obras
            </button>
          }
        />
      ) : (
        <div className="grid gap-2.5 sm:grid-cols-2">
          {filtered.map(({ book, item }) => {
            const b = book!;
            const chapter = b.chapters.find((c) => c.id === item.lastChapterId) ?? b.chapters[0];
            const p =
              item.progress ||
              Math.round(((chapter ? b.chapters.findIndex((c) => c.id === chapter.id) + 1 : 0) / Math.max(1, b.chapters.length)) * 100);
            return (
              <div key={b.id} className="liquid-card liquid-card-hover flex gap-3 p-2.5">
                <button type="button" onClick={() => navigate(`/obra/${b.id}`)} className="shrink-0">
                  <img src={b.cover} alt="" className="h-[110px] w-[74px] rounded-lg object-cover" />
                </button>
                <div className="min-w-0 flex-1">
                  <button
                    type="button"
                    onClick={() => navigate(`/obra/${b.id}`)}
                    className="clamp-2 text-left text-[12.5px] font-semibold leading-tight text-chalk hover:text-hot-300"
                  >
                    {b.title}
                  </button>
                  <p className="mt-0.5 truncate text-[10.5px] text-faint">{b.authorName}</p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <Stars value={b.rating} size={9} />
                    <span className="text-[9.5px] text-faint">{b.chapters.length} caps</span>
                  </div>
                  <div className="mt-1.5 flex items-center gap-2">
                    <Progress value={p} className="flex-1" />
                    <span className="text-[9.5px] tabular-nums text-mute">{p}%</span>
                  </div>
                  <div className="mt-1.5 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => navigate(chapter ? `/ler/${b.id}/${chapter.id}` : `/ler/${b.id}`)}
                      className="inline-flex items-center gap-1 rounded-lg bg-hot-500/15 px-2 py-1 text-[10px] font-semibold text-hot-300 hover:bg-hot-500/25"
                    >
                      <Play size={9} /> {item.status === 'completed' ? 'Reler' : 'Continuar'}
                    </button>
                    {item.status !== 'completed' && (
                      <button
                        type="button"
                        onClick={() => setLibrary(b.id, { status: 'completed', progress: 100 })}
                        className="inline-flex items-center gap-1 rounded-lg border border-white/10 px-2 py-1 text-[10px] text-mute hover:text-[#86efac]"
                      >
                        <CheckCircle2 size={9} /> Concluir
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setLibrary(b.id, { status: item.status === 'favorite' ? 'reading' : 'favorite' })}
                      className={cx(
                        'ml-auto rounded-lg p-1.5 transition-colors',
                        item.status === 'favorite' ? 'text-hot-500' : 'text-faint hover:text-hot-400',
                      )}
                      aria-label="Favoritar"
                    >
                      {item.status === 'favorite' ? <Heart size={12} className="fill-hot-500" /> : <Heart size={12} />}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {entries.length > 0 && tab !== 'posts' && (
        <div className="liquid-card mt-5 flex flex-wrap items-center justify-between gap-3 p-3.5">
          <div>
            <p className="text-[12px] font-semibold text-chalk">Estatísticas da estante</p>
            <p className="mt-0.5 text-[10.5px] text-mute">
              {entries.length} obras · {Object.values(shelf).reduce((a, i) => a + (i.status === 'completed' ? 1 : 0), 0)} concluídas ·{' '}
              {entries.reduce((a, e) => a + (e.book?.chapters.length ?? 0), 0)} capítulos disponíveis
            </p>
          </div>
          <button type="button" onClick={() => navigate('/ranking')} className={btnGhost}>
            Ver ranking
          </button>
        </div>
      )}
    </div>
  );
}
