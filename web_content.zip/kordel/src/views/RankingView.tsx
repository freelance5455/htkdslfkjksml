import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Award, Crown, Flame, Medal, Sparkles, Trophy, TrendingUp } from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Avatar, Badge, EmptyState, Pills, Progress, SectionHeader, btnPink } from '../components/ui';
import { compact, cx } from '../lib/utils';
import { ACHIEVEMENTS, levelFromXp, TITLES, XP_REWARDS } from '../lib/xp';

export default function RankingView({ onOpenProfile }: { onOpenProfile: (uid: string) => void }) {
  const { db, currentUser } = useStore();
  const navigate = useNavigate();
  const [scope, setScope] = useState<'semanal' | 'geral' | 'autores'>('semanal');

  const ranked = useMemo(() => {
    let list = db.users.filter((u) => !u.banned);
    if (scope === 'autores') {
      list = list.filter((u) => db.books.some((b) => b.authorId === u.uid));
    }
    return [...list].sort((a, b) => b.xp - a.xp);
  }, [db.users, db.books, scope]);

  const myIndex = currentUser ? ranked.findIndex((u) => u.uid === currentUser.uid) : -1;
  const myLevel = currentUser ? levelFromXp(currentUser.xp) : null;

  const weeklyTop = useMemo(() => {
    // Ranking semanal: XP derivado da atividade registrada nas transações recentes.
    const since = Date.now() - 7 * 86400000;
    const byUser = new Map<string, number>();
    db.transactions
      .filter((t) => t.type === 'credit' && +new Date(t.createdAt) >= since)
      .forEach((t) => byUser.set(t.userId, (byUser.get(t.userId) ?? 0) + t.amount));
    return db.users
      .filter((u) => !u.banned)
      .map((u) => ({ user: u, weekXp: byUser.get(u.uid) ?? Math.round(u.xp * 0.12) }))
      .sort((a, b) => b.weekXp - a.weekXp);
  }, [db.users, db.transactions]);

  const board = scope === 'semanal' ? weeklyTop.map((w) => ({ ...w.user, weekXp: w.weekXp })) : ranked;

  return (
    <div className="mx-auto max-w-3xl px-4 pb-10 pt-5 sm:px-6">
      <div className="mb-4">
        <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">Gamificação</p>
        <h1 className="mt-1 text-[23px] font-bold tracking-tight text-chalk">Ranking</h1>
        <p className="mt-1 text-[12px] text-mute">
          XP por leitura, escrita e comunidade · níveis até {levelFromXp(Number.MAX_SAFE_INTEGER).level} e ciclos de prestígio
        </p>
      </div>

      {currentUser && myLevel ? (
        <div className="liquid-card mb-4 p-3.5">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Avatar src={currentUser.photoURL} name={currentUser.displayName} size={44} ring />
              {currentUser.subscription.status === 'active' && (
                <Crown size={13} className="absolute -right-1 -top-1 text-hot-400" />
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12.5px] font-semibold text-chalk">{currentUser.displayName}</p>
              <p className="text-[10.5px] text-faint">
                {myIndex >= 0 ? `${myIndex + 1}º lugar` : 'fora do ranking'} · {compact(currentUser.xp)} XP
              </p>
            </div>
            <Badge tone="hot" icon={<Sparkles size={9} />}>
              {myLevel.levelLabel}
            </Badge>
          </div>
          <div className="mt-2.5">
            <div className="mb-1 flex justify-between text-[10px] text-faint">
              <span>Próximo nível</span>
              <span className="tabular-nums">
                {myLevel.xpIntoLevel}/{myLevel.xpForLevel} XP
              </span>
            </div>
            <Progress value={myLevel.progress} />
          </div>
        </div>
      ) : (
        <div className="liquid-card mb-4 flex items-center justify-between gap-3 p-3.5">
          <p className="text-[12px] text-mute">Entre para aparecer no ranking e acumular XP.</p>
          <button type="button" onClick={() => navigate('/entrar')} className={cx(btnPink, '!py-1.5 !text-[11.5px]')}>
            Entrar
          </button>
        </div>
      )}

      <Pills
        className="mb-3"
        items={[
          { id: 'semanal', label: 'Semanal' },
          { id: 'geral', label: 'Geral' },
          { id: 'autores', label: 'Autores' },
        ]}
        value={scope}
        onChange={(v) => setScope(v as typeof scope)}
      />

      {board.length === 0 ? (
        <EmptyState icon={<Trophy size={26} />} title="Ranking vazio" body="Assine o plano Leitor para liberar XP e participar." />
      ) : (
        <div className="liquid-card divide-y divide-white/[0.05] overflow-hidden">
          {board.map((u, i) => {
            const l = levelFromXp(u.xp);
            const weekXp = (u as typeof u & { weekXp?: number }).weekXp;
            const isMe = u.uid === currentUser?.uid;
            return (
              <button
                key={u.uid}
                type="button"
                onClick={() => onOpenProfile(u.uid)}
                className={cx(
                  'flex w-full items-center gap-2.5 px-3 py-2.5 text-left transition-colors hover:bg-white/[0.035]',
                  isMe && 'bg-hot-500/[0.07]',
                )}
              >
                <span
                  className={cx(
                    'grid h-7 w-7 shrink-0 place-items-center rounded-lg text-[11px] font-bold',
                    i === 0
                      ? 'bg-hot-500 text-[#1a1a1a]'
                      : i === 1
                        ? 'bg-white/20 text-chalk'
                        : i === 2
                          ? 'bg-[#fbbf24]/25 text-[#fcd34d]'
                          : 'bg-white/[0.06] text-faint',
                  )}
                >
                  {i < 3 ? <Medal size={13} /> : i + 1}
                </span>
                <Avatar src={u.photoURL} name={u.displayName} size={30} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-1.5">
                    <span className="truncate text-[12px] font-semibold text-chalk">{u.displayName}</span>
                    {isMe && <span className="shrink-0 text-[9px] text-hot-300">você</span>}
                    {u.badges.includes('escritor-verificado') && <span className="shrink-0 text-[9px]">✅</span>}
                  </span>
                  <span className="block truncate text-[10px] text-faint">
                    {l.levelLabel} · {u.achievements.length} conquistas
                    {u.equippedTitle && ` · ${TITLES.find((t) => t.id === u.equippedTitle)?.name ?? ''}`}
                  </span>
                </span>
                <span className="shrink-0 text-right">
                  <span className="block text-[11.5px] font-bold tabular-nums text-hot-300">
                    {compact(scope === 'semanal' ? weekXp ?? u.xp : u.xp)}
                  </span>
                  <span className="block text-[9px] text-faint">XP</span>
                </span>
              </button>
            );
          })}
        </div>
      )}

      <section className="mt-6">
        <SectionHeader eyebrow="Como ganhar XP" title="Recompensas de progressão" />
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            { label: 'Capítulo concluído', xp: XP_REWARDS.chapterComplete, icon: '📖' },
            { label: 'Comentário', xp: XP_REWARDS.chapterComment, icon: '💬' },
            { label: 'Post no Flux', xp: XP_REWARDS.createPost, icon: '✨' },
            { label: 'Comunidade criada', xp: XP_REWARDS.createCommunity, icon: '🏛️' },
            { label: 'Avaliação', xp: XP_REWARDS.reviewBook, icon: '⭐' },
            { label: 'Feedback beta', xp: XP_REWARDS.betaFeedback, icon: '🧪' },
            { label: 'Seguir alguém', xp: XP_REWARDS.followUser, icon: '👤' },
            { label: 'Curtir post', xp: XP_REWARDS.likePost, icon: '❤️' },
          ].map((r) => (
            <div key={r.label} className="rounded-xl border border-white/[0.07] bg-ink-900/50 p-2.5">
              <p className="text-[14px]">{r.icon}</p>
              <p className="mt-1 text-[10.5px] leading-tight text-mute">{r.label}</p>
              <p className="mt-0.5 text-[11px] font-bold text-hot-300">+{r.xp} XP</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-6">
        <SectionHeader eyebrow="Curva de progressão" title="Marcos do nível" action="Conquistas" onAction={() => navigate('/conquistas')} />
        <div className="liquid-card space-y-2 p-3.5">
          {[1, 5, 12, 20, 27, 33].map((lv) => {
            const l = levelFromXp(0);
            const requiredXp = Array.from({ length: lv - 1 }).reduce<number>((acc, _, i) => acc + Math.round(90 * Math.pow(i + 1, 1.62) + 110 * (i + 1) + 90), 0);
            const unlocked = currentUser ? currentUser.xp >= requiredXp : false;
            return (
              <div key={lv} className="flex items-center gap-2.5">
                <span
                  className={cx(
                    'grid h-7 w-7 shrink-0 place-items-center rounded-lg text-[10.5px] font-bold',
                    unlocked ? 'bg-hot-500 text-[#1a1a1a]' : 'bg-white/[0.06] text-faint',
                  )}
                >
                  {lv}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-[11.5px] font-medium text-chalk">
                    {lv === 33 ? 'Nível máximo — Mestre Kordel' : `Nível ${lv}`}
                  </p>
                  <p className="text-[9.5px] text-faint">{compact(requiredXp)} XP acumulados</p>
                </div>
                {unlocked && <Badge tone="ok">desbloqueado</Badge>}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
