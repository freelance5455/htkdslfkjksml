import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  BookOpen,
  Check,
  ChevronLeft,
  ChevronRight,
  Flag,
  List,
  Lock,
  MessageCircle,
  Minus,
  Plus,
  Send,
  Settings2,
  Trash2,
  Type,
  X,
  Pencil,
} from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Avatar, Badge, Stars, btnGhost, btnPink, inputCls } from '../components/ui';
import { Modal } from '../components/ui';
import { cx, pct, timeAgo } from '../lib/utils';
import { XP_REWARDS } from '../lib/xp';

type FontFamily = 'literata' | 'sans' | 'serif';

const FONT_LABEL: Record<FontFamily, string> = { literata: 'Literata', sans: 'Sans', serif: 'Serif' };

export default function ReaderView() {
  const { bookId, chapterId } = useParams<{ bookId: string; chapterId?: string }>();
  const { db, currentUser, setLibrary, awardXp, addChapterComment, editChapterComment, deleteChapterComment, createReport } = useStore();
  const navigate = useNavigate();
  const [fontSize, setFontSize] = useState(18);
  const [font, setFont] = useState<FontFamily>('literata');
  const [drawer, setDrawer] = useState(false);
  const [settings, setSettings] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [replyTo, setReplyTo] = useState<{ id: string; name: string } | null>(null);
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(null);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState('Spoiler sem aviso');
  const scrollRef = useRef<HTMLDivElement>(null);
  const grantedRef = useRef<Set<string>>(new Set());

  const book = db.books.find((b) => b.id === bookId);
  const published = useMemo(() => book?.chapters.filter((c) => c.status === 'published') ?? [], [book]);

  const chapter = useMemo(() => {
    if (!chapterId) return published[0];
    return published.find((c) => c.id === chapterId) ?? published[0];
  }, [chapterId, published]);

  const idx = chapter ? published.findIndex((c) => c.id === chapter.id) : -1;
  const prev = idx > 0 ? published[idx - 1] : null;
  const next = idx >= 0 && idx < published.length - 1 ? published[idx + 1] : null;
  const progress = idx >= 0 ? pct(idx + 1, published.length) : 0;

  const isAuthor = currentUser?.uid === book?.authorId;
  const approvedBeta = db.betaApplications.some(
    (a) => a.bookId === bookId && a.userId === currentUser?.uid && a.status === 'approved',
  );
  const hasPlan = currentUser?.subscription.status === 'active';
  const locked = Boolean(chapter?.earlyAccess && !isAuthor && !approvedBeta && !hasPlan);

  // Salvamento automático de progresso na biblioteca.
  useEffect(() => {
    if (!currentUser || !book || !chapter || locked) return;
    setLibrary(book.id, {
      status: 'reading',
      progress,
      lastChapterId: chapter.id,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chapter?.id, progress, locked]);

  // XP ao concluir o capítulo (uma vez por capítulo por sessão).
  useEffect(() => {
    if (!currentUser || !chapter || locked) return;
    if (grantedRef.current.has(chapter.id)) return;
    grantedRef.current.add(chapter.id);
    const t = window.setTimeout(() => {
      awardXp(XP_REWARDS.chapterComplete, `Capítulo concluído — ${chapter.title}`);
    }, 22000);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chapter?.id, locked]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 0 });
    window.scrollTo({ top: 0 });
  }, [chapter?.id]);

  if (!book) {
    return (
      <div className="grid min-h-dvh place-items-center bg-[#171717] px-4">
        <div className="text-center">
          <p className="text-[13px] text-mute">Obra não encontrada.</p>
          <button type="button" onClick={() => navigate('/')} className={cx(btnPink, 'mt-3')}>
            Voltar ao início
          </button>
        </div>
      </div>
    );
  }

  const comments = chapter?.comments ?? [];
  const roots = comments.filter((c) => !c.parentId);

  const submitComment = () => {
    if (!currentUser || !chapter || !commentText.trim()) return;
    if (editing) {
      editChapterComment(book.id, chapter.id, editing.id, commentText.trim());
      setEditing(null);
      setCommentText('');
      return;
    }
    addChapterComment(book.id, chapter.id, commentText.trim(), replyTo?.id ?? null);
    setCommentText('');
    setReplyTo(null);
  };

  return (
    <div className={cx('reader-surface min-h-dvh', `reader-${font}`)}>
      {/* Barra do leitor */}
      <div className="sticky top-0 z-40 border-b border-white/[0.06] bg-[#171717]/92 backdrop-blur-xl">
        <div className="mx-auto flex h-[54px] max-w-3xl items-center gap-1 px-3">
          <button
            type="button"
            onClick={() => navigate(`/obra/${book.id}`)}
            className="rounded-lg p-2 text-mute transition-colors hover:bg-white/[0.07] hover:text-chalk"
            aria-label="Voltar para a obra"
          >
            <ArrowLeft size={17} />
          </button>
          <div className="min-w-0 flex-1 px-1">
            <p className="truncate text-[11.5px] font-semibold text-chalk">{book.title}</p>
            <p className="truncate text-[10px] text-faint">
              {chapter ? `Cap. ${chapter.number} · ${chapter.title}` : 'Sem capítulos'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setDrawer(true)}
            className="rounded-lg p-2 text-mute transition-colors hover:bg-white/[0.07] hover:text-chalk"
            aria-label="Capítulos"
          >
            <List size={17} />
          </button>
          <button
            type="button"
            onClick={() => setSettings((v) => !v)}
            className={cx(
              'rounded-lg p-2 transition-colors hover:bg-white/[0.07]',
              settings ? 'text-hot-400' : 'text-mute hover:text-chalk',
            )}
            aria-label="Preferências de leitura"
          >
            <Settings2 size={17} />
          </button>
        </div>
        <div className="h-[2px] bg-white/[0.06]">
          <div className="h-full bg-hot-500 transition-[width] duration-300" style={{ width: `${progress}%` }} />
        </div>

        {settings && (
          <div className="border-t border-white/[0.06] bg-[#1b1b1b] px-3 py-3">
            <div className="mx-auto flex max-w-3xl flex-wrap items-center gap-x-5 gap-y-3">
              <div className="flex items-center gap-2">
                <Type size={13} className="text-faint" />
                <span className="text-[11px] text-mute">Tamanho</span>
                <button
                  type="button"
                  onClick={() => setFontSize((s) => Math.max(14, s - 1))}
                  className="rounded-md border border-white/10 p-1 text-mute hover:text-chalk"
                  aria-label="Diminuir fonte"
                >
                  <Minus size={12} />
                </button>
                <span className="w-7 text-center text-[11px] tabular-nums text-chalk">{fontSize}</span>
                <button
                  type="button"
                  onClick={() => setFontSize((s) => Math.min(30, s + 1))}
                  className="rounded-md border border-white/10 p-1 text-mute hover:text-chalk"
                  aria-label="Aumentar fonte"
                >
                  <Plus size={12} />
                </button>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-mute">Tipografia</span>
                {(Object.keys(FONT_LABEL) as FontFamily[]).map((f) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setFont(f)}
                    className={cx(
                      'rounded-lg border px-2 py-1 text-[11px] transition-colors',
                      font === f ? 'border-hot-500 bg-hot-500/12 text-hot-300' : 'border-white/10 text-mute hover:text-chalk',
                      f === 'literata' && 'font-literata',
                      f === 'serif' && 'font-serif',
                    )}
                  >
                    {FONT_LABEL[f]}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <div ref={scrollRef} className="mx-auto max-w-[38rem] px-5 pb-24 pt-7">
        {locked ? (
          <div className="rounded-2xl border border-[#fbbf24]/30 bg-[#fbbf24]/[0.07] p-6 text-center">
            <Lock size={26} className="mx-auto text-[#fcd34d]" />
            <h2 className="mt-3 text-[15px] font-bold text-chalk">Capítulo antecipado</h2>
            <p className="mx-auto mt-1.5 max-w-sm text-[12px] leading-relaxed text-mute">
              Este capítulo está liberado para assinantes e leitores beta aprovados. Assine o plano Leitor por R$ 4,90/mês ou candidate-se à leitura beta desta obra.
            </p>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              <button type="button" onClick={() => navigate('/assinaturas')} className={btnPink}>
                Ver assinaturas
              </button>
              <button type="button" onClick={() => navigate(`/obra/${book.id}`)} className={btnGhost}>
                Página da obra
              </button>
            </div>
          </div>
        ) : !chapter ? (
          <p className="py-16 text-center text-[13px] text-faint">Esta obra ainda não tem capítulos publicados.</p>
        ) : (
          <>
            <p className="mb-1 text-center text-[10px] font-semibold uppercase tracking-[0.22em] text-hot-400">
              Capítulo {chapter.number}
            </p>
            <h1 className="mb-1 text-center text-[22px] font-bold leading-tight text-chalk">{chapter.title}</h1>
            <p className="mb-7 text-center text-[10.5px] text-faint">
              {book.authorName} · {chapter.content.split(/\s+/).length} palavras · ~
              {Math.max(1, Math.round(chapter.content.split(/\s+/).length / 200))} min
            </p>

            <article
              className="reader-content reading-body text-chalk/90"
              style={{ fontSize, lineHeight: font === 'sans' ? 1.75 : 1.88 }}
            >
              {chapter.content.split('\n\n').map((para, i) => (
                <p key={i} className={i === 0 ? 'drop-cap' : undefined}>
                  {para}
                </p>
              ))}
            </article>

            {/* Navegação */}
            <div className="mt-8 flex items-center gap-2 border-t border-white/[0.07] pt-5">
              <button
                type="button"
                disabled={!prev}
                onClick={() => prev && navigate(`/ler/${book.id}/${prev.id}`)}
                className={cx(btnGhost, 'flex-1 !text-[12px] disabled:opacity-35')}
              >
                <ChevronLeft size={14} /> {prev ? 'Anterior' : 'Início'}
              </button>
              <button
                type="button"
                onClick={() => navigate(`/obra/${book.id}`)}
                className="rounded-xl border border-white/10 p-2.5 text-mute hover:text-chalk"
                aria-label="Índice"
              >
                <BookOpen size={15} />
              </button>
              <button
                type="button"
                disabled={!next}
                onClick={() => next && navigate(`/ler/${book.id}/${next.id}`)}
                className={cx(btnPink, 'flex-1 !text-[12px] disabled:opacity-35')}
              >
                {next ? 'Próximo' : 'Fim'} <ChevronRight size={14} />
              </button>
            </div>

            {/* Comentários */}
            <section className="mt-9">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-chalk">
                  <MessageCircle size={14} className="text-hot-400" />
                  Comentários do capítulo
                  <span className="text-[11px] font-normal text-faint">({comments.length})</span>
                </h2>
                <button
                  type="button"
                  onClick={() => setReportOpen(true)}
                  className="inline-flex items-center gap-1 text-[10.5px] text-faint hover:text-[#fca5a5]"
                >
                  <Flag size={10} /> Denunciar
                </button>
              </div>

              {currentUser ? (
                <div className="mb-4 rounded-xl border border-white/[0.08] bg-[#202020] p-2.5">
                  {replyTo && (
                    <p className="mb-1.5 flex items-center justify-between rounded-lg bg-hot-500/10 px-2 py-1 text-[10.5px] text-hot-300">
                      Respondendo {replyTo.name}
                      <button type="button" onClick={() => setReplyTo(null)} aria-label="Cancelar resposta">
                        <X size={11} />
                      </button>
                    </p>
                  )}
                  {editing && (
                    <p className="mb-1.5 rounded-lg bg-[#fbbf24]/10 px-2 py-1 text-[10.5px] text-[#fcd34d]">
                      Editando comentário
                    </p>
                  )}
                  <div className="flex gap-2">
                    <Avatar src={currentUser.photoURL} name={currentUser.displayName} size={28} />
                    <textarea
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      rows={2}
                      placeholder="Comente sem spoilers…"
                      className={cx(inputCls, 'min-h-[42px] resize-none !bg-[#191919] !text-[12px]')}
                    />
                    <button
                      type="button"
                      onClick={submitComment}
                      disabled={!commentText.trim()}
                      className="shrink-0 self-end rounded-lg bg-hot-500 p-2 text-[#1a1a1a] disabled:opacity-40"
                      aria-label="Enviar"
                    >
                      <Send size={14} />
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => navigate('/entrar')}
                  className="mb-4 w-full rounded-xl border border-white/10 bg-[#202020] py-2.5 text-[11.5px] text-mute hover:text-chalk"
                >
                  Entre para comentar este capítulo
                </button>
              )}

              {roots.length === 0 ? (
                <p className="py-6 text-center text-[11.5px] text-faint">
                  Nenhum comentário ainda. Comece a conversa.
                </p>
              ) : (
                <div className="space-y-3">
                  {roots.map((c) => {
                    const replies = comments.filter((r) => r.parentId === c.id);
                    return (
                      <div key={c.id} className="rounded-xl border border-white/[0.06] bg-[#1d1d1d] p-2.5">
                        <CommentHead
                          name={c.userName}
                          photo={c.userPhoto}
                          createdAt={c.createdAt}
                          edited={Boolean(c.editedAt)}
                          mine={c.userId === currentUser?.uid}
                          onReply={() => {
                            setReplyTo({ id: c.id, name: c.userName });
                            setCommentText('');
                          }}
                          onEdit={() => {
                            setEditing({ id: c.id, text: c.content });
                            setCommentText(c.content);
                          }}
                          onDelete={() => deleteChapterComment(book.id, chapter.id, c.id)}
                          onProfile={() => navigate(`/perfil/${c.userId}`)}
                        />
                        <p className="mt-1.5 pl-9 text-[12px] leading-relaxed text-mute">{c.content}</p>

                        {replies.length > 0 && (
                          <div className="mt-2 space-y-2 border-l border-white/[0.08] pl-3">
                            {replies.map((r) => (
                              <div key={r.id}>
                                <CommentHead
                                  name={r.userName}
                                  photo={r.userPhoto}
                                  createdAt={r.createdAt}
                                  edited={Boolean(r.editedAt)}
                                  mine={r.userId === currentUser?.uid}
                                  onReply={() => {
                                    setReplyTo({ id: c.id, name: r.userName });
                                    setCommentText('');
                                  }}
                                  onEdit={() => {
                                    setEditing({ id: r.id, text: r.content });
                                    setCommentText(r.content);
                                  }}
                                  onDelete={() => deleteChapterComment(book.id, chapter.id, r.id)}
                                  onProfile={() => navigate(`/perfil/${r.userId}`)}
                                />
                                <p className="mt-1 pl-8 text-[11.5px] leading-relaxed text-mute">{r.content}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </section>
          </>
        )}
      </div>

      {/* Gaveta de capítulos */}
      {drawer && (
        <div className="fixed inset-0 z-[85]">
          <button
            type="button"
            aria-label="Fechar"
            onClick={() => setDrawer(false)}
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
          />
          <div className="absolute left-0 top-0 h-full w-[min(86vw,340px)] overflow-y-auto border-r border-white/10 bg-[#1c1c1c]">
            <div className="sticky top-0 flex items-center justify-between border-b border-white/[0.07] bg-[#1c1c1c]/95 px-3.5 py-3 backdrop-blur">
              <div className="min-w-0">
                <p className="truncate text-[12px] font-semibold text-chalk">{book.title}</p>
                <p className="text-[10px] text-faint">{published.length} capítulos publicados</p>
              </div>
              <button type="button" onClick={() => setDrawer(false)} className="p-1 text-faint hover:text-chalk" aria-label="Fechar">
                <X size={16} />
              </button>
            </div>
            <ul className="p-2">
              {published.map((c) => {
                const active = c.id === chapter?.id;
                const unlocked = !c.earlyAccess || isAuthor || approvedBeta || hasPlan;
                return (
                  <li key={c.id}>
                    <button
                      type="button"
                      onClick={() => {
                        navigate(`/ler/${book.id}/${c.id}`);
                        setDrawer(false);
                      }}
                      className={cx(
                        'flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-left transition-colors',
                        active ? 'bg-hot-500/12' : 'hover:bg-white/[0.05]',
                      )}
                    >
                      <span
                        className={cx(
                          'grid h-6 w-6 shrink-0 place-items-center rounded-md text-[10.5px] font-semibold',
                          active ? 'bg-hot-500 text-[#1a1a1a]' : 'bg-white/[0.07] text-mute',
                        )}
                      >
                        {c.number}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className={cx('block truncate text-[12px]', active ? 'font-semibold text-hot-300' : 'text-chalk')}>
                          {c.title}
                        </span>
                        <span className="block text-[9.5px] text-faint">
                          {c.content.split(/\s+/).length} palavras
                        </span>
                      </span>
                      {!unlocked && <Lock size={11} className="shrink-0 text-[#fcd34d]" />}
                      {active && <Check size={12} className="shrink-0 text-hot-400" />}
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      )}

      <Modal
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        title="Denunciar capítulo"
        subtitle={chapter?.title}
        footer={
          <button
            type="button"
            className={cx(btnPink, 'w-full')}
            onClick={() => {
              createReport({
                targetType: 'chapter',
                targetId: chapter?.id ?? '',
                targetLabel: `${book.title} — ${chapter?.title}`,
                reason: reportReason,
                details: '',
              });
              setReportOpen(false);
            }}
          >
            Enviar denúncia
          </button>
        }
      >
        <select value={reportReason} onChange={(e) => setReportReason(e.target.value)} className={inputCls}>
          {['Spoiler sem aviso', 'Conteúdo ofensivo', 'Plágio', 'Conteúdo impróprio para a classificação', 'Outro'].map((r) => (
            <option key={r} value={r} className="bg-ink-800">
              {r}
            </option>
          ))}
        </select>
      </Modal>
    </div>
  );
}

function CommentHead({
  name,
  photo,
  createdAt,
  edited,
  mine,
  onReply,
  onEdit,
  onDelete,
  onProfile,
}: {
  name: string;
  photo: string;
  createdAt: string;
  edited: boolean;
  mine: boolean;
  onReply: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onProfile: () => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <button type="button" onClick={onProfile}>
        <Avatar src={photo} name={name} size={24} />
      </button>
      <button type="button" onClick={onProfile} className="min-w-0 flex-1 text-left">
        <span className="block truncate text-[11.5px] font-semibold text-chalk hover:text-hot-300">{name}</span>
        <span className="text-[9.5px] text-faint">
          {timeAgo(createdAt)} atrás{edited ? ' · editado' : ''}
        </span>
      </button>
      <button type="button" onClick={onReply} className="rounded px-1 py-0.5 text-[10.5px] text-faint hover:text-hot-300">
        responder
      </button>
      {mine && (
        <>
          <button type="button" onClick={onEdit} className="rounded p-1 text-faint hover:text-chalk" aria-label="Editar">
            <Pencil size={10} />
          </button>
          <button type="button" onClick={onDelete} className="rounded p-1 text-faint hover:text-[#fca5a5]" aria-label="Excluir">
            <Trash2 size={10} />
          </button>
        </>
      )}
    </div>
  );
}

