import { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ProfileModal } from '../components/Modals';

/** Rota /perfil/:uid — reutiliza o modal público de perfil. */
export default function ProfilePage({ onOpenProfile }: { onOpenProfile: (uid: string) => void }) {
  const { uid } = useParams<{ uid: string }>();
  const navigate = useNavigate();

  useEffect(() => {
    if (uid) onOpenProfile(uid);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [uid]);

  return (
    <div className="mx-auto max-w-2xl px-4 py-16 text-center">
      <p className="text-[12px] text-faint">Abrindo perfil…</p>
      <button
        type="button"
        onClick={() => navigate('/')}
        className="mt-3 rounded-xl border border-white/10 px-3 py-1.5 text-[11px] text-mute hover:text-chalk"
      >
        Voltar ao início
      </button>
      {uid && <ProfileModalWrapper uid={uid} />}
    </div>
  );
}

function ProfileModalWrapper({ uid }: { uid: string }) {
  const navigate = useNavigate();
  return (
    <ProfileModal
      userId={uid}
      onClose={() => navigate(-1)}
      onOpenBook={(id) => navigate(`/obra/${id}`)}
    />
  );
}
