import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Ban,
  BookOpen,
  Check,
  Crown,
  FileWarning,
  Flag,
  Image as ImageIcon,
  Palette,
  ScrollText,
  Search,
  ShieldCheck,
  Trash2,
  Users,
  Wallet,
  X,
} from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Avatar, Badge, EmptyState, Pills, btnGhost, btnPink, inputCls } from '../components/ui';
import { coverArt } from '../lib/art';
import { brl, compact, cx, formatDate, readFileAsDataUrl, timeAgo } from '../lib/utils';
import { uploadMedia } from '../lib/api';
import type { AppUser } from '../types';

type Tab = 'branding' | 'usuarios' | 'destaques' | 'pix' | 'denuncias' | 'conteudo' | 'logs';

export default function DeveloperAdminView({ onOpenProfile }: { onOpenProfile: (uid: string) => void }) {
  const {
    db,
    currentUser,
    updateBranding,
    updateUser,
    banUser,
    adjustKards,
    setSubscription,
    approvePixOrder,
    rejectPixOrder,
    resolveReport,
    deleteBook,
    updateCommunity,
    audit,
    resetDemoData,
    pushToast,
  } = useStore();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('branding');
  const [userQuery, setUserQuery] = useState('');
  const [brandForm, setBrandForm] = useState(db.branding);

  const isDev = currentUser?.role === 'desenvolvedor';

  const users = useMemo(() => {
    const q = userQuery.trim().toLowerCase();
    return db.users.filter((u) => !q || u.displayName.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
  }, [db.users, userQuery]);

  if (!isDev) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20">
        <EmptyState
          icon={<ShieldCheck size={30} />}
          title="Área restrita"
          body="Este painel é exclusivo para o papel desenvolvedor. Toda ação administrativa é registrada nos logs de auditoria."
          action={
            <button type="button" onClick={() => navigate('/entrar')} className={btnPink}>
              Entrar como desenvolvedor
            </button>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 pb-10 pt-5 sm:px-6">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">Administração</p>
          <h1 className="mt-1 text-[23px] font-bold tracking-tight text-chalk">Painel do Desenvolvedor</h1>
          <p className="mt-1 text-[12px] text-mute">
            {db.users.length} usuários · {db.books.length} obras · {db.communities.length} comunidades ·{' '}
            {db.reports.filter((r) => r.status === 'open').length} denúncias abertas
          </p>
        </div>
        <button
          type="button"
          onClick={() => {
            if (window.confirm('Restaurar todos os dados de demonstração? Alterações locais serão perdidas.')) resetDemoData();
          }}
          className={cx(btnGhost, '!py-1.5 !text-[11px]')}
        >
          Restaurar demo
        </button>
      </div>

      <Pills
        className="mb-4 w-full overflow-x-auto"
        items={[
          { id: 'branding', label: 'Branding' },
          { id: 'usuarios', label: 'Usuários', count: db.users.length },
          { id: 'destaques', label: 'Destaques' },
          { id: 'pix', label: 'Pedidos Pix', count: db.pixOrders.filter((o) => o.status === 'pending').length },
          { id: 'denuncias', label: 'Denúncias', count: db.reports.filter((r) => r.status === 'open').length },
          { id: 'conteudo', label: 'Conteúdo' },
          { id: 'logs', label: 'Logs', count: db.auditLogs.length },
        ]}
        value={tab}
        onChange={(v) => setTab(v as Tab)}
      />

      {/* ── BRANDING ─────────────────────────────────────────────────── */}
      {tab === 'branding' && (
        <div className="grid gap-3 lg:grid-cols-[1fr_260px]">
          <div className="liquid-card space-y-3 p-4">
            <div>
              <label className="mb-1 block text-[10.5px] font-semibold uppercase tracking-wide text-faint">Nome do app</label>
              <input
                value={brandForm.appName}
                onChange={(e) => setBrandForm((s) => ({ ...s, appName: e.target.value }))}
                className={inputCls}
              />
            </div>
            <div>
              <label className="mb-1 block text-[10.5px] font-semibold uppercase tracking-wide text-faint">Tagline</label>
              <input
                value={brandForm.tagline}
                onChange={(e) => setBrandForm((s) => ({ ...s, tagline: e.target.value }))}
                className={inputCls}
              />
            </div>
            <div>
              <label className="mb-1 block text-[10.5px] font-semibold uppercase tracking-wide text-faint">Descrição</label>
              <textarea
                value={brandForm.description}
                onChange={(e) => setBrandForm((s) => ({ ...s, description: e.target.value }))}
                rows={3}
                className={cx(inputCls, 'resize-none')}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="mb-1 block text-[10.5px] font-semibold uppercase tracking-wide text-faint">Logo (emoji)</label>
                <input
                  value={brandForm.logoEmoji}
                  onChange={(e) => setBrandForm((s) => ({ ...s, logoEmoji: e.target.value.slice(0, 4) }))}
                  className={inputCls}
                />
              </div>
              <div>
                <label className="mb-1 block text-[10.5px] font-semibold uppercase tracking-wide text-faint">Logo (upload)</label>
                <label className="flex cursor-pointer items-center justify-center gap-1 rounded-xl border border-dashed border-white/15 py-2.5 text-[11px] text-mute hover:text-chalk">
                  <ImageIcon size={12} /> Enviar
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={async (e) => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      const dataUrl = await readFileAsDataUrl(f);
                      let url = dataUrl;
                      try {
                        url = (await uploadMedia(dataUrl, 'banners', 'logo')).url;
                      } catch {
                        /* mantém data URL */
                      }
                      setBrandForm((s) => ({ ...s, logoUrl: url }));
                    }}
                  />
                </label>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                updateBranding({
                  appName: brandForm.appName.trim() || 'KORDEL',
                  tagline: brandForm.tagline.trim(),
                  description: brandForm.description.trim(),
                  logoEmoji: brandForm.logoEmoji || '🎻',
                  logoUrl: brandForm.logoUrl,
                });
                audit('Branding atualizado', brandForm.appName);
                pushToast({ title: 'Branding salvo', body: 'Aplicado em tempo real no app.', tone: 'success' });
              }}
              className={cx(btnPink, 'w-full')}
            >
              <Palette size={13} /> Salvar branding
            </button>
            {brandForm.logoUrl && (
              <button
                type="button"
                onClick={() => setBrandForm((s) => ({ ...s, logoUrl: null }))}
                className="w-full text-[10.5px] text-faint hover:text-[#fca5a5]"
              >
                Remover logo enviada
              </button>
            )}
          </div>

          <aside className="liquid-card p-3">
            <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-faint">Prévia</p>
            <div className="rounded-xl border border-white/[0.08] bg-ink-850 p-2.5">
              <div className="flex items-center gap-1.5">
                {brandForm.logoUrl ? (
                  <img src={brandForm.logoUrl} alt="" className="h-6 w-6 rounded-md object-cover" />
                ) : (
                  <span className="grid h-6 w-6 place-items-center rounded-md bg-gradient-to-br from-hot-500 to-hot-700 text-[11px]">
                    {brandForm.logoEmoji}
                  </span>
                )}
                <span className="text-[11px] font-bold tracking-[0.14em] text-chalk">{brandForm.appName}</span>
              </div>
              <p className="mt-2 text-[13px] font-semibold leading-tight text-chalk">{brandForm.tagline}</p>
              <p className="mt-1 text-[10px] leading-relaxed text-mute">{brandForm.description}</p>
            </div>
            <p className="mt-2 text-[9.5px] leading-relaxed text-faint">
              O branding é gravado em <span className="font-mono">settings/branding</span> e lido por todos os clientes em tempo real.
            </p>
          </aside>
        </div>
      )}

      {/* ── USUÁRIOS ─────────────────────────────────────────────────── */}
      {tab === 'usuarios' && (
        <div>
          <div className="relative mb-3">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-faint" />
            <input
              value={userQuery}
              onChange={(e) => setUserQuery(e.target.value)}
              placeholder="Buscar por nome ou e-mail"
              className={cx(inputCls, 'pl-9')}
            />
          </div>
          <div className="space-y-2">
            {users.map((u) => (
              <UserRow
                key={u.uid}
                user={u}
                onKards={(delta) => {
                  adjustKards(u.uid, delta, delta > 0 ? 'Ajuste manual (admin)' : 'Débito manual (admin)');
                  audit(delta > 0 ? 'Kards creditados' : 'Kards debitados', `${u.displayName} (${delta})`);
                }}
                onSubscription={(plan) => {
                  setSubscription(u.uid, plan, 'granted');
                  audit(`Assinatura ${plan} atribuída manualmente`, u.displayName);
                }}
                onToggleBan={() => {
                  banUser(u.uid, !u.banned);
                  audit(u.banned ? 'Banimento revogado' : 'Usuário banido', u.displayName);
                }}
                onProfile={() => onOpenProfile(u.uid)}
              />
            ))}
          </div>
        </div>
      )}

      {/* ── DESTAQUES ────────────────────────────────────────────────── */}
      {tab === 'destaques' && (
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="liquid-card p-3.5">
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-faint">Livros em destaque</p>
            <div className="space-y-1.5">
              {db.books.map((b) => {
                const on = db.branding.featuredBookIds.includes(b.id);
                return (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => {
                      const next = on
                        ? db.branding.featuredBookIds.filter((id) => id !== b.id)
                        : [...db.branding.featuredBookIds, b.id];
                      updateBranding({ featuredBookIds: next });
                      audit(on ? 'Destaque removido' : 'Destaque adicionado', b.title);
                    }}
                    className={cx(
                      'flex w-full items-center gap-2 rounded-lg border p-1.5 text-left transition-colors',
                      on ? 'border-hot-500/40 bg-hot-500/[0.07]' : 'border-white/[0.07] hover:border-white/20',
                    )}
                  >
                    <img src={b.cover} alt="" className="h-10 w-7 shrink-0 rounded object-cover" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[11.5px] text-chalk">{b.title}</span>
                      <span className="block truncate text-[9.5px] text-faint">{b.authorName}</span>
                    </span>
                    {on && <Check size={12} className="shrink-0 text-hot-400" />}
                  </button>
                );
              })}
            </div>
          </div>
          <div className="liquid-card p-3.5">
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-faint">Comunidades em destaque</p>
            <div className="space-y-1.5">
              {db.communities.map((c) => {
                const on = db.branding.featuredCommunityIds.includes(c.id);
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => {
                      const next = on
                        ? db.branding.featuredCommunityIds.filter((id) => id !== c.id)
                        : [...db.branding.featuredCommunityIds, c.id];
                      updateBranding({ featuredCommunityIds: next });
                      updateCommunity(c.id, { featured: !on });
                      audit(on ? 'Comunidade removida do destaque' : 'Comunidade em destaque', c.name);
                    }}
                    className={cx(
                      'flex w-full items-center gap-2 rounded-lg border p-1.5 text-left transition-colors',
                      on ? 'border-hot-500/40 bg-hot-500/[0.07]' : 'border-white/[0.07] hover:border-white/20',
                    )}
                  >
                    <img src={c.cover} alt="" className="h-8 w-12 shrink-0 rounded object-cover" />
                    <span className="min-w-0 flex-1 truncate text-[11.5px] text-chalk">{c.name}</span>
                    {on && <Check size={12} className="shrink-0 text-hot-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── PIX ──────────────────────────────────────────────────────── */}
      {tab === 'pix' && (
        <div className="space-y-2">
          {db.pixOrders.length === 0 ? (
            <EmptyState icon={<Wallet size={26} />} title="Nenhum pedido Pix" body="Comprovantes enviados pelos leitores aparecem aqui para aprovação manual." />
          ) : (
            db.pixOrders.map((o) => (
              <div key={o.id} className="liquid-card p-3">
                <div className="flex items-center gap-2.5">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-hot-500/12 text-hot-400">
                    <Wallet size={14} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12px] font-semibold text-chalk">{o.userName}</p>
                    <p className="truncate font-mono text-[9.5px] text-faint">{o.e2eid}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-[11.5px] font-semibold text-chalk">{brl(o.amount)}</p>
                    <p className="text-[9.5px] text-faint">{o.plan === 'writer' ? 'Escritor' : 'Leitor'}</p>
                  </div>
                </div>
                <div className="mt-2 flex items-center gap-1.5">
                  <Badge tone={o.status === 'approved' ? 'ok' : o.status === 'rejected' ? 'bad' : 'warn'}>
                    {o.status === 'approved' ? 'aprovado' : o.status === 'rejected' ? 'recusado' : 'pendente'}
                  </Badge>
                  <span className="text-[9.5px] text-faint">{timeAgo(o.createdAt)} atrás</span>
                  {o.status === 'pending' && (
                    <div className="ml-auto flex gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          approvePixOrder(o.id);
                          audit('Pedido Pix aprovado', o.userName);
                        }}
                        className="inline-flex items-center gap-1 rounded-lg bg-[#4ade80]/15 px-2.5 py-1 text-[10.5px] font-semibold text-[#86efac] hover:bg-[#4ade80]/25"
                      >
                        <Check size={10} /> Aprovar
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          rejectPixOrder(o.id);
                          audit('Pedido Pix recusado', o.userName);
                        }}
                        className="inline-flex items-center gap-1 rounded-lg bg-[#f87171]/12 px-2.5 py-1 text-[10.5px] font-semibold text-[#fca5a5] hover:bg-[#f87171]/20"
                      >
                        <X size={10} /> Rejeitar
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* ── DENÚNCIAS ────────────────────────────────────────────────── */}
      {tab === 'denuncias' && (
        <div className="space-y-2">
          {db.reports.length === 0 ? (
            <EmptyState icon={<Flag size={26} />} title="Nenhuma denúncia" body="Denúncias de livros, capítulos, comentários, posts, comunidades e usuários chegam aqui." />
          ) : (
            db.reports.map((r) => (
              <div key={r.id} className="liquid-card p-3">
                <div className="flex items-start gap-2.5">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[#f87171]/12 text-[#fca5a5]">
                    <FileWarning size={14} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12px] font-semibold text-chalk">{r.reason}</p>
                    <p className="truncate text-[10px] text-faint">
                      {r.targetType} · {r.targetLabel}
                    </p>
                    {r.details && <p className="mt-1 text-[10.5px] leading-relaxed text-mute">{r.details}</p>}
                    <p className="mt-1 text-[9.5px] text-faint">
                      por {r.reporterName} · {timeAgo(r.createdAt)} atrás
                    </p>
                  </div>
                  <Badge tone={r.status === 'open' ? 'warn' : r.status === 'resolved' ? 'ok' : 'neutral'} className="shrink-0">
                    {r.status === 'open' ? 'aberta' : r.status === 'resolved' ? 'resolvida' : 'arquivada'}
                  </Badge>
                </div>
                {r.status === 'open' && (
                  <div className="mt-2 flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        resolveReport(r.id, 'resolved');
                        audit('Denúncia resolvida', r.targetLabel);
                      }}
                      className="flex-1 rounded-lg bg-[#4ade80]/15 py-1.5 text-[10.5px] font-semibold text-[#86efac] hover:bg-[#4ade80]/25"
                    >
                      Resolver
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        resolveReport(r.id, 'dismissed');
                        audit('Denúncia arquivada', r.targetLabel);
                      }}
                      className="flex-1 rounded-lg border border-white/10 py-1.5 text-[10.5px] text-mute hover:text-chalk"
                    >
                      Arquivar
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {/* ── CONTEÚDO ─────────────────────────────────────────────────── */}
      {tab === 'conteudo' && (
        <div className="space-y-2">
          {db.books.map((b) => (
            <div key={b.id} className="liquid-card flex items-center gap-2.5 p-2.5">
              <img src={b.cover || coverArt(b.title, b.authorName)} alt="" className="h-12 w-8 shrink-0 rounded object-cover" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[11.5px] font-semibold text-chalk">{b.title}</p>
                <p className="truncate text-[9.5px] text-faint">
                  {b.authorName} · {b.chapters.length} caps · {compact(b.views)} views · {formatDate(b.createdAt)}
                </p>
              </div>
              <Badge tone={b.status === 'published' ? 'ok' : b.status === 'completed' ? 'info' : 'warn'} className="shrink-0">
                {b.status}
              </Badge>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm(`Excluir “${b.title}” permanentemente?`)) {
                    deleteBook(b.id);
                    audit('Obra excluída (admin)', b.title);
                  }
                }}
                className="shrink-0 rounded p-1.5 text-faint hover:text-[#fca5a5]"
                aria-label="Excluir obra"
              >
                <Trash2 size={12} />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* ── LOGS ─────────────────────────────────────────────────────── */}
      {tab === 'logs' && (
        <div className="liquid-card overflow-hidden">
          {db.auditLogs.length === 0 ? (
            <p className="px-4 py-8 text-center text-[11.5px] text-faint">Nenhum log registrado.</p>
          ) : (
            <ul className="divide-y divide-white/[0.05]">
              {db.auditLogs.map((l) => (
                <li key={l.id} className="flex items-start gap-2.5 px-3 py-2.5">
                  <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-md bg-white/[0.06] text-[9px]">
                    <ScrollText size={10} className="text-mute" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[11.5px] text-chalk">
                      <span className="font-semibold">{l.actorName}</span> · {l.action}
                    </p>
                    <p className="truncate text-[9.5px] text-faint">
                      {l.target} · {formatDate(l.createdAt)}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

function UserRow({
  user,
  onKards,
  onSubscription,
  onToggleBan,
  onProfile,
}: {
  user: AppUser;
  onKards: (delta: number) => void;
  onSubscription: (plan: 'free' | 'reader' | 'writer') => void;
  onToggleBan: () => void;
  onProfile: () => void;
}) {
  const [delta, setDelta] = useState(50);
  const sub = user.subscription;

  return (
    <div className={cx('liquid-card p-3', user.banned && 'border-[#f87171]/30')}>
      <div className="flex items-center gap-2.5">
        <button type="button" onClick={onProfile}>
          <Avatar src={user.photoURL} name={user.displayName} size={32} />
        </button>
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1.5 truncate text-[12px] font-semibold text-chalk">
            {user.displayName}
            {user.role === 'desenvolvedor' && <Crown size={10} className="shrink-0 text-hot-400" />}
            {user.banned && <Ban size={10} className="shrink-0 text-[#fca5a5]" />}
          </p>
          <p className="truncate text-[9.5px] text-faint">
            {user.email} · {user.role} · {compact(user.xp)} XP · {user.kards} Kards
          </p>
        </div>
        <Badge
          tone={sub.status === 'active' ? (sub.plan === 'writer' ? 'hot' : 'info') : 'neutral'}
          className="shrink-0 !text-[9px]"
        >
          {sub.status === 'active' ? sub.plan : 'free'}
        </Badge>
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-1.5">
        <div className="flex items-center gap-1 rounded-lg border border-white/10 px-1">
          <input
            type="number"
            value={delta}
            onChange={(e) => setDelta(Number(e.target.value))}
            className="w-14 bg-transparent py-1 text-[10.5px] text-chalk focus:outline-none"
          />
          <button
            type="button"
            onClick={() => onKards(delta)}
            className="rounded bg-[#4ade80]/15 px-1.5 py-0.5 text-[9.5px] font-semibold text-[#86efac]"
          >
            +
          </button>
          <button
            type="button"
            onClick={() => onKards(-Math.abs(delta))}
            className="rounded bg-[#f87171]/12 px-1.5 py-0.5 text-[9.5px] font-semibold text-[#fca5a5]"
          >
            −
          </button>
        </div>
        <select
          value={sub.plan}
          onChange={(e) => onSubscription(e.target.value as 'free' | 'reader' | 'writer')}
          className="rounded-lg border border-white/10 bg-ink-800 px-1.5 py-1 text-[10px] text-mute"
        >
          <option value="free" className="bg-ink-800">Sem assinatura</option>
          <option value="reader" className="bg-ink-800">Leitor</option>
          <option value="writer" className="bg-ink-800">Escritor</option>
        </select>
        <button
          type="button"
          onClick={onToggleBan}
          className={cx(
            'rounded-lg px-2 py-1 text-[10px] font-semibold',
            user.banned
              ? 'bg-[#4ade80]/15 text-[#86efac]'
              : 'bg-[#f87171]/12 text-[#fca5a5]',
          )}
        >
          {user.banned ? 'Revogar ban' : 'Banir'}
        </button>
        <span className="ml-auto text-[9px] text-faint">
          {user.achievements.length} conquistas · {user.badges.length} badges
        </span>
      </div>
    </div>
  );
}
