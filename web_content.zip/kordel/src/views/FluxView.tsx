import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Bookmark,
  ChevronDown,
  ChevronUp,
  Flag,
  Heart,
  Link2,
  MessageCircle,
  Music2,
  Plus,
  Send,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useStore } from '../contexts/StoreContext';
import { Avatar, Badge, btnPink, inputCls } from '../components/ui';
import { ReportModal } from '../components/Modals';
import { coverArt, storyArt } from '../lib/art';
import { compact, cx, timeAgo } from '../lib/utils';
import type { Post } from '../types';

export default function FluxView() {
  const { db, currentUser, toggleLikePost, toggleSavePost, votePoll, addPostComment, deletePost, pushToast } = useStore();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const [index, setIndex] = useState(0);
  const [commentsFor, setCommentsFor] = useState<Post | null>(null);
  const [report, setReport] = useState<Post | null>(null);
  const [muted, setMuted] = useState(true);
  const trackRef = useRef<HTMLDivElement>(null);

  const posts = useMemo(
    () => [...db.fluxPosts].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)),
    [db.fluxPosts],
  );

  // Deep link ?flux=<id>
  useEffect(() => {
    const id = params.get('flux');
    if (!id) return;
    const i = posts.findIndex((p) => p.id === id);
    if (i >= 0) {
      setIndex(i);
      requestAnimationFrame(() => {
        trackRef.current?.scrollTo({ top: i * window.innerHeight, behavior: 'instant' as ScrollBehavior });
      });
    }
  }, [params, posts]);

  // Atualiza a URL conforme rola
  useEffect(() => {
    const id = posts[index]?.id;
    if (!id) return;
    const next = new URLSearchParams(params);
    next.set('flux', id);
    setParams(next, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index]);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  const goTo = (i: number) => {
    if (i < 0 || i >= posts.length) return;
    setIndex(i);
    trackRef.current?.scrollTo({ top: i * window.innerHeight, behavior: 'smooth' });
  };

  if (posts.length === 0) {
    return (
      <div className="grid min-h-dvh place-items-center bg-[#161616] px-6 text-center">
        <div>
          <p className="text-[13px] text-mute">Nenhum Flux publicado ainda.</p>
          <button type="button" onClick={() => navigate('/social/flux/criar')} className={cx(btnPink, 'mt-3')}>
            Criar o primeiro
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative bg-[#121212]">
      <div className="pointer-events-none fixed inset-x-0 top-0 z-50 flex items-center justify-between px-3 pt-3">
        <button
          type="button"
          onClick={() => navigate('/social')}
          className="pointer-events-auto inline-flex items-center gap-1 rounded-full border border-white/15 bg-black/45 px-2.5 py-1.5 text-[11px] font-semibold text-chalk backdrop-blur"
        >
          <X size={12} /> Sair
        </button>
        <div className="pointer-events-auto flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setMuted((m) => !m)}
            className="rounded-full border border-white/15 bg-black/45 p-1.5 text-chalk backdrop-blur"
            aria-label="Som"
          >
            {muted ? <VolumeX size={13} /> : <Volume2 size={13} />}
          </button>
          <button
            type="button"
            onClick={() => navigate('/social/flux/criar')}
            className="inline-flex items-center gap-1 rounded-full bg-hot-500 px-3 py-1.5 text-[11px] font-bold text-[#1a1a1a] pink-glow-soft"
          >
            <Plus size={12} /> CRIAR FLUX
          </button>
        </div>
      </div>

      {/* Setas desktop */}
      <div className="fixed right-3 top-1/2 z-50 hidden -translate-y-1/2 flex-col gap-1.5 sm:flex">
        <button
          type="button"
          onClick={() => goTo(index - 1)}
          className="rounded-full border border-white/15 bg-black/40 p-2 text-chalk backdrop-blur disabled:opacity-30"
          disabled={index === 0}
          aria-label="Anterior"
        >
          <ChevronUp size={16} />
        </button>
        <button
          type="button"
          onClick={() => goTo(index + 1)}
          className="rounded-full border border-white/15 bg-black/40 p-2 text-chalk backdrop-blur disabled:opacity-30"
          disabled={index === posts.length - 1}
          aria-label="Próximo"
        >
          <ChevronDown size={16} />
        </button>
      </div>

      <div
        ref={trackRef}
        className="no-scrollbar h-[100dvh] overflow-y-scroll snap-y snap-mandatory"
        onScroll={(e) => {
          const el = e.currentTarget;
          const i = Math.round(el.scrollTop / window.innerHeight);
          if (i !== index) setIndex(i);
        }}
      >
        {posts.map((post, i) => (
          <FluxSlide
            key={post.id}
            post={post}
            active={i === index}
            muted={muted}
            myId={currentUser?.uid ?? null}
            onLike={() => toggleLikePost(post.id, true)}
            onSave={() => toggleSavePost(post.id)}
            onVote={(opt) => votePoll(post.id, opt, true)}
            onComments={() => setCommentsFor(post)}
            onShare={() => {
              const url = `${window.location.origin}/social/flux?flux=${post.id}`;
              navigator.clipboard?.writeText(url).then(
                () => pushToast({ title: 'Link copiado', body: url, tone: 'success' }),
                () => pushToast({ title: 'Link direto', body: url, tone: 'info' }),
              );
            }}
            onDelete={() => deletePost(post.id, true)}
            onReport={() => setReport(post)}
            onProfile={(uid) => navigate(`/perfil/${uid}`)}
            onOpenBook={() => {
              const book = db.books.find((b) => b.title === post.text.slice(0, 40) || post.text.includes(b.title));
              if (book) navigate(`/obra/${book.id}`);
            }}
          />
        ))}
      </div>

      {/* Modal de comentários */}
      <AnimatePresence>
        {commentsFor && (
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 36 }}
            className="fixed inset-x-0 bottom-0 z-[88] max-h-[74dvh] rounded-t-2xl border-t border-white/10 bg-ink-800"
          >
            <div className="flex items-center justify-between border-b border-white/[0.07] px-4 py-3">
              <p className="text-[12.5px] font-semibold text-chalk">
                Comentários <span className="text-faint">({commentsFor.comments.length})</span>
              </p>
              <button type="button" onClick={() => setCommentsFor(null)} className="p-1 text-faint hover:text-chalk" aria-label="Fechar">
                <X size={16} />
              </button>
            </div>
            <div className="max-h-[52dvh] overflow-y-auto px-3 py-2">
              {commentsFor.comments.length === 0 && (
                <p className="py-8 text-center text-[11.5px] text-faint">Nenhum comentário. Seja o primeiro.</p>
              )}
              {commentsFor.comments.map((c) => (
                <div key={c.id} className="mb-2 flex items-start gap-2">
                  <Avatar src={c.userPhoto} name={c.userName} size={24} />
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] font-semibold text-chalk">
                      {c.userName} <span className="font-normal text-faint">· {timeAgo(c.createdAt)}</span>
                    </p>
                    <p className="text-[11.5px] leading-relaxed text-mute">{c.content}</p>
                  </div>
                </div>
              ))}
            </div>
            <FluxCommentInput
              disabled={!currentUser}
              onSubmit={(text) => {
                addPostComment(commentsFor.id, text, null, true);
                setCommentsFor((prev) => (prev ? { ...prev, comments: prev.comments } : prev));
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <ReportModal
        open={Boolean(report)}
        onClose={() => setReport(null)}
        targetType="post"
        targetId={report?.id ?? ''}
        targetLabel={`Flux de ${report?.authorName ?? ''}`}
      />
    </div>
  );
}

function FluxCommentInput({ onSubmit, disabled }: { onSubmit: (text: string) => void; disabled?: boolean }) {
  const [text, setText] = useState('');
  return (
    <div className="flex gap-1.5 border-t border-white/[0.07] px-3 py-2.5">
      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        disabled={disabled}
        placeholder={disabled ? 'Entre para comentar' : 'Escreva um comentário…'}
        className={cx(inputCls, '!py-2 !text-[12px]')}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && text.trim()) {
            onSubmit(text.trim());
            setText('');
          }
        }}
      />
      <button
        type="button"
        disabled={!text.trim() || disabled}
        onClick={() => {
          onSubmit(text.trim());
          setText('');
        }}
        className="shrink-0 rounded-xl bg-hot-500 px-3 text-[#1a1a1a] disabled:opacity-40"
        aria-label="Enviar"
      >
        <Send size={14} />
      </button>
    </div>
  );
}

function FluxSlide({
  post,
  active,
  muted,
  myId,
  onLike,
  onSave,
  onVote,
  onComments,
  onShare,
  onDelete,
  onReport,
  onProfile,
  onOpenBook,
}: {
  post: Post;
  active: boolean;
  muted: boolean;
  myId: string | null;
  onLike: () => void;
  onSave: () => void;
  onVote: (opt: string) => void;
  onComments: () => void;
  onShare: () => void;
  onDelete: () => void;
  onReport: () => void;
  onProfile: (uid: string) => void;
  onOpenBook: () => void;
}) {
  const [mediaIndex, setMediaIndex] = useState(0);
  const liked = myId ? post.likes.includes(myId) : false;
  const saved = myId ? post.savedBy.includes(myId) : false;
  const totalVotes = post.poll?.options.reduce((a, o) => a + o.votes.length, 0) ?? 0;
  const myVote = myId ? post.poll?.options.find((o) => o.votes.includes(myId))?.id : undefined;

  const background =
    post.media[0] ??
    (post.type === 'story'
      ? storyArt(post.text || 'KORDEL', post.authorName)
      : post.type === 'poll'
        ? coverArt(post.poll?.question ?? 'Enquete', post.authorName, post.id)
        : storyArt(post.text || 'KORDEL', post.authorName));

  return (
    <section className="relative h-[100dvh] w-full snap-start snap-always overflow-hidden">
      <motion.img
        key={background}
        src={background}
        alt=""
        initial={{ scale: 1.06, opacity: 0.6 }}
        animate={{ scale: active ? 1 : 1.04, opacity: 1 }}
        transition={{ duration: 1.1, ease: 'easeOut' }}
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/92 via-black/35 to-black/45" />

      {post.type === 'story' && post.media.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center px-10">
          <p className="font-literata text-center text-[24px] font-semibold leading-snug text-chalk drop-shadow-[0_4px_24px_rgba(0,0,0,0.9)]">
            {post.text}
          </p>
        </div>
      )}

      {post.type === 'carousel' && post.media.length > 1 && (
        <div className="absolute inset-x-0 top-1/2 flex -translate-y-1/2 justify-between px-2">
          <button
            type="button"
            onClick={() => setMediaIndex((i) => Math.max(0, i - 1))}
            className="rounded-full bg-black/45 p-1.5 text-chalk backdrop-blur"
            aria-label="Anterior"
          >
            <ChevronUp size={14} className="-rotate-90" />
          </button>
          <button
            type="button"
            onClick={() => setMediaIndex((i) => Math.min(post.media.length - 1, i + 1))}
            className="rounded-full bg-black/45 p-1.5 text-chalk backdrop-blur"
            aria-label="Próxima"
          >
            <ChevronDown size={14} className="-rotate-90" />
          </button>
        </div>
      )}

      {post.audioUrl && active && (
        <audio src={post.audioUrl} autoPlay={active} muted={muted} loop className="hidden" />
      )}

      {/* Rodapé do post */}
      <div className="absolute inset-x-0 bottom-[86px] px-4">
        <div className="flex items-center gap-2">
          <button type="button" onClick={() => onProfile(post.authorId)} className="flex items-center gap-2">
            <Avatar src={post.authorPhoto} name={post.authorName} size={34} ring />
            <span>
              <span className="block text-[12.5px] font-bold text-chalk drop-shadow">{post.authorName}</span>
              <span className="block text-[9.5px] text-mute">{timeAgo(post.createdAt)} atrás</span>
            </span>
          </button>
          <Badge tone="neutral" className="ml-1 !text-[9px] backdrop-blur">
            {post.type === 'story' ? 'story' : post.type}
          </Badge>
          {post.audioUrl && (
            <span className="inline-flex items-center gap-1 text-[9.5px] text-[#93c5fd]">
              <Music2 size={9} /> áudio
            </span>
          )}
        </div>

        {post.text && post.type !== 'story' && (
          <p className="mt-2 clamp-4 max-w-[86%] whitespace-pre-wrap text-[12.5px] leading-relaxed text-chalk/92 drop-shadow">
            {post.text}
          </p>
        )}

        {post.poll && (
          <div className="mt-2 max-w-[86%] space-y-1.5 rounded-xl border border-white/15 bg-black/45 p-2 backdrop-blur">
            <p className="text-[11px] font-semibold text-chalk">{post.poll.question}</p>
            {post.poll.options.map((o) => {
              const p = totalVotes ? Math.round((o.votes.length / totalVotes) * 100) : 0;
              const mine = myVote === o.id;
              return (
                <button
                  key={o.id}
                  type="button"
                  onClick={() => onVote(o.id)}
                  className={cx(
                    'relative w-full overflow-hidden rounded-lg border px-2 py-1.5 text-left',
                    mine ? 'border-hot-500/70 bg-hot-500/20' : 'border-white/20 bg-white/[0.06]',
                  )}
                >
                  <span className="absolute inset-y-0 left-0 bg-hot-500/25" style={{ width: `${p}%` }} />
                  <span className="relative flex justify-between gap-2">
                    <span className="text-[10.5px] text-chalk">{o.text}</span>
                    <span className="text-[9.5px] tabular-nums text-mute">{p}%</span>
                  </span>
                </button>
              );
            })}
            <p className="text-[9px] text-mute">{totalVotes} votos</p>
          </div>
        )}

        {post.type !== 'story' && !post.poll && (
          <button
            type="button"
            onClick={onOpenBook}
            className="mt-2 inline-flex items-center gap-1 rounded-full border border-white/20 bg-black/40 px-2.5 py-1 text-[10px] text-chalk backdrop-blur"
          >
            <Link2 size={9} /> ver obra relacionada
          </button>
        )}
      </div>

      {/* Ações laterais */}
      <div className="absolute bottom-[92px] right-3 flex flex-col items-center gap-3.5">
        <FluxAction
          icon={<Heart size={20} className={liked ? 'fill-hot-500 text-hot-500' : 'text-chalk'} />}
          label={compact(post.likes.length)}
          onClick={onLike}
        />
        <FluxAction
          icon={<MessageCircle size={20} className="text-chalk" />}
          label={String(post.comments.length)}
          onClick={onComments}
        />
        <FluxAction
          icon={<Bookmark size={19} className={saved ? 'fill-hot-400 text-hot-400' : 'text-chalk'} />}
          label={saved ? 'salvo' : 'salvar'}
          onClick={onSave}
        />
        <FluxAction icon={<Link2 size={19} className="text-chalk" />} label="link" onClick={onShare} />
        {myId === post.authorId ? (
          <FluxAction icon={<Trash2 size={18} className="text-[#fca5a5]" />} label="excluir" onClick={onDelete} />
        ) : (
          <FluxAction icon={<Flag size={18} className="text-chalk/80" />} label="denunciar" onClick={onReport} />
        )}
      </div>

      {/* Swipe hint */}
      {active && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 0.7, 0] }}
          transition={{ duration: 2.4, repeat: 1 }}
          className="pointer-events-none absolute inset-x-0 top-[86px] text-center text-[10px] uppercase tracking-[0.2em] text-chalk/60"
        >
          deslize
        </motion.p>
      )}
    </section>
  );
}

function FluxAction({ icon, label, onClick }: { icon: ReactNode; label: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex flex-col items-center gap-0.5 transition-transform active:scale-90">
      <span className="grid h-10 w-10 place-items-center rounded-full border border-white/15 bg-black/40 backdrop-blur">{icon}</span>
      <span className="text-[9px] font-medium text-chalk/85">{label}</span>
    </button>
  );
}
