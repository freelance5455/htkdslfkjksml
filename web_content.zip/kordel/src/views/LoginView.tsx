import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowRight, BookOpen, Crown, Loader2, Mail, ShieldCheck, Sparkles } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useStore } from '../contexts/StoreContext';
import { btnGhost, btnPink, inputCls } from '../components/ui';
import { cx } from '../lib/utils';

export default function LoginView() {
  const { mode, pending, error, signInGoogle, signInEmail, signUpEmail, signInDemo, clearError } = useAuth();
  const { db, currentUser } = useStore();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [tab, setTab] = useState<'entrar' | 'criar'>('entrar');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    if (currentUser) navigate(params.get('next') || '/', { replace: true });
  }, [currentUser, navigate, params]);

  return (
    <div className="mx-auto grid max-w-5xl gap-8 px-4 py-10 sm:py-16 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
      <div className="order-2 lg:order-1">
        <div className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-hot-500 to-hot-700 text-[16px] pink-glow-soft">
            {db.branding.logoEmoji}
          </span>
          <span className="text-[15px] font-bold tracking-[0.16em] text-chalk">{db.branding.appName}</span>
        </div>

        <h1 className="mt-5 text-[26px] font-bold leading-[1.15] tracking-tight text-chalk sm:text-[32px]">
          Leia o que ainda
          <br />
          <span className="text-hot-500">não virou livro.</span>
        </h1>
        <p className="mt-3 max-w-md text-[13px] leading-relaxed text-mute">{db.branding.description}</p>

        <div className="mt-6 space-y-2">
          {[
            { icon: BookOpen, text: 'Cordel, romance, fantasia e ficção científica em primeira mão.' },
            { icon: Sparkles, text: 'XP, níveis até 33, títulos equipáveis e ranking semanal.' },
            { icon: Crown, text: 'Apoie autores independentes com assinaturas a partir de R$ 4,90.' },
          ].map((f) => (
            <div key={f.text} className="flex items-start gap-2.5">
              <f.icon size={15} className="mt-0.5 shrink-0 text-hot-400" />
              <p className="text-[12px] leading-relaxed text-mute">{f.text}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="order-1 lg:order-2">
        <div className="liquid-card p-5 sm:p-6">
          <div className="mb-4 flex gap-1 rounded-full border border-white/[0.08] bg-ink-900/70 p-1">
            {(['entrar', 'criar'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => {
                  setTab(t);
                  clearError();
                }}
                className={cx(
                  'flex-1 rounded-full py-1.5 text-[12px] font-semibold transition-all',
                  tab === t ? 'bg-hot-500 text-[#1a1a1a]' : 'text-mute hover:text-chalk',
                )}
              >
                {t === 'entrar' ? 'Entrar' : 'Criar conta'}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => void signInGoogle()}
            disabled={pending}
            className={cx(btnGhost, 'w-full !bg-white !text-[#1a1a1a] hover:!bg-[#f2f0ef]')}
          >
            {pending ? <Loader2 size={15} className="animate-spin" /> : <GoogleGlyph />}
            Continuar com Google
          </button>

          <div className="my-4 flex items-center gap-2.5">
            <span className="h-px flex-1 bg-white/[0.08]" />
            <span className="text-[10px] uppercase tracking-widest text-faint">ou</span>
            <span className="h-px flex-1 bg-white/[0.08]" />
          </div>

          <form
            className="space-y-2.5"
            onSubmit={(e) => {
              e.preventDefault();
              if (tab === 'entrar') void signInEmail(email, password);
              else void signUpEmail(name, email, password);
            }}
          >
            {tab === 'criar' && (
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Seu nome de leitor"
                required
                className={inputCls}
              />
            )}
            <div className="relative">
              <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-faint" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="E-mail"
                required
                className={cx(inputCls, 'pl-9')}
              />
            </div>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={tab === 'criar' ? 'Senha (mín. 6 caracteres)' : 'Senha'}
              required
              minLength={6}
              className={inputCls}
            />
            <button type="submit" disabled={pending} className={cx(btnPink, 'w-full')}>
              {pending && <Loader2 size={14} className="animate-spin" />}
              {tab === 'entrar' ? 'Entrar com e-mail' : 'Criar minha conta'}
              <ArrowRight size={14} />
            </button>
          </form>

          {error && (
            <p className="mt-3 rounded-lg border border-[#f87171]/30 bg-[#f87171]/10 px-3 py-2 text-[11.5px] text-[#fca5a5]">
              {error}
            </p>
          )}

          <div className="mt-5 rounded-xl border border-hot-500/20 bg-hot-500/[0.06] p-3">
            <p className="flex items-center gap-1.5 text-[11px] font-semibold text-hot-300">
              <ShieldCheck size={12} /> Acesso de demonstração
            </p>
            <p className="mt-1 text-[10.5px] leading-relaxed text-mute">
              {mode === 'demo'
                ? 'Firebase não configurado (.env). Use um perfil de demonstração para explorar todos os módulos com dados reais persistidos localmente.'
                : 'Sessão Firebase ativa. Para testar papéis administrativos rapidamente, entre com um perfil de demonstração.'}
            </p>
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              {[
                { email: 'dev@kordel.app', label: 'Desenvolvedor' },
                { email: 'marina@kordel.app', label: 'Escritora' },
                { email: 'joao@kordel.app', label: 'Escritor' },
                { email: 'rafa@kordel.app', label: 'Leitor' },
              ].map((p) => (
                <button
                  key={p.email}
                  type="button"
                  disabled={pending}
                  onClick={() => void signInDemo(p.email)}
                  className="rounded-lg border border-white/10 bg-ink-900/70 px-2 py-1.5 text-[10.5px] font-medium text-mute transition-colors hover:border-hot-500/40 hover:text-chalk"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <p className="mt-4 text-center text-[10px] leading-relaxed text-faint">
            Ao entrar, você aceita as diretrizes de convivência da KORDEL. Conteúdo protegido por direitos autorais é de responsabilidade do autor.
          </p>
        </div>
      </div>
    </div>
  );
}

function GoogleGlyph() {
  return (
    <svg width="15" height="15" viewBox="0 0 48 48" aria-hidden>
      <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.6 2.4 30.2 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.2 17.7 9.5 24 9.5z" />
      <path fill="#4285F4" d="M46.1 24.6c0-1.6-.1-2.8-.4-4.1H24v8.1h12.5c-.3 2.1-1.6 5.2-4.6 7.3l7.7 6c4.5-4.2 6.5-10.2 6.5-17.3z" />
      <path fill="#FBBC05" d="M10.5 28.7A14.4 14.4 0 0 1 9.7 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z" />
      <path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.6-5.8l-7.7-6c-2.1 1.4-4.8 2.4-7.9 2.4-6.3 0-11.6-3.7-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z" />
    </svg>
  );
}
