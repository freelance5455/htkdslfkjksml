import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Check,
  Copy,
  CreditCard,
  Crown,
  Loader2,
  QrCode,
  Receipt,
  ShieldCheck,
  Sparkles,
  Wallet,
} from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Badge, Modal, Progress, btnGhost, btnPink, inputCls } from '../components/ui';
import { PLANS } from '../lib/xp';
import { brl, cx, formatDate } from '../lib/utils';
import { createPixCharge, createStripeCheckout, pixQrDataUrl, verifyStripePayment } from '../lib/api';

type CheckoutMode = 'pix' | 'card';

export default function SubscriptionsView() {
  const { db, currentUser, createPixOrder, setSubscription, pushToast } = useStore();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const [plan, setPlan] = useState<'reader' | 'writer' | null>(null);
  const [mode, setMode] = useState<CheckoutMode>('pix');
  const [pix, setPix] = useState<{ payload: string; qr: string; amount: number; txid: string } | null>(null);
  const [e2eid, setE2eid] = useState('');
  const [busy, setBusy] = useState(false);
  const [stripeMsg, setStripeMsg] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const myTx = currentUser ? db.transactions.filter((t) => t.userId === currentUser.uid) : [];
  const myOrders = currentUser ? db.pixOrders.filter((o) => o.userId === currentUser.uid) : [];

  // Retorno do Stripe: ?stripe_success=true&session_id=...
  useEffect(() => {
    const success = params.get('stripe_success');
    const sessionId = params.get('session_id');
    if (success !== 'true' || !sessionId) return;
    (async () => {
      setStripeMsg('Validando pagamento no Stripe…');
      const res = await verifyStripePayment(sessionId);
      if (res.ok && currentUser) {
        setSubscription(currentUser.uid, (res.plan as 'reader' | 'writer') ?? 'reader', 'card');
        setStripeMsg('Pagamento confirmado. Assinatura ativada!');
        pushToast({ title: 'Assinatura ativada', body: 'Pagamento confirmado via Stripe.', tone: 'success' });
      } else {
        setStripeMsg(res.error ?? 'Não foi possível confirmar o pagamento. Verifique no Stripe.');
      }
      const next = new URLSearchParams(params);
      next.delete('stripe_success');
      next.delete('session_id');
      next.delete('plan');
      setParams(next, { replace: true });
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const openCheckout = async (planId: 'reader' | 'writer', m: CheckoutMode) => {
    if (!currentUser) {
      navigate('/entrar?next=/assinaturas');
      return;
    }
    setPlan(planId);
    setMode(m);
    setPix(null);
    setE2eid('');
    if (m === 'pix') {
      setBusy(true);
      try {
        const charge = await createPixCharge(planId);
        const qr = await pixQrDataUrl(charge.payload);
        setPix({ payload: charge.payload, qr, amount: charge.amount, txid: charge.txid });
      } catch {
        const fallback = `00020126580014BR.GOV.BCB.PIX0136kordel@pix.exemplo.com.br520400005303986540${planId === 'writer' ? '513.49' : '44.90'}5802BR5913KORDEL6009SAO PAULO62070503***6304ABCD`;
        setPix({ payload: fallback, qr: await pixQrDataUrl(fallback), amount: planId === 'writer' ? 13.49 : 4.9, txid: 'KDLFALLBACK' });
      } finally {
        setBusy(false);
      }
    }
  };

  const confirmPix = () => {
    if (!currentUser || !plan) return;
    const value = e2eid.trim().toUpperCase();
    const valid = /^E\d{8}\d{12}[A-Z0-9]{11}$/.test(value);
    if (!valid) {
      pushToast({
        title: 'E2EID inválido',
        body: 'Formato esperado: E + ISPB(8) + data/hora(12) + 11 caracteres. Copie o código do comprovante.',
        tone: 'error',
      });
      return;
    }
    if (db.usedPixReceipts.includes(value) || db.pixOrders.some((o) => o.e2eid === value)) {
      pushToast({ title: 'Comprovante já utilizado', body: 'Cada E2EID só pode ser usado uma vez.', tone: 'error' });
      return;
    }
    createPixOrder(plan, value);
    setPlan(null);
    pushToast({
      title: 'Comprovante enviado',
      body: 'A curadoria valida manualmente no Painel do Desenvolvedor.',
      tone: 'success',
    });
  };

  const startCard = async () => {
    if (!currentUser || !plan) return;
    setBusy(true);
    try {
      const res = await createStripeCheckout({ plan, userId: currentUser.uid, email: currentUser.email });
      if (res.url) {
        window.location.assign(res.url);
        return;
      }
      pushToast({
        title: 'Stripe não configurado',
        body: res.error ?? 'Configure STRIPE_SECRET_KEY no backend ou use o checkout Pix.',
        tone: 'warn',
      });
    } finally {
      setBusy(false);
    }
  };

  const currentPlan = currentUser?.subscription;
  const isActive = currentPlan?.status === 'active';

  return (
    <div className="mx-auto max-w-4xl px-4 pb-10 pt-5 sm:px-6">
      <div className="mb-5">
        <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">Apoio ao autor independente</p>
        <h1 className="mt-1 text-[23px] font-bold tracking-tight text-chalk">Assinaturas & Kards</h1>
        <p className="mt-1 max-w-xl text-[12px] leading-relaxed text-mute">
          Kards é a moeda virtual da KORDEL, usada em desbloqueios e gorjetas. Toda movimentação fica registrada na trilha de auditoria de transações.
        </p>
      </div>

      {stripeMsg && (
        <div className="liquid-card mb-4 flex items-center gap-2 border-hot-500/30 p-3">
          <ShieldCheck size={15} className="shrink-0 text-hot-400" />
          <p className="text-[11.5px] text-mute">{stripeMsg}</p>
        </div>
      )}

      {isActive && (
        <div className="liquid-card mb-4 border-hot-500/30 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-hot-500/15 text-hot-400">
                <Crown size={17} />
              </span>
              <div>
                <p className="text-[12.5px] font-semibold text-chalk">
                  {currentPlan.plan === 'writer' ? 'Assinatura Escritor' : 'Assinatura Leitor'} ativa
                </p>
                <p className="text-[10.5px] text-faint">
                  Renova em {formatDate(currentPlan.renewsAt)} · pagamento via {currentPlan.method ?? 'pix'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                if (!currentUser) return;
                setSubscription(currentUser.uid, 'free', 'granted');
                pushToast({ title: 'Assinatura cancelada', body: 'Benefícios mantidos até o fim do ciclo.', tone: 'warn' });
              }}
              className="rounded-xl border border-white/10 px-3 py-1.5 text-[11px] text-mute hover:text-[#fca5a5]"
            >
              Cancelar renovação
            </button>
          </div>
          {currentPlan.plan === 'writer' && currentUser && (
            <p className="mt-2.5 rounded-lg border border-white/10 bg-ink-900/50 px-2.5 py-1.5 text-[10.5px] text-mute">
              Impulsionamentos disponíveis neste ciclo: <strong className="text-hot-300">{currentUser.boostsAvailable}</strong> de 2
            </p>
          )}
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2">
        {PLANS.map((p) => {
          const active = currentPlan?.plan === p.id && isActive;
          return (
            <div key={p.id} className={cx('liquid-card relative overflow-hidden p-4', p.id === 'writer' && 'border-hot-500/30')}>
              {p.id === 'writer' && (
                <span className="absolute right-0 top-0 rounded-bl-lg bg-hot-500 px-2 py-0.5 text-[9px] font-bold text-[#1a1a1a]">
                  MAIS COMPLETO
                </span>
              )}
              <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-hot-400">{p.tagline}</p>
              <h2 className="mt-1 text-[16px] font-bold text-chalk">{p.name}</h2>
              <p className="mt-1.5 flex items-baseline gap-1">
                <span className="text-[26px] font-bold leading-none text-chalk">{brl(p.price)}</span>
                <span className="text-[11px] text-faint">/mês</span>
              </p>
              <ul className="mt-3 space-y-1.5">
                {p.perks.map((perk) => (
                  <li key={perk} className="flex items-start gap-1.5 text-[11px] leading-snug text-mute">
                    <Check size={11} className="mt-0.5 shrink-0 text-hot-400" />
                    {perk}
                  </li>
                ))}
              </ul>
              {active ? (
                <div className="mt-3.5 flex items-center justify-center gap-1 rounded-xl border border-hot-500/40 bg-hot-500/10 py-2 text-[11.5px] font-semibold text-hot-300">
                  <Check size={12} /> Plano atual
                </div>
              ) : (
                <div className="mt-3.5 flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => void openCheckout(p.id, 'pix')}
                    className={cx(btnPink, 'flex-1 !px-2 !py-2 !text-[11.5px]')}
                  >
                    <QrCode size={12} /> Pix
                  </button>
                  <button
                    type="button"
                    onClick={() => void openCheckout(p.id, 'card')}
                    className={cx(btnGhost, 'flex-1 !px-2 !py-2 !text-[11.5px]')}
                  >
                    <CreditCard size={12} /> Cartão
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Kards */}
      <section className="liquid-card mt-4 p-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-hot-500/12 text-hot-400">
              <Wallet size={16} />
            </span>
            <div>
              <p className="text-[12px] font-semibold text-chalk">Meus Kards</p>
              <p className="text-[10.5px] text-faint">Saldo atual e trilha de auditoria</p>
            </div>
          </div>
          <p className="text-[20px] font-bold tabular-nums text-hot-300">{currentUser?.kards ?? 0}</p>
        </div>

        {myTx.length === 0 ? (
          <p className="mt-3 rounded-lg border border-dashed border-white/10 py-3 text-center text-[10.5px] text-faint">
            Nenhuma transação ainda. Leia capítulos e participe para acumular Kards.
          </p>
        ) : (
          <ul className="mt-3 divide-y divide-white/[0.05]">
            {myTx.slice(0, 8).map((t) => (
              <li key={t.id} className="flex items-center gap-2 py-1.5">
                <span
                  className={cx(
                    'grid h-6 w-6 shrink-0 place-items-center rounded-md text-[9px] font-bold',
                    t.type === 'credit' ? 'bg-[#4ade80]/15 text-[#86efac]' : 'bg-[#f87171]/12 text-[#fca5a5]',
                  )}
                >
                  {t.type === 'credit' ? '+' : '−'}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[11px] text-chalk">{t.description}</p>
                  <p className="text-[9.5px] text-faint">{formatDate(t.createdAt)}</p>
                </div>
                <span className={cx('shrink-0 text-[11px] font-semibold tabular-nums', t.type === 'credit' ? 'text-[#86efac]' : 'text-[#fca5a5]')}>
                  {t.type === 'credit' ? '+' : '−'}{t.amount}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Pedidos Pix */}
      {myOrders.length > 0 && (
        <section className="liquid-card mt-4 p-4">
          <p className="mb-2 inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-faint">
            <Receipt size={11} /> Meus comprovantes Pix
          </p>
          <ul className="space-y-1.5">
            {myOrders.map((o) => (
              <li key={o.id} className="flex items-center gap-2 rounded-lg border border-white/[0.06] bg-ink-900/50 p-2">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[11px] text-chalk">
                    {o.plan === 'writer' ? 'Assinatura Escritor' : 'Assinatura Leitor'} · {brl(o.amount)}
                  </p>
                  <p className="truncate font-mono text-[9px] text-faint">{o.e2eid}</p>
                </div>
                <Badge tone={o.status === 'approved' ? 'ok' : o.status === 'rejected' ? 'bad' : 'warn'} className="shrink-0">
                  {o.status === 'approved' ? 'aprovado' : o.status === 'rejected' ? 'recusado' : 'em análise'}
                </Badge>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Modal de checkout */}
      <Modal
        open={Boolean(plan)}
        onClose={() => setPlan(null)}
        title={plan === 'writer' ? 'Assinatura Escritor' : 'Assinatura Leitor'}
        subtitle={mode === 'pix' ? 'Pagamento via Pix dinâmico' : 'Pagamento com cartão via Stripe'}
      >
        {mode === 'pix' ? (
          <div className="space-y-3">
            {busy || !pix ? (
              <div className="flex items-center justify-center gap-2 py-10 text-[12px] text-mute">
                <Loader2 size={15} className="animate-spin" /> Gerando BR Code…
              </div>
            ) : (
              <>
                <div className="flex flex-col items-center gap-2 rounded-xl border border-white/10 bg-white p-3">
                  <img src={pix.qr} alt="QR Code Pix" className="h-44 w-44" />
                  <p className="text-[10px] font-semibold text-[#444]">Escaneie no app do seu banco</p>
                </div>
                <div>
                  <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-faint">
                    BR Code copia e cola
                  </p>
                  <div className="flex gap-1.5">
                    <textarea
                      readOnly
                      value={pix.payload}
                      rows={3}
                      className={cx(inputCls, 'resize-none !font-mono !text-[9.5px] !leading-relaxed')}
                    />
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(pix.payload);
                        setCopied(true);
                        setTimeout(() => setCopied(false), 1800);
                      }}
                      className="shrink-0 self-stretch rounded-xl border border-white/10 px-2 text-mute hover:text-chalk"
                      aria-label="Copiar código"
                    >
                      {copied ? <Check size={14} className="text-[#86efac]" /> : <Copy size={13} />}
                    </button>
                  </div>
                  <p className="mt-1 text-[10px] text-faint">
                    Valor: <strong className="text-chalk">{brl(pix.amount)}</strong> · TXID{' '}
                    <span className="font-mono">{pix.txid}</span> · expira em 30 min
                  </p>
                </div>
                <div className="rounded-xl border border-white/[0.08] bg-ink-900/60 p-2.5">
                  <p className="mb-1.5 text-[10.5px] font-semibold text-chalk">
                    Depois de pagar, cole o código E2EID do comprovante
                  </p>
                  <input
                    value={e2eid}
                    onChange={(e) => setE2eid(e.target.value)}
                    placeholder="E12345678202611031200ABCDEF123456"
                    className={cx(inputCls, '!font-mono !text-[10.5px]')}
                  />
                  <p className="mt-1 text-[9.5px] leading-relaxed text-faint">
                    Validamos o formato (E + ISPB + data/hora + identificador), bloqueamos reuso do mesmo comprovante e a liberação é manual pela curadoria — não temos integração bancária (PSP) para conferir a liquidação em tempo real.
                  </p>
                  <button type="button" onClick={confirmPix} className={cx(btnPink, 'mt-2 w-full !py-2 !text-[11.5px]')}>
                    Enviar comprovante para análise
                  </button>
                </div>
                {myOrders.some((o) => o.status === 'pending') && (
                  <p className="rounded-lg border border-[#fbbf24]/30 bg-[#fbbf24]/10 px-2.5 py-1.5 text-[10px] text-[#fcd34d]">
                    Você já tem um comprovante em análise.
                  </p>
                )}
              </>
            )}
            <button type="button" onClick={() => setMode('card')} className={cx(btnGhost, 'w-full !py-2 !text-[11.5px]')}>
              <CreditCard size={12} /> Prefiro pagar com cartão
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="rounded-xl border border-white/10 bg-ink-900/60 p-3">
              <p className="text-[11.5px] text-mute">
                Você será redirecionado ao checkout seguro do Stripe. O retorno é tratado por
                {' '}<span className="font-mono text-[10px] text-hot-300">?stripe_success=true&amp;session_id=…</span>{' '}
                e validado no backend em <span className="font-mono text-[10px]">/api/verify-stripe-payment</span>.
              </p>
              <p className="mt-2 text-[10px] leading-relaxed text-faint">
                Valor: {brl(PLANS.find((p) => p.id === plan)?.price ?? 0)} / mês · assinatura recorrente · cancele quando quiser.
              </p>
            </div>
            <button type="button" onClick={() => void startCard()} disabled={busy} className={cx(btnPink, 'w-full')}>
              {busy ? <Loader2 size={14} className="animate-spin" /> : <CreditCard size={14} />}
              Ir para o checkout Stripe
            </button>
            <button type="button" onClick={() => setMode('pix')} className={cx(btnGhost, 'w-full !py-2 !text-[11.5px]')}>
              <QrCode size={12} /> Prefiro pagar com Pix
            </button>
          </div>
        )}
      </Modal>

      <p className="mt-5 flex items-start gap-1.5 text-[10px] leading-relaxed text-faint">
        <Sparkles size={10} className="mt-0.5 shrink-0 text-hot-400" />
        Assinaturas apoiam diretamente autores independentes. O plano Leitor libera gamificação completa, capítulos antecipados e obras beta; o plano Escritor adiciona selo verificado, 2 impulsionamentos mensais e 1 comunidade exclusiva por ciclo.
      </p>
    </div>
  );
}
