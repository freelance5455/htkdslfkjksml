import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Compass, Lock, Plus, Search, Users } from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Badge, EmptyState, Modal, Pills, btnGhost, btnPink, inputCls } from '../components/ui';
import { bannerArt } from '../lib/art';
import { cx } from '../lib/utils';

export default function CommunitiesView() {
  const { db, currentUser, createCommunity, joinCommunity } = useStore();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<'todas' | 'minhas' | 'publicas' | 'privadas'>('todas');
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ name: '', description: '', privacy: 'public' as 'public' | 'private', tags: '' });

  const list = useMemo(() => {
    let items = db.communities;
    if (filter === 'minhas' && currentUser) {
      items = items.filter((c) => c.members.some((m) => m.userId === currentUser.uid));
    }
    if (filter === 'publicas') items = items.filter((c) => c.privacy === 'public');
    if (filter === 'privadas') items = items.filter((c) => c.privacy === 'private');
    const term = q.trim().toLowerCase();
    if (term) {
      items = items.filter(
        (c) =>
          c.name.toLowerCase().includes(term) ||
          c.description.toLowerCase().includes(term) ||
          c.tags.some((t) => t.toLowerCase().includes(term)),
      );
    }
    return items;
  }, [db.communities, filter, q, currentUser]);

  const visible = (community: (typeof db.communities)[number]) => {
    if (community.privacy === 'public') return true;
    if (!currentUser) return false;
    return community.members.some((m) => m.userId === currentUser.uid) || currentUser.role === 'desenvolvedor';
  };

  return (
    <div className="mx-auto max-w-5xl px-4 pb-10 pt-5 sm:px-6">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">Comunidades</p>
          <h1 className="mt-1 text-[22px] font-bold tracking-tight text-chalk">Leia junto, comente junto</h1>
          <p className="mt-1 text-[12px] text-mute">
            {db.communities.length} comunidades · públicas e privadas, com moderação por papéis
          </p>
        </div>
        <button type="button" onClick={() => setCreating(true)} className={btnPink}>
          <Plus size={14} /> Criar comunidade
        </button>
      </div>

      <div className="mb-3 flex flex-col gap-2 sm:flex-row">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-faint" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar por nome, tema ou tag…"
            className={cx(inputCls, 'pl-9')}
          />
        </div>
        <Pills
          items={[
            { id: 'todas', label: 'Todas' },
            { id: 'minhas', label: 'Minhas' },
            { id: 'publicas', label: 'Públicas' },
            { id: 'privadas', label: 'Privadas' },
          ]}
          value={filter}
          onChange={(v) => setFilter(v as typeof filter)}
        />
      </div>

      {list.length === 0 ? (
        <EmptyState
          icon={<Compass size={28} />}
          title="Nenhuma comunidade encontrada"
          body="Crie a sua: um espaço com feed próprio, papéis de moderação e enquetes."
          action={
            <button type="button" onClick={() => setCreating(true)} className={btnPink}>
              Criar comunidade
            </button>
          }
        />
      ) : (
        <div className="grid gap-2.5 sm:grid-cols-2">
          {list.map((c) => {
            const isMember = currentUser ? c.members.some((m) => m.userId === currentUser.uid) : false;
            const open = visible(c);
            return (
              <div key={c.id} className="liquid-card liquid-card-hover overflow-hidden">
                <button
                  type="button"
                  onClick={() => navigate(open ? `/social/comunidades/${c.id}` : '/assinaturas')}
                  className="block w-full text-left"
                >
                  <div className="relative h-24 overflow-hidden">
                    <img src={c.cover} alt="" className="h-full w-full object-cover" />
                    <div className="scrim-b absolute inset-0" />
                    <div className="absolute bottom-2 left-2.5 right-2.5 flex items-end justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-[12.5px] font-semibold text-chalk">{c.name}</p>
                        <p className="inline-flex items-center gap-1 text-[9.5px] text-mute">
                          <Users size={9} /> {c.members.length} membros
                        </p>
                      </div>
                      <div className="flex shrink-0 gap-1">
                        {c.privacy === 'private' && (
                          <Badge tone="warn" className="!text-[9px]">
                            <Lock size={8} /> privada
                          </Badge>
                        )}
                        {c.featured && <Badge tone="hot" className="!text-[9px]">destaque</Badge>}
                      </div>
                    </div>
                  </div>
                  <div className="p-2.5">
                    <p className="clamp-2 text-[11px] leading-relaxed text-mute">
                      {open ? c.description : 'Comunidade privada — entre para ver o conteúdo.'}
                    </p>
                    <div className="mt-1.5 flex flex-wrap gap-1">
                      {c.tags.slice(0, 3).map((t) => (
                        <span key={t} className="rounded-full bg-white/[0.06] px-1.5 py-0.5 text-[9px] text-faint">
                          #{t}
                        </span>
                      ))}
                    </div>
                  </div>
                </button>
                <div className="flex items-center justify-between border-t border-white/[0.05] px-2.5 py-2">
                  <p className="truncate text-[9.5px] text-faint">por {c.creatorName}</p>
                  <button
                    type="button"
                    onClick={() => (isMember ? navigate(`/social/comunidades/${c.id}`) : joinCommunity(c.id))}
                    className={cx(
                      'rounded-lg px-2.5 py-1 text-[10.5px] font-semibold transition-colors',
                      isMember
                        ? 'border border-white/10 text-mute hover:text-chalk'
                        : 'bg-hot-500 text-[#1a1a1a] hover:bg-hot-600',
                    )}
                  >
                    {isMember ? 'Abrir' : 'Entrar'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal
        open={creating}
        onClose={() => setCreating(false)}
        title="Criar comunidade"
        subtitle="Pública ou privada, com feed, papéis e enquetes."
        footer={
          <div className="flex gap-2">
            <button type="button" onClick={() => setCreating(false)} className={cx(btnGhost, 'flex-1')}>
              Cancelar
            </button>
            <button
              type="button"
              disabled={form.name.trim().length < 3}
              className={cx(btnPink, 'flex-1')}
              onClick={() => {
                const created = createCommunity({
                  name: form.name.trim(),
                  description: form.description.trim(),
                  privacy: form.privacy,
                  cover: bannerArt(form.name.trim() || 'Comunidade'),
                  tags: form.tags
                    .split(',')
                    .map((t) => t.trim().toLowerCase())
                    .filter(Boolean)
                    .slice(0, 5),
                });
                if (created) {
                  setCreating(false);
                  setForm({ name: '', description: '', privacy: 'public', tags: '' });
                  navigate(`/social/comunidades/${created.id}`);
                }
              }}
            >
              Criar
            </button>
          </div>
        }
      >
        <div className="space-y-3">
          <input
            value={form.name}
            onChange={(e) => setForm((s) => ({ ...s, name: e.target.value }))}
            placeholder="Nome da comunidade"
            className={inputCls}
          />
          <textarea
            value={form.description}
            onChange={(e) => setForm((s) => ({ ...s, description: e.target.value }))}
            rows={3}
            placeholder="Qual é a proposta? Que tipo de conversa cabe aqui?"
            className={cx(inputCls, 'resize-none')}
          />
          <input
            value={form.tags}
            onChange={(e) => setForm((s) => ({ ...s, tags: e.target.value }))}
            placeholder="Tags separadas por vírgula (cordel, poesia, beta)"
            className={inputCls}
          />
          <div className="flex gap-2">
            {(['public', 'private'] as const).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setForm((s) => ({ ...s, privacy: p }))}
                className={cx(
                  'flex-1 rounded-xl border px-3 py-2 text-[11.5px] font-medium transition-colors',
                  form.privacy === p
                    ? 'border-hot-500 bg-hot-500/12 text-hot-300'
                    : 'border-white/10 text-mute hover:text-chalk',
                )}
              >
                {p === 'public' ? 'Pública — todos veem' : 'Privada — só membros'}
              </button>
            ))}
          </div>
          <p className="text-[10px] leading-relaxed text-faint">
            Criadores definem papéis: moderador, moderador parcial (só silencia) e membro. Assinatura Escritor libera 1 comunidade exclusiva por ciclo.
          </p>
        </div>
      </Modal>
    </div>
  );
}
