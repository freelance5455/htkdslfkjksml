import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Filter, Search, SlidersHorizontal, Sparkles, X } from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { BookCard } from '../components/Modals';
import { Badge, EmptyState, Pills, inputCls } from '../components/ui';
import { AGE_RATINGS, GENRES, type AgeRating, type Genre } from '../types';
import { cx } from '../lib/utils';

type SortKey = 'recentes' | 'populares' | 'avaliadas' | 'beta';

export default function ExploreBooksView({ onOpenProfile }: { onOpenProfile: (uid: string) => void }) {
  const { db } = useStore();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [genres, setGenres] = useState<Genre[]>([]);
  const [ratings, setRatings] = useState<AgeRating[]>([]);
  const [sort, setSort] = useState<SortKey>('populares');
  const [onlyBeta, setOnlyBeta] = useState(false);
  const [onlyCompleted, setOnlyCompleted] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  const results = useMemo(() => {
    const term = q.trim().toLowerCase();
    let list = db.books.filter((b) => b.status !== 'draft');
    if (term) {
      list = list.filter(
        (b) =>
          b.title.toLowerCase().includes(term) ||
          b.authorName.toLowerCase().includes(term) ||
          b.synopsis.toLowerCase().includes(term) ||
          b.genres.some((g) => g.toLowerCase().includes(term)),
      );
    }
    if (genres.length) list = list.filter((b) => b.genres.some((g) => genres.includes(g)));
    if (ratings.length) list = list.filter((b) => ratings.includes(b.ageRating));
    if (onlyBeta) list = list.filter((b) => b.betaMode);
    if (onlyCompleted) list = list.filter((b) => b.status === 'completed');

    switch (sort) {
      case 'recentes':
        return [...list].sort((a, b) => +new Date(b.updatedAt) - +new Date(a.updatedAt));
      case 'avaliadas':
        return [...list].sort((a, b) => b.rating - a.rating);
      case 'beta':
        return [...list].sort((a, b) => Number(b.betaMode) - Number(a.betaMode));
      default:
        return [...list].sort((a, b) => b.readers - a.readers);
    }
  }, [db.books, q, genres, ratings, onlyBeta, onlyCompleted, sort]);

  const toggle = <T,>(arr: T[], v: T, set: (n: T[]) => void) =>
    set(arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  const activeFilters = genres.length + ratings.length + (onlyBeta ? 1 : 0) + (onlyCompleted ? 1 : 0);

  return (
    <div className="mx-auto max-w-7xl px-4 pb-10 pt-5 sm:px-6">
      <div className="mb-4">
        <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">Catálogo</p>
        <h1 className="mt-1 text-[23px] font-bold tracking-tight text-chalk">Explorar obras</h1>
        <p className="mt-1 text-[12px] text-mute">
          {results.length} obra{results.length === 1 ? '' : 's'} · cordel, romance, fantasia, ficção científica e mais
        </p>
      </div>

      <div className="mb-3 flex gap-2">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-faint" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Título, autor, sinopse ou gênero…"
            className={cx(inputCls, 'pl-9')}
          />
          {q && (
            <button
              type="button"
              onClick={() => setQ('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-0.5 text-faint hover:text-chalk"
              aria-label="Limpar"
            >
              <X size={13} />
            </button>
          )}
        </div>
        <button
          type="button"
          onClick={() => setShowFilters((v) => !v)}
          className={cx(
            'relative inline-flex shrink-0 items-center gap-1.5 rounded-xl border px-3 text-[12px] font-medium transition-colors',
            showFilters || activeFilters
              ? 'border-hot-500/50 bg-hot-500/[0.1] text-hot-300'
              : 'border-white/10 bg-white/[0.045] text-mute hover:text-chalk',
          )}
        >
          <SlidersHorizontal size={14} />
          Filtros
          {activeFilters > 0 && (
            <span className="grid h-4 min-w-4 place-items-center rounded-full bg-hot-500 px-1 text-[9px] font-bold text-[#1a1a1a]">
              {activeFilters}
            </span>
          )}
        </button>
      </div>

      <div className="mb-3 flex flex-wrap items-center gap-1.5">
        <Pills
          items={[
            { id: 'populares', label: 'Populares' },
            { id: 'recentes', label: 'Recentes' },
            { id: 'avaliadas', label: 'Melhor avaliadas' },
            { id: 'beta', label: 'Beta' },
          ]}
          value={sort}
          onChange={(v) => setSort(v as SortKey)}
        />
        <button
          type="button"
          onClick={() => setOnlyBeta((v) => !v)}
          className={cx(
            'inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors',
            onlyBeta ? 'border-[#60a5fa]/50 bg-[#60a5fa]/15 text-[#bfdbfe]' : 'border-white/10 text-mute hover:text-chalk',
          )}
        >
          🧪 Leitura beta
        </button>
        <button
          type="button"
          onClick={() => setOnlyCompleted((v) => !v)}
          className={cx(
            'inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors',
            onlyCompleted ? 'border-[#4ade80]/50 bg-[#4ade80]/12 text-[#86efac]' : 'border-white/10 text-mute hover:text-chalk',
          )}
        >
          ✓ Completas
        </button>
      </div>

      {showFilters && (
        <div className="liquid-card mb-4 space-y-3.5 p-3.5">
          <div>
            <p className="mb-1.5 flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-faint">
              <Filter size={10} /> Gêneros
            </p>
            <div className="flex flex-wrap gap-1.5">
              {GENRES.map((g) => {
                const active = genres.includes(g);
                return (
                  <button
                    key={g}
                    type="button"
                    onClick={() => toggle(genres, g, setGenres)}
                    className={cx(
                      'rounded-full border px-2.5 py-1 text-[11px] transition-colors',
                      active
                        ? 'border-hot-500 bg-hot-500/15 text-hot-300'
                        : 'border-white/10 text-mute hover:border-white/25 hover:text-chalk',
                    )}
                  >
                    {g}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <p className="mb-1.5 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-faint">
              Classificação indicativa
            </p>
            <div className="flex flex-wrap gap-1.5">
              {AGE_RATINGS.map((r) => {
                const active = ratings.includes(r);
                return (
                  <button
                    key={r}
                    type="button"
                    onClick={() => toggle(ratings, r, setRatings)}
                    className={cx(
                      'rounded-lg border px-2.5 py-1 text-[11px] transition-colors',
                      active
                        ? 'border-hot-500 bg-hot-500/15 text-hot-300'
                        : 'border-white/10 text-mute hover:border-white/25 hover:text-chalk',
                    )}
                  >
                    {r}
                  </button>
                );
              })}
            </div>
          </div>
          {activeFilters > 0 && (
            <button
              type="button"
              onClick={() => {
                setGenres([]);
                setRatings([]);
                setOnlyBeta(false);
                setOnlyCompleted(false);
              }}
              className="text-[11px] font-medium text-hot-300 hover:text-hot-400"
            >
              Limpar filtros
            </button>
          )}
        </div>
      )}

      {results.length === 0 ? (
        <EmptyState
          icon={<Search size={30} />}
          title="Nenhuma obra encontrada"
          body="Ajuste a busca ou remova alguns filtros. Se você escreve, publique no Estúdio — o catálogo cresce com você."
        />
      ) : (
        <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4 lg:grid-cols-6">
          {results.map((b) => (
            <BookCard key={b.id} book={b} onOpen={() => navigate(`/obra/${b.id}`)} />
          ))}
        </div>
      )}

      <section className="mt-8">
        <p className="mb-2 text-[10.5px] font-semibold uppercase tracking-[0.18em] text-faint">Autores em destaque</p>
        <div className="no-scrollbar flex gap-2.5 overflow-x-auto pb-1">
          {db.users
            .filter((u) => db.books.some((b) => b.authorId === u.uid))
            .map((u) => (
              <button
                key={u.uid}
                type="button"
                onClick={() => onOpenProfile(u.uid)}
                className="liquid-card liquid-card-hover flex w-[172px] shrink-0 flex-col items-center gap-2 p-3 text-center"
              >
                <img src={u.photoURL} alt="" className="h-14 w-14 rounded-full object-cover ring-2 ring-hot-500/40 ring-offset-2 ring-offset-ink-750" />
                <span className="w-full truncate text-[12px] font-semibold text-chalk">{u.displayName}</span>
                <Badge tone={u.role === 'escritor' ? 'info' : 'neutral'} className="!text-[9.5px]">
                  {u.role}
                </Badge>
              </button>
            ))}
        </div>
      </section>
    </div>
  );
}
