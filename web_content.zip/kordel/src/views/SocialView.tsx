import { Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { Compass, Film, Home } from 'lucide-react';
import { cx } from '../lib/utils';
import CommunitiesView from './CommunitiesView';
import CommunityDetailView from './CommunityDetailView';
import FluxView from './FluxView';
import FluxCreatorView from './FluxCreatorView';
import SocialHomeView from './SocialHomeView';

const SUBS = [
  { to: '/social', label: 'INÍCIO', icon: Home },
  { to: '/social/comunidades', label: 'COMUNIDADES', icon: Compass },
  { to: '/social/flux', label: 'FLUX', icon: Film },
];

export default function SocialView() {
  const location = useLocation();
  const navigate = useNavigate();
  const isFlux = location.pathname.startsWith('/social/flux');

  const active =
    location.pathname.startsWith('/social/comunidades')
      ? '/social/comunidades'
      : isFlux
        ? '/social/flux'
        : '/social';

  return (
    <div className={isFlux ? '' : 'min-h-[80dvh]'}>
      {/* Sub-navegação em pílula escura */}
      <div className="sticky top-[58px] z-40 border-b border-white/[0.06] bg-ink-850/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-5xl items-center justify-center gap-1 px-3 py-2">
          {SUBS.map((s) => {
            const on = active === s.to;
            return (
              <button
                key={s.to}
                type="button"
                onClick={() => navigate(s.to)}
                className={cx(
                  'inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-[11px] font-bold tracking-[0.1em] transition-all',
                  on
                    ? 'border-hot-500 bg-hot-500/[0.12] text-hot-300 shadow-[0_0_18px_-8px_rgba(255,87,178,0.9)]'
                    : 'border-transparent text-faint hover:text-chalk',
                )}
              >
                <s.icon size={12} />
                {s.label}
              </button>
            );
          })}
        </div>
      </div>

      <Routes>
        <Route index element={<SocialHomeView />} />
        <Route path="comunidades" element={<CommunitiesView />} />
        <Route path="comunidades/:communityId" element={<CommunityDetailView />} />
        <Route path="flux" element={<FluxView />} />
        <Route path="flux/criar" element={<FluxCreatorView />} />
      </Routes>
    </div>
  );
}
