import { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  BarChart3,
  Ban,
  BellOff,
  Flag,
  Heart,
  Image as ImageIcon,
  Lock,
  MessageCircle,
  Mic,
  Pencil,
  Plus,
  Send,
  Shield,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Avatar, Badge, EmptyState, Modal, Pills, btnGhost, btnPink, inputCls } from '../components/ui';
import { ReportModal } from '../components/Modals';
import { readFileAsDataUrl, cx, formatDate, timeAgo } from '../lib/utils';
import { uploadMedia } from '../lib/api';
import type { CommunityRole, ModerationState, Post } from '../types';

const ROLE_LABEL: Record<CommunityRole, string> = {
  creator: 'Criador',
  moderator: 'Moderador',
  partial_moderator: 'Mod. parcial',
  member: 'Membro',
};

export default function CommunityDetailView() {
  const { communityId } = useParams<{ communityId: string }>();
  const {
    db,
    currentUser,
    joinCommunity,
    leaveCommunity,
    setMemberRole,
    setMemberModeration,
    createPost,
    deletePost,
    toggleLikePost,
    toggleSavePost,
    votePoll,
    addPostComment,
    editPostComment,
    deletePostComment,
  } = useStore();
  const navigate = useNavigate();
  const [composerOpen, setComposerOpen] = useState(false);
  const [membersOpen, setMembersOpen] = useState(false);
  const [report, setReport] = useState<{ type: 'community' | 'post'; id: string; label: string } | null>(null);

  const community = db.communities.find((c) => c.id === communityId);
  const posts = useMemo(
    () => db.posts.filter((p) => p.communityId === communityId).sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)),
    [db.posts, communityId],
  );

  if (!community) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20">
        <EmptyState title="Comunidade não encontrada" body="Ela pode ter sido excluída pelo criador." />
      </div>
    );
  }

  const myMembership = currentUser ? community.members.find((m) => m.userId === currentUser.uid) : undefined;
  const isMember = Boolean(myMembership);
  const isStaff = myMembership?.role === 'creator' || myMembership?.role === 'moderator';
  const isCreator = myMembership?.role === 'creator';
  const canSee = community.privacy === 'public' || isMember || currentUser?.role === 'desenvolvedor';

  if (!canSee) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16">
        <div className="liquid-card p-6 text-center">
          <Lock size={26} className="mx-auto text-[#fcd34d]" />
          <h2 className="mt-3 text-[15px] font-bold text-chalk">Comunidade privada</h2>
          <p className="mx-auto mt-1.5 max-w-xs text-[12px] leading-relaxed text-mute">
            Só membros aprovados veem o feed. Peça entrada ao criador ou entre com uma conta convidada.
          </p>
          <button
            type="button"
            onClick={() => {
              if (!currentUser) navigate('/entrar');
              else joinCommunity(community.id);
            }}
            className={cx(btnPink, 'mt-4')}
          >
            {currentUser ? 'Solicitar entrada' : 'Entrar na KORDEL'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-10">
      <div className="relative">
        <img src={community.cover} alt="" className="h-36 w-full object-cover sm:h-44" />
        <div className="scrim-b absolute inset-0" />
        <div className="absolute inset-x-0 top-0 p-3">
          <button
            type="button"
            onClick={() => navigate('/social/comunidades')}
            className="inline-flex items-center gap-1 rounded-lg bg-black/40 px-2 py-1 text-[11px] text-chalk backdrop-blur hover:bg-black/60"
          >
            <ArrowLeft size={12} /> Comunidades
          </button>
        </div>
        <div className="absolute inset-x-0 bottom-0 p-3.5">
          <div className="mx-auto flex max-w-3xl items-end justify-between gap-3">
            <div className="min-w-0">
              <div className="mb-1 flex gap-1">
                <Badge tone={community.privacy === 'public' ? 'ok' : 'warn'}>
                  {community.privacy === 'public' ? 'pública' : 'privada'}
                </Badge>
                {community.featured && <Badge tone="hot">destaque</Badge>}
                {myMembership && <Badge tone="info">{ROLE_LABEL[myMembership.role]}</Badge>}
              </div>
              <h1 className="truncate text-[20px] font-bold text-chalk sm:text-[24px]">{community.name}</h1>
              <p className="text-[10.5px] text-mute">
                {community.members.length} membros · criada por {community.creatorName} · {formatDate(community.createdAt)}
              </p>
            </div>
            <div className="flex shrink-0 gap-1.5">
              {isMember ? (
                <>
                  <button type="button" onClick={() => setMembersOpen(true)} className={cx(btnGhost, '!px-2.5 !py-1.5 !text-[11px]')}>
                    <Users size={12} /> Membros
                  </button>
                  <button
                    type="button"
                    onClick={() => leaveCommunity(community.id)}
                    className="rounded-xl border border-white/10 px-2.5 py-1.5 text-[11px] text-mute hover:text-[#fca5a5]"
                  >
                    Sair
                  </button>
                </>
              ) : (
                <button type="button" onClick={() => joinCommunity(community.id)} className={cx(btnPink, '!px-3 !py-1.5 !text-[11.5px]')}>
                  Entrar
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-3xl px-4 pt-4 sm:px-6">
        <p className="synopsis mb-3 text-[12.5px] leading-relaxed text-mute">{community.description}</p>

        <div className="mb-3 flex flex-wrap items-center gap-1.5">
          {community.tags.map((t) => (
            <span key={t} className="rounded-full bg-white/[0.06] px-2 py-0.5 text-[9.5px] text-faint">
              #{t}
            </span>
          ))}
          <button
            type="button"
            onClick={() => setReport({ type: 'community', id: community.id, label: community.name })}
            className="ml-auto inline-flex items-center gap-1 text-[10px] text-faint hover:text-[#fca5a5]"
          >
            <Flag size={9} /> Denunciar
          </button>
        </div>

        {isMember ? (
          <button
            type="button"
            onClick={() => setComposerOpen(true)}
            className="liquid-card mb-3 flex w-full items-center gap-2 p-3 text-left transition-colors hover:border-hot-500/35"
          >
            <Avatar src={currentUser?.photoURL} name={currentUser?.displayName ?? ''} size={30} />
            <span className="text-[12px] text-faint">Publicar texto, imagem, carrossel, vídeo ou enquete…</span>
            <Plus size={14} className="ml-auto text-hot-400" />
          </button>
        ) : (
          <div className="liquid-card mb-3 p-3 text-center text-[11.5px] text-mute">
            Entre na comunidade para publicar e comentar.
          </div>
        )}

        {posts.length === 0 ? (
          <EmptyState icon={<MessageCircle size={26} />} title="Sem posts ainda" body="Publique a primeira mensagem deste feed." />
        ) : (
          <div className="space-y-2.5">
            {posts.map((p) => (
              <PostCard
                key={p.id}
                post={p}
                canModerate={isStaff}
                myId={currentUser?.uid ?? null}
                onLike={() => toggleLikePost(p.id, false)}
                onSave={() => toggleSavePost(p.id)}
                onVote={(opt) => votePoll(p.id, opt, false)}
                onComment={(text, parent) => addPostComment(p.id, text, parent, false)}
                onEditComment={(cid, text) => editPostComment(p.id, cid, text, false)}
                onDeleteComment={(cid) => deletePostComment(p.id, cid, false)}
                onDelete={() => deletePost(p.id, false)}
                onReport={() => setReport({ type: 'post', id: p.id, label: `Post de ${p.authorName}` })}
                onProfile={(uid) => navigate(`/perfil/${uid}`)}
              />
            ))}
          </div>
        )}
      </div>

      <Composer
        open={composerOpen}
        onClose={() => setComposerOpen(false)}
        communityId={community.id}
        onCreate={(payload) => {
          const created = createPost({ communityId: community.id, ...payload });
          if (created) setComposerOpen(false);
        }}
      />

      {/* Membros & moderação */}
      <Modal open={membersOpen} onClose={() => setMembersOpen(false)} title="Membros e moderação" size="lg">
        <div className="space-y-1.5">
          {community.members.map((m) => (
            <div key={m.userId} className="flex items-center gap-2.5 rounded-xl border border-white/[0.06] bg-ink-900/50 p-2">
              <button type="button" onClick={() => navigate(`/perfil/${m.userId}`)}>
                <Avatar src={m.userPhoto} name={m.userName} size={30} />
              </button>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[11.5px] font-semibold text-chalk">{m.userName}</p>
                <p className="text-[9.5px] text-faint">
                  {ROLE_LABEL[m.role]}
                  {m.moderation !== 'active' && ` · ${m.moderation === 'banned' ? 'banido' : 'silenciado'}`}
                </p>
              </div>
              {isCreator && m.role !== 'creator' && (
                <div className="flex shrink-0 items-center gap-1">
                  <select
                    value={m.role}
                    onChange={(e) => setMemberRole(community.id, m.userId, e.target.value as CommunityRole)}
                    className="rounded-lg border border-white/10 bg-ink-800 px-1.5 py-1 text-[9.5px] text-mute"
                  >
                    <option value="member" className="bg-ink-800">Membro</option>
                    <option value="partial_moderator" className="bg-ink-800">Mod. parcial</option>
                    <option value="moderator" className="bg-ink-800">Moderador</option>
                  </select>
                  <button
                    type="button"
                    onClick={() =>
                      setMemberModeration(
                        community.id,
                        m.userId,
                        m.moderation === 'silenced' ? 'active' : 'silenced',
                      )
                    }
                    className={cx(
                      'rounded-lg p-1.5',
                      m.moderation === 'silenced' ? 'bg-[#fbbf24]/20 text-[#fcd34d]' : 'text-faint hover:text-[#fcd34d]',
                    )}
                    title="Silenciar / reativar"
                  >
                    <BellOff size={11} />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setMemberModeration(community.id, m.userId, m.moderation === 'banned' ? 'active' : 'banned')
                    }
                    className={cx(
                      'rounded-lg p-1.5',
                      m.moderation === 'banned' ? 'bg-[#f87171]/20 text-[#fca5a5]' : 'text-faint hover:text-[#fca5a5]',
                    )}
                    title="Banir / reativar"
                  >
                    <Ban size={11} />
                  </button>
                </div>
              )}
              {!isCreator && isStaff && <Badge tone="neutral" className="!text-[9px]">{ROLE_LABEL[m.role]}</Badge>}
            </div>
          ))}
        </div>
        {isStaff && (
          <p className="mt-3 flex items-start gap-1.5 rounded-lg border border-white/[0.07] bg-ink-900/40 p-2 text-[10px] leading-relaxed text-faint">
            <Shield size={11} className="mt-0.5 shrink-0 text-hot-400" />
            Moderadores gerenciam posts e silenciam membros. Apenas o criador altera papéis e bane.
          </p>
        )}
      </Modal>

      <ReportModal
        open={Boolean(report)}
        onClose={() => setReport(null)}
        targetType={report?.type ?? 'post'}
        targetId={report?.id ?? ''}
        targetLabel={report?.label ?? ''}
      />
    </div>
  );
}

/* ── Card de post com comentários aninhados ─────────────────────────────── */
export function PostCard({
  post,
  myId,
  canModerate,
  onLike,
  onSave,
  onVote,
  onComment,
  onEditComment,
  onDeleteComment,
  onDelete,
  onReport,
  onProfile,
  compactMedia = false,
}: {
  post: Post;
  myId: string | null;
  canModerate?: boolean;
  onLike: () => void;
  onSave: () => void;
  onVote: (optionId: string) => void;
  onComment: (text: string, parentId: string | null) => void;
  onEditComment: (id: string, text: string) => void;
  onDeleteComment: (id: string) => void;
  onDelete: () => void;
  onReport: () => void;
  onProfile: (uid: string) => void;
  compactMedia?: boolean;
}) {
  const [showComments, setShowComments] = useState(false);
  const [text, setText] = useState('');
  const [replyTo, setReplyTo] = useState<{ id: string; name: string } | null>(null);
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(null);
  const [mediaIndex, setMediaIndex] = useState(0);

  const liked = myId ? post.likes.includes(myId) : false;
  const saved = myId ? post.savedBy.includes(myId) : false;
  const roots = post.comments.filter((c) => !c.parentId);
  const totalVotes = post.poll?.options.reduce((a, o) => a + o.votes.length, 0) ?? 0;
  const myVote = myId ? post.poll?.options.find((o) => o.votes.includes(myId))?.id : undefined;

  return (
    <article className="liquid-card p-3">
      <div className="flex items-center gap-2">
        <button type="button" onClick={() => onProfile(post.authorId)}>
          <Avatar src={post.authorPhoto} name={post.authorName} size={30} />
        </button>
        <div className="min-w-0 flex-1">
          <button type="button" onClick={() => onProfile(post.authorId)} className="block truncate text-[11.5px] font-semibold text-chalk hover:text-hot-300">
            {post.authorName}
          </button>
          <p className="text-[9.5px] text-faint">
            {timeAgo(post.createdAt)} atrás{post.communityName ? ` · ${post.communityName}` : ''}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-0.5">
          <button type="button" onClick={onReport} className="rounded p-1 text-faint hover:text-[#fca5a5]" aria-label="Denunciar">
            <Flag size={11} />
          </button>
          {(post.authorId === myId || canModerate) && (
            <button type="button" onClick={onDelete} className="rounded p-1 text-faint hover:text-[#fca5a5]" aria-label="Excluir post">
              <Trash2 size={11} />
            </button>
          )}
        </div>
      </div>

      {post.text && <p className="mt-2 whitespace-pre-wrap text-[12.5px] leading-relaxed text-mute">{post.text}</p>}

      {/* Mídia */}
      {post.media.length > 0 && (
        <div className={cx('mt-2 overflow-hidden rounded-xl', compactMedia && 'max-h-64')}>
          {post.type === 'carousel' && post.media.length > 1 ? (
            <div className="relative">
              <img src={post.media[mediaIndex]} alt="" className="h-auto max-h-[380px] w-full object-cover" />
              <div className="absolute inset-x-0 bottom-1.5 flex justify-center gap-1">
                {post.media.map((_, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setMediaIndex(i)}
                    className={cx('h-1.5 rounded-full transition-all', i === mediaIndex ? 'w-4 bg-hot-500' : 'w-1.5 bg-white/50')}
                    aria-label={`Mídia ${i + 1}`}
                  />
                ))}
              </div>
              <button
                type="button"
                onClick={() => setMediaIndex((i) => (i + 1) % post.media.length)}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-1.5 text-chalk"
                aria-label="Próxima mídia"
              >
                <ImageIcon size={12} />
              </button>
            </div>
          ) : post.type === 'video' ? (
            <video src={post.media[0]} controls className="max-h-[380px] w-full bg-black" />
          ) : (
            <img src={post.media[0]} alt="" className="h-auto max-h-[380px] w-full object-cover" />
          )}
        </div>
      )}

      {post.audioUrl && (
        <audio src={post.audioUrl} controls className="mt-2 w-full" />
      )}

      {/* Enquete */}
      {post.poll && (
        <div className="mt-2 rounded-xl border border-white/[0.07] bg-ink-900/60 p-2.5">
          <p className="mb-1.5 flex items-center gap-1 text-[11px] font-semibold text-chalk">
            <BarChart3 size={11} className="text-hot-400" /> {post.poll.question}
          </p>
          <div className="space-y-1.5">
            {post.poll.options.map((o) => {
              const pctv = totalVotes ? Math.round((o.votes.length / totalVotes) * 100) : 0;
              const mine = myVote === o.id;
              return (
                <button
                  key={o.id}
                  type="button"
                  onClick={() => onVote(o.id)}
                  className={cx(
                    'relative w-full overflow-hidden rounded-lg border px-2.5 py-1.5 text-left transition-colors',
                    mine ? 'border-hot-500/60 bg-hot-500/[0.1]' : 'border-white/10 hover:border-white/25',
                  )}
                >
                  <span
                    className="absolute inset-y-0 left-0 bg-hot-500/15 transition-[width] duration-500"
                    style={{ width: `${pctv}%` }}
                  />
                  <span className="relative flex items-center justify-between gap-2">
                    <span className={cx('text-[11px]', mine ? 'font-semibold text-hot-200' : 'text-mute')}>{o.text}</span>
                    <span className="shrink-0 text-[10px] tabular-nums text-faint">{pctv}%</span>
                  </span>
                </button>
              );
            })}
          </div>
          <p className="mt-1.5 text-[9.5px] text-faint">{totalVotes} votos · toque para votar (1 voto por conta)</p>
        </div>
      )}

      {/* Ações */}
      <div className="mt-2 flex items-center gap-3 border-t border-white/[0.05] pt-2 text-[10.5px]">
        <button
          type="button"
          onClick={onLike}
          className={cx('inline-flex items-center gap-1', liked ? 'text-hot-500' : 'text-faint hover:text-hot-400')}
        >
          <Heart size={12} className={liked ? 'fill-hot-500' : ''} /> {post.likes.length}
        </button>
        <button
          type="button"
          onClick={() => setShowComments((v) => !v)}
          className="inline-flex items-center gap-1 text-faint hover:text-chalk"
        >
          <MessageCircle size={12} /> {post.comments.length}
        </button>
        <button
          type="button"
          onClick={onSave}
          className={cx('ml-auto inline-flex items-center gap-1', saved ? 'text-hot-400' : 'text-faint hover:text-chalk')}
        >
          <Mic size={12} className={saved ? 'text-hot-400' : ''} /> {saved ? 'salvo' : 'salvar'}
        </button>
      </div>

      {showComments && (
        <div className="mt-2 border-t border-white/[0.05] pt-2">
          {myId && (
            <div className="mb-2">
              {replyTo && (
                <p className="mb-1 flex items-center justify-between rounded bg-hot-500/10 px-2 py-0.5 text-[10px] text-hot-300">
                  respondendo {replyTo.name}
                  <button type="button" onClick={() => setReplyTo(null)} aria-label="Cancelar">
                    <X size={10} />
                  </button>
                </p>
              )}
              <div className="flex gap-1.5">
                <input
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Comentar…"
                  className={cx(inputCls, '!py-1.5 !text-[11.5px]')}
                  onKeyDown={(e) => {
                    if (e.key !== 'Enter' || !text.trim()) return;
                    if (editing) {
                      onEditComment(editing.id, text.trim());
                      setEditing(null);
                    } else onComment(text.trim(), replyTo?.id ?? null);
                    setText('');
                    setReplyTo(null);
                  }}
                />
                <button
                  type="button"
                  onClick={() => {
                    if (!text.trim()) return;
                    if (editing) {
                      onEditComment(editing.id, text.trim());
                      setEditing(null);
                    } else onComment(text.trim(), replyTo?.id ?? null);
                    setText('');
                    setReplyTo(null);
                  }}
                  className="shrink-0 rounded-lg bg-hot-500 px-2 text-[#1a1a1a]"
                  aria-label="Enviar comentário"
                >
                  <Send size={12} />
                </button>
              </div>
            </div>
          )}

          {roots.length === 0 && <p className="py-2 text-center text-[10.5px] text-faint">Nenhum comentário ainda.</p>}

          <div className="space-y-2">
            {roots.map((c) => {
              const replies = post.comments.filter((r) => r.parentId === c.id);
              return (
                <div key={c.id}>
                  <div className="flex items-start gap-1.5">
                    <button type="button" onClick={() => onProfile(c.userId)}>
                      <Avatar src={c.userPhoto} name={c.userName} size={20} />
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className="text-[10.5px] font-semibold text-chalk">
                        {c.userName} <span className="font-normal text-faint">· {timeAgo(c.createdAt)}</span>
                      </p>
                      <p className="text-[11px] leading-relaxed text-mute">{c.content}</p>
                      <div className="mt-0.5 flex gap-2 text-[9.5px] text-faint">
                        <button type="button" onClick={() => setReplyTo({ id: c.id, name: c.userName })} className="hover:text-hot-300">
                          responder
                        </button>
                        {c.userId === myId && (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                setEditing({ id: c.id, text: c.content });
                                setText(c.content);
                              }}
                              className="hover:text-chalk"
                            >
                              editar
                            </button>
                            <button type="button" onClick={() => onDeleteComment(c.id)} className="hover:text-[#fca5a5]">
                              excluir
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  {replies.length > 0 && (
                    <div className="ml-5 mt-1 space-y-1 border-l border-white/[0.07] pl-2">
                      {replies.map((r) => (
                        <div key={r.id} className="flex items-start gap-1.5">
                          <Avatar src={r.userPhoto} name={r.userName} size={16} />
                          <div className="min-w-0 flex-1">
                            <p className="text-[10px] font-semibold text-chalk">
                              {r.userName} <span className="font-normal text-faint">· {timeAgo(r.createdAt)}</span>
                            </p>
                            <p className="text-[10.5px] leading-relaxed text-mute">{r.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </article>
  );
}

/* ── Composer: texto, imagem, carrossel, vídeo, enquete, story ──────────── */
export function Composer({
  open,
  onClose,
  communityId,
  onCreate,
}: {
  open: boolean;
  onClose: () => void;
  communityId: string | null;
  onCreate: (payload: {
    type: Post['type'];
    text: string;
    media?: string[];
    poll?: Post['poll'];
    audioUrl?: string | null;
  }) => void;
}) {
  const [type, setType] = useState<Post['type']>('text');
  const [text, setText] = useState('');
  const [media, setMedia] = useState<string[]>([]);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);
  const [busy, setBusy] = useState(false);

  const upload = async (file: File, folder: 'posts' | 'audios') => {
    setBusy(true);
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const res = await uploadMedia(dataUrl, folder, file.name);
      return res.url;
    } catch {
      return await readFileAsDataUrl(file);
    } finally {
      setBusy(false);
    }
  };

  const reset = () => {
    setType('text');
    setText('');
    setMedia([]);
    setAudioUrl(null);
    setPollQuestion('');
    setPollOptions(['', '']);
  };

  return (
    <Modal
      open={open}
      onClose={() => {
        reset();
        onClose();
      }}
      title={communityId ? 'Novo post na comunidade' : 'Criar Flux'}
      size="lg"
      footer={
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => {
              reset();
              onClose();
            }}
            className={cx(btnGhost, 'flex-1')}
          >
            Cancelar
          </button>
          <button
            type="button"
            disabled={busy || (!text.trim() && media.length === 0 && !pollQuestion.trim())}
            className={cx(btnPink, 'flex-1')}
            onClick={() => {
              const cleanOpts = pollOptions.map((o) => o.trim()).filter(Boolean);
              onCreate({
                type: type === 'poll' && cleanOpts.length < 2 ? 'text' : type,
                text: text.trim(),
                media,
                audioUrl,
                poll:
                  type === 'poll' && cleanOpts.length >= 2
                    ? {
                        question: pollQuestion.trim() || text.trim(),
                        options: cleanOpts.map((o, i) => ({ id: `o${i + 1}`, text: o, votes: [] })),
                      }
                    : null,
              });
              reset();
            }}
          >
            Publicar
          </button>
        </div>
      }
    >
      <div className="space-y-3">
        <div className="flex flex-wrap gap-1.5">
          {(
            [
              ['text', 'Texto'],
              ['image', 'Imagem'],
              ['carousel', 'Carrossel'],
              ['video', 'Vídeo'],
              ['poll', 'Enquete'],
              ['story', 'Story Canvas'],
            ] as Array<[Post['type'], string]>
          ).map(([t, label]) => (
            <button
              key={t}
              type="button"
              onClick={() => setType(t)}
              className={cx(
                'rounded-full border px-2.5 py-1 text-[10.5px] transition-colors',
                type === t ? 'border-hot-500 bg-hot-500/15 text-hot-300' : 'border-white/10 text-mute hover:text-chalk',
              )}
            >
              {label}
            </button>
          ))}
        </div>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={type === 'story' ? 5 : 3}
          placeholder={
            type === 'story'
              ? 'Texto do Story Canvas — aparece centralizado em tela cheia.'
              : 'O que você quer dizer para a comunidade?'
          }
          className={cx(inputCls, 'resize-none', type === 'story' && 'font-literata text-[13px] leading-relaxed')}
        />

        {(type === 'image' || type === 'carousel' || type === 'video') && (
          <label className="flex cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-dashed border-white/15 py-3 text-[11.5px] text-mute hover:border-hot-500/40 hover:text-chalk">
            <ImageIcon size={13} />
            {busy ? 'Enviando…' : `Selecionar ${type === 'video' ? 'vídeo' : type === 'carousel' ? 'imagens (múltiplas)' : 'imagem'}`}
            <input
              type="file"
              accept={type === 'video' ? 'video/*' : 'image/*'}
              multiple={type === 'carousel'}
              className="hidden"
              onChange={async (e) => {
                const files = Array.from(e.target.files ?? []);
                const urls: string[] = [];
                for (const f of files) urls.push(await upload(f, 'posts'));
                setMedia(type === 'carousel' ? urls : urls.slice(0, 1));
              }}
            />
          </label>
        )}

        {media.length > 0 && (
          <div className="flex gap-1.5 overflow-x-auto">
            {media.map((m, i) => (
              <div key={`${m}-${i}`} className="relative shrink-0">
                {type === 'video' ? (
                  <video src={m} className="h-20 rounded-lg" />
                ) : (
                  <img src={m} alt="" className="h-20 rounded-lg object-cover" />
                )}
                <button
                  type="button"
                  onClick={() => setMedia(media.filter((_, j) => j !== i))}
                  className="absolute -right-1 -top-1 rounded-full bg-ink-900 p-0.5 text-[#fca5a5] ring-1 ring-white/20"
                  aria-label="Remover"
                >
                  <X size={9} />
                </button>
              </div>
            ))}
          </div>
        )}

        {type === 'story' && (
          <div className="rounded-xl border border-white/[0.08] bg-ink-900/60 p-2.5">
            <label className="flex cursor-pointer items-center gap-1.5 text-[11px] text-mute hover:text-chalk">
              <Mic size={12} /> Trilha de áudio (opcional)
              <input
                type="file"
                accept="audio/*"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (f) setAudioUrl(await upload(f, 'audios'));
                }}
              />
            </label>
            {audioUrl && <audio src={audioUrl} controls className="mt-1.5 w-full" />}
          </div>
        )}

        {type === 'poll' && (
          <div className="space-y-1.5 rounded-xl border border-white/[0.08] bg-ink-900/60 p-2.5">
            <input
              value={pollQuestion}
              onChange={(e) => setPollQuestion(e.target.value)}
              placeholder="Pergunta da enquete"
              className={cx(inputCls, '!py-1.5 !text-[11.5px]')}
            />
            {pollOptions.map((o, i) => (
              <div key={i} className="flex gap-1.5">
                <input
                  value={o}
                  onChange={(e) => setPollOptions((prev) => prev.map((x, j) => (j === i ? e.target.value : x)))}
                  placeholder={`Opção ${i + 1}`}
                  className={cx(inputCls, '!py-1.5 !text-[11.5px]')}
                />
                {pollOptions.length > 2 && (
                  <button
                    type="button"
                    onClick={() => setPollOptions((prev) => prev.filter((_, j) => j !== i))}
                    className="text-faint hover:text-[#fca5a5]"
                    aria-label="Remover opção"
                  >
                    <X size={12} />
                  </button>
                )}
              </div>
            ))}
            {pollOptions.length < 5 && (
              <button
                type="button"
                onClick={() => setPollOptions((prev) => [...prev, ''])}
                className="inline-flex items-center gap-1 text-[10.5px] text-hot-300"
              >
                <Plus size={10} /> Adicionar opção
              </button>
            )}
          </div>
        )}

        <p className="text-[10px] leading-relaxed text-faint">
          {communityId
            ? 'Publicado no feed da comunidade. Moderadores podem remover conteúdos que violem as regras.'
            : 'Publicado no Flux vertical. Vídeos e Stories ocupam a tela inteira.'}
        </p>
      </div>
    </Modal>
  );
}
