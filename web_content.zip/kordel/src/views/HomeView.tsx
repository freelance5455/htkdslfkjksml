import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Clock,
  Crown,
  Flame,
  Play,
  Sparkles,
  TrendingUp,
  Users,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useStore } from '../contexts/StoreContext';
import { BookCard } from '../components/Modals';
import { Badge, EmptyState, Progress, SectionHeader, Stars, btnGhost, btnPink } from '../components/ui';
import { compact, cx, formatDate, pct } from '../lib/utils';
import { levelFromXp } from '../lib/xp';
import type { Book } from '../types';

export default function HomeView({ onOpenProfile }: { onOpenProfile: (uid: string) => void }) {
  const { db, currentUser } = useStore();
  const navigate = useNavigate();
  const featured = useMemo(() => {
    const ids = db.branding.featuredBookIds;
    const list = ids.map((id) => db.books.find((b) => b.id === id)).filter(Boolean) as typeof db.books;
    return list.length ? list : db.books.filter((b) => b.featured).slice(0, 5);
  }, [db.books, db.branding.featuredBookIds]);

  const popular = useMemo(
    () => [...db.books].filter((b) => b.status !== 'draft').sort((a, b) => b.readers - a.readers).slice(0, 10),
    [db.books],
  );
  const recent = useMemo(
    () =>
      [...db.books]
        .filter((b) => b.status !== 'draft')
        .sort((a, b) => +new Date(b.updatedAt) - +new Date(a.updatedAt))
        .slice(0, 10),
    [db.books],
  );
  const betaBooks = useMemo(() => db.books.filter((b) => b.betaMode).slice(0, 4), [db.books]);
  const featuredCommunities = useMemo(() => {
    const ids = db.branding.featuredCommunityIds;
    const list = ids.map((id) => db.communities.find((c) => c.id === id)).filter(Boolean) as typeof db.communities;
    return list.length ? list : db.communities.filter((c) => c.featured);
  }, [db.communities, db.branding.featuredCommunityIds]);

  const reading = useMemo(() => {
    if (!currentUser) return [];
    const shelf = db.libraries[currentUser.uid] ?? {};
    return Object.values(shelf)
      .filter((i) => i.status === 'reading' || i.status === 'favorite')
      .map((i) => ({ item: i, book: db.books.find((b) => b.id === i.bookId) }))
      .filter((x) => x.book)
      .sort((a, b) => +new Date(b.item.updatedAt) - +new Date(a.item.updatedAt))
      .slice(0, 4);
  }, [currentUser, db.libraries, db.books]);

  const ranking = useMemo(
    () => [...db.users].filter((u) => !u.banned).sort((a, b) => b.xp - a.xp).slice(0, 5),
    [db.users],
  );

  const lvl = currentUser ? levelFromXp(currentUser.xp) : null;

  return (
    <div className="mx-auto max-w-7xl px-4 pb-10 pt-4 sm:px-6">
      {/* Hero contextual */}
      <section className="mb-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">
              {greeting()}, {currentUser?.displayName.split(' ')[0] ?? 'leitor'}
            </p>
            <h1 className="mt-1 text-[24px] font-bold leading-tight tracking-tight text-chalk sm:text-[30px]">
              {db.branding.tagline}
            </h1>
          </div>
          {currentUser ? (
            <button
              type="button"
              onClick={() => navigate('/conquistas')}
              className="liquid-card flex items-center gap-2.5 px-3 py-2 transition-colors hover:border-hot-500/30"
            >
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-hot-500/15 text-[13px] font-bold text-hot-300">
                {lvl?.level}
              </span>
              <div className="text-left">
                <p className="text-[11px] font-semibold text-chalk">{lvl?.levelLabel}</p>
                <div className="mt-1 w-24">
                  <Progress value={lvl?.progress ?? 0} />
                </div>
              </div>
              <Sparkles size={14} className="text-hot-400" />
            </button>
          ) : (
            <div className="flex gap-2">
              <button type="button" onClick={() => navigate('/entrar')} className={btnPink}>
                Entrar <ArrowRight size={14} />
              </button>
              <button type="button" onClick={() => navigate('/explorar')} className={btnGhost}>
                Explorar
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Destaques da Semana — carrossel */}
      {featured.length > 0 && (
        <section className="mb-8">
          <FeatureCarousel books={featured} onOpen={(id) => navigate(`/obra/${id}`)} onOpenProfile={onOpenProfile} />
        </section>
      )}

      {/* Continuar lendo */}
      {reading.length > 0 && (
        <section className="mb-8">
          <SectionHeader
            eyebrow="Sua estante"
            title="Continuar lendo"
            action="Biblioteca"
            onAction={() => navigate('/biblioteca')}
          />
          <div className="grid gap-2.5 sm:grid-cols-2">
            {reading.map(({ book, item }) => {
              const total = book!.chapters.length || 1;
              const p = item.progress || Math.round(((item.lastChapterId ? book!.chapters.findIndex((c) => c.id === item.lastChapterId) + 1 : 0) / total) * 100);
              const chapter = book!.chapters.find((c) => c.id === item.lastChapterId) ?? book!.chapters[0];
              return (
                <div key={book!.id} className="liquid-card liquid-card-hover flex items-center gap-3 p-2.5">
                  <img src={book!.cover} alt="" className="h-[86px] w-[60px] shrink-0 rounded-lg object-cover" />
                  <div className="min-w-0 flex-1">
                    <button
                      type="button"
                      onClick={() => navigate(`/obra/${book!.id}`)}
                      className="block w-full truncate text-left text-[12.5px] font-semibold text-chalk hover:text-hot-300"
                    >
                      {book!.title}
                    </button>
                    <p className="mt-0.5 truncate text-[10.5px] text-faint">
                      {chapter ? `Cap. ${chapter.number} · ${chapter.title}` : 'Ainda não iniciado'}
                    </p>
                    <div className="mt-1.5 flex items-center gap-2">
                      <Progress value={p} className="flex-1" />
                      <span className="shrink-0 text-[10px] tabular-nums text-mute">{p}%</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigate(chapter ? `/ler/${book!.id}/${chapter.id}` : `/ler/${book!.id}`)}
                      className="mt-2 inline-flex items-center gap-1 rounded-lg bg-hot-500/15 px-2.5 py-1 text-[10.5px] font-semibold text-hot-300 transition-colors hover:bg-hot-500/25"
                    >
                      <Play size={10} /> Retomar leitura
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Populares */}
      <section className="mb-8">
        <SectionHeader eyebrow="Mais lidas" title="Obras populares" action="Ver tudo" onAction={() => navigate('/explorar')} />
        <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4 lg:grid-cols-6">
          {popular.slice(0, 6).map((b) => (
            <BookCard key={b.id} book={b} onOpen={() => navigate(`/obra/${b.id}`)} />
          ))}
        </div>
      </section>

      {/* Lançamentos */}
      <section className="mb-8">
        <SectionHeader eyebrow="Recém-chegadas" title="Lançamentos recentes" action="Explorar" onAction={() => navigate('/explorar')} />
        <div className="no-scrollbar flex gap-2.5 overflow-x-auto pb-1">
          {recent.map((b) => (
            <BookCard key={b.id} book={b} onOpen={() => navigate(`/obra/${b.id}`)} variant="carousel" />
          ))}
        </div>
      </section>

      {/* Beta */}
      {betaBooks.length > 0 && (
        <section className="mb-8">
          <SectionHeader eyebrow="Antes de todo mundo" title="Leitura Beta aberta" />
          <div className="grid gap-2.5 sm:grid-cols-2">
            {betaBooks.map((b) => {
              const approved = db.betaApplications.filter((a) => a.bookId === b.id && a.status === 'approved').length;
              return (
                <div key={b.id} className="liquid-card liquid-card-hover p-3">
                  <div className="flex gap-3">
                    <img src={b.cover} alt="" className="h-24 w-[68px] shrink-0 rounded-lg object-cover" />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => navigate(`/obra/${b.id}`)}
                          className="clamp-2 text-left text-[12.5px] font-semibold leading-tight text-chalk hover:text-hot-300"
                        >
                          {b.title}
                        </button>
                        <Badge tone="info" className="shrink-0">
                          🧪 Beta
                        </Badge>
                      </div>
                      <p className="mt-0.5 truncate text-[10.5px] text-faint">{b.authorName}</p>
                      <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-[10px] text-mute">
                        <span className="inline-flex items-center gap-1">
                          <Users size={10} /> {approved}/{b.betaSlots} vagas
                        </span>
                        {b.betaDeadline && (
                          <span className="inline-flex items-center gap-1">
                            <Clock size={10} /> até {formatDate(b.betaDeadline)}
                          </span>
                        )}
                      </div>
                      <Progress value={pct(approved, b.betaSlots || 1)} className="mt-2" />
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => navigate(`/obra/${b.id}`)}
                    className="mt-2.5 w-full rounded-lg border border-hot-500/30 bg-hot-500/[0.09] py-1.5 text-[11px] font-semibold text-hot-300 transition-colors hover:bg-hot-500/[0.16]"
                  >
                    Candidatar-se à leitura beta
                  </button>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Comunidades */}
      {featuredCommunities.length > 0 && (
        <section className="mb-8">
          <SectionHeader
            eyebrow="Gente que lê junto"
            title="Comunidades em destaque"
            action="Todas"
            onAction={() => navigate('/social/comunidades')}
          />
          <div className="no-scrollbar flex gap-2.5 overflow-x-auto pb-1">
            {featuredCommunities.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => navigate(`/social/comunidades/${c.id}`)}
                className="group relative w-[230px] shrink-0 overflow-hidden rounded-2xl border border-white/[0.08] text-left transition-all hover:-translate-y-1 hover:border-hot-500/40"
              >
                <img src={c.cover} alt="" className="h-24 w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="scrim-full absolute inset-0" />
                <div className="relative p-2.5 pt-0">
                  <p className="truncate text-[12px] font-semibold text-chalk">{c.name}</p>
                  <p className="mt-0.5 inline-flex items-center gap-1 text-[10px] text-mute">
                    <Users size={9} /> {c.members.length} membros · {c.privacy === 'public' ? 'pública' : 'privada'}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Ranking preview */}
      <section className="mb-8">
        <SectionHeader eyebrow="Semana atual" title="Ranking de leitores" action="Ranking completo" onAction={() => navigate('/ranking')} />
        <div className="liquid-card divide-y divide-white/[0.05] overflow-hidden">
          {ranking.map((u, i) => {
            const l = levelFromXp(u.xp);
            return (
              <div key={u.uid} className="flex items-center gap-2.5 px-3 py-2.5">
                <span
                  className={cx(
                    'grid h-6 w-6 shrink-0 place-items-center rounded-lg text-[10.5px] font-bold',
                    i === 0 ? 'bg-hot-500 text-[#1a1a1a]' : i < 3 ? 'bg-hot-500/18 text-hot-300' : 'bg-white/[0.06] text-faint',
                  )}
                >
                  {i + 1}
                </span>
                <button type="button" onClick={() => onOpenProfile(u.uid)} className="flex min-w-0 flex-1 items-center gap-2.5 text-left">
                  <img src={u.photoURL} alt="" className="h-7 w-7 rounded-full object-cover" />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[12px] font-medium text-chalk">{u.displayName}</span>
                    <span className="block truncate text-[10px] text-faint">
                      {l.levelLabel} · {u.achievements.length} conquistas
                    </span>
                  </span>
                </button>
                <span className="shrink-0 text-[11px] font-semibold tabular-nums text-hot-300">{compact(u.xp)} XP</span>
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA assinatura */}
      {(!currentUser || currentUser.subscription.status !== 'active') && (
        <section className="liquid-card relative overflow-hidden p-5">
          <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full bg-hot-500/15 blur-3xl" />
          <div className="relative flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <Badge tone="hot" icon={<Crown size={10} />}>
                Assinaturas
              </Badge>
              <h3 className="mt-2 text-[16px] font-bold text-chalk">Leia antes, apoie quem escreve.</h3>
              <p className="mt-1 max-w-md text-[12px] leading-relaxed text-mute">
                Leitor por R$ 4,90/mês: capítulos antecipados, obras beta e gamificação completa. Escritor por R$ 13,49/mês: selo verificado e 2 impulsionamentos.
              </p>
            </div>
            <button type="button" onClick={() => navigate('/assinaturas')} className={cx(btnPink, 'shrink-0')}>
              Ver planos <ArrowRight size={14} />
            </button>
          </div>
        </section>
      )}
    </div>
  );
}

function greeting() {
  const h = new Date().getHours();
  if (h < 6) return 'Boa madrugada';
  if (h < 12) return 'Bom dia';
  if (h < 19) return 'Boa tarde';
  return 'Boa noite';
}

/* ── Carrossel de destaques com autoplay, setas, dots e swipe ──────────── */
function FeatureCarousel({
  books,
  onOpen,
  onOpenProfile,
}: {
  books: Book[];
  onOpen: (id: string) => void;
  onOpenProfile: (uid: string) => void;
}) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const touchX = useRef<number | null>(null);
  const count = books.length;

  useEffect(() => {
    if (paused || count <= 1) return;
    const t = window.setInterval(() => setIndex((i) => (i + 1) % count), 6000);
    return () => window.clearInterval(t);
  }, [count, paused, index]);

  const go = (dir: -1 | 1) => setIndex((i) => (i + dir + count) % count);
  const book = books[index];
  if (!book) return null;

  return (
    <div
      className="relative overflow-hidden rounded-3xl border border-white/[0.08] bg-ink-800"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={(e) => {
        touchX.current = e.touches[0]!.clientX;
        setPaused(true);
      }}
      onTouchEnd={(e) => {
        if (touchX.current == null) return;
        const dx = e.changedTouches[0]!.clientX - touchX.current;
        if (Math.abs(dx) > 42) go(dx < 0 ? 1 : -1);
        touchX.current = null;
        setPaused(false);
      }}
    >
      <div className="relative min-h-[248px] sm:min-h-[290px]">
        <motion.img
          key={book.id + '-bg'}
          src={book.cover}
          alt=""
          initial={{ opacity: 0, scale: 1.06 }}
          animate={{ opacity: 0.5, scale: 1 }}
          transition={{ duration: 0.85, ease: 'easeOut' }}
          className="absolute inset-0 h-full w-full object-cover blur-xl"
        />
        <div className="scrim-full absolute inset-0" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-900/95 via-ink-900/70 to-transparent" />

        <div className="relative flex h-full items-center gap-4 p-4 sm:gap-6 sm:p-6">
          <motion.button
            key={book.id + '-cover'}
            type="button"
            onClick={() => onOpen(book.id)}
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.45 }}
            className="hidden shrink-0 sm:block"
          >
            <img
              src={book.cover}
              alt={book.title}
              className="h-[188px] w-[126px] rounded-xl object-cover shadow-[0_22px_50px_-18px_rgba(0,0,0,0.95)] ring-1 ring-white/10"
            />
          </motion.button>

          <motion.div
            key={book.id + '-content'}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.06 }}
            className="min-w-0 flex-1"
          >
            <div className="mb-2 flex flex-wrap items-center gap-1.5">
              <Badge tone="hot" icon={<Flame size={9} />}>
                Destaque da semana
              </Badge>
              {book.betaMode && <Badge tone="info">Beta</Badge>}
              <Badge tone="neutral">{book.ageRating}</Badge>
            </div>
            <button type="button" onClick={() => onOpen(book.id)} className="block text-left">
              <h2 className="clamp-2 text-[21px] font-bold leading-[1.16] tracking-tight text-chalk sm:text-[27px]">
                {book.title}
              </h2>
            </button>
            <button
              type="button"
              onClick={() => onOpenProfile(book.authorId)}
              className="mt-1.5 inline-flex items-center gap-1.5 text-[11.5px] text-mute hover:text-hot-300"
            >
              <img src={book.authorPhoto} alt="" className="h-4.5 w-4.5 rounded-full object-cover" style={{ width: 18, height: 18 }} />
              {book.authorName}
            </button>
            <p className="synopsis clamp-3 mt-2 max-w-lg text-[12px] leading-relaxed text-mute/90">{book.synopsis}</p>
            <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-[10.5px] text-faint">
              <span className="inline-flex items-center gap-1">
                <Stars value={book.rating} size={10} /> {book.rating.toFixed(1)} ({book.ratingCount})
              </span>
              <span className="inline-flex items-center gap-1">
                <Users size={10} /> {compact(book.readers)} leitores
              </span>
              <span className="inline-flex items-center gap-1">
                <TrendingUp size={10} /> {compact(book.views)} views
              </span>
            </div>
            <div className="mt-3.5 flex gap-2">
              <button type="button" onClick={() => onOpen(book.id)} className={cx(btnPink, '!px-4 !py-2 !text-[12px]')}>
                Ler agora <ArrowRight size={13} />
              </button>
              <button
                type="button"
                onClick={() => onOpen(book.id)}
                className={cx(btnGhost, '!px-3.5 !py-2 !text-[12px]')}
              >
                Detalhes
              </button>
            </div>
          </motion.div>
        </div>

        {count > 1 && (
          <>
            <button
              type="button"
              onClick={() => go(-1)}
              className="absolute left-2 top-1/2 hidden -translate-y-1/2 rounded-full border border-white/15 bg-black/40 p-1.5 text-chalk backdrop-blur transition-colors hover:bg-black/70 sm:block"
              aria-label="Anterior"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              type="button"
              onClick={() => go(1)}
              className="absolute right-2 top-1/2 hidden -translate-y-1/2 rounded-full border border-white/15 bg-black/40 p-1.5 text-chalk backdrop-blur transition-colors hover:bg-black/70 sm:block"
              aria-label="Próximo"
            >
              <ChevronRight size={16} />
            </button>
          </>
        )}
      </div>

      {count > 1 && (
        <div className="flex items-center justify-center gap-1.5 border-t border-white/[0.06] bg-ink-900/60 py-2.5">
          {books.map((b, i) => (
            <button
              key={b.id}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Ir para ${b.title}`}
              className={cx(
                'h-1.5 rounded-full transition-all',
                i === index ? 'w-6 bg-hot-500' : 'w-1.5 bg-white/20 hover:bg-white/40',
              )}
            />
          ))}
        </div>
      )}
    </div>
  );
}
