import { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  Bookmark,
  BookOpen,
  Check,
  ChevronRight,
  Clock,
  Eye,
  Flag,
  Heart,
  Lock,
  Play,
  Send,
  Sparkles,
  TrendingUp,
  Users,
} from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Avatar, Badge, EmptyState, Modal, Progress, Stars, btnGhost, btnPink, inputCls } from '../components/ui';
import { BetaApplyModal } from '../components/Modals';
import { compact, cx, formatDate, pct, timeAgo } from '../lib/utils';
import { levelFromXp } from '../lib/xp';

export default function BookDetailsView({ onOpenProfile }: { onOpenProfile: (uid: string) => void }) {
  const { bookId } = useParams<{ bookId: string }>();
  const { db, currentUser, setLibrary, toggleFavoritePost, addReview, submitBetaFeedback } = useStore();
  const navigate = useNavigate();
  const [betaOpen, setBetaOpen] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [reviewText, setReviewText] = useState('');
  const [feedbackFor, setFeedbackFor] = useState<string | null>(null);
  const [feedbackText, setFeedbackText] = useState('');

  const book = db.books.find((b) => b.id === bookId);
  const shelf = currentUser ? db.libraries[currentUser.uid]?.[bookId ?? ''] : undefined;
  const myApplication = currentUser
    ? db.betaApplications.find((a) => a.bookId === bookId && a.userId === currentUser.uid)
    : undefined;
  const approvedBeta = myApplication?.status === 'approved';
  const hasPlan = currentUser?.subscription.status === 'active';
  const isAuthor = currentUser?.uid === book?.authorId;

  const stats = useMemo(() => {
    if (!book) return null;
    const published = book.chapters.filter((c) => c.status === 'published');
    return {
      published,
      words: published.reduce((a, c) => a + c.content.split(/\s+/).length, 0),
      inLibrary: Object.values(db.libraries).filter((s) => s[book.id]).length,
    };
  }, [book, db.libraries]);

  if (!book || !stats) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-20">
        <EmptyState
          title="Obra não encontrada"
          body="Ela pode ter sido removida pelo autor ou nunca existiu."
          action={
            <button type="button" onClick={() => navigate('/explorar')} className={btnPink}>
              Explorar o catálogo
            </button>
          }
        />
      </div>
    );
  }

  const canReadChapter = (chapterId: string, earlyAccess: boolean) => {
    if (!earlyAccess) return true;
    if (isAuthor) return true;
    if (approvedBeta) return true;
    return Boolean(hasPlan);
  };

  const startReading = () => {
    const first = stats.published[0];
    if (first) navigate(`/ler/${book.id}/${first.id}`);
    else navigate(`/ler/${book.id}`);
  };

  const myRating = book.reviews.find((r) => r.userId === currentUser?.uid);

  return (
    <div className="pb-10">
      {/* Hero */}
      <div className="relative overflow-hidden border-b border-white/[0.06]">
        <img src={book.cover} alt="" className="absolute inset-0 h-full w-full scale-110 object-cover opacity-25 blur-2xl" />
        <div className="absolute inset-0 bg-gradient-to-b from-ink-850/70 via-ink-850/90 to-ink-850" />
        <div className="relative mx-auto max-w-5xl px-4 py-5 sm:px-6">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="mb-4 inline-flex items-center gap-1 text-[11.5px] text-mute transition-colors hover:text-chalk"
          >
            <ArrowLeft size={13} /> Voltar
          </button>

          <div className="flex flex-col gap-4 sm:flex-row sm:gap-6">
            <div className="relative mx-auto shrink-0 sm:mx-0">
              <img
                src={book.cover}
                alt={book.title}
                className="h-[248px] w-[166px] rounded-xl object-cover shadow-[0_24px_60px_-20px_rgba(0,0,0,0.95)] ring-1 ring-white/10"
              />
              {book.boostedUntil && new Date(book.boostedUntil) > new Date() && (
                <span className="absolute -left-2 -top-2 inline-flex items-center gap-1 rounded-full bg-hot-500 px-2 py-0.5 text-[9.5px] font-bold text-[#1a1a1a]">
                  <TrendingUp size={9} /> BOOST
                </span>
              )}
            </div>

            <div className="min-w-0 flex-1 text-center sm:text-left">
              <div className="mb-2 flex flex-wrap justify-center gap-1.5 sm:justify-start">
                <Badge tone="neutral">{book.ageRating}</Badge>
                {book.status === 'completed' && <Badge tone="ok">Completa</Badge>}
                {book.betaMode && <Badge tone="info">🧪 Leitura Beta</Badge>}
                {book.genres.slice(0, 3).map((g) => (
                  <Badge key={g} tone="hot">
                    {g}
                  </Badge>
                ))}
              </div>

              <h1 className="text-[24px] font-bold leading-tight tracking-tight text-chalk sm:text-[30px]">
                {book.title}
              </h1>

              <button
                type="button"
                onClick={() => onOpenProfile(book.authorId)}
                className="mt-2 inline-flex items-center gap-2 text-[12px] text-mute transition-colors hover:text-hot-300"
              >
                <Avatar src={book.authorPhoto} name={book.authorName} size={22} />
                {book.authorName}
                {db.users.find((u) => u.uid === book.authorId)?.badges.includes('escritor-verificado') && (
                  <Badge tone="info" className="!px-1.5 !py-0 !text-[9px]">
                    ✓ verificado
                  </Badge>
                )}
              </button>

              <div className="mt-3 flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5 text-[11px] text-faint sm:justify-start">
                <span className="inline-flex items-center gap-1">
                  <Stars value={book.rating} size={11} />
                  <strong className="font-semibold text-chalk">{book.rating.toFixed(1)}</strong>({book.ratingCount})
                </span>
                <span className="inline-flex items-center gap-1">
                  <Users size={11} /> {compact(book.readers)} leitores
                </span>
                <span className="inline-flex items-center gap-1">
                  <Eye size={11} /> {compact(book.views)}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Heart size={11} /> {compact(book.likes)}
                </span>
                <span className="inline-flex items-center gap-1">
                  <BookOpen size={11} /> {stats.published.length} capítulos
                </span>
              </div>

              <div className="mt-4 flex flex-wrap justify-center gap-2 sm:justify-start">
                <button type="button" onClick={startReading} className={cx(btnPink, '!px-5')}>
                  <Play size={14} /> {shelf?.progress ? 'Continuar leitura' : 'Começar a ler'}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (!currentUser) {
                      navigate('/entrar');
                      return;
                    }
                    setLibrary(book.id, { status: shelf?.status === 'saved' ? 'reading' : 'saved' });
                  }}
                  className={cx(btnGhost, shelf?.status === 'saved' && '!border-hot-500/50 !text-hot-300')}
                >
                  <Bookmark size={14} className={shelf?.status === 'saved' ? 'fill-hot-500' : ''} />
                  {shelf?.status === 'saved' ? 'Salvo' : 'Salvar'}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (!currentUser) {
                      navigate('/entrar');
                      return;
                    }
                    setLibrary(book.id, { status: shelf?.status === 'favorite' ? 'reading' : 'favorite' });
                  }}
                  className={cx(btnGhost, shelf?.status === 'favorite' && '!border-hot-500/50 !text-hot-300')}
                >
                  <Heart size={14} className={shelf?.status === 'favorite' ? 'fill-hot-500 text-hot-500' : ''} />
                  {shelf?.status === 'favorite' ? 'Favorito' : 'Favoritar'}
                </button>

                {book.betaMode && !isAuthor && (
                  <button type="button" onClick={() => setBetaOpen(true)} className={cx(btnGhost, '!border-[#60a5fa]/40 !text-[#bfdbfe]')}>
                    🧪 {myApplication ? 'Ver candidatura' : 'Ser leitor beta'}
                  </button>
                )}
              </div>

              {shelf && shelf.progress > 0 && (
                <div className="mt-4 rounded-xl border border-white/[0.07] bg-ink-900/60 p-2.5 text-left">
                  <div className="mb-1 flex items-center justify-between text-[10.5px]">
                    <span className="text-mute">Seu progresso</span>
                    <span className="tabular-nums text-hot-300">{shelf.progress}%</span>
                  </div>
                  <Progress value={shelf.progress} />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto grid max-w-5xl gap-5 px-4 pt-5 sm:px-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-5">
          {/* Sinopse */}
          <section className="liquid-card p-4">
            <h2 className="mb-2 text-[13px] font-semibold uppercase tracking-[0.14em] text-hot-400">Sinopse</h2>
            <p className="synopsis text-[13px] leading-relaxed text-mute">{book.synopsis}</p>
            <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5 border-t border-white/[0.06] pt-3 text-[10.5px] text-faint">
              <span>{stats.words.toLocaleString('pt-BR')} palavras</span>
              <span>{stats.inLibrary} na biblioteca de leitores</span>
              <span>Atualizada em {formatDate(book.updatedAt)}</span>
              <button
                type="button"
                onClick={() => navigate(`/perfil/${book.authorId}`)}
                className="ml-auto inline-flex items-center gap-1 text-mute hover:text-hot-300"
              >
                <Flag size={10} /> Denunciar obra
              </button>
            </div>
          </section>

          {/* Capítulos */}
          <section className="liquid-card overflow-hidden">
            <div className="flex items-center justify-between border-b border-white/[0.06] px-4 py-3">
              <h2 className="text-[13px] font-semibold text-chalk">Capítulos</h2>
              <span className="text-[10.5px] text-faint">{stats.published.length} publicados</span>
            </div>
            {stats.published.length === 0 ? (
              <p className="px-4 py-8 text-center text-[12px] text-faint">
                O autor ainda não publicou capítulos desta obra.
              </p>
            ) : (
              <ul className="divide-y divide-white/[0.05]">
                {stats.published.map((c) => {
                  const unlocked = canReadChapter(c.id, c.earlyAccess);
                  return (
                    <li key={c.id}>
                      <button
                        type="button"
                        onClick={() =>
                          unlocked
                            ? navigate(`/ler/${book.id}/${c.id}`)
                            : setBetaOpen(true)
                        }
                        className="flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-white/[0.035]"
                      >
                        <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-white/[0.06] text-[11px] font-semibold text-mute">
                          {c.number}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="flex items-center gap-1.5">
                            <span className="truncate text-[12.5px] font-medium text-chalk">{c.title}</span>
                            {c.earlyAccess && (
                              <Badge tone={unlocked ? 'ok' : 'warn'} className="!px-1.5 !py-0 !text-[9px]">
                                {unlocked ? 'liberado' : 'antecipado'}
                              </Badge>
                            )}
                          </span>
                          <span className="mt-0.5 flex items-center gap-2 text-[10px] text-faint">
                            {formatDate(c.createdAt)} · {c.reads} leituras · {c.comments.length} comentários
                          </span>
                        </span>
                        {unlocked ? (
                          <ChevronRight size={14} className="shrink-0 text-faint" />
                        ) : (
                          <Lock size={13} className="shrink-0 text-[#fcd34d]" />
                        )}
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>

          {/* Avaliações */}
          <section className="liquid-card p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-[13px] font-semibold text-chalk">Avaliações</h2>
              <button
                type="button"
                onClick={() => {
                  if (!currentUser) {
                    navigate('/entrar');
                    return;
                  }
                  setRating(myRating?.rating ?? 5);
                  setReviewText(myRating?.text ?? '');
                  setReviewOpen(true);
                }}
                className="text-[11px] font-medium text-hot-300 hover:text-hot-400"
              >
                {myRating ? 'Editar avaliação' : 'Avaliar'}
              </button>
            </div>

            {book.reviews.length === 0 ? (
              <p className="rounded-xl border border-dashed border-white/10 px-3 py-6 text-center text-[11.5px] text-faint">
                Ainda sem avaliações. Seja o primeiro a comentar — sem spoilers.
              </p>
            ) : (
              <div className="space-y-2.5">
                {book.reviews.map((r) => (
                  <div key={r.id} className="rounded-xl border border-white/[0.06] bg-ink-900/50 p-3">
                    <div className="flex items-center gap-2">
                      <button type="button" onClick={() => onOpenProfile(r.userId)}>
                        <Avatar src={r.userPhoto} name={r.userName} size={26} />
                      </button>
                      <div className="min-w-0 flex-1">
                        <button
                          type="button"
                          onClick={() => onOpenProfile(r.userId)}
                          className="block truncate text-[12px] font-semibold text-chalk hover:text-hot-300"
                        >
                          {r.userName}
                        </button>
                        <span className="text-[10px] text-faint">{timeAgo(r.createdAt)} atrás</span>
                      </div>
                      <Stars value={r.rating} size={11} />
                    </div>
                    <p className="mt-2 text-[12px] leading-relaxed text-mute">{r.text}</p>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        {/* Sidebar */}
        <aside className="space-y-4">
          {book.betaMode && (
            <div className="liquid-card p-4">
              <Badge tone="info">🧪 Leitura Beta</Badge>
              <p className="mt-2 text-[12px] font-semibold text-chalk">
                {db.betaApplications.filter((a) => a.bookId === book.id && a.status === 'approved').length}/
                {book.betaSlots} vagas preenchidas
              </p>
              <p className="mt-1 text-[11px] leading-relaxed text-mute">{book.betaRules}</p>
              {book.betaDeadline && (
                <p className="mt-2 inline-flex items-center gap-1 text-[10.5px] text-faint">
                  <Clock size={10} /> Prazo: {formatDate(book.betaDeadline)}
                </p>
              )}

              {myApplication?.status === 'approved' && myApplication.feedbackStatus !== 'submitted' && (
                <button
                  type="button"
                  onClick={() => setFeedbackFor(myApplication.id)}
                  className={cx(btnPink, 'mt-3 w-full !py-2 !text-[12px]')}
                >
                  <Send size={12} /> Enviar feedback
                </button>
              )}
              {myApplication?.feedbackStatus === 'submitted' && (
                <p className="mt-3 rounded-lg border border-[#4ade80]/30 bg-[#4ade80]/10 px-2.5 py-1.5 text-[10.5px] text-[#86efac]">
                  ✓ Feedback enviado ao autor
                </p>
              )}
            </div>
          )}

          <div className="liquid-card p-4">
            <h3 className="mb-2.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-faint">Sobre o autor</h3>
            {(() => {
              const author = db.users.find((u) => u.uid === book.authorId);
              if (!author) return null;
              const lvl = levelFromXp(author.xp);
              const works = db.books.filter((b) => b.authorId === author.uid);
              return (
                <>
                  <button type="button" onClick={() => onOpenProfile(author.uid)} className="flex w-full items-center gap-2.5 text-left">
                    <Avatar src={author.photoURL} name={author.displayName} size={40} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12.5px] font-semibold text-chalk">{author.displayName}</p>
                      <p className="truncate text-[10.5px] text-faint">
                        {lvl.levelLabel} · {works.length} obras
                      </p>
                    </div>
                    <Sparkles size={13} className="text-hot-400" />
                  </button>
                  <p className="mt-2 clamp-3 text-[11px] leading-relaxed text-mute">{author.bio}</p>
                  <div className="mt-2.5 flex flex-wrap gap-1">
                    {author.badges.slice(0, 3).map((b) => (
                      <Badge key={b} tone={b === 'escritor-verificado' ? 'info' : 'hot'} className="!text-[9.5px]">
                        {b === 'escritor-verificado' ? '✅' : b === 'leitor-experiente' ? '🎓' : '👑'} {b.replace(/-/g, ' ')}
                      </Badge>
                    ))}
                  </div>
                </>
              );
            })()}
          </div>

          <div className="liquid-card p-4">
            <h3 className="mb-2.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-faint">Você também pode gostar</h3>
            <div className="space-y-2">
              {db.books
                .filter((b) => b.id !== book.id && b.genres.some((g) => book.genres.includes(g)))
                .slice(0, 3)
                .map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => navigate(`/obra/${b.id}`)}
                    className="flex w-full items-center gap-2 text-left"
                  >
                    <img src={b.cover} alt="" className="h-12 w-8 shrink-0 rounded object-cover" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[11.5px] font-medium text-chalk">{b.title}</span>
                      <span className="block truncate text-[10px] text-faint">{b.authorName}</span>
                    </span>
                  </button>
                ))}
              {db.books.filter((b) => b.id !== book.id && b.genres.some((g) => book.genres.includes(g))).length === 0 && (
                <p className="text-[11px] text-faint">Sem recomendações ainda.</p>
              )}
            </div>
          </div>
        </aside>
      </div>

      <BetaApplyModal book={betaOpen ? book : null} onClose={() => setBetaOpen(false)} />

      <Modal
        open={reviewOpen}
        onClose={() => setReviewOpen(false)}
        title="Avaliar obra"
        subtitle={book.title}
        footer={
          <div className="flex gap-2">
            <button type="button" onClick={() => setReviewOpen(false)} className={cx(btnGhost, 'flex-1')}>
              Cancelar
            </button>
            <button
              type="button"
              className={cx(btnPink, 'flex-1')}
              onClick={() => {
                addReview(book.id, rating, reviewText.trim() || 'Sem comentário.');
                setReviewOpen(false);
              }}
            >
              Publicar
            </button>
          </div>
        }
      >
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <span className="text-[12px] text-mute">Sua nota:</span>
            <Stars value={rating} size={20} onChange={setRating} />
            <span className="text-[12px] font-semibold text-hot-300">{rating}/5</span>
          </div>
          <textarea
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            rows={4}
            placeholder="O que funcionou? O que não funcionou? Sem spoilers, por favor."
            className={cx(inputCls, 'resize-none')}
          />
          <p className="text-[10.5px] text-faint">Sua avaliação fica pública no perfil e na página da obra.</p>
        </div>
      </Modal>

      <Modal
        open={Boolean(feedbackFor)}
        onClose={() => setFeedbackFor(null)}
        title="Feedback de leitura beta"
        subtitle={book.title}
        footer={
          <button
            type="button"
            className={cx(btnPink, 'w-full')}
            disabled={feedbackText.trim().length < 40}
            onClick={() => {
              if (feedbackFor) submitBetaFeedback(feedbackFor, feedbackText.trim());
              setFeedbackText('');
              setFeedbackFor(null);
            }}
          >
            Enviar ao autor
          </button>
        }
      >
        <textarea
          value={feedbackText}
          onChange={(e) => setFeedbackText(e.target.value)}
          rows={6}
          placeholder="Feedback honesto e acionável. Mínimo 40 caracteres. Diga o que travou sua leitura e o que te prendeu."
          className={cx(inputCls, 'resize-none')}
        />
        <p className="mt-1 text-right text-[10px] text-faint">{feedbackText.trim().length}/40</p>
      </Modal>
    </div>
  );
}
