import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Award, Check, Crown, Lock, Sparkles, Tag } from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Badge, EmptyState, Pills, Progress, btnPink } from '../components/ui';
import { ACHIEVEMENTS, TITLES, levelFromXp, MAX_LEVEL, XP_REWARDS } from '../lib/xp';
import { compact, cx } from '../lib/utils';

export default function AchievementsView() {
  const { db, currentUser, equipTitle, grantAchievement } = useStore();
  const navigate = useNavigate();
  const [tab, setTab] = useState<'conquistas' | 'titulos'>('conquistas');
  const [filter, setFilter] = useState<'todas' | 'leitura' | 'escrita' | 'comunidade' | 'assinatura'>('todas');

  const lvl = currentUser ? levelFromXp(currentUser.xp) : null;

  const visible = useMemo(
    () => ACHIEVEMENTS.filter((a) => filter === 'todas' || a.category === filter),
    [filter],
  );

  if (!currentUser) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20">
        <EmptyState
          icon={<Award size={30} />}
          title="Conquistas e títulos"
          body="Entre para desbloquear conquistas por leitura, escrita e participação em comunidades, equipar títulos e acompanhar seu nível."
          action={
            <button type="button" onClick={() => navigate('/entrar')} className={btnPink}>
              Entrar
            </button>
          }
        />
      </div>
    );
  }

  const unlocked = currentUser.achievements;
  const totalXpFromAchievements = ACHIEVEMENTS.filter((a) => unlocked.includes(a.id)).reduce((a, b) => a + b.xp, 0);

  return (
    <div className="mx-auto max-w-3xl px-4 pb-10 pt-5 sm:px-6">
      <div className="mb-4">
        <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">Gamificação</p>
        <h1 className="mt-1 text-[23px] font-bold tracking-tight text-chalk">Conquistas & Títulos</h1>
        <p className="mt-1 text-[12px] text-mute">
          {unlocked.length}/{ACHIEVEMENTS.length} conquistas · {compact(totalXpFromAchievements)} XP conquistados ·{' '}
          {compact(currentUser.xp)} XP totais
        </p>
      </div>

      {lvl && (
        <div className="liquid-card mb-4 p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-faint">Nível atual</p>
              <p className="mt-0.5 text-[22px] font-bold leading-none text-chalk">{lvl.level}</p>
              <p className="mt-1 text-[10.5px] text-mute">
                {lvl.isMax ? `Nível máximo • Prestígio ${lvl.prestige}` : `${lvl.xpForLevel - lvl.xpIntoLevel} XP para o nível ${lvl.level + 1}`}
              </p>
            </div>
            <div className="text-right">
              <Badge tone="hot" icon={<Sparkles size={9} />}>
                {lvl.levelLabel}
              </Badge>
              {lvl.prestige > 0 && (
                <p className="mt-1 text-[9.5px] text-faint">Ciclo {lvl.prestige} de 3</p>
              )}
            </div>
          </div>
          <div className="mt-3">
            <Progress value={lvl.progress} />
            <div className="mt-1 flex justify-between text-[9.5px] text-faint">
              <span className="tabular-nums">{lvl.xpIntoLevel} XP</span>
              <span className="tabular-nums">{lvl.xpForLevel} XP</span>
            </div>
          </div>
          <p className="mt-2 text-[10px] leading-relaxed text-faint">
            Curva quadrática progressiva até o nível {MAX_LEVEL}. Ao completar, o ciclo reinicia com prestígio — mantendo títulos e conquistas.
          </p>
        </div>
      )}

      {currentUser.subscription.status !== 'active' && (
        <div className="liquid-card mb-4 flex flex-wrap items-center justify-between gap-2.5 border-hot-500/25 p-3">
          <p className="text-[11.5px] leading-relaxed text-mute">
            A gamificação completa (XP, ranking e conquistas de assinante) é liberada pela <strong className="text-hot-300">Assinatura Leitor</strong>.
          </p>
          <button type="button" onClick={() => navigate('/assinaturas')} className={cx(btnPink, '!py-1.5 !text-[11.5px]')}>
            Ver planos
          </button>
        </div>
      )}

      <Pills
        className="mb-3"
        items={[
          { id: 'conquistas', label: 'Conquistas', count: unlocked.length },
          { id: 'titulos', label: 'Títulos', count: currentUser.titles.length },
        ]}
        value={tab}
        onChange={(v) => setTab(v as typeof tab)}
      />

      {tab === 'conquistas' ? (
        <>
          <div className="mb-3 flex flex-wrap gap-1.5">
            {(['todas', 'leitura', 'escrita', 'comunidade', 'assinatura'] as const).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFilter(f)}
                className={cx(
                  'rounded-full border px-2.5 py-1 text-[10.5px] capitalize transition-colors',
                  filter === f ? 'border-hot-500 bg-hot-500/12 text-hot-300' : 'border-white/10 text-mute hover:text-chalk',
                )}
              >
                {f}
              </button>
            ))}
          </div>

          <div className="grid gap-2 sm:grid-cols-2">
            {visible.map((a) => {
              const has = unlocked.includes(a.id);
              return (
                <div
                  key={a.id}
                  className={cx(
                    'liquid-card flex items-start gap-2.5 p-3',
                    has ? 'border-hot-500/25' : 'opacity-80',
                  )}
                >
                  <span
                    className={cx(
                      'grid h-10 w-10 shrink-0 place-items-center rounded-xl text-[18px]',
                      has ? 'bg-hot-500/15' : 'bg-white/[0.05] grayscale',
                    )}
                  >
                    {has ? a.icon : <Lock size={14} className="text-faint" />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <p className={cx('truncate text-[12px] font-semibold', has ? 'text-chalk' : 'text-mute')}>{a.name}</p>
                      {has && <Check size={11} className="shrink-0 text-[#86efac]" />}
                    </div>
                    <p className="mt-0.5 text-[10.5px] leading-snug text-faint">{a.description}</p>
                    <div className="mt-1 flex items-center gap-1.5">
                      <Badge tone={has ? 'hot' : 'neutral'} className="!text-[9px]">
                        +{a.xp} XP
                      </Badge>
                      <span className="text-[9px] uppercase tracking-wide text-faint">{a.category}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="liquid-card mt-4 p-3.5">
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-faint">Como progredir</p>
            <div className="grid grid-cols-2 gap-1.5 text-[10.5px] text-mute sm:grid-cols-3">
              {[
                `Leia capítulos (+${XP_REWARDS.chapterComplete} XP cada)`,
                `Comente (+${XP_REWARDS.chapterComment} XP)`,
                `Avalie obras (+${XP_REWARDS.reviewBook} XP)`,
                `Publique no Flux (+${XP_REWARDS.createPost} XP)`,
                `Crie comunidades (+${XP_REWARDS.createCommunity} XP)`,
                `Envie feedback beta (+${XP_REWARDS.betaFeedback} XP)`,
              ].map((t) => (
                <p key={t} className="rounded-lg border border-white/[0.06] bg-ink-900/50 px-2 py-1.5 leading-snug">
                  {t}
                </p>
              ))}
            </div>
          </div>
        </>
      ) : (
        <div className="space-y-2">
          {TITLES.map((t) => {
            const owned = currentUser.titles.includes(t.id);
            const equipped = currentUser.equippedTitle === t.id;
            const levelOk = !t.minLevel || (lvl ? lvl.level >= t.minLevel || lvl.prestige > 0 : false);
            return (
              <div key={t.id} className={cx('liquid-card flex items-center gap-2.5 p-3', equipped && 'border-hot-500/40')}>
                <span
                  className={cx(
                    'grid h-9 w-9 shrink-0 place-items-center rounded-xl',
                    owned ? 'bg-hot-500/15 text-hot-300' : 'bg-white/[0.05] text-faint',
                  )}
                >
                  <Tag size={15} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className={cx('truncate text-[12px] font-semibold', owned ? 'text-chalk' : 'text-mute')}>{t.name}</p>
                  <p className="text-[10px] text-faint">{t.requirement}</p>
                </div>
                {equipped ? (
                  <Badge tone="hot" icon={<Crown size={9} />}>
                    equipado
                  </Badge>
                ) : owned ? (
                  <button
                    type="button"
                    onClick={() => equipTitle(t.id)}
                    className="rounded-lg border border-white/10 px-2.5 py-1 text-[10.5px] text-mute hover:border-hot-500/40 hover:text-hot-300"
                  >
                    Equipar
                  </button>
                ) : levelOk && t.minLevel ? (
                  <button
                    type="button"
                    onClick={() => grantAchievement('primeira-pagina')}
                    className="rounded-lg bg-hot-500/15 px-2.5 py-1 text-[10.5px] text-hot-300"
                  >
                    Resgatar
                  </button>
                ) : (
                  <Badge tone="neutral" icon={<Lock size={8} />}>
                    bloqueado
                  </Badge>
                )}
              </div>
            );
          })}
          {currentUser.equippedTitle && (
            <button
              type="button"
              onClick={() => equipTitle(null)}
              className="mt-1 w-full rounded-xl border border-white/10 py-2 text-[11px] text-mute hover:text-chalk"
            >
              Remover título do perfil
            </button>
          )}
          <p className="mt-2 text-[10px] leading-relaxed text-faint">
            Títulos aparecem no seu perfil público e no dropdown da conta. Assinantes Escritor recebem o título “Autor Verificado”.
          </p>
        </div>
      )}

      <div className="liquid-card mt-4 flex items-center justify-between gap-3 p-3.5">
        <div>
          <p className="text-[12px] font-semibold text-chalk">Badges do perfil</p>
          <p className="mt-0.5 text-[10.5px] text-mute">
            Leitor Experiente (assinatura), Escritor Verificado (plano Escritor) e selo de assinatura ativa.
          </p>
        </div>
        <Badge tone="info" className="shrink-0">
          {db.users.filter((u) => u.badges.length > 0).length} usuários com badges
        </Badge>
      </div>
    </div>
  );
}
