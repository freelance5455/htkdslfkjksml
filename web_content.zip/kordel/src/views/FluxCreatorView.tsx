import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, BarChart3, Image as ImageIcon, Music2, Plus, Send, Type, Video, X, LayoutGrid } from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Badge, btnGhost, btnPink, inputCls } from '../components/ui';
import { storyArt } from '../lib/art';
import { readFileAsDataUrl, cx } from '../lib/utils';
import { uploadMedia } from '../lib/api';
import type { Post } from '../types';

const TYPES: Array<{ id: Post['type']; label: string; icon: typeof Type; hint: string }> = [
  { id: 'story', label: 'Story Canvas', icon: LayoutGrid, hint: 'Texto centralizado em tela cheia, com trilha opcional' },
  { id: 'text', label: 'Texto', icon: Type, hint: 'Fundo gerado automaticamente a partir do texto' },
  { id: 'image', label: 'Imagem', icon: ImageIcon, hint: 'Uma imagem vertical ou quadrada' },
  { id: 'carousel', label: 'Carrossel', icon: ImageIcon, hint: 'Várias imagens com navegação lateral' },
  { id: 'video', label: 'Vídeo', icon: Video, hint: 'MP4/WebM em tela cheia, com som' },
  { id: 'poll', label: 'Enquete', icon: BarChart3, hint: 'Pergunta + opções, voto único por conta' },
];

export default function FluxCreatorView() {
  const { createPost, pushToast } = useStore();
  const navigate = useNavigate();
  const [type, setType] = useState<Post['type']>('story');
  const [text, setText] = useState('');
  const [media, setMedia] = useState<string[]>([]);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [pollQuestion, setPollQuestion] = useState('');
  const [options, setOptions] = useState<string[]>(['', '']);
  const [busy, setBusy] = useState(false);

  const upload = async (file: File, folder: 'posts' | 'audios') => {
    setBusy(true);
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const res = await uploadMedia(dataUrl, folder, file.name);
      return res.url;
    } catch {
      return readFileAsDataUrl(file);
    } finally {
      setBusy(false);
    }
  };

  const cleanOptions = options.map((o) => o.trim()).filter(Boolean);
  const canPublish =
    !busy &&
    (type === 'story' || type === 'text'
      ? text.trim().length > 0
      : type === 'poll'
        ? pollQuestion.trim().length > 0 && cleanOptions.length >= 2
        : media.length > 0);

  const preview =
    type === 'story' || type === 'text'
      ? storyArt(text || 'Seu texto aparece aqui', 'Prévia')
      : media[0] ?? storyArt('Adicione mídia para ver a prévia', 'Prévia');

  return (
    <div className="mx-auto max-w-4xl px-4 pb-10 pt-5 sm:px-6">
      <button
        type="button"
        onClick={() => navigate('/social/flux')}
        className="mb-3 inline-flex items-center gap-1 text-[11.5px] text-mute hover:text-chalk"
      >
        <ArrowLeft size={13} /> Voltar ao Flux
      </button>

      <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
        <div>
          <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">Flux</p>
          <h1 className="mt-1 text-[22px] font-bold tracking-tight text-chalk">Criar Flux</h1>
          <p className="mt-1 text-[12px] text-mute">
            Formato vertical de tela cheia. Cada Flux ocupa 100dvh no feed, com transição animada ao rolar.
          </p>

          <div className="mt-4 grid grid-cols-2 gap-1.5 sm:grid-cols-3">
            {TYPES.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setType(t.id)}
                className={cx(
                  'flex flex-col items-start gap-1 rounded-xl border p-2.5 text-left transition-colors',
                  type === t.id
                    ? 'border-hot-500 bg-hot-500/[0.1]'
                    : 'border-white/[0.08] bg-ink-750 hover:border-white/20',
                )}
              >
                <t.icon size={15} className={type === t.id ? 'text-hot-400' : 'text-mute'} />
                <span className={cx('text-[11.5px] font-semibold', type === t.id ? 'text-hot-300' : 'text-chalk')}>
                  {t.label}
                </span>
                <span className="text-[9px] leading-snug text-faint">{t.hint}</span>
              </button>
            ))}
          </div>

          <div className="mt-4 space-y-3">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={type === 'story' ? 5 : 3}
              placeholder={
                type === 'story'
                  ? 'Texto do Story Canvas — frases curtas funcionam melhor em tela cheia.'
                  : 'Legenda do Flux'
              }
              className={cx(inputCls, 'resize-none', type === 'story' && 'font-literata text-[13.5px] leading-relaxed')}
            />

            {(type === 'image' || type === 'carousel' || type === 'video') && (
              <label className="flex cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-dashed border-white/15 py-4 text-[11.5px] text-mute hover:border-hot-500/40 hover:text-chalk">
                <ImageIcon size={14} />
                {busy ? 'Enviando…' : type === 'video' ? 'Selecionar vídeo' : type === 'carousel' ? 'Selecionar imagens' : 'Selecionar imagem'}
                <input
                  type="file"
                  accept={type === 'video' ? 'video/*' : 'image/*'}
                  multiple={type === 'carousel'}
                  className="hidden"
                  onChange={async (e) => {
                    const files = Array.from(e.target.files ?? []);
                    const urls: string[] = [];
                    for (const f of files) urls.push(await upload(f, 'posts'));
                    setMedia(type === 'carousel' ? urls : urls.slice(0, 1));
                  }}
                />
              </label>
            )}

            {(type === 'story' || type === 'text') && (
              <div className="rounded-xl border border-white/[0.08] bg-ink-900/60 p-2.5">
                <label className="flex cursor-pointer items-center gap-1.5 text-[11px] text-mute hover:text-chalk">
                  <Music2 size={12} /> Trilha de áudio {type === 'story' ? '' : '(opcional)'}
                  <input
                    type="file"
                    accept="audio/*"
                    className="hidden"
                    onChange={async (e) => {
                      const f = e.target.files?.[0];
                      if (f) setAudioUrl(await upload(f, 'audios'));
                    }}
                  />
                </label>
                {audioUrl && (
                  <div className="mt-1.5 flex items-center gap-1.5">
                    <audio src={audioUrl} controls className="w-full" />
                    <button type="button" onClick={() => setAudioUrl(null)} className="text-faint hover:text-[#fca5a5]" aria-label="Remover áudio">
                      <X size={12} />
                    </button>
                  </div>
                )}
              </div>
            )}

            {type === 'poll' && (
              <div className="space-y-1.5 rounded-xl border border-white/[0.08] bg-ink-900/60 p-2.5">
                <input
                  value={pollQuestion}
                  onChange={(e) => setPollQuestion(e.target.value)}
                  placeholder="Pergunta da enquete"
                  className={cx(inputCls, '!py-1.5 !text-[11.5px]')}
                />
                {options.map((o, i) => (
                  <input
                    key={i}
                    value={o}
                    onChange={(e) => setOptions((prev) => prev.map((x, j) => (j === i ? e.target.value : x)))}
                    placeholder={`Opção ${i + 1}`}
                    className={cx(inputCls, '!py-1.5 !text-[11.5px]')}
                  />
                ))}
                {options.length < 5 && (
                  <button
                    type="button"
                    onClick={() => setOptions((prev) => [...prev, ''])}
                    className="inline-flex items-center gap-1 text-[10.5px] text-hot-300"
                  >
                    <Plus size={10} /> Adicionar opção
                  </button>
                )}
              </div>
            )}

            {media.length > 0 && (
              <div className="flex gap-1.5 overflow-x-auto">
                {media.map((m, i) => (
                  <div key={`${m}-${i}`} className="relative shrink-0">
                    {type === 'video' ? <video src={m} className="h-24 rounded-lg" /> : <img src={m} alt="" className="h-24 rounded-lg object-cover" />}
                    <button
                      type="button"
                      onClick={() => setMedia(media.filter((_, j) => j !== i))}
                      className="absolute -right-1 -top-1 rounded-full bg-ink-900 p-0.5 text-[#fca5a5] ring-1 ring-white/20"
                      aria-label="Remover"
                    >
                      <X size={9} />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <button type="button" onClick={() => navigate('/social/flux')} className={cx(btnGhost, 'flex-1')}>
                Cancelar
              </button>
              <button
                type="button"
                disabled={!canPublish}
                onClick={() => {
                  const created = createPost({
                    communityId: null,
                    type,
                    text: text.trim(),
                    media,
                    audioUrl,
                    poll:
                      type === 'poll' && cleanOptions.length >= 2
                        ? {
                            question: pollQuestion.trim(),
                            options: cleanOptions.map((o, i) => ({ id: `o${i + 1}`, text: o, votes: [] })),
                          }
                        : null,
                  });
                  if (created) {
                    pushToast({ title: 'Flux publicado', body: '+25 XP', tone: 'success', link: `/social/flux?flux=${created.id}` });
                    navigate(`/social/flux?flux=${created.id}`);
                  }
                }}
                className={cx(btnPink, 'flex-1')}
              >
                <Send size={13} /> Publicar no Flux
              </button>
            </div>
          </div>
        </div>

        <aside className="lg:sticky lg:top-24 lg:self-start">
          <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-faint">Prévia 9:16</p>
          <div className="relative aspect-[9/16] w-full overflow-hidden rounded-2xl border border-white/10 bg-ink-900">
            <img src={preview} alt="" className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/25" />
            <div className="absolute inset-x-0 bottom-0 p-3">
              <Badge tone="hot" className="!text-[9px]">
                {type}
              </Badge>
              {text && <p className="mt-1.5 clamp-4 font-literata text-[12px] leading-snug text-chalk">{text}</p>}
              {audioUrl && (
                <p className="mt-1 inline-flex items-center gap-1 text-[9.5px] text-[#93c5fd]">
                  <Music2 size={9} /> com trilha
                </p>
              )}
            </div>
          </div>
          <p className="mt-2 text-[10px] leading-relaxed text-faint">
            Ao rolar, cada Flux trava na tela (scroll-snap 100dvh) com transição animada via motion.
          </p>
        </aside>
      </div>
    </div>
  );
}
