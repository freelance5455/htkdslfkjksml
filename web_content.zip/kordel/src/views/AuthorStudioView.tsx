import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BarChart3,
  BookPlus,
  Check,
  Clock,
  Eye,
  FileText,
  FlaskConical,
  MessageSquare,
  Plus,
  Rocket,
  Save,
  Star,
  Trash2,
  Upload,
  Users,
  X,
} from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Badge, EmptyState, Modal, Pills, Progress, Stars, btnGhost, btnPink, inputCls } from '../components/ui';
import { coverArt } from '../lib/art';
import { AGE_RATINGS, GENRES, type AgeRating, type Book, type Genre } from '../types';
import { readFileAsDataUrl, compact, cx, formatDate, pct } from '../lib/utils';
import { uploadMedia } from '../lib/api';

type Tab = 'obras' | 'capitulos' | 'beta' | 'estatisticas';

export default function AuthorStudioView() {
  const { db, currentUser, createBook, updateBook, deleteBook, addChapter, updateChapter, deleteChapter, decideBeta, boostBook, pushToast } = useStore();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('obras');
  const [editorBook, setEditorBook] = useState<Book | null>(null);
  const [creating, setCreating] = useState(false);
  const [chapterBookId, setChapterBookId] = useState<string | null>(null);
  const [newChapter, setNewChapter] = useState({ title: '', content: '', earlyAccess: false, status: 'published' as 'draft' | 'published' });

  const myBooks = useMemo(
    () => db.books.filter((b) => b.authorId === currentUser?.uid),
    [db.books, currentUser],
  );
  const myApps = useMemo(
    () => db.betaApplications.filter((a) => myBooks.some((b) => b.id === a.bookId)),
    [db.betaApplications, myBooks],
  );

  if (!currentUser) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20">
        <EmptyState
          icon={<BookPlus size={30} />}
          title="Estúdio do Autor"
          body="Publique obras, gerencie capítulos, conduza leituras beta e acompanhe métricas reais de leitura."
          action={
            <button type="button" onClick={() => navigate('/entrar')} className={btnPink}>
              Entrar para escrever
            </button>
          }
        />
      </div>
    );
  }

  const totalReads = myBooks.reduce((a, b) => a + b.chapters.reduce((x, c) => x + c.reads, 0), 0);
  const totalReaders = myBooks.reduce((a, b) => a + b.readers, 0);

  return (
    <div className="mx-auto max-w-5xl px-4 pb-10 pt-5 sm:px-6">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">Área do autor</p>
          <h1 className="mt-1 text-[23px] font-bold tracking-tight text-chalk">Estúdio</h1>
          <p className="mt-1 text-[12px] text-mute">
            {myBooks.length} obras · {totalReads.toLocaleString('pt-BR')} leituras · {compact(totalReaders)} leitores
          </p>
        </div>
        <button type="button" onClick={() => setCreating(true)} className={btnPink}>
          <Plus size={15} /> Nova obra
        </button>
      </div>

      <Pills
        className="mb-4 w-full sm:w-auto"
        items={[
          { id: 'obras', label: 'Obras', count: myBooks.length },
          { id: 'capitulos', label: 'Capítulos' },
          { id: 'beta', label: 'Leitores Beta', count: myApps.filter((a) => a.status === 'pending').length },
          { id: 'estatisticas', label: 'Estatísticas' },
        ]}
        value={tab}
        onChange={(v) => setTab(v as Tab)}
      />

      {tab === 'obras' && (
        myBooks.length === 0 ? (
          <EmptyState
            icon={<BookPlus size={28} />}
            title="Nenhuma obra ainda"
            body="Crie sua primeira obra, escreva o capítulo 1 e publique quando estiver pronto. Rascunhos ficam invisíveis no catálogo."
            action={
              <button type="button" onClick={() => setCreating(true)} className={btnPink}>
                Criar obra
              </button>
            }
          />
        ) : (
          <div className="space-y-2.5">
            {myBooks.map((b) => (
              <div key={b.id} className="liquid-card p-3">
                <div className="flex gap-3">
                  <img src={b.cover} alt="" className="h-[92px] w-[62px] shrink-0 rounded-lg object-cover" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => navigate(`/obra/${b.id}`)}
                        className="clamp-2 text-left text-[13px] font-semibold leading-tight text-chalk hover:text-hot-300"
                      >
                        {b.title}
                      </button>
                      <Badge tone={b.status === 'published' ? 'ok' : b.status === 'completed' ? 'info' : 'warn'} className="shrink-0">
                        {b.status === 'published' ? 'Publicada' : b.status === 'completed' ? 'Completa' : 'Rascunho'}
                      </Badge>
                    </div>
                    <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-faint">
                      <span className="inline-flex items-center gap-1">
                        <FileText size={9} /> {b.chapters.length} caps
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <Eye size={9} /> {compact(b.views)}
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <Users size={9} /> {compact(b.readers)}
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <Star size={9} /> {b.rating.toFixed(1)}
                      </span>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      <button type="button" onClick={() => setEditorBook(b)} className={cx(btnGhost, '!px-2.5 !py-1 !text-[10.5px]')}>
                        Editar obra
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setChapterBookId(b.id);
                          setNewChapter({ title: '', content: '', earlyAccess: false, status: 'published' });
                        }}
                        className={cx(btnGhost, '!px-2.5 !py-1 !text-[10.5px]')}
                      >
                        <Plus size={10} /> Capítulo
                      </button>
                      <button
                        type="button"
                        onClick={() => boostBook(b.id)}
                        className="inline-flex items-center gap-1 rounded-lg border border-hot-500/30 bg-hot-500/[0.08] px-2.5 py-1 text-[10.5px] font-medium text-hot-300 hover:bg-hot-500/15"
                      >
                        <Rocket size={10} /> Boost
                      </button>
                      {b.betaMode && (
                        <Badge tone="info" className="!text-[9px]">
                          <FlaskConical size={9} /> Beta {pct(myApps.filter((a) => a.bookId === b.id && a.status === 'approved').length, b.betaSlots || 1)}%
                        </Badge>
                      )}
                      {b.boostedUntil && new Date(b.boostedUntil) > new Date() && (
                        <Badge tone="hot" className="!text-[9px]">
                          🚀 até {formatDate(b.boostedUntil)}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      {tab === 'capitulos' && (
        <div className="space-y-3">
          {myBooks.length === 0 && <p className="text-[12px] text-faint">Crie uma obra para começar a escrever capítulos.</p>}
          {myBooks.map((b) => (
            <div key={b.id} className="liquid-card overflow-hidden">
              <div className="flex items-center justify-between border-b border-white/[0.06] px-3.5 py-2.5">
                <p className="truncate text-[12.5px] font-semibold text-chalk">{b.title}</p>
                <button
                  type="button"
                  onClick={() => {
                    setChapterBookId(b.id);
                    setNewChapter({ title: '', content: '', earlyAccess: false, status: 'published' });
                  }}
                  className="inline-flex items-center gap-1 rounded-lg bg-hot-500/15 px-2 py-1 text-[10.5px] font-semibold text-hot-300"
                >
                  <Plus size={10} /> Novo
                </button>
              </div>
              {b.chapters.length === 0 ? (
                <p className="px-3.5 py-4 text-[11.5px] text-faint">Nenhum capítulo. Comece pelo primeiro.</p>
              ) : (
                <ul className="divide-y divide-white/[0.05]">
                  {b.chapters.map((c) => (
                    <li key={c.id} className="flex items-center gap-2.5 px-3.5 py-2.5">
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-white/[0.06] text-[10.5px] text-mute">
                        {c.number}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[11.5px] font-medium text-chalk">{c.title}</p>
                        <p className="text-[9.5px] text-faint">
                          {c.status === 'draft' ? 'rascunho' : 'publicado'} · {c.content.split(/\s+/).length} palavras
                          {c.earlyAccess ? ' · antecipado' : ''}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          updateChapter(b.id, c.id, { status: c.status === 'published' ? 'draft' : 'published' })
                        }
                        className="rounded-lg px-2 py-1 text-[10px] text-mute hover:text-hot-300"
                      >
                        {c.status === 'published' ? 'Despublicar' : 'Publicar'}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const title = window.prompt('Novo título do capítulo', c.title);
                          if (title) updateChapter(b.id, c.id, { title });
                        }}
                        className="rounded p-1 text-faint hover:text-chalk"
                        aria-label="Renomear"
                      >
                        <Save size={11} />
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteChapter(b.id, c.id)}
                        className="rounded p-1 text-faint hover:text-[#fca5a5]"
                        aria-label="Excluir capítulo"
                      >
                        <Trash2 size={11} />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === 'beta' && (
        <div className="space-y-2.5">
          {myApps.length === 0 ? (
            <EmptyState
              icon={<FlaskConical size={28} />}
              title="Nenhuma candidatura beta"
              body="Ative o modo Leitura Beta em uma obra (com vagas e prazo) para receber candidaturas de leitores assinantes."
            />
          ) : (
            myApps.map((a) => (
              <div key={a.id} className="liquid-card p-3">
                <div className="flex items-center gap-2.5">
                  <img src={a.userPhoto} alt="" className="h-8 w-8 rounded-full object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12px] font-semibold text-chalk">{a.userName}</p>
                    <p className="truncate text-[10px] text-faint">
                      {a.bookTitle} · {formatDate(a.createdAt)}
                    </p>
                  </div>
                  <Badge
                    tone={a.status === 'approved' ? 'ok' : a.status === 'rejected' ? 'bad' : 'warn'}
                    className="shrink-0"
                  >
                    {a.status === 'approved' ? 'aprovado' : a.status === 'rejected' ? 'recusado' : 'pendente'}
                  </Badge>
                </div>
                <p className="mt-2 rounded-lg border border-white/[0.06] bg-ink-900/60 p-2 text-[11px] leading-relaxed text-mute">
                  “{a.motivation}”
                </p>
                {a.status === 'pending' && (
                  <div className="mt-2 flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => decideBeta(a.id, 'approved')}
                      className="inline-flex flex-1 items-center justify-center gap-1 rounded-lg bg-[#4ade80]/15 py-1.5 text-[10.5px] font-semibold text-[#86efac] hover:bg-[#4ade80]/25"
                    >
                      <Check size={10} /> Aprovar
                    </button>
                    <button
                      type="button"
                      onClick={() => decideBeta(a.id, 'rejected')}
                      className="inline-flex flex-1 items-center justify-center gap-1 rounded-lg bg-[#f87171]/12 py-1.5 text-[10.5px] font-semibold text-[#fca5a5] hover:bg-[#f87171]/20"
                    >
                      <X size={10} /> Recusar
                    </button>
                  </div>
                )}
                {a.feedback && (
                  <div className="mt-2 rounded-lg border border-hot-500/25 bg-hot-500/[0.06] p-2">
                    <p className="mb-1 inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-hot-300">
                      <MessageSquare size={9} /> Feedback recebido
                    </p>
                    <p className="text-[11px] leading-relaxed text-mute">{a.feedback}</p>
                  </div>
                )}
                {a.status === 'approved' && !a.feedback && (
                  <p className="mt-2 inline-flex items-center gap-1 text-[10px] text-faint">
                    <Clock size={9} /> Aguardando feedback do leitor
                  </p>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'estatisticas' && (
        <div className="grid gap-2.5 sm:grid-cols-2">
          {[
            { label: 'Leituras totais', value: totalReads.toLocaleString('pt-BR'), icon: Eye },
            { label: 'Leitores únicos', value: compact(totalReaders), icon: Users },
            { label: 'Avaliação média', value: (myBooks.reduce((a, b) => a + b.rating, 0) / Math.max(1, myBooks.length)).toFixed(2), icon: Star },
            { label: 'Capítulos publicados', value: String(myBooks.reduce((a, b) => a + b.chapters.filter((c) => c.status === 'published').length, 0)), icon: FileText },
          ].map((s) => (
            <div key={s.label} className="liquid-card flex items-center gap-3 p-3.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-hot-500/12 text-hot-400">
                <s.icon size={16} />
              </span>
              <div>
                <p className="text-[18px] font-bold leading-none text-chalk">{s.value}</p>
                <p className="mt-1 text-[10.5px] text-mute">{s.label}</p>
              </div>
            </div>
          ))}
          <div className="liquid-card p-3.5 sm:col-span-2">
            <p className="mb-2 inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-faint">
              <BarChart3 size={11} /> Desempenho por obra
            </p>
            <div className="space-y-2">
              {myBooks.map((b) => {
                const max = Math.max(...myBooks.map((x) => x.readers), 1);
                return (
                  <div key={b.id}>
                    <div className="mb-1 flex items-center justify-between text-[11px]">
                      <span className="truncate text-mute">{b.title}</span>
                      <span className="shrink-0 tabular-nums text-chalk">{b.readers} leitores</span>
                    </div>
                    <Progress value={pct(b.readers, max)} />
                  </div>
                );
              })}
              {myBooks.length === 0 && <p className="text-[11.5px] text-faint">Sem dados ainda.</p>}
            </div>
          </div>
        </div>
      )}

      {/* Modal criar/editar obra */}
      {(creating || editorBook) && (
        <BookEditor
          book={editorBook}
          onClose={() => {
            setCreating(false);
            setEditorBook(null);
          }}
          onSave={(data) => {
            if (editorBook) {
              updateBook(editorBook.id, data);
              pushToast({ title: 'Obra atualizada', tone: 'success' });
            } else {
              createBook({ ...data, title: data.title ?? 'Sem título', synopsis: data.synopsis ?? '' });
              pushToast({ title: 'Obra criada', body: 'Escreva o primeiro capítulo no Estúdio.', tone: 'success' });
            }
            setCreating(false);
            setEditorBook(null);
          }}
          onDelete={
            editorBook
              ? () => {
                  deleteBook(editorBook.id);
                  setEditorBook(null);
                }
              : undefined
          }
        />
      )}

      {/* Modal novo capítulo */}
      <Modal
        open={Boolean(chapterBookId)}
        onClose={() => setChapterBookId(null)}
        title="Novo capítulo"
        subtitle={myBooks.find((b) => b.id === chapterBookId)?.title}
        size="lg"
        footer={
          <div className="flex gap-2">
            <button type="button" onClick={() => setChapterBookId(null)} className={cx(btnGhost, 'flex-1')}>
              Cancelar
            </button>
            <button
              type="button"
              className={cx(btnPink, 'flex-1')}
              disabled={!newChapter.title.trim() || !newChapter.content.trim()}
              onClick={() => {
                if (!chapterBookId) return;
                addChapter(chapterBookId, newChapter);
                setNewChapter({ title: '', content: '', earlyAccess: false, status: 'published' });
                setChapterBookId(null);
                pushToast({ title: 'Capítulo criado', tone: 'success' });
              }}
            >
              Salvar capítulo
            </button>
          </div>
        }
      >
        <div className="space-y-3">
          <input
            value={newChapter.title}
            onChange={(e) => setNewChapter((s) => ({ ...s, title: e.target.value }))}
            placeholder="Título do capítulo"
            className={inputCls}
          />
          <textarea
            value={newChapter.content}
            onChange={(e) => setNewChapter((s) => ({ ...s, content: e.target.value }))}
            rows={12}
            placeholder="Escreva aqui. Separe parágrafos com uma linha em branco."
            className={cx(inputCls, 'resize-none font-literata text-[13px] leading-relaxed')}
          />
          <div className="flex flex-wrap items-center gap-3">
            <label className="inline-flex items-center gap-1.5 text-[11.5px] text-mute">
              <input
                type="checkbox"
                checked={newChapter.earlyAccess}
                onChange={(e) => setNewChapter((s) => ({ ...s, earlyAccess: e.target.checked }))}
                className="accent-hot-500"
              />
              Acesso antecipado (assinantes/beta)
            </label>
            <select
              value={newChapter.status}
              onChange={(e) => setNewChapter((s) => ({ ...s, status: e.target.value as 'draft' | 'published' }))}
              className={cx(inputCls, 'w-auto !py-1.5 !text-[11.5px]')}
            >
              <option value="published" className="bg-ink-800">
                Publicado
              </option>
              <option value="draft" className="bg-ink-800">
                Rascunho
              </option>
            </select>
          </div>
          <p className="text-[10px] text-faint">
            {newChapter.content.split(/\s+/).filter(Boolean).length} palavras ·{' '}
            {Math.max(1, Math.round(newChapter.content.split(/\s+/).filter(Boolean).length / 200))} min de leitura
          </p>
        </div>
      </Modal>
    </div>
  );
}

function BookEditor({
  book,
  onClose,
  onSave,
  onDelete,
}: {
  book: Book | null;
  onClose: () => void;
  onSave: (data: Partial<Book>) => void;
  onDelete?: () => void;
}) {
  const [title, setTitle] = useState(book?.title ?? '');
  const [synopsis, setSynopsis] = useState(book?.synopsis ?? '');
  const [genres, setGenres] = useState<Genre[]>(book?.genres ?? ['Romance']);
  const [ageRating, setAgeRating] = useState<AgeRating>(book?.ageRating ?? 'Livre');
  const [status, setStatus] = useState(book?.status ?? 'draft');
  const [cover, setCover] = useState(book?.cover ?? '');
  const [betaMode, setBetaMode] = useState(book?.betaMode ?? false);
  const [betaSlots, setBetaSlots] = useState(book?.betaSlots ?? 10);
  const [betaRules, setBetaRules] = useState(book?.betaRules ?? '');
  const [betaDeadline, setBetaDeadline] = useState(book?.betaDeadline?.slice(0, 10) ?? '');
  const [busy, setBusy] = useState(false);

  const toggleGenre = (g: Genre) =>
    setGenres((prev) => (prev.includes(g) ? prev.filter((x) => x !== g) : [...prev, g]));

  const handleUpload = async (file: File) => {
    setBusy(true);
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const res = await uploadMedia(dataUrl, 'covers', title || 'capa');
      setCover(res.url);
    } catch {
      const dataUrl = await readFileAsDataUrl(file);
      setCover(dataUrl);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={book ? 'Editar obra' : 'Nova obra'}
      size="lg"
      footer={
        <div className="flex gap-2">
          {onDelete && (
            <button
              type="button"
              onClick={() => {
                if (window.confirm('Excluir esta obra e todo o progresso dos leitores? Esta ação não pode ser desfeita.')) onDelete();
              }}
              className="rounded-xl border border-[#f87171]/30 px-3 text-[12px] text-[#fca5a5] hover:bg-[#f87171]/10"
            >
              Excluir
            </button>
          )}
          <button type="button" onClick={onClose} className={cx(btnGhost, 'flex-1')}>
            Cancelar
          </button>
          <button
            type="button"
            disabled={!title.trim() || genres.length === 0 || busy}
            onClick={() =>
              onSave({
                title: title.trim(),
                synopsis: synopsis.trim(),
                genres,
                ageRating,
                status,
                cover: cover || coverArt(title, book?.authorName ?? 'Autor', title),
                betaMode,
                betaSlots: Number(betaSlots),
                betaRules,
                betaDeadline: betaDeadline ? new Date(betaDeadline).toISOString() : null,
              })
            }
            className={cx(btnPink, 'flex-1')}
          >
            Salvar
          </button>
        </div>
      }
    >
      <div className="space-y-3">
        <div className="flex gap-3">
          <div className="shrink-0">
            <img
              src={cover || coverArt(title || 'Sua obra', 'Autor')}
              alt=""
              className="h-[132px] w-[88px] rounded-lg object-cover ring-1 ring-white/10"
            />
            <label className="mt-1.5 flex cursor-pointer items-center justify-center gap-1 rounded-lg border border-white/10 py-1 text-[10px] text-mute hover:text-chalk">
              <Upload size={9} /> {busy ? 'Enviando…' : 'Capa'}
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void handleUpload(f);
                }}
              />
            </label>
          </div>
          <div className="min-w-0 flex-1 space-y-2">
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Título da obra" className={inputCls} />
            <textarea
              value={synopsis}
              onChange={(e) => setSynopsis(e.target.value)}
              rows={4}
              placeholder="Sinopse — o que o leitor encontra nas primeiras páginas?"
              className={cx(inputCls, 'resize-none text-[12.5px]')}
            />
          </div>
        </div>

        <div>
          <p className="mb-1.5 text-[10.5px] font-semibold uppercase tracking-wide text-faint">Gêneros</p>
          <div className="flex flex-wrap gap-1.5">
            {GENRES.map((g) => (
              <button
                key={g}
                type="button"
                onClick={() => toggleGenre(g)}
                className={cx(
                  'rounded-full border px-2.5 py-1 text-[10.5px] transition-colors',
                  genres.includes(g)
                    ? 'border-hot-500 bg-hot-500/15 text-hot-300'
                    : 'border-white/10 text-mute hover:text-chalk',
                )}
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="mb-1.5 text-[10.5px] font-semibold uppercase tracking-wide text-faint">Classificação</p>
            <select value={ageRating} onChange={(e) => setAgeRating(e.target.value as AgeRating)} className={inputCls}>
              {AGE_RATINGS.map((r) => (
                <option key={r} value={r} className="bg-ink-800">
                  {r}
                </option>
              ))}
            </select>
          </div>
          <div>
            <p className="mb-1.5 text-[10.5px] font-semibold uppercase tracking-wide text-faint">Status</p>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as Book['status'])}
              className={inputCls}
            >
              <option value="draft" className="bg-ink-800">
                Rascunho
              </option>
              <option value="published" className="bg-ink-800">
                Publicada
              </option>
              <option value="completed" className="bg-ink-800">
                Concluída
              </option>
            </select>
          </div>
        </div>

        <div className="rounded-xl border border-[#60a5fa]/25 bg-[#60a5fa]/[0.06] p-2.5">
          <label className="flex items-center gap-2 text-[11.5px] font-semibold text-[#bfdbfe]">
            <input type="checkbox" checked={betaMode} onChange={(e) => setBetaMode(e.target.checked)} className="accent-[#60a5fa]" />
            Modo Leitura Beta
          </label>
          {betaMode && (
            <div className="mt-2 space-y-2">
              <div className="flex gap-2">
                <input
                  type="number"
                  min={1}
                  max={200}
                  value={betaSlots}
                  onChange={(e) => setBetaSlots(Number(e.target.value))}
                  className={cx(inputCls, '!py-1.5 !text-[11.5px]')}
                  placeholder="Vagas"
                />
                <input
                  type="date"
                  value={betaDeadline}
                  onChange={(e) => setBetaDeadline(e.target.value)}
                  className={cx(inputCls, '!py-1.5 !text-[11.5px]')}
                />
              </div>
              <textarea
                value={betaRules}
                onChange={(e) => setBetaRules(e.target.value)}
                rows={2}
                placeholder="Regras para os leitores beta (o que você espera do feedback)"
                className={cx(inputCls, 'resize-none !text-[11.5px]')}
              />
            </div>
          )}
        </div>
        <p className="flex items-center gap-1 text-[10px] text-faint">
          <Stars value={0} size={8} /> Obras em rascunho não aparecem no catálogo nem na busca.
        </p>
      </div>
    </Modal>
  );
}
