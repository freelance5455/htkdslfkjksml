import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Film, Flame, Plus, Sparkles, TrendingUp, Users } from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Badge, EmptyState, SectionHeader, btnGhost, btnPink } from '../components/ui';
import { compact, timeAgo } from '../lib/utils';

export default function SocialHomeView() {
  const { db, currentUser } = useStore();
  const navigate = useNavigate();

  const myCommunities = useMemo(
    () => (currentUser ? db.communities.filter((c) => c.members.some((m) => m.userId === currentUser.uid)) : []),
    [db.communities, currentUser],
  );
  const feed = useMemo(
    () => [...db.posts].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)).slice(0, 6),
    [db.posts],
  );
  const fluxPreview = useMemo(() => db.fluxPosts.slice(0, 4), [db.fluxPosts]);

  return (
    <div className="mx-auto max-w-3xl px-4 pb-10 pt-5 sm:px-6">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-hot-400">Área social</p>
          <h1 className="mt-1 text-[22px] font-bold tracking-tight text-chalk">Onde a leitura vira conversa</h1>
          <p className="mt-1 text-[12px] text-mute">
            {db.communities.length} comunidades · {db.posts.length} posts no feed · {db.fluxPosts.length} no Flux
          </p>
        </div>
        <button type="button" onClick={() => navigate('/social/flux/criar')} className={btnPink}>
          <Plus size={14} /> CRIAR FLUX
        </button>
      </div>

      {/* Flux preview */}
      <section className="mb-6">
        <SectionHeader eyebrow="Feed vertical" title="Últimos Flux" action="Abrir Flux" onAction={() => navigate('/social/flux')} />
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          {fluxPreview.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => navigate(`/social/flux?flux=${p.id}`)}
              className="group relative aspect-[9/16] overflow-hidden rounded-xl border border-white/[0.08] text-left transition-transform hover:-translate-y-1"
            >
              {p.media[0] ? (
                <img src={p.media[0]} alt="" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
              ) : (
                <div className="h-full w-full bg-gradient-to-br from-hot-900/60 to-ink-900 p-2.5">
                  <p className="clamp-4 text-[11px] font-literata leading-snug text-chalk/90">{p.text}</p>
                </div>
              )}
              <div className="scrim-b absolute inset-0" />
              <div className="absolute inset-x-0 bottom-0 p-2">
                <p className="truncate text-[10px] font-semibold text-chalk">{p.authorName}</p>
                <p className="text-[9px] text-mute">{compact(p.likes.length)} curtidas</p>
              </div>
              <Film size={11} className="absolute right-2 top-2 text-hot-300" />
            </button>
          ))}
        </div>
      </section>

      {/* Minhas comunidades */}
      {myCommunities.length > 0 && (
        <section className="mb-6">
          <SectionHeader eyebrow="Você participa" title="Minhas comunidades" action="Ver todas" onAction={() => navigate('/social/comunidades')} />
          <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
            {myCommunities.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => navigate(`/social/comunidades/${c.id}`)}
                className="flex w-[168px] shrink-0 items-center gap-2 rounded-xl border border-white/[0.08] bg-ink-750 p-2 text-left transition-colors hover:border-hot-500/35"
              >
                <img src={c.cover} alt="" className="h-9 w-9 shrink-0 rounded-lg object-cover" />
                <span className="min-w-0">
                  <span className="block truncate text-[11.5px] font-semibold text-chalk">{c.name}</span>
                  <span className="block text-[9.5px] text-faint">{c.members.length} membros</span>
                </span>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Feed */}
      <section>
        <SectionHeader
          eyebrow="Feed das comunidades"
          title="Movimento recente"
          action="Comunidades"
          onAction={() => navigate('/social/comunidades')}
        />
        {feed.length === 0 ? (
          <EmptyState
            icon={<Users size={28} />}
            title="Feed vazio"
            body="Entre em uma comunidade e publique o primeiro post — texto, imagem, carrossel, vídeo ou enquete."
            action={
              <button type="button" onClick={() => navigate('/social/comunidades')} className={btnGhost}>
                Explorar comunidades
              </button>
            }
          />
        ) : (
          <div className="space-y-2.5">
            {feed.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => p.communityId && navigate(`/social/comunidades/${p.communityId}`)}
                className="liquid-card liquid-card-hover block w-full p-3 text-left"
              >
                <div className="flex items-center gap-2">
                  <img src={p.authorPhoto} alt="" className="h-7 w-7 rounded-full object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11.5px] font-semibold text-chalk">
                      {p.authorName}{' '}
                      {p.communityName && <span className="font-normal text-faint">em {p.communityName}</span>}
                    </p>
                    <p className="text-[9.5px] text-faint">{timeAgo(p.createdAt)} atrás</p>
                  </div>
                  {p.type === 'poll' && <Badge tone="hot">enquete</Badge>}
                  {p.type === 'text' && <Badge tone="neutral">texto</Badge>}
                </div>
                <p className="clamp-3 mt-2 text-[12px] leading-relaxed text-mute">{p.text}</p>
                {p.media[0] && <img src={p.media[0]} alt="" className="mt-2 h-36 w-full rounded-lg object-cover" />}
                <div className="mt-2 flex items-center gap-3 text-[10px] text-faint">
                  <span>❤️ {p.likes.length}</span>
                  <span>💬 {p.comments.length}</span>
                  <span className="ml-auto inline-flex items-center gap-1 text-hot-300">
                    abrir <ArrowRight size={9} />
                  </span>
                </div>
              </button>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
