import { Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { Suspense, lazy, useEffect, useState } from 'react';
import { StoreProvider, useStore } from './contexts/StoreContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Footer, FloatingDock, Header } from './components/Header';
import { NotificationsDrawer, ProfileModal, SearchOverlay } from './components/Modals';
import { ToastStack } from './components/ToastStack';
import { Skeleton } from './components/ui';
import HomeView from './views/HomeView';
import ExploreBooksView from './views/ExploreBooksView';
import BookDetailsView from './views/BookDetailsView';
import ReaderView from './views/ReaderView';
import LibraryView from './views/LibraryView';
import AuthorStudioView from './views/AuthorStudioView';
import SocialView from './views/SocialView';
import RankingView from './views/RankingView';
import AchievementsView from './views/AchievementsView';
import SubscriptionsView from './views/SubscriptionsView';
import DeveloperAdminView from './views/DeveloperAdminView';
import LoginView from './views/LoginView';
import ProfilePage from './views/ProfilePage';

const Splash = () => (
  <div className="flex min-h-[60dvh] items-center justify-center">
    <div className="w-full max-w-sm space-y-3 px-6">
      <Skeleton className="h-6 w-32" />
      <Skeleton className="h-40 w-full" />
      <Skeleton className="h-4 w-48" />
    </div>
  </div>
);

function Shell() {
  const location = useLocation();
  const { db } = useStore();
  const { loading } = useAuth();
  const [searchOpen, setSearchOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileId, setProfileId] = useState<string | null>(null);

  const isReader = location.pathname.startsWith('/ler/');
  const isFlux = location.pathname.startsWith('/social/flux');
  const immersive = isReader || isFlux;

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, [location.pathname]);

  useEffect(() => {
    document.title = `${db.branding.appName} — ${db.branding.tagline}`;
  }, [db.branding]);

  // Abre modal de perfil quando a rota é /perfil/:uid (link direto)
  const profileRoute = location.pathname.startsWith('/perfil/')
    ? location.pathname.split('/perfil/')[1]
    : null;

  return (
    <div className={immersive ? '' : 'ambient-shell'}>
      <Header
        immersive={immersive}
        onOpenSearch={() => setSearchOpen(true)}
        onOpenNotifications={() => setNotifOpen(true)}
        onOpenProfile={() => setProfileId(profileRoute ?? (localStorage.getItem('kordel.session.v1') || null))}
      />

      <main className={immersive ? '' : 'min-h-[70dvh]'}>
        {loading ? (
          <Splash />
        ) : (
          <Suspense fallback={<Splash />}>
            <Routes>
              <Route path="/" element={<HomeView onOpenProfile={setProfileId} />} />
              <Route path="/explorar" element={<ExploreBooksView onOpenProfile={setProfileId} />} />
              <Route path="/obra/:bookId" element={<BookDetailsView onOpenProfile={setProfileId} />} />
              <Route path="/ler/:bookId" element={<ReaderView />} />
              <Route path="/ler/:bookId/:chapterId" element={<ReaderView />} />
              <Route path="/biblioteca" element={<LibraryView />} />
              <Route path="/estudio" element={<AuthorStudioView />} />
              <Route path="/social/*" element={<SocialView />} />
              <Route path="/ranking" element={<RankingView onOpenProfile={setProfileId} />} />
              <Route path="/conquistas" element={<AchievementsView />} />
              <Route path="/assinaturas" element={<SubscriptionsView />} />
              <Route path="/dev" element={<DeveloperAdminView onOpenProfile={setProfileId} />} />
              <Route path="/entrar" element={<LoginView />} />
              <Route path="/perfil/:uid" element={<ProfilePage onOpenProfile={setProfileId} />} />
              <Route
                path="*"
                element={
                  <div className="mx-auto max-w-lg px-4 py-24 text-center">
                    <p className="text-[13px] font-semibold text-hot-400">404</p>
                    <h1 className="mt-1 text-xl font-bold text-chalk">Página não encontrada</h1>
                    <p className="mt-2 text-[12.5px] text-mute">
                      A história que você procura não está neste varal.
                    </p>
                  </div>
                }
              />
            </Routes>
          </Suspense>
        )}
      </main>

      {!immersive && <Footer />}
      {!immersive && <FloatingDock />}

      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
      <NotificationsDrawer open={notifOpen} onClose={() => setNotifOpen(false)} />
      {profileId && <ProfileModal userId={profileId} onClose={() => setProfileId(null)} onOpenBook={(id) => { setProfileId(null); window.location.assign(`/obra/${id}`); }} />}
      <ToastStack />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <AuthProvider>
        <Shell />
      </AuthProvider>
    </StoreProvider>
  );
}
