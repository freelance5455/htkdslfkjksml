import { X, Star, ChevronRight } from 'lucide-react';
import { useEffect, type ReactNode } from 'react';
import { cx } from '../lib/utils';

/* ── Avatar ─────────────────────────────────────────────────────────────── */
export function Avatar({
  src,
  name,
  size = 40,
  ring = false,
  onClick,
  className,
}: {
  src?: string | null;
  name: string;
  size?: number;
  ring?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  const content = (
    <img
      src={src || ''}
      alt={name}
      width={size}
      height={size}
      loading="lazy"
      onError={(e) => {
        const el = e.currentTarget;
        if (!el.dataset.fb) {
          el.dataset.fb = '1';
          el.src = `https://api.dicebear.com/9.x/initials/svg?seed=${encodeURIComponent(name)}&backgroundColor=ff57b2&textColor=1a1a1a`;
        }
      }}
      className="h-full w-full object-cover"
      style={{ borderRadius: 999 }}
    />
  );
  const cls = cx(
    'inline-flex shrink-0 items-center justify-center overflow-hidden bg-ink-700',
    ring && 'ring-2 ring-hot-500/70 ring-offset-2 ring-offset-ink-850',
    onClick && 'cursor-pointer transition-transform hover:scale-105',
    className,
  );
  if (onClick)
    return (
      <button type="button" onClick={onClick} className={cls} style={{ width: size, height: size }} aria-label={name}>
        {content}
      </button>
    );
  return (
    <span className={cls} style={{ width: size, height: size }}>
      {content}
    </span>
  );
}

/* ── Badge ──────────────────────────────────────────────────────────────── */
const TONES = {
  hot: 'bg-hot-500/16 text-hot-300 border-hot-500/35',
  ok: 'bg-[#4ade80]/12 text-[#86efac] border-[#4ade80]/30',
  info: 'bg-[#60a5fa]/12 text-[#93c5fd] border-[#60a5fa]/30',
  warn: 'bg-[#fbbf24]/12 text-[#fcd34d] border-[#fbbf24]/30',
  neutral: 'bg-white/[0.06] text-mute border-white/10',
  bad: 'bg-[#f87171]/12 text-[#fca5a5] border-[#f87171]/30',
} as const;

export function Badge({
  children,
  tone = 'neutral',
  icon,
  className,
}: {
  children: ReactNode;
  tone?: keyof typeof TONES;
  icon?: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cx(
        'inline-flex items-center gap-1 rounded-full border px-2.5 py-[3px] text-[11px] font-medium tracking-wide whitespace-nowrap',
        TONES[tone],
        className,
      )}
    >
      {icon}
      {children}
    </span>
  );
}

/* ── Botões ─────────────────────────────────────────────────────────────── */
export const btnPink =
  'inline-flex items-center justify-center gap-2 rounded-xl bg-hot-500 px-5 py-2.5 text-sm font-semibold text-[#1a1a1a] transition-all hover:bg-hot-600 active:bg-hot-700 active:scale-[0.985] disabled:cursor-not-allowed disabled:opacity-45 pink-glow';
export const btnGhost =
  'inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.045] px-4 py-2.5 text-sm font-medium text-chalk transition-all hover:border-white/20 hover:bg-white/[0.08] active:scale-[0.985] disabled:cursor-not-allowed disabled:opacity-45';
export const btnSubtle =
  'inline-flex items-center justify-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-mute transition-colors hover:bg-white/[0.07] hover:text-chalk';
export const inputCls =
  'w-full rounded-xl border border-white/10 bg-ink-900/80 px-3.5 py-2.5 text-sm text-chalk placeholder:text-faint transition-colors focus:border-hot-500/60 focus:outline-none focus:ring-2 focus:ring-hot-500/20';

/* ── Estrelas ───────────────────────────────────────────────────────────── */
export function Stars({
  value,
  size = 14,
  onChange,
  className,
}: {
  value: number;
  size?: number;
  onChange?: (v: number) => void;
  className?: string;
}) {
  return (
    <span className={cx('inline-flex items-center gap-0.5', className)}>
      {[1, 2, 3, 4, 5].map((i) => {
        const filled = i <= Math.round(value);
        return onChange ? (
          <button key={i} type="button" onClick={() => onChange(i)} aria-label={`${i} estrelas`}>
            <Star
              size={size}
              className={filled ? 'fill-hot-500 text-hot-500' : 'text-white/25'}
            />
          </button>
        ) : (
          <Star key={i} size={size} className={filled ? 'fill-hot-500 text-hot-500' : 'text-white/20'} />
        );
      })}
    </span>
  );
}

/* ── Progresso ──────────────────────────────────────────────────────────── */
export function Progress({ value, className }: { value: number; className?: string }) {
  return (
    <div className={cx('h-1.5 w-full overflow-hidden rounded-full bg-white/[0.08]', className)}>
      <div
        className="h-full rounded-full bg-gradient-to-r from-hot-700 to-hot-400 transition-[width] duration-500"
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  );
}

/* ── Modal ──────────────────────────────────────────────────────────────── */
export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  size = 'md',
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}) {
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
  }, [open, onClose]);

  if (!open) return null;
  const widths = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' };

  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center" role="dialog" aria-modal>
      <button
        type="button"
        aria-label="Fechar"
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
      />
      <div
        className={cx(
          'relative z-10 max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border border-white/10 bg-ink-800 shadow-[0_-10px_60px_rgba(0,0,0,0.6)] sm:rounded-2xl',
          widths[size],
        )}
      >
        {(title || subtitle) && (
          <div className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-white/[0.07] bg-ink-800/95 px-5 py-4 backdrop-blur">
            <div className="min-w-0">
              {title && <h3 className="truncate font-semibold text-chalk">{title}</h3>}
              {subtitle && <p className="mt-0.5 text-xs text-mute">{subtitle}</p>}
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg p-1.5 text-mute transition-colors hover:bg-white/10 hover:text-chalk"
              aria-label="Fechar modal"
            >
              <X size={17} />
            </button>
          </div>
        )}
        <div className="px-5 py-4">{children}</div>
        {footer && (
          <div className="sticky bottom-0 border-t border-white/[0.07] bg-ink-800/95 px-5 py-3.5 backdrop-blur">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Seção ──────────────────────────────────────────────────────────────── */
export function SectionHeader({
  title,
  eyebrow,
  action,
  onAction,
}: {
  title: string;
  eyebrow?: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="mb-3.5 flex items-end justify-between gap-3">
      <div>
        {eyebrow && (
          <p className="mb-1 text-[10.5px] font-semibold uppercase tracking-[0.18em] text-hot-400">{eyebrow}</p>
        )}
        <h2 className="text-[17px] font-semibold tracking-tight text-chalk sm:text-lg">{title}</h2>
      </div>
      {action && (
        <button
          type="button"
          onClick={onAction}
          className="group inline-flex shrink-0 items-center gap-0.5 text-xs font-medium text-mute transition-colors hover:text-hot-400"
        >
          {action}
          <ChevronRight size={14} className="transition-transform group-hover:translate-x-0.5" />
        </button>
      )}
    </div>
  );
}

/* ── Estado vazio ───────────────────────────────────────────────────────── */
export function EmptyState({
  icon,
  title,
  body,
  action,
}: {
  icon?: ReactNode;
  title: string;
  body?: string;
  action?: ReactNode;
}) {
  return (
    <div className="liquid-card flex flex-col items-center justify-center px-6 py-12 text-center">
      <div className="mb-3 text-hot-500/80">{icon}</div>
      <p className="text-sm font-semibold text-chalk">{title}</p>
      {body && <p className="mt-1 max-w-sm text-xs leading-relaxed text-mute">{body}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

/* ── Skeleton ───────────────────────────────────────────────────────────── */
export function Skeleton({ className }: { className?: string }) {
  return <div className={cx('shimmer rounded-xl', className)} />;
}

/* ── Abas em pílula ─────────────────────────────────────────────────────── */
export function Pills<T extends string>({
  items,
  value,
  onChange,
  className,
}: {
  items: Array<{ id: T; label: string; count?: number }>;
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={cx('no-scrollbar flex gap-1.5 overflow-x-auto rounded-full border border-white/[0.08] bg-ink-900/70 p-1', className)}>
      {items.map((it) => {
        const active = it.id === value;
        return (
          <button
            key={it.id}
            type="button"
            onClick={() => onChange(it.id)}
            className={cx(
              'flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[12.5px] font-semibold tracking-wide transition-all',
              active
                ? 'border border-hot-500 bg-hot-500/[0.14] text-hot-300 shadow-[0_0_18px_-8px_rgba(255,87,178,0.9)]'
                : 'border border-transparent text-mute hover:text-chalk',
            )}
          >
            {it.label}
            {typeof it.count === 'number' && (
              <span className={cx('rounded-full px-1.5 py-px text-[10px]', active ? 'bg-hot-500/25 text-hot-200' : 'bg-white/10 text-mute')}>
                {it.count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}

/* ── Dropdown genérico ──────────────────────────────────────────────────── */
export function useClickOutside(onOutside: () => void) {
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      if (!t.closest('[data-popover]')) onOutside();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [onOutside]);
}
