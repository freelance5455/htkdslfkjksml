import { useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Crown,
  Search,
  Sparkles,
  TrendingUp,
  UserPlus,
  UserCheck,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useStore } from '../contexts/StoreContext';
import { Avatar, Badge, EmptyState, Modal, Stars, btnGhost, btnPink, inputCls, Progress } from './ui';
import { ACHIEVEMENTS, BADGES, levelFromXp, TITLES } from '../lib/xp';
import { compact, cx, timeAgo } from '../lib/utils';
import type { AppNotification, AppUser, Book } from '../types';

/* ══════════════════════════════════════════════════════════════════════════
   Perfil público
   ══════════════════════════════════════════════════════════════════════════ */
export function ProfileModal({
  userId,
  onClose,
  onOpenBook,
}: {
  userId: string | null;
  onClose: () => void;
  onOpenBook: (id: string) => void;
}) {
  const { db, currentUser, toggleFollow, isFollowing } = useStore();
  const navigate = useNavigate();
  const user = db.users.find((u) => u.uid === userId);
  if (!userId || !user) return null;

  const lvl = levelFromXp(user.xp);
  const works = db.books.filter((b) => b.authorId === user.uid);
  const following = isFollowing(user.uid);
  const isMe = currentUser?.uid === user.uid;
  const followersCount = db.follows.filter((f) => f.followingId === user.uid).length;
  const followingCount = db.follows.filter((f) => f.followerId === user.uid).length;
  const badges = BADGES.filter((b) => user.badges.includes(b.id));
  const titleDef = TITLES.find((t) => t.id === user.equippedTitle);

  return (
    <Modal open onClose={onClose} size="lg">
      <div className="-mx-5 -mt-4">
        <div className="relative h-24 overflow-hidden rounded-t-2xl bg-gradient-to-r from-hot-900/70 via-ink-750 to-[#2A1A24]">
          <div className="absolute inset-0 opacity-40 [background:radial-gradient(20rem_10rem_at_80%_0%,rgba(255,87,178,0.6),transparent)]" />
          {!isMe && currentUser && (
            <button
              type="button"
              onClick={() => toggleFollow(user.uid)}
              className={cx(
                'absolute right-3 top-3 inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11.5px] font-semibold transition-all',
                following
                  ? 'border border-white/20 bg-black/40 text-chalk hover:border-[#f87171]/50 hover:text-[#fca5a5]'
                  : 'bg-hot-500 text-[#1a1a1a] pink-glow-soft hover:bg-hot-600',
              )}
            >
              {following ? <UserCheck size={13} /> : <UserPlus size={13} />}
              {following ? 'Seguindo' : 'Seguir'}
            </button>
          )}
          {isMe && (
            <button
              type="button"
              onClick={() => {
                onClose();
                navigate('/conquistas');
              }}
              className="absolute right-3 top-3 rounded-full border border-white/20 bg-black/40 px-3 py-1.5 text-[11.5px] font-semibold text-chalk"
            >
              Editar perfil
            </button>
          )}
        </div>

        <div className="px-5">
          <div className="-mt-9 flex items-end gap-3">
            <Avatar src={user.photoURL} name={user.displayName} size={72} ring className="border-4 border-ink-800" />
            <div className="min-w-0 flex-1 pb-1">
              <h3 className="truncate text-[17px] font-bold text-chalk">{user.displayName}</h3>
              <p className="truncate text-[11.5px] text-mute">
                @{user.email.split('@')[0]} · {user.role}
              </p>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <Badge tone="hot" icon={<Sparkles size={10} />}>
              {lvl.levelLabel}
            </Badge>
            {titleDef && <Badge tone="neutral">🏷️ {titleDef.name}</Badge>}
            {badges.map((b) => (
              <Badge key={b.id} tone={b.tone}>
                {b.icon} {b.label}
              </Badge>
            ))}
          </div>

          {user.bio && <p className="mt-3 text-[12.5px] leading-relaxed text-mute">{user.bio}</p>}

          <div className="mt-4 grid grid-cols-4 gap-2">
            {[
              { label: 'Seguidores', value: compact(followersCount) },
              { label: 'Seguindo', value: compact(followingCount) },
              { label: 'Obras', value: String(works.length) },
              { label: 'XP', value: compact(user.xp) },
            ].map((s) => (
              <div key={s.label} className="rounded-xl border border-white/[0.07] bg-ink-900/60 px-2 py-2.5 text-center">
                <p className="text-[15px] font-bold text-chalk">{s.value}</p>
                <p className="mt-0.5 text-[10px] uppercase tracking-wide text-faint">{s.label}</p>
              </div>
            ))}
          </div>

          <div className="mt-4">
            <div className="mb-1.5 flex items-center justify-between text-[11px]">
              <span className="font-medium text-mute">Progresso de nível</span>
              <span className="tabular-nums text-faint">
                {lvl.xpIntoLevel} / {lvl.xpForLevel} XP
              </span>
            </div>
            <Progress value={lvl.progress} />
          </div>

          <div className="mt-5">
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-faint">
              Obras publicadas
            </p>
            {works.length === 0 ? (
              <p className="rounded-xl border border-dashed border-white/10 px-3 py-4 text-center text-[11.5px] text-faint">
                Nenhuma obra publicada ainda.
              </p>
            ) : (
              <div className="space-y-1.5">
                {works.slice(0, 4).map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenBook(b.id);
                    }}
                    className="flex w-full items-center gap-2.5 rounded-xl border border-white/[0.07] bg-ink-900/50 p-2 text-left transition-colors hover:border-hot-500/30 hover:bg-hot-500/[0.05]"
                  >
                    <img src={b.cover} alt="" className="h-12 w-9 shrink-0 rounded object-cover" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[12.5px] font-medium text-chalk">{b.title}</span>
                      <span className="block truncate text-[10.5px] text-faint">
                        {b.chapters.length} capítulos · {b.genres.join(', ')}
                      </span>
                    </span>
                    {b.rating > 0 && (
                      <span className="flex shrink-0 items-center gap-1 text-[11px] text-mute">
                        <Stars value={b.rating} size={10} />
                        {b.rating.toFixed(1)}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="mt-4 mb-4">
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-faint">
              Conquistas ({user.achievements.length}/{ACHIEVEMENTS.length})
            </p>
            <div className="flex flex-wrap gap-1.5">
              {ACHIEVEMENTS.filter((a) => user.achievements.includes(a.id)).map((a) => (
                <span
                  key={a.id}
                  title={a.description}
                  className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-ink-900/70 text-[15px]"
                >
                  {a.icon}
                </span>
              ))}
              {user.achievements.length === 0 && (
                <p className="text-[11.5px] text-faint">Nenhuma conquista desbloqueada.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   Busca global
   ══════════════════════════════════════════════════════════════════════════ */
export function SearchOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { db } = useStore();
  const navigate = useNavigate();
  const [q, setQ] = useState('');

  const term = q.trim().toLowerCase();
  const books = useMemo(
    () =>
      term
        ? db.books
            .filter(
              (b) =>
                b.title.toLowerCase().includes(term) ||
                b.authorName.toLowerCase().includes(term) ||
                b.genres.some((g) => g.toLowerCase().includes(term)),
            )
            .slice(0, 5)
        : db.books.filter((b) => b.featured).slice(0, 4),
    [db.books, term],
  );
  const users = useMemo(
    () =>
      term
        ? db.users
            .filter((u) => u.displayName.toLowerCase().includes(term) || u.bio.toLowerCase().includes(term))
            .slice(0, 4)
        : [],
    [db.users, term],
  );
  const communities = useMemo(
    () =>
      term
        ? db.communities
            .filter((c) => c.name.toLowerCase().includes(term) || c.description.toLowerCase().includes(term))
            .slice(0, 3)
        : db.communities.filter((c) => c.featured).slice(0, 3),
    [db.communities, term],
  );

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[92] flex items-start justify-center px-3 pt-[8vh]">
      <button type="button" aria-label="Fechar busca" onClick={onClose} className="absolute inset-0 bg-black/75 backdrop-blur-sm" />
      <motion.div
        initial={{ opacity: 0, y: -14, scale: 0.99 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        className="relative z-10 w-full max-w-2xl overflow-hidden rounded-2xl border border-white/10 bg-ink-800 shadow-lift"
      >
        <div className="flex items-center gap-2.5 border-b border-white/[0.07] px-4 py-3">
          <Search size={17} className="shrink-0 text-hot-400" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar obras, autores, comunidades, gêneros…"
            className="min-w-0 flex-1 bg-transparent text-[14px] text-chalk placeholder:text-faint focus:outline-none"
          />
          <button type="button" onClick={onClose} className="rounded p-1 text-faint hover:text-chalk" aria-label="Fechar">
            <X size={15} />
          </button>
        </div>

        <div className="max-h-[62dvh] overflow-y-auto p-3">
          {books.length > 0 && (
            <div className="mb-3">
              <p className="mb-1.5 px-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-faint">Obras</p>
              {books.map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => {
                    onClose();
                    navigate(`/obra/${b.id}`);
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-1.5 py-1.5 text-left transition-colors hover:bg-white/[0.05]"
                >
                  <img src={b.cover} alt="" className="h-11 w-8 rounded object-cover" />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[12.5px] font-medium text-chalk">{b.title}</span>
                    <span className="block truncate text-[10.5px] text-faint">
                      {b.authorName} · {b.genres[0]}
                    </span>
                  </span>
                </button>
              ))}
            </div>
          )}

          {users.length > 0 && (
            <div className="mb-3">
              <p className="mb-1.5 px-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-faint">Pessoas</p>
              {users.map((u) => (
                <button
                  key={u.uid}
                  type="button"
                  onClick={() => {
                    onClose();
                    navigate(`/perfil/${u.uid}`);
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-1.5 py-1.5 text-left transition-colors hover:bg-white/[0.05]"
                >
                  <Avatar src={u.photoURL} name={u.displayName} size={28} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[12.5px] font-medium text-chalk">{u.displayName}</span>
                    <span className="block truncate text-[10.5px] text-faint">{u.role}</span>
                  </span>
                </button>
              ))}
            </div>
          )}

          {communities.length > 0 && (
            <div>
              <p className="mb-1.5 px-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-faint">Comunidades</p>
              {communities.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    onClose();
                    navigate(`/social/comunidades/${c.id}`);
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-1.5 py-1.5 text-left transition-colors hover:bg-white/[0.05]"
                >
                  <img src={c.cover} alt="" className="h-8 w-12 rounded object-cover" />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[12.5px] font-medium text-chalk">{c.name}</span>
                    <span className="block truncate text-[10.5px] text-faint">
                      {c.members.length} membros · {c.privacy === 'public' ? 'pública' : 'privada'}
                    </span>
                  </span>
                </button>
              ))}
            </div>
          )}

          {books.length === 0 && users.length === 0 && communities.length === 0 && (
            <p className="px-2 py-8 text-center text-[12px] text-faint">
              Nada encontrado para “{q}”. Tente outro termo.
            </p>
          )}
        </div>
      </motion.div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   Gaveta de notificações
   ══════════════════════════════════════════════════════════════════════════ */
const NOTIF_ICON: Record<AppNotification['type'], string> = {
  like: '❤️',
  comment: '💬',
  follow: '👤',
  system: '⚙️',
  achievement: '🏆',
  payment: '💳',
  beta: '🧪',
};

export function NotificationsDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { db, currentUser, markNotificationRead, markAllNotificationsRead } = useStore();
  const navigate = useNavigate();
  const list = currentUser
    ? db.notifications.filter((n) => n.userId === currentUser.uid)
    : [];

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[93]">
          <motion.button
            type="button"
            aria-label="Fechar"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
          />
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 36 }}
            className="absolute right-0 top-0 flex h-full w-[min(94vw,380px)] flex-col border-l border-white/10 bg-ink-800"
          >
            <div className="flex items-center justify-between border-b border-white/[0.07] px-4 py-3.5">
              <div>
                <h3 className="text-[14px] font-semibold text-chalk">Notificações</h3>
                <p className="text-[10.5px] text-faint">
                  {list.filter((n) => !n.read).length} não lidas de {list.length}
                </p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={markAllNotificationsRead}
                  className="rounded-lg px-2 py-1 text-[10.5px] font-medium text-hot-300 hover:bg-hot-500/10"
                >
                  Marcar todas
                </button>
                <button type="button" onClick={onClose} className="rounded-lg p-1.5 text-faint hover:text-chalk" aria-label="Fechar">
                  <X size={16} />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-2.5">
              {list.length === 0 ? (
                <div className="px-3 py-14 text-center">
                  <p className="text-[12.5px] font-medium text-mute">Nenhuma notificação</p>
                  <p className="mt-1 text-[11px] text-faint">Novidades de leituras, comunidades e pagamentos aparecem aqui.</p>
                </div>
              ) : (
                list.map((n) => (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => {
                      markNotificationRead(n.id);
                      if (n.link) {
                        onClose();
                        navigate(n.link);
                      }
                    }}
                    className={cx(
                      'mb-1.5 flex w-full gap-2.5 rounded-xl border p-2.5 text-left transition-colors',
                      n.read
                        ? 'border-white/[0.05] bg-transparent hover:bg-white/[0.03]'
                        : 'border-hot-500/20 bg-hot-500/[0.06] hover:bg-hot-500/10',
                    )}
                  >
                    <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-ink-900 text-[14px]">
                      {NOTIF_ICON[n.type]}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-1.5">
                        <span className="truncate text-[12px] font-semibold text-chalk">{n.title}</span>
                        {!n.read && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-hot-500" />}
                      </span>
                      <span className="mt-0.5 block line-clamp-2 text-[11px] leading-snug text-mute">{n.body}</span>
                      <span className="mt-1 block text-[10px] text-faint">{timeAgo(n.createdAt)} atrás</span>
                    </span>
                  </button>
                ))
              )}
            </div>
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   Denúncias
   ══════════════════════════════════════════════════════════════════════════ */
const REPORT_REASONS = [
  'Conteúdo ofensivo ou discurso de ódio',
  'Spoiler sem aviso',
  'Plágio ou violação de direitos autorais',
  'Assédio ou ameaça',
  'Spam ou propaganda',
  'Conteúdo impróprio para a classificação indicativa',
  'Perfil falso',
];

export function ReportModal({
  open,
  onClose,
  targetType,
  targetId,
  targetLabel,
}: {
  open: boolean;
  onClose: () => void;
  targetType: 'book' | 'chapter' | 'comment' | 'post' | 'community' | 'user';
  targetId: string;
  targetLabel: string;
}) {
  const { createReport, currentUser } = useStore();
  const navigate = useNavigate();
  const [reason, setReason] = useState(REPORT_REASONS[0]!);
  const [details, setDetails] = useState('');

  if (!currentUser) {
    return (
      <Modal open={open} onClose={onClose} title="Entre para denunciar" size="sm">
        <p className="text-[12.5px] text-mute">A moderação da KORDEL exige uma conta identificada para evitar denúncias abusivas.</p>
        <button
          type="button"
          className={cx(btnPink, 'mt-4 w-full')}
          onClick={() => {
            onClose();
            navigate('/entrar');
          }}
        >
          Entrar
        </button>
      </Modal>
    );
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Denunciar conteúdo"
      subtitle={targetLabel}
      size="md"
      footer={
        <div className="flex gap-2">
          <button type="button" onClick={onClose} className={cx(btnGhost, 'flex-1')}>
            Cancelar
          </button>
          <button
            type="button"
            className={cx(btnPink, 'flex-1')}
            onClick={() => {
              createReport({ targetType, targetId, targetLabel, reason, details });
              setDetails('');
              onClose();
            }}
          >
            Enviar denúncia
          </button>
        </div>
      }
    >
      <div className="space-y-3">
        <div>
          <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wide text-faint">Motivo</label>
          <select value={reason} onChange={(e) => setReason(e.target.value)} className={inputCls}>
            {REPORT_REASONS.map((r) => (
              <option key={r} value={r} className="bg-ink-800">
                {r}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wide text-faint">
            Detalhes (opcional)
          </label>
          <textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            rows={4}
            placeholder="Descreva o problema para agilizar a análise."
            className={cx(inputCls, 'resize-none')}
          />
        </div>
        <p className="text-[10.5px] leading-relaxed text-faint">
          Denúncias falsas podem resultar em restrição da conta. A curadoria responde em até 48h.
        </p>
      </div>
    </Modal>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   Candidatura Beta
   ══════════════════════════════════════════════════════════════════════════ */
export function BetaApplyModal({
  book,
  onClose,
}: {
  book: Book | null;
  onClose: () => void;
}) {
  const { applyBeta, db, currentUser } = useStore();
  const [motivation, setMotivation] = useState('');
  if (!book) return null;
  const existing = db.betaApplications.find((a) => a.bookId === book.id && a.userId === currentUser?.uid);
  const approved = db.betaApplications.filter((a) => a.bookId === book.id && a.status === 'approved').length;

  return (
    <Modal
      open
      onClose={onClose}
      title="Candidatura para Leitura Beta"
      subtitle={book.title}
      footer={
        existing ? (
          <button type="button" onClick={onClose} className={cx(btnGhost, 'w-full')}>
            Fechar
          </button>
        ) : (
          <div className="flex gap-2">
            <button type="button" onClick={onClose} className={cx(btnGhost, 'flex-1')}>
              Cancelar
            </button>
            <button
              type="button"
              className={cx(btnPink, 'flex-1')}
              disabled={motivation.trim().length < 30}
              onClick={() => {
                if (applyBeta(book.id, motivation.trim())) {
                  setMotivation('');
                  onClose();
                }
              }}
            >
              Enviar candidatura
            </button>
          </div>
        )
      }
    >
      <div className="space-y-3">
        <div className="rounded-xl border border-hot-500/25 bg-hot-500/[0.07] p-3">
          <p className="text-[11.5px] leading-relaxed text-hot-100">
            <strong>Regras do autor:</strong> {book.betaRules || 'Sem regras adicionais.'}
          </p>
          <p className="mt-1.5 text-[10.5px] text-hot-300">
            {approved}/{book.betaSlots} vagas preenchidas
            {book.betaDeadline ? ` · prazo até ${new Date(book.betaDeadline).toLocaleDateString('pt-BR')}` : ''}
          </p>
        </div>

        {existing ? (
          <div className="rounded-xl border border-white/10 bg-ink-900/60 p-3">
            <p className="text-[12px] font-semibold text-chalk">
              Sua candidatura:{' '}
              {existing.status === 'pending' ? 'em análise' : existing.status === 'approved' ? 'aprovada' : 'não aprovada'}
            </p>
            <p className="mt-1 text-[11.5px] leading-relaxed text-mute">“{existing.motivation}”</p>
            {existing.status === 'approved' && (
              <p className="mt-2 text-[11px] text-[#86efac]">
                Os capítulos antecipados estão liberados no leitor. Envie seu feedback pela página da obra.
              </p>
            )}
          </div>
        ) : (
          <div>
            <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wide text-faint">
              Por que você quer ler esta obra em beta?
            </label>
            <textarea
              value={motivation}
              onChange={(e) => setMotivation(e.target.value)}
              rows={5}
              placeholder="Conte o que você lê, o que costuma observar e que tipo de feedback pretende dar. Mínimo 30 caracteres."
              className={cx(inputCls, 'resize-none')}
            />
            <p className="mt-1 text-right text-[10.5px] text-faint">{motivation.trim().length}/30</p>
          </div>
        )}
      </div>
    </Modal>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   Cartão de obra reutilizável
   ══════════════════════════════════════════════════════════════════════════ */
export function BookCard({
  book,
  onOpen,
  variant = 'grid',
}: {
  book: Book;
  onOpen: () => void;
  variant?: 'grid' | 'row' | 'carousel';
}) {
  const boosted = book.boostedUntil && new Date(book.boostedUntil) > new Date();
  if (variant === 'row') {
    return (
      <button
        type="button"
        onClick={onOpen}
        className="liquid-card liquid-card-hover flex w-full items-center gap-3 p-2.5 text-left"
      >
        <img src={book.cover} alt="" className="h-20 w-14 shrink-0 rounded-lg object-cover" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-semibold text-chalk">{book.title}</p>
          <p className="truncate text-[11px] text-mute">{book.authorName}</p>
          <div className="mt-1 flex items-center gap-1.5">
            <Stars value={book.rating} size={10} />
            <span className="text-[10.5px] text-faint">{book.rating.toFixed(1)}</span>
            <span className="text-[10.5px] text-faint">· {compact(book.readers)} leitores</span>
          </div>
        </div>
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={onOpen}
      className={cx(
        'group relative flex shrink-0 flex-col overflow-hidden rounded-2xl border border-white/[0.08] bg-ink-750 text-left transition-all hover:-translate-y-1 hover:border-hot-500/40 hover:shadow-[0_20px_50px_-22px_rgba(255,87,178,0.5)]',
        variant === 'carousel' ? 'w-[132px] sm:w-[144px]' : 'w-full',
      )}
    >
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-ink-900">
        <img
          src={book.cover}
          alt={book.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.045]"
        />
        <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/70 to-transparent" />
        {boosted && (
          <span className="absolute left-1.5 top-1.5 inline-flex items-center gap-1 rounded-full bg-hot-500 px-1.5 py-0.5 text-[9px] font-bold text-[#1a1a1a]">
            <TrendingUp size={9} /> BOOST
          </span>
        )}
        {book.betaMode && (
          <span className="absolute right-1.5 top-1.5 rounded-full border border-[#93c5fd]/40 bg-[#60a5fa]/20 px-1.5 py-0.5 text-[9px] font-bold text-[#bfdbfe] backdrop-blur">
            BETA
          </span>
        )}
        {book.status === 'completed' && (
          <span className="absolute bottom-1.5 left-1.5 rounded-full bg-black/60 px-1.5 py-0.5 text-[9px] font-semibold text-[#86efac] backdrop-blur">
            COMPLETA
          </span>
        )}
      </div>
      <div className="p-2">
        <p className="clamp-2 text-[12px] font-semibold leading-tight text-chalk">{book.title}</p>
        <p className="mt-0.5 truncate text-[10.5px] text-faint">{book.authorName}</p>
        {book.rating > 0 && (
          <div className="mt-1 flex items-center gap-1">
            <Stars value={book.rating} size={9} />
            <span className="text-[9.5px] text-faint">{book.rating.toFixed(1)}</span>
          </div>
        )}
      </div>
    </button>
  );
}

export function BookCarousel({
  books,
  onOpen,
  title,
}: {
  books: Book[];
  onOpen: (id: string) => void;
  title?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: -1 | 1) => {
    ref.current?.scrollBy({ left: dir * 320, behavior: 'smooth' });
  };
  return (
    <div className="relative">
      {title && (
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-[13px] font-semibold text-chalk">{title}</h3>
          <div className="flex gap-1">
            <button type="button" onClick={() => scroll(-1)} className="rounded-full border border-white/10 p-1 text-mute hover:text-chalk" aria-label="Anterior">
              <ChevronLeft size={13} />
            </button>
            <button type="button" onClick={() => scroll(1)} className="rounded-full border border-white/10 p-1 text-mute hover:text-chalk" aria-label="Próximo">
              <ChevronRight size={13} />
            </button>
          </div>
        </div>
      )}
      <div ref={ref} className="no-scrollbar flex gap-2.5 overflow-x-auto pb-1">
        {books.map((b) => (
          <BookCard key={b.id} book={b} onOpen={() => onOpen(b.id)} variant="carousel" />
        ))}
      </div>
    </div>
  );
}

