import { AnimatePresence, motion } from 'motion/react';
import { CheckCircle2, Info, TriangleAlert, XCircle, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../contexts/StoreContext';

const TONE = {
  info: { icon: Info, cls: 'text-[#93c5fd]', bar: 'bg-[#60a5fa]' },
  success: { icon: CheckCircle2, cls: 'text-[#86efac]', bar: 'bg-[#4ade80]' },
  warn: { icon: TriangleAlert, cls: 'text-[#fcd34d]', bar: 'bg-[#fbbf24]' },
  error: { icon: XCircle, cls: 'text-[#fca5a5]', bar: 'bg-[#f87171]' },
} as const;

export function ToastStack() {
  const { toasts, dismissToast } = useStore();
  const navigate = useNavigate();

  return (
    <div className="pointer-events-none fixed inset-x-0 top-[68px] z-[95] flex flex-col items-center gap-2 px-3">
      <AnimatePresence initial={false}>
        {toasts.map((t) => {
          const tone = TONE[t.tone];
          const Icon = tone.icon;
          return (
            <motion.div
              key={t.id}
              layout
              initial={{ opacity: 0, y: -14, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.98 }}
              transition={{ type: 'spring', stiffness: 420, damping: 32 }}
              className="pointer-events-auto w-full max-w-md overflow-hidden rounded-xl border border-white/10 bg-ink-800/95 shadow-lift backdrop-blur-xl"
            >
              <div className="flex items-start gap-2.5 px-3.5 py-3">
                <Icon size={17} className={`mt-0.5 shrink-0 ${tone.cls}`} />
                <button
                  type="button"
                  onClick={() => {
                    if (t.link) navigate(t.link);
                    dismissToast(t.id);
                  }}
                  className="min-w-0 flex-1 text-left"
                >
                  <p className="truncate text-[13px] font-semibold text-chalk">{t.title}</p>
                  {t.body && <p className="mt-0.5 text-[11.5px] leading-snug text-mute">{t.body}</p>}
                </button>
                <button
                  type="button"
                  onClick={() => dismissToast(t.id)}
                  className="rounded p-1 text-faint transition-colors hover:text-chalk"
                  aria-label="Dispensar"
                >
                  <X size={13} />
                </button>
              </div>
              <motion.div
                initial={{ width: '100%' }}
                animate={{ width: 0 }}
                transition={{ duration: 5.2, ease: 'linear' }}
                className={`h-[2px] ${tone.bar} opacity-70`}
              />
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
