import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell,
  BookOpen,
  Crown,
  Flame,
  Home,
  Library,
  LogOut,
  Menu,
  Search,
  Settings,
  Sparkles,
  Trophy,
  User as UserIcon,
  Users,
  X,
  Award,
  PenLine,
  ShieldCheck,
  ChevronDown,
} from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { useAuth } from '../contexts/AuthContext';
import { Avatar, Badge, btnPink, useClickOutside } from './ui';
import { levelFromXp } from '../lib/xp';
import { cx } from '../lib/utils';

export interface NavItem {
  to: string;
  label: string;
  icon: typeof Home;
  devOnly?: boolean;
}

export const NAV: NavItem[] = [
  { to: '/', label: 'Início', icon: Home },
  { to: '/explorar', label: 'Explorar', icon: Search },
  { to: '/social', label: 'Social', icon: Users },
  { to: '/biblioteca', label: 'Biblioteca', icon: Library },
  { to: '/ranking', label: 'Ranking', icon: Trophy },
  { to: '/conquistas', label: 'Conquistas', icon: Award },
  { to: '/assinaturas', label: 'Assinaturas', icon: Crown },
  { to: '/estudio', label: 'Estúdio', icon: PenLine },
  { to: '/dev', label: 'Área Dev', icon: ShieldCheck, devOnly: true },
];

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenNotifications: () => void;
  onOpenProfile: () => void;
  onOpenMenu?: () => void;
  immersive?: boolean;
}

export function Header({ onOpenSearch, onOpenNotifications, onOpenProfile, onOpenMenu, immersive }: HeaderProps) {
  const { db, currentUser } = useStore();
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [dropdown, setDropdown] = useState(false);
  const branding = db.branding;

  useClickOutside(() => setDropdown(false));

  const unread = useMemo(
    () => (currentUser ? db.notifications.filter((n) => n.userId === currentUser.uid && !n.read).length : 0),
    [db.notifications, currentUser],
  );
  const lvl = currentUser ? levelFromXp(currentUser.xp) : null;
  const hasSub = currentUser?.subscription.status === 'active';

  if (immersive) return null;

  return (
    <header className="sticky top-0 z-50 border-b border-white/[0.06] bg-ink-850/80 backdrop-blur-xl">
      <div className="mx-auto flex h-[58px] max-w-7xl items-center gap-2 px-3 sm:px-5">
        <button
          type="button"
          onClick={() => navigate('/')}
          className="group flex shrink-0 items-center gap-2"
          aria-label="Início"
        >
          {branding.logoUrl ? (
            <img src={branding.logoUrl} alt={branding.appName} className="h-8 w-8 rounded-lg object-cover" />
          ) : (
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-hot-500 to-hot-700 text-[15px] shadow-[0_0_18px_-6px_rgba(255,87,178,0.9)]">
              {branding.logoEmoji}
            </span>
          )}
          <span className="text-[15px] font-bold tracking-[0.14em] text-chalk transition-colors group-hover:text-hot-300">
            {branding.appName}
          </span>
        </button>

        <nav className="ml-3 hidden items-center gap-0.5 lg:flex">
          {NAV.filter((n) => !n.devOnly || currentUser?.role === 'desenvolvedor')
            .slice(0, 6)
            .map((n) => (
              <button
                key={n.to}
                type="button"
                onClick={() => navigate(n.to)}
                className="rounded-lg px-2.5 py-1.5 text-[13px] font-medium text-mute transition-colors hover:bg-white/[0.06] hover:text-chalk"
              >
                {n.label}
              </button>
            ))}
        </nav>

        <div className="ml-auto flex items-center gap-1">
          <button
            type="button"
            onClick={onOpenSearch}
            className="rounded-xl p-2 text-mute transition-colors hover:bg-white/[0.07] hover:text-chalk"
            aria-label="Busca global"
            title="Busca global"
          >
            <Search size={18} />
          </button>

          <button
            type="button"
            onClick={onOpenNotifications}
            className="relative rounded-xl p-2 text-mute transition-colors hover:bg-white/[0.07] hover:text-chalk"
            aria-label="Notificações"
            title="Notificações"
          >
            <Bell size={18} />
            {unread > 0 && (
              <span className="absolute right-1 top-1 grid min-w-[16px] place-items-center rounded-full bg-hot-500 px-1 text-[9.5px] font-bold leading-[15px] text-[#1a1a1a]">
                {unread > 9 ? '9+' : unread}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => navigate('/assinaturas')}
            className={cx(
              'relative rounded-xl p-2 transition-colors hover:bg-white/[0.07]',
              hasSub ? 'text-hot-400' : 'text-mute hover:text-chalk',
            )}
            aria-label="Assinaturas"
            title="Assinaturas"
          >
            <Crown size={18} />
            {hasSub && <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-hot-500" />}
          </button>

          {currentUser ? (
            <div className="relative ml-0.5" data-popover>
              <button
                type="button"
                onClick={() => setDropdown((v) => !v)}
                className="flex items-center gap-1 rounded-full p-0.5 transition-colors hover:bg-white/[0.07]"
                aria-label="Menu do usuário"
              >
                <Avatar src={currentUser.photoURL} name={currentUser.displayName} size={30} ring={hasSub} />
                <ChevronDown size={13} className="mr-1 hidden text-faint sm:block" />
              </button>

              {dropdown && (
                <div className="absolute right-0 top-[46px] w-64 overflow-hidden rounded-xl border border-white/10 bg-ink-800 shadow-lift">
                  <div className="border-b border-white/[0.07] px-3.5 py-3">
                    <p className="truncate text-[13px] font-semibold text-chalk">{currentUser.displayName}</p>
                    <p className="truncate text-[11px] text-mute">{currentUser.email}</p>
                    {lvl && (
                      <div className="mt-2 flex items-center gap-2">
                        <Badge tone="hot" icon={<Sparkles size={10} />}>
                          {lvl.levelLabel}
                        </Badge>
                        {currentUser.equippedTitle && <Badge tone="neutral">{currentUser.equippedTitle}</Badge>}
                      </div>
                    )}
                  </div>
                  <div className="py-1">
                    {[
                      { label: 'Meu perfil', icon: UserIcon, action: () => { setDropdown(false); onOpenProfile(); } },
                      { label: 'Biblioteca', icon: BookOpen, action: () => { setDropdown(false); navigate('/biblioteca'); } },
                      { label: 'Estúdio do Autor', icon: PenLine, action: () => { setDropdown(false); navigate('/estudio'); } },
                      { label: 'Conquistas', icon: Trophy, action: () => { setDropdown(false); navigate('/conquistas'); } },
                      { label: 'Assinaturas & Kards', icon: Crown, action: () => { setDropdown(false); navigate('/assinaturas'); } },
                      ...(currentUser.role === 'desenvolvedor'
                        ? [{ label: 'Área Dev', icon: Settings, action: () => { setDropdown(false); navigate('/dev'); } }]
                        : []),
                    ].map((it) => (
                      <button
                        key={it.label}
                        type="button"
                        onClick={it.action}
                        className="flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-[12.5px] text-mute transition-colors hover:bg-white/[0.06] hover:text-chalk"
                      >
                        <it.icon size={14} />
                        {it.label}
                      </button>
                    ))}
                  </div>
                  <div className="border-t border-white/[0.07] py-1">
                    <button
                      type="button"
                      onClick={async () => {
                        setDropdown(false);
                        await logout();
                        navigate('/');
                      }}
                      className="flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-[12.5px] text-[#fca5a5] transition-colors hover:bg-[#f87171]/10"
                    >
                      <LogOut size={14} />
                      Sair da conta
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button type="button" onClick={() => navigate('/entrar')} className={cx(btnPink, 'ml-1 !px-3.5 !py-1.5 !text-[12.5px]')}>
              Entrar
            </button>
          )}

          {onOpenMenu && (
            <button
              type="button"
              onClick={onOpenMenu}
              className="rounded-xl p-2 text-mute hover:text-chalk lg:hidden"
              aria-label="Menu"
            >
              <Menu size={18} />
            </button>
          )}
        </div>
      </div>
    </header>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   Floating Dock centralizado
   ══════════════════════════════════════════════════════════════════════════ */
export function FloatingDock() {
  const { currentUser } = useStore();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [open]);

  const items = NAV.filter((n) => !n.devOnly || currentUser?.role === 'desenvolvedor');

  return (
    <div ref={ref} className="fixed inset-x-0 bottom-6 z-[80] flex justify-center px-4">
      <div className="relative">
        {open && (
          <div className="absolute bottom-[62px] left-1/2 w-[min(88vw,420px)] -translate-x-1/2 rounded-2xl border border-white/10 bg-ink-800/95 p-2.5 shadow-lift backdrop-blur-xl">
            <div className="mb-1.5 flex items-center justify-between px-1.5">
              <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-faint">Navegar</p>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded p-0.5 text-faint hover:text-chalk"
                aria-label="Fechar menu"
              >
                <X size={13} />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {items.map((it) => (
                <button
                  key={it.to}
                  type="button"
                  onClick={() => {
                    navigate(it.to);
                    setOpen(false);
                  }}
                  className="group flex flex-col items-center gap-1.5 rounded-xl border border-transparent px-2 py-3 transition-all hover:border-hot-500/30 hover:bg-hot-500/[0.07]"
                >
                  <it.icon size={19} className="text-mute transition-colors group-hover:text-hot-400" />
                  <span className="text-[11px] font-medium text-mute transition-colors group-hover:text-chalk">
                    {it.label}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="dock-shell flex items-center gap-1 rounded-full border border-white/10 bg-ink-800/90 px-2 py-1.5 backdrop-blur-xl">
          <DockIcon icon={Home} label="Início" onClick={() => navigate('/')} />
          <DockIcon icon={Search} label="Explorar" onClick={() => navigate('/explorar')} />
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className={cx(
              'mx-0.5 grid h-11 w-11 place-items-center rounded-full bg-hot-500 text-[#1a1a1a] transition-all hover:bg-hot-600 active:scale-95',
              open ? 'pink-glow rotate-45' : 'pink-glow-soft',
            )}
            aria-label="Abrir todas as áreas"
          >
            {open ? <X size={19} strokeWidth={2.6} /> : <Flame size={19} strokeWidth={2.4} />}
          </button>
          <DockIcon icon={Users} label="Social" onClick={() => navigate('/social')} />
          <DockIcon icon={Library} label="Biblioteca" onClick={() => navigate('/biblioteca')} />
        </div>
      </div>
    </div>
  );
}

function DockIcon({ icon: Icon, label, onClick }: { icon: typeof Home; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group grid h-10 w-10 place-items-center rounded-full text-mute transition-colors hover:bg-white/[0.07] hover:text-chalk"
      aria-label={label}
      title={label}
    >
      <Icon size={18} />
    </button>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   Rodapé
   ══════════════════════════════════════════════════════════════════════════ */
export function Footer() {
  const { db } = useStore();
  const navigate = useNavigate();
  return (
    <footer className="mt-16 border-t border-white/[0.06] pb-28 pt-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
          <div className="max-w-sm">
            <div className="flex items-center gap-2">
              <span className="grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-br from-hot-500 to-hot-700 text-[13px]">
                {db.branding.logoEmoji}
              </span>
              <span className="text-[13px] font-bold tracking-[0.14em] text-chalk">{db.branding.appName}</span>
            </div>
            <p className="mt-2 text-[11.5px] leading-relaxed text-faint">{db.branding.description}</p>
          </div>
          <div className="flex flex-wrap gap-x-8 gap-y-3 text-[11.5px]">
            {[
              { label: 'Explorar', to: '/explorar' },
              { label: 'Comunidades', to: '/social/comunidades' },
              { label: 'Flux', to: '/social/flux' },
              { label: 'Ranking', to: '/ranking' },
              { label: 'Assinaturas', to: '/assinaturas' },
            ].map((l) => (
              <button
                key={l.to}
                type="button"
                onClick={() => navigate(l.to)}
                className="text-mute transition-colors hover:text-hot-400"
              >
                {l.label}
              </button>
            ))}
          </div>
        </div>
        <p className="mt-6 border-t border-white/[0.05] pt-4 text-[10.5px] text-faint">
          {db.branding.appName} © {new Date().getFullYear()} — plataforma de leitura independente. Feito para quem escreve na margem.
        </p>
      </div>
    </footer>
  );
}
