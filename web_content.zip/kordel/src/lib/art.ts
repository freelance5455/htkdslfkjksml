/**
 * Geradores de arte procedural (SVG inline → data URI).
 * Garantem capas, banners e avatares sem dependência de rede.
 */

const esc = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

export interface ArtPalette {
  a: string;
  b: string;
  c: string;
}

const PALETTES: ArtPalette[] = [
  { a: '#FF57B2', b: '#5A1036', c: '#1B1B1B' },
  { a: '#F5B841', b: '#7A3A12', c: '#191919' },
  { a: '#7FD1C7', b: '#134E4A', c: '#181C1C' },
  { a: '#B79CFF', b: '#2E1D5C', c: '#18181F' },
  { a: '#FF8A5B', b: '#5C1E12', c: '#1B1817' },
  { a: '#8FB8FF', b: '#152B55', c: '#171A20' },
  { a: '#F2E9DC', b: '#3B3229', c: '#1A1816' },
  { a: '#FF6B6B', b: '#4A1120', c: '#1A1517' },
];

export function paletteFor(seed: string): ArtPalette {
  return PALETTES[hash(seed) % PALETTES.length];
}

export function svgToDataUri(svg: string): string {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg.replace(/\s+/g, ' '))}`;
}

function wrapTitle(title: string, max: number): string[] {
  const words = title.split(/\s+/);
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    if ((cur + ' ' + w).trim().length > max && cur) {
      lines.push(cur.trim());
      cur = w;
    } else {
      cur = `${cur} ${w}`;
    }
  }
  if (cur.trim()) lines.push(cur.trim());
  return lines.slice(0, 4);
}

/** Capa 600×900 com textura de cordel, blocos geométricos e tipografia literária. */
export function coverArt(title: string, author: string, seed = title): string {
  const p = paletteFor(seed);
  const h = hash(seed);
  const lines = wrapTitle(title.toUpperCase(), 12);
  const startY = 560 - (lines.length - 1) * 32;
  const titleTspans = lines
    .map(
      (l, i) =>
        `<tspan x="52" dy="${i === 0 ? 0 : 62}">${esc(l)}</tspan>`,
    )
    .join('');
  const stripes = Array.from({ length: 9 }, (_, i) => {
    const y = 90 + i * 46 + (h % 13);
    return `<line x1="-40" y1="${y}" x2="640" y2="${y + 40}" stroke="${p.a}" stroke-opacity="${0.06 + (i % 3) * 0.025}" stroke-width="${1 + (i % 2)}"/>`;
  }).join('');
  const dots = Array.from({ length: 7 }, (_, i) => {
    const cx = 60 + ((h >> (i + 2)) % 480);
    const cy = 120 + ((h >> (i + 5)) % 380);
    return `<circle cx="${cx}" cy="${cy}" r="${1.6 + (i % 3)}" fill="${p.a}" fill-opacity="0.5"/>`;
  }).join('');

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="900" viewBox="0 0 600 900">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${p.c}"/>
      <stop offset="0.55" stop-color="${p.b}"/>
      <stop offset="1" stop-color="${p.c}"/>
    </linearGradient>
    <radialGradient id="glow" cx="0.7" cy="0.18" r="0.75">
      <stop offset="0" stop-color="${p.a}" stop-opacity="0.55"/>
      <stop offset="1" stop-color="${p.a}" stop-opacity="0"/>
    </radialGradient>
    <pattern id="grain" width="4" height="4" patternUnits="userSpaceOnUse">
      <rect width="4" height="4" fill="none"/>
      <circle cx="1" cy="1" r="0.6" fill="#fff" fill-opacity="0.05"/>
    </pattern>
  </defs>
  <rect width="600" height="900" fill="url(#bg)"/>
  <rect width="600" height="900" fill="url(#glow)"/>
  ${stripes}
  <g opacity="0.55">
    <circle cx="452" cy="212" r="132" fill="none" stroke="${p.a}" stroke-width="1.2" stroke-opacity="0.5"/>
    <circle cx="452" cy="212" r="92" fill="none" stroke="${p.a}" stroke-width="0.8" stroke-opacity="0.35"/>
    <path d="M320 212 L584 212 M452 80 L452 344 M358 118 L546 306 M546 118 L358 306" stroke="${p.a}" stroke-width="0.7" stroke-opacity="0.28"/>
    <circle cx="452" cy="212" r="14" fill="${p.a}" fill-opacity="0.8"/>
  </g>
  ${dots}
  <rect x="52" y="60" width="44" height="3" fill="${p.a}"/>
  <text x="52" y="96" font-family="Inter, Helvetica, sans-serif" font-size="13" letter-spacing="4.4" fill="${p.a}" fill-opacity="0.85">KORDEL</text>
  <text x="52" y="${startY}" font-family="Georgia, 'Times New Roman', serif" font-size="${lines.length > 3 ? 48 : 56}" font-weight="700" fill="#F7F3F1" letter-spacing="-0.5">${titleTspans}</text>
  <line x1="52" y1="${startY + lines.length * 62 + 14}" x2="188" y2="${startY + lines.length * 62 + 14}" stroke="${p.a}" stroke-width="2"/>
  <text x="52" y="${startY + lines.length * 62 + 52}" font-family="Inter, Helvetica, sans-serif" font-size="15" letter-spacing="2.4" fill="#F7F3F1" fill-opacity="0.72">${esc(author.toUpperCase().slice(0, 30))}</text>
  <rect width="600" height="900" fill="url(#grain)"/>
  <rect x="16" y="16" width="568" height="868" fill="none" stroke="#fff" stroke-opacity="0.1"/>
</svg>`;
  return svgToDataUri(svg);
}

/** Banner 1200×640 para comunidades e destaques. */
export function bannerArt(name: string, seed = name): string {
  const p = paletteFor(seed);
  const h = hash(seed);
  const arcs = Array.from({ length: 6 }, (_, i) => {
    const r = 90 + i * 78;
    return `<circle cx="${980 - (h % 90)}" cy="${120 + (h % 60)}" r="${r}" fill="none" stroke="${p.a}" stroke-opacity="${0.3 - i * 0.035}" stroke-width="1.4"/>`;
  }).join('');
  const bars = Array.from({ length: 14 }, (_, i) => {
    const x = 60 + i * 82;
    const hh = 30 + ((h >> (i % 12)) % 190);
    return `<rect x="${x}" y="${560 - hh}" width="${6 + (i % 3) * 5}" height="${hh}" fill="${p.a}" fill-opacity="${0.06 + (i % 4) * 0.03}" rx="3"/>`;
  }).join('');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="640" viewBox="0 0 1200 640">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${p.c}"/>
      <stop offset="1" stop-color="${p.b}"/>
    </linearGradient>
    <radialGradient id="gg" cx="0.82" cy="0.16" r="0.8">
      <stop offset="0" stop-color="${p.a}" stop-opacity="0.45"/>
      <stop offset="1" stop-color="${p.a}" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="1200" height="640" fill="url(#g)"/>
  <rect width="1200" height="640" fill="url(#gg)"/>
  ${bars}
  ${arcs}
  <text x="60" y="470" font-family="Inter, Helvetica, sans-serif" font-size="18" letter-spacing="6" fill="${p.a}">COMUNIDADE</text>
  <text x="60" y="540" font-family="Georgia, serif" font-size="64" font-weight="700" fill="#F7F3F1">${esc(name.slice(0, 26))}</text>
</svg>`;
  return svgToDataUri(svg);
}

/** Story Canvas 1080×1920 — usado no Flux quando não há mídia. */
export function storyArt(text: string, author: string): string {
  const p = paletteFor(author + text.slice(0, 12));
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    if ((cur + ' ' + w).trim().length > 17 && cur) {
      lines.push(cur.trim());
      cur = w;
    } else cur = `${cur} ${w}`;
  }
  if (cur.trim()) lines.push(cur.trim());
  const sliced = lines.slice(0, 9);
  const tspans = sliced
    .map((l, i) => `<tspan x="96" dy="${i === 0 ? 0 : 88}">${esc(l)}</tspan>`)
    .join('');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920" viewBox="0 0 1080 1920">
  <defs>
    <linearGradient id="s" x1="0" y1="0" x2="0.6" y2="1">
      <stop offset="0" stop-color="${p.b}"/>
      <stop offset="0.6" stop-color="${p.c}"/>
      <stop offset="1" stop-color="#141414"/>
    </linearGradient>
    <radialGradient id="sg" cx="0.2" cy="0.1" r="0.85">
      <stop offset="0" stop-color="${p.a}" stop-opacity="0.34"/>
      <stop offset="1" stop-color="${p.a}" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="1080" height="1920" fill="url(#s)"/>
  <rect width="1080" height="1920" fill="url(#sg)"/>
  <circle cx="880" cy="1580" r="420" fill="none" stroke="${p.a}" stroke-opacity="0.16" stroke-width="2"/>
  <circle cx="880" cy="1580" r="300" fill="none" stroke="${p.a}" stroke-opacity="0.12" stroke-width="2"/>
  <text x="96" y="200" font-family="Inter, sans-serif" font-size="26" letter-spacing="10" fill="${p.a}">FLUX</text>
  <text x="96" y="560" font-family="Georgia, serif" font-size="76" font-weight="600" fill="#F8F4F2">${tspans}</text>
  <text x="96" y="1760" font-family="Inter, sans-serif" font-size="30" letter-spacing="4" fill="#F8F4F2" fill-opacity="0.7">${esc(author)}</text>
</svg>`;
  return svgToDataUri(svg);
}

/** Avatar geométrico com iniciais (fallback sem rede). */
export function avatarArt(name: string): string {
  const p = paletteFor(name || 'kordel');
  const h = hash(name || 'k');
  const ini = (name || '?')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((x) => x[0]?.toUpperCase() ?? '')
    .join('');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
  <defs>
    <linearGradient id="av" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${p.b}"/>
      <stop offset="1" stop-color="${p.c}"/>
    </linearGradient>
  </defs>
  <rect width="200" height="200" fill="url(#av)"/>
  <circle cx="${140 + (h % 30)}" cy="${50 + (h % 30)}" r="84" fill="${p.a}" fill-opacity="0.2"/>
  <circle cx="${40 + (h % 40)}" cy="${170 - (h % 30)}" r="46" fill="${p.a}" fill-opacity="0.12"/>
  <text x="100" y="118" text-anchor="middle" font-family="Inter, Helvetica, sans-serif" font-size="74" font-weight="700" fill="#FBF7F5">${esc(ini || 'K')}</text>
</svg>`;
  return svgToDataUri(svg);
}
