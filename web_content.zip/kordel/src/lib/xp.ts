import type { AchievementDef, TitleDef } from '../types';

export const MAX_LEVEL = 33;
export const MAX_PRESTIGE = 3;

/** XP necessário para sair do nível informado (curva quadrática progressiva). */
export function xpForNextLevel(level: number): number {
  const l = Math.min(level, MAX_LEVEL);
  return Math.round(90 * Math.pow(l, 1.62) + 110 * l + 90);
}

/** XP acumulado necessário para alcançar o nível informado (1 = zero). */
export function cumulativeXpForLevel(level: number): number {
  let total = 0;
  for (let l = 1; l < level; l++) total += xpForNextLevel(l);
  return total;
}

export interface LevelState {
  level: number;
  prestige: number;
  xpIntoLevel: number;
  xpForLevel: number;
  progress: number;
  totalXp: number;
  levelLabel: string;
  isMax: boolean;
  nextCycleXp: number;
}

export function levelFromXp(totalXp: number): LevelState {
  const xp = Math.max(0, Math.floor(totalXp));
  const cycleXp = cumulativeXpForLevel(MAX_LEVEL + 1);
  const prestige = Math.min(MAX_PRESTIGE, Math.floor(xp / cycleXp));
  const inCycle = xp - prestige * cycleXp;

  let level = 1;
  let acc = 0;
  while (level < MAX_LEVEL && acc + xpForNextLevel(level) <= inCycle) {
    acc += xpForNextLevel(level);
    level += 1;
  }
  const xpForLevel = xpForNextLevel(level);
  const isMax = level >= MAX_LEVEL;
  return {
    level,
    prestige,
    xpIntoLevel: inCycle - acc,
    xpForLevel: isMax ? xpForLevel : xpForLevel,
    progress: isMax ? 100 : Math.min(100, Math.round(((inCycle - acc) / xpForLevel) * 100)),
    totalXp: xp,
    levelLabel: prestige > 0 ? `Nv. ${level} • Prestígio ${prestige}` : `Nível ${level}`,
    isMax,
    nextCycleXp: cycleXp,
  };
}

export const TITLES: TitleDef[] = [
  { id: 'aprendiz', name: 'Aprendiz de Versos', requirement: 'Disponível desde o início' },
  { id: 'leitor-constante', name: 'Leitor Constante', requirement: 'Alcance o nível 5', minLevel: 5 },
  { id: 'devorador', name: 'Devorador de Histórias', requirement: 'Alcance o nível 12', minLevel: 12 },
  { id: 'guardiao', name: 'Guardião do Cordel', requirement: 'Alcance o nível 20', minLevel: 20 },
  { id: 'mestre', name: 'Mestre Kordel', requirement: 'Alcance o nível 33', minLevel: 33 },
  { id: 'voz-comunidade', name: 'Voz da Comunidade', requirement: 'Alcance 500 XP em comunidade' },
  { id: 'autor-verificado', name: 'Autor Verificado', requirement: 'Assinatura Escritor ativa' },
];

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: 'primeira-pagina', name: 'Primeira Página', description: 'Conclua seu primeiro capítulo.', icon: '📖', category: 'leitura', xp: 40 },
  { id: 'leitor-experiente', name: 'Leitor Experiente', description: 'Conclua 5 obras na biblioteca.', icon: '🎓', category: 'leitura', xp: 120 },
  { id: 'maratona', name: 'Maratona Literária', description: 'Leia 10 capítulos em um único dia.', icon: '🏃', category: 'leitura', xp: 90 },
  { id: 'colecionador', name: 'Colecionador', description: 'Salve 10 obras para ler depois.', icon: '🔖', category: 'leitura', xp: 70 },
  { id: 'critico', name: 'Olhar Crítico', description: 'Publique 3 avaliações com estrelas.', icon: '⭐', category: 'leitura', xp: 60 },
  { id: 'primeira-obra', name: 'Tinta no Papel', description: 'Publique sua primeira obra.', icon: '✍️', category: 'escrita', xp: 150 },
  { id: 'serial', name: 'Autor Serial', description: 'Publique 5 capítulos em uma obra.', icon: '📚', category: 'escrita', xp: 110 },
  { id: 'beta-host', name: 'Anfitrião Beta', description: 'Aprove 3 leitores beta.', icon: '🧪', category: 'escrita', xp: 130 },
  { id: 'impulsionado', name: 'Em Alta', description: 'Use seu primeiro impulsionamento.', icon: '🚀', category: 'escrita', xp: 80 },
  { id: 'fundador', name: 'Fundador', description: 'Crie sua primeira comunidade.', icon: '🏛️', category: 'comunidade', xp: 100 },
  { id: 'voz-ativa', name: 'Voz Ativa', description: 'Publique 10 posts no Flux.', icon: '💬', category: 'comunidade', xp: 120 },
  { id: 'moderador', name: 'Mão na Massa', description: 'Atue como moderador de uma comunidade.', icon: '🛡️', category: 'comunidade', xp: 90 },
  { id: 'assinante', name: 'Apoiador do Cordel', description: 'Ative uma assinatura.', icon: '👑', category: 'assinatura', xp: 200 },
];

export const BADGES = [
  { id: 'leitor-experiente', label: 'Leitor Experiente', icon: '🎓', tone: 'hot' as const },
  { id: 'escritor-verificado', label: 'Escritor Verificado', icon: '✅', tone: 'info' as const },
  { id: 'assinante', label: 'Assinante', icon: '👑', tone: 'warn' as const },
  { id: 'fundador', label: 'Fundador', icon: '🏛️', tone: 'ok' as const },
  { id: 'beta', label: 'Leitor Beta', icon: '🧪', tone: 'info' as const },
];

export function badgesForSubscription(plan: string): string[] {
  if (plan === 'reader') return ['leitor-experiente', 'assinante'];
  if (plan === 'writer') return ['escritor-verificado', 'assinante', 'leitor-experiente'];
  return [];
}

export const XP_REWARDS = {
  chapterComplete: 35,
  chapterComment: 12,
  likePost: 3,
  createPost: 25,
  createCommunity: 60,
  reviewBook: 20,
  followUser: 5,
  betaFeedback: 45,
};

export const PLANS = [
  {
    id: 'reader' as const,
    name: 'Assinatura Leitor',
    price: 4.9,
    tagline: 'Leia à frente de todos.',
    perks: [
      'Gamificação completa: XP, níveis e ranking semanal',
      'Capítulos antecipados exclusivos',
      'Acesso a obras em Leitura Beta',
      'Selo Leitor Experiente no perfil',
    ],
  },
  {
    id: 'writer' as const,
    name: 'Assinatura Escritor',
    price: 13.49,
    tagline: 'Publique com alcance.',
    perks: [
      'Selo Escritor Verificado',
      '2 impulsionamentos por mês (7 dias cada)',
      'Criação de 1 comunidade exclusiva por ciclo',
      'Conquistas exclusivas de autor',
      'Tudo da Assinatura Leitor',
    ],
  },
];
