/** Cliente do backend Express (upload de mídia, Pix, Stripe, health). */

export interface UploadResult {
  ok: boolean;
  url: string;
  folder: string;
  filename: string;
  mime: string;
  size: number;
  backedUp: boolean;
}

export async function uploadMedia(
  dataUrl: string,
  folder: 'avatars' | 'covers' | 'posts' | 'banners' | 'audios',
  filename?: string,
): Promise<UploadResult> {
  const res = await fetch('/api/upload', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ file: dataUrl, folder, filename }),
  });
  const json = (await res.json()) as UploadResult & { error?: string };
  if (!res.ok || json.error) throw new Error(json.error ?? 'Falha no upload.');
  return json;
}

export interface PixChargeResponse {
  ok: boolean;
  plan: 'reader' | 'writer';
  payload: string;
  amount: number;
  txid: string;
  key: string;
  merchant: string;
  city: string;
  expiresIn: number;
}

export async function createPixCharge(plan: 'reader' | 'writer'): Promise<PixChargeResponse> {
  const res = await fetch('/api/create-pix-charge', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ plan }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error ?? 'Falha ao gerar Pix.');
  return json as PixChargeResponse;
}

export async function verifyPixReceipt(input: {
  e2eid: string;
  plan: 'reader' | 'writer';
  userId: string;
  amount: number;
}): Promise<{ ok: boolean; orderId: string; message: string }> {
  const res = await fetch('/api/verify-pix-receipt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error ?? 'Comprovante recusado.');
  return json;
}

export async function createStripeCheckout(input: {
  plan: 'reader' | 'writer';
  userId: string;
  email?: string;
}): Promise<{ ok: boolean; url?: string; sessionId?: string; error?: string; simulated?: boolean }> {
  const res = await fetch('/api/create-stripe-checkout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
  return (await res.json()) as { ok: boolean; url?: string; sessionId?: string; error?: string; simulated?: boolean };
}

export async function verifyStripePayment(sessionId: string) {
  const res = await fetch('/api/verify-stripe-payment', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sessionId }),
  });
  return (await res.json()) as {
    ok: boolean;
    plan?: string;
    userId?: string | null;
    paymentStatus?: string;
    error?: string;
  };
}

export async function apiHealth() {
  try {
    const res = await fetch('/api/health');
    if (!res.ok) return null;
    return (await res.json()) as {
      ok: boolean;
      app: string;
      version: string;
      env: string;
      uptime: number;
      integrations: { firebaseAdmin: boolean; stripe: boolean; pix: boolean };
    };
  } catch {
    return null;
  }
}

/** Gera QR Code (PNG data URL) localmente a partir do payload Pix. */
export async function pixQrDataUrl(payload: string): Promise<string> {
  const { default: QRCode } = await import('qrcode');
  return QRCode.toDataURL(payload, {
    errorCorrectionLevel: 'M',
    margin: 1,
    width: 512,
    color: { dark: '#141414', light: '#FFFFFF' },
  });
}
