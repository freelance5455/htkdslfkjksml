export type Role = 'leitor' | 'escritor' | 'desenvolvedor';

export type AgeRating = 'Livre' | '12+' | '14+' | '16+' | '18+';

export type Genre =
  | 'Cordel'
  | 'Romance'
  | 'Fantasia'
  | 'Ficção Científica'
  | 'Suspense & Mistério'
  | 'Poesia'
  | 'Folclore & Lendas'
  | 'Drama'
  | 'Aventura';

export const GENRES: Genre[] = [
  'Cordel',
  'Romance',
  'Fantasia',
  'Ficção Científica',
  'Suspense & Mistério',
  'Poesia',
  'Folclore & Lendas',
  'Drama',
  'Aventura',
];

export const AGE_RATINGS: AgeRating[] = ['Livre', '12+', '14+', '16+', '18+'];

export type BookStatus = 'draft' | 'published' | 'completed';

export type PlanId = 'free' | 'reader' | 'writer';

export interface Subscription {
  plan: string;
  status: 'active' | 'canceled' | 'none';
  renewsAt: string | null;
  method?: 'pix' | 'card' | 'granted';
  grantedBy?: string;
}

export interface AppUser {
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
  bio: string;
  role: Role;
  xp: number;
  kards: number;
  subscription: Subscription;
  badges: string[];
  achievements: string[];
  titles: string[];
  equippedTitle: string | null;
  followers: number;
  following: number;
  banned: boolean;
  createdAt: string;
  boostsAvailable: number;
  boostsResetAt: string;
}

export interface Chapter {
  id: string;
  number: number;
  title: string;
  content: string;
  status: 'draft' | 'published';
  earlyAccess: boolean;
  createdAt: string;
  reads: number;
  comments: ChapterComment[];
}

export interface ChapterComment {
  id: string;
  parentId: string | null;
  userId: string;
  userName: string;
  userPhoto: string;
  content: string;
  createdAt: string;
  editedAt?: string | null;
  likes: number;
  repliedTo?: string | null;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  userPhoto: string;
  rating: number;
  text: string;
  createdAt: string;
}

export interface Book {
  id: string;
  title: string;
  synopsis: string;
  cover: string;
  genres: Genre[];
  ageRating: AgeRating;
  status: BookStatus;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  betaMode: boolean;
  betaSlots: number;
  betaRules: string;
  betaDeadline: string | null;
  readers: number;
  views: number;
  likes: number;
  rating: number;
  ratingCount: number;
  chapters: Chapter[];
  reviews: Review[];
  featured: boolean;
  boostedUntil: string | null;
  createdAt: string;
  updatedAt: string;
}

export type LibraryStatus = 'reading' | 'completed' | 'saved' | 'favorite';

export interface LibraryItem {
  bookId: string;
  status: LibraryStatus;
  progress: number;
  lastChapterId: string | null;
  updatedAt: string;
}

export type CommunityRole = 'creator' | 'moderator' | 'partial_moderator' | 'member';
export type ModerationState = 'active' | 'silenced' | 'banned';

export interface CommunityMember {
  userId: string;
  userName: string;
  userPhoto: string;
  role: CommunityRole;
  moderation: ModerationState;
  joinedAt: string;
}

export interface Community {
  id: string;
  name: string;
  description: string;
  cover: string;
  privacy: 'public' | 'private';
  creatorId: string;
  creatorName: string;
  members: CommunityMember[];
  tags: string[];
  featured: boolean;
  createdAt: string;
}

export interface PollOption {
  id: string;
  text: string;
  votes: string[];
}

export type PostType = 'text' | 'image' | 'video' | 'carousel' | 'poll' | 'story';

export interface Post {
  id: string;
  communityId: string | null;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  type: PostType;
  text: string;
  media: string[];
  poll: { question: string; options: PollOption[]; closesAt?: string | null } | null;
  audioUrl: string | null;
  likes: string[];
  savedBy: string[];
  comments: PostComment[];
  createdAt: string;
  views: number;
  communityName?: string | null;
}

export interface PostComment {
  id: string;
  parentId: string | null;
  userId: string;
  userName: string;
  userPhoto: string;
  content: string;
  createdAt: string;
  likes: number;
  editedAt?: string | null;
}

export interface BetaApplication {
  id: string;
  bookId: string;
  bookTitle: string;
  userId: string;
  userName: string;
  userPhoto: string;
  motivation: string;
  status: 'pending' | 'approved' | 'rejected';
  feedback: string | null;
  feedbackStatus?: 'none' | 'submitted';
  createdAt: string;
}

export type NotificationType = 'like' | 'comment' | 'follow' | 'system' | 'achievement' | 'payment' | 'beta';

export interface AppNotification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  body: string;
  read: boolean;
  link: string | null;
  createdAt: string;
}

export interface KardsTransaction {
  id: string;
  userId: string;
  amount: number;
  type: 'credit' | 'debit';
  description: string;
  createdAt: string;
}

export interface Report {
  id: string;
  targetType: 'book' | 'chapter' | 'comment' | 'post' | 'community' | 'user';
  targetId: string;
  targetLabel: string;
  reason: string;
  details: string;
  reporterId: string;
  reporterName: string;
  status: 'open' | 'resolved' | 'dismissed';
  createdAt: string;
}

export interface PixOrder {
  id: string;
  userId: string;
  userName: string;
  plan: 'reader' | 'writer';
  amount: number;
  e2eid: string | null;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorName: string;
  action: string;
  target: string;
  createdAt: string;
}

export interface Branding {
  appName: string;
  tagline: string;
  description: string;
  logoEmoji: string;
  logoUrl: string | null;
  featuredBookIds: string[];
  featuredCommunityIds: string[];
}

export interface AchievementDef {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'leitura' | 'escrita' | 'comunidade' | 'assinatura';
  xp: number;
}

export interface TitleDef {
  id: string;
  name: string;
  requirement: string;
  minLevel?: number;
}

export interface ToastMsg {
  id: string;
  title: string;
  body?: string;
  tone: 'info' | 'success' | 'warn' | 'error';
  link?: string | null;
}
