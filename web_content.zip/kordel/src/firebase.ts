import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';

const cfg = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY as string | undefined,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID as string | undefined,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET as string | undefined,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined,
  appId: import.meta.env.VITE_FIREBASE_APP_ID as string | undefined,
};

/**
 * A aplicação roda em dois modos:
 *  - `live`: Firebase configurado (.env com VITE_FIREBASE_*), autenticação e Firestore reais.
 *  - `demo`: sem configuração, o AuthProvider usa sessão local e o store persiste em localStorage.
 * O mesmo contrato de dados é usado pelos dois modos.
 */
export const isFirebaseConfigured = Boolean(
  cfg.apiKey && cfg.projectId && cfg.authDomain && cfg.appId,
);

export const firebaseMode: 'live' | 'demo' = isFirebaseConfigured ? 'live' : 'demo';

let app: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;

if (isFirebaseConfigured) {
  try {
    app = getApps().length ? getApps()[0]! : initializeApp(cfg as Required<typeof cfg>);
    authInstance = getAuth(app);
    dbInstance = getFirestore(app);
  } catch (err) {
    console.warn('[KORDEL] Falha ao inicializar Firebase, seguindo em modo demo.', err);
    app = null;
    authInstance = null;
    dbInstance = null;
  }
}

export const firebaseApp = app;
export const firebaseAuth = authInstance;
export const firestore = dbInstance;

export const DEV_EMAIL = (import.meta.env.VITE_DEV_EMAIL as string | undefined) ?? 'dev@kordel.app';

export const collections = {
  users: 'users',
  books: 'books',
  chapters: 'chapters',
  reviews: 'reviews',
  libraries: 'libraries',
  libraryItems: 'items',
  communities: 'communities',
  members: 'members',
  posts: 'posts',
  comments: 'comments',
  fluxPosts: 'fluxPosts',
  favoritePosts: 'favoritePosts',
  betaApplications: 'betaApplications',
  transactions: 'transactions',
  notifications: 'notifications',
  reports: 'reports',
  auditLogs: 'auditLogs',
  settings: 'settings',
  pixOrders: 'pixOrders',
  usedPixReceipts: 'usedPixReceipts',
  follows: 'follows',
  storageImages: 'storageImages',
} as const;
