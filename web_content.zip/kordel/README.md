# 🎻 KORDEL

**Plataforma de leitura, publicação independente, comunidades literárias e rede social vertical.**
Português (pt-BR) · React 19 + TypeScript + Vite + Tailwind CSS v4 · Node.js + Express · Firebase (Firestore + Auth)

---

## 1. O que é

KORDEL reúne leitura imersiva, publicação independente (cordel, romance, fantasia, ficção científica, suspense, poesia, folclore, drama, aventura), comunidades literárias com moderação por papéis e um feed vertical estilo Reels (`Flux`) — tudo em dark charcoal com acento Hot Pink.

**Módulos implementados**

| Área | Rota | Destaques |
|---|---|---|
| Início | `/` | Carrossel Destaques da Semana (autoplay, setas, indicadores, swipe), Continuar Lendo sincronizado, Populares, Lançamentos, vitrine Beta com vagas/prazo, carrossel de Comunidades, prévia do Ranking |
| Explorar | `/explorar` | Busca por título/autor/sinopse/gênero, 9 gêneros, 5 classificações indicativas, ordenação, filtros beta/completas |
| Detalhes da obra | `/obra/:bookId` | Capa, sinopse, métricas, capítulos com trava de antecipado, avaliações com estrelas, candidatura Beta |
| Leitor | `/ler/:bookId/:chapterId` | Tema escuro confortável, fonte 14–30px, Literata/Sans/Serif, gaveta de capítulos, progresso automático, XP por capítulo, comentários aninhados com editar/excluir/denunciar |
| Biblioteca | `/biblioteca` | Lendo / Concluídos / Salvos / Favoritos com % de progresso + Posts Favoritos |
| Estúdio | `/estudio` | CRUD de obras, editor de capítulos (rascunho/publicado/antecipado), gestão de candidatos Beta + feedbacks, Boost de 7 dias, estatísticas |
| Social | `/social` | Sub-nav pílula INÍCIO / COMUNIDADES / FLUX |
| Comunidades | `/social/comunidades` | Criar públicas/privadas, papéis `creator`/`moderator`/`partial_moderator`/`member`, moderação `silenced`/`banned`, posts texto/imagem/carrossel/vídeo/enquete, comentários aninhados |
| Flux | `/social/flux` | Feed 100dvh com scroll-snap e `motion/react`, texto/imagem/carrossel/vídeo/Story Canvas com áudio, curtir/salvar/compartilhar (`?flux=id`), comentários |
| Criar Flux | `/social/flux/criar` | Seletor de formato + prévia 9:16 |
| Ranking | `/ranking` | Semanal / Geral / Autores, marcos de nível, tabela de XP |
| Conquistas | `/conquistas` | 13 conquistas em 4 categorias, títulos equipáveis, curva quadrática até nível 33 + prestígio |
| Assinaturas | `/assinaturas` | Leitor R$ 4,90 e Escritor R$ 13,49, checkout Pix (QR + copia-e-cola) e Stripe, carteira Kards com trilha de transações |
| Área Dev | `/dev` | Branding em tempo real, usuários (Kards, assinatura, ban), destaques, pedidos Pix, denúncias, conteúdo, logs de auditoria |

## 2. Rodar localmente

```bash
npm install
cp .env.example .env      # opcional: sem Firebase, o app roda em modo demonstração
npm run dev               # Express + Vite middleware em http://localhost:3000
```

Build de produção:

```bash
npm run build             # tsc --noEmit && vite build
npm start                 # NODE_ENV=production tsx server.ts (serve /dist)
```

### Modo demonstração vs. modo Firebase

- **Sem** `VITE_FIREBASE_*` no `.env`: `firebaseMode = 'demo'`. A sessão e os dados persistem em `localStorage` (chave `kordel.db.v1`), com seed completo (6 usuários, 9 obras, 3 comunidades, 6 Flux). Na tela `/entrar`, use os perfis prontos: **Desenvolvedor** (`dev@kordel.app`), **Escritora** (`marina@kordel.app`), **Escritor** (`joao@kordel.app`), **Leitor** (`rafa@kordel.app`).
- **Com** as chaves: Firebase Auth real (Google popup + e-mail/senha) e Firestore. O contrato de dados é o mesmo; o provider de estado é o único ponto a trocar por leitores/escritores do Firestore.

## 3. Firebase

1. Crie um projeto, ative **Authentication** (Google + E-mail/senha) e **Firestore**.
2. Preencha `.env` com as chaves web (`VITE_FIREBASE_*`) e o e-mail admin em `VITE_DEV_EMAIL`.
3. Publique as regras: `firebase deploy --only firestore:rules` (arquivo `firestore.rules`).

As regras derivam o papel **sempre** do documento `users/{uid}` do próprio requisitante (`myDoc().role`), nunca de um campo enviado no request — impedindo escalonamento de privilégio. Resumo:

- `users`: leitura pública; o dono só edita perfil/gamificação (`displayName`, `photoURL`, `bio`, `xp`, `kards`…), jamais `role`, `banned` ou `subscription`. Só `desenvolvedor` escreve esses campos.
- `books` / `chapters`: autor gerencia apenas as próprias obras e capítulos; `earlyAccess` exige assinatura ativa.
- `communities`: privadas invisíveis a não membros; publicação exige ser membro e não estar silenciado/banido; criador/moderador moderam.
- `libraries/{userId}/items`: exclusivo do dono (e dev).
- `transactions`, `pixOrders`, `usedPixReceipts`, `auditLogs`: escrita só admin/backend.
- `auditLogs`: append-only (`update, delete: if false`).

## 4. Backend (`server.ts`, porta 3000)

| Rota | Descrição |
|---|---|
| `GET /api/health` | status, uptime e integrações ativas |
| `POST /api/upload` | recebe base64, grava em `public/uploads/{avatars,covers,posts,banners,audios}` e faz backup em `storageImages` no Firestore |
| `GET /uploads/:folder/:filename` | serve o arquivo local; se não existir (container reiniciado), restaura do Firestore |
| `POST /api/create-pix-charge` | gera BR Code EMV com CRC16-CCITT/FALSE |
| `POST /api/verify-pix-receipt` | valida formato do E2EID, bloqueia reuso (`usedPixReceipts`) e cria `pixOrders` pendente |
| `POST /api/create-stripe-checkout` | sessão de assinatura Stripe, retorno em `?stripe_success=true&session_id=...` |
| `POST /api/verify-stripe-payment` | confirma a sessão no Stripe |

**Sobre o Pix:** o payload segue o padrão EMV® QRCPS-MPM (IDs 00, 01, 26, 52, 53, 54, 58, 59, 60, 62 + CRC16). Não há integração com PSP/banco neste repositório, portanto **não é possível conferir a liquidação real de um comprovante**. Por isso o fluxo implementa (a) validação de formato do E2EID (`E + ISPB(8) + AAAAMMDDHHMM(12) + 11 alfanuméricos`), (b) deduplicação anti-fraude em `usedPixReceipts` e (c) **aprovação manual** no Painel do Desenvolvedor → aba *Pedidos Pix*. Para produção, troque a etapa (c) por webhook do PSP.

## 5. Estrutura de dados (Firestore)

```
users/{uid}
  ├── favoritePosts/{postId}
  └── private/{docId}
books/{bookId}
  ├── chapters/{chapterId}/comments/{commentId}
  └── reviews/{reviewId}
libraries/{userId}/items/{bookId}
communities/{communityId}
  ├── members/{userId}
  └── posts/{postId}/comments/{commentId}
fluxPosts/{postId}/comments/{commentId}
betaApplications · transactions · notifications · reports · auditLogs
settings · pixOrders · usedPixReceipts · follows · storageImages
```

## 6. Assinaturas

| Plano | Preço | Libera |
|---|---|---|
| **Leitor** | R$ 4,90/mês | gamificação/XP/ranking, capítulos antecipados, obras beta, selo *Leitor Experiente* |
| **Escritor** | R$ 13,49/mês | selo *Escritor Verificado*, 2 impulsionamentos/mês (7 dias cada), 1 comunidade exclusiva por ciclo, conquistas de autor — inclui o plano Leitor |

## 7. Gamificação

XP com curva quadrática progressiva (`90·L^1.62 + 110·L + 90`) até o **nível 33**, com até 3 ciclos de prestígio. Recompensas: capítulo concluído (+35), comentário (+12), post (+25), comunidade (+60), avaliação (+20), feedback beta (+45), seguir (+5), curtir (+3). 13 conquistas e 7 títulos equipáveis.

## 8. Android (Capacitor)

`capacitor.config.json` já aponta `webDir: "dist"`.

```bash
npm i -D @capacitor/cli && npm i @capacitor/core @capacitor/android
npm run build
npx cap add android && npx cap sync android
npx cap open android
```

## 9. Design system

- Fundo `#202020` / `#1A1A1A`; cards `.liquid-card` em `#262626` com borda `rgba(255,255,255,0.08)`, raio `1.25rem` e glow Hot Pink no hover.
- Acento `#FF57B2` (hover `#FF40A4`, ativo `#E03595`) com `.pink-glow`; seleção de texto em Hot Pink.
- `Inter` para UI, `Literata` para leitura/sinopses; atmosfera com brilhos radiais + grão sutil.
- Header minimalista (logo/nome customizável, busca global, notificações com badge, coroa de assinaturas, avatar com dropdown) e **Floating Dock** central em `bottom-6` que expande a grade com todas as áreas. Header, rodapé, dock e sub-nav ficam ocultos no Leitor e no Flux imersivo.

## 10. Estrutura de arquivos

```
server.ts                     Express + Vite middleware, uploads, Pix, Stripe
firestore.rules               Regras de segurança por papel
capacitor.config.json         Empacotamento Android
src/
  App.tsx  main.tsx  index.css  types.ts  firebase.ts
  contexts/ StoreContext.tsx  AuthContext.tsx
  components/ Header.tsx  Modals.tsx  ToastStack.tsx  ui.tsx
  lib/ api.ts  art.ts  seed.ts  utils.ts  xp.ts
  views/ HomeView  ExploreBooksView  BookDetailsView  ReaderView  LibraryView
         AuthorStudioView  SocialView  SocialHomeView  CommunitiesView
         CommunityDetailView  FluxView  FluxCreatorView  RankingView
         AchievementsView  SubscriptionsView  DeveloperAdminView
         LoginView  ProfilePage
```

---

Feito para quem escreve na margem. 🎻
