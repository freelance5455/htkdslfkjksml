PAPA ENGINEERING Calculator update

- Shaft 1/2/3 steps: દરેક step નો diameter અને length નાખો. બંને છેડે સરખી step design ગણાય છે.
- Hard Chrome, Grinding, Rubber Coating અલગ checkbox.
- Area = Roller Diameter × Roller Length ÷ 205 (sq. inch).
- Hard Chrome default ₹5/sq. inch. Grinding અને Rubber rate જાતે નાખવાના.
- Material અને finishing cost નો final total.

Android એપ તરીકે install કરવા HTTPS hosting પર આ ફોલ્ડર upload કરવું જરૂરી છે.

Shafting update: Left Side અને Right Side માટે 1, 2 અથવા 3 Steps અલગથી પસંદ કરો. દરેક step નો Diameter અને Length અલગથી નાખો. બંને બાજુની ગણતરી સ્વતંત્ર થાય છે.
