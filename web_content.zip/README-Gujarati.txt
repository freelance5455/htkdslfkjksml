PAPA ENGINEERING – Roller Weight & Quotation Calculator

આ અપડેટમાં થયેલા મુખ્ય સુધારા:
1. Calculator શરૂ થતો અટકાવતી JavaScript ભૂલ દૂર કરી છે (જૂના code માં ન હોય તેવા slLabel element ને access કરાતું હતું).
2. Left Side અને Right Side shaft ના 1/2/3 steps અલગ-અલગ ગણાય છે.
3. Hard Chrome, Grinding અને Rubber Coating ના rate પ્રતિ sq.inch પ્રમાણે item-wise બતાવે છે.
4. Quotation માં roller specification, weight breakup, quantity, material cost, finishing cost અને grand total અલગ બતાવે છે.
5. WhatsApp share માટે પહેલા ફોનનું Share Sheet ખૂલે છે; ત્યાં WhatsApp અથવા WhatsApp Business પસંદ કરી શકાય છે. જો Share Sheet ઉપલબ્ધ ન હોય તો WhatsApp link ખોલવાનો પ્રયાસ થાય છે.
6. Logo, manifest અને offline cache support સામેલ છે.

મહત્વપૂર્ણ:
- ZIP ને સીધું APK તરીકે install કરી શકાતું નથી. ZIP extract કરીને તેની અંદરની બધી ફાઇલો એક જ folder માં રાખો.
- APK બનાવતા WebView/App Builder માં external links / open links outside app / external intents ને allow કરો. નહીં તો WhatsApp app ખુલી શકશે નહીં.
- APK Builder માં Start URL તરીકે index.html રાખો.
- આ Calculator બે અલગ stub shafts (Left અને Right) માટે છે. One-piece through shaft આ આવૃત્તિમાં સામેલ નથી.
- Hard Chrome નો default rate ₹5/sq.inch છે. Grinding અને Rubber rate તમે ભરી શકો છો.

ફોનમાં APK બનાવતા પહેલાં index.html ને Chrome માં ખોલીને ગણતરી અને Share button ચકાસો.
