# Kodla

## 1) Sunucu (Canlı Ders ve Dönüştür için)
Node 18+ olan bir yere yükle (Render, Railway, Fly.io...).
Ortam değişkenleri: ANTHROPIC_API_KEY (zorunlu), APP_TOKEN (uygulama şifresi, öneririm).
Başlat: node server/server.js

## 2) APK derleme (GitHub, ücretsiz)
1. github.com'da yeni bir depo aç (Public olursa indirme linki giriş istemez).
2. github-repo/ klasöründeki her şeyi (.github, www, appname.txt) depoya yükle.
3. GitHub > Settings > Developer settings > Fine-grained tokens: sadece bu depo için,
   "Contents: Read and write" iznli bir token üret.
4. Uygulamada APK Yap sekmesinde GitHub ayarına kullanıcı adı, depo adı ve token'ı yaz.

## 3) Uygulamayı ilk kez APK yapmak
app/ klasörünü (index.html) bir APK aracına ver ya da github-repo/www/index.html yerine koyup depoya yükle,
GitHub APK'yı kendisi derler (Releases bölümünde çıkar).
Canlı Ders sekmesinde sunucu adresini ve şifreyi yaz.
server/ klasörünü APK'ya koyma.

## Yapay zekâ seçimi (v3)
Uygulamanın üstündeki listeden Claude, ChatGPT ya da Gemini seçilir.
Sunucuda hangisini kullanacaksan onun anahtarını ekle (hepsi ayrı ve genelde ücretli):
ANTHROPIC_API_KEY, OPENAI_API_KEY, GEMINI_API_KEY.
Model adları zamanla değişir. Hata alırsan CLAUDE_MODEL, OPENAI_MODEL, GEMINI_MODEL,
OPENAI_IMAGE_MODEL, GEMINI_IMAGE_MODEL değişkenleriyle güncel adı yaz.
Resim: ChatGPT ve Gemini yapar, Claude yapmaz.

## Sunucusuz kullanım (v4)
Sunucu kurmadan da çalışır: Canlı Ders > Ayar kısmına kullanacağın yapay zekânın anahtarını yaz.
Anahtar sadece telefonunda durur. Uygulamayı başkalarına dağıtacaksan bunu yapma, sunucu kullan.

## v15
- Savaş sekmesi silindi.
- 3D modeller gerçekçi: gölge, yansıma, parlak boya, kürk/kumaş/tuğla dokusu, gerçekçi gözler.
  Kedi, köpek, insan, araba, uçak, ev, tren, robot, ağaç yeniden yapıldı. Modeller zemine oturur.
- Resim sekmesi: resim yapılınca "3D yap" düğmesi çıkar, "otomatik 3D yap" kutusu açıksa kendiliğinden 3D'ye geçer.
- Resim 3D kabartma: daha ince ayrıntı, çerçeveli, gerçek renkli.

## v16
- Resim -> 3D hafifletildi (donma düzeltmesi), durum yazısı ve hata mesajı eklendi.

## v17
- 3D: at, kuş, kelebek, helikopter, uzay gemisi, motosiklet, kule, köprü. Kuş/kelebek kanat çırpar, helikopter pervanesi ve motosiklet tekerleği döner.
- 3D ses: kedi, köpek, araba, motosiklet, tren, helikopter, at, kuş vb. 🔊 düğmesi ya da modele dokun.
- 📦 .glb kaydet: 3D modeli .glb dosyası yapar (ilk seferde internet ister).
- Yıldız sekmesi: günlük elmas görevleri, daha çok rozet, seri sayacı.
- 🤖 Robot sekmesi: komut yazarak robotu labirentte yürüt (ileri, sol, sağ, tekrar 3 { ileri }).
- Çevrimdışı: sw.js + "3D'yi çevrimdışı hazırla" düğmesi. Üstte 📴 simgesi çıkar.
- 🔗 Link yap: kodu link olarak gönder. Uygulamanı koyduğun internet adresini bir kez yazman gerekir.
- Tema düğmesi ☀️/🌙 gösterir.
- Yarış: 4 araba, 4 pist, skor tablosu (en iyi 5), puana göre elmas.
- Düzeltme: ders ilerleme listesi artık sadece Dersler sekmesindeki kartlara bakar.

## v18 (bugüne özel)
- 24 Ekim-1 Kasım: Cadılar Bayramı haftası. 🎃 Balkabağı ve 👻 Hayalet 3D modelleri (sesli), Yarış'ta Cadı yolu, her gün 10 elmas hediye, rozet.
- 24-29 Ekim: 29 Ekim Cumhuriyet Bayramı geri sayımı. 29 Ekim'de 15 elmas ve rozet.

## v19
- 3D: 🇹🇷 Türk bayrağı (dalgalanır) ve 🏛️ Atatürk Anıtı (yüzsüz sade anıt, kitabeli kaide).

## v20
- 3D: 🙂 Ben (kendi fotoğrafını seçince yüz olur), 👦 Çocuk, 🧑‍🚀 Astronot, 💪 Dev adam, 🦔 Kirpi (renkleri değiştirilebilir).

## v21
- Robot: 8 bölüm. Quiz: internetsiz hazır sorular (anahtar gerekmez). 3D: 🏛️ Anıtkabir.
