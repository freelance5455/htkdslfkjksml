# Kodla

## 1) Sunucu (Canlı Ders ve Dönüştür için)
Node 18+ olan bir yere yükle (Render, Railway, Fly.io...).
Ortam değişkenleri: ANTHROPIC_API_KEY (zorunlu), APP_TOKEN (uygulama şifresi, öneririm).
Başlat: node server/server.js

## 2) APK derleme (GitHub, ücretsiz)
1. github.com'da yeni bir depo aç (Public olursa indirme linki giriş istemez).
2. github-repo/ klasöründeki her şeyi (.github, www, appname.txt) depoya yükle.
3. GitHub > Settings > Developer settings > Fine-grained tokens: sadece bu depo için,
   "Contents: Read and write" iznli bir token üret.
4. Uygulamada APK Yap sekmesinde GitHub ayarına kullanıcı adı, depo adı ve token'ı yaz.

## 3) Uygulamayı ilk kez APK yapmak
app/ klasörünü (index.html) bir APK aracına ver ya da github-repo/www/index.html yerine koyup depoya yükle,
GitHub APK'yı kendisi derler (Releases bölümünde çıkar).
Canlı Ders sekmesinde sunucu adresini ve şifreyi yaz.
server/ klasörünü APK'ya koyma.

## Yapay zekâ seçimi (v3)
Uygulamanın üstündeki listeden Claude, ChatGPT ya da Gemini seçilir.
Sunucuda hangisini kullanacaksan onun anahtarını ekle (hepsi ayrı ve genelde ücretli):
ANTHROPIC_API_KEY, OPENAI_API_KEY, GEMINI_API_KEY.
Model adları zamanla değişir. Hata alırsan CLAUDE_MODEL, OPENAI_MODEL, GEMINI_MODEL,
OPENAI_IMAGE_MODEL, GEMINI_IMAGE_MODEL değişkenleriyle güncel adı yaz.
Resim: ChatGPT ve Gemini yapar, Claude yapmaz.

## Sunucusuz kullanım (v4)
Sunucu kurmadan da çalışır: Canlı Ders > Ayar kısmına kullanacağın yapay zekânın anahtarını yaz.
Anahtar sadece telefonunda durur. Uygulamayı başkalarına dağıtacaksan bunu yapma, sunucu kullan.

## v15
- Savaş sekmesi silindi.
- 3D modeller gerçekçi: gölge, yansıma, parlak boya, kürk/kumaş/tuğla dokusu, gerçekçi gözler.
  Kedi, köpek, insan, araba, uçak, ev, tren, robot, ağaç yeniden yapıldı. Modeller zemine oturur.
- Resim sekmesi: resim yapılınca "3D yap" düğmesi çıkar, "otomatik 3D yap" kutusu açıksa kendiliğinden 3D'ye geçer.
- Resim 3D kabartma: daha ince ayrıntı, çerçeveli, gerçek renkli.

## v16
- Resim -> 3D hafifletildi (donma düzeltmesi), durum yazısı ve hata mesajı eklendi.

## v17
- 3D: at, kuş, kelebek, helikopter, uzay gemisi, motosiklet, kule, köprü. Kuş/kelebek kanat çırpar, helikopter pervanesi ve motosiklet tekerleği döner.
- 3D ses: kedi, köpek, araba, motosiklet, tren, helikopter, at, kuş vb. 🔊 düğmesi ya da modele dokun.
- 📦 .glb kaydet: 3D modeli .glb dosyası yapar (ilk seferde internet ister).
- Yıldız sekmesi: günlük elmas görevleri, daha çok rozet, seri sayacı.
- 🤖 Robot sekmesi: komut yazarak robotu labirentte yürüt (ileri, sol, sağ, tekrar 3 { ileri }).
- Çevrimdışı: sw.js + "3D'yi çevrimdışı hazırla" düğmesi. Üstte 📴 simgesi çıkar.
- 🔗 Link yap: kodu link olarak gönder. Uygulamanı koyduğun internet adresini bir kez yazman gerekir.
- Tema düğmesi ☀️/🌙 gösterir.
- Yarış: 4 araba, 4 pist, skor tablosu (en iyi 5), puana göre elmas.
- Düzeltme: ders ilerleme listesi artık sadece Dersler sekmesindeki kartlara bakar.

## v18 (bugüne özel)
- 24 Ekim-1 Kasım: Cadılar Bayramı haftası. 🎃 Balkabağı ve 👻 Hayalet 3D modelleri (sesli), Yarış'ta Cadı yolu, her gün 10 elmas hediye, rozet.
- 24-29 Ekim: 29 Ekim Cumhuriyet Bayramı geri sayımı. 29 Ekim'de 15 elmas ve rozet.

## v19
- 3D: 🇹🇷 Türk bayrağı (dalgalanır) ve 🏛️ Atatürk Anıtı (yüzsüz sade anıt, kitabeli kaide).

## v20
- 3D: 🙂 Ben (kendi fotoğrafını seçince yüz olur), 👦 Çocuk, 🧑‍🚀 Astronot, 💪 Dev adam, 🦔 Kirpi (renkleri değiştirilebilir).

## v21
- Robot: 8 bölüm. Quiz: internetsiz hazır sorular (anahtar gerekmez). 3D: 🏛️ Anıtkabir.

## v22
- 🧊 3D Atölye sekmesi: küp, küre, silindir, koni, halka ekle; taşı/döndür/ölçekle, renk ve boyut kaydırıcıları, sil. Dokunarak seçilir, sürükleyince kamera döner. Çevrimdışı hazırlama düğmesine de eklendi.
- 3D Atölye: ⧉ Çoğalt, ↩️ Geri al (60 adım), 💾 Kaydet / 📂 Yükle. Kayıtlı sahne sekme açılınca kendiliğinden gelir. Kısayol: D çoğalt, Ctrl+Z geri al.

## v23
- 3D: 👨 Bıyıklı adam (Hawaii gömlek), 🎮 Mini konsol robot, 🏎️ Spor araba, 🚕 Taksi, 🚓 Polis, 🚙 Jip, 🚚 Kamyon, 🚌 Otobüs, 🚒 İtfaiye.
- 🖼️ Foto sekmesi: resim seç ya da yapıştır; emoji süsü, bıyık, yazı ekle; sürükle, boyutlandır, döndür; çiz; geri al; PNG kaydet; 3D yap.
- 3D Atölye: Piramit ve Elmas şekilleri.

## v24 (son sürüm)
- 🎨 Çizim sekmesi: fırça, silgi, gökkuşağı fırça, renk/kalınlık, zemin, geri al, PNG kaydet, Foto'ya gönder, 3D yap.
- 🎮 Oyun Yap sekmesi: Yılan, Balon patlat, Zıpla koş. Karakter, renk ve hız seç, oyna. Kodunu Kod sekmesine gönder, değiştir.
- 3D Atölye: 📦 .glb kaydet, 📝 Kod yap (sahnenin Three.js kodu).

## v25
- 🧑‍🎨 Canvas sekmesi: sohbetle kod yazdır, yanında canlı ön izleme. "Şunu değiştir" dersen yapay zekâ mevcut kodu düzenler. Kod sekmesinde elle de düzenlenir. Önceki sürüme dön, kopyala, .html indir, tam ekran, Kod sekmesine gönder.
- Oyun Yap ve Kod Ver sekmelerinden "Canvas'ta aç".
- server.js: /code isteği artık 30000 karaktere kadar (Canvas mevcut kodu da gönderir). Sunucuyu yeniden yükle.

## v26 (son sürüm)
- 🎞️ Foto sekmesi: Animasyon düğmesi. 8 animasyon (nefes, sallan, zıpla, dön, kalp atışı, titre, sinema, dalga), hız ayarı. Süs, yazı ve çizimle birlikte oynar.
- 🎬 Video kaydet: animasyonu 4 saniyelik video olarak indirir (WebM, telefon destekliyorsa).
- 🎛️ Foto filtreleri: siyah-beyaz, sepya, parlak, canlı, soluk, ters renk, bulanık, rüya. PNG ve 3D'ye de geçer.
- ⭐ Uygulama açılınca yıldız verme penceresi (5 yıldız + not). İlk puana 3 elmas. Sağ altta hep "⭐ Yıldız ver" düğmesi durur, puanı değiştirebilirsin.

## v27 (son sürüm)
- 🎵 Müzik sekmesi: 8 tuşlu piyano (4 ses tipi), 4 davul pedi, kaydet ve oynat.
- 🧩 Hafıza sekmesi: 8 çift kartlı eşleştirme oyunu, hamle sayacı, en iyi skor, bitirince 2 elmas.

## v28 (son sürüm)
- 📚 Kitap sekmesi: kapak adı/rengi, sayfa ekle/sil, sayfa emojisi, yazı, Foto'dan ya da galeriden resim. 📖 Oku: sayfa çevirme animasyonlu okuyucu. 💾 .html indir: internetsiz açılan tek dosya kitap. Her şey kendiliğinden kaydolur.

## v29 (son sürüm)
- 🧮 2048: kaydır ya da ok tuşları, skor, en iyi skor, 512'ye gelince 2 elmas.
- 🔤 Kelime: karışık harflerden kelimeyi bul, ipucu, her 5 doğruya 1 elmas.
- 📝 Not: birden çok not, kendiliğinden kaydolur, kopyala, Kod sekmesine gönder.
- ⏱️ Odak: 1/10/25/45 dk sayaç, bitince elmas (10 dk = 1 elmas) ve günlük toplam.
- 🎲 Çark: 1-2 zar ve kendi seçeneklerinle dönen çark.
- 📚 Kitap: 🔊 Sesli oku (sayfaları sırayla okur) ve 🎬 Video yap (sayfaları kayarak geçen video, WebM).

## v30 (son sürüm)
- Menü: Hepsi / Öğren / Yarat / Oyun / Araçlar kategorileri ve 🔍 arama kutusu.
- 🧱 Kod Bulmaca: karışık kod satırlarını doğru sıraya diz, her yeni bulmacaya 1 elmas, Kod sekmesine gönder.
- 🌐 Site Yap: başlık, emoji, yazı, renkler, resim, düğme seç; HTML kodu yazılır. Önizle, Kod sekmesine gönder, Canvas'ta aç, .html indir.
- 🎞️ Çizgi Film: kare kare çiz (önceki kare soluk görünür), oynat, hız ayarı, video kaydet.
- 🐾 Evcil: aç kalır, canı sıkılır. Elmasla besle, oyna, seviye atlar.
- 🏆 Rozet: 13 rozet ve isimli sertifika resmi (PNG kaydet, Foto'ya gönder).
- 🔐 Günlük: PIN ile açılan, AES şifreli günlük. PIN unutulursa geri gelmez. Başka sekmeye geçince kendiliğinden kilitlenir.
- 🤝 Yarış Kodu: skor kodunu arkadaşına gönder, onunkini yapıştırıp kıyasla. Sunucu gerekmez.
- 📊 İstatistik: sekmelerde geçirdiğin süre, elmas, rozet.
- 🎤 Sesle komut: sol alttaki düğmeye bas, "yeni not", "2048", "kod bulmaca" gibi söyle (cihaz destekliyorsa).

## v31: 3D Atölye ek özellikleri
- Yeni modeller: Yıldız, Kalp, Mantar, Pasta, Gezegen (halkalı), Kaktüs, Çadır, Kamp ateşi, Çam, Trafik lambası, Ahtapot, Kaplumbağa.
- 🪞 Ayna (seçili şekli ya da tüm sahneyi X ekseninde yansıtır), ⬇️ Zemine indir, 🎲 Rastgele sahne.
- 🖼️ PNG kaydet, arka plan seçimi, ızgara aç/kapa, PNG şeffaf arka plan.
- Malzeme (mat, metalik, parlak, cam, parlayan, tel kafes) ve 90° döndürme düğmeleri.
- .glb ve "Kod yap" yeni modelleri ve malzemeleri de kapsar.
- 3D sekmesine de eklendi: Mantar, Pasta, Gezegen, Kaktüs, Kamp çadırı, Kamp ateşi, Çam, Trafik lambası, Ahtapot, Kaplumbağa (Yıldız ve Kalp zaten vardı).
