// Kodla sunucusu. Bağımlılık yok. Node 18+ gerekir.
// ANTHROPIC_API_KEY (Claude), OPENAI_API_KEY (ChatGPT), GEMINI_API_KEY (Gemini): hangisini kullanacaksan onu ekle.
// APP_TOKEN: uygulama şifresi (öneririm). İsteğe bağlı: CLAUDE_MODEL, OPENAI_MODEL, GEMINI_MODEL, OPENAI_IMAGE_MODEL, GEMINI_IMAGE_MODEL
const http = require("http");
const K = { claude: process.env.ANTHROPIC_API_KEY, chatgpt: process.env.OPENAI_API_KEY, gemini: process.env.GEMINI_API_KEY };
const M = { claude: process.env.CLAUDE_MODEL || "claude-sonnet-5-5", chatgpt: process.env.OPENAI_MODEL || "gpt-4o-mini", gemini: process.env.GEMINI_MODEL || "gemini-2.5-flash" };
const PROV = ["claude", "chatgpt", "gemini"];
const TOKEN = process.env.APP_TOKEN || "";
const PORT = process.env.PORT || 3000;
const hits = new Map();
const SAFE = "GÜVENLİK KURALI: Kötü amaçlı yazılım (virüs, fidye yazılımı, keylogger, casus yazılım), hesap ya da şifre çalma, sistemlere izinsiz sızma, DDoS, oltalama (phishing) sayfası, başkasına zarar verecek ya da onu gizlice izleyecek kod yazma, açıklama, çevirme ya da çalıştırma. Böyle bir istek gelirse nazikçe reddet ve yerine güvenli bir alternatif öner (örn. kendi sitesini korumayı öğrenmek).";
const TUTOR = "Sen Kodla uygulamasının içindeki Türk kodlama hocasısın. Her zaman Türkçe, kısa ve sade konuş. " +
  "UYGULAMA BİLGİSİ: Kodla'nın sekmeleri: Kod (10 dilde yaz ve çalıştır; JavaScript ve HTML telefonda çalışır, diğerleri internetle), " +
  "Dönüştür (kodu başka dile çevirir), Dersler, Canlı Ders (sen), APK Yap (editördeki HTML ya da JavaScript kodunu GitHub'a gönderir, orada APK derlenir, indirme linki çıkar). " +
  "ÖĞRETİRKEN: bir seferde tek küçük konu anlat, sonra mini alıştırma ver, cevabı hemen verme, hata yapana suçlamadan nedenini göster. " +
  "KOD YAZARKEN: öğrenci senden uygulama, oyun ya da kod isterse tam çalışan kodu yaz. Uygulama istenirse tek dosyalık eksiksiz bir HTML yaz (CSS ve JS içinde, internetten dosya çağırma, telefon ekranına uygun). " +
  "Kodu tek bir ``` bloğunda ver. Sonra kısaca şunu söyle: Editöre al, Kod sekmesinde dene, beğenirsen APK Yap sekmesine geç. " +
  "Kodu verdikten sonra öğrenciye neyi nasıl yaptığını 2-3 cümleyle öğret. Her cevabın sonunda tek satırda Yeni kelime: yazıp bir kodlama kelimesini İngilizcesi, Türkçesi ve kısa örnekle öğret.";
const CONVERT = "Verilen kodu istenen programlama diline çevir. Sadece çevrilmiş kodu ver, açıklama ekleme, markdown kullanma.";

const RUN = "Verilen kodu gerçekten çalıştırmışsın gibi SADECE programın çıktısını yaz. Açıklama ve markdown ekleme. Hata varsa hata mesajını yaz.";
const CODE = "Kullanıcının istediği kodu yaz. Uygulama, oyun ya da sayfa isterse telefon ekranına uygun, tek dosyalık eksiksiz HTML ver (CSS ve JS içinde, internetten dosya çağırma). Dil belirtilmezse HTML kullan. Sadece kodu ver, markdown ve açıklama ekleme. Kodun içine kısa Türkçe yorum satırları koy.";

async function post(url, headers, body) {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json", ...headers }, body: JSON.stringify(body) });
  const d = await r.json();
  if (!r.ok) throw new Error((d.error && (d.error.message || d.error)) || "API hatası");
  return d;
}
async function ask(p, system, messages) {
  system = SAFE + " " + system;
  if (!K[p]) throw new Error(p + " anahtarı sunucuda yok.");
  if (p === "claude") {
    const d = await post("https://api.anthropic.com/v1/messages", { "x-api-key": K.claude, "anthropic-version": "2023-06-01" }, { model: M.claude, max_tokens: 4000, system, messages });
    return d.content.map((c) => c.text || "").join("");
  }
  if (p === "chatgpt") {
    const d = await post("https://api.openai.com/v1/chat/completions", { authorization: "Bearer " + K.chatgpt }, { model: M.chatgpt, messages: [{ role: "system", content: system }, ...messages] });
    return d.choices[0].message.content;
  }
  const d = await post(`https://generativelanguage.googleapis.com/v1beta/models/${M.gemini}:generateContent`, { "x-goog-api-key": K.gemini },
    { systemInstruction: { parts: [{ text: system }] }, contents: messages.map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] })) });
  return ((d.candidates && d.candidates[0] && d.candidates[0].content.parts) || []).map((x) => x.text || "").join("");
}
async function image(p, prompt) {
  if (p === "claude") throw new Error("Claude resim yapamaz. Üstten ChatGPT ya da Gemini seç.");
  if (!K[p]) throw new Error(p + " anahtarı sunucuda yok.");
  if (p === "chatgpt") {
    const d = await post("https://api.openai.com/v1/images/generations", { authorization: "Bearer " + K.chatgpt }, { model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-1", prompt, size: "1024x1024" });
    const b = d.data[0];
    return b.b64_json ? "data:image/png;base64," + b.b64_json : b.url;
  }
  const d = await post(`https://generativelanguage.googleapis.com/v1beta/models/${process.env.GEMINI_IMAGE_MODEL || "gemini-2.5-flash-image"}:generateContent`, { "x-goog-api-key": K.gemini },
    { contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseModalities: ["TEXT", "IMAGE"] } });
  const parts = (d.candidates && d.candidates[0] && d.candidates[0].content.parts) || [];
  const part = parts.find((x) => x.inlineData || x.inline_data);
  if (!part) throw new Error("Resim gelmedi.");
  const i = part.inlineData || part.inline_data;
  return "data:" + (i.mimeType || i.mime_type) + ";base64," + i.data;
}
const strip = (s) => s.replace(/^```\w*\n|\n```\s*$/g, "");

http.createServer((req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "content-type,x-app-token");
  res.setHeader("Content-Type", "application/json");
  if (req.method === "OPTIONS") return res.end();
  if (req.method === "GET") return res.end(JSON.stringify({ ok: true }));
  const ip = req.socket.remoteAddress, now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 60000);
  list.push(now); hits.set(ip, list);
  if (list.length > 20) { res.statusCode = 429; return res.end(JSON.stringify({ error: "Çok hızlı, biraz bekle." })); }
  if (TOKEN && req.headers["x-app-token"] !== TOKEN) { res.statusCode = 401; return res.end(JSON.stringify({ error: "Şifre yanlış." })); }
  let body = "";
  req.on("data", (c) => { body += c; if (body.length > 50000) req.destroy(); });
  req.on("end", async () => {
    try {
      const j = JSON.parse(body || "{}");
      const p = PROV.includes(j.provider) ? j.provider : "claude";
      if (req.url === "/tutor") {
        const msgs = (j.messages || []).slice(-20).map((m) => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content).slice(0, 4000) }));
        return res.end(JSON.stringify({ reply: await ask(p, TUTOR, msgs) }));
      }
      if (req.url === "/convert") {
        const q = `Kaynak dil: ${j.from}\nHedef dil: ${j.to}\n\nKod:\n${String(j.code).slice(0, 8000)}`;
        return res.end(JSON.stringify({ code: strip(await ask(p, CONVERT, [{ role: "user", content: q }])) }));
      }
      if (req.url === "/code") {
        return res.end(JSON.stringify({ code: strip(await ask(p, CODE, [{ role: "user", content: String(j.prompt).slice(0, 30000) }])) }));
      }
      if (req.url === "/run") {
        return res.end(JSON.stringify({ code: strip(await ask(p, RUN, [{ role: "user", content: `Dil: ${j.lang}\n\n${String(j.code).slice(0, 8000)}` }])) }));
      }
      if (req.url === "/image") {
        return res.end(JSON.stringify({ image: await image(p, String(j.prompt).slice(0, 1000)) }));
      }
      res.statusCode = 404; res.end(JSON.stringify({ error: "Yol yok" }));
    } catch (e) { res.statusCode = 500; res.end(JSON.stringify({ error: e.message })); }
  });
}).listen(PORT, () => console.log("Kodla sunucusu: " + PORT));
