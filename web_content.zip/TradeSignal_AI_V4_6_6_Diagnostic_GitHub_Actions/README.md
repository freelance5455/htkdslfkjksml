# TradeSignal AI V4.6.6 — Diagnostic Panel — GitHub Actions Build

Esta é a nova estratégia de build para evitar a dependência do `getBranchSha(main)` não autenticado da Central de Builds.

## Estratégia
- O motor V4.6.6 permanece congelado.
- O painel diagnóstico é apenas laboratório e não altera o motor.
- O APK é compilado pelo GitHub Actions.
- O workflow usa `GITHUB_TOKEN` internamente através das Actions, evitando depender de uma chamada REST anônima de resolução de branch.
- O APK final é publicado como artefato do workflow.

## Como gerar no GitHub
1. Criar/usar um repositório GitHub.
2. Enviar esta pasta para a branch `main`.
3. Abrir **Actions → Build TradeSignal AI APK → Run workflow**.
4. Baixar o artefato `TradeSignal-AI-V4.6.6-Diagnostic-debug`.

## Importante
Não coloque Binance API Secret, tokens pessoais ou outras credenciais no repositório.
