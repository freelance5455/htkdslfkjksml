// Hifadhi faili hili kama firebase-config.js kwenye folda moja na HTML.
// Nakili thamani za firebaseConfig kutoka Firebase Console > Project settings > Your apps.
// Usiongeze nenosiri la akaunti ya shule kwenye faili hili.
window.SCHOOL_FIREBASE_CONFIG = {
  apiKey: "WEKA_API_KEY_HAPA",
  authDomain: "WEKA_PROJECT_ID_HAPA.firebaseapp.com",
  projectId: "WEKA_PROJECT_ID_HAPA",
  appId: "WEKA_APP_ID_HAPA",
  // Tumia ID ileile iliyo kwenye firestore.rules.
  schoolId: "shule-yangu"
};
