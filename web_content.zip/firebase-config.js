// Configuración de Firebase de Mi Negocio.
// Esta configuración web puede estar dentro de la APK.
// La seguridad real depende de Firebase Authentication y las reglas de Firestore.
export default {
  apiKey: "AIzaSyDWK2WnmF3nX7jDGOp4aag_0QUraKiMGG4",
  authDomain: "mi-negocio-ad9f0.firebaseapp.com",
  projectId: "mi-negocio-ad9f0",
  storageBucket: "mi-negocio-ad9f0.firebasestorage.app",
  messagingSenderId: "705483248698",
  appId: "1:705483248698:web:fc8c3f180ccf78c3cb5103",
  measurementId: "G-HN041KN1EZ"
};
