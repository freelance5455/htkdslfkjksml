// Firebase Console থেকে Web App config কপি করে নিচে বসান।
window.KUSHULIA_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
