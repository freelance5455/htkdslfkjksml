/* Firebase Console > Project settings > Your apps > SDK setup > Config
   Bu dosyaya sadece Firebase web config değerlerini koy. Service account/private key koyma. */
window.MINIHUB_FIREBASE_CONFIG = {
  apiKey: "BURAYA_API_KEY",
  authDomain: "PROJE_ID.firebaseapp.com",
  projectId: "PROJE_ID",
  storageBucket: "PROJE_ID.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};
