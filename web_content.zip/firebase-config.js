// 1) Create a Firebase project at https://console.firebase.google.com
// 2) Add a Web app and copy its config below.
// 3) Enable Realtime Database and Authentication > Sign-in method > Anonymous.
// 4) Add your deployed domain to Firebase Authentication > Authorized domains.
window.REMOTEX_FIREBASE_CONFIG = {
  apiKey: "PASTE_YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
  projectId: "YOUR_PROJECT",
  appId: "YOUR_APP_ID"
};