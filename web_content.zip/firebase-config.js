// Substitua os valores abaixo pelas credenciais do seu app Web no Firebase Console.
// Firebase Console > Configurações do projeto > Seus apps > Aplicativo da Web > Configuração do SDK.
export const firebaseConfig = {
  apiKey: "COLOQUE_SUA_API_KEY",
  authDomain: "SEU-PROJETO.firebaseapp.com",
  projectId: "SEU-PROJETO",
  storageBucket: "SEU-PROJETO.firebasestorage.app",
  messagingSenderId: "SEU_SENDER_ID",
  appId: "SEU_APP_ID"
};
