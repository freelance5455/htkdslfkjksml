// إعدادات تطبيق الويب لمشروع أبناء أبو بهاء.
// هذه القيم تخص Firebase Web App وليست مفاتيح Service Account.
window.ABBA_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBqWcLa5QqNPyH3Sxp8LWzKCRl0M_GO37Y",
  authDomain: "abnaa-abu-bahaa.firebaseapp.com",
  projectId: "abnaa-abu-bahaa",
  storageBucket: "abnaa-abu-bahaa.firebasestorage.app",
  messagingSenderId: "762657651250",
  appId: "1:762657651250:web:18a4641b93dc612c681a2b",
  measurementId: "G-FVETFWZ1QY"
};
