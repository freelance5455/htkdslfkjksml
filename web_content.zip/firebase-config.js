// Firebase web configuration for the Varavu Selavu project.
// Firebase web API keys are client identifiers, not database access protection.
// Protect Firestore with the rules in firestore.rules.
export const firebaseConfig = {
  apiKey: "AIzaSyCxsMfh1ewN0_qDmorwx58ZBCRcZ3yky38",
  authDomain: "varavu-selavu-c2750.firebaseapp.com",
  projectId: "varavu-selavu-c2750",
  storageBucket: "varavu-selavu-c2750.firebasestorage.app",
  messagingSenderId: "915623782071",
  appId: "1:915623782071:web:be800317124149d446cf32",
  measurementId: "G-SBDK4VZLCR"
};
