// THE MANAGEMENT Firebase configuration
// 1. Create a Firebase project at https://console.firebase.google.com/
// 2. Enable Authentication > Sign-in method > Anonymous.
// 3. Create Firestore Database.
// 4. Enable Storage.
// 5. Create a Web App and copy its config below.
// NEVER put Firebase service-account/private keys here.
window.TM_FIREBASE_CONFIG = {
  apiKey: "PASTE_YOUR_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_STORAGE_BUCKET",
  messagingSenderId: "PASTE_YOUR_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};
