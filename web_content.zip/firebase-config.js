// Paste the Firebase Web App config from Firebase Console here.
// Example:
// window.HALLWAY_FIREBASE_CONFIG = {
//   apiKey: "...",
//   authDomain: "your-project.firebaseapp.com",
//   projectId: "your-project",
//   storageBucket: "your-project.firebasestorage.app",
//   messagingSenderId: "...",
//   appId: "..."
// };
