// Firebase Web App configuration. Paste values from Firebase Console > Project settings > Your apps.
// This config is not a password. Keep Firestore security rules enabled as provided.
export const firebaseConfig = {
  apiKey: "AIzaSyBC-Sj4omH166wnhk9x4lwIBaQhJRwfgZU",
  authDomain: "kisanagrikhata.firebaseapp.com",
  projectId: "kisanagrikhata",
  storageBucket: "kisanagrikhata.firebasestorage.app",
  messagingSenderId: "298111925653",
  appId: "1:298111925653:web:c8df8abc58b45ac8344a9c"
};