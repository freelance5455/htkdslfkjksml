// Firebase web app configuration.
// Replace every YOUR_* value with the configuration from Firebase Console.
// Do not paste private service-account keys here.
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_APP_ID"
};
