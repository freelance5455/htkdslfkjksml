// KhetCycle Firebase configuration.
// Add your Firebase Web App configuration here if you want to connect
// the app to a real Firebase project. Demo mode works without Firebase.
//
// Example:
// window.KHETCYCLE_FIREBASE_CONFIG = {
//   apiKey: "YOUR_API_KEY",
//   authDomain: "YOUR_PROJECT.firebaseapp.com",
//   projectId: "YOUR_PROJECT",
//   storageBucket: "YOUR_PROJECT.firebasestorage.app",
//   messagingSenderId: "YOUR_SENDER_ID",
//   appId: "YOUR_APP_ID"
// };
window.KHETCYCLE_FIREBASE_CONFIG = null;
