// 1) Firebase Console > Project settings > Your apps > Web app
// 2) Copy your config below.
// 3) Also set VAPID_KEY in index.html/admin.html from Firebase Cloud Messaging settings.
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

export const VAPID_KEY = "YOUR_WEB_PUSH_VAPID_KEY";
