// Firebase Console থেকে Web App-এর config এখানে বসাও.
// এই ফাইলের config public হতে পারে, কিন্তু Firestore/Storage Security Rules অবশ্যই ঠিকভাবে সেট করতে হবে.
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "PASTE_YOUR_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};

// Web Push ব্যবহার করলে Firebase Console > Cloud Messaging থেকে VAPID public key বসাও.
export const vapidKey = "PASTE_YOUR_WEB_PUSH_VAPID_PUBLIC_KEY";
