// My College Firebase Web App configuration
export const firebaseConfig = {
  apiKey: "AIzaSyAnR5_PXZQS8VeHnDjsD5xh-1jm-667rUo",
  authDomain: "my-college-98ee2.firebaseapp.com",
  projectId: "my-college-98ee2",
  storageBucket: "my-college-98ee2.firebasestorage.app",
  messagingSenderId: "165198019598",
  appId: "1:165198019598:web:3ae568470329d61237505f",
  measurementId: "G-X7521714R2"
};
export const SUPER_ADMIN_UID = "HJf60F7a78RFgsBwWJw81gLUXx83";
