// Add your Firebase Web App configuration here to enable real cross-device chats.
// Get it from Firebase Console -> Project settings -> Your apps -> Web app.
window.HALLWAY_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  databaseURL: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
