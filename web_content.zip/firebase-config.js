/*
  1) Create a Firebase project at https://console.firebase.google.com/
  2) Add a Web app, then copy its Firebase config below.
  3) Enable Authentication > Sign-in method > Email/Password.
  4) Create a Cloud Firestore database.
  Firebase web config is public client configuration, NOT a password.
  Never put service-account keys or private server credentials in this file.
*/
window.STUDY_BUDDY_FIREBASE_CONFIG = {
  apiKey: "PASTE_YOUR_FIREBASE_WEB_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};
