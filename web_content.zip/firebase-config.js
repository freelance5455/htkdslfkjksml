import { initializeApp } from "firebase/app";
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const requiredConfigValues = Object.values(firebaseConfig);
const isConfigured = requiredConfigValues.every((value) =>
  typeof value === "string" && value.trim() !== "" && !value.startsWith("YOUR_")
);

let db = null;

const status = document.getElementById("connection-status");
const message = document.getElementById("setup-message");
const errorNotice = document.getElementById("setup-error");

if (isConfigured) {
  try {
    const app = initializeApp(firebaseConfig);

    db = initializeFirestore(app, {
      localCache: persistentLocalCache({
        tabManager: persistentMultipleTabManager()
      })
    });

    status.textContent = "Firebase configured";
    status.classList.add("status-ready");
    message.textContent =
      "Firebase is configured. User sign-in and ledger screens still need to be implemented.";
  } catch (error) {
    console.error("Firebase initialization failed:", error);
    status.textContent = "Setup error";
    status.classList.add("status-error");
    message.textContent = "Firebase could not be initialized. Review the project settings and try again.";
    errorNotice.textContent = error instanceof Error ? error.message : String(error);
    errorNotice.hidden = false;
  }
} else if (status && message) {
  status.textContent = "Setup required";
  status.classList.add("status-warning");
}

export { db };