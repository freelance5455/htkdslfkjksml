// Konfigurasi Firebase untuk BLOCK MASTER
window.BM_FIREBASE_CONFIG = {
  apiKey: "AIzaSyCrlg72Aht4sbMDO8vm1HVcl7AQ3p6Pd3s",
  authDomain: "block-master-rasya.firebaseapp.com",
  projectId: "block-master-rasya",
  storageBucket: "block-master-rasya.firebasestorage.app",
  messagingSenderId: "766120544385",
  appId: "1:766120544385:web:925e686ce4fd88de0da580",
  measurementId: "G-KCX7469LZY"
};
