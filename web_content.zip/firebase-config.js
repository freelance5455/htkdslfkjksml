/* =========================================================
   CONFIGURAÇÃO DO FIREBASE — SINCRONIZAÇÃO ENTRE CONTAS
   =========================================================

   Enquanto os valores abaixo estiverem como "COLOQUE_AQUI",
   a aplicação funciona apenas neste dispositivo (sem sincronizar
   com as outras contas). Assim que preencher com os dados do
   SEU projeto Firebase, tudo o que for cadastrado numa conta
   (Presidente, Financeiro Sénior ou Financeiro Júnior) passa a
   aparecer automaticamente nas outras, sempre que houver internet.

   COMO OBTER ESTES DADOS (gratuito):
   1. Aceda a https://console.firebase.google.com
   2. Crie um projeto (ex.: "associacao-terra-vermelha")
   3. No menu à esquerda: Compilação → Firestore Database → Criar
      base de dados (escolha "modo de produção" e a região mais
      próxima, ex.: europe-west)
   4. Nas Regras do Firestore, para começar, pode usar:
         allow read, write: if true;
      (depois pode reforçar a segurança conforme necessário)
   5. No menu ⚙️ → Definições do projeto → role até "Seus apps" →
      clique no ícone </> (Web) → registe a app → copie o objeto
      "firebaseConfig" que aparece e cole os valores abaixo.
   ========================================================= */

const firebaseConfig = {
    apiKey: "AIzaSyA6snsY46XdF63_atxbhKQ9UdQ1v-EQc1o",
    authDomain: "desta-9b27b.firebaseapp.com",
    projectId: "desta-9b27b",
    storageBucket: "desta-9b27b.firebasestorage.app",
    messagingSenderId: "762219132317",
    appId: "1:762219132317:web:cdf3b5c6ddbf5d8b66ab74"
};
