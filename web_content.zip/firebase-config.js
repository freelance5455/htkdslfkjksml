// CONFIGURAÇÃO DO MODO ONLINE - Firebase
// 1) Crie um projeto em https://console.firebase.google.com/
// 2) Adicione um app Web e copie os dados para este objeto.
// 3) Ative Authentication > Sign-in method > Anonymous.
// 4) Crie o Firestore Database.
window.ECO_FIREBASE_CONFIG = {
  apiKey: "COLOQUE_SUA_API_KEY",
  authDomain: "SEU_PROJETO.firebaseapp.com",
  projectId: "SEU_PROJECT_ID",
  storageBucket: "SEU_PROJETO.firebasestorage.app",
  messagingSenderId: "SEU_MESSAGING_SENDER_ID",
  appId: "SEU_APP_ID"
};
