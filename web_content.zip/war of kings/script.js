window.WOK_VERSION = "WOK-R-1.4";
window.WOK_BUILD = "R"; // release
window.WOK_isMobile = function () {
  try {
    if (navigator.userAgentData && navigator.userAgentData.mobile) return true;
  } catch (_) {}
  try {
    return /Android|iPhone|iPad|iPod|Mobile|IEMobile|Opera Mini/i.test(navigator.userAgent || '')
      || (Math.min(screen.width, screen.height) <= 820);
  } catch (_) { return false; }
};
window.WOK_perfDefaults = function () {
  const mobile = window.WOK_isMobile && WOK_isMobile();
  return {
    hideSmallIslands: !!mobile,
    countryBorderDetail: mobile ? 18 : 28,
    regionBorderDetail: mobile ? 18 : 28,
    showMapStats: false
  };
};

/**
 * Global game settings (NOT per-world). Key: wok_settings
 */
(function (global) {
  'use strict';
  const KEY = 'wok_settings';
  function clampSens(v) {
    const n = Number(v);
    if (!isFinite(n)) return 1;
    return Math.max(0.5, Math.min(2, n));
  }
  function clampDetail(v, def) {
    const n = Number(v);
    if (!isFinite(n)) return def;
    return Math.min(64, Math.max(15, Math.round(n)));
  }
  function defaults() {
    const perf = (global.WOK_perfDefaults && global.WOK_perfDefaults()) || {};
    return {
      lang: 'ar',
      orient: 'landscape',
      sensitivity: 1,
      panSensitivity: 1,
      zoomSensitivity: 1,
      hideSmallIslands: perf.hideSmallIslands != null ? !!perf.hideSmallIslands : false,
      showMapStats: false,
      muteMapBanners: false,
      countryBorderDetail: perf.countryBorderDetail != null ? perf.countryBorderDetail : 28,
      regionBorderDetail: perf.regionBorderDetail != null ? perf.regionBorderDetail : 28
    };
  }
  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      const d = raw ? JSON.parse(raw) : {};
      const base = defaults();
      const sens = d.sensitivity != null ? clampSens(d.sensitivity) : 1;
      const pan = d.panSensitivity != null ? clampSens(d.panSensitivity) : sens;
      const zoom = d.zoomSensitivity != null ? clampSens(d.zoomSensitivity) : sens;
      return {
        lang: (d.lang === 'en' || d.lang === 'tr') ? d.lang : 'ar',
        orient: d.orient === 'portrait' ? 'portrait' : 'landscape', // R1.4 default landscape
        sensitivity: clampSens(d.sensitivity != null ? d.sensitivity : pan),
        panSensitivity: pan,
        zoomSensitivity: zoom,
        hideSmallIslands: !!d.hideSmallIslands,
        showMapStats: !!d.showMapStats,
        muteMapBanners: !!d.muteMapBanners,
        countryBorderDetail: clampDetail(d.countryBorderDetail, 32),
        regionBorderDetail: clampDetail(d.regionBorderDetail, 32)
      };
    } catch (_) {
      return defaults();
    }
  }
  /** Merge-patch save so partial updates never wipe other keys */
  function save(patch) {
    const cur = load();
    const next = Object.assign({}, cur, patch || {});
    // keep sensitivity mirrored to pan for legacy
    if (patch && patch.panSensitivity != null && patch.sensitivity == null) {
      next.sensitivity = next.panSensitivity;
    }
    if (patch && patch.sensitivity != null && patch.panSensitivity == null) {
      next.panSensitivity = next.sensitivity;
    }
    next.lang = (next.lang === 'en' || next.lang === 'tr') ? next.lang : 'ar';
    next.orient = next.orient === 'landscape' ? 'landscape' : 'portrait';
    next.sensitivity = clampSens(next.sensitivity);
    next.panSensitivity = clampSens(next.panSensitivity);
    next.zoomSensitivity = clampSens(next.zoomSensitivity);
    next.hideSmallIslands = !!next.hideSmallIslands;
    next.showMapStats = !!next.showMapStats;
    next.muteMapBanners = !!next.muteMapBanners;
    next.countryBorderDetail = clampDetail(next.countryBorderDetail, 32);
    next.regionBorderDetail = clampDetail(next.regionBorderDetail, 32);
    try { localStorage.setItem(KEY, JSON.stringify(next)); } catch (_) {}
    return next;
  }
  global.WOK_Settings = { KEY: KEY, load: load, save: save, defaults: defaults };
})(typeof window !== 'undefined' ? window : globalThis);

/**
 * War of Kings — Central Script
 * يستقبل العناصر والوحدات والمباني والأبحاث من المترجمين.
 */
(function (global) {
  'use strict';

  const GameData = {
    items: null,
    units: null,
    builds: null,
    research: null,
    ready: false,
    _waiters: []
  };

  function tryReady() {
    // research optional for readiness of economy; wait if translator present
    const researchOk = GameData.research || !global.WOK_ResearchTranslator;
    if (GameData.items && GameData.units && GameData.builds && (GameData.research || researchOk)) {
      if (global.WOK_RESEARCH) GameData.research = global.WOK_RESEARCH;
      GameData.ready = !!(GameData.items && GameData.units && GameData.builds);
      if (!GameData.ready) return;
      console.log('[WOK] GameData ready', {
        materials: GameData.items.list.length,
        units: GameData.units.list.length,
        builds: GameData.builds.list.length,
        research: GameData.research ? GameData.research.list.length : 0
      });
      GameData._waiters.forEach(fn => {
        try { fn(GameData); } catch (e) { console.error(e); }
      });
      GameData._waiters = [];
    }
  }

  function poll() {
    if (global.WOK_ITEMS) GameData.items = global.WOK_ITEMS;
    if (global.WOK_UNITS) GameData.units = global.WOK_UNITS;
    if (global.WOK_BUILDS) GameData.builds = global.WOK_BUILDS;
    if (global.WOK_RESEARCH) GameData.research = global.WOK_RESEARCH;
    tryReady();
    if (!GameData.ready || (global.WOK_ResearchTranslator && !GameData.research)) {
      setTimeout(poll, 50);
    }
  }

  global.WOK = {
    data: GameData,

    whenReady: function (fn) {
      if (GameData.ready && (!global.WOK_ResearchTranslator || GameData.research)) fn(GameData);
      else GameData._waiters.push(fn);
    },

    getItem: function (id) {
      return GameData.items ? GameData.items.get(id) : null;
    },
    getUnit: function (id) {
      return GameData.units ? GameData.units.get(id) : null;
    },
    getBuild: function (id) {
      return GameData.builds ? GameData.builds.get(id) : null;
    },
    getResearch: function (id) {
      return GameData.research ? GameData.research.get(id) : null;
    },

    getBasicResources: function () {
      return GameData.items ? GameData.items.basic : [];
    },
    getBasicBuilds: function () {
      return GameData.builds ? (GameData.builds.basic || []) : [];
    },
    listBuilds: function () {
      return GameData.builds ? (GameData.builds.list || []) : [];
    },
    listUnits: function () {
      return GameData.units ? (GameData.units.list || []) : [];
    },
    listResearchMilitary: function () {
      if (!GameData.research) return [];
      return GameData.research.military || GameData.research.list || [];
    },

    GOLD_ID: 'WOK:ECONOMY.MATERIAL.GOLD.BAR',

    getStartAmount: function (id) {
      const item = this.getItem(id);
      if (!item) return 0;
      const n = Number(item.startAmount);
      return isFinite(n) ? n : 0;
    },

    getExchangeRate: function (id) {
      if (id === this.GOLD_ID) return 1;
      const item = this.getItem(id);
      if (!item) return 0;
      const n = Number(item.exchangeRate);
      return isFinite(n) ? n : 0;
    },

    listExchangeRates: function () {
      if (!GameData.items) return [];
      return (GameData.items.list || []).map(function (item) {
        const rate = item.identifier === 'WOK:ECONOMY.MATERIAL.GOLD.BAR'
          ? 1
          : (isFinite(Number(item.exchangeRate)) ? Number(item.exchangeRate) : 0);
        return { id: item.identifier, item: item, rate: rate };
      });
    }
  };

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', poll);
    } else {
      poll();
    }
  } else {
    poll();
  }
})(typeof window !== 'undefined' ? window : globalThis);
