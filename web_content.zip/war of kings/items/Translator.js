/**
 * War of Kings — Items Translator
 * يقرأ كل ملفات JSON في مجلد items ويحوّلها إلى كائنات جاهزة.
 * يصدّر النتيجة إلى window.WOK_ITEMS
 */
(function (global) {
  'use strict';

  const ITEMS_PATH = 'items/';
  const FILES = [
    'Gold.json',
    'Iron.json',
    'Oil.json'
  ];

  async function loadJSON(path) {
    const res = await fetch(path);
    if (!res.ok) throw new Error('Failed to load ' + path);
    return res.json();
  }

  async function loadAll() {
    const map = Object.create(null);
    const list = [];

    for (const file of FILES) {
      try {
        const data = await loadJSON(ITEMS_PATH + file);
        if (!data || !data.identifier) {
          console.warn('[Items] missing identifier in', file);
          continue;
        }
        map[data.identifier] = data;
        list.push(data);
      } catch (err) {
        console.error('[Items] load failed:', file, err);
      }
    }

    // ترتيب حسب order
    list.sort((a, b) => (a.order || 0) - (b.order || 0));

    const result = {
      byId: map,
      list: list,
      basic: list.filter(i => Array.isArray(i.tags) && i.tags.includes('basic')),
      get: function (id) { return map[id] || null; }
    };

    global.WOK_ITEMS = result;
    console.log('[Items] loaded', list.length, 'materials');
    return result;
  }

  // تشغيل تلقائي
  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => loadAll().catch(console.error));
    } else {
      loadAll().catch(console.error);
    }
  }

  // تصدير يدوي
  global.WOK_ItemsTranslator = { loadAll };
})(typeof window !== 'undefined' ? window : globalThis);
