# ITEMS — دليل كتابة ملفات العناصر

## صيغة المعرف (IDENTIFIER)
```
WOK:ECONOMY.MATERIAL.<NAME>.<FORM>
```
أمثلة:
- `WOK:ECONOMY.MATERIAL.GOLD.BAR`
- `WOK:ECONOMY.MATERIAL.IRON.INGOT`
- `WOK:ECONOMY.MATERIAL.OIL.BARREL`

**لا تستخدم الاسم العادي أبداً في الأسعار أو الاستهلاك.**  
دائماً استخدم الـ identifier الكامل.

---

## الحقول الإلزامية

| الحقل | النوع | شرح |
|-------|-------|-----|
| `identifier` | string | المعرف الفريد |
| `type` | string | `"material"` حالياً |
| `name` | object | `{ "en": "...", "ar": "..." }` |
| `description` | object | وصف ثنائي اللغة |
| `tags` | array | قائمة وسوم |
| `texture` | string | مسار نسبي من داخل مجلد items |
| `icon` | string | نفس المسار أو نسخة أصغر |
| `stackable` | bool | هل يُكدّس |
| `maxStack` | number | الحد الأقصى |
| `displayInUIBars` | bool | يظهر في شريط الموارد فوق الخريطة |
| `order` | number | ترتيب الظهور في الـ UI |

---

## الوسوم (Tags)

- `basic`      → يظهر في شريط الموارد الرئيسي فوق الخريطة
- `material`  → مادة خام
- `economy`   → مرتبط بالاقتصاد
- `currency`  → عملة (ذهب)
- `industrial`→ صناعي (حديد)
- `fuel`      → وقود (نفط)

---

## مثال كامل
انظر إلى `Gold.json` / `Iron.json` / `Oil.json`.

---

## ملاحظات مهمة
1. الأسعار في الوحدات والمباني تُكتب بالمعرف وليس بالاسم:
   ```json
   "cost": {
     "WOK:ECONOMY.MATERIAL.GOLD.BAR": 100,
     "WOK:ECONOMY.MATERIAL.IRON.INGOT": 100
   }
   ```
2. أي عنصر جديد تريد ظهوره في الشريط العلوي يجب أن يحمل وسم `basic`.
3. الـ Translator يقرأ كل ملفات `.json` في هذا المجلد (ما عدا نفسه) ويصدّرها.


---

## حدود السعر المحلي (Market bounds)

| الحقل | المعنى |
|--------|--------|
| `minLocalPrice` | أدنى مضاعف للسعر المحلي (الأصل = 1). الافتراضي الشائع **0.25** = 25% من السعر الأصلي |
| `maxLocalPrice` | أعلى مضاعف. الافتراضي الشائع **4** = 400% من السعر الأصلي |

سعر الوحدة بالذهب = `exchangeRate × localPrice` (محصور بين الحدود).

**الذهب:** `minLocalPrice` و `maxLocalPrice` = **1** دائماً (لا يتغير سعره المحلي).

احسب القيم وضعها في JSON — الكود يقرأها ولا يفترض 0.25/4 لكل عنصر مستقبلي.
