# PER — Performance notes

## WOK-PER-1.4.3
- Map-only Web Worker for regions.json parse (`map-loader.worker.js`)
- Render pause while heavy panels / confirm-clear open
- Resource bar: cached `.amt` element refs
- confirm-clear z-index 200 (above news 120)
- docs/FUNCTION_INDEX.md

## WOK-PER-1.4.2
- regions ~2.1MB, IDB/Cache, res-bar rAF batch, targetFps 30

## Next (R series prep)
- Playtest confirm-clear + news
- Optional deeper game.js state-bag split
