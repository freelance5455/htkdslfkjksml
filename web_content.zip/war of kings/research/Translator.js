/**
 * War of Kings — Research Translator
 * يقرأ ملفات JSON في research/ ويصدّر window.WOK_RESEARCH
 */
(function (global) {
  'use strict';

  const PATH = 'research/';
  const FILES = [
    'recruit.json',
    'powder_force.json',
    'naval_keel.json',
    'deep_hull.json',
    'sky_fleet.json',
    'aviation.json',
    'sky_ghost.json'
  ];

  async function loadJSON(path) {
    const res = await fetch(path);
    if (!res.ok) throw new Error('Failed to load ' + path);
    return res.json();
  }

  async function loadAll() {
    const map = Object.create(null);
    const list = [];
    for (const file of FILES) {
      try {
        const data = await loadJSON(PATH + file);
        if (!data || !data.identifier) continue;
        map[data.identifier] = data;
        list.push(data);
      } catch (err) {
        console.error('[Research] load failed:', file, err);
      }
    }
    list.sort((a, b) => (a.order || 0) - (b.order || 0));
    const result = {
      byId: map,
      list: list,
      military: list.filter(r => Array.isArray(r.tags) && r.tags.includes('military')),
      get: function (id) { return map[id] || null; }
    };
    global.WOK_RESEARCH = result;
    console.log('[Research] loaded', list.length);
    return result;
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () { loadAll().catch(console.error); });
    } else {
      loadAll().catch(console.error);
    }
  }
  global.WOK_ResearchTranslator = { loadAll: loadAll };
})(typeof window !== 'undefined' ? window : globalThis);
