# War of Kings — UI & Style Guide

Document describes the current menu UI (`main.html`), visual language, shapes, interaction, and navigation flow.

---

## 1. Screens & flow

```
main.html
├── Main Menu              (Play / Settings / Quit)
├── Settings               (categories + options)
├── Your Worlds            (list + Add World)
├── New World              (Offline / Online)
└── Create Offline World   (name + difficulty → Next)
```

### Navigation rules
- Every secondary screen has a **`< Back`** control in the corner.
- Opening Settings / Play **hides** the main three buttons and the title brand.
- Back from Settings or Your Worlds returns to Main Menu.
- Back from New World returns to Your Worlds.
- Back from Create Offline World returns to New World.
- Orientation toggle (`⟳`) is always available on all screens.

---

## 2. Visual style (glass dark)

| Token | Value | Use |
|--------|--------|-----|
| Page / ocean bg | `#0a1525` | Full-screen base |
| Glass fill | `rgba(0,0,0,0.45–0.55)` | Buttons, cards, controls |
| Glass fill hover | `rgba(0,0,0,0.55–0.62)` | Hover / focus |
| Blue outline | `rgba(90,170,255,0.45–0.55)` | Default borders |
| Blue outline strong | `rgba(130,200,255,0.85–0.95)` | Hover / active |
| Red outline | `rgba(255,90,90,0.55)` | Danger (Quit) |
| Green outline | `rgba(80,210,140,0.55)` | Positive (Add World, Online) |
| Text primary | `#e8f2ff` / `#e8f4ff` | Titles, button labels |
| Text secondary | `#9fd0ff` / `#7aa8d4` / `#6a90b8` | Hints, meta |
| Blur | `backdrop-filter: blur(10–14px)` | Glass depth |
| Shadow | `0 4–16px` soft black | Elevation |

**Principle:** semi-transparent black panels on the living map, thin colored outlines, no solid opaque blocks.

---

## 3. Shapes & geometry

| Element | Shape | Notes |
|---------|--------|--------|
| Main menu buttons | Rounded rect, **`border-radius: 18%`** | Stacked vertically |
| Button gap | **`5px`** between edges | Fixed |
| Layer cards | `border-radius: 16px` | Wider panels (`min(520–560px, 92–94vw)`) |
| Small controls (Back, orient) | `border-radius: 10px` | Pill-ish but not full capsule |
| Category chips | `border-radius: 10px` | Settings left/right column |
| Selects | `border-radius: 10px` | Full width of content column |
| Slider track | Fully rounded (`99px`) | Height ~8px |
| Slider thumb | Circle **20×20** | Blue fill + light border |
| World list items | `border-radius: 12px` | Same glass language |

### Main menu layout
```
        [ Brand title ]
              |
    +------------------+
    |      Play        |  ← same width, 18% corners
    +------------------+  5px
    |    Settings      |
    +------------------+  5px
    |      Quit        |  ← red outline
    +------------------+
```

Portrait: panel ~260px wide.  
Landscape: panel ~240px / 40vw, brand higher.

---

## 4. Components

### 4.1 Menu button (`.menu-btn`)
- Glass black + blue outline (default)
- **Danger** (`.danger`): red outline, warm text
- **OK** (`.ok`): green outline
- States: default → hover (brighter border + deeper fill) → active (scale ~0.97)

### 4.2 Glass control (`.glass-ctrl`)
- Used for **Back** and **orientation toggle**
- Same glass recipe, smaller padding
- `.active` on orientation = currently locked landscape

### 4.3 Layer / window (`.layer` + `.layer-card`)
- Full-screen dim + light blur behind card
- Card: wider glass panel, blue outline, centered
- Title centered; Back sits top-left (LTR: top-right when English)

### 4.4 Settings split
```
+------------------------------------------+
|                 Settings                 |
|  +-----------+  +---------------------+  |
|  | General * |  | Language  [select]  |  |
|  | Touch     |  | Orientation [select]|  |
|  +-----------+  +---------------------+  |
+------------------------------------------+
```
- **Categories column** (visual right in RTL): narrow chips
- **Content column**: options for the selected category
- Active category: stronger blue fill/outline

### 4.5 Form controls
- **Select (`.glass-select`)**: glass field; **never use the native OS popup**
- **Range (`.glass-range`)**: dark track, blue circular thumb, live numeric value

### 4.6 Custom dropdown (animated select)
All `<select class="glass-select">` across the game (main, settings, create world, market trade, in-game settings) are enhanced by `js/custom-select.js`.

**Behavior**
- Click the field → menu **slides open** (`max-height` + opacity transition ~0.28s)
- Click the same field again → menu **closes**
- Click outside → all open menus close
- Choosing an option updates the hidden native `<select>`, fires `change`, then closes
- Dynamic option lists (e.g. market item list) rebuild automatically via `MutationObserver`

**Structure (generated)**
```
.wok-cs
├── select.glass-select.wok-cs-native   (hidden, keeps form value)
├── button.wok-cs-btn                   (visible trigger + label + caret)
└── .wok-cs-menu                        (animated panel)
    └── button.wok-cs-opt               (one per option; .active = selected)
```

**Visual**
- Trigger: same glass recipe as `.glass-select` (dark fill, blue border, 10px radius)
- Caret: small chevron that rotates when open
- Menu: dark panel `rgba(8,16,28,.96)`, blue outline, soft shadow, max height ~220px scrollable
- Active option: stronger blue fill

**Rules**
- Do **not** style or rely on native `<select>` popup appearance
- Always keep `class="glass-select"` on the underlying select so enhancement runs
- After injecting new selects at runtime, call `WOK_CustomSelect.enhanceAll()` (or `enhance(selectEl)`)
- Script is loaded on `main.html`, `select-country.html`, and `game.html`

---

## 5. Settings (persisted)

Storage key: `localStorage.wok_settings`

| Category | Setting | Type | Range / values | Default |
|----------|---------|------|----------------|---------|
| General | Language | select | `en`, `ar` | `ar` |
| General | Default orientation | select | `portrait`, `landscape` | `portrait` |
| Touch | Map sensitivity | slider | `0.5` … `2` step `0.05` | `1` |

- Language switches `dir` / `lang` and all `data-i18n` strings immediately.
- Default orientation is the **permanent** preferred mode after relaunch (and when changed in Settings). Manual toggle still works in-session; next cold start follows the saved default.
- Sensitivity multiplies map pan speed via `MapEngine.setPanSensitivity()` (used in gameplay views that share the engine).

Worlds list key: `localStorage.wok_worlds` (array; empty until gameplay saves worlds).

---

## 6. Background map

- Full-viewport canvas under UI (`MapEngine`)
- Locked to **min zoom** (full world framed)
- Idle **longitude spin** ~2.2°/sec (slow, continuous)
- Soft radial vignette over the map for text contrast
- Canvas `pointer-events: none` on the menu so it does not steal taps

---

## 7. Orientation toggle

- Control: top corner (`#btn-landscape`)
- Tries: fullscreen → `screen.orientation.lock('landscape'|'portrait')`
- Fallback label asks the user to rotate the device
- On success, map is refit (`_minZoom`, clamp, redraw)

---

## 8. Quit behavior

Order of attempts:
1. **Android WebView:** `window.Android.quit()` → activity `finishAffinity()` + exit  
2. Stop background RAF spin  
3. Exit fullscreen if any  
4. `window.close()` (only if the environment allows)  
5. Fallback: clear DOM and navigate to `about:blank`

Android bridge is registered in `MainActivity` as `Android` (`@JavascriptInterface quit()`).  
Entry page on Android: `file:///android_asset/main.html`.

---

## 9. Files

| File | Role |
|------|------|
| `main.html` | Main menu UI + settings + worlds shell |
| `index.html` | Live map sandbox (game canvas entry) |
| `test.html` | Dev tests (selection, occupy, HUD) |
| `css/style.css` | Styles for `index.html` map view |
| `js/map-engine.js` | Map renderer + pan sensitivity API |
| `js/main.js` | Map entry for `index.html` |
| `UI.md` | This document |

---

## 10. Do / Don’t

**Do**
- Keep glass black + colored outline language for new controls
- Keep 5px stack gap and 18% radius on primary menu buttons
- Persist user prefs under `wok_settings`
- Provide Back on every overlay

**Don’t**
- Solid opaque primary buttons (breaks the glass look)
- Over-bright fills that hide the living map
- Settings without category split when adding many options
- Hard-code strings without `data-i18n` when user-facing

---

*Last updated with glass UI, Settings (General / Touch), and Quit bridge.*

---

## File split (2026-11-17)

Screen-specific styles and logic were moved out of the HTML files for maintainability:

- `main.html` → `css/main.css` + `js/main-menu.js`
- `select-country.html` → `css/select-country.css` + `js/select-country.js`
- `game.html` → `css/game.css` + `js/game.js`

HTML files keep structure and script/link tags only. See `README.md` and `docs/DECISIONS.md`.
