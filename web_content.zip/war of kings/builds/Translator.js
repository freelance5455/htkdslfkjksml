/**
 * War of Kings — Builds Translator
 * يقرأ ملفات JSON في مجلد builds ويحوّلها إلى كائنات جاهزة.
 * يصدّر النتيجة إلى window.WOK_BUILDS
 */
(function (global) {
  'use strict';

  const BUILDS_PATH = 'builds/';
  const FILES = [
    'gold_mine.json',
    'iron_mine.json',
    'oil_rig.json'
  ];

  async function loadJSON(path) {
    const res = await fetch(path);
    if (!res.ok) throw new Error('Failed to load ' + path);
    return res.json();
  }

  async function loadAll() {
    const map = Object.create(null);
    const list = [];

    for (const file of FILES) {
      try {
        const data = await loadJSON(BUILDS_PATH + file);
        if (!data || !data.identifier) {
          console.warn('[Builds] missing identifier in', file);
          continue;
        }
        map[data.identifier] = data;
        list.push(data);
      } catch (err) {
        console.error('[Builds] load failed:', file, err);
      }
    }

    list.sort((a, b) => (a.order || 0) - (b.order || 0));

    const result = {
      byId: map,
      list: list,
      mines: list.filter(b => Array.isArray(b.tags) && b.tags.includes('mine')),
      basic: list.filter(b => Array.isArray(b.tags) && b.tags.includes('basic')),
      get: function (id) { return map[id] || null; }
    };

    global.WOK_BUILDS = result;
    console.log('[Builds] loaded', list.length, 'buildings');
    return result;
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => loadAll().catch(console.error));
    } else {
      loadAll().catch(console.error);
    }
  }

  global.WOK_BuildsTranslator = { loadAll };
})(typeof window !== 'undefined' ? window : globalThis);
