# BUILDS — دليل كتابة ملفات المباني / المناجم

## صيغة المعرف
```
WOK:ECONOMY.BUILDING.<CATEGORY>.<NAME>
```
أمثلة:
- `WOK:ECONOMY.BUILDING.MINE.GOLD`
- `WOK:ECONOMY.BUILDING.MINE.IRON`
- `WOK:ECONOMY.BUILDING.MINE.OIL`

---

## الحقول الإلزامية

| الحقل | شرح |
|-------|-----|
| `identifier` | المعرف الفريد |
| `type` | `"building"` |
| `name` / `description` | `{en, ar}` |
| `tags` | وسوم |
| `texture` / `icon` | مسار نسبي داخل builds/ |
| `cost` | مفاتيحه **معرفات المواد** |
| `buildTimeMinutes` | مدة البناء بالدقائق الواقعية |
| `production` | كائن الإنتاج |
| `defaultStartingCount` | الكمية عند بداية العالم |
| `storagePerBuilding` | حد تكديس الإنتاج **لكل** مبنى (الإجمالي = × العدد) |
| `order` | ترتيب |

---

## كائن الإنتاج
```json
"production": {
  "resource": "WOK:ECONOMY.MATERIAL.GOLD.BAR",
  "amountPerMinute": 1.2,
  "amountPerSecond": 0.02
}
```

وحدة الزمن الأساسية = **دقيقة واقعية**.

---

## القيم الحالية

| المبنى | التكلفة | المدة | الإنتاج | البداية |
|--------|---------|-------|---------|--------|
| منجم ذهب | 1000 ذهب + 200 حديد | 3 دقائق | 1.2 ذهب/دقيقة | 100 |
| منجم حديد | 600 ذهب + 200 حديد | 5 دقائق | 1 حديد/دقيقة | 50 |
| منصة نفط | 1200 ذهب + 400 حديد | 6 دقائق | 0.9 نفط/دقيقة | 40 |

---

## قاعدة التسمية
دائماً استخدم المعرف الكامل في `cost` و `production.resource`.  
لا تكتب `"Gold"` أو `"حديد"`.
