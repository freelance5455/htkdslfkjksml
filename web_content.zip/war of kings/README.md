# War of Kings

لعبة استراتيجية جيوسياسية / عسكرية تعمل في المتصفح (PWA)، بواجهة عربية (RTL) ودعم إنجليزي في البيانات.

**الإصدار الحالي:** WOK-PER-1.4.0 (Performance)

**الوصف القصير:** سيطرة على العالم عبر الموارد والمباني والوحدات والأبحاث على خريطة حقيقية.

---

## التشغيل

1. افتح المجلد كخادم محلي (مطلوب بسبب `fetch` للـ JSON والـ GeoJSON):

```bash
# مثال بـ Python
cd "war of kings"
python3 -m http.server 8080
```

2. افتح المتصفح على: `http://localhost:8080/main.html`  
   أو `index.html` (خريطة تجريبية).

3. للتجربة على الموبايل: استخدم وضع landscape ويفضّل إضافتها كـ Web App من المتصفح.

> **ملاحظة:** فتح الملفات مباشرة بـ `file://` لن يعمل بشكل صحيح بسبب سياسات CORS.

---

## هيكل المشروع

```
war of kings/
├── main.html              # القائمة الرئيسية / الإعدادات / العوالم
├── select-country.html    # اختيار الدولة للعالم الجديد
├── game.html              # شاشة اللعب
├── index.html             # دخول بسيط للخريطة (تطوير)
├── manifest.json          # PWA
├── script.js              # بيانات مشتركة (GameData)
├── UI.md                  # دليل الواجهة والثيم الزجاجي
├── README.md              # هذا الملف
├── docs/
│   └── DECISIONS.md       # قرارات تصميمية (دمج جغرافي، توازن…)
├── css/
│   ├── style.css          # أنماط عامة
│   ├── main.css           # أنماط القائمة
│   ├── game.css           # أنماط شاشة اللعب
│   └── select-country.css
├── js/
│   ├── map-engine.js      # محرك الخريطة
│   ├── military.js        # النظام العسكري
│   ├── bot.js             # ذكاء الدول
│   ├── game.js            # منطق شاشة اللعب
│   ├── main-menu.js       # منطق القائمة
│   ├── select-country.js
│   ├── flags.js, terrain.js, news.js, custom-select.js
│   └── topojson-client.min.js
├── data/                  # خرائط وموارد الدول
├── items/                 # المواد (ذهب، حديد، نفط) + Translator
├── builds/                # المباني الإنتاجية
├── units/                 # الوحدات العسكرية
├── research/              # شجرة الأبحاث
└── assets/flags/          # أعلام الدول
```

---

## تدفق الشاشات

```
main.html
  ├── Main Menu (Play / Settings / Quit)
  ├── Settings
  ├── Your Worlds → New World → Create Offline World
  └── → select-country.html → game.html
```

كل شاشة ثانوية تحتوي زر رجوع. إعداد التوجه (landscape/portrait) محفوظ في الجلسة.

---

## نظام المعرفات (Identifiers)

**لا تستخدم الأسماء العادية في الأسعار أو الإنتاج.** دائماً المعرف الكامل:

| النوع   | الصيغة                                      | مثال |
|---------|---------------------------------------------|------|
| مادة    | `WOK:ECONOMY.MATERIAL.<NAME>.<FORM>`        | `WOK:ECONOMY.MATERIAL.GOLD.BAR` |
| مبنى    | `WOK:ECONOMY.BUILDING.<...>`                | `WOK:ECONOMY.BUILDING.MINE.GOLD` |
| وحدة    | `WOK:MILITARY.UNIT.<DOMAIN>.<NAME>`         | `WOK:MILITARY.UNIT.LAND.TANK` |
| بحث     | `WOK:RESEARCH.MILITARY.<...>`               | `WOK:RESEARCH.MILITARY.RECRUIT` |

كل مجلد بيانات (`items`, `builds`, `units`, `research`) يحتوي:
- ملفات `.json` للكيانات
- `Learn.md` يشرح الحقول
- `Translator.js` يحمّل كل الملفات ويصدّر كائناً عالمياً (`WOK_ITEMS`, `WOK_UNITS`, …)

---

## الموارد والمباني الابتدائية

- **ذهب / حديد / نفط** تظهر في شريط الموارد إذا وُسمت بـ `basic`.
- عدد المناجم الابتدائي مرتفع عمداً (مثلاً 100 منجم ذهب) لأن إنتاج المنجم الواحد منخفض؛ الهدف إنتاج لحظي معتدل (~1 ذهب/ثانية) دون تحويل اللعبة إلى idle طويل. اللاعب يبقى متفاعلاً باستخدام الذهب ومراقبة العدادات.

راجع `builds/*.json` و `items/*.json` و `docs/DECISIONS.md`.

---

## التطوير السريع

| مهمة | أين |
|------|-----|
| إضافة مادة | `items/New.json` + سطر في `items/Translator.js` |
| إضافة مبنى | `builds/New.json` + Translator |
| إضافة وحدة | `units/New.json` + Translator |
| إضافة بحث | `research/New.json` + Translator + ربط `unlocksUnits` / `requires` |
| تعديل الثيم | `UI.md` + ملفات `css/` |
| قرارات جغرافية | `data/country-merge.json` + `docs/DECISIONS.md` |

---

## المتصفحات المستهدفة

- Chrome / Edge / Safari حديث (دعم `backdrop-filter` و Canvas و ES6).
- موجه للمس والـ landscape على الموبايل.

---

## الترخيص والمحتوى

المشروع قيد التطوير. بيانات الخرائط من مصادر TopoJSON/GeoJSON عامة الاستخدام في مثل هذه المشاريع. الأعلام والملمس ملك للمشروع أو مرخّصة للاستخدام داخل اللعبة.
