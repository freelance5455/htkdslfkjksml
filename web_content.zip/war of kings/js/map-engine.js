/**
 * map-engine.js — PER-1.4.0
 * Logical sections (future split targets):
 *   1) Data load / topojson parse
 *   2) Projection & geometry simplify
 *   3) Draw loop (RAF / DPR / layers)
 *   4) Interaction (pan, zoom, hit-test)
 *   5) Region styles, borders, islands filter
 *   6) Units / movement overlays
 * Shared perf defaults: script.js → WOK_perfDefaults / WOK_isMobile
 * Panel lifecycle: js/panels.js
 */
/**
 * War of Kings – Map Engine (complete rewrite)
 *
 * - No country selection / hover (disabled)
 * - Proper antimeridian split for Russia, Fiji, etc.
 * - Israel + Palestine geometries merged → single "Palestine"
 * - Seamless wrap: only offset the features that need it (never 3 full worlds)
 * - Dirty-flag rendering only
 * - Two LOD levels (110m / 50m) with clean switch
 * - Mobile / landscape WebView oriented
 */

(function (global) {
  'use strict';

  const CFG = {
    WORLD_W: 360,
    // Cropped mercator height so poles sit near edges (less void past Antarctica)
    WORLD_H: 300,
    LAT_MAX: 85.05112878,
    MIN_ZOOM: 1.0,            // raised dynamically in _minZoom()
    MAX_ZOOM: 42,
    // ── 5 LOD tiers ──
    LOD1: 1.6,   // 1: coarse countries (110m simplified)
    LOD2: 3.2,   // 2: full countries (110m simplified)
    LOD3: 5.5,   // 3: large regions only, low border detail
    LOD4: 9.0,   // 4: more regions, medium detail (still simplified)
    LOD5: 12.0,  // 5: full detail (50m + all region borders/fills)
    REGION_ZOOM_START: 4.2,
    REGION_ZOOM_FULL: 10.5,
    BG: '#0a1525',
    LAND: '#1a3350',
    STROKE: '#4a8ec0',
    // border widths in SCREEN PIXELS (stable, no zoom glitches)
    COUNTRY_PX: 1.85,
    REGION_PX: 1.0,
    REGION_STROKE: '#3a6a92'
  };

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  /** Geographic lat → Web-Mercator Y (same units as lon degrees, ≈±180) */
  function mercY(lat) {
    const l = clamp(lat, -CFG.LAT_MAX, CFG.LAT_MAX);
    const φ = l * Math.PI / 180;
    return Math.log(Math.tan(Math.PI / 4 + φ / 2)) * (180 / Math.PI);
  }
  function invMercY(y) {
    const φ = 2 * Math.atan(Math.exp(y * Math.PI / 180)) - Math.PI / 2;
    return φ * 180 / Math.PI;
  }
  /** Project a [lon,lat] ring in-place-style → [lon, mercY] */
  function projectRing(ring) {
    const out = new Array(ring.length);
    for (let i = 0; i < ring.length; i++) {
      const p = ring[i];
      out[i] = [p[0], mercY(p[1])];
    }
    return out;
  }
  function projectGeom(geom) {
    if (!geom) return geom;
    if (geom.type === 'Polygon') {
      return { type: 'Polygon', coordinates: geom.coordinates.map(projectRing) };
    }
    if (geom.type === 'MultiPolygon') {
      return {
        type: 'MultiPolygon',
        coordinates: geom.coordinates.map(poly => poly.map(projectRing))
      };
    }
    return geom;
  }

  // ─────────────────────────────────────────────
  /**
   * Unwrap longitudes so a ring is continuous (no ±180 jumps).
   * Russia/Fiji become one polygon that may extend past ±180 — no diagonal cuts.
   */
  function unwrapRing(ring) {
    if (!ring || ring.length < 2) return ring;
    const out = [ring[0].slice()];
    for (let i = 1; i < ring.length; i++) {
      let lon = ring[i][0];
      const prev = out[out.length - 1][0];
      while (lon - prev > 180) lon -= 360;
      while (prev - lon > 180) lon += 360;
      out.push([lon, ring[i][1]]);
    }
    // close if needed
    if (out.length >= 3) {
      const a = out[0], b = out[out.length - 1];
      if (a[0] !== b[0] || a[1] !== b[1]) out.push(a.slice());
    }
    return out;
  }

  function fixGeometry(geom) {
    if (!geom || !geom.coordinates) return geom;

    if (geom.type === 'Polygon') {
      return {
        type: 'Polygon',
        coordinates: geom.coordinates.map(unwrapRing)
      };
    }
    if (geom.type === 'MultiPolygon') {
      return {
        type: 'MultiPolygon',
        coordinates: geom.coordinates.map(poly => poly.map(unwrapRing))
      };
    }
    return geom;
  }

  function bboxOf(geom) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    const visit = (c) => {
      if (typeof c[0] === 'number') {
        if (c[0] < minX) minX = c[0];
        if (c[0] > maxX) maxX = c[0];
        if (c[1] < minY) minY = c[1];
        if (c[1] > maxY) maxY = c[1];
      } else {
        for (let i = 0; i < c.length; i++) visit(c[i]);
      }
    };
    visit(geom.coordinates);
    if (!isFinite(minX)) return { minX: -180, minY: -90, maxX: 180, maxY: 90 };
    return { minX, minY, maxX, maxY };
  }


  const MIN_ISLAND_KM2 = 50000; // permanent recognition + optional draw filter

  /** Approximate area of a lon/lat ring in km² (planar at mean latitude). */
  function ringAreaKm2(ring) {
    if (!ring || ring.length < 3) return 0;
    let a = 0, latSum = 0, n = 0;
    for (let i = 0; i < ring.length - 1; i++) {
      const x1 = ring[i][0], y1 = ring[i][1];
      const x2 = ring[i + 1][0], y2 = ring[i + 1][1];
      a += x1 * y2 - x2 * y1;
      latSum += y1;
      n++;
    }
    a = Math.abs(a) * 0.5;
    if (!n || !isFinite(a)) return 0;
    const lat = latSum / n;
    const kmLat = 110.574;
    const kmLon = 111.320 * Math.cos((lat * Math.PI) / 180);
    return a * kmLat * Math.max(0.05, Math.abs(kmLon));
  }

  function polyAreaKm2(poly) {
    if (!poly || !poly.length) return 0;
    return ringAreaKm2(poly[0]); // exterior ring only
  }

  /** Largest polygon component area (km²) of a lon/lat geometry. */
  function maxComponentKm2(geom) {
    if (!geom) return 0;
    if (geom.type === 'Polygon') return polyAreaKm2(geom.coordinates);
    if (geom.type === 'MultiPolygon') {
      let m = 0;
      for (let i = 0; i < geom.coordinates.length; i++) {
        const a = polyAreaKm2(geom.coordinates[i]);
        if (a > m) m = a;
      }
      return m;
    }
    return 0;
  }

  /**
   * Drop ONLY small detached island polygons (&lt; minKm2).
   * Never removes a country's largest land component (keeps Switzerland, Malta, etc.).
   * Sole Polygon countries are NEVER stripped — hiding islands ≠ hiding small countries.
   */
  function filterSmallIslandsGeom(geom, minKm2) {
    if (!geom) return null;
    minKm2 = minKm2 != null ? minKm2 : MIN_ISLAND_KM2;
    if (geom.type === 'Polygon') {
      // Single body country/territory — always keep (even if &lt; 50k km²)
      return geom;
    }
    if (geom.type === 'MultiPolygon') {
      const polys = geom.coordinates || [];
      if (!polys.length) return null;
      let maxA = 0;
      const areas = [];
      for (let i = 0; i < polys.length; i++) {
        const a = polyAreaKm2(polys[i]);
        areas.push(a);
        if (a > maxA) maxA = a;
      }
      const kept = [];
      for (let i = 0; i < polys.length; i++) {
        const a = areas[i];
        // keep largest body always; drop only smaller detached islands under threshold
        if (a >= minKm2 || a >= maxA - 1e-6) kept.push(polys[i]);
      }
      if (!kept.length) return geom; // safety
      if (kept.length === 1) return { type: 'Polygon', coordinates: kept[0] };
      return { type: 'MultiPolygon', coordinates: kept };
    }
    return geom;
  }

  /** Ramer–Douglas–Peucker — fewer coastal segments (LOD stroke density). */
  function rdpRing(ring, tol) {
    if (!ring || ring.length < 3) return ring;
    const tol2 = tol * tol;
    const n = ring.length;
    // Keep closed ring: last ≈ first
    const pts = ring;
    const keep = new Uint8Array(n);
    keep[0] = 1;
    keep[n - 1] = 1;
    const stack = [[0, n - 1]];
    while (stack.length) {
      const seg = stack.pop();
      const a = seg[0], b = seg[1];
      const ax = pts[a][0], ay = pts[a][1], bx = pts[b][0], by = pts[b][1];
      const dx = bx - ax, dy = by - ay;
      const len2 = dx * dx + dy * dy;
      let maxD = -1, maxI = -1;
      for (let i = a + 1; i < b; i++) {
        const px = pts[i][0], py = pts[i][1];
        let d;
        if (len2 < 1e-12) {
          const ex = px - ax, ey = py - ay;
          d = ex * ex + ey * ey;
        } else {
          let t = ((px - ax) * dx + (py - ay) * dy) / len2;
          if (t < 0) t = 0; else if (t > 1) t = 1;
          const qx = ax + t * dx - px, qy = ay + t * dy - py;
          d = qx * qx + qy * qy;
        }
        if (d > maxD) { maxD = d; maxI = i; }
      }
      if (maxD > tol2 && maxI >= 0) {
        keep[maxI] = 1;
        stack.push([a, maxI], [maxI, b]);
      }
    }
    const out = [];
    for (let i = 0; i < n; i++) if (keep[i]) out.push(pts[i]);
    if (out.length < 5) return ring;
    // ensure closed
    const f = out[0], l = out[out.length - 1];
    if (f[0] !== l[0] || f[1] !== l[1]) out.push([f[0], f[1]]);
    return out;
  }

  /** RDP for open polylines (region borders borders). */
  function rdpLine(line, tol) {
    if (!line || line.length < 3) return line;
    const tol2 = tol * tol;
    const n = line.length;
    const keep = new Uint8Array(n);
    keep[0] = 1;
    keep[n - 1] = 1;
    const stack = [[0, n - 1]];
    while (stack.length) {
      const seg = stack.pop();
      const a = seg[0], b = seg[1];
      if (b - a < 2) continue;
      const ax = line[a][0], ay = line[a][1], bx = line[b][0], by = line[b][1];
      const dx = bx - ax, dy = by - ay;
      const len2 = dx * dx + dy * dy;
      let maxD = -1, maxI = -1;
      for (let i = a + 1; i < b; i++) {
        const px = line[i][0], py = line[i][1];
        let d;
        if (len2 < 1e-12) {
          const ex = px - ax, ey = py - ay;
          d = ex * ex + ey * ey;
        } else {
          let tt = ((px - ax) * dx + (py - ay) * dy) / len2;
          if (tt < 0) tt = 0; else if (tt > 1) tt = 1;
          const qx = ax + tt * dx - px, qy = ay + tt * dy - py;
          d = qx * qx + qy * qy;
        }
        if (d > maxD) { maxD = d; maxI = i; }
      }
      if (maxD > tol2 && maxI >= 0) {
        keep[maxI] = 1;
        stack.push([a, maxI], [maxI, b]);
      }
    }
    const out = [];
    for (let i = 0; i < n; i++) if (keep[i]) out.push(line[i]);
    return out.length >= 2 ? out : line;
  }

  function linesToPath(lines) {
    const path = new Path2D();
    if (!lines) return path;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (!line || line.length < 2) continue;
      path.moveTo(line[0][0], line[0][1]);
      for (let j = 1; j < line.length; j++) path.lineTo(line[j][0], line[j][1]);
    }
    return path;
  }

    function simplifyProjectedGeom(geom, tol) {
    if (!geom || !(tol > 0)) return geom;
    const simpPoly = (poly) => poly.map((ring) => rdpRing(ring, tol));
    if (geom.type === 'Polygon') {
      return { type: 'Polygon', coordinates: simpPoly(geom.coordinates) };
    }
    if (geom.type === 'MultiPolygon') {
      return {
        type: 'MultiPolygon',
        coordinates: geom.coordinates.map(simpPoly)
      };
    }
    return geom;
  }

  function toPath(geom) {
    const path = new Path2D();
    const ring = (r) => {
      if (!r || r.length < 2) return;
      path.moveTo(r[0][0], r[0][1]);
      for (let i = 1; i < r.length; i++) path.lineTo(r[i][0], r[i][1]);
      path.closePath();
    };
    if (geom.type === 'Polygon') {
      for (const r of geom.coordinates) ring(r);
    } else if (geom.type === 'MultiPolygon') {
      for (const poly of geom.coordinates)
        for (const r of poly) ring(r);
    }
    return path;
  }

  // ─────────────────────────────────────────────
  // Country feature
  // ─────────────────────────────────────────────
  class Country {
    constructor(id, name, geometry) {
      this.id = id;
      this.name = name;
      // Keep lon/lat (unwrapped) for island area tests before mercator project
      this._lonLatGeom = fixGeometry(geometry);
      this.maxIslandKm2 = maxComponentKm2(this._lonLatGeom);
      // antimeridian fix in lon/lat, then Mercator project
      this.geometry = projectGeom(this._lonLatGeom);
      this.bbox = bboxOf(this.geometry);
      this.path = toPath(this.geometry);
      // pathSimple: far LOD. pathMid: realistic borders for LOD3–5.
      this.pathSimple = toPath(simplifyProjectedGeom(this.geometry, 0.42));
      this.pathMid = toPath(simplifyProjectedGeom(this.geometry, 0.30));
      this.cx = (this.bbox.minX + this.bbox.maxX) * 0.5;
      this.cy = (this.bbox.minY + this.bbox.maxY) * 0.5;
    }
    /**
     * Rebuild path from lon/lat.
     * hideSmall = strip detached MultiPolygon islands &lt; 50k km² only.
     * Never deletes a whole country (even if the country is &lt; 50k km²).
     */
    applyIslandFilter(hideSmall) {
      let g = this._lonLatGeom;
      if (!g) return false;
      if (hideSmall) {
        const filtered = filterSmallIslandsGeom(g, MIN_ISLAND_KM2);
        g = filtered || g;
      }
      this.geometry = projectGeom(g);
      this.bbox = bboxOf(this.geometry);
      this.path = toPath(this.geometry);
      this.pathSimple = toPath(simplifyProjectedGeom(this.geometry, 0.42));
      this.pathMid = toPath(simplifyProjectedGeom(this.geometry, 0.30));
      this.cx = (this.bbox.minX + this.bbox.maxX) * 0.5;
      this.cy = (this.bbox.minY + this.bbox.maxY) * 0.5;
      return true;
    }
  }

  // ─────────────────────────────────────────────
  // Engine
  // ─────────────────────────────────────────────
  
  const MAP_CACHE = 'wok-map-cache-v142';
  async function fetchJSONCached(url) {
    // PER-1.4.2: regions use dedicated IndexedDB + Cache layer
    if (url && /regions\.json(\?|$)/.test(String(url)) && global.WOK_RegionsCache && WOK_RegionsCache.load) {
      try {
        return await WOK_RegionsCache.load(url);
      } catch (e) {
        try { console.warn('[Map] RegionsCache failed, network fallback', e); } catch (_) {}
      }
    }
    try {
      if (typeof caches !== 'undefined') {
        const cache = await caches.open(MAP_CACHE);
        let res = await cache.match(url);
        if (!res) {
          res = await fetch(url);
          if (res && res.ok) {
            try { await cache.put(url, res.clone()); } catch (_) {}
          }
        }
        if (res && res.ok) return res.json();
      }
    } catch (_) {}
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to load ' + url);
    return res.json();
  }

class MapEngine {
    constructor(canvas, options = {}) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d', { alpha: false });
      // Cap DPR for mobile performance (12fps → target 30+)
      this.dpr = Math.min(Math.min(window.devicePixelRatio || 1, (typeof window.WOK_isMobile === "function" && WOK_isMobile()) ? 1.75 : 2), 1.5);

      this.camLon = 25;
      this.camLat = mercY(20); // mercator Y
      this.hideSmallIslands = false;
      this._countryBorderDetail = 32;
      this._regionBorderDetail = (typeof window.WOK_isMobile === 'function' && WOK_isMobile())
        || /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent || '') ? 18 : 32;
      this.zoom = 1.0;

      this.lod = { low: [], med: [] };
      this.regions = [];
      this.visible = [];
      this.visibleRegions = [];
      this.ready = false;
      this.dirty = true;
      this.renderPaused = false; // PER-1.4.3 panels
      this._raf = null;
      this._currentLod = 'low';

      // style overrides: name → { border?, fill? }
      this.countryStyles = new Map();
      this.regionStyles = new Map();
      /** country name → { gold, iron, oil, total }  (always total ≈ 3.5) */
      this.countryResources = new Map();
      /** small/invalid country → absorbed into this name (area < 10k km² or dependency) */
      this.countryMerge = new Map();
      /** Natural Earth short names → game canonical names */
      this.countryAliases = new Map();
      /** country → { lon, lat, mercY } capital */
      this.countryCapitals = new Map();

      // interaction: distinguish pan / pinch / tap / long-press
      this.pointers = new Map();
      this.lastPinch = 0;
      this.zoomSensitivity = 1;
      this._press = null; // { x, y, t, id, moved }
      this._longTimer = null;
      this.TAP_MAX_MOVE = options.tapMaxMove != null ? options.tapMaxMove : 24; // px
      this.LONG_PRESS_MS = options.longPressMs != null ? options.longPressMs : 480;
      /** movement allowed while arming long-press (finger jitter) */
      this.LONG_PRESS_SLOP = options.longPressSlop != null ? options.longPressSlop : 56;

      this.onStats = options.onStats || null;
      this.onTap = options.onTap || null;           // ({ country, region, lon, lat })
      this.onLongPress = options.onLongPress || null;
      this.onLongPressEnd = options.onLongPressEnd || null;
      /** regionKey → [{ id, count, icon }] drawn only at high LOD */
      this.regionUnitMarkers = new Map();
      this._unitImgCache = new Map();
      this.militaryMoves = [];
      this._regionCenters = new Map();

      this._fc = 0;
      this._ft = performance.now();
      this.fps = 0;
      // Adaptive performance (device + runtime frame cost)
      this.perf = this._detectPerf();
      this._frameTimes = [];
      this._lastDrawAt = 0;
      this._collectCacheKey = '';
      this._moveAnimTimer = null;

      this._bind();
      this._resize();
    }

    /**
     * @param {object} [opts] { onProgress(p,label), terrainQuality }
     */
    async load(lowUrl, medUrl, regionsUrl, opts) {
      opts = opts || {};
      const report = (p, label) => {
        if (opts.onProgress) opts.onProgress(p, label);
      };

      report(0.02, 'تحميل بيانات الخريطة…');
      const resourcesUrl = (opts && opts.resourcesUrl) || 'data/country-resources.json';
      const mergeUrl = (opts && opts.mergeUrl) || 'data/country-merge.json';
      const capitalsUrl = (opts && opts.capitalsUrl) || 'data/country-capitals.json';
      const tasks = [
        fetchJSONCached(lowUrl),
        fetchJSONCached(medUrl),
        fetchJSONCached(resourcesUrl).catch(() => null),
        fetchJSONCached(mergeUrl).catch(() => null),
        fetchJSONCached(capitalsUrl).catch(() => null)
      ];
      if (regionsUrl) tasks.push(fetchJSONCached(regionsUrl).catch(() => null));

      const results = await Promise.all(tasks);
      const tLow = results[0];
      const tMed = results[1];
      const resData = results[2];
      const mergeData = results[3];
      const capData = results[4];
      const regData = regionsUrl ? results[5] : null;

      // country merge rules (area < 10k km² or non-sovereign territories)
      this.countryMerge = new Map();
      if (mergeData && typeof mergeData === 'object') {
        for (const [src, dst] of Object.entries(mergeData)) {
          if (src && dst) this.countryMerge.set(src, dst);
        }
        console.log('[Map] Country merge rules:', this.countryMerge.size);
      }

      // Natural Earth name aliases → canonical game names
      this._initCountryAliases();

      // Capitals (geographic lon/lat → mercator Y stored)
      this.countryCapitals = new Map();
      if (capData && typeof capData === 'object') {
        for (const [name, v] of Object.entries(capData)) {
          if (!v) continue;
          const lon = +v.lon, lat = +v.lat;
          this.countryCapitals.set(name, { lon, lat, mercY: mercY(lat) });
        }
        console.log('[Map] Capitals:', this.countryCapitals.size);
      }

      report(0.2, 'بناء الدول…');
      // Coarse 110m first; 50m deferred after ready (see background build below)
      this.lod.low = this._build(tLow);
      this.lod.med = [];
      this._pendingMedTopo = tMed;

      // ── country resource reserves (gold / iron / oil) ──
      this.countryResources = new Map();
      if (resData && typeof resData === 'object') {
        for (const [name, vals] of Object.entries(resData)) {
          if (!vals || typeof vals !== 'object') continue;
          const gold = +vals.gold || 0;
          const iron = +vals.iron || 0;
          const oil  = +vals.oil  || 0;
          this.countryResources.set(name, {
            gold, iron, oil,
            total: Math.round((gold + iron + oil) * 100) / 100
          });
        }
        console.log('[Map] Country resources:', this.countryResources.size);
      }

      if (regData && regData.regions) {
        report(0.4, 'بناء الأقاليم…');
        this.regions = this._buildRegions(regData.regions);
        this._initPolitics();
        if (typeof Terrain !== 'undefined' && Terrain.computeFromRegions) {
          const list = this.regions.map(r => ({
            key: r.key,
            id: r.id,
            name: r.name,
            country: r.country,
            lat: invMercY(r.cy != null ? r.cy : (r.bbox.minY + r.bbox.maxY) * 0.5),
            lon: ((r.cx + 180) % 360 + 360) % 360 - 180
          }));
          Terrain.computeFromRegions(list);
        }
        // Largest first — used for progressive region LOD (25 / 125 / all)
        this._regionsByArea = this.regions.slice().sort(function (a, b) {
          return (b.area || 0) - (a.area || 0);
        });
        console.log('[Map] Regions:', this.regions.length);
      }

      if (typeof Terrain !== 'undefined') {
        report(0.5, 'توليد التضاريس…');
        await Terrain.buildAll({
          quality: opts.terrainQuality || 'med',
          worldW: CFG.WORLD_W,
          worldH: CFG.WORLD_H,
          onProgress: (tp) => {
            report(0.5 + tp * 0.45, 'توليد التضاريس… ' + Math.round(tp * 100) + '%');
          }
        });
        console.log('[Map] Terrain ready, quality=', Terrain.quality);
      }

      if (opts && opts.hideSmallIslands) {
        this.setHideSmallIslands(true);
      }
      report(0.92, 'جاهز — تفاصيل إضافية…');
      this.ready = true;
      this._resize(); // ensure pixel buffer matches CSS size
      this.zoom = Math.max(this.zoom, this._minZoom());
      this._clampCamera();
      this.setDirty();
      // second draw after layout (mobile WebView sometimes 0-size on first paint)
      setTimeout(() => {
        this._resize();
        this._clampCamera();
        this.setDirty();
      }, 50);

      // Background: build 50m mesh after first frames (does not block enter-game)
      const pendingMed = this._pendingMedTopo;
      this._pendingMedTopo = null;
      if (pendingMed) {
        const buildMed = () => {
          try {
            report(0.96, 'بناء تفاصيل الدول…');
            this.lod.med = this._build(pendingMed);
            if (this.hideSmallIslands) {
              for (let i = 0; i < this.lod.med.length; i++) {
                const c = this.lod.med[i];
                if (c && c.applyIslandFilter) c.applyIslandFilter(true);
              }
            }
            this._collectCacheKey = '';
            this.setDirty();
            report(1, 'جاهز');
            console.log('[Map] 50m mesh ready:', this.lod.med.length);
          } catch (e) {
            console.warn('[Map] med build failed', e);
            report(1, 'جاهز');
          }
        };
        if (typeof requestIdleCallback === 'function') {
          requestIdleCallback(buildMed, { timeout: 1200 });
        } else {
          setTimeout(buildMed, 180);
        }
      } else {
        report(1, 'جاهز');
      }
      return this;
    }

    /**
     * Political layer: ownership, land adjacency, sea helpers.
     * Default owner of a region = its original country.
     */
    _initPolitics() {
      this.regionByKey = new Map();
      this.owners = new Map(); // regionKey → owner country name
      this._landAdj = new Map(); // regionKey → Set of neighbor regionKeys
      this._countryLandAdj = new Map();
      this._coastal = new Set();
      this._coastalLen = new Map(); // regionKey → total outer edge length (degrees)
      this._occupationActive = false;
      // Geometry edges for political borders
      // shared: { a:[x,y], b:[x,y], r1, r2 }
      // outer:  { a, b, r }
      this._sharedEdges = [];
      this._outerEdges = [];
      this._landAdjStrict = new Map(); // shared-edge only (no proximity)
      // Built paths: thin region borders / thick country borders per owner
      this._regionBorderPath = null; // Path2D all same-owner internal borders
      this._countryBorderPaths = new Map(); // owner → Path2D
      this._allCountryBorderPath = null; // all different-owner edges + outers

      for (const r of this.regions) {
        this.regionByKey.set(r.key, r);
        this.owners.set(r.key, this.resolveCountryName(r.country) || r.country);
        this._landAdj.set(r.key, new Set());
      }

      const edgeToRegions = new Map();
      const edgePts = new Map();
      // Coarser snap → neighboring region borders fuse into shared edges (fewer fake inland "coasts")
      const quant = (n) => Math.round(n * 64) / 64;

      const addSeg = (rKey, p0, p1) => {
        const ax = quant(p0[0]), ay = quant(p0[1]), bx = quant(p1[0]), by = quant(p1[1]);
        if (ax === bx && ay === by) return;
        const key = (ax < bx || (ax === bx && ay < by))
          ? ax + ',' + ay + '|' + bx + ',' + by
          : bx + ',' + by + '|' + ax + ',' + ay;
        if (!edgeToRegions.has(key)) {
          edgeToRegions.set(key, new Set());
          edgePts.set(key, [
            ax < bx || (ax === bx && ay < by) ? [ax, ay] : [bx, by],
            ax < bx || (ax === bx && ay < by) ? [bx, by] : [ax, ay]
          ]);
        }
        edgeToRegions.get(key).add(rKey);
      };

      for (const r of this.regions) {
        if (r.rings && r.rings.length) {
          for (const ring of r.rings) {
            for (let i = 0; i < ring.length - 1; i++) addSeg(r.key, ring[i], ring[i + 1]);
          }
        }
        if (r.lines && r.lines.length) {
          for (const line of r.lines) {
            for (let i = 0; i < line.length - 1; i++) addSeg(r.key, line[i], line[i + 1]);
          }
        }
      }

      for (const [ek, regs] of edgeToRegions) {
        const pts = edgePts.get(ek);
        const arr = [...regs];
        if (arr.length >= 2) {
          for (let i = 0; i < arr.length; i++) {
            for (let j = i + 1; j < arr.length; j++) {
              this._landAdj.get(arr[i]).add(arr[j]);
              this._landAdj.get(arr[j]).add(arr[i]);
              this._sharedEdges.push({ a: pts[0], b: pts[1], r1: arr[i], r2: arr[j] });
            }
          }
        } else if (arr.length === 1) {
          const a = pts[0], b = pts[1];
          // ignore pure antimeridian seam edges
          const nearAnti = (Math.abs(Math.abs(a[0]) - 180) < 0.8 && Math.abs(Math.abs(b[0]) - 180) < 0.8);
          const segLen = Math.hypot(b[0] - a[0], b[1] - a[1]);
          if (!nearAnti && segLen > 0.0005) {
            this._coastalLen.set(arr[0], (this._coastalLen.get(arr[0]) || 0) + segLen);
            this._outerEdges.push({ a: a, b: b, r: arr[0] });
          }
        }
      }

      // Coastal = has meaningful outer edge length (filters topology gaps)
      const COAST_MIN = 0.35; // degrees of outer boundary
      this._coastal = new Set();
      for (const [k, len] of this._coastalLen) {
        if (len >= COAST_MIN) this._coastal.add(k);
      }
      // Coast anchor = midpoint of outer edges, nudged seaward from region center
      this._coastAnchor = new Map();
      const edgesByR = new Map();
      for (const e of (this._outerEdges || [])) {
        if (!edgesByR.has(e.r)) edgesByR.set(e.r, []);
        edgesByR.get(e.r).push(e);
      }
      const rByKey = new Map((this.regions || []).map(function (r) { return [String(r.key), r]; }));
      for (const [rk, edges] of edgesByR) {
        let sx = 0, sy = 0, n = 0;
        for (const e of edges) {
          sx += (e.a[0] + e.b[0]) * 0.5;
          sy += (e.a[1] + e.b[1]) * 0.5;
          n++;
        }
        if (n <= 0) continue;
        let x = sx / n, y = sy / n;
        const r = rByKey.get(String(rk));
        if (r) {
          let dx = x - r.cx, dy = y - r.cy;
          const len = Math.hypot(dx, dy) || 1;
          // push slightly into the sea (outside the landmass)
          x += (dx / len) * 0.55;
          y += (dy / len) * 0.55;
        }
        this._coastAnchor.set(String(rk), { x: x, y: y });
      }
      console.log('[Map] Coastal regions:', this._coastal.size, '/', this.regions.length);

      // Snapshot strict adjacency BEFORE proximity expansion
      this._landAdjStrict = new Map();
      for (const [k, set] of this._landAdj) {
        this._landAdjStrict.set(k, new Set(set));
      }

      // Once: link nearly-touching regions (West Bank gaps etc.) — never O(n) per query later
      this._finalizeLandAdjProximity();
      this._rebuildCountryAdjacency();
      this._rebuildPoliticalGeometry();
      // Dissolve same-country internal region edges once (O(edges), during load)
      this._precomputeNaturalExteriors();
    }

    /**
     * Spatial pass once at load: bbox-near regions become land-adjacent.
     * Makes getRegionLandNeighbors O(degree) forever (no full scan).
     */
    _finalizeLandAdjProximity() {
      const regs = this.regions || [];
      const n = regs.length;
      if (!n) return;
      const cell = 3;
      const grid = new Map();
      for (let i = 0; i < n; i++) {
        const r = regs[i];
        if (!r || !r.bbox) continue;
        const cx = Math.floor((r.cx != null ? r.cx : (r.bbox.minX + r.bbox.maxX) * 0.5) / cell);
        const cy = Math.floor(((r.bbox.minY + r.bbox.maxY) * 0.5) / cell);
        const k = cx + ',' + cy;
        if (!grid.has(k)) grid.set(k, []);
        grid.get(k).push(i);
      }
      const PAD = 0.3;
      let added = 0;
      for (let i = 0; i < n; i++) {
        const r = regs[i];
        if (!r || !r.bbox) continue;
        const cx = Math.floor((r.cx != null ? r.cx : (r.bbox.minX + r.bbox.maxX) * 0.5) / cell);
        const cy = Math.floor(((r.bbox.minY + r.bbox.maxY) * 0.5) / cell);
        const a = r.bbox;
        for (let dx = -1; dx <= 1; dx++) {
          for (let dy = -1; dy <= 1; dy++) {
            const bucket = grid.get((cx + dx) + ',' + (cy + dy));
            if (!bucket) continue;
            for (let bi = 0; bi < bucket.length; bi++) {
              const j = bucket[bi];
              if (j <= i) continue;
              const r2 = regs[j];
              if (!r2 || !r2.bbox) continue;
              const b = r2.bbox;
              if (a.maxX + PAD < b.minX || b.maxX + PAD < a.minX ||
                  a.maxY + PAD < b.minY || b.maxY + PAD < a.minY) continue;
              const ka = String(r.key), kb = String(r2.key);
              if (!this._landAdj.has(ka)) this._landAdj.set(ka, new Set());
              if (!this._landAdj.has(kb)) this._landAdj.set(kb, new Set());
              if (!this._landAdj.get(ka).has(kb)) {
                this._landAdj.get(ka).add(kb);
                this._landAdj.get(kb).add(ka);
                added++;
              }
            }
          }
        }
      }
      console.log('[Map] Proximity land links added:', added);
    }

    /**
     * Rebuild political border paths from current ownership.
     * - Same-owner shared edge → thin region border
     * - Different-owner shared edge → thick country border
     * - Outer/coast edge → thick country border for that owner
     * Annexation expands actor borders and shrinks target borders automatically.
     */
    /**
     * Owner exterior = region border segments (lines) that appear for that owner
     * in exactly ONE region. Segments shared by two owned regions cancel (internal).
     * Uses lines only (regions are dissolved border polylines, not full polygons).
     * No coastal heuristics — those caused either gaps or fake internals.
     */

    /**
     * Load-time dissolve: O(E) edge walk.
     * Same-country shared edge → internal (hidden when far / LOD3 exterior-only).
     * Coast or different-country edge → country exterior.
     */
    _precomputeNaturalExteriors() {
      const byCountry = new Map();
      const regionSegs = new Map();
      const pathOf = (map, k) => {
        if (!map.has(k)) map.set(k, new Path2D());
        return map.get(k);
      };
      const addSeg = (path, a, b) => {
        path.moveTo(a[0], a[1]);
        path.lineTo(b[0], b[1]);
      };
      const pushRegion = (rk, a, b) => {
        const k = String(rk);
        if (!regionSegs.has(k)) regionSegs.set(k, []);
        regionSegs.get(k).push(a, b);
      };
      const countryOf = (rk) => {
        const r = this.regionByKey && this.regionByKey.get(String(rk));
        return r ? r.country : null;
      };

      const outer = this._outerEdges || [];
      for (let i = 0; i < outer.length; i++) {
        const e = outer[i];
        if (!e) continue;
        const c = countryOf(e.r);
        if (!c) continue;
        addSeg(pathOf(byCountry, c), e.a, e.b);
        pushRegion(e.r, e.a, e.b);
      }

      const shared = this._sharedEdges || [];
      for (let i = 0; i < shared.length; i++) {
        const e = shared[i];
        if (!e) continue;
        const c1 = countryOf(e.r1);
        const c2 = countryOf(e.r2);
        if (c1 && c2 && c1 === c2) continue; // internal same country
        if (c1) {
          addSeg(pathOf(byCountry, c1), e.a, e.b);
          pushRegion(e.r1, e.a, e.b);
        }
        if (c2) {
          addSeg(pathOf(byCountry, c2), e.a, e.b);
          pushRegion(e.r2, e.a, e.b);
        }
      }

      this._naturalExteriorByCountry = byCountry;
      let nR = 0;
      for (const [rk, segs] of regionSegs) {
        const r = this.regionByKey.get(rk);
        if (!r) continue;
        const path = new Path2D();
        for (let i = 0; i + 1 < segs.length; i += 2) {
          path.moveTo(segs[i][0], segs[i][1]);
          path.lineTo(segs[i + 1][0], segs[i + 1][1]);
        }
        r.exteriorPath = path;
        nR++;
      }
      console.log('[Map] Natural exteriors: countries=', byCountry.size, 'regionsWithExterior=', nR);
    }

    /**
     * FAST ownership borders from precomputed topology (_outerEdges / _sharedEdges).
     * O(edges) — never pairwise segment matching (that froze the game).
     * Exterior = coast of owned regions + borders with different owner.
     * Internal = shared edge where both sides same owner.
     * Hidden small islands: no stroke emission.
     */
    _rebuildPoliticalGeometry() {
      const byOwner = new Map();
      const internalByOwner = new Map();
      const allCountry = new Path2D();
      const regionPath = new Path2D();
      // Edge counts as country exterior only if that interface (coast or other
      // country) is ≥ 30% of the region's total border length — kills tiny touches.
      const MIN_IFACE = 0.30;
      // Fresh perimeter cache each rebuild (ownership does not change lines, but safe)
      if (this.regions) {
        for (let ri = 0; ri < this.regions.length; ri++) {
          const rr = this.regions[ri];
          if (rr) rr._perimCache = null;
        }
      }

      const ownerPath = (owner) => {
        if (owner == null || owner === '') return null;
        if (!byOwner.has(owner)) byOwner.set(owner, new Path2D());
        return byOwner.get(owner);
      };
      const isHidden = (key) => {
        const r = this.regionByKey && this.regionByKey.get(String(key));
        return !!(r && r._hiddenSmallIsland);
      };
      const areaOf = (key) => {
        const r = this.regionByKey && this.regionByKey.get(String(key));
        if (!r) return 1;
        if (r.area != null) return r.area;
        if (r.bbox) return Math.max(0.01, (r.bbox.maxX - r.bbox.minX) * (r.bbox.maxY - r.bbox.minY));
        return 1;
      };
      const segLen = (a, b) => {
        if (!a || !b) return 0;
        const dx = b[0] - a[0], dy = b[1] - a[1];
        return Math.sqrt(dx * dx + dy * dy);
      };
      const polyLen = (pts) => {
        if (!pts || pts.length < 2) return 0;
        let L = 0;
        for (let i = 1; i < pts.length; i++) L += segLen(pts[i - 1], pts[i]);
        return L;
      };
      /** Accurate region perimeter from full border polylines (all vertices). */
      const regionPerimeter = (key) => {
        const r = this.regionByKey && this.regionByKey.get(String(key));
        if (!r) return 0;
        if (r._perimCache != null && r._perimCache >= 0) return r._perimCache;
        let L = 0;
        if (r.lines && r.lines.length) {
          for (let i = 0; i < r.lines.length; i++) L += polyLen(r.lines[i]);
        }
        if (L < 1e-12 && r.bbox) {
          const w = r.bbox.maxX - r.bbox.minX, h = r.bbox.maxY - r.bbox.minY;
          L = 2 * (Math.abs(w) + Math.abs(h));
        }
        r._perimCache = L;
        return L;
      };
      const add = (map, k, L) => { map.set(k, (map.get(k) || 0) + L); };

      const outer = this._outerEdges || [];
      const shared = this._sharedEdges || [];

      // Pass 1 — interface lengths (topology edges) + full perimeters (polylines)
      const coastLen = new Map();
      const ifaceLen = new Map();
      const topoTotal = new Map(); // all topology edge length touching region

      for (let i = 0; i < outer.length; i++) {
        const e = outer[i];
        if (!e || isHidden(e.r)) continue;
        const k = String(e.r);
        const L = segLen(e.a, e.b);
        if (L < 1e-12) continue;
        add(coastLen, k, L);
        add(topoTotal, k, L);
      }
      for (let i = 0; i < shared.length; i++) {
        const e = shared[i];
        if (!e) continue;
        const k1 = String(e.r1), k2 = String(e.r2);
        const h1 = isHidden(k1), h2 = isHidden(k2);
        const L = segLen(e.a, e.b);
        if (L < 1e-12) continue;
        if (!h1) add(topoTotal, k1, L);
        if (!h2) add(topoTotal, k2, L);
        let o1 = this.owners.get(k1);
        let o2 = this.owners.get(k2);
        if (this.resolveCountryName) {
          if (o1) o1 = this.resolveCountryName(o1) || o1;
          if (o2) o2 = this.resolveCountryName(o2) || o2;
        }
        if (o1 == null || o2 == null || o1 === o2) continue;
        if (!h1) {
          if (!ifaceLen.has(k1)) ifaceLen.set(k1, new Map());
          add(ifaceLen.get(k1), o2, L);
        }
        if (!h2) {
          if (!ifaceLen.has(k2)) ifaceLen.set(k2, new Map());
          add(ifaceLen.get(k2), o1, L);
        }
      }

      /**
       * Interface counts as country border only if its length is ≥ 30% of the
       * LONGEST side on that region (longest among: coast, each other-country
       * contact). Tiny corner touches fail; major frontiers pass.
       */
      const longestSide = new Map(); // regionKey → max interface length
      for (const [k, L] of coastLen) {
        longestSide.set(k, Math.max(longestSide.get(k) || 0, L));
      }
      for (const [k, m] of ifaceLen) {
        let best = longestSide.get(k) || 0;
        for (const L of m.values()) if (L > best) best = L;
        longestSide.set(k, best);
      }

      const ifaceOk = (regionKey, otherOwnerOrCoast) => {
        const k = String(regionKey);
        const longest = longestSide.get(k) || 0;
        if (longest < 1e-12) return false;
        let L = 0;
        if (otherOwnerOrCoast === '__coast__') L = coastLen.get(k) || 0;
        else {
          const m = ifaceLen.get(k);
          L = m ? (m.get(otherOwnerOrCoast) || 0) : 0;
        }
        if (L < 1e-12) return false;
        return (L / longest) >= MIN_IFACE;
      };

      // Normalize owner labels so "France" aliases never create fake international borders
      const norm = (o) => {
        if (o == null || o === '') return null;
        return (this.resolveCountryName && this.resolveCountryName(o)) || o;
      };

      // Outer edge is often a topology gap between same-owner regions (not real coast).
      // Skip if midpoint sits in a same-owner neighbor's bbox, or region is not coastal.
      const isFalseOuter = (e, owner) => {
        const k = String(e.r);
        if (this._coastal && !this._coastal.has(k)) return true; // non-coastal → not real shore
        const midX = (e.a[0] + e.b[0]) * 0.5;
        const midY = (e.a[1] + e.b[1]) * 0.5;
        const neigh = this._landAdj && this._landAdj.get(k);
        if (!neigh) return false;
        const pad = 0.2;
        for (const nk of neigh) {
          if (norm(this.owners.get(String(nk))) !== owner) continue;
          const r2 = this.regionByKey.get(String(nk));
          if (!r2 || !r2.bbox) continue;
          const b = r2.bbox;
          if (midX >= b.minX - pad && midX <= b.maxX + pad &&
              midY >= b.minY - pad && midY <= b.maxY + pad) {
            return true;
          }
        }
        return false;
      };

      // Pass 2: emit only significant true exteriors
      for (let i = 0; i < outer.length; i++) {
        const e = outer[i];
        if (!e || isHidden(e.r)) continue;
        const owner = norm(this.owners.get(String(e.r)));
        if (owner == null) continue;
        if (isFalseOuter(e, owner)) continue;
        if (!ifaceOk(e.r, '__coast__')) continue;
        const path = ownerPath(owner);
        if (!path) continue;
        path.moveTo(e.a[0], e.a[1]);
        path.lineTo(e.b[0], e.b[1]);
        allCountry.moveTo(e.a[0], e.a[1]);
        allCountry.lineTo(e.b[0], e.b[1]);
      }

      for (let i = 0; i < shared.length; i++) {
        const e = shared[i];
        if (!e) continue;
        const h1 = isHidden(e.r1), h2 = isHidden(e.r2);
        if (h1 && h2) continue;
        const o1 = norm(this.owners.get(String(e.r1)));
        const o2 = norm(this.owners.get(String(e.r2)));
        if (o1 == null && o2 == null) continue;

        if (o1 != null && o1 === o2) {
          // Same owner → always internal (never country border)
          if (!h1 || !h2) {
            if (!internalByOwner.has(o1)) internalByOwner.set(o1, []);
            internalByOwner.get(o1).push({
              a: e.a, b: e.b,
              area: Math.min(areaOf(e.r1), areaOf(e.r2))
            });
            regionPath.moveTo(e.a[0], e.a[1]);
            regionPath.lineTo(e.b[0], e.b[1]);
          }
        } else {
          if (o1 != null && !h1 && o2 != null && ifaceOk(e.r1, o2)) {
            const path = ownerPath(o1);
            if (path) {
              path.moveTo(e.a[0], e.a[1]);
              path.lineTo(e.b[0], e.b[1]);
            }
            allCountry.moveTo(e.a[0], e.a[1]);
            allCountry.lineTo(e.b[0], e.b[1]);
          }
          if (o2 != null && !h2 && o1 != null && ifaceOk(e.r2, o1)) {
            const path = ownerPath(o2);
            if (path) {
              path.moveTo(e.a[0], e.a[1]);
              path.lineTo(e.b[0], e.b[1]);
            }
          }
        }
      }

      // Largest internal segments first → progressive LOD reveals big provinces first
      for (const [owner, segs] of internalByOwner) {
        segs.sort((a, b) => (b.area || 0) - (a.area || 0));
        internalByOwner.set(owner, segs);
      }

      this._regionBorderPath = regionPath;
      this._countryBorderPaths = byOwner;
      this._allCountryBorderPath = allCountry;
      this._internalBordersByOwner = internalByOwner;
      this._regionCenters = this._regionCenters || new Map();

      // Countries that gained/lost land — used for sparse political overlay at LOD1–2
      const dirty = new Set();
      if (this.regions && this.owners) {
        for (let i = 0; i < this.regions.length; i++) {
          const r = this.regions[i];
          if (!r) continue;
          const o = this.owners.get(r.key);
          if (o != null && o !== r.country) {
            dirty.add(o);
            dirty.add(r.country);
          }
        }
      }
      this._dirtyOwners = dirty;
    }

    _rebuildCountryAdjacency() {
      this._countryLandAdj = new Map();
      this._countryToRegions = new Map(); // owner → regionKey[]
      const ensure = (c) => {
        if (!this._countryLandAdj.has(c)) this._countryLandAdj.set(c, new Set());
      };
      for (const [key, ownerA] of this.owners) {
        if (!this._countryToRegions.has(ownerA)) this._countryToRegions.set(ownerA, []);
        this._countryToRegions.get(ownerA).push(key);
        ensure(ownerA);
        const neigh = this._landAdj.get(key);
        if (!neigh) continue;
        for (const n of neigh) {
          const ownerB = this.owners.get(n);
          if (ownerA !== ownerB) {
            ensure(ownerB);
            this._countryLandAdj.get(ownerA).add(ownerB);
            this._countryLandAdj.get(ownerB).add(ownerA);
          }
        }
      }
    }

    _haversineKm(lon1, lat1, lon2, lat2) {
      const R = 6371;
      const toR = Math.PI / 180;
      const dLat = (lat2 - lat1) * toR;
      const dLon = (lon2 - lon1) * toR;
      const a = Math.sin(dLat / 2) ** 2 +
        Math.cos(lat1 * toR) * Math.cos(lat2 * toR) * Math.sin(dLon / 2) ** 2;
      return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
    }

    _regionCentroid(r) {
      return { lon: r.cx, lat: (r.bbox.minY + r.bbox.maxY) * 0.5 };
    }

    /** Sample points on region boundary for sea distance */
    _boundarySamples(r, maxPts = 24) {
      const pts = [];
      const rings = r.rings || [];
      for (const ring of rings) {
        const step = Math.max(1, Math.floor(ring.length / Math.max(1, Math.floor(maxPts / Math.max(1, rings.length)))));
        for (let i = 0; i < ring.length; i += step) pts.push(ring[i]);
      }
      if (!pts.length) pts.push([r.cx, (r.bbox.minY + r.bbox.maxY) * 0.5]);
      return pts;
    }

    _minBoundaryDistanceKm(rA, rB) {
      const a = this._boundarySamples(rA);
      const b = this._boundarySamples(rB);
      let min = Infinity;
      for (let i = 0; i < a.length; i++) {
        for (let j = 0; j < b.length; j++) {
          const d = this._haversineKm(a[i][0], a[i][1], b[j][0], b[j][1]);
          if (d < min) min = d;
        }
      }
      return min;
    }

    /**
     * Regions are stored as dissolved border polylines (NOT province polygons).
     * Internal province edges were removed during build.
     */
    _buildRegions(arr) {
      const list = [];
      for (const r of arr) {
        if (!r.lines || !r.lines.length) continue;
        // project lon/lat → mercator
        const lines = (r.lines || []).map(projectRing);
        const rings = (r.rings || []).map(projectRing);
        const path = new Path2D();
        for (const line of lines) {
          if (!line || line.length < 2) continue;
          path.moveTo(line[0][0], line[0][1]);
          for (let i = 1; i < line.length; i++) path.lineTo(line[i][0], line[i][1]);
        }
        const fillPath = new Path2D();
        for (const ring of rings) {
          if (!ring || ring.length < 3) continue;
          fillPath.moveTo(ring[0][0], ring[0][1]);
          for (let i = 1; i < ring.length; i++) fillPath.lineTo(ring[i][0], ring[i][1]);
          fillPath.closePath();
        }
        // bbox from projected lines
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (const line of lines) {
          for (const p of line) {
            if (p[0] < minX) minX = p[0];
            if (p[0] > maxX) maxX = p[0];
            if (p[1] < minY) minY = p[1];
            if (p[1] > maxY) maxY = p[1];
          }
        }
        if (!isFinite(minX)) { minX = -180; maxX = 180; minY = -180; maxY = 180; }
        const cy = (minY + maxY) * 0.5;
        const latApprox = invMercY(cy);
        const id = r.id | 0;
        let lonApprox = (minX + maxX) * 0.5;
        lonApprox = ((lonApprox + 180) % 360 + 360) % 360 - 180;
        const biome = (typeof Terrain !== 'undefined' && Terrain.biomeAt)
          ? Terrain.biomeAt(latApprox, id, lonApprox)
          : 'forest';
        const area = Math.max(0.0001, (maxX - minX) * (maxY - minY));
        let countryName = r.country || '';
        if (this.countryMerge && this.countryMerge.has(countryName)) {
          countryName = this.countryMerge.get(countryName);
        }
        list.push({
          id: r.id,
          key: r.key != null ? String(r.key) : String(r.id),
          name: r.displayName || r.name || 'Region',
          country: countryName,
          provinces: r.provinces || 1,
          path,
          fillPath,
          rings,
          lines,
          area,
          biome,
          bbox: { minX, minY, maxX, maxY },
          cx: (minX + maxX) * 0.5,
          cy
        });
      }
      return this._mergeTinyRegions(list);
    }

    /**
     * Merge very small regions into nearest same-country neighbor so they are tappable.
     * Threshold ~0.55 deg² (West Bank-scale and smaller).
     */
    _mergeTinyRegions(list) {
      if (!list || list.length < 2) return list || [];
      const MIN_AREA = 0.85; // merge West Bank-scale and smaller into neighbor
      const byCountry = new Map();
      for (let i = 0; i < list.length; i++) {
        const r = list[i];
        const c = r.country || '';
        if (!byCountry.has(c)) byCountry.set(c, []);
        byCountry.get(c).push(r);
      }
      const drop = new Set();
      for (const [, regs] of byCountry) {
        if (regs.length < 2) continue;
        for (let i = 0; i < regs.length; i++) {
          const tiny = regs[i];
          if (tiny.area >= MIN_AREA) continue;
          // nearest larger same-country region
          let best = null, bestD = Infinity;
          for (let j = 0; j < regs.length; j++) {
            if (i === j) continue;
            const o = regs[j];
            if (drop.has(o.key)) continue;
            if (o.area < MIN_AREA * 0.9) continue;
            const d = (tiny.cx - o.cx) * (tiny.cx - o.cx) + (tiny.cy - o.cy) * (tiny.cy - o.cy);
            if (d < bestD) { bestD = d; best = o; }
          }
          if (!best) {
            // absorb into any neighbor same country
            for (let j = 0; j < regs.length; j++) {
              if (i === j || drop.has(regs[j].key)) continue;
              best = regs[j]; break;
            }
          }
          if (!best) continue;
          // merge geometry into best
          if (tiny.lines && tiny.lines.length) {
            best.lines = (best.lines || []).concat(tiny.lines);
          }
          if (tiny.rings && tiny.rings.length) {
            best.rings = (best.rings || []).concat(tiny.rings);
          }
          best.provinces = (best.provinces || 1) + (tiny.provinces || 1);
          best.area = (best.area || 0) + (tiny.area || 0);
          best.bbox = {
            minX: Math.min(best.bbox.minX, tiny.bbox.minX),
            minY: Math.min(best.bbox.minY, tiny.bbox.minY),
            maxX: Math.max(best.bbox.maxX, tiny.bbox.maxX),
            maxY: Math.max(best.bbox.maxY, tiny.bbox.maxY)
          };
          best.cx = (best.bbox.minX + best.bbox.maxX) * 0.5;
          best.cy = (best.bbox.minY + best.bbox.maxY) * 0.5;
          // rebuild path
          const path = new Path2D();
          for (const line of (best.lines || [])) {
            if (!line || line.length < 2) continue;
            path.moveTo(line[0][0], line[0][1]);
            for (let k = 1; k < line.length; k++) path.lineTo(line[k][0], line[k][1]);
          }
          best.path = path;
          drop.add(tiny.key);
        }
      }
      if (!drop.size) return list;
      const out = list.filter(function (r) { return !drop.has(r.key); });
      console.log('[Map] Merged tiny regions:', drop.size, '→', out.length, 'regions');
      return out;
    }

    _build(topology) {
      const fc = topojson.feature(topology, topology.objects.countries);
      const byName = new Map();
      const list = [];

      // First pass – collect
      for (const f of fc.features) {
        const id = f.id != null ? f.id : list.length;
        let name = (f.properties && f.properties.name) || String(id);

        // Political choice + micro-state merge + NE aliases → canonical name
        name = this.resolveCountryName(name) || name;

        // If target already collected, merge geometry into it
        if (byName.has(name)) {
          const existing = byName.get(name);
          const addLL = fixGeometry(f.geometry);
          existing._lonLatGeom = this._mergeGeom(existing._lonLatGeom || existing.geometry, addLL);
          existing.maxIslandKm2 = maxComponentKm2(existing._lonLatGeom);
          existing.geometry = projectGeom(existing._lonLatGeom);
          existing.bbox = bboxOf(existing.geometry);
          existing.path = toPath(existing.geometry);
          existing.pathSimple = toPath(simplifyProjectedGeom(existing.geometry, 0.42));
          existing.pathMid = toPath(simplifyProjectedGeom(existing.geometry, 0.30));
          existing.cy = (existing.bbox.minY + existing.bbox.maxY) * 0.5;
          existing.cx = (existing.bbox.minX + existing.bbox.maxX) * 0.5;
          continue;
        }

        const c = new Country(id, name, f.geometry);
        list.push(c);
        byName.set(name, c);
      }
      // Keep all countries. Small-island draw filter is optional (setting) and
      // never deletes a nation's largest landmass (see filterSmallIslandsGeom).
      return list;
    }

    _mergeGeom(a, b) {
      // Turn both into MultiPolygon coordinates and concat
      function toMulti(g) {
        if (g.type === 'Polygon') return [g.coordinates];
        if (g.type === 'MultiPolygon') return g.coordinates;
        return [];
      }
      return {
        type: 'MultiPolygon',
        coordinates: toMulti(a).concat(toMulti(b))
      };
    }

    // ───────── view ─────────
    _fit() {
      const cssW = this.canvas.clientWidth || 1;
      const cssH = this.canvas.clientHeight || 1;
      return Math.min(cssW / CFG.WORLD_W, cssH / CFG.WORLD_H);
    }
    get viewW() {
      const cssW = this.canvas.clientWidth || 1;
      return cssW / (this._fit() * this.zoom);
    }
    get viewH() {
      const cssH = this.canvas.clientHeight || 1;
      return cssH / (this._fit() * this.zoom);
    }

    _collect() {
      // 5-tier LOD
      let tier = 1;
      if (this.zoom >= CFG.LOD5) tier = 5;
      else if (this.zoom >= CFG.LOD4) tier = 4;
      else if (this.zoom >= CFG.LOD3) tier = 3;
      else if (this.zoom >= CFG.LOD2) tier = 2;
      else if (this.zoom >= CFG.LOD1) tier = 1;
      else tier = 1;
      this._lodTier = tier;
      // 50m mesh only at LOD5 (full detail). LOD3–4 stay on simplified 110m.
      let key = (tier >= 5 && this.lod.med && this.lod.med.length &&
        (!this.perf || this.perf.useMedMesh !== false)) ? 'med' : 'low';
      let src = this.lod[key];
      if (!src || !src.length) {
        key = 'low';
        src = this.lod.low || [];
      }
      this._currentLod = key;

      const hw = this.viewW * 0.5 + 3;
      const hh = this.viewH * 0.5 + 3;
      const minLon = this.camLon - hw;
      const maxLon = this.camLon + hw;
      const minY = this.camLat - hh;
      const maxY = this.camLat + hh;

      const out = [];
      for (let i = 0; i < src.length; i++) {
        const c = src[i];
        const b = c.bbox;
        // at tier 0 skip very small countries for speed
        if (tier === 0) {
          const a = (b.maxX - b.minX) * (b.maxY - b.minY);
          if (a < 2.5) continue;
        }
        // Prefer offset 0. Only ±360 when the view wraps past the date line
        // and the feature is not already visible at 0 (camera wraps; no second world).
        const offs = this.zoom < 3.5 ? [0, -360, 360] : [0];
        let chosen = null;
        for (const off of offs) {
          const x0 = b.minX + off;
          const x1 = b.maxX + off;
          if (x1 >= minLon && x0 <= maxLon &&
              b.maxY >= minY && b.minY <= maxY) {
            chosen = off;
            break;
          }
        }
        if (chosen !== null) out.push({ c, off: chosen });
      }
      // Cap when zoomed in. World view keeps all. LOD3–4 tighter; LOD5 can show more.
      const maxCBase = (this.perf && this.perf.maxCountries) || 220;
      let maxC;
      if (this.zoom < 2.8) maxC = 10000;
      else if (tier >= 5) maxC = Math.min(maxCBase, 200);
      else if (tier >= 4) maxC = Math.min(maxCBase, 160);
      else if (tier >= 3) maxC = Math.min(maxCBase, 180);
      else if (this.zoom < 4.5) maxC = Math.max(maxCBase, 280);
      else maxC = maxCBase;
      if (out.length > maxC) {
        const cx = this.camLon, cy = this.camLat;
        out.sort((a, b) => {
          const ba = a.c.bbox, bb = b.c.bbox;
          const aa = Math.max(0.01, (ba.maxX - ba.minX) * (ba.maxY - ba.minY));
          const ab = Math.max(0.01, (bb.maxX - bb.minX) * (bb.maxY - bb.minY));
          // Always keep bigger landmasses; only then prefer closer to camera
          if (ab !== aa) return ab - aa;
          const acx = (ba.minX + ba.maxX) * 0.5 + a.off;
          const acy = (ba.minY + ba.maxY) * 0.5;
          const bcx = (bb.minX + bb.maxX) * 0.5 + b.off;
          const bcy = (bb.minY + bb.maxY) * 0.5;
          const da = (acx - cx) * (acx - cx) + (acy - cy) * (acy - cy);
          const db = (bcx - cx) * (bcx - cx) + (bcy - cy) * (bcy - cy);
          return da - db;
        });
        out = out.slice(0, maxC);
      }
      this.visible = out;

      // Regions: LOD3 huge only → LOD4 medium → LOD5 all (viewport-culled + capped)
      this.visibleRegions = [];
      // LOD3: top 25 · LOD4: top 125 · LOD5+: rest — borders never before LOD3
      if (tier >= 3 && this.regions.length) {
        const pool = this._regionsByArea && this._regionsByArea.length
          ? this._regionsByArea
          : this.regions;
        let maxRegions;
        if (tier >= 5) maxRegions = pool.length;
        else if (tier >= 4) maxRegions = 125;
        else maxRegions = 25; // LOD3 only largest
        let taken = 0;
        for (let i = 0; i < pool.length; i++) {
          if (taken >= maxRegions) break;
          const r = pool[i];
          if (!r) continue;
          if (this.hideSmallIslands && (r._hiddenSmallIsland || this.isRegionSmallIsland(r.key))) {
            r._hiddenSmallIsland = true;
            continue;
          }
          const b = r.bbox;
          if (!b) continue;
          if (b.maxX < minLon || b.minX > maxLon || b.maxY < minY || b.minY > maxY) continue;
          this.visibleRegions.push({ c: r, off: 0 });
          taken++;
        }
      }
    }

    /** Minimum zoom: exact fit of full world (E–W and N–S) — no overscan, no under-fill */
    _minZoom() {
      const cssW = this.canvas.clientWidth || 1;
      const cssH = this.canvas.clientHeight || 1;
      const fit = Math.min(cssW / CFG.WORLD_W, cssH / CFG.WORLD_H) || 1;
      // Exact cover: view matches world on the tighter axis, other axis flush (no gaps, no extra zoom)
      const zFitH = cssH / (fit * CFG.WORLD_H);
      const zFitW = cssW / (fit * CFG.WORLD_W);
      return Math.max(CFG.MIN_ZOOM, zFitH, zFitW);
    }

    /** Clamp camera so the view never leaves the map vertically */
    _clampCamera() {
      // Recover from NaN / Infinity (pinch glitches, zero-size canvas)
      if (!Number.isFinite(this.zoom) || this.zoom <= 0) this.zoom = this._minZoom();
      if (!Number.isFinite(this.camLon)) this.camLon = 0;
      if (!Number.isFinite(this.camLat)) this.camLat = 0;

      const zMin = this._minZoom();
      const zMax = CFG.MAX_ZOOM;
      if (this.zoom < zMin) this.zoom = zMin;
      if (this.zoom > zMax) this.zoom = zMax;

      const halfH = this.viewH * 0.5;
      const maxY = CFG.WORLD_H * 0.5;
      if (!Number.isFinite(halfH) || halfH <= 0) {
        this.camLat = 0;
        return;
      }
      if (this.viewH >= CFG.WORLD_H - 0.01) {
        this.camLat = 0; // full height locked
      } else {
        this.camLat = clamp(this.camLat, -maxY + halfH, maxY - halfH);
      }
      this.camLon = ((this.camLon + 180) % 360 + 360) % 360 - 180;
      if (!Number.isFinite(this.camLon)) this.camLon = 0;
    }

    // ───────── adaptive performance ─────────
    _detectPerf() {
      let cores = 4;
      let mem = 4;
      try {
        if (navigator.hardwareConcurrency) cores = navigator.hardwareConcurrency;
        if (navigator.deviceMemory) mem = navigator.deviceMemory; // GB
      } catch (_) {}
      const dpr = Math.min(Math.min(window.devicePixelRatio || 1, (typeof window.WOK_isMobile === "function" && WOK_isMobile()) ? 1.75 : 2), 2);
      // Score: higher = stronger device
      let score = cores * 1.2 + mem * 1.5 - Math.max(0, dpr - 1) * 1.5;
      // Mobile UA soft penalty
      try {
        if (/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent || '')) score -= 2;
      } catch (_) {}
      let tier = 'med';
      if (score < 6) tier = 'low';
      else if (score >= 12) tier = 'high';
      const table = {
        // PER-1.4.2: mobile aims ~30 FPS stable (not 60)
        low:  { maxDpr: 1.0, targetFps: 24, maxCountries: 220, maxRegions: 200, maxRegionsHi: 360, useMedMesh: false, regionFill: false, sortCountries: true },
        med:  { maxDpr: 1.25, targetFps: 30, maxCountries: 280, maxRegions: 300, maxRegionsHi: 560, useMedMesh: true, regionFill: false, sortCountries: true },
        high: { maxDpr: 1.5, targetFps: 30, maxCountries: 280, maxRegions: 420, maxRegionsHi: 750, useMedMesh: true, regionFill: true, sortCountries: true }
      };
      const cfg = table[tier];
      cfg.tier = tier;
      cfg.score = score;
      cfg.cores = cores;
      cfg.mem = mem;
      // Cap canvas DPR to device budget
      this.dpr = Math.min(Math.min(window.devicePixelRatio || 1, (typeof window.WOK_isMobile === "function" && WOK_isMobile()) ? 1.75 : 2), cfg.maxDpr);
      return cfg;
    }

    _adaptPerfFromFrames() {
      if (!this._frameTimes.length) return;
      const arr = this._frameTimes;
      let sum = 0;
      for (let i = 0; i < arr.length; i++) sum += arr[i];
      const avg = sum / arr.length;
      // Slow frames → drop quality one step
      if (avg > 55 && this.perf.tier !== 'low') {
        if (this.perf.tier === 'high') {
          this.perf = Object.assign(this.perf, {
            tier: 'med', targetFps: 30, maxCountries: 260, maxRegions: 300, maxRegionsHi: 560,
            useMedMesh: true, regionFill: false, sortCountries: true, maxDpr: 1.25
          });
        } else {
          this.perf = Object.assign(this.perf, {
            tier: 'low', targetFps: 24, maxCountries: 200, maxRegions: 200, maxRegionsHi: 360,
            useMedMesh: false, regionFill: false, sortCountries: false, maxDpr: 1.0
          });
        }
        this.dpr = Math.min(Math.min(window.devicePixelRatio || 1, (typeof window.WOK_isMobile === "function" && WOK_isMobile()) ? 1.75 : 2), this.perf.maxDpr);
        this._frameTimes = [];
        this._collectCacheKey = '';
        if (this._resize) this._resize();
      } else if (avg < 22 && this.perf.tier === 'low' && this.perf.score >= 5) {
        // Recover slightly if stable
        this.perf = Object.assign(this.perf, {
          tier: 'med', targetFps: 30, maxCountries: 280, maxRegions: 300, maxRegionsHi: 560,
          useMedMesh: true, regionFill: false, sortCountries: true, maxDpr: 1.25
        });
        this.dpr = Math.min(Math.min(window.devicePixelRatio || 1, (typeof window.WOK_isMobile === "function" && WOK_isMobile()) ? 1.75 : 2), this.perf.maxDpr);
        this._frameTimes = [];
        this._collectCacheKey = '';
      }
    }

    // ───────── render ─────────
    setRenderPaused(on) {
      this.renderPaused = !!on;
      if (!this.renderPaused) this.setDirty();
    }

    setDirty() {
      this.dirty = true;
      if (this.renderPaused) return;
      if (this._raf != null) return;
      const self = this;
      // PER-1.4.2/1.4.3: pace RAF to targetFps (mobile ~30)
      const _isMob = (typeof global.WOK_isMobile === 'function' && global.WOK_isMobile());
      const _defaultFps = _isMob ? 30 : 30;
      const minGap = 1000 / Math.max(12, (this.perf && this.perf.targetFps) || _defaultFps);
      const schedule = function () {
        self._raf = requestAnimationFrame(function (ts) {
          self._raf = null;
          if (self.renderPaused) return;
          if (!self.dirty) return;
          const last = self._lastDrawAt || 0;
          if (ts - last < minGap * 0.85) {
            self._raf = requestAnimationFrame(schedule);
            return;
          }
          self._draw();
        });
      };
      schedule();
    }

    _draw() {
      if (this.renderPaused) return;
      if (!this.dirty || !this.ready) return;
      this.dirty = false;
      const t0 = performance.now();
      this._lastDrawAt = performance.now();

      const ctx = this.ctx;
      const W = this.canvas.width;
      const H = this.canvas.height;
      const cssW = this.canvas.clientWidth;
      const cssH = this.canvas.clientHeight;
      if (cssW < 2 || cssH < 2) return;

      // Hard safety: never draw with broken camera (full-screen solid biome glitch)
      if (!Number.isFinite(this.zoom) || !Number.isFinite(this.camLon) || !Number.isFinite(this.camLat)) {
        this.zoom = this._minZoom();
        this.camLon = 0;
        this.camLat = 0;
        this._collectCacheKey = '';
      }
      this._clampCamera();

      // Collect only when camera/zoom/tier budget changes
      const ck = [
        this.zoom.toFixed(3),
        this.camLon.toFixed(3),
        this.camLat.toFixed(3),
        this.perf && this.perf.tier,
        this.canvas.clientWidth,
        this.canvas.clientHeight
      ].join('|');
      if (ck !== this._collectCacheKey) {
        this._collectCacheKey = ck;
        this._collect();
      }

      ctx.save();
      ctx.scale(this.dpr, this.dpr);

      // Ocean — solid color (terrain is independent, not a canvas pattern)
      ctx.fillStyle = (typeof Terrain !== 'undefined' && Terrain.oceanColor)
        ? Terrain.oceanColor()
        : CFG.BG;
      ctx.fillRect(0, 0, cssW, cssH);

      // Fit scale: zoom=1 → whole mercator world visible on landscape
      const fit = Math.min(cssW / CFG.WORLD_W, cssH / CFG.WORLD_H) || 1;
      const sx = fit * this.zoom;
      const sy = fit * this.zoom;
      if (sx < 1e-6) { ctx.restore(); return; }

      ctx.translate(cssW * 0.5, cssH * 0.5);
      ctx.scale(sx, -sy);
      ctx.translate(-this.camLon, -this.camLat);

      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';

      // screen-pixel → world units (stable borders)
      const countryLW = CFG.COUNTRY_PX / sx;
      const regionLW = CFG.REGION_PX / sx;

      const hw = this.viewW * 0.5 + 4;
      const hh = this.viewH * 0.5 + 4;
      const minLon = this.camLon - hw;
      const maxLon = this.camLon + hw;
      const minLat = this.camLat - hh;
      const maxLat = this.camLat + hh;

      // ═══════════════════════════════════════════
      // LOD tiers:
      //   1 — coarse countries (110m mesh only)
      //   2 — full countries (110m mesh only)
      //   3 — 50m countries + large regions
      //   4 — all regions + dense region borders
      // Political (ownership) borders replace mesh when occupation is active
      // or from tier 3+ so annexation geometry is accurate when zoomed.
      // ═══════════════════════════════════════════
      const showRegions = this.visibleRegions.length > 0;
      const T = (typeof Terrain !== 'undefined') ? Terrain : null;
      const tier = this._lodTier || 1;
      const occ = !!this._occupationActive;
      // Full region-edge political mesh is EXPENSIVE and looks like provinces.
      // Use it only at LOD3+ while occupation is active. LOD1–2 always mesh.

      // 1) COUNTRY FILLS — geographic mesh (never skip whole countries for island filter)
      const allowWrap = this.zoom < 2.8;
      // Borders: LOD1–2 simple · LOD3–5 pathMid (tol=0.30). Always fall back safely.
      const strokePathOf = (c) => {
        if (!c) return null;
        if (tier >= 3) return c.pathMid || c.pathSimple || c.path;
        return c.pathSimple || c.path;
      };
      for (let i = 0; i < this.visible.length; i++) {
        const { c, off } = this.visible[i];
        if (!allowWrap && off !== 0) continue;
        const st = this.countryStyles.get(c.name);
        const fillPath = (tier >= 5 ? c.path : (c.pathSimple || c.path));
        const drawOne = () => {
          if (st && st.fill) ctx.fillStyle = st.fill;
          else if (T && T.dominantColor) ctx.fillStyle = T.dominantColor(c.name) || CFG.LAND;
          else ctx.fillStyle = CFG.LAND;
          try { ctx.fill(fillPath); } catch (_) {}
        };
        if (off === 0) drawOne();
        else {
          ctx.save();
          ctx.translate(off, 0);
          drawOne();
          ctx.restore();
        }
      }

      // 2) REGIONS — only from LOD3 (never far/LOD1–2)
      if (showRegions && tier >= 3) {
        for (let i = 0; i < this.visibleRegions.length; i++) {
          const { c, off } = this.visibleRegions[i];
          if (c && c._hiddenSmallIsland) continue;
          const rst = this.regionStyles.get(c.key);
          const selBorder = rst && rst.border;

          const drawOne = () => {
            if (tier >= 5 && c.fillPath && this.perf && this.perf.regionFill) {
              if (rst && rst.fill) ctx.fillStyle = rst.fill;
              else if (T && T.colorForRegionKey) ctx.fillStyle = T.colorForRegionKey(c.key);
              else ctx.fillStyle = CFG.LAND;
              try { ctx.fill(c.fillPath); } catch (_) {}
            }
            // LOD3: exterior only. LOD4+: pathMid (DETAIL from settings, not width).
            // Region border WIDTH is fixed (×2 of previous thin baseline).
            const rp = (tier <= 3)
              ? (c.exteriorPath || null)
              : (c.pathMid || c.path);
            if (rp) {
              ctx.strokeStyle = (selBorder && rst && rst.forceBorder) ? selBorder : CFG.REGION_STROKE;
              const mul = (selBorder && rst && rst.forceBorder)
                ? Math.max(2.4 * ((rst && rst.borderWidth) || 1), 1.4)
                : 1.6; // fixed ×2 of previous ~0.8 avg
              ctx.lineWidth = Math.max(regionLW * mul, countryLW * 0.2);
              ctx.globalAlpha = (selBorder && rst && rst.forceBorder) ? 0.95 : 0.55;
              try { ctx.stroke(rp); } catch (_) {}
              ctx.globalAlpha = 1;
            }
          };
          if (off === 0) drawOne();
          else {
            ctx.save();
            ctx.translate(off, 0);
            drawOne();
            ctx.restore();
          }
        }
      }

      // 3) COUNTRY BORDERS
      // LOD1–2: Natural Earth mesh only (clean). Never region-edge spiderweb.
      // LOD3+ with occupation: political exterior (ownership).
      // LOD3+ without occupation: still mesh (countries only).
      ctx.save();
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      ctx.miterLimit = 2;

      // Nature Earth style always. For dirty countries (occupation), replace the
      // original mesh path with political exterior of current ownership — same
      // stroke style, no double-draw, old shared border disappears.
      const dirty = (occ && this._dirtyOwners) ? this._dirtyOwners : null;
      const pol = (occ && this._countryBorderPaths) ? this._countryBorderPaths : null;
      const lwMul = tier >= 4 ? 1.89 : (tier >= 3 ? 1.8 : 1.89);
      const playerLW = Math.max(countryLW * 2.43, (CFG.COUNTRY_PX * 2.5) / Math.max(sx, 1e-6));

      const pathForCountry = (name, meshFeature) => {
        if (pol && dirty && dirty.has(name)) {
          const pp = pol.get(name);
          if (pp) return pp; // modified original border from ownership
          return null; // fully annexed — no border
        }
        if (meshFeature) return strokePathOf(meshFeature);
        return null;
      };

      for (let i = 0; i < this.visible.length; i++) {
        const { c, off } = this.visible[i];
        if (!allowWrap && off !== 0) continue;
        const isPlayer = this._playerBorderName && c.name === this._playerBorderName;
        if (isPlayer) continue;
        // Skip mesh of a country that lost all land (no pol path)
        const p = pathForCountry(c.name, c);
        if (!p) continue;
        const st = this.countryStyles.get(c.name);
        const stroke = (st && st.border) || CFG.STROKE;
        const lw = countryLW * ((st && st.borderWidth) ? 2.0 : lwMul);
        const strokeOne = () => {
          ctx.strokeStyle = stroke;
          ctx.lineWidth = lw;
          try { ctx.stroke(p); } catch (_) {}
        };
        if (off === 0) strokeOne();
        else {
          ctx.save();
          ctx.translate(off, 0);
          strokeOne();
          ctx.restore();
        }
      }

      // Dirty countries not in visible mesh (e.g. renamed/expanded) still need stroke
      if (pol && dirty) {
        const seen = new Set();
        for (let i = 0; i < this.visible.length; i++) {
          const c = this.visible[i] && this.visible[i].c;
          if (c && c.name) seen.add(c.name);
        }
        for (const name of dirty) {
          if (!name || name === this._playerBorderName || seen.has(name)) continue;
          const pp = pol.get(name);
          if (!pp) continue;
          const st = this.countryStyles.get(name);
          ctx.strokeStyle = (st && st.border) || CFG.STROKE;
          ctx.lineWidth = countryLW * ((st && st.borderWidth) ? 2.0 : lwMul);
          try { ctx.stroke(pp); } catch (_) {}
        }
      }

      if (this._playerBorderName) {
        const mesh = this._getCountryMesh && this._getCountryMesh(this._playerBorderName);
        const p = pathForCountry(this._playerBorderName, mesh);
        if (p) {
          ctx.strokeStyle = this._playerBorderColor || '#3db8ff';
          ctx.lineWidth = playerLW;
          try { ctx.stroke(p); } catch (_) {}
        }
      }

      // 4) INTERNAL region borders
      // LOD4: very sparse (huge provinces only). LOD5: progressive full detail.
      if (tier >= 4 && this._internalBordersByOwner) {
        // Region detail slider 15–36 absolute quality (independent of pathMid)
        const rd = this._regionBorderDetail != null ? this._regionBorderDetail : 18;
        const rDetail = Math.max(0, Math.min(1, (rd - 5) / 59)); // absolute 15..48 (48=1.5× of 32)
        let minArea, maxSeg, alpha, lwMul;
        if (tier >= 5) {
          const tprog = Math.max(0, Math.min(1, (this.zoom - CFG.LOD5) / 14));
          const dens = 0.35 + 0.65 * rDetail;
          minArea = (40 - 30 * rDetail) * (1 - tprog) * (1 - tprog) + (2.5 - 2 * rDetail) * tprog;
          maxSeg = Math.floor((40 + 160 * dens) + tprog * (120 + 400 * dens));
          alpha = 0.2 + 0.35 * dens + 0.25 * tprog;
          lwMul = 0.85; // width fixed; dens only affects segment count
        } else {
          // LOD4 reduced, still scaled by region detail
          const tprog = Math.max(0, Math.min(1, (this.zoom - CFG.LOD4) / Math.max(0.01, CFG.LOD5 - CFG.LOD4)));
          minArea = (150 - 80 * rDetail) * (1 - tprog * 0.5);
          maxSeg = Math.floor((10 + 25 * rDetail) + tprog * (20 + 40 * rDetail));
          alpha = 0.12 + 0.2 * rDetail + 0.15 * tprog;
          lwMul = 0.7; // width fixed; rDetail only affects segment count
        }
        ctx.strokeStyle = CFG.REGION_STROKE;
        ctx.lineWidth = Math.max(regionLW * lwMul * 0.75, countryLW * 0.1);
        ctx.globalAlpha = alpha;
        let drawn = 0;
        for (const [, segs] of this._internalBordersByOwner) {
          if (!segs || !segs.length) continue;
          for (let i = 0; i < segs.length && drawn < maxSeg; i++) {
            const seg = segs[i];
            if ((seg.area || 0) < minArea) continue;
            ctx.beginPath();
            ctx.moveTo(seg.a[0], seg.a[1]);
            ctx.lineTo(seg.b[0], seg.b[1]);
            ctx.stroke();
            drawn++;
          }
        }
        ctx.globalAlpha = 1;
      }
      ctx.restore();

      // Battle / highlight region borders — LOD3+ only (never far view)
      if (tier >= 3 && this.regionStyles && this.regionStyles.size && this.regionByKey) {
        const battleBase = Math.max(countryLW * 1.15, (CFG.COUNTRY_PX * 1.2) / Math.max(sx, 1e-6));
        const vminX = minLon, vmaxX = maxLon, vminY = minLat, vmaxY = maxLat;
        let nBattle = 0;
        const maxBattle = tier >= 5 ? 100 : (tier >= 4 ? 40 : (tier >= 3 ? 24 : 16));
        for (const [key, st] of this.regionStyles) {
          if (nBattle >= maxBattle) break;
          if (!st || !st.border) continue;
          const r = this.regionByKey.get(String(key));
          if (!r || !r.bbox) continue;
          const b = r.bbox;
          if (b.maxX < vminX || b.minX > vmaxX || b.maxY < vminY || b.minY > vmaxY) continue;
          const mult = Number(st.borderWidth) > 0 ? Number(st.borderWidth) : 1.5;
          ctx.strokeStyle = st.border;
          ctx.lineWidth = battleBase * mult;
          ctx.lineJoin = 'round';
          try {
            if (r.path) ctx.stroke(r.path);
            else if (r.fillPath) ctx.stroke(r.fillPath);
          } catch (_) {}
          nBattle++;
        }
      }

      // Player country outline ON TOP (world space) — always readable
      // Player mesh border handled in dedicated block above — no fallback double stroke

      // Troop lines in WORLD space (locked to region centers — never drifts with UI)
      if (this.militaryMoves && this.militaryMoves.length) {
        this._drawMilitaryMovesWorld(ctx);
      }

      ctx.restore();

      // (legacy screen overlay disabled — world-space is authoritative)
      // if (this.militaryMoves && this.militaryMoves.length) {
      //   this._drawMilitaryMovesScreen(ctx);
      // }
      // Unit icons on map disabled (performance + design)
      // if (this.zoom >= CFG.LOD4 && this.regionUnitMarkers && this.regionUnitMarkers.size) {
      //   this._drawRegionUnitMarkersScreen(ctx);
      // }

      // stats + adaptive quality
      const frameMs = performance.now() - t0;
      this._frameTimes.push(frameMs);
      if (this._frameTimes.length > 30) this._frameTimes.shift();
      if (this._frameTimes.length >= 12) this._adaptPerfFromFrames();

      this._fc++;
      const now = performance.now();
      if (now - this._ft >= 1000) {
        this.fps = this._fc;
        this._fc = 0;
        this._ft = now;
      }
      if (this.onStats) {
        this.onStats({
          zoom: this.zoom,
          fps: this.fps,
          visible: this.visible.length,
          regions: this.visibleRegions.length,
          lod: this._currentLod,
          tier: this._lodTier,
          perf: this.perf && this.perf.tier,
          frameMs: Math.round(frameMs)
        });
      }
    }

    // ───────── controls ─────────
    /** Map pan sensitivity multiplier (0.5–2). Default 1. */
    setPanSensitivity(v) {
      const n = Number(v);
      this.panSensitivity = clamp(isFinite(n) ? n : 1, 0.5, 2);
    }
    getPanSensitivity() {
      return this.panSensitivity != null ? this.panSensitivity : 1;
    }
    setZoomSensitivity(v) {
      const n = Number(v);
      this.zoomSensitivity = clamp(isFinite(n) ? n : 1, 0.5, 2);
    }
    getZoomSensitivity() {
      return this.zoomSensitivity != null ? this.zoomSensitivity : 1;
    }

    _sens() {
      const s = this.panSensitivity != null ? this.panSensitivity : 1;
      return Number.isFinite(s) ? clamp(s, 0.5, 2) : 1;
    }
    _zoomSens() {
      const s = this.zoomSensitivity != null ? this.zoomSensitivity : 1;
      return Number.isFinite(s) ? clamp(s, 0.5, 2) : 1;
    }

    /** Screen delta (px) → pan. Always scaled by sensitivity. */
    pan(dx, dy) {
      const cssW = this.canvas.clientWidth || 1;
      const cssH = this.canvas.clientHeight || 1;
      if (cssW < 2 || cssH < 2) return;
      if (!Number.isFinite(dx) || !Number.isFinite(dy)) return;
      const s = this._sens();
      const fit = Math.min(cssW / CFG.WORLD_W, cssH / CFG.WORLD_H) || 1;
      const z = Number.isFinite(this.zoom) ? this.zoom : 1;
      const scale = fit * z;
      if (!Number.isFinite(scale) || scale < 1e-8) {
        this._clampCamera();
        return;
      }
      // world units moved = pixels / scale * sensitivity
      this.camLon -= (dx / scale) * s;
      this.camLat += (dy / scale) * s;
      this._clampCamera();
      this.setDirty();
    }

    /**
     * Zoom at screen point (sx,sy). factor>1 zooms in.
     * Sensitivity speeds up/slows pinch & wheel the same way as pan.
     */
    zoomAt(factor, sx, sy) {
      const cssW = this.canvas.clientWidth || 1;
      const cssH = this.canvas.clientHeight || 1;
      if (cssW < 2 || cssH < 2) return;
      if (!Number.isFinite(factor) || factor <= 0) return;

      // Zoom sensitivity independent from pan (legacy: both were the same slider)
      const sens = this._zoomSens ? this._zoomSens() : this._sens();
      const t = Math.log(clamp(factor, 0.5, 2));
      factor = Math.exp(t * (0.65 + 0.35 * sens));
      factor = clamp(factor, 0.9, 1.1);

      const z0 = Number.isFinite(this.zoom) ? this.zoom : this._minZoom();
      const zMin = this._minZoom();
      const z1 = clamp(z0 * factor, zMin, CFG.MAX_ZOOM);
      if (Math.abs(z1 - z0) < 1e-9) return;

      const fit = Math.min(cssW / CFG.WORLD_W, cssH / CFG.WORLD_H) || 1;
      const den0 = fit * z0;
      if (!Number.isFinite(den0) || den0 < 1e-8) return;
      const worldX = this.camLon + (sx - cssW * 0.5) / den0;
      const worldY = this.camLat - (sy - cssH * 0.5) / den0;

      this.zoom = z1;
      const den1 = fit * z1;
      if (Number.isFinite(worldX) && Number.isFinite(den1) && den1 > 1e-8) {
        this.camLon = worldX - (sx - cssW * 0.5) / den1;
        this.camLat = worldY + (sy - cssH * 0.5) / den1;
      }
      this._clampCamera();
      this.setDirty();
    }

    // ───────── Public API ─────────
    /**
     * تلوين حدود دولة حسب الملكية الحالية (هندسة الضم).
     * الحدود = حواف الأقاليم المملوكة التي تلامس مالكاً آخر أو البحر.
     */
    setCountryBorder(name, color, silent) {
      const st = this.countryStyles.get(name) || {};
      if (st.border === color && st.borderWidth === 1) {
        this.countryStyles.set(name, st);
        return;
      }
      st.border = color;
      st.borderWidth = 1;
      this.countryStyles.set(name, st);
      if (!silent) this.setDirty();
    }
    /** Distinct player outline drawn last on top of regions */
    setPlayerBorder(name, color, silent) {
      this._playerBorderName = name || null;
      this._playerBorderColor = color || '#3db8ff';
      if (name) this.setCountryBorder(name, color, true);
      if (!silent) this.setDirty();
    }
    /**
     * تلوين مساحة دولة = كل الأقاليم التي تملكها حالياً (بعد الضم).
     */
    setCountryFill(name, color, silent) {
      const st = this.countryStyles.get(name) || {};
      st.fill = color;
      this.countryStyles.set(name, st);
      if (!silent) this.setDirty();
    }
    clearCountryStyle(name) {
      this.countryStyles.delete(name);
      this.setDirty();
    }
    clearAllCountryStyles(silent) {
      this.countryStyles.clear();
      this._playerBorderName = null;
      this._playerBorderColor = null;
      if (!silent) this.setDirty();
    }

    /** regionKey = unique region id (string). Always unique — never shared names. */
    setRegionBorder(regionKey, color, widthMult, silent) {
      const k = String(regionKey);
      const st = this.regionStyles.get(k) || {};
      const bw = widthMult != null ? widthMult : 1;
      if (st.border === color && st.borderWidth === bw && st.forceBorder) return;
      st.border = color;
      st.borderWidth = bw;
      // Thick contest style; still gated by LOD3+ in draw (never far view)
      st.forceBorder = bw >= 1.5;
      this.regionStyles.set(k, st);
      if (!silent) this.setDirty();
    }
    setRegionFill(regionKey, color) {
      const k = String(regionKey);
      const st = this.regionStyles.get(k) || {};
      st.fill = color;
      this.regionStyles.set(k, st);
      this.setDirty();
    }
    clearRegionStyle(regionKey) {
      this.regionStyles.delete(String(regionKey));
      this.setDirty();
    }
    clearAllRegionStyles() {
      this.regionStyles.clear();
      this.setDirty();
    }
    /** Keep only contest borders for activeKeys; drop stale red outlines */
    syncContestBorders(activeKeys, color, widthMult) {
      const keep = new Set();
      if (activeKeys && activeKeys.length) {
        for (let i = 0; i < activeKeys.length; i++) keep.add(String(activeKeys[i]));
      }
      let changed = false;
      for (const k of Array.from(this.regionStyles.keys())) {
        if (!keep.has(k)) {
          this.regionStyles.delete(k);
          changed = true;
        }
      }
      for (const k of keep) {
        const st = this.regionStyles.get(k) || {};
        const bw = widthMult != null ? widthMult : 1.6;
        const col = color || '#ff2020';
        if (st.border !== col || st.borderWidth !== bw || !st.forceBorder) {
          st.border = col;
          st.borderWidth = bw;
          st.forceBorder = true;
          this.regionStyles.set(k, st);
          changed = true;
        }
      }
      if (changed) this.setDirty();
      return changed;
    }

    /**
     * regionKey → [{ id, count, icon }]
     * Icons drawn only at high zoom (LOD4+).
     */
    setRegionUnitMarkers(map) {
      this.regionUnitMarkers = new Map();
      if (map && typeof map === 'object') {
        Object.keys(map).forEach((k) => {
          const arr = map[k];
          if (arr && arr.length) this.regionUnitMarkers.set(String(k), arr);
        });
      }
      this.setDirty();
    }

    _ensureFlagImg(country) {
      if (!this._flagImgCache) this._flagImgCache = new Map();
      if (this._flagImgCache.has(country)) return this._flagImgCache.get(country);
      const API = (typeof WOK_FLAGS !== 'undefined') ? WOK_FLAGS : null;
      if (!API || !API.get) { this._flagImgCache.set(country, null); return null; }
      const src = API.get(country);
      if (!src) { this._flagImgCache.set(country, null); return null; }
      const img = new Image();
      img.decoding = 'async';
      img.src = src;
      this._flagImgCache.set(country, img);
      return img;
    }
    /**
     * Political center of mass of currently owned regions.
     * Longitudes unwrapped around a reference so Russia/USA don't land mid-ocean.
     * Returns { x: lon, y: mercY } in world space.
     */
    getCountryCenter(country) {
      const keys = this.getCountryRegions ? this.getCountryRegions(country) : [];
      const pts = [];
      if (keys && keys.length) {
        for (let i = 0; i < keys.length; i++) {
          const r = this.regionByKey && this.regionByKey.get(String(keys[i]));
          if (!r || !r.bbox) continue;
          const a = Math.max(0.01, r.area || ((r.bbox.maxX - r.bbox.minX) * (r.bbox.maxY - r.bbox.minY)));
          let cx = r.cx != null ? r.cx : (r.bbox.minX + r.bbox.maxX) * 0.5;
          // normalize lon
          cx = ((cx + 180) % 360 + 360) % 360 - 180;
          const cy = r.cy != null ? r.cy : (r.bbox.minY + r.bbox.maxY) * 0.5;
          pts.push({ x: cx, y: cy, a: a });
        }
      }
      if (!pts.length) {
        // fallback: country mesh centroid / capital
        if (this.countryCapitals && this.countryCapitals.has(country)) {
          const cap = this.countryCapitals.get(country);
          return { x: cap.lon, y: cap.mercY };
        }
        const list = this.lod && this.lod.med && this.lod.med.length ? this.lod.med : (this.lod && this.lod.low) || [];
        for (let i = 0; i < list.length; i++) {
          if (list[i].name === country) return { x: list[i].cx, y: list[i].cy };
        }
        return null;
      }
      // Reference longitude = largest region (stable for antimeridian)
      let ref = pts[0].x, bestA = pts[0].a;
      for (let i = 1; i < pts.length; i++) {
        if (pts[i].a > bestA) { bestA = pts[i].a; ref = pts[i].x; }
      }
      let sx = 0, sy = 0, w = 0;
      for (let i = 0; i < pts.length; i++) {
        let x = pts[i].x;
        let d = x - ref;
        while (d > 180) d -= 360;
        while (d < -180) d += 360;
        x = ref + d;
        const a = pts[i].a;
        sx += x * a; sy += pts[i].y * a; w += a;
      }
      if (w <= 0) return null;
      let outX = sx / w;
      outX = ((outX + 180) % 360 + 360) % 360 - 180;
      return { x: outX, y: sy / w };
    }

    /**
     * Draw flags in SCREEN space so images are upright (world transform flips Y).
     * Position = political center of mass of owned land.
     */
    _drawCountryFlags(ctx, sx) {
      return; // PER: flags removed
    }

    /** moves: array from WOK_Military.activeMoves */
    setMilitaryMoves(moves) {
      const next = Array.isArray(moves) ? moves : [];
      const prev = this.militaryMoves || [];
      let changed = prev.length !== next.length;
      if (!changed) {
        for (let i = 0; i < next.length; i++) {
          if (!prev[i] || prev[i].id !== next[i].id || prev[i].endsAt !== next[i].endsAt) {
            changed = true; break;
          }
        }
      }
      this.militaryMoves = next;
      if (changed) this.setDirty();
      // animate progress dots at low FPS without full logic storms
      if (next.length && !this._moveAnimTimer) {
        const self = this;
        this._moveAnimTimer = setInterval(function () {
          if (!self.militaryMoves || !self.militaryMoves.length) {
            clearInterval(self._moveAnimTimer);
            self._moveAnimTimer = null;
            return;
          }
          self.setDirty();
        }, (self.perf && self.perf.tier === 'low') ? 200 : 140);
      }
    }

    _regionCenterWorld(key) {
      key = String(key);
      if (this._regionCenters.has(key)) return this._regionCenters.get(key);
      // Canonical lookup
      const r = this.regionByKey && this.regionByKey.get(key);
      if (r) {
        let x = r.cx != null ? r.cx : (r.bbox.minX + r.bbox.maxX) * 0.5;
        if (x > 180) x -= 360;
        if (x < -180) x += 360;
        const pt = {
          x: x,
          y: r.cy != null ? r.cy : (r.bbox.minY + r.bbox.maxY) * 0.5
        };
        this._regionCenters.set(key, pt);
        return pt;
      }
      // Fallback: visible regions
      if (this.visibleRegions) {
        for (let i = 0; i < this.visibleRegions.length; i++) {
          const c = this.visibleRegions[i].c || this.visibleRegions[i];
          if (String(c.key) === key) {
            const pt = {
              x: c.cx != null ? c.cx : (c.bbox.minX + c.bbox.maxX) * 0.5,
              y: c.cy != null ? c.cy : (c.bbox.minY + c.bbox.maxY) * 0.5
            };
            this._regionCenters.set(key, pt);
            return pt;
          }
        }
      }
      if (this.regions) {
        for (let i = 0; i < this.regions.length; i++) {
          const c = this.regions[i];
          if (String(c.key) === key) {
            const pt = {
              x: c.cx != null ? c.cx : (c.bbox.minX + c.bbox.maxX) * 0.5,
              y: c.cy != null ? c.cy : (c.bbox.minY + c.bbox.maxY) * 0.5
            };
            this._regionCenters.set(key, pt);
            return pt;
          }
        }
      }
      return null;
    }

    _unwrapNear(lon) {
      let d = lon - this.camLon;
      while (d > 180) d -= 360;
      while (d < -180) d += 360;
      return this.camLon + d;
    }

    /** Normalize region center lon to -180..180 */
    _normLon(x) {
      let v = Number(x);
      if (!Number.isFinite(v)) return 0;
      // accept 0..360 storage
      if (v > 180) v -= 360;
      if (v < -180) v += 360;
      return v;
    }

    /**
     * Draw moves in current world transform (ctx already scaled/translated).
     * Positions = region centers → stays glued when panning/zooming.
     */
    /** Screen-space hit test against troop move lines. Returns move obj or null. */
    hitMilitaryMove(sx, sy, maxPx) {
      const moves = this.militaryMoves || [];
      if (!moves.length) return null;
      const tol = maxPx != null ? maxPx : 28;
      const tol2 = tol * tol;
      let best = null, bestD = tol2;
      for (let i = 0; i < moves.length; i++) {
        const mv = moves[i];
        const a = this._regionCenterWorld(mv.from);
        const b = this._regionCenterWorld(mv.to);
        if (!a || !b) continue;
        const pa = this.worldToScreen(a.x, a.y);
        const pb = this.worldToScreen(b.x, b.y);
        if (!pa || !pb) continue;
        const d = this._distPointSeg2(sx, sy, pa.x, pa.y, pb.x, pb.y);
        if (d < bestD) { bestD = d; best = mv; }
      }
      return best;
    }
    _distPointSeg2(px, py, x1, y1, x2, y2) {
      const dx = x2 - x1, dy = y2 - y1;
      const len2 = dx * dx + dy * dy || 1e-12;
      let t = ((px - x1) * dx + (py - y1) * dy) / len2;
      if (t < 0) t = 0; else if (t > 1) t = 1;
      const mx = x1 + t * dx - px, my = y1 + t * dy - py;
      return mx * mx + my * my;
    }

    _drawMilitaryMovesWorld(ctx) {
      const t = Date.now();
      const lw = Math.max((CFG.COUNTRY_PX * 1.2) / Math.max(this._fit() * this.zoom, 1e-6), 0.15);
      for (let i = 0; i < this.militaryMoves.length; i++) {
        const mv = this.militaryMoves[i];
        // Bot reinforcements stay invisible until they arrive
        if (mv.hiddenUntilArrive || mv.silent) continue;
        const a = this._regionCenterWorld(mv.from);
        const b = this._regionCenterWorld(mv.to);
        if (!a || !b) continue;
        let ax = this._unwrapNear(this._normLon(a.x));
        let bx = this._unwrapNear(this._normLon(b.x));
        const ay = a.y, by = b.y;
        if (!Number.isFinite(ax) || !Number.isFinite(bx) || !Number.isFinite(ay) || !Number.isFinite(by)) continue;
        const prog = Math.max(0, Math.min(1, (t - (mv.startedAt || t)) / Math.max(1, (mv.endsAt || t) - (mv.startedAt || t))));
        const friendly = !!mv.friendly;
        ctx.save();
        ctx.strokeStyle = friendly ? '#2f8cff' : '#e02020';
        ctx.fillStyle = friendly ? '#2f8cff' : '#e02020';
        ctx.lineWidth = lw * (friendly ? 1.1 : 1.25);
        ctx.lineCap = 'round';
        ctx.setLineDash(mv.sea ? [1.2, 0.8] : []);
        ctx.beginPath();
        ctx.moveTo(ax, ay);
        ctx.lineTo(bx, by);
        ctx.stroke();
        ctx.setLineDash([]);
        const mx = ax + (bx - ax) * prog;
        const my = ay + (by - ay) * prog;
        ctx.beginPath();
        ctx.arc(mx, my, lw * 1.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }

    _drawMilitaryMovesScreen(ctx) {
      // Deprecated — use _drawMilitaryMovesWorld
      this._drawMilitaryMovesWorld(ctx);
    }

    /** World anchor for unit icons — land = region center; sea = coast point in the water */
    _unitAnchorWorld(region, domain) {
      if (!region) return null;
      const key = String(region.key);
      if (domain === 'sea' && this._coastAnchor && this._coastAnchor.has(key)) {
        return this._coastAnchor.get(key);
      }
      // Non-coastal sea units: still try outer edge if any, else center
      if (domain === 'sea' && this._coastAnchor && this._coastAnchor.size) {
        // fallback: center nudged east slightly (harmless)
      }
      const x = region.cx != null ? region.cx : (region.bbox.minX + region.bbox.maxX) * 0.5;
      const y = region.cy != null ? region.cy : (region.bbox.minY + region.bbox.maxY) * 0.5;
      return { x: x, y: y };
    }

    _drawRegionUnitMarkersScreen(ctx) {
      const self = this;
      const cssW = this.canvas.clientWidth || 1;
      const cssH = this.canvas.clientHeight || 1;
      const scale = (this._fit() * this.zoom) || 1;

      this.visibleRegions.forEach(function (item) {
        const c = item.c;
        const markers = self.regionUnitMarkers.get(String(c.key));
        if (!markers || !markers.length) return;

        // Icon size from region size on screen (larger province → larger icon)
        const rw = Math.max(1, (c.bbox.maxX - c.bbox.minX) * scale);
        const rh = Math.max(1, (c.bbox.maxY - c.bbox.minY) * scale);
        const regionPx = Math.sqrt(rw * rh);
        let size = Math.max(20, Math.min(52, regionPx * 0.28));

        // Split land vs sea markers so each domain gets its own fixed world anchor
        const land = [];
        const sea = [];
        markers.forEach(function (m) {
          if (m.domain === 'sea') sea.push(m);
          else land.push(m);
        });

        function drawGroup(list, domain) {
          if (!list.length) return;
          const anchor = self._unitAnchorWorld(c, domain);
          if (!anchor) return;
          const scr = self.worldToScreen(anchor.x, anchor.y);
          if (!Number.isFinite(scr.x) || !Number.isFinite(scr.y)) return;
          if (scr.x < -60 || scr.y < -60 || scr.x > cssW + 60 || scr.y > cssH + 60) return;

          list.forEach(function (m, idx) {
            // Small spread in SCREEN pixels only for stacking multiple types — anchor stays fixed
            const ang = (idx * 2.15) + (c.id | 0) * 0.13;
            const rad = idx * (size * 0.42);
            const px = scr.x + Math.cos(ang) * rad;
            const py = scr.y + Math.sin(ang) * rad * 0.7;
            const img = self._getUnitImage(m.icon);
            ctx.save();
            ctx.globalAlpha = 0.96;
            // Soft plate under icon so it reads on any terrain
            ctx.fillStyle = domain === 'sea' ? 'rgba(20,60,120,0.55)' : 'rgba(0,0,0,0.4)';
            ctx.beginPath();
            ctx.arc(px, py, size * 0.48, 0, Math.PI * 2);
            ctx.fill();
            if (img && img.complete && img.naturalWidth) {
              ctx.drawImage(img, px - size / 2, py - size / 2, size, size);
            } else {
              ctx.fillStyle = domain === 'sea' ? 'rgba(80,180,255,0.9)' : 'rgba(40,100,180,0.85)';
              ctx.beginPath();
              ctx.arc(px, py, size * 0.32, 0, Math.PI * 2);
              ctx.fill();
            }
            if (m.count > 1) {
              ctx.fillStyle = '#fff';
              ctx.strokeStyle = 'rgba(0,0,0,0.75)';
              ctx.lineWidth = 3;
              ctx.font = 'bold ' + Math.max(11, size * 0.36) + 'px sans-serif';
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              const tx = px, ty = py + size * 0.42;
              ctx.strokeText(String(m.count), tx, ty);
              ctx.fillText(String(m.count), tx, ty);
            }
            ctx.restore();
          });
        }

        drawGroup(land, 'land');
        drawGroup(sea, 'sea');
      });
    }

    _getUnitImage(src) {
      if (!src) return null;
      let img = this._unitImgCache.get(src);
      if (img) return img;
      img = new Image();
      img.src = src;
      const self = this;
      // Debounced redraw — avoid zoom glitch when many unit icons load at once
      img.onload = function () {
        if (self._unitImgDirtyTimer) return;
        self._unitImgDirtyTimer = setTimeout(function () {
          self._unitImgDirtyTimer = null;
          self.setDirty();
        }, 120);
      };
      this._unitImgCache.set(src, img);
      return img;
    }

    /** Screen → world lon/lat (lat = mercator Y) */
    screenToWorld(sx, sy) {
      const cssW = this.canvas.clientWidth || 1;
      const cssH = this.canvas.clientHeight || 1;
      const lon = this.camLon + (sx / cssW - 0.5) * this.viewW;
      const lat = this.camLat - (sy / cssH - 0.5) * this.viewH;
      return { lon, lat };
    }

    /** World lon + mercatorY → screen CSS pixels */
    worldToScreen(lon, mercY) {
      const cssW = this.canvas.clientWidth || 1;
      const cssH = this.canvas.clientHeight || 1;
      // unwrap lon near camera for seamless map
      let dLon = lon - this.camLon;
      while (dLon > 180) dLon -= 360;
      while (dLon < -180) dLon += 360;
      const sx = (dLon / this.viewW + 0.5) * cssW;
      const sy = ((this.camLat - mercY) / this.viewH + 0.5) * cssH;
      return { x: sx, y: sy };
    }

    /** Normalize Natural Earth / alternate names to game canonical names */
    _initCountryAliases() {
      const pairs = [
        ['Czechia', 'Czech Republic'],
        ['Bosnia and Herz.', 'Bosnia and Herzegovina'],
        ['Central African Rep.', 'Central African Republic'],
        ['Dem. Rep. Congo', 'Democratic Republic of the Congo'],
        ['Congo', 'Republic of the Congo'],
        ['Dominican Rep.', 'Dominican Republic'],
        ['Eq. Guinea', 'Equatorial Guinea'],
        ["Côte d'Ivoire", 'Ivory Coast'],
        ['Guinea-Bissau', 'Guinea Bissau'],
        ['Serbia', 'Republic of Serbia'],
        ['Solomon Is.', 'Solomon Islands'],
        ['Tanzania', 'United Republic of Tanzania'],
        ['Timor-Leste', 'East Timor'],
        ['eSwatini', 'Swaziland'],
        ['W. Sahara', 'Western Sahara'],
        ['Bahamas', 'The Bahamas'],
        ['Falkland Is.', 'United Kingdom'],
        ['Fr. S. Antarctic Lands', 'France'],
        ['New Caledonia', 'France'],
        ['Puerto Rico', 'United States of America'],
        ['N. Cyprus', 'Turkey'],
        ['Cyprus', 'Turkey'],
        ['Luxembourg', 'Belgium'],
        ['Trinidad and Tobago', 'Venezuela'],
        ['Brunei', 'Malaysia']
      ];
      this.countryAliases = new Map(pairs);
    }

    /** Resolve any name variant → canonical game country name */
    resolveCountryName(name) {
      if (!name) return null;
      if (this.countryMerge && this.countryMerge.has(name)) name = this.countryMerge.get(name);
      if (this.countryAliases && this.countryAliases.has(name)) name = this.countryAliases.get(name);
      if (name === 'Israel') name = 'Palestine';
      return name;
    }

    /**
     * Capital of a country: from country-capitals.json (real capital city).
     * Fallback: region named like capital / highest-pop region with sane bbox.
     * @returns {{ lon: number, mercY: number, lat?: number }}
     */
    getCountryCapital(country) {
      country = this.resolveCountryName(country) || country;
      const fixed = this.countryCapitals && this.countryCapitals.get(country);
      if (fixed) return { lon: fixed.lon, mercY: fixed.mercY, lat: fixed.lat };

      // fallback: best region (high pop, non-wrapping bbox)
      const keys = this.getCountryRegions(country);
      let best = null, bestPop = -1;
      for (const k of keys) {
        const r = this.regionByKey.get(k);
        if (!r || !r.bbox) continue;
        const bw = r.bbox.maxX - r.bbox.minX;
        if (bw > 90) continue; // antimeridian junk
        const pop = r.pop || 0;
        if (pop > bestPop) { bestPop = pop; best = r; }
      }
      if (best) return { lon: best.cx, mercY: best.cy };

      const list = this.lod.med.length ? this.lod.med : this.lod.low;
      for (const c of list) {
        if (c.name === country) return { lon: c.cx, mercY: c.cy };
      }
      return { lon: 0, mercY: 0 };
    }

    /** Approximate country area from region bboxes (for flag LOD) */
    getCountryAreaScore(country) {
      const keys = this.getCountryRegions(country);
      let a = 0;
      for (const k of keys) {
        const r = this.regionByKey.get(k);
        if (r) a += r.area || 0;
      }
      return a;
    }

    /** عدد أقاليم الدولة المطلة على البحر */
    /**
     * Performance: never draw island polygons &lt; 50,000 km².
     * Rebuilds paths from source lon/lat (not draw-then-erase).
     */
    /**
     * Estimate region area in km² (cached on r.areaKm2).
     * Coastline does NOT make a region an island — only land connectivity does.
     */
    _regionAreaKm2(r) {
      if (!r) return 0;
      if (r.areaKm2 != null && isFinite(r.areaKm2)) return r.areaKm2;
      if (!r.bbox) return 0;
      const lat = invMercY((r.bbox.minY + r.bbox.maxY) * 0.5);
      const w = Math.abs(r.bbox.maxX - r.bbox.minX) * 111.32 * Math.cos(lat * Math.PI / 180);
      // mercator Y span → approx geographic degrees then km
      const hDeg = Math.abs(r.bbox.maxY - r.bbox.minY) * Math.cos(lat * Math.PI / 180);
      const h = hDeg * 110.574;
      r.areaKm2 = Math.abs(w * h);
      return r.areaKm2;
    }

    /**
     * Land-connected component total area (km²) for each region via _landAdj.
     * Mainland coastal provinces connect inland → large component.
     * True islands form their own small component.
     */
    _ensureIslandComponents() {
      if (this._islandCompReady && this._islandCompArea) return;
      this._islandCompArea = new Map();
      this._islandCompIsIsland = new Map();
      const regions = this.regions || [];
      const visited = new Set();
      // IMPORTANT: use STRICT adjacency only (shared edge). Proximity links would
      // glue near-shore islands to the mainland and make hide-islands fail on zoom.
      const adj = this._landAdjStrict && this._landAdjStrict.size
        ? this._landAdjStrict
        : this._landAdj;
      for (let i = 0; i < regions.length; i++) {
        const start = regions[i];
        if (!start || visited.has(String(start.key))) continue;
        const queue = [String(start.key)];
        const comp = [];
        visited.add(String(start.key));
        while (queue.length) {
          const k = queue.shift();
          comp.push(k);
          const neigh = adj && adj.get(k);
          if (!neigh) continue;
          for (const n of neigh) {
            const nk = String(n);
            if (visited.has(nk)) continue;
            visited.add(nk);
            queue.push(nk);
          }
        }
        let total = 0;
        let hasInterior = false;
        for (let j = 0; j < comp.length; j++) {
          const r = this.regionByKey && this.regionByKey.get(comp[j]);
          total += this._regionAreaKm2(r);
          if (!(this._coastal && this._coastal.has(comp[j]))) hasInterior = true;
        }
        // Island mass = no landlocked hinterland in the component
        const isIslandMass = !hasInterior;
        for (let j = 0; j < comp.length; j++) {
          this._islandCompArea.set(comp[j], total);
          this._islandCompIsIsland.set(comp[j], isIslandMass);
        }
      }
      this._islandCompReady = true;
    }

    _isSmallIslandRegion(r) {
      if (!r) return false;
      return this.isRegionSmallIsland(r.key);
    }

    setHideSmallIslands(on) {
      this.hideSmallIslands = !!on;
      // Mesh: strip ONLY detached MultiPolygon island parts &lt; 50k — never whole countries
      if (this.lod) {
        const applyList = (arr) => {
          if (!arr) return;
          for (let i = 0; i < arr.length; i++) {
            const c = arr[i];
            if (c && typeof c.applyIslandFilter === 'function') c.applyIslandFilter(this.hideSmallIslands);
          }
        };
        applyList(this.lod.low);
        applyList(this.lod.med);
      }
      // Regions: hide true island land-components &lt; 50k (fills + borders at LOD3–4)
      this._islandCompReady = false;
      let nHide = 0;
      if (this.regions) {
        for (let i = 0; i < this.regions.length; i++) {
          const r = this.regions[i];
          if (!r) continue;
          const island = this._isSmallIslandRegion(r);
          r._hiddenSmallIsland = !!(this.hideSmallIslands && island);
          if (r._hiddenSmallIsland) nHide++;
        }
      }
      console.log('[Map] Small-island filter', this.hideSmallIslands ? 'ON' : 'OFF',
        'hiddenIslandRegions=', nHide, '(countries always kept)');
      try { this._rebuildPoliticalGeometry(); } catch (_) {}
      // Re-apply country border detail after mesh paths rebuild
      if (this._countryBorderDetail != null) {
        try { this.setCountryBorderDetail(this._countryBorderDetail); } catch (_) {}
      } else {
        this._collectCacheKey = '';
        this.setDirty();
      }
    }

    getHideSmallIslands() { return !!this.hideSmallIslands; }

    /**
     * Absolute detail level → RDP tolerance.
     * Quality uses the number itself (15 = 3× quality of old 5), not a remapped min.
     * Each +1 keeps the same quality step as the old 5–24 scale.
     */
    _detailToTol(level) {
      // Absolute quality ∝ level → tol ∝ 1/level
      // 5→1.25, 15→0.417 (3× of 5), 48→0.130, 64→0.098 — absolute quality ∝ level
      const v = Math.max(15, Math.min(64, Number(level) || 32));
      let tol = 6.25 / v;
      if (tol < 0.05) tol = 0.05;
      if (tol > 1.35) tol = 1.35;
      return tol;
    }

    /** Country outer borders LOD3–5 (pathMid). Independent of region borders. */
    setCountryBorderDetail(level) {
      const v = Math.max(15, Math.min(64, Math.round(Number(level) || 32)));
      this._countryBorderDetail = v;
      const tol = this._detailToTol(v);
      const rebuild = (arr) => {
        if (!arr) return;
        for (let i = 0; i < arr.length; i++) {
          const c = arr[i];
          if (!c || !c.geometry) continue;
          try { c.pathMid = toPath(simplifyProjectedGeom(c.geometry, tol)); }
          catch (_) { c.pathMid = c.pathSimple || c.path; }
        }
      };
      if (this.lod) { rebuild(this.lod.low); rebuild(this.lod.med); }
      this.setDirty();
      return v;
    }
    getCountryBorderDetail() {
      return this._countryBorderDetail != null ? this._countryBorderDetail : 32;
    }

    /** Region border detail (LOD2+ outlines + LOD4–5 internal). Independent of country pathMid. */
    setRegionBorderDetail(level) {
      const v = Math.max(15, Math.min(64, Math.round(Number(level) || 32)));
      this._regionBorderDetail = v;
      const tol = this._detailToTol(v);
      // Rebuild simplified region stroke paths so the slider actually changes geometry
      if (this.regions && this.regions.length) {
        for (let i = 0; i < this.regions.length; i++) {
          const r = this.regions[i];
          if (!r || !r.lines || !r.lines.length) continue;
          const simp = [];
          for (let j = 0; j < r.lines.length; j++) {
            const ln = r.lines[j];
            if (!ln || ln.length < 2) continue;
            simp.push(rdpLine(ln, tol));
          }
          r.pathMid = linesToPath(simp);
        }
      }
      this.setDirty();
      return v;
    }
    getRegionBorderDetail() {
      return this._regionBorderDetail != null ? this._regionBorderDetail : 32;
    }

    /** Country feature from LOD mesh (true exterior path). */
    _getCountryMesh(name) {
      if (!name || !this.lod) return null;
      const lists = [this.lod.med, this.lod.low];
      for (let li = 0; li < lists.length; li++) {
        const arr = lists[li];
        if (!arr) continue;
        for (let i = 0; i < arr.length; i++) {
          if (arr[i] && arr[i].name === name) return arr[i];
        }
      }
      return null;
    }

    /** هل الإقليم مطل على البحر؟ */
    isRegionCoastal(regionKey) {
      return !!(this._coastal && this._coastal.has(String(regionKey)));
    }

    /** كتلة جزرية: كل أقاليم المكوّن البرّي ساحلية (لا داخل قاري). */
    isRegionIsland(regionKey) {
      this._ensureIslandComponents();
      const k = String(regionKey);
      // Recompute island-mass flag if missing
      if (!this._islandCompIsIsland) {
        this._islandCompReady = false;
        this._ensureIslandComponents();
      }
      if (this._islandCompIsIsland && this._islandCompIsIsland.has(k)) {
        return !!this._islandCompIsIsland.get(k);
      }
      // Fallback: component area < 50k treated as island mass
      const a = this._islandCompArea && this._islandCompArea.get(k);
      return a != null && a < MIN_ISLAND_KM2;
    }

    getRegionLandComponentAreaKm2(regionKey) {
      this._ensureIslandComponents();
      return (this._islandCompArea && this._islandCompArea.get(String(regionKey))) || 0;
    }

    isRegionSmallIsland(regionKey) {
      this._ensureIslandComponents();
      const k = String(regionKey);
      const a = this._islandCompArea && this._islandCompArea.get(k);
      if (a == null || a >= MIN_ISLAND_KM2) return false;
      // Prefer explicit island-mass flag when present
      if (this._islandCompIsIsland && this._islandCompIsIsland.has(k)) {
        return !!this._islandCompIsIsland.get(k);
      }
      return true;
    }


    colorCountryBorder(country, color, opts) {
      opts = opts || {};
      if (!country) return;
      if (color == null) {
        this.clearCountryStyle(country);
      } else {
        this.setCountryBorder(country, color, true);
        if (opts.player) this.setPlayerBorder(country, color, true);
      }
      if (!opts.silent) this.setDirty();
    }

    colorRegionBorder(regionKey, color, opts) {
      opts = opts || {};
      const k = String(regionKey);
      if (color == null) { this.clearRegionStyle(k); return; }
      const st = this.regionStyles.get(k) || {};
      st.border = color;
      st.borderWidth = opts.width != null ? opts.width : 1;
      st.forceBorder = !!opts.always;
      this.regionStyles.set(k, st);
      if (!opts.silent) this.setDirty();
    }

    listCountries() {
      // Only countries that currently own ≥1 region (eliminated nations drop out)
      const names = new Set();
      if (this.owners) {
        for (const o of this.owners.values()) {
          if (o) names.add(o);
        }
      }
      return Array.from(names);
    }

    getCountryCoastalCount(country) {
      const keys = this.getCountryRegions(country);
      let n = 0;
      for (const k of keys) {
        if (this.isRegionCoastal(k)) n++;
      }
      return n;
    }

    /** عدد الأقاليم بالملكية الحالية (بعد الاحتلال) */
    getCountryRegionCount(country) {
      return this.getCountryRegions(country).length;
    }

    /** هل للدولة إقليم ساحلي واحد على الأقل (ملكية حالية)؟ */
    countryHasSeaAccess(country) {
      return this.getCountryCoastalCount(country) > 0;
    }

    /** أقاليم ساحلية مملوكة حالياً */
    getCountryCoastalRegions(country) {
      const keys = this.getCountryRegions(country);
      const out = [];
      for (let i = 0; i < keys.length; i++) {
        if (this.isRegionCoastal(keys[i])) out.push(keys[i]);
      }
      return out;
    }

    /** Ray-casting point-in-ring */
    _pointInRing(lon, lat, ring) {
      let inside = false;
      for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
        const xi = ring[i][0], yi = ring[i][1];
        const xj = ring[j][0], yj = ring[j][1];
        const denom = (yj - yi) || 1e-15;
        if (((yi > lat) !== (yj > lat)) &&
            (lon < (xj - xi) * (lat - yi) / denom + xi)) {
          inside = !inside;
        }
      }
      return inside;
    }

    /** Point in GeoJSON polygon / multipolygon (holes respected) */
    _pointInGeom(lon, lat, geom) {
      if (!geom) return false;
      if (geom.type === 'Polygon') {
        if (!this._pointInRing(lon, lat, geom.coordinates[0])) return false;
        for (let h = 1; h < geom.coordinates.length; h++) {
          if (this._pointInRing(lon, lat, geom.coordinates[h])) return false;
        }
        return true;
      }
      if (geom.type === 'MultiPolygon') {
        for (let p = 0; p < geom.coordinates.length; p++) {
          const poly = geom.coordinates[p];
          if (!this._pointInRing(lon, lat, poly[0])) continue;
          let inHole = false;
          for (let h = 1; h < poly.length; h++) {
            if (this._pointInRing(lon, lat, poly[h])) { inHole = true; break; }
          }
          if (!inHole) return true;
        }
      }
      return false;
    }

    _pointInRings(lon, lat, rings) {
      if (!rings || !rings.length) return false;
      for (let i = 0; i < rings.length; i++) {
        if (this._pointInRing(lon, lat, rings[i])) return true;
      }
      return false;
    }

    /**
     * Accurate hit-test: real point-in-polygon, smallest feature wins.
     * Always tests against ALL countries/regions (not only visible list)
     * so zoom/culling never causes wrong country (e.g. Syria→France).
     */
    hitTest(sx, sy) {
      let { lon, lat } = this.screenToWorld(sx, sy);
      // normalize lon into [-180, 180]
      lon = ((lon + 180) % 360 + 360) % 360 - 180;

      const countries = this._currentLod === 'med' ? this.lod.med : this.lod.low;
      let bestCountry = null;
      let bestCountryArea = Infinity;

      for (let i = 0; i < countries.length; i++) {
        const c = countries[i];
        const b = c.bbox;
        // try primary + wrap offsets for antimeridian features
        for (const off of [0, -360, 360]) {
          const testLon = lon - off;
          if (testLon < b.minX - 0.5 || testLon > b.maxX + 0.5) continue;
          if (lat < b.minY - 0.5 || lat > b.maxY + 0.5) continue;
          if (!this._pointInGeom(testLon, lat, c.geometry)) continue;
          const area = (b.maxX - b.minX) * (b.maxY - b.minY);
          if (area < bestCountryArea) {
            bestCountryArea = area;
            bestCountry = c.name;
          }
          break;
        }
      }

      let bestRegion = null;
      let bestRegionArea = Infinity;
      let bestRegionDist = Infinity;
      if (this.zoom >= CFG.REGION_ZOOM_START && this.regions.length) {
        const scale = Math.max(1e-6, this._fit() * this.zoom);
        // ~36px finger tolerance in world degrees
        const fingerPad = 36 / scale;
        const nearLinePad = Math.max(0.25, Math.min(1.2, 28 / scale));
        const pool = (this.visibleRegions && this.visibleRegions.length)
          ? this.visibleRegions.map(function (x) { return x.c; })
          : this.regions;
        const lim = Math.min(pool.length, 600);
        for (let i = 0; i < lim; i++) {
          const r = pool[i];
          if (!r || !r.bbox || r._hiddenSmallIsland) continue;
          const b = r.bbox;
          const area = r.area != null ? r.area : ((b.maxX - b.minX) * (b.maxY - b.minY));
          // Extra pad for tiny regions so a fat finger can select them
          const pad = area < 1.2 ? fingerPad : Math.min(fingerPad * 0.45, 0.35);
          for (const off of [0, -360, 360]) {
            const testLon = lon - off;
            if (testLon < b.minX - pad || testLon > b.maxX + pad) continue;
            if (lat < b.minY - pad || lat > b.maxY + pad) continue;
            let hit = false;
            if (r.rings && r.rings.length) {
              hit = this._pointInRings(testLon, lat, r.rings);
              // if inside expanded bbox of tiny region but not in ring, still accept near center
              if (!hit && area < 1.2) {
                const cx = r.cx != null ? r.cx : (b.minX + b.maxX) * 0.5;
                const cy = r.cy != null ? r.cy : (b.minY + b.maxY) * 0.5;
                const ddx = testLon - cx, ddy = lat - cy;
                if (ddx * ddx + ddy * ddy <= pad * pad) hit = true;
              }
            } else if (r.lines && r.lines.length) {
              hit = this._pointNearLines(testLon, lat, r.lines, nearLinePad);
            }
            if (!hit) continue;
            const cx = r.cx != null ? r.cx : (b.minX + b.maxX) * 0.5;
            const cy = r.cy != null ? r.cy : (b.minY + b.maxY) * 0.5;
            const dist = (testLon - cx) * (testLon - cx) + (lat - cy) * (lat - cy);
            // Prefer smaller regions when finger covers several (West Bank over neighbor)
            if (area < bestRegionArea - 1e-6 || (Math.abs(area - bestRegionArea) < 1e-6 && dist < bestRegionDist)) {
              bestRegionArea = area;
              bestRegionDist = dist;
              bestRegion = {
                id: r.id,
                name: r.name,
                country: r.country,
                key: r.key || String(r.id)
              };
            }
            break;
          }
        }
      }

      // Country identity follows political ownership of the region when available
      if (bestRegion) {
        const owner = this.owners.get(bestRegion.key);
        if (owner) bestCountry = owner;
        else if (bestRegion.country) bestCountry = bestRegion.country;
      }
      // Normalize NE short names → canonical game names
      bestCountry = this.resolveCountryName(bestCountry);
      if (bestRegion && bestRegion.country) {
        bestRegion = Object.assign({}, bestRegion, {
          country: this.resolveCountryName(bestRegion.country) || bestRegion.country
        });
      }
      return { country: bestCountry, region: bestRegion, lon, lat };
    }

    _clearPress() {
      if (this._longTimer) {
        clearTimeout(this._longTimer);
        this._longTimer = null;
      }
      this._press = null;
    }

    _bind() {
      const c = this.canvas;
      const rectOf = () => c.getBoundingClientRect();

      const down = (clientX, clientY, id) => {
        const rect = rectOf();
        const x = clientX - rect.left;
        const y = clientY - rect.top;
        this.pointers.set(id, { x, y });

        if (this.pointers.size === 1) {
          this._press = { x, y, t: performance.now(), id, moved: false, longFired: false };
          // Only arm long-press when a handler is registered (avoids portrait lag / false long-press)
          if (this.onLongPress) {
            this._longTimer = setTimeout(() => {
              if (!this._press || this._press.moved) return;
              const hit = this.hitTest(this._press.x, this._press.y);
              this.onLongPress(hit);
              this._press.longFired = true;
            }, this.LONG_PRESS_MS);
          }
        } else {
          // multi-touch → cancel tap/long
          this._clearPress();
          if (this.pointers.size === 2) {
            const p = [...this.pointers.values()];
            this.lastPinch = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y);
          }
        }
      };

      const move = (clientX, clientY, id) => {
        if (!this.pointers.has(id)) return;
        const rect = rectOf();
        const x = clientX - rect.left;
        const y = clientY - rect.top;
        const prev = this.pointers.get(id);
        this.pointers.set(id, { x, y });

        // Drop stale pointers (WebView ghost fingers)
        if (this.pointers.size > 2) {
          const keep = [id];
          for (const k of this.pointers.keys()) {
            if (keep.length >= 2) break;
            if (k !== id) keep.push(k);
          }
          for (const k of Array.from(this.pointers.keys())) {
            if (keep.indexOf(k) < 0) this.pointers.delete(k);
          }
        }

        if (this.pointers.size === 1) {
          this.lastPinch = 0;
          const dx = x - prev.x, dy = y - prev.y;
          if (this._press) {
            const total = Math.hypot(x - this._press.x, y - this._press.y);
            if (this._press.longFired) {
              if (total > this.TAP_MAX_MOVE) this._press.moved = true;
            } else if (total > this.LONG_PRESS_SLOP) {
              this._press.moved = true;
              if (this._longTimer) {
                clearTimeout(this._longTimer);
                this._longTimer = null;
              }
            }
          }
          if (this._press && this._press.longFired) {
            // camera frozen during aim
          } else if (!this._press || this._press.moved) {
            this.pan(dx, dy);
          }
        } else if (this.pointers.size === 2) {
          this._clearPress();
          const pts = [...this.pointers.values()];
          const d = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
          // Original continuous pinch (no hard freeze thresholds)
          if (this.lastPinch >= 20 && d >= 20) {
            let f = d / this.lastPinch;
            if (Number.isFinite(f) && f > 0) {
              f = clamp(f, 0.9, 1.1);
              const cx = (pts[0].x + pts[1].x) * 0.5;
              const cy = (pts[0].y + pts[1].y) * 0.5;
              this.zoomAt(f, cx, cy);
            }
          }
          if (d >= 16) this.lastPinch = d;
        }
      };

      const up = (clientX, clientY, id) => {
        if (this._press && this._press.id === id) {
          const press = this._press;
          if (!press.moved && !press.longFired) {
            const hit = this.hitTest(press.x, press.y);
            if (hit) { hit.sx = press.x; hit.sy = press.y; }
            if (this.onTap) this.onTap(hit);
          } else if (press.longFired && this.onLongPressEnd) {
            const rect = rectOf();
            const x = clientX - rect.left;
            const y = clientY - rect.top;
            const hit = this.hitTest(x, y);
            this.onLongPressEnd({
              startHit: this.hitTest(press.x, press.y),
              endHit: hit,
              moved: !!press.moved,
              sx: x,
              sy: y
            });
          }
          this._clearPress();
        }
        this.pointers.delete(id);
        if (this.pointers.size < 2) this.lastPinch = 0;
      };

      c.addEventListener('pointerdown', e => {
        try { c.setPointerCapture(e.pointerId); } catch (_) {}
        down(e.clientX, e.clientY, e.pointerId);
      });
      c.addEventListener('pointermove', e => move(e.clientX, e.clientY, e.pointerId));
      c.addEventListener('pointerup', e => up(e.clientX, e.clientY, e.pointerId));
      c.addEventListener('pointercancel', e => up(e.clientX, e.clientY, e.pointerId));
      c.addEventListener('lostpointercapture', e => {
        // WebView sometimes drops a finger without pointerup — clear ghost
        if (this.pointers.has(e.pointerId)) {
          up(e.clientX || 0, e.clientY || 0, e.pointerId);
        }
      });
      c.addEventListener('wheel', e => {
        e.preventDefault();
        // base step; zoomAt multiplies by sensitivity
        const f = e.deltaY < 0 ? 1.08 : 1 / 1.08;
        const r = c.getBoundingClientRect();
        this.zoomAt(f, e.clientX - r.left, e.clientY - r.top);
      }, { passive: false });

      window.addEventListener('resize', () => this._resize());
      window.addEventListener('orientationchange', () => setTimeout(() => this._resize(), 120));
    }

    _resize() {
      const r = this.canvas.getBoundingClientRect();
      const tw = Math.round(r.width * this.dpr);
      const th = Math.round(r.height * this.dpr);
      if (this.canvas.width !== tw || this.canvas.height !== th) {
        this.canvas.width = tw;
        this.canvas.height = th;
        this.setDirty();
      }
    }

    // ═══════════════════════════════════════════
    // API — الجوار البري / البحري / الاحتلال
    // ═══════════════════════════════════════════

    /** هل إقليمان متجاوران برياً؟ (يشمل روابط القرب) */
    areRegionsLandAdjacent(keyA, keyB) {
      const a = String(keyA), b = String(keyB);
      const set = this._landAdj && this._landAdj.get(a);
      return !!(set && set.has(b));
    }

    /**
     * جوار بري صارم: حافة مشتركة فقط — بدون توسعة القرب.
     * يُستخدم للبوت والحركة الصارمة وكشف الجزر الحقيقية.
     */
    areRegionsStrictLandAdjacent(keyA, keyB) {
      const a = String(keyA), b = String(keyB);
      const set = this._landAdjStrict && this._landAdjStrict.get(a);
      return !!(set && set.has(b));
    }

    /** مفاتيح الأقاليم المجاورة برياً بصرامة (حافة مشتركة فقط) */
    getRegionStrictLandNeighbors(regionKey) {
      const set = this._landAdjStrict && this._landAdjStrict.get(String(regionKey));
      return set ? Array.from(set) : [];
    }

    /** هل دولتان متجاورتان برياً؟ (حسب الملكية الحالية للأقاليم) */
    areCountriesLandAdjacent(countryA, countryB) {
      if (countryA === countryB) return false;
      const set = this._countryLandAdj && this._countryLandAdj.get(countryA);
      return !!(set && set.has(countryB));
    }

    /** مفاتيح الأقاليم المجاورة برياً لإقليم معيّن */
    getRegionLandNeighbors(regionKey) {
      const set = this._landAdj && this._landAdj.get(String(regionKey));
      return set ? Array.from(set) : [];
    }

    /**
     * أسماء الدول المجاورة برياً لدولة معيّنة (حسب الملكية الحالية).
     * مفيد لتحريك الجيوش / أهداف الاحتلال.
     */
    getCountryLandNeighbors(country) {
      const set = this._countryLandAdj && this._countryLandAdj.get(country);
      return set ? [...set] : [];
    }

    /** أقاليم دولة معيّنة (حسب الملكية الحالية) — O(1) عبر كاش _countryToRegions */
    getCountryRegions(country) {
      if (!country) return [];
      if (this._countryToRegions && this._countryToRegions.has(country)) {
        return this._countryToRegions.get(country).slice();
      }
      // fallback بطيء إن لم يُبنَ الكاش بعد
      const out = [];
      for (const [key, owner] of this.owners) {
        if (owner === country) out.push(key);
      }
      return out;
    }

    /**
     * احتياطي الموارد الثابت للدولة (نقاط، المجموع دائماً ≈ 3.5).
     * @returns {{ gold: number, iron: number, oil: number, total: number }}
     */
    getCountryResources(country) {
      if (!country) return { gold: 0, iron: 0, oil: 0, total: 0 };
      const r = this.countryResources.get(country);
      if (r) return { gold: r.gold, iron: r.iron, oil: r.oil, total: r.total };
      // fallback متوازن إن لم تُعرّف الدولة
      return { gold: 1.25, iron: 1.25, oil: 1.0, total: 3.5 };
    }

    /**
     * احتياطي الإقليم = احتياطي الدولة المالكة حالياً
     * (لاحقاً يمكن تقسيم النقاط على الأقاليم).
     */
    getRegionResources(regionKey) {
      const owner = this.getRegionOwner(regionKey);
      return this.getCountryResources(owner);
    }

    /** قائمة كل الدول التي لها بيانات موارد */
    listCountriesWithResources() {
      return [...this.countryResources.keys()].sort();
    }

    /** مالك إقليم حالياً */
    getRegionOwner(regionKey) {
      return this.owners.get(String(regionKey)) || null;
    }

    /**
     * اتصال بحري بين إقليمين.
     * @returns {{ connected: boolean, distance: number }}
     * distance = أقصر مسافة تقريبية (كم) بين حدود الإقليمين.
     * connected = true إذا لم يكونا متجاورين برياً وكلاهما ساحلي والمسافة ضمن حد معقول،
     *            أو دائماً تُرجع المسافة حتى لو غير ساحليين (connected=false).
     */
    getRegionsSeaConnection(keyA, keyB) {
      const a = String(keyA), b = String(keyB);
      if (a === b) return { connected: false, distance: 0 };
      if (this.areRegionsLandAdjacent(a, b)) {
        return { connected: false, distance: 0 };
      }
      const rA = this.regionByKey.get(a);
      const rB = this.regionByKey.get(b);
      if (!rA || !rB) return { connected: false, distance: Infinity };

      const distance = this._minBoundaryDistanceKm(rA, rB);
      const bothCoastal = this._coastal.has(a) && this._coastal.has(b);
      // حد تقريبي: مسطحات مائية إقليمية / بحر قريب
      const connected = bothCoastal && distance < 800;
      return { connected, distance: Math.round(distance * 10) / 10 };
    }

    /**
     * اتصال بحري بين دولتين (أقصر مسافة بين أي إقليمين مملوكين لهما).
     * @returns {{ connected: boolean, distance: number }}
     */
    getCountriesSeaConnection(countryA, countryB) {
      if (countryA === countryB) return { connected: false, distance: 0 };
      if (this.areCountriesLandAdjacent(countryA, countryB)) {
        return { connected: false, distance: 0 };
      }
      const regsA = this.getCountryRegions(countryA);
      const regsB = this.getCountryRegions(countryB);
      let best = Infinity;
      let connected = false;
      for (const ka of regsA) {
        for (const kb of regsB) {
          const s = this.getRegionsSeaConnection(ka, kb);
          if (s.distance < best) best = s.distance;
          if (s.connected) connected = true;
        }
      }
      if (!isFinite(best)) best = Infinity;
      return { connected, distance: Math.round(best * 10) / 10 };
    }

    /**
     * احتلال إقليم → ينتقل لمالك جديد.
     * يحدّث الجوار بين الدول ويزيل/ينشئ الحدود السياسية منطقياً.
     * @returns {{ ok: boolean, from: string, to: string, regionKey: string }}
     */
    /**
     * ضم إقليم: يخرج من حدود الدولة المفعولة ويدخل حدود الفاعلة.
     * يعيد بناء هندسة الحدود (إزالة/إنشاء حدود دولية).
     */
    /**
     * ضم إقليم واحد. لإجراء كثيرة استخدم occupyRegions (إعادة بناء مرة واحدة).
     */
    occupyRegion(regionKey, newOwnerCountry) {
      return this.occupyRegions([regionKey], newOwnerCountry);
    }

    /**
     * ضم عدة أقاليم دفعة واحدة — rebuild واحد فقط (لا يجمد اللعبة).
     */
    /**
     * After any ownership change: adjacency, borders, coastal ownership,
     * country existence, island flags — all engine queries stay consistent.
     */
    _afterOwnershipChange() {
      this._collectKey = null;
      this._collectCacheKey = '';
      try { this._rebuildCountryAdjacency(); } catch (e) { console.warn('[Map] adj', e); }
      try { this._rebuildPoliticalGeometry(); } catch (e) { console.warn('[Map] pol', e); }
      try { this._refreshOccupationFlag(); } catch (_) {}
      // Re-apply island hide so hidden flags stay correct for border topology
      if (this.hideSmallIslands) {
        try {
          if (this.regions) {
            for (let i = 0; i < this.regions.length; i++) {
              const r = this.regions[i];
              if (!r) continue;
              r._hiddenSmallIsland = !!this.isRegionSmallIsland(r.key);
            }
          }
        } catch (_) {}
      }
      this.setDirty();
    }

    occupyRegions(regionKeys, newOwnerCountry) {
      if (!newOwnerCountry || !regionKeys || !regionKeys.length) {
        return { ok: false, moved: [] };
      }
      const moved = [];
      for (let i = 0; i < regionKeys.length; i++) {
        const key = String(regionKeys[i]);
        const r = this.regionByKey.get(key);
        if (!r) continue;
        const from = this.owners.get(key);
        if (from === newOwnerCountry) continue;
        const to = this.resolveCountryName(newOwnerCountry) || newOwnerCountry;
        this.owners.set(key, to);
        moved.push(key);
      }
      if (!moved.length) return { ok: true, moved: [], to: newOwnerCountry };
      this._occupationActive = true;
      this._afterOwnershipChange();
      return { ok: true, moved, to: newOwnerCountry };
    }

    /** Only regions whose owner ≠ original country (compact save) */
    exportOccupation() {
      const out = {};
      if (!this.owners || !this.regions) return out;
      // Fast path: no occupation layer
      if (!this._occupationActive) return out;
      for (const r of this.regions) {
        const o = this.owners.get(r.key);
        if (o && o !== r.country) out[String(r.key)] = o;
      }
      return out;
    }

    /** Restore after load — does not freeze (single rebuild) */
    importOccupation(map) {
      if (!map || typeof map !== 'object' || !this.owners) return 0;
      let n = 0;
      Object.keys(map).forEach(function (k) {
        const key = String(k);
        if (!this.regionByKey.get(key)) return;
        const owner = map[k];
        if (!owner) return;
        this.owners.set(key, this.resolveCountryName(owner) || owner);
        n++;
      }.bind(this));
      if (n > 0) {
        this._occupationActive = true;
        this._afterOwnershipChange();
      } else {
        this._refreshOccupationFlag();
      }
      return n;
    }

    /** True if every region is owned by country */
    isWorldOwnedBy(country) {
      if (!country || !this.owners || !this.regions || !this.regions.length) return false;
      for (const r of this.regions) {
        if (this.owners.get(r.key) !== country) return false;
      }
      return true;
    }

    occupyCountry(targetCountry, newOwnerCountry) {
      if (!targetCountry || !newOwnerCountry || targetCountry === newOwnerCountry) {
        return { ok: false, moved: [] };
      }
      const keys = [];
      for (const r of this.regions) {
        const owner = this.owners.get(r.key);
        if (owner === targetCountry || r.country === targetCountry) {
          if (owner !== newOwnerCountry) keys.push(r.key);
        }
      }
      if (!keys.length) return { ok: false, moved: [] };
      const res = this.occupyRegions(keys, newOwnerCountry);
      return { ok: res.ok, moved: res.moved, from: targetCountry, to: newOwnerCountry };
    }

    /**
     * ضم عدة دول دفعة واحدة (مثل الوطن العربي) — rebuild واحد في النهاية.
     */
    occupyCountries(targetCountries, newOwnerCountry) {
      if (!newOwnerCountry || !targetCountries || !targetCountries.length) {
        return { ok: false, moved: [] };
      }
      const keys = [];
      const targets = new Set(targetCountries);
      targets.delete(newOwnerCountry);
      for (const r of this.regions) {
        const owner = this.owners.get(r.key);
        if (targets.has(owner) || targets.has(r.country)) {
          if (owner !== newOwnerCountry) keys.push(r.key);
        }
      }
      return this.occupyRegions(keys, newOwnerCountry);
    }

    liberateRegion(regionKey) {
      const key = String(regionKey);
      const r = this.regionByKey.get(key);
      if (!r) return { ok: false };
      const from = this.owners.get(key);
      const to = r.country;
      this.owners.set(key, to);
      this._afterOwnershipChange();
      return { ok: true, from, to, regionKey: key };
    }

    /** occupationActive only while at least one region owner ≠ original country */
    _refreshOccupationFlag() {
      let active = false;
      if (this.regions) {
        for (const r of this.regions) {
          if (this.owners.get(r.key) !== r.country) { active = true; break; }
        }
      }
      this._occupationActive = active;
    }

    /** هل الدولة ما زالت تملك إقليماً واحداً على الأقل؟ */
    countryExists(country) {
      if (!country || !this.owners) return false;
      for (const owner of this.owners.values()) {
        if (owner === country) return true;
      }
      return false;
    }

    /**
     * هل يمكن لجيش أن ينتقل برياً من إقليم إلى آخر؟
     * - نفس المالك + متجاوران برياً → true
     * - مالك مختلف + متجاوران → true (هجوم/دخول حدودي)
     */
    canMoveLand(fromRegionKey, toRegionKey) {
      return this.areRegionsLandAdjacent(fromRegionKey, toRegionKey);
    }

    /** قائمة الأقاليم التي يمكن لجيش في fromKey الوصول لها برياً مباشرة */
    getLandMoveTargets(fromRegionKey) {
      return this.getRegionLandNeighbors(fromRegionKey);
    }

    /** تصدير لقطة سياسية سريعة للتصحيح */
    dumpPolitics(country) {
      const regions = this.getCountryRegions(country);
      return {
        country,
        regionCount: regions.length,
        landNeighbors: this.getCountryLandNeighbors(country),
        regions: regions.map(k => {
          const r = this.regionByKey.get(k);
          return { key: k, name: r && r.name, owner: this.owners.get(k) };
        })
      };
    }
  }

  global.MapEngine = MapEngine;
})(window);
