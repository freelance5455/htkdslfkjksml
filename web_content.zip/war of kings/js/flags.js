/**
 * War of Kings — Flags stub (PER build)
 * Country flag images removed for performance / package size.
 * Map engine no longer draws flags.
 */
(function (global) {
  'use strict';
  const API = {
    get: function () { return null; },
    getIso: function () { return null; },
    isCrossBlocked: function () { return false; },
    list: function () { return []; },
    enabled: false
  };
  global.WOK_FLAGS = API;
})(typeof window !== 'undefined' ? window : globalThis);
