/**
 * regions-cache.js — PER-1.4.3
 * Cache simplified regions after first parse (IndexedDB + Cache API)
 * Network path prefers map Web Worker for JSON.parse off the main thread.
 */
(function (global) {
  'use strict';

  var CACHE_NAME = 'wok-regions-v143';
  var IDB_NAME = 'wok_regions_db';
  var IDB_STORE = 'json';
  var IDB_KEY = 'regions_simplified_v143';
  var REGIONS_URL = 'data/regions.json';

  var _worker = null;
  var _workerFailed = false;
  var _seq = 1;
  var _pending = Object.create(null);

  function getMapWorker() {
    if (_workerFailed) return null;
    if (_worker) return _worker;
    try {
      _worker = new Worker('js/workers/map-loader.worker.js');
      _worker.onmessage = function (ev) {
        var msg = ev.data || {};
        var slot = _pending[msg.requestId];
        if (!slot) return;
        delete _pending[msg.requestId];
        if (msg.type === 'ok') slot.resolve(msg.data);
        else slot.reject(new Error(msg.message || 'worker error'));
      };
      _worker.onerror = function () {
        _workerFailed = true;
        try { _worker.terminate(); } catch (_) {}
        _worker = null;
        Object.keys(_pending).forEach(function (k) {
          try { _pending[k].reject(new Error('worker failed')); } catch (_) {}
          delete _pending[k];
        });
      };
      return _worker;
    } catch (e) {
      _workerFailed = true;
      return null;
    }
  }

  function loadRegionsViaWorker(url) {
    return new Promise(function (resolve, reject) {
      var w = getMapWorker();
      if (!w) return reject(new Error('no worker'));
      var id = _seq++;
      _pending[id] = { resolve: resolve, reject: reject };
      try {
        w.postMessage({ type: 'loadRegions', requestId: id, url: url });
      } catch (e) {
        delete _pending[id];
        reject(e);
      }
    });
  }

  function idbOpen() {
    return new Promise(function (resolve, reject) {
      if (!global.indexedDB) return reject(new Error('no idb'));
      var req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = function () {
        var db = req.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error || new Error('idb open')); };
    });
  }

  function idbGet() {
    return idbOpen().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(IDB_STORE, 'readonly');
        var st = tx.objectStore(IDB_STORE);
        var g = st.get(IDB_KEY);
        g.onsuccess = function () { resolve(g.result || null); };
        g.onerror = function () { reject(g.error); };
      });
    });
  }

  function idbPut(data) {
    return idbOpen().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(IDB_STORE, 'readwrite');
        var st = tx.objectStore(IDB_STORE);
        var p = st.put(data, IDB_KEY);
        p.onsuccess = function () { resolve(true); };
        p.onerror = function () { reject(p.error); };
      });
    });
  }

  async function cacheApiGet(url) {
    if (!global.caches) return null;
    try {
      var cache = await caches.open(CACHE_NAME);
      var res = await cache.match(url);
      if (res && res.ok) return res.json();
    } catch (_) {}
    return null;
  }

  async function cacheApiPut(url, data) {
    if (!global.caches) return false;
    try {
      var cache = await caches.open(CACHE_NAME);
      var body = JSON.stringify(data);
      var res = new Response(body, {
        headers: { 'Content-Type': 'application/json', 'X-WOK-Cached': '1' }
      });
      await cache.put(url, res);
      return true;
    } catch (_) { return false; }
  }

  async function loadRegionsCached(url) {
    url = url || REGIONS_URL;

    try {
      var fromIdb = await idbGet();
      if (fromIdb && fromIdb.regions && fromIdb.regions.length) {
        try { console.log('[RegionsCache] hit IndexedDB', fromIdb.regions.length); } catch (_) {}
        return fromIdb;
      }
    } catch (_) {}

    try {
      var fromCache = await cacheApiGet(url);
      if (fromCache && fromCache.regions && fromCache.regions.length) {
        try { console.log('[RegionsCache] hit Cache API'); } catch (_) {}
        try { await idbPut(fromCache); } catch (_) {}
        return fromCache;
      }
    } catch (_) {}

    var data = null;
    try {
      data = await loadRegionsViaWorker(url);
      try { console.log('[RegionsCache] worker load', (data.regions && data.regions.length) || 0); } catch (_) {}
    } catch (we) {
      try { console.warn('[RegionsCache] worker miss', we && we.message); } catch (_) {}
      var res = await fetch(url);
      if (!res.ok) throw new Error('regions fetch ' + res.status);
      data = await res.json();
      try { console.log('[RegionsCache] network load', (data.regions && data.regions.length) || 0); } catch (_) {}
    }

    Promise.resolve().then(function () { return idbPut(data); }).catch(function () {});
    Promise.resolve().then(function () { return cacheApiPut(url, data); }).catch(function () {});
    return data;
  }

  global.WOK_RegionsCache = {
    load: loadRegionsCached,
    CACHE_NAME: CACHE_NAME,
    IDB_KEY: IDB_KEY,
    workerAvailable: function () { return !!getMapWorker() && !_workerFailed; }
  };
})(typeof window !== 'undefined' ? window : this);
