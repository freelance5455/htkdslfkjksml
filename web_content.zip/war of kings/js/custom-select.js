/**
 * War of Kings — Custom animated dropdown for select.glass-select
 * Click opens with slide; click again / outside closes.
 */
(function (global) {
  'use strict';

  const STYLE_ID = 'wok-custom-select-style';

  
  function clampMenu(wrap) {
    const menu = wrap.querySelector('.wok-cs-menu');
    if (!menu) return;
    menu.style.top = '';
    menu.style.bottom = '';
    menu.style.maxHeight = '220px';
    const rect = menu.getBoundingClientRect();
    const vh = window.innerHeight || document.documentElement.clientHeight;
    if (rect.bottom > vh - 8) {
      const roomBelow = vh - wrap.getBoundingClientRect().bottom - 12;
      if (roomBelow < 120) {
        menu.style.top = 'auto';
        menu.style.bottom = 'calc(100% + 4px)';
        menu.style.maxHeight = Math.max(100, Math.min(220, wrap.getBoundingClientRect().top - 12)) + 'px';
      } else {
        menu.style.maxHeight = Math.max(100, Math.min(220, roomBelow)) + 'px';
      }
    }
    // Horizontal clamp
    const r2 = menu.getBoundingClientRect();
    if (r2.left < 4) menu.style.transform = 'translateX(' + (4 - r2.left) + 'px)';
    else if (r2.right > (window.innerWidth || 0) - 4)
      menu.style.transform = 'translateX(' + ((window.innerWidth - 4) - r2.right) + 'px)';
    else menu.style.transform = '';
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = `
      .wok-cs { position: relative; width: 100%; }
      .wok-cs-btn {
        width: 100%;
        display: flex; align-items: center; justify-content: space-between; gap: 8px;
        background: rgba(0,0,0,.42);
        color: #e8f2ff;
        border: 1px solid rgba(90,170,255,.45);
        border-radius: 10px;
        padding: 11px 14px;
        font-size: 14px; font-weight: 600; font-family: inherit;
        cursor: pointer; text-align: inherit;
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        transition: border-color .15s, background .15s;
      }
      .wok-cs-btn:hover { border-color: rgba(130,200,255,.85); background: rgba(0,0,0,.52); }
      .wok-cs.open .wok-cs-btn { border-color: rgba(130,200,255,.9); }
      .wok-cs-label {
        flex: 1; min-width: 0;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
      }
      .wok-cs-caret {
        width: 10px; height: 10px; flex-shrink: 0;
        border-right: 2px solid #9fd0ff;
        border-bottom: 2px solid #9fd0ff;
        transform: rotate(45deg);
        margin-top: -4px;
        transition: transform .2s ease;
      }
      .wok-cs.open .wok-cs-caret {
        transform: rotate(-135deg);
        margin-top: 4px;
      }
      .wok-cs-menu {
        position: absolute; left: 0; right: 0; top: calc(100% + 4px);
        z-index: 80;
        background: rgba(8,16,28,.96);
        border: 1px solid rgba(90,170,255,.5);
        border-radius: 12px;
        box-shadow: 0 12px 32px rgba(0,0,0,.5);
        overflow: hidden;
        max-height: 0;
        opacity: 0;
        pointer-events: none;
        transition: max-height .28s ease, opacity .2s ease;
      }
      .wok-cs.open .wok-cs-menu {
        max-height: 220px;
        opacity: 1;
        pointer-events: auto;
        overflow-y: auto;
      }
      .wok-cs-opt {
        display: block; width: 100%;
        background: transparent; border: 0;
        color: #d8ecff;
        padding: 12px 14px;
        font-size: 14px; font-weight: 600; font-family: inherit;
        text-align: inherit; cursor: pointer;
        transition: background .12s;
      }
      .wok-cs-opt:hover { background: rgba(40,100,170,.35); }
      .wok-cs-opt.active {
        background: rgba(30,90,160,.45);
        color: #fff;
      }
      select.glass-select.wok-cs-native {
        position: absolute !important;
        width: 1px !important; height: 1px !important;
        opacity: 0 !important; pointer-events: none !important;
        left: -9999px !important;
      }
    `;
    document.head.appendChild(s);
  }

  function closeAll(except) {
    document.querySelectorAll('.wok-cs.open').forEach(function (el) {
      if (except && el === except) return;
      el.classList.remove('open');
    });
  }

  function enhanceSelect(sel) {
    if (!sel || sel.tagName !== 'SELECT') return;
    if (sel.dataset.wokCs === '1') return;
    sel.dataset.wokCs = '1';
    sel.classList.add('wok-cs-native');

    const wrap = document.createElement('div');
    wrap.className = 'wok-cs';
    sel.parentNode.insertBefore(wrap, sel);
    wrap.appendChild(sel);

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'wok-cs-btn';
    const label = document.createElement('span');
    label.className = 'wok-cs-label';
    const caret = document.createElement('span');
    caret.className = 'wok-cs-caret';
    btn.appendChild(label);
    btn.appendChild(caret);

    const menu = document.createElement('div');
    menu.className = 'wok-cs-menu';

    wrap.appendChild(btn);
    wrap.appendChild(menu);

    function selectedText() {
      const opt = sel.options[sel.selectedIndex];
      return opt ? opt.textContent : '';
    }

    function rebuild() {
      label.textContent = selectedText();
      menu.innerHTML = '';
      for (let i = 0; i < sel.options.length; i++) {
        const opt = sel.options[i];
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'wok-cs-opt' + (i === sel.selectedIndex ? ' active' : '');
        b.textContent = opt.textContent;
        b.dataset.value = opt.value;
        b.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          sel.value = opt.value;
          sel.dispatchEvent(new Event('change', { bubbles: true }));
          label.textContent = opt.textContent;
          wrap.classList.remove('open');
          rebuild();
        });
        menu.appendChild(b);
      }
    }

    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      const willOpen = !wrap.classList.contains('open');
      closeAll(wrap);
      wrap.classList.toggle('open', willOpen);
    });

    sel.addEventListener('change', function () {
      label.textContent = selectedText();
      rebuild();
    });

    // observe option list mutations (dynamic trade items)
    const mo = new MutationObserver(function () { rebuild(); });
    mo.observe(sel, { childList: true, subtree: true, characterData: true });

    rebuild();
  }

  function enhanceAll(root) {
    injectStyles();
    const scope = root || document;
    scope.querySelectorAll('select.glass-select').forEach(enhanceSelect);
  }

  document.addEventListener('click', function (e) {
    if (!e.target.closest('.wok-cs')) closeAll();
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { enhanceAll(document); });
  } else {
    enhanceAll(document);
  }

  global.WOK_CustomSelect = {
    enhance: enhanceSelect,
    enhanceAll: enhanceAll,
    closeAll: closeAll
  };
})(typeof window !== 'undefined' ? window : globalThis);
