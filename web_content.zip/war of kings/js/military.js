/**
 * War of Kings — Military core
 * Timings in game-days (10 real seconds = 1 game day).
 * Land move 10d · reinforce same as normal move · battle pulse 10d · hold 360d.
 */
(function (global) {
  'use strict';

  const MS_PER_GAME_DAY = 10000;
  const LAND_MOVE_DAYS = 10;
  const REINFORCE_BATTLE_DAYS = 10; // same base as land; sea still scales by distance
  const BATTLE_PULSE_DAYS = 10;
  const OCCUPY_HOLD_DAYS = 360;
  const OIL_ID = 'WOK:ECONOMY.MATERIAL.OIL.BARREL';

  function now() { return Date.now(); }
  function daysMs(d) { return d * MS_PER_GAME_DAY; }

  function ensureMilitary(world) {
    if (!world.game) world.game = {};
    const g = world.game;
    if (!g.researchDone || typeof g.researchDone !== 'object') g.researchDone = {};
    // Recruit is always owned (founding doctrine)
    g.researchDone['WOK:RESEARCH.MILITARY.RECRUIT'] = true;
    if (!g.researchQueue) g.researchQueue = {};
    if (!g.package) g.package = {};
    if (!g.trainQueue) g.trainQueue = {};
    if (!g.regionArmies) g.regionArmies = {};
    if (!g.regionSoldiers) g.regionSoldiers = {};
    if (!g.regionBarracks) g.regionBarracks = {}; // fixed barracks count per region
    if (!g.moves) g.moves = [];
    if (!g.battles) g.battles = [];
    // soldiers belong only in regionSoldiers — never as army unit rows
    try { migrateSoldiersOutOfArmy(g); } catch (_) {}
    if (!g.threats) g.threats = [];
    if (!g.relations) g.relations = {}; // country -> score (bad after attack)
    return g;
  }

  const BARRACKS_ID = 'WOK:MILITARY.UNIT.LAND.INFANTRY';

  function isFixedUnit(unitId) {
    // Barracks / infantry card = fixed structure, not a movable unit
    return unitId === BARRACKS_ID;
  }

  function soldierPower(n) {
    // 1000 soldiers ≈ 1 barracks worth of power (10)
    return (Number(n) || 0) * 0.01;
  }

  function forcePower(units) {
    // units: { soldiers?: n, unitId?: count }
    let p = soldierPower(units && units.soldiers);
    if (!units) return p;
    Object.keys(units).forEach(function (id) {
      if (id === 'soldiers' || isFixedUnit(id)) return;
      const unit = global.WOK.getUnit(id);
      const n = units[id] || 0;
      p += (Number(unit && unit.power) || 10) * n;
    });
    return p;
  }

  function splitThree(total) {
    total = Math.max(0, Math.floor(total || 0));
    const a = Math.floor(total / 3);
    const b = Math.floor(total / 3);
    const c = total - a - b;
    return [a, b, c];
  }

  function splitForce(units) {
    // Split each stack into 3 waves (integer)
    const waves = [{}, {}, {}];
    const sol = splitThree(units.soldiers || 0);
    for (let i = 0; i < 3; i++) if (sol[i] > 0) waves[i].soldiers = sol[i];
    Object.keys(units || {}).forEach(function (id) {
      if (id === 'soldiers' || isFixedUnit(id)) return;
      const parts = splitThree(units[id] || 0);
      for (let i = 0; i < 3; i++) if (parts[i] > 0) waves[i][id] = parts[i];
    });
    return waves;
  }

  function mergeForce(into, from) {
    if (!from) return into;
    into.soldiers = (into.soldiers || 0) + (from.soldiers || 0);
    Object.keys(from).forEach(function (id) {
      if (id === 'soldiers') return;
      into[id] = (into[id] || 0) + (from[id] || 0);
    });
    return into;
  }

  function redistributeRemain(waves, fromIdx) {
    // After wave fromIdx resolves, push remaining power evenly into later waves
    const left = waves[fromIdx] || {};
    waves[fromIdx] = {};
    const later = [];
    for (let i = fromIdx + 1; i < 3; i++) later.push(i);
    if (!later.length) {
      waves[fromIdx] = left;
      return;
    }
    // naive: put all remaining into next wave
    const next = later[0];
    waves[next] = mergeForce(waves[next] || {}, left);
  }


  function unitIcon(unit) {
    if (!unit) return '';
    const rel = unit.icon || unit.texture || '';
    if (!rel) return '';
    if (rel.indexOf('units/') === 0 || rel.indexOf('/') === 0) return rel;
    return 'units/' + rel;
  }

  function domainOf(unit) {
    if (!unit) return 'land';
    if (unit === 'soldiers' || (unit && unit.id === 'soldiers')) return 'land';
    return unit.domain || (unit.movement && unit.movement.type) || 'land';
  }

  function isUnlocked(world, unitId) {
    const g = ensureMilitary(world);
    if (unitId === BARRACKS_ID || unitId === 'WOK:MILITARY.UNIT.LAND.INFANTRY') return true;

    function researchUnlocks(r) {
      return !!(r && r.unlocksUnits && r.unlocksUnits.indexOf(unitId) >= 0 &&
        (r.unlockedByDefault || g.researchDone[r.identifier]));
    }

    // Primary: military research list
    let list = (global.WOK && global.WOK.listResearchMilitary) ? global.WOK.listResearchMilitary() : [];
    if (!list.length && global.WOK_RESEARCH && global.WOK_RESEARCH.list) list = global.WOK_RESEARCH.list;
    for (let i = 0; i < list.length; i++) {
      if (researchUnlocks(list[i])) return true;
    }

    // Fallback: scan completed research by id (survives empty list / load race)
    const getR = global.WOK && global.WOK.getResearch
      ? global.WOK.getResearch.bind(global.WOK)
      : (global.WOK_RESEARCH && global.WOK_RESEARCH.get)
        ? global.WOK_RESEARCH.get.bind(global.WOK_RESEARCH)
        : null;
    if (getR && g.researchDone) {
      const ids = Object.keys(g.researchDone);
      for (let i = 0; i < ids.length; i++) {
        if (!g.researchDone[ids[i]]) continue;
        if (researchUnlocks(getR(ids[i]))) return true;
      }
    }
    return false;
  }

  function canStartResearch(world, researchId) {
    const g = ensureMilitary(world);
    if (g.researchDone[researchId]) return false;
    if (g.researchQueue[researchId]) return false;
    const r = global.WOK && global.WOK.getResearch ? global.WOK.getResearch(researchId) : null;
    if (!r) return false;
    const req = r.requires || [];
    for (let i = 0; i < req.length; i++) if (!g.researchDone[req[i]]) return false;
    const all = r.requiresAll || [];
    for (let i = 0; i < all.length; i++) if (!g.researchDone[all[i]]) return false;
    return true;
  }

  function startResearch(world, researchId, getStock, setStock) {
    const r = global.WOK && global.WOK.getResearch ? global.WOK.getResearch(researchId) : null;
    if (!r || !canStartResearch(world, researchId)) return false;
    const cost = r.cost || {};
    for (const id of Object.keys(cost)) {
      if (getStock(id) < Number(cost[id])) return false;
    }
    Object.keys(cost).forEach(function (id) {
      setStock(id, getStock(id) - Number(cost[id]));
    });
    const g = ensureMilitary(world);
    const days = Number(r.researchTimeGameDays) || 0;
    g.researchQueue[researchId] = { startedAt: now(), endsAt: now() + daysMs(days) };
    return true;
  }

  function tickResearch(world) {
    const g = ensureMilitary(world);
    const t = now();
    Object.keys(g.researchQueue).forEach(function (id) {
      const job = g.researchQueue[id];
      if (job && job.endsAt <= t) {
        g.researchDone[id] = true;
        delete g.researchQueue[id];
        try { console.log('[Military] research complete', id); } catch (_) {}
      }
    });
  }

  function addToPackage(world, unitId, qty) {
    const g = ensureMilitary(world);
    if (!isUnlocked(world, unitId)) return false;
    qty = Math.max(1, Math.floor(qty || 1));
    g.package[unitId] = (g.package[unitId] || 0) + qty;
    return true;
  }

  function trainJobKey(regionKey, unitId) {
    return String(regionKey) + '|' + String(unitId);
  }

  function migrateTrainQueue(g) {
    // Old format: trainQueue[unitId] = { remaining, regionKey, ... }
    // New format: trainQueue[regionKey|unitId] = { unitId, regionKey, remaining, ... }
    if (!g.trainQueue) g.trainQueue = {};
    const keys = Object.keys(g.trainQueue);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      const job = g.trainQueue[k];
      if (!job) continue;
      if (job.unitId && job.regionKey != null && String(k).indexOf('|') >= 0) continue;
      // legacy entry keyed by unit id only
      const unitId = job.unitId || k;
      const regionKey = job.regionKey != null ? String(job.regionKey) : '0';
      const nk = trainJobKey(regionKey, unitId);
      if (nk === k && job.unitId) continue;
      const existing = g.trainQueue[nk];
      if (existing && existing !== job) {
        existing.remaining = (existing.remaining || 0) + (job.remaining || 0);
      } else if (!existing) {
        g.trainQueue[nk] = {
          unitId: unitId,
          regionKey: regionKey,
          remaining: job.remaining || 0,
          startedAt: job.startedAt || now(),
          endsAt: job.endsAt || null
        };
      }
      if (nk !== k) delete g.trainQueue[k];
    }
  }

  function startTrainFromPackage(world, regionKey, getStock, setStock) {
    const g = ensureMilitary(world);
    migrateTrainQueue(g);
    regionKey = String(regionKey);
    const pkg = g.package || {};
    const ids = Object.keys(pkg).filter(function (id) { return pkg[id] > 0; });
    if (!ids.length) return { ok: false, reason: 'empty' };
    for (let i = 0; i < ids.length; i++) {
      const unit = global.WOK.getUnit(ids[i]);
      if (!unit) return { ok: false, reason: 'bad_unit' };
      const qty = Math.max(0, Math.floor(Number(pkg[ids[i]]) || 0));
      if (qty <= 0) continue;
      const cost = unit.cost || {};
      for (const res of Object.keys(cost)) {
        if (getStock(res) < Number(cost[res]) * qty) return { ok: false, reason: 'no_funds' };
      }
    }
    ids.forEach(function (id) {
      const unit = global.WOK.getUnit(id);
      const qty = Math.max(0, Math.floor(Number(pkg[id]) || 0));
      if (!unit || qty <= 0) return;
      const cost = unit.cost || {};
      Object.keys(cost).forEach(function (res) {
        setStock(res, getStock(res) - Number(cost[res]) * qty);
      });
      const mins = Number(unit.trainTimeMinutes || unit.buildTimeMinutes) || 5;
      const ms = mins * 60 * 1000;
      const key = trainJobKey(regionKey, id);
      let job = g.trainQueue[key];
      // Same unit + same region → queue. Never let a past endsAt mass-complete a stacked qty.
      if (job && job.remaining > 0) {
        job.remaining += qty;
        if (!job.endsAt || job.endsAt <= now()) {
          job.startedAt = now();
          job.endsAt = now() + ms;
        }
      } else {
        g.trainQueue[key] = {
          unitId: id,
          regionKey: regionKey,
          remaining: qty,
          startedAt: now(),
          endsAt: now() + ms
        };
      }
    });
    g.package = {};
    return { ok: true };
  }

  function removeFromPackage(world, unitId, qty) {
    const g = ensureMilitary(world);
    if (!g.package || !unitId) return false;
    if (qty == null || qty >= g.package[unitId]) delete g.package[unitId];
    else g.package[unitId] = Math.max(0, (g.package[unitId] || 0) - qty);
    if (g.package[unitId] === 0) delete g.package[unitId];
    return true;
  }

  function ensureRegionArmy(g, key) {
    key = String(key);
    if (!g.regionArmies[key]) g.regionArmies[key] = {};
    return g.regionArmies[key];
  }

  function tryActivateUnits(g, regionKey, unitId) {
    const unit = global.WOK.getUnit(unitId);
    if (!unit) return;
    const need = Number(unit.soldiersPerUnit) || 0;
    const army = ensureRegionArmy(g, regionKey);
    const slot = army[unitId];
    if (!slot) return;
    if (need <= 0) { slot.active = slot.count; return; }
    let surplus = g.regionSoldiers[regionKey] || 0;
    const inactive = slot.count - (slot.active || 0);
    const can = Math.min(inactive, Math.floor(surplus / need));
    if (can > 0) {
      slot.active = (slot.active || 0) + can;
      g.regionSoldiers[regionKey] = surplus - can * need;
    }
  }

  function tickTrain(world) {
    const g = ensureMilitary(world);
    migrateTrainQueue(g);
    const t = now();
    Object.keys(g.trainQueue).forEach(function (key) {
      const job = g.trainQueue[key];
      if (!job || job.remaining <= 0) { delete g.trainQueue[key]; return; }
      const unitId = job.unitId || key;
      const regionKey = String(job.regionKey != null ? job.regionKey : '0');
      const unit = global.WOK.getUnit(unitId);
      const mins = Number(unit && (unit.trainTimeMinutes || unit.buildTimeMinutes)) || 5;
      const ms = mins * 60 * 1000;
      if (!job.endsAt) job.endsAt = (job.startedAt || t) + ms;
      let guard = 0;
      while (job.remaining > 0 && job.endsAt <= t && guard < 5000) {
        guard++;
        if (isFixedUnit(unitId)) {
          // Barracks: fixed structure + 1000 soldiers (soldiers are the mobile force)
          g.regionBarracks[regionKey] = (g.regionBarracks[regionKey] || 0) + 1;
          g.regionSoldiers[regionKey] = (g.regionSoldiers[regionKey] || 0) + (Number(unit && unit.soldiersPerUnit) || 1000);
        } else {
          const army = ensureRegionArmy(g, regionKey);
          if (!army[unitId]) army[unitId] = { count: 0, active: 0 };
          army[unitId].count += 1;
          tryActivateUnits(g, regionKey, unitId);
        }
        job.remaining -= 1;
        if (job.remaining > 0) { job.startedAt = job.endsAt; job.endsAt = job.startedAt + ms; }
      }
      if (job.remaining <= 0) delete g.trainQueue[key];
    });
  }

  function powerOfArmy(armyMap) {
    let p = 0;
    if (!armyMap) return 0;
    Object.keys(armyMap).forEach(function (id) {
      const unit = global.WOK.getUnit(id);
      const slot = armyMap[id];
      if (!unit || !slot) return;
      const n = slot.active != null ? slot.active : slot.count;
      p += (Number(unit.power) || 0) * Math.max(0, n);
    });
    return p;
  }

  function powerOfUnitMap(units) {
    let p = 0;
    if (!units) return 0;
    Object.keys(units).forEach(function (id) {
      const unit = global.WOK.getUnit(id);
      const n = units[id] || 0;
      p += (Number(unit && unit.power) || 10) * n;
    });
    return p;
  }

  function regionsLandLinked(engine, a, b) {
    if (!engine) return false;
    if (engine.areRegionsLandAdjacent) return engine.areRegionsLandAdjacent(String(a), String(b));
    if (!engine.getRegionLandNeighbors) return false;
    const n = engine.getRegionLandNeighbors(String(a)) || [];
    return n.map(String).indexOf(String(b)) >= 0;
  }

  function regionsStrictLandLinked(engine, a, b) {
    if (!engine) return false;
    if (engine.areRegionsStrictLandAdjacent) return engine.areRegionsStrictLandAdjacent(String(a), String(b));
    return regionsLandLinked(engine, a, b);
  }

  function regionsSeaLinked(engine, a, b) {
    if (!engine) return false;
    a = String(a); b = String(b);
    if (a === b) return false;
    if (engine.areRegionsLandAdjacent && engine.areRegionsLandAdjacent(a, b)) return false;
    // Fast: both coastal → sea route (avoids O(n²) boundary distance on attack UI)
    if (typeof engine.isRegionCoastal === 'function') {
      return !!(engine.isRegionCoastal(a) && engine.isRegionCoastal(b));
    }
    if (engine._coastal) return !!(engine._coastal.has(a) && engine._coastal.has(b));
    return false;
  }

  function oilPerUnit(unitId) {
    // Infantry soldiers: small per-head land fuel (was 0 because no unit JSON)
    if (unitId === 'soldiers') return 0.002;
    const unit = global.WOK.getUnit(unitId);
    if (!unit || !unit.oilConsumption) return 0;
    return Number(unit.oilConsumption[OIL_ID] || 0);
  }

  function unitWeight(unitId) {
    const unit = global.WOK.getUnit(unitId);
    return Number(unit && unit.weight) || 1;
  }

  function seaDistanceFactor(engine, a, b) {
    // Cheap estimate from region bbox centers — never scan full borders (UI freezes)
    try {
      if (!engine || !engine.regionByKey) return 1.5;
      const rA = engine.regionByKey.get(String(a));
      const rB = engine.regionByKey.get(String(b));
      if (!rA || !rB || !rA.bbox || !rB.bbox) return 1.5;
      const lon1 = (rA.bbox.minX + rA.bbox.maxX) * 0.5;
      const lat1 = (rA.bbox.minY + rA.bbox.maxY) * 0.5;
      const lon2 = (rB.bbox.minX + rB.bbox.maxX) * 0.5;
      const lat2 = (rB.bbox.minY + rB.bbox.maxY) * 0.5;
      const dx = (lon1 - lon2) * 111;
      const dy = (lat1 - lat2) * 111;
      const km = Math.sqrt(dx * dx + dy * dy);
      return Math.max(1, Math.min(3, km / 500));
    } catch (_) {
      return 1.5;
    }
  }

  function estimateOil(engine, fromKey, toKey, moving, sea) {
    let oil = 0;
    const dist = sea ? seaDistanceFactor(engine, fromKey, toKey) : 1;
    let cargoWeight = 0;
    Object.keys(moving).forEach(function (id) {
      const n = Math.floor(Number(moving[id]) || 0);
      if (n <= 0) return;
      if (id === 'soldiers') {
        // 0.002 oil / soldier land; sea transport higher
        oil += n * (sea ? 0.008 * dist : 0.002);
        cargoWeight += n * 0.001;
        return;
      }
      const d = domainOf(global.WOK.getUnit(id));
      if (sea) {
        if (d === 'sea') oil += oilPerUnit(id) * n * dist;
        else {
          cargoWeight += unitWeight(id) * n;
          oil += oilPerUnit(id) * n * 0.25 * dist;
        }
      } else {
        oil += oilPerUnit(id) * n;
      }
    });
    if (sea && cargoWeight > 0) oil += cargoWeight * 0.15 * dist;
    return Math.ceil(oil);
  }

  function validateMoveComposition(engine, fromKey, toKey, moving, land, sea) {
    if (!land && !sea) return 'not_connected';
    let hasLand = false, hasSea = false, hasAir = false;
    let cargoSlots = 0, shipSlots = 0;
    Object.keys(moving).forEach(function (id) {
      const n = moving[id];
      if (n <= 0) return;
      const unit = global.WOK.getUnit(id);
      const d = domainOf(unit);
      if (d === 'land') { hasLand = true; cargoSlots += n; }
      if (d === 'air') { hasAir = true; cargoSlots += n; }
      if (d === 'sea') {
        hasSea = true;
        if (unit && unit.transport) {
          shipSlots += (Number(unit.transport.capacity) || 0) * n;
          shipSlots += (Number(unit.transport.infantryCapacity) || 0) * n;
        }
      }
    });
    if (hasAir && !hasLand && !hasSea) return 'air_only';
    if (sea && !land && hasLand && shipSlots <= 0) return 'need_transport';
    if (land && !sea) {
      let onlySea = true;
      Object.keys(moving).forEach(function (id) {
        if (moving[id] > 0 && domainOf(global.WOK.getUnit(id)) !== 'sea') onlySea = false;
      });
      if (onlySea) return 'sea_on_land';
    }
    return null;
  }

  function findBattleAt(g, regionKey) {
    regionKey = String(regionKey);
    for (let i = 0; i < g.battles.length; i++) {
      const b = g.battles[i];
      if (String(b.region) === regionKey && (b.status === 'fighting' || b.status === 'holding')) return b;
    }
    return null;
  }

  function mergeUnits(into, from) {
    Object.keys(from).forEach(function (id) {
      into[id] = (into[id] || 0) + from[id];
    });
  }

  function startMove(world, engine, fromKey, toKey, ratios, getStock, setStock, playerCountry) {
    const g = ensureMilitary(world);
    fromKey = String(fromKey);
    toKey = String(toKey);
    const army = g.regionArmies[fromKey] || (g.regionArmies[fromKey] = {});
    // soldiers alone are enough to move (barracks are fixed)
    if (!army && !(g.regionSoldiers[fromKey] > 0)) return { ok: false, reason: 'no_army' };

    const land = regionsLandLinked(engine, fromKey, toKey);
    const sea = regionsSeaLinked(engine, fromKey, toKey);
    if (!land && !sea) return { ok: false, reason: 'not_connected' };

    // ratios may be { unitId: count } integers OR legacy 0..1 ratios
    const moving = {};
    let soldiersMove = 0;
    const availSoldiers = g.regionSoldiers[fromKey] || 0;
    Object.keys(ratios || {}).forEach(function (id) {
      if (id === 'soldiers') {
        soldiersMove = Math.max(0, Math.floor(Number(ratios[id]) || 0));
        return;
      }
      if (isFixedUnit(id)) return; // cannot move barracks
      let n = Math.floor(Number(ratios[id]) || 0);
      // legacy ratio support
      if (n > 0 && n <= 1 && String(ratios[id]).indexOf('.') >= 0) {
        const slot = army[id];
        n = Math.floor((slot && slot.count || 0) * n);
      }
      if (n <= 0) return;
      const unit = global.WOK.getUnit(id);
      if (!unit) return;
      const d = domainOf(unit);
      if (land && !sea && d === 'sea') return;
      const slot = army[id];
      if (!slot || !slot.count) return;
      n = Math.min(n, slot.count);
      if (n <= 0) return;
      moving[id] = n;
    });
    if (soldiersMove > 0) {
      soldiersMove = Math.min(soldiersMove, availSoldiers);
      if (soldiersMove > 0) moving.soldiers = soldiersMove;
    }
    // Crew check: vehicles need soldiers
    let crewNeed = 0;
    Object.keys(moving).forEach(function (id) {
      if (id === 'soldiers') return;
      const unit = global.WOK.getUnit(id);
      crewNeed += (Number(unit && unit.soldiersPerUnit) || 0) * moving[id];
    });
    const soldiersLeftAfter = (availSoldiers - (moving.soldiers || 0));
    // soldiers assigned to crew are still "with" the force; pure soldier stack is separate.
    // Require enough total soldiers in region to crew vehicles (crew drawn from region pool).
    if (crewNeed > availSoldiers) {
      return { ok: false, reason: 'no_crew', crewNeed: crewNeed, have: availSoldiers };
    }
    if (!Object.keys(moving).length) return { ok: false, reason: 'nothing' };

    const err = validateMoveComposition(engine, fromKey, toKey, moving, land, sea);
    if (err) return { ok: false, reason: err };

    const oilNeed = estimateOil(engine, fromKey, toKey, moving, sea && !land);
    if (oilNeed > 0 && getStock(OIL_ID) < oilNeed) return { ok: false, reason: 'no_oil', oilNeed: oilNeed };
    if (oilNeed > 0) setStock(OIL_ID, getStock(OIL_ID) - oilNeed);

    Object.keys(moving).forEach(function (id) {
      if (id === 'soldiers') {
        g.regionSoldiers[fromKey] = Math.max(0, (g.regionSoldiers[fromKey] || 0) - moving.soldiers);
        return;
      }
      const n = moving[id];
      army[id].count -= n;
      if (army[id].active) army[id].active = Math.min(army[id].active, army[id].count);
      if (army[id].count <= 0) delete army[id];
    });
    // Lock crew soldiers with vehicles (they leave the region with the force)
    if (crewNeed > 0) {
      const takeCrew = Math.min(crewNeed, g.regionSoldiers[fromKey] || 0);
      g.regionSoldiers[fromKey] = Math.max(0, (g.regionSoldiers[fromKey] || 0) - takeCrew);
      moving._crew = takeCrew;
    }

    // Reinforce uses the SAME travel time as a normal move (land 10d, sea by distance).
    // Previous 90d made mid-battle supply unusable.
    const existingBattle = findBattleAt(g, toKey);
    let moveDays = LAND_MOVE_DAYS;
    if (!land && sea) moveDays = Math.round(LAND_MOVE_DAYS * seaDistanceFactor(engine, fromKey, toKey));
    // Optional tiny logistics overhead when reinforcing an active fight (max +2 days)
    if (existingBattle) moveDays = Math.min(moveDays + 2, Math.max(moveDays, LAND_MOVE_DAYS + 2));

    const duration = daysMs(moveDays);
    const ownerTo = engine.getRegionOwner ? engine.getRegionOwner(toKey) : null;

    const destOwner = engine.getRegionOwner ? engine.getRegionOwner(toKey) : null;
    const friendlyMove = destOwner === playerCountry;
    g.moves.push({
      id: 'm_' + now() + '_' + Math.random().toString(36).slice(2, 7),
      from: fromKey,
      to: toKey,
      units: moving,
      startedAt: now(),
      endsAt: now() + duration,
      player: true,
      friendly: friendlyMove,
      sea: !!(sea && !land),
      oilSpent: oilNeed,
      reinforce: !!existingBattle
    });
    return {
      ok: true,
      duration: duration,
      days: moveDays,
      isFriendly: ownerTo === playerCountry,
      oilNeed: oilNeed,
      reinforce: !!existingBattle
    };
  }

  function emitPrivate(world, title, body, meta) {
    try {
      if (!world.game) world.game = {};
      if (!world.game.alertLog) world.game.alertLog = [];
      world.game.alertLog.unshift({ title: title, body: body, meta: meta || {}, at: Date.now() });
      if (world.game.alertLog.length > 100) world.game.alertLog.length = 100;
    } catch (_) {}

    if (global.WOK_News && global.WOK_News.addPrivate) {
      try { global.WOK_News.addPrivate(world, { title: title, body: body, meta: meta || {} }); } catch (_) {}
    }
  }

  function emitPublic(world, engine, attacker, defender, region, kind) {
    if (!global.WOK_News) return;
    try {
      if (kind === 'start') global.WOK_News.reportAttack(world, engine, attacker, defender, region, 'ar');
      else if (kind === 'win') global.WOK_News.onBattleWin(world, engine, attacker, defender, region, 'ar');
      else if (kind === 'lose') global.WOK_News.onBattleLose(world, engine, attacker, defender, region, 'ar');
      else if (kind === 'annex') global.WOK_News.onAnnex(world, engine, attacker, defender, region, 'ar');
    } catch (_) {}
  }

  function regionLabel(engine, regionKey) {
    const k = String(regionKey);
    try {
      if (engine && engine.regionByKey && engine.regionByKey.get) {
        const r = engine.regionByKey.get(k);
        if (r) {
          const n = r.displayName || r.name;
          if (n) return n;
        }
      }
    } catch (_) {}
    return 'إقليم ' + k;
  }

  function placeLabel(engine, regionKey) {
    return ' [' + regionLabel(engine, regionKey) + ']';
  }

  /** Start a 3-round battle (player or bot). Defenders taken from region stock. */
  function returnForceToRegion(g, regionKey, units) {
    if (!g || regionKey == null || !units) return;
    const rk = String(regionKey);
    const army = ensureRegionArmy(g, rk);
    Object.keys(units).forEach(function (id) {
      const n = Math.floor(units[id] || 0);
      if (n <= 0) return;
      if (id === 'soldiers' || id === '_crew') {
        g.regionSoldiers[rk] = (g.regionSoldiers[rk] || 0) + n;
        return;
      }
      if (isFixedUnit(id)) return;
      if (!army[id]) army[id] = { count: 0, active: 0 };
      army[id].count = (army[id].count || 0) + n;
    });
  }

  function beginBattle(world, engine, opts) {
    const g = ensureMilitary(world);
    const to = String(opts.to);
    const from = opts.from != null ? String(opts.from) : null;
    const attacker = opts.attacker;
    const defender = opts.defender;
    const units = opts.units || {};
    if (!attacker || !Object.keys(units).length) return null;

    // Existing battle → reinforce attacker side
    const existing = findBattleAt(g, to);
    if (existing && (existing.status === 'fighting' || existing.status === 'holding')) {
      if (existing.attacker === attacker) {
        mergeUnits(existing.units, units);
        const parts = splitForce(units);
        existing.atkWaves = existing.atkWaves || [{}, {}, {}];
        const start = existing.pulseCount || 0;
        for (let i = start, j = 0; i < 3; i++, j++) {
          mergeForce(existing.atkWaves[i], parts[Math.min(j, 2)]);
        }
        emitPrivate(world,
          'تعزيزات هجومية' + placeLabel(engine, to),
          'وصلت تعزيزات للمهاجم في ' + regionLabel(engine, to) + '.',
          { battleId: existing.id, region: to, kind: 'reinforce_arrive' });
        return existing;
      }
    }

    // Pull defender garrison into battle (losses will apply here)
    const defUnits = {};
    const army = g.regionArmies[to] || {};
    Object.keys(army).forEach(function (id) {
      if (isFixedUnit(id)) return;
      const c = army[id] && army[id].count ? army[id].count : 0;
      if (c > 0) {
        defUnits[id] = c;
        army[id].count = 0;
        if (army[id].count <= 0) delete army[id];
      }
    });
    const sol = g.regionSoldiers[to] || 0;
    if (sol > 0) {
      defUnits.soldiers = sol;
      g.regionSoldiers[to] = 0;
    }

    const t = now();
    const battle = {
      id: 'b_' + t + '_' + Math.random().toString(36).slice(2, 7),
      region: to,
      from: from,
      attacker: attacker,
      defender: defender,
      units: JSON.parse(JSON.stringify(units)),
      defUnits: defUnits,
      atkWaves: splitForce(units),
      defWaves: splitForce(defUnits),
      startedAt: t,
      nextPulseAt: t + daysMs(BATTLE_PULSE_DAYS),
      lastPulseAt: t,
      pulseCount: 0,
      waveResults: [],
      status: 'fighting',
      revealed: true
    };
    g.battles.push(battle);
    // Red contested outline on top of political borders for whole fight
    try {
      if (engine && engine.setRegionBorder) engine.setRegionBorder(String(to), '#ff2020', 2.2, false);
    } catch (_) {}
    if (typeof opts.onVisual === 'function') {
      try { opts.onVisual(to, 'contest', defender); } catch (_) {}
    }
    emitPublic(world, engine, attacker, defender, to, 'start');
    emitPrivate(world,
      'معركة بدأت' + placeLabel(engine, to),
      'قتال مستعر في ' + regionLabel(engine, to) + ' بين ' + (attacker || '?') + ' و ' + (defender || '?') + '. 3 جولات.',
      { battleId: battle.id, region: to, kind: 'battle_start', withdraw: attacker === (opts.playerCountry || null) });
    if (typeof opts.onVisual === 'function') opts.onVisual(to, 'contest');
    return battle;
  }


  function tickMoves(world, engine, playerCountry) {
    const g = ensureMilitary(world);
    const t = now();
    const left = [];
    g.moves.forEach(function (mv) {
      if (mv.player === false) { left.push(mv); return; }
      if (mv.endsAt > t) { left.push(mv); return; }

      const ownerTo = engine.getRegionOwner ? engine.getRegionOwner(mv.to) : null;
      const battle = findBattleAt(g, mv.to);

      // Reinforcements into ongoing battle
      if (battle && (battle.status === 'fighting' || battle.status === 'holding')) {
        if (mv.player && battle.attacker === playerCountry) {
          mergeUnits(battle.units, mv.units);
          // Split reinforcements into remaining waves
          const remainWaves = Math.max(1, 3 - (battle.pulseCount || 0));
          const parts = splitForce(mv.units);
          for (let i = battle.pulseCount || 0, j = 0; i < 3; i++, j++) {
            battle.atkWaves = battle.atkWaves || [{}, {}, {}];
            mergeForce(battle.atkWaves[i], parts[Math.min(j, 2)]);
          }
          emitPrivate(world,
            'تعزيزات وصلت',
            'تأكد وصول المساعدات إلى المعركة. توزعت على الجولات المتبقية.',
            { battleId: battle.id, region: mv.to, kind: 'reinforce_arrive' }
          );
        } else if (ownerTo === playerCountry || battle.defender === playerCountry) {
          // defender reinforce stored on battle
          if (!battle.defUnits) battle.defUnits = {};
          mergeUnits(battle.defUnits, mv.units);
          emitPrivate(world,
            'تعزيزات دفاعية',
            'وصلت تعزيزات دفاعية إلى الإقليم ' + mv.to + '.',
            { battleId: battle.id, region: mv.to, kind: 'def_reinforce' }
          );
        }
        return;
      }

      if (ownerTo === playerCountry) {
        const army = ensureRegionArmy(g, mv.to);
        Object.keys(mv.units).forEach(function (id) {
          if (id === 'soldiers' || id === '_crew') {
            g.regionSoldiers[String(mv.to)] = (g.regionSoldiers[String(mv.to)] || 0) + (mv.units[id] || 0);
            return;
          }
          if (isFixedUnit(id)) return;
          if (!army[id]) army[id] = { count: 0, active: 0 };
          army[id].count += mv.units[id];
          tryActivateUnits(g, mv.to, id);
        });
      } else {
        // Start battle
        const defArmy = g.regionArmies[String(mv.to)] || {};
        const defUnits = {};
        Object.keys(defArmy).forEach(function (id) {
          defUnits[id] = defArmy[id].count || 0;
        });
        // Defender: vehicles + soldiers from region (barracks stay fixed)
        const defForce = Object.assign({}, defUnits);
        defForce.soldiers = g.regionSoldiers[String(mv.to)] || 0;
        const atkForce = Object.assign({}, mv.units);
        // Clear engaged garrison vehicles/soldiers (barracks remain)
        g.regionArmies[String(mv.to)] = {};
        g.regionSoldiers[String(mv.to)] = 0;
        const atkWaves = splitForce(atkForce);
        const defWaves = splitForce(defForce);
        g.battles.push({
          id: 'b_' + now() + '_' + Math.random().toString(36).slice(2, 6),
          region: mv.to,
          from: mv.from,
          attacker: playerCountry,
          defender: ownerTo,
          units: atkForce,
          defUnits: defForce,
          atkWaves: atkWaves,
          defWaves: defWaves,
          startedAt: t,
          lastPulseAt: t,
          nextPulseAt: t + daysMs(BATTLE_PULSE_DAYS),
          status: 'fighting',
          revealed: true,
          pulseCount: 0,
          maxWaves: 3
        });
        try {
          if (engine && engine.setRegionBorder) engine.setRegionBorder(String(mv.to), '#ff2020', 2.2, false);
        } catch (_) {}
        // Relations worsen
        if (!g.relations[ownerTo]) g.relations[ownerTo] = 0;
        g.relations[ownerTo] -= 25;
        emitPublic(world, engine, playerCountry, ownerTo, mv.to, 'start');
        emitPrivate(world,
          'المعركة بدأت' + placeLabel(engine, mv.to),
          'قواتك دخلت المعركة في ' + regionLabel(engine, mv.to) + '. 3 جولات × 10 أيام.',
          { region: mv.to, kind: 'battle_start', withdraw: true }
        );
      }
    });
    g.moves = left;
  }

  function battlePulseMessage(ratio, lang) {
    // ratio = atkPower / (atk+def)
    if (ratio > 0.62) {
      return lang === 'en'
        ? { title: 'We are advancing', body: 'We are advancing — we inflicted heavy losses on the enemy.', mood: 'good' }
        : { title: 'نحن نتقدم', body: 'نحن نتقدم؛ ألحقنا خسائر شديدة بالعدو.', mood: 'good' };
    }
    if (ratio < 0.38) {
      return lang === 'en'
        ? { title: 'Enemy advancing', body: 'We must withdraw now — the enemy is advancing.', mood: 'bad', withdraw: true }
        : { title: 'العدو يتقدم', body: 'علينا الانسحاب حالاً؛ العدو يتقدم.', mood: 'bad', withdraw: true };
    }
    return lang === 'en'
      ? { title: 'Stalemate', body: 'Fighting continues with heavy losses on both sides.', mood: 'mid' }
      : { title: 'استمرار القتال', body: 'القتال مستمر وخسائر الطرفين مرتفعة.', mood: 'mid' };
  }

  function applyAttrition(units, factor) {
    const out = {};
    Object.keys(units || {}).forEach(function (id) {
      const n = Math.max(0, Math.floor((units[id] || 0) * factor));
      if (n > 0) out[id] = n;
    });
    return out;
  }

  /** Mutual losses every wave — both sides always bleed */
  function applyWaveLosses(aW, dW, atkWon) {
    // Winner keeps ~70–85%, loser keeps ~25–40%
    const aKeep = atkWon ? 0.78 : 0.32;
    const dKeep = atkWon ? 0.30 : 0.75;
    const aOut = applyAttrition(aW, aKeep);
    const dOut = applyAttrition(dW, dKeep);
    Object.keys(aW || {}).forEach(function (k) { delete aW[k]; });
    Object.keys(dW || {}).forEach(function (k) { delete dW[k]; });
    Object.assign(aW, aOut);
    Object.assign(dW, dOut);
    return { aOut: aOut, dOut: dOut };
  }


  function tryBotDefendReinforce(world, engine, battle, playerCountry) {
    // Only called when defender LOST the round (roundWinner === 'atk').
    // Winner of a round does not send reinforcements.
    if (!battle || !engine || !battle.defender) return;
    const def = battle.defender;
    if (def === playerCountry) return;
    // One logistics order per lost round
    if (battle._botReinfWave === battle.pulseCount) return;
    battle._botReinfWave = battle.pulseCount;

    const g = ensureMilitary(world);
    const regionKey = String(battle.region);

    // Only reinforce when losing pressure — size force to close the power gap
    const enemyPow = Math.max(1, forcePower(battle.units || {}));
    const ourPow = Math.max(0, forcePower(battle.defUnits || {}));
    if (ourPow >= enemyPow * 1.05) return; // already winning or even — no reinforce
    const deficit = Math.max(0, enemyPow - ourPow);
    // Aim to cover ~70–110% of deficit from one donor, never strip >55% of donor
    let sendRatio = 0.22;
    // Find donor first? ratio refined after score — provisional from pressure
    const pressure = enemyPow / Math.max(1, ourPow + 1);
    sendRatio = Math.min(0.55, Math.max(0.15, 0.12 + deficit / Math.max(80, ourPow + deficit + 1) * 0.5 + Math.min(0.2, pressure * 0.08)));

    // Find strongest neighboring donor (land first), else any owned region nearby
    let donor = null;
    let donorScore = 0;
    let viaSea = false;
    function scoreRegion(nk) {
      const sol = g.regionSoldiers[nk] || 0;
      const army = g.regionArmies[nk] || {};
      let p = sol;
      Object.keys(army).forEach(function (id) {
        if (isFixedUnit(id)) return;
        if (army[id] && army[id].count) p += army[id].count * 12;
      });
      return p;
    }
    if (engine._landAdj && engine._landAdj.get) {
      const neigh = engine._landAdj.get(regionKey) || [];
      const list = neigh instanceof Set ? Array.from(neigh) : (neigh || []);
      for (let i = 0; i < list.length; i++) {
        const nk = String(list[i]);
        const own = engine.getRegionOwner ? engine.getRegionOwner(nk) : null;
        if (own !== def) continue;
        const sc = scoreRegion(nk);
        if (sc > donorScore) { donorScore = sc; donor = nk; viaSea = false; }
      }
    }
    // Sea logistics fallback: other coastal owned region
    if (!donor && engine.isRegionCoastal && engine.isRegionCoastal(regionKey)) {
      const regs = engine.getCountryRegions ? engine.getCountryRegions(def) : [];
      for (let i = 0; i < Math.min(regs.length, 40); i++) {
        const nk = String(regs[i]);
        if (nk === regionKey) continue;
        if (!engine.isRegionCoastal(nk)) continue;
        const sc = scoreRegion(nk);
        if (sc > donorScore) { donorScore = sc; donor = nk; viaSea = true; }
      }
    }
    if (!donor || donorScore < 8) return;

    const reinf = {};
    const sendSol = Math.floor((g.regionSoldiers[donor] || 0) * sendRatio);
    if (sendSol > 0) {
      g.regionSoldiers[donor] = Math.max(0, (g.regionSoldiers[donor] || 0) - sendSol);
      reinf.soldiers = sendSol;
    }
    const army = g.regionArmies[donor] || {};
    Object.keys(army).forEach(function (id) {
      if (isFixedUnit(id)) return;
      const c = Math.floor((army[id].count || 0) * sendRatio);
      if (c > 0) {
        army[id].count -= c;
        if (army[id].active) army[id].active = Math.min(army[id].active, army[id].count);
        if (army[id].count <= 0) delete army[id];
        reinf[id] = c;
      }
    });
    if (forcePower(reinf) <= 0) return;

    // Travel same rules as player: land 10d, sea scaled; +2d logistics into active battle
    let travelDays = viaSea
      ? Math.round(LAND_MOVE_DAYS * (typeof seaDistanceFactor === 'function'
          ? seaDistanceFactor(engine, donor, regionKey) : 2.2))
      : LAND_MOVE_DAYS;
    travelDays = Math.min(travelDays + 2, Math.max(travelDays, LAND_MOVE_DAYS + 2));
    const endsAt = now() + daysMs(travelDays);

    // Target power needed to roughly match attacker (precise quantity)
    const needPow = Math.max(0, enemyPow - ourPow);
    let gotPow = forcePower(reinf);
    // If still weak, try a second donor (strongest remaining)
    if (gotPow < needPow * 0.55) {
      // keep what we have; ratio already applied — do not strip more from same region
    }

    g.moves.push({
      id: 'bot_reinf_' + now() + '_' + Math.random().toString(36).slice(2, 6),
      from: String(donor),
      to: regionKey,
      units: reinf,
      startedAt: now(),
      endsAt: endsAt,
      player: false,
      sea: !!viaSea,
      botDefender: def,
      botReinforceBattle: battle.id,
      botAttacker: null,
      // Hidden from player UI/news until arrival
      hiddenUntilArrive: true,
      silent: true
    });
    // No alert while on the road — player only learns on arrival (tickMoves / beginBattle)
  }

  function tickBattles(world, engine, playerCountry, onAnnexVisual) {
    const g = ensureMilitary(world);
    const t = now();
    const remain = [];
    g.battles.forEach(function (b) {
      if (b.status === 'fighting') {
        if (!b.atkWaves) b.atkWaves = splitForce(b.units || {});
        if (!b.defWaves) b.defWaves = splitForce(b.defUnits || {});
        if (!b.nextPulseAt) b.nextPulseAt = (b.lastPulseAt || b.startedAt || t) + daysMs(BATTLE_PULSE_DAYS);
        // One wave result per tick so reports arrive one-by-one (not all at once)
        if (b.nextPulseAt <= t && b.status === 'fighting') {
          const wave = b.pulseCount || 0; // 0,1,2
          if (wave < 3) {
          const aW = b.atkWaves[wave] || {};
          const dW = b.defWaves[wave] || {};
          let aP = forcePower(aW);
          let dP = forcePower(dW);
          const roundNo = wave + 1;
          const place = placeLabel(engine, b.region);
          const placeName = regionLabel(engine, b.region);
          if (dP <= 0 && aP <= 0) {
            emitPrivate(world,
              'نتيجة الجولة ' + roundNo + place,
              'الجولة ' + roundNo + ' في ' + placeName + ' بلا اشتباك (لا قوات في الموجة).',
              { battleId: b.id, region: b.region, kind: 'battle_pulse', wave: roundNo, mood: 'mid' });
          } else if (dP > aP) {
            // Defender wins round — both take losses (attacker heavier)
            applyWaveLosses(aW, dW, false);
            b.defWaves[wave] = dW;
            b.atkWaves[wave] = aW;
            redistributeRemain(b.defWaves, wave);
            emitPrivate(world,
              'نتيجة الجولة ' + roundNo + ' — فشل' + place,
              'الجولة ' + roundNo + ' في ' + placeName + ': العدو تفوق. الطرفان تلقيا خسائر. هل ننسحب؟',
              { battleId: b.id, region: b.region, kind: 'battle_pulse', wave: roundNo, withdraw: true, mood: 'bad' });
          } else {
            // Attacker wins round — both take losses (defender heavier)
            applyWaveLosses(aW, dW, true);
            b.atkWaves[wave] = aW;
            b.defWaves[wave] = dW;
            redistributeRemain(b.atkWaves, wave);
            emitPrivate(world,
              'نتيجة الجولة ' + roundNo + ' — نجاح' + place,
              'الجولة ' + roundNo + ' في ' + placeName + ': تفوقنا مع خسائر للطرفين. نواصل.',
              { battleId: b.id, region: b.region, kind: 'battle_pulse', wave: roundNo, mood: 'good' });
          }
          b.pulseCount = wave + 1;
          if (!b.waveResults) b.waveResults = [];
          // record who won this round
          const aP2 = forcePower(b.atkWaves[wave] || {});
          const dP2 = forcePower(b.defWaves[wave] || {});
          let roundWinner = 'draw';
          if (aP2 > dP2 && aP2 > 0) roundWinner = 'atk';
          else if (dP2 > aP2 && dP2 > 0) roundWinner = 'def';
          else if (aP > dP) roundWinner = 'atk';
          else if (dP > aP) roundWinner = 'def';
          b.waveResults[wave] = roundWinner;

          // Rebuild aggregate units from remaining waves
          b.units = {};
          b.defUnits = {};
          for (let i = 0; i < 3; i++) {
            mergeForce(b.units, b.atkWaves[i]);
            mergeForce(b.defUnits, b.defWaves[i]);
          }
          const aLeft = forcePower(b.units);
          const dLeft = forcePower(b.defUnits);

          // Bot defender may reinforce after losing a round (before final round ends)
          if (roundWinner === 'atk' && b.pulseCount < 3 && b.defender && b.defender !== playerCountry) {
            tryBotDefendReinforce(world, engine, b, playerCountry);
          }

          // Early end ONLY if attackers fully wiped — never end early just because defender lost a wave
          const plc = placeLabel(engine, b.region);
          const pln = regionLabel(engine, b.region);
          if (aLeft <= 0) {
            b.status = 'lost';
            // Defender survivors (with losses) return to region
            returnForceToRegion(g, b.region, b.defUnits);
            emitPublic(world, engine, b.attacker, b.defender, b.region, 'lose');
            emitPrivate(world, 'هزيمة' + plc,
              'فشل الهجوم على ' + pln + ' بعد الجولة ' + (wave + 1) + '. الطرفان تكبدا خسائر.',
              { battleId: b.id, region: b.region, kind: 'lost' });
          } else if (b.pulseCount >= 3) {
            // Round 3 is decisive: win/lose by the third wave only.
            // Rounds 1–2 are probes for strength and logistics.
            const lastWin = b.waveResults[2];
            let victory = false;
            if (lastWin === 'atk') victory = true;
            else if (lastWin === 'def') victory = false;
            else victory = aLeft > 0 && forcePower(b.units || {}) >= forcePower(b.defUnits || {});

            if (victory && aLeft > 0) {
              b.status = 'holding';
              b.holdUntil = t + daysMs(OCCUPY_HOLD_DAYS);
              // Defender garrison wiped/lost in battle — residual def destroyed
              b.defUnits = {};
              try {
                if (b.defender && b.defender !== playerCountry && global.WOK_Bot && global.WOK_Bot.recordLostRegion) {
                  global.WOK_Bot.recordLostRegion(world, b.defender, String(b.region));
                }
              } catch (_) {}
              emitPublic(world, engine, b.attacker, b.defender, b.region, 'win');
              emitPrivate(world, 'انتصار ميداني' + plc,
                'فزنا في ' + pln + ' (الجولة الأخيرة حاسمة). صمود 360 يوماً. العدو قد يرسل تعزيزات.',
                { battleId: b.id, region: b.region, kind: 'holding' });
              if (typeof onAnnexVisual === 'function') onAnnexVisual(b.region, 'contest');
            } else {
              b.status = 'lost';
              // Attackers limp home with losses; defenders return residual
              if (b.from) returnForceToRegion(g, b.from, b.units);
              returnForceToRegion(g, b.region, b.defUnits);
              emitPublic(world, engine, b.attacker, b.defender, b.region, 'lose');
              emitPrivate(world, 'هزيمة' + plc,
                'لم نحسم ' + pln + '. قواتنا المتبقية تراجعت بخسائر، والمدافع أيضاً تلقى خسائر.',
                { battleId: b.id, region: b.region, kind: 'lost' });
            }
          }
          b.lastPulseAt = b.nextPulseAt;
          b.nextPulseAt = b.lastPulseAt + daysMs(BATTLE_PULSE_DAYS);
          } // end wave < 3
        } // end single pulse
        if (b.status === 'fighting' || b.status === 'holding') remain.push(b);
        return;
      }

      if (b.status === 'holding') {
        // Enemy counter-attack possible via bot moves into this region while holding
        if (b.holdUntil <= t) {
          const owner = b.attacker || playerCountry;
          const defName = b.defender;
          if (engine.occupyRegion) engine.occupyRegion(b.region, owner);
          const army = ensureRegionArmy(g, b.region);
          Object.keys(b.units || {}).forEach(function (id) {
            if (id === 'soldiers' || id === '_crew') {
              g.regionSoldiers[String(b.region)] = (g.regionSoldiers[String(b.region)] || 0) + Math.floor(b.units[id] || 0);
              return;
            }
            if (isFixedUnit(id)) return;
            if (!army[id]) army[id] = { count: 0, active: 0 };
            army[id].count = (army[id].count || 0) + Math.floor(b.units[id] || 0);
            army[id].active = army[id].count;
          });
          emitPublic(world, engine, owner, defName, b.region, 'annex');
          emitPrivate(world,
            'ضم مكتمل',
            'صمدنا 360 يوماً وتم ضم الإقليم نهائياً.',
            { region: b.region, kind: 'annex' }
          );
          // Full country wipe: 0 regions left → public bulletin + gone from world lists
          try {
            const left = engine.getCountryRegions ? engine.getCountryRegions(defName) : [];
            if (defName && (!left || !left.length)) {
              if (global.WOK_News && global.WOK_News.onCountryEliminated) {
                global.WOK_News.onCountryEliminated(world, engine, owner, defName);
              } else {
                emitPrivate(world, 'عاجل',
                  'عدد الدول المعترفة بـ ' + defName + ' وصل إلى 0 بعد أن احتلتها ' + owner + '.',
                  { kind: 'eliminate', victim: defName, by: owner });
              }
            }
          } catch (_) {}
          if (typeof onAnnexVisual === 'function') onAnnexVisual(b.region, 'annex', defName);
          return;
        }
        remain.push(b);
      }
    });
    g.battles = remain;
  }

  function withdrawBattle(world, battleId) {
    const g = ensureMilitary(world);
    const idx = g.battles.findIndex(function (b) { return b.id === battleId; });
    if (idx < 0) return false;
    const b = g.battles[idx];
    if (b.status !== 'fighting' && b.status !== 'holding') return false;
    const from = b.from != null ? String(b.from) : null;
    const region = String(b.region);
    // March home as a visible move (same bar as an attack)
    const moving = Object.assign({}, b.units || {});
    if (from && Object.keys(moving).length) {
      g.moves.push({
        id: 'm_wd_' + now() + '_' + Math.random().toString(36).slice(2, 6),
        from: region,
        to: from,
        units: moving,
        startedAt: now(),
        endsAt: now() + daysMs(LAND_MOVE_DAYS),
        player: true,
        friendly: true,
        sea: false,
        oilSpent: 0,
        withdraw: true
      });
    } else {
      // No origin — dump into regionSoldiers/army on the contested region then clear battle
      returnForceToRegion(g, region, moving);
    }
    g.threats.push({ region: region, at: now(), from: from });
    g.battles.splice(idx, 1);
    emitPrivate(world,
      'انسحاب',
      'قواتك تنسحب من المعركة وتعود إلى قاعدتها.',
      { region: region, kind: 'withdraw', battleId: battleId }
    );
    // Signal UI to drop contest (red) border immediately
    return { ok: true, region: region, from: from, clearContest: true };
  }

  function tickAll(world, engine, playerCountry, getStock, setStock, onAnnexVisual) {
    tickResearch(world);
    tickTrain(world);
    tickMoves(world, engine, playerCountry);
    tickBattles(world, engine, playerCountry, onAnnexVisual);
  }

  function markersForEngine(world, playerCountry, engine) {
    const g = ensureMilitary(world);
    const revealed = {};
    (g.battles || []).forEach(function (b) {
      if (b.revealed || b.status === 'fighting' || b.status === 'holding') revealed[String(b.region)] = true;
    });
    const out = {};
    Object.keys(g.regionArmies || {}).forEach(function (rk) {
      const owner = engine && engine.getRegionOwner ? engine.getRegionOwner(rk) : null;
      const isPlayer = owner === playerCountry;
      const isRevealedEnemy = !isPlayer && revealed[rk];
      if (!isPlayer && !isRevealedEnemy) return;
      const army = g.regionArmies[rk];
      const markers = [];
      Object.keys(army).forEach(function (id) {
        const slot = army[id];
        if (!slot || slot.count <= 0) return;
        const u = global.WOK.getUnit(id);
        markers.push({
          id: id,
          count: slot.count,
          icon: unitIcon(u),
          domain: domainOf(u)
        });
      });
      if (markers.length) out[rk] = markers;
    });
    return out;
  }

  function activeMoves(world) { return ensureMilitary(world).moves.slice(); }

  /** Recall a player move mid-route — reverse direction back to origin. */
  function recallMove(world, moveId) {
    const g = ensureMilitary(world);
    const id = String(moveId || '');
    const mv = (g.moves || []).find(function (m) { return String(m.id) === id; });
    if (!mv) return false;
    // Only player-initiated moves (or unmarked legacy)
    if (mv.player === false) return false;
    if (mv.recalling) return false;
    const t = now();
    const total = Math.max(1, (mv.endsAt || t) - (mv.startedAt || t));
    const prog = Math.max(0.05, Math.min(0.95, (t - (mv.startedAt || t)) / total));
    const origin = mv.originFrom || mv.from;
    mv.originFrom = origin;
    mv.recalling = true;
    // Reverse endpoints so the line heads home
    const dest = mv.to;
    mv.from = dest;
    mv.to = origin;
    mv.startedAt = t;
    mv.endsAt = t + Math.max(daysMs(2), Math.round(total * prog));
    mv.friendly = true;
    return true;
  }

  function activeBattles(world) { return ensureMilitary(world).battles.slice(); }

  function armySummary(world, regionKey) {
    const g = ensureMilitary(world);
    const army = g.regionArmies[String(regionKey)] || {};
    const rows = [];
    Object.keys(army).forEach(function (id) {
      if (id === 'soldiers' || id === '_crew') return;
      if (isFixedUnit(id)) return;
      const u = global.WOK.getUnit(id);
      const slot = army[id];
      if (!slot) return;
      // Clamp corrupt / inflated saves
      let c = Math.floor(Number(slot.count) || 0);
      let a = Math.floor(Number(slot.active) || 0);
      if (c < 0) c = 0;
      if (a < 0) a = 0;
      if (a > c) a = c;
      slot.count = c;
      slot.active = a;
      if (c <= 0) { delete army[id]; return; }
      if (!u) return; // unknown unit id → drop from display
      rows.push({
        id: id,
        name: u.name || { en: id, ar: id },
        count: c,
        active: a,
        icon: unitIcon(u),
        domain: domainOf(u),
        power: (Number(u.power) || 0) * a
      });
    });
    const barracks = g.regionBarracks[String(regionKey)] || 0;
    const soldiers = g.regionSoldiers[String(regionKey)] || 0;
    const totalPower = powerOfArmy(army) + soldierPower(soldiers);
    return { rows: rows, soldiers: soldiers, barracks: barracks, totalPower: totalPower };
  }

  global.WOK_Military = {
    ensure: ensureMilitary,
    isUnlocked: isUnlocked,
    canStartResearch: canStartResearch,
    startResearch: startResearch,
    addToPackage: addToPackage,
    startTrainFromPackage: startTrainFromPackage,
    removeFromPackage: removeFromPackage,
    startMove: startMove,
    beginBattle: beginBattle,
    regionLabel: regionLabel,
    withdrawBattle: withdrawBattle,
    tickAll: tickAll,
    powerOfArmy: powerOfArmy,
    markersForEngine: markersForEngine,
    activeMoves: activeMoves,
    recallMove: recallMove,
    activeBattles: activeBattles,
    armySummary: armySummary,
    estimateOil: estimateOil,
    unitIcon: unitIcon,
    domainOf: domainOf,
    isFixedUnit: isFixedUnit,
    forcePower: forcePower,
    BARRACKS_ID: BARRACKS_ID,
    regionsLandLinked: regionsLandLinked,
    regionsStrictLandLinked: regionsStrictLandLinked,
    regionsSeaLinked: regionsSeaLinked,
    findBattleAt: findBattleAt,
    LAND_MOVE_DAYS: LAND_MOVE_DAYS,
    REINFORCE_BATTLE_DAYS: REINFORCE_BATTLE_DAYS,
    BATTLE_PULSE_DAYS: BATTLE_PULSE_DAYS,
    OCCUPY_HOLD_DAYS: OCCUPY_HOLD_DAYS,
    MS_PER_GAME_DAY: MS_PER_GAME_DAY
  };
})(typeof window !== 'undefined' ? window : globalThis);
