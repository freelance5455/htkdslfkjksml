  (function () {
    'use strict';

    const SETTINGS_KEY = 'wok_settings';
    const WORLDS_KEY = 'wok_worlds';
    const PENDING_KEY = 'wok_pending_world';
    const ORIENT_SESSION_KEY = 'wok_session_orient';

    function rememberOrient(mode, permanent) {
      if (mode !== 'landscape' && mode !== 'portrait') return;
      try { sessionStorage.setItem(ORIENT_SESSION_KEY, mode); } catch (_) {}
      try { localStorage.setItem(ORIENT_SESSION_KEY, mode); } catch (_) {}
      if (permanent) {
        try {
          const raw = localStorage.getItem(SETTINGS_KEY);
          const s = raw ? JSON.parse(raw) : {};
          s.orient = mode;
          localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
          if (typeof settings !== 'undefined') settings.orient = mode;
        } catch (_) {}
      }
    }
    function readSavedOrient() {
      // Single source of truth: settings.orient in wok_settings
      try {
        const raw = localStorage.getItem(SETTINGS_KEY);
        if (raw) {
          const s = JSON.parse(raw);
          if (s && (s.orient === 'landscape' || s.orient === 'portrait')) return s.orient;
        }
      } catch (_) {}
      try {
        const q = new URLSearchParams(location.search || '').get('orient');
        if (q === 'landscape' || q === 'portrait') return q;
      } catch (_) {}
      try {
        const a = sessionStorage.getItem(ORIENT_SESSION_KEY);
        if (a === 'landscape' || a === 'portrait') return a;
      } catch (_) {}
      return null;
    }
    function readSessionOrient() { return readSavedOrient(); }
    function detectOrient() {
      try {
        if (screen.orientation && screen.orientation.type) {
          if (String(screen.orientation.type).indexOf('landscape') >= 0) return 'landscape';
          if (String(screen.orientation.type).indexOf('portrait') >= 0) return 'portrait';
        }
      } catch (_) {}
      try {
        if (window.matchMedia && window.matchMedia('(orientation: landscape)').matches) return 'landscape';
        if (window.matchMedia && window.matchMedia('(orientation: portrait)').matches) return 'portrait';
      } catch (_) {}
      return (window.innerWidth >= window.innerHeight) ? 'landscape' : 'portrait';
    }
    async function lockOrientNow(mode) {
      if (mode !== 'landscape' && mode !== 'portrait') return false;
      try {
        const el = document.documentElement;
        if (!document.fullscreenElement && !document.webkitFullscreenElement) {
          if (el.requestFullscreen) await el.requestFullscreen();
          else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen();
        }
      } catch (_) {}
      try {
        if (screen.orientation && screen.orientation.lock) {
          await screen.orientation.lock(mode);
          rememberOrient(mode);
          return true;
        }
      } catch (e) {
        console.warn('lockOrientNow failed', e);
      }
      rememberOrient(mode);
      return false;
    }

    const I18N = (window.WOK_I18N && WOK_I18N.compat) ? WOK_I18N.compat() : { en: {}, ar: {} };
    function tKey(key, fallback) {
      if (window.WOK_I18N && WOK_I18N.t) {
        if (window.WOK_I18N.setLang) WOK_I18N.setLang((typeof settings !== 'undefined' && settings.lang) || 'ar');
        return WOK_I18N.t(key, fallback);
      }
      const lang = (typeof settings !== 'undefined' && settings.lang) || 'ar';
      const bag = I18N[lang] || I18N.ar || I18N.en || {};
      return (bag[key] != null && bag[key] !== '') ? bag[key] : (fallback != null ? fallback : key);
    }

    function loadSettings() {
      if (window.WOK_Settings && WOK_Settings.load) return WOK_Settings.load();
      try {
        const raw = localStorage.getItem(SETTINGS_KEY);
        const d = raw ? JSON.parse(raw) : {};
        return Object.assign({
          lang: 'ar', orient: 'landscape', sensitivity: 1, panSensitivity: 1, zoomSensitivity: 1,
          hideSmallIslands: !!(window.WOK_perfDefaults && WOK_perfDefaults().hideSmallIslands), showMapStats: false, muteMapBanners: false,
          countryBorderDetail: (window.WOK_perfDefaults && WOK_perfDefaults().countryBorderDetail) || 28, regionBorderDetail: (window.WOK_perfDefaults && WOK_perfDefaults().regionBorderDetail) || 28
        }, d);
      } catch (_) {
        return { lang: 'ar', orient: 'landscape', sensitivity: 1, panSensitivity: 1, zoomSensitivity: 1, hideSmallIslands: false, showMapStats: false, muteMapBanners: false, countryBorderDetail: 32, regionBorderDetail: 32 };
      }
    }
    function saveSettings(s) {
      if (window.WOK_Settings && WOK_Settings.save) {
        settings = WOK_Settings.save(s || settings);
        return settings;
      }
      try {
        const cur = loadSettings();
        const next = Object.assign({}, cur, s || {});
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
        settings = next;
        return next;
      } catch (_) { return s; }
    }
    function clampSens(v) {
      const n = Number(v);
      if (!isFinite(n)) return 1;
      return Math.max(0.5, Math.min(2, n));
    }

    let settings = loadSettings();

    function tx(key, fallback) {
      if (window.WOK_I18N && WOK_I18N.t) {
        WOK_I18N.setLang(settings.lang);
        const v = WOK_I18N.t(key, fallback);
        if (v != null && v !== '') return v === key && fallback ? fallback : v;
      }
      const bag = ((I18N[settings.lang] || I18N.en || I18N.ar || {}) || {});
      return (bag[key] != null && bag[key] !== '') ? bag[key] : (fallback != null ? fallback : '');
    }
    function setTxt(id, key, fallback) {
      const el = typeof id === 'string' ? document.getElementById(id) : id;
      if (!el) return;
      const v = tx(key, fallback != null ? fallback : el.textContent);
      if (v != null && v !== '') el.textContent = v;
    }
    function applyI18n() {
      if (window.WOK_I18N && WOK_I18N.setLang) WOK_I18N.setLang(settings.lang);
      const t = (window.WOK_I18N && WOK_I18N.bundle) ? WOK_I18N.bundle(settings.lang) : ((I18N[settings.lang] || I18N.en || I18N.ar || {}) || {});
      document.documentElement.lang = settings.lang;
      document.documentElement.dir = (window.WOK_I18N && WOK_I18N.isRtl) ? (WOK_I18N.isRtl(settings.lang) ? 'rtl' : 'ltr') : (settings.lang === 'ar' ? 'rtl' : 'ltr');
      document.querySelectorAll('[data-i18n]').forEach(function (el) {
        const k = el.getAttribute('data-i18n');
        if (!k) return;
        const v = tx(k, el.textContent);
        if (v && v !== k) el.textContent = v;
      });
      setTxt('btn-new-world', 'add_world', 'إضافة عالم');
      setTxt('title-worlds', 'your_worlds', 'عوالمك');
      // common labels if present
      ['btn-back', 'btn-settings', 'btn-play'].forEach(function () {});
      const selO = document.getElementById('sel-orient');
      if (selO && selO.options && selO.options.length >= 2) {
        const p = tx('portrait', selO.options[0].textContent);
        const l = tx('landscape', selO.options[1].textContent);
        if (p) selO.options[0].textContent = p;
        if (l) selO.options[1].textContent = l;
      }
    }

    // ── Map background ──
    const canvas = document.getElementById('bg-canvas');
    const panelMain = document.getElementById('panel-main');
    const layerSettings = document.getElementById('layer-settings');
    const layerWorlds = document.getElementById('layer-worlds');
    const layerAdd = document.getElementById('layer-add');
    const layerOnline = document.getElementById('layer-online');
    const layerOnlineCreate = document.getElementById('layer-online-create');
    const layerOffline = document.getElementById('layer-offline');
    const layerEditWorld = document.getElementById('layer-edit-world');
    const layerConfirmDelete = document.getElementById('layer-confirm-delete');
    const worldsList = document.getElementById('worlds-list');
    const brand = document.getElementById('brand');
    let editingWorldId = null;

    const engine = new MapEngine(canvas, { onStats() {} });
    canvas.style.pointerEvents = 'none';
    if (engine.setPanSensitivity) engine.setPanSensitivity(settings.panSensitivity != null ? settings.panSensitivity : settings.sensitivity);
    if (engine.setZoomSensitivity) engine.setZoomSensitivity(settings.zoomSensitivity != null ? settings.zoomSensitivity : settings.sensitivity);

    let spinRaf = null;
    const SPIN_DEG_PER_SEC = 2.2;

    function startSpin() {
      let last = performance.now();
      let frame = 0;
      function tick(now) {
        const dt = Math.min(0.05, (now - last) / 1000);
        last = now;
        frame++;
        if (engine.ready && !document.hidden) {
          engine.camLon = ((engine.camLon + SPIN_DEG_PER_SEC * dt + 180) % 360) - 180;
          const zMin = engine._minZoom();
          if (Math.abs(engine.zoom - zMin) > 0.001) engine.zoom = zMin;
          engine.camLat = 0;
          // redraw every 2nd frame — smoother battery, same look
          if (frame % 2 === 0) engine.setDirty();
        }
        spinRaf = requestAnimationFrame(tick);
      }
      spinRaf = requestAnimationFrame(tick);
    }

    engine.load(
      'data/countries-110m.json',
      'data/countries-50m.json',
      'data/regions.json'
    ).then(() => {
      engine.camLon = 20;
      engine.camLat = 0;
      engine.zoom = engine._minZoom();
      engine._clampCamera();
      engine._resize();
      engine.setDirty();
      startSpin();
    }).catch(err => console.error('bg map failed', err));

    function refitMap() {
      if (!engine.ready) return;
      engine._resize();
      engine.zoom = engine._minZoom();
      engine.camLat = 0;
      engine._clampCamera();
      engine.setDirty();
    }
    window.addEventListener('resize', () => setTimeout(refitMap, 80));
    window.addEventListener('orientationchange', () => setTimeout(refitMap, 160));

    // ── Navigation ──
    function showMain() {
      layerSettings.classList.add('hidden');
      layerWorlds.classList.add('hidden');
      layerAdd.classList.add('hidden');
      if (layerOnline) layerOnline.classList.add('hidden');
      if (layerOnlineCreate) layerOnlineCreate.classList.add('hidden');
      const layerJoinHide = document.getElementById('layer-online-join');
      if (layerJoinHide) layerJoinHide.classList.add('hidden');
      layerOffline.classList.add('hidden');
      layerEditWorld.classList.add('hidden');
      layerConfirmDelete.classList.add('hidden');
      panelMain.classList.remove('hidden');
      brand.style.display = '';
      editingWorldId = null;
    }
    function showWorlds() {
      layerSettings.classList.add('hidden');
      layerAdd.classList.add('hidden');
      if (layerOnline) layerOnline.classList.add('hidden');
      if (layerOnlineCreate) layerOnlineCreate.classList.add('hidden');
      const layerJoinHide2 = document.getElementById('layer-online-join');
      if (layerJoinHide2) layerJoinHide2.classList.add('hidden');
      layerOffline.classList.add('hidden');
      layerEditWorld.classList.add('hidden');
      layerConfirmDelete.classList.add('hidden');
      panelMain.classList.add('hidden');
      brand.style.display = 'none';
      layerWorlds.classList.remove('hidden');
      editingWorldId = null;
      renderWorlds();
    }
    function hideMainButtons() {
      panelMain.classList.add('hidden');
      brand.style.display = 'none';
    }

    document.getElementById('btn-play').onclick = () => {
      hideMainButtons();
      layerWorlds.classList.remove('hidden');
      renderWorlds();
    };
    document.getElementById('btn-settings').onclick = () => {
      hideMainButtons();
      layerSettings.classList.remove('hidden');
      // Force-sync selects from saved settings (never leave browser default index 0)
      try {
        settings = loadSettings() || settings;
        var wantLang = (window.WOK_I18N && WOK_I18N.normalizeLang)
          ? WOK_I18N.normalizeLang(settings.lang)
          : (settings.lang || 'ar');
        settings.lang = wantLang;
        var langSel = document.getElementById('sel-lang');
        if (langSel) {
          langSel.value = wantLang;
          if (langSel.value !== wantLang) {
            for (var i = 0; i < langSel.options.length; i++) {
              if (langSel.options[i].value === wantLang) { langSel.selectedIndex = i; break; }
            }
          }
        }
        var orientSel = document.getElementById('sel-orient');
        if (orientSel) orientSel.value = settings.orient === 'landscape' ? 'landscape' : 'portrait';
      } catch (_) {}
      try {
        const chk = document.getElementById('chk-hide-islands');
        if (chk) chk.checked = !!settings.hideSmallIslands;
      } catch (_) {}
      const panEl = document.getElementById('rng-sens-pan') || document.getElementById('rng-sens');
      const zoomEl = document.getElementById('rng-sens-zoom');
      const panVal = document.getElementById('sens-pan-val') || document.getElementById('sens-val');
      const zoomVal = document.getElementById('sens-zoom-val');
      const pan = settings.panSensitivity != null ? settings.panSensitivity : settings.sensitivity;
      const zoom = settings.zoomSensitivity != null ? settings.zoomSensitivity : settings.sensitivity;
      if (panEl) panEl.value = pan;
      if (panVal) panVal.textContent = Number(pan).toFixed(2);
      if (zoomEl) zoomEl.value = zoom;
      if (zoomVal) zoomVal.textContent = Number(zoom).toFixed(2);
      const chkMute = document.getElementById('chk-mute-banners');
      if (chkMute) chkMute.checked = !!settings.muteMapBanners;
      const rb = document.getElementById('rng-border-detail');
      const vb = document.getElementById('border-detail-val');
      if (rb) rb.value = settings.countryBorderDetail != null ? settings.countryBorderDetail : 32;
      if (vb) vb.textContent = String(settings.countryBorderDetail != null ? settings.countryBorderDetail : 32);
      const rr = document.getElementById('rng-region-detail');
      const vr = document.getElementById('region-detail-val');
      if (rr) rr.value = settings.regionBorderDetail != null ? settings.regionBorderDetail : 32;
      if (vr) vr.textContent = String(settings.regionBorderDetail != null ? settings.regionBorderDetail : 32);
      showCat('general');
    };
    document.getElementById('btn-quit').onclick = () => {
      // 1) Android WebView bridge
      try {
        if (window.Android && typeof window.Android.quit === 'function') {
          window.Android.quit();
          return;
        }
      } catch (_) {}

      // 2) stop background spin + hide UI
      if (spinRaf != null) {
        cancelAnimationFrame(spinRaf);
        spinRaf = null;
      }
      try {
        if (document.fullscreenElement) document.exitFullscreen();
        else if (document.webkitFullscreenElement) document.webkitExitFullscreen();
      } catch (_) {}

      // 3) try close the tab/window (works only if script opened it)
      try { window.close(); } catch (_) {}
      try { window.open('', '_self'); window.close(); } catch (_) {}

      // 4) fallback: blank the page so nothing remains interactive
      document.body.innerHTML = '';
      document.body.style.cssText = 'margin:0;background:#000;width:100%;height:100%;';
      try { window.location.replace('about:blank'); } catch (_) {}
    };

    document.getElementById('btn-add-world').onclick = () => {
      layerWorlds.classList.add('hidden');
      layerAdd.classList.remove('hidden');
    };
    document.getElementById('btn-offline').onclick = () => {
      layerAdd.classList.add('hidden');
      layerOffline.classList.remove('hidden');
      const inp = document.getElementById('inp-world-name');
      if (inp) {
        inp.value = '';
        setTimeout(() => inp.focus(), 80);
      }
      const sel = document.getElementById('sel-difficulty');
      if (sel) sel.value = 'medium';
    };
    document.getElementById('btn-online').onclick = () => {
      layerAdd.classList.add('hidden');
      if (layerOnline) layerOnline.classList.remove('hidden');
    };
    // Online Create / Join — Create opens form; server Create not functional yet
    const btnOnlineCreate = document.getElementById('btn-online-create');
    const btnOnlineJoin = document.getElementById('btn-online-join');
    if (btnOnlineCreate) {
      btnOnlineCreate.onclick = () => {
        if (layerOnline) layerOnline.classList.add('hidden');
        if (layerOnlineCreate) {
          layerOnlineCreate.classList.remove('hidden');
          // defaults
          const maxP = document.getElementById('inp-max-players');
          if (maxP && !maxP.value) maxP.value = '5';
          const g = document.getElementById('chk-global-chat');
          if (g) g.checked = true;
          const p = document.getElementById('chk-private-chat');
          if (p) p.checked = true;
          const bd = document.getElementById('sel-bot-diff');
          if (bd && !bd.value) bd.value = 'medium';
          setTimeout(function () {
            const n = document.getElementById('inp-srv-name');
            if (n) n.focus();
          }, 60);
        }
      };
    }
    if (btnOnlineJoin) {
      btnOnlineJoin.onclick = () => {
        if (layerOnline) layerOnline.classList.add('hidden');
        const layerJoin = document.getElementById('layer-online-join');
        if (layerJoin) {
          layerJoin.classList.remove('hidden');
          setTimeout(function () {
            const n = document.getElementById('inp-join-srv');
            if (n) n.focus();
          }, 60);
        }
      };
    }
    // Join validation wired after validators are defined (see below)
    let _wireJoinValidate = null;
    const btnJoinGo = document.getElementById('btn-join-go');
    if (btnJoinGo) {
      btnJoinGo.onclick = function (ev) {
        if (typeof _wireJoinValidate === 'function') return _wireJoinValidate(ev);
        // fallback until validators exist
        const name = ((document.getElementById('inp-join-srv') || {}).value || '').trim();
        const pass = (document.getElementById('inp-join-pass') || {}).value || '';
        if (!name || !pass) {
          const miss = !name ? document.getElementById('inp-join-srv') : document.getElementById('inp-join-pass');
          if (miss) miss.focus();
          return;
        }
        console.log('[UI] Online Join — not implemented yet', { name: name });
      };
    }
    function syncPassEye(btn, inp) {
      // 👁 = password visible (text); 🙈 = hidden (password)
      const visible = inp.type === 'text';
      btn.textContent = visible ? '👁' : '🙈';
      btn.setAttribute('title', visible ? 'Hide' : 'Show');
      btn.setAttribute('aria-label', visible ? 'Hide password' : 'Show password');
    }
    function bindPassEye(btnId, inputId) {
      const btn = document.getElementById(btnId);
      const inp = document.getElementById(inputId);
      if (!btn || !inp) return;
      // Initial: field is password → closed eye
      if (inp.type === 'password') {
        btn.textContent = '🙈';
        btn.setAttribute('title', 'Show');
      }
      btn.addEventListener('click', function () {
        const willShow = inp.type === 'password';
        inp.type = willShow ? 'text' : 'password';
        syncPassEye(btn, inp);
      });
    }
    bindPassEye('eye-srv-pass', 'inp-srv-pass');
    bindPassEye('eye-owner-pass', 'inp-owner-pass');
    bindPassEye('eye-join-pass', 'inp-join-pass');

    // Max players: clamp 2–32 live (never wipe the create layer)
    const maxPlayersEl = document.getElementById('inp-max-players');
    function clampMaxPlayers() {
      if (!maxPlayersEl) return;
      let n = Number(maxPlayersEl.value);
      if (!Number.isFinite(n)) n = 5;
      if (n > 32) n = 32;
      if (n < 2) n = 2;
      if (String(maxPlayersEl.value) !== String(n)) maxPlayersEl.value = String(n);
      clearFieldErr('err-max-players', maxPlayersEl);
    }
    if (maxPlayersEl) {
      maxPlayersEl.setAttribute('min', '2');
      maxPlayersEl.setAttribute('max', '32');
      maxPlayersEl.addEventListener('change', clampMaxPlayers);
      maxPlayersEl.addEventListener('blur', clampMaxPlayers);
      maxPlayersEl.addEventListener('input', function () {
        const n = Number(maxPlayersEl.value);
        if (!Number.isFinite(n)) return;
        if (n > 32) maxPlayersEl.value = '32';
        clearFieldErr('err-max-players', maxPlayersEl);
      });
      // Prevent Enter from acting like submit / clearing the layer
      maxPlayersEl.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.keyCode === 13) {
          e.preventDefault();
          e.stopPropagation();
          clampMaxPlayers();
          maxPlayersEl.blur();
        }
      });
    }

    function tMsg(key, fb) {
      try {
        if (window.WOK_I18N && WOK_I18N.t) return WOK_I18N.t(key, fb);
      } catch (_) {}
      return fb;
    }
    function setFieldErr(errId, inputEl, msg) {
      const er = document.getElementById(errId);
      if (er) {
        er.textContent = msg || '';
        if (msg) er.removeAttribute('hidden');
        else er.setAttribute('hidden', '');
      }
      if (inputEl) {
        if (msg) inputEl.classList.add('invalid');
        else inputEl.classList.remove('invalid');
      }
    }
    function clearFieldErr(errId, inputEl) {
      setFieldErr(errId, inputEl, '');
    }
    function countMatches(str, re) {
      const m = String(str || '').match(re);
      return m ? m.length : 0;
    }
    // Special / "suspicious" symbols (not letters/digits/space) — Unicode-aware with fallback
    let RE_SPECIAL, RE_DIGIT, RE_LETTER;
    try {
      RE_SPECIAL = /[^\p{L}\p{N}\s]/gu;
      RE_DIGIT = /\p{N}/gu;
      RE_LETTER = /\p{L}/gu;
      // probe
      RE_LETTER.test('a');
    } catch (_) {
      RE_SPECIAL = /[^A-Za-z0-9\u0600-\u06FF\u00C0-\u024F\s]/g;
      RE_DIGIT = /[0-9]/g;
      RE_LETTER = /[A-Za-z\u0600-\u06FF\u00C0-\u024F]/g;
    }

    function validateSrvName(v) {
      const s = String(v || '').trim();
      if (s.length < 8 || s.length > 24) {
        return tMsg('err_srv_name_len', 'Name must be 8–24 characters');
      }
      return '';
    }
    function validateJoinPass(v) {
      const s = String(v || '');
      if (s.length < 8 || s.length > 24) {
        return tMsg('err_join_pass_len', 'Password must be 8–24 characters');
      }
      if (countMatches(s, RE_DIGIT) < 1) {
        return tMsg('err_join_pass_digit', 'Need at least 1 digit');
      }
      if (countMatches(s, RE_SPECIAL) < 1) {
        return tMsg('err_join_pass_symbol', 'Need at least 1 symbol');
      }
      return '';
    }
    function validateOwnerPass(v) {
      const s = String(v || '');
      if (s.length < 30 || s.length > 64) {
        return tMsg('err_owner_pass_len', 'Owner password must be 30–64 characters');
      }
      if (countMatches(s, RE_SPECIAL) < 5) {
        return tMsg('err_owner_pass_symbol', 'Need at least 5 symbols');
      }
      if (countMatches(s, RE_DIGIT) < 5) {
        return tMsg('err_owner_pass_digit', 'Need at least 5 digits');
      }
      if (countMatches(s, RE_LETTER) < 5) {
        return tMsg('err_owner_pass_letter', 'Need at least 5 letters');
      }
      return '';
    }
    function validateMaxPlayers(v) {
      const n = Number(v);
      if (!Number.isFinite(n) || n < 2 || n > 32) {
        return tMsg('err_max_players', 'Players must be between 2 and 32');
      }
      return '';
    }

    // Live clear errors while typing (create + join)
    ['inp-srv-name', 'inp-srv-pass', 'inp-owner-pass', 'inp-join-srv', 'inp-join-pass'].forEach(function (id) {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('input', function () {
        const map = {
          'inp-srv-name': ['err-srv-name', validateSrvName],
          'inp-srv-pass': ['err-srv-pass', validateJoinPass],
          'inp-owner-pass': ['err-owner-pass', validateOwnerPass],
          'inp-join-srv': ['err-join-srv', validateSrvName],
          'inp-join-pass': ['err-join-pass', validateJoinPass]
        };
        const pair = map[id];
        if (!pair) return;
        const msg = pair[1](el.value);
        if (!msg) clearFieldErr(pair[0], el);
      });
      el.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.keyCode === 13) {
          e.preventDefault();
          e.stopPropagation();
        }
      });
    });

    // Join: same rules as create for name + join password
    _wireJoinValidate = function (ev) {
      try {
        if (ev) { ev.preventDefault(); ev.stopPropagation(); }
        const layerJoin = document.getElementById('layer-online-join');
        if (layerJoin) layerJoin.classList.remove('hidden');

        const nameEl = document.getElementById('inp-join-srv');
        const passEl = document.getElementById('inp-join-pass');
        const eName = validateSrvName(nameEl ? nameEl.value : '');
        const ePass = validateJoinPass(passEl ? passEl.value : '');
        setFieldErr('err-join-srv', nameEl, eName);
        setFieldErr('err-join-pass', passEl, ePass);
        if (eName || ePass) {
          const first = eName ? nameEl : passEl;
          if (first) {
            try { first.focus(); } catch (_) {}
            try { first.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (_) {}
          }
          return;
        }
        console.log('[UI] Online Join — validated, not implemented yet', {
          name: String(nameEl.value).trim()
        });
      } catch (err) {
        console.warn('[UI] join validate', err);
      }
    };
    if (btnJoinGo) btnJoinGo.onclick = _wireJoinValidate;

    const btnSrvCreate = document.getElementById('btn-srv-create');
    if (btnSrvCreate) {
      btnSrvCreate.onclick = function (ev) {
        try {
          if (ev) { ev.preventDefault(); ev.stopPropagation(); }
          // Keep layer visible always
          if (layerOnlineCreate) layerOnlineCreate.classList.remove('hidden');
          const card = document.getElementById('online-create-card');
          if (card) card.style.display = '';

          const nameEl = document.getElementById('inp-srv-name');
          const passEl = document.getElementById('inp-srv-pass');
          const ownerEl = document.getElementById('inp-owner-pass');
          const maxEl = document.getElementById('inp-max-players');

          clampMaxPlayers();

          const eName = validateSrvName(nameEl ? nameEl.value : '');
          const ePass = validateJoinPass(passEl ? passEl.value : '');
          const eOwner = validateOwnerPass(ownerEl ? ownerEl.value : '');
          const eMax = validateMaxPlayers(maxEl ? maxEl.value : '');

          setFieldErr('err-srv-name', nameEl, eName);
          setFieldErr('err-srv-pass', passEl, ePass);
          setFieldErr('err-owner-pass', ownerEl, eOwner);
          setFieldErr('err-max-players', maxEl, eMax);

          if (eName || ePass || eOwner || eMax) {
            const first = eName ? nameEl : (ePass ? passEl : (eOwner ? ownerEl : maxEl));
            if (first) {
              try { first.focus(); } catch (_) {}
              try { first.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (_) {}
            }
            return;
          }

          // Valid — do NOT create a server yet
          console.log('[UI] Online Create Server — validated, hosting not implemented', {
            name: String(nameEl.value).trim(),
            maxPlayers: Number(maxEl.value),
            globalChat: !!(document.getElementById('chk-global-chat') || {}).checked,
            privateChat: !!(document.getElementById('chk-private-chat') || {}).checked,
            botDifficulty: (document.getElementById('sel-bot-diff') || {}).value || 'medium'
          });
        } catch (err) {
          console.warn('[UI] create server validate', err);
          if (layerOnlineCreate) layerOnlineCreate.classList.remove('hidden');
        }
      };
    }

    document.getElementById('btn-next-offline').onclick = async () => {
      const name = (document.getElementById('inp-world-name').value || '').trim();
      const difficulty = document.getElementById('sel-difficulty').value || 'medium';
      if (!name) {
        const inp = document.getElementById('inp-world-name');
        if (inp) inp.focus();
        return;
      }
      try {
        localStorage.setItem(PENDING_KEY, JSON.stringify({
          name: name,
          difficulty: difficulty,
          mode: 'offline',
          at: Date.now()
        }));
      } catch (e) {
        console.error('pending world save failed', e);
      }
      // Prefer locked session, else settings default, else detect
      let orient = locked ? 'landscape' : (settings.orient === 'landscape' || settings.orient === 'portrait' ? settings.orient : detectOrient());
      rememberOrient(orient);
      try { await lockOrientNow(orient); } catch (_) {}
      location.href = 'select-country.html?from=create&orient=' + encodeURIComponent(orient);
    };

    document.querySelectorAll('.btn-back').forEach(btn => {
      btn.addEventListener('click', () => {
        const from = btn.getAttribute('data-back');
        if (from === 'settings' || from === 'worlds') showMain();
        else if (from === 'add') {
          layerAdd.classList.add('hidden');
          layerWorlds.classList.remove('hidden');
        } else if (from === 'online') {
          if (layerOnline) layerOnline.classList.add('hidden');
          layerAdd.classList.remove('hidden');
        } else if (from === 'online-create') {
          if (layerOnlineCreate) layerOnlineCreate.classList.add('hidden');
          if (layerOnline) layerOnline.classList.remove('hidden');
        } else if (from === 'online-join') {
          const layerJoin = document.getElementById('layer-online-join');
          if (layerJoin) layerJoin.classList.add('hidden');
          if (layerOnline) layerOnline.classList.remove('hidden');
        } else if (from === 'offline') {
          layerOffline.classList.add('hidden');
          layerAdd.classList.remove('hidden');
        } else if (from === 'edit-world') {
          layerEditWorld.classList.add('hidden');
          layerWorlds.classList.remove('hidden');
          editingWorldId = null;
          renderWorlds();
        } else if (from === 'confirm-delete') {
          layerConfirmDelete.classList.add('hidden');
          layerEditWorld.classList.remove('hidden');
        }
      });
    });

    
    function safeFileName(name) {
      return String(name || 'world').replace(/[^\w\u0600-\u06FF\-]+/g, '_').slice(0, 40) || 'world';
    }
    function downloadWokWorld(w) {
      if (!w) return;
      const payload = {
        format: 'WOK_WORLD',
        version: 1,
        exportedAt: Date.now(),
        world: w
      };
      const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = safeFileName(w.name) + '.WOKWORLD';
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    }
    function importWokFile(file) {
      if (!file) return;
      const reader = new FileReader();
      reader.onload = function () {
        try {
          const data = JSON.parse(String(reader.result || ''));
          let w = data && data.world ? data.world : data;
          if (!w || typeof w !== 'object') throw new Error('bad file');
          if (!w.id) w.id = 'w_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
          if (!w.name) w.name = (file.name || 'Imported').replace(/\.wokworld$/i, '');
          if (!w.mode) w.mode = 'offline';
          if (!w.game) w.game = {};
          const list = loadWorlds();
          const idx = list.findIndex(function (x) { return x.id === w.id; });
          if (idx >= 0) list[idx] = w;
          else list.push(w);
          saveWorlds(list);
          renderWorlds();
          layerOffline.classList.add('hidden');
          layerAdd.classList.add('hidden');
          showWorlds();
        } catch (e) {
          console.error('WOK import', e);
          alert((settings.lang === 'en') ? 'Invalid .WOKWORLD file' : 'ملف .WOKWORLD غير صالح');
        }
      };
      reader.readAsText(file);
    }
    const btnDl = document.getElementById('btn-download-wok');
    if (btnDl) {
      btnDl.onclick = function () {
        if (!editingWorldId) return;
        const w = loadWorlds().find(function (x) { return x.id === editingWorldId; });
        downloadWokWorld(w);
      };
    }
    const btnUp = document.getElementById('btn-upload-wok');
    const inpUp = document.getElementById('inp-upload-wok');
    function importWokText(text, nameHint) {
      try {
        const data = JSON.parse(String(text || ''));
        let w = data && data.world ? data.world : data;
        if (!w || typeof w !== 'object') throw new Error('bad');
        if (!w.id) w.id = 'w_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
        if (!w.name) w.name = String(nameHint || 'Imported').replace(/\.wokworld$/i, '');
        if (!w.mode) w.mode = 'offline';
        if (!w.game) w.game = {};
        const list = loadWorlds();
        const idx = list.findIndex(function (x) { return x.id === w.id; });
        if (idx >= 0) list[idx] = w;
        else list.push(w);
        saveWorlds(list);
        renderWorlds();
        try { layerOffline.classList.add('hidden'); } catch (_) {}
        try { layerAdd.classList.add('hidden'); } catch (_) {}
        showWorlds();
        return true;
      } catch (e) {
        console.error('WOK import text', e);
        alert((settings.lang === 'en') ? 'Invalid .WOKWORLD data' : (settings.lang === 'tr' ? 'Geçersiz .WOKWORLD' : 'بيانات .WOKWORLD غير صالحة'));
        return false;
      }
    }
    function openUploadPicker() {
      // R1.4 APK/WebView: <input type=file> often broken — offer Paste fallback
      var sheet = document.getElementById('upload-wok-sheet');
      if (!sheet) {
        sheet = document.createElement('div');
        sheet.id = 'upload-wok-sheet';
        sheet.style.cssText = 'display:none;position:fixed;inset:0;z-index:250;background:rgba(0,0,0,.55);align-items:center;justify-content:center;padding:16px;';
        sheet.innerHTML = '<div style="width:min(420px,94vw);background:linear-gradient(160deg,rgba(16,28,48,.98),rgba(8,14,28,.99));border:1px solid rgba(90,170,255,.45);border-radius:16px;padding:14px;color:#e8f2ff;">' +
          '<div style="font-weight:800;margin-bottom:8px;" id="upload-wok-title">Upload .WOKWORLD</div>' +
          '<p style="font-size:12px;color:#9fd0ff;line-height:1.4;margin:0 0 10px;" id="upload-wok-hint">File picker or paste JSON</p>' +
          '<textarea id="upload-wok-paste" rows="6" style="width:100%;box-sizing:border-box;border-radius:10px;border:1px solid rgba(90,170,255,.35);background:rgba(0,0,0,.35);color:#e8f2ff;padding:8px;font-size:12px;"></textarea>' +
          '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;">' +
          '<button type="button" class="menu-btn" id="upload-wok-file">File…</button>' +
          '<button type="button" class="menu-btn ok" id="upload-wok-paste-btn">Paste / Import</button>' +
          '<button type="button" class="menu-btn" id="upload-wok-close">Close</button>' +
          '</div></div>';
        document.body.appendChild(sheet);
        sheet.addEventListener('click', function (e) {
          if (e.target === sheet) { sheet.style.display = 'none'; }
        });
        document.getElementById('upload-wok-close').onclick = function () { sheet.style.display = 'none'; };
        document.getElementById('upload-wok-file').onclick = function () {
          if (inpUp) {
            try { inpUp.value = ''; inpUp.click(); } catch (err) { console.warn(err); }
          }
        };
        document.getElementById('upload-wok-paste-btn').onclick = function () {
          var ta = document.getElementById('upload-wok-paste');
          if (importWokText(ta && ta.value, 'Pasted')) {
            sheet.style.display = 'none';
            if (ta) ta.value = '';
          }
        };
      }
      var lang = settings.lang || 'ar';
      var title = document.getElementById('upload-wok-title');
      var hint = document.getElementById('upload-wok-hint');
      if (title) title.textContent = lang === 'en' ? 'Upload .WOKWORLD' : (lang === 'tr' ? '.WOKWORLD yükle' : 'رفع .WOKWORLD');
      if (hint) hint.textContent = lang === 'en'
        ? 'On some APKs the file picker fails — paste the file contents below, or try File.'
        : (lang === 'tr'
          ? 'Bazı APKlarda dosya seçici çalışmaz — içeriği yapıştırın veya Dosya deneyin.'
          : 'في بعض ملفات APK لا يعمل اختيار الملف — الصق محتوى الملف هنا أو جرّب «ملف».');
      sheet.style.display = 'flex';
    }
    if (btnUp) {
      btnUp.onclick = function (e) {
        try { e.preventDefault(); e.stopPropagation(); } catch (_) {}
        openUploadPicker();
      };
    }
    if (inpUp) {
      inpUp.setAttribute('accept', '.WOKWORLD,.wokworld,application/json,text/plain,*/*');
      inpUp.onchange = function () {
        const f = inpUp.files && inpUp.files[0];
        if (f) {
          importWokFile(f);
          var sheet = document.getElementById('upload-wok-sheet');
          if (sheet) sheet.style.display = 'none';
        }
        inpUp.value = '';
      };
    }


    document.getElementById('btn-save-world').onclick = () => {
      if (!editingWorldId) return;
      const name = (document.getElementById('inp-edit-name').value || '').trim();
      if (!name) {
        document.getElementById('inp-edit-name').focus();
        return;
      }
      const worlds = loadWorlds();
      const idx = worlds.findIndex(w => w.id === editingWorldId);
      if (idx < 0) {
        showWorlds();
        return;
      }
      worlds[idx].name = name;
      worlds[idx].updatedAt = Date.now();
      saveWorlds(worlds);
      showWorlds();
    };

    document.getElementById('btn-delete-world').onclick = () => {
      if (!editingWorldId) return;
      const worlds = loadWorlds();
      const w = worlds.find(x => x.id === editingWorldId);
      const t = (I18N[settings.lang] || I18N.en || I18N.ar || {});
      const msg = (t.delete_confirm || '').replace('{name}', (w && w.name) ? w.name : '—');
      const msgEl = document.getElementById('confirm-delete-msg');
      if (msgEl) msgEl.textContent = msg;
      layerEditWorld.classList.add('hidden');
      layerConfirmDelete.classList.remove('hidden');
    };

    document.getElementById('btn-cancel-delete').onclick = () => {
      layerConfirmDelete.classList.add('hidden');
      layerEditWorld.classList.remove('hidden');
    };

    document.getElementById('btn-confirm-delete').onclick = () => {
      if (!editingWorldId) {
        showWorlds();
        return;
      }
      const worlds = loadWorlds().filter(w => w.id !== editingWorldId);
      saveWorlds(worlds);
      editingWorldId = null;
      showWorlds();
    };

    // ── Settings categories ──
    function showCat(id) {
      document.querySelectorAll('.settings-cat').forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-cat') === id);
      });
      document.getElementById('panel-general').classList.toggle('hidden', id !== 'general');
      document.getElementById('panel-touch').classList.toggle('hidden', id !== 'touch');
      const pv = document.getElementById('panel-video');
      if (pv) pv.classList.toggle('hidden', id !== 'video');
    }
    const chkIslands = document.getElementById('chk-hide-islands');
    if (chkIslands) {
      chkIslands.checked = !!settings.hideSmallIslands;
      chkIslands.addEventListener('change', () => {
        settings.hideSmallIslands = !!chkIslands.checked;
        saveSettings(settings);
      });
    }
    const chkStats = document.getElementById('chk-map-stats');
    if (chkStats) {
      chkStats.checked = !!settings.showMapStats;
      chkStats.addEventListener('change', () => {
        settings.showMapStats = !!chkStats.checked;
        saveSettings(settings);
      });
    }
    document.getElementById('settings-cats').addEventListener('click', (e) => {
      const b = e.target.closest('.settings-cat');
      if (!b) return;
      showCat(b.getAttribute('data-cat'));
    });

    // Language
    document.getElementById('sel-lang').addEventListener('change', (e) => {
      const v = e.target.value;
      settings.lang = (window.WOK_I18N && WOK_I18N.normalizeLang) ? WOK_I18N.normalizeLang(v) : (v === 'en' || v === 'tr' ? v : 'ar');
      if (window.WOK_I18N && WOK_I18N.setLang) WOK_I18N.setLang(settings.lang);
      settings = saveSettings(settings) || settings;
      try {
        if (window.WOK_I18N && WOK_I18N.applyScene) WOK_I18N.applyScene(settings.lang);
        else applyI18n();
      } catch (_) { try { applyI18n(); } catch (__) {} }
      try { applyI18n(); } catch (_) {}
    });

    // Default orientation (persistent)
    document.getElementById('sel-orient').addEventListener('change', async (e) => {
      settings.orient = e.target.value === 'landscape' ? 'landscape' : 'portrait';
      saveSettings(settings);
      rememberOrient(settings.orient, true);
      await applyDefaultOrient(true);
    });

    // Sensitivity (pan + zoom) — global game settings, not per-world
    function bindSens(id, valId, key) {
      const el = document.getElementById(id);
      const val = document.getElementById(valId);
      if (!el) return;
      el.addEventListener('input', function () {
        const v = clampSens(el.value);
        el.value = v;
        if (val) val.textContent = v.toFixed(2);
        settings[key] = v;
        if (key === 'panSensitivity') {
          settings.sensitivity = v;
          try { if (engine.setPanSensitivity) engine.setPanSensitivity(v); } catch (_) {}
        }
        if (key === 'zoomSensitivity') {
          try { if (engine.setZoomSensitivity) engine.setZoomSensitivity(v); } catch (_) {}
        }
        saveSettings(settings);
      });
    }
    bindSens('rng-sens-pan', 'sens-pan-val', 'panSensitivity');
    bindSens('rng-sens-zoom', 'sens-zoom-val', 'zoomSensitivity');
    bindSens('rng-sens', 'sens-val', 'panSensitivity');

    const chkMuteB = document.getElementById('chk-mute-banners');
    if (chkMuteB) {
      chkMuteB.checked = !!settings.muteMapBanners;
      chkMuteB.addEventListener('change', function () {
        settings.muteMapBanners = !!chkMuteB.checked;
        saveSettings(settings);
      });
    }
    const rngBorder = document.getElementById('rng-border-detail');
    if (rngBorder) {
      rngBorder.addEventListener('input', function () {
        let v = Math.round(Number(rngBorder.value) || 32);
        v = Math.min(64, Math.max(15, v));
        settings.countryBorderDetail = v;
        const vb = document.getElementById('border-detail-val');
        if (vb) vb.textContent = String(v);
        saveSettings(settings);
      });
    }
    const rngRegion = document.getElementById('rng-region-detail');
    if (rngRegion) {
      rngRegion.addEventListener('input', function () {
        let v = Math.round(Number(rngRegion.value) || 32);
        v = Math.min(64, Math.max(15, v));
        settings.regionBorderDetail = v;
        const vr = document.getElementById('region-detail-val');
        if (vr) vr.textContent = String(v);
        saveSettings(settings);
      });
    }

    // ── Worlds ──
    function loadWorlds() {
      try {
        const raw = localStorage.getItem(WORLDS_KEY);
        const list = raw ? JSON.parse(raw) : [];
        return Array.isArray(list) ? list : [];
      } catch (_) { return []; }
    }
    function saveWorlds(list) {
      localStorage.setItem(WORLDS_KEY, JSON.stringify(list));
    }
    /** Recency key: last open wins, else update, else create */
    function worldRecency(w) {
      if (!w) return 0;
      return Number(w.lastOpenedAt || w.updatedAt || w.createdAt || 0) || 0;
    }
    /** Mark world as most recently opened → sorts to top of list */
    function touchWorldOpened(worldId) {
      if (!worldId) return;
      try {
        const list = loadWorlds();
        const idx = list.findIndex(function (x) { return x && x.id === worldId; });
        if (idx < 0) return;
        list[idx].lastOpenedAt = Date.now();
        list[idx].updatedAt = list[idx].updatedAt || list[idx].lastOpenedAt;
        saveWorlds(list);
      } catch (e) {
        console.warn('[worlds] touch open', e);
      }
    }
    function diffLabel(key) {
      const t = (I18N[settings.lang] || I18N.en || I18N.ar || {});
      return t[key] || key || '—';
    }
    function openEditWorld(world) {
      if (!world || !world.id) return;
      editingWorldId = world.id;
      layerWorlds.classList.add('hidden');
      layerEditWorld.classList.remove('hidden');
      const inp = document.getElementById('inp-edit-name');
      if (inp) {
        inp.value = world.name || '';
        setTimeout(() => inp.focus(), 60);
      }
      const diffEl = document.getElementById('edit-diff-ro');
      if (diffEl) diffEl.textContent = diffLabel(world.difficulty);
      const cEl = document.getElementById('edit-country-ro');
      if (cEl) cEl.textContent = world.country || '—';
    }
    function renderWorlds() {
      const t = (I18N[settings.lang] || I18N.en || I18N.ar || {});
      const worlds = loadWorlds();
      worldsList.innerHTML = '';
      if (!worlds.length) {
        const empty = document.createElement('div');
        empty.className = 'worlds-empty';
        empty.setAttribute('data-i18n', 'no_worlds');
        empty.textContent = t.no_worlds;
        worldsList.appendChild(empty);
        return;
      }
      // Most recently opened first (then updated, then created)
      const ordered = worlds.slice().sort(function (a, b) {
        return worldRecency(b) - worldRecency(a);
      });
      ordered.forEach((w) => {
        const el = document.createElement('div');
        el.className = 'world-item' + (w.victory ? ' victory' : '');
        el.setAttribute('data-id', w.id);

        const body = document.createElement('div');
        body.className = 'world-item-body';
        const nameEl = document.createElement('div');
        nameEl.className = 'world-item-name';
        nameEl.textContent = w.name || 'World';
        const meta = document.createElement('span');
        meta.className = 'meta';
        const modeTxt = w.mode === 'offline'
          ? (t.mode_offline || t.offline || 'Offline')
          : (w.mode === 'online'
            ? (t.mode_online || t.online || 'Online')
            : (w.mode || '—'));
        const bits = [modeTxt, diffLabel(w.difficulty)];
        if (w.country) bits.push(w.country);
        meta.textContent = bits.join(' · ');
        body.appendChild(nameEl);
        body.appendChild(meta);

        const editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.className = 'world-edit-btn';
        editBtn.textContent = t.edit;
        editBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          openEditWorld(w);
        });

        el.appendChild(body);
        el.appendChild(editBtn);
        el.addEventListener('click', async () => {
          if (!w || !w.id) return;
          touchWorldOpened(w.id);
          const orient = locked ? 'landscape' : detectOrient();
          rememberOrient(orient);
          try { await lockOrientNow(orient); } catch (_) {}
          location.href = 'game.html?id=' + encodeURIComponent(w.id) +
            '&orient=' + encodeURIComponent(orient);
        });
        worldsList.appendChild(el);
      });
    }

    // ── Orientation lock button + default ──
    const btnLand = document.getElementById('btn-landscape');
    let locked = false;

    async function tryLock(mode) {
      // mode: 'landscape' | 'portrait'
      try {
        const el = document.documentElement;
        if (el.requestFullscreen) await el.requestFullscreen();
        else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen();
        if (screen.orientation && screen.orientation.lock) {
          await screen.orientation.lock(mode);
          locked = mode === 'landscape';
          btnLand.classList.toggle('active', locked);
          const t = (I18N[settings.lang] || I18N.en || I18N.ar || {});
          btnLand.textContent = locked ? t.orient_btn_alt : t.orient_btn;
          rememberOrient(mode);
          setTimeout(refitMap, 150);
          return true;
        }
      } catch (e) {
        console.warn('orientation lock failed', e);
      }
      return false;
    }
    async function unlockOrientation() {
      try {
        if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock();
        if (document.exitFullscreen) await document.exitFullscreen();
        else if (document.webkitExitFullscreen) await document.webkitExitFullscreen();
      } catch (_) {}
      locked = false;
      btnLand.classList.remove('active');
      const t = (I18N[settings.lang] || I18N.en || I18N.ar || {});
      btnLand.textContent = t.orient_btn;
      rememberOrient('portrait');
      setTimeout(refitMap, 120);
    }

    async function applyDefaultOrient(force) {
      // Default orientation locks every screen (COC landscape / CR portrait)
      const want = settings.orient === 'landscape' ? 'landscape' : 'portrait';
      rememberOrient(want);
      if (want === 'landscape') {
        await tryLock('landscape');
      } else {
        try {
          if (screen.orientation && screen.orientation.lock) {
            const el = document.documentElement;
            if (!document.fullscreenElement) {
              if (el.requestFullscreen) await el.requestFullscreen();
            }
            await screen.orientation.lock('portrait');
            locked = false;
            btnLand.classList.remove('active');
            const t = (I18N[settings.lang] || I18N.en || I18N.ar || {});
            btnLand.textContent = t.orient_btn;
            rememberOrient('portrait');
            setTimeout(refitMap, 150);
          }
        } catch (e) {
          console.warn('portrait lock failed', e);
        }
      }
    }

    function applyMenuOrientUi(mode) {
      const want = mode === 'portrait' ? 'portrait' : 'landscape';
      settings.orient = want;
      saveSettings(settings);
      rememberOrient(want, true);
      locked = (want === 'landscape');
      if (btnLand) {
        const bag = (I18N[settings.lang] || I18N.en || I18N.ar || {});
        btnLand.classList.toggle('active', locked);
        btnLand.textContent = locked ? (bag.orient_btn_alt || bag.orientAlt || '⟳ طولي') : (bag.orient_btn || bag.orient || '⟳ عرض');
      }
      try {
        document.documentElement.setAttribute('data-wok-orient', want);
      } catch (_) {}
    }
    btnLand.addEventListener('click', async () => {
      // R1.4: toggle preferred orient; always update app state (APK lock often fails)
      const next = locked || settings.orient === 'landscape' ? 'portrait' : 'landscape';
      let ok = false;
      try {
        if (next === 'landscape') ok = await tryLock('landscape');
        else {
          await unlockOrientation();
          try {
            if (screen.orientation && screen.orientation.lock) {
              await screen.orientation.lock('portrait');
              ok = true;
            }
          } catch (_) {}
        }
      } catch (_) { ok = false; }
      applyMenuOrientUi(next);
      if (!ok) {
        // brief hint only if physical orientation mismatches
        let mismatch = false;
        try {
          mismatch = next === 'landscape'
            ? !(window.matchMedia && window.matchMedia('(orientation: landscape)').matches) && window.innerWidth < window.innerHeight
            : window.innerWidth >= window.innerHeight;
        } catch (_) {}
        if (mismatch && btnLand) {
          const bag = (I18N[settings.lang] || I18N.en || I18N.ar || {});
          btnLand.textContent = bag.rotate_hint || '↻';
          setTimeout(() => applyMenuOrientUi(settings.orient), 1800);
        }
      }
    });
    document.addEventListener('fullscreenchange', () => {
      if (!document.fullscreenElement && locked) {
        locked = false;
        btnLand.classList.remove('active');
        const t = (I18N[settings.lang] || I18N.en || I18N.ar || {});
        btnLand.textContent = t.orient_btn;
      }
    });

    // boot — language + orientation from saved settings
    try {
      if (window.WOK_I18N && WOK_I18N.applyScene) WOK_I18N.applyScene(settings.lang);
    } catch (_) {}
    applyI18n();
    // Re-apply after CSV refresh (embed is immediate; CSV may arrive later)
    if (window.WOK_I18N && WOK_I18N.onReady) {
      WOK_I18N.onReady(function () {
        try {
          if (window.WOK_I18N.applyScene) WOK_I18N.applyScene(settings.lang);
          applyI18n();
        } catch (_) {}
      });
    }
    if (window.WOK_I18N && WOK_I18N.load) {
      try {
        WOK_I18N.load('i18n/translation.csv').then(function () {
          try {
            if (window.WOK_I18N.applyScene) WOK_I18N.applyScene(settings.lang);
            applyI18n();
          } catch (_) {}
        });
      } catch (_) {}
    }
    try {
      var ls = document.getElementById('sel-lang');
      if (ls) {
        ls.value = settings.lang;
        if (ls.value !== settings.lang) {
          for (var i = 0; i < ls.options.length; i++) {
            if (ls.options[i].value === settings.lang) { ls.selectedIndex = i; break; }
          }
        }
      }
      var os = document.getElementById('sel-orient');
      if (os) os.value = settings.orient === 'portrait' ? 'portrait' : 'landscape';
    } catch (_) {}
    // Always apply saved orientation (settings.orient) on every scene open
    rememberOrient(settings.orient === 'landscape' ? 'landscape' : 'portrait', false);
    setTimeout(function () { applyDefaultOrient(false); }, 100);
    setTimeout(function () { applyDefaultOrient(false); }, 400);
    setTimeout(function () { applyDefaultOrient(false); }, 1000);

    // return from country select / deep-link to worlds
    try {
      const params = new URLSearchParams(location.search || '');
      const hash = (location.hash || '').replace(/^#/, '');
      if (params.get('worlds') === '1' || hash === 'worlds') {
        hideMainButtons();
        showWorlds();
      }
      // keep orient in storage; strip query for cleanliness
      if (params.get('orient') || params.get('worlds') || hash) {
        try {
          history.replaceState(null, '', location.pathname);
        } catch (_) {}
      }
    } catch (_) {}

    window.mapEngine = engine;
    window.wokworldSettings = settings;
  })();
