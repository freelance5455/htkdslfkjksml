/**
 * War of Kings — World news feed
 * Public (world) + Private (your forces) channels, with de-duplication.
 */
(function (global) {
  'use strict';

  function ensure(world) {
    if (!world.game) world.game = {};
    if (!world.game.news) world.game.news = [];
    if (!world.game.newsPrivate) world.game.newsPrivate = [];
    if (!world.game.newsHistory) world.game.newsHistory = {};
    if (!world.game.newsDedupe) world.game.newsDedupe = {};
    return world.game;
  }

  function regionLabel(engine, regionKey) {
    if (!engine) return String(regionKey);
    if (engine.regionByKey && engine.regionByKey.get) {
      const r = engine.regionByKey.get(String(regionKey));
      if (r) return r.name || r.key;
    }
    if (engine.regions) {
      for (let i = 0; i < engine.regions.length; i++) {
        if (String(engine.regions[i].key) === String(regionKey)) {
          return engine.regions[i].name || engine.regions[i].key;
        }
      }
    }
    return String(regionKey);
  }

  function histKey(a, b, region) {
    return String(region) + '|' + String(a) + '>' + String(b);
  }

  function pushHist(g, key, kind) {
    if (!g.newsHistory[key]) g.newsHistory[key] = [];
    g.newsHistory[key].push({ kind: kind, at: Date.now() });
    if (g.newsHistory[key].length > 20) g.newsHistory[key].shift();
  }

  function countKind(g, key, kind) {
    const arr = g.newsHistory[key] || [];
    let n = 0;
    for (let i = 0; i < arr.length; i++) if (arr[i].kind === kind) n++;
    return n;
  }

  function lastKind(g, key) {
    const arr = g.newsHistory[key] || [];
    return arr.length ? arr[arr.length - 1].kind : null;
  }

  /** Prevent same event within windowMs */
  function canEmit(g, dedupeKey, windowMs) {
    windowMs = windowMs || 60000;
    const t = Date.now();
    const prev = g.newsDedupe[dedupeKey] || 0;
    if (t - prev < windowMs) return false;
    g.newsDedupe[dedupeKey] = t;
    return true;
  }

  function addPublic(world, item) {
    const g = ensure(world);
    const dedupe = (item.type || '') + '|' + (item.meta && item.meta.region) + '|' + (item.meta && item.meta.attacker) + '|' + (item.title || '');
    if (!canEmit(g, 'pub:' + dedupe, 45000)) return null;
    const entry = {
      id: 'n_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      at: Date.now(),
      channel: 'public',
      title: item.title,
      body: item.body,
      type: item.type || 'battle',
      meta: item.meta || {}
    };
    g.news.unshift(entry);
    if (g.news.length > 150) g.news.length = 150;
    return entry;
  }

  function addPrivate(world, item) {
    const g = ensure(world);
    const dedupe = (item.meta && item.meta.kind) + '|' + (item.meta && item.meta.battleId) + '|' + (item.meta && item.meta.region) + '|' + (item.title || '');
    if (!canEmit(g, 'priv:' + dedupe, 8000)) return null;
    const entry = {
      id: 'p_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      at: Date.now(),
      channel: 'private',
      title: item.title,
      body: item.body,
      type: item.type || 'forces',
      meta: item.meta || {}
    };
    g.newsPrivate.unshift(entry);
    if (g.newsPrivate.length > 100) g.newsPrivate.length = 100;
    return entry;
  }

  function add(world, item) {
    return addPublic(world, item);
  }

  function remove(world, id) {
    const g = ensure(world);
    g.news = (g.news || []).filter(function (n) { return n.id !== id; });
    g.newsPrivate = (g.newsPrivate || []).filter(function (n) { return n.id !== id; });
  }

  function list(world, channel) {
    const g = ensure(world);
    if (channel === 'private') return (g.newsPrivate || []).slice();
    if (channel === 'public') return (g.news || []).slice();
    return (g.news || []).concat(g.newsPrivate || []).sort(function (a, b) { return b.at - a.at; });
  }

  function onBattleStart(world, engine, attacker, defender, regionKey, lang) {
    lang = lang || 'ar';
    const g = ensure(world);
    const place = regionLabel(engine, regionKey);
    const key = histKey(attacker, defender, regionKey);
    const attacks = countKind(g, key, 'attack');
    const again = attacks > 0;
    pushHist(g, key, 'attack');

    let title, body;
    if (lang === 'en') {
      title = again ? (attacker + ' attacks ' + place + ' again') : (attacker + ' strikes ' + place);
      body = again
        ? ('Forces of ' + attacker + ' entered ' + place + ' once more. Battle with ' + defender + ' underway — will they win this time?')
        : ('Forces of ' + attacker + ' entered ' + place + '. Fierce battle with ' + defender + ' — who will prevail?');
    } else {
      title = again ? ('قوات ' + attacker + ' تهاجم ' + place + ' مجدداً') : ('قوات ' + attacker + ' تدخل ' + place);
      body = again
        ? ('أرسلت قوات ' + attacker + ' قوة عسكرية إلى ' + place + ' «مجدداً». هل ستفوز هذه المرة؟')
        : ('قوات ' + attacker + ' دخلت ' + place + ' وتجري معركة طاحنة مع ' + defender + '، يا تُرى من سيكون المنتصر؟');
    }
    return addPublic(world, {
      title: title, body: body, type: 'battle_start',
      meta: { attacker: attacker, defender: defender, region: regionKey }
    });
  }

  function onBattleWin(world, engine, attacker, defender, regionKey, lang) {
    lang = lang || 'ar';
    const g = ensure(world);
    const place = regionLabel(engine, regionKey);
    const key = histKey(attacker, defender, regionKey);
    pushHist(g, key, 'win');
    const liberations = countKind(g, key, 'liberate');
    let title, body;
    if (lang === 'en') {
      title = attacker + ' seizes ' + place;
      body = liberations > 0
        ? (attacker + ' again drove ' + defender + ' from ' + place + ' and prepares occupation.')
        : (attacker + ' drove ' + defender + ' from ' + place + ' and prepares permanent occupation.');
    } else {
      title = attacker + ' تسيطر على ' + place;
      body = liberations > 0
        ? ('استطاعت ' + attacker + ' مجدداً طرد قوات ' + defender + ' من ' + place + ' وبدأت تجهّز للاحتلال الدائم.')
        : ('استطاعت ' + attacker + ' طرد قوات ' + defender + ' من ' + place + ' وبدأت تجهّز للاحتلال الدائم.');
    }
    return addPublic(world, {
      title: title, body: body, type: 'battle_win',
      meta: { attacker: attacker, defender: defender, region: regionKey }
    });
  }

  function onBattleLose(world, engine, attacker, defender, regionKey, lang) {
    lang = lang || 'ar';
    const place = regionLabel(engine, regionKey);
    const g = ensure(world);
    pushHist(g, histKey(attacker, defender, regionKey), 'lose');
    let title, body;
    if (lang === 'en') {
      title = defender + ' holds ' + place;
      body = (attacker + ' failed to take ' + place + '. ' + defender + ' remains in control.');
    } else {
      title = defender + ' تصمد في ' + place;
      body = ('فشلت قوات ' + attacker + ' في السيطرة على ' + place + '. ما زالت ' + defender + ' تسيطر.');
    }
    return addPublic(world, {
      title: title, body: body, type: 'battle_lose',
      meta: { attacker: attacker, defender: defender, region: regionKey }
    });
  }

  function onAnnex(world, engine, attacker, defender, regionKey, lang) {
    lang = lang || 'ar';
    const place = regionLabel(engine, regionKey);
    const g = ensure(world);
    pushHist(g, histKey(attacker, defender, regionKey), 'annex');
    let title, body;
    if (lang === 'en') {
      title = place + ' annexed by ' + attacker;
      body = (attacker + ' completed permanent occupation of ' + place + ' from ' + defender + '.');
    } else {
      title = 'ضم ' + place + ' إلى ' + attacker;
      body = ('أتمّت ' + attacker + ' الاحتلال الدائم لـ' + place + ' بعد انتزاعها من ' + defender + '.');
    }
    return addPublic(world, {
      title: title, body: body, type: 'annex',
      meta: { attacker: attacker, defender: defender, region: regionKey }
    });
  }

  function onLiberate(world, engine, liberator, occupier, regionKey, lang) {
    lang = lang || 'ar';
    const place = regionLabel(engine, regionKey);
    const g = ensure(world);
    pushHist(g, histKey(liberator, occupier, regionKey), 'liberate');
    let title, body;
    if (lang === 'en') {
      title = liberator + ' liberates ' + place;
      body = (liberator + ' expelled ' + occupier + ' from ' + place + ' and reclaimed it.');
    } else {
      title = liberator + ' تحرّر ' + place;
      body = ('طردت قوات ' + liberator + ' آخر قوات ' + occupier + ' من ' + place + ' وحرّرتها.');
    }
    return addPublic(world, {
      title: title, body: body, type: 'liberate',
      meta: { attacker: liberator, defender: occupier, region: regionKey }
    });
  }

  function onCounterAttack(world, engine, attacker, defender, regionKey, lang) {
    lang = lang || 'ar';
    const place = regionLabel(engine, regionKey);
    const g = ensure(world);
    pushHist(g, histKey(attacker, defender, regionKey), 'counter');
    let title, body;
    if (lang === 'en') {
      title = attacker + ' counter-attacks at ' + place;
      body = (attacker + ' opened another battle for ' + place + '. Can they retake it from ' + defender + '?');
    } else {
      title = attacker + ' تشن هجوماً مضاداً على ' + place;
      body = ('أرسلت ' + attacker + ' قوة عسكرية وبدأت معركة أخرى، هل ستستطيع تحرير ' + place + '؟');
    }
    return addPublic(world, {
      title: title, body: body, type: 'counter',
      meta: { attacker: attacker, defender: defender, region: regionKey }
    });
  }

  function reportAttack(world, engine, attacker, defender, regionKey, lang) {
    const g = ensure(world);
    const key = histKey(attacker, defender, regionKey);
    const last = lastKind(g, key);
    const revKey = histKey(defender, attacker, regionKey);
    const enemyAnnexed = countKind(g, revKey, 'annex') > 0 || countKind(g, revKey, 'win') > 0;
    if (enemyAnnexed || last === 'lose' || last === 'liberate') {
      return onCounterAttack(world, engine, attacker, defender, regionKey, lang);
    }
    return onBattleStart(world, engine, attacker, defender, regionKey, lang);
  }

  
  function clearChannel(world, channel) {
    const g = ensure(world);
    if (channel === 'private') g.newsPrivate = [];
    else g.news = [];
  }
  function clearAll(world) {
    const g = ensure(world);
    g.news = [];
    g.newsPrivate = [];
  }

global.WOK_News = {
    clearChannel: clearChannel,
    clearAll: clearAll,
    ensure: ensure,
    list: list,
    remove: remove,
    add: add,
    addPublic: addPublic,
    addPrivate: addPrivate,
    reportAttack: reportAttack,
    onBattleStart: onBattleStart,
    onBattleWin: onBattleWin,
    onBattleLose: onBattleLose,
    onCountryEliminated: function (world, engine, attacker, defender) {
      const g = ensure(world);
      const titleAr = 'عاجل';
      const bodyAr = 'عدد الدول المعترفة بالدولة ' + defender + ' اليوم وصل إلى 0 بعد أن احتلتها الدولة ' + attacker + '.';
      const titleEn = 'Breaking';
      const bodyEn = 'Countries recognizing ' + defender + ' reached 0 today after occupation by ' + attacker + '.';
      addPublic(world, {
        title: titleAr,
        body: bodyAr,
        titleEn: titleEn,
        bodyEn: bodyEn,
        type: 'eliminate',
        meta: { attacker: attacker, defender: defender }
      });
    },
    onAnnex: onAnnex,
    onLiberate: onLiberate,
    onCounterAttack: onCounterAttack
  };
})(typeof window !== 'undefined' ? window : globalThis);
