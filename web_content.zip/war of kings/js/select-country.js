  (function () {
    'use strict';

    const SETTINGS_KEY = 'wok_settings';
    const ORIENT_SESSION_KEY = 'wok_session_orient';

    const BLOCKED_START_COUNTRIES = {
      'Antarctica': true,
      'antarctica': true,
      'القارة القطبية الجنوبية': true,
      'قطب جنوبي': true
    };
    function isBlockedStartCountry(name) {
      if (!name) return false;
      const n = String(name).trim();
      if (BLOCKED_START_COUNTRIES[n]) return true;
      const low = n.toLowerCase();
      if (low === 'antarctica' || low.indexOf('antarctic') >= 0) return true;
      if (n.indexOf('القطب الجنوبي') >= 0 || n.indexOf('القطبية الجنوبية') >= 0) return true;
      return false;
    }


    function rememberOrient(mode, permanent) {
      if (mode !== 'landscape' && mode !== 'portrait') return;
      try { sessionStorage.setItem(ORIENT_SESSION_KEY, mode); } catch (_) {}
      try { localStorage.setItem(ORIENT_SESSION_KEY, mode); } catch (_) {}
      if (permanent) {
        try {
          const raw = localStorage.getItem(SETTINGS_KEY);
          const s = raw ? JSON.parse(raw) : {};
          s.orient = mode;
          localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
          if (typeof settings !== 'undefined') settings.orient = mode;
        } catch (_) {}
      }
    }
    function readSavedOrient() {
      try {
        const raw = localStorage.getItem(SETTINGS_KEY);
        if (raw) {
          const s = JSON.parse(raw);
          if (s && (s.orient === 'landscape' || s.orient === 'portrait')) return s.orient;
        }
      } catch (_) {}
      try {
        const q = new URLSearchParams(location.search || '').get('orient');
        if (q === 'landscape' || q === 'portrait') return q;
      } catch (_) {}
      try {
        const a = sessionStorage.getItem(ORIENT_SESSION_KEY);
        if (a === 'landscape' || a === 'portrait') return a;
      } catch (_) {}
      return null;
    }
    function readSessionOrient() { return readSavedOrient(); }
    function detectOrient() {
      try {
        if (screen.orientation && screen.orientation.type) {
          if (String(screen.orientation.type).indexOf('landscape') >= 0) return 'landscape';
          if (String(screen.orientation.type).indexOf('portrait') >= 0) return 'portrait';
        }
      } catch (_) {}
      try {
        if (window.matchMedia && window.matchMedia('(orientation: landscape)').matches) return 'landscape';
        if (window.matchMedia && window.matchMedia('(orientation: portrait)').matches) return 'portrait';
      } catch (_) {}
      return (window.innerWidth >= window.innerHeight) ? 'landscape' : 'portrait';
    }
    async function lockOrientNow(mode) {
      if (mode !== 'landscape' && mode !== 'portrait') return false;
      try {
        const el = document.documentElement;
        if (!document.fullscreenElement && !document.webkitFullscreenElement) {
          if (el.requestFullscreen) await el.requestFullscreen();
          else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen();
        }
      } catch (_) {}
      try {
        if (screen.orientation && screen.orientation.lock) {
          await screen.orientation.lock(mode);
          rememberOrient(mode);
          return true;
        }
      } catch (e) {
        console.warn('lockOrientNow failed', e);
      }
      rememberOrient(mode);
      return false;
    }

    function isEnUi() {
      const lang = (typeof settings !== 'undefined' && settings.lang) || 'ar';
      return lang === 'en' || lang === 'tr';
    }
    function _L(en, ar, tr) {
      const lang = (typeof settings !== 'undefined' && settings.lang) || 'ar';
      if (lang === 'en') return en;
      if (lang === 'tr') return (tr != null && tr !== '') ? tr : en;
      return ar;
    }
const I18N = (window.WOK_I18N && WOK_I18N.compat) ? WOK_I18N.compat() : { en: {}, ar: {} };
    function tKey(key, fallback) {
      if (window.WOK_I18N && WOK_I18N.t) {
        if (window.WOK_I18N.setLang) WOK_I18N.setLang((typeof settings !== 'undefined' && settings.lang) || 'ar');
        return WOK_I18N.t(key, fallback);
      }
      const lang = (typeof settings !== 'undefined' && settings.lang) || 'ar';
      const bag = I18N[lang] || I18N.ar || {};
      return (bag[key] != null && bag[key] !== '') ? bag[key] : (fallback != null ? fallback : key);
    }

    function loadSettings() {
      try {
        const raw = localStorage.getItem(SETTINGS_KEY);
        const d = raw ? JSON.parse(raw) : {};
        const sens = Number(d.sensitivity);
        return {
          lang: (window.WOK_I18N && WOK_I18N.normalizeLang) ? WOK_I18N.normalizeLang(d.lang) : (d.lang || 'ar'),
          orient: d.orient === 'landscape' ? 'landscape' : 'portrait',
          sensitivity: isFinite(sens) ? Math.min(2, Math.max(0.5, sens)) : 1
        };
      } catch (_) {
        return { lang: 'ar', orient: 'landscape', sensitivity: 1 };
      }
    }

    const settings = loadSettings();
    function buildT() {
      const lang = (window.WOK_I18N && WOK_I18N.normalizeLang) ? WOK_I18N.normalizeLang(settings.lang) : (settings.lang || 'ar');
      if (window.WOK_I18N && WOK_I18N.setLang) WOK_I18N.setLang(lang);
      if (window.WOK_I18N && WOK_I18N.applyScene) WOK_I18N.applyScene(lang);
      const base = (window.WOK_I18N && WOK_I18N.bundle) ? WOK_I18N.bundle(lang) : (I18N[lang] || {});
      const o = Object.assign({}, base);
      // function-style strings kept local (not in CSV)
      o.meta = function (regions, neighbors) {
        return lang === 'en'
          ? (regions + ' regions · ' + neighbors + ' neighbors')
          : (regions + ' أقاليم · ' + neighbors + ' جيران');
      };
      o.selected = function (n) {
        return lang === 'en' ? ('Selected: ' + n) : ('محدد: ' + n);
      };
      // ensure critical keys
      ['back','close','choose','title','sub','tapHint','loading','orient','eco','regions','coastal','neighbors'].forEach(function (k) {
        if (!o[k] && window.WOK_I18N) o[k] = WOK_I18N.t(k, k);
      });
      // ranks object for resource labels (also used via flat keys)
      o.ranks = o.ranks || {
        vl: o.vl || _L('Very low', 'قليل جدا', 'Çok düşük'),
        l:  o.l  || _L('Low', 'قليل', 'Düşük'),
        m:  o.m  || _L('Average', 'متوسط', 'Orta'),
        h:  o.h  || _L('High', 'كثير', 'Yüksek'),
        vh: o.vh || _L('Very high', 'كثير جدا', 'Çok yüksek')
      };
      return o;
    }
    let t = buildT();

    function applyI18n() {
      t = buildT();
      document.documentElement.lang = settings.lang;
      document.documentElement.dir = (window.WOK_I18N && WOK_I18N.isRtl) ? (WOK_I18N.isRtl(settings.lang) ? 'rtl' : 'ltr') : (settings.lang === 'ar' ? 'rtl' : 'ltr');
      const _set = function (id, key, fb) {
        const el = document.getElementById(id);
        if (!el) return;
        const v = (window.WOK_I18N && WOK_I18N.t) ? WOK_I18N.t(key, fb || el.textContent) : (t[key] || fb || el.textContent);
        if (v) el.textContent = v;
      };
      _set('btn-back', 'back', '‹ رجوع');
      document.querySelector('[data-i18n-title]').childNodes[0].textContent = t.title + ' ';
      document.querySelector('[data-i18n-sub]').textContent = t.sub;
      document.getElementById('lbl-eco').textContent = t.eco;
      document.getElementById('lbl-regions').textContent = t.regions;
      document.getElementById('lbl-coastal').textContent = t.coastal;
      document.getElementById('lbl-neighbors').textContent = t.neighbors;
      document.getElementById('btn-close').textContent = t.close || 'إغلاق';
      document.getElementById('btn-choose').textContent = t.choose || 'اختيار';
      document.getElementById('tap-hint').textContent = t.tapHint;
      document.getElementById('load-text').textContent = t.loading;
      const btnO = document.getElementById('btn-orient');
      if (!btnO.classList.contains('active')) btnO.textContent = t.orient;
      else btnO.textContent = t.orientAlt;
    }
    applyI18n();
    if (window.WOK_I18N && WOK_I18N.onReady) WOK_I18N.onReady(function () { applyI18n(); });

    const canvas = document.getElementById('map-canvas');
    const sheet = document.getElementById('country-sheet');
    const sheetDim = document.getElementById('sheet-dim');
    const loadOverlay = document.getElementById('load-overlay');
    const loadFill = document.getElementById('load-fill');
    const tapHint = document.getElementById('tap-hint');
    const btnOrient = document.getElementById('btn-orient');

    let selected = null;
    let orientLocked = false; // true when locked to landscape

    function rankLabel(v) {
      // Flat i18n keys (vl/l/m/h/vh) — never assume nested t.ranks
      const bag = t || {};
      const ranks = bag.ranks || {};
      const pick = function (k, fb) {
        if (ranks[k] != null && ranks[k] !== '') return ranks[k];
        if (bag[k] != null && bag[k] !== '') return bag[k];
        if (window.WOK_I18N && WOK_I18N.t) return WOK_I18N.t(k, fb);
        return fb;
      };
      const n = Number(v);
      if (!(n > 0.25)) return pick('vl', _L('Very low', 'قليل جدا'));
      if (n <= 0.5)  return pick('l',  _L('Low', 'قليل'));
      if (n <= 1.0)  return pick('m',  _L('Average', 'متوسط'));
      if (n <= 1.5)  return pick('h',  _L('High', 'كثير'));
      return pick('vh', _L('Very high', 'كثير جدا'));
    }
    function barPct(v) {
      return Math.max(4, Math.min(100, (Number(v) / 3) * 100));
    }
    function setRes(key, val) {
      try {
        const nEl = document.getElementById('res-' + key + '-n');
        const fEl = document.getElementById('res-' + key + '-f');
        const rEl = document.getElementById('res-' + key + '-r');
        if (nEl) nEl.textContent = Number(val).toFixed(2);
        if (fEl) fEl.style.width = barPct(val) + '%';
        if (rEl) rEl.textContent = rankLabel(val);
      } catch (e) {
        console.warn('[select-country] setRes', key, e);
      }
    }

    function refitMap() {
      if (!window.mapEngine) return;
      engine._resize && engine._resize();
      engine._clampCamera && engine._clampCamera();
      engine.setDirty && engine.setDirty();
    }

    function forceSheetOpen(open) {
      // Hardened for Android WebView: class + explicit style + reflow
      if (open) {
        if (sheetDim) {
          sheetDim.classList.add('open');
          sheetDim.style.display = 'block';
          sheetDim.style.visibility = 'visible';
          sheetDim.style.pointerEvents = 'auto';
          sheetDim.style.zIndex = '100';
        }
        sheet.classList.add('open');
        sheet.style.display = 'block';
        sheet.style.visibility = 'visible';
        sheet.style.pointerEvents = 'auto';
        sheet.style.zIndex = '110';
        // force reflow so WebView commits the layer
        void sheet.offsetHeight;
      } else {
        sheet.classList.remove('open');
        sheet.style.display = '';
        sheet.style.visibility = '';
        sheet.style.pointerEvents = '';
        sheet.style.zIndex = '';
        if (sheetDim) {
          sheetDim.classList.remove('open');
          sheetDim.style.display = '';
          sheetDim.style.visibility = '';
          sheetDim.style.pointerEvents = '';
          sheetDim.style.zIndex = '';
        }
      }
    }

    function openCountry(name) {
      if (!name) return;
      try {
        if (engine.resolveCountryName) name = engine.resolveCountryName(name) || name;
      } catch (_) {}
      if (isBlockedStartCountry(name)) {
        selected = null;
        const lang = _L('en', 'ar');
        const msg = lang === 'en'
          ? 'Antarctica is not a playable country.'
          : 'القارة القطبية الجنوبية ليست دولة قابلة للاختيار.';
        try {
          const hint = document.getElementById('tap-hint');
          if (hint) hint.textContent = msg;
        } catch (_) {}
        forceSheetOpen(false);
        if (engine.clearAllCountryStyles) engine.clearAllCountryStyles();
        return;
      }
      selected = name;

      // Batch style changes (silent) then one dirty — keeps pan smooth
      try {
        if (engine.clearAllCountryStyles) engine.clearAllCountryStyles(true);
        if (engine.setCountryFill) engine.setCountryFill(name, 'rgba(90,170,255,0.35)', true);
        if (engine.setCountryBorder) engine.setCountryBorder(name, 'rgba(130,200,255,0.95)', true);
        if (engine.setDirty) engine.setDirty();
      } catch (e) {
        console.warn('[select-country] style', e);
      }

      try {
        document.getElementById('sheet-name').textContent = name;
        const regions = (engine.getCountryRegions && engine.getCountryRegions(name)) || [];
        const coastal = engine.getCountryCoastalCount ? engine.getCountryCoastalCount(name) : 0;
        const neighbors = (engine.getCountryLandNeighbors && engine.getCountryLandNeighbors(name)) || [];
        const metaEl = document.getElementById('sheet-meta');
        if (metaEl) metaEl.innerHTML = (t.meta ? t.meta(regions.length, neighbors.length) : (regions.length + ' · ' + neighbors.length));
        const sr = document.getElementById('stat-regions');
        if (sr) sr.textContent = String(regions.length);
        const sc = document.getElementById('stat-coastal');
        if (sc) sc.textContent = String(coastal);
        const sn = document.getElementById('stat-neighbors');
        if (sn) sn.textContent = String(neighbors.length);

        const res = (engine.getCountryResources && engine.getCountryResources(name)) || { gold: 0, iron: 0, oil: 0 };
        setRes('gold', res.gold);
        setRes('iron', res.iron);
        setRes('oil', res.oil);
      } catch (e) {
        console.warn('[select-country] fill sheet', e);
      }

      // Open panel after data is ready (requestAnimationFrame helps WebView paint)
      requestAnimationFrame(function () {
        forceSheetOpen(true);
        if (tapHint) tapHint.textContent = t.selected ? t.selected(name) : name;
      });
    }

    function closeSheet() {
      selected = null;
      forceSheetOpen(false);
      try {
        if (engine.clearAllCountryStyles) engine.clearAllCountryStyles();
      } catch (_) {}
      if (tapHint) tapHint.textContent = t.tapHint || '';
    }

    // ── MapEngine: official onTap only (no onLongPress on this screen) ──
    const engine = new MapEngine(canvas, {
      tapMaxMove: 36,
      onTap: function (hit) {
        if (!hit || !hit.country) { closeSheet(); return; }
        openCountry(hit.country);
      }
      // intentionally NO onLongPress → normal tap in both orientations
    });

    if (engine.setPanSensitivity) engine.setPanSensitivity(settings.sensitivity);

    function startMapLoad() {
      const btnRetry = document.getElementById('btn-load-retry');
      if (btnRetry) btnRetry.classList.remove('show');
      document.getElementById('load-text').textContent = t.loading || '…';
      loadOverlay.classList.remove('hide');
      loadFill.style.width = '0%';
      engine.load(
        'data/countries-110m.json',
        'data/countries-50m.json',
        'data/regions.json',
        {
          onProgress: function (p) { loadFill.style.width = Math.round(p * 100) + '%'; },
          terrainQuality: 'low'
        }
      ).then(function () {
        loadFill.style.width = '100%';
        setTimeout(function () { loadOverlay.classList.add('hide'); }, 150);
        setTimeout(function () { applyDefaultOrient(); }, 120);
        setTimeout(function () { applyDefaultOrient(); }, 500);
      }).catch(function (err) {
        console.error(err);
        document.getElementById('load-text').textContent =
          (isEnUi()) ? 'Failed to load' : 'فشل التحميل';
        if (btnRetry) {
          btnRetry.textContent = (isEnUi()) ? 'Retry' : 'إعادة المحاولة';
          btnRetry.classList.add('show');
        }
      });
    }
    applyDefaultOrient(); // early — keep landscape/portrait from previous page
    startMapLoad();
    document.getElementById('btn-load-retry').addEventListener('click', startMapLoad);

    // ── Orientation toggle (same model as main.html) ──
    async function tryLock(mode) {
      try {
        const el = document.documentElement;
        if (el.requestFullscreen) await el.requestFullscreen();
        else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen();
        if (screen.orientation && screen.orientation.lock) {
          await screen.orientation.lock(mode);
          orientLocked = (mode === 'landscape');
          btnOrient.classList.toggle('active', orientLocked);
          btnOrient.textContent = orientLocked ? t.orientAlt : t.orient;
          rememberOrient(mode);
          setTimeout(refitMap, 160);
          return true;
        }
      } catch (e) {
        console.warn('orientation lock failed', e);
      }
      return false;
    }

    async function unlockOrientation() {
      try {
        if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock();
        if (document.exitFullscreen) await document.exitFullscreen();
        else if (document.webkitExitFullscreen) await document.webkitExitFullscreen();
      } catch (_) {}
      orientLocked = false;
      btnOrient.classList.remove('active');
      btnOrient.textContent = t.orient;
      rememberOrient('portrait');
      setTimeout(refitMap, 120);
    }

    async function applyDefaultOrient() {
      const want = (settings && settings.orient === 'landscape') ? 'landscape'
        : (settings && settings.orient === 'portrait') ? 'portrait'
        : (readSavedOrient() || 'portrait');
      rememberOrient(want, false);
      try {
        await lockOrientNow(want);
        orientLocked = (want === 'landscape');
        if (btnOrient) {
          const t = (window.WOK_I18N && WOK_I18N.bundle) ? WOK_I18N.bundle(settings.lang) : {};
          btnOrient.classList.toggle('active', orientLocked);
          btnOrient.textContent = orientLocked ? (t.orientAlt || t.orient_btn_alt || '⟳') : (t.orient || t.orient_btn || '⟳');
        }
      } catch (e) {
        console.warn('applyDefaultOrient', e);
      }
    }

    btnOrient.addEventListener('click', async function () {
      if (orientLocked) {
        // return to portrait
        try {
          const el = document.documentElement;
          if (!document.fullscreenElement) {
            if (el.requestFullscreen) await el.requestFullscreen();
            else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen();
          }
          if (screen.orientation && screen.orientation.lock) {
            await screen.orientation.lock('portrait');
            orientLocked = false;
            btnOrient.classList.remove('active');
            btnOrient.textContent = t.orient;
            rememberOrient('portrait');
            setTimeout(refitMap, 160);
            return;
          }
        } catch (e) {
          console.warn('portrait lock failed', e);
        }
        // fallback: unlock
        await unlockOrientation();
      } else {
        const ok = await tryLock('landscape');
        if (!ok) {
          btnOrient.textContent = t.rotateHint;
          setTimeout(function () {
            if (!orientLocked) btnOrient.textContent = t.orient;
          }, 2200);
        }
      }
    });

    document.addEventListener('fullscreenchange', function () {
      if (!document.fullscreenElement && orientLocked) {
        orientLocked = false;
        btnOrient.classList.remove('active');
        btnOrient.textContent = t.orient;
      }
    });
    window.addEventListener('orientationchange', function () {
      setTimeout(refitMap, 160);
    });

    document.getElementById('btn-close').addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation(); closeSheet();
    });
    sheetDim.addEventListener('click', closeSheet);

    document.getElementById('btn-choose').addEventListener('click', function (e) {
      if (isBlockedStartCountry(selected)) {
        const lang = _L('en', 'ar');
        alert(lang === 'en'
          ? 'Antarctica is not a playable country.'
          : 'القارة القطبية الجنوبية ليست دولة قابلة للاختيار.');
        return;
      }
      e.preventDefault(); e.stopPropagation();
      if (!selected) return;
      const PENDING_KEY = 'wok_pending_world';
      const WORLDS_KEY = 'wok_worlds';
      let pending = null;
      try {
        const raw = localStorage.getItem(PENDING_KEY);
        pending = raw ? JSON.parse(raw) : null;
      } catch (_) { pending = null; }

      try {
        localStorage.setItem('wok_selected_country', selected);
        localStorage.setItem('wok_selected_country_meta', JSON.stringify({
          country: selected,
          resources: engine.getCountryResources ? engine.getCountryResources(selected) : null,
          regions: (engine.getCountryRegions ? engine.getCountryRegions(selected) : []) || [],
          at: Date.now()
        }));
      } catch (_) {}

      const leaveOrient = orientLocked ? 'landscape' : detectOrient();
      rememberOrient(leaveOrient);

      function goMain(withWorlds) {
        const q = withWorlds ? 'worlds=1&orient=' : 'orient=';
        location.href = 'main.html?' + q + encodeURIComponent(leaveOrient);
      }

      // re-lock under this user gesture before navigating away
      lockOrientNow(leaveOrient).then(function () {
        if (pending && pending.name) {
          let worlds = [];
          try {
            const rawW = localStorage.getItem(WORLDS_KEY);
            worlds = rawW ? JSON.parse(rawW) : [];
            if (!Array.isArray(worlds)) worlds = [];
          } catch (_) { worlds = []; }
          const now = Date.now();
          const world = {
            id: 'w_' + now + '_' + Math.random().toString(36).slice(2, 9),
            name: String(pending.name).trim() || 'World',
            difficulty: pending.difficulty || 'medium',
            mode: pending.mode || 'offline',
            country: selected,
            createdAt: now,
            updatedAt: now,
            lastOpenedAt: now,
            game: {
              version: 1,
              playerCountry: selected,
              stockpile: {},
              stockpileInitialized: false,
              occupied: {}
            }
          };
          worlds.push(world);
          try {
            localStorage.setItem(WORLDS_KEY, JSON.stringify(worlds));
            localStorage.removeItem(PENDING_KEY);
          } catch (err) {
            console.error('save world failed', err);
          }
          // Enter the new world immediately
          location.href = 'game.html?id=' + encodeURIComponent(world.id) +
            '&orient=' + encodeURIComponent(leaveOrient);
          return;
        }
        goMain(false);
      });
    });

    document.getElementById('btn-back').addEventListener('click', function () {
      const leaveOrient = orientLocked ? 'landscape' : detectOrient();
      rememberOrient(leaveOrient);
      const params = new URLSearchParams(location.search || '');
      lockOrientNow(leaveOrient).then(function () {
        if (params.get('from') === 'create') {
          try { localStorage.removeItem('wok_pending_world'); } catch (_) {}
          location.href = 'main.html?worlds=1&orient=' + encodeURIComponent(leaveOrient);
          return;
        }
        location.href = 'main.html?orient=' + encodeURIComponent(leaveOrient);
      });
    });

    // live settings sync if changed in another tab later
    window.addEventListener('storage', function (e) {
      if (e.key !== SETTINGS_KEY) return;
      const s = loadSettings();
      settings.lang = s.lang;
      settings.orient = s.orient;
      settings.sensitivity = s.sensitivity;
      applyI18n();
      if (engine.setPanSensitivity) engine.setPanSensitivity(settings.sensitivity);
    });

    window.mapEngine = engine;
    window.wokSettings = settings;
  })();
