/**
 * map-ui-bridge.js — PER-1.4.3
 * Bridge between heavy UI panels and MapEngine render pause.
 * game.js still owns panel lifecycle; this exposes a stable API for tooling/index.
 */
(function (global) {
  'use strict';

  var HEAVY_IDS = [
    'news-panel', 'army-panel', 'market-panel', 'builds-panel', 'build-buy-panel',
    'region-army-sheet', 'country-info', 'confirm-clear-sheet', 'alerts-sheet', 'move-sheet'
  ];

  function isHeavyOpen() {
    for (var i = 0; i < HEAVY_IDS.length; i++) {
      var el = document.getElementById(HEAVY_IDS[i]);
      if (!el) continue;
      if (el.classList.contains('open')) return true;
      if (el.id === 'confirm-clear-sheet' && !el.classList.contains('hidden')) return true;
    }
    return false;
  }

  function sync(engine) {
    if (!engine || typeof engine.setRenderPaused !== 'function') return;
    try { engine.setRenderPaused(isHeavyOpen()); } catch (_) {}
  }

  global.WOK_MapUiBridge = {
    HEAVY_IDS: HEAVY_IDS,
    isHeavyOpen: isHeavyOpen,
    sync: sync
  };
})(typeof window !== 'undefined' ? window : this);
