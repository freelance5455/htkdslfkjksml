/**
 * Terrain: region types → country dominant = majority vote.
 * Far: one country color. Near: per-region.
 * Exceptions: Alaska ice; large Canadian arctic islands ice.
 */
(function (global) {
  'use strict';

  const RGB = {
    plains:        [120, 150, 80],
    forest:        [40, 110, 55],
    spruce:        [28, 78, 48],
    desert:        [210, 175, 95],
    hills:         [130, 125, 70],
    mountains:     [105, 100, 95],
    ice:           [210, 225, 235],
    ice_mountains: [175, 190, 210],
    tundra:        [155, 168, 158],
    swamp:         [55, 95, 70],
    savanna:       [170, 160, 70],
    tropical:      [30, 130, 70]
  };

  const regionTerrainMap = new Map();
  const countryDominant = new Map();
  let ready = true;
  let progress = 1;
  let quality = 'med';

  function hash(n) {
    n = Math.imul(n ^ (n >>> 16), 0x45d9f3b);
    n = Math.imul(n ^ (n >>> 16), 0x45d9f3b);
    return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
  }

  function colorFor(type) {
    const r = RGB[type] || RGB.plains;
    return 'rgb(' + r[0] + ',' + r[1] + ',' + r[2] + ')';
  }

  function isAlaska(country, name, lat, lon) {
    if (!/united states/i.test(country || '')) return false;
    if (/alaska/i.test(name || '')) return true;
    return lat > 50 && lon < -129 && lon > -172;
  }

  function isCanadianArcticIsland(country, name, lat, lon) {
    if (!/canada/i.test(country || '')) return false;
    if (/baffin|ellesmere|victoria island|banks island|devon|somerset|axel|melville/i.test(name || '')) return true;
    return lat > 65 && lon < -60 && lon > -125;
  }

  /** Hard desert countries — almost every region is desert */
  function isDesertCountry(n) {
    return /saudi arabia|yemen|oman|kuwait|qatar|bahrain|united arab emirates|uae|egypt|libya|algeria|mauritania|mali|niger|chad|sudan|western sahara|iraq|syria|jordan|israel|palestine/.test(n);
  }

  function baseRegionTerrain(country, name, lat, lon, id) {
    if (isAlaska(country, name, lat, lon)) {
      return lat > 60 ? 'ice_mountains' : 'ice';
    }
    if (isCanadianArcticIsland(country, name, lat, lon)) {
      return 'ice';
    }

    const n = (country || '').toLowerCase();
    const a = lat || 0;
    const h = hash((id | 0) * 2654435761);

    // ── Desert belt: force desert majority ──
    if (isDesertCountry(n)) {
      // ~85% desert, rare hills
      return h > 0.85 ? 'hills' : 'desert';
    }

    // ── USA (continental): plains/forest — NOT desert majority ──
    if (/united states/i.test(n)) {
      // Southwest corner can be desert (secondary only)
      if (lat < 38 && lat > 28 && lon < -105 && lon > -125 && h > 0.55) return 'desert';
      if (lat > 40 && lon < -105) return h > 0.5 ? 'mountains' : 'hills';
      if (lon < -95) return h > 0.45 ? 'plains' : 'forest';
      return h > 0.5 ? 'forest' : 'plains';
    }

    // ── Canada ──
    if (/canada/i.test(n)) {
      if (a > 60) return h > 0.5 ? 'tundra' : 'spruce';
      return h > 0.45 ? 'spruce' : 'forest';
    }

    // ── Russia / Greenland / Norway / Finland / Antarctica → ice ──
    if (/russia|greenland|norway|finland|antarctica/i.test(n)) {
      if (a > 62) return h > 0.4 ? 'ice_mountains' : 'ice';
      if (a > 55) return h > 0.45 ? 'ice' : 'tundra';
      return h > 0.55 ? 'tundra' : 'ice';
    }

    // ── Tropical ──
    if (/brazil|congo|indonesia|malaysia|colombia|peru|venezuela|ecuador|papua/.test(n)) {
      return h > 0.7 ? 'swamp' : (h > 0.35 ? 'tropical' : 'forest');
    }

    // ── Australia: desert majority ──
    if (/australia/i.test(n)) {
      return h > 0.75 ? 'savanna' : (h > 0.55 ? 'plains' : 'desert');
    }

    // ── China ──
    if (/china/i.test(n)) {
      if (lon < 95 && lat > 35) return h > 0.4 ? 'desert' : 'hills';
      return h > 0.5 ? 'hills' : 'forest';
    }

    // ── India / SE Asia ──
    if (/india|japan|vietnam|thailand|myanmar|bangladesh|philippines|korea/.test(n)) {
      return h > 0.55 ? 'tropical' : 'forest';
    }

    // ── Europe ──
    if (/france|germany|poland|ukraine|spain|italy|united kingdom|britain|ireland|romania|greece|portugal|netherlands|belgium|austria|czech|hungary|serbia|sweden|denmark/.test(n)) {
      if (a > 60) return 'spruce';
      return h > 0.5 ? 'forest' : 'plains';
    }

    if (/turkey|iran|afghanistan|pakistan/.test(n)) {
      return h > 0.55 ? 'mountains' : (h > 0.3 ? 'hills' : 'plains');
    }

    if (/mexico|argentina|chile|south africa/.test(n)) {
      return h > 0.55 ? 'hills' : 'plains';
    }

    if (/ethiopia|kenya|tanzania|nigeria|ghana|cameroon|angola|namibia|botswana|zimbabwe|mozambique/.test(n)) {
      return h > 0.55 ? 'savanna' : (h > 0.3 ? 'plains' : 'tropical');
    }

    // generic
    if (a > 55) return h > 0.5 ? 'spruce' : 'forest';
    if (a > 35) return h > 0.5 ? 'forest' : 'plains';
    if (a > 15) return h > 0.55 ? 'savanna' : 'plains';
    return h > 0.5 ? 'tropical' : 'forest';
  }

  function computeFromRegions(regions) {
    regionTerrainMap.clear();
    countryDominant.clear();
    const counts = new Map();

    for (let i = 0; i < regions.length; i++) {
      const r = regions[i];
      const key = String(r.key != null ? r.key : r.id);
      const country = r.country || '';
      const lat = r.lat != null ? r.lat : 0;
      const lon = r.lon != null ? r.lon : 0;
      const t = baseRegionTerrain(country, r.name, lat, lon, r.id | 0);
      regionTerrainMap.set(key, t);

      if (!counts.has(country)) counts.set(country, new Map());
      const cm = counts.get(country);
      cm.set(t, (cm.get(t) || 0) + 1);
    }

    for (const [country, cm] of counts) {
      let best = 'plains', bestN = -1;
      for (const [t, n] of cm) {
        if (n > bestN) { bestN = n; best = t; }
      }
      // Canada: green (spruce/forest) vs ice — pick spruce if greens win
      if (/canada/i.test(country)) {
        const g = (cm.get('spruce') || 0) + (cm.get('forest') || 0);
        const ice = (cm.get('ice') || 0) + (cm.get('ice_mountains') || 0) + (cm.get('tundra') || 0);
        if (g >= ice) best = (cm.get('spruce') || 0) >= (cm.get('forest') || 0) ? 'spruce' : 'forest';
      }
      // Russia, Greenland, Norway, Finland, Antarctica → dominant ice
      if (/russia|greenland|norway|finland|antarctica/i.test(country)) {
        best = 'ice';
      }
      countryDominant.set(country, best);
    }

    console.log('[Terrain] Saudi=', countryDominant.get('Saudi Arabia'),
      'Egypt=', countryDominant.get('Egypt'),
      'USA=', countryDominant.get('United States of America'),
      'Canada=', countryDominant.get('Canada'));
  }

  function dominantColor(countryName) {
    return colorFor(countryDominant.get(countryName) || 'plains');
  }

  function regionTerrain(country, lat, lon, regionId) {
    return baseRegionTerrain(country, '', lat, lon, regionId);
  }

  function terrainForRegionKey(key) {
    return regionTerrainMap.get(String(key)) || 'plains';
  }

  function colorForRegionKey(key) {
    return colorFor(terrainForRegionKey(key));
  }

  function buildAll(opts) {
    opts = opts || {};
    if (opts.quality) quality = opts.quality;
    ready = true;
    progress = 1;
    if (opts.onProgress) opts.onProgress(1);
    return Promise.resolve();
  }

  global.Terrain = {
    buildAll,
    computeFromRegions,
    dominantColor,
    regionTerrain,
    terrainForRegionKey,
    colorForRegionKey,
    colorFor,
    isSplit: function () { return false; },
    getWorldCanvas: function () { return null; },
    oceanColor: function () { return 'rgb(12,42,74)'; },
    warmPatterns: function () {},
    getPattern: function () { return null; },
    RGB,
    get ready() { return ready; },
    get progress() { return progress; },
    get quality() { return quality; },
    setQuality: function (q) { if (q) quality = q; }
  };
})(window);
