/**
 * War of Kings — Lightweight bot controller
 *
 * Goals:
 *  - Player FEELS the world is alive; full sim of every nation is NOT required.
 *  - 360 day-groups: day % 360 selects the group (~one country every couple days).
 *  - Interaction priority: if A hits B, B is forced into the next decision slot.
 *  - Only near-player / on-screen / priority bots do real work. Far bots are idle.
 *  - Cheap: no full-country sweeps every tick.
 */
(function (global) {
  'use strict';

  const MS_DAY = 10000;
  const GROUPS = 10; // each game-day: one group of countries decides
  const DIFF_IQ = {
    very_easy: 0.22,
    easy: 0.4,
    medium: 0.62,
    hard: 0.8,
    very_hard: 0.95
  };
  const INF = 'WOK:MILITARY.UNIT.LAND.INFANTRY';
  const TANK = 'WOK:MILITARY.UNIT.LAND.TANK';
  const GOLD = 'WOK:ECONOMY.MATERIAL.GOLD.BAR';
  const IRON = 'WOK:ECONOMY.MATERIAL.IRON.INGOT';
  const OIL = 'WOK:ECONOMY.MATERIAL.OIL.BARREL';
  const BLD_GOLD = 'WOK:ECONOMY.BUILDING.MINE.GOLD';
  const BLD_IRON = 'WOK:ECONOMY.BUILDING.MINE.IRON';
  const BLD_OIL = 'WOK:ECONOMY.BUILDING.MINE.OIL';
  const RES_RECRUIT = 'WOK:RESEARCH.MILITARY.RECRUIT';
  const RES_POWDER = 'WOK:RESEARCH.MILITARY.POWDER_FORCE';

  function iq(world) {
    const d = (world && world.difficulty) || 'medium';
    return DIFF_IQ[d] != null ? DIFF_IQ[d] : 0.62;
  }

  function gameDay(world) {
    const start = (world.game && world.game.startedAt) || world.createdAt || Date.now();
    return Math.max(0, Math.floor((Date.now() - start) / MS_DAY));
  }

  function hashCountry(name) {
    let h = 0;
    const s = String(name || '');
    for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    return Math.abs(h) % GROUPS;
  }

  function ensure(world) {
    if (!world.game) world.game = {};
    const g = world.game;
    if (!g.botStates) g.botStates = {};
    if (!g.botBuildings) g.botBuildings = {};
    if (!g.botStock) g.botStock = {};
    if (!g.botPriority) g.botPriority = []; // countries forced next
    if (!g.botCache) g.botCache = { neighbors: null, list: null, dayBuilt: -1 };
    // Lost homeland regions the bot still claims and may try to retake
    if (!g.botClaims) g.botClaims = {}; // { country: { regionKey: { lostAt, attempts } } }
    return g;
  }

  function ensureArmy(g, key) {
    key = String(key);
    if (!g.regionArmies) g.regionArmies = {};
    if (!g.regionArmies[key]) g.regionArmies[key] = {};
    return g.regionArmies[key];
  }

  function addUnits(army, id, n) {
    if (!army[id]) army[id] = { count: 0, active: 0 };
    army[id].count += n;
    army[id].active = army[id].count;
  }

  function armyPower(army) {
    if (!army || !global.WOK) return 0;
    let p = 0;
    const keys = Object.keys(army);
    for (let i = 0; i < keys.length; i++) {
      const id = keys[i];
      const u = global.WOK.getUnit(id);
      const slot = army[id];
      if (!u || !slot) continue;
      p += (Number(u.power) || 10) * (slot.active != null ? slot.active : slot.count);
    }
    return p;
  }

  function countryRegions(engine, c) {
    if (engine.getCountryRegions) return engine.getCountryRegions(c) || [];
    return [];
  }

  function getBotStock(g, c, res) {
    const bag = g.botStock[c] || (g.botStock[c] = {});
    return bag[res] || 0;
  }
  function setBotStock(g, c, res, v) {
    const bag = g.botStock[c] || (g.botStock[c] = {});
    bag[res] = Math.max(0, v);
  }
  function getBotBld(g, c, id) {
    const bag = g.botBuildings[c] || (g.botBuildings[c] = {});
    return bag[id] || 0;
  }
  function addBotBld(g, c, id, n) {
    const bag = g.botBuildings[c] || (g.botBuildings[c] = {});
    bag[id] = (bag[id] || 0) + n;
  }

  function initBotEconomy(world, engine, c, smart) {
    const g = ensure(world);
    const st = g.botStates[c] || (g.botStates[c] = {});
    if (st.econInit) return;
    const res = engine.getCountryResources ? engine.getCountryResources(c) : { gold: 1, iron: 1, oil: 1 };
    setBotStock(g, c, GOLD, Math.floor(14000 * (Number(res.gold) || 1) * (0.55 + smart * 0.55)));
    setBotStock(g, c, IRON, Math.floor(32000 * (Number(res.iron) || 1) * (0.55 + smart * 0.55)));
    setBotStock(g, c, OIL, Math.floor(900 * (Number(res.oil) || 1) * (0.55 + smart * 0.55)));
    addBotBld(g, c, BLD_GOLD, Math.floor(50 + smart * 70));
    addBotBld(g, c, BLD_IRON, Math.floor(50 + smart * 70));
    addBotBld(g, c, BLD_OIL, Math.floor(30 + smart * 50));
    st.econInit = true;
    st.lastDecideDay = -1;
  }

  function pushPriority(world, country) {
    if (!country) return;
    const g = ensure(world);
    if (g.botPriority.indexOf(country) < 0) g.botPriority.push(country);
    // Cap queue
    if (g.botPriority.length > 12) g.botPriority.shift();
  }

  /** Countries that matter to the player (neighbors + optional view) */
  function relevantCountries(world, engine, playerCountry) {
    const g = ensure(world);
    const day = gameDay(world);
    if (g.botCache.neighbors && g.botCache.dayBuilt === day) {
      return g.botCache.neighbors;
    }
    const set = {};
    const out = [];
    function add(c) {
      if (!c || c === playerCountry || set[c]) return;
      set[c] = true;
      out.push(c);
    }
    // Land neighbors of player country
    if (engine.getCountryLandNeighbors) {
      const n = engine.getCountryLandNeighbors(playerCountry) || [];
      for (let i = 0; i < n.length; i++) add(n[i]);
    }
    // Regions near camera (cheap sample)
    if (engine.visibleRegions && engine.visibleRegions.length) {
      const max = Math.min(engine.visibleRegions.length, 40);
      for (let i = 0; i < max; i++) {
        const item = engine.visibleRegions[i];
        const r = item && item.c;
        if (!r) continue;
        const owner = engine.getRegionOwner ? engine.getRegionOwner(r.key) : r.country;
        add(owner);
      }
    }
    // Always include priority targets
    for (let i = 0; i < (g.botPriority || []).length; i++) add(g.botPriority[i]);

    g.botCache.neighbors = out;
    g.botCache.dayBuilt = day;
    return out;
  }

  function produceOne(world, engine, c, days) {
    if (days <= 0) return;
    const g = ensure(world);
    const res = engine.getCountryResources ? engine.getCountryResources(c) : { gold: 1, iron: 1, oil: 1 };
    const mins = days * (MS_DAY / 60000);
    const specs = [
      { id: BLD_GOLD, res: GOLD, rate: 1.2, den: Number(res.gold) || 1 },
      { id: BLD_IRON, res: IRON, rate: 1.5, den: Number(res.iron) || 1 },
      { id: BLD_OIL, res: OIL, rate: 0.8, den: Number(res.oil) || 1 }
    ];
    for (let i = 0; i < specs.length; i++) {
      const s = specs[i];
      const n = getBotBld(g, c, s.id);
      if (n <= 0) continue;
      setBotStock(g, c, s.res, getBotStock(g, c, s.res) + n * s.rate * s.den * mins * 0.12);
    }
  }

  function botBuildDays(id) {
    try {
      const b = global.WOK && global.WOK.getBuild ? global.WOK.getBuild(id) : null;
      const m = Number(b && (b.buildTimeMinutes || b.buildTime)) || 8;
      // game days ≈ minutes / 2 (same ballpark as player pacing)
      return Math.max(4, Math.round(m * 0.75));
    } catch (_) { return 8; }
  }
  function botTrainDays(id) {
    try {
      const u = global.WOK && global.WOK.getUnit ? global.WOK.getUnit(id) : null;
      const m = Number(u && (u.trainTimeMinutes || u.buildTimeMinutes)) || 4;
      return Math.max(3, Math.round(m * 0.75));
    } catch (_) { return 5; }
  }

  function decideBuild(world, engine, c, smart) {
    const g = ensure(world);
    if (!g.botBuildQueue) g.botBuildQueue = {};
    const q = g.botBuildQueue[c] || (g.botBuildQueue[c] = []);
    // Wait like the player: one construction job at a time
    if (q.length) return false;
    const res = engine.getCountryResources ? engine.getCountryResources(c) : { gold: 1, iron: 1, oil: 1 };
    let pick = BLD_GOLD;
    if ((res.iron || 0) >= (res.gold || 0) && (res.iron || 0) >= (res.oil || 0)) pick = BLD_IRON;
    if ((res.oil || 0) >= (res.gold || 0) && (res.oil || 0) >= (res.iron || 0)) pick = BLD_OIL;
    const costG = pick === BLD_OIL ? 1500 : 1000;
    const costI = pick === BLD_GOLD ? 200 : 400;
    if (getBotStock(g, c, GOLD) < costG || getBotStock(g, c, IRON) < costI) return false;
    setBotStock(g, c, GOLD, getBotStock(g, c, GOLD) - costG);
    setBotStock(g, c, IRON, getBotStock(g, c, IRON) - costI);
    const n = Math.floor(1 + smart * 2);
    const days = botBuildDays(pick) * Math.max(1, n);
    q.push({ id: pick, n: n, endsAt: Date.now() + days * MS_DAY });
    return true;
  }

  function decideRecruit(world, engine, c, smart) {
    const g = global.WOK_Military.ensure(world);
    const bg = ensure(world);
    if (!bg.botTrainQueue) bg.botTrainQueue = {};
    const tq = bg.botTrainQueue[c] || (bg.botTrainQueue[c] = []);
    if (tq.length) return false; // wait for current training
    const regs = countryRegions(engine, c);
    if (!regs.length) return false;
    const costG = 40 * Math.floor(2 + smart * 5);
    if (getBotStock(bg, c, GOLD) < costG) return false;
    setBotStock(bg, c, GOLD, getBotStock(bg, c, GOLD) - costG);
    const rk = String(regs[Math.floor(Math.random() * Math.min(regs.length, 8))]);
    const nInf = Math.floor(2 + smart * 6);
    const jobs = [{ unitId: INF, n: nInf, region: rk, endsAt: Date.now() + botTrainDays(INF) * MS_DAY }];
    if (smart >= 0.55 && getBotStock(bg, c, IRON) > 300) {
      setBotStock(bg, c, IRON, getBotStock(bg, c, IRON) - 180);
      jobs.push({ unitId: TANK, n: 1, region: rk, endsAt: Date.now() + botTrainDays(TANK) * MS_DAY });
    }
    for (let i = 0; i < jobs.length; i++) tq.push(jobs[i]);
    return true;
  }

  function botEnsureResearch(world, c, smart) {
    const g = ensure(world);
    const st = g.botStates[c] || (g.botStates[c] = {});
    if (!st.research) st.research = {};
    // Auto-progress: recruit unlocked early, powder after ~40+ game days of existence
    st.research[RES_RECRUIT] = true;
    const day = gameDay(world);
    const needDay = Math.floor(35 + (1 - smart) * 40);
    if (day >= needDay) st.research[RES_POWDER] = true;
    // Mirror into military researchDone only for player path; bots use st.research
    return st.research;
  }
  function botCanAttack(world, c, smart, fromPower) {
    const res = botEnsureResearch(world, c, smart);
    if (!res[RES_POWDER]) return false;
    // Slightly lower bar so wars actually start, still not a joke stack
    const minP = 55 + smart * 45;
    return fromPower >= minP;
  }

  function botResearchDone(g, c, id) {
    if (!g.botResearch) g.botResearch = {};
    const st = g.botResearch[c] || (g.botResearch[c] = { done: {}, queue: null });
    if (!st.done) st.done = {};
    return !!st.done[id];
  }

  function decideResearch(world, engine, c, smart) {
    const g = ensure(world);
    if (!g.botResearch) g.botResearch = {};
    const st = g.botResearch[c] || (g.botResearch[c] = { done: {}, queue: null });
    if (!st.done) st.done = {};
    // Complete finished job
    if (st.queue && st.queue.endsAt <= Date.now()) {
      st.done[st.queue.id] = true;
      st.queue = null;
    }
    if (st.queue) return false;
    // Need recruit first (free default for bots after a while)
    if (!st.done[RECRUIT_RES]) {
      st.done[RECRUIT_RES] = true;
    }
    if (st.done[POWDER]) return false;
    const costG = 50000, costI = 40000;
    if (getBotStock(g, c, GOLD) < costG * 0.6 || getBotStock(g, c, IRON) < costI * 0.6) return false;
    setBotStock(g, c, GOLD, getBotStock(g, c, GOLD) - Math.floor(costG * 0.6));
    setBotStock(g, c, IRON, getBotStock(g, c, IRON) - Math.floor(costI * 0.6));
    const days = Math.max(20, Math.round(30 * (1.15 - smart * 0.25)));
    st.queue = { id: POWDER, endsAt: Date.now() + days * MS_DAY };
    return true;
  }

  function processBotQueues(world) {
    const g = ensure(world);
    const now = Date.now();
    if (g.botResearch) {
      Object.keys(g.botResearch).forEach(function (c) {
        const st = g.botResearch[c];
        if (st && st.queue && st.queue.endsAt <= now) {
          if (!st.done) st.done = {};
          st.done[st.queue.id] = true;
          st.queue = null;
        }
      });
    }
    if (!g.botBuildQueue) g.botBuildQueue = {};
    Object.keys(g.botBuildQueue).forEach(function (c) {
      const q = g.botBuildQueue[c] || [];
      const left = [];
      for (let i = 0; i < q.length; i++) {
        const job = q[i];
        if (job.endsAt <= now) addBotBld(g, c, job.id, job.n || 1);
        else left.push(job);
      }
      g.botBuildQueue[c] = left;
    });
    if (!g.botTrainQueue) g.botTrainQueue = {};
    const mil = global.WOK_Military.ensure(world);
    Object.keys(g.botTrainQueue).forEach(function (c) {
      const q = g.botTrainQueue[c] || [];
      const left = [];
      for (let i = 0; i < q.length; i++) {
        const job = q[i];
        if (job.endsAt <= now) {
          const army = ensureArmy(mil, job.region);
          addUnits(army, job.unitId, job.n || 1);
          if (job.unitId === INF) {
            mil.regionSoldiers[String(job.region)] =
              (mil.regionSoldiers[String(job.region)] || 0) + (job.n || 1) * 1000;
          }
        } else left.push(job);
      }
      g.botTrainQueue[c] = left;
    });
  }

  function borderTargetsVsPlayer(engine, country, playerCountry) {
    const regs = countryRegions(engine, country);
    const targets = [];
    const maxR = Math.min(regs.length, 14);
    for (let i = 0; i < maxR; i++) {
      const rk = String(regs[i]);
      const neigh = engine.getRegionLandNeighbors ? (engine.getRegionLandNeighbors(rk) || []) : [];
      for (let j = 0; j < neigh.length; j++) {
        const nk = String(neigh[j]);
        // Strict land only — no proximity jumps across water
        if (engine.areRegionsStrictLandAdjacent && !engine.areRegionsStrictLandAdjacent(rk, nk)) continue;
        const owner = engine.getRegionOwner ? engine.getRegionOwner(nk) : null;
        if (owner === playerCountry) {
          targets.push({ from: rk, to: nk, owner: owner });
        }
      }
    }
    return targets;
  }

  function borderTargetsAny(engine, country, playerCountry) {
    const regs = countryRegions(engine, country);
    const targets = [];
    const maxR = Math.min(regs.length, 12);
    for (let i = 0; i < maxR; i++) {
      const rk = String(regs[i]);
      const neigh = engine.getRegionLandNeighbors ? (engine.getRegionLandNeighbors(rk) || []) : [];
      for (let j = 0; j < Math.min(neigh.length, 8); j++) {
        const nk = String(neigh[j]);
        if (engine.areRegionsStrictLandAdjacent && !engine.areRegionsStrictLandAdjacent(rk, nk)) continue;
        const owner = engine.getRegionOwner ? engine.getRegionOwner(nk) : null;
        if (!owner || owner === country) continue;
        targets.push({ from: rk, to: nk, owner: owner, isPlayer: owner === playerCountry });
      }
    }
    return targets;
  }


  function recordLostRegion(world, country, regionKey) {
    rememberClaim(world, country, regionKey);
  }

  function rememberClaim(world, country, regionKey) {
    const g = ensure(world);
    if (!g.botClaims[country]) g.botClaims[country] = {};
    if (!g.botClaims[country][regionKey]) {
      g.botClaims[country][regionKey] = { lostAt: Date.now(), attempts: 0 };
    }
  }

  function noteLostRegions(world, engine, country) {
    if (!engine || !engine.getCountryRegions) return;
    const g = ensure(world);
    const home = engine.getCountryRegions(country) || [];
    // Regions that historically belonged via claims, plus: if occupation map says foreign owner on a region that was in bot memory
    // Scan all regions currently not owned by country but in claims
    const claims = g.botClaims[country] || {};
    Object.keys(claims).forEach(function (rk) {
      const own = engine.getRegionOwner ? engine.getRegionOwner(rk) : null;
      if (own === country) delete claims[rk]; // recovered
    });
  }

  function decideRetake(world, engine, c, smart) {
    const g = ensure(world);
    const bg = ensureMilitaryBag(world);
    noteLostRegions(world, engine, c);
    const claims = g.botClaims[c] || {};
    const keys = Object.keys(claims);
    if (!keys.length) return false;
    // Pick oldest claim with cooldown
    keys.sort(function (a, b) { return (claims[a].lostAt || 0) - (claims[b].lostAt || 0); });
    const now = Date.now();
    for (let i = 0; i < keys.length; i++) {
      const rk = keys[i];
      const cl = claims[rk];
      const own = engine.getRegionOwner ? engine.getRegionOwner(rk) : null;
      if (own === c) { delete claims[rk]; continue; }
      if (!own) continue;
      // cooldown: at least 40 game-days between attempts (400s real)
      const last = cl.lastAttemptAt || 0;
      if (now - last < 40 * 10000) continue;
      // Find owned neighbor to attack from
      let from = null;
      if (engine._landAdj && engine._landAdj.get) {
        const neigh = engine._landAdj.get(rk) || [];
        const list = neigh instanceof Set ? Array.from(neigh) : (neigh || []);
        for (let j = 0; j < list.length; j++) {
          const nk = String(list[j]);
          if ((engine.getRegionOwner && engine.getRegionOwner(nk)) === c) {
            const army = (bg.regionArmies && bg.regionArmies[nk]) || {};
            const sol = (bg.regionSoldiers && bg.regionSoldiers[nk]) || 0;
            if (sol > 20 || Object.keys(army).length) { from = nk; break; }
          }
        }
      }
      if (!from) continue;
      cl.lastAttemptAt = now;
      cl.attempts = (cl.attempts || 0) + 1;
      try {
        return !!launchAttack(world, engine, bg, from, rk, smart, c, own);
      } catch (e) { return false; }
    }
    return false;
  }

  function ensureMilitaryBag(world) {
    if (global.WOK_Military && global.WOK_Military.ensureMilitary) {
      try { return global.WOK_Military.ensureMilitary(world); } catch (_) {}
    }
    if (!world.game) world.game = {};
    if (!world.game.military) world.game.military = {};
    return world.game.military;
  }

  function launchAttack(world, engine, g, from, to, smart, attacker, defender) {
    // Hard gate: must be strict land neighbors (or explicit sea later)
    if (engine.areRegionsStrictLandAdjacent && !engine.areRegionsStrictLandAdjacent(String(from), String(to))) {
      return false;
    }
    const bg = ensure(world);
    // Must have researched Powder Force before any war
    if (!botResearchDone(bg, attacker, POWDER)) return false;
    const army = g.regionArmies[from];
    if (!army) return false;
    // Need a respectable force — not a single green stack of 1000 soldiers
    const pow = armyPower(army);
    if (pow < 60 + smart * 35) return false;
    // Stronger push while keeping a reserve
    const ratio = 0.38 + smart * 0.2; // commit a real force, keep reserve
    const units = {};
    const ids = Object.keys(army);
    for (let i = 0; i < ids.length; i++) {
      const id = ids[i];
      const n = Math.floor((army[id].count || 0) * ratio);
      if (n <= 0) continue;
      units[id] = n;
      army[id].count -= n;
      if (army[id].active) army[id].active = Math.min(army[id].active, army[id].count);
      if (army[id].count <= 0) delete army[id];
    }
    if (!Object.keys(units).length) return false;
    const now = Date.now();
    g.moves.push({
      id: 'bot_' + now + '_' + Math.random().toString(36).slice(2, 6),
      from: String(from),
      to: String(to),
      units: units,
      startedAt: now,
      endsAt: now + 10 * MS_DAY,
      player: false,
      sea: false,
      botAttacker: attacker
    });
    // Interacted country gets next decision turn
    if (defender) pushPriority(world, defender);
    return true;
  }

  function resolveBotMovesNearPlayer(world, engine, playerCountry) {
    const g = global.WOK_Military.ensure(world);
    const now = Date.now();
    if (!g.moves || !g.moves.length) return;
    const left = [];
    for (let i = 0; i < g.moves.length; i++) {
      const mv = g.moves[i];
      if (mv.player) { left.push(mv); continue; }
      if (mv.endsAt > now) { left.push(mv); continue; }

      const ownerTo = engine.getRegionOwner ? engine.getRegionOwner(mv.to) : null;
      const attacker = mv.botAttacker;
      // Only fully resolve if involves player or is on-screen-ish (owner is relevant)
      const involvesPlayer = ownerTo === playerCountry || attacker === playerCountry;
      const relevant = involvesPlayer || (relevantCountries(world, engine, playerCountry).indexOf(attacker) >= 0)
        || (relevantCountries(world, engine, playerCountry).indexOf(ownerTo) >= 0);

      if (!relevant) {
        // Silent discard far battles — player never saw them
        continue;
      }

      // Defender logistics reinforce arriving into an ongoing battle
      if (mv.botReinforceBattle || mv.botDefender) {
        const battle = (global.WOK_Military.findBattleAt
          ? global.WOK_Military.findBattleAt(g, mv.to)
          : null) || (function () {
            for (let bi = 0; bi < (g.battles || []).length; bi++) {
              const b = g.battles[bi];
              if (b && String(b.region) === String(mv.to) &&
                  (b.status === 'fighting' || b.status === 'holding')) return b;
            }
            return null;
          })();
        if (battle && (battle.status === 'fighting' || battle.status === 'holding')) {
          if (!battle.defUnits) battle.defUnits = {};
          if (!battle.defWaves) battle.defWaves = [{}, {}, {}];
          Object.keys(mv.units || {}).forEach(function (id) {
            const n = mv.units[id] || 0;
            if (n <= 0) return;
            if (id === 'soldiers') {
              battle.defUnits.soldiers = (battle.defUnits.soldiers || 0) + n;
            } else {
              battle.defUnits[id] = (battle.defUnits[id] || 0) + n;
            }
          });
          // Feed remaining waves
          const start = Math.min(2, Math.max(0, battle.pulseCount || 0));
          for (let wi = start; wi < 3; wi++) {
            Object.keys(mv.units || {}).forEach(function (id) {
              const n = Math.floor((mv.units[id] || 0) * (wi === start ? 1 : 0.35));
              if (n > 0) battle.defWaves[wi][id] = (battle.defWaves[wi][id] || 0) + n;
            });
          }
          try {
            if (global.WOK_Military && global.WOK_Military.emitPrivate) {
              /* private log already on dispatch */
            }
          } catch (_) {}
          continue;
        }
        // Battle already over — dump into region army if still owned by defender
        if (ownerTo === mv.botDefender) {
          const army = ensureArmy(g, mv.to);
          Object.keys(mv.units || {}).forEach(function (id) {
            if (id === 'soldiers') {
              g.regionSoldiers[String(mv.to)] = (g.regionSoldiers[String(mv.to)] || 0) + (mv.units[id] || 0);
            } else {
              addUnits(army, id, mv.units[id]);
            }
          });
        }
        continue;
      }

      if (ownerTo === attacker) {
        // Friendly reinforce / redeploy
        const army = ensureArmy(g, mv.to);
        Object.keys(mv.units).forEach(function (id) { addUnits(army, id, mv.units[id]); });
        continue;
      }

      // Same 3-round battle system as the player (no instant resolution)
      if (global.WOK_Military && global.WOK_Military.beginBattle) {
        try {
          global.WOK_Military.beginBattle(world, engine, {
            from: mv.from,
            to: mv.to,
            units: mv.units,
            attacker: attacker,
            defender: ownerTo,
            playerCountry: playerCountry
          });
        } catch (e) { console.warn('bot beginBattle', e); }
      }
      if (ownerTo) pushPriority(world, ownerTo);
      if (attacker) pushPriority(world, attacker);
    }
    g.moves = left;
  }

  function decideMarket(world, engine, c, smart) {
    const bg = ensure(world);
    initBotEconomy(world, engine, c, smart);
    if (!global.WOK_Market || !global.WOK_Market.recordTrade) return false;
    // Prefer selling surplus oil/iron, sometimes buy scarcity
    const oil = getBotStock(bg, c, OIL);
    const iron = getBotStock(bg, c, IRON);
    const gold = getBotStock(bg, c, GOLD);
    const roll = Math.random();
    if (oil > 200 && roll < 0.45) {
      const qty = Math.floor(Math.min(oil * 0.15, 80 + smart * 120));
      if (qty >= 1) {
        setBotStock(bg, c, OIL, oil - qty);
        // bots convert ~90% global value conceptually into gold
        setBotStock(bg, c, GOLD, gold + qty * 0.5);
        global.WOK_Market.recordTrade(OIL, qty, false);
        return true;
      }
    }
    if (iron > 800 && roll < 0.7) {
      const qty = Math.floor(Math.min(iron * 0.12, 200 + smart * 300));
      if (qty >= 1) {
        setBotStock(bg, c, IRON, iron - qty);
        setBotStock(bg, c, GOLD, getBotStock(bg, c, GOLD) + qty * 0.08);
        global.WOK_Market.recordTrade(IRON, qty, false);
        return true;
      }
    }
    if (gold > 500 && roll > 0.75) {
      // buy a little oil or iron
      const buyOil = Math.random() < 0.5;
      const qty = Math.floor(10 + smart * 40);
      if (buyOil) {
        setBotStock(bg, c, GOLD, gold - qty * 2);
        setBotStock(bg, c, OIL, oil + qty);
        global.WOK_Market.recordTrade(OIL, qty, true);
      } else {
        setBotStock(bg, c, GOLD, gold - qty * 0.5);
        setBotStock(bg, c, IRON, iron + qty);
        global.WOK_Market.recordTrade(IRON, qty, true);
      }
      return true;
    }
    return false;
  }

  function decideOne(world, engine, c, playerCountry, smart) {
    initBotEconomy(world, engine, c, smart);
    const g = global.WOK_Military.ensure(world);
    const roll = Math.random();

    // Near player: slightly more aggressive; far: mostly economy
    const nearPlayer = (engine.getCountryLandNeighbors
      ? (engine.getCountryLandNeighbors(playerCountry) || []).indexOf(c) >= 0
      : false);

    // Research path (Powder Force) before serious wars
    if (roll < 0.22) {
      if (decideResearch(world, engine, c, smart)) return;
      if (!decideMarket(world, engine, c, smart)) decideBuild(world, engine, c, smart);
      return;
    }
    // Economy still dominant, but wars are visible on the map
    if (roll < 0.34) {
      if (!decideMarket(world, engine, c, smart)) decideBuild(world, engine, c, smart);
      return;
    }
    if (roll < 0.58) {
      decideBuild(world, engine, c, smart);
      return;
    }
    if (roll < 0.78) {
      decideRecruit(world, engine, c, smart);
      return;
    }
    // ~22% of decisions consider war (was ~8–10%)
    // First: try to retake a claimed homeland region (periodic pressure on occupier)
    if (Math.random() < 0.45) {
      try {
        if (decideRetake(world, engine, c, smart)) return;
      } catch (_) {}
    }
    // Far bots still attack less often
    if (!nearPlayer && Math.random() < 0.55) {
      if (!decideMarket(world, engine, c, smart)) decideBuild(world, engine, c, smart);
      return;
    }
    let targets = nearPlayer
      ? borderTargetsVsPlayer(engine, c, playerCountry)
      : borderTargetsAny(engine, c, playerCountry);
    if (!targets.length) {
      // Try any border even if not vs player
      targets = borderTargetsAny(engine, c, playerCountry);
    }
    if (!targets.length) {
      decideRecruit(world, engine, c, smart);
      return;
    }
    // Prefer player when near; otherwise prefer weaker / richer borders
    if (nearPlayer && Math.random() < 0.40 + smart * 0.2) {
      const vsP = targets.filter(function (x) { return x.owner === playerCountry; });
      if (vsP.length) targets = vsP;
    }
    // Score targets: strong FROM region, weaker TO owner presence
    let best = null;
    let bestScore = -1e9;
    for (let ti = 0; ti < targets.length; ti++) {
      const cand = targets[ti];
      const fp = armyPower(g.regionArmies[cand.from] || {});
      const enemyHere = armyPower(g.regionArmies[cand.to] || {}) + (g.regionSoldiers[cand.to] || 0) * 0.05;
      let sc = fp - enemyHere * 0.6 + Math.random() * 40;
      if (cand.owner === playerCountry) sc += 30 + smart * 25;
      if (fp > bestScore * 0.01) { /* keep scanning */ }
      if (sc > bestScore) { bestScore = sc; best = cand; }
    }
    const t = best || targets[Math.floor(Math.random() * targets.length)];
    const fromPower = armyPower(g.regionArmies[t.from] || {});
    if (!botCanAttack(world, c, smart, fromPower)) {
      botEnsureResearch(world, c, smart);
      decideRecruit(world, engine, c, smart);
      return;
    }
    const st = g.botStates[c] || (g.botStates[c] = {});
    const day = gameDay(world);
    // Cool-down between wars (was 25 days)
    if (st.lastWarDay != null && day - st.lastWarDay < 12) {
      decideRecruit(world, engine, c, smart);
      return;
    }
    if (launchAttack(world, engine, g, t.from, t.to, smart, c, t.owner)) {
      st.lastWarDay = day;
    }
  }

  /**
   * Main tick — called from game loop. Must stay under ~2ms average.
   */
  function tick(world, engine, playerCountry) {
    if (!world || !engine || !global.WOK_Military || !playerCountry) return;
    const g = ensure(world);
    const smart = iq(world);
    const day = gameDay(world);

    // Resolve only finished bot moves that matter (cheap if queue empty)
    resolveBotMovesNearPlayer(world, engine, playerCountry);
    try { processBotQueues(world); } catch (_) {}

    // Production only for relevant countries, only when day changes
    if (g._botProdDay !== day) {
      const rel = relevantCountries(world, engine, playerCountry);
      const elapsed = (g._botProdDay == null) ? 1 : Math.max(1, day - g._botProdDay);
      for (let i = 0; i < rel.length; i++) {
        initBotEconomy(world, engine, rel[i], smart);
        produceOne(world, engine, rel[i], Math.min(elapsed, 8));
      }
      g._botProdDay = day;
    }

    // 10 groups: day % 10 → that group decides today.
    // Budget a few decisions per tick so the full group finishes over the day without freezes.
    const activeGroup = day % GROUPS;
    let acted = 0;
    const MAX_ACT = 3; // a few more decisions — wars stay visible

    // 1) Priority (attacked countries) first
    while (g.botPriority.length && acted < MAX_ACT) {
      const c = g.botPriority.shift();
      if (!c || c === playerCountry) continue;
      const st = g.botStates[c] || (g.botStates[c] = {});
      if (st.lastDecideDay === day) continue;
      st.lastDecideDay = day;
      decideOne(world, engine, c, playerCountry, smart);
      acted++;
    }

    // 2) Build today's group queue once (all countries in group, relevant first)
    if (g._botGroupDay !== day) {
      g._botGroupDay = day;
      let all = (engine.listCountries && engine.listCountries()) || [];
      if (!all.length) {
        const rel0 = relevantCountries(world, engine, playerCountry);
        all = rel0.slice();
      }
      const relSet = {};
      const rel = relevantCountries(world, engine, playerCountry);
      for (let i = 0; i < rel.length; i++) relSet[rel[i]] = true;
      const group = [];
      for (let i = 0; i < all.length; i++) {
        const c = all[i];
        if (!c || c === playerCountry) continue;
        if (hashCountry(c) !== activeGroup) continue;
        group.push(c);
      }
      // relevant members first
      group.sort(function (a, b) {
        const ar = relSet[a] ? 0 : 1, br = relSet[b] ? 0 : 1;
        return ar - br;
      });
      g._botGroupQueue = group;
    }

    const queue = g._botGroupQueue || [];
    while (queue.length && acted < MAX_ACT) {
      const c = queue.shift();
      if (!c || c === playerCountry) continue;
      const st = g.botStates[c] || (g.botStates[c] = {});
      if (st.lastDecideDay === day) continue;
      st.lastDecideDay = day;
      decideOne(world, engine, c, playerCountry, smart);
      acted++;
    }

    // 3) Sparse tension news — ONLY land-adjacent country pairs (never cross-world)
    if (day > 0 && day % 40 === 0 && g._botFlavorDay !== day) {
      g._botFlavorDay = day;
      if (global.WOK_News && engine.getCountryLandNeighbors && Math.random() < 0.4) {
        const rel = relevantCountries(world, engine, playerCountry);
        const pool = rel.length ? rel : [];
        if (pool.length) {
          const a = pool[Math.floor(Math.random() * pool.length)];
          const neigh = engine.getCountryLandNeighbors(a) || [];
          const landOnly = neigh.filter(function (b) {
            return b && b !== a && b !== playerCountry;
          });
          if (landOnly.length) {
            const b = landOnly[Math.floor(Math.random() * landOnly.length)];
            try {
              global.WOK_News.addPublic(world, {
                title: 'توتر حدودي بين ' + a + ' و' + b,
                body: 'تقارير عن مناورات على الحدود البرية بين ' + a + ' و' + b + '. الوضع تحت المراقبة.',
                type: 'flavor',
                meta: { attacker: a, defender: b, land: true }
              });
            } catch (_) {}
          }
        }
      }
    }
  }

  global.WOK_Bot = {
    tick: tick,
    iq: iq,
    gameDay: gameDay,
    pushPriority: pushPriority,
    recordLostRegion: recordLostRegion,
    GROUPS: GROUPS
  };
})(typeof window !== 'undefined' ? window : globalThis);
