/**
 * War of Kings – Entry
 */
(function () {
  'use strict';

  const canvas = document.getElementById('map-canvas');
  if (!canvas) return;

  // disable loader if present
  const loader = document.getElementById('loader');
  if (loader) loader.style.display = 'none';

  const zoomEl = document.getElementById('zoom-level');
  const fpsEl  = document.getElementById('fps-counter');
  const visEl  = document.getElementById('visible-count');

  const engine = new MapEngine(canvas, {
    onStats({ zoom, fps, visible, regions, lod, tier }) {
      if (zoomEl) zoomEl.textContent = `Zoom: ${zoom.toFixed(2)} (T${tier != null ? tier : '?'}/${lod})`;
      if (fpsEl)  fpsEl.textContent  = `FPS: ${fps}`;
      if (visEl)  visEl.textContent  = `Visible: ${visible}` + (regions ? ` | Reg: ${regions}` : '');
    }
  });

  engine.load(
    'data/countries-110m.json',
    'data/countries-50m.json',
    'data/regions.json'
  )
    .then(() => {
      engine._clampCamera();
      engine.setDirty();
      console.log('[War of Kings] ready');
    })
    .catch(err => console.error('Map load failed', err));

  window.mapEngine = engine;

  // ── زر وضع العرض (Landscape) ──
  const btnLand = document.getElementById('btn-landscape');
  if (btnLand) {
    let locked = false;

    async function tryLockLandscape() {
      try {
        // Fullscreen أولاً (مطلوب لقفل الاتجاه في أغلب المتصفحات)
        const el = document.documentElement;
        if (el.requestFullscreen) await el.requestFullscreen();
        else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen();

        if (screen.orientation && screen.orientation.lock) {
          await screen.orientation.lock('landscape');
          locked = true;
          btnLand.classList.add('active');
          btnLand.textContent = '⟳ طولي';
          // بعد التحويل للعرض: أعد حساب الزوم الأدنى وألغِ الفراغات شرق/غرب
          setTimeout(() => {
            if (window.mapEngine) {
              window.mapEngine._resize();
              window.mapEngine._clampCamera();
              window.mapEngine.setDirty();
            }
          }, 150);
          return true;
        }
      } catch (e) {
        console.warn('orientation lock failed', e);
      }
      return false;
    }

    async function unlockOrientation() {
      try {
        if (screen.orientation && screen.orientation.unlock) {
          screen.orientation.unlock();
        }
        if (document.exitFullscreen) await document.exitFullscreen();
        else if (document.webkitExitFullscreen) await document.webkitExitFullscreen();
      } catch (_) {}
      locked = false;
      btnLand.classList.remove('active');
      btnLand.textContent = '⟳ عرض';
    }

    btnLand.addEventListener('click', async () => {
      if (locked) {
        await unlockOrientation();
      } else {
        const ok = await tryLockLandscape();
        if (!ok) {
          // fallback: أخبر المستخدم يدير الجهاز
          btnLand.textContent = 'أدر الجهاز ↻';
          setTimeout(() => { if (!locked) btnLand.textContent = '⟳ عرض'; }, 2200);
        }
      }
    });

    // لو خرج من ملء الشاشة، رجّع الزر لحالته
    document.addEventListener('fullscreenchange', () => {
      if (!document.fullscreenElement && locked) {
        locked = false;
        btnLand.classList.remove('active');
        btnLand.textContent = '⟳ عرض';
      }
    });
  }
})();
