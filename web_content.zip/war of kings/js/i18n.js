/**
 * War of Kings — i18n (PER-1.3.3)
 * Source of truth: i18n/translation.csv (columns: key,en,ar,tr)
 * EMBED below is generated from the same CSV so UI never shows blank labels before fetch.
 * Languages: ar (RTL), en, tr.
 */
(function (global) {
  'use strict';

  var SUPPORTED = { ar: 1, en: 1, tr: 1 };
  var RTL = { ar: 1 };

  // Generated from i18n/translation.csv — do not edit by hand; edit the CSV then rebuild.
  var EMBED = {"en":{"active":"active","add_world":"Add World","aid_received_":"Aid received: ","aid_refused":"Aid refused (−10% relations)","aid_sent_":"Aid sent · +","alerts":"Alerts","alliance_refused":"Alliance refused","amount":"Amount","army":"Army","attack":"Attack","back":"‹ Back","back_list":"← Back to list","back_menu":"Back","barracks_":"Barracks ","blockedCountry":"Antarctica is not a playable country.","border_detail":"Country borders","border_detail_hint":"Outer country edge detail · 15–64 · default 32","brand_sub":"World conquest strategy","build_embassy":"Build embassy (10k gold, 20k iron, 1k oil)","build_time":"Build time","building":"building","buildings":"Buildings","buy":"Buy","cancel":"Cancel","cannot_afford":"You cannot afford this package","cannot_recall":"Cannot recall","cannot_train":"Cannot train here","cat_general":"General","cat_touch":"Touch","cat_video":"Video","choose":"Select","choose_action":"Choose action","clear_all":"Delete all","clear_all_close":"Close","clear_all_msg":"Are you sure you want to delete all?","clear_all_ok":"Delete","clear_all_title":"Delete all?","close":"Close","coastal":"Coastal","confirm":"Confirm","cost":"Cost","country_":"Country: ","country_label":"Country","create_offline":"Create Offline World","day":"d","default_orient":"Default orientation","defensive_alliance":"Defensive alliance formed","delete":"Delete","delete_confirm":"Delete “{name}”? This cannot be undone.","delete_world":"Delete World","difficulty":"Difficulty","done":"Done","easy":"Easy","eco":"Economy points (total 3.5)","edit":"Edit","edit_world":"Edit World","embassy_built":"Embassy built","embassy_options":"Embassy options","enlistment":"Enlistment","failed":"Failed","fixed_structure":" · Fixed structure · +1000 soldiers","forces_en_route":"Forces en route","forces_moving":"Forces moving…","forces_turning_back":"Forces turning back","forces_withdrawing":"Forces withdrawing…","from_":"From ","fx_sub":"Local market prices in gold","fx_title":"Exchange rates","game_version":"Version","gold":"Gold","gold_unit":" gold","h":"High","hard":"Hard","hide_small_islands":"Hide small islands","hide_small_islands_hint":"Skip drawing islands under 50,000 km² (performance)","hold_drag_move":"Hold & drag to move, or release for info","in_queue":"in queue","invalid_wokworld":"Invalid .WOKWORLD file","iron":"Iron","item":"Item","just_now":"Just now","l":"Low","land_10_days":"Land · 10 game days","landscape":"Landscape","language":"The language","load_fail":"Failed to load","loading":"Loading map…","loading_dots":"…","locked":"Locked","long_press_region":"Long-press a region","long_press_train":"Long-press your region to train","m":"Average","m_short":"m","medium":"Medium","menu":"Menu","min_ago":" min ago","missing":"World not found","mode_offline":"Offline","month":"mo","move_army_attack":"Move army / Attack","move_failed":"Move failed","move_forces":"Move forces","move_from_own":"Can only move from your regions","move_ui_error":"Move UI error","mute_map_banners":"Hide UI alerts","mute_map_banners_hint":"Red banners only in Alerts list","need_ground_naval":"Need ground or naval units","need_transport":"Need transport ships","neighbors":"Land borders","new_world":"New World","news":"News","news_private":"Your forces","news_public":"Public","next":"Next","no_alerts":"No alerts","no_army_here":"No army here","no_mobile_forces":"No mobile forces","no_news":"No news yet","no_target":"No target","no_unit_data":"No unit data","no_units":"No units","no_units_training":"No units training","no_worlds":"No worlds yet — tap Add World","not_connected":"Not connected","not_enough":"Not enough","not_enough_crew":"Not enough soldiers for crew","not_enough_oil":"Not enough oil","not_enough_resources":"Not enough resources","not_your_region":"Not your region","offline":"Offline","oil":"Oil","oil_cost_":"Oil cost: ","online":"Online","open":"Open","orient":"⟳ Landscape","orientAlt":"⟳ Portrait","orient_btn":"⟳ Landscape","orient_btn_alt":"⟳ Portrait","orient_hint":"Locks every screen to this mode","owned":"Owned","owned_":"Owned: ","package_empty":"Package empty","play":"Play","portrait":"Portrait","power_":"Power ","price_drop":"{name} price drops ~{pct}%","price_rise":"{name} price rises ~{pct}%","prod_time_one":"Time to produce 1","produces":"Produces","quantity":"Quantity","quit":"Quit","recall_forces":"Recall forces","recalling_suffix":" (recalling)","region_army":"Region army","region_detail":"Region border detail","region_detail_hint":"Province edge detail · 15–64 · default 32","regions":"Regions","regions_not_linked":"Regions not linked","relations":"Relations ","relations_":"Relations: ","relations_dot":" · Relations ","research_tree":"Research tree","resume":"Resume game","retry":"Retry","rotateHint":"Rotate device ↻","rotate_hint":"Rotate device ↻","route_":"Route: ","save":"Save","save_quit":"Save and quit","sea_route":"Sea route","selected_":"Selected: ","sell":"Sell","send_aid":"Send aid","sens_hint":"Pan speed · default 1","sens_pan":"Pan smoothness","sens_pan_hint":"Drag speed · default 1","sens_zoom":"Zoom smoothness","sens_zoom_hint":"Pinch / wheel speed · default 1","sensitivity":"Map sensitivity","settings":"Settings","ships_no_land":"Ships cannot move over land","show_map_stats":"Map stats","show_map_stats_hint":"Show FPS and zoom on the date bar","soldiers":"Soldiers","soldiers_":"Soldiers ","storage_per":"Storage per building","sub":"Tap any country","tapHint":"Tap a country to view info","target_":"Target: ","title":"Choose your country","to_":" to ","toggle_off":"Off","toggle_on":"On","total":"Total","total_cost":"Total cost","trade":"Trade","training_queue":"Training queue","training_started":"Training started","unit_price":"Unit","version_hint":"Release","very_easy":"Very Easy","very_hard":"Very Hard","vh":"Very high","withdraw":"Withdraw","withdraw_forces":"Withdraw","world_conquered":"World Conquered!","world_name":"World name","world_name_ph":"Enter world name","year":"y","you_suffix":" (You)","your_package":"Your package","your_worlds":"Your Worlds"},"ar":{"active":"نشطة","add_world":"إضافة عالم","aid_received_":"وصلت مساعدات: ","aid_refused":"رُفضت المساعدات (−10% علاقة)","aid_sent_":"أُرسلت المساعدات · +","alerts":"التنبيهات","alliance_refused":"رُفض التحالف","amount":"الكمية","army":"الجيش","attack":"هجوم","back":"‹ رجوع","back_list":"→ رجوع للقائمة","back_menu":"رجوع","barracks_":"ثكنات ","blockedCountry":"القارة القطبية الجنوبية ليست دولة قابلة للاختيار.","border_detail":"حدود الدول","border_detail_hint":"تفصيل حدود الدول · 15–64 · افتراضي 32","brand_sub":"استراتيجية السيطرة على العالم","build_embassy":"بناء سفارة (10 آلاف ذهب، 20 آلاف حديد، ألف نفط)","build_time":"مدة البناء","building":"مبنى","buildings":"المباني","buy":"شراء","cancel":"إلغاء","cannot_afford":"لا تملك السعر","cannot_recall":"تعذر الإعادة","cannot_train":"تعذر التدريب هنا","cat_general":"عام","cat_touch":"اللمس","cat_video":"الفيديو","choose":"اختيار","choose_action":"اختر العملية","clear_all":"حذف الكل","clear_all_close":"إغلاق","clear_all_msg":"هل أنت متأكد من أنك تريد حذف الكل؟","clear_all_ok":"حذف","clear_all_title":"حذف الكل؟","close":"إغلاق","coastal":"مطلة على البحر","confirm":"تأكيد","cost":"التكلفة","country_":"دولة: ","country_label":"الدولة","create_offline":"إنشاء عالم بدون اتصال","day":"ي","default_orient":"الوضع الافتراضي","defensive_alliance":"تم التحالف الدفاعي","delete":"حذف","delete_confirm":"حذف «{name}»؟ لا يمكن التراجع.","delete_world":"حذف العالم","difficulty":"الصعوبة","done":"مكتمل","easy":"سهل","eco":"توزيع نقاط الاقتصاد (المجموع 3.5)","edit":"تعديل","edit_world":"تعديل العالم","embassy_built":"بُنيت السفارة","embassy_options":"خيارات السفارة","enlistment":"تجنيد على الخريطة","failed":"فشل","fixed_structure":" · مبنى ثابت · +1000 جندي","forces_en_route":"القوات في الطريق","forces_moving":"القوات في الطريق…","forces_turning_back":"القوات تتراجع إلى القاعدة","forces_withdrawing":"القوات تنسحب…","from_":"من ","fx_sub":"أسعار السوق المحلي بالذهب","fx_title":"أسعار الصرف","game_version":"الإصدار","gold":"ذهب","gold_unit":" ذهب","h":"كثير","hard":"صعب","hide_small_islands":"إخفاء الجزر الصغيرة","hide_small_islands_hint":"عدم رسم الجزر أصغر من 50 ألف كم² لتحسين أداء الأجهزة الضعيفة","hold_drag_move":"اسحب للنقل أو أفلت للمعلومات","in_queue":"قيد البناء","invalid_wokworld":"ملف .WOKWORLD غير صالح","iron":"الحديد","item":"العنصر","just_now":"الآن","l":"قليل","land_10_days":"بري · 10 أيام","landscape":"عرضي","language":"اللغة","load_fail":"فشل التحميل","loading":"تحميل الخريطة…","loading_dots":"جارٍ","locked":"مقفل","long_press_region":"اضغط مطولاً على إقليم","long_press_train":"اضغط مطولاً على إقليمك لبدء التدريب","m":"متوسط","m_short":"د","medium":"متوسط","menu":"القائمة","min_ago":" د","missing":"العالم غير موجود","mode_offline":"بدون اتصال","month":"ش","move_army_attack":"نقل جيش / هجوم","move_failed":"فشل النقل","move_forces":"نقل القوات","move_from_own":"النقل من أقاليمك فقط","move_ui_error":"خطأ واجهة النقل","mute_map_banners":"إخفاء تنبيهات الواجهة","mute_map_banners_hint":"اللافتات الحمراء في قائمة التنبيهات فقط","need_ground_naval":"تحتاج وحدة برية أو بحرية","need_transport":"تحتاج سفن نقل","neighbors":"حدود مع دول","new_world":"عالم جديد","news":"البريد","news_private":"قواتك","news_public":"العامة","next":"التالي","no_alerts":"لا تنبيهات","no_army_here":"لا جيش هنا","no_mobile_forces":"لا قوات متحركة (الجنود فقط تتحرك)","no_news":"لا أخبار بعد","no_target":"لا هدف","no_unit_data":"لا بيانات وحدات","no_units":"لا وحدات","no_units_training":"لا وحدات قيد التدريب","no_worlds":"لا توجد عوالم بعد — اضغط إضافة عالم","not_connected":"غير متصل","not_enough":"غير كافٍ","not_enough_crew":"جنود غير كافين للطاقم","not_enough_oil":"نفط غير كافٍ","not_enough_resources":"موارد غير كافية","not_your_region":"هذا الإقليم ليس تابعًا لك","offline":"بدون اتصال","oil":"النفط","oil_cost_":"تكلفة النفط: ","online":"متصل","open":"متاح","orient":"⟳ عرض","orientAlt":"⟳ طولي","orient_btn":"⟳ عرض","orient_btn_alt":"⟳ طولي","orient_hint":"يقفل كل الشاشات على هذا الوضع","owned":"لديك","owned_":"لديك: ","package_empty":"الحزمة فارغة","play":"العب","portrait":"طولي","power_":"قوة ","price_drop":"هبوط سعر {name} بنحو {pct}%","price_rise":"ارتفاع سعر {name} بنحو {pct}%","prod_time_one":"مدة إنتاج 1","produces":"ينتج","quantity":"الكمية","quit":"خروج","recall_forces":"إعادة / تراجع","recalling_suffix":" (عودة)","region_army":"جيش الإقليم","region_detail":"تفصيل حدود الأقاليم","region_detail_hint":"تفصيل حدود المحافظات · 15–64 · افتراضي 32","regions":"أقاليم","regions_not_linked":"الإقليمان غير متصلين","relations":"العلاقة ","relations_":"العلاقة: ","relations_dot":" · العلاقة ","research_tree":"شجرة الأبحاث","resume":"متابعة اللعب","retry":"إعادة المحاولة","rotateHint":"أدر الجهاز ↻","rotate_hint":"أدر الجهاز ↻","route_":"المسار: ","save":"حفظ","save_quit":"حفظ وخروج","sea_route":"مسار بحري","selected_":"محدد: ","sell":"بيع","send_aid":"نقل مساعدات","sens_hint":"سرعة السحب · الافتراضي 1","sens_pan":"سلاسة السحب","sens_pan_hint":"سرعة السحب · الافتراضي 1","sens_zoom":"سلاسة التكبير","sens_zoom_hint":"سرعة القرص/العجلة · الافتراضي 1","sensitivity":"حساسية الخريطة","settings":"الإعدادات","ships_no_land":"لا يمكن للسفن عبور البر","show_map_stats":"إحصائيات الخريطة","show_map_stats_hint":"عرض معدل الإطارات والتقريب على شريط التاريخ","soldiers":"جنود","soldiers_":"جنود ","storage_per":"التخزين لكل مبنى","sub":"اضغط على أي دولة","tapHint":"اضغط على دولة لعرض معلوماتها","target_":"الهدف: ","title":"اختر دولتك","to_":" إلى ","toggle_off":"إيقاف","toggle_on":"تشغيل","total":"الإجمالي","total_cost":"التكلفة النهائية","trade":"التبادل","training_queue":"طابور التدريب","training_started":"بدأ التدريب","unit_price":"الوحدة","version_hint":"إصدار رسمي","very_easy":"سهل جدا","very_hard":"صعب جدا","vh":"كثير جدا","withdraw":"انسحاب","withdraw_forces":"انسحبوا","world_conquered":"احتلت العالم!","world_name":"اسم العالم","world_name_ph":"أدخل اسم العالم","year":"س","you_suffix":" (أنت)","your_package":"حزمتك","your_worlds":"عوالمك"},"tr":{"active":"aktif","add_world":"Dünya Ekle","aid_received_":"Yardım alındı: ","aid_refused":"Yardım reddedildi (−10% ilişki)","aid_sent_":"Yardım gönderildi · +","alerts":"Uyarılar","alliance_refused":"İttifak reddedildi","amount":"Miktar","army":"Ordu","attack":"Saldırı","back":"‹ Geri","back_list":"← Listeye dön","back_menu":"Geri","barracks_":"Kışla ","blockedCountry":"Antarktika oynanabilir bir ülke değildir.","border_detail":"Ülke sınırları","border_detail_hint":"Dış ülke kenar detayı · 15–64 · varsayılan 32","brand_sub":"Dünya fethi stratejisi","build_embassy":"Elçilik kur (10k altın, 20k demir, 1k petrol)","build_time":"İnşa süresi","building":"bina","buildings":"Binalar","buy":"Satın al","cancel":"İptal","cannot_afford":"Bu paketi karşılayamazsınız","cannot_recall":"Geri çağrılamadı","cannot_train":"Burada eğitim yapılamaz","cat_general":"Genel","cat_touch":"Dokunma","cat_video":"Görüntü","choose":"Seç","choose_action":"İşlem seçin","clear_all":"Tümünü sil","clear_all_close":"Kapat","clear_all_msg":"Tümünü silmek istediğinize emin misiniz?","clear_all_ok":"Sil","clear_all_title":"Tümü silinsin mi?","close":"Kapat","coastal":"Kıyı","confirm":"Onayla","cost":"Maliyet","country_":"Ülke: ","country_label":"Ülke","create_offline":"Çevrimdışı dünya oluştur","day":"g","default_orient":"Varsayılan yön","defensive_alliance":"Savunma ittifakı kuruldu","delete":"Sil","delete_confirm":"“{name}” silinsin mi? Bu işlem geri alınamaz.","delete_world":"Dünyayı sil","difficulty":"Zorluk","done":"Tamam","easy":"Kolay","eco":"Ekonomi puanları (toplam 3.5)","edit":"Düzenle","edit_world":"Dünyayı düzenle","embassy_built":"Elçilik kuruldu","embassy_options":"Elçilik seçenekleri","enlistment":"Askere alma","failed":"Başarısız","fixed_structure":" · Sabit yapı · +1000 asker","forces_en_route":"Birlikler yolda","forces_moving":"Birlikler ilerliyor…","forces_turning_back":"Birlikler üsse dönüyor","forces_withdrawing":"Birlikler geri çekiliyor…","from_":"Kimden ","fx_sub":"Yerel piyasa fiyatları (altın)","fx_title":"Döviz kurları","game_version":"Sürüm","gold":"Altın","gold_unit":" altın","h":"Yüksek","hard":"Zor","hide_small_islands":"Küçük adaları gizle","hide_small_islands_hint":"50.000 km² altındaki adaları çizme (performans)","hold_drag_move":"Taşımak için sürükleyin veya bilgi için bırakın","in_queue":"kuyrukta","invalid_wokworld":"Geçersiz .WOKWORLD dosyası","iron":"Demir","item":"Öğe","just_now":"Az önce","l":"Düşük","land_10_days":"Kara · 10 oyun günü","landscape":"Yatay","language":"Dil","load_fail":"Yükleme başarısız","loading":"Harita yükleniyor…","loading_dots":"…","locked":"Kilitli","long_press_region":"Bir bölgeye uzun basın","long_press_train":"Eğitim için bölgenize uzun basın","m":"Orta","m_short":"dk","medium":"Orta","menu":"Menü","min_ago":" dk önce","missing":"Dünya bulunamadı","mode_offline":"Çevrimdışı","month":"ay","move_army_attack":"Orduyu taşı / Saldır","move_failed":"Hareket başarısız","move_forces":"Birlikleri taşı","move_from_own":"Yalnızca kendi bölgelerinizden hareket","move_ui_error":"Hareket arayüzü hatası","mute_map_banners":"Arayüz uyarılarını gizle","mute_map_banners_hint":"Kırmızı afişler yalnızca Uyarılar listesinde","need_ground_naval":"Kara veya deniz birimi gerekli","need_transport":"Nakliye gemisi gerekli","neighbors":"Kara sınırları","new_world":"Yeni dünya","news":"Haberler","news_private":"Birlikleriniz","news_public":"Genel","next":"İleri","no_alerts":"Uyarı yok","no_army_here":"Burada ordu yok","no_mobile_forces":"Hareketli birlik yok","no_news":"Henüz haber yok","no_target":"Hedef yok","no_unit_data":"Birim verisi yok","no_units":"Birim yok","no_units_training":"Eğitimde birim yok","no_worlds":"Henüz dünya yok — Dünya Ekle’ye dokunun","not_connected":"Bağlı değil","not_enough":"Yetersiz","not_enough_crew":"Mürettebat için yetersiz asker","not_enough_oil":"Yetersiz petrol","not_enough_resources":"Yetersiz kaynak","not_your_region":"Bu sizin bölgeniz değil","offline":"Çevrimdışı","oil":"Petrol","oil_cost_":"Petrol maliyeti: ","online":"Çevrimiçi","open":"Açık","orient":"⟳ Yatay","orientAlt":"⟳ Dikey","orient_btn":"⟳ Yatay","orient_btn_alt":"⟳ Dikey","orient_hint":"Tüm ekranları bu moda kilitler","owned":"Sahip","owned_":"Sahip: ","package_empty":"Paket boş","play":"Oyna","portrait":"Dikey","power_":"Güç ","price_drop":"{name} fiyatı ~%{pct} düştü","price_rise":"{name} fiyatı ~%{pct} arttı","prod_time_one":"1 üretme süresi","produces":"Üretir","quantity":"Miktar","quit":"Çıkış","recall_forces":"Birlikleri geri çağır","recalling_suffix":" (geri dönüş)","region_army":"Bölge ordusu","region_detail":"Bölge sınır detayı","region_detail_hint":"İl kenar detayı · 15–64 · varsayılan 32","regions":"Bölgeler","regions_not_linked":"Bölgeler bağlı değil","relations":"İlişkiler ","relations_":"İlişkiler: ","relations_dot":" · İlişkiler ","research_tree":"Araştırma ağacı","resume":"Oyuna devam","retry":"Yeniden dene","rotateHint":"Cihazı çevirin ↻","rotate_hint":"Cihazı çevirin ↻","route_":"Rota: ","save":"Kaydet","save_quit":"Kaydet ve çık","sea_route":"Deniz rotası","selected_":"Seçili: ","sell":"Sat","send_aid":"Yardım gönder","sens_hint":"Kaydırma hızı · varsayılan 1","sens_pan":"Kaydırma yumuşaklığı","sens_pan_hint":"Sürükleme hızı · varsayılan 1","sens_zoom":"Yakınlaştırma yumuşaklığı","sens_zoom_hint":"Pinch / tekerlek hızı · varsayılan 1","sensitivity":"Harita hassasiyeti","settings":"Ayarlar","ships_no_land":"Gemiler karadan geçemez","show_map_stats":"Harita istatistikleri","show_map_stats_hint":"Tarih çubuğunda FPS ve yakınlaştırmayı göster","soldiers":"Askerler","soldiers_":"Askerler ","storage_per":"Bina başına depolama","sub":"Herhangi bir ülkeye dokunun","tapHint":"Bilgi için bir ülkeye dokunun","target_":"Hedef: ","title":"Ülkenizi seçin","to_":" → ","toggle_off":"Kapalı","toggle_on":"Açık","total":"Toplam","total_cost":"Toplam maliyet","trade":"Ticaret","training_queue":"Eğitim kuyruğu","training_started":"Eğitim başladı","unit_price":"Birim","version_hint":"Sürüm","very_easy":"Çok kolay","very_hard":"Çok zor","vh":"Çok yüksek","withdraw":"Geri çekil","withdraw_forces":"Geri çek","world_conquered":"Dünya fethedildi!","world_name":"Dünya adı","world_name_ph":"Dünya adını girin","year":"y","you_suffix":" (Siz)","your_package":"Paketiniz","your_worlds":"Dünyalarınız"}};

  var STATE = {
    ready: true, // embed is ready immediately
    lang: 'ar',
    byLang: {
      en: Object.assign({}, EMBED.en),
      ar: Object.assign({}, EMBED.ar),
      tr: Object.assign({}, EMBED.tr)
    },
    listeners: []
  };

  function splitCsvLine(line) {
    var out = [], cur = '', inQ = false;
    for (var i = 0; i < line.length; i++) {
      var c = line[i];
      if (inQ) {
        if (c === '"') {
          if (line[i + 1] === '"') { cur += '"'; i++; }
          else inQ = false;
        } else cur += c;
      } else {
        if (c === '"') inQ = true;
        else if (c === ',') { out.push(cur); cur = ''; }
        else cur += c;
      }
    }
    out.push(cur);
    return out;
  }

  function parseCsv(text) {
    var lines = String(text || '').replace(/^\uFEFF/, '').split(/\r?\n/);
    if (!lines.length) return;
    var header = splitCsvLine(lines[0]).map(function (h) { return String(h || '').trim().toLowerCase(); });
    var idxKey = Math.max(0, header.indexOf('key'));
    var idxEn = header.indexOf('en'); if (idxEn < 0) idxEn = 1;
    var idxAr = header.indexOf('ar'); if (idxAr < 0) idxAr = 2;
    var idxTr = header.indexOf('tr'); if (idxTr < 0) idxTr = 3;
    for (var i = 1; i < lines.length; i++) {
      var line = lines[i];
      if (!line || !line.trim()) continue;
      var cols = splitCsvLine(line);
      var key = (cols[idxKey] || '').trim();
      if (!key) continue;
      var enV = cols[idxEn] != null ? cols[idxEn] : '';
      var arV = cols[idxAr] != null ? cols[idxAr] : '';
      var trV = cols[idxTr] != null ? cols[idxTr] : '';
      if (enV !== '') STATE.byLang.en[key] = enV;
      if (arV !== '') STATE.byLang.ar[key] = arV;
      if (trV !== '') STATE.byLang.tr[key] = trV;
      if (enV !== '' && !STATE.byLang.ar[key]) STATE.byLang.ar[key] = enV;
      if (enV !== '' && !STATE.byLang.tr[key]) STATE.byLang.tr[key] = enV;
    }
  }

  function normalizeLang(lang) {
    lang = String(lang || 'ar').toLowerCase();
    return SUPPORTED[lang] ? lang : 'ar';
  }

  function setLang(lang) {
    STATE.lang = normalizeLang(lang);
    return STATE.lang;
  }

  function isRtl(lang) {
    return !!RTL[normalizeLang(lang || STATE.lang)];
  }

  function t(key, fallback) {
    if (!key) return fallback != null ? fallback : '';
    var bag = STATE.byLang[STATE.lang] || {};
    if (bag[key] != null && bag[key] !== '') return bag[key];
    var order = ['en', 'ar', 'tr'];
    for (var i = 0; i < order.length; i++) {
      if (order[i] === STATE.lang) continue;
      var o = STATE.byLang[order[i]] || {};
      if (o[key] != null && o[key] !== '') return o[key];
    }
    if (fallback != null && fallback !== '') return fallback;
    return key;
  }

  function bundle(lang) {
    return Object.assign({}, STATE.byLang[normalizeLang(lang || STATE.lang)] || {});
  }

  function makeCompat() {
    return {
      get en() { return STATE.byLang.en; },
      get ar() { return STATE.byLang.ar; },
      get tr() { return STATE.byLang.tr; }
    };
  }

  function notify() {
    STATE.ready = true;
    STATE.listeners.slice().forEach(function (fn) {
      try { fn(); } catch (_) {}
    });
  }

  function onReady(fn) {
    // Always register so CSV refresh after embed also re-applies scene labels
    if (typeof fn === 'function') STATE.listeners.push(fn);
    if (STATE.ready) { try { fn(); } catch (_) {} }
  }

  function loadFromText(text) {
    parseCsv(text);
    notify();
  }

  function load(url) {
    url = url || 'i18n/translation.csv';
    return fetch(url, { cache: 'no-cache' })
      .then(function (r) {
        if (!r.ok) throw new Error('i18n HTTP ' + r.status);
        return r.text();
      })
      .then(function (text) {
        loadFromText(text);
        return true;
      })
      .catch(function (err) {
        try { console.warn('[WOK_I18N] CSV refresh failed (using embed)', err); } catch (_) {}
        notify();
        return false;
      });
  }

  /** Apply translations to all [data-i18n] / [data-i18n-opt] in document */
  function applyDom(root) {
    root = root || document;
    try {
      root.querySelectorAll('[data-i18n]').forEach(function (el) {
        var k = el.getAttribute('data-i18n');
        if (!k) return;
        var v = t(k, el.textContent);
        if (v != null && v !== '') el.textContent = v;
      });
      root.querySelectorAll('[data-i18n-opt]').forEach(function (el) {
        var k = el.getAttribute('data-i18n-opt');
        if (!k) return;
        var v = t(k, el.textContent);
        if (v != null && v !== '') el.textContent = v;
      });
      root.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
        var k = el.getAttribute('data-i18n-placeholder');
        if (!k) return;
        var v = t(k, el.getAttribute('placeholder') || '');
        if (v != null && v !== '') el.setAttribute('placeholder', v);
      });
    } catch (_) {}
  }

  /** Full scene apply: lang + dir + DOM */
  function applyScene(lang) {
    if (lang) setLang(lang);
    try {
      document.documentElement.lang = STATE.lang;
      document.documentElement.dir = isRtl(STATE.lang) ? 'rtl' : 'ltr';
    } catch (_) {}
    applyDom(document);
  }

  // Init lang from storage
  try {
    var raw = localStorage.getItem('wok_settings');
    if (raw) {
      var s = JSON.parse(raw);
      if (s && s.lang) setLang(s.lang);
    }
  } catch (_) {}

  // Optional CSV refresh (keeps CSV as editable source of truth)
  try { load('i18n/translation.csv'); } catch (_) {}

  global.WOK_I18N = {
    load: load,
    loadFromText: loadFromText,
    t: t,
    setLang: setLang,
    normalizeLang: normalizeLang,
    isRtl: isRtl,
    bundle: bundle,
    onReady: onReady,
    applyDom: applyDom,
    applyScene: applyScene,
    supported: ['ar', 'en', 'tr'],
    get ready() { return STATE.ready; },
    get lang() { return STATE.lang; },
    compat: makeCompat
  };
})(typeof window !== 'undefined' ? window : globalThis);
