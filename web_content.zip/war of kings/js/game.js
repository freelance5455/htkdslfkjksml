/**
 * game.js — PER-1.4.2
 * Logical sections (modularization in progress):
 *   - Settings / worlds / i18n helpers (tKey)
 *   - Resource bar & market
 *   - Region army / move / intent / aid sheets
 *   - Army / enlist / research panels
 *   - News & alerts
 * Panel open/close centralized via js/panels.js (WOK_Panels)
 * Strings: i18n/translation.csv (former _L calls → tKey)
 */
  (function () {
    'use strict';

    const SETTINGS_KEY = 'wok_settings';
    const WORLDS_KEY = 'wok_worlds';
    const ORIENT_SESSION_KEY = 'wok_session_orient';
    const PLAYER_BORDER = '#3db8ff';
    const OTHER_BORDER = 'rgba(255,255,255,0.92)';

    const ID_GOLD = 'WOK:ECONOMY.MATERIAL.GOLD.BAR';
    const ID_IRON = 'WOK:ECONOMY.MATERIAL.IRON.INGOT';
    const ID_OIL  = 'WOK:ECONOMY.MATERIAL.OIL.BARREL';

    /**
     * Difficulty divisors for starting stockpile:
     * amount = (density × item.startAmount) / DIFF_DIV[difficulty]
     */
    const DIFF_DIV = {
      very_easy: 0.5,
      easy: 0.75,
      medium: 1,
      hard: 1.5,
      very_hard: 2
    };

    function isEnUi() {
      const lang = (typeof settings !== 'undefined' && settings.lang) || 'ar';
      return lang === 'en' || lang === 'tr';
    }
    function _L(en, ar, tr) {
      const lang = (typeof settings !== 'undefined' && settings.lang) || 'ar';
      if (lang === 'en') return en;
      if (lang === 'tr') return (tr != null && tr !== '') ? tr : en;
      return ar;
    }

    function bagLang() {
      if (window.WOK_I18N && WOK_I18N.bundle) {
        return WOK_I18N.bundle(settings.lang) || {};
      }
      const I = (window.WOK_I18N && WOK_I18N.compat) ? WOK_I18N.compat() : { en: {}, ar: {}, tr: {} };
      return I[settings.lang] || I.en || I.ar || {};
    }
const I18N = (window.WOK_I18N && WOK_I18N.compat) ? WOK_I18N.compat() : { en: {}, ar: {} };
    function tKey(key, fallback) {
      if (window.WOK_I18N && WOK_I18N.t) {
        if (window.WOK_I18N.setLang) WOK_I18N.setLang((typeof settings !== 'undefined' && settings.lang) || 'ar');
        return WOK_I18N.t(key, fallback);
      }
      const lang = (typeof settings !== 'undefined' && settings.lang) || 'ar';
      const bag = I18N[lang] || I18N.ar || {};
      return (bag[key] != null && bag[key] !== '') ? bag[key] : (fallback != null ? fallback : key);
    }

    function loadSettings() {
      if (window.WOK_Settings && WOK_Settings.load) return WOK_Settings.load();
      try {
        const raw = localStorage.getItem(SETTINGS_KEY);
        const d = raw ? JSON.parse(raw) : {};
        const perf = (window.WOK_perfDefaults && WOK_perfDefaults()) || {};
        const base = {
          lang: 'ar', orient: 'landscape', sensitivity: 1, panSensitivity: 1, zoomSensitivity: 1,
          hideSmallIslands: !!perf.hideSmallIslands, showMapStats: false, muteMapBanners: false,
          countryBorderDetail: perf.countryBorderDetail != null ? perf.countryBorderDetail : 28,
          regionBorderDetail: perf.regionBorderDetail != null ? perf.regionBorderDetail : 28
        };
        return Object.assign(base, d || {});
      } catch (_) {
        const perf = (window.WOK_perfDefaults && WOK_perfDefaults()) || {};
        return {
          lang: 'ar', orient: 'landscape', sensitivity: 1, panSensitivity: 1, zoomSensitivity: 1,
          hideSmallIslands: !!perf.hideSmallIslands, showMapStats: false, muteMapBanners: false,
          countryBorderDetail: perf.countryBorderDetail != null ? perf.countryBorderDetail : 28,
          regionBorderDetail: perf.regionBorderDetail != null ? perf.regionBorderDetail : 28
        };
      }
    }
    function saveSettings(s) {
      // Always merge-save via WOK_Settings so no key is wiped
      if (window.WOK_Settings && WOK_Settings.save) {
        settings = WOK_Settings.save(s || settings);
        return settings;
      }
      try {
        const cur = loadSettings();
        const next = Object.assign({}, cur, s || {});
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
        settings = next;
        return next;
      } catch (_) { return s; }
    }
    function loadWorlds() {
      try {
        const raw = localStorage.getItem(WORLDS_KEY);
        const list = raw ? JSON.parse(raw) : [];
        return Array.isArray(list) ? list : [];
      } catch (_) { return []; }
    }
    function saveWorlds(list) {
      localStorage.setItem(WORLDS_KEY, JSON.stringify(list));
    }
    function rememberOrient(mode, permanent) {
      if (mode !== 'landscape' && mode !== 'portrait') return;
      try { sessionStorage.setItem(ORIENT_SESSION_KEY, mode); } catch (_) {}
      try { localStorage.setItem(ORIENT_SESSION_KEY, mode); } catch (_) {}
      if (permanent) {
        try {
          const raw = localStorage.getItem(SETTINGS_KEY);
          const s = raw ? JSON.parse(raw) : {};
          s.orient = mode;
          localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
          if (typeof settings !== 'undefined') settings.orient = mode;
        } catch (_) {}
      }
    }
    function readSavedOrient() {
      try {
        const raw = localStorage.getItem(SETTINGS_KEY);
        if (raw) {
          const s = JSON.parse(raw);
          if (s && (s.orient === 'landscape' || s.orient === 'portrait')) return s.orient;
        }
      } catch (_) {}
      try {
        const q = new URLSearchParams(location.search || '').get('orient');
        if (q === 'landscape' || q === 'portrait') return q;
      } catch (_) {}
      try {
        const a = sessionStorage.getItem(ORIENT_SESSION_KEY);
        if (a === 'landscape' || a === 'portrait') return a;
      } catch (_) {}
      return null;
    }
    function readSessionOrient() { return readSavedOrient(); }

    let settings = loadSettings();
    if (window.WOK_I18N && WOK_I18N.setLang) WOK_I18N.setLang(settings.lang);
    // PER-1.3.3: re-apply language on every scene open
    try {
      if (window.WOK_I18N && WOK_I18N.applyScene) WOK_I18N.applyScene(settings.lang);
    } catch (_) {}
    // Apply saved orientation immediately
    try {
      rememberOrient(settings.orient === 'portrait' ? 'portrait' : 'landscape', false);
      setTimeout(function () { try { applyDefaultOrient(false); } catch (e) {} }, 120);
      setTimeout(function () { try { applyDefaultOrient(false); } catch (e) {} }, 600);
    } catch (_) {}
    if (window.WOK_I18N && WOK_I18N.onReady) {
      WOK_I18N.onReady(function () {
        try {
          if (window.WOK_I18N.applyScene) WOK_I18N.applyScene(settings.lang);
          applyI18n();
        } catch (_) {}
      });
    }
    if (window.WOK_I18N && WOK_I18N.load) {
      try {
        WOK_I18N.load('i18n/translation.csv').then(function () {
          try {
            if (window.WOK_I18N.applyScene) WOK_I18N.applyScene(settings.lang);
            applyI18n();
          } catch (_) {}
        });
      } catch (_) {}
    }
    let t = bagLang();

    // Resolve world id
    const params = new URLSearchParams(location.search || '');
    const worldId = params.get('id') || '';
    let world = loadWorlds().find(w => w.id === worldId) || null;
    // Recency for worlds list: last opened rises to top
    if (world && world.id) {
      try {
        world.lastOpenedAt = Date.now();
        const list = loadWorlds();
        const ix = list.findIndex(function (x) { return x && x.id === world.id; });
        if (ix >= 0) {
          list[ix].lastOpenedAt = world.lastOpenedAt;
          saveWorlds(list);
        }
      } catch (_) {}
    }

    const MS_PER_GAME_DAY = 10000; // 10 real seconds = 1 game day
    const DAYS_PER_MONTH = 30;
    const MONTHS_PER_YEAR = 12;
    const DAYS_PER_YEAR = DAYS_PER_MONTH * MONTHS_PER_YEAR; // 360
    const MARKET_HISTORY_YEARS = 50;
    /** Rolling window in game-days (option ب): last 50 years continuously */
    const MARKET_WINDOW_DAYS = MARKET_HISTORY_YEARS * DAYS_PER_YEAR; // 18000
    const LOCAL_PRICE_MIN = 0.25;

    // Ensure world has game state fields
    function ensureWorldState(w) {
      if (!w) return w;
      if (!w.game) w.game = {};
      if (w.game.version == null) w.game.version = 1;
      if (!w.game.playerCountry) w.game.playerCountry = w.country || null;
      if (!w.game.stockpile || typeof w.game.stockpile !== 'object') {
        w.game.stockpile = {};
      }
      if (w.game.occupied == null) w.game.occupied = {};
      if (!w.game.calendarStartedAt) w.game.calendarStartedAt = w.createdAt || Date.now();
      if (!w.game.market || typeof w.game.market !== 'object') {
        w.game.market = { localPrice: {}, history: [] };
      }
      if (!w.game.market.localPrice) w.game.market.localPrice = {};
      if (!Array.isArray(w.game.market.history)) w.game.market.history = [];
      if (!w.game.buildings || typeof w.game.buildings !== 'object') w.game.buildings = {};
      if (!w.game.buildQueue || typeof w.game.buildQueue !== 'object') w.game.buildQueue = {};
      if (w.game.lastProductionAt == null) w.game.lastProductionAt = Date.now();
      return w;
    }
    if (world) {
      world = ensureWorldState(world);
    }

    function dispInt(n) {
      return Math.floor(Number(n) || 0);
    }
    /** Show integer, or up to 2 decimals when fractional part is non-zero */
    function dispPrice(n) {
      const v = Number(n);
      if (!isFinite(v)) return '0';
      const flo = Math.floor(v);
      const cents = Math.round((v - flo) * 100);
      if (cents === 0) return String(flo);
      return (flo + cents / 100).toFixed(2);
    }
    function buildIconPath(b) {
      const rel = (b && (b.icon || b.texture)) || '';
      if (!rel) return '';
      if (rel.indexOf('builds/') === 0 || rel.indexOf('/') === 0) return rel;
      return 'builds/' + rel;
    }
    function getBuildCount(id) {
      if (!world || !world.game || !world.game.buildings) return 0;
      return Math.max(0, Math.floor(Number(world.game.buildings[id]) || 0));
    }
    function setBuildCount(id, n) {
      if (!world || !world.game) return;
      if (!world.game.buildings) world.game.buildings = {};
      world.game.buildings[id] = Math.max(0, Math.floor(Number(n) || 0));
    }
    function listBasicBuilds() {
      if (window.WOK && typeof window.WOK.getBasicBuilds === 'function') {
        return window.WOK.getBasicBuilds() || [];
      }
      if (window.WOK_BUILDS && window.WOK_BUILDS.basic) return window.WOK_BUILDS.basic;
      return [];
    }
    /** Real minutes → game calendar text (10s real = 1 game day) */
    function formatGameDurationFromRealMinutes(mins) {
      const m = Number(mins) || 0;
      const days = Math.max(0, Math.round(m * 6)); // 60s/min / 10s/day
      if (days <= 0) return '0' + (t.day || 'd');
      const years = Math.floor(days / DAYS_PER_YEAR);
      const months = Math.floor((days % DAYS_PER_YEAR) / DAYS_PER_MONTH);
      const d = days % DAYS_PER_MONTH;
      const parts = [];
      if (years > 0) parts.push(years + (t.year || 'y'));
      if (months > 0) parts.push(months + (t.month || 'mo'));
      if (d > 0 || parts.length === 0) parts.push(d + (t.day || 'd'));
      return parts.join(' ');
    }
    /** Real seconds for one unit of production */
    function prodSecondsPerUnit(build) {
      if (!build || !build.production) return 0;
      const aps = Number(build.production.amountPerSecond);
      if (aps > 0) return 1 / aps;
      const apm = Number(build.production.amountPerMinute);
      if (apm > 0) return 60 / apm;
      return 0;
    }
    function seedStartingBuildings() {
      if (!world || !world.game) return;
      if (world.game.buildingsSeedOk) return;
      const list = (window.WOK_BUILDS && window.WOK_BUILDS.list) || listBasicBuilds();
      if (!list.length) return false;
      list.forEach(function (b) {
        if (!b || !b.identifier) return;
        if (world.game.buildings[b.identifier] == null) {
          const n = Math.max(0, Math.floor(Number(b.defaultStartingCount) || 0));
          world.game.buildings[b.identifier] = n;
        }
      });
      world.game.buildingsSeedOk = true;
      if (world.game.lastProductionAt == null) world.game.lastProductionAt = Date.now();
      persistWorld(world);
      return true;
    }
    function processBuildQueue(now) {
      if (!world || !world.game || !world.game.buildQueue) return;
      const q = world.game.buildQueue;
      Object.keys(q).forEach(function (id) {
        const job = q[id];
        if (!job || !job.remaining || job.remaining <= 0) {
          delete q[id];
          return;
        }
        const build = window.WOK && window.WOK.getBuild ? window.WOK.getBuild(id) : null;
        const mins = build ? Number(build.buildTimeMinutes) || 1 : 1;
        const ms = mins * 60 * 1000;
        if (!job.endsAt) {
          job.endsAt = (job.startedAt || now) + ms;
        }
        // complete as many sequential builds as time allows
        let guard = 0;
        while (job.remaining > 0 && job.endsAt <= now && guard < 10000) {
          guard++;
          setBuildCount(id, getBuildCount(id) + 1);
          job.remaining -= 1;
          if (job.remaining > 0) {
            job.startedAt = job.endsAt;
            job.endsAt = job.startedAt + ms;
          }
        }
        if (job.remaining <= 0) delete q[id];
        else q[id] = job;
      });
    }
    function applyProduction(now) {
      if (!world || !world.game) return;
      const last = world.game.lastProductionAt || now;
      let dt = (now - last) / 1000;
      if (dt <= 0) return;
      if (dt > 30 * 24 * 3600) dt = 30 * 24 * 3600;
      let dens = { gold: 1, iron: 1, oil: 1 };
      try {
        const c = world.game.playerCountry || world.country;
        if (typeof engine !== 'undefined' && engine && engine.getCountryResources) {
          dens = engine.getCountryResources(c) || dens;
        }
      } catch (_) {}
      const densityFor = function (resId) {
        if (resId === ID_GOLD) return Number(dens.gold) || 0;
        if (resId === ID_IRON) return Number(dens.iron) || 0;
        if (resId === ID_OIL) return Number(dens.oil) || 0;
        return 1;
      };
      const list = (window.WOK_BUILDS && window.WOK_BUILDS.list) || listBasicBuilds();
      list.forEach(function (b) {
        if (!b || !b.production || !b.production.resource) return;
        const count = getBuildCount(b.identifier);
        if (count <= 0) return;
        let rate = Number(b.production.amountPerSecond);
        if (!(rate > 0)) {
          const apm = Number(b.production.amountPerMinute);
          rate = apm > 0 ? apm / 60 : 0;
        }
        if (!(rate > 0)) return;
        const resId = b.production.resource;
        // baseRate × buildings × economy density for that resource
        const produced = rate * count * dt * densityFor(resId);
        const storageEach = Number(b.storagePerBuilding);
        const cap = (isFinite(storageEach) ? storageEach : 0) * count;
        const cur = getStock(resId);
        if (cap > 0 && cur >= cap) return;
        let next = cur + produced;
        if (cap > 0 && next > cap) next = cap;
        setStock(resId, next);
      });
      world.game.lastProductionAt = now;
    }
    function drainAlertLog() {
      if (!world || !world.game || !world.game.alertLog || !world.game.alertLog.length) return;
      const incoming = world.game.alertLog.splice(0, world.game.alertLog.length);
      // Newest last in log when unshifting; show latest on banner, archive all once after 5s
      for (let i = 0; i < incoming.length; i++) {
        const it = incoming[i];
        // Queue structured alert (panel) — top banner only for the freshest
        pushAlert(it.title || '', it.body || '', it.meta || {});
      }
      const last = incoming[0];
      if (last) {
        const line = (last.title ? (last.title + ' — ') : '') + (last.body || '');
        // asAlert=false: already in list via pushAlert
        showMapHint(line, false);
      }
    }
    function tickEconomy() {
      if (!world || !world.game) return;
      const now = Date.now();
      processBuildQueue(now);
      applyProduction(now);
      if (window.WOK_Military) {
        WOK_Military.tickAll(world, engine, playerCountry, getStock, setStock, function (rk, mode, defender) {
          // Event-only visuals (not every economy tick)
          if (mode === 'contest' || mode === 'holding') {
            if (!window._wokRedRegions) window._wokRedRegions = {};
            if (!window._wokRedRegions[rk]) {
              window._wokRedRegions[rk] = true;
              try { engine.setRegionBorder(rk, '#ff2020', 2.2, true); } catch (_) {}
              try { engine.setDirty && engine.setDirty(); } catch (_) {}
            }
          }
          if (mode === 'annex' || mode === 'clear') {
            const rkS = String(rk);
            if (window._wokRedRegions) delete window._wokRedRegions[rkS];
            try { if (engine.clearRegionStyle) engine.clearRegionStyle(rkS); } catch (_) {}
            try {
              if (engine.syncContestBorders && window.WOK_Military) {
                const alive = (WOK_Military.activeBattles(world) || [])
                  .filter(function (b) { return b && (b.status === 'fighting' || b.status === 'holding') && String(b.region) !== rkS; })
                  .map(function (b) { return String(b.region); });
                engine.syncContestBorders(alive, '#ff2020', 1.6);
              } else {
                reapplyContestBorders(true);
              }
            } catch (_) {}
            if (mode === 'annex') {
              try { lootDefenderBuildings(defender, rk); } catch (_) {}
              window._wokBordersKey = null;
              try { applyPlayerBorders(true); } catch (e) {}
              try { snapshotOccupation(world); } catch (_) {}
              try { checkWorldVictory(); } catch (_) {}
            }
            try { engine.setDirty && engine.setDirty(); } catch (_) {}
          }
          try { refreshBattleBar(); } catch (_) {}
        });
        // Move list: only when count changes (not every economy tick)
        if (engine && engine.setMilitaryMoves && window.WOK_Military) {
          const mv = WOK_Military.activeMoves(world) || [];
          const sig = mv.length + ':' + (mv[0] && mv[0].id || '') + ':' + (mv[mv.length-1] && mv[mv.length-1].id || '');
          if (window._wokMoveSig !== sig) {
            window._wokMoveSig = sig;
            engine.setMilitaryMoves(mv);
          }
        }
        if (!window._wokBattleBarAt || Date.now() - window._wokBattleBarAt > 3000) {
          window._wokBattleBarAt = Date.now();
          try { refreshBattleBar(); } catch (_) {}
        }
        try { drainAlertLog(); } catch (_) {}
      }
      // Bot: max ~3 Hz — heavy work is inside bot.js and already capped
      if (window.WOK_Bot) {
        const nowB = Date.now();
        if (!window._wokBotAt || nowB - window._wokBotAt > 1200) {
          window._wokBotAt = nowB;
          WOK_Bot.tick(world, engine, playerCountry);
          if (typeof updateNewsBadge === 'function') updateNewsBadge();
        }
      }
      // Persist at most every 2s (was every tick — caused freezes)
      const nowP = Date.now();
      if (!window._wokPersistAt || nowP - window._wokPersistAt > 10000) {
        window._wokPersistAt = nowP;
        persistWorld(world);
      }
      renderResBar();
    }
    function queueBuild(id, qty) {
      if (!world || !world.game || qty < 1) return false;
      const build = window.WOK && window.WOK.getBuild ? window.WOK.getBuild(id) : null;
      if (!build) return false;
      const cost = build.cost || {};
      // affordability
      for (const resId of Object.keys(cost)) {
        const need = Number(cost[resId]) * qty;
        if (getStock(resId) < need) return false;
      }
      // pay
      Object.keys(cost).forEach(function (resId) {
        setStock(resId, getStock(resId) - Number(cost[resId]) * qty);
      });
      if (!world.game.buildQueue) world.game.buildQueue = {};
      const now = Date.now();
      const mins = Number(build.buildTimeMinutes) || 1;
      const ms = mins * 60 * 1000;
      let job = world.game.buildQueue[id];
      if (job && job.remaining > 0) {
        job.remaining += qty;
      } else {
        job = { remaining: qty, startedAt: now, endsAt: now + ms };
      }
      world.game.buildQueue[id] = job;
      persistWorld(world);
      renderResBar();
      return true;
    }
    function globalRate(id) {
      if (window.WOK && typeof window.WOK.getExchangeRate === 'function') {
        return window.WOK.getExchangeRate(id);
      }
      if (id === ID_GOLD) return 1;
      const item = window.WOK_ITEMS && window.WOK_ITEMS.get ? window.WOK_ITEMS.get(id) : null;
      return item && isFinite(Number(item.exchangeRate)) ? Number(item.exchangeRate) : 0;
    }
    /** Per-item local bounds from JSON (fallback 0.25 .. 4; gold 1..1) */
    function itemLocalBounds(id) {
      if (id === ID_GOLD) return { min: 1, max: 1 };
      const item = window.WOK_ITEMS && window.WOK_ITEMS.get ? window.WOK_ITEMS.get(id) : null;
      let minL = 0.25, maxL = 4;
      if (item) {
        if (item.minLocalPrice != null && isFinite(Number(item.minLocalPrice))) minL = Number(item.minLocalPrice);
        if (item.maxLocalPrice != null && isFinite(Number(item.maxLocalPrice))) maxL = Number(item.maxLocalPrice);
      }
      if (!(maxL >= minL)) { minL = 0.25; maxL = 4; }
      return { min: minL, max: maxL };
    }
    function clampLocalPrice(id, v) {
      const b = itemLocalBounds(id);
      let x = Number(v);
      if (!isFinite(x) || x <= 0) x = 1;
      if (x < b.min) x = b.min;
      if (x > b.max) x = b.max;
      return x;
    }
    function localPrice(id) {
      if (!world || !world.game || !world.game.market) return 1;
      if (id === ID_GOLD) return 1;
      const v = world.game.market.localPrice[id];
      if (v == null || !isFinite(Number(v))) return 1;
      return clampLocalPrice(id, v);
    }
    function unitBuyPrice(id) {
      return globalRate(id) * localPrice(id);
    }
    function unitSellPrice(id) {
      // Always 10% below buy at the same local mid (display / bots)
      return 0.9 * unitBuyPrice(id);
    }
    /**
     * Full demand/supply impact (no per-trade ±2% cap).
     * Clamped only by item minLocalPrice / maxLocalPrice from JSON.
     */
    function applyLocalImpact(id, qty, isBuy) {
      if (!id || id === ID_GOLD || !world || !world.game || !world.game.market) return;
      if (!world.game.market.localPrice) world.game.market.localPrice = {};
      let loc = Number(world.game.market.localPrice[id]);
      if (!isFinite(loc) || loc <= 0) loc = 1;
      const q = Math.min(Math.max(0, Math.floor(Number(qty) || 0)), 500000);
      const factor = Math.pow(1.00001, q);
      if (!isFinite(factor) || factor <= 0) return;
      if (isBuy) loc *= factor;
      else loc /= factor;
      world.game.market.localPrice[id] = clampLocalPrice(id, loc);
    }
    function gameDaysElapsed() {
      if (!world || !world.game) return 0;
      const start = world.game.calendarStartedAt || world.createdAt || Date.now();
      return Math.max(0, Math.floor((Date.now() - start) / MS_PER_GAME_DAY));
    }
    function calendarParts() {
      const totalDays = gameDaysElapsed();
      const years = Math.floor(totalDays / DAYS_PER_YEAR);
      const rem = totalDays % DAYS_PER_YEAR;
      const months = Math.floor(rem / DAYS_PER_MONTH);
      const days = rem % DAYS_PER_MONTH;
      return { years: years, months: months, days: days, totalDays: totalDays };
    }
    function formatCalendar() {
      const p = calendarParts();
      const yy = p.years < 10 ? ('0' + p.years) : String(p.years);
      return yy + '/' + p.months + '/' + p.days;
    }
    function updateDateBar() {
      const el = document.getElementById('date-text') || document.getElementById('date-bar');
      if (el) el.textContent = formatCalendar();
    }
    function currentGameYear() {
      return Math.floor(gameDaysElapsed() / DAYS_PER_YEAR);
    }
    /** Normalize legacy year-rows → day-rows, then prune to rolling window (ب). */
    function pruneMarketHistory(today) {
      if (!world.game.market.history) world.game.market.history = [];
      const minDay = Math.max(0, today - MARKET_WINDOW_DAYS + 1);
      world.game.market.history = world.game.market.history
        .map(function (h) {
          if (h.day == null && h.year != null) {
            // migrate old year-bucket to mid-year day approx
            return {
              day: Number(h.year) * DAYS_PER_YEAR,
              buys: h.buys || {},
              sells: h.sells || {}
            };
          }
          return h;
        })
        .filter(function (h) {
          return isFinite(Number(h.day)) && Number(h.day) >= minDay;
        })
        .sort(function (a, b) { return a.day - b.day; });
    }
    function ensureMarketDay(day) {
      pruneMarketHistory(day);
      let row = world.game.market.history.find(function (h) { return h.day === day; });
      if (!row) {
        row = { day: day, buys: {}, sells: {} };
        world.game.market.history.push(row);
      }
      return row;
    }
    function recordTrade(id, qty, isBuy) {
      const day = gameDaysElapsed();
      const row = ensureMarketDay(day);
      const bag = isBuy ? row.buys : row.sells;
      const q = Math.min(Math.max(0, Math.floor(Number(qty) || 0)), 500000);
      bag[id] = (bag[id] || 0) + q;
      // Impact applied by confirmTrade in correct order; bots rely on recordTrade
      if (!world.game.market._skipImpactOnce) {
        applyLocalImpact(id, q, isBuy);
      }
      world.game.market._skipImpactOnce = false;
      recomputeLocalPrices();
    }
    /**
     * Local price from last-50y buy/sell volume (player + bots).
     * Each +1 buy:  × 1.00001  (≈ +0.001% = 1/100000)
     * Each +1 sell: × 0.99999  (≈ −0.001%)
     * y = (1.00001)^buys * (0.99999)^sells
     * Gold local stays 1.
     */
    function recomputeLocalPrices() {
      if (!world || !world.game || !world.game.market) return;
      const today = gameDaysElapsed();
      pruneMarketHistory(today);
      const minDay = Math.max(0, today - MARKET_WINDOW_DAYS + 1);
      const hist = (world.game.market.history || []).filter(function (h) {
        return h.day >= minDay && h.day <= today;
      });
      let ids = [];
      if (window.WOK_ITEMS && window.WOK_ITEMS.list) {
        ids = window.WOK_ITEMS.list.map(function (i) { return i.identifier; });
      } else {
        ids = [ID_GOLD, ID_IRON, ID_OIL];
      }
      // Long-run soft target from net volume (diminishing). Does NOT overwrite
      // short-term incremental moves aggressively — blend 15% toward target.
      // Hard clamp [0.5, 2] so 10% sell spread can never be outrun by mid swings.
      const BUY_LN = Math.log(1.00001);
      if (!world.game.market._lastAnnounced) world.game.market._lastAnnounced = {};
      ids.forEach(function (id) {
        if (id === ID_GOLD) {
          world.game.market.localPrice[id] = 1;
          return;
        }
        let buy = 0, sell = 0;
        for (let i = 0; i < hist.length; i++) {
          const h = hist[i];
          buy += Number(h.buys && h.buys[id]) || 0;
          sell += Number(h.sells && h.sells[id]) || 0;
        }
        const prev = Number(world.game.market.localPrice[id]);
        const cur = (isFinite(prev) && prev > 0) ? prev : 1;
        const net = buy - sell;
        let target = Math.exp(Math.sign(net) * Math.log1p(Math.abs(net)) * BUY_LN);
        if (!isFinite(target) || target <= 0) target = 1;
        if (target < 0.5) target = 0.5;
        if (target > 2) target = 2;
        // Gentle blend so history cannot yank price through the 10% spread in one tick
        let next = cur * 0.85 + target * 0.15;
        next = clampLocalPrice(id, next);
        world.game.market.localPrice[id] = next;
        // World news on big sudden swings (>= 8% vs last announced)
        const lastA = world.game.market._lastAnnounced[id];
        const base = (lastA != null && isFinite(lastA)) ? lastA : (isFinite(prev) ? prev : 1);
        const ratio = next / Math.max(1e-9, base);
        if (ratio <= 0.92 || ratio >= 1.08) {
          world.game.market._lastAnnounced[id] = next;
          if (window.WOK_News && typeof WOK_News.addPublic === 'function') {
            const name = (id === ID_OIL) ? (tKey("oil_2", "Oil"))
              : (id === ID_IRON) ? (tKey("iron_2", "Iron"))
              : id;
            const pct = Math.round(Math.abs(ratio - 1) * 100);
            const down = ratio < 1;
            const reason = down
              ? (isEnUi()
                ? ('Heavy selling pressure over recent decades (sell volume high vs buy).')
                : ('ضغط بيع قوي خلال العقود الأخيرة (حجم البيع أعلى من الشراء).'))
              : (isEnUi()
                ? ('Strong buying demand over recent decades (buy volume high vs sell).')
                : ('طلب شراء قوي خلال العقود الأخيرة (حجم الشراء أعلى من البيع).'));
            try {
              WOK_News.addPublic(world, {
                title: down
                  ? (isEnUi() ? (name + ' price drops ~' + pct + '%') : ('هبوط سعر ' + name + ' بنحو ' + pct + '%'))
                  : (isEnUi() ? (name + ' price rises ~' + pct + '%') : ('ارتفاع سعر ' + name + ' بنحو ' + pct + '%')),
                body: reason,
                type: 'market',
                meta: { resource: id, ratio: ratio }
              });
            } catch (_) {}
          }
        }
      });
    }

    // Exposed for bots
    window.WOK_Market = {
      recordTrade: function (id, qty, isBuy) { recordTrade(id, qty, isBuy); },
      recompute: function () { recomputeLocalPrices(); },
      localPrice: function (id) { return localPrice(id); }
    };
    function ensureLocalPricesSeeded() {
      if (!world || !world.game) return;
      let list = [];
      if (window.WOK_ITEMS && window.WOK_ITEMS.list) list = window.WOK_ITEMS.list;
      list.forEach(function (item) {
        if (!item || !item.identifier) return;
        if (world.game.market.localPrice[item.identifier] == null) {
          world.game.market.localPrice[item.identifier] = 1;
        }
      });
    }

    function getStock(id) {
      if (!world || !world.game || !world.game.stockpile) return 0;
      const v = world.game.stockpile[id];
      return isFinite(Number(v)) ? Number(v) : 0;
    }
    function setStock(id, amount) {
      if (!world) return;
      if (!world.game) world.game = {};
      if (!world.game.stockpile) world.game.stockpile = {};
      world.game.stockpile[id] = Math.max(0, Math.round(Number(amount) || 0));
    }
    function formatAmount(n) {
      const v = Math.round(Number(n) || 0);
      try { return v.toLocaleString('en-US'); } catch (_) { return String(v); }
    }
    function itemUnit(item) {
      if (!item) return '';
      if (typeof item.unitSymbol === 'string') return item.unitSymbol;
      if (typeof item.unit === 'string') return item.unit;
      if (item.unit && typeof item.unit === 'object') {
        return item.unit[settings.lang] || item.unit.en || item.unit.ar || '';
      }
      return '';
    }
    function itemIconPath(item) {
      const rel = (item && (item.icon || item.texture)) || '';
      if (!rel) return '';
      if (rel.indexOf('items/') === 0 || rel.indexOf('/') === 0) return rel;
      return 'items/' + rel;
    }

    /**
     * First open stockpile:
     * amount = (startAmount × density) / difficultyDiv
     * difficultyDiv: VE 0.5 … M 1 … VH 2
     */
    function initStockpileIfNeeded(engine) {
      if (!world || !world.game) return;
      // Already successfully seeded
      if (world.game.stockpileSeedOk) return;

      const startOf = function (id) {
        if (window.WOK && typeof window.WOK.getStartAmount === 'function') {
          return window.WOK.getStartAmount(id);
        }
        const item = window.WOK_ITEMS && window.WOK_ITEMS.get ? window.WOK_ITEMS.get(id) : null;
        return item && isFinite(Number(item.startAmount)) ? Number(item.startAmount) : 0;
      };

      // Wait until item data is available (avoid seeding 0 because Translator not ready)
      const sGold = startOf(ID_GOLD);
      const sIron = startOf(ID_IRON);
      const sOil = startOf(ID_OIL);
      if (sGold <= 0 && sIron <= 0 && sOil <= 0) {
        return false; // not ready yet
      }

      let country = world.game.playerCountry || world.country;
      if (engine && engine.resolveCountryName) {
        country = engine.resolveCountryName(country) || country;
      }
      const res = engine && engine.getCountryResources
        ? engine.getCountryResources(country)
        : { gold: 0, iron: 0, oil: 0 };
      const div = DIFF_DIV[world.difficulty] != null ? DIFF_DIV[world.difficulty] : 1;
      const densityOf = function (id) {
        if (id === ID_GOLD) return Number(res.gold) || 0;
        if (id === ID_IRON) return Number(res.iron) || 0;
        if (id === ID_OIL) return Number(res.oil) || 0;
        return 0;
      };

      setStock(ID_GOLD, (densityOf(ID_GOLD) * sGold) / div);
      setStock(ID_IRON, (densityOf(ID_IRON) * sIron) / div);
      setStock(ID_OIL,  (densityOf(ID_OIL)  * sOil)  / div);

      world.game.stockpileInitialized = true;
      world.game.stockpileSeedOk = true;
      persistWorld(world);
      return true;
    }

    function tryInitStockpile(engine) {
      if (initStockpileIfNeeded(engine)) {
        renderResBar();
        return;
      }
      // retry a few times until Translator/WOK ready
      let tries = 0;
      const t = setInterval(function () {
        tries++;
        if (initStockpileIfNeeded(engine) || tries > 40) {
          clearInterval(t);
          renderResBar();
        }
      }, 50);
    }

    // ── PER-1.4.2 resource bar: memory every frame, DOM every 250ms / significant change ──
    var _resBarMem = Object.create(null);   // id → last numeric stock
    var _resBarDom = Object.create(null);   // id → last displayed string
    var _resBarAmtEl = Object.create(null); // PER-1.4.3 id → .amt el
    var _resBarDirty = false;
    var _resBarRaf = null;
    var _resBarLastDom = 0;
    var _resBarBuilt = false;
    var _resBarForce = false;
    var RES_BAR_DOM_MS = 250;
    var RES_BAR_MIN_DELTA = 0.05; // relative change to force immediate paint

    function _resBarBasics() {
      var basics = [];
      try {
        if (window.WOK && typeof window.WOK.getBasicResources === 'function') {
          basics = window.WOK.getBasicResources() || [];
        } else if (window.WOK_ITEMS && window.WOK_ITEMS.basic) {
          basics = window.WOK_ITEMS.basic;
        }
      } catch (_) { basics = []; }
      if (!basics || !basics.length) {
        basics = [
          { identifier: ID_GOLD, name: { en: 'Gold', ar: 'ذهب' }, unitSymbol: '' },
          { identifier: ID_IRON, name: { en: 'Iron', ar: 'حديد' }, unitSymbol: '' },
          { identifier: ID_OIL, name: { en: 'Oil', ar: 'نفط' }, unitSymbol: '' }
        ];
        if (!window._wokResBarRetry) {
          window._wokResBarRetry = setTimeout(function () {
            window._wokResBarRetry = null;
            _resBarBuilt = false;
            _resBarForce = true;
            try { renderResBar(); } catch (_) {}
          }, 800);
        }
      }
      return basics;
    }

    function _resBarEnsureDom(bar, basics) {
      if (_resBarBuilt && bar.childElementCount) return;
      bar.innerHTML = '';
      _resBarDom = Object.create(null);
      _resBarAmtEl = Object.create(null);
      basics.forEach(function (item) {
        if (!item || !item.identifier) return;
        var id = item.identifier;
        var chip = document.createElement('div');
        chip.className = 'res-chip';
        chip.setAttribute('data-id', id);
        var img = document.createElement('img');
        img.src = itemIconPath(item);
        img.alt = '';
        var sep = document.createElement('span');
        sep.className = 'sep';
        sep.textContent = ':';
        var amt = document.createElement('span');
        amt.className = 'amt';
        amt.textContent = '0';
        var unit = document.createElement('span');
        unit.className = 'unit';
        unit.textContent = itemUnit(item);
        chip.appendChild(img);
        chip.appendChild(sep);
        chip.appendChild(amt);
        if (unit.textContent) chip.appendChild(unit);
        bar.appendChild(chip);
        _resBarDom[id] = '0';
        _resBarAmtEl[id] = amt;
      });
      _resBarBuilt = true;
    }

    function _resBarWriteDom(force) {
      var bar = document.getElementById('res-bar');
      if (!bar) return;
      var basics = _resBarBasics();
      _resBarEnsureDom(bar, basics);
      var now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
      if (!force && !_resBarForce && (now - _resBarLastDom) < RES_BAR_DOM_MS) return;
      _resBarLastDom = now;
      _resBarForce = false;
      for (var i = 0; i < basics.length; i++) {
        var item = basics[i];
        if (!item || !item.identifier) continue;
        var id = item.identifier;
        var n = _resBarMem[id];
        if (n == null) n = getStock(id);
        var s = formatAmount(n);
                if (_resBarDom[id] === s) continue;
        var amt = _resBarAmtEl[id];
        if (!amt) {
          var chip = bar.querySelector('.res-chip[data-id="' + id.replace(/"/g, '\\"') + '"]');
          if (chip) {
            amt = chip.querySelector('.amt');
            if (amt) _resBarAmtEl[id] = amt;
          }
        }
        if (amt) amt.textContent = s;
        _resBarDom[id] = s;
      }
      _resBarDirty = false;
    }

    function _resBarPump() {
      _resBarRaf = null;
      // sample stocks into memory every animation frame when dirty
      var basics = _resBarBasics();
      var significant = false;
      for (var i = 0; i < basics.length; i++) {
        var item = basics[i];
        if (!item || !item.identifier) continue;
        var id = item.identifier;
        var n = getStock(id);
        var prev = _resBarMem[id];
        _resBarMem[id] = n;
        if (prev == null) significant = true;
        else {
          var base = Math.max(1, Math.abs(prev));
          if (Math.abs(n - prev) / base >= RES_BAR_MIN_DELTA) significant = true;
        }
      }
      _resBarWriteDom(significant || _resBarForce);
      if (_resBarDirty) {
        _resBarRaf = requestAnimationFrame(_resBarPump);
      }
    }

    function renderResBar() {
      _resBarDirty = true;
      // first build or language/structure change: force full structure
      if (!_resBarBuilt) _resBarForce = true;
      if (_resBarRaf == null) {
        _resBarRaf = requestAnimationFrame(_resBarPump);
      }
    }

    /** Force immediate DOM sync (menus / one-shot events) */
    function renderResBarNow() {
      _resBarForce = true;
      _resBarDirty = true;
      _resBarWriteDom(true);
    }

    function ensureGameClock(w) {
      if (!w.game) w.game = {};
      if (!w.game.startedAt) w.game.startedAt = w.createdAt || Date.now();
    }
    ensureGameClock(world);

    function snapshotOccupation(w) {
      if (!w || !w.game) return;
      try {
        if (typeof engine !== 'undefined' && engine && engine.exportOccupation) {
          w.game.regionOwners = engine.exportOccupation();
        }
      } catch (_) {}
    }
    function persistWorld(w) {
      if (!w || !w.id) return;
      snapshotOccupation(w);
      const list = loadWorlds();
      const idx = list.findIndex(x => x.id === w.id);
      w.updatedAt = Date.now();
      if (idx >= 0) list[idx] = w;
      else list.push(w);
      saveWorlds(list);
    }
    function reapplyContestBorders(silentOnly) {
      if (!engine || !window.WOK_Military) return;
      try {
        const battles = WOK_Military.activeBattles(world) || [];
        const keys = [];
        for (let i = 0; i < battles.length; i++) {
          const b = battles[i];
          if (b && (b.status === 'fighting' || b.status === 'holding') && b.region != null) {
            keys.push(String(b.region));
          }
        }
        // Drop red borders for finished battles; keep only active
        if (engine.syncContestBorders) {
          engine.syncContestBorders(keys, '#ff2020', 1.6);
        } else {
          for (let i = 0; i < keys.length; i++) {
            try { engine.setRegionBorder(keys[i], '#ff2020', 2.2, true); } catch (_) {}
          }
        }
        window._wokRedRegions = {};
        for (let i = 0; i < keys.length; i++) window._wokRedRegions[keys[i]] = true;
        if (!silentOnly && engine.setDirty) engine.setDirty();
      } catch (_) {}
    }
    function lootDefenderBuildings(defender, regionKey) {
      if (!world || !world.game || !defender || defender === playerCountry) return;
      if (!world.game.botBuildings) world.game.botBuildings = {};
      const bag = world.game.botBuildings[defender];
      if (!bag) return;
      if (!world.game.buildings) world.game.buildings = {};
      const pct = 0.1;
      Object.keys(bag).forEach(function (bid) {
        const have = Math.floor(Number(bag[bid]) || 0);
        if (have <= 0) return;
        const take = Math.max(1, Math.floor(have * pct));
        bag[bid] = Math.max(0, have - take);
        world.game.buildings[bid] = (Math.floor(Number(world.game.buildings[bid]) || 0)) + take;
      });
    }
    function checkWorldVictory() {
      if (!world || !playerCountry || !engine || !engine.isWorldOwnedBy) return;
      if (world.victory) return;
      if (!engine.isWorldOwnedBy(playerCountry)) return;
      world.victory = true;
      world.victoryAt = Date.now();
      persistWorld(world);
      if (typeof showVictoryOverlay === 'function') showVictoryOverlay();
    }
    function showVictoryOverlay() {
      let ov = document.getElementById('victory-overlay');
      if (!ov) {
        ov = document.createElement('div');
        ov.id = 'victory-overlay';
        ov.innerHTML = '<div class="victory-card">' +
          '<div class="victory-title" id="victory-title">Victory</div>' +
          '<div class="victory-sub" id="victory-sub"></div>' +
          '<button type="button" class="menu-btn ok" id="btn-victory-ok">OK</button></div>';
        document.body.appendChild(ov);
        document.getElementById('btn-victory-ok').addEventListener('click', function () {
          ov.classList.remove('open');
        });
      }
      document.getElementById('victory-title').textContent =
        tKey("world_conquered_2", "World Conquered!");
      document.getElementById('victory-sub').textContent =
        isEnUi()
          ? ('All regions under ' + (playerCountry || '') + '.')
          : ('كل الأقاليم تحت سيطرة ' + (playerCountry || '') + '.');
      ov.classList.add('open');
    }


    function tx(key, fallback) {
      if (window.WOK_I18N && WOK_I18N.t) {
        WOK_I18N.setLang(settings.lang);
        const v = WOK_I18N.t(key, fallback);
        if (v != null && v !== '' && v !== key) return v;
        if (fallback != null && fallback !== '') return fallback;
        return v;
      }
      const bag = (bagLang());
      const v = bag[key];
      if (v != null && v !== '') return v;
      return fallback != null ? fallback : '';
    }
    function setTxt(id, key, fallback) {
      const el = typeof id === 'string' ? document.getElementById(id) : id;
      if (!el) return;
      const v = tx(key, fallback);
      if (v != null && v !== '') el.textContent = v;
    }
    function applyI18n() {
      if (window.WOK_I18N && WOK_I18N.setLang) WOK_I18N.setLang(settings.lang);
      t = (window.WOK_I18N && WOK_I18N.bundle)
        ? WOK_I18N.bundle(settings.lang)
        : (bagLang());
      document.documentElement.lang = settings.lang;
      document.documentElement.dir = (window.WOK_I18N && WOK_I18N.isRtl) ? (WOK_I18N.isRtl(settings.lang) ? 'rtl' : 'ltr') : (settings.lang === 'ar' ? 'rtl' : 'ltr');
      setTxt('btn-menu', 'menu', 'القائمة');
      setTxt('btn-resume', 'resume', 'متابعة');
      setTxt('btn-game-settings', 'settings', 'الإعدادات');
      setTxt('btn-save-quit', 'save_quit', 'حفظ وخروج');
      setTxt('lbl-eco', 'eco', '');
      setTxt('lbl-regions', 'regions', '');
      setTxt('lbl-coastal', 'coastal', '');
      setTxt('lbl-neighbors', 'neighbors', '');
      setTxt('load-text', 'loading', '');
      setTxt('fx-title', 'fx_title', '');
      setTxt('fx-sub', 'fx_sub', '');
      setTxt('trade-title', 'trade', '');
      setTxt('tab-buy', 'buy', 'شراء');
      setTxt('tab-sell', 'sell', 'بيع');
      setTxt('lbl-trade-item', 'item', '');
      setTxt('lbl-trade-qty', 'amount', '');
      setTxt('btn-trade-confirm', 'confirm', 'تأكيد');
      document.querySelectorAll('[data-i18n]').forEach(function (el) {
        const k = el.getAttribute('data-i18n');
        if (!k) return;
        const prev = el.textContent;
        const v = tx(k, prev);
        if (v != null && v !== '' && v !== k) el.textContent = v;
      });
      const selO = document.getElementById('sel-orient');
      if (selO && selO.options && selO.options.length >= 2) {
        const p = tx('portrait', selO.options[0].textContent);
        const l = tx('landscape', selO.options[1].textContent);
        if (p) selO.options[0].textContent = p;
        if (l) selO.options[1].textContent = l;
      }
      const btnO = document.getElementById('btn-orient');
      if (btnO) {
        if (!btnO.classList.contains('active')) setTxt(btnO, 'orient', btnO.textContent);
        else setTxt(btnO, 'orientAlt', btnO.textContent);
      }
      // version label
      const ver = document.getElementById('wok-version-label');
      if (ver && window.WOK_VERSION) ver.textContent = window.WOK_VERSION;
    }
    applyI18n();

    if (world) {
      document.getElementById('pause-world-name').textContent = world.name || '—';
    } else {
      document.getElementById('load-text').textContent = t.missing;
    }

    // ── Map ──
    const canvas = document.getElementById('map-canvas');
    const loadOverlay = document.getElementById('load-overlay');
    const loadFill = document.getElementById('load-fill');
    const layerPause = document.getElementById('layer-pause');
    const layerSettings = document.getElementById('layer-settings');
    const infoDim = document.getElementById('info-dim');
    const countryInfo = document.getElementById('country-info');
    const btnOrient = document.getElementById('btn-orient');

    let paused = false;
    let orientLocked = false;
    let playerCountry = world && world.game ? world.game.playerCountry : (world && world.country);

    let armyMode = null; // null | 'enlist_pick' | 'move'
    let longPressRegion = null;
    let longPressOwner = null;
    let dragMoveActive = false;

    function regionKeyFromHit(hit) {
      if (!hit || !hit.region) return null;
      const r = hit.region;
      if (typeof r === 'string' || typeof r === 'number') return String(r);
      if (r.key != null) return String(r.key);
      if (r.id != null) return String(r.id);
      return null;
    }

    // Persistent red alerts (after top banner hides)
    if (!window._wokAlerts) window._wokAlerts = [];
    function pushAlert(title, body, meta) {
      const item = {
        id: 'a_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
        title: title || '',
        body: body || '',
        meta: meta || {},
        at: Date.now()
      };
      window._wokAlerts.unshift(item);
      if (window._wokAlerts.length > 80) window._wokAlerts.length = 80;
      updateAlertsBadge();
      return item;
    }
    function updateAlertsBadge() {
      const b = document.getElementById('alerts-badge');
      if (!b) return;
      const n = (window._wokAlerts || []).length;
      b.textContent = String(n);
      b.classList.toggle('show', n > 0);
    }
    function renderAlertsList() {
      const box = document.getElementById('alerts-list');
      if (!box) return;
      const lang = (window.WOK_I18N && WOK_I18N.normalizeLang) ? WOK_I18N.normalizeLang(settings.lang) : (settings.lang || 'ar');
      const tt = I18N[lang] || I18N.ar;
      const titleEl = document.getElementById('alerts-title');
      if (titleEl) titleEl.textContent = tt.alerts || (lang === 'en' ? 'Alerts' : 'التنبيهات');
      const btnClear = document.getElementById('btn-alerts-clear');
      if (btnClear) btnClear.title = tt.clear_all || (lang === 'en' ? 'Delete all' : 'حذف الكل');
      const list = window._wokAlerts || [];
      if (!list.length) {
        box.innerHTML = '<div style="color:#7aa8d4;font-size:13px;padding:8px;">' +
          (tt.no_alerts || (lang === 'en' ? 'No alerts' : 'لا تنبيهات')) + '</div>';
        return;
      }
      box.innerHTML = '';
      list.forEach(function (it) {
        const div = document.createElement('div');
        div.className = 'alert-item';
        div.innerHTML = '<button type="button" class="x" data-id="' + it.id + '">×</button>' +
          '<div class="t"></div><div class="b"></div>';
        div.querySelector('.t').textContent = it.title;
        div.querySelector('.b').textContent = it.body;
        div.querySelector('.x').addEventListener('click', function () {
          window._wokAlerts = (window._wokAlerts || []).filter(function (x) { return x.id !== it.id; });
          updateAlertsBadge();
          renderAlertsList();
        });
        box.appendChild(div);
      });
    }
    function showMapHint(msg, asAlert) {
      const title = msg && msg.length > 48 ? msg.slice(0, 48) + '…' : (msg || '');
      const body = msg || '';
      // Always keep in alerts list when requested
      if (msg && asAlert !== false) {
        try { pushAlert(title, body, { kind: 'hint' }); } catch (_) {}
      }
      // Mute: no red top banner — only alerts panel
      if (settings && settings.muteMapBanners) {
        const el = document.getElementById('map-hint-bar');
        if (el) el.classList.remove('show');
        layoutTopBars();
        return;
      }
      const el = document.getElementById('map-hint-bar');
      const tx = document.getElementById('map-hint-text');
      if (!el) return;
      if (tx) tx.textContent = msg || '';
      else el.textContent = msg || '';
      el.classList.toggle('show', !!msg);
      if (window._wokHintTimer) clearTimeout(window._wokHintTimer);
      if (msg) {
        window._wokHintTimer = setTimeout(function () {
          el.classList.remove('show');
          layoutTopBars();
        }, 5000);
      }
      layoutTopBars();
    }
    
    (function wireHintX() {
      const btn = document.getElementById('map-hint-x');
      if (!btn) return;
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        const el = document.getElementById('map-hint-bar');
        const tx = document.getElementById('map-hint-text');
        const msg = tx ? tx.textContent : '';
        if (el) el.classList.remove('show');
        if (window._wokHintTimer) clearTimeout(window._wokHintTimer);
        if (msg) pushAlert(msg.length > 48 ? msg.slice(0, 48) + '…' : msg, msg, { kind: 'hint' });
        layoutTopBars();
      });
    })();
    function layoutTopBars() {
      const hint = document.getElementById('map-hint-bar');
      const battle = document.getElementById('battle-bar');
      if (!hint || !battle) return;
      if (battle.classList.contains('show')) {
        hint.style.top = 'auto';
        // push black hint below red battle bar
        const h = battle.offsetHeight || 36;
        hint.style.marginTop = (h + 4) + 'px';
      } else {
        hint.style.marginTop = '';
      }
    }

    const engine = new MapEngine(canvas, {
      tapMaxMove: 28,
      longPressMs: 480,
      longPressSlop: 56,
      onTap: function (hit) {
        if (!hit) return;
        // Tap troop line → show units + recall
        try {
          if (engine.hitMilitaryMove && hit.sx != null) {
            const mv = engine.hitMilitaryMove(hit.sx, hit.sy, 30);
            if (mv && mv.player !== false) {
              openMoveInfoSheet(mv);
              return;
            }
          }
        } catch (_) {}
        if (armyMode === 'enlist_pick') {
          if (!hit.region) {
            showMapHint(tKey("long_press_a_region", "Long-press a region"));
          }
          return;
        }
        if (hit.country) openCountryInfoFor(hit.country);
      },
      onLongPress: function (hit) {
        if (!hit || !hit.region) return;
        const rk = regionKeyFromHit(hit);
        if (!rk) return;
        const owner = engine.getRegionOwner ? engine.getRegionOwner(rk) : null;
        if (armyMode === 'enlist_pick') {
          if (owner !== playerCountry) {
            showMapHint(tKey("not_your_region_2", "Not your region"));
            return;
          }
          if (window.WOK_Military) {
            const res = WOK_Military.startTrainFromPackage(world, rk, getStock, setStock);
            const ok = res && (res.ok === true || res === true);
            if (ok) {
              showMapHint(tKey("training_started_2", "Training started"));
              armyMode = null;
              showHud(true);
              persistWorld(world);
              tickEconomy();
              try { openArmyPanel(); } catch (_) {}
            } else {
              armyMode = null;
              showHud(true);
              try { openArmyPanel(); } catch (_) {}
              const reason = res && res.reason;
              if (reason === 'no_funds') {
                showArmyFundsToast(isEnUi()
                  ? 'You cannot afford this package'
                  : 'لا تملك السعر');
              } else {
                showMapHint(tKey("cannot_train_here", "Cannot train here"));
              }
            }
          }
          return;
        }
        longPressRegion = rk;
        longPressOwner = owner;
        showMapHint(isEnUi()
          ? 'Hold & drag to move, or release for info'
          : 'اسحب للنقل أو أفلت للمعلومات');
      },
      onLongPressEnd: function (info) {
        const from = longPressRegion;
        const owner = longPressOwner;
        longPressRegion = null;
        longPressOwner = null;
        if (!from) return;
        const to = regionKeyFromHit(info && info.endHit);
        if (info && info.moved && to && to !== from) {
          if (owner !== playerCountry) {
            showMapHint(tKey("can_only_move_from_your_regions", "Can only move from your regions"));
            return;
          }
          const destOwner = engine.getRegionOwner ? engine.getRegionOwner(to) : null;
          if (destOwner && destOwner !== playerCountry) {
            openIntentSheet(from, to, destOwner);
          } else {
            openMoveRatioSheet(from, to);
          }
          return;
        }
        // Holding/contest: show who occupies and remaining days on black bar
        try {
          if (window.WOK_Military) {
            const battles = WOK_Military.activeBattles(world) || [];
            for (let bi = 0; bi < battles.length; bi++) {
              const b = battles[bi];
              if (!b || String(b.region) !== String(from)) continue;
              if (b.status === 'holding' || b.status === 'fighting') {
                const dayMs = WOK_Military.MS_PER_GAME_DAY || 10000;
                const left = b.status === 'holding'
                  ? Math.max(0, Math.ceil(((b.holdUntil || Date.now()) - Date.now()) / dayMs))
                  : Math.max(0, 3 - (b.pulseCount || 0));
                const rName = (engine.regionByKey && engine.regionByKey.get(String(from)) || {}).name || from;
                if (b.status === 'holding') {
                  showMapHint(
                    (isEnUi()
                      ? (rName + ' contested by ' + (b.attacker || '?') + ' · annex in ~' + left + ' days')
                      : (rName + ' تحت احتلال ' + (b.attacker || '?') + ' · الضم خلال ~' + left + ' يوم')),
                    true
                  );
                  return;
                }
                showMapHint(
                  (isEnUi()
                    ? (rName + ' battle · waves left ~' + left)
                    : (rName + ' معركة · جولات متبقية ~' + left)),
                  true
                );
                return;
              }
            }
          }
        } catch (_) {}
        if (owner === playerCountry) openRegionArmySheet(from);
        else openEnemyCountryInfo(owner, from);
      }
    });

    engine.onStats = function (s) {
      if (!settings || !settings.showMapStats) return;
      const f = document.getElementById('date-fps');
      const z = document.getElementById('date-zoom');
      if (f) f.textContent = 'FPS: ' + (s && s.fps != null ? Math.round(s.fps) : '—');
      if (z) {
        const zv = (s && s.zoom != null) ? Number(s.zoom).toFixed(2) : '—';
        // LOD tier is computed from zoom every frame in map-engine._collect
        const lod = (s && s.tier != null) ? s.tier : '—';
        z.textContent = 'ZOOM: ' + zv + ' / LOD ' + lod;
      }
    };
    if (engine.setPanSensitivity) engine.setPanSensitivity(settings.panSensitivity != null ? settings.panSensitivity : settings.sensitivity);
    if (engine.setZoomSensitivity) engine.setZoomSensitivity(settings.zoomSensitivity != null ? settings.zoomSensitivity : settings.sensitivity);

    function showHud(on) {
      document.getElementById('top-bar').style.display = on ? '' : 'none';
      document.getElementById('btn-res-fab').style.display = on ? '' : 'none';
      document.getElementById('btn-fx-fab').style.display = on ? '' : 'none';
      document.getElementById('btn-builds-fab').style.display = on ? '' : 'none';
      const nf = document.getElementById('btn-news-fab');
      if (nf) nf.style.display = on ? '' : 'none';
      document.getElementById('btn-army-fab').style.display = on ? '' : 'none';
      document.getElementById('date-bar').style.display = on ? '' : 'none';
    }

    let moveFrom = null, moveTo = null;

    function openRegionArmySheet(rk) {
      if (!window.WOK_Military) return;
      const sum = WOK_Military.armySummary(world, rk);
      const sheet = document.getElementById('region-army-sheet');
      const list = document.getElementById('region-army-list');
      let rTitle = tKey("region_army_2", "Region army");
      try {
        const r = engine && engine.regionByKey && engine.regionByKey.get(String(rk));
        if (r) {
          const nm = (typeof regionDisplayName === 'function') ? regionDisplayName(r) : (r.displayName || r.name);
          if (nm) rTitle = nm;
        }
      } catch (_) {}
      document.getElementById('region-army-title').textContent = rTitle;
      document.getElementById('region-army-meta').textContent =
        (tKey("soldiers_2", "Soldiers ")) + sum.soldiers +
        ' · ' + (tKey("power", "Power ")) + Math.round(sum.totalPower) +
        (sum.barracks ? (' · ' + (tKey("barracks", "Barracks ")) + sum.barracks) : '');
      list.innerHTML = '';
      if (!sum.rows.length) {
        list.innerHTML = '<div class="sheet-meta">' +
          (tKey("no_units_2", "No units")) + '</div>';
      } else {
        sum.rows.forEach(function (row) {
          const div = document.createElement('div');
          div.className = 'ratio-row';
          const img = document.createElement('img');
          img.src = row.icon;
          const nm = document.createElement('div');
          nm.className = 'rn';
          nm.textContent = row.name[settings.lang] || row.name.en || row.id;
          const meta = document.createElement('div');
          meta.style.cssText = 'font-size:12px;font-weight:700;color:#9fd0ff;';
          meta.textContent = row.count + ' (' + row.active + ' ' +
            (tKey("active_2", "active")) + ')';
          div.appendChild(img);
          div.appendChild(nm);
          div.appendChild(meta);
          list.appendChild(div);
        });
      }
      forcePanelOpen(sheet, true, 120);
      if (infoDim) {
        infoDim.classList.add('open');
        infoDim.style.display = 'block';
        infoDim.style.visibility = 'visible';
        infoDim.style.pointerEvents = 'auto';
        infoDim.style.zIndex = '100';
      }
    }
    function openEnemyCountryInfo(owner, rk) {
      if (!owner) return;
      ensureRelations();
      const res = engine.getCountryResources ? engine.getCountryResources(owner) : null;
      let armyNote = '';
      try {
        if (window.WOK_Military) {
          const sum = WOK_Military.armySummary ? WOK_Military.armySummary(world, rk) : null;
          if (sum && sum.totalPower) {
            armyNote = isEnUi()
              ? (' · Enemy power ~' + Math.round(sum.totalPower))
              : (' · قوة العدو ~' + Math.round(sum.totalPower));
          }
        }
      } catch (_) {}
      const rel = getRelation(owner);
      const emb = world.game.embassies[owner];
      const msg = (tKey("country", "Country: ")) + owner +
        (res ? (' · G' + res.gold + ' I' + res.iron + ' O' + res.oil) : '') +
        armyNote +
        (tKey("relations_2", " · Relations ")) + Math.round(rel) + '%';
      showMapHint(msg, true);
      // Relation strip + embassy on info dim if present
      let bar = document.getElementById('relation-float');
      if (!bar) {
        bar = document.createElement('div');
        bar.id = 'relation-float';
        bar.style.cssText = 'position:absolute;top:100px;left:12px;right:12px;z-index:30;background:rgba(0,0,0,.55);border:1px solid rgba(90,170,255,.4);border-radius:12px;padding:10px;backdrop-filter:blur(10px);';
        const root = document.getElementById('game-container') || document.body;
        root.appendChild(bar);
      }
      const col = relationColor(rel);
      bar.innerHTML = '';
      const title = document.createElement('div');
      title.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;';
      title.innerHTML = '<span style="color:#9fd0ff;font-weight:700;"></span><button type="button" style="border:none;background:rgba(255,255,255,.1);color:#fff;border-radius:8px;width:28px;height:28px;">×</button>';
      title.querySelector('span').textContent = owner;
      title.querySelector('button').onclick = function () { bar.style.display = 'none'; };
      bar.appendChild(title);
      const track = document.createElement('div');
      track.style.cssText = 'height:10px;border-radius:99px;background:rgba(255,255,255,.12);overflow:hidden;';
      const fill = document.createElement('div');
      fill.style.cssText = 'height:100%;width:' + rel + '%;background:' + col + ';transition:width .3s;';
      track.appendChild(fill);
      bar.appendChild(track);
      const pct = document.createElement('div');
      pct.style.cssText = 'font-size:12px;margin-top:4px;color:' + col + ';';
      pct.textContent = (tKey("relations_3", "Relations: ")) + Math.round(rel) + '%';
      bar.appendChild(pct);
      if (rel >= 70) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'menu-btn ok';
        btn.style.cssText = 'width:100%;margin-top:8px;';
        if (emb && emb.built) {
          btn.textContent = tKey("embassy_options_2", "Embassy options");
          btn.onclick = function () { openEmbassyPanel(owner); };
        } else {
          btn.textContent = isEnUi()
            ? 'Build embassy (10k gold, 20k iron, 1k oil)'
            : 'بناء سفارة (10 آلاف ذهب، 20 آلاف حديد، ألف نفط)';
          btn.onclick = function () {
            if (getStock('WOK:ECONOMY.MATERIAL.GOLD.BAR') < 10000 ||
                getStock('WOK:ECONOMY.MATERIAL.IRON.INGOT') < 20000 ||
                getStock('WOK:ECONOMY.MATERIAL.OIL.BARREL') < 1000) {
              showMapHint(tKey("not_enough_resources_2", "Not enough resources"));
              return;
            }
            setStock('WOK:ECONOMY.MATERIAL.GOLD.BAR', getStock('WOK:ECONOMY.MATERIAL.GOLD.BAR') - 10000);
            setStock('WOK:ECONOMY.MATERIAL.IRON.INGOT', getStock('WOK:ECONOMY.MATERIAL.IRON.INGOT') - 20000);
            setStock('WOK:ECONOMY.MATERIAL.OIL.BARREL', getStock('WOK:ECONOMY.MATERIAL.OIL.BARREL') - 1000);
            world.game.embassies[owner] = { built: true, builtAt: Date.now() };
            addRelation(owner, 5);
            persistWorld(world);
            renderResBar();
            showMapHint(tKey("embassy_built_2", "Embassy built"));
            openEnemyCountryInfo(owner, rk);
          };
        }
        bar.appendChild(btn);
      }
      bar.style.display = 'block';
      bar._owner = owner;
    }
    function openEmbassyPanel(owner) {
      const lang = (window.WOK_I18N && WOK_I18N.normalizeLang) ? WOK_I18N.normalizeLang(settings.lang) : (settings.lang || 'ar');
      const choice = window.confirm(lang === 'en'
        ? 'Embassy with ' + owner + '\nOK = Request aid\nCancel = Defensive alliance'
        : 'سفارة مع ' + owner + '\nموافق = طلب مساعدات\nإلغاء = تحالف دفاعي');
      if (choice) {
        // Request aid from bot
        const rel = getRelation(owner);
        const accept = Math.random() < (0.25 + rel / 200);
        if (accept) {
          const gold = Math.floor(80 + rel * 2);
          setStock('WOK:ECONOMY.MATERIAL.GOLD.BAR', getStock('WOK:ECONOMY.MATERIAL.GOLD.BAR') + gold);
          addRelation(owner, 3);
          showMapHint((lang === 'en' ? 'Aid received: ' : 'وصلت مساعدات: ') + gold + (lang === 'en' ? ' gold' : ' ذهب'));
        } else {
          addRelation(owner, -10);
          showMapHint(lang === 'en' ? 'Aid refused (−10% relations)' : 'رُفضت المساعدات (−10% علاقة)');
        }
        persistWorld(world);
        renderResBar();
      } else {
        // Alliance
        const rel = getRelation(owner);
        const accept = Math.random() < (0.08 + rel / 500);
        if (accept) {
          ensureRelations();
          world.game.alliances.push([playerCountry, owner]);
          addRelation(owner, 8);
          showMapHint(lang === 'en' ? 'Defensive alliance formed' : 'تم التحالف الدفاعي');
        } else {
          addRelation(owner, -5);
          showMapHint(lang === 'en' ? 'Alliance refused' : 'رُفض التحالف');
        }
        persistWorld(world);
      }
    }

    function ensureRelations() {
      if (!world.game) world.game = {};
      if (!world.game.relations) world.game.relations = {};
      if (!world.game.embassies) world.game.embassies = {};
      if (!world.game.alliances) world.game.alliances = [];
    }
    function getRelation(country) {
      ensureRelations();
      if (country == null || country === playerCountry) return 100;
      if (world.game.relations[country] == null) world.game.relations[country] = 50;
      return Math.max(0, Math.min(100, Number(world.game.relations[country]) || 50));
    }
    function setRelation(country, v) {
      ensureRelations();
      world.game.relations[country] = Math.max(0, Math.min(100, v));
    }
    function addRelation(country, delta) {
      setRelation(country, getRelation(country) + delta);
    }
    function relationColor(pct) {
      // 0 red → 50 yellow → 100 green
      const t = Math.max(0, Math.min(1, pct / 100));
      const r = Math.round(220 * (1 - t) + 40 * t);
      const g = Math.round(50 * (1 - t) + 190 * t);
      const b = Math.round(60 * (1 - t) + 90 * t);
      return 'rgb(' + r + ',' + g + ',' + b + ')';
    }
    function collectMoveRatios() {
      // Progress bars → whole-number troop counts
      const ratios = {};
      document.querySelectorAll('#move-ratios input[type=range][data-unit]').forEach(function (rng) {
        const id = rng.dataset.unit;
        const max = Math.max(0, Math.floor(Number(rng.dataset.max) || 0));
        const pct = Math.max(0, Math.min(100, Number(rng.value) || 0));
        const n = Math.floor(max * pct / 100);
        if (n > 0) ratios[id] = n;
      });
      return ratios;
    }
    function refreshMoveOilEstimate() {
      if (!moveFrom || !moveTo || !window.WOK_Military) return;
      const moving = collectMoveRatios();
      const land = WOK_Military.regionsLandLinked(engine, moveFrom, moveTo);
      const sea = WOK_Military.regionsSeaLinked(engine, moveFrom, moveTo);
      const oil = WOK_Military.estimateOil(engine, moveFrom, moveTo, moving, sea && !land);
      document.getElementById('move-oil').textContent =
        (tKey("oil_cost", "Oil cost: ")) + oil;
    }






    let intentFrom = null, intentTo = null, intentOwner = null;
    function openIntentSheet(from, to, owner) {
      intentFrom = from; intentTo = to; intentOwner = owner;
      const sheet = document.getElementById('intent-sheet');
      if (!sheet) { openMoveRatioSheet(from, to); return; }
      const lang = (window.WOK_I18N && WOK_I18N.normalizeLang) ? WOK_I18N.normalizeLang(settings.lang) : (settings.lang || 'ar');
      document.getElementById('intent-title').textContent = lang === 'en' ? 'Choose action' : 'اختر العملية';
      const fn = (engine.regionByKey && engine.regionByKey.get(String(from)) || {}).name || from;
      const tn = (engine.regionByKey && engine.regionByKey.get(String(to)) || {}).name || to;
      document.getElementById('intent-meta').textContent =
        (lang === 'en' ? 'From ' : 'من ') + fn + (lang === 'en' ? ' to ' : ' إلى ') + tn +
        ' (' + owner + ') · ' + (lang === 'en' ? 'Relations ' : 'العلاقة ') + Math.round(getRelation(owner)) + '%';
      document.getElementById('btn-intent-attack').textContent = lang === 'en' ? 'Move army / Attack' : 'نقل جيش / هجوم';
      document.getElementById('btn-intent-aid').textContent = lang === 'en' ? 'Send aid' : 'نقل مساعدات';
      sheet.style.display = 'flex';
      sheet.style.zIndex = '60';
      sheet.style.pointerEvents = 'auto';
      sheet.classList.add('open');
    }
    function openAidSheet(from, to, owner) {
      const sheet = document.getElementById('aid-sheet');
      if (!sheet) return;
      const sel = document.getElementById('sel-aid-item');
      const rng = document.getElementById('rng-aid');
      const val = document.getElementById('aid-qty-val');
      const ids = [
        'WOK:ECONOMY.MATERIAL.GOLD.BAR',
        'WOK:ECONOMY.MATERIAL.IRON.INGOT',
        'WOK:ECONOMY.MATERIAL.OIL.BARREL'
      ];
      const names = isEnUi()
        ? { [ids[0]]: 'Gold', [ids[1]]: 'Iron', [ids[2]]: 'Oil' }
        : { [ids[0]]: 'ذهب', [ids[1]]: 'حديد', [ids[2]]: 'نفط' };
      sel.innerHTML = '';
      ids.forEach(function (id) {
        const o = document.createElement('option');
        o.value = id;
        o.textContent = names[id] || id;
        sel.appendChild(o);
      });
      function sync() {
        const id = sel.value;
        const have = Math.floor(getStock(id) || 0);
        rng.max = String(Math.max(1, have));
        rng.value = String(Math.min(Number(rng.value) || 1, have));
        val.textContent = rng.value + ' / ' + have;
      }
      sel.onchange = sync;
      rng.oninput = sync;
      sync();
      sheet.dataset.from = from;
      sheet.dataset.to = to;
      sheet.dataset.owner = owner;
      sheet.style.display = 'flex';
      sheet.classList.add('open');
    }

    let selectedMoveId = null;
    function unitDisplayName(id) {
      if (id === 'soldiers') return tKey("soldiers_3", "Soldiers");
      try {
        const u = window.WOK && WOK.getUnit ? WOK.getUnit(id) : null;
        if (u) {
          if (u.name) {
            if (typeof u.name === 'string') return u.name;
            return u.name[settings.lang] || u.name.ar || u.name.en || id;
          }
          if (u.label) return u.label;
        }
        if (window.WOK_UNITS && WOK_UNITS[id]) {
          const n = WOK_UNITS[id].name;
          if (n) return (typeof n === 'string') ? n : (n[settings.lang] || n.ar || n.en || id);
        }
      } catch (_) {}
      // last resort: humanize identifier tail
      const parts = String(id).split('.');
      return parts[parts.length - 1] || id;
    }
    function hideMoveInfoSheet() {
      const sheet = document.getElementById('move-info-sheet');
      if (!sheet) return;
      sheet.classList.remove('open');
      sheet.style.display = 'none';
    }
    function wireMoveInfoSheet() {
      const sheet = document.getElementById('move-info-sheet');
      if (!sheet) return;
      // Always rebind — avoids dead handlers after DOM/style changes
      const close = document.getElementById('btn-move-info-close');
      const recall = document.getElementById('btn-move-recall');
      const card = document.getElementById('move-info-card');
      if (close) {
        close.onclick = function (e) {
          if (e) { e.preventDefault(); e.stopPropagation(); }
          hideMoveInfoSheet();
        };
      }
      if (sheet) {
        sheet.onclick = function (e) {
          if (e.target === sheet) hideMoveInfoSheet();
        };
      }
      if (card) {
        card.onclick = function (e) { e.stopPropagation(); };
      }
      if (recall) {
        recall.onclick = function (e) {
          if (e) { e.preventDefault(); e.stopPropagation(); }
          const id = window._wokSelectedMoveId || selectedMoveId;
          if (!id || !window.WOK_Military) {
            showMapHint(tKey("cannot_recall_2", "Cannot recall"), false);
            return;
          }
          const ok = WOK_Military.recallMove(world, id);
          if (ok) {
            showMapHint(tKey("forces_turning_back_2", "Forces turning back"), false);
            if (engine.setMilitaryMoves) engine.setMilitaryMoves(WOK_Military.activeMoves(world));
            try { persistWorld(world); } catch (_) {}
            hideMoveInfoSheet();
          } else {
            showMapHint(tKey("cannot_recall_2", "Cannot recall"), false);
          }
        };
      }
    }
    function openMoveInfoSheet(mv) {
      if (!mv) return;
      selectedMoveId = mv.id;
      window._wokSelectedMoveId = mv.id;
      wireMoveInfoSheet();
      const sheet = document.getElementById('move-info-sheet');
      if (!sheet) return;
      sheet.style.display = 'flex';
      sheet.classList.add('open');
      const title = document.getElementById('move-info-title');
      const body = document.getElementById('move-info-body');
      const recallBtn = document.getElementById('btn-move-recall');
      const lang = (window.WOK_I18N && WOK_I18N.normalizeLang) ? WOK_I18N.normalizeLang(settings.lang) : (settings.lang || 'ar');
      if (title) title.textContent = lang === 'en' ? 'Forces en route' : 'القوات في الطريق';
      const units = mv.units || {};
      const lines = [];
      Object.keys(units).forEach(function (id) {
        const n = units[id];
        if (!n) return;
        lines.push(unitDisplayName(id) + ': ' + n);
      });
      const fromN = (engine.regionByKey && engine.regionByKey.get(String(mv.from)) || {}).name || mv.from;
      const toN = (engine.regionByKey && engine.regionByKey.get(String(mv.to)) || {}).name || mv.to;
      if (body) {
        body.innerHTML = '';
        const meta = document.createElement('div');
        meta.style.marginBottom = '8px';
        meta.style.color = '#9fd0ff';
        meta.textContent = (lang === 'en' ? 'Route: ' : 'المسار: ') + fromN + ' → ' + toN +
          (mv.recalling ? (lang === 'en' ? ' (recalling)' : ' (عودة)') : '');
        body.appendChild(meta);
        lines.forEach(function (t) {
          const d = document.createElement('div');
          d.textContent = t;
          body.appendChild(d);
        });
        if (!lines.length) {
          const d = document.createElement('div');
          d.textContent = lang === 'en' ? 'No unit data' : 'لا بيانات وحدات';
          body.appendChild(d);
        }
      }
      if (recallBtn) {
        recallBtn.style.display = (mv.player !== false && !mv.recalling) ? '' : 'none';
        recallBtn.textContent = lang === 'en' ? 'Recall forces' : 'إعادة / تراجع';
      }
    }

    function closeMoveSheet() {
      try {
        forcePanelOpen(document.getElementById('move-sheet'), false);
        const armyOpen = document.getElementById('army-panel') && document.getElementById('army-panel').classList.contains('open');
        const regOpen = document.getElementById('region-army-sheet') && document.getElementById('region-army-sheet').classList.contains('open');
        const newsOpen = document.getElementById('news-panel') && document.getElementById('news-panel').classList.contains('open');
        if (!armyOpen && !regOpen && !newsOpen && typeof infoDim !== 'undefined' && infoDim) {
          infoDim.classList.remove('open');
          infoDim.style.display = '';
          infoDim.style.visibility = '';
          infoDim.style.pointerEvents = '';
          infoDim.style.zIndex = '';
        }
      } catch (_) {}
    }
    function openMoveRatioSheet(from, to) {
      // Show sheet immediately so UI never freezes on heavy checks
      try {
        forcePanelOpen(document.getElementById('move-sheet'), true, 120);
        if (typeof infoDim !== 'undefined' && infoDim) {
          infoDim.classList.add('open');
          infoDim.style.display = 'block';
          infoDim.style.visibility = 'visible';
          infoDim.style.pointerEvents = 'auto';
          infoDim.style.zIndex = '100';
        }
      } catch (_) {}

      if (!window.WOK_Military) return;
      const g = WOK_Military.ensure(world);
      const army = g.regionArmies[from] || {};
      const soldiers = g.regionSoldiers[from] || 0;
      const ids = Object.keys(army).filter(function (id) {
        if (id === 'soldiers' || id === '_crew') return false;
        return army[id] && army[id].count > 0 && !WOK_Military.isFixedUnit(id);
      });
      if (!ids.length && soldiers <= 0) {
        showMapHint(tKey("no_mobile_forces_2", "No mobile forces"));
        return;
      }
      moveFrom = from;
      moveTo = to;
      const land = WOK_Military.regionsLandLinked(engine, from, to);
      // Skip expensive sea distance when already land-linked (was freezing attack UI)
      const sea = land ? false : WOK_Military.regionsSeaLinked(engine, from, to);
      const destOwner = engine.getRegionOwner ? engine.getRegionOwner(to) : null;
      const isAttack = !!(destOwner && destOwner !== playerCountry);
      document.getElementById('move-title').textContent = isAttack
        ? (tKey("attack_2", "Attack"))
        : (tKey("move_forces_2", "Move forces"));
      let linkTxt =
        (land ? (tKey("land_10_game_days", "Land · 10 game days")) : '') +
        (sea && !land ? (tKey("sea_route_2", "Sea route")) : '') +
        (!land && !sea ? (tKey("not_connected_2", "Not connected")) : '');
      if (isAttack) {
        const on = (typeof countryDisplayName === 'function') ? countryDisplayName(destOwner) : destOwner;
        linkTxt = (tKey("target", "Target: ")) + (on || destOwner) + (linkTxt ? ' · ' + linkTxt : '');
      }
      document.getElementById('move-meta').textContent = linkTxt;
      const box = document.getElementById('move-ratios');
      box.innerHTML = '';
      function addSliderRow(id, label, max, iconSrc) {
        max = Math.max(0, Math.floor(max));
        const row = document.createElement('div');
        row.className = 'ratio-row';
        if (iconSrc) {
          const img = document.createElement('img');
          img.src = iconSrc;
          row.appendChild(img);
        }
        const nm = document.createElement('div');
        nm.className = 'rn';
        nm.textContent = label;
        const wrap = document.createElement('div');
        wrap.className = 'slider-wrap';
        const rng = document.createElement('input');
        rng.type = 'range';
        rng.className = 'glass-range';
        rng.min = '0';
        rng.max = '100';
        rng.value = '100';
        rng.dataset.unit = id;
        rng.dataset.max = String(max);
        const val = document.createElement('span');
        val.className = 'slider-val';
        function sync() {
          const n = Math.floor(max * (Number(rng.value) || 0) / 100);
          val.textContent = String(n) + '/' + max;
          refreshMoveOilEstimate();
        }
        rng.addEventListener('input', sync);
        sync();
        wrap.appendChild(rng);
        wrap.appendChild(val);
        row.appendChild(nm);
        row.appendChild(wrap);
        box.appendChild(row);
      }
      if (soldiers > 0) {
        addSliderRow('soldiers',
          tKey("soldiers_3", "Soldiers"),
          soldiers, null);
      }
      ids.forEach(function (id) {
        const u = WOK.getUnit(id);
        const d = WOK_Military.domainOf(u);
        if (land && !sea && d === 'sea') return;
        addSliderRow(id,
          unitDisplayName(id),
          army[id].count,
          WOK_Military.unitIcon(u));
      });
      refreshMoveOilEstimate();
      forcePanelOpen(document.getElementById('move-sheet'), true, 120);
      if (infoDim) {
        infoDim.classList.add('open');
        infoDim.style.display = 'block';
        infoDim.style.visibility = 'visible';
        infoDim.style.pointerEvents = 'auto';
        infoDim.style.zIndex = '100';
      }
    }

function refreshBattleBar() {
      const bar = document.getElementById('battle-bar');
      const txt = document.getElementById('battle-bar-text');
      if (!bar || !window.WOK_Military) return;
      const battles = WOK_Military.activeBattles(world).filter(function (b) {
        return b.attacker === playerCountry && (b.status === 'fighting' || b.status === 'holding');
      });
      if (!battles.length) {
        bar.classList.remove('show');
        bar.dataset.battleId = '';
        if (typeof layoutTopBars === 'function') layoutTopBars();
        return;
      }
      const b = battles[0];
      const now = Date.now();
      const dayMs = (window.WOK_Military && WOK_Military.MS_PER_GAME_DAY) || 10000;
      let msg = '';
      const wbtn = document.getElementById('btn-battle-withdraw');
      if (b.status === 'fighting') {
        const wave = Math.min(3, (b.pulseCount || 0) + 1);
        const nextIn = Math.max(0, Math.ceil(((b.nextPulseAt || now) - now) / dayMs));
        msg = (isEnUi()
          ? ('Battle wave ' + wave + '/3 · next result in ~' + nextIn + ' game days')
          : ('موجة القتال ' + wave + '/3 · النتيجة التالية خلال ~' + nextIn + ' يوم'));
        if (wbtn) wbtn.style.display = '';
      } else {
        const leftDays = Math.max(0, Math.ceil(((b.holdUntil || now) - now) / dayMs));
        msg = (isEnUi()
          ? ('Holding region · annex in ~' + leftDays + ' game days (enemy may counter-attack)')
          : ('صامدون · الضم خلال ~' + leftDays + ' يوم (العدو قد يرسل قوات مضادة)'));
        if (wbtn) {
          wbtn.style.display = '';
          wbtn.textContent = tKey("withdraw_2", "Withdraw");
        }
      }
      if (wbtn) wbtn.textContent = tKey("withdraw_2", "Withdraw");
      txt.textContent = msg;
      bar.dataset.battleId = b.id;
      bar.classList.add('show');
      if (typeof layoutTopBars === 'function') layoutTopBars();
    }

    function refitMap() {
      if (!engine.ready) return;
      engine._resize && engine._resize();
      engine._clampCamera && engine._clampCamera();
      engine.setDirty && engine.setDirty();
    }

    /** Borders painted once on load / when ownership actually changes — never every frame */
    function applyPlayerBorders(force) {
      if (!engine || !engine.ready) return;
      const occN = (world && world.game && world.game.regionOwners)
        ? Object.keys(world.game.regionOwners).length : 0;
      const key = String(playerCountry || '') + '|' + occN;
      if (!force && window._wokBordersKey === key) return;
      window._wokBordersKey = key;

      if (engine.clearAllCountryStyles) engine.clearAllCountryStyles(true);
      const list = engine.listCountriesWithResources ? engine.listCountriesWithResources() : [];
      for (let i = 0; i < list.length; i++) {
        const name = list[i];
        if (name === playerCountry) continue;
        if (engine.setCountryBorder) engine.setCountryBorder(name, OTHER_BORDER, true);
      }
      if (playerCountry && engine.setPlayerBorder) {
        engine.setPlayerBorder(playerCountry, PLAYER_BORDER, true);
      } else if (playerCountry && engine.setCountryBorder) {
        engine.setCountryBorder(playerCountry, PLAYER_BORDER, true);
      }
      reapplyContestBorders(true); // silent styles only
      if (engine.setDirty) engine.setDirty();
    }

    function focusPlayer() {
      if (!playerCountry || !engine.getCountryCapital) return;
      const cap = engine.getCountryCapital(playerCountry);
      if (cap && cap.lon != null) {
        engine.camLon = cap.lon;
        engine.camLat = cap.mercY != null ? cap.mercY : (typeof mercY === 'function' ? 0 : 0);
        // gentle zoom so country is visible
        const zMin = engine._minZoom ? engine._minZoom() : 1;
        engine.zoom = Math.max(zMin, Math.min(4.5, zMin * 2.2));
        engine._clampCamera && engine._clampCamera();
        engine.setDirty && engine.setDirty();
      }
    }

    document.getElementById('btn-alerts').addEventListener('click', function () {
      renderAlertsList();
      document.getElementById('alerts-sheet').classList.add('open');
    });
    document.getElementById('alerts-sheet').addEventListener('click', function (e) {
      if (e.target.id === 'alerts-sheet') e.currentTarget.classList.remove('open');
    });
    var _wokClearTarget = null; // 'alerts' | 'news'
    function openClearConfirm(target) {
      _wokClearTarget = target;
      const lang = (window.WOK_I18N && WOK_I18N.normalizeLang) ? WOK_I18N.normalizeLang(settings.lang) : (settings.lang || 'ar');
      const tt = I18N[lang] || I18N.ar;
      const sheet = document.getElementById('confirm-clear-sheet');
      if (!sheet) return;
      const title = document.getElementById('confirm-clear-title');
      const msg = document.getElementById('confirm-clear-msg');
      const ok = document.getElementById('btn-confirm-clear-ok');
      const cl = document.getElementById('btn-confirm-clear-close');
      if (title) title.textContent = tt.clear_all_title || (lang === 'en' ? 'Delete all?' : 'حذف الكل؟');
      if (msg) msg.textContent = tt.clear_all_msg || (lang === 'en' ? 'Are you sure you want to delete all?' : 'هل أنت متأكد من أنك تريد حذف الكل؟');
      if (ok) ok.textContent = tt.clear_all_ok || (lang === 'en' ? 'Delete' : 'حذف');
      if (cl) cl.textContent = tt.clear_all_close || (lang === 'en' ? 'Close' : 'إغلاق');
      sheet.classList.remove('hidden');
      try { syncMapRenderPause(); } catch (_) {}
    }
    function closeClearConfirm() {
      const sheet = document.getElementById('confirm-clear-sheet');
      if (sheet) sheet.classList.add('hidden');
      _wokClearTarget = null;
      try { syncMapRenderPause(); } catch (_) {}
    }
    function doClearAll() {
      if (_wokClearTarget === 'alerts') {
        window._wokAlerts = [];
        updateAlertsBadge();
        renderAlertsList();
      } else if (_wokClearTarget === 'news' && window.WOK_News) {
        try {
          if (typeof WOK_News.clearChannel === 'function') {
            WOK_News.clearChannel(world, newsChannel);
          } else {
            const g = world && world.game;
            if (g) {
              if (newsChannel === 'private') g.newsPrivate = [];
              else g.news = [];
            }
          }
        } catch (_) {}
        try { renderNewsList(); updateNewsBadge(); } catch (_) {}
        try { persistWorld(world); } catch (_) {}
      }
      closeClearConfirm();
    }
    const btnAlertsClear = document.getElementById('btn-alerts-clear');
    if (btnAlertsClear) btnAlertsClear.addEventListener('click', function (e) {
      e.stopPropagation();
      openClearConfirm('alerts');
    });
    const btnAlertsClose = document.getElementById('btn-alerts-close');
    if (btnAlertsClose) btnAlertsClose.addEventListener('click', function () {
      document.getElementById('alerts-sheet').classList.remove('open');
    });
    const btnCClose = document.getElementById('btn-confirm-clear-close');
    if (btnCClose) btnCClose.addEventListener('click', closeClearConfirm);
    const btnCOk = document.getElementById('btn-confirm-clear-ok');
    if (btnCOk) btnCOk.addEventListener('click', doClearAll);
    const confSheet = document.getElementById('confirm-clear-sheet');
    if (confSheet) confSheet.addEventListener('click', function (e) {
      if (e.target.id === 'confirm-clear-sheet') closeClearConfirm();
    });


    function startMapLoad() {
      if (!world) return;
      const btnRetry = document.getElementById('btn-load-retry');
      if (btnRetry) {
        btnRetry.classList.remove('show');
        btnRetry.textContent = t.retry;
      }
      document.getElementById('load-text').textContent = t.loading;
      loadOverlay.classList.remove('hide');
      loadFill.style.width = '0%';
      let prog = 0;
      const tick = setInterval(function () {
        // slow crawl — weak devices may take long; this is NOT failure
        prog = Math.min(88, prog + 3);
        loadFill.style.width = prog + '%';
      }, 200);

      engine.load(
        'data/countries-110m.json',
        'data/countries-50m.json',
        'data/regions.json',
        (function () {
          var mobile = (typeof window.WOK_isMobile === 'function' && WOK_isMobile())
            || /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent || '');
          var hideIslands = settings && settings.hideSmallIslands;
          if (hideIslands == null && mobile) hideIslands = true;
          return {
            terrainQuality: mobile ? 'low' : 'med',
            hideSmallIslands: !!hideIslands
          };
        })()
      ).then(function () {
        clearInterval(tick);
        loadFill.style.width = '100%';
        try {
          if (world.game && world.game.regionOwners && engine.importOccupation) {
            engine.importOccupation(world.game.regionOwners);
          }
        } catch (e) { console.warn('importOccupation', e); }
        window._wokBordersKey = null;
        window._wokRedRegions = {};
        try { applyPlayerBorders(true); } catch (e) { console.warn('borders', e); }
        try { applyBorderDetailsToEngine(); } catch (e) { console.warn('detail', e); }
        try { reapplyContestBorders(true); } catch (e) {}
        try { focusPlayer(); } catch (e) {}
        try { tryInitStockpile(engine); } catch (e) {}
        try { seedStartingBuildings(); } catch (e) {}
        if (window.WOK && window.WOK.whenReady) {
          window.WOK.whenReady(function () {
            try { seedStartingBuildings(); } catch (e) {}
            try { tickEconomy(); } catch (e) {}
          });
        }
        try { ensureLocalPricesSeeded(); } catch (e) {}
        try { tickEconomy(); } catch (e) {}
        try { renderResBar(); } catch (e) {}
        try { updateDateBar(); } catch (e) {}
        if (!window._wokEconTimer) {
          window._wokEconTimer = setInterval(function () {
            try { updateDateBar(); } catch (e) {}
            if (world && world.game) {
              try { recomputeLocalPrices(); } catch (e) {}
              try { tickEconomy(); } catch (e) {}
            }
          }, 1000);
        }
        setTimeout(function () { loadOverlay.classList.add('hide'); }, 180);
        setTimeout(function () { try { applyDefaultOrient(); } catch (e) {} }, 200);
        setTimeout(function () { try { applyDefaultOrient(); } catch (e) {} }, 550);
      }).catch(function (err) {
        clearInterval(tick);
        console.error(err);
        document.getElementById('load-text').textContent = t.load_fail;
        if (btnRetry) btnRetry.classList.add('show');
      });
    }
    if (world) startMapLoad();
    document.getElementById('btn-load-retry').addEventListener('click', function () {
      startMapLoad();
    });

    // Resource bar from items tagged "basic" (via Translator → script.js)
    if (window.WOK && typeof window.WOK.whenReady === 'function') {
      window.WOK.whenReady(function () { renderResBar(); });
    } else {
      let tries = 0;
      const pollItems = setInterval(function () {
        tries++;
        if ((window.WOK && window.WOK.data && window.WOK.data.ready) || window.WOK_ITEMS) {
          clearInterval(pollItems);
          renderResBar();
        } else if (tries > 40) clearInterval(pollItems);
      }, 50);
    }

    // ── Country info panel ──
    function rankLabel(v) {
      // Flat i18n keys — never assume nested t.ranks (was crashing openCountryInfo)
      const bag = t || bagLang() || {};
      const ranks = bag.ranks || {};
      const pick = function (k, fb) {
        if (ranks[k] != null && ranks[k] !== '') return ranks[k];
        if (bag[k] != null && bag[k] !== '') return bag[k];
        if (window.WOK_I18N && WOK_I18N.t) return WOK_I18N.t(k, fb);
        return fb;
      };
      const n = Number(v);
      if (!(n > 0.25)) return pick('vl', tKey("very_low", "Very low"));
      if (n <= 0.5)  return pick('l',  tKey("low", "Low"));
      if (n <= 1.0)  return pick('m',  tKey("average", "Average"));
      if (n <= 1.5)  return pick('h',  tKey("high", "High"));
      return pick('vh', tKey("very_high", "Very high"));
    }
    function barPct(v) {
      return Math.max(4, Math.min(100, (Number(v) / 3) * 100));
    }
    function setRes(key, val) {
      try {
        const nEl = document.getElementById('res-' + key + '-n');
        const fEl = document.getElementById('res-' + key + '-f');
        const rEl = document.getElementById('res-' + key + '-r');
        if (nEl) nEl.textContent = Number(val).toFixed(2);
        if (fEl) fEl.style.width = barPct(val) + '%';
        if (rEl) rEl.textContent = rankLabel(val);
      } catch (e) {
        console.warn('[game] setRes', key, e);
      }
    }
    
    // ── Locale: country + region names ──
    const AR_COUNTRIES = {
      "Afghanistan": "أفغانستان",
      "Albania": "ألبانيا",
      "Algeria": "الجزائر",
      "Angola": "أنغولا",
      "Antarctica": "أنتاركتيكا",
      "Argentina": "الأرجنتين",
      "Armenia": "أرمينيا",
      "Australia": "أستراليا",
      "Austria": "النمسا",
      "Azerbaijan": "أذربيجان",
      "Bahamas": "البهاما",
      "Bahrain": "البحرين",
      "Bangladesh": "بنغلاديش",
      "Belarus": "بيلاروس",
      "Belgium": "بلجيكا",
      "Belize": "بليز",
      "Benin": "بنين",
      "Bhutan": "بوتان",
      "Bolivia": "بوليفيا",
      "Bosnia and Herz.": "البوسنة",
      "Bosnia and Herzegovina": "البوسنة",
      "Botswana": "بوتسوانا",
      "Brazil": "البرازيل",
      "Brunei": "بروناي",
      "Bulgaria": "بلغاريا",
      "Burkina Faso": "بوركينا فاسو",
      "Burundi": "بوروندي",
      "Cambodia": "كمبوديا",
      "Cameroon": "الكاميرون",
      "Canada": "كندا",
      "Central African Rep.": "أفريقيا الوسطى",
      "Central African Republic": "أفريقيا الوسطى",
      "Chad": "تشاد",
      "Chile": "تشيلي",
      "China": "الصين",
      "Colombia": "كولومبيا",
      "Congo": "الكونغو",
      "Costa Rica": "كوستاريكا",
      "Croatia": "كرواتيا",
      "Cuba": "كوبا",
      "Cyprus": "قبرص",
      "Czechia": "التشيك",
      "Czech Republic": "التشيك",
      "Côte d'Ivoire": "ساحل العاج",
      "Dem. Rep. Congo": "الكونغو الديمقراطية",
      "Democratic Republic of the Congo": "الكونغو الديمقراطية",
      "Denmark": "الدنمارك",
      "Djibouti": "جيبوتي",
      "Dominican Rep.": "الدومينيكان",
      "Dominican Republic": "الدومينيكان",
      "East Timor": "تيمور الشرقية",
      "Ecuador": "الإكوادور",
      "Egypt": "مصر",
      "El Salvador": "السلفادور",
      "Eq. Guinea": "غينيا الاستوائية",
      "Equatorial Guinea": "غينيا الاستوائية",
      "Eritrea": "إريتريا",
      "Estonia": "إستونيا",
      "Eswatini": "إسواتيني",
      "Ethiopia": "إثيوبيا",
      "Falkland Is.": "فوكلاند",
      "Fiji": "فيجي",
      "Finland": "فنلندا",
      "France": "فرنسا",
      "Gabon": "الغابون",
      "Gambia": "غامبيا",
      "Georgia": "جورجيا",
      "Germany": "ألمانيا",
      "Ghana": "غانا",
      "Greece": "اليونان",
      "Greenland": "غرينلاند",
      "Guatemala": "غواتيمالا",
      "Guinea": "غينيا",
      "Guinea Bissau": "غينيا بيساو",
      "Guinea-Bissau": "غينيا بيساو",
      "Guyana": "غيانا",
      "Haiti": "هايتي",
      "Honduras": "هندوراس",
      "Hungary": "هنغاريا",
      "Iceland": "آيسلندا",
      "India": "الهند",
      "Indonesia": "إندونيسيا",
      "Iran": "إيران",
      "Iraq": "العراق",
      "Ireland": "أيرلندا",
      "Israel": "فلسطين",
      "Italy": "إيطاليا",
      "Ivory Coast": "ساحل العاج",
      "Jamaica": "جامايكا",
      "Japan": "اليابان",
      "Jordan": "الأردن",
      "Kazakhstan": "كازاخستان",
      "Kenya": "كينيا",
      "Kosovo": "كوسوفو",
      "Kuwait": "الكويت",
      "Kyrgyzstan": "قيرغيزستان",
      "Laos": "لاوس",
      "Latvia": "لاتفيا",
      "Lebanon": "لبنان",
      "Lesotho": "ليسوتو",
      "Liberia": "ليبيريا",
      "Libya": "ليبيا",
      "Lithuania": "ليتوانيا",
      "Luxembourg": "لوكسمبورغ",
      "Macedonia": "مقدونيا",
      "Madagascar": "مدغشقر",
      "Malawi": "ملاوي",
      "Malaysia": "ماليزيا",
      "Mali": "مالي",
      "Malta": "مالطا",
      "Mauritania": "موريتانيا",
      "Mauritius": "موريشيوس",
      "Mexico": "المكسيك",
      "Moldova": "مولدوفا",
      "Mongolia": "منغوليا",
      "Montenegro": "الجبل الأسود",
      "Morocco": "المغرب",
      "Mozambique": "موزمبيق",
      "Myanmar": "ميانمار",
      "Namibia": "ناميبيا",
      "Nepal": "نيبال",
      "Netherlands": "هولندا",
      "New Caledonia": "كاليدونيا الجديدة",
      "New Zealand": "نيوزيلندا",
      "Nicaragua": "نيكاراغوا",
      "Niger": "النيجر",
      "Nigeria": "نيجيريا",
      "North Korea": "كوريا الشمالية",
      "North Macedonia": "مقدونيا الشمالية",
      "Norway": "النرويج",
      "Oman": "عمان",
      "Pakistan": "باكستان",
      "Palestine": "فلسطين",
      "Panama": "بنما",
      "Papua New Guinea": "بابوا غينيا الجديدة",
      "Paraguay": "باراغواي",
      "Peru": "بيرو",
      "Philippines": "الفلبين",
      "Poland": "بولندا",
      "Portugal": "البرتغال",
      "Puerto Rico": "بورتوريكو",
      "Qatar": "قطر",
      "Republic of Serbia": "صربيا",
      "Republic of the Congo": "الكونغو",
      "Romania": "رومانيا",
      "Russia": "روسيا",
      "Rwanda": "رواندا",
      "S. Sudan": "جنوب السودان",
      "Saudi Arabia": "السعودية",
      "Senegal": "السنغال",
      "Serbia": "صربيا",
      "Sierra Leone": "سيراليون",
      "Slovakia": "سلوفاكيا",
      "Slovenia": "سلوفينيا",
      "Solomon Is.": "جزر سليمان",
      "Solomon Islands": "جزر سليمان",
      "Somalia": "الصومال",
      "Somaliland": "صوماليلاند",
      "South Africa": "جنوب أفريقيا",
      "South Korea": "كوريا الجنوبية",
      "South Sudan": "جنوب السودان",
      "Spain": "إسبانيا",
      "Sri Lanka": "سريلانكا",
      "Sudan": "السودان",
      "Suriname": "سورينام",
      "Swaziland": "إسواتيني",
      "Sweden": "السويد",
      "Switzerland": "سويسرا",
      "Syria": "سوريا",
      "Taiwan": "تايوان",
      "Tajikistan": "طاجيكستان",
      "Tanzania": "تنزانيا",
      "United Republic of Tanzania": "تنزانيا",
      "Thailand": "تايلاند",
      "The Bahamas": "البهاما",
      "Timor-Leste": "تيمور الشرقية",
      "Togo": "توغو",
      "Trinidad and Tobago": "ترينيداد وتوباغو",
      "Tunisia": "تونس",
      "Turkey": "تركيا",
      "Turkmenistan": "تركمانستان",
      "Uganda": "أوغندا",
      "Ukraine": "أوكرانيا",
      "United Arab Emirates": "الإمارات",
      "United Kingdom": "المملكة المتحدة",
      "United States of America": "الولايات المتحدة",
      "United States": "الولايات المتحدة",
      "Uruguay": "الأوروغواي",
      "Uzbekistan": "أوزبكستان",
      "Vanuatu": "فانواتو",
      "Venezuela": "فنزويلا",
      "Vietnam": "فيتنام",
      "W. Sahara": "الصحراء الغربية",
      "Western Sahara": "الصحراء الغربية",
      "Yemen": "اليمن",
      "Zambia": "زامبيا",
      "Zimbabwe": "زيمبابوي",
      "eSwatini": "إسواتيني",
      "Fr. S. Antarctic Lands": "أراض فرنسية جنوبية",
      "N. Cyprus": "قبرص"
    };

    function countryDisplayName(name) {
      if (!name) return '';
      if (isEnUi()) return name;
      return AR_COUNTRIES[name] || name;
    }
    function regionDisplayName(r) {
      if (!r) return '';
      const base = r.displayName || r.name || '';
      if (isEnUi()) return base;
      // Prefer "Country · Region" when we have an Arabic country
      const cAr = r.country ? (AR_COUNTRIES[r.country] || r.country) : '';
      if (cAr && base) return cAr + ' · ' + base;
      return base;
    }

    function metaLine(regionsCount, neighborsCount) {
      try {
        if (t && typeof t.meta === 'function') return t.meta(regionsCount, neighborsCount);
      } catch (_) {}
      const lang = (settings && settings.lang) || 'ar';
      if (lang === 'en') return regionsCount + ' regions · ' + neighborsCount + ' neighbors';
      if (lang === 'tr') return regionsCount + ' bölge · ' + neighborsCount + ' komşu';
      return regionsCount + ' أقاليم · ' + neighborsCount + ' جيران';
    }
    function forceCountryInfoOpen(open) {
      if (!countryInfo) return;
      if (open) {
        if (infoDim) {
          infoDim.classList.add('open');
          infoDim.style.display = 'block';
          infoDim.style.visibility = 'visible';
          infoDim.style.pointerEvents = 'auto';
          infoDim.style.zIndex = '100';
        }
        countryInfo.classList.add('open');
        countryInfo.style.display = 'block';
        countryInfo.style.visibility = 'visible';
        countryInfo.style.pointerEvents = 'auto';
        countryInfo.style.zIndex = '110';
        void countryInfo.offsetHeight;
      } else {
        countryInfo.classList.remove('open');
        countryInfo.style.display = '';
        countryInfo.style.visibility = '';
        countryInfo.style.pointerEvents = '';
        countryInfo.style.zIndex = '';
        if (infoDim) {
          infoDim.classList.remove('open');
          infoDim.style.display = '';
          infoDim.style.visibility = '';
          infoDim.style.pointerEvents = '';
          infoDim.style.zIndex = '';
        }
      }
    }
    function openCountryInfoFor(countryName) {
      if (!countryName || !engine || !engine.ready) return;
      let name = countryName;
      try {
        if (engine.resolveCountryName) name = engine.resolveCountryName(name) || name;
      } catch (_) {}

      let regions = [], coastal = 0, neighbors = [], res = { gold: 0, iron: 0, oil: 0 };
      try {
        regions = engine.getCountryRegions ? (engine.getCountryRegions(name) || []) : [];
        coastal = engine.getCountryCoastalCount ? engine.getCountryCoastalCount(name) : 0;
        neighbors = engine.getCountryLandNeighbors ? (engine.getCountryLandNeighbors(name) || []) : [];
        res = engine.getCountryResources ? engine.getCountryResources(name) : res;
      } catch (e) {
        console.warn('[game] country stats', e);
      }

      try {
        const isPlayer = name === playerCountry || countryName === playerCountry;
        const nameEl = document.getElementById('info-name');
        if (nameEl) nameEl.textContent = countryDisplayName(name) + (isPlayer ? (tKey("you", " (You)")) : '');
        const metaEl = document.getElementById('info-meta');
        if (metaEl) metaEl.innerHTML = metaLine(regions.length, neighbors.length);
        setRes('gold', res.gold);
        setRes('iron', res.iron);
        setRes('oil', res.oil);
        const sr = document.getElementById('stat-regions');
        if (sr) sr.textContent = String(regions.length);
        const sc = document.getElementById('stat-coastal');
        if (sc) sc.textContent = String(coastal);
        const sn = document.getElementById('stat-neighbors');
        if (sn) sn.textContent = String(neighbors.length);
      } catch (e) {
        console.warn('[game] fill country info', e);
      }

      requestAnimationFrame(function () {
        forceCountryInfoOpen(true);
      });
    }
    function openCountryInfo() {
      openCountryInfoFor(playerCountry);
    }
    function closeCountryInfo() {
      forceCountryInfoOpen(false);
    }

    let tradeMode = 'buy'; // buy | sell

    document.getElementById('btn-res-fab').addEventListener('click', function () {
      if (paused) return;
      closeMarket();
      openCountryInfo();
    });
    document.getElementById('btn-info-close').addEventListener('click', closeCountryInfo);
    function closeRegionArmySheet() {
      forcePanelOpen(document.getElementById('region-army-sheet'), false);
      // Drop dim only if nothing else needs it
      if (!countryInfo.classList.contains('open') &&
          !document.getElementById('market-panel').classList.contains('open') &&
          !document.getElementById('news-panel').classList.contains('open') &&
          !document.getElementById('move-sheet').classList.contains('open') &&
          !document.getElementById('army-panel').classList.contains('open') &&
          !document.getElementById('builds-panel').classList.contains('open')) {
        if (infoDim) {
          infoDim.classList.remove('open');
          infoDim.style.display = '';
          infoDim.style.visibility = '';
          infoDim.style.pointerEvents = '';
          infoDim.style.zIndex = '';
        }
      }
    }
    // PER-1.4.2: register panel closers + unified backdrop (also handled in panels.js)
    if (window.WOK_Panels) {
      try {
        WOK_Panels.register('countryInfo', closeCountryInfo);
        WOK_Panels.register('market', closeMarket);
        if (typeof closeBuildsPanel === 'function') WOK_Panels.register('builds', closeBuildsPanel);
        if (typeof closeBuildBuyPanel === 'function') WOK_Panels.register('buildBuy', closeBuildBuyPanel);
        if (typeof closeArmyPanel === 'function') WOK_Panels.register('army', closeArmyPanel);
        if (typeof closeNewsPanel === 'function') WOK_Panels.register('news', closeNewsPanel);
        if (typeof closeMoveSheet === 'function') WOK_Panels.register('move', closeMoveSheet);
        WOK_Panels.register('regionArmy', closeRegionArmySheet);
        if (typeof closeEnlistDetail === 'function') WOK_Panels.register('enlistDetail', closeEnlistDetail);
        if (typeof closeResearchBuy === 'function') WOK_Panels.register('researchBuy', closeResearchBuy);
      } catch (e) { console.warn('WOK_Panels register', e); }
    }
    infoDim.addEventListener('click', function () {
      if (window.WOK_Panels && typeof WOK_Panels.closeAll === 'function') {
        WOK_Panels.closeAll();
        return;
      }
      closeCountryInfo();
      closeMarket();
      if (typeof closeBuildsPanel === 'function') closeBuildsPanel();
      if (typeof closeBuildBuyPanel === 'function') closeBuildBuyPanel();
      if (typeof closeArmyPanel === 'function') closeArmyPanel();
      if (typeof closeNewsPanel === 'function') closeNewsPanel();
      if (typeof closeMoveSheet === 'function') closeMoveSheet();
      closeRegionArmySheet();
    });

    function listTradeItems() {
      if (window.WOK_ITEMS && window.WOK_ITEMS.list) return window.WOK_ITEMS.list.slice();
      return [];
    }
    function renderRateList() {
      const listEl = document.getElementById('fx-list');
      if (!listEl) return;
      listEl.innerHTML = '';
      ensureLocalPricesSeeded();
      const items = listTradeItems();
      let maxRate = LOCAL_PRICE_MIN;
      const rows = items.map(function (item) {
        const rate = unitBuyPrice(item.identifier); // display buy unit price
        if (rate > maxRate) maxRate = rate;
        return { item: item, rate: rate };
      });
      rows.forEach(function (r) {
        const item = r.item;
        const name = item && item.name
          ? (item.name[settings.lang] || item.name.en || item.name.ar || item.identifier)
          : item.identifier;
        const row = document.createElement('div');
        row.className = 'fx-row';
        const img = document.createElement('img');
        img.className = 'res-icon';
        img.src = itemIconPath(item);
        img.alt = '';
        const nameEl = document.createElement('div');
        nameEl.className = 'fx-name';
        nameEl.textContent = name;
        const track = document.createElement('div');
        track.className = 'res-track';
        const fill = document.createElement('div');
        fill.className = 'res-fill gold';
        fill.style.width = Math.max(4, Math.min(100, (r.rate / maxRate) * 100)) + '%';
        track.appendChild(fill);
        const rateEl = document.createElement('div');
        rateEl.className = 'fx-rate';
        rateEl.textContent = dispPrice(r.rate);
        row.appendChild(img);
        row.appendChild(nameEl);
        row.appendChild(track);
        row.appendChild(rateEl);
        listEl.appendChild(row);
      });
    }
    function fillTradeItemSelect() {
      const sel = document.getElementById('sel-trade-item');
      if (!sel) return;
      const prev = sel.value;
      sel.innerHTML = '';
      listTradeItems().forEach(function (item) {
        if (!item || item.identifier === ID_GOLD) return; // trade goods only (not pure gold)
        const opt = document.createElement('option');
        opt.value = item.identifier;
        opt.textContent = item.name
          ? (item.name[settings.lang] || item.name.en || item.name.ar || item.identifier)
          : item.identifier;
        sel.appendChild(opt);
      });
      // if only gold exists, allow gold too
      if (!sel.options.length) {
        listTradeItems().forEach(function (item) {
          const opt = document.createElement('option');
          opt.value = item.identifier;
          opt.textContent = item.name
            ? (item.name[settings.lang] || item.name.en || item.name.ar || item.identifier)
            : item.identifier;
          sel.appendChild(opt);
        });
      }
      if (prev) sel.value = prev;
      if (!sel.value && sel.options.length) sel.selectedIndex = 0;
    }
    function syncTradeSlider() {
      const sel = document.getElementById('sel-trade-item');
      const rng = document.getElementById('rng-trade');
      const qtyEl = document.getElementById('trade-qty-val');
      const unitEl = document.getElementById('trade-unit-price');
      const totalEl = document.getElementById('trade-total');
      if (!sel || !rng) return;
      const id = sel.value;
      if (!id) return;
      const gold = getStock(ID_GOLD);
      const stock = getStock(id);
      const buyU = unitBuyPrice(id);
      const sellU = unitSellPrice(id);

      if (tradeMode === 'buy') {
        // slider in gold spent: min = unit price (at least 1 gold display), max = gold owned
        const minGold = Math.max(1, dispInt(buyU) || 1);
        const maxGold = Math.max(minGold, dispInt(gold));
        rng.min = String(minGold);
        rng.max = String(maxGold);
        let cur = Number(rng.value);
        if (!isFinite(cur) || cur < minGold) cur = minGold;
        if (cur > maxGold) cur = maxGold;
        rng.value = String(cur);
        const qty = buyU > 0 ? Math.floor(cur / buyU) : 0;
        qtyEl.textContent = String(Math.max(0, qty));
        unitEl.textContent = t.unit_price + ': ' + dispPrice(buyU);
        totalEl.textContent = t.total + ': ' + dispPrice(qty * buyU);
      } else {
        const maxQ = Math.max(1, dispInt(stock));
        rng.min = '1';
        rng.max = String(maxQ);
        let cur = Number(rng.value);
        if (!isFinite(cur) || cur < 1) cur = 1;
        if (cur > maxQ) cur = maxQ;
        rng.value = String(cur);
        qtyEl.textContent = String(dispInt(cur));
        unitEl.textContent = t.unit_price + ': ' + dispPrice(sellU);
        totalEl.textContent = t.total + ': ' + dispPrice(cur * sellU);
      }
    }
    function setTradeMode(mode) {
      tradeMode = mode === 'sell' ? 'sell' : 'buy';
      document.getElementById('tab-buy').classList.toggle('active', tradeMode === 'buy');
      document.getElementById('tab-sell').classList.toggle('active', tradeMode === 'sell');
      syncTradeSlider();
    }

    function anyHeavyPanelOpen() {
      var ids = ['news-panel', 'army-panel', 'market-panel', 'builds-panel', 'build-buy-panel',
        'region-army-sheet', 'country-info', 'confirm-clear-sheet', 'alerts-sheet', 'move-sheet'];
      for (var i = 0; i < ids.length; i++) {
        var el = document.getElementById(ids[i]);
        if (!el) continue;
        if (el.classList.contains('open')) return true;
        if (ids[i] === 'confirm-clear-sheet' && !el.classList.contains('hidden') && el.style.display !== 'none') {
          // confirm uses .hidden not .open
          if (!el.classList.contains('hidden')) return true;
        }
      }
      return false;
    }
    function syncMapRenderPause() {
      try {
        if (typeof engine === 'undefined' || !engine) return;
        if (window.WOK_MapUiBridge && WOK_MapUiBridge.sync) {
          WOK_MapUiBridge.sync(engine);
          return;
        }
        if (typeof engine.setRenderPaused === 'function') {
          engine.setRenderPaused(anyHeavyPanelOpen());
        }
      } catch (_) {}
    }

    function forcePanelOpen(el, open, z) {
      if (!el) return;
      if (open) {
        el.classList.add('open');
        el.style.display = el.id === 'market-panel' ? 'flex' : 'block';
        el.style.visibility = 'visible';
        el.style.pointerEvents = 'auto';
        el.style.zIndex = String(z != null ? z : 120);
      } else {
        el.classList.remove('open');
        el.style.display = '';
        el.style.visibility = '';
        el.style.pointerEvents = '';
        el.style.zIndex = '';
      }
      try { syncMapRenderPause(); } catch (_) {}
    }
    function openMarket() {
      ensureLocalPricesSeeded();
      recomputeLocalPrices();
      renderRateList();
      fillTradeItemSelect();
      setTradeMode(tradeMode);
      try { closeCountryInfo(); } catch (_) {}
      const panel = document.getElementById('market-panel');
      forcePanelOpen(panel, true, 120);
      if (infoDim) {
        infoDim.classList.add('open');
        infoDim.style.display = 'block';
        infoDim.style.visibility = 'visible';
        infoDim.style.pointerEvents = 'auto';
        infoDim.style.zIndex = '100';
      }
    }
    function closeMarket() {
      const el = document.getElementById('market-panel');
      forcePanelOpen(el, false);
      if (!countryInfo.classList.contains('open')) {
        if (infoDim) {
          infoDim.classList.remove('open');
          infoDim.style.display = '';
          infoDim.style.visibility = '';
          infoDim.style.pointerEvents = '';
          infoDim.style.zIndex = '';
        }
      }
    }
    function confirmTrade() {
      try {
        const sel = document.getElementById('sel-trade-item');
        const rng = document.getElementById('rng-trade');
        if (!sel || !rng || !world) return;
        const id = sel.value;
        if (!id) return;
        if (!world.game.market) world.game.market = { localPrice: {}, history: [] };
        if (tradeMode === 'buy') {
          // Pay at CURRENT buy price, then raise mid (all items).
          const buyU = unitBuyPrice(id);
          if (!(buyU > 0)) return;
          const goldSpend = Number(rng.value) || 0;
          const qty = Math.floor(goldSpend / buyU);
          if (qty < 1) return;
          const pay = Math.max(1, Math.ceil(qty * buyU - 1e-9));
          if (getStock(ID_GOLD) < pay) return;
          setStock(ID_GOLD, getStock(ID_GOLD) - pay);
          setStock(id, getStock(id) + qty);
          world.game.market._skipImpactOnce = true;
          recordTrade(id, qty, true);
          applyLocalImpact(id, qty, true);
        } else {
          // All goods: lower mid FIRST, then pay 90% of NEW buy price (anti-arbitrage).
          const qty = Math.max(1, dispInt(rng.value));
          if (getStock(id) < qty) return;
          applyLocalImpact(id, qty, false);
          const buyU = unitBuyPrice(id);
          const sellU = 0.9 * buyU;
          const recv = Math.max(0, Math.floor(qty * sellU + 1e-9));
          setStock(id, getStock(id) - qty);
          setStock(ID_GOLD, getStock(ID_GOLD) + recv);
          world.game.market._skipImpactOnce = true;
          recordTrade(id, qty, false);
        }
        persistWorld(world);
        renderResBar();
        renderRateList();
        syncTradeSlider();
      } catch (err) {
        try { console.error('[WOK] confirmTrade', err); } catch (_) {}
      }
    }

    document.getElementById('btn-fx-fab').addEventListener('click', function (e) {
      try { e.stopPropagation(); } catch (_) {}
      if (paused) return;
      // Market only — do NOT open country-info / reserves sheet
      try { closeCountryInfo(); } catch (_) {}
      closeBuildsPanel();
      closeBuildBuyPanel();
      try { closeArmyPanel(); } catch (_) {}
      openMarket();
    });
    document.getElementById('btn-fx-close').addEventListener('click', closeMarket);
    document.getElementById('tab-buy').addEventListener('click', function () { setTradeMode('buy'); });
    document.getElementById('tab-sell').addEventListener('click', function () { setTradeMode('sell'); });
    document.getElementById('sel-trade-item').addEventListener('change', syncTradeSlider);
    document.getElementById('rng-trade').addEventListener('input', syncTradeSlider);
    document.getElementById('btn-trade-confirm').addEventListener('click', confirmTrade);

    // ── Buildings UI ──
    let selectedBuildId = null;
    function closeBuildsPanel() {
      forcePanelOpen(document.getElementById('builds-panel'), false);
      if (!countryInfo.classList.contains('open') &&
          !document.getElementById('market-panel').classList.contains('open') &&
          !document.getElementById('build-buy-panel').classList.contains('open') &&
          !document.getElementById('army-panel').classList.contains('open')) {
        if (infoDim) {
          infoDim.classList.remove('open');
          infoDim.style.display = '';
          infoDim.style.visibility = '';
          infoDim.style.pointerEvents = '';
          infoDim.style.zIndex = '';
        }
      }
    }
    function closeBuildBuyPanel() {
      forcePanelOpen(document.getElementById('build-buy-panel'), false);
      if (!countryInfo.classList.contains('open') &&
          !document.getElementById('market-panel').classList.contains('open') &&
          !document.getElementById('builds-panel').classList.contains('open') &&
          !document.getElementById('army-panel').classList.contains('open')) {
        if (infoDim) {
          infoDim.classList.remove('open');
          infoDim.style.display = '';
          infoDim.style.visibility = '';
          infoDim.style.pointerEvents = '';
          infoDim.style.zIndex = '';
        }
      }
    }
    function renderBuildsPanel() {
      seedStartingBuildings();
      processBuildQueue(Date.now());
      const title = document.getElementById('builds-title');
      if (title) title.textContent = t.buildings;
      const bar = document.getElementById('builds-owned-bar');
      const cards = document.getElementById('build-cards');
      if (!bar || !cards) return;
      bar.innerHTML = '';
      cards.innerHTML = '';
      const list = listBasicBuilds();
      list.forEach(function (b) {
        if (!b || !b.identifier) return;
        const owned = getBuildCount(b.identifier);
        const chip = document.createElement('div');
        chip.className = 'builds-owned-chip';
        const img = document.createElement('img');
        img.src = buildIconPath(b);
        img.alt = '';
        const span = document.createElement('span');
        span.textContent = ': ' + owned;
        chip.appendChild(img);
        chip.appendChild(span);
        bar.appendChild(chip);

        const card = document.createElement('div');
        card.className = 'build-card';
        const cimg = document.createElement('img');
        cimg.src = buildIconPath(b);
        cimg.alt = '';
        const nm = document.createElement('div');
        nm.className = 'bn';
        nm.textContent = b.name ? (b.name[settings.lang] || b.name.en || b.name.ar) : b.identifier;
        const q = document.createElement('div');
        q.className = 'bq';
        const job = world.game.buildQueue && world.game.buildQueue[b.identifier];
        const qLeft = job && job.remaining > 0 ? job.remaining : 0;
        q.innerHTML = t.owned + ': <b>' + owned + '</b>' +
          (qLeft ? ' <span class="q-building">(' + qLeft + ' ' + t.in_queue + ')</span>' : '');
        const buyBtn = document.createElement('button');
        buyBtn.type = 'button';
        buyBtn.className = 'menu-btn ok';
        buyBtn.textContent = t.buy;
        buyBtn.addEventListener('click', function () {
          openBuildBuy(b.identifier);
        });
        card.appendChild(cimg);
        card.appendChild(nm);
        card.appendChild(q);
        card.appendChild(buyBtn);
        cards.appendChild(card);
      });
    }
    function openBuildsPanel() {
      closeMarket();
      closeCountryInfo();
      closeBuildBuyPanel();
      try { closeArmyPanel(); } catch (_) {}
      renderBuildsPanel();
      forcePanelOpen(document.getElementById('builds-panel'), true, 120);
      if (infoDim) {
        infoDim.classList.add('open');
        infoDim.style.display = 'block';
        infoDim.style.visibility = 'visible';
        infoDim.style.pointerEvents = 'auto';
        infoDim.style.zIndex = '100';
      }
    }
    function refreshBuildBuyDetails() {
      if (!selectedBuildId) return;
      const b = window.WOK && window.WOK.getBuild ? window.WOK.getBuild(selectedBuildId) : null;
      if (!b) return;
      const rawQ = document.getElementById('inp-build-qty').value;
      let qty = rawQ === '' ? 0 : Math.max(0, Math.floor(Number(rawQ) || 0));
      if (qty < 1) qty = 1; // cost preview uses at least 1, but do not force-write into input

      document.getElementById('lbl-build-qty').textContent = t.quantity;
      document.getElementById('lbl-build-cost').textContent = t.cost;
      document.getElementById('lbl-build-time').textContent = t.build_time;
      document.getElementById('lbl-build-prod').textContent = t.produces;
      document.getElementById('lbl-build-prod-time').textContent = t.prod_time_one;
      document.getElementById('lbl-build-storage').textContent = t.storage_per;
      document.getElementById('btn-build-confirm').textContent = t.buy;

      const chips = document.getElementById('build-cost-chips');
      chips.innerHTML = '';
      const cost = b.cost || {};
      Object.keys(cost).forEach(function (resId) {
        const item = window.WOK && window.WOK.getItem ? window.WOK.getItem(resId) : null;
        const chip = document.createElement('span');
        chip.className = 'cost-chip';
        const img = document.createElement('img');
        img.src = itemIconPath(item);
        img.alt = '';
        const amt = document.createElement('span');
        amt.textContent = formatAmount(Number(cost[resId]) * qty);
        chip.appendChild(img);
        chip.appendChild(amt);
        chips.appendChild(chip);
      });

      document.getElementById('build-time-val').textContent =
        formatGameDurationFromRealMinutes((Number(b.buildTimeMinutes) || 0) * qty);

      const resId = b.production && b.production.resource;
      const resItem = resId && window.WOK ? window.WOK.getItem(resId) : null;
      const resName = resItem && resItem.name
        ? (resItem.name[settings.lang] || resItem.name.en || resItem.name.ar)
        : (resId || '—');
      document.getElementById('build-prod-val').textContent = resName;

      const sec = prodSecondsPerUnit(b);
      document.getElementById('build-prod-time-val').textContent =
        formatGameDurationFromRealMinutes(sec / 60);

      const storage = Number(b.storagePerBuilding) || 0;
      document.getElementById('build-storage-val').textContent = formatAmount(storage);
    }
    function openBuildBuy(id) {
      selectedBuildId = id;
      const b = window.WOK && window.WOK.getBuild ? window.WOK.getBuild(id) : null;
      if (!b) return;
      document.getElementById('build-buy-name').textContent =
        b.name ? (b.name[settings.lang] || b.name.en || b.name.ar) : id;
      document.getElementById('build-buy-desc').textContent =
        b.description ? (b.description[settings.lang] || b.description.en || b.description.ar || '') : '';
      document.getElementById('inp-build-qty').value = '1';
      refreshBuildBuyDetails();
      document.getElementById('build-buy-panel').classList.add('open');
      infoDim.classList.add('open');
    }

    document.getElementById('btn-builds-fab').addEventListener('click', function (e) {
      try { e.stopPropagation(); } catch (_) {}
      if (paused) return;
      openBuildsPanel();
    });
    document.getElementById('btn-builds-close').addEventListener('click', closeBuildsPanel);
    document.getElementById('btn-build-buy-close').addEventListener('click', function () {
      closeBuildBuyPanel();
    });
    document.getElementById('inp-build-qty').addEventListener('input', refreshBuildBuyDetails);
    document.getElementById('inp-build-qty').addEventListener('focus', function () { this.select(); });
    document.getElementById('inp-enlist-qty').addEventListener('focus', function () { this.select(); });
    document.getElementById('btn-build-confirm').addEventListener('click', function () {
      if (!selectedBuildId) return;
      let qty = Math.max(1, Math.floor(Number(document.getElementById('inp-build-qty').value) || 1));
      if (!queueBuild(selectedBuildId, qty)) return;
      closeBuildBuyPanel();
      renderBuildsPanel();
      tickEconomy();
    });

    // ── Army UI ──
    function closeArmyPanel() {
      forcePanelOpen(document.getElementById('army-panel'), false);
      const ed = document.getElementById('enlist-detail-panel');
      if (ed) ed.style.display = 'none';
      const rb = document.getElementById('research-buy-panel');
      if (rb) rb.style.display = 'none';
      if (!countryInfo.classList.contains('open') &&
          !document.getElementById('market-panel').classList.contains('open') &&
          !document.getElementById('builds-panel').classList.contains('open') &&
          !document.getElementById('build-buy-panel').classList.contains('open')) {
        if (infoDim) {
          infoDim.classList.remove('open');
          infoDim.style.display = '';
          infoDim.style.visibility = '';
          infoDim.style.pointerEvents = '';
          infoDim.style.zIndex = '';
        }
      }
    }
    function showArmySec(id) {
      document.querySelectorAll('.army-tab').forEach(function (b) {
        b.classList.toggle('active', b.getAttribute('data-army') === id);
      });
      document.getElementById('sec-package').classList.toggle('hidden', id !== 'package');
      document.getElementById('sec-enlist').classList.toggle('hidden', id !== 'enlist');
      document.getElementById('sec-research').classList.toggle('hidden', id !== 'research');
    }
    function unitIconPath(u) {
      return window.WOK_Military ? WOK_Military.unitIcon(u) : '';
    }
    function renderEnlistList() {
      const box = document.getElementById('enlist-list');
      if (!box) return;
      box.innerHTML = '';
      const units = (window.WOK && WOK.listUnits) ? WOK.listUnits() : [];
      units.forEach(function (u) {
        if (!u || !WOK_Military.isUnlocked(world, u.identifier)) return;
        const card = document.createElement('div');
        card.className = 'build-card';
        const img = document.createElement('img');
        img.src = unitIconPath(u);
        const nm = document.createElement('div');
        nm.className = 'bn';
        nm.textContent = u.name ? (u.name[settings.lang] || u.name.en) : u.identifier;
        const q = document.createElement('div');
        q.className = 'bq';
        // total owned across regions
        let total = 0;
        const g = WOK_Military.ensure(world);
        Object.keys(g.regionArmies).forEach(function (rk) {
          const slot = g.regionArmies[rk][u.identifier];
          if (slot) total += slot.count || 0;
        });
        q.textContent = (tKey("owned_2", "Owned: ")) + total;
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'menu-btn ok';
        btn.textContent = tKey("enlistment_2", "Enlistment");
        btn.addEventListener('click', function () { openEnlistDetail(u.identifier); });
        card.appendChild(img);
        card.appendChild(nm);
        card.appendChild(q);
        card.appendChild(btn);
        box.appendChild(card);
      });
    }
    function showArmyFundsToast(msg) {
      const el = document.getElementById('army-funds-toast');
      if (!el) return;
      el.textContent = msg;
      el.classList.add('show');
      clearTimeout(showArmyFundsToast._t);
      showArmyFundsToast._t = setTimeout(function () {
        el.classList.remove('show');
      }, 3000);
    }
    function renderPackageList() {
      const box = document.getElementById('package-list');
      if (!box) return;
      box.innerHTML = '';
      const g = WOK_Military.ensure(world);
      const pkg = g.package || {};
      const ids = Object.keys(pkg).filter(function (id) { return pkg[id] > 0; });
      if (!ids.length) {
        box.innerHTML = '<div class="sheet-meta">' +
          (tKey("package_empty_2", "Package empty")) + '</div>';
        return;
      }
      ids.forEach(function (id) {
        const u = WOK.getUnit(id);
        const card = document.createElement('div');
        card.className = 'build-card';
        const rm = document.createElement('button');
        rm.type = 'button';
        rm.className = 'pkg-remove';
        rm.setAttribute('aria-label', 'remove');
        rm.textContent = '×';
        rm.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          if (window.WOK_Military && WOK_Military.removeFromPackage) {
            WOK_Military.removeFromPackage(world, id);
            persistWorld(world);
            renderPackageList();
          }
        });
        const img = document.createElement('img');
        img.src = unitIconPath(u);
        const nm = document.createElement('div');
        nm.className = 'bn';
        nm.textContent = u && u.name ? (u.name[settings.lang] || u.name.en) : id;
        const q = document.createElement('div');
        q.className = 'bq';
        q.textContent = '× ' + pkg[id];
        card.appendChild(rm);
        card.appendChild(img);
        card.appendChild(nm);
        card.appendChild(q);
        box.appendChild(card);
      });
    }
    function renderTrainQueue() {
      const box = document.getElementById('train-queue-list');
      const title = document.getElementById('train-queue-title');
      if (!box) return;
      box.innerHTML = '';
      if (!window.WOK_Military) return;
      const g = WOK_Military.ensure(world);
      const q = g.trainQueue || {};
      const keys = Object.keys(q).filter(function (k) { return q[k] && q[k].remaining > 0; });
      if (title) {
        title.textContent = tKey("training_queue_2", "Training queue");
        title.style.display = keys.length ? '' : 'none';
      }
      if (!keys.length) {
        box.innerHTML = '<div class="sheet-meta">' +
          (tKey("no_units_training_2", "No units training")) + '</div>';
        return;
      }
      const now = Date.now();
      keys.forEach(function (key) {
        const job = q[key];
        const unitId = job.unitId || key;
        const u = WOK.getUnit(unitId);
        const row = document.createElement('div');
        row.className = 'ratio-row';
        const img = document.createElement('img');
        img.src = WOK_Military.unitIcon(u);
        const nm = document.createElement('div');
        nm.className = 'rn';
        nm.textContent = u && u.name ? (u.name[settings.lang] || u.name.en) : unitId;
        const meta = document.createElement('div');
        meta.style.cssText = 'font-size:12px;font-weight:700;color:#f0d060;flex:1;';
        const leftMs = Math.max(0, (job.endsAt || now) - now);
        const leftMin = Math.ceil(leftMs / 60000);
        let regLabel = '';
        if (job.regionKey != null) {
          regLabel = ' · R' + job.regionKey;
          try {
            const r = engine && engine.regionByKey && engine.regionByKey.get(String(job.regionKey));
            if (r) {
              const nm = (typeof regionDisplayName === 'function')
                ? regionDisplayName(r)
                : (r.displayName || r.name);
              if (nm) regLabel += ' ' + nm;
            }
          } catch (_) {}
        }
        meta.textContent = '×' + job.remaining + ' · ~' + leftMin +
          (tKey("m_2", "m")) + regLabel;
        row.appendChild(img);
        row.appendChild(nm);
        row.appendChild(meta);
        box.appendChild(row);
      });
    }

    function researchIconPath(r) {
      if (!r) return '';
      let rel = r.icon || r.texture || '';
      if (!rel) return '';
      if (rel.indexOf('..') === 0) return rel.replace(/^\.\.\//, '');
      if (rel.indexOf('research/') === 0 || rel.indexOf('units/') === 0) return rel;
      return 'research/' + rel;
    }
    function renderResearchList() {
      const box = document.getElementById('research-list');
      if (!box) return;
      box.innerHTML = '';
      const list = (WOK.listResearchMilitary && WOK.listResearchMilitary()) || [];
      const g = WOK_Military.ensure(world);
      const byNode = {};
      const byId = {};
      list.forEach(function (r) {
        byId[r.identifier] = r;
        if (r.nodeId) byNode[r.nodeId] = r;
      });

      // Graphical layout (x,y in 720×420 tree space) — branches as a real tree
      // root ──┬── a1 (powder)
      //        ├── b1 (naval) ──┬── b2 (sub)
      //        │                └── bc1 (carrier, AND with c1)
      //        └── c1 (aviation) ──┬── cb1/bc1 carrier
      //                            └── c2 (sky ghost)
      const layout = {
        root: { x: 90, y: 210 },
        a1:   { x: 260, y: 70 },
        b1:   { x: 260, y: 210 },
        c1:   { x: 260, y: 350 },
        b2:   { x: 430, y: 140 },
        bc1:  { x: 520, y: 260 },
        c2:   { x: 430, y: 380 }
      };

      // Edges: parent nodeId → child nodeId (visual branches)
      const edges = [
        ['root', 'a1'],
        ['root', 'b1'],
        ['root', 'c1'],
        ['b1', 'b2'],
        ['b1', 'bc1'],
        ['c1', 'bc1'], // AND merge into carrier
        ['c1', 'c2']
      ];

      const svgNS = 'http://www.w3.org/2000/svg';
      const svg = document.createElementNS(svgNS, 'svg');
      svg.setAttribute('class', 'rt-lines');
      svg.setAttribute('viewBox', '0 0 720 420');

      function elbow(x1, y1, x2, y2) {
        const mx = (x1 + x2) / 2;
        return 'M ' + x1 + ' ' + y1 + ' C ' + mx + ' ' + y1 + ', ' + mx + ' ' + y2 + ', ' + x2 + ' ' + y2;
      }

      edges.forEach(function (e) {
        const a = layout[e[0]], b = layout[e[1]];
        if (!a || !b) return;
        const path = document.createElementNS(svgNS, 'path');
        path.setAttribute('d', elbow(a.x, a.y, b.x, b.y));
        path.setAttribute('fill', 'none');
        path.setAttribute('stroke', 'rgba(100,170,230,0.55)');
        path.setAttribute('stroke-width', '2.5');
        path.setAttribute('stroke-linecap', 'round');
        svg.appendChild(path);
      });
      // AND marker near carrier merge
      if (layout.bc1) {
        const badge = document.createElement('div');
        badge.className = 'rt-and-badge';
        badge.textContent = 'AND';
        badge.style.left = (layout.bc1.x - 40) + 'px';
        badge.style.top = (layout.bc1.y - 36) + 'px';
        box.appendChild(badge);
      }
      box.appendChild(svg);

      // Map nodeId → research row
      const nodeOrder = ['root', 'a1', 'b1', 'c1', 'b2', 'bc1', 'c2'];
      nodeOrder.forEach(function (nid) {
        const r = byNode[nid];
        const pos = layout[nid];
        if (!r || !pos) return;
        const done = !!g.researchDone[r.identifier];
        const queued = !!g.researchQueue[r.identifier];
        const can = WOK_Military.canStartResearch(world, r.identifier);
        const el = document.createElement('div');
        el.className = 'rt-node';
        if (done) el.classList.add('done');
        else if (queued) el.classList.add('queued');
        else if (can) el.classList.add('available');
        else el.classList.add('locked');
        el.style.left = pos.x + 'px';
        el.style.top = pos.y + 'px';

        const disc = document.createElement('div');
        disc.className = 'rt-disc';
        const img = document.createElement('img');
        img.src = researchIconPath(r);
        img.alt = '';
        disc.appendChild(img);

        const label = document.createElement('div');
        label.className = 'rt-label';
        label.textContent = r.name ? (r.name[settings.lang] || r.name.en) : r.identifier;

        const st = document.createElement('div');
        st.className = 'rt-state';
        if (done) st.textContent = tKey("done_2", "Done");
        else if (queued) st.textContent = tKey("str", "…");
        else if (can) st.textContent = tKey("open_2", "Open");
        else st.textContent = tKey("locked_2", "Locked");

        el.appendChild(disc);
        el.appendChild(label);
        el.appendChild(st);
        if (can && !done && !queued) {
          el.addEventListener('click', function () { openResearchBuy(r.identifier); });
        } else if (done || queued) {
          el.addEventListener('click', function () {
            showMapHint(r.name ? (r.name[settings.lang] || r.name.en) : r.identifier);
          });
        }
        box.appendChild(el);
      });
    }

    
    // ── News system ──
    function processNewsFlags() {
      if (!window.WOK_News || !window.WOK_Military) return;
      const g = WOK_Military.ensure(world);
      const lang = (window.WOK_I18N && WOK_I18N.normalizeLang) ? WOK_I18N.normalizeLang(settings.lang) : (settings.lang || 'ar');
      // Battles: start / win / lose / annex
      (g.battles || []).forEach(function (b) {
        if (b._newsStart) {
          WOK_News.reportAttack(world, engine, b.attacker, b.defender, b.region, lang);
          b._newsStart = false;
        }
        if (b._newsWin) {
          WOK_News.onBattleWin(world, engine, b.attacker, b.defender, b.region, lang);
          b._newsWin = false;
        }
        if (b._newsLose) {
          WOK_News.onBattleLose(world, engine, b.attacker, b.defender, b.region, lang);
          b._newsLose = false;
        }
        if (b._newsAnnex) {
          WOK_News.onAnnex(world, engine, b.attacker, b.defender, b.region, lang);
          b._newsAnnex = false;
        }
      });
      // Also scan recently finished lost battles still in array - handled above
      updateNewsBadge();
    }

    let newsChannel = 'public'; // public | private

    function updateNewsBadge() {
      const badge = document.getElementById('news-badge');
      if (!badge || !window.WOK_News) return;
      const n = WOK_News.list(world, 'public').length + WOK_News.list(world, 'private').length;
      badge.textContent = n > 99 ? '99+' : String(n);
      badge.classList.toggle('show', n > 0);
    }

    function showNewsDetail(item) {
      const detail = document.getElementById('news-detail');
      const list = document.getElementById('news-list');
      if (!detail || !item) return;
      document.getElementById('news-detail-title').textContent = item.title || '';
      document.getElementById('news-detail-body').textContent = item.body || '';
      const back = document.getElementById('btn-news-detail-back');
      if (back) back.textContent = tKey("back_to_list", "← Back to list");
      const wbtn = document.getElementById('btn-news-withdraw');
      if (wbtn) {
        const canW = item.meta && item.meta.withdraw && item.meta.battleId;
        wbtn.style.display = canW ? '' : 'none';
        wbtn.textContent = tKey("withdraw_forces_2", "Withdraw forces");
        wbtn.onclick = function () {
          if (!item.meta || !item.meta.battleId) return;
          if (window.WOK_Military) {
            const wd = WOK_Military.withdrawBattle(world, item.meta.battleId);
            try { reapplyContestBorders(false); } catch (_) {}
            if (wd) {
              try {
                if (wd.region && engine && engine.clearRegionStyle) engine.clearRegionStyle(wd.region);
                if (window._wokRedRegions && wd.region) delete window._wokRedRegions[wd.region];
                if (engine && engine.setMilitaryMoves) engine.setMilitaryMoves(WOK_Military.activeMoves(world) || []);
              } catch (_) {}
              persistWorld(world);
              hideNewsDetail();
              renderNewsList();
              updateNewsBadge();
              showMapHint(tKey("forces_withdrawing_2", "Forces withdrawing…"));
            }
          }
        };
      }
      if (list) list.style.display = 'none';
      detail.classList.add('open');
      try { detail.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (_) {}
    }
    function hideNewsDetail() {
      const detail = document.getElementById('news-detail');
      const list = document.getElementById('news-list');
      if (detail) detail.classList.remove('open');
      if (list) list.style.display = '';
      const wbtn = document.getElementById('btn-news-withdraw');
      if (wbtn) wbtn.style.display = 'none';
    }
    function renderNewsList() {
      const list = document.getElementById('news-list');
      const meta = document.getElementById('news-meta');
      if (!list || !window.WOK_News) return;
      hideNewsDetail();
      const items = WOK_News.list(world, newsChannel);
      meta.textContent = isEnUi()
        ? (items.length + (newsChannel === 'private' ? ' force reports' : ' world reports'))
        : (items.length + (newsChannel === 'private' ? ' من قواتك' : ' عامة'));
      list.innerHTML = '';
      if (!items.length) {
        list.innerHTML = '<div class="sheet-meta">' +
          ( bagLang().no_news || (tKey("no_news_yet", "No news yet")) ) + '</div>';
        return;
      }
      items.forEach(function (item) {
        const row = document.createElement('div');
        row.className = 'news-item';
        const body = document.createElement('div');
        body.className = 'ni-body';
        const title = document.createElement('div');
        title.className = 'ni-title';
        title.textContent = item.title;
        const time = document.createElement('div');
        time.className = 'ni-time';
        const ago = Math.max(0, Math.floor((Date.now() - item.at) / 60000));
        time.textContent = ago < 1
          ? (tKey("just_now_2", "Just now"))
          : (ago + (tKey("min_ago_2", " min ago")));
        body.appendChild(title);
        body.appendChild(time);
        const del = document.createElement('button');
        del.type = 'button';
        del.className = 'ni-del';
        del.textContent = '×';
        del.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          WOK_News.remove(world, item.id);
          persistWorld(world);
          renderNewsList();
          updateNewsBadge();
        });
        row.addEventListener('click', function (e) {
          if (e.target === del || del.contains(e.target)) return;
          showNewsDetail(item);
        });
        row.appendChild(body);
        row.appendChild(del);
        list.appendChild(row);
      });
    }

    function openNewsPanel() {
      closeCountryInfo();
      closeMarket();
      if (typeof closeBuildsPanel === 'function') closeBuildsPanel();
      if (typeof closeArmyPanel === 'function') closeArmyPanel();
      const tt = bagLang();
      document.getElementById('news-title').textContent = tt.news || (tKey("news_2", "News"));
      const tp = document.getElementById('tab-news-public');
      const tpr = document.getElementById('tab-news-private');
      if (tp) tp.textContent = tt.news_public || (tKey("public", "Public"));
      if (tpr) tpr.textContent = tt.news_private || (tKey("your_forces", "Your forces"));
      const nc = document.getElementById('btn-news-clear');
      if (nc) nc.title = tt.clear_all || (tKey("delete_all", "Delete all"));
      renderNewsList();
      forcePanelOpen(document.getElementById('news-panel'), true, 120);
      if (infoDim) {
        infoDim.classList.add('open');
        infoDim.style.display = 'block';
        infoDim.style.visibility = 'visible';
        infoDim.style.pointerEvents = 'auto';
        infoDim.style.zIndex = '100';
      }
    }
    function closeNewsPanel() {
      forcePanelOpen(document.getElementById('news-panel'), false);
      hideNewsDetail();
      if (!countryInfo.classList.contains('open') &&
          !document.getElementById('market-panel').classList.contains('open') &&
          !document.getElementById('builds-panel').classList.contains('open') &&
          !document.getElementById('army-panel').classList.contains('open') &&
          !document.getElementById('move-sheet').classList.contains('open') &&
          !document.getElementById('region-army-sheet').classList.contains('open')) {
        if (infoDim) {
          infoDim.classList.remove('open');
          infoDim.style.display = '';
          infoDim.style.visibility = '';
          infoDim.style.pointerEvents = '';
          infoDim.style.zIndex = '';
        }
      }
    }

    document.getElementById('btn-news-fab').addEventListener('click', function (e) {
      try { e.stopPropagation(); } catch (_) {}
      if (paused) return;
      try {
        // clear stuck dim from other panels so FAB always works
        openNewsPanel();
      } catch (err) {
        console.warn('openNewsPanel', err);
        try { document.getElementById('news-panel').classList.add('open'); } catch (_) {}
        try { infoDim.classList.add('open'); } catch (_) {}
      }
    });
    document.getElementById('btn-news-close').addEventListener('click', function () {
      closeNewsPanel();
      infoDim.classList.remove('open');
    });
    const btnNewsClear = document.getElementById('btn-news-clear');
    if (btnNewsClear) {
      btnNewsClear.addEventListener('click', function (e) {
        e.stopPropagation();
        openClearConfirm('news');
      });
    }

    document.getElementById('btn-news-detail-back').addEventListener('click', function () {
      hideNewsDetail();
    });
    document.getElementById('tab-news-public').addEventListener('click', function () {
      newsChannel = 'public';
      document.getElementById('tab-news-public').classList.add('active');
      document.getElementById('tab-news-private').classList.remove('active');
      renderNewsList();
    });
    document.getElementById('tab-news-private').addEventListener('click', function () {
      newsChannel = 'private';
      document.getElementById('tab-news-private').classList.add('active');
      document.getElementById('tab-news-public').classList.remove('active');
      renderNewsList();
    });

    function openArmyPanel() {
      closeMarket();
      closeBuildsPanel();
      closeBuildBuyPanel();
      closeCountryInfo();
      document.getElementById('army-title').textContent = tKey("army_2", "Army");
      document.getElementById('tab-package').textContent = tKey("your_package_2", "Your package");
      document.getElementById('tab-enlist').textContent = tKey("enlistment_3", "Enlistment");
      document.getElementById('tab-research').textContent = tKey("research_tree_2", "Research tree");
      document.getElementById('btn-enlist-map').textContent = tKey("enlistment_4", "Enlistment");
      renderPackageList();
      renderTrainQueue();
      renderEnlistList();
      renderResearchList();
      showArmySec('package');
      forcePanelOpen(document.getElementById('army-panel'), true, 120);
      if (infoDim) {
        infoDim.classList.add('open');
        infoDim.style.display = 'block';
        infoDim.style.visibility = 'visible';
        infoDim.style.pointerEvents = 'auto';
        infoDim.style.zIndex = '100';
      }
    }
    function renderEnlistCost(id) {
      const u = WOK.getUnit(id);
      if (!u) return;
      const row = document.getElementById('enlist-cost-row');
      const raw = document.getElementById('inp-enlist-qty').value;
      const qty = raw === '' ? 0 : Math.max(0, Math.floor(Number(raw) || 0));
      const mult = qty < 1 ? 1 : qty; // preview
      row.innerHTML = '<span class="label">' + (tKey("total_cost_2", "Total cost")) + '</span>';
      const cost = u.cost || {};
      Object.keys(cost).forEach(function (resId) {
        const item = WOK.getItem(resId);
        const chip = document.createElement('span');
        chip.className = 'cost-chip';
        const img = document.createElement('img');
        img.src = itemIconPath(item);
        chip.appendChild(img);
        chip.appendChild(document.createTextNode(String(Number(cost[resId]) * mult)));
        row.appendChild(chip);
      });
    }
    function openEnlistDetail(id) {
      const u = WOK.getUnit(id);
      if (!u) return;
      document.getElementById('enlist-detail-name').textContent =
        u.name ? (u.name[settings.lang] || u.name.en) : id;
      const isBarracks = window.WOK_Military && WOK_Military.isFixedUnit && WOK_Military.isFixedUnit(id);
      document.getElementById('enlist-detail-meta').textContent =
        (u.description ? (u.description[settings.lang] || u.description.en) : '') +
        (isBarracks
          ? (tKey("fixed_structure_1000_soldiers", " · Fixed structure · +1000 soldiers"))
          : (' · power ' + (u.power || 0) + ' · crew ' + (u.soldiersPerUnit || 0)));
      const inp = document.getElementById('inp-enlist-qty');
      inp.value = '1';
      inp.oninput = function () { renderEnlistCost(id); };
      renderEnlistCost(id);
      document.getElementById('btn-add-package').onclick = function () {
        try {
          const raw = document.getElementById('inp-enlist-qty').value;
          const qty = Math.max(1, Math.floor(Number(raw) || 1));
          if (window.WOK_Military && WOK_Military.addToPackage) {
            WOK_Military.addToPackage(world, id, qty);
            persistWorld(world);
          }
          const ed = document.getElementById('enlist-detail-panel');
          if (ed) {
            ed.style.display = 'none';
            ed.style.zIndex = '';
          }
          renderPackageList();
          showArmySec('package');
        } catch (err) {
          console.warn('[army] add package', err);
        }
      };
      const edPanel = document.getElementById('enlist-detail-panel');
      if (edPanel) {
        edPanel.style.display = 'block';
        edPanel.style.visibility = 'visible';
        edPanel.style.pointerEvents = 'auto';
        edPanel.style.zIndex = '130';
      }
    }
    function openResearchBuy(id) {
      const r = WOK.getResearch(id);
      if (!r) return;
      document.getElementById('research-buy-name').textContent =
        r.name ? (r.name[settings.lang] || r.name.en) : id;
      document.getElementById('research-buy-meta').textContent =
        r.description ? (r.description[settings.lang] || r.description.en) : '';
      const row = document.getElementById('research-cost-row');
      row.innerHTML = '<span class="label">' + (tKey("cost_2", "Cost")) + '</span>';
      const cost = r.cost || {};
      Object.keys(cost).forEach(function (resId) {
        const item = WOK.getItem(resId);
        const chip = document.createElement('span');
        chip.className = 'cost-chip';
        const img = document.createElement('img');
        img.src = itemIconPath(item);
        chip.appendChild(img);
        chip.appendChild(document.createTextNode(formatAmount(cost[resId])));
        row.appendChild(chip);
      });
      const days = Number(r.researchTimeGameDays) || 0;
      document.getElementById('research-time-val').textContent =
        formatGameDurationFromRealMinutes((days * 10) / 60); // game days → real minutes display via same formatter
      // Actually researchTimeGameDays is already game days; format directly:
      document.getElementById('research-time-val').textContent =
        formatGameDurationFromRealMinutes(days / 6); // inverse of *6 in formatter... cleaner:
      const y = Math.floor(days / 360), m = Math.floor((days % 360) / 30), d = days % 30;
      const parts = [];
      if (y) parts.push(y + (t.year || 'y'));
      if (m) parts.push(m + (t.month || 'mo'));
      if (d || !parts.length) parts.push(d + (t.day || 'd'));
      document.getElementById('research-time-val').textContent = parts.join(' ');
      document.getElementById('btn-research-start').onclick = function () {
        try {
          if (window.WOK_Military && WOK_Military.startResearch &&
              WOK_Military.startResearch(world, id, getStock, setStock)) {
            persistWorld(world);
            const rp = document.getElementById('research-buy-panel');
            if (rp) {
              rp.style.display = 'none';
              rp.style.zIndex = '';
            }
            renderResearchList();
            renderResBar();
          }
        } catch (err) {
          console.warn('[army] research start', err);
        }
      };
      const rpPanel = document.getElementById('research-buy-panel');
      if (rpPanel) {
        rpPanel.style.display = 'block';
        rpPanel.style.visibility = 'visible';
        rpPanel.style.pointerEvents = 'auto';
        rpPanel.style.zIndex = '130';
      }
    }

    document.getElementById('btn-army-fab').addEventListener('click', function (e) {
      try { e.stopPropagation(); } catch (_) {}
      if (paused) return;
      try {
        openArmyPanel();
      } catch (err) {
        console.warn('openArmyPanel', err);
        try { document.getElementById('army-panel').classList.add('open'); } catch (_) {}
        try { infoDim.classList.add('open'); } catch (_) {}
      }
    });
    document.getElementById('btn-army-close').addEventListener('click', function () {
      closeArmyPanel();
      infoDim.classList.remove('open');
    });
    document.querySelectorAll('.army-tab').forEach(function (b) {
      b.addEventListener('click', function () {
        const sec = b.getAttribute('data-army');
        showArmySec(sec);
        try {
          if (sec === 'enlist') renderEnlistList();
          if (sec === 'research') renderResearchList();
          if (sec === 'package') {
            renderPackageList();
            renderTrainQueue();
          }
        } catch (err) {
          console.warn('[army] tab', sec, err);
        }
      });
    });
    document.getElementById('btn-enlist-map').addEventListener('click', function () {
      const g = WOK_Military.ensure(world);
      if (!Object.keys(g.package || {}).length) {
        showMapHint(tKey("package_empty_2", "Package empty"));
        return;
      }
      closeArmyPanel();
      infoDim.classList.remove('open');
      armyMode = 'enlist_pick';
      showHud(false);
      showMapHint(isEnUi()
        ? 'Long-press your region to train'
        : 'اضغط مطولاً على إقليمك لبدء التدريب');
    });
    document.getElementById('btn-enlist-detail-close').addEventListener('click', function () {
      const ed = document.getElementById('enlist-detail-panel');
      if (ed) {
        ed.style.display = 'none';
        ed.style.zIndex = '';
        ed.style.visibility = '';
        ed.style.pointerEvents = '';
      }
    });
    document.getElementById('btn-research-close').addEventListener('click', function () {
      const rp = document.getElementById('research-buy-panel');
      if (rp) {
        rp.style.display = 'none';
        rp.style.zIndex = '';
        rp.style.visibility = '';
        rp.style.pointerEvents = '';
      }
    });


    (function wireIntentAid() {
      const isheet = document.getElementById('intent-sheet');
      const asheet = document.getElementById('aid-sheet');
      const iclose = document.getElementById('btn-intent-close');
      const aclose = document.getElementById('btn-aid-close');
      const iatk = document.getElementById('btn-intent-attack');
      const iaid = document.getElementById('btn-intent-aid');
      const send = document.getElementById('btn-aid-send');
      function hideI() { if (isheet) { isheet.classList.remove('open'); isheet.style.display = 'none'; } }
      function hideA() { if (asheet) { asheet.classList.remove('open'); asheet.style.display = 'none'; } }
      if (iclose) iclose.onclick = hideI;
      if (aclose) aclose.onclick = hideA;
      if (isheet) isheet.addEventListener('click', function (e) { if (e.target === isheet) hideI(); });
      if (asheet) asheet.addEventListener('click', function (e) { if (e.target === asheet) hideA(); });
      if (iatk) {
        iatk.onclick = function (e) {
          if (e) { e.preventDefault(); e.stopPropagation(); }
          const f = intentFrom, t = intentTo;
          hideI();
          if (f && t) {
            try { openMoveRatioSheet(f, t); }
            catch (err) { console.error(err); showMapHint(tKey("move_ui_error_2", "Move UI error")); }
          } else {
            showMapHint(tKey("no_target_2", "No target"));
          }
        };
      }
      if (iaid) {
        iaid.onclick = function (e) {
          if (e) { e.preventDefault(); e.stopPropagation(); }
          const f = intentFrom, t = intentTo, o = intentOwner;
          hideI();
          if (f && t && o) openAidSheet(f, t, o);
        };
      }
      if (send) send.onclick = function () {
        if (!asheet) return;
        const id = document.getElementById('sel-aid-item').value;
        const qty = Math.floor(Number(document.getElementById('rng-aid').value) || 0);
        const owner = asheet.dataset.owner;
        if (!id || qty <= 0 || !owner) return;
        if (getStock(id) < qty) {
          showMapHint(tKey("not_enough_2", "Not enough"));
          return;
        }
        setStock(id, getStock(id) - qty);
        // Relation gain scales with qty (soft)
        const gain = Math.max(1, Math.min(12, Math.round(Math.log10(qty + 1) * 3)));
        // Credit bot stock if present
        try {
          if (window.WOK_Bot && world.game.botStock) {
            if (!world.game.botStock[owner]) world.game.botStock[owner] = {};
            world.game.botStock[owner][id] = (world.game.botStock[owner][id] || 0) + qty;
          }
        } catch (_) {}
        persistWorld(world);
        renderResBar();
        hideA();
        showMapHint((tKey("aid_sent", "Aid sent · +")) + gain + '%');
      };
    })();

    document.getElementById('btn-move-close').addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      closeMoveSheet();
    });
    document.getElementById('btn-region-army-close').addEventListener('click', function () {
      closeRegionArmySheet();
    });
    document.getElementById('btn-move-confirm').addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (!moveFrom || !moveTo) {
        closeMoveSheet();
        return;
      }
      if (!window.WOK_Military) return;
      const ratios = collectMoveRatios();
      let res;
      try {
        res = WOK_Military.startMove(world, engine, moveFrom, moveTo, ratios, getStock, setStock, playerCountry);
      } catch (err) {
        console.error(err);
        showMapHint(tKey("move_failed_2", "Move failed"));
        return;
      }
      // Always close UI after confirm attempt
      closeMoveSheet();
      if (!res || !res.ok) {
        const reasons = {
          not_connected: tKey("regions_not_linked_2", "Regions not linked"),
          air_only: tKey("need_ground_or_naval_units", "Need ground or naval units"),
          no_oil: tKey("not_enough_oil_2", "Not enough oil"),
          nothing: tKey("no_units_2", "No units"),
          need_transport: tKey("need_transport_ships", "Need transport ships"),
          sea_on_land: tKey("ships_cannot_move_over_land", "Ships cannot move over land"),
          no_crew: tKey("not_enough_soldiers_for_crew", "Not enough soldiers for crew"),
          no_army: tKey("no_army_here_2", "No army here")
        };
        showMapHint(reasons[res && res.reason] || (res && res.reason) || (tKey("failed_2", "Failed")));
        return;
      }
      showMapHint(tKey("forces_moving_2", "Forces moving…"));
      try {
        if (engine && engine.setMilitaryMoves && window.WOK_Military) {
          const mv = WOK_Military.activeMoves(world) || [];
          window._wokMoveSig = mv.length + ':' + (mv[0] && mv[0].id || '');
          engine.setMilitaryMoves(mv);
        }
      } catch (_) {}
      persistWorld(world);
      renderResBar();
    });
    document.getElementById('btn-battle-x').addEventListener('click', function () {
      const bar = document.getElementById('battle-bar');
      if (bar) bar.classList.remove('show');
      if (typeof layoutTopBars === 'function') layoutTopBars();
    });
    document.getElementById('btn-battle-withdraw').addEventListener('click', function () {
      const bar = document.getElementById('battle-bar');
      const id = bar && bar.dataset.battleId;
      if (!id) return;
      const wd = WOK_Military.withdrawBattle(world, id);
        try { reapplyContestBorders(false); } catch (_) {}
      if (wd) {
        showMapHint(tKey("forces_withdrawing_2", "Forces withdrawing…"));
        try {
          if (engine && engine.clearRegionStyle && (wd.region || id)) {
            engine.clearRegionStyle(wd.region || (bar && bar.dataset.region));
          }
          // Drop contest/red style on the region after withdraw
          if (wd.region && window._wokRedRegions) delete window._wokRedRegions[wd.region];
          if (engine && engine.clearRegionStyle && wd.region) engine.clearRegionStyle(wd.region);
          try { if (typeof reapplyContestBorders === 'function') reapplyContestBorders(true); } catch (_) {}
        } catch (_) {}
        try {
          if (engine && engine.setMilitaryMoves) {
            engine.setMilitaryMoves(WOK_Military.activeMoves(world) || []);
          }
        } catch (_) {}
        persistWorld(world);
        refreshBattleBar();
        tickEconomy();
      }
    });


    // ── Pause menu ──
    function openPause() {
      paused = true;
      closeCountryInfo();
      document.getElementById('pause-world-name').textContent = (world && world.name) || '—';
      layerPause.classList.remove('hidden');
      layerSettings.classList.add('hidden');
    }
    function closePause() {
      paused = false;
      layerPause.classList.add('hidden');
      layerSettings.classList.add('hidden');
    }

    document.getElementById('btn-menu').addEventListener('click', openPause);
    document.getElementById('btn-resume').addEventListener('click', closePause);

    function showSettingsCat(id) {
      document.querySelectorAll('.settings-cat').forEach(function (b) {
        b.classList.toggle('active', b.getAttribute('data-cat') === id);
      });
      const g = document.getElementById('panel-general');
      const touch = document.getElementById('panel-touch');
      const video = document.getElementById('panel-video');
      if (g) g.classList.toggle('hidden', id !== 'general');
      if (touch) touch.classList.toggle('hidden', id !== 'touch');
      if (video) video.classList.toggle('hidden', id !== 'video');
    }
    function syncIslandsToggleUI() {
      const chk = document.getElementById('chk-hide-islands');
      if (chk) chk.checked = !!settings.hideSmallIslands;
    }

    function applyMapStatsUI() {
      const bar = document.getElementById('date-bar');
      const chk = document.getElementById('chk-map-stats');
      if (chk) chk.checked = !!settings.showMapStats;
      if (bar) bar.classList.toggle('show-perf', !!settings.showMapStats);
      const chkMute = document.getElementById('chk-mute-banners');
      if (chkMute) chkMute.checked = !!settings.muteMapBanners;
    }
    applyMapStatsUI();
    const chkStats = document.getElementById('chk-map-stats');
    if (chkStats) {
      chkStats.addEventListener('change', function () {
        settings.showMapStats = !!chkStats.checked;
        saveSettings(settings);
        applyMapStatsUI();
      });
    }
    const chkMuteB = document.getElementById('chk-mute-banners');
    if (chkMuteB) {
      chkMuteB.addEventListener('change', function () {
        settings.muteMapBanners = !!chkMuteB.checked;
        saveSettings(settings);
        if (settings.muteMapBanners) {
          const el = document.getElementById('map-hint-bar');
          if (el) el.classList.remove('show');
          try { layoutTopBars(); } catch (_) {}
        }
      });
    }
    // keep checkbox in sync when opening video panel
    (function () {
      const m = document.getElementById('chk-mute-banners');
      if (m) m.checked = !!settings.muteMapBanners;
    })();

    try { syncIslandsToggleUI(); } catch (_) {}
    const chkIslands = document.getElementById('chk-hide-islands');
    if (chkIslands) {
      chkIslands.addEventListener('change', function () {
        settings.hideSmallIslands = !!chkIslands.checked;
        saveSettings(settings);
        try {
          if (typeof engine !== 'undefined' && engine && engine.setHideSmallIslands) {
            engine.setHideSmallIslands(settings.hideSmallIslands);
          }
        } catch (_) {}
      });
    }

    function clampDetail(v) {
      v = Math.round(Number(v));
      if (!isFinite(v)) return 32;
      return Math.min(64, Math.max(15, v));
    }
    function syncBorderDetailUI() {
      const bd = clampDetail(settings.countryBorderDetail != null ? settings.countryBorderDetail : 32);
      const rd = clampDetail(settings.regionBorderDetail != null ? settings.regionBorderDetail : 32);
      settings.countryBorderDetail = bd;
      settings.regionBorderDetail = rd;
      const rb = document.getElementById('rng-border-detail');
      const rr = document.getElementById('rng-region-detail');
      const vb = document.getElementById('border-detail-val');
      const vr = document.getElementById('region-detail-val');
      if (rb) rb.value = bd;
      if (rr) rr.value = rd;
      if (vb) vb.textContent = String(bd);
      if (vr) vr.textContent = String(rd);
    }
    function applyBorderDetailsToEngine() {
      if (typeof engine === 'undefined' || !engine) return;
      try {
        if (engine.setCountryBorderDetail) engine.setCountryBorderDetail(settings.countryBorderDetail);
        if (engine.setRegionBorderDetail) engine.setRegionBorderDetail(settings.regionBorderDetail);
      } catch (e) { console.warn('border detail', e); }
    }
    try { syncBorderDetailUI(); } catch (_) {}
    const rngBorder = document.getElementById('rng-border-detail');
    if (rngBorder) {
      rngBorder.addEventListener('input', function () {
        const v = clampDetail(rngBorder.value);
        settings.countryBorderDetail = v;
        const vb = document.getElementById('border-detail-val');
        if (vb) vb.textContent = String(v);
        saveSettings(settings);
        if (typeof engine !== 'undefined' && engine && engine.setCountryBorderDetail) {
          engine.setCountryBorderDetail(v);
        }
      });
    }
    const rngRegion = document.getElementById('rng-region-detail');
    if (rngRegion) {
      rngRegion.addEventListener('input', function () {
        const v = clampDetail(rngRegion.value);
        settings.regionBorderDetail = v;
        const vr = document.getElementById('region-detail-val');
        if (vr) vr.textContent = String(v);
        saveSettings(settings);
        if (typeof engine !== 'undefined' && engine && engine.setRegionBorderDetail) {
          engine.setRegionBorderDetail(v);
        }
      });
    }

    document.getElementById('settings-cats').addEventListener('click', function (e) {
      const b = e.target.closest('.settings-cat');
      if (!b) return;
      showSettingsCat(b.getAttribute('data-cat'));
    });

    document.getElementById('btn-game-settings').addEventListener('click', function () {
      layerPause.classList.add('hidden');
      layerSettings.classList.remove('hidden');
      // Force reload selected options from saved settings (not HTML default index 0)
      try {
        var langSel = document.getElementById('sel-lang');
        var orientSel = document.getElementById('sel-orient');
        var wantLang = (window.WOK_I18N && WOK_I18N.normalizeLang)
          ? WOK_I18N.normalizeLang(settings.lang)
          : (settings.lang || 'ar');
        settings.lang = wantLang;
        if (langSel) {
          langSel.value = wantLang;
          // if browser ignored unknown value, set selectedIndex manually
          if (langSel.value !== wantLang) {
            for (var i = 0; i < langSel.options.length; i++) {
              if (langSel.options[i].value === wantLang) {
                langSel.selectedIndex = i;
                break;
              }
            }
          }
        }
        if (orientSel) {
          orientSel.value = settings.orient === 'landscape' ? 'landscape' : 'portrait';
        }
      } catch (_) {}
      const panV = settings.panSensitivity != null ? settings.panSensitivity : settings.sensitivity;
      const zoomV = settings.zoomSensitivity != null ? settings.zoomSensitivity : settings.sensitivity;
      const elPan = document.getElementById('rng-sens-pan') || document.getElementById('rng-sens');
      const elZoom = document.getElementById('rng-sens-zoom');
      const valPan = document.getElementById('sens-pan-val') || document.getElementById('sens-val');
      const valZoom = document.getElementById('sens-zoom-val');
      if (elPan) elPan.value = panV;
      if (valPan) valPan.textContent = Number(panV).toFixed(2);
      if (elZoom) elZoom.value = zoomV;
      if (valZoom) valZoom.textContent = Number(zoomV).toFixed(2);
      try { syncBorderDetailUI(); } catch (_) {}
      showSettingsCat('general');
    });
    document.getElementById('btn-settings-back').addEventListener('click', function () {
      layerSettings.classList.add('hidden');
      layerPause.classList.remove('hidden');
    });

    document.getElementById('btn-save-quit').addEventListener('click', function () {
      if (world) persistWorld(world);
      // always return using saved default orientation
      const orient = settings.orient === 'landscape' ? 'landscape' : 'portrait';
      rememberOrient(orient);
      location.href = 'main.html?worlds=1&orient=' + encodeURIComponent(orient);
    });

    // Settings controls
    document.getElementById('sel-lang').addEventListener('change', function (e) {
      var v = e.target.value;
      settings.lang = (window.WOK_I18N && WOK_I18N.normalizeLang) ? WOK_I18N.normalizeLang(v) : (v === 'en' || v === 'tr' ? v : 'ar');
      if (window.WOK_I18N && WOK_I18N.setLang) WOK_I18N.setLang(settings.lang);
      try { if (window.WOK_Settings && WOK_Settings.save) WOK_Settings.save(settings); else localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch (_) {}
      try {
        if (window.WOK_I18N && WOK_I18N.applyScene) WOK_I18N.applyScene(settings.lang);
        if (typeof applyI18n === 'function') applyI18n();
      } catch (_) {}
    });
    document.getElementById('sel-orient').addEventListener('change', async function (e) {
      settings.orient = e.target.value === 'portrait' ? 'portrait' : 'landscape';
      try { if (window.WOK_Settings && WOK_Settings.save) WOK_Settings.save(settings); else localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch (_) {}
      rememberOrient(settings.orient, true);
      try { await tryLock(settings.orient); } catch (_) {}
      try {
        orientLocked = settings.orient === 'landscape';
        if (btnOrient) {
          btnOrient.classList.toggle('active', orientLocked);
          btnOrient.textContent = orientLocked ? (t.orientAlt || t.orient) : (t.orient || '⟳');
        }
        document.documentElement.setAttribute('data-wok-orient', settings.orient);
        setTimeout(refitMap, 100);
      } catch (_) {}
    });
    function bindSensSlider(rngId, valId, key, applyFn) {
      const el = document.getElementById(rngId);
      if (!el) return;
      el.addEventListener('input', function () {
        let v = Number(el.value);
        if (!isFinite(v)) v = 1;
        v = Math.max(0.5, Math.min(2, v));
        const lab = document.getElementById(valId);
        if (lab) lab.textContent = v.toFixed(2);
        settings[key] = v;
        // keep legacy field = pan for old saves that only read sensitivity
        if (key === 'panSensitivity') settings.sensitivity = v;
        saveSettings(settings);
        if (applyFn) applyFn(v);
      });
    }
    bindSensSlider('rng-sens-pan', 'sens-pan-val', 'panSensitivity', function (v) {
      if (engine.setPanSensitivity) engine.setPanSensitivity(v);
    });
    bindSensSlider('rng-sens-zoom', 'sens-zoom-val', 'zoomSensitivity', function (v) {
      if (engine.setZoomSensitivity) engine.setZoomSensitivity(v);
    });
    // legacy single slider if still in DOM
    bindSensSlider('rng-sens', 'sens-val', 'panSensitivity', function (v) {
      if (engine.setPanSensitivity) engine.setPanSensitivity(v);
    });

    // ── Orientation ──
    // Default orientation = force this mode on every screen (COC landscape / CR portrait)
    async function tryLock(mode) {
      try {
        const el = document.documentElement;
        if (el.requestFullscreen) await el.requestFullscreen();
        else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen();
        if (screen.orientation && screen.orientation.lock) {
          await screen.orientation.lock(mode);
          orientLocked = (mode === 'landscape');
          btnOrient.classList.toggle('active', orientLocked);
          btnOrient.textContent = orientLocked ? t.orientAlt : t.orient;
          rememberOrient(mode);
          setTimeout(refitMap, 160);
          return true;
        }
      } catch (e) {
        console.warn('orientation lock failed', e);
      }
      return false;
    }
    async function forceOrient(mode) {
      const want = mode === 'landscape' ? 'landscape' : 'portrait';
      rememberOrient(want);
      if (want === 'landscape') {
        await tryLock('landscape');
      } else {
        try {
          if (screen.orientation && screen.orientation.lock) {
            const el = document.documentElement;
            if (!document.fullscreenElement && el.requestFullscreen) await el.requestFullscreen();
            await screen.orientation.lock('portrait');
            orientLocked = false;
            btnOrient.classList.remove('active');
            btnOrient.textContent = t.orient;
            setTimeout(refitMap, 160);
          }
        } catch (_) {}
      }
    }
    async function applyDefaultOrient(force) {
      const want = (settings && settings.orient === 'portrait') ? 'portrait'
        : (settings && settings.orient === 'landscape') ? 'landscape'
        : (readSavedOrient() || 'landscape');
      rememberOrient(want, false);
      try {
        if (typeof lockOrientNow === 'function') await lockOrientNow(want);
        else await tryLock(want);
      } catch (e) {
        console.warn('applyDefaultOrient', e);
      }
      // R1.4: always sync UI/classes even if lock failed (APK)
      try {
        orientLocked = (want === 'landscape');
        if (btnOrient) {
          btnOrient.classList.toggle('active', orientLocked);
          btnOrient.textContent = orientLocked ? (t.orientAlt || t.orient) : (t.orient || '⟳');
        }
        document.documentElement.setAttribute('data-wok-orient', want);
      } catch (_) {}
      try { setTimeout(refitMap, 100); } catch (_) {}
    }
    /** R1.4: apply orient even when screen.orientation.lock is unavailable (APK WebView) */
    function applyOrientUi(mode) {
      var want = mode === 'portrait' ? 'portrait' : 'landscape';
      settings.orient = want;
      try { saveSettings(settings); } catch (_) {}
      rememberOrient(want, true);
      orientLocked = (want === 'landscape');
      if (btnOrient) {
        btnOrient.classList.toggle('active', orientLocked);
        var bag = t || {};
        btnOrient.textContent = orientLocked ? (bag.orientAlt || bag.orient_btn_alt || '⟳ طولي') : (bag.orient || bag.orient_btn || '⟳ عرض');
      }
      try {
        document.documentElement.setAttribute('data-wok-orient', want);
        document.body.classList.toggle('wok-prefer-landscape', want === 'landscape');
        document.body.classList.toggle('wok-prefer-portrait', want === 'portrait');
      } catch (_) {}
      setTimeout(refitMap, 80);
      setTimeout(refitMap, 200);
    }
    function physicalMatches(want) {
      try {
        if (window.matchMedia) {
          if (want === 'landscape' && window.matchMedia('(orientation: landscape)').matches) return true;
          if (want === 'portrait' && window.matchMedia('(orientation: portrait)').matches) return true;
        }
        if (want === 'landscape') return window.innerWidth >= window.innerHeight;
        return window.innerHeight > window.innerWidth;
      } catch (_) { return true; }
    }
    btnOrient.addEventListener('click', async function () {
      var next = orientLocked || (settings.orient === 'landscape') ? 'portrait' : 'landscape';
      var ok = false;
      try { ok = await tryLock(next); } catch (_) { ok = false; }
      // Always apply app-level orient (WebView often cannot lock)
      applyOrientUi(next);
      if (!ok && !physicalMatches(next)) {
        // Soft hint only if device is still the wrong way
        if (btnOrient) {
          btnOrient.textContent = (t && (t.rotateHint || t.rotate_hint)) || '↻';
          setTimeout(function () {
            applyOrientUi(settings.orient === 'portrait' ? 'portrait' : 'landscape');
          }, 1800);
        }
      }
    });
    window.addEventListener('resize', function () { setTimeout(refitMap, 80); });
    window.addEventListener('orientationchange', function () { setTimeout(refitMap, 160); });

    
    
    // Click outside sheet/panel content closes it
    (function setupOutsideClose() {
      function closeEl(el) {
        if (!el) return;
        el.classList.remove('open');
      }
      [
        'market-panel', 'builds-panel', 'build-buy-panel', 'army-panel',
        'news-panel', 'alerts-sheet', 'region-army-sheet', 'move-sheet'
      ].forEach(function (id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('click', function (e) {
          if (e.target !== el) return;
          closeEl(el);
          if (id === 'news-panel') { try { closeNewsPanel(); } catch (_) {} }
          if (id === 'market-panel') { try { closeMarket(); } catch (_) {} }
          if (id === 'builds-panel') { try { closeBuildsPanel(); } catch (_) {} }
          if (id === 'build-buy-panel') { try { closeBuildBuyPanel(); } catch (_) {} }
        });
      });
      const infoDim = document.getElementById('info-dim');
      if (infoDim) {
        infoDim.addEventListener('click', function () {
          try { closeCountryInfo(); } catch (_) {}
          try { closeMarket(); } catch (_) {}
          try { closeBuildsPanel(); } catch (_) {}
          try { closeBuildBuyPanel(); } catch (_) {}
          try { closeArmyPanel(); } catch (_) {}
          try { closeNewsPanel(); } catch (_) {}
          try { closeMoveSheet(); } catch (_) {}
          try { closeRegionArmySheet(); } catch (_) {}
          closeEl(document.getElementById('army-panel'));
          closeEl(document.getElementById('news-panel'));
          closeEl(document.getElementById('region-army-sheet'));
          closeEl(document.getElementById('move-sheet'));
        });
      }
      // Settings / pause layers: click backdrop (not card) closes
      ['layer-settings', 'layer-pause'].forEach(function (id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('click', function (e) {
          if (e.target !== el) return;
          el.classList.add('hidden');
          if (id === 'layer-pause') {
            // CRITICAL: closing pause overlay must unpause or FABs stay dead
            try { paused = false; } catch (_) {}
          }
          if (id === 'layer-settings') {
            try {
              document.getElementById('layer-pause').classList.remove('hidden');
            } catch (_) {}
          }
        });
      });
    })();

    
    // PER: pause heavy work when tab hidden
    document.addEventListener('visibilitychange', function () {
      try {
        if (document.hidden) {
          window._wokTabHidden = true;
          if (engine && engine.setPaused) engine.setPaused(true);
        } else {
          window._wokTabHidden = false;
          if (engine && engine.setPaused) engine.setPaused(false);
          if (engine && engine.setDirty) engine.setDirty();
        }
      } catch (_) {}
    });

    window.mapEngine = engine;
    window.wokWorld = world;
    window.wokSettings = settings;
  })();
