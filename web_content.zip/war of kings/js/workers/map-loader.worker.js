/**
 * map-loader.worker.js — PER-1.4.3
 * Web Worker: fetch + JSON.parse for map region data only.
 * In:  { type:'loadRegions', requestId, url }
 * Out: { type:'ok', requestId, data } | { type:'error', requestId, message }
 */
'use strict';
self.onmessage = async function (ev) {
  var msg = ev.data || {};
  var id = msg.requestId;
  try {
    if (msg.type !== 'loadRegions') {
      self.postMessage({ type: 'error', requestId: id, message: 'unknown type' });
      return;
    }
    var url = msg.url || 'data/regions.json';
    var res = await fetch(url, { credentials: 'same-origin' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    var data = await res.json();
    self.postMessage({ type: 'ok', requestId: id, data: data });
  } catch (e) {
    self.postMessage({ type: 'error', requestId: id, message: String(e && e.message || e) });
  }
};
