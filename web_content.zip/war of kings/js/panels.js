/**
 * WOK Panels — centralized open/close + backdrop handling
 * PER-1.4.0: extract panel lifecycle from game.js
 */
(function (global) {
  'use strict';

  var closers = [];

  function register(name, fn) {
    if (typeof fn === 'function') {
      closers.push({ name: name, fn: fn });
    }
  }

  function resetDim(el) {
    if (!el) return;
    el.classList.remove('open');
    try {
      el.style.display = '';
      el.style.visibility = '';
      el.style.pointerEvents = '';
      el.style.zIndex = '';
    } catch (_) {}
  }

  function hideSheetById(id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.classList.remove('open');
    if (el.style && el.style.display === 'flex') el.style.display = 'none';
    if (el.style && el.style.display === 'block') el.style.display = 'none';
  }

  /** Close every known panel / sheet and clear shared dim */
  function closeAll() {
    // Registered closers from game.js (preferred)
    for (var i = 0; i < closers.length; i++) {
      try { closers[i].fn(); } catch (_) {}
    }

    // Fallback by id — covers panels that use class "open" or inline display
    var ids = [
      'country-info', 'market-panel', 'builds-panel', 'build-buy-panel',
      'army-panel', 'news-panel', 'news-detail-panel', 'region-army-sheet',
      'move-sheet', 'move-ratio-sheet', 'move-info-sheet',
      'intent-sheet', 'aid-sheet', 'alerts-sheet',
      'enlist-detail-panel', 'research-buy-panel', 'pause-overlay'
    ];
    for (var j = 0; j < ids.length; j++) {
      hideSheetById(ids[j]);
    }

    resetDim(document.getElementById('info-dim'));
  }

  /**
   * Click on a full-screen sheet root (the dim area) closes it when target === currentTarget
   */
  function bindSelfClose(sheetId) {
    var el = document.getElementById(sheetId);
    if (!el || el._wokSelfClose) return;
    el._wokSelfClose = true;
    el.addEventListener('click', function (e) {
      if (e.target === el) {
        el.classList.remove('open');
        if (el.style.display === 'flex' || el.style.display === 'block') {
          el.style.display = 'none';
        }
        // if no other panels need dim, clear it
        var still = document.querySelector(
          '#market-panel.open, #builds-panel.open, #army-panel.open, #news-panel.open, #region-army-sheet.open, #country-info.open, #move-sheet.open'
        );
        if (!still) resetDim(document.getElementById('info-dim'));
      }
    });
  }

  function bindBackdrop(dimId) {
    var dim = document.getElementById(dimId || 'info-dim');
    if (!dim || dim._wokBackdropBound) return;
    dim._wokBackdropBound = true;
    dim.addEventListener('click', function () {
      closeAll();
    });
  }

  function init() {
    bindBackdrop('info-dim');
    bindSelfClose('intent-sheet');
    bindSelfClose('aid-sheet');
    bindSelfClose('move-info-sheet');
    bindSelfClose('alerts-sheet');
    bindSelfClose('move-sheet');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  global.WOK_Panels = {
    register: register,
    closeAll: closeAll,
    resetDim: resetDim,
    bindBackdrop: bindBackdrop,
    bindSelfClose: bindSelfClose,
    init: init
  };
})(typeof window !== 'undefined' ? window : this);
