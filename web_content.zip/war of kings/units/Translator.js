/**
 * War of Kings — Units Translator
 * يقرأ كل ملفات JSON في مجلد units ويحوّلها إلى كائنات جاهزة.
 * يصدّر النتيجة إلى window.WOK_UNITS
 */
(function (global) {
  'use strict';

  const UNITS_PATH = 'units/';
  const FILES = [
    'Barracks.json',
    'artillery.json',
    'tank.json',
    'warship.json',
    'warsubmarine.json',
    'warplanes_carrier.json',
    'warplane.json',
    'B-2_warplane.json'
  ];

  async function loadJSON(path) {
    const res = await fetch(path);
    if (!res.ok) throw new Error('Failed to load ' + path);
    return res.json();
  }

  async function loadAll() {
    const map = Object.create(null);
    const list = [];

    for (const file of FILES) {
      try {
        const data = await loadJSON(UNITS_PATH + file);
        if (!data || !data.identifier) {
          console.warn('[Units] missing identifier in', file);
          continue;
        }
        map[data.identifier] = data;
        list.push(data);
      } catch (err) {
        console.error('[Units] load failed:', file, err);
      }
    }

    list.sort((a, b) => (a.order || 0) - (b.order || 0));

    const byDomain = {
      land: list.filter(u => u.domain === 'land'),
      sea:  list.filter(u => u.domain === 'sea'),
      air:  list.filter(u => u.domain === 'air')
    };

    const result = {
      byId: map,
      list: list,
      byDomain: byDomain,
      basic: list.filter(u => Array.isArray(u.tags) && u.tags.includes('basic')),
      get: function (id) { return map[id] || null; }
    };

    global.WOK_UNITS = result;
    console.log('[Units] loaded', list.length, 'units');
    return result;
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => loadAll().catch(console.error));
    } else {
      loadAll().catch(console.error);
    }
  }

  global.WOK_UnitsTranslator = { loadAll };
})(typeof window !== 'undefined' ? window : globalThis);
