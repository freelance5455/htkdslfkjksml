# UNITS — دليل كتابة ملفات الوحدات

## صيغة المعرف
```
WOK:MILITARY.UNIT.<DOMAIN>.<NAME>
```
أمثلة:
- `WOK:MILITARY.UNIT.LAND.INFANTRY`
- `WOK:MILITARY.UNIT.SEA.CARRIER`
- `WOK:MILITARY.UNIT.AIR.BOMBER_B2`

---

## الحقول الإلزامية

| الحقل | شرح |
|-------|-----|
| `identifier` | المعرف الفريد |
| `type` | دائماً `"unit"` |
| `name` / `description` | كائنات `{en, ar}` |
| `tags` | قائمة وسوم (انظر الأسفل) |
| `domain` | `"land"` \| `"sea"` \| `"air"` |
| `texture` / `icon` | مسار نسبي داخل units/ |
| `cost` | كائن مفاتيحه **معرفات المواد** وليس الأسماء |
| `power` | قوة القتال |
| `oilConsumption` | استهلاك النفط لكل انتقال بين محافظة (مفاتيح معرفات) |
| `transport` | `null` أو كائن سعة النقل |
| `movement` | نوع الحركة والمتطلبات |
| `order` | ترتيب العرض |

---

## الأسعار والاستهلاك — قاعدة ذهبية
```json
"cost": {
  "WOK:ECONOMY.MATERIAL.GOLD.BAR": 500,
  "WOK:ECONOMY.MATERIAL.IRON.INGOT": 1000
},
"oilConsumption": {
  "WOK:ECONOMY.MATERIAL.OIL.BARREL": 5
}
```
**ممنوع** كتابة `"Gold": 5` أو `"نفط": 3`.

---

## استهلاك النفط (الحالي)

| الوحدة | نفط / انتقال |
|--------|--------------|
| مشاة (Infantry) | 2 |
| مدفعية | 3 |
| دبابة | 5 |
| سفينة حربية | 25 |
| غواصة | 45 |
| حاملة طائرات | 120 |
| طائرة حربية | 70 |
| قاذفة B-2 | 400 |

البحرية أعلى بكثير من البرية مجتمعة.  
الجوية أعلى من الغواصة وأقل من الحاملة (ما عدا B-2 التي أعلى بكثير).

---

## الوسوم المستخدمة

- `units` — تصنيف عام
- `land` / `sea` / `air`
- `infantry` / `artillery` / `armor`
- `ship` / `submarine` / `carrier`
- `fighter` / `bomber`
- `basic` — متاحة من البداية
- `heavy` — تكلفة وقوة مرتفعتان
- `stealth` — خفية
- `strategic` — نادرة عالية التأثير
- `transport` — قادرة على نقل وحدات أخرى

---

## ملاحظات
- المشاة = 1000 جندي لكل وحدة (`soldiersPerUnit`).
- النقل في الغواصة مخصص للمشاة فقط.
- الحاملة تنقل جوي + مشاة بسعات مختلفة.
