/* UNO Flip card scanner - pure JS, offline. Works on RGBA pixel arrays. */
(function (root) {
  const GW = 20, GH = 24; // glyph descriptor grid
  const CW = 64, CH = 96; // canonical warped card size

  function lin(v, a, b) { return v <= a ? 0 : v >= b ? 255 : 255 * (v - a) / (b - a); }
  function median(a) { const b = a.slice().sort((x, y) => x - y); return b[b.length >> 1] || 0; }

  /* ---------- segmentation ---------- */
  function boxBlur(src, W, H, r) { // separable box blur on RGBA (removes screen moire / sensor noise before segmentation)
    const tmp = new Float32Array(W * H * 3), out = new Uint8ClampedArray(src.length), k = 2 * r + 1;
    for (let y = 0; y < H; y++) for (let c = 0; c < 3; c++) {
      let s = 0; for (let x = -r; x <= r; x++) s += src[(y * W + Math.min(W - 1, Math.max(0, x))) * 4 + c];
      for (let x = 0; x < W; x++) { tmp[(y * W + x) * 3 + c] = s / k; s += src[(y * W + Math.min(W - 1, x + r + 1)) * 4 + c] - src[(y * W + Math.max(0, x - r)) * 4 + c]; }
    }
    for (let x = 0; x < W; x++) for (let c = 0; c < 3; c++) {
      let s = 0; for (let y = -r; y <= r; y++) s += tmp[(Math.min(H - 1, Math.max(0, y)) * W + x) * 3 + c];
      for (let y = 0; y < H; y++) { out[(y * W + x) * 4 + c] = s / k; out[(y * W + x) * 4 + 3] = 255; s += tmp[(Math.min(H - 1, y + r + 1) * W + x) * 3 + c] - tmp[(Math.max(0, y - r) * W + x) * 3 + c]; }
    }
    return out;
  }
  function closeR(m, W, H, k) {
    const step = (src, dil) => { const out = new Uint8Array(src.length); for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const i = y * W + x; const c = src[i - W - 1] + src[i - W] + src[i - W + 1] + src[i - 1] + src[i] + src[i + 1] + src[i + W - 1] + src[i + W] + src[i + W + 1]; out[i] = dil ? (c > 0 ? 1 : 0) : (c === 9 ? 1 : 0); } return out; };
    for (let i = 0; i < k; i++) m = step(m, true);
    for (let i = 0; i < k; i++) m = step(m, false);
    return m;
  }
  function tableChroma(img, W, H) { // median chromaticity (r/s, g/s) of the image border frame = table colour
    const fr = Math.max(3, Math.round(Math.min(W, H) * 0.03)), rs = [], gs = [];
    for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) if (x < fr || y < fr || x >= W - fr || y >= H - fr) {
      const i = (y * W + x) * 4, s = img.data[i] + img.data[i + 1] + img.data[i + 2]; if (s > 150) { rs.push(img.data[i] / s); gs.push(img.data[i + 1] / s); }
    }
    return [median(rs), median(gs)];
  }
  function openR(m, W, H, k) {
    const step = (src, dil) => { const out = new Uint8Array(src.length); for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const i = y * W + x; const c = src[i - W - 1] + src[i - W] + src[i - W + 1] + src[i - 1] + src[i] + src[i + 1] + src[i + W - 1] + src[i + W] + src[i + W + 1]; out[i] = dil ? (c > 0 ? 1 : 0) : (c === 9 ? 1 : 0); } return out; };
    for (let i = 0; i < k; i++) m = step(m, false);
    for (let i = 0; i < k; i++) m = step(m, true);
    return m;
  }
  function chromaMask(img, W, H, tc) { // cards = colours that differ from the table's chromaticity, or very dark borders; ignores brightness patterns
    const data = boxBlur(img.data, W, H, 1), N = W * H; let m = new Uint8Array(N);
    for (let p = 0; p < N; p++) {
      const r = data[p * 4], g = data[p * 4 + 1], b = data[p * 4 + 2], s = r + g + b, mx = Math.max(r, g, b);
      if (mx < 55) { m[p] = 1; continue; }
      if (s > 150) { const dr = r / s - tc[0], dg = g / s - tc[1]; if (Math.sqrt(dr * dr + dg * dg) > 0.045) m[p] = 1; }
    }
    m = morph(m, W, H, false);
    m = closeR(m, W, H, 4);
    const raw = m; m = fillHoles(m, W, H, N);
    m = openR(m, W, H, 6); // strip thin attachments (table shadows / pattern bits) from the cards
    return { mask: m, raw };
  }
  function segment(img) {
    const W = img.width, H = img.height, tc = tableChroma(img, W, H);
    if (Math.abs(tc[0] - 1 / 3) + Math.abs(tc[1] - 1 / 3) < 0.1) { const c = chromaMask(img, W, H, tc); c.chroma = true; return c; } // grey / white / neutral table
    return segmentDist(img);
  }
  function segmentDist(img) {
    const W = img.width, H = img.height, N = W * H, data = boxBlur(img.data, W, H, 1);
    // local background model: median colour per grid cell, bilinearly interpolated (handles shading)
    const GX = 8, GY = 6, cellMed = [];
    for (let gy = 0; gy < GY; gy++) for (let gx = 0; gx < GX; gx++) {
      const ch = [[], [], []];
      for (let y = Math.floor(gy * H / GY); y < Math.floor((gy + 1) * H / GY); y += 2) for (let x = Math.floor(gx * W / GX); x < Math.floor((gx + 1) * W / GX); x += 2) { const i = (y * W + x) * 4; ch[0].push(data[i]); ch[1].push(data[i + 1]); ch[2].push(data[i + 2]); }
      cellMed.push([median(ch[0]), median(ch[1]), median(ch[2])]);
    }
    // table colour = median of the image border frame (the table touches the edges; cards usually do not)
    const allc = [[], [], []], fr = Math.max(3, Math.round(Math.min(W, H) * 0.03));
    for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) {
      if (x < fr || y < fr || x >= W - fr || y >= H - fr) { const i = (y * W + x) * 4; allc[0].push(data[i]); allc[1].push(data[i + 1]); allc[2].push(data[i + 2]); }
    }
    const G = [median(allc[0]), median(allc[1]), median(allc[2])];
    for (const m of cellMed) if (Math.max(Math.abs(m[0] - G[0]), Math.abs(m[1] - G[1]), Math.abs(m[2] - G[2])) > 40) { m[0] = G[0]; m[1] = G[1]; m[2] = G[2]; }
    const D = new Float32Array(N);
    for (let y = 0; y < H; y++) {
      const fy = Math.min(GY - 1, Math.max(0, y / H * GY - 0.5)), y0 = Math.floor(fy), y1 = Math.min(GY - 1, y0 + 1), ty = fy - y0;
      for (let x = 0; x < W; x++) {
        const fx = Math.min(GX - 1, Math.max(0, x / W * GX - 0.5)), x0 = Math.floor(fx), x1 = Math.min(GX - 1, x0 + 1), tx = fx - x0, i = (y * W + x) * 4;
        let mx = 0;
        for (let c = 0; c < 3; c++) {
          const bgc = (cellMed[y0 * GX + x0][c] * (1 - tx) + cellMed[y0 * GX + x1][c] * tx) * (1 - ty) + (cellMed[y1 * GX + x0][c] * (1 - tx) + cellMed[y1 * GX + x1][c] * tx) * ty;
          const d = Math.abs(data[i + c] - bgc); if (d > mx) mx = d;
        }
        D[y * W + x] = mx;
      }
    }
    // Otsu on D
    const hist = new Float64Array(256); for (let p = 0; p < N; p++) hist[Math.min(255, D[p] | 0)]++;
    let sum = 0; for (let t = 0; t < 256; t++) sum += t * hist[t];
    let wB = 0, sB = 0, best = 0, thr = 40;
    for (let t = 0; t < 256; t++) {
      wB += hist[t]; if (!wB) continue; const wF = N - wB; if (!wF) break;
      sB += t * hist[t]; const mB = sB / wB, mF = (sum - sB) / wF, v = wB * wF * (mB - mF) * (mB - mF);
      if (v > best) { best = v; thr = t; }
    }
    thr = Math.max(36, Math.min(thr, 62));
    let mask = new Uint8Array(N); for (let p = 0; p < N; p++) mask[p] = D[p] > thr ? 1 : 0;
    mask = morph(mask, W, H, true); mask = morph(mask, W, H, true); // close x2
    const raw = morph(mask, W, H, false); // before hole filling: gaps between touching cards are still visible here
    mask = fillHoles(mask, W, H, N);
    mask = morph(mask, W, H, false); // open: remove specks / thin bridges
    return { mask, raw };
  }
  function morph(m, W, H, dilateFirst) { // 3x3 dilate+erode (close) or erode+dilate (open)
    const op = (src, dil) => {
      const out = new Uint8Array(src.length);
      for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
        let c = 0; const i = y * W + x;
        c = src[i - W - 1] + src[i - W] + src[i - W + 1] + src[i - 1] + src[i] + src[i + 1] + src[i + W - 1] + src[i + W] + src[i + W + 1];
        out[i] = dil ? (c > 0 ? 1 : 0) : (c === 9 ? 1 : 0);
      }
      return out;
    };
    return dilateFirst ? op(op(m, true), false) : op(op(m, false), true);
  }
  function fillHoles(m, W, H, maxHole) { // fill only SMALL enclosed background pockets (glyph/ring holes), never the gaps between cards
    const N = W * H, lab = new Uint8Array(N), out = Uint8Array.from(m), st = [];
    for (let s = 0; s < N; s++) {
      if (m[s] || lab[s]) continue;
      const px = []; let border = false; lab[s] = 1; st.push(s);
      while (st.length) {
        const p = st.pop(); px.push(p); const x = p % W, y = (p / W) | 0;
        if (x === 0 || y === 0 || x === W - 1 || y === H - 1) border = true;
        if (x > 0 && !m[p - 1] && !lab[p - 1]) { lab[p - 1] = 1; st.push(p - 1); }
        if (x < W - 1 && !m[p + 1] && !lab[p + 1]) { lab[p + 1] = 1; st.push(p + 1); }
        if (y > 0 && !m[p - W] && !lab[p - W]) { lab[p - W] = 1; st.push(p - W); }
        if (y < H - 1 && !m[p + W] && !lab[p + W]) { lab[p + W] = 1; st.push(p + W); }
      }
      if (!border && px.length <= maxHole) for (const p of px) out[p] = 1;
    }
    return out;
  }
  function components(mask, W, H) {
    const N = W * H, lab = new Int32Array(N), comps = []; let id = 0;
    const st = [];
    for (let s = 0; s < N; s++) {
      if (!mask[s] || lab[s]) continue; id++; const px = []; lab[s] = id; st.push(s);
      while (st.length) {
        const p = st.pop(); px.push(p); const x = p % W, y = (p / W) | 0;
        if (x > 0 && mask[p - 1] && !lab[p - 1]) { lab[p - 1] = id; st.push(p - 1); }
        if (x < W - 1 && mask[p + 1] && !lab[p + 1]) { lab[p + 1] = id; st.push(p + 1); }
        if (y > 0 && mask[p - W] && !lab[p - W]) { lab[p - W] = id; st.push(p - W); }
        if (y < H - 1 && mask[p + W] && !lab[p + W]) { lab[p + W] = id; st.push(p + W); }
      }
      comps.push(px);
    }
    return comps;
  }

  /* ---------- splitting touching cards (erode -> label -> regrow) ---------- */
  function splitBlob(px, W, H) {
    let x0 = W, x1 = 0, y0 = H, y1 = 0;
    for (const p of px) { const x = p % W, y = (p / W) | 0; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    const w = x1 - x0 + 3, h = y1 - y0 + 3, base = new Uint8Array(w * h);
    for (const p of px) base[((((p / W) | 0) - y0 + 1) * w) + (p % W - x0 + 1)] = 1;
    const erode = m => { const o = new Uint8Array(w * h); for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { const i = y * w + x; if (m[i] && m[i - 1] && m[i + 1] && m[i - w] && m[i + w] && m[i - w - 1] && m[i - w + 1] && m[i + w - 1] && m[i + w + 1]) o[i] = 1; } return o; };
    const label = m => { const lab = new Int32Array(w * h); let n = 0; const sizes = [0], st = []; for (let s = 0; s < w * h; s++) { if (!m[s] || lab[s]) continue; n++; sizes.push(0); lab[s] = n; st.push(s); while (st.length) { const q = st.pop(); sizes[n]++; const x = q % w; if (x > 0 && m[q - 1] && !lab[q - 1]) { lab[q - 1] = n; st.push(q - 1); } if (x < w - 1 && m[q + 1] && !lab[q + 1]) { lab[q + 1] = n; st.push(q + 1); } if (q >= w && m[q - w] && !lab[q - w]) { lab[q - w] = n; st.push(q - w); } if (q + w < w * h && m[q + w] && !lab[q + w]) { lab[q + w] = n; st.push(q + w); } } } return { lab, n, sizes }; };
    let cur = base, best = null, bestScore = 1;
    for (let r = 1; r <= 14; r++) {
      cur = erode(cur); const L = label(cur); if (!L.n) break;
      const maxS = Math.max(...L.sizes.slice(1)), good = L.sizes.slice(1).filter(s => s >= 0.3 * maxS).length;
      if (good > bestScore) { bestScore = good; best = { L, r }; }
      if (good >= bestScore && best && r > best.r + 3) break;
    }
    if (!best) return [px];
    // regrow markers back into the blob
    let lab = Int32Array.from(best.L.lab);
    for (let it = 0; it < best.r + 3; it++) {
      const nl = Int32Array.from(lab);
      for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { const i = y * w + x; if (base[i] && !lab[i]) { const v = lab[i - 1] || lab[i + 1] || lab[i - w] || lab[i + w]; if (v) nl[i] = v; } }
      lab = nl;
    }
    const maxS = Math.max(...best.L.sizes.slice(1)), keep = new Set(); best.L.sizes.forEach((s, k) => { if (k && s >= 0.3 * maxS) keep.add(k); });
    const groups = {}; for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { const v = lab[y * w + x]; if (v && keep.has(v)) (groups[v] = groups[v] || []).push((y + y0 - 1) * W + (x + x0 - 1)); }
    const out = Object.values(groups); return out.length >= 2 ? out : [px];
  }

  function splitByRaw(c, raw, W, H, minA) { // re-cut a merged blob using the un-filled mask, then close each card separately
    const N = W * H, sub = new Uint8Array(N); for (const p of c) sub[p] = raw[p];
    let m = sub; for (let i = 0; i < 3; i++) m = morph(m, W, H, true);
    m = fillHoles(m, W, H, Math.round(N * 0.06)); m = morph(m, W, H, false);
    return components(m, W, H).filter(q => q.length >= minA);
  }

  /* ---------- geometry ---------- */
  function orient(px, W, qs) {
    let n = px.length, mx = 0, my = 0;
    for (const p of px) { mx += p % W; my += (p / W) | 0; } mx /= n; my /= n;
    let sxx = 0, syy = 0, sxy = 0;
    for (const p of px) { const dx = p % W - mx, dy = ((p / W) | 0) - my; sxx += dx * dx; syy += dy * dy; sxy += dx * dy; }
    const ang = 0.5 * Math.atan2(2 * sxy, sxx - syy); // major axis angle
    const ev = [Math.cos(ang), Math.sin(ang)], eu = [ev[1], -ev[0]];
    let umin = 1e9, umax = -1e9, vmin = 1e9, vmax = -1e9;
    for (const p of px) {
      const dx = p % W - mx, dy = ((p / W) | 0) - my, u = dx * eu[0] + dy * eu[1], v = dx * ev[0] + dy * ev[1];
      if (u < umin) umin = u; if (u > umax) umax = u; if (v < vmin) vmin = v; if (v > vmax) vmax = v;
    }
    // four corners (extreme pixels along the diagonals in normalised card coordinates) -> handles perspective
    const wu0 = umax - umin + 1, hv0 = vmax - vmin + 1, best = [[1e9, 0, 0], [-1e9, 0, 0], [-1e9, 0, 0], [-1e9, 0, 0]];
    for (const p of px) {
      const x = p % W, y = (p / W) | 0, dx = x - mx, dy = y - my, a = ((dx * eu[0] + dy * eu[1]) - umin) / wu0, b = ((dx * ev[0] + dy * ev[1]) - vmin) / hv0;
      const sc = [a + b, a - b, b - a, a + b];
      if (sc[0] < best[0][0]) best[0] = [sc[0], x, y];
      if (sc[1] > best[1][0]) best[1] = [sc[1], x, y];
      if (sc[2] > best[2][0]) best[2] = [sc[2], x, y];
      if (sc[3] > best[3][0]) best[3] = [sc[3], x, y];
    }
    let qcx = 0, qcy = 0; for (const c of best) { qcx += c[1] / 4; qcy += c[2] / 4; }
    const q = qs || 1.04, quad = best.map(c => [qcx + (c[1] - qcx) * q, qcy + (c[2] - qcy) * q]); // order: 00, 10, 01, 11
    return { mx, my, eu, ev, umin, umax, vmin, vmax, wu: wu0, hv: hv0, area: n, quad };
  }
  function warp(img, o) {
    const { data, width: W, height: H } = img, out = new Uint8ClampedArray(CW * CH * 4);
    for (let j = 0; j < CH; j++) for (let i = 0; i < CW; i++) {
      let x, y;
      if (o.quad) {
        const s = (i + 0.5) / CW, t = (j + 0.5) / CH, q = o.quad;
        x = (1 - s) * (1 - t) * q[0][0] + s * (1 - t) * q[1][0] + (1 - s) * t * q[2][0] + s * t * q[3][0];
        y = (1 - s) * (1 - t) * q[0][1] + s * (1 - t) * q[1][1] + (1 - s) * t * q[2][1] + s * t * q[3][1];
      } else {
        const u = o.umin + (i + 0.5) / CW * (o.umax - o.umin), v = o.vmin + (j + 0.5) / CH * (o.vmax - o.vmin);
        x = o.mx + u * o.eu[0] + v * o.ev[0]; y = o.my + u * o.eu[1] + v * o.ev[1];
      }
      const x0 = Math.floor(x - 0.5), y0 = Math.floor(y - 0.5), fx = x - 0.5 - x0, fy = y - 0.5 - y0;
      for (let c = 0; c < 3; c++) {
        const g = (xx, yy) => data[(Math.min(H - 1, Math.max(0, yy)) * W + Math.min(W - 1, Math.max(0, xx))) * 4 + c];
        out[(j * CW + i) * 4 + c] = (g(x0, y0) * (1 - fx) + g(x0 + 1, y0) * fx) * (1 - fy) + (g(x0, y0 + 1) * (1 - fx) + g(x0 + 1, y0 + 1) * fx) * fy;
      }
      out[(j * CW + i) * 4 + 3] = 255;
    }
    return { data: out, width: CW, height: CH };
  }
  function rot180(c) {
    const o = new Uint8ClampedArray(c.data.length), n = c.width * c.height;
    for (let p = 0; p < n; p++) { const q = n - 1 - p; for (let k = 0; k < 4; k++) o[q * 4 + k] = c.data[p * 4 + k]; }
    return { data: o, width: c.width, height: c.height };
  }

  /* ---------- descriptor of a canonical card ---------- */
  function rgb2hsv(r, g, b) {
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; let h = 0;
    if (d) { if (mx === r) h = ((g - b) / d + 6) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; }
    return [h * 60, mx ? d / mx : 0, mx / 255];
  }
  // maps: W = min channel (white glyph), K = 255-max channel (black outline). Both are colour-independent.
  function describe(card) {
    const { data, width: W, height: H } = card;
    const zx0 = W * 0.2, zx1 = W * 0.8, zy0 = H * 0.2, zy1 = H * 0.8;
    const Wm = new Float32Array(GW * GH), Km = new Float32Array(GW * GH);
    for (let gy = 0; gy < GH; gy++) for (let gx = 0; gx < GW; gx++) {
      const xa = Math.floor(zx0 + (zx1 - zx0) * gx / GW), xb = Math.max(xa + 1, Math.floor(zx0 + (zx1 - zx0) * (gx + 1) / GW));
      const ya = Math.floor(zy0 + (zy1 - zy0) * gy / GH), yb = Math.max(ya + 1, Math.floor(zy0 + (zy1 - zy0) * (gy + 1) / GH));
      let sw = 0, sk = 0, c = 0;
      for (let y = ya; y < yb; y++) for (let x = xa; x < xb; x++) { const i = (y * W + x) * 4; sw += lin(Math.min(data[i], data[i + 1], data[i + 2]), 130, 175); sk += lin(255 - Math.max(data[i], data[i + 1], data[i + 2]), 120, 170); c++; }
      Wm[gy * GW + gx] = sw / c; Km[gy * GW + gx] = sk / c;
    }
    const blur = m => { const o = new Float32Array(m.length); for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) { let s = 0, c = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if (xx >= 0 && xx < GW && yy >= 0 && yy < GH) { s += m[yy * GW + xx] * (dx || dy ? 1 : 2); c += (dx || dy ? 1 : 2); } } o[y * GW + x] = s / c; } return o; };
    const Wb = blur(Wm), Kb = blur(Km); Wm.set(Wb); Km.set(Kb);
    // energy = how much structure (glyph) the centre has
    let mw = 0, mk = 0; for (let i = 0; i < Wm.length; i++) { mw += Wm[i]; mk += Km[i]; } mw /= Wm.length; mk /= Km.length;
    let ew = 0, ek = 0; for (let i = 0; i < Wm.length; i++) { ew += (Wm[i] - mw) ** 2; ek += (Km[i] - mk) ** 2; }
    const energy = Math.sqrt((ew + ek) / (2 * Wm.length));
    // hue diversity in the inner centre
    const hb = new Float64Array(12); let tot = 0;
    for (let y = Math.round(H * 0.3); y < Math.round(H * 0.7); y++) for (let x = Math.round(W * 0.25); x < Math.round(W * 0.75); x++) {
      const i = (y * W + x) * 4, [h, s, v] = rgb2hsv(data[i], data[i + 1], data[i + 2]);
      if (s > 0.4 && v > 0.35) { hb[Math.floor(h / 30) % 12]++; tot++; }
    }
    let nHue = 0; if (tot > 40) for (let k = 0; k < 12; k++) if (hb[k] / tot > 0.07) nHue++;
    // face: fraction of bright pixels in the outer band (white border = light face, black border = dark face)
    let eb = 0, en = 0;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const dx = Math.min(x, W - 1 - x), dy = Math.min(y, H - 1 - y);
      if (Math.min(dx, dy) >= 1 && Math.min(dx, dy) <= 4) { const i = (y * W + x) * 4; if (Math.min(data[i], data[i + 1], data[i + 2]) > 185) eb++; en++; }
    }
    return { Wm, Km, energy, nHue, edge: eb / en };
  }
  function nccShift(a, b, flip) { // a,b = {Wm,Km}; best NCC over +-1 cell shifts; flip = rotate b by 180
    let best = -1;
    const get = (m, x, y) => flip ? m[(GH - 1 - y) * GW + (GW - 1 - x)] : m[y * GW + x];
    for (let sy = -2; sy <= 2; sy++) for (let sx = -2; sx <= 2; sx++) {
      let tot = 0;
      for (const key of ['Wm', 'Km']) {
        let n = 0, ma = 0, mb = 0;
        for (let y = 2; y < GH - 2; y++) for (let x = 2; x < GW - 2; x++) { ma += a[key][y * GW + x]; mb += get(b[key], x + sx, y + sy); n++; }
        ma /= n; mb /= n; let sab = 0, saa = 0, sbb = 0;
        for (let y = 2; y < GH - 2; y++) for (let x = 2; x < GW - 2; x++) { const u = a[key][y * GW + x] - ma, v = get(b[key], x + sx, y + sy) - mb; sab += u * v; saa += u * u; sbb += v * v; }
        tot += saa > 1 && sbb > 1 ? sab / Math.sqrt(saa * sbb) : 0;
      }
      if (tot / 2 > best) best = tot / 2;
    }
    return best;
  }

  /* ---------- trained classifier (MLP) running offline in JS ---------- */
  const MGW = 20, MGH = 30;
  const MXE = Array.from({ length: MGW + 1 }, (_, i) => Math.floor(i * CW / MGW)), MYE = Array.from({ length: MGH + 1 }, (_, i) => Math.floor(i * CH / MGH));
  const linf = (v, a, b) => v <= a ? 0 : v >= b ? 1 : (v - a) / (b - a);
  function modelFeats(card) { // must match common.py feats() exactly
    const { data } = card, W = CW, H = CH, f = new Float32Array(2 * MGW * MGH + 13);
    for (let gy = 0; gy < MGH; gy++) for (let gx = 0; gx < MGW; gx++) {
      let sw = 0, sk = 0, c = 0;
      for (let y = MYE[gy]; y < MYE[gy + 1]; y++) for (let x = MXE[gx]; x < MXE[gx + 1]; x++) {
        const i = (y * W + x) * 4, r = data[i], g = data[i + 1], b = data[i + 2];
        sw += linf(Math.min(r, g, b), 130, 175); sk += linf(255 - Math.max(r, g, b), 120, 170); c++;
      }
      f[gy * MGW + gx] = sw / c; f[MGW * MGH + gy * MGW + gx] = sk / c;
    }
    const hist = new Float64Array(12); let n = 0;
    for (let y = 29; y < 67; y++) for (let x = 16; x < 48; x++) {
      const i = (y * W + x) * 4, r = data[i], g = data[i + 1], b = data[i + 2], M = Math.max(r, g, b), m = Math.min(r, g, b), d = M - m;
      let h = 0; if (d > 0) { if (M === r) h = ((g - b) / d + 6) % 6; else if (M === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; } h *= 60;
      const s = M > 0 ? d / M : 0, v = M / 255;
      if (s > 0.4 && v > 0.35) { hist[Math.floor(h / 30) % 12]++; n++; }
    }
    for (let k = 0; k < 12; k++) f[2 * MGW * MGH + k] = hist[k] / Math.max(1, n);
    f[2 * MGW * MGH + 12] = n / (32 * 38);
    return f;
  }
  function modelProbs(card, M) {
    const f = modelFeats(card), D = f.length, H = M.H, h = new Float32Array(H);
    for (let j = 0; j < H; j++) h[j] = M.b1[j];
    for (let i = 0; i < D; i++) { const xi = (f[i] - M.mu[i]) / M.sd[i]; if (!xi) continue; const base = i * H; for (let j = 0; j < H; j++) h[j] += xi * M.W1[base + j]; }
    const K = M.ids.length, z = new Float64Array(K);
    for (let k = 0; k < K; k++) z[k] = M.b2[k];
    for (let j = 0; j < H; j++) { const hj = h[j] > 0 ? h[j] : 0; if (!hj) continue; for (let k = 0; k < K; k++) z[k] += hj * M.W2[j * K + k]; }
    let mx = -1e9; for (let k = 0; k < K; k++) if (z[k] > mx) mx = z[k];
    let s = 0; for (let k = 0; k < K; k++) { z[k] = Math.exp(z[k] - mx); s += z[k]; }
    return Array.from(z, v => v / s);
  }

  /* ---------- classification ---------- */
  const isLightId = id => id.startsWith('num_') || id.startsWith('light_');
  const WILDS = ['light_wild', 'dark_wild'];
  function classify(card, refs) {
    const MM = root.UNO_MODEL;
    if (MM) {
      const pr = modelProbs(card, MM), order = pr.map((v, k) => k).sort((a, b) => pr[b] - pr[a]);
      const li = order.slice(0, 3).map(k => ({ id: MM.ids[k], score: pr[k], rot: 0 }));
      return { best: li[0], second: li[1], list: li };
    }
    const d = describe(card), light = d.edge > 0.12, wildLike = d.nHue >= 4;
    const res = [];
    for (const id in refs) {
      const r = refs[id];
      let s;
      const facePen = isLightId(id) !== light ? 0.3 : 0; // soft: face detection can be fooled by perspective/background
      const rd = { Wm: Float32Array.from(r.Wm), Km: Float32Array.from(r.Km) };
      if (r.plain) { // plain wild: no glyph, many colours
        s = (d.energy < 25 ? 0.7 : 0.2) + (wildLike ? 0.3 : -0.4) - facePen; res.push({ id, score: s, rot: 0 }); continue;
      }
      const s0 = nccShift(d, rd, false), s1 = nccShift(d, rd, true), rot = s1 > s0 ? 180 : 0;
      s = Math.max(s0, s1) - facePen;
      if (r.nHue >= 4) s += wildLike ? 0.1 : -0.15; else s += wildLike ? -0.15 : 0;
      res.push({ id, score: s, rot });
    }
    res.sort((a, b) => b.score - a.score);
    return { best: res[0], second: res[1], list: res.slice(0, 3), light };
  }

  /* ---------- main entry ---------- */
  function analyze(img, refs) {
    const { width: W, height: H } = img;
    const seg = segment(img), mask = seg.mask, comps = components(mask, W, H);
    const minA = W * H * 0.0015;
    let big = comps.filter(c => c.length >= minA);
    if (!big.length) return { cards: [], warnings: ['no_cards'] };
    const med = median(big.map(c => c.length));
    big = big.filter(c => c.length >= med * 0.35);
    const med2 = median(big.map(c => c.length));
    const cards = [], warnings = [];
    const merged = c => { const o = orient(c, W), asp = o.hv / o.wu, fl = o.area / (o.wu * o.hv); if (fl > 0.88 && asp > 1.3 && asp < 1.8 && c.length < med2 * 2.4) return false; return c.length > med2 * 1.7 || (big.length === 1 && c.length > W * H * 0.25 && (asp < 1.3 || asp > 1.8)); };
    const plausible = q => { const o = orient(q, W), asp = o.hv / o.wu; return asp > 1.2 && asp < 1.9 && o.area / (o.wu * o.hv) > 0.8; };
    let work = [];
    for (const c of big) {
      if (merged(c)) {
        for (const parts of [splitByRaw(c, seg.raw, W, H, minA), splitBlob(c, W, H).filter(q => q.length >= minA)]) {
          if (parts.length >= 2 && parts.filter(plausible).length >= parts.length * 0.6) { work.push(...parts); c.__split = true; break; }
        }
        if (c.__split) continue;
      }
      work.push(c);
    }
    for (const c of work) {
      const o = orient(c, W, seg.chroma ? 1.09 : 1.04), aspect = o.hv / o.wu, fill = o.area / (o.wu * o.hv);
      const touchesEdge = c.some(p => { const x = p % W, y = (p / W) | 0; return x < 2 || y < 2 || x >= W - 2 || y >= H - 2; });
      const flags = [];
      if (o.area > med2 * 1.7 && !(fill > 0.88 && aspect > 1.3 && aspect < 1.8 && o.area < med2 * 2.4)) flags.push('overlap');
      else if (fill < 0.86 || aspect < 1.25 || aspect > 1.85) flags.push('odd_shape');
      if (touchesEdge) flags.push('cut');
      const item = { cx: o.mx, cy: o.my, area: o.area, flags, estCount: Math.max(1, Math.round(o.area / med2)) };
      if (!flags.includes('overlap')) {
        const cardImg = warp(img, o), cl = classify(cardImg, refs);
        item.canon = cardImg; item.cw = o.wu; item.ch = o.hv;
        item.thumb = (cl.best.rot ? rot180(cardImg) : cardImg);
        item.id = cl.best.id; item.score = cl.best.score; item.margin = cl.best.score - cl.second.score; item.alts = cl.list.map(x => x.id);
        if (root.UNO_MODEL ? (item.score < 0.7 || item.margin < 0.3) : (item.score < 0.5 || item.margin < 0.07)) flags.push('uncertain');
      }
      cards.push(item);
    }
    // reading order: rows top-to-bottom, then left-to-right
    cards.sort((a, b) => (Math.round(a.cy / (H / 6)) - Math.round(b.cy / (H / 6))) || (a.cx - b.cx));
    return { cards, warnings, mask };
  }

  /* ---------- build reference descriptor from a reference image ---------- */
  function refFromImage(img, padFrac) { // img = whole reference picture (RGBA); padFrac = white border to add (light-face cards)
    const { data, width: W, height: H } = img;
    const corner = [[0, 0], [W - 1, 0], [0, H - 1], [W - 1, H - 1]].map(([x, y]) => { const i = (y * W + x) * 4; return [data[i], data[i + 1], data[i + 2]]; });
    const bg = [0, 1, 2].map(c => median(corner.map(p => p[c])));
    let x0 = W, x1 = -1, y0 = H, y1 = -1;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4;
      if (Math.max(Math.abs(data[i] - bg[0]), Math.abs(data[i + 1] - bg[1]), Math.abs(data[i + 2] - bg[2])) > 40) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    }
    const pad = (padFrac || 0) * (x1 - x0), hw = (x1 - x0) / 2 + pad, hh = (y1 - y0) / 2 + pad;
    const o = { mx: (x0 + x1) / 2, my: (y0 + y1) / 2, eu: [1, 0], ev: [0, 1], umin: -hw, umax: hw, vmin: -hh, vmax: hh };
    const d = describe(warp(img, o));
    const r2 = a => Array.from(a, v => Math.round(v * 10) / 10);
    return { Wm: r2(d.Wm), Km: r2(d.Km), energy: +d.energy.toFixed(1), nHue: d.nHue, plain: d.energy < 25 && d.nHue >= 4 };
  }

  const api = { analyze, refFromImage, describe, warp, modelFeats, modelProbs, CW, CH };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.UnoScan = api;
})(typeof window !== 'undefined' ? window : globalThis);
