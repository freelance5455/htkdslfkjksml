/* UNO Flip card scanner - pure JS, offline. Works on RGBA pixel arrays. */
(function (root) {
  const GW = 20, GH = 24; // glyph descriptor grid
  const CW = 64, CH = 96; // canonical warped card size

  function lin(v, a, b) { return v <= a ? 0 : v >= b ? 255 : 255 * (v - a) / (b - a); }
  function median(a) { const b = a.slice().sort((x, y) => x - y); return b[b.length >> 1] || 0; }

  /* ---------- segmentation ---------- */
  function segment(img) {
    const { data, width: W, height: H } = img, N = W * H;
    // local background model: median colour per grid cell, bilinearly interpolated (handles shading)
    const GX = 8, GY = 6, cellMed = [];
    for (let gy = 0; gy < GY; gy++) for (let gx = 0; gx < GX; gx++) {
      const ch = [[], [], []];
      for (let y = Math.floor(gy * H / GY); y < Math.floor((gy + 1) * H / GY); y += 2) for (let x = Math.floor(gx * W / GX); x < Math.floor((gx + 1) * W / GX); x += 2) { const i = (y * W + x) * 4; ch[0].push(data[i]); ch[1].push(data[i + 1]); ch[2].push(data[i + 2]); }
      cellMed.push([median(ch[0]), median(ch[1]), median(ch[2])]);
    }
    const allc = [[], [], []];
    for (let y = 0; y < H; y += 3) for (let x = 0; x < W; x += 3) { const i = (y * W + x) * 4; allc[0].push(data[i]); allc[1].push(data[i + 1]); allc[2].push(data[i + 2]); }
    const G = [median(allc[0]), median(allc[1]), median(allc[2])];
    for (const m of cellMed) if (Math.max(Math.abs(m[0] - G[0]), Math.abs(m[1] - G[1]), Math.abs(m[2] - G[2])) > 40) { m[0] = G[0]; m[1] = G[1]; m[2] = G[2]; }
    const D = new Float32Array(N);
    for (let y = 0; y < H; y++) {
      const fy = Math.min(GY - 1, Math.max(0, y / H * GY - 0.5)), y0 = Math.floor(fy), y1 = Math.min(GY - 1, y0 + 1), ty = fy - y0;
      for (let x = 0; x < W; x++) {
        const fx = Math.min(GX - 1, Math.max(0, x / W * GX - 0.5)), x0 = Math.floor(fx), x1 = Math.min(GX - 1, x0 + 1), tx = fx - x0, i = (y * W + x) * 4;
        let mx = 0;
        for (let c = 0; c < 3; c++) {
          const bgc = (cellMed[y0 * GX + x0][c] * (1 - tx) + cellMed[y0 * GX + x1][c] * tx) * (1 - ty) + (cellMed[y1 * GX + x0][c] * (1 - tx) + cellMed[y1 * GX + x1][c] * tx) * ty;
          const d = Math.abs(data[i + c] - bgc); if (d > mx) mx = d;
        }
        D[y * W + x] = mx;
      }
    }
    // Otsu on D
    const hist = new Float64Array(256); for (let p = 0; p < N; p++) hist[Math.min(255, D[p] | 0)]++;
    let sum = 0; for (let t = 0; t < 256; t++) sum += t * hist[t];
    let wB = 0, sB = 0, best = 0, thr = 40;
    for (let t = 0; t < 256; t++) {
      wB += hist[t]; if (!wB) continue; const wF = N - wB; if (!wF) break;
      sB += t * hist[t]; const mB = sB / wB, mF = (sum - sB) / wF, v = wB * wF * (mB - mF) * (mB - mF);
      if (v > best) { best = v; thr = t; }
    }
    thr = Math.max(36, Math.min(thr, 62));
    let mask = new Uint8Array(N); for (let p = 0; p < N; p++) mask[p] = D[p] > thr ? 1 : 0;
    mask = morph(mask, W, H, true); mask = morph(mask, W, H, true); // close x2
    mask = fillHoles(mask, W, H);
    mask = morph(mask, W, H, false); // open: remove specks / thin bridges
    return mask;
  }
  function morph(m, W, H, dilateFirst) { // 3x3 dilate+erode (close) or erode+dilate (open)
    const op = (src, dil) => {
      const out = new Uint8Array(src.length);
      for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
        let c = 0; const i = y * W + x;
        c = src[i - W - 1] + src[i - W] + src[i - W + 1] + src[i - 1] + src[i] + src[i + 1] + src[i + W - 1] + src[i + W] + src[i + W + 1];
        out[i] = dil ? (c > 0 ? 1 : 0) : (c === 9 ? 1 : 0);
      }
      return out;
    };
    return dilateFirst ? op(op(m, true), false) : op(op(m, false), true);
  }
  function fillHoles(m, W, H) {
    const N = W * H, seen = new Uint8Array(N), st = [];
    const push = p => { if (!seen[p] && !m[p]) { seen[p] = 1; st.push(p); } };
    for (let x = 0; x < W; x++) { push(x); push((H - 1) * W + x); }
    for (let y = 0; y < H; y++) { push(y * W); push(y * W + W - 1); }
    while (st.length) {
      const p = st.pop(), x = p % W, y = (p / W) | 0;
      if (x > 0) push(p - 1); if (x < W - 1) push(p + 1); if (y > 0) push(p - W); if (y < H - 1) push(p + W);
    }
    const out = new Uint8Array(N); for (let p = 0; p < N; p++) out[p] = (m[p] || !seen[p]) ? 1 : 0; return out;
  }
  function components(mask, W, H) {
    const N = W * H, lab = new Int32Array(N), comps = []; let id = 0;
    const st = [];
    for (let s = 0; s < N; s++) {
      if (!mask[s] || lab[s]) continue; id++; const px = []; lab[s] = id; st.push(s);
      while (st.length) {
        const p = st.pop(); px.push(p); const x = p % W, y = (p / W) | 0;
        if (x > 0 && mask[p - 1] && !lab[p - 1]) { lab[p - 1] = id; st.push(p - 1); }
        if (x < W - 1 && mask[p + 1] && !lab[p + 1]) { lab[p + 1] = id; st.push(p + 1); }
        if (y > 0 && mask[p - W] && !lab[p - W]) { lab[p - W] = id; st.push(p - W); }
        if (y < H - 1 && mask[p + W] && !lab[p + W]) { lab[p + W] = id; st.push(p + W); }
      }
      comps.push(px);
    }
    return comps;
  }

  /* ---------- geometry ---------- */
  function orient(px, W) {
    let n = px.length, mx = 0, my = 0;
    for (const p of px) { mx += p % W; my += (p / W) | 0; } mx /= n; my /= n;
    let sxx = 0, syy = 0, sxy = 0;
    for (const p of px) { const dx = p % W - mx, dy = ((p / W) | 0) - my; sxx += dx * dx; syy += dy * dy; sxy += dx * dy; }
    const ang = 0.5 * Math.atan2(2 * sxy, sxx - syy); // major axis angle
    const ev = [Math.cos(ang), Math.sin(ang)], eu = [ev[1], -ev[0]];
    let umin = 1e9, umax = -1e9, vmin = 1e9, vmax = -1e9;
    for (const p of px) {
      const dx = p % W - mx, dy = ((p / W) | 0) - my, u = dx * eu[0] + dy * eu[1], v = dx * ev[0] + dy * ev[1];
      if (u < umin) umin = u; if (u > umax) umax = u; if (v < vmin) vmin = v; if (v > vmax) vmax = v;
    }
    return { mx, my, eu, ev, umin, umax, vmin, vmax, wu: umax - umin + 1, hv: vmax - vmin + 1, area: n };
  }
  function warp(img, o) {
    const { data, width: W, height: H } = img, out = new Uint8ClampedArray(CW * CH * 4);
    for (let j = 0; j < CH; j++) for (let i = 0; i < CW; i++) {
      const u = o.umin + (i + 0.5) / CW * (o.umax - o.umin), v = o.vmin + (j + 0.5) / CH * (o.vmax - o.vmin);
      const x = o.mx + u * o.eu[0] + v * o.ev[0], y = o.my + u * o.eu[1] + v * o.ev[1];
      const x0 = Math.floor(x - 0.5), y0 = Math.floor(y - 0.5), fx = x - 0.5 - x0, fy = y - 0.5 - y0;
      for (let c = 0; c < 3; c++) {
        const g = (xx, yy) => data[(Math.min(H - 1, Math.max(0, yy)) * W + Math.min(W - 1, Math.max(0, xx))) * 4 + c];
        out[(j * CW + i) * 4 + c] = (g(x0, y0) * (1 - fx) + g(x0 + 1, y0) * fx) * (1 - fy) + (g(x0, y0 + 1) * (1 - fx) + g(x0 + 1, y0 + 1) * fx) * fy;
      }
      out[(j * CW + i) * 4 + 3] = 255;
    }
    return { data: out, width: CW, height: CH };
  }
  function rot180(c) {
    const o = new Uint8ClampedArray(c.data.length), n = c.width * c.height;
    for (let p = 0; p < n; p++) { const q = n - 1 - p; for (let k = 0; k < 4; k++) o[q * 4 + k] = c.data[p * 4 + k]; }
    return { data: o, width: c.width, height: c.height };
  }

  /* ---------- descriptor of a canonical card ---------- */
  function rgb2hsv(r, g, b) {
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; let h = 0;
    if (d) { if (mx === r) h = ((g - b) / d + 6) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; }
    return [h * 60, mx ? d / mx : 0, mx / 255];
  }
  // maps: W = min channel (white glyph), K = 255-max channel (black outline). Both are colour-independent.
  function describe(card) {
    const { data, width: W, height: H } = card;
    const zx0 = W * 0.2, zx1 = W * 0.8, zy0 = H * 0.2, zy1 = H * 0.8;
    const Wm = new Float32Array(GW * GH), Km = new Float32Array(GW * GH);
    for (let gy = 0; gy < GH; gy++) for (let gx = 0; gx < GW; gx++) {
      const xa = Math.floor(zx0 + (zx1 - zx0) * gx / GW), xb = Math.max(xa + 1, Math.floor(zx0 + (zx1 - zx0) * (gx + 1) / GW));
      const ya = Math.floor(zy0 + (zy1 - zy0) * gy / GH), yb = Math.max(ya + 1, Math.floor(zy0 + (zy1 - zy0) * (gy + 1) / GH));
      let sw = 0, sk = 0, c = 0;
      for (let y = ya; y < yb; y++) for (let x = xa; x < xb; x++) { const i = (y * W + x) * 4; sw += lin(Math.min(data[i], data[i + 1], data[i + 2]), 130, 175); sk += lin(255 - Math.max(data[i], data[i + 1], data[i + 2]), 120, 170); c++; }
      Wm[gy * GW + gx] = sw / c; Km[gy * GW + gx] = sk / c;
    }
    const blur = m => { const o = new Float32Array(m.length); for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) { let s = 0, c = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if (xx >= 0 && xx < GW && yy >= 0 && yy < GH) { s += m[yy * GW + xx] * (dx || dy ? 1 : 2); c += (dx || dy ? 1 : 2); } } o[y * GW + x] = s / c; } return o; };
    const Wb = blur(Wm), Kb = blur(Km); Wm.set(Wb); Km.set(Kb);
    // energy = how much structure (glyph) the centre has
    let mw = 0, mk = 0; for (let i = 0; i < Wm.length; i++) { mw += Wm[i]; mk += Km[i]; } mw /= Wm.length; mk /= Km.length;
    let ew = 0, ek = 0; for (let i = 0; i < Wm.length; i++) { ew += (Wm[i] - mw) ** 2; ek += (Km[i] - mk) ** 2; }
    const energy = Math.sqrt((ew + ek) / (2 * Wm.length));
    // hue diversity in the inner centre
    const hb = new Float64Array(12); let tot = 0;
    for (let y = Math.round(H * 0.3); y < Math.round(H * 0.7); y++) for (let x = Math.round(W * 0.25); x < Math.round(W * 0.75); x++) {
      const i = (y * W + x) * 4, [h, s, v] = rgb2hsv(data[i], data[i + 1], data[i + 2]);
      if (s > 0.4 && v > 0.35) { hb[Math.floor(h / 30) % 12]++; tot++; }
    }
    let nHue = 0; if (tot > 40) for (let k = 0; k < 12; k++) if (hb[k] / tot > 0.07) nHue++;
    // face: fraction of bright pixels in the outer band (white border = light face, black border = dark face)
    let eb = 0, en = 0;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const dx = Math.min(x, W - 1 - x), dy = Math.min(y, H - 1 - y);
      if (Math.min(dx, dy) >= 1 && Math.min(dx, dy) <= 4) { const i = (y * W + x) * 4; if (Math.min(data[i], data[i + 1], data[i + 2]) > 185) eb++; en++; }
    }
    return { Wm, Km, energy, nHue, edge: eb / en };
  }
  function nccShift(a, b, flip) { // a,b = {Wm,Km}; best NCC over +-1 cell shifts; flip = rotate b by 180
    let best = -1;
    const get = (m, x, y) => flip ? m[(GH - 1 - y) * GW + (GW - 1 - x)] : m[y * GW + x];
    for (let sy = -2; sy <= 2; sy++) for (let sx = -2; sx <= 2; sx++) {
      let tot = 0;
      for (const key of ['Wm', 'Km']) {
        let n = 0, ma = 0, mb = 0;
        for (let y = 2; y < GH - 2; y++) for (let x = 2; x < GW - 2; x++) { ma += a[key][y * GW + x]; mb += get(b[key], x + sx, y + sy); n++; }
        ma /= n; mb /= n; let sab = 0, saa = 0, sbb = 0;
        for (let y = 2; y < GH - 2; y++) for (let x = 2; x < GW - 2; x++) { const u = a[key][y * GW + x] - ma, v = get(b[key], x + sx, y + sy) - mb; sab += u * v; saa += u * u; sbb += v * v; }
        tot += saa > 1 && sbb > 1 ? sab / Math.sqrt(saa * sbb) : 0;
      }
      if (tot / 2 > best) best = tot / 2;
    }
    return best;
  }

  /* ---------- classification ---------- */
  const isLightId = id => id.startsWith('num_') || id.startsWith('light_');
  const WILDS = ['light_wild', 'dark_wild'];
  function classify(card, refs) {
    const d = describe(card), light = d.edge > 0.12, wildLike = d.nHue >= 4;
    const res = [];
    for (const id in refs) {
      const r = refs[id];
      let s;
      if (isLightId(id) !== light) { res.push({ id, score: -1, rot: 0 }); continue; } // wrong face
      const rd = { Wm: Float32Array.from(r.Wm), Km: Float32Array.from(r.Km) };
      if (r.plain) { // plain wild: no glyph, many colours
        s = (d.energy < 25 ? 0.7 : 0.2) + (wildLike ? 0.3 : -0.4); res.push({ id, score: s, rot: 0 }); continue;
      }
      const s0 = nccShift(d, rd, false), s1 = nccShift(d, rd, true), rot = s1 > s0 ? 180 : 0;
      s = Math.max(s0, s1);
      if (r.nHue >= 4) s += wildLike ? 0.1 : -0.15; else s += wildLike ? -0.15 : 0;
      res.push({ id, score: s, rot });
    }
    res.sort((a, b) => b.score - a.score);
    return { best: res[0], second: res[1], list: res.slice(0, 3), light };
  }

  /* ---------- main entry ---------- */
  function analyze(img, refs) {
    const { width: W, height: H } = img;
    const mask = segment(img), comps = components(mask, W, H);
    const minA = W * H * 0.0015;
    let big = comps.filter(c => c.length >= minA);
    if (!big.length) return { cards: [], warnings: ['no_cards'] };
    const med = median(big.map(c => c.length));
    big = big.filter(c => c.length >= med * 0.35);
    const med2 = median(big.map(c => c.length));
    const cards = [], warnings = [];
    for (const c of big) {
      const o = orient(c, W), aspect = o.hv / o.wu, fill = o.area / (o.wu * o.hv);
      const touchesEdge = c.some(p => { const x = p % W, y = (p / W) | 0; return x < 2 || y < 2 || x >= W - 2 || y >= H - 2; });
      const flags = [];
      if (o.area > med2 * 1.6) flags.push('overlap');
      else if (fill < 0.86 || aspect < 1.25 || aspect > 1.85) flags.push('odd_shape');
      if (touchesEdge) flags.push('cut');
      const item = { cx: o.mx, cy: o.my, area: o.area, flags, estCount: Math.max(1, Math.round(o.area / med2)) };
      if (!flags.includes('overlap')) {
        const cardImg = warp(img, o), cl = classify(cardImg, refs);
        item.thumb = (cl.best.rot ? rot180(cardImg) : cardImg);
        item.id = cl.best.id; item.score = cl.best.score; item.margin = cl.best.score - cl.second.score; item.alts = cl.list.map(x => x.id);
        if (item.score < 0.5 || item.margin < 0.07) flags.push('uncertain');
      }
      cards.push(item);
    }
    // reading order: rows top-to-bottom, then left-to-right
    cards.sort((a, b) => (Math.round(a.cy / (H / 6)) - Math.round(b.cy / (H / 6))) || (a.cx - b.cx));
    return { cards, warnings, mask };
  }

  /* ---------- build reference descriptor from a reference image ---------- */
  function refFromImage(img, padFrac) { // img = whole reference picture (RGBA); padFrac = white border to add (light-face cards)
    const { data, width: W, height: H } = img;
    const corner = [[0, 0], [W - 1, 0], [0, H - 1], [W - 1, H - 1]].map(([x, y]) => { const i = (y * W + x) * 4; return [data[i], data[i + 1], data[i + 2]]; });
    const bg = [0, 1, 2].map(c => median(corner.map(p => p[c])));
    let x0 = W, x1 = -1, y0 = H, y1 = -1;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4;
      if (Math.max(Math.abs(data[i] - bg[0]), Math.abs(data[i + 1] - bg[1]), Math.abs(data[i + 2] - bg[2])) > 40) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    }
    const pad = (padFrac || 0) * (x1 - x0), hw = (x1 - x0) / 2 + pad, hh = (y1 - y0) / 2 + pad;
    const o = { mx: (x0 + x1) / 2, my: (y0 + y1) / 2, eu: [1, 0], ev: [0, 1], umin: -hw, umax: hw, vmin: -hh, vmax: hh };
    const d = describe(warp(img, o));
    const r2 = a => Array.from(a, v => Math.round(v * 10) / 10);
    return { Wm: r2(d.Wm), Km: r2(d.Km), energy: +d.energy.toFixed(1), nHue: d.nHue, plain: d.energy < 25 && d.nHue >= 4 };
  }

  const api = { analyze, refFromImage, describe, warp, CW, CH };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.UnoScan = api;
})(typeof window !== 'undefined' ? window : globalThis);
