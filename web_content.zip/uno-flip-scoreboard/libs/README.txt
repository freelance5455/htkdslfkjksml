لتعمل بدون انترنت: نزّل هذه الملفات وضعها بهذه الأسماء بالضبط:

1) https://cdn.tailwindcss.com                                   -> libs/tailwind.js
2) https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js   -> libs/alpine.min.js
3) https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css -> libs/css/all.min.css
4) https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/webfonts/fa-solid-900.woff2 -> libs/webfonts/fa-solid-900.woff2
