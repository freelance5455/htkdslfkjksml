# v1.52.3 — Limite de carreira 2049

- Define 2026 como a temporada inicial aos 17 anos.
- Permite jogar as temporadas de 2026 até 2049, totalizando 24 temporadas.
- Encerra a carreira ao concluir a temporada 2049/aos 40 anos, tanto no profissional quanto no Sub-20.
- Impede iniciar uma temporada posterior a 2049 e preserva o histórico de carreira.
- O Sub-20 não oferece a escolha de continuar ou subir ao profissional depois do limite de idade/ano.
