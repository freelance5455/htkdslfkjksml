const $ = id => document.getElementById(id);
let accessCode = sessionStorage.getItem('novaAccessCode') || '';
const api = async (url, options={}) => {
  const response = await fetch(url, { ...options, headers: { 'Content-Type':'application/json', 'x-app-access-code':accessCode, ...(options.headers||{}) } });
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || 'حدث خطأ في الاتصال.');
  return data;
};
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function setStatus(ok){$('connection').innerHTML = `<i></i>${ok?'متصل بالخادم':'غير متصل'}`;$('connection').className=`status ${ok?'online':''}`;}
function showLoginError(message){$('loginError').textContent=message;}
async function login(){
  accessCode=$('accessCode').value.trim();if(!accessCode)return showLoginError('أدخل رمز الدخول أولاً.');
  $('loginBtn').disabled=true;showLoginError('');
  try{const status=await api('/api/status');sessionStorage.setItem('novaAccessCode',accessCode);$('loginCard').hidden=true;$('appView').hidden=false;setStatus(true);await loadAll();if(!status.configured)alert('تم الاتصال بالخادم، لكن مفتاح Telnyx لم يُضف بعد.');}
  catch(e){setStatus(false);showLoginError(e.message);}
  finally{$('loginBtn').disabled=false;}
}
async function loadNumbers(){
  const rows=await api('/api/numbers');$('numberCount').textContent=rows.length;
  $('numbersList').innerHTML=rows.length?rows.map(n=>`<div class="number-row"><div><b>${escapeHtml(n.phoneNumber)}</b><small>${escapeHtml(n.status||'الحالة غير محددة')}</small></div><span class="pill">SMS</span></div>`).join(''):'<div class="empty-state">لا توجد أرقام مملوكة في حساب Telnyx حتى الآن.</div>';
}
async function loadMessages(){
  const rows=await api('/api/messages');$('messageCount').textContent=rows.length;
  $('messagesList').innerHTML=rows.length?rows.map(m=>`<article class="message-row"><div class="message-top"><b>${escapeHtml(m.from)}</b><small>${new Date(m.receivedAt).toLocaleString('ar')}</small></div><div class="message-text">${escapeHtml(m.text)}</div><small>إلى ${escapeHtml(m.to)}</small></article>`).join(''):'<div class="empty-state">لا توجد رسائل بعد. تأكد من تفعيل استقبال SMS وإعداد Webhook.</div>';
}
async function loadAll(){try{await Promise.all([loadNumbers(),loadMessages()]);setStatus(true);}catch(e){setStatus(false);showLoginError(e.message);}}
async function searchNumbers(){
  const btn=$('searchBtn');btn.disabled=true;btn.textContent='جارٍ البحث عن الأرقام…';
  try{const rows=await api('/api/available');$('availableList').innerHTML=rows.length?rows.map(n=>`<div class="number-row"><div><b>${escapeHtml(n.phoneNumber)}</b><small>أمريكي · SMS متاح · راجع السعر في Telnyx</small></div><button class="buy" data-number="${escapeHtml(n.phoneNumber)}">طلب الرقم</button></div>`).join(''):'<div class="empty-state">لم تظهر أرقام متاحة في البحث الحالي.</div>';document.querySelectorAll('[data-number]').forEach(b=>b.addEventListener('click',()=>orderNumber(b.dataset.number,b)));}
  catch(e){$('availableList').innerHTML=`<div class="empty-state">${escapeHtml(e.message)}</div>`;}
  finally{btn.disabled=false;btn.innerHTML='ابحث عن أرقام متاحة <span>⌕</span>';}
}
async function orderNumber(number,button){
  if(!confirm(`طلب ${number} قد يسبب رسوماً شهرية ورسوم رسائل وضرائب. راجع السعر والتوفر في لوحة Telnyx. هل تريد إرسال الطلب؟`))return;
  button.disabled=true;button.textContent='جارٍ الطلب…';
  try{await api('/api/order',{method:'POST',body:JSON.stringify({phoneNumber:number})});alert('أُرسل طلب الرقم إلى Telnyx. تابع حالة الطلب في لوحة Telnyx.');await loadNumbers();}
  catch(e){alert(e.message);button.disabled=false;button.textContent='طلب الرقم';}
}
$('loginBtn').addEventListener('click',login);$('accessCode').addEventListener('keydown',e=>{if(e.key==='Enter')login();});$('refreshBtn').addEventListener('click',loadAll);$('messagesRefresh').addEventListener('click',loadMessages);$('searchBtn').addEventListener('click',searchNumbers);
if(accessCode){$('accessCode').value=accessCode;login();}
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
