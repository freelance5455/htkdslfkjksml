import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import Telnyx from 'telnyx';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, 'data');
const MESSAGES_FILE = path.join(DATA_DIR, 'messages.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
let messages = [];
try { messages = JSON.parse(fs.readFileSync(MESSAGES_FILE, 'utf8')); } catch { messages = []; }
const saveMessages = () => fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages.slice(-1000), null, 2));
let telnyx;
function getTelnyx() {
  if (!process.env.TELNYX_API_KEY) throw new Error('أضف TELNYX_API_KEY إلى إعدادات الخادم.');
  if (!telnyx) telnyx = new Telnyx({ apiKey: process.env.TELNYX_API_KEY });
  return telnyx;
}
function requireAppCode(req, res, next) {
  const expected = process.env.APP_ACCESS_CODE || '';
  const supplied = req.get('x-app-access-code') || '';
  if (!expected) return res.status(503).json({ error: 'الخادم غير مكتمل الإعداد: APP_ACCESS_CODE مفقود.' });
  const a = Buffer.from(supplied), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'رمز دخول التطبيق غير صحيح.' });
  next();
}

// Verify Telnyx webhook signatures using the raw request body before parsing JSON.
app.post('/webhooks/telnyx', express.raw({ type: 'application/json' }), (req, res) => {
  try {
    if (!process.env.TELNYX_PUBLIC_KEY) return res.status(503).send('Webhook public key is not configured');
    const event = getTelnyx().webhooks.unwrap(req.body, { headers: req.headers });
    const payload = event?.data?.payload;
    if (event?.data?.event_type === 'message.received' && payload?.direction === 'inbound') {
      const id = payload.id || `${Date.now()}-${crypto.randomUUID()}`;
      if (!messages.some(m => m.id === id)) {
        messages.push({
          id,
          from: payload.from?.phone_number || 'غير معروف',
          to: payload.to?.[0]?.phone_number || 'غير معروف',
          text: payload.text || '',
          receivedAt: payload.received_at || new Date().toISOString()
        });
        messages = messages.slice(-1000);
        saveMessages();
      }
    }
    return res.sendStatus(200);
  } catch (error) {
    console.error('Webhook verification failed:', error.message);
    return res.status(400).send('Invalid webhook');
  }
});

app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/api/status', requireAppCode, (req, res) => res.json({
  configured: Boolean(process.env.TELNYX_API_KEY),
  webhookConfigured: Boolean(process.env.TELNYX_PUBLIC_KEY),
  app: 'Nova Numbers 2.0'
}));
app.get('/api/numbers', requireAppCode, async (req, res) => {
  try {
    const result = await getTelnyx().phoneNumbers.list({ 'page[size]': 100 });
    res.json((result.data || []).map(n => ({ id: n.id, phoneNumber: n.phone_number, status: n.status, connectionName: n.connection_name || '' })));
  } catch (e) { res.status(502).json({ error: e.message || 'تعذر جلب الأرقام من Telnyx.' }); }
});
app.get('/api/available', requireAppCode, async (req, res) => {
  try {
    const result = await getTelnyx().availablePhoneNumbers.list({ filter: { country_code: 'US', features: ['sms'], limit: 20 } });
    res.json((result.data || []).map(n => ({ phoneNumber: n.phone_number, type: n.phone_number_type || 'US', features: n.features || [], cost: n.cost_information || n.cost || null })));
  } catch (e) { res.status(502).json({ error: e.message || 'تعذر البحث عن أرقام متاحة.' }); }
});
app.post('/api/order', requireAppCode, async (req, res) => {
  const phoneNumber = String(req.body?.phoneNumber || '');
  if (!/^\+1\d{10}$/.test(phoneNumber)) return res.status(400).json({ error: 'رقم أمريكي غير صالح.' });
  try {
    const result = await getTelnyx().numberOrders.create({ phone_numbers: [{ phone_number: phoneNumber }] });
    res.json({ ok: true, order: result.data || result });
  } catch (e) { res.status(502).json({ error: e.message || 'تعذر إرسال طلب الرقم.' }); }
});
app.get('/api/messages', requireAppCode, (req, res) => {
  const number = String(req.query.number || '');
  const rows = number ? messages.filter(m => m.to === number) : messages;
  res.json(rows.slice(-250).reverse());
});
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`Nova Numbers 2.0 listening on ${PORT}`));
