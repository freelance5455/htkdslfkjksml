// Palmas Bot Música: fica de prontidão (fora da sala) olhando os pedidos no Firestore.
// Quando alguém pede uma música, entra na sala "palmas-musica" do LiveKit, toca a fila e sai
// depois de um tempo sem pedidos (ou sem ouvintes). Veja LEIA-ME.md.
import { AccessToken } from "livekit-server-sdk";
import { Room, RoomEvent, AudioSource, AudioFrame, LocalAudioTrack, TrackPublishOptions, TrackSource } from "@livekit/rtc-node";
import { initializeApp, cert, applicationDefault } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { spawn } from "node:child_process";
import { readFileSync } from "node:fs";
import dns from "node:dns/promises";
import net from "node:net";

const URL_LK = process.env.LIVEKIT_URL, KEY = process.env.LIVEKIT_API_KEY, SECRET = process.env.LIVEKIT_API_SECRET;
const SALA = process.env.SALA || "palmas-musica";
const MAX_SEG = +process.env.MAX_SEG || 900;          // corta cada faixa em 15 min
const SAI_APOS = (+process.env.SAI_APOS_SEG || 90) * 1000; // sai da sala depois de tanto tempo sem pedidos
const SOZINHO = (+process.env.SOZINHO_SEG || 10) * 1000; // sai da call se ficar sozinho nela por tanto tempo
const HOSTS = (process.env.ALLOWED_HOSTS || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
if (!URL_LK || !KEY || !SECRET) { console.error("Faltam LIVEKIT_URL, LIVEKIT_API_KEY ou LIVEKIT_API_SECRET."); process.exit(1); }

initializeApp({ credential: process.env.FIREBASE_SERVICE_ACCOUNT ? cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)) : applicationDefault() });
const db = getFirestore();

let playlist = [];
try {
  playlist = JSON.parse(readFileSync(new URL("./playlist.json", import.meta.url), "utf8"))
    .filter((x) => x && typeof x.t === "string" && /^https:\/\//.test(x.url || ""));
} catch (e) { console.warn("playlist.json não lido:", e.message); }
// o app lê esta lista (só os títulos) para mostrar os botões da playlist
db.doc("palmas_music_cfg/catalogo").set({ lista: playlist.map((x) => x.t.slice(0, 60)) }).catch((e) => console.warn("catálogo:", e.message));

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const est = { atual: null, pausado: false };
let room = null, source = null, conectado = false, pular = null, pend = [];
const feitos = new Set();

// ---------- pedidos ----------
db.collection("palmas_music_req").orderBy("ts").onSnapshot((sn) => {
  pend = sn.docs.map((d) => ({ id: d.id, ref: d.ref, ...d.data() }));
  pub();
}, (e) => console.error("pedidos:", e.message));
const fila = () => pend.filter((x) => !feitos.has(x.id));
const idade = (x) => Date.now() - (x.ts && x.ts.toMillis ? x.ts.toMillis() : Date.now());

// ---------- segurança de link (só vale para pedidos por link) ----------
function privado(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }
  const x = ip.toLowerCase();
  return x === "::1" || x === "::" || x.startsWith("fc") || x.startsWith("fd") || x.startsWith("fe80") || x.startsWith("::ffff:");
}
async function urlOk(s) {
  let u; try { u = new URL(s); } catch { return "Link inválido."; }
  if (u.protocol !== "https:" || u.username || u.password) return "Só links https simples são aceitos.";
  const h = u.hostname.toLowerCase();
  if (net.isIP(h)) return "Endereço IP não é aceito.";
  if (HOSTS.length && !HOSTS.some((d) => h === d || h.endsWith("." + d))) return "Esse site não está liberado.";
  try { const r = await dns.lookup(h, { all: true }); if (!r.length || r.some((x) => privado(x.address))) return "Endereço não permitido."; }
  catch { return "Não achei esse endereço."; }
  return "";
}

// ---------- busca na internet (só fontes onde a música é liberada) ----------
// Audius (músicas de artistas independentes), Jamendo (Creative Commons; precisa de JAMENDO_CLIENT_ID)
// e Radio Browser (rádios online: escreva "rádio" + nome). YouTube/Spotify NÃO são usados.
const APP = "PalmasBR", JAMENDO = process.env.JAMENDO_CLIENT_ID || "";
async function json(u) {
  const r = await fetch(u, { signal: AbortSignal.timeout(8000), headers: { "User-Agent": "PalmasBR-bot/1.0" } });
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.json();
}
async function seguro(s, http) { // confere protocolo e se o endereço não é interno
  let u; try { u = new URL(s); } catch { return false; }
  if (!(u.protocol === "https:" || (http && u.protocol === "http:")) || u.username || u.password) return false;
  const h = u.hostname.toLowerCase();
  if (net.isIP(h)) return false;
  try { const r = await dns.lookup(h, { all: true }); return r.length > 0 && !r.some((x) => privado(x.address)); } catch { return false; }
}
async function achar(q) {
  q = q.trim();
  const radio = /^r[áa]dio\s+(.+)/i.exec(q);
  try {
    if (radio) {
      const L = await json("https://de1.api.radio-browser.info/json/stations/byname/" + encodeURIComponent(radio[1]) + "?limit=8&order=votes&reverse=true&hidebroken=true");
      for (const x of L) { const u = x.url_resolved || x.url; if (u && await seguro(u, true)) return { url: u, t: "Rádio " + String(x.name).trim().slice(0, 50), http: u.startsWith("http:") }; }
      return null;
    }
    const A = await json("https://api.audius.co/v1/tracks/search?limit=8&app_name=" + APP + "&query=" + encodeURIComponent(q));
    for (const x of (A.data || [])) {
      if (x.is_streamable === false || (x.access && x.access.stream === false)) continue;
      return { url: "https://api.audius.co/v1/tracks/" + x.id + "/stream?app_name=" + APP, t: ((x.user && x.user.name ? x.user.name + " - " : "") + x.title).slice(0, 60) };
    }
    if (JAMENDO) {
      const J = await json("https://api.jamendo.com/v3.0/tracks/?format=json&limit=5&audioformat=mp32&client_id=" + JAMENDO + "&search=" + encodeURIComponent(q));
      for (const x of (J.results || [])) if (x.audio && await seguro(x.audio, false)) return { url: x.audio, t: (x.artist_name + " - " + x.name).slice(0, 60) };
    }
  } catch (e) { console.warn("busca:", e.message); }
  return null;
}

// ---------- dados para os aparelhos ----------
function enviar(obj, topic, para) {
  if (!conectado || !room) return;
  try {
    const o = { reliable: true, topic };
    if (para) o.destination_identities = [para];
    room.localParticipant.publishData(new TextEncoder().encode(JSON.stringify(obj)), o);
  } catch (e) { console.warn("publishData:", e.message); }
}
function pub() {
  enviar({
    atual: est.atual ? { t: est.atual.t, por: est.atual.por, uid: est.atual.uid } : null,
    fila: fila().filter((x) => !est.atual || x.id !== est.atual.id).map((x) => ({ t: x.t, por: x.n })),
    pausado: est.pausado,
  }, "estado");
}
const aviso = (id, msg) => id && enviar({ msg }, "aviso", id);

function onCmd(m, p) {
  if (!p) return;
  const admin = p.attributes && p.attributes.admin === "1", c = m && m.c;
  if (c === "pular") { if (est.atual && (admin || est.atual.uid === p.identity) && pular) pular(); }
  else if (!admin) return;
  else if (c === "pausar") { est.pausado = true; pub(); }
  else if (c === "retomar") { est.pausado = false; pub(); }
  else if (c === "parar") { fila().forEach((x) => { feitos.add(x.id); x.ref.delete().catch(() => {}); }); if (pular) pular(); pub(); }
}

// ---------- entrar e sair da sala ----------
async function entrar() {
  if (conectado) return true;
  try {
    const at = new AccessToken(KEY, SECRET, { identity: "palmas-bot", name: "Palmas Bot", ttl: "6h", attributes: { bot: "1" } });
    at.addGrant({ room: SALA, roomJoin: true, canPublish: true, canSubscribe: true, canPublishData: true });
    room = new Room();
    room.on(RoomEvent.DataReceived, (payload, p, _k, topic) => {
      if (topic !== "cmd") return;
      let m; try { m = JSON.parse(Buffer.from(payload).toString()); } catch { return; }
      onCmd(m, p);
    });
    room.on(RoomEvent.ParticipantConnected, () => setTimeout(pub, 1200));
    room.on(RoomEvent.Disconnected, () => { conectado = false; if (pular) pular(); });
    await room.connect(URL_LK, await at.toJwt(), { autoSubscribe: false, dynacast: false });
    source = new AudioSource(48000, 1, 300);
    await room.localParticipant.publishTrack(LocalAudioTrack.createAudioTrack("musica", source), new TrackPublishOptions({ source: TrackSource.SOURCE_MICROPHONE }));
    conectado = true; console.log("Bot entrou na sala", SALA); pub();
    return true;
  } catch (e) { console.warn("não consegui entrar:", e.message); try { await room.disconnect(); } catch {} conectado = false; return false; }
}
async function sair() {
  if (!room) return;
  est.atual = null; est.pausado = false;
  try { await room.disconnect(); } catch {}
  conectado = false; room = null; console.log("Bot saiu da sala");
}

// ---------- tocar uma faixa ----------
async function tocar(it, url, http) {
  est.atual = { id: it.id, t: it.t, por: it.n, uid: it.uid }; est.pausado = false; pub();
  const ff = spawn("ffmpeg", [
    "-hide_banner", "-loglevel", "error", "-protocol_whitelist", http ? "http,https,tls,tcp,crypto" : "https,tls,tcp,crypto",
    "-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "5",
    "-i", url, "-t", String(MAX_SEG), "-vn", "-f", "s16le", "-ar", "48000", "-ac", "1", "pipe:1",
  ], { stdio: ["ignore", "pipe", "pipe"] });
  let cancel = false, errTxt = "", n = 0, acc = Buffer.alloc(0), t0 = Date.now();
  pular = () => { cancel = true; try { ff.kill("SIGKILL"); } catch {} };
  ff.stderr.on("data", (d) => { if (errTxt.length < 300) errTxt += d.toString(); });
  const FR = 960; // 10 ms de áudio mono 48 kHz
  try {
    for await (const chunk of ff.stdout) {
      acc = acc.length ? Buffer.concat([acc, chunk]) : chunk;
      while (acc.length >= FR && !cancel) {
        if (est.pausado) { while (est.pausado && !cancel) await sleep(100); t0 = Date.now() - n * 10; }
        if (cancel) break;
        const espera = t0 + n * 10 - Date.now() - 250;
        if (espera > 0) await sleep(espera);
        const i16 = new Int16Array(480);
        Buffer.from(i16.buffer).set(acc.subarray(0, FR));
        acc = acc.subarray(FR);
        await source.captureFrame(new AudioFrame(i16, 48000, 1, 480));
        n++;
      }
      if (cancel) break;
    }
    if (!cancel && n > 0) await source.waitForPlayout();
  } catch (e) { console.warn("erro tocando:", e.message); }
  if (pular) pular(); pular = null;
  if (n === 0) { console.warn("Não consegui tocar:", it.t, errTxt.trim().slice(0, 200)); aviso(it.uid, "Não consegui tocar essa música (o link precisa ser áudio direto)."); }
  est.atual = null; pub();
}

// ---------- laço principal ----------
let ocioDesde = Date.now();
async function laco() {
  for (;;) {
    // pedidos velhos (bot ficou fora do ar) são descartados
    pend.filter((x) => idade(x) > 30 * 60000 && !feitos.has(x.id)).forEach((x) => { feitos.add(x.id); x.ref.delete().catch(() => {}); });
    const it = fila()[0];
    if (!it) {
      if (conectado && Date.now() - ocioDesde > SAI_APOS) await sair();
      await sleep(700); continue;
    }
    ocioDesde = Date.now();
    if (!(await entrar())) { await sleep(4000); continue; }
    // sem ninguém na sala: o vigia (abaixo) tira o bot da call; aqui só não toca para a sala vazia
    if (room.remoteParticipants.size === 0) { await sleep(1000); continue; }
    let url = it.url, t = it.t, http = false;
    if (it.q) {
      const r = await achar(it.q);
      if (!r) { aviso(it.uid, "Não encontrei \"" + String(it.q).slice(0, 40) + "\" nas fontes livres."); feitos.add(it.id); it.ref.delete().catch(() => {}); continue; }
      url = r.url; t = r.t; http = !!r.http;
    } else if (typeof it.i === "number") { const p = playlist[it.i]; if (!p) { feitos.add(it.id); it.ref.delete().catch(() => {}); continue; } url = p.url; t = p.t; }
    else { const er = await urlOk(url); if (er) { aviso(it.uid, er); feitos.add(it.id); it.ref.delete().catch(() => {}); continue; } }
    it.t = t;
    await tocar(it, url, http);
    feitos.add(it.id); it.ref.delete().catch(() => {});
    ocioDesde = Date.now();
    if (feitos.size > 500) feitos.clear();
  }
}
// Vigia: se todo mundo sair da call e o bot ficar sozinho, ele para a música, limpa a fila e sai sozinho.
let sozinhoDesde = 0;
setInterval(async () => {
  if (!conectado || !room) { sozinhoDesde = 0; return; }
  if (room.remoteParticipants.size > 0) { sozinhoDesde = 0; return; }
  sozinhoDesde = sozinhoDesde || Date.now();
  if (Date.now() - sozinhoDesde < SOZINHO) return;
  sozinhoDesde = 0;
  console.log("Ficou sozinho na sala: saindo.");
  fila().forEach((x) => { feitos.add(x.id); x.ref.delete().catch(() => {}); });
  if (pular) pular();
  await sair();
}, 1000);
laco();
