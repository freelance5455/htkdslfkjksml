# Palmas Bot Música

Fica ligado de prontidão (fora da sala). Quando alguém pede uma música no app (nome, artista, rádio ou link), ele procura na internet, entra na
sala "Música" do LiveKit, toca a fila e sai depois de ~90 s sem pedidos.
Guia completo: `../docs/SALA-DE-MUSICA.md`.

Rodar no seu computador (precisa de Node 20.6+ e ffmpeg instalado):

    cd music-bot
    npm install
    cp .env.example .env     # preencha as chaves do LiveKit e do Firebase
    npm start

Playlist: edite `playlist.json` (links https diretos de áudio). Os títulos viram botões no app:

    [ { "t": "Nome da música", "url": "https://seu-site.com/musica.mp3" } ]

Use só músicas que você tem direito de tocar (suas, livres de direitos ou com licença).
