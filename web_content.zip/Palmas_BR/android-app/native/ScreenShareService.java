package br.palmas.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import android.util.DisplayMetrics;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

/** Serviço em primeiro plano que captura a tela (MediaProjection) e guarda o último quadro em JPEG. */
public class ScreenShareService extends Service {
    static volatile boolean running = false;
    static volatile boolean stopped = false;
    static volatile String frame = "";
    static volatile int seq = 0;
    static volatile int outW = 0, outH = 0;

    private static final String CH = "palmas_screen";
    private static final int MAX_SIDE = 1100;
    private static final int MIN_GAP_MS = 110;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Bitmap bmp;
    private long last = 0;
    private boolean closing = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        if (in == null || "stop".equals(in.getAction())) {
            shutdown();
            return START_NOT_STICKY;
        }
        closing = false;
        startAsForeground();
        try {
            int rc = in.getIntExtra("rc", 0);
            Intent data = in.getParcelableExtra("data");
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = m.getMediaProjection(rc, data);
            // Obrigatório no Android 14+: registrar o callback antes de criar o display virtual.
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { shutdown(); }
            }, new Handler(Looper.getMainLooper()));

            DisplayMetrics dm = getResources().getDisplayMetrics();
            float sc = Math.min(1f, (float) MAX_SIDE / Math.max(dm.widthPixels, dm.heightPixels));
            final int w = Math.max(2, (int) (dm.widthPixels * sc) & ~1);
            final int h = Math.max(2, (int) (dm.heightPixels * sc) & ~1);
            outW = w; outH = h;

            thread = new HandlerThread("palmas-screen");
            thread.start();
            Handler bg = new Handler(thread.getLooper());
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
            reader.setOnImageAvailableListener(r -> {
                Image img = null;
                try {
                    img = r.acquireLatestImage();
                    if (img == null) return;
                    long now = SystemClock.elapsedRealtime();
                    if (now - last < MIN_GAP_MS) return;
                    last = now;
                    Image.Plane p = img.getPlanes()[0];
                    ByteBuffer buf = p.getBuffer();
                    int px = p.getPixelStride();
                    int pad = (p.getRowStride() - px * w) / px;
                    if (bmp == null) bmp = Bitmap.createBitmap(w + pad, h, Bitmap.Config.ARGB_8888);
                    bmp.copyPixelsFromBuffer(buf);
                    Bitmap out = pad == 0 ? bmp : Bitmap.createBitmap(bmp, 0, 0, w, h);
                    ByteArrayOutputStream bo = new ByteArrayOutputStream(64 * 1024);
                    out.compress(Bitmap.CompressFormat.JPEG, 60, bo);
                    frame = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
                    seq++;
                } catch (Exception ignored) {
                } finally {
                    if (img != null) img.close();
                }
            }, bg);
            display = projection.createVirtualDisplay("palmas-screen", w, h, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, bg);
            running = true;
            stopped = false;
        } catch (Exception e) {
            shutdown();
        }
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Compartilhamento de tela", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CH);
        } else {
            b = new Notification.Builder(this);
        }
        Notification n = b.setContentTitle("Palmas BR")
                .setContentText("Você está compartilhando a tela")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(4711, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(4711, n);
        }
    }

    private void shutdown() {
        if (closing) return;
        closing = true;
        running = false;
        stopped = true;
        try { if (display != null) display.release(); } catch (Exception ignored) {}
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        try { if (thread != null) thread.quitSafely(); } catch (Exception ignored) {}
        display = null; reader = null; projection = null; thread = null; bmp = null;
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() { if (running) shutdown(); super.onDestroy(); }
}
