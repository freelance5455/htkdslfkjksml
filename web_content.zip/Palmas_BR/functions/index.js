// Envia aviso (push) para quem foi marcado com @ numa mensagem do Palmas BR.
// Requer plano Blaze. Deploy: firebase deploy --only functions
const {onDocumentCreated}=require("firebase-functions/v2/firestore");
const admin=require("firebase-admin");
admin.initializeApp();
exports.palmasMencoes=onDocumentCreated("palmas_msgs/{id}",async(ev)=>{
  const m=ev.data&&ev.data.data();if(!m)return;
  const quem=(m.mn||[]).filter(u=>typeof u==="string"&&u!==m.u).slice(0,5);if(!quem.length)return;
  const snaps=await Promise.all(quem.map(u=>admin.firestore().doc("palmas_users/"+u).get()));
  const tokens=[];snaps.forEach(s=>{if(s.exists)(s.data().fcm||[]).forEach(t=>tokens.push(t))});
  if(!tokens.length)return;
  const fig=/^\[figurinha:/.test(m.x||"");
  await admin.messaging().sendEachForMulticast({tokens:tokens.slice(0,200),data:{title:(m.n||m.u)+" te marcou",body:fig?"enviou uma figurinha":String(m.x||"").slice(0,120),ch:String(m.ch||"")},webpush:{headers:{Urgency:"high",TTL:"3600"}}});
});


// ===== Filtro de palavrões da comunidade oficial: censura no servidor, conta avisos e bane no 4º =====
// Mantenha a lista igual à BADWORDS do index.html. Requer plano Blaze. Deploy: firebase deploy --only functions
const BAD=["puta","puto","putaria","putinha","caralho","karalho","krl","crl","porra","merda","bosta","buceta","boceta","bct","cuzao","cu","foda","foder","fodase","fodido","fodida","fdp","vsf","vtnc","pqp","tnc","pnc","arrombado","arrombada","viado","viadinho","piranha","vagabunda","vagabundo","fuck","fucking","shit","bitch","asshole","dick","pussy","cunt"];
const BAN_AT=4,CANAIS=["rg","an","fc","sr","cg","lm","su"];
const LET={a:"[a4@àáâãä]",e:"[e3éèêë]",i:"[i1!íìîï]",o:"[o0óòôõö]",u:"[uúùûü]",s:"[s5$z]",c:"[cçk]",k:"[kcq]",t:"[t7]"};
const RX=new RegExp("(^|[^a-zA-Z0-9À-ÿ])((?:"+BAD.map(w=>w.split("").map(ch=>(LET[ch]||ch)+"+").join("[._\\-*]*")).join("|")+")s?)(?![a-zA-Z0-9À-ÿ])","gi");
function censura(t){let hit=0;const out=String(t).replace(RX,(a,pre,w)=>{hit++;return pre+w.charAt(0)+"*".repeat(w.length-1)});return{t:out,hit};}
exports.palmasFiltro=onDocumentCreated("palmas_msgs/{id}",async(ev)=>{
  const m=ev.data&&ev.data.data();if(!m||m.pub!==true||!CANAIS.includes(m.ch)||typeof m.x!=="string"||typeof m.u!=="string")return;
  const c=censura(m.x);if(!c.hit)return;
  const db=admin.firestore();
  await ev.data.ref.update({x:c.t,cz:true});
  if((await db.doc("palmas_admins/"+m.u).get()).exists)return; // ADM é censurado, mas não leva aviso
  const w=db.doc("palmas_warns/"+m.u);
  const n=await db.runTransaction(async t=>{const s=await t.get(w);const k=(s.exists?(s.data().n||0):0)+1;t.set(w,{n:k,last:admin.firestore.FieldValue.serverTimestamp()});return k;});
  if(n>=BAN_AT)await db.doc("palmas_bans/"+m.u).set({by:"palmas_bot",t:admin.firestore.FieldValue.serverTimestamp(),why:"palavrões"});
});

// ===== Aviso (push) de toda mensagem nova nos canais da comunidade, com o app fechado =====
// Quem mandou aparece no título: "Fulano em #Geral". Quem escolheu "Somente @menções" ou "Nada" (campo pn) não recebe.
// Quem foi marcado já recebe o aviso de menção (palmasMencoes), então não duplica aqui.
const NOTIF_CANAIS={cg:"Geral",an:"Anúncios",fc:"Financiamento Coletivo",sr:"Sorteio",lm:"Links & Mídia"};
exports.palmasCanais=onDocumentCreated("palmas_msgs/{id}",async(ev)=>{
  const m=ev.data&&ev.data.data();
  if(!m||m.pub!==true||!NOTIF_CANAIS[m.ch]||typeof m.u!=="string"||m.u==="@bot")return;
  const marcados=new Set((m.mn||[]).filter(u=>typeof u==="string"));
  const snap=await admin.firestore().collection("palmas_users").select("fcm","pn").get();
  const tokens=[];
  snap.forEach(d=>{
    if(d.id===m.u||marcados.has(d.id))return;
    const x=d.data();if(x.pn==="mn"||x.pn==="none")return;
    (x.fcm||[]).forEach(t=>{if(typeof t==="string")tokens.push(t)});
  });
  if(!tokens.length)return;
  const fig=/^\[figurinha:/.test(m.x||"");
  const data={title:(m.n||m.u)+" em #"+NOTIF_CANAIS[m.ch],body:fig?"enviou uma figurinha":String(m.x||"").slice(0,120),ch:String(m.ch)};
  for(let i=0;i<tokens.length;i+=500){
    await admin.messaging().sendEachForMulticast({tokens:tokens.slice(i,i+500),data,webpush:{headers:{Urgency:"high",TTL:"3600"}}});
  }
});


// ===== Figurinhas de servidor: triagem automática (opcional) =====
// Toda figurinha nova nasce "pend". Esta função olha a imagem com o Google Cloud Vision e RECUSA sozinha
// se achar conteúdo adulto/violento ou texto/link escrito dentro da imagem. O que passar continua "pend":
// quem aprova é sempre um ADM (Moderação > Figurinhas). Se o Vision não estiver ligado, nada quebra: fica para o ADM.
// Requer plano Blaze + API "Cloud Vision" ativada no projeto + `npm install` em functions/.
const vision=require("@google-cloud/vision");
const VIS=new vision.ImageAnnotatorClient();
const RISCO=["LIKELY","VERY_LIKELY"];
const LINK_RX=/(https?:\/\/|www\.|\b[a-z0-9-]{2,}\.(com|net|org|gg|me|io|ly|xyz|br|tv|app|link)\b|discord\.gg|t\.me\/|bit\.ly)/i;
function recusaFigu(ev,why){return ev.data.ref.update({s:"no",why,rb:"palmas_bot",rt:admin.firestore.FieldValue.serverTimestamp()});}
exports.palmasFiguTriagem=onDocumentCreated("palmas_sstk/{id}",async(ev)=>{
  const f=ev.data&&ev.data.data();if(!f||(f.s!=="pend"&&f.s!=="ok"))return;
  const m=/^data:image\/(?:webp|png|gif);base64,([A-Za-z0-9+\/=]+)$/.exec(String(f.d||""));
  if(!m)return recusaFigu(ev,"formato");
  try{
    const [r]=await VIS.annotateImage({image:{content:Buffer.from(m[1],"base64")},features:[{type:"SAFE_SEARCH_DETECTION"},{type:"TEXT_DETECTION"}]});
    const ss=r.safeSearchAnnotation||{};
    if(["adult","violence","racy"].some(k=>RISCO.includes(ss[k])))return recusaFigu(ev,"conteudo");
    const tx=(r.fullTextAnnotation&&r.fullTextAnnotation.text)||"";
    if(tx&&(LINK_RX.test(tx)||censura(tx).hit))return recusaFigu(ev,"texto");
  }catch(e){console.error("triagem de figurinha falhou; segue para o ADM:",e.message);}
});


// ===== Sala de música (LiveKit) =====
// A pessoa entra na sala (palmasMusicaToken) e escolhe a música (palmasMusicaPedir); o pedido vai para a
// coleção palmas_music_req e o bot (pasta music-bot) entra na sala, toca e sai. Requer plano Blaze. Antes do deploy:
//   firebase functions:secrets:set LIVEKIT_API_KEY
//   firebase functions:secrets:set LIVEKIT_API_SECRET
//   crie functions/.env com a linha: LIVEKIT_URL=wss://SEU-PROJETO.livekit.cloud
// Deploy: firebase deploy --only functions
const {onCall,HttpsError}=require("firebase-functions/v2/https");
const {defineSecret,defineString}=require("firebase-functions/params");
const {AccessToken}=require("livekit-server-sdk");
const LK_KEY=defineSecret("LIVEKIT_API_KEY"),LK_SECRET=defineSecret("LIVEKIT_API_SECRET"),LK_URL=defineString("LIVEKIT_URL");
const MUS_HOSTS=defineString("MUSICA_HOSTS",{default:""}); // opcional: sites liberados para pedido por link, separados por vírgula
async function musQuem(req){
  if(!req.auth)throw new HttpsError("unauthenticated","Entre na sua conta.");
  const db=admin.firestore();
  const q=await db.collection("palmas_users").where("uid","==",req.auth.uid).limit(1).get();
  if(q.empty)throw new HttpsError("permission-denied","Conta não encontrada.");
  const user=q.docs[0].id,nome=String(q.docs[0].data().n||user).slice(0,40);
  if((await db.doc("palmas_bans/"+user).get()).exists)throw new HttpsError("permission-denied","Conta suspensa.");
  const adm=(await db.doc("palmas_admins/"+user).get()).exists;
  return{db,user,nome,adm};
}
exports.palmasMusicaToken=onCall({secrets:[LK_KEY,LK_SECRET]},async(req)=>{
  const w=await musQuem(req);
  const at=new AccessToken(LK_KEY.value(),LK_SECRET.value(),{identity:req.auth.uid,name:w.nome,ttl:"2h",attributes:{u:w.user,admin:w.adm?"1":"0"}});
  at.addGrant({room:"palmas-musica",roomJoin:true,canSubscribe:true,canPublish:false,canPublishData:true});
  const cat=await w.db.doc("palmas_music_cfg/catalogo").get();
  return{token:await at.toJwt(),url:LK_URL.value(),lista:cat.exists&&Array.isArray(cat.data().lista)?cat.data().lista.slice(0,50):[]};
});
exports.palmasMusicaPedir=onCall(async(req)=>{
  const w=await musQuem(req),d=req.data||{},col=w.db.collection("palmas_music_req");
  const rec=await col.where("uid","==",req.auth.uid).get();
  const agora=Date.now(),meus=rec.docs.filter(x=>x.data().ts&&agora-x.data().ts.toMillis()<30*60000);
  if(meus.some(x=>agora-x.data().ts.toMillis()<3000))throw new HttpsError("resource-exhausted","Calma, espere uns segundos.");
  if(!w.adm&&meus.length>=3)throw new HttpsError("resource-exhausted","Você já tem 3 músicas na fila.");
  if((await col.count().get()).data().count>=20)throw new HttpsError("resource-exhausted","A fila está cheia.");
  const doc={uid:req.auth.uid,u:w.user,n:w.nome,ts:admin.firestore.FieldValue.serverTimestamp()};
  if(Number.isInteger(d.i)){
    const cat=await w.db.doc("palmas_music_cfg/catalogo").get(),l=cat.exists?cat.data().lista:[];
    if(d.i<0||d.i>=l.length)throw new HttpsError("invalid-argument","Música não encontrada.");
    doc.i=d.i;doc.t=String(l[d.i]).slice(0,60);
  }else if(typeof d.q==="string"&&d.q.trim()&&!/^https?:\/\//i.test(d.q.trim())){
    const q=d.q.replace(/[\u0000-\u001f<>]/g,"").trim().slice(0,80);
    if(q.length<2)throw new HttpsError("invalid-argument","Digite o nome da música ou do artista.");
    doc.q=q;doc.t=q;
  }else{
    let u;try{u=new URL(String(d.q||d.url||"").trim().slice(0,500))}catch(e){throw new HttpsError("invalid-argument","Link inválido.")}
    const h=u.hostname.toLowerCase(),ok=MUS_HOSTS.value().split(",").map(x=>x.trim().toLowerCase()).filter(Boolean);
    if(u.protocol!=="https:"||u.username||u.password||/^[\d.]+$/.test(h)||h.includes(":"))throw new HttpsError("invalid-argument","Use um link https de áudio (como .mp3).");
    if(ok.length&&!ok.some(x=>h===x||h.endsWith("."+x)))throw new HttpsError("invalid-argument","Esse site não está liberado.");
    doc.url=u.toString();
    doc.t=String(d.titulo||"").trim().slice(0,60)||decodeURIComponent(u.pathname.split("/").pop()||"Música").slice(0,60);
  }
  doc.t=doc.t.replace(/[<>]/g,"");
  await col.add(doc);
  return{msg:"Pedido enviado. O Palmas Bot já entra na sala."};
});
