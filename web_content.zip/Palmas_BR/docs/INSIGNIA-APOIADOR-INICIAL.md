# Insígnia Apoiador Inicial (por código)

Insígnia com o mapa do Tocantins na bandeira do estado. Só é obtida resgatando um código em **Presentes → Resgatar código**. Aparece no perfil, nas mensagens e no cartão de perfil, no mesmo tamanho das outras insígnias (`--ins`).

Código de teste desta versão: `PALMAS-APOIADOR-4HX7-R3VD`
(no app só fica o hash: SHA-256 de `palmas-apoiador:` + CÓDIGO em maiúsculas).

Para gerar novos códigos, calcule o hash e troque o valor em `giftGo()` no `index.html`.

A insígnia é salva na conta (`apoCode`) e enviada ao perfil sincronizado no campo `b` (pode ser `beta`, `apoiador` ou `beta apoiador`). Ao entrar de novo em outro aparelho, ela é restaurada do perfil.

Importante: assim como a insígnia Beta, o código é validado no cliente. Antes de distribuir para muita gente, mova a validação para uma Cloud Function para que o código não possa ser extraído do JavaScript.

## Vários códigos
Os hashes ficam nas listas `BETA_H` e `APO_H` (antes de `giftGo()` no `index.html`). Para invalidar um código, apague o hash da lista. Hoje o mesmo código pode ser usado em contas diferentes; para uso único é preciso validar no servidor.

## Insígnia Beta Tester: Sol de Palmas
A insígnia Beta Tester agora é o Sol de Palmas, um desenho original em SVG (`BSVG.beta` no `index.html`). Uma cópia está em `assets/insignia-sol-de-palmas.svg`.
