# Códigos de insígnia: uso único (Beta Tester e Apoiador Inicial)

Cada código vale **uma vez**. A validação é no servidor (Firestore), na coleção `palmas_badge_codes`:
o ID do documento é o SHA-256 de `palmas-beta:` ou `palmas-apoiador:` + CÓDIGO (maiúsculas), e o documento guarda `kind`, `used`, `by` (uid) e `at`.

- Código novo e livre: vira da conta que resgatou (`used: true`, `by: uid`).
- Segunda pessoa/outro celular usando o mesmo código: "Este código já foi usado." (as regras do Firestore impedem consumir de novo).
- A mesma conta entrando em outro aparelho: a insígnia volta pelo campo `b` do perfil, sem gastar outro código.
- Sem internet/sem login: não resgata (precisa do servidor).
- As listas `BETA_H`/`APO_H` do `index.html` foram removidas: código que não está no Firestore é inválido.

## Como cadastrar códigos
1. Publique as regras novas (`firebase/firestore.rules`).
2. No Cloud Shell: `cd scripts && npm i` e depois
   - `node semear-codigos.js ../../codigos.txt` (cadastra os códigos de um arquivo), ou
   - `node semear-codigos.js --gerar beta 10 ../../codigos.txt` (gera, cadastra e anota no arquivo).
3. Guarde o .txt FORA da pasta publicada.

Para cancelar um código antes de alguém usar, marque `used: true` no console do Firestore.
Limite que ainda existe: o campo `b` do próprio perfil não é verificado pelas regras; quem editar o próprio perfil na mão consegue exibir a insígnia sem código. Para fechar isso, é preciso uma Cloud Function que escreva o `b`.

## Gerar códigos pelo próprio app (v50)
Como ADM: Ajustes › Moderação › aba **Insígnias** › escolha Beta Tester ou Apoiador Inicial e a quantidade. Os códigos são cadastrados no Firestore (`palmas_badge_codes`) e copiados; envie cada um para uma pessoa. Quem resgata usa Ajustes › Presentes. Os códigos antigos de teste não valem mais. Se aparecer "Sem permissão", publique de novo `firebase/firestore.rules`.
