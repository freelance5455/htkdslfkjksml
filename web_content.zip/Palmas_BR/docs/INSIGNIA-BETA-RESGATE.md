# Insígnia Beta Tester por código

A atribuição automática da insígnia Beta Tester foi removida. Novas contas não recebem mais a insígnia só por terem sido criadas durante a fase beta; ela é liberada ao resgatar um código na área **Presentes → Resgatar código**.

Código de teste configurado nesta versão: `PALMAS-BETA-7KQ9-M2XP`.

Importante: esta primeira implementação valida o código no cliente do aplicativo. Para impedir que alguém extraia o código do JavaScript e o compartilhe, a validação deve migrar para uma Cloud Function/servidor antes de distribuir a insígnia amplamente. A insígnia resgatada é salva no perfil sincronizado.
