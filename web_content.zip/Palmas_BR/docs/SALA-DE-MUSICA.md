# Sala de música (v76)

A pessoa entra na sala "Música", escolhe uma música e o Palmas Bot **entra na call para tocar**. Quando a fila acaba (e passam ~90 s sem pedidos), ele sai. Só esta sala usa o LiveKit; as chamadas de voz continuam como antes (ponto a ponto).

Como funciona:
1. O app chama a função `palmasMusicaToken` (Firebase) e entra na sala `palmas-musica` do LiveKit.
2. A pessoa escreve o nome da música ou do artista (ou escolhe da playlist, ou cola um link de áudio). O app chama `palmasMusicaPedir`, que confere a conta e grava o pedido em `palmas_music_req`.
3. O bot (pasta `music-bot/`, ligado em um servidor) vê o pedido, **procura na internet**, entra na sala, toca a fila e sai quando acaba.

## De onde vêm as músicas (busca)
- **Audius:** músicas de artistas independentes, sem precisar de chave.
- **Jamendo:** músicas Creative Commons; precisa de uma chave grátis (`JAMENDO_CLIENT_ID` no bot). Confira os termos do Jamendo se o app tiver cobrança (apoiadores): uso comercial pede licença própria.
- **Rádios online:** escrever "rádio" + nome (ex.: "rádio jovem pan"), via Radio Browser.
- **Playlist e links:** os botões do `playlist.json` e links https de áudio continuam valendo.
- **Não incluído de propósito:** YouTube, Spotify, Deezer e similares. Baixar ou captar o áudio deles viola os termos dessas plataformas e os direitos autorais. Por isso músicas comerciais famosas só tocam se você tiver uma licença/arquivo próprio (playlist) ou se a rádio transmitir.
- Se o bot não achar nada, avisa na tela ("Não encontrei...").

## Passo a passo
1. **LiveKit:** crie uma conta em livekit.io (LiveKit Cloud tem plano grátis para começar) e um projeto. Anote a URL (`wss://...`), a API Key e a API Secret.
2. **Firebase (funções):**
   - `firebase functions:secrets:set LIVEKIT_API_KEY` e `firebase functions:secrets:set LIVEKIT_API_SECRET`
   - crie `functions/.env` com `LIVEKIT_URL=wss://SEU-PROJETO.livekit.cloud` (opcional: `MUSICA_HOSTS=site1.com,site2.com` para liberar só esses sites nos pedidos por link)
   - `cd functions && npm install && cd ..` e `firebase deploy --only functions` (plano Blaze).
3. **Chave do bot no Firebase:** Configurações do projeto > Contas de serviço > Gerar nova chave. Cole o JSON inteiro, em uma linha, na variável `FIREBASE_SERVICE_ACCOUNT` do bot. Não publique essa chave.
4. **Bot (precisa ficar ligado 24h):** veja `music-bot/LEIA-ME.md`. Opções simples: uma VPS barata, ou Railway/Render usando o `Dockerfile` da pasta. Variáveis: `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`, `FIREBASE_SERVICE_ACCOUNT`.
5. **Playlist (opcional):** edite `music-bot/playlist.json`. Os títulos aparecem como botões no app.
6. **App:** publique o `index.html` novo. Na comunidade oficial aparece "🎵 Sala de música" no fim da lista de canais.

Não precisa mudar `firestore.rules`: as coleções novas (`palmas_music_req`, `palmas_music_cfg`) ficam bloqueadas para os aparelhos e só as funções e o bot (servidor) acessam.

## Comandos no chat
`!tocar nome da música` (ou `!play`, `!p`) pede uma música de qualquer canal. `!pular`, `!pausar`, `!retomar` e `!parar` funcionam para quem está na sala (pausar, retomar e parar só ADM). Os mesmos pedidos podem ser feitos pela tela da sala.

## Regras
- Qualquer pessoa na conta logada pede música: até 3 na fila por pessoa (ADM sem esse limite) e 20 no total.
- Pausar, retomar e parar tudo: só ADM. Pular: ADM ou quem pediu a música tocando.
- Contas banidas não recebem acesso nem pedem música.
- Se todo mundo sair da sala e o bot ficar sozinho (10 s, `SOZINHO_SEG`), ele para a música, descarta a fila e sai da call sozinho.
- Cada faixa é cortada em 15 min (`MAX_SEG`).

## Limites e cuidados
- O bot toca **links https diretos de áudio** (mp3, aac, rádios online). Links de YouTube/Spotify/Deezer não funcionam e não devem ser usados.
- Toque só música que você tem direito de usar. Se deixar qualquer pessoa pedir por link, a responsabilidade pelo conteúdo é do servidor; considere liberar só alguns sites com `MUSICA_HOSTS` (função) e `ALLOWED_HOSTS` (bot).
- Segurança dos links: o bot só aceita https, recusa endereços IP e redes internas. Como o ffmpeg segue redirecionamentos, limitar os sites com `ALLOWED_HOSTS` é o mais seguro.
- Se o bot estiver desligado, os pedidos ficam na fila (até 30 min) e o app mostra "Fora da sala".
- Esta versão foi escrita sem poder rodar contra um LiveKit de verdade: teste com 2 aparelhos antes de divulgar. Se as versões das bibliotecas (`livekit-client` no `index.html`, `@livekit/rtc-node` no bot) mudarem de comportamento, ajuste as versões fixas.
