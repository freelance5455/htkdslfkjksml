# Segurança do Palmas BR

## O que o app já faz (e onde é imposto)
| Proteção | Onde vale |
|---|---|
| **Convite verificado no servidor.** O perfil só é criado se o convite existir e estiver livre; ele é consumido na mesma operação. Os códigos não estão mais no código-fonte. | Regras do Firestore |
| **Só membro com perfil acessa dados.** Criar um login no Authentication sozinho não dá acesso a mensagens, perfis, amigos nem chamadas. | Regras |
| **Banimento e silenciar** (por ADM): conta banida perde todo acesso; silenciada não consegue enviar. | Regras |
| **Filtro de palavrões** na comunidade oficial: censura no servidor, 4 avisos e banimento automático (`palmasFiltro`). | Cloud Function + regras |
| **Denúncias** de mensagem (spam, assédio, sexual, violência, golpe, outro), lidas só por ADM. | Regras |
| **Bloqueio** que vale também no servidor: quem foi bloqueado não consegue mandar DM. | Regras |
| **Validação de campos**: só os campos esperados, tamanhos máximos, DM só entre os dois, autor = quem está logado, hora do servidor. | Regras |
| **Apagar**: autor apaga o que escreveu; ADM apaga mensagens públicas. | Regras |
| **Termos e Privacidade** com aceite no cadastro (13+), **baixar meus dados** e **excluir minha conta** (LGPD). | App |
| Senhas fracas bloqueadas; limite de envio (8 por 10 s); texto sempre escapado (sem XSS). | App |
| Cabeçalhos de segurança (HSTS, anti-iframe, nosniff, CSP em modo relatório). | `firebase.json` |

## Passo a passo para ligar (nesta ordem)
1. **Publique as regras**: copie o bloco `palmas_*` de `firebase/firestore.rules` para as regras do seu projeto (as do RPG ficam como estão) e publique.
2. **Crie seu primeiro ADM** no console: coleção `palmas_admins`, documento com ID = seu @usuario, campo `ok: true`.
3. **Gere convites**: entre no app com o ADM > Ajustes > **Moderação > Convites**. Cada código vale para uma conta e aparece só uma vez.
4. Publique com **https** (Firebase Hosting usa o `firebase.json` deste pacote). Depois confira o painel de relatórios de CSP e só então troque `Content-Security-Policy-Report-Only` por `Content-Security-Policy`.

> Atenção: depois de publicar as regras novas, **só entra conta nova com convite gerado no painel**. Contas já existentes continuam funcionando.

## Checklist no console do Firebase (não dá para fazer pelo código)
- **App Check** (reCAPTCHA v3/Enterprise) ligado e **imposto** para Firestore e Authentication. É a defesa contra bots usando sua chave.
- **Authentication > Configurações**: ligar *proteção contra enumeração de e-mails* e definir *política de senha* (mínimo 8, com letras e números).
- **Chave de API**: restrinja por *referenciadores HTTP* (seu domínio) no Google Cloud > Credenciais.
- **Orçamento e alertas** de cobrança, e cotas diárias, para um ataque não virar conta alta.
- **Domínios autorizados** só com o seu domínio.
- Apague usuários de teste e revise `palmas_admins`.
- Backup/exportação agendada do Firestore.

## Limites que continuam
- Não há limite de envio **no servidor** (o de 8/10 s é só no app). Para isso: App Check + Cloud Function.
- O banco guarda um perfil por @usuário: quem exclui a conta libera o @ para outra pessoa.
- Mensagens públicas são legíveis por qualquer membro (é o esperado de um canal aberto). DMs não têm criptografia ponta a ponta; o Google/Firebase processa os dados.
- Fotos de perfil não passam por moderação automática.
- **Termos e Privacidade são modelos**: peça a um advogado para revisar e preencha controlador e e-mail. Há legislação recente sobre crianças e adolescentes no ambiente digital (ECA Digital) que pode exigir mais (verificação de idade, controles parentais). Confirme com um profissional antes de abrir ao público.

## Se algo der errado
Banir (Moderação > Punições), apagar a mensagem, e se for vazamento de chave: restringir/rotacionar a chave no Google Cloud e ativar App Check imposto.

## Filtro de palavrões (palmasFiltro)
Publique as regras de novo (coleção nova `palmas_warns`, só o servidor escreve) e faça o deploy: `firebase deploy --only functions` (plano Blaze). A lista de palavras está duplicada em `functions/index.js` e em `BADWORDS` no `index.html`: mantenha as duas iguais.

## Cargos
Só o ADM (`palmas_admins`) cria cargos e atribui. As permissões de cada pessoa ficam copiadas em `palmas_userroles/{usuario}.perms` e as regras do Firestore consultam essa lista (`rperm`). Quem tem *Silenciar* só consegue silenciar por até 1 hora; banir exige ADM.
