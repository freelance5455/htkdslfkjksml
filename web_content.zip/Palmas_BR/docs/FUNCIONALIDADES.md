# Funcionalidades

## Estrutura da tela
Celular: menu "Navegação" (gaveta) com a barra de servidores à esquerda e a lista de canais/conversas. Computador: 4 colunas (servidores, canais, conteúdo, membros).

## Conta
- Criar conta com código de convite (hash SHA-256 conferido no navegador, cada código vale uma vez), nome de exibição, @usuário, senha (mín. 8) e estado (UF).
- Entrar com @usuário e senha. Sair em Ajustes. **Depois de sair, a tela abre em "Entrar"** (não em "Criar conta"): digite o @usuário e a senha da primeira vez. Em um aparelho/navegador novo, o login confere o @usuário e a senha na nuvem e traz nome, estado, bio, foto e banner do perfil (sem pedir convite). "Não tenho conta · Criar conta" e "Já tenho conta · Entrar" alternam as telas.
- **Todo mundo que cria conta durante a beta (até 31/12/2026) recebe a insígnia Beta Tester**, inclusive contas e mensagens antigas; contas criadas a partir de 2027 **não** recebem (constante `BETA_ATE` no `index.html`). Todos conseguem vê-la (no perfil rápido, no perfil completo, na lista de membros e nas mensagens). A Equipe mostra Beta Tester e Equipe.

## Início e Amigos (novo)
- Botão Início (casa) na barra de servidores abre a tela de Início.
- Lateral: campo "Encontre ou comece uma conversa", botão Amigos e lista de **Mensagens diretas** (toque abre a conversa; X fecha).
- Tela Amigos: abas **Online / Todos / Pendentes / Bloqueados**, busca na lista, e por amigo: mensagem, ligar, mais (perfil).
- Adicionar amigo por @usuário exato → vai para Pendentes (Cancelar disponível). Bloqueados têm Desbloquear.

## Mensagens (v0.3)
- Hora em cada mensagem, separador de dia (Hoje, Ontem, data) e agrupamento de mensagens seguidas da mesma pessoa (até 5 min).
- **Editar** e **Apagar** suas próprias mensagens (marca "editada"). Vale só para mensagens locais; mensagens da nuvem ainda não podem ser alteradas. Mensagens antigas, sem hora salva, também não.
- **Busca** em todos os canais e conversas: mostra servidor e canal, destaca o trecho, ordena das mais novas e abre o canal ao tocar no resultado.
- **Esc** fecha janelas e o menu. A lista de membros de servidores criados por você mostra só você (a lista de exemplo vale para a comunidade oficial).

## Chamadas de voz e tela (v0.5, direto no navegador)
- Sem instalar nada: WebRTC no próprio app. O Firestore só serve para os celulares se encontrarem (coleções `palmas_callpeers` e `palmas_callsig`); o áudio e a tela vão direto de um aparelho ao outro.
- **Conversa direta:** ícone de telefone no topo da conversa ou na lista de amigos. A pessoa recebe a mensagem "📞 Chamada de voz iniciada" com o botão **Entrar**.
- **Sala de voz** de um canal: botão **Entrar na chamada**. Várias pessoas (indicado até ~5; cada uma se liga a todas as outras).
- Um quadro por pessoa, com **anel verde ao redor da foto quando ela fala**, ícone de microfone cortado quando está no mudo e o estado da conexão. Botões: **Silenciar**, **Compartilhar tela** e **Sair**.
- Compartilhar tela só funciona em **computador** (navegadores de celular não permitem). Ver a tela de alguém funciona no celular.
- Requer login na nuvem (Firebase) e página em https. Pede permissão de microfone.
- Sem servidor TURN, ~1 em cada 5 conexões pode falhar (principalmente 4G/redes de empresa): veja `TURN_SERVERS` em docs/FIREBASE.md.

## Lotação e quem está nas salas de voz (novo)
- Cada sala de voz mostra **quantas pessoas cabem** e **quantas estão nela agora** (ex.: `2/5`), tanto na lista de canais quanto dentro da sala, com uma barra de ocupação.
- Dá para ver **quem está na sala** antes de entrar: os nomes aparecem embaixo do canal e na tela da sala; tocar em um nome abre o perfil rápido. Quem fica mais de 90 segundos sem sinal sai da lista.
- Capacidade padrão: **5 pessoas**. Ao criar um canal de voz dá para escolher de 2 a 10; depois quem criou (ou a equipe, na comunidade oficial) muda no seletor "Capacidade da sala".
- Sala cheia: o botão vira "Sala cheia" e entrar mostra um aviso. Acima de 5 pessoas a qualidade pode cair (conexão direta entre aparelhos).
- Precisa estar conectado à nuvem; sem ela só aparece a capacidade ("máx. N").

## Palmas Bot: XP, nível e ranking (novo)
- O **Palmas Bot** é membro da comunidade oficial (selo BOT na lista de membros e nas respostas). Tocar nele abre o painel do bot.
- **XP:** cada mensagem com 3+ caracteres nos canais de texto da comunidade oficial vale 15 XP (+1 a cada 20 caracteres, máx. +5). Só conta 1 mensagem por minuto por pessoa (anti-spam). **Nível** = floor(√(XP/50)): nível 1 = 50 XP, 2 = 200, 5 = 1.250, 10 = 5.000. Títulos: Novato, Participante (3), Habitual (6), Veterano (10), Lenda (15).
- O XP é **calculado do histórico de mensagens da nuvem**, então é o mesmo em todos os aparelhos e nada novo é gravado no Firestore (sem regras novas). Sem nuvem, conta só as mensagens locais.
- **Nível ao lado do nome** nas mensagens e na lista de membros (ex.: `Nv 3`).
- **Ranking de quem mais escreveu:** botão de troféu no topo da comunidade oficial (nível, barra de XP, top 10, loja e comandos) ou comando `!top`.
- **Avisos do bot** (só você vê, com botão Dispensar): "Subiu de nível!" e "Destaque de ontem" (quem mais escreveu no dia anterior, uma vez por dia).
- **Foto do bot:** `assets/palmas-bot.png` (robô verde com sol dourado). No app ela vai embutida na constante `BOTIMG` (se trocar a imagem, gere de novo o base64).
- **Comandos** (digitados no canal # Comandos da comunidade oficial; não vão para a nuvem e não dão XP). Toque num comando dentro da lista de `!ajuda` para escrevê-lo na caixa de mensagem:
  - Nível e ranking: `!rank` (ou `!rank @usuario`), `!top`, `!niveis`.
  - Diversão: `!dado` (`!dado 20`, `!dado 2d6`), `!moeda`, `!escolher a, b, c`, `!8ball pergunta`, `!piada`, `!frase`.
  - Utilidades: `!calc (2+3)*4`, `!hora` (Palmas-TO), `!ping`.
  - Comunidade: `!sobre`, `!regras`, `!links`, `!servidor`, `!tocantins`.
  - Loja: `!loja`, `!comprar` (em breve).
  - Para criar um comando novo: acrescente o nome em `BC`, o texto em `BCMDS` e a resposta em `bRun`.
- **Cosméticos:** `!loja` e `!comprar` mostram **"Em breve"** (molduras de avatar, cores de nome, títulos, fundos de perfil). Nada é gasto ainda.
- Os @usuários `palmas_bot`, `bot`, `equipe_palmas`, `eq` e `voce` são reservados no cadastro.

## Filtro de palavrões do Palmas Bot (novo)
- Em **qualquer canal de texto da comunidade oficial**, o bot censura palavrão **na hora**: a mensagem aparece com asteriscos (ex.: `m****`) e quem escreveu recebe um **aviso do Palmas Bot** (só ele vê): "Aviso 1 de 4", "2 de 4"… **No 4º aviso a conta é banida do aplicativo** (constante `BAN_AT`). Fora da comunidade oficial (DMs e servidores criados pela pessoa) **palavrão é permitido**: não há filtro, aviso nem banimento.
- **Na nuvem quem censura, conta e bane é o servidor** (função `palmasFiltro` em `functions/index.js`): troca o texto por asteriscos, soma 1 em `palmas_warns/<usuario>` e, no 4º, cria `palmas_bans/<usuario>`. A pessoa é desconectada na hora ("Conta banida") e as regras do Firestore bloqueiam o resto. ADMs são censurados mas não levam aviso. Para desbanir: Ajustes > Moderação > Punições > Limpar (também zera os avisos).
- Se não quiser/puder usar a função (plano Blaze), troque `FILTRO_SERVIDOR` para `false` no `index.html`: o app censura antes de enviar e conta os avisos no aparelho, mas aí o banimento não é imposto no servidor.
- Pega variações comuns: maiúsculas, acentos, letras repetidas (`merdaaa`), números/símbolos no lugar de letras (`p0rr4`) e pontos entre as letras (`p.u.t.a`), sem censurar palavras normais (`computador`, `disputa`, `cuidado`).
- Também **censura ao exibir**: mensagens antigas ou vindas de um app modificado aparecem censuradas para quem usa esta versão. Fora da comunidade oficial (DMs e seus servidores) não há filtro.
- A lista é a constante `BADWORDS` no fim do `index.html` (acrescente ou tire palavras). Limite: o filtro roda no aplicativo, então não impede alguém com um app alterado de gravar a palavra na nuvem; para bloqueio de verdade seria preciso uma Cloud Function que censure/remova a mensagem no servidor.

## Insígnias compactas e fotos de todos (novo)
- Nas mensagens e na lista de membros, as insígnias (Beta Tester, Equipe, bandeira do estado) aparecem como **ícones pequenos ao lado do nome**, no tamanho `--ins` (16 px), igual ao perfil rápido. No **Ver perfil completo** os mesmos ícones pequenos ficam ao lado do nome (Beta Tester + bandeira) e, na seção Insígnias, o nome por extenso.
- **Foto e banner de cada pessoa** passam a aparecer para os outros: ao salvar o perfil (e ao entrar), o app envia uma versão reduzida (foto 160×160, banner 640×220, JPEG) para `palmas_users`; quem não tem foto continua com a inicial colorida. Sem mudança nas regras do Firestore. GIFs animados viram imagem parada para os outros. Quem trocar a foto aparece atualizada para os demais ao recarregar a página.

- Comunidade oficial verificada (canais Regras, Anúncios, Financiamento Coletivo, Sorteio, Geral, Links & Mídia, Suporte & Report, Sala de voz); só a equipe cria canais nela.
- Criar servidor próprio, criar canais de texto/voz, descobrir e entrar/sair de servidores (catálogo de exemplo).
- Mensagens com reações, busca de mensagens, lista de membros.

## Perfil rápido (novo)
- Tocar na foto ou no nome de alguém (mensagens, lista de membros, lista de amigos) abre um cartão compacto: foto com o status, nome, @usuário e as **insígnias ao lado do @** (Beta Tester, Equipe e bandeira do estado; toque ou passe o mouse para ver o nome).
- Botão **Enviar mensagem** (abre a conversa direta; some se a pessoa estiver bloqueada) e, no seu próprio perfil, **Editar perfil**.
- Linha "N servidor(es) mútuo(s)": conta os servidores oficiais em comum (nesta prévia, só a comunidade oficial é compartilhada).
- Botão **...**: adicionar, remover ou cancelar pedido de amizade, bloquear e desbloquear.
- **Ver perfil completo** abre o perfil inteiro (banner, sobre mim, informações e insígnias).
- O tamanho das insígnias é a variável `--ins` (14 px; no CSS, no fim do arquivo). Esc ou toque fora fecha o cartão.

## Perfil e insígnias
- Foto/GIF (até 1 MB), banner (até 2 MB), descrição, status (Online, Ausente, Ocupado, Invisível), estado (UF).
- Insígnias: Beta Tester, Equipe e **bandeira do estado** (27 UFs, escudo com a bandeira; toque mostra o nome).

## Ajustes
Conta e segurança, aparência, avisos, voz e vídeo, atalhos, apps, privacidade, termos, financiamento coletivo, sobre.

## Simulado nesta prévia
Não há servidor: os outros usuários (Ana, Caio, Equipe) são fixos; chamadas de voz/vídeo não funcionam; nada é enviado pela rede.

## Administração da comunidade oficial
- O dono do aparelho (a primeira conta criada nele) é administrador: vê o lápis no cabeçalho da comunidade oficial, edita nome, descrição, foto e renomeia/exclui canais, e cria canais em qualquer categoria.
- O lápis também troca o **banner da comunidade** (fundo do cabeçalho; imagem até 4 MB, reduzida automaticamente) e tem **Remover banner** e **Remover foto** (dá para ficar só com o banner). Como o resto da edição da comunidade, isso fica salvo no aparelho do ADM; para valer para todos, cole a imagem em `COMM_BANNER` / `COMM_PHOTO` no início do script. GIF vira imagem parada no banner.
- Quem não é administrador vê "Sem permissão". Atenção: sem servidor isso é só uma regra do navegador; para valer de verdade precisa de backend.

## Figurinhas
- **Painel compacto (v27):** duas abas no topo, **Emoji | Figurinhas**, e na aba Figurinhas uma barra lateral com os pacotes (Palmas, Memes, Aura, Imagens, Minhas, Criar) e grade de 4 colunas. Ocupa no máximo ~38% da altura da tela.
- **Pacote Imagens:** figurinhas de imagem (PNG/WebP/GIF/JPG) ficam em `assets/figurinhas/` e são listadas em `STK_IMG` no `index.html` (veja `assets/figurinhas/LEIA-ME.md`). As 4 imagens da pasta são só exemplos: troque pelas suas. Só nomes `a-z 0-9 - _` são aceitos.
- Botão pequeno de figurinha ao lado do "Enviar". Abas: **Palmas** (17 figurinhas próprias desenhadas em SVG), **Memes** (15: Sigma, Cringe, Bruh, Hmmm, Kkkkk, Sextou, Tá pago, Vish, Calma, Nem ligo, Fica a dica, Quê?!, RIP, Tankei, Meu Deus), **Aura** (10: +1000, -1000, Max, Farming, Sem aura, De ouro, Infinita, Roxa, +9999, Tocantins), **Minhas** (as que você salvar, até 30) e **Criar** (texto ou emoji + 8 cores).
- Para criar figurinha nova: acrescente em `STK_M` (memes) ou `STK_A` (aura) no `index.html` (`id:["Nome",SVG]`, desenho em 100x100). O id vai dentro de `[figurinha:id]` (máx. 60 caracteres, sem `]`).
- Enviam-se como texto especial `[figurinha:...]` (cabe nas regras atuais do Firestore) e são desenhadas por quem recebe; não usa Storage.

## Marcar pessoas (@)
Lista de sugestões ao digitar `@`, destaque da menção, faixa laranja na mensagem de quem foi marcado e avisos no celular (veja `docs/NOTIFICACOES.md`).

## Segurar a mensagem (Editar / Apagar)
Toque e segure uma mensagem sua (ou clique com o botão direito no computador) para abrir um **painelzinho compacto** (cerca de 200 px, com ícones) perto do dedo/cursor, com **Copiar texto, Editar e Apagar** (e Denunciar nas mensagens dos outros). Tocar fora fecha; Apagar ainda pede confirmação. No celular os botõezinhos antigos ficam escondidos. Nos canais públicos da nuvem a edição não está disponível (as regras do Firestore não permitem alterar mensagens enviadas); lá aparece só Apagar, e ADMs também podem apagar mensagens de outras pessoas.

## Segurança e moderação
Convite verificado no servidor, denunciar mensagem (segurar a mensagem de outra pessoa), copiar texto, painel de **Moderação** para ADM (denúncias, silenciar, banir, gerar convites), bloqueio que vale no servidor, Termos e Privacidade com aceite, baixar meus dados e excluir minha conta. Detalhes em `docs/SEGURANCA.md`.

## Painel do servidor
Toque no nome do servidor (ou na setinha) no topo da lista de canais: abre o painel com **Marcar como lido**, **Silenciar servidor**, **Avisos** (Todas as mensagens / Somente @menções / Nada), **Ignorar @everyone e @here** e **Sair do servidor**. As escolhas ficam salvas por servidor. Silenciar e Avisos já controlam as notificações; "Marcar como lido" e "Ignorar @everyone e @here" guardam a configuração para quando existirem o contador de não lidas e o @everyone. A comunidade oficial não pode ser deixada. O lápis de edição do cabeçalho foi removido (a função `editCom` continua no código para voltar dentro do painel depois).

## Cargos (v0.7, comunidade oficial)
- **Quem gerencia:** só o ADM (quem tem o documento em `palmas_admins`). Em **Ajustes > Cargos e administração** (sempre visível). Quem ainda não é ADM vê o passo a passo para criar o documento no Firebase e um botão **Já criei, verificar**; quem já é ADM cai direto na aba Cargos.
- **Criar cargo:** nome (até 24 letras), cor do nome (cores prontas ou qualquer cor) e permissões. A ordem na lista define qual cor vale quando a pessoa tem mais de um cargo (setas para subir/descer).
- **Permissões reais (também nas regras do Firestore):** *Apagar mensagens de outros* nos canais públicos; *Silenciar membros* por até 1 hora (botões no perfil da pessoa). *Administrador* marca as duas.
- **Dar cargo:** abra o perfil de alguém (ou o seu) e toque em **Gerenciar cargos**, ou use "Dar cargo a um usuário" na aba Cargos.
- **O que aparece:** o nome da pessoa na cor do cargo nas mensagens, na lista de membros e no perfil, com o(s) cargo(s) listados no perfil.
- **Modelo:** se não houver cargos, há o botão **Criar o cargo "Dono"** (dourado, administrador).
- Só funciona com a nuvem ligada (os cargos ficam em `palmas_roles` e `palmas_userroles`). Banir e convites continuam só para o ADM.

## Ajustes > Voz e vídeo (novo)
- **Microfone:** escolher o dispositivo de entrada, ver a permissão do navegador e **testar** com uma barra de nível (o teste não grava nem envia nada).
- **Filtros de áudio:** cancelamento de eco, redução de ruído e controle automático de ganho (ligados por padrão).
- **Saída de áudio:** escolher as caixas ou o fone (só Chrome e Edge; nos outros navegadores usa a saída padrão do aparelho) e ajustar o **volume das pessoas** na chamada, com botão "Testar som".
- Tudo vale de verdade nas chamadas: ao entrar na sala o app usa o microfone e os filtros escolhidos, e mudar durante a chamada troca o microfone na hora, sem sair da sala e respeitando o "Silenciar".
- **Câmera nas chamadas:** aparece como "em breve" (por enquanto só há voz e compartilhamento de tela).
- "Restaurar padrões" volta tudo ao original. As escolhas ficam salvas só neste aparelho.

## Perfil: cartão pequeno e perfil completo (atualizado)
- Tocar na foto ou no nome de alguém na conversa abre o **cartão pequeno**: banner (só aparece se a pessoa tiver um), foto com o **ícone de status** (verde = online, lua = ausente, vermelho = ocupado, anel vazio = invisível/offline), nome, @usuário com as insígnias ao lado e o botão principal.
- No **seu próprio perfil** o botão é "Editar perfil" e o link é **"Ver meu perfil"**; nos outros é "Enviar mensagem" e "Ver perfil completo".
- O link abre o **perfil completo**: banner com botão de fechar, foto maior, nome, @usuário e insígnias, "Sobre mim", "No Palmas BR desde..." e "Neste servidor desde..." (só na comunidade oficial, onde a entrada coincide com a criação da conta).
- Rodapé do perfil completo: no seu perfil, o aviso "Este é o seu perfil, do jeito que as outras pessoas veem" com "Editar perfil"; no de outra pessoa, as ações de amizade (adicionar, remover, cancelar pedido, bloquear/desbloquear).


## Cartão do bot, cargos e status
- Toque no Palmas Bot: cartão "App" (foto, selo APP, Online, descrição, "Adicionado por Equipe Palmas", botão Ver comandos).
- Perfil rápido mostra CARGOS (ex.: Admin) e nome na cor do cargo.
- Status: Online = bolinha verde, Ausente = lua, Não perturbe = bolinha vermelha com traço preto, Offline = anel cinza.
- Lista de membros agrupada: App, cargos (coroa para Admin), Online, Offline.
- Ajustes > Cargos: lista "Membros e cargos" mostra, por cargo, quem tem, e "Sem cargo" com botão Dar cargo.

## Ajustes (v1.1)
- **Painel do nome** (toque no seu nome, na barra de baixo): Disponível, Ausente, Não perturbe, Invisível, Perfil, Conta e Sair. Não perturbe silencia avisos de mensagens.
- **Conta e segurança**: dados da conta, copiar @usuário, **alterar senha** (confere a atual; com a nuvem ligada também troca no Firebase), baixar dados, sair e excluir conta. O @usuário não muda durante a beta.
- **Presentes**: mostra a insígnia Beta Tester e os presentes resgatados; **resgatar código** libera banners extras no editor de perfil. Os códigos ficam no `index.html` só como hash (`GIFT_CODES`; hash = SHA-256 de `palmas-gift:` + CÓDIGO em maiúsculas). A conferência é feita no aparelho, como nos convites.
- **Aparência**: tema Escuro/Preto/Claro, cor de destaque, tamanho do texto das mensagens e reduzir animações. Salvo neste aparelho.
- **Avisos**: avisos dentro do app, notificações do sistema (pede permissão), vibração e "só quando me marcarem". Botão de aviso de teste.
- **Atalhos** (computador): Ctrl+K busca, Alt+↑/↓ troca de canal, Ctrl+, Ajustes, Ctrl+/ lista, Ctrl+Shift+M microfone, Ctrl+Shift+D som. Dá para desligar.
- **Apps**: Palmas Bot (abre os comandos) e instalar o Palmas BR no aparelho.
- **Financiamento coletivo**: abre o canal # Financiamento Coletivo da comunidade.
- **Sobre**: versão, termos, privacidade, procurar atualização e copiar informações do app.


## Servidores próprios (assistente, classificação e cargos)
- **Criar servidor** (botão + da barra lateral) abre um assistente: 1) *Criar o meu servidor* ou *Convidar amigos para o meu servidor*; 2) **classificação**: *até 16 anos* (menores de idade, com regras de proteção que a pessoa precisa aceitar; palavrões são censurados no servidor) ou *18 anos ou mais* (tudo liberado dentro da lei; a pessoa confirma ter 18+); 3) **nome, descrição e foto** do servidor; 4) (só no modo com amigos) escolher quais amigos entram.
- O servidor mostra um selo **16** ou **18+** ao lado do nome.
- **Cargos do servidor** (painel do servidor > *Cargos do servidor*): o dono cria cargos (nome, cor e permissões), dá cargo aos membros e vê a lista de membros agrupada por cargo. Os cargos valem só dentro daquele servidor.
- **Convidar amigos** (painel do servidor) adiciona amigos já aceitos ao servidor.
- **Limite desta versão:** servidores próprios ficam salvos neste aparelho (como já era). Os amigos aparecem na lista de membros, mas ainda não conseguem abrir o servidor no aparelho deles, e as permissões dos cargos ainda não são impostas, porque isso depende de um servidor na nuvem (próxima etapa).

## Barra de mensagem (botões)
Botões originais do Palmas BR: Emojis (sol sorridente, seletor próprio com abas e recentes), Figurinhas e Enviar (seta). Anexos e GIFs ainda não existem: as mensagens aceitam só texto de até 500 caracteres, então precisam de armazenamento (Firebase Storage) e, para GIFs, de um provedor.

## Selo de verificado
Selo original do Palmas BR: flor de 8 pétalas dourada com visto (`VFSVG` no `index.html`). Aparece no cabeçalho do servidor e no ícone dele na barra lateral. Ao tocar no selo do cabeçalho, uma mensagem preta informa o motivo ("Comunidade oficial do Palmas BR" ou "Servidor verificado").

## Foto e banner da comunidade
A foto (palmeira e sol nascendo) e o banner (faixas azul, branca e amarela com sol) são originais do Palmas BR e ficam embutidos em `COMM_PHOTO` e `COMM_BANNER` no `index.html`. As imagens em tamanho original estão em `assets/foto-comunidade.png` e `assets/banner-comunidade.png`. O selo de verificado aparece no recorte escuro do ícone do servidor.

## Dar selo de verificado a um servidor
Somente administradores (conta listada em `palmas_admins` e conectada à nuvem) veem a opção. O administrador abre o menu do servidor (toque no nome no topo) e escolhe **Dar selo de verificado** ou **Remover selo de verificado**. A comunidade oficial já é sempre verificada. Limitação atual: os servidores que não são o oficial ficam salvos só no aparelho de cada pessoa, então o selo concedido por você aparece no seu aparelho. Para o selo valer para todo mundo, os servidores precisam ser guardados na nuvem (Firestore).

## Tela "Seu lugar no Palmas BR"
Ao tocar no + da barra lateral abre um painel próprio com faixa azul, branca e amarela com o Sol de Palmas e três opções: Criar o meu servidor, Criar com amigos e Descobrir servidores. Entrar por código ou link de convite ainda não existe: depende de guardar os servidores na nuvem.

## Responder mensagem (novo)
- **Segure (ou clique com o botão direito) numa mensagem** e toque em **Responder**. Aparece uma barrinha em cima da caixa de texto ("Respondendo a Fulano" + trecho) com X para cancelar (Esc também cancela). Trocar de canal cancela a resposta.
- A mensagem enviada mostra, acima do nome, uma **linha de referência** com a fotinha, o nome e o começo da mensagem respondida, ligada à sua foto por uma curvinha. **Tocar na linha rola até a mensagem original** e a destaca por um instante; se ela não estiver mais na conversa, avisa.
- Funciona em canais e conversas diretas, inclusive respondendo a figurinhas.
- Nos servidores da nuvem a resposta é gravada no campo `rp` (`{id, u, x}`) da mensagem. **Publique de novo `firebase/firestore.rules`** (ou `firestore.palmas-only.rules`); sem isso o Firestore recusa mensagens com resposta.

## Novo canal v2 (novo)
- Janela redesenhada: tipo em cartões (**Texto, Voz, Avisos**), nome com prévia do prefixo e contador, **ícone em emoji**, **descrição** (aparece abaixo do título do canal) e categoria (comunidade oficial).
- **Voz:** quantidade de pessoas na sala com botões − / + (2 a 10) e **Call privada**.
- **Texto:** **Modo lento** (5 s, 10 s, 30 s, 1 min, 5 min) e **Somente leitura** (só quem criou escreve). **Avisos** = texto somente leitura.
- **Canal/Call privada:** o canal tem cadeado, some para quem não foi convidado e a entrada na chamada é bloqueada. Em servidores seus, escolha os convidados entre os membros; na comunidade oficial, só a equipe vê.
- Limite atual: servidores e canais criados por você ficam salvos no seu aparelho (como já era), então privacidade, modo lento e somente leitura valem neste aparelho. Para valer entre aparelhos seria preciso gravar os canais na nuvem (Firestore) com regras novas.
- Código: funções `ncOpen`, `ncCreate`, `ncSee`, `ncWrite` no fim do `index.html`.

## Descobrir (v28)
- Tela cheia aberta por **Descobrir servidores** (menu "+" da barra de servidores e criação de servidor). Topo com bússola, busca **"Buscar pelo nome"**, categorias em pílulas (**Tudo, Jogos, Tecnologia, Estudos, Arte, Música, Esportes, Comunidade**) e cartões com banner em degradê, ícone, nome, membros, online, descrição e botão **Entrar / Abrir**. Quem já entrou tem também um botão para **sair** do servidor (a comunidade oficial não sai).
- A comunidade oficial aparece primeiro, com selo azul de verificado.
- Os servidores da lista são **exemplos** (`CAT` no `index.html`: `id, name, icon, desc, cat, n` membros, `on` online). Troque pelos reais quando existirem.
- Ainda não há botão de denunciar servidor (a referência tinha uma bandeirinha): depende de um sistema de denúncias.
