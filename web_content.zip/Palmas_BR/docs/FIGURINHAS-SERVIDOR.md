# Figurinhas do servidor

O **dono** de um servidor pode ter figurinhas próprias. Toda figurinha passa por análise de segurança antes de aparecer para os membros.

## Onde fica
Servidor (toque no nome no topo) > **Figurinhas do servidor**, logo abaixo de *Convidar amigos*. Só aparece para o dono.

## Fluxo
1. **Dono envia**: escolhe a imagem, dá um nome, diz **que tipo é** (Meme, Reação, Logo, Arte própria, Outro) e confirma duas declarações (direito de uso e sem conteúdo proibido).
2. **No aparelho** (antes de enviar):
   - confere os bytes da imagem (PNG, JPG, WebP ou GIF; SVG é recusado);
   - limita 3 MB e 32 a 4096 px;
   - **redesenha** a imagem em 256×256 WebP/PNG, o que descarta metadados e qualquer coisa escondida no arquivo (fica parada, sem animação);
   - nome sem link, @ ou palavrão.
3. **No Firestore** (`palmas_sstk`, regras): nasce sempre `pend`; máximo **20 por servidor** (a vaga `servidor_1..20` é o limite); só o dono do servidor cria; formato e tamanho validados.
4. **Triagem automática (opcional)**, função `palmasFiguTriagem`: Cloud Vision recusa sozinho conteúdo adulto/violento e texto/link escrito dentro da imagem.
5. **ADM aprova**: Ajustes > Moderação > **Figurinhas**. Só o ADM muda para `ok`/`no`. Dá para **Remover** uma figurinha já aprovada.
6. **Membros**: só leem figurinhas `ok` do servidor em que estão. A figurinha aparece no seletor, numa aba com a foto/inicial do servidor, e vai na mensagem como `[figurinha:sv/<servidor>_<vaga>]`. Se for removida, as mensagens antigas mostram "Figurinha indisponível".

## O que precisa ser feito uma vez
1. Publicar as regras novas (`firebase/firestore.rules` ou `firestore.palmas-only.rules`: bloco `palmas_sstk`).
2. (Opcional, recomendado) Ativar a API **Cloud Vision** no projeto e publicar: `cd functions && npm install && firebase deploy --only functions`. Sem isso, tudo continua funcionando: as figurinhas esperam o ADM.

## Limites
- A triagem do aparelho **não enxerga o conteúdo** da imagem. Quem barra conteúdo impróprio é o Cloud Vision (se ligado) e, sempre, o ADM. Sem os dois, nada é aprovado.
- Reutilizar uma vaga (excluir e enviar de novo) faz mensagens antigas daquela vaga mostrarem a figurinha nova, depois de aprovada.
- Figurinhas não animadas. Se o servidor for apagado, os documentos ficam no Firestore (ninguém lê); o ADM pode limpá-los pelo console.

## v68: sem aprovação manual
O dono adiciona e a figurinha já vale na hora (`s:"ok"`). A função `palmasFiguTriagem`, se estiver publicada, ainda olha a imagem e muda para `no` o que tiver conteúdo adulto/violento ou link escrito. O ADM pode excluir qualquer figurinha pelo console. **Republique `firebase/firestore.rules`** (ou o bloco `palmas_sstk`).
