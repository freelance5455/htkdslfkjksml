# Marcações (@) e avisos no celular

## Como funciona para o usuário
- No chat, digite `@` e escolha a pessoa na lista (ou digite o @usuário inteiro). A menção aparece destacada e a mensagem de quem foi marcado fica com faixa laranja.
- Quem foi marcado recebe: faixa no app (se estiver em outro canal), vibração, número no título da aba e **notificação do sistema** (se o app estiver em segundo plano).
- Na primeira vez aparece "Ative os avisos…" no topo; toque em **Ativar** e aceite a permissão do navegador.

## Mensagens novas nos canais (v23)
- Na comunidade oficial o padrão agora é **avisar todas as mensagens** (antes era só @menção). Dá para mudar em: nome da comunidade > Avisos (Todas / Somente @menções / Nada) ou silenciando o servidor.
- O aviso mostra **quem mandou e em qual canal** ("Fulano em #Geral"). App em segundo plano: notificação do aparelho. App aberto em outro canal: cartão no topo.
- Canal com mensagem nova ganha uma **bolinha dourada** (e o nome fica em negrito). A bolinha também aparece no botão de menu e no ícone da comunidade. Some ao abrir o canal.
- Com o app **fechado**: precisa do Nível 2 abaixo (a função `palmasCanais` envia o aviso de todas as mensagens).

## Nível 1 – App aberto ou em segundo plano (já funciona, sem custo)
Usa o Firestore em tempo real + `sw.js` (precisa de **https** ou localhost). Se o navegador for fechado de vez, não chega nada.

## Nível 2 – App fechado (push de verdade, opcional)
Precisa de plano **Blaze** do Firebase (tem cota gratuita) e de 4 passos:
1. Console Firebase > Configurações do projeto > **Cloud Messaging** > Certificados push da Web > gerar par de chaves. Cole a chave pública em `var FCM_VAPID_KEY="";` no `index.html`.
2. Na pasta do projeto: `firebase init functions` (JavaScript, Node 20), copie `functions/index.js` e `functions/package.json` deste pacote.
3. `firebase deploy --only functions`.
4. Reabra o app, aceite os avisos: o token do aparelho é salvo em `palmas_users/<usuario>.fcm`.

No iPhone, notificações só funcionam com o app **instalado na tela inicial** (Compartilhar > Adicionar à Tela de Início) e iOS 16.4+.

## Limites
- Os avisos só valem para quem aceitou a permissão neste aparelho.
- O campo `mn` (marcados) é enviado pelo próprio app; nas regras atuais um usuário mal-intencionado poderia marcar pessoas à toa. Para blindar, valide `mn` na Cloud Function.
