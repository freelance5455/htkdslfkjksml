/* Palmas BR - avisos (push) e notificações. Deve ficar na mesma pasta do index.html. */
self.addEventListener("install",function(){self.skipWaiting()});
self.addEventListener("activate",function(e){e.waitUntil(self.clients.claim())});
self.addEventListener("push",function(e){
  var p={};try{p=e.data.json()}catch(x){}
  var d=p.data||p.notification||p;
  e.waitUntil(self.registration.showNotification(d.title||"Palmas BR",{body:d.body||"",icon:"palmas-192.png",badge:"palmas-192.png",tag:"mn-"+(d.ch||""),renotify:true,data:{ch:d.ch||""}}));
});
self.addEventListener("notificationclick",function(e){
  e.notification.close();var ch=e.notification.data&&e.notification.data.ch;
  e.waitUntil(self.clients.matchAll({type:"window",includeUncontrolled:true}).then(function(L){
    for(var i=0;i<L.length;i++){if("focus" in L[i]){L[i].postMessage({go:ch});return L[i].focus()}}
    return self.clients.openWindow("index.html");
  }));
});

/* Instalável: páginas abrem pela rede e guardam a última cópia para abrir sem internet. */
self.addEventListener("fetch",function(e){
  var r=e.request;if(r.method!=="GET"||r.mode!=="navigate")return;
  e.respondWith(fetch(r).then(function(res){
    if(res&&res.ok){var c=res.clone();caches.open("palmas-shell").then(function(k){k.put("./index.html",c)}).catch(function(){})}
    return res;
  }).catch(function(){
    return caches.match("./index.html").then(function(m){return m||Response.error()});
  }));
});
