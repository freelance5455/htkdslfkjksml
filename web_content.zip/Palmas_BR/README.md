# Palmas BR

Aplicativo de comunidades e mensagens em português, feito como um único arquivo HTML (sem dependências).
Versão atual: **prévia beta 0.7** (inclui o Palmas Bot: XP, níveis e ranking) · Tema escuro · Pensado primeiro para celular.

## Como usar
Abra `index.html` no navegador (de preferência por um link https). Para criar conta é preciso um **código de convite** beta.
Os dados ficam no `localStorage` do navegador (chave `palmas`). Exceção: nome, banner, foto e canais da comunidade oficial ficam no Firestore (`palmas_config/community`), para o app ficar igual em qualquer endereço ou aparelho (publique `firebase/firestore.rules`; um ADM abre *Editar comunidade* e toca em *Salvar* uma vez para publicar).

## Estrutura do pacote
| Pasta | Conteúdo |
|---|---|
| `index.html` | O aplicativo completo (abra este arquivo) |
| `docs/FUNCIONALIDADES.md` | Telas e recursos, o que funciona e o que é simulado |
| `docs/DADOS.md` | Estrutura dos dados salvos e do código |
| `docs/PENDENCIAS.md` | Limitações e próximos passos |
| `docs/SEGURANCA.md` | Segurança, moderação, LGPD e checklist do Firebase |
| `firebase.json` | Hospedagem com cabeçalhos de segurança |
| `docs/NOTIFICACOES.md` | Marcações (@) e avisos no celular |
| `sw.js`, `manifest.webmanifest`, `icon-*.png` | Avisos e instalação como app (deixar ao lado do index.html) |
| `functions/` | Cloud Function opcional para push com o app fechado |
| `docs/FIREBASE.md` | Passo a passo para conversar entre celulares |
| `firebase/firestore.rules` | Regras de segurança do Firestore |
| `docs/INSIGNIA-APOIADOR-INICIAL.md` | Insígnia Apoiador Inicial e código de resgate |
| `assets/bandeiras/` | As 27 insígnias de estado em SVG + `INDICE.md` |
