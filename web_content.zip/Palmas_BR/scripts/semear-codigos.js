// Cadastra no Firestore os códigos de insígnia (Beta Tester / Apoiador Inicial). Cada código vale UMA vez.
// Uso:
//   node semear-codigos.js <arquivo.txt>                 -> lê as linhas PALMAS-BETA-XXXX-XXXX / PALMAS-APOIADOR-XXXX-XXXX e cadastra
//   node semear-codigos.js --gerar beta 10 <arquivo.txt>  -> gera 10 códigos novos, cadastra e acrescenta ao arquivo
//   node semear-codigos.js --gerar apoiador 10 <arquivo.txt>
// Não deixe o .txt com os códigos dentro da pasta publicada (hosting). Rode no Cloud Shell ou logado como dono do projeto.
const admin = require("firebase-admin");
const crypto = require("crypto");
const fs = require("fs");

const sha = (t) => crypto.createHash("sha256").update(t).digest("hex");
const PRE = { beta: "palmas-beta:", apoiador: "palmas-apoiador:" };
const TAG = { beta: "BETA", apoiador: "APOIADOR" };
const AL = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

const args = process.argv.slice(2);
let lista = [];
let arq;
if (args[0] === "--gerar") {
  const kind = args[1], n = Math.min(200, parseInt(args[2], 10) || 0);
  arq = args[3];
  if (!PRE[kind] || !n || !arq) { console.log("Uso: node semear-codigos.js --gerar beta|apoiador N arquivo.txt"); process.exit(1); }
  for (let i = 0; i < n; i++) {
    const b = crypto.randomBytes(8); let s = "";
    for (let j = 0; j < 8; j++) s += AL[b[j] % 32];
    lista.push({ kind, code: "PALMAS-" + TAG[kind] + "-" + s.slice(0, 4) + "-" + s.slice(4) });
  }
} else {
  arq = args[0];
  if (!arq || !fs.existsSync(arq)) { console.log("Uso: node semear-codigos.js arquivo.txt"); process.exit(1); }
  const re = /PALMAS-(BETA|APOIADOR)-[A-Z0-9]{4}-[A-Z0-9]{4}/g;
  for (const m of fs.readFileSync(arq, "utf8").toUpperCase().match(re) || [])
    lista.push({ kind: m.includes("-BETA-") ? "beta" : "apoiador", code: m });
}
if (!lista.length) { console.log("Nenhum código encontrado."); process.exit(1); }

admin.initializeApp({ projectId: process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT || "eldoria-6720d" });
const db = admin.firestore();

(async () => {
  let novos = 0, jaExistiam = 0;
  for (const { kind, code } of lista) {
    const ref = db.collection("palmas_badge_codes").doc(sha(PRE[kind] + code));
    const d = await ref.get();
    if (d.exists) { jaExistiam++; continue; } // não reativa código já cadastrado/usado
    await ref.set({ kind, used: false, by: null, at: null });
    novos++;
  }
  if (args[0] === "--gerar") {
    fs.appendFileSync(arq, "\n" + lista.map((x) => x.code).join("\n") + "\n");
    console.log("Códigos gerados e salvos em", arq);
  }
  console.log("Cadastrados:", novos, "· já existiam:", jaExistiam);
})().catch((e) => { console.error(e); process.exit(1); });
