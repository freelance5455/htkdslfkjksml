// Cria a conta de ADM do Palmas BR (login + perfil + documento em palmas_admins) e, se quiser, convites.
// Uso:  node criar-adm.js <usuario> "<Nome>" "<senha>" [--convites N]
// Rode no Cloud Shell (shell.cloud.google.com) ou no seu computador logado como dono do projeto Firebase.
const admin = require("firebase-admin");
const crypto = require("crypto");

const args = process.argv.slice(2);
const ci = args.indexOf("--convites");
const nConv = ci > -1 ? Math.min(50, Math.max(0, parseInt(args[ci + 1], 10) || 0)) : 0;
const [u0, nome, senha] = args;
const u = String(u0 || "").trim().toLowerCase();

if (!/^[a-z0-9_.]{3,20}$/.test(u) || !nome || !senha) {
  console.log('Uso: node criar-adm.js <usuario> "<Nome>" "<senha>" [--convites N]');
  console.log("Usuário: 3 a 20 letras minúsculas, números, _ ou ponto. Senha: mínimo 8 caracteres.");
  process.exit(1);
}
if (senha.length < 8) { console.log("A senha precisa ter pelo menos 8 caracteres."); process.exit(1); }

admin.initializeApp({ projectId: process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT || "eldoria-6720d" });
const sha = (t) => crypto.createHash("sha256").update(t).digest("hex");

(async () => {
  const email = u + "@palmas.app";
  let user;
  try {
    user = await admin.auth().getUserByEmail(email);
    await admin.auth().updateUser(user.uid, { password: senha, displayName: nome });
    console.log("O login já existia: a senha foi atualizada.");
  } catch (e) {
    if (e.code !== "auth/user-not-found") throw e;
    user = await admin.auth().createUser({ email, password: senha, displayName: nome, emailVerified: true });
    console.log("Login criado:", email);
  }
  const db = admin.firestore();
  await db.collection("palmas_users").doc(u).set({
    uid: user.uid, user: u, n: nome, uf: "", bio: "", st: "Online", b: "beta",
    joined: new Date().toLocaleDateString("pt-BR"), av: "", bn: "", inv: sha("admin-inicial"),
  }, { merge: true });
  await db.collection("palmas_admins").doc(u).set({ ok: true });
  console.log("Perfil e ADM criados para @" + u);

  if (nConv) {
    const AL = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789", codes = [];
    for (let i = 0; i < nConv; i++) {
      const b = crypto.randomBytes(12); let s = "";
      for (let j = 0; j < 12; j++) s += AL[b[j] % 32];
      codes.push("PALMAS-" + s.slice(0, 4) + "-" + s.slice(4, 8) + "-" + s.slice(8));
    }
    await Promise.all(codes.map((c) => db.collection("palmas_invites").doc(sha(c.toUpperCase().replace(/[^A-Z0-9]/g, "")))
      .set({ used: false, by: null, at: null, note: "por " + u })));
    console.log("\nConvites (cada um vale para uma conta):\n" + codes.join("\n"));
  }
  console.log("\nPronto. No app: Já tenho conta > Entrar com @" + u + " e a senha.");
  process.exit(0);
})().catch((e) => { console.error("Erro:", e.message); process.exit(1); });
