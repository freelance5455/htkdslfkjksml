# Bandeiras dos estados (insígnias)

UF | Estado | Arquivo
---|---|---
AC | Acre | assets/bandeiras/AC.svg
AL | Alagoas | assets/bandeiras/AL.svg
AP | Amapá | assets/bandeiras/AP.svg
AM | Amazonas | assets/bandeiras/AM.svg
BA | Bahia | assets/bandeiras/BA.svg
CE | Ceará | assets/bandeiras/CE.svg
DF | Distrito Federal | assets/bandeiras/DF.svg
ES | Espírito Santo | assets/bandeiras/ES.svg
GO | Goiás | assets/bandeiras/GO.svg
MA | Maranhão | assets/bandeiras/MA.svg
MT | Mato Grosso | assets/bandeiras/MT.svg
MS | Mato Grosso do Sul | assets/bandeiras/MS.svg
MG | Minas Gerais | assets/bandeiras/MG.svg
PA | Pará | assets/bandeiras/PA.svg
PB | Paraíba | assets/bandeiras/PB.svg
PR | Paraná | assets/bandeiras/PR.svg
PE | Pernambuco | assets/bandeiras/PE.svg
PI | Piauí | assets/bandeiras/PI.svg
RJ | Rio de Janeiro | assets/bandeiras/RJ.svg
RN | Rio Grande do Norte | assets/bandeiras/RN.svg
RS | Rio Grande do Sul | assets/bandeiras/RS.svg
RO | Rondônia | assets/bandeiras/RO.svg
RR | Roraima | assets/bandeiras/RR.svg
SC | Santa Catarina | assets/bandeiras/SC.svg
SP | São Paulo | assets/bandeiras/SP.svg
SE | Sergipe | assets/bandeiras/SE.svg
TO | Tocantins | assets/bandeiras/TO.svg
