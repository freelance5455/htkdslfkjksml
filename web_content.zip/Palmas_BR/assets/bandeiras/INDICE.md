# Bandeiras dos estados (insígnias)

UF | Estado | Arquivo
---|---|---
AC | Acre | assets/bandeiras/AC.svg
AL | Alagoas | assets/bandeiras/AL.svg
AP | Amapá | assets/bandeiras/AP.svg
AM | Amazonas | assets/bandeiras/AM.svg
BA | Bahia | assets/bandeiras/BA.svg
CE | Ceará | assets/bandeiras/CE.svg
DF | Distrito Federal | assets/bandeiras/DF.svg
ES | Espírito Santo | assets/bandeiras/ES.svg
GO | Goiás | assets/bandeiras/GO.svg
MA | Maranhão | assets/bandeiras/MA.svg
MT | Mato Grosso | assets/bandeiras/MT.svg
MS | Mato Grosso do Sul | assets/bandeiras/MS.svg
MG | Minas Gerais | assets/bandeiras/MG.svg
PA | Pará | assets/bandeiras/PA.svg
PB | Paraíba | assets/bandeiras/PB.svg
PR | Paraná | assets/bandeiras/PR.svg
PE | Pernambuco | assets/bandeiras/PE.svg
PI | Piauí | assets/bandeiras/PI.svg
RJ | Rio de Janeiro | assets/bandeiras/RJ.svg
RN | Rio Grande do Norte | assets/bandeiras/RN.svg
RS | Rio Grande do Sul | assets/bandeiras/RS.svg
RO | Rondônia | assets/bandeiras/RO.svg
RR | Roraima | assets/bandeiras/RR.svg
SC | Santa Catarina | assets/bandeiras/SC.svg
SP | São Paulo | assets/bandeiras/SP.svg
SE | Sergipe | assets/bandeiras/SE.svg
TO | Tocantins | assets/bandeiras/TO.svg

## Países (quem mora fora do Brasil)

Código | País | Arquivo
---|---|---
DE | Alemanha | assets/bandeiras/paises/DE.svg
AO | Angola | assets/bandeiras/paises/AO.svg
AR | Argentina | assets/bandeiras/paises/AR.svg
AU | Austrália | assets/bandeiras/paises/AU.svg
AT | Áustria | assets/bandeiras/paises/AT.svg
BE | Bélgica | assets/bandeiras/paises/BE.svg
BO | Bolívia | assets/bandeiras/paises/BO.svg
CV | Cabo Verde | assets/bandeiras/paises/CV.svg
CA | Canadá | assets/bandeiras/paises/CA.svg
CL | Chile | assets/bandeiras/paises/CL.svg
CN | China | assets/bandeiras/paises/CN.svg
CO | Colômbia | assets/bandeiras/paises/CO.svg
KR | Coreia do Sul | assets/bandeiras/paises/KR.svg
CR | Costa Rica | assets/bandeiras/paises/CR.svg
CU | Cuba | assets/bandeiras/paises/CU.svg
DK | Dinamarca | assets/bandeiras/paises/DK.svg
EG | Egito | assets/bandeiras/paises/EG.svg
EC | Equador | assets/bandeiras/paises/EC.svg
ES | Espanha | assets/bandeiras/paises/ES.svg
US | Estados Unidos | assets/bandeiras/paises/US.svg
FI | Finlândia | assets/bandeiras/paises/FI.svg
FR | França | assets/bandeiras/paises/FR.svg
GR | Grécia | assets/bandeiras/paises/GR.svg
GW | Guiné-Bissau | assets/bandeiras/paises/GW.svg
HU | Hungria | assets/bandeiras/paises/HU.svg
IN | Índia | assets/bandeiras/paises/IN.svg
IE | Irlanda | assets/bandeiras/paises/IE.svg
IL | Israel | assets/bandeiras/paises/IL.svg
IT | Itália | assets/bandeiras/paises/IT.svg
JP | Japão | assets/bandeiras/paises/JP.svg
MA | Marrocos | assets/bandeiras/paises/MA.svg
MX | México | assets/bandeiras/paises/MX.svg
MZ | Moçambique | assets/bandeiras/paises/MZ.svg
NO | Noruega | assets/bandeiras/paises/NO.svg
NZ | Nova Zelândia | assets/bandeiras/paises/NZ.svg
NL | Países Baixos | assets/bandeiras/paises/NL.svg
PY | Paraguai | assets/bandeiras/paises/PY.svg
PE | Peru | assets/bandeiras/paises/PE.svg
PL | Polônia | assets/bandeiras/paises/PL.svg
PT | Portugal | assets/bandeiras/paises/PT.svg
GB | Reino Unido | assets/bandeiras/paises/GB.svg
RO | Romênia | assets/bandeiras/paises/RO.svg
RU | Rússia | assets/bandeiras/paises/RU.svg
ST | São Tomé e Príncipe | assets/bandeiras/paises/ST.svg
SE | Suécia | assets/bandeiras/paises/SE.svg
CH | Suíça | assets/bandeiras/paises/CH.svg
CZ | Tchéquia | assets/bandeiras/paises/CZ.svg
TL | Timor-Leste | assets/bandeiras/paises/TL.svg
TR | Turquia | assets/bandeiras/paises/TR.svg
UA | Ucrânia | assets/bandeiras/paises/UA.svg
UY | Uruguai | assets/bandeiras/paises/UY.svg
VE | Venezuela | assets/bandeiras/paises/VE.svg

No app o valor salvo no perfil é `C:` + código (ex.: `C:PT`).
