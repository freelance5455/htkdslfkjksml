# Figurinhas de imagem

Coloque aqui as imagens (PNG, WebP, GIF ou JPG, de preferência quadradas, até ~100 KB).
Use nomes só com letras minúsculas, números, - e _ (ex.: `show.png`).

Para aparecer no painel, acrescente o arquivo em `STK_IMG` no `index.html`:

    var STK_IMG=[["show.png","Show"],["medo.png","Medo"]];

As 4 imagens desta pasta são exemplos feitos para o projeto: troque pelas suas.
Use só imagens suas ou que você tem direito de usar.
