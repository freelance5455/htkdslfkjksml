=== Turbo Downloader & Multi-Thread Speed Package ===

Dieses Paket enthält alle Dateien (Python, HTML, Shell, Batch).

DATEIEN IN DIESEM PAKET:
1. index.html          - Die interaktive Web-Oberfläche / Dashboard.
2. fast_downloader.py   - Das Python-Skript (installiert 'requests' automatisch & lädt schnell).
3. run_downloader.sh    - Shell-Skript für Linux/macOS/Termux.
4. run_downloader.bat   - Batch-Skript für Windows.
5. README.txt           - Diese Anleitung.
