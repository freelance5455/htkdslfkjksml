#!/bin/sh
python3 fast_downloader.py
