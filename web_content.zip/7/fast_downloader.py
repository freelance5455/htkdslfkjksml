import os
import sys
import subprocess

# 1. Automatische Installation von 'requests', falls es fehlt
try:
    import requests
except ImportError:
    print("[+] Modul 'requests' fehlt. Installiere automatisch...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

import threading

def download_chunk(url, start, end, part_filename):
    headers = {'Range': f'bytes={start}-{end}'}
    try:
        response = requests.get(url, headers=headers, stream=True, timeout=10)
        with open(part_filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
    except Exception as e:
        print(f"\n[Fehler im Thread] {e}")

def turbo_download(url, output_folder="downloads", num_threads=8):
    os.makedirs(output_folder, exist_ok=True)
    filename = url.split("/")[-1].split("?")[0] or "downloaded_file.bin"
    filepath = os.path.join(output_folder, filename)
    
    print(f"\n[1/3] Verbinde: {url}")
    try:
        head_res = requests.head(url, allow_redirects=True, timeout=10)
        file_size = int(head_res.headers.get('content-length', 0))
    except Exception:
        file_size = 0

    if file_size == 0:
        print("[!] Server unterstützt kein Multi-Threading. Starte normalen Download...")
        res = requests.get(url, stream=True)
        with open(filepath, 'wb') as f:
            for chunk in res.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f"[✔] Download fertig! Gespeichert in: {filepath}")
        return

    print(f"[2/3] Dateigröße: {file_size / (1024*1024):.2f} MB. Starte {num_threads} Threads parallel...")
    chunk_size = file_size // num_threads
    threads = []
    part_files = []

    for i in range(num_threads):
        start = i * chunk_size
        end = file_size - 1 if i == num_threads - 1 else start + chunk_size - 1
        part_filename = f"{filepath}.part{i}"
        part_files.append(part_filename)

        t = threading.Thread(target=download_chunk, args=(url, start, end, part_filename))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print(f"[3/3] Füge Teildateien zusammen...")
    with open(filepath, 'wb') as outfile:
        for part_file in part_files:
            if os.path.exists(part_file):
                with open(part_file, 'rb') as infile:
                    outfile.write(infile.read())
                os.remove(part_file)

    print(f"\n[✔] Fertig! Gespeichert unter: {os.path.abspath(filepath)}")

if __name__ == "__main__":
    url_input = input("Gib die Download-URL ein: ").strip()
    if url_input:
        turbo_download(url_input, output_folder="downloads", num_threads=8)
