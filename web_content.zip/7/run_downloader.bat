@echo off
python fast_downloader.py
pause
