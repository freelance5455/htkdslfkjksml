# Handover 2026 — Android Studio project

## Included
- Futuristic dark UI
- Initial login: `handover` / `handover`
- Department → unit → room → bed folder navigation
- Patient ID, history & physical examination, diagnosis, investigations, treatment, plan, new complaints
- Delete-room action (asks for confirmation and deletes all beds/patient entries inside the room)
- Multiple imaging/PACS links
- Local offline storage and JSON backup/restore
- Android WebView wrapper

## Important limitations
This is a functional prototype, not a validated clinical information system. Local data is stored in WebView local storage and is **not encrypted**. Do not enter identifiable patient data into this prototype or deploy it for clinical use without a security review, encryption, audit logs, access control, backup strategy, and institutional approval.

Online status is displayed, but **multi-device online synchronization is not implemented**. That requires a secure backend/API, authentication, conflict handling, and server/database hosting. No server credentials or endpoint were supplied.

## Build an APK
This environment did not have the Android SDK, Android Gradle build tools, or Gradle installed, so an APK could not be compiled here. To build:
1. Install Android Studio with Android SDK Platform 35 and a compatible JDK.
2. Open this folder (`Handover2026`) in Android Studio.
3. Allow Gradle sync and install any requested SDK components.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

For an installable release APK, configure signing in Android Studio and build a signed APK.
