OX Berserkco Android project
============================

This is an Android Studio / AndroidIDE project wrapper for the included OX Berserkco HTML app.
App ID: com.oxberserkco.app
Version: 1.1
Login password: FFH4X

Build into an APK on Android:
1. Install a reputable Android IDE/build environment that supports Android Gradle projects (for example AndroidIDE, if currently supported on your device).
2. Extract this ZIP to a folder.
3. Open/import the extracted OX_Berserkco_Android folder as an existing Gradle project.
4. Allow Gradle sync and install the required Android SDK platform/build tools when prompted.
5. Use the IDE's Build APK / Assemble Debug task. The APK will be placed under app/build/outputs/apk/debug/.

Important limitations:
- This project has NOT been compiled into an APK in this environment because an Android SDK/Gradle build environment is not installed here.
- No Android accessibility, screen-capture, overlay, or touch-injection permissions are requested.
- The tap recorder is a practice demo inside this app only; it does not replay touches in other apps or games.
- Sensitivity controls and crosshair designs are in-app presets/previews and do not change Free Fire settings.
- AI chat is demo/offline logic, not connected to an AI service.

Included in this version: in-app Performance Mode (reduces this dashboard's animations/shadows), a browser-visible device hint check, and a gaming readiness checklist. These features do not modify Android system RAM/CPU/GPU settings or game files.


Version 1.2 floating panel
--------------------------
After entering the app password, tap START FLOATING PANEL on the Home screen. Android will open the system permission page for “Display over other apps”; enable it only if you want the floating control. Return to the app. A draggable wolf icon will appear above other apps. Tap it for shortcuts to Home, Sensitivity, Crosshair Studio, Gaming Optimizer, and Training Tools. HIDE PANEL closes the shortcut menu; stop the app/service from Android app settings or reopen the app to start it again.

The overlay is a draggable shortcut menu only. It does not record screen content, capture touches in other apps, inject/replay taps, or automate game actions. Overlay permission is optional and controlled by Android. This project has not been compiled into an APK in this environment because Android SDK/build tools are unavailable.
