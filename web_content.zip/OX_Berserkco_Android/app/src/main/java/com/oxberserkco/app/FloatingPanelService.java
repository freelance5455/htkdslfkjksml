package com.oxberserkco.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** A user-started, draggable shortcut panel. It does not capture or inject touches. */
public class FloatingPanelService extends Service {
    private WindowManager windowManager;
    private View bubble;
    private View panel;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private boolean panelOpen = false;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showBubble();
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private WindowManager.LayoutParams params(int width, int height, int gravity) {
        return new WindowManager.LayoutParams(width, height, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void showBubble() {
        if (bubble != null) return;
        TextView icon = text("🐺", 27);
        icon.setBackground(roundBg(Color.rgb(170, 18, 48)));
        icon.setElevation(12f);
        bubble = icon;
        bubbleParams = params(dp(58), dp(58), Gravity.TOP | Gravity.START);
        bubbleParams.x = dp(12); bubbleParams.y = dp(180);
        icon.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: downX=e.getRawX(); downY=e.getRawY(); startX=bubbleParams.x; startY=bubbleParams.y; moved=false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx=(int)(e.getRawX()-downX), dy=(int)(e.getRawY()-downY);
                        if (Math.abs(dx)>5 || Math.abs(dy)>5) moved=true;
                        bubbleParams.x=startX+dx; bubbleParams.y=startY+dy;
                        try { windowManager.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP: if (!moved) togglePanel(); return true;
                }
                return false;
            }
        });
        windowManager.addView(bubble, bubbleParams);
    }

    private android.graphics.drawable.GradientDrawable roundBg(int color) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(18)); d.setStroke(dp(1), Color.rgb(255, 70, 96)); return d;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void togglePanel() { if (panelOpen) hidePanel(); else showPanel(); }

    private void showPanel() {
        if (panel != null) { panelOpen=true; panel.setVisibility(View.VISIBLE); return; }
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(12), dp(10), dp(12), dp(10)); box.setBackground(roundBg(Color.rgb(24, 10, 15))); box.setElevation(18f);
        TextView title = text("OX BERSERKCO", 15); title.setPadding(0,0,0,dp(8)); box.addView(title);
        addShortcut(box, "🏠  Open app", "home");
        addShortcut(box, "🎯  Sensitivity", "sensitivity");
        addShortcut(box, "✛  Crosshair Studio", "crosshair");
        addShortcut(box, "⚡  Gaming Optimizer", "optimizer");
        addShortcut(box, "🛠  Training Tools", "tools");
        Button close = new Button(this); close.setText("HIDE PANEL"); close.setTextColor(Color.WHITE); close.setBackground(roundBg(Color.rgb(105, 16, 38))); close.setOnClickListener(v -> hidePanel()); box.addView(close);
        panel = box; panelParams = params(dp(220), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        panelParams.x = Math.max(dp(8), bubbleParams.x - dp(150)); panelParams.y = bubbleParams.y + dp(64);
        windowManager.addView(panel, panelParams); panelOpen=true;
    }

    private void addShortcut(LinearLayout box, String label, String section) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTextSize(13); b.setBackground(roundBg(Color.rgb(48, 18, 28)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46)); lp.bottomMargin=dp(5); box.addView(b, lp);
        b.setOnClickListener(v -> { Intent i = new Intent(this, MainActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP); i.putExtra("ox_section", section); startActivity(i); hidePanel(); });
    }

    private void hidePanel() {
        if (panel != null) { try { windowManager.removeView(panel); } catch (Exception ignored) {} panel=null; }
        panelOpen=false;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_NOT_STICKY; }
    @Override public void onDestroy() { hidePanel(); if (bubble != null) { try { windowManager.removeView(bubble); } catch (Exception ignored) {} bubble=null; } super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
