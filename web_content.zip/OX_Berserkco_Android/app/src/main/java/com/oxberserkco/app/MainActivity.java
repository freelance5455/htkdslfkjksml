package com.oxberserkco.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 4412;
    private WebView webView;
    private boolean pendingOverlayStart = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(android.graphics.Color.rgb(16, 6, 9));
        window.setNavigationBarColor(android.graphics.Color.rgb(16, 6, 9));
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new AppBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private class AppBridge {
        @JavascriptInterface
        public void startFloatingPanel() {
            runOnUiThread(() -> requestOverlayAndStart());
        }
    }

    private void requestOverlayAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            pendingOverlayStart = true;
            Toast.makeText(this, "Allow display over other apps for the floating icon", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_REQUEST);
            return;
        }
        startOverlayService();
    }

    private void startOverlayService() {
        Intent service = new Intent(this, FloatingPanelService.class);
        startService(service);
        if (webView != null) webView.evaluateJavascript("setOverlayStatus('Floating wolf icon is active. Drag it; tap it to open options.');", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && pendingOverlayStart) {
            pendingOverlayStart = false;
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) startOverlayService();
            else if (webView != null) webView.evaluateJavascript("setOverlayStatus('Overlay permission was not enabled. You can enable it in Android Settings and try again.');", null);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String section = intent.getStringExtra("ox_section");
        if (section != null && webView != null) {
            final String safeSection = section.replaceAll("[^a-z]", "");
            webView.postDelayed(() -> webView.evaluateJavascript(
                    "if(!document.getElementById('app').hidden){showSection('" + safeSection + "');}", null), 250);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
