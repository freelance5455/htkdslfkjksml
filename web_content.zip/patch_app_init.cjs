const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetInit = `export default function App() {
  const [currentTab, setCurrentTab] = useState('worship');
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      return offlineCache?.getProfile?.() || { email: 'juhnkrix.musika@gmail.com', name: 'Prophetic Believer' };
    } catch {
      return { email: 'juhnkrix.musika@gmail.com', name: 'Prophetic Believer' };
    }
  });`;

const replacementInit = `export default function App() {
  const [currentTab, setCurrentTab] = useState('worship');
  const [isInitializing, setIsInitializing] = useState(true);
  const [engineInitError, setEngineInitError] = useState<string | null>(null);

  useEffect(() => {
    // Robust Initialization Service wrapper with 'graceful-fallback' state
    const initializeEngines = async () => {
      try {
        if (typeof audioEngine?.init === 'function') {
          await audioEngine.init();
        }
        if (typeof offlineCache?.init === 'function') {
          await offlineCache.init();
        }
      } catch (err) {
        console.warn('One or more engines failed to initialize. Running in graceful-fallback mode.', err);
        setEngineInitError('Audio or Cache Engine failed to load fully. The app will continue to operate with limited offline capabilities.');
      } finally {
        setIsInitializing(false);
      }
    };
    
    initializeEngines();
  }, []);

  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      return offlineCache?.getProfile?.() || { email: 'juhnkrix.musika@gmail.com', name: 'Prophetic Believer' };
    } catch {
      return { email: 'juhnkrix.musika@gmail.com', name: 'Prophetic Believer' };
    }
  });`;

if (code.includes(targetInit)) {
  code = code.replace(targetInit, replacementInit);
} else {
  console.log("Could not find target init to replace");
}

fs.writeFileSync('src/App.tsx', code);
