import { useCallback, useEffect, useRef, useState } from 'react';
import { soundEngine } from './audio/soundEngine';
import { FlightHUD } from './components/FlightHUD';
import { InteractiveWorldMap } from './components/InteractiveWorldMap';
import {
  AtcTowerBriefingModal,
  CareerHubScreen,
  EconomyScreen,
  FlightPrepScreen,
  FlightResultsScreen,
  HangarScreen,
  MainMenuScreen,
  PauseModal,
  SettingsScreen,
  WorldMapScreen,
} from './components/Menus';
import { getAircraftById } from './data/aircraft';
import { AIRPORTS, getAirportById } from './data/airports';
import { WorldPixelRenderer } from './graphics/worldRenderer';
import {
  adjustAutopilotAltitude,
  AP_ALT_STEP_FT,
  createInitialPhysicsState,
  createSimulationContext,
  FlightSimulationContext,
  retargetSimulationDestination,
  setAutopilotEnabled,
  stepFlightPhysics,
} from './physics/flightPhysics';
import {
  applyCareerFlightResult,
  createInitialCareerSave,
  hasSavedCareer,
  loadCareerSave,
  loadGameSettings,
  purchaseAircraft,
  purchaseLicense,
  refuelOwnedAircraft,
  repairOwnedAircraft,
  saveCareerData,
  saveGameSettings,
  selectCareerAircraftAndRefreshAtc,
} from './storage/careerStorage';
import {
  CameraMode,
  CareerAtcAssignment,
  CareerSaveData,
  ControlMode,
  DescentGuidanceStage,
  EmergencyType,
  FlightPhysicsState,
  FlightResultSummary,
  FlightSetupConfig,
  GameSettings,
  LicenseId,
  ScreenId,
  TimeOfDay,
  WeatherType,
} from './types/game';

const FIXED_DT = 1 / 120;

function cloneHudSnapshot(st: FlightPhysicsState): FlightPhysicsState {
  return {
    ...st,
    liveWeather: { ...st.liveWeather },
    navData: { ...st.navData },
    assistantAdvisory: st.assistantAdvisory ? { ...st.assistantAdvisory } : null,
    atcMessage: st.atcMessage ? { ...st.atcMessage } : null,
    atcHistory: st.atcHistory.slice(),
  };
}

function createDemoMenuFlight(): {
  ctx: FlightSimulationContext;
  state: FlightPhysicsState;
} {
  const demoSetup: FlightSetupConfig = {
    mode: 'free',
    aircraftId: 'cessna_172',
    departureId: 'limb',
    destinationId: 'lsza',
    fuelKg: 115,
    payloadKg: 160,
    passengers: 2,
    plannedEmergency: EmergencyType.NONE,
    weather: {
      type: WeatherType.CLEAR,
      timeOfDay: TimeOfDay.SUNSET,
      windDirectionDeg: 205,
      windSpeedKt: 7,
      headwindKt: 6,
      crosswindKt: 2,
      cloudCover: 0.2,
      gustIntensityKt: 3,
      turbulence: 0.08,
      visibilityKm: 22,
    },
  };
  const ctx = createSimulationContext(demoSetup);
  const state = createInitialPhysicsState(ctx);
  // Start airborne cruising gently past mountains and airport for atmospheric live background
  state.sM = 320;
  state.altM = 390;
  state.aglM = 240;
  state.vxMs = 58;
  state.vyMs = 0;
  state.throttle = 0.72;
  state.enginePowerPct = 72;
  state.rpm = 2350;
  state.flapStage = 0;
  state.flapAngleDeg = 0;
  state.onGround = false;
  state.hasTakenOff = true;
  return { ctx, state };
}

export default function App() {
  const [career, setCareer] = useState<CareerSaveData>(() => loadCareerSave());
  const [saveExists, setSaveExists] = useState<boolean>(() => hasSavedCareer());
  const [settings, setSettings] = useState<GameSettings>(() => loadGameSettings());
  const [screen, setScreen] = useState<ScreenId>(ScreenId.MAIN_MENU);
  const [isPaused, setIsPaused] = useState(false);
  const [inFlightMapOpen, setInFlightMapOpen] = useState(false);
  const [atcBriefingOpen, setAtcBriefingOpen] = useState(false);
  const [mapWaypoints, setMapWaypoints] = useState<string[]>([]);

  const [cameraMode, setCameraMode] = useState<CameraMode>(CameraMode.STANDARD);
  const [userZoom, setUserZoom] = useState<number>(1.0);
  const [simSpeed, setSimSpeed] = useState<1 | 2 | 4>(1);

  const [pendingSetup, setPendingSetup] = useState<FlightSetupConfig>(() => ({
    mode: 'free',
    aircraftId: 'cessna_172',
    departureId: 'limb',
    destinationId: 'lsza',
    fuelKg: 110,
    payloadKg: 170,
    passengers: 2,
    plannedEmergency: EmergencyType.NONE,
    weather: {
      type: WeatherType.CLEAR,
      timeOfDay: TimeOfDay.DAY,
      windDirectionDeg: 210,
      windSpeedKt: 6,
      headwindKt: 5,
      crosswindKt: 0,
      cloudCover: 0.18,
      gustIntensityKt: 2,
      turbulence: 0.06,
      visibilityKm: 20,
    },
  }));

  const [hudState, setHudState] = useState<FlightPhysicsState>(() => createDemoMenuFlight().state);
  const [flightResult, setFlightResult] = useState<FlightResultSummary | null>(null);

  // Mutable simulation refs isolated from React render cycle
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const worldRendererRef = useRef<WorldPixelRenderer>(new WorldPixelRenderer());
  const simCtxRef = useRef<FlightSimulationContext>(createDemoMenuFlight().ctx);
  const physStateRef = useRef<FlightPhysicsState>(createDemoMenuFlight().state);
  const initialFuelRef = useRef<number>(115);

  const overlayPaused = isPaused || inFlightMapOpen || atcBriefingOpen;

  const screenRef = useRef<ScreenId>(screen);
  const pausedRef = useRef<boolean>(overlayPaused);
  const settingsRef = useRef<GameSettings>(settings);
  const cameraModeRef = useRef<CameraMode>(cameraMode);
  const userZoomRef = useRef<number>(userZoom);
  const simSpeedRef = useRef<1 | 2 | 4>(simSpeed);
  const careerRef = useRef<CareerSaveData>(career);

  const [activePitchDir, setActivePitchDir] = useState<-1 | 0 | 1>(0);
  const [activeThrottleDir, setActiveThrottleDir] = useState<-1 | 0 | 1>(0);

  const heldKeysRef = useRef<Set<string>>(new Set());
  const sliderPitchRef = useRef<number>(0);
  const sliderPitchHeldRef = useRef<boolean>(false);
  const buttonTrimOffsetRef = useRef<number>(0);
  const touchPitchRef = useRef<number>(0);
  const touchPitchBtnRef = useRef<-1 | 0 | 1>(0);
  const touchThrottleBtnRef = useRef<-1 | 0 | 1>(0);
  const touchBrakeRef = useRef<boolean>(false);
  const hitstopTimerRef = useRef<number>(0);
  const prevOnGroundRef = useRef<boolean>(true);
  const prevBounceCountRef = useRef<number>(0);
  const prevLightningRef = useRef<number>(0);
  const prevGuidanceStageRef = useRef<DescentGuidanceStage>('HOLD_ALTITUDE');
  const prevDecisionHeightRef = useRef<boolean>(false);

  useEffect(() => {
    screenRef.current = screen;
  }, [screen]);
  useEffect(() => {
    pausedRef.current = overlayPaused;
  }, [overlayPaused]);
  useEffect(() => {
    settingsRef.current = settings;
    soundEngine.configure(settings.soundEnabled, settings.soundVolume);
  }, [settings]);
  useEffect(() => {
    cameraModeRef.current = cameraMode;
  }, [cameraMode]);
  useEffect(() => {
    userZoomRef.current = userZoom;
  }, [userZoom]);
  useEffect(() => {
    simSpeedRef.current = simSpeed;
  }, [simSpeed]);
  useEffect(() => {
    careerRef.current = career;
  }, [career]);

  // Launch a flight session from a finalized FlightSetupConfig
  const startFlightSession = useCallback((setupConfig: FlightSetupConfig) => {
    const currentCareer = careerRef.current;
    const ownedState =
      setupConfig.mode === 'career'
        ? currentCareer.ownedAircraft.find((a) => a.aircraftId === setupConfig.aircraftId)
        : undefined;

    const ctx = createSimulationContext(setupConfig, ownedState);
    const phys = createInitialPhysicsState(ctx);

    simCtxRef.current = ctx;
    physStateRef.current = phys;
    initialFuelRef.current = setupConfig.fuelKg;
    prevOnGroundRef.current = true;
    prevBounceCountRef.current = 0;
    prevGuidanceStageRef.current = 'HOLD_ALTITUDE';
    prevDecisionHeightRef.current = false;
    hitstopTimerRef.current = 0;
    sliderPitchRef.current = 0;
    sliderPitchHeldRef.current = false;
    buttonTrimOffsetRef.current = 0;
    touchPitchRef.current = 0;
    touchPitchBtnRef.current = 0;
    touchThrottleBtnRef.current = 0;
    touchBrakeRef.current = false;
    setActivePitchDir(0);
    setActiveThrottleDir(0);

    worldRendererRef.current.resetCamera(phys);
    setPendingSetup(setupConfig);
    setHudState(cloneHudSnapshot(phys));
    setSimSpeed(1);
    setIsPaused(false);
    setInFlightMapOpen(false);
    if (setupConfig.mode === 'career') {
      setMapWaypoints([]);
    }
    // In Career Mode, present the official Control Tower Flight Plan & Clearance window before takeoff!
    setAtcBriefingOpen(Boolean(setupConfig.mode === 'career' && setupConfig.atcAssignment));
    setFlightResult(null);
    setScreen(ScreenId.FLYING);

    soundEngine.configure(settingsRef.current.soundEnabled, settingsRef.current.soundVolume);
    soundEngine.startFlightLoop(ctx.aircraft);
  }, []);

  // Finalize flight when landed or crashed
  const finalizeFlight = useCallback(() => {
    const ctx = simCtxRef.current;
    const st = physStateRef.current;
    soundEngine.stopFlightLoop();
    setInFlightMapOpen(false);
    setAtcBriefingOpen(false);

    const landedAirport = st.landedAirportId ? getAirportById(st.landedAirportId) : null;
    const fuelUsedKg = Math.max(0, initialFuelRef.current - st.fuelKg);
    const centerlineErrorM = Math.abs(st.lateralOffsetM);

    let outcome: FlightResultSummary['outcome'] = 'SUCCESS';
    let reason = `Atterraggio regolare sulla pista di ${landedAirport?.name || ctx.destination.name}.`;

    if (st.crashed) {
      outcome = 'CRASHED';
      reason = st.crashReason || 'Impatto strutturale al suolo.';
      soundEngine.playCrash();
    } else if (!landedAirport) {
      outcome = 'DAMAGED';
      reason = 'Atterraggio di fortuna fuori pista completato. Richiesto recupero tecnico.';
      soundEngine.playBeep(320, 0.2, 'triangle', 0.25);
    } else if (landedAirport.id !== ctx.destination.id) {
      outcome = st.gearDamaged || st.airframeDamage >= 55 ? 'DAMAGED' : 'DIVERTED';
      reason = `Atterraggio alternato eseguito in sicurezza a ${landedAirport.name} (${landedAirport.icao}).`;
      soundEngine.playSuccessChime();
    } else if (st.gearDamaged || st.airframeDamage >= 55) {
      outcome = 'DAMAGED';
      reason = `Arrivo a destinazione (${landedAirport.icao}), ma si registrano danni per atterraggio duro.`;
      soundEngine.playBeep(360, 0.2, 'triangle', 0.25);
    } else {
      outcome = 'SUCCESS';
      soundEngine.playSuccessChime();
    }

    const landingGrade: FlightResultSummary['landingGrade'] =
      outcome === 'CRASHED'
        ? 'F'
        : st.touchdownFpm < 150 && centerlineErrorM < 8 && outcome === 'SUCCESS'
          ? 'S'
          : st.touchdownFpm < 310 && centerlineErrorM < 14
            ? 'A'
            : st.touchdownFpm < 540
              ? 'B'
              : 'C';

    let contractRewardEur = 0;
    let landingBonusEur = 0;
    let maintenanceCostEur = 0;
    let reputationDelta = 0;

    if (ctx.setup.mode === 'career') {
      const baseReward = ctx.setup.contract?.rewardEur || 1800;
      if (outcome === 'SUCCESS') {
        contractRewardEur = baseReward;
        landingBonusEur =
          landingGrade === 'S'
            ? Math.round(baseReward * 0.2)
            : landingGrade === 'A'
              ? Math.round(baseReward * 0.1)
              : 0;
        reputationDelta = (ctx.setup.contract?.reputationGain || 4) + (landingGrade === 'S' ? 2 : 0);
      } else if (outcome === 'DIVERTED') {
        contractRewardEur = Math.round(baseReward * 0.45);
        reputationDelta = 1;
      } else if (outcome === 'DAMAGED') {
        contractRewardEur = landedAirport?.id === ctx.destination.id ? Math.round(baseReward * 0.6) : 0;
        maintenanceCostEur = Math.round(850 + ctx.aircraft.priceEur * 0.015 + 600);
        reputationDelta = -4;
      } else {
        maintenanceCostEur = Math.round(1600 + ctx.aircraft.priceEur * 0.03);
        reputationDelta = -10;
      }
    }

    const netProfitEur = contractRewardEur + landingBonusEur - maintenanceCostEur;

    const summary: FlightResultSummary = {
      mode: ctx.setup.mode,
      outcome,
      reason,
      aircraftName: ctx.aircraft.name,
      departureAirport: ctx.departure,
      destinationAirport: ctx.destination,
      landedAirport,
      elapsedSec: st.elapsedSec,
      touchdownFpm: st.touchdownFpm,
      centerlineErrorM,
      fuelUsedKg,
      fuelCostEur: Math.round(fuelUsedKg * ctx.departure.fuelPricePerKg),
      maintenanceCostEur,
      contractRewardEur,
      landingBonusEur,
      netProfitEur,
      reputationDelta,
      landingGrade,
    };

    if (ctx.setup.mode === 'career') {
      const airframeWear = Math.round(2 + st.airframeDamage * 0.45);
      const engineWear = Math.round(2 + (st.engineTempC > 112 ? 12 : 1));
      const gearWear = Math.round(
        2 + (st.gearDamaged ? 38 : Math.max(0, (st.touchdownFpm - 250) * 0.03))
      );
      const updatedCareer = applyCareerFlightResult(
        careerRef.current,
        ctx.aircraft.id,
        st.fuelKg,
        airframeWear,
        engineWear,
        gearWear,
        summary
      );
      setCareer(updatedCareer);
      setSaveExists(true);
    }

    setFlightResult(summary);
    setScreen(ScreenId.FLIGHT_RESULTS);
  }, []);

  // Edge-triggered cockpit actions
  const handleCycleFlaps = useCallback(() => {
    const st = physStateRef.current;
    st.flapStage = ((st.flapStage + 1) % 4) as 0 | 1 | 2 | 3;
    soundEngine.playMechanicalToggle(st.flapStage > 0);
    setHudState(cloneHudSnapshot(st));
  }, []);

  const handleAdjustFlaps = useCallback((delta: -1 | 1) => {
    const st = physStateRef.current;
    const nextStage = Math.max(0, Math.min(3, st.flapStage + delta)) as 0 | 1 | 2 | 3;
    if (nextStage === st.flapStage) {
      soundEngine.playBeep(230, 0.06, 'square', 0.1);
      return;
    }
    st.flapStage = nextStage;
    soundEngine.playMechanicalToggle(delta > 0);
    setHudState(cloneHudSnapshot(st));
  }, []);

  const handleToggleGear = useCallback(() => {
    const ctx = simCtxRef.current;
    const st = physStateRef.current;
    if (ctx.aircraft.fixedGear) {
      soundEngine.playBeep(240, 0.08, 'square', 0.12);
      return;
    }
    if (st.onGround) {
      soundEngine.playBeep(210, 0.1, 'square', 0.15);
      return;
    }
    st.gearTargetDown = !st.gearTargetDown;
    soundEngine.playMechanicalToggle(st.gearTargetDown);
    setHudState(cloneHudSnapshot(st));
  }, []);

  const handleToggleDeIce = useCallback(() => {
    const st = physStateRef.current;
    st.liveWeather.deIceActive = !st.liveWeather.deIceActive;
    soundEngine.playMechanicalToggle(st.liveWeather.deIceActive);
    setHudState(cloneHudSnapshot(st));
  }, []);

  const handleCycleCamera = useCallback(() => {
    setCameraMode((prev) => {
      const order = [CameraMode.STANDARD, CameraMode.CLOSE, CameraMode.WIDE, CameraMode.TOWER];
      const next = order[(order.indexOf(prev) + 1) % order.length];
      soundEngine.playBeep(520, 0.05, 'sine', 0.1);
      return next;
    });
  }, []);

  const handleToggleAutopilot = useCallback(() => {
    const ctx = simCtxRef.current;
    const st = physStateRef.current;
    if (st.apEnabled) {
      setAutopilotEnabled(st, ctx.aircraft, false);
      sliderPitchRef.current = st.elevatorInput;
      buttonTrimOffsetRef.current = 0;
      soundEngine.playBeep(420, 0.09, 'triangle', 0.16);
      setHudState(cloneHudSnapshot(st));
    } else {
      const engaged = setAutopilotEnabled(st, ctx.aircraft, true);
      if (engaged) {
        soundEngine.playBeep(680, 0.08, 'sine', 0.16);
      } else {
        soundEngine.playBeep(220, 0.1, 'square', 0.14);
      }
      setHudState(cloneHudSnapshot(st));
    }
  }, []);

  const handleAdjustAutopilotAlt = useCallback((deltaFt: number) => {
    const st = physStateRef.current;
    const prevFt = st.apTargetAltFt;
    const nextFt = adjustAutopilotAltitude(st, deltaFt);
    if (nextFt !== prevFt) {
      soundEngine.playBeep(deltaFt > 0 ? 640 : 540, 0.032, 'sine', 0.085);
    } else {
      soundEngine.playBeep(230, 0.045, 'square', 0.08);
    }
    setHudState(cloneHudSnapshot(st));
  }, []);

  const handleSetElevator = useCallback((val: number) => {
    const clamped = Math.max(-1, Math.min(1, val));
    sliderPitchRef.current = clamped;
    if (!physStateRef.current.apEnabled) {
      physStateRef.current.elevatorInput = clamped;
      setHudState((prev) => ({ ...prev, elevatorInput: clamped }));
    }
  }, []);

  const handlePitchSliderHoldChange = useCallback((held: boolean) => {
    sliderPitchHeldRef.current = held;
  }, []);

  const handleSetThrottle = useCallback((val: number) => {
    const clamped = Math.max(0, Math.min(1, val));
    physStateRef.current.throttle = clamped;
    setHudState((prev) => ({ ...prev, throttle: clamped }));
  }, []);

  const handleChangeControlMode = useCallback((nextMode: ControlMode) => {
    const st = physStateRef.current;
    sliderPitchRef.current = st.elevatorInput;
    sliderPitchHeldRef.current = false;
    buttonTrimOffsetRef.current = st.elevatorInput;
    touchPitchRef.current = 0;
    touchPitchBtnRef.current = 0;
    touchThrottleBtnRef.current = 0;
    setActivePitchDir(0);
    setActiveThrottleDir(0);

    setSettings((prev) => {
      if (prev.controlMode === nextMode) return prev;
      const updated: GameSettings = { ...prev, controlMode: nextMode };
      settingsRef.current = updated;
      saveGameSettings(updated);
      soundEngine.playBeep(560, 0.05, 'sine', 0.11);
      return updated;
    });
    setHudState(cloneHudSnapshot(st));
  }, []);

  const handleRetargetFreeFlightDestination = useCallback((airportId: string) => {
    const ctx = simCtxRef.current;
    const st = physStateRef.current;
    const changed = retargetSimulationDestination(ctx, st, airportId);
    if (!changed) {
      soundEngine.playBeep(220, 0.09, 'square', 0.14);
      return;
    }
    setPendingSetup((prev) => ({ ...prev, destinationId: airportId }));
    setHudState(cloneHudSnapshot(st));
    soundEngine.playSuccessChime();
  }, []);

  // Keyboard Listeners (Continuous held vs Edge-triggered justPressed + Window Blur Reset)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (screenRef.current === ScreenId.MAIN_MENU && (e.code === 'Enter' || e.code === 'Space')) {
        if (document.activeElement?.tagName !== 'BUTTON') {
          e.preventDefault();
          setScreen(ScreenId.CAREER_HUB);
          return;
        }
      }

      if (screenRef.current !== ScreenId.FLYING) {
        if (
          e.code === 'Escape' &&
          screenRef.current !== ScreenId.MAIN_MENU &&
          screenRef.current !== ScreenId.FLIGHT_RESULTS
        ) {
          setScreen(ScreenId.MAIN_MENU);
        }
        return;
      }

      if (['ArrowUp', 'ArrowDown', 'Space', 'KeyW', 'KeyS'].includes(e.code)) {
        e.preventDefault();
      }

      heldKeysRef.current.add(e.code);
      if (e.code === 'KeyW') setActivePitchDir(1);
      else if (e.code === 'KeyS') setActivePitchDir(-1);
      else if (e.code === 'ArrowUp') setActiveThrottleDir(1);
      else if (e.code === 'ArrowDown') setActiveThrottleDir(-1);

      if (!pausedRef.current) {
        if (e.code === 'Minus' || e.code === 'NumpadSubtract' || e.code === 'BracketLeft') {
          e.preventDefault();
          handleAdjustAutopilotAlt(-AP_ALT_STEP_FT);
        } else if (e.code === 'Equal' || e.code === 'NumpadAdd' || e.code === 'BracketRight') {
          e.preventDefault();
          handleAdjustAutopilotAlt(AP_ALT_STEP_FT);
        }
      }

      if (!e.repeat) {
        if (e.code === 'Escape') {
          sliderPitchHeldRef.current = false;
          setInFlightMapOpen((mapOpen) => {
            if (mapOpen) return false;
            setAtcBriefingOpen((atcOpen) => {
              if (atcOpen) return false;
              setIsPaused((p) => !p);
              return false;
            });
            return false;
          });
        } else if (e.code === 'KeyM') {
          sliderPitchHeldRef.current = false;
          setIsPaused(false);
          setInFlightMapOpen((prev) => !prev);
          soundEngine.playBeep(590, 0.05, 'sine', 0.11);
        } else if (!pausedRef.current) {
          if (e.code === 'KeyF') handleCycleFlaps();
          else if (e.code === 'KeyV') handleAdjustFlaps(-1);
          else if (e.code === 'KeyG') handleToggleGear();
          else if (e.code === 'KeyI') handleToggleDeIce();
          else if (e.code === 'KeyC') handleCycleCamera();
          else if (e.code === 'KeyP') handleToggleAutopilot();
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      heldKeysRef.current.delete(e.code);
      const keys = heldKeysRef.current;
      if (e.code === 'KeyW' || e.code === 'KeyS') {
        setActivePitchDir(
          keys.has('KeyW') ? 1 : keys.has('KeyS') ? -1 : touchPitchBtnRef.current
        );
      }
      if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
        setActiveThrottleDir(
          keys.has('ArrowUp') ? 1 : keys.has('ArrowDown') ? -1 : touchThrottleBtnRef.current
        );
      }
    };

    const clearHeld = () => {
      heldKeysRef.current.clear();
      sliderPitchHeldRef.current = false;
      touchPitchRef.current = 0;
      touchPitchBtnRef.current = 0;
      touchThrottleBtnRef.current = 0;
      touchBrakeRef.current = false;
      setActivePitchDir(0);
      setActiveThrottleDir(0);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', clearHeld);

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', clearHeld);
    };
  }, [
    handleAdjustAutopilotAlt,
    handleAdjustFlaps,
    handleCycleCamera,
    handleCycleFlaps,
    handleToggleAutopilot,
    handleToggleDeIce,
    handleToggleGear,
  ]);

  // Isolated 60fps Canvas Render & Fixed-Timestep Physics Loop
  useEffect(() => {
    let rafId = 0;
    let lastTime = performance.now();
    let accumulator = 0;
    let lastHudSync = 0;
    let lastAtisMsg: string | null = null;
    let wasPitchSliderReturning = false;

    const tick = (now: number) => {
      const rawDt = Math.min(0.05, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;

      const activeScreen = screenRef.current;
      const canvas = canvasRef.current;

      if (activeScreen === ScreenId.FLYING) {
        const ctx = simCtxRef.current;
        const st = physStateRef.current;

        if (!pausedRef.current) {
          const keys = heldKeysRef.current;
          st.bankInput = 0;
          let isPitchSliderReturning = false;

          if (settingsRef.current.controlMode === 'sliders') {
            if (st.apEnabled) {
              sliderPitchRef.current = st.elevatorInput;
            } else {
              const kbPitchDir = keys.has('KeyW') ? 1 : keys.has('KeyS') ? -1 : 0;
              if (sliderPitchHeldRef.current) {
                st.elevatorInput = sliderPitchRef.current;
              } else if (kbPitchDir !== 0) {
                sliderPitchRef.current +=
                  (kbPitchDir - sliderPitchRef.current) * Math.min(1, 3.2 * rawDt);
                st.elevatorInput = sliderPitchRef.current;
              } else if (sliderPitchRef.current !== 0) {
                const decay = Math.exp(-4.6 * rawDt);
                let nextVal = sliderPitchRef.current * decay;
                const linearStep = 0.32 * rawDt;
                if (Math.abs(nextVal) <= linearStep || Math.abs(nextVal) < 0.004) {
                  nextVal = 0;
                } else {
                  nextVal -= Math.sign(nextVal) * linearStep;
                }
                sliderPitchRef.current = nextVal;
                st.elevatorInput = nextVal;
                isPitchSliderReturning = nextVal !== 0;
              } else {
                st.elevatorInput = 0;
              }
            }
          } else {
            if (st.apEnabled) {
              buttonTrimOffsetRef.current = st.elevatorInput;
            } else {
              const touchP = touchPitchRef.current;
              const curvedTouchPitch = Math.sign(touchP) * Math.pow(Math.abs(touchP), 1.3);

              let pitchCmd = curvedTouchPitch;
              if (keys.has('KeyW') || touchPitchBtnRef.current === 1) pitchCmd = 1;
              else if (keys.has('KeyS') || touchPitchBtnRef.current === -1) pitchCmd = -1;

              if (Math.abs(pitchCmd) > 0.02) {
                buttonTrimOffsetRef.current *= Math.max(0, 1 - 2.2 * rawDt);
                st.elevatorInput += (pitchCmd - st.elevatorInput) * Math.min(1, 3.2 * rawDt);
              } else {
                const targetTrim = buttonTrimOffsetRef.current;
                st.elevatorInput += (targetTrim - st.elevatorInput) * Math.min(1, 4.5 * rawDt);
                if (Math.abs(targetTrim) < 0.005 && Math.abs(st.elevatorInput) < 0.005) {
                  st.elevatorInput = 0;
                }
              }
            }
          }

          // Engine power is ALWAYS under manual player control (Autopilot never overrides throttle)
          const thrDir = keys.has('ArrowUp')
            ? 1
            : keys.has('ArrowDown')
              ? -1
              : settingsRef.current.controlMode === 'buttons'
                ? touchThrottleBtnRef.current
                : 0;
          if (thrDir !== 0) {
            st.throttle = Math.max(0, Math.min(1, st.throttle + thrDir * 0.36 * rawDt));
          }

          st.brakesApplied = keys.has('KeyB') || touchBrakeRef.current;

          // Auto-cancel time warp near ground or during warnings
          let warp = simSpeedRef.current;
          if (
            warp > 1 &&
            (st.onGround || st.aglFt < 350 || st.isStalling || st.engineFailed || st.sinkRateWarning)
          ) {
            warp = 1;
            setSimSpeed(1);
          }

          if (hitstopTimerRef.current > 0) {
            hitstopTimerRef.current = Math.max(0, hitstopTimerRef.current - rawDt);
          } else {
            accumulator += rawDt * warp;
            let maxSubSteps = 20;
            while (accumulator >= FIXED_DT && maxSubSteps > 0) {
              stepFlightPhysics(st, ctx, FIXED_DT);
              accumulator -= FIXED_DT;
              maxSubSteps--;
              if (st.crashed || st.flightCompleted) break;
            }
          }

          // VHF radio squelch chime whenever Career Control Tower transmits a new message
          if (ctx.atcJustTransmitted) {
            ctx.atcJustTransmitted = false;
            soundEngine.playBeep(820, 0.06, 'sine', 0.13);
          }

          // Subtle cockpit ATIS chime when a new dynamic weather front bulletin arrives
          if (st.liveWeather.atisNotice && st.liveWeather.atisNotice !== lastAtisMsg) {
            lastAtisMsg = st.liveWeather.atisNotice;
            if (st.elapsedSec > 2) {
              soundEngine.playBeep(740, 0.08, 'sine', 0.12);
            }
          }

          // Touchdown & damped bounce audio + brief tactile hitstop on heavy landing
          const justBounced = st.touchdownBounceCount > prevBounceCountRef.current;
          if (((!prevOnGroundRef.current && st.onGround) || justBounced) && !st.crashed) {
            const impactRate = st.lastTouchdownImpactFpm || st.touchdownFpm;
            soundEngine.playTouchdown(impactRate);
            if (impactRate > 520) {
              hitstopTimerRef.current = 0.038;
            }
          }
          prevOnGroundRef.current = st.onGround;
          prevBounceCountRef.current = st.touchdownBounceCount;

          // Approach & VNAV Audio Callouts (TOD, Final Approach, Landing Minimums)
          const curStage = st.navData.guidanceStage;
          if (curStage !== prevGuidanceStageRef.current && !st.onGround && st.hasTakenOff) {
            if (prevGuidanceStageRef.current === 'HOLD_ALTITUDE' && curStage === 'BEGIN_DESCENT') {
              soundEngine.playTodAdvisory();
            } else if (curStage === 'FINAL_APPROACH' && st.navData.relativePosition !== 'PASSED') {
              soundEngine.playFinalApproachAdvisory();
            }
          }
          prevGuidanceStageRef.current = curStage;

          if (st.navData.atDecisionHeight && !prevDecisionHeightRef.current) {
            soundEngine.playLandingAltitudeCallout();
          }
          prevDecisionHeightRef.current = st.navData.atDecisionHeight;

          // Lightning thunder sound
          if (st.lightningFlash > 0.7 && prevLightningRef.current <= 0.7) {
            soundEngine.playThunder();
          }
          prevLightningRef.current = st.lightningFlash;

          soundEngine.updateFlightAudio(
            ctx.aircraft,
            st.enginePowerPct,
            st.iasKt,
            st.isStalling,
            st.sinkRateWarning,
            st.liveWeather.rainIntensity,
            false,
            {
              tooLow: st.navData.tooLow,
              tooHigh: st.navData.tooHigh,
              tooFast: st.navData.tooFast,
              tooSlow: st.navData.tooSlow,
            }
          );

          const justFinishedReturn = wasPitchSliderReturning && !isPitchSliderReturning;
          wasPitchSliderReturning = isPitchSliderReturning;
          const hudSyncIntervalMs = isPitchSliderReturning ? 16 : 55;

          if (st.crashed || st.flightCompleted) {
            finalizeFlight();
          } else if (justFinishedReturn || now - lastHudSync > hudSyncIntervalMs) {
            lastHudSync = now;
            setHudState(cloneHudSnapshot(st));
          }
        } else {
          soundEngine.updateFlightAudio(ctx.aircraft, 0, 0, false, false, 0, true);
        }

        if (canvas) {
          worldRendererRef.current.render(
            canvas,
            st,
            ctx,
            cameraModeRef.current,
            userZoomRef.current,
            settingsRef.current.pixelScale,
            settingsRef.current.cameraShake,
            pausedRef.current ? 0 : rawDt
          );
        }
      } else if (activeScreen === ScreenId.MAIN_MENU && canvas) {
        const ctx = simCtxRef.current;
        const st = physStateRef.current;
        st.sM = (st.sM + 48 * rawDt) % 95000;
        const groundElev = st.groundAltM;
        const targetCruiseAlt = Math.max(420, groundElev + 260) + Math.sin(now * 0.0007) * 18;
        st.altM += (targetCruiseAlt - st.altM) * Math.min(1, 1.5 * rawDt);
        st.pitchRad = Math.sin(now * 0.0012) * 0.035;
        st.propPhase = (st.propPhase + rawDt * 32) % (Math.PI * 2);
        st.elapsedSec += rawDt;

        worldRendererRef.current.render(
          canvas,
          st,
          ctx,
          CameraMode.STANDARD,
          1.0,
          settingsRef.current.pixelScale,
          false,
          rawDt
        );
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(rafId);
      soundEngine.stopFlightLoop();
    };
  }, [finalizeFlight]);

  // Menu navigation helpers
  const handleStartNewCareer = () => {
    const fresh = createInitialCareerSave('Comandante Rossi');
    saveCareerData(fresh);
    setCareer(fresh);
    setSaveExists(true);
    setScreen(ScreenId.CAREER_HUB);
  };

  const handleAcceptCareerAtcMission = (assignment: CareerAtcAssignment) => {
    const owned =
      career.ownedAircraft.find((a) => a.aircraftId === career.selectedAircraftId) ||
      career.ownedAircraft[0];
    const spec = getAircraftById(owned.aircraftId);
    const contract = assignment.contract;

    const clampedPassengers = Math.min(contract.passengers, spec.passengerCapacity);
    const clampedCargo = Math.min(contract.cargoKg, spec.maxPayloadKg);

    const careerSetup: FlightSetupConfig = {
      mode: 'career',
      aircraftId: spec.id,
      departureId: assignment.departureId,
      destinationId: assignment.destinationId,
      fuelKg: Math.max(15, owned.fuelKg),
      payloadKg: clampedCargo,
      passengers: clampedPassengers,
      weather: {
        ...contract.weather,
        dynamicsMode: contract.difficulty >= 4 ? 'extreme' : 'dynamic',
      },
      contract,
      atcAssignment: assignment,
      plannedEmergency: EmergencyType.NONE,
    };
    setPendingSetup(careerSetup);
    setScreen(ScreenId.FLIGHT_PREP);
  };

  const handleOpenFreeFlight = (
    aircraftId = career.selectedAircraftId,
    depId = 'limb',
    destId = 'lsza'
  ) => {
    const spec = getAircraftById(aircraftId);
    const safeDestId = destId === depId ? AIRPORTS.find((a) => a.id !== depId)!.id : destId;
    const destAp = getAirportById(safeDestId);
    const setup: FlightSetupConfig = {
      mode: 'free',
      aircraftId: spec.id,
      departureId: depId,
      destinationId: safeDestId,
      fuelKg: Math.round(spec.maxFuelKg * 0.65),
      payloadKg: Math.round(spec.maxPayloadKg * 0.45),
      passengers: Math.round(spec.passengerCapacity * 0.5),
      plannedEmergency: EmergencyType.NONE,
      weather: {
        type: WeatherType.CLEAR,
        timeOfDay: TimeOfDay.DAY,
        windDirectionDeg: destAp.typicalWindDirDeg,
        windSpeedKt: destAp.typicalWindKt,
        headwindKt: 6,
        crosswindKt: 0,
        cloudCover: 0.2,
        gustIntensityKt: 3,
        turbulence: 0.08,
        visibilityKm: 20,
        dynamicsMode: 'dynamic',
      },
    };
    setPendingSetup(setup);
    setScreen(ScreenId.FLIGHT_PREP);
  };

  const enterMenuDemoMode = () => {
    soundEngine.stopFlightLoop();
    const demo = createDemoMenuFlight();
    simCtxRef.current = demo.ctx;
    physStateRef.current = demo.state;
    worldRendererRef.current.resetCamera(demo.state);
    setIsPaused(false);
    setInFlightMapOpen(false);
    setAtcBriefingOpen(false);
    setScreen(ScreenId.MAIN_MENU);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 select-none">
      {/* Isolated Full-Viewport High-Resolution 2D Simulation Canvas */}
      <canvas ref={canvasRef} className="sim-canvas block w-full h-full" />

      {/* Screen Router */}
      {screen === ScreenId.MAIN_MENU && (
        <MainMenuScreen
          hasSave={saveExists}
          career={career}
          onQuickContinue={() => setScreen(ScreenId.CAREER_HUB)}
          onNewCareer={handleStartNewCareer}
          onNavigate={(next) => setScreen(next)}
          onOpenFreeFlight={() => handleOpenFreeFlight('cessna_172', 'limb', 'lsza')}
        />
      )}

      {screen === ScreenId.CAREER_HUB && (
        <CareerHubScreen
          career={career}
          onBack={enterMenuDemoMode}
          onOpenEconomy={() => setScreen(ScreenId.ECONOMY)}
          onOpenHangar={() => setScreen(ScreenId.HANGAR)}
          onAcceptAtcMission={handleAcceptCareerAtcMission}
        />
      )}

      {screen === ScreenId.ECONOMY && (
        <EconomyScreen
          career={career}
          onBack={() => setScreen(ScreenId.CAREER_HUB)}
          onRefuel={(acId, targetKg) => {
            setCareer((prev) => refuelOwnedAircraft(prev, acId, targetKg));
            soundEngine.playBeep(580, 0.08, 'triangle', 0.18);
          }}
          onRepair={(acId) => {
            setCareer((prev) => repairOwnedAircraft(prev, acId));
            soundEngine.playSuccessChime();
          }}
          onBuyLicense={(licId: LicenseId) => {
            setCareer((prev) => purchaseLicense(prev, licId));
            soundEngine.playSuccessChime();
          }}
        />
      )}

      {screen === ScreenId.HANGAR && (
        <HangarScreen
          career={career}
          onBack={enterMenuDemoMode}
          onSelectCareerAircraft={(acId) => {
            setCareer((prev) => selectCareerAircraftAndRefreshAtc(prev, acId));
            soundEngine.playBeep(520, 0.07, 'triangle', 0.16);
          }}
          onBuyAircraft={(acId) => {
            setCareer((prev) => purchaseAircraft(prev, acId));
            setSaveExists(true);
            soundEngine.playSuccessChime();
          }}
          onLaunchFreeFlightWith={(acId) => {
            const spec = getAircraftById(acId);
            const suitableDep =
              AIRPORTS.find((a) => a.runwayLengthM >= spec.minRunwayM) || AIRPORTS[3];
            const suitableDest =
              AIRPORTS.find((a) => a.id !== suitableDep.id && a.runwayLengthM >= spec.minRunwayM) ||
              AIRPORTS[5];
            handleOpenFreeFlight(acId, suitableDep.id, suitableDest.id);
          }}
        />
      )}

      {screen === ScreenId.WORLD_MAP && (
        <WorldMapScreen
          career={career}
          initialDepartureId={career.currentAirportId}
          initialDestinationId={career.currentAirportId === 'limb' ? 'lsza' : 'limb'}
          onBack={enterMenuDemoMode}
          onConfirmRoute={(depId, destId) =>
            handleOpenFreeFlight(career.selectedAircraftId, depId, destId)
          }
        />
      )}

      {screen === ScreenId.FLIGHT_PREP && (
        <FlightPrepScreen
          career={career}
          initialSetup={pendingSetup}
          onBack={() =>
            setScreen(
              pendingSetup.mode === 'career' ? ScreenId.CAREER_HUB : ScreenId.MAIN_MENU
            )
          }
          onStartFlight={startFlightSession}
        />
      )}

      {screen === ScreenId.SETTINGS && (
        <SettingsScreen
          career={career}
          settings={settings}
          onUpdateSettings={(next) => {
            if (next.controlMode !== settings.controlMode) {
              sliderPitchRef.current = physStateRef.current.elevatorInput;
              buttonTrimOffsetRef.current = physStateRef.current.elevatorInput;
            }
            settingsRef.current = next;
            setSettings(next);
            saveGameSettings(next);
          }}
          onResetCareer={() => {
            const fresh = createInitialCareerSave('Comandante Rossi');
            saveCareerData(fresh);
            setCareer(fresh);
          }}
          onBack={enterMenuDemoMode}
        />
      )}

      {screen === ScreenId.FLYING && (
        <>
          <FlightHUD
            hudState={hudState}
            aircraft={simCtxRef.current.aircraft}
            isCareerMode={simCtxRef.current.setup.mode === 'career'}
            atcAssignment={simCtxRef.current.setup.atcAssignment}
            waypointIds={mapWaypoints}
            cameraMode={cameraMode}
            userZoom={userZoom}
            simSpeed={simSpeed}
            settings={settings}
            activePitchDir={activePitchDir}
            activeThrottleDir={activeThrottleDir}
            onPitchMove={(pitch) => {
              touchPitchRef.current = pitch;
            }}
            onSetElevator={handleSetElevator}
            onPitchSliderHoldChange={handlePitchSliderHoldChange}
            onHoldPitchButton={(dir) => {
              touchPitchBtnRef.current = dir;
              setActivePitchDir(dir);
            }}
            onHoldThrottleButton={(dir) => {
              touchThrottleBtnRef.current = dir;
              setActiveThrottleDir(dir);
              if (dir !== 0) {
                const nextThr = Math.max(
                  0,
                  Math.min(1, physStateRef.current.throttle + dir * 0.025)
                );
                physStateRef.current.throttle = nextThr;
                setHudState((prev) => ({ ...prev, throttle: nextThr }));
              }
            }}
            onSetThrottle={handleSetThrottle}
            onChangeControlMode={handleChangeControlMode}
            onToggleAutopilot={handleToggleAutopilot}
            onAdjustAutopilotAlt={handleAdjustAutopilotAlt}
            onAdjustFlaps={handleAdjustFlaps}
            onCycleFlaps={handleCycleFlaps}
            onToggleGear={handleToggleGear}
            onToggleDeIce={handleToggleDeIce}
            onSetBrakes={(active) => {
              touchBrakeRef.current = active;
            }}
            onCycleCamera={handleCycleCamera}
            onAdjustZoom={(delta) =>
              setUserZoom((z) => Math.max(0.5, Math.min(2.4, +(z + delta).toFixed(2))))
            }
            onCycleSimSpeed={() =>
              setSimSpeed((s) => (s === 1 ? 2 : s === 2 ? 4 : 1))
            }
            onSelectTargetAirport={handleRetargetFreeFlightDestination}
            onOpenInteractiveMap={() => {
              sliderPitchHeldRef.current = false;
              setIsPaused(false);
              setInFlightMapOpen(true);
              soundEngine.playBeep(590, 0.05, 'sine', 0.11);
            }}
            onOpenAtcBriefing={() => {
              if (simCtxRef.current.setup.atcAssignment) {
                sliderPitchHeldRef.current = false;
                setIsPaused(false);
                setAtcBriefingOpen(true);
                soundEngine.playBeep(640, 0.05, 'sine', 0.11);
              }
            }}
            onToggleMute={() => {
              const next = { ...settings, soundEnabled: !settings.soundEnabled };
              settingsRef.current = next;
              setSettings(next);
              saveGameSettings(next);
            }}
            onPause={() => {
              sliderPitchHeldRef.current = false;
              setIsPaused(true);
            }}
          />

          {/* Interactive Aeronautical World Map Modal (Editable in Free Flight, Locked ATC Corridor in Career) */}
          {inFlightMapOpen && (
            <InteractiveWorldMap
              airports={AIRPORTS}
              currentWorldXM={hudState.worldXM}
              currentWorldYM={hudState.worldYM}
              headingDeg={hudState.headingDeg}
              altitudeFt={hudState.altitudeFt}
              iasKt={hudState.iasKt}
              departureAirportId={simCtxRef.current.departure.id}
              activeDestinationId={hudState.targetAirportId}
              aircraft={simCtxRef.current.aircraft}
              liveWeather={hudState.liveWeather}
              isInFlight={true}
              isCareerMode={simCtxRef.current.setup.mode === 'career'}
              destinationLocked={simCtxRef.current.setup.mode === 'career'}
              atcAssignment={simCtxRef.current.setup.atcAssignment}
              waypointIds={mapWaypoints}
              onChangeWaypoints={setMapWaypoints}
              allowChangeDeparture={false}
              onConfirmDestination={(chosenDestId) => {
                if (simCtxRef.current.setup.mode === 'free') {
                  handleRetargetFreeFlightDestination(chosenDestId);
                }
                setInFlightMapOpen(false);
              }}
              onClose={() => setInFlightMapOpen(false)}
            />
          )}

          {/* Control Tower Pre-Takeoff Clearance & In-Flight VHF Log Modal (Career Mode) */}
          {atcBriefingOpen && simCtxRef.current.setup.atcAssignment && (
            <AtcTowerBriefingModal
              assignment={simCtxRef.current.setup.atcAssignment}
              aircraftName={simCtxRef.current.aircraft.name}
              hasTakenOff={hudState.hasTakenOff}
              atcHistory={hudState.atcHistory}
              onAcknowledge={() => {
                setAtcBriefingOpen(false);
                soundEngine.playBeep(760, 0.06, 'sine', 0.13);
              }}
            />
          )}

          {isPaused && (
            <PauseModal
              controlMode={settings.controlMode}
              isFreeFlight={simCtxRef.current.setup.mode === 'free'}
              onChangeControlMode={handleChangeControlMode}
              onOpenInteractiveMap={() => {
                setIsPaused(false);
                setInFlightMapOpen(true);
              }}
              onResume={() => setIsPaused(false)}
              onRestart={() => startFlightSession(pendingSetup)}
              onAbortToMenu={enterMenuDemoMode}
            />
          )}
        </>
      )}

      {screen === ScreenId.FLIGHT_RESULTS && flightResult && (
        <FlightResultsScreen
          result={flightResult}
          onFlyAgain={() => startFlightSession(pendingSetup)}
          onContinue={() =>
            flightResult.mode === 'career'
              ? setScreen(ScreenId.CAREER_HUB)
              : enterMenuDemoMode()
          }
        />
      )}
    </div>
  );
}
