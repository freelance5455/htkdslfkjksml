import React, { useEffect, useId, useRef, useState } from 'react';
import {
  getWaypointById,
  ITALY_MAINLAND_POLYGON,
} from '../data/aeronauticalChartData';
import { AIRPORTS } from '../data/airports';
import { useI18n } from '../i18n/I18nContext';
import { compassWestLetter } from '../i18n/localizeGameData';
import {
  AircraftSpec,
  FlightNavigationData,
  FlightPhysicsState,
} from '../types/game';

export type DialSizeMode = 'desktop' | 'mobile' | 'landscape';

function polarToCartesian(cx: number, cy: number, r: number, angleDegFromTop: number) {
  const rad = ((angleDegFromTop - 90) * Math.PI) / 180;
  return {
    x: cx + r * Math.cos(rad),
    y: cy + r * Math.sin(rad),
  };
}

function describeArc(
  cx: number,
  cy: number,
  r: number,
  startAngleDeg: number,
  endAngleDeg: number
): string {
  const clampedEnd = Math.max(startAngleDeg + 0.5, endAngleDeg);
  const start = polarToCartesian(cx, cy, r, clampedEnd);
  const end = polarToCartesian(cx, cy, r, startAngleDeg);
  const largeArcFlag = clampedEnd - startAngleDeg <= 180 ? '0' : '1';
  return `M ${start.x.toFixed(2)} ${start.y.toFixed(2)} A ${r} ${r} 0 ${largeArcFlag} 0 ${end.x.toFixed(2)} ${end.y.toFixed(2)}`;
}

function getDialSizeClasses(mode: DialSizeMode = 'desktop'): {
  wrapper: string;
  caption: string;
} {
  if (mode === 'mobile') {
    return {
      wrapper: 'w-[50px] h-[50px] sm:w-[62px] sm:h-[62px]',
      caption: 'text-[7.5px] sm:text-[8.5px]',
    };
  }
  if (mode === 'landscape') {
    return {
      wrapper: 'w-[44px] h-[44px] md:w-[54px] md:h-[54px]',
      caption: 'text-[7px] md:text-[7.5px]',
    };
  }
  return {
    wrapper: 'w-[58px] h-[58px] xl:w-[76px] xl:h-[76px] 2xl:w-[88px] 2xl:h-[88px]',
    caption: 'text-[8px] xl:text-[9px]',
  };
}

/**
 * Shared recessed cockpit instrument housing with 4 panel mounting screws & phase illumination
 */
const DialBezelFrame: React.FC<{ highlighted?: boolean; alert?: boolean }> = ({
  highlighted,
  alert,
}) => {
  const outerStroke = alert
    ? '#ef4444'
    : highlighted
      ? '#38bdf8'
      : '#334155';
  const innerRim = alert
    ? '#f87171'
    : highlighted
      ? '#0ea5e9'
      : '#1e293b';

  return (
    <>
      <rect
        x="2"
        y="2"
        width="96"
        height="96"
        rx="16"
        fill="#0b1120"
        stroke={ highlighted || alert ? outerStroke : '#1e293b' }
        strokeWidth={ highlighted || alert ? '1.6' : '1' }
      />
      {[
        [10, 10],
        [90, 10],
        [10, 90],
        [90, 90],
      ].map(([sx, sy], i) => (
        <g key={i}>
          <circle cx={sx} cy={sy} r="2.4" fill="#1e293b" stroke="#475569" strokeWidth="0.6" />
          <line x1={sx - 1.4} y1={sy - 1.4} x2={sx + 1.4} y2={sy + 1.4} stroke="#090d16" strokeWidth="0.7" />
        </g>
      ))}
      <circle cx="50" cy="50" r="45.5" fill="#0f172a" stroke={outerStroke} strokeWidth={highlighted || alert ? '2.2' : '1.8'} />
      <circle cx="50" cy="50" r="42.5" fill="#060a12" stroke={innerRim} strokeWidth="0.9" />
    </>
  );
};

/**
 * 1. ANEMOMETRO (Airspeed Indicator - Knots + Vref Approach Bug)
 */
export const AirspeedDial: React.FC<{
  iasKt: number;
  aircraft: AircraftSpec;
  vRefKt?: number;
  idealSpeedKt?: number;
  sizeMode?: DialSizeMode;
  highlighted?: boolean;
}> = ({
  iasKt,
  aircraft,
  vRefKt,
  idealSpeedKt,
  sizeMode = 'desktop',
  highlighted,
}) => {
  const maxDialKt =
    aircraft.vMaxKt <= 180 ? 180 : aircraft.vMaxKt <= 280 ? 300 : 420;
  const valToAngle = (kt: number) => {
    const ratio = Math.max(0, Math.min(1.04, kt / maxDialKt));
    return 25 + ratio * 305;
  };

  const needleAngle = valToAngle(iasKt);
  const whiteStart = valToAngle(aircraft.vStallKt * 0.86);
  const whiteEnd = valToAngle(aircraft.vFlapMaxKt);
  const greenStart = valToAngle(aircraft.vStallKt);
  const greenEnd = valToAngle(Math.min(aircraft.vMaxKt * 0.88, aircraft.vCruiseKt * 1.08));
  const yellowStart = greenEnd;
  const yellowEnd = valToAngle(aircraft.vMaxKt);
  const vnePt1 = polarToCartesian(50, 50, 33.5, yellowEnd);
  const vnePt2 = polarToCartesian(50, 50, 41.5, yellowEnd);

  const stepKt = maxDialKt <= 180 ? 30 : maxDialKt <= 300 ? 50 : 70;
  const majorTicks: number[] = [];
  for (let v = 0; v <= maxDialKt; v += stepKt) majorTicks.push(v);

  const vRefPos = vRefKt ? polarToCartesian(50, 50, 39.5, valToAngle(vRefKt)) : null;
  const idealPos =
    idealSpeedKt && idealSpeedKt > 5
      ? polarToCartesian(50, 50, 41.2, valToAngle(idealSpeedKt))
      : null;
  const lowSpeedAlert = iasKt > 12 && iasKt < aircraft.vStallKt * 1.04;
  const sz = getDialSizeClasses(sizeMode);
  const { t } = useI18n();

  return (
    <div
      className={`flex flex-col items-center gap-0.5 shrink-0 select-none transition-opacity duration-200 ${
        highlighted ? 'opacity-100' : 'opacity-90'
      }`}
      title={`${t('common.speed')}: ${Math.round(iasKt)} KT${idealSpeedKt ? ` · ${t('hud.idealSpeed')} ${idealSpeedKt} KT` : ''}${vRefKt ? ` · Vref ${vRefKt} KT` : ''}`}
    >
      <div className={`${sz.wrapper} relative`}>
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <DialBezelFrame highlighted={highlighted} alert={lowSpeedAlert} />

          <path d={describeArc(50, 50, 37.2, whiteStart, whiteEnd)} fill="none" stroke="#f8fafc" strokeWidth="2.2" opacity="0.9" />
          <path d={describeArc(50, 50, 39.8, greenStart, greenEnd)} fill="none" stroke="#10b981" strokeWidth="2.8" />
          <path d={describeArc(50, 50, 39.8, yellowStart, yellowEnd)} fill="none" stroke="#f59e0b" strokeWidth="2.8" />
          <line x1={vnePt1.x} y1={vnePt1.y} x2={vnePt2.x} y2={vnePt2.y} stroke="#ef4444" strokeWidth="2.5" />

          {majorTicks.map((v) => {
            const ang = valToAngle(v);
            const p1 = polarToCartesian(50, 50, 34.8, ang);
            const p2 = polarToCartesian(50, 50, 41.5, ang);
            const lbl = polarToCartesian(50, 50, 26.8, ang);
            return (
              <g key={v}>
                <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke="#cbd5e1" strokeWidth="1.2" />
                <text
                  x={lbl.x}
                  y={lbl.y + 2.4}
                  textAnchor="middle"
                  fill="#e2e8f0"
                  fontSize="7.2"
                  fontFamily="JetBrains Mono, monospace"
                  fontWeight="600"
                >
                  {v}
                </text>
              </g>
            );
          })}

          {vRefPos && (
            <circle cx={vRefPos.x} cy={vRefPos.y} r="2.2" fill="#fbbf24" stroke="#0f172a" strokeWidth="0.7" />
          )}
          {idealPos && (
            <circle cx={idealPos.x} cy={idealPos.y} r="2.5" fill="#22d3ee" stroke="#020617" strokeWidth="0.8" />
          )}

          <text x="50" y="36" textAnchor="middle" fill="#94a3b8" fontSize="6.1" fontFamily="Outfit, sans-serif" fontWeight="700">
            IAS KT
          </text>
          <rect x="28" y="61" width="44" height="14.5" rx="2.5" fill="#020617" stroke="#334155" strokeWidth="0.9" />
          <text
            x="50"
            y="71.2"
            textAnchor="middle"
            fill={lowSpeedAlert ? '#f87171' : '#34d399'}
            fontSize="9.6"
            fontFamily="JetBrains Mono, monospace"
            fontWeight="700"
          >
            {Math.round(iasKt)}
          </text>

          <g transform={`rotate(${needleAngle.toFixed(1)} 50 50)`}>
            <line x1="50" y1="56" x2="50" y2="12.5" stroke="#f8fafc" strokeWidth="2.1" strokeLinecap="round" />
            <polygon points="50,9.5 48.2,16 51.8,16" fill="#f8fafc" />
          </g>
          <circle cx="50" cy="50" r="4" fill="#1e293b" stroke="#94a3b8" strokeWidth="1" />
        </svg>
      </div>
      <span
        className={`font-mono leading-none tracking-tight whitespace-nowrap ${sz.caption} ${
          highlighted ? 'text-sky-300 font-bold' : 'text-slate-400 font-medium'
        }`}
      >
        {t('inst.airspeed')}
      </span>
    </div>
  );
};

/**
 * 2. ORIZZONTE ARTIFICIALE (Attitude Indicator - Pitch, Bank & Flight Director)
 */
export const AttitudeDial: React.FC<{
  pitchRad: number;
  bankDeg: number;
  apEnabled: boolean;
  elevatorInput: number;
  sizeMode?: DialSizeMode;
  highlighted?: boolean;
}> = ({ pitchRad, bankDeg, apEnabled, elevatorInput, sizeMode = 'desktop', highlighted }) => {
  const rawId = useId();
  const clipId = `adiClip_${rawId.replace(/[^a-zA-Z0-9]/g, '')}`;
  const pitchDeg = (pitchRad * 180) / Math.PI;
  const shiftY = Math.max(-27, Math.min(27, pitchDeg * 1.35));
  const fdShiftY = Math.max(-21, Math.min(21, (pitchDeg + elevatorInput * 6) * 1.1));
  const sz = getDialSizeClasses(sizeMode);
  const { t } = useI18n();

  return (
    <div
      className={`flex flex-col items-center gap-0.5 shrink-0 select-none transition-opacity duration-200 ${
        highlighted ? 'opacity-100' : 'opacity-90'
      }`}
      title={`${t('inst.attitude')}: ${pitchDeg >= 0 ? '+' : ''}${pitchDeg.toFixed(1)}°`}
    >
      <div className={`${sz.wrapper} relative`}>
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <defs>
            <clipPath id={clipId}>
              <circle cx="50" cy="50" r="39.5" />
            </clipPath>
          </defs>

          <DialBezelFrame highlighted={highlighted} />

          <g clipPath={`url(#${clipId})`}>
            <g transform={`rotate(${(-bankDeg).toFixed(1)} 50 50) translate(0 ${shiftY.toFixed(1)})`}>
              <rect x="-30" y="-60" width="160" height="110" fill="#0284c7" />
              <rect x="-30" y="50" width="160" height="110" fill="#78350f" />
              <line x1="-20" y1="50" x2="120" y2="50" stroke="#f8fafc" strokeWidth="1.6" />

              {[-20, -15, -10, -5, 5, 10, 15, 20].map((deg) => {
                const y = 50 - deg * 1.35;
                const halfW = Math.abs(deg) % 10 === 0 ? 12.5 : 6.5;
                return (
                  <line
                    key={deg}
                    x1={50 - halfW}
                    y1={y}
                    x2={50 + halfW}
                    y2={y}
                    stroke="#f8fafc"
                    strokeWidth="1.1"
                    opacity="0.88"
                  />
                );
              })}
            </g>

            {apEnabled && (
              <path
                d={`M 32 ${(50 - fdShiftY + shiftY).toFixed(1)} L 50 ${(47 - fdShiftY + shiftY).toFixed(1)} L 68 ${(50 - fdShiftY + shiftY).toFixed(1)}`}
                fill="none"
                stroke="#e879f9"
                strokeWidth="2.1"
                strokeLinecap="round"
              />
            )}

            {[-30, -20, -10, 0, 10, 20, 30].map((b) => {
              const p1 = polarToCartesian(50, 50, 36, b);
              const p2 = polarToCartesian(50, 50, 39.5, b);
              return <line key={b} x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke="#f8fafc" strokeWidth="1.1" />;
            })}
            <polygon points="50,11 47.8,15.5 52.2,15.5" fill="#facc15" />
          </g>

          <circle cx="50" cy="50" r="40" fill="none" stroke="#1e293b" strokeWidth="1.8" />
          <path
            d="M 25 50 L 40 50 L 43 54 M 75 50 L 60 50 L 57 54"
            fill="none"
            stroke="#facc15"
            strokeWidth="2.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="50" cy="50" r="2.2" fill="#facc15" />

          <rect x="32" y="72.5" width="36" height="12.5" rx="2" fill="#020617" fillOpacity="0.92" stroke="#334155" strokeWidth="0.8" />
          <text x="50" y="81.2" textAnchor="middle" fill="#f8fafc" fontSize="8.2" fontFamily="JetBrains Mono, monospace" fontWeight="700">
            {pitchDeg >= 0 ? `+${pitchDeg.toFixed(1)}°` : `${pitchDeg.toFixed(1)}°`}
          </text>
        </svg>
      </div>
      <span
        className={`font-mono leading-none tracking-tight whitespace-nowrap ${sz.caption} ${
          highlighted ? 'text-sky-300 font-bold' : 'text-slate-400 font-medium'
        }`}
      >
        {t('inst.attitude')}
      </span>
    </div>
  );
};

/**
 * 3. ALTIMETRO SENSIBILE (Two-Needle Cessna Altimeter - Feet + Radio AGL)
 */
export const AltimeterDial: React.FC<{
  altitudeFt: number;
  aglFt: number;
  apEnabled: boolean;
  apTargetAltFt: number;
  sizeMode?: DialSizeMode;
  highlighted?: boolean;
}> = ({ altitudeFt, aglFt, apEnabled, apTargetAltFt, sizeMode = 'desktop', highlighted }) => {
  const hundredsAngle = ((altitudeFt % 1000) / 1000) * 360;
  const thousandsAngle = ((altitudeFt % 10000) / 10000) * 360;
  const targetBugAngle = ((apTargetAltFt % 1000) / 1000) * 360;
  const bugPt = polarToCartesian(50, 50, 40.5, targetBugAngle);
  const sz = getDialSizeClasses(sizeMode);
  const { t } = useI18n();

  return (
    <div
      className={`flex flex-col items-center gap-0.5 shrink-0 select-none transition-opacity duration-200 ${
        highlighted ? 'opacity-100' : 'opacity-90'
      }`}
      title={`${t('inst.altimeter')}: ${altitudeFt} FT MSL (${aglFt} FT AGL)`}
    >
      <div className={`${sz.wrapper} relative`}>
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <DialBezelFrame highlighted={highlighted} />

          {Array.from({ length: 50 }).map((_, idx) => {
            const ang = idx * 7.2;
            const isMajor = idx % 5 === 0;
            const p1 = polarToCartesian(50, 50, isMajor ? 34.5 : 38, ang);
            const p2 = polarToCartesian(50, 50, 41.5, ang);
            const lbl = polarToCartesian(50, 50, 26.8, ang);
            return (
              <g key={idx}>
                <line
                  x1={p1.x}
                  y1={p1.y}
                  x2={p2.x}
                  y2={p2.y}
                  stroke={isMajor ? '#e2e8f0' : '#64748b'}
                  strokeWidth={isMajor ? '1.3' : '0.7'}
                />
                {isMajor && (
                  <text
                    x={lbl.x}
                    y={lbl.y + 2.5}
                    textAnchor="middle"
                    fill="#e2e8f0"
                    fontSize="7.6"
                    fontFamily="JetBrains Mono, monospace"
                    fontWeight="700"
                  >
                    {idx / 5}
                  </text>
                )}
              </g>
            );
          })}

          <text x="50" y="34.5" textAnchor="middle" fill="#94a3b8" fontSize="6" fontFamily="Outfit, sans-serif" fontWeight="700">
            ALT FT
          </text>

          <rect x="25" y="60.5" width="50" height="15" rx="2.5" fill="#020617" stroke="#334155" strokeWidth="0.9" />
          <text x="50" y="70.6" textAnchor="middle" fill="#38bdf8" fontSize="9.1" fontFamily="JetBrains Mono, monospace" fontWeight="700">
            {altitudeFt}
          </text>

          <circle
            cx={bugPt.x}
            cy={bugPt.y}
            r="2.6"
            fill={apEnabled ? '#34d399' : '#38bdf8'}
            fillOpacity={apEnabled ? '1' : '0.65'}
            stroke="#0f172a"
            strokeWidth="0.7"
          />

          <g transform={`rotate(${thousandsAngle.toFixed(1)} 50 50)`}>
            <polygon points="50,22 46.8,44 50,53 53.2,44" fill="#cbd5e1" stroke="#0f172a" strokeWidth="0.6" />
          </g>

          <g transform={`rotate(${hundredsAngle.toFixed(1)} 50 50)`}>
            <line x1="50" y1="56" x2="50" y2="11.5" stroke="#f8fafc" strokeWidth="2" strokeLinecap="round" />
            <polygon points="50,9 48.3,15 51.7,15" fill="#f8fafc" />
          </g>

          <circle cx="50" cy="50" r="4" fill="#1e293b" stroke="#94a3b8" strokeWidth="1" />
        </svg>
      </div>
      <span
        className={`font-mono leading-none tracking-tight whitespace-nowrap ${sz.caption} ${
          highlighted ? 'text-sky-300 font-bold' : 'text-slate-400 font-medium'
        }`}
      >
        {t('inst.altimeter')}
      </span>
    </div>
  );
};

/**
 * 4. VARIOMETRO (Vertical Speed Indicator - FT/MIN)
 */
export const VerticalSpeedDial: React.FC<{
  vsiFpm: number;
  recommendedVsiFpm: number;
  aircraft: AircraftSpec;
  showVnavBug: boolean;
  sizeMode?: DialSizeMode;
  highlighted?: boolean;
}> = ({
  vsiFpm,
  recommendedVsiFpm,
  aircraft,
  showVnavBug,
  sizeMode = 'desktop',
  highlighted,
}) => {
  const maxScaleFpm =
    aircraft.engineType === 'jet' ? 4000 : aircraft.engineType === 'turboprop' ? 3000 : 2000;

  const fpmToAngle = (fpm: number) => {
    const clamped = Math.max(-maxScaleFpm, Math.min(maxScaleFpm, fpm));
    return 270 + (clamped / maxScaleFpm) * 165;
  };

  const needleAngle = fpmToAngle(vsiFpm);
  const bugAngle = fpmToAngle(recommendedVsiFpm);
  const bugPt = polarToCartesian(50, 50, 40.2, bugAngle);

  const stepFpm = maxScaleFpm === 2000 ? 500 : 1000;
  const tickValues: number[] = [];
  for (let v = -maxScaleFpm; v <= maxScaleFpm; v += stepFpm) tickValues.push(v);

  const sinkAlert = vsiFpm < -850;
  const sz = getDialSizeClasses(sizeMode);
  const { t } = useI18n();

  return (
    <div
      className={`flex flex-col items-center gap-0.5 shrink-0 select-none transition-opacity duration-200 ${
        highlighted ? 'opacity-100' : 'opacity-90'
      }`}
      title={`${t('inst.vsi')}: ${vsiFpm >= 0 ? '+' : ''}${vsiFpm} ft/min`}
    >
      <div className={`${sz.wrapper} relative`}>
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <DialBezelFrame highlighted={highlighted} alert={sinkAlert} />

          {tickValues.map((v) => {
            const ang = fpmToAngle(v);
            const p1 = polarToCartesian(50, 50, 35, ang);
            const p2 = polarToCartesian(50, 50, 41.5, ang);
            const lbl = polarToCartesian(50, 50, 26.8, ang);
            return (
              <g key={v}>
                <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke="#cbd5e1" strokeWidth="1.2" />
                <text
                  x={lbl.x}
                  y={lbl.y + 2.4}
                  textAnchor="middle"
                  fill="#e2e8f0"
                  fontSize="7"
                  fontFamily="JetBrains Mono, monospace"
                  fontWeight="600"
                >
                  {Math.abs(v) / 100}
                </text>
              </g>
            );
          })}

          <text x="53" y="35.5" textAnchor="middle" fill="#94a3b8" fontSize="5.9" fontFamily="Outfit, sans-serif" fontWeight="700">
            VSI FPM
          </text>
          <text x="27" y="42" textAnchor="middle" fill="#34d399" fontSize="5.6" fontWeight="700">
            UP
          </text>
          <text x="27" y="61" textAnchor="middle" fill="#fbbf24" fontSize="5.6" fontWeight="700">
            DN
          </text>

          {showVnavBug && (
            <circle cx={bugPt.x} cy={bugPt.y} r="2.7" fill="#e879f9" stroke="#0f172a" strokeWidth="0.7" />
          )}

          <rect x="28" y="60.5" width="47" height="15" rx="2.5" fill="#020617" stroke="#334155" strokeWidth="0.9" />
          <text
            x="51.5"
            y="70.8"
            textAnchor="middle"
            fill={sinkAlert ? '#f87171' : vsiFpm < -550 ? '#fbbf24' : '#f8fafc'}
            fontSize="8.7"
            fontFamily="JetBrains Mono, monospace"
            fontWeight="700"
          >
            {vsiFpm >= 0 ? `+${vsiFpm}` : vsiFpm}
          </text>

          <g transform={`rotate(${needleAngle.toFixed(1)} 50 50)`}>
            <line x1="50" y1="55" x2="50" y2="12.5" stroke="#f8fafc" strokeWidth="2.1" strokeLinecap="round" />
            <polygon points="50,9.5 48.2,15.5 51.8,15.5" fill="#f8fafc" />
          </g>
          <circle cx="50" cy="50" r="4" fill="#1e293b" stroke="#94a3b8" strokeWidth="1" />
        </svg>
      </div>
      <span
        className={`font-mono leading-none tracking-tight whitespace-nowrap ${sz.caption} ${
          highlighted ? 'text-sky-300 font-bold' : 'text-slate-400 font-medium'
        }`}
      >
        {t('inst.vsi')}
      </span>
    </div>
  );
};

/**
 * 5. GIRODIREZIONALE + BUSSOLA MAGNETICA
 */
export const HeadingCompassDial: React.FC<{
  headingDeg: number;
  magneticCompassDeg: number;
  runwayBearingDeg: number;
  sizeMode?: DialSizeMode;
  highlighted?: boolean;
}> = ({
  headingDeg,
  magneticCompassDeg,
  runwayBearingDeg,
  sizeMode = 'desktop',
  highlighted,
}) => {
  const { lang, t } = useI18n();
  const westChar = compassWestLetter(lang);
  const cardMarks = [
    { deg: 0, label: 'N' },
    { deg: 30, label: '3' },
    { deg: 60, label: '6' },
    { deg: 90, label: 'E' },
    { deg: 120, label: '12' },
    { deg: 150, label: '15' },
    { deg: 180, label: 'S' },
    { deg: 210, label: '21' },
    { deg: 240, label: '24' },
    { deg: 270, label: westChar },
    { deg: 300, label: '30' },
    { deg: 330, label: '33' },
  ];

  const relBearing = (runwayBearingDeg - headingDeg + 360) % 360;
  const brgBugPt = polarToCartesian(50, 50, 40.2, relBearing);
  const sz = getDialSizeClasses(sizeMode);

  return (
    <div
      className={`flex flex-col items-center gap-0.5 shrink-0 select-none transition-opacity duration-200 ${
        highlighted ? 'opacity-100' : 'opacity-90'
      }`}
      title={`${t('common.heading')} ${String(headingDeg).padStart(3, '0')}° · Mag ${String(Math.round(magneticCompassDeg)).padStart(3, '0')}°`}
    >
      <div className={`${sz.wrapper} relative`}>
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <DialBezelFrame highlighted={highlighted} />

          <g transform={`rotate(${(-headingDeg).toFixed(1)} 50 50)`}>
            {Array.from({ length: 36 }).map((_, i) => {
              const ang = i * 10;
              const p1 = polarToCartesian(50, 50, i % 3 === 0 ? 35.5 : 38.5, ang);
              const p2 = polarToCartesian(50, 50, 41.5, ang);
              return (
                <line
                  key={i}
                  x1={p1.x}
                  y1={p1.y}
                  x2={p2.x}
                  y2={p2.y}
                  stroke="#94a3b8"
                  strokeWidth={i % 3 === 0 ? '1.2' : '0.7'}
                />
              );
            })}
            {cardMarks.map((m) => {
              const pos = polarToCartesian(50, 50, 27.8, m.deg);
              const isCard = ['N', 'E', 'S', 'W', 'O'].includes(m.label);
              return (
                <text
                  key={m.deg}
                  x={pos.x}
                  y={pos.y + 2.4}
                  textAnchor="middle"
                  fill={m.label === 'N' ? '#f87171' : isCard ? '#fbbf24' : '#e2e8f0'}
                  fontSize={isCard ? '7.8' : '6.4'}
                  fontFamily="JetBrains Mono, monospace"
                  fontWeight="700"
                >
                  {m.label}
                </text>
              );
            })}
          </g>

          <circle cx={brgBugPt.x} cy={brgBugPt.y} r="2.7" fill="#f59e0b" stroke="#0f172a" strokeWidth="0.8" />
          <polygon points="50,11.5 47.4,6.2 52.6,6.2" fill="#f97316" />

          <path
            d="M 50 37 L 50 55 M 39.5 45.5 L 60.5 45.5 M 45 53.5 L 55 53.5"
            stroke="#f8fafc"
            strokeWidth="2"
            strokeLinecap="round"
          />

          <rect x="26" y="62.5" width="48" height="14" rx="2.5" fill="#020617" stroke="#334155" strokeWidth="0.9" />
          <text x="50" y="72" textAnchor="middle" fill="#fbbf24" fontSize="8" fontFamily="JetBrains Mono, monospace" fontWeight="700">
            M {String(Math.round(magneticCompassDeg)).padStart(3, '0')}°
          </text>
        </svg>
      </div>
      <span
        className={`font-mono leading-none tracking-tight whitespace-nowrap ${sz.caption} ${
          highlighted ? 'text-sky-300 font-bold' : 'text-slate-400 font-medium'
        }`}
      >
        {t('inst.heading')}
      </span>
    </div>
  );
};

/**
 * 6. CONTAGIRI MOTORE + INDICATORI EIS (Carburante, Potenza, Temperatura, Olio)
 */
export const EngineTachAndGauges: React.FC<{
  hudState: FlightPhysicsState;
  aircraft: AircraftSpec;
  sizeMode?: DialSizeMode;
  engineHighlighted?: boolean;
  fuelHighlighted?: boolean;
  compactGaugesOnly?: boolean;
}> = ({
  hudState,
  aircraft,
  sizeMode = 'desktop',
  engineHighlighted,
  fuelHighlighted,
  compactGaugesOnly,
}) => {
  const isJet = aircraft.engineType === 'jet';
  const maxRpmScale = isJet ? 110 : aircraft.maxRpm * 1.12;
  const rpmRatio = Math.max(0, Math.min(1.05, hudState.rpm / maxRpmScale));
  const rpmAngle = 225 + rpmRatio * 270;
  const greenStart = 225 + (aircraft.idleRpm / maxRpmScale) * 270;
  const greenEnd = 225 + (aircraft.maxRpm / maxRpmScale) * 270;
  const redPt1 = polarToCartesian(50, 50, 34, greenEnd);
  const redPt2 = polarToCartesian(50, 50, 41.5, greenEnd);

  const fuelPct = Math.max(0, Math.min(100, Math.round((hudState.fuelKg / aircraft.maxFuelKg) * 100)));
  const pwrPct = Math.max(0, Math.min(100, Math.round(hudState.enginePowerPct)));
  const tempPct = Math.max(0, Math.min(100, Math.round(((hudState.engineTempC - 20) / 120) * 100)));
  const oilPct = Math.max(0, Math.min(100, Math.round((hudState.engineOilPressPsi / 100) * 100)));

  const burnRateKgHr = Math.max(
    4,
    aircraft.fuelBurnKgPerHourCruise * (0.25 + 0.95 * hudState.throttle)
  );
  const enduranceMin = Math.min(999, Math.round((hudState.fuelKg / burnRateKgHr) * 60));

  const sz = getDialSizeClasses(sizeMode);
  const { lang, t } = useI18n();
  const endurPrefix =
    lang === 'en'
      ? 'Endur.'
      : lang === 'fr'
        ? 'Auton.'
        : lang === 'de'
          ? 'Dauer'
          : lang === 'es'
            ? 'Auton.'
            : 'Auton.';

  if (compactGaugesOnly) {
    return (
      <div
        className={`rounded-lg border px-1.5 py-1 flex flex-col justify-between w-[88px] sm:w-[110px] h-[60px] sm:h-[72px] font-mono tabular-nums shrink-0 select-none ${
          engineHighlighted || fuelHighlighted
            ? 'cockpit-module-priority border-sky-400/70'
            : 'cockpit-module border-slate-700/90'
        }`}
      >
        <div className="flex items-center justify-between text-[8.5px] sm:text-[9.5px] leading-none">
          <span className={engineHighlighted ? 'text-sky-300 font-bold' : 'text-slate-400'}>
            {isJet ? 'N1' : 'RPM'}
          </span>
          <span className={hudState.engineFailed ? 'text-red-400 font-bold' : 'text-amber-300 font-bold'}>
            {isJet ? `${hudState.rpm.toFixed(0)}%` : Math.round(hudState.rpm)}
          </span>
        </div>

        <div>
          <div className="flex items-center justify-between text-[8px] sm:text-[9px] leading-none">
            <span className={fuelHighlighted ? 'text-sky-300 font-bold' : 'text-slate-400'}>{t('inst.fuel')}</span>
            <span className={hudState.lowFuelWarning ? 'text-red-400 font-bold' : 'text-sky-200 font-semibold'}>
              {Math.round(hudState.fuelKg)}kg
            </span>
          </div>
          <svg viewBox="0 0 100 6" className="w-full h-1.5 mt-0.5">
            <rect x="0" y="0" width="100" height="6" rx="3" fill="#020617" />
            <rect
              x="0"
              y="0"
              width={fuelPct}
              height="6"
              rx="3"
              fill={hudState.lowFuelWarning ? '#ef4444' : '#38bdf8'}
            />
          </svg>
        </div>

        <div className="flex items-center justify-between text-[7.5px] sm:text-[8.5px] leading-none text-slate-300">
          <span className={hudState.engineTempC > 112 ? 'text-red-400 font-bold' : 'text-emerald-300'}>
            {Math.round(hudState.engineTempC)}°C
          </span>
          <span className={hudState.engineOilPressPsi < 25 ? 'text-red-400 font-bold' : 'text-slate-300'}>
            {Math.round(hudState.engineOilPressPsi)}psi
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1.5 xl:gap-2 shrink-0">
      {/* Analog Tachometer Dial */}
      <div
        className={`flex flex-col items-center gap-0.5 shrink-0 select-none transition-opacity duration-200 ${
          engineHighlighted ? 'opacity-100' : 'opacity-90'
        }`}
        title={`${t('inst.engine')}: ${isJet ? `${hudState.rpm.toFixed(0)}% N1` : `${Math.round(hudState.rpm)} RPM`} · ${t('inst.power')} ${pwrPct}%`}
      >
        <div className={`${sz.wrapper} relative`}>
          <svg viewBox="0 0 100 100" className="w-full h-full">
            <DialBezelFrame highlighted={engineHighlighted} alert={hudState.engineFailed} />

            <path d={describeArc(50, 50, 39.2, greenStart, greenEnd)} fill="none" stroke="#10b981" strokeWidth="3" />
            <line x1={redPt1.x} y1={redPt1.y} x2={redPt2.x} y2={redPt2.y} stroke="#ef4444" strokeWidth="2.5" />

            {[0, 0.25, 0.5, 0.75, 1].map((f, i) => {
              const ang = 225 + f * 270;
              const p1 = polarToCartesian(50, 50, 34.8, ang);
              const p2 = polarToCartesian(50, 50, 41.5, ang);
              return <line key={i} x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke="#cbd5e1" strokeWidth="1.2" />;
            })}

            <text x="50" y="34" textAnchor="middle" fill="#94a3b8" fontSize="6.1" fontFamily="Outfit, sans-serif" fontWeight="700">
              {isJet ? 'N1 %' : 'RPM'}
            </text>

            <rect x="24" y="61" width="52" height="14.5" rx="2.5" fill="#020617" stroke="#334155" strokeWidth="0.9" />
            <text
              x="50"
              y="71.2"
              textAnchor="middle"
              fill={hudState.engineFailed ? '#f87171' : '#fcd34d'}
              fontSize="8.8"
              fontFamily="JetBrains Mono, monospace"
              fontWeight="700"
            >
              {isJet ? `${hudState.rpm.toFixed(0)}%` : Math.round(hudState.rpm)}
            </text>

            <g transform={`rotate(${rpmAngle.toFixed(1)} 50 50)`}>
              <line x1="50" y1="55" x2="50" y2="13" stroke="#f8fafc" strokeWidth="2.1" strokeLinecap="round" />
            </g>
            <circle cx="50" cy="50" r="4" fill="#1e293b" stroke="#94a3b8" strokeWidth="1" />
          </svg>
        </div>
        <span
          className={`font-mono leading-none tracking-tight whitespace-nowrap ${sz.caption} ${
            engineHighlighted ? 'text-sky-300 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          {t('inst.engine')}
        </span>
      </div>

      {/* EIS Fuel, Power, Temp & Oil Bar Cluster */}
      <div
        className={`rounded-xl border px-2 py-1.5 flex flex-col justify-between w-[96px] xl:w-[118px] 2xl:w-[134px] h-[94px] xl:h-[106px] font-mono tabular-nums select-none transition-colors duration-200 ${
          fuelHighlighted || engineHighlighted
            ? 'cockpit-module-priority border-sky-400/70'
            : 'cockpit-module border-slate-700/90'
        }`}
      >
        {/* Fuel Gauge */}
        <div>
          <div className="flex items-center justify-between text-[8.5px] xl:text-[9.5px] leading-none">
            <span className={fuelHighlighted ? 'text-sky-300 font-bold' : 'text-slate-400'}>
              {t('inst.fuel')} ({fuelPct}%)
            </span>
            <span className={hudState.lowFuelWarning ? 'text-red-400 font-bold' : 'text-sky-200 font-bold'}>
              {Math.round(hudState.fuelKg)}kg
            </span>
          </div>
          <svg viewBox="0 0 100 6" className="w-full h-1.5 mt-0.5">
            <rect x="0" y="0" width="100" height="6" rx="3" fill="#020617" />
            <rect
              x="0"
              y="0"
              width={fuelPct}
              height="6"
              rx="3"
              fill={hudState.lowFuelWarning ? '#ef4444' : '#38bdf8'}
            />
          </svg>
          <div className="text-[7.5px] xl:text-[8px] text-slate-400 leading-none mt-0.5">
            {endurPrefix} ~{enduranceMin} min
          </div>
        </div>

        {/* Engine Power % */}
        <div>
          <div className="flex items-center justify-between text-[8.5px] xl:text-[9px] leading-none">
            <span className={engineHighlighted ? 'text-sky-300 font-bold' : 'text-slate-400'}>{t('inst.power')}</span>
            <span className="text-amber-300 font-semibold">{pwrPct}%</span>
          </div>
          <svg viewBox="0 0 100 5" className="w-full h-1 mt-0.5">
            <rect x="0" y="0" width="100" height="5" rx="2.5" fill="#020617" />
            <rect x="0" y="0" width={pwrPct} height="5" rx="2.5" fill="#f59e0b" />
          </svg>
        </div>

        {/* Oil Temp & Oil Pressure */}
        <div className="grid grid-cols-2 gap-1.5 pt-0.5 border-t border-slate-800/90">
          <div>
            <div className="flex items-center justify-between text-[7.5px] xl:text-[8.5px] leading-none">
              <span className="text-slate-400">TMP</span>
              <span className={hudState.engineTempC > 112 ? 'text-red-400 font-bold' : 'text-emerald-300 font-semibold'}>
                {Math.round(hudState.engineTempC)}°
              </span>
            </div>
            <svg viewBox="0 0 100 5" className="w-full h-1 mt-0.5">
              <rect x="0" y="0" width="100" height="5" rx="2.5" fill="#020617" />
              <rect
                x="0"
                y="0"
                width={tempPct}
                height="5"
                rx="2.5"
                fill={hudState.engineTempC > 112 ? '#ef4444' : '#10b981'}
              />
            </svg>
          </div>
          <div>
            <div className="flex items-center justify-between text-[7.5px] xl:text-[8.5px] leading-none">
              <span className="text-slate-400">OIL</span>
              <span className={hudState.engineOilPressPsi < 25 ? 'text-red-400 font-bold' : 'text-emerald-300 font-semibold'}>
                {Math.round(hudState.engineOilPressPsi)}
              </span>
            </div>
            <svg viewBox="0 0 100 5" className="w-full h-1 mt-0.5">
              <rect x="0" y="0" width="100" height="5" rx="2.5" fill="#020617" />
              <rect
                x="0"
                y="0"
                width={oilPct}
                height="5"
                rx="2.5"
                fill={hudState.engineOilPressPsi < 25 ? '#ef4444' : '#10b981'}
              />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * 7. DISPLAY PROFILO IDEALE DI AVVICINAMENTO (VNAV Lateral Glideslope MFD)
 *    High-contrast, glanceable approach display preserving exact container geometry.
 */
export const DescentProfileDisplay: React.FC<{
  nav: FlightNavigationData;
  altitudeFt: number;
  iasKt: number;
  apTargetAltFt: number;
  apEnabled: boolean;
  highlighted?: boolean;
  className?: string;
}> = ({
  nav,
  altitudeFt,
  iasKt,
  apTargetAltFt,
  apEnabled,
  highlighted,
  className = 'w-full h-full',
}) => {
  const rawDistNm = Math.max(0, nav.distanceToRunwayNm);
  const maxDistRef = Math.max(rawDistNm * 1.16, nav.todDistanceNm * 1.22, 2.6);
  const targetScaleNm =
    maxDistRef <= 3.2
      ? 3.2
      : maxDistRef <= 6.5
        ? 6.5
        : maxDistRef <= 12
          ? 12
          : maxDistRef <= 22
            ? 22
            : Math.ceil(maxDistRef / 10) * 10;

  const rwyElevFt = nav.runwayElevationFt;
  const glideTan = Math.tan((nav.glideAngleDeg * Math.PI) / 180);

  const targetPlateauFt =
    nav.guidanceStage === 'HOLD_ALTITUDE'
      ? Math.max(
          nav.thresholdTargetAltFt + 900,
          apEnabled ? apTargetAltFt : Math.round(altitudeFt / 50) * 50
        )
      : Math.max(
          altitudeFt,
          Math.round(nav.thresholdTargetAltFt + nav.todDistanceNm * 6076.12 * glideTan)
        );

  // Smooth 60fps visual state + actual trajectory history buffer (no layout changes)
  const [smooth, setSmooth] = useState(() => ({
    distNm: nav.distanceToRunwayNm,
    altFt: altitudeFt,
    plateauFt: targetPlateauFt,
    scaleNm: targetScaleNm,
    remainingRwyM: nav.remainingRunwayM,
  }));

  const latestTargetsRef = useRef({
    airportId: nav.airportId,
    distNm: nav.distanceToRunwayNm,
    altFt: altitudeFt,
    plateauFt: targetPlateauFt,
    scaleNm: targetScaleNm,
    remainingRwyM: nav.remainingRunwayM,
  });

  const trailRef = useRef<Array<{ distNm: number; altFt: number }>>([
    { distNm: Math.max(0, nav.distanceToRunwayNm), altFt: altitudeFt },
  ]);
  const prevSlopeRef = useRef<number>(0);

  latestTargetsRef.current = {
    airportId: nav.airportId,
    distNm: nav.distanceToRunwayNm,
    altFt: altitudeFt,
    plateauFt: targetPlateauFt,
    scaleNm: targetScaleNm,
    remainingRwyM: nav.remainingRunwayM,
  };

  // Record actual aircraft trajectory samples cleanly along approach
  useEffect(() => {
    const curDist = Math.max(0, nav.distanceToRunwayNm);
    const pts = trailRef.current;
    const last = pts[pts.length - 1];

    // Reset trail on destination change, flight restart, or large jump back
    if (!last || Math.abs(curDist - last.distNm) > 2.4 || curDist > last.distNm + 0.45) {
      trailRef.current = [{ distNm: curDist, altFt: altitudeFt }];
      prevSlopeRef.current = 0;
      return;
    }

    const dDist = last.distNm - curDist;
    if (dDist >= 0.08 || Math.abs(altitudeFt - last.altFt) >= 28) {
      if (dDist > 0.02) {
        const instDeg = Math.atan2(last.altFt - altitudeFt, dDist * 6076.12) * (180 / Math.PI);
        prevSlopeRef.current = prevSlopeRef.current * 0.6 + instDeg * 0.4;
      }
      const next = [...pts, { distNm: curDist, altFt: altitudeFt }];
      trailRef.current = next.length > 30 ? next.slice(next.length - 30) : next;
    }
  }, [nav.airportId, nav.distanceToRunwayNm, altitudeFt]);

  // Smooth exponential interpolation for fluid symbol & scale motion
  useEffect(() => {
    let rafId: number | null = null;
    let lastTs = performance.now();

    const tick = (now: number) => {
      const dt = Math.min(0.06, Math.max(0.004, (now - lastTs) / 1000));
      lastTs = now;
      const tgt = latestTargetsRef.current;

      setSmooth((prev) => {
        // Snap immediately if flight restarted or destination switched
        if (Math.abs(tgt.distNm - prev.distNm) > 3.5 || Math.abs(tgt.altFt - prev.altFt) > 1200) {
          return {
            distNm: tgt.distNm,
            altFt: tgt.altFt,
            plateauFt: tgt.plateauFt,
            scaleNm: tgt.scaleNm,
            remainingRwyM: tgt.remainingRwyM,
          };
        }

        const alphaPos = 1 - Math.exp(-dt * 11.5);
        const alphaScale = 1 - Math.exp(-dt * 7.5);

        const nextDist = prev.distNm + (tgt.distNm - prev.distNm) * alphaPos;
        const nextAlt = prev.altFt + (tgt.altFt - prev.altFt) * alphaPos;
        const nextPlateau = prev.plateauFt + (tgt.plateauFt - prev.plateauFt) * alphaScale;
        const nextScale = prev.scaleNm + (tgt.scaleNm - prev.scaleNm) * alphaScale;
        const nextRemRwy = prev.remainingRwyM + (tgt.remainingRwyM - prev.remainingRwyM) * alphaPos;

        const settled =
          Math.abs(tgt.distNm - nextDist) < 0.002 &&
          Math.abs(tgt.altFt - nextAlt) < 0.6 &&
          Math.abs(tgt.scaleNm - nextScale) < 0.01;

        if (!settled) {
          rafId = window.requestAnimationFrame(tick);
        }

        return {
          distNm: settled ? tgt.distNm : nextDist,
          altFt: settled ? tgt.altFt : nextAlt,
          plateauFt: settled ? tgt.plateauFt : nextPlateau,
          scaleNm: settled ? tgt.scaleNm : nextScale,
          remainingRwyM: settled ? tgt.remainingRwyM : nextRemRwy,
        };
      });
    };

    rafId = window.requestAnimationFrame(tick);
    return () => {
      if (rafId !== null) window.cancelAnimationFrame(rafId);
    };
  }, [
    nav.airportId,
    nav.distanceToRunwayNm,
    nav.remainingRunwayM,
    altitudeFt,
    targetPlateauFt,
    targetScaleNm,
  ]);

  const dispDistNm = smooth.distNm;
  const dispAltFt = smooth.altFt;
  const dispPlateauFt = smooth.plateauFt;
  const maxScaleNm = Math.max(2.5, smooth.scaleNm);

  const minAltFt = Math.max(0, Math.floor((rwyElevFt - 180) / 200) * 200);
  const peakAlt = Math.max(
    dispAltFt + 420,
    dispPlateauFt + 420,
    nav.thresholdTargetAltFt + 1350
  );
  const maxAltFt = Math.max(minAltFt + 1000, peakAlt);
  const altSpan = Math.max(1000, maxAltFt - minAltFt);

  // Internal SVG Coordinate Geometry (outer container size stays 100% untouched)
  const W = 336;
  const H = 92;
  const headerH = 16.5;
  const footerY = 75.5;
  const padL = 8;
  const rwyX = 278;
  const rwyEndX = 328;
  const padT = 20;
  const padB = 19.5;
  const plotW = rwyX - padL;
  const plotH = H - padT - padB;

  const nmToX = (nm: number) => {
    if (nm >= 0) {
      const clamped = Math.min(maxScaleNm, nm);
      return rwyX - (clamped / maxScaleNm) * plotW;
    }
    const pastRatio = Math.min(1, Math.abs(nm) / 1.4);
    return rwyX + pastRatio * (rwyEndX - rwyX - 6);
  };

  const ftToY = (ft: number) => {
    const ratio = (ft - minAltFt) / altSpan;
    return padT + plotH - Math.max(0, Math.min(1.03, ratio)) * plotH;
  };

  const interceptDistNm = Math.max(
    0.35,
    (dispPlateauFt - nav.thresholdTargetAltFt) / (6076.12 * glideTan)
  );
  const todMarkerNm = Math.min(maxScaleNm * 0.96, nav.todDistanceNm);

  const xLeft = padL;
  const xIntercept = nmToX(Math.min(maxScaleNm, interceptDistNm));
  const yPlateau = ftToY(dispPlateauFt);
  const xTodRaw = nmToX(todMarkerNm);
  const xTod = Math.max(padL + 16, Math.min(rwyX - 20, xTodRaw));
  const yThreshold = ftToY(nav.thresholdTargetAltFt);
  const yRwy = ftToY(rwyElevFt);
  const xTouchdown = rwyX + 9;

  const acX =
    nav.relativePosition === 'OVER_RUNWAY'
      ? rwyX +
        Math.max(
          0,
          Math.min(1, 1 - smooth.remainingRwyM / Math.max(400, nav.runwayLengthM))
        ) *
          (rwyEndX - rwyX - 8)
      : nmToX(dispDistNm);
  const acY = ftToY(dispAltFt);
  const idealAtAcY = ftToY(nav.targetProfileAltFt);

  // Intuitive 3-Level Color Coding:
  // - Verde (#34d399): profilo corretto
  // - Giallo (#fbbf24): piccola correzione necessaria / avvio discesa
  // - Rosso (#f87171): fuori dal profilo ideale
  const absAltDev = Math.abs(nav.altDeviationFt);
  const onSlopeStage =
    nav.guidanceStage === 'BEGIN_DESCENT' || nav.guidanceStage === 'FINAL_APPROACH';

  const isRedState =
    nav.tooLow ||
    nav.tooSlow ||
    (onSlopeStage && absAltDev > 340) ||
    (nav.guidanceStage === 'FINAL_APPROACH' && nav.tooFast && nav.distanceToRunwayNm < 2.2);

  const isYellowState =
    !isRedState &&
    (nav.tooHigh ||
      nav.tooFast ||
      (onSlopeStage && absAltDev > 125) ||
      (nav.guidanceStage === 'HOLD_ALTITUDE' && absAltDev > 210) ||
      (nav.guidanceStage === 'BEGIN_DESCENT' &&
        nav.distanceToTodNm >= -0.9 &&
        nav.altDeviationFt > 75));

  const profileHex = isRedState ? '#f87171' : isYellowState ? '#fbbf24' : '#34d399';

  const { lang, t } = useI18n();
  const profileDict = {
    it: {
      onRwy: 'IN PISTA',
      lowSpd: 'VEL. BASSA',
      flareOk: 'FLARE · OK',
      tooLow: 'TROPPO BASSO',
      tooHigh: 'TROPPO ALTO',
      offProf: 'FUORI PROFILO',
      startDesc: 'INIZIA DISCESA',
      highDesc: 'ALTO · SCENDI',
      lowClimb: 'BASSO · SALI',
      fixSpd: 'CORREGGI VEL.',
      holdAlt: 'MANTIENI QUOTA',
      finalOk: 'FINALE OK',
      profOk: 'PROFILO OK',
      todCue: '↘ SCENDI',
      todActive: '3° ATTIVO',
      distLbl: 'DIST ',
      tgtAltLbl: 'Q.CONS ',
      tooltip: 'Profilo di Avvicinamento 3°: Traiettoria Ideale (tratteggiata) vs Traiettoria Effettiva',
    },
    en: {
      onRwy: 'ON RUNWAY',
      lowSpd: 'LOW SPEED',
      flareOk: 'FLARE · OK',
      tooLow: 'TOO LOW',
      tooHigh: 'TOO HIGH',
      offProf: 'OFF PROFILE',
      startDesc: 'BEGIN DESCENT',
      highDesc: 'HIGH · DESCEND',
      lowClimb: 'LOW · CLIMB',
      fixSpd: 'CHECK SPEED',
      holdAlt: 'HOLD ALTITUDE',
      finalOk: 'FINAL OK',
      profOk: 'ON PROFILE',
      todCue: '↘ DESCEND',
      todActive: '3° ACTIVE',
      distLbl: 'DIST ',
      tgtAltLbl: 'IDEAL ',
      tooltip: '3° Approach Profile: Ideal Glideslope (dashed) vs Actual Flight Path',
    },
    fr: {
      onRwy: 'SUR PISTE',
      lowSpd: 'VIT. BASSE',
      flareOk: 'ARRONDI · OK',
      tooLow: 'TROP BAS',
      tooHigh: 'TROP HAUT',
      offProf: 'HORS PLAN',
      startDesc: 'DESCENDRE',
      highDesc: 'HAUT · DESC.',
      lowClimb: 'BAS · MONTEZ',
      fixSpd: 'CORR. VITESSE',
      holdAlt: 'MAINT. ALT.',
      finalOk: 'FINALE OK',
      profOk: 'PLAN OK',
      todCue: '↘ DESC.',
      todActive: '3° ACTIF',
      distLbl: 'DIST ',
      tgtAltLbl: 'ALT.ID ',
      tooltip: 'Profil d’Approche 3° : Plan Idéal (pointillé) vs Trajectoire Réelle',
    },
    de: {
      onRwy: 'AUF PISTE',
      lowSpd: 'ZU LANGSAM',
      flareOk: 'FLARE · OK',
      tooLow: 'ZU TIEF',
      tooHigh: 'ZU HOCH',
      offProf: 'ABWEICHUNG',
      startDesc: 'SINKFLUG START',
      highDesc: 'HOCH · SINKEN',
      lowClimb: 'TIEF · STEIGEN',
      fixSpd: 'TEMPO PRÜFEN',
      holdAlt: 'HÖHE HALTEN',
      finalOk: 'ENDANFLUG OK',
      profOk: 'PROFIL OK',
      todCue: '↘ SINKEN',
      todActive: '3° AKTIV',
      distLbl: 'ENTF ',
      tgtAltLbl: 'SOLL ',
      tooltip: '3°-Anflugprofil: Idealer Gleitpfad (gestrichelt) vs. Tatsächliche Flugbahn',
    },
    es: {
      onRwy: 'EN PISTA',
      lowSpd: 'VEL. BAJA',
      flareOk: 'FLARE · OK',
      tooLow: 'MUY BAJO',
      tooHigh: 'MUY ALTO',
      offProf: 'FUERA SENDA',
      startDesc: 'BAJAR AHORA',
      highDesc: 'ALTO · BAJAR',
      lowClimb: 'BAJO · SUBIR',
      fixSpd: 'AJUSTAR VEL.',
      holdAlt: 'MANT. ALTITUD',
      finalOk: 'FINAL OK',
      profOk: 'SENDA OK',
      todCue: '↘ BAJAR',
      todActive: '3° ACTIVO',
      distLbl: 'DIST ',
      tgtAltLbl: 'ALT.ID ',
      tooltip: 'Perfil de Aproximación 3°: Senda Ideal (discontinua) vs Trayectoria Real',
    },
  }[lang];

  const statusText =
    nav.guidanceStage === 'LANDED'
      ? profileDict.onRwy
      : nav.inFlareWindow
        ? nav.tooSlow
          ? profileDict.lowSpd
          : profileDict.flareOk
        : isRedState
          ? nav.tooLow
            ? profileDict.tooLow
            : nav.tooSlow
              ? `${profileDict.lowSpd} ${Math.round(iasKt)}kt`
              : nav.altDeviationFt > 340
                ? profileDict.tooHigh
                : profileDict.offProf
          : isYellowState
            ? nav.guidanceStage === 'BEGIN_DESCENT' && nav.distanceToTodNm >= -0.9
              ? profileDict.startDesc
              : nav.altDeviationFt > 125
                ? profileDict.highDesc
                : nav.altDeviationFt < -125
                  ? profileDict.lowClimb
                  : profileDict.fixSpd
            : nav.guidanceStage === 'HOLD_ALTITUDE'
              ? profileDict.holdAlt
              : nav.guidanceStage === 'FINAL_APPROACH'
                ? profileDict.finalOk
                : profileDict.profOk;

  const isTodCueMoment =
    nav.relativePosition === 'AHEAD' &&
    ((nav.guidanceStage === 'BEGIN_DESCENT' && nav.distanceToTodNm >= -1.05) ||
      (nav.guidanceStage === 'HOLD_ALTITUDE' &&
        nav.distanceToTodNm >= 0 &&
        nav.distanceToTodNm <= 0.5));

  const isDescentUnderway =
    !isTodCueMoment &&
    (nav.guidanceStage === 'FINAL_APPROACH' ||
      nav.guidanceStage === 'LANDED' ||
      (nav.guidanceStage === 'BEGIN_DESCENT' && nav.distanceToTodNm < -1.05));

  const todColor = isTodCueMoment
    ? absAltDev <= 125
      ? '#34d399'
      : '#fbbf24'
    : isDescentUnderway
      ? '#10b981'
      : '#fbbf24';

  const todLabel = isTodCueMoment
    ? profileDict.todCue
    : isDescentUnderway
      ? profileDict.todActive
      : nav.distanceToTodNm > 0.1
        ? `TOD ${nav.distanceToTodNm.toFixed(1)}NM`
        : t('inst.profileTodMarker');

  // Build actual aircraft flight trail polyline in SVG coordinates
  const visibleTrailPts = trailRef.current
    .filter((p) => p.distNm <= maxScaleNm * 1.02 && p.distNm >= Math.max(0, dispDistNm) - 0.02)
    .map((p) => `${nmToX(p.distNm).toFixed(1)},${ftToY(p.altFt).toFixed(1)}`);

  if (nav.relativePosition === 'AHEAD') {
    visibleTrailPts.push(`${acX.toFixed(1)},${acY.toFixed(1)}`);
  }
  const actualTrailPointsStr = visibleTrailPts.length >= 2 ? visibleTrailPts.join(' ') : null;

  // Short forward actual-trajectory projection vector ahead of aircraft nose
  const slopeDeg =
    nav.guidanceStage === 'LANDED'
      ? 0
      : Math.max(-8, Math.min(10, prevSlopeRef.current));
  const vecLen = nav.relativePosition === 'AHEAD' ? 15 : 0;
  const vecEndX = Math.min(xTouchdown, acX + vecLen);
  const vecEndY = Math.max(
    padT + 1,
    Math.min(yRwy, acY + Math.sin((slopeDeg * Math.PI) / 180) * vecLen * 2.1)
  );
  const acTiltSvgDeg =
    nav.guidanceStage === 'LANDED' ? 0 : Math.max(-5.5, Math.min(6.5, slopeDeg * 0.65));

  const distDisplay =
    nav.relativePosition === 'OVER_RUNWAY' || nav.guidanceStage === 'LANDED'
      ? `${Math.max(0, Math.round(smooth.remainingRwyM))}m`
      : `${Math.max(0, nav.distanceToRunwayNm).toFixed(1)} NM`;

  const vsFormatted =
    nav.recommendedVsiFpm > 0
      ? `+${nav.recommendedVsiFpm}`
      : `${nav.recommendedVsiFpm}`;

  const altDevFormatted =
    nav.altDeviationFt >= 0 ? `+${nav.altDeviationFt}ft` : `${nav.altDeviationFt}ft`;

  return (
    <div
      className={`rounded-xl border overflow-hidden select-none transition-colors duration-200 ${
        highlighted
          ? 'border-sky-400/80 shadow-[inset_0_0_16px_rgba(56,189,248,0.16)]'
          : 'border-slate-700/90'
      } bg-[#030711] ${className}`}
      title={profileDict.tooltip}
    >
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="w-full h-full block">
        {/* High-Contrast Avionics Background & Dedicated Telemetry Bands */}
        <rect x="0" y="0" width={W} height={H} fill="#030711" />
        <rect x="0" y="0" width={W} height={headerH} fill="#07101f" />
        <line x1="0" y1={headerH} x2={W} y2={headerH} stroke="#1e293b" strokeWidth="0.8" />
        <rect x="0" y={footerY} width={W} height={H - footerY} fill="#07101f" />
        <line x1="0" y1={footerY} x2={W} y2={footerY} stroke="#1e293b" strokeWidth="0.8" />

        {/* Single Minimalist Mid-Altitude Reference Line (Clutter-Free) */}
        <line
          x1={padL}
          y1={padT + plotH * 0.5}
          x2={rwyX}
          y2={padT + plotH * 0.5}
          stroke="#132036"
          strokeWidth="0.75"
          strokeDasharray="3 4"
        />

        {/* TOP TELEMETRY BAR: Distanza Pista | Velocità Verticale Ideale | Stato Discesa */}
        <text
          x={padL}
          y="11.6"
          fontSize="7.7"
          fontFamily="JetBrains Mono, monospace"
        >
          <tspan fill="#94a3b8" fontWeight="600">{profileDict.distLbl}</tspan>
          <tspan fill="#f8fafc" fontWeight="800">{distDisplay}</tspan>
        </text>

        <text
          x="156"
          y="11.6"
          textAnchor="middle"
          fontSize="7.7"
          fontFamily="JetBrains Mono, monospace"
        >
          <tspan fill="#94a3b8" fontWeight="600">VS </tspan>
          <tspan fill="#e2e8f0" fontWeight="800">{vsFormatted}</tspan>
          <tspan fill="#94a3b8" fontSize="6.9"> fpm</tspan>
        </text>

        <text
          x={rwyEndX}
          y="11.6"
          textAnchor="end"
          fill={profileHex}
          fontSize="7.8"
          fontFamily="JetBrains Mono, monospace"
          fontWeight="800"
        >
          {statusText}
        </text>

        {/* IDEAL TRAJECTORY CORRIDOR & DASHED REFERENCE PATH (3° Glideslope) */}
        <polygon
          points={`${xIntercept.toFixed(1)},${Math.max(padT - 1, yPlateau - 5.2).toFixed(1)} ${xTouchdown},${(yThreshold - 1.8).toFixed(1)} ${xTouchdown},${Math.min(yRwy, yThreshold + 1.8).toFixed(1)} ${xIntercept.toFixed(1)},${Math.min(yRwy, yPlateau + 5.2).toFixed(1)}`}
          fill="#10b981"
          fillOpacity="0.11"
        />
        {xIntercept > xLeft + 4 && (
          <line
            x1={xLeft}
            y1={yPlateau}
            x2={xIntercept}
            y2={yPlateau}
            stroke="#7dd3fc"
            strokeWidth="1.45"
            strokeDasharray="4.5 2.5"
          />
        )}
        <line
          x1={xIntercept}
          y1={yPlateau}
          x2={xTouchdown}
          y2={yThreshold}
          stroke="#2dd4bf"
          strokeWidth="1.85"
          strokeDasharray="5 2.5"
        />

        {/* GROUND LINE & RECOGNIZABLE RUNWAY SYMBOL (Threshold Stripes, Centerline & PAPI) */}
        <line x1={padL} y1={yRwy} x2={rwyX - 2} y2={yRwy} stroke="#475569" strokeWidth="1.2" />

        {/* Approach Lead-in Lights & PAPI Indicator Dots */}
        <circle cx={rwyX - 9.5} cy={yRwy - 0.5} r="0.9" fill="#bae6fd" opacity="0.85" />
        <circle cx={rwyX - 6} cy={yRwy - 0.5} r="0.9" fill="#bae6fd" opacity="0.95" />
        <circle
          cx={rwyX - 2.6}
          cy={yRwy - 1.4}
          r="1.15"
          fill={isRedState ? '#f87171' : isYellowState ? '#fbbf24' : '#34d399'}
        />

        {/* Runway Asphalt Strip with Crisp Border, Threshold Zebra & Centerline */}
        <g>
          <rect
            x={rwyX}
            y={yRwy - 3.1}
            width={rwyEndX - rwyX}
            height="6.2"
            rx="1.2"
            fill="#1e293b"
            stroke="#f8fafc"
            strokeWidth="0.95"
          />
          {/* Threshold Piano-Keys */}
          <line x1={rwyX + 2.2} y1={yRwy - 1.7} x2={rwyX + 6.4} y2={yRwy - 1.7} stroke="#f8fafc" strokeWidth="0.85" />
          <line x1={rwyX + 2.2} y1={yRwy} x2={rwyX + 6.4} y2={yRwy} stroke="#f8fafc" strokeWidth="0.85" />
          <line x1={rwyX + 2.2} y1={yRwy + 1.7} x2={rwyX + 6.4} y2={yRwy + 1.7} stroke="#f8fafc" strokeWidth="0.85" />
          {/* Aiming Point & Dashed Centerline */}
          <rect x={xTouchdown - 1.2} y={yRwy - 1.8} width="3" height="3.6" rx="0.5" fill="#34d399" fillOpacity="0.9" />
          <line
            x1={rwyX + 14.5}
            y1={yRwy}
            x2={rwyEndX - 3}
            y2={yRwy}
            stroke="#f8fafc"
            strokeWidth="0.85"
            strokeDasharray="3.5 2.5"
          />
        </g>

        {/* DESCENT INDICATOR (TOD — Top of Descent) */}
        {todMarkerNm <= maxScaleNm * 0.99 && (
          <g transform={`translate(${xTod.toFixed(1)} ${yPlateau.toFixed(1)})`}>
            {/* Subtle vertical reference drop to ground */}
            <line
              x1="0"
              y1="4.8"
              x2="0"
              y2={Math.max(5.5, yRwy - yPlateau)}
              stroke={todColor}
              strokeWidth="0.85"
              strokeDasharray="2 2.5"
              opacity={isDescentUnderway ? '0.32' : '0.62'}
            />

            {/* Discrete 2-Cycle Soft Ring Animation ONLY when reaching descent point */}
            {isTodCueMoment && (
              <circle
                key="tod-cue-active"
                cx="0"
                cy="0"
                r="6.2"
                fill="none"
                stroke={todColor}
                strokeWidth="1.4"
                className="tod-cue-pulse"
              />
            )}

            {/* TOD Diamond Vertex Symbol */}
            <polygon
              points={isTodCueMoment ? '0,-5.2 5.2,0 0,5.2 -5.2,0' : '0,-4.2 4.2,0 0,4.2 -4.2,0'}
              fill={isDescentUnderway ? '#064e3b' : todColor}
              stroke={isDescentUnderway ? '#34d399' : '#020617'}
              strokeWidth="0.95"
            />

            {/* Label Pill Above or Below Vertex (Clamped Away from Header) */}
            <g transform={`translate(0 ${yPlateau < padT + 10 ? 11.5 : -7.2})`}>
              <rect
                x={isTodCueMoment ? -21 : -23}
                y="-5.6"
                width={isTodCueMoment ? 42 : 46}
                height="7.6"
                rx="2"
                fill="#030711"
                fillOpacity="0.88"
                stroke={todColor}
                strokeWidth={isTodCueMoment ? '0.85' : '0.5'}
                strokeOpacity={isDescentUnderway ? '0.55' : '0.9'}
              />
              <text
                x="0"
                y="0.2"
                textAnchor="middle"
                fill={isTodCueMoment ? todColor : isDescentUnderway ? '#6ee7b7' : '#fde68a'}
                fontSize="6.5"
                fontFamily="JetBrains Mono, monospace"
                fontWeight="800"
              >
                {todLabel}
              </text>
            </g>
          </g>
        )}

        {/* ACTUAL AIRCRAFT TRAJECTORY (Solid High-Contrast Trail + Forward Trend Vector) */}
        {actualTrailPointsStr && (
          <g>
            <polyline
              points={actualTrailPointsStr}
              fill="none"
              stroke="#020617"
              strokeWidth="3.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <polyline
              points={actualTrailPointsStr}
              fill="none"
              stroke={profileHex}
              strokeWidth="1.9"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </g>
        )}

        {nav.relativePosition === 'AHEAD' && vecEndX > acX + 3 && (
          <line
            x1={acX}
            y1={acY}
            x2={vecEndX}
            y2={vecEndY}
            stroke={profileHex}
            strokeWidth="1.35"
            strokeLinecap="round"
            opacity="0.9"
          />
        )}

        {/* Vertical Deviation Connector to Ideal Path */}
        {nav.relativePosition === 'AHEAD' && absAltDev >= 35 && (
          <line
            x1={acX}
            y1={acY}
            x2={acX}
            y2={idealAtAcY}
            stroke={profileHex}
            strokeWidth="1.15"
            strokeDasharray="1.8 1.8"
            opacity="0.92"
          />
        )}

        {/* HIGH-VISIBILITY AIRCRAFT SYMBOL */}
        <g transform={`translate(${acX.toFixed(2)} ${acY.toFixed(2)}) rotate(${acTiltSvgDeg.toFixed(1)})`}>
          {/* Dark Contrast Halo */}
          <path
            d="M -8.4 0.9 L 6.4 0.9 L 9.5 -0.8 L 6.2 -2.3 L -3.6 -2.3 L -7.4 -5.8 L -9.6 -5.8 L -8.4 0.9 Z"
            fill="#020617"
            stroke="#020617"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
          {/* Crisp Colored Fuselage & Tailfin */}
          <path
            d="M -8.0 0.8 L 6.2 0.8 L 9.2 -0.8 L 6.0 -2.1 L -3.6 -2.1 L -7.2 -5.5 L -9.2 -5.5 L -8.0 0.8 Z"
            fill={profileHex}
            stroke="#f8fafc"
            strokeWidth="0.65"
            strokeLinejoin="round"
          />
          {/* Wing Reference Highlight */}
          <line x1="-2.6" y1="-0.4" x2="2.6" y2="-0.4" stroke="#f8fafc" strokeWidth="1.25" strokeLinecap="round" />
        </g>

        {/* BOTTOM TELEMETRY BAR: Quota Consigliata & Scostamento | Vref | Identificativo Pista */}
        <text
          x={padL}
          y="87.2"
          fontSize="7.5"
          fontFamily="JetBrains Mono, monospace"
        >
          <tspan fill="#94a3b8" fontWeight="600">{profileDict.tgtAltLbl}</tspan>
          <tspan fill="#f8fafc" fontWeight="800">{nav.targetProfileAltFt}ft </tspan>
          <tspan fill={profileHex} fontWeight="800">({altDevFormatted})</tspan>
        </text>

        <text
          x="216"
          y="87.2"
          textAnchor="middle"
          fontSize="7.5"
          fontFamily="JetBrains Mono, monospace"
        >
          <tspan fill="#94a3b8" fontWeight="600">Vref </tspan>
          <tspan fill="#e2e8f0" fontWeight="800">{nav.vRefKt}kt</tspan>
        </text>

        <text
          x={rwyEndX}
          y="87.2"
          textAnchor="end"
          fill="#fcd34d"
          fontSize="7.7"
          fontFamily="JetBrains Mono, monospace"
          fontWeight="800"
        >
          RWY {nav.runwayId}
        </text>
      </svg>
    </div>
  );
};

/**
 * 8. HARDWARE-STYLE SVG PITCH YOKE LEVER (Zero inline styles, touch & mouse pointer capture)
 */
export const PitchYokeLever: React.FC<{
  pitchKnobPct: number; // -1 (top/cabra) .. +1 (bottom/picchia)
  elevatorInput: number;
  apEnabled: boolean;
  onPointerDown: (e: React.PointerEvent<HTMLDivElement>) => void;
  onPointerMove: (e: React.PointerEvent<HTMLDivElement>) => void;
  onPointerUp: (e: React.PointerEvent<HTMLDivElement>) => void;
  className?: string;
}> = ({
  pitchKnobPct,
  elevatorInput,
  apEnabled,
  onPointerDown,
  onPointerMove,
  onPointerUp,
  className = 'w-[48px] h-[104px]',
}) => {
  const { t } = useI18n();
  // Visual handle Y inside 0..100 SVG coordinate space (center = 50)
  const activeOffset = apEnabled ? -elevatorInput : pitchKnobPct;
  const knobY = 50 + Math.max(-1, Math.min(1, activeOffset)) * 31;

  return (
    <div
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      className={`rounded-xl border border-slate-600/90 cockpit-module relative touch-none select-none cursor-ns-resize shrink-0 ${className}`}
      title={t('hud.pitchControlHeader')}
    >
      <svg viewBox="0 0 52 110" className="w-full h-full block pointer-events-none">
        <text x="26" y="10" textAnchor="middle" fill="#94a3b8" fontSize="7.5" fontFamily="JetBrains Mono, monospace" fontWeight="700">
          {t('hud.btnPitchUp')}
        </text>
        <text x="26" y="105" textAnchor="middle" fill="#94a3b8" fontSize="7.5" fontFamily="JetBrains Mono, monospace" fontWeight="700">
          {t('hud.btnPitchDown')}
        </text>

        {/* Center Recessed Slot & Graduation Ticks */}
        <rect x="22.5" y="16" width="7" height="78" rx="3.5" fill="#020617" stroke="#334155" strokeWidth="1" />
        {[22, 36, 50, 64, 78, 88].map((ty) => (
          <g key={ty}>
            <line
              x1={ty === 50 ? 9 : 14}
              y1={ty}
              x2={20}
              y2={ty}
              stroke={ty === 50 ? '#38bdf8' : '#475569'}
              strokeWidth={ty === 50 ? '1.4' : '0.9'}
            />
            <line
              x1={32}
              y1={ty}
              x2={ty === 50 ? 43 : 38}
              y2={ty}
              stroke={ty === 50 ? '#38bdf8' : '#475569'}
              strokeWidth={ty === 50 ? '1.4' : '0.9'}
            />
          </g>
        ))}

        {/* Tactile Yoke Grip Handle */}
        <g transform={`translate(0 ${(knobY - 50).toFixed(1)})`}>
          <rect
            x="6"
            y="40"
            width="40"
            height="20"
            rx="5"
            fill={apEnabled ? '#0284c7' : '#f59e0b'}
            stroke={apEnabled ? '#bae6fd' : '#fef3c7'}
            strokeWidth="1.4"
          />
          <line x1="14" y1="48" x2="38" y2="48" stroke="#0f172a" strokeWidth="1.3" strokeLinecap="round" />
          <line x1="14" y1="52" x2="38" y2="52" stroke="#0f172a" strokeWidth="1.3" strokeLinecap="round" />
        </g>
      </svg>
    </div>
  );
};

/**
 * 9. HARDWARE-STYLE SVG THROTTLE VERNIER QUADRANT (Zero inline styles, touch & mouse pointer capture)
 */
export const ThrottleQuadrantLever: React.FC<{
  throttle: number; // 0..1
  apEnabled: boolean;
  highlighted?: boolean;
  onPointerDown: (e: React.PointerEvent<HTMLDivElement>) => void;
  onPointerMove: (e: React.PointerEvent<HTMLDivElement>) => void;
  onPointerUp: (e: React.PointerEvent<HTMLDivElement>) => void;
  className?: string;
}> = ({
  throttle,
  apEnabled,
  highlighted,
  onPointerDown,
  onPointerMove,
  onPointerUp,
  className = 'w-[46px] h-[104px]',
}) => {
  const pct = Math.max(0, Math.min(100, Math.round(throttle * 100)));
  const trackTop = 18;
  const trackBottom = 88;
  const trackH = trackBottom - trackTop;
  const fillH = (pct / 100) * trackH;
  const fillY = trackBottom - fillH;
  const handleY = fillY;

  const { t } = useI18n();
  return (
    <div
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      className={`rounded-xl border relative touch-none select-none cursor-ns-resize shrink-0 transition-colors duration-200 ${
        highlighted
          ? 'cockpit-module-priority border-sky-400/75'
          : 'cockpit-module border-slate-600/90'
      } ${className}`}
      title={`${t('hud.powerControlHeader')}: ${pct}%`}
    >
      <svg viewBox="0 0 48 110" className="w-full h-full block pointer-events-none">
        <text x="24" y="10.5" textAnchor="middle" fill="#cbd5e1" fontSize="7.5" fontFamily="JetBrains Mono, monospace" fontWeight="700">
          {t('inst.powerSliderLabel')}
        </text>

        {/* Throttle Slot & Power Fill */}
        <rect x="15" y={trackTop} width="18" height={trackH} rx="4" fill="#020617" stroke="#334155" strokeWidth="1" />
        <rect
          x="16.5"
          y={fillY}
          width="15"
          height={Math.max(0, fillH)}
          rx="3"
          fill={pct > 90 ? '#f97316' : '#f59e0b'}
          opacity="0.85"
        />

        {/* 0-25-50-75-100 Detent Ticks */}
        {[0, 0.25, 0.5, 0.75, 1].map((t) => {
          const ty = trackBottom - t * trackH;
          return (
            <g key={t}>
              <line x1="8" y1={ty} x2="13.5" y2={ty} stroke="#64748b" strokeWidth="1" />
              <line x1="34.5" y1={ty} x2="40" y2={ty} stroke="#64748b" strokeWidth="1" />
            </g>
          );
        })}

        {/* Throttle Grip Bar (Always 100% Manual Pilot Control) */}
        <rect
          x="6"
          y={handleY - 5.5}
          width="36"
          height="11"
          rx="3.5"
          fill="#fbbf24"
          stroke="#0f172a"
          strokeWidth="1.2"
        />
        <line x1="13" y1={handleY} x2="35" y2={handleY} stroke="#0f172a" strokeWidth="1.3" strokeLinecap="round" />

        {/* Numeric Readout */}
        <text x="24" y="104.5" textAnchor="middle" fill="#f8fafc" fontSize="9.2" fontFamily="JetBrains Mono, monospace" fontWeight="700">
          {pct}%
        </text>
      </svg>
    </div>
  );
};

/**
 * 10. LARGE GRADUATED PITCH SLIDER ("CURSORI" MODE — CABRATA / PICCHIATA)
 *     Auto-centering spring-return command (-100% .. 0% .. +100%):
 *     dragging up pitches up, dragging down pitches down, releasing smoothly returns to 0%.
 *     Zero inline style= attributes; full Mouse & Touchscreen multi-touch PointerCapture.
 */
export const PitchControlSlider: React.FC<{
  elevatorValue: number; // -1 (picchia -100%) .. 0 (neutro 0%) .. +1 (cabra +100%)
  apEnabled: boolean;
  onChangeElevator: (val: number) => void;
  onHoldChange?: (held: boolean) => void;
  compact?: boolean;
  className?: string;
}> = ({
  elevatorValue,
  apEnabled,
  onChangeElevator,
  onHoldChange,
  compact = false,
  className = 'w-full h-full',
}) => {
  const pointerIdRef = useRef<number | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const onHoldChangeRef = useRef(onHoldChange);
  onHoldChangeRef.current = onHoldChange;
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    if (apEnabled && pointerIdRef.current !== null) {
      pointerIdRef.current = null;
      setIsDragging(false);
      onHoldChangeRef.current?.(false);
    }
  }, [apEnabled]);

  useEffect(() => {
    return () => {
      if (pointerIdRef.current !== null) {
        pointerIdRef.current = null;
        onHoldChangeRef.current?.(false);
      }
    };
  }, []);

  const clampedVal = Math.max(-1, Math.min(1, elevatorValue));
  const pct = Math.round(clampedVal * 100);
  const formattedPct = pct > 0 ? `+${pct}%` : `${pct}%`;

  const svgW = 144;
  const svgH = compact ? 66 : 86;
  const trackTop = compact ? 8 : 9;
  const trackBottom = svgH - (compact ? 8 : 9);
  const trackH = trackBottom - trackTop;
  const centerY = trackTop + trackH * 0.5;
  const handleY = centerY - clampedVal * (trackH * 0.5);

  const fillY = Math.min(centerY, handleY);
  const fillH = Math.abs(handleY - centerY);

  const updateFromClientY = (clientY: number) => {
    if (apEnabled) return;
    const svgEl = svgRef.current;
    if (!svgEl) return;
    const rect = svgEl.getBoundingClientRect();
    if (rect.height <= 1) return;
    const vFrac = (clientY - rect.top) / rect.height;
    const topFrac = trackTop / svgH;
    const bottomFrac = trackBottom / svgH;
    const normFromTop = Math.max(0, Math.min(1, (vFrac - topFrac) / (bottomFrac - topFrac)));
    const nextVal = Math.round((1 - 2 * normFromTop) * 100) / 100;
    onChangeElevator(Math.max(-1, Math.min(1, nextVal)));
  };

  const releasePointer = (pointerId?: number) => {
    if (pointerId !== undefined && pointerIdRef.current !== pointerId) return;
    if (pointerIdRef.current !== null) {
      pointerIdRef.current = null;
      setIsDragging(false);
      onHoldChangeRef.current?.(false);
    }
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (apEnabled) return;
    e.preventDefault();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Synthetic or non-capturable pointer fallback
    }
    pointerIdRef.current = e.pointerId;
    setIsDragging(true);
    onHoldChangeRef.current?.(true);
    updateFromClientY(e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (pointerIdRef.current !== e.pointerId) return;
    updateFromClientY(e.clientY);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    releasePointer(e.pointerId);
  };

  const handleLostPointerCapture = (e: React.PointerEvent<HTMLDivElement>) => {
    releasePointer(e.pointerId);
  };

  const pitchMarks = compact
    ? [
        { val: 1, label: '+100', major: true },
        { val: 0.5, label: '+50', major: false },
        { val: 0, label: '0%', major: true },
        { val: -0.5, label: '-50', major: false },
        { val: -1, label: '-100', major: true },
      ]
    : [
        { val: 1, label: '+100%', major: true },
        { val: 0.75, label: '', major: false },
        { val: 0.5, label: '+50%', major: true },
        { val: 0.25, label: '', major: false },
        { val: 0, label: '0%', major: true },
        { val: -0.25, label: '', major: false },
        { val: -0.5, label: '-50%', major: true },
        { val: -0.75, label: '', major: false },
        { val: -1, label: '-100%', major: true },
      ];

  const { t } = useI18n();
  const upWord = t('inst.pitchUpTag').replace('▲ ', '');
  const dnWord = t('inst.pitchDownTag').replace('▼ ', '');
  const stateWord = apEnabled
    ? 'AP'
    : pct > 1
      ? upWord
      : pct < -1
        ? dnWord
        : t('hud.pitchNeutral');

  return (
    <div
      className={`rounded-xl border-2 flex flex-col justify-between select-none font-mono tabular-nums transition-colors duration-150 ${
        apEnabled
          ? 'cockpit-module border-emerald-500/60'
          : isDragging
            ? 'cockpit-module border-sky-400'
            : 'cockpit-module border-slate-600 hover:border-sky-400/80'
      } ${className}`}
      title={`${t('hud.pitchControlHeader')}: ${formattedPct} (${stateWord})`}
    >
      {/* Top Digital Value Readout */}
      <div className="flex items-center justify-between gap-1 px-2 pt-1 pb-0.5 border-b border-slate-800/90 shrink-0">
        <span className="text-[8.5px] sm:text-[9px] font-bold text-slate-300 tracking-tight truncate">
          {compact ? t('inst.pitchSliderLabel') : t('hud.pitchControlHeader')}
        </span>
        <div className="flex items-center gap-1 shrink-0">
          <span
            className={`px-1.5 py-0.2 rounded border text-[9.5px] sm:text-[10.5px] font-extrabold leading-tight ${
              apEnabled
                ? 'bg-emerald-950/90 border-emerald-400/70 text-emerald-300'
                : pct > 0
                  ? 'bg-sky-950/90 border-sky-400/70 text-sky-200'
                  : pct < 0
                    ? 'bg-amber-950/90 border-amber-400/70 text-amber-200'
                    : 'bg-slate-950 border-slate-700 text-slate-200'
            }`}
          >
            {apEnabled ? `AP ${formattedPct}` : formattedPct}
          </span>
        </div>
      </div>

      {/* Interactive Pointer-Captured Graduated Slider Track */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onLostPointerCapture={handleLostPointerCapture}
        className={`flex-1 w-full min-h-0 touch-none ${
          apEnabled ? 'cursor-not-allowed opacity-85' : 'cursor-ns-resize'
        }`}
      >
        <svg
          ref={svgRef}
          viewBox={`0 0 ${svgW} ${svgH}`}
          className="w-full h-full block pointer-events-none"
        >
          {/* Directional End Labels on Right Margin */}
          <text
            x={svgW - 6}
            y={trackTop + 4}
            textAnchor="end"
            fill="#7dd3fc"
            fontSize={compact ? '6.8' : '7.5'}
            fontFamily="JetBrains Mono, monospace"
            fontWeight="700"
          >
            {upWord}
          </text>
          {!compact && (
            <text
              x={svgW - 6}
              y={centerY + 2.5}
              textAnchor="end"
              fill="#94a3b8"
              fontSize="6.8"
              fontFamily="JetBrains Mono, monospace"
              fontWeight="600"
            >
              {stateWord}
            </text>
          )}
          <text
            x={svgW - 6}
            y={trackBottom + 1}
            textAnchor="end"
            fill="#fcd34d"
            fontSize={compact ? '6.8' : '7.5'}
            fontFamily="JetBrains Mono, monospace"
            fontWeight="700"
          >
            {dnWord}
          </text>

          {/* Graduated Percentage Scale & Tick Marks */}
          {pitchMarks.map((m) => {
            const ty = centerY - m.val * (trackH * 0.5);
            const isZero = m.val === 0;
            return (
              <g key={m.val}>
                <line
                  x1={m.major ? 40 : 45}
                  y1={ty}
                  x2={isZero ? 104 : 53}
                  y2={ty}
                  stroke={isZero ? '#38bdf8' : m.major ? '#94a3b8' : '#475569'}
                  strokeWidth={isZero ? '1.5' : m.major ? '1.1' : '0.8'}
                  strokeDasharray={isZero ? '2.5 1.5' : undefined}
                />
                {m.label && (
                  <text
                    x="37"
                    y={ty + 2.6}
                    textAnchor="end"
                    fill={isZero ? '#7dd3fc' : '#cbd5e1'}
                    fontSize={compact ? '7' : '7.6'}
                    fontFamily="JetBrains Mono, monospace"
                    fontWeight={isZero ? '700' : '600'}
                  >
                    {m.label}
                  </text>
                )}
              </g>
            );
          })}

          {/* Recessed Vertical Slider Channel */}
          <rect
            x="56"
            y={trackTop}
            width="22"
            height={trackH}
            rx="5"
            fill="#020617"
            stroke="#334155"
            strokeWidth="1.2"
          />

          {/* Center Neutral Detent Line Across Channel */}
          <line
            x1="53"
            y1={centerY}
            x2="81"
            y2={centerY}
            stroke="#38bdf8"
            strokeWidth="1.6"
          />

          {/* Bidirectional Active Deflection Fill from 0% Center */}
          {fillH > 0.5 && (
            <rect
              x="58"
              y={fillY}
              width="18"
              height={fillH}
              rx="3"
              fill={apEnabled ? '#10b981' : clampedVal >= 0 ? '#38bdf8' : '#f59e0b'}
              opacity="0.82"
            />
          )}

          {/* Large Tactile Yoke Slider Handle */}
          <g transform={`translate(0 ${handleY.toFixed(1)})`}>
            <rect
              x="46"
              y="-6.5"
              width="42"
              height="13"
              rx="4"
              fill={apEnabled ? '#10b981' : clampedVal > 0.02 ? '#38bdf8' : clampedVal < -0.02 ? '#fbbf24' : '#e2e8f0'}
              stroke="#0f172a"
              strokeWidth="1.3"
            />
            <line x1="53" y1="-2" x2="81" y2="-2" stroke="#0f172a" strokeWidth="1.2" strokeLinecap="round" />
            <line x1="53" y1="2" x2="81" y2="2" stroke="#0f172a" strokeWidth="1.2" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
};

/**
 * 11. LARGE GRADUATED ENGINE POWER SLIDER ("CURSORI" MODE — POTENZA MOTORE 0%..100%)
 *     Holds selected throttle setting (0% .. 100%) until adjusted by the pilot.
 *     Zero inline style= attributes; full Mouse & Touchscreen multi-touch PointerCapture.
 */
export const PowerControlSlider: React.FC<{
  throttle: number; // 0..1
  highlighted?: boolean;
  onChangeThrottle: (val: number) => void;
  compact?: boolean;
  className?: string;
}> = ({
  throttle,
  highlighted = false,
  onChangeThrottle,
  compact = false,
  className = 'w-full h-full',
}) => {
  const pointerIdRef = useRef<number | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const clampedThr = Math.max(0, Math.min(1, throttle));
  const pct = Math.round(clampedThr * 100);

  const svgW = 144;
  const svgH = compact ? 66 : 86;
  const trackTop = compact ? 8 : 9;
  const trackBottom = svgH - (compact ? 8 : 9);
  const trackH = trackBottom - trackTop;
  const fillH = clampedThr * trackH;
  const handleY = trackBottom - fillH;

  const updateFromClientY = (clientY: number) => {
    const svgEl = svgRef.current;
    if (!svgEl) return;
    const rect = svgEl.getBoundingClientRect();
    if (rect.height <= 1) return;
    const vFrac = (clientY - rect.top) / rect.height;
    const topFrac = trackTop / svgH;
    const bottomFrac = trackBottom / svgH;
    const normFromTop = Math.max(0, Math.min(1, (vFrac - topFrac) / (bottomFrac - topFrac)));
    const nextThr = Math.round((1 - normFromTop) * 100) / 100;
    onChangeThrottle(Math.max(0, Math.min(1, nextThr)));
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    pointerIdRef.current = e.pointerId;
    updateFromClientY(e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (pointerIdRef.current !== e.pointerId) return;
    updateFromClientY(e.clientY);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (pointerIdRef.current === e.pointerId) {
      pointerIdRef.current = null;
    }
  };

  const powerMarks = compact
    ? [
        { val: 1, label: '100%', major: true },
        { val: 0.75, label: '', major: false },
        { val: 0.5, label: '50%', major: true },
        { val: 0.25, label: '', major: false },
        { val: 0, label: '0%', major: true },
      ]
    : [
        { val: 1, label: '100%', major: true },
        { val: 0.875, label: '', major: false },
        { val: 0.75, label: '75%', major: true },
        { val: 0.625, label: '', major: false },
        { val: 0.5, label: '50%', major: true },
        { val: 0.375, label: '', major: false },
        { val: 0.25, label: '25%', major: true },
        { val: 0.125, label: '', major: false },
        { val: 0, label: '0%', major: true },
      ];

  const { t } = useI18n();
  return (
    <div
      className={`rounded-xl border-2 flex flex-col justify-between select-none font-mono tabular-nums transition-colors duration-150 ${
        highlighted
          ? 'cockpit-module-priority border-amber-400/85'
          : 'cockpit-module border-slate-600 hover:border-amber-400/80'
      } ${className}`}
      title={`${t('hud.powerControlHeader')}: ${pct}%`}
    >
      {/* Top Digital Percentage Readout */}
      <div className="flex items-center justify-between gap-1 px-2 pt-1 pb-0.5 border-b border-slate-800/90 shrink-0">
        <span className="text-[8.5px] sm:text-[9px] font-bold text-slate-300 tracking-tight truncate">
          {compact ? t('inst.power') : t('hud.powerControlHeader')}
        </span>
        <span
          className={`px-1.5 py-0.2 rounded border text-[9.5px] sm:text-[10.5px] font-extrabold leading-tight ${
            pct > 90
              ? 'bg-orange-950/90 border-orange-400/80 text-orange-200'
              : pct > 0
                ? 'bg-amber-950/90 border-amber-400/75 text-amber-300'
                : 'bg-slate-950 border-slate-700 text-slate-300'
          }`}
        >
          {pct}%
        </span>
      </div>

      {/* Interactive Pointer-Captured Graduated Throttle Track */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="flex-1 w-full min-h-0 touch-none cursor-ns-resize"
      >
        <svg
          ref={svgRef}
          viewBox={`0 0 ${svgW} ${svgH}`}
          className="w-full h-full block pointer-events-none"
        >
          {/* End Regime Labels on Right Margin */}
          <text
            x={svgW - 6}
            y={trackTop + 4}
            textAnchor="end"
            fill="#fbbf24"
            fontSize={compact ? '6.8' : '7.5'}
            fontFamily="JetBrains Mono, monospace"
            fontWeight="700"
          >
            {t('inst.powerMaxTag')}
          </text>
          {!compact && (
            <text
              x={svgW - 6}
              y={trackTop + trackH * 0.5 + 2.5}
              textAnchor="end"
              fill="#94a3b8"
              fontSize="6.8"
              fontFamily="JetBrains Mono, monospace"
              fontWeight="600"
            >
              {t('inst.powerSliderLabel')}
            </text>
          )}
          <text
            x={svgW - 6}
            y={trackBottom + 1}
            textAnchor="end"
            fill="#94a3b8"
            fontSize={compact ? '6.8' : '7.5'}
            fontFamily="JetBrains Mono, monospace"
            fontWeight="700"
          >
            {t('inst.powerIdleTag')}
          </text>

          {/* Graduated Percentage Scale & Tick Marks */}
          {powerMarks.map((m) => {
            const ty = trackBottom - m.val * trackH;
            return (
              <g key={m.val}>
                <line
                  x1={m.major ? 38 : 44}
                  y1={ty}
                  x2={51}
                  y2={ty}
                  stroke={m.val === 1 ? '#f59e0b' : m.major ? '#94a3b8' : '#475569'}
                  strokeWidth={m.major ? '1.1' : '0.8'}
                />
                {m.label && (
                  <text
                    x="35"
                    y={ty + 2.6}
                    textAnchor="end"
                    fill={m.val === 1 ? '#fcd34d' : '#cbd5e1'}
                    fontSize={compact ? '7' : '7.6'}
                    fontFamily="JetBrains Mono, monospace"
                    fontWeight="600"
                  >
                    {m.label}
                  </text>
                )}
              </g>
            );
          })}

          {/* Recessed Throttle Quadrant Channel */}
          <rect
            x="54"
            y={trackTop}
            width="24"
            height={trackH}
            rx="5"
            fill="#020617"
            stroke="#334155"
            strokeWidth="1.2"
          />

          {/* Illuminated Engine Power Fill */}
          {fillH > 0.5 && (
            <rect
              x="56"
              y={handleY}
              width="20"
              height={Math.max(0, fillH)}
              rx="3.5"
              fill={pct > 90 ? '#f97316' : '#f59e0b'}
              opacity="0.88"
            />
          )}

          {/* Large Tactile Throttle Lever Handle */}
          <g transform={`translate(0 ${handleY.toFixed(1)})`}>
            <rect
              x="44"
              y="-6.5"
              width="44"
              height="13"
              rx="4"
              fill={pct > 90 ? '#fb923c' : '#fbbf24'}
              stroke="#0f172a"
              strokeWidth="1.3"
            />
            <line x1="51" y1="-2" x2="81" y2="-2" stroke="#0f172a" strokeWidth="1.2" strokeLinecap="round" />
            <line x1="51" y1="2" x2="81" y2="2" stroke="#0f172a" strokeWidth="1.2" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
};

/**
 * 12. COMPACT COCKPIT WIND VECTOR INDICATOR
 *     Displays wind direction (0..359°), speed (kt), rotating vector relative to heading, and head/crosswind effect.
 */
export const WindIndicatorBadge: React.FC<{
  windDirectionDeg: number;
  windSpeedKt: number;
  headingDeg: number;
  headwindKt: number;
  crosswindKt: number;
  compact?: boolean;
}> = ({
  windDirectionDeg,
  windSpeedKt,
  headingDeg,
  headwindKt,
  crosswindKt,
  compact = false,
}) => {
  const { lang, t } = useI18n();
  const arrowBlowDeg = (windDirectionDeg + 180 - headingDeg + 360) % 360;
  const normDir = String(Math.round(((windDirectionDeg % 360) + 360) % 360)).padStart(3, '0');
  const spd = Math.round(windSpeedKt);
  const crossLbl =
    lang === 'en'
      ? 'Xwind'
      : lang === 'fr'
        ? 'Trav'
        : lang === 'de'
          ? 'Seite'
          : lang === 'es'
            ? 'Cruz'
            : 'Trav';

  if (compact) {
    return (
      <div
        className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded border border-slate-700 bg-slate-950/90 font-mono tabular-nums text-[9.5px] text-slate-200 shrink-0"
        title={t('inst.windTitle', { dir: normDir, spd })}
      >
        <svg viewBox="0 0 20 20" className="w-3.5 h-3.5 shrink-0">
          <circle cx="10" cy="10" r="8.5" fill="#020617" stroke="#334155" strokeWidth="1.2" />
          <g transform={`rotate(${arrowBlowDeg.toFixed(1)} 10 10)`}>
            <line x1="10" y1="15" x2="10" y2="5" stroke="#38bdf8" strokeWidth="1.8" strokeLinecap="round" />
            <polygon points="10,3.2 7.5,7.4 12.5,7.4" fill="#38bdf8" />
          </g>
        </svg>
        <span className="font-bold text-sky-300">{normDir}°/{spd}kt</span>
      </div>
    );
  }

  return (
    <div
      className="flex items-center justify-between gap-2 px-2 py-1 rounded-lg border border-slate-800 bg-slate-950/90 font-mono tabular-nums text-[9.5px]"
      title={t('inst.windTitle', { dir: normDir, spd })}
    >
      <div className="flex items-center gap-1.5">
        <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0">
          <circle cx="12" cy="12" r="10.5" fill="#020617" stroke="#334155" strokeWidth="1.3" />
          <g transform={`rotate(${arrowBlowDeg.toFixed(1)} 12 12)`}>
            <line x1="12" y1="18.5" x2="12" y2="6" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
            <polygon points="12,3.8 9,8.8 15,8.8" fill="#38bdf8" />
          </g>
        </svg>
        <div className="leading-tight">
          <div className="text-[8px] text-slate-400 uppercase">{t('common.wind')}</div>
          <div className="font-bold text-sky-200">
            {normDir}° / {spd} kt
          </div>
        </div>
      </div>
      <div className="text-right leading-tight text-[8.5px]">
        <div className={headwindKt >= 0 ? 'text-emerald-300 font-semibold' : 'text-amber-300 font-semibold'}>
          {headwindKt >= 0
            ? `${t('inst.windHead')} ${Math.round(headwindKt)}kt`
            : `${t('inst.windTail')} ${Math.abs(Math.round(headwindKt))}kt`}
        </div>
        <div className="text-slate-400">
          {crossLbl} {Math.abs(Math.round(crosswindKt))}kt
        </div>
      </div>
    </div>
  );
};

/**
 * 13. COMPACT COCKPIT NAVIGATION ROUTE DISPLAY (HSI / ND STRIP)
 *     Draws recognizable Italian coastline, airports, optional intermediate waypoints,
 *     distinct Career ATC vs Free Flight route line with directional chevron, and live aircraft icon.
 */
export const MiniCockpitRouteMap: React.FC<{
  acWorldXM: number;
  acWorldYM: number;
  headingDeg: number;
  targetAirportId: string;
  routeCode: string;
  bearingDeg: number;
  isCareerMode?: boolean;
  waypointIds?: string[];
  onClick?: () => void;
}> = ({
  acWorldXM,
  acWorldYM,
  headingDeg,
  targetAirportId,
  routeCode,
  bearingDeg,
  isCareerMode = false,
  waypointIds = [],
  onClick,
}) => {
  const W = 240;
  const H = 52;

  const toMapXYRaw = (wx: number, wy: number) => ({
    x: 12 + ((wx + 12000) / 146000) * (W - 24),
    y: H - 7 - ((wy + 34000) / 66000) * (H - 18),
  });

  const toMapXY = (wx: number, wy: number) => {
    const p = toMapXYRaw(wx, wy);
    return {
      x: Math.max(7, Math.min(W - 7, p.x)),
      y: Math.max(12, Math.min(H - 6, p.y)),
    };
  };

  const coastPointsAttr = ITALY_MAINLAND_POLYGON.map((pt) => {
    const p = toMapXYRaw(pt.x, pt.y);
    return `${p.x.toFixed(1)},${p.y.toFixed(1)}`;
  }).join(' ');

  const targetAp = AIRPORTS.find((a) => a.id === targetAirportId) || AIRPORTS[0];
  const acPt = toMapXY(acWorldXM, acWorldYM);
  const dstPt = toMapXY(targetAp.worldXM, targetAp.worldYM);

  const wptNodes = isCareerMode
    ? []
    : waypointIds
        .map((id) => getWaypointById(id))
        .filter((w): w is NonNullable<typeof w> => Boolean(w))
        .map((w) => ({ ...w, pt: toMapXY(w.x, w.y) }));

  const routeChain = [acPt, ...wptNodes.map((w) => w.pt), dstPt];
  const routePolyline = routeChain.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');

  // Midpoint directional arrow on the primary leg
  const legStart = routeChain[0];
  const legEnd = routeChain[1] || dstPt;
  const midX = (legStart.x + legEnd.x) * 0.5;
  const midY = (legStart.y + legEnd.y) * 0.5;
  const legAngleDeg = (Math.atan2(legEnd.y - legStart.y, legEnd.x - legStart.x) * 180) / Math.PI;

  const { t } = useI18n();
  const primaryStroke = isCareerMode ? '#e879f9' : '#10b981';
  const accentTextFill = isCareerMode ? '#f5d0fe' : '#34d399';

  return (
    <div
      onClick={onClick}
      className={`w-full h-[50px] rounded-lg border overflow-hidden select-none transition-colors duration-150 ${
        isCareerMode
          ? 'border-fuchsia-500/40 hover:border-fuchsia-400/75'
          : 'border-slate-700/90 hover:border-sky-400/75'
      } bg-[#040c18] ${onClick ? 'cursor-pointer' : ''}`}
      title={onClick ? t('inst.miniMapTitle') : t('inst.miniMapLockedTitle')}
    >
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-full block">
        <rect x="0" y="0" width={W} height={H} fill="#040c18" />

        {/* Mini Italian Coastline Silhouette */}
        <polygon
          points={coastPointsAttr}
          fill="#0f1f33"
          stroke="#1e3a5f"
          strokeWidth="0.7"
        />

        {/* Subtle Graticule Lines */}
        <line x1="0" y1={H * 0.54} x2={W} y2={H * 0.54} stroke="#1e293b" strokeWidth="0.5" strokeDasharray="2 2" />
        <line x1={W * 0.34} y1="10" x2={W * 0.34} y2={H} stroke="#1e293b" strokeWidth="0.5" strokeDasharray="2 2" />
        <line x1={W * 0.67} y1="10" x2={W * 0.67} y2={H} stroke="#1e293b" strokeWidth="0.5" strokeDasharray="2 2" />

        {/* Top Header Strip */}
        <rect x="0" y="0" width={W} height="10.5" fill="#020617" fillOpacity="0.86" />
        <text
          x="5"
          y="7.8"
          fill={isCareerMode ? '#fbbf24' : '#94a3b8'}
          fontSize="6.4"
          fontFamily="JetBrains Mono, monospace"
          fontWeight="700"
        >
          {isCareerMode ? `ATC ${routeCode}` : routeCode}
        </text>
        <text
          x={W - 5}
          y="7.8"
          textAnchor="end"
          fill={accentTextFill}
          fontSize="6.5"
          fontFamily="JetBrains Mono, monospace"
          fontWeight="700"
        >
          {String(bearingDeg).padStart(3, '0')}° → {targetAp.icao}
        </text>

        {/* Career IFR Airway Casing vs Free Flight Route */}
        {isCareerMode && (
          <polyline
            points={routePolyline}
            fill="none"
            stroke="#f59e0b"
            strokeOpacity="0.28"
            strokeWidth="4.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}
        <polyline
          points={routePolyline}
          fill="none"
          stroke={primaryStroke}
          strokeWidth="1.6"
          strokeDasharray={isCareerMode ? undefined : '4 2.2'}
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Directional Midpoint Chevron */}
        {Math.hypot(legEnd.x - legStart.x, legEnd.y - legStart.y) > 14 && (
          <g transform={`translate(${midX.toFixed(1)} ${midY.toFixed(1)}) rotate(${legAngleDeg.toFixed(1)})`}>
            <polygon points="3.2,0 -2.2,-2.3 -1,0 -2.2,2.3" fill={primaryStroke} />
          </g>
        )}

        {/* Intermediate Waypoints */}
        {wptNodes.map((w) => (
          <polygon
            key={w.id}
            points={`${w.pt.x},${w.pt.y - 2.6} ${w.pt.x + 2.4},${w.pt.y + 1.8} ${w.pt.x - 2.4},${w.pt.y + 1.8}`}
            fill="#22d3ee"
            stroke="#020617"
            strokeWidth="0.5"
          />
        ))}

        {/* World Airports Fixes */}
        {AIRPORTS.map((ap) => {
          const p = toMapXY(ap.worldXM, ap.worldYM);
          const isDst = ap.id === targetAirportId;
          return (
            <g key={ap.id}>
              <circle
                cx={p.x}
                cy={p.y}
                r={isDst ? '3' : '1.6'}
                fill={isDst ? primaryStroke : '#38bdf8'}
                fillOpacity={isDst ? '1' : '0.65'}
              />
              {isDst && (
                <circle
                  cx={p.x}
                  cy={p.y}
                  r="5.2"
                  fill="none"
                  stroke={primaryStroke}
                  strokeWidth="0.85"
                  opacity="0.85"
                />
              )}
            </g>
          );
        })}

        {/* Aircraft Live Position Symbol */}
        <g transform={`translate(${acPt.x.toFixed(1)} ${acPt.y.toFixed(1)}) rotate(${headingDeg.toFixed(1)})`}>
          <polygon
            points="0,-4.6 3.5,3.4 0,1.7 -3.5,3.4"
            fill="#fbbf24"
            stroke="#020617"
            strokeWidth="0.65"
          />
        </g>
      </svg>
    </div>
  );
};


