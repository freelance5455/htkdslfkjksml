import React, { useEffect, useRef, useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  ChevronsDown,
  ChevronsUp,
  CircleDot,
  Compass,
  Eye,
  Lock,
  Map as MapIcon,
  Minus,
  Navigation,
  OctagonAlert,
  Pause,
  Plus,
  Radio,
  Settings,
  SlidersHorizontal,
  Snowflake,
  Sparkles,
  Volume2,
  VolumeX,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { AIRPORTS } from '../data/airports';
import { useI18n } from '../i18n/I18nContext';
import {
  localizeAtcMessage,
  localizeAtisNotice,
  localizeFlightAssistantAdvisory,
  localizeFlightPhase,
  localizeWeatherType,
} from '../i18n/localizeGameData';
import {
  AircraftSpec,
  CameraMode,
  CareerAtcAssignment,
  ControlMode,
  DescentGuidanceStage,
  FlightPhysicsState,
  GameSettings,
  LanguageCode,
} from '../types/game';
import {
  AirspeedDial,
  AltimeterDial,
  AttitudeDial,
  DescentProfileDisplay,
  EngineTachAndGauges,
  HeadingCompassDial,
  MiniCockpitRouteMap,
  PitchControlSlider,
  PowerControlSlider,
  VerticalSpeedDial,
  WindIndicatorBadge,
} from './CockpitInstruments';

type FlightPhaseId = 'TAKEOFF' | 'CRUISE' | 'DESCENT' | 'FINAL' | 'ROLLOUT';

interface FlightPhaseContext {
  id: FlightPhaseId;
  cue: string;
  badgeCls: string;
  focus: {
    airspeed: boolean;
    attitude: boolean;
    altimeter: boolean;
    vsi: boolean;
    compass: boolean;
    engine: boolean;
    fuel: boolean;
    autopilot: boolean;
    navigation: boolean;
    profile: boolean;
    flaps: boolean;
    gear: boolean;
    brakes: boolean;
  };
}

function formatSelectedAltFt(altFt: number): string {
  const rounded = Math.max(0, Math.round(altFt));
  return `${rounded.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')} FT`;
}

function formatEta(etaSeconds: number | null, lang: LanguageCode): string {
  if (etaSeconds === null || !Number.isFinite(etaSeconds)) return '--:--';
  if (etaSeconds <= 0) {
    return lang === 'en'
      ? 'THRESH'
      : lang === 'fr'
        ? 'SEUIL'
        : lang === 'de'
          ? 'SCHWELLE'
          : lang === 'es'
            ? 'UMBRAL'
            : 'SOGLIA';
  }
  if (etaSeconds >= 3600) {
    const h = Math.floor(etaSeconds / 3600);
    const m = Math.floor((etaSeconds % 3600) / 60);
    return `${h}h ${String(m).padStart(2, '0')}m`;
  }
  const m = Math.floor(etaSeconds / 60);
  const s = etaSeconds % 60;
  return `${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`;
}

function getStageDisplay(
  stage: DescentGuidanceStage,
  lang: LanguageCode
): {
  label: string;
  shortLabel: string;
  lampCls: string;
} {
  const map: Record<
    DescentGuidanceStage,
    Record<LanguageCode, { label: string; shortLabel: string }>
  > = {
    HOLD_ALTITUDE: {
      it: { label: 'MANTIENI QUOTA', shortLabel: 'MANTIENI QUOTA' },
      en: { label: 'HOLD ALTITUDE', shortLabel: 'HOLD ALT' },
      fr: { label: 'MAINTENIR ALT.', shortLabel: 'MAINT. ALT.' },
      de: { label: 'HÖHE HALTEN', shortLabel: 'HÖHE HALTEN' },
      es: { label: 'MANTENER ALT.', shortLabel: 'MANT. ALT.' },
    },
    BEGIN_DESCENT: {
      it: { label: 'INIZIA DISCESA', shortLabel: 'INIZIA DISCESA' },
      en: { label: 'BEGIN DESCENT', shortLabel: 'DESCEND' },
      fr: { label: 'DÉBUT DESCENTE', shortLabel: 'DESCENDRE' },
      de: { label: 'SINKFLUG STARTEN', shortLabel: 'SINKFLUG' },
      es: { label: 'INICIAR DESCENSO', shortLabel: 'DESCENDER' },
    },
    FINAL_APPROACH: {
      it: { label: 'AVVICINAMENTO FINALE', shortLabel: 'FINALE' },
      en: { label: 'FINAL APPROACH', shortLabel: 'FINAL' },
      fr: { label: 'APPROCHE FINALE', shortLabel: 'FINALE' },
      de: { label: 'ENDANFLUG', shortLabel: 'ENDANFLUG' },
      es: { label: 'APROXIMACIÓN FINAL', shortLabel: 'FINAL' },
    },
    LANDED: {
      it: { label: 'IN PISTA · FRENA', shortLabel: 'IN PISTA' },
      en: { label: 'ON RUNWAY · BRAKE', shortLabel: 'ON RUNWAY' },
      fr: { label: 'SUR PISTE · FREINEZ', shortLabel: 'SUR PISTE' },
      de: { label: 'AUF PISTE · BREMSEN', shortLabel: 'AUF PISTE' },
      es: { label: 'EN PISTA · FRENA', shortLabel: 'EN PISTA' },
    },
  };
  const txt = map[stage][lang] ?? map[stage].it;
  switch (stage) {
    case 'HOLD_ALTITUDE':
      return { ...txt, lampCls: 'text-sky-200 border-sky-400/75 bg-sky-950/85' };
    case 'BEGIN_DESCENT':
      return { ...txt, lampCls: 'text-amber-200 border-amber-400/90 bg-amber-950/90' };
    case 'FINAL_APPROACH':
      return { ...txt, lampCls: 'text-emerald-200 border-emerald-400/90 bg-emerald-950/90' };
    case 'LANDED':
      return { ...txt, lampCls: 'text-emerald-100 border-emerald-400 bg-emerald-900/90' };
  }
}

function computeFlightPhaseContext(
  st: FlightPhysicsState,
  aircraft: AircraftSpec,
  lang: LanguageCode
): FlightPhaseContext {
  const nav = st.navData;

  if (
    st.onGround &&
    st.hasTakenOff &&
    (nav.guidanceStage === 'LANDED' || Math.abs(nav.distanceToRunwayM) < 2600)
  ) {
    const cue =
      lang === 'en'
        ? 'Idle power · Hold BRAKES'
        : lang === 'fr'
          ? 'Réduisez les gaz · Maintenez FREINS'
          : lang === 'de'
            ? 'Leerlauf · BREMSEN gedrückt halten'
            : lang === 'es'
              ? 'Reduce potencia · Mantén pulsado FRENOS'
              : 'Riduci potenza · Tieni premuto FRENI';
    return {
      id: 'ROLLOUT',
      cue,
      badgeCls: 'bg-emerald-950/90 border-emerald-400/80 text-emerald-200',
      focus: {
        airspeed: true,
        attitude: false,
        altimeter: false,
        vsi: false,
        compass: false,
        engine: true,
        fuel: false,
        autopilot: false,
        navigation: true,
        profile: false,
        flaps: false,
        gear: false,
        brakes: true,
      },
    };
  }

  if (
    st.onGround ||
    (st.aglFt < 550 && nav.guidanceStage === 'HOLD_ALTITUDE' && st.vsiFpm >= -150)
  ) {
    const needGearUp =
      !st.onGround && !aircraft.fixedGear && st.gearTargetDown && st.aglFt > 140;
    const cue = st.onGround
      ? lang === 'en'
        ? 'Full throttle · Rotate smoothly at Vr'
        : lang === 'fr'
          ? 'Pleins gaz · Cabrez doucement à Vr'
          : lang === 'de'
            ? 'Vollschub · Sanft bei Vr rotieren'
            : lang === 'es'
              ? 'Máxima potencia · Encabrita suave en Vr'
              : 'Accelera al massimo · Cabra dolcemente a Vr'
      : lang === 'en'
        ? 'Initial climb · Monitor airspeed and landing gear'
        : lang === 'fr'
          ? 'Montée initiale · Surveillez vitesse et train'
          : lang === 'de'
            ? 'Anfangssteigflug · Fahrt und Fahrwerk prüfen'
            : lang === 'es'
              ? 'Ascenso inicial · Vigila velocidad y tren'
              : 'Salita iniziale · Controlla velocità e carrello';
    return {
      id: 'TAKEOFF',
      cue,
      badgeCls: 'bg-amber-950/90 border-amber-400/80 text-amber-200',
      focus: {
        airspeed: true,
        attitude: true,
        altimeter: false,
        vsi: true,
        compass: false,
        engine: true,
        fuel: false,
        autopilot: false,
        navigation: false,
        profile: false,
        flaps: true,
        gear: needGearUp,
        brakes: false,
      },
    };
  }

  if (nav.guidanceStage === 'FINAL_APPROACH') {
    const cue =
      lang === 'en'
        ? `Hold Vref ${nav.vRefKt}kt · Flaps extended · Gear down`
        : lang === 'fr'
          ? `Maintenez Vref ${nav.vRefKt}kt · Volets sortis · Train bas`
          : lang === 'de'
            ? `Vref ${nav.vRefKt}kt halten · Klappen raus · Fahrwerk raus`
            : lang === 'es'
              ? `Mantén Vref ${nav.vRefKt}kt · Flaps extendidos · Tren abajo`
              : `Mantieni Vref ${nav.vRefKt}kt · Flap estesi · Carrello giù`;
    return {
      id: 'FINAL',
      cue,
      badgeCls: 'bg-emerald-950/90 border-emerald-400/85 text-emerald-200',
      focus: {
        airspeed: true,
        attitude: true,
        altimeter: false,
        vsi: true,
        compass: false,
        engine: false,
        fuel: false,
        autopilot: false,
        navigation: true,
        profile: true,
        flaps: true,
        gear: true,
        brakes: false,
      },
    };
  }

  if (nav.guidanceStage === 'BEGIN_DESCENT') {
    const cue = st.apEnabled
      ? lang === 'en'
        ? 'Disengage Autopilot or lower selected altitude'
        : lang === 'fr'
          ? 'Désactivez le Pilote Auto ou réduisez l’altitude'
          : lang === 'de'
            ? 'Autopilot ausschalten oder Zielhöhe senken'
            : lang === 'es'
              ? 'Desactiva Piloto Auto o reduce altitud seleccionada'
              : 'Disattiva Autopilota o riduci quota selezionata'
      : lang === 'en'
        ? `Descend smoothly (${nav.recommendedVsiFpm} fpm) toward ${nav.targetProfileAltFt} ft`
        : lang === 'fr'
          ? `Descendez progressivement (${nav.recommendedVsiFpm} fpm) vers ${nav.targetProfileAltFt} ft`
          : lang === 'de'
            ? `Sanft sinken (${nav.recommendedVsiFpm} fpm) auf ${nav.targetProfileAltFt} ft`
            : lang === 'es'
              ? `Desciende suave (${nav.recommendedVsiFpm} fpm) hacia ${nav.targetProfileAltFt} ft`
              : `Scendi gradualmente (${nav.recommendedVsiFpm} fpm) verso ${nav.targetProfileAltFt} ft`;
    return {
      id: 'DESCENT',
      cue,
      badgeCls: 'bg-amber-950/90 border-amber-400/85 text-amber-200',
      focus: {
        airspeed: false,
        attitude: false,
        altimeter: true,
        vsi: true,
        compass: false,
        engine: false,
        fuel: false,
        autopilot: st.apEnabled,
        navigation: true,
        profile: true,
        flaps: false,
        gear: false,
        brakes: false,
      },
    };
  }

  const cue = st.apEnabled
    ? lang === 'en'
      ? `Autopilot hold ${formatSelectedAltFt(st.apTargetAltFt)} · Manage throttle`
      : lang === 'fr'
        ? `Pilote Auto ${formatSelectedAltFt(st.apTargetAltFt)} · Gérez la puissance`
        : lang === 'de'
          ? `Autopilot ${formatSelectedAltFt(st.apTargetAltFt)} · Schub regeln`
          : lang === 'es'
            ? `Piloto Auto ${formatSelectedAltFt(st.apTargetAltFt)} · Gestiona potencia`
            : `Autopilota quota ${formatSelectedAltFt(st.apTargetAltFt)} · Gestisci potenza`
    : lang === 'en'
      ? 'Trim level flight or engage AUTOPILOT ON'
      : lang === 'fr'
        ? 'Stabilisez le palier ou activez PILOTE AUTO'
        : lang === 'de'
          ? 'Flughöhe halten oder AUTOPILOT aktivieren'
          : lang === 'es'
            ? 'Estabiliza altitud o activa PILOTO AUTO'
            : 'Stabilizza quota o attiva AUTOPILOT ON';

  return {
    id: 'CRUISE',
    cue,
    badgeCls: 'bg-sky-950/90 border-sky-400/80 text-sky-200',
    focus: {
      airspeed: true,
      attitude: false,
      altimeter: true,
      vsi: false,
      compass: true,
      engine: false,
      fuel: true,
      autopilot: true,
      navigation: false,
      profile: false,
      flaps: false,
      gear: false,
      brakes: false,
    },
  };
}

export interface FlightHUDProps {
  hudState: FlightPhysicsState;
  aircraft: AircraftSpec;
  isCareerMode: boolean;
  atcAssignment?: CareerAtcAssignment;
  waypointIds?: string[];
  cameraMode: CameraMode;
  userZoom: number;
  simSpeed: 1 | 2 | 4;
  settings: GameSettings;
  activePitchDir: -1 | 0 | 1;
  activeThrottleDir: -1 | 0 | 1;
  onPitchMove: (pitch: number) => void;
  onSetElevator: (val: number) => void;
  onPitchSliderHoldChange: (held: boolean) => void;
  onHoldPitchButton: (dir: -1 | 0 | 1) => void;
  onHoldThrottleButton: (dir: -1 | 0 | 1) => void;
  onSetThrottle: (val: number) => void;
  onChangeControlMode: (mode: ControlMode) => void;
  onToggleAutopilot: () => void;
  onAdjustAutopilotAlt: (deltaFt: number) => void;
  onAdjustFlaps: (delta: -1 | 1) => void;
  onCycleFlaps: () => void;
  onToggleGear: () => void;
  onToggleDeIce: () => void;
  onSetBrakes: (active: boolean) => void;
  onCycleCamera: () => void;
  onAdjustZoom: (delta: number) => void;
  onCycleSimSpeed: () => void;
  onSelectTargetAirport: (airportId: string) => void;
  onOpenInteractiveMap: () => void;
  onOpenAtcBriefing?: () => void;
  onToggleMute: () => void;
  onOpenSettings: () => void;
  onPause: () => void;
}

export const FlightHUD: React.FC<FlightHUDProps> = ({
  hudState,
  aircraft,
  isCareerMode,
  atcAssignment,
  waypointIds = [],
  cameraMode,
  simSpeed,
  settings,
  activePitchDir,
  activeThrottleDir,
  onSetElevator,
  onPitchSliderHoldChange,
  onHoldPitchButton,
  onHoldThrottleButton,
  onSetThrottle,
  onChangeControlMode,
  onToggleAutopilot,
  onAdjustAutopilotAlt,
  onAdjustFlaps,
  onToggleGear,
  onToggleDeIce,
  onSetBrakes,
  onCycleCamera,
  onAdjustZoom,
  onCycleSimSpeed,
  onSelectTargetAirport,
  onOpenInteractiveMap,
  onOpenAtcBriefing,
  onToggleMute,
  onOpenSettings,
  onPause,
}) => {
  const { lang, t } = useI18n();
  const isLargeButtons = settings.buttonSize === 'large';
  const [flapPressedDir, setFlapPressedDir] = useState<-1 | 0 | 1>(0);
  const [gearPressed, setGearPressed] = useState(false);
  const [apAltHeldDir, setApAltHeldDir] = useState<-1 | 0 | 1>(0);

  const apHoldDelayRef = useRef<number | null>(null);
  const apHoldIntervalRef = useRef<number | null>(null);
  const onAdjustAutopilotAltRef = useRef(onAdjustAutopilotAlt);
  onAdjustAutopilotAltRef.current = onAdjustAutopilotAlt;

  const stopApAltHold = () => {
    if (apHoldDelayRef.current !== null) {
      window.clearTimeout(apHoldDelayRef.current);
      apHoldDelayRef.current = null;
    }
    if (apHoldIntervalRef.current !== null) {
      window.clearInterval(apHoldIntervalRef.current);
      apHoldIntervalRef.current = null;
    }
    setApAltHeldDir(0);
  };

  useEffect(() => {
    return () => {
      if (apHoldDelayRef.current !== null) window.clearTimeout(apHoldDelayRef.current);
      if (apHoldIntervalRef.current !== null) window.clearInterval(apHoldIntervalRef.current);
    };
  }, []);

  const bindHoldApAlt = (dir: -1 | 1) => ({
    onPointerDown: (e: React.PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // Synthetic pointer fallback
      }
      stopApAltHold();
      setApAltHeldDir(dir);
      onAdjustAutopilotAltRef.current(dir * 100);
      apHoldDelayRef.current = window.setTimeout(() => {
        apHoldIntervalRef.current = window.setInterval(() => {
          onAdjustAutopilotAltRef.current(dir * 100);
        }, 85);
      }, 250);
    },
    onPointerUp: stopApAltHold,
    onPointerCancel: stopApAltHold,
    onLostPointerCapture: stopApAltHold,
    onKeyDown: (e: React.KeyboardEvent<HTMLButtonElement>) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        onAdjustAutopilotAltRef.current(dir * 100);
      }
    },
  });

  const isSlidersMode = settings.controlMode === 'sliders';
  const nav = hudState.navData;
  const liveWx = hudState.liveWeather;
  const icingPct = Math.round(liveWx.icingLevel * 100);
  const canEngageAp = !hudState.onGround && hudState.aglFt >= 40 && !hudState.crashed;
  const formattedApAlt = formatSelectedAltFt(hudState.apTargetAltFt);
  const apAltDiffFt = hudState.apTargetAltFt - hudState.altitudeFt;
  const apVerticalStatus = !hudState.apEnabled
    ? 'Manuale'
    : apAltDiffFt > 45
      ? `Sale → ${formattedApAlt}`
      : apAltDiffFt < -45
        ? `Scende → ${formattedApAlt}`
        : `Mantiene ${formattedApAlt}`;

  const stageInfo = getStageDisplay(nav.guidanceStage);
  const phase = computeFlightPhaseContext(hudState, aircraft);

  const throttlePct = Math.max(0, Math.min(100, Math.round(hudState.throttle * 100)));
  const isCabraPressed = activePitchDir === 1;
  const isPicchiaPressed = activePitchDir === -1;
  const isAcceleraPressed = activeThrottleDir === 1;
  const isRiduciPressed = activeThrottleDir === -1;

  const gearStatusLabel = aircraft.fixedGear
    ? 'FISSO'
    : hudState.gearDamaged
      ? 'DANNO'
      : hudState.gearJammed
        ? 'BLOCC'
        : hudState.gearPosition >= 0.98
          ? 'GIÙ'
          : hudState.gearPosition <= 0.02
            ? 'SU'
            : 'MOVIM';

  const gearDownLocked =
    aircraft.fixedGear || (hudState.gearPosition >= 0.98 && !hudState.gearDamaged);
  const gearLedCls =
    hudState.gearDamaged || hudState.gearJammed
      ? 'bg-red-500'
      : gearDownLocked
        ? 'bg-emerald-400'
        : hudState.gearPosition <= 0.02
          ? 'bg-slate-600'
          : 'bg-amber-400';

  const bindHoldPitch = (dir: -1 | 1) => ({
    onPointerDown: (e: React.PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // Synthetic pointer fallback
      }
      onHoldPitchButton(dir);
    },
    onPointerUp: () => onHoldPitchButton(0),
    onPointerCancel: () => onHoldPitchButton(0),
    onLostPointerCapture: () => onHoldPitchButton(0),
  });

  const bindHoldThrottle = (dir: -1 | 1) => ({
    onPointerDown: (e: React.PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // Synthetic pointer fallback
      }
      onHoldThrottleButton(dir);
    },
    onPointerUp: () => onHoldThrottleButton(0),
    onPointerCancel: () => onHoldThrottleButton(0),
    onLostPointerCapture: () => onHoldThrottleButton(0),
  });

  const bindHoldBrakes = {
    onPointerDown: (e: React.PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // Synthetic pointer fallback
      }
      onSetBrakes(true);
    },
    onPointerUp: () => onSetBrakes(false),
    onPointerCancel: () => onSetBrakes(false),
    onLostPointerCapture: () => onSetBrakes(false),
  };

  const hudLocal = {
    it: {
      stall: 'STALLO',
      sink: 'RATEO VSI',
      altLow: 'QUOTA BASSA',
      altHigh: 'QUOTA ALTA',
      glide: 'SENTIERO',
      spdLow: 'VEL. BASSA',
      spdHigh: 'VEL. ALTA',
      ice: 'GHIACCIO',
      engFail: 'MOTORE KO',
      lowFuel: 'RISERVA CARB.',
      phasePrefix: 'FASE:',
      emergPrefix: 'EMERGENZA:',
      emEng: 'Avaria Motore — Mantieni assetto di planata verso la pista',
      emGear: 'Carrello Bloccato — Prepara atterraggio a bassa velocità',
      emPwr: 'Perdita Parziale Potenza Motore',
      highShort: 'ALTA',
      lowShort: 'BASSA',
      retractShort: 'Ritrai',
      atcChartBtn: 'CARTA ATC',
      mapKeyBtn: 'MAPPA [M]',
      cursShort: 'CURS',
      pulsShort: 'PULS',
      simSpdTitle: 'Velocità Simulazione (1x / 2x / 4x in crociera)',
    },
    en: {
      stall: 'STALL',
      sink: 'SINK RATE',
      altLow: 'TOO LOW',
      altHigh: 'TOO HIGH',
      glide: 'GLIDESLOPE',
      spdLow: 'LOW SPEED',
      spdHigh: 'HIGH SPEED',
      ice: 'WING ICE',
      engFail: 'ENG FAIL',
      lowFuel: 'LOW FUEL',
      phasePrefix: 'PHASE:',
      emergPrefix: 'EMERGENCY:',
      emEng: 'Engine Failure — Maintain best glide attitude toward the runway',
      emGear: 'Landing Gear Jammed — Prepare for low-speed touchdown',
      emPwr: 'Partial Engine Power Loss',
      highShort: 'HIGH',
      lowShort: 'LOW',
      retractShort: 'Retract',
      atcChartBtn: 'ATC CHART',
      mapKeyBtn: 'CHART [M]',
      cursShort: 'SLID',
      pulsShort: 'BTNS',
      simSpdTitle: 'Simulation Speed (1x / 2x / 4x in cruise)',
    },
    fr: {
      stall: 'DÉCROCHAGE',
      sink: 'TAUX CHUTE',
      altLow: 'TROP BAS',
      altHigh: 'TROP HAUT',
      glide: 'PLAN 3°',
      spdLow: 'VIT. BASSE',
      spdHigh: 'VIT. HAUTE',
      ice: 'GIVRAGE',
      engFail: 'PANNE MOT.',
      lowFuel: 'RÉSERVE CARB.',
      phasePrefix: 'PHASE :',
      emergPrefix: 'URGENCE :',
      emEng: 'Panne Moteur — Maintenez la finesse max vers la piste',
      emGear: 'Train Bloqué — Préparez un toucher à basse vitesse',
      emPwr: 'Perte Partielle de Puissance Moteur',
      highShort: 'HAUTE',
      lowShort: 'BASSE',
      retractShort: 'Rentrer',
      atcChartBtn: 'CARTE ATC',
      mapKeyBtn: 'CARTE [M]',
      cursShort: 'CURS',
      pulsShort: 'BOUT',
      simSpdTitle: 'Vitesse Simulation (1x / 2x / 4x en croisière)',
    },
    de: {
      stall: 'ABRISS',
      sink: 'SINKRATE',
      altLow: 'ZU TIEF',
      altHigh: 'ZU HOCH',
      glide: 'GLEITPFAD',
      spdLow: 'ZU LANGSAM',
      spdHigh: 'ZU SCHNELL',
      ice: 'VEREISUNG',
      engFail: 'TRIEBWERK KO',
      lowFuel: 'TANKRESERVE',
      phasePrefix: 'PHASE:',
      emergPrefix: 'NOTFALL:',
      emEng: 'Triebwerksausfall — Gleitflug zur Piste beibehalten',
      emGear: 'Fahrwerk Blockiert — Langsame Landung vorbereiten',
      emPwr: 'Teilweiser Triebwerks-Leistungsverlust',
      highShort: 'HOCH',
      lowShort: 'TIEF',
      retractShort: 'Einfahren',
      atcChartBtn: 'ATC-KARTE',
      mapKeyBtn: 'KARTE [M]',
      cursShort: 'REGL',
      pulsShort: 'TAST',
      simSpdTitle: 'Simulationsgeschwindigkeit (1x / 2x / 4x im Reiseflug)',
    },
    es: {
      stall: 'PÉRDIDA',
      sink: 'DESCENSO',
      altLow: 'MUY BAJO',
      altHigh: 'MUY ALTO',
      glide: 'SENDA',
      spdLow: 'VEL. BAJA',
      spdHigh: 'VEL. ALTA',
      ice: 'HIELO',
      engFail: 'MOTOR KO',
      lowFuel: 'RESERVA COMB.',
      phasePrefix: 'FASE:',
      emergPrefix: 'EMERGENCIA:',
      emEng: 'Fallo de Motor — Mantén actitud de planeo hacia la pista',
      emGear: 'Tren Bloqueado — Prepara aterrizaje a baja velocidad',
      emPwr: 'Pérdida Parcial de Potencia del Motor',
      highShort: 'ALTA',
      lowShort: 'BAJA',
      retractShort: 'Retraer',
      atcChartBtn: 'CARTA ATC',
      mapKeyBtn: 'MAPA [M]',
      cursShort: 'CURS',
      pulsShort: 'BOT.',
      simSpdTitle: 'Velocidad de Simulación (1x / 2x / 4x en crucero)',
    },
  }[lang];

  // Master Caution / Warning Annunciators
  const annunciators: Array<{
    id: string;
    label: string;
    state: 'off' | 'caution' | 'warning';
  }> = [
    { id: 'stall', label: hudLocal.stall, state: hudState.isStalling ? 'warning' : 'off' },
    { id: 'sink', label: hudLocal.sink, state: hudState.sinkRateWarning ? 'warning' : 'off' },
    {
      id: 'gs',
      label: nav.tooLow ? hudLocal.altLow : nav.tooHigh ? hudLocal.altHigh : hudLocal.glide,
      state: nav.tooLow ? 'warning' : nav.tooHigh ? 'caution' : 'off',
    },
    {
      id: 'spd',
      label: hudState.isOverspeed
        ? 'OVERSPEED'
        : nav.tooSlow
          ? hudLocal.spdLow
          : nav.tooFast
            ? hudLocal.spdHigh
            : t('common.speed').toUpperCase(),
      state:
        hudState.isOverspeed || nav.tooSlow ? 'warning' : nav.tooFast ? 'caution' : 'off',
    },
    {
      id: 'gear',
      label: t('hud.gearLabel'),
      state: nav.gearWarning || hudState.gearDamaged ? 'warning' : 'off',
    },
    {
      id: 'flap',
      label: nav.inFlareWindow ? 'FLARE' : t('hud.flapsLabel'),
      state: nav.flapWarning || nav.inFlareWindow ? 'caution' : 'off',
    },
    {
      id: 'ice',
      label: `${hudLocal.ice} ${icingPct}%`,
      state:
        icingPct > 45 && !liveWx.deIceActive
          ? 'warning'
          : icingPct >= 20 && !liveWx.deIceActive
            ? 'caution'
            : 'off',
    },
    {
      id: 'eng',
      label: hudState.engineFailed ? hudLocal.engFail : hudLocal.lowFuel,
      state: hudState.engineFailed
        ? 'warning'
        : hudState.lowFuelWarning
          ? 'caution'
          : 'off',
    },
  ];

  const activeAlerts = annunciators.filter((a) => a.state !== 'off');

  const curWxName = localizeWeatherType(liveWx.currentType, lang);
  const tgtWxName = localizeWeatherType(liveWx.targetType, lang);
  const wxTransitionLabel =
    liveWx.transitionProgress < 0.92 && liveWx.targetType !== liveWx.currentType
      ? `${curWxName}→${tgtWxName}`
      : curWxName;

  const cameraLabel = t(`cam.${cameraMode}`);

  const emergencyBannerText = hudState.engineFailed
    ? hudLocal.emEng
    : hudState.gearJammed
      ? hudLocal.emGear
      : hudState.enginePowerMultiplier < 0.9
        ? hudLocal.emPwr
        : null;

  const localizedPhaseName = localizeFlightPhase(nav.operationalPhase, lang);
  const localizedAtc = hudState.atcMessage
    ? localizeAtcMessage(hudState.atcMessage, lang)
    : null;
  const localizedAdvisoryText = hudState.assistantAdvisory
    ? localizeFlightAssistantAdvisory(hudState.assistantAdvisory, lang)
    : '';
  const localizedAtis = liveWx.atisNotice ? localizeAtisNotice(liveWx.atisNotice, lang) : '';

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between select-none">
      {/* ===================================================================== */}
      {/* 1. SLIM TOP UTILITY & ANNUNCIATOR BAR (Minimal Vertical Footprint)    */}
      {/* ===================================================================== */}
      <div className="w-full flex flex-col gap-1">
        <header className="pointer-events-auto w-full cockpit-chassis border-b border-slate-800/95 px-2 sm:px-3 py-1 flex items-center justify-between gap-2 font-mono text-[10px] tabular-nums">
          {/* Left: Operational Phase + Active Warnings + Weather */}
          <div className="flex items-center gap-1.5 min-w-0 overflow-hidden">
            <div
              className={`px-2 py-0.5 rounded border font-bold tracking-tight whitespace-nowrap shrink-0 ${phase.badgeCls}`}
              title={phase.cue}
            >
              <span className="hidden sm:inline">
                {hudLocal.phasePrefix} {localizedPhaseName}
              </span>
              <span className="sm:hidden">{localizedPhaseName}</span>
            </div>

            {activeAlerts.length > 0 ? (
              <div className="flex items-center gap-1 overflow-x-auto custom-scroll">
                {activeAlerts.slice(0, 4).map((a) => (
                  <span
                    key={a.id}
                    className={`px-1.5 py-0.5 rounded border font-extrabold text-[9.5px] whitespace-nowrap shrink-0 ${
                      a.state === 'warning'
                        ? 'bg-red-950/95 border-red-400 text-red-100'
                        : 'bg-amber-950/95 border-amber-400 text-amber-200'
                    }`}
                  >
                    {a.label}
                  </span>
                ))}
              </div>
            ) : (
              <span className="hidden xl:inline text-slate-400 truncate max-w-[260px]">
                {phase.cue}
              </span>
            )}

            <div className="hidden md:flex items-center gap-1.5 pl-1 border-l border-slate-800 text-slate-300 shrink-0">
              <span>{wxTransitionLabel}</span>
              <WindIndicatorBadge
                windDirectionDeg={hudState.windDirectionDeg}
                windSpeedKt={hudState.windSpeedKt}
                headingDeg={hudState.headingDeg}
                headwindKt={hudState.currentWindXKt}
                crosswindKt={hudState.currentCrosswindKt}
                compact
              />
            </div>
          </div>

          {/* Right: Compact Secondary Utilities (Time Warp, Camera, Zoom, Audio, Settings ⚙️, Pause) */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={onCycleSimSpeed}
              disabled={hudState.onGround || hudState.aglFt < 350}
              className={`min-h-[32px] px-2 rounded-lg border font-bold transition-colors whitespace-nowrap ${
                simSpeed > 1
                  ? 'bg-amber-500 text-slate-950 border-amber-300 cursor-pointer'
                  : hudState.onGround || hudState.aglFt < 350
                    ? 'bg-slate-900/50 text-slate-600 border-slate-800 cursor-not-allowed'
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border-slate-700 cursor-pointer'
              }`}
              title={hudLocal.simSpdTitle}
            >
              {simSpeed}x
            </button>

            <button
              type="button"
              onClick={onCycleCamera}
              className="hidden sm:flex min-h-[32px] px-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 items-center gap-1 cursor-pointer whitespace-nowrap"
              title={t('hud.cameraCycleTitle')}
            >
              <Eye className="w-3.5 h-3.5 text-sky-400" />
              <span>{cameraLabel}</span>
            </button>

            <div className="hidden md:flex items-center bg-slate-900 border border-slate-700 rounded-lg overflow-hidden">
              <button
                type="button"
                onClick={() => onAdjustZoom(-0.15)}
                className="min-h-[30px] px-1.5 hover:bg-slate-800 text-slate-300 cursor-pointer"
                title={t('hud.zoomOutTitle')}
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onAdjustZoom(0.15)}
                className="min-h-[30px] px-1.5 hover:bg-slate-800 text-slate-300 border-l border-slate-800 cursor-pointer"
                title={t('hud.zoomInTitle')}
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              type="button"
              onClick={onToggleMute}
              className="min-h-[32px] min-w-[32px] px-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 flex items-center justify-center cursor-pointer"
              title={t('hud.muteTitle')}
            >
              {settings.soundEnabled ? (
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <VolumeX className="w-3.5 h-3.5 text-slate-500" />
              )}
            </button>

            <button
              type="button"
              onClick={onOpenSettings}
              className="min-h-[32px] px-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-sky-500/60 text-sky-200 font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
              title={t('hud.settingsTitle')}
            >
              <Settings className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden md:inline">{t('common.settings')}</span>
            </button>

            <button
              type="button"
              onClick={onPause}
              className="min-h-[32px] px-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-600 text-white font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
              title={`${t('hud.pauseBtn')} [Esc]`}
            >
              <Pause className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{t('hud.pauseBtn')}</span>
            </button>
          </div>
        </header>

        {/* SMARTPHONE / TABLET COMPACT NAVIGATION & LANDING ASSIST BAR (< 1024px) */}
        <div className="lg:hidden pointer-events-auto mx-1.5 sm:mx-2.5 rounded-xl border border-slate-700/85 cockpit-glass px-2 py-1 font-mono text-[9.5px] sm:text-[10px] tabular-nums flex flex-col gap-1">
          <div className="flex items-center justify-between gap-1.5">
            {/* Mobile Group: NAVIGAZIONE */}
            <div className="flex items-center gap-1 min-w-0">
              {isCareerMode ? (
                <div className="flex items-center gap-1 bg-slate-950/90 border border-fuchsia-500/50 rounded-md px-1.5 py-0.5 min-w-0">
                  <Lock className="w-3 h-3 text-fuchsia-400 shrink-0" />
                  <span className="font-bold text-fuchsia-200 truncate">
                    {nav.airportIcao} · RWY {nav.runwayId}
                  </span>
                </div>
              ) : (
                <select
                  aria-label={t('common.destination')}
                  value={hudState.targetAirportId}
                  onChange={(e) => onSelectTargetAirport(e.target.value)}
                  className="min-h-[30px] bg-slate-950 border border-slate-700 rounded-md px-1.5 text-emerald-300 font-bold text-[10px] max-w-[116px] sm:max-w-[160px]"
                >
                  {AIRPORTS.map((ap) => (
                    <option key={ap.id} value={ap.id} className="bg-slate-950 text-white">
                      {ap.icao} · {ap.city}
                    </option>
                  ))}
                </select>
              )}

              <button
                type="button"
                onClick={onOpenInteractiveMap}
                className={`min-h-[30px] px-2 rounded-md border font-bold flex items-center gap-1 shrink-0 whitespace-nowrap ${
                  isCareerMode
                    ? 'bg-fuchsia-500/20 border-fuchsia-400/70 text-fuchsia-200'
                    : 'bg-sky-500/20 border-sky-400/70 text-sky-200'
                }`}
              >
                <MapIcon className="w-3 h-3" />
                <span>{t('inst.miniMapBtn')}</span>
              </button>

              {isCareerMode && onOpenAtcBriefing && (
                <button
                  type="button"
                  onClick={onOpenAtcBriefing}
                  className="min-h-[30px] px-1.5 rounded-md bg-amber-500/20 border border-amber-400/70 text-amber-200 font-bold flex items-center gap-1 shrink-0 whitespace-nowrap"
                >
                  <Radio className="w-3 h-3" />
                  <span>ATC</span>
                </button>
              )}
            </div>

            {/* Mobile Nav Telemetry: Dist, ETA, Bearing */}
            <div className="flex items-center gap-2 text-right shrink-0">
              <span>
                <strong className="text-white">{nav.distanceToRunwayNm.toFixed(1)}</strong>
                <span className="text-slate-400">NM</span>
              </span>
              <span className="hidden sm:inline text-amber-300 font-semibold">
                {formatEta(nav.etaSeconds, lang)}
              </span>
              <span className="text-sky-300 font-bold">
                {String(nav.bearingDeg).padStart(3, '0')}°
              </span>
            </div>
          </div>

          {/* Mobile Group: ASSISTENZA ATTERRAGGIO */}
          <div className="flex items-center justify-between gap-1.5 pt-0.5 border-t border-slate-800/80">
            <span className={`px-1.5 py-0.2 rounded border text-[9px] font-bold shrink-0 ${stageInfo.lampCls}`}>
              {stageInfo.shortLabel}
            </span>
            <div className="flex items-center gap-2.5 text-[9.5px] truncate">
              <span>
                {t('common.speed').slice(0, 3).toUpperCase()}{' '}
                <strong className="text-white">{Math.round(hudState.iasKt)}</strong>/
                <span className="text-cyan-300 font-bold">{nav.idealSpeedKt}kt</span>
              </span>
              <span>
                {t('common.altitude').slice(0, 3).toUpperCase()}{' '}
                <strong className="text-white">{hudState.altitudeFt}</strong>/
                <span className="text-sky-300 font-bold">{nav.targetProfileAltFt}ft</span>
              </span>
            </div>
          </div>
        </div>

        {/* FLOATING CONTEXTUAL ADVISORY / ATC RADIO PILL (Non-intrusive, Center Top) */}
        {(localizedAtc || hudState.assistantAdvisory || emergencyBannerText) && (
          <div className="px-3 flex flex-col items-center gap-1 pointer-events-none">
            {emergencyBannerText && (
              <div className="px-3 py-1 rounded-lg bg-red-950/92 border border-red-400 text-red-100 font-mono text-[10.5px] font-bold max-w-xl truncate shadow-lg">
                {hudLocal.emergPrefix} {emergencyBannerText}
              </div>
            )}

            {localizedAtc ? (
              <div className="pointer-events-auto px-3 py-1 rounded-lg bg-slate-950/90 border border-amber-400/70 text-amber-100 font-mono text-[10.5px] flex items-center gap-2 max-w-2xl shadow-lg">
                <Radio className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="text-amber-300 font-bold shrink-0">
                  {localizedAtc.sender}:
                </span>
                <span className="truncate">&ldquo;{localizedAtc.text}&rdquo;</span>
              </div>
            ) : (
              hudState.assistantAdvisory && (
                <div
                  className={`px-3 py-1 rounded-lg border font-mono text-[10.5px] flex items-center gap-1.5 max-w-xl shadow-lg ${
                    hudState.assistantAdvisory.category === 'config' ||
                    hudState.assistantAdvisory.category === 'approach'
                      ? 'bg-amber-950/90 border-amber-400/80 text-amber-100'
                      : 'bg-slate-950/88 border-sky-400/65 text-sky-100'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-sky-300 shrink-0" />
                  <span className="font-semibold truncate">{localizedAdvisoryText}</span>
                </div>
              )
            )}
          </div>
        )}
      </div>

      {/* ===================================================================== */}
      {/* 2. DESKTOP INTEGRATED COCKPIT (Wide Open Windshield + 5 Crisp Groups) */}
      {/* ===================================================================== */}
      <div className="hidden lg:flex flex-col w-full">
        {/* Lateral Slim Avionics Wings: Left = NAVIGAZIONE | Center = WIDE OPEN SKY | Right = ASSISTENZA ATTERRAGGIO */}
        <div className="flex items-end justify-between px-2.5 xl:px-3.5 pb-2 gap-4">
          {/* GRUPPO 4: NAVIGAZIONE (Compact Left Module) */}
          <section
            aria-label={t('hud.navTitle')}
            className={`pointer-events-auto w-[244px] xl:w-[268px] rounded-xl border cockpit-glass p-2 flex flex-col gap-1.5 font-mono tabular-nums transition-colors duration-150 ${
              phase.focus.navigation ? 'border-sky-400/75' : 'border-slate-700/85'
            }`}
          >
            <div className="flex items-center justify-between gap-1.5 border-b border-slate-800/90 pb-1">
              <span className="text-[9.5px] font-bold tracking-wider text-sky-300 flex items-center gap-1">
                <Navigation className="w-3 h-3" />
                {t('hud.navTitle')}
              </span>

              <div className="flex items-center gap-1">
                {isCareerMode && onOpenAtcBriefing && (
                  <button
                    type="button"
                    onClick={onOpenAtcBriefing}
                    className="min-h-[24px] px-1.5 rounded bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/65 text-amber-200 text-[9px] font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
                    title={t('hud.openAtcTitle')}
                  >
                    <Radio className="w-2.5 h-2.5" />
                    <span>{t('hud.atcBtn').toUpperCase()}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={onOpenInteractiveMap}
                  className={`min-h-[24px] px-2 rounded border text-[9px] font-extrabold flex items-center gap-1 transition-colors cursor-pointer whitespace-nowrap ${
                    isCareerMode
                      ? 'bg-fuchsia-500/20 hover:bg-fuchsia-500/30 border-fuchsia-400/70 text-fuchsia-200'
                      : 'bg-sky-500 hover:bg-sky-400 border-sky-300 text-slate-950'
                  }`}
                  title={t('hud.openMapTitle')}
                >
                  <MapIcon className="w-2.5 h-2.5" />
                  <span>{isCareerMode ? hudLocal.atcChartBtn : hudLocal.mapKeyBtn}</span>
                </button>
              </div>
            </div>

            {/* Destination Selector (Free Flight) or Locked ATC Assignment (Career) */}
            {isCareerMode ? (
              <div className="bg-slate-950/90 border border-fuchsia-500/45 rounded-lg px-2 py-1 flex items-center justify-between text-[10px]">
                <div className="min-w-0 truncate">
                  <span className="text-fuchsia-300 font-bold">{nav.airportIcao}</span>{' '}
                  <span className="text-slate-200">{nav.airportCity}</span>
                </div>
                <span className="text-emerald-300 font-bold shrink-0 inline-flex items-center gap-1">
                  <Lock className="w-2.5 h-2.5 text-fuchsia-400" />
                  RWY {nav.runwayId}
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 bg-slate-950/90 border border-slate-700/90 rounded-lg px-2 py-1">
                <span className="text-[8.5px] text-slate-400 font-bold shrink-0">{t('chart.canvasDestTag')}</span>
                <select
                  aria-label={t('common.destination')}
                  value={hudState.targetAirportId}
                  onChange={(e) => onSelectTargetAirport(e.target.value)}
                  className="flex-1 bg-transparent text-[10.5px] font-bold text-emerald-300 focus:outline-none cursor-pointer truncate"
                >
                  {AIRPORTS.map((ap) => (
                    <option key={ap.id} value={ap.id} className="bg-slate-950 text-slate-100">
                      {ap.icao} · {ap.city} ({ap.runwayLengthM}m)
                    </option>
                  ))}
                </select>
                <span className="text-[9px] text-sky-300 font-bold shrink-0">
                  RWY {nav.runwayId}
                </span>
              </div>
            )}

            {/* Distance, ETA & Bearing Readouts */}
            <div className="grid grid-cols-3 gap-1 text-[9.5px]">
              <div className="bg-slate-950/85 border border-slate-800 rounded-lg px-1.5 py-1">
                <div className="text-[7.5px] text-slate-400 leading-none uppercase">{t('hud.navDist')}</div>
                <div className="font-bold text-white mt-0.5 whitespace-nowrap">
                  {nav.distanceToRunwayNm.toFixed(1)} <span className="text-sky-300 text-[8px]">NM</span>
                </div>
                <div className="text-[7.5px] text-slate-400 leading-none">
                  {nav.distanceToRunwayKm.toFixed(1)} km
                </div>
              </div>

              <div className="bg-slate-950/85 border border-slate-800 rounded-lg px-1.5 py-1">
                <div className="text-[7.5px] text-slate-400 leading-none uppercase">{t('hud.navEta')}</div>
                <div className="font-bold text-amber-300 mt-0.5 whitespace-nowrap">
                  {formatEta(nav.etaSeconds, lang)}
                </div>
                <div className="text-[7.5px] text-slate-400 leading-none">
                  GS {Math.round(hudState.groundSpeedKt)}kt
                </div>
              </div>

              <div className="bg-slate-950/85 border border-slate-800 rounded-lg px-1.5 py-1">
                <div className="text-[7.5px] text-slate-400 leading-none uppercase">{t('hud.navBrg')}</div>
                <div className="font-bold text-emerald-300 mt-0.5 whitespace-nowrap">
                  {String(nav.bearingDeg).padStart(3, '0')}°
                </div>
                <div className="text-[7.5px] text-slate-400 leading-none">
                  CRS {String(nav.runwayHeadingDeg).padStart(3, '0')}°
                </div>
              </div>
            </div>

            {/* Clickable Live Route Mini-Map */}
            <MiniCockpitRouteMap
              acWorldXM={hudState.worldXM}
              acWorldYM={hudState.worldYM}
              headingDeg={hudState.headingDeg}
              targetAirportId={hudState.targetAirportId}
              routeCode={atcAssignment?.routeCode ?? nav.routeCode}
              bearingDeg={nav.bearingDeg}
              isCareerMode={isCareerMode}
              waypointIds={waypointIds}
              onClick={onOpenInteractiveMap}
            />
          </section>

          {/* Center ATIS Subtle Notice */}
          {localizedAtis && (
            <div className="mb-1 px-2.5 py-1 rounded-lg bg-slate-950/85 border border-sky-500/45 font-mono text-[10px] text-sky-200 max-w-sm truncate">
              ATIS: {localizedAtis}
            </div>
          )}

          {/* GRUPPO 5: ASSISTENZA ATTERRAGGIO (Compact Right Module with Profile) */}
          <section
            aria-label={t('hud.landingAssistTitle')}
            className={`pointer-events-auto w-[256px] xl:w-[284px] rounded-xl border cockpit-glass p-2 flex flex-col gap-1.5 font-mono tabular-nums transition-colors duration-150 ${
              phase.focus.profile ? 'border-emerald-400/75' : 'border-slate-700/85'
            }`}
          >
            <div className="flex items-center justify-between gap-1.5 border-b border-slate-800/90 pb-1">
              <span className="text-[9.5px] font-bold tracking-wider text-emerald-300 truncate">
                {t('hud.landingAssistTitle')}
              </span>
              <span
                className={`px-1.5 py-0.5 rounded border text-[8.5px] font-extrabold whitespace-nowrap ${stageInfo.lampCls}`}
              >
                {stageInfo.shortLabel}
              </span>
            </div>

            {/* Ideal Speed & Ideal Altitude Comparison Cells */}
            <div className="grid grid-cols-2 gap-1.5 text-[9.5px]">
              <div className="bg-slate-950/85 border border-slate-800 rounded-lg px-2 py-1">
                <div className="flex items-center justify-between text-[7.5px] text-slate-400 leading-none">
                  <span className="truncate">{t('hud.idealSpeed')}</span>
                  <span
                    className={
                      nav.speedStatus === 'TOO_FAST'
                        ? 'text-amber-300 font-bold'
                        : nav.speedStatus === 'TOO_SLOW'
                          ? 'text-red-400 font-bold'
                          : 'text-emerald-400 font-bold'
                    }
                  >
                    {nav.speedStatus === 'TOO_FAST'
                      ? hudLocal.highShort
                      : nav.speedStatus === 'TOO_SLOW'
                        ? hudLocal.lowShort
                        : 'OK'}
                  </span>
                </div>
                <div className="font-bold text-white mt-0.5 whitespace-nowrap">
                  {Math.round(hudState.iasKt)} <span className="text-slate-500">/</span>{' '}
                  <span className="text-cyan-300">{nav.idealSpeedKt} kt</span>
                </div>
              </div>

              <div className="bg-slate-950/85 border border-slate-800 rounded-lg px-2 py-1">
                <div className="flex items-center justify-between text-[7.5px] text-slate-400 leading-none">
                  <span className="truncate">{t('hud.idealAlt')}</span>
                  <span
                    className={
                      nav.tooHigh
                        ? 'text-amber-300 font-bold'
                        : nav.tooLow
                          ? 'text-red-400 font-bold'
                          : 'text-emerald-400 font-bold'
                    }
                  >
                    {nav.tooHigh ? hudLocal.highShort : nav.tooLow ? hudLocal.lowShort : 'OK'}
                  </span>
                </div>
                <div className="font-bold text-white mt-0.5 whitespace-nowrap">
                  {hudState.altitudeFt} <span className="text-slate-500">/</span>{' '}
                  <span className="text-sky-300">{nav.targetProfileAltFt} ft</span>
                </div>
              </div>
            </div>

            {/* Integrated 3° Descent Profile & TOD Display */}
            <DescentProfileDisplay
              nav={nav}
              altitudeFt={hudState.altitudeFt}
              iasKt={hudState.iasKt}
              apTargetAltFt={hudState.apTargetAltFt}
              apEnabled={hudState.apEnabled}
              highlighted={phase.focus.profile}
              className="w-full h-[74px] xl:h-[80px]"
            />
          </section>
        </div>

        {/* BOTTOM MAIN INSTRUMENT & COMMAND DECK (Strumenti + AUTOPILOTA + CONFIGURAZIONE AEREO + PILOTAGGIO) */}
        <div className="pointer-events-auto w-full cockpit-chassis">
          <div className="w-full h-1.5 cockpit-glareshield-lip" />

          <div className="w-full px-2.5 xl:px-4 py-1.5 flex items-stretch justify-between gap-2 xl:gap-3 font-mono tabular-nums">
            {/* FLIGHT & ENGINE INSTRUMENTS CLUSTER */}
            <div className="flex items-center gap-1.5 xl:gap-2.5 shrink-0">
              <div className="hidden 2xl:block shrink-0">
                <EngineTachAndGauges
                  hudState={hudState}
                  aircraft={aircraft}
                  sizeMode="desktop"
                  engineHighlighted={phase.focus.engine}
                  fuelHighlighted={phase.focus.fuel}
                />
              </div>
              <div className="2xl:hidden shrink-0">
                <EngineTachAndGauges
                  hudState={hudState}
                  aircraft={aircraft}
                  compactGaugesOnly
                  engineHighlighted={phase.focus.engine}
                  fuelHighlighted={phase.focus.fuel}
                />
              </div>

              <div className="flex items-center gap-1 xl:gap-1.5 border-l border-slate-800/90 pl-2 xl:pl-2.5">
                <AirspeedDial
                  iasKt={hudState.iasKt}
                  aircraft={aircraft}
                  vRefKt={nav.vRefKt}
                  idealSpeedKt={nav.idealSpeedKt}
                  sizeMode="desktop"
                  highlighted={phase.focus.airspeed}
                />
                <AttitudeDial
                  pitchRad={hudState.pitchRad}
                  bankDeg={hudState.bankDeg}
                  apEnabled={hudState.apEnabled}
                  elevatorInput={hudState.elevatorDeflection}
                  sizeMode="desktop"
                  highlighted={phase.focus.attitude}
                />
                <AltimeterDial
                  altitudeFt={hudState.altitudeFt}
                  aglFt={hudState.aglFt}
                  apEnabled={hudState.apEnabled}
                  apTargetAltFt={hudState.apTargetAltFt}
                  sizeMode="desktop"
                  highlighted={phase.focus.altimeter}
                />
                <VerticalSpeedDial
                  vsiFpm={hudState.vsiFpm}
                  recommendedVsiFpm={nav.recommendedVsiFpm}
                  aircraft={aircraft}
                  showVnavBug={nav.guidanceStage !== 'LANDED'}
                  sizeMode="desktop"
                  highlighted={phase.focus.vsi}
                />
                <HeadingCompassDial
                  headingDeg={hudState.headingDeg}
                  magneticCompassDeg={hudState.magneticCompassDeg}
                  runwayBearingDeg={nav.bearingDeg}
                  sizeMode="desktop"
                  highlighted={phase.focus.compass}
                />
              </div>
            </div>

            {/* GRUPPO 3: AUTOPILOTA (Activation, Altitude Adjust -/+, Selected Altitude Display) */}
            <section
              aria-label={t('hud.apTitle')}
              className={`flex-1 min-w-[168px] max-w-[218px] rounded-xl border px-2 py-1.5 flex flex-col justify-between transition-colors duration-150 ${
                hudState.apEnabled
                  ? 'cockpit-module border-emerald-400/80'
                  : phase.focus.autopilot
                    ? 'cockpit-module border-sky-400/65'
                    : 'cockpit-module border-slate-700/90'
              }`}
            >
              <div className="flex items-center justify-between text-[9px] border-b border-slate-800/90 pb-0.5">
                <span className="font-bold tracking-wider text-slate-300 truncate">{t('hud.apTitle')}</span>
                <span
                  className={`inline-flex items-center gap-1 font-extrabold ${
                    hudState.apEnabled ? 'text-emerald-300' : 'text-slate-400'
                  }`}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      hudState.apEnabled ? 'bg-emerald-400' : 'bg-slate-600'
                    }`}
                  />
                  {hudState.apEnabled ? t('common.on') : 'OFF'}
                </span>
              </div>

              <button
                type="button"
                onClick={onToggleAutopilot}
                className={`w-full min-h-[34px] rounded-lg border px-2 flex items-center justify-between transition-all duration-150 active:scale-[0.98] cursor-pointer ${
                  hudState.apEnabled
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 border-emerald-200 font-extrabold'
                    : canEngageAp
                      ? 'bg-slate-900 hover:bg-slate-800 text-slate-100 border-slate-600 hover:border-sky-400 font-bold'
                      : 'bg-slate-950 text-slate-500 border-slate-800 font-semibold'
                }`}
                title={t('hud.apEngageTitle')}
              >
                <span className="flex items-center gap-1.5 text-[11px] whitespace-nowrap">
                  <Compass className="w-3.5 h-3.5 shrink-0" />
                  <span>{t('hud.apTitle')}</span>
                </span>
                <span className="text-[10px] font-extrabold">
                  {hudState.apEnabled ? 'ON' : 'OFF'}
                </span>
              </button>

              <div className="flex items-stretch gap-1 h-[36px]">
                <button
                  type="button"
                  aria-label={t('hud.apDecAltTitle')}
                  {...bindHoldApAlt(-1)}
                  className={`w-9 rounded-lg border flex items-center justify-center touch-none transition-colors cursor-pointer ${
                    apAltHeldDir === -1
                      ? 'bg-sky-400 text-slate-950 border-sky-100'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-100 border-slate-600 hover:border-sky-400'
                  }`}
                  title={t('hud.apDecAltTitle')}
                >
                  <Minus className="w-3.5 h-3.5 stroke-[2.8]" />
                </button>

                <div
                  className={`flex-1 rounded-lg border bg-[#020617] px-1.5 flex flex-col items-center justify-center ${
                    hudState.apEnabled
                      ? Math.abs(apAltDiffFt) <= 45
                        ? 'border-emerald-400/75 text-emerald-300'
                        : 'border-sky-400/75 text-sky-300'
                      : 'border-slate-700 text-amber-300'
                  }`}
                  title={`${t('hud.apSelectedAlt')}: ${apVerticalStatus}`}
                >
                  <span className="text-[7px] text-slate-400 leading-none truncate max-w-full">
                    {t('hud.apSelectedAlt')}
                  </span>
                  <span className="text-[12.5px] xl:text-[13.5px] font-extrabold leading-tight">
                    {formattedApAlt}
                  </span>
                </div>

                <button
                  type="button"
                  aria-label={t('hud.apIncAltTitle')}
                  {...bindHoldApAlt(1)}
                  className={`w-9 rounded-lg border flex items-center justify-center touch-none transition-colors cursor-pointer ${
                    apAltHeldDir === 1
                      ? 'bg-sky-400 text-slate-950 border-sky-100'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-100 border-slate-600 hover:border-sky-400'
                  }`}
                  title={t('hud.apIncAltTitle')}
                >
                  <Plus className="w-3.5 h-3.5 stroke-[2.8]" />
                </button>
              </div>
            </section>

            {/* GRUPPO 2: CONFIGURAZIONE AEREO (Flap, Carrello, Freni, Anti-Ghiaccio) */}
            <section
              aria-label={t('hud.configTitle')}
              className="w-[186px] xl:w-[208px] rounded-xl border border-slate-700/90 cockpit-module px-2 py-1.5 flex flex-col justify-between shrink-0"
            >
              <div className="flex items-center justify-between gap-1 text-[9px] border-b border-slate-800/90 pb-0.5">
                <span className="font-bold tracking-wider text-slate-300 truncate">
                  {t('hud.configTitle')}
                </span>

                <button
                  type="button"
                  onClick={onToggleDeIce}
                  className={`px-1.5 py-0.2 rounded border text-[8.5px] font-bold flex items-center gap-0.5 cursor-pointer whitespace-nowrap ${
                    liveWx.deIceActive
                      ? 'bg-cyan-500 text-slate-950 border-cyan-200'
                      : icingPct >= 15
                        ? 'bg-amber-950 border-amber-400 text-amber-200'
                        : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-slate-200'
                  }`}
                  title={t('hud.deIceTitle')}
                >
                  <Snowflake className="w-2.5 h-2.5" />
                  <span>ICE {liveWx.deIceActive ? 'ON' : icingPct > 0 ? `${icingPct}%` : ''}</span>
                </button>
              </div>

              {/* Row 1: FLAP - / FLAP + */}
              <div className="grid grid-cols-2 gap-1.5 h-[35px]">
                <button
                  type="button"
                  disabled={hudState.flapStage === 0}
                  onPointerDown={() => setFlapPressedDir(-1)}
                  onPointerUp={() => setFlapPressedDir(0)}
                  onPointerLeave={() => setFlapPressedDir(0)}
                  onClick={() => onAdjustFlaps(-1)}
                  className={`rounded-lg border px-1.5 flex flex-col items-center justify-center transition-all cursor-pointer ${
                    flapPressedDir === -1
                      ? 'bg-sky-400 text-slate-950 border-sky-100 scale-95'
                      : hudState.flapStage === 0
                        ? 'bg-slate-950 text-slate-600 border-slate-800 cursor-not-allowed'
                        : 'bg-slate-900 hover:bg-slate-800 text-sky-200 border-slate-600 hover:border-sky-400'
                  }`}
                  title={`${t('hud.flapsLabel')} − [V]`}
                >
                  <span className="text-[10px] font-extrabold leading-none whitespace-nowrap">
                    {t('hud.flapsLabel')} −
                  </span>
                  <span className="text-[8px] opacity-80 leading-none mt-0.5">{hudLocal.retractShort}</span>
                </button>

                <button
                  type="button"
                  disabled={hudState.flapStage === 3}
                  onPointerDown={() => setFlapPressedDir(1)}
                  onPointerUp={() => setFlapPressedDir(0)}
                  onPointerLeave={() => setFlapPressedDir(0)}
                  onClick={() => onAdjustFlaps(1)}
                  className={`rounded-lg border px-1.5 flex flex-col items-center justify-center transition-all cursor-pointer ${
                    flapPressedDir === 1
                      ? 'bg-sky-400 text-slate-950 border-sky-100 scale-95'
                      : hudState.flapStage === 3
                        ? 'bg-slate-950 text-slate-500 border-slate-800 cursor-not-allowed'
                        : phase.focus.flaps
                          ? 'cockpit-module-priority border-sky-400 text-sky-100'
                          : 'bg-slate-900 hover:bg-slate-800 text-sky-200 border-slate-600 hover:border-sky-400'
                  }`}
                  title={t('hud.flapsTitle')}
                >
                  <span className="text-[10px] font-extrabold leading-none whitespace-nowrap">
                    {t('hud.flapsLabel')} +
                  </span>
                  <span className="text-[8px] text-sky-300 font-bold leading-none mt-0.5">
                    {Math.round(hudState.flapAngleDeg)}° ({hudState.flapStage}/3)
                  </span>
                </button>
              </div>

              {/* Row 2: CARRELLO & FRENI */}
              <div className="grid grid-cols-2 gap-1.5 h-[36px]">
                <button
                  type="button"
                  onPointerDown={() => setGearPressed(true)}
                  onPointerUp={() => setGearPressed(false)}
                  onPointerLeave={() => setGearPressed(false)}
                  onClick={onToggleGear}
                  className={`rounded-lg border px-1.5 flex items-center justify-between transition-all cursor-pointer ${
                    gearPressed
                      ? 'bg-emerald-400 text-slate-950 border-emerald-100 scale-95'
                      : nav.gearWarning
                        ? 'bg-red-950 border-red-400 text-red-100'
                        : phase.focus.gear
                          ? 'cockpit-module-priority border-sky-400 text-slate-100'
                          : 'bg-slate-900 hover:bg-slate-800 border-slate-600 text-slate-100'
                  }`}
                  title={aircraft.fixedGear ? t('hud.gearFixedTitle') : t('hud.gearToggleTitle')}
                >
                  <span className="flex flex-col gap-0.5">
                    <span className={`w-1.5 h-1.5 rounded-full ${gearLedCls}`} />
                    <span className={`w-1.5 h-1.5 rounded-full ${gearLedCls}`} />
                  </span>
                  <div className="text-right leading-none min-w-0">
                    <div className="text-[9px] font-bold truncate">{t('hud.gearLabel')}</div>
                    <div
                      className={`text-[8.5px] font-extrabold mt-0.5 truncate ${
                        gearDownLocked ? 'text-emerald-400' : 'text-amber-300'
                      }`}
                    >
                      {gearStatusLabel}
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  {...bindHoldBrakes}
                  className={`rounded-lg border px-1.5 flex items-center justify-between transition-all touch-none cursor-pointer ${
                    hudState.brakesApplied
                      ? 'bg-red-600 text-white border-red-200 scale-95'
                      : phase.focus.brakes
                        ? 'cockpit-module-priority border-amber-400 text-amber-200'
                        : 'bg-slate-900 hover:bg-slate-800 border-slate-600 text-slate-100 hover:border-red-400/75'
                  }`}
                  title={t('hud.brakesTitle')}
                >
                  <OctagonAlert
                    className={`w-3.5 h-3.5 shrink-0 ${
                      hudState.brakesApplied ? 'text-white' : 'text-red-400'
                    }`}
                  />
                  <div className="text-right leading-none min-w-0">
                    <div className="text-[9.5px] font-extrabold truncate">{t('hud.brakesLabel')}</div>
                    <div className="text-[8px] text-slate-300 mt-0.5">
                      {hudState.brakesApplied
                        ? `${Math.max(15, Math.round(hudState.brakePressure * 100))}%`
                        : '[B]'}
                    </div>
                  </div>
                </button>
              </div>
            </section>

            {/* GRUPPO 1: PILOTAGGIO (Cursore Muso, Cursore Potenza & Controlli Alternativi) */}
            <section
              aria-label={t('hud.flightControlsGroup')}
              className="w-[264px] xl:w-[304px] rounded-xl border border-slate-700/90 cockpit-module px-2 py-1.5 flex flex-col justify-between gap-1 shrink-0"
            >
              <div className="flex items-center justify-between gap-1 text-[9px] border-b border-slate-800/90 pb-0.5">
                <span className="font-bold tracking-wider text-amber-300 flex items-center gap-1 truncate">
                  <SlidersHorizontal className="w-3 h-3 shrink-0" />
                  <span className="truncate">{t('hud.flightControlsGroup')}</span>
                </span>

                {/* Instant CURSORI vs PULSANTI Mode Switch */}
                <div className="flex items-center bg-slate-950 border border-slate-700 rounded-md p-0.5 text-[8.5px] shrink-0">
                  <button
                    type="button"
                    onClick={() => onChangeControlMode('sliders')}
                    title={t('hud.modeSwitchToSliders')}
                    className={`px-1.5 py-0.2 rounded font-bold transition-colors cursor-pointer whitespace-nowrap ${
                      isSlidersMode
                        ? 'bg-amber-500 text-slate-950'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {t('hud.modeSlidersBadge')}
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeControlMode('buttons')}
                    title={t('hud.modeSwitchToButtons')}
                    className={`px-1.5 py-0.2 rounded font-bold transition-colors cursor-pointer whitespace-nowrap ${
                      !isSlidersMode
                        ? 'bg-amber-500 text-slate-950'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {t('hud.modeButtonsBadge')}
                  </button>
                </div>
              </div>

              {isSlidersMode ? (
                <div className={`grid grid-cols-2 gap-1.5 ${isLargeButtons ? 'h-[92px]' : 'h-[82px]'}`}>
                  <PitchControlSlider
                    elevatorValue={hudState.elevatorInput}
                    apEnabled={hudState.apEnabled}
                    onChangeElevator={onSetElevator}
                    onHoldChange={onPitchSliderHoldChange}
                    compact
                    className="w-full h-full"
                  />
                  <PowerControlSlider
                    throttle={hudState.throttle}
                    highlighted={phase.focus.engine}
                    onChangeThrottle={onSetThrottle}
                    compact
                    className="w-full h-full"
                  />
                </div>
              ) : (
                <div className={`grid grid-cols-2 gap-1.5 ${isLargeButtons ? 'h-[92px]' : 'h-[82px]'}`}>
                  {/* Pitch Buttons: CABRA / PICCHIA */}
                  <div className="flex flex-col gap-1.5 h-full">
                    <button
                      type="button"
                      {...bindHoldPitch(1)}
                      className={`flex-1 rounded-lg border px-2 flex items-center justify-between touch-none transition-all cursor-pointer ${
                        isCabraPressed
                          ? 'bg-sky-500 text-slate-950 border-sky-200 scale-[0.97]'
                          : hudState.apEnabled
                            ? 'bg-slate-900/75 text-slate-400 border-slate-700'
                            : 'bg-slate-900 hover:bg-slate-800 text-sky-100 border-slate-600 hover:border-sky-400'
                      }`}
                    >
                      <ChevronUp className="w-4 h-4 shrink-0" />
                      <span className="text-[10px] font-extrabold whitespace-nowrap">
                        {t('hud.btnPitchUp')} [W]
                      </span>
                    </button>

                    <button
                      type="button"
                      {...bindHoldPitch(-1)}
                      className={`flex-1 rounded-lg border px-2 flex items-center justify-between touch-none transition-all cursor-pointer ${
                        isPicchiaPressed
                          ? 'bg-sky-500 text-slate-950 border-sky-200 scale-[0.97]'
                          : hudState.apEnabled
                            ? 'bg-slate-900/75 text-slate-400 border-slate-700'
                            : 'bg-slate-900 hover:bg-slate-800 text-sky-100 border-slate-600 hover:border-sky-400'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4 shrink-0" />
                      <span className="text-[10px] font-extrabold whitespace-nowrap">
                        {t('hud.btnPitchDown')} [S]
                      </span>
                    </button>
                  </div>

                  {/* Throttle Buttons: ACCELERA / RIDUCI */}
                  <div className="flex flex-col gap-1.5 h-full">
                    <button
                      type="button"
                      {...bindHoldThrottle(1)}
                      className={`flex-1 rounded-lg border px-2 flex items-center justify-between touch-none transition-all cursor-pointer ${
                        isAcceleraPressed
                          ? 'bg-amber-400 text-slate-950 border-amber-100 scale-[0.97]'
                          : 'bg-slate-900 hover:bg-slate-800 text-amber-100 border-slate-600 hover:border-amber-400'
                      }`}
                    >
                      <ChevronsUp className="w-4 h-4 shrink-0 text-amber-400" />
                      <div className="text-right leading-none">
                        <div className="text-[10px] font-extrabold">{t('hud.btnThrottleUp')}</div>
                        <div className="text-[8px] text-amber-300 font-bold mt-0.5">
                          {throttlePct}%
                        </div>
                      </div>
                    </button>

                    <button
                      type="button"
                      {...bindHoldThrottle(-1)}
                      className={`flex-1 rounded-lg border px-2 flex items-center justify-between touch-none transition-all cursor-pointer ${
                        isRiduciPressed
                          ? 'bg-amber-400 text-slate-950 border-amber-100 scale-[0.97]'
                          : 'bg-slate-900 hover:bg-slate-800 text-slate-100 border-slate-600 hover:border-amber-400'
                      }`}
                    >
                      <ChevronsDown className="w-4 h-4 shrink-0 text-amber-400" />
                      <span className="text-[10px] font-extrabold whitespace-nowrap">
                        {t('hud.btnThrottleDown')}
                      </span>
                    </button>
                  </div>
                </div>
              )}
            </section>
          </div>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* 3. SMARTPHONE & TABLET INTEGRATED COCKPIT DECK (< 1024px)             */}
      {/*    Touch-Friendly Targets, Zero Overlap, Portrait & Landscape         */}
      {/* ===================================================================== */}
      <div className="lg:hidden pointer-events-auto w-full cockpit-chassis">
        <div className="w-full h-1 cockpit-glareshield-lip" />

        {/* A. PORTRAIT SMARTPHONE & TABLET LAYOUT */}
        <div className="landscape:hidden px-2 sm:px-3 py-1.5 flex flex-col gap-1.5 font-mono tabular-nums">
          {/* Compact Dials + Descent Profile Row */}
          <div className="flex items-center justify-between gap-1">
            <AirspeedDial
              iasKt={hudState.iasKt}
              aircraft={aircraft}
              vRefKt={nav.vRefKt}
              idealSpeedKt={nav.idealSpeedKt}
              sizeMode="mobile"
              highlighted={phase.focus.airspeed}
            />
            <AttitudeDial
              pitchRad={hudState.pitchRad}
              bankDeg={hudState.bankDeg}
              apEnabled={hudState.apEnabled}
              elevatorInput={hudState.elevatorDeflection}
              sizeMode="mobile"
              highlighted={phase.focus.attitude}
            />
            <AltimeterDial
              altitudeFt={hudState.altitudeFt}
              aglFt={hudState.aglFt}
              apEnabled={hudState.apEnabled}
              apTargetAltFt={hudState.apTargetAltFt}
              sizeMode="mobile"
              highlighted={phase.focus.altimeter}
            />
            <VerticalSpeedDial
              vsiFpm={hudState.vsiFpm}
              recommendedVsiFpm={nav.recommendedVsiFpm}
              aircraft={aircraft}
              showVnavBug={nav.guidanceStage !== 'LANDED'}
              sizeMode="mobile"
              highlighted={phase.focus.vsi}
            />
            <HeadingCompassDial
              headingDeg={hudState.headingDeg}
              magneticCompassDeg={hudState.magneticCompassDeg}
              runwayBearingDeg={nav.bearingDeg}
              sizeMode="mobile"
              highlighted={phase.focus.compass}
            />
            <EngineTachAndGauges
              hudState={hudState}
              aircraft={aircraft}
              compactGaugesOnly
              engineHighlighted={phase.focus.engine}
              fuelHighlighted={phase.focus.fuel}
            />
          </div>

          <DescentProfileDisplay
            nav={nav}
            altitudeFt={hudState.altitudeFt}
            iasKt={hudState.iasKt}
            apTargetAltFt={hudState.apTargetAltFt}
            apEnabled={hudState.apEnabled}
            highlighted={phase.focus.profile}
            className="w-full h-[42px] sm:h-[48px]"
          />

          {/* Touch-Safe Primary Controls Grid: PILOTAGGIO (Left/Right) + AUTOPILOTA & CONFIGURAZIONE (Center) */}
          <div className="grid grid-cols-12 gap-1.5">
            {/* Left Thumb: PILOTAGGIO MUSO */}
            <div className="col-span-4">
              {isSlidersMode ? (
                <PitchControlSlider
                  elevatorValue={hudState.elevatorInput}
                  apEnabled={hudState.apEnabled}
                  onChangeElevator={onSetElevator}
                  onHoldChange={onPitchSliderHoldChange}
                  className={`w-full ${isLargeButtons ? 'h-[140px] sm:h-[150px]' : 'h-[126px] sm:h-[136px]'}`}
                />
              ) : (
                <div className={`flex flex-col gap-1.5 ${isLargeButtons ? 'h-[140px] sm:h-[150px]' : 'h-[126px] sm:h-[136px]'}`}>
                  <button
                    type="button"
                    {...bindHoldPitch(1)}
                    className={`flex-1 rounded-xl border-2 px-2 flex items-center justify-center gap-1 touch-none ${
                      isCabraPressed
                        ? 'bg-sky-500 text-slate-950 border-sky-100 scale-95'
                        : 'bg-slate-900 text-sky-100 border-slate-600'
                    }`}
                  >
                    <ChevronUp className="w-4 h-4 shrink-0" />
                    <span className="text-[11px] font-extrabold truncate">{t('hud.btnPitchUp')}</span>
                  </button>
                  <button
                    type="button"
                    {...bindHoldPitch(-1)}
                    className={`flex-1 rounded-xl border-2 px-2 flex items-center justify-center gap-1 touch-none ${
                      isPicchiaPressed
                        ? 'bg-sky-500 text-slate-950 border-sky-100 scale-95'
                        : 'bg-slate-900 text-sky-100 border-slate-600'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4 shrink-0" />
                    <span className="text-[11px] font-extrabold truncate">{t('hud.btnPitchDown')}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Center Pedestal: AUTOPILOTA + CONFIGURAZIONE AEREO + Mode Toggle */}
            <div className={`col-span-4 flex flex-col justify-between gap-1 ${isLargeButtons ? 'h-[140px] sm:h-[150px]' : 'h-[126px] sm:h-[136px]'}`}>
              {/* AUTOPILOTA */}
              <div className="rounded-lg border border-slate-700 bg-slate-950/90 p-1 flex flex-col gap-1">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={onToggleAutopilot}
                    className={`flex-1 min-h-[26px] rounded border px-1.5 flex items-center justify-between text-[9px] font-extrabold ${
                      hudState.apEnabled
                        ? 'bg-emerald-500 text-slate-950 border-emerald-200'
                        : 'bg-slate-900 text-slate-200 border-slate-600'
                    }`}
                  >
                    <span>AP</span>
                    <span>{hudState.apEnabled ? 'ON' : 'OFF'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeControlMode(isSlidersMode ? 'buttons' : 'sliders')}
                    className="min-h-[26px] px-1.5 rounded border border-amber-500/50 bg-slate-900 text-amber-300 text-[8.5px] font-bold"
                    title={isSlidersMode ? t('hud.modeSwitchToButtons') : t('hud.modeSwitchToSliders')}
                  >
                    {isSlidersMode ? hudLocal.cursShort : hudLocal.pulsShort}
                  </button>
                </div>

                <div className="flex items-stretch gap-1 h-[26px]">
                  <button
                    type="button"
                    aria-label={t('hud.apDecAltTitle')}
                    {...bindHoldApAlt(-1)}
                    className="w-7 rounded border border-slate-600 bg-slate-900 text-slate-100 flex items-center justify-center touch-none"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <div className="flex-1 rounded border border-slate-800 bg-[#020617] flex items-center justify-center text-[9.5px] font-extrabold text-amber-300">
                    {formattedApAlt}
                  </div>
                  <button
                    type="button"
                    aria-label={t('hud.apIncAltTitle')}
                    {...bindHoldApAlt(1)}
                    className="w-7 rounded border border-slate-600 bg-slate-900 text-slate-100 flex items-center justify-center touch-none"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* CONFIGURAZIONE AEREO: FLAP + CARRELLO + FRENI */}
              <div className="grid grid-cols-2 gap-1 flex-1">
                <button
                  type="button"
                  disabled={hudState.flapStage === 0}
                  onClick={() => onAdjustFlaps(-1)}
                  className="rounded-lg border border-slate-600 bg-slate-900 text-sky-200 text-[9.5px] font-extrabold disabled:opacity-40"
                >
                  {t('hud.flapsLabel')}−
                </button>
                <button
                  type="button"
                  disabled={hudState.flapStage === 3}
                  onClick={() => onAdjustFlaps(1)}
                  className="rounded-lg border border-slate-600 bg-slate-900 text-sky-300 text-[9.5px] font-extrabold disabled:opacity-40"
                >
                  F+ {hudState.flapStage * 10}°
                </button>
                <button
                  type="button"
                  onClick={onToggleGear}
                  className={`rounded-lg border border-slate-600 bg-slate-900 text-[9px] font-extrabold truncate px-1 ${
                    gearDownLocked ? 'text-emerald-400' : 'text-amber-300'
                  }`}
                >
                  {t('hud.gearLabel')} {gearStatusLabel}
                </button>
                <button
                  type="button"
                  {...bindHoldBrakes}
                  className={`rounded-lg border text-[9.5px] font-extrabold touch-none truncate px-1 ${
                    hudState.brakesApplied
                      ? 'bg-red-600 border-red-200 text-white'
                      : 'bg-slate-900 border-slate-600 text-slate-100'
                  }`}
                >
                  {t('hud.brakesLabel')}
                </button>
              </div>
            </div>

            {/* Right Thumb: PILOTAGGIO POTENZA */}
            <div className="col-span-4">
              {isSlidersMode ? (
                <PowerControlSlider
                  throttle={hudState.throttle}
                  highlighted={phase.focus.engine}
                  onChangeThrottle={onSetThrottle}
                  className={`w-full ${isLargeButtons ? 'h-[140px] sm:h-[150px]' : 'h-[126px] sm:h-[136px]'}`}
                />
              ) : (
                <div className={`flex flex-col gap-1.5 ${isLargeButtons ? 'h-[140px] sm:h-[150px]' : 'h-[126px] sm:h-[136px]'}`}>
                  <button
                    type="button"
                    {...bindHoldThrottle(1)}
                    className={`flex-1 rounded-xl border-2 px-2 flex items-center justify-center gap-1 touch-none ${
                      isAcceleraPressed
                        ? 'bg-amber-400 text-slate-950 border-amber-100 scale-95'
                        : 'bg-slate-900 text-amber-200 border-slate-600'
                    }`}
                  >
                    <ChevronsUp className="w-4 h-4 shrink-0" />
                    <span className="text-[11px] font-extrabold">{throttlePct}%</span>
                  </button>
                  <button
                    type="button"
                    {...bindHoldThrottle(-1)}
                    className={`flex-1 rounded-xl border-2 px-2 flex items-center justify-center gap-1 touch-none ${
                      isRiduciPressed
                        ? 'bg-amber-400 text-slate-950 border-amber-100 scale-95'
                        : 'bg-slate-900 text-slate-200 border-slate-600'
                    }`}
                  >
                    <ChevronsDown className="w-4 h-4 shrink-0" />
                    <span className="text-[11px] font-extrabold truncate">{t('hud.btnThrottleDown')}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* B. MOBILE LANDSCAPE SINGLE-ROW COCKPIT (< 1024px Horizontal) */}
        <div className="hidden landscape:flex items-center justify-between gap-1.5 px-2 py-1 h-[84px] font-mono tabular-nums">
          {isSlidersMode ? (
            <PitchControlSlider
              elevatorValue={hudState.elevatorInput}
              apEnabled={hudState.apEnabled}
              onChangeElevator={onSetElevator}
              onHoldChange={onPitchSliderHoldChange}
              compact
              className="w-[102px] md:w-[116px] h-full shrink-0"
            />
          ) : (
            <div className="flex flex-col justify-between h-full w-[86px] gap-1 shrink-0">
              <button
                type="button"
                {...bindHoldPitch(1)}
                className="flex-1 rounded-lg border border-slate-600 bg-slate-900 text-sky-100 font-extrabold text-[10px] touch-none truncate px-1"
              >
                {t('hud.btnPitchUp')}
              </button>
              <button
                type="button"
                {...bindHoldPitch(-1)}
                className="flex-1 rounded-lg border border-slate-600 bg-slate-900 text-sky-100 font-extrabold text-[10px] touch-none truncate px-1"
              >
                {t('hud.btnPitchDown')}
              </button>
            </div>
          )}

          <div className="flex items-center gap-0.5 md:gap-1 shrink-0">
            <AirspeedDial
              iasKt={hudState.iasKt}
              aircraft={aircraft}
              vRefKt={nav.vRefKt}
              idealSpeedKt={nav.idealSpeedKt}
              sizeMode="landscape"
              highlighted={phase.focus.airspeed}
            />
            <AttitudeDial
              pitchRad={hudState.pitchRad}
              bankDeg={hudState.bankDeg}
              apEnabled={hudState.apEnabled}
              elevatorInput={hudState.elevatorDeflection}
              sizeMode="landscape"
              highlighted={phase.focus.attitude}
            />
            <AltimeterDial
              altitudeFt={hudState.altitudeFt}
              aglFt={hudState.aglFt}
              apEnabled={hudState.apEnabled}
              apTargetAltFt={hudState.apTargetAltFt}
              sizeMode="landscape"
              highlighted={phase.focus.altimeter}
            />
            <VerticalSpeedDial
              vsiFpm={hudState.vsiFpm}
              recommendedVsiFpm={nav.recommendedVsiFpm}
              aircraft={aircraft}
              showVnavBug={nav.guidanceStage !== 'LANDED'}
              sizeMode="landscape"
              highlighted={phase.focus.vsi}
            />
            <HeadingCompassDial
              headingDeg={hudState.headingDeg}
              magneticCompassDeg={hudState.magneticCompassDeg}
              runwayBearingDeg={nav.bearingDeg}
              sizeMode="landscape"
              highlighted={phase.focus.compass}
            />
          </div>

          <DescentProfileDisplay
            nav={nav}
            altitudeFt={hudState.altitudeFt}
            iasKt={hudState.iasKt}
            apTargetAltFt={hudState.apTargetAltFt}
            apEnabled={hudState.apEnabled}
            highlighted={phase.focus.profile}
            className="flex-1 min-w-[92px] h-full"
          />

          <div className="flex flex-col justify-between h-full w-[158px] shrink-0 gap-1 text-[9px]">
            <div className="flex items-center gap-1 h-[24px]">
              <button
                type="button"
                onClick={onToggleAutopilot}
                className={`flex-1 h-full rounded border font-extrabold px-1.5 flex items-center justify-between ${
                  hudState.apEnabled
                    ? 'bg-emerald-500 text-slate-950 border-emerald-200'
                    : 'bg-slate-900 text-slate-100 border-slate-600'
                }`}
              >
                <span>AP</span>
                <span>{hudState.apEnabled ? 'ON' : 'OFF'}</span>
              </button>
              <button
                type="button"
                {...bindHoldApAlt(-1)}
                className="w-6 h-full rounded border border-slate-600 bg-slate-900 text-slate-100 flex items-center justify-center touch-none"
              >
                −
              </button>
              <span className="px-1 text-amber-300 font-bold">{formattedApAlt}</span>
              <button
                type="button"
                {...bindHoldApAlt(1)}
                className="w-6 h-full rounded border border-slate-600 bg-slate-900 text-slate-100 flex items-center justify-center touch-none"
              >
                +
              </button>
            </div>

            <div className="flex-1 grid grid-cols-4 gap-1">
              <button
                type="button"
                disabled={hudState.flapStage === 0}
                onClick={() => onAdjustFlaps(-1)}
                className="rounded border border-slate-600 bg-slate-900 text-sky-200 font-extrabold"
              >
                F−
              </button>
              <button
                type="button"
                disabled={hudState.flapStage === 3}
                onClick={() => onAdjustFlaps(1)}
                className="rounded border border-slate-600 bg-slate-900 text-sky-300 font-extrabold"
              >
                F+
              </button>
              <button
                type="button"
                onClick={onToggleGear}
                className={`rounded border border-slate-600 bg-slate-900 font-extrabold truncate px-0.5 ${
                  gearDownLocked ? 'text-emerald-400' : 'text-amber-300'
                }`}
              >
                {gearStatusLabel}
              </button>
              <button
                type="button"
                {...bindHoldBrakes}
                className={`rounded border font-extrabold touch-none truncate px-0.5 ${
                  hudState.brakesApplied
                    ? 'bg-red-600 border-red-200 text-white'
                    : 'bg-slate-900 border-slate-600 text-slate-100'
                }`}
              >
                {t('hud.brakesLabel').slice(0, 3)}
              </button>
            </div>
          </div>

          {isSlidersMode ? (
            <PowerControlSlider
              throttle={hudState.throttle}
              highlighted={phase.focus.engine}
              onChangeThrottle={onSetThrottle}
              compact
              className="w-[102px] md:w-[116px] h-full shrink-0"
            />
          ) : (
            <div className="flex flex-col justify-between h-full w-[88px] gap-1 shrink-0">
              <button
                type="button"
                {...bindHoldThrottle(1)}
                className="flex-1 rounded-lg border border-slate-600 bg-slate-900 text-amber-200 font-extrabold text-[9.5px] touch-none"
              >
                {throttlePct}%
              </button>
              <button
                type="button"
                {...bindHoldThrottle(-1)}
                className="flex-1 rounded-lg border border-slate-600 bg-slate-900 text-slate-200 font-extrabold text-[9.5px] touch-none truncate px-1"
              >
                {t('hud.btnThrottleDown')}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
