import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  CloudRain,
  Compass,
  Crosshair,
  Lock,
  LocateFixed,
  MapPin,
  Maximize2,
  Navigation,
  Plane,
  Radio,
  Wind,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  BATHYMETRY_CONTOURS,
  CHART_AIRWAYS,
  CHART_ISLANDS,
  CHART_LAKES,
  CHART_MOUNTAIN_PEAKS,
  CHART_RIVERS,
  CHART_SEA_LABELS,
  CHART_URBAN_ZONES,
  CHART_WAYPOINTS,
  ChartPoint,
  ChartWaypoint,
  FIR_BOUNDARIES,
  formatAviationLatLon,
  getWaypointById,
  INTERNATIONAL_BORDERS,
  ITALY_MAINLAND_POLYGON,
  RELIEF_FOOTHILLS,
  RELIEF_HIGH_ALPS,
  RELIEF_MID_MOUNTAINS,
} from '../data/aeronauticalChartData';
import {
  computeWorldBearingAndDistance,
  getAirportWeatherSnapshot,
  selectBestRunwayForWind,
} from '../data/airports';
import { useI18n } from '../i18n/I18nContext';
import {
  bearingToCardinalLocalized,
  compassWestLetter,
  localizeAirportRegion,
  localizeChartGeoLabel,
  localizeRunwaySurface,
  localizeWeatherType,
} from '../i18n/localizeGameData';
import {
  AircraftSpec,
  AirportSpec,
  CareerAtcAssignment,
  LanguageCode,
  LiveWeatherState,
  WeatherType,
} from '../types/game';

const M_TO_FT = 3.28084;
const M_TO_NM = 1 / 1852;

const LOCALE_FOR_LANG: Record<LanguageCode, string> = {
  it: 'it-IT',
  en: 'en-GB',
  fr: 'fr-FR',
  de: 'de-DE',
  es: 'es-ES',
};

const WEATHER_METAR_CODE: Record<WeatherType, string> = {
  [WeatherType.CLEAR]: 'CAVOK',
  [WeatherType.CLOUDY]: 'SCT',
  [WeatherType.RAIN]: 'RA',
  [WeatherType.STORM]: 'TSRA',
  [WeatherType.SNOW]: 'SN',
  [WeatherType.FOG]: 'FG',
};

export interface InteractiveWorldMapProps {
  airports: AirportSpec[];
  currentWorldXM: number;
  currentWorldYM: number;
  headingDeg: number;
  altitudeFt?: number;
  iasKt?: number;
  departureAirportId: string;
  activeDestinationId: string;
  aircraft: AircraftSpec;
  liveWeather?: LiveWeatherState;
  isInFlight: boolean;
  isCareerMode?: boolean;
  destinationLocked?: boolean;
  atcAssignment?: CareerAtcAssignment;
  waypointIds?: string[];
  onChangeWaypoints?: (nextWaypointIds: string[]) => void;
  allowChangeDeparture?: boolean;
  embedded?: boolean;
  onConfirmDestination: (destinationId: string, departureId?: string) => void;
  onClose?: () => void;
}

export const InteractiveWorldMap: React.FC<InteractiveWorldMapProps> = ({
  airports,
  currentWorldXM,
  currentWorldYM,
  headingDeg,
  altitudeFt,
  iasKt,
  departureAirportId,
  activeDestinationId,
  aircraft,
  liveWeather,
  isInFlight,
  isCareerMode = false,
  destinationLocked = false,
  atcAssignment,
  waypointIds: controlledWaypointIds,
  onChangeWaypoints,
  allowChangeDeparture = false,
  embedded = false,
  onConfirmDestination,
  onClose,
}) => {
  const { lang, t } = useI18n();
  const lockedRoute = isCareerMode || destinationLocked;

  const [selectedDepartureId, setSelectedDepartureId] = useState<string>(departureAirportId);
  const [selectedAirportId, setSelectedAirportId] = useState<string>(activeDestinationId);
  const [internalWaypoints, setInternalWaypoints] = useState<string[]>(
    controlledWaypointIds ?? []
  );

  // Sync controlled waypoints if provided
  const activeWaypoints = controlledWaypointIds ?? internalWaypoints;
  const updateWaypoints = useCallback(
    (next: string[]) => {
      if (lockedRoute) return;
      setInternalWaypoints(next);
      onChangeWaypoints?.(next);
    },
    [lockedRoute, onChangeWaypoints]
  );

  // Map Layer Visibility Toggles
  const [showRelief, setShowRelief] = useState<boolean>(true);
  const [showAirways, setShowAirways] = useState<boolean>(true);
  const [showWeatherOverlay, setShowWeatherOverlay] = useState<boolean>(true);
  const [mobileInspectorExpanded, setMobileInspectorExpanded] = useState<boolean>(false);

  // Camera pan & zoom state (world center X/Y in meters + meters-per-pixel scale)
  const [camWorldX, setCamWorldX] = useState<number>(() =>
    isInFlight ? (currentWorldXM + 54000) * 0.5 : 54000
  );
  const [camWorldY, setCamWorldY] = useState<number>(() =>
    isInFlight ? (currentWorldYM + 1000) * 0.5 : 1500
  );
  const [zoomFactor, setZoomFactor] = useState<number>(1.0);
  const [cursorWorldPos, setCursorWorldPos] = useState<ChartPoint | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Multi-pointer drag & pinch-to-zoom state
  const activePointersRef = useRef<Map<number, { x: number; y: number }>>(new Map());
  const dragOriginRef = useRef<{
    startX: number;
    startY: number;
    camX: number;
    camY: number;
    movedPx: number;
  } | null>(null);
  const pinchRef = useRef<{
    initialDist: number;
    initialZoom: number;
  } | null>(null);

  useEffect(() => {
    setSelectedAirportId(activeDestinationId);
  }, [activeDestinationId]);

  useEffect(() => {
    setSelectedDepartureId(departureAirportId);
  }, [departureAirportId]);

  const selectedAirport = useMemo(
    () => airports.find((a) => a.id === selectedAirportId) || airports[0],
    [airports, selectedAirportId]
  );

  const activeDestAirport = useMemo(
    () => airports.find((a) => a.id === activeDestinationId) || airports[0],
    [airports, activeDestinationId]
  );

  const departureAirport = useMemo(
    () => airports.find((a) => a.id === selectedDepartureId) || airports[0],
    [airports, selectedDepartureId]
  );

  const originX = isInFlight ? currentWorldXM : departureAirport.worldXM;
  const originY = isInFlight ? currentWorldYM : departureAirport.worldYM;

  // Resolved intermediate waypoint objects
  const resolvedWaypoints = useMemo(
    () =>
      lockedRoute
        ? []
        : activeWaypoints
            .map((id) => getWaypointById(id))
            .filter((w): w is ChartWaypoint => Boolean(w)),
    [activeWaypoints, lockedRoute]
  );

  // Target airport for the planned/inspected route
  const targetRouteAirport = lockedRoute ? activeDestAirport : selectedAirport;

  // Compute multi-leg route geometry (Origin -> Waypoints... -> Target)
  const routeChainSummary = useMemo(() => {
    const nodes: { label: string; x: number; y: number }[] = [
      {
        label: isInFlight ? t('chart.aircraftTag') : departureAirport.icao,
        x: originX,
        y: originY,
      },
      ...resolvedWaypoints.map((w) => ({
        label: w.code,
        x: w.x,
        y: w.y,
      })),
      {
        label: targetRouteAirport.icao,
        x: targetRouteAirport.worldXM,
        y: targetRouteAirport.worldYM,
      },
    ];

    const legs: {
      fromX: number;
      fromY: number;
      toX: number;
      toY: number;
      fromLabel: string;
      toLabel: string;
      bearingDeg: number;
      distanceNm: number;
      distanceKm: number;
    }[] = [];

    let totalDistanceNm = 0;
    let totalDistanceKm = 0;

    for (let i = 0; i < nodes.length - 1; i++) {
      const a = nodes[i];
      const b = nodes[i + 1];
      const geo = computeWorldBearingAndDistance(a.x, a.y, b.x, b.y);
      totalDistanceNm += geo.directDistanceNm;
      totalDistanceKm += geo.directDistanceKm;
      legs.push({
        fromX: a.x,
        fromY: a.y,
        toX: b.x,
        toY: b.y,
        fromLabel: a.label,
        toLabel: b.label,
        bearingDeg: geo.bearingDeg,
        distanceNm: geo.directDistanceNm,
        distanceKm: geo.directDistanceKm,
      });
    }

    const directGeo = computeWorldBearingAndDistance(
      originX,
      originY,
      targetRouteAirport.worldXM,
      targetRouteAirport.worldYM
    );

    return {
      nodes,
      legs,
      totalDistanceNm,
      totalDistanceKm,
      initialBearingDeg: legs[0]?.bearingDeg ?? directGeo.bearingDeg,
      directDistanceNm: directGeo.directDistanceNm,
      directDistanceKm: directGeo.directDistanceKm,
    };
  }, [
    departureAirport.icao,
    isInFlight,
    originX,
    originY,
    resolvedWaypoints,
    t,
    targetRouteAirport,
  ]);

  // Airport weather snapshot for selected airport
  const selectedWeather = useMemo(
    () => getAirportWeatherSnapshot(selectedAirport, liveWeather, activeDestinationId),
    [selectedAirport, liveWeather, activeDestinationId]
  );

  // Best runway for wind at selected airport
  const recommendedRunway = useMemo(
    () =>
      selectBestRunwayForWind(
        selectedAirport,
        selectedWeather.windDirectionDeg,
        selectedWeather.windSpeedKt,
        lockedRoute && selectedAirport.id === activeDestinationId
          ? atcAssignment?.destinationRunwayId
          : undefined
      ),
    [
      selectedAirport,
      selectedWeather.windDirectionDeg,
      selectedWeather.windSpeedKt,
      lockedRoute,
      activeDestinationId,
      atcAssignment?.destinationRunwayId,
    ]
  );

  const clampZoom = (z: number) => Math.max(0.55, Math.min(5.2, z));

  const getMetersPerCssPixel = useCallback(
    (cssW: number, cssH: number) => {
      const fitX = 172000 / Math.max(320, cssW);
      const fitY = 82000 / Math.max(240, cssH);
      const baseMPerPx = Math.max(fitX, fitY);
      return baseMPerPx / zoomFactor;
    },
    [zoomFactor]
  );

  const screenToWorld = useCallback(
    (localX: number, localY: number, cssW: number, cssH: number): ChartPoint => {
      const mPerPx = getMetersPerCssPixel(cssW, cssH);
      return {
        x: camWorldX + (localX - cssW * 0.5) * mPerPx,
        y: camWorldY - (localY - cssH * 0.5) * mPerPx,
      };
    },
    [camWorldX, camWorldY, getMetersPerCssPixel]
  );

  const handleToggleWaypoint = useCallback(
    (waypointId: string) => {
      if (lockedRoute) return;
      if (activeWaypoints.includes(waypointId)) {
        updateWaypoints(activeWaypoints.filter((id) => id !== waypointId));
      } else {
        // Limit to 5 clean intermediate fixes so route stays uncluttered
        const next = [...activeWaypoints, waypointId].slice(-5);
        updateWaypoints(next);
      }
    },
    [activeWaypoints, lockedRoute, updateWaypoints]
  );

  const handleResetView = () => {
    setCamWorldX(54000);
    setCamWorldY(1500);
    setZoomFactor(1.0);
  };

  const handleCenterOnAircraft = () => {
    setCamWorldX(originX);
    setCamWorldY(originY);
    setZoomFactor((z) => Math.max(1.55, z));
  };

  const handleCenterOnAirport = (ap: AirportSpec) => {
    setSelectedAirportId(ap.id);
    setCamWorldX(ap.worldXM);
    setCamWorldY(ap.worldYM);
    setZoomFactor((z) => Math.max(1.65, z));
  };

  // High-Craft Aeronautical Chart Canvas Renderer
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    let rafId = 0;

    const renderMap = () => {
      const rect = container.getBoundingClientRect();
      const cssW = Math.max(280, Math.floor(rect.width));
      const cssH = Math.max(220, Math.floor(rect.height));
      const dpr = Math.min(2, window.devicePixelRatio || 1);

      if (canvas.width !== Math.floor(cssW * dpr) || canvas.height !== Math.floor(cssH * dpr)) {
        canvas.width = Math.floor(cssW * dpr);
        canvas.height = Math.floor(cssH * dpr);
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.save();
      ctx.scale(dpr, dpr);

      const mPerPx = getMetersPerCssPixel(cssW, cssH);
      const worldToScreen = (wx: number, wy: number) => ({
        x: cssW * 0.5 + (wx - camWorldX) / mPerPx,
        y: cssH * 0.5 - (wy - camWorldY) / mPerPx,
      });

      const tracePolygon = (pts: ChartPoint[], close = true) => {
        if (pts.length === 0) return;
        ctx.beginPath();
        pts.forEach((pt, idx) => {
          const p = worldToScreen(pt.x, pt.y);
          if (idx === 0) ctx.moveTo(p.x, p.y);
          else ctx.lineTo(p.x, p.y);
        });
        if (close) ctx.closePath();
      };

      // 1. DEEP AERONAUTICAL MARITIME SEA BACKDROP
      const seaGrad = ctx.createLinearGradient(0, 0, cssW, cssH);
      seaGrad.addColorStop(0, '#04101f');
      seaGrad.addColorStop(0.55, '#07192e');
      seaGrad.addColorStop(1, '#041222');
      ctx.fillStyle = seaGrad;
      ctx.fillRect(0, 0, cssW, cssH);

      // 2. COASTAL BATHYMETRIC CONTINENTAL SHELF CONTOURS
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.14)';
      ctx.lineWidth = 1.2;
      ctx.setLineDash([6, 4]);
      for (const shelf of BATHYMETRY_CONTOURS) {
        tracePolygon(shelf, false);
        ctx.stroke();
      }
      ctx.setLineDash([]);

      // 3. LAT / LON AERONAUTICAL GRATICULE GRID (Every 20,000 m ~ 10.8 NM)
      const gridStepM = zoomFactor >= 2.2 ? 10000 : 20000;
      const minWX = camWorldX - cssW * 0.6 * mPerPx;
      const maxWX = camWorldX + cssW * 0.6 * mPerPx;
      const minWY = camWorldY - cssH * 0.6 * mPerPx;
      const maxWY = camWorldY + cssH * 0.6 * mPerPx;

      ctx.lineWidth = 0.75;
      for (
        let gx = Math.floor(minWX / gridStepM) * gridStepM;
        gx <= maxWX;
        gx += gridStepM
      ) {
        const sx = worldToScreen(gx, 0).x;
        const isMajor = gx % 40000 === 0;
        ctx.strokeStyle = isMajor ? 'rgba(56, 189, 248, 0.14)' : 'rgba(51, 65, 85, 0.25)';
        ctx.beginPath();
        ctx.moveTo(sx, 0);
        ctx.lineTo(sx, cssH);
        ctx.stroke();
      }
      for (
        let gy = Math.floor(minWY / gridStepM) * gridStepM;
        gy <= maxWY;
        gy += gridStepM
      ) {
        const sy = worldToScreen(0, gy).y;
        const isMajor = gy % 20000 === 0;
        ctx.strokeStyle = isMajor ? 'rgba(56, 189, 248, 0.14)' : 'rgba(51, 65, 85, 0.25)';
        ctx.beginPath();
        ctx.moveTo(0, sy);
        ctx.lineTo(cssW, sy);
        ctx.stroke();
      }

      // 4. ITALIAN PENINSULA LANDMASS & ISLANDS (Coastal Shelf Glow + Land Fill)
      // Shallow water halo around mainland
      tracePolygon(ITALY_MAINLAND_POLYGON, true);
      ctx.strokeStyle = 'rgba(14, 165, 233, 0.22)';
      ctx.lineWidth = 7;
      ctx.lineJoin = 'round';
      ctx.stroke();

      const landGrad = ctx.createLinearGradient(0, 0, 0, cssH);
      landGrad.addColorStop(0, '#132524');
      landGrad.addColorStop(0.5, '#162825');
      landGrad.addColorStop(1, '#182622');
      ctx.fillStyle = landGrad;
      ctx.fill();

      ctx.strokeStyle = '#38bdf8';
      ctx.globalAlpha = 0.52;
      ctx.lineWidth = 1.35;
      ctx.stroke();
      ctx.globalAlpha = 1;

      // Islands (Lido di Venezia, Venezia Centro, Elba, Giglio, Corsica, Istria)
      for (const isl of CHART_ISLANDS) {
        tracePolygon(isl.points, true);
        ctx.fillStyle = '#152724';
        ctx.fill();
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
        ctx.lineWidth = 1.1;
        ctx.stroke();

        if (isl.name && zoomFactor >= 0.85) {
          const cx = isl.points.reduce((s, p) => s + p.x, 0) / isl.points.length;
          const cy = isl.points.reduce((s, p) => s + p.y, 0) / isl.points.length;
          const sp = worldToScreen(cx, cy);
          ctx.fillStyle = 'rgba(148, 163, 184, 0.68)';
          ctx.font = '600 8.5px "Outfit", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(isl.name, sp.x, sp.y + 3);
        }
      }

      // 5. HYPSOMETRIC TERRAIN RELIEF (Alps, Dolomites & Apennines)
      if (showRelief) {
        for (const poly of RELIEF_FOOTHILLS) {
          tracePolygon(poly.points, true);
          ctx.fillStyle = 'rgba(52, 78, 65, 0.46)';
          ctx.fill();
          ctx.strokeStyle = 'rgba(110, 145, 118, 0.24)';
          ctx.lineWidth = 0.9;
          ctx.stroke();
        }

        for (const poly of RELIEF_MID_MOUNTAINS) {
          tracePolygon(poly.points, true);
          ctx.fillStyle = 'rgba(92, 83, 66, 0.48)';
          ctx.fill();
          ctx.strokeStyle = 'rgba(168, 150, 118, 0.28)';
          ctx.lineWidth = 0.9;
          ctx.stroke();
        }

        for (const poly of RELIEF_HIGH_ALPS) {
          tracePolygon(poly.points, true);
          ctx.fillStyle = 'rgba(148, 140, 132, 0.36)';
          ctx.fill();
          ctx.strokeStyle = 'rgba(226, 232, 240, 0.34)';
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }

      // 6. RIVERS & HYDROGRAPHY (Po, Ticino, Adda, Adige, Piave, Arno, Tevere)
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      for (const river of CHART_RIVERS) {
        tracePolygon(river.points, false);
        ctx.strokeStyle = 'rgba(14, 165, 233, 0.62)';
        ctx.lineWidth = Math.max(1.1, river.widthPx * Math.min(1.6, Math.sqrt(zoomFactor)));
        ctx.stroke();

        if (zoomFactor >= 1.05) {
          const lp = worldToScreen(river.labelPoint.x, river.labelPoint.y);
          ctx.fillStyle = 'rgba(125, 211, 252, 0.66)';
          ctx.font = 'italic 600 8.5px "Outfit", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(river.name, lp.x, lp.y - 3);
        }
      }

      // 7. LAKES (Maggiore, Lugano, Como, Iseo, Garda, Trasimeno, Bolsena, Bracciano)
      for (const lake of CHART_LAKES) {
        tracePolygon(lake.points, true);
        ctx.fillStyle = '#093152';
        ctx.fill();
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.72)';
        ctx.lineWidth = 1.1;
        ctx.stroke();

        if (lake.name && zoomFactor >= 0.9) {
          const cx = lake.points.reduce((s, p) => s + p.x, 0) / lake.points.length;
          const cy = lake.points.reduce((s, p) => s + p.y, 0) / lake.points.length;
          const sp = worldToScreen(cx, cy);
          ctx.fillStyle = 'rgba(125, 211, 252, 0.85)';
          ctx.font = '600 8.5px "Outfit", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(lake.name, sp.x, sp.y + 3);
        }
      }

      // 8. METROPOLITAN URBAN FOOTPRINTS & CITY LABELS
      for (const city of CHART_URBAN_ZONES) {
        tracePolygon(city.polygon, true);
        ctx.fillStyle =
          city.populationTier === 'metropolis'
            ? 'rgba(245, 158, 11, 0.22)'
            : 'rgba(217, 119, 6, 0.16)';
        ctx.fill();
        ctx.strokeStyle = 'rgba(251, 191, 36, 0.36)';
        ctx.lineWidth = 0.85;
        ctx.stroke();

        // Show major cities always; regional cities when zoomed >= 1.1
        if (city.populationTier !== 'regional' || zoomFactor >= 1.12) {
          const cp = worldToScreen(city.x, city.y);
          ctx.fillStyle = 'rgba(253, 230, 138, 0.82)';
          ctx.beginPath();
          ctx.arc(cp.x, cp.y, city.populationTier === 'metropolis' ? 2.4 : 1.8, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle =
            city.populationTier === 'metropolis'
              ? 'rgba(254, 243, 199, 0.88)'
              : 'rgba(226, 232, 240, 0.74)';
          ctx.font =
            city.populationTier === 'metropolis'
              ? '700 9.5px "Outfit", sans-serif'
              : '600 8.5px "Outfit", sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText(city.name, cp.x + 5, cp.y + 3);
        }
      }

      // 9. MOUNTAIN SPOT ELEVATION PEAKS (▲ + FT)
      if (showRelief) {
        for (const peak of CHART_MOUNTAIN_PEAKS) {
          if (peak.elevationFt < 7500 && zoomFactor < 1.15) continue;
          const pp = worldToScreen(peak.x, peak.y);
          ctx.fillStyle = '#e2e8f0';
          ctx.strokeStyle = '#0f172a';
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(pp.x, pp.y - 4.5);
          ctx.lineTo(pp.x + 4, pp.y + 3);
          ctx.lineTo(pp.x - 4, pp.y + 3);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();

          if (zoomFactor >= 0.85) {
            ctx.fillStyle = 'rgba(226, 232, 240, 0.82)';
            ctx.font = '700 8px "JetBrains Mono", monospace';
            ctx.textAlign = 'center';
            ctx.fillText(`${peak.elevationFt} FT`, pp.x, pp.y + 11.5);
            if (zoomFactor >= 1.25) {
              ctx.fillStyle = 'rgba(148, 163, 184, 0.82)';
              ctx.font = '600 8px "Outfit", sans-serif';
              ctx.fillText(peak.name, pp.x, pp.y - 6.5);
            }
          }
        }
      }

      // 10. INTERNATIONAL BORDERS & FIR SECTOR BOUNDARIES
      ctx.save();
      ctx.setLineDash([7, 4, 2, 4]);
      ctx.strokeStyle = 'rgba(248, 250, 252, 0.35)';
      ctx.lineWidth = 1.25;
      for (const b of INTERNATIONAL_BORDERS) {
        tracePolygon(b.points, false);
        ctx.stroke();
        const lp = worldToScreen(b.labelPos.x, b.labelPos.y);
        ctx.fillStyle = 'rgba(203, 213, 225, 0.58)';
        ctx.font = '700 8px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText(localizeChartGeoLabel(b.id, b.label, lang), lp.x, lp.y);
      }

      if (showAirways) {
        ctx.setLineDash([4, 6]);
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.24)';
        ctx.lineWidth = 1;
        for (const fir of FIR_BOUNDARIES) {
          tracePolygon(fir.points, false);
          ctx.stroke();
          if (zoomFactor >= 0.85) {
            const lp = worldToScreen(fir.labelPos.x, fir.labelPos.y);
            ctx.fillStyle = 'rgba(56, 189, 248, 0.46)';
            ctx.font = '700 7.8px "JetBrains Mono", monospace';
            ctx.textAlign = 'center';
            ctx.fillText(localizeChartGeoLabel(fir.id, fir.label, lang), lp.x, lp.y);
          }
        }
      }
      ctx.restore();

      // 11. SEA & REGIONAL CARTOGRAPHIC WATERMARKS
      for (const sea of CHART_SEA_LABELS) {
        const sp = worldToScreen(sea.x, sea.y);
        ctx.fillStyle =
          sea.id === 'pianura_padana'
            ? 'rgba(134, 239, 172, 0.22)'
            : 'rgba(56, 189, 248, 0.32)';
        ctx.font = '700 10.5px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText(localizeChartGeoLabel(sea.id, sea.name, lang), sp.x, sp.y);
        if (sea.subLabel && zoomFactor >= 0.9) {
          ctx.font = '600 8px "JetBrains Mono", monospace';
          ctx.fillStyle = 'rgba(125, 211, 252, 0.24)';
          ctx.fillText(localizeChartGeoLabel(`sub_${sea.id}`, sea.subLabel, lang), sp.x, sp.y + 11);
        }
      }

      // 12. PUBLISHED ATS / VICTOR AIRWAYS & INTERACTIVE WAYPOINTS
      if (showAirways) {
        for (const awy of CHART_AIRWAYS) {
          tracePolygon(awy.points, false);
          ctx.strokeStyle = 'rgba(100, 116, 139, 0.34)';
          ctx.lineWidth = 1.15;
          ctx.setLineDash([5, 5]);
          ctx.stroke();
          ctx.setLineDash([]);

          // Airway Designator Box at Midpoint Segment
          if (awy.points.length >= 2) {
            const midIdx = Math.floor((awy.points.length - 1) / 2);
            const pA = worldToScreen(awy.points[midIdx].x, awy.points[midIdx].y);
            const pB = worldToScreen(awy.points[midIdx + 1].x, awy.points[midIdx + 1].y);
            const segLen = Math.hypot(pB.x - pA.x, pB.y - pA.y);
            if (segLen > 52) {
              const mx = (pA.x + pB.x) * 0.5;
              const my = (pA.y + pB.y) * 0.5;
              ctx.fillStyle = 'rgba(9, 15, 28, 0.9)';
              ctx.strokeStyle = 'rgba(71, 85, 105, 0.7)';
              ctx.lineWidth = 0.8;
              ctx.beginPath();
              ctx.roundRect(mx - 15, my - 6.5, 30, 13, 3);
              ctx.fill();
              ctx.stroke();
              ctx.fillStyle = '#94a3b8';
              ctx.font = '700 7.8px "JetBrains Mono", monospace';
              ctx.textAlign = 'center';
              ctx.fillText(awy.designator, mx, my + 2.6);
            }
          }
        }
      }

      // Draw Interactive Aeronautical Waypoints (VOR / RNAV / VFR)
      for (const wpt of CHART_WAYPOINTS) {
        const wp = worldToScreen(wpt.x, wpt.y);
        if (wp.x < -30 || wp.x > cssW + 30 || wp.y < -30 || wp.y > cssH + 30) continue;

        const wptIdx = resolvedWaypoints.findIndex((rw) => rw.id === wpt.id);
        const isInRoute = wptIdx >= 0;

        if (isInRoute) {
          ctx.strokeStyle = 'rgba(34, 211, 238, 0.8)';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(wp.x, wp.y, 10.5, 0, Math.PI * 2);
          ctx.stroke();
        }

        ctx.save();
        ctx.translate(wp.x, wp.y);
        if (wpt.kind === 'VOR') {
          // Aeronautical VOR Hexagon with Center Dot
          ctx.fillStyle = isInRoute ? '#083344' : '#0b1528';
          ctx.strokeStyle = isInRoute ? '#22d3ee' : '#38bdf8';
          ctx.lineWidth = isInRoute ? 1.8 : 1.2;
          ctx.beginPath();
          for (let k = 0; k < 6; k++) {
            const ang = (k * Math.PI) / 3;
            const rx = Math.cos(ang) * 5.4;
            const ry = Math.sin(ang) * 5.4;
            if (k === 0) ctx.moveTo(rx, ry);
            else ctx.lineTo(rx, ry);
          }
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
          ctx.fillStyle = isInRoute ? '#67e8f9' : '#38bdf8';
          ctx.beginPath();
          ctx.arc(0, 0, 1.5, 0, Math.PI * 2);
          ctx.fill();
        } else if (wpt.kind === 'RNAV') {
          // Aeronautical 4-Point RNAV Fly-Over Star
          ctx.fillStyle = isInRoute ? '#22d3ee' : '#0f172a';
          ctx.strokeStyle = isInRoute ? '#a5f3fc' : '#818cf8';
          ctx.lineWidth = isInRoute ? 1.6 : 1.2;
          ctx.beginPath();
          for (let k = 0; k < 8; k++) {
            const r = k % 2 === 0 ? 6 : 2.3;
            const ang = (k * Math.PI) / 4 - Math.PI / 2;
            const rx = Math.cos(ang) * r;
            const ry = Math.sin(ang) * r;
            if (k === 0) ctx.moveTo(rx, ry);
            else ctx.lineTo(rx, ry);
          }
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        } else {
          // Aeronautical VFR Reporting Triangle (△)
          ctx.fillStyle = isInRoute ? '#22d3ee' : '#0f172a';
          ctx.strokeStyle = isInRoute ? '#ecfeff' : '#cbd5e1';
          ctx.lineWidth = isInRoute ? 1.6 : 1.15;
          ctx.beginPath();
          ctx.moveTo(0, -5.6);
          ctx.lineTo(5, 3.8);
          ctx.lineTo(-5, 3.8);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
        ctx.restore();

        if (isInRoute || zoomFactor >= 0.9) {
          ctx.fillStyle = isInRoute ? '#67e8f9' : 'rgba(148, 163, 184, 0.85)';
          ctx.font = isInRoute
            ? '700 8.8px "JetBrains Mono", monospace'
            : '600 7.8px "JetBrains Mono", monospace';
          ctx.textAlign = 'center';
          const tag = isInRoute ? `${wptIdx + 1}·${wpt.code}` : wpt.code;
          ctx.fillText(tag, wp.x, wp.y - 8);
        }
      }

      // 13. ACTIVE CONFIRMED ROUTE & PREVIEW/WAYPOINT ROUTE RENDERING
      const origPt = worldToScreen(originX, originY);
      const activeDestPt = worldToScreen(activeDestAirport.worldXM, activeDestAirport.worldYM);

      // Helper to draw directional chevrons along any screen segment
      const drawRouteChevrons = (
        x1: number,
        y1: number,
        x2: number,
        y2: number,
        fillColor: string
      ) => {
        const dx = x2 - x1;
        const dy = y2 - y1;
        const dist = Math.hypot(dx, dy);
        if (dist < 38) return;
        const ang = Math.atan2(dy, dx);
        const count = dist > 220 ? 3 : dist > 110 ? 2 : 1;
        for (let i = 1; i <= count; i++) {
          const t = i / (count + 1);
          const cx = x1 + dx * t;
          const cy = y1 + dy * t;
          ctx.save();
          ctx.translate(cx, cy);
          ctx.rotate(ang);
          ctx.fillStyle = fillColor;
          ctx.strokeStyle = '#020617';
          ctx.lineWidth = 0.9;
          ctx.beginPath();
          ctx.moveTo(6.5, 0);
          ctx.lineTo(-4.2, -4.4);
          ctx.lineTo(-1.8, 0);
          ctx.lineTo(-4.2, 4.4);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
          ctx.restore();
        }
      };

      // If in Free Flight and user is inspecting a different airport than activeDestinationId,
      // draw the current confirmed direct route subtly underneath
      if (!lockedRoute && selectedAirport.id !== activeDestinationId) {
        ctx.save();
        ctx.strokeStyle = 'rgba(16, 185, 129, 0.35)';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 5]);
        ctx.beginPath();
        ctx.moveTo(origPt.x, origPt.y);
        ctx.lineTo(activeDestPt.x, activeDestPt.y);
        ctx.stroke();
        ctx.restore();
      }

      // Draw Main Route Chain (Career Locked IFR Corridor vs Free Flight Route with Waypoints)
      for (let i = 0; i < routeChainSummary.legs.length; i++) {
        const leg = routeChainSummary.legs[i];
        const p1 = worldToScreen(leg.fromX, leg.fromY);
        const p2 = worldToScreen(leg.toX, leg.toY);

        ctx.save();
        if (lockedRoute) {
          // DISTINCTIVE CAREER MODE ATC ROUTE: Authoritative Magenta/Amber IFR Airway Corridor
          ctx.strokeStyle = 'rgba(245, 158, 11, 0.24)';
          ctx.lineWidth = 11;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();

          ctx.strokeStyle = '#e879f9';
          ctx.lineWidth = 2.8;
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();

          ctx.strokeStyle = '#fde68a';
          ctx.lineWidth = 1.1;
          ctx.setLineDash([8, 6]);
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
          ctx.setLineDash([]);

          drawRouteChevrons(p1.x, p1.y, p2.x, p2.y, '#f5d0fe');
        } else {
          const isConfirmedDest = selectedAirport.id === activeDestinationId;
          const haloColor = isConfirmedDest
            ? 'rgba(16, 185, 129, 0.2)'
            : 'rgba(56, 189, 248, 0.2)';
          const coreColor = isConfirmedDest ? '#10b981' : '#38bdf8';
          const chevronColor = isConfirmedDest ? '#34d399' : '#7dd3fc';

          ctx.strokeStyle = haloColor;
          ctx.lineWidth = 8;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();

          ctx.strokeStyle = coreColor;
          ctx.lineWidth = 2.4;
          if (!isConfirmedDest) ctx.setLineDash([7, 4]);
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
          ctx.setLineDash([]);

          drawRouteChevrons(p1.x, p1.y, p2.x, p2.y, chevronColor);
        }

        // Leg Bearing & Distance Callout Pill
        const segLen = Math.hypot(p2.x - p1.x, p2.y - p1.y);
        if (segLen > 88) {
          const mx = (p1.x + p2.x) * 0.5;
          const my = (p1.y + p2.y) * 0.5;
          const badgeText = lockedRoute
            ? `ATC ${atcAssignment?.routeCode ?? `${leg.fromLabel}-${leg.toLabel}`} · ${String(leg.bearingDeg).padStart(3, '0')}° · ${leg.distanceNm.toFixed(1)} NM`
            : `${String(leg.bearingDeg).padStart(3, '0')}° · ${leg.distanceNm.toFixed(1)} NM`;
          ctx.font = '700 8.5px "JetBrains Mono", monospace';
          const tw = ctx.measureText(badgeText).width + 12;

          ctx.fillStyle = 'rgba(2, 6, 23, 0.92)';
          ctx.strokeStyle = lockedRoute
            ? 'rgba(232, 121, 249, 0.8)'
            : selectedAirport.id === activeDestinationId
              ? 'rgba(16, 185, 129, 0.8)'
              : 'rgba(56, 189, 248, 0.8)';
          ctx.lineWidth = 1.1;
          ctx.beginPath();
          ctx.roundRect(mx - tw * 0.5, my - 19, tw, 15, 4);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = lockedRoute
            ? '#f5d0fe'
            : selectedAirport.id === activeDestinationId
              ? '#6ee7b7'
              : '#bae6fd';
          ctx.textAlign = 'center';
          ctx.fillText(badgeText, mx, my - 8.5);
        }
        ctx.restore();
      }

      // 14. AIRPORTS, ORIENTED RUNWAYS, ILS CONES & WEATHER MICRO-BADGES
      for (const ap of airports) {
        const pt = worldToScreen(ap.worldXM, ap.worldYM);
        const isSelected = ap.id === selectedAirport.id;
        const isActiveDest = ap.id === activeDestinationId;
        const isDeparture = ap.id === selectedDepartureId;
        const runwayTooShort = ap.runwayLengthM < aircraft.minRunwayM;

        // ILS Approach Feather & Oriented Runway Strips
        const rwyVisualHalfLenPx = Math.max(
          9,
          Math.min(34, (ap.runwayLengthM / Math.max(85, mPerPx)) * 2.2 + 5 * Math.sqrt(zoomFactor))
        );

        for (const rwy of ap.runways) {
          const rad = ((rwy.endAHeadingDeg - 90) * Math.PI) / 180;
          const dx = Math.cos(rad) * rwyVisualHalfLenPx;
          const dy = Math.sin(rad) * rwyVisualHalfLenPx;

          // ILS Feather Cone when zoomed in or selected/destination
          if (rwy.ilsEquipped && (zoomFactor >= 1.35 || isSelected || isActiveDest)) {
            const coneLen = rwyVisualHalfLenPx * 1.65;
            const perpX = -Math.sin(rad) * 3.4;
            const perpY = Math.cos(rad) * 3.4;
            ctx.fillStyle = isActiveDest
              ? lockedRoute
                ? 'rgba(232, 121, 249, 0.16)'
                : 'rgba(16, 185, 129, 0.16)'
              : 'rgba(56, 189, 248, 0.13)';
            ctx.beginPath();
            ctx.moveTo(pt.x - dx, pt.y - dy);
            ctx.lineTo(pt.x - Math.cos(rad) * (rwyVisualHalfLenPx + coneLen) + perpX, pt.y - Math.sin(rad) * (rwyVisualHalfLenPx + coneLen) + perpY);
            ctx.lineTo(pt.x - Math.cos(rad) * (rwyVisualHalfLenPx + coneLen) - perpX, pt.y - Math.sin(rad) * (rwyVisualHalfLenPx + coneLen) - perpY);
            ctx.closePath();
            ctx.fill();
          }

          // Asphalt Runway Casing
          ctx.strokeStyle = '#020617';
          ctx.lineWidth = 5.2;
          ctx.lineCap = 'butt';
          ctx.beginPath();
          ctx.moveTo(pt.x - dx, pt.y - dy);
          ctx.lineTo(pt.x + dx, pt.y + dy);
          ctx.stroke();

          // Runway Strip Core
          ctx.strokeStyle = isActiveDest
            ? lockedRoute
              ? '#f0abfc'
              : '#6ee7b7'
            : isSelected
              ? '#7dd3fc'
              : '#e2e8f0';
          ctx.lineWidth = 2.6;
          ctx.beginPath();
          ctx.moveTo(pt.x - dx, pt.y - dy);
          ctx.lineTo(pt.x + dx, pt.y + dy);
          ctx.stroke();

          // Runway Designator Numbers when zoomed in
          if (zoomFactor >= 1.65) {
            ctx.fillStyle = '#fde68a';
            ctx.font = '700 7.2px "JetBrains Mono", monospace';
            ctx.textAlign = 'center';
            ctx.fillText(
              rwy.endAId,
              pt.x - dx * 1.32,
              pt.y - dy * 1.32 + 2.5
            );
            ctx.fillText(
              rwy.endBId,
              pt.x + dx * 1.32,
              pt.y + dy * 1.32 + 2.5
            );
          }
        }

        // Aeronautical Aerodrome Target Reticles
        if (isActiveDest) {
          ctx.strokeStyle = lockedRoute
            ? 'rgba(232, 121, 249, 0.9)'
            : 'rgba(16, 185, 129, 0.9)';
          ctx.lineWidth = 1.9;
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 16, 0, Math.PI * 2);
          ctx.stroke();
        }
        if (isSelected) {
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 2.1;
          ctx.setLineDash([4, 3]);
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 20, 0, Math.PI * 2);
          ctx.stroke();
          ctx.setLineDash([]);
        }

        // ICAO Aerodrome Ring + Cardinal Ticks
        const ringColor = isActiveDest
          ? lockedRoute
            ? '#e879f9'
            : '#10b981'
          : isDeparture
            ? '#f59e0b'
            : runwayTooShort
              ? '#fb7185'
              : '#38bdf8';

        ctx.fillStyle = '#071120';
        ctx.strokeStyle = ringColor;
        ctx.lineWidth = 2.1;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // 4 Aeronautical Aerodrome Cog Ticks
        for (let c = 0; c < 4; c++) {
          const ca = (c * Math.PI) / 2;
          ctx.beginPath();
          ctx.moveTo(pt.x + Math.cos(ca) * 8, pt.y + Math.sin(ca) * 8);
          ctx.lineTo(pt.x + Math.cos(ca) * 11, pt.y + Math.sin(ca) * 11);
          ctx.stroke();
        }

        // Center Beacon Dot
        ctx.fillStyle = ringColor;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 2.3, 0, Math.PI * 2);
        ctx.fill();

        // Airport Label Plate (ICAO + City + Optional Surface Wind/Weather)
        const apWx = getAirportWeatherSnapshot(ap, liveWeather, activeDestinationId);
        const labelText = `${ap.icao} · ${ap.city}`;
        ctx.font = '700 10px "JetBrains Mono", monospace';
        const textW = ctx.measureText(labelText).width;
        const plateH = showWeatherOverlay && zoomFactor >= 0.85 ? 25 : 16;
        const plateW = Math.max(textW + 12, showWeatherOverlay ? 86 : textW + 12);
        const plateX = pt.x - plateW * 0.5;
        const plateY = pt.y + 13;

        ctx.fillStyle = isSelected ? 'rgba(8, 25, 48, 0.95)' : 'rgba(4, 10, 22, 0.9)';
        ctx.strokeStyle = isActiveDest
          ? lockedRoute
            ? '#e879f9'
            : '#10b981'
          : isSelected
            ? '#38bdf8'
            : 'rgba(71, 85, 105, 0.85)';
        ctx.lineWidth = isSelected || isActiveDest ? 1.35 : 0.95;
        ctx.beginPath();
        ctx.roundRect(plateX, plateY, plateW, plateH, 4);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = isActiveDest
          ? lockedRoute
            ? '#f5d0fe'
            : '#6ee7b7'
          : isDeparture
            ? '#fcd34d'
            : '#f8fafc';
        ctx.textAlign = 'center';
        ctx.fillText(labelText, pt.x, plateY + 11.2);

        if (showWeatherOverlay && zoomFactor >= 0.85) {
          const wxStr = `${WEATHER_METAR_CODE[apWx.weatherType]} ${String(apWx.windDirectionDeg).padStart(3, '0')}°/${apWx.windSpeedKt}kt`;
          ctx.fillStyle =
            apWx.weatherType === WeatherType.STORM
              ? '#fca5a5'
              : apWx.weatherType === WeatherType.FOG || apWx.weatherType === WeatherType.RAIN
                ? '#fde68a'
                : '#7dd3fc';
          ctx.font = '600 8px "JetBrains Mono", monospace';
          ctx.fillText(wxStr, pt.x, plateY + 21.2);
        }
      }

      // 15. LIVE ORIENTED AIRCRAFT POSITION SYMBOL + TELEMETRY TAG
      const acPt = worldToScreen(currentWorldXM, currentWorldYM);
      ctx.save();
      ctx.translate(acPt.x, acPt.y);

      // Outer Radar Position Ring (Distinct from circular airport rings)
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.45)';
      ctx.lineWidth = 1.3;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.arc(0, 0, 15, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.rotate((headingDeg * Math.PI) / 180);

      // Heading Leader Vector Line
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(0, -11);
      ctx.lineTo(0, -28);
      ctx.stroke();

      // Crisp Swept-Wing Aircraft Silhouette
      ctx.fillStyle = '#fbbf24';
      ctx.strokeStyle = '#020617';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(0, -11);
      ctx.lineTo(2.4, -3.5);
      ctx.lineTo(10.5, 1.5);
      ctx.lineTo(10.5, 3.8);
      ctx.lineTo(2.2, 2.2);
      ctx.lineTo(1.8, 7.6);
      ctx.lineTo(5.2, 9.8);
      ctx.lineTo(5.2, 11.2);
      ctx.lineTo(0, 9.8);
      ctx.lineTo(-5.2, 11.2);
      ctx.lineTo(-5.2, 9.8);
      ctx.lineTo(-1.8, 7.6);
      ctx.lineTo(-2.2, 2.2);
      ctx.lineTo(-10.5, 3.8);
      ctx.lineTo(-10.5, 1.5);
      ctx.lineTo(-2.4, -3.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();

      // Aircraft Telemetry Callout Tag
      const acLabelWord = t('chart.aircraftTag');
      const acTag =
        isInFlight && altitudeFt !== undefined && iasKt !== undefined
          ? `${acLabelWord} · ${Math.round(altitudeFt)}FT · ${Math.round(iasKt)}KT`
          : isInFlight
            ? `${acLabelWord} · HDG ${String(Math.round(headingDeg)).padStart(3, '0')}°`
            : `${t('chart.apronTag')} ${departureAirport.icao}`;
      ctx.font = '700 8.5px "JetBrains Mono", monospace';
      const acTagW = ctx.measureText(acTag).width + 10;
      ctx.fillStyle = 'rgba(2, 6, 23, 0.92)';
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.85)';
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.roundRect(acPt.x - acTagW * 0.5, acPt.y - 31, acTagW, 13.5, 3.5);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#fde68a';
      ctx.textAlign = 'center';
      ctx.fillText(acTag, acPt.x, acPt.y - 21.8);

      // 16. PRECISION AERONAUTICAL COMPASS ROSE (Top-Right of Canvas)
      const roseX = cssW - 44;
      const roseY = 46;
      const roseR = 26;
      ctx.save();
      ctx.translate(roseX, roseY);
      ctx.fillStyle = 'rgba(4, 10, 22, 0.86)';
      ctx.strokeStyle = 'rgba(71, 85, 105, 0.85)';
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.arc(0, 0, roseR + 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      for (let deg = 0; deg < 360; deg += 15) {
        const rad = ((deg - 90) * Math.PI) / 180;
        const inner = deg % 90 === 0 ? roseR - 7 : deg % 45 === 0 ? roseR - 4.5 : roseR - 2.5;
        ctx.strokeStyle = deg === 0 ? '#f87171' : deg % 90 === 0 ? '#cbd5e1' : '#475569';
        ctx.lineWidth = deg % 90 === 0 ? 1.3 : 0.8;
        ctx.beginPath();
        ctx.moveTo(Math.cos(rad) * inner, Math.sin(rad) * inner);
        ctx.lineTo(Math.cos(rad) * roseR, Math.sin(rad) * roseR);
        ctx.stroke();
      }

      // North Pointer Star
      ctx.fillStyle = '#f87171';
      ctx.beginPath();
      ctx.moveTo(0, -roseR + 4);
      ctx.lineTo(3.2, -4);
      ctx.lineTo(0, -7);
      ctx.lineTo(-3.2, -4);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#f87171';
      ctx.font = '700 8.5px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText('N', 0, -roseR + 13);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '700 7.2px "JetBrains Mono", monospace';
      ctx.fillText('E', roseR - 9, 2.5);
      ctx.fillText('S', 0, roseR - 6);
      ctx.fillText(compassWestLetter(lang), -roseR + 9, 2.5);
      ctx.restore();

      // 17. DYNAMIC DISTANCE SCALE BAR (Bottom-Left of Canvas — NM & km)
      const targetBarPx = 88;
      const rawNm = targetBarPx * mPerPx * M_TO_NM;
      const niceNmSteps = [1, 2, 5, 10, 15, 20, 30, 50];
      const scaleNm =
        niceNmSteps.reduce((prev, curr) =>
          Math.abs(curr - rawNm) < Math.abs(prev - rawNm) ? curr : prev
        ) || 10;
      const barPx = (scaleNm * 1852) / mPerPx;
      const scaleKm = (scaleNm * 1.852).toFixed(scaleNm < 5 ? 1 : 0);

      const sbX = 14;
      const sbY = cssH - 16;
      ctx.fillStyle = 'rgba(4, 10, 22, 0.88)';
      ctx.strokeStyle = 'rgba(51, 65, 85, 0.85)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(sbX - 6, sbY - 22, barPx + 18, 28, 5);
      ctx.fill();
      ctx.stroke();

      // Alternating aviation scale segments
      const halfBar = barPx * 0.5;
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(sbX + 2, sbY - 6, halfBar, 3.5);
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(sbX + 2 + halfBar, sbY - 6, halfBar, 3.5);

      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(sbX + 2, sbY - 10);
      ctx.lineTo(sbX + 2, sbY - 2);
      ctx.moveTo(sbX + 2 + barPx, sbY - 10);
      ctx.lineTo(sbX + 2 + barPx, sbY - 2);
      ctx.stroke();

      ctx.fillStyle = '#e2e8f0';
      ctx.font = '700 8.5px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`${scaleNm} NM (${scaleKm} km)`, sbX + 2, sbY - 12);

      ctx.restore();
    };

    rafId = requestAnimationFrame(renderMap);
    const onResize = () => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(renderMap);
    };
    window.addEventListener('resize', onResize);
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', onResize);
    };
  }, [
    airports,
    selectedAirport,
    activeDestAirport,
    activeDestinationId,
    selectedDepartureId,
    departureAirport.icao,
    currentWorldXM,
    currentWorldYM,
    originX,
    originY,
    headingDeg,
    altitudeFt,
    iasKt,
    aircraft.minRunwayM,
    camWorldX,
    camWorldY,
    zoomFactor,
    getMetersPerCssPixel,
    isInFlight,
    lockedRoute,
    atcAssignment?.routeCode,
    liveWeather,
    resolvedWaypoints,
    routeChainSummary,
    showAirways,
    showRelief,
    showWeatherOverlay,
    lang,
    t,
  ]);

  // Pointer & Wheel Handlers (Drag Pan, Pinch Zoom, Wheel Zoom, Airport & Waypoint Hit-Test)
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    activePointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (activePointersRef.current.size === 1) {
      dragOriginRef.current = {
        startX: e.clientX,
        startY: e.clientY,
        camX: camWorldX,
        camY: camWorldY,
        movedPx: 0,
      };
      pinchRef.current = null;
    } else if (activePointersRef.current.size === 2) {
      const pts = Array.from(activePointersRef.current.values());
      const dist = Math.max(12, Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y));
      pinchRef.current = {
        initialDist: dist,
        initialZoom: zoomFactor,
      };
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const container = containerRef.current;
    if (container) {
      const rect = container.getBoundingClientRect();
      setCursorWorldPos(
        screenToWorld(e.clientX - rect.left, e.clientY - rect.top, rect.width, rect.height)
      );
    }

    if (!activePointersRef.current.has(e.pointerId)) return;
    activePointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (!container) return;
    const rect = container.getBoundingClientRect();
    const cssW = Math.max(280, rect.width);
    const cssH = Math.max(220, rect.height);

    if (activePointersRef.current.size === 2 && pinchRef.current) {
      const pts = Array.from(activePointersRef.current.values());
      const dist = Math.max(12, Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y));
      const scaleRatio = dist / pinchRef.current.initialDist;
      setZoomFactor(clampZoom(pinchRef.current.initialZoom * scaleRatio));
      if (dragOriginRef.current) dragOriginRef.current.movedPx = 99;
      return;
    }

    if (activePointersRef.current.size === 1 && dragOriginRef.current) {
      const dx = e.clientX - dragOriginRef.current.startX;
      const dy = e.clientY - dragOriginRef.current.startY;
      dragOriginRef.current.movedPx = Math.max(dragOriginRef.current.movedPx, Math.hypot(dx, dy));

      const mPerPx = getMetersPerCssPixel(cssW, cssH);
      setCamWorldX(
        Math.max(-45000, Math.min(165000, dragOriginRef.current.camX - dx * mPerPx))
      );
      setCamWorldY(
        Math.max(-48000, Math.min(42000, dragOriginRef.current.camY + dy * mPerPx))
      );
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    activePointersRef.current.delete(e.pointerId);

    const dragInfo = dragOriginRef.current;
    if (activePointersRef.current.size === 0) {
      dragOriginRef.current = null;
      pinchRef.current = null;
    }

    // Click / Tap Hit-Test (Airports first, then Waypoints)
    if (dragInfo && dragInfo.movedPx < 8 && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const localX = e.clientX - rect.left;
      const localY = e.clientY - rect.top;
      const cssW = Math.max(280, rect.width);
      const cssH = Math.max(220, rect.height);
      const mPerPx = getMetersPerCssPixel(cssW, cssH);

      let closestAp: AirportSpec | null = null;
      let bestApDistPx = 30;

      for (const ap of airports) {
        const sx = cssW * 0.5 + (ap.worldXM - camWorldX) / mPerPx;
        const sy = cssH * 0.5 - (ap.worldYM - camWorldY) / mPerPx;
        const d = Math.hypot(localX - sx, localY - sy);
        if (d < bestApDistPx) {
          bestApDistPx = d;
          closestAp = ap;
        }
      }

      if (closestAp) {
        setSelectedAirportId(closestAp.id);
        setMobileInspectorExpanded(true);
        return;
      }

      // Hit-test Waypoints in Free Flight mode
      if (!lockedRoute) {
        let closestWpt: ChartWaypoint | null = null;
        let bestWptDistPx = 22;
        for (const wpt of CHART_WAYPOINTS) {
          const sx = cssW * 0.5 + (wpt.x - camWorldX) / mPerPx;
          const sy = cssH * 0.5 - (wpt.y - camWorldY) / mPerPx;
          const d = Math.hypot(localX - sx, localY - sy);
          if (d < bestWptDistPx) {
            bestWptDistPx = d;
            closestWpt = wpt;
          }
        }
        if (closestWpt) {
          handleToggleWaypoint(closestWpt.id);
        }
      }
    }
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const container = containerRef.current;
    const factor = e.deltaY < 0 ? 1.18 : 1 / 1.18;
    const nextZoom = clampZoom(zoomFactor * factor);
    if (!container || Math.abs(nextZoom - zoomFactor) < 0.001) {
      setZoomFactor(nextZoom);
      return;
    }

    // Zoom smoothly toward mouse cursor position
    const rect = container.getBoundingClientRect();
    const localX = e.clientX - rect.left;
    const localY = e.clientY - rect.top;
    const beforeWorld = screenToWorld(localX, localY, rect.width, rect.height);

    const fitX = 172000 / Math.max(320, rect.width);
    const fitY = 82000 / Math.max(240, rect.height);
    const nextMPerPx = Math.max(fitX, fitY) / nextZoom;

    const nextCamX = beforeWorld.x - (localX - rect.width * 0.5) * nextMPerPx;
    const nextCamY = beforeWorld.y + (localY - rect.height * 0.5) * nextMPerPx;

    setZoomFactor(nextZoom);
    setCamWorldX(Math.max(-45000, Math.min(165000, nextCamX)));
    setCamWorldY(Math.max(-48000, Math.min(42000, nextCamY)));
  };

  const isSameAsDeparture = !isInFlight && selectedAirport.id === selectedDepartureId;
  const isAlreadyActiveDestination = isInFlight && selectedAirport.id === activeDestinationId;
  const runwayCompatible = selectedAirport.runwayLengthM >= aircraft.minRunwayM;

  const aircraftGeoStr = useMemo(
    () => formatAviationLatLon(currentWorldXM, currentWorldYM),
    [currentWorldXM, currentWorldYM]
  );

  const cursorGeoStr = useMemo(
    () =>
      cursorWorldPos
        ? formatAviationLatLon(cursorWorldPos.x, cursorWorldPos.y)
        : aircraftGeoStr,
    [cursorWorldPos, aircraftGeoStr]
  );

  // Global Live Wind / Weather Summary for Map Corner Overlay
  const mapWindDir = Math.round(
    liveWeather?.windDirectionDeg ?? selectedWeather.windDirectionDeg
  );
  const mapWindSpd = Math.round(liveWeather?.windSpeedKt ?? selectedWeather.windSpeedKt);
  const mapWxType: WeatherType = liveWeather?.currentType ?? selectedWeather.weatherType;
  const mapVisKm = liveWeather?.visibilityKm ?? selectedWeather.visibilityKm;

  const wrapperCls = embedded
    ? 'w-full h-full flex flex-col bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden map-modal-enter'
    : 'fixed inset-0 z-50 bg-slate-950/92 backdrop-blur-sm flex items-center justify-center p-1.5 sm:p-3.5 map-modal-enter';

  const innerCls = embedded
    ? 'w-full h-full flex flex-col min-h-0'
    : 'w-full max-w-[1440px] h-full max-h-[900px] bg-slate-950 border border-slate-700/90 rounded-2xl overflow-hidden flex flex-col avionics-panel';

  return (
    <div className={wrapperCls}>
      <div className={innerCls}>
        {/* TOP AERONAUTICAL NAVIGATION HEADER BAR */}
        <header className="px-2.5 sm:px-4 py-2 border-b border-slate-800 bg-slate-950 flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className={`w-8 h-8 rounded-lg border flex items-center justify-center shrink-0 ${
                lockedRoute
                  ? 'bg-fuchsia-500/15 border-fuchsia-400/60 text-fuchsia-300'
                  : 'bg-sky-500/15 border-sky-400/60 text-sky-300'
              }`}
            >
              <Navigation className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xs sm:text-sm font-bold text-white truncate">
                  {t('chart.headerTitle')}
                </h2>
                {lockedRoute ? (
                  <span className="px-2 py-0.5 rounded bg-fuchsia-950/90 border border-fuchsia-400/70 text-[9.5px] font-mono font-bold text-fuchsia-200 inline-flex items-center gap-1 whitespace-nowrap">
                    <Lock className="w-2.5 h-2.5" />
                    {t('chart.badgeAtcLocked')}
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded bg-emerald-950/85 border border-emerald-400/60 text-[9.5px] font-mono font-bold text-emerald-300 whitespace-nowrap">
                    {t('chart.badgeFreePlanning')}
                  </span>
                )}
              </div>
              <p className="text-[10.5px] text-slate-400 truncate hidden md:block">
                {lockedRoute
                  ? t('chart.subLocked', { callsign: atcAssignment?.callsign ?? 'ATC' })
                  : t('chart.subFree')}
              </p>
            </div>
          </div>

          {/* Active Route Summary & Layer Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap font-mono text-[10.5px] tabular-nums">
            {/* Layer Filter Toggles */}
            <div className="hidden sm:flex items-center gap-1 bg-slate-900/90 border border-slate-800 rounded-lg p-0.5">
              <button
                type="button"
                onClick={() => setShowRelief((v) => !v)}
                className={`min-h-[28px] px-2 rounded text-[9.5px] font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  showRelief
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title={t('chart.layerReliefTitle')}
              >
                {t('chart.layerRelief')}
              </button>
              <button
                type="button"
                onClick={() => setShowAirways((v) => !v)}
                className={`min-h-[28px] px-2 rounded text-[9.5px] font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  showAirways
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title={t('chart.layerAirwaysTitle')}
              >
                {t('chart.layerAirways')}
              </button>
              <button
                type="button"
                onClick={() => setShowWeatherOverlay((v) => !v)}
                className={`min-h-[28px] px-2 rounded text-[9.5px] font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  showWeatherOverlay
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title={t('chart.layerWeatherTitle')}
              >
                {t('chart.layerWeather')}
              </button>
            </div>

            {/* Total Route Distance & Bearing Pill */}
            <div
              className={`px-2.5 py-1 rounded-lg border flex items-center gap-1.5 ${
                lockedRoute
                  ? 'bg-fuchsia-950/40 border-fuchsia-500/50 text-fuchsia-200'
                  : 'bg-slate-900 border-slate-700 text-slate-200'
              }`}
            >
              <span className="text-amber-300 font-bold">
                {isInFlight ? t('chart.aircraftTag') : departureAirport.icao}
              </span>
              <span className="text-slate-500">→</span>
              {resolvedWaypoints.length > 0 && (
                <>
                  <span className="text-cyan-300 font-bold">
                    {resolvedWaypoints.length} WPT
                  </span>
                  <span className="text-slate-500">→</span>
                </>
              )}
              <span className={lockedRoute ? 'text-fuchsia-300 font-bold' : 'text-emerald-300 font-bold'}>
                {targetRouteAirport.icao}
              </span>
              <span className="text-slate-500 hidden sm:inline">|</span>
              <span className="text-sky-300 font-bold hidden sm:inline">
                {routeChainSummary.totalDistanceNm.toFixed(1)} NM (
                {Math.round(routeChainSummary.totalDistanceKm)} km)
              </span>
            </div>

            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="min-h-[38px] px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-100 text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                <X className="w-4 h-4" />
                <span>{t('chart.returnToFlight')}</span>
              </button>
            )}
          </div>
        </header>

        {/* INTERMEDIATE WAYPOINT RIBBON (Visible in Free Flight when waypoints exist or as quick hint) */}
        {!lockedRoute && (
          <div className="px-2.5 sm:px-4 py-1.5 bg-slate-900/90 border-b border-slate-800/90 flex items-center justify-between gap-2 overflow-x-auto custom-scroll shrink-0 font-mono text-[10px]">
            <div className="flex items-center gap-1.5 shrink-0">
              <span className="text-slate-400 font-bold">{t('chart.routeWaypointsLabel')}</span>
              <span className="px-1.5 py-0.5 rounded bg-slate-950 border border-amber-500/40 text-amber-300 font-bold">
                {isInFlight ? t('chart.currentPosTag') : departureAirport.icao}
              </span>
              {resolvedWaypoints.map((wpt) => (
                <React.Fragment key={wpt.id}>
                  <span className="text-slate-500">→</span>
                  <button
                    type="button"
                    onClick={() => handleToggleWaypoint(wpt.id)}
                    className="min-h-[26px] px-2 py-0.5 rounded bg-cyan-950/80 hover:bg-red-950/80 border border-cyan-400/60 hover:border-red-400/70 text-cyan-200 hover:text-red-200 font-bold inline-flex items-center gap-1 transition-colors cursor-pointer whitespace-nowrap"
                    title={t('chart.removeWaypointTitle', { code: wpt.code, name: wpt.name })}
                  >
                    <span>{wpt.code}</span>
                    <X className="w-3 h-3" />
                  </button>
                </React.Fragment>
              ))}
              <span className="text-slate-500">→</span>
              <span className="px-1.5 py-0.5 rounded bg-slate-950 border border-emerald-500/50 text-emerald-300 font-bold">
                {selectedAirport.icao}
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {resolvedWaypoints.length > 0 ? (
                <button
                  type="button"
                  onClick={() => updateWaypoints([])}
                  className="min-h-[26px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold cursor-pointer whitespace-nowrap"
                >
                  {t('chart.directRouteClear')}
                </button>
              ) : (
                <span className="text-slate-400 hidden sm:inline">
                  {t('chart.clickWaypointHint')}
                </span>
              )}
            </div>
          </div>
        )}

        {/* MAIN SPLIT BODY: INTERACTIVE CHART CANVAS + COMPACT AIRPORT INSPECTOR */}
        <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-hidden">
          {/* LEFT / MAIN: HIGH-CRAFT INTERACTIVE AERONAUTICAL CHART */}
          <div
            ref={containerRef}
            className="relative flex-1 min-h-[270px] bg-[#04101f] overflow-hidden select-none"
          >
            <canvas
              ref={canvasRef}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerUp}
              onPointerLeave={() => setCursorWorldPos(null)}
              onWheel={handleWheel}
              className="w-full h-full block touch-none cursor-grab active:cursor-grabbing"
            />

            {/* TOP-LEFT MAP CONTROLS: ZOOM, CENTER ON AIRCRAFT, FULL EXTENT */}
            <div className="absolute top-2.5 left-2.5 flex flex-wrap items-center gap-1.5 pointer-events-auto">
              <div className="flex items-center bg-slate-950/90 border border-slate-700/90 rounded-xl p-0.5 font-mono text-xs tabular-nums shadow-lg">
                <button
                  type="button"
                  onClick={() => setZoomFactor((z) => clampZoom(z / 1.25))}
                  className="min-h-[36px] min-w-[36px] rounded-lg hover:bg-slate-800 text-slate-200 flex items-center justify-center cursor-pointer"
                  title={t('chart.zoomOutTitle')}
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <span className="px-2 text-[11px] font-bold text-sky-300 min-w-[48px] text-center">
                  {Math.round(zoomFactor * 100)}%
                </span>
                <button
                  type="button"
                  onClick={() => setZoomFactor((z) => clampZoom(z * 1.25))}
                  className="min-h-[36px] min-w-[36px] rounded-lg hover:bg-slate-800 text-slate-200 flex items-center justify-center cursor-pointer"
                  title={t('chart.zoomInTitle')}
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
              </div>

              <button
                type="button"
                onClick={handleCenterOnAircraft}
                className="min-h-[38px] px-2.5 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-amber-400/60 text-amber-300 text-[11px] font-mono font-bold flex items-center gap-1.5 cursor-pointer shadow-lg whitespace-nowrap"
                title={t('chart.centerPlaneTitle')}
              >
                <LocateFixed className="w-3.5 h-3.5" />
                <span>{t('chart.centerPlaneBtn')}</span>
              </button>

              <button
                type="button"
                onClick={handleResetView}
                className="min-h-[38px] px-2.5 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-slate-700 text-slate-200 text-[11px] font-mono font-semibold flex items-center gap-1.5 cursor-pointer shadow-lg whitespace-nowrap"
                title={t('chart.fullItalyTitle')}
              >
                <Maximize2 className="w-3.5 h-3.5 text-sky-400" />
                <span className="hidden sm:inline">{t('chart.fullItalyBtn')}</span>
              </button>
            </div>

            {/* TOP-LEFT SUB-BADGE: LIVE METEOROLOGICAL & WIND INDICATOR ON MAP */}
            {showWeatherOverlay && (
              <div className="absolute top-14 left-2.5 bg-slate-950/88 border border-slate-700/85 rounded-xl px-2.5 py-1.5 font-mono text-[10px] tabular-nums text-slate-200 flex items-center gap-2 pointer-events-none shadow-lg">
                <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0">
                  <circle cx="12" cy="12" r="10.5" fill="#020617" stroke="#334155" strokeWidth="1.2" />
                  <g transform={`rotate(${((mapWindDir + 180) % 360).toFixed(0)} 12 12)`}>
                    <line x1="12" y1="18" x2="12" y2="6" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
                    <polygon points="12,3.8 9,8.6 15,8.6" fill="#38bdf8" />
                  </g>
                </svg>
                <div className="leading-tight">
                  <div className="text-[9px] text-slate-400 flex items-center gap-1">
                    <CloudRain className="w-3 h-3 text-sky-400" />
                    <span>
                      {t('chart.areaWeather')} · {localizeWeatherType(mapWxType, lang).toUpperCase()}
                    </span>
                  </div>
                  <div className="font-bold text-sky-200">
                    {t('common.wind')} {String(mapWindDir).padStart(3, '0')}° / {mapWindSpd} kt · Vis {mapVisKm} km
                  </div>
                </div>
              </div>
            )}

            {/* BOTTOM-RIGHT OVERLAY: GEOGRAPHIC COORDINATES & AERONAUTICAL LEGEND */}
            <div className="absolute bottom-2.5 right-2.5 flex flex-col items-end gap-1.5 pointer-events-none font-mono text-[9.5px] tabular-nums">
              <div className="bg-slate-950/90 border border-slate-700/85 rounded-lg px-2.5 py-1 text-slate-200 flex items-center gap-2">
                <span className="text-slate-400">{t('chart.coordLabel')}</span>
                <span className="text-sky-300 font-bold">{cursorGeoStr}</span>
              </div>

              <div className="hidden sm:flex items-center gap-2.5 bg-slate-950/90 border border-slate-800 rounded-lg px-2.5 py-1 text-[9px] text-slate-300">
                <span className="inline-flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  {t('chart.legPlane')}
                </span>
                <span className="inline-flex items-center gap-1">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      lockedRoute ? 'bg-fuchsia-400' : 'bg-emerald-400'
                    }`}
                  />
                  {t('chart.legDest')}
                </span>
                <span className="inline-flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-sky-400" />
                  {t('chart.legAirport')}
                </span>
                <span className="inline-flex items-center gap-1">
                  <span className="w-2 h-2 rotate-45 bg-cyan-400" />
                  {t('chart.legWaypoint')}
                </span>
              </div>
            </div>
          </div>

          {/* RIGHT SIDEBAR (Desktop) / COMPACT DOCKED PANEL (Mobile): AIRPORT INFO & ROUTE CONFIRMATION */}
          <aside className="w-full lg:w-[336px] xl:w-[364px] border-t lg:border-t-0 lg:border-l border-slate-800 bg-slate-950 flex flex-col shrink-0 max-h-[44vh] lg:max-h-none">
            {/* Quick Airport Chips Strip */}
            <div className="px-3 py-2 border-b border-slate-800/90 flex items-center justify-between gap-1.5 overflow-x-auto custom-scroll shrink-0">
              <div className="flex items-center gap-1">
                {airports.map((ap) => {
                  const isSel = ap.id === selectedAirport.id;
                  const isDst = ap.id === activeDestinationId;
                  return (
                    <button
                      key={ap.id}
                      type="button"
                      onClick={() => handleCenterOnAirport(ap)}
                      className={`min-h-[30px] px-2 py-0.5 rounded-md font-mono text-[10px] font-bold border transition-colors cursor-pointer shrink-0 ${
                        isSel
                          ? 'bg-sky-500 text-slate-950 border-sky-300'
                          : isDst
                            ? lockedRoute
                              ? 'bg-fuchsia-950/90 text-fuchsia-300 border-fuchsia-500/60'
                              : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/60'
                            : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800'
                      }`}
                    >
                      {ap.icao}
                    </button>
                  );
                })}
              </div>

              {/* Mobile Toggle to Expand/Collapse Detailed Airport Specs */}
              <button
                type="button"
                onClick={() => setMobileInspectorExpanded((v) => !v)}
                className="lg:hidden min-h-[30px] px-2 rounded-md bg-slate-900 border border-slate-700 text-[10px] font-mono font-bold text-sky-300 shrink-0 whitespace-nowrap"
              >
                {mobileInspectorExpanded ? t('chart.collapseDetails') : t('chart.expandDetails')}
              </button>
            </div>

            {/* Scrollable Airport Technical Card */}
            <div
              className={`flex-1 overflow-y-auto custom-scroll p-3 space-y-2.5 ${
                mobileInspectorExpanded ? 'block' : 'hidden lg:block'
              }`}
            >
              {/* Airport Header */}
              <div className="bg-slate-900/95 border border-slate-800 rounded-xl p-3 space-y-1.5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-1.5 font-mono text-[10.5px]">
                      <span className="px-1.5 py-0.5 rounded bg-sky-500/20 border border-sky-400/50 text-sky-300 font-bold">
                        {selectedAirport.icao}
                      </span>
                      <span className="text-slate-400">
                        {localizeAirportRegion(selectedAirport.region, lang)}
                      </span>
                    </div>
                    <h3 className="text-sm sm:text-base font-bold text-white mt-1 leading-tight">
                      {selectedAirport.name}
                    </h3>
                    <div className="text-[10.5px] font-mono text-slate-400 mt-0.5">
                      {formatAviationLatLon(selectedAirport.worldXM, selectedAirport.worldYM)}
                    </div>
                  </div>

                  {selectedAirport.id === activeDestinationId && (
                    <span
                      className={`px-2 py-0.5 rounded text-[9.5px] font-mono font-bold shrink-0 ${
                        lockedRoute
                          ? 'bg-fuchsia-500/20 border border-fuchsia-400/60 text-fuchsia-200'
                          : 'bg-emerald-500/20 border border-emerald-400/60 text-emerald-300'
                      }`}
                    >
                      {lockedRoute ? t('chart.destAtcBadge') : t('chart.activeBadge')}
                    </span>
                  )}
                </div>

                {/* Key Telemetry Metrics */}
                <div className="grid grid-cols-3 gap-1.5 pt-1.5 font-mono text-[10.5px] tabular-nums">
                  <div className="bg-slate-950 border border-slate-800/90 rounded-lg px-2 py-1.5">
                    <span className="text-[8.5px] text-slate-400 block">{t('chart.distCaps')}</span>
                    <span className="font-bold text-sky-300">
                      {computeWorldBearingAndDistance(
                        originX,
                        originY,
                        selectedAirport.worldXM,
                        selectedAirport.worldYM
                      ).directDistanceNm.toFixed(1)}{' '}
                      NM
                    </span>
                  </div>
                  <div className="bg-slate-950 border border-slate-800/90 rounded-lg px-2 py-1.5">
                    <span className="text-[8.5px] text-slate-400 block">{t('chart.dirCaps')}</span>
                    <span className="font-bold text-white">
                      {String(
                        computeWorldBearingAndDistance(
                          originX,
                          originY,
                          selectedAirport.worldXM,
                          selectedAirport.worldYM
                        ).bearingDeg
                      ).padStart(3, '0')}
                      °
                    </span>
                  </div>
                  <div className="bg-slate-950 border border-slate-800/90 rounded-lg px-2 py-1.5">
                    <span className="text-[8.5px] text-slate-400 block">{t('chart.elevCaps')}</span>
                    <span className="font-bold text-amber-300">
                      {Math.round(selectedAirport.elevationM * M_TO_FT)} FT
                    </span>
                  </div>
                </div>
              </div>

              {/* Runways & Orientations */}
              <div className="bg-slate-900/95 border border-slate-800 rounded-xl p-3 space-y-2 font-mono text-xs tabular-nums">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-300 flex items-center gap-1.5">
                    <Compass className="w-3.5 h-3.5 text-sky-400" />
                    {t('chart.rwyMagneticHeader')}
                  </span>
                  <span
                    className={`text-[9.5px] font-bold ${
                      runwayCompatible ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {runwayCompatible ? t('chart.rwySuitable') : `MIN ${aircraft.minRunwayM}m`}
                  </span>
                </div>

                <div className="space-y-1.5">
                  {selectedAirport.runways.map((rwy) => (
                    <div
                      key={rwy.id}
                      className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 space-y-0.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white text-[11px]">RWY {rwy.id}</span>
                        <span className="text-[10px] text-slate-300">
                          {rwy.lengthM} × {rwy.widthM} m · {localizeRunwaySurface(rwy.surface, lang)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span>
                          {t('chart.rwyThresholds')} {rwy.endAId} (
                          {String(rwy.endAHeadingDeg).padStart(3, '0')}°) / {rwy.endBId} (
                          {String(rwy.endBHeadingDeg).padStart(3, '0')}°)
                        </span>
                        <span className={rwy.ilsEquipped ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
                          {rwy.ilsEquipped ? 'ILS/PAPI' : 'VFR/PAPI'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-emerald-950/35 border border-emerald-500/40 rounded-lg px-2.5 py-1.5 flex items-center justify-between text-[10.5px]">
                  <span className="text-slate-300">{t('chart.rwyRecommendedWind')}</span>
                  <span className="font-bold text-emerald-300">
                    RWY {recommendedRunway.runwayId} (
                    {String(recommendedRunway.headingDeg).padStart(3, '0')}°)
                  </span>
                </div>
              </div>

              {/* Airport Surface Weather */}
              <div className="bg-slate-900/95 border border-slate-800 rounded-xl p-3 space-y-1.5 font-mono text-xs tabular-nums">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-300 flex items-center gap-1.5">
                    <Wind className="w-3.5 h-3.5 text-sky-400" />
                    {t('chart.localAirportWx')}
                  </span>
                  <span className="text-[10.5px] font-bold text-amber-300">
                    {localizeWeatherType(selectedWeather.weatherType, lang)}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-1.5 text-[10.5px]">
                  <div className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1">
                    <span className="text-[8.5px] text-slate-400 block">
                      {t('chart.surfaceWindCaps')}
                    </span>
                    <span className="text-sky-200 font-bold">
                      {String(selectedWeather.windDirectionDeg).padStart(3, '0')}° (
                      {bearingToCardinalLocalized(selectedWeather.windDirectionDeg, lang)}) ·{' '}
                      {selectedWeather.windSpeedKt} kt
                    </span>
                  </div>
                  <div className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1">
                    <span className="text-[8.5px] text-slate-400 block">
                      {t('chart.visibilityCaps')}
                    </span>
                    <span className="text-white font-bold">{selectedWeather.visibilityKm} km</span>
                  </div>
                </div>
              </div>

              {/* Career ATC Dispatch Info if Locked */}
              {lockedRoute && atcAssignment && (
                <div className="bg-fuchsia-950/25 border border-fuchsia-500/45 rounded-xl p-3 space-y-1 font-mono text-[10.5px]">
                  <div className="flex items-center justify-between text-fuchsia-300 font-bold">
                    <span className="flex items-center gap-1">
                      <Radio className="w-3.5 h-3.5" />
                      {t('chart.atcFlightPlanHeader')}
                    </span>
                    <span>{atcAssignment.towerFrequencyMhz} MHz</span>
                  </div>
                  <div className="text-slate-200">
                    {t('chart.lockedRouteCruise', { route: atcAssignment.routeCode })}{' '}
                    <strong className="text-cyan-300">
                      {atcAssignment.recommendedCruiseAltFt.toLocaleString(LOCALE_FOR_LANG[lang])}{' '}
                      FT
                    </strong>
                  </div>
                </div>
              )}
            </div>

            {/* STICKY ACTION FOOTER (Always reachable on Desktop & Mobile) */}
            <div className="p-2.5 sm:p-3 border-t border-slate-800 bg-slate-950 space-y-2 shrink-0">
              {/* Compact Mobile Summary when Inspector Collapsed */}
              {!mobileInspectorExpanded && (
                <div className="lg:hidden flex items-center justify-between gap-2 text-xs font-mono tabular-nums px-1">
                  <div className="truncate">
                    <span className="font-bold text-sky-300">{selectedAirport.icao}</span>{' '}
                    <span className="text-white font-semibold">{selectedAirport.city}</span> ·{' '}
                    <span className="text-slate-400">
                      RWY {recommendedRunway.runwayId} ({selectedAirport.runwayLengthM}m)
                    </span>
                  </div>
                  <span className="text-emerald-300 font-bold shrink-0">
                    {computeWorldBearingAndDistance(
                      originX,
                      originY,
                      selectedAirport.worldXM,
                      selectedAirport.worldYM
                    ).directDistanceNm.toFixed(1)}{' '}
                    NM
                  </span>
                </div>
              )}

              {lockedRoute ? (
                <div className="flex items-center justify-between gap-2">
                  <div className="text-[11px] font-mono text-fuchsia-200 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-fuchsia-400 shrink-0" />
                    <span>
                      {t('chart.destAssignedFooter', { icao: activeDestAirport.icao })}
                    </span>
                  </div>
                  {onClose && (
                    <button
                      type="button"
                      onClick={onClose}
                      className="min-h-[42px] px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer whitespace-nowrap"
                    >
                      {t('chart.closeChartBtn')}
                    </button>
                  )}
                </div>
              ) : (
                <>
                  {allowChangeDeparture && !isInFlight && (
                    <button
                      type="button"
                      disabled={selectedAirport.id === selectedDepartureId}
                      onClick={() => {
                        const nextDep = selectedAirport.id;
                        setSelectedDepartureId(nextDep);
                        if (selectedAirportId === nextDep) {
                          const alt = airports.find((a) => a.id !== nextDep);
                          if (alt) setSelectedAirportId(alt.id);
                        }
                      }}
                      className={`w-full min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition-colors ${
                        selectedAirport.id === selectedDepartureId
                          ? 'bg-slate-900 border-slate-800 text-slate-500 cursor-not-allowed'
                          : 'bg-slate-900 hover:bg-slate-800 border-amber-500/50 text-amber-300 cursor-pointer'
                      }`}
                    >
                      <Plane className="w-3.5 h-3.5" />
                      <span>
                        {selectedAirport.id === selectedDepartureId
                          ? t('chart.currentDepBtn', { icao: selectedAirport.icao })
                          : t('chart.setAsDepBtn', { icao: selectedAirport.icao })}
                      </span>
                    </button>
                  )}

                  <button
                    type="button"
                    disabled={isSameAsDeparture || isAlreadyActiveDestination}
                    onClick={() => onConfirmDestination(selectedAirport.id, selectedDepartureId)}
                    className={`w-full min-h-[44px] px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                      isSameAsDeparture || isAlreadyActiveDestination
                        ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                        : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer shadow-lg shadow-emerald-950/50'
                    }`}
                  >
                    {isAlreadyActiveDestination ? (
                      <>
                        <Crosshair className="w-4 h-4" />
                        <span>{t('chart.activeDestBtn', { icao: selectedAirport.icao })}</span>
                      </>
                    ) : isSameAsDeparture ? (
                      <>
                        <MapPin className="w-4 h-4" />
                        <span>{t('chart.selectDiffAirportBtn')}</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>
                          {t('chart.confirmDestCityBtn', {
                            icao: selectedAirport.icao,
                            city: selectedAirport.city,
                          })}
                        </span>
                      </>
                    )}
                  </button>
                </>
              )}
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};
