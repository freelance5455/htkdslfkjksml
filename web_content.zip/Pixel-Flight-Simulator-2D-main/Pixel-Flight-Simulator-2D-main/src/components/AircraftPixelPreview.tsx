import React, { useEffect, useRef } from 'react';
import { drawPixelAircraft, getAircraftGearClearancePx } from '../graphics/pixelSprites';
import { AircraftSpec } from '../types/game';

interface AircraftPixelPreviewProps {
  aircraft: AircraftSpec;
  className?: string;
  nightPreview?: boolean;
}

export const AircraftPixelPreview: React.FC<AircraftPixelPreviewProps> = ({
  aircraft,
  className = '',
  nightPreview = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    let animId = 0;
    let phase = 0;
    let lastTime = performance.now();

    const renderFrame = (now: number) => {
      const dt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;
      phase = (phase + dt * 20) % (Math.PI * 2);

      const canvas = canvasRef.current;
      if (canvas) {
        const vw = 480;
        const vh = 195;
        const dpr = typeof window !== 'undefined' ? Math.min(window.devicePixelRatio || 1, 2) : 1;
        const targetW = Math.round(vw * dpr);
        const targetH = Math.round(vh * dpr);

        if (canvas.width !== targetW || canvas.height !== targetH) {
          canvas.width = targetW;
          canvas.height = targetH;
        }

        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';

          // 1. Natural Multi-Stop Sky Backdrop
          const sky = ctx.createLinearGradient(0, 0, 0, 146);
          if (nightPreview) {
            sky.addColorStop(0, '#020617');
            sky.addColorStop(0.55, '#0f172a');
            sky.addColorStop(1, '#1e293b');
          } else {
            sky.addColorStop(0, '#0369a1');
            sky.addColorStop(0.55, '#38bdf8');
            sky.addColorStop(1, '#e0f2fe');
          }
          ctx.fillStyle = sky;
          ctx.fillRect(0, 0, vw, 148);

          // Soft atmospheric clouds
          ctx.fillStyle = nightPreview ? 'rgba(148, 163, 184, 0.14)' : 'rgba(255, 255, 255, 0.55)';
          ctx.beginPath();
          ctx.arc(92, 42, 22, 0, Math.PI * 2);
          ctx.arc(116, 38, 28, 0, Math.PI * 2);
          ctx.arc(142, 44, 20, 0, Math.PI * 2);
          ctx.arc(355, 52, 18, 0, Math.PI * 2);
          ctx.arc(378, 48, 24, 0, Math.PI * 2);
          ctx.fill();

          // 2. Distant Alpine Mountain Silhouette
          ctx.fillStyle = nightPreview ? '#0f172a' : '#64748b';
          ctx.beginPath();
          ctx.moveTo(0, 148);
          ctx.lineTo(0, 118);
          ctx.lineTo(68, 92);
          ctx.lineTo(135, 116);
          ctx.lineTo(215, 84);
          ctx.lineTo(295, 114);
          ctx.lineTo(385, 90);
          ctx.lineTo(480, 115);
          ctx.lineTo(480, 148);
          ctx.closePath();
          ctx.fill();

          // Distant hangar & tower silhouette on apron horizon
          ctx.fillStyle = nightPreview ? '#020617' : '#334155';
          ctx.fillRect(28, 124, 68, 24);
          ctx.beginPath();
          ctx.moveTo(26, 124);
          ctx.quadraticCurveTo(62, 114, 98, 124);
          ctx.fill();
          ctx.fillRect(418, 108, 10, 40);
          ctx.fillRect(413, 102, 20, 7);
          if (nightPreview) {
            ctx.fillStyle = '#fef08a';
            ctx.fillRect(42, 132, 40, 14);
            ctx.fillStyle = '#38bdf8';
            ctx.fillRect(415, 104, 16, 4);
          }

          // 3. Detailed Concrete & Asphalt Apron Tarmac
          const tarmac = ctx.createLinearGradient(0, 146, 0, vh);
          tarmac.addColorStop(0, nightPreview ? '#1e293b' : '#475569');
          tarmac.addColorStop(0.2, nightPreview ? '#0f172a' : '#334155');
          tarmac.addColorStop(1, nightPreview ? '#020617' : '#1e293b');
          ctx.fillStyle = tarmac;
          ctx.fillRect(0, 146, vw, vh - 146);

          // Turf strip at edge of apron
          ctx.fillStyle = nightPreview ? '#064e3b' : '#15803d';
          ctx.fillRect(0, 145, vw, 3);

          // Yellow apron taxiway lead-in line
          ctx.fillStyle = '#facc15';
          for (let x = 14; x < vw; x += 44) {
            ctx.fillRect(x, 174, 24, 2.2);
          }

          // 4. Calibrated HD Side-Profile Scale for Hangar Inspection
          const pxPerMeter =
            aircraft.id === 'boeing_747'
              ? 5.0
              : aircraft.lengthM > 32
                ? 7.2
                : aircraft.lengthM > 22
                  ? 9.5
                  : aircraft.lengthM > 12
                    ? 14.5
                    : 20.5;

          const groundY = 166;
          const gearClearance = getAircraftGearClearancePx(aircraft, pxPerMeter);
          const acX = vw * 0.5;
          const acY = groundY - gearClearance;

          // Soft Elliptical Ground Shadow on Tarmac
          const shadowRx = Math.min(185, Math.max(68, aircraft.lengthM * pxPerMeter * 0.48));
          const shadowGrad = ctx.createRadialGradient(acX, groundY + 1, 6, acX, groundY + 1, shadowRx);
          shadowGrad.addColorStop(0, 'rgba(2, 6, 23, 0.55)');
          shadowGrad.addColorStop(0.65, 'rgba(2, 6, 23, 0.24)');
          shadowGrad.addColorStop(1, 'rgba(2, 6, 23, 0)');
          ctx.fillStyle = shadowGrad;
          ctx.beginPath();
          ctx.ellipse(acX, groundY + 1.5, shadowRx, 7, 0, 0, Math.PI * 2);
          ctx.fill();

          // 5. Render High-Resolution Aircraft
          ctx.save();
          ctx.translate(acX, acY);
          drawPixelAircraft(ctx, aircraft, pxPerMeter, {
            elevatorInput: Math.sin(now * 0.0022) * 0.35,
            flapAngleDeg: 10,
            gearPosition: 1,
            gearDamaged: false,
            propPhase: phase,
            powerPct: 38,
            isNightOrDusk: nightPreview,
            strobeOn: Math.floor(now / 450) % 2 === 0,
            onGround: true,
            bankDeg: 0,
          });
          ctx.restore();
        }
      }
      animId = requestAnimationFrame(renderFrame);
    };

    animId = requestAnimationFrame(renderFrame);
    return () => cancelAnimationFrame(animId);
  }, [aircraft, nightPreview]);

  return (
    <canvas
      ref={canvasRef}
      className={`sim-canvas w-full h-auto rounded-lg border border-slate-700/90 bg-slate-950 ${className}`}
    />
  );
};
